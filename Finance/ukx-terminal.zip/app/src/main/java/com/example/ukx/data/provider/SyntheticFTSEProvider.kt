package com.example.ukx.data.provider

import com.example.ukx.domain.model.LseListingType
import com.example.ukx.domain.model.SecurityMasterRecord
import com.example.ukx.domain.model.TradingExchange
import com.example.ukx.domain.model.UkSector

/**
 * Synthetic FTSE Data Provider (UKX-CORE)
 * 
 * Provides an institutional synthetic digital twin of London Stock Exchange equities.
 * Every datum is explicitly marked with status = SYNTHETIC / RECONSTRUCTED.
 */
object SyntheticFTSEProvider {

    fun generateCompleteSecurityUniverse(): List<SecurityMasterRecord> {
        val universe = mutableListOf<SecurityMasterRecord>()

        fun addSec(
            ticker: String,
            name: String,
            isin: String,
            sedol: String,
            sector: UkSector,
            industry: String,
            shares: Long,
            freeFloat: Double,
            priceGbp: Double,
            priceChange: Double,
            vol: Long,
            dps: Double,
            foreignSales: Double = 0.70,
            beta: Double = 1.0,
            listingType: LseListingType = LseListingType.PRIMARY_EQUITY,
            exchange: TradingExchange = TradingExchange.LSE_SETS,
            currency: String = "GBP"
        ) {
            universe.add(
                SecurityMasterRecord(
                    securityId = "SEC-LSE-$ticker",
                    companyId = "CMP-UK-$ticker",
                    ticker = ticker,
                    companyName = name,
                    isin = isin,
                    sedol = sedol,
                    exchange = exchange,
                    listingType = listingType,
                    tradingCurrency = currency,
                    sector = sector,
                    industry = industry,
                    sharesInIssue = shares,
                    freeFloatFactor = freeFloat,
                    priceGbp = priceGbp,
                    priceChangePct = priceChange,
                    volumeToday = vol,
                    medianDailyVolume = vol / 2,
                    dividendPerShareGbp = dps,
                    betaToUkx = beta,
                    foreignSalesPct = foreignSales
                )
            )
        }

        // Top UK Mega-Caps & Large-Caps
        addSec("SHEL", "Shell plc", "GB00BP6MXD84", "BP6MXD8", UkSector.ENERGY, "Oil & Gas Integrated", 6_450_000_000L, 0.98, 27.80, 1.45, 14_200_000, 1.14, 0.92, 1.25)
        addSec("AZN", "AstraZeneca plc", "GB0009895292", "0989529", UkSector.HEALTHCARE, "Pharmaceuticals", 1_550_000_000L, 0.99, 122.40, 0.85, 2_100_000, 3.10, 0.95, 0.75)
        addSec("HSBA", "HSBC Holdings plc", "GB0005405286", "0540528", UkSector.FINANCIALS, "Diversified Banking", 18_800_000_000L, 0.95, 6.75, 0.92, 28_500_000, 0.58, 0.88, 0.95)
        addSec("ULVR", "Unilever plc", "GB00B10RZP78", "B10RZP7", UkSector.CONSUMER_STAPLES, "Personal Goods", 2_510_000_000L, 0.97, 46.20, -0.32, 3_800_000, 1.52, 0.90, 0.65)
        addSec("BP.", "BP plc", "GB0007980591", "0798059", UkSector.ENERGY, "Oil & Gas Integrated", 16_800_000_000L, 0.99, 4.38, 1.85, 34_000_000, 0.24, 0.89, 1.20)
        addSec("GSK", "GSK plc", "GB00BN7SWP63", "BN7SWP6", UkSector.HEALTHCARE, "Pharmaceuticals", 4_100_000_000L, 0.98, 15.60, 0.40, 6_200_000, 0.60, 0.92, 0.70)
        addSec("BATS", "British American Tobacco plc", "GB0002875804", "0287580", UkSector.CONSUMER_STAPLES, "Tobacco", 2_220_000_000L, 0.96, 26.50, 0.15, 4_100_000, 2.38, 0.94, 0.60)
        addSec("RIO", "Rio Tinto plc", "GB0007188757", "0718875", UkSector.MATERIALS, "Diversified Mining", 1_250_000_000L, 0.88, 50.80, 2.10, 2_400_000, 3.45, 0.98, 1.35)
        addSec("DGE", "Diageo plc", "GB0002374006", "0237400", UkSector.CONSUMER_STAPLES, "Beverages", 2_230_000_000L, 0.99, 25.40, -0.80, 3_500_000, 0.82, 0.96, 0.80)
        addSec("LSEG", "London Stock Exchange Group plc", "GB00B0SWJX34", "B0SWJX3", UkSector.FINANCIALS, "Financial Market Infrastructure", 535_000_000L, 0.82, 98.60, 1.12, 950_000, 1.15, 0.85, 0.90)
        addSec("REL", "RELX plc", "GB00B2B0DG97", "B2B0DG9", UkSector.INDUSTRIALS, "Media & Analytics", 1_870_000_000L, 0.99, 36.40, 0.60, 2_200_000, 0.62, 0.88, 0.85)
        addSec("PRU", "Prudential plc", "GB0007099541", "0709954", UkSector.FINANCIALS, "Life Insurance", 2_740_000_000L, 0.98, 6.90, -1.25, 5_800_000, 0.16, 0.95, 1.10)
        addSec("GLEN", "Glencore plc", "JE00B4T3BW64", "B4T3BW6", UkSector.MATERIALS, "Metals & Mining", 12_200_000_000L, 0.90, 4.15, 1.95, 26_000_000, 0.13, 0.99, 1.40)
        addSec("BARC", "Barclays plc", "GB0031348658", "3134865", UkSector.FINANCIALS, "Banking", 14_900_000_000L, 0.95, 2.38, 1.50, 38_000_000, 0.085, 0.60, 1.15)
        addSec("LLOY", "Lloyds Banking Group plc", "GB0008706128", "0870612", UkSector.FINANCIALS, "Retail Banking", 63_200_000_000L, 0.99, 0.58, 0.85, 110_000_000, 0.031, 0.15, 1.05)
        addSec("NWG", "NatWest Group plc", "GB00BM8PJY71", "BM8PJY7", UkSector.FINANCIALS, "Banking", 8_400_000_000L, 0.85, 3.42, 1.30, 18_000_000, 0.18, 0.10, 1.05)
        addSec("BA.", "BAE Systems plc", "GB0002634946", "0263494", UkSector.INDUSTRIALS, "Aerospace & Defense", 3_020_000_000L, 0.99, 13.50, 0.70, 5_200_000, 0.32, 0.85, 0.65)
        addSec("RR.", "Rolls-Royce Holdings plc", "GB00B63H8491", "B63H849", UkSector.INDUSTRIALS, "Aerospace & Engines", 8_450_000_000L, 0.99, 5.25, 2.30, 22_000_000, 0.08, 0.90, 1.30)
        addSec("NG.", "National Grid plc", "GB00BDR05C01", "BDR05C0", UkSector.UTILITIES, "Multi-Utilities", 4_850_000_000L, 0.98, 10.15, -0.40, 8_100_000, 0.58, 0.40, 0.55)
        addSec("CPG", "Compass Group plc", "GB00BD6KKN57", "BD6KKN5", UkSector.CONSUMER_DISCRETIONARY, "Food Services", 1_710_000_000L, 0.99, 24.10, 0.50, 2_400_000, 0.45, 0.90, 0.80)
        addSec("EXPN", "Experian plc", "GB00B19NLV48", "B19NLV4", UkSector.INDUSTRIALS, "Financial Technology", 915_000_000L, 0.99, 38.60, 0.30, 1_100_000, 0.42, 0.92, 0.85)
        addSec("FLTR", "Flutter Entertainment plc", "IE00BWT62847", "BWT6284", UkSector.CONSUMER_DISCRETIONARY, "Gambling", 177_000_000L, 0.92, 178.00, 1.10, 450_000, 0.00, 0.90, 1.15)
        addSec("AHT", "Ashtead Group plc", "GB0000533227", "0053322", UkSector.INDUSTRIALS, "Equipment Rental", 438_000_000L, 0.99, 58.20, 1.60, 750_000, 0.88, 0.95, 1.25)
        addSec("HLN", "Haleon plc", "GB00BMX86V44", "BMX86V4", UkSector.HEALTHCARE, "Consumer Healthcare", 9_150_000_000L, 0.82, 3.88, 0.25, 12_000_000, 0.062, 0.90, 0.60)
        addSec("RKT", "Reckitt Benckiser Group plc", "GB00B24CGK77", "B24CGK7", UkSector.CONSUMER_STAPLES, "Household Products", 710_000_000L, 0.99, 44.80, -1.10, 1_400_000, 1.95, 0.92, 0.60)
        addSec("AAL", "Anglo American plc", "GB00B1XZS820", "B1XZS82", UkSector.MATERIALS, "Mining", 1_330_000_000L, 0.98, 23.90, 2.40, 4_200_000, 0.75, 0.98, 1.45)
        addSec("STAN", "Standard Chartered plc", "GB0004052071", "0405207", UkSector.FINANCIALS, "Emerging Markets Banking", 2_580_000_000L, 0.95, 8.45, 1.20, 5_600_000, 0.28, 0.98, 1.10)
        addSec("III", "3i Group plc", "GB00B1YW4409", "B1YW440", UkSector.FINANCIALS, "Private Equity & Infrastructure", 970_000_000L, 0.99, 32.80, 0.90, 1_800_000, 0.61, 0.85, 0.95)
        addSec("SSE", "SSE plc", "GB0007908733", "0790873", UkSector.UTILITIES, "Renewable Energy", 1_100_000_000L, 0.99, 18.20, -0.15, 2_100_000, 0.65, 0.20, 0.70)
        addSec("IMB", "Imperial Brands plc", "GB0004544929", "0454492", UkSector.CONSUMER_STAPLES, "Tobacco", 860_000_000L, 0.99, 21.60, 0.40, 1_800_000, 1.55, 0.90, 0.55)
        addSec("LGEN", "Legal & General Group plc", "GB0005603997", "0560399", UkSector.FINANCIALS, "Life Insurance & Asset Mgmt", 5_950_000_000L, 0.99, 2.28, -0.45, 12_500_000, 0.208, 0.30, 0.95)
        addSec("AV.", "Aviva plc", "GB0002162385", "0216238", UkSector.FINANCIALS, "Composite Insurance", 2_710_000_000L, 0.99, 4.92, 0.60, 6_100_000, 0.34, 0.25, 0.90)
        addSec("TSCO", "Tesco plc", "GB00BLGZ9862", "BLGZ986", UkSector.CONSUMER_STAPLES, "Food Retailers", 6_950_000_000L, 0.99, 3.65, 0.30, 14_000_000, 0.125, 0.20, 0.75)
        addSec("VOD", "Vodafone Group plc", "GB00BH4HKS39", "BH4HKS3", UkSector.TELECOMS, "Telecommunications", 26_500_000_000L, 0.95, 0.74, -0.80, 48_000_000, 0.045, 0.85, 0.80)
        addSec("SGE", "The Sage Group plc", "GB00B8C3BL03", "B8C3BL0", UkSector.TECHNOLOGY, "Enterprise Software", 1_010_000_000L, 0.98, 11.20, 0.55, 1_900_000, 0.20, 0.88, 0.85)
        addSec("NXT", "Next plc", "GB0032089863", "3208986", UkSector.CONSUMER_DISCRETIONARY, "Apparel Retail", 125_000_000L, 0.95, 96.50, 0.80, 240_000, 2.15, 0.30, 0.95)
        addSec("MKS", "Marks and Spencer Group plc", "GB0031274896", "3127489", UkSector.CONSUMER_DISCRETIONARY, "Department Stores", 1_980_000_000L, 0.98, 3.55, 1.40, 5_800_000, 0.035, 0.15, 1.05)
        addSec("BNZL", "Bunzl plc", "GB00B0744B38", "B0744B3", UkSector.INDUSTRIALS, "Distribution Services", 335_000_000L, 0.99, 35.80, 0.20, 620_000, 0.70, 0.90, 0.75)
        addSec("HLMA", "Halma plc", "GB0004052071", "0405207", UkSector.TECHNOLOGY, "Safety Electronics", 380_000_000L, 0.99, 26.20, 0.40, 710_000, 0.22, 0.85, 0.80)
        addSec("SPX", "Spirax Group plc", "GB00BWFGQN14", "BWFGQN1", UkSector.INDUSTRIALS, "Thermal Energy & Pumping", 74_000_000L, 0.98, 72.50, -0.60, 180_000, 1.62, 0.92, 0.85)
        addSec("ANTO", "Antofagasta plc", "GB0000456144", "0045614", UkSector.MATERIALS, "Copper Mining", 985_000_000L, 0.35, 18.50, 1.80, 1_400_000, 0.38, 0.99, 1.35)
        addSec("SGRO", "SEGRO plc", "GB00B5ZN1N88", "B5ZN1N8", UkSector.REAL_ESTATE, "Industrial REIT", 1_350_000_000L, 0.99, 8.85, -1.10, 3_100_000, 0.285, 0.40, 0.90, LseListingType.REIT)
        addSec("LAND", "Land Securities Group plc", "GB00BYW0PQ60", "BYW0PQ6", UkSector.REAL_ESTATE, "Commercial REIT", 750_000_000L, 0.99, 6.40, -1.30, 2_200_000, 0.395, 0.05, 0.95, LseListingType.REIT)
        addSec("BLND", "The British Land Company plc", "GB0001367019", "0136701", UkSector.REAL_ESTATE, "Commercial REIT", 930_000_000L, 0.99, 4.10, -0.90, 2_800_000, 0.23, 0.05, 0.95, LseListingType.REIT)
        addSec("SVT", "Severn Trent plc", "GB00B1FH8J72", "B1FH8J7", UkSector.UTILITIES, "Water Utility", 300_000_000L, 0.99, 26.80, -0.20, 680_000, 1.18, 0.00, 0.50)
        addSec("UU.", "United Utilities Group plc", "GB00B39J2M42", "B39J2M4", UkSector.UTILITIES, "Water Utility", 685_000_000L, 0.99, 10.45, -0.30, 1_500_000, 0.49, 0.00, 0.50)
        addSec("CNA", "Centrica plc", "GB00B033F229", "B033F22", UkSector.UTILITIES, "Gas & Electricity Supply", 5_300_000_000L, 0.98, 1.25, 0.50, 16_000_000, 0.045, 0.25, 0.85)
        addSec("BEZ", "Beazley plc", "GB00BYQ0JC66", "BYQ0JC6", UkSector.FINANCIALS, "Specialist Insurance", 670_000_000L, 0.98, 7.80, 0.90, 1_300_000, 0.165, 0.85, 0.80)
        addSec("HSX", "Hiscox Ltd", "BMG4593F1389", "B178229", UkSector.FINANCIALS, "Specialist Insurance", 350_000_000L, 0.95, 11.40, 0.40, 620_000, 0.39, 0.80, 0.80)
        addSec("ADM", "Admiral Group plc", "GB00B02J6398", "B02J639", UkSector.FINANCIALS, "Motor Insurance", 305_000_000L, 0.88, 28.60, 0.30, 480_000, 1.25, 0.15, 0.70)
        addSec("PHNX", "Phoenix Group Holdings plc", "GB00BGXQNP29", "BGXQNP2", UkSector.FINANCIALS, "Life Insurance", 1_000_000_000L, 0.92, 5.45, -0.20, 2_400_000, 0.535, 0.10, 0.85)
        addSec("MNG", "M&G plc", "GB00BKFBFL54", "BKFBFL5", UkSector.FINANCIALS, "Investment Management", 2_380_000_000L, 0.98, 2.12, -0.50, 6_200_000, 0.20, 0.30, 0.95)
        addSec("ITRK", "Intertek Group plc", "GB0031638363", "3163836", UkSector.INDUSTRIALS, "Testing & Inspection", 162_000_000L, 0.99, 49.50, 0.10, 290_000, 1.15, 0.92, 0.80)
        addSec("SMIN", "Smiths Group plc", "GB00B1WY2338", "B1WY233", UkSector.INDUSTRIALS, "Industrial Engineering", 345_000_000L, 0.98, 17.80, 0.40, 580_000, 0.44, 0.90, 0.85)
        addSec("WEIR", "The Weir Group plc", "GB0009465807", "0946580", UkSector.INDUSTRIALS, "Mining Machinery", 260_000_000L, 0.98, 21.40, 1.20, 480_000, 0.39, 0.95, 1.10)
        addSec("IMI", "IMI plc", "GB00BGLP8L22", "BGLP8L2", UkSector.INDUSTRIALS, "Fluid Engineering", 255_000_000L, 0.99, 18.10, 0.30, 420_000, 0.30, 0.90, 0.90)
        addSec("RTO", "Rentokil Initial plc", "GB00B082RF11", "B082RF1", UkSector.INDUSTRIALS, "Pest Control & Hygiene", 2_540_000_000L, 0.98, 3.85, -1.80, 8_900_000, 0.088, 0.90, 0.95)
        addSec("JD.", "JD Sports Fashion plc", "GB00BYX9MX42", "BYX9MX4", UkSector.CONSUMER_DISCRETIONARY, "Athletic Retail", 5_180_000_000L, 0.48, 1.32, -0.90, 11_000_000, 0.012, 0.70, 1.15)
        addSec("WTB", "Whitbread plc", "GB00B1KJJ408", "B1KJJ40", UkSector.CONSUMER_DISCRETIONARY, "Hotels & Restaurants", 182_000_000L, 0.98, 30.50, 0.60, 390_000, 0.98, 0.20, 0.85)
        addSec("IHG", "InterContinental Hotels Group plc", "GB00BHJYC031", "BHJYC03", UkSector.CONSUMER_DISCRETIONARY, "Hotels", 163_000_000L, 0.98, 85.20, 0.40, 280_000, 1.25, 0.95, 0.90)
        addSec("CRDA", "Croda International plc", "GB00BJFFLV09", "BJFFLV0", UkSector.MATERIALS, "Specialty Chemicals", 140_000_000L, 0.99, 41.20, -0.50, 310_000, 1.10, 0.88, 0.95)
        addSec("BDEV", "Barratt Developments plc", "GB0000811801", "0081180", UkSector.CONSUMER_DISCRETIONARY, "Residential Construction", 975_000_000L, 0.99, 4.85, 0.70, 2_400_000, 0.165, 0.00, 1.05)
        addSec("TW.", "Taylor Wimpey plc", "GB0008782301", "0878230", UkSector.CONSUMER_DISCRETIONARY, "Residential Construction", 3_550_000_000L, 0.99, 1.55, 0.80, 8_200_000, 0.095, 0.00, 1.05)
        addSec("HWDN", "Howden Joinery Group plc", "GB0005576813", "0557681", UkSector.INDUSTRIALS, "Building Products", 550_000_000L, 0.99, 9.20, 0.30, 950_000, 0.21, 0.10, 0.90)
        addSec("BME", "B&M European Value Retail SA", "LU1072616219", "BMR9624", UkSector.CONSUMER_DISCRETIONARY, "Discount Retail", 1_005_000_000L, 0.85, 4.60, -0.40, 2_100_000, 0.155, 0.20, 0.85)
        addSec("KGF", "Kingfisher plc", "GB0033195214", "3319521", UkSector.CONSUMER_DISCRETIONARY, "Home Improvement Retail", 1_850_000_000L, 0.99, 2.75, 0.20, 4_100_000, 0.125, 0.50, 0.95)
        addSec("SBRY", "J Sainsbury plc", "GB00B019KW72", "B019KW7", UkSector.CONSUMER_STAPLES, "Food Retailers", 2_350_000_000L, 0.88, 2.95, 0.10, 4_800_000, 0.135, 0.05, 0.70)
        addSec("EDV", "Endeavour Mining plc", "GB00BL6K5J42", "BL6K5J4", UkSector.MATERIALS, "Gold Mining", 245_000_000L, 0.82, 17.40, 2.60, 680_000, 0.65, 0.99, 1.25)
        addSec("FRES", "Fresnillo plc", "GB00B2QPKJ12", "B2QPKJ1", UkSector.MATERIALS, "Silver & Gold Mining", 736_000_000L, 0.25, 6.45, 3.10, 1_100_000, 0.065, 0.99, 1.30)
        addSec("PNN", "Pennon Group plc", "GB00BNNTLN49", "BNNTLN4", UkSector.UTILITIES, "Water Utility", 390_000_000L, 0.99, 6.10, -0.70, 750_000, 0.44, 0.00, 0.55)

        // 2026 Additions & Boundary Movers (June & September Reviews)
        addSec("EZJ", "easyJet plc", "GB00B7KR2P84", "B7KR2P8", UkSector.CONSUMER_DISCRETIONARY, "Airlines", 760_000_000L, 0.85, 6.38, 1.90, 3_800_000, 0.12, 0.75, 1.25)
        addSec("ITH", "Ithaca Energy plc", "GB00BPJNZ491", "BPJNZ49", UkSector.ENERGY, "North Sea Oil & Gas", 1_450_000_000L, 0.85, 3.25, 2.40, 2_200_000, 0.28, 0.30, 1.30)
        addSec("ABDN", "Aberdeen Group plc", "GB00BF8Q6K64", "BF8Q6K6", UkSector.FINANCIALS, "Asset Management", 1_880_000_000L, 0.90, 2.72, 1.10, 4_100_000, 0.146, 0.50, 1.05)
        addSec("CCC", "Computacenter plc", "GB00BV9FP384", "BV9FP38", UkSector.TECHNOLOGY, "IT Infrastructure Services", 114_000_000L, 0.88, 43.60, 0.90, 220_000, 0.72, 0.70, 0.95)
        addSec("INVP", "Investec plc", "GB00B17BBQ50", "B17BBQ5", UkSector.FINANCIALS, "Banking & Wealth Mgmt", 695_000_000L, 0.88, 6.70, 1.20, 1_400_000, 0.36, 0.70, 1.00)

        // Extended Blue-Chips & Incumbents (reaching full 100 constituents)
        addSec("DCC", "DCC plc", "IE0002424900", "0242490", UkSector.INDUSTRIALS, "Support Services", 99_000_000L, 0.98, 56.40, 0.30, 180_000, 1.95, 0.85, 0.80)
        addSec("SMDS", "Smith (DS) plc", "GB0008220112", "0822011", UkSector.MATERIALS, "Packaging", 1_380_000_000L, 0.99, 4.80, 0.10, 2_900_000, 0.18, 0.85, 0.90)
        addSec("AUTO", "Auto Trader Group plc", "GB00BVYVFW23", "BVYVFW2", UkSector.TECHNOLOGY, "Online Classifieds", 910_000_000L, 0.99, 8.40, 0.40, 1_400_000, 0.096, 0.05, 0.85)
        addSec("HIK", "Hikma Pharmaceuticals plc", "GB00B0LCW083", "B0LCW08", UkSector.HEALTHCARE, "Generics & Injectables", 220_000_000L, 0.72, 19.80, -0.40, 390_000, 0.58, 0.95, 0.70)
        addSec("UTG", "Unite Group plc", "GB0009137452", "0913745", UkSector.REAL_ESTATE, "Student Accommodation REIT", 440_000_000L, 0.99, 9.45, -0.50, 750_000, 0.36, 0.00, 0.85, LseListingType.REIT)
        addSec("JMAT", "Johnson Matthey plc", "GB00BZ4BQC70", "BZ4BQC7", UkSector.MATERIALS, "Catalysts & Platinum", 183_000_000L, 0.99, 16.20, 0.70, 420_000, 0.77, 0.90, 1.05)
        addSec("SN.", "Smith & Nephew plc", "GB0009223206", "0922320", UkSector.HEALTHCARE, "Medical Equipment", 875_000_000L, 0.99, 11.15, -0.30, 1_800_000, 0.30, 0.95, 0.75)
        addSec("BKG", "Berkeley Group Holdings plc", "GB00BLGLQ970", "BLGLQ97", UkSector.CONSUMER_DISCRETIONARY, "Homebuilding", 108_000_000L, 0.96, 32.80, 0.40, 240_000, 0.66, 0.00, 1.05)
        addSec("MNDI", "Mondi plc", "GB00B1CRLC47", "B1CRLC4", UkSector.MATERIALS, "Paper & Packaging", 485_000_000L, 0.98, 7.05, -0.20, 950_000, 0.45, 0.90, 0.95)
        addSec("RMV", "Rightmove plc", "GB00BGDTB052", "BGDTB05", UkSector.TECHNOLOGY, "Real Estate Portal", 805_000_000L, 0.98, 4.16, -0.80, 2_100_000, 0.09, 0.00, 0.85)
        addSec("ENT", "Entain plc", "IM00B5VQMV65", "B5VQMV6", UkSector.CONSUMER_DISCRETIONARY, "Sports Betting", 640_000_000L, 0.90, 5.39, -1.90, 1_800_000, 0.178, 0.80, 1.15)
        addSec("PSN", "Persimmon plc", "GB0006825383", "0682538", UkSector.CONSUMER_DISCRETIONARY, "Residential Construction", 320_000_000L, 0.99, 10.55, 0.30, 720_000, 0.60, 0.00, 1.10)
        addSec("SDR", "Schroders plc", "GB0002405495", "0240549", UkSector.FINANCIALS, "Asset Management", 1_600_000_000L, 0.55, 3.85, -0.40, 1_200_000, 0.215, 0.65, 0.95)
        addSec("ROO", "Deliveroo plc", "GB00BNC5T391", "BNC5T39", UkSector.TECHNOLOGY, "Food Delivery Tech", 1_750_000_000L, 0.80, 1.55, 1.10, 3_100_000, 0.00, 0.40, 1.20)
        addSec("BWY", "Bellway plc", "GB0000904986", "0090498", UkSector.CONSUMER_DISCRETIONARY, "Homebuilder", 120_000_000L, 0.99, 28.40, 0.80, 210_000, 0.54, 0.00, 1.05)
        addSec("VTY", "Vistry Group plc", "GB0001859296", "0185929", UkSector.CONSUMER_DISCRETIONARY, "Partnership Housing", 340_000_000L, 0.98, 8.90, -0.60, 850_000, 0.32, 0.00, 1.10)
        addSec("DLG", "Direct Line Insurance Group plc", "GB00BY9DNL86", "BY9DNL8", UkSector.FINANCIALS, "General Insurance", 1_310_000_000L, 0.99, 1.95, 0.50, 2_400_000, 0.076, 0.00, 0.80)
        addSec("DOCS", "Dr. Martens plc", "GB00BL6NGV24", "BL6NGV2", UkSector.CONSUMER_DISCRETIONARY, "Footwear & Apparel", 960_000_000L, 0.65, 0.62, -2.10, 1_900_000, 0.025, 0.85, 1.30)
        addSec("AML", "Aston Martin Lagonda Global Holdings", "GB00BFXZC444", "BFXZC44", UkSector.CONSUMER_DISCRETIONARY, "Luxury Automobiles", 820_000_000L, 0.55, 1.18, -3.20, 2_500_000, 0.00, 0.90, 1.45)
        addSec("DARK", "Darktrace plc", "GB00BNK3CD64", "BNK3CD6", UkSector.TECHNOLOGY, "Cybersecurity AI", 710_000_000L, 0.75, 5.80, 0.90, 1_600_000, 0.00, 0.85, 1.25)
        addSec("QTEK", "Quanta Technology Group plc", "GB00B891XYZ1", "B891XYZ", UkSector.TECHNOLOGY, "Semiconductor IP", 310_000_000L, 0.92, 14.50, 2.80, 680_000, 0.15, 0.95, 1.35)
        addSec("LION", "Liontrust Asset Management plc", "GB0007388407", "0738840", UkSector.FINANCIALS, "Fund Management", 65_000_000L, 0.98, 6.20, -0.40, 110_000, 0.72, 0.20, 1.10)
        addSec("WIZZ", "Wizz Air Holdings plc", "JE00BN574F90", "BN574F9", UkSector.CONSUMER_DISCRETIONARY, "Airlines", 103_000_000L, 0.70, 13.80, 2.10, 310_000, 0.00, 0.90, 1.40)
        addSec("TUI", "TUI AG", "DE000TUAG505", "TUAG505", UkSector.CONSUMER_DISCRETIONARY, "Travel & Tourism", 507_000_000L, 0.85, 6.40, 1.50, 1_200_000, 0.00, 0.85, 1.30)
        addSec("CBG", "Close Brothers Group plc", "GB0007668071", "0766807", UkSector.FINANCIALS, "Merchant Banking", 150_000_000L, 0.95, 2.85, -1.20, 850_000, 0.12, 0.00, 1.15)
        addSec("SGC", "Supermarket Income REIT plc", "GB00BF37LF46", "BF37LF4", UkSector.REAL_ESTATE, "Grocery Property REIT", 1_240_000_000L, 0.99, 0.78, 0.10, 1_400_000, 0.061, 0.00, 0.50, LseListingType.REIT)
        addSec("GRP", "Greencoat UK Wind plc", "GB00B8SC6K54", "B8SC6K5", UkSector.UTILITIES, "Renewable Energy Fund", 2_310_000_000L, 0.99, 1.32, 0.20, 2_100_000, 0.10, 0.00, 0.45, LseListingType.INVESTMENT_ENTITY)
        addSec("TRIG", "The Renewables Infrastructure Group", "GG00BBHX2H91", "BBHX2H9", UkSector.UTILITIES, "Clean Energy Fund", 2_480_000_000L, 0.99, 0.95, -0.10, 1_900_000, 0.075, 0.20, 0.45, LseListingType.INVESTMENT_ENTITY)
        addSec("HICL", "HICL Infrastructure plc", "GB00BJLP1Y05", "BJLP1Y0", UkSector.FINANCIALS, "Core Infrastructure Fund", 2_030_000_000L, 0.99, 1.22, 0.30, 1_600_000, 0.082, 0.25, 0.40, LseListingType.INVESTMENT_ENTITY)
        addSec("INPP", "International Public Partnerships", "GB00B1YKG049", "B1YKG04", UkSector.FINANCIALS, "PPP Infrastructure Fund", 1_910_000_000L, 0.99, 1.26, 0.00, 1_400_000, 0.081, 0.30, 0.40, LseListingType.INVESTMENT_ENTITY)
        addSec("THG", "THG plc", "GB00BMTV7393", "BMTV739", UkSector.CONSUMER_DISCRETIONARY, "E-Commerce Tech", 1_350_000_000L, 0.52, 0.58, -1.80, 2_200_000, 0.00, 0.60, 1.40)
        addSec("BVIC", "Britvic plc", "GB00B0N8QD54", "B0N8QD5", UkSector.CONSUMER_STAPLES, "Soft Drinks", 248_000_000L, 0.98, 12.80, 0.10, 310_000, 0.345, 0.40, 0.70)
        addSec("GNS", "Genuit Group plc", "GB00BL635444", "BL63544", UkSector.INDUSTRIALS, "Water & Climate Systems", 250_000_000L, 0.99, 4.45, 0.60, 380_000, 0.124, 0.05, 0.95)
        addSec("BOY", "Bodycote plc", "GB00B3FLWH99", "B3FLWH9", UkSector.INDUSTRIALS, "Thermal Processing", 190_000_000L, 0.98, 6.15, 0.40, 290_000, 0.23, 0.85, 1.05)
        addSec("RNK", "The Rank Group plc", "GB00B14H7397", "B14H739", UkSector.CONSUMER_DISCRETIONARY, "Gaming & Casinos", 470_000_000L, 0.45, 0.82, 0.70, 410_000, 0.00, 0.15, 1.15)
        addSec("GFTU", "Grafton Group plc", "IE00B00MZ448", "B00MZ44", UkSector.INDUSTRIALS, "Building Distribution", 205_000_000L, 0.98, 10.20, 0.50, 280_000, 0.36, 0.35, 0.95)

        return universe
    }
}
