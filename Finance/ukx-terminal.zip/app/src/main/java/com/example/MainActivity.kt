package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxTerminalTheme
import com.example.ukx.ui.TerminalTab
import com.example.ukx.ui.UkxTerminalViewModel
import com.example.ukx.ui.components.TerminalHeader
import com.example.ukx.ui.components.TerminalTabBar
import com.example.ukx.ui.screens.ConstituentMatrixScreen
import com.example.ukx.ui.screens.HeatmapAndSectorsScreen
import com.example.ukx.ui.screens.MacroScenarioLabScreen
import com.example.ukx.ui.screens.MethodologyAndRulesScreen
import com.example.ukx.ui.screens.QuarterlyReviewScreen
import com.example.ukx.ui.screens.TerminalHomeScreen
import com.example.ukx.ui.screens.TotalReturnAndDividendsScreen
import com.example.ukx.ui.screens.UkIndexApiScreen
import com.example.ukx.ui.screens.UkxAiAssistantScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            UkxTerminalTheme {
                UkxTerminalApp()
            }
        }
    }
}

@Composable
fun UkxTerminalApp(
    viewModel: UkxTerminalViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding(),
        containerColor = UkxObsidian
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(UkxObsidian)
        ) {
            // Institutional Terminal Top Header
            TerminalHeader(
                selectedIndex = uiState.selectedIndex,
                selectedCurrency = uiState.selectedCurrency,
                isStreaming = uiState.isRealtimeStreaming,
                onIndexSelected = { viewModel.selectIndex(it) },
                onCurrencySelected = { viewModel.selectCurrency(it) }
            )

            // Dealing Room Monospace Navigation Bar
            TerminalTabBar(
                selectedTab = uiState.activeTab,
                onTabSelected = { viewModel.selectTab(it) }
            )

            // Main Active Screen Pane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
            ) {
                when (uiState.activeTab) {
                    TerminalTab.HOME -> {
                        TerminalHomeScreen(uiState = uiState)
                    }
                    TerminalTab.CONSTITUENTS -> {
                        ConstituentMatrixScreen(
                            uiState = uiState,
                            onSearchQueryChanged = { viewModel.updateSearchQuery(it) },
                            onSectorFilterSelected = { viewModel.setSectorFilter(it) },
                            onSortFieldSelected = { viewModel.setSort(it) },
                            onConstituentSelected = { viewModel.selectConstituent(it) }
                        )
                    }
                    TerminalTab.HEATMAP -> {
                        HeatmapAndSectorsScreen(
                            uiState = uiState,
                            onConstituentSelected = { viewModel.selectConstituent(it) }
                        )
                    }
                    TerminalTab.REVIEW_TWIN -> {
                        QuarterlyReviewScreen(
                            uiState = uiState,
                            onReviewSelected = { viewModel.selectReviewEvent(it) }
                        )
                    }
                    TerminalTab.TOTAL_RETURN -> {
                        TotalReturnAndDividendsScreen(uiState = uiState)
                    }
                    TerminalTab.METHODOLOGY -> {
                        MethodologyAndRulesScreen(
                            uiState = uiState,
                            onMethodologySelected = { viewModel.selectMethodologyVersion(it) },
                            onTestSecurityTicker = { viewModel.testSecurityEligibility(it) }
                        )
                    }
                    TerminalTab.SCENARIO_LAB -> {
                        MacroScenarioLabScreen(
                            uiState = uiState,
                            onScenarioSelected = { viewModel.selectMacroScenario(it) },
                            onCustomIndexBuild = { viewModel.runCustomIndexBuild(it) }
                        )
                    }
                    TerminalTab.DEVELOPER_API -> {
                        UkIndexApiScreen(
                            uiState = uiState,
                            onExecuteQuery = { viewModel.executeApiQuery(it) }
                        )
                    }
                    TerminalTab.UKX_AI -> {
                        UkxAiAssistantScreen(
                            uiState = uiState,
                            onSendMessage = { viewModel.sendAiUserQuery(it) }
                        )
                    }
                }
            }
        }
    }
}
