package com.example.ukx.domain.model

data class ReviewConstituentChange(
    val ticker: String,
    val companyName: String,
    val sector: UkSector,
    val rank: Int,
    val fullMarketCapGbp: Double,
    val investableMarketCapGbp: Double,
    val reason: String
)

data class ReviewCalendar(
    val reviewMonth: String,
    val rankingCutoff: String,
    val dataCutoff: String,
    val announcementDate: String,
    val implementationDate: String,
    val effectiveDate: String,
    val isLocked: Boolean = false
)

data class QuarterlyReviewEvent(
    val reviewId: String,
    val title: String,
    val reviewQuarter: String,
    val calendar: ReviewCalendar,
    val additions: List<ReviewConstituentChange>,
    val deletions: List<ReviewConstituentChange>,
    val promotions: List<ReviewConstituentChange>,
    val demotions: List<ReviewConstituentChange>,
    val oneWayTurnoverPct: Double,
    val estimatedPassiveRebalanceGbp: Double,
    val methodologyVersion: String,
    val status: DataStatus = DataStatus.SYNTHETIC,
    val officialAnnouncementNotice: String
)

enum class BufferStatus(val label: String, val badgeColorHex: Long) {
    SECURE_CONSTITUENT("Rank 1-90: Fully Secure", 0xFF238636),
    BORDERLINE_INCUMBENT("Rank 91-100: Borderline Incumbent", 0xFFD29922),
    BUFFER_ZONE_AT_RISK("Rank 101-110: Buffer Zone / At Risk", 0xFFDB6D28),
    AUTOMATIC_DEMOTION("Rank 111+: Automatic Demotion", 0xFFF85149),
    AUTOMATIC_PROMOTION("Rank <=90 (FTSE 250): Automatic Promotion", 0xFF1F6FEB),
    CHALLENGER_CANDIDATE("Rank 91-100 (FTSE 250): Reserve List", 0xFF8957E5)
}

data class ReviewCandidate(
    val rank: Int,
    val ticker: String,
    val companyName: String,
    val currentIndex: String,
    val projectedIndex: String,
    val fullMarketCapGbp: Double,
    val investableMarketCapGbp: Double,
    val freeFloatPct: Double,
    val liquidityRatio: Double,
    val bufferStatus: BufferStatus,
    val estimatedWeightChangePct: Double,
    val estimatedPassiveFlowGbp: Double
)
