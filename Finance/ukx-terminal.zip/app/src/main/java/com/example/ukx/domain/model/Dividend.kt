package com.example.ukx.domain.model

data class DividendPointRecord(
    val recordId: String,
    val ticker: String,
    val companyName: String,
    val exDate: String,
    val recordDate: String,
    val paymentDate: String,
    val dividendPerShareGbp: Double,
    val currency: String = "GBP",
    val isSpecial: Boolean = false,
    val constituentWeightPct: Double,
    val dividendPoints: Double, // Contribution to FTSE 100 dividend index points
    val indexYieldImpactBps: Double,
    val withholdingTaxRatePct: Double = 0.0 // UK domestic dividend standard
)

data class DividendSeriesState(
    val indexCode: String = "UKX",
    val tradeYear: Int = 2026,
    val annualDeclaredPoints: Double = 312.45,
    val cumulativeYearToDatePoints: Double = 248.80,
    val estimatedForwardAnnualYieldPct: Double = 3.82,
    val rolling12mPoints: Double = 318.20,
    val topDividendContributors: List<DividendPointRecord>
)
