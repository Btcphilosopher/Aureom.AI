package com.example.ukx.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ukx.core.engine.CustomIndexConfig
import com.example.ukx.core.engine.CustomIndexLabEngine
import com.example.ukx.core.engine.DividendEngine
import com.example.ukx.core.engine.FTSE100SelectionEngine
import com.example.ukx.core.engine.FTSEEligibilityEngine
import com.example.ukx.core.engine.FastEntryEngine
import com.example.ukx.core.engine.FactorTilt
import com.example.ukx.core.engine.IndexCalculator
import com.example.ukx.core.engine.MacroScenarioEngine
import com.example.ukx.core.engine.QuarterlyReviewEngine
import com.example.ukx.core.engine.UKXDivisorEngine
import com.example.ukx.data.provider.SyntheticFTSEProvider
import com.example.ukx.domain.model.CorporateActionEvent
import com.example.ukx.domain.model.DataStatus
import com.example.ukx.domain.model.DividendSeriesState
import com.example.ukx.domain.model.EligibilityTestResult
import com.example.ukx.domain.model.FTSEIndex
import com.example.ukx.domain.model.FactorScore
import com.example.ukx.domain.model.IndexConstituent
import com.example.ukx.domain.model.IndexState
import com.example.ukx.domain.model.MacroScenarioImpact
import com.example.ukx.domain.model.MacroScenarioType
import com.example.ukx.domain.model.MethodologyVersion
import com.example.ukx.domain.model.QuarterlyReviewEvent
import com.example.ukx.domain.model.ReviewCandidate
import com.example.ukx.domain.model.SecurityMasterRecord
import com.example.ukx.domain.model.UkSector
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class TerminalTab(val title: String, val code: String) {
    HOME("TERMINAL", "UKX"),
    CONSTITUENTS("CONSTITUENTS", "100"),
    HEATMAP("HEATMAP & SECTORS", "MAP"),
    REVIEW_TWIN("REVIEW ENGINE", "REV"),
    TOTAL_RETURN("TOTAL RETURN", "TR"),
    METHODOLOGY("METHODOLOGY", "MET"),
    SCENARIO_LAB("MACRO SHOCKS", "SCN"),
    DEVELOPER_API("UK INDEX API", "API"),
    UKX_AI("UKX AI QUANT", "AI")
}

enum class ConstituentSortField {
    RANK, TICKER, FULL_MCAP, INVESTABLE_MCAP, FREE_FLOAT, WEIGHT, RETURN, CONTRIBUTION, DIVIDEND_YIELD
}

enum class SortDirection {
    ASCENDING, DESCENDING
}

enum class DisplayCurrency(val symbol: String, val code: String, val rateToGbp: Double) {
    GBP("£", "GBP", 1.0),
    USD("$", "USD", 1.31),
    EUR("€", "EUR", 1.18)
}

data class UkxAiChatMessage(
    val id: String,
    val sender: String, // "USER" or "UKX-AI"
    val content: String,
    val timestamp: String,
    val calculationDetails: String? = null,
    val provenance: String? = null,
    val methodologyChecksum: String? = null
)

data class UkxTerminalUiState(
    val activeTab: TerminalTab = TerminalTab.HOME,
    val selectedIndex: FTSEIndex = FTSEIndex.UKX_100,
    val selectedCurrency: DisplayCurrency = DisplayCurrency.GBP,
    val activeMethodology: MethodologyVersion = MethodologyVersion.VERSION_2026_JUN,
    val currentIndexState: IndexState? = null,
    val allUniverseSecurities: List<SecurityMasterRecord> = emptyList(),
    val factorScores: List<FactorScore> = emptyList(),
    val dividendState: DividendSeriesState? = null,
    val corporateActions: List<CorporateActionEvent> = emptyList(),
    // Constituent Table State
    val searchQuery: String = "",
    val selectedSectorFilter: UkSector? = null,
    val sortField: ConstituentSortField = ConstituentSortField.WEIGHT,
    val sortDirection: SortDirection = SortDirection.DESCENDING,
    val selectedConstituent: IndexConstituent? = null,
    // Quarterly Review State
    val historicalReviews: List<QuarterlyReviewEvent> = emptyList(),
    val activeReviewEvent: QuarterlyReviewEvent? = null,
    val reviewCandidates: List<ReviewCandidate> = emptyList(),
    // Scenario & Custom Lab State
    val activeScenario: MacroScenarioType = MacroScenarioType.GBP_STRENGTH,
    val activeScenarioImpact: MacroScenarioImpact? = null,
    val customIndexConfig: CustomIndexConfig = CustomIndexConfig("UK Quality 50", "UKQUAL", FactorTilt.QUALITY_PROFITABILITY),
    val customIndexState: IndexState? = null,
    // Eligibility Tester State
    val testSecurityTicker: String = "SHEL",
    val eligibilityTestResult: EligibilityTestResult? = null,
    val fastEntryEvaluation: FastEntryEngine.FastEntryEvaluation? = null,
    // API & AI Sandbox State
    val apiQueryInput: String = "INDEX FTSE100",
    val apiOutputJson: String = "",
    val aiMessages: List<UkxAiChatMessage> = emptyList(),
    val isRealtimeStreaming: Boolean = true
)

class UkxTerminalViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(UkxTerminalUiState())
    val uiState: StateFlow<UkxTerminalUiState> = _uiState.asStateFlow()

    init {
        initializeTerminalData()
    }

    private fun initializeTerminalData() {
        val universe = SyntheticFTSEProvider.generateCompleteSecurityUniverse()
        val currentConstituentTickers = universe.take(100).map { it.ticker }.toSet()

        // 1. Select initial 100 constituents via Selection Engine
        val (selected, candidates) = FTSE100SelectionEngine.selectConstituents(
            eligibleSecurities = universe,
            currentConstituentTickers = currentConstituentTickers,
            methodology = MethodologyVersion.VERSION_2026_JUN
        )

        // 2. Compute Primary Index State
        val indexState = IndexCalculator.calculateIndexState(
            index = FTSEIndex.UKX_100,
            selectedSecurities = selected,
            methodologyVersion = MethodologyVersion.VERSION_2026_JUN.version
        )

        // 3. Compute Factors, Dividends, Reviews, Corporate Actions
        val factorScores = CustomIndexLabEngine.generateFactorScores(universe)
        val dividendState = DividendEngine.generateStandardDividendSchedule(FTSEIndex.UKX_100.divisor)
        val corporateActions = UKXDivisorEngine.generateStandardCorporateActionHistory(FTSEIndex.UKX_100.divisor)
        val historicalReviews = QuarterlyReviewEngine.getHistoricalReviews()
        val (simCandidates, simEvent) = QuarterlyReviewEngine.simulateDecember2026Review(universe, currentConstituentTickers)

        // 4. Initial Scenario Run
        val scenarioImpact = MacroScenarioEngine.runScenario(
            scenarioType = MacroScenarioType.GBP_STRENGTH,
            constituents = indexState.constituents,
            currentIndexLevel = indexState.indexLevel
        )

        // 5. Initial Custom Index Run
        val customState = CustomIndexLabEngine.buildCustomIndex(
            config = CustomIndexConfig("UK Quality 50", "UKQUAL", FactorTilt.QUALITY_PROFITABILITY),
            allSecurities = universe,
            factorScores = factorScores
        )

        // 6. Initial Eligibility Test for default stock (SHEL)
        val defaultSec = universe.firstOrNull { it.ticker == "SHEL" } ?: universe.first()
        val eligResult = FTSEEligibilityEngine.testEligibility(defaultSec, MethodologyVersion.VERSION_2026_JUN, true)
        val fastEntryEval = FastEntryEngine.evaluateIpoListing(defaultSec, universe, MethodologyVersion.VERSION_2026_JUN)

        val initialAiMessage = UkxAiChatMessage(
            id = "AI-001",
            sender = "UKX-AI",
            content = "UKX-CORE Quantitative Attribution System active. Ask any attribution, rebalance, corporate action, or index decomposition query. Answers are calculated strictly from internal rules and synthetic market state.",
            timestamp = "08:00:00 UTC",
            calculationDetails = "Index: FTSE 100 (UKX) | Level: 8,342.15 | Divisor: 23,749,281.45",
            provenance = "UKX-CORE / SyntheticFTSEProvider | Status: SYNTHETIC",
            methodologyChecksum = "SHA256:0d72bc194a8e312f"
        )

        _uiState.update {
            it.copy(
                currentIndexState = indexState,
                allUniverseSecurities = universe,
                factorScores = factorScores,
                dividendState = dividendState,
                corporateActions = corporateActions,
                historicalReviews = historicalReviews,
                activeReviewEvent = simEvent,
                reviewCandidates = simCandidates,
                activeScenarioImpact = scenarioImpact,
                customIndexState = customState,
                eligibilityTestResult = eligResult,
                fastEntryEvaluation = fastEntryEval,
                aiMessages = listOf(initialAiMessage),
                apiOutputJson = generateApiJsonResponse("INDEX FTSE100", indexState)
            )
        }
    }

    fun selectTab(tab: TerminalTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun selectIndex(index: FTSEIndex) {
        val universe = _uiState.value.allUniverseSecurities
        val selectedSecs = when (index.indexId) {
            "FTSE100" -> universe.take(100)
            "FTSE250" -> universe.drop(100).take(250).ifEmpty { universe.take(60) }
            "FTSE350" -> universe.take(350).ifEmpty { universe }
            "UKX_EQW" -> universe.take(100)
            "UKX_DIV50" -> universe.sortedByDescending { it.dividendYieldPct }.take(50)
            "UKX_QUAL50" -> universe.sortedByDescending { it.priceGbp }.take(50)
            else -> universe.take(100)
        }
        val newState = IndexCalculator.calculateIndexState(
            index = index,
            selectedSecurities = selectedSecs,
            divisor = index.divisor,
            methodologyVersion = _uiState.value.activeMethodology.version
        )
        _uiState.update {
            it.copy(
                selectedIndex = index,
                currentIndexState = newState,
                apiOutputJson = generateApiJsonResponse("INDEX ${index.indexCode}", newState)
            )
        }
    }

    fun selectCurrency(currency: DisplayCurrency) {
        _uiState.update { it.copy(selectedCurrency = currency) }
    }

    fun selectMethodologyVersion(version: MethodologyVersion) {
        val universe = _uiState.value.allUniverseSecurities
        val (selected, candidates) = FTSE100SelectionEngine.selectConstituents(
            eligibleSecurities = universe,
            currentConstituentTickers = universe.take(100).map { it.ticker }.toSet(),
            methodology = version
        )
        val newState = IndexCalculator.calculateIndexState(
            index = _uiState.value.selectedIndex,
            selectedSecurities = selected,
            methodologyVersion = version.version
        )
        _uiState.update {
            it.copy(
                activeMethodology = version,
                currentIndexState = newState,
                reviewCandidates = candidates
            )
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setSectorFilter(sector: UkSector?) {
        _uiState.update { it.copy(selectedSectorFilter = sector) }
    }

    fun setSort(field: ConstituentSortField) {
        _uiState.update { current ->
            val newDir = if (current.sortField == field && current.sortDirection == SortDirection.DESCENDING) {
                SortDirection.ASCENDING
            } else {
                SortDirection.DESCENDING
            }
            current.copy(sortField = field, sortDirection = newDir)
        }
    }

    fun selectConstituent(constituent: IndexConstituent?) {
        _uiState.update { it.copy(selectedConstituent = constituent) }
    }

    fun selectReviewEvent(event: QuarterlyReviewEvent) {
        _uiState.update { it.copy(activeReviewEvent = event) }
    }

    fun selectMacroScenario(scenario: MacroScenarioType) {
        val state = _uiState.value.currentIndexState ?: return
        val impact = MacroScenarioEngine.runScenario(
            scenarioType = scenario,
            constituents = state.constituents,
            currentIndexLevel = state.indexLevel
        )
        _uiState.update {
            it.copy(
                activeScenario = scenario,
                activeScenarioImpact = impact
            )
        }
    }

    fun runCustomIndexBuild(config: CustomIndexConfig) {
        val customState = CustomIndexLabEngine.buildCustomIndex(
            config = config,
            allSecurities = _uiState.value.allUniverseSecurities,
            factorScores = _uiState.value.factorScores
        )
        _uiState.update {
            it.copy(
                customIndexConfig = config,
                customIndexState = customState
            )
        }
    }

    fun testSecurityEligibility(ticker: String) {
        val sec = _uiState.value.allUniverseSecurities.find { it.ticker.equals(ticker.trim(), ignoreCase = true) }
            ?: return
        val result = FTSEEligibilityEngine.testEligibility(sec, _uiState.value.activeMethodology, true)
        val fastEntry = FastEntryEngine.evaluateIpoListing(sec, _uiState.value.allUniverseSecurities, _uiState.value.activeMethodology)
        _uiState.update {
            it.copy(
                testSecurityTicker = ticker,
                eligibilityTestResult = result,
                fastEntryEvaluation = fastEntry
            )
        }
    }

    fun executeApiQuery(query: String) {
        val json = generateApiJsonResponse(query, _uiState.value.currentIndexState)
        _uiState.update {
            it.copy(
                apiQueryInput = query,
                apiOutputJson = json
            )
        }
    }

    fun sendAiUserQuery(queryText: String) {
        if (queryText.isBlank()) return

        val userMsg = UkxAiChatMessage(
            id = "USR-${System.currentTimeMillis()}",
            sender = "USER",
            content = queryText,
            timestamp = "Just now"
        )

        val state = _uiState.value.currentIndexState
        val answer = processAiQuantQuery(queryText, state)

        _uiState.update {
            it.copy(aiMessages = it.aiMessages + userMsg + answer)
        }
    }

    private fun processAiQuantQuery(query: String, state: IndexState?): UkxAiChatMessage {
        val q = query.lowercase()
        val indexLevelStr = state?.let { String.format("%.2f", it.indexLevel) } ?: "8,342.15"
        val changeStr = state?.let { String.format("%+.2f (%+.2f%%)", it.dailyChangePoints, it.dailyReturnPct) } ?: "+45.20 (+0.54%)"

        val content: String
        val calc: String

        when {
            q.contains("why") || q.contains("move") || q.contains("rose") || q.contains("fell") || q.contains("attribution") -> {
                val topStock = state?.topContributors?.firstOrNull()
                val topDetractor = state?.topDetractors?.firstOrNull()
                val topSector = state?.sectorExposures?.firstOrNull()

                content = "FTSE 100 Index moved $changeStr to settle at $indexLevelStr.\n\n" +
                        "Primary Attribution Drivers:\n" +
                        "• Lead Sector: ${topSector?.sector?.displayName} contributed ${String.format("%+.2f%%", topSector?.sectorContributionPct ?: 0.0)} to index movement.\n" +
                        "• Lead Stock: ${topStock?.ticker} (${topStock?.companyName}) provided ${String.format("%+.2f pts", topStock?.contributionPoints ?: 0.0)}.\n" +
                        "• Largest Drag: ${topDetractor?.ticker} shaved ${String.format("%.2f pts", topDetractor?.contributionPoints ?: 0.0)}.\n" +
                        "• Foreign Currency Translation: Multinational dollar earnings contributed +0.18%."
                calc = "Attribution Formula: Sum(w_i * r_i) = ${String.format("%.2f%%", state?.dailyReturnPct ?: 0.54)} | Divisor: 23,749,281.45"
            }
            q.contains("review") || q.contains("rebalance") || q.contains("addition") || q.contains("deletion") -> {
                content = "Quarterly Review Engine Status:\n\n" +
                        "• Next Review: December 2026 (Ranking Cutoff: 2026-12-01)\n" +
                        "• Buffer Inclusion Boundary: Rank <= 90 (Automatic FTSE 100 Inclusion)\n" +
                        "• Buffer Demotion Boundary: Rank >= 111 (Automatic Demotion to FTSE 250)\n" +
                        "• Projected One-Way Turnover: ~0.45% (£920M passive rebalance flow)."
                calc = "Buffer Bands: 90 / 111 | Turnover: Sum(|w_post - w_pre|) / 2"
            }
            q.contains("gbp") || q.contains("sterling") || q.contains("shock") || q.contains("currency") -> {
                content = "Macro Scenario Simulation (Sterling FX Shock):\n\n" +
                        "• A +5.0% GBP appreciation against USD/EUR translates into a modelled -2.15% drag on FTSE 100.\n" +
                        "• Cause: ~75% of FTSE 100 aggregate revenue is generated outside the UK (Shell, AstraZeneca, HSBC, Unilever).\n" +
                        "• Pure UK domestic earners (Housebuilders, Utilities) gain +0.85%."
                calc = "FX Sensitivity: Beta_FX = -0.43 | Domestic/Foreign Sales split = 25% / 75%"
            }
            q.contains("divisor") || q.contains("corporate action") -> {
                content = "Divisor Continuity Logic (UKXDivisorEngine):\n\n" +
                        "• Divisor preserves index price continuity across corporate events: D_{t+1} = D_t * (Cap_{post} / Cap_{pre}).\n" +
                        "• Current Divisor: 23,749,281.45\n" +
                        "• Latest Adjustment: Shell plc share buyback cancellation (-£520M market cap adjustment)."
                calc = "Continuity check: Index_Level(pre) == Index_Level(post) across event boundary"
            }
            else -> {
                content = "UKX Quantitative Analysis Query Result for '$query':\n\n" +
                        "• Current Index Level: $indexLevelStr ($changeStr)\n" +
                        "• Investable Market Cap: £${String.format("%.2f", (state?.totalInvestableMarketCapGbp ?: 2.08e12) / 1e12)}T\n" +
                        "• Free Float Factor Weighted\n" +
                        "• Methodology: ${_uiState.value.activeMethodology.version} (Active)\n" +
                        "• All computations deterministic and reproducible from synthetic event stream."
                calc = "Index Formula: I = Sum(P_i * S_i * FF_i) / D | Divisor = ${state?.divisor ?: 23749281.45}"
            }
        }

        return UkxAiChatMessage(
            id = "AI-${System.currentTimeMillis()}",
            sender = "UKX-AI",
            content = content,
            timestamp = "Just now",
            calculationDetails = calc,
            provenance = "UKX-CORE Quantitative Engine | Status: SYNTHETIC",
            methodologyChecksum = _uiState.value.activeMethodology.checksum
        )
    }

    private fun generateApiJsonResponse(query: String, state: IndexState?): String {
        val q = query.trim().uppercase()
        val level = state?.let { String.format("%.2f", it.indexLevel) } ?: "8342.15"
        val changePts = state?.let { String.format("%+.2f", it.dailyChangePoints) } ?: "+45.20"
        val changePct = state?.let { String.format("%+.2f", it.dailyReturnPct) } ?: "+0.54"

        return when {
            q.startsWith("INDEX") || q.startsWith("GET /API/V1/INDICES/FTSE100") -> """
{
  "status": "success",
  "data_status": "SYNTHETIC",
  "provenance": {
    "source": "UKX-CORE / LSE Digital Twin",
    "methodology_version": "${_uiState.value.activeMethodology.version}",
    "checksum": "${_uiState.value.activeMethodology.checksum}"
  },
  "index": {
    "index_id": "FTSE100",
    "index_code": "UKX",
    "currency": "GBP",
    "level": $level,
    "change_points": $changePts,
    "change_percent": $changePct,
    "total_return_level": 12495.80,
    "net_total_return_level": 11158.40,
    "divisor": 23749281.45,
    "full_market_cap_gbp": 2485000000000.0,
    "investable_market_cap_gbp": 1980875000000.0,
    "constituent_count": 100
  }
}
""".trimIndent()

            q.startsWith("CONSTITUENTS") || q.startsWith("GET /API/V1/INDICES/FTSE100/CONSTITUENTS") -> """
{
  "status": "success",
  "index_code": "UKX",
  "count": 100,
  "constituents_sample": [
    { "rank": 1, "ticker": "SHEL", "name": "Shell plc", "price_gbp": 27.80, "weight_pct": 8.84, "sector": "ENERGY", "free_float": 0.98 },
    { "rank": 2, "ticker": "AZN", "name": "AstraZeneca plc", "price_gbp": 122.40, "weight_pct": 8.35, "sector": "HEALTHCARE", "free_float": 0.99 },
    { "rank": 3, "ticker": "HSBA", "name": "HSBC Holdings plc", "price_gbp": 6.75, "weight_pct": 6.12, "sector": "FINANCIALS", "free_float": 0.95 },
    { "rank": 4, "ticker": "ULVR", "name": "Unilever plc", "price_gbp": 46.20, "weight_pct": 5.48, "sector": "CONSUMER_STAPLES", "free_float": 0.97 },
    { "rank": 5, "ticker": "BP.", "name": "BP plc", "price_gbp": 4.38, "weight_pct": 3.92, "sector": "ENERGY", "free_float": 0.99 }
  ]
}
""".trimIndent()

            q.startsWith("REVIEW") || q.startsWith("GET /API/V1/REVIEWS") -> """
{
  "status": "success",
  "review_id": "REV-2026-Q4-DEC-SIM",
  "status": "SIMULATED",
  "calendar": {
    "ranking_cutoff": "2026-12-01",
    "effective_date": "2026-12-21"
  },
  "buffer_rules": { "upper_inclusion": 90, "lower_demotion": 111 },
  "estimated_turnover_pct": 0.45,
  "projected_additions": ["EZJ", "ITH"],
  "projected_deletions": ["ENT", "PSN"]
}
""".trimIndent()

            else -> """
{
  "status": "success",
  "query": "$query",
  "executed_at": "2026-10-06T09:45:00Z",
  "data_status": "SYNTHETIC",
  "result": {
    "index_level": $level,
    "change": "$changePct"
  }
}
""".trimIndent()
        }
    }
}
