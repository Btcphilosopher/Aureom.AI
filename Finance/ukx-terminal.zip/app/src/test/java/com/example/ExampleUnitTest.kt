package com.example

import com.example.ukx.core.engine.DividendEngine
import com.example.ukx.core.engine.FTSE100SelectionEngine
import com.example.ukx.core.engine.FTSEEligibilityEngine
import com.example.ukx.core.engine.FastEntryEngine
import com.example.ukx.core.engine.FreeFloatEngine
import com.example.ukx.core.engine.FullMarketCapitalisationEngine
import com.example.ukx.core.engine.IndexCalculator
import com.example.ukx.core.engine.UKLiquidityEngine
import com.example.ukx.core.engine.UKXDivisorEngine
import com.example.ukx.data.provider.SyntheticFTSEProvider
import com.example.ukx.domain.model.BufferStatus
import com.example.ukx.domain.model.FTSEIndex
import com.example.ukx.domain.model.MethodologyVersion
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun test_full_market_cap_calculation() {
        val price = 25.0
        val shares = 2_000_000_000L
        val fullCap = FullMarketCapitalisationEngine.calculateFullMarketCap(price, shares)
        assertEquals(50_000_000_000.0, fullCap, 0.001)
    }

    @Test
    fun test_investable_market_cap_and_free_float() {
        val fullCap = 50_000_000_000.0
        val floatFactor = 0.85
        val invCap = FreeFloatEngine.calculateInvestableMarketCap(fullCap, floatFactor)
        assertEquals(42_500_000_000.0, invCap, 0.001)

        assertTrue(FreeFloatEngine.isFreeFloatEligible(0.12, MethodologyVersion.VERSION_2026_JUN))
        assertFalse(FreeFloatEngine.isFreeFloatEligible(0.08, MethodologyVersion.VERSION_2026_JUN))
    }

    @Test
    fun test_liquidity_ratio() {
        val ratio = UKLiquidityEngine.calculateLiquidityRatio(
            medianDailyVolume = 5_000_000,
            sharesInIssue = 1_000_000_000,
            freeFloatFactor = 0.80
        )
        // 5M / (1B * 0.8) * 100 = 5M / 800M * 100 = 0.625%
        assertEquals(0.625, ratio, 0.001)
    }

    @Test
    fun test_divisor_continuity_preservation() {
        val currentDivisor = 20_000_000.0
        val preCap = 1_000_000_000_000.0
        val postCap = 1_050_000_000_000.0 // +5% cap expansion
        val newDivisor = UKXDivisorEngine.calculateNewDivisor(currentDivisor, preCap, postCap)
        assertEquals(21_000_000.0, newDivisor, 0.001)

        val preIndexLevel = preCap / currentDivisor
        val postIndexLevel = postCap / newDivisor
        assertEquals(preIndexLevel, postIndexLevel, 0.001)
    }

    @Test
    fun test_ftse100_buffer_status() {
        assertEquals(BufferStatus.SECURE_CONSTITUENT, FTSE100SelectionEngine.determineBufferStatus(rank = 45, isCurrentConstituent = true))
        assertEquals(BufferStatus.BORDERLINE_INCUMBENT, FTSE100SelectionEngine.determineBufferStatus(rank = 95, isCurrentConstituent = true))
        assertEquals(BufferStatus.BUFFER_ZONE_AT_RISK, FTSE100SelectionEngine.determineBufferStatus(rank = 105, isCurrentConstituent = true))
        assertEquals(BufferStatus.AUTOMATIC_DEMOTION, FTSE100SelectionEngine.determineBufferStatus(rank = 112, isCurrentConstituent = true))
        assertEquals(BufferStatus.AUTOMATIC_PROMOTION, FTSE100SelectionEngine.determineBufferStatus(rank = 88, isCurrentConstituent = false))
    }

    @Test
    fun test_index_state_deterministic_calculation() {
        val universe = SyntheticFTSEProvider.generateCompleteSecurityUniverse()
        val indexState = IndexCalculator.calculateIndexState(
            index = FTSEIndex.UKX_100,
            selectedSecurities = universe.take(100)
        )

        assertEquals(100, indexState.constituents.size)
        assertTrue(indexState.indexLevel > 0)
        assertTrue(indexState.totalInvestableMarketCapGbp > 0)
        val weightSum = indexState.constituents.sumOf { it.weightPct }
        assertEquals(100.0, weightSum, 0.1)
    }
}
