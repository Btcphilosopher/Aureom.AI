-- TEXAS STOCK EXCHANGE (TXSE)
-- PostgreSQL Core Production Database Schema
-- Version: 1.0.0
-- Security: Strict Zero-Trust, Decimal-Safe Monetary Columns

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Customers and Accounts
CREATE TYPE user_role_type AS ENUM ('RETAIL_INVESTOR', 'INSTITUTIONAL_TRADER', 'MARKET_MAKER', 'ISSUER_REPRESENTATIVE', 'EXCHANGE_ADMIN', 'COMPLIANCE_OFFICER');
CREATE TYPE kyc_status_type AS ENUM ('UNVERIFIED', 'PENDING_REVIEW', 'TIER_1_BASIC', 'TIER_2_VERIFIED', 'TIER_3_INSTITUTIONAL', 'SUSPENDED');

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role_type NOT NULL DEFAULT 'RETAIL_INVESTOR',
    kyc_status kyc_status_type NOT NULL DEFAULT 'TIER_1_BASIC',
    two_factor_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    two_factor_secret VARCHAR(64),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    organization_name VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE trading_accounts (
    account_number VARCHAR(32) PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    account_type VARCHAR(32) NOT NULL DEFAULT 'MARGIN_PRO',
    currency VARCHAR(3) NOT NULL DEFAULT 'USD',
    cash_balance NUMERIC(18, 4) NOT NULL DEFAULT 100000.0000 CHECK (cash_balance >= 0),
    buying_power NUMERIC(18, 4) NOT NULL DEFAULT 200000.0000,
    frozen_collateral NUMERIC(18, 4) NOT NULL DEFAULT 0.0000,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Instruments and Securities
CREATE TYPE sector_type AS ENUM ('ENERGY', 'TECHNOLOGY', 'FINANCIALS', 'UTILITIES', 'REAL_ESTATE', 'MATERIALS', 'AEROSPACE', 'HEALTHCARE');
CREATE TYPE exchange_tier_type AS ENUM ('TXSE_PRIME', 'TXSE_VENTURE', 'DUAL_LISTED_NATIONAL');

CREATE TABLE instruments (
    symbol VARCHAR(12) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    cusip VARCHAR(9) UNIQUE,
    isin VARCHAR(12) UNIQUE,
    sector sector_type NOT NULL,
    exchange_tier exchange_tier_type NOT NULL DEFAULT 'TXSE_PRIME',
    lot_size INT NOT NULL DEFAULT 100,
    tick_size NUMERIC(8, 4) NOT NULL DEFAULT 0.0100,
    par_value NUMERIC(10, 4) NOT NULL DEFAULT 1.0000,
    shares_outstanding BIGINT NOT NULL,
    is_trading_halted BOOLEAN NOT NULL DEFAULT FALSE,
    headquarters_city VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Orders and Matching Engine Journal
CREATE TYPE order_side AS ENUM ('BUY', 'SELL');
CREATE TYPE order_type AS ENUM ('MARKET', 'LIMIT', 'STOP', 'STOP_LIMIT');
CREATE TYPE time_in_force AS ENUM ('DAY', 'GTC', 'IOC', 'FOK');
CREATE TYPE order_status AS ENUM ('NEW', 'ACCEPTED', 'PARTIALLY_FILLED', 'FILLED', 'CANCEL_PENDING', 'CANCELLED', 'REJECTED', 'EXPIRED');

CREATE TABLE orders (
    order_id VARCHAR(64) PRIMARY KEY,
    client_order_id VARCHAR(64),
    account_number VARCHAR(32) NOT NULL REFERENCES trading_accounts(account_number),
    symbol VARCHAR(12) NOT NULL REFERENCES instruments(symbol),
    side order_side NOT NULL,
    order_type order_type NOT NULL,
    time_in_force time_in_force NOT NULL DEFAULT 'DAY',
    limit_price NUMERIC(18, 4),
    stop_price NUMERIC(18, 4),
    quantity INT NOT NULL CHECK (quantity > 0),
    filled_quantity INT NOT NULL DEFAULT 0 CHECK (filled_quantity >= 0 AND filled_quantity <= quantity),
    status order_status NOT NULL DEFAULT 'NEW',
    rejection_reason TEXT,
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE executions (
    execution_id VARCHAR(64) PRIMARY KEY,
    order_id VARCHAR(64) NOT NULL REFERENCES orders(order_id),
    symbol VARCHAR(12) NOT NULL REFERENCES instruments(symbol),
    side order_side NOT NULL,
    price NUMERIC(18, 4) NOT NULL CHECK (price > 0),
    quantity INT NOT NULL CHECK (quantity > 0),
    fee NUMERIC(10, 4) NOT NULL DEFAULT 0.0000,
    liquidity_flag VARCHAR(1) NOT NULL DEFAULT 'A', -- 'M' = Maker, 'T' = Taker, 'A' = Auction
    executed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Holdings & Portfolio Positions
CREATE TABLE positions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    account_number VARCHAR(32) NOT NULL REFERENCES trading_accounts(account_number),
    symbol VARCHAR(12) NOT NULL REFERENCES instruments(symbol),
    shares INT NOT NULL DEFAULT 0 CHECK (shares >= 0),
    average_cost NUMERIC(18, 4) NOT NULL DEFAULT 0.0000,
    realized_pl NUMERIC(18, 4) NOT NULL DEFAULT 0.0000,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(account_number, symbol)
);

-- 5. Issuer Applications
CREATE TYPE listing_status_type AS ENUM ('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'CONDITIONALLY_APPROVED', 'APPROVED', 'REJECTED');

CREATE TABLE listing_applications (
    application_id VARCHAR(32) PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    proposed_symbol VARCHAR(12) NOT NULL,
    sector sector_type NOT NULL,
    capital_target_usd NUMERIC(18, 2) NOT NULL,
    shares_offered BIGINT NOT NULL,
    underwriter_firm VARCHAR(255) NOT NULL,
    sec_cik_number VARCHAR(10),
    status listing_status_type NOT NULL DEFAULT 'UNDER_REVIEW',
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reviewed_by UUID REFERENCES users(id)
);

-- 6. Audit & Market Surveillance Logs
CREATE TABLE surveillance_events (
    event_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(64) NOT NULL,
    symbol VARCHAR(12) REFERENCES instruments(symbol),
    account_number VARCHAR(32) REFERENCES trading_accounts(account_number),
    severity VARCHAR(16) NOT NULL, -- INFO, WARNING, CRITICAL
    description TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indices for Micro-Second Queries
CREATE INDEX idx_orders_symbol_status ON orders(symbol, status);
CREATE INDEX idx_orders_account ON orders(account_number);
CREATE INDEX idx_executions_symbol ON executions(symbol, executed_at DESC);
CREATE INDEX idx_positions_account ON positions(account_number);
