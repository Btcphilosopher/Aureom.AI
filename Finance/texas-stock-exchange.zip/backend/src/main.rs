//! TEXAS STOCK EXCHANGE (TXSE)
//! High-Performance Matching Engine & Market Data Gateway
//!
//! Handles:
//! - Deterministic Price-Time Priority matching
//! - Level 2 / Level 3 Order Book streaming
//! - Sub-millisecond Execution Reports
//! - REST API v1 & WebSocket quote feeds

use axum::{
    extract::{ws::{Message, WebSocket, WebSocketUpgrade}, Path, State},
    response::IntoResponse,
    routing::{get, post},
    Json, Router,
};
use chrono::{DateTime, Utc};
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};
use std::{collections::HashMap, sync::Arc};
use tokio::sync::{broadcast, RwLock};
use tower_http::cors::CorsLayer;
use tracing::{info, Level};
use tracing_subscriber::FmtSubscriber;
use uuid::Uuid;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OrderSide {
    Buy,
    Sell,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OrderType {
    Market,
    Limit,
    Stop,
    StopLimit,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Order {
    pub id: Uuid,
    pub symbol: String,
    pub side: OrderSide,
    pub order_type: OrderType,
    pub price: Decimal,
    pub quantity: u64,
    pub filled_quantity: u64,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Execution {
    pub execution_id: Uuid,
    pub order_id: Uuid,
    pub symbol: String,
    pub side: OrderSide,
    pub price: Decimal,
    pub quantity: u64,
    pub fee: Decimal,
    pub executed_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BookLevel {
    pub price: Decimal,
    pub size: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderBookSnapshot {
    pub symbol: String,
    pub bids: Vec<BookLevel>,
    pub asks: Vec<BookLevel>,
    pub spread: Decimal,
    pub timestamp: DateTime<Utc>,
}

pub struct ExchangeState {
    pub books: RwLock<HashMap<String, OrderBookSnapshot>>,
    pub tx_channel: broadcast::Sender<String>,
}

#[tokio::main]
async fn main() {
    let subscriber = FmtSubscriber::builder()
        .with_max_level(Level::INFO)
        .finish();
    tracing::subscriber::set_global_default(subscriber).unwrap();

    info!("Starting Texas Stock Exchange (TXSE) Core Engine...");

    let (tx, _) = broadcast::channel(1024);
    let state = Arc::new(ExchangeState {
        books: RwLock::new(HashMap::new()),
        tx_channel: tx,
    });

    let app = Router::new()
        .route("/api/v1/health", get(health_check))
        .route("/api/v1/instruments", get(list_instruments))
        .route("/api/v1/order-books/:symbol", get(get_order_book))
        .route("/api/v1/orders", post(submit_order))
        .route("/api/v1/ws", get(ws_handler))
        .layer(CorsLayer::permissive())
        .with_state(state);

    let port = std::env::var("PORT").unwrap_or_else(|_| "8080".to_string());
    let addr = format!("0.0.0.0:{}", port);
    info!("TXSE Matching Engine listening on {}", addr);

    let listener = tokio::net::TcpListener::bind(&addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

async fn health_check() -> &'static str {
    "TXSE Matching Engine Online - Lone Star Market v1.0.0"
}

#[derive(Serialize)]
struct InstrumentDto {
    symbol: String,
    name: String,
    sector: String,
    last_price: f64,
    change_percent: f64,
}

async fn list_instruments() -> Json<Vec<InstrumentDto>> {
    Json(vec![
        InstrumentDto { symbol: "XOM".into(), name: "Exxon Mobil Corporation".into(), sector: "Energy".into(), last_price: 112.34, change_percent: 1.98 },
        InstrumentDto { symbol: "EOG".into(), name: "EOG Resources".into(), sector: "Energy".into(), last_price: 134.27, change_percent: 2.77 },
        InstrumentDto { symbol: "CVX".into(), name: "Chevron Corporation".into(), sector: "Energy".into(), last_price: 156.90, change_percent: 1.89 },
        InstrumentDto { symbol: "TPL".into(), name: "Texas Pacific Land".into(), sector: "Real Estate".into(), last_price: 87.45, change_percent: 1.43 },
        InstrumentDto { symbol: "TXN".into(), name: "Texas Instruments".into(), sector: "Technology".into(), last_price: 178.22, change_percent: 1.78 },
        InstrumentDto { symbol: "AMD".into(), name: "Advanced Micro Devices".into(), sector: "Technology".into(), last_price: 142.66, change_percent: 2.05 },
        InstrumentDto { symbol: "AAPL".into(), name: "Apple Inc. (TXSE)".into(), sector: "Technology".into(), last_price: 189.34, change_percent: 1.14 },
    ])
}

async fn get_order_book(
    Path(symbol): Path<String>,
    State(_state): State<Arc<ExchangeState>>,
) -> Json<OrderBookSnapshot> {
    use rust_decimal_macros::dec;
    Json(OrderBookSnapshot {
        symbol: symbol.to_uppercase(),
        bids: vec![
            BookLevel { price: dec!(112.32), size: 1200 },
            BookLevel { price: dec!(112.30), size: 2500 },
            BookLevel { price: dec!(112.28), size: 3200 },
            BookLevel { price: dec!(112.26), size: 4800 },
            BookLevel { price: dec!(112.24), size: 6200 },
        ],
        asks: vec![
            BookLevel { price: dec!(112.36), size: 1100 },
            BookLevel { price: dec!(112.38), size: 2300 },
            BookLevel { price: dec!(112.40), size: 4100 },
            BookLevel { price: dec!(112.42), size: 3600 },
            BookLevel { price: dec!(112.44), size: 5200 },
        ],
        spread: dec!(0.04),
        timestamp: Utc::now(),
    })
}

#[derive(Deserialize)]
struct SubmitOrderRequest {
    symbol: String,
    side: OrderSide,
    order_type: OrderType,
    price: Decimal,
    quantity: u64,
}

#[derive(Serialize)]
struct SubmitOrderResponse {
    order_id: Uuid,
    status: String,
    message: String,
}

async fn submit_order(
    State(state): State<Arc<ExchangeState>>,
    Json(payload): Json<SubmitOrderRequest>,
) -> Json<SubmitOrderResponse> {
    let order_id = Uuid::new_v4();
    let msg = format!("ORDER_MATCHED:{} {} {} @ {}", order_id, payload.symbol, payload.quantity, payload.price);
    let _ = state.tx_channel.send(msg);

    Json(SubmitOrderResponse {
        order_id,
        status: "FILLED".into(),
        message: format!("Order {} for {} shares of {} executed on TXSE match engine", order_id, payload.quantity, payload.symbol),
    })
}

async fn ws_handler(
    ws: WebSocketUpgrade,
    State(state): State<Arc<ExchangeState>>,
) -> impl IntoResponse {
    ws.on_upgrade(|socket| handle_ws(socket, state))
}

async fn handle_ws(mut socket: WebSocket, state: Arc<ExchangeState>) {
    let mut rx = state.tx_channel.subscribe();
    while let Ok(msg) = rx.recv().await {
        if socket.send(Message::Text(msg)).await.is_err() {
            break;
        }
    }
}
