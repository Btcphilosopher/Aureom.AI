import React, { useState } from 'react';
import Head from 'next/head';

export default function TxseDesktopTerminal() {
  const [selectedSymbol, setSelectedSymbol] = useState('XOM');
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [shares, setShares] = useState(100);
  const [price, setPrice] = useState(112.36);
  const [timeframe, setTimeframe] = useState('1D');

  const top20 = [
    { symbol: 'XOM', last: 112.34, chg: 2.18, pct: 1.98 },
    { symbol: 'EOG', last: 134.27, chg: 3.62, pct: 2.77 },
    { symbol: 'CVX', last: 156.90, chg: 2.91, pct: 1.89 },
    { symbol: 'TPL', last: 87.45, chg: 1.23, pct: 1.43 },
    { symbol: 'FANG', last: 162.18, chg: 4.87, pct: 3.10 },
    { symbol: 'CVE', last: 78.32, chg: 1.56, pct: 2.03 },
    { symbol: 'BHP', last: 61.17, chg: 0.92, pct: 1.53 },
    { symbol: 'TXN', last: 178.22, chg: 3.11, pct: 1.78 },
    { symbol: 'AMD', last: 142.66, chg: 2.87, pct: 2.05 },
    { symbol: 'AAPL', last: 189.34, chg: 2.14, pct: 1.14 },
  ];

  const orderBook = {
    bids: [
      { size: 1200, price: 112.32 },
      { size: 2500, price: 112.30 },
      { size: 3200, price: 112.28 },
      { size: 4800, price: 112.26 },
      { size: 6200, price: 112.24 },
    ],
    asks: [
      { size: 1100, price: 112.36 },
      { size: 2300, price: 112.38 },
      { size: 4100, price: 112.40 },
      { size: 3600, price: 112.42 },
      { size: 5200, price: 112.44 },
    ]
  };

  const recentTrades = [
    { time: '10:24:12', price: 112.34, size: 200, isUp: false },
    { time: '10:24:11', price: 112.36, size: 500, isUp: false },
    { time: '10:24:10', price: 112.33, size: 100, isUp: true },
    { time: '10:24:08', price: 112.32, size: 300, isUp: true },
    { time: '10:24:06', price: 112.31, size: 250, isUp: true },
    { time: '10:24:04', price: 112.34, size: 400, isUp: false },
    { time: '10:24:02', price: 112.37, size: 150, isUp: true },
  ];

  return (
    <div style={{ backgroundColor: '#061321', color: '#F8FAFC', minHeight: '100vh', fontFamily: 'monospace' }}>
      <Head>
        <title>TEXAS STOCK EXCHANGE — Lone Star Trading Terminal</title>
      </Head>

      {/* Top Exchange Banner */}
      <header style={{ backgroundColor: '#0B1B2B', borderBottom: '1px solid #1B3550', padding: '10px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{ width: 34, height: 34, borderRadius: 6, backgroundColor: '#1478E8', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#D6B36A', fontWeight: 'bold' }}>
            ★
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 900, letterSpacing: '1px' }}>
              TEXAS <span style={{ color: '#38BDF8' }}>STOCK EXCHANGE</span>
            </div>
            <div style={{ fontSize: 10, color: '#D6B36A', letterSpacing: '1.5px' }}>
              THE LONE STAR MARKET  •  CAPITAL ★ COMMERCE ★ TEXAS
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <div style={{ backgroundColor: '#16C7841F', border: '1px solid #16C784', color: '#16C784', padding: '4px 10px', borderRadius: 12, fontSize: 11, fontWeight: 'bold' }}>
            • MARKET OPEN
          </div>
          <div style={{ color: '#94A3B8', fontSize: 11 }}>
            Apr 28, 2026  10:24:37 CT
          </div>
        </div>
      </header>

      {/* Sub Nav */}
      <div style={{ backgroundColor: '#0A1726', borderBottom: '1px solid #1B3550', padding: '6px 20px', display: 'flex', gap: '24px', fontSize: 12, fontWeight: 'bold', color: '#94A3B8' }}>
        <span style={{ color: '#1478E8', cursor: 'pointer' }}>MARKETS</span>
        <span style={{ cursor: 'pointer' }}>TRADE</span>
        <span style={{ cursor: 'pointer' }}>PORTFOLIO</span>
        <span style={{ cursor: 'pointer' }}>WATCHLIST</span>
        <span style={{ cursor: 'pointer' }}>NEWS</span>
        <span style={{ cursor: 'pointer' }}>RESEARCH</span>
        <span style={{ cursor: 'pointer' }}>SETTINGS</span>
      </div>

      {/* Grid Desktop Body */}
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr 340px', gap: '12px', padding: '14px' }}>
        {/* Left Column: Top 20 & Sectors */}
        <div style={{ backgroundColor: '#0B1B2B', border: '1px solid #1B3550', borderRadius: 8, padding: 12 }}>
          <div style={{ fontWeight: 'bold', fontSize: 13, marginBottom: 8, color: '#F8FAFC' }}>TEXAS TOP 20</div>
          <table style={{ width: '100%', fontSize: 11, borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ color: '#64748B', borderBottom: '1px solid #1B3550', textAlign: 'left' }}>
                <th>Symbol</th>
                <th>Last</th>
                <th style={{ textAlign: 'right' }}>% Chg</th>
              </tr>
            </thead>
            <tbody>
              {top20.map(item => (
                <tr key={item.symbol} onClick={() => setSelectedSymbol(item.symbol)} style={{ cursor: 'pointer', borderBottom: '1px solid #102438', height: 26, color: item.symbol === selectedSymbol ? '#38BDF8' : '#F8FAFC' }}>
                  <td style={{ fontWeight: 'bold' }}>{item.symbol}</td>
                  <td>${item.last.toFixed(2)}</td>
                  <td style={{ textAlign: 'right', color: item.pct >= 0 ? '#16C784' : '#F04452' }}>+{item.pct}%</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{ fontWeight: 'bold', fontSize: 13, marginTop: 18, marginBottom: 8, color: '#F8FAFC' }}>SECTORS</div>
          <div style={{ fontSize: 11, display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Energy</span><span style={{ color: '#16C784' }}>+2.34%</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Technology</span><span style={{ color: '#16C784' }}>+1.72%</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Financials</span><span style={{ color: '#16C784' }}>+1.21%</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Utilities</span><span style={{ color: '#16C784' }}>+0.83%</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Real Estate</span><span style={{ color: '#16C784' }}>+0.56%</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Materials</span><span style={{ color: '#F04452' }}>-0.12%</span></div>
          </div>
        </div>

        {/* Center Column: Interactive Chart + Order Book + Trade Ticket */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Chart Header */}
          <div style={{ backgroundColor: '#0B1B2B', border: '1px solid #1B3550', borderRadius: 8, padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <span style={{ fontSize: 20, fontWeight: 'bold' }}>{selectedSymbol}</span>
                <span style={{ color: '#94A3B8', fontSize: 13, marginLeft: 8 }}>Exxon Mobil Corporation</span>
              </div>
              <div style={{ fontSize: 22, fontWeight: 'bold', color: '#16C784' }}>
                $112.34 <span style={{ fontSize: 14 }}>+2.18 (+1.98%)</span>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
              {['1D', '1W', '1M', '3M', '1Y', '5Y'].map(tf => (
                <button key={tf} onClick={() => setTimeframe(tf)} style={{ backgroundColor: timeframe === tf ? '#1478E8' : '#102438', border: 'none', color: '#fff', padding: '4px 10px', borderRadius: 4, fontSize: 11, cursor: 'pointer' }}>
                  {tf}
                </button>
              ))}
            </div>

            {/* Stylized Canvas/SVG Candlestick chart */}
            <div style={{ height: 260, backgroundColor: '#061321', marginTop: 12, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #1B3550' }}>
              <span style={{ color: '#64748B' }}>[ High-Resolution TXSE Candlestick Stream — {selectedSymbol} {timeframe} ]</span>
            </div>
          </div>

          {/* Side-by-side Order Book & Trade Box */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {/* Order Book */}
            <div style={{ backgroundColor: '#0B1B2B', border: '1px solid #1B3550', borderRadius: 8, padding: 12 }}>
              <div style={{ fontWeight: 'bold', fontSize: 12, marginBottom: 8 }}>ORDER BOOK — {selectedSymbol}</div>
              <table style={{ width: '100%', fontSize: 11 }}>
                <thead>
                  <tr style={{ color: '#64748B', textAlign: 'center' }}>
                    <th style={{ textAlign: 'left' }}>Size</th>
                    <th style={{ color: '#16C784' }}>Bid</th>
                    <th style={{ color: '#F04452' }}>Ask</th>
                    <th style={{ textAlign: 'right' }}>Size</th>
                  </tr>
                </thead>
                <tbody>
                  {orderBook.bids.map((b, idx) => (
                    <tr key={idx} style={{ height: 22 }}>
                      <td style={{ color: '#94A3B8' }}>{b.size}</td>
                      <td style={{ color: '#16C784', fontWeight: 'bold', textAlign: 'center' }}>{b.price.toFixed(2)}</td>
                      <td style={{ color: '#F04452', fontWeight: 'bold', textAlign: 'center' }}>{orderBook.asks[idx].price.toFixed(2)}</td>
                      <td style={{ color: '#94A3B8', textAlign: 'right' }}>{orderBook.asks[idx].size}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Trade Ticket */}
            <div style={{ backgroundColor: '#0B1B2B', border: '1px solid #1B3550', borderRadius: 8, padding: 12 }}>
              <div style={{ fontWeight: 'bold', fontSize: 12, marginBottom: 8 }}>TRADE {selectedSymbol}</div>
              <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                <button onClick={() => setSide('BUY')} style={{ flex: 1, padding: 6, backgroundColor: side === 'BUY' ? '#16C784' : '#102438', border: 'none', color: '#fff', borderRadius: 4, fontWeight: 'bold', cursor: 'pointer' }}>Buy</button>
                <button onClick={() => setSide('SELL')} style={{ flex: 1, padding: 6, backgroundColor: side === 'SELL' ? '#F04452' : '#102438', border: 'none', color: '#fff', borderRadius: 4, fontWeight: 'bold', cursor: 'pointer' }}>Sell</button>
              </div>
              <div style={{ fontSize: 11, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div>Limit Price: <input type="number" value={price} onChange={e => setPrice(parseFloat(e.target.value))} style={{ width: '100%', backgroundColor: '#061321', border: '1px solid #1B3550', color: '#fff', padding: 4, borderRadius: 4 }} /></div>
                <div>Shares: <input type="number" value={shares} onChange={e => setShares(parseInt(e.target.value))} style={{ width: '100%', backgroundColor: '#061321', border: '1px solid #1B3550', color: '#fff', padding: 4, borderRadius: 4 }} /></div>
                <div style={{ color: '#D6B36A', fontWeight: 'bold' }}>Total: ${(shares * price).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                <button style={{ backgroundColor: side === 'BUY' ? '#16C784' : '#F04452', color: '#fff', border: 'none', padding: '8px', borderRadius: 4, fontWeight: 'bold', marginTop: 4, cursor: 'pointer' }}>
                  {side} {selectedSymbol}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Recent Trades & News & Lone Star Branding Poster */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Recent Trades */}
          <div style={{ backgroundColor: '#0B1B2B', border: '1px solid #1B3550', borderRadius: 8, padding: 12 }}>
            <div style={{ fontWeight: 'bold', fontSize: 12, marginBottom: 8 }}>RECENT TRADES</div>
            <table style={{ width: '100%', fontSize: 11 }}>
              <thead>
                <tr style={{ color: '#64748B' }}>
                  <th style={{ textAlign: 'left' }}>Time</th>
                  <th>Price</th>
                  <th style={{ textAlign: 'right' }}>Size</th>
                </tr>
              </thead>
              <tbody>
                {recentTrades.map((t, i) => (
                  <tr key={i} style={{ height: 20 }}>
                    <td style={{ color: '#64748B' }}>{t.time}</td>
                    <td style={{ textAlign: 'center', color: t.isUp ? '#16C784' : '#F04452', fontWeight: 'bold' }}>{t.price.toFixed(2)}</td>
                    <td style={{ textAlign: 'right', color: '#94A3B8' }}>{t.size}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Texas Stock Exchange Poster */}
          <div style={{ backgroundColor: '#071829', border: '1px solid #D6B36A55', borderRadius: 8, padding: 16, textAlign: 'center' }}>
            <div style={{ color: '#D6B36A', fontSize: 24 }}>★</div>
            <div style={{ fontWeight: 900, fontSize: 14, letterSpacing: '1px', marginTop: 4 }}>TEXAS STOCK EXCHANGE</div>
            <div style={{ color: '#D6B36A', fontSize: 11, fontWeight: 'bold', marginTop: 2 }}>INVEST IN AMERICA'S ENERGY POWERHOUSE</div>
            <div style={{ color: '#64748B', fontSize: 10, marginTop: 10, display: 'flex', justifyContent: 'center', gap: 10 }}>
              <span>EQUITIES</span> • <span>OPTIONS</span> • <span>FUTURES</span>
            </div>
            <div style={{ color: '#38BDF8', fontSize: 11, fontWeight: 'bold', marginTop: 10 }}>TEXAS OWNED. TEXAS DRIVEN.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
