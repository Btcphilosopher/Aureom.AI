# TEXAS STOCK EXCHANGE (TXSE)
## REST API & WebSocket Protocol Specification (v1)

### 1. Overview
The Texas Stock Exchange (TXSE) provides ultra-low latency, deterministic REST and WebSocket interfaces designed for retail brokerages, market makers, quantitative hedge funds, and corporate issuers.

Base URLs:
- **REST Gateway:** `https://api.txse.market/api/v1`
- **WebSocket Gateway:** `wss://stream.txse.market/api/v1/ws`

Authentication:
All authenticated endpoints require an `Authorization: Bearer <JWT_TOKEN>` header with sub-second token lifecycle validation.

---

### 2. Core Endpoints

#### 2.1 Market Reference Data
- `GET /api/v1/instruments`
  - Returns listed securities, tick sizes ($0.01), lot sizes (100 shares), and exchange tier classification (`TXSE_PRIME`).
- `GET /api/v1/instruments/{symbol}`
  - Returns real-time instrument details, fundamentals (Market Cap, P/E, Div Yield), corporate headquarters, and trading halt status.
- `GET /api/v1/order-books/{symbol}`
  - Returns Level 2 market depth snapshot with aggregated bids and asks, spread, and timestamp.
- `GET /api/v1/candles/{symbol}?timeframe={1D|1W|1M|3M|1Y|5Y}`
  - Returns historical OHLCV bars and volume metrics.

#### 2.2 Order Management & Execution
- `POST /api/v1/orders`
  - Submits a new Limit, Market, Stop, or Stop-Limit order to the matching engine.
  - Payload:
    ```json
    {
      "symbol": "XOM",
      "side": "BUY",
      "order_type": "LIMIT",
      "time_in_force": "DAY",
      "price": 112.36,
      "quantity": 100
    }
    ```
- `DELETE /api/v1/orders/{order_id}`
  - Cancels an open resting order.
- `GET /api/v1/orders`
  - Lists open working orders and historical order states.
- `GET /api/v1/executions`
  - Returns time and sales trade blotter with execution IDs, execution price, shares, and zero-fee confirmation.

#### 2.3 Accounts & Portfolio
- `GET /api/v1/portfolios`
  - Returns aggregate total portfolio value, cash balance, buying power, unrealized P&L, and asset allocation breakdown.
- `GET /api/v1/positions`
  - Returns active equity and commodity positions with average acquisition price and mark-to-market valuations.

#### 2.4 Issuer Portal & Exchange Administration
- `POST /api/v1/issuers/applications`
  - Submits initial listing documentation for corporate issuers.
- `GET /api/v1/admin/telemetry`
  - Exchange surveillance, matching engine latency (120 microseconds), and circuit breaker triggers.
- `POST /api/v1/admin/session/halt`
  - Emergency trading halt or volatility auction switch.

---

### 3. Real-Time WebSocket Feeds (`/api/v1/ws`)
Channels:
1. `quotes.{symbol}`: Micro-second tick stream with bid/ask prices and volumes.
2. `depth.{symbol}`: Incremental L2 order book updates.
3. `trades.{symbol}`: Real-time tape of executed prints.
4. `user.orders`: Private channel for order fills, rejections, and cancellations.
