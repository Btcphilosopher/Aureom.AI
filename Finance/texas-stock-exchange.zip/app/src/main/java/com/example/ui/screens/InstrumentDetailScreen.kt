package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderSide
import com.example.model.Timeframe
import com.example.ui.TxseViewModel
import com.example.ui.components.CandlestickChart
import com.example.ui.components.OrderBookView
import com.example.ui.components.RecentTradesView
import com.example.ui.theme.*

@Composable
fun InstrumentDetailScreen(
    viewModel: TxseViewModel,
    onBackClick: () -> Unit,
    onTradeClick: (OrderSide) -> Unit,
    modifier: Modifier = Modifier
) {
    val instrument by viewModel.selectedInstrument.collectAsState()
    val timeframe by viewModel.selectedTimeframe.collectAsState()
    val candles by viewModel.candles.collectAsState()
    val orderBook by viewModel.orderBook.collectAsState()
    val recentTrades by viewModel.recentTrades.collectAsState()
    val watchlist by viewModel.watchlistSymbols.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0: Depth Book, 1: Recent Trades, 2: Fundamentals

    val isUp = instrument.change >= 0
    val isStarred = watchlist.contains(instrument.symbol)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        // Top Bar with Back Arrow and Watchlist Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.testTag("detail_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TxseTextPrimary
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = instrument.symbol,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TxseTextPrimary
                    )
                )
                Text(
                    text = instrument.name,
                    style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary)
                )
            }

            IconButton(
                onClick = { viewModel.toggleWatchlist(instrument.symbol) }
            ) {
                Icon(
                    imageVector = if (isStarred) Icons.Filled.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Watchlist",
                    tint = if (isStarred) TxseTexasGold else TxseTextMuted
                )
            }
        }

        HorizontalDivider(color = TxseCardBorder, thickness = 1.dp)

        // Scrollable Body
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Price & Change Banner (matching mockup Screen 3)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "$%.2f".format(instrument.price),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${if (isUp) "+" else ""}$%.2f (${if (isUp) "+" else ""}%.2f%%)".format(
                            instrument.change,
                            instrument.changePercent
                        ),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isUp) TxseGreen else TxseRed
                        )
                    )
                }

                Surface(
                    color = TxseCardBg,
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder)
                ) {
                    Text(
                        text = instrument.exchangeTier,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TxseTexasGold,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Timeframe Selector Chips: 1D, 1W, 1M, 3M, 1Y, 5Y
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Timeframe.values().forEach { tf ->
                    val isSelected = timeframe == tf
                    Box(
                        modifier = Modifier
                            .testTag("timeframe_${tf.label.lowercase()}")
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) TxseElectricBlue else TxseCardBg)
                            .border(
                                1.dp,
                                if (isSelected) TxseBlueGlow else TxseCardBorder,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { viewModel.setTimeframe(tf) }
                            .padding(horizontal = 12.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = tf.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else TxseTextSecondary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Candlestick Chart
            CandlestickChart(candles = candles)

            Spacer(modifier = Modifier.height(16.dp))

            // Metrics Grid (Open, High, Low, Volume, Market Cap, P/E Ratio)
            Surface(
                color = TxseCardBg,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricItem("Open", "$%.2f".format(instrument.open))
                        MetricItem("Volume", "%.1fM".format(instrument.volume / 1000000.0))
                    }
                    HorizontalDivider(color = TxseCardBorder, modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricItem("High", "$%.2f".format(instrument.high))
                        MetricItem("Market Cap", "$%.1fB".format(instrument.marketCap))
                    }
                    HorizontalDivider(color = TxseCardBorder, modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricItem("Low", "$%.2f".format(instrument.low))
                        MetricItem("P/E Ratio", "%.1f".format(instrument.peRatio))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sub Tabs: Order Book / Recent Trades / Fundamentals
            TabRow(
                selectedTabIndex = activeSubTab,
                containerColor = TxseCardBg,
                contentColor = TxseElectricBlue,
                divider = { HorizontalDivider(color = TxseCardBorder) }
            ) {
                Tab(
                    selected = activeSubTab == 0,
                    onClick = { activeSubTab = 0 },
                    text = { Text("Order Book") }
                )
                Tab(
                    selected = activeSubTab == 1,
                    onClick = { activeSubTab = 1 },
                    text = { Text("Recent Trades") }
                )
                Tab(
                    selected = activeSubTab == 2,
                    onClick = { activeSubTab = 2 },
                    text = { Text("Company Info") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (activeSubTab) {
                0 -> OrderBookView(orderBook = orderBook)
                1 -> RecentTradesView(trades = recentTrades)
                2 -> {
                    Surface(
                        color = TxseCardBg,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "About ${instrument.name}",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TxseTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = instrument.description,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TxseTextSecondary,
                                    lineHeight = 20.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Headquarters: ${instrument.hqCity}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TxseTexasGold)
                            )
                            Text(
                                text = "Primary Sector: ${instrument.sector.displayName}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TxseBlueGlow)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Bottom Fixed Buy / Sell Buttons (matching mockup Screen 3)
        Surface(
            color = TxseDarkSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                HorizontalDivider(color = TxseCardBorder, thickness = 1.dp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { onTradeClick(OrderSide.BUY) },
                        modifier = Modifier
                            .testTag("detail_buy_button")
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TxseGreen)
                    ) {
                        Text(
                            text = "Buy",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }

                    Button(
                        onClick = { onTradeClick(OrderSide.SELL) },
                        modifier = Modifier
                            .testTag("detail_sell_button")
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TxseRed)
                    ) {
                        Text(
                            text = "Sell",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                color = TxseTextPrimary
            )
        )
    }
}
