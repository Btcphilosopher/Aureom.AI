package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Instrument
import com.example.model.Sector
import com.example.ui.TxseViewModel
import com.example.ui.components.MarketTickerTape
import com.example.ui.theme.*

@Composable
fun MarketsScreen(
    viewModel: TxseViewModel,
    onInstrumentClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val instruments by viewModel.filteredInstruments.collectAsState()
    val allInstruments by viewModel.instruments.collectAsState()
    val watchlist by viewModel.watchlistSymbols.collectAsState()
    val selectedSector by viewModel.selectedSector.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var showWatchlistOnly by remember { mutableStateOf(false) }

    val displayedInstruments = if (showWatchlistOnly) {
        instruments.filter { watchlist.contains(it.symbol) }
    } else {
        instruments
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        // Continuous Live Ticker Tape
        MarketTickerTape(
            instruments = allInstruments,
            onSelectSymbol = {
                viewModel.selectInstrument(it)
                onInstrumentClick(it)
            }
        )

        // Title and Watchlist Toggle Header (matching mockup Screen 2)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (showWatchlistOnly) "Watchlist" else "Texas Securities",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TxseTextPrimary
                    )
                )
                Text(
                    text = "${displayedInstruments.size} Listed Instruments",
                    style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                )
            }

            // Watchlist toggle pill
            FilterChip(
                selected = showWatchlistOnly,
                onClick = { showWatchlistOnly = !showWatchlistOnly },
                label = {
                    Text(
                        text = if (showWatchlistOnly) "★ Starred" else "All Listings",
                        style = MaterialTheme.typography.labelSmall
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = TxseElectricBlue,
                    selectedLabelColor = Color.White,
                    containerColor = TxseCardBg,
                    labelColor = TxseTextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = showWatchlistOnly,
                    borderColor = TxseCardBorder,
                    selectedBorderColor = TxseElectricBlue
                )
            )
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = {
                Text("Search by ticker, company, or city...", color = TxseTextMuted)
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = TxseTextMuted
                )
            },
            singleLine = true,
            modifier = Modifier
                .testTag("instrument_search_input")
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = TxseCardBg,
                unfocusedContainerColor = TxseCardBg,
                focusedBorderColor = TxseElectricBlue,
                unfocusedBorderColor = TxseCardBorder,
                focusedTextColor = TxseTextPrimary,
                unfocusedTextColor = TxseTextPrimary
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Sector Filter Chips: All, Energy, Tech, Finance, Utilities, Real Estate, Materials
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Sector.values().forEach { sector ->
                val isSelected = selectedSector == sector
                Box(
                    modifier = Modifier
                        .testTag("sector_filter_${sector.name.lowercase()}")
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) TxseElectricBlue else TxseCardBg)
                        .border(
                            1.dp,
                            if (isSelected) TxseBlueGlow else TxseCardBorder,
                            RoundedCornerShape(16.dp)
                        )
                        .clickable { viewModel.setSector(sector) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = sector.displayName,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else TxseTextSecondary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Securities Table
        if (displayedInstruments.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No matching instruments found",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TxseTextMuted)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(displayedInstruments, key = { it.symbol }) { inst ->
                    InstrumentRowItem(
                        instrument = inst,
                        isWatchlisted = watchlist.contains(inst.symbol),
                        onToggleWatchlist = { viewModel.toggleWatchlist(inst.symbol) },
                        onClick = {
                            viewModel.selectInstrument(inst.symbol)
                            onInstrumentClick(inst.symbol)
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
fun InstrumentRowItem(
    instrument: Instrument,
    isWatchlisted: Boolean,
    onToggleWatchlist: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        color = TxseCardBg,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
        modifier = modifier
            .testTag("instrument_row_${instrument.symbol.lowercase()}")
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Star + Symbol + Company Name
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onToggleWatchlist,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isWatchlisted) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Watchlist",
                        tint = if (isWatchlisted) TxseTexasGold else TxseTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = instrument.symbol,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TxseTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = instrument.hqCity,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 10.sp,
                                color = TxseTextMuted
                            )
                        )
                    }
                    Text(
                        text = instrument.name,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TxseTextSecondary
                        ),
                        maxLines = 1
                    )
                }
            }

            // Right: Price & Percent Change Pill
            val isUp = instrument.change >= 0
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "$%.2f".format(instrument.price),
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TxseTextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Surface(
                    color = if (isUp) TxseGreenBg else TxseRedBg,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = (if (isUp) "+" else "") + "%.2f%%".format(instrument.changePercent),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isUp) TxseGreen else TxseRed,
                            fontSize = 11.sp
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
