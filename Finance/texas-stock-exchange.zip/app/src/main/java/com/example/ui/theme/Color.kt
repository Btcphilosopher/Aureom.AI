package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Lone Star Terminal UI Color Palette
val TxseNavy = Color(0xFF061321)         // Primary midnight background
val TxseDarkSurface = Color(0xFF0B1B2B)   // Secondary surface
val TxseCardBg = Color(0xFF102438)        // Card container
val TxseCardBorder = Color(0xFF1B3550)    // Subtle borders and gridlines
val TxseCardHover = Color(0xFF16304A)     // Elevated hover / selected state

// Brand & Accent Colors
val TxseElectricBlue = Color(0xFF1478E8)  // Texas electric blue
val TxseBlueGlow = Color(0xFF38BDF8)      // Cyan accent / glow
val TxseTexasGold = Color(0xFFD6B36A)     // Restrained Lone Star gold
val TxseGoldMuted = Color(0xFF9E844A)     // Subtle gold for borders/tags

// Market Movement Indicators
val TxseGreen = Color(0xFF16C784)         // Emerald gain / buy
val TxseGreenBg = Color(0x1F16C784)       // Green tint badge
val TxseRed = Color(0xFFF04452)           // Exchange red / sell
val TxseRedBg = Color(0x1FF04452)         // Red tint badge

// Typography Colors
val TxseTextPrimary = Color(0xFFF8FAFC)   // Crisp white
val TxseTextSecondary = Color(0xFF94A3B8) // Cool silver
val TxseTextMuted = Color(0xFF64748B)     // Muted slate
val TxseDivider = Color(0xFF1E293B)       // Separator line
