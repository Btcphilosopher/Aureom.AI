package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Instrument
import com.example.ui.BottomNavTab
import com.example.ui.theme.*

@Composable
fun LoneStarTopBar(
    isMarketOpen: Boolean,
    isProTerminal: Boolean,
    onToggleTerminal: () -> Unit,
    onOpenSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = TxseDarkSurface,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Title with Texas Star Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(TxseElectricBlue, Color(0xFF0A3B75))
                                )
                            )
                            .border(1.dp, TxseBlueGlow.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "TXSE Star",
                            tint = TxseTexasGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "TEXAS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    color = TxseTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "STOCK EXCHANGE",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    color = TxseBlueGlow
                                )
                            )
                        }
                        Text(
                            text = "THE LONE STAR MARKET",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                letterSpacing = 1.2.sp,
                                color = TxseTexasGold
                            )
                        )
                    }
                }

                // Controls: Market Status Badge + Pro Terminal Toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Pulsing Market Status
                    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                    val alpha by infiniteTransition.animateFloat(
                        initialValue = 0.4f,
                        targetValue = 1.0f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(800, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "alpha"
                    )

                    Surface(
                        color = if (isMarketOpen) TxseGreenBg else TxseRedBg,
                        shape = RoundedCornerShape(12.dp),
                        border = borderStroke(if (isMarketOpen) TxseGreen else TxseRed, alpha)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isMarketOpen) TxseGreen.copy(alpha = alpha) else TxseRed
                                    )
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (isMarketOpen) "MARKET OPEN" else "CLOSED",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMarketOpen) TxseGreen else TxseRed
                                )
                            )
                        }
                    }

                    // Terminal View Toggle Button
                    IconButton(
                        onClick = onToggleTerminal,
                        modifier = Modifier
                            .testTag("toggle_terminal_button")
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isProTerminal) TxseElectricBlue else TxseCardBg)
                            .border(1.dp, TxseCardBorder, RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "Toggle Pro Terminal",
                            tint = if (isProTerminal) Color.White else TxseTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            HorizontalDivider(color = TxseCardBorder, thickness = 1.dp)
        }
    }
}

private fun borderStroke(color: Color, alpha: Float): androidx.compose.foundation.BorderStroke {
    return androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = alpha))
}

@Composable
fun MarketTickerTape(
    instruments: List<Instrument>,
    onSelectSymbol: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Surface(
        color = TxseCardBg,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // TSE Tag
            Surface(
                color = TxseNavy,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseTexasGold.copy(alpha = 0.5f)),
                modifier = Modifier.padding(end = 12.dp)
            ) {
                Text(
                    text = "TXSE TAPE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TxseTexasGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    ),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            for (inst in instruments) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onSelectSymbol(inst.symbol) }
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = inst.symbol,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$%.2f".format(inst.price),
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = TxseTextSecondary
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    val isUp = inst.change >= 0
                    Text(
                        text = (if (isUp) "+" else "") + "%.2f%%".format(inst.changePercent),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isUp) TxseGreen else TxseRed
                        )
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "•", color = TxseCardBorder)
                }
            }
        }
    }
}

@Composable
fun LoneStarBottomNav(
    currentTab: BottomNavTab,
    onTabSelected: (BottomNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = TxseDarkSurface,
        modifier = modifier.fillMaxWidth()
    ) {
        Column {
            HorizontalDivider(color = TxseCardBorder, thickness = 1.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .height(64.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomNavItem(
                    label = "Home",
                    icon = Icons.Default.Home,
                    isSelected = currentTab == BottomNavTab.HOME,
                    onClick = { onTabSelected(BottomNavTab.HOME) },
                    testTag = "nav_home"
                )
                BottomNavItem(
                    label = "Markets",
                    icon = Icons.AutoMirrored.Filled.ShowChart,
                    isSelected = currentTab == BottomNavTab.MARKETS,
                    onClick = { onTabSelected(BottomNavTab.MARKETS) },
                    testTag = "nav_markets"
                )
                BottomNavItem(
                    label = "Trade",
                    icon = Icons.Default.SwapHoriz,
                    isSelected = currentTab == BottomNavTab.TRADE,
                    onClick = { onTabSelected(BottomNavTab.TRADE) },
                    testTag = "nav_trade"
                )
                BottomNavItem(
                    label = "Portfolio",
                    icon = Icons.Default.AccountBalanceWallet,
                    isSelected = currentTab == BottomNavTab.PORTFOLIO,
                    onClick = { onTabSelected(BottomNavTab.PORTFOLIO) },
                    testTag = "nav_portfolio"
                )
                BottomNavItem(
                    label = "More",
                    icon = Icons.Default.MoreHoriz,
                    isSelected = currentTab == BottomNavTab.MORE,
                    onClick = { onTabSelected(BottomNavTab.MORE) },
                    testTag = "nav_more"
                )
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        modifier = Modifier
            .testTag(testTag)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) TxseElectricBlue else TxseTextMuted,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) TxseElectricBlue else TxseTextMuted
            )
        )
    }
}
