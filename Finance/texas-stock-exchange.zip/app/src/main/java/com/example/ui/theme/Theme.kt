package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LoneStarColorScheme = darkColorScheme(
    primary = TxseElectricBlue,
    onPrimary = Color.White,
    primaryContainer = TxseCardHover,
    onPrimaryContainer = TxseBlueGlow,
    secondary = TxseTexasGold,
    onSecondary = TxseNavy,
    secondaryContainer = TxseCardBg,
    onSecondaryContainer = TxseTexasGold,
    tertiary = TxseGreen,
    onTertiary = Color.White,
    background = TxseNavy,
    onBackground = TxseTextPrimary,
    surface = TxseDarkSurface,
    onSurface = TxseTextPrimary,
    surfaceVariant = TxseCardBg,
    onSurfaceVariant = TxseTextSecondary,
    outline = TxseCardBorder,
    outlineVariant = TxseDivider,
    error = TxseRed,
    onError = Color.White
)

@Composable
fun TexasStockExchangeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Lone Star Terminal UI is a high-contrast dark financial exchange terminal by design
    MaterialTheme(
        colorScheme = LoneStarColorScheme,
        typography = TxseTypography,
        content = content
    )
}
