package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketDataEngine
import com.example.model.NewsItem
import com.example.ui.theme.*

@Composable
fun NewsScreen(
    onBackClick: () -> Unit,
    onSelectSymbol: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val news = MarketDataEngine.newsItems

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.testTag("news_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TxseTextPrimary
                )
            }
            Text(
                text = "Texas Market Wire & Research",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseTextPrimary
                )
            )
        }

        HorizontalDivider(color = TxseCardBorder)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(news, key = { it.id }) { item ->
                NewsCardItem(
                    item = item,
                    onSelectSymbol = onSelectSymbol
                )
            }
        }
    }
}

@Composable
private fun NewsCardItem(
    item: NewsItem,
    onSelectSymbol: (String) -> Unit
) {
    Surface(
        color = TxseCardBg,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = TxseDarkSurface,
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder)
                ) {
                    Text(
                        text = item.category.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TxseTexasGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = "${item.source}  •  ${item.timeAgo}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = item.title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseTextPrimary,
                    lineHeight = 20.sp
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = item.preview,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TxseTextSecondary,
                    lineHeight = 18.sp
                )
            )

            if (item.relatedSymbol != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Related: ",
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
                    )
                    Surface(
                        color = TxseElectricBlue.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.clickable { onSelectSymbol(item.relatedSymbol) }
                    ) {
                        Text(
                            text = item.relatedSymbol,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TxseBlueGlow,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
