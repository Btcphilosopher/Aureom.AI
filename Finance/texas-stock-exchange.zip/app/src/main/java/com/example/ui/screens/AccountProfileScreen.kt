package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppScreen
import com.example.ui.TxseViewModel
import com.example.ui.theme.*

@Composable
fun AccountProfileScreen(
    viewModel: TxseViewModel,
    onNavigate: (AppScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val userRole by viewModel.userRole.collectAsState()
    val accountNumber by viewModel.accountNumber.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Account & Settings",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseTextPrimary
                )
            )
        }

        // Account Profile Badge
        item {
            Surface(
                color = TxseCardBg,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(TxseElectricBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "User",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = userRole,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TxseTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Account: $accountNumber",
                            style = MaterialTheme.typography.labelSmall.copy(color = TxseTexasGold)
                        )
                        Text(
                            text = "Verification: Level 3 Institutional • 2FA Active",
                            style = MaterialTheme.typography.bodySmall.copy(color = TxseGreen)
                        )
                    }
                }
            }
        }

        // Exchange Tools & Portals
        item {
            Text(
                text = "Exchange Portals & Services",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseTextSecondary
                )
            )
        }

        item {
            Surface(
                color = TxseCardBg,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    SettingsRowItem(
                        icon = Icons.Default.Description,
                        title = "Order Blotter & Execution Records",
                        subtitle = "Audit trails, trade IDs, and canceled orders",
                        onClick = { onNavigate(AppScreen.ORDERS) }
                    )
                    HorizontalDivider(color = TxseCardBorder)
                    SettingsRowItem(
                        icon = Icons.Default.Newspaper,
                        title = "Texas Market Wire & Research",
                        subtitle = "Permian Basin updates, crude flows, earnings",
                        onClick = { onNavigate(AppScreen.NEWS) }
                    )
                    HorizontalDivider(color = TxseCardBorder)
                    SettingsRowItem(
                        icon = Icons.Default.CorporateFare,
                        title = "Issuer & Admin Console",
                        subtitle = "Listing approvals, market session controls",
                        onClick = { onNavigate(AppScreen.ADMIN_CONSOLE) }
                    )
                    HorizontalDivider(color = TxseCardBorder)
                    SettingsRowItem(
                        icon = Icons.Default.Dashboard,
                        title = "Pro Multi-Panel Terminal",
                        subtitle = "Full desktop multi-window trading console",
                        onClick = { onNavigate(AppScreen.DESKTOP_TERMINAL) }
                    )
                }
            }
        }

        // Security & Regulatory Compliance
        item {
            Text(
                text = "Security & Regulatory",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseTextSecondary
                )
            )
        }

        item {
            Surface(
                color = TxseCardBg,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Texas Stock Exchange Regulatory Notice",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTexasGold
                        )
                    )
                    Text(
                        text = "Securities traded on TXSE are cleared through registered clearing agencies. Market data is streamed with low-latency direct connectivity under TXSE Rulebook Articles 4 & 7.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary, lineHeight = 17.sp)
                    )
                }
            }
        }

        // Log out button
        item {
            Button(
                onClick = { viewModel.logout() },
                colors = ButtonDefaults.buttonColors(containerColor = TxseRedBg),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .testTag("logout_button")
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text(
                    text = "Log Out of Terminal",
                    color = TxseRed,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsRowItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TxseElectricBlue,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TxseTextPrimary
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                )
            }
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = TxseTextMuted,
            modifier = Modifier.size(14.dp)
        )
    }
}
