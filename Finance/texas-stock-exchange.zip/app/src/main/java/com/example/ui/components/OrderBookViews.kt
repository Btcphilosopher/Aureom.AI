package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderBook
import com.example.model.RecentTrade
import com.example.ui.theme.*

@Composable
fun OrderBookView(
    orderBook: OrderBook,
    modifier: Modifier = Modifier
) {
    Surface(
        color = TxseCardBg,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ORDER BOOK — ${orderBook.symbol}",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = TxseTextPrimary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                )
                Text(
                    text = "Spread: $%.2f (%.2f%%)".format(orderBook.spread, orderBook.spreadPercent),
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTexasGold)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Column Titles
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Size",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "Bid",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseGreen, fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Ask",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseRed, fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Size",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.End
                )
            }

            HorizontalDivider(
                color = TxseCardBorder,
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            // Rows (Bid & Ask levels side-by-side)
            val rowCount = minOf(orderBook.bids.size, orderBook.asks.size, 6)
            for (i in 0 until rowCount) {
                val bid = orderBook.bids[i]
                val ask = orderBook.asks[i]

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "%,d".format(bid.size),
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextSecondary),
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "%.2f".format(bid.price),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TxseGreen,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "%.2f".format(ask.price),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TxseRed,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "%,d".format(ask.size),
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextSecondary),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.End
                    )
                }
            }
        }
    }
}

@Composable
fun RecentTradesView(
    trades: List<RecentTrade>,
    modifier: Modifier = Modifier
) {
    Surface(
        color = TxseCardBg,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "RECENT TRADES",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = TxseTextPrimary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                )
                Text(
                    text = "TXSE Feed",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseBlueGlow)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Column Header
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Time",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "Price",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Size",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.End
                )
            }

            HorizontalDivider(
                color = TxseCardBorder,
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            // Trade tape items
            val displayedTrades = trades.take(10)
            for (t in displayedTrades) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = t.time,
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "%.2f".format(t.price),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (t.isUptick) TxseGreen else TxseRed,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "%,d".format(t.size),
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextSecondary),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.End
                    )
                }
            }
        }
    }
}
