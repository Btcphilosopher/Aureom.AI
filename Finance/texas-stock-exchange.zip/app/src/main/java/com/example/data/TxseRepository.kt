package com.example.data

import com.example.engine.MarketDataEngine
import com.example.engine.MatchingEngine
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.random.Random

class TxseRepository(
    val matchingEngine: MatchingEngine = MatchingEngine()
) {
    // Auth & User Profile
    private val _isLoggedIn = MutableStateFlow(true)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userRole = MutableStateFlow("Institutional Trader")
    val userRole: StateFlow<String> = _userRole.asStateFlow()

    private val _accountNumber = MutableStateFlow("TXSE-PRO-849201")
    val accountNumber: StateFlow<String> = _accountNumber.asStateFlow()

    // Market session state
    private val _isMarketOpen = MutableStateFlow(true)
    val isMarketOpen: StateFlow<Boolean> = _isMarketOpen.asStateFlow()

    // Instruments
    private val _instruments = MutableStateFlow(MarketDataEngine.initialInstruments)
    val instruments: StateFlow<List<Instrument>> = _instruments.asStateFlow()

    // Watchlist
    private val _watchlistSymbols = MutableStateFlow(
        setOf("XOM", "EOG", "CVX", "TPL", "FANG", "CVE", "BHP", "XLE", "TXN", "AMD", "AAPL")
    )
    val watchlistSymbols: StateFlow<Set<String>> = _watchlistSymbols.asStateFlow()

    // Selected Instrument
    private val _selectedSymbol = MutableStateFlow("XOM")
    val selectedSymbol: StateFlow<String> = _selectedSymbol.asStateFlow()

    // Portfolio State: Matches user's mockup exactly!
    // Total Value: $248,532.17, Cash: $99,658.00, Positions: XOM, EOG, CVX, AAPL
    private val _cashBalance = MutableStateFlow(99658.00)
    val cashBalance: StateFlow<Double> = _cashBalance.asStateFlow()

    private val _positions = MutableStateFlow(
        listOf(
            Position("XOM", shares = 500, avgPrice = 109.90, currentPrice = 112.34),
            Position("EOG", shares = 315, avgPrice = 130.65, currentPrice = 134.27),
            Position("CVX", shares = 200, avgPrice = 154.00, currentPrice = 156.90),
            Position("AAPL", shares = 100, avgPrice = 187.20, currentPrice = 189.34)
        )
    )
    val positions: StateFlow<List<Position>> = _positions.asStateFlow()

    // Orders & Executions
    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _executions = MutableStateFlow<List<Execution>>(emptyList())
    val executions: StateFlow<List<Execution>> = _executions.asStateFlow()

    // Issuer Applications
    private val _listingApplications = MutableStateFlow(
        listOf(
            ListingApplication(
                id = "TXSE-APP-01",
                companyName = "Permian Hydrogen Clean Energy Corp",
                proposedTicker = "PHCE",
                sector = Sector.ENERGY,
                capitalTarget = "$450,000,000",
                sharesOffered = "15,000,000",
                underwriter = "Lone Star Capital Markets LLC",
                status = "Under Review",
                submissionDate = "Oct 19, 2026"
            ),
            ListingApplication(
                id = "TXSE-APP-02",
                companyName = "Austin Quantum Photonics Inc",
                proposedTicker = "AQPH",
                sector = Sector.TECH,
                capitalTarget = "$220,000,000",
                sharesOffered = "8,000,000",
                underwriter = "Texas Securities Underwriters",
                status = "Conditionally Approved",
                submissionDate = "Oct 14, 2026"
            )
        )
    )
    val listingApplications: StateFlow<List<ListingApplication>> = _listingApplications.asStateFlow()

    fun setSelectedSymbol(symbol: String) {
        _selectedSymbol.value = symbol
    }

    fun toggleWatchlist(symbol: String) {
        val current = _watchlistSymbols.value.toMutableSet()
        if (current.contains(symbol)) {
            current.remove(symbol)
        } else {
            current.add(symbol)
        }
        _watchlistSymbols.value = current
    }

    fun login(role: String = "Institutional Trader") {
        _userRole.value = role
        _isLoggedIn.value = true
    }

    fun logout() {
        _isLoggedIn.value = false
    }

    fun setMarketSession(isOpen: Boolean) {
        _isMarketOpen.value = isOpen
    }

    // Submit Order through Matching Engine
    fun placeOrder(order: Order): Pair<Boolean, String> {
        val instrument = _instruments.value.find { it.symbol == order.symbol }
            ?: return Pair(false, "Instrument not found")

        val currentPosition = _positions.value.find { it.symbol == order.symbol }
        val availableShares = currentPosition?.shares ?: 0

        val (isValid, errorMsg) = matchingEngine.validateOrder(
            order = order,
            cashBalance = _cashBalance.value,
            availableShares = availableShares
        )

        if (!isValid) {
            return Pair(false, errorMsg ?: "Order validation failed")
        }

        // Submit to matching engine
        val (processedOrder, fills) = matchingEngine.submitOrder(order, instrument.price)

        val updatedOrders = _orders.value.toMutableList()
        updatedOrders.add(0, processedOrder)
        _orders.value = updatedOrders

        if (fills.isNotEmpty()) {
            val updatedExecs = _executions.value.toMutableList()
            updatedExecs.addAll(0, fills)
            _executions.value = updatedExecs

            // Update cash and positions based on fills
            for (fill in fills) {
                applyExecution(fill)
            }
        }

        return Pair(true, "Order ${processedOrder.id} successfully ${processedOrder.status.displayName}")
    }

    fun cancelOrder(orderId: String): Boolean {
        val removed = matchingEngine.cancelOrder(orderId)
        val list = _orders.value.map {
            if (it.id == orderId) it.copy(status = OrderStatus.CANCELLED) else it
        }
        _orders.value = list
        return true
    }

    private fun applyExecution(execution: Execution) {
        val tradeValue = execution.shares * execution.price
        if (execution.side == OrderSide.BUY) {
            // Deduct cash
            _cashBalance.value = maxOf(0.0, _cashBalance.value - tradeValue)
            // Add to positions
            val currentPositions = _positions.value.toMutableList()
            val existingIndex = currentPositions.indexOfFirst { it.symbol == execution.symbol }
            if (existingIndex >= 0) {
                val existing = currentPositions[existingIndex]
                val newShares = existing.shares + execution.shares
                val newTotalCost = existing.totalCost + tradeValue
                val newAvgPrice = newTotalCost / newShares
                currentPositions[existingIndex] = existing.copy(
                    shares = newShares,
                    avgPrice = newAvgPrice,
                    currentPrice = execution.price
                )
            } else {
                currentPositions.add(
                    Position(
                        symbol = execution.symbol,
                        shares = execution.shares,
                        avgPrice = execution.price,
                        currentPrice = execution.price
                    )
                )
            }
            _positions.value = currentPositions
        } else {
            // Add cash
            _cashBalance.value = _cashBalance.value + tradeValue
            // Deduct from positions
            val currentPositions = _positions.value.toMutableList()
            val existingIndex = currentPositions.indexOfFirst { it.symbol == execution.symbol }
            if (existingIndex >= 0) {
                val existing = currentPositions[existingIndex]
                val remainingShares = existing.shares - execution.shares
                if (remainingShares <= 0) {
                    currentPositions.removeAt(existingIndex)
                } else {
                    currentPositions[existingIndex] = existing.copy(
                        shares = remainingShares,
                        currentPrice = execution.price
                    )
                }
            }
            _positions.value = currentPositions
        }
    }

    fun depositFunds(amount: Double) {
        _cashBalance.value = _cashBalance.value + amount
    }

    fun withdrawFunds(amount: Double): Boolean {
        if (amount > _cashBalance.value) return false
        _cashBalance.value = _cashBalance.value - amount
        return true
    }

    fun submitListingApplication(app: ListingApplication) {
        val list = _listingApplications.value.toMutableList()
        list.add(0, app)
        _listingApplications.value = list
    }

    // Called on periodic ticker to simulate live quote fluctuations
    fun simulateMarketTick() {
        if (!_isMarketOpen.value) return

        val updated = _instruments.value.map { inst ->
            val delta = (Random.nextDouble() - 0.48) * 0.15
            val newPrice = Math.round((inst.price + delta) * 100) / 100.0
            val newChange = Math.round((newPrice - inst.prevClose) * 100) / 100.0
            val newChangePct = Math.round((newChange / inst.prevClose * 100) * 100) / 100.0
            val newHigh = maxOf(inst.high, newPrice)
            val newLow = minOf(inst.low, newPrice)
            val newVol = inst.volume + Random.nextLong(100L, 2500L)

            // Random trade print
            if (Random.nextInt(10) > 6) {
                matchingEngine.recordTrade(
                    symbol = inst.symbol,
                    price = newPrice,
                    size = Random.nextInt(1, 15) * 100,
                    isUptick = delta >= 0
                )
            }

            inst.copy(
                price = newPrice,
                change = newChange,
                changePercent = newChangePct,
                high = newHigh,
                low = newLow,
                volume = newVol
            )
        }
        _instruments.value = updated

        // Sync positions with new market prices
        val updatedPositions = _positions.value.map { pos ->
            val inst = updated.find { it.symbol == pos.symbol }
            if (inst != null) pos.copy(currentPrice = inst.price) else pos
        }
        _positions.value = updatedPositions
    }
}
