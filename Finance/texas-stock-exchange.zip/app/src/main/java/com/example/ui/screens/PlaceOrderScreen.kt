package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderSide
import com.example.model.OrderType
import com.example.model.TimeInForce
import com.example.ui.TxseViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaceOrderScreen(
    viewModel: TxseViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val instrument by viewModel.selectedInstrument.collectAsState()
    val side by viewModel.orderSide.collectAsState()
    val orderType by viewModel.orderType.collectAsState()
    val price by viewModel.orderPrice.collectAsState()
    val shares by viewModel.orderShares.collectAsState()
    val timeInForce by viewModel.timeInForce.collectAsState()
    val cashBalance by viewModel.cashBalance.collectAsState()
    val positions by viewModel.positions.collectAsState()

    val currentHolding = positions.find { it.symbol == instrument.symbol }?.shares ?: 0
    val estimatedTotal = shares * price

    var showReviewModal by remember { mutableStateOf(false) }
    var orderTypeDropdownExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.testTag("order_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TxseTextPrimary
                )
            }

            Column {
                Text(
                    text = "Place Order",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TxseTextPrimary
                    )
                )
                Text(
                    text = "${instrument.symbol} — ${instrument.name}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary)
                )
            }
        }

        HorizontalDivider(color = TxseCardBorder, thickness = 1.dp)

        // Main Body Form
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Buy / Sell Toggle Tabs (matching mockup Screen 4)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(TxseCardBg)
                    .border(1.dp, TxseCardBorder, RoundedCornerShape(8.dp))
            ) {
                Box(
                    modifier = Modifier
                        .testTag("order_side_buy")
                        .weight(1f)
                        .fillMaxHeight()
                        .background(if (side == OrderSide.BUY) TxseGreen else Color.Transparent)
                        .clickable { viewModel.setOrderSide(OrderSide.BUY) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Buy",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (side == OrderSide.BUY) Color.White else TxseTextSecondary
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .testTag("order_side_sell")
                        .weight(1f)
                        .fillMaxHeight()
                        .background(if (side == OrderSide.SELL) TxseRed else Color.Transparent)
                        .clickable { viewModel.setOrderSide(OrderSide.SELL) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Sell",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (side == OrderSide.SELL) Color.White else TxseTextSecondary
                        )
                    )
                }
            }

            // 2. Order Type Selector Dropdown
            Column {
                Text(
                    text = "Order Type",
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
                )
                Spacer(modifier = Modifier.height(4.dp))
                ExposedDropdownMenuBox(
                    expanded = orderTypeDropdownExpanded,
                    onExpandedChange = { orderTypeDropdownExpanded = !orderTypeDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = orderType.displayName,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = orderTypeDropdownExpanded) },
                        modifier = Modifier
                            .testTag("order_type_dropdown")
                            .fillMaxWidth()
                            .menuAnchor(),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = TxseCardBg,
                            unfocusedContainerColor = TxseCardBg,
                            focusedBorderColor = TxseElectricBlue,
                            unfocusedBorderColor = TxseCardBorder,
                            focusedTextColor = TxseTextPrimary,
                            unfocusedTextColor = TxseTextPrimary
                        )
                    )

                    ExposedDropdownMenu(
                        expanded = orderTypeDropdownExpanded,
                        onDismissRequest = { orderTypeDropdownExpanded = false },
                        modifier = Modifier.background(TxseDarkSurface)
                    ) {
                        OrderType.values().forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.displayName, color = TxseTextPrimary) },
                                onClick = {
                                    viewModel.setOrderType(type)
                                    orderTypeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // 3. Price Input Card (with - and + buttons)
            if (orderType != OrderType.MARKET) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Limit Price",
                            style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
                        )
                        Text(
                            text = "Market: $%.2f".format(instrument.price),
                            style = MaterialTheme.typography.labelSmall.copy(color = TxseBlueGlow)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = TxseCardBg,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "$%.2f".format(price),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TxseTextPrimary
                                ),
                                modifier = Modifier.padding(start = 8.dp)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = { viewModel.adjustOrderPrice(-0.05) },
                                    modifier = Modifier
                                        .testTag("price_decrement")
                                        .size(36.dp)
                                        .background(TxseDarkSurface, RoundedCornerShape(6.dp))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Decrease Price",
                                        tint = TxseTextPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.adjustOrderPrice(0.05) },
                                    modifier = Modifier
                                        .testTag("price_increment")
                                        .size(36.dp)
                                        .background(TxseDarkSurface, RoundedCornerShape(6.dp))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Increase Price",
                                        tint = TxseTextPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 4. Shares Input Card (with - and + buttons and quick pills)
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Shares",
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
                    )
                    Text(
                        text = if (side == OrderSide.BUY) "Available: $%,.2f".format(cashBalance) else "Owned: $currentHolding shs",
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTexasGold)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = TxseCardBg,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "$shares",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TxseTextPrimary
                            ),
                            modifier = Modifier.padding(start = 8.dp)
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = { viewModel.adjustOrderShares(-10) },
                                modifier = Modifier
                                    .testTag("shares_decrement")
                                    .size(36.dp)
                                    .background(TxseDarkSurface, RoundedCornerShape(6.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Remove,
                                    contentDescription = "Decrease Shares",
                                    tint = TxseTextPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { viewModel.adjustOrderShares(10) },
                                modifier = Modifier
                                    .testTag("shares_increment")
                                    .size(36.dp)
                                    .background(TxseDarkSurface, RoundedCornerShape(6.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Increase Shares",
                                    tint = TxseTextPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Quick Shares Selector Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(10, 50, 100, 500).forEach { qty ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(TxseCardBg)
                                .border(1.dp, TxseCardBorder, RoundedCornerShape(6.dp))
                                .clickable { viewModel.setOrderShares(qty) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$qty",
                                style = MaterialTheme.typography.labelSmall.copy(color = TxseTextSecondary)
                            )
                        }
                    }
                }
            }

            // 5. Estimated Total Summary Box
            Surface(
                color = TxseCardBg,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Estimated Total",
                            style = MaterialTheme.typography.titleSmall.copy(color = TxseTextSecondary)
                        )
                        Text(
                            text = "$%,.2f".format(estimatedTotal),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TxseTextPrimary
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "TXSE Commission",
                            style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                        )
                        Text(
                            text = "$0.00 (Zero-Fee)",
                            style = MaterialTheme.typography.bodySmall.copy(color = TxseGreen)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Venue Execution",
                            style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                        )
                        Text(
                            text = "TXSE Ultra-Low Latency Match",
                            style = MaterialTheme.typography.bodySmall.copy(color = TxseBlueGlow)
                        )
                    }
                }
            }
        }

        // Review Order Primary Button
        Surface(
            color = TxseDarkSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                HorizontalDivider(color = TxseCardBorder, thickness = 1.dp)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(16.dp)
                ) {
                    Button(
                        onClick = { showReviewModal = true },
                        modifier = Modifier
                            .testTag("review_order_button")
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (side == OrderSide.BUY) TxseGreen else TxseRed
                        )
                    ) {
                        Text(
                            text = "Review Order",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Review Order Confirmation Modal
        if (showReviewModal) {
            AlertDialog(
                onDismissRequest = { showReviewModal = false },
                containerColor = TxseDarkSurface,
                title = {
                    Text(
                        text = "Confirm ${side.name} Order",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary
                        )
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OrderSummaryRow("Instrument", "${instrument.symbol} (${instrument.name})")
                        OrderSummaryRow("Action", "${side.name} $shares Shares")
                        OrderSummaryRow("Order Type", orderType.displayName)
                        OrderSummaryRow("Price", "$%.2f".format(price))
                        OrderSummaryRow("Total Cost", "$%,.2f".format(estimatedTotal))
                        OrderSummaryRow("Exchange", "Texas Stock Exchange (TXSE)")
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showReviewModal = false
                            val success = viewModel.submitCurrentOrder()
                            if (success) {
                                onBackClick()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (side == OrderSide.BUY) TxseGreen else TxseRed
                        )
                    ) {
                        Text("Send Order to Exchange", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showReviewModal = false }) {
                        Text("Cancel", color = TxseTextMuted)
                    }
                }
            )
        }
    }
}

@Composable
private fun OrderSummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted))
        Text(text = value, style = MaterialTheme.typography.labelSmall.copy(color = TxseTextPrimary, fontWeight = FontWeight.Bold))
    }
}
