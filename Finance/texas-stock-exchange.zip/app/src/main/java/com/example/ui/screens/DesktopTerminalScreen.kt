package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderSide
import com.example.model.Timeframe
import com.example.ui.TxseViewModel
import com.example.ui.components.CandlestickChart
import com.example.ui.components.OrderBookView
import com.example.ui.components.RecentTradesView
import com.example.ui.theme.*

@Composable
fun DesktopTerminalScreen(
    viewModel: TxseViewModel,
    onCloseTerminal: () -> Unit,
    modifier: Modifier = Modifier
) {
    val instruments by viewModel.instruments.collectAsState()
    val instrument by viewModel.selectedInstrument.collectAsState()
    val candles by viewModel.candles.collectAsState()
    val orderBook by viewModel.orderBook.collectAsState()
    val recentTrades by viewModel.recentTrades.collectAsState()
    val orderPrice by viewModel.orderPrice.collectAsState()
    val orderShares by viewModel.orderShares.collectAsState()
    val orderSide by viewModel.orderSide.collectAsState()

    var activeTerminalTab by remember { mutableStateOf("MARKETS") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        // 1. Pro Terminal Top Banner (matching mockup Desktop Terminal header)
        Surface(
            color = TxseDarkSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Logo & Slogan
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(TxseElectricBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = TxseTexasGold,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "TEXAS ",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = TxseTextPrimary
                                    )
                                )
                                Text(
                                    text = "STOCK EXCHANGE",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TxseBlueGlow
                                    )
                                )
                            }
                            Text(
                                text = "THE LONE STAR MARKET  •  CAPITAL ★ COMMERCE ★ TEXAS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 8.5.sp,
                                    color = TxseTexasGold
                                )
                            )
                        }
                    }

                    // Terminal Close button to return to mobile view
                    IconButton(
                        onClick = onCloseTerminal,
                        modifier = Modifier
                            .testTag("close_desktop_terminal")
                            .size(32.dp)
                            .background(TxseCardBg, RoundedCornerShape(6.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Terminal",
                            tint = TxseTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Nav Tabs Strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("MARKETS", "TRADE", "PORTFOLIO", "WATCHLIST", "NEWS", "RESEARCH", "SETTINGS").forEach { tab ->
                        val isSelected = activeTerminalTab == tab
                        Text(
                            text = tab,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) TxseBlueGlow else TxseTextMuted
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) TxseCardBg else Color.Transparent)
                                .clickable { activeTerminalTab = tab }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
                HorizontalDivider(color = TxseCardBorder)
            }
        }

        // 2. Multi-Panel Desktop Layout (Vertically and Horizontally scrollable container)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Center High-Density Panel: Symbol Header + Candlestick Chart
            Surface(
                color = TxseDarkSurface,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = instrument.symbol,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TxseTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = instrument.name,
                                style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "$%.2f".format(instrument.price),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TxseTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val isUp = instrument.change >= 0
                            Text(
                                text = "${if (isUp) "+" else ""}$%.2f (${if (isUp) "+" else ""}%.2f%%)".format(
                                    instrument.change,
                                    instrument.changePercent
                                ),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = if (isUp) TxseGreen else TxseRed,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    CandlestickChart(candles = candles)
                }
            }

            // Quick Trade Ticket + Order Book Side by Side
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Left Column: Order Book
                Box(modifier = Modifier.weight(1.2f)) {
                    OrderBookView(orderBook = orderBook)
                }

                // Right Column: Instant Trade Box
                Surface(
                    color = TxseCardBg,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "TRADE ${instrument.symbol}",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TxseTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Buy/Sell buttons
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(32.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(TxseDarkSurface)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(if (orderSide == OrderSide.BUY) TxseGreen else Color.Transparent)
                                    .clickable { viewModel.setOrderSide(OrderSide.BUY) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Buy", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color.White))
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(if (orderSide == OrderSide.SELL) TxseRed else Color.Transparent)
                                    .clickable { viewModel.setOrderSide(OrderSide.SELL) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Sell", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color.White))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Shares: $orderShares", style = MaterialTheme.typography.labelSmall.copy(color = TxseTextSecondary))
                        Text("Limit: $%.2f".format(orderPrice), style = MaterialTheme.typography.labelSmall.copy(color = TxseTextSecondary))
                        Text("Total: $%,.2f".format(orderShares * orderPrice), style = MaterialTheme.typography.labelSmall.copy(color = TxseTexasGold, fontWeight = FontWeight.Bold))

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { viewModel.submitCurrentOrder() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (orderSide == OrderSide.BUY) TxseGreen else TxseRed
                            )
                        ) {
                            Text(
                                text = "${orderSide.name} ${instrument.symbol}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                            )
                        }
                    }
                }
            }

            // Recent Trades Stream
            RecentTradesView(trades = recentTrades)

            // Texas Top 20 Table
            Surface(
                color = TxseCardBg,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "TEXAS TOP 20 SECURITIES",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    instruments.take(8).forEach { inst ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectInstrument(inst.symbol) }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = inst.symbol,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (inst.symbol == instrument.symbol) TxseBlueGlow else TxseTextPrimary
                                )
                            )
                            Text(
                                text = "$%.2f".format(inst.price),
                                style = MaterialTheme.typography.labelMedium.copy(color = TxseTextSecondary)
                            )
                            val isUp = inst.change >= 0
                            Text(
                                text = "${if (isUp) "+" else ""}$%.2f (${if (isUp) "+" else ""}%.2f%%)".format(inst.change, inst.changePercent),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isUp) TxseGreen else TxseRed,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }

            // Texas Energy Powerhouse Banner Poster
            Surface(
                color = TxseDarkSurface,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TxseTexasGold.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = TxseTexasGold,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "TEXAS STOCK EXCHANGE",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = TxseTextPrimary,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "INVEST IN AMERICA'S ENERGY POWERHOUSE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TxseTexasGold,
                            letterSpacing = 1.2.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "EQUITIES  ★  OPTIONS  ★  FUTURES  ★  BONDS  ★  COMMODITIES",
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "TEXAS OWNED. TEXAS DRIVEN.",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TxseBlueGlow,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}
