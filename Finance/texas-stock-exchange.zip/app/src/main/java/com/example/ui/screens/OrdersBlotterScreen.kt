package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Execution
import com.example.model.Order
import com.example.model.OrderSide
import com.example.model.OrderStatus
import com.example.ui.TxseViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrdersBlotterScreen(
    viewModel: TxseViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.orders.collectAsState()
    val executions by viewModel.executions.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Working Orders, 1: Executions Blotter

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.testTag("blotter_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TxseTextPrimary
                )
            }
            Text(
                text = "Orders & Execution Blotter",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseTextPrimary
                )
            )
        }

        TabRow(
            selectedTabIndex = activeTab,
            containerColor = TxseDarkSurface,
            contentColor = TxseElectricBlue,
            divider = { HorizontalDivider(color = TxseCardBorder) }
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Working Orders (${orders.count { it.status == OrderStatus.ACCEPTED }})") }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Filled Trades (${executions.size})") }
            )
        }

        if (activeTab == 0) {
            // Working Orders
            if (orders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No active or historical orders submitted yet.", color = TxseTextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(orders, key = { it.id }) { order ->
                        OrderCardItem(
                            order = order,
                            onCancelOrder = { viewModel.cancelOrder(order.id) }
                        )
                    }
                }
            }
        } else {
            // Executions
            if (executions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No executions recorded this session.", color = TxseTextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(executions, key = { it.executionId }) { exec ->
                        ExecutionCardItem(execution = exec)
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderCardItem(
    order: Order,
    onCancelOrder: () -> Unit
) {
    val isBuy = order.side == OrderSide.BUY

    Surface(
        color = TxseCardBg,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = if (isBuy) TxseGreenBg else TxseRedBg,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = order.side.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isBuy) TxseGreen else TxseRed
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = order.symbol,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary
                        )
                    )
                }

                Surface(
                    color = TxseDarkSurface,
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder)
                ) {
                    Text(
                        text = order.status.displayName,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = when (order.status) {
                                OrderStatus.FILLED -> TxseGreen
                                OrderStatus.CANCELLED -> TxseTextMuted
                                else -> TxseBlueGlow
                            }
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${order.type.displayName}  •  ${order.shares} shs @ $%.2f".format(order.price),
                    style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary)
                )
                Text(
                    text = "$%,.2f".format(order.totalValue),
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = TxseTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            if (order.status == OrderStatus.ACCEPTED) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onCancelOrder,
                    colors = ButtonDefaults.buttonColors(containerColor = TxseRedBg),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Cancel Order", color = TxseRed, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ExecutionCardItem(execution: Execution) {
    val isBuy = execution.side == OrderSide.BUY
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    Surface(
        color = TxseCardBg,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = if (isBuy) TxseGreenBg else TxseRedBg,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = execution.side.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isBuy) TxseGreen else TxseRed
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = execution.symbol,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary
                        )
                    )
                }

                Text(
                    text = timeFormat.format(Date(execution.executedAt)),
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Filled ${execution.shares} shs @ $%.2f".format(execution.price),
                    style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary)
                )
                Text(
                    text = "$%,.2f".format(execution.shares * execution.price),
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = TxseTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "ID: ${execution.executionId}  •  Venue: TXSE Direct Match",
                style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
            )
        }
    }
}
