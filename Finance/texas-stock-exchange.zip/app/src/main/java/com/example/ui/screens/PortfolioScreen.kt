package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketDataEngine
import com.example.model.Position
import com.example.model.Timeframe
import com.example.ui.AppScreen
import com.example.ui.TxseViewModel
import com.example.ui.components.PortfolioPerformanceChart
import com.example.ui.theme.*

@Composable
fun PortfolioScreen(
    viewModel: TxseViewModel,
    onInstrumentClick: (String) -> Unit,
    onViewOrdersClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val portfolio by viewModel.portfolio.collectAsState()
    val cashBalance by viewModel.cashBalance.collectAsState()

    var selectedTf by remember { mutableStateOf(Timeframe.ONE_DAY) }
    var showDepositDialog by remember { mutableStateOf(false) }
    var depositAmountText by remember { mutableStateOf("10000") }

    val chartPoints = remember(portfolio.totalValue, selectedTf) {
        MarketDataEngine.generatePortfolioHistory(portfolio.totalValue, selectedTf)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                // Portfolio Header Title (matching mockup Screen 5)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Portfolio",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TxseTextPrimary
                            )
                        )
                        Text(
                            text = "Total Value",
                            style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                        )
                    }

                    // Quick Orders Blotter Button
                    TextButton(
                        onClick = onViewOrdersClick,
                        modifier = Modifier.testTag("portfolio_view_orders")
                    ) {
                        Text("Order Blotter", color = TxseBlueGlow, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Total Value & Day Gain
            item {
                Column {
                    Text(
                        text = "$%,.2f".format(portfolio.totalValue),
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary,
                            letterSpacing = (-0.5).sp
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "+$%,.2f (+%.2f%%)".format(portfolio.dayPl, portfolio.dayPlPercent),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseGreen
                        )
                    )
                }
            }

            // Performance Line Chart
            item {
                Surface(
                    color = TxseDarkSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder)
                ) {
                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                        PortfolioPerformanceChart(points = chartPoints)

                        Spacer(modifier = Modifier.height(8.dp))

                        // Timeframe Buttons: 1D, 1W, 1M, 3M, 1Y
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            listOf(
                                Timeframe.ONE_DAY,
                                Timeframe.ONE_WEEK,
                                Timeframe.ONE_MONTH,
                                Timeframe.THREE_MONTHS,
                                Timeframe.ONE_YEAR
                            ).forEach { tf ->
                                val isSelected = selectedTf == tf
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) TxseElectricBlue else Color.Transparent)
                                        .clickable { selectedTf = tf }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = tf.label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isSelected) Color.White else TxseTextSecondary,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Quick Cash & Deposit / Withdraw Bar
            item {
                Surface(
                    color = TxseCardBg,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Available Cash",
                                style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                            )
                            Text(
                                text = "$%,.2f".format(cashBalance),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TxseTextPrimary
                                )
                            )
                        }

                        Button(
                            onClick = { showDepositDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = TxseElectricBlue),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Deposit", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            // Asset Breakdown Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Asset",
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                        modifier = Modifier.weight(1.5f)
                    )
                    Text(
                        text = "Value",
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                        modifier = Modifier.weight(1.2f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.End
                    )
                    Text(
                        text = "Chg %",
                        style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted),
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.End
                    )
                }
            }

            // Positions list (matching mockup: XOM, EOG, CVX, AAPL, Cash)
            items(portfolio.positions, key = { it.symbol }) { pos ->
                HoldingRowItem(
                    position = pos,
                    onClick = {
                        viewModel.selectInstrument(pos.symbol)
                        onInstrumentClick(pos.symbol)
                    }
                )
            }

            // Cash Row
            item {
                Surface(
                    color = TxseCardBg,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Cash",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TxseTextPrimary
                            ),
                            modifier = Modifier.weight(1.5f)
                        )
                        Text(
                            text = "$%,d".format(cashBalance.toInt()),
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TxseTextPrimary
                            ),
                            modifier = Modifier.weight(1.2f),
                            textAlign = androidx.compose.ui.text.style.TextAlign.End
                        )
                        Text(
                            text = "—",
                            style = MaterialTheme.typography.labelMedium.copy(color = TxseTextMuted),
                            modifier = Modifier.weight(1f),
                            textAlign = androidx.compose.ui.text.style.TextAlign.End
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Deposit Funds Dialog
        if (showDepositDialog) {
            AlertDialog(
                onDismissRequest = { showDepositDialog = false },
                containerColor = TxseDarkSurface,
                title = {
                    Text("Fund Account via ACH / Wire", color = TxseTextPrimary)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "Instant deposit into your TXSE Settlement Ledger:",
                            style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary)
                        )
                        OutlinedTextField(
                            value = depositAmountText,
                            onValueChange = { depositAmountText = it },
                            label = { Text("Amount ($ USD)") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = TxseCardBg,
                                unfocusedContainerColor = TxseCardBg,
                                focusedTextColor = TxseTextPrimary,
                                unfocusedTextColor = TxseTextPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val amt = depositAmountText.toDoubleOrNull() ?: 10000.0
                            viewModel.depositFunds(amt)
                            showDepositDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TxseGreen)
                    ) {
                        Text("Confirm Deposit", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDepositDialog = false }) {
                        Text("Cancel", color = TxseTextMuted)
                    }
                }
            )
        }
    }
}

@Composable
fun HoldingRowItem(
    position: Position,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUp = position.unrealizedPl >= 0

    Surface(
        onClick = onClick,
        color = TxseCardBg,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
        modifier = modifier
            .testTag("holding_row_${position.symbol.lowercase()}")
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.5f)) {
                Text(
                    text = position.symbol,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TxseTextPrimary
                    )
                )
                Text(
                    text = "${position.shares} shs @ $%.2f".format(position.avgPrice),
                    style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                )
            }

            Text(
                text = "$%,d".format(position.marketValue.toInt()),
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseTextPrimary
                ),
                modifier = Modifier.weight(1.2f),
                textAlign = androidx.compose.ui.text.style.TextAlign.End
            )

            Text(
                text = (if (isUp) "+" else "") + "%.2f%%".format(position.unrealizedPlPercent),
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isUp) TxseGreen else TxseRed
                ),
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.End
            )
        }
    }
}
