package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.TxseRepository
import com.example.engine.MarketDataEngine
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppScreen {
    SPLASH,
    MARKETS,
    DETAIL,
    PLACE_ORDER,
    PORTFOLIO,
    ORDERS,
    NEWS,
    DESKTOP_TERMINAL,
    ADMIN_CONSOLE,
    ISSUER_PORTAL,
    PROFILE
}

enum class BottomNavTab {
    HOME,
    MARKETS,
    TRADE,
    PORTFOLIO,
    MORE
}

class TxseViewModel(
    val repository: TxseRepository = TxseRepository()
) : ViewModel() {

    private val _currentScreen = MutableStateFlow(AppScreen.MARKETS)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _currentTab = MutableStateFlow(BottomNavTab.MARKETS)
    val currentTab: StateFlow<BottomNavTab> = _currentTab.asStateFlow()

    private val _isProTerminal = MutableStateFlow(false)
    val isProTerminal: StateFlow<Boolean> = _isProTerminal.asStateFlow()

    val isLoggedIn = repository.isLoggedIn
    val userRole = repository.userRole
    val accountNumber = repository.accountNumber
    val isMarketOpen = repository.isMarketOpen
    val instruments = repository.instruments
    val watchlistSymbols = repository.watchlistSymbols
    val positions = repository.positions
    val cashBalance = repository.cashBalance
    val orders = repository.orders
    val executions = repository.executions
    val listingApplications = repository.listingApplications

    // Sector & Search filters
    private val _selectedSector = MutableStateFlow(Sector.ALL)
    val selectedSector: StateFlow<Sector> = _selectedSector.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Filtered Instruments
    val filteredInstruments: StateFlow<List<Instrument>> = combine(
        instruments,
        _selectedSector,
        _searchQuery
    ) { list, sector, query ->
        list.filter { inst ->
            val matchesSector = (sector == Sector.ALL) || (inst.sector == sector)
            val matchesQuery = query.isBlank() ||
                    inst.symbol.contains(query, ignoreCase = true) ||
                    inst.name.contains(query, ignoreCase = true)
            matchesSector && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MarketDataEngine.initialInstruments)

    // Selected Instrument
    val selectedSymbol = repository.selectedSymbol
    val selectedInstrument: StateFlow<Instrument> = combine(
        instruments,
        selectedSymbol
    ) { list, sym ->
        list.find { it.symbol == sym } ?: list.first()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MarketDataEngine.initialInstruments.first())

    // Chart Timeframe & Candles
    private val _selectedTimeframe = MutableStateFlow(Timeframe.ONE_DAY)
    val selectedTimeframe: StateFlow<Timeframe> = _selectedTimeframe.asStateFlow()

    val candles: StateFlow<List<Candle>> = combine(
        selectedInstrument,
        _selectedTimeframe
    ) { inst, tf ->
        MarketDataEngine.generateCandles(inst.symbol, tf, inst.price)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Order Book & Recent Trades
    val orderBook: StateFlow<OrderBook> = selectedInstrument.map { inst ->
        repository.matchingEngine.generateOrderBook(inst.symbol, inst.price)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repository.matchingEngine.generateOrderBook("XOM", 112.34))

    val recentTrades: StateFlow<List<RecentTrade>> = selectedInstrument.map { inst ->
        repository.matchingEngine.getRecentTrades(inst.symbol)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Portfolio Computed Totals
    val portfolio: StateFlow<Portfolio> = combine(
        cashBalance,
        positions
    ) { cash, posList ->
        val stockValue = posList.sumOf { it.marketValue }
        val total = cash + stockValue
        val dayGain = posList.sumOf { (it.currentPrice - it.avgPrice) * it.shares * 0.4 } // simulated day movement
        val dayGainPct = if (total > 0) (dayGain / total) * 100.0 else 0.0
        Portfolio(
            totalValue = total,
            cashBalance = cash,
            buyingPower = cash * 2.0, // 2x Reg T day trading buying power
            dayPl = dayGain,
            dayPlPercent = dayGainPct,
            positions = posList
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Portfolio(248532.17, 99658.0, 199316.0, 4982.32, 2.05, emptyList()))

    // Order Ticket Draft
    private val _orderSide = MutableStateFlow(OrderSide.BUY)
    val orderSide: StateFlow<OrderSide> = _orderSide.asStateFlow()

    private val _orderType = MutableStateFlow(OrderType.LIMIT)
    val orderType: StateFlow<OrderType> = _orderType.asStateFlow()

    private val _orderPrice = MutableStateFlow(112.36)
    val orderPrice: StateFlow<Double> = _orderPrice.asStateFlow()

    private val _orderShares = MutableStateFlow(100)
    val orderShares: StateFlow<Int> = _orderShares.asStateFlow()

    private val _timeInForce = MutableStateFlow(TimeInForce.DAY)
    val timeInForce: StateFlow<TimeInForce> = _timeInForce.asStateFlow()

    // User Feedback Toast / Dialog
    private val _tradeMessage = MutableStateFlow<String?>(null)
    val tradeMessage: StateFlow<String?> = _tradeMessage.asStateFlow()

    init {
        // Start live market data ticker (1.5 second ticks)
        viewModelScope.launch {
            while (true) {
                delay(1500)
                repository.simulateMarketTick()
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun selectTab(tab: BottomNavTab) {
        _currentTab.value = tab
        when (tab) {
            BottomNavTab.HOME, BottomNavTab.MARKETS -> _currentScreen.value = AppScreen.MARKETS
            BottomNavTab.TRADE -> {
                // Initialize order ticket with current selected instrument
                val inst = selectedInstrument.value
                _orderPrice.value = inst.price
                _currentScreen.value = AppScreen.PLACE_ORDER
            }
            BottomNavTab.PORTFOLIO -> _currentScreen.value = AppScreen.PORTFOLIO
            BottomNavTab.MORE -> _currentScreen.value = AppScreen.PROFILE
        }
    }

    fun toggleProTerminal() {
        _isProTerminal.value = !_isProTerminal.value
    }

    fun selectInstrument(symbol: String) {
        repository.setSelectedSymbol(symbol)
        val inst = repository.instruments.value.find { it.symbol == symbol }
        if (inst != null) {
            _orderPrice.value = inst.price
        }
    }

    fun setTimeframe(timeframe: Timeframe) {
        _selectedTimeframe.value = timeframe
    }

    fun setSector(sector: Sector) {
        _selectedSector.value = sector
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleWatchlist(symbol: String) {
        repository.toggleWatchlist(symbol)
    }

    fun setOrderSide(side: OrderSide) {
        _orderSide.value = side
    }

    fun setOrderType(type: OrderType) {
        _orderType.value = type
    }

    fun setOrderPrice(price: Double) {
        _orderPrice.value = Math.max(0.01, Math.round(price * 100) / 100.0)
    }

    fun adjustOrderPrice(delta: Double) {
        setOrderPrice(_orderPrice.value + delta)
    }

    fun setOrderShares(shares: Int) {
        _orderShares.value = Math.max(1, shares)
    }

    fun adjustOrderShares(delta: Int) {
        setOrderShares(_orderShares.value + delta)
    }

    fun submitCurrentOrder(): Boolean {
        val sym = selectedSymbol.value
        val order = Order(
            id = "TXSE-ORD-" + UUID.randomUUID().toString().take(6).uppercase(),
            symbol = sym,
            side = _orderSide.value,
            type = _orderType.value,
            timeInForce = _timeInForce.value,
            price = _orderPrice.value,
            shares = _orderShares.value
        )
        val (success, msg) = repository.placeOrder(order)
        _tradeMessage.value = msg
        return success
    }

    fun cancelOrder(orderId: String) {
        repository.cancelOrder(orderId)
        _tradeMessage.value = "Order $orderId canceled by user"
    }

    fun dismissTradeMessage() {
        _tradeMessage.value = null
    }

    fun login(role: String) {
        repository.login(role)
        _currentScreen.value = AppScreen.MARKETS
    }

    fun logout() {
        repository.logout()
        _currentScreen.value = AppScreen.SPLASH
    }

    fun depositFunds(amount: Double) {
        repository.depositFunds(amount)
        _tradeMessage.value = "Deposited $%.2f via Texas Commerce Wire".format(amount)
    }

    fun withdrawFunds(amount: Double) {
        val ok = repository.withdrawFunds(amount)
        if (ok) {
            _tradeMessage.value = "Withdrawn $%.2f to linked settlement account".format(amount)
        } else {
            _tradeMessage.value = "Withdrawal exceeds available cash balance"
        }
    }

    fun setMarketSession(isOpen: Boolean) {
        repository.setMarketSession(isOpen)
    }
}
