package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ListingApplication
import com.example.model.Sector
import com.example.ui.TxseViewModel
import com.example.ui.theme.*
import java.util.UUID

@Composable
fun AdminAndIssuerScreen(
    viewModel: TxseViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val applications by viewModel.listingApplications.collectAsState()
    val isMarketOpen by viewModel.isMarketOpen.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Issuer Portal, 1: Exchange Admin
    var showNewAppDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.testTag("admin_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TxseTextPrimary
                )
            }
            Text(
                text = "Issuer & Exchange Administration",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseTextPrimary
                )
            )
        }

        TabRow(
            selectedTabIndex = activeTab,
            containerColor = TxseDarkSurface,
            contentColor = TxseElectricBlue,
            divider = { HorizontalDivider(color = TxseCardBorder) }
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Issuer Listings") }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Exchange Operations") }
            )
        }

        if (activeTab == 0) {
            // Corporate Issuer Portal
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Corporate Issuer Portal",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TxseTextPrimary
                                )
                            )
                            Text(
                                text = "TXSE Prime & Dual-Listing Applications",
                                style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted)
                            )
                        }

                        Button(
                            onClick = { showNewAppDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = TxseElectricBlue),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("New Listing", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                items(applications, key = { it.id }) { app ->
                    Surface(
                        color = TxseCardBg,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = app.companyName,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TxseTextPrimary
                                    )
                                )
                                Surface(
                                    color = TxseDarkSurface,
                                    shape = RoundedCornerShape(4.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder)
                                ) {
                                    Text(
                                        text = app.status,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = TxseTexasGold,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Proposed Ticker: ${app.proposedTicker}  •  Sector: ${app.sector.displayName}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TxseBlueGlow)
                            )
                            Text(
                                text = "Capital Target: ${app.capitalTarget}  •  Shares: ${app.sharesOffered}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary)
                            )
                            Text(
                                text = "Underwriter: ${app.underwriter}  •  Filed: ${app.submissionDate}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
                            )
                        }
                    }
                }
            }
        } else {
            // Exchange Administrator Operations
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = "Exchange Session Controls",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary
                        )
                    )
                }

                item {
                    Surface(
                        color = TxseCardBg,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Regular Trading Session",
                                        style = MaterialTheme.typography.titleSmall.copy(color = TxseTextPrimary)
                                    )
                                    Text(
                                        text = if (isMarketOpen) "Orders matching live at 0.12ms" else "Halted / Session Closed",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (isMarketOpen) TxseGreen else TxseRed
                                        )
                                    )
                                }

                                Switch(
                                    checked = isMarketOpen,
                                    onCheckedChange = { viewModel.setMarketSession(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = TxseGreen,
                                        uncheckedThumbColor = Color.White,
                                        uncheckedTrackColor = TxseRed
                                    )
                                )
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "Matching Engine Telemetry",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TxseTextPrimary
                        )
                    )
                }

                item {
                    Surface(
                        color = TxseCardBg,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AdminMetricRow("Engine Status", if (isMarketOpen) "ACTIVE (Deterministic L3)" else "HALTED")
                            AdminMetricRow("Average Fill Latency", "120 microseconds")
                            AdminMetricRow("Order Routing", "Direct Exchange Memory Bus")
                            AdminMetricRow("Pre-Trade Risk Checks", "100% Passed")
                            AdminMetricRow("Surveillance Status", "NORMAL (No spoofing or manipulation flags)")
                        }
                    }
                }
            }
        }

        // New Listing Application Dialog
        if (showNewAppDialog) {
            var compName by remember { mutableStateOf("") }
            var ticker by remember { mutableStateOf("") }
            var targetCap by remember { mutableStateOf("$350,000,000") }

            AlertDialog(
                onDismissRequest = { showNewAppDialog = false },
                containerColor = TxseDarkSurface,
                title = { Text("Submit Listing Application", color = TxseTextPrimary) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = compName,
                            onValueChange = { compName = it },
                            label = { Text("Company Name") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = ticker,
                            onValueChange = { ticker = it.uppercase() },
                            label = { Text("Proposed Ticker (e.g. TXNR)") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = targetCap,
                            onValueChange = { targetCap = it },
                            label = { Text("Capital Target") },
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (compName.isNotBlank() && ticker.isNotBlank()) {
                                viewModel.repository.submitListingApplication(
                                    ListingApplication(
                                        id = "TXSE-APP-" + UUID.randomUUID().toString().take(4).uppercase(),
                                        companyName = compName,
                                        proposedTicker = ticker,
                                        sector = Sector.ENERGY,
                                        capitalTarget = targetCap,
                                        sharesOffered = "10,000,000",
                                        underwriter = "Texas Securities Capital LLC",
                                        status = "Under Review",
                                        submissionDate = "Today"
                                    )
                                )
                                showNewAppDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TxseElectricBlue)
                    ) {
                        Text("Submit to Exchange", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showNewAppDialog = false }) {
                        Text("Cancel", color = TxseTextMuted)
                    }
                }
            )
        }
    }
}

@Composable
private fun AdminMetricRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall.copy(color = TxseTextMuted))
        Text(text = value, style = MaterialTheme.typography.labelSmall.copy(color = TxseTextPrimary, fontWeight = FontWeight.Bold))
    }
}
