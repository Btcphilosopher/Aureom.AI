package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@Composable
fun SplashScreen(
    onLoginClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showRoleDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(TxseNavy)
    ) {
        // Hero Background: Dallas & Houston skyline with oil pumpjack twilight
        Image(
            painter = painterResource(id = R.drawable.txse_hero_skyline),
            contentDescription = "Texas Skyline Background",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay for readability and financial terminal atmosphere
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            TxseNavy.copy(alpha = 0.75f),
                            TxseNavy.copy(alpha = 0.5f),
                            TxseNavy.copy(alpha = 0.95f),
                            TxseNavy
                        )
                    )
                )
        )

        // Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(TxseDarkSurface.copy(alpha = 0.85f))
                    .border(1.dp, TxseTexasGold.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = TxseTexasGold,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "THE LONE STAR MARKET",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TxseTexasGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                )
            }

            // Center: Brand Logo and Title (matching mockup Screen 1)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 20.dp)
            ) {
                // Large Lone Star Logo Asset
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(TxseElectricBlue, Color(0xFF07274E))
                            )
                        )
                        .border(1.5.dp, TxseBlueGlow.copy(alpha = 0.6f), RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Lone Star Logo",
                        tint = TxseTexasGold,
                        modifier = Modifier.size(54.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "TEXAS",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        color = TxseTextPrimary
                    )
                )
                Text(
                    text = "STOCK EXCHANGE",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = TxseBlueGlow
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "THE LONE STAR MARKET",
                    style = MaterialTheme.typography.labelMedium.copy(
                        letterSpacing = 2.sp,
                        color = TxseTextSecondary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Texas Capital. Global Reach.\nSecurities, Energy & Industrial Marketplace",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TxseTextMuted,
                        lineHeight = 20.sp
                    )
                )
            }

            // Bottom Actions: Log In & Create Account
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = { showRoleDialog = true },
                    modifier = Modifier
                        .testTag("login_button")
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TxseElectricBlue)
                ) {
                    Text(
                        text = "Log In",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = { onLoginClick("Retail Investor") },
                    modifier = Modifier
                        .testTag("create_account_button")
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = TxseDarkSurface.copy(alpha = 0.7f)
                    )
                ) {
                    Text(
                        text = "Create Account",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = TxseTextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Footer branding
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Trade  ★  Invest  ★  Grow",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TxseTexasGold,
                            letterSpacing = 1.2.sp
                        )
                    )
                }
            }
        }

        // Quick Role Picker Modal
        if (showRoleDialog) {
            AlertDialog(
                onDismissRequest = { showRoleDialog = false },
                containerColor = TxseDarkSurface,
                title = {
                    Text(
                        text = "Select Account Profile",
                        style = MaterialTheme.typography.titleMedium.copy(color = TxseTextPrimary)
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        RoleOptionItem("Institutional Trader", "High-frequency desk, Level 2 depth & direct execution") {
                            showRoleDialog = false
                            onLoginClick("Institutional Trader")
                        }
                        RoleOptionItem("Retail Investor", "Individual cash & margin trading with portfolio analytics") {
                            showRoleDialog = false
                            onLoginClick("Retail Investor")
                        }
                        RoleOptionItem("Exchange Administrator", "Market surveillance, session halts & issuer approvals") {
                            showRoleDialog = false
                            onLoginClick("Exchange Administrator")
                        }
                        RoleOptionItem("Corporate Issuer", "Listing management, capital raises & compliance filings") {
                            showRoleDialog = false
                            onLoginClick("Corporate Issuer")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showRoleDialog = false }) {
                        Text("Cancel", color = TxseTextMuted)
                    }
                }
            )
        }
    }
}

@Composable
private fun RoleOptionItem(
    role: String,
    description: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = TxseCardBg,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TxseCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = role,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TxseElectricBlue
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(color = TxseTextSecondary)
            )
        }
    }
}
