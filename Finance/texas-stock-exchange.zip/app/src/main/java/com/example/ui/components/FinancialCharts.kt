package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Candle
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CandlestickChart(
    candles: List<Candle>,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(260.dp)
                .background(TxseDarkSurface),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "Loading Live Feed...", color = TxseTextMuted)
        }
        return
    }

    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.US) }

    val activeCandle = selectedIndex?.let { if (it in candles.indices) candles[it] else null } ?: candles.last()

    Column(modifier = modifier.fillMaxWidth()) {
        // Floating Scrubber HUD
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "O: $%.2f".format(activeCandle.open),
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseTextSecondary)
                )
                Text(
                    text = "H: $%.2f".format(activeCandle.high),
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseGreen)
                )
                Text(
                    text = "L: $%.2f".format(activeCandle.low),
                    style = MaterialTheme.typography.labelSmall.copy(color = TxseRed)
                )
                Text(
                    text = "C: $%.2f".format(activeCandle.close),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (activeCandle.close >= activeCandle.open) TxseGreen else TxseRed,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
            Text(
                text = "Vol: %,d".format(activeCandle.volume),
                style = MaterialTheme.typography.labelSmall.copy(color = TxseTextMuted)
            )
        }

        // Canvas Chart
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(TxseNavy)
                .pointerInput(candles) {
                    detectTapGestures(
                        onPress = { offset ->
                            val candleWidth = size.width / candles.size
                            val index = (offset.x / candleWidth).toInt().coerceIn(0, candles.size - 1)
                            selectedIndex = index
                        }
                    )
                }
                .pointerInput(candles) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val candleWidth = size.width / candles.size
                            val index = (offset.x / candleWidth).toInt().coerceIn(0, candles.size - 1)
                            selectedIndex = index
                        },
                        onDragEnd = { selectedIndex = null },
                        onDragCancel = { selectedIndex = null },
                        onDrag = { change, _ ->
                            val candleWidth = size.width / candles.size
                            val index = (change.position.x / candleWidth).toInt().coerceIn(0, candles.size - 1)
                            selectedIndex = index
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                val volumeHeight = height * 0.22f
                val chartHeight = height - volumeHeight - 16f

                val minPrice = candles.minOf { it.low } * 0.998f
                val maxPrice = candles.maxOf { it.high } * 1.002f
                val priceRange = if (maxPrice > minPrice) (maxPrice - minPrice).toFloat() else 1f

                val maxVolume = candles.maxOfOrNull { it.volume } ?: 1L

                // 1. Draw horizontal gridlines and price markers
                val gridLines = 4
                for (i in 0..gridLines) {
                    val y = chartHeight * (i.toFloat() / gridLines)
                    drawLine(
                        color = TxseCardBorder.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1f
                    )
                }

                // Volume separator
                drawLine(
                    color = TxseCardBorder,
                    start = Offset(0f, height - volumeHeight),
                    end = Offset(width, height - volumeHeight),
                    strokeWidth = 1f
                )

                // 2. Draw Candlesticks & Volume
                val candleCount = candles.size
                val candleSpacing = width / candleCount
                val candleBodyWidth = (candleSpacing * 0.65f).coerceAtLeast(3f)

                fun priceToY(price: Double): Float {
                    val normalized = ((maxPrice - price) / priceRange).toFloat()
                    return (normalized * chartHeight).coerceIn(0f, chartHeight)
                }

                candles.forEachIndexed { i, candle ->
                    val x = i * candleSpacing + (candleSpacing / 2f)
                    val isBullish = candle.close >= candle.open
                    val candleColor = if (isBullish) TxseGreen else TxseRed

                    val highY = priceToY(candle.high)
                    val lowY = priceToY(candle.low)
                    val openY = priceToY(candle.open)
                    val closeY = priceToY(candle.close)

                    // Draw Wick
                    drawLine(
                        color = candleColor,
                        start = Offset(x, highY),
                        end = Offset(x, lowY),
                        strokeWidth = 1.5f
                    )

                    // Draw Candle Body
                    val topY = minOf(openY, closeY)
                    val bodyHeight = maxOf(Math.abs(closeY - openY), 2f)

                    drawRect(
                        color = candleColor,
                        topLeft = Offset(x - candleBodyWidth / 2f, topY),
                        size = Size(candleBodyWidth, bodyHeight)
                    )

                    // Draw Volume Bar
                    val volHeight = (candle.volume.toFloat() / maxVolume) * volumeHeight
                    val volTop = height - volHeight
                    drawRect(
                        color = candleColor.copy(alpha = 0.35f),
                        topLeft = Offset(x - candleBodyWidth / 2f, volTop),
                        size = Size(candleBodyWidth, volHeight)
                    )
                }

                // 3. Draw Touch Crosshair if scrubber active
                selectedIndex?.let { idx ->
                    if (idx in candles.indices) {
                        val crossX = idx * candleSpacing + (candleSpacing / 2f)
                        val touchCandle = candles[idx]
                        val crossY = priceToY(touchCandle.close)

                        // Vertical guideline
                        drawLine(
                            color = TxseTextSecondary.copy(alpha = 0.7f),
                            start = Offset(crossX, 0f),
                            end = Offset(crossX, height),
                            strokeWidth = 1.2f
                        )
                        // Horizontal guideline
                        drawLine(
                            color = TxseTextSecondary.copy(alpha = 0.7f),
                            start = Offset(0f, crossY),
                            end = Offset(width, crossY),
                            strokeWidth = 1.2f
                        )
                        // Touch circle on price
                        drawCircle(
                            color = TxseBlueGlow,
                            radius = 4.5f,
                            center = Offset(crossX, crossY)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PortfolioPerformanceChart(
    points: List<Pair<Long, Double>>,
    modifier: Modifier = Modifier
) {
    if (points.isEmpty()) return

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(TxseDarkSurface)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            val minVal = points.minOf { it.second } * 0.995
            val maxVal = points.maxOf { it.second } * 1.005
            val range = if (maxVal > minVal) (maxVal - minVal).toFloat() else 1f

            val stepX = width / (points.size - 1).coerceAtLeast(1)

            val linePath = Path()
            val fillPath = Path()

            points.forEachIndexed { i, pt ->
                val x = i * stepX
                val normalizedY = ((maxVal - pt.second) / range).toFloat()
                val y = (normalizedY * (height * 0.85f)) + (height * 0.05f)

                if (i == 0) {
                    linePath.moveTo(x, y)
                    fillPath.moveTo(x, height)
                    fillPath.lineTo(x, y)
                } else {
                    linePath.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }

                if (i == points.size - 1) {
                    fillPath.lineTo(x, height)
                    fillPath.close()
                }
            }

            // Fill gradient below curve
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        TxseGreen.copy(alpha = 0.35f),
                        TxseGreen.copy(alpha = 0.05f),
                        Color.Transparent
                    )
                )
            )

            // Draw line curve
            drawPath(
                path = linePath,
                color = TxseGreen,
                style = Stroke(width = 2.5f)
            )

            // Draw final indicator dot
            val lastPt = points.last()
            val lastX = (points.size - 1) * stepX
            val lastY = (((maxVal - lastPt.second) / range).toFloat() * (height * 0.85f)) + (height * 0.05f)

            drawCircle(
                color = TxseGreen,
                radius = 5f,
                center = Offset(lastX, lastY)
            )
            drawCircle(
                color = Color.White,
                radius = 2.5f,
                center = Offset(lastX, lastY)
            )
        }
    }
}
