package com.example.model

enum class Sector(val displayName: String) {
    ALL("All"),
    ENERGY("Energy"),
    TECH("Tech"),
    FINANCE("Finance"),
    UTILITIES("Utilities"),
    REAL_ESTATE("Real Estate"),
    MATERIALS("Materials"),
    AEROSPACE("Aerospace")
}

data class Instrument(
    val symbol: String,
    val name: String,
    val sector: Sector,
    val price: Double,
    val change: Double,
    val changePercent: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val prevClose: Double,
    val volume: Long,
    val avgVolume: Long,
    val marketCap: Double, // in Billions USD
    val peRatio: Double,
    val dividendYield: Double,
    val exchangeTier: String = "TXSE Prime",
    val hqCity: String,
    val description: String,
    val isTop20: Boolean = true
)

enum class Timeframe(val label: String) {
    ONE_DAY("1D"),
    ONE_WEEK("1W"),
    ONE_MONTH("1M"),
    THREE_MONTHS("3M"),
    ONE_YEAR("1Y"),
    FIVE_YEARS("5Y")
}

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long
)

enum class OrderSide {
    BUY, SELL
}

enum class OrderType(val displayName: String) {
    LIMIT("Limit Order"),
    MARKET("Market Order"),
    STOP("Stop Order"),
    STOP_LIMIT("Stop-Limit")
}

enum class TimeInForce(val displayName: String) {
    DAY("Day Only"),
    GTC("Good 'Til Canceled (GTC)")
}

enum class OrderStatus(val displayName: String) {
    NEW("New"),
    ACCEPTED("Accepted"),
    PARTIALLY_FILLED("Partial Fill"),
    FILLED("Filled"),
    CANCELLED("Canceled"),
    REJECTED("Rejected")
}

data class Order(
    val id: String,
    val symbol: String,
    val side: OrderSide,
    val type: OrderType,
    val timeInForce: TimeInForce = TimeInForce.DAY,
    val price: Double,
    val stopPrice: Double? = null,
    val shares: Int,
    val filledShares: Int = 0,
    val status: OrderStatus = OrderStatus.NEW,
    val submittedAt: Long = System.currentTimeMillis(),
    val rejectionReason: String? = null
) {
    val remainingShares: Int get() = shares - filledShares
    val totalValue: Double get() = shares * price
}

data class Execution(
    val executionId: String,
    val orderId: String,
    val symbol: String,
    val side: OrderSide,
    val price: Double,
    val shares: Int,
    val fee: Double = 0.0,
    val executedAt: Long = System.currentTimeMillis()
)

data class RecentTrade(
    val id: String,
    val time: String,
    val price: Double,
    val size: Int,
    val isUptick: Boolean
)

data class BookLevel(
    val price: Double,
    val size: Int,
    val cumulativeSize: Int = 0
)

data class OrderBook(
    val symbol: String,
    val bids: List<BookLevel>,
    val asks: List<BookLevel>,
    val spread: Double,
    val spreadPercent: Double
)

data class Position(
    val symbol: String,
    val shares: Int,
    val avgPrice: Double,
    val currentPrice: Double
) {
    val marketValue: Double get() = shares * currentPrice
    val totalCost: Double get() = shares * avgPrice
    val unrealizedPl: Double get() = marketValue - totalCost
    val unrealizedPlPercent: Double get() = if (totalCost > 0) (unrealizedPl / totalCost) * 100.0 else 0.0
}

data class Portfolio(
    val totalValue: Double,
    val cashBalance: Double,
    val buyingPower: Double,
    val dayPl: Double,
    val dayPlPercent: Double,
    val positions: List<Position>
)

data class MarketIndex(
    val symbol: String,
    val name: String,
    val value: Double,
    val change: Double,
    val changePercent: Double
)

data class NewsItem(
    val id: String,
    val title: String,
    val source: String,
    val timeAgo: String,
    val category: String,
    val preview: String,
    val relatedSymbol: String? = null
)

data class ListingApplication(
    val id: String,
    val companyName: String,
    val proposedTicker: String,
    val sector: Sector,
    val capitalTarget: String,
    val sharesOffered: String,
    val underwriter: String,
    val status: String,
    val submissionDate: String
)
