package com.example.engine

import com.example.model.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MatchingEngine {
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    // Order books by symbol
    private val bidBooks = mutableMapOf<String, MutableList<Order>>()
    private val askBooks = mutableMapOf<String, MutableList<Order>>()
    
    // Trade logs
    private val executionHistory = mutableListOf<Execution>()
    private val recentTrades = mutableMapOf<String, MutableList<RecentTrade>>()

    // Pre-trade risk validation
    fun validateOrder(
        order: Order,
        cashBalance: Double,
        availableShares: Int
    ): Pair<Boolean, String?> {
        if (order.shares <= 0) {
            return Pair(false, "Invalid quantity: must be at least 1 share")
        }
        if (order.price <= 0.0 && order.type != OrderType.MARKET) {
            return Pair(false, "Invalid price: limit price must be greater than $0.00")
        }

        // Tick size check: standard $0.01 tick
        val priceInCents = Math.round(order.price * 100)
        if (Math.abs(order.price - priceInCents / 100.0) > 0.001) {
            return Pair(false, "Invalid tick size: minimum price increment is $0.01")
        }

        // Purchasing power check for Buy orders
        if (order.side == OrderSide.BUY) {
            val requiredCapital = order.shares * order.price
            if (requiredCapital > cashBalance) {
                return Pair(false, "Insufficient buying power: $%.2f required, $%.2f available".format(requiredCapital, cashBalance))
            }
        }

        // Holding check for Sell orders
        if (order.side == OrderSide.SELL) {
            if (order.shares > availableShares) {
                return Pair(false, "Insufficient position: $availableShares shares owned, ${order.shares} requested")
            }
        }

        return Pair(true, null)
    }

    // Process order through matching engine
    @Synchronized
    fun submitOrder(order: Order, currentMarketPrice: Double): Pair<Order, List<Execution>> {
        val fills = mutableListOf<Execution>()
        var workingOrder = order.copy(status = OrderStatus.ACCEPTED)

        val executionPrice = when (workingOrder.type) {
            OrderType.MARKET -> currentMarketPrice
            OrderType.LIMIT -> workingOrder.price
            OrderType.STOP, OrderType.STOP_LIMIT -> workingOrder.price
        }

        // Price-time matching logic:
        // In this simulated institutional exchange, Market & marketable Limit orders execute immediately against book liquidity
        val canFillImmediately = when (workingOrder.side) {
            OrderSide.BUY -> (workingOrder.type == OrderType.MARKET) || (workingOrder.price >= currentMarketPrice - 0.05)
            OrderSide.SELL -> (workingOrder.type == OrderType.MARKET) || (workingOrder.price <= currentMarketPrice + 0.05)
        }

        if (canFillImmediately) {
            // Fill order in full or in chunks
            val fillShares = workingOrder.shares
            val fillPrice = if (workingOrder.type == OrderType.MARKET) currentMarketPrice else workingOrder.price
            val execution = Execution(
                executionId = "TXSE-FILL-" + UUID.randomUUID().toString().take(8).uppercase(),
                orderId = workingOrder.id,
                symbol = workingOrder.symbol,
                side = workingOrder.side,
                price = fillPrice,
                shares = fillShares,
                fee = 0.0 // TXSE Zero Commission Initiative
            )
            fills.add(execution)
            executionHistory.add(0, execution)

            workingOrder = workingOrder.copy(
                filledShares = fillShares,
                status = OrderStatus.FILLED
            )

            // Record trade print in recent trades
            recordTrade(workingOrder.symbol, fillPrice, fillShares, isUptick = workingOrder.side == OrderSide.BUY)
        } else {
            // Resting Limit order placed on order book
            val list = if (workingOrder.side == OrderSide.BUY) {
                bidBooks.getOrPut(workingOrder.symbol) { mutableListOf() }
            } else {
                askBooks.getOrPut(workingOrder.symbol) { mutableListOf() }
            }
            list.add(workingOrder)
            // Sort price-time priority: bids descending by price, asks ascending
            if (workingOrder.side == OrderSide.BUY) {
                list.sortByDescending { it.price }
            } else {
                list.sortBy { it.price }
            }
        }

        return Pair(workingOrder, fills)
    }

    @Synchronized
    fun cancelOrder(orderId: String): Boolean {
        for ((_, bids) in bidBooks) {
            val found = bids.indexOfFirst { it.id == orderId }
            if (found >= 0) {
                bids.removeAt(found)
                return true
            }
        }
        for ((_, asks) in askBooks) {
            val found = asks.indexOfFirst { it.id == orderId }
            if (found >= 0) {
                asks.removeAt(found)
                return true
            }
        }
        return false
    }

    @Synchronized
    fun recordTrade(symbol: String, price: Double, size: Int, isUptick: Boolean) {
        val list = recentTrades.getOrPut(symbol) { mutableListOf() }
        val trade = RecentTrade(
            id = UUID.randomUUID().toString().take(6),
            time = timeFormat.format(Date()),
            price = price,
            size = size,
            isUptick = isUptick
        )
        list.add(0, trade)
        if (list.size > 50) {
            list.removeAt(list.size - 1)
        }
    }

    @Synchronized
    fun getRecentTrades(symbol: String): List<RecentTrade> {
        val list = recentTrades[symbol]
        if (list != null && list.isNotEmpty()) return list.toList()

        // Generate initial trade tape matching mockup
        val seed = mutableListOf<RecentTrade>()
        val baseTime = System.currentTimeMillis()
        val times = listOf("10:24:12", "10:24:11", "10:24:10", "10:24:08", "10:24:06", "10:24:04", "10:24:02", "10:24:01", "10:23:58", "10:23:56")
        val sizes = listOf(200, 500, 100, 300, 250, 400, 150, 600, 200, 350)
        val deltas = listOf(0.00, 0.02, -0.01, -0.02, -0.03, 0.00, 0.03, 0.01, -0.01, -0.02)
        val defaultPrice = 112.34

        for (i in times.indices) {
            val p = defaultPrice + deltas[i]
            seed.add(
                RecentTrade(
                    id = "T-$i",
                    time = times[i],
                    price = Math.round(p * 100) / 100.0,
                    size = sizes[i],
                    isUptick = deltas[i] >= 0
                )
            )
        }
        recentTrades[symbol] = seed
        return seed
    }

    // Generate Level 2 Depth Order Book
    fun generateOrderBook(symbol: String, marketPrice: Double): OrderBook {
        val spread = 0.04
        val bestBid = Math.round((marketPrice - 0.02) * 100) / 100.0
        val bestAsk = Math.round((marketPrice + 0.02) * 100) / 100.0

        val bids = mutableListOf<BookLevel>()
        var cumBid = 0
        val bidSizes = listOf(1200, 2500, 3200, 4800, 6200, 7500, 9100)
        for (i in bidSizes.indices) {
            val price = Math.round((bestBid - (i * 0.02)) * 100) / 100.0
            cumBid += bidSizes[i]
            bids.add(BookLevel(price = price, size = bidSizes[i], cumulativeSize = cumBid))
        }

        val asks = mutableListOf<BookLevel>()
        var cumAsk = 0
        val askSizes = listOf(1100, 2300, 4100, 3600, 5200, 6800, 8400)
        for (i in askSizes.indices) {
            val price = Math.round((bestAsk + (i * 0.02)) * 100) / 100.0
            cumAsk += askSizes[i]
            asks.add(BookLevel(price = price, size = askSizes[i], cumulativeSize = cumAsk))
        }

        return OrderBook(
            symbol = symbol,
            bids = bids,
            asks = asks,
            spread = spread,
            spreadPercent = (spread / marketPrice) * 100.0
        )
    }

    fun getAllExecutions(): List<Execution> = executionHistory.toList()
}
