package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.OrderSide
import com.example.ui.components.LoneStarBottomNav
import com.example.ui.components.LoneStarTopBar
import com.example.ui.screens.*
import com.example.ui.theme.TexasStockExchangeTheme
import com.example.ui.theme.TxseCardBg
import com.example.ui.theme.TxseNavy
import kotlinx.coroutines.launch

@Composable
fun TxseApp(
    viewModel: TxseViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val isProTerminal by viewModel.isProTerminal.collectAsState()
    val isMarketOpen by viewModel.isMarketOpen.collectAsState()
    val tradeMessage by viewModel.tradeMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(tradeMessage) {
        tradeMessage?.let { msg ->
            scope.launch {
                snackbarHostState.showSnackbar(
                    message = msg,
                    duration = SnackbarDuration.Short
                )
                viewModel.dismissTradeMessage()
            }
        }
    }

    TexasStockExchangeTheme {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (currentScreen != AppScreen.SPLASH && !isProTerminal) {
                    LoneStarTopBar(
                        isMarketOpen = isMarketOpen,
                        isProTerminal = isProTerminal,
                        onToggleTerminal = { viewModel.toggleProTerminal() },
                        onOpenSearch = { viewModel.navigateTo(AppScreen.MARKETS) }
                    )
                }
            },
            bottomBar = {
                if (currentScreen != AppScreen.SPLASH && !isProTerminal) {
                    LoneStarBottomNav(
                        currentTab = currentTab,
                        onTabSelected = { viewModel.selectTab(it) }
                    )
                }
            },
            containerColor = TxseNavy
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // If Pro Terminal mode is active
                if (isProTerminal) {
                    BackHandler { viewModel.toggleProTerminal() }
                    DesktopTerminalScreen(
                        viewModel = viewModel,
                        onCloseTerminal = { viewModel.toggleProTerminal() }
                    )
                } else {
                    when (currentScreen) {
                        AppScreen.SPLASH -> {
                            SplashScreen(
                                onLoginClick = { role -> viewModel.login(role) }
                            )
                        }

                        AppScreen.MARKETS -> {
                            MarketsScreen(
                                viewModel = viewModel,
                                onInstrumentClick = { viewModel.navigateTo(AppScreen.DETAIL) }
                            )
                        }

                        AppScreen.DETAIL -> {
                            BackHandler { viewModel.navigateTo(AppScreen.MARKETS) }
                            InstrumentDetailScreen(
                                viewModel = viewModel,
                                onBackClick = { viewModel.navigateTo(AppScreen.MARKETS) },
                                onTradeClick = { side ->
                                    viewModel.setOrderSide(side)
                                    viewModel.navigateTo(AppScreen.PLACE_ORDER)
                                }
                            )
                        }

                        AppScreen.PLACE_ORDER -> {
                            BackHandler { viewModel.navigateTo(AppScreen.DETAIL) }
                            PlaceOrderScreen(
                                viewModel = viewModel,
                                onBackClick = { viewModel.navigateTo(AppScreen.DETAIL) }
                            )
                        }

                        AppScreen.PORTFOLIO -> {
                            BackHandler { viewModel.selectTab(BottomNavTab.MARKETS) }
                            PortfolioScreen(
                                viewModel = viewModel,
                                onInstrumentClick = { viewModel.navigateTo(AppScreen.DETAIL) },
                                onViewOrdersClick = { viewModel.navigateTo(AppScreen.ORDERS) }
                            )
                        }

                        AppScreen.ORDERS -> {
                            BackHandler { viewModel.navigateTo(AppScreen.PORTFOLIO) }
                            OrdersBlotterScreen(
                                viewModel = viewModel,
                                onBackClick = { viewModel.navigateTo(AppScreen.PORTFOLIO) }
                            )
                        }

                        AppScreen.NEWS -> {
                            BackHandler { viewModel.navigateTo(AppScreen.PROFILE) }
                            NewsScreen(
                                onBackClick = { viewModel.navigateTo(AppScreen.PROFILE) },
                                onSelectSymbol = { sym ->
                                    viewModel.selectInstrument(sym)
                                    viewModel.navigateTo(AppScreen.DETAIL)
                                }
                            )
                        }

                        AppScreen.ADMIN_CONSOLE, AppScreen.ISSUER_PORTAL -> {
                            BackHandler { viewModel.navigateTo(AppScreen.PROFILE) }
                            AdminAndIssuerScreen(
                                viewModel = viewModel,
                                onBackClick = { viewModel.navigateTo(AppScreen.PROFILE) }
                            )
                        }

                        AppScreen.PROFILE -> {
                            BackHandler { viewModel.selectTab(BottomNavTab.MARKETS) }
                            AccountProfileScreen(
                                viewModel = viewModel,
                                onNavigate = { dest -> viewModel.navigateTo(dest) }
                            )
                        }

                        AppScreen.DESKTOP_TERMINAL -> {
                            BackHandler { viewModel.navigateTo(AppScreen.MARKETS) }
                            DesktopTerminalScreen(
                                viewModel = viewModel,
                                onCloseTerminal = { viewModel.navigateTo(AppScreen.MARKETS) }
                            )
                        }
                    }
                }
            }
        }
    }
}
