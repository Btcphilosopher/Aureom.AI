package com.example.engine

import com.example.model.*
import kotlin.random.Random

object MarketDataEngine {

    val initialInstruments: List<Instrument> = listOf(
        Instrument(
            symbol = "XOM",
            name = "Exxon Mobil Corporation",
            sector = Sector.ENERGY,
            price = 112.34,
            change = 2.18,
            changePercent = 1.98,
            open = 110.12,
            high = 113.06,
            low = 109.87,
            prevClose = 110.16,
            volume = 24800000L,
            avgVolume = 19200000L,
            marketCap = 442.8,
            peRatio = 12.6,
            dividendYield = 3.42,
            hqCity = "Spring, TX",
            description = "American multinational oil and gas corporation headquartered in Spring, Texas. Largest direct descendant of Rockefeller's Standard Oil."
        ),
        Instrument(
            symbol = "EOG",
            name = "EOG Resources",
            sector = Sector.ENERGY,
            price = 134.27,
            change = 3.62,
            changePercent = 2.77,
            open = 131.00,
            high = 134.85,
            low = 130.40,
            prevClose = 130.65,
            volume = 4320000L,
            avgVolume = 3800000L,
            marketCap = 76.5,
            peRatio = 9.8,
            dividendYield = 2.85,
            hqCity = "Houston, TX",
            description = "Leading Permian Basin and Eagle Ford shale exploration and production company based in Houston."
        ),
        Instrument(
            symbol = "CVX",
            name = "Chevron Corporation",
            sector = Sector.ENERGY,
            price = 156.90,
            change = 2.91,
            changePercent = 1.89,
            open = 154.20,
            high = 157.45,
            low = 153.80,
            prevClose = 153.99,
            volume = 7800000L,
            avgVolume = 6900000L,
            marketCap = 288.4,
            peRatio = 13.4,
            dividendYield = 4.12,
            hqCity = "Houston, TX",
            description = "Integrated global energy enterprise with significant Gulf Coast refining and Permian deep assets."
        ),
        Instrument(
            symbol = "TPL",
            name = "Texas Pacific Land",
            sector = Sector.REAL_ESTATE,
            price = 87.45,
            change = 1.23,
            changePercent = 1.43,
            open = 86.10,
            high = 88.00,
            low = 85.90,
            prevClose = 86.22,
            volume = 1250000L,
            avgVolume = 980000L,
            marketCap = 20.1,
            peRatio = 32.1,
            dividendYield = 1.15,
            hqCity = "Dallas, TX",
            description = "Historic landowner in West Texas managing extensive mineral royalties, water resources, and surface leases."
        ),
        Instrument(
            symbol = "FANG",
            name = "Diamondback Energy",
            sector = Sector.ENERGY,
            price = 162.18,
            change = 4.87,
            changePercent = 3.10,
            open = 158.00,
            high = 163.20,
            low = 157.50,
            prevClose = 157.31,
            volume = 3100000L,
            avgVolume = 2400000L,
            marketCap = 29.8,
            peRatio = 9.2,
            dividendYield = 4.60,
            hqCity = "Midland, TX",
            description = "Premier pure-play Midland & Delaware Basin Permian operator focused on horizontal shale drilling."
        ),
        Instrument(
            symbol = "CVE",
            name = "Cenovus Energy",
            sector = Sector.ENERGY,
            price = 78.32,
            change = 1.56,
            changePercent = 2.03,
            open = 76.90,
            high = 78.80,
            low = 76.40,
            prevClose = 76.76,
            volume = 5200000L,
            avgVolume = 4500000L,
            marketCap = 42.1,
            peRatio = 11.0,
            dividendYield = 2.30,
            hqCity = "Houston Hub, TX",
            description = "Integrated crude oil, oil sands, and Gulf Coast pipeline operator trading actively on TXSE."
        ),
        Instrument(
            symbol = "BHP",
            name = "BHP Group",
            sector = Sector.MATERIALS,
            price = 61.17,
            change = 0.92,
            changePercent = 1.53,
            open = 60.40,
            high = 61.50,
            low = 60.10,
            prevClose = 60.25,
            volume = 8400000L,
            avgVolume = 7200000L,
            marketCap = 154.6,
            peRatio = 11.8,
            dividendYield = 5.25,
            hqCity = "Houston, TX",
            description = "Global natural resources supplier with copper, iron ore, and industrial metallurgical operations."
        ),
        Instrument(
            symbol = "TXN",
            name = "Texas Instruments Inc.",
            sector = Sector.TECH,
            price = 178.22,
            change = 3.11,
            changePercent = 1.78,
            open = 175.50,
            high = 179.10,
            low = 174.80,
            prevClose = 175.11,
            volume = 6100000L,
            avgVolume = 5400000L,
            marketCap = 162.4,
            peRatio = 27.4,
            dividendYield = 3.02,
            hqCity = "Dallas, TX",
            description = "Semiconductor pioneer headquartered in Dallas, world leader in analog chips and embedded processors."
        ),
        Instrument(
            symbol = "AMD",
            name = "Advanced Micro Devices",
            sector = Sector.TECH,
            price = 142.66,
            change = 2.87,
            changePercent = 2.05,
            open = 140.10,
            high = 143.40,
            low = 139.50,
            prevClose = 139.79,
            volume = 48500000L,
            avgVolume = 42000000L,
            marketCap = 231.0,
            peRatio = 45.2,
            dividendYield = 0.00,
            hqCity = "Austin, TX",
            description = "High-performance computing, data center GPUs, and AI accelerators with flagship design campus in Austin."
        ),
        Instrument(
            symbol = "AAPL",
            name = "Apple Inc. (TXSE Tier)",
            sector = Sector.TECH,
            price = 189.34,
            change = 2.14,
            changePercent = 1.14,
            open = 187.60,
            high = 190.20,
            low = 187.00,
            prevClose = 187.20,
            volume = 52000000L,
            avgVolume = 48000000L,
            marketCap = 2910.0,
            peRatio = 31.0,
            dividendYield = 0.52,
            hqCity = "Austin Campus, TX",
            description = "Global technology consumer hardware and services leader with massive 133-acre campus in Austin, Texas."
        ),
        Instrument(
            symbol = "XLE",
            name = "Energy Select SPDR",
            sector = Sector.ENERGY,
            price = 92.45,
            change = 1.60,
            changePercent = 1.76,
            open = 91.00,
            high = 92.80,
            low = 90.75,
            prevClose = 90.85,
            volume = 16200000L,
            avgVolume = 14100000L,
            marketCap = 38.5,
            peRatio = 12.1,
            dividendYield = 3.25,
            hqCity = "Exchange Index",
            description = "Benchmark exchange-traded fund tracking the largest US energy companies heavily weighted to Texas."
        ),
        Instrument(
            symbol = "OXY",
            name = "Occidental Petroleum",
            sector = Sector.ENERGY,
            price = 62.80,
            change = 1.45,
            changePercent = 2.36,
            open = 61.50,
            high = 63.10,
            low = 61.20,
            prevClose = 61.35,
            volume = 9800000L,
            avgVolume = 8500000L,
            marketCap = 56.4,
            peRatio = 14.2,
            dividendYield = 1.40,
            hqCity = "Houston, TX",
            description = "Leading hydrocarbon exploration and direct air carbon capture technology pioneer headquartered in Houston."
        ),
        Instrument(
            symbol = "COP",
            name = "ConocoPhillips",
            sector = Sector.ENERGY,
            price = 118.50,
            change = 2.30,
            changePercent = 1.98,
            open = 116.40,
            high = 119.10,
            low = 115.80,
            prevClose = 116.20,
            volume = 6400000L,
            avgVolume = 5900000L,
            marketCap = 138.2,
            peRatio = 12.8,
            dividendYield = 3.10,
            hqCity = "Houston, TX",
            description = "Independent exploration and production giant with key operations across the Lower 48 and Alaska."
        ),
        Instrument(
            symbol = "VLO",
            name = "Valero Energy Corporation",
            sector = Sector.ENERGY,
            price = 148.90,
            change = 3.20,
            changePercent = 2.20,
            open = 146.10,
            high = 149.50,
            low = 145.50,
            prevClose = 145.70,
            volume = 3800000L,
            avgVolume = 3200000L,
            marketCap = 49.3,
            peRatio = 8.5,
            dividendYield = 2.90,
            hqCity = "San Antonio, TX",
            description = "World's largest independent petroleum refiner and renewable fuels producer, based in San Antonio."
        ),
        Instrument(
            symbol = "CRWD",
            name = "CrowdStrike Holdings",
            sector = Sector.TECH,
            price = 312.40,
            change = 6.80,
            changePercent = 2.22,
            open = 306.00,
            high = 314.50,
            low = 305.20,
            prevClose = 305.60,
            volume = 4100000L,
            avgVolume = 3600000L,
            marketCap = 74.8,
            peRatio = 72.0,
            dividendYield = 0.00,
            hqCity = "Austin, TX",
            description = "Cloud-delivered endpoint protection and cybersecurity leader headquartered in Austin, Texas."
        )
    )

    val marketIndices: List<MarketIndex> = listOf(
        MarketIndex("TXSE", "TXSE Composite", 4892.40, 68.32, 1.41),
        MarketIndex("TX100", "TXSE 100 Flagship", 1940.12, 34.18, 1.79),
        MarketIndex("WTI", "WTI Crude Oil", 82.40, 1.72, 2.13),
        MarketIndex("NG", "Henry Hub Natural Gas", 2.85, 0.02, 0.81),
        MarketIndex("SPX", "S&P 500 Ref", 5782.10, 42.15, 0.73)
    )

    val newsItems: List<NewsItem> = listOf(
        NewsItem(
            id = "N-1",
            title = "Texas Energy Stocks Rally on Strong Global Crude Demand & Refinery Utilization",
            source = "TXSE Markets Desk",
            timeAgo = "2h ago",
            category = "Energy",
            preview = "Permian Basin output reaches fresh monthly high as Gulf Coast export terminals report record crude liftings for overseas markets.",
            relatedSymbol = "XOM"
        ),
        NewsItem(
            id = "N-2",
            title = "Exxon Mobil Reports Q1 Earnings Beat Driven by Deepwater Guyana & Permian Growth",
            source = "Securities Wire",
            timeAgo = "3h ago",
            category = "Earnings",
            preview = "Net operating cash flow surges past expectations; company increases quarterly dividend and reaffirms capital distribution program.",
            relatedSymbol = "XOM"
        ),
        NewsItem(
            id = "N-3",
            title = "Texas Leads U.S. in Renewable Energy Investment with $38B Solar and Wind Pipeline",
            source = "Austin Chronicle Business",
            timeAgo = "5h ago",
            category = "Infrastructure",
            preview = "ERCOT grid stability boosted by new battery storage installations and massive grid-scale solar farms across West and South Texas.",
            relatedSymbol = "EOG"
        ),
        NewsItem(
            id = "N-4",
            title = "Semiconductor Corridor Expands as Advanced Packaging Facilities Break Ground in Sherman",
            source = "Dallas Business Journal",
            timeAgo = "7h ago",
            category = "Tech",
            preview = "Texas Instruments and supplier network commit $11B in new cleanrooms, creating 4,500 advanced manufacturing jobs.",
            relatedSymbol = "TXN"
        ),
        NewsItem(
            id = "N-5",
            title = "TXSE Proposes Low-Fee Listing Framework to Attract S&P 500 Dual Listings",
            source = "Exchange Regulatory Feed",
            timeAgo = "10h ago",
            category = "Exchange",
            preview = "The Texas Stock Exchange announces transparent issuer fee schedules, zero listing transfer friction, and state-of-the-art co-location.",
            relatedSymbol = null
        )
    )

    // Generate realistic Candlestick series
    fun generateCandles(symbol: String, timeframe: Timeframe, basePrice: Double): List<Candle> {
        val count = when (timeframe) {
            Timeframe.ONE_DAY -> 30      // 30 15-min intraday bars
            Timeframe.ONE_WEEK -> 35     // 35 hourly bars
            Timeframe.ONE_MONTH -> 30    // 30 daily bars
            Timeframe.THREE_MONTHS -> 45 // 45 2-day bars
            Timeframe.ONE_YEAR -> 52     // 52 weekly bars
            Timeframe.FIVE_YEARS -> 60   // 60 monthly bars
        }

        val candles = mutableListOf<Candle>()
        var currentPrice = basePrice * (if (timeframe == Timeframe.ONE_DAY) 0.985 else 0.88)
        val random = Random(symbol.hashCode() + timeframe.ordinal * 31)

        val now = System.currentTimeMillis()
        val interval = when (timeframe) {
            Timeframe.ONE_DAY -> 15 * 60 * 1000L
            Timeframe.ONE_WEEK -> 60 * 60 * 1000L
            Timeframe.ONE_MONTH -> 24 * 60 * 60 * 1000L
            Timeframe.THREE_MONTHS -> 2 * 24 * 60 * 60 * 1000L
            Timeframe.ONE_YEAR -> 7 * 24 * 60 * 60 * 1000L
            Timeframe.FIVE_YEARS -> 30 * 24 * 60 * 60 * 1000L
        }

        for (i in 0 until count) {
            val stepTime = now - (count - 1 - i) * interval
            // Bullish bias with realistic volatility
            val changeFactor = (random.nextDouble() - 0.46) * (basePrice * 0.015)
            val open = currentPrice
            var close = open + changeFactor
            if (i == count - 1) {
                close = basePrice // Pin the last bar close to the exact live market price!
            }
            val high = maxOf(open, close) + random.nextDouble() * (basePrice * 0.008)
            val low = minOf(open, close) - random.nextDouble() * (basePrice * 0.008)
            val volume = (random.nextLong(150000L, 1200000L))

            candles.add(
                Candle(
                    timestamp = stepTime,
                    open = Math.round(open * 100) / 100.0,
                    high = Math.round(high * 100) / 100.0,
                    low = Math.round(low * 100) / 100.0,
                    close = Math.round(close * 100) / 100.0,
                    volume = volume
                )
            )
            currentPrice = close
        }

        return candles
    }

    // Generate Portfolio Historical Performance Curve
    fun generatePortfolioHistory(currentValue: Double, timeframe: Timeframe): List<Pair<Long, Double>> {
        val points = 25
        val list = mutableListOf<Pair<Long, Double>>()
        val random = Random(42 + timeframe.ordinal)
        val now = System.currentTimeMillis()
        val interval = 3600000L * 24

        var runningVal = currentValue * 0.92
        for (i in 0 until points) {
            val time = now - (points - 1 - i) * interval
            val drift = (random.nextDouble() - 0.45) * 1400.0
            runningVal += drift
            if (i == points - 1) {
                runningVal = currentValue
            }
            list.add(Pair(time, runningVal))
        }
        return list
    }
}
