package com.example

import com.example.data.TxseRepository
import com.example.engine.MatchingEngine
import com.example.model.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class TxseExchangeTest {

    private lateinit var matchingEngine: MatchingEngine
    private lateinit var repository: TxseRepository

    @Before
    fun setUp() {
        matchingEngine = MatchingEngine()
        repository = TxseRepository(matchingEngine)
    }

    @Test
    fun testPreTradeRiskValidation() {
        val buyOrder = Order(
            id = "ORD-001",
            symbol = "XOM",
            side = OrderSide.BUY,
            type = OrderType.LIMIT,
            price = 112.34,
            shares = 100
        )
        // Sufficient funds ($99,658 available)
        val (valid, error) = matchingEngine.validateOrder(buyOrder, cashBalance = 99658.0, availableShares = 0)
        assertTrue(valid)
        assertNull(error)

        // Insufficient funds
        val (invalid, err) = matchingEngine.validateOrder(buyOrder, cashBalance = 100.0, availableShares = 0)
        assertFalse(invalid)
        assertNotNull(err)
    }

    @Test
    fun testSellOrderHoldingValidation() {
        val sellOrder = Order(
            id = "ORD-002",
            symbol = "EOG",
            side = OrderSide.SELL,
            type = OrderType.LIMIT,
            price = 134.27,
            shares = 50
        )
        // User has 100 shares -> valid
        val (valid, _) = matchingEngine.validateOrder(sellOrder, cashBalance = 5000.0, availableShares = 100)
        assertTrue(valid)

        // User has only 20 shares -> invalid oversell
        val (invalid, err) = matchingEngine.validateOrder(sellOrder, cashBalance = 5000.0, availableShares = 20)
        assertFalse(invalid)
        assertTrue(err?.contains("Insufficient position") == true)
    }

    @Test
    fun testMarketOrderImmediateFill() {
        val order = Order(
            id = "ORD-003",
            symbol = "XOM",
            side = OrderSide.BUY,
            type = OrderType.MARKET,
            price = 0.0,
            shares = 25
        )
        val (processed, fills) = matchingEngine.submitOrder(order, currentMarketPrice = 112.34)
        assertEquals(OrderStatus.FILLED, processed.status)
        assertEquals(1, fills.size)
        assertEquals(25, fills[0].shares)
        assertEquals(112.34, fills[0].price, 0.001)
    }

    @Test
    fun testOrderPlacementAndLedgerUpdateInRepository() {
        val initialCash = repository.cashBalance.value
        val order = Order(
            id = "ORD-004",
            symbol = "XOM",
            side = OrderSide.BUY,
            type = OrderType.MARKET,
            price = 112.00,
            shares = 10
        )
        val (success, msg) = repository.placeOrder(order)
        assertTrue(success)
        assertTrue(msg.contains("successfully Filled"))

        // Cash should be deducted by 10 * 112.00 = 1120.00
        val expectedCash = initialCash - (10 * 112.34) // current market price for XOM
        assertEquals(expectedCash, repository.cashBalance.value, 1.0)
    }

    @Test
    fun testOrderBookGeneration() {
        val book = matchingEngine.generateOrderBook("CVX", 156.90)
        assertEquals("CVX", book.symbol)
        assertTrue(book.bids.isNotEmpty())
        assertTrue(book.asks.isNotEmpty())
        assertTrue(book.asks[0].price > book.bids[0].price)
        assertEquals(0.04, book.spread, 0.001)
    }
}
