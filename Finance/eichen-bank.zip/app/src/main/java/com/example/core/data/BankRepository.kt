package com.example.core.data

import com.example.core.model.*
import com.example.core.util.GermanFormatter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class BankRepository private constructor() {

  private val _accounts = MutableStateFlow<List<Account>>(DemoDataProvider.createInitialAccounts())
  val accounts: StateFlow<List<Account>> = _accounts.asStateFlow()

  private val _transactions = MutableStateFlow<List<TransactionItem>>(DemoDataProvider.createInitialTransactions())
  val transactions: StateFlow<List<TransactionItem>> = _transactions.asStateFlow()

  private val _cards = MutableStateFlow<List<CardItem>>(DemoDataProvider.createInitialCards())
  val cards: StateFlow<List<CardItem>> = _cards.asStateFlow()

  private val _savingsGoals = MutableStateFlow<List<SavingsGoal>>(DemoDataProvider.createInitialSavingsGoals())
  val savingsGoals: StateFlow<List<SavingsGoal>> = _savingsGoals.asStateFlow()

  private val _beneficiaries = MutableStateFlow<List<Beneficiary>>(DemoDataProvider.createInitialBeneficiaries())
  val beneficiaries: StateFlow<List<Beneficiary>> = _beneficiaries.asStateFlow()

  private val _standingOrders = MutableStateFlow<List<StandingOrder>>(DemoDataProvider.createInitialStandingOrders())
  val standingOrders: StateFlow<List<StandingOrder>> = _standingOrders.asStateFlow()

  private val _notifications = MutableStateFlow<List<NotificationItem>>(DemoDataProvider.createInitialNotifications())
  val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

  private val _userProfile = MutableStateFlow(UserProfile())
  val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

  companion object {
    @Volatile
    private var instance: BankRepository? = null

    fun getInstance(): BankRepository {
      return instance ?: synchronized(this) {
        instance ?: BankRepository().also { instance = it }
      }
    }
  }

  fun togglePrivacyMask() {
    _userProfile.value = _userProfile.value.copy(
      privacyMask = !_userProfile.value.privacyMask
    )
  }

  fun toggleLanguage() {
    val current = _userProfile.value.language
    val newLang = if (current == "de") "en" else "de"
    _userProfile.value = _userProfile.value.copy(language = newLang)
  }

  fun resetToDemoData() {
    _accounts.value = DemoDataProvider.createInitialAccounts()
    _transactions.value = DemoDataProvider.createInitialTransactions()
    _cards.value = DemoDataProvider.createInitialCards()
    _savingsGoals.value = DemoDataProvider.createInitialSavingsGoals()
    _beneficiaries.value = DemoDataProvider.createInitialBeneficiaries()
    _standingOrders.value = DemoDataProvider.createInitialStandingOrders()
    _notifications.value = DemoDataProvider.createInitialNotifications()
    _userProfile.value = UserProfile()
  }

  /**
   * Executes a SEPA transfer from source account with authoritative ledger update and ISO Modulo 97 validation.
   */
  fun executeSepaTransfer(
    recipientName: String,
    recipientIban: String,
    amountCents: Long,
    reference: String,
    isInstant: Boolean,
    sourceAccountId: String = "acc_hauptkonto"
  ): Result<TransactionItem> {
    if (amountCents <= 0) {
      return Result.failure(IllegalArgumentException("Der Überweisungsbetrag muss größer als 0,00 € sein."))
    }

    val ibanValidation = GermanFormatter.validateGermanIban(recipientIban)
    if (!ibanValidation.isValid) {
      return Result.failure(IllegalArgumentException(ibanValidation.errorMessage ?: "Ungültige IBAN."))
    }

    val currentAccounts = _accounts.value
    val sourceAccount = currentAccounts.find { it.id == sourceAccountId }
      ?: return Result.failure(IllegalStateException("Quellkonto nicht gefunden."))

    if (sourceAccount.availableBalanceCents < amountCents) {
      return Result.failure(IllegalStateException("Nicht genügend Guthaben verfügbar. Verfügbar: ${GermanFormatter.formatEuro(sourceAccount.availableBalanceCents)}"))
    }

    // Ledger update: Debit source account
    val updatedAccounts = currentAccounts.map { acc ->
      if (acc.id == sourceAccountId) {
        acc.copy(
          balanceCents = acc.balanceCents - amountCents,
          availableBalanceCents = acc.availableBalanceCents - amountCents
        )
      } else {
        acc
      }
    }
    _accounts.value = updatedAccounts

    // Create authoritative booked transaction
    val txReference = "TX-SEPA-" + UUID.randomUUID().toString().take(8).uppercase()
    val newTransaction = TransactionItem(
      id = "tx_${System.currentTimeMillis()}",
      accountId = sourceAccountId,
      title = recipientName,
      subtitle = if (isInstant) "SEPA-Echtzeitüberweisung" else "SEPA-Überweisung",
      counterpartyName = recipientName,
      counterpartyIban = recipientIban,
      amountCents = -amountCents,
      timestamp = System.currentTimeMillis(),
      category = TransactionCategory.FREIZEIT,
      status = TransactionStatus.BOOKED,
      paymentType = if (isInstant) PaymentType.SEPA_INSTANT else PaymentType.SEPA_CREDIT,
      reference = reference.ifBlank { "Überweisung" },
      receiptCode = txReference
    )

    _transactions.value = listOf(newTransaction) + _transactions.value

    // Add push notification
    val newNotification = NotificationItem(
      id = "notif_${System.currentTimeMillis()}",
      title = if (isInstant) "Echtzeit-Überweisung gesendet" else "Überweisung ausgeführt",
      message = "${GermanFormatter.formatEuro(amountCents)} an $recipientName erfolgreich übermittelt.",
      timestamp = System.currentTimeMillis(),
      category = NotificationCategory.TRANSACTION,
      isRead = false
    )
    _notifications.value = listOf(newNotification) + _notifications.value

    return Result.success(newTransaction)
  }

  fun toggleCardFreeze(cardId: String) {
    _cards.value = _cards.value.map { card ->
      if (card.id == cardId) {
        val nextState = !card.isFrozen
        card.copy(isFrozen = nextState)
      } else card
    }
  }

  fun toggleCardOnline(cardId: String) {
    _cards.value = _cards.value.map { card ->
      if (card.id == cardId) card.copy(onlineEnabled = !card.onlineEnabled) else card
    }
  }

  fun toggleCardContactless(cardId: String) {
    _cards.value = _cards.value.map { card ->
      if (card.id == cardId) card.copy(contactlessEnabled = !card.contactlessEnabled) else card
    }
  }

  fun toggleCardAtm(cardId: String) {
    _cards.value = _cards.value.map { card ->
      if (card.id == cardId) card.copy(atmEnabled = !card.atmEnabled) else card
    }
  }

  fun updateCardLimit(cardId: String, newLimitCents: Long) {
    _cards.value = _cards.value.map { card ->
      if (card.id == cardId) card.copy(monthlyLimitCents = newLimitCents) else card
    }
  }

  fun createSavingsGoal(
    title: String,
    targetAmountCents: Long,
    targetDate: String,
    monthlyContributionCents: Long,
    categoryTag: String
  ) {
    val newGoal = SavingsGoal(
      id = "goal_${System.currentTimeMillis()}",
      title = title,
      targetAmountCents = targetAmountCents,
      currentAmountCents = 0L,
      targetDate = targetDate,
      monthlyContributionCents = monthlyContributionCents,
      categoryTag = categoryTag
    )
    _savingsGoals.value = _savingsGoals.value + newGoal
  }

  fun depositToSavingsGoal(goalId: String, amountCents: Long): Result<Unit> {
    val primaryAccount = _accounts.value.find { it.isPrimary }
      ?: return Result.failure(IllegalStateException("Hauptkonto nicht gefunden"))

    if (primaryAccount.availableBalanceCents < amountCents) {
      return Result.failure(IllegalStateException("Nicht genügend Guthaben auf dem Hauptkonto."))
    }

    // Debit primary account
    _accounts.value = _accounts.value.map { acc ->
      if (acc.isPrimary) {
        acc.copy(
          balanceCents = acc.balanceCents - amountCents,
          availableBalanceCents = acc.availableBalanceCents - amountCents
        )
      } else acc
    }

    // Credit goal
    _savingsGoals.value = _savingsGoals.value.map { goal ->
      if (goal.id == goalId) {
        goal.copy(currentAmountCents = goal.currentAmountCents + amountCents)
      } else goal
    }

    return Result.success(Unit)
  }

  fun withdrawFromSavingsGoal(goalId: String, amountCents: Long): Result<Unit> {
    val targetGoal = _savingsGoals.value.find { it.id == goalId }
      ?: return Result.failure(IllegalStateException("Sparziel nicht gefunden"))

    if (targetGoal.currentAmountCents < amountCents) {
      return Result.failure(IllegalStateException("Im Sparziel ist nicht genügend Guthaben."))
    }

    // Credit primary account
    _accounts.value = _accounts.value.map { acc ->
      if (acc.isPrimary) {
        acc.copy(
          balanceCents = acc.balanceCents + amountCents,
          availableBalanceCents = acc.availableBalanceCents + amountCents
        )
      } else acc
    }

    // Debit goal
    _savingsGoals.value = _savingsGoals.value.map { goal ->
      if (goal.id == goalId) {
        goal.copy(currentAmountCents = goal.currentAmountCents - amountCents)
      } else goal
    }

    return Result.success(Unit)
  }

  fun markNotificationRead(notificationId: String) {
    _notifications.value = _notifications.value.map {
      if (it.id == notificationId) it.copy(isRead = true) else it
    }
  }

  fun addBeneficiary(name: String, iban: String, category: String) {
    val initials = name.split(" ")
      .mapNotNull { it.firstOrNull()?.toString() }
      .take(2)
      .joinToString("")
      .uppercase()

    val newBeneficiary = Beneficiary(
      id = "ben_${System.currentTimeMillis()}",
      name = name,
      iban = GermanFormatter.formatIban(iban),
      bic = "EICHDEFFXXX",
      category = category.ifBlank { "Empfänger" },
      initials = initials.ifBlank { "EM" }
    )
    _beneficiaries.value = _beneficiaries.value + newBeneficiary
  }
}
