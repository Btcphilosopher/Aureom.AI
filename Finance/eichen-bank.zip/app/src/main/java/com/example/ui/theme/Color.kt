package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Eichen Bank Luxury German Fintech Palette
val EichenForestGreen = Color(0xFF1E5E41)
val EichenForestGreenDark = Color(0xFF144630)
val EichenForestGreenLight = Color(0xFF2C7D58)
val EichenForestGreenContainer = Color(0xFFE3F3EB)
val EichenOnForestGreenContainer = Color(0xFF093321)

val EichenGraphite = Color(0xFF111215)
val EichenDarkNavy = Color(0xFF181A20)
val EichenCardSurface = Color(0xFF1F222A)

val EichenBackground = Color(0xFFF8F9FA)
val EichenSurface = Color(0xFFFFFFFF)
val EichenSurfaceVariant = Color(0xFFF1F3F5)
val EichenBorder = Color(0xFFE5E7EB)

val EichenTextPrimary = Color(0xFF111215)
val EichenTextSecondary = Color(0xFF6B7280)
val EichenTextTertiary = Color(0xFF9CA3AF)

// Accents & Financial Status
val EichenPositive = Color(0xFF059669) // Emerald Mint for incoming funds & positive delta
val EichenPositiveContainer = Color(0xFFECFDF5)
val EichenNegative = Color(0xFFDC2626) // German Red for outgoing funds & alerts
val EichenNegativeContainer = Color(0xFFFEF2F2)
val EichenPending = Color(0xFFD97706) // Amber for pending
val EichenPendingContainer = Color(0xFFFFFBEB)

// German Flag Micro-Accent Capsule
val FlagBlack = Color(0xFF18191C)
val FlagRed = Color(0xFFDC2626)
val FlagGold = Color(0xFFF59E0B)
