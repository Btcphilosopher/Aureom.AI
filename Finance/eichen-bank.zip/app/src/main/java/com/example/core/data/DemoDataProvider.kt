package com.example.core.data

import com.example.core.model.*

object DemoDataProvider {

  val primaryIban = "DE89 3704 0044 0532 0130 00"
  val savingsIban = "DE62 3704 0044 0532 0130 01"
  val depotIban = "DE35 3704 0044 0532 0130 02"

  fun createInitialAccounts(): List<Account> {
    return listOf(
      Account(
        id = "acc_hauptkonto",
        name = "Hauptkonto",
        iban = primaryIban,
        bic = "EICHDEFFXXX",
        type = AccountType.GIRO,
        balanceCents = 841220L, // 8.412,20 €
        availableBalanceCents = 838788L, // 8.387,88 € (minus 24,32 € pending hold)
        pendingHoldsCents = 2432L,
        isPrimary = true
      ),
      Account(
        id = "acc_flex_sparen",
        name = "Flex-Sparen",
        iban = savingsIban,
        bic = "EICHDEFFXXX",
        type = AccountType.FLEX_SPAREN,
        balanceCents = 350000L, // 3.500,00 € (3,25 % p.a. Zins)
        availableBalanceCents = 350000L,
        pendingHoldsCents = 0L,
        isPrimary = false
      ),
      Account(
        id = "acc_depot",
        name = "Zukunfts-Depot",
        iban = depotIban,
        bic = "EICHDEFFXXX",
        type = AccountType.DEPOT,
        balanceCents = 57016L, // 570,16 €
        availableBalanceCents = 57016L,
        pendingHoldsCents = 0L,
        isPrimary = false
      )
    )
  }

  fun createInitialTransactions(): List<TransactionItem> {
    val now = System.currentTimeMillis()
    val hour = 3600 * 1000L
    val day = 24 * hour

    return listOf(
      TransactionItem(
        id = "tx_01",
        accountId = "acc_hauptkonto",
        title = "REWE Markt GmbH",
        subtitle = "Filiale Frankfurt Kaiserstraße",
        counterpartyName = "REWE Markt GmbH",
        counterpartyIban = "DE67 5005 0201 1234 5678 90",
        amountCents = -2432L, // -24,32 €
        timestamp = now - 2 * hour,
        category = TransactionCategory.EINKAUFEN,
        status = TransactionStatus.PENDING,
        paymentType = PaymentType.CARD_PURCHASE,
        reference = "Kartenzahlung Debitkarte •• 4892",
        receiptCode = "REWE-FR-88914"
      ),
      TransactionItem(
        id = "tx_02",
        accountId = "acc_hauptkonto",
        title = "BMW Group AG",
        subtitle = "Gehaltsabrechnung Oktober 2026",
        counterpartyName = "BMW Group AG",
        counterpartyIban = "DE40 7002 0270 0012 3456 78",
        amountCents = 285000L, // +2.850,00 €
        timestamp = now - day,
        category = TransactionCategory.GEHALT,
        status = TransactionStatus.BOOKED,
        paymentType = PaymentType.SEPA_CREDIT,
        reference = "Gehalt 10/2026 Maximilian Eichenberg",
        receiptCode = "SEPA-BMW-98210"
      ),
      TransactionItem(
        id = "tx_03",
        accountId = "acc_hauptkonto",
        title = "Deutsche Bahn AG",
        subtitle = "ICE Fahrkarte Frankfurt - Berlin",
        counterpartyName = "DB Fernverkehr AG",
        counterpartyIban = "DE29 1001 0010 0987 6543 21",
        amountCents = -7990L, // -79,90 €
        timestamp = now - 2 * day,
        category = TransactionCategory.TRANSPORT,
        status = TransactionStatus.BOOKED,
        paymentType = PaymentType.CARD_PURCHASE,
        reference = "Online Buchung bahn.de Auftr. 9841",
        receiptCode = "DB-9841-TK"
      ),
      TransactionItem(
        id = "tx_04",
        accountId = "acc_hauptkonto",
        title = "Alnatura Bio-Supermarkt",
        subtitle = "Bio-Lebensmittel",
        counterpartyName = "Alnatura Produktions- und Handels GmbH",
        counterpartyIban = "DE41 5001 0517 0123 4567 89",
        amountCents = -3845L, // -38,45 €
        timestamp = now - 3 * day,
        category = TransactionCategory.EINKAUFEN,
        status = TransactionStatus.BOOKED,
        paymentType = PaymentType.CARD_PURCHASE,
        reference = "Kartenzahlung kontaktlos Apple/Google Pay",
        receiptCode = "ALN-2026-11"
      ),
      TransactionItem(
        id = "tx_05",
        accountId = "acc_hauptkonto",
        title = "Sarah Schmidt",
        subtitle = "SEPA-Echtzeitüberweisung",
        counterpartyName = "Sarah Schmidt",
        counterpartyIban = "DE43 5001 0517 5544 3322 11",
        amountCents = 4500L, // +45,00 €
        timestamp = now - 4 * day,
        category = TransactionCategory.FREIZEIT,
        status = TransactionStatus.BOOKED,
        paymentType = PaymentType.SEPA_INSTANT,
        reference = "Konzertkarten & Abendessen gestern",
        receiptCode = "SEPA-INST-881"
      ),
      TransactionItem(
        id = "tx_06",
        accountId = "acc_hauptkonto",
        title = "Hausverwaltung Taunusanlage",
        subtitle = "Monatsmiete Wohnung",
        counterpartyName = "Immobilien Taunus KG",
        counterpartyIban = "DE13 5005 0000 0011 2233 44",
        amountCents = -115000L, // -1.150,00 €
        timestamp = now - 7 * day,
        category = TransactionCategory.WOHNEN,
        status = TransactionStatus.BOOKED,
        paymentType = PaymentType.SEPA_CREDIT,
        reference = "Miete Wohnung 4.OG Taunusanlage 8",
        receiptCode = "DA-MIETE-2026"
      ),
      TransactionItem(
        id = "tx_07",
        accountId = "acc_hauptkonto",
        title = "Spotify AB",
        subtitle = "Monatliches Familien-Abo",
        counterpartyName = "Spotify AB",
        counterpartyIban = "DE09 1007 0000 0555 4443 33",
        amountCents = -1499L, // -14,99 €
        timestamp = now - 10 * day,
        category = TransactionCategory.ABO,
        status = TransactionStatus.BOOKED,
        paymentType = PaymentType.CARD_PURCHASE,
        reference = "Spotify Premium Recurring",
        receiptCode = "SPOT-REC-99"
      )
    )
  }

  fun createInitialCards(): List<CardItem> {
    return listOf(
      CardItem(
        id = "card_physical_01",
        accountId = "acc_hauptkonto",
        cardholderName = "MAXIMILIAN EICHENBERG",
        maskedNumber = "•••• •••• •••• 4892",
        last4 = "4892",
        expiryDate = "08/29",
        cardType = CardType.PHYSICAL,
        isFrozen = false,
        onlineEnabled = true,
        contactlessEnabled = true,
        atmEnabled = true,
        monthlyLimitCents = 350000L, // 3.500,00 € Limit
        dailySpentCents = 2432L,
        pinCode = "4820",
        cvv = "834",
        inGoogleWallet = true
      ),
      CardItem(
        id = "card_virtual_01",
        accountId = "acc_hauptkonto",
        cardholderName = "MAXIMILIAN EICHENBERG",
        maskedNumber = "•••• •••• •••• 7109",
        last4 = "7109",
        expiryDate = "11/27",
        cardType = CardType.VIRTUAL,
        isFrozen = false,
        onlineEnabled = true,
        contactlessEnabled = true,
        atmEnabled = false,
        monthlyLimitCents = 100000L, // 1.000,00 € Limit
        dailySpentCents = 0L,
        pinCode = "1923",
        cvv = "419",
        inGoogleWallet = true
      )
    )
  }

  fun createInitialSavingsGoals(): List<SavingsGoal> {
    return listOf(
      SavingsGoal(
        id = "goal_01",
        title = "Notgroschen (3 Monatsausgaben)",
        targetAmountCents = 500000L, // 5.000,00 €
        currentAmountCents = 320000L, // 3.200,00 €
        targetDate = "31.12.2026",
        monthlyContributionCents = 30000L,
        categoryTag = "Sicherheit"
      ),
      SavingsGoal(
        id = "goal_02",
        title = "Sommerurlaub Alpen & Dolomiten",
        targetAmountCents = 150000L, // 1.500,00 €
        currentAmountCents = 95000L, // 950,00 €
        targetDate = "01.07.2027",
        monthlyContributionCents = 15000L,
        categoryTag = "Reise"
      ),
      SavingsGoal(
        id = "goal_03",
        title = "Neues MacBook Pro M5",
        targetAmountCents = 220000L, // 2.200,00 €
        currentAmountCents = 180000L, // 1.800,00 €
        targetDate = "15.11.2026",
        monthlyContributionCents = 20000L,
        categoryTag = "Technik"
      )
    )
  }

  fun createInitialBeneficiaries(): List<Beneficiary> {
    return listOf(
      Beneficiary(
        id = "ben_01",
        name = "Sarah Schmidt",
        iban = "DE43 5001 0517 5544 3322 11",
        bic = "HELDDEF1FRA",
        category = "Freunde",
        initials = "SS"
      ),
      Beneficiary(
        id = "ben_02",
        name = "Hausverwaltung Taunus KG",
        iban = "DE13 5005 0000 0011 2233 44",
        bic = "HELDDEF1FRA",
        category = "Miete",
        initials = "HT"
      ),
      Beneficiary(
        id = "ben_03",
        name = "Stadtwerke Frankfurt",
        iban = "DE09 5005 0201 0099 8877 66",
        bic = "FRASDEFFXXX",
        category = "Versorger",
        initials = "SW"
      ),
      Beneficiary(
        id = "ben_04",
        name = "Alexander Weber",
        iban = "DE65 1007 0000 0123 4567 89",
        bic = "DEUTDEDDFRA",
        category = "Freunde",
        initials = "AW"
      )
    )
  }

  fun createInitialStandingOrders(): List<StandingOrder> {
    return listOf(
      StandingOrder(
        id = "so_01",
        recipientName = "Hausverwaltung Taunus KG",
        recipientIban = "DE13 5005 0000 0011 2233 44",
        amountCents = 115000L, // 1.150,00 €
        intervalDescription = "Monatlich zum 1.",
        nextExecutionDate = "01.11.2026",
        reference = "Miete Wohnung 4.OG Taunusanlage 8"
      ),
      StandingOrder(
        id = "so_02",
        recipientName = "Eichen Bank Flex-Sparen",
        recipientIban = savingsIban,
        amountCents = 30000L, // 300,00 €
        intervalDescription = "Monatlich zum 15.",
        nextExecutionDate = "15.11.2026",
        reference = "Automatischer Sparplan Notgroschen"
      )
    )
  }

  fun createInitialNotifications(): List<NotificationItem> {
    val now = System.currentTimeMillis()
    return listOf(
      NotificationItem(
        id = "notif_01",
        title = "Geldeingang verbucht",
        message = "+ 2.850,00 € von BMW Group AG eingegangen.",
        timestamp = now - 3600 * 1000L * 24,
        category = NotificationCategory.TRANSACTION,
        isRead = false
      ),
      NotificationItem(
        id = "notif_02",
        title = "Kartensicherheit aktiv",
        message = "Deine physische Karte •• 4892 ist für Auslandszahlungen geschützt.",
        timestamp = now - 3600 * 1000L * 48,
        category = NotificationCategory.CARD_SECURITY,
        isRead = true
      ),
      NotificationItem(
        id = "notif_03",
        title = "BaFin Einlagensicherung",
        message = "Deine Einlagen sind bis 100.000 € gesetzlich geschützt (EinSiG).",
        timestamp = now - 3600 * 1000L * 72,
        category = NotificationCategory.SYSTEM,
        isRead = true
      )
    )
  }
}
