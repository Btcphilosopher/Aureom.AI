package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.data.BankRepository
import com.example.core.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class BankDestination(val germanTitle: String, val englishTitle: String) {
  OVERVIEW("Übersicht", "Overview"),
  CARDS("Karten", "Cards"),
  PAYMENTS("Zahlungen", "Payments"),
  SAVINGS("Sparen", "Savings"),
  PROFILE("Profil", "Profile")
}

data class TransferFormState(
  val recipientName: String = "",
  val recipientIban: String = "",
  val amountInput: String = "",
  val reference: String = "",
  val isInstant: Boolean = true,
  val isSubmitting: Boolean = false,
  val error: String? = null,
  val successTransaction: TransactionItem? = null
)

class BankViewModel(
  private val repository: BankRepository = BankRepository.getInstance()
) : ViewModel() {

  private val _currentDestination = MutableStateFlow(BankDestination.OVERVIEW)
  val currentDestination: StateFlow<BankDestination> = _currentDestination.asStateFlow()

  val accounts: StateFlow<List<Account>> = repository.accounts
  val transactions: StateFlow<List<TransactionItem>> = repository.transactions
  val cards: StateFlow<List<CardItem>> = repository.cards
  val savingsGoals: StateFlow<List<SavingsGoal>> = repository.savingsGoals
  val beneficiaries: StateFlow<List<Beneficiary>> = repository.beneficiaries
  val standingOrders: StateFlow<List<StandingOrder>> = repository.standingOrders
  val notifications: StateFlow<List<NotificationItem>> = repository.notifications
  val userProfile: StateFlow<UserProfile> = repository.userProfile

  // Total balance across all accounts
  val totalBalanceCents: StateFlow<Long> = repository.accounts.map { list ->
    list.sumOf { it.balanceCents }
  }.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)

  // Primary account
  val primaryAccount: StateFlow<Account?> = repository.accounts.map { list ->
    list.find { it.isPrimary } ?: list.firstOrNull()
  }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

  // Transfer sheet/form state
  private val _transferForm = MutableStateFlow(TransferFormState())
  val transferForm: StateFlow<TransferFormState> = _transferForm.asStateFlow()

  // Selected transaction for detail dialog
  private val _selectedTransaction = MutableStateFlow<TransactionItem?>(null)
  val selectedTransaction: StateFlow<TransactionItem?> = _selectedTransaction.asStateFlow()

  // Money request dialog state
  private val _showRequestMoneyDialog = MutableStateFlow(false)
  val showRequestMoneyDialog: StateFlow<Boolean> = _showRequestMoneyDialog.asStateFlow()

  // Notifications sheet state
  private val _showNotificationsSheet = MutableStateFlow(false)
  val showNotificationsSheet: StateFlow<Boolean> = _showNotificationsSheet.asStateFlow()

  fun navigateTo(destination: BankDestination) {
    _currentDestination.value = destination
  }

  fun togglePrivacy() {
    repository.togglePrivacyMask()
  }

  fun toggleLanguage() {
    repository.toggleLanguage()
  }

  fun resetDemo() {
    repository.resetToDemoData()
  }

  fun selectTransaction(tx: TransactionItem?) {
    _selectedTransaction.value = tx
  }

  fun setShowRequestMoney(show: Boolean) {
    _showRequestMoneyDialog.value = show
  }

  fun setShowNotifications(show: Boolean) {
    _showNotificationsSheet.value = show
  }

  fun updateTransferRecipient(name: String, iban: String) {
    _transferForm.value = _transferForm.value.copy(
      recipientName = name,
      recipientIban = iban,
      error = null
    )
  }

  fun updateTransferAmount(amount: String) {
    _transferForm.value = _transferForm.value.copy(
      amountInput = amount,
      error = null
    )
  }

  fun updateTransferReference(reference: String) {
    _transferForm.value = _transferForm.value.copy(reference = reference)
  }

  fun toggleInstantTransfer(instant: Boolean) {
    _transferForm.value = _transferForm.value.copy(isInstant = instant)
  }

  fun submitTransfer() {
    val state = _transferForm.value
    val cleanAmount = state.amountInput.replace(",", ".").trim()
    val parsedAmount = cleanAmount.toDoubleOrNull()

    if (parsedAmount == null || parsedAmount <= 0.0) {
      _transferForm.value = state.copy(error = "Bitte einen gültigen Betrag eingeben (z. B. 45,50)")
      return
    }

    val cents = (parsedAmount * 100).toLong()

    _transferForm.value = state.copy(isSubmitting = true, error = null)

    viewModelScope.launch {
      val result = repository.executeSepaTransfer(
        recipientName = state.recipientName.ifBlank { "Unbekannter Empfänger" },
        recipientIban = state.recipientIban,
        amountCents = cents,
        reference = state.reference,
        isInstant = state.isInstant
      )

      result.onSuccess { tx ->
        _transferForm.value = TransferFormState(
          successTransaction = tx
        )
      }.onFailure { err ->
        _transferForm.value = state.copy(
          isSubmitting = false,
          error = err.message ?: "Überweisung fehlgeschlagen."
        )
      }
    }
  }

  fun clearTransferState() {
    _transferForm.value = TransferFormState()
  }

  fun toggleCardFreeze(cardId: String) = repository.toggleCardFreeze(cardId)
  fun toggleCardOnline(cardId: String) = repository.toggleCardOnline(cardId)
  fun toggleCardContactless(cardId: String) = repository.toggleCardContactless(cardId)
  fun toggleCardAtm(cardId: String) = repository.toggleCardAtm(cardId)
  fun updateCardLimit(cardId: String, limitCents: Long) = repository.updateCardLimit(cardId, limitCents)

  fun createSavingsGoal(title: String, targetCents: Long, targetDate: String, monthlyCents: Long, tag: String) {
    repository.createSavingsGoal(title, targetCents, targetDate, monthlyCents, tag)
  }

  fun depositToGoal(goalId: String, amountCents: Long) = repository.depositToSavingsGoal(goalId, amountCents)
  fun withdrawFromGoal(goalId: String, amountCents: Long) = repository.withdrawFromSavingsGoal(goalId, amountCents)

  fun markNotificationRead(id: String) = repository.markNotificationRead(id)
}
