package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.core.model.NotificationCategory
import com.example.core.model.NotificationItem
import com.example.core.util.GermanFormatter
import com.example.ui.theme.*

@Composable
fun NotificationsSheet(
  notifications: List<NotificationItem>,
  onMarkRead: (String) -> Unit,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
        .testTag("notifications_sheet"),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Benachrichtigungen",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Schließen")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (notifications.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Keine Benachrichtigungen vorhanden",
              style = MaterialTheme.typography.bodyMedium,
              color = EichenTextSecondary
            )
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 400.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(notifications) { item ->
              NotificationRow(item = item, onClick = { onMarkRead(item.id) })
            }
          }
        }
      }
    }
  }
}

@Composable
private fun NotificationRow(
  item: NotificationItem,
  onClick: () -> Unit
) {
  val icon = when (item.category) {
    NotificationCategory.TRANSACTION -> Icons.Default.SwapHoriz
    NotificationCategory.CARD_SECURITY -> Icons.Default.Security
    NotificationCategory.SYSTEM -> Icons.Default.Notifications
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(if (!item.isRead) EichenForestGreenContainer.copy(alpha = 0.5f) else EichenSurfaceVariant)
      .clickable(onClick = onClick)
      .padding(12.dp),
    verticalAlignment = Alignment.Top,
    horizontalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Box(
      modifier = Modifier
        .size(36.dp)
        .clip(CircleShape)
        .background(EichenForestGreenContainer),
      contentAlignment = Alignment.Center
    ) {
      Icon(icon, contentDescription = null, tint = EichenForestGreen, modifier = Modifier.size(18.dp))
    }

    Column(modifier = Modifier.weight(1f)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = item.title,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = GermanFormatter.formatGermanDateTime(item.timestamp),
          style = MaterialTheme.typography.labelSmall,
          color = EichenTextSecondary
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = item.message,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}
