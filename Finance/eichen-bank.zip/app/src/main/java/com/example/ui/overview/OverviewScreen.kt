package com.example.ui.overview

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Account
import com.example.core.model.AccountType
import com.example.core.model.TransactionItem
import com.example.core.util.GermanFormatter
import com.example.ui.components.GermanFlagAccent
import com.example.ui.components.TransactionItemRow
import com.example.ui.theme.*

@Composable
fun OverviewScreen(
  totalBalanceCents: Long,
  accounts: List<Account>,
  recentTransactions: List<TransactionItem>,
  isMasked: Boolean,
  onNavigateToPayments: () -> Unit,
  onNavigateToCards: () -> Unit,
  onNavigateToSavings: () -> Unit,
  onOpenReceiveDialog: () -> Unit,
  onSelectTransaction: (TransactionItem) -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(20.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp)
  ) {
    // 1. Personal Greeting
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Guten Tag, Maximilian",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "Willkommen bei deiner Eichen Bank",
            style = MaterialTheme.typography.bodySmall,
            color = EichenTextSecondary
          )
        }

        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(EichenForestGreenContainer),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "ME",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = EichenForestGreen
          )
        }
      }
    }

    // 2. Central Balance Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("overview_balance_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(22.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Gesamtguthaben",
              style = MaterialTheme.typography.bodyMedium,
              color = EichenTextSecondary,
              fontWeight = FontWeight.Medium
            )
            GermanFlagAccent()
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = GermanFormatter.formatEuro(totalBalanceCents, isMasked),
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(8.dp))

          // Daily Delta Movement Pill
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(EichenPositiveContainer)
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.TrendingUp,
              contentDescription = null,
              tint = EichenPositive,
              modifier = Modifier.size(16.dp)
            )
            Text(
              text = if (isMasked) "•••• heute" else "+ 328,45 € (2,7 %) heute",
              style = MaterialTheme.typography.labelMedium,
              color = EichenPositive,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }

    // 3. Quick Action Buttons (Senden, Empfangen, Karte, Sparen)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        QuickActionButton(
          icon = Icons.Default.ArrowOutward,
          label = "Senden",
          testTag = "quick_action_send",
          onClick = onNavigateToPayments
        )
        QuickActionButton(
          icon = Icons.Default.SouthWest,
          label = "Empfangen",
          testTag = "quick_action_receive",
          onClick = onOpenReceiveDialog
        )
        QuickActionButton(
          icon = Icons.Default.CreditCard,
          label = "Karte",
          testTag = "quick_action_card",
          onClick = onNavigateToCards
        )
        QuickActionButton(
          icon = Icons.Default.Savings,
          label = "Sparen",
          testTag = "quick_action_savings",
          onClick = onNavigateToSavings
        )
      }
    }

    // 4. Accounts Section (Konten)
    item {
      Text(
        text = "Konten & Depots",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }

    items(accounts) { account ->
      AccountItemCard(account = account, isMasked = isMasked)
    }

    // 5. Recent Transactions Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Letzte Transaktionen",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )

        TextButton(
          onClick = onNavigateToPayments,
          modifier = Modifier.testTag("view_all_transactions_button")
        ) {
          Text(
            text = "Alle anzeigen",
            style = MaterialTheme.typography.bodySmall,
            color = EichenForestGreen,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }

    // Recent Transactions List (first 5)
    items(recentTransactions.take(5)) { tx ->
      TransactionItemRow(
        transaction = tx,
        isMasked = isMasked,
        onClick = { onSelectTransaction(tx) }
      )
    }
  }
}

@Composable
private fun QuickActionButton(
  icon: ImageVector,
  label: String,
  testTag: String,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable(onClick = onClick)
      .testTag(testTag)
  ) {
    Box(
      modifier = Modifier
        .size(56.dp)
        .clip(CircleShape)
        .background(EichenSurfaceVariant),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.size(24.dp)
      )
    }
    Spacer(modifier = Modifier.height(8.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.Medium,
      color = MaterialTheme.colorScheme.onSurface
    )
  }
}

@Composable
private fun AccountItemCard(
  account: Account,
  isMasked: Boolean
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("account_card_${account.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(
              when (account.type) {
                AccountType.GIRO -> EichenForestGreenContainer
                AccountType.FLEX_SPAREN -> EichenPositiveContainer
                AccountType.DEPOT -> FlagGold.copy(alpha = 0.15f)
              }
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = when (account.type) {
              AccountType.GIRO -> Icons.Default.AccountBalance
              AccountType.FLEX_SPAREN -> Icons.Default.Savings
              AccountType.DEPOT -> Icons.Default.ShowChart
            },
            contentDescription = null,
            tint = when (account.type) {
              AccountType.GIRO -> EichenForestGreen
              AccountType.FLEX_SPAREN -> EichenPositive
              AccountType.DEPOT -> FlagGold
            },
            modifier = Modifier.size(20.dp)
          )
        }

        Column {
          Text(
            text = account.name,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = GermanFormatter.formatIban(account.iban),
            style = MaterialTheme.typography.bodySmall,
            color = EichenTextSecondary,
            fontSize = 11.sp
          )
        }
      }

      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = GermanFormatter.formatEuro(account.balanceCents, isMasked),
          style = MaterialTheme.typography.bodyLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        if (account.type == AccountType.FLEX_SPAREN) {
          Text(
            text = "3,25 % Zins p. a.",
            style = MaterialTheme.typography.labelSmall,
            color = EichenPositive,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }
  }
}
