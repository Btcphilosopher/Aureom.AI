package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.TransactionCategory
import com.example.core.model.TransactionItem
import com.example.core.model.TransactionStatus
import com.example.core.util.GermanFormatter
import com.example.ui.theme.*

@Composable
fun TransactionItemRow(
  transaction: TransactionItem,
  isMasked: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val iconData = getCategoryIcon(transaction.category)
  val isPositive = transaction.amountCents > 0
  val isPending = transaction.status == TransactionStatus.PENDING

  Row(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 8.dp, vertical = 10.dp)
      .testTag("transaction_item_${transaction.id}"),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    // Left: Icon + Title/Subtitle
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.weight(1f)
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(iconData.backgroundColor),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = iconData.icon,
          contentDescription = transaction.category.germanLabel,
          tint = iconData.iconColor,
          modifier = Modifier.size(20.dp)
        )
      }

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = transaction.title,
          style = MaterialTheme.typography.bodyLarge,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1
        )

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = GermanFormatter.formatGermanDateTime(transaction.timestamp),
            style = MaterialTheme.typography.bodySmall,
            color = EichenTextSecondary
          )

          if (isPending) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(EichenPendingContainer)
                .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
              Text(
                text = "Vormerkung",
                style = MaterialTheme.typography.labelSmall,
                color = EichenPending,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // Right: Amount
    Text(
      text = GermanFormatter.formatEuroWithSign(transaction.amountCents, isMasked),
      style = MaterialTheme.typography.bodyLarge,
      fontWeight = FontWeight.Bold,
      color = when {
        isPositive -> EichenPositive
        isPending -> EichenPending
        else -> MaterialTheme.colorScheme.onSurface
      }
    )
  }
}

private data class CategoryIconData(
  val icon: ImageVector,
  val backgroundColor: androidx.compose.ui.graphics.Color,
  val iconColor: androidx.compose.ui.graphics.Color
)

private fun getCategoryIcon(category: TransactionCategory): CategoryIconData {
  return when (category) {
    TransactionCategory.GEHALT -> CategoryIconData(
      icon = Icons.Default.TrendingUp,
      backgroundColor = EichenPositiveContainer,
      iconColor = EichenPositive
    )
    TransactionCategory.EINKAUFEN -> CategoryIconData(
      icon = Icons.Default.ShoppingCart,
      backgroundColor = EichenSurfaceVariant,
      iconColor = EichenTextPrimary
    )
    TransactionCategory.WOHNEN -> CategoryIconData(
      icon = Icons.Default.Home,
      backgroundColor = EichenSurfaceVariant,
      iconColor = EichenForestGreen
    )
    TransactionCategory.FREIZEIT -> CategoryIconData(
      icon = Icons.Default.Restaurant,
      backgroundColor = EichenPendingContainer,
      iconColor = EichenPending
    )
    TransactionCategory.TRANSPORT -> CategoryIconData(
      icon = Icons.Default.DirectionsTransit,
      backgroundColor = EichenSurfaceVariant,
      iconColor = EichenTextPrimary
    )
    TransactionCategory.SPAREN -> CategoryIconData(
      icon = Icons.Default.Savings,
      backgroundColor = EichenForestGreenContainer,
      iconColor = EichenForestGreen
    )
    TransactionCategory.ABO -> CategoryIconData(
      icon = Icons.Default.Subscriptions,
      backgroundColor = EichenSurfaceVariant,
      iconColor = EichenTextSecondary
    )
  }
}
