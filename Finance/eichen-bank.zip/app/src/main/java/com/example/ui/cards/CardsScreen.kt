package com.example.ui.cards

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.CardItem
import com.example.core.model.CardType
import com.example.core.util.GermanFormatter
import com.example.ui.components.GermanFlagAccent
import com.example.ui.theme.*

@Composable
fun CardsScreen(
  cards: List<CardItem>,
  onToggleFreeze: (String) -> Unit,
  onToggleOnline: (String) -> Unit,
  onToggleContactless: (String) -> Unit,
  onToggleAtm: (String) -> Unit,
  onUpdateLimit: (String, Long) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedCardIndex by remember { mutableIntStateOf(0) }
  val currentCard = cards.getOrNull(selectedCardIndex) ?: cards.firstOrNull()
  var showDetails by remember { mutableStateOf(false) }
  var showPinDialog by remember { mutableStateOf(false) }
  var showLimitDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp)
  ) {
    item {
      Text(
        text = "Karten & Digital Wallet",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = "Verwalte deine physischen und virtuellen Eichen-Debitkarten",
        style = MaterialTheme.typography.bodySmall,
        color = EichenTextSecondary
      )
    }

    // Card Type Selector Tabs (Physisch vs Virtuell)
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(EichenSurfaceVariant)
          .padding(4.dp)
      ) {
        cards.forEachIndexed { index, card ->
          val isSelected = index == selectedCardIndex
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent)
              .clickable { selectedCardIndex = index }
              .padding(vertical = 10.dp)
              .testTag("card_tab_$index"),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = if (card.cardType == CardType.PHYSICAL) "Physische Karte" else "Virtuelle Karte",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) MaterialTheme.colorScheme.onSurface else EichenTextSecondary
            )
          }
        }
      }
    }

    // Luxury Banking Card Visualization
    if (currentCard != null) {
      item {
        LuxuryCardWidget(
          card = currentCard,
          showDetails = showDetails,
          onToggleDetails = { showDetails = !showDetails }
        )
      }

      // Google Wallet Provisioning Status Pill
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(EichenPositiveContainer),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.AccountBalanceWallet,
                  contentDescription = null,
                  tint = EichenPositive,
                  modifier = Modifier.size(18.dp)
                )
              }

              Column {
                Text(
                  text = "Google Wallet & Apple Pay",
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.SemiBold
                )
                Text(
                  text = "Karte ist digital tokenisiert und einsatzbereit",
                  style = MaterialTheme.typography.bodySmall,
                  color = EichenTextSecondary
                )
              }
            }

            Text(
              text = "Aktiv",
              style = MaterialTheme.typography.labelSmall,
              color = EichenPositive,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      // Security & Limits Controls Section
      item {
        Text(
          text = "Sicherheit & Karteneinstellungen",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      // 1. Freeze / Unfreeze Switch
      item {
        CardSettingRow(
          title = if (currentCard.isFrozen) "Karte ist eingefroren" else "Karte vorübergehend sperren",
          subtitle = if (currentCard.isFrozen) "Zahlungen sind blockiert" else "Kann jederzeit reaktiviert werden",
          icon = Icons.Default.Lock,
          isChecked = currentCard.isFrozen,
          onCheckedChange = { onToggleFreeze(currentCard.id) },
          testTag = "toggle_freeze_switch"
        )
      }

      // 2. Online Payments Toggle
      item {
        CardSettingRow(
          title = "Online-Zahlungen",
          subtitle = "Zahlungen im Internet und Apps zulassen",
          icon = Icons.Default.Language,
          isChecked = currentCard.onlineEnabled,
          onCheckedChange = { onToggleOnline(currentCard.id) },
          testTag = "toggle_online_switch"
        )
      }

      // 3. Contactless NFC Toggle
      item {
        CardSettingRow(
          title = "Kontaktloses Bezahlen",
          subtitle = "NFC-Terminals und POS-Terminals",
          icon = Icons.Default.Contactless,
          isChecked = currentCard.contactlessEnabled,
          onCheckedChange = { onToggleContactless(currentCard.id) },
          testTag = "toggle_contactless_switch"
        )
      }

      // 4. ATM Cash Withdrawals Toggle
      item {
        CardSettingRow(
          title = "Bargeld am Geldautomaten",
          subtitle = "Abhebungen weltweit freigeben",
          icon = Icons.Default.LocalAtm,
          isChecked = currentCard.atmEnabled,
          onCheckedChange = { onToggleAtm(currentCard.id) },
          testTag = "toggle_atm_switch"
        )
      }

      // 5. Limits & PIN action buttons
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          OutlinedButton(
            onClick = { showLimitDialog = true },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("change_limit_button"),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Limit ändern")
          }

          OutlinedButton(
            onClick = { showPinDialog = true },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("show_pin_button"),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Pin, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Karten-PIN")
          }
        }
      }
    }
  }

  // Dialog for PIN
  if (showPinDialog && currentCard != null) {
    AlertDialog(
      onDismissRequest = { showPinDialog = false },
      title = { Text("Karten-PIN für Debitkarte") },
      text = {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text("Deine autorisierte 4-stellige Karten-PIN:")
          Spacer(modifier = Modifier.height(16.dp))
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(EichenSurfaceVariant)
              .padding(horizontal = 24.dp, vertical = 12.dp)
          ) {
            Text(
              text = currentCard.pinCode,
              style = MaterialTheme.typography.headlineLarge,
              fontWeight = FontWeight.Bold,
              letterSpacing = 8.sp,
              color = EichenForestGreen
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Niemals an Dritte weitergeben.",
            style = MaterialTheme.typography.bodySmall,
            color = EichenTextSecondary
          )
        }
      },
      confirmButton = {
        Button(
          onClick = { showPinDialog = false },
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen)
        ) {
          Text("Verstanden")
        }
      }
    )
  }

  // Dialog for Spending Limit
  if (showLimitDialog && currentCard != null) {
    var newLimitText by remember { mutableStateOf((currentCard.monthlyLimitCents / 100).toString()) }

    AlertDialog(
      onDismissRequest = { showLimitDialog = false },
      title = { Text("Monatliches Ausgabenlimit") },
      text = {
        Column {
          Text("Aktuelles Limit: ${GermanFormatter.formatEuro(currentCard.monthlyLimitCents)}")
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = newLimitText,
            onValueChange = { newLimitText = it },
            label = { Text("Neues Limit in €") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val amount = newLimitText.toLongOrNull()
            if (amount != null && amount > 0) {
              onUpdateLimit(currentCard.id, amount * 100)
            }
            showLimitDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen)
        ) {
          Text("Speichern")
        }
      },
      dismissButton = {
        TextButton(onClick = { showLimitDialog = false }) {
          Text("Abbrechen")
        }
      }
    )
  }
}

@Composable
private fun LuxuryCardWidget(
  card: CardItem,
  showDetails: Boolean,
  onToggleDetails: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .height(210.dp)
      .testTag("luxury_card_widget"),
    shape = RoundedCornerShape(20.dp),
    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          brush = Brush.linearGradient(
            colors = if (card.isFrozen) {
              listOf(Color(0xFF374151), Color(0xFF1F2937))
            } else {
              listOf(Color(0xFF161A22), Color(0xFF0F261C), Color(0xFF121316))
            }
          )
        )
        .padding(22.dp)
    ) {
      Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        // Top row: Brand & EMV Chip / Status
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(FlagGold),
              contentAlignment = Alignment.Center
            ) {
              Text("E", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = EichenGraphite)
            }
            Text(
              text = "EICHEN BANK",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp,
              style = MaterialTheme.typography.titleSmall
            )
            GermanFlagAccent()
          }

          if (card.isFrozen) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(FlagRed.copy(alpha = 0.3f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "EINGEFROREN",
                color = FlagRed,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
              )
            }
          } else {
            Icon(
              imageVector = Icons.Default.Contactless,
              contentDescription = "Kontaktlos NFC",
              tint = Color.White.copy(alpha = 0.8f),
              modifier = Modifier.size(24.dp)
            )
          }
        }

        // Middle: Card Number
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (showDetails) "4829 9102 3844 ${card.last4}" else card.maskedNumber,
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 2.sp
          )

          IconButton(onClick = onToggleDetails) {
            Icon(
              imageVector = if (showDetails) Icons.Default.VisibilityOff else Icons.Default.Visibility,
              contentDescription = "Kartendetails",
              tint = Color.White.copy(alpha = 0.8f)
            )
          }
        }

        // Bottom row: Holder Name, Expiry, CVV
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
        ) {
          Column {
            Text(
              text = "KARTENINHABER",
              color = Color.White.copy(alpha = 0.5f),
              style = MaterialTheme.typography.labelSmall,
              fontSize = 9.sp
            )
            Text(
              text = card.cardholderName,
              color = Color.White,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold
            )
          }

          Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = "GÜLTIG BIS",
                color = Color.White.copy(alpha = 0.5f),
                style = MaterialTheme.typography.labelSmall,
                fontSize = 9.sp
              )
              Text(
                text = card.expiryDate,
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = "CVV",
                color = Color.White.copy(alpha = 0.5f),
                style = MaterialTheme.typography.labelSmall,
                fontSize = 9.sp
              )
              Text(
                text = if (showDetails) card.cvv else "•••",
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun CardSettingRow(
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  isChecked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  testTag: String
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(EichenSurfaceVariant),
          contentAlignment = Alignment.Center
        ) {
          Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(20.dp))
        }

        Column {
          Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = EichenTextSecondary
          )
        }
      }

      Switch(
        checked = isChecked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
          checkedThumbColor = Color.White,
          checkedTrackColor = EichenForestGreen
        ),
        modifier = Modifier.testTag(testTag)
      )
    }
  }
}
