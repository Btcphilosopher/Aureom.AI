package com.example.core.model

enum class AccountType(val germanLabel: String) {
  GIRO("Hauptkonto (Girokonto)"),
  FLEX_SPAREN("Flex-Sparen (Tagesgeld)"),
  DEPOT("Zukunfts-Depot")
}

data class Account(
  val id: String,
  val name: String,
  val iban: String,
  val bic: String,
  val type: AccountType,
  val balanceCents: Long,
  val availableBalanceCents: Long,
  val pendingHoldsCents: Long = 0,
  val isPrimary: Boolean = false
)

enum class TransactionStatus(val germanLabel: String) {
  BOOKED("Gebucht"),
  PENDING("Vormerkung"),
  SCHEDULED("Terminiert")
}

enum class TransactionCategory(val germanLabel: String) {
  GEHALT("Gehalt & Einnahmen"),
  EINKAUFEN("Lebensmittel & Einkauf"),
  WOHNEN("Miete & Wohnen"),
  FREIZEIT("Freizeit & Gastronomie"),
  TRANSPORT("Mobilität & Reise"),
  SPAREN("Sparen & Investieren"),
  ABO("Abonnements & Verträge")
}

enum class PaymentType(val germanLabel: String) {
  SEPA_CREDIT("SEPA-Überweisung"),
  SEPA_INSTANT("SEPA-Echtzeitüberweisung"),
  CARD_PURCHASE("Kartenzahlung"),
  INTERNAL_TRANSFER("Umbuchung")
}

data class TransactionItem(
  val id: String,
  val accountId: String,
  val title: String,
  val subtitle: String,
  val counterpartyName: String,
  val counterpartyIban: String,
  val amountCents: Long, // Positive for credit, negative for debit
  val timestamp: Long,
  val category: TransactionCategory,
  val status: TransactionStatus,
  val paymentType: PaymentType,
  val reference: String,
  val receiptCode: String
)

enum class CardType(val germanLabel: String) {
  PHYSICAL("Physische Eichen Debitkarte"),
  VIRTUAL("Virtuelle Sofort-Karte")
}

data class CardItem(
  val id: String,
  val accountId: String,
  val cardholderName: String,
  val maskedNumber: String,
  val last4: String,
  val expiryDate: String,
  val cardType: CardType,
  val isFrozen: Boolean,
  val onlineEnabled: Boolean,
  val contactlessEnabled: Boolean,
  val atmEnabled: Boolean,
  val monthlyLimitCents: Long,
  val dailySpentCents: Long,
  val pinCode: String = "4820",
  val cvv: String = "834",
  val inGoogleWallet: Boolean = true
)

data class SavingsGoal(
  val id: String,
  val title: String,
  val targetAmountCents: Long,
  val currentAmountCents: Long,
  val targetDate: String,
  val monthlyContributionCents: Long,
  val categoryTag: String
) {
  val progressPercent: Float
    get() = if (targetAmountCents > 0) (currentAmountCents.toFloat() / targetAmountCents).coerceIn(0f, 1f) else 0f
}

data class Beneficiary(
  val id: String,
  val name: String,
  val iban: String,
  val bic: String,
  val category: String,
  val initials: String
)

data class StandingOrder(
  val id: String,
  val recipientName: String,
  val recipientIban: String,
  val amountCents: Long,
  val intervalDescription: String,
  val nextExecutionDate: String,
  val reference: String
)

enum class NotificationCategory {
  TRANSACTION,
  CARD_SECURITY,
  SYSTEM
}

data class NotificationItem(
  val id: String,
  val title: String,
  val message: String,
  val timestamp: Long,
  val category: NotificationCategory,
  val isRead: Boolean = false
)

data class UserProfile(
  val name: String = "Maximilian Eichenberg",
  val email: String = "maximilian.eichenberg@eichen-bank.de",
  val address: String = "Taunusanlage 8, 60329 Frankfurt am Main",
  val kycStatus: String = "Vollständig verifiziert (VideoIdent GwG)",
  val language: String = "de",
  val isDemoMode: Boolean = true,
  val privacyMask: Boolean = false
)
