package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = EichenForestGreenLight,
  onPrimary = Color.White,
  primaryContainer = EichenForestGreenDark,
  onPrimaryContainer = Color.White,
  secondary = EichenPositive,
  onSecondary = Color.White,
  tertiary = FlagGold,
  background = Color(0xFF101216),
  surface = Color(0xFF181A20),
  surfaceVariant = Color(0xFF222630),
  onBackground = Color(0xFFF3F4F6),
  onSurface = Color(0xFFF3F4F6),
  outline = Color(0xFF374151)
)

private val LightColorScheme = lightColorScheme(
  primary = EichenForestGreen,
  onPrimary = Color.White,
  primaryContainer = EichenForestGreenContainer,
  onPrimaryContainer = EichenOnForestGreenContainer,
  secondary = EichenForestGreenDark,
  onSecondary = Color.White,
  tertiary = FlagGold,
  background = EichenBackground,
  surface = EichenSurface,
  surfaceVariant = EichenSurfaceVariant,
  onBackground = EichenTextPrimary,
  onSurface = EichenTextPrimary,
  outline = EichenBorder
)

@Composable
fun EichenBankTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = EichenTypography,
    content = content
  )
}
