package com.example.ui.savings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.SavingsGoal
import com.example.core.util.GermanFormatter
import com.example.ui.theme.*

@Composable
fun SavingsScreen(
  savingsGoals: List<SavingsGoal>,
  isMasked: Boolean,
  onCreateGoal: (String, Long, String, Long, String) -> Unit,
  onDepositToGoal: (String, Long) -> Unit,
  onWithdrawFromGoal: (String, Long) -> Unit,
  modifier: Modifier = Modifier
) {
  var showCreateGoalDialog by remember { mutableStateOf(false) }
  var selectedGoalForAction by remember { mutableStateOf<SavingsGoal?>(null) }
  var actionType by remember { mutableStateOf<String?>(null) } // "DEPOSIT" or "WITHDRAW"

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp)
  ) {
    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Sparen & Spaces",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "Erreiche deine Sparziele mit automatischen Sparplänen",
            style = MaterialTheme.typography.bodySmall,
            color = EichenTextSecondary
          )
        }

        IconButton(
          onClick = { showCreateGoalDialog = true },
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(EichenForestGreenContainer)
            .testTag("create_goal_button")
        ) {
          Icon(Icons.Default.Add, contentDescription = "Neues Sparziel anlegen", tint = EichenForestGreen)
        }
      }
    }

    // Tagesgeld / Flex-Sparen Interest Highlight Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EichenForestGreen),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Flex-Sparen Tagesgeld",
              color = Color.White.copy(alpha = 0.8f),
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.SemiBold
            )
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(FlagGold)
                .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text(
                text = "3,25 % p. a.",
                color = EichenGraphite,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "Zinsen werden monatlich gutgeschrieben",
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "Täglich verfügbar ohne Kündigungsfrist. Bis 100.000 € gesetzlich durch die Entschädigungseinrichtung deutscher Banken geschützt.",
            color = Color.White.copy(alpha = 0.75f),
            style = MaterialTheme.typography.bodySmall
          )
        }
      }
    }

    // Savings Goals Section
    item {
      Text(
        text = "Deine aktiven Sparziele",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    items(savingsGoals) { goal ->
      SavingsGoalCard(
        goal = goal,
        isMasked = isMasked,
        onDepositClick = {
          selectedGoalForAction = goal
          actionType = "DEPOSIT"
        },
        onWithdrawClick = {
          selectedGoalForAction = goal
          actionType = "WITHDRAW"
        }
      )
    }

    // Spending Categories & Budgets
    item {
      Text(
        text = "Monatsausgaben nach Kategorien",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          CategoryBudgetBar(
            title = "Wohnen & Miete",
            amountText = "1.150,00 €",
            percent = 0.46f,
            color = EichenForestGreen
          )
          CategoryBudgetBar(
            title = "Lebensmittel & Supermarkt",
            amountText = "420,50 €",
            percent = 0.22f,
            color = EichenPositive
          )
          CategoryBudgetBar(
            title = "Mobilität & DB Bahn",
            amountText = "149,90 €",
            percent = 0.12f,
            color = FlagGold
          )
          CategoryBudgetBar(
            title = "Freizeit & Restaurant",
            amountText = "98,00 €",
            percent = 0.08f,
            color = EichenPending
          )
        }
      }
    }
  }

  // Create Goal Dialog
  if (showCreateGoalDialog) {
    var titleInput by remember { mutableStateOf("") }
    var targetInput by remember { mutableStateOf("") }
    var monthlyInput by remember { mutableStateOf("100") }
    var targetDateInput by remember { mutableStateOf("31.12.2027") }

    AlertDialog(
      onDismissRequest = { showCreateGoalDialog = false },
      title = { Text("Neues Sparziel anlegen") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = titleInput,
            onValueChange = { titleInput = it },
            label = { Text("Name des Sparziels") },
            placeholder = { Text("z. B. Neues E-Bike") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
          )
          OutlinedTextField(
            value = targetInput,
            onValueChange = { targetInput = it },
            label = { Text("Zielbetrag in €") },
            placeholder = { Text("z. B. 2500") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
          )
          OutlinedTextField(
            value = monthlyInput,
            onValueChange = { monthlyInput = it },
            label = { Text("Monatlicher Sparplan (€)") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val targetCents = (targetInput.toDoubleOrNull() ?: 1000.0) * 100
            val monthlyCents = (monthlyInput.toDoubleOrNull() ?: 50.0) * 100
            if (titleInput.isNotBlank()) {
              onCreateGoal(
                titleInput,
                targetCents.toLong(),
                targetDateInput,
                monthlyCents.toLong(),
                "Ziele"
              )
            }
            showCreateGoalDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen)
        ) {
          Text("Ziel erstellen")
        }
      },
      dismissButton = {
        TextButton(onClick = { showCreateGoalDialog = false }) {
          Text("Abbrechen")
        }
      }
    )
  }

  // Deposit/Withdraw Dialog
  if (selectedGoalForAction != null && actionType != null) {
    val goal = selectedGoalForAction!!
    var amountText by remember { mutableStateOf("100") }

    AlertDialog(
      onDismissRequest = {
        selectedGoalForAction = null
        actionType = null
      },
      title = {
        Text(if (actionType == "DEPOSIT") "Geld einzahlen in ${goal.title}" else "Geld auszahlen auf Hauptkonto")
      },
      text = {
        Column {
          Text("Aktueller Stand im Sparziel: ${GermanFormatter.formatEuro(goal.currentAmountCents)}")
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it },
            label = { Text("Betrag in €") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val amount = amountText.toDoubleOrNull()
            if (amount != null && amount > 0) {
              val cents = (amount * 100).toLong()
              if (actionType == "DEPOSIT") {
                onDepositToGoal(goal.id, cents)
              } else {
                onWithdrawFromGoal(goal.id, cents)
              }
            }
            selectedGoalForAction = null
            actionType = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen)
        ) {
          Text("Ausführen")
        }
      },
      dismissButton = {
        TextButton(onClick = {
          selectedGoalForAction = null
          actionType = null
        }) {
          Text("Abbrechen")
        }
      }
    )
  }
}

@Composable
private fun SavingsGoalCard(
  goal: SavingsGoal,
  isMasked: Boolean,
  onDepositClick: () -> Unit,
  onWithdrawClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("savings_goal_${goal.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = goal.title,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Ziel bis ${goal.targetDate} • ${GermanFormatter.formatEuro(goal.monthlyContributionCents)} / Monat",
            style = MaterialTheme.typography.bodySmall,
            color = EichenTextSecondary
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(EichenForestGreenContainer)
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "${(goal.progressPercent * 100).toInt()} %",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = EichenForestGreen
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Progress bar
      LinearProgressIndicator(
        progress = { goal.progressPercent },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = EichenForestGreen,
        trackColor = EichenSurfaceVariant
      )

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Gespart",
            style = MaterialTheme.typography.labelSmall,
            color = EichenTextSecondary
          )
          Text(
            text = GermanFormatter.formatEuro(goal.currentAmountCents, isMasked),
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "Zielbetrag",
            style = MaterialTheme.typography.labelSmall,
            color = EichenTextSecondary
          )
          Text(
            text = GermanFormatter.formatEuro(goal.targetAmountCents, isMasked),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = EichenTextSecondary
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Action buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = onDepositClick,
          modifier = Modifier
            .weight(1f)
            .height(40.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Einzahlen", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onWithdrawClick,
          modifier = Modifier
            .weight(1f)
            .height(40.dp),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("Auszahlen", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }
}

@Composable
private fun CategoryBudgetBar(
  title: String,
  amountText: String,
  percent: Float,
  color: Color
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Medium
      )
      Text(
        text = amountText,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.height(6.dp))

    LinearProgressIndicator(
      progress = { percent },
      modifier = Modifier
        .fillMaxWidth()
        .height(6.dp)
        .clip(RoundedCornerShape(3.dp)),
      color = color,
      trackColor = EichenSurfaceVariant
    )
  }
}
