package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.cards.CardsScreen
import com.example.ui.components.NotificationsSheet
import com.example.ui.components.RequestMoneyDialog
import com.example.ui.components.TopBankingBar
import com.example.ui.components.TransactionDetailDialog
import com.example.ui.overview.OverviewScreen
import com.example.ui.payments.PaymentsScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.savings.SavingsScreen
import com.example.ui.theme.EichenForestGreen
import com.example.ui.theme.EichenForestGreenContainer
import com.example.ui.viewmodel.BankDestination
import com.example.ui.viewmodel.BankViewModel

@Composable
fun MainScreen(
  viewModel: BankViewModel = viewModel(),
  modifier: Modifier = Modifier
) {
  val currentDestination by viewModel.currentDestination.collectAsStateWithLifecycle()
  val totalBalanceCents by viewModel.totalBalanceCents.collectAsStateWithLifecycle()
  val accounts by viewModel.accounts.collectAsStateWithLifecycle()
  val transactions by viewModel.transactions.collectAsStateWithLifecycle()
  val cards by viewModel.cards.collectAsStateWithLifecycle()
  val savingsGoals by viewModel.savingsGoals.collectAsStateWithLifecycle()
  val beneficiaries by viewModel.beneficiaries.collectAsStateWithLifecycle()
  val standingOrders by viewModel.standingOrders.collectAsStateWithLifecycle()
  val notifications by viewModel.notifications.collectAsStateWithLifecycle()
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val primaryAccount by viewModel.primaryAccount.collectAsStateWithLifecycle()
  val transferForm by viewModel.transferForm.collectAsStateWithLifecycle()
  val selectedTransaction by viewModel.selectedTransaction.collectAsStateWithLifecycle()
  val showRequestMoney by viewModel.showRequestMoneyDialog.collectAsStateWithLifecycle()
  val showNotifications by viewModel.showNotificationsSheet.collectAsStateWithLifecycle()

  // Handle back button: if not in overview, navigate back to overview
  BackHandler(enabled = currentDestination != BankDestination.OVERVIEW) {
    viewModel.navigateTo(BankDestination.OVERVIEW)
  }

  val unreadNotificationsCount = notifications.count { !it.isRead }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    topBar = {
      TopBankingBar(
        isPrivacyMasked = userProfile.privacyMask,
        unreadNotificationsCount = unreadNotificationsCount,
        onTogglePrivacy = { viewModel.togglePrivacy() },
        onOpenNotifications = { viewModel.setShowNotifications(true) }
      )
    },
    bottomBar = {
      NavigationBar(
        modifier = Modifier
          .fillMaxWidth()
          .windowInsetsPadding(WindowInsets.navigationBars)
          .testTag("bottom_navigation_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
      ) {
        val isGerman = userProfile.language == "de"

        // 1. Übersicht
        NavigationBarItem(
          selected = currentDestination == BankDestination.OVERVIEW,
          onClick = { viewModel.navigateTo(BankDestination.OVERVIEW) },
          icon = {
            Icon(
              imageVector = if (currentDestination == BankDestination.OVERVIEW) Icons.Filled.Home else Icons.Outlined.Home,
              contentDescription = "Übersicht"
            )
          },
          label = {
            Text(
              text = if (isGerman) "Übersicht" else "Overview",
              fontWeight = if (currentDestination == BankDestination.OVERVIEW) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = EichenForestGreenContainer,
            selectedIconColor = EichenForestGreen,
            selectedTextColor = EichenForestGreen
          ),
          modifier = Modifier.testTag("nav_item_overview")
        )

        // 2. Karten
        NavigationBarItem(
          selected = currentDestination == BankDestination.CARDS,
          onClick = { viewModel.navigateTo(BankDestination.CARDS) },
          icon = {
            Icon(
              imageVector = if (currentDestination == BankDestination.CARDS) Icons.Filled.CreditCard else Icons.Outlined.CreditCard,
              contentDescription = "Karten"
            )
          },
          label = {
            Text(
              text = if (isGerman) "Karten" else "Cards",
              fontWeight = if (currentDestination == BankDestination.CARDS) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = EichenForestGreenContainer,
            selectedIconColor = EichenForestGreen,
            selectedTextColor = EichenForestGreen
          ),
          modifier = Modifier.testTag("nav_item_cards")
        )

        // 3. Zahlungen
        NavigationBarItem(
          selected = currentDestination == BankDestination.PAYMENTS,
          onClick = { viewModel.navigateTo(BankDestination.PAYMENTS) },
          icon = {
            Icon(
              imageVector = if (currentDestination == BankDestination.PAYMENTS) Icons.Filled.Send else Icons.Outlined.Send,
              contentDescription = "Zahlungen"
            )
          },
          label = {
            Text(
              text = if (isGerman) "Zahlungen" else "Payments",
              fontWeight = if (currentDestination == BankDestination.PAYMENTS) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = EichenForestGreenContainer,
            selectedIconColor = EichenForestGreen,
            selectedTextColor = EichenForestGreen
          ),
          modifier = Modifier.testTag("nav_item_payments")
        )

        // 4. Sparen
        NavigationBarItem(
          selected = currentDestination == BankDestination.SAVINGS,
          onClick = { viewModel.navigateTo(BankDestination.SAVINGS) },
          icon = {
            Icon(
              imageVector = if (currentDestination == BankDestination.SAVINGS) Icons.Filled.Savings else Icons.Outlined.Savings,
              contentDescription = "Sparen"
            )
          },
          label = {
            Text(
              text = if (isGerman) "Sparen" else "Savings",
              fontWeight = if (currentDestination == BankDestination.SAVINGS) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = EichenForestGreenContainer,
            selectedIconColor = EichenForestGreen,
            selectedTextColor = EichenForestGreen
          ),
          modifier = Modifier.testTag("nav_item_savings")
        )

        // 5. Profil
        NavigationBarItem(
          selected = currentDestination == BankDestination.PROFILE,
          onClick = { viewModel.navigateTo(BankDestination.PROFILE) },
          icon = {
            Icon(
              imageVector = if (currentDestination == BankDestination.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
              contentDescription = "Profil"
            )
          },
          label = {
            Text(
              text = if (isGerman) "Profil" else "Profile",
              fontWeight = if (currentDestination == BankDestination.PROFILE) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = EichenForestGreenContainer,
            selectedIconColor = EichenForestGreen,
            selectedTextColor = EichenForestGreen
          ),
          modifier = Modifier.testTag("nav_item_profile")
        )
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentDestination) {
        BankDestination.OVERVIEW -> {
          OverviewScreen(
            totalBalanceCents = totalBalanceCents,
            accounts = accounts,
            recentTransactions = transactions,
            isMasked = userProfile.privacyMask,
            onNavigateToPayments = { viewModel.navigateTo(BankDestination.PAYMENTS) },
            onNavigateToCards = { viewModel.navigateTo(BankDestination.CARDS) },
            onNavigateToSavings = { viewModel.navigateTo(BankDestination.SAVINGS) },
            onOpenReceiveDialog = { viewModel.setShowRequestMoney(true) },
            onSelectTransaction = { viewModel.selectTransaction(it) }
          )
        }

        BankDestination.CARDS -> {
          CardsScreen(
            cards = cards,
            onToggleFreeze = { viewModel.toggleCardFreeze(it) },
            onToggleOnline = { viewModel.toggleCardOnline(it) },
            onToggleContactless = { viewModel.toggleCardContactless(it) },
            onToggleAtm = { viewModel.toggleCardAtm(it) },
            onUpdateLimit = { id, limit -> viewModel.updateCardLimit(id, limit) }
          )
        }

        BankDestination.PAYMENTS -> {
          PaymentsScreen(
            primaryAccount = primaryAccount,
            beneficiaries = beneficiaries,
            standingOrders = standingOrders,
            allTransactions = transactions,
            transferForm = transferForm,
            isMasked = userProfile.privacyMask,
            onUpdateRecipient = { name, iban -> viewModel.updateTransferRecipient(name, iban) },
            onUpdateAmount = { viewModel.updateTransferAmount(it) },
            onUpdateReference = { viewModel.updateTransferReference(it) },
            onToggleInstant = { viewModel.toggleInstantTransfer(it) },
            onSubmitTransfer = { viewModel.submitTransfer() },
            onClearTransferState = { viewModel.clearTransferState() },
            onSelectTransaction = { viewModel.selectTransaction(it) }
          )
        }

        BankDestination.SAVINGS -> {
          SavingsScreen(
            savingsGoals = savingsGoals,
            isMasked = userProfile.privacyMask,
            onCreateGoal = { title, target, date, monthly, tag ->
              viewModel.createSavingsGoal(title, target, date, monthly, tag)
            },
            onDepositToGoal = { id, amount -> viewModel.depositToGoal(id, amount) },
            onWithdrawFromGoal = { id, amount -> viewModel.withdrawFromGoal(id, amount) }
          )
        }

        BankDestination.PROFILE -> {
          ProfileScreen(
            userProfile = userProfile,
            onResetDemo = { viewModel.resetDemo() },
            onToggleLanguage = { viewModel.toggleLanguage() }
          )
        }
      }
    }
  }

  // Modals
  if (selectedTransaction != null) {
    TransactionDetailDialog(
      transaction = selectedTransaction!!,
      onDismiss = { viewModel.selectTransaction(null) }
    )
  }

  if (showRequestMoney && primaryAccount != null) {
    RequestMoneyDialog(
      iban = primaryAccount!!.iban,
      accountHolder = userProfile.name,
      onDismiss = { viewModel.setShowRequestMoney(false) }
    )
  }

  if (showNotifications) {
    NotificationsSheet(
      notifications = notifications,
      onMarkRead = { viewModel.markNotificationRead(it) },
      onDismiss = { viewModel.setShowNotifications(false) }
    )
  }
}
