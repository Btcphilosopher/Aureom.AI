package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TopBankingBar(
  isPrivacyMasked: Boolean,
  unreadNotificationsCount: Int,
  onTogglePrivacy: () -> Unit,
  onOpenNotifications: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = MaterialTheme.colorScheme.background,
    tonalElevation = 0.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left: Brand identity & German Flag Capsule
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(EichenGraphite),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "E",
            color = FlagGold,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
          )
        }

        Column {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text(
              text = "EICHEN BANK",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp
            )
            GermanFlagAccent()
          }

          // Unobtrusive Demo-Modus badge
          Text(
            text = "DEMO-MODUS • DEUTSCHLAND",
            style = MaterialTheme.typography.labelSmall,
            color = EichenForestGreen,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.4.sp
          )
        }
      }

      // Right: Actions (Privacy mask toggle + Notifications)
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Privacy toggle
        IconButton(
          onClick = onTogglePrivacy,
          modifier = Modifier
            .size(40.dp)
            .testTag("privacy_toggle_button")
        ) {
          Icon(
            imageVector = if (isPrivacyMasked) Icons.Default.VisibilityOff else Icons.Default.Visibility,
            contentDescription = if (isPrivacyMasked) "Guthaben einblenden" else "Guthaben ausblenden",
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(20.dp)
          )
        }

        // Notification Bell
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(onClick = onOpenNotifications)
            .testTag("notifications_button"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Notifications,
            contentDescription = "Benachrichtigungen",
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(20.dp)
          )

          if (unreadNotificationsCount > 0) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(FlagRed)
                .align(Alignment.TopEnd)
            )
          }
        }
      }
    }
  }
}
