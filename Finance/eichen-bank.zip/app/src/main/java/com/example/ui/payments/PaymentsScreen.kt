package com.example.ui.payments

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Account
import com.example.core.model.Beneficiary
import com.example.core.model.StandingOrder
import com.example.core.model.TransactionItem
import com.example.core.util.GermanFormatter
import com.example.ui.components.GermanFlagAccent
import com.example.ui.components.TransactionItemRow
import com.example.ui.theme.*
import com.example.ui.viewmodel.TransferFormState

@Composable
fun PaymentsScreen(
  primaryAccount: Account?,
  beneficiaries: List<Beneficiary>,
  standingOrders: List<StandingOrder>,
  allTransactions: List<TransactionItem>,
  transferForm: TransferFormState,
  isMasked: Boolean,
  onUpdateRecipient: (String, String) -> Unit,
  onUpdateAmount: (String) -> Unit,
  onUpdateReference: (String) -> Unit,
  onToggleInstant: (Boolean) -> Unit,
  onSubmitTransfer: () -> Unit,
  onClearTransferState: () -> Unit,
  onSelectTransaction: (TransactionItem) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Überweisen, 1: Daueraufträge, 2: Historie
  var showConfirmDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp)
  ) {
    item {
      Text(
        text = "Zahlungen & Überweisungen",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = "SEPA-Überweisungen, Echtzeit-Transfers und Daueraufträge",
        style = MaterialTheme.typography.bodySmall,
        color = EichenTextSecondary
      )
    }

    // Tab Header
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(EichenSurfaceVariant)
          .padding(4.dp)
      ) {
        listOf("Überweisen", "Daueraufträge", "Historie").forEachIndexed { index, title ->
          val isSelected = index == selectedTab
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent)
              .clickable { selectedTab = index }
              .padding(vertical = 10.dp)
              .testTag("payment_subtab_$index"),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = title,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              color = if (isSelected) MaterialTheme.colorScheme.onSurface else EichenTextSecondary
            )
          }
        }
      }
    }

    // TAB 0: SEPA Überweisung Form
    if (selectedTab == 0) {
      if (transferForm.successTransaction != null) {
        // Success Receipt Card
        item {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("transfer_success_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = EichenPositiveContainer)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Box(
                modifier = Modifier
                  .size(54.dp)
                  .clip(CircleShape)
                  .background(EichenPositive),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
              }

              Spacer(modifier = Modifier.height(12.dp))

              Text(
                text = "Überweisung erfolgreich ausgeführt!",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = EichenForestGreen
              )

              Text(
                text = "${GermanFormatter.formatEuro(Math.abs(transferForm.successTransaction.amountCents))} an ${transferForm.successTransaction.counterpartyName}",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
              )

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = "Transaktions-Referenz: ${transferForm.successTransaction.receiptCode}",
                style = MaterialTheme.typography.bodySmall,
                color = EichenTextSecondary
              )

              Spacer(modifier = Modifier.height(16.dp))

              Button(
                onClick = onClearTransferState,
                colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("new_transfer_button")
              ) {
                Text("Weitere Überweisung tätigen")
              }
            }
          }
        }
      } else {
        // Source Account Available Balance Banner
        if (primaryAccount != null) {
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = EichenSurfaceVariant)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = "Ausgangskonto: ${primaryAccount.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                  )
                  Text(
                    text = GermanFormatter.formatIban(primaryAccount.iban),
                    style = MaterialTheme.typography.bodySmall,
                    color = EichenTextSecondary
                  )
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "Verfügbar",
                    style = MaterialTheme.typography.labelSmall,
                    color = EichenTextSecondary
                  )
                  Text(
                    text = GermanFormatter.formatEuro(primaryAccount.availableBalanceCents, isMasked),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = EichenForestGreen
                  )
                }
              }
            }
          }
        }

        // Saved Beneficiaries Quick Pick Carousel
        item {
          Text(
            text = "Gespeicherte Empfänger",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
        }

        item {
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            items(beneficiaries) { ben ->
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                  .clickable { onUpdateRecipient(ben.name, ben.iban) }
                  .testTag("beneficiary_${ben.id}")
              ) {
                Box(
                  modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(EichenForestGreenContainer),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = ben.initials,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = EichenForestGreen
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = ben.name.split(" ").firstOrNull() ?: ben.name,
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.Medium,
                  maxLines = 1
                )
              }
            }
          }
        }

        // Transfer Input Form
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
              // Recipient Name
              OutlinedTextField(
                value = transferForm.recipientName,
                onValueChange = { onUpdateRecipient(it, transferForm.recipientIban) },
                label = { Text("Empfänger (Name oder Firma)") },
                placeholder = { Text("z. B. Sarah Schmidt") },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("transfer_recipient_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
              )

              // IBAN with live validation indicator
              val ibanValidation = GermanFormatter.validateGermanIban(transferForm.recipientIban)
              OutlinedTextField(
                value = transferForm.recipientIban,
                onValueChange = { onUpdateRecipient(transferForm.recipientName, it) },
                label = { Text("IBAN (Deutschland)") },
                placeholder = { Text("DE89 3704 ...") },
                supportingText = {
                  if (transferForm.recipientIban.isNotBlank()) {
                    if (ibanValidation.isValid) {
                      Text("Gültige deutsche IBAN (Prüfsumme korrespondierend)", color = EichenPositive)
                    } else {
                      Text(ibanValidation.errorMessage ?: "Ungültige IBAN", color = FlagRed)
                    }
                  } else {
                    Text("DE und 20 Stellen (Gesamt 22 Zeichen)")
                  }
                },
                isError = transferForm.recipientIban.isNotBlank() && !ibanValidation.isValid,
                trailingIcon = {
                  if (transferForm.recipientIban.isNotBlank()) {
                    if (ibanValidation.isValid) {
                      Icon(Icons.Default.CheckCircle, contentDescription = "Gültig", tint = EichenPositive)
                    } else {
                      Icon(Icons.Default.Error, contentDescription = "Fehler", tint = FlagRed)
                    }
                  }
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("transfer_iban_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
              )

              // Amount
              OutlinedTextField(
                value = transferForm.amountInput,
                onValueChange = onUpdateAmount,
                label = { Text("Betrag in Euro (€)") },
                placeholder = { Text("0,00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                trailingIcon = {
                  Text("EUR €", fontWeight = FontWeight.Bold, color = EichenForestGreen, modifier = Modifier.padding(end = 12.dp))
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("transfer_amount_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
              )

              // Reference / Verwendungszweck
              OutlinedTextField(
                value = transferForm.reference,
                onValueChange = onUpdateReference,
                label = { Text("Verwendungszweck (optional)") },
                placeholder = { Text("z. B. Miete oder Rechnung") },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("transfer_reference_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
              )

              // Instant SEPA Switch
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .background(EichenSurfaceVariant)
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    Text(
                      text = "SEPA-Echtzeitüberweisung",
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.Bold
                    )
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(EichenPositiveContainer)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                      Text("In Sekunden", style = MaterialTheme.typography.labelSmall, color = EichenPositive, fontSize = 9.sp)
                    }
                  }
                  Text(
                    text = "Gutschrift beim Empfänger innerhalb von Sekunden",
                    style = MaterialTheme.typography.bodySmall,
                    color = EichenTextSecondary
                  )
                }

                Switch(
                  checked = transferForm.isInstant,
                  onCheckedChange = onToggleInstant,
                  colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EichenForestGreen)
                )
              }

              if (transferForm.error != null) {
                Text(
                  text = transferForm.error,
                  color = FlagRed,
                  style = MaterialTheme.typography.bodySmall
                )
              }

              // Submit Button
              Button(
                onClick = { showConfirmDialog = true },
                enabled = transferForm.recipientName.isNotBlank() &&
                  ibanValidation.isValid &&
                  transferForm.amountInput.isNotBlank() &&
                  !transferForm.isSubmitting,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(52.dp)
                  .testTag("transfer_submit_button"),
                colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen),
                shape = RoundedCornerShape(12.dp)
              ) {
                if (transferForm.isSubmitting) {
                  CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                  Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Überweisung prüfen & freigeben", fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }

    // TAB 1: Daueraufträge (Standing Orders)
    if (selectedTab == 1) {
      item {
        Text(
          text = "Aktive Daueraufträge",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }

      items(standingOrders) { order ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = order.recipientName,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = order.reference,
                style = MaterialTheme.typography.bodySmall,
                color = EichenTextSecondary
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "${order.intervalDescription} • Nächste: ${order.nextExecutionDate}",
                style = MaterialTheme.typography.labelSmall,
                color = EichenForestGreen,
                fontWeight = FontWeight.Medium
              )
            }

            Text(
              text = GermanFormatter.formatEuro(order.amountCents, isMasked),
              style = MaterialTheme.typography.bodyLarge,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }

    // TAB 2: Historie (All Transactions)
    if (selectedTab == 2) {
      item {
        Text(
          text = "Gesamte Umsatzhistorie",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }

      items(allTransactions) { tx ->
        TransactionItemRow(
          transaction = tx,
          isMasked = isMasked,
          onClick = { onSelectTransaction(tx) }
        )
      }
    }
  }

  // 2FA / SCA Confirmation Dialog
  if (showConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showConfirmDialog = false },
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.Security, contentDescription = null, tint = EichenForestGreen)
          Text("Zahlung freigeben (2FA / SCA)")
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Bitte bestätige die SEPA-Überweisung:")
          HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
          Text("Empfänger: ${transferForm.recipientName}", fontWeight = FontWeight.SemiBold)
          Text("IBAN: ${GermanFormatter.formatIban(transferForm.recipientIban)}")
          Text("Betrag: ${transferForm.amountInput} €", fontWeight = FontWeight.Bold, color = EichenForestGreen)
          Text("Verwendungszweck: ${transferForm.reference.ifBlank { "Keiner" }}")
          Text("Ausführung: ${if (transferForm.isInstant) "SEPA-Echtzeit (sofort)" else "Standard SEPA"}")
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showConfirmDialog = false
            onSubmitTransfer()
          },
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen),
          modifier = Modifier.testTag("confirm_transfer_dialog_button")
        ) {
          Text("Autorisieren & Senden")
        }
      },
      dismissButton = {
        TextButton(onClick = { showConfirmDialog = false }) {
          Text("Abbrechen")
        }
      }
    )
  }
}
