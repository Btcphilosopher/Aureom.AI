package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.core.model.TransactionItem
import com.example.core.model.TransactionStatus
import com.example.core.util.GermanFormatter
import com.example.ui.theme.*

@Composable
fun TransactionDetailDialog(
  transaction: TransactionItem,
  onDismiss: () -> Unit
) {
  val isPositive = transaction.amountCents > 0

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
        .testTag("transaction_detail_dialog"),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(24.dp)
      ) {
        // Header with close
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Buchungsdetails",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
          IconButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("close_detail_button")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Schließen")
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large Amount Display
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isPositive) EichenPositiveContainer else EichenSurfaceVariant)
            .padding(vertical = 16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = GermanFormatter.formatEuroWithSign(transaction.amountCents),
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = if (isPositive) EichenPositive else MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = transaction.title,
            style = MaterialTheme.typography.bodyMedium,
            color = EichenTextSecondary
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Details grid
        DetailRow(label = "Status", value = transaction.status.germanLabel)
        DetailRow(label = "Buchungsart", value = transaction.paymentType.germanLabel)
        DetailRow(label = "Kategorie", value = transaction.category.germanLabel)
        DetailRow(label = "Datum & Uhrzeit", value = GermanFormatter.formatGermanDateTime(transaction.timestamp))
        DetailRow(label = "Empfänger/Sender", value = transaction.counterpartyName)
        DetailRow(label = "IBAN", value = GermanFormatter.formatIban(transaction.counterpartyIban))
        DetailRow(label = "Verwendungszweck", value = transaction.reference)
        DetailRow(label = "Transaktions-ID", value = transaction.receiptCode)

        Spacer(modifier = Modifier.height(24.dp))

        // Action button
        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("dismiss_detail_button"),
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Quittung als PDF exportieren", fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }
}

@Composable
private fun DetailRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = EichenTextSecondary,
      modifier = Modifier.weight(0.4f)
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.Medium,
      color = MaterialTheme.colorScheme.onSurface,
      modifier = Modifier.weight(0.6f)
    )
  }
}
