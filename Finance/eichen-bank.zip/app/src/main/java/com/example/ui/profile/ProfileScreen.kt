package com.example.ui.profile

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.UserProfile
import com.example.ui.components.GermanFlagAccent
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
  userProfile: UserProfile,
  onResetDemo: () -> Unit,
  onToggleLanguage: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var biometricEnabled by remember { mutableStateOf(true) }
  var showDepositInsuranceDialog by remember { mutableStateOf(false) }
  var showBafinDialog by remember { mutableStateOf(false) }
  var showImpressumDialog by remember { mutableStateOf(false) }
  var showResetSuccessNotice by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp)
  ) {
    // Top Customer Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("profile_user_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            Box(
              modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(EichenForestGreenContainer),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "ME",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = EichenForestGreen
              )
            }

            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = userProfile.name,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = userProfile.email,
                style = MaterialTheme.typography.bodySmall,
                color = EichenTextSecondary
              )
              Text(
                text = userProfile.address,
                style = MaterialTheme.typography.bodySmall,
                color = EichenTextSecondary
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // KYC Verified Pill
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(EichenPositiveContainer)
              .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = EichenPositive, modifier = Modifier.size(18.dp))
            Text(
              text = userProfile.kycStatus,
              style = MaterialTheme.typography.labelMedium,
              color = EichenPositive,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // Demo Modus Notice & Reset Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EichenSurfaceVariant)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(Icons.Default.Science, contentDescription = null, tint = EichenForestGreen)
              Text(
                text = "DEMO-MODUS AKTIV",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = EichenForestGreen
              )
            }
            GermanFlagAccent()
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "Diese Applikation läuft mit deterministischen Simulationsdaten. Zahlungen und Buchungen verändern autoritative lokale Ledger-Zustände ohne reale Banküberweisung.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(14.dp))

          OutlinedButton(
            onClick = {
              onResetDemo()
              showResetSuccessNotice = true
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("reset_demo_button"),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Demo-Daten auf Ausgangszustand zurücksetzen")
          }

          if (showResetSuccessNotice) {
            Text(
              text = "Demo-Daten wurden erfolgreich zurückgesetzt",
              style = MaterialTheme.typography.labelSmall,
              color = EichenPositive,
              modifier = Modifier.padding(top = 6.dp)
            )
          }
        }
      }
    }

    // Security Section
    item {
      Text(
        text = "Sicherheit & Authentifizierung",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
          SettingSwitchRow(
            icon = Icons.Default.Fingerprint,
            title = "Biometrischer Login",
            subtitle = "Fingerabdruck & Face Unlock aktiv",
            isChecked = biometricEnabled,
            onCheckedChange = { biometricEnabled = it }
          )
          HorizontalDivider(color = EichenBorder)
          SettingItemRow(
            icon = Icons.Default.PhoneAndroid,
            title = "Registriertes Sicherheitsgerät",
            subtitle = "Google Pixel 9 Pro (Dieses Gerät)"
          )
          HorizontalDivider(color = EichenBorder)
          SettingItemRow(
            icon = Icons.Default.Lock,
            title = "App-PIN ändern",
            subtitle = "4-stellige Zugangs-PIN anpassen"
          )
        }
      }
    }

    // Language & Preferences
    item {
      Text(
        text = "App-Einstellungen",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable(onClick = onToggleLanguage)
              .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              Icon(Icons.Default.Language, contentDescription = null, tint = EichenForestGreen)
              Column {
                Text("Sprache / Language", fontWeight = FontWeight.SemiBold)
                Text(
                  if (userProfile.language == "de") "Deutsch (Standard)" else "English",
                  style = MaterialTheme.typography.bodySmall,
                  color = EichenTextSecondary
                )
              }
            }
            Text(
              text = if (userProfile.language == "de") "DE" else "EN",
              fontWeight = FontWeight.Bold,
              color = EichenForestGreen
            )
          }
        }
      }
    }

    // Regulatory & Legal Disclosures Section
    item {
      Text(
        text = "Rechtliches, BaFin & Einlagensicherung",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
          ClickableInfoRow(
            title = "Gesetzliche Einlagensicherung (EinSiG)",
            subtitle = "Geschützt bis 100.000 € je Kunde",
            onClick = { showDepositInsuranceDialog = true }
          )
          HorizontalDivider(color = EichenBorder)
          ClickableInfoRow(
            title = "Aufsicht & Bankenlizenz (BaFin / EZB)",
            subtitle = "Transparenzhinweis zur Bankeninfrastruktur",
            onClick = { showBafinDialog = true }
          )
          HorizontalDivider(color = EichenBorder)
          ClickableInfoRow(
            title = "Impressum & Datenschutz (DSGVO)",
            subtitle = "Eichen Bank Technologies GmbH",
            onClick = { showImpressumDialog = true }
          )
        }
      }
    }

    // Emergency Sperr-Notruf 116 116
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:116116"))
            context.startActivity(intent)
          },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = EichenNegativeContainer)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(FlagRed),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Phone, contentDescription = null, tint = Color.White)
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Sperr-Notruf: 116 116",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = FlagRed
            )
            Text(
              text = "Kostenlos rund um die Uhr aus Deutschland zur Kartensperrung",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }
  }

  // Dialog Einlagensicherung
  if (showDepositInsuranceDialog) {
    AlertDialog(
      onDismissRequest = { showDepositInsuranceDialog = false },
      title = { Text("Gesetzliche Einlagensicherung") },
      text = {
        Text("Ihre Einlagen sind über die Entschädigungseinrichtung deutscher Banken GmbH (EdB) bis zu einem Betrag von 100.000 Euro pro Kontoinhaber gesetzlich geschützt (EinSiG). Für Einlagen im Rahmen von bestimmten Lebensereignissen (z. B. Immobilienverkauf) gilt ein erweiterter Schutz bis 500.000 Euro.")
      },
      confirmButton = {
        Button(
          onClick = { showDepositInsuranceDialog = false },
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen)
        ) {
          Text("Schließen")
        }
      }
    )
  }

  // Dialog BaFin
  if (showBafinDialog) {
    AlertDialog(
      onDismissRequest = { showBafinDialog = false },
      title = { Text("Aufsichtsrechtliche Struktur") },
      text = {
        Text("Eichen Bank erbringt Bankdienstleistungen in Kooperation mit einer lizenzierten Partnerbank mit deutscher Vollbanklizenz unter Aufsicht der Bundesanstalt für Finanzdienstleistungsaufsicht (BaFin) und der Europäischen Zentralbank (EZB). Alle Kontoguthaben werden treuhänderisch auf insolvenzgeschützten Konten geführt.")
      },
      confirmButton = {
        Button(
          onClick = { showBafinDialog = false },
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen)
        ) {
          Text("Schließen")
        }
      }
    )
  }

  // Dialog Impressum
  if (showImpressumDialog) {
    AlertDialog(
      onDismissRequest = { showImpressumDialog = false },
      title = { Text("Impressum & Datenschutz") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text("Eichen Bank Technologies GmbH", fontWeight = FontWeight.Bold)
          Text("Taunusanlage 8, 60329 Frankfurt am Main")
          Text("Amtsgericht Frankfurt am Main, HRB 128940")
          Text("USt-IdNr.: DE 348 291 042")
          Text("E-Mail: kontakt@eichen-bank.de")
          Spacer(modifier = Modifier.height(6.dp))
          Text("Datenschutzkonform nach EU-DSGVO. Verschlüsselung nach BSI TR-03112 Standards.")
        }
      },
      confirmButton = {
        Button(
          onClick = { showImpressumDialog = false },
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen)
        ) {
          Text("Schließen")
        }
      }
    )
  }
}

@Composable
private fun SettingSwitchRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  isChecked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.weight(1f)
    ) {
      Icon(icon, contentDescription = null, tint = EichenForestGreen)
      Column {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = EichenTextSecondary)
      }
    }
    Switch(
      checked = isChecked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EichenForestGreen)
    )
  }
}

@Composable
private fun SettingItemRow(
  icon: ImageVector,
  title: String,
  subtitle: String
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Icon(icon, contentDescription = null, tint = EichenForestGreen)
    Column {
      Text(title, fontWeight = FontWeight.SemiBold)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = EichenTextSecondary)
    }
  }
}

@Composable
private fun ClickableInfoRow(
  title: String,
  subtitle: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(vertical = 14.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Column {
      Text(title, fontWeight = FontWeight.SemiBold)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = EichenTextSecondary)
    }
    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = EichenTextSecondary)
  }
}
