package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.FlagBlack
import com.example.ui.theme.FlagGold
import com.example.ui.theme.FlagRed

@Composable
fun GermanFlagAccent(
  modifier: Modifier = Modifier,
  width: Dp = 18.dp,
  height: Dp = 4.dp
) {
  Row(
    modifier = modifier
      .clip(RoundedCornerShape(2.dp))
      .height(height)
      .width(width)
  ) {
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxHeight()
        .background(FlagBlack)
    )
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxHeight()
        .background(FlagRed)
    )
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxHeight()
        .background(FlagGold)
    )
  }
}

@Composable
fun GermanFlagVerticalAccent(
  modifier: Modifier = Modifier,
  width: Dp = 3.dp,
  height: Dp = 20.dp
) {
  Column(
    modifier = modifier
      .clip(RoundedCornerShape(2.dp))
      .width(width)
      .height(height)
  ) {
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .background(FlagBlack)
    )
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .background(FlagRed)
    )
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .background(FlagGold)
    )
  }
}
