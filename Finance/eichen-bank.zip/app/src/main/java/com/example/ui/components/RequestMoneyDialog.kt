package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.util.GermanFormatter
import com.example.ui.theme.*

@Composable
fun RequestMoneyDialog(
  iban: String,
  accountHolder: String,
  onDismiss: () -> Unit
) {
  val clipboardManager = LocalClipboardManager.current
  var amountInput by remember { mutableStateOf("") }
  var referenceInput by remember { mutableStateOf("Zahlungsanforderung") }
  var copiedNotice by remember { mutableStateOf(false) }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
        .testTag("request_money_dialog"),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Geld anfordern",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Schließen")
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // EPC QR Code Visualizer
        Box(
          modifier = Modifier
            .size(150.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, EichenBorder, RoundedCornerShape(16.dp)),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.QrCode2,
              contentDescription = "EPC QR GiroCode",
              modifier = Modifier.size(100.dp),
              tint = EichenGraphite
            )
            Text(
              text = "EPC-QR / GiroCode",
              style = MaterialTheme.typography.labelSmall,
              color = EichenTextSecondary,
              fontSize = 10.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // IBAN Card with Copy
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = EichenSurfaceVariant),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Deine Kontoverbindung",
                style = MaterialTheme.typography.labelSmall,
                color = EichenTextSecondary
              )
              Text(
                text = GermanFormatter.formatIban(iban),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = accountHolder,
                style = MaterialTheme.typography.bodySmall,
                color = EichenTextSecondary
              )
            }

            IconButton(
              onClick = {
                clipboardManager.setText(AnnotatedString(iban))
                copiedNotice = true
              },
              modifier = Modifier.testTag("copy_iban_button")
            ) {
              Icon(
                Icons.Default.ContentCopy,
                contentDescription = "IBAN kopieren",
                tint = EichenForestGreen
              )
            }
          }
        }

        if (copiedNotice) {
          Text(
            text = "IBAN in Zwischenablage kopiert",
            style = MaterialTheme.typography.labelSmall,
            color = EichenPositive,
            modifier = Modifier.padding(top = 4.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Optional Amount Field
        OutlinedTextField(
          value = amountInput,
          onValueChange = { amountInput = it },
          label = { Text("Betrag (optional, in €)") },
          placeholder = { Text("z. B. 25,00") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = referenceInput,
          onValueChange = { referenceInput = it },
          label = { Text("Verwendungszweck") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("share_payment_request_button"),
          colors = ButtonDefaults.buttonColors(containerColor = EichenForestGreen),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Zahlungslink teilen", fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }
}
