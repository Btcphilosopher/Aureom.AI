package com.example.core.util

import java.math.BigInteger
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GermanFormatter {

  private val germanSymbols = DecimalFormatSymbols(Locale.GERMANY).apply {
    groupingSeparator = '.'
    decimalSeparator = ','
  }

  private val euroFormat = DecimalFormat("#,##0.00", germanSymbols)

  fun formatEuro(cents: Long, mask: Boolean = false): String {
    if (mask) return "•••••• €"
    val euros = cents / 100.0
    return "${euroFormat.format(euros)} €"
  }

  fun formatEuroWithSign(cents: Long, mask: Boolean = false): String {
    if (mask) return "•••• €"
    val absEuros = Math.abs(cents) / 100.0
    val formatted = euroFormat.format(absEuros)
    return when {
      cents > 0 -> "+ $formatted €"
      cents < 0 -> "- $formatted €"
      else -> "0,00 €"
    }
  }

  fun formatIban(rawIban: String): String {
    val clean = rawIban.replace("\\s+".toRegex(), "").uppercase()
    return clean.chunked(4).joinToString(" ")
  }

  fun formatGermanDateTime(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    val oneDay = 24 * 60 * 60 * 1000L

    val timeFormat = SimpleDateFormat("HH:mm 'Uhr'", Locale.GERMANY)
    val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY)

    return when {
      diff in 0 until oneDay -> "Heute, ${timeFormat.format(Date(timestamp))}"
      diff in oneDay until 2 * oneDay -> "Gestern, ${timeFormat.format(Date(timestamp))}"
      else -> dateFormat.format(Date(timestamp))
    }
  }

  fun formatGermanDate(timestamp: Long): String {
    val dateFormat = SimpleDateFormat("dd. MMMM yyyy", Locale.GERMANY)
    return dateFormat.format(Date(timestamp))
  }

  data class IbanValidationResult(
    val isValid: Boolean,
    val errorMessage: String? = null
  )

  /**
   * Validates German SEPA IBAN (ISO 13616 / ISO 7064 Modulo 97).
   * Format: DEkk BBBB BBBB CCCC CCCC CC (total 22 chars)
   */
  fun validateGermanIban(ibanInput: String): IbanValidationResult {
    val clean = ibanInput.replace("\\s+".toRegex(), "").uppercase()

    if (clean.isBlank()) {
      return IbanValidationResult(false, "Bitte IBAN eingeben")
    }

    if (!clean.startsWith("DE")) {
      return IbanValidationResult(false, "Nur deutsche IBANs (beginnend mit DE) werden unterstützt")
    }

    if (clean.length != 22) {
      return IbanValidationResult(false, "Deutsche IBAN muss genau 22 Zeichen lang sein (aktuell: ${clean.length})")
    }

    if (!clean.matches("^[A-Z0-9]+$".toRegex())) {
      return IbanValidationResult(false, "IBAN enthält ungültige Zeichen")
    }

    // Rearrange: move first 4 chars to end: DEkk -> moved to the end
    val rearranged = clean.substring(4) + clean.substring(0, 4)

    // Replace letters with two digits (A=10, ..., Z=35)
    val numericBuilder = StringBuilder()
    for (char in rearranged) {
      if (char.isDigit()) {
        numericBuilder.append(char)
      } else if (char in 'A'..'Z') {
        numericBuilder.append(char - 'A' + 10)
      } else {
        return IbanValidationResult(false, "Ungültiges Zeichen in IBAN")
      }
    }

    return try {
      val bigInt = BigInteger(numericBuilder.toString())
      val mod = bigInt.mod(BigInteger.valueOf(97)).toInt()
      if (mod == 1) {
        IbanValidationResult(true)
      } else {
        IbanValidationResult(false, "IBAN-Prüfsumme ist fehlerhaft. Bitte Tippfehler prüfen.")
      }
    } catch (e: Exception) {
      IbanValidationResult(false, "Fehler bei der IBAN-Prüfsummenberechnung")
    }
  }
}
