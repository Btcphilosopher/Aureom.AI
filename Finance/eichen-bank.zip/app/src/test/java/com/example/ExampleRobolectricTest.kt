package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.BankRepository
import com.example.core.data.DemoDataProvider
import com.example.core.util.GermanFormatter
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var repository: BankRepository

  @Before
  fun setup() {
    repository = BankRepository.getInstance()
    repository.resetToDemoData()
  }

  @Test
  fun testAppNameResource() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Eichen Bank", appName)
  }

  @Test
  fun testGermanCurrencyFormatting() {
    // 12.482,36 €
    val formattedLarge = GermanFormatter.formatEuro(1248236L)
    assertEquals("12.482,36 €", formattedLarge)

    // 0,00 €
    val formattedZero = GermanFormatter.formatEuro(0L)
    assertEquals("0,00 €", formattedZero)

    // Masked
    val formattedMasked = GermanFormatter.formatEuro(1248236L, mask = true)
    assertEquals("•••••• €", formattedMasked)

    // With sign
    val positive = GermanFormatter.formatEuroWithSign(285000L)
    assertEquals("+ 2.850,00 €", positive)

    val negative = GermanFormatter.formatEuroWithSign(-2432L)
    assertEquals("- 24,32 €", negative)
  }

  @Test
  fun testGermanIbanValidation() {
    // Valid German IBAN from DemoDataProvider
    val validIban = DemoDataProvider.primaryIban
    val validResult = GermanFormatter.validateGermanIban(validIban)
    assertTrue("Primary IBAN should be valid", validResult.isValid)

    // Invalid length
    val shortIban = "DE89 3704 0044"
    val shortResult = GermanFormatter.validateGermanIban(shortIban)
    assertFalse("Short IBAN must be rejected", shortResult.isValid)

    // Non-German prefix
    val frenchIban = "FR14 2004 1010 0505 0001 3M02 606"
    val frenchResult = GermanFormatter.validateGermanIban(frenchIban)
    assertFalse("Non-DE IBAN should be rejected", frenchResult.isValid)

    // Checksum error
    val badChecksumIban = "DE99 3704 0044 0532 0130 00"
    val badChecksumResult = GermanFormatter.validateGermanIban(badChecksumIban)
    assertFalse("Corrupted checksum IBAN must fail ISO 7064 check", badChecksumResult.isValid)
  }

  @Test
  fun testAuthoritativeSepaTransferAndLedgerBalancing() {
    val initialAccounts = repository.accounts.value
    val primary = initialAccounts.find { it.isPrimary }!!
    val initialBalance = primary.availableBalanceCents

    val transferAmount = 15000L // 150,00 €
    val validRecipientIban = DemoDataProvider.savingsIban

    val result = repository.executeSepaTransfer(
      recipientName = "Alexander Weber",
      recipientIban = validRecipientIban,
      amountCents = transferAmount,
      reference = "Gemeinsames Abendessen",
      isInstant = true
    )

    assertTrue("Transfer should succeed", result.isSuccess)
    val transaction = result.getOrNull()!!
    assertEquals(-transferAmount, transaction.amountCents)
    assertTrue("Transaction should start with TX-SEPA", transaction.receiptCode.startsWith("TX-SEPA"))

    // Verify ledger balance deducted exactly
    val updatedPrimary = repository.accounts.value.find { it.isPrimary }!!
    assertEquals(initialBalance - transferAmount, updatedPrimary.availableBalanceCents)
  }

  @Test
  fun testTransferOverdraftProtection() {
    val primary = repository.accounts.value.find { it.isPrimary }!!
    val excessiveAmount = primary.availableBalanceCents + 1000000L // Over available funds

    val result = repository.executeSepaTransfer(
      recipientName = "Müller",
      recipientIban = DemoDataProvider.savingsIban,
      amountCents = excessiveAmount,
      reference = "Too much",
      isInstant = false
    )

    assertTrue("Transfer exceeding available funds must fail", result.isFailure)
  }

  @Test
  fun testCardControls() {
    val cards = repository.cards.value
    val physicalCard = cards.find { it.cardType == com.example.core.model.CardType.PHYSICAL }!!
    assertFalse(physicalCard.isFrozen)

    // Freeze card
    repository.toggleCardFreeze(physicalCard.id)
    val frozenCard = repository.cards.value.find { it.id == physicalCard.id }!!
    assertTrue("Card should now be frozen", frozenCard.isFrozen)

    // Unfreeze
    repository.toggleCardFreeze(physicalCard.id)
    val unfrozenCard = repository.cards.value.find { it.id == physicalCard.id }!!
    assertFalse("Card should now be unfrozen", unfrozenCard.isFrozen)

    // Limit update
    repository.updateCardLimit(physicalCard.id, 500000L)
    val updatedLimitCard = repository.cards.value.find { it.id == physicalCard.id }!!
    assertEquals(500000L, updatedLimitCard.monthlyLimitCents)
  }

  @Test
  fun testSavingsGoalDepositAndWithdrawal() {
    val initialPrimary = repository.accounts.value.find { it.isPrimary }!!
    val goals = repository.savingsGoals.value
    val firstGoal = goals.first()
    val initialGoalAmount = firstGoal.currentAmountCents
    val depositAmount = 5000L // 50,00 €

    val depResult = repository.depositToSavingsGoal(firstGoal.id, depositAmount)
    assertTrue(depResult.isSuccess)

    val updatedGoal = repository.savingsGoals.value.find { it.id == firstGoal.id }!!
    assertEquals(initialGoalAmount + depositAmount, updatedGoal.currentAmountCents)

    // Withdraw back
    val withResult = repository.withdrawFromSavingsGoal(firstGoal.id, depositAmount)
    assertTrue(withResult.isSuccess)

    val restoredGoal = repository.savingsGoals.value.find { it.id == firstGoal.id }!!
    assertEquals(initialGoalAmount, restoredGoal.currentAmountCents)
  }
}
