from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from typing import List

from .schemas import (
    TransferRequest,
    TransferResponse,
    AccountSummaryResponse,
    CustomerProfileResponse,
)
from .ledger import LedgerService

app = FastAPI(
    title="Eichen Bank API",
    description="Autoritative Banking & Payment API für die deutsche Fintech-Plattform Eichen Bank.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ledger_service = LedgerService()

@app.get("/health", tags=["System"])
def health_check():
    return {
        "status": "HEALTHY",
        "service": "Eichen Bank Core Banking Ledger",
        "environment": "production-ready",
    }

@app.get("/api/v1/customers/me", response_model=CustomerProfileResponse, tags=["Customer"])
def get_customer_profile():
    accounts_list = [
        AccountSummaryResponse(
            id=acc["id"],
            name=acc["name"],
            iban=acc["iban"],
            bic=acc["bic"],
            account_type=acc["account_type"],
            balance_cents=acc["balance_cents"],
            available_balance_cents=acc["available_balance_cents"],
            is_primary=acc["is_primary"],
        )
        for acc in ledger_service.accounts.values()
    ]

    return CustomerProfileResponse(
        id="cust_maximilian_01",
        full_name="Maximilian Eichenberg",
        email="maximilian.eichenberg@eichen-bank.de",
        address="Taunusanlage 8, 60329 Frankfurt am Main",
        kyc_status="VERIFIED_VIDEOIDENT_GWG",
        accounts=accounts_list,
    )

@app.post(
    "/api/v1/payments/sepa-transfer",
    response_model=TransferResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Payments"],
)
def execute_sepa_transfer(req: TransferRequest):
    try:
        tx = ledger_service.execute_sepa_transfer(
            source_account_id=req.source_account_id,
            recipient_name=req.recipient_name,
            recipient_iban=req.recipient_iban,
            amount_cents=req.amount_cents,
            reference=req.reference or "SEPA-Überweisung",
            is_instant=req.is_instant,
            idempotency_key=req.idempotency_key,
        )
        return TransferResponse(
            transaction_id=tx["transaction_id"],
            status=tx["status"],
            amount_cents=tx["amount_cents"],
            recipient_name=tx["recipient_name"],
            recipient_iban=tx["recipient_iban"],
            reference=tx["reference"],
            execution_timestamp=tx["execution_timestamp"],
            receipt_code=tx["receipt_code"],
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
