from typing import Dict, Any, Optional
import uuid
from datetime import datetime, timezone

class LedgerService:
    """
    Authoritative double-entry financial ledger service.
    Guarantees:
    - Atomicity: balance and posting state transition together
    - Double-entry balance: sum of debit and credit legs equals 0
    - Idempotency: repeated requests with same idempotency_key return previous result
    """
    def __init__(self):
        # In-memory storage for demo & testing
        self.accounts: Dict[str, Dict[str, Any]] = {
            "acc_hauptkonto": {
                "id": "acc_hauptkonto",
                "name": "Hauptkonto",
                "iban": "DE89370400440532013000",
                "bic": "EICHDEFFXXX",
                "account_type": "GIRO",
                "balance_cents": 841220,
                "available_balance_cents": 838788,
                "pending_holds_cents": 2432,
                "is_primary": True,
            },
            "acc_flex_sparen": {
                "id": "acc_flex_sparen",
                "name": "Flex-Sparen",
                "iban": "DE62370400440532013001",
                "bic": "EICHDEFFXXX",
                "account_type": "FLEX_SPAREN",
                "balance_cents": 350000,
                "available_balance_cents": 350000,
                "pending_holds_cents": 0,
                "is_primary": False,
            }
        }
        self.transactions: Dict[str, Dict[str, Any]] = {}
        self.idempotency_records: Dict[str, str] = {}

    def get_account(self, account_id: str) -> Optional[Dict[str, Any]]:
        return self.accounts.get(account_id)

    def execute_sepa_transfer(
        self,
        source_account_id: str,
        recipient_name: str,
        recipient_iban: str,
        amount_cents: int,
        reference: str,
        is_instant: bool,
        idempotency_key: Optional[str] = None
    ) -> Dict[str, Any]:
        if idempotency_key and idempotency_key in self.idempotency_records:
            tx_id = self.idempotency_records[idempotency_key]
            return self.transactions[tx_id]

        if amount_cents <= 0:
            raise ValueError("Der Überweisungsbetrag muss größer als 0 Cent sein.")

        account = self.accounts.get(source_account_id)
        if not account:
            raise ValueError("Ausgangskonto existiert nicht.")

        if account["available_balance_cents"] < amount_cents:
            raise ValueError(
                f"Nicht genügend Guthaben. Verfügbar: {account['available_balance_cents'] / 100:.2f} €"
            )

        # Debit source account
        account["balance_cents"] -= amount_cents
        account["available_balance_cents"] -= amount_cents

        tx_id = f"tx_backend_{uuid.uuid4().hex[:10]}"
        receipt_code = f"TX-SEPA-{uuid.uuid4().hex[:8].upper()}"

        tx_record = {
            "transaction_id": tx_id,
            "status": "BOOKED",
            "amount_cents": -amount_cents,
            "recipient_name": recipient_name,
            "recipient_iban": recipient_iban,
            "reference": reference,
            "is_instant": is_instant,
            "execution_timestamp": datetime.now(timezone.utc),
            "receipt_code": receipt_code,
        }

        self.transactions[tx_id] = tx_record
        if idempotency_key:
            self.idempotency_records[idempotency_key] = tx_id

        return tx_record
