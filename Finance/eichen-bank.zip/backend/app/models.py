import enum
from datetime import datetime, timezone
from sqlalchemy import (
    Column,
    String,
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Enum as SQLEnum,
    Text,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class AccountType(str, enum.Enum):
    GIRO = "GIRO"
    FLEX_SPAREN = "FLEX_SPAREN"
    DEPOT = "DEPOT"

class TransactionStatus(str, enum.Enum):
    BOOKED = "BOOKED"
    PENDING = "PENDING"
    SCHEDULED = "SCHEDULED"
    DECLINED = "DECLINED"

class PaymentType(str, enum.Enum):
    SEPA_CREDIT = "SEPA_CREDIT"
    SEPA_INSTANT = "SEPA_INSTANT"
    CARD_PURCHASE = "CARD_PURCHASE"
    INTERNAL_TRANSFER = "INTERNAL_TRANSFER"

class Customer(Base):
    __tablename__ = "customers"

    id = Column(String(64), primary_key=True)
    full_name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    address = Column(String(512), nullable=False)
    kyc_status = Column(String(64), default="VERIFIED_VIDEOIDENT")
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    accounts = relationship("Account", back_populates="customer")

class Account(Base):
    __tablename__ = "accounts"

    id = Column(String(64), primary_key=True)
    customer_id = Column(String(64), ForeignKey("customers.id"), nullable=False)
    name = Column(String(128), nullable=False)
    iban = Column(String(34), unique=True, nullable=False)
    bic = Column(String(11), default="EICHDEFFXXX")
    account_type = Column(SQLEnum(AccountType), default=AccountType.GIRO)
    balance_cents = Column(BigInteger, default=0, nullable=False)
    available_balance_cents = Column(BigInteger, default=0, nullable=False)
    pending_holds_cents = Column(BigInteger, default=0, nullable=False)
    is_primary = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    customer = relationship("Customer", back_populates="accounts")
    postings = relationship("LedgerPosting", back_populates="account")

class LedgerTransaction(Base):
    """
    Auditable double-entry financial ledger transaction.
    Every financial event must balance sum(credits) == sum(debits).
    """
    __tablename__ = "ledger_transactions"

    id = Column(String(64), primary_key=True)
    idempotency_key = Column(String(128), unique=True, nullable=True)
    reference = Column(String(255), nullable=False)
    status = Column(SQLEnum(TransactionStatus), default=TransactionStatus.BOOKED)
    payment_type = Column(SQLEnum(PaymentType), default=PaymentType.SEPA_CREDIT)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    postings = relationship("LedgerPosting", back_populates="transaction")

class LedgerPosting(Base):
    """
    Individual debit/credit leg of a ledger transaction.
    amount_cents is positive for credit, negative for debit.
    """
    __tablename__ = "ledger_postings"

    id = Column(String(64), primary_key=True)
    transaction_id = Column(String(64), ForeignKey("ledger_transactions.id"), nullable=False)
    account_id = Column(String(64), ForeignKey("accounts.id"), nullable=False)
    amount_cents = Column(BigInteger, nullable=False)
    counterparty_name = Column(String(255), nullable=True)
    counterparty_iban = Column(String(34), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    transaction = relationship("LedgerTransaction", back_populates="postings")
    account = relationship("Account", back_populates="postings")
