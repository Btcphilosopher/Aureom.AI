from pydantic import BaseModel, Field, field_validator
from typing import Optional, List
from datetime import datetime
import re

class IbanValidator:
    @staticmethod
    def validate_german_iban(iban: str) -> str:
        clean = re.sub(r"\s+", "", iban).upper()
        if not clean.startswith("DE"):
            raise ValueError("Nur deutsche IBANs (beginnend mit DE) werden unterstützt")
        if len(clean) != 22:
            raise ValueError(f"Deutsche IBAN muss genau 22 Zeichen haben, aktuell {len(clean)}")
        return clean

class TransferRequest(BaseModel):
    recipient_name: str = Field(..., min_length=2, max_length=140)
    recipient_iban: str = Field(...)
    amount_cents: int = Field(..., gt=0, description="Amount in Euro cents (e.g. 5000 = 50.00 EUR)")
    reference: Optional[str] = Field(default="SEPA-Überweisung", max_length=140)
    is_instant: bool = Field(default=True)
    idempotency_key: Optional[str] = None
    source_account_id: str = Field(default="acc_hauptkonto")

    @field_validator("recipient_iban")
    @classmethod
    def check_iban(cls, v: str) -> str:
        return IbanValidator.validate_german_iban(v)

class TransferResponse(BaseModel):
    transaction_id: str
    status: str
    amount_cents: int
    recipient_name: str
    recipient_iban: str
    reference: str
    execution_timestamp: datetime
    receipt_code: str

class AccountSummaryResponse(BaseModel):
    id: str
    name: str
    iban: str
    bic: str
    account_type: str
    balance_cents: int
    available_balance_cents: int
    is_primary: bool

class CustomerProfileResponse(BaseModel):
    id: str
    full_name: str
    email: str
    address: str
    kyc_status: str
    accounts: List[AccountSummaryResponse]
