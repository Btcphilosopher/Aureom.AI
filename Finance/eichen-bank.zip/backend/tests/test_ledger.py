import pytest
from app.ledger import LedgerService
from app.schemas import IbanValidator

def test_iban_validation_valid():
    valid = "DE89 3704 0044 0532 0130 00"
    clean = IbanValidator.validate_german_iban(valid)
    assert clean == "DE89370400440532013000"

def test_iban_validation_invalid_prefix():
    with pytest.raises(ValueError, match="Nur deutsche IBANs"):
        IbanValidator.validate_german_iban("FR76 3000 6000 0112 3456 7890 189")

def test_iban_validation_invalid_length():
    with pytest.raises(ValueError, match="22 Zeichen"):
        IbanValidator.validate_german_iban("DE1234")

def test_ledger_transfer_success():
    service = LedgerService()
    account = service.get_account("acc_hauptkonto")
    initial_avail = account["available_balance_cents"]

    transfer_cents = 25000  # 250.00 EUR
    tx = service.execute_sepa_transfer(
        source_account_id="acc_hauptkonto",
        recipient_name="Sarah Schmidt",
        recipient_iban="DE44500105175544332211",
        amount_cents=transfer_cents,
        reference="Urlaub",
        is_instant=True
    )

    assert tx["status"] == "BOOKED"
    assert tx["amount_cents"] == -transfer_cents
    assert account["available_balance_cents"] == initial_avail - transfer_cents

def test_ledger_overdraft_protection():
    service = LedgerService()
    account = service.get_account("acc_hauptkonto")
    too_much = account["available_balance_cents"] + 100000

    with pytest.raises(ValueError, match="Nicht genügend Guthaben"):
        service.execute_sepa_transfer(
            source_account_id="acc_hauptkonto",
            recipient_name="Rich Person",
            recipient_iban="DE44500105175544332211",
            amount_cents=too_much,
            reference="Overdraft",
            is_instant=False
        )

def test_ledger_idempotency():
    service = LedgerService()
    idempotency_key = "req-unique-991284"

    tx1 = service.execute_sepa_transfer(
        source_account_id="acc_hauptkonto",
        recipient_name="Alexander Weber",
        recipient_iban="DE92100700000123456789",
        amount_cents=5000,
        reference="Idempotent test",
        is_instant=True,
        idempotency_key=idempotency_key
    )

    # Second call with same idempotency key must not debit again
    tx2 = service.execute_sepa_transfer(
        source_account_id="acc_hauptkonto",
        recipient_name="Alexander Weber",
        recipient_iban="DE92100700000123456789",
        amount_cents=5000,
        reference="Idempotent test",
        is_instant=True,
        idempotency_key=idempotency_key
    )

    assert tx1["transaction_id"] == tx2["transaction_id"]
    assert tx1["receipt_code"] == tx2["receipt_code"]
