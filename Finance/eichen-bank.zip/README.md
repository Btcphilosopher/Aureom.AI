# Eichen Bank — German Fintech Mobile Banking & Digital Wallet

Eichen Bank is a modern, production-grade Android mobile banking and digital wallet application designed for customers in Germany. The product pairs German engineering precision with European financial sophistication, disciplined Bauhaus-inspired typography, and an authoritative double-entry accounting architecture.

---

## 🏛️ Architecture & Highlights

- **Visual Design & German Precision**:
  - Restrained Swiss & Bauhaus layout principles with Google Font **Plus Jakarta Sans**.
  - Deep graphite (`#111215`), warm white surface, muted Germanic forest green (`#1E5E41`), and subtle German national flag micro-accents (Schwarz-Rot-Gold).
  - Exact German currency notation (e.g., `12.482,36 €`), DIN 5008 date formatting, and 4-block IBAN formatting.
  - Discrete privacy mode to mask/unmask balances with a single tap.
  - Custom adaptive luxury launcher icon generated with geometric oak acorn & vault monogram.

- **5 Core Banking Modules**:
  1. **Übersicht (Overview)**: Total available balance, daily delta movement indicator, quick actions (*Senden, Empfangen, Karte, Sparen*), multi-account breakdown (*Hauptkonto, Flex-Sparen, Depot*), and recent booked & pending transactions.
  2. **Karten (Cards & Digital Wallet)**: Virtual and physical debit cards, card freeze/unfreeze toggles, online payments switch, NFC contactless toggle, ATM withdrawal permission, monthly limit controls, secure PIN & CVV reveal, and Google Wallet / Apple Pay tokenization status.
  3. **Zahlungen (Payments & Transfers)**: Complete SEPA and SEPA-Instant transfer flow with inline **ISO 7064 Modulo 97 IBAN checksum validation**, saved beneficiaries, 2FA/SCA authorization, transaction reference, instant EPC-QR / GiroCode generation, and active standing orders (*Daueraufträge*).
  4. **Sparen & Spaces**: Goal-based savings spaces (*Notgroschen, Sommerurlaub, Technik*), 3.25% p.a. daily-access interest on *Flex-Sparen*, interactive deposits/withdrawals with authoritative ledger balance recalculation, and spending breakdown by category.
  5. **Profil & Sicherheit**: Verified KYC status via VideoIdent (GwG), biometric authentication toggle, registered security device management, BaFin and statutory deposit insurance (*Einlagensicherung bis 100.000 € gem. EinSiG*) disclosures, emergency card block hotline (*Sperr-Notruf 116 116*), and one-tap demo reset.

---

## 💻 Tech Stack

### Android Frontend
- **Language**: Kotlin 2.2.10
- **UI Framework**: Jetpack Compose with Material 3
- **Architecture**: MVVM with unidirectional data flow (`StateFlow`, `collectAsStateWithLifecycle`)
- **Typography**: Local static `.ttf` Google Font (*Plus Jakarta Sans*) via `font-util`
- **Testing**: Robolectric test runner & local JVM unit tests (`:app:testDebugUnitTest`)

### Backend & Infrastructure (`backend/`)
- **API Framework**: Python 3.12+ with FastAPI & Pydantic v2
- **Database & Ledger**: PostgreSQL 16 with double-entry accounting principles
- **Deployment**: Docker & Docker Compose configuration (`docker-compose.yml`)

---

## 🧪 Testing

To run the Android Robolectric and business logic test suite:
```bash
gradle :app:testDebugUnitTest
```
Tests verify:
- Resource string integrity
- Exact German currency formatting and masking
- ISO 7064 Modulo 97 German IBAN checksum verification
- Authoritative SEPA transfer execution & ledger debit
- Overdraft protection (preventing transfers exceeding available balance)
- Card controls (freeze, limits)
- Savings goals deposit and withdrawal synchronization
