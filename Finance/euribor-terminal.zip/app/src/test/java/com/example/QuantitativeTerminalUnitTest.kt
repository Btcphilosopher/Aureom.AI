package com.example

import com.example.domain.engine.CalendarEngine
import com.example.domain.engine.CurveConstructionEngine
import com.example.domain.engine.FraAndFuturesEngine
import com.example.domain.engine.RqqlCommandEngine
import com.example.domain.engine.SwapPricingEngine
import com.example.domain.engine.VolatilityAndOptionsEngine
import com.example.domain.model.CurveType
import com.example.domain.model.DayCountConvention
import com.example.domain.model.TradeDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import kotlin.math.abs

class QuantitativeTerminalUnitTest {

    @Test
    fun testTarget2CalendarHolidays() {
        // TARGET2 is closed on New Year's Day, Good Friday, Easter Monday, Labour Day (May 1), Christmas Day (Dec 25), Boxing Day (Dec 26), and weekends
        val newYear2026 = LocalDate.of(2026, 1, 1)
        val labourDay2026 = LocalDate.of(2026, 5, 1)
        val christmas2026 = LocalDate.of(2026, 12, 25)
        val saturday = LocalDate.of(2026, 10, 10)
        val businessWednesday = LocalDate.of(2026, 10, 7)

        assertFalse("New Year's Day should be closed on TARGET2", CalendarEngine.isTargetBusinessDay(newYear2026))
        assertFalse("Labour Day should be closed on TARGET2", CalendarEngine.isTargetBusinessDay(labourDay2026))
        assertFalse("Christmas should be closed on TARGET2", CalendarEngine.isTargetBusinessDay(christmas2026))
        assertFalse("Saturday should be closed on TARGET2", CalendarEngine.isTargetBusinessDay(saturday))
        assertTrue("Wednesday Oct 7 should be an open TARGET2 business day", CalendarEngine.isTargetBusinessDay(businessWednesday))
    }

    @Test
    fun testDayCountConventions() {
        val d1 = LocalDate.of(2026, 1, 1)
        val d2 = LocalDate.of(2026, 7, 1) // 181 days
        val tauAct360 = CalendarEngine.yearFraction(d1, d2, DayCountConvention.ACT_360)
        val tauAct365 = CalendarEngine.yearFraction(d1, d2, DayCountConvention.ACT_365F)
        val tau30360 = CalendarEngine.yearFraction(d1, d2, DayCountConvention.THIRTY_360)

        assertEquals(181.0 / 360.0, tauAct360, 1e-6)
        assertEquals(181.0 / 365.0, tauAct365, 1e-6)
        assertEquals(180.0 / 360.0, tau30360, 1e-6)
    }

    @Test
    fun testDiscountFactorCurveMonotonicity() {
        val testCurve = CurveConstructionEngine.buildCurve(
            id = "TEST_CURVE",
            type = CurveType.ESTR_DISCOUNT,
            asOfDate = "2026-10-07",
            nodes = listOf(
                0.25 to 3.20,
                0.50 to 3.10,
                1.00 to 3.00,
                2.00 to 2.80,
                5.00 to 2.60
            )
        )

        val warnings = CurveConstructionEngine.checkArbitrageConsistency(testCurve)
        assertTrue("Well-formed curve should have zero arbitrage warnings", warnings.isEmpty())

        // Positive interest rate curve must have decreasing discount factors over time
        val df1Y = testCurve.discountFactorAt(1.0)
        val df2Y = testCurve.discountFactorAt(2.0)
        val df5Y = testCurve.discountFactorAt(5.0)

        assertTrue(df1Y > df2Y)
        assertTrue(df2Y > df5Y)
    }

    @Test
    fun testForwardRateReconstructionInvariant() {
        // Mathematical invariant: F(t1, t2) = (1 / tau) * [ P(t1) / P(t2) - 1 ]
        val curve = CurveConstructionEngine.buildCurve(
            id = "EURIBOR_PROJ",
            type = CurveType.EURIBOR_3M_PROJECTION,
            asOfDate = "2026-10-07",
            nodes = listOf(
                0.25 to 3.238,
                0.50 to 3.276,
                1.00 to 3.291
            )
        )

        val t1 = 0.25
        val t2 = 0.50
        val tau = 0.25
        val fwd = CurveConstructionEngine.calculateForwardRate(curve, t1, t2)

        val p1 = curve.discountFactorAt(t1)
        val p2 = curve.discountFactorAt(t2)
        val expectedFwd = (p1 / p2 - 1.0) / tau * 100.0

        assertEquals(expectedFwd, fwd, 1e-5)
    }

    @Test
    fun testParSwapHasZeroNpvInvariant() {
        // Mathematical invariant: A swap evaluated with fixed rate equal to its par rate must have ~0 NPV
        val estrDisc = CurveConstructionEngine.buildCurve(
            id = "ESTR_DISC",
            type = CurveType.ESTR_DISCOUNT,
            asOfDate = "2026-10-07",
            nodes = listOf(
                0.25 to 3.15,
                1.00 to 3.10,
                2.00 to 2.90,
                5.00 to 2.65
            )
        )
        val euriborProj = CurveConstructionEngine.buildCurve(
            id = "EURIBOR_PROJ",
            type = CurveType.EURIBOR_3M_PROJECTION,
            asOfDate = "2026-10-07",
            nodes = listOf(
                0.25 to 3.238,
                1.00 to 3.291,
                2.00 to 3.080,
                5.00 to 2.810
            )
        )

        // First find par rate
        val initialSwap = SwapPricingEngine.priceSwap(
            tradeId = "TEST_SWP_01",
            book = "TEST",
            desk = "TEST",
            counterparty = "TEST",
            notionalEur = 10_000_000.0,
            direction = TradeDirection.PAY_FIXED,
            fixedRatePercent = 2.80,
            floatingIndex = "Euribor 3M",
            maturityYears = 5.0,
            discountCurveEstr = estrDisc,
            projectionCurveEuribor = euriborProj
        )

        val parRate = initialSwap.parRate

        // Reprice with fixedRate = parRate
        val parSwap = SwapPricingEngine.priceSwap(
            tradeId = "TEST_SWP_02",
            book = "TEST",
            desk = "TEST",
            counterparty = "TEST",
            notionalEur = 10_000_000.0,
            direction = TradeDirection.PAY_FIXED,
            fixedRatePercent = parRate,
            floatingIndex = "Euribor 3M",
            maturityYears = 5.0,
            discountCurveEstr = estrDisc,
            projectionCurveEuribor = euriborProj
        )

        // NPV should be 0 within small numerical rounding (< EUR 1 on EUR 10M notional)
        assertTrue("Par swap NPV should be approximately 0. Was: ${parSwap.npvEur}", abs(parSwap.npvEur) < 1.0)
    }

    @Test
    fun testBachelierCallPutParity() {
        // Under Bachelier normal vol model:
        // Call(F, K) - Put(F, K) = D(T) * tau * (F - K)
        val fwd = 0.0320
        val strike = 0.0300
        val t = 1.0
        val vol = 0.0050
        val df = 0.968
        val tau = 0.25

        val call = VolatilityAndOptionsEngine.bachelierPrice(isCallOrPayer = true, fwd, strike, t, vol, df, tau)
        val put = VolatilityAndOptionsEngine.bachelierPrice(isCallOrPayer = false, fwd, strike, t, vol, df, tau)

        val diff = call - put
        val parity = df * tau * (fwd - strike)

        assertEquals(parity, diff, 1e-7)
    }

    @Test
    fun testFraPricingAndBreakeven() {
        val estrDisc = CurveConstructionEngine.buildCurve(
            id = "ESTR_DISC",
            type = CurveType.ESTR_DISCOUNT,
            asOfDate = "2026-10-07",
            nodes = listOf(0.25 to 3.15, 0.50 to 3.15, 1.00 to 3.15)
        )
        val euriborProj = CurveConstructionEngine.buildCurve(
            id = "EURIBOR_PROJ",
            type = CurveType.EURIBOR_3M_PROJECTION,
            asOfDate = "2026-10-07",
            nodes = listOf(0.25 to 3.238, 0.50 to 3.276, 1.00 to 3.291)
        )

        val fra = FraAndFuturesEngine.priceFra(
            tradeId = "FRA_TEST",
            tenorPair = "3x6",
            notionalEur = 10_000_000.0,
            fixedRatePercent = 3.25,
            discountCurveEstr = estrDisc,
            euriborProjectionCurve = euriborProj
        )

        // Breakeven rate equals the forward rate
        assertEquals(fra.referenceRate, fra.breakevenRate, 1e-6)
    }

    @Test
    fun testRqqlCommandParser() {
        val res1 = RqqlCommandEngine.execute("EURIBOR 3M")
        assertEquals("SUCCESS", res1.status)
        assertTrue(res1.primaryMessage.contains("EURIBOR 3M Fixing"))

        val res2 = RqqlCommandEngine.execute("BASIS 3M/6M")
        assertEquals("SUCCESS", res2.status)

        val res3 = RqqlCommandEngine.execute("HELP")
        assertEquals("SUCCESS", res3.status)
        assertTrue(res3.details.isNotEmpty())
    }
}
