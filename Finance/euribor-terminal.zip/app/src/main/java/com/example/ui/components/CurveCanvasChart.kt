package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CurveNode
import com.example.domain.model.YieldCurve
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPurpleMuted
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

@Composable
fun CurveCanvasChart(
    primaryCurve: YieldCurve,
    secondaryCurve: YieldCurve? = null,
    tertiaryCurve: YieldCurve? = null,
    chartTitle: String = "EURIBOR TERM STRUCTURE",
    modifier: Modifier = Modifier
) {
    var selectedNode by remember { mutableStateOf<CurveNode?>(null) }
    var selectedCurveName by remember { mutableStateOf("Euribor 3M") }

    val allNodes = primaryCurve.nodes + (secondaryCurve?.nodes ?: emptyList()) + (tertiaryCurve?.nodes ?: emptyList())
    val minRate = (allNodes.minOfOrNull { it.zeroRate } ?: 2.4).coerceAtLeast(0.0) - 0.20
    val maxRate = (allNodes.maxOfOrNull { it.zeroRate } ?: 3.5) + 0.20

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(TerminalPanel, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
            .testTag("curve_chart_$chartTitle")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header bar & legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = chartTitle,
                    color = TerminalTextPrimary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    LegendItem(label = primaryCurve.curveType.displayName.split(" ").firstOrNull() ?: "Euribor", color = TerminalCyanBlue)
                    if (secondaryCurve != null) {
                        Spacer(modifier = Modifier.width(10.dp))
                        LegendItem(label = secondaryCurve.curveType.displayName.split(" ").firstOrNull() ?: "€STR", color = TerminalPurpleMuted)
                    }
                    if (tertiaryCurve != null) {
                        Spacer(modifier = Modifier.width(10.dp))
                        LegendItem(label = "Comparison", color = TerminalGold)
                    }
                }
            }

            // Interactive Node details inspect panel
            if (selectedNode != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 2.dp)
                        .background(TerminalSurface, RoundedCornerShape(3.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "NODE: ${selectedNode!!.tenorLabel} (${selectedCurveName})",
                        color = TerminalCyanBlue,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Rate: ${String.format("%.3f", selectedNode!!.zeroRate)}%  |  DF: ${String.format("%.4f", selectedNode!!.discountFactor)}",
                        color = TerminalTextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                Text(
                    text = "Tap on any curve point to inspect maturity & discount factor",
                    color = TerminalTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // Canvas drawing area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .pointerInput(primaryCurve) {
                        detectTapGestures { offset ->
                            // Find closest node
                            val w = size.width
                            val padLeft = 40f
                            val padRight = 20f
                            val plotWidth = w - padLeft - padRight

                            val candidate = primaryCurve.nodes.minByOrNull { node ->
                                val x = padLeft + (logMaturityX(node.maturityYears) * plotWidth)
                                kotlin.math.abs(offset.x - x)
                            }
                            if (candidate != null) {
                                selectedNode = candidate
                                selectedCurveName = primaryCurve.curveType.displayName
                            }
                        }
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val padLeft = 40f
                    val padRight = 20f
                    val padTop = 15f
                    val padBottom = 25f

                    val plotW = size.width - padLeft - padRight
                    val plotH = size.height - padTop - padBottom

                    fun rateToY(rate: Double): Float {
                        val fraction = (rate - minRate) / (maxRate - minRate)
                        return (padTop + plotH * (1f - fraction.toFloat())).coerceIn(padTop, padTop + plotH)
                    }

                    fun matToX(mat: Double): Float {
                        return padLeft + (logMaturityX(mat) * plotW).coerceIn(0f, plotW)
                    }

                    // Draw Horizontal Grid Lines
                    val gridSteps = 4
                    for (i in 0..gridSteps) {
                        val r = minRate + (maxRate - minRate) * (i / gridSteps.toDouble())
                        val y = rateToY(r)
                        drawLine(
                            color = TerminalBorderSubtle,
                            start = Offset(padLeft, y),
                            end = Offset(size.width - padRight, y),
                            strokeWidth = 1f
                        )
                    }

                    // Helper to draw single curve
                    fun drawYieldCurve(nodes: List<CurveNode>, color: Color, strokeWidth: Float) {
                        if (nodes.isEmpty()) return
                        val path = Path()
                        nodes.forEachIndexed { i, node ->
                            val x = matToX(node.maturityYears)
                            val y = rateToY(node.zeroRate)
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        drawPath(path = path, color = color, style = Stroke(width = strokeWidth))

                        // Draw node points
                        nodes.forEach { node ->
                            val x = matToX(node.maturityYears)
                            val y = rateToY(node.zeroRate)
                            drawCircle(color = color, radius = 4f, center = Offset(x, y))
                            drawCircle(color = TerminalPanel, radius = 2f, center = Offset(x, y))
                        }
                    }

                    // Draw secondary curve
                    secondaryCurve?.let { sec ->
                        drawYieldCurve(sec.nodes, TerminalPurpleMuted, 2f)
                    }

                    // Draw tertiary curve
                    tertiaryCurve?.let { ter ->
                        drawYieldCurve(ter.nodes, TerminalGold, 2f)
                    }

                    // Draw primary curve
                    drawYieldCurve(primaryCurve.nodes, TerminalCyanBlue, 3f)

                    // Draw selected node highlight
                    selectedNode?.let { sel ->
                        val x = matToX(sel.maturityYears)
                        val y = rateToY(sel.zeroRate)
                        drawCircle(color = Color.White, radius = 6f, center = Offset(x, y), style = Stroke(width = 2f))
                    }
                }
            }

            // X-Axis Tenor Labels
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 30.dp, end = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("1W", "1M", "3M", "6M", "1Y", "2Y", "5Y", "10Y", "30Y").forEach { label ->
                    Text(
                        text = label,
                        color = TerminalTextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

/**
 * Logarithmic mapping for maturities (dense at short end 1W-1Y, compressed at 10Y-30Y)
 */
private fun logMaturityX(years: Double): Float {
    val minLog = ln(0.015) // ~1W
    val maxLog = ln(30.0)
    val curLog = ln(years.coerceIn(0.015, 30.0))
    return ((curLog - minLog) / (maxLog - minLog)).toFloat().coerceIn(0f, 1f)
}

@Composable
private fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = TerminalTextSecondary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
