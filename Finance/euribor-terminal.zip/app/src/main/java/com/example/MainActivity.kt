package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.InstitutionalHeader
import com.example.ui.screens.BasisEstrScreen
import com.example.ui.screens.CurveScreen
import com.example.ui.screens.ForwardsFuturesScreen
import com.example.ui.screens.FraOptionsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MethodologyAuditScreen
import com.example.ui.screens.MoneyMarketFundingScreen
import com.example.ui.screens.PortfolioBlotterScreen
import com.example.ui.screens.RiskScenarioScreen
import com.example.ui.screens.RqqlConsoleScreen
import com.example.ui.screens.SwapsOisScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val terminalVm: TerminalViewModel = viewModel()
                TerminalApp(viewModel = terminalVm)
            }
        }
    }
}

val WORKSPACE_TABS = listOf(
    "HOME" to "Fixings Monitor",
    "CURVE" to "Term Structure",
    "BASIS" to "€STR Rel Value",
    "SWAPS" to "IRS Multi-Curve",
    "FORWARDS" to "3M Futures",
    "OPTIONS" to "FRAs & Caps",
    "FUNDING" to "Money Markets",
    "RISK" to "KRD & Scenarios",
    "BLOTTER" to "Rates Portfolio",
    "AUDIT" to "EMMI Waterfall",
    "CONSOLE" to "RQ-RATES RQQL"
)

@Composable
fun TerminalApp(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val activeWorkspace by viewModel.activeWorkspace.collectAsState()
    val portfolio by viewModel.portfolio.collectAsState()

    // Handle Android system back gesture to navigate to HOME workspace if inside another tab
    BackHandler(enabled = activeWorkspace != 0) {
        viewModel.setWorkspace(0)
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TerminalPanel)
        ) {
            // Institutional Rates Desk Header
            InstitutionalHeader(
                onOpenConsole = { viewModel.setWorkspace(10) }
            )

            // Scrollable Institutional Workspaces Navigation Ribbon
            WorkspaceNavigationRibbon(
                activeWorkspace = activeWorkspace,
                onSelectWorkspace = { viewModel.setWorkspace(it) }
            )

            // Primary Screen Content Workspace
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (activeWorkspace) {
                    0 -> HomeScreen(viewModel = viewModel, onNavigateToWorkspace = { viewModel.setWorkspace(it) })
                    1 -> CurveScreen(viewModel = viewModel)
                    2 -> BasisEstrScreen(viewModel = viewModel)
                    3 -> SwapsOisScreen(viewModel = viewModel)
                    4 -> ForwardsFuturesScreen(viewModel = viewModel)
                    5 -> FraOptionsScreen(viewModel = viewModel)
                    6 -> MoneyMarketFundingScreen()
                    7 -> RiskScenarioScreen(viewModel = viewModel)
                    8 -> PortfolioBlotterScreen(viewModel = viewModel)
                    9 -> MethodologyAuditScreen()
                    10 -> RqqlConsoleScreen(viewModel = viewModel)
                    else -> HomeScreen(viewModel = viewModel, onNavigateToWorkspace = { viewModel.setWorkspace(it) })
                }
            }

            // Terminal Footer Status Ribbon
            TerminalFooterStatus(
                totalDv01 = portfolio.totalDv01Eur,
                dailyPnl = portfolio.dailyPnlEur,
                activeWorkspaceName = WORKSPACE_TABS.getOrNull(activeWorkspace)?.first ?: "HOME"
            )
        }
    }
}

@Composable
private fun WorkspaceNavigationRibbon(
    activeWorkspace: Int,
    onSelectWorkspace: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(0.5.dp, TerminalBorder)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 5.dp)
            .testTag("workspace_navigation_ribbon"),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        WORKSPACE_TABS.forEachIndexed { index, (name, subtitle) ->
            val isActive = (activeWorkspace == index)
            Box(
                modifier = Modifier
                    .background(
                        if (isActive) TerminalCyanBlue else TerminalSurfaceElevated,
                        RoundedCornerShape(3.dp)
                    )
                    .border(
                        0.5.dp,
                        if (isActive) TerminalCyanBlue else TerminalBorder,
                        RoundedCornerShape(3.dp)
                    )
                    .clickable { onSelectWorkspace(index) }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
                    .testTag("nav_tab_${name.lowercase()}")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = name,
                        color = if (isActive) TerminalPanel else TerminalTextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = subtitle,
                        color = if (isActive) TerminalPanel.copy(alpha = 0.8f) else TerminalTextMuted,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun TerminalFooterStatus(
    totalDv01: Double,
    dailyPnl: Double,
    activeWorkspaceName: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(0.5.dp, TerminalBorder)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "WS: $activeWorkspaceName",
                color = TerminalCyanBlue,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "DV01: €${String.format("%,.0f", totalDv01)}",
                color = TerminalTextSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "DAY P&L: +€${String.format("%,.0f", dailyPnl)}",
                color = TerminalPositive,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "RHINOQUANT RATES v3.7",
                color = TerminalTextMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
