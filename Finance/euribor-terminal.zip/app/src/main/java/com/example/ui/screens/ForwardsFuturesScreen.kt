package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.CurveConstructionEngine
import com.example.domain.engine.FraAndFuturesEngine
import com.example.domain.model.DataClassification
import com.example.domain.model.EuriborFutureContract
import com.example.domain.model.ForwardRatePoint
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun ForwardsFuturesScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val euribor3mCurve by viewModel.euribor3mCurve.collectAsState()
    val forwardPoints = CurveConstructionEngine.generateForwardCurve(euribor3mCurve, 3)
    val futuresContracts = FraAndFuturesEngine.getFuturesContracts(euribor3mCurve)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_forwards_futures")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "FORWARD RATES & 3M FUTURES",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.MARKET)
            }
            Text(
                text = "EURIBOR 3M STIR FUTURES",
                color = TerminalTextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3M Euribor Futures (IMM Quarterly Contracts) Table
        Text(
            text = "3M EURIBOR FUTURES CONTRACTS (IMM LIQUID STRIP)",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("CONTRACT", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                Text("EXPIRY", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("PRICE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("IMPLIED RATE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("CONVEXITY (BP)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                Text("VOLUME", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("OPEN INT", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
            }

            futuresContracts.forEach { contract ->
                FutureContractRow(contract)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Forward Curve Table F(t1, t2)
        Text(
            text = "EURIBOR 3M IMPLIED FORWARD CURVE MATRIX",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("HORIZON", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.6f))
                Text("TENOR WINDOW", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("FORWARD RATE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("SPOT SPREAD", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("NORMAL VOL", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
            }

            forwardPoints.forEach { pt ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(pt.forwardLabel, color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.6f))
                    Text("${String.format("%.2f", pt.startYears)}Y - ${String.format("%.2f", pt.endYears)}Y", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                    Text("${String.format("%.3f", pt.impliedForwardRate)}%", color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
                    val spreadStr = if (pt.forwardSpreadBp >= 0) "+${String.format("%.1f", pt.forwardSpreadBp)} bp" else "${String.format("%.1f", pt.forwardSpreadBp)} bp"
                    Text(spreadStr, color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                    Text("${String.format("%.1f", pt.forwardVolatilityNorm)} bp", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                }
            }
        }
    }
}

@Composable
private fun FutureContractRow(contract: EuriborFutureContract) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(contract.contractCode, color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
        Text(contract.expiryDate, color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
        Text(String.format("%.3f", contract.marketPrice), color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f))
        Text("${String.format("%.3f", contract.impliedRate)}%", color = TerminalPositive, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.3f))
        Text("+${String.format("%.1f", contract.basisVsForwardCurveBp)} bp", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
        Text(String.format("%,d", contract.volume), color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
        Text(String.format("%,d", contract.openInterest), color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
    }
}
