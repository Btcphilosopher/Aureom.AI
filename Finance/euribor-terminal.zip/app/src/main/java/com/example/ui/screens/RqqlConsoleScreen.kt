package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.RqqlCommandEngine
import com.example.domain.engine.RqqlResult
import com.example.domain.model.DataClassification
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RqqlConsoleScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val input by viewModel.commandInput.collectAsState()
    val history by viewModel.commandHistory.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .padding(12.dp)
            .testTag("workspace_rqql_console")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "RQ-RATES COMMAND CONSOLE (RQQL)",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.OFFICIAL)
            }
            Text(
                text = "QUERY PARSER v3.7",
                color = TerminalTextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Suggestion Chips
        Text(
            text = "QUICK COMMAND SHORTCUTS:",
            color = TerminalTextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(4.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            RqqlCommandEngine.SAMPLE_COMMANDS.take(8).forEach { sampleCmd ->
                Box(
                    modifier = Modifier
                        .background(TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                        .border(0.5.dp, TerminalBorder, RoundedCornerShape(3.dp))
                        .clickable { viewModel.executeQuickCommand(sampleCmd) }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = sampleCmd,
                        color = TerminalCyanBlue,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Interactive Input Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { viewModel.onCommandInputChange(it) },
                placeholder = {
                    Text(
                        text = "Enter query (e.g. 'EURIBOR 3M', 'STRESS CURVE +25BP', 'HELP')...",
                        color = TerminalTextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_rqql_command"),
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = TerminalTextPrimary
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TerminalCyanBlue,
                    unfocusedBorderColor = TerminalBorder,
                    focusedContainerColor = TerminalSurface,
                    unfocusedContainerColor = TerminalSurface
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { viewModel.executeCurrentCommand() })
            )

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = { viewModel.executeCurrentCommand() },
                modifier = Modifier
                    .background(TerminalCyanBlue, RoundedCornerShape(4.dp))
                    .testTag("btn_execute_rqql")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Execute Query",
                    tint = TerminalPanel
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // History Output Log
        Text(
            text = "TERMINAL EXECUTION LOG & QUERY RESULTS",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .verticalScroll(rememberScrollState())
                .padding(8.dp)
        ) {
            if (history.isEmpty()) {
                Text(
                    text = "No queries executed yet. Type HELP or select a quick shortcut.",
                    color = TerminalTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            } else {
                history.forEach { item ->
                    QueryResultItem(item)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun QueryResultItem(res: RqqlResult) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
            .border(0.5.dp, TerminalBorderSubtle, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "> ${res.command}",
                    color = TerminalCyanBlue,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = res.classification)
            }
            Text(
                text = "[${res.status}]",
                color = TerminalPositive,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = res.primaryMessage,
            color = TerminalTextPrimary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )

        if (res.details.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            res.details.forEach { (k, v) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 1.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(k, color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text(v, color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}
