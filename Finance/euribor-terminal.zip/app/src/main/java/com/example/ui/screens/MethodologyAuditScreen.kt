package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TerminalRepository
import com.example.domain.engine.EuriborMethodologyEngine
import com.example.domain.model.DataClassification
import com.example.domain.model.EuriborRevisionRecord
import com.example.domain.model.MethodologyTenorUsage
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun MethodologyAuditScreen(
    repository: TerminalRepository = TerminalRepository(),
    modifier: Modifier = Modifier
) {
    val waterfall = EuriborMethodologyEngine.getTransparencyWaterfallDistribution()
    val revisions = EuriborMethodologyEngine.getHistoricalRevisions()
    val provenanceRecords = repository.provenanceRecords

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_methodology_audit")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "EMMI METHODOLOGY & REVISION MONITOR",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.OFFICIAL)
            }
            Text(
                text = "HYBRID WATERFALL v4.2",
                color = TerminalTextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Mandatory Regulatory Safeguard Disclaimer Notice Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalAmber.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "CRITICAL REGULATORY NOTICE & SAFEGUARD:",
                    color = TerminalAmber,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = EuriborMethodologyEngine.getMethodologyLegalDisclaimer(),
                    color = TerminalTextPrimary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 13.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Current Methodology Specifications
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "EURIBOR BENCHMARK GOVERNANCE & FRAMEWORK",
                color = TerminalCyanBlue,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            SpecLine("Administrator", EuriborMethodologyEngine.ADMINISTRATOR)
            SpecLine("Current Version", EuriborMethodologyEngine.CURRENT_FRAMEWORK_VERSION)
            SpecLine("Effective Date", EuriborMethodologyEngine.EFFECTIVE_DATE)
            SpecLine("Publication Time", EuriborMethodologyEngine.PUBLICATION_TIME_CET)
            SpecLine("Intraday Refixing Cutoff", EuriborMethodologyEngine.REFIXING_CUTOFF_CET)
            SpecLine("Regulatory Status", "Critical Benchmark under EU Benchmark Regulation (EU BMR)")
        }

        Spacer(modifier = Modifier.height(14.dp))

        // EMMI Transparency Waterfall Breakdown Table
        Text(
            text = "EMMI TRANSPARENCY INDICATORS: WATERFALL LEVEL USAGE",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TENOR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("LVL 1 (TX)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("LVL 2.1 (INT)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("LVL 2.2 (ROLL)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("LVL 2.3 (MOD)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("LVL 3", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                Text("VOL (EUR M)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
            }

            waterfall.forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(item.tenor.code, color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.0f))
                    Text("${item.level1Percent}%", color = TerminalPositive, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                    Text("${item.level2_1Percent}%", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("${item.level2_2Percent}%", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("${item.level2_3Percent}%", color = TerminalAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("${item.level3Percent}%", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text("€${String.format("%,.0f", item.transactionVolumeEurMln)}M", color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Historical Refixing & Revision Events Log
        Text(
            text = "EURIBOR BENCHMARK REVISION LOG (REFIXING MONITOR)",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("REV ID", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                Text("DATE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("TENOR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("ORIGINAL", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("REVISED", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("DELTA", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("CATEGORY", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(2.0f))
            }

            revisions.forEach { rev ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(rev.revisionId, color = TerminalCyanBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                    Text(rev.affectedDate, color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text(rev.affectedTenor.code, color = TerminalTextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.0f))
                    Text("${rev.originalFixing}%", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    Text("${rev.revisedFixing}%", color = TerminalPositive, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f))
                    val dStr = if (rev.revisionAmountBp > 0) "+${rev.revisionAmountBp} bp" else "${rev.revisionAmountBp} bp"
                    Text(dStr, color = TerminalAmber, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                    Text(rev.category, color = TerminalTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(2.0f))
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Data Provenance & Integrity Hashes
        Text(
            text = "DATA PROVENANCE & INTEGRITY AUDIT",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            provenanceRecords.forEach { prov ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(0.5.dp, TerminalBorderSubtle, RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(prov.datasetName, color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Text(prov.publisher, color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                    Text("Publication: ${prov.publicationDate} | Retriev: ${prov.retrievalTimestamp}", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text("SHA256: ${prov.checksumSha256}", color = TerminalTextMuted, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
                    Text("Status: ${prov.licenseStatus} (${prov.regulatoryClassification})", color = TerminalPositive, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun SpecLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalTextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
    }
}
