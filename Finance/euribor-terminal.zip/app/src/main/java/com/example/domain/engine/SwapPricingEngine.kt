package com.example.domain.engine

import com.example.domain.model.Cashflow
import com.example.domain.model.DayCountConvention
import com.example.domain.model.InterestRateSwap
import com.example.domain.model.TradeDirection
import com.example.domain.model.YieldCurve
import java.time.LocalDate

object SwapPricingEngine {

    /**
     * Prices an institutional Fixed-for-Floating Interest Rate Swap under the modern multi-curve framework:
     * - Float leg forward rates projected off the Euribor projection curve (e.g. Euribor 3M or 6M)
     * - Both fixed and float cashflows discounted on the €STR OIS discount curve
     */
    fun priceSwap(
        tradeId: String,
        book: String,
        desk: String,
        counterparty: String,
        notionalEur: Double,
        direction: TradeDirection,
        fixedRatePercent: Double,
        floatingIndex: String,
        maturityYears: Double,
        discountCurveEstr: YieldCurve,
        projectionCurveEuribor: YieldCurve,
        fixedFrequencyMonths: Int = 12,
        floatFrequencyMonths: Int = if (floatingIndex.contains("6M")) 6 else 3,
        dayCount: DayCountConvention = DayCountConvention.ACT_360
    ): InterestRateSwap {
        val today = LocalDate.of(2026, 10, 8)
        val maturityDate = today.plusMonths((maturityYears * 12).toLong())

        val fixedPeriods = (maturityYears * 12 / fixedFrequencyMonths).toInt().coerceAtLeast(1)
        val floatPeriods = (maturityYears * 12 / floatFrequencyMonths).toInt().coerceAtLeast(1)

        // Generate schedule for float leg & fixed leg
        val schedule = mutableListOf<Cashflow>()
        var fixedPv = 0.0
        var floatPv = 0.0
        var pv01Sum = 0.0

        // Float leg cashflows
        val dtFloat = floatFrequencyMonths / 12.0
        for (i in 1..floatPeriods) {
            val tEnd = i * dtFloat
            val tStart = (i - 1) * dtFloat
            val fwdRate = CurveConstructionEngine.calculateForwardRate(projectionCurveEuribor, tStart, tEnd)
            val df = discountCurveEstr.discountFactorAt(tEnd)
            val payment = notionalEur * (fwdRate / 100.0) * dtFloat
            val pv = payment * df
            floatPv += pv

            schedule.add(
                Cashflow(
                    paymentDate = today.plusDays((tEnd * 365).toLong()).toString(),
                    periodStart = today.plusDays((tStart * 365).toLong()).toString(),
                    periodEnd = today.plusDays((tEnd * 365).toLong()).toString(),
                    yearFraction = dtFloat,
                    forwardOrFixedRate = fwdRate,
                    discountFactor = df,
                    paymentAmountEur = payment,
                    presentValueEur = pv
                )
            )
        }

        // Fixed leg annuity
        val dtFixed = fixedFrequencyMonths / 12.0
        for (i in 1..fixedPeriods) {
            val tEnd = i * dtFixed
            val df = discountCurveEstr.discountFactorAt(tEnd)
            val payment = notionalEur * (fixedRatePercent / 100.0) * dtFixed
            val pv = payment * df
            fixedPv += pv
            pv01Sum += notionalEur * 0.0001 * dtFixed * df
        }

        // Par swap rate: fixed rate that sets floatPv == fixedPv
        val annuity = pv01Sum / (notionalEur * 0.0001)
        val parRate = if (annuity > 0) (floatPv / (notionalEur * annuity)) * 100.0 else fixedRatePercent

        // Net Present Value depends on pay/receive fixed direction
        val npv = when (direction) {
            TradeDirection.PAY_FIXED -> floatPv - fixedPv
            TradeDirection.RECEIVE_FIXED -> fixedPv - floatPv
        }

        // DV01 (Dollar/Euro Value of a Basis Point)
        val dv01 = pv01Sum * (if (direction == TradeDirection.RECEIVE_FIXED) 1.0 else -1.0)
        val modifiedDuration = if (annuity > 0) annuity / (1.0 + parRate / 100.0) else maturityYears * 0.95
        val convexity = modifiedDuration * modifiedDuration * 0.01

        return InterestRateSwap(
            tradeId = tradeId,
            book = book,
            desk = desk,
            counterparty = counterparty,
            notionalEur = notionalEur,
            direction = direction,
            fixedRate = fixedRatePercent,
            floatingIndex = floatingIndex,
            effectiveDate = today.toString(),
            maturityDate = maturityDate.toString(),
            maturityYears = maturityYears,
            fixedFrequencyMonths = fixedFrequencyMonths,
            floatFrequencyMonths = floatFrequencyMonths,
            dayCount = dayCount,
            parRate = parRate,
            npvEur = npv,
            dv01Eur = dv01,
            durationYears = modifiedDuration,
            convexity = convexity,
            schedule = schedule
        )
    }

    /**
     * Tenor basis swap: Euribor 3M vs Euribor 6M
     * Returns the par basis spread in basis points that makes 3M float leg + spread == 6M float leg NPV.
     */
    fun calculateBasisSwapSpreadBp(
        maturityYears: Double,
        discountCurveEstr: YieldCurve,
        euribor3mCurve: YieldCurve,
        euribor6mCurve: YieldCurve
    ): Double {
        var pv3m = 0.0
        var pv6m = 0.0
        var annuity3m = 0.0

        val periods3m = (maturityYears * 4).toInt()
        val dt3m = 0.25
        for (i in 1..periods3m) {
            val tEnd = i * dt3m
            val tStart = (i - 1) * dt3m
            val fwd = CurveConstructionEngine.calculateForwardRate(euribor3mCurve, tStart, tEnd)
            val df = discountCurveEstr.discountFactorAt(tEnd)
            pv3m += (fwd / 100.0) * dt3m * df
            annuity3m += dt3m * df
        }

        val periods6m = (maturityYears * 2).toInt()
        val dt6m = 0.50
        for (i in 1..periods6m) {
            val tEnd = i * dt6m
            val tStart = (i - 1) * dt6m
            val fwd = CurveConstructionEngine.calculateForwardRate(euribor6mCurve, tStart, tEnd)
            val df = discountCurveEstr.discountFactorAt(tEnd)
            pv6m += (fwd / 100.0) * dt6m * df
        }

        val spreadDecimal = if (annuity3m > 0) (pv6m - pv3m) / annuity3m else 0.0
        return spreadDecimal * 10_000.0 // in basis points
    }
}
