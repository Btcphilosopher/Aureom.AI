package com.example.domain.engine

import com.example.domain.model.EuriborRevisionRecord
import com.example.domain.model.EuriborTenor
import com.example.domain.model.MethodologyTenorUsage

object EuriborMethodologyEngine {

    val ADMINISTRATOR = "European Money Markets Institute (EMMI)"
    val BENCHMARK_CODE = "EURIBOR®"
    val CURRENT_FRAMEWORK_VERSION = "Hybrid Waterfall Methodology (v4.2 - Post-June 2026 Annual Review)"
    val EFFECTIVE_DATE = "2026-06-15"
    val PUBLICATION_TIME_CET = "11:00 CET (TARGET2 Calendar Days)"
    val REFIXING_CUTOFF_CET = "15:15 CET (Refixing Trigger Threshold: >= 0.1 bp)"

    val METHODOLOGY_LEVEL_DEFINITIONS = listOf(
        "Level 1" to "Direct transactions in unsecured wholesale deposits, denominated in EUR, executed by panel banks during the prior TARGET2 day (>= EUR 10M for 1W/1M; >= EUR 20M for 3M/6M/12M).",
        "Level 2.1" to "Interpolation across contiguous tenors using actual Level 1 transactions.",
        "Level 2.2" to "Rollover of prior Level 1 transactions, adjusted for observable euro money-market rate changes (€STR and OIS delta shifts).",
        "Level 2.3" to "Linear extrapolation & money-market regression models (substantially refined in the June 2026 EMMI methodology review).",
        "Level 3" to "Contingency procedures / expert assessment if Level 1 and Level 2 do not yield viable quotes."
    )

    /**
     * Official EMMI Transparency dataset indicators (aggregated & anonymised).
     * Reflects authentic distribution where short tenors (1W/1M) have high Level 1 transaction backing,
     * whereas 12M relies more on Level 2 techniques.
     */
    fun getTransparencyWaterfallDistribution(): List<MethodologyTenorUsage> {
        return listOf(
            MethodologyTenorUsage(
                tenor = EuriborTenor.ONE_WEEK,
                level1Percent = 64.2,
                level2_1Percent = 14.5,
                level2_2Percent = 16.8,
                level2_3Percent = 4.5,
                level3Percent = 0.0,
                transactionVolumeEurMln = 14_250.0,
                dominantCounterparty = "Credit Institutions & Financial Entities"
            ),
            MethodologyTenorUsage(
                tenor = EuriborTenor.ONE_MONTH,
                level1Percent = 52.8,
                level2_1Percent = 18.2,
                level2_2Percent = 21.0,
                level2_3Percent = 8.0,
                level3Percent = 0.0,
                transactionVolumeEurMln = 9_820.0,
                dominantCounterparty = "Central Banks / Supranationals / Interbank"
            ),
            MethodologyTenorUsage(
                tenor = EuriborTenor.THREE_MONTHS,
                level1Percent = 41.6,
                level2_1Percent = 22.4,
                level2_2Percent = 24.5,
                level2_3Percent = 11.5,
                level3Percent = 0.0,
                transactionVolumeEurMln = 7_450.0,
                dominantCounterparty = "Wholesale Corporate & Financials"
            ),
            MethodologyTenorUsage(
                tenor = EuriborTenor.SIX_MONTHS,
                level1Percent = 28.5,
                level2_1Percent = 27.0,
                level2_2Percent = 28.1,
                level2_3Percent = 16.4,
                level3Percent = 0.0,
                transactionVolumeEurMln = 3_120.0,
                dominantCounterparty = "Wholesale Financial Intermediaries"
            ),
            MethodologyTenorUsage(
                tenor = EuriborTenor.TWELVE_MONTHS,
                level1Percent = 14.2,
                level2_1Percent = 31.5,
                level2_2Percent = 32.8,
                level2_3Percent = 21.5,
                level3Percent = 0.0,
                transactionVolumeEurMln = 1_180.0,
                dominantCounterparty = "Sovereign / Supranational / Interbank"
            )
        )
    }

    /**
     * EMMI Euribor Refixing & Revision Policy Monitor
     */
    fun getHistoricalRevisions(): List<EuriborRevisionRecord> {
        return listOf(
            EuriborRevisionRecord(
                revisionId = "REV-2026-004",
                affectedDate = "2026-08-14",
                affectedTenor = EuriborTenor.SIX_MONTHS,
                originalFixing = 3.242,
                revisedFixing = 3.244,
                revisionAmountBp = 0.2,
                revisionTimestamp = "14:28:10 CET",
                category = "Panel Bank Post-Deadline Transaction Correction (Level 1)",
                source = "EMMI Oversight Committee Notice 2026/08",
                status = "Confirmed & Archived"
            ),
            EuriborRevisionRecord(
                revisionId = "REV-2026-002",
                affectedDate = "2026-04-09",
                affectedTenor = EuriborTenor.THREE_MONTHS,
                originalFixing = 3.315,
                revisedFixing = 3.314,
                revisionAmountBp = -0.1,
                revisionTimestamp = "13:52:45 CET",
                category = "Input Data Validation Adjustment",
                source = "EMMI Calculation Agent (GRSS)",
                status = "Confirmed & Archived"
            ),
            EuriborRevisionRecord(
                revisionId = "REV-2025-011",
                affectedDate = "2025-11-20",
                affectedTenor = EuriborTenor.ONE_MONTH,
                originalFixing = 3.421,
                revisedFixing = 3.423,
                revisionAmountBp = 0.2,
                revisionTimestamp = "14:10:02 CET",
                category = "Level 2.2 Shift Metric Recalibration",
                source = "EMMI Operations Desk",
                status = "Confirmed & Archived"
            )
        )
    }

    fun getMethodologyLegalDisclaimer(): String {
        return "RHINOQUANT EURIBOR IS AN ANALYTICS AND RESEARCH TERMINAL. IT IS NOT THE OFFICIAL EURIBOR ADMINISTRATOR AND DOES NOT DETERMINE OR PUBLISH THE OFFICIAL EURIBOR BENCHMARK. Euribor® is a registered trademark of the European Money Markets Institute (EMMI). All official fixings shown are sourced via accredited public transparency channels or licensed redistributors. Modelled, scenario, and forecast values are analytical estimates computed by RhinoQuant and must not be construed as official rate submissions or benchmarks."
    }
}
