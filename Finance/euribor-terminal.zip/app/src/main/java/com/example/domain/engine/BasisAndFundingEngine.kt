package com.example.domain.engine

import com.example.domain.model.DataClassification
import com.example.domain.model.EuriborTenor
import com.example.domain.model.FundingCurvePoint
import com.example.domain.model.RelativeValueSpread
import com.example.domain.model.RhinoQuantDecomposition

object BasisAndFundingEngine {

    fun calculateRelativeValueSpreads(
        euriborRates: Map<EuriborTenor, Double>,
        estrCompoundedRates: Map<EuriborTenor, Double>,
        overnightEstr: Double
    ): List<RelativeValueSpread> {
        val list = mutableListOf<RelativeValueSpread>()

        // 1W Euribor vs compounded €STR
        val r1w = euriborRates[EuriborTenor.ONE_WEEK] ?: 3.165
        val estr1w = estrCompoundedRates[EuriborTenor.ONE_WEEK] ?: 3.150
        list.add(
            createSpread(
                "1W Euribor vs €STR (1W Compounded)",
                "1W",
                r1w,
                estr1w,
                "€STR 1W Comp.",
                1.5,
                1.6,
                2.1,
                0.22,
                55.0
            )
        )

        // 1M Euribor vs compounded €STR
        val r1m = euriborRates[EuriborTenor.ONE_MONTH] ?: 3.185
        val estr1m = estrCompoundedRates[EuriborTenor.ONE_MONTH] ?: 3.152
        list.add(
            createSpread(
                "1M Euribor vs €STR (1M Compounded)",
                "1M",
                r1m,
                estr1m,
                "€STR 1M Comp.",
                3.3,
                3.2,
                2.8,
                0.41,
                58.4
            )
        )

        // 3M Euribor vs compounded €STR
        val r3m = euriborRates[EuriborTenor.THREE_MONTHS] ?: 3.238
        val estr3m = estrCompoundedRates[EuriborTenor.THREE_MONTHS] ?: 3.154
        list.add(
            createSpread(
                "3M Euribor vs €STR (3M Compounded)",
                "3M",
                r3m,
                estr3m,
                "€STR 3M Comp.",
                8.4,
                8.5,
                3.6,
                0.78,
                68.2
            )
        )

        // 6M Euribor vs compounded €STR
        val r6m = euriborRates[EuriborTenor.SIX_MONTHS] ?: 3.276
        val estr6m = estrCompoundedRates[EuriborTenor.SIX_MONTHS] ?: 3.156
        list.add(
            createSpread(
                "6M Euribor vs €STR (6M Compounded)",
                "6M",
                r6m,
                estr6m,
                "€STR 6M Comp.",
                12.0,
                11.8,
                4.2,
                0.95,
                74.0
            )
        )

        // 12M Euribor vs compounded €STR
        val r12m = euriborRates[EuriborTenor.TWELVE_MONTHS] ?: 3.291
        val estr12m = estrCompoundedRates[EuriborTenor.TWELVE_MONTHS] ?: 3.158
        list.add(
            createSpread(
                "12M Euribor vs €STR (12M Compounded)",
                "12M",
                r12m,
                estr12m,
                "€STR 12M Comp.",
                13.3,
                13.4,
                5.1,
                0.82,
                70.5
            )
        )

        // Inter-Euribor Basis Spreads
        list.add(
            createSpread(
                "Euribor Tenor Basis: 1M vs 3M",
                "1M/3M",
                r3m,
                r1m,
                "Euribor 1M",
                (r3m - r1m) * 100.0,
                5.2,
                2.4,
                0.35,
                61.0
            )
        )
        list.add(
            createSpread(
                "Euribor Tenor Basis: 3M vs 6M",
                "3M/6M",
                r6m,
                r3m,
                "Euribor 3M",
                (r6m - r3m) * 100.0,
                3.8,
                2.9,
                0.48,
                64.5
            )
        )
        list.add(
            createSpread(
                "Euribor Tenor Basis: 6M vs 12M",
                "6M/12M",
                r12m,
                r6m,
                "Euribor 6M",
                (r12m - r6m) * 100.0,
                1.5,
                3.1,
                -0.12,
                48.0
            )
        )

        return list
    }

    private fun createSpread(
        title: String,
        tenor: String,
        euribor: Double,
        reference: Double,
        refDesc: String,
        basisBp: Double,
        prevBp: Double,
        vol: Double,
        zScore: Double,
        pct: Double
    ): RelativeValueSpread {
        return RelativeValueSpread(
            comparisonName = title,
            tenorCode = tenor,
            euriborRate = euribor,
            referenceRate = reference,
            referenceDescription = refDesc,
            basisSpreadBp = basisBp,
            prevBasisSpreadBp = prevBp,
            changeBp = basisBp - prevBp,
            vol30dBp = vol,
            zScore1Y = zScore,
            percentile1Y = pct
        )
    }

    /**
     * RhinoQuant Modelled Decomposition of Euribor - €STR Basis
     * Separates the observable spread into:
     * - Bank Credit Component Proxy (CDS implied spread of panel banks)
     * - Liquidity / Collateral Component Proxy (unsecured vs secured preference)
     * - Term / Tenor Premium (fixing horizon uncertainty)
     * - Market Stress Residual
     */
    fun decomposeEuriborEstrBasis(
        tenor: EuriborTenor,
        totalBasisBp: Double
    ): RhinoQuantDecomposition {
        val (creditRatio, liqRatio, termRatio) = when (tenor) {
            EuriborTenor.ONE_WEEK -> Triple(0.20, 0.50, 0.25)
            EuriborTenor.ONE_MONTH -> Triple(0.30, 0.40, 0.25)
            EuriborTenor.THREE_MONTHS -> Triple(0.40, 0.30, 0.25)
            EuriborTenor.SIX_MONTHS -> Triple(0.45, 0.25, 0.25)
            EuriborTenor.TWELVE_MONTHS -> Triple(0.50, 0.20, 0.25)
            else -> Triple(0.35, 0.35, 0.25)
        }

        val credit = totalBasisBp * creditRatio
        val liq = totalBasisBp * liqRatio
        val term = totalBasisBp * termRatio
        val stress = totalBasisBp - (credit + liq + term)

        return RhinoQuantDecomposition(
            tenor = tenor,
            observableTotalBasisBp = totalBasisBp,
            creditComponentProxyBp = credit,
            liquidityComponentProxyBp = liq,
            termTenorPremiumBp = term,
            marketStressComponentBp = stress
        )
    }

    /**
     * Funding curve engine: Risk-free OIS, Secured Repo (GC), Unsecured Bank Wholesale.
     */
    fun getFundingCurvePoints(): List<FundingCurvePoint> {
        return listOf(
            FundingCurvePoint("O/N", 0.0027, 3.152, 3.148, 3.160, -0.4, 0.8),
            FundingCurvePoint("1W", 0.0194, 3.150, 3.145, 3.165, -0.5, 1.5),
            FundingCurvePoint("1M", 0.0833, 3.152, 3.144, 3.185, -0.8, 3.3),
            FundingCurvePoint("3M", 0.2500, 3.154, 3.140, 3.238, -1.4, 8.4),
            FundingCurvePoint("6M", 0.5000, 3.156, 3.138, 3.276, -1.8, 12.0),
            FundingCurvePoint("1Y", 1.0000, 3.158, 3.135, 3.291, -2.3, 13.3),
            FundingCurvePoint("2Y", 2.0000, 2.940, 2.910, 3.080, -3.0, 14.0),
            FundingCurvePoint("5Y", 5.0000, 2.650, 2.615, 2.810, -3.5, 16.0)
        )
    }
}
