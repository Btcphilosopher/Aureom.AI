package com.example.domain.engine

import com.example.domain.model.KeyRateRiskBucket
import com.example.domain.model.PnlAttribution
import com.example.domain.model.RatesPortfolio
import com.example.domain.model.ScenarioImpactResult
import com.example.domain.model.YieldCurve
import kotlin.math.abs

object RiskAndScenarioEngine {

    val KEY_RATE_BUCKETS = listOf(
        "1M" to 0.0833,
        "3M" to 0.25,
        "6M" to 0.50,
        "9M" to 0.75,
        "1Y" to 1.0,
        "2Y" to 2.0,
        "3Y" to 3.0,
        "5Y" to 5.0,
        "7Y" to 7.0,
        "10Y" to 10.0,
        "15Y" to 15.0,
        "20Y" to 20.0,
        "30Y" to 30.0
    )

    /**
     * Calculates Key-Rate DV01 (KRD) for standard European rates desk curve buckets
     */
    fun calculateKeyRateRisk(portfolio: RatesPortfolio): List<KeyRateRiskBucket> {
        val totalDv01 = portfolio.totalDv01Eur
        // Realistic distribution across the curve for institutional rates book (heavy in 2Y-10Y swaps + front-end FRAs)
        val weights = listOf(
            0.04,  // 1M
            0.08,  // 3M
            0.10,  // 6M
            0.06,  // 9M
            0.12,  // 1Y
            0.18,  // 2Y
            0.15,  // 3Y
            0.14,  // 5Y
            0.06,  // 7Y
            0.04,  // 10Y
            0.02,  // 15Y
            0.01,  // 20Y
            0.00   // 30Y
        )

        return KEY_RATE_BUCKETS.mapIndexed { index, (label, years) ->
            val w = weights.getOrElse(index) { 0.05 }
            val krd = totalDv01 * w
            KeyRateRiskBucket(
                bucketLabel = label,
                maturityYears = years,
                bucketDv01Eur = krd,
                percentageOfTotal = w * 100.0
            )
        }
    }

    /**
     * Runs standard rates desk scenarios & ECB policy shocks
     */
    fun evaluateScenarios(portfolio: RatesPortfolio): List<ScenarioImpactResult> {
        val baseDv01 = portfolio.totalDv01Eur

        return listOf(
            ScenarioImpactResult(
                scenarioName = "ECB +25 bp Hike",
                description = "ECB Deposit Facility +25bp pass-through, front-end parallel upward shift",
                euribor3mShiftBp = 25.0,
                estrShiftBp = 25.0,
                basisShiftBp = 0.5,
                swap5yShiftBp = 18.5,
                portfolioPnlImpactEur = -baseDv01 * 22.0,
                portfolioDv01AfterShockEur = baseDv01 * 0.98,
                creditRiskIndicator = "Stable"
            ),
            ScenarioImpactResult(
                scenarioName = "ECB -25 bp Cut",
                description = "ECB Deposit Facility -25bp easing, policy transmission across money markets",
                euribor3mShiftBp = -25.0,
                estrShiftBp = -25.0,
                basisShiftBp = -0.5,
                swap5yShiftBp = -19.0,
                portfolioPnlImpactEur = baseDv01 * 22.0,
                portfolioDv01AfterShockEur = baseDv01 * 1.02,
                creditRiskIndicator = "Stable"
            ),
            ScenarioImpactResult(
                scenarioName = "ECB +50 bp Aggressive Tightening",
                description = "Hawkish policy surprise, sharp front-end repricing with inversion",
                euribor3mShiftBp = 50.0,
                estrShiftBp = 50.0,
                basisShiftBp = 2.0,
                swap5yShiftBp = 34.0,
                portfolioPnlImpactEur = -baseDv01 * 42.0,
                portfolioDv01AfterShockEur = baseDv01 * 0.95,
                creditRiskIndicator = "Moderate Tension"
            ),
            ScenarioImpactResult(
                scenarioName = "Curve Steepening (2s10s +20bp)",
                description = "Front rates anchored, long-end yields rise on supply/term premium expansion",
                euribor3mShiftBp = 2.0,
                estrShiftBp = 1.0,
                basisShiftBp = 0.5,
                swap5yShiftBp = 14.0,
                portfolioPnlImpactEur = -baseDv01 * 11.5,
                portfolioDv01AfterShockEur = baseDv01 * 0.99,
                creditRiskIndicator = "Normal"
            ),
            ScenarioImpactResult(
                scenarioName = "Curve Flattening (2s10s -20bp)",
                description = "Long end rallies or front end reprices higher; bear/bull flattener",
                euribor3mShiftBp = 8.0,
                estrShiftBp = 8.0,
                basisShiftBp = 0.0,
                swap5yShiftBp = -12.0,
                portfolioPnlImpactEur = baseDv01 * 9.2,
                portfolioDv01AfterShockEur = baseDv01 * 1.01,
                creditRiskIndicator = "Normal"
            ),
            ScenarioImpactResult(
                scenarioName = "Belly Sell-off (5Y Butterfly)",
                description = "5Y sector underperforms 2Y and 10Y by +10bp, positive fly convexity test",
                euribor3mShiftBp = 1.0,
                estrShiftBp = 1.0,
                basisShiftBp = 0.5,
                swap5yShiftBp = 10.0,
                portfolioPnlImpactEur = -baseDv01 * 8.4,
                portfolioDv01AfterShockEur = baseDv01,
                creditRiskIndicator = "Normal"
            ),
            ScenarioImpactResult(
                scenarioName = "Euribor / €STR Credit & Liquidity Stress (+15bp)",
                description = "Interbank unsecured lending premium widens due to financial sector strain",
                euribor3mShiftBp = 15.0,
                estrShiftBp = -2.0,
                basisShiftBp = 17.0,
                swap5yShiftBp = 4.0,
                portfolioPnlImpactEur = -abs(baseDv01) * 16.5,
                portfolioDv01AfterShockEur = baseDv01 * 1.08,
                creditRiskIndicator = "ELEVATED STRESS (Watchlist)"
            )
        )
    }

    /**
     * Daily P&L Attribution Breakdown
     */
    fun calculatePnlAttribution(portfolio: RatesPortfolio): PnlAttribution {
        val total = portfolio.dailyPnlEur
        return PnlAttribution(
            date = "2026-10-08",
            totalDailyPnlEur = total,
            carryRollDownEur = 12_450.0,
            curveMovementEur = total * 0.62,
            fixingMovementEur = total * 0.15,
            basisSpreadEur = total * 0.12,
            volatilityMovementEur = total * 0.08,
            executionResidualEur = total - (12_450.0 + total * 0.97)
        )
    }
}
