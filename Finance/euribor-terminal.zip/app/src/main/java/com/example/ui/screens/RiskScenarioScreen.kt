package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.RiskAndScenarioEngine
import com.example.domain.model.DataClassification
import com.example.domain.model.KeyRateRiskBucket
import com.example.domain.model.ScenarioImpactResult
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalNegative
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun RiskScenarioScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val portfolio by viewModel.portfolio.collectAsState()
    val krdBuckets = viewModel.keyRateRiskBuckets
    val scenarioResults = viewModel.scenarioResults
    val pnlAttribution = RiskAndScenarioEngine.calculatePnlAttribution(portfolio)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_risk_scenario")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "RISK ENGINE & SCENARIO STRESS",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.SIMULATED)
            }
            Text(
                text = "PORTFOLIO SENSITIVITIES & KRD",
                color = TerminalTextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Portfolio Risk Summary KPI Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            RiskKpiItem("TOTAL NET DV01", "€${String.format("%,.0f", portfolio.totalDv01Eur)} / bp", TerminalCyanBlue)
            RiskKpiItem("TOTAL PORTFOLIO VEGA", "€${String.format("%,.0f", portfolio.totalVegaEur)} / bp", TerminalAmber)
            RiskKpiItem("DAILY P&L", "+€${String.format("%,.0f", portfolio.dailyPnlEur)}", TerminalPositive)
            RiskKpiItem("YTD P&L", "+€${String.format("%,.0f", portfolio.ytdPnlEur)}", TerminalPositive)
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Bucketed Key-Rate DV01 (KRD) Table
        Text(
            text = "BUCKETED KEY-RATE RISK (1M TO 30Y TENOR BUCKETS)",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("BUCKET", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("MATURITY", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("BUCKET DV01 (EUR)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.6f))
                Text("% OF TOTAL DV01", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                Text("EXPOSURE PROFILE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(2.0f))
            }

            krdBuckets.forEach { krd ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(krd.bucketLabel, color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.0f))
                    Text("${String.format("%.2f", krd.maturityYears)}Y", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("€${String.format("%,.0f", krd.bucketDv01Eur)}", color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.6f))
                    Text("${String.format("%.1f", krd.percentageOfTotal)}%", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))

                    // Mini exposure bar
                    Box(
                        modifier = Modifier
                            .weight(2.0f)
                            .height(8.dp)
                            .background(TerminalSurfaceElevated, RoundedCornerShape(2.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth((krd.percentageOfTotal / 25.0).toFloat().coerceIn(0.05f, 1.0f))
                                .height(8.dp)
                                .background(TerminalCyanBlue, RoundedCornerShape(2.dp))
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // ECB Monetary Policy & Curve Stress Scenarios
        Text(
            text = "SCENARIO MATRIX & CENTRAL BANK POLICY SHOCKS",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("SCENARIO", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f))
                Text("EURIBOR Δ", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("€STR Δ", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("PORTFOLIO P&L IMPACT", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f))
                Text("CREDIT STATUS", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
            }

            scenarioResults.forEach { sc ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(sc.scenarioName, color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.8f))
                    val eStr = if (sc.euribor3mShiftBp > 0) "+${String.format("%.0f", sc.euribor3mShiftBp)} bp" else "${String.format("%.0f", sc.euribor3mShiftBp)} bp"
                    Text(eStr, color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    val estStr = if (sc.estrShiftBp > 0) "+${String.format("%.0f", sc.estrShiftBp)} bp" else "${String.format("%.0f", sc.estrShiftBp)} bp"
                    Text(estStr, color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                    val pnlColor = if (sc.portfolioPnlImpactEur >= 0) TerminalPositive else TerminalNegative
                    val pnlStr = if (sc.portfolioPnlImpactEur >= 0) "+€${String.format("%,.0f", sc.portfolioPnlImpactEur)}" else "-€${String.format("%,.0f", kotlin.math.abs(sc.portfolioPnlImpactEur))}"
                    Text(pnlStr, color = pnlColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                    val crColor = if (sc.creditRiskIndicator.contains("STRESS")) TerminalNegative else TerminalPositive
                    Text(sc.creditRiskIndicator, color = crColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Daily P&L Attribution Breakdown
        Text(
            text = "DAILY P&L FACTOR ATTRIBUTION (DESK 1)",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PnlFactorCard("Carry & Roll-down", "+€${String.format("%,.0f", pnlAttribution.carryRollDownEur)}", Modifier.weight(1f))
            PnlFactorCard("Curve Movement", "+€${String.format("%,.0f", pnlAttribution.curveMovementEur)}", Modifier.weight(1f))
            PnlFactorCard("Fixing Movement", "+€${String.format("%,.0f", pnlAttribution.fixingMovementEur)}", Modifier.weight(1f))
            PnlFactorCard("Basis Spread Shift", "+€${String.format("%,.0f", pnlAttribution.basisSpreadEur)}", Modifier.weight(1f))
        }
    }
}

@Composable
private fun RiskKpiItem(title: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column {
        Text(title, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PnlFactorCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Text(title, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalPositive, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}
