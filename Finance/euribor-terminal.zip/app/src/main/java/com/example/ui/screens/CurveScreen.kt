package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.CurveConstructionEngine
import com.example.domain.model.CurveSteepnessMetric
import com.example.domain.model.DataClassification
import com.example.ui.components.CurveCanvasChart
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalNegative
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun CurveScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val euribor3mCurve by viewModel.euribor3mCurve.collectAsState()
    val euribor6mCurve by viewModel.euribor6mCurve.collectAsState()
    val estrCurve by viewModel.estrDiscountCurve.collectAsState()
    val histPeriod by viewModel.historicalPeriod.collectAsState()
    val histCurve by viewModel.historicalCurve.collectAsState()
    val steepnessMetrics = viewModel.curveSteepnessMetrics
    val nsParams = CurveConstructionEngine.fitNelsonSiegel(euribor3mCurve)

    val historicalOptions = listOf(
        "TODAY", "1 DAY AGO", "1 WEEK AGO", "1 MONTH AGO",
        "3 MONTHS AGO", "6 MONTHS AGO", "1 YEAR AGO", "5 YEARS AGO"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_curve")
    ) {
        // Workspace Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "EURIBOR TERM STRUCTURE & SPREADS",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.CALCULATED)
            }
            Text(
                text = "BOOTSTRAP LOG-LINEAR / CUBIC",
                color = TerminalTextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Historical Replay / Curve-over-Curve Selector Bar
        Text(
            text = "HISTORICAL CURVE COMPARISON ARCHIVE",
            color = TerminalTextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            historicalOptions.forEach { period ->
                val isSelected = (histPeriod == period)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isSelected) TerminalCyanBlue else TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                        .clickable { viewModel.selectHistoricalPeriod(period) }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = period.replace(" AGO", ""),
                        color = if (isSelected) TerminalPanel else TerminalTextSecondary,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Multi-curve chart: Euribor 3M vs Historical Curve
        CurveCanvasChart(
            primaryCurve = euribor3mCurve,
            secondaryCurve = histCurve,
            tertiaryCurve = estrCurve,
            chartTitle = "EURIBOR 3M vs $histPeriod (GOLD = €STR DISCOUNT)"
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Curve Steepness & Curvature Matrix
        Text(
            text = "CURVE STEEPNESS & BUTTERFLY CURVATURE METRICS",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TENOR PAIR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(2.0f))
                Text("SPREAD (BP)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("1D Δ", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("52W PCTL", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("Z-SCORE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
            }

            steepnessMetrics.forEach { metric ->
                SteepnessRow(metric)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Nelson-Siegel 4-Parameter Model Fitting Box
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "NELSON-SIEGEL PARAMETRIC FIT (LEVEL, SLOPE, CURVATURE)",
                    color = TerminalCyanBlue,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                DataClassificationBadge(classification = DataClassification.MODELLED)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                NsMetricItem("β₀ (Level)", String.format("%.3f", nsParams.beta0Level))
                NsMetricItem("β₁ (Slope)", String.format("%.3f", nsParams.beta1Slope))
                NsMetricItem("β₂ (Curv)", String.format("%.3f", nsParams.beta2Curvature))
                NsMetricItem("λ (Decay)", String.format("%.2f", nsParams.lambdaDecay))
                NsMetricItem("Fit R²", String.format("%.3f", nsParams.rSquared))
            }
            Text(
                text = "Model: y(t) = β₀ + β₁·((1-e^(-t/λ))/(t/λ)) + β₂·(((1-e^(-t/λ))/(t/λ)) - e^(-t/λ))",
                color = TerminalTextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Zero Rate & Discount Factor Node Table
        Text(
            text = "DISCOUNT FACTORS & INTERPOLATED ZERO NODES",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TENOR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                Text("MATURITY", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("EURIBOR 3M", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("€STR OIS", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("DISCOUNT FACTOR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
            }

            euribor3mCurve.nodes.take(9).forEach { node ->
                val estrRate = estrCurve.rateAt(node.maturityYears)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(node.tenorLabel, color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${String.format("%.2f", node.maturityYears)}Y", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("${String.format("%.3f", node.zeroRate)}%", color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                    Text("${String.format("%.3f", estrRate)}%", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                    Text(String.format("%.5f", node.discountFactor), color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                }
            }
        }
    }
}

@Composable
private fun SteepnessRow(metric: CurveSteepnessMetric) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(metric.pairName, color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(2.0f))
        Text("${String.format("%.1f", metric.spreadBp)} bp", color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
        val changeText = if (metric.changeBp > 0) "+${String.format("%.1f", metric.changeBp)}" else String.format("%.1f", metric.changeBp)
        Text(changeText, color = if (metric.changeBp > 0) TerminalPositive else if (metric.changeBp < 0) TerminalNegative else TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
        Text("${String.format("%.1f", metric.percentile52w)}%", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
        val zColor = if (metric.zScore52w > 1.0) TerminalPositive else if (metric.zScore52w < -1.0) TerminalNegative else TerminalTextMuted
        Text(String.format("%.2f", metric.zScore52w), color = zColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
    }
}

@Composable
private fun NsMetricItem(label: String, value: String) {
    Column {
        Text(label, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}
