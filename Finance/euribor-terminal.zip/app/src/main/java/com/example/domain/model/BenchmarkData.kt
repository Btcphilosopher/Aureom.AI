package com.example.domain.model

data class EuriborFixing(
    val tenor: EuriborTenor,
    val officialFixing: Double,      // in percentage, e.g. 3.185%
    val previousFixing: Double,
    val dailyChangeBp: Double,       // in basis points (1 bp = 0.01%)
    val weeklyChangeBp: Double,
    val monthlyChangeBp: Double,
    val ytdChangeBp: Double,
    val high52w: Double,
    val low52w: Double,
    val fixingDate: String,          // e.g. "2026-10-07"
    val publicationStatus: String,   // e.g. "Published (TARGET2 11:00 CET)"
    val dataTimestamp: String,       // e.g. "11:02:15 CET"
    val dataSource: String = "EMMI (European Money Markets Institute)",
    val classification: DataClassification = DataClassification.OFFICIAL,
    val quality: DataQualityFlag = DataQualityFlag.CLEAN
) {
    val spreadOverPrev: Double get() = (officialFixing - previousFixing) * 100.0
}

data class EstrFixing(
    val fixingDate: String,
    val rate: Double,                // e.g. 3.152%
    val previousRate: Double,
    val changeBp: Double,
    val volumeEurBillions: Double,   // e.g. 68.4 bn
    val numberOfBanks: Int,          // e.g. 34 banks
    val shareOfTop5BanksPercent: Double,
    val compounded1W: Double,
    val compounded1M: Double,
    val compounded3M: Double,
    val compounded6M: Double,
    val compounded12M: Double,
    val publicationStatus: String = "Published (ECB 08:00 CET)",
    val source: String = "European Central Bank (€STR)"
)

data class EuriborRevisionRecord(
    val revisionId: String,
    val affectedDate: String,
    val affectedTenor: EuriborTenor,
    val originalFixing: Double,
    val revisedFixing: Double,
    val revisionAmountBp: Double,
    val revisionTimestamp: String,
    val category: String,           // e.g. "Level 1 Transaction Late Delivery", "Calculation Input Correction"
    val source: String,
    val status: String              // "Confirmed & Archived"
)

data class MethodologyTenorUsage(
    val tenor: EuriborTenor,
    val level1Percent: Double,      // Eligible unsecured transactions
    val level2_1Percent: Double,    // Tenor interpolation
    val level2_2Percent: Double,    // Historical transaction rollover
    val level2_3Percent: Double,    // Modeling / linear extrapolation
    val level3Percent: Double,      // Contingency / Expert assessment
    val transactionVolumeEurMln: Double,
    val dominantCounterparty: String
)

data class EcbPolicyRates(
    val date: String,
    val depositFacilityRate: Double,     // DFR, e.g. 3.25%
    val mainRefinancingRate: Double,     // MRO, e.g. 3.40%
    val marginalLendingRate: Double,     // MLF, e.g. 3.65%
    val nextMeetingDate: String,
    val policyTransmissionLagDays: Int
)
