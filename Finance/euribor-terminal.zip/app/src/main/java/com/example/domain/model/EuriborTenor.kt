package com.example.domain.model

enum class EuriborTenor(
    val code: String,
    val label: String,
    val daysApprox: Int,
    val yearFractionApprox: Double,
    val isOfficialTenor: Boolean
) {
    ONE_WEEK("1W", "1 Week", 7, 7.0 / 360.0, true),
    ONE_MONTH("1M", "1 Month", 30, 30.0 / 360.0, true),
    THREE_MONTHS("3M", "3 Months", 91, 91.0 / 360.0, true),
    SIX_MONTHS("6M", "6 Months", 182, 182.0 / 360.0, true),
    TWELVE_MONTHS("12M", "12 Months", 365, 365.0 / 360.0, true),

    // Sub-benchmark or reference interpolated points
    OVERNIGHT("O/N", "Overnight (€STR Ref)", 1, 1.0 / 360.0, false),
    NINE_MONTHS("9M", "9 Months (Interpolated)", 273, 273.0 / 360.0, false);

    companion object {
        val OFFICIAL_TENORS = listOf(ONE_WEEK, ONE_MONTH, THREE_MONTHS, SIX_MONTHS, TWELVE_MONTHS)

        fun fromCode(code: String): EuriborTenor? =
            values().firstOrNull { it.code.equals(code.trim(), ignoreCase = true) }
    }
}
