package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.SwapPricingEngine
import com.example.domain.model.DataClassification
import com.example.domain.model.TradeDirection
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalNegative
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun SwapsOisScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val estrCurve by viewModel.estrDiscountCurve.collectAsState()
    val euribor3mCurve by viewModel.euribor3mCurve.collectAsState()
    val euribor6mCurve by viewModel.euribor6mCurve.collectAsState()

    var selectedSwapTenorYears by remember { mutableStateOf(5.0) }
    var selectedIndex by remember { mutableStateOf("Euribor 3M") }
    var selectedDirection by remember { mutableStateOf(TradeDirection.PAY_FIXED) }
    var inputFixedRate by remember { mutableStateOf(2.85) }

    val activeProjectionCurve = if (selectedIndex == "Euribor 6M") euribor6mCurve else euribor3mCurve

    val swapPricing = remember(selectedSwapTenorYears, selectedIndex, selectedDirection, inputFixedRate) {
        SwapPricingEngine.priceSwap(
            tradeId = "CALC-SWP-01",
            book = "RATES_DESK_EUR",
            desk = "Institutional Linear Rates",
            counterparty = "Bilateral Clearing (LCH SwapClear)",
            notionalEur = 100_000_000.0,
            direction = selectedDirection,
            fixedRatePercent = inputFixedRate,
            floatingIndex = selectedIndex,
            maturityYears = selectedSwapTenorYears,
            discountCurveEstr = estrCurve,
            projectionCurveEuribor = activeProjectionCurve
        )
    }

    val basisSwapSpreadBp = remember(selectedSwapTenorYears) {
        SwapPricingEngine.calculateBasisSwapSpreadBp(selectedSwapTenorYears, estrCurve, euribor3mCurve, euribor6mCurve)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_swaps")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "MULTI-CURVE SWAP ENGINE",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.CALCULATED)
            }
            Text(
                text = "DISCOUNT: €STR OIS | PROJ: EURIBOR",
                color = TerminalTextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Swap Configurator Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "SWAP INSTRUMENT CONFIGURATION",
                color = TerminalTextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Tenor Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(1.0 to "1Y", 2.0 to "2Y", 3.0 to "3Y", 5.0 to "5Y", 7.0 to "7Y", 10.0 to "10Y").forEach { (y, label) ->
                    val isSel = (selectedSwapTenorYears == y)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSel) TerminalCyanBlue else TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                            .clickable { selectedSwapTenorYears = y }
                            .padding(vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSel) TerminalPanel else TerminalTextSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Float Index & Direction
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Floating Index Selector
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Index: ", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    listOf("Euribor 3M", "Euribor 6M").forEach { idx ->
                        val isSel = (selectedIndex == idx)
                        Text(
                            text = "[$idx]",
                            color = if (isSel) TerminalCyanBlue else TerminalTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .clickable { selectedIndex = idx }
                                .padding(horizontal = 4.dp)
                        )
                    }
                }

                // Direction Selector
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Leg: ", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    listOf(TradeDirection.PAY_FIXED to "Pay Fixed", TradeDirection.RECEIVE_FIXED to "Rec Fixed").forEach { (dir, label) ->
                        val isSel = (selectedDirection == dir)
                        Text(
                            text = "[$label]",
                            color = if (isSel) TerminalCyanBlue else TerminalTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .clickable { selectedDirection = dir }
                                .padding(horizontal = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Valuation Metrics Results Box
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalCyanBlue.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "VALUATION & RISK RESULTS (EUR 100M NOTIONAL)",
                    color = TerminalCyanBlue,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "LCH SWAPCLEAR DUAL-CURVE",
                    color = TerminalTextMuted,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SwapMetricItem("PAR SWAP RATE", "${String.format("%.3f", swapPricing.parRate)}%", TerminalCyanBlue)
                SwapMetricItem("FIXED RATE", "${String.format("%.2f", inputFixedRate)}%", TerminalTextPrimary)
                val npvColor = if (swapPricing.npvEur >= 0) TerminalPositive else TerminalNegative
                SwapMetricItem("NPV (EUR)", "€${String.format("%,.0f", swapPricing.npvEur)}", npvColor)
                SwapMetricItem("DV01 (PER BP)", "€${String.format("%,.0f", kotlin.math.abs(swapPricing.dv01Eur))}", TerminalTextPrimary)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SwapMetricItem("MODIFIED DURATION", "${String.format("%.2f", swapPricing.durationYears)} Yrs", TerminalTextSecondary)
                SwapMetricItem("CONVEXITY", String.format("%.3f", swapPricing.convexity), TerminalTextSecondary)
                SwapMetricItem("3M vs 6M BASIS SPREAD", "+${String.format("%.1f", basisSwapSpreadBp)} bp", TerminalTextSecondary)
                SwapMetricItem("DAY-COUNT", "ACT/360", TerminalTextMuted)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Cashflow Schedule Table
        Text(
            text = "DISCOUNTED CASHFLOW SCHEDULE (FLOAT & FIXED)",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("DATE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("TAU", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                Text("FWD RATE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("DISC FACTOR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("PAYMENT (EUR)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                Text("PV (EUR)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
            }

            swapPricing.schedule.take(8).forEach { cf ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(cf.paymentDate, color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                    Text(String.format("%.2f", cf.yearFraction), color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text("${String.format("%.3f", cf.forwardOrFixedRate)}%", color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text(String.format("%.4f", cf.discountFactor), color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                    Text("€${String.format("%,.0f", cf.paymentAmountEur)}", color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    Text("€${String.format("%,.0f", cf.presentValueEur)}", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                }
            }
        }
    }
}

@Composable
private fun SwapMetricItem(title: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column {
        Text(title, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}
