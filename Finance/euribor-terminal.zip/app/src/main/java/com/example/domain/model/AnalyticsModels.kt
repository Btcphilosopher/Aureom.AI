package com.example.domain.model

data class RelativeValueSpread(
    val comparisonName: String,
    val tenorCode: String,
    val euriborRate: Double,
    val referenceRate: Double,
    val referenceDescription: String,
    val basisSpreadBp: Double,
    val prevBasisSpreadBp: Double,
    val changeBp: Double,
    val vol30dBp: Double,
    val zScore1Y: Double,
    val percentile1Y: Double
)

data class RhinoQuantDecomposition(
    val tenor: EuriborTenor,
    val observableTotalBasisBp: Double,
    val creditComponentProxyBp: Double,
    val liquidityComponentProxyBp: Double,
    val termTenorPremiumBp: Double,
    val marketStressComponentBp: Double,
    val label: String = "RHINOQUANT MODELLED DECOMPOSITION",
    val classification: DataClassification = DataClassification.MODELLED
)

data class FundingCurvePoint(
    val tenorLabel: String,
    val maturityYears: Double,
    val riskFreeEstrOisRate: Double,
    val securedRepoRate: Double,
    val bankWholesaleUnsecuredRate: Double,
    val securedSpreadBp: Double,
    val unsecuredSpreadBp: Double
)

data class KeyRateRiskBucket(
    val bucketLabel: String,
    val maturityYears: Double,
    val bucketDv01Eur: Double,
    val percentageOfTotal: Double
)

data class ScenarioImpactResult(
    val scenarioName: String,
    val description: String,
    val euribor3mShiftBp: Double,
    val estrShiftBp: Double,
    val basisShiftBp: Double,
    val swap5yShiftBp: Double,
    val portfolioPnlImpactEur: Double,
    val portfolioDv01AfterShockEur: Double,
    val creditRiskIndicator: String
)

data class PnlAttribution(
    val date: String,
    val totalDailyPnlEur: Double,
    val carryRollDownEur: Double,
    val curveMovementEur: Double,
    val fixingMovementEur: Double,
    val basisSpreadEur: Double,
    val volatilityMovementEur: Double,
    val executionResidualEur: Double
)

data class VolatilitySurfacePoint(
    val expiryLabel: String,
    val expiryYears: Double,
    val tenorLabel: String,
    val tenorYears: Double,
    val atmNormalVolBp: Double,
    val strikeMinus50Bp: Double,
    val strikePlus50Bp: Double,
    val riskReversal25D: Double,
    val butterfly25D: Double
)
