package com.example.domain.model

enum class TradeDirection { PAY_FIXED, RECEIVE_FIXED }
enum class OptionType { CAP, FLOOR, PAYER_SWAPTION, RECEIVER_SWAPTION }

data class Cashflow(
    val paymentDate: String,
    val periodStart: String,
    val periodEnd: String,
    val yearFraction: Double,
    val forwardOrFixedRate: Double, // in %
    val discountFactor: Double,
    val paymentAmountEur: Double,
    val presentValueEur: Double
)

data class InterestRateSwap(
    val tradeId: String,
    val book: String,
    val desk: String,
    val counterparty: String,
    val notionalEur: Double,
    val direction: TradeDirection,
    val fixedRate: Double,          // in %
    val floatingIndex: String,      // "Euribor 3M", "Euribor 6M", "€STR"
    val effectiveDate: String,
    val maturityDate: String,
    val maturityYears: Double,
    val fixedFrequencyMonths: Int = 12,
    val floatFrequencyMonths: Int = 3,
    val dayCount: DayCountConvention = DayCountConvention.ACT_360,
    val parRate: Double,            // %
    val npvEur: Double,
    val dv01Eur: Double,
    val durationYears: Double,
    val convexity: Double,
    val schedule: List<Cashflow> = emptyList()
)

data class FraContract(
    val tradeId: String,
    val tenorLabel: String,         // e.g. "3x6 FRA"
    val notionalEur: Double,
    val fixedRate: Double,
    val referenceRate: Double,
    val startDate: String,
    val endDate: String,
    val periodDays: Int,
    val payoffEur: Double,
    val dv01Eur: Double,
    val breakevenRate: Double
)

data class EuriborFutureContract(
    val contractCode: String,       // e.g. "FEU3 Dec26"
    val expiryDate: String,
    val marketPrice: Double,        // e.g. 96.815
    val impliedRate: Double,        // 100 - marketPrice = 3.185%
    val dailyChangePrice: Double,
    val volume: Int,
    val openInterest: Int,
    val notionalPerContract: Double = 1_000_000.0,
    val basisVsForwardCurveBp: Double,
    val contractsHeld: Int = 0
)

data class CapFloorTrade(
    val tradeId: String,
    val optionType: OptionType,
    val strikeRate: Double,
    val underlyingTenor: EuriborTenor,
    val maturityYears: Double,
    val notionalEur: Double,
    val impliedVolBp: Double,       // Normal Bachelier vol in bp
    val premiumEur: Double,
    val delta: Double,
    val vegaEur: Double,
    val gamma: Double,
    val thetaEur: Double,
    val dv01Eur: Double
)

data class SwaptionTrade(
    val tradeId: String,
    val optionType: OptionType,     // PAYER_SWAPTION or RECEIVER_SWAPTION
    val expiryYears: Double,        // e.g. 1.0 (1Y)
    val underlyingTenorYears: Double,// e.g. 5.0 (5Y)
    val strikeRate: Double,
    val forwardSwapRate: Double,
    val normalVolBp: Double,
    val notionalEur: Double,
    val premiumEur: Double,
    val delta: Double,
    val vegaEur: Double,
    val dv01Eur: Double
)

data class MoneyMarketInstrument(
    val instrumentId: String,
    val name: String,
    val category: String,           // "Secured Repo", "Term Deposit", "Commercial Paper", "Treasury Bill"
    val rate: Double,
    val spreadToEstrBp: Double,
    val maturityDays: Int,
    val collateralType: String,     // "Gov Sovereign (General Collateral)", "Unsecured Interbank", "High Grade Corporate"
    val haircutPercent: Double
)

data class RatesPortfolio(
    val portfolioName: String,
    val totalNotionalEur: Double,
    val totalNpvEur: Double,
    val totalDv01Eur: Double,
    val totalVegaEur: Double,
    val dailyPnlEur: Double,
    val mtdPnlEur: Double,
    val ytdPnlEur: Double,
    val swaps: List<InterestRateSwap>,
    val fras: List<FraContract>,
    val futures: List<EuriborFutureContract>,
    val options: List<CapFloorTrade>,
    val swaptions: List<SwaptionTrade>
)
