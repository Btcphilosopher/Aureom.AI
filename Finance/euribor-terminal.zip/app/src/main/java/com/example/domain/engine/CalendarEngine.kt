package com.example.domain.engine

import com.example.domain.model.BusinessDayConvention
import com.example.domain.model.DayCountConvention
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

object CalendarEngine {

    /**
     * TARGET2 (Trans-European Automated Real-time Gross settlement Express Transfer)
     * Closed on Saturdays, Sundays, and specific official EU banking holidays:
     * - Jan 1: New Year's Day
     * - Good Friday
     * - Easter Monday
     * - May 1: Labour Day
     * - Dec 25: Christmas Day
     * - Dec 26: Boxing Day
     */
    fun isTargetBusinessDay(date: LocalDate): Boolean {
        if (date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY) {
            return false
        }
        val month = date.monthValue
        val day = date.dayOfMonth

        if (month == 1 && day == 1) return false
        if (month == 5 && day == 1) return false
        if (month == 12 && (day == 25 || day == 26)) return false

        // Easter calculation (computus for Good Friday & Easter Monday)
        val easter = calculateEaster(date.year)
        val goodFriday = easter.minusDays(2)
        val easterMonday = easter.plusDays(1)

        if (date == goodFriday || date == easterMonday) return false

        return true
    }

    private fun calculateEaster(year: Int): LocalDate {
        val a = year % 19
        val b = year / 100
        val c = year % 100
        val d = b / 4
        val e = b % 4
        val f = (b + 8) / 25
        val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4
        val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = ((h + l - 7 * m + 114) % 31) + 1
        return LocalDate.of(year, month, day)
    }

    /**
     * Standard Euro wholesale unsecured market spot lag is T+2 TARGET business days.
     */
    fun spotDate(fixingDate: LocalDate, spotLagDays: Int = 2): LocalDate {
        var current = fixingDate
        var added = 0
        while (added < spotLagDays) {
            current = current.plusDays(1)
            if (isTargetBusinessDay(current)) {
                added++
            }
        }
        return current
    }

    fun adjustDate(date: LocalDate, convention: BusinessDayConvention): LocalDate {
        if (isTargetBusinessDay(date)) return date

        return when (convention) {
            BusinessDayConvention.FOLLOWING -> nextBusinessDay(date)
            BusinessDayConvention.PRECEDING -> previousBusinessDay(date)
            BusinessDayConvention.MODIFIED_FOLLOWING -> {
                val next = nextBusinessDay(date)
                if (next.monthValue == date.monthValue) {
                    next
                } else {
                    previousBusinessDay(date)
                }
            }
            BusinessDayConvention.UNADJUSTED -> date
        }
    }

    fun nextBusinessDay(date: LocalDate): LocalDate {
        var d = date.plusDays(1)
        while (!isTargetBusinessDay(d)) {
            d = d.plusDays(1)
        }
        return d
    }

    fun previousBusinessDay(date: LocalDate): LocalDate {
        var d = date.minusDays(1)
        while (!isTargetBusinessDay(d)) {
            d = d.minusDays(1)
        }
        return d
    }

    fun yearFraction(
        startDate: LocalDate,
        endDate: LocalDate,
        convention: DayCountConvention
    ): Double {
        val days = ChronoUnit.DAYS.between(startDate, endDate)
        return when (convention) {
            DayCountConvention.ACT_360 -> days / 360.0
            DayCountConvention.ACT_365F -> days / 365.0
            DayCountConvention.THIRTY_360,
            DayCountConvention.THIRTY_E_360 -> {
                val d1 = startDate.dayOfMonth.coerceAtMost(30)
                val d2 = if (d1 == 30 && endDate.dayOfMonth == 31) 30 else endDate.dayOfMonth.coerceAtMost(30)
                val m1 = startDate.monthValue
                val m2 = endDate.monthValue
                val y1 = startDate.year
                val y2 = endDate.year
                val count = (360 * (y2 - y1) + 30 * (m2 - m1) + (d2 - d1))
                count / 360.0
            }
        }
    }

    fun parseDate(dateStr: String): LocalDate {
        return try {
            LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE)
        } catch (_: Exception) {
            LocalDate.now()
        }
    }
}
