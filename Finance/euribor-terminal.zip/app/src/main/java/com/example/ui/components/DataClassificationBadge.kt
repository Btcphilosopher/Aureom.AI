package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DataClassification
import com.example.ui.theme.BadgeForecastBg
import com.example.ui.theme.BadgeForecastText
import com.example.ui.theme.BadgeMarketBg
import com.example.ui.theme.BadgeMarketText
import com.example.ui.theme.BadgeModelledBg
import com.example.ui.theme.BadgeModelledText
import com.example.ui.theme.BadgeOfficialBg
import com.example.ui.theme.BadgeOfficialText
import com.example.ui.theme.BadgeSimulatedBg
import com.example.ui.theme.BadgeSimulatedText
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalPanel

@Composable
fun DataClassificationBadge(
    classification: DataClassification,
    modifier: Modifier = Modifier
) {
    val (bg, textCol) = when (classification) {
        DataClassification.OFFICIAL -> Pair(BadgeOfficialBg, BadgeOfficialText)
        DataClassification.MARKET -> Pair(BadgeMarketBg, BadgeMarketText)
        DataClassification.MODELLED -> Pair(BadgeModelledBg, BadgeModelledText)
        DataClassification.FORECAST -> Pair(BadgeForecastBg, BadgeForecastText)
        DataClassification.SIMULATED -> Pair(BadgeSimulatedBg, BadgeSimulatedText)
        DataClassification.CALCULATED -> Pair(Color(0xFF0F2E4A), TerminalCyanBlue)
        DataClassification.HISTORICAL -> Pair(Color(0xFF1E293B), Color(0xFF94A3B8))
        DataClassification.STALE -> Pair(Color(0xFF450A0A), Color(0xFFF87171))
    }

    Box(
        modifier = modifier
            .background(bg, RoundedCornerShape(3.dp))
            .border(0.5.dp, textCol.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
            .padding(horizontal = 5.dp, vertical = 1.5.dp)
            .testTag("badge_${classification.name.lowercase()}")
    ) {
        Text(
            text = "[${classification.label}]",
            color = textCol,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            lineHeight = 11.sp
        )
    }
}
