package com.example.domain.model

data class CurveNode(
    val maturityYears: Double,
    val tenorLabel: String,
    val zeroRate: Double,          // in %
    val discountFactor: Double,    // e.g. 0.9682
    val instantaneousForward: Double = zeroRate
)

enum class CurveType(val displayName: String, val indexFamily: String) {
    ESTR_DISCOUNT("€STR OIS Discount Curve", "€STR Risk-Free"),
    EURIBOR_1M_PROJECTION("Euribor 1M Projection Curve", "Euribor 1M Unsecured"),
    EURIBOR_3M_PROJECTION("Euribor 3M Projection Curve", "Euribor 3M Unsecured"),
    EURIBOR_6M_PROJECTION("Euribor 6M Projection Curve", "Euribor 6M Unsecured"),
    EURIBOR_12M_PROJECTION("Euribor 12M Projection Curve", "Euribor 12M Unsecured"),
    BUND_BENCHMARK("German Bund Sovereign Yield Curve", "Sovereign Debt")
}

data class YieldCurve(
    val id: String,
    val curveType: CurveType,
    val asOfDate: String,
    val nodes: List<CurveNode>,
    val interpolationMethod: String = "Log-Linear Discount / Cubic Spline Zero",
    val classification: DataClassification = DataClassification.CALCULATED
) {
    fun rateAt(maturity: Double): Double {
        if (nodes.isEmpty()) return 0.0
        if (maturity <= nodes.first().maturityYears) return nodes.first().zeroRate
        if (maturity >= nodes.last().maturityYears) return nodes.last().zeroRate

        for (i in 0 until nodes.size - 1) {
            val n1 = nodes[i]
            val n2 = nodes[i + 1]
            if (maturity >= n1.maturityYears && maturity <= n2.maturityYears) {
                val weight = (maturity - n1.maturityYears) / (n2.maturityYears - n1.maturityYears)
                return n1.zeroRate + weight * (n2.zeroRate - n1.zeroRate)
            }
        }
        return nodes.last().zeroRate
    }

    fun discountFactorAt(maturity: Double): Double {
        val rate = rateAt(maturity) / 100.0
        return kotlin.math.exp(-rate * maturity)
    }
}

data class CurveSteepnessMetric(
    val pairName: String,
    val spreadBp: Double,
    val prevSpreadBp: Double,
    val changeBp: Double,
    val percentile52w: Double,
    val zScore52w: Double
)

data class ForwardRatePoint(
    val forwardLabel: String,       // e.g. "1M -> 4M (3M Fwd)", "3M -> 6M"
    val startYears: Double,
    val endYears: Double,
    val tenorFraction: Double,
    val impliedForwardRate: Double, // in %
    val spotRate: Double,
    val forwardSpreadBp: Double,
    val forwardVolatilityNorm: Double // normal vol in bp
)

data class NelsonSiegelParams(
    val beta0Level: Double,
    val beta1Slope: Double,
    val beta2Curvature: Double,
    val lambdaDecay: Double,
    val rSquared: Double
) {
    fun evaluate(t: Double): Double {
        if (t <= 0.0001) return beta0Level + beta1Slope
        val tLambda = t / lambdaDecay
        val expFactor = kotlin.math.exp(-tLambda)
        val term1 = (1.0 - expFactor) / tLambda
        val term2 = term1 - expFactor
        return beta0Level + beta1Slope * term1 + beta2Curvature * term2
    }
}
