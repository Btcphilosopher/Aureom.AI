package com.example.domain.engine

import com.example.domain.model.EuriborFutureContract
import com.example.domain.model.FraContract
import com.example.domain.model.YieldCurve
import java.time.LocalDate

object FraAndFuturesEngine {

    /**
     * FRA Valuation:
     * Settlement at fixing:
     * Payoff = Notional * [ (Ref - Fixed) * tau ] / [ 1 + Ref * tau ]
     * Discounted Value = Payoff * DiscountFactor(Start)
     */
    fun priceFra(
        tradeId: String,
        tenorPair: String, // e.g. "3x6", "6x9", "6x12"
        notionalEur: Double,
        fixedRatePercent: Double,
        discountCurveEstr: YieldCurve,
        euriborProjectionCurve: YieldCurve
    ): FraContract {
        val parts = tenorPair.split("x")
        val startMonths = parts.getOrNull(0)?.toDoubleOrNull() ?: 3.0
        val endMonths = parts.getOrNull(1)?.toDoubleOrNull() ?: 6.0

        val tStart = startMonths / 12.0
        val tEnd = endMonths / 12.0
        val tau = (endMonths - startMonths) / 12.0

        val forwardRefRate = CurveConstructionEngine.calculateForwardRate(euriborProjectionCurve, tStart, tEnd)
        val rFix = fixedRatePercent / 100.0
        val rRef = forwardRefRate / 100.0

        val payoffAtSettlement = notionalEur * ((rRef - rFix) * tau) / (1.0 + rRef * tau)
        val dfStart = discountCurveEstr.discountFactorAt(tStart)
        val pv = payoffAtSettlement * dfStart

        // DV01 calculation (1 bp change in fixed rate)
        val dv01 = (notionalEur * 0.0001 * tau / (1.0 + rRef * tau)) * dfStart

        val today = LocalDate.of(2026, 10, 8)
        val startDate = today.plusMonths(startMonths.toLong()).toString()
        val endDate = today.plusMonths(endMonths.toLong()).toString()

        return FraContract(
            tradeId = tradeId,
            tenorLabel = "${tenorPair} FRA",
            notionalEur = notionalEur,
            fixedRate = fixedRatePercent,
            referenceRate = forwardRefRate,
            startDate = startDate,
            endDate = endDate,
            periodDays = (tau * 360).toInt(),
            payoffEur = pv,
            dv01Eur = dv01,
            breakevenRate = forwardRefRate
        )
    }

    /**
     * Standard list of 3M Euribor Futures contracts (quarterly IMM contracts)
     * e.g. Dec 2026, Mar 2027, Jun 2027, Sep 2027, Dec 2027, Mar 2028
     */
    fun getFuturesContracts(euribor3mCurve: YieldCurve): List<EuriborFutureContract> {
        val list = mutableListOf<EuriborFutureContract>()
        val maturities = listOf(
            Triple("FEU3 Dec26", "2026-12-16", 0.19),
            Triple("FEU3 Mar27", "2027-03-17", 0.44),
            Triple("FEU3 Jun27", "2027-06-16", 0.69),
            Triple("FEU3 Sep27", "2027-09-15", 0.94),
            Triple("FEU3 Dec27", "2027-12-15", 1.19),
            Triple("FEU3 Mar28", "2028-03-15", 1.44),
            Triple("FEU3 Jun28", "2028-06-21", 1.69),
            Triple("FEU3 Sep28", "2028-09-20", 1.94)
        )

        for ((code, expDate, tStart) in maturities) {
            val tEnd = tStart + 0.25
            val fwdRate = CurveConstructionEngine.calculateForwardRate(euribor3mCurve, tStart, tEnd)
            // Convexity adjustment between futures rate and forward rate (futures trades higher in yield / lower in price due to daily margining)
            val convexityAdjBp = 1.2 * tStart
            val futuresYield = fwdRate + (convexityAdjBp / 100.0)
            val price = 100.0 - futuresYield
            val basisVsCurveBp = (futuresYield - fwdRate) * 100.0

            list.add(
                EuriborFutureContract(
                    contractCode = code,
                    expiryDate = expDate,
                    marketPrice = String.format("%.3f", price).toDouble(),
                    impliedRate = String.format("%.3f", futuresYield).toDouble(),
                    dailyChangePrice = 0.025,
                    volume = (18_000 + (10 - (tStart * 4)).toInt() * 3200).coerceAtLeast(4200),
                    openInterest = (85_000 + (10 - (tStart * 4)).toInt() * 12500).coerceAtLeast(15000),
                    basisVsForwardCurveBp = basisVsCurveBp,
                    contractsHeld = if (code.contains("Dec26")) 50 else if (code.contains("Mar27")) -25 else 0
                )
            )
        }
        return list
    }
}
