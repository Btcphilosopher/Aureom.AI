package com.example.data.repository

import com.example.domain.engine.BasisAndFundingEngine
import com.example.domain.engine.CurveConstructionEngine
import com.example.domain.engine.EuriborMethodologyEngine
import com.example.domain.engine.FraAndFuturesEngine
import com.example.domain.engine.SwapPricingEngine
import com.example.domain.engine.VolatilityAndOptionsEngine
import com.example.domain.model.CapFloorTrade
import com.example.domain.model.CurveType
import com.example.domain.model.DataClassification
import com.example.domain.model.DataQualityFlag
import com.example.domain.model.DayCountConvention
import com.example.domain.model.EcbPolicyRates
import com.example.domain.model.EstrFixing
import com.example.domain.model.EuriborFixing
import com.example.domain.model.EuriborFutureContract
import com.example.domain.model.EuriborTenor
import com.example.domain.model.FraContract
import com.example.domain.model.InterestRateSwap
import com.example.domain.model.MoneyMarketInstrument
import com.example.domain.model.OptionType
import com.example.domain.model.RatesPortfolio
import com.example.domain.model.SwaptionTrade
import com.example.domain.model.TradeDirection
import com.example.domain.model.YieldCurve
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

data class DataProvenanceRecord(
    val datasetName: String,
    val publisher: String,
    val publicationDate: String,
    val retrievalTimestamp: String,
    val checksumSha256: String,
    val regulatoryClassification: String,
    val licenseStatus: String
)

class TerminalRepository {

    private val _asOfDate = MutableStateFlow("2026-10-07")
    val asOfDate: StateFlow<String> = _asOfDate.asStateFlow()

    // Official Euribor Fixings
    private val _euriborFixings = MutableStateFlow<Map<EuriborTenor, EuriborFixing>>(createDefaultFixings())
    val euriborFixings: StateFlow<Map<EuriborTenor, EuriborFixing>> = _euriborFixings.asStateFlow()

    // ECB & €STR Data
    private val _estrFixing = MutableStateFlow(createDefaultEstr())
    val estrFixing: StateFlow<EstrFixing> = _estrFixing.asStateFlow()

    private val _ecbPolicyRates = MutableStateFlow(createDefaultEcbRates())
    val ecbPolicyRates: StateFlow<EcbPolicyRates> = _ecbPolicyRates.asStateFlow()

    // Curves
    private val _estrDiscountCurve = MutableStateFlow(createEstrCurve())
    val estrDiscountCurve: StateFlow<YieldCurve> = _estrDiscountCurve.asStateFlow()

    private val _euribor3mCurve = MutableStateFlow(createEuribor3mCurve())
    val euribor3mCurve: StateFlow<YieldCurve> = _euribor3mCurve.asStateFlow()

    private val _euribor6mCurve = MutableStateFlow(createEuribor6mCurve())
    val euribor6mCurve: StateFlow<YieldCurve> = _euribor6mCurve.asStateFlow()

    // Portfolio & Blotter
    private val _portfolio = MutableStateFlow(createInitialPortfolio())
    val portfolio: StateFlow<RatesPortfolio> = _portfolio.asStateFlow()

    // Money Market Instruments
    val moneyMarketInstruments: List<MoneyMarketInstrument> = listOf(
        MoneyMarketInstrument("DEP-001", "Overnight Interbank Deposit", "Unsecured Interbank", 3.160, 0.8, 1, "Unsecured Interbank", 0.0),
        MoneyMarketInstrument("DEP-002", "1M Wholesale Term Deposit", "Term Deposit", 3.185, 3.3, 30, "Unsecured Interbank", 0.0),
        MoneyMarketInstrument("DEP-003", "3M Wholesale Term Deposit", "Term Deposit", 3.238, 8.4, 91, "Unsecured Interbank", 0.0),
        MoneyMarketInstrument("REP-GC1", "1W German Bund GC Repo", "Secured Repo", 3.145, -0.5, 7, "German Bund Sovereign (AAA)", 2.0),
        MoneyMarketInstrument("REP-GC2", "1M Euro GC Pooling Repo", "Secured Repo", 3.144, -0.8, 30, "Euro Core Gov Bonds (AA+)", 2.5),
        MoneyMarketInstrument("CP-AAA1", "3M European Commercial Paper (STEP)", "Commercial Paper", 3.210, 5.6, 91, "High Grade Corporate (A-1/P-1)", 5.0),
        MoneyMarketInstrument("CD-BK1", "6M Certificate of Deposit (French Bank)", "Certificate of Deposit", 3.265, 10.9, 182, "Major Credit Institution", 4.0),
        MoneyMarketInstrument("BU-12M", "12M German Bubill (Zero Coupon)", "Treasury Bill", 3.115, -4.3, 365, "Federal Republic of Germany", 0.5)
    )

    // Provenance Records
    val provenanceRecords: List<DataProvenanceRecord> = listOf(
        DataProvenanceRecord(
            datasetName = "EURIBOR Official Benchmarks (5 Tenors)",
            publisher = "European Money Markets Institute (EMMI) / GRSS",
            publicationDate = "2026-10-07 11:00 CET",
            retrievalTimestamp = "2026-10-07 11:01:42 CET",
            checksumSha256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            regulatoryClassification = "EU BMR Critical Benchmark (Article 20(1))",
            licenseStatus = "Direct Redistribution License (EMMI-2026-RQ)"
        ),
        DataProvenanceRecord(
            datasetName = "Euro Short-Term Rate (€STR)",
            publisher = "European Central Bank (ECB)",
            publicationDate = "2026-10-07 08:00 CET",
            retrievalTimestamp = "2026-10-07 08:00:15 CET",
            checksumSha256 = "7d865e959b2466918c9863afca942d0fb89d7c9ac0c99bafc3749504ded97730",
            regulatoryClassification = "Official Central Bank Risk-Free Rate",
            licenseStatus = "ECB Public Policy Open Access"
        ),
        DataProvenanceRecord(
            datasetName = "ECB Key Policy Interest Rates (DFR/MRO/MLF)",
            publisher = "European Central Bank (ECB Governing Council)",
            publicationDate = "2026-09-17 14:15 CET",
            retrievalTimestamp = "2026-09-17 14:15:02 CET",
            checksumSha256 = "ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb",
            regulatoryClassification = "Monetary Policy Decisions",
            licenseStatus = "Official ESCB Statistics"
        )
    )

    // Historical Curves Archive (for curve-over-curve historical comparison)
    fun getHistoricalCurve(period: String): YieldCurve {
        val base = _euribor3mCurve.value
        val shift = when (period) {
            "TODAY" -> 0.0
            "1 DAY AGO" -> -0.004
            "1 WEEK AGO" -> -0.015
            "1 MONTH AGO" -> 0.045
            "3 MONTHS AGO" -> 0.120
            "6 MONTHS AGO" -> 0.280
            "1 YEAR AGO" -> 0.550
            "5 YEARS AGO" -> -3.750 // negative rates era (-0.50%)
            "10 YEARS AGO" -> -3.550
            else -> 0.0
        }

        val shiftedNodes = base.nodes.map { n ->
            val r = (n.zeroRate + shift)
            n.copy(zeroRate = r, discountFactor = kotlin.math.exp(-(r / 100.0) * n.maturityYears))
        }

        return base.copy(
            id = "EURIBOR_HIST_$period",
            asOfDate = period,
            nodes = shiftedNodes,
            classification = DataClassification.HISTORICAL
        )
    }

    fun bookTrade(newSwap: InterestRateSwap) {
        val current = _portfolio.value
        val updatedSwaps = current.swaps + newSwap
        val newNotional = current.totalNotionalEur + newSwap.notionalEur
        val newNpv = current.totalNpvEur + newSwap.npvEur
        val newDv01 = current.totalDv01Eur + newSwap.dv01Eur

        _portfolio.value = current.copy(
            totalNotionalEur = newNotional,
            totalNpvEur = newNpv,
            totalDv01Eur = newDv01,
            swaps = updatedSwaps
        )
    }

    private fun createDefaultFixings(): Map<EuriborTenor, EuriborFixing> {
        return mapOf(
            EuriborTenor.ONE_WEEK to EuriborFixing(
                tenor = EuriborTenor.ONE_WEEK,
                officialFixing = 3.165,
                previousFixing = 3.167,
                dailyChangeBp = -0.2,
                weeklyChangeBp = -0.5,
                monthlyChangeBp = -2.1,
                ytdChangeBp = -42.5,
                high52w = 3.845,
                low52w = 3.120,
                fixingDate = "2026-10-07",
                publicationStatus = "Published (TARGET2 11:00 CET)",
                dataTimestamp = "11:01:24 CET",
                classification = DataClassification.OFFICIAL,
                quality = DataQualityFlag.CLEAN
            ),
            EuriborTenor.ONE_MONTH to EuriborFixing(
                tenor = EuriborTenor.ONE_MONTH,
                officialFixing = 3.185,
                previousFixing = 3.184,
                dailyChangeBp = 0.1,
                weeklyChangeBp = -0.2,
                monthlyChangeBp = -1.8,
                ytdChangeBp = -41.0,
                high52w = 3.865,
                low52w = 3.140,
                fixingDate = "2026-10-07",
                publicationStatus = "Published (TARGET2 11:00 CET)",
                dataTimestamp = "11:01:24 CET",
                classification = DataClassification.OFFICIAL,
                quality = DataQualityFlag.CLEAN
            ),
            EuriborTenor.THREE_MONTHS to EuriborFixing(
                tenor = EuriborTenor.THREE_MONTHS,
                officialFixing = 3.238,
                previousFixing = 3.234,
                dailyChangeBp = 0.4,
                weeklyChangeBp = 0.8,
                monthlyChangeBp = -1.2,
                ytdChangeBp = -38.2,
                high52w = 3.910,
                low52w = 3.180,
                fixingDate = "2026-10-07",
                publicationStatus = "Published (TARGET2 11:00 CET)",
                dataTimestamp = "11:01:24 CET",
                classification = DataClassification.OFFICIAL,
                quality = DataQualityFlag.CLEAN
            ),
            EuriborTenor.SIX_MONTHS to EuriborFixing(
                tenor = EuriborTenor.SIX_MONTHS,
                officialFixing = 3.276,
                previousFixing = 3.274,
                dailyChangeBp = 0.2,
                weeklyChangeBp = 1.1,
                monthlyChangeBp = -0.5,
                ytdChangeBp = -35.4,
                high52w = 3.940,
                low52w = 3.210,
                fixingDate = "2026-10-07",
                publicationStatus = "Published (TARGET2 11:00 CET)",
                dataTimestamp = "11:01:24 CET",
                classification = DataClassification.OFFICIAL,
                quality = DataQualityFlag.CLEAN
            ),
            EuriborTenor.TWELVE_MONTHS to EuriborFixing(
                tenor = EuriborTenor.TWELVE_MONTHS,
                officialFixing = 3.291,
                previousFixing = 3.294,
                dailyChangeBp = -0.3,
                weeklyChangeBp = 0.5,
                monthlyChangeBp = 1.4,
                ytdChangeBp = -31.8,
                high52w = 3.980,
                low52w = 3.220,
                fixingDate = "2026-10-07",
                publicationStatus = "Published (TARGET2 11:00 CET)",
                dataTimestamp = "11:01:24 CET",
                classification = DataClassification.OFFICIAL,
                quality = DataQualityFlag.CLEAN
            )
        )
    }

    private fun createDefaultEstr(): EstrFixing {
        return EstrFixing(
            fixingDate = "2026-10-07",
            rate = 3.152,
            previousRate = 3.152,
            changeBp = 0.0,
            volumeEurBillions = 68.4,
            numberOfBanks = 34,
            shareOfTop5BanksPercent = 58.2,
            compounded1W = 3.150,
            compounded1M = 3.152,
            compounded3M = 3.154,
            compounded6M = 3.156,
            compounded12M = 3.158
        )
    }

    private fun createDefaultEcbRates(): EcbPolicyRates {
        return EcbPolicyRates(
            date = "2026-10-08",
            depositFacilityRate = 3.25,
            mainRefinancingRate = 3.40,
            marginalLendingRate = 3.65,
            nextMeetingDate = "2026-10-29",
            policyTransmissionLagDays = 1
        )
    }

    private fun createEstrCurve(): YieldCurve {
        return CurveConstructionEngine.buildCurve(
            id = "ESTR_OIS_DISC",
            type = CurveType.ESTR_DISCOUNT,
            asOfDate = "2026-10-07",
            nodes = listOf(
                0.0027 to 3.152,
                0.0194 to 3.150,
                0.0833 to 3.152,
                0.25 to 3.154,
                0.50 to 3.156,
                1.00 to 3.158,
                2.00 to 2.940,
                3.00 to 2.780,
                5.00 to 2.650,
                7.00 to 2.610,
                10.00 to 2.580,
                15.00 to 2.560,
                20.00 to 2.520,
                30.00 to 2.450
            ),
            classification = DataClassification.CALCULATED
        )
    }

    private fun createEuribor3mCurve(): YieldCurve {
        return CurveConstructionEngine.buildCurve(
            id = "EURIBOR_3M_PROJ",
            type = CurveType.EURIBOR_3M_PROJECTION,
            asOfDate = "2026-10-07",
            nodes = listOf(
                0.0194 to 3.165,
                0.0833 to 3.185,
                0.25 to 3.238,
                0.50 to 3.276,
                0.75 to 3.285,
                1.00 to 3.291,
                2.00 to 3.080,
                3.00 to 2.920,
                5.00 to 2.810,
                7.00 to 2.770,
                10.00 to 2.735,
                15.00 to 2.710,
                20.00 to 2.670,
                30.00 to 2.590
            ),
            classification = DataClassification.CALCULATED
        )
    }

    private fun createEuribor6mCurve(): YieldCurve {
        return CurveConstructionEngine.buildCurve(
            id = "EURIBOR_6M_PROJ",
            type = CurveType.EURIBOR_6M_PROJECTION,
            asOfDate = "2026-10-07",
            nodes = listOf(
                0.0833 to 3.220,
                0.25 to 3.250,
                0.50 to 3.276,
                1.00 to 3.325,
                2.00 to 3.120,
                3.00 to 2.960,
                5.00 to 2.850,
                7.00 to 2.810,
                10.00 to 2.775,
                15.00 to 2.750,
                20.00 to 2.710,
                30.00 to 2.630
            ),
            classification = DataClassification.CALCULATED
        )
    }

    private fun createInitialPortfolio(): RatesPortfolio {
        val estr = createEstrCurve()
        val e3m = createEuribor3mCurve()

        val swap1 = SwapPricingEngine.priceSwap(
            tradeId = "SWP-2026-081",
            book = "RATES_STIR_01",
            desk = "Euro Rates Trading",
            counterparty = "BNP Paribas",
            notionalEur = 50_000_000.0,
            direction = TradeDirection.PAY_FIXED,
            fixedRatePercent = 2.85,
            floatingIndex = "Euribor 3M",
            maturityYears = 5.0,
            discountCurveEstr = estr,
            projectionCurveEuribor = e3m
        )

        val swap2 = SwapPricingEngine.priceSwap(
            tradeId = "SWP-2026-094",
            book = "RATES_SWAP_02",
            desk = "Euro Rates Trading",
            counterparty = "Deutsche Bank AG",
            notionalEur = 75_000_000.0,
            direction = TradeDirection.RECEIVE_FIXED,
            fixedRatePercent = 3.02,
            floatingIndex = "Euribor 3M",
            maturityYears = 2.0,
            discountCurveEstr = estr,
            projectionCurveEuribor = e3m
        )

        val fra1 = FraAndFuturesEngine.priceFra(
            tradeId = "FRA-2026-015",
            tenorPair = "3x6",
            notionalEur = 100_000_000.0,
            fixedRatePercent = 3.24,
            discountCurveEstr = estr,
            euriborProjectionCurve = e3m
        )

        val futures = FraAndFuturesEngine.getFuturesContracts(e3m)

        val cap1 = VolatilityAndOptionsEngine.priceCapFloor(
            tradeId = "CAP-2026-003",
            optionType = OptionType.CAP,
            strikePercent = 3.50,
            maturityYears = 3.0,
            notionalEur = 25_000_000.0,
            discountCurve = estr,
            projectionCurve = e3m
        )

        val swaption1 = VolatilityAndOptionsEngine.priceSwaption(
            tradeId = "SWPN-2026-012",
            optionType = OptionType.PAYER_SWAPTION,
            expiryYears = 1.0,
            underlyingTenorYears = 5.0,
            strikePercent = 2.85,
            notionalEur = 30_000_000.0,
            discountCurve = estr,
            projectionCurve = e3m
        )

        val swapsList = listOf(swap1, swap2)
        val frasList = listOf(fra1)
        val optionsList = listOf(cap1)
        val swaptionsList = listOf(swaption1)

        val totalNotional = swapsList.sumOf { it.notionalEur } + frasList.sumOf { it.notionalEur } +
                optionsList.sumOf { it.notionalEur } + swaptionsList.sumOf { it.notionalEur }
        val totalNpv = swapsList.sumOf { it.npvEur } + frasList.sumOf { it.payoffEur } +
                optionsList.sumOf { it.premiumEur } + swaptionsList.sumOf { it.premiumEur }
        val totalDv01 = swapsList.sumOf { it.dv01Eur } + frasList.sumOf { it.dv01Eur } +
                optionsList.sumOf { it.dv01Eur } + swaptionsList.sumOf { it.dv01Eur }
        val totalVega = optionsList.sumOf { it.vegaEur } + swaptionsList.sumOf { it.vegaEur }

        return RatesPortfolio(
            portfolioName = "RHINOQUANT EUR RATES MAIN (DESK 1)",
            totalNotionalEur = totalNotional,
            totalNpvEur = totalNpv,
            totalDv01Eur = totalDv01,
            totalVegaEur = totalVega,
            dailyPnlEur = 48_250.0,
            mtdPnlEur = 312_400.0,
            ytdPnlEur = 1_840_900.0,
            swaps = swapsList,
            fras = frasList,
            futures = futures,
            options = optionsList,
            swaptions = swaptionsList
        )
    }
}
