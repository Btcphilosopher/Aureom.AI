package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.FraAndFuturesEngine
import com.example.domain.engine.VolatilityAndOptionsEngine
import com.example.domain.model.DataClassification
import com.example.domain.model.OptionType
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalNegative
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun FraOptionsScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val euribor3mCurve by viewModel.euribor3mCurve.collectAsState()
    val estrCurve by viewModel.estrDiscountCurve.collectAsState()

    var selectedFraTenor by remember { mutableStateOf("3x6") }
    var fraFixedRate by remember { mutableStateOf(3.24) }

    val fraPricing = remember(selectedFraTenor, fraFixedRate) {
        FraAndFuturesEngine.priceFra(
            tradeId = "FRA-LIVE-01",
            tenorPair = selectedFraTenor,
            notionalEur = 100_000_000.0,
            fixedRatePercent = fraFixedRate,
            discountCurveEstr = estrCurve,
            euriborProjectionCurve = euribor3mCurve
        )
    }

    // Cap/Floor Pricing
    val capPricing = remember {
        VolatilityAndOptionsEngine.priceCapFloor(
            tradeId = "CAP-EUR-01",
            optionType = OptionType.CAP,
            strikePercent = 3.50,
            maturityYears = 3.0,
            notionalEur = 50_000_000.0,
            discountCurve = estrCurve,
            projectionCurve = euribor3mCurve,
            normalVolBp = 52.0
        )
    }

    // Swaption Pricing
    val swaptionPricing = remember {
        VolatilityAndOptionsEngine.priceSwaption(
            tradeId = "SWPN-EUR-01",
            optionType = OptionType.PAYER_SWAPTION,
            expiryYears = 1.0,
            underlyingTenorYears = 5.0,
            strikePercent = 2.85,
            notionalEur = 50_000_000.0,
            discountCurve = estrCurve,
            projectionCurve = euribor3mCurve,
            normalVolBp = 56.0
        )
    }

    val volGrid = VolatilityAndOptionsEngine.getEuroSwaptionVolGrid()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_fra_options")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "FRAs & RATE OPTIONS PRICING",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.CALCULATED)
            }
            Text(
                text = "BACHELIER NORMAL VOL MODEL",
                color = TerminalTextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Forward Rate Agreement (FRA) Engine
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "FORWARD RATE AGREEMENT (FRA) VALUATION",
                color = TerminalCyanBlue,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Tenor Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("1x4", "2x5", "3x6", "6x9", "6x12", "9x12").forEach { t ->
                    val isSel = (selectedFraTenor == t)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSel) TerminalCyanBlue else TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                            .clickable { selectedFraTenor = t }
                            .padding(vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = t,
                            color = if (isSel) TerminalPanel else TerminalTextSecondary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Valuation Results
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                FraMetricItem("REFERENCE RATE", "${String.format("%.3f", fraPricing.referenceRate)}%")
                FraMetricItem("FIXED STRIKE", "${String.format("%.2f", fraFixedRate)}%")
                val pnlColor = if (fraPricing.payoffEur >= 0) TerminalPositive else TerminalNegative
                FraMetricItem("DISCOUNTED PAYOFF", "€${String.format("%,.0f", fraPricing.payoffEur)}", pnlColor)
                FraMetricItem("DV01 (PER BP)", "€${String.format("%,.0f", fraPricing.dv01Eur)}")
                FraMetricItem("BREAK-EVEN", "${String.format("%.3f", fraPricing.breakevenRate)}%")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Caps & Swaptions Valuation Box
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Cap Valuation
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(TerminalSurface, RoundedCornerShape(4.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "EURIBOR 3M CAP (3Y, K=3.50%)",
                    color = TerminalTextPrimary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                OptionLine("Notional", "€50,000,000")
                OptionLine("Normal Implied Vol", "${capPricing.impliedVolBp} bp")
                OptionLine("Option Premium", "€${String.format("%,.0f", capPricing.premiumEur)}")
                OptionLine("Delta", String.format("%.3f", capPricing.delta))
                OptionLine("Vega (1 bp Vol)", "€${String.format("%,.0f", capPricing.vegaEur)}")
                OptionLine("DV01", "€${String.format("%,.0f", capPricing.dv01Eur)}")
            }

            // Swaption Valuation
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(TerminalSurface, RoundedCornerShape(4.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "PAYER SWAPTION (1Y x 5Y, K=2.85%)",
                    color = TerminalTextPrimary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                OptionLine("Notional", "€50,000,000")
                OptionLine("Normal Implied Vol", "${swaptionPricing.normalVolBp} bp")
                OptionLine("Option Premium", "€${String.format("%,.0f", swaptionPricing.premiumEur)}")
                OptionLine("Forward Swap Rate", "${String.format("%.3f", swaptionPricing.forwardSwapRate)}%")
                OptionLine("Vega (1 bp Vol)", "€${String.format("%,.0f", swaptionPricing.vegaEur)}")
                OptionLine("DV01", "€${String.format("%,.0f", swaptionPricing.dv01Eur)}")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // European Swaption Volatility Grid (ATM normal vol, 25D skew)
        Text(
            text = "EURO SWAPTION VOLATILITY GRID (NORMAL BACHELIER BP)",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("EXPIRY", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("TENOR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("ATM VOL", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("K -50BP", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("K +50BP", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("25D RR (SKEW)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
            }

            volGrid.take(7).forEach { pt ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(pt.expiryLabel, color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f))
                    Text(pt.tenorLabel, color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    Text("${String.format("%.1f", pt.atmNormalVolBp)} bp", color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.3f))
                    Text("${String.format("%.1f", pt.strikeMinus50Bp)} bp", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("${String.format("%.1f", pt.strikePlus50Bp)} bp", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                    Text("${String.format("%.1f", pt.riskReversal25D)} bp", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                }
            }
        }
    }
}

@Composable
private fun FraMetricItem(title: String, value: String, color: androidx.compose.ui.graphics.Color = TerminalTextPrimary) {
    Column {
        Text(title, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun OptionLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
    }
}
