package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DataClassification
import com.example.domain.model.EuriborTenor
import com.example.domain.model.RelativeValueSpread
import com.example.domain.model.RhinoQuantDecomposition
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalNegative
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun BasisEstrScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val spreads = viewModel.relativeValueSpreads
    val selectedTenor by viewModel.selectedTenor.collectAsState()
    val decomp = viewModel.modelledDecomposition

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_basis_estr")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "EURIBOR / €STR RELATIVE VALUE & BASIS",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.MODELLED)
            }
            Text(
                text = "INTERBANK UNSECURED SPREAD",
                color = TerminalTextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Important Economic Distinction Callout Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                .border(0.5.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Column {
                Text(
                    text = "ECONOMIC BENCHMARK DISTINCTION NOTE:",
                    color = TerminalCyanBlue,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Euribor measures the euro unsecured wholesale term funding market for credit institutions (EMMI administered). €STR measures the overnight unsecured borrowing costs of banks from non-bank financial institutions and banks (ECB administered). They represent fundamentally distinct economic risks; the spread reflects credit proxy, term premium, and liquidity preference.",
                    color = TerminalTextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 13.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Relative Value Spreads Table
        Text(
            text = "OBSERVABLE EURIBOR VS COMPOUNDED €STR SPREADS",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("SPREAD COMPONENT", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(2.2f))
                Text("EURIBOR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("REF RATE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("BASIS (BP)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("VOL 30D", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("Z-SCORE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("1Y PCTL", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
            }

            spreads.forEach { spread ->
                SpreadRowItem(spread)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // RhinoQuant Modelled Decomposition Box
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = decomp.label,
                    color = TerminalAmber,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                DataClassificationBadge(classification = DataClassification.MODELLED)
            }

            Text(
                text = "Analytical decomposition of Euribor ${selectedTenor.code} – €STR spread (+${String.format("%.1f", decomp.observableTotalBasisBp)} bp total):",
                color = TerminalTextPrimary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )

            // Decomposition Components Breakdown Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DecompMetricBox("Bank Credit Proxy", "+${String.format("%.1f", decomp.creditComponentProxyBp)} bp", "Panel bank CDS proxy", Modifier.weight(1f))
                DecompMetricBox("Liquidity Premium", "+${String.format("%.1f", decomp.liquidityComponentProxyBp)} bp", "Secured vs Unsecured", Modifier.weight(1f))
                DecompMetricBox("Term Tenor Horizon", "+${String.format("%.1f", decomp.termTenorPremiumBp)} bp", "Rate horizon volatility", Modifier.weight(1f))
                DecompMetricBox("Stress Residual", "+${String.format("%.1f", decomp.marketStressComponentBp)} bp", "Market dislocation", Modifier.weight(1f))
            }

            Text(
                text = "DISCLAIMER: This decomposition is computed by RhinoQuant quantitative models using sovereign CDS spreads, repo collateral haircuts, and OIS forward term structures. It is NOT the official EMMI waterfall methodology decomposition.",
                color = TerminalTextMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 11.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Inter-Euribor Tenor Basis (1M vs 3M, 3M vs 6M, 6M vs 12M)
        Text(
            text = "INTER-EURIBOR TENOR BASIS MATRIX",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TenorBasisCard("1M vs 3M Basis", "+5.3 bp", "Spread for 2M forward exposure", Modifier.weight(1f))
            TenorBasisCard("3M vs 6M Basis", "+3.8 bp", "Standard STIR swaps basis", Modifier.weight(1f))
            TenorBasisCard("6M vs 12M Basis", "+1.5 bp", "Long-end money market slope", Modifier.weight(1f))
        }
    }
}

@Composable
private fun SpreadRowItem(spread: RelativeValueSpread) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(spread.comparisonName, color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(2.2f))
        Text("${String.format("%.3f", spread.euriborRate)}%", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
        Text("${String.format("%.3f", spread.referenceRate)}%", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
        Text("+${String.format("%.1f", spread.basisSpreadBp)} bp", color = TerminalCyanBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
        Text("${String.format("%.1f", spread.vol30dBp)} bp", color = TerminalTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
        val zColor = if (spread.zScore1Y > 1.0) TerminalPositive else if (spread.zScore1Y < -1.0) TerminalNegative else TerminalTextMuted
        Text(String.format("%.2f", spread.zScore1Y), color = zColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
        Text("${String.format("%.1f", spread.percentile1Y)}%", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
    }
}

@Composable
private fun DecompMetricBox(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(TerminalSurfaceElevated, RoundedCornerShape(3.dp))
            .border(0.5.dp, TerminalBorder, RoundedCornerShape(3.dp))
            .padding(6.dp)
    ) {
        Text(title, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalAmber, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text(subtitle, color = TerminalTextSecondary, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun TenorBasisCard(title: String, spread: String, detail: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Text(title, color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(spread, color = TerminalCyanBlue, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text(detail, color = TerminalTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}
