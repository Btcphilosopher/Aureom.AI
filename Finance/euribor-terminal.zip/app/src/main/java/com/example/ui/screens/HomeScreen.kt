package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DataClassification
import com.example.domain.model.EuriborFixing
import com.example.domain.model.EuriborTenor
import com.example.ui.components.CurveCanvasChart
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalNegative
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun HomeScreen(
    viewModel: TerminalViewModel,
    onNavigateToWorkspace: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val fixings by viewModel.euriborFixings.collectAsState()
    val estr by viewModel.estrFixing.collectAsState()
    val ecbRates by viewModel.ecbPolicyRates.collectAsState()
    val euribor3mCurve by viewModel.euribor3mCurve.collectAsState()
    val estrCurve by viewModel.estrDiscountCurve.collectAsState()
    val selectedTenor by viewModel.selectedTenor.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_home")
    ) {
        // Section Title: EURIBOR OFFICIAL FIXINGS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "EURIBOR BENCHMARK FIXINGS",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.OFFICIAL)
            }
            Text(
                text = "EMMI // TARGET2 11:00 CET",
                color = TerminalTextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Dense Financial Table for the 5 official Euribor tenors
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            // Table Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TENOR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("FIXING", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                Text("PREV", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("1D Δ", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("1W Δ", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("1M Δ", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.0f))
                Text("YTD Δ", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                Text("52W RANGE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f))
            }

            EuriborTenor.OFFICIAL_TENORS.forEach { tenor ->
                val item = fixings[tenor]
                if (item != null) {
                    FixingRowItem(
                        fixing = item,
                        isSelected = (selectedTenor == tenor),
                        onSelect = { viewModel.selectTenor(tenor) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Selected Tenor Inspector Bar
        val curFix = fixings[selectedTenor]
        if (curFix != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                    .border(1.dp, TerminalCyanBlue.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "SELECTED: EURIBOR ${selectedTenor.label.uppercase()} [${selectedTenor.code}]",
                            color = TerminalCyanBlue,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${curFix.fixingDate} @ ${curFix.dataTimestamp}",
                            color = TerminalTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Rate: ${String.format("%.3f", curFix.officialFixing)}%  (Prev: ${String.format("%.3f", curFix.previousFixing)}%)",
                            color = TerminalTextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Status: ${curFix.publicationStatus}",
                            color = TerminalPositive,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "Source: ${curFix.dataSource} | Quality: CLEAN (No active refixing triggers)",
                        color = TerminalTextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Live Yield Curve Glance
        CurveCanvasChart(
            primaryCurve = euribor3mCurve,
            secondaryCurve = estrCurve,
            chartTitle = "EURIBOR 3M PROJECTION vs €STR OIS DISCOUNT CURVE"
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Central Bank Monetary Policy & Money Market Anchor Panel
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ECB Policy Reference
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(TerminalSurface, RoundedCornerShape(4.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ECB POLICY RATES",
                        color = TerminalTextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    DataClassificationBadge(classification = DataClassification.OFFICIAL)
                }
                Spacer(modifier = Modifier.height(6.dp))
                EcbRateLine("Deposit Facility (DFR)", "${ecbRates.depositFacilityRate}%")
                EcbRateLine("Main Refinancing (MRO)", "${ecbRates.mainRefinancingRate}%")
                EcbRateLine("Marginal Lending (MLF)", "${ecbRates.marginalLendingRate}%")
                EcbRateLine("Next GC Meeting", ecbRates.nextMeetingDate)
            }

            // €STR Overnight Wholesale
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(TerminalSurface, RoundedCornerShape(4.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "€STR (OVERNIGHT)",
                        color = TerminalTextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    DataClassificationBadge(classification = DataClassification.OFFICIAL)
                }
                Spacer(modifier = Modifier.height(6.dp))
                EcbRateLine("€STR Spot Rate", "${estr.rate}%")
                EcbRateLine("Total Volume", "€${estr.volumeEurBillions} Bn")
                EcbRateLine("Reporting Banks", "${estr.numberOfBanks} banks")
                EcbRateLine("Top 5 Concentration", "${estr.shareOfTop5BanksPercent}%")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Workspaces Links
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            WorkspaceQuickButton("CURVES & SPREADS", Modifier.weight(1f)) { onNavigateToWorkspace(1) }
            WorkspaceQuickButton("EURIBOR / €STR BASIS", Modifier.weight(1f)) { onNavigateToWorkspace(2) }
            WorkspaceQuickButton("SWAPS PRICER", Modifier.weight(1f)) { onNavigateToWorkspace(3) }
            WorkspaceQuickButton("RISK & DV01", Modifier.weight(1f)) { onNavigateToWorkspace(7) }
        }
    }
}

@Composable
private fun FixingRowItem(
    fixing: EuriborFixing,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isSelected) TerminalSurfaceElevated else Color.Transparent)
            .clickable { onSelect() }
            .padding(vertical = 5.dp, horizontal = 2.dp)
            .testTag("fixing_row_${fixing.tenor.code}"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = fixing.tenor.code,
            color = if (isSelected) TerminalCyanBlue else TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1.2f)
        )
        Text(
            text = "${String.format("%.3f", fixing.officialFixing)}%",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1.4f)
        )
        Text(
            text = "${String.format("%.3f", fixing.previousFixing)}%",
            color = TerminalTextSecondary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1.2f)
        )
        BpChangeText(fixing.dailyChangeBp, Modifier.weight(1.0f))
        BpChangeText(fixing.weeklyChangeBp, Modifier.weight(1.0f))
        BpChangeText(fixing.monthlyChangeBp, Modifier.weight(1.0f))
        BpChangeText(fixing.ytdChangeBp, Modifier.weight(1.2f))
        Text(
            text = "${String.format("%.3f", fixing.low52w)} - ${String.format("%.3f", fixing.high52w)}",
            color = TerminalTextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1.8f)
        )
    }
}

@Composable
private fun BpChangeText(bp: Double, modifier: Modifier = Modifier) {
    val text = if (bp > 0) "+${String.format("%.1f", bp)}" else String.format("%.1f", bp)
    val color = when {
        bp > 0 -> TerminalPositive
        bp < 0 -> TerminalNegative
        else -> TerminalTextMuted
    }
    Text(
        text = text,
        color = color,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        modifier = modifier
    )
}

@Composable
private fun EcbRateLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun WorkspaceQuickButton(
    title: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = TerminalCyanBlue,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}
