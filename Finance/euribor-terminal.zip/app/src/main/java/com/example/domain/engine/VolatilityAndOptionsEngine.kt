package com.example.domain.engine

import com.example.domain.model.CapFloorTrade
import com.example.domain.model.EuriborTenor
import com.example.domain.model.OptionType
import com.example.domain.model.SwaptionTrade
import com.example.domain.model.VolatilitySurfacePoint
import com.example.domain.model.YieldCurve
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sqrt

object VolatilityAndOptionsEngine {

    private const val INV_SQRT_2PI = 0.3989422804014327

    fun normalPdf(x: Double): Double = INV_SQRT_2PI * exp(-0.5 * x * x)

    /**
     * Approximation of standard normal CDF Phi(x)
     */
    fun normalCdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419
        val c = 0.39894228

        if (x >= 0.0) {
            val t = 1.0 / (1.0 + p * x)
            return (1.0 - c * exp(-x * x / 2.0) * t *
                    (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        } else {
            val t = 1.0 / (1.0 - p * x)
            return (c * exp(-x * x / 2.0) * t *
                    (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        }
    }

    /**
     * Bachelier (Normal) model pricing for Caplet / Floorlet / Swaptions
     * Used exclusively on European rates desks due to zero/negative rate robustness.
     * sigmaN is in decimal (e.g. 50 bp normal vol = 0.0050)
     */
    fun bachelierPrice(
        isCallOrPayer: Boolean,
        forwardRate: Double,    // e.g. 0.0320
        strikeRate: Double,     // e.g. 0.0300
        timeToExpiry: Double,   // e.g. 1.0
        normalVol: Double,      // e.g. 0.0055 (55 bp)
        discountFactor: Double,
        accrualFraction: Double = 0.25
    ): Double {
        val t = max(0.0001, timeToExpiry)
        val volSqrtT = normalVol * sqrt(t)
        if (volSqrtT <= 1e-9) {
            val payoff = if (isCallOrPayer) max(0.0, forwardRate - strikeRate) else max(0.0, strikeRate - forwardRate)
            return discountFactor * accrualFraction * payoff
        }

        val d = (forwardRate - strikeRate) / volSqrtT
        val phiD = normalPdf(d)
        val cdfD = normalCdf(d)

        val price = if (isCallOrPayer) {
            discountFactor * accrualFraction * ((forwardRate - strikeRate) * cdfD + volSqrtT * phiD)
        } else {
            val cdfMinusD = normalCdf(-d)
            discountFactor * accrualFraction * ((strikeRate - forwardRate) * cdfMinusD + volSqrtT * phiD)
        }
        return max(0.0, price)
    }

    /**
     * Prices an institutional Cap or Floor on Euribor 3M
     */
    fun priceCapFloor(
        tradeId: String,
        optionType: OptionType,
        strikePercent: Double,
        maturityYears: Double,
        notionalEur: Double,
        discountCurve: YieldCurve,
        projectionCurve: YieldCurve,
        normalVolBp: Double = 52.0
    ): CapFloorTrade {
        val isCap = (optionType == OptionType.CAP)
        val strikeDec = strikePercent / 100.0
        val volDec = normalVolBp / 10_000.0

        val periods = (maturityYears * 4).toInt().coerceAtLeast(1)
        val dt = 0.25
        var totalPremium = 0.0
        var totalVega = 0.0
        var totalDelta = 0.0

        for (i in 1..periods) {
            val tStart = (i - 1) * dt
            val tEnd = i * dt
            val fwdRate = CurveConstructionEngine.calculateForwardRate(projectionCurve, tStart, tEnd) / 100.0
            val df = discountCurve.discountFactorAt(tEnd)

            val capletPrice = bachelierPrice(isCap, fwdRate, strikeDec, tStart, volDec, df, dt) * notionalEur
            totalPremium += capletPrice

            // Vega per 1 bp vol change
            val d = if (tStart > 0) (fwdRate - strikeDec) / (volDec * sqrt(tStart)) else 0.0
            val capletVega = df * dt * notionalEur * sqrt(max(0.001, tStart)) * normalPdf(d) * 0.0001
            totalVega += capletVega

            val capletDelta = df * dt * (if (isCap) normalCdf(d) else -normalCdf(-d))
            totalDelta += capletDelta
        }

        val dv01 = totalDelta * notionalEur * 0.0001
        val theta = -totalPremium * 0.05 / 365.0
        val gamma = (totalDelta * 1.5) / 100.0

        return CapFloorTrade(
            tradeId = tradeId,
            optionType = optionType,
            strikeRate = strikePercent,
            underlyingTenor = EuriborTenor.THREE_MONTHS,
            maturityYears = maturityYears,
            notionalEur = notionalEur,
            impliedVolBp = normalVolBp,
            premiumEur = totalPremium,
            delta = totalDelta / periods,
            vegaEur = totalVega,
            gamma = gamma,
            thetaEur = theta,
            dv01Eur = dv01
        )
    }

    /**
     * Prices an institutional Swaption (European exercise)
     */
    fun priceSwaption(
        tradeId: String,
        optionType: OptionType, // PAYER_SWAPTION or RECEIVER_SWAPTION
        expiryYears: Double,
        underlyingTenorYears: Double,
        strikePercent: Double,
        notionalEur: Double,
        discountCurve: YieldCurve,
        projectionCurve: YieldCurve,
        normalVolBp: Double = 56.0
    ): SwaptionTrade {
        val isPayer = (optionType == OptionType.PAYER_SWAPTION)
        val strikeDec = strikePercent / 100.0
        val volDec = normalVolBp / 10_000.0

        // Forward swap rate starting at expiryYears for underlyingTenorYears
        val fwdSwapRate = CurveConstructionEngine.calculateForwardRate(
            projectionCurve,
            expiryYears,
            expiryYears + underlyingTenorYears
        ) / 100.0

        // Annuity calculation for underlying swap
        var annuity = 0.0
        val steps = underlyingTenorYears.toInt().coerceAtLeast(1)
        for (i in 1..steps) {
            val tPay = expiryYears + i * 1.0
            annuity += discountCurve.discountFactorAt(tPay) * 1.0
        }

        val tExp = max(0.01, expiryYears)
        val volSqrtT = volDec * sqrt(tExp)
        val d = (fwdSwapRate - strikeDec) / volSqrtT
        val phiD = normalPdf(d)
        val cdfD = normalCdf(d)

        val price = if (isPayer) {
            annuity * ((fwdSwapRate - strikeDec) * cdfD + volSqrtT * phiD)
        } else {
            annuity * ((strikeDec - fwdSwapRate) * normalCdf(-d) + volSqrtT * phiD)
        }
        val totalPremium = price * notionalEur
        val vega = annuity * sqrt(tExp) * phiD * notionalEur * 0.0001
        val delta = if (isPayer) annuity * cdfD else -annuity * normalCdf(-d)
        val dv01 = delta * notionalEur * 0.0001

        return SwaptionTrade(
            tradeId = tradeId,
            optionType = optionType,
            expiryYears = expiryYears,
            underlyingTenorYears = underlyingTenorYears,
            strikeRate = strikePercent,
            forwardSwapRate = fwdSwapRate * 100.0,
            normalVolBp = normalVolBp,
            notionalEur = notionalEur,
            premiumEur = totalPremium,
            delta = delta,
            vegaEur = vega,
            dv01Eur = dv01
        )
    }

    /**
     * Institutional Euro Swaption Volatility Grid (ATM normal vol in bps, 25D skew)
     */
    fun getEuroSwaptionVolGrid(): List<VolatilitySurfacePoint> {
        return listOf(
            VolatilitySurfacePoint("1M", 0.0833, "1Y", 1.0, 48.5, 52.1, 46.2, -5.9, 2.1),
            VolatilitySurfacePoint("1M", 0.0833, "5Y", 5.0, 52.0, 56.4, 49.5, -6.9, 2.5),
            VolatilitySurfacePoint("3M", 0.2500, "1Y", 1.0, 49.2, 53.0, 47.0, -6.0, 2.2),
            VolatilitySurfacePoint("3M", 0.2500, "5Y", 5.0, 53.8, 58.1, 51.0, -7.1, 2.6),
            VolatilitySurfacePoint("6M", 0.5000, "5Y", 5.0, 55.4, 59.8, 52.6, -7.2, 2.8),
            VolatilitySurfacePoint("1Y", 1.0000, "2Y", 2.0, 53.0, 57.2, 50.4, -6.8, 2.4),
            VolatilitySurfacePoint("1Y", 1.0000, "5Y", 5.0, 56.2, 60.9, 53.1, -7.8, 3.0),
            VolatilitySurfacePoint("1Y", 1.0000, "10Y", 10.0, 54.5, 58.9, 51.8, -7.1, 2.7),
            VolatilitySurfacePoint("5Y", 5.0000, "5Y", 5.0, 51.0, 54.8, 48.8, -6.0, 2.3),
            VolatilitySurfacePoint("5Y", 5.0000, "10Y", 10.0, 48.2, 51.5, 46.0, -5.5, 2.1)
        )
    }
}
