package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DataClassification
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalNegative
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun InstitutionalHeader(
    onOpenConsole: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalPanel)
            .border(1.dp, TerminalBorder)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("terminal_header")
    ) {
        // Top Branding & Market Status Line
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "RHINOQUANT",
                    color = TerminalCyanBlue,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = " // EURIBOR",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.OFFICIAL)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Live market green dot
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(TerminalPositive, CircleShape)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "TARGET2: 11:00 CET FIXED",
                    color = TerminalTextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Rates Ticker Ribbon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TickerRateItem(name = "EURIBOR 3M", value = "3.238%", change = "+0.4 bp", isPositive = true)
            TickerRateItem(name = "€STR O/N", value = "3.152%", change = "0.0 bp", isPositive = true)
            TickerRateItem(name = "3M/€STR BASIS", value = "+8.4 bp", change = "+0.8 bp", isPositive = true)
            TickerRateItem(name = "ECB DFR", value = "3.250%", change = "Unchanged", isPositive = true)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Quick Command Bar Prompt
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(0.5.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .clickable { onOpenConsole() }
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .testTag("quick_command_trigger"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "RQQL Terminal",
                    tint = TerminalCyanBlue,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "RQ-RATES command line (e.g. 'EURIBOR 3M', 'CURVE ESTR', 'DV01 PORTFOLIO')...",
                    color = TerminalTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = "RUN [↵]",
                color = TerminalCyanBlue,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun TickerRateItem(
    name: String,
    value: String,
    change: String,
    isPositive: Boolean
) {
    Column {
        Text(
            text = name,
            color = TerminalTextMuted,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = value,
                color = TerminalTextPrimary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = change,
                color = if (change.startsWith("+")) TerminalPositive else if (change.startsWith("-")) TerminalNegative else TerminalTextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
