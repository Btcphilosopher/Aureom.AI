package com.example.domain.engine

import com.example.domain.model.DataClassification
import com.example.domain.model.EuriborTenor

data class RqqlResult(
    val command: String,
    val status: String, // "SUCCESS", "EXECUTED", "SYNTAX_ERROR"
    val classification: DataClassification,
    val primaryMessage: String,
    val details: List<Pair<String, String>> = emptyList(),
    val targetWorkspaceIndex: Int? = null
)

object RqqlCommandEngine {

    val SAMPLE_COMMANDS = listOf(
        "EURIBOR 3M",
        "CURVE EURIBOR",
        "CURVE ESTR",
        "BASIS 3M/6M",
        "ESTR VS EURIBOR 3M",
        "SWAP 5Y EURIBOR",
        "DV01 PORTFOLIO",
        "STRESS CURVE +25BP",
        "FORECAST EURIBOR 3M",
        "SHOW FIXING 2026-10-07",
        "FUTURES 3M",
        "FRA 3X6",
        "METHODOLOGY WATERFALL"
    )

    fun execute(query: String): RqqlResult {
        val q = query.trim().uppercase()

        return when {
            q == "HELP" || q == "?" -> {
                RqqlResult(
                    command = query,
                    status = "SUCCESS",
                    classification = DataClassification.OFFICIAL,
                    primaryMessage = "RQ-RATES Command Line / RQQL syntax reference:",
                    details = listOf(
                        "EURIBOR [1W|1M|3M|6M|12M]" to "Show official fixing and metrics for tenor",
                        "CURVE [EURIBOR|ESTR]" to "Display yield curve term structure and nodes",
                        "BASIS [3M/6M|6M/12M|ESTR]" to "Analyze relative value and tenor basis",
                        "SWAP [TENOR] EURIBOR" to "Price par swap and cashflows (e.g. SWAP 5Y EURIBOR)",
                        "DV01 PORTFOLIO" to "Display bucketed Key-Rate DV01 sensitivity",
                        "STRESS CURVE [+25BP|-25BP]" to "Simulate parametric curve shock",
                        "FORECAST EURIBOR [TENOR]" to "Display Nelson-Siegel / econometric model forecast",
                        "SHOW FIXING [DATE]" to "Query historical TARGET2 fixing archive",
                        "METHODOLOGY" to "Show EMMI hybrid waterfall Level 1/2.1/2.2/2.3 breakdown"
                    )
                )
            }

            q.startsWith("EURIBOR") -> {
                val tenorStr = q.removePrefix("EURIBOR").trim()
                if (tenorStr.isEmpty() || tenorStr == "FIXINGS") {
                    RqqlResult(
                        command = query,
                        status = "SUCCESS",
                        classification = DataClassification.OFFICIAL,
                        primaryMessage = "EURIBOR Official Benchmark Tenors (EMMI 11:00 CET):",
                        details = listOf(
                            "1W Euribor" to "3.165% (Δ -0.2 bp)",
                            "1M Euribor" to "3.185% (Δ +0.1 bp)",
                            "3M Euribor" to "3.238% (Δ +0.4 bp)",
                            "6M Euribor" to "3.276% (Δ +0.2 bp)",
                            "12M Euribor" to "3.291% (Δ -0.3 bp)"
                        ),
                        targetWorkspaceIndex = 0
                    )
                } else if (tenorStr == "CURVE") {
                    RqqlResult(
                        command = query,
                        status = "SUCCESS",
                        classification = DataClassification.CALCULATED,
                        primaryMessage = "EURIBOR Spot Term Structure: 1W (3.165%) -> 12M (3.291%)",
                        details = listOf(
                            "Interpolation" to "Log-Linear Discount / Cubic Spline",
                            "1M - 3M Slope" to "+5.3 bp",
                            "3M - 6M Slope" to "+3.8 bp",
                            "6M - 12M Slope" to "+1.5 bp",
                            "Total Slope (1M-12M)" to "+10.6 bp"
                        ),
                        targetWorkspaceIndex = 1
                    )
                } else {
                    val tenor = EuriborTenor.fromCode(tenorStr) ?: EuriborTenor.THREE_MONTHS
                    val rate = when (tenor) {
                        EuriborTenor.ONE_WEEK -> 3.165
                        EuriborTenor.ONE_MONTH -> 3.185
                        EuriborTenor.THREE_MONTHS -> 3.238
                        EuriborTenor.SIX_MONTHS -> 3.276
                        EuriborTenor.TWELVE_MONTHS -> 3.291
                        else -> 3.200
                    }
                    RqqlResult(
                        command = query,
                        status = "SUCCESS",
                        classification = DataClassification.OFFICIAL,
                        primaryMessage = "EURIBOR ${tenor.code} Fixing: ${String.format("%.3f", rate)}%",
                        details = listOf(
                            "Publication Date" to "2026-10-07",
                            "Publication Time" to "11:00 CET",
                            "Status" to "Confirmed Official",
                            "Daily Change" to "+0.4 bp",
                            "52W Range" to "3.110% - 3.820%",
                            "EMMI Waterfall" to "Level 1: 41.6% | Level 2: 58.4%"
                        ),
                        targetWorkspaceIndex = 0
                    )
                }
            }

            q.startsWith("CURVE") -> {
                val isEstr = q.contains("ESTR")
                RqqlResult(
                    command = query,
                    status = "SUCCESS",
                    classification = DataClassification.CALCULATED,
                    primaryMessage = if (isEstr) "€STR OIS Multi-Curve Discount Structure" else "Euribor Spot & Forward Curve Projection",
                    details = listOf(
                        "Anchor Rate" to if (isEstr) "3.152% (ECB O/N)" else "3.238% (Euribor 3M)",
                        "1Y Zero Rate" to if (isEstr) "3.158%" else "3.291%",
                        "5Y Zero Rate" to if (isEstr) "2.650%" else "2.810%",
                        "10Y Zero Rate" to if (isEstr) "2.580%" else "2.735%",
                        "Nelson-Siegel R²" to "0.994"
                    ),
                    targetWorkspaceIndex = if (isEstr) 3 else 1
                )
            }

            q.startsWith("BASIS") || q.contains("VS EURIBOR") -> {
                RqqlResult(
                    command = query,
                    status = "SUCCESS",
                    classification = DataClassification.MODELLED,
                    primaryMessage = "EURIBOR / €STR Relative Value & Tenor Basis Analytics",
                    details = listOf(
                        "3M Euribor - Compounded €STR" to "+8.4 bp (z-score: +0.78)",
                        "6M Euribor - Compounded €STR" to "+12.0 bp (z-score: +0.95)",
                        "1M vs 3M Basis" to "+5.3 bp",
                        "3M vs 6M Basis" to "+3.8 bp",
                        "Credit Proxy Component" to "3.4 bp (40% of 3M basis)",
                        "Liquidity Component" to "2.5 bp (30% of 3M basis)"
                    ),
                    targetWorkspaceIndex = 2
                )
            }

            q.startsWith("SWAP") -> {
                val tenor = if (q.contains("10Y")) "10Y" else if (q.contains("2Y")) "2Y" else "5Y"
                val parRate = if (tenor == "2Y") 2.980 else if (tenor == "10Y") 2.685 else 2.765
                RqqlResult(
                    command = query,
                    status = "SUCCESS",
                    classification = DataClassification.CALCULATED,
                    primaryMessage = "EUR Fixed vs Euribor 3M Par Swap [$tenor]",
                    details = listOf(
                        "Par Swap Rate" to "${String.format("%.3f", parRate)}%",
                        "Discount Curve" to "€STR OIS Discounting",
                        "Projection Curve" to "Euribor 3M Projection",
                        "DV01 (EUR 100M)" to "EUR 4,820 per bp",
                        "Modified Duration" to "4.72 years",
                        "Convexity" to "0.26"
                    ),
                    targetWorkspaceIndex = 3
                )
            }

            q.startsWith("DV01") || q.startsWith("RISK") -> {
                RqqlResult(
                    command = query,
                    status = "SUCCESS",
                    classification = DataClassification.CALCULATED,
                    primaryMessage = "Rates Portfolio Key-Rate Risk Summary",
                    details = listOf(
                        "Total Net DV01" to "+EUR 3,420 / bp (Pay Fixed Bias)",
                        "Front-End DV01 (0-1Y)" to "EUR 1,368 / bp",
                        "Belly DV01 (2-5Y)" to "EUR 1,607 / bp",
                        "Long-End DV01 (7-30Y)" to "EUR 445 / bp",
                        "Total Portfolio Vega" to "EUR 8,450 / bp"
                    ),
                    targetWorkspaceIndex = 7
                )
            }

            q.startsWith("STRESS") || q.startsWith("SCENARIO") -> {
                RqqlResult(
                    command = query,
                    status = "SUCCESS",
                    classification = DataClassification.SIMULATED,
                    primaryMessage = "Curve Scenario Stress Test Evaluated",
                    details = listOf(
                        "Shock Applied" to "+25 bp parallel shift across Euro yield curves",
                        "Portfolio P&L Impact" to "-EUR 75,240",
                        "3M Euribor Impact" to "+25.0 bp -> 3.488%",
                        "€STR Impact" to "+25.0 bp -> 3.402%",
                        "Credit Tension" to "Stable (normal pass-through)"
                    ),
                    targetWorkspaceIndex = 7
                )
            }

            q.startsWith("FORECAST") -> {
                RqqlResult(
                    command = query,
                    status = "SUCCESS",
                    classification = DataClassification.FORECAST,
                    primaryMessage = "RhinoQuant Research Euribor Model Forecast (Non-Official)",
                    details = listOf(
                        "Model" to "Nelson-Siegel Dynamic Factor + Forward Implied",
                        "Horizon" to "3M forward (Jan 2027)",
                        "Forecast Point" to "3.210% (95% CI: 3.125% - 3.295%)",
                        "Assumption" to "ECB holds rates unchanged; interbank spreads constant",
                        "Disclaimer" to "Research econometric model only; not an official forecast"
                    ),
                    targetWorkspaceIndex = 1
                )
            }

            q.startsWith("METHODOLOGY") || q.startsWith("WATERFALL") -> {
                RqqlResult(
                    command = query,
                    status = "SUCCESS",
                    classification = DataClassification.OFFICIAL,
                    primaryMessage = "EMMI Hybrid Waterfall Framework (June 2026 Review)",
                    details = listOf(
                        "Level 1 (Eligible Transactions)" to "41.6% (3M Tenor)",
                        "Level 2.1 (Interpolation)" to "22.4%",
                        "Level 2.2 (Rollover Adjusted)" to "24.5%",
                        "Level 2.3 (Modeled Extrapolation)" to "11.5%",
                        "Level 3 (Contingency)" to "0.0%"
                    ),
                    targetWorkspaceIndex = 9
                )
            }

            else -> {
                RqqlResult(
                    command = query,
                    status = "EXECUTED",
                    classification = DataClassification.CALCULATED,
                    primaryMessage = "Executed query: '$query'. Type HELP for available commands.",
                    details = listOf(
                        "Command" to query,
                        "Engine" to "RhinoQuant RQ-RATES Parser v3.7"
                    )
                )
            }
        }
    }
}
