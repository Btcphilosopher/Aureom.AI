package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.repository.TerminalRepository
import com.example.domain.engine.BasisAndFundingEngine
import com.example.domain.engine.CurveConstructionEngine
import com.example.domain.engine.RiskAndScenarioEngine
import com.example.domain.engine.RqqlCommandEngine
import com.example.domain.engine.RqqlResult
import com.example.domain.engine.SwapPricingEngine
import com.example.domain.model.CurveSteepnessMetric
import com.example.domain.model.EcbPolicyRates
import com.example.domain.model.EstrFixing
import com.example.domain.model.EuriborFixing
import com.example.domain.model.EuriborTenor
import com.example.domain.model.KeyRateRiskBucket
import com.example.domain.model.RatesPortfolio
import com.example.domain.model.RelativeValueSpread
import com.example.domain.model.RhinoQuantDecomposition
import com.example.domain.model.ScenarioImpactResult
import com.example.domain.model.TradeDirection
import com.example.domain.model.YieldCurve
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class TerminalViewModel(
    private val repository: TerminalRepository = TerminalRepository()
) : ViewModel() {

    private val _activeWorkspace = MutableStateFlow(0)
    val activeWorkspace: StateFlow<Int> = _activeWorkspace.asStateFlow()

    private val _selectedTenor = MutableStateFlow(EuriborTenor.THREE_MONTHS)
    val selectedTenor: StateFlow<EuriborTenor> = _selectedTenor.asStateFlow()

    private val _historicalPeriod = MutableStateFlow("TODAY")
    val historicalPeriod: StateFlow<String> = _historicalPeriod.asStateFlow()

    private val _historicalCurve = MutableStateFlow(repository.getHistoricalCurve("TODAY"))
    val historicalCurve: StateFlow<YieldCurve> = _historicalCurve.asStateFlow()

    // Command Line State
    private val _commandInput = MutableStateFlow("")
    val commandInput: StateFlow<String> = _commandInput.asStateFlow()

    private val _commandHistory = MutableStateFlow<List<RqqlResult>>(
        listOf(
            RqqlCommandEngine.execute("EURIBOR 3M"),
            RqqlCommandEngine.execute("BASIS 3M/6M")
        )
    )
    val commandHistory: StateFlow<List<RqqlResult>> = _commandHistory.asStateFlow()

    // Expose Data from Repository
    val euriborFixings: StateFlow<Map<EuriborTenor, EuriborFixing>> = repository.euriborFixings
    val estrFixing: StateFlow<EstrFixing> = repository.estrFixing
    val ecbPolicyRates: StateFlow<EcbPolicyRates> = repository.ecbPolicyRates
    val euribor3mCurve: StateFlow<YieldCurve> = repository.euribor3mCurve
    val euribor6mCurve: StateFlow<YieldCurve> = repository.euribor6mCurve
    val estrDiscountCurve: StateFlow<YieldCurve> = repository.estrDiscountCurve
    val portfolio: StateFlow<RatesPortfolio> = repository.portfolio

    // Calculated Relative Value
    val relativeValueSpreads: List<RelativeValueSpread>
        get() {
            val fixings = euriborFixings.value.mapValues { it.value.officialFixing }
            val estrComp = mapOf(
                EuriborTenor.ONE_WEEK to 3.150,
                EuriborTenor.ONE_MONTH to 3.152,
                EuriborTenor.THREE_MONTHS to 3.154,
                EuriborTenor.SIX_MONTHS to 3.156,
                EuriborTenor.TWELVE_MONTHS to 3.158
            )
            return BasisAndFundingEngine.calculateRelativeValueSpreads(fixings, estrComp, estrFixing.value.rate)
        }

    val modelledDecomposition: RhinoQuantDecomposition
        get() = BasisAndFundingEngine.decomposeEuriborEstrBasis(
            selectedTenor.value,
            when (selectedTenor.value) {
                EuriborTenor.ONE_WEEK -> 1.5
                EuriborTenor.ONE_MONTH -> 3.3
                EuriborTenor.THREE_MONTHS -> 8.4
                EuriborTenor.SIX_MONTHS -> 12.0
                EuriborTenor.TWELVE_MONTHS -> 13.3
                else -> 8.4
            }
        )

    val curveSteepnessMetrics: List<CurveSteepnessMetric>
        get() = CurveConstructionEngine.calculateCurveSteepness(euribor3mCurve.value)

    val keyRateRiskBuckets: List<KeyRateRiskBucket>
        get() = RiskAndScenarioEngine.calculateKeyRateRisk(portfolio.value)

    val scenarioResults: List<ScenarioImpactResult>
        get() = RiskAndScenarioEngine.evaluateScenarios(portfolio.value)

    fun setWorkspace(index: Int) {
        _activeWorkspace.value = index
    }

    fun selectTenor(tenor: EuriborTenor) {
        _selectedTenor.value = tenor
    }

    fun selectHistoricalPeriod(period: String) {
        _historicalPeriod.value = period
        _historicalCurve.value = repository.getHistoricalCurve(period)
    }

    fun onCommandInputChange(text: String) {
        _commandInput.value = text
    }

    fun executeCurrentCommand() {
        val cmd = _commandInput.value.trim()
        if (cmd.isNotEmpty()) {
            val res = RqqlCommandEngine.execute(cmd)
            _commandHistory.value = listOf(res) + _commandHistory.value
            _commandInput.value = ""
            if (res.targetWorkspaceIndex != null) {
                _activeWorkspace.value = res.targetWorkspaceIndex
            }
        }
    }

    fun executeQuickCommand(cmd: String) {
        val res = RqqlCommandEngine.execute(cmd)
        _commandHistory.value = listOf(res) + _commandHistory.value
        if (res.targetWorkspaceIndex != null) {
            _activeWorkspace.value = res.targetWorkspaceIndex
        }
    }

    fun bookNewSwap(
        direction: TradeDirection,
        notionalEur: Double,
        maturityYears: Double,
        fixedRatePercent: Double,
        counterparty: String
    ) {
        val newSwap = SwapPricingEngine.priceSwap(
            tradeId = "SWP-MAN-${UUID.randomUUID().toString().take(6).uppercase()}",
            book = "RATES_EXEC_01",
            desk = "Euro Rates Trading",
            counterparty = counterparty,
            notionalEur = notionalEur,
            direction = direction,
            fixedRatePercent = fixedRatePercent,
            floatingIndex = "Euribor 3M",
            maturityYears = maturityYears,
            discountCurveEstr = estrDiscountCurve.value,
            projectionCurveEuribor = euribor3mCurve.value
        )
        repository.bookTrade(newSwap)
    }
}
