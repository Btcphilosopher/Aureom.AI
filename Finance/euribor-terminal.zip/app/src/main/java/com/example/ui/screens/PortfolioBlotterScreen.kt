package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DataClassification
import com.example.domain.model.TradeDirection
import com.example.ui.components.DataClassificationBadge
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyanBlue
import com.example.ui.theme.TerminalNegative
import com.example.ui.theme.TerminalPanel
import com.example.ui.theme.TerminalPositive
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun PortfolioBlotterScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val portfolio by viewModel.portfolio.collectAsState()
    var showNewTradeDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalPanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("workspace_portfolio_blotter")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "RATES TRADE BLOTTER & PORTFOLIO",
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                DataClassificationBadge(classification = DataClassification.CALCULATED)
            }

            Box(
                modifier = Modifier
                    .background(TerminalCyanBlue, RoundedCornerShape(3.dp))
                    .clickable { showNewTradeDialog = true }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("btn_new_trade"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "+ NEW TRADE TICKET",
                    color = TerminalPanel,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Portfolio Level Totals Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            PortfolioKpi("TOTAL NOTIONAL", "€${String.format("%,.0f", portfolio.totalNotionalEur)}", TerminalCyanBlue)
            val npvColor = if (portfolio.totalNpvEur >= 0) TerminalPositive else TerminalNegative
            PortfolioKpi("NET PORTFOLIO NPV", "€${String.format("%,.0f", portfolio.totalNpvEur)}", npvColor)
            PortfolioKpi("PORTFOLIO DV01", "€${String.format("%,.0f", portfolio.totalDv01Eur)} / bp", TerminalTextPrimary)
            PortfolioKpi("PORTFOLIO VEGA", "€${String.format("%,.0f", portfolio.totalVegaEur)} / bp", TerminalTextSecondary)
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Open Interest Rate Swaps Table
        Text(
            text = "INTEREST RATE SWAPS (IRS) BOOK",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TRADE ID", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                Text("COUNTERPARTY", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                Text("NOTIONAL (EUR)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                Text("DIR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                Text("FIXED", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                Text("INDEX", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                Text("NPV (EUR)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f))
                Text("DV01", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
            }

            portfolio.swaps.forEach { swp ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(swp.tradeId, color = TerminalCyanBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.4f))
                    Text(swp.counterparty, color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    Text("€${String.format("%,.0f", swp.notionalEur)}", color = TerminalTextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.4f))
                    val dirStr = if (swp.direction == TradeDirection.PAY_FIXED) "PAY" else "REC"
                    Text(dirStr, color = if (dirStr == "PAY") TerminalNegative else TerminalPositive, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
                    Text("${String.format("%.2f", swp.fixedRate)}%", color = TerminalTextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    Text(swp.floatingIndex, color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    val npvColor = if (swp.npvEur >= 0) TerminalPositive else TerminalNegative
                    Text("€${String.format("%,.0f", swp.npvEur)}", color = npvColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
                    Text("€${String.format("%,.0f", kotlin.math.abs(swp.dv01Eur))}", color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // FRAs and Options Blotter
        Text(
            text = "MONEY MARKET DERIVATIVES (FRAS & CAPS/SWAPTIONS)",
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface, RoundedCornerShape(4.dp))
                .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            portfolio.fras.forEach { fra ->
                DerivRow(fra.tradeId, fra.tenorLabel, "€${String.format("%,.0f", fra.notionalEur)}", "Fix: ${fra.fixedRate}%", "Payoff: €${String.format("%,.0f", fra.payoffEur)}", "DV01: €${String.format("%,.0f", fra.dv01Eur)}")
            }
            portfolio.options.forEach { opt ->
                DerivRow(opt.tradeId, "${opt.underlyingTenor.code} CAP", "€${String.format("%,.0f", opt.notionalEur)}", "Strike: ${opt.strikeRate}%", "Prem: €${String.format("%,.0f", opt.premiumEur)}", "Vega: €${String.format("%,.0f", opt.vegaEur)}")
            }
            portfolio.swaptions.forEach { swpn ->
                DerivRow(swpn.tradeId, "1Yx5Y SWAPTION", "€${String.format("%,.0f", swpn.notionalEur)}", "Strike: ${swpn.strikeRate}%", "Prem: €${String.format("%,.0f", swpn.premiumEur)}", "Vega: €${String.format("%,.0f", swpn.vegaEur)}")
            }
        }
    }

    // New Trade Ticket Booking Modal Dialog
    if (showNewTradeDialog) {
        NewTradeTicketDialog(
            onDismiss = { showNewTradeDialog = false },
            onConfirmTrade = { dir, notional, matYears, rate, cpty ->
                viewModel.bookNewSwap(dir, notional, matYears, rate, cpty)
                showNewTradeDialog = false
            }
        )
    }
}

@Composable
private fun PortfolioKpi(title: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column {
        Text(title, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DerivRow(id: String, type: String, notional: String, strike: String, value: String, sens: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(id, color = TerminalCyanBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text(type, color = TerminalTextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(notional, color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(strike, color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalPositive, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text(sens, color = TerminalTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun NewTradeTicketDialog(
    onDismiss: () -> Unit,
    onConfirmTrade: (TradeDirection, Double, Double, Double, String) -> Unit
) {
    var selectedDirection by remember { mutableStateOf(TradeDirection.PAY_FIXED) }
    var notionalStr by remember { mutableStateOf("25000000") }
    var maturityYearsStr by remember { mutableStateOf("5.0") }
    var fixedRateStr by remember { mutableStateOf("2.80") }
    var counterpartyStr by remember { mutableStateOf("Société Générale") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TerminalPanel,
        title = {
            Text(
                text = "EXECUTE TRADE TICKET (EUR IRS)",
                color = TerminalCyanBlue,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = "Desk: Euro Linear Rates | Index: Euribor 3M | Clearing: LCH",
                    color = TerminalTextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Direction selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (selectedDirection == TradeDirection.PAY_FIXED) TerminalNegative else TerminalSurface, RoundedCornerShape(3.dp))
                            .clickable { selectedDirection = TradeDirection.PAY_FIXED }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("PAY FIXED", color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (selectedDirection == TradeDirection.RECEIVE_FIXED) TerminalPositive else TerminalSurface, RoundedCornerShape(3.dp))
                            .clickable { selectedDirection = TradeDirection.RECEIVE_FIXED }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("RECEIVE FIXED", color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notionalStr,
                    onValueChange = { notionalStr = it },
                    label = { Text("Notional (EUR)", color = TerminalTextMuted, fontSize = 10.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = maturityYearsStr,
                    onValueChange = { maturityYearsStr = it },
                    label = { Text("Tenor (Years)", color = TerminalTextMuted, fontSize = 10.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = fixedRateStr,
                    onValueChange = { fixedRateStr = it },
                    label = { Text("Fixed Rate (%)", color = TerminalTextMuted, fontSize = 10.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = counterpartyStr,
                    onValueChange = { counterpartyStr = it },
                    label = { Text("Counterparty", color = TerminalTextMuted, fontSize = 10.sp) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val notional = notionalStr.toDoubleOrNull() ?: 25_000_000.0
                    val mat = maturityYearsStr.toDoubleOrNull() ?: 5.0
                    val rate = fixedRateStr.toDoubleOrNull() ?: 2.80
                    onConfirmTrade(selectedDirection, notional, mat, rate, counterpartyStr)
                },
                colors = ButtonDefaults.buttonColors(containerColor = TerminalCyanBlue)
            ) {
                Text("BOOK TRADE", color = TerminalPanel, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TerminalSurface)
            ) {
                Text("CANCEL", color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    )
}
