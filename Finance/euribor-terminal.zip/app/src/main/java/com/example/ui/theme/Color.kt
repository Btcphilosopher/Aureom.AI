package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RhinoQuant Institutional Rates Terminal Palette
val TerminalNavyDark = Color(0xFF080D1A)
val TerminalPanel = Color(0xFF0E1726)
val TerminalSurface = Color(0xFF131F33)
val TerminalSurfaceElevated = Color(0xFF192842)
val TerminalBorder = Color(0xFF223654)
val TerminalBorderSubtle = Color(0xFF192A44)

// Typographic Colors
val TerminalTextPrimary = Color(0xFFF1F5F9)
val TerminalTextSecondary = Color(0xFF94A3B8)
val TerminalTextMuted = Color(0xFF64748B)

// Financial Semantic Accents
val TerminalCyanBlue = Color(0xFF38BDF8)
val TerminalMutedBlue = Color(0xFF2563EB)
val TerminalPositive = Color(0xFF10B981) // Up / Inflow / Clean
val TerminalNegative = Color(0xFFF43F5E) // Down / Outflow
val TerminalAmber = Color(0xFFF59E0B)    // Alert / Modelled / Level 2
val TerminalPurpleMuted = Color(0xFF818CF8) // Secondary Curve
val TerminalGold = Color(0xFFFBBF24)

// Classification Badges
val BadgeOfficialBg = Color(0xFF064E3B)
val BadgeOfficialText = Color(0xFF34D399)
val BadgeMarketBg = Color(0xFF0C4A6E)
val BadgeMarketText = Color(0xFF38BDF8)
val BadgeModelledBg = Color(0xFF78350F)
val BadgeModelledText = Color(0xFFFBBF24)
val BadgeForecastBg = Color(0xFF312E81)
val BadgeForecastText = Color(0xFFA5B4FC)
val BadgeSimulatedBg = Color(0xFF374151)
val BadgeSimulatedText = Color(0xFFE5E7EB)
