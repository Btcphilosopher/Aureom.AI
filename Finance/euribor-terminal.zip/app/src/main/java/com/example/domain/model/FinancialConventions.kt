package com.example.domain.model

enum class DayCountConvention(val displayName: String, val daysInYear: Double) {
    ACT_360("ACT/360", 360.0),
    ACT_365F("ACT/365F", 365.0),
    THIRTY_360("30/360", 360.0),
    THIRTY_E_360("30E/360", 360.0);

    fun yearFraction(days: Int): Double = days / daysInYear
}

enum class BusinessDayConvention(val displayName: String) {
    MODIFIED_FOLLOWING("Modified Following"),
    FOLLOWING("Following"),
    PRECEDING("Preceding"),
    UNADJUSTED("Unadjusted")
}

enum class DataClassification(val label: String, val description: String) {
    OFFICIAL("OFFICIAL", "Published by authorized administrator (e.g., EMMI / ECB)"),
    MARKET("MARKET", "Live interbank market pricing or exchange quote"),
    CALCULATED("CALCULATED", "Derived via exact analytical formulas / conventions"),
    MODELLED("MODELLED", "RhinoQuant calibrated quantitative model output"),
    FORECAST("FORECAST", "Quantitative statistical / scenario projection"),
    SIMULATED("SIMULATED", "Parametric stress or scenario simulation"),
    HISTORICAL("HISTORICAL", "Historical observation from verified archive"),
    STALE("STALE", "Data has exceeded freshness threshold")
}

enum class DataQualityFlag {
    CLEAN,
    REVISED,
    DISLOCATION_DETECTED,
    HIGH_SPREAD,
    INTERPOLATED
}
