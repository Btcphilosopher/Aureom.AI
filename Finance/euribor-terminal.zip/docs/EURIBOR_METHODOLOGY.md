# Euribor Methodology & Governance Reference

## Official Status
- **Administrator**: European Money Markets Institute (EMMI)
- **Calculation Agent**: Global Rate Set Systems (GRSS)
- **Publication Frequency**: Every TARGET2 Day at 11:00 CET
- **Intraday Refixing**: Triggered if a calculation error $\ge 0.1$ bp is identified before 15:15 CET.

## Hybrid Waterfall Methodology Levels
- **Level 1**: Direct eligible unsecured deposit transactions of $\ge$ EUR 10M (1W/1M) or $\ge$ EUR 20M (3M/6M/12M) executed between 08:00 and 18:00 CET on the prior TARGET2 day.
- **Level 2.1**: Interpolation between contiguous official tenors with Level 1 backing.
- **Level 2.2**: Roll-forward of prior Level 1 transactions with market rate adjustments (€STR & OIS deltas).
- **Level 2.3**: Linear extrapolation and regression modeling against money-market benchmarks (refined in the June 2026 methodology review).
- **Level 3**: Contingency assessment if Levels 1 and 2 fail to produce a rate.

## Regulatory Safeguard
RhinoQuant Euribor Terminal is an analytics platform. It is not the benchmark administrator and does not calculate or determine official benchmark rates.
