# RhinoQuant EURIBOR Terminal — Quantitative Architecture

## 1. Euribor Reference Framework
- **Administrator**: European Money Markets Institute (EMMI)
- **Official Tenors**: 1 Week (1W), 1 Month (1M), 3 Months (3M), 6 Months (6M), 12 Months (12M).
- **Target Market**: Euro wholesale unsecured term lending market for credit institutions.
- **Publication Schedule**: Every TARGET2 business day at 11:00 CET.
- **Refixing Policy**: Intraday revisions permitted until 15:15 CET if errors exceed 0.1 bp.

## 2. EMMI Hybrid Waterfall Methodology
1. **Level 1**: Eligible direct unsecured deposit transactions executed during prior TARGET2 day.
2. **Level 2.1**: Tenor interpolation between contiguous official tenors with Level 1 backing.
3. **Level 2.2**: Rollover of historical Level 1 transactions adjusted for money-market changes (€STR/OIS shift).
4. **Level 2.3**: Linear extrapolation and money-market regressions (refined in the June 2026 EMMI review).
5. **Level 3**: Contingency assessment if Level 1 & 2 yield insufficient volume.

## 3. Multi-Curve Pricing Architecture
- **Discount Curve**: €STR OIS Discount Curve ($D_{\text{€STR}}(t)$).
- **Projection Curves**: Independent curves for Euribor 1M, Euribor 3M, Euribor 6M, and Euribor 12M.
- **Forward Rate Pricing**:
  $$F(t_1, t_2) = \frac{1}{\tau} \left( \frac{P_{\text{proj}}(t_1)}{P_{\text{proj}}(t_2)} - 1 \right)$$
- **Fixed-for-Floating Swap Pricing**:
  $$\text{NPV} = \sum_{j} N \cdot \tau_j \cdot F_j \cdot D_{\text{€STR}}(t_j) - \sum_{k} N \cdot \tau_k \cdot R_{\text{fix}} \cdot D_{\text{€STR}}(t_k)$$
- **Par Swap Rate**:
  $$R_{\text{par}} = \frac{\sum_{j} \tau_j F_j D_{\text{€STR}}(t_j)}{\sum_{k} \tau_k D_{\text{€STR}}(t_k)}$$

## 4. Options Pricing (Bachelier Model)
Euro interest rate swaptions and caps/floors utilize the **Normal Bachelier Model**:
$$d = \frac{F - K}{\sigma_N \sqrt{T}}$$
$$\text{Caplet} = D(T) \cdot \tau \cdot \left[ (F - K) \Phi(d) + \sigma_N \sqrt{T} \phi(d) \right]$$
$$\text{Vega} = D(T) \cdot \tau \cdot \sqrt{T} \phi(d)$$

## 5. Relative Value & RhinoQuant Modelled Decomposition
Observable Spread: $\text{Euribor} - \text{€STR}$
Decomposed analytically into:
1. **Bank Credit Proxy**: Credit risk premium estimated from panel bank CDS spreads.
2. **Liquidity / Collateral Premium**: Term liquidity preference over secured General Collateral repo.
3. **Term Tenor Horizon**: Uncertainty of interest rate fixing horizon.
4. **Market Stress Residual**: Dislocations or market microstructure frictions.
