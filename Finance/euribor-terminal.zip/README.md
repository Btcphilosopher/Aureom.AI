# RhinoQuant EURIBOR Terminal

A production-grade institutional European interest-rate, euro money-market, Euribor analytics and trading-research terminal for rates traders, bank treasuries, fixed-income quants, derivatives structurers, and risk managers.

---

### CRITICAL REGULATORY SAFEGUARD & DISCLAIMER
> **RHINOQUANT EURIBOR IS AN ANALYTICS AND RESEARCH TERMINAL. IT IS NOT THE OFFICIAL EURIBOR ADMINISTRATOR AND DOES NOT DETERMINE OR PUBLISH THE OFFICIAL EURIBOR BENCHMARK.**
>
> Euribor® is a registered trademark of the European Money Markets Institute (EMMI). The official Euribor benchmark is administered solely by EMMI and published every TARGET2 business day at 11:00 CET. All official benchmark fixings displayed in this terminal are derived from accredited public transparency datasets or licensed redistributors. Modelled, scenario, and forecast values are analytical estimates computed by RhinoQuant quantitative algorithms and must never be construed as official rate submissions or benchmarks.

---

## Architecture & Workspaces

1. **HOME / EURIBOR FIXINGS**:
   - Official 5-tenor benchmark monitoring: **1W, 1M, 3M, 6M, 12M**.
   - Daily change (bp), weekly change, monthly change, YTD change, 52-week high/low ranges, publication status, timestamps, and data provenance.
   - ECB Policy Reference anchor (DFR: 3.25%, MRO: 3.40%, MLF: 3.65%) and €STR overnight volume breakdown.

2. **CURVE & TERM STRUCTURE**:
   - Multi-curve yield curve construction using log-linear discount factors and cubic spline interpolation.
   - Curve steepness & curvature metrics: **1M–3M, 3M–6M, 6M–12M, 1M–12M, 3M–12M**, and curvature butterfly ($2 \times 3\text{M} - 1\text{M} - 6\text{M}$), with 52-week percentiles and z-scores.
   - Nelson-Siegel 4-parameter estimation ($\beta_0, \beta_1, \beta_2, \lambda, R^2$).
   - Historical curve-over-curve replay engine comparing **Today, 1D ago, 1W ago, 1M ago, 3M ago, 6M ago, 1Y ago, and 5Y ago**.

3. **EURIBOR / €STR RELATIVE VALUE & BASIS**:
   - Distinct economic benchmark handling: Euribor wholesale unsecured term borrowing vs €STR overnight bank borrowing.
   - Observable basis spreads ($1\text{W}, 1\text{M}, 3\text{M}, 6\text{M}, 12\text{M}$ Euribor vs compounded €STR).
   - **RhinoQuant Modelled Decomposition**: Analytical attribution into **Bank Credit Component Proxy**, **Liquidity / Collateral Premium**, **Term Horizon Premium**, and **Market Stress Residual**.

4. **SWAPS & MULTI-CURVE OIS ENGINE**:
   - Dual-curve valuation adhering to LCH / Eurex clearing standards: floating leg Euribor forwards projected off Euribor projection curves; all cashflows discounted on the €STR OIS discount curve.
   - Par swap rate solver ($NPV = 0$), DV01, PV01, modified duration, convexity, and full cashflow schedule generator.
   - Floating-for-floating basis swaps ($3\text{M}$ vs $6\text{M}$ Euribor).

5. **FORWARDS & 3M EURIBOR FUTURES**:
   - Simply compounded forward rate calculation: $F(t_1, t_2) = \frac{1}{\tau} \left[\frac{P(t_1)}{P(t_2)} - 1\right]$.
   - 3M Euribor IMM quarterly futures contracts (FEU3 Dec26, Mar27, Jun27, Sep27, etc.) with implied rates, prices, convexity adjustment, and basis vs swap curves.

6. **FRAs & RATE OPTIONS PRICING**:
   - Forward Rate Agreements ($1\times4, 3\times6, 6\times9, 6\times12, 9\times12$) with discounted settlement payoffs and break-even rates.
   - Caps, floors, caplets, and swaptions priced using the **Normal Bachelier Model** (European interest rate desk standard).
   - Swaption volatility surface grid (normal vol in bp, ATM vol, 25D risk-reversal skew).

7. **EURO MONEY MARKETS & FUNDING**:
   - Multi-tier funding curves: Risk-free OIS, Secured Repo (German Bund GC), and Unsecured Bank Wholesale.
   - Commercial Paper (CP), Certificates of Deposit (CD), Treasury Bills (Bubills).

8. **RISK ENGINE & SCENARIO ANALYSIS**:
   - Bucketed Key-Rate DV01 (KRD) across 13 curve buckets ($1\text{M}, 3\text{M}, 6\text{M}, 9\text{M}, 1\text{Y}, 2\text{Y}, 3\text{Y}, 5\text{Y}, 7\text{Y}, 10\text{Y}, 15\text{Y}, 20\text{Y}, 30\text{Y}$).
   - ECB monetary policy rate shift simulations ($\pm25\text{ bp}, \pm50\text{ bp}$, steepener, flattener, credit stress).
   - Daily P&L factor attribution (carry/roll-down, curve movement, fixing movement, basis, volatility).

9. **TRADE BLOTTER & PORTFOLIO**:
   - Institutional trade blotter aggregating IRS, FRAs, futures, caps, and swaptions.
   - Interactive New Trade Ticket execution dialog.

10. **METHODOLOGY & AUDIT MONITOR**:
    - Detailed breakdown of the EMMI Hybrid Waterfall Methodology (Level 1, Level 2.1, Level 2.2, Level 2.3, Level 3).
    - June 2026 methodology update documentation.
    - Historical Refixing Monitor & 15:15 CET threshold verification rule ($\ge 0.1\text{ bp}$).
    - SHA-256 data provenance records.

11. **RQ-RATES COMMAND CONSOLE (RQQL)**:
    - High-density command line interface supporting queries like `EURIBOR 3M`, `CURVE EURIBOR`, `BASIS 3M/6M`, `ESTR VS EURIBOR 3M`, `SWAP 5Y EURIBOR`, `DV01 PORTFOLIO`, `STRESS CURVE +25BP`, `FORECAST EURIBOR 3M`, `SHOW FIXING 2026-10-07`, and `HELP`.
