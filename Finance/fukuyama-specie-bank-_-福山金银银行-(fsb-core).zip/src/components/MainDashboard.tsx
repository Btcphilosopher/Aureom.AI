/**
 * Fukuyama Specie Bank (FSB-Core)
 * Main Control Room & Institutional Monetary Architecture Overview
 */

import React from 'react';
import { 
  ShieldCheck, 
  TrendingUp, 
  Activity, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Zap, 
  Building2, 
  Layers, 
  Coins, 
  CreditCard,
  Lock,
  RefreshCw
} from 'lucide-react';
import { Language } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface MainDashboardProps {
  system: BankingSystem;
  lang: Language;
  onNavigate: (view: string) => void;
  onRefresh: () => void;
}

export const MainDashboard: React.FC<MainDashboardProps> = ({
  system,
  lang,
  onNavigate,
  onRefresh
}) => {
  const pos = system.getMonetaryPosition();
  const res = system.ledger.getReserveMetrics();
  const bs = system.ledger.getBalanceSheet();
  const recentEntries = system.ledger.getJournalEntries().slice(0, 5);

  return (
    <div className="space-y-4">
      {/* Top Banner Notice: The Central Banking Concept & Real World Boundary */}
      <div className="bg-slate-900 border-l-4 border-amber-500 p-3 rounded-r border-y border-r border-slate-800 text-xs font-mono text-slate-300">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
          <div className="flex items-start gap-2">
            <Lock className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
            <div>
              <span className="font-bold text-amber-300">
                {lang === 'en' ? 'MONETARY NATURE DISCLOSURE: ' : '货币属性法定披露：'}
              </span>
              <span>
                {lang === 'en'
                  ? 'FSB-CNY is a private banking deposit liability issued by Fukuyama Specie Bank, denominated in Renminbi. It is backed by eligible reserve assets and PBOC settlement balances. It is NOT sovereign legal tender.'
                  : '福山人民币存款 (FSB-CNY) 系由福山金银银行签发的、以法定人民币计价的商业银行私人负债，由合规央行准备金及高流动性国债资产全额增信支撑，绝非央行主权法定货币。'}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="px-2 py-0.5 bg-slate-800 border border-slate-700 text-cyan-300 rounded text-[11px]">
              PBOC M0/M1/M2 INTEROPERABLE
            </span>
          </div>
        </div>
      </div>

      {/* Grid: System Status & Monetary Position (Directly matching Prompt #44) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* System Status Panel */}
        <div className="bg-slate-900/90 border border-slate-800 rounded p-3.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="text-xs font-mono font-bold text-slate-200 tracking-wider flex items-center gap-2">
                <Activity className="w-3.5 h-3.5 text-cyan-400" />
                {lang === 'en' ? 'SYSTEM STATUS' : '系统运行状态'}
              </span>
              <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 border border-emerald-800 rounded">
                NORMAL 正常
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">RMB PAYMENT NETWORK</span>
                <span className="text-emerald-400 font-bold">ONLINE 在线</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">FSB LEDGER (ΣD=ΣC)</span>
                <span className="text-emerald-400 font-bold">ONLINE 在线</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">POS NETWORK</span>
                <span className="text-emerald-400 font-bold">ONLINE 在线</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">SETTLEMENT ENGINE</span>
                <span className="text-emerald-400 font-bold">ONLINE 在线</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">e-CNY ADAPTER (PBOC)</span>
                <span className="text-cyan-400 font-bold">SIMULATION 模拟</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">TREASURY DESK</span>
                <span className="text-emerald-400 font-bold">ONLINE 在线</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">RISK ENGINE</span>
                <span className="text-emerald-400 font-bold">ONLINE 在线</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">FRAUD ENGINE (SM2/SM3)</span>
                <span className="text-emerald-400 font-bold">ONLINE 在线</span>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800/80 text-[11px] font-mono text-slate-500 flex justify-between items-center">
            <span>CORE NODE: SH-FIN-01</span>
            <span className="text-slate-400">LATENCY: 12ms</span>
          </div>
        </div>

        {/* Monetary Position Panel */}
        <div className="bg-slate-900/90 border border-slate-800 rounded p-3.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="text-xs font-mono font-bold text-slate-200 tracking-wider flex items-center gap-2">
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                {lang === 'en' ? 'MONETARY POSITION' : '货币头寸与储备'}
              </span>
              <button 
                onClick={onRefresh}
                className="text-[10px] font-mono text-slate-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
                title="Refresh calculations"
              >
                <RefreshCw className="w-2.5 h-2.5" />
                CALC
              </button>
            </div>

            <div className="space-y-3 font-mono">
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'FSB-CNY LIABILITIES' : '福山存款负债 (FSB-CNY)'}</span>
                <span className="text-sm font-bold text-amber-300">
                  {Money.formatInstitutional(pos.totalCustomerDepositsCents, lang)}
                </span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'LIQUID ASSETS (HQLA)' : '合格流动性资产 (HQLA)'}</span>
                <span className="text-sm font-bold text-emerald-400">
                  {Money.formatInstitutional(pos.liquidAssetsCents, lang)}
                </span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'RESERVE COVERAGE' : '法定与流动储备覆盖率'}</span>
                <div className="text-right">
                  <span className="text-sm font-bold text-cyan-300">{pos.reserveCoverageRatio.toFixed(1)}%</span>
                  <span className="text-[10px] text-slate-500 ml-1.5">(Reg: &gt;12.5%)</span>
                </div>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'AVAILABLE LIQUIDITY' : '未质押可用清算头寸'}</span>
                <span className="text-sm font-bold text-slate-100">
                  {Money.formatInstitutional(pos.availableLiquidityCents, lang)}
                </span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'e-CNY CONVERSION BUFFER' : '数币互操作备付头寸'}</span>
                <span className="text-sm font-bold text-cyan-400">
                  {Money.formatInstitutional(pos.ecnyConversionCapacityCents, lang)}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800/80">
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div 
                className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(pos.reserveCoverageRatio * 2, 100)}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
              <span>PBOC MANDATE: 12.5%</span>
              <span className="text-emerald-400">CURRENT: {pos.reserveCoverageRatio.toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Payments Today Panel */}
        <div className="bg-slate-900/90 border border-slate-800 rounded p-3.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="text-xs font-mono font-bold text-slate-200 tracking-wider flex items-center gap-2">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                {lang === 'en' ? 'PAYMENTS TODAY' : '今日清算与交易吞吐'}
              </span>
              <span className="text-[10px] font-mono text-slate-400">T+0 REALTIME</span>
            </div>

            <div className="space-y-3 font-mono">
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'TRANSACTIONS' : '全渠道受理笔数'}</span>
                <span className="text-sm font-bold text-slate-100">
                  {(system.dailyTransactionsCount / 1000000).toFixed(1)}m 笔
                </span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'TOTAL VALUE' : '累计清算金额'}</span>
                <span className="text-sm font-bold text-emerald-300">
                  {Money.formatInstitutional(system.dailyTransactionsVolumeCents, lang)}
                </span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'SUCCESS RATE' : '报文处理成功率'}</span>
                <span className="text-sm font-bold text-emerald-400">{system.successRatePercent}%</span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'AVG LATENCY' : '平均端到端延迟'}</span>
                <span className="text-sm font-bold text-cyan-300">{system.avgLatencyMs} ms</span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-slate-400">{lang === 'en' ? 'ACTIVE MERCHANTS' : '在线特约商户'}</span>
                <span className="text-sm font-bold text-slate-300">410,000 户</span>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
            <span className="text-slate-500">POS TERMINALS: 1.28m</span>
            <span className="text-emerald-400 font-bold">99.99% UP</span>
          </div>
        </div>
      </div>

      {/* THREE-LAYER MONEY MODEL ARCHITECTURE DIAGRAM (Strict prompt #3 & #6) */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div>
            <h3 className="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              {lang === 'en' ? 'THREE-LAYER MONETARY ARCHITECTURE' : '三层货币模型与清算架构'}
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              {lang === 'en'
                ? 'Clear demarcation between Sovereign Legal Tender, Fukuyama Private Bank Liabilities, and Payment Tokens'
                : '严格隔离：央行主权法定货币、福山私人商业银行负债、支付媒介与报文凭证'}
            </p>
          </div>
          <span className="text-[11px] font-mono text-amber-400/80 border border-amber-500/30 px-2 py-0.5 rounded bg-amber-950/30">
            NON-COMMINGLED LEDGERS
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Layer A */}
          <div className="bg-slate-950/80 border border-emerald-900/60 rounded p-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-emerald-950 text-emerald-400 text-[10px] font-mono px-2 py-0.5 border-b border-l border-emerald-800 rounded-bl font-bold">
              LAYER A
            </div>
            <div className="text-xs font-mono font-bold text-emerald-400 mb-1">
              {lang === 'en' ? 'Sovereign Money' : '央行货币 (法定单位)'}
            </div>
            <div className="text-[11px] text-slate-400 font-mono mb-3">
              {lang === 'en' ? 'Legal Tender: Renminbi (CNY)' : '法定偿付基础: 人民币 (CNY)'}
            </div>

            <ul className="space-y-1.5 text-xs font-mono text-slate-300">
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'RMB Cash' : '人民币现金 (M0)'}</span>
                <span className="text-emerald-400 font-bold">{Money.formatInstitutional(res.sovereignCash, lang)}</span>
              </li>
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'e-CNY DC/EP' : '数字人民币 (e-CNY)'}</span>
                <span className="text-cyan-400 font-bold">{Money.formatInstitutional(res.ecnyClearing, lang)}</span>
              </li>
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'PBOC Reserves' : '央行准备金存款'}</span>
                <span className="text-emerald-400 font-bold">{Money.formatInstitutional(res.pbocReserves, lang)}</span>
              </li>
            </ul>

            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-slate-500">
              {lang === 'en' ? 'Issuer: People\'s Bank of China (PBOC)' : '法定发行人: 中国人民银行 (PBOC)'}
            </div>
          </div>

          {/* Layer B */}
          <div className="bg-slate-950/80 border border-amber-900/60 rounded p-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-amber-950 text-amber-400 text-[10px] font-mono px-2 py-0.5 border-b border-l border-amber-800 rounded-bl font-bold">
              LAYER B
            </div>
            <div className="text-xs font-mono font-bold text-amber-400 mb-1">
              {lang === 'en' ? 'Commercial Bank Money' : '商业银行货币 (银行存款)'}
            </div>
            <div className="text-[11px] text-slate-400 font-mono mb-3">
              {lang === 'en' ? 'Private Liability: FSB-CNY' : '私人银行负债: 福山人民币 (FSB-CNY)'}
            </div>

            <ul className="space-y-1.5 text-xs font-mono text-slate-300">
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'Retail Deposits' : '福山个人储蓄存款'}</span>
                <span className="text-amber-300 font-bold">{Money.formatInstitutional(res.retailDeposits, lang)}</span>
              </li>
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'Corporate Deposits' : '企业活期存款'}</span>
                <span className="text-amber-300 font-bold">{Money.formatInstitutional(res.corporateDeposits, lang)}</span>
              </li>
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'Merchant Balances' : '商户待结算浮存'}</span>
                <span className="text-amber-300 font-bold">{Money.formatInstitutional(res.merchantFloat, lang)}</span>
              </li>
            </ul>

            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-amber-500/90">
              {lang === 'en' ? 'Issuer: Fukuyama Specie Bank (FSB)' : '经济签发主体: 福山金银银行 (FSB)'}
            </div>
          </div>

          {/* Layer C */}
          <div className="bg-slate-950/80 border border-cyan-900/60 rounded p-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-cyan-950 text-cyan-400 text-[10px] font-mono px-2 py-0.5 border-b border-l border-cyan-800 rounded-bl font-bold">
              LAYER C
            </div>
            <div className="text-xs font-mono font-bold text-cyan-400 mb-1">
              {lang === 'en' ? 'Payment Representation' : '支付媒介与凭证 (报文形态)'}
            </div>
            <div className="text-[11px] text-slate-400 font-mono mb-3">
              {lang === 'en' ? 'Channel Tokens & Instructions' : '收单报文、二维码与硬件凭证'}
            </div>

            <ul className="space-y-1.5 text-xs font-mono text-slate-300">
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'POS Auth Tokens' : 'POS刷卡/NFC授权凭证'}</span>
                <span className="text-cyan-300 font-mono">AUTH-884xxx</span>
              </li>
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'Dynamic QR Code' : '动态聚合银联二维码'}</span>
                <span className="text-cyan-300 font-mono">EMVCo-ISO</span>
              </li>
              <li className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded">
                <span>{lang === 'en' ? 'Clearing Instructions' : '商户结算指令 (T+0/T+1)'}</span>
                <span className="text-cyan-300 font-mono">BATCH-RT</span>
              </li>
            </ul>

            <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] font-mono text-slate-500">
              {lang === 'en' ? 'Standard: ISO 20022 / PBOC SM2/3' : '标准规范: ISO 20022 / 人行国密'}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Interactive Operational Triggers */}
      <div className="bg-slate-900/80 border border-slate-800 rounded p-3">
        <div className="text-xs font-mono text-slate-400 mb-2 uppercase tracking-wider flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          {lang === 'en' ? 'FAST OPERATIONAL ACTIONS' : '快速业务控制台通道'}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() => onNavigate('POS')}
            className="p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/60 rounded text-left transition-all group"
          >
            <div className="text-amber-400 font-mono font-bold text-xs flex items-center justify-between">
              <span>POS &lt;GO&gt;</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
            <div className="text-[11px] text-slate-300 font-sans mt-0.5">
              {lang === 'en' ? 'POS Cashier Terminal' : 'POS刷卡柜台与12步验证'}
            </div>
          </button>

          <button
            onClick={() => onNavigate('ECNY')}
            className="p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/60 rounded text-left transition-all group"
          >
            <div className="text-cyan-400 font-mono font-bold text-xs flex items-center justify-between">
              <span>ECNY &lt;GO&gt;</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
            <div className="text-[11px] text-slate-300 font-sans mt-0.5">
              {lang === 'en' ? 'e-CNY Bridge Interop' : '数字人民币双向兑换网关'}
            </div>
          </button>

          <button
            onClick={() => onNavigate('RESERVE')}
            className="p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/60 rounded text-left transition-all group"
          >
            <div className="text-emerald-400 font-mono font-bold text-xs flex items-center justify-between">
              <span>ISSUE &lt;GO&gt;</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
            <div className="text-[11px] text-slate-300 font-sans mt-0.5">
              {lang === 'en' ? 'Private RMB Issuance' : '私人人民币发行与储备测试'}
            </div>
          </button>

          <button
            onClick={() => onNavigate('STRESS')}
            className="p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-red-500/60 rounded text-left transition-all group"
          >
            <div className="text-red-400 font-mono font-bold text-xs flex items-center justify-between">
              <span>STRESS &lt;GO&gt;</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
            <div className="text-[11px] text-slate-300 font-sans mt-0.5">
              {lang === 'en' ? 'Liquidity Stress Test' : '挤兑压力测试与断网模拟'}
            </div>
          </button>
        </div>
      </div>

      {/* Live Double-Entry Journal Ticker */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4 font-mono text-xs">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
          <span className="font-bold text-slate-200 flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            {lang === 'en' ? 'LIVE GENERAL LEDGER JOURNAL ENTRIES' : '核心总账复式记账实时流水 (Σ 借 = Σ 贷)'}
          </span>
          <button 
            onClick={() => onNavigate('BAL')}
            className="text-amber-400 hover:underline text-[11px]"
          >
            {lang === 'en' ? 'View Full Balance Sheet (BAL <GO>)' : '查看完整资产负债表 &gt;'}
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-slate-500 border-b border-slate-800 text-[11px]">
                <th className="pb-1.5">ENTRY ID</th>
                <th className="pb-1.5">MODULE</th>
                <th className="pb-1.5">DEBIT / CREDIT LINES</th>
                <th className="pb-1.5 text-right">TOTAL</th>
                <th className="pb-1.5 text-center">INVARIANT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {recentEntries.map((e, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-2 text-slate-400">{e.entryId}</td>
                  <td className="py-2">
                    <span className="px-1.5 py-0.5 bg-slate-800 text-cyan-300 rounded text-[10px]">
                      {e.sourceModule}
                    </span>
                  </td>
                  <td className="py-2 text-slate-300">
                    <div className="space-y-0.5">
                      {e.lines.map((l, lIdx) => (
                        <div key={lIdx} className="text-[11px] flex items-center gap-2">
                          <span className={l.debitCents > 0n ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                            {l.debitCents > 0n ? `借 (Dr) [${l.accountCode}]` : `贷 (Cr) [${l.accountCode}]`}
                          </span>
                          <span className="text-slate-400">{l.accountNameZh}</span>
                          <span className="text-slate-200">
                            {Money.format(l.debitCents > 0n ? l.debitCents : l.creditCents)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </td>
                  <td className="py-2 text-right font-bold text-slate-100">
                    {Money.format(e.totalDebitCents)}
                  </td>
                  <td className="py-2 text-center">
                    <span className="px-1.5 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                      BALANCED
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
