/**
 * Fukuyama Specie Bank (FSB-Core)
 * Corporate Banking & Programmable Payments Engine (CORP / 企业银行)
 * (Prompt #21 & #34)
 */

import React, { useState } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  Clock, 
  Lock, 
  Play, 
  ShieldCheck, 
  Layers, 
  ArrowRight,
  FileCheck,
  UserCheck
} from 'lucide-react';
import { Language, ProgrammablePaymentRule } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface CorporateBankingViewProps {
  system: BankingSystem;
  lang: Language;
  onRefresh: () => void;
}

export const CorporateBankingView: React.FC<CorporateBankingViewProps> = ({
  system,
  lang,
  onRefresh
}) => {
  const [selectedRuleId, setSelectedRuleId] = useState('RULE-PROG-2026-001');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const rules = system.progEngine.getAllRules();
  const currentRule = rules.find(r => r.ruleId === selectedRuleId) || rules[0];

  const handleApproveRole = (role: 'EMPLOYEE' | 'MANAGER' | 'TREASURER' | 'CFO', approverName: string) => {
    try {
      system.progEngine.approveStep(currentRule.ruleId, role, approverName);
      setSuccessMsg(
        lang === 'en'
          ? `Step Approved: [${role}] signature attached by ${approverName}`
          : `审批成功：[${role}] 电子私钥签名由 ${approverName} 签署完成。`
      );
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleToggleCondition = (condKey: 'deliveryConfirmed' | 'invoiceValidated') => {
    system.progEngine.toggleCondition(currentRule.ruleId, condKey);
    onRefresh();
  };

  const handleExecutePayment = () => {
    try {
      system.progEngine.executePayment(currentRule.ruleId);
      setSuccessMsg(
        lang === 'en'
          ? `Settlement Triggered! Disbursed ${Money.format(currentRule.amountCents)} to supplier account in core ledger.`
          : `条件完全达成！已自动触发执行支付，在核心总账中借记企业存款、贷记供应商账户 ${Money.format(currentRule.amountCents)}。`
      );
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'CORPORATE BANKING & PROGRAMMABLE PAYMENTS' : '企业银行与可编程支付规则引擎'}
              </h2>
              <span className="text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded border border-slate-700">
                CORP &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Controlled Institutional Banking Logic (Non-Crypto) • Multi-signature chains and conditional smart-clearing triggers'
                : '受控商业银行工作流逻辑 (非无约束加密智能合约) • 多级审批链条与条件履约清算触发器'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-500 text-[11px]">CORPORATE CLIENT DEPOSITS</span>
            <div className="text-sm font-bold text-amber-400">
              {Money.formatInstitutional(system.ledger.getAccount('2002').balanceCents, lang)}
            </div>
          </div>
        </div>

        {/* Rule Switcher */}
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {rules.map(r => (
            <button
              key={r.ruleId}
              onClick={() => {
                setSelectedRuleId(r.ruleId);
                setSuccessMsg(null);
              }}
              className={`px-3 py-1.5 rounded border text-xs whitespace-nowrap transition-colors ${
                r.ruleId === currentRule.ruleId
                  ? 'bg-amber-950/80 border-amber-500 text-amber-200 font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {r.titleZh.slice(0, 24)}... ({Money.format(r.amountCents)})
            </button>
          ))}
        </div>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            {successMsg}
          </span>
          <button onClick={() => setSuccessMsg(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Grid: Workflow Conditions & Multi-Sig Approval Chain */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Rule & Verification Conditions (6 Cols) */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm">
                {lang === 'en' ? 'PAYMENT RULE SPECIFICATION' : '可编程规则定义与触发条件'}
              </span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                currentRule.status === 'EXECUTED'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : currentRule.status === 'CONDITIONS_MET'
                  ? 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                  : 'bg-slate-800 text-slate-400'
              }`}>
                {currentRule.status}
              </span>
            </div>

            <div className="space-y-3">
              <div>
                <span className="text-slate-500 text-[10px]">INSTRUCTION TITLE:</span>
                <div className="text-sm font-bold text-slate-200 mt-0.5">{currentRule.titleZh}</div>
                <div className="text-[11px] text-slate-400">{currentRule.titleEn}</div>
              </div>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">拟清算货款金额:</span>
                  <span className="text-amber-400 font-bold text-base">{Money.format(currentRule.amountCents)}</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500">供应商收款账户:</span>
                  <span className="text-cyan-300 font-mono">{currentRule.supplierAccountId}</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500">触发器模式:</span>
                  <span className="text-slate-300">{currentRule.triggerType} (受控银行网关)</span>
                </div>
              </div>

              {/* Conditions Toggle List */}
              <div className="pt-2">
                <div className="text-xs font-bold text-slate-300 mb-2">
                  {lang === 'en' ? 'Prerequisite Conditions:' : '前置生效要件 (点击模拟外部数据回调):'}
                </div>
                <div className="space-y-2">
                  <div 
                    onClick={() => handleToggleCondition('deliveryConfirmed')}
                    className="p-2.5 bg-slate-950 border border-slate-800 rounded flex items-center justify-between cursor-pointer hover:border-slate-700 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className={`w-4 h-4 ${
                        currentRule.conditions.deliveryConfirmed ? 'text-emerald-400' : 'text-slate-600'
                      }`} />
                      <div>
                        <div className="font-bold text-slate-200">仓储物流货物验收 (DELIVERY_CONFIRMED)</div>
                        <div className="text-[10px] text-slate-500">ERP 仓库 WMS 入库扫码确认</div>
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      currentRule.conditions.deliveryConfirmed ? 'bg-emerald-950 text-emerald-300' : 'bg-slate-800 text-slate-500'
                    }`}>
                      {currentRule.conditions.deliveryConfirmed ? 'TRUE (已满足)' : 'FALSE (未达成)'}
                    </span>
                  </div>

                  <div 
                    onClick={() => handleToggleCondition('invoiceValidated')}
                    className="p-2.5 bg-slate-950 border border-slate-800 rounded flex items-center justify-between cursor-pointer hover:border-slate-700 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className={`w-4 h-4 ${
                        currentRule.conditions.invoiceValidated ? 'text-emerald-400' : 'text-slate-600'
                      }`} />
                      <div>
                        <div className="font-bold text-slate-200">增值税专用发票核验 (INVOICE_VALIDATED)</div>
                        <div className="text-[10px] text-slate-500">全国增值税发票查验平台 API 验真通过</div>
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      currentRule.conditions.invoiceValidated ? 'bg-emerald-950 text-emerald-300' : 'bg-slate-800 text-slate-500'
                    }`}>
                      {currentRule.conditions.invoiceValidated ? 'TRUE (已满足)' : 'FALSE (未达成)'}
                    </span>
                  </div>

                  <div className="p-2.5 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className={`w-4 h-4 ${
                        currentRule.conditions.cfoApproved ? 'text-emerald-400' : 'text-slate-600'
                      }`} />
                      <div>
                        <div className="font-bold text-slate-200">首席财务官终审授权 (APPROVED_BY = CFO)</div>
                        <div className="text-[10px] text-slate-500">右侧审批流 CFO 级国密私钥签署</div>
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      currentRule.conditions.cfoApproved ? 'bg-emerald-950 text-emerald-300' : 'bg-slate-800 text-slate-500'
                    }`}>
                      {currentRule.conditions.cfoApproved ? 'TRUE (已核准)' : 'FALSE (待签署)'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800">
            <button
              onClick={handleExecutePayment}
              disabled={currentRule.status !== 'CONDITIONS_MET'}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" />
              <span>
                {currentRule.status === 'EXECUTED'
                  ? 'PROGRAMMABLE PAYMENT ALREADY EXECUTED (已结算)'
                  : currentRule.status === 'CONDITIONS_MET'
                  ? 'CONDITIONS MET: EXECUTE SETTLEMENT IN CORE LEDGER'
                  : 'AWAITING PREREQUISITES / APPROVALS (要件尚未齐备)'}
              </span>
            </button>
          </div>
        </div>

        {/* Right: Multi-Tier Approval Chain (Prompt #34 Employee -> Manager -> Treasurer -> CFO) */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-amber-400 text-sm flex items-center gap-2">
                <UserCheck className="w-4 h-4" />
                {lang === 'en' ? 'MULTI-SIGNATURE APPROVAL CHAIN' : '企业多级授权审批链 (Employee ➔ Mgr ➔ Treasurer ➔ CFO)'}
              </span>
              <span className="text-[10px] text-slate-500">4-TIER GOVERNANCE</span>
            </div>

            <div className="space-y-3">
              {currentRule.approvalChain.map((step, idx) => (
                <div
                  key={step.role}
                  className={`p-3 rounded border transition-colors ${
                    step.approved
                      ? 'bg-slate-950 border-emerald-900/80 text-slate-200'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center font-bold text-[10px] text-amber-400">
                        {idx + 1}
                      </span>
                      <span className="font-bold text-xs text-slate-200">
                        {step.role === 'EMPLOYEE' && '1. 采购专员发起 (Employee)'}
                        {step.role === 'MANAGER' && '2. 业务部门总监复核 (Manager)'}
                        {step.role === 'TREASURER' && '3. 资金部司库审核 (Treasurer)'}
                        {step.role === 'CFO' && '4. 首席财务官终审 (CFO Dual-Auth)'}
                      </span>
                    </div>

                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      step.approved ? 'bg-emerald-950 text-emerald-300' : 'bg-slate-800 text-slate-500'
                    }`}>
                      {step.approved ? 'APPROVED 已签署' : 'PENDING 待审'}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-400 mt-2 flex justify-between items-center">
                    <div>
                      <span>签署人: </span>
                      <span className="text-slate-200 font-bold">{step.approvedBy}</span>
                    </div>
                    {step.approvedAt && (
                      <span className="text-[10px] text-slate-500">
                        {new Date(step.approvedAt).toLocaleTimeString()}
                      </span>
                    )}
                  </div>

                  {!step.approved && (
                    <div className="mt-2 pt-2 border-t border-slate-800 flex justify-end">
                      <button
                        onClick={() => handleApproveRole(step.role, '赵建国 (首席财务官 CFO)')}
                        className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-[11px] transition-colors"
                      >
                        {lang === 'en' ? `Sign as ${step.role}` : `以 ${step.role} 身份电子盖章核准`}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 p-2.5 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-500">
            {lang === 'en'
              ? 'Security standard: Multi-sig transactions require HSM-backed key authorization with hardware device binding.'
              : '安全规范：大额可编程支付遵循人民银行数字证书与金融硬密码机双人复核标准。'}
          </div>
        </div>
      </div>
    </div>
  );
};
