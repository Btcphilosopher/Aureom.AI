/**
 * Fukuyama Specie Bank (FSB-Core)
 * Open Banking API Gateway & ISO 20022 Message Sandbox (API <GO>)
 * (Prompt #35)
 */

import React, { useState } from 'react';
import { 
  Layers, 
  Send, 
  CheckCircle2, 
  Code, 
  Lock, 
  Copy, 
  Terminal,
  ShieldCheck,
  FileCode
} from 'lucide-react';
import { Language } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface APIGatewayViewProps {
  system: BankingSystem;
  lang: Language;
}

export const APIGatewayView: React.FC<APIGatewayViewProps> = ({ system, lang }) => {
  const [selectedEndpoint, setSelectedEndpoint] = useState('POST /payments');
  const [formatMode, setFormatMode] = useState<'REST_JSON' | 'ISO_20022'>('REST_JSON');
  const [responsePayload, setResponsePayload] = useState<string | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);

  const endpoints = [
    { method: 'POST', path: '/payments', desc: '提交收单支付清算指令', isoDoc: 'pacs.008.001.09 (Customer Credit Transfer)' },
    { method: 'GET', path: '/payments/{id}', desc: '查询特定支付交易授权状态', isoDoc: 'pacs.002.001.10 (Payment Status Report)' },
    { method: 'POST', path: '/payments/{id}/authorise', desc: '执行POS二次结算授权冲正', isoDoc: 'camt.056.001.08 (Payment Cancellation)' },
    { method: 'GET', path: '/balances/{id}', desc: '核心存款账户头寸与可用余额核验', isoDoc: 'camt.053.001.08 (Bank to Customer Statement)' },
    { method: 'POST', path: '/settlements', desc: '触发特约商户批量清分划拨', isoDoc: 'pacs.009.001.08 (Financial Institution Transfer)' }
  ];

  const getSampleRequest = () => {
    if (formatMode === 'ISO_20022') {
      return `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.09">
  <FIToFICstmrCdtTrf>
    <GrpHdr>
      <MsgId>FSB-MSG-20261012-09941</MsgId>
      <CreDtTm>2026-10-12T17:45:00Z</CreDtTm>
      <NbOfTxs>1</NbOfTxs>
      <SttlmInf>
        <SttlmMtd>CLRG</SttlmMtd>
        <ClrSys>
          <Prtry>PBOC_DCEP_INTEROP</Prtry>
        </ClrSys>
      </SttlmInf>
    </GrpHdr>
    <CdtTrfTxInf>
      <PmtId>
        <EndToEndId>ORDER-8829-9901</EndToEndId>
        <TxId>TX-FSB-77281</TxId>
      </PmtId>
      <IntrBkSttlmAmt Ccy="CNY">128.00</IntrBkSttlmAmt>
      <Dbtr>
        <Nm>Chen Liqun (陈立群)</Nm>
        <Id><OrgId><Othr><Id>310104198809224192</Id></Othr></OrgId></Id>
      </Dbtr>
      <DbtrAgt>
        <FinInstnId><BICFI>FSBCCNBJ</BICFI></FinInstnId>
      </DbtrAgt>
      <Cdtr>
        <Nm>Fukuyama Convenience Stores</Nm>
      </Cdtr>
    </CdtTrfTxInf>
  </FIToFICstmrCdtTrf>
</Document>`;
    }

    return JSON.stringify({
      header: {
        idempotencyKey: `IDEM-${Date.now()}`,
        clientCertThumbprint: "SM2-9A8B7C6D5E4F3210",
        timestamp: new Date().toISOString(),
        version: "v4.8"
      },
      payload: {
        merchantId: "MERCH-001",
        terminalId: "FSB-TERM-0018",
        amountCents: 12800,
        currency: "CNY",
        payerAccount: "6222 0888 1029 4401",
        instrument: "FSB_ACCOUNT",
        digitalSignatureSM2: "SM2_SIG_7F89E002B41C9D"
      }
    }, null, 2);
  };

  const handleTestAPI = () => {
    setIsExecuting(true);
    setTimeout(() => {
      const resp = {
        status: 200,
        statusCode: "OK",
        header: {
          server: "FSB-Core-Gateway/4.8",
          pbocNodeRelay: "PBOC-DCEP-EDGE-SH02",
          latencyMs: 14,
          signatureVerified: true
        },
        body: {
          traceNumber: `FSB-API-${Date.now()}`,
          authCode: `AUTH-${Math.floor(100000 + Math.random() * 900000)}`,
          status: "SETTLED",
          amount: "¥128.00",
          currency: "CNY",
          settlementLayer: "FSB_INTERNAL_LEDGER",
          ledgerRef: `JE-${Date.now()}`,
          timestamp: new Date().toISOString()
        }
      };
      setResponsePayload(JSON.stringify(resp, null, 2));
      setIsExecuting(false);
    }, 250);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Code className="w-5 h-5 text-cyan-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'OPEN BANKING API GATEWAY & ISO 20022 SANDBOX' : '开放银行接口网关与 ISO 20022 报文沙箱'}
              </h2>
              <span className="text-xs bg-slate-800 text-cyan-300 px-2 py-0.5 rounded border border-slate-700">
                API &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Standardized REST JSON & ISO 20022 pacs/camt message interfaces • mTLS, SM2/SM3 signature, idempotency'
                : '金融级 RESTful JSON 与国际 ISO 20022 pacs/camt 标准报文 • 双向 mTLS 认证、国密签名与防重放幂等键'}
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => { setFormatMode('REST_JSON'); setResponsePayload(null); }}
              className={`px-3 py-1.5 rounded font-bold transition-colors ${
                formatMode === 'REST_JSON'
                  ? 'bg-cyan-950 border border-cyan-500 text-cyan-200'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              RESTful JSON (OpenAPI)
            </button>
            <button
              onClick={() => { setFormatMode('ISO_20022'); setResponsePayload(null); }}
              className={`px-3 py-1.5 rounded font-bold transition-colors ${
                formatMode === 'ISO_20022'
                  ? 'bg-amber-950 border border-amber-500 text-amber-200'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              ISO 20022 XML (pacs.008)
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Endpoint Selector & Request/Response Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Endpoint List (4 Cols) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded p-4 space-y-2">
          <div className="text-xs font-bold text-slate-200 mb-2">AVAILABLE ENDPOINTS:</div>
          {endpoints.map(ep => {
            const key = `${ep.method} ${ep.path}`;
            const isSelected = selectedEndpoint === key;
            return (
              <div
                key={key}
                onClick={() => { setSelectedEndpoint(key); setResponsePayload(null); }}
                className={`p-2.5 rounded border cursor-pointer transition-colors ${
                  isSelected
                    ? 'bg-cyan-950/80 border-cyan-500 text-slate-100'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-xs">
                  <span className={ep.method === 'POST' ? 'text-emerald-400' : 'text-cyan-400'}>
                    {ep.method}
                  </span>
                  <span>{ep.path}</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-1">{ep.desc}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">{ep.isoDoc}</div>
              </div>
            );
          })}
        </div>

        {/* Right: Request & Response Inspector (8 Cols) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Request Payload */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
              <span className="font-bold text-slate-200 text-xs flex items-center gap-2">
                <FileCode className="w-4 h-4 text-amber-400" />
                REQUEST PAYLOAD ({selectedEndpoint})
              </span>
              <button
                onClick={handleTestAPI}
                disabled={isExecuting}
                className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-bold rounded text-xs transition-colors flex items-center gap-1.5"
              >
                <Send className="w-3 h-3" />
                <span>{isExecuting ? 'DISPATCHING...' : 'DISPATCH REQUEST'}</span>
              </button>
            </div>
            <pre className="bg-black p-3 rounded border border-slate-800 text-slate-300 overflow-x-auto text-[11px] leading-relaxed max-h-56">
              {getSampleRequest()}
            </pre>
          </div>

          {/* Response Payload */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
              <span className="font-bold text-slate-200 text-xs flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                GATEWAY RESPONSE OUTPUT
              </span>
              <span className="text-[10px] text-slate-500">HTTP/2 TLS 1.3 mTLS</span>
            </div>
            <pre className="bg-black p-3 rounded border border-slate-800 text-emerald-300 overflow-x-auto text-[11px] leading-relaxed max-h-60">
              {responsePayload || '// Click "DISPATCH REQUEST" above to test API gateway call against running FSB-Core engine.'}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
