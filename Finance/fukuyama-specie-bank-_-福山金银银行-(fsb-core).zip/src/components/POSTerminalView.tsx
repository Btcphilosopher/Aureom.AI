/**
 * Fukuyama Specie Bank (FSB-Core)
 * Dedicated POS Terminal Counter & Institutional 12-Step Validator
 * (Prompt #8, #9, #32)
 */

import React, { useState } from 'react';
import { 
  CreditCard, 
  Smartphone, 
  QrCode, 
  Wifi, 
  CheckCircle2, 
  AlertTriangle, 
  Printer, 
  ShieldCheck,
  RefreshCw,
  Coins,
  Store,
  Layers,
  ArrowRight
} from 'lucide-react';
import { Language, PaymentMethod, PaymentInstruction } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface POSTerminalViewProps {
  system: BankingSystem;
  lang: Language;
  onRefresh: () => void;
}

export const POSTerminalView: React.FC<POSTerminalViewProps> = ({
  system,
  lang,
  onRefresh
}) => {
  const [selectedMerchantId, setSelectedMerchantId] = useState('MERCH-001');
  const [selectedAccountId, setSelectedAccountId] = useState('ACC-6222-001');
  const [amountInput, setAmountInput] = useState('128.00'); // ¥128.00 default matching prompt #32
  const [instrument, setInstrument] = useState<PaymentMethod>('FSB_ACCOUNT');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeInstruction, setActiveInstruction] = useState<PaymentInstruction | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const merchants = system.getMerchants();
  const accounts = system.getAccounts();
  const selectedMerchant = merchants.find(m => m.merchantId === selectedMerchantId) || merchants[0];
  const selectedAccount = accounts.find(a => a.accountId === selectedAccountId) || accounts[0];
  const terminal = selectedMerchant.terminals[0];
  const history = system.posValidator.getHistory();

  const handleExecutePayment = async () => {
    setIsProcessing(true);
    setErrorMsg(null);
    try {
      const amountCents = Money.parse(amountInput);
      if (amountCents <= 0n) {
        throw new Error('Please enter a valid amount');
      }

      const nonce = `NONCE-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const signature = `SM2-SIG-${Math.random().toString(36).substring(2, 12).toUpperCase()}`;

      const cust = system.getCustomer(selectedAccount.customerId);

      const instruction = await system.posValidator.validateAndProcess(
        {
          merchantId: selectedMerchant.merchantId,
          terminalId: terminal.terminalId,
          payerAccountId: selectedAccount.accountId,
          payerNameZh: cust?.nameZh || '陈立群',
          payerNameEn: cust?.nameEn || 'Chen Liqun',
          amountCents,
          instrument,
          nonce,
          signature,
          customerReference: `ORDER-${Date.now().toString().slice(-6)}`
        },
        selectedMerchant,
        selectedAccount
      );

      setActiveInstruction(instruction);
      onRefresh();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const getMethodIcon = (m: PaymentMethod) => {
    switch (m) {
      case 'FSB_ACCOUNT': return <CreditCard className="w-4 h-4" />;
      case 'ECNY': return <Coins className="w-4 h-4 text-cyan-400" />;
      case 'BANK_CARD': return <CreditCard className="w-4 h-4" />;
      case 'QR_CODE': return <QrCode className="w-4 h-4" />;
      case 'NFC': return <Wifi className="w-4 h-4" />;
      case 'API': return <Layers className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* View Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Store className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'POS TERMINAL & 12-STEP VALIDATOR' : 'POS收单终端与12步制度性验证器'}
              </h2>
              <span className="text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded border border-slate-700">
                POS &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Full transaction authorization lifecycle • SM2/SM3 signature, fraud scoring, and double-entry settlement'
                : '全流程交易授权生命周期 • 国密SM2/SM3数字验签、反欺诈流速监测、实时复式记账清算'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-500 text-[11px]">ACTIVE TERMINALS</span>
            <div className="text-sm font-bold text-emerald-400">1,280,000 ONLINE</div>
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 bg-red-950/80 border border-red-800 text-red-300 rounded flex items-center justify-between">
          <span>{errorMsg}</span>
          <button onClick={() => setErrorMsg(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Main Grid: POS Counter Hardware (Left) & 12-Step Validator Stepper (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (5 Cols): The Physical POS Terminal Frame */}
        <div className="lg:col-span-5 bg-slate-950 border-2 border-slate-800 rounded-xl p-4 shadow-2xl flex flex-col justify-between">
          <div>
            {/* Terminal Top Hardware Bezel */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-400">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="font-bold text-slate-200">PAX A920 Pro (SM2)</span>
              </div>
              <div className="text-[10px] text-slate-500">
                TERM ID: {terminal.terminalId}
              </div>
            </div>

            {/* Merchant & Account Selectors */}
            <div className="my-3 space-y-2">
              <div>
                <label className="text-[10px] text-slate-500 uppercase block mb-1">
                  {lang === 'en' ? 'Acquiring Merchant' : '收单商户与机具'}
                </label>
                <select
                  value={selectedMerchantId}
                  onChange={e => setSelectedMerchantId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                >
                  {merchants.map(m => (
                    <option key={m.merchantId} value={m.merchantId}>
                      {m.businessNameZh} ({m.feeRateBps} bps)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-500 uppercase block mb-1">
                  {lang === 'en' ? 'Payer Customer & Account' : '付款客户与账户 (借记方)'}
                </label>
                <select
                  value={selectedAccountId}
                  onChange={e => setSelectedAccountId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                >
                  {accounts.map(a => {
                    const c = system.getCustomer(a.customerId);
                    return (
                      <option key={a.accountId} value={a.accountId}>
                        {c?.nameZh} - {a.accountNumber} ({Money.format(a.availableBalanceCents)})
                      </option>
                    );
                  })}
                </select>
              </div>
            </div>

            {/* Terminal Screen (Prompt #32 styling) */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 my-3 text-center shadow-inner">
              <div className="text-xs font-mono text-slate-400 tracking-wider">
                福山金银银行
              </div>
              <div className="text-[10px] font-mono text-slate-500">
                FUKUYAMA SPECIE BANK
              </div>

              {/* Amount Display */}
              <div className="my-3 py-2 bg-black border border-slate-800 rounded">
                <span className="text-2xl font-bold font-mono text-amber-300">
                  ¥{amountInput || '0.00'}
                </span>
              </div>

              {/* Amount quick picker */}
              <div className="flex gap-1.5 justify-center mb-3">
                {['128.00', '58.00', '680.00', '4800.00'].map(amt => (
                  <button
                    key={amt}
                    onClick={() => setAmountInput(amt)}
                    className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px]"
                  >
                    ¥{amt}
                  </button>
                ))}
              </div>

              {/* Payment Method Selector (Prompt #32) */}
              <div className="text-left mb-2">
                <span className="text-[10px] text-slate-400">选择支付方式 / Select Payment Method:</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                <button
                  type="button"
                  onClick={() => setInstrument('ECNY')}
                  className={`p-2 rounded border flex flex-col items-center gap-1 transition-colors ${
                    instrument === 'ECNY'
                      ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Coins className="w-4 h-4 text-cyan-400" />
                  <span>数字人民币</span>
                </button>

                <button
                  type="button"
                  onClick={() => setInstrument('FSB_ACCOUNT')}
                  className={`p-2 rounded border flex flex-col items-center gap-1 transition-colors ${
                    instrument === 'FSB_ACCOUNT'
                      ? 'bg-amber-950/80 border-amber-500 text-amber-200 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-amber-400" />
                  <span>银行账户</span>
                </button>

                <button
                  type="button"
                  onClick={() => setInstrument('BANK_CARD')}
                  className={`p-2 rounded border flex flex-col items-center gap-1 transition-colors ${
                    instrument === 'BANK_CARD'
                      ? 'bg-amber-950/80 border-amber-500 text-amber-200 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-slate-400" />
                  <span>银联借记卡</span>
                </button>

                <button
                  type="button"
                  onClick={() => setInstrument('QR_CODE')}
                  className={`p-2 rounded border flex flex-col items-center gap-1 transition-colors ${
                    instrument === 'QR_CODE'
                      ? 'bg-amber-950/80 border-amber-500 text-amber-200 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-slate-400" />
                  <span>二维码支付</span>
                </button>

                <button
                  type="button"
                  onClick={() => setInstrument('NFC')}
                  className={`p-2 rounded border flex flex-col items-center gap-1 transition-colors ${
                    instrument === 'NFC'
                      ? 'bg-amber-950/80 border-amber-500 text-amber-200 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Wifi className="w-4 h-4 text-slate-400" />
                  <span>NFC 触碰</span>
                </button>

                <button
                  type="button"
                  onClick={() => setInstrument('API')}
                  className={`p-2 rounded border flex flex-col items-center gap-1 transition-colors ${
                    instrument === 'API'
                      ? 'bg-amber-950/80 border-amber-500 text-amber-200 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Layers className="w-4 h-4 text-slate-400" />
                  <span>商户API</span>
                </button>
              </div>
            </div>
          </div>

          {/* Action Trigger Button */}
          <div className="mt-2">
            <button
              onClick={handleExecutePayment}
              disabled={isProcessing}
              className="w-full py-3 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-bold rounded-lg text-sm transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>VALIDATING 12 STEPS...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {lang === 'en' ? 'CONFIRM & AUTHORISE PAYMENT' : '确认支付并提交12步授权'}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column (7 Cols): 12-Step Validator Pipeline & Thermal Receipt */}
        <div className="lg:col-span-7 space-y-4">
          {/* Validator Stepper */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                {lang === 'en' ? 'INSTITUTIONAL 12-STEP VALIDATION PIPELINE' : '金融机构级12步合规与风控验证流程'}
              </span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                activeInstruction?.status === 'SETTLED'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-slate-800 text-slate-400'
              }`}>
                {activeInstruction ? `${activeInstruction.status} (已结算)` : 'IDLE 待命'}
              </span>
            </div>

            {/* Stepper lines */}
            <div className="space-y-1.5">
              {(activeInstruction?.validationSteps || [
                { step: 'AUTH_SIGNATURE', labelZh: '1. 数字签名与终端硬件验证', labelEn: '1. Authenticate payment signature', passed: true, detailZh: '国密SM2/SM3硬件签名有效' },
                { step: 'VERIFY_MERCHANT', labelZh: '2. 特约商户资质与终端在线核验', labelEn: '2. Verify merchant and terminal', passed: true, detailZh: '商户处于GRADE_A准入，终端在网' },
                { step: 'VERIFY_CURRENCY', labelZh: '3. 交易币种法定人民币核验 (CNY)', labelEn: '3. Verify currency (CNY legal tender)', passed: true, detailZh: '严格CNY计价核验' },
                { step: 'VERIFY_ACCOUNT', labelZh: '4. 付款方银行账户状态核验', labelEn: '4. Verify account active status', passed: true, detailZh: '借记账户无止付/冻结' },
                { step: 'VERIFY_BALANCE', labelZh: '5. 未质押可用头寸与活期余额核验', labelEn: '5. Verify available balance', passed: true, detailZh: '可用余额充足' },
                { step: 'CHECK_LIMITS', labelZh: '6. 单笔与单日累计限额核验', labelEn: '6. Check velocity limits', passed: true, detailZh: '未超单笔50万限额' },
                { step: 'FRAUD_RISK_CHECK', labelZh: '7. 反欺诈模型实时评分与流速监测', labelEn: '7. Check fraud risk score', passed: true, detailZh: '风险评分 12/100 (低风险)' },
                { step: 'IDEMPOTENCY_CHECK', labelZh: '8. 防重放随机数与幂等性校验', labelEn: '8. Check duplicate transaction', passed: true, detailZh: '唯一随机数校验通过' },
                { step: 'RESERVE_FUNDS', labelZh: '9. 付款方账户资金预冻结 (Hold)', labelEn: '9. Reserve customer funds', passed: true, detailZh: '建立授权冻结凭据' },
                { step: 'AUTHORISE_TX', labelZh: '10. 核发银行授权码与数字凭据', labelEn: '10. Authorise transaction', passed: true, detailZh: '核发 AUTH-xxxxxx 凭据' },
                { step: 'EXECUTE_SETTLEMENT', labelZh: '11. 核心总账复式记账入账 (借/贷)', labelEn: '11. Settle in core ledger', passed: true, detailZh: '借: 客户存款 | 贷: 商户应付款' },
                { step: 'AUDIT_RECONCILE', labelZh: '12. 建立不可篡改审计与日终对账锚点', labelEn: '12. Reconcile & audit trace', passed: true, detailZh: '纳入日终清分对账池' }
              ]).map((st: any, idx: number) => (
                <div
                  key={idx}
                  className={`p-2 rounded border flex items-center justify-between text-xs transition-colors ${
                    activeInstruction
                      ? st.passed
                        ? 'bg-slate-950 border-emerald-900/60 text-slate-200'
                        : 'bg-red-950/40 border-red-900 text-red-200'
                      : 'bg-slate-950/40 border-slate-800/40 text-slate-500'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className={`w-3.5 h-3.5 ${
                      activeInstruction ? (st.passed ? 'text-emerald-400' : 'text-red-400') : 'text-slate-600'
                    }`} />
                    <span className="font-bold text-slate-300">
                      {lang === 'en' ? st.labelEn || st.labelZh : st.labelZh}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    {lang === 'en' ? st.detailEn || st.detailZh : st.detailZh}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Thermal Receipt Simulator (Prompt #32 Exact Output) */}
          {activeInstruction && (
            <div className="bg-slate-950 border border-slate-700 rounded p-4 font-mono shadow-2xl relative">
              <div className="flex items-center justify-between pb-2 border-b border-dashed border-slate-700 mb-3">
                <span className="flex items-center gap-1.5 font-bold text-amber-400">
                  <Printer className="w-3.5 h-3.5" />
                  {lang === 'en' ? 'TRANSACTION RECEIPT' : 'POS 签购单 (机打凭据)'}
                </span>
                <span className="text-[10px] text-slate-500">MERCHANT COPY</span>
              </div>

              <div className="space-y-1 text-slate-300 text-xs">
                <div className="text-center font-bold text-slate-100 text-sm">
                  福山银行 / FUKUYAMA SPECIE BANK
                </div>
                <div className="text-center text-emerald-400 font-bold text-sm my-1">
                  支付成功 / PAYMENT SUCCESSFUL
                </div>
                <div className="text-center text-xl font-bold text-amber-300 my-2">
                  ¥{Money.format(activeInstruction.amountCents, false)}
                </div>

                <div className="pt-2 border-t border-dashed border-slate-800 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">商户名称 / MERCHANT:</span>
                    <span className="font-bold text-slate-200">{activeInstruction.payeeMerchantNameZh}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">交易流水 / TRANSACTION:</span>
                    <span className="text-cyan-300">{activeInstruction.traceNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">授权代码 / AUTH CODE:</span>
                    <span className="text-amber-300">{activeInstruction.authCode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">清算方式 / SETTLEMENT:</span>
                    <span className="text-emerald-400 font-bold">即时 / INSTANT (T+0)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">手续费 / ACQUIRING FEE:</span>
                    <span>{Money.format(activeInstruction.feeCents)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">商户净入账 / NET CREDIT:</span>
                    <span className="text-emerald-300 font-bold">{Money.format(activeInstruction.merchantNetCents)}</span>
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-dashed border-slate-700 text-center text-[10px] text-slate-500">
                持卡人存根 • 感谢使用福山金银银行收单服务
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
