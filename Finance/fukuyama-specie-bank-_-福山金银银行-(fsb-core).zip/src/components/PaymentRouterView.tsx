/**
 * Fukuyama Specie Bank (FSB-Core)
 * Payment Routing Engine & Monetary Network Graph
 * (Prompt #10, #19, #20)
 */

import React, { useState } from 'react';
import { 
  Network, 
  GitFork, 
  CheckCircle2, 
  Zap, 
  Layers, 
  ArrowRight, 
  Coins, 
  CreditCard,
  Building2,
  Clock,
  ShieldAlert,
  Sliders
} from 'lucide-react';
import { Language, PaymentMethod } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';
import { RouteEvaluation } from '../core/paymentRouter';

interface PaymentRouterViewProps {
  system: BankingSystem;
  lang: Language;
}

export const PaymentRouterView: React.FC<PaymentRouterViewProps> = ({ system, lang }) => {
  const [amountInput, setAmountInput] = useState('250000.00'); // ¥250,000
  const [instrument, setInstrument] = useState<PaymentMethod>('FSB_ACCOUNT');
  const [isPayerFSB, setIsPayerFSB] = useState(true);
  const [isPayeeFSB, setIsPayeeFSB] = useState(true);
  const [selectedNode, setSelectedNode] = useState<string>('TREASURY');

  const amountCents = Money.parse(amountInput);
  const routes = system.paymentRouter.evaluateRoutes(
    amountCents,
    instrument,
    isPayerFSB,
    isPayeeFSB
  );

  const res = system.ledger.getReserveMetrics();

  // Topology node details for inspector
  const nodeDetails: Record<string, any> = {
    PBOC: {
      titleZh: '中国人民银行 / 人民币主权清算总中心',
      titleEn: 'PBOC / Sovereign RMB Settlement Infrastructure',
      type: 'SOVEREIGN_ROOT',
      balance: '¥128.6bn (FSB Reserve Dep)',
      status: 'ONLINE 正常',
      roleZh: '法定货币总发行人与大额实时支付清算系统 (HVPS/BEPS)',
      roleEn: 'Monetary sovereign issuer & core interbank clearing rail'
    },
    SETTLEMENT: {
      titleZh: '人民币清算与跨行中继层 (CNAPS / e-CNY Core)',
      titleEn: 'RMB Clearing & Interbank Relay Layer',
      type: 'CLEARING_RELAY',
      balance: '¥42.0bn (e-CNY Clearing)',
      status: 'ONLINE 正常',
      roleZh: '数字人民币母网与全国跨行大额资金清算网关',
      roleEn: 'DC/EP core backbone & national payment switch'
    },
    TREASURY: {
      titleZh: '福山金银银行资金运营部 (FSB Treasury Desk)',
      titleEn: 'Fukuyama Specie Bank Treasury Operations',
      type: 'COMMERCIAL_TREASURY',
      balance: Money.formatInstitutional(res.totalHQLA, lang),
      status: 'ACTIVE 营运中',
      roleZh: '负责合格储备资产、国债质押回购、日间流动性头寸管理',
      roleEn: 'Responsible for HQLA reserves, repo collateral, and intraday liquidity'
    },
    RETAIL: {
      titleZh: '个人与零售客户业务条线 (Retail Customers)',
      titleEn: 'Retail & Consumer Banking Division',
      type: 'DEPOSIT_LIABILITY',
      balance: Money.formatInstitutional(res.retailDeposits, lang),
      status: 'ACTIVE 活跃',
      roleZh: '240万个人活期存款账户，高频扫码与POS小额消费',
      roleEn: '2.4M demand deposit accounts, high-frequency QR and POS micro-transactions'
    },
    CORPORATE: {
      titleZh: '企业大客户与供应链结算 (Corporate Banking)',
      titleEn: 'Corporate & Institutional Supply Chain Division',
      type: 'DEPOSIT_LIABILITY',
      balance: Money.formatInstitutional(res.corporateDeposits, lang),
      status: 'ACTIVE 活跃',
      roleZh: '8.4万企业账户，司库资金池、可编程多方批量结算',
      roleEn: '84k corporate accounts, corporate cash pooling and programmable workflows'
    },
    MERCHANT: {
      titleZh: '特约商户与收单网络 (Acquiring Network)',
      titleEn: 'Merchant Acquiring & POS Terminal Fleet',
      type: 'ACQUIRING_NETWORK',
      balance: Money.formatInstitutional(res.merchantFloat, lang),
      status: 'ACTIVE 活跃',
      roleZh: '41万注册商户，128万台POS机具，实时T+0/T+1清分',
      roleEn: '410k merchants, 1.28M POS terminals, intraday T+0/T+1 clearing'
    }
  };

  const activeNodeInfo = nodeDetails[selectedNode] || nodeDetails.TREASURY;

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <GitFork className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'PAYMENT ROUTING OPTIMIZER & NETWORK TOPOLOGY' : '支付路由优化引擎与货币流动网络拓扑'}
              </h2>
              <span className="text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded border border-slate-700">
                PAY / MONEYGRAPH &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Dynamic multi-rail routing • Latency, cost, liquidity efficiency, and counterparty exposure optimizer'
                : '动态多通道智能路由决策 • 综合评估清算成本 (bps)、时延 (ms)、流动性占用与结算终局性'}
            </p>
          </div>
        </div>
      </div>

      {/* Grid: Routing Simulator (Left) vs Interactive Money Flow Graph (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Routing Evaluator (5 Cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-amber-400 text-sm flex items-center gap-2">
                <Zap className="w-4 h-4" />
                {lang === 'en' ? 'ROUTING SIMULATOR' : '通道寻径与成本测算'}
              </span>
              <span className="text-[10px] text-slate-500">REAL-TIME ENGINE</span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  {lang === 'en' ? 'Transaction Amount (RMB ¥):' : '拟清算交易金额 (人民币元):'}
                </label>
                <input
                  type="text"
                  value={amountInput}
                  onChange={e => setAmountInput(e.target.value)}
                  className="w-full bg-black border border-slate-700 rounded px-2.5 py-1.5 text-xs text-amber-300 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  {lang === 'en' ? 'Payment Instrument:' : '支付工具 / 结算介质:'}
                </label>
                <div className="grid grid-cols-3 gap-1 text-[11px]">
                  {(['FSB_ACCOUNT', 'ECNY', 'BANK_CARD', 'QR_CODE', 'NFC'] as PaymentMethod[]).map(m => (
                    <button
                      key={m}
                      onClick={() => setInstrument(m)}
                      className={`p-1.5 rounded border text-center transition-colors ${
                        instrument === m
                          ? 'bg-amber-950 border-amber-500 text-amber-200 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2 bg-slate-950 rounded border border-slate-800">
                  <label className="text-[10px] text-slate-500 block mb-1">付款方归属</label>
                  <button
                    onClick={() => setIsPayerFSB(!isPayerFSB)}
                    className={`w-full py-1 rounded text-[11px] font-bold border ${
                      isPayerFSB ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {isPayerFSB ? '福山行内账户 (FSB)' : '外部商业银行'}
                  </button>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800">
                  <label className="text-[10px] text-slate-500 block mb-1">收款方归属</label>
                  <button
                    onClick={() => setIsPayeeFSB(!isPayeeFSB)}
                    className={`w-full py-1 rounded text-[11px] font-bold border ${
                      isPayeeFSB ? '福山特约商户 (FSB)' : '外部商户/账户'
                    }`}
                  >
                    {isPayeeFSB ? '福山特约商户 (FSB)' : '外部商户/账户'}
                  </button>
                </div>
              </div>

              {/* Three-Rail Comparison Cards */}
              <div className="space-y-2 mt-2">
                {routes.map(r => (
                  <div
                    key={r.route}
                    className={`p-2.5 rounded border transition-colors ${
                      r.recommended
                        ? 'bg-amber-950/40 border-amber-500/80'
                        : 'bg-slate-950 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-bold text-slate-200">
                        {r.recommended && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />}
                        <span>{lang === 'en' ? r.nameEn : r.nameZh}</span>
                      </div>
                      {r.recommended && (
                        <span className="px-1.5 py-0.2 bg-amber-500 text-slate-950 font-bold rounded text-[10px]">
                          RECOMMENDED
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[10px] mt-2 pt-2 border-t border-slate-800/80 text-slate-400">
                      <div>
                        <span>成本: </span>
                        <span className="text-emerald-400 font-bold">{r.estimatedCostBps} bps</span>
                      </div>
                      <div>
                        <span>延迟: </span>
                        <span className="text-cyan-400 font-bold">{r.estimatedLatencyMs} ms</span>
                      </div>
                      <div>
                        <span>终局性: </span>
                        <span className="text-slate-200 font-bold">{r.settlementCertaintyScore}%</span>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-500 mt-1">
                      {lang === 'en' ? r.routingReasonEn : r.routingReasonZh}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-4 pt-2 border-t border-slate-800 text-[10px] text-slate-500">
            Routing Objective: Minimum cost & latency, maximum liquidity efficiency.
          </div>
        </div>

        {/* Right: Digital Money Flow Graph (Prompt #19 & #20) (7 Cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm flex items-center gap-2">
                <Network className="w-4 h-4 text-cyan-400" />
                {lang === 'en' ? 'INTERACTIVE MONETARY FLOW GRAPH' : '货币流动拓扑结构图 (点击节点查看头寸)'}
              </span>
              <span className="text-[10px] text-slate-500">MONEYGRAPH &lt;GO&gt;</span>
            </div>

            {/* Visual Node Hierarchy */}
            <div className="space-y-3 py-2">
              {/* Root Node: PBOC */}
              <div className="flex justify-center">
                <button
                  onClick={() => setSelectedNode('PBOC')}
                  className={`px-4 py-2 rounded-lg border text-center transition-all ${
                    selectedNode === 'PBOC'
                      ? 'bg-emerald-950 border-emerald-400 text-emerald-200 shadow-lg scale-105'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] text-emerald-400 font-bold">SOVEREIGN ROOT (Layer A)</div>
                  <div className="text-xs font-bold mt-0.5">中国人民银行 (PBOC) / 人民币货币发行体系</div>
                  <div className="text-[10px] text-slate-500">M0/M1 Legal Tender Backbone</div>
                </button>
              </div>

              {/* Connecting Line */}
              <div className="flex justify-center">
                <div className="w-0.5 h-4 bg-slate-700"></div>
              </div>

              {/* Relay: Settlement Layer */}
              <div className="flex justify-center">
                <button
                  onClick={() => setSelectedNode('SETTLEMENT')}
                  className={`px-4 py-2 rounded-lg border text-center transition-all ${
                    selectedNode === 'SETTLEMENT'
                      ? 'bg-cyan-950 border-cyan-400 text-cyan-200 shadow-lg scale-105'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] text-cyan-400 font-bold">SETTLEMENT INTEROP LAYER</div>
                  <div className="text-xs font-bold mt-0.5">跨行支付系统 (CNAPS) ⇄ 数字人民币 (e-CNY 网关)</div>
                  <div className="text-[10px] text-slate-500">Interbank Clearing & Conversion Gateway</div>
                </button>
              </div>

              {/* Connecting Line */}
              <div className="flex justify-center">
                <div className="w-0.5 h-4 bg-slate-700"></div>
              </div>

              {/* Middle: Fukuyama Specie Bank Treasury */}
              <div className="flex justify-center">
                <button
                  onClick={() => setSelectedNode('TREASURY')}
                  className={`px-6 py-2.5 rounded-lg border-2 text-center transition-all ${
                    selectedNode === 'TREASURY'
                      ? 'bg-amber-950 border-amber-400 text-amber-200 shadow-xl scale-105'
                      : 'bg-slate-950 border-amber-900/60 text-slate-200 hover:border-amber-700'
                  }`}
                >
                  <div className="text-[10px] text-amber-400 font-bold">FUKUYAMA SPECIE BANK (Layer B)</div>
                  <div className="text-sm font-bold mt-0.5">福山金银银行核心总账与资金运营部</div>
                  <div className="text-[10px] text-slate-400">FSB-Core • Private RMB Issuance & Reserves</div>
                </button>
              </div>

              {/* Fan out Line */}
              <div className="flex justify-center">
                <div className="w-0.5 h-4 bg-slate-700"></div>
              </div>

              {/* Lower Tier: Retail, Corporate, Merchant */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setSelectedNode('RETAIL')}
                  className={`p-2.5 rounded border text-center transition-all ${
                    selectedNode === 'RETAIL'
                      ? 'bg-amber-950 border-amber-400 text-amber-200 scale-102'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] text-slate-500">RETAIL BANKING</div>
                  <div className="text-xs font-bold mt-0.5">个人零售储蓄</div>
                  <div className="text-[10px] text-amber-400/90 mt-1">240万客户</div>
                </button>

                <button
                  onClick={() => setSelectedNode('CORPORATE')}
                  className={`p-2.5 rounded border text-center transition-all ${
                    selectedNode === 'CORPORATE'
                      ? 'bg-amber-950 border-amber-400 text-amber-200 scale-102'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] text-slate-500">CORPORATE</div>
                  <div className="text-xs font-bold mt-0.5">企业结算资金</div>
                  <div className="text-[10px] text-amber-400/90 mt-1">8.4万企业</div>
                </button>

                <button
                  onClick={() => setSelectedNode('MERCHANT')}
                  className={`p-2.5 rounded border text-center transition-all ${
                    selectedNode === 'MERCHANT'
                      ? 'bg-amber-950 border-amber-400 text-amber-200 scale-102'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] text-slate-500">ACQUIRING</div>
                  <div className="text-xs font-bold mt-0.5">商户收单网络</div>
                  <div className="text-[10px] text-amber-400/90 mt-1">41万商户</div>
                </button>
              </div>
            </div>

            {/* Inspector Pane for Selected Node (Prompt #19) */}
            <div className="mt-4 p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-900">
                <span className="font-bold text-amber-300 text-xs">
                  {lang === 'en' ? activeNodeInfo.titleEn : activeNodeInfo.titleZh}
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-900">
                  {activeNodeInfo.status}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-500">账面余额/头寸: </span>
                  <span className="text-slate-200 font-bold">{activeNodeInfo.balance}</span>
                </div>
                <div>
                  <span className="text-slate-500">体系角色: </span>
                  <span className="text-slate-300">{lang === 'en' ? activeNodeInfo.roleEn : activeNodeInfo.roleZh}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-3 text-[10px] text-slate-500 flex justify-between">
            <span>NETWORK HEALTH: 100%</span>
            <span>END-OF-DAY RECONCILIATION: ACTIVE</span>
          </div>
        </div>
      </div>
    </div>
  );
};
