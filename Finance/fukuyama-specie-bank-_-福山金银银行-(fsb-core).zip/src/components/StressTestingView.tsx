/**
 * Fukuyama Specie Bank (FSB-Core)
 * Institutional Liquidity & Outage Stress Testing Engine (STRESS <GO> / 压力测试)
 * (Prompt #24)
 */

import React, { useState } from 'react';
import { 
  AlertOctagon, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingDown, 
  ShieldAlert, 
  Flame, 
  ArrowRight,
  Clock,
  Layers,
  HelpCircle
} from 'lucide-react';
import { Language } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';
import { StressEngine, StressSimulationResult } from '../core/stressEngine';

interface StressTestingViewProps {
  system: BankingSystem;
  lang: Language;
}

export const StressTestingView: React.FC<StressTestingViewProps> = ({ system, lang }) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState('RUN_20');

  const res = system.ledger.getReserveMetrics();
  const scenarios = StressEngine.SCENARIOS;
  const currentScenario = scenarios.find(s => s.id === selectedScenarioId) || scenarios[0];

  const simResult: StressSimulationResult = system.stressEngine.runSimulation(
    currentScenario,
    res.totalFSBDeposits,
    res.totalEligibleReserves,
    res.govBonds
  );

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-red-500" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'SYSTEMIC LIQUIDITY & OUTAGE STRESS TESTING' : '流动性挤兑与系统断网压力测试模拟器'}
              </h2>
              <span className="text-xs bg-red-950 text-red-300 px-2 py-0.5 rounded border border-red-800">
                STRESS &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Simulates 10%-50% bank runs, bond mark-to-market haircut shocks, and e-CNY/POS rail blackouts'
                : '模拟 10%～50% 存款流出挤兑、债券二级市场折价减值、数币与收单通道单点阻断'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-500 text-[11px]">SURVIVAL HORIZON</span>
            <div className={`text-base font-bold ${
              simResult.survivalHorizonHours <= 24 ? 'text-red-400 animate-pulse' : 'text-emerald-400'
            }`}>
              {simResult.survivalHorizonHours} HOURS ({Math.round(simResult.survivalHorizonHours / 24)} DAYS)
            </div>
          </div>
        </div>

        {/* Scenario Switcher Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mt-3">
          {scenarios.map(s => (
            <button
              key={s.id}
              onClick={() => setSelectedScenarioId(s.id)}
              className={`p-2 rounded border text-left transition-colors ${
                s.id === selectedScenarioId
                  ? 'bg-red-950/80 border-red-500 text-red-200 font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="text-[10px] text-slate-500 uppercase">{s.id}</div>
              <div className="text-xs mt-0.5 truncate">{s.nameZh}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Stress Scenario Parameters vs Simulation Impact Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left (5 Cols): Scenario Narrative & Stress Inputs */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm">
                {currentScenario.nameZh}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400">
                SCENARIO PROFILE
              </span>
            </div>

            <div className="space-y-3">
              <p className="text-slate-400 leading-relaxed text-xs">
                {lang === 'en' ? currentScenario.descriptionEn : currentScenario.descriptionZh}
              </p>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">假设存款流出比例:</span>
                  <span className="text-red-400 font-bold text-sm">
                    {currentScenario.depositWithdrawalPercent}%
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">国债变现折价率 (Haircut):</span>
                  <span className="text-amber-400 font-bold">{currentScenario.bondHaircutPercent}%</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">数字人民币网关阻断:</span>
                  <span className={currentScenario.ecnyOutage ? 'text-red-400 font-bold' : 'text-slate-500'}>
                    {currentScenario.ecnyOutage ? 'YES (离线状态)' : 'NO (畅通)'}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">POS商户网络中断:</span>
                  <span className={currentScenario.posOutage ? 'text-red-400 font-bold' : 'text-slate-500'}>
                    {currentScenario.posOutage ? 'YES (收单暂停)' : 'NO (正常)'}
                  </span>
                </div>
              </div>

              {/* Stress Severity Gauge */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>流动性清偿承受状态:</span>
                  <span className={`font-bold ${
                    simResult.settlementCapacityStatus === 'SECURE'
                      ? 'text-emerald-400'
                      : simResult.settlementCapacityStatus === 'MARGINAL'
                      ? 'text-amber-400'
                      : 'text-red-400 animate-pulse'
                  }`}>
                    {simResult.settlementCapacityStatus}
                  </span>
                </div>
                <div className="text-[11px] text-slate-300 mt-2">
                  {lang === 'en' ? simResult.summaryEn : simResult.summaryZh}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-2 border-t border-slate-800 text-[10px] text-slate-500">
            Regulatory Standard: Basel III Liquidity Coverage Ratio & PBOC Macroprudential Stress Framework.
          </div>
        </div>

        {/* Right (7 Cols): Quantitative Capital & Liquidity Impact Deck */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-amber-400 text-sm flex items-center gap-2">
                <TrendingDown className="w-4 h-4" />
                {lang === 'en' ? 'QUANTITATIVE IMPACT METRICS' : '压力测试前后关键财务与流动性指标对比'}
              </span>
              <span className="text-[10px] text-slate-500">POST-STRESS PROJECTION</span>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px]">PRE-STRESS DEPOSITS</div>
                <div className="text-slate-200 font-bold text-sm mt-0.5">
                  {Money.formatInstitutional(simResult.preDepositsCents, lang)}
                </div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px]">POST-STRESS DEPOSITS (残存负债)</div>
                <div className="text-amber-400 font-bold text-sm mt-0.5">
                  {Money.formatInstitutional(simResult.postDepositsCents, lang)}
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px]">DEPOSIT OUTFLOW (流出总量)</div>
                <div className="text-red-400 font-bold text-sm mt-0.5">
                  -{Money.formatInstitutional(simResult.depositOutflowCents, lang)}
                </div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="text-slate-500 text-[10px]">RESERVES DEPLETED (准备金消耗率)</div>
                <div className="text-red-400 font-bold text-sm mt-0.5">
                  {simResult.reserveDepletionPercent.toFixed(1)}% 耗尽
                </div>
              </div>
            </div>

            {/* Ratios Comparison Table */}
            <div className="bg-slate-950 rounded border border-slate-800 p-3 space-y-2">
              <div className="flex justify-between items-center text-xs pb-1.5 border-b border-slate-900">
                <span className="text-slate-400">准备金覆盖率 (Reserve Ratio):</span>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 line-through">
                    {Money.ratioPercentage(simResult.preReservesCents, simResult.preDepositsCents).toFixed(1)}%
                  </span>
                  <ArrowRight className="w-3 h-3 text-slate-500" />
                  <span className="text-emerald-400 font-bold">
                    {simResult.postReserveCoverageRatio.toFixed(1)}%
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center text-xs pb-1.5 border-b border-slate-900">
                <span className="text-slate-400">流动性覆盖率 (LCR):</span>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 line-through">
                    {Money.ratioPercentage(simResult.preLCRCents, simResult.preDepositsCents).toFixed(1)}%
                  </span>
                  <ArrowRight className="w-3 h-3 text-slate-500" />
                  <span className={`font-bold ${simResult.postLiquidityCoverageRatio < 30 ? 'text-red-400' : 'text-cyan-400'}`}>
                    {simResult.postLiquidityCoverageRatio.toFixed(1)}%
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">需申请人行SLF应急流动性支持:</span>
                <span className={simResult.emergencyPBOCRefinancingNeededCents > 0n ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                  {simResult.emergencyPBOCRefinancingNeededCents > 0n
                    ? Money.formatInstitutional(simResult.emergencyPBOCRefinancingNeededCents, lang)
                    : '¥0.00 (自有HQLA缓冲充足)'}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 p-2 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>RESILIENCE EVALUATION: PASS</span>
            <span className="text-emerald-400 font-bold">CAPITAL SOUNDNESS MAINTAINED</span>
          </div>
        </div>
      </div>
    </div>
  );
};
