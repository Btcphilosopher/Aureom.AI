/**
 * Fukuyama Specie Bank (FSB-Core)
 * Multi-Rail Automated Reconciliation Engine (RECON <GO> / 清算对账)
 * (Prompt #28)
 */

import React, { useState } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Layers, 
  FileCheck, 
  ArrowRight,
  ShieldCheck,
  Search
} from 'lucide-react';
import { Language, ReconciliationDiscrepancy } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';
import { ReconRunReport } from '../core/reconciliation';

interface ReconciliationViewProps {
  system: BankingSystem;
  lang: Language;
  onRefresh: () => void;
}

export const ReconciliationView: React.FC<ReconciliationViewProps> = ({
  system,
  lang,
  onRefresh
}) => {
  const [report, setReport] = useState<ReconRunReport>(() => system.reconEngine.runReconciliation());
  const [resolutionNotice, setResolutionNotice] = useState<string | null>(null);

  const handleRunFreshRecon = () => {
    const res = system.reconEngine.runReconciliation();
    setReport(res);
    onRefresh();
  };

  const handleResolveDiscrepancy = (item: ReconciliationDiscrepancy) => {
    system.reconEngine.resolveDiscrepancy(item.discrepancyId, '经调阅终端日志与人行对账流水，平账补记');
    const updated = system.reconEngine.runReconciliation();
    setReport(updated);
    setResolutionNotice(
      lang === 'en'
        ? `Discrepancy [${item.discrepancyId}] adjusted and reconciled in core ledger.`
        : `差错记录 [${item.discrepancyId}] 已完成平账冲销调整，核心总账分录已记入。`
    );
    onRefresh();
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'MULTI-RAIL RECONCILIATION ENGINE' : '跨通道多源自动化平账与日终对账系统'}
              </h2>
              <span className="text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded border border-slate-700">
                RECON &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Matches Core Ledger ⇄ POS Journal ⇄ e-CNY PBOC Clearing ⇄ CNAPS Statements'
                : '核心总账 ⇄ POS收单流水 ⇄ 人行数字人民币清分 ⇄ 跨行大额对账单四方一致性比对'}
            </p>
          </div>

          <button
            onClick={handleRunFreshRecon}
            className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition-colors flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'RUN FULL RECON SCAN' : '触发全渠道对账扫描'}</span>
          </button>
        </div>

        {/* Status Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px]">TOTAL SCANNED</div>
            <div className="text-slate-100 font-bold text-sm mt-0.5">
              {report.totalRecordsScanned.toLocaleString()} 笔
            </div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px]">MATCHED RECORDS</div>
            <div className="text-emerald-400 font-bold text-sm mt-0.5">
              {report.totalMatchedRecords.toLocaleString()} 笔
            </div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px]">MATCHED VOLUME</div>
            <div className="text-cyan-400 font-bold text-sm mt-0.5">
              {Money.formatInstitutional(report.matchedVolumeCents, lang)}
            </div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px]">UNRECONCILED DISCREPANCIES</div>
            <div className={`font-bold text-sm mt-0.5 ${
              report.unreconciledDiscrepanciesCount > 0 ? 'text-amber-400 animate-pulse' : 'text-emerald-400'
            }`}>
              {report.unreconciledDiscrepanciesCount} 笔差错
            </div>
          </div>
        </div>
      </div>

      {resolutionNotice && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            {resolutionNotice}
          </span>
          <button onClick={() => setResolutionNotice(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Discrepancy Queue */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
          <span className="font-bold text-slate-200 text-sm">
            {lang === 'en' ? 'DISCREPANCY EXCEPTION QUEUE' : '差错流水明细与平账调整工作台'}
          </span>
          <span className="text-[10px] text-slate-500">AUTOMATED DISCREPANCY DETECTOR</span>
        </div>

        <div className="space-y-3">
          {report.discrepancies.length === 0 ? (
            <div className="text-emerald-400 text-center py-6">
              所有外部清算通道流水与总账借贷100%匹配一致，无差错待平。
            </div>
          ) : (
            report.discrepancies.map(d => (
              <div
                key={d.discrepancyId}
                className={`p-3 rounded border transition-colors ${
                  d.status === 'RESOLVED_ADJUSTED'
                    ? 'bg-slate-950/40 border-slate-800 text-slate-500'
                    : 'bg-slate-950 border-amber-900/80 text-slate-200'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between pb-2 border-b border-slate-900 gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-amber-400">{d.discrepancyId}</span>
                    <span className="text-slate-500">|</span>
                    <span className="text-slate-300 font-mono">{d.transactionRef}</span>
                    <span className="text-slate-500">|</span>
                    <span className="px-1.5 py-0.2 bg-slate-900 text-cyan-300 rounded text-[10px]">
                      RAIL: {d.systemRail}
                    </span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    d.status === 'RESOLVED_ADJUSTED'
                      ? 'bg-emerald-950 text-emerald-400'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}>
                    {d.status}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px] my-2">
                  <div>
                    <span className="text-slate-500">总账记录金额 (Ledger): </span>
                    <span className="font-bold text-slate-200">{Money.format(d.ledgerAmountCents)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">通道对账单金额 (Rail): </span>
                    <span className="font-bold text-slate-200">{Money.format(d.externalRailAmountCents)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">差错类型 (Type): </span>
                    <span className="text-amber-400 font-bold">{d.type}</span>
                  </div>
                </div>

                {d.status !== 'RESOLVED_ADJUSTED' && (
                  <div className="mt-2 pt-2 border-t border-slate-900 flex justify-end">
                    <button
                      onClick={() => handleResolveDiscrepancy(d)}
                      className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition-colors flex items-center gap-1.5"
                    >
                      <span>平账调整 (Post Adjusting Entry in Ledger)</span>
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
