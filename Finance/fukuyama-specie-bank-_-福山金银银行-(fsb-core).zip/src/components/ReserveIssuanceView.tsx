/**
 * Fukuyama Specie Bank (FSB-Core)
 * Reserve Engine & Private RMB Issuance Simulator (RESERVE / ISSUE <GO>)
 */

import React, { useState } from 'react';
import { 
  Coins, 
  ShieldCheck, 
  TrendingUp, 
  Sliders, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  Building,
  Layers,
  Sparkles
} from 'lucide-react';
import { Language } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface ReserveIssuanceViewProps {
  system: BankingSystem;
  lang: Language;
  onRefresh: () => void;
}

export const ReserveIssuanceView: React.FC<ReserveIssuanceViewProps> = ({
  system,
  lang,
  onRefresh
}) => {
  // Issuance simulator state
  const [simDepositAmountInput, setSimDepositAmountInput] = useState('100000000'); // 1亿 (100M)
  const [targetReserveRatio, setTargetReserveRatio] = useState(30); // 30% target
  const [selectedAssetCode, setSelectedAssetCode] = useState<'1002' | '1003' | '1001'>('1002');
  const [selectedDepositCode, setSelectedDepositCode] = useState<'2001' | '2002' | '2004'>('2002');
  const [counterpartyName, setCounterpartyName] = useState('上海临港先进制造集团');
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  const res = system.ledger.getReserveMetrics();
  const bs = system.ledger.getBalanceSheet();
  const history = system.issuanceEngine.getHistory();

  // Dynamic Simulator calculations
  const simCents = Money.parse(simDepositAmountInput);
  const currentDeposits = res.totalFSBDeposits;
  const currentReserves = res.totalEligibleReserves;
  
  // Post-simulated numbers if new issuance occurred
  const simulatedDeposits = currentDeposits + simCents;
  const simulatedReserves = currentReserves + simCents; // Assuming 100% reserve asset inflow
  const simulatedReserveRatio = Money.ratioPercentage(simulatedReserves, simulatedDeposits);

  // Maximum theoretical deposit capacity given target reserve ratio:
  // MaxDeposits = AvailableReserves / (TargetRatio / 100)
  // MaxAdditional = MaxDeposits - CurrentDeposits
  const targetRatioBig = BigInt(targetReserveRatio);
  const maxPossibleDepositsCents = targetRatioBig > 0n 
    ? (currentReserves * 100n) / targetRatioBig 
    : 0n;
  const maxAdditionalDepositsCents = maxPossibleDepositsCents > currentDeposits 
    ? maxPossibleDepositsCents - currentDeposits 
    : 0n;

  const handleExecuteLiveIssuance = () => {
    try {
      if (simCents <= 0n) return;
      system.issuanceEngine.issuePrivateRMB(
        simCents,
        counterpartyName,
        'Enterprise Partner',
        selectedDepositCode,
        selectedAssetCode,
        'CHIEF-TREASURER-01'
      );
      setActionSuccessMsg(
        lang === 'en'
          ? `SUCCESSFULLY ISSUED: Created ${Money.format(simCents)} FSB-CNY liabilities backed by [${selectedAssetCode}] reserves.`
          : `发行成功：核发以人民币计价的私人银行存款负债 (FSB-CNY) ${Money.format(simCents)}，对应储备资产 [${selectedAssetCode}] 划入核心总账。`
      );
      onRefresh();
    } catch (err: any) {
      alert(`Issuance failed: ${err.message}`);
    }
  };

  const handleExecuteLiveRedemption = () => {
    try {
      if (simCents <= 0n) return;
      system.issuanceEngine.redeemPrivateRMB(
        simCents,
        counterpartyName,
        'Enterprise Partner',
        selectedDepositCode,
        selectedAssetCode,
        'CHIEF-TREASURER-01'
      );
      setActionSuccessMsg(
        lang === 'en'
          ? `SUCCESSFULLY REDEEMED: Extinguished ${Money.format(simCents)} FSB-CNY liabilities via [${selectedAssetCode}] reserve outflow.`
          : `兑付注销成功：核销私人人民币存款负债 (FSB-CNY) ${Money.format(simCents)}，划付央行清算备付金。`
      );
      onRefresh();
    } catch (err: any) {
      alert(`Redemption failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-3 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Coins className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'RESERVE ENGINE & PRIVATE RMB ISSUANCE' : '准备金管理引擎与私人人民币发行模拟'}
              </h2>
              <span className="text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded border border-slate-700">
                RESERVE / ISSUE &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Monetary Issuance Equation: Net Issuance = Deposits Created - Deposits Redeemed'
                : '货币负债核算恒等式: 净发行量 = 存款创造额 - 存款兑付额 - 注销额'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-500 text-[11px]">NET PRIVATE RMB ISSUED</span>
            <div className="text-base font-bold text-amber-400">
              {Money.formatInstitutional(res.totalFSBDeposits, lang)}
            </div>
          </div>
        </div>

        {/* Live Metrics Quad */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'ELIGIBLE RESERVES' : '法定合格准备金'}</div>
            <div className="text-emerald-400 font-bold text-sm mt-0.5">
              {Money.formatInstitutional(res.totalEligibleReserves, lang)}
            </div>
            <div className="text-[10px] text-slate-500 mt-1">Cash + PBOC + e-CNY</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'RESERVE COVERAGE RATIO' : '准备金覆盖率'}</div>
            <div className="text-cyan-400 font-bold text-sm mt-0.5">
              {res.reserveRatio.toFixed(1)}%
            </div>
            <div className="text-[10px] text-emerald-500 mt-1">PBOC Reg: &gt;12.5%</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'LIQUIDITY COVERAGE (LCR)' : '流动性覆盖率 (LCR)'}</div>
            <div className="text-amber-400 font-bold text-sm mt-0.5">
              {res.liquidityRatio.toFixed(1)}%
            </div>
            <div className="text-[10px] text-slate-500 mt-1">HQLA / Stressed Outflows</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'AVAILABLE UNENCUMBERED' : '未质押可用流动性'}</div>
            <div className="text-slate-100 font-bold text-sm mt-0.5">
              {Money.formatInstitutional(res.availableLiquidity, lang)}
            </div>
            <div className="text-[10px] text-slate-500 mt-1">Free for clearing</div>
          </div>
        </div>
      </div>

      {actionSuccessMsg && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded flex items-center justify-between">
          <span>{actionSuccessMsg}</span>
          <button onClick={() => setActionSuccessMsg(null)} className="text-slate-400 hover:text-white text-xs">
            ✕
          </button>
        </div>
      )}

      {/* Main Grid: Waterfall Structure vs Interactive Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Waterfall: Monetary Liability Structure (Prompt #15) */}
        <div className="bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm">
                {lang === 'en' ? 'MONETARY LIABILITY STRUCTURE' : '货币负债与资产支撑结构 (资产负债分解)'}
              </span>
              <span className="text-[10px] text-slate-500">WATERFALL ANALYSIS</span>
            </div>

            {/* FSB-CNY Deposits breakdown */}
            <div className="space-y-3">
              <div>
                <div className="text-xs font-bold text-amber-400 mb-1.5 flex justify-between">
                  <span>{lang === 'en' ? 'Private RMB Deposit Liabilities' : '私人人民币存款负债总量'}</span>
                  <span>{Money.formatInstitutional(res.totalFSBDeposits, lang)}</span>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded">
                    <span className="text-slate-400">个人活期储蓄 (Retail)</span>
                    <span className="font-bold text-slate-200">{Money.formatInstitutional(res.retailDeposits, lang)}</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded">
                    <span className="text-slate-400">企业活期存款 (Corporate)</span>
                    <span className="font-bold text-slate-200">{Money.formatInstitutional(res.corporateDeposits, lang)}</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded">
                    <span className="text-slate-400">商户待结算浮存 (Merchant)</span>
                    <span className="font-bold text-slate-200">{Money.formatInstitutional(res.merchantFloat, lang)}</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded">
                    <span className="text-slate-400">同业与机构托管 (Institutional)</span>
                    <span className="font-bold text-slate-200">{Money.formatInstitutional(res.institutionalDeposits, lang)}</span>
                  </div>
                </div>
              </div>

              {/* Backing Assets breakdown */}
              <div className="pt-2 border-t border-slate-800">
                <div className="text-xs font-bold text-emerald-400 mb-1.5 flex justify-between">
                  <span>{lang === 'en' ? 'Backing Reserve & Liquid Assets' : '增信支撑储备与优质流动性资产'}</span>
                  <span>{Money.formatInstitutional(res.totalHQLA, lang)}</span>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded">
                    <span className="text-slate-400">存放央行准备金 (PBOC Deposits)</span>
                    <span className="font-bold text-emerald-400">{Money.formatInstitutional(res.pbocReserves, lang)}</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded">
                    <span className="text-slate-400">中国国债投资 (PRC Treasury Bonds)</span>
                    <span className="font-bold text-emerald-400">{Money.formatInstitutional(res.govBonds, lang)}</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded">
                    <span className="text-slate-400">数字人民币系统清算资金 (e-CNY Clearing)</span>
                    <span className="font-bold text-cyan-400">{Money.formatInstitutional(res.ecnyClearing, lang)}</span>
                  </div>
                  <div className="flex justify-between items-center bg-slate-950 p-2 rounded">
                    <span className="text-slate-400">政策性金融债 (Policy Bank Bonds)</span>
                    <span className="font-bold text-slate-300">{Money.formatInstitutional(res.policyBonds, lang)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-2.5 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-400">
            {lang === 'en'
              ? 'Institutional Safeguard: Fukuyama operates with a 39.5% liquid backing ratio, substantially exceeding the required 12.5% PBOC statutory threshold.'
              : '制度性保障：福山金银银行保持高达 39.5% 的流动储备增信比例，远高于中国人民银行 12.5% 的法定存款准备金率要求。'}
          </div>
        </div>

        {/* Interactive Issuance Simulator (Prompt #23) */}
        <div className="bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-amber-400 text-sm flex items-center gap-2">
                <Sliders className="w-4 h-4" />
                {lang === 'en' ? 'RESERVE-BACKED ISSUANCE SIMULATOR' : '准备金支撑负债发行模拟与执行'}
              </span>
              <span className="text-[10px] text-slate-500">INTERACTIVE REGULATION MODEL</span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  {lang === 'en' ? 'Issuance Amount (RMB ¥):' : '发行/赎回金额 (人民币元):'}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={simDepositAmountInput}
                    onChange={e => setSimDepositAmountInput(e.target.value)}
                    placeholder="100000000"
                    className="flex-1 bg-black border border-slate-700 rounded px-2.5 py-1.5 text-xs text-amber-200 focus:outline-none focus:border-amber-500 font-mono"
                  />
                  <div className="flex gap-1">
                    <button
                      onClick={() => setSimDepositAmountInput('10000000')}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[10px] text-slate-300"
                    >
                      1000万
                    </button>
                    <button
                      onClick={() => setSimDepositAmountInput('100000000')}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[10px] text-slate-300"
                    >
                      1亿
                    </button>
                    <button
                      onClick={() => setSimDepositAmountInput('500000000')}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[10px] text-slate-300"
                    >
                      5亿
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center text-[11px] text-slate-400 mb-1">
                  <span>{lang === 'en' ? 'Target Minimum Reserve Ratio:' : '目标最低准备金率约束:'}</span>
                  <span className="text-cyan-400 font-bold">{targetReserveRatio}%</span>
                </div>
                <input
                  type="range"
                  min="12"
                  max="60"
                  value={targetReserveRatio}
                  onChange={e => setTargetReserveRatio(Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">
                    {lang === 'en' ? 'Backing Reserve Asset:' : '划入储备资产账户:'}
                  </label>
                  <select
                    value={selectedAssetCode}
                    onChange={e => setSelectedAssetCode(e.target.value as any)}
                    className="w-full bg-black border border-slate-700 rounded px-2 py-1.5 text-xs text-slate-200 focus:outline-none"
                  >
                    <option value="1002">[1002] 存放中央银行准备金</option>
                    <option value="1003">[1003] 数字人民币清算资金</option>
                    <option value="1001">[1001] 库存现金</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">
                    {lang === 'en' ? 'Target Liability Account:' : '记入私人负债账户:'}
                  </label>
                  <select
                    value={selectedDepositCode}
                    onChange={e => setSelectedDepositCode(e.target.value as any)}
                    className="w-full bg-black border border-slate-700 rounded px-2 py-1.5 text-xs text-slate-200 focus:outline-none"
                  >
                    <option value="2002">[2002] 企业活期存款</option>
                    <option value="2001">[2001] 个人储蓄存款</option>
                    <option value="2004">[2004] 机构特种存款</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  {lang === 'en' ? 'Counterparty Entity Name:' : '交易对手/客户名称:'}
                </label>
                <input
                  type="text"
                  value={counterpartyName}
                  onChange={e => setCounterpartyName(e.target.value)}
                  className="w-full bg-black border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-200 focus:outline-none font-mono"
                />
              </div>

              {/* Simulation Result Box */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1.5">
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-400">最大理论支持新增存款扩张空间:</span>
                  <span className="text-emerald-400 font-bold">
                    {Money.formatInstitutional(maxAdditionalDepositsCents, lang)}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-400">执行后预计准备金覆盖率:</span>
                  <span className="text-cyan-400 font-bold">{simulatedReserveRatio.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-400">合规审计结论:</span>
                  <span className="text-emerald-400 font-bold">符合央行宏观审慎评估 (MPA) 监管要求</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex gap-2">
            <button
              onClick={handleExecuteLiveIssuance}
              className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              {lang === 'en' ? 'ISSUE FSB-CNY (Create Deposit)' : '核准发行 (借储备/贷存款负债)'}
            </button>
            <button
              onClick={handleExecuteLiveRedemption}
              className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold border border-slate-700 rounded text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <ArrowRight className="w-3.5 h-3.5" />
              {lang === 'en' ? 'REDEEM FSB-CNY (Extinguish)' : '兑付注销 (借存款/贷储备)'}
            </button>
          </div>
        </div>
      </div>

      {/* Issuance Audit Log */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
          <span className="font-bold text-slate-200">
            {lang === 'en' ? 'IMMUTABLE ISSUANCE AUDIT TRAIL' : '私人人民币负债创造与注销不可篡改审计凭据'}
          </span>
          <span className="text-[10px] text-slate-500">SM2/SM3 DIGITALLY SIGNED</span>
        </div>

        <div className="space-y-2">
          {history.length === 0 ? (
            <div className="text-slate-500 text-center py-4">
              暂无人工触发发行记录。点击上方按钮执行动态货币发行或兑付。
            </div>
          ) : (
            history.map(evt => (
              <div key={evt.eventId} className="p-2.5 bg-slate-950 border border-slate-800 rounded flex justify-between items-center">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                      evt.type === 'CREATION' ? 'bg-emerald-950 text-emerald-400' : 'bg-cyan-950 text-cyan-400'
                    }`}>
                      {evt.type}
                    </span>
                    <span className="font-bold text-slate-200">{evt.eventId}</span>
                    <span className="text-slate-500">|</span>
                    <span className="text-slate-300">{evt.counterpartyCustomerZh}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    {lang === 'en' ? evt.notesEn : evt.notesZh}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-amber-300 text-xs">
                    {evt.type === 'CREATION' ? '+' : '-'}{Money.format(evt.amountCents)}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    {evt.auditSignature}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
