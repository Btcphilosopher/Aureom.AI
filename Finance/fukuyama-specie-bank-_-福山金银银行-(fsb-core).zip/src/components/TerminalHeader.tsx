/**
 * Fukuyama Specie Bank (FSB-Core)
 * Institutional Terminal Header & Command Line Bar
 */

import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  Search, 
  ShieldCheck, 
  Cpu, 
  Clock, 
  Layers, 
  Globe2, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { Language, TerminalCommandDef } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';

interface TerminalHeaderProps {
  currentView: string;
  onNavigate: (viewId: string) => void;
  lang: Language;
  onToggleLang: () => void;
  system: BankingSystem;
}

export const TerminalHeader: React.FC<TerminalHeaderProps> = ({
  currentView,
  onNavigate,
  lang,
  onToggleLang,
  system
}) => {
  const [commandInput, setCommandInput] = useState('');
  const [currentTime, setCurrentTime] = useState('');
  const [suggestions, setSuggestions] = useState<TerminalCommandDef[]>([]);
  const [showHelp, setShowHelp] = useState(false);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      // Format as Beijing Time (CST / UTC+8)
      const options: Intl.DateTimeFormatOptions = {
        timeZone: 'Asia/Shanghai',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      };
      const formatted = new Intl.DateTimeFormat('zh-CN', options).format(now);
      setCurrentTime(`${formatted} CST (UTC+8)`);
    };

    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleCommandChange = (val: string) => {
    setCommandInput(val);
    if (!val.trim()) {
      setSuggestions([]);
      return;
    }
    const clean = val.toUpperCase().trim();
    const matches = BankingSystem.TERMINAL_COMMANDS.filter(
      c => c.command.includes(clean) || c.chineseAlias.includes(val.trim()) || c.targetView.includes(clean)
    );
    setSuggestions(matches.slice(0, 5));
  };

  const handleExecuteCommand = (cmdDef?: TerminalCommandDef) => {
    const target = cmdDef || suggestions[0];
    if (target) {
      onNavigate(target.targetView);
      setCommandInput('');
      setSuggestions([]);
      return;
    }

    // Direct match against known target views
    const upper = commandInput.toUpperCase().trim().replace('<GO>', '').trim();
    const directMatch = BankingSystem.TERMINAL_COMMANDS.find(
      c => c.command.startsWith(upper) || c.targetView === upper || c.chineseAlias === commandInput.trim()
    );
    if (directMatch) {
      onNavigate(directMatch.targetView);
    }
    setCommandInput('');
    setSuggestions([]);
  };

  const navItems = [
    { id: 'MAIN', zh: '总览', en: 'OVERVIEW', code: 'MAIN' },
    { id: 'BAL', zh: '资产负债表', en: 'BAL SHEET', code: 'BAL' },
    { id: 'RESERVE', zh: '储备与发行', en: 'RESERVES', code: 'RES' },
    { id: 'POS', zh: 'POS验证器', en: 'POS VAL', code: 'POS' },
    { id: 'ECNY', zh: '数字人民币', en: 'e-CNY', code: 'ECNY' },
    { id: 'ROUTER', zh: '支付路由', en: 'ROUTER', code: 'ROUT' },
    { id: 'MERCHANT', zh: '商户银行', en: 'MERCHANT', code: 'MER' },
    { id: 'CORPORATE', zh: '企业银行', en: 'CORP PAY', code: 'CORP' },
    { id: 'MOBILE', zh: '手机银行', en: 'MOBILE', code: 'MOB' },
    { id: 'RECON', zh: '对账系统', en: 'RECON', code: 'REC' },
    { id: 'RISK', zh: '风控合规', en: 'RISK/AML', code: 'RISK' },
    { id: 'STRESS', zh: '压力测试', en: 'STRESS', code: 'STR' },
    { id: 'API', zh: 'API沙箱', en: 'API GATE', code: 'API' }
  ];

  const bs = system.ledger.getBalanceSheet();

  return (
    <header className="bg-slate-950 border-b border-slate-800 text-slate-200 select-none sticky top-0 z-50">
      {/* Top Telemetry Strip */}
      <div className="px-3 py-1 bg-slate-900/90 border-b border-slate-800/80 text-[11px] font-mono flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 font-bold text-amber-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            FSB-CORE v4.8
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400">
            {lang === 'en' ? 'Fukuyama Specie Bank' : '福山金银银行'}
          </span>
          <span className="text-slate-500">|</span>
          <span className="flex items-center gap-1 text-emerald-400">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            RMB PAYMENT: ONLINE
          </span>
          <span className="flex items-center gap-1 text-emerald-400">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            LEDGER: BALANCED (ΣD=ΣC)
          </span>
          <span className="flex items-center gap-1 text-cyan-400">
            <Cpu className="w-3 h-3 text-cyan-400" />
            e-CNY: SIMULATION READY
          </span>
        </div>

        <div className="flex items-center gap-4 text-slate-400">
          <span className="flex items-center gap-1 text-slate-300">
            <Clock className="w-3 h-3 text-slate-400" />
            {currentTime || '2026-10-12 17:45:00 CST'}
          </span>
          <span className="text-slate-500">|</span>
          <button 
            onClick={onToggleLang}
            className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded text-[10px] flex items-center gap-1 transition-colors border border-slate-700"
            title="Switch Language (ZH / EN / Bilingual)"
          >
            <Globe2 className="w-3 h-3 text-cyan-400" />
            {lang === 'zh' ? '中文 (CN)' : lang === 'en' ? 'English (EN)' : '中英双语'}
          </button>
        </div>
      </div>

      {/* Main Terminal Bar & Command Box */}
      <div className="px-3 py-2 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-600 to-amber-900 border border-amber-500/50 flex items-center justify-center font-serif font-black text-amber-200 text-sm shadow-inner">
              福
            </div>
            <div>
              <div className="font-bold text-slate-100 tracking-tight text-sm leading-tight flex items-center gap-1.5">
                <span>福山金银银行</span>
                <span className="text-xs font-mono text-slate-400 font-normal">Fukuyama Specie Bank</span>
              </div>
              <div className="text-[10px] font-mono text-amber-400/90 tracking-wider">
                RMB PRIVATE BANK MONEY & INTEROPERABILITY ARCHITECTURE
              </div>
            </div>
          </div>
        </div>

        {/* Command Input / Quick Jump (Bloomberg Terminal style <GO>) */}
        <div className="relative flex-1 max-w-xl">
          <div className="flex items-center bg-black border border-slate-700 focus-within:border-amber-500 rounded px-2.5 py-1 text-xs font-mono transition-colors shadow-inner">
            <Terminal className="w-3.5 h-3.5 text-amber-400 mr-2 shrink-0" />
            <span className="text-amber-500 font-bold mr-1 shrink-0">FSB&gt;</span>
            <input 
              type="text"
              value={commandInput}
              onChange={e => handleCommandChange(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleExecuteCommand();
                }
              }}
              placeholder={lang === 'en' ? 'Enter command: BAL <GO>, POS <GO>, RESERVE <GO>, ECNY <GO>...' : '输入命令: BAL <GO>, POS <GO>, 储备 <GO>, 资产负债表 <GO>...'}
              className="bg-transparent text-amber-200 focus:outline-none w-full placeholder:text-slate-600 text-xs font-mono"
            />
            <button 
              onClick={() => handleExecuteCommand()}
              className="ml-2 px-2 py-0.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/50 rounded text-[10px] font-bold tracking-wider shrink-0 transition-colors"
            >
              &lt;GO&gt;
            </button>
          </div>

          {/* Autocomplete Dropdown */}
          {suggestions.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1 bg-slate-900 border border-slate-700 rounded shadow-2xl z-50 overflow-hidden font-mono text-xs">
              {suggestions.map((s, idx) => (
                <div 
                  key={idx}
                  onClick={() => handleExecuteCommand(s)}
                  className="px-3 py-1.5 hover:bg-amber-500/20 cursor-pointer flex items-center justify-between border-b border-slate-800 last:border-b-0 text-slate-300 hover:text-amber-200"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">{s.command}</span>
                    <span className="text-slate-400">({s.chineseAlias})</span>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    {lang === 'en' ? s.descriptionEn : s.descriptionZh}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Invariant badge & fast telemetry */}
        <div className="hidden lg:flex items-center gap-3 font-mono text-[11px]">
          <div className="bg-slate-900 border border-slate-800 px-2 py-1 rounded">
            <span className="text-slate-500">ASSETS: </span>
            <span className="text-emerald-400 font-bold">¥1.05tn</span>
          </div>
          <div className="bg-slate-900 border border-slate-800 px-2 py-1 rounded">
            <span className="text-slate-500">LIAB (FSB-CNY): </span>
            <span className="text-cyan-400 font-bold">¥930.0bn</span>
          </div>
          <div className="bg-slate-900 border border-slate-800 px-2 py-1 rounded">
            <span className="text-slate-500">EQUITY: </span>
            <span className="text-amber-400 font-bold">¥120.0bn</span>
          </div>
        </div>
      </div>

      {/* Navigation Subsystem Tabs */}
      <nav className="flex items-center gap-0.5 px-2 bg-slate-900 border-t border-slate-800/80 overflow-x-auto scrollbar-none font-mono text-xs">
        {navItems.map(item => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`px-3 py-1.5 whitespace-nowrap transition-colors border-b-2 flex items-center gap-1.5 text-xs ${
                isActive
                  ? 'border-amber-400 text-amber-300 bg-slate-950 font-bold shadow-sm'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <span className="text-[10px] text-slate-500 font-normal">[{item.code}]</span>
              <span>{lang === 'en' ? item.en : item.zh}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
