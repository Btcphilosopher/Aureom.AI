/**
 * Fukuyama Specie Bank (FSB-Core)
 * Merchant Acquiring & Settlement Engine (MERCHANT <GO> / 商户银行与清分结算)
 * (Prompt #11 & #12)
 */

import React, { useState } from 'react';
import { 
  Store, 
  CheckCircle2, 
  ArrowRight, 
  RefreshCw, 
  ShieldCheck, 
  Coins, 
  AlertTriangle,
  Clock,
  DollarSign
} from 'lucide-react';
import { Language, MerchantProfile } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface MerchantBankingViewProps {
  system: BankingSystem;
  lang: Language;
  onRefresh: () => void;
}

export const MerchantBankingView: React.FC<MerchantBankingViewProps> = ({
  system,
  lang,
  onRefresh
}) => {
  const [selectedMerchantId, setSelectedMerchantId] = useState('MERCH-001');
  const [settlementCycle, setSettlementCycle] = useState<'REALTIME' | 'INTRADAY' | 'T_PLUS_0' | 'T_PLUS_1'>('REALTIME');
  const [batchSettlementResult, setBatchSettlementResult] = useState<string | null>(null);

  const merchants = system.getMerchants();
  const currentMerchant = merchants.find(m => m.merchantId === selectedMerchantId) || merchants[0];
  const settlementAccount = system.getAccount(currentMerchant.settlementAccountId);

  const handleExecuteBatchSettlement = () => {
    try {
      const res = system.settleMerchantBatch(currentMerchant.merchantId, settlementCycle);
      if (res.settledAmountCents > 0n) {
        setBatchSettlementResult(
          lang === 'en'
            ? `Batch Settlement Completed: Disbursed ${Money.format(res.settledAmountCents)} into merchant account. Core Ref: ${res.txRef}`
            : `清算批次执行完毕：成功清分划拨 ${Money.format(res.settledAmountCents)} 净款至商户结算户。总账清算流水: ${res.txRef}`
        );
      } else {
        setBatchSettlementResult(
          lang === 'en' ? 'No pending settlement funds available for batch clearing.' : '当前无待结算在途资金。'
        );
      }
      onRefresh();
    } catch (err: any) {
      alert(`Settlement failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Store className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'MERCHANT ACQUIRING & SETTLEMENT ENGINE' : '特约商户银行收单与清分结算管理'}
              </h2>
              <span className="text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded border border-slate-700">
                MERCHANT / SETTLE &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Lifecycle: Authorisation ➔ Clearing ➔ Settlement ➔ Double-Entry Reconciliation'
                : '收单生命周期：交易授权 ➔ 净额轧差清分 ➔ 资金日终解付 ➔ 核心总账平账'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-500 text-[11px]">MERCHANT ACQUIRING FLOAT</span>
            <div className="text-sm font-bold text-amber-400">
              {Money.formatInstitutional(system.ledger.getAccount('2003').balanceCents, lang)}
            </div>
          </div>
        </div>

        {/* Merchant Switcher Ribbon */}
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {merchants.map(m => (
            <button
              key={m.merchantId}
              onClick={() => {
                setSelectedMerchantId(m.merchantId);
                setBatchSettlementResult(null);
              }}
              className={`px-3 py-1.5 rounded border whitespace-nowrap text-xs transition-colors ${
                m.merchantId === currentMerchant.merchantId
                  ? 'bg-amber-950/80 border-amber-500 text-amber-200 font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {m.businessNameZh} ({m.merchantId})
            </button>
          ))}
        </div>
      </div>

      {batchSettlementResult && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            {batchSettlementResult}
          </span>
          <button onClick={() => setBatchSettlementResult(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Merchant Dashboard KPI Cards (Prompt #11) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
          <div className="text-slate-500 text-[10px]">{lang === 'en' ? "Today's Volume" : '今日交易'}</div>
          <div className="text-sm font-bold text-slate-100 mt-1">
            {Money.format(currentMerchant.todayVolumeCents)}
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
          <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'Pending Settlement' : '待结算 (在途)'}</div>
          <div className="text-sm font-bold text-amber-400 mt-1">
            {Money.format(currentMerchant.pendingSettlementCents)}
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
          <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'Settled Today' : '已结算解付'}</div>
          <div className="text-sm font-bold text-emerald-400 mt-1">
            {Money.format(currentMerchant.settledTodayCents)}
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
          <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'Refunds' : '退款冲正'}</div>
          <div className="text-sm font-bold text-slate-300 mt-1">¥0.00</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
          <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'Chargebacks' : '拒付与调单'}</div>
          <div className="text-sm font-bold text-slate-300 mt-1">0 笔</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
          <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'Exceptions' : '异常交易'}</div>
          <div className="text-sm font-bold text-slate-300 mt-1">0 笔</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded">
          <div className="text-slate-500 text-[10px]">{lang === 'en' ? 'Fee Rate' : '综合费率'}</div>
          <div className="text-sm font-bold text-cyan-400 mt-1">{currentMerchant.feeRateBps} bps</div>
        </div>
      </div>

      {/* Grid: Merchant Profile (Left) & Settlement Batch Controller (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Merchant Profile */}
        <div className="bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm">
                {lang === 'en' ? 'MERCHANT INSTITUTION PROFILE' : '特约商户法定资质与准入档案'}
              </span>
              <span className="px-1.5 py-0.2 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                {currentMerchant.riskClassification}
              </span>
            </div>

            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-950">
                <span className="text-slate-500">企业法定名称:</span>
                <span className="font-bold text-slate-100">{currentMerchant.businessNameZh}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-950">
                <span className="text-slate-500">统一社会信用代码:</span>
                <span className="font-mono text-slate-300">{currentMerchant.registrationNumber}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-950">
                <span className="text-slate-500">商户类别码 (MCC):</span>
                <span className="font-mono text-cyan-300">{currentMerchant.mccCode} (零售/商超)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-950">
                <span className="text-slate-500">本行结算存款账户:</span>
                <span className="font-mono text-amber-300">{settlementAccount?.accountNumber}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-950">
                <span className="text-slate-500">账户活期余额 (FSB-CNY):</span>
                <span className="font-mono font-bold text-emerald-400">
                  {Money.format(settlementAccount?.balanceCents || 0n)}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-950">
                <span className="text-slate-500">单日收单上限额度:</span>
                <span className="font-mono text-slate-300">
                  {Money.format(currentMerchant.dailyVolumeLimitCents)}
                </span>
              </div>
            </div>

            {/* Terminal Fleet */}
            <div className="mt-3 pt-2 border-t border-slate-800">
              <div className="text-[11px] font-bold text-slate-400 mb-2">已绑定在网硬件机具:</div>
              <div className="space-y-1.5">
                {currentMerchant.terminals.map(t => (
                  <div key={t.terminalId} className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between items-center text-[11px]">
                    <div>
                      <span className="font-bold text-slate-200">{t.terminalId}</span>
                      <span className="text-slate-500 ml-2">({t.model})</span>
                      <div className="text-[10px] text-slate-500 mt-0.5">{t.location}</div>
                    </div>
                    <span className="text-emerald-400 font-bold">{t.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Settlement Cycle & Batch Executor (Prompt #12) */}
        <div className="bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-amber-400 text-sm flex items-center gap-2">
                <Clock className="w-4 h-4" />
                {lang === 'en' ? 'SETTLEMENT ENGINE DISBURSEMENT' : '商户清分结算执行与解付冲销'}
              </span>
              <span className="text-[10px] text-slate-500">DOUBLE-ENTRY CLEARING</span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  {lang === 'en' ? 'Select Settlement Frequency / Cycle:' : '选择清算解付周期 (结算批次):'}
                </label>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  {[
                    { id: 'REALTIME', zh: '实时即刻解付 (Real-Time)', en: 'Real-Time Clearing' },
                    { id: 'INTRADAY', zh: '日间多批次 (Intraday Net)', en: 'Intraday Batches' },
                    { id: 'T_PLUS_0', zh: '日终实时到账 (T+0 EOD)', en: 'T+0 End of Day' },
                    { id: 'T_PLUS_1', zh: '次日标准清算 (T+1 Standard)', en: 'T+1 Morning Run' }
                  ].map(c => (
                    <button
                      key={c.id}
                      onClick={() => setSettlementCycle(c.id as any)}
                      className={`p-2 rounded border text-left transition-colors ${
                        settlementCycle === c.id
                          ? 'bg-amber-950 border-amber-500 text-amber-200 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <div>{c.zh}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Pending Funds Breakdown Box */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">商户待解付净额 (扣除规费后):</span>
                  <span className="text-amber-400 font-bold text-sm">
                    {Money.format(currentMerchant.pendingSettlementCents)}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500">总账贷方科目 (2003):</span>
                  <span className="text-slate-300">商户待结算与在途款项</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500">划入借方科目 (2002):</span>
                  <span className="text-slate-300">企业活期存款 (商户自有资金)</span>
                </div>
              </div>

              <div className="p-2.5 bg-slate-950 rounded border border-slate-800/80 text-[11px] text-slate-400">
                {lang === 'en'
                  ? 'Clearing Rule: Funds held in account 2003 represent uncompleted settlement liabilities. Clicking below executes final gross-to-net netting and transfers claim balance to merchant demand deposit.'
                  : '清分规则：2003 科目记载尚未解付的收单在途负债。点击下方按钮将触发净额轧差计算，将收单款项全额解付至商户本行活期账户，完成核心总账借贷平账。'}
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800">
            <button
              onClick={handleExecuteBatchSettlement}
              disabled={currentMerchant.pendingSettlementCents <= 0n}
              className="w-full py-3 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 disabled:opacity-40 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>
                {lang === 'en'
                  ? `EXECUTE ${settlementCycle} BATCH DISBURSEMENT (${Money.format(currentMerchant.pendingSettlementCents)})`
                  : `执行 [${settlementCycle}] 批次资金清分解付 (${Money.format(currentMerchant.pendingSettlementCents)})`}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
