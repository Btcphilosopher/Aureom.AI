/**
 * Fukuyama Specie Bank (FSB-Core)
 * Balance Sheet & General Ledger (BAL <GO> / 资产负债表)
 * 
 * Strict Double-Entry Verification:
 * Total Assets === Total Liabilities + Total Equity
 * Σ Debits === Σ Credits
 */

import React, { useState } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  AlertTriangle, 
  Scale, 
  FileText, 
  Search, 
  Filter, 
  Layers,
  ArrowDownUp
} from 'lucide-react';
import { Language } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface BalanceSheetViewProps {
  system: BankingSystem;
  lang: Language;
}

export const BalanceSheetView: React.FC<BalanceSheetViewProps> = ({ system, lang }) => {
  const [activeTab, setActiveTab] = useState<'SHEET' | 'JOURNAL'>('SHEET');
  const [filterModule, setFilterModule] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const bs = system.ledger.getBalanceSheet();
  const accounts = system.ledger.getAllAccounts();
  const entries = system.ledger.getJournalEntries();

  const assetAccounts = accounts.filter(a => a.category === 'ASSET');
  const liabilityAccounts = accounts.filter(a => a.category === 'LIABILITY');
  const equityAccounts = accounts.filter(a => a.category === 'EQUITY');

  const filteredEntries = entries.filter(e => {
    if (filterModule !== 'ALL' && e.sourceModule !== filterModule) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchId = e.entryId.toLowerCase().includes(term);
      const matchRef = e.transactionRef.toLowerCase().includes(term);
      const matchLine = e.lines.some(
        l => l.memoZh.toLowerCase().includes(term) || l.memoEn.toLowerCase().includes(term) || l.accountCode.includes(term)
      );
      return matchId || matchRef || matchLine;
    }
    return true;
  });

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header and Live Invariant Verification Box */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-3 border-b border-slate-800 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Scale className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'GENERAL LEDGER & BALANCE SHEET' : '核心总账与法定资产负债表'}
              </h2>
              <span className="text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded border border-slate-700">
                BAL &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Standard Chinese Commercial Banking Chart of Accounts • Real-time double-entry trial balance'
                : '中国商业银行标准会计科目体系 • 实时复式记账平衡试算表'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('SHEET')}
              className={`px-3 py-1.5 rounded transition-colors text-xs font-bold ${
                activeTab === 'SHEET'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'en' ? 'BALANCE SHEET' : '资产负债表结构'}
            </button>
            <button
              onClick={() => setActiveTab('JOURNAL')}
              className={`px-3 py-1.5 rounded transition-colors text-xs font-bold ${
                activeTab === 'JOURNAL'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'en' ? 'JOURNAL ENTRIES (ΣD=ΣC)' : '记账凭证流水'}
            </button>
          </div>
        </div>

        {/* Live Accounting Invariant Bar */}
        <div className="mt-3 p-3 bg-slate-950 rounded border border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            {bs.isBalanced ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
            )}
            <div>
              <div className="text-xs font-bold text-slate-200 flex items-center gap-2">
                <span>
                  {bs.isBalanced
                    ? (lang === 'en' ? 'ACCOUNTING INVARIANT VERIFIED' : '会计恒等式完全平衡')
                    : (lang === 'en' ? 'BALANCE SHEET UNBALANCED!' : '资产负债表借贷失衡！')}
                </span>
                <span className={`px-2 py-0.2 rounded text-[10px] ${bs.isBalanced ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-red-950 text-red-400'}`}>
                  {bs.isBalanced ? 'A = L + E' : 'DISCREPANCY DETECTED'}
                </span>
              </div>
              <div className="text-[11px] text-slate-400">
                {lang === 'en'
                  ? `Total Assets (${Money.formatInstitutional(bs.totalAssets, lang)}) === Total Liabilities (${Money.formatInstitutional(bs.totalLiabilities, lang)}) + Equity (${Money.formatInstitutional(bs.effectiveEquity, lang)})`
                  : `资产总计 (${Money.formatInstitutional(bs.totalAssets, lang)}) === 负债总计 (${Money.formatInstitutional(bs.totalLiabilities, lang)}) + 所有者权益 (${Money.formatInstitutional(bs.effectiveEquity, lang)})`}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 text-right">
            <div>
              <div className="text-[10px] text-slate-500 uppercase">{lang === 'en' ? 'Net Retained Profit' : '当期清算净损益'}</div>
              <div className="text-xs font-bold text-emerald-400">
                +{Money.formatInstitutional(bs.netCurrentProfit, lang)}
              </div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500 uppercase">{lang === 'en' ? 'Discrepancy (Δ)' : '借贷差异'}</div>
              <div className="text-xs font-bold text-slate-300">
                {Money.format(bs.difference)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {activeTab === 'SHEET' ? (
        /* Balance Sheet Two-Column Layout */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Left Column: Assets */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
                <span className="font-bold text-emerald-400 text-sm">
                  {lang === 'en' ? 'ASSETS (资产类)' : '资产类 (1xxx)'}
                </span>
                <span className="text-slate-400 text-xs">
                  {Money.formatInstitutional(bs.totalAssets, lang)}
                </span>
              </div>

              <div className="space-y-2">
                {assetAccounts.map(acc => (
                  <div 
                    key={acc.code}
                    className="p-2 bg-slate-950/70 border border-slate-800/80 rounded flex justify-between items-center hover:border-slate-700 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-emerald-400 font-bold">[{acc.code}]</span>
                        <span className="text-slate-200">{lang === 'en' ? acc.nameEn : acc.nameZh}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5">
                        <span className="px-1 bg-slate-900 rounded">{acc.layer}</span>
                        {acc.hqlTier && (
                          <span className="text-cyan-400">HQLA: {acc.hqlTier}</span>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-slate-100 font-bold text-xs">
                        {Money.formatInstitutional(acc.balanceCents, lang)}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        {Money.format(acc.balanceCents)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between items-center text-sm font-bold bg-slate-950 p-3 rounded">
              <span className="text-slate-300">{lang === 'en' ? 'TOTAL ASSETS' : '资产总计'}</span>
              <span className="text-emerald-400">{Money.format(bs.totalAssets)}</span>
            </div>
          </div>

          {/* Right Column: Liabilities + Equity */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Liabilities */}
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
                  <span className="font-bold text-cyan-400 text-sm">
                    {lang === 'en' ? 'LIABILITIES (负债类 / 私人人民币存款)' : '负债类 (2xxx / 私人人民币负债)'}
                  </span>
                  <span className="text-slate-400 text-xs">
                    {Money.formatInstitutional(bs.totalLiabilities, lang)}
                  </span>
                </div>

                <div className="space-y-2">
                  {liabilityAccounts.map(acc => (
                    <div 
                      key={acc.code}
                      className="p-2 bg-slate-950/70 border border-slate-800/80 rounded flex justify-between items-center hover:border-slate-700 transition-colors"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-cyan-400 font-bold">[{acc.code}]</span>
                          <span className="text-slate-200">{lang === 'en' ? acc.nameEn : acc.nameZh}</span>
                        </div>
                        <div className="text-[10px] text-amber-400/90 mt-0.5">
                          {acc.code.startsWith('200') ? 'FSB-CNY Private Claim' : 'Interbank Liability'}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-slate-100 font-bold text-xs">
                          {Money.formatInstitutional(acc.balanceCents, lang)}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {Money.format(acc.balanceCents)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Equity */}
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
                  <span className="font-bold text-amber-400 text-sm">
                    {lang === 'en' ? 'EQUITY & CAPITAL (所有者权益)' : '所有者权益类 (3xxx)'}
                  </span>
                  <span className="text-slate-400 text-xs">
                    {Money.formatInstitutional(bs.effectiveEquity, lang)}
                  </span>
                </div>

                <div className="space-y-2">
                  {equityAccounts.map(acc => (
                    <div 
                      key={acc.code}
                      className="p-2 bg-slate-950/70 border border-slate-800/80 rounded flex justify-between items-center hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-amber-400 font-bold">[{acc.code}]</span>
                        <span className="text-slate-200">{lang === 'en' ? acc.nameEn : acc.nameZh}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-slate-100 font-bold text-xs">
                          {Money.formatInstitutional(acc.balanceCents, lang)}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {Money.format(acc.balanceCents)}
                        </div>
                      </div>
                    </div>
                  ))}

                  <div className="p-2 bg-slate-950/70 border border-slate-800/80 rounded flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span className="text-amber-400 font-bold">[PROFIT]</span>
                      <span className="text-slate-200">{lang === 'en' ? 'Current Period Retained Net Profit' : '本期累计未结清算净损益'}</span>
                    </div>
                    <div className="text-right font-bold text-emerald-400 text-xs">
                      {Money.formatInstitutional(bs.netCurrentProfit, lang)}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between items-center text-sm font-bold bg-slate-950 p-3 rounded">
              <span className="text-slate-300">{lang === 'en' ? 'TOTAL LIABILITIES & EQUITY' : '负债及权益总计'}</span>
              <span className="text-cyan-400">{Money.format(bs.totalLiabilities + bs.effectiveEquity)}</span>
            </div>
          </div>
        </div>
      ) : (
        /* Journal Entries Explorer */
        <div className="bg-slate-900 border border-slate-800 rounded p-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between pb-3 border-b border-slate-800 gap-3 mb-3">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-slate-200">
                {lang === 'en' ? 'DOUBLE-ENTRY JOURNAL AUDIT ARCHIVE' : '核心总账复式记账明细分录档案'}
              </span>
              <span className="text-[10px] text-slate-500">({filteredEntries.length} Records)</span>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2 top-2" />
                <input
                  type="text"
                  placeholder={lang === 'en' ? 'Filter entries...' : '搜索分录/凭证号...'}
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="bg-black border border-slate-700 rounded pl-7 pr-2 py-1 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-amber-500"
                />
              </div>

              <select
                value={filterModule}
                onChange={e => setFilterModule(e.target.value)}
                className="bg-black border border-slate-700 rounded px-2 py-1 text-xs text-slate-200 focus:outline-none"
              >
                <option value="ALL">ALL MODULES (全部业务来源)</option>
                <option value="POS">POS ACQUIRING (POS收单)</option>
                <option value="ISSUANCE">ISSUANCE (私人RMB发行)</option>
                <option value="ECNY_CONVERSION">e-CNY (数币互操作)</option>
                <option value="SETTLEMENT">SETTLEMENT (清分结算)</option>
              </select>
            </div>
          </div>

          <div className="space-y-3">
            {filteredEntries.map(entry => (
              <div key={entry.entryId} className="bg-slate-950 border border-slate-800 rounded p-3">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-900 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-amber-400">{entry.entryId}</span>
                    <span className="text-slate-500">|</span>
                    <span className="text-slate-400">Ref: {entry.transactionRef}</span>
                    <span className="text-slate-500">|</span>
                    <span className="px-1.5 py-0.2 bg-slate-900 text-cyan-300 rounded text-[10px]">
                      {entry.sourceModule}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-500 text-[11px]">
                    <span>Operator: {entry.operator}</span>
                    <span>{new Date(entry.timestamp).toLocaleTimeString()}</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  {entry.lines.map((line, idx) => (
                    <div 
                      key={idx}
                      className="flex items-center justify-between bg-slate-900/60 px-2 py-1 rounded text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className={`font-bold px-1 rounded text-[10px] ${
                          line.debitCents > 0n ? 'bg-emerald-950 text-emerald-400' : 'bg-cyan-950 text-cyan-400'
                        }`}>
                          {line.debitCents > 0n ? '借 (Dr)' : '贷 (Cr)'}
                        </span>
                        <span className="text-slate-300 font-bold">[{line.accountCode}]</span>
                        <span className="text-slate-300">{lang === 'en' ? line.accountNameEn : line.accountNameZh}</span>
                        <span className="text-slate-500 text-[11px]">({lang === 'en' ? line.memoEn : line.memoZh})</span>
                      </div>
                      <div className="font-bold text-slate-200">
                        {Money.format(line.debitCents > 0n ? line.debitCents : line.creditCents)}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-2 pt-2 border-t border-slate-900 flex justify-between items-center text-[11px] text-slate-400">
                  <span className="text-emerald-400 font-bold">Σ Debits = Σ Credits = {Money.format(entry.totalDebitCents)}</span>
                  <span className="text-emerald-400">STATUS: AUDITED & BALANCED</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
