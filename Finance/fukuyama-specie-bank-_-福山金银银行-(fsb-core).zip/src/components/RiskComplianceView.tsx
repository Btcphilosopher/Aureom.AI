/**
 * Fukuyama Specie Bank (FSB-Core)
 * Fraud Detection Engine & AML Compliance Cases (RISK / COMPLIANCE <GO>)
 * (Prompt #25, #26, #27)
 */

import React, { useState } from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  FileText, 
  Lock, 
  Search, 
  Eye, 
  ShieldCheck,
  Send
} from 'lucide-react';
import { Language, FraudAlert } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { AMLCase } from '../core/compliance';
import { Money } from '../core/math';

interface RiskComplianceViewProps {
  system: BankingSystem;
  lang: Language;
  onRefresh: () => void;
}

export const RiskComplianceView: React.FC<RiskComplianceViewProps> = ({
  system,
  lang,
  onRefresh
}) => {
  const [activeTab, setActiveTab] = useState<'FRAUD' | 'AML'>('FRAUD');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const alerts = system.complianceEngine.getAlerts();
  const cases = system.complianceEngine.getCases();

  const handleUpdateAlert = (alertId: string, status: FraudAlert['status']) => {
    system.complianceEngine.updateAlertStatus(alertId, status);
    setActionNotice(
      lang === 'en'
        ? `Alert ${alertId} updated to [${status}]. Audit record logged.`
        : `警报 ${alertId} 处理状态已更新为 [${status}]，写入合规审计日志。`
    );
    onRefresh();
  };

  const handleUpdateCase = (caseId: string, status: AMLCase['status']) => {
    system.complianceEngine.updateCaseStatus(caseId, status);
    setActionNotice(
      lang === 'en'
        ? `AML Case ${caseId} updated to [${status}]. Reported to MLRO.`
        : `反洗钱监测专案 ${caseId} 状态已更新为 [${status}]，向合规官及人行大额可疑系统报送。`
    );
    onRefresh();
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-red-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'FRAUD ENGINE & AML REGULATORY COMPLIANCE' : '反欺诈实时引擎与反洗钱 (AML) 合规专案'}
              </h2>
              <span className="text-xs bg-slate-800 text-red-300 px-2 py-0.5 rounded border border-slate-700">
                RISK / COMPLIANCE &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Real-time velocity scoring, sanctions screening adapter, and SAR/STR regulatory workflows'
                : '毫秒级交易流速异常建模、反洗钱大额与可疑交易报告 (STR/SAR) 工作流与制裁名单筛查'}
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('FRAUD')}
              className={`px-3 py-1.5 rounded font-bold transition-colors ${
                activeTab === 'FRAUD'
                  ? 'bg-red-950 border border-red-500 text-red-200'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'en' ? 'FRAUD ENGINE ALERTS' : '反欺诈实时告警队列'}
            </button>
            <button
              onClick={() => setActiveTab('AML')}
              className={`px-3 py-1.5 rounded font-bold transition-colors ${
                activeTab === 'AML'
                  ? 'bg-amber-950 border border-amber-500 text-amber-200'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'en' ? 'AML CASE MANAGEMENT (SAR/STR)' : '反洗钱专案与可疑报告'}
            </button>
          </div>
        </div>
      </div>

      {actionNotice && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            {actionNotice}
          </span>
          <button onClick={() => setActionNotice(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {activeTab === 'FRAUD' ? (
        /* Real-time Fraud Alerts Queue (Prompt #26) */
        <div className="space-y-3">
          {alerts.map(a => (
            <div key={a.alertId} className="bg-slate-900 border border-slate-800 rounded p-4">
              <div className="flex flex-wrap items-center justify-between pb-2 border-b border-slate-800 gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-red-400 text-sm">{a.alertId}</span>
                  <span className="text-slate-500">|</span>
                  <span className="text-slate-300">Ref: {a.transactionRef}</span>
                  <span className="text-slate-500">|</span>
                  <span className="text-slate-200 font-bold">{a.merchantNameZh}</span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 block">RISK SCORE:</span>
                    <span className="text-sm font-bold text-red-400 font-mono">{a.riskScore} / 100</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                    a.decision === 'REVIEW' ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-red-950 text-red-400'
                  }`}>
                    {a.decision === 'REVIEW' ? '人工审核 (REVIEW)' : '直接阻断 (BLOCK)'}
                  </span>
                </div>
              </div>

              {/* Grid: Details & Reason Codes (Prompt #26 Exact Chinese UI) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-300">
                <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
                  <div className="text-xs font-bold text-slate-200">
                    {lang === 'en' ? 'Reason Codes Flagged:' : '风险特征触发因子 (REASON CODES):'}
                  </div>
                  <ul className="space-y-1 text-[11px] text-amber-300">
                    {(lang === 'en' ? a.reasonCodesEn : a.reasonCodesZh).map((code, idx) => (
                      <li key={idx} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span>
                        <span>{code}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 flex flex-col justify-between">
                  <div className="space-y-1 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-500">涉案交易金额:</span>
                      <span className="font-bold text-slate-100">{Money.format(a.amountCents)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">风控拦截时间:</span>
                      <span>{new Date(a.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">当前工单状态:</span>
                      <span className="text-amber-400 font-bold">{a.status}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 mt-3 pt-2 border-t border-slate-900">
                    <button
                      onClick={() => handleUpdateAlert(a.alertId, 'CLEARED')}
                      className="flex-1 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition-colors"
                    >
                      放行解冻 / Clear
                    </button>
                    <button
                      onClick={() => handleUpdateAlert(a.alertId, 'SAR_FILED')}
                      className="flex-1 py-1 bg-red-600 hover:bg-red-500 text-slate-950 font-bold rounded text-xs transition-colors"
                    >
                      转交反洗钱 (File SAR)
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* AML Case Management (Prompt #27) */
        <div className="space-y-3">
          {cases.map(c => (
            <div key={c.caseId} className="bg-slate-900 border border-slate-800 rounded p-4">
              <div className="flex flex-wrap items-center justify-between pb-2 border-b border-slate-800 gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-amber-400 text-sm">{c.caseId}</span>
                  <span className="text-slate-500">|</span>
                  <span className="text-slate-100 font-bold">{c.customerNameZh}</span>
                  <span className="text-slate-500">({c.customerId})</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    c.riskRating === 'HIGH' ? 'bg-red-950 text-red-300 border border-red-800' : 'bg-amber-950 text-amber-300'
                  }`}>
                    {c.riskRating} RISK
                  </span>
                  <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded text-[10px]">
                    {c.status}
                  </span>
                </div>
              </div>

              <div className="space-y-2 text-slate-300">
                <div className="flex justify-between text-[11px] bg-slate-950 p-2 rounded">
                  <span className="text-slate-500">触发警报模型:</span>
                  <span className="font-bold text-amber-400">{lang === 'en' ? c.triggerTypeEn : c.triggerTypeZh}</span>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 text-xs">
                  <div className="text-slate-500 text-[10px] uppercase mb-1">调查专员初审事实记录:</div>
                  <p className="text-slate-300 leading-relaxed">
                    {lang === 'en' ? c.findingsEn : c.findingsZh}
                  </p>
                </div>

                <div className="flex justify-between items-center text-[11px] pt-1 text-slate-500">
                  <span>主办调查员: {c.investigator} • 立案时间: {c.openedAt}</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleUpdateCase(c.caseId, 'CLOSED_FALSE_POSITIVE')}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
                    >
                      排查结案 (误报)
                    </button>
                    <button
                      onClick={() => handleUpdateCase(c.caseId, 'SAR_SUBMITTED')}
                      className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center gap-1"
                    >
                      <Send className="w-3 h-3" />
                      报送人行反洗钱监测中心 (Submit SAR)
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
