/**
 * Fukuyama Specie Bank (FSB-Core)
 * Digital RMB (e-CNY / 数字人民币) Interoperability Gateway
 * (Prompt #7, #46)
 */

import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  ArrowLeftRight, 
  Cpu, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Wallet, 
  RefreshCw,
  Layers,
  ArrowRight
} from 'lucide-react';
import { Language, ECNYWallet } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface ECNYGatewayViewProps {
  system: BankingSystem;
  lang: Language;
  onRefresh: () => void;
}

export const ECNYGatewayView: React.FC<ECNYGatewayViewProps> = ({
  system,
  lang,
  onRefresh
}) => {
  const [conversionDirection, setConversionDirection] = useState<'FSB_TO_ECNY' | 'ECNY_TO_FSB'>('FSB_TO_ECNY');
  const [selectedWalletId, setSelectedWalletId] = useState('ECNY-8820-0019-3381');
  const [selectedAccountId, setSelectedAccountId] = useState('ACC-6222-001');
  const [amountInput, setAmountInput] = useState('10000.00'); // ¥10,000.00
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [adapterStatus, setAdapterStatus] = useState<any>(null);

  const wallets = system.ecnyProvider.getAllWallets();
  const accounts = system.getAccounts();
  const conversions = system.ecnyProvider.getConversions();
  const ecnyClearingBalance = system.ledger.getAccount('1003').balanceCents;

  useEffect(() => {
    system.ecnyProvider.connect().then(st => setAdapterStatus(st));
  }, [system]);

  const handleExecuteConversion = async () => {
    setIsProcessing(true);
    setStatusMessage(null);
    try {
      const amountCents = Money.parse(amountInput);
      if (amountCents <= 0n) throw new Error('Enter a valid amount');

      const conv = await system.convertWithECNY(
        conversionDirection,
        selectedAccountId,
        selectedWalletId,
        amountCents
      );

      setStatusMessage(
        lang === 'en'
          ? `Conversion Successful! PBOC Settlement Ref: ${conv.pbocSettlementRef}`
          : `兑换成功！中国人民银行数币清算流水编号: ${conv.pbocSettlementRef}`
      );
      onRefresh();
    } catch (err: any) {
      alert(`Conversion error: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* View Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Coins className="w-5 h-5 text-cyan-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'e-CNY INTEROPERABILITY GATEWAY' : '数字人民币 (e-CNY) 互操作网关与适配器'}
              </h2>
              <span className="text-xs bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800">
                ECNY &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'Standardized PBOC DC/EP Interoperability Adapter • Bi-directional M0/M1 conversion bridge'
                : '人民银行法定数字货币 (DC/EP) 标准化互操作适配层 • 双向 M0 (法币) 与商业银行存款互通'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-500 text-[11px]">FSB e-CNY CLEARING POOL</span>
            <div className="text-sm font-bold text-cyan-400">
              {Money.formatInstitutional(ecnyClearingBalance, lang)}
            </div>
          </div>
        </div>

        {/* Adapter Status Ribbon */}
        <div className="mt-3 p-2.5 bg-slate-950 rounded border border-slate-800 flex flex-wrap items-center justify-between text-[11px] gap-2">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-cyan-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
              {adapterStatus?.gatewayNode || 'PBOC-DCEP-EDGE-SH02 (Shanghai Node)'}
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">STATUS: CONNECTED & AUTHENTICATED</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">LATENCY: {adapterStatus?.latencyMs || 38}ms</span>
          </div>
          <span className="text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/80">
            MOCK PROVIDER ADAPTER (SAFE ARCHITECTURE)
          </span>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3 bg-cyan-950/80 border border-cyan-800 text-cyan-200 rounded flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-cyan-400" />
            {statusMessage}
          </span>
          <button onClick={() => setStatusMessage(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Grid: Bi-directional Conversion Terminal & Live Wallets */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left (6 Cols): Conversion Execution Terminal */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm flex items-center gap-2">
                <ArrowLeftRight className="w-4 h-4 text-cyan-400" />
                {lang === 'en' ? 'BI-DIRECTIONAL CONVERSION' : '双向头寸转换终端 (FSB存款 ⇄ e-CNY)'}
              </span>
              <span className="text-[10px] text-slate-500">REALTIME SETTLEMENT</span>
            </div>

            {/* Direction Selector Switch */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              <button
                type="button"
                onClick={() => setConversionDirection('FSB_TO_ECNY')}
                className={`p-2.5 rounded border text-left transition-colors ${
                  conversionDirection === 'FSB_TO_ECNY'
                    ? 'bg-cyan-950 border-cyan-500 text-cyan-200 font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-[10px] text-slate-500 uppercase">DIRECTION 1</div>
                <div className="text-xs mt-0.5">福山存款 ➔ 数字人民币</div>
                <div className="text-[10px] text-slate-400 font-normal mt-1">FSB Deposit into e-CNY M0</div>
              </button>

              <button
                type="button"
                onClick={() => setConversionDirection('ECNY_TO_FSB')}
                className={`p-2.5 rounded border text-left transition-colors ${
                  conversionDirection === 'ECNY_TO_FSB'
                    ? 'bg-amber-950 border-amber-500 text-amber-200 font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-[10px] text-slate-500 uppercase">DIRECTION 2</div>
                <div className="text-xs mt-0.5">数字人民币 ➔ 福山存款</div>
                <div className="text-[10px] text-slate-400 font-normal mt-1">e-CNY into FSB Deposit Claim</div>
              </button>
            </div>

            {/* Account & Wallet Pair */}
            <div className="space-y-3">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  {lang === 'en' ? 'FSB Commercial Bank Account:' : '福山商业银行活期存款账户 (商业银行货币):'}
                </label>
                <select
                  value={selectedAccountId}
                  onChange={e => setSelectedAccountId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                >
                  {accounts.map(a => {
                    const c = system.getCustomer(a.customerId);
                    return (
                      <option key={a.accountId} value={a.accountId}>
                        {c?.nameZh} [{a.accountNumber}] - 可用: {Money.format(a.availableBalanceCents)}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  {lang === 'en' ? 'Target e-CNY Hardware/Software Wallet:' : '数字人民币母/子钱包 (央行主权货币):'}
                </label>
                <select
                  value={selectedWalletId}
                  onChange={e => setSelectedWalletId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                >
                  {wallets.map(w => (
                    <option key={w.walletId} value={w.walletId}>
                      {w.holderName} [{w.walletId}] ({w.tier}) - 余额: {Money.format(w.balanceCents)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  {lang === 'en' ? 'Conversion Amount (RMB ¥):' : '互换清算金额 (人民币元):'}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={amountInput}
                    onChange={e => setAmountInput(e.target.value)}
                    className="flex-1 bg-black border border-slate-700 rounded px-2.5 py-1.5 text-xs text-cyan-300 focus:outline-none font-mono font-bold"
                  />
                  <div className="flex gap-1">
                    {['1000', '10000', '50000', '200000'].map(v => (
                      <button
                        key={v}
                        onClick={() => setAmountInput(v)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px]"
                      >
                        ¥{Number(v).toLocaleString()}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Accounting Flow Explanation */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="text-amber-400 font-bold">
                  {conversionDirection === 'FSB_TO_ECNY' ? '清算会计分录路径:' : '回存会计分录路径:'}
                </div>
                {conversionDirection === 'FSB_TO_ECNY' ? (
                  <div>
                    借 (Dr): 2001 客户私人人民币存款负债减少 | 贷 (Cr): 1003 福山在央行数币清算头寸划出给客户
                  </div>
                ) : (
                  <div>
                    借 (Dr): 1003 福山央行数币清算头寸增加 | 贷 (Cr): 2001 新增福山人民币存款负债记入客户
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800">
            <button
              onClick={handleExecuteConversion}
              disabled={isProcessing}
              className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>COMMUNICATING WITH PBOC DCEP...</span>
                </>
              ) : (
                <>
                  <Coins className="w-4 h-4" />
                  <span>
                    {conversionDirection === 'FSB_TO_ECNY'
                      ? 'EXECUTE: CONVERT FSB-CNY TO e-CNY'
                      : 'EXECUTE: DEPOSIT e-CNY INTO FSB-CNY'}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right (6 Cols): e-CNY Wallets Inspector & Conversion Ledger */}
        <div className="lg:col-span-6 space-y-4">
          {/* Wallets list */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm flex items-center gap-2">
                <Wallet className="w-4 h-4 text-cyan-400" />
                {lang === 'en' ? 'CONNECTED e-CNY WALLETS' : '绑定的数字人民币官方钱包档案'}
              </span>
              <span className="text-[10px] text-slate-500">M0 SOVEREIGN BALANCES</span>
            </div>

            <div className="space-y-2">
              {wallets.map(w => (
                <div
                  key={w.walletId}
                  className="p-2.5 bg-slate-950 border border-slate-800 rounded flex justify-between items-center hover:border-cyan-800/80 transition-colors"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-1.5 py-0.2 bg-cyan-950 text-cyan-400 rounded text-[10px] font-bold">
                        {w.tier}
                      </span>
                      <span className="font-bold text-slate-200">{w.holderName}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-1 font-mono">
                      {w.walletId} • Bound Bank: {w.boundBankId}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-cyan-300 font-bold text-xs">
                      {Money.format(w.balanceCents)}
                    </div>
                    <div className="text-[10px] text-emerald-400">ACTIVE 在线</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Conversions Stream */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
              <span className="font-bold text-slate-200">
                {lang === 'en' ? 'RECENT CONVERSION AUDIT TRAIL' : '最近数币跨层兑换清算指令'}
              </span>
              <span className="text-[10px] text-slate-500">PBOC SETTLEMENT STREAM</span>
            </div>

            <div className="space-y-1.5">
              {conversions.length === 0 ? (
                <div className="text-slate-500 text-center py-3">
                  暂无兑换记录。请使用左侧面板执行头寸划转。
                </div>
              ) : (
                conversions.slice(0, 4).map(c => (
                  <div key={c.conversionId} className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between items-center text-[11px]">
                    <div>
                      <div className="flex items-center gap-2 font-bold text-slate-300">
                        <span className={c.direction === 'FSB_TO_ECNY' ? 'text-cyan-400' : 'text-amber-400'}>
                          {c.direction === 'FSB_TO_ECNY' ? 'FSB ➔ e-CNY' : 'e-CNY ➔ FSB'}
                        </span>
                        <span className="text-slate-500">|</span>
                        <span className="text-slate-400">{c.pbocSettlementRef}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {new Date(c.timestamp).toLocaleTimeString()} • SETTLED AT PBOC EDGE
                      </div>
                    </div>
                    <div className="font-bold text-slate-100">
                      {Money.format(c.amountCents)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
