/**
 * Fukuyama Specie Bank (FSB-Core)
 * Retail Mobile Customer Banking Experience (MOBILE <GO> / 个人手机银行)
 * (Prompt #33)
 */

import React, { useState } from 'react';
import { 
  Smartphone, 
  Send, 
  QrCode, 
  Coins, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  CreditCard,
  ShieldCheck,
  RefreshCw,
  Wallet,
  Eye,
  EyeOff
} from 'lucide-react';
import { Language } from '../types/banking';
import { BankingSystem } from '../core/bankingSystem';
import { Money } from '../core/math';

interface RetailMobileViewProps {
  system: BankingSystem;
  lang: Language;
  onRefresh: () => void;
}

export const RetailMobileView: React.FC<RetailMobileViewProps> = ({
  system,
  lang,
  onRefresh
}) => {
  const [showBalance, setShowBalance] = useState(true);
  const [targetAccountInput, setTargetAccountInput] = useState('6222 0888 3312 9980'); // Wang Xiaoyan
  const [transferAmountInput, setTransferAmountInput] = useState('500.00');
  const [transferSuccess, setTransferSuccess] = useState<string | null>(null);

  const customer = system.getCustomer('CUST-RETAIL-001'); // Chen Liqun
  const account = system.getAccount('ACC-6222-001');
  const boundWallet = system.ecnyProvider.getAllWallets().find(w => w.walletId === customer?.ecnyWalletBinding);

  const handleQuickTransfer = () => {
    try {
      const amountCents = Money.parse(transferAmountInput);
      if (amountCents <= 0n) throw new Error('Enter valid amount');

      const targetAcc = system.getAccounts().find(
        a => a.accountNumber.replace(/\s+/g, '') === targetAccountInput.replace(/\s+/g, '')
      );
      if (!targetAcc) throw new Error('Target account not found');

      system.executeTransfer(
        account!.accountId,
        targetAcc.accountId,
        amountCents,
        '手机银行实时汇款',
        'Mobile Retail Transfer'
      );

      setTransferSuccess(
        lang === 'en'
          ? `Transferred ${Money.format(amountCents)} to ${targetAccountInput}`
          : `转账成功！已实时汇出 ${Money.format(amountCents)} 至对方账户 ${targetAccountInput}，核心总账已即时借贷平账。`
      );
      onRefresh();
    } catch (err: any) {
      alert(`Transfer failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 border-b border-slate-800 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-slate-100">
                {lang === 'en' ? 'FSB RETAIL MOBILE BANKING APP' : '福山金银银行个人移动金融终端 (手机银行)'}
              </h2>
              <span className="text-xs bg-slate-800 text-amber-300 px-2 py-0.5 rounded border border-slate-700">
                MOBILE &lt;GO&gt;
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1">
              {lang === 'en'
                ? 'End-user client portal unified directly onto the institutional core ledger'
                : '零售前端客户端与核心总账完全同频同构 • 实时反映私人存款负债与数币双向互联'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-slate-500 text-[11px]">AUTHENTICATED CLIENT</span>
            <div className="text-sm font-bold text-slate-200">
              {customer?.nameZh} ({customer?.riskRating} RISK)
            </div>
          </div>
        </div>
      </div>

      {transferSuccess && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            {transferSuccess}
          </span>
          <button onClick={() => setTransferSuccess(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Grid: Phone Simulation Viewport (Left) vs Real-Time Core Ledger Linkage (Right) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Mobile Device Frame (5 Cols) */}
        <div className="md:col-span-5 max-w-sm mx-auto w-full bg-slate-950 border-4 border-slate-800 rounded-3xl p-4 shadow-2xl flex flex-col justify-between">
          <div className="space-y-3">
            {/* Phone Top Notch & Brand */}
            <div className="flex justify-between items-center text-[10px] text-slate-500 pb-2 border-b border-slate-900">
              <span className="font-bold text-amber-400">FSB MOBILE 5G</span>
              <span>17:48</span>
              <span>100% 🔋</span>
            </div>

            {/* Mobile Header Card */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-4 relative overflow-hidden shadow-md">
              <div className="flex justify-between items-center text-slate-400 text-xs mb-1">
                <span>福山个人活期储蓄 (FSB-CNY)</span>
                <button onClick={() => setShowBalance(!showBalance)} className="text-slate-400 hover:text-white">
                  {showBalance ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="text-2xl font-bold font-mono text-amber-300 my-1">
                {showBalance ? Money.format(account?.balanceCents || 0n) : '••••••••'}
              </div>

              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-2 pt-2 border-t border-slate-800/80">
                <span>卡号: {account?.accountNumber}</span>
                <span className="text-emerald-400 font-bold">NORMAL 正常</span>
              </div>
            </div>

            {/* Fast Retail Functions Grid (Prompt #33) */}
            <div className="grid grid-cols-4 gap-2 text-center text-[10px] py-1">
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-xl hover:border-slate-700 cursor-pointer">
                <Send className="w-4 h-4 mx-auto text-amber-400 mb-1" />
                <span className="text-slate-300">转账</span>
              </div>
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-xl hover:border-slate-700 cursor-pointer">
                <QrCode className="w-4 h-4 mx-auto text-cyan-400 mb-1" />
                <span className="text-slate-300">扫码付</span>
              </div>
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-xl hover:border-slate-700 cursor-pointer">
                <Coins className="w-4 h-4 mx-auto text-emerald-400 mb-1" />
                <span className="text-slate-300">数字人民币</span>
              </div>
              <div className="p-2 bg-slate-900 border border-slate-800 rounded-xl hover:border-slate-700 cursor-pointer">
                <CreditCard className="w-4 h-4 mx-auto text-slate-400 mb-1" />
                <span className="text-slate-300">银行卡</span>
              </div>
            </div>

            {/* Bound e-CNY Pocket Card */}
            {boundWallet && (
              <div className="bg-cyan-950/40 border border-cyan-800/60 rounded-xl p-3 flex justify-between items-center">
                <div>
                  <div className="flex items-center gap-1.5 text-cyan-300 font-bold text-xs">
                    <Coins className="w-3.5 h-3.5 text-cyan-400" />
                    <span>绑定的数字人民币钱包</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {boundWallet.walletId}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-cyan-300 font-bold text-xs">
                    {Money.format(boundWallet.balanceCents)}
                  </div>
                  <div className="text-[10px] text-slate-500">M0 法币</div>
                </div>
              </div>
            )}

            {/* In-app Quick Transfer Simulator */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-2">
              <div className="text-[11px] font-bold text-slate-200">行内快速汇款:</div>
              <div>
                <label className="text-[10px] text-slate-500 block">对方银行账号:</label>
                <input
                  type="text"
                  value={targetAccountInput}
                  onChange={e => setTargetAccountInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 block">转账金额 (元):</label>
                <input
                  type="text"
                  value={transferAmountInput}
                  onChange={e => setTransferAmountInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-amber-300 font-mono font-bold"
                />
              </div>
              <button
                onClick={handleQuickTransfer}
                className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs mt-1 transition-colors"
              >
                立即确认转账 / Transfer Now
              </button>
            </div>
          </div>
        </div>

        {/* Right: Architectural Explanation (7 Cols) */}
        <div className="md:col-span-7 bg-slate-900 border border-slate-800 rounded p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <span className="font-bold text-slate-200 text-sm flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                {lang === 'en' ? 'SINGLE LEDGER AXIOM' : '统一核心总账单一真相原则'}
              </span>
              <span className="text-[10px] text-slate-500">REALTIME SYNC</span>
            </div>

            <div className="space-y-3 text-slate-300">
              <p className="text-xs leading-relaxed text-slate-400">
                {lang === 'en'
                  ? 'Fukuyama Specie Bank does not operate separate or delayed databases for consumer mobile clients. Customer balances seen on the phone directly represent the exact commercial liability in account 2001 (Retail Demand Deposits) inside the double-entry general ledger.'
                  : '福山金银银行绝不设立任何脱离总账的离线微服务影子账户。客户在手机银行界面查阅的每一分钱，均直接对应核心总账科目 2001 (福山个人储蓄存款) 中的微观借贷总额。'}
              </p>

              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="text-xs font-bold text-amber-300">
                  {lang === 'en' ? 'Underlying Banking Claim Identity:' : '存款法定权利属性标识:'}
                </div>
                <div className="space-y-1 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-500">法定发行主体 (Issuer):</span>
                    <span className="text-slate-200">福山金银银行 (Fukuyama Specie Bank)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">经济属性 (Nature):</span>
                    <span className="text-amber-400 font-bold">以人民币计价的商业银行私人存款负债 (FSB-CNY)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">增信储备 (Backing):</span>
                    <span className="text-emerald-400">100% 央行准备金及国债高流动资产增信</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">清算接口 (Settlement):</span>
                    <span className="text-cyan-300">支持双向原子化兑换至央行数字人民币 (e-CNY) 钱包</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-2 border-t border-slate-800 text-[10px] text-slate-500">
            Audit standard: End-to-end SM2 PKI signature on all transfer payloads.
          </div>
        </div>
      </div>
    </div>
  );
};
