/**
 * Fukuyama Specie Bank / 福山金银银行 (FSB-Core)
 * Production Banking Architecture Type Definitions
 * 
 * Strict separation between:
 * - Sovereign RMB (CNY legal tender, PBOC settlement, e-CNY)
 * - Commercial Bank Money (FSB-CNY deposit liabilities)
 * - Payment Representations (Tokens, POS Authorisations, Settlement Instructions)
 */

// Language setting
export type Language = 'zh' | 'en' | 'bilingual';

// --- THREE-LAYER MONEY MODEL ---

export type MonetaryLayer = 'LAYER_A_SOVEREIGN' | 'LAYER_B_COMMERCIAL' | 'LAYER_C_PAYMENT_REP';

export interface MonetaryLayerInfo {
  layer: MonetaryLayer;
  code: string;
  nameZh: string;
  nameEn: string;
  descriptionZh: string;
  descriptionEn: string;
  legalIssuer: string;
  economicIssuer: string;
  isLegalTender: boolean;
}

// Layer A: Sovereign Money (央行货币)
export type SovereignMoneyType = 
  | 'RMB_CASH'               // 人民币现金 (Paper/Coin)
  | 'ECNY'                   // 数字人民币 (e-CNY, PBOC M0 equivalent)
  | 'PBOC_SETTLEMENT_BALANCE'; // 中央银行结算资金 (Reserve balance at PBOC)

// Layer B: Commercial Bank Money (商业银行货币 / 私人银行负债)
export type CommercialMoneyType =
  | 'FSB_DEMAND_DEPOSIT'     // 福山活期存款 (FSB-CNY)
  | 'FSB_CORPORATE_DEPOSIT'  // 企业存款
  | 'FSB_MERCHANT_BALANCE'   // 商户余额
  | 'FSB_INSTITUTIONAL'      // 机构余额
  | 'INTERBANK_PLACEMENT';   // 同业拆借余额

// Layer C: Payment Representation (支付媒介与凭证)
export type PaymentRepresentationType =
  | 'POS_TOKEN'              // POS支付凭证
  | 'AUTH_HOLD'              // 支付授权冻结
  | 'MERCHANT_SETTLEMENT'    // 商户结算指令
  | 'DYNAMIC_QR'             // 动态二维码
  | 'NFC_PAYMENT_TOKEN'      // NFC支付令牌
  | 'API_INSTRUCTION';       // API支付报文

// --- DOUBLE-ENTRY ACCOUNTING & CHART OF ACCOUNTS ---

export type AccountCategory = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

export interface LedgerAccount {
  code: string;               // e.g. 1001 (Cash), 1002 (PBOC Reserve), 2001 (Customer Deposits)
  nameZh: string;
  nameEn: string;
  category: AccountCategory;
  currency: 'CNY';
  layer: MonetaryLayer;
  balanceCents: bigint;       // Exact balance in RMB cents (¥1.00 = 100 cents)
  isEncumbered?: boolean;     // Whether asset is pledged/encumbered
  hqlTier?: 'LEVEL_1' | 'LEVEL_2A' | 'LEVEL_2B' | 'NONE'; // High Quality Liquid Asset tier
}

export interface JournalLine {
  accountCode: string;
  accountNameZh: string;
  accountNameEn: string;
  debitCents: bigint;
  creditCents: bigint;
  memoZh: string;
  memoEn: string;
}

export interface JournalEntry {
  entryId: string;
  timestamp: string;
  transactionRef: string;
  sourceModule: 'ISSUANCE' | 'POS' | 'ECNY_CONVERSION' | 'SETTLEMENT' | 'TREASURY' | 'PAYROLL' | 'STRESS';
  lines: JournalLine[];
  totalDebitCents: bigint;
  totalCreditCents: bigint;
  isBalanced: boolean;
  operator: string;
}

// --- PRIVATE RMB CLAIM (FSB-CNY) ---

export type ClaimStatus = 'ACTIVE' | 'RESERVED' | 'SETTLED' | 'REDEEMED' | 'FROZEN' | 'EXPIRED';

export interface RMBClaim {
  claimId: string;
  issuer: 'Fukuyama Specie Bank' | '福山金银银行';
  economicNatureZh: '以人民币计价的私人银行负债';
  economicNatureEn: 'Private bank liability denominated in RMB (FSB-CNY)';
  holderId: string;
  holderNameZh: string;
  holderNameEn: string;
  amountCents: bigint;
  currency: 'CNY';
  claimType: 'DEPOSIT_LIABILITY' | 'SETTLEMENT_PAYABLE' | 'COLLATERAL_PLEDGE';
  settlementLayer: 'FSB_CORE_LEDGER';
  reserveReferenceId: string;
  status: ClaimStatus;
  createdAt: string;
  redeemedAt?: string;
}

// --- CUSTOMER & ACCOUNTS ---

export type CustomerType = 'RETAIL' | 'CORPORATE' | 'MERCHANT' | 'INSTITUTIONAL' | 'INTERBANK';

export interface BankCustomer {
  customerId: string;
  type: CustomerType;
  nameZh: string;
  nameEn: string;
  idNumber: string;          // 统一社会信用代码 or 居民身份证
  kycStatus: 'VERIFIED' | 'PENDING' | 'RE_REVIEW';
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  primaryAccountId: string;
  associatedAccounts: string[];
  ecnyWalletBinding?: string; // Bound e-CNY hardware/software wallet ID
}

export interface CustomerAccount {
  accountId: string;
  customerId: string;
  accountNumber: string;      // 16-19 digit standard Chinese bank account number
  accountTypeZh: string;
  accountTypeEn: string;
  balanceCents: bigint;
  availableBalanceCents: bigint;
  holdBalanceCents: bigint;   // Pre-authorised/reserved funds
  currency: 'CNY';
  dailyLimitCents: bigint;
  status: 'ACTIVE' | 'FROZEN' | 'RESTRICTED';
  openedAt: string;
}

// --- POS VALIDATOR & PAYMENT INSTRUCTIONS ---

export type PaymentMethod = 'FSB_ACCOUNT' | 'ECNY' | 'BANK_CARD' | 'QR_CODE' | 'NFC' | 'API';

export type PaymentValidationStepKey = 
  | 'AUTH_SIGNATURE'
  | 'VERIFY_MERCHANT'
  | 'VERIFY_CURRENCY'
  | 'VERIFY_ACCOUNT'
  | 'VERIFY_BALANCE'
  | 'CHECK_LIMITS'
  | 'FRAUD_RISK_CHECK'
  | 'IDEMPOTENCY_CHECK'
  | 'RESERVE_FUNDS'
  | 'AUTHORISE_TX'
  | 'EXECUTE_SETTLEMENT'
  | 'AUDIT_RECONCILE';

export interface ValidationStepResult {
  step: PaymentValidationStepKey;
  labelZh: string;
  labelEn: string;
  passed: boolean;
  timestamp: string;
  detailZh: string;
  detailEn: string;
}

export type PaymentStatus = 'AUTHORISED' | 'DECLINED' | 'PENDING' | 'REVERSED' | 'SETTLED';

export interface PaymentInstruction {
  instructionId: string;
  traceNumber: string;
  payerAccountId: string;
  payerNameZh: string;
  payerNameEn: string;
  payeeMerchantId: string;
  payeeMerchantNameZh: string;
  payeeMerchantNameEn: string;
  terminalId: string;
  amountCents: bigint;
  currency: 'CNY';
  instrument: PaymentMethod;
  settlementRoute: 'FSB_INTERNAL' | 'ECNY_GATEWAY' | 'CNAPS_COMMERCIAL_RAIL';
  timestamp: string;
  status: PaymentStatus;
  authCode?: string;
  riskScore: number;          // 0-100 (high = risky)
  validationSteps: ValidationStepResult[];
  feeCents: bigint;
  merchantNetCents: bigint;
}

// --- MERCHANT & ACQUIRING ---

export interface MerchantTerminal {
  terminalId: string;
  merchantId: string;
  model: string;
  status: 'ONLINE' | 'OFFLINE' | 'SUSPENDED';
  location: string;
  lastPing: string;
}

export interface MerchantProfile {
  merchantId: string;
  businessNameZh: string;
  businessNameEn: string;
  registrationNumber: string; // 营业执照注册号
  mccCode: string;            // Merchant Category Code (e.g. 5411 Grocery)
  settlementAccountId: string;
  riskClassification: 'GRADE_A' | 'GRADE_B' | 'GRADE_C';
  settlementCycle: 'REALTIME' | 'INTRADAY' | 'T_PLUS_0' | 'T_PLUS_1';
  dailyVolumeLimitCents: bigint;
  todayVolumeCents: bigint;
  pendingSettlementCents: bigint;
  settledTodayCents: bigint;
  feeRateBps: number;         // Basis points (e.g. 38 bps = 0.38%)
  terminals: MerchantTerminal[];
}

// --- DIGITAL RMB (e-CNY) INTEROPERABILITY ---

export interface ECNYWallet {
  walletId: string;
  tier: 'TIER_1' | 'TIER_2' | 'TIER_3' | 'TIER_4'; // e-CNY KYC tiers
  holderName: string;
  balanceCents: bigint;
  status: 'ACTIVE' | 'FROZEN';
  boundBankId: string;        // Fukuyama Specie Bank identifier
}

export interface ECNYConversionRequest {
  conversionId: string;
  direction: 'FSB_TO_ECNY' | 'ECNY_TO_FSB';
  amountCents: bigint;
  fsbAccountId: string;
  ecnyWalletId: string;
  status: 'PENDING' | 'SETTLING' | 'COMPLETED' | 'FAILED';
  pbocSettlementRef: string;
  timestamp: string;
}

// --- TREASURY & MONETARY RESERVES ---

export interface ReserveAsset {
  assetId: string;
  nameZh: string;
  nameEn: string;
  type: 'RMB_CASH' | 'PBOC_DEPOSIT' | 'CGB_TREASURY_BOND' | 'POLICY_BANK_BOND' | 'INTERBANK_DEPOSIT';
  faceValueCents: bigint;
  marketValueCents: bigint;
  encumberedCents: bigint;
  unencumberedCents: bigint;
  hqlTier: 'LEVEL_1' | 'LEVEL_2A' | 'LEVEL_2B';
  yieldBps: number;
  maturityDate: string;
}

export interface MonetaryPosition {
  totalCustomerDepositsCents: bigint;   // FSB-CNY liabilities
  totalReserveAssetsCents: bigint;       // PBOC reserves + bonds + cash
  liquidAssetsCents: bigint;             // Level 1 HQLA
  reserveCoverageRatio: number;          // Reserves / Deposits (%)
  liquidityCoverageRatio: number;        // LCR (%)
  availableLiquidityCents: bigint;
  encumberedLiquidityCents: bigint;
  intradaySettlementCapacityCents: bigint;
  ecnyConversionCapacityCents: bigint;
  netRMBPositionCents: bigint;
}

// --- PROGRAMMABLE PAYMENTS ---

export interface ProgrammablePaymentRule {
  ruleId: string;
  corporateCustomerId: string;
  titleZh: string;
  titleEn: string;
  supplierAccountId: string;
  amountCents: bigint;
  conditions: {
    deliveryConfirmed: boolean;
    invoiceValidated: boolean;
    cfoApproved: boolean;
  };
  triggerType: 'AUTOMATED_WEBHOOK' | 'MULTI_SIG_GATE';
  status: 'PENDING_CONDITIONS' | 'CONDITIONS_MET' | 'EXECUTED' | 'CANCELLED';
  approvalChain: {
    role: 'EMPLOYEE' | 'MANAGER' | 'TREASURER' | 'CFO';
    approved: boolean;
    approvedAt?: string;
    approvedBy?: string;
  }[];
  createdAt: string;
  executedAt?: string;
}

// --- FRAUD & COMPLIANCE ---

export interface FraudAlert {
  alertId: string;
  transactionRef: string;
  merchantNameZh: string;
  amountCents: bigint;
  riskScore: number;
  decision: 'APPROVE' | 'REVIEW' | 'BLOCK';
  reasonCodesZh: string[];
  reasonCodesEn: string[];
  timestamp: string;
  status: 'OPEN' | 'CLEARED' | 'SAR_FILED';
}

export interface ReconciliationDiscrepancy {
  discrepancyId: string;
  transactionRef: string;
  ledgerAmountCents: bigint;
  externalRailAmountCents: bigint;
  systemRail: 'POS' | 'ECNY' | 'CNAPS' | 'TREASURY';
  type: 'AMOUNT_MISMATCH' | 'MISSING_IN_LEDGER' | 'MISSING_IN_RAIL' | 'TIMING_LAG';
  status: 'UNRESOLVED' | 'RESOLVED_ADJUSTED' | 'INVESTIGATING';
  flaggedAt: string;
}

// --- TERMINAL COMMANDS ---

export interface TerminalCommandDef {
  command: string;
  chineseAlias: string;
  descriptionZh: string;
  descriptionEn: string;
  targetView: string;
}
