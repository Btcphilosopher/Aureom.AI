/**
 * Fukuyama Specie Bank (FSB-Core)
 * Central Banking System Orchestrator
 * 
 * Unifies:
 * - General Ledger (Double-Entry Core)
 * - Private RMB Issuance Engine (FSB-CNY)
 * - e-CNY Interoperability Gateway
 * - 12-Step POS Validator
 * - Multi-Rail Payment Router
 * - Merchant Acquiring & Settlement Engine
 * - Corporate Programmable Payments
 * - Liquidity & Stress Engine
 * - Fraud, AML & Compliance
 * - Reconciliation Engine
 */

import { 
  BankCustomer, 
  CustomerAccount, 
  MerchantProfile, 
  RMBClaim,
  MonetaryPosition,
  TerminalCommandDef
} from '../types/banking';
import { Money } from './math';
import { GeneralLedger } from './ledger';
import { MockECNYProvider } from './ecnyAdapter';
import { POSValidator } from './posValidator';
import { PaymentRouter } from './paymentRouter';
import { IssuanceEngine } from './issuanceEngine';
import { StressEngine } from './stressEngine';
import { ProgrammablePaymentEngine } from './programmablePayments';
import { ReconciliationEngine } from './reconciliation';
import { ComplianceEngine } from './compliance';

export class BankingSystem {
  public ledger: GeneralLedger;
  public ecnyProvider: MockECNYProvider;
  public posValidator: POSValidator;
  public paymentRouter: PaymentRouter;
  public issuanceEngine: IssuanceEngine;
  public stressEngine: StressEngine;
  public progEngine: ProgrammablePaymentEngine;
  public reconEngine: ReconciliationEngine;
  public complianceEngine: ComplianceEngine;

  private customers: Map<string, BankCustomer> = new Map();
  private accounts: Map<string, CustomerAccount> = new Map();
  private merchants: Map<string, MerchantProfile> = new Map();
  private rmbClaims: RMBClaim[] = [];

  // Intraday telemetry simulation counters
  public dailyTransactionsCount = 28_419_302;
  public dailyTransactionsVolumeCents = 91_240_000_000_00n; // ¥91.24bn
  public avgLatencyMs = 182;
  public successRatePercent = 99.97;

  constructor() {
    this.ledger = new GeneralLedger();
    this.ecnyProvider = new MockECNYProvider();
    this.posValidator = new POSValidator(this.ledger);
    this.paymentRouter = new PaymentRouter();
    this.issuanceEngine = new IssuanceEngine(this.ledger);
    this.stressEngine = new StressEngine();
    this.progEngine = new ProgrammablePaymentEngine(this.ledger);
    this.reconEngine = new ReconciliationEngine(this.ledger);
    this.complianceEngine = new ComplianceEngine();

    this.seedCustomersAndAccounts();
    this.seedMerchants();
    this.seedClaims();
  }

  private seedCustomersAndAccounts(): void {
    const defaultCustomers: { customer: BankCustomer; account: CustomerAccount }[] = [
      {
        customer: {
          customerId: 'CUST-RETAIL-001',
          type: 'RETAIL',
          nameZh: '陈立群',
          nameEn: 'Chen Liqun',
          idNumber: '310104198809224192',
          kycStatus: 'VERIFIED',
          riskRating: 'LOW',
          primaryAccountId: 'ACC-6222-001',
          associatedAccounts: ['ACC-6222-001'],
          ecnyWalletBinding: 'ECNY-8820-0019-3381'
        },
        account: {
          accountId: 'ACC-6222-001',
          customerId: 'CUST-RETAIL-001',
          accountNumber: '6222 0888 1029 4401',
          accountTypeZh: '福山个人综合活期储蓄 (FSB-CNY)',
          accountTypeEn: 'FSB Retail Demand Savings (FSB-CNY)',
          balanceCents: 520_000_00n, // ¥520,000.00
          availableBalanceCents: 520_000_00n,
          holdBalanceCents: 0n,
          currency: 'CNY',
          dailyLimitCents: 500_000_00n,
          status: 'ACTIVE',
          openedAt: '2023-03-15'
        }
      },
      {
        customer: {
          customerId: 'CUST-RETAIL-002',
          type: 'RETAIL',
          nameZh: '王晓燕',
          nameEn: 'Wang Xiaoyan',
          idNumber: '110108199205123048',
          kycStatus: 'VERIFIED',
          riskRating: 'LOW',
          primaryAccountId: 'ACC-6222-002',
          associatedAccounts: ['ACC-6222-002']
        },
        account: {
          accountId: 'ACC-6222-002',
          customerId: 'CUST-RETAIL-002',
          accountNumber: '6222 0888 3312 9980',
          accountTypeZh: '福山尊享贵宾活期存款 (FSB-CNY)',
          accountTypeEn: 'FSB VIP Demand Savings (FSB-CNY)',
          balanceCents: 85_400_00n, // ¥85,400.00
          availableBalanceCents: 85_400_00n,
          holdBalanceCents: 0n,
          currency: 'CNY',
          dailyLimitCents: 200_000_00n,
          status: 'ACTIVE',
          openedAt: '2024-01-10'
        }
      },
      {
        customer: {
          customerId: 'CUST-CORP-001',
          type: 'CORPORATE',
          nameZh: '东方精密制造有限公司',
          nameEn: 'East Precision Tech Ltd',
          idNumber: '91310000MA1FL8829C',
          kycStatus: 'VERIFIED',
          riskRating: 'LOW',
          primaryAccountId: 'ACC-6222-CORP-01',
          associatedAccounts: ['ACC-6222-CORP-01'],
          ecnyWalletBinding: 'ECNY-7700-5511-9923'
        },
        account: {
          accountId: 'ACC-6222-CORP-01',
          customerId: 'CUST-CORP-001',
          accountNumber: '6222 0999 5501 7788',
          accountTypeZh: '福山企业基本结算账户 (FSB-CNY)',
          accountTypeEn: 'FSB Corporate Primary Settlement (FSB-CNY)',
          balanceCents: 48_500_000_00n, // ¥48,500,000.00
          availableBalanceCents: 48_500_000_00n,
          holdBalanceCents: 0n,
          currency: 'CNY',
          dailyLimitCents: 50_000_000_00n,
          status: 'ACTIVE',
          openedAt: '2022-07-01'
        }
      },
      {
        customer: {
          customerId: 'CUST-CORP-002',
          type: 'MERCHANT',
          nameZh: '福山城市便利连锁零售集团',
          nameEn: 'Fukuyama Convenience Retail Group',
          idNumber: '91310000MA1FR9901X',
          kycStatus: 'VERIFIED',
          riskRating: 'LOW',
          primaryAccountId: 'ACC-6222-MERCH-01',
          associatedAccounts: ['ACC-6222-MERCH-01'],
          ecnyWalletBinding: 'ECNY-9901-4472-1102'
        },
        account: {
          accountId: 'ACC-6222-MERCH-01',
          customerId: 'CUST-CORP-002',
          accountNumber: '6222 0999 2234 8899',
          accountTypeZh: '特约商户专有收单结算账户 (FSB-CNY)',
          accountTypeEn: 'Acquiring Merchant Settlement (FSB-CNY)',
          balanceCents: 12_300_000_00n, // ¥12,300,000.00
          availableBalanceCents: 12_300_000_00n,
          holdBalanceCents: 0n,
          currency: 'CNY',
          dailyLimitCents: 20_000_000_00n,
          status: 'ACTIVE',
          openedAt: '2023-11-20'
        }
      }
    ];

    for (const item of defaultCustomers) {
      this.customers.set(item.customer.customerId, item.customer);
      this.accounts.set(item.account.accountId, item.account);
    }
  }

  private seedMerchants(): void {
    const defaultMerchants: MerchantProfile[] = [
      {
        merchantId: 'MERCH-001',
        businessNameZh: '福山便利店 (静安旗舰店)',
        businessNameEn: 'Fukuyama Convenience (Jingan Flagship)',
        registrationNumber: '91310106MA1789421L',
        mccCode: '5411', // Grocery
        settlementAccountId: 'ACC-6222-MERCH-01',
        riskClassification: 'GRADE_A',
        settlementCycle: 'REALTIME',
        dailyVolumeLimitCents: 1_000_000_00n, // ¥1,000,000
        todayVolumeCents: 148_900_00n,
        pendingSettlementCents: 38_400_00n,
        settledTodayCents: 110_500_00n,
        feeRateBps: 38, // 0.38%
        terminals: [
          {
            terminalId: 'FSB-TERM-0018',
            merchantId: 'MERCH-001',
            model: 'PAX A920 Pro (国密SM2/SM3认证)',
            status: 'ONLINE',
            location: '上海市静安区南京西路1288号1层',
            lastPing: new Date().toISOString()
          },
          {
            terminalId: 'FSB-TERM-0019',
            merchantId: 'MERCH-001',
            model: 'Landi APOS A8 (双离线e-CNY硬件终端)',
            status: 'ONLINE',
            location: '上海市静安区南京西路1288号2层',
            lastPing: new Date().toISOString()
          }
        ]
      },
      {
        merchantId: 'MERCH-002',
        businessNameZh: '东方精密设备直销中心',
        businessNameEn: 'East Precision Direct Outlet',
        registrationNumber: '91310000MA1FL8829C',
        mccCode: '5084', // Machinery
        settlementAccountId: 'ACC-6222-CORP-01',
        riskClassification: 'GRADE_A',
        settlementCycle: 'T_PLUS_0',
        dailyVolumeLimitCents: 10_000_000_00n,
        todayVolumeCents: 1_280_000_00n,
        pendingSettlementCents: 1_280_000_00n,
        settledTodayCents: 0n,
        feeRateBps: 25, // 0.25%
        terminals: [
          {
            terminalId: 'FSB-TERM-CORP-01',
            merchantId: 'MERCH-002',
            model: 'Verifone V400m Enterprise',
            status: 'ONLINE',
            location: '张江高科技园区祖冲之路88号',
            lastPing: new Date().toISOString()
          }
        ]
      },
      {
        merchantId: 'MERCH-003',
        businessNameZh: '福山高新数码体验店',
        businessNameEn: 'Fukuyama High-Tech Store',
        registrationNumber: '91310115MA1909823P',
        mccCode: '5732', // Electronics
        settlementAccountId: 'ACC-6222-MERCH-01',
        riskClassification: 'GRADE_B',
        settlementCycle: 'INTRADAY',
        dailyVolumeLimitCents: 500_000_00n,
        todayVolumeCents: 98_200_00n,
        pendingSettlementCents: 98_200_00n,
        settledTodayCents: 0n,
        feeRateBps: 45, // 0.45%
        terminals: [
          {
            terminalId: 'FSB-TERM-DIGI-01',
            merchantId: 'MERCH-003',
            model: 'Sunmi V2 Pro Smart POS',
            status: 'ONLINE',
            location: '陆家嘴环路1000号恒生大厦',
            lastPing: new Date().toISOString()
          }
        ]
      }
    ];

    for (const m of defaultMerchants) {
      this.merchants.set(m.merchantId, m);
    }
  }

  private seedClaims(): void {
    this.rmbClaims = [
      {
        claimId: 'FSB-CLAIM-2026-0001',
        issuer: 'Fukuyama Specie Bank',
        economicNatureZh: '以人民币计价的私人银行负债',
        economicNatureEn: 'Private bank liability denominated in RMB (FSB-CNY)',
        holderId: 'CUST-RETAIL-001',
        holderNameZh: '陈立群',
        holderNameEn: 'Chen Liqun',
        amountCents: 520_000_00n,
        currency: 'CNY',
        claimType: 'DEPOSIT_LIABILITY',
        settlementLayer: 'FSB_CORE_LEDGER',
        reserveReferenceId: 'RES-PBOC-POOL-01',
        status: 'ACTIVE',
        createdAt: '2023-03-15T10:00:00Z'
      },
      {
        claimId: 'FSB-CLAIM-2026-0002',
        issuer: 'Fukuyama Specie Bank',
        economicNatureZh: '以人民币计价的私人银行负债',
        economicNatureEn: 'Private bank liability denominated in RMB (FSB-CNY)',
        holderId: 'CUST-CORP-001',
        holderNameZh: '东方精密制造有限公司',
        holderNameEn: 'East Precision Tech Ltd',
        amountCents: 48_500_000_00n,
        currency: 'CNY',
        claimType: 'DEPOSIT_LIABILITY',
        settlementLayer: 'FSB_CORE_LEDGER',
        reserveReferenceId: 'RES-PBOC-POOL-01',
        status: 'ACTIVE',
        createdAt: '2022-07-01T09:30:00Z'
      }
    ];
  }

  public getCustomers(): BankCustomer[] {
    return Array.from(this.customers.values());
  }

  public getCustomer(id: string): BankCustomer | undefined {
    return this.customers.get(id);
  }

  public getAccounts(): CustomerAccount[] {
    return Array.from(this.accounts.values());
  }

  public getAccount(id: string): CustomerAccount | undefined {
    return this.accounts.get(id);
  }

  public getMerchants(): MerchantProfile[] {
    return Array.from(this.merchants.values());
  }

  public getMerchant(id: string): MerchantProfile | undefined {
    return this.merchants.get(id);
  }

  public getRMBClaims(): RMBClaim[] {
    return [...this.rmbClaims];
  }

  /**
   * Settle merchant pending batches
   */
  public settleMerchantBatch(merchantId: string, cycle: 'REALTIME' | 'INTRADAY' | 'T_PLUS_0' | 'T_PLUS_1'): {
    settledAmountCents: bigint;
    txRef: string;
  } {
    const merchant = this.merchants.get(merchantId);
    if (!merchant) throw new Error(`Merchant ${merchantId} not found`);

    const settleAmount = merchant.pendingSettlementCents;
    if (settleAmount <= 0n) {
      return { settledAmountCents: 0n, txRef: 'NONE' };
    }

    const txRef = `SETTLE-BATCH-${Date.now()}`;

    // Post double entry:
    // Debit: 2003 Merchant Settlement Payable (Clearing float cleared)
    // Credit: 2002/2001 Merchant's Deposit Account
    this.ledger.postEntry(
      'SETTLEMENT',
      txRef,
      `CLEARING-ENGINE-${cycle}`,
      [
        {
          accountCode: '2003',
          debitCents: settleAmount,
          creditCents: 0n,
          memoZh: `商户收单款清分结算批量冲销 [${cycle}] - ${merchant.businessNameZh}`,
          memoEn: `Merchant acquiring batch settlement [${cycle}] - ${merchant.businessNameEn}`
        },
        {
          accountCode: '2002',
          debitCents: 0n,
          creditCents: settleAmount,
          memoZh: `商户净结算资金划入企业存款结算账户`,
          memoEn: `Net settlement funds credited to corporate merchant account`
        }
      ]
    );

    // Update merchant record
    merchant.settledTodayCents += settleAmount;
    merchant.pendingSettlementCents = 0n;

    // Credit account balance
    const acc = this.accounts.get(merchant.settlementAccountId);
    if (acc) {
      acc.balanceCents += settleAmount;
      acc.availableBalanceCents += settleAmount;
    }

    return { settledAmountCents: settleAmount, txRef };
  }

  /**
   * Inter-account transfer within FSB
   */
  public executeTransfer(
    sourceAccountId: string,
    targetAccountId: string,
    amountCents: bigint,
    memoZh: string,
    memoEn: string
  ): { txRef: string; status: 'SUCCESS' } {
    const src = this.accounts.get(sourceAccountId);
    const tgt = this.accounts.get(targetAccountId);
    if (!src || !tgt) throw new Error('Account not found');
    if (src.availableBalanceCents < amountCents) throw new Error('Insufficient funds');

    src.balanceCents -= amountCents;
    src.availableBalanceCents -= amountCents;
    tgt.balanceCents += amountCents;
    tgt.availableBalanceCents += amountCents;

    const txRef = `TX-INT-${Date.now()}`;
    const srcAccountCode = src.accountTypeZh.includes('企业') ? '2002' : '2001';
    const tgtAccountCode = tgt.accountTypeZh.includes('企业') ? '2002' : '2001';

    this.ledger.postEntry(
      'POS',
      txRef,
      'FSB-ONLINE-BANKING',
      [
        {
          accountCode: srcAccountCode,
          debitCents: amountCents,
          creditCents: 0n,
          memoZh: `行内转账出账 - 对方账户: ${tgt.accountNumber} (${memoZh})`,
          memoEn: `Internal transfer debit - Target: ${tgt.accountNumber} (${memoEn})`
        },
        {
          accountCode: tgtAccountCode,
          debitCents: 0n,
          creditCents: amountCents,
          memoZh: `行内转账入账 - 来源账户: ${src.accountNumber} (${memoZh})`,
          memoEn: `Internal transfer credit - Source: ${src.accountNumber} (${memoEn})`
        }
      ]
    );

    return { txRef, status: 'SUCCESS' };
  }

  /**
   * Bi-directional conversion between FSB-CNY and e-CNY
   */
  public async convertWithECNY(
    direction: 'FSB_TO_ECNY' | 'ECNY_TO_FSB',
    fsbAccountId: string,
    ecnyWalletId: string,
    amountCents: bigint
  ) {
    const fsbAcc = this.accounts.get(fsbAccountId);
    if (!fsbAcc) throw new Error('FSB account not found');

    if (direction === 'FSB_TO_ECNY' && fsbAcc.availableBalanceCents < amountCents) {
      throw new Error('Insufficient FSB-CNY account balance');
    }

    const conv = await this.ecnyProvider.request_conversion({
      conversionId: `CNV-${Date.now()}`,
      direction,
      amountCents,
      fsbAccountId,
      ecnyWalletId,
      timestamp: new Date().toISOString()
    });

    const isCorp = fsbAcc.accountTypeZh.includes('企业');
    const depositAccountCode = isCorp ? '2002' : '2001';

    if (direction === 'FSB_TO_ECNY') {
      // Customer FSB-CNY deposit decreases
      // Bank's e-CNY clearing position (1003) decreases as it is transferred to user's wallet
      fsbAcc.balanceCents -= amountCents;
      fsbAcc.availableBalanceCents -= amountCents;

      this.ledger.postEntry(
        'ECNY_CONVERSION',
        conv.conversionId,
        'ECNY-GATEWAY',
        [
          {
            accountCode: depositAccountCode,
            debitCents: amountCents,
            creditCents: 0n,
            memoZh: `福山私人生息存款兑出为数字人民币 (e-CNY)`,
            memoEn: `FSB-CNY private deposit redeemed into sovereign e-CNY`
          },
          {
            accountCode: '1003', // e-CNY clearing asset
            debitCents: 0n,
            creditCents: amountCents,
            memoZh: `福山在PBOC数币清算头寸划出至个人钱包`,
            memoEn: `FSB e-CNY clearing reserve disbursed to user wallet`
          }
        ]
      );
    } else {
      // ECNY_TO_FSB:
      // Customer's e-CNY deposited into bank
      // Bank's e-CNY clearing position (1003) increases
      // Bank's deposit liability (2001/2002) increases
      fsbAcc.balanceCents += amountCents;
      fsbAcc.availableBalanceCents += amountCents;

      this.ledger.postEntry(
        'ECNY_CONVERSION',
        conv.conversionId,
        'ECNY-GATEWAY',
        [
          {
            accountCode: '1003', // e-CNY clearing asset
            debitCents: amountCents,
            creditCents: 0n,
            memoZh: `数字人民币 (e-CNY) 存入本行数币清算总头寸`,
            memoEn: `e-CNY inflow to FSB clearing reserve`
          },
          {
            accountCode: depositAccountCode,
            debitCents: 0n,
            creditCents: amountCents,
            memoZh: `转换为福山人民币存款负债 (FSB-CNY)`,
            memoEn: `Created FSB-CNY deposit liability`
          }
        ]
      );
    }

    return conv;
  }

  /**
   * Monetary position summary
   */
  public getMonetaryPosition(): MonetaryPosition {
    const res = this.ledger.getReserveMetrics();
    const bs = this.ledger.getBalanceSheet();

    return {
      totalCustomerDepositsCents: res.totalFSBDeposits,
      totalReserveAssetsCents: res.totalEligibleReserves,
      liquidAssetsCents: res.totalHQLA,
      reserveCoverageRatio: res.reserveRatio,
      liquidityCoverageRatio: res.liquidityRatio,
      availableLiquidityCents: res.availableLiquidity,
      encumberedLiquidityCents: res.encumberedLiquidity,
      intradaySettlementCapacityCents: res.totalEligibleReserves + (res.govBonds * 80n) / 100n, // Reserves + 80% Repo haircut
      ecnyConversionCapacityCents: res.ecnyClearing,
      netRMBPositionCents: bs.totalAssets - bs.totalLiabilities
    };
  }

  /**
   * Command list for the terminal
   */
  public static readonly TERMINAL_COMMANDS: TerminalCommandDef[] = [
    { command: 'MAIN <GO>', chineseAlias: '系统总览', descriptionZh: '主控制室与核心系统运行指标', descriptionEn: 'Main Control Room & Core Status', targetView: 'MAIN' },
    { command: 'BAL <GO>', chineseAlias: '资产负债表', descriptionZh: '会计总账与资产负债表 (Σ借=Σ贷)', descriptionEn: 'Balance Sheet & Double-Entry Ledger', targetView: 'BAL' },
    { command: 'LIQ <GO>', chineseAlias: '流动性', descriptionZh: '全行动态流动性指标与头寸缺口', descriptionEn: 'Liquidity Coverage & Intraday Position', targetView: 'LIQ' },
    { command: 'TREASURY <GO>', chineseAlias: '资金管理', descriptionZh: '资金部头寸与国债投资组合', descriptionEn: 'Treasury Desks & Bond Portfolio', targetView: 'TREASURY' },
    { command: 'RESERVE <GO>', chineseAlias: '储备', descriptionZh: '准备金结构与合格流动性资产', descriptionEn: 'Reserve Engine & HQLA Composition', targetView: 'RESERVE' },
    { command: 'ISSUE <GO>', chineseAlias: '发行模拟', descriptionZh: '私人人民币负债创造与注销模拟器', descriptionEn: 'Private RMB Issuance & Creation Engine', targetView: 'ISSUE' },
    { command: 'POS <GO>', chineseAlias: 'POS', descriptionZh: 'POS收单交易柜台与12步验证器', descriptionEn: 'POS Terminal & 12-Step Validator', targetView: 'POS' },
    { command: 'ECNY <GO>', chineseAlias: '数字人民币', descriptionZh: '数字人民币 (e-CNY) 互操作网关', descriptionEn: 'e-CNY Interoperability Gateway & Adapter', targetView: 'ECNY' },
    { command: 'PAY <GO>', chineseAlias: '支付', descriptionZh: '行内支付与多通道智能路由', descriptionEn: 'Payment Routing & Rail Optimization', targetView: 'ROUTER' },
    { command: 'MERCHANT <GO>', chineseAlias: '商户', descriptionZh: '特约商户银行收单与清分批次', descriptionEn: 'Merchant Acquiring & Settlement Dashboard', targetView: 'MERCHANT' },
    { command: 'CORP <GO>', chineseAlias: '企业银行', descriptionZh: '企业审批流与可编程支付触发器', descriptionEn: 'Corporate Approval Chain & Programmable Pay', targetView: 'CORPORATE' },
    { command: 'MOBILE <GO>', chineseAlias: '个人手机银行', descriptionZh: '零售个人客户界面 (零售体验)', descriptionEn: 'Mobile Retail Customer Banking Portal', targetView: 'MOBILE' },
    { command: 'RECON <GO>', chineseAlias: '对账', descriptionZh: '跨通道流水差错自动平账与对账', descriptionEn: 'Multi-Rail Automated Reconciliation', targetView: 'RECON' },
    { command: 'RISK <GO>', chineseAlias: '风险', descriptionZh: '实时反欺诈引擎与交易监控评分', descriptionEn: 'Real-Time Fraud Engine & Risk Scoring', targetView: 'RISK' },
    { command: 'COMPLIANCE <GO>', chineseAlias: '合规', descriptionZh: '反洗钱 (AML) 案例与可疑交易报告', descriptionEn: 'AML Cases, Sanctions & SAR Workflow', targetView: 'COMPLIANCE' },
    { command: 'STRESS <GO>', chineseAlias: '压力测试', descriptionZh: '挤兑与通道阻断流动性压力测试', descriptionEn: 'Deposit Run & Rail Outage Stress Testing', targetView: 'STRESS' },
    { command: 'MONEYGRAPH <GO>', chineseAlias: '货币网络', descriptionZh: '三层货币流动拓扑结构图', descriptionEn: 'Three-Layer Monetary Flow Graph', targetView: 'MONEYGRAPH' },
    { command: 'API <GO>', chineseAlias: 'API', descriptionZh: '开放银行与ISO 20022报文沙箱', descriptionEn: 'Open Banking Gateway & ISO 20022 Sandbox', targetView: 'API' }
  ];
}
