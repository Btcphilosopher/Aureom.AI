/**
 * Fukuyama Specie Bank (FSB-Core)
 * Risk, Fraud Detection & AML Compliance System
 * 
 * Implements:
 * 1. Real-time Fraud Scoring (Velocity anomalies, device switching, unusual terminal behavior)
 * 2. Sanctions Screening Adapter (Configurable rules)
 * 3. AML Transaction Structuring Monitor (Smurfing, rapid pass-through detection)
 * 4. Regulatory SAR/STR (Suspicious Activity Report / 可疑交易报告) Filing Workflow
 */

import { FraudAlert } from '../types/banking';

export interface AMLCase {
  caseId: string;
  customerId: string;
  customerNameZh: string;
  customerNameEn: string;
  triggerTypeZh: string;
  triggerTypeEn: string;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'INVESTIGATING' | 'ESCALATED_TO_MLRO' | 'SAR_SUBMITTED' | 'CLOSED_FALSE_POSITIVE';
  investigator: string;
  openedAt: string;
  findingsZh: string;
  findingsEn: string;
}

export class ComplianceEngine {
  private alerts: FraudAlert[] = [];
  private amlCases: AMLCase[] = [];

  constructor() {
    this.seedCases();
  }

  private seedCases(): void {
    this.alerts = [
      {
        alertId: 'FRAUD-ALERT-8819',
        transactionRef: 'FSB-POS-20261012-992318',
        merchantNameZh: '福山高新数码体验店',
        amountCents: 48_800_00n, // ¥48,800.00
        riskScore: 87,
        decision: 'REVIEW',
        reasonCodesZh: ['突发大额异地交易', '新接入终端首笔授权', '交易频次异常高 (10秒内3笔)'],
        reasonCodesEn: ['Large abnormal out-of-town transaction', 'First auth on new terminal', 'High velocity anomaly'],
        timestamp: new Date().toISOString(),
        status: 'OPEN'
      },
      {
        alertId: 'FRAUD-ALERT-8820',
        transactionRef: 'FSB-POS-20261012-992345',
        merchantNameZh: '海天星夜市摊位',
        amountCents: 12_500_00n, // ¥12,500.00
        riskScore: 72,
        decision: 'REVIEW',
        reasonCodesZh: ['夜间小额快频后接大额测试', '商户类别与交易额度不符'],
        reasonCodesEn: ['Night burst pattern before large test', 'MCC turnover mismatch'],
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        status: 'OPEN'
      }
    ];

    this.amlCases = [
      {
        caseId: 'AML-CASE-2026-081',
        customerId: 'CORP-9928',
        customerNameZh: '海纳跨境进出口贸易有限公司',
        customerNameEn: 'Haina Cross-border Trading Ltd',
        triggerTypeZh: '疑似化整为零分拆结汇 (Smurfing)',
        triggerTypeEn: 'Suspected Transaction Structuring (Smurfing)',
        riskRating: 'HIGH',
        status: 'INVESTIGATING',
        investigator: '林建东 (反洗钱合规官)',
        openedAt: '2026-10-11T16:20:00Z',
        findingsZh: '该账户在48小时内接收24笔各为49,800元的汇款，高度贴近5万元反洗钱大额监测红线，且迅速向数字人民币离线钱包充值。',
        findingsEn: '24 inflows of ¥49,800 within 48h, hovering just below the ¥50k threshold, followed by swift transfers to e-CNY offline wallets.'
      },
      {
        caseId: 'AML-CASE-2026-079',
        customerId: 'INST-4412',
        customerNameZh: '华宇远东投资管理合伙企业',
        customerNameEn: 'Huayu Far East Investment LP',
        triggerTypeZh: '制裁筛查模糊匹配警报 (OFAC / UN List Check)',
        triggerTypeEn: 'Sanctions List Fuzzy Match Notification',
        riskRating: 'MEDIUM',
        status: 'CLOSED_FALSE_POSITIVE',
        investigator: '陈美琳 (合规专员)',
        openedAt: '2026-10-09T11:00:00Z',
        findingsZh: '经比对护照号与实际受益所有人登记，确认为同名同姓误报，已解除系统监控标签。',
        findingsEn: 'Name collision cleared following verification of shareholder registry; false positive resolved.'
      }
    ];
  }

  public getAlerts(): FraudAlert[] {
    return [...this.alerts];
  }

  public getCases(): AMLCase[] {
    return [...this.amlCases];
  }

  public evaluateRiskScore(amountCents: bigint, instrument: string, isNewTerminal: boolean): {
    score: number;
    decision: 'APPROVE' | 'REVIEW' | 'BLOCK';
    reasonCodesZh: string[];
    reasonCodesEn: string[];
  } {
    let score = 10;
    const reasonsZh: string[] = [];
    const reasonsEn: string[] = [];

    if (amountCents > 100_000_00n) {
      score += 40;
      reasonsZh.push('单笔交易超十万元大额支付');
      reasonsEn.push('Single transaction exceeds ¥100,000 threshold');
    }

    if (isNewTerminal) {
      score += 25;
      reasonsZh.push('新注册POS终端首次受理');
      reasonsEn.push('First transaction on newly provisioned terminal');
    }

    if (instrument === 'NFC' && amountCents > 5_000_00n) {
      score += 15;
      reasonsZh.push('NFC免密非接大额支付');
      reasonsEn.push('NFC contactless high value payment');
    }

    let decision: 'APPROVE' | 'REVIEW' | 'BLOCK' = 'APPROVE';
    if (score >= 80) decision = 'BLOCK';
    else if (score >= 50) decision = 'REVIEW';

    return { score, decision, reasonCodesZh: reasonsZh, reasonCodesEn: reasonsEn };
  }

  public updateAlertStatus(alertId: string, status: FraudAlert['status']): void {
    const item = this.alerts.find(a => a.alertId === alertId);
    if (item) item.status = status;
  }

  public updateCaseStatus(caseId: string, status: AMLCase['status']): void {
    const item = this.amlCases.find(c => c.caseId === caseId);
    if (item) item.status = status;
  }
}
