/**
 * Fukuyama Specie Bank (FSB-Core)
 * Programmable Banking Payments & Controlled Corporate Workflow
 * 
 * Non-crypto, institutional rule-engine implementation:
 * Enforces enterprise conditional multi-party triggers (Delivery, Tax Invoice, CFO Dual-Auth).
 */

import { ProgrammablePaymentRule } from '../types/banking';
import { GeneralLedger } from './ledger';
import { Money } from './math';

export class ProgrammablePaymentEngine {
  private rules: Map<string, ProgrammablePaymentRule> = new Map();
  private ledger: GeneralLedger;

  constructor(ledger: GeneralLedger) {
    this.ledger = ledger;
    this.seedRules();
  }

  private seedRules(): void {
    const defaultRules: ProgrammablePaymentRule[] = [
      {
        ruleId: 'RULE-PROG-2026-001',
        corporateCustomerId: 'CORP-8842',
        titleZh: '芯片采购货款自动结算指令 (条件：发票核验 + 仓储验收 + 财务总监复核)',
        titleEn: 'Semiconductor Procurement Auto-Pay (Invoice + Warehouse + CFO Approval)',
        supplierAccountId: '2002-CORP-SUPP-01',
        amountCents: 500_000_00n, // ¥500,000.00
        conditions: {
          deliveryConfirmed: true,
          invoiceValidated: true,
          cfoApproved: false
        },
        triggerType: 'MULTI_SIG_GATE',
        status: 'PENDING_CONDITIONS',
        approvalChain: [
          { role: 'EMPLOYEE', approved: true, approvedAt: '2026-10-10T09:12:00Z', approvedBy: '王敏 (采购员)' },
          { role: 'MANAGER', approved: true, approvedAt: '2026-10-10T14:30:00Z', approvedBy: '李振华 (供应链总监)' },
          { role: 'TREASURER', approved: true, approvedAt: '2026-10-11T10:05:00Z', approvedBy: '张凯 (司库主管)' },
          { role: 'CFO', approved: false, approvedBy: '待签署 (赵建国 首席财务官)' }
        ],
        createdAt: '2026-10-10T08:00:00Z'
      },
      {
        ruleId: 'RULE-PROG-2026-002',
        corporateCustomerId: 'CORP-9100',
        titleZh: '云计算服务器租赁按月履约清算 (条件：SLA可用性达到99.95%)',
        titleEn: 'Cloud Infrastructure SLA-Linked Monthly Auto-Disbursement',
        supplierAccountId: '2002-CORP-CLOUD-09',
        amountCents: 85_000_00n, // ¥85,000.00
        conditions: {
          deliveryConfirmed: true,
          invoiceValidated: true,
          cfoApproved: true
        },
        triggerType: 'AUTOMATED_WEBHOOK',
        status: 'CONDITIONS_MET',
        approvalChain: [
          { role: 'EMPLOYEE', approved: true, approvedAt: '2026-10-12T01:00:00Z', approvedBy: '系统运维监控' },
          { role: 'MANAGER', approved: true, approvedAt: '2026-10-12T01:05:00Z', approvedBy: 'IT架构总监' },
          { role: 'TREASURER', approved: true, approvedAt: '2026-10-12T01:10:00Z', approvedBy: '自动风控网关' },
          { role: 'CFO', approved: true, approvedAt: '2026-10-12T01:15:00Z', approvedBy: '预授权智能委派' }
        ],
        createdAt: '2026-10-12T00:30:00Z'
      }
    ];

    for (const r of defaultRules) {
      this.rules.set(r.ruleId, r);
    }
  }

  public getAllRules(): ProgrammablePaymentRule[] {
    return Array.from(this.rules.values());
  }

  public approveStep(ruleId: string, role: 'EMPLOYEE' | 'MANAGER' | 'TREASURER' | 'CFO', approverName: string): ProgrammablePaymentRule {
    const rule = this.rules.get(ruleId);
    if (!rule) throw new Error(`Rule ${ruleId} not found`);

    const step = rule.approvalChain.find(s => s.role === role);
    if (step) {
      step.approved = true;
      step.approvedAt = new Date().toISOString();
      step.approvedBy = approverName;
    }

    if (role === 'CFO') {
      rule.conditions.cfoApproved = true;
    }

    // Check if all conditions are satisfied
    if (rule.conditions.deliveryConfirmed && rule.conditions.invoiceValidated && rule.conditions.cfoApproved) {
      rule.status = 'CONDITIONS_MET';
    }

    return { ...rule };
  }

  public toggleCondition(ruleId: string, conditionKey: 'deliveryConfirmed' | 'invoiceValidated'): ProgrammablePaymentRule {
    const rule = this.rules.get(ruleId);
    if (!rule) throw new Error(`Rule ${ruleId} not found`);

    rule.conditions[conditionKey] = !rule.conditions[conditionKey];

    if (rule.conditions.deliveryConfirmed && rule.conditions.invoiceValidated && rule.conditions.cfoApproved) {
      rule.status = 'CONDITIONS_MET';
    } else if (rule.status === 'CONDITIONS_MET') {
      rule.status = 'PENDING_CONDITIONS';
    }

    return { ...rule };
  }

  public executePayment(ruleId: string): ProgrammablePaymentRule {
    const rule = this.rules.get(ruleId);
    if (!rule) throw new Error(`Rule ${ruleId} not found`);
    if (rule.status === 'EXECUTED') throw new Error(`Rule ${ruleId} has already been executed`);
    if (rule.status !== 'CONDITIONS_MET') throw new Error('Conditions not met yet');

    // Post double entry in ledger
    this.ledger.postEntry(
      'SETTLEMENT',
      `PROG-${ruleId}`,
      'PROGRAMMABLE-PAY-ENGINE',
      [
        {
          accountCode: '2002', // Corporate demand deposit
          debitCents: rule.amountCents,
          creditCents: 0n,
          memoZh: `企业可编程支付履约出账: ${rule.titleZh}`,
          memoEn: `Programmable payment debit: ${rule.titleEn}`
        },
        {
          accountCode: '2002', // Supplier corporate deposit
          debitCents: 0n,
          creditCents: rule.amountCents,
          memoZh: `供应商货款条件履约入账`,
          memoEn: `Supplier disbursement credit`
        }
      ]
    );

    rule.status = 'EXECUTED';
    rule.executedAt = new Date().toISOString();
    return { ...rule };
  }
}
