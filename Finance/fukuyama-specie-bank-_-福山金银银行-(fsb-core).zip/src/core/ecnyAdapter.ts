/**
 * Fukuyama Specie Bank (FSB-Core)
 * Digital RMB (e-CNY / 数字人民币) Interoperability Adapter
 * 
 * ARCHITECTURAL NOTICE:
 * This module is an interoperability abstraction layer connecting Fukuyama private RMB
 * banking liabilities to the Digital Currency Electronic Payment (DC/EP / e-CNY) infrastructure.
 * This software does NOT fabricate direct unauthorized access to PBOC systems.
 * All external connectivity is implemented via a rigorous adapter and MockECNYProvider.
 */

import { ECNYWallet, ECNYConversionRequest } from '../types/banking';
import { Money } from './math';

export interface ECNYPaymentInstructionPayload {
  instructionId: string;
  sourceWalletId: string;
  targetWalletId: string;
  amountCents: bigint;
  purpose: string;
  timestamp: string;
}

export interface ECNYAdapter {
  connect(): Promise<{ connected: boolean; gatewayNode: string; latencyMs: number }>;
  authenticate(institutionId: string, certThumbprint: string): Promise<boolean>;
  get_wallet(walletId: string): Promise<ECNYWallet | null>;
  query_balance(walletId: string): Promise<bigint>;
  request_conversion(request: Omit<ECNYConversionRequest, 'status' | 'pbocSettlementRef'>): Promise<ECNYConversionRequest>;
  create_payment_instruction(payload: ECNYPaymentInstructionPayload): Promise<{ traceNo: string; status: 'SUCCESS' | 'REJECTED' }>;
  submit_payment(instructionId: string): Promise<{ settled: boolean; pbocTxId: string }>;
  receive_settlement(batchId: string): Promise<{ settledCount: number; netAmountCents: bigint }>;
  reconcile(dateString: string): Promise<{ matchedCount: number; discrepancies: number }>;
}

export class MockECNYProvider implements ECNYAdapter {
  private isConnected = false;
  private authenticated = false;
  private wallets: Map<string, ECNYWallet> = new Map();
  private conversions: ECNYConversionRequest[] = [];

  constructor() {
    this.seedMockWallets();
  }

  private seedMockWallets(): void {
    const initialWallets: ECNYWallet[] = [
      {
        walletId: 'ECNY-8820-0019-3381',
        tier: 'TIER_1',
        holderName: '陈立群 (Chen Liqun - Retail Customer)',
        balanceCents: 52_400_00n, // ¥52,400.00
        status: 'ACTIVE',
        boundBankId: 'FSB-BANK-098'
      },
      {
        walletId: 'ECNY-9901-4472-1102',
        tier: 'TIER_2',
        holderName: '福山城市便利连锁 (Fukuyama Retail Chain)',
        balanceCents: 890_200_00n, // ¥890,200.00
        status: 'ACTIVE',
        boundBankId: 'FSB-BANK-098'
      },
      {
        walletId: 'ECNY-7700-5511-9923',
        tier: 'TIER_1',
        holderName: '东方精密制造有限公司 (East Precision Tech)',
        balanceCents: 4_500_000_00n, // ¥4,500,000.00
        status: 'ACTIVE',
        boundBankId: 'FSB-BANK-098'
      },
      {
        walletId: 'ECNY-FSB-TREASURY-01',
        tier: 'TIER_1',
        holderName: '福山金银银行资金运营专户 (FSB Interop Treasury)',
        balanceCents: 42_000_000_000_00n, // ¥42.0bn
        status: 'ACTIVE',
        boundBankId: 'FSB-BANK-098'
      }
    ];

    for (const w of initialWallets) {
      this.wallets.set(w.walletId, w);
    }
  }

  public async connect(): Promise<{ connected: boolean; gatewayNode: string; latencyMs: number }> {
    this.isConnected = true;
    return {
      connected: true,
      gatewayNode: 'PBOC-DCEP-EDGE-SH02 (Shanghai Financial Data Hub)',
      latencyMs: 38
    };
  }

  public async authenticate(institutionId: string, certThumbprint: string): Promise<boolean> {
    if (institutionId.startsWith('FSB') && certThumbprint.length > 8) {
      this.authenticated = true;
      return true;
    }
    return false;
  }

  public async get_wallet(walletId: string): Promise<ECNYWallet | null> {
    return this.wallets.get(walletId) || null;
  }

  public async query_balance(walletId: string): Promise<bigint> {
    const w = this.wallets.get(walletId);
    return w ? w.balanceCents : 0n;
  }

  public getAllWallets(): ECNYWallet[] {
    return Array.from(this.wallets.values());
  }

  public async request_conversion(
    request: Omit<ECNYConversionRequest, 'status' | 'pbocSettlementRef'>
  ): Promise<ECNYConversionRequest> {
    const wallet = this.wallets.get(request.ecnyWalletId);
    if (!wallet) {
      throw new Error(`e-CNY Wallet not found: ${request.ecnyWalletId}`);
    }

    if (request.direction === 'ECNY_TO_FSB' && wallet.balanceCents < request.amountCents) {
      throw new Error(
        `Insufficient e-CNY balance: ${Money.format(wallet.balanceCents)} < ${Money.format(request.amountCents)}`
      );
    }

    // Deduct or credit e-CNY wallet
    if (request.direction === 'ECNY_TO_FSB') {
      wallet.balanceCents -= request.amountCents;
    } else {
      wallet.balanceCents += request.amountCents;
    }

    const pbocRef = `PBOC-DCEP-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100000 + Math.random() * 900000)}`;

    const fullRecord: ECNYConversionRequest = {
      ...request,
      status: 'COMPLETED',
      pbocSettlementRef: pbocRef
    };

    this.conversions.unshift(fullRecord);
    return fullRecord;
  }

  public async create_payment_instruction(
    payload: ECNYPaymentInstructionPayload
  ): Promise<{ traceNo: string; status: 'SUCCESS' | 'REJECTED' }> {
    const src = this.wallets.get(payload.sourceWalletId);
    if (!src || src.balanceCents < payload.amountCents) {
      return { traceNo: `TRACE-REJ-${Date.now()}`, status: 'REJECTED' };
    }
    return {
      traceNo: `PBOC-TRACE-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      status: 'SUCCESS'
    };
  }

  public async submit_payment(
    instructionId: string
  ): Promise<{ settled: boolean; pbocTxId: string }> {
    return {
      settled: true,
      pbocTxId: `DCEP-TX-${instructionId}-${Math.floor(10000 + Math.random() * 90000)}`
    };
  }

  public async receive_settlement(
    batchId: string
  ): Promise<{ settledCount: number; netAmountCents: bigint }> {
    return {
      settledCount: 1420,
      netAmountCents: 45_800_000_00n // ¥45.8M
    };
  }

  public async reconcile(
    _dateString: string
  ): Promise<{ matchedCount: number; discrepancies: number }> {
    return {
      matchedCount: 28419,
      discrepancies: 0
    };
  }

  public getConversions(): ECNYConversionRequest[] {
    return [...this.conversions];
  }
}
