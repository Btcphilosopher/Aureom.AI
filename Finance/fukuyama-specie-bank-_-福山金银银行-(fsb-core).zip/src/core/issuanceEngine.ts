/**
 * Fukuyama Specie Bank (FSB-Core)
 * Private RMB Issuance & Liability Engine (FSB-CNY)
 * 
 * CORE EQUATION:
 * Net Private RMB Issuance = Deposits Created - Deposits Redeemed - Deposits Cancelled
 * 
 * FUNDAMENTAL ACCOUNTING AXIOM:
 * FSB-CNY is a private banking deposit liability denominated in RMB.
 * It is NOT sovereign legal tender. Every issuance must be backed by
 * legitimate reserve assets (Cash, PBOC balances, e-CNY clearing positions, or eligible securities)
 * entered via double-entry accounting.
 */

import { GeneralLedger } from './ledger';
import { Money } from './math';

export interface IssuanceEvent {
  eventId: string;
  timestamp: string;
  type: 'CREATION' | 'REDEMPTION' | 'CANCELLATION';
  amountCents: bigint;
  counterpartyCustomerZh: string;
  counterpartyCustomerEn: string;
  backingAssetCode: string;
  depositLiabilityCode: string;
  netIssuanceAfterCents: bigint;
  auditSignature: string;
  notesZh: string;
  notesEn: string;
}

export class IssuanceEngine {
  private ledger: GeneralLedger;
  private issuanceLog: IssuanceEvent[] = [];

  constructor(ledger: GeneralLedger) {
    this.ledger = ledger;
  }

  public getHistory(): IssuanceEvent[] {
    return [...this.issuanceLog];
  }

  /**
   * Calculate current net private RMB issuance
   */
  public getNetIssuanceCents(): bigint {
    const retail = this.ledger.getAccount('2001').balanceCents;
    const corporate = this.ledger.getAccount('2002').balanceCents;
    const merchant = this.ledger.getAccount('2003').balanceCents;
    const institutional = this.ledger.getAccount('2004').balanceCents;
    return retail + corporate + merchant + institutional;
  }

  /**
   * ISSUE FSB-CNY (Deposit Creation backed by reserve transfer)
   * Debit: Reserve Asset (e.g. 1002 PBOC Reserve or 1003 e-CNY Clearing)
   * Credit: Customer Deposit Liability (e.g. 2001 or 2002)
   */
  public issuePrivateRMB(
    amountCents: bigint,
    customerNameZh: string,
    customerNameEn: string,
    targetAccountCode: '2001' | '2002' | '2004',
    fundingAssetCode: '1001' | '1002' | '1003' | '1101' = '1002',
    operator = 'TREASURY-DESK'
  ): IssuanceEvent {
    if (amountCents <= 0n) {
      throw new Error('Issuance amount must be positive');
    }

    const txRef = `ISSUE-${Date.now()}`;
    const backingAccount = this.ledger.getAccount(fundingAssetCode);
    const depositAccount = this.ledger.getAccount(targetAccountCode);

    // Double-Entry Posting:
    // Debit: Asset (Increases bank's reserve assets)
    // Credit: Liability (Increases private FSB-CNY deposit claims)
    this.ledger.postEntry(
      'ISSUANCE',
      txRef,
      operator,
      [
        {
          accountCode: fundingAssetCode,
          debitCents: amountCents,
          creditCents: 0n,
          memoZh: `存入储备资产 [${backingAccount.nameZh}]，支撑私人人民币负债发行`,
          memoEn: `Inflow of reserve asset [${backingAccount.nameEn}] backing issuance`
        },
        {
          accountCode: targetAccountCode,
          debitCents: 0n,
          creditCents: amountCents,
          memoZh: `福山私人生息存款记入 [${depositAccount.nameZh}] - 客户: ${customerNameZh}`,
          memoEn: `FSB-CNY private deposit claim created - Customer: ${customerNameEn}`
        }
      ]
    );

    const event: IssuanceEvent = {
      eventId: `ISS-EVT-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      type: 'CREATION',
      amountCents,
      counterpartyCustomerZh: customerNameZh,
      counterpartyCustomerEn: customerNameEn,
      backingAssetCode: fundingAssetCode,
      depositLiabilityCode: targetAccountCode,
      netIssuanceAfterCents: this.getNetIssuanceCents(),
      auditSignature: `SM2-SIG-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      notesZh: `核发以人民币计价的私人银行存款负债 (FSB-CNY) ${Money.format(amountCents)}，对应储备资产划入`,
      notesEn: `Created private RMB deposit liability ${Money.format(amountCents)} backed by eligible reserve asset`
    };

    this.issuanceLog.unshift(event);
    return event;
  }

  /**
   * REDEEM FSB-CNY (Deposit Redemption against reserve asset outflow)
   * Debit: Customer Deposit Liability (Reduces private deposit)
   * Credit: Reserve Asset (Outflow from bank)
   */
  public redeemPrivateRMB(
    amountCents: bigint,
    customerNameZh: string,
    customerNameEn: string,
    sourceAccountCode: '2001' | '2002' | '2004',
    payoutAssetCode: '1001' | '1002' | '1003' = '1002',
    operator = 'TREASURY-DESK'
  ): IssuanceEvent {
    const depositAccount = this.ledger.getAccount(sourceAccountCode);
    const payoutAccount = this.ledger.getAccount(payoutAssetCode);

    if (depositAccount.balanceCents < amountCents) {
      throw new Error(`Insufficient deposit balance for redemption: ${Money.format(depositAccount.balanceCents)}`);
    }

    if (payoutAccount.balanceCents < amountCents) {
      throw new Error(`Insufficient reserve asset balance for redemption: ${Money.format(payoutAccount.balanceCents)}`);
    }

    const txRef = `REDEEM-${Date.now()}`;

    // Double-Entry Posting:
    // Debit: Liability (Extinguishes private bank liability)
    // Credit: Asset (Outflow of sovereign settlement funds)
    this.ledger.postEntry(
      'ISSUANCE',
      txRef,
      operator,
      [
        {
          accountCode: sourceAccountCode,
          debitCents: amountCents,
          creditCents: 0n,
          memoZh: `注销福山私人人民币存款负债 [${depositAccount.nameZh}] - 客户: ${customerNameZh}`,
          memoEn: `Extinguish FSB-CNY deposit liability - Customer: ${customerNameEn}`
        },
        {
          accountCode: payoutAssetCode,
          debitCents: 0n,
          creditCents: amountCents,
          memoZh: `储备头寸 [${payoutAccount.nameZh}] 兑付划出`,
          memoEn: `Outflow of settlement reserve asset [${payoutAccount.nameEn}]`
        }
      ]
    );

    const event: IssuanceEvent = {
      eventId: `RED-EVT-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      type: 'REDEMPTION',
      amountCents,
      counterpartyCustomerZh: customerNameZh,
      counterpartyCustomerEn: customerNameEn,
      backingAssetCode: payoutAssetCode,
      depositLiabilityCode: sourceAccountCode,
      netIssuanceAfterCents: this.getNetIssuanceCents(),
      auditSignature: `SM2-SIG-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      notesZh: `兑付并注销私人人民币银行负债 ${Money.format(amountCents)}，划付央行清算备付金`,
      notesEn: `Redeemed private RMB deposit liability ${Money.format(amountCents)} via reserve settlement outflow`
    };

    this.issuanceLog.unshift(event);
    return event;
  }
}
