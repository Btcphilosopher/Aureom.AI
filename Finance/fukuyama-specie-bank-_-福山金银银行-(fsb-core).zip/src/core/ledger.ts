/**
 * Fukuyama Specie Bank (FSB-Core)
 * Double-Entry General Ledger System
 * 
 * CORE INVARIANTS:
 * 1. Σ Debits === Σ Credits for every Journal Entry. Unbalanced entries are strictly rejected.
 * 2. Total Assets === Total Liabilities + Total Equity at all times.
 * 3. Clear distinction between Layer A (Sovereign Money), Layer B (Commercial Bank Money), Layer C (Payment Representation).
 */

import { LedgerAccount, JournalEntry, JournalLine, AccountCategory } from '../types/banking';
import { Money } from './math';

export class GeneralLedger {
  private accounts: Map<string, LedgerAccount> = new Map();
  private entries: JournalEntry[] = [];

  constructor() {
    this.initChartOfAccounts();
    this.seedInitialBalances();
  }

  /**
   * Standard Chinese Commercial Banking Chart of Accounts
   */
  private initChartOfAccounts(): void {
    const chart: LedgerAccount[] = [
      // 1xxx Assets
      {
        code: '1001',
        nameZh: '库存现金',
        nameEn: 'Vault Cash (Sovereign RMB)',
        category: 'ASSET',
        currency: 'CNY',
        layer: 'LAYER_A_SOVEREIGN',
        balanceCents: 0n,
        hqlTier: 'LEVEL_1'
      },
      {
        code: '1002',
        nameZh: '存放中央银行法定与超额准备金',
        nameEn: 'PBOC Settlement Balances & Reserves',
        category: 'ASSET',
        currency: 'CNY',
        layer: 'LAYER_A_SOVEREIGN',
        balanceCents: 0n,
        hqlTier: 'LEVEL_1'
      },
      {
        code: '1003',
        nameZh: '数字人民币系统清算资金',
        nameEn: 'e-CNY System Clearing Position',
        category: 'ASSET',
        currency: 'CNY',
        layer: 'LAYER_A_SOVEREIGN',
        balanceCents: 0n,
        hqlTier: 'LEVEL_1'
      },
      {
        code: '1101',
        nameZh: '存放同业款项',
        nameEn: 'Interbank Deposits & Placements',
        category: 'ASSET',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n,
        hqlTier: 'LEVEL_2A'
      },
      {
        code: '1201',
        nameZh: '中国国债持仓 (高流动性资产)',
        nameEn: 'PRC Sovereign Treasury Bonds (HQLA)',
        category: 'ASSET',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n,
        hqlTier: 'LEVEL_1'
      },
      {
        code: '1202',
        nameZh: '政策性金融债持仓',
        nameEn: 'Policy Bank Bonds (CDB/ADBC)',
        category: 'ASSET',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n,
        hqlTier: 'LEVEL_2A'
      },
      {
        code: '1301',
        nameZh: '各项贷款及绿色信贷资产',
        nameEn: 'Commercial & Institutional Loans',
        category: 'ASSET',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n,
        hqlTier: 'NONE'
      },

      // 2xxx Liabilities
      {
        code: '2001',
        nameZh: '福山个人储蓄存款 (FSB-CNY)',
        nameEn: 'Retail Demand Deposits (FSB-CNY Liability)',
        category: 'LIABILITY',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },
      {
        code: '2002',
        nameZh: '福山企业活期存款 (FSB-CNY)',
        nameEn: 'Corporate Demand Deposits (FSB-CNY Liability)',
        category: 'LIABILITY',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },
      {
        code: '2003',
        nameZh: '商户待结算与在途款项',
        nameEn: 'Merchant Settlement Payable (Acquiring Float)',
        category: 'LIABILITY',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },
      {
        code: '2004',
        nameZh: '特种机构与同业存款',
        nameEn: 'Institutional & Interbank Deposits',
        category: 'LIABILITY',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },
      {
        code: '2101',
        nameZh: '央行再贷款及同业拆入',
        nameEn: 'PBOC Facilities & Interbank Borrowing',
        category: 'LIABILITY',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },

      // 3xxx Equity
      {
        code: '3001',
        nameZh: '实收资本',
        nameEn: 'Paid-in Capital',
        category: 'EQUITY',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },
      {
        code: '3002',
        nameZh: '盈余公积与一般风险准备',
        nameEn: 'Statutory Surplus & Risk Reserves',
        category: 'EQUITY',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },
      {
        code: '3003',
        nameZh: '未分配利润',
        nameEn: 'Retained Earnings',
        category: 'EQUITY',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },

      // 4xxx Revenue & 5xxx Expense
      {
        code: '4001',
        nameZh: '支付收单及清算手续费收入',
        nameEn: 'Payment Acquiring & Clearing Fee Income',
        category: 'REVENUE',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      },
      {
        code: '5001',
        nameZh: '利息及系统运营成本支出',
        nameEn: 'Interest Expense & Operational Costs',
        category: 'EXPENSE',
        currency: 'CNY',
        layer: 'LAYER_B_COMMERCIAL',
        balanceCents: 0n
      }
    ];

    for (const acc of chart) {
      this.accounts.set(acc.code, acc);
    }
  }

  /**
   * Seed baseline balance sheet representing Fukuyama Specie Bank's scale:
   * Total Balance Sheet: ~¥1.05 Trillion (¥1,050.00bn)
   * With balanced double-entry accounting.
   */
  private seedInitialBalances(): void {
    // 1001 Cash: ¥12.4bn
    this.getAccount('1001').balanceCents = 12_400_000_000_00n;
    // 1002 PBOC Reserve: ¥128.6bn
    this.getAccount('1002').balanceCents = 128_600_000_000_00n;
    // 1003 e-CNY Clearing Position: ¥42.0bn
    this.getAccount('1003').balanceCents = 42_000_000_000_00n;
    // 1101 Interbank Deposits: ¥58.5bn
    this.getAccount('1101').balanceCents = 58_500_000_000_00n;
    // 1201 PRC Gov Bonds (HQLA): ¥280.0bn
    this.getAccount('1201').balanceCents = 280_000_000_000_00n;
    // 1202 Policy Bank Bonds: ¥98.5bn
    this.getAccount('1202').balanceCents = 98_500_000_000_00n;
    // 1301 Commercial Loans: ¥430.0bn
    this.getAccount('1301').balanceCents = 430_000_000_000_00n;
    // Total Assets = 12.4 + 128.6 + 42.0 + 58.5 + 280.0 + 98.5 + 430.0 = ¥1,050.0bn

    // Liabilities:
    // 2001 Retail FSB Deposits: ¥520.0bn
    this.getAccount('2001').balanceCents = 520_000_000_000_00n;
    // 2002 Corporate FSB Deposits: ¥245.0bn
    this.getAccount('2002').balanceCents = 245_000_000_000_00n;
    // 2003 Merchant Payable: ¥48.0bn
    this.getAccount('2003').balanceCents = 48_000_000_000_00n;
    // 2004 Institutional Deposits: ¥47.4bn
    this.getAccount('2004').balanceCents = 47_400_000_000_00n;
    // 2101 PBOC Facilities / Interbank: ¥69.6bn
    this.getAccount('2101').balanceCents = 69_600_000_000_00n;
    // Total Liabilities = 520.0 + 245.0 + 48.0 + 47.4 + 69.6 = ¥930.0bn

    // Equity:
    // 3001 Paid-in Capital: ¥60.0bn
    this.getAccount('3001').balanceCents = 60_000_000_000_00n;
    // 3002 Surplus & Risk Reserves: ¥35.0bn
    this.getAccount('3002').balanceCents = 35_000_000_000_00n;
    // 3003 Retained Earnings: ¥25.0bn
    this.getAccount('3003').balanceCents = 25_000_000_000_00n;
    // Total Equity = 60 + 35 + 25 = ¥120.0bn
    // Assets (1050.0) = Liabilities (930.0) + Equity (120.0) -> Balanced!

    // Revenue initial: ¥3.8bn
    this.getAccount('4001').balanceCents = 3_800_000_000_00n;
    // Expense initial: ¥1.2bn
    this.getAccount('5001').balanceCents = 1_200_000_000_00n;
  }

  public getAccount(code: string): LedgerAccount {
    const acc = this.accounts.get(code);
    if (!acc) throw new Error(`Ledger account not found: ${code}`);
    return acc;
  }

  public getAllAccounts(): LedgerAccount[] {
    return Array.from(this.accounts.values());
  }

  public getJournalEntries(): JournalEntry[] {
    return [...this.entries];
  }

  /**
   * Post a balanced journal entry
   * Throws if Σ Debits !== Σ Credits
   */
  public postEntry(
    sourceModule: JournalEntry['sourceModule'],
    transactionRef: string,
    operator: string,
    lines: Omit<JournalLine, 'accountNameZh' | 'accountNameEn'>[]
  ): JournalEntry {
    let totalDebit = 0n;
    let totalCredit = 0n;

    const fullLines: JournalLine[] = lines.map(line => {
      const acc = this.getAccount(line.accountCode);
      totalDebit += line.debitCents;
      totalCredit += line.creditCents;
      return {
        ...line,
        accountNameZh: acc.nameZh,
        accountNameEn: acc.nameEn
      };
    });

    if (totalDebit !== totalCredit) {
      throw new Error(
        `UNBALANCED JOURNAL ENTRY REJECTED: Total Debits (${Money.format(totalDebit)}) !== Total Credits (${Money.format(totalCredit)})`
      );
    }

    // Apply adjustments to account balances
    // For Assets & Expenses: Debit increases balance, Credit decreases balance.
    // For Liabilities, Equity & Revenue: Credit increases balance, Debit decreases balance.
    for (const line of fullLines) {
      const acc = this.getAccount(line.accountCode);
      if (acc.category === 'ASSET' || acc.category === 'EXPENSE') {
        acc.balanceCents += line.debitCents - line.creditCents;
      } else {
        // LIABILITY, EQUITY, REVENUE
        acc.balanceCents += line.creditCents - line.debitCents;
      }
    }

    const entry: JournalEntry = {
      entryId: `JE-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      transactionRef,
      sourceModule,
      lines: fullLines,
      totalDebitCents: totalDebit,
      totalCreditCents: totalCredit,
      isBalanced: true,
      operator
    };

    this.entries.unshift(entry);
    return entry;
  }

  /**
   * Compute Balance Sheet summary
   */
  public getBalanceSheet() {
    let totalAssets = 0n;
    let totalLiabilities = 0n;
    let totalEquity = 0n;
    let totalRevenue = 0n;
    let totalExpense = 0n;

    for (const acc of this.accounts.values()) {
      switch (acc.category) {
        case 'ASSET':
          totalAssets += acc.balanceCents;
          break;
        case 'LIABILITY':
          totalLiabilities += acc.balanceCents;
          break;
        case 'EQUITY':
          totalEquity += acc.balanceCents;
          break;
        case 'REVENUE':
          totalRevenue += acc.balanceCents;
          break;
        case 'EXPENSE':
          totalExpense += acc.balanceCents;
          break;
      }
    }

    // Retained profit = Revenue - Expense
    const netCurrentProfit = totalRevenue - totalExpense;
    const effectiveEquity = totalEquity + netCurrentProfit;
    const isBalanced = totalAssets === totalLiabilities + effectiveEquity;

    return {
      totalAssets,
      totalLiabilities,
      baseEquity: totalEquity,
      netCurrentProfit,
      effectiveEquity,
      isBalanced,
      difference: totalAssets - (totalLiabilities + effectiveEquity)
    };
  }

  /**
   * Compute Reserve & Liquidity Engine metrics
   */
  public getReserveMetrics() {
    // Eligible reserves: Cash (1001) + PBOC balances (1002) + e-CNY clearing (1003)
    const sovereignCash = this.getAccount('1001').balanceCents;
    const pbocReserves = this.getAccount('1002').balanceCents;
    const ecnyClearing = this.getAccount('1003').balanceCents;
    const totalEligibleReserves = sovereignCash + pbocReserves + ecnyClearing;

    // High Quality Liquid Assets (HQLA Level 1: Cash, PBOC, Treasury Bonds)
    const govBonds = this.getAccount('1201').balanceCents;
    const policyBonds = this.getAccount('1202').balanceCents;
    const totalHQLA = totalEligibleReserves + govBonds + policyBonds;

    // Total Customer Deposits (FSB-CNY private bank liabilities): 2001 + 2002 + 2003 + 2004
    const retailDeposits = this.getAccount('2001').balanceCents;
    const corporateDeposits = this.getAccount('2002').balanceCents;
    const merchantFloat = this.getAccount('2003').balanceCents;
    const institutionalDeposits = this.getAccount('2004').balanceCents;
    const totalFSBDeposits = retailDeposits + corporateDeposits + merchantFloat + institutionalDeposits;

    const reserveRatio = Money.ratioPercentage(totalEligibleReserves, totalFSBDeposits);
    const liquidityRatio = Money.ratioPercentage(totalHQLA, totalFSBDeposits);

    // Encumbered vs Unencumbered (assume 15% of bonds pledged in PBOC repo)
    const encumberedBonds = (govBonds * 15n) / 100n;
    const availableLiquidity = totalHQLA - encumberedBonds;

    return {
      sovereignCash,
      pbocReserves,
      ecnyClearing,
      govBonds,
      policyBonds,
      totalEligibleReserves,
      totalHQLA,
      totalFSBDeposits,
      retailDeposits,
      corporateDeposits,
      merchantFloat,
      institutionalDeposits,
      reserveRatio,
      liquidityRatio,
      availableLiquidity,
      encumberedLiquidity: encumberedBonds
    };
  }
}
