/**
 * Fukuyama Specie Bank (FSB-Core)
 * Multi-Rail Reconciliation & Discrepancy Resolution Engine
 * 
 * Reconciles:
 * 1. FSB Internal Core Ledger (2001/2002/2003)
 * 2. POS Terminals Acquiring Journal
 * 3. Digital RMB (e-CNY) PBOC Clearing Stream
 * 4. CNAPS Interbank Settlement Statements
 */

import { ReconciliationDiscrepancy } from '../types/banking';
import { GeneralLedger } from './ledger';
import { Money } from './math';

export interface ReconRunReport {
  runId: string;
  runTimestamp: string;
  totalRecordsScanned: number;
  totalMatchedRecords: number;
  matchedVolumeCents: bigint;
  unreconciledDiscrepanciesCount: number;
  discrepancyVolumeCents: bigint;
  status: 'FULLY_RECONCILED' | 'ACTION_REQUIRED';
  discrepancies: ReconciliationDiscrepancy[];
}

export class ReconciliationEngine {
  private ledger: GeneralLedger;
  private discrepancies: ReconciliationDiscrepancy[] = [];

  constructor(ledger: GeneralLedger) {
    this.ledger = ledger;
    this.seedDiscrepancies();
  }

  private seedDiscrepancies(): void {
    this.discrepancies = [
      {
        discrepancyId: 'DISC-20261012-004',
        transactionRef: 'FSB-POS-20261011-883192',
        ledgerAmountCents: 128_50n, // ¥128.50
        externalRailAmountCents: 128_00n, // ¥128.00
        systemRail: 'POS',
        type: 'AMOUNT_MISMATCH',
        status: 'INVESTIGATING',
        flaggedAt: '2026-10-12T01:30:00Z'
      },
      {
        discrepancyId: 'DISC-20261012-007',
        transactionRef: 'PBOC-DCEP-20261011-992314',
        ledgerAmountCents: 50_000_00n, // ¥50,000.00
        externalRailAmountCents: 50_000_00n,
        systemRail: 'ECNY',
        type: 'TIMING_LAG',
        status: 'UNRESOLVED',
        flaggedAt: '2026-10-12T02:00:00Z'
      }
    ];
  }

  public getDiscrepancies(): ReconciliationDiscrepancy[] {
    return [...this.discrepancies];
  }

  public runReconciliation(): ReconRunReport {
    const activeDiscs = this.discrepancies.filter(d => d.status !== 'RESOLVED_ADJUSTED');
    let discVol = 0n;
    for (const d of activeDiscs) {
      discVol += d.ledgerAmountCents;
    }

    const totalScanned = 148_920;
    const matchedCount = totalScanned - activeDiscs.length;
    const matchedVol = 91_240_000_000_00n; // ¥91.24bn

    return {
      runId: `RECON-RUN-${Date.now()}`,
      runTimestamp: new Date().toISOString(),
      totalRecordsScanned: totalScanned,
      totalMatchedRecords: matchedCount,
      matchedVolumeCents: matchedVol,
      unreconciledDiscrepanciesCount: activeDiscs.length,
      discrepancyVolumeCents: discVol,
      status: activeDiscs.length === 0 ? 'FULLY_RECONCILED' : 'ACTION_REQUIRED',
      discrepancies: [...this.discrepancies]
    };
  }

  public resolveDiscrepancy(discrepancyId: string, resolutionNote: string): void {
    const item = this.discrepancies.find(d => d.discrepancyId === discrepancyId);
    if (!item) return;

    if (item.type === 'AMOUNT_MISMATCH') {
      const diffCents = item.ledgerAmountCents - item.externalRailAmountCents;
      if (diffCents !== 0n) {
        // Adjust in ledger
        this.ledger.postEntry(
          'SETTLEMENT',
          `ADJ-${item.transactionRef}`,
          'RECON-ENGINE',
          [
            {
              accountCode: '2003', // Merchant payable
              debitCents: diffCents > 0n ? diffCents : 0n,
              creditCents: diffCents < 0n ? -diffCents : 0n,
              memoZh: `日终对账差错平账调整: ${resolutionNote}`,
              memoEn: `Reconciliation adjustment line: ${resolutionNote}`
            },
            {
              accountCode: '5001', // Operational expense/clearing loss
              debitCents: diffCents < 0n ? -diffCents : 0n,
              creditCents: diffCents > 0n ? diffCents : 0n,
              memoZh: `清算暂记差错损益调整`,
              memoEn: `Clearing suspense offset`
            }
          ]
        );
      }
    }

    item.status = 'RESOLVED_ADJUSTED';
  }
}
