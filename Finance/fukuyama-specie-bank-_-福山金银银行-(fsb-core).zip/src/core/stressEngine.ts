/**
 * Fukuyama Specie Bank (FSB-Core)
 * Institutional Liquidity & Outage Stress Testing Engine
 */

import { Money } from './math';

export interface StressTestScenario {
  id: string;
  nameZh: string;
  nameEn: string;
  depositWithdrawalPercent: number; // e.g. 10, 20, 30, 50
  bondHaircutPercent: number;        // e.g. 5, 10
  ecnyOutage: boolean;
  posOutage: boolean;
  descriptionZh: string;
  descriptionEn: string;
}

export interface StressSimulationResult {
  scenario: StressTestScenario;
  preDepositsCents: bigint;
  postDepositsCents: bigint;
  depositOutflowCents: bigint;
  preReservesCents: bigint;
  postReservesCents: bigint;
  reserveDepletionPercent: number;
  preLCRCents: bigint;
  postLCRCents: bigint;
  postReserveCoverageRatio: number;
  postLiquidityCoverageRatio: number;
  survivalHorizonHours: number; // Estimated hours of liquidity survival under stressed run
  settlementCapacityStatus: 'SECURE' | 'MARGINAL' | 'DEFICIT_TRIGGERED';
  regulatoryCapitalDeficit: boolean;
  emergencyPBOCRefinancingNeededCents: bigint;
  summaryZh: string;
  summaryEn: string;
}

export class StressEngine {
  public static readonly SCENARIOS: StressTestScenario[] = [
    {
      id: 'RUN_10',
      nameZh: '温和流动性挤兑 (10% 存款流出)',
      nameEn: 'Mild Deposit Outflow (10% Run)',
      depositWithdrawalPercent: 10,
      bondHaircutPercent: 0,
      ecnyOutage: false,
      posOutage: false,
      descriptionZh: '模拟市场恐慌情绪下 10% 活期客户集中提取央行现金或向其他商业银行转账',
      descriptionEn: 'Simulates 10% of demand deposits withdrawn in 24 hours'
    },
    {
      id: 'RUN_20',
      nameZh: '中度系统性挤兑 (20% 存款流出)',
      nameEn: 'Moderate Systemic Run (20% Outflow)',
      depositWithdrawalPercent: 20,
      bondHaircutPercent: 3,
      ecnyOutage: false,
      posOutage: false,
      descriptionZh: '企业与机构客户大额划转，国债资产二级市场轻微承压折价 3%',
      descriptionEn: '20% deposit outflow combined with 3% bond liquidation haircut'
    },
    {
      id: 'RUN_30',
      nameZh: '严重压力情景 (30% 挤兑 + 债券折价5%)',
      nameEn: 'Severe Stress (30% Run + 5% Bond Haircut)',
      depositWithdrawalPercent: 30,
      bondHaircutPercent: 5,
      ecnyOutage: false,
      posOutage: false,
      descriptionZh: '极重流动性枯竭压力，测试一级优质流动性资产 (HQLA) 承受极限',
      descriptionEn: 'Severe liquidity crunch testing Level 1 HQLA depletion'
    },
    {
      id: 'RUN_50',
      nameZh: '极端危机情景 (50% 存款崩溃式挤兑)',
      nameEn: 'Extreme Crisis (50% Deposit Flight)',
      depositWithdrawalPercent: 50,
      bondHaircutPercent: 12,
      ecnyOutage: false,
      posOutage: false,
      descriptionZh: '发生黑天鹅事件，50% 负债要求兑付，需立即申请央行常备借贷便利 (SLF)',
      descriptionEn: 'Black swan tail-risk scenario requiring emergency PBOC SLF facility'
    },
    {
      id: 'OUTAGE_ECNY',
      nameZh: '数字人民币网关中断与清算阻塞',
      nameEn: 'e-CNY Gateway Outage & Settlement Freeze',
      depositWithdrawalPercent: 5,
      bondHaircutPercent: 0,
      ecnyOutage: true,
      posOutage: false,
      descriptionZh: '数字人民币互操作接口断网，所有向数字钱包兑出指令积压，转入行内渠道排队',
      descriptionEn: 'e-CNY bridge disconnected, all external DC/EP settlement queued'
    },
    {
      id: 'OUTAGE_POS',
      nameZh: 'POS终端网络大面积中断',
      nameEn: 'Merchant POS Network Outage',
      depositWithdrawalPercent: 0,
      bondHaircutPercent: 0,
      ecnyOutage: false,
      posOutage: true,
      descriptionZh: '收单机具通信专线故障，全天 2800 万笔交易无法提交，商户资金清算顺延',
      descriptionEn: 'POS gateway unavailable, acquiring transaction flow halted'
    }
  ];

  public runSimulation(
    scenario: StressTestScenario,
    currentDepositsCents: bigint,
    currentReservesCents: bigint,
    currentBondsCents: bigint
  ): StressSimulationResult {
    const outflowPercent = BigInt(scenario.depositWithdrawalPercent);
    const depositOutflowCents = (currentDepositsCents * outflowPercent) / 100n;
    const postDepositsCents = currentDepositsCents - depositOutflowCents;

    // Apply bond haircut
    const haircutPercent = BigInt(scenario.bondHaircutPercent);
    const postBondsCents = currentBondsCents - (currentBondsCents * haircutPercent) / 100n;

    // Outflow is paid from reserves first, then bonds
    let postReservesCents = currentReservesCents;
    let emergencyPBOCRefinancingNeededCents = 0n;

    if (depositOutflowCents <= currentReservesCents) {
      postReservesCents = currentReservesCents - depositOutflowCents;
    } else {
      const remainingDeficit = depositOutflowCents - currentReservesCents;
      postReservesCents = 0n;
      if (remainingDeficit > postBondsCents) {
        emergencyPBOCRefinancingNeededCents = remainingDeficit - postBondsCents;
      }
    }

    const preLCRCents = currentReservesCents + currentBondsCents;
    const postLCRCents = postReservesCents + postBondsCents;

    const reserveDepletionPercent = currentReservesCents > 0n
      ? Number(((currentReservesCents - postReservesCents) * 10000n) / currentReservesCents) / 100
      : 100;

    const postReserveCoverageRatio = postDepositsCents > 0n
      ? Money.ratioPercentage(postReservesCents, postDepositsCents)
      : 100;

    const postLiquidityCoverageRatio = postDepositsCents > 0n
      ? Money.ratioPercentage(postLCRCents, postDepositsCents)
      : 100;

    // Calculate survival horizon
    let survivalHorizonHours = 720; // 30 days normal
    if (scenario.depositWithdrawalPercent === 10) survivalHorizonHours = 240; // 10 days
    if (scenario.depositWithdrawalPercent === 20) survivalHorizonHours = 72;  // 3 days
    if (scenario.depositWithdrawalPercent === 30) survivalHorizonHours = 24;  // 1 day
    if (scenario.depositWithdrawalPercent === 50) survivalHorizonHours = 6;   // 6 hours

    let settlementCapacityStatus: StressSimulationResult['settlementCapacityStatus'] = 'SECURE';
    if (postLiquidityCoverageRatio < 30 || emergencyPBOCRefinancingNeededCents > 0n) {
      settlementCapacityStatus = 'DEFICIT_TRIGGERED';
    } else if (postLiquidityCoverageRatio < 45) {
      settlementCapacityStatus = 'MARGINAL';
    }

    return {
      scenario,
      preDepositsCents: currentDepositsCents,
      postDepositsCents,
      depositOutflowCents,
      preReservesCents: currentReservesCents,
      postReservesCents,
      reserveDepletionPercent,
      preLCRCents,
      postLCRCents,
      postReserveCoverageRatio,
      postLiquidityCoverageRatio,
      survivalHorizonHours,
      settlementCapacityStatus,
      regulatoryCapitalDeficit: emergencyPBOCRefinancingNeededCents > 0n,
      emergencyPBOCRefinancingNeededCents,
      summaryZh: emergencyPBOCRefinancingNeededCents > 0n
        ? `流动性储备已完全耗尽！存在 ${Money.format(emergencyPBOCRefinancingNeededCents)} 敞口，需立即动用央行SLF应急流动性支持。`
        : `情景通过测试：留存储备 ${Money.format(postReservesCents)}，流动性覆盖率维持在 ${postLiquidityCoverageRatio.toFixed(1)}%。`,
      summaryEn: emergencyPBOCRefinancingNeededCents > 0n
        ? `Liquidity buffer exhausted! Deficit of ${Money.format(emergencyPBOCRefinancingNeededCents)} requires PBOC emergency facilities.`
        : `Passed: Post-stress reserves ${Money.format(postReservesCents)}, LCR remains at ${postLiquidityCoverageRatio.toFixed(1)}%.`
    };
  }
}
