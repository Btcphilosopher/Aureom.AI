/**
 * Fukuyama Specie Bank (FSB-Core)
 * Exact Currency Arithmetic & Financial Calculations
 * 
 * INVARIANT: Never use floating-point numbers for money balances.
 * All monetary amounts are stored as BigInt cents (1 CNY = 100 cents).
 */

export class Money {
  /**
   * Parse user input string or number to BigInt cents
   * e.g. "128.50" -> 12850n
   */
  static parse(value: string | number): bigint {
    if (typeof value === 'number') {
      value = value.toFixed(2);
    }
    const clean = value.replace(/[^0-9.-]/g, '').trim();
    if (!clean || isNaN(Number(clean))) return 0n;

    const parts = clean.split('.');
    const integerPart = BigInt(parts[0] || '0');
    let fractionalPart = parts[1] || '00';

    if (fractionalPart.length > 2) {
      fractionalPart = fractionalPart.substring(0, 2);
    } else while (fractionalPart.length < 2) {
      fractionalPart += '0';
    }

    const cents = BigInt(fractionalPart);
    if (integerPart < 0n) {
      return integerPart * 100n - cents;
    }
    return integerPart * 100n + cents;
  }

  /**
   * Format BigInt cents to Chinese RMB string:
   * e.g. 12850n -> "¥128.50"
   */
  static format(cents: bigint, showCurrencySymbol = true): string {
    const isNegative = cents < 0n;
    const absCents = isNegative ? -cents : cents;
    const integerPart = absCents / 100n;
    const fractionalPart = absCents % 100n;

    const intFormatted = integerPart.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    const fracFormatted = fractionalPart.toString().padStart(2, '0');
    const result = `${intFormatted}.${fracFormatted}`;

    const prefix = showCurrencySymbol ? '¥' : '';
    return isNegative ? `-${prefix}${result}` : `${prefix}${result}`;
  }

  /**
   * Format institutional scale amounts (Yi / 亿 or Billion / bn)
   * e.g. 86040000000000n (860.4 billion) -> "¥860.40bn" / "¥8,604.00亿"
   */
  static formatInstitutional(cents: bigint, lang: 'zh' | 'en' | 'bilingual' = 'zh'): string {
    const isNegative = cents < 0n;
    const absCents = isNegative ? -cents : cents;
    const rmb = Number(absCents) / 100;

    // Chinese units: 亿 (100 million = 1e8)
    // English units: bn (1 billion = 1e9), m (1 million = 1e6)
    if (lang === 'zh') {
      if (rmb >= 1e8) {
        const yi = (rmb / 1e8).toFixed(2);
        return `${isNegative ? '-' : ''}¥${Number(yi).toLocaleString('zh-CN', { minimumFractionDigits: 2 })} 亿`;
      }
      if (rmb >= 1e4) {
        const wan = (rmb / 1e4).toFixed(2);
        return `${isNegative ? '-' : ''}¥${Number(wan).toLocaleString('zh-CN', { minimumFractionDigits: 2 })} 万`;
      }
      return Money.format(cents);
    }

    if (lang === 'en') {
      if (rmb >= 1e9) {
        const bn = (rmb / 1e9).toFixed(2);
        return `${isNegative ? '-' : ''}¥${bn}bn`;
      }
      if (rmb >= 1e6) {
        const m = (rmb / 1e6).toFixed(2);
        return `${isNegative ? '-' : ''}¥${m}m`;
      }
      return Money.format(cents);
    }

    // Bilingual mode
    if (rmb >= 1e8) {
      const yi = (rmb / 1e8).toFixed(1);
      const bn = (rmb / 1e9).toFixed(1);
      return `${isNegative ? '-' : ''}¥${yi}亿 (${bn}bn)`;
    }
    return Money.format(cents);
  }

  /**
   * Calculate basis points: amount * (bps / 10000)
   */
  static applyBps(cents: bigint, bps: number): bigint {
    return (cents * BigInt(bps)) / 10000n;
  }

  /**
   * Exact ratio percentage calculation
   */
  static ratioPercentage(numeratorCents: bigint, denominatorCents: bigint): number {
    if (denominatorCents === 0n) return 0;
    // Scale by 10,000 for 2 decimal places precision
    const scaled = (numeratorCents * 10000n) / denominatorCents;
    return Number(scaled) / 100;
  }
}
