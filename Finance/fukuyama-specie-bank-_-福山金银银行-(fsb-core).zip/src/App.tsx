/**
 * Fukuyama Specie Bank / 福山金银银行
 * FSB-Core v4.8 — Institutional Banking Software Platform
 * 
 * Late-2020s Chinese Banking Operating System:
 * - Sovereign RMB vs Commercial Private RMB (FSB-CNY) vs Payment Tokens
 * - Double-Entry Ledger (Σ Debits === Σ Credits)
 * - e-CNY Interoperability Gateway
 * - 12-Step POS Validator & Terminal
 * - Reserve Engine & Issuance Simulator
 * - Multi-Rail Payment Routing & Network Topology
 * - Corporate Programmable Payments
 * - Stress Testing & Risk/AML Compliance
 */

import React, { useState, useReducer, useEffect } from 'react';
import { Language } from './types/banking';
import { BankingSystem } from './core/bankingSystem';
import { TerminalHeader } from './components/TerminalHeader';
import { MainDashboard } from './components/MainDashboard';
import { BalanceSheetView } from './components/BalanceSheetView';
import { ReserveIssuanceView } from './components/ReserveIssuanceView';
import { POSTerminalView } from './components/POSTerminalView';
import { ECNYGatewayView } from './components/ECNYGatewayView';
import { PaymentRouterView } from './components/PaymentRouterView';
import { MerchantBankingView } from './components/MerchantBankingView';
import { CorporateBankingView } from './components/CorporateBankingView';
import { RetailMobileView } from './components/RetailMobileView';
import { RiskComplianceView } from './components/RiskComplianceView';
import { ReconciliationView } from './components/ReconciliationView';
import { StressTestingView } from './components/StressTestingView';
import { APIGatewayView } from './components/APIGatewayView';

// Initialize singleton banking system instance
const bankingSystem = new BankingSystem();

export default function App() {
  const [currentView, setCurrentView] = useState<string>('MAIN');
  const [lang, setLang] = useState<Language>('zh'); // Chinese default as per institutional requirement
  const [, forceUpdate] = useReducer(x => x + 1, 0);

  const handleRefresh = () => {
    forceUpdate();
  };

  const handleToggleLang = () => {
    setLang(prev => (prev === 'zh' ? 'en' : prev === 'en' ? 'bilingual' : 'zh'));
  };

  // Keyboard shortcut listener for terminal navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Escape returns to MAIN
      if (e.key === 'Escape') {
        setCurrentView('MAIN');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200 antialiased">
      {/* Institutional Terminal Top Navigation & Command Bar */}
      <TerminalHeader
        currentView={currentView}
        onNavigate={view => setCurrentView(view)}
        lang={lang}
        onToggleLang={handleToggleLang}
        system={bankingSystem}
      />

      {/* Main Terminal Workspace Pane */}
      <main className="flex-1 p-3 md:p-4 max-w-7xl w-full mx-auto">
        {currentView === 'MAIN' && (
          <MainDashboard
            system={bankingSystem}
            lang={lang}
            onNavigate={view => setCurrentView(view)}
            onRefresh={handleRefresh}
          />
        )}

        {(currentView === 'BAL' || currentView === 'LIQ' || currentView === 'TREASURY') && (
          <BalanceSheetView
            system={bankingSystem}
            lang={lang}
          />
        )}

        {(currentView === 'RESERVE' || currentView === 'ISSUE') && (
          <ReserveIssuanceView
            system={bankingSystem}
            lang={lang}
            onRefresh={handleRefresh}
          />
        )}

        {currentView === 'POS' && (
          <POSTerminalView
            system={bankingSystem}
            lang={lang}
            onRefresh={handleRefresh}
          />
        )}

        {currentView === 'ECNY' && (
          <ECNYGatewayView
            system={bankingSystem}
            lang={lang}
            onRefresh={handleRefresh}
          />
        )}

        {(currentView === 'ROUTER' || currentView === 'MONEYGRAPH' || currentView === 'NETWORK') && (
          <PaymentRouterView
            system={bankingSystem}
            lang={lang}
          />
        )}

        {currentView === 'MERCHANT' && (
          <MerchantBankingView
            system={bankingSystem}
            lang={lang}
            onRefresh={handleRefresh}
          />
        )}

        {currentView === 'CORPORATE' && (
          <CorporateBankingView
            system={bankingSystem}
            lang={lang}
            onRefresh={handleRefresh}
          />
        )}

        {currentView === 'MOBILE' && (
          <RetailMobileView
            system={bankingSystem}
            lang={lang}
            onRefresh={handleRefresh}
          />
        )}

        {(currentView === 'RISK' || currentView === 'COMPLIANCE' || currentView === 'AUDIT') && (
          <RiskComplianceView
            system={bankingSystem}
            lang={lang}
            onRefresh={handleRefresh}
          />
        )}

        {currentView === 'RECON' && (
          <ReconciliationView
            system={bankingSystem}
            lang={lang}
            onRefresh={handleRefresh}
          />
        )}

        {currentView === 'STRESS' && (
          <StressTestingView
            system={bankingSystem}
            lang={lang}
          />
        )}

        {currentView === 'API' && (
          <APIGatewayView
            system={bankingSystem}
            lang={lang}
          />
        )}
      </main>

      {/* Terminal Footer Statusline */}
      <footer className="bg-slate-950 border-t border-slate-900 px-4 py-2 text-[10px] font-mono text-slate-500 flex flex-wrap items-center justify-between gap-2 select-none">
        <div className="flex items-center gap-3">
          <span className="text-slate-400">福山金银银行 FSB-Core 4.8</span>
          <span>•</span>
          <span>PBOC RECONCILIATION: BALANCED</span>
          <span>•</span>
          <span>HSM ENCLAVE: ENFORCED</span>
          <span>•</span>
          <span className="text-amber-400/80">INVARIANT: ΣDEBITS === ΣCREDITS (A = L + E)</span>
        </div>

        <div className="flex items-center gap-3">
          <span>PRESS ESC FOR MAIN &lt;GO&gt;</span>
          <span>•</span>
          <span>SHANGHAI FINANCIAL CLOUD ZONE 2</span>
        </div>
      </footer>
    </div>
  );
}
