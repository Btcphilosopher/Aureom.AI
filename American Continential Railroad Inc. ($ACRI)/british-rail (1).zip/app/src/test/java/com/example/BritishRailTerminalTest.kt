package com.example

import com.example.data.local.KeystoreCredentialProtector
import com.example.data.model.AfterSalesType
import com.example.data.model.AssistanceState
import com.example.data.model.BookingStatus
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentRequest
import com.example.data.model.PaymentResult
import com.example.data.model.RailcardType
import com.example.data.model.ServiceFare
import com.example.data.model.SimulatedPaymentOutcome
import com.example.data.model.Station
import com.example.data.model.TicketIssuanceResult
import com.example.data.model.TicketStatus
import com.example.data.model.TicketType
import com.example.data.model.TravelClass
import com.example.data.model.formatPence
import com.example.data.repository.AfterSalesServiceImpl
import com.example.data.repository.BookingServiceImpl
import com.example.data.repository.FareProviderImpl
import com.example.data.repository.PassengerAssistanceServiceImpl
import com.example.data.repository.PaymentProviderImpl
import com.example.data.repository.PlatformWalletAdapterImpl
import com.example.data.repository.StationRepositoryImpl
import com.example.data.repository.TicketIssuerImpl
import com.example.data.repository.TicketWalletRepositoryImpl
import com.example.data.repository.TimetableProviderImpl
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BritishRailTerminalTest {

    private val stationRepo = StationRepositoryImpl()
    private val fareProvider = FareProviderImpl()
    private val timetableProvider = TimetableProviderImpl(stationRepo)
    private val bookingService = BookingServiceImpl()
    private val paymentProvider = PaymentProviderImpl()
    private val ticketIssuer = TicketIssuerImpl()
    private val assistanceService = PassengerAssistanceServiceImpl()
    private val platformWalletAdapter = PlatformWalletAdapterImpl()

    @Test
    fun testMonetaryPenceFormatting() {
        assertEquals("£56.00", formatPence(5600))
        assertEquals("£48.50", formatPence(4850))
        assertEquals("£0.00", formatPence(0))
        assertEquals("£1.05", formatPence(105))
    }

    @Test
    fun testFareCalculationsAndRailcardEligibility() {
        val stdAdvance = ServiceFare("F1", TicketType.ADVANCE_SINGLE, TravelClass.STANDARD, 5600)
        val stdOffPeak = ServiceFare("F2", TicketType.OFF_PEAK_SINGLE, TravelClass.STANDARD, 7000)

        // 16-25 Railcard applies 34% off adult fare
        val b1 = fareProvider.getBreakdownForServiceFare(
            stdAdvance,
            PassengerConfig(adults = 1, children = 0, railcard = RailcardType.SIXTEEN_TO_TWENTY_FIVE),
            isReturn = false
        )
        assertEquals((5600 * 34) / 100, b1.railcardDiscountPence)

        // Two Together does NOT apply to 1 adult alone
        val b2 = fareProvider.getBreakdownForServiceFare(
            stdAdvance,
            PassengerConfig(adults = 1, children = 0, railcard = RailcardType.TWO_TOGETHER),
            isReturn = false
        )
        assertEquals(0, b2.railcardDiscountPence)
        assertEquals(5600, b2.totalPence)

        // Two Together DOES apply to 2 adults on Standard
        val b3 = fareProvider.getBreakdownForServiceFare(
            stdAdvance,
            PassengerConfig(adults = 2, children = 0, railcard = RailcardType.TWO_TOGETHER),
            isReturn = false
        )
        assertEquals((11200 * 34) / 100, b3.railcardDiscountPence)

        // Network Railcard excludes Advance single, applies to Off-Peak
        val bNetAdv = fareProvider.getBreakdownForServiceFare(
            stdAdvance,
            PassengerConfig(adults = 1, children = 0, railcard = RailcardType.NETWORK),
            isReturn = false
        )
        assertEquals(0, bNetAdv.railcardDiscountPence)

        val bNetOffPeak = fareProvider.getBreakdownForServiceFare(
            stdOffPeak,
            PassengerConfig(adults = 1, children = 0, railcard = RailcardType.NETWORK),
            isReturn = false
        )
        assertTrue(bNetOffPeak.railcardDiscountPence > 0)
    }

    @Test
    fun testBookingAndPaymentIdempotencyAndReconciliation() = runTest {
        val origin = Station("SHF", "Sheffield")
        val dest = Station("STP", "London St Pancras")
        val journey = JourneyOption(
            id = "SHF-STP-1345",
            origin = origin,
            destination = dest,
            serviceDate = "2026-11-13",
            departureTime = "13:45",
            arrivalTime = "15:52",
            durationMinutes = 127
        )
        val fare = ServiceFare("FARE-1", TicketType.ADVANCE_SINGLE, TravelClass.STANDARD, 5600)
        val key = "idem-test-001"

        val b1 = bookingService.createPendingBooking(journey, fare, PassengerConfig(), "Fri 13 Nov 2026", null, false, 5600, key, isGuestPurchase = true)
        val b2 = bookingService.createPendingBooking(journey, fare, PassengerConfig(), "Fri 13 Nov 2026", null, false, 5600, key, isGuestPurchase = true)
        assertEquals(b1.bookingReference, b2.bookingReference)

        // Simulate uncertain network drop then idempotent reconciliation
        val uncertain = paymentProvider.processPayment(
            PaymentRequest(b1.bookingReference, key, 5600, PaymentMethod.CARD_SIMULATED, SimulatedPaymentOutcome.UNCERTAIN_RECONCILE)
        )
        assertTrue(uncertain is PaymentResult.Uncertain)

        val reconciled = paymentProvider.reconcilePayment(key, b1.bookingReference)
        assertTrue(reconciled is PaymentResult.Success)
        assertTrue((reconciled as PaymentResult.Success).reconciled)

        // Separated payment confirmation vs ticket issuance
        val awaiting = bookingService.markPaymentConfirmedAwaitingIssuance(b1.bookingReference, reconciled.authCode)
        assertEquals(BookingStatus.PAYMENT_CONFIRMED_AWAITING_ISSUANCE, awaiting.bookingStatus)
        assertEquals(TicketStatus.PENDING, awaiting.ticketStatus)

        val pendingIssuance = ticketIssuer.issueTicket(awaiting, forcePendingForDemo = true)
        assertTrue(pendingIssuance is TicketIssuanceResult.Pending)

        val issued = ticketIssuer.issueTicket(awaiting, forcePendingForDemo = false)
        assertTrue(issued is TicketIssuanceResult.Issued)
        val payload = (issued as TicketIssuanceResult.Issued).qrData
        assertTrue(payload.contains("NOT_VALID_FOR_TRAVEL"))

        val finalized = bookingService.finalizeIssuedBooking(b1.bookingReference, payload)
        assertEquals(BookingStatus.CONFIRMED, finalized.bookingStatus)
        assertEquals(TicketStatus.AVAILABLE, finalized.ticketStatus)
    }

    @Test
    fun testOvernightAndNoServiceAndSoldOutFares() = runTest {
        val services = timetableProvider.getServices("SHF", "STP", "2026-11-13", "13:00", arriveBy = false, stepFreeOnly = false)
        val overnight = services.find { it.isOvernight }
        assertNotNull(overnight)
        assertEquals("23:20", overnight?.departureTime)
        assertEquals("06:15", overnight?.arrivalTime)
        assertEquals(1, overnight?.arrivalDayOffset)

        val delayed1445 = services.find { it.departureTime == "14:45" }
        assertNotNull(delayed1445)
        val soldOutAdv = delayed1445?.fares?.find { it.ticketType == TicketType.ADVANCE_SINGLE }
        assertNotNull(soldOutAdv)
        assertFalse(soldOutAdv!!.isAvailable)

        val noServices = timetableProvider.getServices("GLC", "CBG", "2026-11-13", "13:00", arriveBy = false, stepFreeOnly = false)
        assertTrue(noServices.isEmpty())
    }

    @Test
    fun testAccessibilityNeverClaimsUnknownIsAccessible() = runTest {
        val bdiInfo = stationRepo.getStationAccessibility("BDI")
        assertNull(bdiInfo)

        // Step-free filter must exclude BDI->YRK because Bradford Interchange has unknown accessibility
        val filtered = timetableProvider.getServices("BDI", "YRK", "2026-11-13", "13:00", arriveBy = false, stepFreeOnly = true)
        assertTrue(filtered.isEmpty())

        val unfiltered = timetableProvider.getServices("BDI", "YRK", "2026-11-13", "13:00", arriveBy = false, stepFreeOnly = false)
        assertFalse(unfiltered.isEmpty())
        assertFalse(unfiltered.first().accessibilityConfidenceKnown)
    }

    @Test
    fun testAssistanceServiceAndAfterSalesAndWallet() = runTest {
        val req = assistanceService.requestAssistance("BR-123", "Sheffield", "Ramp boarding")
        assertEquals(AssistanceState.REQUESTED, req.state)
        val pending = assistanceService.refreshAssistanceStatus(req.id)
        assertEquals(AssistanceState.PENDING, pending?.state)
        val confirmed = assistanceService.refreshAssistanceStatus(req.id)
        assertEquals(AssistanceState.CONFIRMED, confirmed?.state)

        assertFalse(platformWalletAdapter.isSupportedAndConfigured)

        val wallet = TicketWalletRepositoryImpl(dao = null, protector = KeystoreCredentialProtector())
        wallet.seedDemoDataIfEmpty()
        assertTrue(wallet.observeTickets().first().isNotEmpty())
        wallet.clearAllLocalData()
        assertTrue(wallet.observeTickets().first().isEmpty())

        val afterSales = AfterSalesServiceImpl(dao = null)
        val caseItem = afterSales.submitCase("BR-77102-SHF", AfterSalesType.REFUND_REQUEST, "Journey no longer needed")
        assertEquals("Submitted — awaiting operator review", caseItem.status.label)
    }
}
