package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppLanguage
import com.example.data.model.PassengerConfig
import com.example.data.model.RailcardType
import com.example.data.model.Station
import com.example.ui.AppTab
import com.example.ui.YourJourneyViewModel
import com.example.ui.YourJourneyViewModelFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("British Rail", context.getString(R.string.app_name))
        assertEquals("Where are you going?", context.getString(R.string.home_heading))
    }

    @Test
    @Config(qualifiers = "cy")
    fun `read welsh string resources`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Eich Taith", context.getString(R.string.header_title))
        assertEquals("Ble ydych chi'n mynd?", context.getString(R.string.home_heading))
    }

    @Test
    fun `switching tabs preserves planner and passenger state`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vm = YourJourneyViewModelFactory(context).create(YourJourneyViewModel::class.java)
        advanceUntilIdle()

        vm.setOrigin(Station("LDS", "Leeds"))
        vm.setDestination(Station("MAN", "Manchester Piccadilly"))
        vm.setPassengers(PassengerConfig(adults = 2, children = 1, railcard = RailcardType.FAMILY_AND_FRIENDS))
        vm.performSearch(navigateToPlan = true, recordHistory = false)
        advanceUntilIdle()

        assertEquals(AppTab.PLAN, vm.uiState.value.activeTab)
        assertTrue(vm.uiState.value.journeyResults.isNotEmpty())

        vm.selectTab(AppTab.DEPARTURES)
        vm.selectTab(AppTab.PLAN)

        val state = vm.uiState.value
        assertEquals("LDS", state.originStation.crsCode)
        assertEquals("MAN", state.destinationStation.crsCode)
        assertEquals(2, state.passengers.adults)
        assertEquals(1, state.passengers.children)
        assertEquals(RailcardType.FAMILY_AND_FRIENDS, state.passengers.railcard)
    }

    @Test
    fun `language toggle and delete local data update preferences and wallet`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vm = YourJourneyViewModelFactory(context).create(YourJourneyViewModel::class.java)
        advanceUntilIdle()

        vm.setLanguage(AppLanguage.CYMRAEG)
        assertEquals(AppLanguage.CYMRAEG, vm.uiState.value.preferences.language)

        vm.deleteAllLocalData()
        advanceUntilIdle()
        assertTrue(vm.uiState.value.tickets.isEmpty())
        assertTrue(vm.uiState.value.favouriteRoutes.isEmpty())
    }
}
