package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Station
import com.example.data.model.TicketStatus
import com.example.ui.AppTab
import com.example.ui.YourJourneyUiState
import com.example.ui.YourJourneyViewModel
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrSchematicLine
import com.example.ui.components.BrSectionRule
import com.example.ui.components.BrServiceStatusBadge
import com.example.ui.components.PassengerConfigDialog
import com.example.ui.components.StationSearchDialog
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailAmber
import com.example.ui.theme.RailGreyBackground
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

@Composable
fun HomeScreen(
    uiState: YourJourneyUiState,
    viewModel: YourJourneyViewModel
) {
    val language = uiState.preferences.language
    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }
    var showPassengerDialog by remember { mutableStateOf(false) }

    val locationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.onLocationPermissionResult(granted = granted)
    }

    val upcomingTicket = remember(uiState.tickets) {
        uiState.tickets.firstOrNull { it.ticketStatus == TicketStatus.AVAILABLE }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RailGreyBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero heading & service status indicator
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Ble ydych chi'n mynd?" else "Where are you going?",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp,
                        color = BritishRailBlack,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .border(1.dp, RailAmber)
                            .background(BritishRailWhite)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .clickable { viewModel.selectTab(AppTab.DEPARTURES) }
                    ) {
                        Text(
                            text = "${uiState.disruptions.size} alerts",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = RailAmber
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (uiState.preferences.isSignedIn) {
                        "Signed in as ${uiState.preferences.passengerName} • Saved tickets & alerts active"
                    } else {
                        "Planning as guest • No sign-in required to search or buy demo tickets"
                    },
                    fontSize = 12.sp,
                    color = RailGreySubtext
                )
            }

            // Compact Mobile Journey Planner Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(2.dp, BritishRailBlack)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Origin + Swap + Destination
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StationPickerField(
                            label = if (language == AppLanguage.CYMRAEG) "O" else "FROM",
                            station = uiState.originStation,
                            testTag = "home_origin_button",
                            onClick = { showOriginPicker = true }
                        )
                        StationPickerField(
                            label = if (language == AppLanguage.CYMRAEG) "I" else "TO",
                            station = uiState.destinationStation,
                            testTag = "home_dest_button",
                            onClick = { showDestPicker = true }
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { viewModel.swapStations() },
                        modifier = Modifier
                            .size(48.dp)
                            .border(1.5.dp, BritishRailBlack)
                            .background(RailGreyPanel)
                            .testTag("home_swap_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "Swap origin and destination",
                            tint = BritishRailBlack
                        )
                    }
                }

                // Single / Return segmented toggle
                Row(modifier = Modifier.fillMaxWidth()) {
                    ToggleSegment(
                        label = if (language == AppLanguage.CYMRAEG) "Sengl" else "Single",
                        selected = !uiState.isReturn,
                        testTag = "home_single_toggle",
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setReturnMode(false) }
                    )
                    ToggleSegment(
                        label = if (language == AppLanguage.CYMRAEG) "Dychwelyd" else "Return",
                        selected = uiState.isReturn,
                        testTag = "home_return_toggle",
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setReturnMode(true) }
                    )
                }

                // Date & Time quick selectors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val dateOptions = listOf(
                        "Fri 13 Nov 2026" to "2026-11-13",
                        "Sat 14 Nov 2026" to "2026-11-14",
                        "Mon 16 Nov 2026" to "2026-11-16"
                    )
                    val nextDateIdx = (dateOptions.indexOfFirst { it.first == uiState.travelDate } + 1) % dateOptions.size
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .border(1.dp, BritishRailBlack)
                            .clickable {
                                val next = dateOptions[nextDateIdx]
                                viewModel.setTravelDate(next.first, next.second)
                            }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .testTag("home_date_selector")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(13.dp), tint = RailGreySubtext)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("OUTWARD DATE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(uiState.travelDate, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
                    }

                    val timeSlots = listOf("13:00", "14:00", "23:20", "23:45")
                    val nextTimeIdx = (timeSlots.indexOf(uiState.departTime) + 1) % timeSlots.size
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .border(1.dp, BritishRailBlack)
                            .clickable { viewModel.setDepartTime(timeSlots[nextTimeIdx], uiState.arriveBy) }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .testTag("home_time_selector")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(13.dp), tint = RailGreySubtext)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (uiState.arriveBy) "ARRIVE BY" else "DEPART AFTER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(uiState.departTime, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
                    }
                }

                if (uiState.isReturn) {
                    val retDates = listOf("Sun 15 Nov 2026", "Mon 16 Nov 2026", "Fri 20 Nov 2026")
                    val nextRet = retDates[(retDates.indexOf(uiState.returnDate) + 1) % retDates.size]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BritishRailBlack)
                            .clickable { viewModel.setReturnDate(nextRet) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("RETURN DATE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                        Text(uiState.returnDate, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
                    }
                }

                // Passengers + Step-free row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .border(1.dp, BritishRailBlack)
                            .clickable { showPassengerDialog = true }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .testTag("home_passengers_button"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp), tint = BritishRailBlack)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = uiState.passengers.summary(language),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BritishRailBlack
                        )
                    }

                    Row(
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .border(1.5.dp, if (uiState.stepFreeOnly) BritishRailRed else BritishRailBlack)
                            .background(if (uiState.stepFreeOnly) BritishRailRedLight else BritishRailWhite)
                            .clickable { viewModel.setStepFreeOnly(!uiState.stepFreeOnly) }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .testTag("home_step_free_toggle"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Accessible,
                            contentDescription = "Step-free preference",
                            tint = if (uiState.stepFreeOnly) BritishRailRed else BritishRailBlack,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (uiState.stepFreeOnly) "Step-free ✓" else "Step-free",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.stepFreeOnly) BritishRailRed else BritishRailBlack
                        )
                    }
                }

                uiState.searchValidationError?.let { err ->
                    Text(text = err, color = BritishRailRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                BrButton(
                    text = if (language == AppLanguage.CYMRAEG) "Chwilio trenau →" else "Find trains →",
                    onClick = { viewModel.performSearch(navigateToPlan = true, recordHistory = true) },
                    modifier = Modifier.fillMaxWidth(),
                    height = 50.dp,
                    testTag = "find_trains_button"
                )
            }

            // Upcoming Journey / Active Ticket Shortcut
            if (upcomingTicket != null) {
                BrSectionRule(if (language == AppLanguage.CYMRAEG) "Eich Taith Nesaf" else "Upcoming Journey & Active Ticket")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BritishRailWhite)
                        .border(1.5.dp, BritishRailBlack)
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = BritishRailRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${upcomingTicket.travelDate} • ${upcomingTicket.journey.departureTime}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = BritishRailBlack
                            )
                        }
                        Text(
                            text = upcomingTicket.bookingReference,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = RailGreySubtext
                        )
                    }

                    BrSchematicLine(
                        originName = upcomingTicket.journey.origin.name,
                        destinationName = upcomingTicket.journey.destination.name
                    )

                    Text(
                        text = "${upcomingTicket.selectedFare.ticketType.displayName} • ${upcomingTicket.seatReservation}",
                        fontSize = 12.sp,
                        color = RailGreySubtext
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BrButton(
                            text = "Open QR ticket",
                            onClick = { viewModel.openTicketDetail(upcomingTicket) },
                            style = BrButtonStyle.SECONDARY_BLACK,
                            modifier = Modifier.weight(1f),
                            testTag = "home_open_ticket_button"
                        )
                        BrButton(
                            text = "Follow live",
                            onClick = { viewModel.followBooking(upcomingTicket.bookingReference) },
                            style = BrButtonStyle.OUTLINED,
                            modifier = Modifier.weight(1f),
                            testTag = "home_follow_live_button"
                        )
                    }
                }
            }

            // Favourite Routes
            if (uiState.favouriteRoutes.isNotEmpty()) {
                BrSectionRule("Favourite Routes")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    uiState.favouriteRoutes.forEach { route ->
                        Column(
                            modifier = Modifier
                                .width(200.dp)
                                .background(BritishRailWhite)
                                .border(1.dp, BritishRailBlack)
                                .clickable { viewModel.applyRoutePreset(route.originCrs, route.destCrs) }
                                .padding(10.dp)
                                .testTag("fav_route_${route.id}")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = BritishRailRed, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${route.originCrs} → ${route.destCrs}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BritishRailBlack)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("${route.originName} to ${route.destName}", fontSize = 11.sp, color = RailGreySubtext, maxLines = 1)
                        }
                    }
                }
            }

            // Nearby Departures with optional location permission
            BrSectionRule("Nearby Departures")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(1.dp, BritishRailBlack)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = uiState.boardStation.displayName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = uiState.locationStatusNote,
                            fontSize = 11.sp,
                            color = RailGreySubtext
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .heightIn(min = 44.dp)
                            .border(1.dp, BritishRailBlack)
                            .clickable { locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION) }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .testTag("home_use_location_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = BritishRailRed, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (uiState.locationGranted) "Located" else "Use location",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = BritishRailBlack
                            )
                        }
                    }
                }

                uiState.departures.take(3).forEach { dep ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(0.5.dp, RailGreyBorder)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${dep.scheduledTime} → ${dep.destination}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = BritishRailBlack
                            )
                            Text(
                                text = "Plat ${dep.platform ?: "TBC"} • ${dep.operator}",
                                fontSize = 11.sp,
                                color = RailGreySubtext
                            )
                        }
                        BrServiceStatusBadge(dep.status, language)
                    }
                }

                BrButton(
                    text = "View live departure board",
                    onClick = { viewModel.selectTab(AppTab.DEPARTURES) },
                    style = BrButtonStyle.OUTLINED,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Relevant Disruption Notices
            if (uiState.disruptions.isNotEmpty()) {
                BrSectionRule("Disruption Notices (Simulated)")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    uiState.disruptions.forEach { notice ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BritishRailWhite)
                                .border(1.dp, RailAmber)
                                .padding(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = RailAmber, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("${notice.scope} • ${notice.severity}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RailAmber)
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(notice.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BritishRailBlack)
                            Text(notice.detail, fontSize = 12.sp, color = RailGreySubtext)
                        }
                    }
                }
            }

            // Recent Searches
            if (uiState.recentSearches.isNotEmpty()) {
                BrSectionRule("Recent Searches")
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    uiState.recentSearches.take(3).forEach { search ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BritishRailWhite)
                                .border(1.dp, RailGreyBorder)
                                .clickable { viewModel.applyRoutePreset(search.originCrs, search.destCrs) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${search.originName} → ${search.destName}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = BritishRailBlack
                            )
                            Text(search.travelDate, fontSize = 11.sp, color = RailGreySubtext)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    if (showOriginPicker) {
        StationSearchDialog(
            title = "Select Origin Station",
            stations = uiState.allStations,
            recentStations = uiState.allStations.filter { it.isPopular },
            onStationSelected = { viewModel.setOrigin(it) },
            onDismiss = { showOriginPicker = false }
        )
    }

    if (showDestPicker) {
        StationSearchDialog(
            title = "Select Destination Station",
            stations = uiState.allStations,
            recentStations = uiState.allStations.filter { it.isPopular },
            onStationSelected = { viewModel.setDestination(it) },
            onDismiss = { showDestPicker = false }
        )
    }

    if (showPassengerDialog) {
        PassengerConfigDialog(
            initialConfig = uiState.passengers,
            language = language,
            onConfirmed = { viewModel.setPassengers(it) },
            onDismiss = { showPassengerDialog = false }
        )
    }
}

@Composable
private fun StationPickerField(
    label: String,
    station: Station,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 50.dp)
            .border(1.5.dp, BritishRailBlack)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag(testTag),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
            Text(station.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
        }
        Box(
            modifier = Modifier
                .background(RailGreyPanel)
                .border(1.dp, BritishRailBlack)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(station.crsCode, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
        }
    }
}

@Composable
private fun ToggleSegment(
    label: String,
    selected: Boolean,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .border(1.5.dp, BritishRailBlack)
            .background(if (selected) BritishRailRed else BritishRailWhite)
            .clickable { onClick() }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (selected) "✓ $label" else label,
            fontFamily = RailAlphabetFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = if (selected) BritishRailWhite else BritishRailBlack
        )
    }
}
