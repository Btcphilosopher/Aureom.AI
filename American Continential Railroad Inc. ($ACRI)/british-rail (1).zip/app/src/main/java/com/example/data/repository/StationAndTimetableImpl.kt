package com.example.data.repository

import com.example.data.model.DepartureItem
import com.example.data.model.DisruptionNotice
import com.example.data.model.FareBreakdown
import com.example.data.model.JourneyLeg
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.RailcardType
import com.example.data.model.ServiceFare
import com.example.data.model.ServiceStatus
import com.example.data.model.Station
import com.example.data.model.StationAccessibilityInfo
import com.example.data.model.TicketType
import com.example.data.model.TravelClass
import com.example.domain.DepartureProvider
import com.example.domain.DisruptionProvider
import com.example.domain.FareProvider
import com.example.domain.JourneyPlanner
import com.example.domain.StationRepository
import com.example.domain.TimetableProvider
import kotlin.math.pow
import kotlin.math.sqrt

class StationRepositoryImpl : StationRepository {
    private val stations = listOf(
        Station("SHF", "Sheffield", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 53.3781, longitude = -1.4621, isPopular = true),
        Station("STP", "London St Pancras", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 51.5319, longitude = -0.1263, isPopular = true),
        Station("LDS", "Leeds", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 53.7952, longitude = -1.5475, isPopular = true),
        Station("MAN", "Manchester Piccadilly", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 53.4774, longitude = -2.2309, isPopular = true),
        Station("BDI", "Bradford Interchange", accessibilityKnown = false, isStepFree = null, hasHearingLoop = null, hasAccessibleToilet = null, latitude = 53.7912, longitude = -1.7501, isPopular = true),
        Station("YRK", "York", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 53.9579, longitude = -1.0932, isPopular = true),
        Station("NCL", "Newcastle", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 54.9685, longitude = -1.6171, isPopular = true),
        Station("EDB", "Edinburgh Waverley", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 55.9520, longitude = -3.1896, isPopular = true),
        Station("DBY", "Derby", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 52.9162, longitude = -1.4633),
        Station("HUD", "Huddersfield", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 53.6484, longitude = -1.7846),
        Station("BWK", "Berwick-upon-Tweed", accessibilityKnown = false, isStepFree = null, hasHearingLoop = null, hasAccessibleToilet = null, latitude = 55.7745, longitude = -2.0110),
        Station("DON", "Doncaster", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 53.5223, longitude = -1.1394),
        Station("BHM", "Birmingham New Street", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 52.4778, longitude = -1.8989),
        Station("GLC", "Glasgow Central", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 55.8591, longitude = -4.2581),
        Station("CBG", "Cambridge", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 52.1943, longitude = 0.1376),
        Station("CDF", "Cardiff Central", accessibilityKnown = true, isStepFree = true, hasHearingLoop = true, hasAccessibleToilet = true, latitude = 51.4759, longitude = -3.1791)
    )

    private val accessibilityDetails = mapOf(
        "SHF" to StationAccessibilityInfo(
            stationCrs = "SHF",
            stationName = "Sheffield",
            accessibilityKnown = true,
            stepFreeCategory = "Category A: Step-free access to all platforms via lifts.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Assisted travel meeting point on Island Platform 2/3."
        ),
        "STP" to StationAccessibilityInfo(
            stationCrs = "STP",
            stationName = "London St Pancras",
            accessibilityKnown = true,
            stepFreeCategory = "Category A: Full step-free access throughout concourses and platforms.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Assisted Travel Lounge opposite Platform 11."
        ),
        "LDS" to StationAccessibilityInfo(
            stationCrs = "LDS",
            stationName = "Leeds",
            accessibilityKnown = true,
            stepFreeCategory = "Category A: Lifts and escalators connect main concourse to all platforms.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Mobility lounge adjacent to main ticket barriers."
        ),
        "MAN" to StationAccessibilityInfo(
            stationCrs = "MAN",
            stationName = "Manchester Piccadilly",
            accessibilityKnown = true,
            stepFreeCategory = "Category A: Level access to concourse and lifts to Platforms 13–14.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Assistance buggies available from concourse reception."
        ),
        "YRK" to StationAccessibilityInfo(
            stationCrs = "YRK",
            stationName = "York",
            accessibilityKnown = true,
            stepFreeCategory = "Category A: Step-free subway with lifts to all platforms.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Customer Assistance desk near Platform 3."
        ),
        "NCL" to StationAccessibilityInfo(
            stationCrs = "NCL",
            stationName = "Newcastle",
            accessibilityKnown = true,
            stepFreeCategory = "Category A: Step-free access across all mainline platforms.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Assisted travel meeting point at main portico entrance."
        ),
        "EDB" to StationAccessibilityInfo(
            stationCrs = "EDB",
            stationName = "Edinburgh Waverley",
            accessibilityKnown = true,
            stepFreeCategory = "Category A: Step-free lifts from Waverley Bridge and Market Street.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Accessible electric shuttle available at Calton Road ramp."
        )
    )

    override suspend fun getStations(): List<Station> = stations

    override suspend fun searchStations(query: String): List<Station> {
        val trimmed = query.trim().lowercase()
        if (trimmed.isEmpty()) return stations
        return stations.filter {
            it.name.lowercase().contains(trimmed) || it.crsCode.lowercase().contains(trimmed)
        }
    }

    override suspend fun getStationByCrs(crs: String): Station? {
        return stations.find { it.crsCode.equals(crs, ignoreCase = true) }
    }

    override suspend fun getNearestStation(latitude: Double, longitude: Double): Station? {
        return stations.minByOrNull { st ->
            sqrt((st.latitude - latitude).pow(2) + (st.longitude - longitude).pow(2))
        }
    }

    override fun getStationAccessibility(stationCrs: String): StationAccessibilityInfo? {
        return accessibilityDetails[stationCrs.uppercase()]
    }

    override fun getAllStationAccessibility(): List<StationAccessibilityInfo> {
        return stations.map { st ->
            accessibilityDetails[st.crsCode] ?: StationAccessibilityInfo(
                stationCrs = st.crsCode,
                stationName = st.name,
                accessibilityKnown = false,
                stepFreeCategory = "Unknown — station accessibility survey not available offline",
                staffAssistanceAvailable = null,
                inductionLoop = null,
                accessibleToilets = null,
                rampAvailable = null,
                tactilePaving = null,
                notes = "Do not assume step-free access. Contact Passenger Assist before travel."
            )
        }
    }
}

class FareProviderImpl : FareProvider {
    override fun getBreakdownForServiceFare(
        fare: ServiceFare,
        passengers: PassengerConfig,
        isReturn: Boolean
    ): FareBreakdown {
        var unitAdultPence = fare.pricePence
        if (isReturn) {
            unitAdultPence = (unitAdultPence * 17) / 10
        }

        val unitChildPence = (unitAdultPence + 1) / 2
        val totalAdultPence = unitAdultPence * passengers.adults
        val totalChildPence = unitChildPence * passengers.children

        var discountPence = 0
        var appliedNote: String? = null
        val railcard = passengers.railcard

        val isEligible = when (railcard) {
            RailcardType.NONE -> false
            RailcardType.TWO_TOGETHER -> passengers.adults >= 2 && fare.travelClass == TravelClass.STANDARD
            RailcardType.FAMILY_AND_FRIENDS -> passengers.adults >= 1 && passengers.children >= 1
            RailcardType.NETWORK -> fare.ticketType != TicketType.ADVANCE_SINGLE
            RailcardType.SIXTEEN_TO_TWENTY_FIVE,
            RailcardType.SENIOR,
            RailcardType.DISABLED_PERSONS -> true
        }

        if (railcard != RailcardType.NONE) {
            if (isEligible) {
                val adultDiscount = (totalAdultPence * railcard.discountPercent) / 100
                val childDiscount = if (railcard == RailcardType.FAMILY_AND_FRIENDS) {
                    (totalChildPence * 60) / 100
                } else 0
                discountPence = adultDiscount + childDiscount
                appliedNote = "${railcard.englishName} applied"
            } else {
                appliedNote = "${railcard.englishName} not eligible for this passenger/fare combination"
            }
        }

        val ticketFarePence = (totalAdultPence + totalChildPence) - discountPence
        val totalPence = maxOf(0, ticketFarePence)

        return FareBreakdown(
            baseAdultPence = totalAdultPence,
            baseChildPence = totalChildPence,
            railcardDiscountPence = discountPence,
            railcardAppliedNote = appliedNote,
            ticketFarePence = ticketFarePence,
            seatReservationPence = 0,
            bookingFeePence = 0,
            totalPence = totalPence
        )
    }
}

class TimetableProviderImpl(
    private val stationRepository: StationRepository
) : TimetableProvider {

    override suspend fun getServices(
        originCrs: String,
        destCrs: String,
        serviceDate: String,
        departTime: String,
        arriveBy: Boolean,
        stepFreeOnly: Boolean
    ): List<JourneyOption> {
        val origin = stationRepository.getStationByCrs(originCrs) ?: Station(originCrs, originCrs, accessibilityKnown = false, isStepFree = null)
        val dest = stationRepository.getStationByCrs(destCrs) ?: Station(destCrs, destCrs, accessibilityKnown = false, isStepFree = null)

        // Explicit no-service demonstration scenarios
        if (departTime.contains("23:45") ||
            (originCrs.equals("GLC", true) && destCrs.equals("CBG", true))
        ) {
            return emptyList()
        }

        val pair = "${originCrs.uppercase()}-${destCrs.uppercase()}"
        val services = when (pair) {
            "SHF-STP" -> buildSheffieldToLondon(origin, dest, serviceDate)
            "LDS-MAN" -> buildLeedsToManchester(origin, dest, serviceDate)
            "BDI-YRK" -> buildBradfordToYork(origin, dest, serviceDate)
            "NCL-EDB" -> buildNewcastleToEdinburgh(origin, dest, serviceDate)
            else -> buildGenericRoute(origin, dest, serviceDate)
        }

        return if (stepFreeOnly) {
            // Only return services where accessibility is verified known & step-free (never claim unknown is accessible)
            services.filter { it.accessibilityConfidenceKnown && it.isAccessibleRoute }
        } else {
            services
        }
    }

    private fun buildSheffieldToLondon(origin: Station, dest: Station, date: String): List<JourneyOption> {
        return listOf(
            createOption(
                id = "SHF-STP-1315",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:15",
                arr = "15:20",
                durationMin = 125,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "13:15",
                        arrivalTime = "15:20",
                        durationMinutes = 125,
                        operator = "East Midlands Railway",
                        platform = "5",
                        callingPoints = listOf("Chesterfield", "Derby", "Leicester"),
                        accessibilityNote = "Step-free platforms at Sheffield & St Pancras; ramp boarding available."
                    )
                ),
                basePence = 4850,
                status = ServiceStatus.SCHEDULED
            ),
            createOption(
                id = "SHF-STP-1345",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:45",
                arr = "15:52",
                durationMin = 127,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "13:45",
                        arrivalTime = "15:52",
                        durationMinutes = 127,
                        operator = "East Midlands Railway",
                        platform = "2",
                        callingPoints = listOf("Chesterfield", "Derby", "Long Eaton", "Loughborough", "Leicester"),
                        accessibilityNote = "Step-free access verified at both ends."
                    )
                ),
                basePence = 5600,
                status = ServiceStatus.ON_TIME
            ),
            createOption(
                id = "SHF-STP-1415",
                origin = origin,
                dest = dest,
                date = date,
                dep = "14:15",
                arr = "16:23",
                durationMin = 128,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "14:15",
                        arrivalTime = "16:23",
                        durationMinutes = 128,
                        operator = "East Midlands Railway",
                        platform = "5",
                        callingPoints = listOf("Chesterfield", "Derby", "Leicester"),
                        accessibilityNote = "Step-free access verified."
                    )
                ),
                basePence = 4400,
                status = ServiceStatus.SCHEDULED
            ),
            createOption(
                id = "SHF-STP-1445",
                origin = origin,
                dest = dest,
                date = date,
                dep = "14:45",
                arr = "17:10",
                expectedDep = "14:53",
                durationMin = 145,
                changes = 1,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = "Derby",
                        destinationCrs = "DBY",
                        departureTime = "14:45",
                        arrivalTime = "15:15",
                        durationMinutes = 30,
                        operator = "CrossCountry",
                        platform = "1B",
                        callingPoints = listOf("Chesterfield"),
                        accessibilityNote = "Step-free interchange via lifts at Derby.",
                        alertMessage = "Delayed by 8 mins due to signalling fault near Chesterfield"
                    ),
                    JourneyLeg(
                        originStation = "Derby",
                        originCrs = "DBY",
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "15:30",
                        arrivalTime = "17:10",
                        durationMinutes = 100,
                        operator = "East Midlands Railway",
                        platform = "2",
                        isWalkingConnection = true,
                        connectionMinutes = 15,
                        callingPoints = listOf("Leicester", "Kettering"),
                        accessibilityNote = "15m connection time (5m minimum step-free transfer)."
                    )
                ),
                basePence = 3950,
                advanceSoldOut = true,
                status = ServiceStatus.DELAYED,
                disruptionSummary = "Expected 14:53 (+8m delay)"
            ),
            createOption(
                id = "SHF-STP-2320",
                origin = origin,
                dest = dest,
                date = date,
                dep = "23:20",
                arr = "06:15",
                durationMin = 415,
                changes = 1,
                dayOffset = 1,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = "Doncaster",
                        destinationCrs = "DON",
                        departureTime = "23:20",
                        arrivalTime = "23:50",
                        durationMinutes = 30,
                        operator = "Northern",
                        platform = "3B",
                        accessibilityNote = "Step-free access at Sheffield and Doncaster."
                    ),
                    JourneyLeg(
                        originStation = "Doncaster",
                        originCrs = "DON",
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "00:45",
                        arrivalTime = "06:15",
                        durationMinutes = 330,
                        operator = "British Rail Overnight",
                        platform = "1",
                        isWalkingConnection = true,
                        connectionMinutes = 55,
                        callingPoints = listOf("Peterborough", "London St Pancras"),
                        accessibilityNote = "55m overnight connection at Doncaster."
                    )
                ),
                basePence = 7200,
                status = ServiceStatus.SCHEDULED
            )
        )
    }

    private fun buildLeedsToManchester(origin: Station, dest: Station, date: String): List<JourneyOption> {
        return listOf(
            createOption(
                id = "LDS-MAN-1312",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:12",
                arr = "14:07",
                durationMin = 55,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "13:12",
                        arrivalTime = "14:07",
                        durationMinutes = 55,
                        operator = "TransPennine Express",
                        platform = "15A",
                        callingPoints = listOf("Huddersfield"),
                        accessibilityNote = "Step-free access verified at Leeds and Manchester Piccadilly."
                    )
                ),
                basePence = 1840,
                status = ServiceStatus.ON_TIME
            ),
            createOption(
                id = "LDS-MAN-1334",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:34",
                arr = "14:42",
                expectedDep = "13:42",
                durationMin = 68,
                changes = 1,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = "Huddersfield",
                        destinationCrs = "HUD",
                        departureTime = "13:34",
                        arrivalTime = "13:58",
                        durationMinutes = 24,
                        operator = "Northern",
                        platform = "11",
                        alertMessage = "Running 8 mins late due to TransPennine congestion"
                    ),
                    JourneyLeg(
                        originStation = "Huddersfield",
                        originCrs = "HUD",
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "14:08",
                        arrivalTime = "14:42",
                        durationMinutes = 34,
                        operator = "TransPennine Express",
                        platform = "4",
                        isWalkingConnection = true,
                        connectionMinutes = 10,
                        callingPoints = listOf("Stalybridge"),
                        accessibilityNote = "10m lift interchange at Huddersfield."
                    )
                ),
                basePence = 1620,
                status = ServiceStatus.DELAYED,
                disruptionSummary = "Expected 13:42 (+8m)"
            )
        )
    }

    private fun buildBradfordToYork(origin: Station, dest: Station, date: String): List<JourneyOption> {
        return listOf(
            createOption(
                id = "BDI-YRK-1320",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:20",
                arr = "14:26",
                durationMin = 66,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "13:20",
                        arrivalTime = "14:26",
                        durationMinutes = 66,
                        operator = "Northern",
                        platform = "2",
                        callingPoints = listOf("New Pudsey", "Leeds"),
                        accessibilityNote = "Bradford Interchange step-free status UNKNOWN; check station signage."
                    )
                ),
                basePence = 1580,
                status = ServiceStatus.SCHEDULED
            ),
            createOption(
                id = "BDI-YRK-1350",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:50",
                arr = "15:02",
                durationMin = 72,
                changes = 1,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = "Leeds",
                        destinationCrs = "LDS",
                        departureTime = "13:50",
                        arrivalTime = "14:12",
                        durationMinutes = 22,
                        operator = "Northern",
                        platform = "1",
                        accessibilityNote = "Bradford Interchange accessibility unknown."
                    ),
                    JourneyLeg(
                        originStation = "Leeds",
                        originCrs = "LDS",
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "14:24",
                        arrivalTime = "15:02",
                        durationMinutes = 38,
                        operator = "LNER",
                        platform = "8",
                        isWalkingConnection = true,
                        connectionMinutes = 12,
                        accessibilityNote = "12m transfer via Leeds footbridge lifts."
                    )
                ),
                basePence = 1450,
                status = ServiceStatus.SCHEDULED
            )
        )
    }

    private fun buildNewcastleToEdinburgh(origin: Station, dest: Station, date: String): List<JourneyOption> {
        return listOf(
            createOption(
                id = "NCL-EDB-1305",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:05",
                arr = "14:32",
                durationMin = 87,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "13:05",
                        arrivalTime = "14:32",
                        durationMinutes = 87,
                        operator = "LNER Azuma",
                        platform = "3",
                        callingPoints = listOf("Alnmouth", "Berwick-upon-Tweed"),
                        accessibilityNote = "Step-free access verified at Newcastle & Edinburgh Waverley."
                    )
                ),
                basePence = 3450,
                status = ServiceStatus.ON_TIME
            ),
            createOption(
                id = "NCL-EDB-1345",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:45",
                arr = "15:28",
                expectedDep = "14:02",
                durationMin = 103,
                changes = 1,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = "Berwick-upon-Tweed",
                        destinationCrs = "BWK",
                        departureTime = "13:45",
                        arrivalTime = "14:30",
                        durationMinutes = 45,
                        operator = "CrossCountry",
                        platform = "2",
                        accessibilityNote = "Berwick-upon-Tweed step-free status unknown.",
                        alertMessage = "Speed restriction north of Morpeth (+17m)"
                    ),
                    JourneyLeg(
                        originStation = "Berwick-upon-Tweed",
                        originCrs = "BWK",
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "14:42",
                        arrivalTime = "15:28",
                        durationMinutes = 46,
                        operator = "LNER",
                        platform = "1",
                        isWalkingConnection = true,
                        connectionMinutes = 12,
                        accessibilityNote = "12m connection; Berwick platform access unverified."
                    )
                ),
                basePence = 2990,
                status = ServiceStatus.DELAYED,
                disruptionSummary = "Expected 14:02 (+17m speed restriction)"
            )
        )
    }

    private fun buildGenericRoute(origin: Station, dest: Station, date: String): List<JourneyOption> {
        return listOf(
            createOption(
                id = "${origin.crsCode}-${dest.crsCode}-1315",
                origin = origin,
                dest = dest,
                date = date,
                dep = "13:15",
                arr = "14:45",
                durationMin = 90,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "13:15",
                        arrivalTime = "14:45",
                        durationMinutes = 90,
                        operator = "British Rail Regional",
                        platform = "4",
                        accessibilityNote = "${origin.stepFreeSummary()} • ${dest.stepFreeSummary()}"
                    )
                ),
                basePence = 3250,
                status = ServiceStatus.SIMULATED
            ),
            createOption(
                id = "${origin.crsCode}-${dest.crsCode}-1410",
                origin = origin,
                dest = dest,
                date = date,
                dep = "14:10",
                arr = "15:55",
                durationMin = 105,
                changes = 1,
                legs = listOf(
                    JourneyLeg(
                        originStation = origin.name,
                        originCrs = origin.crsCode,
                        destinationStation = "Leeds",
                        destinationCrs = "LDS",
                        departureTime = "14:10",
                        arrivalTime = "14:55",
                        durationMinutes = 45,
                        operator = "British Rail Regional",
                        platform = "2"
                    ),
                    JourneyLeg(
                        originStation = "Leeds",
                        originCrs = "LDS",
                        destinationStation = dest.name,
                        destinationCrs = dest.crsCode,
                        departureTime = "15:08",
                        arrivalTime = "15:55",
                        durationMinutes = 47,
                        operator = "British Rail InterCity",
                        platform = "6",
                        isWalkingConnection = true,
                        connectionMinutes = 13
                    )
                ),
                basePence = 2850,
                status = ServiceStatus.SIMULATED
            )
        )
    }

    private fun createOption(
        id: String,
        origin: Station,
        dest: Station,
        date: String,
        dep: String,
        arr: String,
        durationMin: Int,
        legs: List<JourneyLeg>,
        basePence: Int,
        changes: Int = 0,
        dayOffset: Int = 0,
        expectedDep: String? = null,
        advanceSoldOut: Boolean = false,
        status: ServiceStatus = ServiceStatus.SCHEDULED,
        disruptionSummary: String? = null
    ): JourneyOption {
        val advance = ServiceFare(
            id = "$id-std-adv",
            ticketType = TicketType.ADVANCE_SINGLE,
            travelClass = TravelClass.STANDARD,
            pricePence = basePence,
            isAvailable = !advanceSoldOut,
            quotaRemaining = if (advanceSoldOut) 0 else 7
        )
        val offPeak = ServiceFare(
            id = "$id-std-offpeak",
            ticketType = TicketType.OFF_PEAK_SINGLE,
            travelClass = TravelClass.STANDARD,
            pricePence = (basePence * 125) / 100,
            isAvailable = true,
            quotaRemaining = 18
        )
        val first = ServiceFare(
            id = "$id-first-adv",
            ticketType = TicketType.ADVANCE_SINGLE,
            travelClass = TravelClass.FIRST,
            pricePence = (basePence * 160) / 100,
            isAvailable = true,
            quotaRemaining = 4
        )

        val originKnown = origin.accessibilityKnown && origin.isStepFree == true
        val destKnown = dest.accessibilityKnown && dest.isStepFree == true
        val intermediateOk = legs.all { leg ->
            !leg.accessibilityNote.contains("UNKNOWN", ignoreCase = true) &&
                !leg.accessibilityNote.contains("unknown", ignoreCase = true)
        }
        val confidenceKnown = origin.accessibilityKnown && dest.accessibilityKnown && intermediateOk
        val accessibleRoute = originKnown && destKnown && intermediateOk

        return JourneyOption(
            id = id,
            origin = origin,
            destination = dest,
            serviceDate = date,
            departureTime = dep,
            arrivalTime = arr,
            expectedDepartureTime = expectedDep,
            durationMinutes = durationMin,
            changes = changes,
            arrivalDayOffset = dayOffset,
            legs = legs,
            fares = listOf(advance, offPeak, first),
            status = status,
            disruptionSummary = disruptionSummary,
            isAccessibleRoute = accessibleRoute,
            accessibilityConfidenceKnown = confidenceKnown
        )
    }
}

class JourneyPlannerImpl(
    private val timetableProvider: TimetableProvider
) : JourneyPlanner {
    override suspend fun planJourney(
        origin: Station,
        destination: Station,
        serviceDate: String,
        departTime: String,
        arriveBy: Boolean,
        isReturn: Boolean,
        returnDate: String?,
        stepFreeOnly: Boolean,
        preferredClass: TravelClass
    ): List<JourneyOption> {
        return timetableProvider.getServices(
            originCrs = origin.crsCode,
            destCrs = destination.crsCode,
            serviceDate = serviceDate,
            departTime = departTime,
            arriveBy = arriveBy,
            stepFreeOnly = stepFreeOnly
        )
    }
}

class DepartureProviderImpl : DepartureProvider {
    override suspend fun getDepartures(stationCrs: String): Pair<List<DepartureItem>, Long> {
        val now = System.currentTimeMillis()
        val list = when (stationCrs.uppercase()) {
            "SHF" -> listOf(
                DepartureItem("DEP-SHF-1", "SHF", "London St Pancras", "STP", "13:45", "13:45", "2", ServiceStatus.ON_TIME, listOf("Chesterfield", "Derby", "Leicester", "London St Pancras"), "East Midlands Railway"),
                DepartureItem("DEP-SHF-2", "SHF", "Manchester Piccadilly", "MAN", "13:52", "13:52", "6B", ServiceStatus.ON_TIME, listOf("Dore & Totley", "Stockport", "Manchester Piccadilly"), "TransPennine Express"),
                DepartureItem("DEP-SHF-3", "SHF", "Leeds", "LDS", "14:04", "14:11", "1A", ServiceStatus.DELAYED, listOf("Meadowhall", "Barnsley", "Wakefield Kirkgate", "Leeds"), "Northern"),
                DepartureItem("DEP-SHF-4", "SHF", "Edinburgh Waverley", "EDB", "14:21", null, null, ServiceStatus.CANCELLED, listOf("Leeds", "York", "Newcastle", "Edinburgh"), "CrossCountry"),
                DepartureItem("DEP-SHF-5", "SHF", "London St Pancras", "STP", "14:45", "14:53", "1B", ServiceStatus.DELAYED, listOf("Chesterfield", "Derby"), "CrossCountry")
            )
            "LDS" -> listOf(
                DepartureItem("DEP-LDS-1", "LDS", "Manchester Piccadilly", "MAN", "13:12", "13:12", "15A", ServiceStatus.ON_TIME, listOf("Huddersfield", "Manchester Piccadilly"), "TransPennine Express"),
                DepartureItem("DEP-LDS-2", "LDS", "York", "YRK", "13:24", "13:24", "8", ServiceStatus.SCHEDULED, listOf("Garforth", "York"), "LNER"),
                DepartureItem("DEP-LDS-3", "LDS", "Bradford Interchange", "BDI", "13:38", "13:38", "12B", ServiceStatus.ON_TIME, listOf("New Pudsey", "Bradford Interchange"), "Northern")
            )
            "NCL" -> listOf(
                DepartureItem("DEP-NCL-1", "NCL", "Edinburgh Waverley", "EDB", "13:05", "13:05", "3", ServiceStatus.ON_TIME, listOf("Alnmouth", "Berwick-upon-Tweed", "Edinburgh Waverley"), "LNER Azuma"),
                DepartureItem("DEP-NCL-2", "NCL", "Edinburgh Waverley", "EDB", "13:45", "14:02", "2", ServiceStatus.DELAYED, listOf("Morpeth", "Berwick-upon-Tweed", "Edinburgh"), "CrossCountry")
            )
            else -> listOf(
                DepartureItem("DEP-GEN-1", stationCrs, "Sheffield", "SHF", "13:30", "13:30", "1", ServiceStatus.SIMULATED, listOf("Doncaster", "Sheffield"), "British Rail Regional"),
                DepartureItem("DEP-GEN-2", stationCrs, "London St Pancras", "STP", "14:00", "14:00", "4", ServiceStatus.SIMULATED, listOf("Leicester", "London St Pancras"), "British Rail InterCity")
            )
        }
        return list to now
    }
}

class DisruptionProviderImpl : DisruptionProvider {
    override suspend fun getDisruptions(routeFilterCrs: String?): List<DisruptionNotice> {
        val all = listOf(
            DisruptionNotice(
                id = "DIS-01",
                scope = "Midland Main Line (SHF ↔ STP)",
                severity = "Minor delays",
                title = "Signalling check near Chesterfield",
                detail = "Trains between Sheffield and Derby may experience delays of up to 8 minutes.",
                updatedTime = "13:10"
            ),
            DisruptionNotice(
                id = "DIS-02",
                scope = "East Coast Main Line (NCL ↔ EDB)",
                severity = "Speed restriction",
                title = "Temporary speed limit north of Morpeth",
                detail = "CrossCountry and regional services may add 10–17 minutes to journey times.",
                updatedTime = "12:55"
            ),
            DisruptionNotice(
                id = "DIS-03",
                scope = "TransPennine (LDS ↔ MAN)",
                severity = "Platform notice",
                title = "Busy services between Leeds and Huddersfield",
                detail = "Allow extra time when changing platforms at Huddersfield.",
                updatedTime = "13:05"
            )
        )
        return if (routeFilterCrs.isNullOrBlank()) all else all.filter {
            it.scope.contains(routeFilterCrs, ignoreCase = true)
        }
    }
}
