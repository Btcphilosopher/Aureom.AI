package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Booking
import com.example.data.model.PassengerConfig
import com.example.data.model.RailcardType
import com.example.data.model.Station
import com.example.data.model.StationAccessibilityInfo
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailAmber
import com.example.ui.theme.RailGreen
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationSearchDialog(
    title: String,
    stations: List<Station>,
    recentStations: List<Station>,
    onStationSelected: (Station) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredStations = remember(searchQuery, stations) {
        if (searchQuery.isBlank()) stations
        else stations.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                it.crsCode.contains(searchQuery, ignoreCase = true)
        }
    }

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(16.dp)
            .testTag("station_search_dialog")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = BritishRailBlack
                )
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_station_dialog")) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Station name or CRS code (e.g. SHF, STP)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BritishRailBlack) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("station_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BritishRailBlack,
                    unfocusedBorderColor = RailGreyBorder
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (searchQuery.isBlank() && recentStations.isNotEmpty()) {
                Text(
                    text = "POPULAR STATIONS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = RailGreySubtext,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    recentStations.take(5).forEach { station ->
                        Box(
                            modifier = Modifier
                                .border(1.dp, BritishRailBlack)
                                .clickable {
                                    onStationSelected(station)
                                    onDismiss()
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "${station.name} [${station.crsCode}]",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = BritishRailBlack
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 320.dp)
            ) {
                if (filteredStations.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No stations found matching \"$searchQuery\"",
                                color = RailGreySubtext,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    items(filteredStations, key = { it.crsCode }) { station ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 52.dp)
                                .border(0.5.dp, RailGreyBorder)
                                .clickable {
                                    onStationSelected(station)
                                    onDismiss()
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .testTag("station_item_${station.crsCode}"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = station.name,
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = BritishRailBlack
                                )
                                Text(
                                    text = station.stepFreeSummary(),
                                    fontSize = 11.sp,
                                    color = when {
                                        !station.accessibilityKnown || station.isStepFree == null -> RailAmber
                                        station.isStepFree -> RailGreen
                                        else -> BritishRailRed
                                    },
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .background(RailGreyPanel)
                                    .border(1.dp, BritishRailBlack)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = station.crsCode,
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = BritishRailBlack
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PassengerConfigDialog(
    initialConfig: PassengerConfig,
    language: AppLanguage,
    onConfirmed: (PassengerConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var adults by remember { mutableIntStateOf(initialConfig.adults) }
    var children by remember { mutableIntStateOf(initialConfig.children) }
    var railcard by remember { mutableStateOf(initialConfig.railcard) }

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(16.dp)
            .testTag("passenger_dialog")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (language == AppLanguage.CYMRAEG) "Teithwyr a Cherdyn" else "Passengers & Railcards",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp,
                    color = BritishRailBlack
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Oedolion (16+)" else "Adults (16+)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BritishRailBlack
                    )
                    Text("Standard fare", fontSize = 11.sp, color = RailGreySubtext)
                }
                StepperControl(adults, 1, 8, { adults = it }, "adults")
            }

            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(RailGreyBorder))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Plant (5–15)" else "Children (5–15)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BritishRailBlack
                    )
                    Text("50% child discount", fontSize = 11.sp, color = RailGreySubtext)
                }
                StepperControl(children, 0, 8, { children = it }, "children")
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "RAILCARD & ELIGIBILITY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = RailGreySubtext,
                letterSpacing = 0.8.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 220.dp)
            ) {
                items(RailcardType.entries) { card ->
                    val isSelected = railcard == card
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (isSelected) BritishRailRed else RailGreyBorder)
                            .background(if (isSelected) BritishRailRedLight else BritishRailWhite)
                            .clickable { railcard = card }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("railcard_option_${card.name}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = card.getLocalizedName(language),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isSelected) BritishRailRed else BritishRailBlack
                            )
                            if (isSelected) {
                                Text("SELECTED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BritishRailRed)
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = card.eligibilitySummary, fontSize = 11.sp, color = RailGreySubtext)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            BrButton(
                text = if (language == AppLanguage.CYMRAEG) "Cadarnhau" else "Confirm passengers",
                onClick = {
                    onConfirmed(PassengerConfig(adults, children, railcard))
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                testTag = "confirm_passengers_button"
            )
        }
    }
}

@Composable
fun StepperControl(
    value: Int,
    minValue: Int,
    maxValue: Int,
    onValueChange: (Int) -> Unit,
    tagPrefix: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .border(1.5.dp, BritishRailBlack)
                .background(if (value > minValue) BritishRailWhite else RailGreyPanel)
                .clickable(enabled = value > minValue) { onValueChange(value - 1) }
                .testTag("${tagPrefix}_minus"),
            contentAlignment = Alignment.Center
        ) {
            Text("−", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = if (value > minValue) BritishRailBlack else RailGreyBorder)
        }
        Box(
            modifier = Modifier
                .width(44.dp)
                .height(48.dp)
                .border(1.5.dp, BritishRailBlack)
                .background(BritishRailWhite),
            contentAlignment = Alignment.Center
        ) {
            Text(value.toString(), fontWeight = FontWeight.Bold, fontSize = 17.sp, color = BritishRailBlack)
        }
        Box(
            modifier = Modifier
                .size(48.dp)
                .border(1.5.dp, BritishRailBlack)
                .background(if (value < maxValue) BritishRailWhite else RailGreyPanel)
                .clickable(enabled = value < maxValue) { onValueChange(value + 1) }
                .testTag("${tagPrefix}_plus"),
            contentAlignment = Alignment.Center
        ) {
            Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = if (value < maxValue) BritishRailBlack else RailGreyBorder)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessibilityInfoDialog(
    infoList: List<StationAccessibilityInfo>,
    onDismiss: () -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Station Accessibility Directory",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = BritishRailBlack
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RailGreyPanel)
                    .border(1.dp, BritishRailBlack)
                    .padding(10.dp)
            ) {
                Text(
                    text = "Stations marked UNKNOWN have no offline survey data and are NEVER assumed step-free. Step-free route filtering is separate from Passenger Assist booking.",
                    fontSize = 12.sp,
                    color = BritishRailBlack
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 340.dp)
            ) {
                items(infoList) { info ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BritishRailBlack)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${info.stationName} [${info.stationCrs}]",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = BritishRailBlack
                            )
                            Text(
                                text = if (info.accessibilityKnown) "VERIFIED" else "UNKNOWN",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (info.accessibilityKnown) RailGreen else RailAmber
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = info.stepFreeCategory, fontSize = 12.sp, color = BritishRailBlack)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = info.notes, fontSize = 11.sp, color = RailGreySubtext)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            BrButton("Close directory", onDismiss, modifier = Modifier.fillMaxWidth(), style = BrButtonStyle.SECONDARY_BLACK)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiptDialog(
    booking: Booking,
    onDismiss: () -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Booking Receipt (Demo)", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BritishRailBlack)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }
            Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(BritishRailBlack))
            Spacer(modifier = Modifier.height(10.dp))
            ReceiptRow("Booking Reference", booking.bookingReference)
            ReceiptRow("Collection Code", booking.collectionCode)
            ReceiptRow("Route", "${booking.journey.origin.name} → ${booking.journey.destination.name}")
            ReceiptRow("Travel Date", booking.travelDate)
            ReceiptRow("Fare Type", "${booking.selectedFare.ticketType.displayName} (${booking.selectedFare.travelClass.displayName})")
            ReceiptRow("Passengers", booking.passengers.summary())
            ReceiptRow("Payment Auth", booking.paymentAuthCode.ifBlank { "Pending" })
            ReceiptRow("Purchase Mode", if (booking.isGuestPurchase) "Guest Checkout" else "Signed-in Account")
            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(1.dp).background(BritishRailBlack))
            ReceiptRow("Total Paid (UK Rail 0% VAT)", booking.formattedPrice, bold = true)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Demonstration receipt only. Not valid for tax or rail travel.",
                fontSize = 11.sp,
                color = RailGreySubtext
            )
            Spacer(modifier = Modifier.height(12.dp))
            BrButton("Close receipt", onDismiss, modifier = Modifier.fillMaxWidth(), style = BrButtonStyle.SECONDARY_BLACK)
        }
    }
}

@Composable
private fun ReceiptRow(label: String, value: String, bold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = RailGreySubtext)
        Text(value, fontSize = 12.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium, color = BritishRailBlack)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LostBookingDialog(
    recoveryMessage: String?,
    onRecover: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var ref by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Recover Lost Booking", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BritishRailBlack)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }
            Text(
                text = "Enter your booking reference and collection code to check local encrypted records.",
                fontSize = 12.sp,
                color = RailGreySubtext
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = ref,
                onValueChange = { ref = it },
                label = { Text("Booking Reference (e.g. BR-XXXXXX)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = code,
                onValueChange = { code = it },
                label = { Text("Collection / Verification Code") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            if (recoveryMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RailGreyPanel)
                        .border(1.dp, BritishRailBlack)
                        .padding(8.dp)
                ) {
                    Text(recoveryMessage, fontSize = 12.sp, color = BritishRailBlack)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            BrButton(
                text = "Search booking",
                onClick = { onRecover(ref, code) },
                modifier = Modifier.fillMaxWidth(),
                testTag = "recover_booking_submit"
            )
        }
    }
}
