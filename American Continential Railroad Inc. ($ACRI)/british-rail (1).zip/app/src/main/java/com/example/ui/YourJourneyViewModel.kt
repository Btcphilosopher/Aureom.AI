package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.KeystoreCredentialProtector
import com.example.data.local.TravelSyncWorker
import com.example.data.local.UserPreferences
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.AfterSalesCase
import com.example.data.model.AfterSalesType
import com.example.data.model.AppLanguage
import com.example.data.model.AssistanceRequest
import com.example.data.model.Booking
import com.example.data.model.DepartureItem
import com.example.data.model.DisruptionNotice
import com.example.data.model.FareBreakdown
import com.example.data.model.FavouriteRoute
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentRequest
import com.example.data.model.PaymentResult
import com.example.data.model.RailcardType
import com.example.data.model.RecentSearch
import com.example.data.model.ServiceFare
import com.example.data.model.SimulatedPaymentOutcome
import com.example.data.model.Station
import com.example.data.model.StationAccessibilityInfo
import com.example.data.model.TicketIssuanceResult
import com.example.data.model.TicketStatus
import com.example.data.model.TravelClass
import com.example.data.repository.AfterSalesServiceImpl
import com.example.data.repository.BookingServiceImpl
import com.example.data.repository.DepartureProviderImpl
import com.example.data.repository.DisruptionProviderImpl
import com.example.data.repository.FareProviderImpl
import com.example.data.repository.JourneyPlannerImpl
import com.example.data.repository.MockRailApiClient
import com.example.data.repository.PassengerAssistanceServiceImpl
import com.example.data.repository.PaymentProviderImpl
import com.example.data.repository.PlatformWalletAdapterImpl
import com.example.data.repository.StationRepositoryImpl
import com.example.data.repository.TicketIssuerImpl
import com.example.data.repository.TicketWalletRepositoryImpl
import com.example.data.repository.TimetableProviderImpl
import com.example.domain.AfterSalesService
import com.example.domain.BookingService
import com.example.domain.CredentialProtector
import com.example.domain.DepartureProvider
import com.example.domain.DisruptionProvider
import com.example.domain.FareProvider
import com.example.domain.JourneyPlanner
import com.example.domain.PassengerAssistanceService
import com.example.domain.PaymentProvider
import com.example.domain.PlatformWalletAdapter
import com.example.domain.RailApiClient
import com.example.domain.StationRepository
import com.example.domain.TicketIssuer
import com.example.domain.TicketWalletRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppTab {
    HOME,
    PLAN,
    TICKETS,
    DEPARTURES,
    ACCOUNT
}

enum class CheckoutStage {
    NONE,
    REVIEW_AND_PAY,
    ISSUANCE_PENDING,
    ISSUED_CONFIRMATION
}

data class YourJourneyUiState(
    val activeTab: AppTab = AppTab.HOME,
    val checkoutStage: CheckoutStage = CheckoutStage.NONE,
    val currentTimeStr: String = "13:10",
    val isOfflineSimulated: Boolean = false,
    val apiNotice: String = "",
    // Stations & Search
    val allStations: List<Station> = emptyList(),
    val originStation: Station = Station("SHF", "Sheffield", accessibilityKnown = true, isStepFree = true),
    val destinationStation: Station = Station("STP", "London St Pancras", accessibilityKnown = true, isStepFree = true),
    val travelDate: String = "Fri 13 Nov 2026",
    val serviceDateIso: String = "2026-11-13",
    val isReturn: Boolean = false,
    val returnDate: String = "Sun 15 Nov 2026",
    val departTime: String = "13:00",
    val arriveBy: Boolean = false,
    val passengers: PassengerConfig = PassengerConfig(),
    val preferredClass: TravelClass = TravelClass.STANDARD,
    val stepFreeOnly: Boolean = false,
    val searchValidationError: String? = null,
    // Results & Selection
    val journeyResults: List<JourneyOption> = emptyList(),
    val expandedJourneyId: String? = null,
    val selectedJourney: JourneyOption? = null,
    val selectedFare: ServiceFare? = null,
    val fareBreakdown: FareBreakdown? = null,
    // Checkout & Payment
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val pendingBooking: Booking? = null,
    val confirmedBooking: Booking? = null,
    val paymentMethod: PaymentMethod = PaymentMethod.CARD_SIMULATED,
    val simulatedOutcome: SimulatedPaymentOutcome = SimulatedPaymentOutcome.SUCCESS,
    val forcePendingIssuance: Boolean = false,
    val isProcessingPayment: Boolean = false,
    val canReconcilePayment: Boolean = false,
    val paymentErrorOrInfo: String? = null,
    val paymentProviderName: String = "",
    // Wallet
    val tickets: List<Booking> = emptyList(),
    val ticketFilter: TicketStatus? = null,
    val selectedWalletTicket: Booking? = null,
    val walletProtectionMechanism: String = "",
    val platformWalletSupported: Boolean = false,
    val platformWalletStatus: String = "",
    // Departures & Live Journey
    val boardStation: Station = Station("SHF", "Sheffield", accessibilityKnown = true, isStepFree = true),
    val departures: List<DepartureItem> = emptyList(),
    val departuresLastUpdatedMs: Long = 0L,
    val followedBookingRef: String? = null,
    val nearbyStation: Station? = null,
    val locationGranted: Boolean = false,
    val locationStatusNote: String = "Optional location not granted — showing default local station Sheffield [SHF].",
    val disruptions: List<DisruptionNotice> = emptyList(),
    // User Data & Preferences
    val preferences: UserPreferences = UserPreferences(),
    val favouriteRoutes: List<FavouriteRoute> = emptyList(),
    val favouriteStations: List<String> = emptyList(),
    val recentSearches: List<RecentSearch> = emptyList(),
    val assistanceRequests: List<AssistanceRequest> = emptyList(),
    val afterSalesCases: List<AfterSalesCase> = emptyList(),
    val stationAccessibility: List<StationAccessibilityInfo> = emptyList(),
    val recoveryMessage: String? = null,
    val exportSummaryText: String? = null,
    val bannerMessage: String? = null
)

class YourJourneyViewModel(
    val stationRepository: StationRepository,
    val timetableProvider: TimetableProviderImpl = TimetableProviderImpl(stationRepository),
    val journeyPlanner: JourneyPlanner = JourneyPlannerImpl(timetableProvider),
    val departureProvider: DepartureProvider = DepartureProviderImpl(),
    val fareProvider: FareProvider = FareProviderImpl(),
    val bookingService: BookingService = BookingServiceImpl(),
    val paymentProvider: PaymentProvider = PaymentProviderImpl(),
    val ticketIssuer: TicketIssuer = TicketIssuerImpl(),
    val walletRepository: TicketWalletRepository,
    val disruptionProvider: DisruptionProvider = DisruptionProviderImpl(),
    val assistanceService: PassengerAssistanceService = PassengerAssistanceServiceImpl(),
    val afterSalesService: AfterSalesService,
    val platformWalletAdapter: PlatformWalletAdapter = PlatformWalletAdapterImpl(),
    val railApiClient: RailApiClient = MockRailApiClient(),
    val credentialProtector: CredentialProtector = KeystoreCredentialProtector(),
    private val preferencesRepository: UserPreferencesRepository? = null,
    private val appContext: Context? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        YourJourneyUiState(
            apiNotice = railApiClient.endpointNotice,
            paymentProviderName = paymentProvider.providerName,
            walletProtectionMechanism = credentialProtector.protectionMechanism,
            platformWalletSupported = platformWalletAdapter.isSupportedAndConfigured,
            platformWalletStatus = platformWalletAdapter.statusDescription
        )
    )
    val uiState: StateFlow<YourJourneyUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            if (walletRepository is TicketWalletRepositoryImpl) {
                walletRepository.seedDemoDataIfEmpty()
            }
            val stations = stationRepository.getStations()
            val accessibility = stationRepository.getAllStationAccessibility()
            val disruptions = disruptionProvider.getDisruptions()
            val defaultOrigin = stations.firstOrNull { it.crsCode == "SHF" } ?: stations.first()
            val defaultDest = stations.firstOrNull { it.crsCode == "STP" } ?: stations.last()

            _uiState.update {
                it.copy(
                    allStations = stations,
                    originStation = defaultOrigin,
                    destinationStation = defaultDest,
                    boardStation = defaultOrigin,
                    nearbyStation = defaultOrigin,
                    stationAccessibility = accessibility,
                    disruptions = disruptions
                )
            }
            performSearch(navigateToPlan = false, recordHistory = false)
            loadDepartures(defaultOrigin)
        }

        viewModelScope.launch {
            walletRepository.observeTickets().collect { tickets ->
                val activeRef = _uiState.value.followedBookingRef
                val defaultFollow = activeRef ?: tickets.firstOrNull { it.ticketStatus == TicketStatus.AVAILABLE }?.bookingReference
                _uiState.update {
                    it.copy(
                        tickets = tickets,
                        followedBookingRef = defaultFollow,
                        selectedWalletTicket = it.selectedWalletTicket?.let { sel ->
                            tickets.find { t -> t.bookingReference == sel.bookingReference } ?: sel
                        }
                    )
                }
            }
        }

        viewModelScope.launch {
            walletRepository.observeFavouriteRoutes().collect { routes ->
                _uiState.update { it.copy(favouriteRoutes = routes) }
            }
        }

        viewModelScope.launch {
            walletRepository.observeFavouriteStations().collect { stations ->
                _uiState.update { it.copy(favouriteStations = stations) }
            }
        }

        viewModelScope.launch {
            walletRepository.observeRecentSearches().collect { recent ->
                _uiState.update { it.copy(recentSearches = recent) }
            }
        }

        viewModelScope.launch {
            afterSalesService.observeCases().collect { cases ->
                _uiState.update { it.copy(afterSalesCases = cases) }
            }
        }

        preferencesRepository?.let { repo ->
            viewModelScope.launch {
                repo.preferencesFlow.collect { prefs ->
                    _uiState.update { state ->
                        state.copy(
                            preferences = prefs,
                            passengers = state.passengers.copy(railcard = prefs.preferredRailcard),
                            preferredClass = prefs.preferredClass,
                            stepFreeOnly = prefs.stepFreeOnly
                        )
                    }
                }
            }
        }
    }

    fun selectTab(tab: AppTab) {
        _uiState.update { it.copy(activeTab = tab, bannerMessage = null) }
    }

    fun exitCheckout() {
        _uiState.update {
            it.copy(
                checkoutStage = CheckoutStage.NONE,
                paymentErrorOrInfo = null
            )
        }
    }

    fun setOrigin(station: Station) {
        if (station.crsCode == _uiState.value.destinationStation.crsCode) {
            _uiState.update { it.copy(searchValidationError = "Origin and destination cannot be the same station.") }
            return
        }
        _uiState.update { it.copy(originStation = station, searchValidationError = null) }
    }

    fun setDestination(station: Station) {
        if (station.crsCode == _uiState.value.originStation.crsCode) {
            _uiState.update { it.copy(searchValidationError = "Origin and destination cannot be the same station.") }
            return
        }
        _uiState.update { it.copy(destinationStation = station, searchValidationError = null) }
    }

    fun swapStations() {
        _uiState.update {
            it.copy(
                originStation = it.destinationStation,
                destinationStation = it.originStation,
                searchValidationError = null
            )
        }
        performSearch(navigateToPlan = false, recordHistory = false)
    }

    fun setTravelDate(displayDate: String, isoDate: String) {
        _uiState.update { it.copy(travelDate = displayDate, serviceDateIso = isoDate) }
    }

    fun setReturnMode(isReturn: Boolean) {
        _uiState.update { state ->
            val updatedBreakdown = if (state.selectedFare != null) {
                fareProvider.getBreakdownForServiceFare(state.selectedFare, state.passengers, isReturn)
            } else state.fareBreakdown
            state.copy(isReturn = isReturn, fareBreakdown = updatedBreakdown)
        }
    }

    fun setReturnDate(date: String) {
        _uiState.update { it.copy(returnDate = date) }
    }

    fun setDepartTime(time: String, arriveBy: Boolean) {
        _uiState.update { it.copy(departTime = time, arriveBy = arriveBy) }
    }

    fun setPassengers(config: PassengerConfig) {
        _uiState.update { state ->
            val updatedBreakdown = if (state.selectedFare != null) {
                fareProvider.getBreakdownForServiceFare(state.selectedFare, config, state.isReturn)
            } else state.fareBreakdown
            state.copy(passengers = config, fareBreakdown = updatedBreakdown)
        }
        preferencesRepository?.let { repo ->
            viewModelScope.launch {
                val p = _uiState.value.preferences
                repo.setTravelPreferences(config.railcard, p.preferredClass, p.stepFreeOnly)
            }
        }
    }

    fun setPreferredClass(travelClass: TravelClass) {
        _uiState.update { it.copy(preferredClass = travelClass) }
        preferencesRepository?.let { repo ->
            viewModelScope.launch {
                val p = _uiState.value.preferences
                repo.setTravelPreferences(p.preferredRailcard, travelClass, p.stepFreeOnly)
            }
        }
    }

    fun setStepFreeOnly(enabled: Boolean) {
        _uiState.update { it.copy(stepFreeOnly = enabled) }
        preferencesRepository?.let { repo ->
            viewModelScope.launch {
                val p = _uiState.value.preferences
                repo.setTravelPreferences(p.preferredRailcard, p.preferredClass, enabled)
            }
        }
        performSearch(navigateToPlan = false, recordHistory = false)
    }

    fun performSearch(navigateToPlan: Boolean = true, recordHistory: Boolean = true) {
        val state = _uiState.value
        if (state.originStation.crsCode == state.destinationStation.crsCode) {
            _uiState.update { it.copy(searchValidationError = "Select different origin and destination stations.") }
            return
        }
        viewModelScope.launch {
            val results = journeyPlanner.planJourney(
                origin = state.originStation,
                destination = state.destinationStation,
                serviceDate = state.serviceDateIso,
                departTime = state.departTime,
                arriveBy = state.arriveBy,
                isReturn = state.isReturn,
                returnDate = if (state.isReturn) state.returnDate else null,
                stepFreeOnly = state.stepFreeOnly,
                preferredClass = state.preferredClass
            )
            if (recordHistory) {
                walletRepository.recordRecentSearch(state.originStation, state.destinationStation, state.travelDate)
            }
            val disruptions = disruptionProvider.getDisruptions()
            _uiState.update {
                it.copy(
                    journeyResults = results,
                    activeTab = if (navigateToPlan) AppTab.PLAN else it.activeTab,
                    disruptions = disruptions,
                    searchValidationError = null
                )
            }
        }
    }

    fun applyRoutePreset(originCrs: String, destCrs: String) {
        viewModelScope.launch {
            val origin = stationRepository.getStationByCrs(originCrs) ?: return@launch
            val dest = stationRepository.getStationByCrs(destCrs) ?: return@launch
            _uiState.update {
                it.copy(
                    originStation = origin,
                    destinationStation = dest,
                    searchValidationError = null
                )
            }
            performSearch(navigateToPlan = true, recordHistory = true)
        }
    }

    fun toggleJourneyExpanded(journeyId: String) {
        _uiState.update {
            it.copy(expandedJourneyId = if (it.expandedJourneyId == journeyId) null else journeyId)
        }
    }

    fun selectFareAndBeginCheckout(journey: JourneyOption, fare: ServiceFare) {
        if (!fare.isAvailable) {
            _uiState.update {
                it.copy(bannerMessage = "${fare.ticketType.displayName} is sold out on the ${journey.departureTime} service. Choose another fare.")
            }
            return
        }
        val state = _uiState.value
        val breakdown = fareProvider.getBreakdownForServiceFare(fare, state.passengers, state.isReturn)
        _uiState.update {
            it.copy(
                selectedJourney = journey,
                selectedFare = fare,
                fareBreakdown = breakdown,
                idempotencyKey = UUID.randomUUID().toString(),
                pendingBooking = null,
                confirmedBooking = null,
                canReconcilePayment = false,
                paymentErrorOrInfo = null,
                checkoutStage = CheckoutStage.REVIEW_AND_PAY,
                activeTab = AppTab.PLAN
            )
        }
    }

    fun setPaymentMethod(method: PaymentMethod) {
        _uiState.update { it.copy(paymentMethod = method) }
    }

    fun setSimulatedOutcome(outcome: SimulatedPaymentOutcome) {
        _uiState.update { it.copy(simulatedOutcome = outcome) }
    }

    fun setForcePendingIssuance(pending: Boolean) {
        _uiState.update { it.copy(forcePendingIssuance = pending) }
    }

    fun submitCheckoutPayment() {
        val state = _uiState.value
        val journey = state.selectedJourney ?: return
        val fare = state.selectedFare ?: return
        val breakdown = state.fareBreakdown ?: return
        if (state.isProcessingPayment) return

        viewModelScope.launch {
            _uiState.update { it.copy(isProcessingPayment = true, paymentErrorOrInfo = null) }

            val booking = bookingService.createPendingBooking(
                journey = journey,
                fare = fare,
                passengers = state.passengers,
                travelDate = state.travelDate,
                returnDate = if (state.isReturn) state.returnDate else null,
                isReturn = state.isReturn,
                totalPence = breakdown.totalPence,
                idempotencyKey = state.idempotencyKey,
                isGuestPurchase = !state.preferences.isSignedIn
            )
            _uiState.update { it.copy(pendingBooking = booking) }

            val paymentResult = paymentProvider.processPayment(
                PaymentRequest(
                    bookingReference = booking.bookingReference,
                    idempotencyKey = state.idempotencyKey,
                    amountPence = breakdown.totalPence,
                    method = state.paymentMethod,
                    simulatedOutcome = state.simulatedOutcome
                )
            )

            handlePaymentOutcome(booking, paymentResult, state.forcePendingIssuance)
        }
    }

    fun reconcileUncertainPayment() {
        val state = _uiState.value
        val pending = state.pendingBooking ?: return
        if (state.isProcessingPayment) return

        viewModelScope.launch {
            _uiState.update { it.copy(isProcessingPayment = true, paymentErrorOrInfo = null) }
            val result = paymentProvider.reconcilePayment(state.idempotencyKey, pending.bookingReference)
            handlePaymentOutcome(pending, result, state.forcePendingIssuance)
        }
    }

    private suspend fun handlePaymentOutcome(
        booking: Booking,
        result: PaymentResult,
        forcePendingIssuance: Boolean
    ) {
        when (result) {
            is PaymentResult.Success -> {
                val paidBooking = bookingService.markPaymentConfirmedAwaitingIssuance(
                    bookingReference = booking.bookingReference,
                    paymentAuthCode = result.authCode
                )
                walletRepository.saveTicket(paidBooking)
                attemptTicketIssuance(paidBooking, forcePendingForDemo = forcePendingIssuance)
            }
            is PaymentResult.Declined -> {
                _uiState.update {
                    it.copy(
                        isProcessingPayment = false,
                        canReconcilePayment = false,
                        paymentErrorOrInfo = result.reason
                    )
                }
            }
            is PaymentResult.Timeout -> {
                _uiState.update {
                    it.copy(
                        isProcessingPayment = false,
                        canReconcilePayment = true,
                        paymentErrorOrInfo = "Payment gateway timed out. Check/reconcile status with the same idempotency key before trying again."
                    )
                }
            }
            is PaymentResult.Uncertain -> {
                _uiState.update {
                    it.copy(
                        isProcessingPayment = false,
                        canReconcilePayment = true,
                        paymentErrorOrInfo = result.message
                    )
                }
            }
            is PaymentResult.Cancelled -> {
                _uiState.update {
                    it.copy(
                        isProcessingPayment = false,
                        canReconcilePayment = false,
                        paymentErrorOrInfo = "Payment cancelled. No charge was recorded."
                    )
                }
            }
        }
    }

    fun retryPendingTicketIssuance(booking: Booking? = null) {
        val target = booking ?: _uiState.value.pendingBooking ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessingPayment = true, paymentErrorOrInfo = null) }
            attemptTicketIssuance(target, forcePendingForDemo = false)
        }
    }

    private suspend fun attemptTicketIssuance(paidBooking: Booking, forcePendingForDemo: Boolean) {
        when (val issuance = ticketIssuer.issueTicket(paidBooking, forcePendingForDemo = forcePendingForDemo)) {
            is TicketIssuanceResult.Issued -> {
                val issued = bookingService.finalizeIssuedBooking(paidBooking.bookingReference, issuance.qrData)
                walletRepository.saveTicket(issued)
                _uiState.update {
                    it.copy(
                        isProcessingPayment = false,
                        canReconcilePayment = false,
                        pendingBooking = issued,
                        confirmedBooking = issued,
                        selectedWalletTicket = issued,
                        followedBookingRef = issued.bookingReference,
                        checkoutStage = CheckoutStage.ISSUED_CONFIRMATION,
                        paymentErrorOrInfo = null
                    )
                }
            }
            is TicketIssuanceResult.Pending -> {
                _uiState.update {
                    it.copy(
                        isProcessingPayment = false,
                        pendingBooking = paidBooking,
                        checkoutStage = CheckoutStage.ISSUANCE_PENDING,
                        paymentErrorOrInfo = issuance.reason
                    )
                }
            }
            is TicketIssuanceResult.Failed -> {
                _uiState.update {
                    it.copy(
                        isProcessingPayment = false,
                        pendingBooking = paidBooking,
                        checkoutStage = CheckoutStage.ISSUANCE_PENDING,
                        paymentErrorOrInfo = issuance.error
                    )
                }
            }
        }
    }

    // Wallet actions
    fun setTicketFilter(filter: TicketStatus?) {
        _uiState.update { it.copy(ticketFilter = filter) }
    }

    fun openTicketDetail(booking: Booking) {
        _uiState.update {
            it.copy(
                selectedWalletTicket = booking,
                activeTab = AppTab.TICKETS,
                checkoutStage = CheckoutStage.NONE
            )
        }
    }

    fun closeTicketDetail() {
        _uiState.update { it.copy(selectedWalletTicket = null) }
    }

    fun toggleOfflineSimulated(offline: Boolean) {
        _uiState.update { it.copy(isOfflineSimulated = offline) }
    }

    fun attemptAddToPlatformWallet(booking: Booking) {
        viewModelScope.launch {
            val res = platformWalletAdapter.addTicketToPlatformWallet(booking)
            _uiState.update {
                it.copy(bannerMessage = res.exceptionOrNull()?.message ?: "Added to Platform Wallet.")
            }
        }
    }

    // Favourites & Departures & Location
    fun toggleFavouriteCurrentRoute() {
        val state = _uiState.value
        viewModelScope.launch {
            walletRepository.toggleFavouriteRoute(state.originStation, state.destinationStation)
        }
    }

    fun toggleFavouriteStation(crsCode: String) {
        viewModelScope.launch {
            walletRepository.toggleFavouriteStation(crsCode)
        }
    }

    fun loadDepartures(station: Station) {
        viewModelScope.launch {
            val (items, updatedMs) = departureProvider.getDepartures(station.crsCode)
            _uiState.update {
                it.copy(
                    boardStation = station,
                    departures = items,
                    departuresLastUpdatedMs = updatedMs
                )
            }
        }
    }

    fun refreshDeparturesAndSync() {
        loadDepartures(_uiState.value.boardStation)
        appContext?.let { TravelSyncWorker.enqueueImmediateRefresh(it) }
    }

    fun followBooking(bookingReference: String) {
        _uiState.update {
            it.copy(
                followedBookingRef = bookingReference,
                activeTab = AppTab.DEPARTURES
            )
        }
    }

    fun onLocationPermissionResult(granted: Boolean, latitude: Double? = null, longitude: Double? = null) {
        viewModelScope.launch {
            if (granted) {
                // Use supplied location or Sheffield city coordinates if coarse fix unavailable offline
                val lat = latitude ?: 53.3790
                val lon = longitude ?: -1.4630
                val nearest = stationRepository.getNearestStation(lat, lon)
                _uiState.update {
                    it.copy(
                        locationGranted = true,
                        nearbyStation = nearest ?: it.boardStation,
                        locationStatusNote = "Nearest station resolved via approximate device location: ${nearest?.displayName ?: "Sheffield [SHF]"}."
                    )
                }
                if (nearest != null) {
                    loadDepartures(nearest)
                }
            } else {
                _uiState.update {
                    it.copy(
                        locationGranted = false,
                        locationStatusNote = "Location permission declined — select your departure station manually."
                    )
                }
            }
        }
    }

    // Account, Accessibility & Assistance
    fun toggleSignIn(signIn: Boolean, name: String = "Alex Mercer", email: String = "alex.mercer@example.uk") {
        if (signIn) {
            _uiState.update {
                it.copy(preferences = it.preferences.copy(isSignedIn = true, passengerName = name, passengerEmail = email))
            }
            viewModelScope.launch { preferencesRepository?.setSignedInAccount(true, name, email) }
        } else {
            _uiState.update {
                it.copy(preferences = it.preferences.copy(isSignedIn = false, passengerName = "Guest Traveller", passengerEmail = ""))
            }
            viewModelScope.launch { preferencesRepository?.setSignedInAccount(false, "Guest Traveller", "") }
        }
    }

    fun setLanguage(language: AppLanguage) {
        val current = _uiState.value.preferences
        _uiState.update { it.copy(preferences = it.preferences.copy(language = language)) }
        viewModelScope.launch {
            preferencesRepository?.setAccessibility(language, current.textSizeLevel, current.reducedMotion)
        }
    }

    fun setTextSizeLevel(level: Int) {
        val clamped = level.coerceIn(0, 2)
        val current = _uiState.value.preferences
        _uiState.update { it.copy(preferences = it.preferences.copy(textSizeLevel = clamped)) }
        viewModelScope.launch {
            preferencesRepository?.setAccessibility(current.language, clamped, current.reducedMotion)
        }
    }

    fun setReducedMotion(enabled: Boolean) {
        val current = _uiState.value.preferences
        _uiState.update { it.copy(preferences = it.preferences.copy(reducedMotion = enabled)) }
        viewModelScope.launch {
            preferencesRepository?.setAccessibility(current.language, current.textSizeLevel, enabled)
        }
    }

    fun setNotificationPrefs(delayAlerts: Boolean, platformAlerts: Boolean) {
        _uiState.update {
            it.copy(
                preferences = it.preferences.copy(
                    delayAlertsEnabled = delayAlerts,
                    platformAlertsEnabled = platformAlerts
                )
            )
        }
        viewModelScope.launch {
            preferencesRepository?.setNotificationPreferences(delayAlerts, platformAlerts)
        }
    }

    fun requestPassengerAssistance(bookingRef: String?, stationName: String, requirement: String) {
        viewModelScope.launch {
            assistanceService.requestAssistance(bookingRef, stationName, requirement)
            _uiState.update {
                it.copy(
                    assistanceRequests = assistanceService.getActiveRequests(),
                    bannerMessage = "Passenger Assist request logged for $stationName."
                )
            }
        }
    }

    fun advanceAssistanceStatus(requestId: String) {
        viewModelScope.launch {
            assistanceService.refreshAssistanceStatus(requestId)
            _uiState.update { it.copy(assistanceRequests = assistanceService.getActiveRequests()) }
        }
    }

    fun submitAfterSalesCase(bookingRef: String, type: AfterSalesType, reason: String) {
        if (bookingRef.isBlank() || reason.isBlank()) {
            _uiState.update { it.copy(bannerMessage = "Enter both a booking reference and reason before submitting.") }
            return
        }
        viewModelScope.launch {
            val created = afterSalesService.submitCase(bookingRef, type, reason)
            if (type == AfterSalesType.REFUND_REQUEST) {
                // Keep ticket status honest — don't mark refunded until operator approval; leave intact or note submitted
                _uiState.update {
                    it.copy(bannerMessage = "${type.label} (${created.id}) submitted for operator review.")
                }
            } else {
                _uiState.update {
                    it.copy(bannerMessage = "${type.label} (${created.id}) submitted.")
                }
            }
        }
    }

    fun recoverLostBooking(reference: String, verificationCode: String) {
        viewModelScope.launch {
            val result = bookingService.findBookingForRecovery(reference, verificationCode)
            result.fold(
                onSuccess = { recovered ->
                    walletRepository.saveTicket(recovered)
                    _uiState.update {
                        it.copy(
                            recoveryMessage = "Booking ${recovered.bookingReference} restored to your local Ticket Wallet.",
                            selectedWalletTicket = recovered
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update { it.copy(recoveryMessage = err.message ?: "Lookup failed.") }
                }
            )
        }
    }

    fun generateLocalExportSummary() {
        val state = _uiState.value
        val summary = buildString {
            appendLine("=== British Rail — Your Journey Local Data Export ===")
            appendLine("Account Mode: ${if (state.preferences.isSignedIn) "${state.preferences.passengerName} (${state.preferences.passengerEmail})" else "Guest Traveller"}")
            appendLine("Preferred Railcard: ${state.preferences.preferredRailcard.englishName}")
            appendLine("Tickets Cached (${state.tickets.size}):")
            state.tickets.forEach { t ->
                appendLine(" - ${t.bookingReference} | ${t.journey.origin.crsCode}→${t.journey.destination.crsCode} | ${t.travelDate} | ${t.ticketStatus.label} | ${t.formattedPrice}")
            }
            appendLine("Favourite Routes (${state.favouriteRoutes.size}): ${state.favouriteRoutes.joinToString { "${it.originCrs}→${it.destCrs}" }}")
            appendLine("After-Sales Cases (${state.afterSalesCases.size}): ${state.afterSalesCases.joinToString { "${it.id} (${it.status.label})" }}")
            appendLine("Wallet Protection: ${state.walletProtectionMechanism}")
        }
        _uiState.update { it.copy(exportSummaryText = summary) }
    }

    fun dismissExportSummary() {
        _uiState.update { it.copy(exportSummaryText = null) }
    }

    fun deleteAllLocalData() {
        _uiState.update {
            it.copy(
                preferences = UserPreferences(),
                tickets = emptyList(),
                favouriteRoutes = emptyList(),
                favouriteStations = emptyList(),
                recentSearches = emptyList(),
                afterSalesCases = emptyList(),
                selectedWalletTicket = null,
                followedBookingRef = null,
                exportSummaryText = null,
                bannerMessage = "All local tickets, preferences, favourites, and searches have been deleted."
            )
        }
        viewModelScope.launch {
            walletRepository.clearAllLocalData()
            preferencesRepository?.clearAll()
        }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(bannerMessage = null) }
    }
}

class YourJourneyViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val appCtx = context.applicationContext
        val db = AppDatabase.getInstance(appCtx)
        val dao = db.walletDao()
        val protector = KeystoreCredentialProtector()
        val stationRepo = StationRepositoryImpl()
        val timetable = TimetableProviderImpl(stationRepo)
        val planner = JourneyPlannerImpl(timetable)
        val walletRepo = TicketWalletRepositoryImpl(dao, protector)
        val afterSales = AfterSalesServiceImpl(dao)
        val prefsRepo = UserPreferencesRepository(appCtx)

        return YourJourneyViewModel(
            stationRepository = stationRepo,
            timetableProvider = timetable,
            journeyPlanner = planner,
            departureProvider = DepartureProviderImpl(),
            fareProvider = FareProviderImpl(),
            bookingService = BookingServiceImpl(),
            paymentProvider = PaymentProviderImpl(),
            ticketIssuer = TicketIssuerImpl(),
            walletRepository = walletRepo,
            disruptionProvider = DisruptionProviderImpl(),
            assistanceService = PassengerAssistanceServiceImpl(),
            afterSalesService = afterSales,
            platformWalletAdapter = PlatformWalletAdapterImpl(),
            railApiClient = MockRailApiClient(),
            credentialProtector = protector,
            preferencesRepository = prefsRepo,
            appContext = appCtx
        ) as T
    }
}
