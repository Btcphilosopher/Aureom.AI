package com.example.data.local

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.domain.CredentialProtector
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class KeystoreCredentialProtector : CredentialProtector {
    private val alias = "british_rail_wallet_aes_key"
    private val transformation = "AES/GCM/NoPadding"

    private val hasAndroidKeyStore: Boolean by lazy {
        runCatching {
            val ks = KeyStore.getInstance("AndroidKeyStore")
            ks.load(null)
            true
        }.getOrDefault(false)
    }

    override val protectionMechanism: String
        get() = if (hasAndroidKeyStore) "AndroidKeyStore AES-256-GCM" else "JVM Test Fallback Encoding"

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore")
        keyStore.load(null)
        val existing = keyStore.getKey(alias, null) as? SecretKey
        if (existing != null) return existing

        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGen.init(spec)
        return keyGen.generateKey()
    }

    override fun protect(plainText: String): String {
        if (!hasAndroidKeyStore) {
            return "FALLBACK:" + Base64.encodeToString(
                plainText.toByteArray(StandardCharsets.UTF_8),
                Base64.NO_WRAP
            )
        }
        return runCatching {
            val cipher = Cipher.getInstance(transformation)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
            val iv = cipher.iv
            val encrypted = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
            val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
            val dataB64 = Base64.encodeToString(encrypted, Base64.NO_WRAP)
            "KS:$ivB64:$dataB64"
        }.getOrElse {
            "FALLBACK:" + Base64.encodeToString(
                plainText.toByteArray(StandardCharsets.UTF_8),
                Base64.NO_WRAP
            )
        }
    }

    override fun unprotect(protectedText: String): String {
        if (protectedText.startsWith("FALLBACK:")) {
            val payload = protectedText.removePrefix("FALLBACK:")
            return String(Base64.decode(payload, Base64.NO_WRAP), StandardCharsets.UTF_8)
        }
        if (protectedText.startsWith("KS:") && hasAndroidKeyStore) {
            val parts = protectedText.split(":")
            if (parts.size == 3) {
                val iv = Base64.decode(parts[1], Base64.NO_WRAP)
                val encrypted = Base64.decode(parts[2], Base64.NO_WRAP)
                val cipher = Cipher.getInstance(transformation)
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, iv))
                val decrypted = cipher.doFinal(encrypted)
                return String(decrypted, StandardCharsets.UTF_8)
            }
        }
        return protectedText
    }
}
