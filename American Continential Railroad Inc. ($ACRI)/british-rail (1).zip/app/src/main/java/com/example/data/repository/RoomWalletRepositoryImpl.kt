package com.example.data.repository

import com.example.data.local.AfterSalesEntity
import com.example.data.local.CachedTicketEntity
import com.example.data.local.FavouriteRouteEntity
import com.example.data.local.FavouriteStationEntity
import com.example.data.local.RecentSearchEntity
import com.example.data.local.WalletDao
import com.example.data.model.AfterSalesCase
import com.example.data.model.AfterSalesStatus
import com.example.data.model.AfterSalesType
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.FavouriteRoute
import com.example.data.model.JourneyLeg
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.RecentSearch
import com.example.data.model.ServiceFare
import com.example.data.model.ServiceStatus
import com.example.data.model.Station
import com.example.data.model.TicketStatus
import com.example.data.model.TicketType
import com.example.data.model.TravelClass
import com.example.domain.AfterSalesService
import com.example.domain.CredentialProtector
import com.example.domain.TicketWalletRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

class TicketWalletRepositoryImpl(
    private val dao: WalletDao?,
    private val protector: CredentialProtector
) : TicketWalletRepository {

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    private val bookingAdapter = moshi.adapter(Booking::class.java)

    private val memoryTickets = MutableStateFlow<List<Booking>>(emptyList())
    private val memoryRoutes = MutableStateFlow<List<FavouriteRoute>>(emptyList())
    private val memoryStations = MutableStateFlow<List<String>>(emptyList())
    private val memoryRecent = MutableStateFlow<List<RecentSearch>>(emptyList())

    suspend fun seedDemoDataIfEmpty() {
        val currentTickets = if (dao != null) dao.observeTickets().first() else memoryTickets.value
        val currentRoutes = if (dao != null) dao.observeFavouriteRoutes().first() else memoryRoutes.value

        if (currentTickets.isEmpty()) {
            val shf = Station("SHF", "Sheffield", accessibilityKnown = true, isStepFree = true)
            val stp = Station("STP", "London St Pancras", accessibilityKnown = true, isStepFree = true)
            val lds = Station("LDS", "Leeds", accessibilityKnown = true, isStepFree = true)
            val man = Station("MAN", "Manchester Piccadilly", accessibilityKnown = true, isStepFree = true)

            val upcomingFare = ServiceFare(
                id = "SEED-SHF-STP-ADV",
                ticketType = TicketType.ADVANCE_SINGLE,
                travelClass = TravelClass.STANDARD,
                pricePence = 4850,
                isAvailable = true
            )
            val upcomingJourney = JourneyOption(
                id = "SHF-STP-1315",
                origin = shf,
                destination = stp,
                serviceDate = "2026-11-13",
                departureTime = "13:15",
                arrivalTime = "15:20",
                durationMinutes = 125,
                changes = 0,
                legs = listOf(
                    JourneyLeg(
                        originStation = "Sheffield",
                        originCrs = "SHF",
                        destinationStation = "London St Pancras",
                        destinationCrs = "STP",
                        departureTime = "13:15",
                        arrivalTime = "15:20",
                        durationMinutes = 125,
                        operator = "East Midlands Railway",
                        platform = "5",
                        callingPoints = listOf("Chesterfield", "Derby", "Leicester"),
                        accessibilityNote = "Step-free access verified at Sheffield & St Pancras."
                    )
                ),
                fares = listOf(upcomingFare),
                status = ServiceStatus.SCHEDULED,
                isAccessibleRoute = true,
                accessibilityConfidenceKnown = true
            )
            val activeBooking = Booking(
                bookingReference = "BR-77102-SHF",
                collectionCode = "8X49PL2K",
                journey = upcomingJourney,
                selectedFare = upcomingFare,
                passengers = PassengerConfig(adults = 1, children = 0),
                travelDate = "Fri 13 Nov 2026",
                isReturn = false,
                totalPence = 4850,
                paymentAuthCode = "DEMO-AUTH-771",
                idempotencyKey = "seed-shf-stp",
                bookingStatus = BookingStatus.CONFIRMED,
                ticketStatus = TicketStatus.AVAILABLE,
                seatReservation = "Coach C, Seat 42 (Window)",
                qrPayload = "BR-DEMO|NOT_VALID_FOR_TRAVEL|REF=BR-77102-SHF|SHF-STP|13:15",
                isGuestPurchase = false
            )

            val expiredFare = ServiceFare(
                id = "SEED-LDS-MAN-OP",
                ticketType = TicketType.OFF_PEAK_SINGLE,
                travelClass = TravelClass.STANDARD,
                pricePence = 1840,
                isAvailable = true
            )
            val expiredJourney = JourneyOption(
                id = "LDS-MAN-1312",
                origin = lds,
                destination = man,
                serviceDate = "2026-10-04",
                departureTime = "13:12",
                arrivalTime = "14:07",
                durationMinutes = 55,
                changes = 0,
                legs = listOf(
                    JourneyLeg(
                        originStation = "Leeds",
                        originCrs = "LDS",
                        destinationStation = "Manchester Piccadilly",
                        destinationCrs = "MAN",
                        departureTime = "13:12",
                        arrivalTime = "14:07",
                        durationMinutes = 55,
                        operator = "TransPennine Express",
                        platform = "15A",
                        accessibilityNote = "Step-free access verified."
                    )
                ),
                fares = listOf(expiredFare),
                status = ServiceStatus.SCHEDULED,
                isAccessibleRoute = true,
                accessibilityConfidenceKnown = true
            )
            val expiredBooking = Booking(
                bookingReference = "BR-41088-LDS",
                collectionCode = "2K91MN4R",
                journey = expiredJourney,
                selectedFare = expiredFare,
                passengers = PassengerConfig(adults = 1, children = 0),
                travelDate = "Sun 04 Oct 2026",
                isReturn = false,
                totalPence = 1840,
                paymentAuthCode = "DEMO-AUTH-410",
                idempotencyKey = "seed-lds-man",
                timestampEpochMs = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000,
                bookingStatus = BookingStatus.CONFIRMED,
                ticketStatus = TicketStatus.EXPIRED,
                seatReservation = "Coach B, Seat 14",
                qrPayload = "BR-DEMO|EXPIRED|REF=BR-41088-LDS|LDS-MAN",
                isGuestPurchase = false
            )

            saveTicket(activeBooking)
            saveTicket(expiredBooking)
        }

        if (currentRoutes.isEmpty()) {
            val seedRoutes = listOf(
                FavouriteRoute("SHF-STP", "SHF", "Sheffield", "STP", "London St Pancras"),
                FavouriteRoute("LDS-MAN", "LDS", "Leeds", "MAN", "Manchester Piccadilly")
            )
            if (dao != null) {
                seedRoutes.forEach {
                    dao.upsertFavouriteRoute(FavouriteRouteEntity(it.id, it.originCrs, it.originName, it.destCrs, it.destName))
                }
                dao.insertFavouriteStation(FavouriteStationEntity("SHF", System.currentTimeMillis()))
                dao.insertFavouriteStation(FavouriteStationEntity("LDS", System.currentTimeMillis() - 1000))
            } else {
                memoryRoutes.value = seedRoutes
                memoryStations.value = listOf("SHF", "LDS")
            }
        }
    }

    override fun observeTickets(): Flow<List<Booking>> {
        if (dao == null) return memoryTickets
        return dao.observeTickets().map { entities ->
            entities.mapNotNull { entity ->
                runCatching {
                    val json = protector.unprotect(entity.protectedJsonPayload)
                    bookingAdapter.fromJson(json)?.copy(
                        ticketStatus = runCatching { TicketStatus.valueOf(entity.ticketStatus) }
                            .getOrDefault(TicketStatus.AVAILABLE),
                        lastSyncedEpochMs = entity.lastSyncedEpochMs
                    )
                }.getOrNull()
            }
        }
    }

    override fun observeFavouriteRoutes(): Flow<List<FavouriteRoute>> {
        if (dao == null) return memoryRoutes
        return dao.observeFavouriteRoutes().map { list ->
            list.map { FavouriteRoute(it.id, it.originCrs, it.originName, it.destCrs, it.destName) }
        }
    }

    override fun observeFavouriteStations(): Flow<List<String>> {
        return dao?.observeFavouriteStationCodes() ?: memoryStations
    }

    override fun observeRecentSearches(): Flow<List<RecentSearch>> {
        if (dao == null) return memoryRecent
        return dao.observeRecentSearches().map { list ->
            list.map {
                RecentSearch(it.id, it.originCrs, it.originName, it.destCrs, it.destName, it.travelDate, it.searchedAtEpochMs)
            }
        }
    }

    override suspend fun saveTicket(booking: Booking) {
        if (dao == null) {
            val current = memoryTickets.value.filterNot { it.bookingReference == booking.bookingReference }
            memoryTickets.value = listOf(booking) + current
            return
        }
        val json = bookingAdapter.toJson(booking)
        val protectedPayload = protector.protect(json)
        dao.upsertTicket(
            CachedTicketEntity(
                bookingReference = booking.bookingReference,
                ticketStatus = booking.ticketStatus.name,
                protectedJsonPayload = protectedPayload,
                timestampEpochMs = booking.timestampEpochMs,
                lastSyncedEpochMs = booking.lastSyncedEpochMs
            )
        )
    }

    override suspend fun updateTicketStatus(bookingReference: String, status: TicketStatus) {
        val now = System.currentTimeMillis()
        if (dao == null) {
            memoryTickets.value = memoryTickets.value.map {
                if (it.bookingReference == bookingReference) it.copy(ticketStatus = status, lastSyncedEpochMs = now) else it
            }
            return
        }
        val entity = dao.getTicketByRef(bookingReference) ?: return
        val booking = runCatching {
            bookingAdapter.fromJson(protector.unprotect(entity.protectedJsonPayload))
        }.getOrNull()
        if (booking != null) {
            saveTicket(booking.copy(ticketStatus = status, lastSyncedEpochMs = now))
        } else {
            dao.updateTicketStatus(bookingReference, status.name, now)
        }
    }

    override suspend fun getTicket(bookingReference: String): Booking? {
        if (dao == null) {
            return memoryTickets.value.find { it.bookingReference == bookingReference }
        }
        val entity = dao.getTicketByRef(bookingReference) ?: return null
        return runCatching {
            val json = protector.unprotect(entity.protectedJsonPayload)
            bookingAdapter.fromJson(json)?.copy(
                ticketStatus = runCatching { TicketStatus.valueOf(entity.ticketStatus) }
                    .getOrDefault(TicketStatus.AVAILABLE),
                lastSyncedEpochMs = entity.lastSyncedEpochMs
            )
        }.getOrNull()
    }

    override suspend fun toggleFavouriteRoute(origin: Station, destination: Station) {
        val id = "${origin.crsCode}-${destination.crsCode}"
        if (dao == null) {
            val exists = memoryRoutes.value.any { it.id == id }
            memoryRoutes.value = if (exists) {
                memoryRoutes.value.filterNot { it.id == id }
            } else {
                memoryRoutes.value + FavouriteRoute(id, origin.crsCode, origin.name, destination.crsCode, destination.name)
            }
            return
        }
        if (dao.getFavouriteRoute(id) != null) {
            dao.deleteFavouriteRoute(id)
        } else {
            dao.upsertFavouriteRoute(FavouriteRouteEntity(id, origin.crsCode, origin.name, destination.crsCode, destination.name))
        }
    }

    override suspend fun toggleFavouriteStation(crsCode: String) {
        val code = crsCode.uppercase()
        if (dao == null) {
            val exists = memoryStations.value.contains(code)
            memoryStations.value = if (exists) memoryStations.value - code else listOf(code) + memoryStations.value
            return
        }
        if (dao.countFavouriteStation(code) > 0) {
            dao.deleteFavouriteStation(code)
        } else {
            dao.insertFavouriteStation(FavouriteStationEntity(code, System.currentTimeMillis()))
        }
    }

    override suspend fun recordRecentSearch(origin: Station, destination: Station, travelDate: String) {
        val id = "${origin.crsCode}-${destination.crsCode}-$travelDate"
        val item = RecentSearch(id, origin.crsCode, origin.name, destination.crsCode, destination.name, travelDate, System.currentTimeMillis())
        if (dao == null) {
            memoryRecent.value = (listOf(item) + memoryRecent.value.filterNot { it.id == id }).take(6)
            return
        }
        dao.upsertRecentSearch(
            RecentSearchEntity(item.id, item.originCrs, item.originName, item.destCrs, item.destName, item.travelDate, item.searchedAtEpochMs)
        )
    }

    override suspend fun clearAllLocalData() {
        if (dao == null) {
            memoryTickets.value = emptyList()
            memoryRoutes.value = emptyList()
            memoryStations.value = emptyList()
            memoryRecent.value = emptyList()
            return
        }
        dao.deleteAllTickets()
        dao.deleteAllFavouriteRoutes()
        dao.deleteAllFavouriteStations()
        dao.deleteAllRecentSearches()
        dao.deleteAllAfterSales()
    }
}

class AfterSalesServiceImpl(
    private val dao: WalletDao?
) : AfterSalesService {
    private val memoryCases = MutableStateFlow<List<AfterSalesCase>>(emptyList())

    override fun observeCases(): Flow<List<AfterSalesCase>> {
        if (dao == null) return memoryCases
        return dao.observeAfterSalesCases().map { list ->
            list.map { entity ->
                AfterSalesCase(
                    id = entity.id,
                    bookingReference = entity.bookingReference,
                    type = runCatching { AfterSalesType.valueOf(entity.type) }.getOrDefault(AfterSalesType.REFUND_REQUEST),
                    status = runCatching { AfterSalesStatus.valueOf(entity.status) }.getOrDefault(AfterSalesStatus.SUBMITTED),
                    reason = entity.reason,
                    submittedAtEpochMs = entity.submittedAtEpochMs,
                    note = entity.note
                )
            }
        }
    }

    override suspend fun submitCase(
        bookingReference: String,
        type: AfterSalesType,
        reason: String
    ): AfterSalesCase {
        val note = when (type) {
            AfterSalesType.REFUND_REQUEST ->
                "Submitted for operator review. Eligibility and any £10 administration fee depend on ticket type and travel status; automatic refund is not guaranteed."
            AfterSalesType.TICKET_CHANGE ->
                "Change request logged. Fare differences and operator admin rules apply prior to original departure."
            AfterSalesType.DISRUPTION_CLAIM ->
                "Delay Repay claim recorded. Final compensation depends on verified delay duration and operator scheme rules."
        }
        val item = AfterSalesCase(
            id = "CASE-${UUID.randomUUID().toString().take(6).uppercase()}",
            bookingReference = bookingReference.trim().uppercase(),
            type = type,
            status = AfterSalesStatus.SUBMITTED,
            reason = reason.trim(),
            submittedAtEpochMs = System.currentTimeMillis(),
            note = note
        )
        if (dao == null) {
            memoryCases.value = listOf(item) + memoryCases.value
        } else {
            dao.upsertAfterSalesCase(
                AfterSalesEntity(
                    id = item.id,
                    bookingReference = item.bookingReference,
                    type = item.type.name,
                    status = item.status.name,
                    reason = item.reason,
                    submittedAtEpochMs = item.submittedAtEpochMs,
                    note = item.note
                )
            )
        }
        return item
    }
}
