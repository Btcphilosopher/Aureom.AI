package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DepartureBoard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.DepartureBoard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.ServiceStatus
import com.example.data.model.TicketStatus
import com.example.ui.AppTab
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailAmber
import com.example.ui.theme.RailGreen
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

@Composable
fun BrLogo(
    modifier: Modifier = Modifier,
    size: Dp = 36.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .background(BritishRailRed)
            .padding(3.dp),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_br_logo_1794486819321),
            contentDescription = "British Rail Double Arrow Logo",
            modifier = Modifier.size(size - 6.dp)
        )
    }
}

@Composable
fun BrMobileHeader(
    isSignedIn: Boolean,
    passengerName: String,
    isOfflineSimulated: Boolean,
    language: AppLanguage,
    onProfileClick: () -> Unit,
    onBrandClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailBlack)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clickable(onClick = onBrandClick)
                    .testTag("br_brand_header")
            ) {
                BrLogo(size = 34.dp)
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .border(1.5.dp, BritishRailWhite)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "British Rail",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BritishRailWhite
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (language == AppLanguage.CYMRAEG) "Eich Taith" else "Your Journey",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 13.sp,
                    color = Color(0xFFCCCCCC),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .border(1.dp, if (isOfflineSimulated) RailAmber else Color(0xFF666666))
                        .background(if (isOfflineSimulated) Color(0xFF3A1D00) else Color.Transparent)
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isOfflineSimulated) "OFFLINE" else "DEMO",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = BritishRailWhite,
                        letterSpacing = 0.8.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .heightIn(min = 36.dp)
                        .border(1.dp, BritishRailWhite)
                        .clickable { onProfileClick() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("header_profile_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isSignedIn) passengerName.substringBefore(" ") else if (language == AppLanguage.CYMRAEG) "Gwestai" else "Guest",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = BritishRailWhite
                    )
                }
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(BritishRailRed)
        )
    }
}

private data class NavTabMeta(
    val tab: AppTab,
    val labelEn: String,
    val labelCy: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val navTabs = listOf(
    NavTabMeta(AppTab.HOME, "Home", "Cartref", Icons.Filled.Home, Icons.Outlined.Home),
    NavTabMeta(AppTab.PLAN, "Plan", "Cynllunio", Icons.Filled.Search, Icons.Outlined.Search),
    NavTabMeta(AppTab.TICKETS, "Tickets", "Tocynnau", Icons.Filled.ConfirmationNumber, Icons.Outlined.ConfirmationNumber),
    NavTabMeta(AppTab.DEPARTURES, "Departures", "Ymadawiadau", Icons.Filled.DepartureBoard, Icons.Outlined.DepartureBoard),
    NavTabMeta(AppTab.ACCOUNT, "Account", "Cyfrif", Icons.Filled.AccountCircle, Icons.Outlined.AccountCircle)
)

@Composable
fun BrBottomNavigationBar(
    activeTab: AppTab,
    availableTicketCount: Int,
    language: AppLanguage,
    onSelectTab: (AppTab) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .navigationBarsPadding()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(BritishRailBlack)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 60.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            navTabs.forEach { meta ->
                val isSelected = activeTab == meta.tab
                val label = if (language == AppLanguage.CYMRAEG) meta.labelCy else meta.labelEn
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 60.dp)
                        .background(if (isSelected) BritishRailRedLight else BritishRailWhite)
                        .clickable { onSelectTab(meta.tab) }
                        .semantics { contentDescription = "$label tab" }
                        .testTag("nav_tab_${meta.tab.name.lowercase()}"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Top
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .background(if (isSelected) BritishRailRed else Color.Transparent)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(contentAlignment = Alignment.TopEnd) {
                        Icon(
                            imageVector = if (isSelected) meta.selectedIcon else meta.unselectedIcon,
                            contentDescription = null,
                            tint = if (isSelected) BritishRailRed else BritishRailBlack,
                            modifier = Modifier.size(22.dp)
                        )
                        if (meta.tab == AppTab.TICKETS && availableTicketCount > 0) {
                            Box(
                                modifier = Modifier
                                    .background(BritishRailRed)
                                    .padding(horizontal = 3.dp, vertical = 0.5.dp)
                            ) {
                                Text(
                                    text = availableTicketCount.toString(),
                                    color = BritishRailWhite,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = label,
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 11.sp,
                        color = if (isSelected) BritishRailRed else BritishRailBlack,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
fun BrNavigationRail(
    activeTab: AppTab,
    availableTicketCount: Int,
    language: AppLanguage,
    onSelectTab: (AppTab) -> Unit
) {
    Column(
        modifier = Modifier
            .width(96.dp)
            .fillMaxHeight()
            .background(BritishRailWhite)
            .border(1.dp, BritishRailBlack)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        navTabs.forEach { meta ->
            val isSelected = activeTab == meta.tab
            val label = if (language == AppLanguage.CYMRAEG) meta.labelCy else meta.labelEn
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 64.dp)
                    .background(if (isSelected) BritishRailRedLight else BritishRailWhite)
                    .clickable { onSelectTab(meta.tab) }
                    .padding(horizontal = 4.dp, vertical = 8.dp)
                    .testTag("nav_rail_${meta.tab.name.lowercase()}"),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (isSelected) meta.selectedIcon else meta.unselectedIcon,
                    contentDescription = label,
                    tint = if (isSelected) BritishRailRed else BritishRailBlack,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (meta.tab == AppTab.TICKETS && availableTicketCount > 0) "$label ($availableTicketCount)" else label,
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 11.sp,
                    color = if (isSelected) BritishRailRed else BritishRailBlack,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun BrServiceStatusBadge(
    status: ServiceStatus,
    language: AppLanguage = AppLanguage.ENGLISH
) {
    val (bg, fg, icon) = when (status) {
        ServiceStatus.ON_TIME -> Triple(Color(0xFFE8F5E9), RailGreen, Icons.Default.CheckCircle)
        ServiceStatus.SCHEDULED -> Triple(RailGreyPanel, BritishRailBlack, Icons.Default.Schedule)
        ServiceStatus.DELAYED -> Triple(Color(0xFFFFF3E0), RailAmber, Icons.Default.Warning)
        ServiceStatus.CANCELLED -> Triple(BritishRailRedLight, BritishRailRed, Icons.Default.Cancel)
        ServiceStatus.SIMULATED -> Triple(Color(0xFFECEFF1), BritishRailBlack, Icons.Default.Schedule)
    }
    Row(
        modifier = Modifier
            .border(1.dp, fg)
            .background(bg)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = fg, modifier = Modifier.size(12.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = status.localized(language).uppercase(),
            fontFamily = RailAlphabetFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = fg
        )
    }
}

@Composable
fun BrTicketStatusBadge(
    status: TicketStatus,
    language: AppLanguage = AppLanguage.ENGLISH
) {
    val (bg, fg) = when (status) {
        TicketStatus.AVAILABLE -> Color(0xFFE8F5E9) to RailGreen
        TicketStatus.PENDING -> Color(0xFFFFF3E0) to RailAmber
        TicketStatus.EXPIRED -> RailGreyPanel to RailGreySubtext
        TicketStatus.CANCELLED -> BritishRailRedLight to BritishRailRed
        TicketStatus.REFUNDED -> Color(0xFFE3F2FD) to BritishRailBlack
    }
    Box(
        modifier = Modifier
            .border(1.dp, fg)
            .background(bg)
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(
            text = status.localized(language).uppercase(),
            fontFamily = RailAlphabetFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = fg
        )
    }
}

@Composable
fun BrSectionRule(
    title: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title.uppercase(),
            fontFamily = RailAlphabetFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = BritishRailBlack,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(BritishRailBlack)
        )
    }
}

@Composable
fun BrSchematicLine(
    originName: String,
    destinationName: String,
    modifier: Modifier = Modifier,
    interchangeName: String? = null
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = originName,
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = BritishRailBlack,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (interchangeName != null) {
                Text(
                    text = interchangeName,
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 10.sp,
                    color = RailGreySubtext
                )
            }
            Text(
                text = destinationName,
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = BritishRailBlack,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(14.dp)
        ) {
            val circleRadius = 4.5.dp.toPx()
            val strokeW = 2.5.dp.toPx()
            val centerY = size.height / 2
            val startX = circleRadius + 2.dp.toPx()
            val endX = size.width - circleRadius - 2.dp.toPx()

            drawLine(
                color = BritishRailRed,
                start = Offset(startX, centerY),
                end = Offset(endX, centerY),
                strokeWidth = strokeW
            )
            drawCircle(color = BritishRailWhite, radius = circleRadius, center = Offset(startX, centerY))
            drawCircle(color = BritishRailBlack, radius = circleRadius, center = Offset(startX, centerY), style = Stroke(2.dp.toPx()))
            if (interchangeName != null) {
                val midX = size.width / 2
                drawCircle(color = BritishRailWhite, radius = circleRadius - 1.dp.toPx(), center = Offset(midX, centerY))
                drawCircle(color = BritishRailBlack, radius = circleRadius - 1.dp.toPx(), center = Offset(midX, centerY), style = Stroke(2.dp.toPx()))
            }
            drawCircle(color = BritishRailWhite, radius = circleRadius, center = Offset(endX, centerY))
            drawCircle(color = BritishRailBlack, radius = circleRadius, center = Offset(endX, centerY), style = Stroke(2.dp.toPx()))
        }
    }
}

enum class BrButtonStyle {
    PRIMARY_RED,
    SECONDARY_BLACK,
    OUTLINED,
    SELECTED_RED
}

@Composable
fun BrButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: BrButtonStyle = BrButtonStyle.PRIMARY_RED,
    enabled: Boolean = true,
    height: Dp = 48.dp,
    testTag: String = ""
) {
    val bg = when (style) {
        BrButtonStyle.PRIMARY_RED -> if (enabled) BritishRailRed else RailGreyBorder
        BrButtonStyle.SECONDARY_BLACK -> if (enabled) BritishRailBlack else RailGreyBorder
        BrButtonStyle.OUTLINED -> BritishRailWhite
        BrButtonStyle.SELECTED_RED -> BritishRailRed
    }
    val contentColor = when (style) {
        BrButtonStyle.OUTLINED -> if (enabled) BritishRailBlack else RailGreySubtext
        else -> BritishRailWhite
    }
    val borderMod = if (style == BrButtonStyle.OUTLINED) {
        Modifier.border(1.5.dp, if (enabled) BritishRailBlack else RailGreyBorder, RoundedCornerShape(0.dp))
    } else Modifier

    Box(
        modifier = modifier
            .then(borderMod)
            .heightIn(min = maxOf(48.dp, height))
            .background(bg, RoundedCornerShape(0.dp))
            .clickable(
                enabled = enabled,
                onClick = onClick,
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple()
            )
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontFamily = RailAlphabetFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = contentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun QrCodeView(
    dataPayload: String,
    modifier: Modifier = Modifier,
    qrBoxSize: Dp = 150.dp
) {
    Canvas(
        modifier = modifier
            .size(qrBoxSize)
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(8.dp)
            .semantics { contentDescription = "QR inspection ticket barcode" }
            .testTag("qr_ticket_canvas")
    ) {
        val matrixSize = 25
        val cellSize = this.size.width / matrixSize

        fun drawPositionMarker(startCol: Int, startRow: Int) {
            drawRect(BritishRailBlack, Offset(startCol * cellSize, startRow * cellSize), Size(7 * cellSize, 7 * cellSize))
            drawRect(BritishRailWhite, Offset((startCol + 1) * cellSize, (startRow + 1) * cellSize), Size(5 * cellSize, 5 * cellSize))
            drawRect(BritishRailBlack, Offset((startCol + 2) * cellSize, (startRow + 2) * cellSize), Size(3 * cellSize, 3 * cellSize))
        }

        drawPositionMarker(0, 0)
        drawPositionMarker(matrixSize - 7, 0)
        drawPositionMarker(0, matrixSize - 7)

        val hash = dataPayload.hashCode()
        for (row in 0 until matrixSize) {
            for (col in 0 until matrixSize) {
                val inTopLeft = row < 8 && col < 8
                val inTopRight = row < 8 && col >= matrixSize - 8
                val inBottomLeft = row >= matrixSize - 8 && col < 8
                if (!inTopLeft && !inTopRight && !inBottomLeft) {
                    val bit = ((hash + row * 31 + col * 17) xor (row * col + 7)) % 3 == 0
                    if (bit) {
                        drawRect(BritishRailBlack, Offset(col * cellSize, row * cellSize), Size(cellSize, cellSize))
                    }
                }
            }
        }
    }
}
