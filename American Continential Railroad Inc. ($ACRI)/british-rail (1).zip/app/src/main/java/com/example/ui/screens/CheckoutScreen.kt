package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentMethod
import com.example.data.model.SimulatedPaymentOutcome
import com.example.data.model.formatPence
import com.example.ui.AppTab
import com.example.ui.CheckoutStage
import com.example.ui.YourJourneyUiState
import com.example.ui.YourJourneyViewModel
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrSchematicLine
import com.example.ui.components.BrSectionRule
import com.example.ui.components.QrCodeView
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailAmber
import com.example.ui.theme.RailGreen
import com.example.ui.theme.RailGreyBackground
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext
import com.example.ui.theme.RailTicketBuff
import com.example.ui.theme.RailTicketOrangeHeader

@Composable
fun CheckoutScreen(
    uiState: YourJourneyUiState,
    viewModel: YourJourneyViewModel
) {
    val journey = uiState.selectedJourney
    val fare = uiState.selectedFare
    val breakdown = uiState.fareBreakdown

    if (journey == null || fare == null || breakdown == null) {
        viewModel.exitCheckout()
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RailGreyBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top bar with Back
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (uiState.checkoutStage != CheckoutStage.ISSUED_CONFIRMATION) {
                    IconButton(
                        onClick = { viewModel.exitCheckout() },
                        modifier = Modifier.testTag("checkout_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to results", tint = BritishRailBlack)
                    }
                }
                Column {
                    Text(
                        text = when (uiState.checkoutStage) {
                            CheckoutStage.REVIEW_AND_PAY -> "Checkout & Payment"
                            CheckoutStage.ISSUANCE_PENDING -> "Ticket Issuance Pending"
                            CheckoutStage.ISSUED_CONFIRMATION -> "Booking Confirmed"
                            CheckoutStage.NONE -> ""
                        },
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = BritishRailBlack
                    )
                    Text(
                        text = "Idempotency key: ${uiState.idempotencyKey.take(8)} • ${uiState.paymentProviderName}",
                        fontSize = 11.sp,
                        color = RailGreySubtext
                    )
                }
            }

            when (uiState.checkoutStage) {
                CheckoutStage.REVIEW_AND_PAY -> {
                    // Journey & Fare Breakdown
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRailWhite)
                            .border(2.dp, BritishRailBlack)
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BrSectionRule("Journey & Fare Breakdown")
                        Text(
                            text = "${journey.departureTime} → ${journey.arrivalTime} • ${uiState.travelDate}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = BritishRailBlack
                        )
                        BrSchematicLine(journey.origin.name, journey.destination.name)
                        Text(
                            text = "${fare.ticketType.displayName} (${fare.travelClass.displayName}) • ${uiState.passengers.summary()}",
                            fontSize = 12.sp,
                            color = BritishRailBlack
                        )

                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(RailGreyBorder))

                        PriceLine("Adults (${uiState.passengers.adults})", formatPence(breakdown.baseAdultPence))
                        if (uiState.passengers.children > 0) {
                            PriceLine("Children (${uiState.passengers.children})", formatPence(breakdown.baseChildPence))
                        }
                        if (breakdown.railcardDiscountPence > 0) {
                            PriceLine("Railcard discount", "-${formatPence(breakdown.railcardDiscountPence)}")
                        }
                        breakdown.railcardAppliedNote?.let { note ->
                            Text(note, fontSize = 11.sp, color = if (breakdown.railcardDiscountPence > 0) RailGreen else RailAmber)
                        }
                        PriceLine("Seat reservation & booking fee", "£0.00")
                        Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(BritishRailBlack))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total (0% UK Rail VAT)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BritishRailBlack)
                            Text(breakdown.formattedTotal, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = BritishRailRed)
                        }
                    }

                    // Ticket Restrictions & Refund Policy
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RailGreyPanel)
                            .border(1.dp, BritishRailBlack)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("TICKET RESTRICTIONS & REFUND TERMS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = BritishRailBlack)
                        Text(fare.restrictions, fontSize = 12.sp, color = BritishRailBlack)
                        Text(fare.ticketType.defaultRefundPolicy, fontSize = 12.sp, color = RailGreySubtext)
                    }

                    // Payment Method & Acquirer Notice
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRailWhite)
                            .border(1.5.dp, BritishRailBlack)
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BrSectionRule("Payment Method")
                        Text(
                            text = "Offline demonstration gateway. Real payments require a configured backend payment provider; ordinary phone NFC hardware cannot act as a card acquirer.",
                            fontSize = 11.sp,
                            color = RailGreySubtext
                        )
                        PaymentMethod.entries.forEach { method ->
                            val selected = uiState.paymentMethod == method
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.5.dp, if (selected) BritishRailRed else RailGreyBorder)
                                    .background(if (selected) BritishRailRedLight else BritishRailWhite)
                                    .clickable { viewModel.setPaymentMethod(method) }
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(method.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BritishRailBlack)
                                if (selected) Text("SELECTED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BritishRailRed)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("DEMO PAYMENT OUTCOME SIMULATION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                        SimulatedPaymentOutcome.entries.forEach { outcome ->
                            val selected = uiState.simulatedOutcome == outcome
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, if (selected) BritishRailBlack else RailGreyBorder)
                                    .background(if (selected) RailGreyPanel else BritishRailWhite)
                                    .clickable { viewModel.setSimulatedOutcome(outcome) }
                                    .padding(horizontal = 10.dp, vertical = 7.dp)
                                    .testTag("sim_outcome_${outcome.name}"),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = when (outcome) {
                                        SimulatedPaymentOutcome.SUCCESS -> "Authorised & issue ticket"
                                        SimulatedPaymentOutcome.DECLINED -> "Simulate card declined"
                                        SimulatedPaymentOutcome.TIMEOUT -> "Simulate gateway timeout"
                                        SimulatedPaymentOutcome.CANCELLED -> "Simulate user cancelled"
                                        SimulatedPaymentOutcome.UNCERTAIN_RECONCILE -> "Simulate uncertain network drop (Reconcile)"
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    color = BritishRailBlack
                                )
                                if (selected) Text("✓", fontWeight = FontWeight.Bold, color = BritishRailRed)
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.setForcePendingIssuance(!uiState.forcePendingIssuance) }
                        ) {
                            Checkbox(
                                checked = uiState.forcePendingIssuance,
                                onCheckedChange = { viewModel.setForcePendingIssuance(it) }
                            )
                            Text(
                                text = "Simulate separated issuance delay (Paid → Pending Ticket)",
                                fontSize = 12.sp,
                                color = BritishRailBlack
                            )
                        }
                    }

                    uiState.paymentErrorOrInfo?.let { msg ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BritishRailRedLight)
                                .border(1.5.dp, BritishRailRed)
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = BritishRailRed)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(msg, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
                            }
                            if (uiState.canReconcilePayment) {
                                BrButton(
                                    text = "Reconcile payment status (Idempotent)",
                                    onClick = { viewModel.reconcileUncertainPayment() },
                                    style = BrButtonStyle.SECONDARY_BLACK,
                                    modifier = Modifier.fillMaxWidth(),
                                    testTag = "reconcile_payment_button"
                                )
                            }
                        }
                    }

                    if (uiState.isProcessingPayment) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(color = BritishRailRed)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Processing payment & issuing ticket...", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        BrButton(
                            text = "Confirm & pay ${breakdown.formattedTotal} (Demo)",
                            onClick = { viewModel.submitCheckoutPayment() },
                            modifier = Modifier.fillMaxWidth(),
                            height = 52.dp,
                            testTag = "pay_now_button"
                        )
                    }
                }

                CheckoutStage.ISSUANCE_PENDING -> {
                    val pending = uiState.pendingBooking
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRailWhite)
                            .border(2.dp, RailAmber)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("PAYMENT CONFIRMED — TICKET ISSUANCE PENDING", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = RailAmber)
                        Text(
                            text = "Booking ${pending?.bookingReference ?: ""} was authorised (${pending?.paymentAuthCode ?: ""}), but barcode issuance has not yet completed. Do NOT pay again.",
                            fontSize = 13.sp,
                            color = BritishRailBlack
                        )
                        uiState.paymentErrorOrInfo?.let {
                            Text(it, fontSize = 12.sp, color = RailGreySubtext)
                        }
                        BrButton(
                            text = "Retry ticket issuance",
                            onClick = { viewModel.retryPendingTicketIssuance(pending) },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "retry_issuance_button"
                        )
                        BrButton(
                            text = "View pending item in Ticket Wallet",
                            onClick = {
                                viewModel.exitCheckout()
                                viewModel.selectTab(AppTab.TICKETS)
                            },
                            style = BrButtonStyle.OUTLINED,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                CheckoutStage.ISSUED_CONFIRMATION -> {
                    val booking = uiState.confirmedBooking
                    if (booking != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFE8F5E9))
                                .border(1.5.dp, RailGreen)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RailGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Ticket issued & protected offline (${uiState.walletProtectionMechanism})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = BritishRailBlack
                            )
                        }

                        // Classic Buff & Orange British Rail Ticket Preview
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(RailTicketBuff)
                                .border(2.dp, BritishRailBlack)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(RailTicketOrangeHeader)
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("BRITISH RAIL TICKET", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BritishRailWhite)
                                Text("NOT VALID FOR TRAVEL", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = BritishRailWhite)
                            }
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("${booking.journey.origin.name} → ${booking.journey.destination.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BritishRailBlack)
                                Text("${booking.travelDate} • Departs ${booking.journey.departureTime} • ${booking.selectedFare.ticketType.displayName}", fontSize = 13.sp, color = BritishRailBlack)
                                Text("Ref: ${booking.bookingReference} • Collect code: ${booking.collectionCode}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BritishRailRed)
                                Text(booking.seatReservation, fontSize = 12.sp, color = BritishRailBlack)
                                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    QrCodeView(dataPayload = booking.qrPayload, qrBoxSize = 148.dp)
                                }
                            }
                        }

                        BrButton(
                            text = "Open in Ticket Wallet",
                            onClick = { viewModel.openTicketDetail(booking) },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "open_issued_ticket_wallet"
                        )
                        BrButton(
                            text = "Follow journey live",
                            onClick = {
                                viewModel.exitCheckout()
                                viewModel.followBooking(booking.bookingReference)
                            },
                            style = BrButtonStyle.SECONDARY_BLACK,
                            modifier = Modifier.fillMaxWidth()
                        )
                        BrButton(
                            text = "Back to Home",
                            onClick = {
                                viewModel.exitCheckout()
                                viewModel.selectTab(AppTab.HOME)
                            },
                            style = BrButtonStyle.OUTLINED,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                CheckoutStage.NONE -> Unit
            }
        }
    }
}

@Composable
private fun PriceLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = RailGreySubtext)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
    }
}
