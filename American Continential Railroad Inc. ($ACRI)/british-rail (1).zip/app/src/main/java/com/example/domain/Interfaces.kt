package com.example.domain

import com.example.data.model.AfterSalesCase
import com.example.data.model.AfterSalesType
import com.example.data.model.AssistanceRequest
import com.example.data.model.Booking
import com.example.data.model.DepartureItem
import com.example.data.model.DisruptionNotice
import com.example.data.model.FareBreakdown
import com.example.data.model.FavouriteRoute
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.PaymentRequest
import com.example.data.model.PaymentResult
import com.example.data.model.RecentSearch
import com.example.data.model.ServiceFare
import com.example.data.model.Station
import com.example.data.model.StationAccessibilityInfo
import com.example.data.model.TicketIssuanceResult
import com.example.data.model.TicketStatus
import com.example.data.model.TravelClass
import kotlinx.coroutines.flow.Flow

interface StationRepository {
    suspend fun getStations(): List<Station>
    suspend fun searchStations(query: String): List<Station>
    suspend fun getStationByCrs(crs: String): Station?
    suspend fun getNearestStation(latitude: Double, longitude: Double): Station?
    fun getStationAccessibility(stationCrs: String): StationAccessibilityInfo?
    fun getAllStationAccessibility(): List<StationAccessibilityInfo>
}

interface TimetableProvider {
    suspend fun getServices(
        originCrs: String,
        destCrs: String,
        serviceDate: String,
        departTime: String,
        arriveBy: Boolean,
        stepFreeOnly: Boolean
    ): List<JourneyOption>
}

interface JourneyPlanner {
    suspend fun planJourney(
        origin: Station,
        destination: Station,
        serviceDate: String,
        departTime: String,
        arriveBy: Boolean,
        isReturn: Boolean,
        returnDate: String? = null,
        stepFreeOnly: Boolean = false,
        preferredClass: TravelClass = TravelClass.STANDARD
    ): List<JourneyOption>
}

interface DepartureProvider {
    suspend fun getDepartures(stationCrs: String): Pair<List<DepartureItem>, Long>
}

interface FareProvider {
    fun getBreakdownForServiceFare(
        fare: ServiceFare,
        passengers: PassengerConfig,
        isReturn: Boolean
    ): FareBreakdown
}

interface BookingService {
    suspend fun createPendingBooking(
        journey: JourneyOption,
        fare: ServiceFare,
        passengers: PassengerConfig,
        travelDate: String,
        returnDate: String?,
        isReturn: Boolean,
        totalPence: Int,
        idempotencyKey: String,
        isGuestPurchase: Boolean
    ): Booking

    suspend fun markPaymentConfirmedAwaitingIssuance(
        bookingReference: String,
        paymentAuthCode: String
    ): Booking

    suspend fun finalizeIssuedBooking(
        bookingReference: String,
        qrPayload: String
    ): Booking

    suspend fun getBooking(bookingReference: String): Booking?
    suspend fun findBookingForRecovery(reference: String, verificationCode: String): Result<Booking>
}

interface PaymentProvider {
    val providerName: String
    val requiresConfiguredBackend: Boolean
    suspend fun processPayment(request: PaymentRequest): PaymentResult
    suspend fun reconcilePayment(idempotencyKey: String, bookingReference: String): PaymentResult
}

interface TicketIssuer {
    suspend fun issueTicket(booking: Booking, forcePendingForDemo: Boolean = false): TicketIssuanceResult
}

interface TicketWalletRepository {
    fun observeTickets(): Flow<List<Booking>>
    fun observeFavouriteRoutes(): Flow<List<FavouriteRoute>>
    fun observeFavouriteStations(): Flow<List<String>>
    fun observeRecentSearches(): Flow<List<RecentSearch>>
    suspend fun saveTicket(booking: Booking)
    suspend fun updateTicketStatus(bookingReference: String, status: TicketStatus)
    suspend fun getTicket(bookingReference: String): Booking?
    suspend fun toggleFavouriteRoute(origin: Station, destination: Station)
    suspend fun toggleFavouriteStation(crsCode: String)
    suspend fun recordRecentSearch(origin: Station, destination: Station, travelDate: String)
    suspend fun clearAllLocalData()
}

interface DisruptionProvider {
    suspend fun getDisruptions(routeFilterCrs: String? = null): List<DisruptionNotice>
}

interface PassengerAssistanceService {
    suspend fun requestAssistance(
        bookingReference: String?,
        stationName: String,
        requirement: String
    ): AssistanceRequest

    suspend fun refreshAssistanceStatus(requestId: String): AssistanceRequest?
    fun getActiveRequests(): List<AssistanceRequest>
}

interface PlatformWalletAdapter {
    val isSupportedAndConfigured: Boolean
    val statusDescription: String
    suspend fun addTicketToPlatformWallet(booking: Booking): Result<Unit>
}

interface AfterSalesService {
    fun observeCases(): Flow<List<AfterSalesCase>>
    suspend fun submitCase(
        bookingReference: String,
        type: AfterSalesType,
        reason: String
    ): AfterSalesCase
}

interface CredentialProtector {
    fun protect(plainText: String): String
    fun unprotect(protectedText: String): String
    val protectionMechanism: String
}

interface RailApiClient {
    val isOfflineDemoMode: Boolean
    val endpointNotice: String
}
