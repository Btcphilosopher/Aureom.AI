package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cached_tickets")
data class CachedTicketEntity(
    @PrimaryKey val bookingReference: String,
    val ticketStatus: String,
    val protectedJsonPayload: String,
    val timestampEpochMs: Long,
    val lastSyncedEpochMs: Long
)

@Entity(tableName = "favourite_routes")
data class FavouriteRouteEntity(
    @PrimaryKey val id: String,
    val originCrs: String,
    val originName: String,
    val destCrs: String,
    val destName: String
)

@Entity(tableName = "favourite_stations")
data class FavouriteStationEntity(
    @PrimaryKey val crsCode: String,
    val addedAtEpochMs: Long
)

@Entity(tableName = "recent_searches")
data class RecentSearchEntity(
    @PrimaryKey val id: String,
    val originCrs: String,
    val originName: String,
    val destCrs: String,
    val destName: String,
    val travelDate: String,
    val searchedAtEpochMs: Long
)

@Entity(tableName = "after_sales_cases")
data class AfterSalesEntity(
    @PrimaryKey val id: String,
    val bookingReference: String,
    val type: String,
    val status: String,
    val reason: String,
    val submittedAtEpochMs: Long,
    val note: String
)

@Dao
interface WalletDao {
    @Query("SELECT * FROM cached_tickets ORDER BY timestampEpochMs DESC")
    fun observeTickets(): Flow<List<CachedTicketEntity>>

    @Query("SELECT * FROM cached_tickets WHERE bookingReference = :ref LIMIT 1")
    suspend fun getTicketByRef(ref: String): CachedTicketEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTicket(entity: CachedTicketEntity)

    @Query("UPDATE cached_tickets SET ticketStatus = :status, lastSyncedEpochMs = :syncedAt WHERE bookingReference = :ref")
    suspend fun updateTicketStatus(ref: String, status: String, syncedAt: Long)

    @Query("DELETE FROM cached_tickets")
    suspend fun deleteAllTickets()

    @Query("SELECT * FROM favourite_routes ORDER BY originName ASC")
    fun observeFavouriteRoutes(): Flow<List<FavouriteRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFavouriteRoute(route: FavouriteRouteEntity)

    @Query("DELETE FROM favourite_routes WHERE id = :id")
    suspend fun deleteFavouriteRoute(id: String)

    @Query("SELECT * FROM favourite_routes WHERE id = :id LIMIT 1")
    suspend fun getFavouriteRoute(id: String): FavouriteRouteEntity?

    @Query("DELETE FROM favourite_routes")
    suspend fun deleteAllFavouriteRoutes()

    @Query("SELECT crsCode FROM favourite_stations ORDER BY addedAtEpochMs DESC")
    fun observeFavouriteStationCodes(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavouriteStation(entity: FavouriteStationEntity)

    @Query("DELETE FROM favourite_stations WHERE crsCode = :crs")
    suspend fun deleteFavouriteStation(crs: String)

    @Query("SELECT COUNT(*) FROM favourite_stations WHERE crsCode = :crs")
    suspend fun countFavouriteStation(crs: String): Int

    @Query("DELETE FROM favourite_stations")
    suspend fun deleteAllFavouriteStations()

    @Query("SELECT * FROM recent_searches ORDER BY searchedAtEpochMs DESC LIMIT 6")
    fun observeRecentSearches(): Flow<List<RecentSearchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecentSearch(search: RecentSearchEntity)

    @Query("DELETE FROM recent_searches")
    suspend fun deleteAllRecentSearches()

    @Query("SELECT * FROM after_sales_cases ORDER BY submittedAtEpochMs DESC")
    fun observeAfterSalesCases(): Flow<List<AfterSalesEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAfterSalesCase(item: AfterSalesEntity)

    @Query("DELETE FROM after_sales_cases")
    suspend fun deleteAllAfterSales()
}

@Database(
    entities = [
        CachedTicketEntity::class,
        FavouriteRouteEntity::class,
        FavouriteStationEntity::class,
        RecentSearchEntity::class,
        AfterSalesEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun walletDao(): WalletDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "british_rail_your_journey.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
