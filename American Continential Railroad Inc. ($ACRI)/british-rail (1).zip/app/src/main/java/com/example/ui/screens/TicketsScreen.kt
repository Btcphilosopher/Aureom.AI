package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Booking
import com.example.data.model.TicketStatus
import com.example.ui.AppTab
import com.example.ui.YourJourneyUiState
import com.example.ui.YourJourneyViewModel
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrSchematicLine
import com.example.ui.components.BrSectionRule
import com.example.ui.components.BrTicketStatusBadge
import com.example.ui.components.LostBookingDialog
import com.example.ui.components.QrCodeView
import com.example.ui.components.ReceiptDialog
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailAmber
import com.example.ui.theme.RailGreyBackground
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext
import com.example.ui.theme.RailTicketBuff
import com.example.ui.theme.RailTicketOrangeHeader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TicketsScreen(
    uiState: YourJourneyUiState,
    viewModel: YourJourneyViewModel
) {
    val language = uiState.preferences.language
    var receiptBooking by remember { mutableStateOf<Booking?>(null) }
    var showRecoveryDialog by remember { mutableStateOf(false) }

    val selected = uiState.selectedWalletTicket
    if (selected != null) {
        TicketDetailInspector(
            booking = selected,
            uiState = uiState,
            onBack = { viewModel.closeTicketDetail() },
            onRetryIssuance = { viewModel.retryPendingTicketIssuance(selected) },
            onFollowLive = { viewModel.followBooking(selected.bookingReference) },
            onOpenReceipt = { receiptBooking = selected },
            onPlatformWalletClick = { viewModel.attemptAddToPlatformWallet(selected) },
            onAfterSalesClick = { viewModel.selectTab(AppTab.ACCOUNT) }
        )
    } else {
        val filtered = remember(uiState.tickets, uiState.ticketFilter) {
            if (uiState.ticketFilter == null) uiState.tickets
            else uiState.tickets.filter { it.ticketStatus == uiState.ticketFilter }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(RailGreyBackground),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (language == AppLanguage.CYMRAEG) "Waled Tocynnau" else "Ticket Wallet",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp,
                                color = BritishRailBlack
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = BritishRailBlack, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Offline protected (${uiState.walletProtectionMechanism})",
                                    fontSize = 11.sp,
                                    color = RailGreySubtext
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Offline", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
                            Spacer(modifier = Modifier.width(4.dp))
                            Switch(
                                checked = uiState.isOfflineSimulated,
                                onCheckedChange = { viewModel.toggleOfflineSimulated(it) },
                                modifier = Modifier.testTag("wallet_offline_switch")
                            )
                        }
                    }
                }

                // Offline & Sync Freshness Notice
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRailWhite)
                            .border(1.dp, if (uiState.isOfflineSimulated) RailAmber else BritishRailBlack)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = if (uiState.isOfflineSimulated) RailAmber else BritishRailBlack,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        val syncTime = if (uiState.preferences.lastSyncEpochMs > 0L) {
                            SimpleDateFormat("HH:mm", Locale.UK).format(Date(uiState.preferences.lastSyncEpochMs))
                        } else "Cached locally"
                        Text(
                            text = if (uiState.isOfflineSimulated) {
                                "Offline inspection mode active. Cached QR tickets remain available; live status & refunds require connectivity."
                            } else {
                                "Cached tickets ready offline • Last sync: $syncTime • All demo tickets are NOT VALID FOR TRAVEL."
                            },
                            fontSize = 11.sp,
                            color = BritishRailBlack
                        )
                    }
                }

                // Filter Strip
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        WalletFilterTab("All (${uiState.tickets.size})", uiState.ticketFilter == null) {
                            viewModel.setTicketFilter(null)
                        }
                        TicketStatus.entries.forEach { status ->
                            val count = uiState.tickets.count { it.ticketStatus == status }
                            WalletFilterTab("${status.localized(language)} ($count)", uiState.ticketFilter == status) {
                                viewModel.setTicketFilter(status)
                            }
                        }
                    }
                }

                if (filtered.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BritishRailWhite)
                                .border(1.5.dp, BritishRailBlack)
                                .padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("No tickets in this view", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BritishRailBlack)
                            Text("Plan a journey to purchase a demonstration ticket, or recover a booking by reference.", fontSize = 13.sp, color = RailGreySubtext)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                BrButton("Plan journey", { viewModel.selectTab(AppTab.PLAN) }, modifier = Modifier.weight(1f))
                                BrButton("Find booking", { showRecoveryDialog = true }, style = BrButtonStyle.OUTLINED, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                } else {
                    items(filtered, key = { it.bookingReference }) { booking ->
                        WalletTicketCard(
                            booking = booking,
                            language = language,
                            onClick = { viewModel.openTicketDetail(booking) }
                        )
                    }
                }

                item {
                    BrButton(
                        text = "Recover a booking by reference",
                        onClick = { showRecoveryDialog = true },
                        style = BrButtonStyle.OUTLINED,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "wallet_recover_button"
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }
            }
        }
    }

    receiptBooking?.let { booking ->
        ReceiptDialog(booking = booking, onDismiss = { receiptBooking = null })
    }

    if (showRecoveryDialog) {
        LostBookingDialog(
            recoveryMessage = uiState.recoveryMessage,
            onRecover = { ref, code -> viewModel.recoverLostBooking(ref, code) },
            onDismiss = { showRecoveryDialog = false }
        )
    }
}

@Composable
private fun WalletTicketCard(
    booking: Booking,
    language: AppLanguage,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .border(1.5.dp, BritishRailBlack)
            .clickable { onClick() }
            .testTag("wallet_ticket_${booking.bookingReference}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (booking.ticketStatus == TicketStatus.AVAILABLE) RailTicketOrangeHeader else BritishRailBlack)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${booking.bookingReference} • ${booking.selectedFare.ticketType.getLocalizedName(language)}",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = BritishRailWhite
            )
            Text("DEMO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BritishRailWhite)
        }

        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${booking.travelDate} • ${booking.journey.departureTime}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = BritishRailBlack
                )
                BrTicketStatusBadge(booking.ticketStatus, language)
            }

            BrSchematicLine(booking.journey.origin.name, booking.journey.destination.name)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(booking.seatReservation, fontSize = 11.sp, color = RailGreySubtext)
                Text(booking.formattedPrice, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BritishRailBlack)
            }
        }
    }
}

@Composable
private fun TicketDetailInspector(
    booking: Booking,
    uiState: YourJourneyUiState,
    onBack: () -> Unit,
    onRetryIssuance: () -> Unit,
    onFollowLive: () -> Unit,
    onOpenReceipt: () -> Unit,
    onPlatformWalletClick: () -> Unit,
    onAfterSalesClick: () -> Unit
) {
    val language = uiState.preferences.language
    val syncTime = SimpleDateFormat("dd MMM HH:mm", Locale.UK).format(Date(booking.lastSyncedEpochMs))

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RailGreyBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 620.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("ticket_detail_back")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Ticket Wallet", tint = BritishRailBlack)
                }
                Text("Railway Ticket", fontFamily = RailAlphabetFontFamily, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = BritishRailBlack)
            }

            // Traditional Buff-and-Orange British Rail Ticket Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RailTicketBuff)
                    .border(2.dp, BritishRailBlack)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RailTicketOrangeHeader)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("BRITISH RAIL • RAIL TICKET", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BritishRailWhite)
                        Text(booking.selectedFare.ticketType.getLocalizedName(language), fontSize = 11.sp, color = BritishRailWhite)
                    }
                    BrTicketStatusBadge(booking.ticketStatus, language)
                }

                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, BritishRailRed)
                            .background(BritishRailRedLight)
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "NOT VALID FOR TRAVEL — DEMONSTRATION TICKET",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = BritishRailRed
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("FROM", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                            Text(booking.journey.origin.displayName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BritishRailBlack)
                        }
                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                            Text("TO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                            Text(booking.journey.destination.displayName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BritishRailBlack)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("DATE & DEPARTURE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                            Text("${booking.travelDate} • ${booking.journey.departureTime}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BritishRailBlack)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("PRICE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                            Text(booking.formattedPrice, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BritishRailBlack)
                        }
                    }

                    Text(
                        text = "${booking.passengers.summary(language)} • ${booking.seatReservation}",
                        fontSize = 12.sp,
                        color = BritishRailBlack
                    )
                    Text(
                        text = "Ref: ${booking.bookingReference} • Collection Code: ${booking.collectionCode}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BritishRailRed
                    )

                    if (booking.ticketStatus == TicketStatus.PENDING) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BritishRailWhite)
                                .border(1.dp, RailAmber)
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Issuance pending — tap below to complete barcode generation.", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RailAmber)
                            BrButton("Complete ticket issuance", onRetryIssuance, modifier = Modifier.fillMaxWidth())
                        }
                    } else if (booking.qrPayload.isNotBlank()) {
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            QrCodeView(dataPayload = booking.qrPayload, qrBoxSize = 168.dp)
                        }
                    }

                    Text(
                        text = "Offline cache synced: $syncTime • Restrictions: ${booking.selectedFare.restrictions}",
                        fontSize = 11.sp,
                        color = RailGreySubtext
                    )
                }
            }

            // Actions
            BrSectionRule("Ticket Actions")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BrButton("Follow live", onFollowLive, modifier = Modifier.weight(1f), testTag = "ticket_follow_live")
                BrButton("View receipt", onOpenReceipt, style = BrButtonStyle.SECONDARY_BLACK, modifier = Modifier.weight(1f), testTag = "ticket_view_receipt")
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(1.dp, BritishRailBlack)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Wallet, contentDescription = null, tint = BritishRailBlack, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Platform Wallet Export", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BritishRailBlack)
                }
                Text(uiState.platformWalletStatus, fontSize = 11.sp, color = RailGreySubtext)
                BrButton(
                    text = if (uiState.platformWalletSupported) "Add to Google Wallet" else "Google Wallet (Requires Pass Backend)",
                    onClick = onPlatformWalletClick,
                    style = BrButtonStyle.OUTLINED,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "platform_wallet_button"
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(1.dp, BritishRailBlack)
                    .clickable { onAfterSalesClick() }
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Receipt, contentDescription = null, tint = BritishRailRed, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Need a refund, ticket change, or Delay Repay?", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
                }
                Text("Open →", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BritishRailRed)
            }
        }
    }
}

@Composable
private fun WalletFilterTab(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .heightIn(min = 40.dp)
            .border(1.dp, if (selected) BritishRailRed else BritishRailBlack)
            .background(if (selected) BritishRailRed else BritishRailWhite)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) BritishRailWhite else BritishRailBlack
        )
    }
}
