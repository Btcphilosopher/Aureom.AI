package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.DepartureItem
import com.example.data.model.ServiceStatus
import com.example.data.model.TicketStatus
import com.example.ui.YourJourneyUiState
import com.example.ui.YourJourneyViewModel
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrSchematicLine
import com.example.ui.components.BrSectionRule
import com.example.ui.components.BrServiceStatusBadge
import com.example.ui.components.StationSearchDialog
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailAmber
import com.example.ui.theme.RailGreyBackground
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DeparturesScreen(
    uiState: YourJourneyUiState,
    viewModel: YourJourneyViewModel
) {
    val language = uiState.preferences.language
    var showStationPicker by remember { mutableStateOf(false) }

    val followedBooking = remember(uiState.tickets, uiState.followedBookingRef) {
        uiState.tickets.find { it.bookingReference == uiState.followedBookingRef }
            ?: uiState.tickets.firstOrNull { it.ticketStatus == TicketStatus.AVAILABLE }
    }
    val isFavStation = uiState.favouriteStations.contains(uiState.boardStation.crsCode)

    val lastRefreshStr = remember(uiState.departuresLastUpdatedMs) {
        if (uiState.departuresLastUpdatedMs == 0L) "Not synced yet"
        else SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(uiState.departuresLastUpdatedMs))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RailGreyBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Follow-a-journey Live Mode Card
            if (followedBooking != null) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    BrSectionRule("Live Journey Mode")
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRailWhite)
                            .border(2.dp, BritishRailRed)
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "FOLLOWING ${followedBooking.bookingReference}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = BritishRailRed
                            )
                            BrServiceStatusBadge(followedBooking.journey.status, language)
                        }

                        BrSchematicLine(
                            originName = followedBooking.journey.origin.name,
                            destinationName = followedBooking.journey.destination.name
                        )

                        val firstLeg = followedBooking.journey.legs.firstOrNull()
                        val nextStop = firstLeg?.callingPoints?.firstOrNull() ?: followedBooking.journey.destination.name
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("NEXT STOP / INTERCHANGE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                                Text(nextStop, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BritishRailBlack)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("PLATFORM", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                                Text(firstLeg?.platform ?: "TBC", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BritishRailRed)
                            }
                        }

                        Text(
                            text = "Note: Train progress is timetable-estimated in demo mode without continuous background GPS tracking.",
                            fontSize = 11.sp,
                            color = RailGreySubtext
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = BritishRailBlack, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Delay & platform alerts", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                            Switch(
                                checked = uiState.preferences.delayAlertsEnabled,
                                onCheckedChange = {
                                    viewModel.setNotificationPrefs(it, uiState.preferences.platformAlertsEnabled)
                                }
                            )
                        }

                        BrButton(
                            text = "Open ticket QR",
                            onClick = { viewModel.openTicketDetail(followedBooking) },
                            style = BrButtonStyle.SECONDARY_BLACK,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            } else {
                item { Spacer(modifier = Modifier.height(10.dp)) }
            }

            // Station Departure Board Header
            item {
                BrSectionRule("Station Departure Board")
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BritishRailWhite)
                        .border(2.dp, BritishRailBlack)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showStationPicker = true }
                                .testTag("departures_station_selector")
                        ) {
                            Text("SELECTED STATION (TAP TO CHANGE)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                            Text(
                                text = uiState.boardStation.displayName,
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = BritishRailBlack
                            )
                        }
                        IconButton(
                            onClick = { viewModel.toggleFavouriteStation(uiState.boardStation.crsCode) },
                            modifier = Modifier.testTag("departures_fav_station_toggle")
                        ) {
                            Icon(
                                imageVector = if (isFavStation) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "Favourite station",
                                tint = if (isFavStation) BritishRailRed else BritishRailBlack
                            )
                        }
                        IconButton(
                            onClick = { viewModel.refreshDeparturesAndSync() },
                            modifier = Modifier.testTag("departures_refresh_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh departure board", tint = BritishRailBlack)
                        }
                    }

                    // Favourite stations quick chips
                    if (uiState.favouriteStations.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            uiState.favouriteStations.forEach { crs ->
                                val st = uiState.allStations.find { it.crsCode == crs }
                                val isCurrent = crs == uiState.boardStation.crsCode
                                Box(
                                    modifier = Modifier
                                        .border(1.dp, if (isCurrent) BritishRailRed else BritishRailBlack)
                                        .background(if (isCurrent) BritishRailRedLight else RailGreyPanel)
                                        .clickable { if (st != null) viewModel.loadDepartures(st) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = st?.displayName ?: crs,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCurrent) BritishRailRed else BritishRailBlack
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        text = if (uiState.isOfflineSimulated) {
                            "STALE / OFFLINE NOTICE: Showing cached simulated departures from $lastRefreshStr"
                        } else {
                            "Simulated live feed • Last refreshed $lastRefreshStr"
                        },
                        fontSize = 11.sp,
                        fontWeight = if (uiState.isOfflineSimulated) FontWeight.Bold else FontWeight.Normal,
                        color = if (uiState.isOfflineSimulated) RailAmber else RailGreySubtext
                    )
                }
            }

            items(uiState.departures, key = { it.id }) { dep ->
                DepartureRowCard(dep = dep, language = language)
            }

            item { Spacer(modifier = Modifier.height(14.dp)) }
        }
    }

    if (showStationPicker) {
        StationSearchDialog(
            title = "Select Departure Station",
            stations = uiState.allStations,
            recentStations = uiState.allStations.filter { it.isPopular },
            onStationSelected = { viewModel.loadDepartures(it) },
            onDismiss = { showStationPicker = false }
        )
    }
}

@Composable
private fun DepartureRowCard(
    dep: DepartureItem,
    language: AppLanguage
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .border(1.5.dp, BritishRailBlack)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = dep.scheduledTime,
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = BritishRailBlack
                )
                if (dep.expectedTime != null && dep.expectedTime != dep.scheduledTime) {
                    Text(
                        text = "Exp ${dep.expectedTime}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = RailAmber
                    )
                }
            }
            BrServiceStatusBadge(dep.status, language)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${dep.destination} [${dep.destinationCrs}]",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = BritishRailBlack
                )
                Text(
                    text = dep.operator,
                    fontSize = 11.sp,
                    color = RailGreySubtext
                )
            }
            Box(
                modifier = Modifier
                    .border(1.5.dp, BritishRailBlack)
                    .background(RailGreyPanel)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (dep.status == ServiceStatus.CANCELLED) "PLAT —" else "PLAT ${dep.platform ?: "TBC"}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = BritishRailBlack
                )
            }
        }

        if (dep.callingPoints.isNotEmpty()) {
            Text(
                text = "Calling at: ${dep.callingPoints.joinToString(" • ")}",
                fontSize = 11.sp,
                color = RailGreySubtext
            )
        }
    }
}
