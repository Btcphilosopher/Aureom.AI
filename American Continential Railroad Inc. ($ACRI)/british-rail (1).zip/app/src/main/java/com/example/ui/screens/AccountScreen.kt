package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AfterSalesType
import com.example.data.model.AppLanguage
import com.example.data.model.Booking
import com.example.ui.YourJourneyUiState
import com.example.ui.YourJourneyViewModel
import com.example.ui.components.AccessibilityInfoDialog
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrSectionRule
import com.example.ui.components.LostBookingDialog
import com.example.ui.components.PassengerConfigDialog
import com.example.ui.components.ReceiptDialog
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailAmber
import com.example.ui.theme.RailGreen
import com.example.ui.theme.RailGreyBackground
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

@Composable
fun AccountScreen(
    uiState: YourJourneyUiState,
    viewModel: YourJourneyViewModel
) {
    val language = uiState.preferences.language
    var showPassengerDefaults by remember { mutableStateOf(false) }
    var showAccessibilityDirectory by remember { mutableStateOf(false) }
    var showLostBookingDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var receiptBooking by remember { mutableStateOf<Booking?>(null) }

    var assistStation by remember { mutableStateOf(uiState.originStation.name) }
    var assistNote by remember { mutableStateOf("Ramp boarding & level transfer") }

    var afterSalesRef by remember { mutableStateOf(uiState.tickets.firstOrNull()?.bookingReference ?: "") }
    var afterSalesType by remember { mutableStateOf(AfterSalesType.REFUND_REQUEST) }
    var afterSalesReason by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RailGreyBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (language == AppLanguage.CYMRAEG) "Cyfrif, Cymorth a Hygyrchedd" else "Account, Support & Accessibility",
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = BritishRailBlack
            )

            // 1. Account Status (Guest vs Signed-in)
            BrSectionRule("Traveller Profile")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(2.dp, BritishRailBlack)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = uiState.preferences.passengerName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = if (uiState.preferences.isSignedIn) {
                                "${uiState.preferences.passengerEmail} • Signed-in Rail Account"
                            } else {
                                "Guest Mode — planning & ticket wallet stored locally on this device"
                            },
                            fontSize = 12.sp,
                            color = RailGreySubtext
                        )
                    }
                    Box(
                        modifier = Modifier
                            .border(1.dp, if (uiState.preferences.isSignedIn) RailGreen else BritishRailBlack)
                            .background(if (uiState.preferences.isSignedIn) BritishRailWhite else RailGreyPanel)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (uiState.preferences.isSignedIn) "SIGNED IN" else "GUEST",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BritishRailBlack
                        )
                    }
                }
                BrButton(
                    text = if (uiState.preferences.isSignedIn) "Switch to Guest mode" else "Sign in to Rail Account (Demo)",
                    onClick = { viewModel.toggleSignIn(!uiState.preferences.isSignedIn) },
                    style = if (uiState.preferences.isSignedIn) BrButtonStyle.OUTLINED else BrButtonStyle.SECONDARY_BLACK,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "account_signin_toggle"
                )
            }

            // 2. Accessibility, Text Scale, Reduced Motion & Language
            BrSectionRule("Accessibility & Language")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(1.5.dp, BritishRailBlack)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Language / Iaith", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BritishRailBlack)
                        Text(
                            text = if (language == AppLanguage.CYMRAEG) {
                                "Cymraeg active for core labels; specialist rail tariff terms appear in English."
                            } else "English (switch to Cymraeg)",
                            fontSize = 11.sp,
                            color = RailGreySubtext
                        )
                    }
                    BrButton(
                        text = if (language == AppLanguage.CYMRAEG) "English" else "Cymraeg",
                        onClick = {
                            val next = if (language == AppLanguage.ENGLISH) AppLanguage.CYMRAEG else AppLanguage.ENGLISH
                            viewModel.setLanguage(next)
                        },
                        style = BrButtonStyle.OUTLINED,
                        testTag = "account_language_toggle"
                    )
                }

                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(RailGreyBorder))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Text size", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BritishRailBlack)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0 to "A-", 1 to "A", 2 to "A+").forEach { (lvl, lbl) ->
                            val selected = uiState.preferences.textSizeLevel == lvl
                            Box(
                                modifier = Modifier
                                    .heightIn(min = 44.dp)
                                    .border(1.5.dp, if (selected) BritishRailRed else BritishRailBlack)
                                    .background(if (selected) BritishRailRed else BritishRailWhite)
                                    .clickable { viewModel.setTextSizeLevel(lvl) }
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                                    .testTag("account_text_size_$lvl"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(lbl, fontWeight = FontWeight.Bold, color = if (selected) BritishRailWhite else BritishRailBlack)
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Reduced motion", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Minimise animated transitions", fontSize = 11.sp, color = RailGreySubtext)
                    }
                    Switch(
                        checked = uiState.preferences.reducedMotion,
                        onCheckedChange = { viewModel.setReducedMotion(it) },
                        modifier = Modifier.testTag("account_reduced_motion_switch")
                    )
                }

                BrButton(
                    text = "Station accessibility directory",
                    onClick = { showAccessibilityDirectory = true },
                    style = BrButtonStyle.OUTLINED,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "account_accessibility_directory_btn"
                )
            }

            // 3. Passenger Assistance Service
            BrSectionRule("Passenger Assistance")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(1.5.dp, BritishRailBlack)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Step-free route filtering only checks station infrastructure. Request staff boarding assistance below:",
                    fontSize = 12.sp,
                    color = RailGreySubtext
                )
                OutlinedTextField(
                    value = assistStation,
                    onValueChange = { assistStation = it },
                    label = { Text("Station name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = assistNote,
                    onValueChange = { assistNote = it },
                    label = { Text("Assistance requirement") },
                    modifier = Modifier.fillMaxWidth()
                )
                BrButton(
                    text = "Request Passenger Assist",
                    onClick = {
                        viewModel.requestPassengerAssistance(
                            bookingRef = uiState.tickets.firstOrNull()?.bookingReference,
                            stationName = assistStation,
                            requirement = assistNote
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "request_assistance_btn"
                )
                uiState.assistanceRequests.forEach { req ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RailGreyPanel)
                            .border(1.dp, BritishRailBlack)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${req.id} • ${req.stationName}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(req.state.localized(language), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BritishRailRed)
                        }
                        Text(req.requirement, fontSize = 11.sp, color = RailGreySubtext)
                        BrButton(
                            text = "Refresh operator status",
                            onClick = { viewModel.advanceAssistanceStatus(req.id) },
                            style = BrButtonStyle.OUTLINED,
                            height = 44.dp
                        )
                    }
                }
            }

            // 4. After-Sales: Refunds, Changes, Delay Repay & Recovery
            BrSectionRule("After-Sales & Support")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(1.5.dp, BritishRailBlack)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Refunds, ticket changes, and Delay Repay depend on ticket conditions and verified journey details. No automatic refund is promised prior to operator review.",
                    fontSize = 11.sp,
                    color = RailGreySubtext
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AfterSalesType.entries.forEach { t ->
                        val sel = afterSalesType == t
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 44.dp)
                                .border(1.dp, if (sel) BritishRailRed else BritishRailBlack)
                                .background(if (sel) BritishRailRedLight else BritishRailWhite)
                                .clickable { afterSalesType = t }
                                .padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (t) {
                                    AfterSalesType.REFUND_REQUEST -> "Refund"
                                    AfterSalesType.TICKET_CHANGE -> "Change"
                                    AfterSalesType.DISRUPTION_CLAIM -> "Delay Repay"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (sel) BritishRailRed else BritishRailBlack
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = afterSalesRef,
                    onValueChange = { afterSalesRef = it },
                    label = { Text("Booking Reference") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = afterSalesReason,
                    onValueChange = { afterSalesReason = it },
                    label = { Text("Reason / Delay details") },
                    modifier = Modifier.fillMaxWidth()
                )
                BrButton(
                    text = "Submit request for review",
                    onClick = {
                        viewModel.submitAfterSalesCase(afterSalesRef, afterSalesType, afterSalesReason)
                        afterSalesReason = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "after_sales_submit_btn"
                )

                uiState.afterSalesCases.forEach { caseItem ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, RailGreyBorder)
                            .padding(8.dp)
                    ) {
                        Text("${caseItem.id} • ${caseItem.type.label} (${caseItem.bookingReference})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(caseItem.status.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RailAmber)
                        Text(caseItem.note, fontSize = 11.sp, color = RailGreySubtext)
                    }
                }

                BrButton(
                    text = "Recover lost booking",
                    onClick = { showLostBookingDialog = true },
                    style = BrButtonStyle.OUTLINED,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 5. Preferences, Notifications, Receipts & Local Data Controls
            BrSectionRule("Preferences, Receipts & Privacy")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BritishRailWhite)
                    .border(1.5.dp, BritishRailBlack)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Default Railcard & Passengers", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(uiState.preferences.preferredRailcard.getLocalizedName(language), fontSize = 12.sp, color = RailGreySubtext)
                    }
                    BrButton("Edit", { showPassengerDefaults = true }, style = BrButtonStyle.OUTLINED)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Platform change alerts", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Switch(
                        checked = uiState.preferences.platformAlertsEnabled,
                        onCheckedChange = { viewModel.setNotificationPrefs(uiState.preferences.delayAlertsEnabled, it) }
                    )
                }

                if (uiState.tickets.isNotEmpty()) {
                    Text("RECENT BOOKING RECEIPTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RailGreySubtext)
                    uiState.tickets.take(3).forEach { b ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, RailGreyBorder)
                                .clickable { receiptBooking = b }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${b.bookingReference} (${b.journey.origin.crsCode}→${b.journey.destination.crsCode})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("${b.formattedPrice} • Receipt", fontSize = 12.sp, color = BritishRailRed, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Text(
                    text = uiState.apiNotice,
                    fontSize = 11.sp,
                    color = RailGreySubtext
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BrButton(
                        text = "Export local data",
                        onClick = { viewModel.generateLocalExportSummary() },
                        style = BrButtonStyle.SECONDARY_BLACK,
                        modifier = Modifier.weight(1f),
                        testTag = "export_local_data_btn"
                    )
                    BrButton(
                        text = "Delete all data",
                        onClick = { showDeleteConfirm = true },
                        style = BrButtonStyle.OUTLINED,
                        modifier = Modifier.weight(1f),
                        testTag = "delete_local_data_btn"
                    )
                }
            }

            uiState.exportSummaryText?.let { summary ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BritishRailWhite)
                        .border(2.dp, BritishRailBlack)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Local Data Export Summary", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(summary, fontSize = 11.sp, color = BritishRailBlack)
                    BrButton("Close export", { viewModel.dismissExportSummary() }, style = BrButtonStyle.OUTLINED, modifier = Modifier.fillMaxWidth())
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }
    }

    if (showPassengerDefaults) {
        PassengerConfigDialog(
            initialConfig = uiState.passengers,
            language = language,
            onConfirmed = { viewModel.setPassengers(it) },
            onDismiss = { showPassengerDefaults = false }
        )
    }

    if (showAccessibilityDirectory) {
        AccessibilityInfoDialog(
            infoList = uiState.stationAccessibility,
            onDismiss = { showAccessibilityDirectory = false }
        )
    }

    if (showLostBookingDialog) {
        LostBookingDialog(
            recoveryMessage = uiState.recoveryMessage,
            onRecover = { ref, code -> viewModel.recoverLostBooking(ref, code) },
            onDismiss = { showLostBookingDialog = false }
        )
    }

    receiptBooking?.let { b ->
        ReceiptDialog(booking = b, onDismiss = { receiptBooking = null })
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete all local data?", fontWeight = FontWeight.Bold) },
            text = { Text("This clears all cached demonstration tickets, favourite routes, favourite stations, recent searches, and preferences from this device.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAllLocalData()
                        showDeleteConfirm = false
                    },
                    modifier = Modifier.testTag("confirm_delete_all_data")
                ) {
                    Text("Delete all", color = BritishRailRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = BritishRailBlack)
                }
            }
        )
    }
}
