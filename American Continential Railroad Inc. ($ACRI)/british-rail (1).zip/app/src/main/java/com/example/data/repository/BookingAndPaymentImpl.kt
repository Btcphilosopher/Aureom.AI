package com.example.data.repository

import com.example.data.model.AssistanceRequest
import com.example.data.model.AssistanceState
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.PaymentRequest
import com.example.data.model.PaymentResult
import com.example.data.model.ServiceFare
import com.example.data.model.SimulatedPaymentOutcome
import com.example.data.model.TicketIssuanceResult
import com.example.data.model.TicketStatus
import com.example.domain.BookingService
import com.example.domain.PassengerAssistanceService
import com.example.domain.PaymentProvider
import com.example.domain.PlatformWalletAdapter
import com.example.domain.RailApiClient
import com.example.domain.TicketIssuer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class BookingServiceImpl : BookingService {
    private val bookingsByRef = ConcurrentHashMap<String, Booking>()
    private val bookingsByIdempotency = ConcurrentHashMap<String, Booking>()

    override suspend fun createPendingBooking(
        journey: JourneyOption,
        fare: ServiceFare,
        passengers: PassengerConfig,
        travelDate: String,
        returnDate: String?,
        isReturn: Boolean,
        totalPence: Int,
        idempotencyKey: String,
        isGuestPurchase: Boolean
    ): Booking {
        bookingsByIdempotency[idempotencyKey]?.let { existing ->
            return existing
        }

        val randomSuffix = UUID.randomUUID().toString().take(6).uppercase()
        val ref = "BR-$randomSuffix"
        val collectionCode = "8X${randomSuffix.take(4)}"
        val booking = Booking(
            bookingReference = ref,
            collectionCode = collectionCode,
            journey = journey,
            selectedFare = fare,
            passengers = passengers,
            travelDate = travelDate,
            returnDate = returnDate,
            isReturn = isReturn,
            totalPence = totalPence,
            paymentAuthCode = "",
            idempotencyKey = idempotencyKey,
            bookingStatus = BookingStatus.PENDING_PAYMENT,
            ticketStatus = TicketStatus.PENDING,
            seatReservation = if (fare.reservationIncluded) "Coach C, Seat 42 (Window, Forward)" else "Unreserved seating",
            qrPayload = "",
            isGuestPurchase = isGuestPurchase,
            assistanceState = AssistanceState.NONE
        )
        bookingsByRef[ref] = booking
        bookingsByIdempotency[idempotencyKey] = booking
        return booking
    }

    override suspend fun markPaymentConfirmedAwaitingIssuance(
        bookingReference: String,
        paymentAuthCode: String
    ): Booking {
        val current = bookingsByRef[bookingReference]
            ?: error("Booking $bookingReference not found")
        val updated = current.copy(
            paymentAuthCode = paymentAuthCode,
            bookingStatus = BookingStatus.PAYMENT_CONFIRMED_AWAITING_ISSUANCE,
            ticketStatus = TicketStatus.PENDING,
            lastSyncedEpochMs = System.currentTimeMillis()
        )
        bookingsByRef[bookingReference] = updated
        if (updated.idempotencyKey.isNotEmpty()) {
            bookingsByIdempotency[updated.idempotencyKey] = updated
        }
        return updated
    }

    override suspend fun finalizeIssuedBooking(
        bookingReference: String,
        qrPayload: String
    ): Booking {
        val current = bookingsByRef[bookingReference]
            ?: error("Booking $bookingReference not found")
        val updated = current.copy(
            bookingStatus = BookingStatus.CONFIRMED,
            ticketStatus = TicketStatus.AVAILABLE,
            qrPayload = qrPayload,
            lastSyncedEpochMs = System.currentTimeMillis()
        )
        bookingsByRef[bookingReference] = updated
        if (updated.idempotencyKey.isNotEmpty()) {
            bookingsByIdempotency[updated.idempotencyKey] = updated
        }
        return updated
    }

    override suspend fun getBooking(bookingReference: String): Booking? {
        return bookingsByRef[bookingReference]
    }

    override suspend fun findBookingForRecovery(
        reference: String,
        verificationCode: String
    ): Result<Booking> {
        val cleanRef = reference.trim().uppercase()
        val cleanCode = verificationCode.trim().uppercase()
        if (cleanRef.isBlank() || cleanCode.length < 4) {
            return Result.failure(IllegalArgumentException("Enter both a valid booking reference and collection/verification code."))
        }
        val found = bookingsByRef[cleanRef]
        if (found != null && found.collectionCode.equals(cleanCode, ignoreCase = true)) {
            return Result.success(found)
        }
        return Result.failure(
            NoSuchElementException("No local booking found matching $cleanRef. Remote booking lookup requires an authenticated retail backend.")
        )
    }
}

class PaymentProviderImpl : PaymentProvider {
    override val providerName: String = "Simulated Card Acquirer (Demo)"
    override val requiresConfiguredBackend: Boolean = true

    private val completedTransactions = ConcurrentHashMap<String, PaymentResult.Success>()
    private val uncertainKeys = ConcurrentHashMap<String, String>()

    override suspend fun processPayment(request: PaymentRequest): PaymentResult {
        completedTransactions[request.idempotencyKey]?.let { prior ->
            return prior.copy(reconciled = true)
        }

        return when (request.simulatedOutcome) {
            SimulatedPaymentOutcome.SUCCESS -> {
                val tx = PaymentResult.Success(
                    authCode = "AUTH-${request.idempotencyKey.take(6).uppercase()}",
                    transactionId = "TX-${UUID.randomUUID().toString().take(8).uppercase()}",
                    reconciled = false
                )
                completedTransactions[request.idempotencyKey] = tx
                tx
            }
            SimulatedPaymentOutcome.DECLINED -> {
                PaymentResult.Declined("Card issuer declined transaction (simulated). Check funds or try another method.")
            }
            SimulatedPaymentOutcome.TIMEOUT -> {
                PaymentResult.Timeout
            }
            SimulatedPaymentOutcome.CANCELLED -> {
                PaymentResult.Cancelled
            }
            SimulatedPaymentOutcome.UNCERTAIN_RECONCILE -> {
                uncertainKeys[request.idempotencyKey] = request.bookingReference
                PaymentResult.Uncertain(
                    "Connection dropped after payment submission. Payment status is uncertain—reconcile before retrying to prevent duplicate charges."
                )
            }
        }
    }

    override suspend fun reconcilePayment(
        idempotencyKey: String,
        bookingReference: String
    ): PaymentResult {
        completedTransactions[idempotencyKey]?.let { prior ->
            return prior.copy(reconciled = true)
        }
        if (uncertainKeys.containsKey(idempotencyKey)) {
            uncertainKeys.remove(idempotencyKey)
            val reconciled = PaymentResult.Success(
                authCode = "REC-${idempotencyKey.take(6).uppercase()}",
                transactionId = "TXR-${UUID.randomUUID().toString().take(8).uppercase()}",
                reconciled = true
            )
            completedTransactions[idempotencyKey] = reconciled
            return reconciled
        }
        return PaymentResult.Declined("No authorised transaction found for key $idempotencyKey. Safe to initiate a fresh payment.")
    }
}

class TicketIssuerImpl : TicketIssuer {
    override suspend fun issueTicket(
        booking: Booking,
        forcePendingForDemo: Boolean
    ): TicketIssuanceResult {
        if (forcePendingForDemo) {
            return TicketIssuanceResult.Pending(
                "Payment authorised (${booking.paymentAuthCode}), awaiting rail barcode fulfillment from fulfillment queue."
            )
        }
        val payload = "BR-DEMO|NOT_VALID_FOR_TRAVEL|REF=${booking.bookingReference}|" +
            "FROM=${booking.journey.origin.crsCode}|TO=${booking.journey.destination.crsCode}|" +
            "DATE=${booking.travelDate}|DEP=${booking.journey.departureTime}|" +
            "FARE=${booking.selectedFare.ticketType.name}|AUTH=${booking.paymentAuthCode}"
        return TicketIssuanceResult.Issued(
            ticketPayload = payload,
            qrData = payload,
            issuedAtEpochMs = System.currentTimeMillis()
        )
    }
}

class PassengerAssistanceServiceImpl : PassengerAssistanceService {
    private val requests = ConcurrentHashMap<String, AssistanceRequest>()

    override suspend fun requestAssistance(
        bookingReference: String?,
        stationName: String,
        requirement: String
    ): AssistanceRequest {
        val id = "AST-${UUID.randomUUID().toString().take(6).uppercase()}"
        val request = AssistanceRequest(
            id = id,
            bookingReference = bookingReference,
            stationName = stationName,
            requirement = requirement,
            state = AssistanceState.REQUESTED,
            updatedAtEpochMs = System.currentTimeMillis()
        )
        requests[id] = request
        return request
    }

    override suspend fun refreshAssistanceStatus(requestId: String): AssistanceRequest? {
        val current = requests[requestId] ?: return null
        val nextState = when (current.state) {
            AssistanceState.NONE -> AssistanceState.REQUESTED
            AssistanceState.REQUESTED -> AssistanceState.PENDING
            AssistanceState.PENDING -> AssistanceState.CONFIRMED
            AssistanceState.CONFIRMED -> AssistanceState.CONFIRMED
        }
        val updated = current.copy(
            state = nextState,
            updatedAtEpochMs = System.currentTimeMillis()
        )
        requests[requestId] = updated
        return updated
    }

    override fun getActiveRequests(): List<AssistanceRequest> {
        return requests.values.sortedByDescending { it.updatedAtEpochMs }
    }
}

class PlatformWalletAdapterImpl : PlatformWalletAdapter {
    override val isSupportedAndConfigured: Boolean = false
    override val statusDescription: String =
        "Platform Wallet (Google Wallet) pass signing is not yet configured in this offline build. Use the British Rail in-app QR ticket for offline inspection."

    override suspend fun addTicketToPlatformWallet(booking: Booking): Result<Unit> {
        return Result.failure(UnsupportedOperationException(statusDescription))
    }
}

class MockRailApiClient : RailApiClient {
    override val isOfflineDemoMode: Boolean = true
    override val endpointNotice: String =
        "Bundled illustrative rail timetable & fare catalogue active. Configure Rail Data / RDG retail endpoints via RailApiClient before production use."
}
