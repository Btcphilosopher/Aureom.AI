package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.TravelSyncWorker
import com.example.data.model.TicketStatus
import com.example.ui.AppTab
import com.example.ui.CheckoutStage
import com.example.ui.YourJourneyViewModel
import com.example.ui.YourJourneyViewModelFactory
import com.example.ui.components.BrBottomNavigationBar
import com.example.ui.components.BrMobileHeader
import com.example.ui.components.BrNavigationRail
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.DeparturesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlanScreen
import com.example.ui.screens.TicketsScreen
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailTheme
import com.example.ui.theme.BritishRailWhite

class MainActivity : ComponentActivity() {
    private val viewModel: YourJourneyViewModel by viewModels {
        YourJourneyViewModelFactory(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        TravelSyncWorker.schedulePeriodicRefresh(applicationContext)

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            val baseDensity = LocalDensity.current
            val fontScaleMultiplier = when (state.preferences.textSizeLevel) {
                1 -> 1.15f
                2 -> 1.30f
                else -> 1.0f
            }
            val customDensity = remember(baseDensity, fontScaleMultiplier) {
                Density(
                    density = baseDensity.density,
                    fontScale = baseDensity.fontScale * fontScaleMultiplier
                )
            }

            CompositionLocalProvider(LocalDensity provides customDensity) {
                BritishRailTheme {
                    BritishRailYourJourneyApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun BritishRailYourJourneyApp(
    viewModel: YourJourneyViewModel
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val availableTickets = remember(state.tickets) {
        state.tickets.count { it.ticketStatus == TicketStatus.AVAILABLE }
    }

    BackHandler(
        enabled = state.checkoutStage != CheckoutStage.NONE ||
            (state.activeTab == AppTab.TICKETS && state.selectedWalletTicket != null) ||
            state.activeTab != AppTab.HOME
    ) {
        when {
            state.checkoutStage != CheckoutStage.NONE -> viewModel.exitCheckout()
            state.activeTab == AppTab.TICKETS && state.selectedWalletTicket != null -> viewModel.closeTicketDetail()
            state.activeTab != AppTab.HOME -> viewModel.selectTab(AppTab.HOME)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp && state.checkoutStage == CheckoutStage.NONE

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                BrMobileHeader(
                    isSignedIn = state.preferences.isSignedIn,
                    passengerName = state.preferences.passengerName,
                    isOfflineSimulated = state.isOfflineSimulated,
                    language = state.preferences.language,
                    onProfileClick = {
                        viewModel.exitCheckout()
                        viewModel.selectTab(AppTab.ACCOUNT)
                    },
                    onBrandClick = {
                        viewModel.exitCheckout()
                        viewModel.selectTab(AppTab.HOME)
                    }
                )
            },
            bottomBar = {
                if (!useNavigationRail && state.checkoutStage == CheckoutStage.NONE) {
                    BrBottomNavigationBar(
                        activeTab = state.activeTab,
                        availableTicketCount = availableTickets,
                        language = state.preferences.language,
                        onSelectTab = { viewModel.selectTab(it) }
                    )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BritishRailWhite)
            ) {
                state.bannerMessage?.let { msg ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRailRedLight)
                            .border(1.dp, BritishRailRed)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = msg,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BritishRailBlack,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "DISMISS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BritishRailRed,
                            modifier = Modifier
                                .clickable { viewModel.dismissBanner() }
                                .padding(start = 10.dp)
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxSize()) {
                    if (useNavigationRail) {
                        BrNavigationRail(
                            activeTab = state.activeTab,
                            availableTicketCount = availableTickets,
                            language = state.preferences.language,
                            onSelectTab = { viewModel.selectTab(it) }
                        )
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                        if (state.checkoutStage != CheckoutStage.NONE) {
                            CheckoutScreen(uiState = state, viewModel = viewModel)
                        } else {
                            when (state.activeTab) {
                                AppTab.HOME -> HomeScreen(uiState = state, viewModel = viewModel)
                                AppTab.PLAN -> PlanScreen(uiState = state, viewModel = viewModel)
                                AppTab.TICKETS -> TicketsScreen(uiState = state, viewModel = viewModel)
                                AppTab.DEPARTURES -> DeparturesScreen(uiState = state, viewModel = viewModel)
                                AppTab.ACCOUNT -> AccountScreen(uiState = state, viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
