package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.JourneyOption
import com.example.data.model.ServiceFare
import com.example.data.model.TravelClass
import com.example.ui.YourJourneyUiState
import com.example.ui.YourJourneyViewModel
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrSchematicLine
import com.example.ui.components.BrServiceStatusBadge
import com.example.ui.components.PassengerConfigDialog
import com.example.ui.components.StationSearchDialog
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailRedLight
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailAmber
import com.example.ui.theme.RailGreen
import com.example.ui.theme.RailGreyBackground
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

@Composable
fun PlanScreen(
    uiState: YourJourneyUiState,
    viewModel: YourJourneyViewModel
) {
    val language = uiState.preferences.language
    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }
    var showPassengerDialog by remember { mutableStateOf(false) }

    val isFavRoute = remember(uiState.favouriteRoutes, uiState.originStation, uiState.destinationStation) {
        val id = "${uiState.originStation.crsCode}-${uiState.destinationStation.crsCode}"
        uiState.favouriteRoutes.any { it.id == id }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RailGreyBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                // Route header & editable summary
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BritishRailWhite)
                        .border(2.dp, BritishRailBlack)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${uiState.originStation.name} → ${uiState.destinationStation.name}",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = BritishRailBlack
                            )
                            Text(
                                text = "${uiState.travelDate} • ${if (uiState.arriveBy) "Arrive by" else "Depart after"} ${uiState.departTime} • ${if (uiState.isReturn) "Return" else "Single"}",
                                fontSize = 12.sp,
                                color = RailGreySubtext
                            )
                        }
                        IconButton(
                            onClick = { viewModel.toggleFavouriteCurrentRoute() },
                            modifier = Modifier.testTag("plan_favourite_route_btn")
                        ) {
                            Icon(
                                imageVector = if (isFavRoute) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = if (isFavRoute) "Remove route from favourites" else "Save route to favourites",
                                tint = if (isFavRoute) BritishRailRed else BritishRailBlack
                            )
                        }
                    }

                    // Filter & edit bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChipBox("From: ${uiState.originStation.crsCode}", false) { showOriginPicker = true }
                        FilterChipBox("To: ${uiState.destinationStation.crsCode}", false) { showDestPicker = true }
                        FilterChipBox(
                            text = if (uiState.arriveBy) "Arrive by ${uiState.departTime}" else "Depart ${uiState.departTime}",
                            selected = uiState.arriveBy
                        ) {
                            viewModel.setDepartTime(uiState.departTime, !uiState.arriveBy)
                            viewModel.performSearch(navigateToPlan = false, recordHistory = false)
                        }
                        FilterChipBox(
                            text = uiState.preferredClass.getLocalizedName(language),
                            selected = uiState.preferredClass == TravelClass.FIRST
                        ) {
                            val next = if (uiState.preferredClass == TravelClass.STANDARD) TravelClass.FIRST else TravelClass.STANDARD
                            viewModel.setPreferredClass(next)
                        }
                        FilterChipBox(
                            text = if (uiState.stepFreeOnly) "Step-free ON" else "Step-free",
                            selected = uiState.stepFreeOnly
                        ) {
                            viewModel.setStepFreeOnly(!uiState.stepFreeOnly)
                        }
                        FilterChipBox("${uiState.passengers.totalPassengers} pax", false) {
                            showPassengerDialog = true
                        }
                    }

                    // Quick route test presets for demonstration corridors
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "SHF" to "STP",
                            "LDS" to "MAN",
                            "BDI" to "YRK",
                            "NCL" to "EDB",
                            "GLC" to "CBG"
                        ).forEach { (o, d) ->
                            Box(
                                modifier = Modifier
                                    .border(1.dp, RailGreyBorder)
                                    .background(RailGreyPanel)
                                    .clickable { viewModel.applyRoutePreset(o, d) }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                                    .testTag("preset_${o}_${d}")
                            ) {
                                Text("$o→$d", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BritishRailWhite)
                        .border(1.dp, BritishRailBlack)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Gwasanaethau a thocynnau enghreifftiol" else "Illustrative services and fares",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BritishRailBlack
                    )
                    Text(
                        text = "${uiState.journeyResults.size} services",
                        fontSize = 12.sp,
                        color = RailGreySubtext
                    )
                }
            }

            if (uiState.journeyResults.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRailWhite)
                            .border(2.dp, BritishRailBlack)
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "No matching services found",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = if (uiState.stepFreeOnly) {
                                "Step-free filter is enabled. Routes including stations with UNKNOWN accessibility (such as Bradford Interchange [BDI] or Berwick-upon-Tweed [BWK]) are excluded rather than falsely shown as accessible."
                            } else {
                                "No services operate on ${uiState.originStation.crsCode} → ${uiState.destinationStation.crsCode} at ${uiState.departTime} in this demonstration timetable."
                            },
                            fontSize = 13.sp,
                            color = RailGreySubtext
                        )
                        if (uiState.stepFreeOnly) {
                            BrButton(
                                text = "Show all routes (including unknown access)",
                                onClick = { viewModel.setStepFreeOnly(false) },
                                style = BrButtonStyle.SECONDARY_BLACK,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            } else {
                items(uiState.journeyResults, key = { it.id }) { journey ->
                    JourneyResultCard(
                        journey = journey,
                        isExpanded = uiState.expandedJourneyId == journey.id,
                        preferredClass = uiState.preferredClass,
                        language = language,
                        onToggleExpand = { viewModel.toggleJourneyExpanded(journey.id) },
                        onSelectFare = { fare -> viewModel.selectFareAndBeginCheckout(journey, fare) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(14.dp)) }
        }
    }

    if (showOriginPicker) {
        StationSearchDialog(
            title = "Select Origin",
            stations = uiState.allStations,
            recentStations = uiState.allStations.filter { it.isPopular },
            onStationSelected = {
                viewModel.setOrigin(it)
                viewModel.performSearch(navigateToPlan = false, recordHistory = true)
            },
            onDismiss = { showOriginPicker = false }
        )
    }

    if (showDestPicker) {
        StationSearchDialog(
            title = "Select Destination",
            stations = uiState.allStations,
            recentStations = uiState.allStations.filter { it.isPopular },
            onStationSelected = {
                viewModel.setDestination(it)
                viewModel.performSearch(navigateToPlan = false, recordHistory = true)
            },
            onDismiss = { showDestPicker = false }
        )
    }

    if (showPassengerDialog) {
        PassengerConfigDialog(
            initialConfig = uiState.passengers,
            language = language,
            onConfirmed = { viewModel.setPassengers(it) },
            onDismiss = { showPassengerDialog = false }
        )
    }
}

@Composable
private fun JourneyResultCard(
    journey: JourneyOption,
    isExpanded: Boolean,
    preferredClass: TravelClass,
    language: AppLanguage,
    onToggleExpand: () -> Unit,
    onSelectFare: (ServiceFare) -> Unit
) {
    val displayedFares = remember(journey.fares, preferredClass) {
        val preferred = journey.fares.filter { it.travelClass == preferredClass }
        val others = journey.fares.filter { it.travelClass != preferredClass }
        preferred + others
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .border(1.5.dp, BritishRailBlack)
            .padding(14.dp)
            .testTag("journey_card_${journey.id}"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Top times & status row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "${journey.departureTime} → ${journey.arrivalTime}",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = BritishRailBlack
                    )
                    if (journey.isOvernight) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(BritishRailBlack)
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "+${journey.arrivalDayOffset}d",
                                color = BritishRailWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Text(
                    text = "${journey.durationStr} • ${journey.routeSummary} • ${journey.serviceDate}",
                    fontSize = 12.sp,
                    color = RailGreySubtext
                )
            }
            BrServiceStatusBadge(journey.status, language)
        }

        BrSchematicLine(
            originName = journey.origin.name,
            destinationName = journey.destination.name,
            interchangeName = if (journey.changes > 0 && journey.legs.isNotEmpty()) journey.legs.first().destinationStation else null
        )

        if (journey.disruptionSummary != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFF8E1))
                    .border(1.dp, RailAmber)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = RailAmber, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(journey.disruptionSummary, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RailAmber)
            }
        }

        // Accessibility confidence badge (never claiming unknown is accessible)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Accessible,
                contentDescription = null,
                tint = when {
                    !journey.accessibilityConfidenceKnown -> RailAmber
                    journey.isAccessibleRoute -> RailGreen
                    else -> BritishRailRed
                },
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = when {
                    !journey.accessibilityConfidenceKnown -> "Step-free status UNKNOWN at 1+ station — check before travel"
                    journey.isAccessibleRoute -> "Step-free stations verified"
                    else -> "Not step-free throughout"
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = when {
                    !journey.accessibilityConfidenceKnown -> RailAmber
                    journey.isAccessibleRoute -> RailGreen
                    else -> BritishRailRed
                }
            )
        }

        // Expandable vertical itinerary toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 44.dp)
                .border(1.dp, RailGreyBorder)
                .clickable { onToggleExpand() }
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .testTag("expand_itinerary_${journey.id}"),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isExpanded) "Hide vertical itinerary & platforms" else "Show itinerary, platforms & accessibility",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BritishRailBlack
            )
            Icon(
                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = BritishRailBlack
            )
        }

        if (isExpanded) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RailGreyPanel)
                    .border(1.dp, BritishRailBlack)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                journey.legs.forEachIndexed { idx, leg ->
                    if (leg.isWalkingConnection && leg.connectionMinutes != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BritishRailWhite)
                                .border(1.dp, RailGreyBorder)
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = BritishRailRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Interchange at ${leg.originStation}: ${leg.connectionMinutes}m connection",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = BritishRailBlack
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRailWhite)
                            .border(1.dp, BritishRailBlack)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Train, contentDescription = null, tint = BritishRailBlack, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Leg ${idx + 1}: ${leg.operator}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BritishRailBlack)
                            }
                            Text("Plat ${leg.platform ?: "TBC"}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BritishRailRed)
                        }
                        Text(
                            text = "${leg.departureTime} ${leg.originStation} [${leg.originCrs}] → ${leg.arrivalTime} ${leg.destinationStation} [${leg.destinationCrs}] (${leg.durationStr})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BritishRailBlack
                        )
                        if (leg.callingPoints.isNotEmpty()) {
                            Text(
                                text = "Calling at: ${leg.callingPoints.joinToString(", ")}",
                                fontSize = 11.sp,
                                color = RailGreySubtext
                            )
                        }
                        Text(
                            text = "Accessibility: ${leg.accessibilityNote}",
                            fontSize = 11.sp,
                            color = BritishRailBlack
                        )
                        leg.alertMessage?.let { alert ->
                            Text(
                                text = "Alert: $alert",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = RailAmber
                            )
                        }
                    }
                }
            }
        }

        // Available Fares
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            displayedFares.forEach { fare ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (fare.isAvailable) BritishRailBlack else RailGreyBorder)
                        .background(if (fare.isAvailable) BritishRailWhite else RailGreyPanel)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${fare.ticketType.getLocalizedName(language)} • ${fare.travelClass.getLocalizedName(language)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = if (fare.isAvailable) "${fare.quotaRemaining} illustrative tickets at this fare" else "Sold out on this service",
                            fontSize = 11.sp,
                            color = if (fare.isAvailable) RailGreySubtext else BritishRailRed
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    BrButton(
                        text = if (fare.isAvailable) "Buy ${fare.formattedPrice}" else "Sold out",
                        onClick = { onSelectFare(fare) },
                        enabled = fare.isAvailable,
                        style = if (fare.isAvailable) BrButtonStyle.PRIMARY_RED else BrButtonStyle.OUTLINED,
                        height = 48.dp,
                        testTag = "select_fare_${fare.id}"
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterChipBox(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .heightIn(min = 38.dp)
            .border(1.dp, if (selected) BritishRailRed else BritishRailBlack)
            .background(if (selected) BritishRailRedLight else BritishRailWhite)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (selected) "✓ $text" else text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) BritishRailRed else BritishRailBlack
        )
    }
}
