package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppLanguage
import com.example.data.model.RailcardType
import com.example.data.model.TravelClass
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.brDataStore: DataStore<Preferences> by preferencesDataStore(name = "br_your_journey_prefs")

data class UserPreferences(
    val isSignedIn: Boolean = false,
    val passengerName: String = "Guest Traveller",
    val passengerEmail: String = "",
    val preferredRailcard: RailcardType = RailcardType.NONE,
    val preferredClass: TravelClass = TravelClass.STANDARD,
    val stepFreeOnly: Boolean = false,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val textSizeLevel: Int = 0,
    val reducedMotion: Boolean = false,
    val delayAlertsEnabled: Boolean = true,
    val platformAlertsEnabled: Boolean = true,
    val lastSyncEpochMs: Long = 0L
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val IS_SIGNED_IN = booleanPreferencesKey("is_signed_in")
        val PASSENGER_NAME = stringPreferencesKey("passenger_name")
        val PASSENGER_EMAIL = stringPreferencesKey("passenger_email")
        val PREFERRED_RAILCARD = stringPreferencesKey("preferred_railcard")
        val PREFERRED_CLASS = stringPreferencesKey("preferred_class")
        val STEP_FREE_ONLY = booleanPreferencesKey("step_free_only")
        val LANGUAGE = stringPreferencesKey("language")
        val TEXT_SIZE_LEVEL = intPreferencesKey("text_size_level")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val DELAY_ALERTS = booleanPreferencesKey("delay_alerts")
        val PLATFORM_ALERTS = booleanPreferencesKey("platform_alerts")
        val LAST_SYNC_MS = longPreferencesKey("last_sync_ms")
    }

    val preferencesFlow: Flow<UserPreferences> = context.brDataStore.data.map { prefs ->
        UserPreferences(
            isSignedIn = prefs[Keys.IS_SIGNED_IN] ?: false,
            passengerName = prefs[Keys.PASSENGER_NAME] ?: "Guest Traveller",
            passengerEmail = prefs[Keys.PASSENGER_EMAIL] ?: "",
            preferredRailcard = prefs[Keys.PREFERRED_RAILCARD]?.let {
                runCatching { RailcardType.valueOf(it) }.getOrNull()
            } ?: RailcardType.NONE,
            preferredClass = prefs[Keys.PREFERRED_CLASS]?.let {
                runCatching { TravelClass.valueOf(it) }.getOrNull()
            } ?: TravelClass.STANDARD,
            stepFreeOnly = prefs[Keys.STEP_FREE_ONLY] ?: false,
            language = prefs[Keys.LANGUAGE]?.let {
                runCatching { AppLanguage.valueOf(it) }.getOrNull()
            } ?: AppLanguage.ENGLISH,
            textSizeLevel = prefs[Keys.TEXT_SIZE_LEVEL] ?: 0,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            delayAlertsEnabled = prefs[Keys.DELAY_ALERTS] ?: true,
            platformAlertsEnabled = prefs[Keys.PLATFORM_ALERTS] ?: true,
            lastSyncEpochMs = prefs[Keys.LAST_SYNC_MS] ?: 0L
        )
    }

    suspend fun setSignedInAccount(signedIn: Boolean, name: String, email: String) {
        context.brDataStore.edit { prefs ->
            prefs[Keys.IS_SIGNED_IN] = signedIn
            prefs[Keys.PASSENGER_NAME] = name
            prefs[Keys.PASSENGER_EMAIL] = email
        }
    }

    suspend fun setTravelPreferences(
        railcard: RailcardType,
        travelClass: TravelClass,
        stepFreeOnly: Boolean
    ) {
        context.brDataStore.edit { prefs ->
            prefs[Keys.PREFERRED_RAILCARD] = railcard.name
            prefs[Keys.PREFERRED_CLASS] = travelClass.name
            prefs[Keys.STEP_FREE_ONLY] = stepFreeOnly
        }
    }

    suspend fun setAccessibility(
        language: AppLanguage,
        textSizeLevel: Int,
        reducedMotion: Boolean
    ) {
        context.brDataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = language.name
            prefs[Keys.TEXT_SIZE_LEVEL] = textSizeLevel
            prefs[Keys.REDUCED_MOTION] = reducedMotion
        }
    }

    suspend fun setNotificationPreferences(delayAlerts: Boolean, platformAlerts: Boolean) {
        context.brDataStore.edit { prefs ->
            prefs[Keys.DELAY_ALERTS] = delayAlerts
            prefs[Keys.PLATFORM_ALERTS] = platformAlerts
        }
    }

    suspend fun updateLastSync(epochMs: Long) {
        context.brDataStore.edit { prefs ->
            prefs[Keys.LAST_SYNC_MS] = epochMs
        }
    }

    suspend fun clearAll() {
        context.brDataStore.edit { it.clear() }
    }
}
