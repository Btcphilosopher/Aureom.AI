package com.example.data.model

import java.util.Locale

enum class AppLanguage {
    ENGLISH,
    CYMRAEG
}

enum class ServiceStatus(val label: String, val welshLabel: String) {
    SCHEDULED("Scheduled", "Amserlen"),
    ON_TIME("On time", "Ar amser"),
    DELAYED("Delayed", "Oedi"),
    CANCELLED("Cancelled", "Wedi'i ganslo"),
    SIMULATED("Simulated", "Efelychiedig");

    fun localized(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshLabel else label
}

enum class TicketStatus(val label: String, val welshLabel: String) {
    PENDING("Pending", "Yn aros"),
    AVAILABLE("Available", "Ar gael"),
    EXPIRED("Expired", "Wedi dod i ben"),
    CANCELLED("Cancelled", "Wedi'i ganslo"),
    REFUNDED("Refunded", "Wedi'i ad-dalu");

    fun localized(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshLabel else label
}

enum class AssistanceState(val label: String, val welshLabel: String) {
    NONE("Not requested", "Heb ei ofyn"),
    REQUESTED("Requested", "Gofynnwyd"),
    PENDING("Pending confirmation", "Yn aros am gadarnhad"),
    CONFIRMED("Confirmed", "Cadarnhawyd");

    fun localized(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshLabel else label
}

enum class AfterSalesType(val label: String) {
    REFUND_REQUEST("Refund request"),
    TICKET_CHANGE("Ticket change"),
    DISRUPTION_CLAIM("Delay Repay / disruption claim")
}

enum class AfterSalesStatus(val label: String) {
    SUBMITTED("Submitted — awaiting operator review"),
    UNDER_REVIEW("Under review"),
    APPROVED("Approved"),
    DECLINED("Declined")
}

data class Station(
    val crsCode: String,
    val name: String,
    val accessibilityKnown: Boolean = true,
    val isStepFree: Boolean? = true,
    val hasHearingLoop: Boolean? = true,
    val hasAccessibleToilet: Boolean? = true,
    val interchangeTimeMinutes: Int = 5,
    val latitude: Double = 53.3781,
    val longitude: Double = -1.4621,
    val isPopular: Boolean = false
) {
    val displayName: String get() = "$name [$crsCode]"

    fun stepFreeSummary(): String = when {
        !accessibilityKnown || isStepFree == null -> "Step-free status unknown (not surveyed)"
        isStepFree -> "Step-free access verified"
        else -> "Not step-free throughout"
    }
}

enum class RailcardType(
    val englishName: String,
    val welshName: String,
    val discountPercent: Int,
    val eligibilitySummary: String
) {
    NONE("No railcard", "Dim cerdyn rheilffordd", 0, "Standard undiscounted fares."),
    SIXTEEN_TO_TWENTY_FIVE("16-25 Railcard", "Cerdyn Rheilffordd 16-25", 34, "1/3 off eligible adult fares."),
    TWO_TOGETHER("Two Together Railcard", "Cerdyn Rheilffordd Dau Gyda'n Gilydd", 34, "Requires 2 adults travelling together on Standard fares."),
    SENIOR("Senior Railcard", "Cerdyn Rheilffordd Hŷn", 34, "1/3 off eligible adult fares."),
    DISABLED_PERSONS("Disabled Persons Railcard", "Cerdyn Rheilffordd Personau Anabl", 34, "1/3 off holder and 1 adult companion."),
    NETWORK("Network Railcard", "Cerdyn Rheilffordd Network", 34, "1/3 off eligible flexible Off-Peak/Anytime fares; excludes Advance."),
    FAMILY_AND_FRIENDS("Family & Friends Railcard", "Cerdyn Rheilffordd Teulu a Ffrindiau", 34, "Requires at least 1 adult and 1 child; 1/3 off adults, 60% off children.");

    fun getLocalizedName(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshName else englishName
}

enum class TravelClass(val displayName: String, val welshName: String) {
    STANDARD("Standard", "Safonol"),
    FIRST("First Class", "Dosbarth Cyntaf");

    fun getLocalizedName(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshName else displayName
}

enum class TicketType(
    val displayName: String,
    val welshName: String,
    val isTrainSpecific: Boolean,
    val isReturn: Boolean,
    val defaultRestrictions: String,
    val defaultRefundPolicy: String
) {
    ADVANCE_SINGLE(
        displayName = "Advance single",
        welshName = "Sengl Ymlaen Llaw",
        isTrainSpecific = true,
        isReturn = false,
        defaultRestrictions = "Valid ONLY on the booked date and exact train service shown.",
        defaultRefundPolicy = "Non-refundable. Date/time changes permitted prior to departure subject to fare difference and £10 admin fee."
    ),
    OFF_PEAK_SINGLE(
        displayName = "Off-Peak single",
        welshName = "Sengl Oriau Tawel",
        isTrainSpecific = false,
        isReturn = false,
        defaultRestrictions = "Valid on off-peak services on the date shown via permitted routes.",
        defaultRefundPolicy = "Refundable before expiry subject to £10 administration fee (product rules apply)."
    ),
    ANYTIME_SINGLE(
        displayName = "Anytime single",
        welshName = "Sengl Unrhyw Bryd",
        isTrainSpecific = false,
        isReturn = false,
        defaultRestrictions = "Flexible: valid on any train along the route on the travel date.",
        defaultRefundPolicy = "Refundable before travel subject to £10 admin fee unless waived."
    ),
    OFF_PEAK_RETURN(
        displayName = "Off-Peak return",
        welshName = "Dychwelyd Oriau Tawel",
        isTrainSpecific = false,
        isReturn = true,
        defaultRestrictions = "Outward valid on date shown (off-peak); return valid within 1 calendar month.",
        defaultRefundPolicy = "Unused return tickets refundable before expiry minus admin fee."
    ),
    ANYTIME_RETURN(
        displayName = "Anytime return",
        welshName = "Dychwelyd Unrhyw Bryd",
        isTrainSpecific = false,
        isReturn = true,
        defaultRestrictions = "Outward valid 5 days; return valid within 1 calendar month on any service.",
        defaultRefundPolicy = "Refundable subject to explicit operator rules."
    );

    fun getLocalizedName(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshName else displayName
}

data class PassengerConfig(
    val adults: Int = 1,
    val children: Int = 0,
    val railcard: RailcardType = RailcardType.NONE
) {
    val totalPassengers: Int get() = adults + children

    fun summary(language: AppLanguage = AppLanguage.ENGLISH): String {
        val adultStr = if (adults == 1) {
            if (language == AppLanguage.CYMRAEG) "1 oedolyn" else "1 adult"
        } else {
            if (language == AppLanguage.CYMRAEG) "$adults oedolion" else "$adults adults"
        }

        val childStr = if (children > 0) {
            if (children == 1) {
                if (language == AppLanguage.CYMRAEG) " • 1 plentyn" else " • 1 child"
            } else {
                if (language == AppLanguage.CYMRAEG) " • $children plant" else " • $children children"
            }
        } else ""

        val railcardStr = if (railcard != RailcardType.NONE) {
            " • " + railcard.getLocalizedName(language)
        } else {
            if (language == AppLanguage.CYMRAEG) " • Dim cerdyn" else " • No railcard"
        }

        return "$adultStr$childStr$railcardStr"
    }
}

data class JourneyLeg(
    val originStation: String,
    val originCrs: String,
    val destinationStation: String,
    val destinationCrs: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val operator: String = "British Rail InterCity",
    val platform: String? = null,
    val isWalkingConnection: Boolean = false,
    val connectionMinutes: Int? = null,
    val callingPoints: List<String> = emptyList(),
    val accessibilityNote: String = "Step-free status unknown",
    val alertMessage: String? = null
) {
    val durationStr: String
        get() {
            val h = durationMinutes / 60
            val m = durationMinutes % 60
            return if (h > 0) "${h}h ${m.toString().padStart(2, '0')}m" else "${m}m"
        }
}

data class ServiceFare(
    val id: String,
    val ticketType: TicketType,
    val travelClass: TravelClass,
    val pricePence: Int,
    val isAvailable: Boolean = true,
    val quotaRemaining: Int = 8,
    val reservationIncluded: Boolean = true,
    val customRestrictions: String? = null
) {
    val formattedPrice: String get() = formatPence(pricePence)
    val restrictions: String get() = customRestrictions ?: ticketType.defaultRestrictions
}

data class JourneyOption(
    val id: String,
    val origin: Station,
    val destination: Station,
    val serviceDate: String,      // ISO e.g. "2026-11-13"
    val timeZoneId: String = "Europe/London",
    val departureTime: String,
    val arrivalTime: String,
    val expectedDepartureTime: String? = null,
    val durationMinutes: Int,
    val changes: Int = 0,
    val arrivalDayOffset: Int = 0, // 0 = same day, 1 = next day (+1d overnight)
    val legs: List<JourneyLeg> = emptyList(),
    val fares: List<ServiceFare> = emptyList(),
    val status: ServiceStatus = ServiceStatus.SCHEDULED,
    val disruptionSummary: String? = null,
    val isAccessibleRoute: Boolean = false,
    val accessibilityConfidenceKnown: Boolean = true
) {
    val isOvernight: Boolean get() = arrivalDayOffset > 0
    val durationStr: String
        get() {
            val h = durationMinutes / 60
            val m = durationMinutes % 60
            return if (h > 0) "${h}h ${m.toString().padStart(2, '0')}m" else "${m}m"
        }
    val routeSummary: String
        get() = if (changes == 0) "Direct" else if (changes == 1) "1 change" else "$changes changes"
}

data class FareBreakdown(
    val baseAdultPence: Int,
    val baseChildPence: Int,
    val railcardDiscountPence: Int,
    val railcardAppliedNote: String? = null,
    val ticketFarePence: Int,
    val seatReservationPence: Int = 0,
    val bookingFeePence: Int = 0,
    val totalPence: Int
) {
    val formattedTotal: String get() = formatPence(totalPence)
}

enum class BookingStatus {
    PENDING_PAYMENT,
    PAYMENT_CONFIRMED_AWAITING_ISSUANCE,
    CONFIRMED,
    CANCELLED,
    REFUND_REQUESTED
}

data class Booking(
    val bookingReference: String,
    val collectionCode: String,
    val journey: JourneyOption,
    val selectedFare: ServiceFare,
    val passengers: PassengerConfig,
    val travelDate: String,
    val returnDate: String? = null,
    val isReturn: Boolean = false,
    val totalPence: Int,
    val paymentAuthCode: String = "",
    val idempotencyKey: String = "",
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val lastSyncedEpochMs: Long = System.currentTimeMillis(),
    val bookingStatus: BookingStatus = BookingStatus.CONFIRMED,
    val ticketStatus: TicketStatus = TicketStatus.AVAILABLE,
    val seatReservation: String = "Coach C, Seat 42 (Window, Forward)",
    val qrPayload: String = "",
    val isGuestPurchase: Boolean = true,
    val assistanceState: AssistanceState = AssistanceState.NONE
) {
    val formattedPrice: String get() = formatPence(totalPence)
}

enum class PaymentMethod(val displayName: String, val welshName: String) {
    CARD_SIMULATED("Debit / Credit Card (Simulated Gateway)", "Cerdyn Debyd / Credyd (Efelychiedig)"),
    APP_PAY_SIMULATED("Mobile Payment Token (Configured Provider)", "Taliad Symudol (Darparwr wedi'i ffurfweddu)")
}

enum class SimulatedPaymentOutcome {
    SUCCESS,
    DECLINED,
    TIMEOUT,
    CANCELLED,
    UNCERTAIN_RECONCILE
}

data class PaymentRequest(
    val bookingReference: String,
    val idempotencyKey: String,
    val amountPence: Int,
    val method: PaymentMethod,
    val simulatedOutcome: SimulatedPaymentOutcome = SimulatedPaymentOutcome.SUCCESS
)

sealed class PaymentResult {
    data class Success(val authCode: String, val transactionId: String, val reconciled: Boolean = false) : PaymentResult()
    data class Declined(val reason: String) : PaymentResult()
    data class Uncertain(val message: String) : PaymentResult()
    object Timeout : PaymentResult()
    object Cancelled : PaymentResult()
}

sealed class TicketIssuanceResult {
    data class Issued(val ticketPayload: String, val qrData: String, val issuedAtEpochMs: Long) : TicketIssuanceResult()
    data class Pending(val reason: String) : TicketIssuanceResult()
    data class Failed(val error: String) : TicketIssuanceResult()
}

data class DepartureItem(
    val id: String,
    val stationCrs: String,
    val destination: String,
    val destinationCrs: String,
    val scheduledTime: String,
    val expectedTime: String?,
    val platform: String?,
    val status: ServiceStatus,
    val callingPoints: List<String>,
    val operator: String,
    val isSimulated: Boolean = true
)

data class DisruptionNotice(
    val id: String,
    val scope: String,
    val severity: String, // "Minor delays", "Service alert", "Planned engineering"
    val title: String,
    val detail: String,
    val updatedTime: String,
    val isSimulated: Boolean = true
)

data class FavouriteRoute(
    val id: String,
    val originCrs: String,
    val originName: String,
    val destCrs: String,
    val destName: String
)

data class RecentSearch(
    val id: String,
    val originCrs: String,
    val originName: String,
    val destCrs: String,
    val destName: String,
    val travelDate: String,
    val searchedAtEpochMs: Long
)

data class AfterSalesCase(
    val id: String,
    val bookingReference: String,
    val type: AfterSalesType,
    val status: AfterSalesStatus,
    val reason: String,
    val submittedAtEpochMs: Long,
    val note: String
)

data class AssistanceRequest(
    val id: String,
    val bookingReference: String?,
    val stationName: String,
    val requirement: String,
    val state: AssistanceState,
    val updatedAtEpochMs: Long
)

data class StationAccessibilityInfo(
    val stationCrs: String,
    val stationName: String,
    val accessibilityKnown: Boolean,
    val stepFreeCategory: String,
    val staffAssistanceAvailable: Boolean?,
    val inductionLoop: Boolean?,
    val accessibleToilets: Boolean?,
    val rampAvailable: Boolean?,
    val tactilePaving: Boolean?,
    val notes: String
)

fun formatPence(pence: Int): String {
    val pounds = pence / 100
    val remainder = kotlin.math.abs(pence % 100)
    return String.format(Locale.UK, "£%d.%02d", pounds, remainder)
}
