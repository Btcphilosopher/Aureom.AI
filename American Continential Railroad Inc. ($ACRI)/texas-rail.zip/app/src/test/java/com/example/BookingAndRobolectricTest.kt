package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.database.EncryptedTokenStore
import com.example.core.database.PreferencesRepository
import com.example.core.database.TexasRailDatabase
import com.example.core.model.BookingStatus
import com.example.core.model.JourneySearchQuery
import com.example.core.model.OperatingMode
import com.example.core.model.Passenger
import com.example.core.model.PassengerType
import com.example.core.model.PaymentStatus
import com.example.core.model.SandboxPaymentOutcome
import com.example.core.model.SeatAssignment
import com.example.core.network.TexasRailApiFactory
import com.example.core.routing.RaptorRouter
import com.example.data.booking.FareBookingPaymentTicketRepository
import com.example.data.timetables.DemoSeedDataset
import com.example.data.timetables.NetworkAndTimetableRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.Instant
import java.time.LocalDate

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BookingAndRobolectricTest {

    private lateinit var db: TexasRailDatabase
    private lateinit var prefsRepo: PreferencesRepository
    private lateinit var bookingRepo: FareBookingPaymentTicketRepository
    private lateinit var timetableRepo: NetworkAndTimetableRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, TexasRailDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val tokenStore = EncryptedTokenStore(context)
        prefsRepo = PreferencesRepository(context, tokenStore)
        runBlocking {
            prefsRepo.setOperatingMode(OperatingMode.CONCEPT_DEMONSTRATION, "http://10.0.2.2:8080/", ticketingAuthorized = false)
        }
        bookingRepo = FareBookingPaymentTicketRepository(db, db.inventoryAndBookingDao(), prefsRepo)
        val apiFactory = TexasRailApiFactory(OkHttpClient(), Json { ignoreUnknownKeys = true })
        timetableRepo = NetworkAndTimetableRepository(
            timetableDao = db.timetableDao(),
            preferencesRepository = prefsRepo,
            apiFactory = apiFactory,
            raptorRouter = RaptorRouter(),
            fareProvider = bookingRepo
        )
    }

    @After
    fun tearDown() {
        runBlocking {
            prefsRepo.setOperatingMode(OperatingMode.CONCEPT_DEMONSTRATION, "http://10.0.2.2:8080/", ticketingAuthorized = false)
        }
        db.close()
    }

    @Test
    fun `expired fare offer is rejected before creating reservation`() = runTest {
        timetableRepo.ensureSeeded()
        val date = LocalDate.parse(DemoSeedDataset.REFERENCE_DATE_ISO)
        val journey = timetableRepo.searchJourneys(JourneySearchQuery("st_dal", "st_aus", date, 1)).first()
        val expiredJourney = journey.copy(
            fareOffer = journey.fareOffer.copy(expiresAt = Instant.now().minusSeconds(60))
        )
        val result = bookingRepo.createReservation("user_a", "idem_exp_1", expiredJourney, date, 1, emptyList())
        assertTrue(result.isFailure)
    }

    @Test
    fun `concurrent seat reservation prevents overselling and duplicate seat collision`() = runTest {
        timetableRepo.ensureSeeded()
        val date = LocalDate.parse(DemoSeedDataset.REFERENCE_DATE_ISO)
        val journey = timetableRepo.searchJourneys(JourneySearchQuery("st_dal", "st_aus", date, 1)).first()

        val firstRes = bookingRepo.createReservation("user_a", "idem_c1", journey, date, 1, listOf("5A"))
        assertTrue(firstRes.isSuccess)

        // Second user tries to book the exact same seat 5A
        val secondRes = bookingRepo.createReservation("user_b", "idem_c2", journey, date, 1, listOf("5A"))
        assertTrue(secondRes.isFailure)
    }

    @Test
    fun `failed and cancelled payments cannot confirm booking`() = runTest {
        timetableRepo.ensureSeeded()
        val date = LocalDate.parse(DemoSeedDataset.REFERENCE_DATE_ISO)
        val journey = timetableRepo.searchJourneys(JourneySearchQuery("st_dal", "st_aus", date, 1)).first()
        val res = bookingRepo.createReservation("user_a", "idem_fail_res", journey, date, 1, listOf("6A")).getOrThrow()

        val declinedPay = bookingRepo.initializeSandboxPayment(
            reservation = res,
            idempotencyKey = "pay_declined",
            paymentMethodToken = "tok_sandbox_visa_4242",
            simulationOutcome = SandboxPaymentOutcome.FAIL_DECLINED
        ).getOrThrow()
        assertEquals(PaymentStatus.FAILED, declinedPay.status)

        val confirmAttempt = bookingRepo.confirmBooking(
            userId = "user_a",
            reservationId = res.id,
            paymentId = declinedPay.id,
            passengers = listOf(Passenger("p1", "Jane Doe", PassengerType.ADULT)),
            seats = listOf(SeatAssignment("seg_0", "Coach 1", "6A", false)),
            journey = journey
        )
        assertTrue(confirmAttempt.isFailure)
    }

    @Test
    fun `duplicate webhook is idempotent and successful demo booking creates isolated offline ticket with demo label and refund`() = runTest {
        timetableRepo.ensureSeeded()
        val date = LocalDate.parse(DemoSeedDataset.REFERENCE_DATE_ISO)
        val journey = timetableRepo.searchJourneys(JourneySearchQuery("st_dal", "st_aus", date, 1)).first()
        val res = bookingRepo.createReservation("user_a", "idem_ok_res", journey, date, 1, listOf("7B")).getOrThrow()

        val pay = bookingRepo.initializeSandboxPayment(
            reservation = res,
            idempotencyKey = "pay_dup_ok",
            paymentMethodToken = "tok_sandbox_visa_4242",
            simulationOutcome = SandboxPaymentOutcome.DUPLICATE_WEBHOOK_SUCCEED
        ).getOrThrow()
        assertEquals(PaymentStatus.SUCCEEDED, pay.status)

        val booking = bookingRepo.confirmBooking(
            userId = "user_a",
            reservationId = res.id,
            paymentId = pay.id,
            passengers = listOf(Passenger("p1", "Sam Houston", PassengerType.ADULT)),
            seats = listOf(SeatAssignment("seg_0", "Coach 1", "7B", false)),
            journey = journey
        ).getOrThrow()

        assertTrue(booking.ticket.isDemonstration)
        assertEquals("DEMO — NOT VALID FOR TRAVEL", booking.ticket.demoDisclaimer)
        assertTrue(booking.ticket.qrPayload.contains("NOT-VALID-FOR-TRAVEL"))

        // Account data isolation: user_b must NOT see or access user_a's booking
        assertNull(bookingRepo.getBooking(booking.id, "user_b"))
        assertTrue(bookingRepo.observeBookings("user_b").first().isEmpty())
        assertEquals(1, bookingRepo.observeBookings("user_a").first().size)

        // Refund restores seats and marks REFUNDED
        val refund = bookingRepo.requestRefund("user_a", booking.id, "Plan change").getOrThrow()
        assertTrue(refund.amount.cents > 0L)
        assertEquals(BookingStatus.REFUNDED, bookingRepo.getBooking(booking.id, "user_a")?.status)
    }

    @Test
    fun `connected services mode refuses ticket issuance when ticketing is not authorized`() = runTest {
        timetableRepo.ensureSeeded()
        val date = LocalDate.parse(DemoSeedDataset.REFERENCE_DATE_ISO)
        val journey = timetableRepo.searchJourneys(JourneySearchQuery("st_dal", "st_aus", date, 1)).first()
        prefsRepo.setOperatingMode(OperatingMode.CONNECTED_SERVICES, "http://10.0.2.2:8080/", ticketingAuthorized = false)

        val res = bookingRepo.createReservation("user_a", "idem_conn_blocked", journey, date, 1, emptyList())
        assertTrue(res.isFailure)
    }
}
