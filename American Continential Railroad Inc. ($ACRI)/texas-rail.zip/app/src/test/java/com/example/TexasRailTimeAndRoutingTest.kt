package com.example

import com.example.core.model.CalendarException
import com.example.core.model.CalendarExceptionType
import com.example.core.model.FareCondition
import com.example.core.model.FareOffer
import com.example.core.model.JourneyFilter
import com.example.core.model.JourneySearchQuery
import com.example.core.model.Money
import com.example.core.model.OperatingMode
import com.example.core.model.ServiceCalendar
import com.example.core.model.Station
import com.example.core.model.StationAccessibility
import com.example.core.model.StationParkingBikes
import com.example.core.model.StopTime
import com.example.core.model.Transfer
import com.example.core.model.Trip
import com.example.core.routing.RaptorRouter
import com.example.core.time.TexasRailTime
import com.example.data.timetables.DatabaseMappers.toDomain
import com.example.data.timetables.DemoSeedDataset
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate

class TexasRailTimeAndRoutingTest {

    private val router = RaptorRouter()

    private fun buildSeedSnapshot(): RaptorRouter.TimetableSnapshot {
        val stations = DemoSeedDataset.stations.map { it.toDomain() }.associateBy { it.id }
        val routes = DemoSeedDataset.routes.map { it.toDomain() }.associateBy { it.id }
        val calendars = DemoSeedDataset.calendars.map { it.toDomain() }.associateBy { it.id }
        val exceptions = DemoSeedDataset.calendarExceptions.map { it.toDomain() }
        val trips = DemoSeedDataset.trips.map { it.toDomain() }
        val stopTimesByTrip = DemoSeedDataset.stopTimes.map { it.toDomain() }.groupBy { it.tripId }
        val transfersByStation = DemoSeedDataset.transfers.map { it.toDomain() }.groupBy { it.fromStationId }
        return RaptorRouter.TimetableSnapshot(
            stations = stations,
            routes = routes,
            calendars = calendars,
            exceptions = exceptions,
            trips = trips,
            stopTimesByTrip = stopTimesByTrip,
            transfersByStation = transfersByStation
        )
    }

    private fun seedFareResolver(tripIds: List<String>, date: LocalDate, pax: Int): FareOffer {
        var base = 0L
        var tax = 0L
        var fee = 0L
        tripIds.forEach { id ->
            val (b, t, f) = DemoSeedDataset.basePricingForTrip(id)
            base += b
            tax += t
            fee += f
        }
        return FareOffer(
            id = "offer_${tripIds.joinToString("_")}",
            tripIds = tripIds,
            fareClass = "Standard",
            baseFarePerPassenger = Money(base, "USD"),
            taxPerPassenger = Money(tax, "USD"),
            feePerPassenger = Money(fee, "USD"),
            availableSeats = 40,
            seatAvailabilitySupported = true,
            expiresAt = Instant.now().plusSeconds(900),
            conditions = FareCondition("Standard", 24, 10, true, 0L, true, 2, "Standard Flex", 0L),
            operatingMode = OperatingMode.CONCEPT_DEMONSTRATION
        )
    }

    @Test
    fun `dallas to austin reproduces reference schedules and fares`() = runTest {
        val snapshot = buildSeedSnapshot()
        val results = router.findJourneys(
            snapshot = snapshot,
            query = JourneySearchQuery("st_dal", "st_aus", LocalDate.of(2026, 5, 14), 1),
            fareResolver = { ids, d, p -> seedFareResolver(ids, d, p) }
        )
        assertEquals(3, results.size)
        val summary = results.map {
            Triple(
                TexasRailTime.formatLocalTime(it.departureInstant, "America/Chicago"),
                TexasRailTime.formatLocalTime(it.arrivalInstant, "America/Chicago"),
                it.fareOffer.totalPerPassenger.cents
            )
        }
        assertEquals(
            listOf(
                Triple("08:00", "10:10", 4900L),
                Triple("10:30", "12:40", 5900L),
                Triple("13:00", "15:10", 4500L)
            ),
            summary
        )
        assertTrue(results.all { it.totalDurationMinutes == 130L && it.isDirect })
    }

    @Test
    fun `central to mountain time overnight trip calculates true instant duration`() = runTest {
        val snapshot = buildSeedSnapshot()
        val results = router.findJourneys(
            snapshot = snapshot,
            query = JourneySearchQuery("st_ftw", "st_elp", LocalDate.of(2026, 5, 14), 1),
            fareResolver = { ids, d, p -> seedFareResolver(ids, d, p) }
        )
        assertEquals(1, results.size)
        val trip = results.first()
        // 21:15 CDT -> 07:45 MDT (+1d) is 11h 30m (690 minutes), NOT 10h 30m
        assertEquals(690L, trip.totalDurationMinutes)
        assertEquals("21:15", TexasRailTime.formatLocalTime(trip.departureInstant, "America/Chicago"))
        assertEquals("07:45", TexasRailTime.formatLocalTime(trip.arrivalInstant, "America/Denver"))
        assertEquals("+1d", TexasRailTime.formatDayDifferenceBadge(trip.departureInstant, "America/Chicago", trip.arrivalInstant, "America/Denver"))
        // El Paso has unknown levelBoarding, so accessibilityVerified must be false
        assertFalse(trip.accessibilityVerified)
    }

    @Test
    fun `daylight saving spring forward and fall back transitions compute exact elapsed minutes`() {
        // Spring forward in America/Chicago: 2026-03-08 (02:00 jumps to 03:00)
        val springDep = TexasRailTime.resolveStopInstant(LocalDate.of(2026, 3, 8), 1 * 3600 + 1800, 0, "America/Chicago") // 01:30 CST
        val springArr = TexasRailTime.resolveStopInstant(LocalDate.of(2026, 3, 8), 3 * 3600 + 1800, 0, "America/Chicago") // 03:30 CDT
        assertEquals(60L, TexasRailTime.elapsedMinutes(springDep, springArr))

        // Fall back in America/Chicago: 2026-11-01 (clocks fall back 1h)
        val fallDep = TexasRailTime.resolveStopInstant(LocalDate.of(2026, 11, 1), 23 * 3600, 0, "America/Chicago") // 23:00 CST
        val fallNight = TexasRailTime.resolveStopInstant(LocalDate.of(2026, 10, 31), 23 * 3600, 0, "America/Chicago") // 23:00 CDT
        val fallMorning = TexasRailTime.resolveStopInstant(LocalDate.of(2026, 11, 1), 6 * 3600, 0, "America/Chicago") // 06:00 CST
        assertEquals(480L, TexasRailTime.elapsedMinutes(fallNight, fallMorning))
        assertTrue(fallDep.isAfter(fallMorning))
    }

    @Test
    fun `transfer timing enforces minimum connection time`() = runTest {
        val baseSnapshot = buildSeedSnapshot()
        // Dallas -> Amarillo requires transfer at Fort Worth:
        // TX-201 arrives FTW 07:40, TX-301 departs FTW 08:30 (50m >= 15m min transfer) -> valid!
        val okResults = router.findJourneys(
            snapshot = baseSnapshot,
            query = JourneySearchQuery("st_dal", "st_ama", LocalDate.of(2026, 5, 14), 1),
            fareResolver = { ids, d, p -> seedFareResolver(ids, d, p) }
        )
        assertTrue(okResults.any { it.transferCount == 1 })

        // Now raise minTransferMinutes at Fort Worth to 60m -> 50m connection must be rejected
        val strictTransfers = baseSnapshot.transfersByStation.toMutableMap()
        strictTransfers["st_ftw"] = listOf(Transfer("xf_strict", "st_ftw", "st_ftw", 60, 90, true))
        val strictResults = router.findJourneys(
            snapshot = baseSnapshot.copy(transfersByStation = strictTransfers),
            query = JourneySearchQuery("st_dal", "st_ama", LocalDate.of(2026, 5, 14), 1),
            fareResolver = { ids, d, p -> seedFareResolver(ids, d, p) }
        )
        assertTrue(strictResults.isEmpty())
    }

    @Test
    fun `calendar exception removes service on excluded date`() = runTest {
        val baseSnapshot = buildSeedSnapshot()
        val removedDate = LocalDate.of(2026, 5, 15)
        val withRemoval = baseSnapshot.copy(
            exceptions = listOf(CalendarException("ex1", "cal_daily", removedDate, CalendarExceptionType.REMOVED))
        )
        val results = router.findJourneys(
            snapshot = withRemoval,
            query = JourneySearchQuery("st_dal", "st_aus", removedDate, 1),
            fareResolver = { ids, d, p -> seedFareResolver(ids, d, p) }
        )
        assertTrue(results.isEmpty())
    }

    @Test
    fun `accessible filter excludes routes where level boarding is unverified`() = runTest {
        val snapshot = buildSeedSnapshot()
        val results = router.findJourneys(
            snapshot = snapshot,
            query = JourneySearchQuery("st_ftw", "st_elp", LocalDate.of(2026, 5, 14), 1, setOf(JourneyFilter.ACCESSIBLE)),
            fareResolver = { ids, d, p -> seedFareResolver(ids, d, p) }
        )
        assertTrue(results.isEmpty())
    }
}
