package com.example

import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.example.core.designsystem.QrCodeMatrixView
import com.example.core.designsystem.TexasRailTheme
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.OperatingMode
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class UiSemanticsRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `top bar exposes heading semantics and accessible labels`() {
        composeRule.setContent {
            TexasRailTheme(darkTheme = false) {
                TexasRailTopBar(
                    showBack = true,
                    operatingMode = OperatingMode.CONCEPT_DEMONSTRATION
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("TEXAS RAIL").assertIsDisplayed()
        composeRule.onNode(SemanticsMatcher.keyIsDefined(SemanticsProperties.Heading)).assertIsDisplayed()
        composeRule.onNodeWithTag("top_bar_back_button").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Navigate back").assertIsDisplayed()
    }

    @Test
    fun `demo qr code displays non-valid-for-travel disclaimer and semantics`() {
        composeRule.setContent {
            TexasRailTheme(darkTheme = true) {
                QrCodeMatrixView(
                    payload = "DEMO-TXR-ABC123-NOT-VALID-FOR-TRAVEL",
                    isDemonstration = true,
                    demoDisclaimer = "DEMO — NOT VALID FOR TRAVEL"
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("DEMO — NOT VALID FOR TRAVEL").assertIsDisplayed()
        composeRule.onNodeWithContentDescription(
            "Demonstration QR code, not valid for travel. Reference DEMO-TXR-ABC123-NOT-VALID-FOR-TRAVEL"
        ).assertIsDisplayed()
    }
}
