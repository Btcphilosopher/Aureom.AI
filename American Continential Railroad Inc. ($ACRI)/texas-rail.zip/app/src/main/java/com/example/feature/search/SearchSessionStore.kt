package com.example.feature.search

import com.example.core.model.JourneyFilter
import com.example.core.model.JourneyOption
import com.example.core.model.JourneySearchQuery
import com.example.data.timetables.DemoSeedDataset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchSessionStore @Inject constructor() {
    private val _query = MutableStateFlow(
        JourneySearchQuery(
            originStationId = "st_dal",
            destinationStationId = "st_aus",
            serviceDate = LocalDate.parse(DemoSeedDataset.REFERENCE_DATE_ISO),
            passengerCount = 1,
            activeFilters = emptySet()
        )
    )
    val query: StateFlow<JourneySearchQuery> = _query.asStateFlow()

    private val _results = MutableStateFlow<List<JourneyOption>>(emptyList())
    val results: StateFlow<List<JourneyOption>> = _results.asStateFlow()

    private val _selectedJourney = MutableStateFlow<JourneyOption?>(null)
    val selectedJourney: StateFlow<JourneyOption?> = _selectedJourney.asStateFlow()

    fun updateRoute(originStationId: String, destinationStationId: String) {
        _query.value = _query.value.copy(
            originStationId = originStationId,
            destinationStationId = destinationStationId
        )
    }

    fun updateOrigin(originStationId: String) {
        _query.value = _query.value.copy(originStationId = originStationId)
    }

    fun updateDestination(destinationStationId: String) {
        _query.value = _query.value.copy(destinationStationId = destinationStationId)
    }

    fun swapOriginDestination() {
        val cur = _query.value
        _query.value = cur.copy(
            originStationId = cur.destinationStationId,
            destinationStationId = cur.originStationId
        )
    }

    fun updateDate(date: LocalDate) {
        _query.value = _query.value.copy(serviceDate = date)
    }

    fun updatePassengerCount(count: Int) {
        _query.value = _query.value.copy(passengerCount = count.coerceIn(1, 8))
    }

    fun toggleFilter(filter: JourneyFilter) {
        val current = _query.value.activeFilters.toMutableSet()
        if (filter in current) current.remove(filter) else current.add(filter)
        _query.value = _query.value.copy(activeFilters = current)
    }

    fun setResults(options: List<JourneyOption>) {
        _results.value = options
    }

    fun selectJourney(option: JourneyOption) {
        _selectedJourney.value = option
    }

    fun findJourneyById(id: String): JourneyOption? =
        _results.value.firstOrNull { it.id == id } ?: _selectedJourney.value?.takeIf { it.id == id }
}
