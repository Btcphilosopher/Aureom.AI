package com.example.feature.tickets

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.OfflinePin
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.QrCodeMatrixView
import com.example.core.designsystem.SectionHeadingWithAccent
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.Booking
import com.example.core.model.BookingStatus
import com.example.core.time.TexasRailTime
import java.time.Instant

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(
    viewModel: TicketsViewModel,
    onPlanTrip: () -> Unit
) {
    val bookings by viewModel.bookings.collectAsStateWithLifecycle()
    val statusMsg by viewModel.statusMessage.collectAsStateWithLifecycle()
    val tokens = LocalTexasRailTokens.current

    var selectedTab by remember { mutableIntStateOf(0) }
    var activePassBooking by remember { mutableStateOf<Booking?>(null) }

    val now = Instant.now()
    val upcoming = remember(bookings, selectedTab) {
        bookings.filter {
            it.status == BookingStatus.CONFIRMED &&
                (it.segments.lastOrNull()?.arrivalInstant?.isAfter(now.minusSeconds(3600)) ?: true)
        }
    }
    val pastOrRefunded = remember(bookings, selectedTab) {
        bookings.filter { it !in upcoming }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        TexasRailTopBar()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .align(Alignment.CenterHorizontally)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            SectionHeadingWithAccent(title = "Ticket Wallet")
            Spacer(modifier = Modifier.height(12.dp))

            if (statusMsg != null) {
                Surface(
                    color = tokens.verifiedBadgeBg,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                ) {
                    Text(
                        text = statusMsg!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.verifiedBadgeInk,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = tokens.cardSurface,
                contentColor = tokens.accentOrange
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Upcoming (${upcoming.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Past & Refunded (${pastOrRefunded.size})") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            val displayed = if (selectedTab == 0) upcoming else pastOrRefunded
            if (displayed.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.cardSurface,
                    border = BorderStroke(1.dp, tokens.divider),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Outlined.ConfirmationNumber,
                            contentDescription = null,
                            tint = tokens.accentOrange,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (selectedTab == 0) "No upcoming tickets" else "No past or refunded journeys",
                            style = MaterialTheme.typography.titleMedium,
                            color = tokens.primaryInk
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Completed demonstration or connected bookings are stored offline here.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = tokens.secondaryInk
                        )
                        if (selectedTab == 0) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = onPlanTrip,
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange)
                            ) {
                                Text("Search trains")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(displayed, key = { it.id }) { booking ->
                        TicketWalletCard(
                            booking = booking,
                            onShowPass = { activePassBooking = booking },
                            onRefund = { viewModel.requestRefund(booking) }
                        )
                    }
                }
            }
        }
    }

    activePassBooking?.let { booking ->
        ModalBottomSheet(onDismissRequest = { activePassBooking = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = booking.referenceCode,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                    color = tokens.primaryInk
                )
                val firstSeg = booking.segments.firstOrNull()
                val lastSeg = booking.segments.lastOrNull()
                if (firstSeg != null && lastSeg != null) {
                    Text(
                        text = "${firstSeg.originStationName} → ${lastSeg.destinationStationName}",
                        style = MaterialTheme.typography.titleMedium,
                        color = tokens.secondaryInk
                    )
                }
                QrCodeMatrixView(
                    payload = booking.ticket.qrPayload,
                    isDemonstration = booking.ticket.isDemonstration,
                    demoDisclaimer = booking.ticket.demoDisclaimer
                )
                Text(
                    text = "Passengers: ${booking.passengers.joinToString { it.fullName }}",
                    style = MaterialTheme.typography.bodyMedium
                )
                if (booking.seats.isNotEmpty()) {
                    Text(
                        text = "Seats: ${booking.seats.joinToString { "${it.coach} • ${it.seatNumber}" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.secondaryInk
                    )
                }
                Text(
                    text = "Offline cache timestamp: ${TexasRailTime.formatRefreshTimestamp(booking.cachedAt)}. Offline storage does not imply operator acceptance without valid issuer credentials.",
                    style = MaterialTheme.typography.bodySmall,
                    color = tokens.secondaryInk
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun TicketWalletCard(
    booking: Booking,
    onShowPass: () -> Unit,
    onRefund: () -> Unit
) {
    val tokens = LocalTexasRailTokens.current
    val firstSeg = booking.segments.firstOrNull()
    val lastSeg = booking.segments.lastOrNull()

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        border = BorderStroke(
            width = if (booking.ticket.isDemonstration) 1.5.dp else 1.dp,
            color = if (booking.ticket.isDemonstration) tokens.accentOrange.copy(alpha = 0.6f) else tokens.divider
        ),
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth().testTag("ticket_card_${booking.referenceCode}")
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (booking.ticket.isDemonstration) {
                Surface(color = tokens.accentOrange, shape = RoundedCornerShape(6.dp)) {
                    Text(
                        text = booking.ticket.demoDisclaimer,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = booking.referenceCode,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = tokens.primaryInk
                )
                Text(
                    text = booking.status.name,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (booking.status == BookingStatus.CONFIRMED) tokens.verifiedBadgeInk else tokens.secondaryInk
                )
            }

            if (firstSeg != null && lastSeg != null) {
                Text(
                    text = "${firstSeg.originStationName} → ${lastSeg.destinationStationName}",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = tokens.primaryInk
                )
                val depStr = TexasRailTime.formatLocalTime(firstSeg.departureInstant, firstSeg.originZoneId)
                val arrStr = TexasRailTime.formatLocalTime(lastSeg.arrivalInstant, lastSeg.destinationZoneId)
                Text(
                    text = "${TexasRailTime.formatDateChip(booking.serviceDate)} • $depStr → $arrStr • ${firstSeg.trainNumber}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = tokens.secondaryInk
                )
            }

            Text(
                text = "Passengers: ${booking.passengers.joinToString { it.fullName }}",
                style = MaterialTheme.typography.bodySmall,
                color = tokens.primaryInk
            )
            if (booking.seats.isNotEmpty()) {
                Text(
                    text = "Assigned seats: ${booking.seats.joinToString { "${it.coach} ${it.seatNumber}" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = tokens.secondaryInk
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.OfflinePin, contentDescription = null, tint = tokens.verifiedBadgeInk, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Available offline • Cached ${TexasRailTime.formatRefreshTimestamp(booking.cachedAt)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.secondaryInk
                )
            }

            HorizontalDivider(color = tokens.divider)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onShowPass,
                    colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                    modifier = Modifier.weight(1f).testTag("show_pass_${booking.referenceCode}")
                ) {
                    Icon(Icons.Outlined.QrCode2, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Show pass")
                }
                if (booking.status == BookingStatus.CONFIRMED && booking.fareConditionSnapshot.exchangeAllowed) {
                    OutlinedButton(
                        onClick = onRefund,
                        modifier = Modifier.weight(1f).testTag("refund_${booking.referenceCode}")
                    ) {
                        Text("Refund (${100 - booking.fareConditionSnapshot.refundFeePercent}%)")
                    }
                }
            }
        }
    }
}
