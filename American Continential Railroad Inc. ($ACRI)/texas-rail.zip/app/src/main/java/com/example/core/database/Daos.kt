package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TimetableDao {
    @Query("SELECT * FROM dataset_versions ORDER BY lastSyncedAtMillis DESC LIMIT 1")
    fun observeLatestDatasetVersion(): Flow<DatasetVersionEntity?>

    @Query("SELECT * FROM dataset_versions ORDER BY lastSyncedAtMillis DESC LIMIT 1")
    suspend fun getLatestDatasetVersion(): DatasetVersionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDatasetVersion(version: DatasetVersionEntity)

    @Query("SELECT * FROM stations ORDER BY isMajorCity DESC, name ASC")
    fun observeStations(): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations")
    suspend fun getAllStations(): List<StationEntity>

    @Query("SELECT * FROM stations WHERE id = :stationId")
    suspend fun getStation(stationId: String): StationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    @Query("SELECT * FROM routes")
    fun observeRoutes(): Flow<List<RouteEntity>>

    @Query("SELECT * FROM routes")
    suspend fun getAllRoutes(): List<RouteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutes(routes: List<RouteEntity>)

    @Query("SELECT * FROM route_patterns")
    fun observeRoutePatterns(): Flow<List<RoutePatternEntity>>

    @Query("SELECT * FROM route_patterns")
    suspend fun getAllRoutePatterns(): List<RoutePatternEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutePatterns(patterns: List<RoutePatternEntity>)

    @Query("SELECT * FROM service_calendars")
    suspend fun getAllCalendars(): List<ServiceCalendarEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendars(calendars: List<ServiceCalendarEntity>)

    @Query("SELECT * FROM calendar_exceptions")
    suspend fun getAllCalendarExceptions(): List<CalendarExceptionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendarExceptions(exceptions: List<CalendarExceptionEntity>)

    @Query("SELECT * FROM trips")
    suspend fun getAllTrips(): List<TripEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrips(trips: List<TripEntity>)

    @Query("SELECT * FROM stop_times ORDER BY stopSequence ASC")
    suspend fun getAllStopTimes(): List<StopTimeEntity>

    @Query("SELECT * FROM stop_times WHERE stationId = :stationId AND pickupAllowed = 1 ORDER BY departureOffsetSeconds ASC")
    suspend fun getDeparturesForStation(stationId: String): List<StopTimeEntity>

    @Query("SELECT * FROM stop_times WHERE tripId = :tripId ORDER BY stopSequence ASC")
    suspend fun getStopTimesForTrip(tripId: String): List<StopTimeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStopTimes(stopTimes: List<StopTimeEntity>)

    @Query("SELECT * FROM transfers")
    suspend fun getAllTransfers(): List<TransferEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransfers(transfers: List<TransferEntity>)

    @Query("SELECT * FROM service_alerts ORDER BY startsAtMillis DESC")
    fun observeAlerts(): Flow<List<ServiceAlertEntity>>

    @Query("SELECT * FROM service_alerts WHERE stationId = :stationId OR stationId IS NULL ORDER BY startsAtMillis DESC")
    suspend fun getAlertsForStation(stationId: String): List<ServiceAlertEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<ServiceAlertEntity>)
}

@Dao
interface InventoryAndBookingDao {
    @Query("SELECT * FROM trip_inventory WHERE tripId = :tripId AND serviceDateIso = :serviceDateIso AND fareClass = :fareClass")
    suspend fun getInventory(tripId: String, serviceDateIso: String, fareClass: String): TripInventoryEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertInventoryIfMissing(items: List<TripInventoryEntity>)

    @Query(
        """
        UPDATE trip_inventory
        SET availableSeats = availableSeats - :count, occupiedSeatsJson = :occupiedSeatsJson
        WHERE tripId = :tripId AND serviceDateIso = :serviceDateIso AND fareClass = :fareClass AND availableSeats >= :count
        """
    )
    suspend fun decrementSeatsAtomically(
        tripId: String,
        serviceDateIso: String,
        fareClass: String,
        count: Int,
        occupiedSeatsJson: String
    ): Int

    @Query(
        """
        UPDATE trip_inventory
        SET availableSeats = MIN(totalSeats, availableSeats + :count), occupiedSeatsJson = :occupiedSeatsJson
        WHERE tripId = :tripId AND serviceDateIso = :serviceDateIso AND fareClass = :fareClass
        """
    )
    suspend fun releaseSeats(
        tripId: String,
        serviceDateIso: String,
        fareClass: String,
        count: Int,
        occupiedSeatsJson: String
    )

    @Query("SELECT * FROM inventory_reservations WHERE idempotencyKey = :idempotencyKey LIMIT 1")
    suspend fun getReservationByIdempotencyKey(idempotencyKey: String): InventoryReservationEntity?

    @Query("SELECT * FROM inventory_reservations WHERE id = :reservationId AND userId = :userId LIMIT 1")
    suspend fun getReservationForUser(reservationId: String, userId: String): InventoryReservationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReservation(reservation: InventoryReservationEntity)

    @Query("UPDATE inventory_reservations SET status = :status WHERE id = :reservationId")
    suspend fun updateReservationStatus(reservationId: String, status: String)

    @Query("SELECT * FROM inventory_reservations WHERE status = 'HELD' AND expiresAtMillis < :nowMillis")
    suspend fun getExpiredHeldReservations(nowMillis: Long): List<InventoryReservationEntity>

    @Query("SELECT * FROM payment_records WHERE idempotencyKey = :idempotencyKey LIMIT 1")
    suspend fun getPaymentByIdempotencyKey(idempotencyKey: String): PaymentRecordEntity?

    @Query("SELECT * FROM payment_records WHERE id = :paymentId LIMIT 1")
    suspend fun getPayment(paymentId: String): PaymentRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayment(payment: PaymentRecordEntity)

    @Query("UPDATE payment_records SET status = :status WHERE id = :paymentId")
    suspend fun updatePaymentStatus(paymentId: String, status: String)

    @Query("SELECT * FROM processed_webhooks WHERE eventId = :eventId LIMIT 1")
    suspend fun getProcessedWebhook(eventId: String): ProcessedWebhookEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertProcessedWebhook(webhook: ProcessedWebhookEntity): Long

    @Query("SELECT * FROM bookings WHERE userId = :userId ORDER BY createdAtMillis DESC")
    fun observeBookingsForUser(userId: String): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE id = :bookingId AND userId = :userId LIMIT 1")
    suspend fun getBookingForUser(bookingId: String, userId: String): BookingEntity?

    @Query("SELECT * FROM bookings WHERE reservationId = :reservationId LIMIT 1")
    suspend fun getBookingByReservationId(reservationId: String): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBooking(booking: BookingEntity)

    @Query("UPDATE bookings SET status = :status WHERE id = :bookingId AND userId = :userId")
    suspend fun updateBookingStatus(bookingId: String, userId: String, status: String)

    @Query("DELETE FROM bookings WHERE userId = :userId")
    suspend fun deleteBookingsForUser(userId: String)

    @Query("DELETE FROM inventory_reservations WHERE userId = :userId")
    suspend fun deleteReservationsForUser(userId: String)
}

@Dao
interface UserLibraryDao {
    @Query("SELECT * FROM saved_journeys WHERE userId = :userId ORDER BY createdAtMillis DESC")
    fun observeSavedJourneys(userId: String): Flow<List<SavedJourneyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedJourney(journey: SavedJourneyEntity)

    @Query("DELETE FROM saved_journeys WHERE id = :id AND userId = :userId")
    suspend fun deleteSavedJourney(id: String, userId: String)

    @Query("DELETE FROM saved_journeys WHERE userId = :userId")
    suspend fun deleteAllSavedJourneysForUser(userId: String)

    @Query("SELECT * FROM saved_passengers WHERE userId = :userId ORDER BY fullName ASC")
    fun observeSavedPassengers(userId: String): Flow<List<SavedPassengerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSavedPassenger(passenger: SavedPassengerEntity)

    @Query("DELETE FROM saved_passengers WHERE id = :id AND userId = :userId")
    suspend fun deleteSavedPassenger(id: String, userId: String)

    @Query("DELETE FROM saved_passengers WHERE userId = :userId")
    suspend fun deleteAllSavedPassengersForUser(userId: String)

    @Query("SELECT * FROM recent_searches ORDER BY searchedAtMillis DESC LIMIT 6")
    fun observeRecentSearches(): Flow<List<RecentSearchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecentSearch(search: RecentSearchEntity)

    @Query("SELECT * FROM saved_stations ORDER BY savedAtMillis DESC")
    fun observeSavedStations(): Flow<List<SavedStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveStation(station: SavedStationEntity)

    @Query("DELETE FROM saved_stations WHERE stationId = :stationId")
    suspend fun removeSavedStation(stationId: String)
}
