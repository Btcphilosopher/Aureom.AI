package com.example.feature.search

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.Accessible
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.DirectionsTransit
import androidx.compose.material.icons.outlined.Savings
import androidx.compose.material.icons.outlined.Train
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.PlusJakartaSansFamily
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.JourneyFilter
import com.example.core.model.JourneyOption
import com.example.core.model.OperatingMode
import com.example.core.model.ServiceStatus
import com.example.core.time.TexasRailTime
import java.time.Instant
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyResultsScreen(
    originId: String,
    destinationId: String,
    dateIso: String,
    passengerCount: Int,
    viewModel: JourneyResultsViewModel,
    onBack: () -> Unit,
    onSelectJourney: (JourneyOption) -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val tokens = LocalTexasRailTokens.current
    var showDatePicker by remember { mutableStateOf(false) }

    LaunchedEffect(originId, destinationId, dateIso, passengerCount) {
        viewModel.load(originId, destinationId, dateIso, passengerCount)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        val currentMode = (state as? ResultsState.Success)?.operatingMode
        TexasRailTopBar(
            showBack = true,
            onBackClick = onBack,
            operatingMode = currentMode
        )

        when (val s = state) {
            ResultsState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = tokens.accentOrange)
                }
            }
            is ResultsState.Error -> {
                Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(s.message, style = MaterialTheme.typography.titleMedium, color = tokens.primaryInk)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = viewModel::executeSearch) { Text("Retry") }
                    }
                }
            }
            is ResultsState.Success -> {
                val originName = s.origin?.name ?: "Origin"
                val destName = s.destination?.name ?: "Destination"

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp)
                        .align(Alignment.CenterHorizontally)
                        .padding(horizontal = 16.dp)
                ) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "$originName → $destName",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = PlusJakartaSansFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 27.sp
                        ),
                        color = tokens.primaryInk,
                        modifier = Modifier.semantics { heading() }
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Date selector bar matching reference
                    Surface(
                        onClick = { showDatePicker = true },
                        shape = RoundedCornerShape(14.dp),
                        color = tokens.cardSurface,
                        border = BorderStroke(1.dp, tokens.divider),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("results_date_bar")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CalendarToday,
                                contentDescription = null,
                                tint = tokens.primaryInk,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = TexasRailTime.formatDateChip(s.query.serviceDate),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = tokens.primaryInk,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = if (s.query.passengerCount == 1) "1 adult" else "${s.query.passengerCount} adults",
                                style = MaterialTheme.typography.labelMedium,
                                color = tokens.secondaryInk
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "Change travel date",
                                tint = tokens.secondaryInk
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Filters: Fastest, Lowest fare, Direct, Accessible
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChipItem(
                            selected = JourneyFilter.FASTEST in s.query.activeFilters,
                            label = "Fastest",
                            icon = { Icon(Icons.Outlined.Bolt, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            testTag = "filter_fastest",
                            onClick = { viewModel.toggleFilter(JourneyFilter.FASTEST) }
                        )
                        FilterChipItem(
                            selected = JourneyFilter.LOWEST_FARE in s.query.activeFilters,
                            label = "Lowest fare",
                            icon = { Icon(Icons.Outlined.Savings, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            testTag = "filter_lowest_fare",
                            onClick = { viewModel.toggleFilter(JourneyFilter.LOWEST_FARE) }
                        )
                        FilterChipItem(
                            selected = JourneyFilter.DIRECT in s.query.activeFilters,
                            label = "Direct",
                            icon = { Icon(Icons.Outlined.DirectionsTransit, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            testTag = "filter_direct",
                            onClick = { viewModel.toggleFilter(JourneyFilter.DIRECT) }
                        )
                        FilterChipItem(
                            selected = JourneyFilter.ACCESSIBLE in s.query.activeFilters,
                            label = "Accessible",
                            icon = { Icon(Icons.AutoMirrored.Outlined.Accessible, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            testTag = "filter_accessible",
                            onClick = { viewModel.toggleFilter(JourneyFilter.ACCESSIBLE) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (s.options.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = tokens.cardSurface,
                            border = BorderStroke(1.dp, tokens.divider),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Train,
                                    contentDescription = null,
                                    tint = tokens.accentOrange,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No matching services",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = tokens.primaryInk
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Try clearing Direct or Accessible filters, or check another date.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = tokens.secondaryInk
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(s.options, key = { it.id }) { option ->
                                val isHighlighted = option.id == s.highlightedOptionId
                                JourneyOptionCard(
                                    option = option,
                                    passengerCount = s.query.passengerCount,
                                    isHighlighted = isHighlighted,
                                    onCardClick = { viewModel.highlightOption(option.id) },
                                    onSelectClick = {
                                        viewModel.selectJourneyForDetail(option)
                                        onSelectJourney(option)
                                    }
                                )
                            }

                            item {
                                Spacer(modifier = Modifier.height(4.dp))
                                if (s.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                                    Text(
                                        text = "Illustrative schedules and fares.",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                                        color = tokens.secondaryInk,
                                        modifier = Modifier.padding(vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                if (showDatePicker) {
                    val initMillis = s.query.serviceDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
                    val pickerState = rememberDatePickerState(initialSelectedDateMillis = initMillis)
                    DatePickerDialog(
                        onDismissRequest = { showDatePicker = false },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    pickerState.selectedDateMillis?.let { ms ->
                                        viewModel.changeDate(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate())
                                    }
                                    showDatePicker = false
                                }
                            ) { Text("Confirm", color = tokens.accentOrange) }
                        },
                        dismissButton = {
                            TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
                        }
                    ) { DatePicker(state = pickerState) }
                }
            }
        }
    }
}

@Composable
private fun FilterChipItem(
    selected: Boolean,
    label: String,
    icon: @Composable () -> Unit,
    testTag: String,
    onClick: () -> Unit
) {
    val tokens = LocalTexasRailTokens.current
    FilterChip(
        selected = selected,
        onClick = onClick,
        leadingIcon = icon,
        label = { Text(label, style = MaterialTheme.typography.labelLarge) },
        shape = RoundedCornerShape(10.dp),
        colors = FilterChipDefaults.filterChipColors(
            containerColor = tokens.cardSurface,
            labelColor = tokens.primaryInk,
            iconColor = tokens.primaryInk,
            selectedContainerColor = tokens.accentSoft,
            selectedLabelColor = tokens.accentOrange,
            selectedLeadingIconColor = tokens.accentOrange
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = tokens.divider,
            selectedBorderColor = tokens.accentOrange
        ),
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag(testTag)
    )
}

@Composable
private fun JourneyOptionCard(
    option: JourneyOption,
    passengerCount: Int,
    isHighlighted: Boolean,
    onCardClick: () -> Unit,
    onSelectClick: () -> Unit
) {
    val tokens = LocalTexasRailTokens.current
    val crossesZone = option.originStation.timeZoneId != option.destinationStation.timeZoneId
    val depStr = TexasRailTime.formatLocalTime(option.departureInstant, option.originStation.timeZoneId)
    val arrStr = TexasRailTime.formatLocalTime(option.arrivalInstant, option.destinationStation.timeZoneId)
    val depZone = TexasRailTime.shortZoneLabel(option.departureInstant, option.originStation.timeZoneId)
    val arrZone = TexasRailTime.shortZoneLabel(option.arrivalInstant, option.destinationStation.timeZoneId)
    val dayDiff = TexasRailTime.formatDayDifferenceBadge(
        option.departureInstant,
        option.originStation.timeZoneId,
        option.arrivalInstant,
        option.destinationStation.timeZoneId
    )

    val timeDisplay = buildString {
        append(depStr)
        if (crossesZone) append(" $depZone")
        append(" → ")
        append(arrStr)
        if (crossesZone) append(" $arrZone")
        if (dayDiff != null) append(" ($dayDiff)")
    }

    val totalFare = option.fareOffer.totalForPassengers(passengerCount)
    val priceDisplay = TexasRailTime.formatMoney(totalFare)
    val durationDisplay = TexasRailTime.formatDuration(option.totalDurationMinutes)
    val transfersDisplay = if (option.isDirect) "Direct" else "${option.transferCount} change"

    val statusText = when (option.serviceStatus) {
        ServiceStatus.SCHEDULED_ILLUSTRATIVE -> "Illustrative schedule"
        ServiceStatus.ON_TIME -> "On time"
        ServiceStatus.DELAYED -> "Delayed"
        ServiceStatus.CANCELLED -> "Cancelled"
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = tokens.cardSurface,
        border = BorderStroke(
            width = if (isHighlighted) 1.75.dp else 1.dp,
            color = if (isHighlighted) tokens.accentOrange else tokens.divider
        ),
        shadowElevation = if (isHighlighted) 3.dp else 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCardClick)
            .semantics(mergeDescendants = true) {
                contentDescription = "$timeDisplay from ${option.originStation.name} to ${option.destinationStation.name}, $durationDisplay, $transfersDisplay, $priceDisplay, $statusText"
            }
            .testTag("journey_card_${option.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = timeDisplay,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = PlusJakartaSansFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 21.sp
                    ),
                    color = tokens.primaryInk,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = priceDisplay,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = PlusJakartaSansFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp
                    ),
                    color = tokens.primaryInk
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$durationDisplay • $transfersDisplay",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                        color = tokens.secondaryInk
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${option.originStation.name} (${option.originStation.code}) → ${option.destinationStation.name} (${option.destinationStation.code})",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.secondaryInk
                    )
                }

                if (isHighlighted) {
                    Button(
                        onClick = onSelectClick,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = tokens.accentOrange,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("select_journey_button_${option.id}")
                    ) {
                        Text("Select", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                } else {
                    OutlinedButton(
                        onClick = onSelectClick,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, tokens.divider),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.primaryInk),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("select_journey_button_${option.id}")
                    ) {
                        Text("Select", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$statusText • ${option.fareOffer.conditions.fareClass} Flex",
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.secondaryInk
                )
                if (option.fareOffer.seatAvailabilitySupported && option.fareOffer.availableSeats != null) {
                    Text(
                        text = "${option.fareOffer.availableSeats} seats left",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = tokens.verifiedBadgeInk
                    )
                }
            }
        }
    }
}
