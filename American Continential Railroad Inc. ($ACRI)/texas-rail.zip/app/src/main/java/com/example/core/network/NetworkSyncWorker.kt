package com.example.core.network

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.core.model.NetworkProvider
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class NetworkSyncWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val networkProvider: NetworkProvider
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val syncResult = networkProvider.refreshSnapshot(force = false)
        return if (syncResult.isSuccess) Result.success() else Result.retry()
    }

    companion object {
        private const val WORK_NAME = "texas_rail_periodic_sync"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<NetworkSyncWorker>(6, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
