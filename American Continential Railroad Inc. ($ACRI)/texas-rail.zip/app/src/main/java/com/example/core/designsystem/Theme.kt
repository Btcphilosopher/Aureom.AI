package com.example.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val TexasRailLightScheme = lightColorScheme(
    primary = TexasRailPalette.BurntOrange,
    onPrimary = TexasRailPalette.PureWhite,
    primaryContainer = TexasRailPalette.BurntOrangeSoft,
    onPrimaryContainer = TexasRailPalette.BurntOrange,
    secondary = TexasRailPalette.DeepNavy,
    onSecondary = TexasRailPalette.PureWhite,
    secondaryContainer = Color(0xFFE2E8F0),
    onSecondaryContainer = TexasRailPalette.DeepNavy,
    tertiary = TexasRailPalette.SlateNavy,
    background = TexasRailPalette.LimestoneIvory,
    onBackground = TexasRailPalette.DeepNavy,
    surface = TexasRailPalette.PureWhite,
    onSurface = TexasRailPalette.DeepNavy,
    surfaceVariant = TexasRailPalette.WarmCream,
    onSurfaceVariant = TexasRailPalette.SlateNavy,
    outline = TexasRailPalette.DividerWarm,
    error = TexasRailPalette.ErrorCrimson,
    errorContainer = TexasRailPalette.ErrorCrimsonSoft
)

private val TexasRailDarkScheme = darkColorScheme(
    primary = TexasRailPalette.BurntOrangeBright,
    onPrimary = TexasRailPalette.PureWhite,
    primaryContainer = TexasRailPalette.BurntOrangeSoftDark,
    onPrimaryContainer = Color(0xFFFFB591),
    secondary = Color(0xFF93B4D8),
    onSecondary = TexasRailPalette.DeepNavyDark,
    secondaryContainer = TexasRailPalette.MidnightElevated,
    onSecondaryContainer = Color(0xFFE6EEF7),
    tertiary = Color(0xFF8CA6C2),
    background = Color(0xFF0C1826),
    onBackground = Color(0xFFF4EDE3),
    surface = TexasRailPalette.MidnightSurface,
    onSurface = Color(0xFFF4EDE3),
    surfaceVariant = TexasRailPalette.MidnightElevated,
    onSurfaceVariant = Color(0xFFAAB8C8),
    outline = TexasRailPalette.DividerDark,
    error = Color(0xFFF28B82),
    errorContainer = Color(0xFF5C1915)
)

private val TexasRailShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun TexasRailTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) TexasRailDarkScheme else TexasRailLightScheme
    val tokens = if (darkTheme) DarkTexasRailTokens else LightTexasRailTokens

    CompositionLocalProvider(LocalTexasRailTokens provides tokens) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = TexasRailTypography,
            shapes = TexasRailShapes,
            content = content
        )
    }
}
