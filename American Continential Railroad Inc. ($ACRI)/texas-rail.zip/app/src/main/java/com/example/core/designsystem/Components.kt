package com.example.core.designsystem

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.OperatingMode
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Split burnt-orange and white five-point Lone Star emblem matching the TEXAS RAIL header mark.
 */
@Composable
fun LoneStarEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 26.dp,
    primaryColor: Color = TexasRailPalette.BurntOrange,
    highlightColor: Color = Color.White
) {
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val outerR = this.size.minDimension * 0.48f
        val innerR = outerR * 0.40f

        val fullStar = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outerR else innerR
            val angle = (-90.0 + i * 36.0) * PI / 180.0
            val px = cx + (r * cos(angle)).toFloat()
            val py = cy + (r * sin(angle)).toFloat()
            if (i == 0) fullStar.moveTo(px, py) else fullStar.lineTo(px, py)
        }
        fullStar.close()
        drawPath(fullStar, color = primaryColor)

        // Subtle crisp white right-upper facet echoing the TEXAS RAIL brand star
        val facet = Path().apply {
            val topX = cx
            val topY = cy - outerR
            val rArmAngle = (-18.0) * PI / 180.0
            val rArmX = cx + (outerR * cos(rArmAngle)).toFloat()
            val rArmY = cy + (outerR * sin(rArmAngle)).toFloat()
            val innerRightAngle = (-54.0) * PI / 180.0
            val innerX = cx + (innerR * cos(innerRightAngle)).toFloat()
            val innerY = cy + (innerR * sin(innerRightAngle)).toFloat()
            moveTo(cx, cy)
            lineTo(topX, topY)
            lineTo(innerX, innerY)
            lineTo(rArmX, rArmY)
            close()
        }
        drawPath(facet, color = highlightColor.copy(alpha = 0.88f))
    }
}

@Composable
fun TexasRailTopBar(
    modifier: Modifier = Modifier,
    showBack: Boolean = false,
    onBackClick: () -> Unit = {},
    showCornerAccent: Boolean = false,
    operatingMode: OperatingMode? = null,
    trailingAction: @Composable (() -> Unit)? = null
) {
    val tokens = LocalTexasRailTokens.current
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(tokens.headerNavy)
            .statusBarsPadding()
    ) {
        if (showCornerAccent) {
            Canvas(
                modifier = Modifier
                    .matchParentSize()
            ) {
                val tri = Path().apply {
                    moveTo(size.width * 0.72f, size.height)
                    lineTo(size.width, size.height * 0.25f)
                    lineTo(size.width, size.height)
                    close()
                }
                drawPath(tri, color = tokens.accentOrange)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (showBack) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("top_bar_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Navigate back",
                        tint = tokens.onHeaderNavy
                    )
                }
            } else {
                Spacer(modifier = Modifier.width(12.dp))
            }

            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LoneStarEmblem(size = 24.dp, primaryColor = tokens.accentOrange)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TEXAS RAIL",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = PlusJakartaSansFamily,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.6.sp,
                        fontSize = 18.sp
                    ),
                    color = tokens.onHeaderNavy,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.semantics { heading() }
                )
            }

            if (trailingAction != null) {
                trailingAction()
            } else if (operatingMode == OperatingMode.CONNECTED_SERVICES) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = tokens.verifiedBadgeBg,
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text(
                        text = "LIVE",
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.verifiedBadgeInk,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            } else {
                Spacer(modifier = Modifier.width(if (showBack) 48.dp else 12.dp))
            }
        }
    }
}

@Composable
fun SectionHeadingWithAccent(
    title: String,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null
) {
    val tokens = LocalTexasRailTokens.current
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 28.sp
                ),
                color = tokens.primaryInk,
                modifier = Modifier.semantics { heading() }
            )
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .width(42.dp)
                    .height(4.dp)
                    .background(tokens.accentOrange, RoundedCornerShape(2.dp))
            )
        }
        if (trailing != null) {
            trailing()
        }
    }
}

@Composable
fun OperatingModeBanner(
    operatingMode: OperatingMode,
    modifier: Modifier = Modifier,
    customText: String? = null
) {
    val tokens = LocalTexasRailTokens.current
    val isDemo = operatingMode == OperatingMode.CONCEPT_DEMONSTRATION
    val bg = if (isDemo) tokens.warningBadgeBg else tokens.verifiedBadgeBg
    val fg = if (isDemo) tokens.warningBadgeInk else tokens.verifiedBadgeInk
    val label = customText ?: if (isDemo) {
        "Concept Demonstration — Illustrative routes, schedules & fares"
    } else {
        "Connected Services — Verified operator feed"
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) {
                contentDescription = label
            },
        color = bg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.28f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isDemo) Icons.Outlined.Info else Icons.Outlined.VerifiedUser,
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = fg
            )
        }
    }
}

@Composable
fun QrCodeMatrixView(
    payload: String,
    isDemonstration: Boolean,
    demoDisclaimer: String,
    modifier: Modifier = Modifier,
    size: Dp = 180.dp
) {
    val matrix = remember(payload) {
        runCatching {
            QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 29, 29)
        }.getOrNull()
    }
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            color = Color.White,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(
                width = if (isDemonstration) 2.dp else 1.dp,
                color = if (isDemonstration) TexasRailPalette.BurntOrange else TexasRailPalette.DividerWarm
            )
        ) {
            Box(
                modifier = Modifier
                    .padding(14.dp)
                    .size(size),
                contentAlignment = Alignment.Center
            ) {
                if (matrix != null) {
                    Canvas(
                        modifier = Modifier
                            .matchParentSize()
                            .semantics {
                                contentDescription = if (isDemonstration) {
                                    "Demonstration QR code, not valid for travel. Reference $payload"
                                } else {
                                    "Boarding QR code for $payload"
                                }
                            }
                    ) {
                        val cols = matrix.width
                        val rows = matrix.height
                        val cellW = this.size.width / cols
                        val cellH = this.size.height / rows
                        for (y in 0 until rows) {
                            for (x in 0 until cols) {
                                if (matrix.get(x, y)) {
                                    drawRect(
                                        color = Color(0xFF0E223A),
                                        topLeft = Offset(x * cellW, y * cellH),
                                        size = Size(cellW + 0.5f, cellH + 0.5f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        if (isDemonstration) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = TexasRailPalette.BurntOrange,
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = demoDisclaimer,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
    }
}
