package com.example.feature.tickets

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.database.PreferencesRepository
import com.example.core.model.Booking
import com.example.core.model.BookingProvider
import com.example.core.model.BookingStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class TicketsViewModel @Inject constructor(
    private val bookingProvider: BookingProvider,
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    val bookings: StateFlow<List<Booking>> = preferencesRepository.preferencesFlow
        .flatMapLatest { prefs -> bookingProvider.observeBookings(prefs.userProfile.userId) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun requestRefund(booking: Booking) {
        if (!booking.fareConditionSnapshot.exchangeAllowed && booking.fareConditionSnapshot.refundFeePercent >= 100) {
            _statusMessage.value = "This fare class is non-refundable."
            return
        }
        viewModelScope.launch {
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            bookingProvider.requestRefund(userId, booking.id, "Passenger requested cancellation")
                .onSuccess { refund ->
                    _statusMessage.value = "Refund processed for ${booking.referenceCode} (${com.example.core.time.TexasRailTime.formatMoneyExact(refund.amount)})."
                }
                .onFailure { err ->
                    _statusMessage.value = err.message ?: "Refund unavailable."
                }
        }
    }

    fun clearMessage() {
        _statusMessage.value = null
    }
}
