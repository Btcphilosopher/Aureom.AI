package com.example.core.model

import kotlinx.coroutines.flow.Flow
import java.time.Instant
import java.time.LocalDate

interface NetworkProvider {
    fun observeOperatingMode(): Flow<OperatingMode>
    fun observeDatasetVersion(): Flow<DatasetVersion?>
    suspend fun setOperatingMode(mode: OperatingMode, connectedBaseUrl: String?)
    suspend fun refreshSnapshot(force: Boolean = false): Result<DatasetVersion>
}

interface TimetableProvider {
    fun observeStations(): Flow<List<Station>>
    fun observeRoutes(): Flow<List<Route>>
    fun observeRoutePatterns(): Flow<List<RoutePattern>>
    suspend fun getStation(stationId: String): Station?
    suspend fun searchJourneys(query: JourneySearchQuery): List<JourneyOption>
}

interface RealtimeProvider {
    suspend fun getDepartures(stationId: String, date: LocalDate): DepartureBoardResult
}

data class DepartureBoardResult(
    val station: Station,
    val operatingMode: OperatingMode,
    val isLiveTelemetryAvailable: Boolean,
    val refreshedAt: Instant,
    val entries: List<DepartureBoardEntry>
)

interface FareProvider {
    suspend fun getFareOffer(
        tripIds: List<String>,
        serviceDate: LocalDate,
        passengerCount: Int,
        fareClass: String = "Standard"
    ): FareOffer?

    suspend fun getSeatMap(tripId: String, serviceDate: LocalDate): List<CoachSeatState>
}

data class CoachSeatState(
    val coach: String,
    val seatNumber: String,
    val isWindow: Boolean,
    val isAccessibleSpace: Boolean,
    val isOccupied: Boolean
)

interface BookingProvider {
    fun observeBookings(userId: String): Flow<List<Booking>>
    suspend fun getBooking(bookingId: String, userId: String): Booking?
    suspend fun createReservation(
        userId: String,
        idempotencyKey: String,
        journey: JourneyOption,
        serviceDate: LocalDate,
        passengerCount: Int,
        requestedSeats: List<String>
    ): Result<InventoryReservation>

    suspend fun confirmBooking(
        userId: String,
        reservationId: String,
        paymentId: String,
        passengers: List<Passenger>,
        seats: List<SeatAssignment>,
        journey: JourneyOption
    ): Result<Booking>

    suspend fun requestRefund(userId: String, bookingId: String, reason: String): Result<Refund>
}

interface PaymentProvider {
    suspend fun initializeSandboxPayment(
        reservation: InventoryReservation,
        idempotencyKey: String,
        paymentMethodToken: String,
        simulationOutcome: SandboxPaymentOutcome
    ): Result<Payment>

    suspend fun processWebhookEvent(
        eventId: String,
        paymentId: String,
        eventType: String
    ): Result<PaymentStatus>
}

enum class SandboxPaymentOutcome {
    SUCCEED,
    FAIL_DECLINED,
    CANCELLED_BY_USER,
    DUPLICATE_WEBHOOK_SUCCEED
}

interface TicketIssuer {
    suspend fun issueTicket(
        bookingId: String,
        referenceCode: String,
        operatingMode: OperatingMode
    ): Result<Ticket>
}

interface AlertProvider {
    fun observeAlerts(): Flow<List<ServiceAlert>>
    suspend fun getAlertsForStation(stationId: String): List<ServiceAlert>
}
