package com.example.core.database

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.model.OperatingMode
import com.example.core.model.ThemePreference
import com.example.core.model.UserProfile
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "texas_rail_prefs")

data class AppPreferences(
    val operatingMode: OperatingMode = OperatingMode.CONCEPT_DEMONSTRATION,
    val connectedBaseUrl: String = "http://10.0.2.2:8080/",
    val connectedTicketingAuthorized: Boolean = false,
    val themePreference: ThemePreference = ThemePreference.SYSTEM,
    val languageCode: String = "en-US",
    val delayAlertsEnabled: Boolean = true,
    val tripRemindersEnabled: Boolean = true,
    val userProfile: UserProfile = UserProfile(
        userId = GUEST_USER_ID,
        email = "",
        displayName = "Guest Traveler",
        isSignedIn = false
    )
) {
    companion object {
        const val GUEST_USER_ID = "guest_local"
    }
}

@Singleton
class PreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val tokenStore: EncryptedTokenStore
) {
    private object Keys {
        val OPERATING_MODE = stringPreferencesKey("operating_mode")
        val CONNECTED_URL = stringPreferencesKey("connected_base_url")
        val CONNECTED_TICKETING_AUTH = booleanPreferencesKey("connected_ticketing_auth")
        val THEME_PREF = stringPreferencesKey("theme_pref")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val DELAY_ALERTS = booleanPreferencesKey("delay_alerts")
        val TRIP_REMINDERS = booleanPreferencesKey("trip_reminders")
        val USER_ID = stringPreferencesKey("user_id")
        val USER_EMAIL = stringPreferencesKey("user_email")
        val USER_NAME = stringPreferencesKey("user_name")
        val USER_SIGNED_IN = booleanPreferencesKey("user_signed_in")
    }

    val preferencesFlow: Flow<AppPreferences> = context.dataStore.data.map { prefs ->
        val mode = prefs[Keys.OPERATING_MODE]?.let {
            runCatching { OperatingMode.valueOf(it) }.getOrNull()
        } ?: OperatingMode.CONCEPT_DEMONSTRATION
        val theme = prefs[Keys.THEME_PREF]?.let {
            runCatching { ThemePreference.valueOf(it) }.getOrNull()
        } ?: ThemePreference.SYSTEM
        val signedIn = prefs[Keys.USER_SIGNED_IN] ?: false
        val userId = if (signedIn) (prefs[Keys.USER_ID] ?: AppPreferences.GUEST_USER_ID) else AppPreferences.GUEST_USER_ID

        AppPreferences(
            operatingMode = mode,
            connectedBaseUrl = prefs[Keys.CONNECTED_URL] ?: "http://10.0.2.2:8080/",
            connectedTicketingAuthorized = prefs[Keys.CONNECTED_TICKETING_AUTH] ?: false,
            themePreference = theme,
            languageCode = prefs[Keys.LANGUAGE_CODE] ?: "en-US",
            delayAlertsEnabled = prefs[Keys.DELAY_ALERTS] ?: true,
            tripRemindersEnabled = prefs[Keys.TRIP_REMINDERS] ?: true,
            userProfile = UserProfile(
                userId = userId,
                email = prefs[Keys.USER_EMAIL].orEmpty(),
                displayName = prefs[Keys.USER_NAME] ?: "Guest Traveler",
                isSignedIn = signedIn
            )
        )
    }

    suspend fun setOperatingMode(mode: OperatingMode, baseUrl: String?, ticketingAuthorized: Boolean = false) {
        context.dataStore.edit { prefs ->
            prefs[Keys.OPERATING_MODE] = mode.name
            if (!baseUrl.isNullOrBlank()) {
                prefs[Keys.CONNECTED_URL] = baseUrl.trim()
            }
            prefs[Keys.CONNECTED_TICKETING_AUTH] = ticketingAuthorized
        }
    }

    suspend fun setThemePreference(theme: ThemePreference) {
        context.dataStore.edit { it[Keys.THEME_PREF] = theme.name }
    }

    suspend fun setLanguageCode(code: String) {
        context.dataStore.edit { it[Keys.LANGUAGE_CODE] = code }
    }

    suspend fun setNotificationPreferences(delayAlerts: Boolean, tripReminders: Boolean) {
        context.dataStore.edit {
            it[Keys.DELAY_ALERTS] = delayAlerts
            it[Keys.TRIP_REMINDERS] = tripReminders
        }
    }

    suspend fun signIn(userId: String, email: String, displayName: String, sessionToken: String) {
        tokenStore.saveSessionToken(sessionToken)
        context.dataStore.edit {
            it[Keys.USER_ID] = userId
            it[Keys.USER_EMAIL] = email
            it[Keys.USER_NAME] = displayName
            it[Keys.USER_SIGNED_IN] = true
        }
    }

    suspend fun signOut() {
        tokenStore.clearSessionToken()
        context.dataStore.edit {
            it[Keys.USER_ID] = AppPreferences.GUEST_USER_ID
            it[Keys.USER_EMAIL] = ""
            it[Keys.USER_NAME] = "Guest Traveler"
            it[Keys.USER_SIGNED_IN] = false
        }
    }
}
