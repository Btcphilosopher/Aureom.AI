package com.example.feature.booking

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.database.PreferencesRepository
import com.example.core.database.SavedPassengerEntity
import com.example.core.database.UserLibraryDao
import com.example.core.model.Booking
import com.example.core.model.BookingProvider
import com.example.core.model.CoachSeatState
import com.example.core.model.FareProvider
import com.example.core.model.InventoryReservation
import com.example.core.model.JourneyLeg
import com.example.core.model.JourneyOption
import com.example.core.model.Passenger
import com.example.core.model.PassengerType
import com.example.core.model.PaymentProvider
import com.example.core.model.PaymentStatus
import com.example.core.model.SandboxPaymentOutcome
import com.example.core.model.SeatAssignment
import com.example.data.timetables.DatabaseMappers.toDomain
import com.example.feature.search.SearchSessionStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

enum class BookingStep {
    PASSENGERS,
    SEATS,
    REVIEW_AND_PAY,
    CONFIRMED
}

data class BookingUiState(
    val step: BookingStep = BookingStep.PASSENGERS,
    val journey: JourneyOption? = null,
    val passengerCount: Int = 1,
    val passengers: List<Passenger> = listOf(Passenger(id = "p_1", fullName = "", passengerType = PassengerType.ADULT)),
    val savedPassengers: List<Passenger> = emptyList(),
    val seatMap: List<CoachSeatState> = emptyList(),
    val selectedSeats: List<String> = emptyList(),
    val reservation: InventoryReservation? = null,
    val selectedToken: String = "tok_sandbox_visa_4242",
    val sandboxOutcome: SandboxPaymentOutcome = SandboxPaymentOutcome.SUCCEED,
    val confirmedBooking: Booking? = null,
    val isBusy: Boolean = false,
    val errorMessage: String? = null,
    val connectedTicketingAuthorized: Boolean = false
)

@HiltViewModel
class BookingViewModel @Inject constructor(
    private val searchSessionStore: SearchSessionStore,
    private val fareProvider: FareProvider,
    private val bookingProvider: BookingProvider,
    private val paymentProvider: PaymentProvider,
    private val preferencesRepository: PreferencesRepository,
    private val userLibraryDao: UserLibraryDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(BookingUiState())
    val uiState: StateFlow<BookingUiState> = _uiState.asStateFlow()

    private var reservationIdempotencyKey: String = UUID.randomUUID().toString()
    private var paymentIdempotencyKey: String = UUID.randomUUID().toString()

    fun initialize(journeyId: String) {
        val journey = searchSessionStore.findJourneyById(journeyId)
        val query = searchSessionStore.query.value
        val paxCount = query.passengerCount
        val initialPassengers = (1..paxCount).map { idx ->
            Passenger(id = "p_$idx", fullName = "", passengerType = PassengerType.ADULT)
        }
        reservationIdempotencyKey = UUID.randomUUID().toString()
        paymentIdempotencyKey = UUID.randomUUID().toString()

        viewModelScope.launch {
            val prefs = preferencesRepository.preferencesFlow.first()
            val saved = userLibraryDao.observeSavedPassengers(prefs.userProfile.userId).first().map { it.toDomain() }
            val firstTripId = journey?.legs?.filterIsInstance<JourneyLeg.RailRide>()?.firstOrNull()?.trip?.id
            val seatMap = if (firstTripId != null) {
                fareProvider.getSeatMap(firstTripId, query.serviceDate)
            } else {
                emptyList()
            }
            _uiState.value = BookingUiState(
                step = BookingStep.PASSENGERS,
                journey = journey,
                passengerCount = paxCount,
                passengers = initialPassengers,
                savedPassengers = saved,
                seatMap = seatMap,
                connectedTicketingAuthorized = prefs.connectedTicketingAuthorized
            )
        }
    }

    fun updatePassenger(index: Int, fullName: String, email: String, type: PassengerType, notes: String) {
        val list = _uiState.value.passengers.toMutableList()
        if (index in list.indices) {
            list[index] = list[index].copy(
                fullName = fullName,
                email = email,
                passengerType = type,
                accessibilityNotes = notes
            )
            _uiState.value = _uiState.value.copy(passengers = list, errorMessage = null)
        }
    }

    fun applySavedPassenger(index: Int, saved: Passenger) {
        val list = _uiState.value.passengers.toMutableList()
        if (index in list.indices) {
            list[index] = saved.copy(id = list[index].id)
            _uiState.value = _uiState.value.copy(passengers = list, errorMessage = null)
        }
    }

    fun proceedToSeats() {
        val pax = _uiState.value.passengers
        val invalid = pax.any { it.fullName.trim().length < 2 }
        if (invalid) {
            _uiState.value = _uiState.value.copy(errorMessage = "Enter a full name (at least 2 characters) for each passenger.")
            return
        }
        // Optionally persist first passenger if email provided
        viewModelScope.launch {
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            val first = pax.firstOrNull()
            if (first != null && first.fullName.isNotBlank()) {
                userLibraryDao.upsertSavedPassenger(
                    SavedPassengerEntity(
                        id = "sp_${first.fullName.trim().lowercase().replace(" ", "_")}",
                        userId = userId,
                        fullName = first.fullName.trim(),
                        passengerType = first.passengerType.name,
                        email = first.email.trim(),
                        accessibilityNotes = first.accessibilityNotes.trim()
                    )
                )
            }
        }
        _uiState.value = _uiState.value.copy(step = BookingStep.SEATS, errorMessage = null)
    }

    fun toggleSeat(seatNumber: String) {
        val current = _uiState.value.selectedSeats.toMutableList()
        if (seatNumber in current) {
            current.remove(seatNumber)
        } else {
            if (current.size >= _uiState.value.passengerCount) {
                current.removeAt(0)
            }
            current.add(seatNumber)
        }
        _uiState.value = _uiState.value.copy(selectedSeats = current, errorMessage = null)
    }

    fun reserveAndProceedToReview() {
        val journey = _uiState.value.journey ?: return
        val query = searchSessionStore.query.value
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true, errorMessage = null)
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            val resResult = bookingProvider.createReservation(
                userId = userId,
                idempotencyKey = reservationIdempotencyKey,
                journey = journey,
                serviceDate = query.serviceDate,
                passengerCount = _uiState.value.passengerCount,
                requestedSeats = _uiState.value.selectedSeats
            )
            resResult.onSuccess { reservation ->
                _uiState.value = _uiState.value.copy(
                    isBusy = false,
                    reservation = reservation,
                    step = BookingStep.REVIEW_AND_PAY
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isBusy = false,
                    errorMessage = err.message ?: "Unable to hold seats."
                )
            }
        }
    }

    fun selectPaymentToken(token: String) {
        _uiState.value = _uiState.value.copy(selectedToken = token, errorMessage = null)
    }

    fun selectSandboxOutcome(outcome: SandboxPaymentOutcome) {
        _uiState.value = _uiState.value.copy(sandboxOutcome = outcome, errorMessage = null)
    }

    fun goBackStep() {
        val next = when (_uiState.value.step) {
            BookingStep.SEATS -> BookingStep.PASSENGERS
            BookingStep.REVIEW_AND_PAY -> BookingStep.SEATS
            else -> null
        }
        if (next != null) {
            _uiState.value = _uiState.value.copy(step = next, errorMessage = null)
        }
    }

    fun submitPaymentAndConfirm() {
        val reservation = _uiState.value.reservation ?: return
        val journey = _uiState.value.journey ?: return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true, errorMessage = null)
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            // Generate a fresh payment idempotency key on retry after failure/cancel
            val payRes = paymentProvider.initializeSandboxPayment(
                reservation = reservation,
                idempotencyKey = paymentIdempotencyKey,
                paymentMethodToken = _uiState.value.selectedToken,
                simulationOutcome = _uiState.value.sandboxOutcome
            )

            payRes.onFailure { err ->
                paymentIdempotencyKey = UUID.randomUUID().toString()
                _uiState.value = _uiState.value.copy(isBusy = false, errorMessage = err.message ?: "Payment failed")
                return@launch
            }

            val payment = payRes.getOrThrow()
            if (payment.status != PaymentStatus.SUCCEEDED) {
                paymentIdempotencyKey = UUID.randomUUID().toString()
                _uiState.value = _uiState.value.copy(
                    isBusy = false,
                    errorMessage = when (payment.status) {
                        PaymentStatus.FAILED -> "Sandbox card declined (simulated). Switch outcome to Standard Approval to complete demo."
                        PaymentStatus.CANCELLED -> "Checkout was cancelled before authorization. Reservation hold remains active until expiry."
                        else -> "Payment not settled (${payment.status})."
                    }
                )
                return@launch
            }

            val seatAssignments = if (_uiState.value.selectedSeats.isNotEmpty()) {
                _uiState.value.selectedSeats.mapIndexed { idx, s ->
                    val seatInfo = _uiState.value.seatMap.firstOrNull { it.seatNumber == s }
                    SeatAssignment("seg_$idx", seatInfo?.coach ?: "Coach 1", s, seatInfo?.isAccessibleSpace == true)
                }
            } else {
                reservation.requestedSeats.mapIndexed { idx, s ->
                    SeatAssignment("seg_$idx", "Coach 1", s, false)
                }
            }

            val confirmRes = bookingProvider.confirmBooking(
                userId = userId,
                reservationId = reservation.id,
                paymentId = payment.id,
                passengers = _uiState.value.passengers,
                seats = seatAssignments,
                journey = journey
            )
            confirmRes.onSuccess { booking ->
                _uiState.value = _uiState.value.copy(
                    isBusy = false,
                    confirmedBooking = booking,
                    step = BookingStep.CONFIRMED
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isBusy = false,
                    errorMessage = err.message ?: "Confirmation error"
                )
            }
        }
    }
}
