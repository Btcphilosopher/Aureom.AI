package com.example.feature.map

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.FormatListBulleted
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DirectionsTransit
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.PlusJakartaSansFamily
import com.example.core.designsystem.SectionHeadingWithAccent
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.CorridorPattern
import com.example.core.model.OperatingMode
import com.example.core.model.Route
import com.example.core.model.RoutePattern
import com.example.core.model.Station
import com.example.core.time.TexasRailTime
import kotlin.math.hypot

@Composable
fun MapScreen(
    viewModel: MapViewModel,
    onViewJourneys: (originId: String, destinationId: String, dateIso: String, paxCount: Int) -> Unit,
    onOpenStationDetails: (stationId: String) -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val tokens = LocalTexasRailTokens.current

    val stationsById = remember(state.stations) { state.stations.associateBy { it.id } }
    val routesById = remember(state.routes) { state.routes.associateBy { it.id } }
    val originStation = stationsById[state.query.originStationId]
    val destStation = stationsById[state.query.destinationStationId]

    val filteredStations = remember(state.stations, state.searchQuery) {
        if (state.searchQuery.isBlank()) state.stations
        else state.stations.filter {
            it.name.contains(state.searchQuery, ignoreCase = true) ||
                it.code.contains(state.searchQuery, ignoreCase = true)
        }
    }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        TexasRailTopBar(operatingMode = state.operatingMode)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 820.dp)
                .align(Alignment.CenterHorizontally)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            SectionHeadingWithAccent(
                title = "Explore Texas",
                trailing = {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (state.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                                "Concept network"
                            } else {
                                "Operator network"
                            },
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Medium
                            ),
                            color = tokens.secondaryInk
                        )
                        state.datasetVersion?.let { ver ->
                            Text(
                                text = "Offline • ${TexasRailTime.formatRefreshTimestamp(ver.lastSyncedAt)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.secondaryInk
                            )
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Search + Mode toggles (Schematic vs Geographic, Map vs Accessible List)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = state.searchQuery,
                    onValueChange = viewModel::updateSearchQuery,
                    placeholder = { Text("Find station...", maxLines = 1) },
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                    trailingIcon = {
                        if (state.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Outlined.Close, contentDescription = "Clear station search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("map_station_search")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = !state.showAccessibleList && state.coordinateMode == MapCoordinateMode.SCHEMATIC,
                    onClick = {
                        viewModel.setShowAccessibleList(false)
                        viewModel.setCoordinateMode(MapCoordinateMode.SCHEMATIC)
                    },
                    label = { Text("Schematic") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = tokens.accentSoft,
                        selectedLabelColor = tokens.accentOrange
                    ),
                    modifier = Modifier.testTag("map_mode_schematic")
                )
                FilterChip(
                    selected = !state.showAccessibleList && state.coordinateMode == MapCoordinateMode.GEOGRAPHIC,
                    onClick = {
                        viewModel.setShowAccessibleList(false)
                        viewModel.setCoordinateMode(MapCoordinateMode.GEOGRAPHIC)
                    },
                    label = { Text("Geographic") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = tokens.accentSoft,
                        selectedLabelColor = tokens.accentOrange
                    ),
                    modifier = Modifier.testTag("map_mode_geographic")
                )
                FilterChip(
                    selected = state.showAccessibleList,
                    onClick = { viewModel.setShowAccessibleList(!state.showAccessibleList) },
                    leadingIcon = {
                        Icon(
                            imageVector = if (state.showAccessibleList) Icons.Outlined.Map else Icons.AutoMirrored.Outlined.FormatListBulleted,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = { Text("Station list") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = tokens.accentSoft,
                        selectedLabelColor = tokens.accentOrange
                    ),
                    modifier = Modifier.testTag("map_accessible_list_toggle")
                )
            }

            // If user typed a search query and map is open, show quick jump results
            if (!state.showAccessibleList && state.searchQuery.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = tokens.cardSurface,
                    border = BorderStroke(1.dp, tokens.divider),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        filteredStations.take(4).forEach { st ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .pointerInput(st.id) {
                                        detectTapGestures {
                                            viewModel.selectStation(st.id)
                                            viewModel.updateSearchQuery("")
                                        }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${st.name} (${st.code})", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    TexasRailTime.shortZoneLabel(java.time.Instant.now(), st.timeZoneId),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tokens.secondaryInk
                                )
                            }
                        }
                    }
                }
            }

            if (state.showAccessibleList) {
                // Screen-reader-friendly station list alternative
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .testTag("map_station_list"),
                    contentPadding = PaddingValues(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredStations, key = { it.id }) { station ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = tokens.cardSurface,
                            border = BorderStroke(1.dp, tokens.divider),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${station.name} (${station.code})",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = tokens.primaryInk
                                        )
                                        Text(
                                            text = "${station.address} • ${TexasRailTime.accessibleZoneName(station.timeZoneId)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = tokens.secondaryInk
                                        )
                                    }
                                    OutlinedButton(onClick = { onOpenStationDetails(station.id) }) {
                                        Text("Details")
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { viewModel.planFrom(station.id) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Plan from here")
                                    }
                                    Button(
                                        onClick = { viewModel.planTo(station.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Plan to here")
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Interactive Vector Texas Rail Map
                BoxWithConstraints(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clipToBounds()
                ) {
                    val density = LocalDensity.current
                    val widthPx = with(density) { maxWidth.toPx() }
                    val heightPx = with(density) { maxHeight.toPx() }
                    val textMeasurer = rememberTextMeasurer()

                    val selectedOriginId = state.query.originStationId
                    val selectedDestId = state.query.destinationStationId

                    val stationOffsets = remember(
                        state.stations,
                        state.coordinateMode,
                        widthPx,
                        heightPx
                    ) {
                        state.stations.associate { st ->
                            st.id to projectStationOffset(st, state.coordinateMode, widthPx, heightPx)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val newScale = (scale * zoom).coerceIn(1f, 2.8f)
                                    scale = newScale
                                    if (newScale > 1.02f) {
                                        val maxPanX = (widthPx * (newScale - 1f)) / 2f
                                        val maxPanY = (heightPx * (newScale - 1f)) / 2f
                                        offsetX = (offsetX + pan.x).coerceIn(-maxPanX, maxPanX)
                                        offsetY = (offsetY + pan.y).coerceIn(-maxPanY, maxPanY)
                                    } else {
                                        offsetX = 0f
                                        offsetY = 0f
                                    }
                                }
                            }
                            .pointerInput(stationOffsets, scale, offsetX, offsetY) {
                                detectTapGestures { tap ->
                                    // Convert screen tap into un-transformed canvas coordinates
                                    val cx = widthPx / 2f
                                    val cy = heightPx / 2f
                                    val canvasTap = Offset(
                                        x = (tap.x - cx - offsetX) / scale + cx,
                                        y = (tap.y - cy - offsetY) / scale + cy
                                    )
                                    val hit = stationOffsets.entries.minByOrNull { (_, pos) ->
                                        hypot(pos.x - canvasTap.x, pos.y - canvasTap.y)
                                    }
                                    if (hit != null && hypot(hit.value.x - canvasTap.x, hit.value.y - canvasTap.y) < 56f) {
                                        viewModel.selectStation(hit.key)
                                    } else {
                                        viewModel.selectStation(null)
                                    }
                                }
                            }
                            .semantics {
                                contentDescription = "Interactive Texas Rail ${state.coordinateMode.name.lowercase()} network map showing Dallas, Fort Worth, Austin, San Antonio, Houston, El Paso, Amarillo, and Corpus Christi."
                            }
                    ) {
                        TexasVectorMapCanvas(
                            stations = state.stations,
                            routesById = routesById,
                            patterns = state.patterns,
                            stationOffsets = stationOffsets,
                            selectedOriginId = selectedOriginId,
                            selectedDestId = selectedDestId,
                            highlightedStationId = state.selectedStation?.id,
                            coordinateMode = state.coordinateMode,
                            textMeasurer = textMeasurer,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    scaleX = scale
                                    scaleY = scale
                                    translationX = offsetX
                                    translationY = offsetY
                                }
                        )

                        // Accessible zoom controls
                        Column(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = tokens.cardSurface.copy(alpha = 0.94f),
                                border = BorderStroke(1.dp, tokens.divider)
                            ) {
                                Column {
                                    IconButton(
                                        onClick = { scale = (scale + 0.4f).coerceAtMost(2.8f) },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(Icons.Filled.Add, contentDescription = "Zoom in map", tint = tokens.primaryInk)
                                    }
                                    IconButton(
                                        onClick = {
                                            scale = (scale - 0.4f).coerceAtLeast(1f)
                                            if (scale <= 1.05f) {
                                                offsetX = 0f
                                                offsetY = 0f
                                            }
                                        },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(Icons.Filled.Remove, contentDescription = "Zoom out map", tint = tokens.primaryInk)
                                    }
                                    IconButton(
                                        onClick = {
                                            scale = 1f
                                            offsetX = 0f
                                            offsetY = 0f
                                        },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(Icons.Outlined.MyLocation, contentDescription = "Reset map zoom", tint = tokens.accentOrange)
                                    }
                                }
                            }
                        }
                    }
                }

                // Line Legend (with non-color solid/dashed/dotted indicators)
                val selectedRouteLabel = "${originStation?.name ?: "Origin"} – ${destStation?.name ?: "Destination"} (selected)"
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    LegendRow(
                        label = selectedRouteLabel,
                        isOrangeLine = true,
                        isDashed = false,
                        isRing = false
                    )
                    LegendRow(
                        label = "Other passenger routes (solid / dashed / dotted by corridor)",
                        isOrangeLine = false,
                        isDashed = true,
                        isRing = false
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        LegendRow(label = "Station (major city)", isOrangeLine = false, isDashed = false, isRing = true, ringLarge = true)
                        LegendRow(label = "Station (other)", isOrangeLine = false, isDashed = false, isRing = true, ringLarge = false)
                    }
                    if (state.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Info, contentDescription = null, tint = tokens.secondaryInk, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Schematic corridor lines illustrate proposed concepts, not active rail operations.",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.secondaryInk
                            )
                        }
                    }
                }
            }

            // Selected station quick action popup card (when user taps a city on the map)
            state.selectedStation?.let { picked ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.cardSurface,
                    shadowElevation = 4.dp,
                    border = BorderStroke(1.5.dp, tokens.accentOrange),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .testTag("map_selected_station_card")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${picked.name} (${picked.code})",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = tokens.primaryInk
                                )
                                Text(
                                    text = "${picked.address} • ${TexasRailTime.accessibleZoneName(picked.timeZoneId)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.secondaryInk
                                )
                            }
                            IconButton(onClick = { viewModel.selectStation(null) }) {
                                Icon(Icons.Outlined.Close, contentDescription = "Close station card")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.planFrom(picked.id) },
                                modifier = Modifier.weight(1f).testTag("map_plan_from_here")
                            ) {
                                Text("Plan from here", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Button(
                                onClick = { viewModel.planTo(picked.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                                modifier = Modifier.weight(1f).testTag("map_plan_to_here")
                            ) {
                                Text("Plan to here", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = { onOpenStationDetails(picked.id) },
                            modifier = Modifier.fillMaxWidth().testTag("map_open_station_details")
                        ) {
                            Text("Station facilities, departures & alerts")
                        }
                    }
                }
            }

            // Bottom Floating Route Bar matching reference
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                shadowElevation = 3.dp,
                border = BorderStroke(1.dp, tokens.divider),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DirectionsTransit,
                        contentDescription = null,
                        tint = tokens.primaryInk,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "${originStation?.name ?: "Dallas"} → ${destStation?.name ?: "Austin"}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = tokens.primaryInk,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Button(
                        onClick = {
                            onViewJourneys(
                                state.query.originStationId,
                                state.query.destinationStationId,
                                state.query.serviceDate.toString(),
                                state.query.passengerCount
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = tokens.accentOrange,
                            contentColor = tokens.onAccentOrange
                        ),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("map_view_journeys_button")
                    ) {
                        Text(
                            text = "View journeys",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TexasVectorMapCanvas(
    stations: List<Station>,
    routesById: Map<String, Route>,
    patterns: List<RoutePattern>,
    stationOffsets: Map<String, Offset>,
    selectedOriginId: String,
    selectedDestId: String,
    highlightedStationId: String?,
    coordinateMode: MapCoordinateMode,
    textMeasurer: TextMeasurer,
    modifier: Modifier = Modifier
) {
    val tokens = LocalTexasRailTokens.current
    val labelStyle = TextStyle(
        fontFamily = PlusJakartaSansFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = tokens.primaryInk
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Draw authentic Texas outline polygon
        val txPath = buildTexasOutlinePath(w, h)
        drawPath(path = txPath, color = tokens.mapLandFill)
        drawPath(
            path = txPath,
            color = tokens.mapLandOutline,
            style = Stroke(width = 2.dp.toPx(), join = StrokeJoin.Round)
        )

        // Draw non-selected corridors first with distinct dash/dot patterns for accessibility
        val drawnPairs = mutableSetOf<Pair<String, String>>()
        patterns.forEach { pattern ->
            val route = routesById[pattern.routeId]
            val seq = pattern.stationSequence
            val dashEffect = when (route?.corridorPattern) {
                CorridorPattern.DASHED -> PathEffect.dashPathEffect(floatArrayOf(16f, 10f), 0f)
                CorridorPattern.DOTTED -> PathEffect.dashPathEffect(floatArrayOf(5f, 9f), 0f)
                else -> null
            }
            for (i in 0 until seq.lastIndex) {
                val a = seq[i]
                val b = seq[i + 1]
                val edgeKey = if (a < b) a to b else b to a
                if (!drawnPairs.add(edgeKey)) continue
                val p1 = stationOffsets[a] ?: continue
                val p2 = stationOffsets[b] ?: continue
                drawLine(
                    color = tokens.mapSecondaryRoute,
                    start = p1,
                    end = p2,
                    strokeWidth = 2.6.dp.toPx(),
                    cap = StrokeCap.Round,
                    pathEffect = dashEffect
                )
            }
        }

        // Highlight selected origin -> destination corridor in vibrant burnt orange
        val origPos = stationOffsets[selectedOriginId]
        val destPos = stationOffsets[selectedDestId]
        if (origPos != null && destPos != null) {
            // Find if there is a multi-stop pattern containing both, else draw direct corridor highlight
            val matchingSeq = patterns.firstOrNull { p ->
                val i1 = p.stationSequence.indexOf(selectedOriginId)
                val i2 = p.stationSequence.indexOf(selectedDestId)
                i1 >= 0 && i2 >= 0
            }?.let { p ->
                val i1 = p.stationSequence.indexOf(selectedOriginId)
                val i2 = p.stationSequence.indexOf(selectedDestId)
                if (i1 <= i2) p.stationSequence.subList(i1, i2 + 1)
                else p.stationSequence.subList(i2, i1 + 1).reversed()
            } ?: listOf(selectedOriginId, selectedDestId)

            val highlightPath = Path()
            matchingSeq.forEachIndexed { idx, stId ->
                val pt = stationOffsets[stId] ?: return@forEachIndexed
                if (idx == 0) highlightPath.moveTo(pt.x, pt.y) else highlightPath.lineTo(pt.x, pt.y)
            }
            drawPath(
                path = highlightPath,
                color = tokens.accentOrange.copy(alpha = 0.28f),
                style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawPath(
                path = highlightPath,
                color = tokens.accentOrange,
                style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }

        // Draw station nodes & labels
        stations.forEach { station ->
            val pos = stationOffsets[station.id] ?: return@forEach
            val isEndpoint = station.id == selectedOriginId || station.id == selectedDestId
            val isHighlighted = station.id == highlightedStationId
            val radius = when {
                isEndpoint || isHighlighted -> 8.dp.toPx()
                station.isMajorCity -> 5.5.dp.toPx()
                else -> 3.8.dp.toPx()
            }

            if (isEndpoint) {
                drawCircle(
                    color = tokens.accentOrange.copy(alpha = 0.24f),
                    radius = radius + 6.dp.toPx(),
                    center = pos
                )
            }
            drawCircle(color = tokens.cardSurface, radius = radius, center = pos)
            drawCircle(
                color = when {
                    isEndpoint -> tokens.accentOrange
                    isHighlighted -> tokens.accentOrange
                    else -> tokens.primaryInk
                },
                radius = radius,
                center = pos,
                style = Stroke(width = if (isEndpoint) 3.dp.toPx() else 2.2.dp.toPx())
            )

            // Draw city labels for major cities (plus highlighted station)
            if (station.isMajorCity || isHighlighted) {
                val measured = textMeasurer.measure(station.name, style = labelStyle)
                val labelOffset = labelOffsetForStation(station.code, pos, measured.size.width.toFloat(), measured.size.height.toFloat(), w)
                drawText(
                    textLayoutResult = measured,
                    topLeft = labelOffset
                )
            }
        }
    }
}

private fun labelOffsetForStation(
    code: String,
    pos: Offset,
    textW: Float,
    textH: Float,
    canvasW: Float
): Offset {
    return when (code) {
        "AMA" -> Offset(pos.x + 8f, pos.y - textH - 6f)
        "ELP" -> Offset((pos.x - 6f).coerceAtLeast(4f), pos.y - textH - 12f)
        "FTW" -> Offset(pos.x - textW - 12f, pos.y - textH / 2f)
        "DAL" -> Offset((pos.x + 14f).coerceAtMost(canvasW - textW - 4f), pos.y - textH / 2f)
        "AUS" -> Offset(pos.x + 12f, pos.y - textH / 2f)
        "SAT" -> Offset(pos.x - textW - 12f, pos.y - 4f)
        "HOU" -> Offset((pos.x + 10f).coerceAtMost(canvasW - textW - 4f), pos.y - textH - 6f)
        "CRP" -> Offset(pos.x + 10f, pos.y - textH / 2f)
        else -> Offset(pos.x + 10f, pos.y - textH / 2f)
    }
}

private fun projectStationOffset(
    station: Station,
    mode: MapCoordinateMode,
    width: Float,
    height: Float
): Offset {
    val padX = width * 0.06f
    val padY = height * 0.06f
    val usableW = width - padX * 2f
    val usableH = height - padY * 2f

    return if (mode == MapCoordinateMode.SCHEMATIC) {
        Offset(
            x = padX + station.schematicX * usableW,
            y = padY + station.schematicY * usableH
        )
    } else {
        // Geographic equirectangular projection calibrated to Texas bounds
        val minLon = -106.7
        val maxLon = -93.4
        val minLat = 25.8
        val maxLat = 36.6
        val normX = ((station.longitude - minLon) / (maxLon - minLon)).toFloat().coerceIn(0.02f, 0.98f)
        val normY = (1.0 - ((station.latitude - minLat) / (maxLat - minLat))).toFloat().coerceIn(0.02f, 0.98f)
        Offset(
            x = padX + normX * usableW,
            y = padY + normY * usableH
        )
    }
}

private fun buildTexasOutlinePath(w: Float, h: Float): Path {
    // Normalized polygon of Texas matching the map coordinate space
    val pts = listOf(
        0.27f to 0.04f, 0.44f to 0.04f, 0.44f to 0.24f, 0.54f to 0.26f,
        0.68f to 0.28f, 0.86f to 0.30f, 0.88f to 0.44f, 0.91f to 0.57f,
        0.84f to 0.68f, 0.74f to 0.75f, 0.65f to 0.85f, 0.61f to 0.96f,
        0.54f to 0.94f, 0.49f to 0.82f, 0.41f to 0.72f, 0.32f to 0.74f,
        0.24f to 0.65f, 0.16f to 0.56f, 0.08f to 0.48f, 0.27f to 0.48f,
        0.27f to 0.04f
    )
    return Path().apply {
        pts.forEachIndexed { idx, (nx, ny) ->
            val x = nx * w
            val y = ny * h
            if (idx == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }
}

@Composable
private fun LegendRow(
    label: String,
    isOrangeLine: Boolean,
    isDashed: Boolean,
    isRing: Boolean,
    ringLarge: Boolean = true
) {
    val tokens = LocalTexasRailTokens.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier = Modifier.size(width = 30.dp, height = 14.dp)) {
            val cy = size.height / 2f
            if (isRing) {
                val r = if (ringLarge) 5.dp.toPx() else 3.2.dp.toPx()
                drawCircle(color = tokens.cardSurface, radius = r, center = Offset(size.width / 2f, cy))
                drawCircle(
                    color = tokens.primaryInk,
                    radius = r,
                    center = Offset(size.width / 2f, cy),
                    style = Stroke(width = 2.dp.toPx())
                )
            } else {
                val color = if (isOrangeLine) tokens.accentOrange else tokens.mapSecondaryRoute
                val effect = if (isDashed) PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f) else null
                drawLine(
                    color = color,
                    start = Offset(3.dp.toPx(), cy),
                    end = Offset(size.width - 3.dp.toPx(), cy),
                    strokeWidth = if (isOrangeLine) 3.5.dp.toPx() else 2.2.dp.toPx(),
                    pathEffect = effect
                )
                drawCircle(color = tokens.cardSurface, radius = 3.2.dp.toPx(), center = Offset(4.dp.toPx(), cy))
                drawCircle(color = color, radius = 3.2.dp.toPx(), center = Offset(4.dp.toPx(), cy), style = Stroke(1.8.dp.toPx()))
                drawCircle(color = tokens.cardSurface, radius = 3.2.dp.toPx(), center = Offset(size.width - 4.dp.toPx(), cy))
                drawCircle(color = color, radius = 3.2.dp.toPx(), center = Offset(size.width - 4.dp.toPx(), cy), style = Stroke(1.8.dp.toPx()))
            }
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = tokens.primaryInk,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
