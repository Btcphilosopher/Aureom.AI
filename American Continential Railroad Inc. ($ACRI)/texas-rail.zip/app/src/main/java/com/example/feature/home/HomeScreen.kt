package com.example.feature.home

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.DirectionsTransit
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.OperatingModeBanner
import com.example.core.designsystem.PlusJakartaSansFamily
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.Station
import com.example.core.time.TexasRailTime
import java.time.Instant
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onFindTrains: (originId: String, destinationId: String, dateIso: String, passengerCount: Int) -> Unit,
    onOpenTickets: () -> Unit,
    onOpenDepartures: (stationId: String) -> Unit,
    onOpenSavedTripsSheet: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val tokens = LocalTexasRailTokens.current
    val context = LocalContext.current

    var pickingOrigin by remember { mutableStateOf(false) }
    var pickingDestination by remember { mutableStateOf(false) }
    var pickingDate by remember { mutableStateOf(false) }
    var pickingPassengers by remember { mutableStateOf(false) }
    var showSavedTripsModal by remember { mutableStateOf(false) }
    var locationNotice by remember { mutableStateOf<String?>(null) }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            resolveCoarseLocation(context)?.let { (lat, lon) ->
                viewModel.selectNearestStationFromCoordinates(lat, lon)
                locationNotice = "Nearest station selected from coarse location."
            } ?: run {
                locationNotice = "Device location unavailable right now."
            }
        } else {
            locationNotice = "Location permission declined; select your station manually."
        }
    }

    val stationsById = remember(state.stations) { state.stations.associateBy { it.id } }
    val originStation = stationsById[state.query.originStationId]
    val destinationStation = stationsById[state.query.destinationStationId]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        TexasRailTopBar(
            showCornerAccent = true,
            operatingMode = state.operatingMode
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Hero photo with "Where to next?" headline and burnt-orange underline
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(248.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_texas_rail),
                    contentDescription = "Silver, navy, and burnt-orange Texas Rail passenger train traveling through Texas Hill Country",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xA60E223A),
                                    Color(0x330E223A),
                                    Color.Transparent
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                ) {
                    Text(
                        text = "Where to next?",
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontFamily = PlusJakartaSansFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 31.sp
                        ),
                        color = Color.White,
                        modifier = Modifier.semantics { heading() }
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .width(46.dp)
                            .height(4.dp)
                            .background(tokens.accentOrange, RoundedCornerShape(2.dp))
                    )
                }
            }

            // Responsive centered container for tablets and phones
            Column(
                modifier = Modifier
                    .widthIn(max = 620.dp)
                    .fillMaxWidth()
                    .offset(y = (-28).dp)
                    .padding(horizontal = 16.dp)
            ) {
                // Main Journey Search Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(tokens.radiusCard),
                    color = tokens.cardSurface,
                    shadowElevation = 4.dp,
                    border = BorderStroke(1.dp, tokens.divider)
                ) {
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        // Origin + Swap anchor
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Column {
                                SearchFieldRow(
                                    icon = Icons.Outlined.LocationOn,
                                    caption = "From",
                                    value = originStation?.name ?: "Select origin",
                                    testTag = "home_from_field",
                                    onClick = { pickingOrigin = true }
                                )
                                HorizontalDivider(
                                    color = tokens.divider,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                                SearchFieldRow(
                                    icon = Icons.Outlined.LocationOn,
                                    caption = "To",
                                    value = destinationStation?.name ?: "Select destination",
                                    testTag = "home_to_field",
                                    onClick = { pickingDestination = true }
                                )
                            }

                            Surface(
                                onClick = { viewModel.swapStations() },
                                shape = CircleShape,
                                color = tokens.cardSecondary,
                                border = BorderStroke(1.dp, tokens.divider),
                                modifier = Modifier
                                    .align(Alignment.CenterEnd)
                                    .padding(end = 42.dp)
                                    .size(40.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("home_swap_button")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.SwapVert,
                                        contentDescription = "Swap origin and destination stations",
                                        tint = tokens.primaryInk,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(
                            color = tokens.divider,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )

                        SearchFieldRow(
                            icon = Icons.Outlined.CalendarToday,
                            caption = null,
                            value = TexasRailTime.formatDateChip(state.query.serviceDate),
                            testTag = "home_date_field",
                            onClick = { pickingDate = true }
                        )

                        HorizontalDivider(
                            color = tokens.divider,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )

                        val paxCount = state.query.passengerCount
                        val paxLabel = if (paxCount == 1) "1 adult" else "$paxCount adults"
                        SearchFieldRow(
                            icon = Icons.Outlined.PersonOutline,
                            caption = null,
                            value = paxLabel,
                            testTag = "home_passengers_field",
                            onClick = { pickingPassengers = true }
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = {
                                viewModel.recordSearch()
                                onFindTrains(
                                    state.query.originStationId,
                                    state.query.destinationStationId,
                                    state.query.serviceDate.toString(),
                                    state.query.passengerCount
                                )
                            },
                            enabled = originStation != null && destinationStation != null && originStation.id != destinationStation.id,
                            shape = RoundedCornerShape(tokens.radiusButton),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = tokens.accentOrange,
                                contentColor = tokens.onAccentOrange
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .height(52.dp)
                                .testTag("find_trains_button")
                        ) {
                            Text(
                                text = "Find trains",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                fontSize = 17.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 3 Quick-Action Tiles matching reference
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HomeShortcutCard(
                        icon = Icons.Outlined.ConfirmationNumber,
                        label = "My\ntickets",
                        testTag = "shortcut_my_tickets",
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTickets
                    )
                    HomeShortcutCard(
                        icon = Icons.Outlined.DirectionsTransit,
                        label = "Live\ndepartures",
                        testTag = "shortcut_live_departures",
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenDepartures(state.query.originStationId) }
                    )
                    HomeShortcutCard(
                        icon = Icons.Outlined.StarOutline,
                        label = "Saved\ntrips",
                        testTag = "shortcut_saved_trips",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            showSavedTripsModal = true
                            onOpenSavedTripsSheet()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                val syncSuffix = state.datasetVersion?.let {
                    " • Cached ${TexasRailTime.formatRefreshTimestamp(it.lastSyncedAt)}"
                }.orEmpty()
                OperatingModeBanner(
                    operatingMode = state.operatingMode,
                    customText = if (state.operatingMode == com.example.core.model.OperatingMode.CONCEPT_DEMONSTRATION) {
                        "Concept network demonstration$syncSuffix"
                    } else {
                        "Connected operator service$syncSuffix"
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Optional coarse location helper + Save current search
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        onClick = {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                resolveCoarseLocation(context)?.let { (lat, lon) ->
                                    viewModel.selectNearestStationFromCoordinates(lat, lon)
                                    locationNotice = "Nearest station selected."
                                } ?: run {
                                    locationNotice = "Location unavailable; choose a station manually."
                                }
                            } else {
                                locationPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        color = tokens.cardSurface,
                        border = BorderStroke(1.dp, tokens.divider),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("nearest_station_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.MyLocation,
                                contentDescription = null,
                                tint = tokens.accentOrange,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Nearest station",
                                style = MaterialTheme.typography.labelLarge,
                                color = tokens.primaryInk,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Surface(
                        onClick = {
                            viewModel.saveCurrentTrip()
                            locationNotice = "Trip saved to Saved Trips."
                        },
                        shape = RoundedCornerShape(10.dp),
                        color = tokens.cardSurface,
                        border = BorderStroke(1.dp, tokens.divider),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("save_current_trip_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.BookmarkBorder,
                                contentDescription = null,
                                tint = tokens.accentOrange,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Save trip",
                                style = MaterialTheme.typography.labelLarge,
                                color = tokens.primaryInk,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                if (locationNotice != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = locationNotice!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.secondaryInk
                    )
                }

                // Recent Searches & Saved Stations
                if (state.recentSearches.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(18.dp))
                    Text(
                        text = "Recent searches",
                        style = MaterialTheme.typography.titleSmall,
                        color = tokens.primaryInk,
                        modifier = Modifier.semantics { heading() }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.recentSearches, key = { it.id }) { recent ->
                            val orig = stationsById[recent.originStationId]?.name ?: recent.originStationId
                            val dest = stationsById[recent.destinationStationId]?.name ?: recent.destinationStationId
                            Surface(
                                onClick = {
                                    viewModel.applyRecentOrSaved(
                                        recent.originStationId,
                                        recent.destinationStationId,
                                        recent.serviceDate,
                                        recent.passengerCount
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                color = tokens.cardSurface,
                                border = BorderStroke(1.dp, tokens.divider),
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.History,
                                        contentDescription = null,
                                        tint = tokens.secondaryInk,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "$orig → $dest",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = tokens.primaryInk
                                    )
                                }
                            }
                        }
                    }
                }

                if (state.savedStationIds.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Saved stations",
                        style = MaterialTheme.typography.titleSmall,
                        color = tokens.primaryInk,
                        modifier = Modifier.semantics { heading() }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.savedStationIds.toList()) { stId ->
                            val st = stationsById[stId] ?: return@items
                            Surface(
                                onClick = { viewModel.selectOrigin(st.id) },
                                shape = RoundedCornerShape(12.dp),
                                color = tokens.cardSurface,
                                border = BorderStroke(1.dp, tokens.divider),
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Star,
                                        contentDescription = null,
                                        tint = tokens.accentOrange,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${st.name} (${st.code})",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = tokens.primaryInk
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (pickingOrigin || pickingDestination) {
        StationPickerBottomSheet(
            title = if (pickingOrigin) "Select origin station" else "Select destination station",
            stations = state.stations,
            savedStationIds = state.savedStationIds,
            onToggleSavedStation = viewModel::toggleSavedStation,
            onSelect = { station ->
                if (pickingOrigin) viewModel.selectOrigin(station.id) else viewModel.selectDestination(station.id)
                pickingOrigin = false
                pickingDestination = false
            },
            onDismiss = {
                pickingOrigin = false
                pickingDestination = false
            }
        )
    }

    if (pickingDate) {
        val initialMillis = state.query.serviceDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { pickingDate = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            val picked = Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate()
                            viewModel.selectDate(picked)
                        }
                        pickingDate = false
                    }
                ) {
                    Text("Confirm", color = tokens.accentOrange)
                }
            },
            dismissButton = {
                TextButton(onClick = { pickingDate = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    if (pickingPassengers) {
        ModalBottomSheet(onDismissRequest = { pickingPassengers = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "Passengers",
                    style = MaterialTheme.typography.titleLarge,
                    color = tokens.primaryInk
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Adults (16+)", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Maximum 8 passengers per booking",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.secondaryInk
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.selectPassengerCount(state.query.passengerCount - 1) },
                            enabled = state.query.passengerCount > 1,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Filled.Remove, contentDescription = "Decrease passengers")
                        }
                        Text(
                            text = "${state.query.passengerCount}",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        IconButton(
                            onClick = { viewModel.selectPassengerCount(state.query.passengerCount + 1) },
                            enabled = state.query.passengerCount < 8,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "Increase passengers")
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = { pickingPassengers = false },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange)
                ) {
                    Text("Done")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showSavedTripsModal) {
        ModalBottomSheet(onDismissRequest = { showSavedTripsModal = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Saved Trips",
                    style = MaterialTheme.typography.titleLarge,
                    color = tokens.primaryInk
                )
                Spacer(modifier = Modifier.height(10.dp))
                if (state.savedJourneys.isEmpty()) {
                    Text(
                        text = "No saved trips yet. Use 'Save trip' on the Home screen to pin a favorite corridor.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.secondaryInk,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    state.savedJourneys.forEach { saved ->
                        Surface(
                            onClick = {
                                viewModel.applyRecentOrSaved(saved.originStationId, saved.destinationStationId)
                                showSavedTripsModal = false
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.cardSecondary,
                            border = BorderStroke(1.dp, tokens.divider),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .minimumInteractiveComponentSize()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = saved.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = tokens.primaryInk
                                )
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = "Select saved trip"
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun SearchFieldRow(
    icon: ImageVector,
    caption: String?,
    value: String,
    testTag: String,
    onClick: () -> Unit
) {
    val tokens = LocalTexasRailTokens.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = if (caption != null) 10.dp else 13.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tokens.primaryInk,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            if (caption != null) {
                Text(
                    text = caption,
                    style = MaterialTheme.typography.labelMedium,
                    color = tokens.secondaryInk
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ),
                color = tokens.primaryInk,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = tokens.secondaryInk
        )
    }
}

@Composable
private fun HomeShortcutCard(
    icon: ImageVector,
    label: String,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tokens = LocalTexasRailTokens.current
    Surface(
        onClick = onClick,
        modifier = modifier
            .height(98.dp)
            .minimumInteractiveComponentSize()
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        color = tokens.cardSurface,
        shadowElevation = 2.dp,
        border = BorderStroke(1.dp, tokens.divider)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tokens.accentOrange,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    lineHeight = 16.sp
                ),
                color = tokens.primaryInk,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationPickerBottomSheet(
    title: String,
    stations: List<Station>,
    savedStationIds: Set<String>,
    onToggleSavedStation: (String) -> Unit,
    onSelect: (Station) -> Unit,
    onDismiss: () -> Unit
) {
    val tokens = LocalTexasRailTokens.current
    var query by remember { mutableStateOf("") }
    val filtered = remember(stations, query) {
        if (query.isBlank()) stations
        else stations.filter {
            it.name.contains(query, ignoreCase = true) ||
                it.code.contains(query, ignoreCase = true) ||
                it.city.contains(query, ignoreCase = true)
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = tokens.primaryInk
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search city or 3-letter station code") },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("station_picker_search")
            )
            Spacer(modifier = Modifier.height(10.dp))
            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(filtered, key = { it.id }) { station ->
                    val isSaved = station.id in savedStationIds
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelect(station) }
                            .minimumInteractiveComponentSize()
                            .padding(horizontal = 10.dp, vertical = 10.dp)
                            .testTag("station_option_${station.code}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = tokens.headerNavy,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = station.code,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = station.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = tokens.primaryInk
                            )
                            Text(
                                text = "${station.address} • ${TexasRailTime.accessibleZoneName(station.timeZoneId)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.secondaryInk,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { onToggleSavedStation(station.id) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = if (isSaved) Icons.Filled.Star else Icons.Outlined.StarOutline,
                                contentDescription = if (isSaved) "Remove ${station.name} from saved stations" else "Save ${station.name}",
                                tint = if (isSaved) tokens.accentOrange else tokens.secondaryInk
                            )
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("MissingPermission")
private fun resolveCoarseLocation(context: Context): Pair<Double, Double>? {
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val providers = manager.getProviders(true)
    for (provider in providers) {
        val loc = runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
        if (loc != null) return loc.latitude to loc.longitude
    }
    return null
}
