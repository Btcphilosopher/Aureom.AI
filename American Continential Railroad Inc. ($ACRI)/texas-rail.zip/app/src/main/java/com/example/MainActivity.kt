package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.core.database.PreferencesRepository
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.TexasRailPalette
import com.example.core.designsystem.TexasRailTheme
import com.example.core.model.ThemePreference
import com.example.feature.account.AccountScreen
import com.example.feature.account.AccountViewModel
import com.example.feature.booking.BookingScreen
import com.example.feature.booking.BookingViewModel
import com.example.feature.departures.DeparturesAndStationViewModel
import com.example.feature.departures.DeparturesScreen
import com.example.feature.departures.StationDetailScreen
import com.example.feature.home.HomeScreen
import com.example.feature.home.HomeViewModel
import com.example.feature.journey.JourneyDetailScreen
import com.example.feature.map.MapScreen
import com.example.feature.map.MapViewModel
import com.example.feature.search.JourneyResultsScreen
import com.example.feature.search.JourneyResultsViewModel
import com.example.feature.search.SearchSessionStore
import com.example.feature.tickets.TicketsScreen
import com.example.feature.tickets.TicketsViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.serialization.Serializable
import javax.inject.Inject

@Serializable object HomeRoute
@Serializable object MapRoute
@Serializable object TicketsRoute
@Serializable object AccountRoute
@Serializable data class ResultsRoute(
    val originId: String,
    val destinationId: String,
    val dateIso: String,
    val passengerCount: Int
)
@Serializable data class JourneyDetailRoute(val journeyId: String)
@Serializable data class BookingRoute(val journeyId: String)
@Serializable data class DeparturesRoute(val stationId: String)
@Serializable data class StationDetailRoute(val stationId: String)

private data class TopTabItem(
    val label: String,
    val route: Any,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var preferencesRepository: PreferencesRepository
    @Inject lateinit var searchSessionStore: SearchSessionStore

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(TexasRailPalette.DeepNavy.toArgb())
        )
        setContent {
            val prefs by preferencesRepository.preferencesFlow.collectAsStateWithLifecycle(
                initialValue = com.example.core.database.AppPreferences()
            )
            val useDark = when (prefs.themePreference) {
                ThemePreference.SYSTEM -> isSystemInDarkTheme()
                ThemePreference.LIGHT -> false
                ThemePreference.DARK -> true
            }
            val windowSizeClass = calculateWindowSizeClass(this)

            TexasRailTheme(darkTheme = useDark) {
                TexasRailRootApp(
                    widthSizeClass = windowSizeClass.widthSizeClass,
                    searchSessionStore = searchSessionStore
                )
            }
        }
    }
}

@Composable
private fun TexasRailRootApp(
    widthSizeClass: WindowWidthSizeClass,
    searchSessionStore: SearchSessionStore
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination
    val tokens = LocalTexasRailTokens.current

    val topTabs = remember {
        listOf(
            TopTabItem("Home", HomeRoute, Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
            TopTabItem("Map", MapRoute, Icons.Filled.LocationOn, Icons.Outlined.LocationOn, "nav_map"),
            TopTabItem("Tickets", TicketsRoute, Icons.Filled.ConfirmationNumber, Icons.Outlined.ConfirmationNumber, "nav_tickets"),
            TopTabItem("Account", AccountRoute, Icons.Filled.Person, Icons.Outlined.PersonOutline, "nav_account")
        )
    }

    val isTopTab = currentDest?.let { dest ->
        dest.hasRoute<HomeRoute>() ||
            dest.hasRoute<MapRoute>() ||
            dest.hasRoute<TicketsRoute>() ||
            dest.hasRoute<AccountRoute>()
    } ?: true

    val showRail = widthSizeClass != WindowWidthSizeClass.Compact

    fun navigateToTopTab(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = tokens.pageBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (!showRail && isTopTab) {
                TexasRailBottomBar(
                    tabs = topTabs,
                    isSelected = { tab ->
                        when (tab.route) {
                            is HomeRoute -> currentDest?.hasRoute<HomeRoute>() == true
                            is MapRoute -> currentDest?.hasRoute<MapRoute>() == true
                            is TicketsRoute -> currentDest?.hasRoute<TicketsRoute>() == true
                            is AccountRoute -> currentDest?.hasRoute<AccountRoute>() == true
                            else -> false
                        }
                    },
                    onSelect = ::navigateToTopTab
                )
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (showRail && isTopTab) {
                NavigationRail(
                    containerColor = tokens.cardSurface
                ) {
                    Spacer(modifier = Modifier.height(16.dp))
                    topTabs.forEach { tab ->
                        val selected = when (tab.route) {
                            is HomeRoute -> currentDest?.hasRoute<HomeRoute>() == true
                            is MapRoute -> currentDest?.hasRoute<MapRoute>() == true
                            is TicketsRoute -> currentDest?.hasRoute<TicketsRoute>() == true
                            is AccountRoute -> currentDest?.hasRoute<AccountRoute>() == true
                            else -> false
                        }
                        NavigationRailItem(
                            selected = selected,
                            onClick = { navigateToTopTab(tab.route) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.label
                                )
                            },
                            label = { Text(tab.label) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = tokens.accentOrange,
                                selectedTextColor = tokens.accentOrange,
                                indicatorColor = tokens.accentSoft,
                                unselectedIconColor = tokens.secondaryInk,
                                unselectedTextColor = tokens.secondaryInk
                            ),
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                NavHost(
                    navController = navController,
                    startDestination = HomeRoute
                ) {
                    composable<HomeRoute> {
                        val vm: HomeViewModel = hiltViewModel()
                        HomeScreen(
                            viewModel = vm,
                            onFindTrains = { orig, dest, dateIso, pax ->
                                navController.navigate(ResultsRoute(orig, dest, dateIso, pax))
                            },
                            onOpenTickets = { navigateToTopTab(TicketsRoute) },
                            onOpenDepartures = { stationId ->
                                navController.navigate(DeparturesRoute(stationId))
                            },
                            onOpenSavedTripsSheet = {}
                        )
                    }
                    composable<MapRoute> {
                        val vm: MapViewModel = hiltViewModel()
                        MapScreen(
                            viewModel = vm,
                            onViewJourneys = { orig, dest, dateIso, pax ->
                                navController.navigate(ResultsRoute(orig, dest, dateIso, pax))
                            },
                            onOpenStationDetails = { stationId ->
                                navController.navigate(StationDetailRoute(stationId))
                            }
                        )
                    }
                    composable<TicketsRoute> {
                        val vm: TicketsViewModel = hiltViewModel()
                        TicketsScreen(
                            viewModel = vm,
                            onPlanTrip = { navigateToTopTab(HomeRoute) }
                        )
                    }
                    composable<AccountRoute> {
                        val vm: AccountViewModel = hiltViewModel()
                        AccountScreen(
                            viewModel = vm,
                            onOpenSavedTripSearch = { orig, dest ->
                                val q = searchSessionStore.query.value
                                navController.navigate(ResultsRoute(orig, dest, q.serviceDate.toString(), q.passengerCount))
                            }
                        )
                    }
                    composable<ResultsRoute> { entry ->
                        val args = entry.toRoute<ResultsRoute>()
                        val vm: JourneyResultsViewModel = hiltViewModel()
                        JourneyResultsScreen(
                            originId = args.originId,
                            destinationId = args.destinationId,
                            dateIso = args.dateIso,
                            passengerCount = args.passengerCount,
                            viewModel = vm,
                            onBack = { navController.popBackStack() },
                            onSelectJourney = { option ->
                                navController.navigate(JourneyDetailRoute(option.id))
                            }
                        )
                    }
                    composable<JourneyDetailRoute> { entry ->
                        val args = entry.toRoute<JourneyDetailRoute>()
                        JourneyDetailScreen(
                            journeyId = args.journeyId,
                            searchSessionStore = searchSessionStore,
                            onBack = { navController.popBackStack() },
                            onProceedToBooking = { option ->
                                navController.navigate(BookingRoute(option.id))
                            }
                        )
                    }
                    composable<BookingRoute> { entry ->
                        val args = entry.toRoute<BookingRoute>()
                        val vm: BookingViewModel = hiltViewModel()
                        BookingScreen(
                            journeyId = args.journeyId,
                            viewModel = vm,
                            onExitToResults = { navController.popBackStack() },
                            onOpenTicketsWallet = {
                                navController.navigate(TicketsRoute) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = false
                                    }
                                    launchSingleTop = true
                                }
                            }
                        )
                    }
                    composable<DeparturesRoute> { entry ->
                        val args = entry.toRoute<DeparturesRoute>()
                        val vm: DeparturesAndStationViewModel = hiltViewModel()
                        DeparturesScreen(
                            initialStationId = args.stationId,
                            viewModel = vm,
                            onBack = { navController.popBackStack() },
                            onOpenStationDetails = { stationId ->
                                navController.navigate(StationDetailRoute(stationId))
                            }
                        )
                    }
                    composable<StationDetailRoute> { entry ->
                        val args = entry.toRoute<StationDetailRoute>()
                        val vm: DeparturesAndStationViewModel = hiltViewModel()
                        StationDetailScreen(
                            stationId = args.stationId,
                            viewModel = vm,
                            onBack = { navController.popBackStack() },
                            onOpenDepartures = { stationId ->
                                navController.navigate(DeparturesRoute(stationId))
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TexasRailBottomBar(
    tabs: List<TopTabItem>,
    isSelected: (TopTabItem) -> Boolean,
    onSelect: (Any) -> Unit
) {
    val tokens = LocalTexasRailTokens.current
    Surface(
        color = tokens.cardSurface,
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.navigationBarsPadding()) {
            HorizontalDivider(color = tokens.divider)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEach { tab ->
                    val selected = isSelected(tab)
                    val interaction = remember { MutableInteractionSource() }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .minimumInteractiveComponentSize()
                            .clickable(
                                interactionSource = interaction,
                                indication = ripple(bounded = true),
                                role = Role.Tab,
                                onClick = { onSelect(tab.route) }
                            )
                            .testTag(tab.testTag),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                            contentDescription = null,
                            tint = if (selected) tokens.accentOrange else tokens.primaryInk,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (selected) tokens.accentOrange else tokens.primaryInk
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Box(
                            modifier = Modifier
                                .width(28.dp)
                                .height(2.5.dp)
                                .background(
                                    color = if (selected) tokens.accentOrange else androidx.compose.ui.graphics.Color.Transparent,
                                    shape = RoundedCornerShape(2.dp)
                                )
                        )
                    }
                }
            }
        }
    }
}
