package com.example.core.database

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class EncryptedTokenStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val prefs: SharedPreferences by lazy {
        runCatching {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "texas_rail_secure_tokens",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }.getOrElse {
            // Fallback strictly for headless JVM test runners without AndroidKeyStore
            context.getSharedPreferences("texas_rail_secure_tokens_test", Context.MODE_PRIVATE)
        }
    }

    fun saveSessionToken(token: String) {
        prefs.edit().putString(KEY_SESSION_TOKEN, token).apply()
    }

    fun getSessionToken(): String? = prefs.getString(KEY_SESSION_TOKEN, null)

    fun clearSessionToken() {
        prefs.edit().remove(KEY_SESSION_TOKEN).apply()
    }

    fun redactedTokenSummary(): String {
        val t = getSessionToken() ?: return "none"
        return if (t.length <= 4) "****" else "${t.take(3)}***"
    }

    companion object {
        private const val KEY_SESSION_TOKEN = "session_bearer_token"
    }
}
