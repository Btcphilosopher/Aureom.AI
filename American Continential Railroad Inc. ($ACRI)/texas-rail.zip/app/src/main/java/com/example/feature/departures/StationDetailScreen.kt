package com.example.feature.departures

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Accessible
import androidx.compose.material.icons.automirrored.outlined.DirectionsBike
import androidx.compose.material.icons.automirrored.outlined.HelpOutline
import androidx.compose.material.icons.outlined.DirectionsBus
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.SectionHeadingWithAccent
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.time.TexasRailTime

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StationDetailScreen(
    stationId: String,
    viewModel: DeparturesAndStationViewModel,
    onBack: () -> Unit,
    onOpenDepartures: (String) -> Unit
) {
    val state by viewModel.stationDetailState.collectAsStateWithLifecycle()
    val tokens = LocalTexasRailTokens.current

    LaunchedEffect(stationId) {
        viewModel.loadStationDetails(stationId)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        TexasRailTopBar(showBack = true, onBackClick = onBack)

        if (state.isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = tokens.accentOrange)
            }
            return@Column
        }

        val station = state.station
        if (station == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Station not found.", color = tokens.primaryInk)
            }
            return@Column
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .align(Alignment.CenterHorizontally)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionHeadingWithAccent(title = "${station.name} (${station.code})")

            // Address & Location
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = tokens.accentOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Address & Coordinates", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    Text(station.address, style = MaterialTheme.typography.bodyLarge, color = tokens.primaryInk)
                    Text(
                        text = "%.4f° N, %.4f° W • %s".format(station.latitude, kotlin.math.abs(station.longitude), TexasRailTime.accessibleZoneName(station.timeZoneId)),
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.secondaryInk
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Schedule, contentDescription = null, tint = tokens.secondaryInk, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Opening hours: ${station.openingHours ?: "Unknown / Not verified"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (station.openingHours == null) tokens.warningBadgeInk else tokens.primaryInk
                        )
                    }
                }
            }

            // Served Routes & Entrances
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Served Corridors", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), modifier = Modifier.semantics { heading() })
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.servedRoutes.forEach { rt ->
                            AssistChip(onClick = {}, label = { Text("${rt.shortCode} • ${rt.name}") })
                        }
                    }
                    Text("Entrances", style = MaterialTheme.typography.titleSmall, color = tokens.primaryInk)
                    station.entrances.forEach { ent ->
                        Text("• $ent", style = MaterialTheme.typography.bodyMedium, color = tokens.secondaryInk)
                    }
                }
            }

            // Accessibility: explicitly separate Verified vs Unknown facilities
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Outlined.Accessible, contentDescription = null, tint = tokens.accentOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Accessibility Facilities", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    val acc = station.accessibility
                    val rows = listOf(
                        "Step-free station access" to acc.stepFreeAccess,
                        "Level train boarding" to acc.levelBoarding,
                        "Tactile platform paving" to acc.tactileGuidance,
                        "Accessible restrooms" to acc.accessibleRestrooms,
                        "Passenger assistance desk" to acc.assistanceDesk,
                        "Audio induction loops" to acc.audioInductionLoops
                    )
                    val known = rows.filter { it.second != null }
                    val unknown = rows.filter { it.second == null }

                    Text("Verified facilities", style = MaterialTheme.typography.labelLarge, color = tokens.verifiedBadgeInk)
                    known.forEach { (label, value) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Verified, contentDescription = null, tint = tokens.verifiedBadgeInk, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$label: ${if (value == true) "Available" else "Unavailable"}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    if (unknown.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Unknown / Unverified information", style = MaterialTheme.typography.labelLarge, color = tokens.warningBadgeInk)
                        unknown.forEach { (label, _) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Outlined.HelpOutline, contentDescription = null, tint = tokens.warningBadgeInk, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("$label: Unknown (not verified)", style = MaterialTheme.typography.bodyMedium, color = tokens.secondaryInk)
                            }
                        }
                    }
                }
            }

            // Parking, Bike Facilities & Local Transport
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Outlined.DirectionsBike, contentDescription = null, tint = tokens.accentOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Parking & Bicycle Facilities", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    val p = station.parkingBikes
                    Text("Structured parking: ${p.structuredParkingSpaces?.let { "$it spaces" } ?: "Unknown"}", style = MaterialTheme.typography.bodyMedium)
                    Text("EV chargers: ${p.evChargers?.let { "$it stalls" } ?: "Unknown"}", style = MaterialTheme.typography.bodyMedium)
                    Text("Covered bike racks: ${p.coveredBikeRacks?.let { "$it racks" } ?: "Unknown"}", style = MaterialTheme.typography.bodyMedium)
                    Text("Bike lockers: ${p.bikeLockers?.let { "$it lockers" } ?: "Unknown"}", style = MaterialTheme.typography.bodyMedium)

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.DirectionsBus, contentDescription = null, tint = tokens.accentOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Local Transport Connections", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    station.localTransitConnections.forEach { transit ->
                        Text("• $transit", style = MaterialTheme.typography.bodyMedium, color = tokens.secondaryInk)
                    }
                }
            }

            Button(
                onClick = { onOpenDepartures(station.id) },
                colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("station_view_departures_button")
            ) {
                Text("View ${station.name} Departures", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        }
    }
}
