package com.example.feature.account

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.OperatingModeBanner
import com.example.core.designsystem.SectionHeadingWithAccent
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.OperatingMode
import com.example.core.model.PassengerType
import com.example.core.model.ThemePreference
import com.example.core.time.TexasRailTime

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AccountScreen(
    viewModel: AccountViewModel,
    onOpenSavedTripSearch: (originId: String, destId: String) -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val tokens = LocalTexasRailTokens.current
    val prefs = state.preferences

    var emailInput by remember { mutableStateOf("") }
    var nameInput by remember { mutableStateOf("") }
    var newPassengerName by remember { mutableStateOf("") }
    var backendUrlInput by remember(prefs.connectedBaseUrl) { mutableStateOf(prefs.connectedBaseUrl) }
    var confirmDelete by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        TexasRailTopBar(operatingMode = prefs.operatingMode)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .align(Alignment.CenterHorizontally)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionHeadingWithAccent(title = "Account & Settings")

            if (state.statusBanner != null) {
                Surface(
                    color = tokens.accentSoft,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, tokens.accentOrange.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = state.statusBanner!!,
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.primaryInk,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Operating Mode (Concept Demonstration vs Connected Services)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Network Operating Mode",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.semantics { heading() }
                    )
                    OperatingModeBanner(operatingMode = prefs.operatingMode)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = prefs.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION,
                            onClick = { viewModel.switchOperatingMode(OperatingMode.CONCEPT_DEMONSTRATION, backendUrlInput) },
                            label = { Text("Concept Demonstration") },
                            modifier = Modifier.testTag("mode_concept_demo")
                        )
                        FilterChip(
                            selected = prefs.operatingMode == OperatingMode.CONNECTED_SERVICES,
                            onClick = { viewModel.switchOperatingMode(OperatingMode.CONNECTED_SERVICES, backendUrlInput) },
                            label = { Text("Connected Services") },
                            modifier = Modifier.testTag("mode_connected_services")
                        )
                    }
                    OutlinedTextField(
                        value = backendUrlInput,
                        onValueChange = { backendUrlInput = it },
                        label = { Text("PostgreSQL Service URL (Docker Compose)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    state.datasetVersion?.let { ver ->
                        Text(
                            text = "Offline dataset ${ver.id} • Synced ${TexasRailTime.formatRefreshTimestamp(ver.lastSyncedAt)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.secondaryInk
                        )
                    }
                }
            }

            // Optional Sign-in (browsing & search never requires registration)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.PersonOutline, contentDescription = null, tint = tokens.accentOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (prefs.userProfile.isSignedIn) prefs.userProfile.displayName else "Optional Sign-In (Guest Mode Active)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    if (prefs.userProfile.isSignedIn) {
                        Text(prefs.userProfile.email, style = MaterialTheme.typography.bodyMedium, color = tokens.secondaryInk)
                        OutlinedButton(onClick = viewModel::signOut, modifier = Modifier.testTag("account_sign_out")) {
                            Text("Sign out")
                        }
                    } else {
                        Text(
                            "Browse routes and search timetables without an account. Sign in optionally to isolate saved passengers and bookings per profile.",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.secondaryInk
                        )
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Email") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("account_email_input")
                        )
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Display name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("account_name_input")
                        )
                        Button(
                            onClick = { viewModel.signInOptional(emailInput, nameInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                            modifier = Modifier.testTag("account_sign_in_button")
                        ) {
                            Text("Sign in")
                        }
                    }
                }
            }

            // Saved Passengers
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Saved Passengers", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newPassengerName,
                            onValueChange = { newPassengerName = it },
                            label = { Text("Add traveler name") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                viewModel.addSavedPassenger(newPassengerName, PassengerType.ADULT)
                                newPassengerName = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange)
                        ) { Text("Add") }
                    }
                    state.savedPassengers.forEach { pax ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${pax.fullName} (${pax.passengerType.name.lowercase()})", style = MaterialTheme.typography.bodyMedium)
                            IconButton(onClick = { viewModel.removeSavedPassenger(pax.id) }) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "Remove passenger ${pax.fullName}")
                            }
                        }
                    }
                }
            }

            // Favourite Journeys
            if (state.savedJourneys.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.cardSurface,
                    border = BorderStroke(1.dp, tokens.divider)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Favourite Journeys", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        state.savedJourneys.forEach { fav ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { onOpenSavedTripSearch(fav.originStationId, fav.destinationStationId) }) {
                                    Text(fav.label, color = tokens.accentOrange)
                                }
                                IconButton(onClick = { viewModel.removeSavedJourney(fav.id) }) {
                                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "Remove saved trip ${fav.label}")
                                }
                            }
                        }
                    }
                }
            }

            // Appearance, Language & Notifications
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Appearance & Preferences", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Theme", style = MaterialTheme.typography.labelLarge, color = tokens.secondaryInk)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemePreference.entries.forEach { theme ->
                            FilterChip(
                                selected = prefs.themePreference == theme,
                                onClick = { viewModel.setTheme(theme) },
                                label = { Text(theme.name.lowercase().replaceFirstChar { it.uppercase() }) }
                            )
                        }
                    }
                    Text("Language", style = MaterialTheme.typography.labelLarge, color = tokens.secondaryInk)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("en-US" to "English (US)", "es-US" to "Español (US)").forEach { (code, label) ->
                            FilterChip(
                                selected = prefs.languageCode == code,
                                onClick = { viewModel.setLanguage(code) },
                                label = { Text(label) }
                            )
                        }
                    }
                    HorizontalDivider(color = tokens.divider)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Service disruption & delay alerts", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = prefs.delayAlertsEnabled,
                            onCheckedChange = { viewModel.setNotifications(it, prefs.tripRemindersEnabled) }
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Departure reminders", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = prefs.tripRemindersEnabled,
                            onCheckedChange = { viewModel.setNotifications(prefs.delayAlertsEnabled, it) }
                        )
                    }
                }
            }

            // Data Export, Account Deletion & Privacy
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.PrivacyTip, contentDescription = null, tint = tokens.accentOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Data, Privacy & Support", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    Text(
                        "Texas Rail minimizes location collection (optional coarse check only), never stores payment card numbers, and isolates cached tickets per signed-in profile.",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.secondaryInk
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = viewModel::exportAccountData,
                            modifier = Modifier.weight(1f).testTag("account_export_button")
                        ) {
                            Icon(Icons.Outlined.Download, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export data")
                        }
                        OutlinedButton(
                            onClick = { confirmDelete = true },
                            modifier = Modifier.weight(1f).testTag("account_delete_button")
                        ) {
                            Text("Delete data", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }

    state.exportedJson?.let { jsonText ->
        AlertDialog(
            onDismissRequest = viewModel::dismissExport,
            title = { Text("Account Data Export (JSON)") },
            text = { Text(jsonText, style = MaterialTheme.typography.labelSmall) },
            confirmButton = {
                TextButton(onClick = viewModel::dismissExport) { Text("Close") }
            }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete Account & Local Data?") },
            text = { Text("This permanently deletes your saved passengers, favourite trips, session token, and cached bookings for this profile.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmDelete = false
                        viewModel.deleteAccountAndData()
                    }
                ) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel") }
            }
        )
    }
}
