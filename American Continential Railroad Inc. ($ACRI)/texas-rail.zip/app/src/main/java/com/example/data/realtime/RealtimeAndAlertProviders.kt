package com.example.data.realtime

import com.example.core.database.PreferencesRepository
import com.example.core.database.TimetableDao
import com.example.core.model.AlertProvider
import com.example.core.model.DepartureBoardEntry
import com.example.core.model.DepartureBoardResult
import com.example.core.model.OperatingMode
import com.example.core.model.RealtimeProvider
import com.example.core.model.ServiceAlert
import com.example.core.model.ServiceStatus
import com.example.core.network.TexasRailApiFactory
import com.example.core.time.TexasRailTime
import com.example.data.timetables.DatabaseMappers.toDomain
import com.example.data.timetables.NetworkAndTimetableRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import java.time.Instant
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RealtimeAndAlertRepository @Inject constructor(
    private val timetableDao: TimetableDao,
    private val timetableRepo: NetworkAndTimetableRepository,
    private val preferencesRepository: PreferencesRepository,
    private val apiFactory: TexasRailApiFactory
) : RealtimeProvider, AlertProvider {

    override suspend fun getDepartures(stationId: String, date: LocalDate): DepartureBoardResult {
        timetableRepo.ensureSeeded()
        val prefs = preferencesRepository.preferencesFlow.first()
        val station = timetableDao.getStation(stationId)?.toDomain()
            ?: error("Unknown station: $stationId")

        val trips = timetableDao.getAllTrips().map { it.toDomain() }.associateBy { it.id }
        val routes = timetableDao.getAllRoutes().map { it.toDomain() }.associateBy { it.id }
        val stations = timetableDao.getAllStations().map { it.toDomain() }.associateBy { it.id }
        val allStopTimes = timetableDao.getAllStopTimes().map { it.toDomain() }.groupBy { it.tripId }

        if (prefs.operatingMode == OperatingMode.CONNECTED_SERVICES) {
            val remote = runCatching {
                apiFactory.create(prefs.connectedBaseUrl).getDepartures(stationId)
            }.getOrNull()

            if (remote != null) {
                val entries = remote.departures.mapNotNull { dto ->
                    val trip = trips[dto.trip_id]
                    val destId = allStopTimes[dto.trip_id]?.maxByOrNull { it.stopSequence }?.stationId
                    val destName = destId?.let { stations[it]?.name } ?: dto.service_name
                    val schedInstant = TexasRailTime.resolveStopInstant(
                        date,
                        dto.departure_offset_seconds,
                        dto.day_offset,
                        station.timeZoneId
                    )
                    DepartureBoardEntry(
                        tripId = dto.trip_id,
                        trainNumber = dto.train_number,
                        routeShortCode = dto.short_code,
                        routeName = dto.route_name,
                        destinationStationName = destName,
                        scheduledDeparture = schedInstant,
                        predictedDeparture = null,
                        stationZoneId = station.timeZoneId,
                        platformCode = null,
                        status = if (remote.isLiveTelemetryAvailable) ServiceStatus.ON_TIME else ServiceStatus.SCHEDULED_ILLUSTRATIVE,
                        delayMinutes = 0,
                        operatingMode = OperatingMode.CONNECTED_SERVICES
                    )
                }
                return DepartureBoardResult(
                    station = station,
                    operatingMode = OperatingMode.CONNECTED_SERVICES,
                    isLiveTelemetryAvailable = remote.isLiveTelemetryAvailable,
                    refreshedAt = runCatching { Instant.parse(remote.refreshedAtUtc) }.getOrDefault(Instant.now()),
                    entries = entries
                )
            }
        }

        // Offline or Concept Demonstration scheduled departure board (never fabricates live telemetry!)
        val stationStops = timetableDao.getDeparturesForStation(stationId).map { it.toDomain() }
        val entries = stationStops.mapNotNull { stop ->
            val trip = trips[stop.tripId] ?: return@mapNotNull null
            if (trip.operatingMode != prefs.operatingMode) return@mapNotNull null
            val route = routes[trip.routeId] ?: return@mapNotNull null
            val tripStops = allStopTimes[trip.id].orEmpty().sortedBy { it.stopSequence }
            val destStationId = tripStops.lastOrNull()?.stationId ?: return@mapNotNull null
            val destStation = stations[destStationId] ?: return@mapNotNull null
            if (destStation.id == stationId) return@mapNotNull null

            val schedInstant = TexasRailTime.resolveStopInstant(
                date,
                stop.departureOffsetSeconds,
                stop.dayOffset,
                station.timeZoneId
            )

            DepartureBoardEntry(
                tripId = trip.id,
                trainNumber = trip.trainNumber,
                routeShortCode = route.shortCode,
                routeName = route.name,
                destinationStationName = destStation.name,
                scheduledDeparture = schedInstant,
                predictedDeparture = null,
                stationZoneId = station.timeZoneId,
                platformCode = stop.platformCode,
                status = ServiceStatus.SCHEDULED_ILLUSTRATIVE,
                delayMinutes = 0,
                operatingMode = trip.operatingMode
            )
        }.sortedBy { it.scheduledDeparture }

        return DepartureBoardResult(
            station = station,
            operatingMode = prefs.operatingMode,
            isLiveTelemetryAvailable = false,
            refreshedAt = Instant.now(),
            entries = entries
        )
    }

    override fun observeAlerts(): Flow<List<ServiceAlert>> =
        combine(
            timetableDao.observeAlerts(),
            preferencesRepository.preferencesFlow
        ) { alerts, prefs ->
            alerts.map { it.toDomain() }.filter { it.operatingMode == prefs.operatingMode }
        }

    override suspend fun getAlertsForStation(stationId: String): List<ServiceAlert> {
        timetableRepo.ensureSeeded()
        val prefs = preferencesRepository.preferencesFlow.first()
        return timetableDao.getAlertsForStation(stationId)
            .map { it.toDomain() }
            .filter { it.operatingMode == prefs.operatingMode }
    }
}
