package com.example.core.time

import com.example.core.model.Money
import java.text.NumberFormat
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object TexasRailTime {
    val CENTRAL_ZONE: ZoneId = ZoneId.of("America/Chicago")
    val MOUNTAIN_ZONE: ZoneId = ZoneId.of("America/Denver")

    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US)
    private val dateHeaderFormatter = DateTimeFormatter.ofPattern("EEE, d MMM", Locale.US)
    private val fullDateFormatter = DateTimeFormatter.ofPattern("EEE, MMM d, yyyy", Locale.US)
    private val timestampFormatter = DateTimeFormatter.ofPattern("HH:mm z", Locale.US)

    /**
     * Resolves a timetable stop offset on a given [serviceDate] + [dayOffset] into an exact UTC [Instant]
     * in the station's IANA [zoneId], handling Daylight Saving Time transitions explicitly.
     */
    fun resolveStopInstant(
        serviceDate: LocalDate,
        offsetSecondsFromMidnight: Int,
        dayOffset: Int,
        zoneId: String
    ): Instant {
        val zone = ZoneId.of(zoneId)
        val extraDays = offsetSecondsFromMidnight / 86_400
        val secondsOfDay = ((offsetSecondsFromMidnight % 86_400) + 86_400) % 86_400
        val effectiveDate = serviceDate.plusDays((dayOffset + extraDays).toLong())
        val localTime = LocalTime.ofSecondOfDay(secondsOfDay.toLong())
        return ZonedDateTime.of(effectiveDate, localTime, zone).toInstant()
    }

    /**
     * Computes actual elapsed duration between two [Instant]s rather than subtracting clock times.
     */
    fun elapsedMinutes(departure: Instant, arrival: Instant): Long {
        return Duration.between(departure, arrival).toMinutes().coerceAtLeast(0L)
    }

    fun formatLocalTime(instant: Instant, zoneId: String): String {
        val zdt = instant.atZone(ZoneId.of(zoneId))
        return timeFormatter.format(zdt)
    }

    fun shortZoneLabel(instant: Instant, zoneId: String): String {
        return when (zoneId) {
            CENTRAL_ZONE.id -> "CT"
            MOUNTAIN_ZONE.id -> "MT"
            else -> instant.atZone(ZoneId.of(zoneId)).format(DateTimeFormatter.ofPattern("z", Locale.US))
        }
    }

    fun accessibleZoneName(zoneId: String): String = when (zoneId) {
        CENTRAL_ZONE.id -> "Central Time"
        MOUNTAIN_ZONE.id -> "Mountain Time"
        else -> zoneId
    }

    fun formatDuration(minutes: Long): String {
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h}h"
            else -> "${m}m"
        }
    }

    fun formatDayDifferenceBadge(
        departureInstant: Instant,
        originZoneId: String,
        arrivalInstant: Instant,
        destinationZoneId: String
    ): String? {
        val depDate = departureInstant.atZone(ZoneId.of(originZoneId)).toLocalDate()
        val arrDate = arrivalInstant.atZone(ZoneId.of(destinationZoneId)).toLocalDate()
        val diff = java.time.temporal.ChronoUnit.DAYS.between(depDate, arrDate)
        return if (diff > 0) "+${diff}d" else null
    }

    fun formatDateChip(date: LocalDate): String = dateHeaderFormatter.format(date)

    fun formatFullDate(date: LocalDate): String = fullDateFormatter.format(date)

    fun formatRefreshTimestamp(instant: Instant, zoneId: String = CENTRAL_ZONE.id): String {
        val zdt = instant.atZone(ZoneId.of(zoneId))
        return timestampFormatter.format(zdt)
    }

    fun formatMoney(money: Money, locale: Locale = Locale.US): String {
        val formatter = NumberFormat.getCurrencyInstance(locale)
        formatter.currency = java.util.Currency.getInstance(money.currency)
        val bd = money.toBigDecimal()
        formatter.maximumFractionDigits = if (money.cents % 100L == 0L) 0 else 2
        formatter.minimumFractionDigits = if (money.cents % 100L == 0L) 0 else 2
        return formatter.format(bd)
    }

    fun formatMoneyExact(money: Money, locale: Locale = Locale.US): String {
        val formatter = NumberFormat.getCurrencyInstance(locale)
        formatter.currency = java.util.Currency.getInstance(money.currency)
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter.format(money.toBigDecimal())
    }

    fun formatDistanceUsCustomary(meters: Int): String {
        val feet = (meters * 3.28084).toInt()
        return if (feet < 1000) "$feet ft" else String.format(Locale.US, "%.1f mi", meters / 1609.344)
    }
}
