package com.example.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Database(
    entities = [
        DatasetVersionEntity::class,
        StationEntity::class,
        RouteEntity::class,
        RoutePatternEntity::class,
        ServiceCalendarEntity::class,
        CalendarExceptionEntity::class,
        TripEntity::class,
        StopTimeEntity::class,
        TransferEntity::class,
        ServiceAlertEntity::class,
        TripInventoryEntity::class,
        InventoryReservationEntity::class,
        PaymentRecordEntity::class,
        ProcessedWebhookEntity::class,
        BookingEntity::class,
        SavedJourneyEntity::class,
        SavedPassengerEntity::class,
        RecentSearchEntity::class,
        SavedStationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TexasRailDatabase : RoomDatabase() {
    abstract fun timetableDao(): TimetableDao
    abstract fun inventoryAndBookingDao(): InventoryAndBookingDao
    abstract fun userLibraryDao(): UserLibraryDao
}

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): TexasRailDatabase {
        return Room.databaseBuilder(
            context,
            TexasRailDatabase::class.java,
            "texas_rail_offline.db"
        ).fallbackToDestructiveMigration(dropAllTables = false).build()
    }

    @Provides
    fun provideTimetableDao(db: TexasRailDatabase): TimetableDao = db.timetableDao()

    @Provides
    fun provideInventoryAndBookingDao(db: TexasRailDatabase): InventoryAndBookingDao =
        db.inventoryAndBookingDao()

    @Provides
    fun provideUserLibraryDao(db: TexasRailDatabase): UserLibraryDao = db.userLibraryDao()
}
