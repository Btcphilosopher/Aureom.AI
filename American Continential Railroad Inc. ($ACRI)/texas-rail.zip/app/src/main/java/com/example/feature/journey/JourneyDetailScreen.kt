package com.example.feature.journey

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Accessible
import androidx.compose.material.icons.automirrored.outlined.DirectionsWalk
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Train
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.OperatingModeBanner
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.JourneyLeg
import com.example.core.model.JourneyOption
import com.example.core.model.OperatingMode
import com.example.core.time.TexasRailTime
import com.example.feature.search.SearchSessionStore

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JourneyDetailScreen(
    journeyId: String,
    searchSessionStore: SearchSessionStore,
    onBack: () -> Unit,
    onProceedToBooking: (JourneyOption) -> Unit
) {
    val tokens = LocalTexasRailTokens.current
    val query by searchSessionStore.query.collectAsStateWithLifecycle()
    val journey = searchSessionStore.findJourneyById(journeyId)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        TexasRailTopBar(
            showBack = true,
            onBackClick = onBack,
            operatingMode = journey?.operatingMode
        )

        if (journey == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Journey details unavailable. Please run a new search.", color = tokens.primaryInk)
            }
            return@Column
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .widthIn(max = 720.dp)
                .align(Alignment.CenterHorizontally)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OperatingModeBanner(operatingMode = journey.operatingMode)

            Text(
                text = "${journey.originStation.name} → ${journey.destinationStation.name}",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                color = tokens.primaryInk,
                modifier = Modifier.semantics { heading() }
            )

            Text(
                text = "${TexasRailTime.formatFullDate(query.serviceDate)} • ${TexasRailTime.formatDuration(journey.totalDurationMinutes)} • ${if (journey.isDirect) "Direct" else "${journey.transferCount} change"}",
                style = MaterialTheme.typography.bodyLarge,
                color = tokens.secondaryInk
            )

            // Station-by-station itinerary
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Itinerary & Boarding",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = tokens.primaryInk,
                        modifier = Modifier.semantics { heading() }
                    )

                    journey.legs.forEach { leg ->
                        when (leg) {
                            is JourneyLeg.RailRide -> {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.Train, contentDescription = null, tint = tokens.accentOrange)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "${leg.trip.trainNumber} • ${leg.trip.serviceName}",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = tokens.primaryInk
                                        )
                                        Text(
                                            text = "${leg.route.shortCode} ${leg.route.name} • ${TexasRailTime.formatDuration(leg.durationMinutes)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = tokens.secondaryInk
                                        )
                                    }
                                }

                                // Origin stop
                                StopTimelineRow(
                                    time = leg.originStop.departureInstant?.let {
                                        "${TexasRailTime.formatLocalTime(it, leg.originStop.station.timeZoneId)} ${TexasRailTime.shortZoneLabel(it, leg.originStop.station.timeZoneId)}"
                                    } ?: "--:--",
                                    stationName = "${leg.originStop.station.name} (${leg.originStop.station.code})",
                                    subtitle = "Boarding: ${leg.originStop.platformCode ?: "Platform TBA"} • Arrive 20m prior",
                                    isEndpoint = true
                                )

                                // Intermediate stops
                                leg.intermediateStops.forEach { mid ->
                                    StopTimelineRow(
                                        time = mid.arrivalInstant?.let {
                                            TexasRailTime.formatLocalTime(it, mid.station.timeZoneId)
                                        } ?: "--:--",
                                        stationName = "${mid.station.name} (${mid.station.code})",
                                        subtitle = "Intermediate stop",
                                        isEndpoint = false
                                    )
                                }

                                // Destination stop
                                StopTimelineRow(
                                    time = leg.destinationStop.arrivalInstant?.let {
                                        "${TexasRailTime.formatLocalTime(it, leg.destinationStop.station.timeZoneId)} ${TexasRailTime.shortZoneLabel(it, leg.destinationStop.station.timeZoneId)}"
                                    } ?: "--:--",
                                    stationName = "${leg.destinationStop.station.name} (${leg.destinationStop.station.code})",
                                    subtitle = "Arrival: ${leg.destinationStop.platformCode ?: "Platform TBA"}",
                                    isEndpoint = true
                                )

                                if (leg.trip.amenities.isNotEmpty()) {
                                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        leg.trip.amenities.forEach { amenity ->
                                            AssistChip(
                                                onClick = {},
                                                label = { Text(amenity, style = MaterialTheme.typography.labelSmall) }
                                            )
                                        }
                                    }
                                }
                            }
                            is JourneyLeg.TransferWalk -> {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = tokens.cardSecondary,
                                    border = BorderStroke(1.dp, tokens.divider),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.AutoMirrored.Outlined.DirectionsWalk, contentDescription = null, tint = tokens.primaryInk)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "Change at ${leg.station.name} (${TexasRailTime.formatDuration(leg.waitDurationMinutes)})",
                                                style = MaterialTheme.typography.titleSmall,
                                                color = tokens.primaryInk
                                            )
                                            Text(
                                                text = "Est. walk ${TexasRailTime.formatDistanceUsCustomary(leg.walkingDistanceMeters)} • Min connection ${leg.minConnectionMinutes}m",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = tokens.secondaryInk
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Accessibility disclosure card (never promises unknown level boarding)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (journey.accessibilityVerified) tokens.verifiedBadgeBg else tokens.warningBadgeBg,
                border = BorderStroke(
                    1.dp,
                    if (journey.accessibilityVerified) tokens.verifiedBadgeInk.copy(alpha = 0.35f)
                    else tokens.warningBadgeInk.copy(alpha = 0.35f)
                )
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = if (journey.accessibilityVerified) Icons.AutoMirrored.Outlined.Accessible else Icons.Outlined.WarningAmber,
                        contentDescription = null,
                        tint = if (journey.accessibilityVerified) tokens.verifiedBadgeInk else tokens.warningBadgeInk
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (journey.accessibilityVerified) "Accessibility Verified" else "Accessibility Verification Notice",
                            style = MaterialTheme.typography.titleSmall,
                            color = if (journey.accessibilityVerified) tokens.verifiedBadgeInk else tokens.warningBadgeInk
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = journey.accessibilityDisclosure,
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.primaryInk
                        )
                    }
                }
            }

            // Fare Restrictions & Price Breakdown
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Outlined.ReceiptLong, contentDescription = null, tint = tokens.accentOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Fare Conditions & Price Breakdown",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = tokens.primaryInk
                        )
                    }
                    Text(
                        text = journey.fareOffer.conditions.summaryText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.secondaryInk
                    )
                    Text(
                        text = "Includes ${journey.fareOffer.conditions.carryOnBagsIncluded} carry-on bags • Seat selection included",
                        style = MaterialTheme.typography.bodySmall,
                        color = tokens.secondaryInk
                    )

                    HorizontalDivider(color = tokens.divider)

                    val pax = query.passengerCount
                    PriceLine("Base fare ($pax ${if (pax == 1) "adult" else "adults"})", TexasRailTime.formatMoneyExact(journey.fareOffer.baseFarePerPassenger * pax))
                    PriceLine("Taxes & state transit levy", TexasRailTime.formatMoneyExact(journey.fareOffer.taxPerPassenger * pax))
                    PriceLine("Booking & platform fee", TexasRailTime.formatMoneyExact(journey.fareOffer.feePerPassenger * pax))
                    HorizontalDivider(color = tokens.divider)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total (${journey.fareOffer.totalPerPassenger.currency})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text(
                            TexasRailTime.formatMoneyExact(journey.fareOffer.totalForPassengers(pax)),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                            color = tokens.accentOrange
                        )
                    }
                    if (journey.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Info, contentDescription = null, tint = tokens.secondaryInk, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Illustrative demonstration fare. No real travel validity.",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.secondaryInk
                            )
                        }
                    }
                }
            }
        }

        // Sticky CTA bar
        Surface(
            color = tokens.cardSurface,
            shadowElevation = 6.dp,
            border = BorderStroke(1.dp, tokens.divider),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Button(
                    onClick = { onProceedToBooking(journey) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = tokens.accentOrange,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .widthIn(max = 600.dp)
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("continue_to_booking_button")
                ) {
                    Text(
                        text = if (journey.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                            "Continue to demo booking"
                        } else {
                            "Continue to booking"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
private fun StopTimelineRow(
    time: String,
    stationName: String,
    subtitle: String,
    isEndpoint: Boolean
) {
    val tokens = LocalTexasRailTokens.current
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Text(
            text = time,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = tokens.primaryInk,
            modifier = Modifier.width(74.dp)
        )
        Box(
            modifier = Modifier
                .padding(top = 4.dp)
                .size(if (isEndpoint) 12.dp else 8.dp)
                .background(if (isEndpoint) tokens.accentOrange else tokens.secondaryInk, CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = stationName,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = if (isEndpoint) FontWeight.Bold else FontWeight.Medium
                ),
                color = tokens.primaryInk
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = tokens.secondaryInk
            )
        }
    }
}

@Composable
private fun PriceLine(label: String, value: String) {
    val tokens = LocalTexasRailTokens.current
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = tokens.secondaryInk)
        Text(value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = tokens.primaryInk)
    }
}
