package com.example.core.model

import kotlinx.serialization.Serializable
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate

enum class OperatingMode {
    CONCEPT_DEMONSTRATION,
    CONNECTED_SERVICES
}

enum class CorridorPattern {
    SOLID,
    DASHED,
    DOTTED
}

enum class CalendarExceptionType {
    ADDED,
    REMOVED
}

enum class AlertSeverity {
    INFO,
    ADVISORY,
    DISRUPTION
}

enum class ServiceStatus {
    SCHEDULED_ILLUSTRATIVE,
    ON_TIME,
    DELAYED,
    CANCELLED
}

enum class JourneyFilter {
    FASTEST,
    LOWEST_FARE,
    DIRECT,
    ACCESSIBLE
}

enum class ReservationStatus {
    HELD,
    CONFIRMED,
    EXPIRED,
    RELEASED
}

enum class BookingStatus {
    CONFIRMED,
    CANCELLED,
    REFUNDED
}

enum class PaymentStatus {
    REQUIRES_CONFIRMATION,
    SUCCEEDED,
    FAILED,
    CANCELLED,
    REFUNDED
}

enum class PassengerType {
    ADULT,
    YOUTH,
    SENIOR,
    ACCESSIBLE_COMPANION
}

enum class ThemePreference {
    SYSTEM,
    LIGHT,
    DARK
}

@Serializable
data class Money(
    val cents: Long,
    val currency: String = "USD"
) {
    fun toBigDecimal(): BigDecimal = BigDecimal.valueOf(cents, 2)

    operator fun plus(other: Money): Money {
        require(currency == other.currency) { "Currency mismatch: $currency vs ${other.currency}" }
        return Money(cents + other.cents, currency)
    }

    operator fun times(multiplier: Int): Money = Money(cents * multiplier, currency)

    companion object {
        fun fromDollars(dollars: String, currency: String = "USD"): Money {
            val bd = BigDecimal(dollars).setScale(2, RoundingMode.HALF_UP)
            return Money(bd.movePointRight(2).longValueExact(), currency)
        }
    }
}

data class DatasetVersion(
    val id: String,
    val operatingMode: OperatingMode,
    val sourceName: String,
    val publishedAt: Instant,
    val lastSyncedAt: Instant,
    val checksum: String
)

data class StationAccessibility(
    val stepFreeAccess: Boolean?,
    val levelBoarding: Boolean?,
    val tactileGuidance: Boolean?,
    val accessibleRestrooms: Boolean?,
    val assistanceDesk: Boolean?,
    val audioInductionLoops: Boolean?
) {
    val isVerifiedStepFree: Boolean
        get() = stepFreeAccess == true && levelBoarding == true
}

data class StationParkingBikes(
    val structuredParkingSpaces: Int?,
    val evChargers: Int?,
    val coveredBikeRacks: Int?,
    val bikeLockers: Int?
)

data class Platform(
    val id: String,
    val stationId: String,
    val code: String,
    val levelBoarding: Boolean?,
    val tactilePaving: Boolean?,
    val notes: String?
)

data class Station(
    val id: String,
    val code: String,
    val name: String,
    val city: String,
    val timeZoneId: String,
    val latitude: Double,
    val longitude: Double,
    val schematicX: Float,
    val schematicY: Float,
    val isMajorCity: Boolean,
    val address: String,
    val entrances: List<String>,
    val accessibility: StationAccessibility,
    val parkingBikes: StationParkingBikes,
    val localTransitConnections: List<String>,
    val openingHours: String?,
    val sourceId: String,
    val provenance: String
)

data class Route(
    val id: String,
    val shortCode: String,
    val name: String,
    val corridorColorHex: Long,
    val corridorPattern: CorridorPattern,
    val operatorName: String,
    val operatingMode: OperatingMode,
    val sourceId: String,
    val provenance: String
)

data class RoutePattern(
    val id: String,
    val routeId: String,
    val direction: String,
    val headsign: String,
    val stationSequence: List<String>
)

data class ServiceCalendar(
    val id: String,
    val monday: Boolean,
    val tuesday: Boolean,
    val wednesday: Boolean,
    val thursday: Boolean,
    val friday: Boolean,
    val saturday: Boolean,
    val sunday: Boolean,
    val startDate: LocalDate,
    val endDate: LocalDate
)

data class CalendarException(
    val id: String,
    val serviceCalendarId: String,
    val date: LocalDate,
    val type: CalendarExceptionType
)

data class Trip(
    val id: String,
    val routeId: String,
    val patternId: String,
    val serviceCalendarId: String,
    val trainNumber: String,
    val serviceName: String,
    val wheelchairAccessible: Boolean?,
    val levelBoardingVerified: Boolean?,
    val amenities: List<String>,
    val operatingMode: OperatingMode,
    val sourceId: String,
    val provenance: String
)

data class StopTime(
    val id: String,
    val tripId: String,
    val stationId: String,
    val platformCode: String?,
    val stopSequence: Int,
    val arrivalOffsetSeconds: Int,
    val departureOffsetSeconds: Int,
    val dayOffset: Int,
    val pickupAllowed: Boolean = true,
    val dropoffAllowed: Boolean = true
)

data class Transfer(
    val id: String,
    val fromStationId: String,
    val toStationId: String,
    val minTransferMinutes: Int,
    val walkingDistanceMeters: Int,
    val accessiblePath: Boolean?
)

data class ServiceAlert(
    val id: String,
    val routeId: String?,
    val stationId: String?,
    val title: String,
    val description: String,
    val severity: AlertSeverity,
    val startsAt: Instant,
    val endsAt: Instant?,
    val operatingMode: OperatingMode,
    val sourceId: String
)

data class RealtimePrediction(
    val tripId: String,
    val stationId: String,
    val predictedDepartureInstant: Instant?,
    val predictedArrivalInstant: Instant?,
    val delayMinutes: Int,
    val platformCode: String?,
    val status: ServiceStatus,
    val observedAt: Instant
)

data class DepartureBoardEntry(
    val tripId: String,
    val trainNumber: String,
    val routeShortCode: String,
    val routeName: String,
    val destinationStationName: String,
    val scheduledDeparture: Instant,
    val predictedDeparture: Instant?,
    val stationZoneId: String,
    val platformCode: String?,
    val status: ServiceStatus,
    val delayMinutes: Int,
    val operatingMode: OperatingMode
)

@Serializable
data class FareCondition(
    val fareClass: String,
    val refundableUntilHoursBefore: Int,
    val refundFeePercent: Int,
    val exchangeAllowed: Boolean,
    val exchangeFeeCents: Long,
    val seatSelectionIncluded: Boolean,
    val carryOnBagsIncluded: Int,
    val summaryText: String,
    val capturedAtEpochMillis: Long
)

data class FareOffer(
    val id: String,
    val tripIds: List<String>,
    val fareClass: String,
    val baseFarePerPassenger: Money,
    val taxPerPassenger: Money,
    val feePerPassenger: Money,
    val availableSeats: Int?,
    val seatAvailabilitySupported: Boolean,
    val expiresAt: Instant,
    val conditions: FareCondition,
    val operatingMode: OperatingMode
) {
    val totalPerPassenger: Money
        get() = baseFarePerPassenger + taxPerPassenger + feePerPassenger

    fun totalForPassengers(count: Int): Money = totalPerPassenger * count
}

data class InventoryReservation(
    val id: String,
    val idempotencyKey: String,
    val tripIds: List<String>,
    val serviceDate: LocalDate,
    val fareClass: String,
    val passengerCount: Int,
    val requestedSeats: List<String>,
    val subtotal: Money,
    val tax: Money,
    val fee: Money,
    val total: Money,
    val fareConditionSnapshot: FareCondition,
    val status: ReservationStatus,
    val expiresAt: Instant,
    val createdAt: Instant
)

data class Passenger(
    val id: String,
    val fullName: String,
    val passengerType: PassengerType,
    val email: String = "",
    val accessibilityNotes: String = ""
)

data class SeatAssignment(
    val segmentId: String,
    val coach: String,
    val seatNumber: String,
    val isAccessibleSpace: Boolean
)

data class BookingSegment(
    val id: String,
    val tripId: String,
    val trainNumber: String,
    val routeName: String,
    val originStationId: String,
    val originStationName: String,
    val originZoneId: String,
    val destinationStationId: String,
    val destinationStationName: String,
    val destinationZoneId: String,
    val departureInstant: Instant,
    val arrivalInstant: Instant,
    val platformCode: String?
)

data class Payment(
    val id: String,
    val reservationId: String,
    val idempotencyKey: String,
    val providerName: String,
    val paymentMethodSummary: String,
    val amount: Money,
    val status: PaymentStatus,
    val createdAt: Instant
)

data class Refund(
    val id: String,
    val bookingId: String,
    val amount: Money,
    val reason: String,
    val refundedAt: Instant
)

data class Ticket(
    val id: String,
    val bookingId: String,
    val referenceCode: String,
    val qrPayload: String,
    val isDemonstration: Boolean,
    val demoDisclaimer: String,
    val issuerName: String,
    val issuedAt: Instant
)

data class Booking(
    val id: String,
    val userId: String,
    val referenceCode: String,
    val operatingMode: OperatingMode,
    val status: BookingStatus,
    val serviceDate: LocalDate,
    val passengers: List<Passenger>,
    val segments: List<BookingSegment>,
    val seats: List<SeatAssignment>,
    val total: Money,
    val fareConditionSnapshot: FareCondition,
    val ticket: Ticket,
    val createdAt: Instant,
    val cachedAt: Instant
)

data class SavedJourney(
    val id: String,
    val originStationId: String,
    val destinationStationId: String,
    val label: String,
    val createdAt: Instant
)

data class RecentSearch(
    val id: String,
    val originStationId: String,
    val destinationStationId: String,
    val serviceDate: LocalDate,
    val passengerCount: Int,
    val searchedAt: Instant
)

data class JourneyStopPoint(
    val station: Station,
    val arrivalInstant: Instant?,
    val departureInstant: Instant?,
    val platformCode: String?
)

sealed class JourneyLeg {
    data class RailRide(
        val trip: Trip,
        val route: Route,
        val originStop: JourneyStopPoint,
        val destinationStop: JourneyStopPoint,
        val intermediateStops: List<JourneyStopPoint>,
        val durationMinutes: Long,
        val serviceStatus: ServiceStatus
    ) : JourneyLeg()

    data class TransferWalk(
        val station: Station,
        val minConnectionMinutes: Int,
        val walkingDistanceMeters: Int,
        val accessiblePath: Boolean?,
        val waitDurationMinutes: Long
    ) : JourneyLeg()
}

data class JourneyOption(
    val id: String,
    val legs: List<JourneyLeg>,
    val originStation: Station,
    val destinationStation: Station,
    val departureInstant: Instant,
    val arrivalInstant: Instant,
    val totalDurationMinutes: Long,
    val transferCount: Int,
    val fareOffer: FareOffer,
    val serviceStatus: ServiceStatus,
    val accessibilityVerified: Boolean,
    val accessibilityDisclosure: String,
    val operatingMode: OperatingMode
) {
    val isDirect: Boolean get() = transferCount == 0
}

data class JourneySearchQuery(
    val originStationId: String,
    val destinationStationId: String,
    val serviceDate: LocalDate,
    val passengerCount: Int = 1,
    val activeFilters: Set<JourneyFilter> = emptySet()
)

data class UserProfile(
    val userId: String,
    val email: String,
    val displayName: String,
    val isSignedIn: Boolean
)
