package com.example.feature.account

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.database.AppPreferences
import com.example.core.database.InventoryAndBookingDao
import com.example.core.database.PreferencesRepository
import com.example.core.database.SavedPassengerEntity
import com.example.core.database.UserLibraryDao
import com.example.core.model.DatasetVersion
import com.example.core.model.NetworkProvider
import com.example.core.model.OperatingMode
import com.example.core.model.Passenger
import com.example.core.model.PassengerType
import com.example.core.model.SavedJourney
import com.example.core.model.ThemePreference
import com.example.core.network.TexasRailApiFactory
import com.example.data.timetables.DatabaseMappers.toDomain
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID
import javax.inject.Inject

@Serializable
data class AccountExportBundle(
    val userId: String,
    val email: String,
    val displayName: String,
    val operatingMode: String,
    val savedPassengers: List<String>,
    val savedJourneys: List<String>,
    val bookingReferences: List<String>
)

data class AccountUiState(
    val preferences: AppPreferences = AppPreferences(),
    val datasetVersion: DatasetVersion? = null,
    val savedPassengers: List<Passenger> = emptyList(),
    val savedJourneys: List<SavedJourney> = emptyList(),
    val statusBanner: String? = null,
    val exportedJson: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class AccountViewModel @Inject constructor(
    private val preferencesRepository: PreferencesRepository,
    private val networkProvider: NetworkProvider,
    private val userLibraryDao: UserLibraryDao,
    private val bookingDao: InventoryAndBookingDao,
    private val apiFactory: TexasRailApiFactory
) : ViewModel() {

    private val _statusBanner = MutableStateFlow<String?>(null)
    private val _exportedJson = MutableStateFlow<String?>(null)
    private val prettyJson = Json { prettyPrint = true }

    private val userDataFlow = preferencesRepository.preferencesFlow.flatMapLatest { prefs ->
        combine(
            userLibraryDao.observeSavedPassengers(prefs.userProfile.userId),
            userLibraryDao.observeSavedJourneys(prefs.userProfile.userId)
        ) { pax, journeys ->
            pax.map { it.toDomain() } to journeys.map { it.toDomain() }
        }
    }

    val uiState: StateFlow<AccountUiState> = combine(
        preferencesRepository.preferencesFlow,
        networkProvider.observeDatasetVersion(),
        userDataFlow,
        _statusBanner,
        _exportedJson
    ) { prefs, version, (pax, journeys), banner, exported ->
        AccountUiState(
            preferences = prefs,
            datasetVersion = version,
            savedPassengers = pax,
            savedJourneys = journeys,
            statusBanner = banner,
            exportedJson = exported
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AccountUiState()
    )

    fun switchOperatingMode(mode: OperatingMode, connectedUrl: String) {
        viewModelScope.launch {
            if (mode == OperatingMode.CONCEPT_DEMONSTRATION) {
                networkProvider.setOperatingMode(mode, connectedUrl)
                networkProvider.refreshSnapshot(force = true)
                _statusBanner.value = "Switched to Concept Demonstration mode."
            } else {
                // Verify connected backend URL health before claiming connected data is active
                val health = runCatching {
                    apiFactory.create(connectedUrl).getHealth()
                }
                if (health.isSuccess) {
                    networkProvider.setOperatingMode(mode, connectedUrl)
                    networkProvider.refreshSnapshot(force = true)
                    _statusBanner.value = "Connected to verified service (${health.getOrNull()?.mode}). Operator ticketing remains gated until authorized."
                } else {
                    _statusBanner.value = "Unable to reach Connected Services at $connectedUrl. Staying in Concept Demonstration mode."
                }
            }
        }
    }

    fun signInOptional(email: String, displayName: String) {
        if (email.isBlank() || !email.contains("@")) {
            _statusBanner.value = "Please enter a valid email address to sign in."
            return
        }
        viewModelScope.launch {
            val cleanEmail = email.trim().lowercase()
            val cleanName = displayName.trim().ifBlank { cleanEmail.substringBefore("@") }
            val userId = "usr_${cleanEmail.hashCode().toUInt()}"
            val opaqueToken = "txr_tok_${UUID.randomUUID()}"
            preferencesRepository.signIn(userId, cleanEmail, cleanName, opaqueToken)
            _statusBanner.value = "Signed in as $cleanName. Token stored in Android Keystore."
        }
    }

    fun signOut() {
        viewModelScope.launch {
            preferencesRepository.signOut()
            _statusBanner.value = "Signed out. Switched to Guest Traveler profile."
        }
    }

    fun addSavedPassenger(name: String, type: PassengerType) {
        if (name.trim().length < 2) return
        viewModelScope.launch {
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            userLibraryDao.upsertSavedPassenger(
                SavedPassengerEntity(
                    id = UUID.randomUUID().toString(),
                    userId = userId,
                    fullName = name.trim(),
                    passengerType = type.name,
                    email = "",
                    accessibilityNotes = ""
                )
            )
        }
    }

    fun removeSavedPassenger(id: String) {
        viewModelScope.launch {
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            userLibraryDao.deleteSavedPassenger(id, userId)
        }
    }

    fun removeSavedJourney(id: String) {
        viewModelScope.launch {
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            userLibraryDao.deleteSavedJourney(id, userId)
        }
    }

    fun setTheme(theme: ThemePreference) {
        viewModelScope.launch { preferencesRepository.setThemePreference(theme) }
    }

    fun setLanguage(code: String) {
        viewModelScope.launch { preferencesRepository.setLanguageCode(code) }
    }

    fun setNotifications(delayAlerts: Boolean, tripReminders: Boolean) {
        viewModelScope.launch { preferencesRepository.setNotificationPreferences(delayAlerts, tripReminders) }
    }

    fun exportAccountData() {
        viewModelScope.launch {
            val prefs = preferencesRepository.preferencesFlow.first()
            val userId = prefs.userProfile.userId
            val pax = userLibraryDao.observeSavedPassengers(userId).first()
            val trips = userLibraryDao.observeSavedJourneys(userId).first()
            val bookings = bookingDao.observeBookingsForUser(userId).first()
            val bundle = AccountExportBundle(
                userId = userId,
                email = prefs.userProfile.email,
                displayName = prefs.userProfile.displayName,
                operatingMode = prefs.operatingMode.name,
                savedPassengers = pax.map { "${it.fullName} (${it.passengerType})" },
                savedJourneys = trips.map { it.label },
                bookingReferences = bookings.map { "${it.referenceCode} [${it.status}]" }
            )
            _exportedJson.value = prettyJson.encodeToString(bundle)
        }
    }

    fun dismissExport() {
        _exportedJson.value = null
    }

    fun deleteAccountAndData() {
        viewModelScope.launch {
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            bookingDao.deleteBookingsForUser(userId)
            bookingDao.deleteReservationsForUser(userId)
            userLibraryDao.deleteAllSavedPassengersForUser(userId)
            userLibraryDao.deleteAllSavedJourneysForUser(userId)
            preferencesRepository.signOut()
            _statusBanner.value = "Account data, saved passengers, and local bookings erased."
        }
    }
}
