package com.example.core.network

import com.example.core.database.EncryptedTokenStore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Serializable
data class ApiHealthDto(
    val status: String,
    val mode: String,
    val timestampUtc: String
)

@Serializable
data class ApiDatasetVersionDto(
    val id: String,
    val operating_mode: String,
    val source_name: String,
    val published_at: String,
    val checksum: String
)

@Serializable
data class ApiDepartureEntryDto(
    val trip_id: String,
    val train_number: String,
    val service_name: String,
    val operating_mode: String,
    val departure_offset_seconds: Int,
    val day_offset: Int,
    val short_code: String,
    val route_name: String
)

@Serializable
data class ApiDeparturesResponseDto(
    val stationId: String,
    val operatingMode: String,
    val refreshedAtUtc: String,
    val isLiveTelemetryAvailable: Boolean = false,
    val departures: List<ApiDepartureEntryDto> = emptyList()
)

@Serializable
data class ApiServiceAlertDto(
    val id: String,
    val route_id: String? = null,
    val station_id: String? = null,
    val title: String,
    val description: String,
    val severity: String,
    val starts_at: String,
    val ends_at: String? = null,
    val operating_mode: String,
    val source_id: String
)

@Serializable
data class ApiNetworkSnapshotDto(
    val datasetVersion: ApiDatasetVersionDto? = null,
    val operatingMode: String,
    val alerts: List<ApiServiceAlertDto> = emptyList()
)

interface TexasRailApi {
    @GET("health")
    suspend fun getHealth(): ApiHealthDto

    @GET("v1/network/snapshot")
    suspend fun getNetworkSnapshot(@Query("sinceVersion") sinceVersion: String? = null): ApiNetworkSnapshotDto

    @GET("v1/stations/{stationId}/departures")
    suspend fun getDepartures(@Path("stationId") stationId: String): ApiDeparturesResponseDto

    @GET("v1/alerts")
    suspend fun getAlerts(): List<ApiServiceAlertDto>
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(tokenStore: EncryptedTokenStore): OkHttpClient {
        val logging = HttpLoggingInterceptor { message ->
            // Redact Authorization headers or token fragments in logs
            val sanitized = if (message.contains("Authorization", ignoreCase = true)) {
                "Authorization: Bearer [REDACTED]"
            } else {
                message
            }
            android.util.Log.d("TexasRailNet", sanitized)
        }.apply {
            level = HttpLoggingInterceptor.Level.BASIC
            redactHeader("Authorization")
            redactHeader("Cookie")
        }

        val authInterceptor = Interceptor { chain ->
            val token = tokenStore.getSessionToken()
            val req = if (!token.isNullOrBlank()) {
                chain.request().newBuilder()
                    .header("Authorization", "Bearer $token")
                    .build()
            } else {
                chain.request()
            }
            chain.proceed(req)
        }

        return OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofitFactory(okHttpClient: OkHttpClient, json: Json): TexasRailApiFactory {
        return TexasRailApiFactory(okHttpClient, json)
    }
}

class TexasRailApiFactory(
    private val okHttpClient: OkHttpClient,
    private val json: Json
) {
    fun create(baseUrl: String): TexasRailApi {
        val normalized = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return Retrofit.Builder()
            .baseUrl(normalized)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(TexasRailApi::class.java)
    }
}
