package com.example.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.JourneyFilter
import com.example.core.model.JourneyOption
import com.example.core.model.JourneySearchQuery
import com.example.core.model.NetworkProvider
import com.example.core.model.OperatingMode
import com.example.core.model.Station
import com.example.core.model.TimetableProvider
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

sealed class ResultsState {
    data object Loading : ResultsState()
    data class Success(
        val query: JourneySearchQuery,
        val origin: Station?,
        val destination: Station?,
        val options: List<JourneyOption>,
        val operatingMode: OperatingMode,
        val highlightedOptionId: String?
    ) : ResultsState()
    data class Error(val message: String) : ResultsState()
}

@HiltViewModel
class JourneyResultsViewModel @Inject constructor(
    private val timetableProvider: TimetableProvider,
    private val networkProvider: NetworkProvider,
    private val searchSessionStore: SearchSessionStore
) : ViewModel() {

    private val _uiState = MutableStateFlow<ResultsState>(ResultsState.Loading)
    val uiState: StateFlow<ResultsState> = _uiState.asStateFlow()

    private var highlightedId: String? = null

    fun load(originId: String, destinationId: String, dateIso: String, passengerCount: Int) {
        val date = runCatching { LocalDate.parse(dateIso) }.getOrDefault(LocalDate.of(2026, 5, 14))
        searchSessionStore.updateRoute(originId, destinationId)
        searchSessionStore.updateDate(date)
        searchSessionStore.updatePassengerCount(passengerCount)
        executeSearch()
    }

    fun changeDate(date: LocalDate) {
        searchSessionStore.updateDate(date)
        executeSearch()
    }

    fun toggleFilter(filter: JourneyFilter) {
        searchSessionStore.toggleFilter(filter)
        executeSearch()
    }

    fun highlightOption(optionId: String) {
        highlightedId = optionId
        val cur = _uiState.value
        if (cur is ResultsState.Success) {
            _uiState.value = cur.copy(highlightedOptionId = optionId)
        }
    }

    fun selectJourneyForDetail(option: JourneyOption) {
        searchSessionStore.selectJourney(option)
    }

    fun executeSearch() {
        viewModelScope.launch {
            _uiState.value = ResultsState.Loading
            runCatching {
                val query = searchSessionStore.query.value
                val origin = timetableProvider.getStation(query.originStationId)
                val dest = timetableProvider.getStation(query.destinationStationId)
                val options = timetableProvider.searchJourneys(query)
                val mode = networkProvider.observeOperatingMode().first()
                searchSessionStore.setResults(options)
                if (highlightedId == null || options.none { it.id == highlightedId }) {
                    highlightedId = options.firstOrNull()?.id
                }
                ResultsState.Success(
                    query = query,
                    origin = origin,
                    destination = dest,
                    options = options,
                    operatingMode = mode,
                    highlightedOptionId = highlightedId
                )
            }.onSuccess {
                _uiState.value = it
            }.onFailure { err ->
                _uiState.value = ResultsState.Error(err.message ?: "Unable to search journeys")
            }
        }
    }
}
