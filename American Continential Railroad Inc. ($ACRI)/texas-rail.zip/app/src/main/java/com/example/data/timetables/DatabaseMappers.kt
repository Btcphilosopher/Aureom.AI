package com.example.data.timetables

import com.example.core.database.BookingEntity
import com.example.core.database.CalendarExceptionEntity
import com.example.core.database.DatasetVersionEntity
import com.example.core.database.InventoryReservationEntity
import com.example.core.database.RouteEntity
import com.example.core.database.RoutePatternEntity
import com.example.core.database.SavedJourneyEntity
import com.example.core.database.SavedPassengerEntity
import com.example.core.database.ServiceAlertEntity
import com.example.core.database.ServiceCalendarEntity
import com.example.core.database.StationEntity
import com.example.core.database.StopTimeEntity
import com.example.core.database.TransferEntity
import com.example.core.database.TripEntity
import com.example.core.model.AlertSeverity
import com.example.core.model.Booking
import com.example.core.model.BookingSegment
import com.example.core.model.BookingStatus
import com.example.core.model.CalendarException
import com.example.core.model.CalendarExceptionType
import com.example.core.model.CorridorPattern
import com.example.core.model.DatasetVersion
import com.example.core.model.FareCondition
import com.example.core.model.InventoryReservation
import com.example.core.model.Money
import com.example.core.model.OperatingMode
import com.example.core.model.Passenger
import com.example.core.model.PassengerType
import com.example.core.model.ReservationStatus
import com.example.core.model.Route
import com.example.core.model.RoutePattern
import com.example.core.model.SavedJourney
import com.example.core.model.SeatAssignment
import com.example.core.model.ServiceAlert
import com.example.core.model.ServiceCalendar
import com.example.core.model.Station
import com.example.core.model.StationAccessibility
import com.example.core.model.StationParkingBikes
import com.example.core.model.StopTime
import com.example.core.model.Ticket
import com.example.core.model.Transfer
import com.example.core.model.Trip
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.LocalDate

@Serializable
data class PassengerDto(
    val id: String,
    val fullName: String,
    val passengerType: String,
    val email: String = "",
    val accessibilityNotes: String = ""
)

@Serializable
data class BookingSegmentDto(
    val id: String,
    val tripId: String,
    val trainNumber: String,
    val routeName: String,
    val originStationId: String,
    val originStationName: String,
    val originZoneId: String,
    val destinationStationId: String,
    val destinationStationName: String,
    val destinationZoneId: String,
    val departureMillis: Long,
    val arrivalMillis: Long,
    val platformCode: String? = null
)

@Serializable
data class SeatAssignmentDto(
    val segmentId: String,
    val coach: String,
    val seatNumber: String,
    val isAccessibleSpace: Boolean
)

object DatabaseMappers {
    val json = Json { ignoreUnknownKeys = true }

    fun DatasetVersionEntity.toDomain(): DatasetVersion = DatasetVersion(
        id = id,
        operatingMode = OperatingMode.valueOf(operatingMode),
        sourceName = sourceName,
        publishedAt = Instant.ofEpochMilli(publishedAtMillis),
        lastSyncedAt = Instant.ofEpochMilli(lastSyncedAtMillis),
        checksum = checksum
    )

    fun StationEntity.toDomain(): Station {
        val acc = json.decodeFromString<AccessibilityDto>(accessibilityJson)
        val park = json.decodeFromString<ParkingBikesDto>(parkingBikesJson)
        return Station(
            id = id,
            code = code,
            name = name,
            city = city,
            timeZoneId = timeZoneId,
            latitude = latitude,
            longitude = longitude,
            schematicX = schematicX,
            schematicY = schematicY,
            isMajorCity = isMajorCity,
            address = address,
            entrances = json.decodeFromString(entrancesJson),
            accessibility = StationAccessibility(
                stepFreeAccess = acc.stepFreeAccess,
                levelBoarding = acc.levelBoarding,
                tactileGuidance = acc.tactileGuidance,
                accessibleRestrooms = acc.accessibleRestrooms,
                assistanceDesk = acc.assistanceDesk,
                audioInductionLoops = acc.audioInductionLoops
            ),
            parkingBikes = StationParkingBikes(
                structuredParkingSpaces = park.structuredParkingSpaces,
                evChargers = park.evChargers,
                coveredBikeRacks = park.coveredBikeRacks,
                bikeLockers = park.bikeLockers
            ),
            localTransitConnections = json.decodeFromString(localTransitJson),
            openingHours = openingHours,
            sourceId = sourceId,
            provenance = provenance
        )
    }

    fun RouteEntity.toDomain(): Route = Route(
        id = id,
        shortCode = shortCode,
        name = name,
        corridorColorHex = corridorColorHex,
        corridorPattern = CorridorPattern.valueOf(corridorPattern),
        operatorName = operatorName,
        operatingMode = OperatingMode.valueOf(operatingMode),
        sourceId = sourceId,
        provenance = provenance
    )

    fun RoutePatternEntity.toDomain(): RoutePattern = RoutePattern(
        id = id,
        routeId = routeId,
        direction = direction,
        headsign = headsign,
        stationSequence = json.decodeFromString(stationSequenceJson)
    )

    fun ServiceCalendarEntity.toDomain(): ServiceCalendar = ServiceCalendar(
        id = id,
        monday = monday,
        tuesday = tuesday,
        wednesday = wednesday,
        thursday = thursday,
        friday = friday,
        saturday = saturday,
        sunday = sunday,
        startDate = LocalDate.parse(startDateIso),
        endDate = LocalDate.parse(endDateIso)
    )

    fun CalendarExceptionEntity.toDomain(): CalendarException = CalendarException(
        id = id,
        serviceCalendarId = serviceCalendarId,
        date = LocalDate.parse(dateIso),
        type = CalendarExceptionType.valueOf(type)
    )

    fun TripEntity.toDomain(): Trip = Trip(
        id = id,
        routeId = routeId,
        patternId = patternId,
        serviceCalendarId = serviceCalendarId,
        trainNumber = trainNumber,
        serviceName = serviceName,
        wheelchairAccessible = wheelchairAccessible,
        levelBoardingVerified = levelBoardingVerified,
        amenities = json.decodeFromString(amenitiesJson),
        operatingMode = OperatingMode.valueOf(operatingMode),
        sourceId = sourceId,
        provenance = provenance
    )

    fun StopTimeEntity.toDomain(): StopTime = StopTime(
        id = id,
        tripId = tripId,
        stationId = stationId,
        platformCode = platformCode,
        stopSequence = stopSequence,
        arrivalOffsetSeconds = arrivalOffsetSeconds,
        departureOffsetSeconds = departureOffsetSeconds,
        dayOffset = dayOffset,
        pickupAllowed = pickupAllowed,
        dropoffAllowed = dropoffAllowed
    )

    fun TransferEntity.toDomain(): Transfer = Transfer(
        id = id,
        fromStationId = fromStationId,
        toStationId = toStationId,
        minTransferMinutes = minTransferMinutes,
        walkingDistanceMeters = walkingDistanceMeters,
        accessiblePath = accessiblePath
    )

    fun ServiceAlertEntity.toDomain(): ServiceAlert = ServiceAlert(
        id = id,
        routeId = routeId,
        stationId = stationId,
        title = title,
        description = description,
        severity = AlertSeverity.valueOf(severity),
        startsAt = Instant.ofEpochMilli(startsAtMillis),
        endsAt = endsAtMillis?.let { Instant.ofEpochMilli(it) },
        operatingMode = OperatingMode.valueOf(operatingMode),
        sourceId = sourceId
    )

    fun InventoryReservationEntity.toDomain(): InventoryReservation = InventoryReservation(
        id = id,
        idempotencyKey = idempotencyKey,
        tripIds = json.decodeFromString(tripIdsJson),
        serviceDate = LocalDate.parse(serviceDateIso),
        fareClass = fareClass,
        passengerCount = passengerCount,
        requestedSeats = json.decodeFromString(requestedSeatsJson),
        subtotal = Money(subtotalCents, currency),
        tax = Money(taxCents, currency),
        fee = Money(feeCents, currency),
        total = Money(totalCents, currency),
        fareConditionSnapshot = json.decodeFromString(fareConditionSnapshotJson),
        status = ReservationStatus.valueOf(status),
        expiresAt = Instant.ofEpochMilli(expiresAtMillis),
        createdAt = Instant.ofEpochMilli(createdAtMillis)
    )

    fun BookingEntity.toDomain(): Booking {
        val passengers = json.decodeFromString<List<PassengerDto>>(passengersJson).map {
            Passenger(
                id = it.id,
                fullName = it.fullName,
                passengerType = PassengerType.valueOf(it.passengerType),
                email = it.email,
                accessibilityNotes = it.accessibilityNotes
            )
        }
        val segments = json.decodeFromString<List<BookingSegmentDto>>(segmentsJson).map {
            BookingSegment(
                id = it.id,
                tripId = it.tripId,
                trainNumber = it.trainNumber,
                routeName = it.routeName,
                originStationId = it.originStationId,
                originStationName = it.originStationName,
                originZoneId = it.originZoneId,
                destinationStationId = it.destinationStationId,
                destinationStationName = it.destinationStationName,
                destinationZoneId = it.destinationZoneId,
                departureInstant = Instant.ofEpochMilli(it.departureMillis),
                arrivalInstant = Instant.ofEpochMilli(it.arrivalMillis),
                platformCode = it.platformCode
            )
        }
        val seats = json.decodeFromString<List<SeatAssignmentDto>>(seatsJson).map {
            SeatAssignment(it.segmentId, it.coach, it.seatNumber, it.isAccessibleSpace)
        }
        val fareCond = json.decodeFromString<FareCondition>(fareConditionSnapshotJson)
        val created = Instant.ofEpochMilli(createdAtMillis)
        return Booking(
            id = id,
            userId = userId,
            referenceCode = referenceCode,
            operatingMode = OperatingMode.valueOf(operatingMode),
            status = BookingStatus.valueOf(status),
            serviceDate = LocalDate.parse(serviceDateIso),
            passengers = passengers,
            segments = segments,
            seats = seats,
            total = Money(totalCents, currency),
            fareConditionSnapshot = fareCond,
            ticket = Ticket(
                id = "tkt_$id",
                bookingId = id,
                referenceCode = referenceCode,
                qrPayload = qrPayload,
                isDemonstration = isDemonstration,
                demoDisclaimer = demoDisclaimer,
                issuerName = issuerName,
                issuedAt = created
            ),
            createdAt = created,
            cachedAt = Instant.ofEpochMilli(cachedAtMillis)
        )
    }

    fun SavedJourneyEntity.toDomain(): SavedJourney = SavedJourney(
        id = id,
        originStationId = originStationId,
        destinationStationId = destinationStationId,
        label = label,
        createdAt = Instant.ofEpochMilli(createdAtMillis)
    )

    fun SavedPassengerEntity.toDomain(): Passenger = Passenger(
        id = id,
        fullName = fullName,
        passengerType = runCatching { PassengerType.valueOf(passengerType) }.getOrDefault(PassengerType.ADULT),
        email = email,
        accessibilityNotes = accessibilityNotes
    )
}
