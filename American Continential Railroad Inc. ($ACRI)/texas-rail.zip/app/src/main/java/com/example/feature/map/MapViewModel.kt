package com.example.feature.map

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.DatasetVersion
import com.example.core.model.JourneySearchQuery
import com.example.core.model.NetworkProvider
import com.example.core.model.OperatingMode
import com.example.core.model.Route
import com.example.core.model.RoutePattern
import com.example.core.model.Station
import com.example.core.model.TimetableProvider
import com.example.data.timetables.NetworkAndTimetableRepository
import com.example.feature.search.SearchSessionStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class MapCoordinateMode {
    SCHEMATIC,
    GEOGRAPHIC
}

data class MapUiState(
    val stations: List<Station> = emptyList(),
    val routes: List<Route> = emptyList(),
    val patterns: List<RoutePattern> = emptyList(),
    val query: JourneySearchQuery = JourneySearchQuery("st_dal", "st_aus", java.time.LocalDate.of(2026, 5, 14)),
    val operatingMode: OperatingMode = OperatingMode.CONCEPT_DEMONSTRATION,
    val datasetVersion: DatasetVersion? = null,
    val coordinateMode: MapCoordinateMode = MapCoordinateMode.SCHEMATIC,
    val selectedStation: Station? = null,
    val searchQuery: String = "",
    val showAccessibleList: Boolean = false
)

@HiltViewModel
class MapViewModel @Inject constructor(
    private val timetableRepo: NetworkAndTimetableRepository,
    timetableProvider: TimetableProvider,
    networkProvider: NetworkProvider,
    private val searchSessionStore: SearchSessionStore
) : ViewModel() {

    private val _coordinateMode = MutableStateFlow(MapCoordinateMode.SCHEMATIC)
    private val _selectedStationId = MutableStateFlow<String?>(null)
    private val _searchText = MutableStateFlow("")
    private val _showList = MutableStateFlow(false)

    init {
        viewModelScope.launch { timetableRepo.ensureSeeded() }
    }

    private val networkData = combine(
        timetableProvider.observeStations(),
        timetableProvider.observeRoutes(),
        timetableProvider.observeRoutePatterns(),
        networkProvider.observeOperatingMode(),
        networkProvider.observeDatasetVersion()
    ) { stations, routes, patterns, mode, version ->
        NetworkTuple(stations, routes, patterns, mode, version)
    }

    private val mapControls = combine(
        searchSessionStore.query,
        _coordinateMode,
        _selectedStationId,
        _searchText,
        _showList
    ) { query, coordMode, selectedId, searchText, showList ->
        ControlsTuple(query, coordMode, selectedId, searchText, showList)
    }

    val uiState: StateFlow<MapUiState> = combine(networkData, mapControls) { net, ctrl ->
        MapUiState(
            stations = net.stations,
            routes = net.routes,
            patterns = net.patterns,
            query = ctrl.query,
            operatingMode = net.mode,
            datasetVersion = net.version,
            coordinateMode = ctrl.coordMode,
            selectedStation = net.stations.firstOrNull { it.id == ctrl.selectedStationId },
            searchQuery = ctrl.searchText,
            showAccessibleList = ctrl.showList
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MapUiState()
    )

    fun setCoordinateMode(mode: MapCoordinateMode) {
        _coordinateMode.value = mode
    }

    fun selectStation(stationId: String?) {
        _selectedStationId.value = stationId
    }

    fun updateSearchQuery(text: String) {
        _searchText.value = text
    }

    fun setShowAccessibleList(show: Boolean) {
        _showList.value = show
    }

    fun planFrom(stationId: String) {
        if (stationId == searchSessionStore.query.value.destinationStationId) {
            searchSessionStore.swapOriginDestination()
        } else {
            searchSessionStore.updateOrigin(stationId)
        }
        _selectedStationId.value = null
    }

    fun planTo(stationId: String) {
        if (stationId == searchSessionStore.query.value.originStationId) {
            searchSessionStore.swapOriginDestination()
        } else {
            searchSessionStore.updateDestination(stationId)
        }
        _selectedStationId.value = null
    }

    private data class NetworkTuple(
        val stations: List<Station>,
        val routes: List<Route>,
        val patterns: List<RoutePattern>,
        val mode: OperatingMode,
        val version: DatasetVersion?
    )

    private data class ControlsTuple(
        val query: JourneySearchQuery,
        val coordMode: MapCoordinateMode,
        val selectedStationId: String?,
        val searchText: String,
        val showList: Boolean
    )
}
