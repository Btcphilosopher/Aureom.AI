package com.example.di

import com.example.core.model.AlertProvider
import com.example.core.model.BookingProvider
import com.example.core.model.FareProvider
import com.example.core.model.NetworkProvider
import com.example.core.model.PaymentProvider
import com.example.core.model.RealtimeProvider
import com.example.core.model.TicketIssuer
import com.example.core.model.TimetableProvider
import com.example.data.booking.FareBookingPaymentTicketRepository
import com.example.data.realtime.RealtimeAndAlertRepository
import com.example.data.timetables.NetworkAndTimetableRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindNetworkProvider(impl: NetworkAndTimetableRepository): NetworkProvider

    @Binds
    @Singleton
    abstract fun bindTimetableProvider(impl: NetworkAndTimetableRepository): TimetableProvider

    @Binds
    @Singleton
    abstract fun bindRealtimeProvider(impl: RealtimeAndAlertRepository): RealtimeProvider

    @Binds
    @Singleton
    abstract fun bindAlertProvider(impl: RealtimeAndAlertRepository): AlertProvider

    @Binds
    @Singleton
    abstract fun bindFareProvider(impl: FareBookingPaymentTicketRepository): FareProvider

    @Binds
    @Singleton
    abstract fun bindBookingProvider(impl: FareBookingPaymentTicketRepository): BookingProvider

    @Binds
    @Singleton
    abstract fun bindPaymentProvider(impl: FareBookingPaymentTicketRepository): PaymentProvider

    @Binds
    @Singleton
    abstract fun bindTicketIssuer(impl: FareBookingPaymentTicketRepository): TicketIssuer
}
