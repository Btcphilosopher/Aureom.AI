package com.example.core.database

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "dataset_versions")
data class DatasetVersionEntity(
    @PrimaryKey val id: String,
    val operatingMode: String,
    val sourceName: String,
    val publishedAtMillis: Long,
    val lastSyncedAtMillis: Long,
    val checksum: String
)

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val city: String,
    val timeZoneId: String,
    val latitude: Double,
    val longitude: Double,
    val schematicX: Float,
    val schematicY: Float,
    val isMajorCity: Boolean,
    val address: String,
    val entrancesJson: String,
    val accessibilityJson: String,
    val parkingBikesJson: String,
    val localTransitJson: String,
    val openingHours: String?,
    val sourceId: String,
    val provenance: String
)

@Entity(tableName = "routes")
data class RouteEntity(
    @PrimaryKey val id: String,
    val shortCode: String,
    val name: String,
    val corridorColorHex: Long,
    val corridorPattern: String,
    val operatorName: String,
    val operatingMode: String,
    val sourceId: String,
    val provenance: String
)

@Entity(tableName = "route_patterns")
data class RoutePatternEntity(
    @PrimaryKey val id: String,
    val routeId: String,
    val direction: String,
    val headsign: String,
    val stationSequenceJson: String
)

@Entity(tableName = "service_calendars")
data class ServiceCalendarEntity(
    @PrimaryKey val id: String,
    val monday: Boolean,
    val tuesday: Boolean,
    val wednesday: Boolean,
    val thursday: Boolean,
    val friday: Boolean,
    val saturday: Boolean,
    val sunday: Boolean,
    val startDateIso: String,
    val endDateIso: String
)

@Entity(tableName = "calendar_exceptions")
data class CalendarExceptionEntity(
    @PrimaryKey val id: String,
    val serviceCalendarId: String,
    val dateIso: String,
    val type: String
)

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val routeId: String,
    val patternId: String,
    val serviceCalendarId: String,
    val trainNumber: String,
    val serviceName: String,
    val wheelchairAccessible: Boolean?,
    val levelBoardingVerified: Boolean?,
    val amenitiesJson: String,
    val operatingMode: String,
    val sourceId: String,
    val provenance: String
)

@Entity(
    tableName = "stop_times",
    indices = [Index("tripId"), Index("stationId")]
)
data class StopTimeEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val stationId: String,
    val platformCode: String?,
    val stopSequence: Int,
    val arrivalOffsetSeconds: Int,
    val departureOffsetSeconds: Int,
    val dayOffset: Int,
    val pickupAllowed: Boolean,
    val dropoffAllowed: Boolean
)

@Entity(tableName = "transfers")
data class TransferEntity(
    @PrimaryKey val id: String,
    val fromStationId: String,
    val toStationId: String,
    val minTransferMinutes: Int,
    val walkingDistanceMeters: Int,
    val accessiblePath: Boolean?
)

@Entity(tableName = "service_alerts")
data class ServiceAlertEntity(
    @PrimaryKey val id: String,
    val routeId: String?,
    val stationId: String?,
    val title: String,
    val description: String,
    val severity: String,
    val startsAtMillis: Long,
    val endsAtMillis: Long?,
    val operatingMode: String,
    val sourceId: String
)

@Entity(
    tableName = "trip_inventory",
    primaryKeys = ["tripId", "serviceDateIso", "fareClass"]
)
data class TripInventoryEntity(
    val tripId: String,
    val serviceDateIso: String,
    val fareClass: String,
    val totalSeats: Int,
    val availableSeats: Int,
    val occupiedSeatsJson: String,
    val baseFareCents: Long,
    val taxCents: Long,
    val feeCents: Long,
    val currency: String
)

@Entity(
    tableName = "inventory_reservations",
    indices = [Index(value = ["idempotencyKey"], unique = true)]
)
data class InventoryReservationEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val idempotencyKey: String,
    val tripIdsJson: String,
    val serviceDateIso: String,
    val fareClass: String,
    val passengerCount: Int,
    val requestedSeatsJson: String,
    val subtotalCents: Long,
    val taxCents: Long,
    val feeCents: Long,
    val totalCents: Long,
    val currency: String,
    val fareConditionSnapshotJson: String,
    val status: String,
    val expiresAtMillis: Long,
    val createdAtMillis: Long
)

@Entity(
    tableName = "payment_records",
    indices = [Index(value = ["idempotencyKey"], unique = true)]
)
data class PaymentRecordEntity(
    @PrimaryKey val id: String,
    val reservationId: String,
    val idempotencyKey: String,
    val providerName: String,
    val paymentMethodSummary: String,
    val amountCents: Long,
    val currency: String,
    val status: String,
    val createdAtMillis: Long
)

@Entity(tableName = "processed_webhooks")
data class ProcessedWebhookEntity(
    @PrimaryKey val eventId: String,
    val paymentId: String,
    val eventType: String,
    val processedAtMillis: Long
)

@Entity(
    tableName = "bookings",
    indices = [Index("userId"), Index(value = ["reservationId"], unique = true)]
)
data class BookingEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val reservationId: String,
    val referenceCode: String,
    val operatingMode: String,
    val status: String,
    val serviceDateIso: String,
    val passengersJson: String,
    val segmentsJson: String,
    val seatsJson: String,
    val totalCents: Long,
    val currency: String,
    val fareConditionSnapshotJson: String,
    val qrPayload: String,
    val isDemonstration: Boolean,
    val demoDisclaimer: String,
    val issuerName: String,
    val createdAtMillis: Long,
    val cachedAtMillis: Long
)

@Entity(tableName = "saved_journeys")
data class SavedJourneyEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val originStationId: String,
    val destinationStationId: String,
    val label: String,
    val createdAtMillis: Long
)

@Entity(tableName = "saved_passengers")
data class SavedPassengerEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val fullName: String,
    val passengerType: String,
    val email: String,
    val accessibilityNotes: String
)

@Entity(tableName = "recent_searches")
data class RecentSearchEntity(
    @PrimaryKey val id: String,
    val originStationId: String,
    val destinationStationId: String,
    val serviceDateIso: String,
    val passengerCount: Int,
    val searchedAtMillis: Long
)

@Entity(tableName = "saved_stations")
data class SavedStationEntity(
    @PrimaryKey val stationId: String,
    val savedAtMillis: Long
)
