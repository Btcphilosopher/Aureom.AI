package com.example.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.database.PreferencesRepository
import com.example.core.database.RecentSearchEntity
import com.example.core.database.SavedJourneyEntity
import com.example.core.database.SavedStationEntity
import com.example.core.database.UserLibraryDao
import com.example.core.model.DatasetVersion
import com.example.core.model.JourneySearchQuery
import com.example.core.model.NetworkProvider
import com.example.core.model.OperatingMode
import com.example.core.model.RecentSearch
import com.example.core.model.SavedJourney
import com.example.core.model.Station
import com.example.core.model.TimetableProvider
import com.example.data.timetables.DatabaseMappers.toDomain
import com.example.data.timetables.NetworkAndTimetableRepository
import com.example.feature.search.SearchSessionStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class HomeUiState(
    val stations: List<Station> = emptyList(),
    val query: JourneySearchQuery = JourneySearchQuery("st_dal", "st_aus", LocalDate.of(2026, 5, 14)),
    val operatingMode: OperatingMode = OperatingMode.CONCEPT_DEMONSTRATION,
    val datasetVersion: DatasetVersion? = null,
    val recentSearches: List<RecentSearch> = emptyList(),
    val savedJourneys: List<SavedJourney> = emptyList(),
    val savedStationIds: Set<String> = emptySet(),
    val nearestStationMessage: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val timetableRepository: NetworkAndTimetableRepository,
    private val timetableProvider: TimetableProvider,
    private val networkProvider: NetworkProvider,
    private val preferencesRepository: PreferencesRepository,
    private val userLibraryDao: UserLibraryDao,
    private val searchSessionStore: SearchSessionStore
) : ViewModel() {

    init {
        viewModelScope.launch {
            timetableRepository.ensureSeeded()
        }
    }

    private val baseDataFlow = combine(
        timetableProvider.observeStations(),
        searchSessionStore.query,
        networkProvider.observeOperatingMode(),
        networkProvider.observeDatasetVersion()
    ) { stations, query, mode, version ->
        Quad(stations, query, mode, version)
    }

    private val libraryFlow = combine(
        userLibraryDao.observeRecentSearches(),
        userLibraryDao.observeSavedStations(),
        preferencesRepository.preferencesFlow
    ) { recent, savedStations, prefs ->
        Triple(recent, savedStations, prefs)
    }

    val uiState: StateFlow<HomeUiState> = combine(
        baseDataFlow,
        libraryFlow
    ) { (stations, query, mode, version), (recentEntities, savedStationEntities, prefs) ->
        val recent = recentEntities.map {
            RecentSearch(
                id = it.id,
                originStationId = it.originStationId,
                destinationStationId = it.destinationStationId,
                serviceDate = LocalDate.parse(it.serviceDateIso),
                passengerCount = it.passengerCount,
                searchedAt = Instant.ofEpochMilli(it.searchedAtMillis)
            )
        }
        val savedJourneys = userLibraryDao.observeSavedJourneys(prefs.userProfile.userId)
            .first()
            .map { it.toDomain() }

        HomeUiState(
            stations = stations,
            query = query,
            operatingMode = mode,
            datasetVersion = version,
            recentSearches = recent,
            savedJourneys = savedJourneys,
            savedStationIds = savedStationEntities.map { it.stationId }.toSet()
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState()
    )

    fun selectOrigin(stationId: String) {
        if (stationId == searchSessionStore.query.value.destinationStationId) {
            searchSessionStore.swapOriginDestination()
        } else {
            searchSessionStore.updateOrigin(stationId)
        }
    }

    fun selectDestination(stationId: String) {
        if (stationId == searchSessionStore.query.value.originStationId) {
            searchSessionStore.swapOriginDestination()
        } else {
            searchSessionStore.updateDestination(stationId)
        }
    }

    fun swapStations() = searchSessionStore.swapOriginDestination()

    fun selectDate(date: LocalDate) = searchSessionStore.updateDate(date)

    fun selectPassengerCount(count: Int) = searchSessionStore.updatePassengerCount(count)

    fun applyRecentOrSaved(originId: String, destinationId: String, date: LocalDate? = null, pax: Int? = null) {
        searchSessionStore.updateRoute(originId, destinationId)
        if (date != null) searchSessionStore.updateDate(date)
        if (pax != null) searchSessionStore.updatePassengerCount(pax)
    }

    fun recordSearch() {
        val q = searchSessionStore.query.value
        viewModelScope.launch {
            userLibraryDao.upsertRecentSearch(
                RecentSearchEntity(
                    id = "${q.originStationId}_${q.destinationStationId}",
                    originStationId = q.originStationId,
                    destinationStationId = q.destinationStationId,
                    serviceDateIso = q.serviceDate.toString(),
                    passengerCount = q.passengerCount,
                    searchedAtMillis = System.currentTimeMillis()
                )
            )
        }
    }

    fun saveCurrentTrip() {
        val q = searchSessionStore.query.value
        val stations = uiState.value.stations.associateBy { it.id }
        val origName = stations[q.originStationId]?.name ?: q.originStationId
        val destName = stations[q.destinationStationId]?.name ?: q.destinationStationId
        viewModelScope.launch {
            val userId = preferencesRepository.preferencesFlow.first().userProfile.userId
            userLibraryDao.insertSavedJourney(
                SavedJourneyEntity(
                    id = UUID.randomUUID().toString(),
                    userId = userId,
                    originStationId = q.originStationId,
                    destinationStationId = q.destinationStationId,
                    label = "$origName → $destName",
                    createdAtMillis = System.currentTimeMillis()
                )
            )
        }
    }

    fun toggleSavedStation(stationId: String) {
        viewModelScope.launch {
            if (stationId in uiState.value.savedStationIds) {
                userLibraryDao.removeSavedStation(stationId)
            } else {
                userLibraryDao.saveStation(SavedStationEntity(stationId, System.currentTimeMillis()))
            }
        }
    }

    fun selectNearestStationFromCoordinates(lat: Double, lon: Double) {
        val nearest = uiState.value.stations.minByOrNull { st ->
            haversineKm(lat, lon, st.latitude, st.longitude)
        } ?: return
        selectOrigin(nearest.id)
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
