package com.example.data.timetables

import com.example.core.database.PreferencesRepository
import com.example.core.database.ServiceAlertEntity
import com.example.core.database.TimetableDao
import com.example.core.model.DatasetVersion
import com.example.core.model.FareProvider
import com.example.core.model.JourneyOption
import com.example.core.model.JourneySearchQuery
import com.example.core.model.NetworkProvider
import com.example.core.model.OperatingMode
import com.example.core.model.Route
import com.example.core.model.RoutePattern
import com.example.core.model.Station
import com.example.core.model.TimetableProvider
import com.example.core.network.TexasRailApiFactory
import com.example.core.routing.RaptorRouter
import com.example.data.timetables.DatabaseMappers.toDomain
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkAndTimetableRepository @Inject constructor(
    private val timetableDao: TimetableDao,
    private val preferencesRepository: PreferencesRepository,
    private val apiFactory: TexasRailApiFactory,
    private val raptorRouter: RaptorRouter,
    private val fareProvider: FareProvider
) : NetworkProvider, TimetableProvider {

    private val seedMutex = Mutex()
    @Volatile
    private var seeded = false

    suspend fun ensureSeeded() {
        if (seeded && timetableDao.getAllStations().isNotEmpty()) return
        seedMutex.withLock {
            if (timetableDao.getAllStations().isEmpty()) {
                timetableDao.upsertDatasetVersion(DemoSeedDataset.datasetVersion())
                timetableDao.insertStations(DemoSeedDataset.stations)
                timetableDao.insertRoutes(DemoSeedDataset.routes)
                timetableDao.insertRoutePatterns(DemoSeedDataset.routePatterns)
                timetableDao.insertCalendars(DemoSeedDataset.calendars)
                timetableDao.insertCalendarExceptions(DemoSeedDataset.calendarExceptions)
                timetableDao.insertTrips(DemoSeedDataset.trips)
                timetableDao.insertStopTimes(DemoSeedDataset.stopTimes)
                timetableDao.insertTransfers(DemoSeedDataset.transfers)
                timetableDao.insertAlerts(DemoSeedDataset.alerts)
            }
            seeded = true
        }
    }

    override fun observeOperatingMode(): Flow<OperatingMode> =
        preferencesRepository.preferencesFlow.map { it.operatingMode }

    override fun observeDatasetVersion(): Flow<DatasetVersion?> =
        timetableDao.observeLatestDatasetVersion().map { it?.toDomain() }

    override suspend fun setOperatingMode(mode: OperatingMode, connectedBaseUrl: String?) {
        preferencesRepository.setOperatingMode(mode, connectedBaseUrl, ticketingAuthorized = false)
    }

    override suspend fun refreshSnapshot(force: Boolean): Result<DatasetVersion> {
        ensureSeeded()
        val prefs = preferencesRepository.preferencesFlow.first()
        if (prefs.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
            val refreshed = DemoSeedDataset.datasetVersion(syncedAtMillis = System.currentTimeMillis())
            timetableDao.upsertDatasetVersion(refreshed)
            return Result.success(refreshed.toDomain())
        }

        // Connected services mode: attempt verified backend snapshot sync
        return runCatching {
            val api = apiFactory.create(prefs.connectedBaseUrl)
            val snapshot = api.getNetworkSnapshot()
            val nowMillis = System.currentTimeMillis()
            val versionEntity = if (snapshot.datasetVersion != null) {
                com.example.core.database.DatasetVersionEntity(
                    id = snapshot.datasetVersion.id,
                    operatingMode = snapshot.operatingMode,
                    sourceName = snapshot.datasetVersion.source_name,
                    publishedAtMillis = runCatching { Instant.parse(snapshot.datasetVersion.published_at).toEpochMilli() }
                        .getOrDefault(nowMillis),
                    lastSyncedAtMillis = nowMillis,
                    checksum = snapshot.datasetVersion.checksum
                )
            } else {
                DemoSeedDataset.datasetVersion(syncedAtMillis = nowMillis)
            }
            timetableDao.upsertDatasetVersion(versionEntity)
            if (snapshot.alerts.isNotEmpty()) {
                timetableDao.insertAlerts(
                    snapshot.alerts.map { dto ->
                        ServiceAlertEntity(
                            id = dto.id,
                            routeId = dto.route_id,
                            stationId = dto.station_id,
                            title = dto.title,
                            description = dto.description,
                            severity = dto.severity,
                            startsAtMillis = runCatching { Instant.parse(dto.starts_at).toEpochMilli() }.getOrDefault(nowMillis),
                            endsAtMillis = dto.ends_at?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() },
                            operatingMode = dto.operating_mode,
                            sourceId = dto.source_id
                        )
                    }
                )
            }
            versionEntity.toDomain()
        }
    }

    override fun observeStations(): Flow<List<Station>> =
        timetableDao.observeStations().map { list -> list.map { it.toDomain() } }

    override fun observeRoutes(): Flow<List<Route>> =
        timetableDao.observeRoutes().map { list -> list.map { it.toDomain() } }

    override fun observeRoutePatterns(): Flow<List<RoutePattern>> =
        timetableDao.observeRoutePatterns().map { list -> list.map { it.toDomain() } }

    override suspend fun getStation(stationId: String): Station? {
        ensureSeeded()
        return timetableDao.getStation(stationId)?.toDomain()
    }

    override suspend fun searchJourneys(query: JourneySearchQuery): List<JourneyOption> {
        ensureSeeded()
        val prefs = preferencesRepository.preferencesFlow.first()
        val stations = timetableDao.getAllStations().map { it.toDomain() }.associateBy { it.id }
        val routes = timetableDao.getAllRoutes().map { it.toDomain() }.associateBy { it.id }
        val calendars = timetableDao.getAllCalendars().map { it.toDomain() }.associateBy { it.id }
        val exceptions = timetableDao.getAllCalendarExceptions().map { it.toDomain() }
        val trips = timetableDao.getAllTrips().map { it.toDomain() }
            .filter { trip ->
                // Never mix demonstration departures with live connected trips without separation
                if (prefs.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                    trip.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION
                } else {
                    trip.operatingMode == OperatingMode.CONNECTED_SERVICES
                }
            }

        val stopTimesByTrip = timetableDao.getAllStopTimes().map { it.toDomain() }.groupBy { it.tripId }
        val transfersByStation = timetableDao.getAllTransfers().map { it.toDomain() }.groupBy { it.fromStationId }

        val snapshot = RaptorRouter.TimetableSnapshot(
            stations = stations,
            routes = routes,
            calendars = calendars,
            exceptions = exceptions,
            trips = trips,
            stopTimesByTrip = stopTimesByTrip,
            transfersByStation = transfersByStation
        )

        return raptorRouter.findJourneys(snapshot, query) { tripIds, serviceDate, paxCount ->
            fareProvider.getFareOffer(tripIds, serviceDate, paxCount)
        }
    }
}
