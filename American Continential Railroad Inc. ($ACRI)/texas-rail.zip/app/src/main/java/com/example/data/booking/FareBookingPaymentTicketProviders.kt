package com.example.data.booking

import androidx.room.withTransaction
import com.example.core.database.BookingEntity
import com.example.core.database.InventoryAndBookingDao
import com.example.core.database.InventoryReservationEntity
import com.example.core.database.PaymentRecordEntity
import com.example.core.database.PreferencesRepository
import com.example.core.database.ProcessedWebhookEntity
import com.example.core.database.TexasRailDatabase
import com.example.core.model.Booking
import com.example.core.model.BookingProvider
import com.example.core.model.BookingStatus
import com.example.core.model.CoachSeatState
import com.example.core.model.FareCondition
import com.example.core.model.FareOffer
import com.example.core.model.FareProvider
import com.example.core.model.InventoryReservation
import com.example.core.model.JourneyLeg
import com.example.core.model.JourneyOption
import com.example.core.model.Money
import com.example.core.model.OperatingMode
import com.example.core.model.Passenger
import com.example.core.model.Payment
import com.example.core.model.PaymentProvider
import com.example.core.model.PaymentStatus
import com.example.core.model.Refund
import com.example.core.model.ReservationStatus
import com.example.core.model.SandboxPaymentOutcome
import com.example.core.model.SeatAssignment
import com.example.core.model.Ticket
import com.example.core.model.TicketIssuer
import com.example.data.timetables.BookingSegmentDto
import com.example.data.timetables.DatabaseMappers.toDomain
import com.example.data.timetables.DemoSeedDataset
import com.example.data.timetables.PassengerDto
import com.example.data.timetables.SeatAssignmentDto
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FareBookingPaymentTicketRepository @Inject constructor(
    private val db: TexasRailDatabase,
    private val dao: InventoryAndBookingDao,
    private val preferencesRepository: PreferencesRepository
) : FareProvider, BookingProvider, PaymentProvider, TicketIssuer {

    private val json = Json { ignoreUnknownKeys = true }

    private suspend fun ensureInventorySeeded(date: LocalDate) {
        dao.insertInventoryIfMissing(DemoSeedDataset.initialInventoryForDate(date))
    }

    override suspend fun getFareOffer(
        tripIds: List<String>,
        serviceDate: LocalDate,
        passengerCount: Int,
        fareClass: String
    ): FareOffer? {
        if (tripIds.isEmpty()) return null
        ensureInventorySeeded(serviceDate)
        val prefs = preferencesRepository.preferencesFlow.first()

        var baseCents = 0L
        var taxCents = 0L
        var feeCents = 0L
        var minSeats = Int.MAX_VALUE

        for (tripId in tripIds) {
            val inv = dao.getInventory(tripId, serviceDate.toString(), fareClass) ?: return null
            baseCents += inv.baseFareCents
            taxCents += inv.taxCents
            feeCents += inv.feeCents
            minSeats = minOf(minSeats, inv.availableSeats)
        }

        // Apply modest multi-segment bundle fee cap so connecting fares stay realistic
        if (tripIds.size > 1) {
            feeCents = minOf(feeCents, 300L)
        }

        val now = System.currentTimeMillis()
        val conditions = FareCondition(
            fareClass = fareClass,
            refundableUntilHoursBefore = 24,
            refundFeePercent = 10,
            exchangeAllowed = true,
            exchangeFeeCents = 0L,
            seatSelectionIncluded = true,
            carryOnBagsIncluded = 2,
            summaryText = "Standard Flex: Free exchange prior to departure; 90% refund up to 24h before travel.",
            capturedAtEpochMillis = now
        )

        return FareOffer(
            id = "offer_${tripIds.joinToString("_")}_${serviceDate}_$fareClass",
            tripIds = tripIds,
            fareClass = fareClass,
            baseFarePerPassenger = Money(baseCents, "USD"),
            taxPerPassenger = Money(taxCents, "USD"),
            feePerPassenger = Money(feeCents, "USD"),
            availableSeats = minSeats,
            seatAvailabilitySupported = prefs.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION,
            expiresAt = Instant.ofEpochMilli(now + 15 * 60 * 1000L),
            conditions = conditions,
            operatingMode = prefs.operatingMode
        )
    }

    override suspend fun getSeatMap(tripId: String, serviceDate: LocalDate): List<CoachSeatState> {
        ensureInventorySeeded(serviceDate)
        val inv = dao.getInventory(tripId, serviceDate.toString(), "Standard")
        val occupied = inv?.let { json.decodeFromString<List<String>>(it.occupiedSeatsJson) }.orEmpty().toSet()

        val seats = mutableListOf<CoachSeatState>()
        val letters = listOf("A", "B", "C", "D")
        for (row in 1..12) {
            for (letter in letters) {
                val label = "$row$letter"
                val isAccessible = row == 1 && (letter == "C" || letter == "D")
                seats.add(
                    CoachSeatState(
                        coach = "Coach 1",
                        seatNumber = label,
                        isWindow = letter == "A" || letter == "D",
                        isAccessibleSpace = isAccessible,
                        isOccupied = label in occupied
                    )
                )
            }
        }
        return seats
    }

    override fun observeBookings(userId: String): Flow<List<Booking>> =
        dao.observeBookingsForUser(userId).map { list -> list.map { it.toDomain() } }

    override suspend fun getBooking(bookingId: String, userId: String): Booking? =
        dao.getBookingForUser(bookingId, userId)?.toDomain()

    override suspend fun createReservation(
        userId: String,
        idempotencyKey: String,
        journey: JourneyOption,
        serviceDate: LocalDate,
        passengerCount: Int,
        requestedSeats: List<String>
    ): Result<InventoryReservation> {
        if (passengerCount !in 1..8) {
            return Result.failure(IllegalArgumentException("Passenger count must be between 1 and 8."))
        }
        val prefs = preferencesRepository.preferencesFlow.first()
        if (prefs.operatingMode == OperatingMode.CONNECTED_SERVICES && !prefs.connectedTicketingAuthorized) {
            return Result.failure(
                IllegalStateException("Connected operator ticketing is not authorized or configured for live purchasing.")
            )
        }
        if (Instant.now().isAfter(journey.fareOffer.expiresAt)) {
            return Result.failure(IllegalStateException("Fare offer has expired. Please refresh search results."))
        }

        ensureInventorySeeded(serviceDate)

        return runCatching {
            db.withTransaction {
                // Reap expired holds before allocating seats
                reapExpiredHoldsLocked(System.currentTimeMillis())

                // Idempotency replay check
                dao.getReservationByIdempotencyKey(idempotencyKey)?.let { existing ->
                    return@withTransaction existing.toDomain()
                }

                val rideLegs = journey.legs.filterIsInstance<JourneyLeg.RailRide>()
                val tripIds = rideLegs.map { it.trip.id }

                for (tripId in tripIds) {
                    val inv = dao.getInventory(tripId, serviceDate.toString(), journey.fareOffer.fareClass)
                        ?: throw IllegalStateException("Inventory unavailable for $tripId")
                    if (inv.availableSeats < passengerCount) {
                        throw IllegalStateException("Insufficient seats remaining on ${tripId}.")
                    }
                    val currentOccupied = json.decodeFromString<List<String>>(inv.occupiedSeatsJson).toMutableSet()
                    if (requestedSeats.any { it in currentOccupied }) {
                        throw IllegalStateException("One or more selected seats were already reserved.")
                    }
                    val assigned = if (requestedSeats.isNotEmpty()) {
                        requestedSeats
                    } else {
                        // Deterministically pick next available seats
                        (1..12).flatMap { row -> listOf("A", "B", "C", "D").map { "$row$it" } }
                            .filterNot { it in currentOccupied }
                            .take(passengerCount)
                    }
                    if (assigned.size < passengerCount) {
                        throw IllegalStateException("Unable to allocate requested seats.")
                    }
                    currentOccupied.addAll(assigned)
                    val updatedRows = dao.decrementSeatsAtomically(
                        tripId = tripId,
                        serviceDateIso = serviceDate.toString(),
                        fareClass = journey.fareOffer.fareClass,
                        count = passengerCount,
                        occupiedSeatsJson = json.encodeToString(currentOccupied.toList())
                    )
                    if (updatedRows == 0) {
                        throw IllegalStateException("Concurrent seat reservation conflict; please try again.")
                    }
                }

                val subtotal = journey.fareOffer.baseFarePerPassenger * passengerCount
                val tax = journey.fareOffer.taxPerPassenger * passengerCount
                val fee = journey.fareOffer.feePerPassenger * passengerCount
                val total = subtotal + tax + fee
                val now = System.currentTimeMillis()
                val entity = InventoryReservationEntity(
                    id = "res_${UUID.randomUUID()}",
                    userId = userId,
                    idempotencyKey = idempotencyKey,
                    tripIdsJson = json.encodeToString(tripIds),
                    serviceDateIso = serviceDate.toString(),
                    fareClass = journey.fareOffer.fareClass,
                    passengerCount = passengerCount,
                    requestedSeatsJson = json.encodeToString(requestedSeats),
                    subtotalCents = subtotal.cents,
                    taxCents = tax.cents,
                    feeCents = fee.cents,
                    totalCents = total.cents,
                    currency = total.currency,
                    fareConditionSnapshotJson = json.encodeToString(journey.fareOffer.conditions),
                    status = ReservationStatus.HELD.name,
                    expiresAtMillis = now + 10 * 60 * 1000L,
                    createdAtMillis = now
                )
                dao.upsertReservation(entity)
                entity.toDomain()
            }
        }
    }

    private suspend fun reapExpiredHoldsLocked(nowMillis: Long) {
        val expired = dao.getExpiredHeldReservations(nowMillis)
        for (res in expired) {
            val tripIds = json.decodeFromString<List<String>>(res.tripIdsJson)
            val seatsToRelease = json.decodeFromString<List<String>>(res.requestedSeatsJson).toSet()
            for (tripId in tripIds) {
                val inv = dao.getInventory(tripId, res.serviceDateIso, res.fareClass) ?: continue
                val occupied = json.decodeFromString<List<String>>(inv.occupiedSeatsJson).toMutableSet()
                occupied.removeAll(seatsToRelease)
                dao.releaseSeats(
                    tripId = tripId,
                    serviceDateIso = res.serviceDateIso,
                    fareClass = res.fareClass,
                    count = res.passengerCount,
                    occupiedSeatsJson = json.encodeToString(occupied.toList())
                )
            }
            dao.updateReservationStatus(res.id, ReservationStatus.EXPIRED.name)
        }
    }

    override suspend fun initializeSandboxPayment(
        reservation: InventoryReservation,
        idempotencyKey: String,
        paymentMethodToken: String,
        simulationOutcome: SandboxPaymentOutcome
    ): Result<Payment> = runCatching {
        require(paymentMethodToken.isNotBlank()) { "Tokenised payment method is required." }
        // Never accept raw card PANs
        require(!paymentMethodToken.replace(" ", "").all { it.isDigit() } || paymentMethodToken.length < 12) {
            "Raw card numbers are not permitted; pass a tokenised sandbox payment token."
        }

        dao.getPaymentByIdempotencyKey(idempotencyKey)?.let { existing ->
            return@runCatching Payment(
                id = existing.id,
                reservationId = existing.reservationId,
                idempotencyKey = existing.idempotencyKey,
                providerName = existing.providerName,
                paymentMethodSummary = existing.paymentMethodSummary,
                amount = Money(existing.amountCents, existing.currency),
                status = PaymentStatus.valueOf(existing.status),
                createdAt = Instant.ofEpochMilli(existing.createdAtMillis)
            )
        }

        val paymentId = "pay_${UUID.randomUUID()}"
        val now = System.currentTimeMillis()
        val initialRecord = PaymentRecordEntity(
            id = paymentId,
            reservationId = reservation.id,
            idempotencyKey = idempotencyKey,
            providerName = "TexasRail Sandbox Gateway",
            paymentMethodSummary = "Sandbox Token ($paymentMethodToken)",
            amountCents = reservation.total.cents,
            currency = reservation.total.currency,
            status = PaymentStatus.REQUIRES_CONFIRMATION.name,
            createdAtMillis = now
        )
        dao.upsertPayment(initialRecord)

        // Dispatch backend-style webhook event(s) rather than trusting UI screen redirect
        val eventId = "evt_${idempotencyKey}_1"
        val eventType = when (simulationOutcome) {
            SandboxPaymentOutcome.SUCCEED -> "payment.succeeded"
            SandboxPaymentOutcome.FAIL_DECLINED -> "payment.failed"
            SandboxPaymentOutcome.CANCELLED_BY_USER -> "payment.cancelled"
            SandboxPaymentOutcome.DUPLICATE_WEBHOOK_SUCCEED -> "payment.succeeded"
        }
        processWebhookEvent(eventId, paymentId, eventType).getOrThrow()
        if (simulationOutcome == SandboxPaymentOutcome.DUPLICATE_WEBHOOK_SUCCEED) {
            // Replay identical webhook eventId to prove idempotent deduplication
            processWebhookEvent(eventId, paymentId, eventType).getOrThrow()
        }

        val updated = dao.getPayment(paymentId)!!
        Payment(
            id = updated.id,
            reservationId = updated.reservationId,
            idempotencyKey = updated.idempotencyKey,
            providerName = updated.providerName,
            paymentMethodSummary = updated.paymentMethodSummary,
            amount = Money(updated.amountCents, updated.currency),
            status = PaymentStatus.valueOf(updated.status),
            createdAt = Instant.ofEpochMilli(updated.createdAtMillis)
        )
    }

    override suspend fun processWebhookEvent(
        eventId: String,
        paymentId: String,
        eventType: String
    ): Result<PaymentStatus> = runCatching {
        db.withTransaction {
            val existing = dao.getProcessedWebhook(eventId)
            if (existing != null) {
                val payment = dao.getPayment(paymentId)
                    ?: throw IllegalStateException("Payment $paymentId missing")
                return@withTransaction PaymentStatus.valueOf(payment.status)
            }
            val nextStatus = when (eventType) {
                "payment.succeeded" -> PaymentStatus.SUCCEEDED
                "payment.failed" -> PaymentStatus.FAILED
                "payment.cancelled" -> PaymentStatus.CANCELLED
                "payment.refunded" -> PaymentStatus.REFUNDED
                else -> throw IllegalArgumentException("Unsupported webhook event: $eventType")
            }
            dao.insertProcessedWebhook(
                ProcessedWebhookEntity(
                    eventId = eventId,
                    paymentId = paymentId,
                    eventType = eventType,
                    processedAtMillis = System.currentTimeMillis()
                )
            )
            dao.updatePaymentStatus(paymentId, nextStatus.name)
            nextStatus
        }
    }

    override suspend fun confirmBooking(
        userId: String,
        reservationId: String,
        paymentId: String,
        passengers: List<Passenger>,
        seats: List<SeatAssignment>,
        journey: JourneyOption
    ): Result<Booking> = runCatching {
        val prefs = preferencesRepository.preferencesFlow.first()
        if (prefs.operatingMode == OperatingMode.CONNECTED_SERVICES && !prefs.connectedTicketingAuthorized) {
            throw IllegalStateException("Cannot issue travel tickets without authorized operator configuration.")
        }

        db.withTransaction {
            val existingBooking = dao.getBookingByReservationId(reservationId)
            if (existingBooking != null) {
                if (existingBooking.userId != userId) {
                    throw SecurityException("Access denied to booking")
                }
                return@withTransaction existingBooking.toDomain()
            }

            val reservation = dao.getReservationForUser(reservationId, userId)
                ?: throw IllegalStateException("Reservation not found for active account.")
            val now = System.currentTimeMillis()
            if (reservation.expiresAtMillis < now || reservation.status == ReservationStatus.EXPIRED.name) {
                dao.updateReservationStatus(reservationId, ReservationStatus.EXPIRED.name)
                throw IllegalStateException("Reservation expired before confirmation. Please select your journey again.")
            }

            val payment = dao.getPayment(paymentId)
                ?: throw IllegalStateException("Payment record missing.")
            if (payment.status != PaymentStatus.SUCCEEDED.name) {
                throw IllegalStateException("Booking cannot be confirmed: payment status is ${payment.status}.")
            }

            val bookingId = "bkg_${UUID.randomUUID()}"
            val referenceCode = "TXR-${UUID.randomUUID().toString().take(6).uppercase()}"
            val ticket = issueTicket(bookingId, referenceCode, prefs.operatingMode).getOrThrow()

            val segments = journey.legs.filterIsInstance<JourneyLeg.RailRide>().mapIndexed { idx, leg ->
                BookingSegmentDto(
                    id = "seg_${bookingId}_$idx",
                    tripId = leg.trip.id,
                    trainNumber = leg.trip.trainNumber,
                    routeName = leg.route.name,
                    originStationId = leg.originStop.station.id,
                    originStationName = leg.originStop.station.name,
                    originZoneId = leg.originStop.station.timeZoneId,
                    destinationStationId = leg.destinationStop.station.id,
                    destinationStationName = leg.destinationStop.station.name,
                    destinationZoneId = leg.destinationStop.station.timeZoneId,
                    departureMillis = leg.originStop.departureInstant?.toEpochMilli() ?: now,
                    arrivalMillis = leg.destinationStop.arrivalInstant?.toEpochMilli() ?: now,
                    platformCode = leg.originStop.platformCode
                )
            }

            val passengerDtos = passengers.map {
                PassengerDto(it.id, it.fullName, it.passengerType.name, it.email, it.accessibilityNotes)
            }
            val seatDtos = seats.map {
                SeatAssignmentDto(it.segmentId, it.coach, it.seatNumber, it.isAccessibleSpace)
            }

            val entity = BookingEntity(
                id = bookingId,
                userId = userId,
                reservationId = reservationId,
                referenceCode = referenceCode,
                operatingMode = prefs.operatingMode.name,
                status = BookingStatus.CONFIRMED.name,
                serviceDateIso = reservation.serviceDateIso,
                passengersJson = json.encodeToString(passengerDtos),
                segmentsJson = json.encodeToString(segments),
                seatsJson = json.encodeToString(seatDtos),
                totalCents = reservation.totalCents,
                currency = reservation.currency,
                fareConditionSnapshotJson = reservation.fareConditionSnapshotJson,
                qrPayload = ticket.qrPayload,
                isDemonstration = ticket.isDemonstration,
                demoDisclaimer = ticket.demoDisclaimer,
                issuerName = ticket.issuerName,
                createdAtMillis = now,
                cachedAtMillis = now
            )

            dao.updateReservationStatus(reservationId, ReservationStatus.CONFIRMED.name)
            dao.upsertBooking(entity)
            entity.toDomain()
        }
    }

    override suspend fun issueTicket(
        bookingId: String,
        referenceCode: String,
        operatingMode: OperatingMode
    ): Result<Ticket> = runCatching {
        val prefs = preferencesRepository.preferencesFlow.first()
        if (operatingMode == OperatingMode.CONNECTED_SERVICES && !prefs.connectedTicketingAuthorized) {
            throw IllegalStateException("Connected Services ticket issuance requires an authorized operator integration.")
        }
        val isDemo = operatingMode == OperatingMode.CONCEPT_DEMONSTRATION
        val disclaimer = if (isDemo) "DEMO — NOT VALID FOR TRAVEL" else "ISSUED BY AUTHORIZED OPERATOR"
        val payload = if (isDemo) {
            "DEMO-$referenceCode-NOT-VALID-FOR-TRAVEL"
        } else {
            "TXR-$bookingId-$referenceCode"
        }
        Ticket(
            id = "tkt_$bookingId",
            bookingId = bookingId,
            referenceCode = referenceCode,
            qrPayload = payload,
            isDemonstration = isDemo,
            demoDisclaimer = disclaimer,
            issuerName = if (isDemo) "Texas Rail Concept Demo Issuer" else "Authorized Operator Issuer",
            issuedAt = Instant.now()
        )
    }

    override suspend fun requestRefund(userId: String, bookingId: String, reason: String): Result<Refund> = runCatching {
        db.withTransaction {
            val booking = dao.getBookingForUser(bookingId, userId)
                ?: throw IllegalStateException("Booking not found for current account.")
            if (booking.status == BookingStatus.REFUNDED.name) {
                throw IllegalStateException("Booking has already been refunded.")
            }
            val cond = json.decodeFromString<FareCondition>(booking.fareConditionSnapshotJson)
            val refundableCents = (booking.totalCents * (100 - cond.refundFeePercent)) / 100L
            dao.updateBookingStatus(bookingId, userId, BookingStatus.REFUNDED.name)

            // Release seats back to inventory
            val res = dao.getReservationForUser(booking.reservationId, userId)
            if (res != null) {
                val tripIds = json.decodeFromString<List<String>>(res.tripIdsJson)
                val releasedSeats = json.decodeFromString<List<String>>(res.requestedSeatsJson).toSet()
                for (tripId in tripIds) {
                    val inv = dao.getInventory(tripId, res.serviceDateIso, res.fareClass) ?: continue
                    val occupied = json.decodeFromString<List<String>>(inv.occupiedSeatsJson).toMutableSet()
                    occupied.removeAll(releasedSeats)
                    dao.releaseSeats(
                        tripId = tripId,
                        serviceDateIso = res.serviceDateIso,
                        fareClass = res.fareClass,
                        count = res.passengerCount,
                        occupiedSeatsJson = json.encodeToString(occupied.toList())
                    )
                }
            }

            Refund(
                id = "rfd_${UUID.randomUUID()}",
                bookingId = bookingId,
                amount = Money(refundableCents, booking.currency),
                reason = reason,
                refundedAt = Instant.now()
            )
        }
    }
}
