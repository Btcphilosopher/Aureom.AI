package com.example.feature.departures

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.AlertProvider
import com.example.core.model.DepartureBoardResult
import com.example.core.model.RealtimeProvider
import com.example.core.model.Route
import com.example.core.model.RoutePattern
import com.example.core.model.ServiceAlert
import com.example.core.model.Station
import com.example.core.model.TimetableProvider
import com.example.data.timetables.DemoSeedDataset
import com.example.data.timetables.NetworkAndTimetableRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class DeparturesUiState(
    val stations: List<Station> = emptyList(),
    val selectedStationId: String = "st_dal",
    val board: DepartureBoardResult? = null,
    val alerts: List<ServiceAlert> = emptyList(),
    val isLoading: Boolean = true,
    val errorMessage: String? = null
)

data class StationDetailUiState(
    val station: Station? = null,
    val servedRoutes: List<Route> = emptyList(),
    val board: DepartureBoardResult? = null,
    val alerts: List<ServiceAlert> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class DeparturesAndStationViewModel @Inject constructor(
    private val timetableRepo: NetworkAndTimetableRepository,
    private val timetableProvider: TimetableProvider,
    private val realtimeProvider: RealtimeProvider,
    private val alertProvider: AlertProvider
) : ViewModel() {

    private val _departuresState = MutableStateFlow(DeparturesUiState())
    val departuresState: StateFlow<DeparturesUiState> = _departuresState.asStateFlow()

    private val _stationDetailState = MutableStateFlow(StationDetailUiState())
    val stationDetailState: StateFlow<StationDetailUiState> = _stationDetailState.asStateFlow()

    fun loadDepartures(stationId: String) {
        viewModelScope.launch {
            _departuresState.value = _departuresState.value.copy(isLoading = true, selectedStationId = stationId, errorMessage = null)
            runCatching {
                timetableRepo.ensureSeeded()
                val stations = timetableProvider.observeStations().first()
                val board = realtimeProvider.getDepartures(stationId, LocalDate.parse(DemoSeedDataset.REFERENCE_DATE_ISO))
                val alerts = alertProvider.getAlertsForStation(stationId)
                DeparturesUiState(
                    stations = stations,
                    selectedStationId = stationId,
                    board = board,
                    alerts = alerts,
                    isLoading = false
                )
            }.onSuccess {
                _departuresState.value = it
            }.onFailure { err ->
                _departuresState.value = _departuresState.value.copy(isLoading = false, errorMessage = err.message)
            }
        }
    }

    fun refreshDepartures() {
        loadDepartures(_departuresState.value.selectedStationId)
    }

    fun loadStationDetails(stationId: String) {
        viewModelScope.launch {
            _stationDetailState.value = StationDetailUiState(isLoading = true)
            timetableRepo.ensureSeeded()
            val station = timetableProvider.getStation(stationId)
            val allRoutes = timetableProvider.observeRoutes().first().associateBy { it.id }
            val patterns: List<RoutePattern> = timetableProvider.observeRoutePatterns().first()
            val servedRoutes = patterns
                .filter { stationId in it.stationSequence }
                .mapNotNull { allRoutes[it.routeId] }
                .distinctBy { it.id }
            val board = runCatching {
                realtimeProvider.getDepartures(stationId, LocalDate.parse(DemoSeedDataset.REFERENCE_DATE_ISO))
            }.getOrNull()
            val alerts = alertProvider.getAlertsForStation(stationId)

            _stationDetailState.value = StationDetailUiState(
                station = station,
                servedRoutes = servedRoutes,
                board = board,
                alerts = alerts,
                isLoading = false
            )
        }
    }
}
