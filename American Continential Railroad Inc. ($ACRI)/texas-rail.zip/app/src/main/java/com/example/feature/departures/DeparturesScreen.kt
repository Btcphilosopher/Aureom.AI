package com.example.feature.departures

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.OperatingModeBanner
import com.example.core.designsystem.PlusJakartaSansFamily
import com.example.core.designsystem.SectionHeadingWithAccent
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.OperatingMode
import com.example.core.model.ServiceStatus
import com.example.core.time.TexasRailTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeparturesScreen(
    initialStationId: String,
    viewModel: DeparturesAndStationViewModel,
    onBack: () -> Unit,
    onOpenStationDetails: (stationId: String) -> Unit
) {
    val state by viewModel.departuresState.collectAsStateWithLifecycle()
    val tokens = LocalTexasRailTokens.current
    var pickingStation by remember { mutableStateOf(false) }

    LaunchedEffect(initialStationId) {
        viewModel.loadDepartures(initialStationId)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        TexasRailTopBar(
            showBack = true,
            onBackClick = onBack,
            operatingMode = state.board?.operatingMode,
            trailingAction = {
                IconButton(
                    onClick = viewModel::refreshDepartures,
                    modifier = Modifier.size(48.dp).testTag("departures_refresh_button")
                ) {
                    Icon(Icons.Outlined.Refresh, contentDescription = "Refresh departures", tint = tokens.onHeaderNavy)
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .align(Alignment.CenterHorizontally)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(14.dp))
            SectionHeadingWithAccent(title = "Departures")
            Spacer(modifier = Modifier.height(10.dp))

            val board = state.board
            Surface(
                onClick = { pickingStation = true },
                shape = RoundedCornerShape(14.dp),
                color = tokens.cardSurface,
                border = BorderStroke(1.dp, tokens.divider),
                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("departures_station_selector")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = tokens.accentOrange)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = board?.station?.let { "${it.name} (${it.code})" } ?: "Select station",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = tokens.primaryInk
                        )
                        board?.let {
                            val telemetryNote = if (it.isLiveTelemetryAvailable) "Live feed active" else "Scheduled times (live telemetry unavailable)"
                            Text(
                                text = "$telemetryNote • Updated ${TexasRailTime.formatRefreshTimestamp(it.refreshedAt, it.station.timeZoneId)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = tokens.secondaryInk
                            )
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Change station")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            board?.let {
                OperatingModeBanner(
                    operatingMode = it.operatingMode,
                    customText = if (it.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                        "Illustrative scheduled departures — not live passenger departures"
                    } else if (!it.isLiveTelemetryAvailable) {
                        "Connected timetable schedule (live telemetry feed unavailable)"
                    } else {
                        "Connected live departure predictions"
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { onOpenStationDetails(it.station.id) },
                    modifier = Modifier.fillMaxWidth().testTag("departures_open_station_details")
                ) {
                    Text("View ${it.station.name} facilities, accessibility & alerts")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (state.alerts.isNotEmpty()) {
                state.alerts.forEach { alert ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = tokens.warningBadgeBg,
                        border = BorderStroke(1.dp, tokens.warningBadgeInk.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Outlined.WarningAmber, contentDescription = null, tint = tokens.warningBadgeInk, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(alert.title, style = MaterialTheme.typography.labelLarge, color = tokens.warningBadgeInk)
                                Text(alert.description, style = MaterialTheme.typography.bodySmall, color = tokens.primaryInk)
                            }
                        }
                    }
                }
            }

            if (state.isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = tokens.accentOrange)
                }
            } else if (board != null && board.entries.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No departures scheduled from this station.", color = tokens.secondaryInk)
                }
            } else if (board != null) {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(board.entries, key = { "${it.tripId}_${it.scheduledDeparture}" }) { entry ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = tokens.cardSurface,
                            border = BorderStroke(1.dp, tokens.divider),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.width(80.dp)) {
                                    Text(
                                        text = TexasRailTime.formatLocalTime(entry.scheduledDeparture, entry.stationZoneId),
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontFamily = PlusJakartaSansFamily,
                                            fontWeight = FontWeight.ExtraBold
                                        ),
                                        color = tokens.primaryInk
                                    )
                                    Text(
                                        text = TexasRailTime.shortZoneLabel(entry.scheduledDeparture, entry.stationZoneId),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.secondaryInk
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = entry.destinationStationName,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = tokens.primaryInk
                                    )
                                    Text(
                                        text = "${entry.trainNumber} • ${entry.routeShortCode}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = tokens.secondaryInk
                                    )
                                    val statusLabel = when (entry.status) {
                                        ServiceStatus.SCHEDULED_ILLUSTRATIVE -> "Scheduled (Illustrative)"
                                        ServiceStatus.ON_TIME -> "On time"
                                        ServiceStatus.DELAYED -> "Delayed +${entry.delayMinutes}m"
                                        ServiceStatus.CANCELLED -> "Cancelled"
                                    }
                                    Text(
                                        text = statusLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (entry.status == ServiceStatus.CANCELLED) MaterialTheme.colorScheme.error else tokens.accentOrange
                                    )
                                }
                                Surface(
                                    color = tokens.cardSecondary,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, tokens.divider)
                                ) {
                                    Text(
                                        text = entry.platformCode ?: "TBA",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = tokens.primaryInk,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (pickingStation) {
        ModalBottomSheet(onDismissRequest = { pickingStation = false }) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Select Station", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(state.stations, key = { it.id }) { st ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .clickable {
                                    pickingStation = false
                                    viewModel.loadDepartures(st.id)
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${st.name} (${st.code})", style = MaterialTheme.typography.titleMedium)
                            Text(TexasRailTime.accessibleZoneName(st.timeZoneId), style = MaterialTheme.typography.bodySmall, color = tokens.secondaryInk)
                        }
                    }
                }
            }
        }
    }
}
