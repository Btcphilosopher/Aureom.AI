package com.example.core.designsystem

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object TexasRailPalette {
    val DeepNavy = Color(0xFF0E223A)
    val DeepNavyDark = Color(0xFF091627)
    val MidnightSurface = Color(0xFF132438)
    val MidnightElevated = Color(0xFF1B304A)
    val LimestoneIvory = Color(0xFFF6F1E9)
    val WarmCream = Color(0xFFFCF9F4)
    val PureWhite = Color(0xFFFFFFFF)
    val BurntOrange = Color(0xFFD1510A)
    val BurntOrangeBright = Color(0xFFEC6B26)
    val BurntOrangeSoft = Color(0xFFFBE9DF)
    val BurntOrangeSoftDark = Color(0xFF3E1F10)
    val SlateNavy = Color(0xFF3D536D)
    val SlateMuted = Color(0xFF6B7B8C)
    val SandstoneFill = Color(0xFFE8DAC8)
    val SandstoneOutline = Color(0xFFD2C0AA)
    val SandstoneFillDark = Color(0xFF1D2F43)
    val SandstoneOutlineDark = Color(0xFF364D69)
    val DividerWarm = Color(0xFFE3D9CC)
    val DividerDark = Color(0xFF283D56)
    val VerifiedGreen = Color(0xFF1A6B4A)
    val VerifiedGreenSoft = Color(0xFFE2F3EB)
    val VerifiedGreenDark = Color(0xFF4CD298)
    val WarningAmber = Color(0xFFB36200)
    val WarningAmberSoft = Color(0xFFFFF1DC)
    val ErrorCrimson = Color(0xFFB3261E)
    val ErrorCrimsonSoft = Color(0xFFFCE8E6)
}

@Immutable
data class TexasRailTokens(
    val headerNavy: Color,
    val onHeaderNavy: Color,
    val pageBackground: Color,
    val cardSurface: Color,
    val cardSecondary: Color,
    val accentOrange: Color,
    val onAccentOrange: Color,
    val accentSoft: Color,
    val primaryInk: Color,
    val secondaryInk: Color,
    val divider: Color,
    val mapLandFill: Color,
    val mapLandOutline: Color,
    val mapSecondaryRoute: Color,
    val verifiedBadgeBg: Color,
    val verifiedBadgeInk: Color,
    val warningBadgeBg: Color,
    val warningBadgeInk: Color,
    val radiusCard: Dp = 18.dp,
    val radiusButton: Dp = 12.dp,
    val radiusChip: Dp = 10.dp,
    val spacingXs: Dp = 4.dp,
    val spacingSm: Dp = 8.dp,
    val spacingMd: Dp = 16.dp,
    val spacingLg: Dp = 24.dp
)

val LightTexasRailTokens = TexasRailTokens(
    headerNavy = TexasRailPalette.DeepNavy,
    onHeaderNavy = TexasRailPalette.PureWhite,
    pageBackground = TexasRailPalette.LimestoneIvory,
    cardSurface = TexasRailPalette.PureWhite,
    cardSecondary = TexasRailPalette.WarmCream,
    accentOrange = TexasRailPalette.BurntOrange,
    onAccentOrange = TexasRailPalette.PureWhite,
    accentSoft = TexasRailPalette.BurntOrangeSoft,
    primaryInk = TexasRailPalette.DeepNavy,
    secondaryInk = TexasRailPalette.SlateNavy,
    divider = TexasRailPalette.DividerWarm,
    mapLandFill = TexasRailPalette.SandstoneFill,
    mapLandOutline = TexasRailPalette.SandstoneOutline,
    mapSecondaryRoute = TexasRailPalette.SlateNavy,
    verifiedBadgeBg = TexasRailPalette.VerifiedGreenSoft,
    verifiedBadgeInk = TexasRailPalette.VerifiedGreen,
    warningBadgeBg = TexasRailPalette.WarningAmberSoft,
    warningBadgeInk = TexasRailPalette.WarningAmber
)

val DarkTexasRailTokens = TexasRailTokens(
    headerNavy = TexasRailPalette.DeepNavyDark,
    onHeaderNavy = Color(0xFFF5EFE6),
    pageBackground = Color(0xFF0C1826),
    cardSurface = TexasRailPalette.MidnightSurface,
    cardSecondary = TexasRailPalette.MidnightElevated,
    accentOrange = TexasRailPalette.BurntOrangeBright,
    onAccentOrange = TexasRailPalette.PureWhite,
    accentSoft = TexasRailPalette.BurntOrangeSoftDark,
    primaryInk = Color(0xFFF4EDE3),
    secondaryInk = Color(0xFFAAB8C8),
    divider = TexasRailPalette.DividerDark,
    mapLandFill = TexasRailPalette.SandstoneFillDark,
    mapLandOutline = TexasRailPalette.SandstoneOutlineDark,
    mapSecondaryRoute = Color(0xFF7B96B5),
    verifiedBadgeBg = Color(0xFF153629),
    verifiedBadgeInk = TexasRailPalette.VerifiedGreenDark,
    warningBadgeBg = Color(0xFF3A2810),
    warningBadgeInk = Color(0xFFFFB74D)
)

val LocalTexasRailTokens = staticCompositionLocalOf { LightTexasRailTokens }
