package com.example.data.timetables

import com.example.core.database.CalendarExceptionEntity
import com.example.core.database.DatasetVersionEntity
import com.example.core.database.RouteEntity
import com.example.core.database.RoutePatternEntity
import com.example.core.database.ServiceAlertEntity
import com.example.core.database.ServiceCalendarEntity
import com.example.core.database.StationEntity
import com.example.core.database.StopTimeEntity
import com.example.core.database.TransferEntity
import com.example.core.database.TripEntity
import com.example.core.database.TripInventoryEntity
import com.example.core.model.StationAccessibility
import com.example.core.model.StationParkingBikes
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.LocalDate

@Serializable
data class AccessibilityDto(
    val stepFreeAccess: Boolean? = null,
    val levelBoarding: Boolean? = null,
    val tactileGuidance: Boolean? = null,
    val accessibleRestrooms: Boolean? = null,
    val assistanceDesk: Boolean? = null,
    val audioInductionLoops: Boolean? = null
)

@Serializable
data class ParkingBikesDto(
    val structuredParkingSpaces: Int? = null,
    val evChargers: Int? = null,
    val coveredBikeRacks: Int? = null,
    val bikeLockers: Int? = null
)

object DemoSeedDataset {
    val json = Json { ignoreUnknownKeys = true }

    const val DATASET_ID = "concept-2026.11"
    const val REFERENCE_DATE_ISO = "2026-05-14"

    fun datasetVersion(syncedAtMillis: Long = System.currentTimeMillis()): DatasetVersionEntity =
        DatasetVersionEntity(
            id = DATASET_ID,
            operatingMode = "CONCEPT_DEMONSTRATION",
            sourceName = "Texas Rail Concept Network Planning Dataset",
            publishedAtMillis = Instant.parse("2026-11-23T08:00:00Z").toEpochMilli(),
            lastSyncedAtMillis = syncedAtMillis,
            checksum = "sha256:txr-concept-2026-11"
        )

    private fun accJson(a: StationAccessibility): String = json.encodeToString(
        AccessibilityDto(
            stepFreeAccess = a.stepFreeAccess,
            levelBoarding = a.levelBoarding,
            tactileGuidance = a.tactileGuidance,
            accessibleRestrooms = a.accessibleRestrooms,
            assistanceDesk = a.assistanceDesk,
            audioInductionLoops = a.audioInductionLoops
        )
    )

    private fun parkJson(p: StationParkingBikes): String = json.encodeToString(
        ParkingBikesDto(
            structuredParkingSpaces = p.structuredParkingSpaces,
            evChargers = p.evChargers,
            coveredBikeRacks = p.coveredBikeRacks,
            bikeLockers = p.bikeLockers
        )
    )

    val stations: List<StationEntity> = listOf(
        StationEntity(
            id = "st_dal",
            code = "DAL",
            name = "Dallas",
            city = "Dallas",
            timeZoneId = "America/Chicago",
            latitude = 32.7767,
            longitude = -96.7970,
            schematicX = 0.70f,
            schematicY = 0.34f,
            isMajorCity = true,
            address = "400 S Houston St, Dallas, TX 75202",
            entrancesJson = json.encodeToString(listOf("Houston St Main Concourse", "Ferris Plaza South Entrance")),
            accessibilityJson = accJson(StationAccessibility(true, true, true, true, true, true)),
            parkingBikesJson = parkJson(StationParkingBikes(640, 24, 80, 20)),
            localTransitJson = json.encodeToString(listOf("DART Red/Blue/Green/Orange Rail", "TRE Commuter Rail", "Dallas Streetcar")),
            openingHours = "05:00 - 23:30 Daily",
            sourceId = "concept:st_dal",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_ftw",
            code = "FTW",
            name = "Fort Worth",
            city = "Fort Worth",
            timeZoneId = "America/Chicago",
            latitude = 32.7503,
            longitude = -97.3267,
            schematicX = 0.59f,
            schematicY = 0.37f,
            isMajorCity = true,
            address = "1001 Jones St, Fort Worth, TX 76102",
            entrancesJson = json.encodeToString(listOf("Jones St East Hall", "9th St Plaza")),
            accessibilityJson = accJson(StationAccessibility(true, true, true, true, true, null)),
            parkingBikesJson = parkJson(StationParkingBikes(410, 12, 50, null)),
            localTransitJson = json.encodeToString(listOf("TEXRail Airport Link", "TRE Commuter Rail", "Trinity Metro Bus")),
            openingHours = "05:15 - 23:00 Daily",
            sourceId = "concept:st_ftw",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_aus",
            code = "AUS",
            name = "Austin",
            city = "Austin",
            timeZoneId = "America/Chicago",
            latitude = 30.2672,
            longitude = -97.7431,
            schematicX = 0.58f,
            schematicY = 0.61f,
            isMajorCity = true,
            address = "250 E 4th St, Austin, TX 78701",
            entrancesJson = json.encodeToString(listOf("4th Street Pavilion", "Brush Square Concourse")),
            accessibilityJson = accJson(StationAccessibility(true, true, true, true, true, true)),
            parkingBikesJson = parkJson(StationParkingBikes(280, 18, 120, 32)),
            localTransitJson = json.encodeToString(listOf("CapMetro Rail Red Line", "Rapid 801/803", "MetroBike Hub")),
            openingHours = "05:30 - 23:30 Daily",
            sourceId = "concept:st_aus",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_sat",
            code = "SAT",
            name = "San Antonio",
            city = "San Antonio",
            timeZoneId = "America/Chicago",
            latitude = 29.4241,
            longitude = -98.4936,
            schematicX = 0.51f,
            schematicY = 0.72f,
            isMajorCity = true,
            address = "1174 E Commerce St, San Antonio, TX 78205",
            entrancesJson = json.encodeToString(listOf("Hoefgen Ave Concourse", "St. Paul Square Arcade")),
            accessibilityJson = accJson(StationAccessibility(true, true, true, true, null, null)),
            parkingBikesJson = parkJson(StationParkingBikes(350, 10, 64, null)),
            localTransitJson = json.encodeToString(listOf("VIA Primo 100", "VIA Link Downtown")),
            openingHours = "05:30 - 23:00 Daily",
            sourceId = "concept:st_sat",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_hou",
            code = "HOU",
            name = "Houston",
            city = "Houston",
            timeZoneId = "America/Chicago",
            latitude = 29.7604,
            longitude = -95.3698,
            schematicX = 0.80f,
            schematicY = 0.69f,
            isMajorCity = true,
            address = "902 Washington Ave, Houston, TX 77002",
            entrancesJson = json.encodeToString(listOf("Washington Ave Grand Hall", "Buffalo Bayou South")),
            accessibilityJson = accJson(StationAccessibility(true, true, true, true, true, true)),
            parkingBikesJson = parkJson(StationParkingBikes(780, 32, 96, 24)),
            localTransitJson = json.encodeToString(listOf("METRORail Red/Green/Purple", "METRO Silver Line")),
            openingHours = "05:00 - 23:45 Daily",
            sourceId = "concept:st_hou",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_elp",
            code = "ELP",
            name = "El Paso",
            city = "El Paso",
            timeZoneId = "America/Denver",
            latitude = 31.7619,
            longitude = -106.4850,
            schematicX = 0.13f,
            schematicY = 0.49f,
            isMajorCity = true,
            address = "700 W San Francisco Ave, El Paso, TX 79901",
            entrancesJson = json.encodeToString(listOf("San Francisco Ave Arch", "Union Plaza East")),
            accessibilityJson = accJson(StationAccessibility(true, null, true, true, null, null)),
            parkingBikesJson = parkJson(StationParkingBikes(220, 6, 36, null)),
            localTransitJson = json.encodeToString(listOf("El Paso Streetcar", "Sun Metro Brio")),
            openingHours = "05:30 - 22:30 MT",
            sourceId = "concept:st_elp",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_ama",
            code = "AMA",
            name = "Amarillo",
            city = "Amarillo",
            timeZoneId = "America/Chicago",
            latitude = 35.2220,
            longitude = -101.8313,
            schematicX = 0.36f,
            schematicY = 0.16f,
            isMajorCity = true,
            address = "301 S Grant St, Amarillo, TX 79101",
            entrancesJson = json.encodeToString(listOf("Grant St Depot Hall")),
            accessibilityJson = accJson(StationAccessibility(true, null, null, true, null, null)),
            parkingBikesJson = parkJson(StationParkingBikes(180, null, 24, null)),
            localTransitJson = json.encodeToString(listOf("Amarillo City Transit Route 1")),
            openingHours = null,
            sourceId = "concept:st_ama",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_crp",
            code = "CRP",
            name = "Corpus Christi",
            city = "Corpus Christi",
            timeZoneId = "America/Chicago",
            latitude = 27.8006,
            longitude = -97.3964,
            schematicX = 0.62f,
            schematicY = 0.89f,
            isMajorCity = true,
            address = "600 N Shoreline Blvd, Corpus Christi, TX 78401",
            entrancesJson = json.encodeToString(listOf("Shoreline Promenade", "Chaparral St Courtyard")),
            accessibilityJson = accJson(StationAccessibility(true, true, true, true, null, null)),
            parkingBikesJson = parkJson(StationParkingBikes(210, 8, 44, null)),
            localTransitJson = json.encodeToString(listOf("CCRTA Bayfront Route 76")),
            openingHours = "06:00 - 22:00 Daily",
            sourceId = "concept:st_crp",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_wac",
            code = "WAC",
            name = "Waco",
            city = "Waco",
            timeZoneId = "America/Chicago",
            latitude = 31.5493,
            longitude = -97.1467,
            schematicX = 0.66f,
            schematicY = 0.47f,
            isMajorCity = false,
            address = "200 S University Parks Dr, Waco, TX 76701",
            entrancesJson = json.encodeToString(listOf("Brazos Riverfront Platform")),
            accessibilityJson = accJson(StationAccessibility(true, true, true, true, null, null)),
            parkingBikesJson = parkJson(StationParkingBikes(120, 4, 30, null)),
            localTransitJson = json.encodeToString(listOf("Waco Transit Route 1")),
            openingHours = "06:00 - 21:30 Daily",
            sourceId = "concept:st_wac",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_tpl",
            code = "TPL",
            name = "Temple",
            city = "Temple",
            timeZoneId = "America/Chicago",
            latitude = 31.0982,
            longitude = -97.3428,
            schematicX = 0.62f,
            schematicY = 0.54f,
            isMajorCity = false,
            address = "315 W Avenue B, Temple, TX 76501",
            entrancesJson = json.encodeToString(listOf("Santa Fe Plaza Entrance")),
            accessibilityJson = accJson(StationAccessibility(true, true, null, true, null, null)),
            parkingBikesJson = parkJson(StationParkingBikes(140, null, null, null)),
            localTransitJson = json.encodeToString(listOf("HOP Commuter Shuttle")),
            openingHours = "06:00 - 21:30 Daily",
            sourceId = "concept:st_tpl",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_bcs",
            code = "BCS",
            name = "College Station",
            city = "College Station",
            timeZoneId = "America/Chicago",
            latitude = 30.6280,
            longitude = -96.3344,
            schematicX = 0.69f,
            schematicY = 0.65f,
            isMajorCity = false,
            address = "310 Wellborn Rd, College Station, TX 77840",
            entrancesJson = json.encodeToString(listOf("Wellborn Concourse")),
            accessibilityJson = accJson(StationAccessibility(true, true, true, true, null, null)),
            parkingBikesJson = parkJson(StationParkingBikes(160, 6, 48, null)),
            localTransitJson = json.encodeToString(listOf("Brazos Transit", "Aggie Spirit Bus")),
            openingHours = "06:00 - 22:00 Daily",
            sourceId = "concept:st_bcs",
            provenance = "Texas Rail Concept Planning"
        ),
        StationEntity(
            id = "st_maf",
            code = "MAF",
            name = "Midland",
            city = "Midland",
            timeZoneId = "America/Chicago",
            latitude = 31.9973,
            longitude = -102.0779,
            schematicX = 0.28f,
            schematicY = 0.50f,
            isMajorCity = false,
            address = "105 W Wall St, Midland, TX 79701",
            entrancesJson = json.encodeToString(listOf("Wall St Basin Depot")),
            accessibilityJson = accJson(StationAccessibility(true, null, null, true, null, null)),
            parkingBikesJson = parkJson(StationParkingBikes(95, null, 12, null)),
            localTransitJson = json.encodeToString(listOf("EZ-Rider Basin Loop")),
            openingHours = null,
            sourceId = "concept:st_maf",
            provenance = "Texas Rail Concept Planning"
        )
    )

    val routes: List<RouteEntity> = listOf(
        RouteEntity("rt_i35", "TX-35", "I-35 Lone Star Express", 0xFFD1510AL, "SOLID", "Texas Rail Concept", "CONCEPT_DEMONSTRATION", "concept:rt_i35", "Concept"),
        RouteEntity("rt_dfw", "TX-10", "Metroplex Connector", 0xFF3E5571L, "SOLID", "Texas Rail Concept", "CONCEPT_DEMONSTRATION", "concept:rt_dfw", "Concept"),
        RouteEntity("rt_triangle", "TX-HT", "Texas Triangle Shuttle", 0xFF2E4D6BL, "DASHED", "Texas Rail Concept", "CONCEPT_DEMONSTRATION", "concept:rt_triangle", "Concept"),
        RouteEntity("rt_west", "TX-WT", "West Texas Overland", 0xFF28527AL, "DOTTED", "Texas Rail Concept", "CONCEPT_DEMONSTRATION", "concept:rt_west", "Concept"),
        RouteEntity("rt_plains", "TX-HP", "High Plains Corridor", 0xFF4A6FA5L, "SOLID", "Texas Rail Concept", "CONCEPT_DEMONSTRATION", "concept:rt_plains", "Concept"),
        RouteEntity("rt_gulf", "TX-GC", "Gulf Breeze Line", 0xFF0E7C7BL, "SOLID", "Texas Rail Concept", "CONCEPT_DEMONSTRATION", "concept:rt_gulf", "Concept")
    )

    val routePatterns: List<RoutePatternEntity> = listOf(
        RoutePatternEntity("pat_i35_sb", "rt_i35", "SOUTHBOUND", "San Antonio via Austin", json.encodeToString(listOf("st_dal", "st_wac", "st_tpl", "st_aus", "st_sat"))),
        RoutePatternEntity("pat_i35_nb", "rt_i35", "NORTHBOUND", "Dallas via Austin", json.encodeToString(listOf("st_sat", "st_aus", "st_tpl", "st_wac", "st_dal"))),
        RoutePatternEntity("pat_dfw_wb", "rt_dfw", "WESTBOUND", "Fort Worth Central", json.encodeToString(listOf("st_dal", "st_ftw"))),
        RoutePatternEntity("pat_dfw_eb", "rt_dfw", "EASTBOUND", "Dallas Union", json.encodeToString(listOf("st_ftw", "st_dal"))),
        RoutePatternEntity("pat_tri_eb", "rt_triangle", "EASTBOUND", "Houston via Austin", json.encodeToString(listOf("st_sat", "st_aus", "st_bcs", "st_hou"))),
        RoutePatternEntity("pat_tri_wb", "rt_triangle", "WESTBOUND", "San Antonio via Austin", json.encodeToString(listOf("st_hou", "st_bcs", "st_aus", "st_sat"))),
        RoutePatternEntity("pat_west_wb", "rt_west", "WESTBOUND", "El Paso (Mountain Time)", json.encodeToString(listOf("st_ftw", "st_maf", "st_elp"))),
        RoutePatternEntity("pat_west_eb", "rt_west", "EASTBOUND", "Fort Worth (Central Time)", json.encodeToString(listOf("st_elp", "st_maf", "st_ftw"))),
        RoutePatternEntity("pat_plains_nb", "rt_plains", "NORTHBOUND", "Amarillo High Plains", json.encodeToString(listOf("st_ftw", "st_ama"))),
        RoutePatternEntity("pat_plains_sb", "rt_plains", "SOUTHBOUND", "Fort Worth Central", json.encodeToString(listOf("st_ama", "st_ftw"))),
        RoutePatternEntity("pat_gulf_sb", "rt_gulf", "SOUTHBOUND", "Corpus Christi Bayfront", json.encodeToString(listOf("st_sat", "st_crp"))),
        RoutePatternEntity("pat_gulf_nb", "rt_gulf", "NORTHBOUND", "San Antonio Sunset", json.encodeToString(listOf("st_crp", "st_sat")))
    )

    val calendars: List<ServiceCalendarEntity> = listOf(
        ServiceCalendarEntity(
            id = "cal_daily",
            monday = true, tuesday = true, wednesday = true, thursday = true,
            friday = true, saturday = true, sunday = true,
            startDateIso = "2026-01-01",
            endDateIso = "2027-12-31"
        )
    )

    val calendarExceptions: List<CalendarExceptionEntity> = listOf(
        // Illustrative calendar exception on Thanksgiving Day removing extra midday shuttle
        CalendarExceptionEntity("exc_thanksgiving", "cal_daily", "2026-11-26", "ADDED")
    )

    val trips: List<TripEntity> = listOf(
        TripEntity("tr_dal_aus_0800", "rt_i35", "pat_i35_sb", "cal_daily", "TX-101", "Morning Lone Star Express", true, true, json.encodeToString(listOf("Wi-Fi", "Power Outlets", "Cafe Car", "Bike Spaces", "Quiet Coach")), "CONCEPT_DEMONSTRATION", "concept:tr_101", "Concept"),
        TripEntity("tr_dal_aus_1030", "rt_i35", "pat_i35_sb", "cal_daily", "TX-103", "Midday Capitol Flyer", true, true, json.encodeToString(listOf("Wi-Fi", "Power Outlets", "Cafe Car")), "CONCEPT_DEMONSTRATION", "concept:tr_103", "Concept"),
        TripEntity("tr_dal_aus_1300", "rt_i35", "pat_i35_sb", "cal_daily", "TX-105", "Hill Country Afternoon", true, true, json.encodeToString(listOf("Wi-Fi", "Power Outlets", "Accessible Coach")), "CONCEPT_DEMONSTRATION", "concept:tr_105", "Concept"),
        TripEntity("tr_aus_dal_0915", "rt_i35", "pat_i35_nb", "cal_daily", "TX-102", "Capitol Northbound Express", true, true, json.encodeToString(listOf("Wi-Fi", "Power Outlets", "Cafe Car")), "CONCEPT_DEMONSTRATION", "concept:tr_102", "Concept"),
        TripEntity("tr_aus_dal_1400", "rt_i35", "pat_i35_nb", "cal_daily", "TX-104", "Trinity Afternoon Flyer", true, true, json.encodeToString(listOf("Wi-Fi", "Power Outlets")), "CONCEPT_DEMONSTRATION", "concept:tr_104", "Concept"),
        TripEntity("tr_dal_ftw_0700", "rt_dfw", "pat_dfw_wb", "cal_daily", "TX-201", "Metroplex Morning Link", true, true, json.encodeToString(listOf("Wi-Fi", "Bike Spaces")), "CONCEPT_DEMONSTRATION", "concept:tr_201", "Concept"),
        TripEntity("tr_dal_ftw_1945", "rt_dfw", "pat_dfw_wb", "cal_daily", "TX-207", "Metroplex Evening Link", true, true, json.encodeToString(listOf("Wi-Fi", "Bike Spaces")), "CONCEPT_DEMONSTRATION", "concept:tr_207", "Concept"),
        TripEntity("tr_ftw_dal_1415", "rt_dfw", "pat_dfw_eb", "cal_daily", "TX-204", "Metroplex Eastbound Link", true, true, json.encodeToString(listOf("Wi-Fi")), "CONCEPT_DEMONSTRATION", "concept:tr_204", "Concept"),
        TripEntity("tr_ftw_ama_0830", "rt_plains", "pat_plains_nb", "cal_daily", "TX-301", "High Plains Express", true, null, json.encodeToString(listOf("Wi-Fi", "Cafe Car")), "CONCEPT_DEMONSTRATION", "concept:tr_301", "Concept"),
        TripEntity("tr_ama_ftw_1430", "rt_plains", "pat_plains_sb", "cal_daily", "TX-302", "Prairie Southbound", true, null, json.encodeToString(listOf("Wi-Fi", "Cafe Car")), "CONCEPT_DEMONSTRATION", "concept:tr_302", "Concept"),
        TripEntity("tr_ftw_elp_2115", "rt_west", "pat_west_wb", "cal_daily", "TX-401", "Pecos Night Sleeper", true, null, json.encodeToString(listOf("Sleeper Berths", "Dining Car", "Wi-Fi")), "CONCEPT_DEMONSTRATION", "concept:tr_401", "Concept"),
        TripEntity("tr_elp_ftw_2000", "rt_west", "pat_west_eb", "cal_daily", "TX-402", "Borderland East Sleeper", true, null, json.encodeToString(listOf("Sleeper Berths", "Dining Car", "Wi-Fi")), "CONCEPT_DEMONSTRATION", "concept:tr_402", "Concept"),
        TripEntity("tr_hou_sat_0730", "rt_triangle", "pat_tri_wb", "cal_daily", "TX-501", "Bayou-to-Alamo Express", true, true, json.encodeToString(listOf("Wi-Fi", "Power Outlets", "Cafe Car")), "CONCEPT_DEMONSTRATION", "concept:tr_501", "Concept"),
        TripEntity("tr_sat_hou_1315", "rt_triangle", "pat_tri_eb", "cal_daily", "TX-502", "Alamo-to-Bayou Express", true, true, json.encodeToString(listOf("Wi-Fi", "Power Outlets", "Cafe Car")), "CONCEPT_DEMONSTRATION", "concept:tr_502", "Concept"),
        TripEntity("tr_sat_crp_1215", "rt_gulf", "pat_gulf_sb", "cal_daily", "TX-601", "Gulf Breeze Express", true, true, json.encodeToString(listOf("Wi-Fi", "Scenic Lounge")), "CONCEPT_DEMONSTRATION", "concept:tr_601", "Concept"),
        TripEntity("tr_crp_sat_0900", "rt_gulf", "pat_gulf_nb", "cal_daily", "TX-602", "Coastal Morning Train", true, true, json.encodeToString(listOf("Wi-Fi", "Scenic Lounge")), "CONCEPT_DEMONSTRATION", "concept:tr_602", "Concept")
    )

    val stopTimes: List<StopTimeEntity> = listOf(
        // TX-101: Dallas 08:00 -> Waco 08:55 -> Temple 09:25 -> Austin 10:10 -> San Antonio 11:10
        StopTimeEntity("st_101_1", "tr_dal_aus_0800", "st_dal", "Track 2", 1, 28800, 28800, 0, true, false),
        StopTimeEntity("st_101_2", "tr_dal_aus_0800", "st_wac", "Track 1", 2, 32100, 32220, 0, true, true),
        StopTimeEntity("st_101_3", "tr_dal_aus_0800", "st_tpl", "Track 1", 3, 33900, 34020, 0, true, true),
        StopTimeEntity("st_101_4", "tr_dal_aus_0800", "st_aus", "Track 3", 4, 36600, 36840, 0, true, true),
        StopTimeEntity("st_101_5", "tr_dal_aus_0800", "st_sat", "Track 2", 5, 40200, 40200, 0, false, true),

        // TX-103: Dallas 10:30 -> Waco 11:25 -> Austin 12:40 -> San Antonio 13:40
        StopTimeEntity("st_103_1", "tr_dal_aus_1030", "st_dal", "Track 4", 1, 37800, 37800, 0, true, false),
        StopTimeEntity("st_103_2", "tr_dal_aus_1030", "st_wac", "Track 1", 2, 41100, 41220, 0, true, true),
        StopTimeEntity("st_103_3", "tr_dal_aus_1030", "st_aus", "Track 2", 3, 45600, 45900, 0, true, true),
        StopTimeEntity("st_103_4", "tr_dal_aus_1030", "st_sat", "Track 1", 4, 49200, 49200, 0, false, true),

        // TX-105: Dallas 13:00 -> Temple 14:15 -> Austin 15:10
        StopTimeEntity("st_105_1", "tr_dal_aus_1300", "st_dal", "Track 1", 1, 46800, 46800, 0, true, false),
        StopTimeEntity("st_105_2", "tr_dal_aus_1300", "st_tpl", "Track 2", 2, 51300, 51480, 0, true, true),
        StopTimeEntity("st_105_3", "tr_dal_aus_1300", "st_aus", "Track 1", 3, 54600, 54600, 0, false, true),

        // TX-102: San Antonio 08:15 -> Austin 09:15 -> Waco 10:30 -> Dallas 11:25
        StopTimeEntity("st_102_1", "tr_aus_dal_0915", "st_sat", "Track 2", 1, 29700, 29700, 0, true, false),
        StopTimeEntity("st_102_2", "tr_aus_dal_0915", "st_aus", "Track 1", 2, 33120, 33300, 0, true, true),
        StopTimeEntity("st_102_3", "tr_aus_dal_0915", "st_wac", "Track 2", 3, 37800, 37920, 0, true, true),
        StopTimeEntity("st_102_4", "tr_aus_dal_0915", "st_dal", "Track 3", 4, 41100, 41100, 0, false, true),

        // TX-104: San Antonio 13:00 -> Austin 14:00 -> Temple 14:55 -> Dallas 16:10
        StopTimeEntity("st_104_1", "tr_aus_dal_1400", "st_sat", "Track 1", 1, 46800, 46800, 0, true, false),
        StopTimeEntity("st_104_2", "tr_aus_dal_1400", "st_aus", "Track 2", 2, 50220, 50400, 0, true, true),
        StopTimeEntity("st_104_3", "tr_aus_dal_1400", "st_tpl", "Track 1", 3, 53700, 53820, 0, true, true),
        StopTimeEntity("st_104_4", "tr_aus_dal_1400", "st_dal", "Track 2", 4, 58200, 58200, 0, false, true),

        // TX-201 & TX-207: Dallas -> Fort Worth
        StopTimeEntity("st_201_1", "tr_dal_ftw_0700", "st_dal", "Track 5", 1, 25200, 25200, 0, true, false),
        StopTimeEntity("st_201_2", "tr_dal_ftw_0700", "st_ftw", "Track 1", 2, 27600, 27600, 0, false, true),
        StopTimeEntity("st_207_1", "tr_dal_ftw_1945", "st_dal", "Track 5", 1, 71100, 71100, 0, true, false),
        StopTimeEntity("st_207_2", "tr_dal_ftw_1945", "st_ftw", "Track 2", 2, 73500, 73500, 0, false, true),

        // TX-204: Fort Worth -> Dallas
        StopTimeEntity("st_204_1", "tr_ftw_dal_1415", "st_ftw", "Track 1", 1, 51300, 51300, 0, true, false),
        StopTimeEntity("st_204_2", "tr_ftw_dal_1415", "st_dal", "Track 5", 2, 53700, 53700, 0, false, true),

        // TX-301 & TX-302: Fort Worth <-> Amarillo
        StopTimeEntity("st_301_1", "tr_ftw_ama_0830", "st_ftw", "Track 3", 1, 30600, 30600, 0, true, false),
        StopTimeEntity("st_301_2", "tr_ftw_ama_0830", "st_ama", null, 2, 49800, 49800, 0, false, true),
        StopTimeEntity("st_302_1", "tr_ama_ftw_1430", "st_ama", null, 1, 52200, 52200, 0, true, false),
        StopTimeEntity("st_302_2", "tr_ama_ftw_1430", "st_ftw", "Track 3", 2, 71400, 71400, 0, false, true),

        // TX-401: Fort Worth 21:15 CT -> Midland 02:05 CT (+1d) -> El Paso 07:45 MT (+1d)
        StopTimeEntity("st_401_1", "tr_ftw_elp_2115", "st_ftw", "Track 4", 1, 76500, 76500, 0, true, false),
        StopTimeEntity("st_401_2", "tr_ftw_elp_2115", "st_maf", null, 2, 7500, 7800, 1, true, true),
        StopTimeEntity("st_401_3", "tr_ftw_elp_2115", "st_elp", "Track 1", 3, 27900, 27900, 1, false, true),

        // TX-402: El Paso 20:00 MT -> Midland 02:30 CT (+1d) -> Fort Worth 08:15 CT (+1d)
        StopTimeEntity("st_402_1", "tr_elp_ftw_2000", "st_elp", "Track 1", 1, 72000, 72000, 0, true, false),
        StopTimeEntity("st_402_2", "tr_elp_ftw_2000", "st_maf", null, 2, 9000, 9300, 1, true, true),
        StopTimeEntity("st_402_3", "tr_elp_ftw_2000", "st_ftw", "Track 4", 3, 29700, 29700, 1, false, true),

        // TX-501: Houston 07:30 -> College Station 09:05 -> Austin 10:35 -> San Antonio 11:45
        StopTimeEntity("st_501_1", "tr_hou_sat_0730", "st_hou", "Track 1", 1, 27000, 27000, 0, true, false),
        StopTimeEntity("st_501_2", "tr_hou_sat_0730", "st_bcs", "Track 1", 2, 32700, 32820, 0, true, true),
        StopTimeEntity("st_501_3", "tr_hou_sat_0730", "st_aus", "Track 2", 3, 38100, 38400, 0, true, true),
        StopTimeEntity("st_501_4", "tr_hou_sat_0730", "st_sat", "Track 3", 4, 42300, 42300, 0, false, true),

        // TX-502: San Antonio 13:15 -> Austin 14:25 -> College Station 15:55 -> Houston 17:30
        StopTimeEntity("st_502_1", "tr_sat_hou_1315", "st_sat", "Track 3", 1, 47700, 47700, 0, true, false),
        StopTimeEntity("st_502_2", "tr_sat_hou_1315", "st_aus", "Track 1", 2, 51900, 52200, 0, true, true),
        StopTimeEntity("st_502_3", "tr_sat_hou_1315", "st_bcs", "Track 1", 3, 57300, 57420, 0, true, true),
        StopTimeEntity("st_502_4", "tr_sat_hou_1315", "st_hou", "Track 2", 4, 63000, 63000, 0, false, true),

        // TX-601 & TX-602: San Antonio <-> Corpus Christi
        StopTimeEntity("st_601_1", "tr_sat_crp_1215", "st_sat", "Track 4", 1, 44100, 44100, 0, true, false),
        StopTimeEntity("st_601_2", "tr_sat_crp_1215", "st_crp", "Track 1", 2, 52800, 52800, 0, false, true),
        StopTimeEntity("st_602_1", "tr_crp_sat_0900", "st_crp", "Track 1", 1, 32400, 32400, 0, true, false),
        StopTimeEntity("st_602_2", "tr_crp_sat_0900", "st_sat", "Track 4", 2, 41100, 41100, 0, false, true)
    )

    val transfers: List<TransferEntity> = listOf(
        TransferEntity("xf_ftw", "st_ftw", "st_ftw", 15, 90, true),
        TransferEntity("xf_aus", "st_aus", "st_aus", 12, 60, true),
        TransferEntity("xf_sat", "st_sat", "st_sat", 15, 75, true),
        TransferEntity("xf_dal", "st_dal", "st_dal", 15, 85, true)
    )

    val alerts: List<ServiceAlertEntity> = listOf(
        ServiceAlertEntity(
            id = "alt_concept_1",
            routeId = "rt_i35",
            stationId = null,
            title = "Concept Network Demonstration Notice",
            description = "All schedules, platform assignments, and fares in Concept Demonstration mode are illustrative models and do not represent live passenger rail operations.",
            severity = "INFO",
            startsAtMillis = Instant.parse("2026-01-01T00:00:00Z").toEpochMilli(),
            endsAtMillis = Instant.parse("2027-12-31T23:59:59Z").toEpochMilli(),
            operatingMode = "CONCEPT_DEMONSTRATION",
            sourceId = "concept:alt_1"
        ),
        ServiceAlertEntity(
            id = "alt_concept_2",
            routeId = "rt_west",
            stationId = "st_elp",
            title = "Central / Mountain Time Zone Boundary",
            description = "El Paso operates in Mountain Time (America/Denver). Itineraries between Central Texas and El Paso display CT and MT labels explicitly.",
            severity = "ADVISORY",
            startsAtMillis = Instant.parse("2026-01-01T00:00:00Z").toEpochMilli(),
            endsAtMillis = Instant.parse("2027-12-31T23:59:59Z").toEpochMilli(),
            operatingMode = "CONCEPT_DEMONSTRATION",
            sourceId = "concept:alt_2"
        )
    )

    /**
     * Exact reproducible base fares, taxes, and fees for every trip so that:
     * TX-101 = $49 ($43.20 + $3.80 + $2.00)
     * TX-103 = $59 ($52.40 + $4.60 + $2.00)
     * TX-105 = $45 ($39.50 + $3.50 + $2.00)
     */
    fun basePricingForTrip(tripId: String): Triple<Long, Long, Long> = when (tripId) {
        "tr_dal_aus_0800" -> Triple(4320L, 380L, 200L) // $49.00
        "tr_dal_aus_1030" -> Triple(5240L, 460L, 200L) // $59.00
        "tr_dal_aus_1300" -> Triple(3950L, 350L, 200L) // $45.00
        "tr_aus_dal_0915" -> Triple(4320L, 380L, 200L) // $49.00
        "tr_aus_dal_1400" -> Triple(4850L, 450L, 200L) // $55.00
        "tr_dal_ftw_0700", "tr_dal_ftw_1945", "tr_ftw_dal_1415" -> Triple(1600L, 150L, 150L) // $19.00
        "tr_ftw_ama_0830", "tr_ama_ftw_1430" -> Triple(6000L, 550L, 250L) // $68.00
        "tr_ftw_elp_2115", "tr_elp_ftw_2000" -> Triple(10200L, 950L, 350L) // $115.00
        "tr_hou_sat_0730", "tr_sat_hou_1315" -> Triple(4750L, 450L, 200L) // $54.00
        "tr_sat_crp_1215", "tr_crp_sat_0900" -> Triple(2950L, 250L, 200L) // $34.00
        else -> Triple(4000L, 350L, 150L)
    }

    fun initialInventoryForDate(date: LocalDate): List<TripInventoryEntity> {
        val dateIso = date.toString()
        val preOccupied = listOf("1A", "1B", "2C", "4D")
        return trips.map { trip ->
            val (base, tax, fee) = basePricingForTrip(trip.id)
            val totalSeats = 48
            val available = when (trip.id) {
                "tr_dal_aus_0800" -> 42
                "tr_dal_aus_1030" -> 28
                "tr_dal_aus_1300" -> 44
                else -> totalSeats - preOccupied.size
            }
            TripInventoryEntity(
                tripId = trip.id,
                serviceDateIso = dateIso,
                fareClass = "Standard",
                totalSeats = totalSeats,
                availableSeats = available,
                occupiedSeatsJson = json.encodeToString(preOccupied),
                baseFareCents = base,
                taxCents = tax,
                feeCents = fee,
                currency = "USD"
            )
        }
    }
}
