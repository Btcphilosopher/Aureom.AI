package com.example.core.routing

import com.example.core.model.CalendarException
import com.example.core.model.CalendarExceptionType
import com.example.core.model.FareOffer
import com.example.core.model.JourneyFilter
import com.example.core.model.JourneyLeg
import com.example.core.model.JourneyOption
import com.example.core.model.JourneySearchQuery
import com.example.core.model.JourneyStopPoint
import com.example.core.model.Route
import com.example.core.model.ServiceCalendar
import com.example.core.model.ServiceStatus
import com.example.core.model.Station
import com.example.core.model.StopTime
import com.example.core.model.Transfer
import com.example.core.model.Trip
import com.example.core.time.TexasRailTime
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Timetable-aware RAPTOR (Round-Based Public Transit Router) operating over exact UTC [Instant]s
 * derived from station IANA time zones, service calendars, exceptions, minimum transfer times,
 * and overnight offsets.
 */
@Singleton
class RaptorRouter @Inject constructor() {

    data class TimetableSnapshot(
        val stations: Map<String, Station>,
        val routes: Map<String, Route>,
        val calendars: Map<String, ServiceCalendar>,
        val exceptions: List<CalendarException>,
        val trips: List<Trip>,
        val stopTimesByTrip: Map<String, List<StopTime>>,
        val transfersByStation: Map<String, List<Transfer>>
    )

    private data class Label(
        val arrivalInstant: Instant,
        val tripId: String?,
        val boardStationId: String?,
        val boardInstant: Instant?,
        val prevStationId: String?,
        val transferUsed: Transfer?,
        val round: Int
    )

    fun isServiceRunning(
        calendar: ServiceCalendar,
        exceptions: List<CalendarException>,
        serviceCalendarId: String,
        date: LocalDate
    ): Boolean {
        val exception = exceptions.firstOrNull {
            it.serviceCalendarId == serviceCalendarId && it.date == date
        }
        if (exception != null) {
            return exception.type == CalendarExceptionType.ADDED
        }
        if (date.isBefore(calendar.startDate) || date.isAfter(calendar.endDate)) {
            return false
        }
        return when (date.dayOfWeek) {
            DayOfWeek.MONDAY -> calendar.monday
            DayOfWeek.TUESDAY -> calendar.tuesday
            DayOfWeek.WEDNESDAY -> calendar.wednesday
            DayOfWeek.THURSDAY -> calendar.thursday
            DayOfWeek.FRIDAY -> calendar.friday
            DayOfWeek.SATURDAY -> calendar.saturday
            DayOfWeek.SUNDAY -> calendar.sunday
        }
    }

    suspend fun findJourneys(
        snapshot: TimetableSnapshot,
        query: JourneySearchQuery,
        fareResolver: suspend (List<String>, LocalDate, Int) -> FareOffer?
    ): List<JourneyOption> {
        val origin = snapshot.stations[query.originStationId] ?: return emptyList()
        val destination = snapshot.stations[query.destinationStationId] ?: return emptyList()
        if (origin.id == destination.id) return emptyList()

        // Evaluate trips active on serviceDate (and previous day if overnight trains arrive on serviceDate)
        val activeTrips = snapshot.trips.filter { trip ->
            val cal = snapshot.calendars[trip.serviceCalendarId] ?: return@filter false
            isServiceRunning(cal, snapshot.exceptions, trip.serviceCalendarId, query.serviceDate)
        }

        val candidates = mutableListOf<JourneyOption>()

        // Round 0: Direct trips serving origin -> destination in sequence order
        for (trip in activeTrips) {
            val stops = snapshot.stopTimesByTrip[trip.id]?.sortedBy { it.stopSequence } ?: continue
            val originIdx = stops.indexOfFirst { it.stationId == origin.id && it.pickupAllowed }
            val destIdx = stops.indexOfLast { it.stationId == destination.id && it.dropoffAllowed }
            if (originIdx >= 0 && destIdx > originIdx) {
                buildDirectOption(
                    snapshot = snapshot,
                    trip = trip,
                    stops = stops.subList(originIdx, destIdx + 1),
                    serviceDate = query.serviceDate,
                    passengerCount = query.passengerCount,
                    fareResolver = fareResolver
                )?.let { candidates.add(it) }
            }
        }

        // Round 1 (RAPTOR 1-transfer pass): Origin -> Transfer Station -> Destination
        val earliestAtStation = mutableMapOf<String, MutableList<Label>>()
        for (trip in activeTrips) {
            val stops = snapshot.stopTimesByTrip[trip.id]?.sortedBy { it.stopSequence } ?: continue
            val originIdx = stops.indexOfFirst { it.stationId == origin.id && it.pickupAllowed }
            if (originIdx < 0) continue
            val boardStop = stops[originIdx]
            val boardStation = snapshot.stations[boardStop.stationId] ?: continue
            val boardInstant = TexasRailTime.resolveStopInstant(
                query.serviceDate,
                boardStop.departureOffsetSeconds,
                boardStop.dayOffset,
                boardStation.timeZoneId
            )

            for (idx in (originIdx + 1) until stops.size) {
                val alightStop = stops[idx]
                if (!alightStop.dropoffAllowed || alightStop.stationId == destination.id) continue
                val alightStation = snapshot.stations[alightStop.stationId] ?: continue
                val arrivalInstant = TexasRailTime.resolveStopInstant(
                    query.serviceDate,
                    alightStop.arrivalOffsetSeconds,
                    alightStop.dayOffset,
                    alightStation.timeZoneId
                )
                earliestAtStation.getOrPut(alightStop.stationId) { mutableListOf() }.add(
                    Label(
                        arrivalInstant = arrivalInstant,
                        tripId = trip.id,
                        boardStationId = origin.id,
                        boardInstant = boardInstant,
                        prevStationId = origin.id,
                        transferUsed = null,
                        round = 1
                    )
                )
            }
        }

        // Expand second leg from reached intermediate transfer hubs
        for ((hubId, firstLegLabels) in earliestAtStation) {
            val bestFirstLeg = firstLegLabels.minByOrNull { it.arrivalInstant } ?: continue
            val firstTrip = snapshot.trips.firstOrNull { it.id == bestFirstLeg.tripId } ?: continue
            val hubTransfers = snapshot.transfersByStation[hubId].orEmpty()
            val defaultTransfer = hubTransfers.firstOrNull { it.toStationId == hubId }
                ?: Transfer(
                    id = "default_$hubId",
                    fromStationId = hubId,
                    toStationId = hubId,
                    minTransferMinutes = 15,
                    walkingDistanceMeters = 75,
                    accessiblePath = snapshot.stations[hubId]?.accessibility?.stepFreeAccess
                )

            val minConnectInstant = bestFirstLeg.arrivalInstant.plusSeconds(defaultTransfer.minTransferMinutes * 60L)

            for (secondTrip in activeTrips) {
                if (secondTrip.id == firstTrip.id) continue
                val stops2 = snapshot.stopTimesByTrip[secondTrip.id]?.sortedBy { it.stopSequence } ?: continue
                val hubIdx = stops2.indexOfFirst { it.stationId == hubId && it.pickupAllowed }
                val destIdx = stops2.indexOfLast { it.stationId == destination.id && it.dropoffAllowed }
                if (hubIdx < 0 || destIdx <= hubIdx) continue

                val hubStation = snapshot.stations[hubId] ?: continue
                val secondDepInstant = TexasRailTime.resolveStopInstant(
                    query.serviceDate,
                    stops2[hubIdx].departureOffsetSeconds,
                    stops2[hubIdx].dayOffset,
                    hubStation.timeZoneId
                )
                if (secondDepInstant.isBefore(minConnectInstant)) continue

                // Skip redundant 1-stop if a direct trip already beats it on both departure & arrival
                val stops1 = snapshot.stopTimesByTrip[firstTrip.id]?.sortedBy { it.stopSequence } ?: continue
                val oIdx1 = stops1.indexOfFirst { it.stationId == origin.id }
                val hIdx1 = stops1.indexOfFirst { it.stationId == hubId }
                if (oIdx1 < 0 || hIdx1 <= oIdx1) continue

                val leg1Stops = stops1.subList(oIdx1, hIdx1 + 1)
                val leg2Stops = stops2.subList(hubIdx, destIdx + 1)
                buildConnectingOption(
                    snapshot = snapshot,
                    trip1 = firstTrip,
                    stops1 = leg1Stops,
                    trip2 = secondTrip,
                    stops2 = leg2Stops,
                    transfer = defaultTransfer,
                    serviceDate = query.serviceDate,
                    passengerCount = query.passengerCount,
                    fareResolver = fareResolver
                )?.let { option ->
                    val dominatedByDirect = candidates.any { direct ->
                        direct.isDirect &&
                            !direct.departureInstant.isBefore(option.departureInstant) &&
                            !direct.arrivalInstant.isAfter(option.arrivalInstant)
                    }
                    if (!dominatedByDirect) {
                        candidates.add(option)
                    }
                }
            }
        }

        // Apply user filters deterministically
        val filtered = candidates.filter { option ->
            val directOk = if (JourneyFilter.DIRECT in query.activeFilters) option.isDirect else true
            val accessibleOk = if (JourneyFilter.ACCESSIBLE in query.activeFilters) option.accessibilityVerified else true
            directOk && accessibleOk
        }

        return when {
            JourneyFilter.LOWEST_FARE in query.activeFilters ->
                filtered.sortedWith(compareBy<JourneyOption> { it.fareOffer.totalPerPassenger.cents }.thenBy { it.departureInstant })
            JourneyFilter.FASTEST in query.activeFilters ->
                filtered.sortedWith(compareBy<JourneyOption> { it.totalDurationMinutes }.thenBy { it.departureInstant })
            else ->
                filtered.sortedWith(compareBy<JourneyOption> { it.transferCount }.thenBy { it.departureInstant })
        }
    }

    private suspend fun buildDirectOption(
        snapshot: TimetableSnapshot,
        trip: Trip,
        stops: List<StopTime>,
        serviceDate: LocalDate,
        passengerCount: Int,
        fareResolver: suspend (List<String>, LocalDate, Int) -> FareOffer?
    ): JourneyOption? {
        val route = snapshot.routes[trip.routeId] ?: return null
        val stopPoints = stops.mapNotNull { st ->
            val station = snapshot.stations[st.stationId] ?: return@mapNotNull null
            JourneyStopPoint(
                station = station,
                arrivalInstant = TexasRailTime.resolveStopInstant(serviceDate, st.arrivalOffsetSeconds, st.dayOffset, station.timeZoneId),
                departureInstant = TexasRailTime.resolveStopInstant(serviceDate, st.departureOffsetSeconds, st.dayOffset, station.timeZoneId),
                platformCode = st.platformCode
            )
        }
        if (stopPoints.size < 2) return null
        val originPoint = stopPoints.first()
        val destPoint = stopPoints.last()
        val depInstant = originPoint.departureInstant ?: return null
        val arrInstant = destPoint.arrivalInstant ?: return null
        val durationMin = TexasRailTime.elapsedMinutes(depInstant, arrInstant)
        val fareOffer = fareResolver(listOf(trip.id), serviceDate, passengerCount) ?: return null

        val status = if (trip.operatingMode == com.example.core.model.OperatingMode.CONCEPT_DEMONSTRATION) {
            ServiceStatus.SCHEDULED_ILLUSTRATIVE
        } else {
            ServiceStatus.ON_TIME
        }

        val (accVerified, accText) = evaluateAccessibility(
            trips = listOf(trip),
            stations = listOf(originPoint.station, destPoint.station),
            transfers = emptyList()
        )

        return JourneyOption(
            id = "jrn_${trip.id}_${originPoint.station.code}_${destPoint.station.code}_$serviceDate",
            legs = listOf(
                JourneyLeg.RailRide(
                    trip = trip,
                    route = route,
                    originStop = originPoint,
                    destinationStop = destPoint,
                    intermediateStops = stopPoints.drop(1).dropLast(1),
                    durationMinutes = durationMin,
                    serviceStatus = status
                )
            ),
            originStation = originPoint.station,
            destinationStation = destPoint.station,
            departureInstant = depInstant,
            arrivalInstant = arrInstant,
            totalDurationMinutes = durationMin,
            transferCount = 0,
            fareOffer = fareOffer,
            serviceStatus = status,
            accessibilityVerified = accVerified,
            accessibilityDisclosure = accText,
            operatingMode = trip.operatingMode
        )
    }

    private suspend fun buildConnectingOption(
        snapshot: TimetableSnapshot,
        trip1: Trip,
        stops1: List<StopTime>,
        trip2: Trip,
        stops2: List<StopTime>,
        transfer: Transfer,
        serviceDate: LocalDate,
        passengerCount: Int,
        fareResolver: suspend (List<String>, LocalDate, Int) -> FareOffer?
    ): JourneyOption? {
        val route1 = snapshot.routes[trip1.routeId] ?: return null
        val route2 = snapshot.routes[trip2.routeId] ?: return null
        val points1 = stops1.mapNotNull { st ->
            val station = snapshot.stations[st.stationId] ?: return@mapNotNull null
            JourneyStopPoint(
                station = station,
                arrivalInstant = TexasRailTime.resolveStopInstant(serviceDate, st.arrivalOffsetSeconds, st.dayOffset, station.timeZoneId),
                departureInstant = TexasRailTime.resolveStopInstant(serviceDate, st.departureOffsetSeconds, st.dayOffset, station.timeZoneId),
                platformCode = st.platformCode
            )
        }
        val points2 = stops2.mapNotNull { st ->
            val station = snapshot.stations[st.stationId] ?: return@mapNotNull null
            JourneyStopPoint(
                station = station,
                arrivalInstant = TexasRailTime.resolveStopInstant(serviceDate, st.arrivalOffsetSeconds, st.dayOffset, station.timeZoneId),
                departureInstant = TexasRailTime.resolveStopInstant(serviceDate, st.departureOffsetSeconds, st.dayOffset, station.timeZoneId),
                platformCode = st.platformCode
            )
        }
        if (points1.size < 2 || points2.size < 2) return null

        val leg1Dep = points1.first().departureInstant ?: return null
        val leg1Arr = points1.last().arrivalInstant ?: return null
        val leg2Dep = points2.first().departureInstant ?: return null
        val leg2Arr = points2.last().arrivalInstant ?: return null

        val leg1Dur = TexasRailTime.elapsedMinutes(leg1Dep, leg1Arr)
        val waitDur = TexasRailTime.elapsedMinutes(leg1Arr, leg2Dep)
        val leg2Dur = TexasRailTime.elapsedMinutes(leg2Dep, leg2Arr)
        val totalDur = TexasRailTime.elapsedMinutes(leg1Dep, leg2Arr)

        val fareOffer = fareResolver(listOf(trip1.id, trip2.id), serviceDate, passengerCount) ?: return null
        val hubStation = points1.last().station
        val status = if (trip1.operatingMode == com.example.core.model.OperatingMode.CONCEPT_DEMONSTRATION) {
            ServiceStatus.SCHEDULED_ILLUSTRATIVE
        } else {
            ServiceStatus.ON_TIME
        }

        val (accVerified, accText) = evaluateAccessibility(
            trips = listOf(trip1, trip2),
            stations = listOf(points1.first().station, hubStation, points2.last().station),
            transfers = listOf(transfer)
        )

        return JourneyOption(
            id = "jrn_${trip1.id}_${trip2.id}_${points1.first().station.code}_${points2.last().station.code}_$serviceDate",
            legs = listOf(
                JourneyLeg.RailRide(
                    trip = trip1,
                    route = route1,
                    originStop = points1.first(),
                    destinationStop = points1.last(),
                    intermediateStops = points1.drop(1).dropLast(1),
                    durationMinutes = leg1Dur,
                    serviceStatus = status
                ),
                JourneyLeg.TransferWalk(
                    station = hubStation,
                    minConnectionMinutes = transfer.minTransferMinutes,
                    walkingDistanceMeters = transfer.walkingDistanceMeters,
                    accessiblePath = transfer.accessiblePath,
                    waitDurationMinutes = waitDur
                ),
                JourneyLeg.RailRide(
                    trip = trip2,
                    route = route2,
                    originStop = points2.first(),
                    destinationStop = points2.last(),
                    intermediateStops = points2.drop(1).dropLast(1),
                    durationMinutes = leg2Dur,
                    serviceStatus = status
                )
            ),
            originStation = points1.first().station,
            destinationStation = points2.last().station,
            departureInstant = leg1Dep,
            arrivalInstant = leg2Arr,
            totalDurationMinutes = totalDur,
            transferCount = 1,
            fareOffer = fareOffer,
            serviceStatus = status,
            accessibilityVerified = accVerified,
            accessibilityDisclosure = accText,
            operatingMode = trip1.operatingMode
        )
    }

    private fun evaluateAccessibility(
        trips: List<Trip>,
        stations: List<Station>,
        transfers: List<Transfer>
    ): Pair<Boolean, String> {
        val allTrainsAccessible = trips.all { it.wheelchairAccessible == true && it.levelBoardingVerified == true }
        val allStationsAccessible = stations.all { it.accessibility.isVerifiedStepFree }
        val allTransfersAccessible = transfers.all { it.accessiblePath == true }

        val anyUnknown = trips.any { it.wheelchairAccessible == null || it.levelBoardingVerified == null } ||
            stations.any { it.accessibility.stepFreeAccess == null || it.accessibility.levelBoarding == null } ||
            transfers.any { it.accessiblePath == null }

        return when {
            allTrainsAccessible && allStationsAccessible && allTransfersAccessible ->
                true to "Step-free station access and level boarding verified on all segments."
            anyUnknown ->
                false to "Accessibility unverified: level boarding or transfer path information is unknown for one or more stops."
            else ->
                false to "Accessible boarding unavailable on one or more segments."
        }
    }
}
