package com.example.feature.booking

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Accessible
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.LocalTexasRailTokens
import com.example.core.designsystem.OperatingModeBanner
import com.example.core.designsystem.QrCodeMatrixView
import com.example.core.designsystem.TexasRailTopBar
import com.example.core.model.OperatingMode
import com.example.core.model.PassengerType
import com.example.core.model.SandboxPaymentOutcome
import com.example.core.time.TexasRailTime
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.Instant

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookingScreen(
    journeyId: String,
    viewModel: BookingViewModel,
    onExitToResults: () -> Unit,
    onOpenTicketsWallet: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val tokens = LocalTexasRailTokens.current

    LaunchedEffect(journeyId) {
        viewModel.initialize(journeyId)
    }

    BackHandler(enabled = state.step == BookingStep.SEATS || state.step == BookingStep.REVIEW_AND_PAY) {
        viewModel.goBackStep()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.pageBackground)
    ) {
        TexasRailTopBar(
            showBack = state.step != BookingStep.CONFIRMED,
            onBackClick = {
                if (state.step == BookingStep.PASSENGERS) onExitToResults()
                else viewModel.goBackStep()
            },
            operatingMode = state.journey?.operatingMode
        )

        val journey = state.journey
        if (journey == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Select a journey to begin booking.", color = tokens.primaryInk)
            }
            return@Column
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .widthIn(max = 720.dp)
                .align(Alignment.CenterHorizontally)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Clear Checkout Mode Disclosure
            OperatingModeBanner(
                operatingMode = journey.operatingMode,
                customText = if (journey.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                    "DEMONSTRATION CHECKOUT — Sandbox simulation only, no real charge"
                } else if (!state.connectedTicketingAuthorized) {
                    "Connected operator ticketing is not configured. Purchasing is disabled."
                } else {
                    "Connected operator checkout"
                }
            )

            // Step indicator
            StepProgressHeader(step = state.step)

            if (state.errorMessage != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("booking_error_banner")
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(state.errorMessage!!, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            when (state.step) {
                BookingStep.PASSENGERS -> {
                    Text(
                        text = "Passenger Details",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = tokens.primaryInk,
                        modifier = Modifier.semantics { heading() }
                    )

                    if (state.savedPassengers.isNotEmpty()) {
                        Text("Quick fill saved passenger", style = MaterialTheme.typography.labelLarge, color = tokens.secondaryInk)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            state.savedPassengers.forEach { saved ->
                                AssistChip(
                                    onClick = { viewModel.applySavedPassenger(0, saved) },
                                    label = { Text(saved.fullName) }
                                )
                            }
                        }
                    }

                    state.passengers.forEachIndexed { idx, pax ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = tokens.cardSurface,
                            border = BorderStroke(1.dp, tokens.divider)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "Passenger ${idx + 1}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = tokens.primaryInk
                                )
                                OutlinedTextField(
                                    value = pax.fullName,
                                    onValueChange = { viewModel.updatePassenger(idx, it, pax.email, pax.passengerType, pax.accessibilityNotes) },
                                    label = { Text("Full name *") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("passenger_name_input_$idx")
                                )
                                if (idx == 0) {
                                    OutlinedTextField(
                                        value = pax.email,
                                        onValueChange = { viewModel.updatePassenger(idx, pax.fullName, it, pax.passengerType, pax.accessibilityNotes) },
                                        label = { Text("Receipt email (optional)") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth().testTag("passenger_email_input")
                                    )
                                }
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    PassengerType.entries.forEach { pt ->
                                        FilterChip(
                                            selected = pax.passengerType == pt,
                                            onClick = { viewModel.updatePassenger(idx, pax.fullName, pax.email, pt, pax.accessibilityNotes) },
                                            label = { Text(pt.name.lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }) }
                                        )
                                    }
                                }
                                OutlinedTextField(
                                    value = pax.accessibilityNotes,
                                    onValueChange = { viewModel.updatePassenger(idx, pax.fullName, pax.email, pax.passengerType, it) },
                                    label = { Text("Mobility or boarding assistance notes (optional)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    Button(
                        onClick = viewModel::proceedToSeats,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("booking_next_to_seats")
                    ) {
                        Text("Continue to seat selection", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }

                BookingStep.SEATS -> {
                    Text(
                        text = "Optional Seat Selection",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = tokens.primaryInk,
                        modifier = Modifier.semantics { heading() }
                    )
                    Text(
                        text = "Select up to ${state.passengerCount} seat(s) in Coach 1, or continue to assign available seats automatically.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = tokens.secondaryInk
                    )

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.cardSurface,
                        border = BorderStroke(1.dp, tokens.divider)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                SeatLegendChip("Available", tokens.cardSecondary, tokens.primaryInk)
                                SeatLegendChip("Selected", tokens.accentOrange, Color.White)
                                SeatLegendChip("Occupied", tokens.divider, tokens.secondaryInk)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            val rows = state.seatMap.chunked(4)
                            rows.take(8).forEach { rowSeats ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    rowSeats.forEachIndexed { colIdx, seat ->
                                        if (colIdx == 2) Spacer(modifier = Modifier.width(12.dp))
                                        val isSelected = seat.seatNumber in state.selectedSeats
                                        val bg = when {
                                            seat.isOccupied -> tokens.divider
                                            isSelected -> tokens.accentOrange
                                            else -> tokens.cardSecondary
                                        }
                                        val fg = when {
                                            seat.isOccupied -> tokens.secondaryInk
                                            isSelected -> Color.White
                                            else -> tokens.primaryInk
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = bg,
                                            border = BorderStroke(1.dp, if (isSelected) tokens.accentOrange else tokens.divider),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                                .clickable(enabled = !seat.isOccupied) {
                                                    viewModel.toggleSeat(seat.seatNumber)
                                                }
                                                .testTag("seat_${seat.seatNumber}")
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxSize(),
                                                horizontalArrangement = Arrangement.Center,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                if (seat.isAccessibleSpace) {
                                                    Icon(Icons.AutoMirrored.Outlined.Accessible, contentDescription = "Accessible space", tint = fg, modifier = Modifier.size(13.dp))
                                                    Spacer(modifier = Modifier.width(2.dp))
                                                }
                                                Text(seat.seatNumber, style = MaterialTheme.typography.labelLarge, color = fg)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = viewModel::reserveAndProceedToReview,
                            enabled = !state.isBusy,
                            modifier = Modifier.weight(1f).height(50.dp)
                        ) {
                            Text("Auto-assign")
                        }
                        Button(
                            onClick = viewModel::reserveAndProceedToReview,
                            enabled = !state.isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                            modifier = Modifier.weight(1f).height(50.dp).testTag("booking_reserve_button")
                        ) {
                            if (state.isBusy) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                            } else {
                                Text("Hold seats & review")
                            }
                        }
                    }
                }

                BookingStep.REVIEW_AND_PAY -> {
                    val reservation = state.reservation
                    var remainingSec by remember(reservation?.id) { mutableLongStateOf(600L) }
                    LaunchedEffect(reservation?.expiresAt) {
                        while (reservation != null) {
                            remainingSec = Duration.between(Instant.now(), reservation.expiresAt).seconds.coerceAtLeast(0L)
                            delay(1000L)
                        }
                    }

                    Text(
                        text = "Fare Review & Sandbox Payment",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = tokens.primaryInk,
                        modifier = Modifier.semantics { heading() }
                    )

                    if (reservation != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.accentSoft,
                            border = BorderStroke(1.dp, tokens.accentOrange.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Outlined.Timer, contentDescription = null, tint = tokens.accentOrange)
                                Spacer(modifier = Modifier.width(8.dp))
                                val mins = remainingSec / 60
                                val secs = remainingSec % 60
                                Text(
                                    text = "Inventory hold active • Expires in %02d:%02d".format(mins, secs),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = tokens.accentOrange
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = tokens.cardSurface,
                            border = BorderStroke(1.dp, tokens.divider)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Final Price Confirmation", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text(
                                    text = "${journey.originStation.name} → ${journey.destinationStation.name} • ${TexasRailTime.formatDateChip(reservation.serviceDate)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = tokens.secondaryInk
                                )
                                Text(
                                    text = "Passengers: ${state.passengers.joinToString { it.fullName }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.secondaryInk
                                )
                                Text(
                                    text = "Locked conditions: ${reservation.fareConditionSnapshot.summaryText}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.secondaryInk
                                )
                                HorizontalDivider(color = tokens.divider)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Subtotal", color = tokens.secondaryInk)
                                    Text(TexasRailTime.formatMoneyExact(reservation.subtotal))
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Taxes", color = tokens.secondaryInk)
                                    Text(TexasRailTime.formatMoneyExact(reservation.tax))
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Booking fee", color = tokens.secondaryInk)
                                    Text(TexasRailTime.formatMoneyExact(reservation.fee))
                                }
                                HorizontalDivider(color = tokens.divider)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Total (${reservation.total.currency})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    Text(
                                        TexasRailTime.formatMoneyExact(reservation.total),
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                                        color = tokens.accentOrange
                                    )
                                }
                            }
                        }

                        // Tokenised Sandbox Payment Method (no PAN/CVV fields stored!)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = tokens.cardSurface,
                            border = BorderStroke(1.dp, tokens.divider)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.CreditCard, contentDescription = null, tint = tokens.accentOrange)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Tokenised Sandbox Payment Method", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                }
                                Text(
                                    "Card details are never entered or stored in-app. Payment uses opaque sandbox tokens.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = tokens.secondaryInk
                                )
                                listOf(
                                    "tok_sandbox_visa_4242" to "Sandbox Visa Token (•••• 4242)",
                                    "tok_sandbox_mc_5555" to "Sandbox Mastercard Token (•••• 5555)",
                                    "tok_sandbox_wallet" to "Sandbox Digital Wallet Token"
                                ).forEach { (tok, label) ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .minimumInteractiveComponentSize()
                                            .clickable { viewModel.selectPaymentToken(tok) },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(selected = state.selectedToken == tok, onClick = { viewModel.selectPaymentToken(tok) })
                                        Text(label, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }

                                HorizontalDivider(color = tokens.divider)
                                Text("Sandbox Gateway Outcome Simulation", style = MaterialTheme.typography.labelLarge, color = tokens.secondaryInk)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(
                                        SandboxPaymentOutcome.SUCCEED to "Approve",
                                        SandboxPaymentOutcome.DUPLICATE_WEBHOOK_SUCCEED to "Duplicate Webhook",
                                        SandboxPaymentOutcome.FAIL_DECLINED to "Decline",
                                        SandboxPaymentOutcome.CANCELLED_BY_USER to "Cancel"
                                    ).forEach { (outcome, label) ->
                                        FilterChip(
                                            selected = state.sandboxOutcome == outcome,
                                            onClick = { viewModel.selectSandboxOutcome(outcome) },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }
                        }

                        val canPay = journey.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION || state.connectedTicketingAuthorized
                        Button(
                            onClick = viewModel::submitPaymentAndConfirm,
                            enabled = canPay && !state.isBusy && remainingSec > 0,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                            modifier = Modifier.fillMaxWidth().height(54.dp).testTag("booking_confirm_pay_button")
                        ) {
                            if (state.isBusy) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
                            } else {
                                Text(
                                    text = if (journey.operatingMode == OperatingMode.CONCEPT_DEMONSTRATION) {
                                        "Complete Demo Checkout (${TexasRailTime.formatMoneyExact(reservation.total)})"
                                    } else {
                                        "Pay & Confirm Booking"
                                    },
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                BookingStep.CONFIRMED -> {
                    val booking = state.confirmedBooking
                    if (booking != null) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = tokens.cardSurface,
                            border = BorderStroke(1.5.dp, tokens.accentOrange)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.CheckCircle,
                                    contentDescription = null,
                                    tint = tokens.verifiedBadgeInk,
                                    modifier = Modifier.size(44.dp)
                                )
                                Text(
                                    text = if (booking.ticket.isDemonstration) "Demonstration Booking Confirmed" else "Booking Confirmed",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                                    color = tokens.primaryInk
                                )
                                Text(
                                    text = "Reference: ${booking.referenceCode}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = tokens.accentOrange
                                )
                                QrCodeMatrixView(
                                    payload = booking.ticket.qrPayload,
                                    isDemonstration = booking.ticket.isDemonstration,
                                    demoDisclaimer = booking.ticket.demoDisclaimer
                                )
                                Text(
                                    text = "Saved offline in your Ticket Wallet.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = tokens.secondaryInk
                                )
                                Button(
                                    onClick = onOpenTicketsWallet,
                                    colors = ButtonDefaults.buttonColors(containerColor = tokens.accentOrange),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("open_ticket_wallet_button")
                                ) {
                                    Text("View in Ticket Wallet", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepProgressHeader(step: BookingStep) {
    val tokens = LocalTexasRailTokens.current
    val steps = listOf(
        BookingStep.PASSENGERS to "1. Passengers",
        BookingStep.SEATS to "2. Seats",
        BookingStep.REVIEW_AND_PAY to "3. Review & Pay",
        BookingStep.CONFIRMED to "4. Ticket"
    )
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        steps.forEach { (s, label) ->
            val active = s.ordinal <= step.ordinal
            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                color = if (active) tokens.accentOrange else tokens.cardSurface,
                border = BorderStroke(1.dp, if (active) tokens.accentOrange else tokens.divider)
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (active) Color.White else tokens.secondaryInk,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun SeatLegendChip(label: String, bg: Color, fg: Color) {
    Surface(color = bg, shape = RoundedCornerShape(6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
