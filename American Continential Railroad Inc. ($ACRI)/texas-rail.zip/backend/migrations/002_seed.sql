-- 002_seed.sql: Coherent fictional concept network seed data for Texas Rail

INSERT INTO dataset_versions (id, operating_mode, source_name, published_at, checksum)
VALUES (
    'concept-2026.11',
    'CONCEPT_DEMONSTRATION',
    'Texas Rail Concept Network Planning Dataset',
    '2026-11-23T08:00:00Z',
    'sha256:txr-concept-2026-11'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO stations (
    id, code, name, city, time_zone, latitude, longitude, schematic_x, schematic_y, is_major_city,
    address, entrances_json, accessibility_json, parking_bikes_json, local_transit_json, opening_hours,
    source_id, provenance
) VALUES
    ('st_dal', 'DAL', 'Dallas Union Concourse', 'Dallas', 'America/Chicago', 32.7767, -96.7970, 0.72, 0.34, TRUE,
     '400 S Houston St, Dallas, TX 75202',
     '["Houston St Main Concourse", "Ferris Plaza South Entrance"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": true, "tactileGuidance": true, "accessibleRestrooms": true, "audioInductionLoops": true}'::jsonb,
     '{"structuredParkingSpaces": 640, "evChargers": 24, "coveredBikeRacks": 80}'::jsonb,
     '["DART Red/Blue/Green/Orange Rail", "TRE Commuter Rail", "Dallas Streetcar"]'::jsonb,
     '05:00 - 23:30 Daily', 'concept:st_dal', 'CONCEPT_PLANNING'),
    ('st_ftw', 'FTW', 'Fort Worth Central Station', 'Fort Worth', 'America/Chicago', 32.7503, -97.3267, 0.59, 0.35, TRUE,
     '1001 Jones St, Fort Worth, TX 76102',
     '["Jones St East Hall", "9th St Plaza"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": true, "tactileGuidance": true, "accessibleRestrooms": true}'::jsonb,
     '{"structuredParkingSpaces": 410, "coveredBikeRacks": 50}'::jsonb,
     '["TEXRail Airport Link", "TRE Commuter Rail", "Trinity Metro Bus"]'::jsonb,
     '05:15 - 23:00 Daily', 'concept:st_ftw', 'CONCEPT_PLANNING'),
    ('st_aus', 'AUS', 'Austin Capitol Station', 'Austin', 'America/Chicago', 30.2672, -97.7431, 0.58, 0.61, TRUE,
     '250 E 4th St, Austin, TX 78701',
     '["4th Street Pavilion", "Brush Square Concourse"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": true, "tactileGuidance": true, "accessibleRestrooms": true, "assistanceDesk": true}'::jsonb,
     '{"structuredParkingSpaces": 280, "coveredBikeRacks": 120, "bikeLockers": 32}'::jsonb,
     '["CapMetro Rail Red Line", "Rapid 801/803", "MetroBike Hub"]'::jsonb,
     '05:30 - 23:30 Daily', 'concept:st_aus', 'CONCEPT_PLANNING'),
    ('st_sat', 'SAT', 'San Antonio Sunset Depot', 'San Antonio', 'America/Chicago', 29.4241, -98.4936, 0.51, 0.71, TRUE,
     '1174 E Commerce St, San Antonio, TX 78205',
     '["Hoefgen Ave Concourse", "St. Paul Square Arcade"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": true, "tactileGuidance": true, "accessibleRestrooms": true}'::jsonb,
     '{"structuredParkingSpaces": 350, "coveredBikeRacks": 64}'::jsonb,
     '["VIA Primo 100", "VIA Link Downtown"]'::jsonb,
     '05:30 - 23:00 Daily', 'concept:st_sat', 'CONCEPT_PLANNING'),
    ('st_hou', 'HOU', 'Houston Bayou Terminal', 'Houston', 'America/Chicago', 29.7604, -95.3698, 0.80, 0.69, TRUE,
     '902 Washington Ave, Houston, TX 77002',
     '["Washington Ave Grand Hall", "Buffalo Bayou South"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": true, "tactileGuidance": true, "accessibleRestrooms": true, "sensoryRoom": true}'::jsonb,
     '{"structuredParkingSpaces": 780, "evChargers": 32, "coveredBikeRacks": 96}'::jsonb,
     '["METRORail Red/Green/Purple", "METRO Silver Line"]'::jsonb,
     '05:00 - 23:45 Daily', 'concept:st_hou', 'CONCEPT_PLANNING'),
    ('st_elp', 'ELP', 'El Paso Borderland Union', 'El Paso', 'America/Denver', 31.7619, -106.4850, 0.14, 0.49, TRUE,
     '700 W San Francisco Ave, El Paso, TX 79901',
     '["San Francisco Ave Arch", "Union Plaza East"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": null, "tactileGuidance": true, "accessibleRestrooms": true}'::jsonb,
     '{"structuredParkingSpaces": 220, "coveredBikeRacks": 36}'::jsonb,
     '["El Paso Streetcar", "Sun Metro Brio"]'::jsonb,
     '05:30 - 22:30 MT', 'concept:st_elp', 'CONCEPT_PLANNING'),
    ('st_ama', 'AMA', 'Amarillo High Plains Terminal', 'Amarillo', 'America/Chicago', 35.2220, -101.8313, 0.34, 0.16, TRUE,
     '301 S Grant St, Amarillo, TX 79101',
     '["Grant St Depot Hall"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": null, "tactileGuidance": null, "accessibleRestrooms": true}'::jsonb,
     '{"structuredParkingSpaces": 180, "coveredBikeRacks": 24}'::jsonb,
     '["Amarillo City Transit Route 1"]'::jsonb,
     NULL, 'concept:st_ama', 'CONCEPT_PLANNING'),
    ('st_crp', 'CRP', 'Corpus Christi Coastal Depot', 'Corpus Christi', 'America/Chicago', 27.8006, -97.3964, 0.62, 0.88, TRUE,
     '600 N Shoreline Blvd, Corpus Christi, TX 78401',
     '["Shoreline Promenade", "Chaparral St Courtyard"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": true, "tactileGuidance": true, "accessibleRestrooms": true}'::jsonb,
     '{"structuredParkingSpaces": 210, "coveredBikeRacks": 44}'::jsonb,
     '["CCRTA Bayfront Route 76"]'::jsonb,
     '06:00 - 22:00 Daily', 'concept:st_crp', 'CONCEPT_PLANNING'),
    ('st_wac', 'WAC', 'Waco Brazos Stop', 'Waco', 'America/Chicago', 31.5493, -97.1467, 0.67, 0.47, FALSE,
     '200 S University Parks Dr, Waco, TX 76701',
     '["Brazos Riverfront Platform"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": true}'::jsonb,
     '{"structuredParkingSpaces": 120, "coveredBikeRacks": 30}'::jsonb,
     '["Waco Transit Route 1"]'::jsonb,
     '06:00 - 21:30 Daily', 'concept:st_wac', 'CONCEPT_PLANNING'),
    ('st_tpl', 'TPL', 'Temple Junction', 'Temple', 'America/Chicago', 31.0982, -97.3428, 0.62, 0.54, FALSE,
     '315 W Avenue B, Temple, TX 76501',
     '["Santa Fe Plaza Entrance"]'::jsonb,
     '{"stepFreeAccess": true, "levelBoarding": true}'::jsonb,
     '{"structuredParkingSpaces": 140}'::jsonb,
     '["HOP Commuter Shuttle"]'::jsonb,
     '06:00 - 21:30 Daily', 'concept:st_tpl', 'CONCEPT_PLANNING')
ON CONFLICT (id) DO NOTHING;

INSERT INTO routes (id, short_code, name, corridor_color_hex, corridor_pattern, operator_name, operating_mode, source_id, provenance)
VALUES
    ('rt_i35', 'TX-35', 'I-35 Lone Star Express (Dallas–San Antonio)', '#D1510A', 'SOLID', 'Texas Rail Concept', 'CONCEPT_DEMONSTRATION', 'concept:rt_i35', 'CONCEPT_PLANNING'),
    ('rt_triangle', 'TX-HT', 'Texas Triangle Shuttle (Houston–Austin–San Antonio)', '#1E3D59', 'DASHED', 'Texas Rail Concept', 'CONCEPT_DEMONSTRATION', 'concept:rt_triangle', 'CONCEPT_PLANNING'),
    ('rt_west', 'TX-WT', 'West Texas Overland (Fort Worth–El Paso)', '#2B5B84', 'DOTTED', 'Texas Rail Concept', 'CONCEPT_DEMONSTRATION', 'concept:rt_west', 'CONCEPT_PLANNING'),
    ('rt_plains', 'TX-HP', 'High Plains Corridor (Fort Worth–Amarillo)', '#4A6FA5', 'SOLID', 'Texas Rail Concept', 'CONCEPT_DEMONSTRATION', 'concept:rt_plains', 'CONCEPT_PLANNING'),
    ('rt_gulf', 'TX-GC', 'Gulf Breeze Line (San Antonio–Corpus Christi)', '#0E7C7B', 'SOLID', 'Texas Rail Concept', 'CONCEPT_DEMONSTRATION', 'concept:rt_gulf', 'CONCEPT_PLANNING')
ON CONFLICT (id) DO NOTHING;

INSERT INTO service_calendars (id, monday, tuesday, wednesday, thursday, friday, saturday, sunday, start_date, end_date)
VALUES
    ('cal_daily', TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, '2026-01-01', '2027-12-31')
ON CONFLICT (id) DO NOTHING;

INSERT INTO route_patterns (id, route_id, direction, headsign, station_sequence_json)
VALUES
    ('pat_i35_sb', 'rt_i35', 'SOUTHBOUND', 'San Antonio via Austin', '["st_dal","st_wac","st_tpl","st_aus","st_sat"]'::jsonb),
    ('pat_i35_nb', 'rt_i35', 'NORTHBOUND', 'Dallas Union Concourse', '["st_sat","st_aus","st_tpl","st_wac","st_dal"]'::jsonb),
    ('pat_west_wb', 'rt_west', 'WESTBOUND', 'El Paso (Mountain Time)', '["st_ftw","st_elp"]'::jsonb),
    ('pat_plains_nb', 'rt_plains', 'NORTHBOUND', 'Amarillo High Plains', '["st_ftw","st_ama"]'::jsonb),
    ('pat_gulf_sb', 'rt_gulf', 'SOUTHBOUND', 'Corpus Christi Bayfront', '["st_sat","st_crp"]'::jsonb),
    ('pat_tri_eb', 'rt_triangle', 'EASTBOUND', 'Houston Bayou Terminal', '["st_sat","st_aus","st_hou"]'::jsonb)
ON CONFLICT (id) DO NOTHING;

INSERT INTO trips (id, route_id, pattern_id, service_calendar_id, train_number, service_name, wheelchair_accessible, level_boarding_verified, amenities_json, operating_mode, source_id, provenance)
VALUES
    ('tr_dal_aus_0800', 'rt_i35', 'pat_i35_sb', 'cal_daily', 'TX-101', 'Morning Lone Star Express', TRUE, TRUE, '["Wi-Fi","Power Outlets","Cafe Car","Bike Spaces","Quiet Coach"]'::jsonb, 'CONCEPT_DEMONSTRATION', 'concept:tr_101', 'CONCEPT_PLANNING'),
    ('tr_dal_aus_1030', 'rt_i35', 'pat_i35_sb', 'cal_daily', 'TX-103', 'Midday Capitol Flyer', TRUE, TRUE, '["Wi-Fi","Power Outlets","Cafe Car"]'::jsonb, 'CONCEPT_DEMONSTRATION', 'concept:tr_103', 'CONCEPT_PLANNING'),
    ('tr_dal_aus_1300', 'rt_i35', 'pat_i35_sb', 'cal_daily', 'TX-105', 'Hill Country Afternoon', TRUE, TRUE, '["Wi-Fi","Power Outlets","Accessible Coach"]'::jsonb, 'CONCEPT_DEMONSTRATION', 'concept:tr_105', 'CONCEPT_PLANNING'),
    ('tr_ftw_elp_2115', 'rt_west', 'pat_west_wb', 'cal_daily', 'TX-401', 'Pecos Night Sleeper', TRUE, NULL, '["Sleeper Berths","Dining Car","Wi-Fi"]'::jsonb, 'CONCEPT_DEMONSTRATION', 'concept:tr_401', 'CONCEPT_PLANNING')
ON CONFLICT (id) DO NOTHING;

INSERT INTO stop_times (id, trip_id, station_id, stop_sequence, arrival_offset_seconds, departure_offset_seconds, day_offset)
VALUES
    ('st_101_1', 'tr_dal_aus_0800', 'st_dal', 1, 28800, 28800, 0),
    ('st_101_2', 'tr_dal_aus_0800', 'st_wac', 2, 32100, 32220, 0),
    ('st_101_3', 'tr_dal_aus_0800', 'st_tpl', 3, 33900, 34020, 0),
    ('st_101_4', 'tr_dal_aus_0800', 'st_aus', 4, 36600, 36840, 0),
    ('st_101_5', 'tr_dal_aus_0800', 'st_sat', 5, 40200, 40200, 0),
    ('st_103_1', 'tr_dal_aus_1030', 'st_dal', 1, 37800, 37800, 0),
    ('st_103_2', 'tr_dal_aus_1030', 'st_wac', 2, 41100, 41220, 0),
    ('st_103_3', 'tr_dal_aus_1030', 'st_aus', 3, 45600, 45900, 0),
    ('st_103_4', 'tr_dal_aus_1030', 'st_sat', 4, 49200, 49200, 0),
    ('st_105_1', 'tr_dal_aus_1300', 'st_dal', 1, 46800, 46800, 0),
    ('st_105_2', 'tr_dal_aus_1300', 'st_tpl', 2, 51300, 51480, 0),
    ('st_105_3', 'tr_dal_aus_1300', 'st_aus', 3, 54600, 54600, 0),
    ('st_401_1', 'tr_ftw_elp_2115', 'st_ftw', 1, 76500, 76500, 0),
    ('st_401_2', 'tr_ftw_elp_2115', 'st_elp', 2, 27900, 27900, 1)
ON CONFLICT (id) DO NOTHING;

INSERT INTO transfers (id, from_station_id, to_station_id, min_transfer_minutes, walking_distance_meters, accessible_path)
VALUES
    ('xf_aus', 'st_aus', 'st_aus', 12, 60, TRUE),
    ('xf_ftw', 'st_ftw', 'st_ftw', 15, 90, TRUE),
    ('xf_sat', 'st_sat', 'st_sat', 15, 75, TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO service_alerts (id, route_id, station_id, title, description, severity, starts_at, ends_at, operating_mode, source_id)
VALUES
    ('alt_concept_1', 'rt_i35', NULL, 'Concept Network Demonstration Notice',
     'All schedules, platform assignments, and fares shown in Concept Demonstration mode are illustrative planning models.',
     'INFO', '2026-01-01T00:00:00Z', '2027-12-31T23:59:59Z', 'CONCEPT_DEMONSTRATION', 'concept:alt_1'),
    ('alt_concept_2', 'rt_west', 'st_elp', 'Time Zone Crossing Reminder',
     'El Paso Union operates in Mountain Time (America/Denver). Check both CT and MT zone labels on overnight West Texas itineraries.',
     'ADVISORY', '2026-01-01T00:00:00Z', '2027-12-31T23:59:59Z', 'CONCEPT_DEMONSTRATION', 'concept:alt_2')
ON CONFLICT (id) DO NOTHING;

INSERT INTO trip_inventory (trip_id, service_date, fare_class, total_seats, available_seats, base_fare_numeric, tax_numeric, fee_numeric, currency)
VALUES
    ('tr_dal_aus_0800', '2026-05-14', 'Standard', 180, 42, 43.20, 3.80, 2.00, 'USD'),
    ('tr_dal_aus_1030', '2026-05-14', 'Standard', 180, 28, 52.40, 4.60, 2.00, 'USD'),
    ('tr_dal_aus_1300', '2026-05-14', 'Standard', 180, 65, 39.50, 3.50, 2.00, 'USD')
ON CONFLICT DO NOTHING;
