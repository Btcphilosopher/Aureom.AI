-- 001_init.sql: PostgreSQL schema for Texas Rail passenger platform

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS dataset_versions (
    id TEXT PRIMARY KEY,
    operating_mode TEXT NOT NULL CHECK (operating_mode IN ('CONCEPT_DEMONSTRATION', 'CONNECTED_SERVICES')),
    source_name TEXT NOT NULL,
    published_at TIMESTAMPTZ NOT NULL,
    checksum TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stations (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    time_zone TEXT NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    schematic_x REAL NOT NULL,
    schematic_y REAL NOT NULL,
    is_major_city BOOLEAN NOT NULL DEFAULT FALSE,
    address TEXT NOT NULL,
    entrances_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    accessibility_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    parking_bikes_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    local_transit_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    opening_hours TEXT,
    source_id TEXT NOT NULL,
    provenance TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS platforms (
    id TEXT PRIMARY KEY,
    station_id TEXT NOT NULL REFERENCES stations(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    level_boarding BOOLEAN,
    tactile_paving BOOLEAN,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS routes (
    id TEXT PRIMARY KEY,
    short_code TEXT NOT NULL,
    name TEXT NOT NULL,
    corridor_color_hex TEXT NOT NULL,
    corridor_pattern TEXT NOT NULL,
    operator_name TEXT NOT NULL,
    operating_mode TEXT NOT NULL CHECK (operating_mode IN ('CONCEPT_DEMONSTRATION', 'CONNECTED_SERVICES')),
    source_id TEXT NOT NULL,
    provenance TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS route_patterns (
    id TEXT PRIMARY KEY,
    route_id TEXT NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    direction TEXT NOT NULL,
    headsign TEXT NOT NULL,
    station_sequence_json JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS service_calendars (
    id TEXT PRIMARY KEY,
    monday BOOLEAN NOT NULL,
    tuesday BOOLEAN NOT NULL,
    wednesday BOOLEAN NOT NULL,
    thursday BOOLEAN NOT NULL,
    friday BOOLEAN NOT NULL,
    saturday BOOLEAN NOT NULL,
    sunday BOOLEAN NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS calendar_exceptions (
    id TEXT PRIMARY KEY,
    service_calendar_id TEXT NOT NULL REFERENCES service_calendars(id) ON DELETE CASCADE,
    exception_date DATE NOT NULL,
    exception_type TEXT NOT NULL CHECK (exception_type IN ('ADDED', 'REMOVED'))
);

CREATE TABLE IF NOT EXISTS trips (
    id TEXT PRIMARY KEY,
    route_id TEXT NOT NULL REFERENCES routes(id),
    pattern_id TEXT NOT NULL REFERENCES route_patterns(id),
    service_calendar_id TEXT NOT NULL REFERENCES service_calendars(id),
    train_number TEXT NOT NULL,
    service_name TEXT NOT NULL,
    wheelchair_accessible BOOLEAN,
    level_boarding_verified BOOLEAN,
    amenities_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    operating_mode TEXT NOT NULL CHECK (operating_mode IN ('CONCEPT_DEMONSTRATION', 'CONNECTED_SERVICES')),
    source_id TEXT NOT NULL,
    provenance TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stop_times (
    id TEXT PRIMARY KEY,
    trip_id TEXT NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    station_id TEXT NOT NULL REFERENCES stations(id),
    platform_id TEXT REFERENCES platforms(id),
    stop_sequence INTEGER NOT NULL,
    arrival_offset_seconds INTEGER,
    departure_offset_seconds INTEGER,
    day_offset INTEGER NOT NULL DEFAULT 0,
    pickup_allowed BOOLEAN NOT NULL DEFAULT TRUE,
    dropoff_allowed BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS transfers (
    id TEXT PRIMARY KEY,
    from_station_id TEXT NOT NULL REFERENCES stations(id),
    to_station_id TEXT NOT NULL REFERENCES stations(id),
    min_transfer_minutes INTEGER NOT NULL CHECK (min_transfer_minutes >= 0),
    walking_distance_meters INTEGER NOT NULL DEFAULT 0,
    accessible_path BOOLEAN
);

CREATE TABLE IF NOT EXISTS service_alerts (
    id TEXT PRIMARY KEY,
    route_id TEXT REFERENCES routes(id),
    station_id TEXT REFERENCES stations(id),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('INFO', 'ADVISORY', 'DISRUPTION')),
    starts_at TIMESTAMPTZ NOT NULL,
    ends_at TIMESTAMPTZ,
    operating_mode TEXT NOT NULL CHECK (operating_mode IN ('CONCEPT_DEMONSTRATION', 'CONNECTED_SERVICES')),
    source_id TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS trip_inventory (
    trip_id TEXT NOT NULL REFERENCES trips(id),
    service_date DATE NOT NULL,
    fare_class TEXT NOT NULL,
    total_seats INTEGER NOT NULL CHECK (total_seats >= 0),
    available_seats INTEGER NOT NULL CHECK (available_seats >= 0),
    base_fare_numeric NUMERIC(10, 2) NOT NULL CHECK (base_fare_numeric >= 0),
    tax_numeric NUMERIC(10, 2) NOT NULL CHECK (tax_numeric >= 0),
    fee_numeric NUMERIC(10, 2) NOT NULL CHECK (fee_numeric >= 0),
    currency TEXT NOT NULL DEFAULT 'USD',
    PRIMARY KEY (trip_id, service_date, fare_class)
);

CREATE TABLE IF NOT EXISTS inventory_reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    trip_ids_json JSONB NOT NULL,
    service_date DATE NOT NULL,
    fare_class TEXT NOT NULL,
    passenger_count INTEGER NOT NULL CHECK (passenger_count BETWEEN 1 AND 8),
    requested_seats_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    subtotal_numeric NUMERIC(10, 2) NOT NULL,
    tax_numeric NUMERIC(10, 2) NOT NULL,
    fee_numeric NUMERIC(10, 2) NOT NULL,
    total_numeric NUMERIC(10, 2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    fare_conditions_snapshot JSONB NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('HELD', 'CONFIRMED', 'EXPIRED', 'RELEASED')),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_intents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reservation_id UUID NOT NULL REFERENCES inventory_reservations(id),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    provider_name TEXT NOT NULL,
    amount_numeric NUMERIC(10, 2) NOT NULL CHECK (amount_numeric > 0),
    currency TEXT NOT NULL DEFAULT 'USD',
    status TEXT NOT NULL CHECK (status IN ('REQUIRES_CONFIRMATION', 'SUCCEEDED', 'FAILED', 'CANCELLED', 'REFUNDED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_webhook_events (
    event_id TEXT PRIMARY KEY,
    payment_intent_id UUID NOT NULL REFERENCES payment_intents(id),
    event_type TEXT NOT NULL,
    processed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    reservation_id UUID NOT NULL UNIQUE REFERENCES inventory_reservations(id),
    reference_code TEXT NOT NULL UNIQUE,
    operating_mode TEXT NOT NULL CHECK (operating_mode IN ('CONCEPT_DEMONSTRATION', 'CONNECTED_SERVICES')),
    status TEXT NOT NULL CHECK (status IN ('CONFIRMED', 'CANCELLED', 'REFUNDED')),
    total_numeric NUMERIC(10, 2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    fare_conditions_snapshot JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tickets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL UNIQUE REFERENCES bookings(id) ON DELETE CASCADE,
    qr_payload TEXT NOT NULL,
    is_demonstration BOOLEAN NOT NULL DEFAULT TRUE,
    demo_disclaimer TEXT NOT NULL DEFAULT 'DEMO — NOT VALID FOR TRAVEL',
    issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_stop_times_trip_seq ON stop_times(trip_id, stop_sequence);
CREATE INDEX IF NOT EXISTS idx_bookings_user ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_reservations_expires ON inventory_reservations(status, expires_at);
