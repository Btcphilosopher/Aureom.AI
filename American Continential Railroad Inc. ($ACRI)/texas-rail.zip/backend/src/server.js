import crypto from "node:crypto";
import express from "express";
import rateLimit from "express-rate-limit";
import pg from "pg";

const { Pool } = pg;

const PORT = Number(process.env.PORT || 8080);
const OPERATING_MODE = process.env.OPERATING_MODE || "CONCEPT_DEMONSTRATION";
const DATABASE_URL = process.env.DATABASE_URL;
const WEBHOOK_SECRET = process.env.PAYMENT_WEBHOOK_SECRET || "";

if (!DATABASE_URL) {
  console.error("DATABASE_URL is required");
  process.exit(1);
}

const pool = new Pool({ connectionString: DATABASE_URL });
const app = express();

app.use(express.json({ limit: "256kb" }));
app.use(
  rateLimit({
    windowMs: 60 * 1000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false
  })
);

function redactToken(value) {
  if (!value) return "<none>";
  return `${value.slice(0, 4)}***`;
}

function hashToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

async function requireAuth(req, res, next) {
  const header = req.header("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  if (!token) {
    return res.status(401).json({ error: "Authentication required" });
  }
  try {
    const result = await pool.query(
      "SELECT user_id FROM sessions WHERE token_hash = $1 AND expires_at > NOW()",
      [hashToken(token)]
    );
    if (result.rowCount === 0) {
      return res.status(401).json({ error: "Invalid or expired session" });
    }
    req.userId = result.rows[0].user_id;
    next();
  } catch (err) {
    console.error("Auth lookup error", { path: req.path, token: redactToken(token) });
    res.status(500).json({ error: "Authentication check failed" });
  }
}

app.get("/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({
      status: "ok",
      mode: OPERATING_MODE,
      timestampUtc: new Date().toISOString()
    });
  } catch {
    res.status(503).json({ status: "degraded", mode: OPERATING_MODE });
  }
});

app.get("/v1/network/snapshot", async (_req, res) => {
  try {
    const [versions, stations, routes, alerts] = await Promise.all([
      pool.query("SELECT * FROM dataset_versions ORDER BY published_at DESC LIMIT 1"),
      pool.query("SELECT * FROM stations ORDER BY name ASC"),
      pool.query("SELECT * FROM routes ORDER BY id ASC"),
      pool.query("SELECT * FROM service_alerts ORDER BY starts_at DESC")
    ]);
    res.json({
      datasetVersion: versions.rows[0] || null,
      operatingMode: OPERATING_MODE,
      stations: stations.rows,
      routes: routes.rows,
      alerts: alerts.rows
    });
  } catch (err) {
    console.error("Snapshot query error", err.message);
    res.status(500).json({ error: "Failed to load network snapshot" });
  }
});

app.get("/v1/stations/:stationId/departures", async (req, res) => {
  const stationId = String(req.params.stationId || "").trim();
  if (!stationId) return res.status(400).json({ error: "stationId is required" });
  try {
    const result = await pool.query(
      `SELECT st.trip_id, t.train_number, t.service_name, t.operating_mode,
              st.departure_offset_seconds, st.day_offset, r.short_code, r.name AS route_name
       FROM stop_times st
       JOIN trips t ON t.id = st.trip_id
       JOIN routes r ON r.id = t.route_id
       WHERE st.station_id = $1 AND st.pickup_allowed = TRUE
       ORDER BY st.departure_offset_seconds ASC`,
      [stationId]
    );
    res.json({
      stationId,
      operatingMode: OPERATING_MODE,
      refreshedAtUtc: new Date().toISOString(),
      isLiveTelemetryAvailable: false,
      departures: result.rows
    });
  } catch (err) {
    console.error("Departures query error", err.message);
    res.status(500).json({ error: "Failed to load departures" });
  }
});

app.get("/v1/alerts", async (_req, res) => {
  try {
    const result = await pool.query("SELECT * FROM service_alerts ORDER BY starts_at DESC");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: "Failed to load alerts" });
  }
});

app.post("/v1/bookings/reservations", requireAuth, async (req, res) => {
  const idempotencyKey = req.header("Idempotency-Key");
  if (!idempotencyKey) return res.status(400).json({ error: "Idempotency-Key header required" });

  const { tripIds, serviceDate, passengerCount, fareClass = "Standard", requestedSeats = [] } = req.body || {};
  if (!Array.isArray(tripIds) || tripIds.length === 0 || !serviceDate || !Number.isInteger(passengerCount) || passengerCount < 1 || passengerCount > 8) {
    return res.status(400).json({ error: "Invalid reservation request" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const existing = await client.query(
      "SELECT * FROM inventory_reservations WHERE idempotency_key = $1",
      [idempotencyKey]
    );
    if (existing.rowCount > 0) {
      await client.query("COMMIT");
      return res.status(201).json(existing.rows[0]);
    }

    let subtotal = 0;
    let tax = 0;
    let fee = 0;
    for (const tripId of tripIds) {
      const inv = await client.query(
        "SELECT * FROM trip_inventory WHERE trip_id = $1 AND service_date = $2 AND fare_class = $3 FOR UPDATE",
        [tripId, serviceDate, fareClass]
      );
      if (inv.rowCount === 0 || inv.rows[0].available_seats < passengerCount) {
        await client.query("ROLLBACK");
        return res.status(409).json({ error: "Insufficient seat inventory" });
      }
      await client.query(
        "UPDATE trip_inventory SET available_seats = available_seats - $1 WHERE trip_id = $2 AND service_date = $3 AND fare_class = $4",
        [passengerCount, tripId, serviceDate, fareClass]
      );
      subtotal += Number(inv.rows[0].base_fare_numeric) * passengerCount;
      tax += Number(inv.rows[0].tax_numeric) * passengerCount;
      fee += Number(inv.rows[0].fee_numeric) * passengerCount;
    }

    const total = Number((subtotal + tax + fee).toFixed(2));
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    const inserted = await client.query(
      `INSERT INTO inventory_reservations (
         user_id, idempotency_key, trip_ids_json, service_date, fare_class, passenger_count,
         requested_seats_json, subtotal_numeric, tax_numeric, fee_numeric, total_numeric,
         currency, fare_conditions_snapshot, status, expires_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'USD',$12,'HELD',$13)
       RETURNING *`,
      [
        req.userId,
        idempotencyKey,
        JSON.stringify(tripIds),
        serviceDate,
        fareClass,
        passengerCount,
        JSON.stringify(requestedSeats),
        subtotal.toFixed(2),
        tax.toFixed(2),
        fee.toFixed(2),
        total.toFixed(2),
        JSON.stringify({ refundableUntilHoursBefore: 24, exchangeAllowed: true, capturedAtUtc: new Date().toISOString() }),
        expiresAt
      ]
    );
    await client.query("COMMIT");
    res.status(201).json(inserted.rows[0]);
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Reservation error", err.message);
    res.status(500).json({ error: "Failed to create reservation" });
  } finally {
    client.release();
  }
});

app.post("/v1/payments/webhooks", async (req, res) => {
  const sig = req.header("X-Webhook-Signature") || "";
  if (WEBHOOK_SECRET) {
    const expected = crypto.createHmac("sha256", WEBHOOK_SECRET).update(JSON.stringify(req.body || {})).digest("hex");
    if (sig !== expected) {
      return res.status(401).json({ error: "Invalid webhook signature" });
    }
  }
  const { eventId, paymentIntentId, eventType } = req.body || {};
  if (!eventId || !paymentIntentId || !eventType) {
    return res.status(400).json({ error: "Malformed webhook payload" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const dup = await client.query("SELECT 1 FROM payment_webhook_events WHERE event_id = $1", [eventId]);
    if (dup.rowCount > 0) {
      await client.query("COMMIT");
      return res.json({ status: "duplicate_ignored", eventId });
    }
    const statusMap = {
      "payment.succeeded": "SUCCEEDED",
      "payment.failed": "FAILED",
      "payment.cancelled": "CANCELLED",
      "payment.refunded": "REFUNDED"
    };
    const nextStatus = statusMap[eventType];
    if (!nextStatus) {
      await client.query("ROLLBACK");
      return res.status(400).json({ error: "Unsupported eventType" });
    }
    await client.query(
      "INSERT INTO payment_webhook_events (event_id, payment_intent_id, event_type) VALUES ($1, $2, $3)",
      [eventId, paymentIntentId, eventType]
    );
    await client.query(
      "UPDATE payment_intents SET status = $1, updated_at = NOW() WHERE id = $2",
      [nextStatus, paymentIntentId]
    );
    await client.query("COMMIT");
    res.json({ status: "processed", eventId, paymentStatus: nextStatus });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Webhook processing error", err.message);
    res.status(500).json({ error: "Webhook failed" });
  } finally {
    client.release();
  }
});

app.post("/v1/bookings/:reservationId/confirm", requireAuth, async (req, res) => {
  const reservationId = req.params.reservationId;
  const { paymentIntentId } = req.body || {};
  if (!paymentIntentId) return res.status(400).json({ error: "paymentIntentId required" });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const resRow = await client.query(
      "SELECT * FROM inventory_reservations WHERE id = $1 AND user_id = $2 FOR UPDATE",
      [reservationId, req.userId]
    );
    if (resRow.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Reservation not found" });
    }
    const reservation = resRow.rows[0];
    if (new Date(reservation.expires_at).getTime() < Date.now()) {
      await client.query("UPDATE inventory_reservations SET status = 'EXPIRED' WHERE id = $1", [reservationId]);
      await client.query("COMMIT");
      return res.status(410).json({ error: "Reservation expired" });
    }
    const payRow = await client.query(
      "SELECT * FROM payment_intents WHERE id = $1 AND reservation_id = $2",
      [paymentIntentId, reservationId]
    );
    if (payRow.rowCount === 0 || payRow.rows[0].status !== "SUCCEEDED") {
      await client.query("ROLLBACK");
      return res.status(402).json({ error: "Server has not confirmed payment settlement" });
    }

    const referenceCode = `TXR-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
    const booking = await client.query(
      `INSERT INTO bookings (user_id, reservation_id, reference_code, operating_mode, status, total_numeric, currency, fare_conditions_snapshot)
       VALUES ($1,$2,$3,$4,'CONFIRMED',$5,$6,$7)
       ON CONFLICT (reservation_id) DO UPDATE SET status = bookings.status
       RETURNING *`,
      [req.userId, reservationId, referenceCode, OPERATING_MODE, reservation.total_numeric, reservation.currency, reservation.fare_conditions_snapshot]
    );
    await client.query("UPDATE inventory_reservations SET status = 'CONFIRMED' WHERE id = $1", [reservationId]);
    const isDemo = OPERATING_MODE === "CONCEPT_DEMONSTRATION";
    const qrPayload = isDemo ? `DEMO-${referenceCode}-NOT-VALID-FOR-TRAVEL` : `TXR-${booking.rows[0].id}`;
    const ticket = await client.query(
      `INSERT INTO tickets (booking_id, qr_payload, is_demonstration)
       VALUES ($1,$2,$3)
       ON CONFLICT (booking_id) DO UPDATE SET qr_payload = tickets.qr_payload
       RETURNING *`,
      [booking.rows[0].id, qrPayload, isDemo]
    );
    await client.query("COMMIT");
    res.json({ booking: booking.rows[0], ticket: ticket.rows[0] });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Confirm booking error", err.message);
    res.status(500).json({ error: "Confirmation failed" });
  } finally {
    client.release();
  }
});

app.get("/v1/tickets", requireAuth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT b.*, t.id AS ticket_id, t.qr_payload, t.is_demonstration, t.demo_disclaimer
       FROM bookings b
       JOIN tickets t ON t.booking_id = b.id
       WHERE b.user_id = $1
       ORDER BY b.created_at DESC`,
      [req.userId]
    );
    res.json(result.rows);
  } catch {
    res.status(500).json({ error: "Failed to load tickets" });
  }
});

app.get("/v1/account/export", requireAuth, async (req, res) => {
  try {
    const [user, bookings] = await Promise.all([
      pool.query("SELECT id, email, display_name, created_at FROM users WHERE id = $1", [req.userId]),
      pool.query("SELECT * FROM bookings WHERE user_id = $1", [req.userId])
    ]);
    res.json({ user: user.rows[0], bookings: bookings.rows });
  } catch {
    res.status(500).json({ error: "Account export failed" });
  }
});

app.delete("/v1/account", requireAuth, async (req, res) => {
  try {
    await pool.query("DELETE FROM users WHERE id = $1", [req.userId]);
    res.status(204).send();
  } catch {
    res.status(500).json({ error: "Account deletion failed" });
  }
});

app.listen(PORT, () => {
  console.log(`Texas Rail API listening on port ${PORT} (${OPERATING_MODE})`);
});
