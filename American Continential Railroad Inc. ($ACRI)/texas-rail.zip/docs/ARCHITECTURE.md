# Texas Rail — Architecture, Contracts, and Build Guide

## 1. Architecture & Assumptions
Texas Rail uses an offline-first, interface-driven MVVM + Clean Repository architecture with strict separation between **CONCEPT_DEMONSTRATION** and **CONNECTED_SERVICES** operating modes:
- **UI & Adaptive Layout**: Jetpack Compose + Material 3 custom design tokens (`LocalTexasRailTokens`), supporting phones (`TexasRailBottomBar`) and tablets (`NavigationRail` via `WindowWidthSizeClass`), Light/Dark/System themes, TalkBack semantics, and dynamic font scaling (`sp`).
- **Time-Zone & DST Engine (`core/time/TexasRailTime.kt`)**: Resolves every stop in its station's IANA time zone (`America/Chicago` for Central Texas, `America/Denver` for El Paso) and computes journey durations exclusively via UTC `Instant` subtraction (`Duration.between(departureInstant, arrivalInstant)`).
- **Timetable-Aware Routing (`core/routing/RaptorRouter.kt`)**: Multi-round RAPTOR algorithm enforcing `ServiceCalendar`, `CalendarException` (`ADDED`/`REMOVED`), `Transfer.minTransferMinutes`, overnight `dayOffset`, and honest accessibility verification (never claiming accessible boarding when `levelBoarding` or `accessiblePath` is `null`).
- **Fares, Inventory & Sandbox Payments (`data/booking/`)**: `Money` integer-cent / `BigDecimal` arithmetic, atomic Room transactions (`availableSeats >= passengerCount`), idempotent reservations with 10-minute holds, tokenised sandbox payment intents (zero raw PAN/CVV collection), duplicate webhook deduplication (`ProcessedWebhookEntity`), and `DEMO — NOT VALID FOR TRAVEL` tickets.
- **Replaceable Interfaces (`core/model/ProviderInterfaces.kt`)**: `NetworkProvider`, `TimetableProvider`, `RealtimeProvider`, `FareProvider`, `BookingProvider`, `PaymentProvider`, `TicketIssuer`, `AlertProvider`.

## 2. Repository Structure
- `app/src/main/java/com/example/`:
  - `core/model/`: Immutable domain models & 8 replaceable provider interfaces
  - `core/time/`: `TexasRailTime` (Central/Mountain zone resolution, DST-safe duration, currency/distance formatting)
  - `core/routing/`: `RaptorRouter`
  - `core/designsystem/`: `Tokens`, `Type` (Plus Jakarta Sans, Inter, JetBrains Mono), `Theme`, `Components`
  - `core/database/`: Room entities, DAOs, `TexasRailDatabase`, `EncryptedTokenStore`, `PreferencesRepository`
  - `core/network/`: `TexasRailApi`, `NetworkSyncWorker` (`WorkManager`)
  - `data/timetables/`, `data/realtime/`, `data/booking/`: Seed data, mappers, and provider implementations
  - `feature/{home,map,search,journey,booking,tickets,departures,account}/`: Screen UIs and Hilt ViewModels
  - `di/RepositoryModule.kt`: Hilt bindings
- `backend/`:
  - `openapi.yaml`: OpenAPI 3.1.0 contract
  - `migrations/001_init.sql` & `002_seed.sql`: PostgreSQL schema & concept seed
  - `src/server.js`: Express + `pg` service with transactional `FOR UPDATE` inventory locks & idempotent webhooks
  - `Dockerfile` & `docker-compose.yml`: Local PostgreSQL + API stack

## 3. Database Schema
- **Android Room (`texas_rail_offline.db`)**: 19 entities covering cached timetable tables (`stations`, `routes`, `route_patterns`, `service_calendars`, `calendar_exceptions`, `trips`, `stop_times`, `transfers`, `service_alerts`, `dataset_versions`), real local inventory & transactional booking tables (`trip_inventory`, `inventory_reservations`, `payment_records`, `processed_webhooks`, `bookings`), and user library tables (`saved_journeys`, `saved_passengers`, `recent_searches`, `saved_stations`).
- **PostgreSQL (`backend/migrations/001_init.sql`)**: Mirrors the domain tables with `NUMERIC(10, 2)` money columns, `TIMESTAMPTZ` UTC timestamps, `CHECK (available_seats >= 0)`, `UNIQUE (idempotency_key)`, and `payment_webhook_events` deduplication.

## 4. API Contract
Defined in `backend/openapi.yaml`:
- `GET /health`
- `GET /v1/network/snapshot`
- `GET /v1/stations/{stationId}/departures`
- `GET /v1/alerts`
- `POST /v1/bookings/reservations` (`Idempotency-Key` required)
- `POST /v1/payments/intents` (`Idempotency-Key` required)
- `POST /v1/payments/webhooks` (HMAC signature + `eventId` deduplication)
- `POST /v1/bookings/{reservationId}/confirm` (verifies non-expired hold & `SUCCEEDED` payment)
- `POST /v1/bookings/{bookingId}/refund`
- `GET /v1/tickets`, `GET /v1/account/export`, `DELETE /v1/account`

## 5. Design Tokens & Component Inventory
- **Palette**: Deep Navy `#0E223A`, Limestone Ivory `#F6F1E9`, Burnt Orange `#D1510A` (Dark `#EC6B26`), Sandstone `#E8DAC8`, Slate Navy `#3D536D`.
- **Typography**: `Plus Jakarta Sans` (display/headers/prices), `Inter` (body/labels), `JetBrains Mono` (booking refs/zones).
- **Components**: `LoneStarEmblem`, `TexasRailTopBar`, `SectionHeadingWithAccent`, `OperatingModeBanner`, `QrCodeMatrixView`, `TexasVectorMapCanvas`, `TexasRailBottomBar`.

## 6. Feature Status Matrix
| Feature | Status | Notes |
| --- | --- | --- |
| Offline Texas network map (Schematic & Geographic, pan/zoom, accessible list) | **Implemented** | Backed by Room cache & `DemoSeedDataset` |
| RAPTOR journey search (Direct + 1-transfer, Central/Mountain TZ, DST, calendars) | **Implemented** | Verified by unit & Robolectric tests |
| Dallas–Austin illustrative schedules & fares (`08:00 $49`, `10:30 $59`, `13:00 $45`) | **Simulated / Concept Demo** | Clearly labelled illustrative; stored in seed dataset, not hardcoded in UI |
| Local inventory holds, concurrent seat protection, idempotency, sandbox checkout | **Simulated / Sandbox** | Real Room transactions + tokenised sandbox adapter; `DEMO — NOT VALID FOR TRAVEL` tickets |
| PostgreSQL service + OpenAPI + Docker Compose stack | **Implemented (Local Dev)** | Run via `cd backend && cp .env.example .env && docker compose up --build` |
| Live operator departures & real-money ticketing | **Credential-Dependent / Gated** | Disabled unless Connected Services backend & authorized operator ticketing credentials are configured |

## 7. Build & Test Instructions
- **Android Debug APK**: `gradle :app:assembleDebug`
- **Android Unit & Robolectric Tests**: `gradle :app:testDebugUnitTest`
- **Local PostgreSQL Backend**: `cd backend && cp .env.example .env && docker compose up --build` (Android emulator connects via `http://10.0.2.2:8080/`).
