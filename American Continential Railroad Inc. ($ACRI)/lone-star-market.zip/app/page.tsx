'use client';

import React, { useState, useEffect, useMemo } from 'react';
import {
  CategoryId,
  DEMO_STORES,
  DemoStore,
  Product,
  PRODUCTS,
} from '@/lib/store-data';
import { HeaderNavigation } from '@/components/HeaderNavigation';
import { HeroAndFeatured } from '@/components/HeroAndFeatured';
import { ProductCatalogSection } from '@/components/ProductCatalogSection';
import { TexasMadeAndStoreLocator } from '@/components/TexasMadeAndStoreLocator';
import {
  CartAndCheckoutDrawer,
  CartItem,
  ProductQuickViewModal,
} from '@/components/CartAndCheckoutDrawer';
import {
  CorporateInfoModal,
  InfoModalTopic,
  SignInModal,
  SiteFooter,
} from '@/components/SiteFooterAndModals';
import { BrandIdentityModal } from '@/components/BrandLogo';
import { CheckCircle2 } from 'lucide-react';

export default function LoneStarMarketApp() {
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'name-asc'>(
    'featured'
  );

  // Persistent state
  const [cartQuantities, setCartQuantities] = useState<Record<string, number>>({
    'prod-ribeye': 1,
    'prod-honey': 1,
  });
  const [favorites, setFavorites] = useState<string[]>(['prod-ribeye', 'prod-sourdough']);
  const [selectedStore, setSelectedStore] = useState<DemoStore>(DEMO_STORES[0]);
  const [signedInUser, setSignedInUser] = useState<{ name: string; email: string } | null>(null);
  const [isHydrated, setIsHydrated] = useState(false);

  // Modals & Drawers
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [brandIdentityOpen, setBrandIdentityOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [infoModalTopic, setInfoModalTopic] = useState<InfoModalTopic>(null);
  const [signInModalOpen, setSignInModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load persisted state from localStorage on client mount
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem('lsm_cart_v1');
      if (savedCart) {
        setCartQuantities(JSON.parse(savedCart));
      }
      const savedFavs = localStorage.getItem('lsm_favorites_v1');
      if (savedFavs) {
        setFavorites(JSON.parse(savedFavs));
      }
      const savedStoreId = localStorage.getItem('lsm_store_v1');
      if (savedStoreId) {
        const found = DEMO_STORES.find((s) => s.id === savedStoreId);
        if (found) setSelectedStore(found);
      }
      const savedUser = localStorage.getItem('lsm_user_v1');
      if (savedUser) {
        setSignedInUser(JSON.parse(savedUser));
      }
    } catch {
      // Ignore storage access errors in restricted environments
    }
    setIsHydrated(true);
  }, []);

  // Persist cart changes
  useEffect(() => {
    if (!isHydrated) return;
    try {
      localStorage.setItem('lsm_cart_v1', JSON.stringify(cartQuantities));
    } catch {
      // Ignore
    }
  }, [cartQuantities, isHydrated]);

  // Persist favorites
  useEffect(() => {
    if (!isHydrated) return;
    try {
      localStorage.setItem('lsm_favorites_v1', JSON.stringify(favorites));
    } catch {
      // Ignore
    }
  }, [favorites, isHydrated]);

  // Persist store selection
  useEffect(() => {
    if (!isHydrated) return;
    try {
      localStorage.setItem('lsm_store_v1', selectedStore.id);
    } catch {
      // Ignore
    }
  }, [selectedStore, isHydrated]);

  // Persist user
  useEffect(() => {
    if (!isHydrated) return;
    try {
      if (signedInUser) {
        localStorage.setItem('lsm_user_v1', JSON.stringify(signedInUser));
      } else {
        localStorage.removeItem('lsm_user_v1');
      }
    } catch {
      // Ignore
    }
  }, [signedInUser, isHydrated]);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const t = setTimeout(() => setToastMessage(null), 2800);
    return () => clearTimeout(t);
  }, [toastMessage]);

  const handleUpdateCart = (product: Product, delta: number) => {
    setCartQuantities((prev) => {
      const current = prev[product.id] || 0;
      const next = Math.max(0, current + delta);
      const updated = { ...prev };
      if (next === 0) {
        delete updated[product.id];
      } else {
        updated[product.id] = next;
      }
      return updated;
    });
    if (delta > 0) {
      triggerToast(`Added ${product.name} to your Lone Star basket`);
    }
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartQuantities((prev) => {
      const updated = { ...prev };
      delete updated[productId];
      return updated;
    });
  };

  const handleClearCart = () => {
    setCartQuantities({});
  };

  const handleToggleFavorite = (productId: string) => {
    setFavorites((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const handleSelectCategory = (cat: CategoryId) => {
    setSelectedCategory(cat);
    const catalogEl = document.getElementById('shopping-catalog');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectStore = (store: DemoStore) => {
    setSelectedStore(store);
    triggerToast(`Active store set to ${store.name}`);
  };

  // Search autocomplete matches
  const searchMatches = useMemo(() => {
    if (!searchQuery.trim()) return PRODUCTS;
    const q = searchQuery.toLowerCase().trim();
    return PRODUCTS.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.origin.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  // Filtered and sorted products for the main catalog
  const filteredProducts = useMemo(() => {
    const base = searchMatches.filter((product) => {
      if (selectedCategory === 'all') return true;
      if (selectedCategory === 'weekly-deals') return Boolean(product.isWeeklyDeal);
      if (selectedCategory === 'texas-made') return Boolean(product.isTexasMade);
      return (
        product.category === selectedCategory ||
        Boolean(product.secondaryCategories?.includes(selectedCategory))
      );
    });

    const sorted = [...base];
    if (sortBy === 'price-asc') {
      sorted.sort((a, b) => (a.promoPrice ?? a.price) - (b.promoPrice ?? b.price));
    } else if (sortBy === 'price-desc') {
      sorted.sort((a, b) => (b.promoPrice ?? b.price) - (a.promoPrice ?? a.price));
    } else if (sortBy === 'name-asc') {
      sorted.sort((a, b) => a.name.localeCompare(b.name));
    }
    return sorted;
  }, [searchMatches, selectedCategory, sortBy]);

  // Derive cart items array & totals
  const cartItems: CartItem[] = useMemo(() => {
    return Object.entries(cartQuantities)
      .map(([id, quantity]) => {
        const product = PRODUCTS.find((p) => p.id === id);
        if (!product || quantity <= 0) return null;
        return { product, quantity };
      })
      .filter((item): item is CartItem => item !== null);
  }, [cartQuantities]);

  const cartCount = useMemo(
    () => cartItems.reduce((sum, item) => sum + item.quantity, 0),
    [cartItems]
  );

  const cartSubtotal = useMemo(
    () =>
      cartItems.reduce(
        (sum, item) => sum + (item.product.promoPrice ?? item.product.price) * item.quantity,
        0
      ),
    [cartItems]
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F3EB] text-[#242A30]">
      {/* Top Announcement Bar, Corporate Header & Department Navigation */}
      <HeaderNavigation
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => handleSelectCategory(cat)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearchSubmit={() => {
          const el = document.getElementById('shopping-catalog');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        matchingProducts={searchMatches}
        onSelectProduct={(prod) => setQuickViewProduct(prod)}
        onAddToCart={(prod, qty = 1) => handleUpdateCart(prod, qty)}
        cartCount={cartCount}
        cartSubtotal={cartSubtotal}
        onOpenCart={() => setCartDrawerOpen(true)}
        selectedStore={selectedStore}
        onOpenStoreLocator={() => {
          const el = document.getElementById('store-locator');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenBrandIdentity={() => setBrandIdentityOpen(true)}
        signedInUser={signedInUser}
        onOpenSignIn={() => setSignInModalOpen(true)}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero, 4 Brand Benefits Strip, 3 Featured Cards, and 6-Card Category Grid */}
        <HeroAndFeatured
          onSelectCategory={handleSelectCategory}
          onShopNow={() => {
            const el = document.getElementById('shopping-catalog');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          onFindStore={() => {
            const el = document.getElementById('store-locator');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          activeCategory={selectedCategory}
        />

        {/* Weekly Deals ("THIS WEEK AT LONE STAR") & Interactive Product Catalog */}
        <ProductCatalogSection
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          searchQuery={searchQuery}
          onClearSearch={() => setSearchQuery('')}
          sortBy={sortBy}
          onSortChange={setSortBy}
          filteredProducts={filteredProducts}
          cartQuantities={cartQuantities}
          favorites={favorites}
          onAddToCart={handleUpdateCart}
          onToggleFavorite={handleToggleFavorite}
          onQuickView={(prod) => setQuickViewProduct(prod)}
        />

        {/* Rooted in Texas Panoramic Feature & Interactive Texas Store Locator */}
        <TexasMadeAndStoreLocator
          selectedStore={selectedStore}
          onSelectStore={handleSelectStore}
          onSelectCategory={setSelectedCategory}
        />
      </main>

      {/* Corporate Footer */}
      <SiteFooter
        onSelectCategory={setSelectedCategory}
        onOpenInfoModal={(topic) => setInfoModalTopic(topic)}
        onOpenBrandIdentity={() => setBrandIdentityOpen(true)}
      />

      {/* Interactive Modals & Drawers */}
      <CartAndCheckoutDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCart}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        selectedStore={selectedStore}
        onSelectStore={handleSelectStore}
      />

      <ProductQuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        cartQuantity={quickViewProduct ? cartQuantities[quickViewProduct.id] || 0 : 0}
        onAddToCart={handleUpdateCart}
      />

      <BrandIdentityModal
        isOpen={brandIdentityOpen}
        onClose={() => setBrandIdentityOpen(false)}
      />

      <CorporateInfoModal
        topic={infoModalTopic}
        onClose={() => setInfoModalTopic(null)}
      />

      <SignInModal
        isOpen={signInModalOpen}
        onClose={() => setSignInModalOpen(false)}
        signedInUser={signedInUser}
        onSignIn={setSignedInUser}
      />

      {/* Subtle Action Toast */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 bg-[#102A43] text-white px-4 py-3 rounded-xl shadow-xl border border-[#D8A64A]/40 flex items-center gap-2.5 text-xs sm:text-sm font-medium"
        >
          <CheckCircle2 className="w-4 h-4 text-[#D8A64A] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
