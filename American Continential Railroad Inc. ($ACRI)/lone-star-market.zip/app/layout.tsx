import type {Metadata} from 'next';
import {Playfair_Display, Plus_Jakarta_Sans, JetBrains_Mono} from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['600', '700', '800'],
  style: ['normal', 'italic'],
  variable: '--font-display',
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-sans',
});

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
});

export const metadata: Metadata = {
  title: 'Lone Star Market — Texas Proud. Everyday.',
  description:
    'Fresh produce, premium Texas meats, local artisans, and everyday grocery essentials at fair prices across the Lone Star State.',
  openGraph: {
    title: 'Lone Star Market — Texas Proud. Everyday.',
    description:
      'Fresh produce, premium Texas meats, local artisans, and everyday grocery essentials at fair prices across the Lone Star State.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Lone Star Market — Texas Proud. Everyday.',
    description:
      'Fresh produce, premium Texas meats, local artisans, and everyday grocery essentials at fair prices across the Lone Star State.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html
      lang="en"
      className={`${playfair.variable} ${jakarta.variable} ${jetbrains.variable}`}
    >
      <body
        suppressHydrationWarning
        className="bg-[#F7F3EB] text-[#242A30] antialiased selection:bg-[#C92332] selection:text-white font-sans"
      >
        {children}
      </body>
    </html>
  );
}
