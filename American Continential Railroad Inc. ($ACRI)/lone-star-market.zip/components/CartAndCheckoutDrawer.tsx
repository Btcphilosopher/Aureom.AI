'use client';

import React, { useState } from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  MapPin,
  Clock,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Heart,
  ShieldCheck,
} from 'lucide-react';
import { DEMO_STORES, DemoStore, Product } from '@/lib/store-data';
import { ResilientImage } from './ResilientImage';
import { LoneStarSymbol } from './BrandLogo';

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartAndCheckoutDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (product: Product, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  selectedStore: DemoStore;
  onSelectStore: (store: DemoStore) => void;
}

const PICKUP_SLOTS = [
  'Today · 2:00 PM – 3:00 PM (Curbside Bay)',
  'Today · 4:00 PM – 5:00 PM (Curbside Bay)',
  'Today · 6:00 PM – 7:00 PM (Curbside Bay)',
  'Tomorrow · 9:00 AM – 10:00 AM (Morning Fresh)',
  'Tomorrow · 12:00 PM – 1:00 PM (Midday Express)',
];

export function CartAndCheckoutDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  selectedStore,
  onSelectStore,
}: CartAndCheckoutDrawerProps) {
  const [step, setStep] = useState<'cart' | 'checkout' | 'confirmed'>('cart');
  const [customerName, setCustomerName] = useState('Clara Barton');
  const [customerEmail, setCustomerEmail] = useState('clara.barton@example.com');
  const [customerPhone, setCustomerPhone] = useState('(512) 555-0199');
  const [vehicleDesc, setVehicleDesc] = useState('Silver Ford F-150 Pickup');
  const [pickupSlot, setPickupSlot] = useState(PICKUP_SLOTS[0]);
  const [formError, setFormError] = useState('');
  const [confirmedOrder, setConfirmedOrder] = useState<{
    orderId: string;
    items: CartItem[];
    subtotal: number;
    savings: number;
    store: DemoStore;
    slot: string;
    customerName: string;
  } | null>(null);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (sum, item) => sum + (item.product.promoPrice ?? item.product.price) * item.quantity,
    0
  );

  const totalSavings = cartItems.reduce((sum, item) => {
    if (item.product.promoPrice && item.product.promoPrice < item.product.price) {
      return sum + (item.product.price - item.product.promoPrice) * item.quantity;
    }
    return sum;
  }, 0);

  const pickupFee = subtotal >= 35 || subtotal === 0 ? 0 : 3.95;
  const estimatedTotal = subtotal + pickupFee;

  const handlePlaceDemoOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerEmail.trim() || !customerPhone.trim()) {
      setFormError('Please complete your contact name, email, and mobile number.');
      return;
    }
    setFormError('');
    const orderNum = `LSM-TX-${Math.floor(100000 + Math.random() * 900000)}`;
    setConfirmedOrder({
      orderId: orderNum,
      items: [...cartItems],
      subtotal: estimatedTotal,
      savings: totalSavings,
      store: selectedStore,
      slot: pickupSlot,
      customerName: customerName.trim(),
    });
    onClearCart();
    setStep('confirmed');
  };

  const handleClose = () => {
    if (step === 'confirmed') {
      setStep('cart');
    }
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/65 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-drawer-title"
    >
      <div className="relative w-full max-w-lg bg-[#F7F3EB] text-[#242A30] h-full flex flex-col shadow-2xl border-l border-[#102A43]/15">
        {/* Top Bar */}
        <div className="px-6 py-4 bg-[#102A43] text-white flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <LoneStarSymbol className="w-6 h-6" variant="color" />
            <h2 id="cart-drawer-title" className="font-display font-bold text-lg">
              {step === 'cart' && 'Your Lone Star Basket'}
              {step === 'checkout' && 'Curbside Pickup Demo Checkout'}
              {step === 'confirmed' && 'Demo Order Reservation Confirmed'}
            </h2>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close drawer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Store Banner */}
        <div className="px-6 py-2.5 bg-[#0B1F33] text-white/90 text-xs flex items-center justify-between">
          <div className="flex items-center gap-1.5 truncate">
            <MapPin className="w-3.5 h-3.5 text-[#D8A64A] shrink-0" />
            <span className="truncate">
              Store: <strong className="text-white">{selectedStore.name}</strong>
            </span>
          </div>
          <span className="font-mono text-[11px] text-[#D8A64A] shrink-0">
            {subtotal >= 35 ? 'Free Pickup Unlocked' : `$${(35 - subtotal).toFixed(2)} to Free Pickup`}
          </span>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {step === 'cart' && (
            <>
              {cartItems.length === 0 ? (
                <div className="text-center py-16 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-white border border-[#102A43]/10 flex items-center justify-center mx-auto">
                    <ShoppingBag className="w-7 h-7 text-[#102A43]/60" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-display font-bold text-xl text-[#102A43]">
                      Your basket is currently empty
                    </h3>
                    <p className="text-xs sm:text-sm text-[#242A30]/70 max-w-xs mx-auto">
                      Add fresh Texas produce, post-oak smoked brisket, or everyday pantry staples
                      to start your order.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleClose}
                    className="px-5 py-2.5 rounded-lg bg-[#C92332] hover:bg-[#AD1B28] text-white text-xs sm:text-sm font-semibold transition-colors"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#242A30]/70">
                    <span>
                      {cartItems.reduce((acc, i) => acc + i.quantity, 0)} items in basket
                    </span>
                    <button
                      type="button"
                      onClick={onClearCart}
                      className="text-[#C92332] hover:underline font-medium"
                    >
                      Clear Basket
                    </button>
                  </div>

                  {cartItems.map(({ product, quantity }) => {
                    const unitPrice = product.promoPrice ?? product.price;
                    return (
                      <div
                        key={product.id}
                        className="bg-white p-3.5 rounded-xl border border-[#102A43]/10 flex items-center gap-3.5 shadow-2xs"
                      >
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-[#F7F3EB] shrink-0 border border-[#102A43]/10">
                          <ResilientImage
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover"
                            fallbackColor={product.fallbackColor}
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <h4 className="font-sans font-semibold text-sm text-[#102A43] truncate">
                            {product.name}
                          </h4>
                          <p className="text-xs text-[#242A30]/65 truncate">
                            {product.brand} · {product.unitSize}
                          </p>
                          <div className="mt-1 flex items-center gap-2 font-mono text-xs tabular-nums">
                            <span className="font-bold text-[#102A43]">
                              ${(unitPrice * quantity).toFixed(2)}
                            </span>
                            <span className="text-[#242A30]/55">
                              (${unitPrice.toFixed(2)} each)
                            </span>
                          </div>
                        </div>

                        <div className="flex flex-col items-end gap-2">
                          <button
                            type="button"
                            onClick={() => onRemoveItem(product.id)}
                            className="text-[#242A30]/45 hover:text-[#C92332] transition-colors"
                            aria-label={`Remove ${product.name}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>

                          <div className="inline-flex items-center rounded-lg bg-[#F7F3EB] border border-[#102A43]/15">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(product, -1)}
                              className="w-7 h-7 flex items-center justify-center text-[#102A43] hover:bg-[#102A43]/10 rounded-l-lg"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-6 text-center font-mono text-xs font-bold tabular-nums">
                              {quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(product, 1)}
                              className="w-7 h-7 flex items-center justify-center text-[#102A43] hover:bg-[#102A43]/10 rounded-r-lg"
                              aria-label="Increase quantity"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {step === 'checkout' && (
            <form id="demo-checkout-form" onSubmit={handlePlaceDemoOrder} className="space-y-5">
              {/* Prototype Disclaimer Banner */}
              <div className="p-3.5 rounded-xl bg-[#102A43] text-white text-xs space-y-1">
                <div className="flex items-center gap-2 font-semibold text-[#D8A64A]">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>Demonstration Checkout — No Real Payment Collected</span>
                </div>
                <p className="text-white/85 leading-relaxed">
                  This is an interactive prototype for Lone Star Market. Payment processing and live
                  order fulfillment are simulated—no credit card details are requested or stored.
                </p>
              </div>

              {formError && (
                <div className="p-3 rounded-lg bg-[#C92332]/10 border border-[#C92332] text-[#C92332] text-xs font-semibold">
                  {formError}
                </div>
              )}

              {/* 1. Selected Demo Store */}
              <div className="bg-white p-4 rounded-xl border border-[#102A43]/12 space-y-2.5">
                <label
                  htmlFor="checkout-store"
                  className="block text-xs font-bold uppercase tracking-wider text-[#102A43]"
                >
                  1. Selected Curbside Pickup Store (Demo)
                </label>
                <select
                  id="checkout-store"
                  value={selectedStore.id}
                  onChange={(e) => {
                    const found = DEMO_STORES.find((s) => s.id === e.target.value);
                    if (found) onSelectStore(found);
                  }}
                  className="w-full h-10 px-3 rounded-lg bg-[#F7F3EB] border border-[#102A43]/15 text-xs sm:text-sm font-semibold text-[#102A43]"
                >
                  {DEMO_STORES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.city}, TX {s.zip})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-[#242A30]/70">{selectedStore.address}</p>
              </div>

              {/* 2. Pickup Time Selection */}
              <div className="bg-white p-4 rounded-xl border border-[#102A43]/12 space-y-2.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#102A43]">
                  2. Select Curbside Pickup Window
                </label>
                <div className="space-y-1.5">
                  {PICKUP_SLOTS.map((slot) => (
                    <label
                      key={slot}
                      className={`flex items-center gap-2.5 p-2.5 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
                        pickupSlot === slot
                          ? 'bg-[#F7F3EB] border-[#C92332] text-[#102A43] font-semibold'
                          : 'border-[#102A43]/10 text-[#242A30]'
                      }`}
                    >
                      <input
                        type="radio"
                        name="pickupSlot"
                        checked={pickupSlot === slot}
                        onChange={() => setPickupSlot(slot)}
                        className="accent-[#C92332]"
                      />
                      <Clock className="w-3.5 h-3.5 text-[#102A43]/70" />
                      <span>{slot}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* 3. Contact Details */}
              <div className="bg-white p-4 rounded-xl border border-[#102A43]/12 space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-[#102A43]">
                  3. Contact &amp; Curbside Arrival Details
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#242A30]/80 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg bg-[#F7F3EB] border border-[#102A43]/15 text-xs sm:text-sm"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-[#242A30]/80 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      className="w-full h-9 px-3 rounded-lg bg-[#F7F3EB] border border-[#102A43]/15 text-xs sm:text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#242A30]/80 mb-1">
                      Mobile Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full h-9 px-3 rounded-lg bg-[#F7F3EB] border border-[#102A43]/15 text-xs sm:text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#242A30]/80 mb-1">
                    Vehicle Description (for Curbside Attendant)
                  </label>
                  <input
                    type="text"
                    value={vehicleDesc}
                    onChange={(e) => setVehicleDesc(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg bg-[#F7F3EB] border border-[#102A43]/15 text-xs sm:text-sm"
                  />
                </div>
              </div>
            </form>
          )}

          {step === 'confirmed' && confirmedOrder && (
            <div className="bg-white p-6 rounded-2xl border border-[#102A43]/15 space-y-5 text-center">
              <div className="w-14 h-14 rounded-full bg-[#71866B]/15 text-[#71866B] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <span className="text-[11px] font-mono font-semibold uppercase tracking-widest text-[#C92332]">
                  Simulated Demo Order #{confirmedOrder.orderId}
                </span>
                <h3 className="font-display font-bold text-2xl text-[#102A43]">
                  Thank You, {confirmedOrder.customerName}!
                </h3>
                <p className="text-xs sm:text-sm text-[#242A30]/75">
                  Your demonstration curbside pickup reservation has been recorded.
                </p>
              </div>

              <div className="bg-[#F7F3EB] p-4 rounded-xl text-left space-y-2 text-xs">
                <div>
                  <span className="text-[#242A30]/60">Pickup Store: </span>
                  <strong className="text-[#102A43]">{confirmedOrder.store.name}</strong>
                </div>
                <div>
                  <span className="text-[#242A30]/60">Pickup Window: </span>
                  <strong className="text-[#102A43]">{confirmedOrder.slot}</strong>
                </div>
                <div>
                  <span className="text-[#242A30]/60">Items Reserved: </span>
                  <strong className="text-[#102A43]">
                    {confirmedOrder.items.reduce((a, b) => a + b.quantity, 0)} items
                  </strong>
                </div>
                <div className="pt-2 border-t border-[#102A43]/10 flex items-center justify-between font-mono text-sm font-bold text-[#102A43]">
                  <span>Total (Demo Estimate):</span>
                  <span>${confirmedOrder.subtotal.toFixed(2)}</span>
                </div>
              </div>

              <p className="text-[11px] text-[#242A30]/65 leading-relaxed">
                Reminder: This is a demonstration checkout flow for the Lone Star Market web
                prototype. No payment was charged and no physical groceries will be dispatched.
              </p>

              <button
                type="button"
                onClick={handleClose}
                className="w-full py-3 rounded-lg bg-[#102A43] hover:bg-[#1B3F63] text-white text-xs sm:text-sm font-semibold transition-colors"
              >
                Return to Lone Star Market
              </button>
            </div>
          )}
        </div>

        {/* Sticky Footer Summary & Actions */}
        {cartItems.length > 0 && step !== 'confirmed' && (
          <div className="p-5 bg-white border-t border-[#102A43]/12 space-y-4">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-[#242A30]/75">
                <span>Basket Subtotal (Demo Prices)</span>
                <span className="font-mono font-semibold tabular-nums">
                  ${subtotal.toFixed(2)}
                </span>
              </div>
              {totalSavings > 0 && (
                <div className="flex justify-between text-[#C92332] font-medium">
                  <span>Weekly Circular Savings</span>
                  <span className="font-mono tabular-nums">-${totalSavings.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-[#242A30]/75">
                <span>Curbside Pickup Fee</span>
                <span className="font-mono tabular-nums">
                  {pickupFee === 0 ? 'FREE' : `$${pickupFee.toFixed(2)}`}
                </span>
              </div>
              <div className="pt-2 border-t border-[#102A43]/10 flex justify-between text-base font-bold text-[#102A43]">
                <span>Estimated Total</span>
                <span className="font-mono tabular-nums">${estimatedTotal.toFixed(2)}</span>
              </div>
            </div>

            {step === 'cart' ? (
              <button
                type="button"
                onClick={() => setStep('checkout')}
                className="w-full py-3.5 px-5 rounded-xl bg-[#C92332] hover:bg-[#AD1B28] text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
              >
                <span>Proceed to Curbside Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setStep('cart')}
                  className="py-3 px-4 rounded-xl border border-[#102A43]/20 text-[#102A43] font-semibold text-xs sm:text-sm inline-flex items-center gap-1.5 hover:bg-[#F7F3EB]"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
                <button
                  type="submit"
                  form="demo-checkout-form"
                  className="flex-1 py-3 px-5 rounded-xl bg-[#C92332] hover:bg-[#AD1B28] text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Complete Demo Order (${estimatedTotal.toFixed(2)})</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

interface ProductQuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  cartQuantity: number;
  onAddToCart: (product: Product, delta: number) => void;
}

export function ProductQuickViewModal({
  product,
  onClose,
  cartQuantity,
  onAddToCart,
}: ProductQuickViewModalProps) {
  if (!product) return null;
  const activePrice = product.promoPrice ?? product.price;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="quickview-title"
    >
      <div className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-[#102A43]/15 grid grid-cols-1 md:grid-cols-2">
        <div className="relative aspect-4/3 md:aspect-auto bg-[#F7F3EB]">
          <ResilientImage
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
            fallbackColor={product.fallbackColor}
          />
        </div>
        <div className="p-6 flex flex-col justify-between space-y-4">
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#C92332]">
                {product.brand}
              </span>
              <button
                type="button"
                onClick={onClose}
                className="p-1 rounded-lg text-[#242A30]/60 hover:text-[#242A30]"
                aria-label="Close product details"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <h3 id="quickview-title" className="font-display font-bold text-2xl text-[#102A43]">
              {product.name}
            </h3>

            <div className="flex items-baseline gap-2 font-mono tabular-nums">
              <span className="text-2xl font-bold text-[#102A43]">
                ${activePrice.toFixed(2)}
              </span>
              {product.promoPrice && (
                <span className="text-sm text-[#242A30]/50 line-through">
                  ${product.price.toFixed(2)}
                </span>
              )}
              <span className="text-xs text-[#242A30]/70">· {product.unitSize}</span>
            </div>

            <p className="text-xs sm:text-sm text-[#242A30]/80 leading-relaxed pt-1">
              {product.description}
            </p>

            <div className="bg-[#F7F3EB] p-3 rounded-lg space-y-1 text-xs">
              <div>
                <strong className="text-[#102A43]">Source / Origin: </strong>
                <span>{product.origin}</span>
              </div>
              <div>
                <strong className="text-[#102A43]">Nutrition &amp; Specs: </strong>
                <span className="font-mono text-[11px]">{product.nutritionSummary}</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-[#102A43]/10 flex items-center justify-between gap-3">
            {cartQuantity > 0 ? (
              <div className="inline-flex items-center rounded-lg bg-[#102A43] text-white p-1">
                <button
                  type="button"
                  onClick={() => onAddToCart(product, -1)}
                  className="w-8 h-8 flex items-center justify-center rounded hover:bg-white/15"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-8 text-center font-mono text-sm font-bold tabular-nums">
                  {cartQuantity}
                </span>
                <button
                  type="button"
                  onClick={() => onAddToCart(product, 1)}
                  className="w-8 h-8 flex items-center justify-center rounded hover:bg-white/15"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => onAddToCart(product, 1)}
                className="flex-1 py-2.5 px-4 rounded-lg bg-[#C92332] hover:bg-[#AD1B28] text-white text-xs sm:text-sm font-semibold transition-colors"
              >
                Add to Basket — ${activePrice.toFixed(2)}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
