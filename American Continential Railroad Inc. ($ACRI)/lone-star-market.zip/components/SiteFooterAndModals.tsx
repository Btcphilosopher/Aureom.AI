'use client';

import React, { useState } from 'react';
import {
  Mail,
  CheckCircle2,
  AlertCircle,
  X,
  User,
  LogOut,
  Share2,
  Globe,
  MessageSquare,
  Video,
} from 'lucide-react';
import { BrandLogo, LoneStarSymbol } from './BrandLogo';
import { CategoryId } from '@/lib/store-data';

export type InfoModalTopic =
  | 'our-story'
  | 'texas-producers'
  | 'careers'
  | 'community'
  | 'sustainability'
  | 'contact'
  | 'help'
  | 'pickup-info'
  | 'faq'
  | 'privacy'
  | 'terms'
  | 'accessibility'
  | null;

const INFO_CONTENT: Record<
  Exclude<InfoModalTopic, null>,
  { kicker: string; title: string; body: string[]; highlights: string[] }
> = {
  'our-story': {
    kicker: 'About Lone Star Market',
    title: 'Our Story — Texas Proud. Everyday.',
    body: [
      'Lone Star Market was conceived to bring together the warm hospitality of an independent Texas town grocer with the selection, food safety, and everyday fair pricing of a modern regional supermarket.',
      'From our architectural limestone storefronts to our in-store post-oak smokehouses and scratch bakeries, every detail is designed for Texas families and communities.',
    ],
    highlights: [
      'Direct partnerships with Texas cattle ranchers and family orchards',
      'Scratch sourdough and panadería bakeries in every flagship store',
      'Transparent everyday low pricing across 15,000+ household essentials',
    ],
  },
  'texas-producers': {
    kicker: 'Local Sourcing Program',
    title: 'Supporting Independent Texas Producers',
    body: [
      'Our Texas Made pavilion highlights small-batch makers from across the state—from Hill Country wildflower apiaries and Austin coffee roasters to Rio Grande Valley produce farms and San Saba pecan orchards.',
      'Note: Products displayed in this digital prototype are illustrative concepts created to demonstrate the Lone Star Market brand system.',
    ],
    highlights: [
      'Fast-track shelf onboarding for independent Texas food businesses',
      'Dedicated end-cap merchandising and seasonal producer spotlights',
      'Fair wholesale payment terms for local family farms',
    ],
  },
  careers: {
    kicker: 'Join Our Team',
    title: 'Careers at Lone Star Market',
    body: [
      'Great supermarkets are built by welcoming, knowledgeable people—from certified meat cutters and scratch bakers to curbside personal shoppers and store leaders.',
      'This is an illustrative careers overview for the Lone Star Market digital retail prototype.',
    ],
    highlights: [
      'Competitive hourly wages and culinary apprenticeship tracks',
      'Store colleague grocery discount and family health benefits',
      'Opportunities across Austin, Dallas–Fort Worth, Houston, and San Antonio',
    ],
  },
  community: {
    kicker: 'Community Stewardship',
    title: 'Neighbours Helping Neighbours',
    body: [
      'Lone Star Market partners with regional Texas food banks, agricultural youth programs, and neighborhood school gardens to ensure fresh, nutritious food is accessible across every community we serve.',
    ],
    highlights: [
      'Daily fresh food rescue partnerships with Texas regional food banks',
      'Annual Future Texas Farmers & Ranchers scholarship program',
      'Disaster relief pantry mobilization across the Gulf Coast and Central Texas',
    ],
  },
  sustainability: {
    kicker: 'Environmental Responsibility',
    title: 'Practical Sustainability for Texas Retail',
    body: [
      'We focus on high-impact operational improvements: shortening supply chains by sourcing inside Texas, utilizing energy-efficient CO2 refrigeration, and offering 100% recycled kraft grocery bags.',
    ],
    highlights: [
      'Shorter farm-to-store transport miles via regional Texas hubs',
      'High-efficiency LED lighting and low-emission refrigeration systems',
      'Compostable produce trimmings and food-bank recovery programs',
    ],
  },
  contact: {
    kicker: 'Customer Service',
    title: 'Contact Lone Star Market Guest Care',
    body: [
      'Have a question about a product, curbside pickup order, or local Texas supplier inquiry? Our guest care team is ready to help.',
      'Prototype Notice: Contact details below are illustrative sample data for this demonstration application.',
    ],
    highlights: [
      'Demo Guest Care Line: 1-800-555-LONE (Mon–Sun, 7:00 AM – 10:00 PM CT)',
      'Demo Guest Support Email: guestcare@lonestarmarket.example.com',
      'Headquarters Concept: Austin, Texas',
    ],
  },
  help: {
    kicker: 'Customer Service',
    title: 'Help Centre & Online Shopping Guide',
    body: [
      'Browse departments using the top navigation bar, search for specific items like milk, ribeye steak, or tomatoes, and add items directly to your basket.',
      'Your basket and selected Texas store are automatically saved in your browser between refreshes.',
    ],
    highlights: [
      '100% Freshness Guarantee on all meat, seafood, produce, and bakery items',
      'Easy quantity adjustments directly on product cards or inside the cart drawer',
      'Instant store switching across 5 Texas demonstration locations',
    ],
  },
  'pickup-info': {
    kicker: 'Curbside Collection',
    title: 'Fast & Easy Curbside Pickup',
    body: [
      'Order online and collect your groceries at your selected Lone Star Market without leaving your vehicle. Our personal shoppers hand-select produce and butcher cuts according to your preferences.',
    ],
    highlights: [
      'Free curbside pickup on orders of $35 or more ($3.95 on smaller baskets)',
      'Dedicated covered curbside bays at every Lone Star Market location',
      'Cold-chain temperature-controlled holding until you arrive',
    ],
  },
  faq: {
    kicker: 'Customer Service',
    title: 'Frequently Asked Questions',
    body: [
      'Q: Are the prices and stores on this website real? A: No—all prices, products, and store addresses are illustrative demonstration data created for the Lone Star Market digital retail prototype.',
      'Q: Does checkout charge a real credit card? A: Never. Checkout is a safe frontend simulation and never asks for payment card numbers.',
    ],
    highlights: [
      'Cart items persist automatically in local browser storage',
      'Switch stores anytime via Find a Store in the header',
      'Explore the full Corporate Visual Identity System from the top announcement bar',
    ],
  },
  privacy: {
    kicker: 'Legal Notice',
    title: 'Privacy Policy (Demonstration Prototype)',
    body: [
      'This application is a frontend e-commerce prototype for Lone Star Market. Cart contents, favorite items, and selected store preferences are stored strictly locally in your browser (localStorage) and are never transmitted to external third parties.',
    ],
    highlights: [
      'Zero real payment information collected',
      'Local browser storage only for cart and store preferences',
      'No external tracking cookies or marketing telemetry',
    ],
  },
  terms: {
    kicker: 'Legal Notice',
    title: 'Terms of Use (Demonstration Prototype)',
    body: [
      'All products, brand names, prices, promotions, and Texas store locations presented on this site are fictional demonstration concepts created to showcase retail UX, corporate branding, and frontend architecture.',
    ],
    highlights: [
      'Illustrative pricing and promotional circulars',
      'Concept packaging and fictional demonstration store addresses',
      'Designed for portfolio and retail evaluation purposes',
    ],
  },
  accessibility: {
    kicker: 'Inclusive Retail',
    title: 'Accessibility Statement',
    body: [
      'Lone Star Market is committed to ensuring a welcoming, accessible shopping experience both in our stores and online. This website is engineered with semantic HTML landmarks, keyboard navigation support, high-contrast typography (WCAG AA+), and screen-reader labels.',
    ],
    highlights: [
      'WCAG AA contrast ratios across Midnight Navy, Warm Cream, and Texas Red',
      'Keyboard-navigable menus, modals, and quantity steppers',
      'Clear descriptive alt text on all food and architectural photography',
    ],
  },
};

interface SiteFooterProps {
  onSelectCategory: (cat: CategoryId) => void;
  onOpenInfoModal: (topic: Exclude<InfoModalTopic, null>) => void;
  onOpenBrandIdentity: () => void;
}

export function SiteFooter({
  onSelectCategory,
  onOpenInfoModal,
  onOpenBrandIdentity,
}: SiteFooterProps) {
  const [email, setEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = email.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmed)) {
      setNewsletterStatus('error');
      setErrorMsg('Please enter a valid email address (for example, shopper@example.com).');
      return;
    }
    setNewsletterStatus('success');
    setErrorMsg('');
    setEmail('');
  };

  const handleCategoryLink = (cat: CategoryId) => {
    onSelectCategory(cat);
    const el = document.getElementById('shopping-catalog');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#102A43] text-white border-t border-white/10">
      {/* Newsletter Banner */}
      <div className="border-b border-white/10 bg-[#0B1F33]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-8 sm:py-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-1 max-w-xl">
            <span className="text-xs font-semibold uppercase tracking-widest text-[#D8A64A]">
              Weekly Circular &amp; Seasonal Recipes
            </span>
            <h3 className="font-display font-bold text-xl sm:text-2xl text-white">
              Get Fresh Texas Savings Delivered to Your Inbox
            </h3>
            <p className="text-xs sm:text-sm text-white/75">
              Sign up for weekly butcher specials, seasonal Texas harvest alerts, and curbside
              pickup offers. (Frontend validation demo — no emails are sent.)
            </p>
          </div>

          <div className="w-full lg:max-w-md">
            <form onSubmit={handleNewsletterSubmit} noValidate className="flex gap-2">
              <div className="relative flex-1">
                <Mail className="w-4 h-4 text-[#242A30]/50 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (newsletterStatus !== 'idle') setNewsletterStatus('idle');
                  }}
                  placeholder="Enter your email address..."
                  aria-label="Email address for weekly deals newsletter"
                  className="w-full h-11 pl-10 pr-3 rounded-lg bg-white text-[#242A30] placeholder:text-[#242A30]/50 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#D8A64A]"
                />
              </div>
              <button
                type="submit"
                className="px-5 h-11 rounded-lg bg-[#C92332] hover:bg-[#AD1B28] text-white font-semibold text-xs sm:text-sm transition-colors shrink-0 cursor-pointer whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>

            {newsletterStatus === 'error' && (
              <p className="mt-2 text-xs text-[#FCA5A5] flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errorMsg}</span>
              </p>
            )}
            {newsletterStatus === 'success' && (
              <p className="mt-2 text-xs text-[#A7F3D0] flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>
                  Thank you for subscribing! (Demo confirmation — no external email sent.)
                </span>
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Main Corporate Footer Links */}
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 pb-10 border-b border-white/10">
          {/* Brand Column (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <BrandLogo
              variant="footer"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            />
            <p className="text-xs sm:text-sm text-white/75 leading-relaxed max-w-sm">
              Combining the warmth and character of an independent Texas grocer with the quality,
              fair prices, and convenience of a modern supermarket chain.
            </p>
            <div className="pt-1">
              <button
                type="button"
                onClick={onOpenBrandIdentity}
                className="text-xs font-semibold text-[#D8A64A] hover:underline"
              >
                Explore Corporate Visual Identity System →
              </button>
            </div>
          </div>

          {/* Link Group 1: SHOP */}
          <div className="space-y-3">
            <h4 className="font-sans text-xs font-bold uppercase tracking-widest text-[#D8A64A]">
              SHOP
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => handleCategoryLink('all')}
                  className="hover:text-white transition-colors"
                >
                  All Groceries
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleCategoryLink('fresh-food')}
                  className="hover:text-white transition-colors"
                >
                  Fresh Produce
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleCategoryLink('meat-seafood')}
                  className="hover:text-white transition-colors"
                >
                  Meat &amp; Seafood
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleCategoryLink('bakery')}
                  className="hover:text-white transition-colors"
                >
                  Bakery
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleCategoryLink('weekly-deals')}
                  className="hover:text-white transition-colors"
                >
                  Weekly Deals
                </button>
              </li>
            </ul>
          </div>

          {/* Link Group 2: CUSTOMER SERVICE */}
          <div className="space-y-3">
            <h4 className="font-sans text-xs font-bold uppercase tracking-widest text-[#D8A64A]">
              CUSTOMER SERVICE
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('contact')}
                  className="hover:text-white transition-colors"
                >
                  Contact Us
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('help')}
                  className="hover:text-white transition-colors"
                >
                  Help Centre
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('pickup-info')}
                  className="hover:text-white transition-colors"
                >
                  Pickup Information
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('faq')}
                  className="hover:text-white transition-colors"
                >
                  Frequently Asked Questions
                </button>
              </li>
            </ul>
          </div>

          {/* Link Group 3: ABOUT LONE STAR */}
          <div className="space-y-3">
            <h4 className="font-sans text-xs font-bold uppercase tracking-widest text-[#D8A64A]">
              ABOUT LONE STAR
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('our-story')}
                  className="hover:text-white transition-colors"
                >
                  Our Story
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('texas-producers')}
                  className="hover:text-white transition-colors"
                >
                  Texas Producers
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('careers')}
                  className="hover:text-white transition-colors"
                >
                  Careers
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('community')}
                  className="hover:text-white transition-colors"
                >
                  Community
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('sustainability')}
                  className="hover:text-white transition-colors"
                >
                  Sustainability
                </button>
              </li>
            </ul>
          </div>

          {/* Link Group 4: LEGAL */}
          <div className="space-y-3">
            <h4 className="font-sans text-xs font-bold uppercase tracking-widest text-[#D8A64A]">
              LEGAL
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('privacy')}
                  className="hover:text-white transition-colors"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('terms')}
                  className="hover:text-white transition-colors"
                >
                  Terms of Use
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('accessibility')}
                  className="hover:text-white transition-colors"
                >
                  Accessibility
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar matching reference image */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/75">
          <div className="flex flex-wrap items-center gap-4">
            <span>
              &copy; {new Date().getFullYear()} Lone Star Market Retail Concept. All rights
              reserved.
            </span>
            <span aria-hidden="true" className="hidden sm:inline">
              |
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => onOpenInfoModal('our-story')}
                className="hover:text-white"
              >
                About Us
              </button>
              <span>|</span>
              <button
                type="button"
                onClick={() => onOpenInfoModal('careers')}
                className="hover:text-white"
              >
                Careers
              </button>
              <span>|</span>
              <button
                type="button"
                onClick={() => onOpenInfoModal('sustainability')}
                className="hover:text-white"
              >
                Sustainability
              </button>
              <span>|</span>
              <button
                type="button"
                onClick={() => onOpenInfoModal('contact')}
                className="hover:text-white"
              >
                Contact
              </button>
            </div>
          </div>

          {/* Social Media Icon Placeholders & Tagline */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2.5" aria-label="Social Media Placeholders">
              <button
                type="button"
                onClick={() => onOpenInfoModal('community')}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
                aria-label="Community Social Placeholder"
              >
                <Globe className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onOpenInfoModal('community')}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
                aria-label="Photo Social Placeholder"
              >
                <Share2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onOpenInfoModal('community')}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
                aria-label="Updates Social Placeholder"
              >
                <MessageSquare className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onOpenInfoModal('community')}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
                aria-label="Video Social Placeholder"
              >
                <Video className="w-3.5 h-3.5" />
              </button>
            </div>

            <span className="font-sans font-bold tracking-[0.22em] text-white uppercase text-[11px] whitespace-nowrap">
              TEXAS PROUD. EVERYDAY.
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

interface InfoModalProps {
  topic: InfoModalTopic;
  onClose: () => void;
}

export function CorporateInfoModal({ topic, onClose }: InfoModalProps) {
  if (!topic) return null;
  const content = INFO_CONTENT[topic];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="corporate-info-title"
    >
      <div className="bg-[#F7F3EB] text-[#242A30] rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-[#102A43]/15">
        <div className="px-6 py-4 bg-[#102A43] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <LoneStarSymbol className="w-6 h-6" variant="color" />
            <span className="text-xs font-semibold uppercase tracking-widest text-[#D8A64A]">
              {content.kicker}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <h3
            id="corporate-info-title"
            className="font-display font-bold text-2xl text-[#102A43]"
          >
            {content.title}
          </h3>
          {content.body.map((paragraph, i) => (
            <p key={i} className="text-xs sm:text-sm text-[#242A30]/85 leading-relaxed">
              {paragraph}
            </p>
          ))}

          <div className="bg-white p-4 rounded-xl border border-[#102A43]/10 space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-[#102A43]">
              Key Highlights
            </div>
            <ul className="space-y-1.5 text-xs text-[#242A30]/85">
              {content.highlights.map((h, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#C92332] mt-1.5 shrink-0" />
                  <span>{h}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-lg bg-[#102A43] hover:bg-[#1B3F63] text-white text-xs font-semibold transition-colors"
            >
              Close Window
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface SignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  signedInUser: { name: string; email: string } | null;
  onSignIn: (user: { name: string; email: string } | null) => void;
}

export function SignInModal({
  isOpen,
  onClose,
  signedInUser,
  onSignIn,
}: SignInModalProps) {
  const [name, setName] = useState('Travis Crockett');
  const [email, setEmail] = useState('travis@lonestar.example.com');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;
    onSignIn({ name: name.trim(), email: email.trim() });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="signin-modal-title"
    >
      <div className="bg-[#F7F3EB] text-[#242A30] rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-[#102A43]/15">
        <div className="px-6 py-4 bg-[#102A43] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <LoneStarSymbol className="w-6 h-6" variant="color" />
            <h3 id="signin-modal-title" className="font-display font-bold text-lg">
              Lone Star Neighbour Account
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white"
            aria-label="Close account modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {signedInUser ? (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-xl border border-[#102A43]/10 flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-[#102A43] text-white flex items-center justify-center font-display font-bold text-lg">
                  {signedInUser.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-sm text-[#102A43]">{signedInUser.name}</div>
                  <div className="text-xs text-[#242A30]/70">{signedInUser.email}</div>
                  <div className="text-[11px] font-semibold text-[#71866B] mt-0.5">
                    Texas Proud Member · Demo Account Active
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  onSignIn(null);
                  onClose();
                }}
                className="w-full py-2.5 px-4 rounded-lg border border-[#C92332] text-[#C92332] hover:bg-[#C92332] hover:text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out of Demo Account</span>
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              <p className="text-xs text-[#242A30]/80 leading-relaxed">
                Sign in to your demonstration Lone Star Market account to save favourite Texas
                products and speed up curbside pickup reservations.
              </p>
              <div>
                <label className="block text-xs font-semibold text-[#102A43] mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg bg-white border border-[#102A43]/15 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#102A43] mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg bg-white border border-[#102A43]/15 text-sm"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-lg bg-[#C92332] hover:bg-[#AD1B28] text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
              >
                Sign In to Demo Account
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
