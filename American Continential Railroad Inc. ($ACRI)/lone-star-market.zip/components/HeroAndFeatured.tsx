'use client';

import React from 'react';
import {
  ArrowRight,
  ChevronRight,
  Truck,
  Tag,
  Sprout,
  MapPin,
} from 'lucide-react';
import { CategoryId, SIX_GRID_CATEGORIES } from '@/lib/store-data';
import { LoneStarSymbol } from './BrandLogo';
import { ResilientImage } from './ResilientImage';

interface HeroAndFeaturedProps {
  onSelectCategory: (cat: CategoryId) => void;
  onShopNow: () => void;
  onFindStore: () => void;
  activeCategory: CategoryId;
}

export function HeroAndFeatured({
  onSelectCategory,
  onShopNow,
  onFindStore,
  activeCategory,
}: HeroAndFeaturedProps) {
  return (
    <div>
      {/* C. Homepage Hero */}
      <section className="relative w-full min-h-[430px] sm:min-h-[490px] lg:min-h-[540px] flex items-center overflow-hidden bg-[#102A43]">
        {/* Background Flagship Store Photograph */}
        <div className="absolute inset-0">
          <ResilientImage
            src="/assets/generated/flagship_store_hero.jpg"
            alt="Lone Star Market flagship Texas supermarket exterior at sunset"
            className="w-full h-full object-cover object-center"
            fallbackColor="#102A43"
          />
          {/* Measured horizontal & vertical contrast scrim for 4.5:1+ WCAG legibility */}
          <div
            className="absolute inset-0 bg-gradient-to-r from-[#0A1929]/90 via-[#0A1929]/55 to-transparent"
            aria-hidden="true"
          />
          <div
            className="absolute inset-0 bg-gradient-to-t from-[#0A1929]/60 via-transparent to-black/20"
            aria-hidden="true"
          />
        </div>

        {/* Hero Editorial Content */}
        <div className="relative z-10 w-full max-w-[1360px] mx-auto px-4 sm:px-6 py-12 sm:py-16 lg:py-20">
          <div className="max-w-xl text-white space-y-5">
            <h1 className="font-display font-bold text-4xl sm:text-5xl lg:text-[62px] leading-[1.04] tracking-tight text-white drop-shadow-sm">
              Good Food.
              <br />
              Great Value.
              <br />
              Texas Proud.
            </h1>

            <p className="text-base sm:text-lg text-white/95 font-medium leading-relaxed max-w-md drop-shadow-xs">
              Fresh produce, quality meats, local favourites, and everything you need — all in one
              place.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={onShopNow}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-lg bg-[#C92332] hover:bg-[#AD1B28] text-white font-semibold text-sm sm:text-base shadow-lg transition-all duration-150 hover:-translate-y-0.5 cursor-pointer whitespace-nowrap"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onFindStore}
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-lg bg-[#102A43]/85 hover:bg-[#102A43] text-white border border-white/30 font-semibold text-sm sm:text-base backdrop-blur-xs transition-all duration-150 hover:-translate-y-0.5 cursor-pointer whitespace-nowrap"
              >
                <MapPin className="w-4 h-4 text-[#D8A64A]" />
                <span>Find a Store</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* D. Brand Benefits Strip */}
      <section
        aria-label="Lone Star Market Value Pillars"
        className="bg-[#F7F3EB] border-b border-[#102A43]/10"
      >
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-5 sm:py-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-0 lg:divide-x lg:divide-[#102A43]/12">
            {/* Benefit 1 */}
            <div className="flex items-center gap-3.5 lg:px-6 first:lg:pl-0">
              <div className="w-11 h-11 rounded-full bg-[#102A43] text-white flex items-center justify-center shrink-0 shadow-xs">
                <Sprout className="w-5 h-5 text-[#D8A64A]" />
              </div>
              <div>
                <h2 className="font-display font-bold text-sm sm:text-[15px] text-[#102A43]">
                  Fresh &amp; Local
                </h2>
                <p className="text-xs text-[#242A30]/75 mt-0.5">
                  Support Texas farmers and producers.
                </p>
              </div>
            </div>

            {/* Benefit 2 */}
            <div className="flex items-center gap-3.5 lg:px-6">
              <div className="w-11 h-11 rounded-full bg-[#102A43] text-white flex items-center justify-center shrink-0 shadow-xs">
                <Truck className="w-5 h-5 text-[#D8A64A]" />
              </div>
              <div>
                <h2 className="font-display font-bold text-sm sm:text-[15px] text-[#102A43]">
                  Fast &amp; Easy Pickup
                </h2>
                <p className="text-xs text-[#242A30]/75 mt-0.5">
                  Order online and collect at your selected store.
                </p>
              </div>
            </div>

            {/* Benefit 3 */}
            <div className="flex items-center gap-3.5 lg:px-6">
              <div className="w-11 h-11 rounded-full bg-[#102A43] text-white flex items-center justify-center shrink-0 shadow-xs">
                <LoneStarSymbol className="w-5 h-5" variant="white" />
              </div>
              <div>
                <h2 className="font-display font-bold text-sm sm:text-[15px] text-[#102A43]">
                  Texas Made
                </h2>
                <p className="text-xs text-[#242A30]/75 mt-0.5">
                  Discover products from Texas producers.
                </p>
              </div>
            </div>

            {/* Benefit 4 */}
            <div className="flex items-center gap-3.5 lg:px-6 last:lg:pr-0">
              <div className="w-11 h-11 rounded-full bg-[#102A43] text-white flex items-center justify-center shrink-0 shadow-xs">
                <Tag className="w-5 h-5 text-[#D8A64A]" />
              </div>
              <div>
                <h2 className="font-display font-bold text-sm sm:text-[15px] text-[#102A43]">
                  Everyday Low Prices
                </h2>
                <p className="text-xs text-[#242A30]/75 mt-0.5">
                  Quality groceries at prices that make sense.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* E. Featured Shopping Categories (3 Large Photographic Promotional Cards) */}
      <section
        aria-label="Featured Departments"
        className="max-w-[1360px] mx-auto px-4 sm:px-6 pt-8 sm:pt-10 pb-6"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Card 1: Premium Meats & Fresh Cuts (5 cols on lg) */}
          <div
            onClick={() => onSelectCategory('meat-seafood')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && onSelectCategory('meat-seafood')}
            className="group relative lg:col-span-5 min-h-[300px] sm:min-h-[340px] rounded-xl overflow-hidden shadow-md cursor-pointer flex items-end bg-[#241411]"
          >
            <ResilientImage
              src="/assets/generated/texas_bbq_brisket.jpg"
              alt="Freshly sliced Texas post-oak smoked beef brisket"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              fallbackColor="#3A1914"
            />
            <div
              className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/15"
              aria-hidden="true"
            />
            <div className="relative z-10 p-6 sm:p-7 text-white w-full space-y-2.5">
              <p className="text-[11px] font-sans font-bold uppercase tracking-[0.2em] text-[#D8A64A]">
                TEXAS BBQ SEASON
              </p>
              <h3 className="font-display font-bold text-2xl sm:text-3xl leading-tight text-white">
                Premium Meats &amp; Fresh Cuts
              </h3>
              <p className="text-xs sm:text-sm text-white/90">
                Brisket, ribeye, sausages, and more.
              </p>
              <div className="pt-2">
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded border border-white/75 bg-black/35 group-hover:bg-[#C92332] group-hover:border-[#C92332] text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap">
                  <span>Shop Meat &amp; Seafood</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          </div>

          {/* Card 2: Farm Fresh Goodness (3.5 -> 3 or 4 cols on lg) */}
          <div
            onClick={() => onSelectCategory('fresh-food')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && onSelectCategory('fresh-food')}
            className="group relative lg:col-span-3 min-h-[300px] sm:min-h-[340px] rounded-xl overflow-hidden shadow-md cursor-pointer flex items-end bg-[#1F331E]"
          >
            <ResilientImage
              src="/assets/generated/farm_fresh_produce.jpg"
              alt="Vibrant Texas vine-ripened tomatoes, avocados, bell peppers, and leafy greens"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              fallbackColor="#2D4A2B"
            />
            <div
              className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/10"
              aria-hidden="true"
            />
            <div className="relative z-10 p-6 text-white w-full space-y-2.5">
              <p className="text-[11px] font-sans font-bold uppercase tracking-[0.2em] text-[#D8A64A]">
                FRESH PRODUCE
              </p>
              <h3 className="font-display font-bold text-2xl leading-tight text-white">
                Farm Fresh Goodness
              </h3>
              <p className="text-xs sm:text-sm text-white/90">
                Local favourites. Seasonal produce. Everyday freshness.
              </p>
              <div className="pt-2">
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded border border-white/75 bg-black/35 group-hover:bg-[#71866B] group-hover:border-[#71866B] text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap">
                  <span>Shop Produce</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          </div>

          {/* Card 3: Texas Made (4 cols on lg) */}
          <div
            onClick={() => onSelectCategory('texas-made')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && onSelectCategory('texas-made')}
            className="group relative lg:col-span-4 min-h-[300px] sm:min-h-[340px] rounded-xl overflow-hidden shadow-md cursor-pointer flex items-end bg-[#2B1D14]"
          >
            <ResilientImage
              src="/assets/generated/texas_made_artisanal.jpg"
              alt="Texas-made wildflower honey, oak-smoked barbecue sauce, Hill Country coffee, and spiced pecans"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              fallbackColor="#3B281E"
            />
            <div
              className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/15"
              aria-hidden="true"
            />
            <div className="relative z-10 p-6 sm:p-7 text-white w-full space-y-2.5">
              <p className="text-[11px] font-sans font-bold uppercase tracking-[0.2em] text-[#D8A64A]">
                TEXAS MADE
              </p>
              <h3 className="font-display font-bold text-2xl sm:text-3xl leading-tight text-white">
                Local Brands You&rsquo;ll Love
              </h3>
              <p className="text-xs sm:text-sm text-white/90">
                Discover products from Texas makers.
              </p>
              <div className="pt-2">
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded border border-white/75 bg-black/35 group-hover:bg-[#C92332] group-hover:border-[#C92332] text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap">
                  <span>Shop Texas Made</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* F. Grocery Category Grid (6 Cards matching reference image) */}
      <section
        aria-label="Shop by Grocery Category"
        className="max-w-[1360px] mx-auto px-4 sm:px-6 pb-10"
      >
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {SIX_GRID_CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => onSelectCategory(cat.id)}
                className={`group text-left rounded-lg overflow-hidden bg-white border transition-all duration-150 hover:-translate-y-0.5 shadow-xs hover:shadow-md flex flex-col cursor-pointer ${
                  isActive
                    ? 'border-[#C92332] ring-2 ring-[#C92332]/30'
                    : 'border-[#102A43]/12'
                }`}
              >
                <div className="h-24 sm:h-28 w-full overflow-hidden bg-[#102A43]/5 relative">
                  <ResilientImage
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="px-3.5 py-2.5 bg-[#F2EFE9] group-hover:bg-white flex items-center justify-between transition-colors">
                  <span className="font-sans font-semibold text-xs sm:text-sm text-[#102A43] truncate">
                    {cat.name}
                  </span>
                  <ChevronRight className="w-4 h-4 text-[#102A43]/60 group-hover:text-[#C92332] group-hover:translate-x-0.5 transition-all shrink-0" />
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}
