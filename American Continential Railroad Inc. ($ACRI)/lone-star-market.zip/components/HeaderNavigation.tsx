'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  MapPin,
  User,
  ShoppingCart,
  ChevronDown,
  X,
  Menu,
  Sparkles,
  Check,
  ArrowRight,
} from 'lucide-react';
import { BrandLogo, LoneStarSymbol } from './BrandLogo';
import {
  CATEGORIES,
  CategoryId,
  DemoStore,
  Product,
  SEARCH_SUGGESTIONS,
} from '@/lib/store-data';
import { ResilientImage } from './ResilientImage';

const ANNOUNCEMENTS = [
  'Fresh savings every week — Explore our Texas Ranch Butcher & Harvest specials.',
  'Order online. Pick up locally — Free curbside pickup on orders over $35 at all Texas demo stores.',
  'Discover products made in Texas — Supporting 180+ independent Lone Star farmers, ranchers, and makers.',
];

interface HeaderNavigationProps {
  selectedCategory: CategoryId;
  onSelectCategory: (cat: CategoryId, subQuery?: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSearchSubmit: (q: string) => void;
  matchingProducts: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, qty?: number) => void;
  cartCount: number;
  cartSubtotal: number;
  onOpenCart: () => void;
  selectedStore: DemoStore;
  onOpenStoreLocator: () => void;
  onOpenBrandIdentity: () => void;
  signedInUser: { name: string; email: string } | null;
  onOpenSignIn: () => void;
}

export function HeaderNavigation({
  selectedCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  matchingProducts,
  onSelectProduct,
  onAddToCart,
  cartCount,
  cartSubtotal,
  onOpenCart,
  selectedStore,
  onOpenStoreLocator,
  onOpenBrandIdentity,
  signedInUser,
  onOpenSignIn,
}: HeaderNavigationProps) {
  const [announcementIdx, setAnnouncementIdx] = useState(0);
  const [searchFocused, setSearchFocused] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<CategoryId | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setAnnouncementIdx((prev) => (prev + 1) % ANNOUNCEMENTS.length);
    }, 5500);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(e.target as Node)
      ) {
        setSearchFocused(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchFocused(false);
    onSearchSubmit(searchQuery);
  };

  return (
    <header className="sticky top-0 z-40 w-full shadow-md">
      {/* A. Slim Announcement Bar */}
      <div className="bg-[#081726] text-[#F7F3EB] border-b border-white/10 text-xs">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 h-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 truncate">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#D8A64A] shrink-0" />
            <p className="truncate font-medium text-[#F7F3EB]/90">
              {ANNOUNCEMENTS[announcementIdx]}
            </p>
          </div>
          <div className="hidden md:flex items-center gap-4 shrink-0 text-[11px] text-[#F7F3EB]/80">
            <button
              type="button"
              onClick={onOpenStoreLocator}
              className="hover:text-[#D8A64A] transition-colors whitespace-nowrap"
            >
              Pickup at: <strong className="text-white">{selectedStore.city}</strong> ({selectedStore.zip})
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={onOpenBrandIdentity}
              className="hover:text-[#D8A64A] transition-colors font-medium text-[#D8A64A] whitespace-nowrap"
            >
              Brand Identity System
            </button>
          </div>
        </div>
      </div>

      {/* B. Main Corporate Header (#102A43 Midnight Navy) */}
      <div className="bg-[#102A43] text-white">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-3 sm:py-3.5 flex items-center justify-between gap-3 sm:gap-6">
          {/* Left: Mobile Menu Button + Brand Logo */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 -ml-1 rounded-lg text-white/90 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <div className="hidden sm:block">
              <BrandLogo
                variant="header"
                onClick={() => {
                  onSelectCategory('all');
                  onSearchChange('');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            </div>
            <div className="sm:hidden">
              <BrandLogo
                variant="compact"
                onClick={() => {
                  onSelectCategory('all');
                  onSearchChange('');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            </div>
          </div>

          {/* Centre: Prominent Product Search Field */}
          <div ref={searchContainerRef} className="relative flex-1 max-w-2xl">
            <form onSubmit={handleFormSubmit} className="relative flex items-center">
              <Search className="w-4 h-4 text-[#242A30]/50 absolute left-3.5 pointer-events-none" />
              <input
                type="search"
                value={searchQuery}
                onFocus={() => setSearchFocused(true)}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search for products, recipes, or brands..."
                aria-label="Search for products, recipes, or brands"
                className="w-full h-10 sm:h-11 pl-10 pr-20 rounded-full bg-white text-[#242A30] placeholder:text-[#242A30]/55 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#D8A64A] shadow-inner"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  className="absolute right-12 p-1 text-[#242A30]/50 hover:text-[#242A30]"
                  aria-label="Clear search query"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                type="submit"
                className="absolute right-1.5 h-7 sm:h-8 px-3 rounded-full bg-[#102A43] hover:bg-[#1B3F63] text-white text-xs font-semibold transition-colors whitespace-nowrap"
              >
                Search
              </button>
            </form>

            {/* Autocomplete & Quick Search Suggestions Dropdown */}
            {searchFocused && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white text-[#242A30] rounded-xl shadow-2xl border border-[#102A43]/15 overflow-hidden z-50">
                <div className="p-3 bg-[#F7F3EB] border-b border-[#102A43]/10 flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#102A43]">
                    {searchQuery.trim()
                      ? `Matching items for "${searchQuery}" (${matchingProducts.length})`
                      : 'Popular Searches at Lone Star Market'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setSearchFocused(false)}
                    className="text-xs text-[#242A30]/60 hover:text-[#242A30]"
                  >
                    Close
                  </button>
                </div>

                {/* Quick suggestion tags */}
                {!searchQuery.trim() && (
                  <div className="p-3.5 border-b border-[#102A43]/10">
                    <div className="flex flex-wrap gap-2">
                      {SEARCH_SUGGESTIONS.map((term) => (
                        <button
                          key={term}
                          type="button"
                          onClick={() => {
                            onSearchChange(term);
                            onSearchSubmit(term);
                            setSearchFocused(false);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-[#F7F3EB] hover:bg-[#102A43] hover:text-white text-xs font-medium text-[#102A43] transition-colors flex items-center gap-1.5"
                        >
                          <Search className="w-3 h-3 opacity-60" />
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Matching Product Results */}
                <div className="max-h-72 overflow-y-auto divide-y divide-[#102A43]/10">
                  {(searchQuery.trim() ? matchingProducts : matchingProducts.slice(0, 4)).map(
                    (item) => {
                      const activePrice = item.promoPrice ?? item.price;
                      return (
                        <div
                          key={item.id}
                          className="p-3 hover:bg-[#F7F3EB]/60 flex items-center justify-between gap-3 transition-colors"
                        >
                          <button
                            type="button"
                            onClick={() => {
                              onSelectProduct(item);
                              setSearchFocused(false);
                            }}
                            className="flex items-center gap-3 text-left flex-1 min-w-0"
                          >
                            <div className="w-12 h-12 rounded-lg overflow-hidden bg-[#F7F3EB] shrink-0 border border-[#102A43]/10">
                              <ResilientImage
                                src={item.image}
                                alt={item.name}
                                className="w-full h-full object-cover"
                                fallbackColor={item.fallbackColor}
                              />
                            </div>
                            <div className="min-w-0">
                              <div className="text-sm font-semibold text-[#102A43] truncate">
                                {item.name}
                              </div>
                              <div className="text-xs text-[#242A30]/65 truncate">
                                {item.brand} · {item.unitSize}
                              </div>
                            </div>
                          </button>
                          <div className="flex items-center gap-3 shrink-0">
                            <div className="text-right font-mono">
                              <div className="text-sm font-bold text-[#C92332] tabular-nums">
                                ${activePrice.toFixed(2)}
                              </div>
                              <div className="text-[10px] text-[#242A30]/60 tabular-nums">
                                {item.unitPriceText}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => onAddToCart(item, 1)}
                              className="px-3 py-1.5 rounded-lg bg-[#C92332] hover:bg-[#A81B28] text-white text-xs font-semibold transition-colors whitespace-nowrap"
                            >
                              Add
                            </button>
                          </div>
                        </div>
                      );
                    }
                  )}

                  {searchQuery.trim() && matchingProducts.length === 0 && (
                    <div className="p-6 text-center">
                      <p className="text-sm font-semibold text-[#102A43]">
                        No exact matches for &ldquo;{searchQuery}&rdquo;
                      </p>
                      <p className="text-xs text-[#242A30]/70 mt-1">
                        Try searching for Milk, Ribeye steak, Fresh tomatoes, Eggs, or Barbecue sauce.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Right: Find a Store, Sign In, Shopping Cart */}
          <div className="flex items-center gap-2 sm:gap-5 shrink-0">
            <button
              type="button"
              onClick={onOpenStoreLocator}
              className="hidden md:inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-white/90 hover:text-[#D8A64A] transition-colors py-1.5 px-2 rounded-lg hover:bg-white/5 whitespace-nowrap"
            >
              <MapPin className="w-4 h-4 text-[#D8A64A] shrink-0" />
              <span>Find a Store</span>
            </button>

            <button
              type="button"
              onClick={onOpenSignIn}
              className="hidden sm:inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-white/90 hover:text-[#D8A64A] transition-colors py-1.5 px-2 rounded-lg hover:bg-white/5 whitespace-nowrap"
            >
              <User className="w-4 h-4 text-white/85 shrink-0" />
              <span>{signedInUser ? signedInUser.name.split(' ')[0] : 'Sign In'}</span>
            </button>

            <button
              type="button"
              onClick={onOpenCart}
              className="relative inline-flex items-center gap-2.5 py-2 px-3 sm:px-3.5 rounded-lg bg-white/10 hover:bg-white/15 text-white transition-colors whitespace-nowrap"
              aria-label={`Shopping Cart with ${cartCount} items`}
            >
              <div className="relative">
                <ShoppingCart className="w-5 h-5 text-white" />
                <span className="absolute -top-2 -right-2.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#C92332] text-white text-[11px] font-bold flex items-center justify-center tabular-nums shadow">
                  {cartCount}
                </span>
              </div>
              <span className="text-xs sm:text-sm font-semibold ml-1">Cart</span>
              {cartSubtotal > 0 && (
                <span className="hidden xl:inline font-mono text-xs text-[#D8A64A] tabular-nums">
                  (${cartSubtotal.toFixed(2)})
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Secondary Navigation Bar (9 Required Departments) */}
      <nav
        aria-label="Store Departments"
        className="hidden lg:block bg-[#0B1F33] text-white border-t border-white/10"
        onMouseLeave={() => setOpenDropdown(null)}
      >
        <div className="max-w-[1360px] mx-auto px-6 flex items-center justify-between h-11">
          <div className="flex items-center gap-1 xl:gap-2">
            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              const isWeekly = cat.id === 'weekly-deals';
              return (
                <div
                  key={cat.id}
                  className="relative"
                  onMouseEnter={() => setOpenDropdown(cat.id)}
                >
                  <button
                    type="button"
                    onClick={() => {
                      onSelectCategory(cat.id);
                      setOpenDropdown(null);
                    }}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs xl:text-[13px] font-medium transition-colors whitespace-nowrap ${
                      isSelected
                        ? 'bg-[#C92332] text-white font-semibold'
                        : isWeekly
                        ? 'text-[#D8A64A] hover:text-white hover:bg-white/10 font-semibold'
                        : 'text-white/90 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <span>{cat.name}</span>
                    {!isWeekly && <ChevronDown className="w-3.5 h-3.5 opacity-70" />}
                  </button>

                  {/* Department Dropdown */}
                  {openDropdown === cat.id && (
                    <div className="absolute left-0 top-full pt-1 w-64 z-50">
                      <div className="bg-white text-[#242A30] rounded-lg shadow-xl border border-[#102A43]/15 p-3">
                        <div className="pb-2 mb-2 border-b border-[#102A43]/10">
                          <div className="font-display font-bold text-sm text-[#102A43]">
                            {cat.name}
                          </div>
                          <p className="text-[11px] text-[#242A30]/70 leading-snug mt-0.5">
                            {cat.shortDesc}
                          </p>
                        </div>
                        <ul className="space-y-1">
                          {cat.subcategories.map((sub) => (
                            <li key={sub}>
                              <button
                                type="button"
                                onClick={() => {
                                  onSelectCategory(cat.id);
                                  setOpenDropdown(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded text-xs font-medium text-[#242A30] hover:bg-[#F7F3EB] hover:text-[#C92332] flex items-center justify-between transition-colors"
                              >
                                <span>{sub}</span>
                                <ArrowRight className="w-3 h-3 opacity-50" />
                              </button>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <button
            type="button"
            onClick={() => onSelectCategory('all')}
            className="text-xs text-white/75 hover:text-[#D8A64A] transition-colors whitespace-nowrap"
          >
            View All Departments
          </button>
        </div>
      </nav>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0B1F33] text-white border-t border-white/15 px-4 py-4 space-y-4 max-h-[75vh] overflow-y-auto">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenStoreLocator();
              }}
              className="flex items-center gap-2 text-xs font-medium text-[#D8A64A]"
            >
              <MapPin className="w-4 h-4" />
              <span>Store: {selectedStore.name}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSignIn();
              }}
              className="flex items-center gap-1.5 text-xs font-medium text-white/90"
            >
              <User className="w-4 h-4" />
              <span>{signedInUser ? signedInUser.name : 'Sign In'}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                onSelectCategory('all');
                setMobileMenuOpen(false);
              }}
              className={`px-3 py-2 rounded-lg text-left text-xs font-semibold ${
                selectedCategory === 'all'
                  ? 'bg-[#C92332] text-white'
                  : 'bg-white/5 text-white/90'
              }`}
            >
              All Groceries
            </button>
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  onSelectCategory(cat.id);
                  setMobileMenuOpen(false);
                }}
                className={`px-3 py-2 rounded-lg text-left text-xs font-semibold ${
                  selectedCategory === cat.id
                    ? 'bg-[#C92332] text-white'
                    : 'bg-white/5 text-white/90'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-white/10 flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBrandIdentity();
              }}
              className="text-xs font-semibold text-[#D8A64A]"
            >
              View Corporate Brand Identity System →
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
