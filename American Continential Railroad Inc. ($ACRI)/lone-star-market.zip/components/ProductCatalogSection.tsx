'use client';

import React from 'react';
import {
  Heart,
  Plus,
  Minus,
  ShoppingCart,
  ArrowRight,
  SlidersHorizontal,
  X,
  Info,
} from 'lucide-react';
import {
  CATEGORIES,
  CategoryId,
  Product,
  PRODUCTS,
} from '@/lib/store-data';
import { ResilientImage } from './ResilientImage';

interface ProductCardProps {
  product: Product;
  cartQuantity: number;
  isFavorite: boolean;
  onAddToCart: (product: Product, delta: number) => void;
  onToggleFavorite: (productId: string) => void;
  onQuickView: (product: Product) => void;
}

export function ProductCard({
  product,
  cartQuantity,
  isFavorite,
  onAddToCart,
  onToggleFavorite,
  onQuickView,
}: ProductCardProps) {
  const effectivePrice = product.promoPrice ?? product.price;
  const hasDiscount =
    typeof product.promoPrice === 'number' && product.promoPrice < product.price;

  return (
    <article className="group bg-white rounded-xl border border-[#102A43]/12 overflow-hidden flex flex-col justify-between transition-all duration-150 hover:-translate-y-0.5 hover:shadow-md">
      <div>
        {/* Product Image Container (4:3 aspect ratio) */}
        <div className="relative aspect-4/3 w-full bg-[#F2EFE9] overflow-hidden">
          <button
            type="button"
            onClick={() => onQuickView(product)}
            className="w-full h-full block text-left focus:outline-none"
            aria-label={`View details for ${product.name}`}
          >
            <ResilientImage
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              fallbackColor={product.fallbackColor}
            />
          </button>

          {/* Subtle single text tag on image corner if on weekly sale */}
          {hasDiscount && (
            <div className="absolute top-2.5 left-2.5 bg-[#C92332] text-white text-[11px] font-bold tracking-wide uppercase px-2.5 py-1 rounded shadow-xs">
              Weekly Deal · Save ${(product.price - effectivePrice).toFixed(2)}
            </div>
          )}

          {/* Favourite Button */}
          <button
            type="button"
            onClick={() => onToggleFavorite(product.id)}
            aria-label={
              isFavorite
                ? `Remove ${product.name} from favourites`
                : `Save ${product.name} to favourites`
            }
            className={`absolute top-2.5 right-2.5 w-8 h-8 rounded-full flex items-center justify-center transition-colors shadow-xs cursor-pointer ${
              isFavorite
                ? 'bg-[#C92332] text-white'
                : 'bg-white/90 text-[#102A43] hover:bg-white'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Product Details */}
        <div className="p-4 space-y-1.5">
          {/* Clean unboxed metadata with typographic separator */}
          <div className="flex items-center gap-1.5 text-[11px] text-[#242A30]/65 truncate">
            <span className="font-medium uppercase tracking-wider text-[#102A43]/80 truncate">
              {product.brand}
            </span>
            {product.isTexasMade && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-[#C92332] shrink-0">Texas Made</span>
              </>
            )}
          </div>

          <button
            type="button"
            onClick={() => onQuickView(product)}
            className="text-left block w-full"
          >
            <h3 className="font-sans font-semibold text-[15px] text-[#102A43] group-hover:text-[#C92332] transition-colors leading-snug line-clamp-2 min-h-[40px]">
              {product.name}
            </h3>
          </button>

          <div className="flex items-center gap-1.5 text-xs text-[#242A30]/70 font-mono tabular-nums">
            <span>{product.unitSize}</span>
            <span aria-hidden="true">·</span>
            <span>{product.unitPriceText}</span>
          </div>
        </div>
      </div>

      {/* Price & Add-to-Cart / Quantity Stepper */}
      <div className="px-4 pb-4 pt-2 border-t border-[#102A43]/8 flex items-center justify-between gap-3">
        <div className="font-mono tabular-nums">
          <div className="flex items-baseline gap-1.5">
            <span className="text-lg font-bold text-[#102A43]">
              ${effectivePrice.toFixed(2)}
            </span>
            {hasDiscount && (
              <span className="text-xs text-[#242A30]/50 line-through">
                ${product.price.toFixed(2)}
              </span>
            )}
          </div>
          <div className="text-[10px] text-[#71866B] font-sans font-medium">
            {product.stockStatus}
          </div>
        </div>

        {cartQuantity > 0 ? (
          <div className="inline-flex items-center rounded-lg bg-[#102A43] text-white p-0.5 shadow-xs">
            <button
              type="button"
              onClick={() => onAddToCart(product, -1)}
              className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-white/15 transition-colors cursor-pointer"
              aria-label={`Decrease quantity of ${product.name}`}
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="w-7 text-center font-mono text-xs font-bold tabular-nums">
              {cartQuantity}
            </span>
            <button
              type="button"
              onClick={() => onAddToCart(product, 1)}
              className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-white/15 transition-colors cursor-pointer"
              aria-label={`Increase quantity of ${product.name}`}
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => onAddToCart(product, 1)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#C92332] hover:bg-[#AD1B28] text-white text-xs font-semibold transition-colors shadow-xs cursor-pointer whitespace-nowrap"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>Add to Cart</span>
          </button>
        )}
      </div>
    </article>
  );
}

interface ProductCatalogSectionProps {
  selectedCategory: CategoryId;
  onSelectCategory: (cat: CategoryId) => void;
  searchQuery: string;
  onClearSearch: () => void;
  sortBy: 'featured' | 'price-asc' | 'price-desc' | 'name-asc';
  onSortChange: (sort: 'featured' | 'price-asc' | 'price-desc' | 'name-asc') => void;
  filteredProducts: Product[];
  cartQuantities: Record<string, number>;
  favorites: string[];
  onAddToCart: (product: Product, delta: number) => void;
  onToggleFavorite: (productId: string) => void;
  onQuickView: (product: Product) => void;
}

export function ProductCatalogSection({
  selectedCategory,
  onSelectCategory,
  searchQuery,
  onClearSearch,
  sortBy,
  onSortChange,
  filteredProducts,
  cartQuantities,
  favorites,
  onAddToCart,
  onToggleFavorite,
  onQuickView,
}: ProductCatalogSectionProps) {
  const weeklyDeals = PRODUCTS.filter((p) => p.isWeeklyDeal).slice(0, 4);

  const activeCategoryLabel =
    selectedCategory === 'all'
      ? 'Popular Everyday Essentials & Full Aisle Catalog'
      : CATEGORIES.find((c) => c.id === selectedCategory)?.name || 'Products';

  return (
    <div id="shopping-catalog" className="space-y-12 pb-12">
      {/* G. Weekly Deals ("THIS WEEK AT LONE STAR") */}
      {selectedCategory === 'all' && !searchQuery.trim() && (
        <section
          aria-labelledby="weekly-deals-heading"
          className="max-w-[1360px] mx-auto px-4 sm:px-6"
        >
          <div className="bg-white rounded-2xl border border-[#102A43]/12 p-6 sm:p-8 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[#102A43]/10">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C92332]">
                  <span>Weekly Circular</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#242A30]/60 font-normal">
                    Illustrative Demo Pricing
                  </span>
                </div>
                <h2
                  id="weekly-deals-heading"
                  className="font-display font-bold text-2xl sm:text-3xl text-[#102A43] mt-1 tracking-tight"
                >
                  THIS WEEK AT LONE STAR
                </h2>
                <p className="text-sm text-[#242A30]/80 mt-1">
                  Everyday essentials. Fresh savings. More value in every basket.
                </p>
              </div>

              <button
                type="button"
                onClick={() => onSelectCategory('weekly-deals')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#102A43] hover:bg-[#1B3F63] text-white text-xs sm:text-sm font-semibold transition-colors self-start md:self-auto cursor-pointer whitespace-nowrap"
              >
                <span>View All Weekly Deals</span>
                <ArrowRight className="w-4 h-4 text-[#D8A64A]" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 pt-6">
              {weeklyDeals.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  cartQuantity={cartQuantities[product.id] || 0}
                  isFavorite={favorites.includes(product.id)}
                  onAddToCart={onAddToCart}
                  onToggleFavorite={onToggleFavorite}
                  onQuickView={onQuickView}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* H. Popular Products & Interactive Department Catalog */}
      <section
        aria-labelledby="catalog-heading"
        className="max-w-[1360px] mx-auto px-4 sm:px-6 space-y-6"
      >
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#242A30]/70">
              <span className="font-semibold uppercase tracking-wider text-[#71866B]">
                Lone Star Market Groceries
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">
                Showing {filteredProducts.length}{' '}
                {filteredProducts.length === 1 ? 'product' : 'products'}
              </span>
              <span aria-hidden="true">·</span>
              <span>Sample Prototype Data</span>
            </div>
            <h2
              id="catalog-heading"
              className="font-display font-bold text-2xl sm:text-3xl text-[#102A43] mt-1 tracking-tight"
            >
              {searchQuery.trim()
                ? `Search Results for "${searchQuery}"`
                : activeCategoryLabel}
            </h2>
          </div>

          {/* Sort & Filter Controls */}
          <div className="flex flex-wrap items-center gap-3">
            {searchQuery.trim() && (
              <button
                type="button"
                onClick={onClearSearch}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#C92332]/10 text-[#C92332] text-xs font-semibold hover:bg-[#C92332]/20 transition-colors"
              >
                <span>Clear search: &ldquo;{searchQuery}&rdquo;</span>
                <X className="w-3.5 h-3.5" />
              </button>
            )}

            <div className="inline-flex items-center gap-2 bg-white px-3 py-2 rounded-lg border border-[#102A43]/15 text-xs">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#102A43]" />
              <label htmlFor="sort-select" className="font-medium text-[#242A30]/70">
                Sort by:
              </label>
              <select
                id="sort-select"
                value={sortBy}
                onChange={(e) =>
                  onSortChange(
                    e.target.value as 'featured' | 'price-asc' | 'price-desc' | 'name-asc'
                  )
                }
                className="font-semibold text-[#102A43] bg-transparent focus:outline-none cursor-pointer"
              >
                <option value="featured">Featured &amp; Popular</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="name-asc">Name: A to Z</option>
              </select>
            </div>
          </div>
        </div>

        {/* Interactive Department Filter Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 no-scrollbar">
          <button
            type="button"
            onClick={() => onSelectCategory('all')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#102A43] text-white shadow-xs'
                : 'bg-white text-[#242A30] hover:bg-[#102A43]/5 border border-[#102A43]/10'
            }`}
          >
            All Products ({PRODUCTS.length})
          </button>
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => onSelectCategory(cat.id)}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-[#C92332] text-white shadow-xs'
                    : 'bg-white text-[#242A30] hover:bg-[#102A43]/5 border border-[#102A43]/10'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>

        {/* Product Grid or Empty State */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                cartQuantity={cartQuantities[product.id] || 0}
                isFavorite={favorites.includes(product.id)}
                onAddToCart={onAddToCart}
                onToggleFavorite={onToggleFavorite}
                onQuickView={onQuickView}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-[#102A43]/12 p-10 text-center max-w-xl mx-auto my-6 space-y-4">
            <div className="w-12 h-12 rounded-full bg-[#F7F3EB] text-[#102A43] flex items-center justify-center mx-auto">
              <Info className="w-6 h-6 text-[#C92332]" />
            </div>
            <div className="space-y-1">
              <h3 className="font-display font-bold text-xl text-[#102A43]">
                No matching groceries found
              </h3>
              <p className="text-xs sm:text-sm text-[#242A30]/75">
                We couldn&rsquo;t find any products matching &ldquo;{searchQuery}&rdquo; in this
                department. Try clearing your filter or explore a suggested department below:
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  onClearSearch();
                  onSelectCategory('all');
                }}
                className="px-4 py-2 rounded-lg bg-[#C92332] text-white text-xs font-semibold hover:bg-[#AD1B28] transition-colors"
              >
                Show All Groceries
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearSearch();
                  onSelectCategory('meat-seafood');
                }}
                className="px-3.5 py-2 rounded-lg bg-[#F7F3EB] text-[#102A43] text-xs font-semibold hover:bg-[#102A43] hover:text-white transition-colors"
              >
                Meat &amp; Seafood
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearSearch();
                  onSelectCategory('fresh-food');
                }}
                className="px-3.5 py-2 rounded-lg bg-[#F7F3EB] text-[#102A43] text-xs font-semibold hover:bg-[#102A43] hover:text-white transition-colors"
              >
                Fresh Produce
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearSearch();
                  onSelectCategory('texas-made');
                }}
                className="px-3.5 py-2 rounded-lg bg-[#F7F3EB] text-[#102A43] text-xs font-semibold hover:bg-[#102A43] hover:text-white transition-colors"
              >
                Texas Made
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
