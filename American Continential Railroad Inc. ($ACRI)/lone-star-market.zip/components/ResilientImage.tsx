'use client';

import React, { useState } from 'react';
import { LoneStarSymbol } from './BrandLogo';

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackColor?: string;
  fallbackLabel?: string;
}

export function ResilientImage({
  src,
  alt,
  className = 'w-full h-full object-cover',
  fallbackColor = '#102A43',
  fallbackLabel,
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        className={`flex flex-col items-center justify-center p-4 text-center ${className}`}
        style={{ backgroundColor: fallbackColor }}
      >
        <LoneStarSymbol className="w-8 h-8 opacity-80 mb-2" variant="white" />
        <span className="font-display text-xs font-semibold text-white/90 line-clamp-2">
          {fallbackLabel || alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
