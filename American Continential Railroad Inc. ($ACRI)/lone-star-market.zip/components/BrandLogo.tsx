'use client';

import React from 'react';
import { X, Check, ShoppingBag, Store, Sparkles } from 'lucide-react';

interface StarProps {
  className?: string;
  variant?: 'color' | 'white' | 'navy' | 'red';
}

export function LoneStarSymbol({ className = 'w-10 h-10', variant = 'white' }: StarProps) {
  const mainFill =
    variant === 'white'
      ? '#FFFFFF'
      : variant === 'navy'
      ? '#102A43'
      : variant === 'red'
      ? '#C92332'
      : '#FFFFFF';

  const accentFill =
    variant === 'color'
      ? '#C92332'
      : variant === 'white'
      ? '#DCE6F2'
      : variant === 'navy'
      ? '#1E3A5F'
      : '#9E1925';

  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      {/* Outer 5-point Texas Star */}
      <path
        d="M32 3L39.6 22.8L60.8 24.1L44.4 37.6L49.8 58.2L32 46.8L14.2 58.2L19.6 37.6L3.2 24.1L24.4 22.8L32 3Z"
        fill={mainFill}
      />
      {/* Subtle heritage facet shading for architectural depth */}
      <path
        d="M32 3L39.6 22.8L32 33.5V3Z"
        fill={accentFill}
        fillOpacity={variant === 'color' ? '0.9' : '0.35'}
      />
      <path
        d="M60.8 24.1L44.4 37.6L32 33.5L60.8 24.1Z"
        fill={accentFill}
        fillOpacity={variant === 'color' ? '0.85' : '0.3'}
      />
      <path
        d="M49.8 58.2L32 46.8V33.5L49.8 58.2Z"
        fill={accentFill}
        fillOpacity={variant === 'color' ? '0.8' : '0.35'}
      />
      <path
        d="M14.2 58.2L19.6 37.6L32 33.5L14.2 58.2Z"
        fill={accentFill}
        fillOpacity={variant === 'color' ? '0.75' : '0.25'}
      />
      <path
        d="M3.2 24.1L24.4 22.8L32 33.5L3.2 24.1Z"
        fill={accentFill}
        fillOpacity={variant === 'color' ? '0.75' : '0.25'}
      />
    </svg>
  );
}

export function TexasStateSilhouette({ className = 'w-7 h-7' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path d="M22 6H35V19H46L50 22L57 23L58 34L54 41L44 48L39 59L33 57L27 45L19 44L14 37L6 30L14 29V19H22V6Z" />
    </svg>
  );
}

interface BrandLogoProps {
  variant?: 'header' | 'footer' | 'compact' | 'dark-on-light';
  onClick?: () => void;
}

export function BrandLogo({ variant = 'header', onClick }: BrandLogoProps) {
  if (variant === 'compact') {
    return (
      <button
        type="button"
        onClick={onClick}
        className="inline-flex items-center gap-2 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D8A64A] rounded"
      >
        <LoneStarSymbol className="w-8 h-8 shrink-0" variant="white" />
        <span className="font-display font-bold text-lg tracking-tight text-white whitespace-nowrap">
          Lone Star Market
        </span>
      </button>
    );
  }

  const isLightBg = variant === 'dark-on-light';
  const textColor = isLightBg ? 'text-[#102A43]' : 'text-white';
  const subColor = isLightBg ? 'text-[#C92332]' : 'text-[#DCE6F2]';

  return (
    <button
      type="button"
      onClick={onClick}
      className="group inline-flex items-center gap-3 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D8A64A] rounded py-0.5 shrink-0"
    >
      <LoneStarSymbol
        className={
          variant === 'footer'
            ? 'w-9 h-9 shrink-0 transition-transform duration-200 group-hover:scale-105'
            : 'w-10 h-10 sm:w-11 sm:h-11 shrink-0 transition-transform duration-200 group-hover:scale-105'
        }
        variant={isLightBg ? 'navy' : 'white'}
      />
      <div className="flex flex-col">
        <span
          className={`font-display font-bold tracking-tight leading-none whitespace-nowrap ${textColor} ${
            variant === 'footer' ? 'text-xl sm:text-2xl' : 'text-xl sm:text-[26px]'
          }`}
        >
          Lone Star Market
        </span>
        <span
          className={`font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase mt-1 whitespace-nowrap ${subColor}`}
        >
          TEXAS PROUD. EVERYDAY.
        </span>
      </div>
    </button>
  );
}

interface BrandIdentityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BrandIdentityModal({ isOpen, onClose }: BrandIdentityModalProps) {
  if (!isOpen) return null;

  const palette = [
    {
      name: 'Midnight Navy',
      hex: '#102A43',
      role: 'Primary corporate color — navigation, footer, editorial headers',
      textDark: false,
    },
    {
      name: 'Texas Red',
      hex: '#C92332',
      role: 'Primary accent — primary CTAs, weekly savings, star facet',
      textDark: false,
    },
    {
      name: 'Warm Cream',
      hex: '#F7F3EB',
      role: 'Principal canvas — warm editorial background surface',
      textDark: true,
    },
    {
      name: 'Prairie Gold',
      hex: '#D8A64A',
      role: 'Secondary accent — Texas sunshine & local maker highlights',
      textDark: true,
    },
    {
      name: 'Fresh Sage',
      hex: '#71866B',
      role: 'Produce & natural — farm freshness & sustainability markers',
      textDark: false,
    },
    {
      name: 'Charcoal',
      hex: '#242A30',
      role: 'Body copy — product specifications & high-contrast legibility',
      textDark: false,
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="brand-system-title"
    >
      <div className="relative w-full max-w-5xl bg-[#F7F3EB] text-[#242A30] rounded-xl shadow-2xl border border-[#102A43]/15 max-h-[90vh] overflow-y-auto">
        {/* Sticky Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-[#102A43] text-white border-b border-white/10">
          <div className="flex items-center gap-3">
            <LoneStarSymbol className="w-7 h-7" variant="color" />
            <div>
              <h2 id="brand-system-title" className="font-display text-lg font-bold">
                Lone Star Market — Corporate Visual Identity System
              </h2>
              <p className="text-xs text-white/75">
                Complete Brand Architecture · Logo System (1–7) · Color Tokens · Typography
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close Brand Identity System"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-8 space-y-10">
          {/* Positioning & Personality */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 bg-white p-6 rounded-lg border border-[#102A43]/10">
            <div className="lg:col-span-2 space-y-2">
              <p className="text-xs font-semibold uppercase tracking-widest text-[#C92332]">
                Brand Positioning
              </p>
              <h3 className="font-display text-2xl font-bold text-[#102A43]">
                Texas Proud. Everyday.
              </h3>
              <p className="text-sm text-[#242A30]/85 leading-relaxed">
                Lone Star Market combines the warmth and character of an independent Texas grocer
                with the operational excellence of a modern regional supermarket chain—celebrating
                Texas ranchers, growers, and makers without cliché caricatures.
              </p>
            </div>
            <div className="bg-[#F7F3EB] p-4 rounded-lg border border-[#102A43]/10">
              <p className="text-xs font-semibold uppercase tracking-wider text-[#102A43] mb-2">
                Five Core Attributes
              </p>
              <ul className="space-y-1.5 text-xs font-medium text-[#242A30]">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C92332]" /> 1. Dependable
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C92332]" /> 2. Proudly Texan
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C92332]" /> 3. Contemporary
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C92332]" /> 4. Good Value
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C92332]" /> 5. Welcoming
                </li>
              </ul>
            </div>
          </div>

          {/* 7-Part Logo System */}
          <div>
            <h3 className="font-display text-xl font-bold text-[#102A43] mb-4">
              Official 7-Component Logo System & Retail Applications
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* 1. Primary Horizontal Logo */}
              <div className="bg-[#102A43] p-5 rounded-lg text-white flex flex-col justify-between min-h-[150px] lg:col-span-2">
                <span className="text-[11px] font-mono text-white/60">
                  01 · Primary Horizontal Corporate Logo
                </span>
                <div className="py-4 flex items-center justify-center">
                  <BrandLogo variant="header" />
                </div>
                <span className="text-[11px] text-white/60">
                  Used on primary desktop headers, fleet livery, and corporate communications
                </span>
              </div>

              {/* 2. Compact Star Symbol */}
              <div className="bg-white p-5 rounded-lg border border-[#102A43]/10 flex flex-col justify-between min-h-[150px]">
                <span className="text-[11px] font-mono text-[#242A30]/60">
                  02 · Compact Star Symbol
                </span>
                <div className="py-3 flex items-center justify-center gap-6">
                  <div className="p-3 rounded-lg bg-[#102A43]">
                    <LoneStarSymbol className="w-10 h-10" variant="color" />
                  </div>
                  <div className="p-3 rounded-lg bg-[#F7F3EB] border border-[#102A43]/15">
                    <LoneStarSymbol className="w-10 h-10" variant="red" />
                  </div>
                </div>
                <span className="text-[11px] text-[#242A30]/70">
                  Faceted 5-point Texas star mark
                </span>
              </div>

              {/* 3. Square Social-Media Avatar */}
              <div className="bg-white p-5 rounded-lg border border-[#102A43]/10 flex flex-col justify-between">
                <span className="text-[11px] font-mono text-[#242A30]/60">
                  03 · Square Social Avatar
                </span>
                <div className="py-4 flex items-center justify-center">
                  <div className="w-20 h-20 rounded-2xl bg-[#102A43] border-2 border-[#D8A64A] shadow-md flex flex-col items-center justify-center p-2">
                    <LoneStarSymbol className="w-9 h-9" variant="color" />
                    <span className="font-display text-[9px] font-bold text-white tracking-wider mt-1">
                      LONE STAR
                    </span>
                  </div>
                </div>
                <span className="text-[11px] text-[#242A30]/70">
                  App icon & social profile badge (1:1)
                </span>
              </div>

              {/* 4. Monochrome Logo */}
              <div className="bg-white p-5 rounded-lg border border-[#102A43]/10 flex flex-col justify-between">
                <span className="text-[11px] font-mono text-[#242A30]/60">
                  04 · Monochrome Stamp Logo
                </span>
                <div className="py-4 flex items-center justify-center">
                  <div className="inline-flex items-center gap-2.5 text-[#242A30]">
                    <LoneStarSymbol className="w-8 h-8" variant="navy" />
                    <div>
                      <div className="font-display font-bold text-lg leading-none text-[#102A43]">
                        Lone Star Market
                      </div>
                      <div className="text-[9px] font-bold tracking-[0.2em] text-[#102A43]/80 mt-0.5">
                        TEXAS PROUD. EVERYDAY.
                      </div>
                    </div>
                  </div>
                </div>
                <span className="text-[11px] text-[#242A30]/70">
                  Single-ink receipts, kraft paper & embossing
                </span>
              </div>

              {/* 5. Small Mobile Navigation Logo */}
              <div className="bg-[#102A43] p-5 rounded-lg text-white flex flex-col justify-between">
                <span className="text-[11px] font-mono text-white/60">
                  05 · Small Mobile Navigation Logo
                </span>
                <div className="py-4 flex items-center justify-center">
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded bg-[#0B1F33] border border-white/15">
                    <LoneStarSymbol className="w-6 h-6" variant="white" />
                    <span className="font-display font-bold text-sm text-white">
                      Lone Star Market
                    </span>
                  </div>
                </div>
                <span className="text-[11px] text-white/60">
                  High-legibility compact lockup for viewports &lt; 640px
                </span>
              </div>

              {/* 6. Store Signage Application */}
              <div className="bg-[#242A30] p-5 rounded-lg text-white flex flex-col justify-between md:col-span-2">
                <span className="text-[11px] font-mono text-white/60 flex items-center gap-1.5">
                  <Store className="w-3.5 h-3.5 text-[#D8A64A]" /> 06 · Architectural Storefront Signage Application
                </span>
                <div className="my-3 py-5 px-6 rounded bg-gradient-to-b from-[#1A2026] to-[#101418] border-y-4 border-[#D8A64A]/60 flex flex-col items-center justify-center shadow-inner">
                  <LoneStarSymbol className="w-11 h-11 drop-shadow-[0_0_12px_rgba(201,35,50,0.6)]" variant="color" />
                  <div className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-white mt-1 drop-shadow">
                    Lone Star Market
                  </div>
                  <div className="text-[10px] tracking-[0.28em] uppercase text-[#F7F3EB]/90 mt-1">
                    TEXAS PROUD. EVERYDAY.
                  </div>
                </div>
                <span className="text-[11px] text-white/60">
                  Internally illuminated channel-letter signage on Texas limestone & dark bronze fascia
                </span>
              </div>

              {/* 7. Shopping Bag & Private-Label Packaging */}
              <div className="bg-[#EDE5D5] p-5 rounded-lg border border-[#102A43]/15 flex flex-col justify-between">
                <span className="text-[11px] font-mono text-[#242A30]/70 flex items-center gap-1.5">
                  <ShoppingBag className="w-3.5 h-3.5 text-[#C92332]" /> 07 · Kraft Bag & Packaging
                </span>
                <div className="my-3 mx-auto w-36 h-40 bg-[#D9C3A3] rounded-b-md border-2 border-[#B39874] shadow-md flex flex-col items-center justify-center p-3 relative">
                  <div className="w-12 h-3 border-2 border-[#8F7553] rounded-t-full -mt-6 mb-3" />
                  <LoneStarSymbol className="w-8 h-8" variant="red" />
                  <span className="font-display font-bold text-xs text-[#102A43] mt-1 text-center leading-tight">
                    Lone Star Market
                  </span>
                  <span className="text-[8px] font-semibold tracking-widest text-[#C92332] uppercase mt-0.5">
                    LOCAL · FRESH · TEXAS
                  </span>
                  <div className="w-full h-1.5 bg-[#102A43] absolute bottom-0 inset-x-0 rounded-b" />
                </div>
                <span className="text-[11px] text-[#242A30]/70">
                  100% recycled unbleached kraft grocery carrier & private-label seal
                </span>
              </div>
            </div>
          </div>

          {/* Color Palette */}
          <div>
            <h3 className="font-display text-xl font-bold text-[#102A43] mb-4">
              Official Corporate Color Palette
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {palette.map((swatch) => (
                <div
                  key={swatch.hex}
                  className="bg-white rounded-lg border border-[#102A43]/10 overflow-hidden shadow-xs"
                >
                  <div
                    className="h-20 p-3 flex items-end justify-between"
                    style={{ backgroundColor: swatch.hex }}
                  >
                    <span
                      className={`font-mono text-xs font-semibold ${
                        swatch.textDark ? 'text-[#102A43]' : 'text-white'
                      }`}
                    >
                      {swatch.hex}
                    </span>
                  </div>
                  <div className="p-3">
                    <div className="font-semibold text-xs text-[#102A43]">{swatch.name}</div>
                    <p className="text-[11px] text-[#242A30]/70 mt-1 leading-snug">{swatch.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 3-Level Typography System */}
          <div className="bg-white p-6 rounded-lg border border-[#102A43]/10">
            <h3 className="font-display text-xl font-bold text-[#102A43] mb-4">
              Three-Level Typographic System
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-1.5">
                <span className="text-xs font-mono text-[#C92332] font-semibold">
                  Level 1 · Display Typography (Playfair Display)
                </span>
                <p className="font-display text-2xl font-bold text-[#102A43]">
                  Good Food. Great Value. Texas Proud.
                </p>
                <p className="text-xs text-[#242A30]/70">
                  Distinctive American editorial serif used for hero statements, department banners,
                  and brand storytelling.
                </p>
              </div>
              <div className="space-y-1.5">
                <span className="text-xs font-mono text-[#C92332] font-semibold">
                  Level 2 · Interface Typography (Plus Jakarta Sans)
                </span>
                <p className="font-sans text-base font-semibold text-[#242A30]">
                  Texas Beef Ribeye Steak — $12.99 / lb
                </p>
                <p className="text-xs text-[#242A30]/70">
                  Clean, high-legibility sans-serif for navigation, aisle filters, product cards,
                  and interactive controls.
                </p>
              </div>
              <div className="space-y-1.5">
                <span className="text-xs font-mono text-[#C92332] font-semibold">
                  Level 3 · Utility Typography (JetBrains Mono / Tabular)
                </span>
                <p className="font-mono text-xs font-medium text-[#242A30] bg-[#F7F3EB] p-2 rounded">
                  UNIT: $0.62/oz · 290 KCAL · SKU #TX-8841
                </p>
                <p className="text-xs text-[#242A30]/70">
                  Compact tabular typography for unit pricing, nutrition facts, stock indicators,
                  and curbside slot codes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
