'use client';

import React, { useState } from 'react';
import {
  MapPin,
  Clock,
  Phone,
  Check,
  Search,
  ArrowRight,
  Navigation,
  Sparkles,
  Store,
} from 'lucide-react';
import { CategoryId, DEMO_STORES, DemoStore } from '@/lib/store-data';
import { TexasStateSilhouette, LoneStarSymbol } from './BrandLogo';
import { ResilientImage } from './ResilientImage';

interface TexasMadeAndStoreLocatorProps {
  selectedStore: DemoStore;
  onSelectStore: (store: DemoStore) => void;
  onSelectCategory: (cat: CategoryId) => void;
}

export function TexasMadeAndStoreLocator({
  selectedStore,
  onSelectStore,
  onSelectCategory,
}: TexasMadeAndStoreLocatorProps) {
  const [storeQuery, setStoreQuery] = useState('');
  const [selectedMarket, setSelectedMarket] = useState<string>('All Markets');
  const [directionsStore, setDirectionsStore] = useState<DemoStore | null>(null);

  const markets = ['All Markets', 'Austin', 'Dallas–Fort Worth', 'Houston', 'San Antonio'];

  const matchingStores = DEMO_STORES.filter((store) => {
    const matchesMarket =
      selectedMarket === 'All Markets' || store.market === selectedMarket;
    if (!storeQuery.trim()) return matchesMarket;
    const q = storeQuery.toLowerCase();
    return (
      matchesMarket &&
      (store.name.toLowerCase().includes(q) ||
        store.city.toLowerCase().includes(q) ||
        store.zip.includes(q) ||
        store.address.toLowerCase().includes(q) ||
        store.market.toLowerCase().includes(q))
    );
  });

  return (
    <div>
      {/* I. Texas-Made Feature Banner (Matching reference image panoramic sunset banner) */}
      <section aria-label="Rooted in Texas Feature" className="relative w-full overflow-hidden">
        <div className="relative min-h-[260px] sm:min-h-[300px] flex items-center bg-[#102A43]">
          <ResilientImage
            src="/assets/generated/texas_bluebonnet_landscape.jpg"
            alt="Golden sunset over Texas Hill Country bluebonnet fields and oak trees"
            className="absolute inset-0 w-full h-full object-cover object-center"
            fallbackColor="#102A43"
          />
          {/* Warm evening contrast scrim */}
          <div
            className="absolute inset-0 bg-gradient-to-r from-[#102A43]/90 via-[#102A43]/70 to-[#102A43]/75"
            aria-hidden="true"
          />

          <div className="relative z-10 w-full max-w-[1360px] mx-auto px-4 sm:px-6 py-10 sm:py-14">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
              {/* Left: Editorial Headline */}
              <div className="lg:col-span-4 lg:border-r lg:border-[#D8A64A]/40 lg:pr-6">
                <p className="text-[11px] font-sans font-bold uppercase tracking-[0.22em] text-[#D8A64A] mb-1.5">
                  LOCAL PRODUCERS &amp; RANCHERS
                </p>
                <h2 className="font-display italic font-bold text-3xl sm:text-4xl text-white leading-tight drop-shadow-xs">
                  Rooted in Texas.
                  <br />
                  Built for You.
                </h2>
              </div>

              {/* Centre: Supporting Story */}
              <div className="lg:col-span-5 text-white/95 space-y-2">
                <p className="text-sm sm:text-[15px] leading-relaxed font-medium">
                  From independent makers to hardworking family businesses, discover products that
                  bring the best of Texas to your table.
                </p>
                <p className="text-xs sm:text-sm text-white/80 leading-relaxed">
                  At Lone Star Market, we&rsquo;re more than a supermarket — we&rsquo;re your
                  neighbour, your local store, and your Texas grocery destination.
                </p>
              </div>

              {/* Right: Action Buttons & Texas State Emblem */}
              <div className="lg:col-span-3 flex flex-wrap lg:flex-col xl:flex-row items-center lg:items-end xl:items-center justify-start lg:justify-end gap-3">
                <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      onSelectCategory('texas-made');
                      const el = document.getElementById('shopping-catalog');
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#D8A64A] hover:bg-[#C69235] text-[#102A43] font-bold text-xs sm:text-sm transition-colors shadow-md cursor-pointer whitespace-nowrap"
                  >
                    <span>Discover Texas Made</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <a
                    href="#store-locator"
                    className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg border border-white/80 bg-black/25 hover:bg-white/15 text-white font-semibold text-xs sm:text-sm transition-colors whitespace-nowrap"
                  >
                    <span>Find Your Nearest Store</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
                <TexasStateSilhouette className="w-10 h-10 text-white/90 shrink-0 hidden sm:block" />
              </div>
            </div>
          </div>
        </div>

        {/* Gold & Cream Producer Highlight Strip */}
        <div className="bg-[#EFE9DA] border-b border-[#D8A64A]/35">
          <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4 text-xs text-[#102A43]">
            <div className="flex items-center gap-2 font-semibold">
              <span className="inline-block w-2 h-2 rounded-full bg-[#D8A64A]" />
              <span>Proudly Partnering Across the Lone Star State:</span>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[#242A30]/80">
              <span>Hill Country Apiaries (Fredericksburg)</span>
              <span aria-hidden="true">·</span>
              <span>Rio Grande Valley Citrus &amp; Produce</span>
              <span aria-hidden="true">·</span>
              <span>San Angelo Cattle Ranchers</span>
              <span aria-hidden="true">·</span>
              <span>Austin Small-Batch Coffee Roasters</span>
            </div>
          </div>
        </div>
      </section>

      {/* J. Store Locator Section */}
      <section
        id="store-locator"
        aria-labelledby="store-locator-heading"
        className="max-w-[1360px] mx-auto px-4 sm:px-6 py-12 sm:py-16"
      >
        <div className="bg-white rounded-2xl border border-[#102A43]/12 p-6 sm:p-8 lg:p-10 shadow-xs space-y-8">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-[#102A43]/10">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C92332]">
                <MapPin className="w-3.5 h-3.5" />
                <span>Texas Store Directory · Illustrative Demo Locations</span>
              </div>
              <h2
                id="store-locator-heading"
                className="font-display font-bold text-2xl sm:text-3xl text-[#102A43]"
              >
                Find Your Local Lone Star Market
              </h2>
              <p className="text-sm text-[#242A30]/75 max-w-2xl">
                Select a demonstration store across Austin, Dallas–Fort Worth, Houston, or San
                Antonio to view curbside pickup hours, in-store smokehouse counters, and local
                services.
              </p>
            </div>

            {/* Currently Selected Store Callout */}
            <div className="bg-[#F7F3EB] px-4 py-3 rounded-xl border border-[#102A43]/15 flex items-center gap-3 shrink-0">
              <div className="w-9 h-9 rounded-lg bg-[#102A43] text-white flex items-center justify-center shrink-0">
                <Store className="w-4 h-4 text-[#D8A64A]" />
              </div>
              <div>
                <div className="text-[11px] font-semibold uppercase tracking-wider text-[#71866B]">
                  Your Selected Store
                </div>
                <div className="text-sm font-bold text-[#102A43]">{selectedStore.name}</div>
                <div className="text-[11px] text-[#242A30]/70 font-mono">
                  {selectedStore.pickupWait}
                </div>
              </div>
            </div>
          </div>

          {/* Search & Market Filter Controls */}
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-[#242A30]/50 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="search"
                value={storeQuery}
                onChange={(e) => setStoreQuery(e.target.value)}
                placeholder="Search by Texas city or ZIP code (e.g. Austin, Dallas, 78704)..."
                aria-label="Search store by city or ZIP code"
                className="w-full h-11 pl-10 pr-4 rounded-lg bg-[#F7F3EB] border border-[#102A43]/15 text-sm text-[#242A30] placeholder:text-[#242A30]/50 focus:outline-none focus:ring-2 focus:ring-[#102A43]"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {markets.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setSelectedMarket(m)}
                  className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    selectedMarket === m
                      ? 'bg-[#102A43] text-white'
                      : 'bg-[#F7F3EB] text-[#242A30] hover:bg-[#102A43]/10'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* Store Results Grid */}
          {matchingStores.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {matchingStores.map((store) => {
                const isSelected = store.id === selectedStore.id;
                return (
                  <div
                    key={store.id}
                    className={`rounded-xl p-5 border transition-all flex flex-col justify-between gap-4 ${
                      isSelected
                        ? 'bg-[#F7F3EB]/70 border-[#C92332] ring-2 ring-[#C92332]/20'
                        : 'bg-white border-[#102A43]/12 hover:border-[#102A43]/30'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C92332]">
                            {store.market} Market
                          </span>
                          <h3 className="font-display font-bold text-lg text-[#102A43] leading-snug">
                            {store.name}
                          </h3>
                        </div>
                        {isSelected && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#71866B] shrink-0">
                            <Check className="w-3.5 h-3.5" /> Active
                          </span>
                        )}
                      </div>

                      <div className="space-y-1.5 text-xs text-[#242A30]/80">
                        <p className="flex items-start gap-2">
                          <MapPin className="w-3.5 h-3.5 text-[#102A43] shrink-0 mt-0.5" />
                          <span>{store.address}</span>
                        </p>
                        <p className="flex items-center gap-2">
                          <Clock className="w-3.5 h-3.5 text-[#102A43] shrink-0" />
                          <span>{store.hours}</span>
                        </p>
                        <p className="flex items-center gap-2 font-mono text-[11px] text-[#71866B] font-medium">
                          <span>{store.pickupWait}</span>
                        </p>
                      </div>

                      <p className="text-xs text-[#242A30]/70 italic bg-[#F7F3EB] p-2.5 rounded-lg">
                        {store.featuredNote}
                      </p>

                      <div className="text-[11px] text-[#242A30]/75">
                        <strong className="text-[#102A43]">Services: </strong>
                        {store.services.join(' · ')}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-[#102A43]/10 flex items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => onSelectStore(store)}
                        className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                          isSelected
                            ? 'bg-[#102A43] text-white'
                            : 'bg-[#C92332] hover:bg-[#AD1B28] text-white'
                        }`}
                      >
                        {isSelected ? 'Selected for Pickup' : 'Set as My Store'}
                      </button>

                      <button
                        type="button"
                        onClick={() => setDirectionsStore(store)}
                        className="py-2 px-3 rounded-lg border border-[#102A43]/20 hover:bg-[#F7F3EB] text-[#102A43] text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <Navigation className="w-3.5 h-3.5" />
                        <span>Directions</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center bg-[#F7F3EB] rounded-xl">
              <p className="text-sm font-semibold text-[#102A43]">
                No demo stores match &ldquo;{storeQuery}&rdquo;
              </p>
              <p className="text-xs text-[#242A30]/70 mt-1">
                Try searching for Austin, Dallas, Fort Worth, Houston, or San Antonio.
              </p>
              <button
                type="button"
                onClick={() => {
                  setStoreQuery('');
                  setSelectedMarket('All Markets');
                }}
                className="mt-3 px-4 py-2 rounded-lg bg-[#102A43] text-white text-xs font-semibold"
              >
                Show All Texas Demo Locations
              </button>
            </div>
          )}

          {/* Directions & Store Details Notice Modal */}
          {directionsStore && (
            <div className="p-5 rounded-xl bg-[#102A43] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-semibold uppercase tracking-wider text-[#D8A64A]">
                  Demo Store Directions &amp; Curbside Arrival Guide
                </div>
                <div className="font-display font-bold text-lg">{directionsStore.name}</div>
                <p className="text-xs text-white/85">
                  {directionsStore.address} · Phone: {directionsStore.phone}
                </p>
                <p className="text-xs text-white/70">
                  Note: This is a fictional demonstration store location created for the Lone Star
                  Market digital retail prototype.
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    onSelectStore(directionsStore);
                    setDirectionsStore(null);
                  }}
                  className="px-4 py-2 rounded-lg bg-[#C92332] hover:bg-[#AD1B28] text-white text-xs font-semibold whitespace-nowrap"
                >
                  Select Store for Pickup
                </button>
                <button
                  type="button"
                  onClick={() => setDirectionsStore(null)}
                  className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
                >
                  Dismiss
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
