export type CategoryId =
  | 'all'
  | 'groceries'
  | 'fresh-food'
  | 'meat-seafood'
  | 'bakery'
  | 'dairy-eggs'
  | 'household'
  | 'health-beauty'
  | 'texas-made'
  | 'weekly-deals';

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: CategoryId;
  secondaryCategories?: CategoryId[];
  unitSize: string;
  unitPriceText: string;
  price: number;
  promoPrice?: number;
  image: string;
  fallbackColor: string;
  origin: string;
  description: string;
  nutritionSummary: string;
  stockStatus: 'In Stock' | 'Fresh Batch Today' | 'Limited Local Harvest';
  isTexasMade?: boolean;
  isWeeklyDeal?: boolean;
  isPopular?: boolean;
}

export interface DemoStore {
  id: string;
  name: string;
  market: 'Austin' | 'Dallas–Fort Worth' | 'Houston' | 'San Antonio' | 'Hill Country';
  city: string;
  zip: string;
  address: string;
  hours: string;
  phone: string;
  pickupWait: string;
  services: string[];
  featuredNote: string;
}

export interface CategoryInfo {
  id: CategoryId;
  name: string;
  shortDesc: string;
  image: string;
  subcategories: string[];
}

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'groceries',
    name: 'Groceries',
    shortDesc: 'Pantry staples, Texas coffee, honey, sauces & everyday essentials',
    image: '/assets/generated/cat_groceries.jpg',
    subcategories: ['Pantry Staples', 'Coffee & Tea', 'BBQ Sauces & Rubs', 'Local Honey & Jams', 'Snacks & Nuts'],
  },
  {
    id: 'fresh-food',
    name: 'Fresh Food',
    shortDesc: 'Vine-ripened produce, organic greens & seasonal Texas harvests',
    image: '/assets/generated/farm_fresh_produce.jpg',
    subcategories: ['Tomatoes & Peppers', 'Avocados & Citrus', 'Leafy Greens & Herbs', 'Root Vegetables', 'Cut Fruit'],
  },
  {
    id: 'meat-seafood',
    name: 'Meat & Seafood',
    shortDesc: 'Prime Texas ranch beef, post-oak smoked brisket & Gulf seafood',
    image: '/assets/generated/cat_ribeye_steak.jpg',
    subcategories: ['Prime & Choice Steaks', 'Smoked BBQ & Brisket', 'Craft Sausages', 'Pasture Poultry', 'Gulf Coast Seafood'],
  },
  {
    id: 'bakery',
    name: 'Bakery',
    shortDesc: 'Scratch-baked sourdough loaves, butter croissants & warm rolls',
    image: '/assets/generated/cat_bakery_rolls.jpg',
    subcategories: ['Artisan Sourdough', 'Dinner Rolls', 'Croissants & Pastries', 'Pecan Pies & Tarts', 'Sandwich Loaves'],
  },
  {
    id: 'dairy-eggs',
    name: 'Dairy & Eggs',
    shortDesc: 'Creamery whole milk, pasture-raised Grade A eggs & aged cheeses',
    image: '/assets/generated/cat_dairy_eggs.jpg',
    subcategories: ['Farmstead Milk', 'Pasture-Raised Eggs', 'Artisan Cheddar & Cheese', 'Cultured Butter', 'Yogurt & Cream'],
  },
  {
    id: 'household',
    name: 'Household',
    shortDesc: 'Dependable home cleaning supplies, paper goods & kitchenware',
    image: '/assets/generated/cat_household.jpg',
    subcategories: ['Surface Cleaners', 'Dish & Laundry Care', 'Paper Towels & Tissue', 'Food Storage', 'Charcoal & Post Oak Wood'],
  },
  {
    id: 'health-beauty',
    name: 'Health & Beauty',
    shortDesc: 'Botanical bath care, everyday wellness & natural grooming',
    image: '/assets/generated/cat_health_beauty.jpg',
    subcategories: ['Botanical Body Wash', 'Hair Care', 'Mineral Sun Care', 'Hand Soaps & Lotions', 'Everyday Wellness'],
  },
  {
    id: 'texas-made',
    name: 'Texas Made',
    shortDesc: 'Crafted by independent Texas makers, ranchers & family farms',
    image: '/assets/generated/texas_made_artisanal.jpg',
    subcategories: ['Hill Country Honey', 'Austin Coffee Roasters', 'Smokehouse Sauces', 'San Antonio Pecans', 'Ranch Butcher Cuts'],
  },
  {
    id: 'weekly-deals',
    name: 'Weekly Deals',
    shortDesc: 'Fresh savings every week across meat, produce, bakery & pantry',
    image: '/assets/generated/texas_bbq_brisket.jpg',
    subcategories: ['Butcher Specials', 'Harvest Deals', 'Pantry Multi-Buys', 'Bakery Bundles'],
  },
];

export const SIX_GRID_CATEGORIES: CategoryInfo[] = [
  CATEGORIES[0], // Groceries
  CATEGORIES[2], // Meat & Seafood
  CATEGORIES[3], // Bakery
  CATEGORIES[4], // Dairy & Eggs
  CATEGORIES[5], // Household
  CATEGORIES[6], // Health & Beauty
];

export const PRODUCTS: Product[] = [
  {
    id: 'prod-ribeye',
    name: 'Texas Beef Ribeye Steak',
    brand: 'Lone Star Ranch Butcher',
    category: 'meat-seafood',
    secondaryCategories: ['texas-made', 'weekly-deals'],
    unitSize: '1 lb (Avg. 16 oz cut)',
    unitPriceText: '$12.99 / lb',
    price: 15.99,
    promoPrice: 12.99,
    image: '/assets/generated/cat_ribeye_steak.jpg',
    fallbackColor: '#4A1D1F',
    origin: 'San Angelo, TX Ranch Partners',
    description:
      'Hand-trimmed, well-marbled Texas beef ribeye aged 21 days for tenderness and rich steakhouse flavor.',
    nutritionSummary: '290 kcal per 4 oz · 23g Protein · 0g Carbs',
    stockStatus: 'Fresh Batch Today',
    isTexasMade: true,
    isWeeklyDeal: true,
    isPopular: true,
  },
  {
    id: 'prod-milk',
    name: 'Fresh Whole Milk',
    brand: 'Brazos Valley Creamery',
    category: 'dairy-eggs',
    secondaryCategories: ['texas-made', 'groceries'],
    unitSize: '1 Gallon (128 fl oz)',
    unitPriceText: '$0.03 / fl oz',
    price: 3.89,
    promoPrice: 3.49,
    image: '/assets/generated/cat_dairy_eggs.jpg',
    fallbackColor: '#1E3A5F',
    origin: 'Waco, TX Family Dairies',
    description:
      'Grade A pasteurized whole milk from pasture-tended Central Texas dairy herds. Rich, creamy, and delivered cold daily.',
    nutritionSummary: '150 kcal per cup · 8g Protein · Calcium 25% DV',
    stockStatus: 'In Stock',
    isTexasMade: true,
    isWeeklyDeal: true,
    isPopular: true,
  },
  {
    id: 'prod-eggs',
    name: 'Large Grade A Pasture Eggs',
    brand: 'Prairie Sun Farms',
    category: 'dairy-eggs',
    secondaryCategories: ['texas-made'],
    unitSize: '12 Count Carton',
    unitPriceText: '$0.27 / egg',
    price: 3.29,
    image: '/assets/generated/cat_dairy_eggs.jpg',
    fallbackColor: '#8C6239',
    origin: 'Gonzales, TX',
    description:
      'Farm-fresh Large Grade A eggs with golden yolks from hens raised on open Texas pastures.',
    nutritionSummary: '70 kcal per egg · 6g Protein · 0g Sugar',
    stockStatus: 'In Stock',
    isTexasMade: true,
    isPopular: true,
  },
  {
    id: 'prod-tomatoes',
    name: 'Vine-Ripened Roma Tomatoes',
    brand: 'Rio Grande Valley Growers',
    category: 'fresh-food',
    secondaryCategories: ['groceries', 'texas-made', 'weekly-deals'],
    unitSize: '1 lb',
    unitPriceText: '$1.49 / lb',
    price: 1.99,
    promoPrice: 1.49,
    image: '/assets/generated/prod_tomatoes.jpg',
    fallbackColor: '#8B1E24',
    origin: 'Edinburg, TX',
    description:
      'Sweet, meaty vine-ripened Roma tomatoes harvested at peak color. Ideal for freshpico de gallo, roasting, and salads.',
    nutritionSummary: '82 kcal per lb · High in Lycopene & Vitamin C',
    stockStatus: 'Fresh Batch Today',
    isTexasMade: true,
    isWeeklyDeal: true,
    isPopular: true,
  },
  {
    id: 'prod-sourdough',
    name: 'Fresh Country Sourdough Loaf',
    brand: 'Lone Star Scratch Bakery',
    category: 'bakery',
    secondaryCategories: ['texas-made', 'weekly-deals'],
    unitSize: '1 Loaf (20 oz)',
    unitPriceText: '$0.22 / oz',
    price: 4.99,
    promoPrice: 4.49,
    image: '/assets/generated/prod_sourdough.jpg',
    fallbackColor: '#6E4726',
    origin: 'Baked In-Store Daily',
    description:
      'Naturally leavened 24-hour fermented sourdough boule baked on hearth stone for a blistered crust and tender crumb.',
    nutritionSummary: '130 kcal per slice · 5g Protein · Zero Preservatives',
    stockStatus: 'Fresh Batch Today',
    isTexasMade: true,
    isWeeklyDeal: true,
    isPopular: true,
  },
  {
    id: 'prod-honey',
    name: 'Raw Texas Wildflower Honey',
    brand: 'Hill Country Bee Co.',
    category: 'texas-made',
    secondaryCategories: ['groceries', 'weekly-deals'],
    unitSize: '12 oz Glass Jar',
    unitPriceText: '$0.62 / oz',
    price: 8.49,
    promoPrice: 7.49,
    image: '/assets/generated/prod_texas_honey.jpg',
    fallbackColor: '#9C6B21',
    origin: 'Fredericksburg, TX',
    description:
      'Unfiltered, unheated wildflower honey gathered from bluebonnet, clover, and mesquite blossoms across the Texas Hill Country.',
    nutritionSummary: '60 kcal per tbsp · 100% Pure Raw Honey',
    stockStatus: 'In Stock',
    isTexasMade: true,
    isWeeklyDeal: true,
    isPopular: true,
  },
  {
    id: 'prod-coffee',
    name: 'Hill Country Blend Ground Coffee',
    brand: 'Deep Texas Coffee Roasters',
    category: 'groceries',
    secondaryCategories: ['texas-made', 'weekly-deals'],
    unitSize: '12 oz Bag',
    unitPriceText: '$0.75 / oz',
    price: 10.99,
    promoPrice: 8.99,
    image: '/assets/generated/prod_coffee.jpg',
    fallbackColor: '#3B281E',
    origin: 'Roasted in Austin, TX',
    description:
      'Small-batch medium-dark roast with smooth notes of toasted pecan, dark cocoa, and warm caramel.',
    nutritionSummary: '5 kcal per cup · 100% Arabica Beans',
    stockStatus: 'In Stock',
    isTexasMade: true,
    isWeeklyDeal: true,
    isPopular: true,
  },
  {
    id: 'prod-cheddar',
    name: 'Aged Sharp Farmhouse Cheddar',
    brand: 'Lone Star Creamery',
    category: 'dairy-eggs',
    secondaryCategories: ['groceries', 'texas-made'],
    unitSize: '8 oz Block',
    unitPriceText: '$0.47 / oz',
    price: 3.79,
    image: '/assets/generated/cat_dairy_eggs.jpg',
    fallbackColor: '#B87A28',
    origin: 'Stephenville, TX',
    description:
      'Aged 12 months for a bold, savory sharpness and crumbly creamery texture.',
    nutritionSummary: '110 kcal per oz · 7g Protein · Calcium 20% DV',
    stockStatus: 'In Stock',
    isTexasMade: true,
    isPopular: true,
  },
  {
    id: 'prod-brisket',
    name: 'Post-Oak Smoked Beef Brisket',
    brand: 'Lone Star Smokehouse',
    category: 'meat-seafood',
    secondaryCategories: ['texas-made', 'weekly-deals'],
    unitSize: '1 lb Sliced Market Pack',
    unitPriceText: '$16.99 / lb',
    price: 19.99,
    promoPrice: 16.99,
    image: '/assets/generated/texas_bbq_brisket.jpg',
    fallbackColor: '#3A1914',
    origin: 'Smoked In-Store Over Texas Post Oak',
    description:
      'Slow-smoked for 14 hours with coarse black pepper and kosher salt for an authentic dark bark and tender smoke ring.',
    nutritionSummary: '310 kcal per 4 oz · 26g Protein · Gluten Free',
    stockStatus: 'Fresh Batch Today',
    isTexasMade: true,
    isWeeklyDeal: true,
  },
  {
    id: 'prod-bbq-sauce',
    name: 'Oak-Smoked Brisket & Bark BBQ Sauce',
    brand: 'Lone Star Smokehouse',
    category: 'texas-made',
    secondaryCategories: ['groceries'],
    unitSize: '16 oz Glass Bottle',
    unitPriceText: '$0.31 / oz',
    price: 4.99,
    image: '/assets/generated/prod_bbq_sauce.jpg',
    fallbackColor: '#541E1B',
    origin: 'Crafted in Austin, TX',
    description:
      'Tangy tomato and apple cider vinegar base simmered with cracked black pepper, molasses, and natural post-oak smoke.',
    nutritionSummary: '45 kcal per 2 tbsp · No High-Fructose Corn Syrup',
    stockStatus: 'In Stock',
    isTexasMade: true,
  },
  {
    id: 'prod-avocados',
    name: 'Ripe Hass Avocados & Sweet Bell Peppers',
    brand: 'Lone Star Fresh Produce',
    category: 'fresh-food',
    secondaryCategories: ['groceries', 'weekly-deals'],
    unitSize: '4 Count Market Pack',
    unitPriceText: '$0.99 / each',
    price: 4.99,
    promoPrice: 3.96,
    image: '/assets/generated/prod_avocados_peppers.jpg',
    fallbackColor: '#3C5A34',
    origin: 'South Texas & Regional Growers',
    description:
      'Hand-selected creamy Hass avocados paired with crisp, sweet multicolor bell peppers.',
    nutritionSummary: '160 kcal per half avocado · Healthy Monounsaturated Fats',
    stockStatus: 'Fresh Batch Today',
    isWeeklyDeal: true,
  },
  {
    id: 'prod-pecans',
    name: 'Cinnamon Chili Spiced Texas Pecans',
    brand: 'Pecan Bayou Artisanal',
    category: 'texas-made',
    secondaryCategories: ['groceries'],
    unitSize: '10 oz Glass Jar',
    unitPriceText: '$0.89 / oz',
    price: 8.99,
    image: '/assets/generated/prod_pecans.jpg',
    fallbackColor: '#5B3A24',
    origin: 'San Saba & San Antonio, TX',
    description:
      'Mammoth Texas native pecan halves glazed in pure cane sugar, warm cinnamon, and a subtle kick of ancho chile.',
    nutritionSummary: '190 kcal per oz · 3g Fiber · Orchard Direct',
    stockStatus: 'Limited Local Harvest',
    isTexasMade: true,
  },
  {
    id: 'prod-croissants',
    name: 'All-Butter Flaky Croissants',
    brand: 'Lone Star Scratch Bakery',
    category: 'bakery',
    secondaryCategories: ['groceries'],
    unitSize: '4 Count Pastry Box',
    unitPriceText: '$1.37 / croissant',
    price: 5.49,
    image: '/assets/generated/prod_croissants.jpg',
    fallbackColor: '#8B5E2B',
    origin: 'Baked In-Store Daily',
    description:
      'Laminated with cultured sweet cream butter and baked to golden, honeycomb-layered perfection every morning.',
    nutritionSummary: '260 kcal per croissant · 100% Real Butter',
    stockStatus: 'Fresh Batch Today',
  },
  {
    id: 'prod-greens',
    name: 'Crisp Organic Romaine & Green Leaf',
    brand: 'Hill Country Hydroponics',
    category: 'fresh-food',
    secondaryCategories: ['texas-made'],
    unitSize: '2 Hearts (12 oz)',
    unitPriceText: '$0.25 / oz',
    price: 2.99,
    image: '/assets/generated/prod_leafy_greens.jpg',
    fallbackColor: '#486B3E',
    origin: 'Dripping Springs, TX',
    description:
      'Greenhouse-grown Texas romaine lettuce harvested with roots intact for lasting crunch and sweetness.',
    nutritionSummary: '15 kcal per 2 cups · Vitamin A & K Rich',
    stockStatus: 'Fresh Batch Today',
    isTexasMade: true,
  },
  {
    id: 'prod-household-bundle',
    name: 'Everyday Kitchen & Surface Care Bundle',
    brand: 'Lone Star Home Essentials',
    category: 'household',
    secondaryCategories: ['groceries'],
    unitSize: '3-Piece Value Pack',
    unitPriceText: '$2.83 / item',
    price: 8.49,
    image: '/assets/generated/cat_household.jpg',
    fallbackColor: '#2E5266',
    origin: 'Packaged in Dallas, TX',
    description:
      'Includes citrus plant-based multi-surface spray, concentrated dish liquid, and ultra-absorbent 2-ply paper towel roll.',
    nutritionSummary: 'Biodegradable Surfactants · Phosphate Free',
    stockStatus: 'In Stock',
  },
  {
    id: 'prod-beauty-wash',
    name: 'Cedarwood & Agave Botanical Body Wash',
    brand: 'West Texas Apothecary',
    category: 'health-beauty',
    secondaryCategories: ['texas-made'],
    unitSize: '16 fl oz Pump Bottle',
    unitPriceText: '$0.49 / fl oz',
    price: 7.99,
    image: '/assets/generated/cat_health_beauty.jpg',
    fallbackColor: '#5C4448',
    origin: 'Marfa & Austin, TX',
    description:
      'Sulfate-free botanical cleanser infused with desert agave nectar, Texas cedarwood essential oil, and aloe vera.',
    nutritionSummary: 'Paraben Free · Dermatologist Tested',
    stockStatus: 'In Stock',
    isTexasMade: true,
  },
];

export const DEMO_STORES: DemoStore[] = [
  {
    id: 'store-austin-soco',
    name: 'Austin Flagship — South Congress Reserve',
    market: 'Austin',
    city: 'Austin',
    zip: '78704',
    address: '2400 Demo S Congress Ave, Austin, TX 78704 (Illustrative Demo Location)',
    hours: 'Open Daily · 6:00 AM – 11:00 PM',
    phone: '(512) 555-0194',
    pickupWait: 'Next Curbside Slot: Today, 2:00 PM – 3:00 PM',
    services: ['Curbside Pickup', 'Post-Oak Smokehouse', 'Scratch Bakery', 'Texas Made Pavilion', 'Full Butcher Counter'],
    featuredNote: 'Features our flagship live-oak barbecue smokehouse and 400+ local Hill Country items.',
  },
  {
    id: 'store-dfw-parkcities',
    name: 'Dallas — Preston Hollow Market',
    market: 'Dallas–Fort Worth',
    city: 'Dallas',
    zip: '75225',
    address: '8300 Demo Preston Rd, Dallas, TX 75225 (Illustrative Demo Location)',
    hours: 'Open Daily · 6:00 AM – 11:00 PM',
    phone: '(214) 555-0148',
    pickupWait: 'Next Curbside Slot: Today, 1:30 PM – 2:30 PM',
    services: ['Curbside Pickup', 'Dry-Aged Steak Vault', 'Scratch Bakery', 'Floral Studio', 'Express Pharmacy'],
    featuredNote: 'Dry-aged Texas beef program and 16 covered curbside pickup bays.',
  },
  {
    id: 'store-ftworth-clearfork',
    name: 'Fort Worth — Trinity Ranch Market',
    market: 'Dallas–Fort Worth',
    city: 'Fort Worth',
    zip: '76107',
    address: '4900 Demo Camp Bowie Blvd, Fort Worth, TX 76107 (Illustrative Demo Location)',
    hours: 'Open Daily · 6:00 AM – 10:30 PM',
    phone: '(817) 555-0182',
    pickupWait: 'Next Curbside Slot: Today, 3:00 PM – 4:00 PM',
    services: ['Curbside Pickup', 'Post-Oak Smokehouse', 'Ranch Butcher Counter', 'Texas Made Pavilion'],
    featuredNote: 'Direct partnership with West Texas cattle ranches and Parker County peach orchards.',
  },
  {
    id: 'store-houston-heights',
    name: 'Houston — The Heights Market',
    market: 'Houston',
    city: 'Houston',
    zip: '77008',
    address: '1920 Demo Yale St, Houston, TX 77008 (Illustrative Demo Location)',
    hours: 'Open Daily · 6:00 AM – 11:00 PM',
    phone: '(713) 555-0166',
    pickupWait: 'Next Curbside Slot: Today, 2:30 PM – 3:30 PM',
    services: ['Curbside Pickup', 'Gulf Seafood Dock', 'Scratch Bakery', 'Tortilleria', 'Texas Made Pavilion'],
    featuredNote: 'Daily Gulf Coast wild shrimp deliveries and warm flour tortillas pressed hourly.',
  },
  {
    id: 'store-sanantonio-pearl',
    name: 'San Antonio — Alamo Heights Market',
    market: 'San Antonio',
    city: 'San Antonio',
    zip: '78209',
    address: '5110 Demo Broadway, San Antonio, TX 78209 (Illustrative Demo Location)',
    hours: 'Open Daily · 6:00 AM – 11:00 PM',
    phone: '(210) 555-0173',
    pickupWait: 'Next Curbside Slot: Today, 2:00 PM – 3:00 PM',
    services: ['Curbside Pickup', 'Post-Oak Smokehouse', 'Scratch Panadería & Bakery', 'Rio Grande Produce Hub'],
    featuredNote: 'Celebrated for scratch pan dulce, mesquite-grilled fajitas, and South Texas citrus.',
  },
];

export const SEARCH_SUGGESTIONS = [
  'Milk',
  'Ribeye steak',
  'Fresh tomatoes',
  'Eggs',
  'Barbecue sauce',
  'Smoked brisket',
  'Texas honey',
  'Sourdough',
];
