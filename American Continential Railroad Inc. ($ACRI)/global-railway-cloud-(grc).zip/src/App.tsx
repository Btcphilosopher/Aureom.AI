import React, { useState, useEffect } from 'react';
import { HeaderNav } from './components/HeaderNav';
import { GlobalOperationsCenter } from './components/GlobalOperationsCenter';
import { GlobalGISMapView } from './components/GlobalGISMapView';
import { TrainDigitalTwin } from './components/TrainDigitalTwin';
import { StationDigitalTwin } from './components/StationDigitalTwin';
import { TimetableStringChart } from './components/TimetableStringChart';
import { DelayIntelligenceLab } from './components/DelayIntelligenceLab';
import { InternationalCorridorsView } from './components/InternationalCorridorsView';
import { EnergyInfrastructureLab } from './components/EnergyInfrastructureLab';
import { ScenarioLab } from './components/ScenarioLab';
import { AIAssistantModal } from './components/AIAssistantModal';
import { DataGovernanceView } from './components/DataGovernanceView';
import { TrainIntelligenceModal } from './components/TrainIntelligenceModal';
import { CommandPalette } from './components/CommandPalette';
import { 
  COUNTRIES, 
  OPERATORS, 
  LINES, 
  STATIONS, 
  ROLLING_STOCK_FLEET, 
  LIVE_TRAINS, 
  INCIDENTS, 
  GLOBAL_KPIS 
} from './data/seedData';
import { Train, Station, Incident } from './types/railway';
import { simulateTrainStep } from './services/simulationEngine';

export function App() {
  const [currentTab, setCurrentTab] = useState<string>('occ');
  const [selectedCountryId, setSelectedCountryId] = useState<string>('ALL');
  const [selectedOperatorId, setSelectedOperatorId] = useState<string>('ALL');
  
  // Real-time trains state
  const [trains, setTrains] = useState<Train[]>(LIVE_TRAINS);
  const [selectedTrain, setSelectedTrain] = useState<Train | null>(LIVE_TRAINS[0]);
  const [isTrainModalOpen, setIsTrainModalOpen] = useState<boolean>(false);
  const [selectedStation, setSelectedStation] = useState<Station | null>(STATIONS[0]);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);

  // Client-side simulation tick interval for live kinematics
  useEffect(() => {
    const timer = setInterval(() => {
      setTrains(prevTrains => prevTrains.map(t => simulateTrainStep(t, 2.0)));
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  // Update selectedTrain reference when trains array updates
  useEffect(() => {
    if (selectedTrain) {
      const updated = trains.find(t => t.id === selectedTrain.id);
      if (updated) setSelectedTrain(updated);
    }
  }, [trains]);

  const handleOpenTrainModal = (train: Train) => {
    setSelectedTrain(train);
    setIsTrainModalOpen(true);
  };

  const handleOpenDigitalTwin = (train: Train) => {
    setSelectedTrain(train);
    setCurrentTab('twin');
  };

  const handleOpenStation = (station: Station) => {
    setSelectedStation(station);
    setCurrentTab('station');
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#070a0f] text-slate-100 overflow-hidden font-sans select-none">
      {/* Header & Global Hierarchy Navigation */}
      <HeaderNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        countries={COUNTRIES}
        operators={OPERATORS}
        selectedCountryId={selectedCountryId}
        onSelectCountry={setSelectedCountryId}
        selectedOperatorId={selectedOperatorId}
        onSelectOperator={setSelectedOperatorId}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        activeTrainsCount={trains.length}
      />

      {/* Main View Router */}
      <div className="flex-1 min-h-0 relative">
        {currentTab === 'occ' && (
          <GlobalOperationsCenter
            countries={COUNTRIES}
            operators={OPERATORS}
            lines={LINES}
            stations={STATIONS}
            trains={trains}
            incidents={INCIDENTS}
            kpis={GLOBAL_KPIS}
            selectedCountryId={selectedCountryId}
            onSelectCountry={setSelectedCountryId}
            selectedTrain={selectedTrain}
            onSelectTrain={setSelectedTrain}
            onOpenTrainModal={handleOpenTrainModal}
            onOpenStationModal={handleOpenStation}
          />
        )}

        {currentTab === 'map' && (
          <GlobalGISMapView
            onSelectTrain={setSelectedTrain}
            onOpenTrainModal={handleOpenTrainModal}
          />
        )}

        {currentTab === 'twin' && (
          <TrainDigitalTwin initialTrain={selectedTrain} />
        )}

        {currentTab === 'station' && (
          <StationDigitalTwin selectedStationId={selectedStation?.id} />
        )}

        {currentTab === 'timetable' && (
          <TimetableStringChart />
        )}

        {currentTab === 'delay' && (
          <DelayIntelligenceLab />
        )}

        {currentTab === 'freight' && (
          <InternationalCorridorsView />
        )}

        {currentTab === 'energy' && (
          <EnergyInfrastructureLab />
        )}

        {currentTab === 'scenario' && (
          <ScenarioLab />
        )}

        {currentTab === 'ai' && (
          <AIAssistantModal />
        )}

        {currentTab === 'governance' && (
          <DataGovernanceView />
        )}
      </div>

      {/* Train Detail Inspection Modal (Speed, Telemetry, ETA, Energy) */}
      {isTrainModalOpen && selectedTrain && (
        <TrainIntelligenceModal
          train={selectedTrain}
          rollingStock={ROLLING_STOCK_FLEET.find(rs => rs.id === selectedTrain.rollingStockId)}
          onClose={() => setIsTrainModalOpen(false)}
          onOpenDigitalTwin={handleOpenDigitalTwin}
        />
      )}

      {/* Global Quick Switcher (Ctrl+K) */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectTrain={(train) => {
          setSelectedTrain(train);
          setIsTrainModalOpen(true);
        }}
        onSelectStation={(station) => {
          setSelectedStation(station);
          setCurrentTab('station');
        }}
        onSelectTab={(tab) => setCurrentTab(tab)}
      />
    </div>
  );
}

export default App;
