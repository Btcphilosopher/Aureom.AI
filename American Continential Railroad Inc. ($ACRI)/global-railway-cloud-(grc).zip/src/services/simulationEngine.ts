/**
 * Global Railway Cloud (GRC) - Physics, Kinematics & Simulation Engine
 * Implements real train dynamics, Davis resistance equation, energy flow, and anomaly detection.
 */

import { Train, Station, RailwayLine, Incident, TimetableConflict } from '../types/railway';

export interface TrainKinematicsState {
  speedKmH: number;
  accelerationMs2: number;
  tractivePowerKw: number;
  energyDrawKWh: number;
  regenerativeReturnKw: number;
  catenaryCurrentA: number;
  anomalyScore: number;
}

/**
 * Davis Equation coefficients for High-Speed EMU (CR400AF / Shinkansen / TGV):
 * R = A + B*v + C*v^2 (N/kN)
 */
const DAVIS_A = 1.2;     // Rolling resistance
const DAVIS_B = 0.008;   // Mechanical resistance
const DAVIS_C = 0.00032; // Aerodynamic drag coefficient
const TRAIN_MASS_TONNES = 480; // 8-car or 16-car EMU nominal mass
const MOTOR_EFFICIENCY = 0.945;
const REGEN_EFFICIENCY = 0.88;

/**
 * Simulates one dynamic time tick for a train along its polyline path
 */
export function simulateTrainStep(
  train: Train,
  deltaSeconds: number = 2.0
): Train {
  const currentSpeed = train.currentSpeedKmH;
  const targetSpeed = train.targetSpeedKmH;
  
  // Calculate acceleration / braking requirement
  let accelerationMs2 = 0;
  let powerKw = 0;
  let regenKw = 0;
  
  if (currentSpeed < targetSpeed - 1) {
    // Accelerating
    accelerationMs2 = Math.min(0.65, (targetSpeed - currentSpeed) / 10);
    const speedMs = (currentSpeed * 1000) / 3600;
    const dragForceN = (DAVIS_A + DAVIS_B * currentSpeed + DAVIS_C * currentSpeed * currentSpeed) * TRAIN_MASS_TONNES;
    const accelForceN = (TRAIN_MASS_TONNES * 1000) * accelerationMs2;
    const totalTractiveForceN = dragForceN + accelForceN;
    powerKw = (totalTractiveForceN * speedMs) / (1000 * MOTOR_EFFICIENCY);
  } else if (currentSpeed > targetSpeed + 1) {
    // Decelerating / Regenerative braking
    accelerationMs2 = -Math.min(0.85, (currentSpeed - targetSpeed) / 8);
    const speedMs = (currentSpeed * 1000) / 3600;
    const brakingForceN = (TRAIN_MASS_TONNES * 1000) * Math.abs(accelerationMs2);
    regenKw = (brakingForceN * speedMs * REGEN_EFFICIENCY) / 1000;
    powerKw = 150; // Auxiliary HVAC & electronics only
  } else {
    // Cruising
    accelerationMs2 = (Math.random() - 0.5) * 0.04;
    const speedMs = (currentSpeed * 1000) / 3600;
    const dragForceN = (DAVIS_A + DAVIS_B * currentSpeed + DAVIS_C * currentSpeed * currentSpeed) * TRAIN_MASS_TONNES;
    powerKw = (dragForceN * speedMs) / (1000 * MOTOR_EFFICIENCY);
  }

  // Update speed
  const newSpeed = Math.max(0, Math.min(380, currentSpeed + (accelerationMs2 * deltaSeconds * 3.6)));
  
  // Progress along route (0 to 100%)
  const speedKmS = newSpeed / 3600;
  const distanceKmInStep = speedKmS * deltaSeconds;
  const deltaProgress = (distanceKmInStep / 1300) * 100; // normalized ~1300km reference
  const newProgress = (train.routeProgressPercent + deltaProgress) % 100;

  // Compute live motor current from 25kV Catenary: I = P / (sqrt(3) * V * cosPhi) or single-phase 25kV
  const catenaryVoltage = 25000 + (Math.sin(Date.now() / 3000) * 450);
  const motorCurrent = (powerKw * 1000) / (catenaryVoltage * 0.95);

  // Anomaly calculation: synthetic multi-variate deviation
  const bearingVib = 0.75 + (newSpeed / 350) * 0.2 + (Math.random() * 0.08);
  const motorTemp = 65 + (powerKw / 8500) * 12 + (Math.random() * 0.5);
  const pantographVib = 0.14 + (newSpeed / 350) * 0.08 + (Math.random() * 0.03);

  let anomalyScore = 1.2;
  if (motorTemp > 78) anomalyScore += 8.5;
  if (bearingVib > 1.05) anomalyScore += 12.0;
  if (train.delayMinutes > 5) anomalyScore += 5.0;

  return {
    ...train,
    currentSpeedKmH: Math.round(newSpeed),
    routeProgressPercent: Number(newProgress.toFixed(2)),
    currentPowerDrawKw: Math.round(powerKw),
    regenerativeBrakingKw: Math.round(regenKw),
    todayEnergyMWh: Number((train.todayEnergyMWh + (powerKw * (deltaSeconds / 3600) / 1000)).toFixed(2)),
    telemetry: {
      ...train.telemetry,
      motorTempC: Number(motorTemp.toFixed(1)),
      motorCurrentA: Math.round(motorCurrent),
      catenaryVoltageV: Math.round(catenaryVoltage),
      bearingVibrationMmS: Number(bearingVib.toFixed(2)),
      pantographVibrationG: Number(pantographVib.toFixed(2)),
      safetyBrakingDistanceMeters: Math.round(((newSpeed / 3.6) ** 2) / (2 * 0.8)),
      tractionEfficiencyPercent: Number((MOTOR_EFFICIENCY * 100 - (Math.random() * 0.4)).toFixed(1)),
      anomalyScore: Number(anomalyScore.toFixed(1))
    }
  };
}

/**
 * Delay Cascade Graph calculation
 * Propagates primary delays through shared junctions and downstream services
 */
export function calculateDelayCascade(
  primaryIncident: Incident,
  trains: Train[]
): {
  affectedTrainIds: string[];
  downstreamDelayMinutes: number;
  impactCascadeTree: {
    level: number;
    trainId: string;
    serviceNumber: string;
    delayAddedMinutes: number;
    cause: string;
  }[];
} {
  const lineTrains = trains.filter(t => t.lineId === primaryIncident.lineId);
  const cascadeTree: {
    level: number;
    trainId: string;
    serviceNumber: string;
    delayAddedMinutes: number;
    cause: string;
  }[] = [];

  let accumulatedDelay = primaryIncident.estimatedNetworkDelayMin;

  lineTrains.forEach((train, idx) => {
    const delayAdd = Math.max(0, Math.round((accumulatedDelay * 0.6) / (idx + 1)));
    cascadeTree.push({
      level: idx + 1,
      trainId: train.id,
      serviceNumber: train.serviceNumber,
      delayAddedMinutes: delayAdd,
      cause: idx === 0 ? primaryIncident.title : `Downstream headway spacing reduction behind ${lineTrains[0]?.serviceNumber}`
    });
  });

  return {
    affectedTrainIds: lineTrains.map(t => t.id),
    downstreamDelayMinutes: accumulatedDelay,
    impactCascadeTree: cascadeTree
  };
}
