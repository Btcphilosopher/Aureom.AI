/**
 * Global Railway Cloud (GRC) - Enterprise Global Seed Dataset
 * Standardized to Universal Railway Data Model (URDM)
 */

import {
  Country,
  RailwayOperator,
  RailwayLine,
  Station,
  RollingStock,
  Train,
  Incident,
  InternationalCorridor,
  NetworkKPIs,
  TimetableConflict,
  ScenarioSimulation
} from '../types/railway';

export const COUNTRIES: Country[] = [
  {
    id: 'CN',
    name: 'China',
    nameZh: '中国',
    flag: '🇨🇳',
    continent: 'Asia',
    primaryGauge: '1435mm_STANDARD',
    primaryVoltage: '25kV_50Hz_AC',
    primarySignalling: 'CTCS-3',
    totalNetworkKm: 159000,
    hsrNetworkKm: 45000,
    totalStations: 5500,
    authorities: [
      {
        id: 'AUTH-CN-NRA',
        countryId: 'CN',
        name: 'National Railway Administration (NRA)',
        nameZh: '国家铁路局',
        code: 'NRA',
        headquarters: 'Beijing',
        operationalRegions: [
          { id: 'REG-CN-BJ', authorityId: 'AUTH-CN-NRA', name: 'China Railway Beijing Bureau', nameZh: '中国铁路北京局集团', code: 'CR-BEIJING', dispatchCenter: 'Beijing OCC', status: 'OPTIMAL' },
          { id: 'REG-CN-SH', authorityId: 'AUTH-CN-NRA', name: 'China Railway Shanghai Bureau', nameZh: '中国铁路上海局集团', code: 'CR-SHANGHAI', dispatchCenter: 'Shanghai Hongqiao OCC', status: 'OPTIMAL' },
          { id: 'REG-CN-GZ', authorityId: 'AUTH-CN-NRA', name: 'China Railway Guangzhou Bureau', nameZh: '中国铁路广州局集团', code: 'CR-GUANGZHOU', dispatchCenter: 'Guangzhou South OCC', status: 'OPTIMAL' },
          { id: 'REG-CN-CD', authorityId: 'AUTH-CN-NRA', name: 'China Railway Chengdu Bureau', nameZh: '中国铁路成都局集团', code: 'CR-CHENGDU', dispatchCenter: 'Chengdu East OCC', status: 'OPTIMAL' },
        ]
      }
    ]
  },
  {
    id: 'JP',
    name: 'Japan',
    nameZh: '日本',
    flag: '🇯🇵',
    continent: 'Asia',
    primaryGauge: '1435mm_STANDARD', // Shinkansen (Narrow 1067mm conventional)
    primaryVoltage: '25kV_60Hz_AC',
    primarySignalling: 'ATC_SHINKANSEN',
    totalNetworkKm: 27500,
    hsrNetworkKm: 3100,
    totalStations: 8800,
    authorities: [
      {
        id: 'AUTH-JP-MLIT',
        countryId: 'JP',
        name: 'Ministry of Land, Infrastructure, Transport and Tourism (MLIT)',
        nameZh: '国土交通省',
        code: 'MLIT',
        headquarters: 'Tokyo',
        operationalRegions: [
          { id: 'REG-JP-EAST', authorityId: 'AUTH-JP-MLIT', name: 'JR East Shinkansen General OCC', nameZh: 'JR东日本新干线总控制中心', code: 'JR-EAST-OCC', dispatchCenter: 'Tokyo Dispatching Center', status: 'OPTIMAL' },
          { id: 'REG-JP-CENTRAL', authorityId: 'AUTH-JP-MLIT', name: 'JR Central Tokaido Shinkansen OCC', nameZh: 'JR东海东海道新干线控制中心', code: 'JR-CENTRAL-OCC', dispatchCenter: 'Shinagawa General Dispatch', status: 'OPTIMAL' }
        ]
      }
    ]
  },
  {
    id: 'DE',
    name: 'Germany',
    nameZh: '德国',
    flag: '🇩🇪',
    continent: 'Europe',
    primaryGauge: '1435mm_STANDARD',
    primaryVoltage: '15kV_16_7Hz_AC',
    primarySignalling: 'ETCS_L2',
    totalNetworkKm: 38400,
    hsrNetworkKm: 1650,
    totalStations: 5700,
    authorities: [
      {
        id: 'AUTH-DE-EBA',
        countryId: 'DE',
        name: 'Eisenbahn-Bundesamt (EBA)',
        nameZh: '联邦铁路局',
        code: 'EBA',
        headquarters: 'Bonn',
        operationalRegions: [
          { id: 'REG-DE-CENTER', authorityId: 'AUTH-DE-EBA', name: 'DB InfraGO Network Control Center', nameZh: '德铁网路运营中心', code: 'DB-OCC-FFM', dispatchCenter: 'Frankfurt Central OCC', status: 'OPTIMAL' }
        ]
      }
    ]
  },
  {
    id: 'FR',
    name: 'France',
    nameZh: '法国',
    flag: '🇫🇷',
    continent: 'Europe',
    primaryGauge: '1435mm_STANDARD',
    primaryVoltage: '25kV_50Hz_AC',
    primarySignalling: 'ETCS_L2',
    totalNetworkKm: 29500,
    hsrNetworkKm: 2800,
    totalStations: 3000,
    authorities: [
      {
        id: 'AUTH-FR-EPSF',
        countryId: 'FR',
        name: 'Établissement Public de Sécurité Ferroviaire (EPSF)',
        nameZh: '法国铁路安全局',
        code: 'EPSF',
        headquarters: 'Amiens',
        operationalRegions: [
          { id: 'REG-FR-NAT', authorityId: 'AUTH-FR-EPSF', name: 'SNCF Réseau National Dispatch', nameZh: '法国国铁网路调度中心', code: 'SNCF-OCC-PAR', dispatchCenter: 'Paris St-Denis OCC', status: 'OPTIMAL' }
        ]
      }
    ]
  },
  {
    id: 'GB',
    name: 'United Kingdom',
    nameZh: '英国',
    flag: '🇬🇧',
    continent: 'Europe',
    primaryGauge: '1435mm_STANDARD',
    primaryVoltage: '25kV_50Hz_AC',
    primarySignalling: 'ETCS_L2',
    totalNetworkKm: 16300,
    hsrNetworkKm: 110,
    totalStations: 2560,
    authorities: [
      {
        id: 'AUTH-GB-ORR',
        countryId: 'GB',
        name: 'Office of Rail and Road (ORR)',
        nameZh: '英国铁路与公路办公室',
        code: 'ORR',
        headquarters: 'London',
        operationalRegions: [
          { id: 'REG-GB-NR-EAST', authorityId: 'AUTH-GB-ORR', name: 'Network Rail East Coast Routing Control', nameZh: '英国国家铁路东海岸运营中心', code: 'NR-ECML-OCC', dispatchCenter: 'York Rail Operating Centre', status: 'OPTIMAL' }
        ]
      }
    ]
  },
  {
    id: 'IN',
    name: 'India',
    nameZh: '印度',
    flag: '🇮🇳',
    continent: 'Asia',
    primaryGauge: '1676mm_INDIAN_BROAD',
    primaryVoltage: '25kV_50Hz_AC',
    primarySignalling: 'KAVACH_INDIA',
    totalNetworkKm: 68100,
    hsrNetworkKm: 508,
    totalStations: 7325,
    authorities: [
      {
        id: 'AUTH-IN-RB',
        countryId: 'IN',
        name: 'Railway Board (Ministry of Railways)',
        nameZh: '印度铁道部铁路局',
        code: 'RB',
        headquarters: 'New Delhi',
        operationalRegions: [
          { id: 'REG-IN-NR', authorityId: 'AUTH-IN-RB', name: 'Northern Railway Central Control', nameZh: '北方铁路中央调度局', code: 'IR-NR-DELHI', dispatchCenter: 'New Delhi Central OCC', status: 'OPTIMAL' }
        ]
      }
    ]
  },
  {
    id: 'US',
    name: 'United States',
    nameZh: '美国',
    flag: '🇺🇸',
    continent: 'North America',
    primaryGauge: '1435mm_STANDARD',
    primaryVoltage: '25kV_60Hz_AC',
    primarySignalling: 'PTC_US',
    totalNetworkKm: 220000,
    hsrNetworkKm: 735,
    totalStations: 12000,
    authorities: [
      {
        id: 'AUTH-US-FRA',
        countryId: 'US',
        name: 'Federal Railroad Administration (FRA)',
        nameZh: '美国联邦铁路管理局',
        code: 'FRA',
        headquarters: 'Washington, D.C.',
        operationalRegions: [
          { id: 'REG-US-NEC', authorityId: 'AUTH-US-FRA', name: 'Amtrak Northeast Corridor Dispatching', nameZh: '美铁东北走廊调度中心', code: 'AMTRAK-NEC-OCC', dispatchCenter: 'Wilmington Consolidated OCC', status: 'OPTIMAL' },
          { id: 'REG-US-BNSF', authorityId: 'AUTH-US-FRA', name: 'BNSF Network Operations Center (NOC)', nameZh: 'BNSF网络调度控制中心', code: 'BNSF-NOC-FTW', dispatchCenter: 'Fort Worth NOC', status: 'OPTIMAL' }
        ]
      }
    ]
  },
  {
    id: 'KZ',
    name: 'Kazakhstan (Eurasian Corridor)',
    nameZh: '哈萨克斯坦 (欧亚走廊)',
    flag: '🇰🇿',
    continent: 'Asia',
    primaryGauge: '1520mm_BROAD_RUSSIAN',
    primaryVoltage: '25kV_50Hz_AC',
    primarySignalling: 'ETCS_L1',
    totalNetworkKm: 16000,
    hsrNetworkKm: 0,
    totalStations: 820,
    authorities: [
      {
        id: 'AUTH-KZ-KTZ',
        countryId: 'KZ',
        name: 'Kazakhstan Temir Zholy (KTZ)',
        nameZh: '哈萨克斯坦国家铁路公司',
        code: 'KTZ',
        headquarters: 'Astana',
        operationalRegions: [
          { id: 'REG-KZ-EAST', authorityId: 'AUTH-KZ-KTZ', name: 'Dostyk Intermodal Gauge Border Control', nameZh: '多斯特克跨国轨距换装枢纽', code: 'KTZ-DOSTYK-OCC', dispatchCenter: 'Dostyk Freight Terminal', status: 'OPTIMAL' }
        ]
      }
    ]
  }
];

export const OPERATORS: RailwayOperator[] = [
  {
    id: 'OP-CR',
    countryId: 'CN',
    name: 'China Railway (CR)',
    nameZh: '中国国家铁路集团有限公司',
    shortCode: 'CR',
    logo: '🚅',
    type: 'PASSENGER_HSR',
    tenantId: 'TENANT-CR-CORP',
    activeTrains: 8420,
    fleetSize: 13500,
    punctualityRate: 99.2,
    dailyPassengerKm: 4200000000,
    dailyFreightTonneKm: 8900000000
  },
  {
    id: 'OP-JR-EAST',
    countryId: 'JP',
    name: 'East Japan Railway Company (JR East)',
    nameZh: '东日本旅客铁道',
    shortCode: 'JR-East',
    logo: '🚄',
    type: 'PASSENGER_HSR',
    tenantId: 'TENANT-JR-EAST',
    activeTrains: 2150,
    fleetSize: 3400,
    punctualityRate: 99.7,
    dailyPassengerKm: 1100000000,
    dailyFreightTonneKm: 12000000
  },
  {
    id: 'OP-DB',
    countryId: 'DE',
    name: 'Deutsche Bahn AG (DB)',
    nameZh: '德国铁路股份公司',
    shortCode: 'DB',
    logo: '🚆',
    type: 'MIXED',
    tenantId: 'TENANT-DB-AG',
    activeTrains: 3600,
    fleetSize: 5800,
    punctualityRate: 91.8,
    dailyPassengerKm: 650000000,
    dailyFreightTonneKm: 820000000
  },
  {
    id: 'OP-SNCF',
    countryId: 'FR',
    name: 'SNCF Voyageurs & Réseau',
    nameZh: '法国国家铁路公司',
    shortCode: 'SNCF',
    logo: '🚄',
    type: 'PASSENGER_HSR',
    tenantId: 'TENANT-SNCF',
    activeTrains: 2900,
    fleetSize: 4200,
    punctualityRate: 93.4,
    dailyPassengerKm: 780000000,
    dailyFreightTonneKm: 240000000
  },
  {
    id: 'OP-LNER',
    countryId: 'GB',
    name: 'London North Eastern Railway (LNER)',
    nameZh: '伦敦东北铁路公司',
    shortCode: 'LNER',
    logo: '🚆',
    type: 'PASSENGER_HSR',
    tenantId: 'TENANT-LNER-UK',
    activeTrains: 420,
    fleetSize: 650,
    punctualityRate: 89.6,
    dailyPassengerKm: 140000000,
    dailyFreightTonneKm: 0
  },
  {
    id: 'OP-AMTRAK',
    countryId: 'US',
    name: 'Amtrak (National Railroad Passenger Corp)',
    nameZh: '美国国家铁路客运公司',
    shortCode: 'Amtrak',
    logo: '🚆',
    type: 'PASSENGER_HSR',
    tenantId: 'TENANT-AMTRAK-US',
    activeTrains: 680,
    fleetSize: 1800,
    punctualityRate: 84.2,
    dailyPassengerKm: 190000000,
    dailyFreightTonneKm: 0
  },
  {
    id: 'OP-IR',
    countryId: 'IN',
    name: 'Indian Railways (IR)',
    nameZh: '印度铁路公司',
    shortCode: 'IR',
    logo: '🚂',
    type: 'MIXED',
    tenantId: 'TENANT-INDIAN-RAIL',
    activeTrains: 6400,
    fleetSize: 14200,
    punctualityRate: 86.5,
    dailyPassengerKm: 3100000000,
    dailyFreightTonneKm: 4200000000
  },
  {
    id: 'OP-CR-EXPRESS',
    countryId: 'CN',
    name: 'China Railway Express (CRE / 欧亚班列)',
    nameZh: '中欧班列跨国货运联合体',
    shortCode: 'CRE',
    logo: '📦',
    type: 'FREIGHT',
    tenantId: 'TENANT-CRE-TRANS',
    activeTrains: 840,
    fleetSize: 22000,
    punctualityRate: 96.8,
    dailyPassengerKm: 0,
    dailyFreightTonneKm: 12500000000
  }
];

export const STATIONS: Station[] = [
  // China
  {
    id: 'STA-CN-BJN',
    countryId: 'CN',
    regionId: 'REG-CN-BJ',
    name: 'Beijing South Station',
    nameZh: '北京南站',
    code: 'VNP',
    city: 'Beijing',
    coordinates: [116.3789, 39.8652],
    platformsCount: 24,
    tracksCount: 24,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 240000,
    currentCrowdDensity: 74,
    status: 'NORMAL',
    connectedLineIds: ['LINE-CN-BJ-SH-HSR', 'LINE-CN-BJ-GZ-HSR'],
    platforms: [
      { id: 'PLT-BJN-1', stationId: 'STA-CN-BJN', number: '01', trackId: 'TRK-1', lengthMeters: 450, currentTrainId: 'TRN-G1234', scheduledDeparture: '14:00', status: 'OCCUPIED' },
      { id: 'PLT-BJN-2', stationId: 'STA-CN-BJN', number: '02', trackId: 'TRK-2', lengthMeters: 450, currentTrainId: null, scheduledDeparture: '14:20', status: 'AVAILABLE' },
      { id: 'PLT-BJN-3', stationId: 'STA-CN-BJN', number: '03', trackId: 'TRK-3', lengthMeters: 450, currentTrainId: 'TRN-G2', scheduledDeparture: '14:35', status: 'APPROACHING' },
    ],
    substations: [
      { id: 'SUB-BJN-A', name: 'Beijing South 220kV Traction Substation', voltageInKv: 220, voltageOutKv: 27.5, currentLoadMva: 64.2, capacityMva: 100, temperatureC: 48, status: 'NOMINAL' }
    ]
  },
  {
    id: 'STA-CN-NJN',
    countryId: 'CN',
    regionId: 'REG-CN-SH',
    name: 'Nanjing South Station',
    nameZh: '南京南站',
    code: 'NKH',
    city: 'Nanjing',
    coordinates: [118.7984, 31.9698],
    platformsCount: 28,
    tracksCount: 28,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 210000,
    currentCrowdDensity: 68,
    status: 'NORMAL',
    connectedLineIds: ['LINE-CN-BJ-SH-HSR'],
    platforms: [
      { id: 'PLT-NJN-1', stationId: 'STA-CN-NJN', number: '06', trackId: 'TRK-6', lengthMeters: 450, currentTrainId: null, status: 'AVAILABLE' }
    ],
    substations: [
      { id: 'SUB-NJN-A', name: 'Nanjing South 220kV Traction Substation', voltageInKv: 220, voltageOutKv: 27.5, currentLoadMva: 52.8, capacityMva: 90, temperatureC: 45, status: 'NOMINAL' }
    ]
  },
  {
    id: 'STA-CN-SHH',
    countryId: 'CN',
    regionId: 'REG-CN-SH',
    name: 'Shanghai Hongqiao Station',
    nameZh: '上海虹桥站',
    code: 'AOH',
    city: 'Shanghai',
    coordinates: [121.3195, 31.1947],
    platformsCount: 30,
    tracksCount: 30,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 350000,
    currentCrowdDensity: 83,
    status: 'HIGH_CROWD',
    connectedLineIds: ['LINE-CN-BJ-SH-HSR'],
    platforms: [
      { id: 'PLT-SHH-1', stationId: 'STA-CN-SHH', number: '01', trackId: 'TRK-1', lengthMeters: 450, currentTrainId: 'TRN-G1', scheduledArrival: '14:32', status: 'OCCUPIED' },
      { id: 'PLT-SHH-2', stationId: 'STA-CN-SHH', number: '02', trackId: 'TRK-2', lengthMeters: 450, currentTrainId: null, status: 'AVAILABLE' },
      { id: 'PLT-SHH-3', stationId: 'STA-CN-SHH', number: '03', trackId: 'TRK-3', lengthMeters: 450, currentTrainId: 'TRN-G1234', scheduledArrival: '18:18', status: 'APPROACHING' },
    ],
    substations: [
      { id: 'SUB-SHH-A', name: 'Hongqiao Grid #1 Main Substation', voltageInKv: 220, voltageOutKv: 27.5, currentLoadMva: 88.4, capacityMva: 120, temperatureC: 56, status: 'PEAK_LOAD' }
    ]
  },
  {
    id: 'STA-CN-ALA',
    countryId: 'CN',
    regionId: 'REG-CN-BJ',
    name: 'Alashankou Border Port Station',
    nameZh: '阿拉山口口岸站',
    code: 'AKR',
    city: 'Bortala',
    coordinates: [82.5701, 45.1764],
    platformsCount: 8,
    tracksCount: 36,
    isHub: true,
    isBorderStation: true,
    gaugeChangeCapable: true,
    dailyPassengerVolume: 4200,
    currentCrowdDensity: 32,
    status: 'NORMAL',
    connectedLineIds: ['LINE-CORR-CR-EXPRESS'],
    platforms: [],
    substations: [
      { id: 'SUB-ALA-1', name: 'Alashankou Intermodal Substation', voltageInKv: 110, voltageOutKv: 27.5, currentLoadMva: 34.0, capacityMva: 60, temperatureC: 38, status: 'NOMINAL' }
    ]
  },
  // Japan
  {
    id: 'STA-JP-TYO',
    countryId: 'JP',
    regionId: 'REG-JP-EAST',
    name: 'Tokyo Station',
    nameZh: '东京站',
    code: 'TYO',
    city: 'Tokyo',
    coordinates: [139.7671, 35.6812],
    platformsCount: 28,
    tracksCount: 28,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 460000,
    currentCrowdDensity: 88,
    status: 'NORMAL',
    connectedLineIds: ['LINE-JP-TOKAIDO-SHINKANSEN', 'LINE-JP-TOHOKU-SHINKANSEN'],
    platforms: [
      { id: 'PLT-TYO-14', stationId: 'STA-JP-TYO', number: '14', trackId: 'TRK-14', lengthMeters: 400, currentTrainId: 'TRN-NOZOMI-312', scheduledDeparture: '14:10', status: 'OCCUPIED' }
    ],
    substations: [
      { id: 'SUB-TYO-1', name: 'Tokyo Shinkansen Substation 50Hz', voltageInKv: 154, voltageOutKv: 25.0, currentLoadMva: 72.1, capacityMva: 100, temperatureC: 51, status: 'NOMINAL' }
    ]
  },
  {
    id: 'STA-JP-OSA',
    countryId: 'JP',
    regionId: 'REG-JP-CENTRAL',
    name: 'Shin-Osaka Station',
    nameZh: '新大阪站',
    code: 'SVO',
    city: 'Osaka',
    coordinates: [135.5003, 34.7335],
    platformsCount: 16,
    tracksCount: 16,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 180000,
    currentCrowdDensity: 65,
    status: 'NORMAL',
    connectedLineIds: ['LINE-JP-TOKAIDO-SHINKANSEN'],
    platforms: [],
    substations: []
  },
  // Germany
  {
    id: 'STA-DE-BER',
    countryId: 'DE',
    regionId: 'REG-DE-CENTER',
    name: 'Berlin Hauptbahnhof',
    nameZh: '柏林中央火车站',
    code: 'BL',
    city: 'Berlin',
    coordinates: [13.3695, 52.5256],
    platformsCount: 16,
    tracksCount: 16,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 330000,
    currentCrowdDensity: 70,
    status: 'NORMAL',
    connectedLineIds: ['LINE-DE-VDE8-HSR'],
    platforms: [
      { id: 'PLT-BER-1', stationId: 'STA-DE-BER', number: '05', trackId: 'TRK-5', lengthMeters: 400, currentTrainId: 'TRN-ICE-612', scheduledDeparture: '14:04', status: 'OCCUPIED' }
    ],
    substations: []
  },
  {
    id: 'STA-DE-MUC',
    countryId: 'DE',
    regionId: 'REG-DE-CENTER',
    name: 'München Hauptbahnhof',
    nameZh: '慕尼黑中央火车站',
    code: 'MH',
    city: 'Munich',
    coordinates: [11.5583, 48.1403],
    platformsCount: 32,
    tracksCount: 32,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 410000,
    currentCrowdDensity: 76,
    status: 'NORMAL',
    connectedLineIds: ['LINE-DE-VDE8-HSR'],
    platforms: [],
    substations: []
  },
  // France
  {
    id: 'STA-FR-PAR',
    countryId: 'FR',
    regionId: 'REG-FR-NAT',
    name: 'Paris Gare de Lyon',
    nameZh: '巴黎里昂火车站',
    code: 'PLY',
    city: 'Paris',
    coordinates: [2.3735, 48.8449],
    platformsCount: 23,
    tracksCount: 23,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 310000,
    currentCrowdDensity: 79,
    status: 'NORMAL',
    connectedLineIds: ['LINE-FR-LGV-SUD-EST'],
    platforms: [
      { id: 'PLT-PAR-1', stationId: 'STA-FR-PAR', number: 'Hall 1 - Voie L', trackId: 'TRK-L', lengthMeters: 400, currentTrainId: 'TRN-TGV-8421', scheduledDeparture: '14:15', status: 'OCCUPIED' }
    ],
    substations: []
  },
  {
    id: 'STA-FR-LYO',
    countryId: 'FR',
    regionId: 'REG-FR-NAT',
    name: 'Lyon Part-Dieu',
    nameZh: '里昂帕尔迪厄站',
    code: 'LPD',
    city: 'Lyon',
    coordinates: [4.8598, 45.7606],
    platformsCount: 12,
    tracksCount: 12,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 160000,
    currentCrowdDensity: 62,
    status: 'NORMAL',
    connectedLineIds: ['LINE-FR-LGV-SUD-EST'],
    platforms: [],
    substations: []
  },
  // United Kingdom
  {
    id: 'STA-GB-STP',
    countryId: 'GB',
    regionId: 'REG-GB-NR-EAST',
    name: 'London Kings Cross / St Pancras',
    nameZh: '伦敦国王十字 / 圣潘克拉斯枢纽',
    code: 'KGX',
    city: 'London',
    coordinates: [-0.1246, 51.5314],
    platformsCount: 15,
    tracksCount: 15,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 280000,
    currentCrowdDensity: 75,
    status: 'NORMAL',
    connectedLineIds: ['LINE-GB-ECML'],
    platforms: [
      { id: 'PLT-KGX-1', stationId: 'STA-GB-STP', number: '08', trackId: 'TRK-8', lengthMeters: 300, currentTrainId: 'TRN-LNER-782', scheduledDeparture: '14:00', status: 'OCCUPIED' }
    ],
    substations: []
  },
  {
    id: 'STA-GB-EDB',
    countryId: 'GB',
    regionId: 'REG-GB-NR-EAST',
    name: 'Edinburgh Waverley',
    nameZh: '爱丁堡威瓦利站',
    code: 'EDB',
    city: 'Edinburgh',
    coordinates: [-3.1892, 55.9520],
    platformsCount: 20,
    tracksCount: 20,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 90000,
    currentCrowdDensity: 54,
    status: 'NORMAL',
    connectedLineIds: ['LINE-GB-ECML'],
    platforms: [],
    substations: []
  },
  // USA
  {
    id: 'STA-US-NYP',
    countryId: 'US',
    regionId: 'REG-US-NEC',
    name: 'New York Penn Station (Moynihan Train Hall)',
    nameZh: '纽约宾夕法尼亚车站 (莫伊尼汉大厅)',
    code: 'NYP',
    city: 'New York',
    coordinates: [-73.9935, 40.7505],
    platformsCount: 21,
    tracksCount: 21,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 650000,
    currentCrowdDensity: 86,
    status: 'HIGH_CROWD',
    connectedLineIds: ['LINE-US-NEC'],
    platforms: [
      { id: 'PLT-NYP-1', stationId: 'STA-US-NYP', number: 'Track 11', trackId: 'TRK-11', lengthMeters: 350, currentTrainId: 'TRN-ACELA-2150', scheduledDeparture: '14:15', status: 'OCCUPIED' }
    ],
    substations: []
  },
  {
    id: 'STA-US-WAS',
    countryId: 'US',
    regionId: 'REG-US-NEC',
    name: 'Washington Union Station',
    nameZh: '华盛顿联合车站',
    code: 'WAS',
    city: 'Washington',
    coordinates: [-77.0062, 38.8973],
    platformsCount: 16,
    tracksCount: 16,
    isHub: true,
    isBorderStation: false,
    gaugeChangeCapable: false,
    dailyPassengerVolume: 120000,
    currentCrowdDensity: 58,
    status: 'NORMAL',
    connectedLineIds: ['LINE-US-NEC'],
    platforms: [],
    substations: []
  },
  // Kazakhstan (Cross-border hub)
  {
    id: 'STA-KZ-DOS',
    countryId: 'KZ',
    regionId: 'REG-KZ-EAST',
    name: 'Dostyk Freight Transfer Hub',
    nameZh: '多斯特克国际铁路货运枢纽',
    code: 'DTK',
    city: 'Dostyk',
    coordinates: [82.4833, 45.2500],
    platformsCount: 4,
    tracksCount: 42,
    isHub: true,
    isBorderStation: true,
    gaugeChangeCapable: true,
    dailyPassengerVolume: 1500,
    currentCrowdDensity: 28,
    status: 'NORMAL',
    connectedLineIds: ['LINE-CORR-CR-EXPRESS'],
    platforms: [],
    substations: []
  }
];

export const LINES: RailwayLine[] = [
  {
    id: 'LINE-CN-BJ-SH-HSR',
    countryId: 'CN',
    operatorIds: ['OP-CR'],
    name: 'Beijing-Shanghai High-Speed Railway',
    nameZh: '京沪高速铁路 (350km/h 标杆线)',
    code: 'BJ-SH-HSR',
    type: 'HIGH_SPEED',
    totalLengthKm: 1318,
    maxDesignSpeed: 380,
    trackGauge: '1435mm_STANDARD',
    electrification: '25kV_50Hz_AC',
    signalling: 'CTCS-3',
    stationIds: ['STA-CN-BJN', 'STA-CN-NJN', 'STA-CN-SHH'],
    coordinates: [
      [116.3789, 39.8652],
      [116.7500, 39.1000],
      [117.0000, 36.6500],
      [117.1500, 34.2600],
      [118.7984, 31.9698],
      [120.6100, 31.3000],
      [121.3195, 31.1947]
    ],
    status: 'NORMAL',
    currentSpeedLimit: 350,
    capacityTrainsPerHour: 16,
    utilizedCapacityPercent: 91.5
  },
  {
    id: 'LINE-JP-TOKAIDO-SHINKANSEN',
    countryId: 'JP',
    operatorIds: ['OP-JR-EAST'],
    name: 'Tokaido Shinkansen',
    nameZh: '东海道新干线',
    code: 'TOKAIDO-SHINKANSEN',
    type: 'HIGH_SPEED',
    totalLengthKm: 515.4,
    maxDesignSpeed: 300,
    trackGauge: '1435mm_STANDARD',
    electrification: '25kV_60Hz_AC',
    signalling: 'ATC_SHINKANSEN',
    stationIds: ['STA-JP-TYO', 'STA-JP-OSA'],
    coordinates: [
      [139.7671, 35.6812],
      [139.6200, 35.5000],
      [138.8000, 35.1500],
      [136.9000, 35.1700],
      [135.8000, 34.9800],
      [135.5003, 34.7335]
    ],
    status: 'NORMAL',
    currentSpeedLimit: 285,
    capacityTrainsPerHour: 17,
    utilizedCapacityPercent: 94.2
  },
  {
    id: 'LINE-DE-VDE8-HSR',
    countryId: 'DE',
    operatorIds: ['OP-DB'],
    name: 'VDE 8 High-Speed Line (Berlin - Munich)',
    nameZh: 'VDE 8 德国柏林-慕尼黑高速线',
    code: 'VDE-8-HSR',
    type: 'HIGH_SPEED',
    totalLengthKm: 623,
    maxDesignSpeed: 300,
    trackGauge: '1435mm_STANDARD',
    electrification: '15kV_16_7Hz_AC',
    signalling: 'ETCS_L2',
    stationIds: ['STA-DE-BER', 'STA-DE-MUC'],
    coordinates: [
      [13.3695, 52.5256],
      [12.3700, 51.3400],
      [11.0300, 50.9800],
      [11.0800, 49.4500],
      [11.5583, 48.1403]
    ],
    status: 'NORMAL',
    currentSpeedLimit: 300,
    capacityTrainsPerHour: 10,
    utilizedCapacityPercent: 78.4
  },
  {
    id: 'LINE-FR-LGV-SUD-EST',
    countryId: 'FR',
    operatorIds: ['OP-SNCF'],
    name: 'LGV Sud-Est (Paris - Lyon)',
    nameZh: '法国东南高速线 (LGV Sud-Est)',
    code: 'LGV-SE',
    type: 'HIGH_SPEED',
    totalLengthKm: 427,
    maxDesignSpeed: 320,
    trackGauge: '1435mm_STANDARD',
    electrification: '25kV_50Hz_AC',
    signalling: 'ETCS_L2',
    stationIds: ['STA-FR-PAR', 'STA-FR-LYO'],
    coordinates: [
      [2.3735, 48.8449],
      [3.3000, 47.8000],
      [4.2000, 46.8000],
      [4.8598, 45.7606]
    ],
    status: 'NORMAL',
    currentSpeedLimit: 300,
    capacityTrainsPerHour: 12,
    utilizedCapacityPercent: 88.0
  },
  {
    id: 'LINE-GB-ECML',
    countryId: 'GB',
    operatorIds: ['OP-LNER'],
    name: 'East Coast Main Line (London - Edinburgh)',
    nameZh: '英国东海岸主干线 (ECML)',
    code: 'ECML',
    type: 'HIGH_SPEED',
    totalLengthKm: 632,
    maxDesignSpeed: 225,
    trackGauge: '1435mm_STANDARD',
    electrification: '25kV_50Hz_AC',
    signalling: 'ETCS_L2',
    stationIds: ['STA-GB-STP', 'STA-GB-EDB'],
    coordinates: [
      [-0.1246, 51.5314],
      [-0.2000, 52.6000],
      [-1.1000, 53.9000],
      [-1.6000, 54.9700],
      [-3.1892, 55.9520]
    ],
    status: 'SPEED_RESTRICTED',
    currentSpeedLimit: 180,
    capacityTrainsPerHour: 8,
    utilizedCapacityPercent: 84.1
  },
  {
    id: 'LINE-US-NEC',
    countryId: 'US',
    operatorIds: ['OP-AMTRAK'],
    name: 'Northeast Corridor (Boston - NY - Washington)',
    nameZh: '美铁东北走廊 (NEC)',
    code: 'NEC',
    type: 'HIGH_SPEED',
    totalLengthKm: 735,
    maxDesignSpeed: 240,
    trackGauge: '1435mm_STANDARD',
    electrification: '25kV_60Hz_AC',
    signalling: 'PTC_US',
    stationIds: ['STA-US-NYP', 'STA-US-WAS'],
    coordinates: [
      [-73.9935, 40.7505],
      [-74.7600, 40.2200],
      [-75.1600, 39.9500],
      [-75.5500, 39.7400],
      [-76.6100, 39.2900],
      [-77.0062, 38.8973]
    ],
    status: 'NORMAL',
    currentSpeedLimit: 240,
    capacityTrainsPerHour: 14,
    utilizedCapacityPercent: 89.2
  },
  {
    id: 'LINE-CORR-CR-EXPRESS',
    countryId: 'CN',
    operatorIds: ['OP-CR-EXPRESS'],
    name: 'New Eurasian Land Bridge (Yiwu - Dostyk - Duisburg)',
    nameZh: '新亚欧大陆桥中欧班列跨国走廊',
    code: 'CRE-CORRIDOR-1',
    type: 'INTERMODAL_CORRIDOR',
    totalLengthKm: 11200,
    maxDesignSpeed: 160,
    trackGauge: '1435mm_STANDARD',
    electrification: '25kV_50Hz_AC',
    signalling: 'CTCS-2',
    stationIds: ['STA-CN-ALA', 'STA-KZ-DOS', 'STA-DE-BER'],
    coordinates: [
      [120.0700, 29.3000], // Yiwu
      [113.6000, 34.7500], // Zhengzhou
      [108.9000, 34.2500], // Xi'an
      [87.6000, 43.8000],  // Urumqi
      [82.5701, 45.1764],  // Alashankou
      [82.4833, 45.2500],  // Dostyk (KZ Gauge change)
      [71.4300, 51.1600],  // Astana
      [37.6100, 55.7500],  // Moscow
      [23.6800, 52.0900],  // Brest (BY Gauge change)
      [21.0100, 52.2300],  // Warsaw
      [13.3695, 52.5256]   // Berlin
    ],
    status: 'NORMAL',
    currentSpeedLimit: 120,
    capacityTrainsPerHour: 4,
    utilizedCapacityPercent: 96.0
  }
];

export const ROLLING_STOCK_FLEET: RollingStock[] = [
  {
    id: 'RS-CR400AF-2001',
    model: 'CR400AF-Z Smart Fuxing',
    series: 'China Standard EMU 350km/h',
    manufacturer: 'CRRC Qingdao Sifang Co., Ltd.',
    operatorId: 'OP-CR',
    countryId: 'CN',
    buildYear: 2023,
    totalMileageKm: 482000,
    operatingHours: 3200,
    maxSpeed: 400,
    formationLength: 16,
    passengerCapacity: 1193,
    totalPowerKw: 19600,
    healthScore: 98.6,
    estimatedRulDays: 780,
    nextScheduledOverhaul: '2027-04-15',
    condition: {
      tractionMotor: 99,
      bogieWheels: 97,
      pantograph: 99,
      brakingSystem: 98,
      hvac: 100,
      batteries: 98
    }
  },
  {
    id: 'RS-N700S-J1',
    model: 'Shinkansen N700S',
    series: 'Supreme High-Speed Series',
    manufacturer: 'Hitachi Rail / Nippon Sharyo',
    operatorId: 'OP-JR-EAST',
    countryId: 'JP',
    buildYear: 2022,
    totalMileageKm: 620000,
    operatingHours: 4100,
    maxSpeed: 360,
    formationLength: 16,
    passengerCapacity: 1323,
    totalPowerKw: 17080,
    healthScore: 99.4,
    estimatedRulDays: 840,
    nextScheduledOverhaul: '2027-08-20',
    condition: {
      tractionMotor: 100,
      bogieWheels: 99,
      pantograph: 99,
      brakingSystem: 100,
      hvac: 99,
      batteries: 99
    }
  },
  {
    id: 'RS-ICE4-001',
    model: 'ICE 4 (BR 412)',
    series: 'Intercity-Express Generation 4',
    manufacturer: 'Siemens Mobility / Bombardier',
    operatorId: 'OP-DB',
    countryId: 'DE',
    buildYear: 2021,
    totalMileageKm: 890000,
    operatingHours: 6200,
    maxSpeed: 265,
    formationLength: 12,
    passengerCapacity: 830,
    totalPowerKw: 9900,
    healthScore: 94.2,
    estimatedRulDays: 520,
    nextScheduledOverhaul: '2026-11-10',
    condition: {
      tractionMotor: 94,
      bogieWheels: 92,
      pantograph: 95,
      brakingSystem: 96,
      hvac: 93,
      batteries: 95
    }
  },
  {
    id: 'RS-TGV-DUPLEX-310',
    model: 'TGV 2N2 Euroduplex',
    series: 'High-Capacity Double-Deck HSR',
    manufacturer: 'Alstom Transport',
    operatorId: 'OP-SNCF',
    countryId: 'FR',
    buildYear: 2020,
    totalMileageKm: 1140000,
    operatingHours: 7800,
    maxSpeed: 320,
    formationLength: 8,
    passengerCapacity: 509,
    totalPowerKw: 9280,
    healthScore: 95.8,
    estimatedRulDays: 610,
    nextScheduledOverhaul: '2026-12-05',
    condition: {
      tractionMotor: 96,
      bogieWheels: 94,
      pantograph: 96,
      brakingSystem: 97,
      hvac: 95,
      batteries: 96
    }
  },
  {
    id: 'RS-ACELA2-01',
    model: 'Avelia Liberty (Acela II)',
    series: 'High-Speed Tilting Trainset',
    manufacturer: 'Alstom Hornell',
    operatorId: 'OP-AMTRAK',
    countryId: 'US',
    buildYear: 2023,
    totalMileageKm: 280000,
    operatingHours: 1900,
    maxSpeed: 260,
    formationLength: 9,
    passengerCapacity: 386,
    totalPowerKw: 7000,
    healthScore: 96.1,
    estimatedRulDays: 710,
    nextScheduledOverhaul: '2027-02-18',
    condition: {
      tractionMotor: 97,
      bogieWheels: 95,
      pantograph: 96,
      brakingSystem: 96,
      hvac: 97,
      batteries: 96
    }
  }
];

export const LIVE_TRAINS: Train[] = [
  {
    id: 'TRN-G1234',
    serviceNumber: 'G1234 (Fuxing Flagship)',
    rollingStockId: 'RS-CR400AF-2001',
    rollingStockModel: 'CR400AF-Z Smart Fuxing',
    operatorId: 'OP-CR',
    countryId: 'CN',
    lineId: 'LINE-CN-BJ-SH-HSR',
    originStationId: 'STA-CN-BJN',
    originStationName: 'Beijing South',
    destinationStationId: 'STA-CN-SHH',
    destinationStationName: 'Shanghai Hongqiao',
    trainType: 'HSR_EMU',
    status: 'RUNNING',
    currentCoordinates: [118.4200, 32.8500],
    headingDeg: 148,
    currentSpeedKmH: 348,
    targetSpeedKmH: 350,
    routeProgressPercent: 62.4,
    nextStationId: 'STA-CN-NJN',
    nextStationName: 'Nanjing South',
    scheduledNextArrival: '14:32',
    estimatedNextArrival: '14:31',
    delayMinutes: -1, // 1 min early
    passengerLoadPercent: 88,
    currentPowerDrawKw: 8420,
    todayEnergyMWh: 412,
    regenerativeBrakingKw: 0,
    telemetry: {
      motorTempC: 71.4,
      motorCurrentA: 382,
      catenaryVoltageV: 26450,
      brakePipePressureKPa: 600,
      pantographVibrationG: 0.18,
      bearingVibrationMmS: 0.82,
      axleTemp1C: 54.2,
      axleTemp2C: 55.1,
      cabinTempC: 22.5,
      safetyBrakingDistanceMeters: 3850,
      tractionEfficiencyPercent: 94.6,
      anomalyScore: 3.2
    }
  },
  {
    id: 'TRN-G1',
    serviceNumber: 'G1 (Direct Express)',
    rollingStockId: 'RS-CR400AF-2001',
    rollingStockModel: 'CR400AF Fuxing',
    operatorId: 'OP-CR',
    countryId: 'CN',
    lineId: 'LINE-CN-BJ-SH-HSR',
    originStationId: 'STA-CN-BJN',
    originStationName: 'Beijing South',
    destinationStationId: 'STA-CN-SHH',
    destinationStationName: 'Shanghai Hongqiao',
    trainType: 'HSR_EMU',
    status: 'RUNNING',
    currentCoordinates: [120.2500, 31.4200],
    headingDeg: 135,
    currentSpeedKmH: 350,
    targetSpeedKmH: 350,
    routeProgressPercent: 88.0,
    nextStationId: 'STA-CN-SHH',
    nextStationName: 'Shanghai Hongqiao',
    scheduledNextArrival: '14:35',
    estimatedNextArrival: '14:35',
    delayMinutes: 0,
    passengerLoadPercent: 96,
    currentPowerDrawKw: 8100,
    todayEnergyMWh: 490,
    regenerativeBrakingKw: 0,
    telemetry: {
      motorTempC: 69.8,
      motorCurrentA: 375,
      catenaryVoltageV: 26500,
      brakePipePressureKPa: 600,
      pantographVibrationG: 0.16,
      bearingVibrationMmS: 0.78,
      axleTemp1C: 52.8,
      axleTemp2C: 53.4,
      cabinTempC: 22.0,
      safetyBrakingDistanceMeters: 3820,
      tractionEfficiencyPercent: 95.1,
      anomalyScore: 2.1
    }
  },
  {
    id: 'TRN-NOZOMI-312',
    serviceNumber: 'Shinkansen Nozomi 312',
    rollingStockId: 'RS-N700S-J1',
    rollingStockModel: 'Shinkansen N700S',
    operatorId: 'OP-JR-EAST',
    countryId: 'JP',
    lineId: 'LINE-JP-TOKAIDO-SHINKANSEN',
    originStationId: 'STA-JP-TYO',
    originStationName: 'Tokyo Station',
    destinationStationId: 'STA-JP-OSA',
    destinationStationName: 'Shin-Osaka',
    trainType: 'HSR_EMU',
    status: 'RUNNING',
    currentCoordinates: [137.8500, 35.1200],
    headingDeg: 252,
    currentSpeedKmH: 285,
    targetSpeedKmH: 285,
    routeProgressPercent: 54.0,
    nextStationId: 'STA-JP-OSA',
    nextStationName: 'Nagoya / Shin-Osaka',
    scheduledNextArrival: '14:52',
    estimatedNextArrival: '14:52',
    delayMinutes: 0,
    passengerLoadPercent: 91,
    currentPowerDrawKw: 6840,
    todayEnergyMWh: 298,
    regenerativeBrakingKw: 0,
    telemetry: {
      motorTempC: 66.2,
      motorCurrentA: 310,
      catenaryVoltageV: 25100,
      brakePipePressureKPa: 580,
      pantographVibrationG: 0.14,
      bearingVibrationMmS: 0.65,
      axleTemp1C: 49.0,
      axleTemp2C: 49.8,
      cabinTempC: 23.0,
      safetyBrakingDistanceMeters: 3100,
      tractionEfficiencyPercent: 96.2,
      anomalyScore: 1.4
    }
  },
  {
    id: 'TRN-ICE-612',
    serviceNumber: 'ICE 612 Sprinter',
    rollingStockId: 'RS-ICE4-001',
    rollingStockModel: 'ICE 4 (BR 412)',
    operatorId: 'OP-DB',
    countryId: 'DE',
    lineId: 'LINE-DE-VDE8-HSR',
    originStationId: 'STA-DE-BER',
    originStationName: 'Berlin Hbf',
    destinationStationId: 'STA-DE-MUC',
    destinationStationName: 'München Hbf',
    trainType: 'HSR_EMU',
    status: 'RUNNING',
    currentCoordinates: [11.8200, 50.4000],
    headingDeg: 195,
    currentSpeedKmH: 295,
    targetSpeedKmH: 300,
    routeProgressPercent: 48.2,
    nextStationId: 'STA-DE-MUC',
    nextStationName: 'Erfurt Hbf / Nürnberg',
    scheduledNextArrival: '15:10',
    estimatedNextArrival: '15:14',
    delayMinutes: 4,
    passengerLoadPercent: 82,
    currentPowerDrawKw: 5900,
    todayEnergyMWh: 215,
    regenerativeBrakingKw: 0,
    telemetry: {
      motorTempC: 74.0,
      motorCurrentA: 345,
      catenaryVoltageV: 15200,
      brakePipePressureKPa: 500,
      pantographVibrationG: 0.22,
      bearingVibrationMmS: 0.95,
      axleTemp1C: 56.4,
      axleTemp2C: 57.0,
      cabinTempC: 21.8,
      safetyBrakingDistanceMeters: 3400,
      tractionEfficiencyPercent: 92.8,
      anomalyScore: 7.8
    }
  },
  {
    id: 'TRN-TGV-8421',
    serviceNumber: 'TGV 8421 Euroduplex',
    rollingStockId: 'RS-TGV-DUPLEX-310',
    rollingStockModel: 'TGV 2N2 Euroduplex',
    operatorId: 'OP-SNCF',
    countryId: 'FR',
    lineId: 'LINE-FR-LGV-SUD-EST',
    originStationId: 'STA-FR-PAR',
    originStationName: 'Paris Gare de Lyon',
    destinationStationId: 'STA-FR-LYO',
    destinationStationName: 'Lyon Part-Dieu',
    trainType: 'HSR_EMU',
    status: 'RUNNING',
    currentCoordinates: [3.9500, 47.2000],
    headingDeg: 142,
    currentSpeedKmH: 312,
    targetSpeedKmH: 320,
    routeProgressPercent: 58.0,
    nextStationId: 'STA-FR-LYO',
    nextStationName: 'Lyon Part-Dieu',
    scheduledNextArrival: '16:12',
    estimatedNextArrival: '16:11',
    delayMinutes: -1,
    passengerLoadPercent: 94,
    currentPowerDrawKw: 7200,
    todayEnergyMWh: 340,
    regenerativeBrakingKw: 0,
    telemetry: {
      motorTempC: 72.1,
      motorCurrentA: 360,
      catenaryVoltageV: 25400,
      brakePipePressureKPa: 500,
      pantographVibrationG: 0.19,
      bearingVibrationMmS: 0.88,
      axleTemp1C: 53.9,
      axleTemp2C: 54.8,
      cabinTempC: 22.4,
      safetyBrakingDistanceMeters: 3600,
      tractionEfficiencyPercent: 93.9,
      anomalyScore: 4.0
    }
  },
  {
    id: 'TRN-LNER-782',
    serviceNumber: 'LNER 782 Flying Scotsman',
    rollingStockId: 'RS-CR400AF-2001',
    rollingStockModel: 'Azuma Class 800',
    operatorId: 'OP-LNER',
    countryId: 'GB',
    lineId: 'LINE-GB-ECML',
    originStationId: 'STA-GB-STP',
    originStationName: 'London Kings Cross',
    destinationStationId: 'STA-GB-EDB',
    destinationStationName: 'Edinburgh Waverley',
    trainType: 'STANDARD_EMU',
    status: 'DELAYED',
    currentCoordinates: [-1.2500, 53.7000],
    headingDeg: 340,
    currentSpeedKmH: 165,
    targetSpeedKmH: 200,
    routeProgressPercent: 42.0,
    nextStationId: 'STA-GB-EDB',
    nextStationName: 'York / Newcastle',
    scheduledNextArrival: '15:20',
    estimatedNextArrival: '15:32',
    delayMinutes: 12,
    passengerLoadPercent: 78,
    currentPowerDrawKw: 4200,
    todayEnergyMWh: 168,
    regenerativeBrakingKw: 0,
    telemetry: {
      motorTempC: 68.0,
      motorCurrentA: 280,
      catenaryVoltageV: 24800,
      brakePipePressureKPa: 500,
      pantographVibrationG: 0.28,
      bearingVibrationMmS: 1.10,
      axleTemp1C: 58.1,
      axleTemp2C: 59.2,
      cabinTempC: 21.0,
      safetyBrakingDistanceMeters: 2200,
      tractionEfficiencyPercent: 91.5,
      anomalyScore: 14.5
    }
  },
  {
    id: 'TRN-ACELA-2150',
    serviceNumber: 'Amtrak Acela 2150',
    rollingStockId: 'RS-ACELA2-01',
    rollingStockModel: 'Avelia Liberty',
    operatorId: 'OP-AMTRAK',
    countryId: 'US',
    lineId: 'LINE-US-NEC',
    originStationId: 'STA-US-WAS',
    originStationName: 'Washington Union',
    destinationStationId: 'STA-US-NYP',
    destinationStationName: 'New York Penn',
    trainType: 'HSR_EMU',
    status: 'RUNNING',
    currentCoordinates: [-75.3500, 39.8500],
    headingDeg: 45,
    currentSpeedKmH: 228,
    targetSpeedKmH: 240,
    routeProgressPercent: 61.5,
    nextStationId: 'STA-US-NYP',
    nextStationName: 'Philadelphia 30th St',
    scheduledNextArrival: '15:45',
    estimatedNextArrival: '15:48',
    delayMinutes: 3,
    passengerLoadPercent: 85,
    currentPowerDrawKw: 5100,
    todayEnergyMWh: 194,
    regenerativeBrakingKw: 0,
    telemetry: {
      motorTempC: 70.5,
      motorCurrentA: 320,
      catenaryVoltageV: 12500,
      brakePipePressureKPa: 620,
      pantographVibrationG: 0.20,
      bearingVibrationMmS: 0.85,
      axleTemp1C: 52.0,
      axleTemp2C: 53.1,
      cabinTempC: 22.2,
      safetyBrakingDistanceMeters: 2600,
      tractionEfficiencyPercent: 92.4,
      anomalyScore: 5.2
    }
  },
  {
    id: 'TRN-CRE-7501',
    serviceNumber: 'CR Express X8011 (Yiwu-Duisburg)',
    rollingStockId: 'RS-CR400AF-2001',
    rollingStockModel: 'HXD1 Heavy Electric Freight',
    operatorId: 'OP-CR-EXPRESS',
    countryId: 'CN',
    lineId: 'LINE-CORR-CR-EXPRESS',
    originStationId: 'STA-CN-ALA',
    originStationName: 'Yiwu International Dry Port',
    destinationStationId: 'STA-DE-BER',
    destinationStationName: 'Duisburg DIT Hub / Madrid',
    trainType: 'DIESEL_FREIGHT',
    status: 'RUNNING',
    currentCoordinates: [82.5200, 45.2100],
    headingDeg: 290,
    currentSpeedKmH: 110,
    targetSpeedKmH: 120,
    routeProgressPercent: 44.2,
    nextStationId: 'STA-KZ-DOS',
    nextStationName: 'Dostyk (Gauge Change & Customs)',
    scheduledNextArrival: '16:00',
    estimatedNextArrival: '16:00',
    delayMinutes: 0,
    passengerLoadPercent: 0,
    cargoTonnage: 3450, // 50 FEU containers
    currentPowerDrawKw: 7200,
    todayEnergyMWh: 680,
    regenerativeBrakingKw: 0,
    telemetry: {
      motorTempC: 78.5,
      motorCurrentA: 420,
      catenaryVoltageV: 26800,
      brakePipePressureKPa: 600,
      pantographVibrationG: 0.24,
      bearingVibrationMmS: 1.15,
      axleTemp1C: 61.2,
      axleTemp2C: 62.0,
      cabinTempC: 20.5,
      safetyBrakingDistanceMeters: 1400,
      tractionEfficiencyPercent: 89.5,
      anomalyScore: 6.8
    }
  }
];

export const INCIDENTS: Incident[] = [
  {
    id: 'INC-2026-0918-01',
    incidentNumber: 'INC-UK-ECML-782',
    countryId: 'GB',
    operatorId: 'OP-LNER',
    lineId: 'LINE-GB-ECML',
    stationId: 'STA-GB-EDB',
    severity: 'MAJOR',
    type: 'CATENARY_DROP',
    title: 'Overhead Catenary Sag & Tension Fault at Segment 782',
    description: 'High crosswinds (75 km/h) caused overhead line oscillation and safety speed limit drop from 200 to 160 km/h between Doncaster and York.',
    timestamp: '2026-09-18T07:15:00Z',
    affectedTrainsCount: 14,
    affectedPassengersEstimate: 6200,
    estimatedNetworkDelayMin: 34,
    responseStatus: 'ON_SITE_REPAIR',
    etaRecovery: '2026-09-18T10:30:00Z'
  },
  {
    id: 'INC-2026-0918-02',
    incidentNumber: 'INC-CN-SHH-CROWD',
    countryId: 'CN',
    operatorId: 'OP-CR',
    lineId: 'LINE-CN-BJ-SH-HSR',
    stationId: 'STA-CN-SHH',
    severity: 'MODERATE',
    type: 'PASSENGER_OBSTRUCTION',
    title: 'Shanghai Hongqiao Concourse Gate 14 Peak Inflow Control',
    description: 'Passenger arrival wave from 3 simultaneous arriving 16-car EMU services reached 92% concourse density; dynamic boarding gate pacing activated.',
    timestamp: '2026-09-18T07:42:00Z',
    affectedTrainsCount: 4,
    affectedPassengersEstimate: 3600,
    estimatedNetworkDelayMin: 4,
    responseStatus: 'RESTRICTED_OPS',
    etaRecovery: '2026-09-18T08:30:00Z'
  },
  {
    id: 'INC-2026-0918-03',
    incidentNumber: 'INC-DE-VDE8-SW',
    countryId: 'DE',
    operatorId: 'OP-DB',
    lineId: 'LINE-DE-VDE8-HSR',
    stationId: 'STA-DE-MUC',
    severity: 'MINOR',
    type: 'SIGNAL_FAILURE',
    title: 'ETCS Level 2 Radio Block Centre (RBC) Handover Latency',
    description: 'GSM-R / FRMCS channel handover jitter detected near Erfurt junction; backup balise transponder confirmed train integrity.',
    timestamp: '2026-09-18T06:50:00Z',
    affectedTrainsCount: 6,
    affectedPassengersEstimate: 2100,
    estimatedNetworkDelayMin: 6,
    responseStatus: 'RESOLVED',
    etaRecovery: '2026-09-18T07:35:00Z'
  }
];

export const INTERNATIONAL_CORRIDORS: InternationalCorridor[] = [
  {
    id: 'CORR-YIWU-MADRID',
    name: 'Yiwu - Madrid China-Europe Railway Express',
    nameZh: '义乌-马德里中欧班列跨国货运大通道',
    code: 'CRE-YIWU-MADRID',
    countries: ['CN', 'KZ', 'RU', 'BY', 'PL', 'DE', 'FR', 'ES'],
    totalDistanceKm: 13052,
    transitDays: 16.5,
    gaugeChanges: [
      {
        stationId: 'STA-CN-ALA',
        stationName: 'Alashankou / Dostyk',
        countryFrom: 'CN',
        countryTo: 'KZ',
        gaugeFrom: '1435mm_STANDARD',
        gaugeTo: '1520mm_BROAD_RUSSIAN',
        averageHandlingHours: 3.5
      },
      {
        stationId: 'STA-BY-BREST',
        stationName: 'Brest / Malaszewicze',
        countryFrom: 'BY',
        countryTo: 'PL',
        gaugeFrom: '1520mm_BROAD_RUSSIAN',
        gaugeTo: '1435mm_STANDARD',
        averageHandlingHours: 4.2
      },
      {
        stationId: 'STA-FR-HENDAYE',
        stationName: 'Hendaye / Irun (Pyrenees)',
        countryFrom: 'FR',
        countryTo: 'ES',
        gaugeFrom: '1435mm_STANDARD',
        gaugeTo: '1668mm_IBERIAN_BROAD' as any,
        averageHandlingHours: 3.0
      }
    ],
    activeFreightTrainsCount: 84,
    annualTeuContainers: 240000,
    interoperabilityStatus: 'FULL_STANDARD'
  }
];

export const GLOBAL_KPIS: NetworkKPIs = {
  globalActiveTrains: 18421,
  onTimePunctualityPercent: 96.4,
  totalNetworkKm: 1350000,
  dailyPassengersMillion: 84.5,
  dailyFreightMillionTonnes: 32.8,
  totalEnergyMWh: 42890,
  activeIncidentsCount: 42,
  averageDelayMinutes: 2.4,
  systemReliabilityPercent: 99.82,
  carbonSavedTonnesToday: 185400
};

export const TIMETABLE_CONFLICTS: TimetableConflict[] = [
  {
    id: 'CONF-01',
    type: 'HEADWAY_VIOLATION',
    lineId: 'LINE-CN-BJ-SH-HSR',
    trainId1: 'TRN-G1234',
    trainId2: 'TRN-G1',
    severity: 'MEDIUM',
    description: 'Dynamic headway between G1234 and leading G1 compressed to 2 min 40s (Minimum CTCS-3 spacing: 3 min 00s).',
    suggestedResolution: 'Regulate G1234 target speed to 330 km/h for 18 km segment to restore 3 min headway buffer.'
  }
];

export const SCENARIO_PRESETS: ScenarioSimulation[] = [
  {
    id: 'SCEN-BASELINE',
    name: 'Current Operational Baseline (Standard Schedule)',
    description: 'Real-time telemetry and schedule data under nominal operational conditions.',
    scenarioType: 'DEMAND_SURGE',
    parameters: { demandMultiplier: 1.0 }
  },
  {
    id: 'SCEN-PEAK-25',
    name: 'Spring Festival / Holiday Rush (+25% Passenger Demand)',
    description: 'Simulates 25% passenger load surge, platform dwell extension (+45s per station), and train frequency compression.',
    scenarioType: 'DEMAND_SURGE',
    parameters: { demandMultiplier: 1.25 },
    simulatedResults: {
      totalDelayMinutesDelta: 18.5,
      passengerCongestionPeakPercent: 94.2,
      cancelledServicesCount: 0,
      energySurgePercent: 22.4,
      bottleneckStations: ['Shanghai Hongqiao', 'Beijing South', 'Tokyo Station', 'New York Penn'],
      recommendedAction: 'Deploy 16 extra coupled EMU sets from reserves; dynamically unlock 4 backup platform tracks.'
    }
  },
  {
    id: 'SCEN-LINE-CLOSURE-6H',
    name: 'Track Closure Scenario (6h Emergency Maintenance)',
    description: 'Simulates complete blockage of Line Segment 782 on East Coast Main Line and evaluates downstream rerouting.',
    scenarioType: 'TRACK_CLOSURE',
    parameters: { targetLineId: 'LINE-GB-ECML', durationHours: 6 },
    simulatedResults: {
      totalDelayMinutesDelta: 142.0,
      passengerCongestionPeakPercent: 88.0,
      cancelledServicesCount: 8,
      energySurgePercent: -12.0,
      bottleneckStations: ['York', 'Doncaster', 'London Kings Cross'],
      recommendedAction: 'Divert 6 passenger services via Midland Main Line; dispatch 28 replacement electric coaches.'
    }
  }
];
