import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  Zap, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Search
} from 'lucide-react';
import { Station } from '../types/railway';
import { STATIONS, LIVE_TRAINS } from '../data/seedData';

interface StationDigitalTwinProps {
  selectedStationId?: string;
}

export const StationDigitalTwin: React.FC<StationDigitalTwinProps> = ({ selectedStationId }) => {
  const [stationId, setStationId] = useState<string>(selectedStationId || 'STA-CN-SHH');
  const [stationSearch, setStationSearch] = useState<string>('');

  const currentStation = STATIONS.find(s => s.id === stationId) || STATIONS[0];
  const stationTrains = LIVE_TRAINS.filter(t => 
    t.originStationName.includes(currentStation.nameZh) ||
    t.destinationStationName.includes(currentStation.nameZh) ||
    t.nextStationName.includes(currentStation.nameZh)
  );

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-y-auto font-sans">
      {/* Top Banner: Station Selector & Statistics */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-indigo-950/60 border border-indigo-800 rounded">
            <Building2 className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                STATION HUB DIGITAL TWIN / 车站数字孪生枢纽
              </h2>
              <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-800 px-1.5 py-0.5 rounded font-mono">
                {currentStation.platformsCount} PLATFORMS / {currentStation.tracksCount} TRACKS
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Platform Occupancy, Passenger Flow Heatmap, In-Station Dispatch & PIS Information
            </p>
          </div>
        </div>

        {/* Station Picker */}
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-400 font-mono">SELECT STATION:</span>
          <select
            value={stationId}
            onChange={(e) => setStationId(e.target.value)}
            className="bg-[#141a24] text-slate-200 border border-slate-700 text-xs rounded px-2.5 py-1 font-mono focus:outline-none focus:border-blue-500"
          >
            {STATIONS.map(s => (
              <option key={s.id} value={s.id}>
                {s.nameZh} ({s.name} - {s.countryId})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Station Hub Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4 min-h-0">
        
        {/* Left 2 Cols: Platform & Track Schematic Grid */}
        <div className="lg:col-span-2 flex flex-col space-y-4">
          
          {/* Station Overview KPI Header */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-indigo-400" />
                瞬时客流负荷 / CROWD
              </span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-indigo-300">
                  {currentStation.currentCrowdDensity}%
                </span>
                <span className="text-xs text-slate-400">({(currentStation.dailyFootfall || currentStation.dailyPassengerVolume).toLocaleString()} 今日)</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                平均停站时分 / DWELL
              </span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-slate-200">
                  {currentStation.averageDwellTimeSec || 180}
                </span>
                <span className="text-xs text-slate-400">秒 / s</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                牵引变电所负荷 / POWER
              </span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-amber-300">
                  34.8
                </span>
                <span className="text-xs text-slate-400">MW</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                股道占用率 / TRACKS
              </span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-emerald-400">
                  {Math.round((currentStation.tracksCount * 0.72))}/{currentStation.tracksCount}
                </span>
                <span className="text-xs text-slate-400">股道占用</span>
              </div>
            </div>
          </div>

          {/* Interactive Track & Platform Yard Matrix */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-4 space-y-3 flex-1">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="text-slate-300 font-mono font-bold uppercase flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                PLATFORM & TRACK OCCUPANCY SCHEMATIC (股道进路占用图)
              </span>
              <div className="flex items-center space-x-3 text-[10px] font-mono">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-sm bg-rose-600 inline-block" /> 占用 (OCCUPIED)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-600 inline-block" /> 空闲 (AVAILABLE)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-sm bg-amber-600 inline-block" /> 进路锁闭 (RESERVED)
                </span>
              </div>
            </div>

            {/* Render Tracks 1 through TracksCount */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 max-h-96 overflow-y-auto pt-1 font-mono text-xs">
              {Array.from({ length: currentStation.tracksCount }).map((_, idx) => {
                const trackNum = idx + 1;
                // Status distribution
                const isOccupied = trackNum % 3 === 0 || trackNum === 1 || trackNum === 5;
                const isReserved = trackNum % 4 === 0;
                const activeTrain = isOccupied ? (stationTrains[idx % stationTrains.length] || LIVE_TRAINS[0]) : null;

                return (
                  <div
                    key={trackNum}
                    className={`p-2.5 rounded border transition ${
                      isOccupied
                        ? 'bg-[#1e151b] border-rose-900/80 text-rose-200'
                        : isReserved
                        ? 'bg-[#1c1a14] border-amber-900/80 text-amber-200'
                        : 'bg-[#0d1715] border-emerald-900/80 text-emerald-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs">股道 Track {trackNum}</span>
                      <span className="text-[9px] px-1 py-0.5 rounded bg-black/40">
                        {isOccupied ? 'OCCUPIED' : isReserved ? 'RESERVED' : 'FREE'}
                      </span>
                    </div>

                    {isOccupied && activeTrain ? (
                      <div className="mt-1.5 space-y-0.5 text-[10px]">
                        <div className="font-bold text-white truncate">{activeTrain.serviceNumber}</div>
                        <div className="text-slate-400 text-[9px] truncate">
                          {activeTrain.destinationStationName}
                        </div>
                      </div>
                    ) : (
                      <div className="mt-1.5 text-[10px] text-slate-500">
                        {isReserved ? '进路排好 / 进站中' : '无车占用 / 待命'}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Real-time PIS Departure / Arrival Board */}
        <div className="flex flex-col space-y-3">
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3 flex-1 flex flex-col">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="font-mono font-bold text-slate-200 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                PIS REAL-TIME TIMETABLE (旅客导向信息屏)
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded">
                LIVE
              </span>
            </div>

            {/* PIS List */}
            <div className="flex-1 space-y-2 overflow-y-auto font-mono text-xs">
              {LIVE_TRAINS.map((train, i) => (
                <div key={train.id} className="p-2.5 bg-[#121824] rounded border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-white text-xs">{train.serviceNumber}</span>
                      <span className="text-[9px] bg-slate-800 text-slate-300 px-1 rounded">
                        检票口 {(i % 8) + 1}A/B
                      </span>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                      train.delayMinutes > 0 ? 'text-rose-400 bg-rose-950' : 'text-emerald-400 bg-emerald-950'
                    }`}>
                      {train.delayMinutes > 0 ? `晚点 +${train.delayMinutes}m` : '正点 / ON TIME'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="text-slate-300">{train.originStationName} ➔ {train.destinationStationName}</span>
                    <span className="text-slate-200">{train.scheduledNextArrival}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
