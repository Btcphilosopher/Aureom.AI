import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  Activity, 
  Layers, 
  Cpu, 
  Building2, 
  GitBranch, 
  AlertTriangle, 
  Truck, 
  Zap, 
  FlaskConical, 
  Bot, 
  Search, 
  Command, 
  ShieldCheck, 
  Radio,
  Clock
} from 'lucide-react';
import { Country, RailwayOperator } from '../types/railway';

interface HeaderNavProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  countries: Country[];
  operators: RailwayOperator[];
  selectedCountryId: string;
  onSelectCountry: (id: string) => void;
  selectedOperatorId: string;
  onSelectOperator: (id: string) => void;
  onOpenCommandPalette: () => void;
  activeTrainsCount: number;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentTab,
  onSelectTab,
  countries,
  operators,
  selectedCountryId,
  onSelectCountry,
  selectedOperatorId,
  onSelectOperator,
  onOpenCommandPalette,
  activeTrainsCount
}) => {
  const [utcTime, setUtcTime] = useState<string>('');
  const [bjTime, setBjTime] = useState<string>('');

  useEffect(() => {
    const updateTimes = () => {
      const now = new Date();
      setUtcTime(now.toUTCString().slice(17, 25) + ' UTC');
      setBjTime(
        new Intl.DateTimeFormat('zh-CN', {
          timeZone: 'Asia/Shanghai',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false
        }).format(now) + ' CST'
      );
    };
    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    return () => clearInterval(interval);
  }, []);

  const tabs = [
    { id: 'occ', label: 'OPERATIONS CONTROL', icon: Activity, badge: 'LIVE' },
    { id: 'map', label: 'GLOBAL GIS MAP', icon: Globe },
    { id: 'twin', label: 'ROLLING STOCK TWIN', icon: Cpu },
    { id: 'station', label: 'STATION TWIN', icon: Building2 },
    { id: 'timetable', label: 'TIMETABLE & STRINGLINE', icon: GitBranch },
    { id: 'delay', label: 'DELAY INTELLIGENCE', icon: AlertTriangle },
    { id: 'freight', label: 'CORRIDORS & FREIGHT', icon: Truck },
    { id: 'energy', label: 'ENERGY & INFRA', icon: Zap },
    { id: 'scenario', label: 'SCENARIO LAB', icon: FlaskConical },
    { id: 'ai', label: 'AI ASSISTANT', icon: Bot, highlight: true },
    { id: 'governance', label: 'URDM GOVERNANCE', icon: ShieldCheck }
  ];

  return (
    <header className="bg-[#0f131a] border-b border-[#1f2937] text-slate-200 select-none z-30 sticky top-0">
      {/* Top Banner: Brand, Railway Master Time, System Status */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#0a0d13] border-b border-[#18202c] text-xs">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-sm bg-[#20bf6b] signal-glow-green animate-pulse" />
            <span className="font-display font-bold text-sm tracking-wider text-slate-100 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-emerald-400 inline" />
              GLOBAL RAILWAY CLOUD
              <span className="text-[10px] bg-slate-800 text-emerald-400 px-1.5 py-0.5 rounded font-mono">
                GRC v3.7 OS
              </span>
            </span>
          </div>
          <span className="text-slate-600">|</span>
          <div className="hidden md:flex items-center space-x-2 text-slate-400">
            <Radio className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
            <span className="font-mono text-[11px]">NETWORK STATUS: 100% OPERATIONAL</span>
          </div>
        </div>

        {/* Global Controls & Clocks */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3 font-mono-num text-[11px] text-slate-300 bg-[#121722] px-2.5 py-1 rounded border border-slate-800">
            <div className="flex items-center space-x-1.5">
              <Clock className="w-3 h-3 text-slate-400" />
              <span className="text-slate-400">UTC:</span>
              <span className="text-slate-100 font-semibold">{utcTime}</span>
            </div>
            <span className="text-slate-700">|</span>
            <div className="flex items-center space-x-1.5">
              <span className="text-emerald-400 font-semibold">BJ:</span>
              <span className="text-emerald-300 font-semibold">{bjTime}</span>
            </div>
          </div>

          {/* Quick Search / Command Palette Button */}
          <button
            onClick={onOpenCommandPalette}
            className="flex items-center space-x-2 bg-[#171f2d] hover:bg-[#202b3e] text-slate-300 px-2.5 py-1 rounded border border-slate-700 text-xs transition cursor-pointer"
            title="Press Ctrl+K or Cmd+K to open Command Palette"
          >
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[11px] text-slate-400 hidden sm:inline">Search Train, Station, Line...</span>
            <kbd className="bg-slate-800 text-slate-300 text-[10px] px-1 py-0.5 rounded border border-slate-700 flex items-center gap-0.5">
              <Command className="w-2.5 h-2.5" /> K
            </kbd>
          </button>
        </div>
      </div>

      {/* Primary Navigation Bar & Tenancy Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 overflow-x-auto no-scrollbar gap-2 bg-[#0f131a]">
        {/* Navigation Tabs */}
        <nav className="flex items-center space-x-1">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded text-[11px] font-semibold tracking-wide uppercase transition cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#1e293b] text-blue-400 border border-blue-500/40 shadow-sm'
                    : tab.highlight
                    ? 'bg-purple-950/40 text-purple-300 border border-purple-800/40 hover:bg-purple-900/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#161d28]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-400' : tab.highlight ? 'text-purple-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-1 rounded-sm font-mono font-normal">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Tenant / Country Filter Selector */}
        <div className="flex items-center space-x-2 pl-3 border-l border-slate-800">
          <div className="flex items-center space-x-1.5">
            <span className="text-[10px] text-slate-500 font-mono uppercase">Country:</span>
            <select
              value={selectedCountryId}
              onChange={(e) => onSelectCountry(e.target.value)}
              className="bg-[#141a24] text-slate-200 border border-slate-700 text-xs rounded px-2 py-1 focus:outline-none focus:border-blue-500 font-mono"
            >
              <option value="ALL">🌐 GLOBAL NETWORK</option>
              {countries.map(c => (
                <option key={c.id} value={c.id}>
                  {c.flag} {c.nameZh} ({c.name})
                </option>
              ))}
            </select>
          </div>

          <div className="hidden lg:flex items-center space-x-1.5">
            <span className="text-[10px] text-slate-500 font-mono uppercase">Operator:</span>
            <select
              value={selectedOperatorId}
              onChange={(e) => onSelectOperator(e.target.value)}
              className="bg-[#141a24] text-slate-200 border border-slate-700 text-xs rounded px-2 py-1 focus:outline-none focus:border-blue-500 font-mono"
            >
              <option value="ALL">ALL OPERATORS</option>
              {operators
                .filter(o => selectedCountryId === 'ALL' || o.countryId === selectedCountryId)
                .map(o => (
                  <option key={o.id} value={o.id}>
                    {o.logo} {o.shortCode} - {o.nameZh}
                  </option>
                ))}
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};
