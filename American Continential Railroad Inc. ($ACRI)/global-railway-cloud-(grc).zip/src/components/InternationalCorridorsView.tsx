import React, { useState } from 'react';
import { 
  Truck, 
  Globe, 
  Layers, 
  MapPin, 
  CheckCircle2, 
  Clock, 
  Activity, 
  ArrowRight,
  ShieldCheck,
  Zap,
  Container
} from 'lucide-react';
import { INTERNATIONAL_CORRIDORS } from '../data/seedData';
import { InternationalCorridor } from '../types/railway';

export const InternationalCorridorsView: React.FC = () => {
  const [selectedCorridorId, setSelectedCorridorId] = useState<string>(INTERNATIONAL_CORRIDORS[0].id);
  const currentCorridor = INTERNATIONAL_CORRIDORS.find(c => c.id === selectedCorridorId) || INTERNATIONAL_CORRIDORS[0];

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-y-auto font-sans">
      {/* Top Banner */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-emerald-950/60 border border-emerald-800 rounded">
            <Truck className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                INTERNATIONAL CORRIDORS & CROSS-BORDER FREIGHT / 国际走廊与跨境货运
              </h2>
              <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-1.5 py-0.5 rounded font-mono">
                INTERCONTINENTAL LOGISTICS
              </span>
            </div>
            <p className="text-xs text-slate-400">
              China-Europe Railway Express (中欧班列), Gauge-Change Yards & North American Double-Stack Rail
            </p>
          </div>
        </div>

        {/* Corridor Selector */}
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-400 font-mono">CORRIDOR:</span>
          <select
            value={selectedCorridorId}
            onChange={(e) => setSelectedCorridorId(e.target.value)}
            className="bg-[#141a24] text-slate-200 border border-slate-700 text-xs rounded px-2.5 py-1 font-mono focus:outline-none focus:border-blue-500"
          >
            {INTERNATIONAL_CORRIDORS.map(cor => (
              <option key={cor.id} value={cor.id}>
                {cor.nameZh} ({(cor.totalLengthKm || cor.totalDistanceKm).toLocaleString()} km)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4 min-h-0">
        
        {/* Left 2 Cols: Corridor Waypoint & Gauge Transshipment Sequence */}
        <div className="lg:col-span-2 flex flex-col space-y-4">
          {/* Key Metrics Header */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono">全程里程 / LENGTH</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-emerald-400">
                  {(currentCorridor.totalLengthKm || currentCorridor.totalDistanceKm).toLocaleString()}
                </span>
                <span className="text-xs text-slate-400">km</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono">过境国家 / COUNTRIES</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-blue-400">
                  {(currentCorridor.countriesCrossed || currentCorridor.countries).length}
                </span>
                <span className="text-xs text-slate-400">国联运</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono">在途集装箱 / TEU LOAD</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-indigo-300">
                  {(currentCorridor.annualTeuCapacity || currentCorridor.annualTeuContainers).toLocaleString()}
                </span>
                <span className="text-xs text-slate-400">TEU</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono">全程平均时效 / TRANSIT</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-amber-400">
                  {currentCorridor.averageTransitDays || currentCorridor.transitDays}
                </span>
                <span className="text-xs text-slate-400">天 / Days</span>
              </div>
            </div>
          </div>

          {/* Gauge Changeover & Transshipment Stations */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-4 space-y-3 flex-1">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="font-mono font-bold text-slate-200 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                BORDER GAUGE CHANGEOVER YARDS / 跨国轨距换装与海关查验节点
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded">
                ELECTRONIC CIM/SMGS CONSIST
              </span>
            </div>

            <div className="space-y-3 pt-2">
              {(currentCorridor.gaugeBreakPoints || currentCorridor.gaugeChanges || []).map((gp: any, idx: number) => (
                <div key={gp.stationName || idx} className="p-3.5 bg-[#121824] rounded-lg border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-5 h-5 rounded bg-blue-900/60 text-blue-300 flex items-center justify-center font-mono font-bold text-xs">
                        {idx + 1}
                      </div>
                      <span className="font-mono font-bold text-white text-sm">
                        {gp.stationName} ({gp.country || gp.countryTo})
                      </span>
                    </div>
                    <span className="text-[11px] font-mono bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded">
                      平均换装作业时效: {gp.averageTransshipmentHours || gp.averageHandlingHours || 3.5} 小时
                    </span>
                  </div>

                  <div className="flex items-center space-x-3 text-xs font-mono text-slate-300 pt-1">
                    <span className="text-slate-400">轨距变换:</span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200">{gp.fromGauge || gp.gaugeFrom}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-blue-400" />
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200">{gp.toGauge || gp.gaugeTo}</span>
                  </div>

                  <div className="text-xs text-slate-400 flex items-center justify-between pt-1">
                    <span>换装方式: {gp.method || '门吊整列快速换装 / 自动化轨距调节'}</span>
                    <span className="text-emerald-400 font-mono text-[11px]">海关单证: 自动放行 (Green Lane)</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Live Block Trains Tracking */}
        <div className="flex flex-col space-y-3">
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3 flex-1 flex flex-col">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="font-mono font-bold text-slate-200 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                ACTIVE CR EXPRESS BLOCK TRAINS (在途班列)
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded">
                8 TRAINS
              </span>
            </div>

            <div className="flex-1 space-y-2 overflow-y-auto font-mono text-xs">
              {[
                { code: 'X8011 (义乌 - 马德里)', load: '50 车 / 100 TEU', speed: '95 km/h', loc: '哈萨克斯坦 阿斯塔纳', status: 'RUNNING' },
                { code: 'X8024 (西安 - 杜伊斯堡)', load: '55 车 / 110 TEU', speed: '102 km/h', loc: '波兰 马拉舍维奇', status: 'TRANSSHIP' },
                { code: 'X9002 (重庆 - 莫斯科)', load: '48 车 / 96 TEU', speed: '88 km/h', loc: '满洲里 口岸站', status: 'CUSTOMS' },
                { code: 'X8102 (成都 - 罗兹)', load: '52 车 / 104 TEU', speed: '98 km/h', loc: '白俄罗斯 布列斯特', status: 'RUNNING' },
                { code: 'BNSF-7422 (Chicago - LA)', load: 'Double Stack 220 TEU', speed: '110 km/h', loc: 'Flagstaff, AZ', status: 'RUNNING' }
              ].map(bt => (
                <div key={bt.code} className="p-2.5 bg-[#121824] rounded border border-slate-800 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white text-xs">{bt.code}</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {bt.status}
                    </span>
                  </div>
                  <div className="text-slate-400 text-[11px]">当前位置: {bt.loc}</div>
                  <div className="flex justify-between text-slate-500 text-[10px] pt-1">
                    <span>编组: {bt.load}</span>
                    <span className="text-emerald-400 font-bold">{bt.speed}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
