import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { 
  Cpu, 
  Activity, 
  Zap, 
  ShieldCheck, 
  AlertTriangle, 
  RotateCcw, 
  Eye, 
  Layers, 
  Wrench, 
  Thermometer, 
  Gauge,
  Sliders,
  CheckCircle2
} from 'lucide-react';
import { Train, RollingStock } from '../types/railway';
import { ROLLING_STOCK_FLEET, LIVE_TRAINS } from '../data/seedData';

interface TrainDigitalTwinProps {
  initialTrain?: Train | null;
}

export const TrainDigitalTwin: React.FC<TrainDigitalTwinProps> = ({ initialTrain }) => {
  const [selectedFleetId, setSelectedFleetId] = useState<string>(
    initialTrain?.rollingStockId || 'RS-CR400AF-001'
  );
  const [selectedSubsystem, setSelectedSubsystem] = useState<string>('BOGIE');
  const [isExplodedView, setIsExplodedView] = useState<boolean>(false);
  const [isRotating, setIsRotating] = useState<boolean>(true);
  const [selectedCoachIndex, setSelectedCoachIndex] = useState<number>(2); // Car 03 M1

  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const trainGroupRef = useRef<THREE.Group | null>(null);
  const partsRef = useRef<{ [key: string]: THREE.Object3D }>({});

  const currentRollingStock = ROLLING_STOCK_FLEET.find(rs => rs.id === selectedFleetId) || ROLLING_STOCK_FLEET[0];
  const matchingTrain = LIVE_TRAINS.find(t => t.rollingStockId === selectedFleetId) || LIVE_TRAINS[0];

  // Initialize Three.js 3D Train Scene
  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight || 450;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0e17);
    scene.fog = new THREE.FogExp2(0x0a0e17, 0.015);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(18, 10, 25);
    camera.lookAt(0, 2, 0);

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 1.8);
    dirLight1.position.set(20, 40, 20);
    dirLight1.castShadow = true;
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x10b981, 1.2);
    dirLight2.position.set(-20, 20, -20);
    scene.add(dirLight2);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(60, 60, 0x1e293b, 0x0f172a);
    gridHelper.position.y = -0.5;
    scene.add(gridHelper);

    // Rails
    const railMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.2 });
    const railGeom = new THREE.BoxGeometry(0.2, 0.3, 50);
    const rail1 = new THREE.Mesh(railGeom, railMat);
    rail1.position.set(-1.435 / 2, -0.35, 0);
    const rail2 = new THREE.Mesh(railGeom, railMat);
    rail2.position.set(1.435 / 2, -0.35, 0);
    scene.add(rail1);
    scene.add(rail2);

    // Build Procedural High-Speed Train Mesh
    const trainGroup = new THREE.Group();
    trainGroupRef.current = trainGroup;
    partsRef.current = {};

    // 1. Aerodynamic Streamlined Nose & Carbody
    const bodyMat = new THREE.MeshStandardMaterial({
      color: currentRollingStock.model.includes('CR400') ? 0xededed : 0xdde6ed,
      metalness: 0.4,
      roughness: 0.3
    });
    const stripeMat = new THREE.MeshStandardMaterial({
      color: currentRollingStock.model.includes('CR400') ? 0xb91c1c : 0x1d4ed8,
      metalness: 0.5,
      roughness: 0.2
    });
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.9,
      roughness: 0.1
    });

    // Carbody main section
    const bodyGeom = new THREE.BoxGeometry(3.2, 3.4, 22);
    const bodyMesh = new THREE.Mesh(bodyGeom, bodyMat);
    bodyMesh.position.set(0, 2.5, 0);
    bodyMesh.castShadow = true;
    trainGroup.add(bodyMesh);
    partsRef.current['CARBODY'] = bodyMesh;

    // Aerodynamic Nose Wedge
    const noseGeom = new THREE.ConeGeometry(2.3, 7, 32);
    noseGeom.rotateX(Math.PI / 2);
    const noseMesh = new THREE.Mesh(noseGeom, bodyMat);
    noseMesh.position.set(0, 2.3, 14.2);
    noseMesh.scale.set(1, 0.75, 1);
    trainGroup.add(noseMesh);

    // Red/Blue Livery Accent Stripe
    const stripeGeom = new THREE.BoxGeometry(3.25, 0.35, 26);
    const stripeMesh = new THREE.Mesh(stripeGeom, stripeMat);
    stripeMesh.position.set(0, 2.0, 2);
    trainGroup.add(stripeMesh);

    // Windshield & Windows
    const windshieldGeom = new THREE.BoxGeometry(2.4, 0.9, 2.5);
    const windshield = new THREE.Mesh(windshieldGeom, glassMat);
    windshield.position.set(0, 3.2, 12);
    windshield.rotateX(-Math.PI / 8);
    trainGroup.add(windshield);

    // 2. Pantograph (Roof Subsystem)
    const pantoGroup = new THREE.Group();
    pantoGroup.position.set(0, 4.4, -6);
    const pantoMat = new THREE.MeshStandardMaterial({ color: 0xe11d48, metalness: 0.8, roughness: 0.2 });
    const arm1 = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.2), pantoMat);
    arm1.rotateX(Math.PI / 4);
    arm1.position.set(0, 0.8, 0.5);
    const arm2 = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.2), pantoMat);
    arm2.rotateX(-Math.PI / 4);
    arm2.position.set(0, 1.6, -0.2);
    const headBar = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.08, 0.3), pantoMat);
    headBar.position.set(0, 2.4, -0.9);
    pantoGroup.add(arm1);
    pantoGroup.add(arm2);
    pantoGroup.add(headBar);
    trainGroup.add(pantoGroup);
    partsRef.current['PANTOGRAPH'] = pantoGroup;

    // 3. Bogies & Wheelsets (Front & Rear)
    const bogieMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.4 });
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.95, roughness: 0.1 });
    const motorMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.7, roughness: 0.3 });

    const createBogie = (zOffset: number) => {
      const bgGroup = new THREE.Group();
      bgGroup.position.set(0, 0.6, zOffset);

      // Frame
      const frame = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.4, 5.0), bogieMat);
      bgGroup.add(frame);

      // Traction Motors (Orange)
      const motor1 = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 1.2), motorMat);
      motor1.rotateZ(Math.PI / 2);
      motor1.position.set(0, 0.2, 1.2);
      const motor2 = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 1.2), motorMat);
      motor2.rotateZ(Math.PI / 2);
      motor2.position.set(0, 0.2, -1.2);
      bgGroup.add(motor1);
      bgGroup.add(motor2);

      // 4 Wheels
      [-1.5, 1.5].forEach(z => {
        [-1.435 / 2, 1.435 / 2].forEach(x => {
          const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.15, 32), wheelMat);
          wheel.rotateZ(Math.PI / 2);
          wheel.position.set(x, 0, z);
          bgGroup.add(wheel);
        });
      });

      return bgGroup;
    };

    const frontBogie = createBogie(6.5);
    const rearBogie = createBogie(-6.5);
    trainGroup.add(frontBogie);
    trainGroup.add(rearBogie);
    partsRef.current['BOGIE'] = frontBogie;
    partsRef.current['TRACTION_MOTOR'] = frontBogie;
    partsRef.current['BRAKES'] = rearBogie;

    scene.add(trainGroup);

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (isRotating && trainGroupRef.current) {
        trainGroupRef.current.rotation.y += 0.003;
      }
      renderer.render(scene, camera);
    };
    animate();

    // Resize Handler
    const handleResize = () => {
      if (!mountRef.current || !rendererRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight || 450;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (renderer.domElement && mountRef.current) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [selectedFleetId, isRotating]);

  // Exploded View Effect
  useEffect(() => {
    if (!partsRef.current['PANTOGRAPH'] || !partsRef.current['CARBODY'] || !partsRef.current['BOGIE']) return;
    if (isExplodedView) {
      partsRef.current['PANTOGRAPH'].position.y = 8.5;
      partsRef.current['CARBODY'].position.y = 4.5;
      partsRef.current['BOGIE'].position.y = -1.2;
    } else {
      partsRef.current['PANTOGRAPH'].position.y = 4.4;
      partsRef.current['CARBODY'].position.y = 2.5;
      partsRef.current['BOGIE'].position.y = 0.6;
    }
  }, [isExplodedView]);

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-y-auto font-sans">
      {/* Top Banner: Fleet Selector & Status */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-950/60 border border-blue-800 rounded">
            <Cpu className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                ROLLING STOCK DIGITAL TWIN
              </h2>
              <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-1.5 py-0.5 rounded font-mono">
                PHYSICS FIDELITY: 100%
              </span>
            </div>
            <p className="text-xs text-slate-400">
              High-Speed EMU Telemetry, Subsystems Diagnostics & Predictive Maintenance (PHM)
            </p>
          </div>
        </div>

        {/* Fleet Model Selector */}
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-400 font-mono">SELECT FLEET:</span>
          <select
            value={selectedFleetId}
            onChange={(e) => setSelectedFleetId(e.target.value)}
            className="bg-[#141a24] text-slate-200 border border-slate-700 text-xs rounded px-2.5 py-1 font-mono focus:outline-none focus:border-blue-500"
          >
            {ROLLING_STOCK_FLEET.map(rs => (
              <option key={rs.id} value={rs.id}>
                {rs.model} ({rs.manufacturer} - {rs.formation})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Digital Twin Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4 min-h-0">
        
        {/* Left 2 Cols: 3D Interactive WebGL Canvas & Carbody Coach Trainset Selector */}
        <div className="lg:col-span-2 flex flex-col space-y-3">
          {/* 3D Viewport Box */}
          <div className="relative flex-1 min-h-[380px] bg-[#0c1018] rounded-lg border border-[#1e293b] overflow-hidden shadow-inner flex flex-col">
            {/* Viewport Overlay Controls */}
            <div className="absolute top-3 left-3 z-10 flex items-center space-x-2 bg-[#121722]/90 backdrop-blur-md px-3 py-1.5 rounded border border-slate-700">
              <span className="text-xs font-mono font-bold text-emerald-400">
                {currentRollingStock.model}
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-[11px] font-mono text-slate-300">
                HEALTH SCORE: <strong className="text-emerald-400">{currentRollingStock.telemetryHealthScore}</strong>/100
              </span>
            </div>

            <div className="absolute top-3 right-3 z-10 flex items-center space-x-1 bg-[#121722]/90 backdrop-blur-md p-1 rounded border border-slate-700">
              <button
                onClick={() => setIsExplodedView(!isExplodedView)}
                className={`px-2 py-1 rounded text-xs font-mono flex items-center gap-1 transition cursor-pointer ${
                  isExplodedView ? 'bg-blue-600 text-white' : 'hover:bg-slate-700 text-slate-300'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{isExplodedView ? 'COLLAPSE' : 'EXPLODE'}</span>
              </button>
              <button
                onClick={() => setIsRotating(!isRotating)}
                className={`p-1.5 rounded transition cursor-pointer ${
                  isRotating ? 'bg-emerald-900/60 text-emerald-300' : 'hover:bg-slate-700 text-slate-400'
                }`}
                title="Toggle Auto Rotation"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Three.js Canvas Container */}
            <div ref={mountRef} className="flex-1 w-full h-full min-h-[380px]" />
          </div>

          {/* 8-Car Coach Trainset Topology Bar */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-semibold font-mono flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-blue-400" />
                8-CAR EMU COMPOSITION FORMATION (8M/0T or 4M4T)
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                CLICK CAR FOR SUBSYSTEM TELEMETRY
              </span>
            </div>

            <div className="grid grid-cols-8 gap-1.5 font-mono text-[11px]">
              {[
                { num: '01', type: 'Tc', role: 'Cab / Control Trailer', health: 99.2 },
                { num: '02', type: 'M1', role: 'Motor / Inverter', health: 98.4 },
                { num: '03', type: 'Tp', role: 'Pantograph / Transformer', health: 97.9 },
                { num: '04', type: 'M2', role: 'Motor / Traction', health: 98.6 },
                { num: '05', type: 'T', role: 'Buffet / Bistro Coach', health: 99.5 },
                { num: '06', type: 'Tp', role: 'Pantograph / Transformer', health: 98.1 },
                { num: '07', type: 'M3', role: 'Motor / Traction', health: 98.8 },
                { num: '08', type: 'Tc', role: 'Cab / Control Trailer', health: 99.1 }
              ].map((car, idx) => {
                const isSelected = selectedCoachIndex === idx;
                return (
                  <button
                    key={car.num}
                    onClick={() => setSelectedCoachIndex(idx)}
                    className={`p-2 rounded border text-center transition cursor-pointer ${
                      isSelected
                        ? 'bg-blue-900/60 border-blue-500 text-white shadow-md'
                        : 'bg-[#121824] border-slate-800 hover:border-slate-600 text-slate-300'
                    }`}
                  >
                    <div className="font-bold text-xs">Car {car.num}</div>
                    <div className="text-[10px] text-blue-400 font-semibold">{car.type}</div>
                    <div className="text-[9px] text-emerald-400 mt-1">{car.health}%</div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Subsystems Diagnostics & PHM Predictive Maintenance */}
        <div className="flex flex-col space-y-3">
          {/* Subsystem Selector Tabs */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3 space-y-3">
            <div className="text-xs font-mono font-bold text-slate-300 uppercase flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Wrench className="w-3.5 h-3.5 text-amber-400" />
                SUBSYSTEM DIAGNOSTICS
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1.5 font-mono text-[11px]">
              {[
                { id: 'TRACTION', label: 'Traction Motors' },
                { id: 'BOGIE', label: 'Bogie & Bearings' },
                { id: 'PANTOGRAPH', label: 'Pantograph & Bow' },
                { id: 'BRAKES', label: 'EP Air Brakes' },
                { id: 'HVAC', label: 'Auxiliary & HVAC' },
                { id: 'BATTERY', label: 'Battery / DC Bus' }
              ].map(sub => (
                <button
                  key={sub.id}
                  onClick={() => setSelectedSubsystem(sub.id)}
                  className={`p-2 rounded border text-left transition cursor-pointer ${
                    selectedSubsystem === sub.id
                      ? 'bg-amber-950/60 border-amber-500 text-amber-200 font-semibold'
                      : 'bg-[#121824] border-slate-800 hover:bg-[#18202c] text-slate-400'
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>
          </div>

          {/* Real-time Subsystem Gauge Telemetry Cards */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3 flex-1">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                {selectedSubsystem} LIVE TELEMETRY
              </span>
              <span className="font-mono text-emerald-400 text-[10px] bg-emerald-950 px-1.5 py-0.5 rounded">
                NORMAL STATUS
              </span>
            </div>

            {selectedSubsystem === 'BOGIE' && (
              <div className="space-y-2.5 font-mono text-xs">
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">轴箱轴承振动 (RMS):</span>
                  <span className="text-emerald-400 font-bold">{matchingTrain.telemetry.bearingVibrationMmS} mm/s</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">1位轴温 (Axle 1 Temp):</span>
                  <span className="text-slate-200 font-bold">{matchingTrain.telemetry.axleTemp1C} °C</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">车轮踏面磨耗深度:</span>
                  <span className="text-slate-200 font-bold">1.42 mm (限度 7.0mm)</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">空簧附加气室压力:</span>
                  <span className="text-slate-200 font-bold">480 kPa</span>
                </div>
              </div>
            )}

            {selectedSubsystem === 'TRACTION' && (
              <div className="space-y-2.5 font-mono text-xs">
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">牵引电机定子温度:</span>
                  <span className="text-amber-400 font-bold">{matchingTrain.telemetry.motorTempC} °C</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">逆变器三相输出电流:</span>
                  <span className="text-slate-200 font-bold">{matchingTrain.telemetry.motorCurrentA} A</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">当前总牵引功率:</span>
                  <span className="text-emerald-400 font-bold">{matchingTrain.currentPowerDrawKw} kW</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">变压器油温 (Oil Temp):</span>
                  <span className="text-slate-200 font-bold">54.2 °C</span>
                </div>
              </div>
            )}

            {selectedSubsystem === 'PANTOGRAPH' && (
              <div className="space-y-2.5 font-mono text-xs">
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">接触网电网电压:</span>
                  <span className="text-emerald-400 font-bold">{matchingTrain.telemetry.catenaryVoltageV} V</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">受电弓垂直加速度:</span>
                  <span className="text-slate-200 font-bold">{matchingTrain.telemetry.pantographVibrationG} g</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">碳滑板剩余厚度:</span>
                  <span className="text-slate-200 font-bold">22.4 mm (限度 5.0mm)</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">离线燃弧率 (Arcing Rate):</span>
                  <span className="text-emerald-400 font-bold">0.02% (优)</span>
                </div>
              </div>
            )}

            {selectedSubsystem !== 'BOGIE' && selectedSubsystem !== 'TRACTION' && selectedSubsystem !== 'PANTOGRAPH' && (
              <div className="space-y-2.5 font-mono text-xs">
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">列车管总风压力:</span>
                  <span className="text-slate-200 font-bold">{matchingTrain.telemetry.brakePipePressureKPa} kPa</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">客室平均温度:</span>
                  <span className="text-emerald-400 font-bold">{matchingTrain.telemetry.cabinTempC} °C</span>
                </div>
                <div className="bg-[#121824] p-2.5 rounded border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">蓄电池充放电电压:</span>
                  <span className="text-slate-200 font-bold">110.4 V (100% SoC)</span>
                </div>
              </div>
            )}

            {/* Predictive Maintenance / RUL Section */}
            <div className="mt-4 pt-3 border-t border-slate-800 space-y-2">
              <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                <span>PHM 预测性健康管理 (RUL)</span>
                <span className="text-emerald-400 font-mono text-[11px]">780 Operating Hours Remaining</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: '92%' }} />
              </div>
              <div className="text-[10px] text-slate-400 font-mono flex items-center justify-between pt-1">
                <span>下次三级修 / Level 3 Overhaul: 2026-11-20</span>
                <span className="text-slate-500">CRC Shanghai Depot</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
