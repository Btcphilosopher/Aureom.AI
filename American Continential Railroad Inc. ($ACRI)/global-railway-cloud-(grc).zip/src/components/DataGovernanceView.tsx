import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Database, 
  Clock, 
  FileCode, 
  Download, 
  CheckCircle2, 
  Layers, 
  Cpu, 
  History 
} from 'lucide-react';

export const DataGovernanceView: React.FC = () => {
  const [pitQueryTimestamp, setPitQueryTimestamp] = useState<string>('2026-06-01T08:00:00Z');
  const [pitResult, setPitResult] = useState<any>(null);
  const [isQuerying, setIsQuerying] = useState<boolean>(false);

  const handleRunPointInTime = () => {
    setIsQuerying(true);
    setTimeout(() => {
      setPitResult({
        queryTimestamp: pitQueryTimestamp,
        recordedTimestamp: new Date().toISOString(),
        networkKm: '135,000 km',
        activeTrainPositions: 18420,
        dataLineageHash: 'sha256-8f4b23c91a0b32948e58129031d2',
        complianceStandard: 'ISO 22163 (IRIS) / RailML 3.2 URDM'
      });
      setIsQuerying(false);
    }, 600);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-y-auto font-sans">
      {/* Top Banner */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-slate-800 border border-slate-700 rounded">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                URDM DATA GOVERNANCE & POINT-IN-TIME WAREHOUSE / 数据治理与历史溯源
              </h2>
              <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-1.5 py-0.5 rounded font-mono">
                BI-TEMPORAL TIMESCALEDB
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Universal Railway Data Model (URDM) Schemas, Point-in-Time Auditing & Cross-Standard Interoperability
            </p>
          </div>
        </div>

        <button className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#17202e] hover:bg-[#202b3e] text-slate-200 rounded border border-slate-700 text-xs font-mono transition cursor-pointer">
          <Download className="w-3.5 h-3.5 text-blue-400" />
          <span>EXPORT URDM SCHEMA (JSON)</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4 min-h-0">
        
        {/* Left 2 Cols: Bi-temporal Point-in-Time Query Engine */}
        <div className="lg:col-span-2 flex flex-col space-y-4">
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs">
              <span className="font-mono font-bold text-slate-200 flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-blue-400" />
                BI-TEMPORAL POINT-IN-TIME RAILWAY REPLAY (历史断面溯源查询)
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                Supports Investigation & Post-Incident Replay
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">
                  有效业务时间 (Effective / Event Time):
                </label>
                <input
                  type="datetime-local"
                  value={pitQueryTimestamp.slice(0, 16)}
                  onChange={(e) => setPitQueryTimestamp(e.target.value + ':00Z')}
                  className="w-full bg-[#121824] border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-end">
                <button
                  onClick={handleRunPointInTime}
                  disabled={isQuerying}
                  className="w-full py-2 rounded bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs font-bold transition cursor-pointer disabled:opacity-50"
                >
                  {isQuerying ? 'RECONSTRUCTING STATE...' : 'QUERY HISTORICAL SNAPSHOT'}
                </button>
              </div>
            </div>

            {pitResult && (
              <div className="p-3.5 bg-[#121824] rounded-lg border border-slate-800 space-y-2 font-mono text-xs">
                <div className="text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  Point-in-Time State Successfully Reconstructed
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-300 text-[11px] pt-1">
                  <div>• Reconstructed Network Track: <span className="text-white">{pitResult.networkKm}</span></div>
                  <div>• Active Tracked Entities: <span className="text-white">{pitResult.activeTrainPositions} trains</span></div>
                  <div>• Lineage Audit Hash: <span className="text-blue-300 truncate">{pitResult.dataLineageHash}</span></div>
                  <div>• Compliance: <span className="text-emerald-300">{pitResult.complianceStandard}</span></div>
                </div>
              </div>
            )}
          </div>

          {/* Supported Global Standards Compatibility */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-4 space-y-3 flex-1">
            <div className="text-xs font-mono font-bold text-slate-200 uppercase border-b border-slate-800 pb-2">
              SUPPORTED STANDARDS & PROTOCOLS
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
              {[
                { name: 'China Railway CTCS / TG / TDCS', desc: 'Full high-speed 350km/h dispatch telemetry and CTC interlocking spec.', status: 'NATIVE' },
                { name: 'RailML 3.x / European ERA', desc: 'Standardized European railway topology, timetable, and rolling stock.', status: 'COMPLIANT' },
                { name: 'GTFS-Realtime / NeTEx', desc: 'Passenger transit timetable and real-time trip updates.', status: 'CONNECTED' },
                { name: 'ISO 22163 / IRIS', desc: 'International Railway Industry Standard quality and asset management.', status: 'CERTIFIED' }
              ].map(std => (
                <div key={std.name} className="p-3 bg-[#121824] rounded border border-slate-800 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white text-xs">{std.name}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {std.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-sans">{std.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: URDM Core Schema Entities Hierarchy */}
        <div className="flex flex-col space-y-3">
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3 flex-1 flex flex-col">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="font-mono font-bold text-slate-200 flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-blue-400" />
                URDM ENTITY SPECIFICATIONS
              </span>
            </div>

            <div className="flex-1 space-y-2 overflow-y-auto font-mono text-xs">
              {[
                { entity: 'Country & National Authority', fields: '12 properties', level: 'L1 Core' },
                { entity: 'Railway Line (Track Polyline)', fields: '24 properties', level: 'L2 Infra' },
                { entity: 'Station Hub & Track Yard', fields: '18 properties', level: 'L2 Infra' },
                { entity: 'Rolling Stock (EMU / Loco)', fields: '32 properties', level: 'L3 Asset' },
                { entity: 'Real-time Train Position', fields: '28 properties', level: 'L4 Telemetry' },
                { entity: 'Timetable Stringline Service', fields: '16 properties', level: 'L4 Ops' },
                { entity: 'Dispatch Incident & Work Order', fields: '20 properties', level: 'L5 Event' }
              ].map(ent => (
                <div key={ent.entity} className="p-2.5 bg-[#121824] rounded border border-slate-800 flex justify-between items-center">
                  <div>
                    <div className="font-bold text-slate-200 text-xs">{ent.entity}</div>
                    <div className="text-[10px] text-slate-500">{ent.fields}</div>
                  </div>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                    {ent.level}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
