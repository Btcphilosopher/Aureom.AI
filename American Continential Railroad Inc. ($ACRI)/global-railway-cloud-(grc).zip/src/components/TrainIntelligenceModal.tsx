import React from 'react';
import { 
  X, 
  Activity, 
  Gauge, 
  Zap, 
  Clock, 
  MapPin, 
  Users, 
  ShieldCheck, 
  AlertCircle,
  TrendingUp,
  Cpu
} from 'lucide-react';
import { Train, RollingStock } from '../types/railway';

interface TrainIntelligenceModalProps {
  train: Train | null;
  rollingStock?: RollingStock;
  onClose: () => void;
  onOpenDigitalTwin?: (train: Train) => void;
}

export const TrainIntelligenceModal: React.FC<TrainIntelligenceModalProps> = ({
  train,
  rollingStock,
  onClose,
  onOpenDigitalTwin
}) => {
  if (!train) return null;

  const isDelayed = train.delayMinutes > 0;
  const isEarly = train.delayMinutes < 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#0f141e] border border-[#26354a] rounded-lg shadow-2xl w-full max-w-2xl text-slate-200 overflow-hidden font-sans animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#151c2a] border-b border-[#222e40] px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 rounded-full bg-emerald-400 signal-glow-green animate-pulse" />
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-mono font-bold text-lg text-white tracking-wide">
                  {train.serviceNumber}
                </h3>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-blue-900/60 text-blue-300 border border-blue-700/50">
                  {train.trainType.replace('_', ' ')}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {train.originStationName} ➔ {train.destinationStationName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded bg-slate-800/50 hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Main Key Indicators Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#121824] border border-[#1e293b] p-3 rounded">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                <Gauge className="w-3 h-3 text-blue-400" />
                当前速度 / SPEED
              </span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-emerald-400">
                  {train.currentSpeedKmH}
                </span>
                <span className="text-xs text-slate-400">km/h</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">目标: {train.targetSpeedKmH} km/h</div>
            </div>

            <div className="bg-[#121824] border border-[#1e293b] p-3 rounded">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                <Activity className="w-3 h-3 text-emerald-400" />
                当前状态 / STATUS
              </span>
              <div className="mt-1 flex items-center space-x-1.5">
                <span className="text-sm font-semibold text-emerald-300">
                  {train.status === 'RUNNING' ? '运行正常' : train.status}
                </span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">CTCS-3 / ATO 巡航</div>
            </div>

            <div className="bg-[#121824] border border-[#1e293b] p-3 rounded">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                <Clock className="w-3 h-3 text-amber-400" />
                准点偏差 / DELAY
              </span>
              <div className="mt-1">
                <span className={`text-xl font-mono-num font-bold ${
                  isDelayed ? 'text-rose-400' : isEarly ? 'text-emerald-400' : 'text-slate-200'
                }`}>
                  {train.delayMinutes === 0 ? '0 min (准点)' : `${train.delayMinutes > 0 ? '+' : ''}${train.delayMinutes} min`}
                </span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">计划到达 {train.scheduledNextArrival}</div>
            </div>

            <div className="bg-[#121824] border border-[#1e293b] p-3 rounded">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                <Users className="w-3 h-3 text-indigo-400" />
                载客率 / LOAD
              </span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-indigo-300">
                  {train.passengerLoadPercent}%
                </span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">定员: 1,193 人</div>
            </div>
          </div>

          {/* Next Station & Routing Bar */}
          <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-950/60 border border-blue-800 rounded">
                <MapPin className="w-4 h-4 text-blue-400" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-mono">下一站 / NEXT STATION</span>
                <div className="font-semibold text-white text-base">
                  {train.nextStationName}
                </div>
              </div>
            </div>
            <div className="text-right font-mono-num text-xs">
              <div className="text-slate-400">预计到达 / ETA: <span className="text-emerald-400 font-bold">{train.estimatedNextArrival}</span></div>
              <div className="text-slate-500 text-[11px]">区间进度: {train.routeProgressPercent}%</div>
            </div>
          </div>

          {/* Energy & Power Telemetry */}
          <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded space-y-2.5">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                能耗与牵引供电 / ENERGY & TRACTION
              </span>
              <span className="font-mono text-slate-400 text-[11px]">
                电网电压: {train.telemetry.catenaryVoltageV} V
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono-num text-xs">
              <div>
                <span className="text-[10px] text-slate-500">当前牵引功率</span>
                <div className="text-sm font-bold text-amber-300">{train.currentPowerDrawKw} kW</div>
              </div>
              <div>
                <span className="text-[10px] text-slate-500">今日累计能耗</span>
                <div className="text-sm font-bold text-slate-200">{train.todayEnergyMWh} MWh</div>
              </div>
              <div>
                <span className="text-[10px] text-slate-500">牵引电机温度</span>
                <div className="text-sm font-bold text-slate-200">{train.telemetry.motorTempC} °C</div>
              </div>
              <div>
                <span className="text-[10px] text-slate-500">牵引效率</span>
                <div className="text-sm font-bold text-emerald-400">{train.telemetry.tractionEfficiencyPercent}%</div>
              </div>
            </div>
          </div>

          {/* Live Subsystem Telemetry Details */}
          <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded space-y-2">
            <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              关键子系统实时工况 / SUBSYSTEM TELEMETRY
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 font-mono text-[11px] text-slate-400">
              <div className="bg-[#0b0e14] p-2 rounded border border-slate-800/80">
                <span className="text-slate-500">制动管风压:</span> <span className="text-slate-200">{train.telemetry.brakePipePressureKPa} kPa</span>
              </div>
              <div className="bg-[#0b0e14] p-2 rounded border border-slate-800/80">
                <span className="text-slate-500">受电弓振动:</span> <span className="text-slate-200">{train.telemetry.pantographVibrationG} g</span>
              </div>
              <div className="bg-[#0b0e14] p-2 rounded border border-slate-800/80">
                <span className="text-slate-500">轴承振动谱:</span> <span className="text-slate-200">{train.telemetry.bearingVibrationMmS} mm/s</span>
              </div>
              <div className="bg-[#0b0e14] p-2 rounded border border-slate-800/80">
                <span className="text-slate-500">1位轴温:</span> <span className="text-slate-200">{train.telemetry.axleTemp1C} °C</span>
              </div>
              <div className="bg-[#0b0e14] p-2 rounded border border-slate-800/80">
                <span className="text-slate-500">客室温度:</span> <span className="text-slate-200">{train.telemetry.cabinTempC} °C</span>
              </div>
              <div className="bg-[#0b0e14] p-2 rounded border border-slate-800/80">
                <span className="text-slate-500">安全制动距离:</span> <span className="text-slate-200">{train.telemetry.safetyBrakingDistanceMeters} m</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-[#151c2a] border-t border-[#222e40] px-5 py-3 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500">
            Model: {train.rollingStockModel} | ID: {train.id}
          </span>
          <div className="flex items-center space-x-2">
            {onOpenDigitalTwin && (
              <button
                onClick={() => {
                  onClose();
                  onOpenDigitalTwin(train);
                }}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition cursor-pointer"
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>进入 3D 车辆数字孪生</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition cursor-pointer"
            >
              关闭 / Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
