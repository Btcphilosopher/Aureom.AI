import React, { useState } from 'react';
import { 
  AlertTriangle, 
  GitMerge, 
  Clock, 
  Activity, 
  TrendingUp, 
  ArrowRight, 
  ShieldAlert, 
  Play, 
  RotateCcw,
  Zap
} from 'lucide-react';
import { INCIDENTS, LIVE_TRAINS } from '../data/seedData';
import { calculateDelayCascade } from '../services/simulationEngine';
import { Incident } from '../types/railway';

export const DelayIntelligenceLab: React.FC = () => {
  const [selectedIncident, setSelectedIncident] = useState<Incident>(INCIDENTS[0]);
  const [injectedDelayMinutes, setInjectedDelayMinutes] = useState<number>(30);

  const cascadeResult = calculateDelayCascade({
    ...selectedIncident,
    estimatedNetworkDelayMin: injectedDelayMinutes
  }, LIVE_TRAINS);

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-y-auto font-sans">
      {/* Top Banner */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-rose-950/60 border border-rose-800 rounded">
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                DELAY INTELLIGENCE & CASCADE LAB / 延误机理与连带传播实验室
              </h2>
              <span className="text-[10px] bg-rose-950 text-rose-300 border border-rose-800 px-1.5 py-0.5 rounded font-mono">
                GRAPH DIFFUSION ENGINE
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Primary Root Cause Attribution, Secondary Cascade Propagation & Recovery Optimization
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4 min-h-0">
        
        {/* Left 1 Col: Root Cause Decomposition & Incident Selector */}
        <div className="flex flex-col space-y-3">
          {/* Root Cause Stats */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3">
            <div className="text-xs font-mono font-bold text-slate-300 uppercase flex items-center justify-between border-b border-slate-800 pb-2">
              <span>ROOT CAUSE ATTRIBUTION / 延误原因归因</span>
            </div>
            
            <div className="space-y-2 font-mono text-xs">
              {[
                { label: 'Infrastructure & Track (工务/道岔)', percent: 34, color: 'bg-rose-500' },
                { label: 'Rolling Stock Failure (车辆机务)', percent: 26, color: 'bg-amber-500' },
                { label: 'Severe Weather / Wind (恶劣天气)', percent: 18, color: 'bg-blue-500' },
                { label: 'Signal & Interlocking (电务信号)', percent: 12, color: 'bg-purple-500' },
                { label: 'Passenger Flow Dwell (客运超时)', percent: 10, color: 'bg-emerald-500' }
              ].map(item => (
                <div key={item.label} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-300">{item.label}</span>
                    <span className="text-slate-400">{item.percent}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className={`${item.color} h-full rounded-full`} style={{ width: `${item.percent}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Incident Selector Box */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3 flex-1">
            <div className="text-xs font-mono font-bold text-slate-300 uppercase flex items-center justify-between border-b border-slate-800 pb-2">
              <span>SELECT PRIMARY INCIDENT</span>
            </div>

            <div className="space-y-2">
              {INCIDENTS.map(inc => (
                <div
                  key={inc.id}
                  onClick={() => setSelectedIncident(inc)}
                  className={`p-2.5 rounded border transition cursor-pointer text-xs ${
                    selectedIncident.id === inc.id
                      ? 'bg-[#22161f] border-rose-500 text-rose-200'
                      : 'bg-[#121824] border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex justify-between font-mono">
                    <span className="font-bold">{inc.incidentNumber}</span>
                    <span className="text-[10px] px-1 bg-black/40 rounded">{inc.severity}</span>
                  </div>
                  <div className="text-[11px] font-medium text-slate-200 mt-1">{inc.title}</div>
                  <div className="text-[10px] text-slate-400 mt-1 font-mono">
                    Baseline Delay: +{inc.estimatedNetworkDelayMin}m | {inc.affectedTrainsCount} Trains
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Delay Cascade Propagation Graph Tree */}
        <div className="lg:col-span-2 bg-[#0c1018] rounded-lg border border-[#1e293b] p-4 flex flex-col space-y-3 min-h-[480px]">
          <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <span className="font-mono text-rose-300 font-bold flex items-center gap-1.5">
              <GitMerge className="w-3.5 h-3.5 text-rose-400" />
              DELAY PROPAGATION CASCADE TREE (连带影响级联树)
            </span>
            <div className="flex items-center space-x-3 text-xs font-mono">
              <span className="text-slate-400">INJECT DELAY:</span>
              <input
                type="range"
                min="10"
                max="90"
                value={injectedDelayMinutes}
                onChange={(e) => setInjectedDelayMinutes(Number(e.target.value))}
                className="w-24 accent-rose-500 cursor-pointer"
              />
              <span className="text-rose-400 font-bold w-12">{injectedDelayMinutes} min</span>
            </div>
          </div>

          {/* Root Incident Banner */}
          <div className="p-3 bg-[#1e141c] border border-rose-800 rounded-lg flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-rose-400 uppercase">
                PRIMARY ROOT INCIDENT (源头事件)
              </span>
              <div className="font-bold text-white text-sm">{selectedIncident.title}</div>
              <div className="text-xs text-slate-300 mt-0.5">{selectedIncident.description}</div>
            </div>
            <div className="text-right font-mono-num">
              <div className="text-2xl font-bold text-rose-400">+{injectedDelayMinutes} min</div>
              <div className="text-[10px] text-slate-400">网络总注入延误</div>
            </div>
          </div>

          {/* Cascade Downstream Step Flow */}
          <div className="flex-1 overflow-y-auto space-y-2 py-2">
            <div className="text-xs font-mono text-slate-400 font-semibold">
              DOWNSTREAM AFFECTED SERVICES ({cascadeResult.impactCascadeTree.length} TRAIN SETS):
            </div>

            {cascadeResult.impactCascadeTree.map((item) => (
              <div key={item.trainId} className="p-3 bg-[#121824] rounded-lg border border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded bg-rose-950/80 border border-rose-800 text-rose-400 flex items-center justify-center font-mono font-bold text-xs">
                    L{item.level}
                  </div>
                  <div>
                    <div className="font-mono font-bold text-sm text-white">
                      {item.serviceNumber}
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      {item.cause}
                    </div>
                  </div>
                </div>

                <div className="text-right font-mono-num">
                  <div className="text-base font-bold text-amber-400">
                    +{item.delayAddedMinutes} min
                  </div>
                  <div className="text-[10px] text-slate-500">
                    传播延误吸收
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Recommended OCC Recovery Directive */}
          <div className="p-3 bg-[#0e171b] border border-emerald-800 rounded-lg flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-emerald-400 uppercase">
                GRC AI DISPATCH RECOVERY PLAN / 智能晚点恢复调度建议
              </span>
              <div className="text-xs text-slate-200 mt-0.5">
                • 调整后行列车区间运行时分，在济南西-南京南段启动 350km/h 达速赶点；
                • 下游上海虹桥站指派 12 站台备用股道接车，避免咽喉道岔进路死锁。
              </div>
            </div>
            <button className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold transition cursor-pointer">
              下发调度令 (DISPATCH)
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
