import React, { useState } from 'react';
import { 
  GitBranch, 
  Clock, 
  AlertTriangle, 
  Filter, 
  CheckCircle2, 
  ZoomIn, 
  ZoomOut, 
  Layers,
  ChevronRight
} from 'lucide-react';
import { TIMETABLE_CONFLICTS, LIVE_TRAINS } from '../data/seedData';

export const TimetableStringChart: React.FC = () => {
  const [selectedCorridor, setSelectedCorridor] = useState<string>('BJ-SH');
  const [highlightedTrain, setHighlightedTrain] = useState<string | null>(null);
  const [showConflictsOnly, setShowConflictsOnly] = useState<boolean>(false);

  // Station Distance Markers along Beijing-Shanghai High-Speed Railway (1318 km)
  const stationsOnLine = [
    { name: '北京南 / Beijing South', km: 0, code: 'VNP' },
    { name: '天津南 / Tianjin South', km: 122, code: 'TIP' },
    { name: '济南西 / Jinan West', km: 406, code: 'JGK' },
    { name: '徐州东 / Xuzhou East', km: 692, code: 'XEL' },
    { name: '南京南 / Nanjing South', km: 1023, code: 'NKH' },
    { name: '上海虹桥 / Shanghai HQ', km: 1318, code: 'AOH' }
  ];

  // Train string lines: Beijing -> Shanghai (Down direction) and Shanghai -> Beijing (Up direction)
  const trainTrajectories = [
    {
      service: 'G1 (复兴号标杆车)',
      trainType: 'CR400AF-Z',
      direction: 'DOWN',
      color: '#10b981',
      points: [
        { time: 7.0, km: 0 },
        { time: 7.45, km: 122 },
        { time: 8.35, km: 406 },
        { time: 9.30, km: 692 },
        { time: 10.35, km: 1023 },
        { time: 11.28, km: 1318 }
      ]
    },
    {
      service: 'G1234 (特快大组车)',
      trainType: 'CR400AF',
      direction: 'DOWN',
      color: '#38bdf8',
      points: [
        { time: 7.8, km: 0 },
        { time: 8.30, km: 122 },
        { time: 9.25, km: 406 },
        { time: 10.30, km: 692 },
        { time: 11.40, km: 1023 },
        { time: 12.38, km: 1318 }
      ]
    },
    {
      service: 'G3 (标杆直达)',
      trainType: 'CR400BF-Z',
      direction: 'DOWN',
      color: '#a855f7',
      points: [
        { time: 8.5, km: 0 },
        { time: 9.75, km: 406 },
        { time: 11.75, km: 1023 },
        { time: 12.78, km: 1318 }
      ]
    },
    {
      service: 'G2 (上行返程标杆)',
      trainType: 'CR400AF-Z',
      direction: 'UP',
      color: '#f59e0b',
      points: [
        { time: 7.0, km: 1318 },
        { time: 7.95, km: 1023 },
        { time: 9.0, km: 692 },
        { time: 9.95, km: 406 },
        { time: 10.85, km: 122 },
        { time: 11.28, km: 0 }
      ]
    },
    {
      service: 'G4 (上行特快)',
      trainType: 'CR400AF',
      direction: 'UP',
      color: '#fb7185',
      points: [
        { time: 8.2, km: 1318 },
        { time: 9.15, km: 1023 },
        { time: 10.25, km: 692 },
        { time: 11.2, km: 406 },
        { time: 12.15, km: 122 },
        { time: 12.6, km: 0 }
      ]
    }
  ];

  // Map graph coordinates: Time (X: 06:00 to 14:00 => 6 to 14), Km (Y: 0 to 1318)
  const mapX = (timeHours: number) => {
    return ((timeHours - 6.0) / 8.0) * 800 + 120;
  };

  const mapY = (km: number) => {
    return (km / 1318) * 440 + 40;
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-y-auto font-sans">
      {/* Top Banner */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-950/60 border border-blue-800 rounded">
            <GitBranch className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                RAILWAY STRINGLINE & TIMETABLE / 列车运行图与时刻表
              </h2>
              <span className="text-[10px] bg-blue-950 text-blue-300 border border-blue-800 px-1.5 py-0.5 rounded font-mono">
                MAREY DIAGRAM ENGINE
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Trajectory Graph (Distance vs. Time), Automatic Conflict Resolution & Headway Envelopes
            </p>
          </div>
        </div>

        {/* Quick Corridor Selector */}
        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="text-slate-400">CORRIDOR:</span>
          <select
            value={selectedCorridor}
            onChange={(e) => setSelectedCorridor(e.target.value)}
            className="bg-[#141a24] text-slate-200 border border-slate-700 rounded px-2.5 py-1 focus:outline-none focus:border-blue-500"
          >
            <option value="BJ-SH">京沪高速铁路 (Beijing - Shanghai HSR, 1318km)</option>
            <option value="TGV-SE">法国东南高铁 (TGV Sud-Est: Paris - Lyon, 465km)</option>
            <option value="SHINKANSEN-TK">日本东海道新干线 (Tokyo - Shin-Osaka, 515km)</option>
          </select>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-4 p-4 min-h-0">
        
        {/* Left 3 Cols: Stringline Diagram Canvas */}
        <div className="lg:col-span-3 bg-[#0c1018] rounded-lg border border-[#1e293b] p-3 flex flex-col min-h-[480px]">
          {/* Header Controls */}
          <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <span className="font-mono text-slate-300 font-semibold">
              运行图断面: 06:00 - 14:00 (时空轨迹网格)
            </span>
            <div className="flex items-center space-x-4 text-[11px] font-mono">
              <span className="text-emerald-400 flex items-center gap-1">
                <span className="w-3 h-0.5 bg-emerald-400 inline-block" /> 下行 G1/G3/G1234
              </span>
              <span className="text-amber-400 flex items-center gap-1">
                <span className="w-3 h-0.5 bg-amber-400 inline-block" /> 上行 G2/G4
              </span>
            </div>
          </div>

          {/* SVG Marey Diagram */}
          <div className="flex-1 w-full relative overflow-x-auto">
            <svg className="w-full h-full min-w-[700px] min-h-[460px]" viewBox="0 0 960 520">
              {/* Time Grid Lines (X-Axis: 06:00 to 14:00) */}
              {[6, 7, 8, 9, 10, 11, 12, 13, 14].map((hour) => {
                const x = mapX(hour);
                return (
                  <g key={hour}>
                    <line
                      x1={x}
                      y1={30}
                      x2={x}
                      y2={480}
                      stroke="#1e293b"
                      strokeWidth="1"
                      strokeDasharray={hour % 2 === 0 ? '0' : '3,3'}
                    />
                    <text
                      x={x}
                      y={20}
                      fill="#64748b"
                      fontSize="10"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {String(hour).padStart(2, '0')}:00
                    </text>
                    <text
                      x={x}
                      y={505}
                      fill="#64748b"
                      fontSize="10"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {String(hour).padStart(2, '0')}:00
                    </text>
                  </g>
                );
              })}

              {/* Station Horizontal Lines (Y-Axis: Distance) */}
              {stationsOnLine.map(sta => {
                const y = mapY(sta.km);
                return (
                  <g key={sta.code}>
                    <line
                      x1={110}
                      y1={y}
                      x2={940}
                      y2={y}
                      stroke="#1e293b"
                      strokeWidth="1.2"
                    />
                    <text
                      x={100}
                      y={y + 3}
                      fill="#94a3b8"
                      fontSize="9.5"
                      fontFamily="monospace"
                      textAnchor="end"
                      className="font-medium"
                    >
                      {sta.name}
                    </text>
                    <text
                      x={945}
                      y={y + 3}
                      fill="#64748b"
                      fontSize="9"
                      fontFamily="monospace"
                    >
                      {sta.km}km
                    </text>
                  </g>
                );
              })}

              {/* Trajectory Stringlines */}
              {trainTrajectories.map(t => {
                const polyPoints = t.points.map(p => `${mapX(p.time)},${mapY(p.km)}`).join(' ');
                const isHovered = highlightedTrain === t.service;

                return (
                  <g 
                    key={t.service} 
                    className="cursor-pointer group"
                    onMouseEnter={() => setHighlightedTrain(t.service)}
                    onMouseLeave={() => setHighlightedTrain(null)}
                  >
                    {/* Wide transparent hover stroke */}
                    <polyline
                      points={polyPoints}
                      fill="none"
                      stroke="transparent"
                      strokeWidth="16"
                    />
                    {/* Visible Train Stringline */}
                    <polyline
                      points={polyPoints}
                      fill="none"
                      stroke={t.color}
                      strokeWidth={isHovered ? '4' : '2'}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="transition-all duration-200"
                    />
                    {/* Node points at stations */}
                    {t.points.map((p, idx) => (
                      <circle
                        key={idx}
                        cx={mapX(p.time)}
                        cy={mapY(p.km)}
                        r={isHovered ? 4.5 : 2.5}
                        fill={t.color}
                        stroke="#090c12"
                        strokeWidth="1"
                      />
                    ))}
                    {/* Train Tag at head of line */}
                    <text
                      x={mapX(t.points[0].time) + 4}
                      y={mapY(t.points[0].km) - 6}
                      fill={t.color}
                      fontSize="9"
                      fontFamily="monospace"
                      fontWeight="bold"
                    >
                      {t.service.split(' ')[0]}
                    </text>
                  </g>
                );
              })}

              {/* Timetable Conflict Intersection Marker */}
              <g transform={`translate(${mapX(8.65)}, ${mapY(240)})`}>
                <circle
                  cx="0"
                  cy="0"
                  r="12"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="2"
                  className="radar-ping"
                />
                <circle cx="0" cy="0" r="4" fill="#ef4444" />
                <rect x="8" y="-10" width="130" height="18" rx="2" fill="#181016" stroke="#b91c1c" strokeWidth="0.8" />
                <text x="12" y="2" fill="#fca5a5" fontSize="8" fontFamily="monospace">
                  CONFLICT: Headway 140s &lt; 180s
                </text>
              </g>
            </svg>
          </div>
        </div>

        {/* Right 1 Col: Conflicts & Auto-Resolution Dispatch Lab */}
        <div className="flex flex-col space-y-3">
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3 flex-1">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="font-mono font-bold text-rose-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                HEADWAY CONFLICTS ({TIMETABLE_CONFLICTS.length})
              </span>
              <span className="text-[10px] font-mono text-rose-400 bg-rose-950 px-1.5 py-0.5 rounded">
                CRITICAL
              </span>
            </div>

            <div className="space-y-2">
              {TIMETABLE_CONFLICTS.map(conf => (
                <div key={conf.id} className="p-3 bg-[#18121a] rounded border border-rose-900/60 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-rose-200">{conf.conflictType}</span>
                    <span className="text-[10px] font-mono text-amber-400 bg-amber-950 px-1 rounded">
                      {conf.locationStationName}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300">{conf.description}</p>

                  <div className="mt-2 p-2 bg-[#0c0d12] rounded border border-slate-800 text-[10px] font-mono text-emerald-400">
                    <span className="text-slate-400">GRC AI 推荐解冲策略:</span>
                    <div className="mt-0.5">{conf.aiResolutionProposal}</div>
                  </div>

                  <div className="flex justify-end pt-1">
                    <button className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-mono text-[10px] transition cursor-pointer">
                      自动下发排图指令 (APPLY)
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
