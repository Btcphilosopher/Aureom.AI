import React, { useState } from 'react';
import { 
  Train as TrainIcon, 
  AlertTriangle, 
  Clock, 
  Zap, 
  Users, 
  MapPin, 
  Navigation, 
  Filter, 
  ChevronRight, 
  Gauge, 
  ShieldAlert, 
  Search,
  Activity,
  Maximize2,
  ZoomIn,
  ZoomOut,
  RotateCcw
} from 'lucide-react';
import { 
  Country, 
  RailwayOperator, 
  RailwayLine, 
  Station, 
  Train, 
  Incident, 
  NetworkKPIs 
} from '../types/railway';

interface GlobalOperationsCenterProps {
  countries: Country[];
  operators: RailwayOperator[];
  lines: RailwayLine[];
  stations: Station[];
  trains: Train[];
  incidents: Incident[];
  kpis: NetworkKPIs;
  selectedCountryId: string;
  onSelectCountry: (id: string) => void;
  selectedTrain: Train | null;
  onSelectTrain: (train: Train) => void;
  onOpenTrainModal: (train: Train) => void;
  onOpenStationModal?: (station: Station) => void;
  onOpenIncidentModal?: (incident: Incident) => void;
}

export const GlobalOperationsCenter: React.FC<GlobalOperationsCenterProps> = ({
  countries,
  operators,
  lines,
  stations,
  trains,
  incidents,
  kpis,
  selectedCountryId,
  onSelectCountry,
  selectedTrain,
  onSelectTrain,
  onOpenTrainModal,
  onOpenStationModal,
  onOpenIncidentModal
}) => {
  const [activeLineFilter, setActiveLineFilter] = useState<string>('ALL');
  const [trainSearchQuery, setTrainSearchQuery] = useState<string>('');
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [mapOffset, setMapOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Filtered lists
  const filteredLines = lines.filter(l => 
    (selectedCountryId === 'ALL' || l.countryId === selectedCountryId)
  );

  const filteredTrains = trains.filter(t => {
    const matchCountry = selectedCountryId === 'ALL' || t.countryId === selectedCountryId;
    const matchLine = activeLineFilter === 'ALL' || t.lineId === activeLineFilter;
    const matchSearch = trainSearchQuery === '' || 
      t.serviceNumber.toLowerCase().includes(trainSearchQuery.toLowerCase()) ||
      t.originStationName.toLowerCase().includes(trainSearchQuery.toLowerCase()) ||
      t.destinationStationName.toLowerCase().includes(trainSearchQuery.toLowerCase());
    return matchCountry && matchLine && matchSearch;
  });

  const filteredStations = stations.filter(s =>
    selectedCountryId === 'ALL' || s.countryId === selectedCountryId
  );

  // Map coordinate conversion: Lng/Lat to Canvas SVG projection (Mercator-approx scaled)
  const projectCoordinates = (lng: number, lat: number) => {
    // Standard projection centering roughly Europe/Asia
    // Lng: -100 to 145 -> X: 50 to 950
    // Lat: 60 to 20 -> Y: 50 to 550
    const x = ((lng + 130) / 280) * 900 + 50;
    const y = ((65 - lat) / 45) * 500 + 50;
    return { x, y };
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - mapOffset.x, y: e.clientY - mapOffset.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setMapOffset({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#0b0e14] text-slate-200 overflow-hidden select-none">
      {/* Main 3-Column OCC Layout */}
      <div className="flex-1 flex min-h-0">
        
        {/* Left Panel: Hierarchy Navigator (Networks, Countries, Operators, Lines) */}
        <aside className="w-72 bg-[#0f131a] border-r border-[#1e293b] flex flex-col min-h-0 hidden md:flex">
          <div className="p-3 border-b border-[#1e293b] bg-[#121722] flex items-center justify-between">
            <span className="text-xs font-mono font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-blue-400" />
              RAILWAY HIERARCHY
            </span>
            <span className="text-[10px] font-mono text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded">
              {countries.length} TENANTS
            </span>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-3">
            {/* Countries & Authorities Accordion */}
            <div>
              <div className="text-[10px] font-mono uppercase text-slate-500 px-2 py-1 font-semibold">
                NATIONAL RAILWAY AUTHORITIES
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => { onSelectCountry('ALL'); setActiveLineFilter('ALL'); }}
                  className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between transition cursor-pointer ${
                    selectedCountryId === 'ALL'
                      ? 'bg-blue-900/40 text-blue-300 border border-blue-700/50 font-semibold'
                      : 'hover:bg-[#161d28] text-slate-400'
                  }`}
                >
                  <span className="flex items-center gap-1.5">
                    <span>🌐</span>
                    <span>Global Network View</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">{trains.length} trains</span>
                </button>

                {countries.map(c => {
                  const countryTrains = trains.filter(t => t.countryId === c.id);
                  const isSelected = selectedCountryId === c.id;
                  return (
                    <div key={c.id} className="space-y-0.5">
                      <button
                        onClick={() => { onSelectCountry(c.id); setActiveLineFilter('ALL'); }}
                        className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between transition cursor-pointer ${
                          isSelected
                            ? 'bg-blue-900/40 text-blue-200 border border-blue-700/50 font-semibold'
                            : 'hover:bg-[#161d28] text-slate-400'
                        }`}
                      >
                        <span className="flex items-center gap-1.5 truncate">
                          <span>{c.flag}</span>
                          <span className="truncate">{c.nameZh} ({c.id})</span>
                        </span>
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-900/60">
                          {countryTrains.length}
                        </span>
                      </button>

                      {/* Expanded Authorities */}
                      {isSelected && (
                        <div className="pl-5 pr-1 py-1 space-y-1 bg-[#0b0e14]/50 rounded border-l-2 border-blue-500/60 ml-3">
                          {c.authorities.map(auth => (
                            <div key={auth.id} className="text-[11px] text-slate-400">
                              <div className="font-semibold text-slate-300 text-[11px]">{auth.nameZh}</div>
                              <div className="space-y-0.5 mt-1">
                                {auth.operationalRegions.map(reg => (
                                  <div key={reg.id} className="flex items-center justify-between text-[10px] text-slate-400 pl-2">
                                    <span className="truncate">• {reg.nameZh}</span>
                                    <span className="text-emerald-400 text-[9px] font-mono">{reg.status}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Railway Lines Filter */}
            <div className="pt-2 border-t border-slate-800">
              <div className="text-[10px] font-mono uppercase text-slate-500 px-2 py-1 font-semibold">
                ACTIVE TRUNK / HSR LINES
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => setActiveLineFilter('ALL')}
                  className={`w-full text-left px-2.5 py-1.5 rounded text-xs transition cursor-pointer ${
                    activeLineFilter === 'ALL'
                      ? 'bg-slate-800 text-white font-semibold'
                      : 'hover:bg-[#161d28] text-slate-400'
                  }`}
                >
                  All Lines ({filteredLines.length})
                </button>
                {filteredLines.map(line => {
                  const lineTrainCount = trains.filter(t => t.lineId === line.id).length;
                  return (
                    <button
                      key={line.id}
                      onClick={() => setActiveLineFilter(line.id)}
                      className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between transition cursor-pointer ${
                        activeLineFilter === line.id
                          ? 'bg-blue-900/40 text-blue-300 border border-blue-700/50 font-semibold'
                          : 'hover:bg-[#161d28] text-slate-400'
                      }`}
                    >
                      <span className="truncate">{line.nameZh}</span>
                      <span className="text-[10px] font-mono text-slate-500">{line.maxDesignSpeed} km/h</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </aside>

        {/* Center: Live Railway GIS Map View */}
        <main className="flex-1 bg-[#090c12] relative overflow-hidden flex flex-col">
          {/* Map Floating Controls Header */}
          <div className="absolute top-3 left-3 z-10 flex items-center space-x-2 bg-[#121722]/90 backdrop-blur-md px-3 py-1.5 rounded-md border border-slate-700/60 shadow-lg">
            <span className="text-xs font-mono font-bold text-slate-200 flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 text-blue-400" />
              LIVE RAILWAY DISPATCH MAP
            </span>
            <span className="text-slate-600">|</span>
            <span className="text-[11px] font-mono text-emerald-400">
              {filteredTrains.length} ACTIVE TRAINS
            </span>
          </div>

          {/* Map Zoom & Reset Controls */}
          <div className="absolute top-3 right-3 z-10 flex items-center space-x-1 bg-[#121722]/90 backdrop-blur-md p-1 rounded-md border border-slate-700/60 shadow-lg">
            <button
              onClick={() => setZoomLevel(prev => Math.min(prev + 0.25, 3.0))}
              className="p-1.5 hover:bg-slate-700 text-slate-300 rounded transition cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(prev => Math.max(prev - 0.25, 0.6))}
              className="p-1.5 hover:bg-slate-700 text-slate-300 rounded transition cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => { setZoomLevel(1.0); setMapOffset({ x: 0, y: 0 }); }}
              className="p-1.5 hover:bg-slate-700 text-slate-300 rounded transition cursor-pointer"
              title="Reset View"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Map Canvas / SVG Stage */}
          <div 
            className="flex-1 w-full h-full relative cursor-grab active:cursor-grabbing bg-[radial-gradient(#151d2c_1px,transparent_1px)] [background-size:24px_24px]"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
          >
            <svg 
              className="w-full h-full"
              viewBox="0 0 1000 600"
              style={{
                transform: `translate(${mapOffset.x}px, ${mapOffset.y}px) scale(${zoomLevel})`,
                transformOrigin: 'center center',
                transition: isDragging ? 'none' : 'transform 0.15s ease-out'
              }}
            >
              <defs>
                {/* Glow Filters */}
                <filter id="glow-green" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
                <filter id="glow-blue" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
                <linearGradient id="hsrGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
              </defs>

              {/* Background Grid Lat/Long Markers */}
              <g stroke="#1a2333" strokeWidth="0.5" strokeDasharray="4,4">
                <line x1="0" y1="150" x2="1000" y2="150" />
                <line x1="0" y1="300" x2="1000" y2="300" />
                <line x1="0" y1="450" x2="1000" y2="450" />
                <line x1="250" y1="0" x2="250" y2="600" />
                <line x1="500" y1="0" x2="500" y2="600" />
                <line x1="750" y1="0" x2="750" y2="600" />
              </g>

              {/* Railway Lines (Tracks) Polylines */}
              {lines.map(line => {
                const points = line.coordinates.map(coord => {
                  const p = projectCoordinates(coord[0], coord[1]);
                  return `${p.x},${p.y}`;
                }).join(' ');

                const isLineActive = activeLineFilter === 'ALL' || activeLineFilter === line.id;

                return (
                  <g key={line.id} opacity={isLineActive ? 1 : 0.25}>
                    {/* Track Casing / Bed */}
                    <polyline
                      points={points}
                      fill="none"
                      stroke="#1e293b"
                      strokeWidth="6"
                      strokeLinecap="round"
                    />
                    {/* Track Rails (Dual Rails or HSR glow) */}
                    <polyline
                      points={points}
                      fill="none"
                      stroke={line.type === 'HIGH_SPEED' ? 'url(#hsrGradient)' : '#64748b'}
                      strokeWidth={line.type === 'HIGH_SPEED' ? '2.5' : '1.8'}
                      strokeLinecap="round"
                    />
                  </g>
                );
              })}

              {/* Station Nodes */}
              {filteredStations.map(station => {
                const pos = projectCoordinates(station.coordinates[0], station.coordinates[1]);
                return (
                  <g 
                    key={station.id} 
                    className="cursor-pointer group"
                    onClick={() => onOpenStationModal && onOpenStationModal(station)}
                  >
                    {/* Station Halo */}
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r={station.isHub ? 7 : 4.5}
                      fill="#0f172a"
                      stroke={station.isHub ? '#38bdf8' : '#94a3b8'}
                      strokeWidth="2"
                    />
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r={station.isHub ? 3 : 2}
                      fill={station.currentCrowdDensity > 80 ? '#ef4444' : '#22c55e'}
                    />
                    {/* Station Label */}
                    <text
                      x={pos.x + 9}
                      y={pos.y + 4}
                      fill="#94a3b8"
                      fontSize="9"
                      fontFamily="monospace"
                      className="group-hover:fill-white font-semibold transition"
                    >
                      {station.nameZh}
                    </text>
                  </g>
                );
              })}

              {/* Live Trains on Map */}
              {filteredTrains.map(train => {
                const pos = projectCoordinates(train.currentCoordinates[0], train.currentCoordinates[1]);
                const isSelected = selectedTrain?.id === train.id;

                return (
                  <g 
                    key={train.id}
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => {
                      onSelectTrain(train);
                      onOpenTrainModal(train);
                    }}
                  >
                    {/* Animated Radar Pulse Ping */}
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r="14"
                      fill="none"
                      stroke={train.delayMinutes > 5 ? '#f43f5e' : '#10b981'}
                      strokeWidth="1.5"
                      className="radar-ping opacity-75"
                    />

                    {/* Speed Vector Tail */}
                    <line
                      x1={pos.x}
                      y1={pos.y}
                      x2={pos.x - (Math.cos((train.headingDeg * Math.PI) / 180) * 16)}
                      y2={pos.y - (Math.sin((train.headingDeg * Math.PI) / 180) * 16)}
                      stroke={train.delayMinutes > 5 ? '#f43f5e' : '#34d399'}
                      strokeWidth="2"
                      strokeDasharray="2,2"
                    />

                    {/* Train Marker Body */}
                    <rect
                      x={pos.x - 6}
                      y={pos.y - 6}
                      width="12"
                      height="12"
                      rx="3"
                      fill={isSelected ? '#38bdf8' : train.delayMinutes > 5 ? '#e11d48' : '#059669'}
                      stroke="#ffffff"
                      strokeWidth={isSelected ? '2.5' : '1.5'}
                      filter={train.delayMinutes > 5 ? 'url(#glow-green)' : 'url(#glow-blue)'}
                    />

                    {/* Speed / Service Callout */}
                    <g transform={`translate(${pos.x + 10}, ${pos.y - 6})`}>
                      <rect
                        x="0"
                        y="-8"
                        width="82"
                        height="18"
                        rx="3"
                        fill="#0f172a"
                        stroke="#334155"
                        strokeWidth="0.8"
                        fillOpacity="0.85"
                      />
                      <text
                        x="4"
                        y="4"
                        fill="#f8fafc"
                        fontSize="8.5"
                        fontWeight="bold"
                        fontFamily="monospace"
                      >
                        {train.serviceNumber.split(' ')[0]} {train.currentSpeedKmH}k
                      </text>
                    </g>
                  </g>
                );
              })}
            </svg>
          </div>
        </main>

        {/* Right Panel: Active Trains Inspector & Incidents Feed */}
        <aside className="w-80 bg-[#0f131a] border-l border-[#1e293b] flex flex-col min-h-0">
          {/* Header & Quick Search Filter */}
          <div className="p-3 border-b border-[#1e293b] bg-[#121722] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <TrainIcon className="w-3.5 h-3.5 text-emerald-400" />
                ACTIVE TRAINS FEED
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800">
                {filteredTrains.length} RUNNING
              </span>
            </div>

            <div className="relative">
              <input
                type="text"
                value={trainSearchQuery}
                onChange={(e) => setTrainSearchQuery(e.target.value)}
                placeholder="Filter G1234, Shinkansen, TGV..."
                className="w-full bg-[#0b0e14] border border-slate-700 text-xs rounded px-2.5 py-1 text-slate-200 placeholder-slate-500 font-mono focus:outline-none focus:border-blue-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-2" />
            </div>
          </div>

          {/* Trains List */}
          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {filteredTrains.map(train => {
              const isSelected = selectedTrain?.id === train.id;
              const isDelayed = train.delayMinutes > 0;

              return (
                <div
                  key={train.id}
                  onClick={() => {
                    onSelectTrain(train);
                    onOpenTrainModal(train);
                  }}
                  className={`p-2.5 rounded border transition cursor-pointer ${
                    isSelected
                      ? 'bg-[#1a2333] border-blue-500 shadow-md'
                      : 'bg-[#121722] border-[#1e293b] hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-white">
                      {train.serviceNumber}
                    </span>
                    <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                      isDelayed
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    }`}>
                      {isDelayed ? `+${train.delayMinutes} min` : 'ON-TIME'}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-400 mt-1 truncate">
                    {train.originStationName} ➔ {train.destinationStationName}
                  </div>

                  {/* Telemetry quick glance */}
                  <div className="mt-2 grid grid-cols-3 gap-1 pt-1.5 border-t border-slate-800/80 font-mono text-[10px] text-slate-400">
                    <div>
                      <span className="text-slate-500">SPD:</span>{' '}
                      <span className="text-emerald-400 font-bold">{train.currentSpeedKmH}</span> km/h
                    </div>
                    <div>
                      <span className="text-slate-500">LOAD:</span>{' '}
                      <span className="text-indigo-300">{train.passengerLoadPercent}%</span>
                    </div>
                    <div>
                      <span className="text-slate-500">ETA:</span>{' '}
                      <span className="text-slate-200">{train.estimatedNextArrival}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Incidents & Critical Alerts Section */}
          <div className="border-t border-[#1e293b] bg-[#0c1018] p-3">
            <div className="flex items-center justify-between text-xs font-mono font-bold text-rose-400 mb-2">
              <span className="flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                DISPATCH INCIDENTS ({incidents.length})
              </span>
            </div>
            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {incidents.map(inc => (
                <div
                  key={inc.id}
                  onClick={() => onOpenIncidentModal && onOpenIncidentModal(inc)}
                  className="p-2 bg-[#17141f] border border-rose-900/60 rounded text-[11px] hover:border-rose-600 transition cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-rose-300 font-semibold">{inc.incidentNumber}</span>
                    <span className="text-[9px] font-mono bg-rose-950 text-rose-400 px-1 rounded">
                      {inc.severity}
                    </span>
                  </div>
                  <div className="text-slate-300 text-[10px] mt-0.5 truncate">{inc.title}</div>
                  <div className="text-slate-500 text-[9px] mt-1 font-mono">
                    Impact: {inc.affectedTrainsCount} trains | Delay +{inc.estimatedNetworkDelayMin}m
                  </div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>

      {/* Bottom Panel: Network Performance Bar (Bloomberg Terminal Style HUD) */}
      <footer className="h-16 bg-[#090d14] border-t border-[#1e293b] px-4 flex items-center justify-between text-xs font-mono overflow-x-auto gap-4">
        <div className="flex items-center space-x-6 min-w-max">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 uppercase">RUNNING TRAINS</span>
            <span className="text-emerald-400 font-bold text-sm font-mono-num">
              {kpis.globalActiveTrains.toLocaleString()}
            </span>
          </div>

          <div className="h-6 w-px bg-slate-800" />

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 uppercase">ON-TIME PUNCTUALITY</span>
            <span className="text-emerald-300 font-bold text-sm font-mono-num">
              {kpis.onTimePunctualityPercent}%
            </span>
          </div>

          <div className="h-6 w-px bg-slate-800" />

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 uppercase">AVG DELAY</span>
            <span className="text-amber-400 font-bold text-sm font-mono-num">
              {kpis.averageDelayMinutes} min
            </span>
          </div>

          <div className="h-6 w-px bg-slate-800" />

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 uppercase">PASSENGERS TODAY</span>
            <span className="text-blue-400 font-bold text-sm font-mono-num">
              {kpis.dailyPassengersMillion} M
            </span>
          </div>

          <div className="h-6 w-px bg-slate-800" />

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 uppercase">FREIGHT VOLUME</span>
            <span className="text-indigo-300 font-bold text-sm font-mono-num">
              {kpis.dailyFreightMillionTonnes} M Tonnes
            </span>
          </div>

          <div className="h-6 w-px bg-slate-800" />

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 uppercase">TOTAL TRACTION ENERGY</span>
            <span className="text-yellow-400 font-bold text-sm font-mono-num">
              {kpis.totalEnergyMWh.toLocaleString()} MWh
            </span>
          </div>

          <div className="h-6 w-px bg-slate-800" />

          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 uppercase">CO2 EMISSIONS SAVED</span>
            <span className="text-teal-300 font-bold text-sm font-mono-num">
              {kpis.carbonSavedTonnesToday.toLocaleString()} T
            </span>
          </div>
        </div>

        {/* Global Security / Compliance Tag */}
        <div className="hidden xl:flex items-center space-x-2 text-[11px] text-slate-500 font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>URDM v3.7 / ISO 22163 COMPLIANT</span>
        </div>
      </footer>
    </div>
  );
};
