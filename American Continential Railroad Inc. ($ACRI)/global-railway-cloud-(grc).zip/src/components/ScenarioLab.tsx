import React, { useState } from 'react';
import { 
  FlaskConical, 
  Play, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  Zap, 
  Users, 
  Clock, 
  Layers 
} from 'lucide-react';
import { SCENARIO_PRESETS } from '../data/seedData';
import { ScenarioPreset } from '../types/railway';

export const ScenarioLab: React.FC = () => {
  const [selectedScenario, setSelectedScenario] = useState<ScenarioPreset>(SCENARIO_PRESETS[1]);
  const [demandMultiplier, setDemandMultiplier] = useState<number>(1.25);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simResult, setSimResult] = useState<any>(null);

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setSimResult({
        deltaPunctuality: -((demandMultiplier - 1) * 7.8).toFixed(1),
        totalDelayDelta: Math.round(18 * demandMultiplier),
        peakCongestion: Math.min(99, Math.round(72 * demandMultiplier)),
        cancelledServices: demandMultiplier > 1.3 ? 4 : 0,
        energySurgePercent: Number(((demandMultiplier - 1) * 100 * 0.88).toFixed(1)),
        bottleneckStations: ['上海虹桥 (Shanghai HQ)', '北京南 (Beijing South)', '南京南 (Nanjing South)'],
        dispatchActions: [
          '部署 6 组重联 CR400AF 备用动车组上线，分担高峰客流。',
          '在上海虹桥站启用双进路同时折返作业，将站台停站时分由 180s 压减至 135s。',
          '推迟非紧急工务天窗点至凌晨 01:30 - 04:30。'
        ]
      });
      setIsSimulating(false);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-y-auto font-sans">
      {/* Top Banner */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-purple-950/60 border border-purple-800 rounded">
            <FlaskConical className="w-4 h-4 text-purple-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                WHAT-IF SCENARIO LAB / 运营演练与突发仿真实验室
              </h2>
              <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800 px-1.5 py-0.5 rounded font-mono">
                MONTE CARLO DISPATCH SOLVER
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Simulate Demand Surges, Track Outages, Severe Weather & Stress-Test Network Resilience
            </p>
          </div>
        </div>

        <button
          onClick={handleRunSimulation}
          disabled={isSimulating}
          className="flex items-center space-x-2 px-4 py-2 rounded bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-bold transition shadow-lg cursor-pointer disabled:opacity-50"
        >
          <Play className="w-3.5 h-3.5" />
          <span>{isSimulating ? 'SIMULATING RUN...' : 'RUN SCENARIO / 启动仿真演练'}</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4 min-h-0">
        
        {/* Left 1 Col: Scenario Presets & Parameter Controls */}
        <div className="flex flex-col space-y-3">
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3">
            <div className="text-xs font-mono font-bold text-slate-300 uppercase border-b border-slate-800 pb-2">
              SCENARIO PRESETS
            </div>

            <div className="space-y-2">
              {SCENARIO_PRESETS.map(preset => (
                <div
                  key={preset.id}
                  onClick={() => {
                    setSelectedScenario(preset);
                    if (preset.parameters.demandMultiplier) {
                      setDemandMultiplier(preset.parameters.demandMultiplier);
                    }
                  }}
                  className={`p-3 rounded border transition cursor-pointer text-xs ${
                    selectedScenario.id === preset.id
                      ? 'bg-[#1e1528] border-purple-500 text-purple-200 shadow-md'
                      : 'bg-[#121824] border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="font-bold text-sm text-white">{preset.name}</div>
                  <div className="text-[11px] text-slate-400 mt-1">{preset.description}</div>
                  <div className="text-[10px] text-purple-400 font-mono mt-1.5">
                    Category: {preset.category}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Parameter Sliders */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3 font-mono text-xs">
            <div className="text-xs font-bold text-slate-300 uppercase border-b border-slate-800 pb-2">
              PARAMETER TUNING
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-slate-400 text-[11px] mb-1">
                  <span>客流需求倍率 (Demand Multiplier):</span>
                  <span className="text-purple-400 font-bold">{demandMultiplier}x</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="2.0"
                  step="0.05"
                  value={demandMultiplier}
                  onChange={(e) => setDemandMultiplier(Number(e.target.value))}
                  className="w-full accent-purple-500 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Simulation Results Comparison Dashboard */}
        <div className="lg:col-span-2 bg-[#0c1018] rounded-lg border border-[#1e293b] p-4 flex flex-col space-y-4 min-h-[480px]">
          <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <span className="font-mono text-purple-300 font-bold flex items-center gap-1.5">
              <FlaskConical className="w-3.5 h-3.5 text-purple-400" />
              SIMULATION OUTPUT: BASELINE VS. SCENARIO DELTA
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              Model: Monte Carlo Dispatch v3.7
            </span>
          </div>

          {simResult ? (
            <div className="space-y-4">
              {/* Delta KPI Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-[#161220] rounded border border-purple-900/60 font-mono">
                  <span className="text-[10px] text-slate-400">准点率变动 (Punctuality)</span>
                  <div className="text-xl font-bold text-rose-400 mt-1">
                    {simResult.deltaPunctuality}%
                  </div>
                </div>

                <div className="p-3 bg-[#161220] rounded border border-purple-900/60 font-mono">
                  <span className="text-[10px] text-slate-400">全网累积延误增量</span>
                  <div className="text-xl font-bold text-amber-400 mt-1">
                    +{simResult.totalDelayDelta} min
                  </div>
                </div>

                <div className="p-3 bg-[#161220] rounded border border-purple-900/60 font-mono">
                  <span className="text-[10px] text-slate-400">枢纽最高拥挤度</span>
                  <div className="text-xl font-bold text-purple-300 mt-1">
                    {simResult.peakCongestion}%
                  </div>
                </div>

                <div className="p-3 bg-[#161220] rounded border border-purple-900/60 font-mono">
                  <span className="text-[10px] text-slate-400">牵引能耗激增</span>
                  <div className="text-xl font-bold text-yellow-400 mt-1">
                    +{simResult.energySurgePercent}%
                  </div>
                </div>
              </div>

              {/* Bottleneck Stations Identified */}
              <div className="p-3.5 bg-[#121824] rounded-lg border border-slate-800 space-y-2">
                <div className="text-xs font-mono font-bold text-slate-300 uppercase">
                  IDENTIFIED BOTTLENECK NODES (关键瓶颈枢纽)
                </div>
                <div className="flex flex-wrap gap-2">
                  {simResult.bottleneckStations.map((sta: string) => (
                    <span key={sta} className="px-2.5 py-1 rounded bg-rose-950/80 text-rose-300 border border-rose-800 text-xs font-mono">
                      ⚠️ {sta}
                    </span>
                  ))}
                </div>
              </div>

              {/* Recommended Dispatch Directives */}
              <div className="p-4 bg-[#0e171b] border border-emerald-800 rounded-lg space-y-2">
                <div className="text-xs font-mono font-bold text-emerald-400 uppercase">
                  GRC AI RECOMMENDED DISPATCH OPTIMIZATION (智能减负调度令建议)
                </div>
                <div className="space-y-1.5 text-xs text-slate-300">
                  {simResult.dispatchActions.map((act: string, idx: number) => (
                    <div key={idx} className="flex items-start space-x-2">
                      <span className="text-emerald-400 font-mono font-bold">•</span>
                      <span>{act}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-500 text-xs font-mono space-y-2">
              <FlaskConical className="w-8 h-8 text-slate-600 animate-pulse" />
              <span>Click "RUN SCENARIO" to execute Monte Carlo multi-train simulation.</span>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
