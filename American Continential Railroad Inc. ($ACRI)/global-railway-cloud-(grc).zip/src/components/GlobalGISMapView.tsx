import React, { useState } from 'react';
import { 
  Globe, 
  Layers, 
  Eye, 
  EyeOff, 
  MapPin, 
  Navigation, 
  Activity, 
  Wind, 
  Zap, 
  ShieldCheck,
  ZoomIn,
  ZoomOut,
  RotateCcw
} from 'lucide-react';
import { COUNTRIES, LINES, STATIONS, LIVE_TRAINS, INCIDENTS } from '../data/seedData';
import { Train, Station } from '../types/railway';

interface GlobalGISMapViewProps {
  onSelectTrain: (train: Train) => void;
  onOpenTrainModal: (train: Train) => void;
}

export const GlobalGISMapView: React.FC<GlobalGISMapViewProps> = ({
  onSelectTrain,
  onOpenTrainModal
}) => {
  const [showHighSpeed, setShowHighSpeed] = useState<boolean>(true);
  const [showConventional, setShowConventional] = useState<boolean>(true);
  const [showStations, setShowStations] = useState<boolean>(true);
  const [showWeatherOverlay, setShowWeatherOverlay] = useState<boolean>(true);
  const [showEnergyOverlay, setShowEnergyOverlay] = useState<boolean>(true);
  const [zoomLevel, setZoomLevel] = useState<number>(1.1);
  const [mapOffset, setMapOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const projectCoordinates = (lng: number, lat: number) => {
    const x = ((lng + 130) / 280) * 900 + 50;
    const y = ((65 - lat) / 45) * 500 + 50;
    return { x, y };
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - mapOffset.x, y: e.clientY - mapOffset.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setMapOffset({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-hidden font-sans relative">
      {/* Top Floating Layer Controls */}
      <div className="absolute top-4 left-4 z-20 bg-[#0f141e]/90 backdrop-blur-md p-3 rounded-lg border border-[#1e293b] shadow-2xl space-y-2 text-xs font-mono">
        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
          <span className="font-bold text-white flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-blue-400" />
            GIS MAP LAYERS (地理图层)
          </span>
        </div>

        <div className="space-y-1.5 pt-1">
          <label className="flex items-center space-x-2 cursor-pointer hover:text-white">
            <input
              type="checkbox"
              checked={showHighSpeed}
              onChange={(e) => setShowHighSpeed(e.target.checked)}
              className="accent-emerald-500 rounded"
            />
            <span className="text-emerald-400 font-semibold">高速铁路网 (HSR ≥250km/h)</span>
          </label>

          <label className="flex items-center space-x-2 cursor-pointer hover:text-white">
            <input
              type="checkbox"
              checked={showConventional}
              onChange={(e) => setShowConventional(e.target.checked)}
              className="accent-blue-500 rounded"
            />
            <span className="text-blue-400 font-semibold">普速/重载干线 (Conventional)</span>
          </label>

          <label className="flex items-center space-x-2 cursor-pointer hover:text-white">
            <input
              type="checkbox"
              checked={showStations}
              onChange={(e) => setShowStations(e.target.checked)}
              className="accent-indigo-500 rounded"
            />
            <span className="text-indigo-300">客货运枢纽站 (Hubs & Yards)</span>
          </label>

          <label className="flex items-center space-x-2 cursor-pointer hover:text-white">
            <input
              type="checkbox"
              checked={showWeatherOverlay}
              onChange={(e) => setShowWeatherOverlay(e.target.checked)}
              className="accent-rose-500 rounded"
            />
            <span className="text-rose-400">大风与极端气象预警区</span>
          </label>

          <label className="flex items-center space-x-2 cursor-pointer hover:text-white">
            <input
              type="checkbox"
              checked={showEnergyOverlay}
              onChange={(e) => setShowEnergyOverlay(e.target.checked)}
              className="accent-yellow-500 rounded"
            />
            <span className="text-yellow-400">接触网供电热力图</span>
          </label>
        </div>
      </div>

      {/* Floating Zoom Controls */}
      <div className="absolute top-4 right-4 z-20 flex items-center space-x-1 bg-[#121722]/90 backdrop-blur-md p-1.5 rounded-md border border-slate-700 shadow-xl">
        <button
          onClick={() => setZoomLevel(prev => Math.min(prev + 0.3, 3.5))}
          className="p-2 hover:bg-slate-700 text-slate-200 rounded cursor-pointer"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={() => setZoomLevel(prev => Math.max(prev - 0.3, 0.6))}
          className="p-2 hover:bg-slate-700 text-slate-200 rounded cursor-pointer"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={() => { setZoomLevel(1.1); setMapOffset({ x: 0, y: 0 }); }}
          className="p-2 hover:bg-slate-700 text-slate-200 rounded cursor-pointer"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Canvas Map Viewport */}
      <div 
        className="flex-1 w-full h-full relative cursor-grab active:cursor-grabbing bg-[#080b10] bg-[radial-gradient(#151e2e_1.2px,transparent_1.2px)] [background-size:28px_28px]"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      >
        <svg 
          className="w-full h-full"
          viewBox="0 0 1000 600"
          style={{
            transform: `translate(${mapOffset.x}px, ${mapOffset.y}px) scale(${zoomLevel})`,
            transformOrigin: 'center center',
            transition: isDragging ? 'none' : 'transform 0.15s ease-out'
          }}
        >
          {/* Continents Contour Approximate Outlines */}
          <g fill="#0e131d" stroke="#1c2536" strokeWidth="1">
            {/* Asia & China Landmass */}
            <path d="M 520,180 L 780,160 L 860,240 L 790,380 L 680,420 L 560,340 Z" />
            {/* Europe Landmass */}
            <path d="M 320,160 L 460,170 L 450,280 L 360,300 L 310,240 Z" />
            {/* North America Landmass */}
            <path d="M 90,140 L 220,150 L 200,320 L 120,310 Z" />
          </g>

          {/* Lines */}
          {LINES.map(line => {
            const isHSR = line.type === 'HIGH_SPEED';
            if (isHSR && !showHighSpeed) return null;
            if (!isHSR && !showConventional) return null;

            const points = line.coordinates.map(coord => {
              const p = projectCoordinates(coord[0], coord[1]);
              return `${p.x},${p.y}`;
            }).join(' ');

            return (
              <g key={line.id}>
                <polyline
                  points={points}
                  fill="none"
                  stroke={isHSR ? '#10b981' : '#3b82f6'}
                  strokeWidth={isHSR ? '3' : '2'}
                  strokeLinecap="round"
                  strokeOpacity="0.85"
                />
              </g>
            );
          })}

          {/* Weather Alert Polygonal Zone */}
          {showWeatherOverlay && (
            <g>
              <polygon
                points="330,220 380,210 390,260 340,270"
                fill="#f43f5e"
                fillOpacity="0.25"
                stroke="#f43f5e"
                strokeWidth="1.5"
                strokeDasharray="4,4"
              />
              <text x="345" y="245" fill="#fda4af" fontSize="9" fontFamily="monospace" fontWeight="bold">
                ⚠️ Gale Wind Warning 25m/s
              </text>
            </g>
          )}

          {/* Stations */}
          {showStations && STATIONS.map(station => {
            const pos = projectCoordinates(station.coordinates[0], station.coordinates[1]);
            return (
              <g key={station.id} className="cursor-pointer group">
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r={station.isHub ? 6 : 4}
                  fill="#0f172a"
                  stroke={station.isHub ? '#38bdf8' : '#cbd5e1'}
                  strokeWidth="2"
                />
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r={2.5}
                  fill="#22c55e"
                />
                <text
                  x={pos.x + 8}
                  y={pos.y + 3}
                  fill="#e2e8f0"
                  fontSize="8.5"
                  fontFamily="monospace"
                  className="font-bold"
                >
                  {station.nameZh}
                </text>
              </g>
            );
          })}

          {/* Live Animated Trains */}
          {LIVE_TRAINS.map(train => {
            const pos = projectCoordinates(train.currentCoordinates[0], train.currentCoordinates[1]);
            return (
              <g
                key={train.id}
                className="cursor-pointer"
                onClick={() => {
                  onSelectTrain(train);
                  onOpenTrainModal(train);
                }}
              >
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r="12"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="1.5"
                  className="radar-ping"
                />
                <rect
                  x={pos.x - 5}
                  y={pos.y - 5}
                  width="10"
                  height="10"
                  rx="2.5"
                  fill="#10b981"
                  stroke="#ffffff"
                  strokeWidth="1.5"
                />
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
};
