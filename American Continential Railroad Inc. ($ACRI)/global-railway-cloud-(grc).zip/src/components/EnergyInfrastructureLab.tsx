import React, { useState } from 'react';
import { 
  Zap, 
  Activity, 
  Layers, 
  TrendingUp, 
  CheckCircle2, 
  AlertTriangle, 
  Gauge, 
  Sliders 
} from 'lucide-react';
import { GLOBAL_KPIS } from '../data/seedData';

export const EnergyInfrastructureLab: React.FC = () => {
  const [selectedSubstation, setSelectedSubstation] = useState<string>('SUB-BJ-01');

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-y-auto font-sans">
      {/* Top Banner */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-yellow-950/60 border border-yellow-800 rounded">
            <Zap className="w-4 h-4 text-yellow-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                ENERGY & INFRASTRUCTURE MONITORING / 能源牵引供电与工务基础设施
              </h2>
              <span className="text-[10px] bg-yellow-950 text-yellow-300 border border-yellow-800 px-1.5 py-0.5 rounded font-mono">
                25kV AC / 50Hz TRACTION GRID
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Catenary Grid Power Flow, Regenerative Braking Energy Recovery & Track Quality Index (TQI)
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4 min-h-0">
        
        {/* Left 2 Cols: Substation Power Flow & Energy Metrics */}
        <div className="lg:col-span-2 flex flex-col space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono">今日总牵引电量</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-yellow-400">
                  {GLOBAL_KPIS.totalEnergyMWh.toLocaleString()}
                </span>
                <span className="text-xs text-slate-400">MWh</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono">再生制动能量反馈</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-emerald-400">
                  {(GLOBAL_KPIS.regenerativeEnergyMWh || 3240).toLocaleString()}
                </span>
                <span className="text-xs text-slate-400">MWh (18.6%)</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono">减排碳当量 (CO2)</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-teal-300">
                  {GLOBAL_KPIS.carbonSavedTonnesToday.toLocaleString()}
                </span>
                <span className="text-xs text-slate-400">吨 / Tonnes</span>
              </div>
            </div>

            <div className="bg-[#0f141e] border border-[#1e293b] p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 font-mono">全网平均 TQI 指数</span>
              <div className="mt-1 flex items-baseline space-x-1">
                <span className="text-2xl font-mono-num font-bold text-blue-400">
                  3.82
                </span>
                <span className="text-xs text-slate-400">mm (优 / A级)</span>
              </div>
            </div>
          </div>

          {/* Substation Grid Flow Visualizer */}
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-4 space-y-3 flex-1">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="font-mono font-bold text-slate-200 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-yellow-400" />
                TRACTION SUBSTATIONS ELECTRICAL BUS STATUS (牵引变电所母线负荷)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 font-mono text-xs">
              {[
                { id: 'SUB-BJ-01', name: '北京南牵引变电所', loadMw: 42.5, voltageKv: 27.2, powerFactor: 0.98 },
                { id: 'SUB-JN-02', name: '济南西牵引变电所', loadMw: 36.8, voltageKv: 26.8, powerFactor: 0.97 },
                { id: 'SUB-SH-03', name: '上海虹桥牵引变电所', loadMw: 58.4, voltageKv: 27.0, powerFactor: 0.99 }
              ].map(sub => (
                <div key={sub.id} className="p-3 bg-[#121824] rounded-lg border border-slate-800 space-y-2">
                  <div className="font-bold text-white text-xs">{sub.name}</div>
                  <div className="space-y-1 text-[11px] text-slate-400">
                    <div className="flex justify-between">
                      <span>瞬时功率:</span>
                      <span className="text-yellow-400 font-bold">{sub.loadMw} MW</span>
                    </div>
                    <div className="flex justify-between">
                      <span>母线电压:</span>
                      <span className="text-emerald-400 font-bold">{sub.voltageKv} kV</span>
                    </div>
                    <div className="flex justify-between">
                      <span>功率因数 cosφ:</span>
                      <span className="text-slate-200">{sub.powerFactor}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Track Quality Index (TQI) Section Inspection */}
        <div className="flex flex-col space-y-3">
          <div className="bg-[#0f141e] border border-[#1e293b] rounded-lg p-3.5 space-y-3 flex-1 flex flex-col">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="font-mono font-bold text-slate-200 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                TRACK QUALITY INDEX (TQI 轨道几何状态)
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded">
                综合检测车 (CIT500)
              </span>
            </div>

            <div className="space-y-3 font-mono text-xs">
              {[
                { metric: '高低不平顺 (Profile)', value: '0.84 mm', limit: '< 2.0 mm', status: 'GOOD' },
                { metric: '轨向不平顺 (Alignment)', value: '0.72 mm', limit: '< 2.0 mm', status: 'GOOD' },
                { metric: '水平偏差 (Cross Level)', value: '0.65 mm', limit: '< 2.0 mm', status: 'GOOD' },
                { metric: '轨距偏差 (Gauge Deviation)', value: '+0.4 mm', limit: '±2.0 mm', status: 'GOOD' },
                { metric: '三角坑 (Twist 18m)', value: '1.10 mm', limit: '< 3.0 mm', status: 'GOOD' },
                { metric: '接触网导高 (Wire Height)', value: '5,300 mm', limit: '5,300±50', status: 'OPTIMAL' }
              ].map(item => (
                <div key={item.metric} className="p-2.5 bg-[#121824] rounded border border-slate-800 flex justify-between items-center">
                  <div>
                    <div className="font-bold text-slate-200 text-xs">{item.metric}</div>
                    <div className="text-[10px] text-slate-500">限值: {item.limit}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-emerald-400 font-bold">{item.value}</div>
                    <div className="text-[9px] text-slate-400">{item.status}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
