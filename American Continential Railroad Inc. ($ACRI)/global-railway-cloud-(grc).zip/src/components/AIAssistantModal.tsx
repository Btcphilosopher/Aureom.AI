import React, { useState } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Terminal, 
  Database, 
  Cpu, 
  Clock, 
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import Markdown from 'react-markdown';

export const AIAssistantModal: React.FC = () => {
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string; source?: string }>>([
    {
      role: 'assistant',
      text: `### 欢迎使用 GRC 全球铁路智能运行控制助理 (Gemini 3.8 / GRC Engine)

我是 Global Railway Cloud (GRC) 的核心调度与数字孪生分析专家。我可以协助您完成：
- **实时运行监控与延误归因**（如：分析京沪高铁晚点根因与连带传播）
- **动车组车辆预测性维护 (PHM)**（如：分析电机轴承振动频谱与 RUL 寿命）
- **枢纽站场进路优化与时刻表解冲**（如：上海虹桥 30 股道冲突策略）
- **中欧班列跨国走廊与换装追踪**（如：阿拉山口与布列斯特换装时效）

请直接输入指令，或点击下方快捷分析问题。`,
      source: 'GRC Dispatch Intelligence'
    }
  ]);

  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const samplePrompts = [
    '上海虹桥枢纽今天哪些线路最拥挤？请给出客流与股道调度建议',
    '为什么 G1234 / 京沪方向平均延误增加？进行连带级联分析',
    '分析德铁 RS-ICE4-001 动车组轴承温度与振动频谱故障风险',
    '如果关闭南京南至镇江区间线路 6 小时，全网会发生什么？'
  ];

  const handleSend = async (textToSend?: string) => {
    const prompt = textToSend || inputPrompt;
    if (!prompt.trim() || isLoading) return;

    const userMessage = { role: 'user' as const, text: prompt };
    setMessages(prev => [...prev, userMessage]);
    if (!textToSend) setInputPrompt('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/v1/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: data.text || '分析完成。',
          source: data.source || 'GRC Core Analytics'
        }
      ]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: '抱歉，请求铁路智能引擎分析时遇到网络异常，请重试。',
          source: 'Error Handler'
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-[#090c12] text-slate-200 overflow-hidden font-sans">
      {/* Top Banner */}
      <div className="p-3 bg-[#0f141e] border-b border-[#1e293b] flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-purple-950/60 border border-purple-800 rounded">
            <Bot className="w-4 h-4 text-purple-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-mono font-bold text-sm text-white">
                GRC RAILWAY INTELLIGENCE ASSISTANT / 铁路综合智能调度助理
              </h2>
              <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800 px-1.5 py-0.5 rounded font-mono">
                GEMINI 3.8 REASONING
              </span>
            </div>
            <p className="text-xs text-slate-400">
              URDM Semantic Querying, Dispatch Optimization & Predictive Engineering Intelligence
            </p>
          </div>
        </div>
      </div>

      {/* Main Chat Workspace */}
      <div className="flex-1 flex flex-col p-4 overflow-hidden max-w-5xl mx-auto w-full">
        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-3xl rounded-lg p-4 text-xs leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-blue-600 text-white font-medium'
                    : 'bg-[#121824] border border-[#1e293b] text-slate-200 shadow-md'
                }`}
              >
                {m.role === 'assistant' ? (
                  <div className="markdown-body space-y-2 text-slate-200 text-xs">
                    <Markdown>{m.text}</Markdown>
                  </div>
                ) : (
                  <div>{m.text}</div>
                )}

                {m.source && (
                  <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-purple-400" />
                      Source: {m.source}
                    </span>
                    <span>{new Date().toLocaleTimeString()}</span>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center space-x-2 p-3 bg-[#121824] border border-slate-800 rounded-lg max-w-sm text-xs font-mono text-slate-400">
              <Sparkles className="w-4 h-4 text-purple-400 animate-spin" />
              <span>GRC Engine is synthesizing live railway telemetry...</span>
            </div>
          )}
        </div>

        {/* Quick Sample Queries */}
        <div className="py-2 flex items-center space-x-2 overflow-x-auto no-scrollbar">
          <span className="text-[10px] font-mono text-slate-500 uppercase shrink-0">
            PROMPT LAB:
          </span>
          {samplePrompts.map((p, i) => (
            <button
              key={i}
              onClick={() => handleSend(p)}
              className="text-[11px] bg-[#141a24] hover:bg-[#1a2333] border border-slate-800 hover:border-slate-600 text-slate-300 px-2.5 py-1 rounded transition whitespace-nowrap cursor-pointer"
            >
              {p.slice(0, 24)}...
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="pt-2">
          <div className="flex items-center space-x-2 bg-[#121824] border border-slate-700 rounded-lg p-1.5 focus-within:border-blue-500 shadow-lg">
            <Terminal className="w-4 h-4 text-slate-500 ml-2" />
            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask GRC Intelligence (e.g., '分析京沪高铁晚点根因与处置方案')..."
              className="flex-1 bg-transparent border-none text-xs text-slate-100 placeholder-slate-500 focus:outline-none font-mono"
            />
            <button
              onClick={() => handleSend()}
              disabled={isLoading || !inputPrompt.trim()}
              className="p-2 rounded bg-blue-600 hover:bg-blue-500 text-white transition disabled:opacity-40 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
