import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Train as TrainIcon, 
  Building2, 
  Globe, 
  AlertTriangle, 
  X, 
  Command, 
  ArrowRight,
  Layers
} from 'lucide-react';
import { LIVE_TRAINS, STATIONS, LINES, INTERNATIONAL_CORRIDORS } from '../data/seedData';
import { Train, Station, RailwayLine } from '../types/railway';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTrain: (train: Train) => void;
  onSelectStation: (station: Station) => void;
  onSelectTab: (tab: string) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onSelectTrain,
  onSelectStation,
  onSelectTab
}) => {
  const [query, setQuery] = useState<string>('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredTrains = LIVE_TRAINS.filter(t => 
    t.serviceNumber.toLowerCase().includes(query.toLowerCase()) ||
    t.originStationName.toLowerCase().includes(query.toLowerCase()) ||
    t.destinationStationName.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 4);

  const filteredStations = STATIONS.filter(s =>
    s.name.toLowerCase().includes(query.toLowerCase()) ||
    s.nameZh.includes(query) ||
    s.countryId.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 4);

  const filteredLines = LINES.filter(l =>
    l.name.toLowerCase().includes(query.toLowerCase()) ||
    l.nameZh.includes(query)
  ).slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-start justify-center pt-20 p-4">
      <div className="bg-[#0f141e] border border-[#2d3748] rounded-xl shadow-2xl w-full max-w-2xl text-slate-200 overflow-hidden font-sans animate-in fade-in zoom-in-95 duration-100">
        {/* Search Bar Input */}
        <div className="p-3.5 border-b border-[#222e40] flex items-center space-x-3 bg-[#131926]">
          <Search className="w-5 h-5 text-blue-400" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command, train number (G1234, Nozomi 312), station, or line..."
            className="flex-1 bg-transparent border-none text-sm text-white placeholder-slate-500 focus:outline-none font-mono"
          />
          <kbd className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="p-3 space-y-4 max-h-[60vh] overflow-y-auto">
          {/* Quick Tab Commands */}
          <div>
            <div className="text-[10px] font-mono uppercase text-slate-500 px-2 mb-1 font-bold">
              QUICK MODULE SWITCHER
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs font-mono">
              {[
                { id: 'occ', label: 'OPERATIONS OCC' },
                { id: 'twin', label: 'ROLLING STOCK TWIN' },
                { id: 'station', label: 'STATION TWIN' },
                { id: 'timetable', label: 'STRINGLINE CHART' },
                { id: 'delay', label: 'DELAY INTELLIGENCE' },
                { id: 'freight', label: 'CORRIDORS' },
                { id: 'scenario', label: 'SCENARIO LAB' },
                { id: 'ai', label: 'AI ASSISTANT' }
              ].map(t => (
                <button
                  key={t.id}
                  onClick={() => { onSelectTab(t.id); onClose(); }}
                  className="p-2 rounded bg-[#161d2b] hover:bg-blue-600 hover:text-white text-slate-300 text-left transition cursor-pointer"
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Trains */}
          {filteredTrains.length > 0 && (
            <div>
              <div className="text-[10px] font-mono uppercase text-slate-500 px-2 mb-1 font-bold">
                TRAIN SERVICES
              </div>
              <div className="space-y-1">
                {filteredTrains.map(train => (
                  <button
                    key={train.id}
                    onClick={() => { onSelectTrain(train); onClose(); }}
                    className="w-full text-left p-2.5 rounded bg-[#141b27] hover:bg-[#1f2a3d] border border-slate-800/80 flex items-center justify-between text-xs transition cursor-pointer group"
                  >
                    <div className="flex items-center space-x-2.5">
                      <TrainIcon className="w-4 h-4 text-emerald-400" />
                      <div>
                        <span className="font-mono font-bold text-white">{train.serviceNumber}</span>
                        <span className="text-slate-400 ml-2">
                          {train.originStationName} ➔ {train.destinationStationName}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 font-mono text-[11px]">
                      <span className="text-emerald-400">{train.currentSpeedKmH} km/h</span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-blue-400 transition" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Stations */}
          {filteredStations.length > 0 && (
            <div>
              <div className="text-[10px] font-mono uppercase text-slate-500 px-2 mb-1 font-bold">
                STATION HUBS
              </div>
              <div className="space-y-1">
                {filteredStations.map(station => (
                  <button
                    key={station.id}
                    onClick={() => { onSelectStation(station); onClose(); }}
                    className="w-full text-left p-2.5 rounded bg-[#141b27] hover:bg-[#1f2a3d] border border-slate-800/80 flex items-center justify-between text-xs transition cursor-pointer group"
                  >
                    <div className="flex items-center space-x-2.5">
                      <Building2 className="w-4 h-4 text-indigo-400" />
                      <div>
                        <span className="font-bold text-white">{station.nameZh}</span>
                        <span className="text-slate-400 text-xs ml-2 font-mono">({station.name} - {station.countryId})</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 font-mono text-[11px] text-slate-400">
                      <span>{station.tracksCount} tracks</span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-blue-400 transition" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-2.5 bg-[#0b0e14] border-t border-[#1e293b] flex items-center justify-between text-[11px] font-mono text-slate-500">
          <span>Global Railway Cloud Command Center</span>
          <span>Press ESC to dismiss</span>
        </div>
      </div>
    </div>
  );
};
