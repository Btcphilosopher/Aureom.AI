/**
 * Universal Railway Data Model (URDM)
 * Global Railway Cloud (GRC) - Enterprise Standard v3.7
 */

export type GaugeType = '1435mm_STANDARD' | '1520mm_BROAD_RUSSIAN' | '1676mm_INDIAN_BROAD' | '1067mm_CAPE_NARROW' | '1000mm_METER';
export type ElectrificationType = '25kV_50Hz_AC' | '25kV_60Hz_AC' | '15kV_16_7Hz_AC' | '3kV_DC' | '1_5kV_DC' | '750V_DC_THIRD_RAIL' | 'DIESEL_NONE';
export type SignallingType = 'CTCS-3' | 'CTCS-2' | 'ETCS_L2' | 'ETCS_L1' | 'ATC_SHINKANSEN' | 'PTC_US' | 'KAVACH_INDIA' | 'CBTC_URBAN';

export interface Country {
  id: string; // e.g. 'CN', 'GB', 'JP', 'DE', 'FR', 'IN', 'US', 'CA', 'AU', 'KZ'
  name: string;
  nameZh: string;
  flag: string;
  continent: 'Asia' | 'Europe' | 'North America' | 'Oceania' | 'Africa' | 'South America';
  primaryGauge: GaugeType;
  primaryVoltage: ElectrificationType;
  primarySignalling: SignallingType;
  totalNetworkKm: number;
  hsrNetworkKm: number;
  totalStations: number;
  authorities: RailwayAuthority[];
}

export interface RailwayAuthority {
  id: string;
  countryId: string;
  name: string;
  nameZh: string;
  code: string; // e.g. 'NRA' (China National Railway Administration), 'DfT' (UK), 'FRA' (US), 'ERA' (Europe)
  headquarters: string;
  operationalRegions: OperationalRegion[];
}

export interface OperationalRegion {
  id: string;
  authorityId: string;
  name: string;
  nameZh: string;
  code: string; // e.g. 'CR-BEIJING', 'CR-SHANGHAI', 'NR-SOUTHERN', 'DB-WEST'
  dispatchCenter: string;
  status: 'OPTIMAL' | 'DEGRADED' | 'WARNING' | 'EMERGENCY';
}

export interface RailwayOperator {
  id: string;
  countryId: string;
  name: string;
  nameZh: string;
  shortCode: string; // e.g. 'CR', 'DB', 'SNCF', 'JR-EAST', 'AMTRAK', 'LNER', 'IR'
  logo: string;
  type: 'PASSENGER_HSR' | 'PASSENGER_REGIONAL' | 'FREIGHT' | 'MIXED' | 'URBAN_TRANSIT';
  tenantId: string;
  activeTrains: number;
  fleetSize: number;
  punctualityRate: number; // e.g. 98.4%
  dailyPassengerKm: number;
  dailyFreightTonneKm: number;
}

export interface RailwayLine {
  id: string;
  countryId: string;
  operatorIds: string[];
  name: string;
  nameZh: string;
  code: string; // e.g. 'BJ-SH-HSR', 'TOKAIDO-SHINKANSEN', 'LGV-SUD-EST', 'NEC'
  type: 'HIGH_SPEED' | 'CONVENTIONAL' | 'HEAVY_HAUL_FREIGHT' | 'INTERMODAL_CORRIDOR' | 'METRO';
  totalLengthKm: number;
  maxDesignSpeed: number; // km/h
  trackGauge: GaugeType;
  electrification: ElectrificationType;
  signalling: SignallingType;
  stationIds: string[];
  coordinates: [number, number][]; // Polyline GeoJSON [[lng, lat], ...]
  status: 'NORMAL' | 'SPEED_RESTRICTED' | 'MAINTENANCE' | 'DISRUPTED';
  currentSpeedLimit: number; // km/h
  capacityTrainsPerHour: number;
  utilizedCapacityPercent: number;
}

export interface Station {
  id: string;
  countryId: string;
  regionId: string;
  name: string;
  nameZh: string;
  code: string; // e.g. 'SHH', 'BJP', 'TYO', 'STP', 'PAR-GDL', 'BER-HBF', 'NYP'
  city: string;
  coordinates: [number, number]; // [lng, lat]
  platformsCount: number;
  tracksCount: number;
  isHub: boolean;
  isBorderStation: boolean;
  gaugeChangeCapable: boolean;
  dailyPassengerVolume: number;
  dailyFootfall?: number;
  averageDwellTimeSec?: number;
  currentCrowdDensity: number; // 0-100%
  status: 'NORMAL' | 'HIGH_CROWD' | 'PLATFORM_RESTRICTION' | 'MAINTENANCE';
  connectedLineIds: string[];
  platforms: Platform[];
  substations: Substation[];
}

export interface Platform {
  id: string;
  stationId: string;
  number: string;
  trackId: string;
  lengthMeters: number;
  currentTrainId?: string | null;
  scheduledArrival?: string;
  scheduledDeparture?: string;
  status: 'OCCUPIED' | 'AVAILABLE' | 'BLOCKED' | 'APPROACHING';
}

export interface Substation {
  id: string;
  name: string;
  voltageInKv: number;
  voltageOutKv: number;
  currentLoadMva: number;
  capacityMva: number;
  temperatureC: number;
  status: 'NOMINAL' | 'PEAK_LOAD' | 'MAINTENANCE' | 'ALERT';
}

export type TrainType = 'HSR_EMU' | 'STANDARD_EMU' | 'DMU' | 'ELECTRIC_LOCOMOTIVE' | 'DIESEL_FREIGHT' | 'METRO';

export interface RollingStock {
  id: string;
  model: string; // e.g. 'CR400AF-Z', 'CR400BF', 'Shinkansen N700S', 'TGV Duplex', 'ICE 4', 'Acela II', 'Vande Bharat'
  series: string;
  manufacturer: string; // e.g. 'CRRC Qingdao Sifang', 'Hitachi / Kawasaki', 'Alstom', 'Siemens Mobility'
  operatorId: string;
  countryId: string;
  buildYear: number;
  totalMileageKm: number;
  operatingHours: number;
  maxSpeed: number;
  formationLength: number; // Carriages count, e.g. 8 or 16
  formation?: string;
  passengerCapacity: number;
  totalPowerKw: number;
  healthScore: number; // 0-100
  telemetryHealthScore?: number;
  estimatedRulDays: number; // Remaining Useful Life
  nextScheduledOverhaul: string;
  condition: {
    tractionMotor: number; // 0-100
    bogieWheels: number;
    pantograph: number;
    brakingSystem: number;
    hvac: number;
    batteries: number;
  };
}

export interface Train {
  id: string;
  serviceNumber: string; // e.g. 'G1234', 'Shinkansen 312', 'TGV 8421', 'ICE 612', '1A84', 'Acela 2150'
  rollingStockId: string;
  rollingStockModel: string;
  operatorId: string;
  countryId: string;
  lineId: string;
  originStationId: string;
  originStationName: string;
  destinationStationId: string;
  destinationStationName: string;
  trainType: TrainType;
  status: 'RUNNING' | 'DWELLING' | 'DELAYED' | 'STOPPED' | 'HOLD_SIGNAL' | 'MAINTENANCE';
  
  // Real-time kinematics & location
  currentCoordinates: [number, number]; // [lng, lat]
  headingDeg: number;
  currentSpeedKmH: number;
  targetSpeedKmH: number;
  routeProgressPercent: number; // 0-100%
  
  // Real-time schedule
  nextStationId: string;
  nextStationName: string;
  scheduledNextArrival: string;
  estimatedNextArrival: string;
  delayMinutes: number; // 0 = on-time, >0 delayed, <0 ahead
  
  // Operational telemetries
  passengerLoadPercent: number;
  cargoTonnage?: number;
  currentPowerDrawKw: number;
  todayEnergyMWh: number;
  regenerativeBrakingKw: number;
  
  // Subsystem real-time parameters
  telemetry: TrainTelemetry;
}

export interface TrainTelemetry {
  motorTempC: number;
  motorCurrentA: number;
  catenaryVoltageV: number;
  brakePipePressureKPa: number;
  pantographVibrationG: number;
  bearingVibrationMmS: number;
  axleTemp1C: number;
  axleTemp2C: number;
  cabinTempC: number;
  safetyBrakingDistanceMeters: number;
  tractionEfficiencyPercent: number;
  anomalyScore: number; // 0-100 (high = alert)
}

export interface Incident {
  id: string;
  incidentNumber: string;
  countryId: string;
  operatorId: string;
  lineId: string;
  stationId?: string;
  severity: 'CRITICAL' | 'MAJOR' | 'MODERATE' | 'MINOR';
  type: 'SIGNAL_FAILURE' | 'CATENARY_DROP' | 'TRACK_GEOMETRY' | 'ROLLING_STOCK_FAULT' | 'EXTREME_WEATHER' | 'PASSENGER_OBSTRUCTION' | 'CROSSING_ALERT';
  title: string;
  description: string;
  timestamp: string;
  affectedTrainsCount: number;
  affectedPassengersEstimate: number;
  estimatedNetworkDelayMin: number;
  responseStatus: 'INVESTIGATING' | 'DISPATCHED' | 'ON_SITE_REPAIR' | 'RESTRICTED_OPS' | 'RESOLVED';
  etaRecovery: string;
}

export interface TimetableEntry {
  id: string;
  serviceNumber: string;
  lineId: string;
  stationId: string;
  stationName: string;
  platformNumber: string;
  arrivalTime: string;
  departureTime: string;
  dwellMinutes: number;
  distanceKm: number;
  isStopping: boolean;
}

export interface TimetableConflict {
  id: string;
  type: 'HEADWAY_VIOLATION' | 'PLATFORM_OVERLAP' | 'TRACK_CONFLICT' | 'OVERTAKING_COLLISION';
  conflictType?: string;
  locationStationName?: string;
  aiResolutionProposal?: string;
  lineId: string;
  stationId?: string;
  trainId1: string;
  trainId2: string;
  severity: 'HIGH' | 'MEDIUM';
  description: string;
  suggestedResolution: string;
}

export interface DelayAttribution {
  category: 'INFRASTRUCTURE' | 'ROLLING_STOCK' | 'SIGNALLING' | 'WEATHER' | 'PASSENGER' | 'CREW_DISPATCH' | 'CONGESTION';
  percent: number;
  minutes: number;
  primaryCause: string;
}

export interface InternationalCorridor {
  id: string;
  name: string;
  nameZh: string;
  code: string; // e.g. 'CREXPRESS-YIWU-MADRID', 'BELT_ROAD_CENTRAL_ASIA'
  countries: string[];
  totalDistanceKm: number;
  totalLengthKm?: number;
  countriesCrossed?: string[];
  annualTeuCapacity?: number;
  averageTransitDays?: number;
  gaugeBreakPoints?: any[];
  transitDays: number;
  gaugeChanges: {
    stationId: string;
    stationName: string;
    countryFrom: string;
    countryTo: string;
    gaugeFrom: GaugeType;
    gaugeTo: GaugeType;
    averageHandlingHours: number;
  }[];
  activeFreightTrainsCount: number;
  annualTeuContainers: number;
  interoperabilityStatus: 'FULL_STANDARD' | 'BORDER_INSPECTION_DELAY' | 'CAPACITY_CONGESTION';
}

export interface NetworkKPIs {
  globalActiveTrains: number;
  onTimePunctualityPercent: number;
  totalNetworkKm: number;
  dailyPassengersMillion: number;
  dailyFreightMillionTonnes: number;
  totalEnergyMWh: number;
  regenerativeEnergyMWh?: number;
  activeIncidentsCount: number;
  averageDelayMinutes: number;
  systemReliabilityPercent: number;
  carbonSavedTonnesToday: number;
}

export interface ScenarioSimulation {
  id: string;
  name: string;
  description: string;
  category?: string;
  scenarioType: 'DEMAND_SURGE' | 'TRACK_CLOSURE' | 'EXTREME_WEATHER' | 'SPEED_RESTRICTION' | 'SUBSTATION_OUTAGE';
  parameters: {
    targetLineId?: string;
    targetStationId?: string;
    demandMultiplier?: number;
    durationHours?: number;
    speedReductionPercent?: number;
  };
  simulatedResults?: {
    totalDelayMinutesDelta: number;
    passengerCongestionPeakPercent: number;
    cancelledServicesCount: number;
    energySurgePercent: number;
    bottleneckStations: string[];
    recommendedAction: string;
  };
}

export type ScenarioPreset = ScenarioSimulation;
