package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

object SmartRailIcons {
    val Train: ImageVector = Icons.Default.PlayArrow
    val Wallet: ImageVector = Icons.Default.Home
    val Analytics: ImageVector = Icons.Default.Favorite
    val NationalRail: ImageVector = Icons.Default.Star
    val Route: ImageVector = Icons.Default.LocationOn
}
