package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SmartRailColorScheme = darkColorScheme(
    primary = RailOrange,
    onPrimary = Color.White,
    primaryContainer = RailNavy,
    onPrimaryContainer = Color.White,
    secondary = SteelGrey,
    onSecondary = Color.White,
    tertiary = StationLedAmber,
    onTertiary = Color.Black,
    background = DarkBackground,
    onBackground = OnDarkSurface,
    surface = DarkSurface,
    onSurface = OnDarkSurface,
    surfaceVariant = StationAmethyst,
    onSurfaceVariant = Color.White,
    error = StationRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force the thematic dark-navy experience by default
    dynamicColor: Boolean = false, // Disable dynamic colors to preserve our brand identity
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SmartRailColorScheme,
        typography = Typography,
        content = content
    )
}
