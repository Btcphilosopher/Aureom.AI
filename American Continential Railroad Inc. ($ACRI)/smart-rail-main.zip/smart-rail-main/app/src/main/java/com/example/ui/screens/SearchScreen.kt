package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Journey
import com.example.model.Station
import com.example.ui.components.SmartRailIcons
import com.example.ui.theme.*
import com.example.viewmodel.RailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: RailViewModel,
    onBooked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val searchResults by viewModel.searchResults.collectAsState()
    val priceHistory by viewModel.priceHistory.collectAsState()
    val origin by viewModel.searchOrigin.collectAsState()
    val destination by viewModel.searchDestination.collectAsState()
    val sDate by viewModel.searchDate.collectAsState()
    val sTime by viewModel.searchTime.collectAsState()
    val railcard by viewModel.searchRailcard.collectAsState()

    val focusManager = LocalFocusManager.current

    // Expanded states
    var originExpanded by remember { mutableStateOf(false) }
    var destExpanded by remember { mutableStateOf(false) }
    var railcardExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // App header aesthetic
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column {
                    Text(
                        text = "RAILCORE OS v2.2",
                        fontSize = 10.sp,
                        color = SteelGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Journey Planner",
                        fontSize = 22.sp,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Geometric Balance badge (circle + square)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(DarkSurface, shape = RoundedCornerShape(20.dp))
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)), shape = RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .border(BorderStroke(2.dp, Color.White.copy(alpha = 0.40f)), shape = RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        // Search Input Engine Box
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Origin Station Dropdown Selection
                    Box {
                        OutlinedTextField(
                            value = "${origin} - ${Station.findByCode(origin).name}",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("From (Origin)") },
                            trailingIcon = {
                                Icon(
                                    Icons.Default.ArrowDropDown,
                                    "Expand",
                                    Modifier.clickable { originExpanded = true })
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("origin_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RailOrange,
                                unfocusedBorderColor = SteelGrey.copy(alpha = 0.5f),
                                focusedLabelColor = RailOrange
                            )
                        )
                        DropdownMenu(
                            expanded = originExpanded,
                            onDismissRequest = { originExpanded = false },
                            modifier = Modifier.background(StationAmethyst)
                        ) {
                            Station.PRESETS.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text("${station.code} - ${station.name}", color = Color.White) },
                                    onClick = {
                                        viewModel.searchOrigin.value = station.code
                                        originExpanded = false
                                        viewModel.executeFareSearch()
                                    }
                                )
                            }
                        }
                    }

                    // Swap stations floating row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = { viewModel.reverseSearch() },
                            modifier = Modifier
                                .size(36.dp)
                                .background(RailNavy, RoundedCornerShape(50))
                                .testTag("swap_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Swap Stations",
                                tint = RailOrange,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Destination Dropdown Selection
                    Box {
                        OutlinedTextField(
                            value = "${destination} - ${Station.findByCode(destination).name}",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("To (Destination)") },
                            trailingIcon = {
                                Icon(
                                    Icons.Default.ArrowDropDown,
                                    "Expand",
                                    Modifier.clickable { destExpanded = true })
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("destination_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RailOrange,
                                unfocusedBorderColor = SteelGrey.copy(alpha = 0.5f),
                                focusedLabelColor = RailOrange
                            )
                        )
                        DropdownMenu(
                            expanded = destExpanded,
                            onDismissRequest = { destExpanded = false },
                            modifier = Modifier.background(StationAmethyst)
                        ) {
                            Station.PRESETS.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text("${station.code} - ${station.name}", color = Color.White) },
                                    onClick = {
                                        viewModel.searchDestination.value = station.code
                                        destExpanded = false
                                        viewModel.executeFareSearch()
                                    }
                                )
                            }
                        }
                    }

                    // Row of Date/Time
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = sDate,
                            onValueChange = { viewModel.searchDate.value = it },
                            label = { Text("Date (YYYY-MM-DD)", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("date_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RailOrange,
                                unfocusedBorderColor = SteelGrey.copy(alpha = 0.3f),
                                focusedLabelColor = RailOrange
                            )
                        )

                        OutlinedTextField(
                            value = sTime,
                            onValueChange = { viewModel.searchTime.value = it },
                            label = { Text("Depart. (HH:MM)", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("time_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RailOrange,
                                unfocusedBorderColor = SteelGrey.copy(alpha = 0.3f),
                                focusedLabelColor = RailOrange
                            )
                        )
                    }

                    // Railcards Discounter dropdown selection
                    Box {
                        OutlinedTextField(
                            value = railcard,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Railcard Discounts") },
                            trailingIcon = {
                                Icon(
                                    Icons.Default.ArrowDropDown,
                                    "Expand",
                                    Modifier.clickable { railcardExpanded = true })
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("railcard_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RailOrange,
                                unfocusedBorderColor = SteelGrey.copy(alpha = 0.5f),
                                focusedLabelColor = RailOrange
                            )
                        )
                        DropdownMenu(
                            expanded = railcardExpanded,
                            onDismissRequest = { railcardExpanded = false },
                            modifier = Modifier.background(StationAmethyst)
                        ) {
                            listOf(
                                "No Railcard",
                                "16-25 Railcard",
                                "Two Together Railcard",
                                "Senior Railcard",
                                "Family & Friends Railcard"
                            ).forEach { cardOption ->
                                DropdownMenuItem(
                                    text = { Text(cardOption, color = Color.White) },
                                    onClick = {
                                        viewModel.searchRailcard.value = cardOption
                                        railcardExpanded = false
                                        viewModel.executeFareSearch()
                                    }
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.executeFareSearch()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("search_submit_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = RailOrange),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "OPTIMISE & CALC FARES",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // Save commute / commuter shortcuts fast bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Frequent commuting route?",
                    style = MaterialTheme.typography.bodySmall,
                    color = SteelGrey
                )
                TextButton(
                    onClick = { viewModel.saveCurrentSearchAsCommute() },
                    colors = ButtonDefaults.textButtonColors(contentColor = RailOrange)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Bookmark Route", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Volatility Demand Forecast Box & Airlines-style analytics graph
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.7f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = SmartRailIcons.Analytics,
                                contentDescription = null,
                                tint = RailYellow,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Airline-Style Pricing Intelligence",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Badge(containerColor = StationGreen, contentColor = Color.White) {
                            Text("BUY NOW ADVISED", fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                        }
                    }

                    Text(
                        text = "Historical price trends and demand forecasting for ${origin} ➔ ${destination}:",
                        style = MaterialTheme.typography.bodySmall,
                        color = SteelGrey,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    // Draw the custom Canvas pricing trend line graph (from the design guidelines)
                    if (priceHistory.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                        ) {
                            PricingCanvasGraph(priceHistory = priceHistory)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "⚠️ Trend Prediction: Heavy peak loads starting in 3 days. Average fare expected to rise by +42% as advance single allocations exhaust. Seat availability currently at peak (98%).",
                        fontSize = 11.sp,
                        color = RailYellow,
                        lineHeight = 15.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Live optimized results headline
        item {
            Text(
                text = "SURFACED OPTIONS FOR YOUR RUN",
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Fares feed list
        if (searchResults.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = RailOrange)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Executing low-fare calculation engines...", color = SteelGrey, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(searchResults) { journey ->
                JourneyFareItem(
                    journey = journey,
                    onBookClick = {
                        viewModel.bookJourney(journey)
                        onBooked()
                    }
                )
            }
        }
    }
}

@Composable
fun PricingCanvasGraph(priceHistory: List<Pair<String, Double>>) {
    val prices = priceHistory.map { it.second }
    val maxPrice = prices.maxOrNull() ?: 100.0
    val minPrice = prices.minOrNull() ?: 0.0
    val priceDiff = maxOf(1.0, maxPrice - minPrice)

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
    ) {
        val width = size.width
        val height = size.height
        val sizeMinusPadding = height - 40f
        val points = priceHistory.size

        val stepX = width / (points - 1).toFloat()
        val path = Path()

        // Generate points coordinates
        val coords = priceHistory.mapIndexed { i, pair ->
            val fraction = (pair.second - minPrice) / priceDiff
            val y = height - 20f - (fraction.toFloat() * sizeMinusPadding)
            val x = i * stepX
            Offset(x, y)
        }

        // Draw background gradient area under line graph
        val bgPath = Path()
        bgPath.moveTo(0f, height)
        coords.forEach { bgPath.lineTo(it.x, it.y) }
        bgPath.lineTo(width, height)
        bgPath.close()

        drawPath(
            path = bgPath,
            brush = Brush.verticalGradient(
                colors = listOf(RailOrange.copy(alpha = 0.25f), Color.Transparent)
            )
        )

        // Draw the main elegant orange line
        path.moveTo(coords.first().x, coords.first().y)
        for (i in 1 until coords.size) {
            path.lineTo(coords[i].x, coords[i].y)
        }

        drawPath(
            path = path,
            color = RailOrange,
            style = Stroke(width = 3.dp.toPx())
        )

        // Draw indicator knots for key entries: Today (which is index 14 out of 22 typically in list)
        coords.forEachIndexed { idx, pt ->
            if (idx == 14) { // Today marker point
                drawCircle(
                    color = RailYellow,
                    radius = 5.dp.toPx(),
                    center = pt
                )
                drawCircle(
                    color = Color.Black,
                    radius = 2.dp.toPx(),
                    center = pt
                )
            }
        }
    }
}

@Composable
fun JourneyFareItem(
    journey: Journey,
    onBookClick: () -> Unit
) {
    val isSplit = journey.fareCombination.type == "SplitTicket"
    val isAlt = journey.fareCombination.type == "AlternativeRoute"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("journey_card_${journey.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSplit) Color.White else StationAmethyst
        ),
        shape = RoundedCornerShape(24.dp), // geometric curved edge matching tailwind "rounded-3xl"
        border = if (isSplit) null else BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
    ) {
        val contentColor = if (isSplit) RailNavy else Color.White
        val subTextColor = if (isSplit) Color(0xFF64748B) else SteelGrey // slate-500 equivalent vs SteelGrey

        Column(modifier = Modifier.padding(20.dp)) {
            // Badges & Tag Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = SmartRailIcons.Train,
                        contentDescription = null,
                        tint = subTextColor,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = (journey.legs.firstOrNull()?.carrier ?: "Avanti West Coast").uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = subTextColor,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                if (isSplit) {
                    Box(
                        modifier = Modifier
                            .background(RailOrange, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "OPTIMAL SPLIT",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                    }
                } else if (isAlt) {
                    Box(
                        modifier = Modifier
                            .background(RailYellow.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .border(BorderStroke(1.dp, RailYellow), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "ALTERNATIVE ROUTE",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = RailYellow,
                            letterSpacing = 0.5.sp
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .background(subTextColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "STANDARD DIRECT",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = contentColor,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // From / To layout mimicking the geometric balance style
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = journey.departureTime,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = journey.origin,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = subTextColor
                    )
                }

                // Geometric intermediate line showing transition balance
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = journey.durationText,
                        fontSize = 11.sp,
                        color = contentColor,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .height(2.dp)
                            .background(subTextColor.copy(alpha = 0.3f))
                    ) {
                        if (journey.changes > 0) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(RailOrange, RoundedCornerShape(2.dp)) // Square indicator for split in geometric balance
                                    .align(Alignment.Center)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(StationGreen, RoundedCornerShape(50)) // Circle indicator for direct
                                    .align(Alignment.Center)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (journey.changes == 0) "Direct Run" else "${journey.changes} Split Layout",
                        fontSize = 9.sp,
                        color = subTextColor,
                        fontWeight = FontWeight.Medium
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = journey.arrivalTime,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = journey.destination,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = subTextColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Split constituents if split
            if (isSplit) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, Color(0xFFE2E8F0)), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("LEG 1", fontSize = 8.sp, color = RailOrange, fontWeight = FontWeight.Bold)
                            Text("${journey.origin} ➔ CRE", fontSize = 11.sp, color = RailNavy, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, Color(0xFFE2E8F0)), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("LEG 2", fontSize = 8.sp, color = RailOrange, fontWeight = FontWeight.Bold)
                            Text("CRE ➔ ${journey.destination}", fontSize = 11.sp, color = RailNavy, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // Savings summary card
            if (journey.fareCombination.savings > 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .background(
                            if (isSplit) RailOrange.copy(alpha = 0.08f) else StationGreen.copy(alpha = 0.1f),
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            BorderStroke(
                                1.dp,
                                if (isSplit) RailOrange.copy(alpha = 0.2f) else StationGreen.copy(alpha = 0.2f)
                            ),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Success",
                            tint = if (isSplit) RailOrange else StationGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SAVE £${String.format("%.2f", journey.fareCombination.savings)} compared to standard direct fares",
                            fontSize = 11.sp,
                            color = if (isSplit) RailOrange else StationGreen,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Advice / guidance text
            if (journey.fareCombination.adviceText.isNotEmpty()) {
                Text(
                    text = journey.fareCombination.adviceText,
                    fontSize = 11.sp,
                    color = subTextColor,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(vertical = 4.dp, horizontal = 2.dp)
                )
            }

            Divider(
                color = subTextColor.copy(alpha = 0.15f),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // Pricing details & action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    if (journey.fareCombination.savings > 0) {
                        Text(
                            text = "Standard £${String.format("%.2f", journey.fareCombination.standardPrice)}",
                            fontSize = 11.sp,
                            color = subTextColor,
                            textDecoration = TextDecoration.LineThrough
                        )
                    }
                    Text(
                        text = "£${String.format("%.2f", journey.fareCombination.totalPrice)}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isSplit) RailOrange else StationLedAmber,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = onBookClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSplit) RailNavy else RailOrange
                    ),
                    modifier = Modifier.testTag("book_button_${journey.id}")
                ) {
                    Text(
                        text = if (isSplit) "OPTIMAL BOOK" else "SELECT FARE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
        }
    }
}
