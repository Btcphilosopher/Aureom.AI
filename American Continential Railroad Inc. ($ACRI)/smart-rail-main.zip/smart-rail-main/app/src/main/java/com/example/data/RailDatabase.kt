package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.SavedRoute
import com.example.model.Ticket

@Database(entities = [Ticket::class, SavedRoute::class], version = 1, exportSchema = false)
abstract class RailDatabase : RoomDatabase() {
    abstract fun railDao(): RailDao

    companion object {
        @Volatile
        private var INSTANCE: RailDatabase? = null

        fun getDatabase(context: Context): RailDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RailDatabase::class.java,
                    "smart_rail_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
