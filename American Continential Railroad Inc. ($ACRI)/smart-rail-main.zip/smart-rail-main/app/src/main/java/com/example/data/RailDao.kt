package com.example.data

import androidx.room.*
import com.example.model.SavedRoute
import com.example.model.Ticket
import kotlinx.coroutines.flow.Flow

@Dao
interface RailDao {
    // Tickets
    @Query("SELECT * FROM digital_tickets ORDER BY date DESC, departureTime DESC")
    fun getAllTickets(): Flow<List<Ticket>>

    @Query("SELECT * FROM digital_tickets WHERE ticketId = :id LIMIT 1")
    suspend fun getTicketById(id: String): Ticket?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: Ticket)

    @Update
    suspend fun updateTicket(ticket: Ticket)

    @Query("DELETE FROM digital_tickets WHERE ticketId = :id")
    suspend fun deleteTicketById(id: String)

    // Saved Routes
    @Query("SELECT * FROM saved_routes")
    fun getSavedRoutes(): Flow<List<SavedRoute>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedRoute(route: SavedRoute)

    @Delete
    suspend fun deleteSavedRoute(route: SavedRoute)
    
    @Query("DELETE FROM saved_routes WHERE originCode = :origin AND destinationCode = :destination")
    suspend fun deleteSavedRouteByCodes(origin: String, destination: String)
}
