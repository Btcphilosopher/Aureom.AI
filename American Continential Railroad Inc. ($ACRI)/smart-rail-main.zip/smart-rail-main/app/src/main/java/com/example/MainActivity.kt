package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SmartRailIcons
import com.example.ui.screens.CommuteAnalyticsScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.TrackerScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RailNavy
import com.example.ui.theme.RailOrange
import com.example.ui.theme.SteelGrey
import com.example.viewmodel.RailViewModel
import com.example.viewmodel.RailViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: RailViewModel = viewModel(
                    factory = RailViewModelFactory(application)
                )
                
                MainNavigationScaffold(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainNavigationScaffold(viewModel: RailViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val notification by viewModel.notification.collectAsState()
    val context = LocalContext.current

    // Trigger Android-native Toasters for operational actions in real time
    LaunchedEffect(notification) {
        notification?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearNotification()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("app_main_scaffold"),
        contentWindowInsets = WindowInsets.safeDrawing, // Perfect notch edge-to-edge support
        bottomBar = {
            NavigationBar(
                containerColor = RailNavy,
                contentColor = Color.White,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Fares Search") },
                    label = { Text("Search", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color.White,
                        unselectedIconColor = SteelGrey,
                        unselectedTextColor = SteelGrey,
                        indicatorColor = RailOrange
                    ),
                    modifier = Modifier.testTag("nav_search_tab")
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(SmartRailIcons.Train, contentDescription = "Live Tracker") },
                    label = { Text("Tracker", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color.White,
                        unselectedIconColor = SteelGrey,
                        unselectedTextColor = SteelGrey,
                        indicatorColor = RailOrange
                    ),
                    modifier = Modifier.testTag("nav_tracker_tab")
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(SmartRailIcons.Wallet, contentDescription = "eTicket Wallet") },
                    label = { Text("Wallet", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color.White,
                        unselectedIconColor = SteelGrey,
                        unselectedTextColor = SteelGrey,
                        indicatorColor = RailOrange
                    ),
                    modifier = Modifier.testTag("nav_wallet_tab")
                )

                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(SmartRailIcons.Analytics, contentDescription = "Analytics Hub") },
                    label = { Text("Commute", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color.White,
                        unselectedIconColor = SteelGrey,
                        unselectedTextColor = SteelGrey,
                        indicatorColor = RailOrange
                    ),
                    modifier = Modifier.testTag("nav_commute_tab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen router
            when (selectedTab) {
                0 -> SearchScreen(
                    viewModel = viewModel,
                    onBooked = { selectedTab = 2 } // Automatically navigate to wallet on fare purchase
                )
                1 -> TrackerScreen(
                    viewModel = viewModel
                )
                2 -> WalletScreen(
                    viewModel = viewModel,
                    onNavigateToTracker = { selectedTab = 1 } // Jump to live operations GPX tracker mapping
                )
                3 -> CommuteAnalyticsScreen(
                    viewModel = viewModel,
                    onNavigateToWallet = { selectedTab = 2 } // Jump to wallet on quick booking
                )
            }
        }
    }
}
