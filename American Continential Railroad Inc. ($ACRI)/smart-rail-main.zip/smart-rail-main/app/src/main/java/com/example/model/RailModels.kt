package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

// Domain Data Models

data class Station(
    val code: String, // CRS code (e.g., EUS, MAN, BHM)
    val name: String,
    val facilities: List<String>,
    val accessibility: String,
    val foodCoffee: List<String>,
    val crowdLevel: String, // "Low", "Moderate", "High"
    val parkingInfo: String,
    val transitConnections: List<String>,
    val occupancyHeatmap: List<Int> // 24 values representing hourly occupancy percent
) {
    companion object {
        val PRESETS = listOf(
            Station(
                "EUS", "London Euston",
                listOf("Waiting Rooms", "Toilets", "Showers", "Wi-Fi"),
                "Step-free access to all platforms",
                listOf("Pret A Manger", "Starbucks", "Leon", "Wetherspoon"),
                "High", "Chargeable multi-storey",
                listOf("London Underground (Victoria, Northern)", "London Overground", "Buses"),
                listOf(10, 15, 20, 35, 60, 85, 95, 90, 75, 70, 75, 80, 85, 90, 95, 95, 85, 65, 45, 30, 20, 15, 10, 5)
            ),
            Station(
                "MAN", "Manchester Piccadilly",
                listOf("First Class Lounge", "Waiting Rooms", "Toilets", "Wi-Fi"),
                "Step-free access, lifts to all platforms",
                listOf("Costa Coffee", "Archie's", "Sainsbury's Local", "The Peveril of the Peak"),
                "Moderate", "Long-term car park available",
                listOf("Metrolink (Trams)", "Local Buses", "Taxi Rank"),
                listOf(5, 10, 15, 30, 50, 75, 85, 80, 65, 60, 65, 70, 75, 80, 85, 80, 70, 55, 35, 25, 15, 10, 5, 2)
            ),
            Station(
                "BHM", "Birmingham New Street",
                listOf("Waiting Rooms", "Toilets", "Luggage Storage", "Wi-Fi"),
                "Full step-free access, tactile paving",
                listOf("Leon", "Wasabi", " Starbucks", "Five Guys"),
                "High", "Grand Central parking",
                listOf("West Midlands Metro", "CrossCountry", "Buses"),
                listOf(8, 12, 18, 30, 55, 80, 90, 85, 70, 65, 70, 75, 80, 88, 92, 88, 78, 60, 40, 28, 18, 12, 8, 4)
            ),
            Station(
                "CRE", "Crewe",
                listOf("Waiting Area", "Toilets", "Refreshments"),
                "Accessible by ramps/lifts to all main platforms",
                listOf("Pumpkin Cafe", "WHSmith"),
                "Low", "Station side parking",
                listOf("Local Buses", "Avanti West Coast connections"),
                listOf(2, 5, 10, 18, 35, 55, 65, 60, 50, 48, 50, 52, 55, 58, 62, 58, 48, 35, 25, 15, 10, 8, 4, 1)
            ),
            Station(
                "YRK", "York",
                listOf("First Class Lounge", "Waiting Rooms", "Left Luggage", "Toilets"),
                "Full step-free access to all platforms via subway lifts",
                listOf("Costa Coffee", "Pasty Shop", "The York Tap"),
                "Moderate", "Adjacent multi-storey park",
                listOf("Local Buses", "LNER rail connections"),
                listOf(3, 8, 12, 25, 45, 65, 75, 72, 60, 58, 62, 68, 72, 75, 80, 75, 65, 50, 35, 22, 12, 8, 5, 2)
            ),
            Station(
                "EDI", "Edinburgh Waverley",
                listOf("First Class Lounge", "Waiting Rooms", "Toilets", "Showers"),
                "Lifts and ramps available from street level",
                listOf("Pret A Manger", "Costa", "The Waverley pub"),
                "High", "Waverley Station Car Park",
                listOf("Edinburgh Trams", "Airlink Bus", "Local Buses"),
                listOf(4, 9, 14, 28, 48, 70, 80, 78, 68, 65, 68, 74, 78, 82, 85, 82, 72, 55, 38, 26, 16, 11, 6, 3)
            )
        )

        fun findByCode(code: String): Station {
            return PRESETS.firstOrNull { it.code.uppercase() == code.uppercase() }
                ?: Station(
                    code, "$code Station",
                    listOf("Waiting Rooms", "Toilets", "Wi-Fi"),
                    "Standard access rules apply",
                    listOf("Station Cafe"),
                    "Moderate", "Standard parking",
                    listOf("Local Buses"),
                    listOf(5, 10, 15, 25, 40, 60, 70, 68, 55, 52, 55, 58, 60, 62, 65, 62, 55, 42, 28, 18, 10, 8, 5, 2)
                )
        }
    }
}

data class JourneyLeg(
    val origin: String,
    val destination: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationText: String,
    val carrier: String,
    val platform: String?,
    val trainNo: String
)

data class FareCombination(
    val type: String, // "Standard", "SplitTicket", "AlternativeRoute"
    val description: String, // e.g. "Save £42 via Split: EUS -> CRE -> MAN"
    val totalPrice: Double,
    val standardPrice: Double,
    val savings: Double,
    val splitPoints: List<String> = emptyList(),
    val adviceText: String = ""
)

data class Journey(
    val id: String,
    val origin: String, // Code
    val destination: String, // Code
    val departureDate: String, // YYYY-MM-DD
    val departureTime: String, // HH:MM
    val arrivalTime: String, // HH:MM
    val durationText: String,
    val changes: Int,
    val fareCombination: FareCombination,
    val legs: List<JourneyLeg>,
    val isDelayed: Boolean = false,
    val delayMinutes: Int = 0,
    val disruptionAlert: String? = null
)

@Entity(tableName = "digital_tickets")
data class Ticket(
    @PrimaryKey val ticketId: String,
    val journeyId: String,
    val origin: String,
    val originName: String,
    val destination: String,
    val destinationName: String,
    val date: String,
    val departureTime: String,
    val arrivalTime: String,
    val seatReservation: String, // e.g. "Coach B, Seat 42"
    val ticketClass: String, // "Standard Class", "First Class"
    val ticketType: String, // "Advance Single", "Off-Peak Return", "Split Ticket Combo"
    val railcardUsed: String?, // "16-25 Railcard", etc.
    val pricePaid: Double,
    val qrCodePayload: String, // Special digital standard barcode string
    val boughtAt: Long = System.currentTimeMillis(),
    val legBreakdowns: String, // Saved as quick JSON or simple format
    val status: String = "ACTIVE" // "ACTIVE", "USED", "REFUNDED", "DELAY_REPAID"
)

@Entity(tableName = "saved_routes")
data class SavedRoute(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originCode: String,
    val destinationCode: String,
    val frequency: String = "Daily Commute",
    val favoriteDepartureTime: String = "08:00"
)
