package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Palette
val RailNavy = Color(0xFF0B162C)        // Deep space base background (#0B162C)
val RailOrange = Color(0xFFFF671F)      // Vibrant transport orange accent (#FF671F)
val SteelGrey = Color(0xFF8E9299)       // Secondary steel grey (#8E9299)
val StationAmethyst = Color(0xFF162235)  // Cool dark navy slate card background (#162235)
val StationLedAmber = Color(0xFFFF9E00)  // Glowing amber
val StationGreen = Color(0xFF4ADE80)     // Vibrant success green (Tailwind green-400 equivalent)
val StationRed = Color(0xFFEF4444)       // Vibrant delay red (Tailwind red-500 equivalent)

// Dark Theme Colors / Surfaces matching Geometric Balance
val DarkBackground = Color(0xFF0B162C)
val DarkSurface = Color(0xFF1E293B)      // Dark slate card surface (#1E293B)
val OnDarkSurface = Color(0xFFFFFFFF)    // Crisp white text
val LightAccentBlue = Color(0xFF38BDF8)  // Bright sky blue
val RailYellow = Color(0xFFFBBF24)       // Warm yellow amber
