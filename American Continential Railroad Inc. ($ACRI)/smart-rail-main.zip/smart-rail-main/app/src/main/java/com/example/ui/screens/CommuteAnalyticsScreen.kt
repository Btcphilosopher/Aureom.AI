package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SavedRoute
import com.example.model.Station
import com.example.model.Journey
import com.example.ui.components.SmartRailIcons
import com.example.ui.theme.*
import com.example.viewmodel.RailViewModel

@Composable
fun CommuteAnalyticsScreen(
    viewModel: RailViewModel,
    onNavigateToWallet: () -> Unit,
    modifier: Modifier = Modifier
) {
    val savedRoutes by viewModel.savedRoutes.collectAsState()
    val totalSaved by viewModel.totalPoundsSaved.collectAsState()
    val completedCount by viewModel.completedJourneysCount.collectAsState()
    val carbonReduced by viewModel.carbonReducedKg.collectAsState()
    val score by viewModel.commuterScore.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Dashboard Title
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column {
                    Text(
                        text = "EFFICIENCY OPERATIONS CONTROL",
                        fontSize = 10.sp,
                        color = SteelGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Analytics Control",
                        fontSize = 22.sp,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Geometric Balance badge (circle + square)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(DarkSurface, shape = RoundedCornerShape(20.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.10f), shape = RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .border(2.dp, Color.White.copy(alpha = 0.40f), shape = RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        // Gamified Metrics Cards Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Total saved
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = StationGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "TOTAL SAVED",
                            fontSize = 10.sp,
                            color = SteelGrey,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "£${String.format("%.2f", totalSaved)}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = StationGreen,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.testTag("total_saved_text")
                        )
                        Text(text = "vs. Standard Fares", fontSize = 9.sp, color = SteelGrey)
                    }
                }

                // Carbon reduction
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFF00FF88), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "CO2 REDUCED",
                            fontSize = 10.sp,
                            color = SteelGrey,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${String.format("%.1f", carbonReduced)} kg",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF00FF88),
                            fontFamily = FontFamily.Monospace
                        )
                        Text(text = "Environmental offset", fontSize = 9.sp, color = SteelGrey)
                    }
                }
            }
        }

        // Commuter Score Dashboard and journeys count
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Radial Score Canvas
                    Box(
                        modifier = Modifier
                            .size(80.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        ScoreRadialCanvas(score = score)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$score",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = StationLedAmber,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(text = "INDEX", fontSize = 7.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "PASSENGER SAVINGS RATING",
                            style = MaterialTheme.typography.labelSmall,
                            color = SteelGrey,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Level 9 Commuter Expert",
                            fontSize = 14.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "You are in the top 2% of UK rail savers on Avanti West Coast and TransPennine sectors. Completed $completedCount journeys successfully.",
                            fontSize = 10.sp,
                            color = SteelGrey,
                            lineHeight = 13.sp
                        )
                    }
                }
            }
        }

        // 2. SAVED COMMUTER ROUTES SHORTCUTS
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ONE-TAP INSTANT booking SECTORS",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelGrey,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Icon(
                    imageVector = SmartRailIcons.Route,
                    contentDescription = null,
                    tint = SteelGrey,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        if (savedRoutes.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AddCircle, contentDescription = null, tint = SteelGrey, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("No bookmark shortcuts established yet.", color = SteelGrey, fontSize = 11.sp)
                        }
                    }
                }
            }
        } else {
            items(savedRoutes) { route ->
                SavedRouteCommuteItem(
                    route = route,
                    onInstantBook = {
                        // Quick automatic purchase: searching standard splits, picking cheapest and adding instantly to database Wallet.
                        val oName = Station.findByCode(route.originCode).name
                        val dName = Station.findByCode(route.destinationCode).name

                        val splitJourney = Journey(
                            id = "SPLIT_QUICK_${route.originCode}_${route.destinationCode}_${System.currentTimeMillis()}",
                            origin = route.originCode,
                            destination = route.destinationCode,
                            departureDate = "2026-05-28",
                            departureTime = route.favoriteDepartureTime,
                            arrivalTime = "10:15",
                            durationText = "2h 15m",
                            changes = 1,
                            legs = emptyList(),
                            fareCombination = com.example.model.FareCombination(
                                type = "SplitTicket",
                                description = "Fast booking split",
                                totalPrice = 24.50,
                                standardPrice = 48.00,
                                savings = 23.50
                            )
                        )

                        viewModel.bookJourney(splitJourney)
                        onNavigateToWallet()
                    },
                    onRemove = {
                        viewModel.removeCommutedRoute(route.originCode, route.destinationCode)
                    }
                )
            }
        }
    }
}

@Composable
fun SavedRouteCommuteItem(
    route: SavedRoute,
    onInstantBook: () -> Unit,
    onRemove: () -> Unit
) {
    val oName = Station.findByCode(route.originCode).name
    val dName = Station.findByCode(route.destinationCode).name

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("saved_route_item_${route.originCode}_${route.destinationCode}"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${route.originCode} ➔ ${route.destinationCode}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(RailNavy, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = route.frequency.uppercase(),
                                fontSize = 8.sp,
                                color = RailOrange,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "$oName to $dName",
                        fontSize = 11.sp,
                        color = SteelGrey
                    )
                }

                IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Route", tint = StationRed.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = SteelGrey.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = SteelGrey, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Preferred Run: ${route.favoriteDepartureTime}",
                        fontSize = 11.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }

                Button(
                    onClick = onInstantBook,
                    colors = ButtonDefaults.buttonColors(containerColor = RailOrange),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("one_tap_book_button_${route.originCode}_${route.destinationCode}")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("One-Tap Book", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

// Draw a beautiful custom segmented meter on Canvas
@Composable
fun ScoreRadialCanvas(score: Int) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val diameter = minOf(width, height) - 10f
        val radius = diameter / 2f
        val center = Offset(width / 2f, height / 2f)

        // Backdrop grey circle arc
        drawArc(
            color = SteelGrey.copy(alpha = 0.2f),
            startAngle = 135f,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(diameter, diameter),
            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
        )

        // Color sweep mapping progress
        val fillSweep = (score / 100f) * 270f
        drawArc(
            color = RailOrange,
            startAngle = 135f,
            sweepAngle = fillSweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(diameter, diameter),
            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}
