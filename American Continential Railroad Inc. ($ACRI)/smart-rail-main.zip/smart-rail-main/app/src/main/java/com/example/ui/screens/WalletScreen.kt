package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Ticket
import com.example.ui.components.SmartRailIcons
import com.example.ui.theme.*
import com.example.viewmodel.RailViewModel

@Composable
fun WalletScreen(
    viewModel: RailViewModel,
    onNavigateToTracker: () -> Unit,
    modifier: Modifier = Modifier
) {
    val savedTickets by viewModel.savedTickets.collectAsState()
    val activeTrackingJourney by viewModel.activeTrackingJourney.collectAsState()

    var selectedTicketId by remember { mutableStateOf<String?>(null) }
    
    // Choose selected ticket or fallback to first active
    val displayedTicketId = selectedTicketId ?: savedTickets.firstOrNull { it.status == "ACTIVE" }?.ticketId

    val displayedTicket = savedTickets.firstOrNull { it.ticketId == displayedTicketId }
    val activeTickets = savedTickets.filter { it.status == "ACTIVE" }
    val historicalTickets = savedTickets.filter { it.status != "ACTIVE" }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Module Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column {
                    Text(
                        text = "SECURE DIGITAL WALLET",
                        fontSize = 10.sp,
                        color = SteelGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Ticket Wallet",
                        fontSize = 22.sp,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Geometric Balance badge (circle + square)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(DarkSurface, shape = RoundedCornerShape(20.dp))
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)), shape = RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .border(BorderStroke(2.dp, Color.White.copy(alpha = 0.40f)), shape = RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        // Main eTicket Detail Component
        if (displayedTicket == null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = SmartRailIcons.Wallet,
                            contentDescription = null,
                            tint = SteelGrey.copy(alpha = 0.4f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No eTickets acquired yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Purchased split pairings appear here immediately for offline gates scanning, carriage management, and disruption insurance triggers.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SteelGrey,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        } else {
            // Display active physical looking ticket card
            item {
                ActiveETicketCanvasCard(
                    ticket = displayedTicket,
                    isCurrentlyTracking = activeTrackingJourney?.id == displayedTicket.journeyId,
                    onStartTracking = {
                        // Extract mock journey matching this ticket
                        val fauxJourney = viewModel.searchResults.value.firstOrNull { it.id == displayedTicket.journeyId }
                            ?: com.example.model.Journey(
                                id = displayedTicket.journeyId,
                                origin = displayedTicket.origin,
                                destination = displayedTicket.destination,
                                departureDate = displayedTicket.date,
                                departureTime = displayedTicket.departureTime,
                                arrivalTime = displayedTicket.arrivalTime,
                                durationText = "2h 06m",
                                changes = if (displayedTicket.ticketType.contains("Split")) 1 else 0,
                                isDelayed = activeTrackingJourney?.isDelayed ?: false, // sync delay if simulated
                                delayMinutes = activeTrackingJourney?.delayMinutes ?: 0,
                                disruptionAlert = activeTrackingJourney?.disruptionAlert,
                                fareCombination = com.example.model.FareCombination(
                                    type = "Split",
                                    description = "Faux split",
                                    totalPrice = displayedTicket.pricePaid,
                                    standardPrice = displayedTicket.pricePaid * 1.5,
                                    savings = displayedTicket.pricePaid * 0.5
                                ),
                                legs = listOf(
                                    com.example.model.JourneyLeg(
                                        origin = displayedTicket.origin,
                                        destination = if (displayedTicket.ticketType.contains("Split")) "CRE" else displayedTicket.destination,
                                        departureTime = displayedTicket.departureTime,
                                        arrivalTime = displayedTicket.arrivalTime,
                                        durationText = "95m",
                                        carrier = "Avanti West Coast",
                                        platform = "Platform 12",
                                        trainNo = "9S12"
                                    )
                                )
                            )
                        viewModel.startTrackingJourney(fauxJourney)
                        onNavigateToTracker()
                    },
                    onClaimRefund = {
                        viewModel.triggerRefundOrClaim(displayedTicket.ticketId, "Repay claim triggered")
                    }
                )
            }
        }

        // Active offline list tab selection slider
        if (activeTickets.isNotEmpty() && activeTickets.size > 1) {
            item {
                Text(
                    text = "ACTIVE PASS DECK (${activeTickets.size})",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelGrey,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    activeTickets.forEach { t ->
                        val selected = t.ticketId == displayedTicketId
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) RailOrange else DarkSurface
                            ),
                            modifier = Modifier
                                .clickable { selectedTicketId = t.ticketId }
                                .weight(1f)
                                .testTag("deck_ticket_${t.ticketId}"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${t.origin} ➔ ${t.destination}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = t.ticketId,
                                    fontSize = 9.sp,
                                    color = if (selected) Color.White.copy(alpha = 0.7f) else SteelGrey,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. ARCHIVED / REFUNDED HISTORIAL TICKETS
        if (historicalTickets.isNotEmpty()) {
            item {
                Text(
                    text = "ARCHIVED TRANSIT HISTORY (" + historicalTickets.size + ")",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelGrey,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }

            items(historicalTickets) { t ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedTicketId = t.ticketId }
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${t.originName} to ${t.destinationName}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "${t.date} · ${t.ticketType} · Paid £${String.format("%.2f", t.pricePaid)}",
                                fontSize = 10.sp,
                                color = SteelGrey
                            )
                        }

                        val badgeColor = when (t.status) {
                            "USED" -> SteelGrey.copy(alpha = 0.3f)
                            "DELAY_REPAID" -> RailOrange.copy(alpha = 0.3f)
                            else -> StationRed.copy(alpha = 0.3f)
                        }
                        val labelColor = when (t.status) {
                            "USED" -> Color.White
                            "DELAY_REPAID" -> RailOrange
                            else -> StationRed
                        }

                        Box(
                            modifier = Modifier
                                .background(badgeColor, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = t.status.replace("_", " "),
                                color = labelColor,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveETicketCanvasCard(
    ticket: Ticket,
    isCurrentlyTracking: Boolean,
    onStartTracking: () -> Unit,
    onClaimRefund: () -> Unit
) {
    // Check if synced simulation is marking this journey delayed
    val isDelayed = ticket.status == "ACTIVE" && isCurrentlyTracking

    Card(
        colors = CardDefaults.cardColors(containerColor = StationAmethyst),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("eticket_canvas_card")
    ) {
        Column {
            // Orange Ticket Header Visual (standard British ticket styling)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp)
                    .background(RailOrange)
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = SmartRailIcons.NationalRail,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "UK RAIL DIGITAL ETICKET",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 1.5.sp
                        )
                    }

                    Badge(containerColor = Color.Black.copy(alpha = 0.4f), contentColor = Color.White) {
                        Text(
                            text = ticket.ticketId,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                    }
                }
            }

            // Ticket Body information
            Column(modifier = Modifier.padding(14.dp)) {
                // Route CRS Codes Huge display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = ticket.origin,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = ticket.originName,
                            fontSize = 11.sp,
                            color = SteelGrey,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Forwarding",
                        tint = RailOrange,
                        modifier = Modifier.size(28.dp)
                    )

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = ticket.destination,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = ticket.destinationName,
                            fontSize = 11.sp,
                            color = SteelGrey,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Metadata Rows
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("DATE OF RUN", fontSize = 9.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                        Text(ticket.date, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("DEPARTURE TIME", fontSize = 9.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                        Text(ticket.departureTime, fontSize = 12.sp, color = StationLedAmber, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("CLASS & VEHICLE", fontSize = 9.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                        Text("${ticket.ticketClass}", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("SEAT RESERVATION", fontSize = 9.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                        Text(ticket.seatReservation, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("FARE MODEL TYPE", fontSize = 9.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                        Text(ticket.ticketType.uppercase(), fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("PRICE PAID", fontSize = 9.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                        Text("£${String.format("%.2f", ticket.pricePaid)}", fontSize = 12.sp, color = StationLedAmber, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                // If split ticket, draw segment boundary warnings
                if (ticket.legBreakdowns.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("SPLIT TICKET CONSTITUENTS:", fontSize = 9.sp, color = RailOrange, fontWeight = FontWeight.Bold)
                            Text(
                                text = ticket.legBreakdowns,
                                fontSize = 10.sp,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 13.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Glow visual interactive QR scanner layout centered on canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp)
                        .background(Color.Black, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Custom Canvas high fidelity vector barcode scanner grid representation
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .background(Color.White, RoundedCornerShape(4.dp))
                                .padding(6.dp)
                        ) {
                            MockQRBarcodeCanvas(payload = ticket.qrCodePayload)
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Pulsing glowing dot
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .background(StationGreen, RoundedCornerShape(50))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "NFC ACTIVE · HOLD TO GATE TERMINAL",
                                color = SteelGrey,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                // Active telemetry launch row (connecting to GPS movement operations)
                Spacer(modifier = Modifier.height(12.dp))
                if (!isCurrentlyTracking && ticket.status == "ACTIVE") {
                    Button(
                        onClick = onStartTracking,
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RailNavy),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("stream_telemetry_button")
                    ) {
                        Icon(Icons.Default.Place, contentDescription = null, tint = RailOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Stream Telemetry GPS Link", fontWeight = FontWeight.Bold)
                    }
                } else if (isCurrentlyTracking && ticket.status == "ACTIVE") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "🛰️ TELEMETRY ACTIVE ON TRACKER TAB",
                            color = RailOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(6.dp)
                        )
                    }
                }

                // 🚨 AUTOMATED COMPENSATION ENGINE DELAY REPAY OVERLAYS
                if (isDelayed) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = StationRed.copy(alpha = 0.18f)),
                        border = BorderStroke(1.dp, StationRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = StationRed)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "DISRUPTION IDENTIFIED: DELAYED (+45M)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StationRed
                                )
                            }
                            Text(
                                text = "This Avanti West Coast direct segment is eligible for full 100% automatic Delay Repay refund under UK rail passengers' charters.",
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.9f),
                                lineHeight = 13.sp,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                            
                            Button(
                                onClick = onClaimRefund,
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StationRed),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                                    .height(34.dp)
                                    .testTag("delay_repay_claim_button")
                            ) {
                                Text("SUBMIT INSTANT REPAY CLAIM", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Custom Grid QR Generator on Canvas (creates gorgeous high fidelity eTicket effect)
@Composable
fun MockQRBarcodeCanvas(payload: String) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val totalSize = size.width
        val blockCount = 14
        val blockSize = totalSize / blockCount
        
        // Use deterministic hashing based on barcode payload string
        val seed = payload.hashCode().toLong()
        val random = java.util.Random(seed)

        // Draw outer borders
        val strokeW = 2.dp.toPx()
        // Top Left
        drawRect(Color.Black, Offset(0f, 0f), Size(blockSize * 4f, blockSize * 4f))
        drawRect(Color.White, Offset(blockSize, blockSize), Size(blockSize * 2f, blockSize * 2f))
        drawRect(Color.Black, Offset(blockSize * 1.5f, blockSize * 1.5f), Size(blockSize, blockSize))

        // Top Right
        drawRect(Color.Black, Offset(blockSize * (blockCount - 4f), 0f), Size(blockSize * 4f, blockSize * 4f))
        drawRect(Color.White, Offset(blockSize * (blockCount - 3f), blockSize), Size(blockSize * 2f, blockSize * 2f))
        drawRect(Color.Black, Offset(blockSize * (blockCount - 2.5f), blockSize * 1.5f), Size(blockSize, blockSize))

        // Bottom Left
        drawRect(Color.Black, Offset(0f, blockSize * (blockCount - 4f)), Size(blockSize * 4f, blockSize * 4f))
        drawRect(Color.White, Offset(blockSize, blockSize * (blockCount - 3f)), Size(blockSize * 2f, blockSize * 2f))
        drawRect(Color.Black, Offset(blockSize * 1.5f, blockSize * (blockCount - 2.5f)), Size(blockSize, blockSize))

        // Draw scatter dots
        for (row in 0 until blockCount) {
            for (col in 0 until blockCount) {
                // Avoid overlap with boundary corners
                val isCorner = (row < 4 && col < 4) || (row < 4 && col >= blockCount - 4) || (row >= blockCount - 4 && col < 4)
                if (!isCorner) {
                    if (random.nextBoolean()) {
                        drawRect(
                            color = Color.Black,
                            topLeft = Offset(col * blockSize, row * blockSize),
                            size = Size(blockSize, blockSize)
                        )
                    }
                }
            }
        }
    }
}
