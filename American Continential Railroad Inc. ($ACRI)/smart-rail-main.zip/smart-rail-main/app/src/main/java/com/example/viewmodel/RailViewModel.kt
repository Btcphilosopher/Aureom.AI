package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.RailDatabase
import com.example.data.RailRepository
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class RailViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RailRepository
    
    // --- UI/Engine States ---
    private val _searchResults = MutableStateFlow<List<Journey>>(emptyList())
    val searchResults: StateFlow<List<Journey>> = _searchResults.asStateFlow()

    private val _savedTickets = MutableStateFlow<List<Ticket>>(emptyList())
    val savedTickets: StateFlow<List<Ticket>> = _savedTickets.asStateFlow()

    private val _savedRoutes = MutableStateFlow<List<SavedRoute>>(emptyList())
    val savedRoutes: StateFlow<List<SavedRoute>> = _savedRoutes.asStateFlow()

    private val _currentStationCode = MutableStateFlow("EUS")
    val currentStationCode: StateFlow<String> = _currentStationCode.asStateFlow()

    private val _liveDepartures = MutableStateFlow<List<Journey>>(emptyList())
    val liveDepartures: StateFlow<List<Journey>> = _liveDepartures.asStateFlow()

    // Active Tracking Segment
    private val _activeTrackingJourney = MutableStateFlow<Journey?>(null)
    val activeTrackingJourney: StateFlow<Journey?> = _activeTrackingJourney.asStateFlow()

    private val _trackingProgress = MutableStateFlow(0f) // 0.0 to 1.5 representing journey completion
    val trackingProgress: StateFlow<Float> = _trackingProgress.asStateFlow()

    private val _priceHistory = MutableStateFlow<List<Pair<String, Double>>>(emptyList())
    val priceHistory: StateFlow<List<Pair<String, Double>>> = _priceHistory.asStateFlow()

    // Input States
    val searchOrigin = MutableStateFlow("EUS")
    val searchDestination = MutableStateFlow("MAN")
    val searchDate = MutableStateFlow("2026-05-28")
    val searchTime = MutableStateFlow("08:00")
    val searchRailcard = MutableStateFlow("No Railcard")

    // Stats
    private val _totalPoundsSaved = MutableStateFlow(1243.60)
    val totalPoundsSaved: StateFlow<Double> = _totalPoundsSaved.asStateFlow()

    private val _completedJourneysCount = MutableStateFlow(42)
    val completedJourneysCount: StateFlow<Int> = _completedJourneysCount.asStateFlow()

    private val _carbonReducedKg = MutableStateFlow(248.5)
    val carbonReducedKg: StateFlow<Double> = _carbonReducedKg.asStateFlow()

    private val _commuterScore = MutableStateFlow(94)
    val commuterScore: StateFlow<Int> = _commuterScore.asStateFlow()

    // Notification helper
    private val _notification = MutableStateFlow<String?>(null)
    val notification: StateFlow<String?> = _notification.asStateFlow()

    private var trackingJob: Job? = null

    init {
        val database = RailDatabase.getDatabase(application)
        repository = RailRepository(database.railDao())

        // Load reactive flows from database
        viewModelScope.launch {
            repository.allTickets.collect { tickets ->
                _savedTickets.value = tickets
                // Calculate dynamic stats updates
                val spent = tickets.size * 25.0
                _completedJourneysCount.value = 42 + tickets.filter { it.status == "USED" }.size
            }
        }

        viewModelScope.launch {
            repository.savedRoutes.collect { routes ->
                _savedRoutes.value = routes
            }
        }

        // Default populate database to avoid cold starts for testers
        seedStarterData()
        
        // Trigger default search and departures
        executeFareSearch()
        loadLiveDepartures("EUS")
    }

    private fun seedStarterData() {
        viewModelScope.launch {
            // Seed a popular commuter route
            repository.saveRoute("EUS", "MAN", "Daily Commute", "08:00")
            repository.saveRoute("BHM", "CRE", "Weekly Client Visit", "09:12")

            // Seed an active digital ticket
            val demoTicketId = "SR-94119"
            val existing = repository.getTicketById(demoTicketId)
            if (existing == null) {
                repository.purchaseTicket(
                    Ticket(
                        ticketId = demoTicketId,
                        journeyId = "EUS_MAN_SPLIT_DEMO",
                        origin = "EUS",
                        originName = "London Euston",
                        destination = "MAN",
                        destinationName = "Manchester Piccadilly",
                        date = "2026-05-28",
                        departureTime = "08:15",
                        arrivalTime = "10:21",
                        seatReservation = "Coach C, Seat 14A",
                        ticketClass = "Standard Class",
                        ticketType = "Split Ticket",
                        railcardUsed = "16-25 Railcard",
                        pricePaid = 26.90,
                        qrCodePayload = "SMARTRAIL_UK_ETICKET_VERIFIED_SECURE_9A8F7642EUS_MAN",
                        status = "ACTIVE",
                        legBreakdowns = "EUS -> CRE (£18.20) + CRE -> MAN (£8.70)"
                    )
                )
            }
        }
    }

    // --- Search Core Operations ---

    fun executeFareSearch() {
        viewModelScope.launch {
            val results = repository.searchJourneys(
                origin = searchOrigin.value,
                destination = searchDestination.value,
                date = searchDate.value,
                time = searchTime.value,
                railcard = searchRailcard.value
            )
            _searchResults.value = results
            
            // Generate prediction list for this pair
            _priceHistory.value = repository.getPriceHistoryAndForecast(searchOrigin.value, searchDestination.value)
        }
    }

    fun reverseSearch() {
        val temp = searchOrigin.value
        searchOrigin.value = searchDestination.value
        searchDestination.value = temp
        executeFareSearch()
    }

    // --- Commuter Favorites ---

    fun saveCurrentSearchAsCommute() {
        viewModelScope.launch {
            repository.saveRoute(
                origin = searchOrigin.value,
                destination = searchDestination.value,
                frequency = "Commuter Fav",
                favTime = searchTime.value
            )
            postToast("Commute saved! Tap 'Usual Journey' anytime.")
        }
    }

    fun removeCommutedRoute(origin: String, dest: String) {
        viewModelScope.launch {
            repository.removeSavedRoute(origin, dest)
            postToast("Saved route removed.")
        }
    }

    // --- Wallet Core Operations ---

    fun bookJourney(journey: Journey) {
        viewModelScope.launch {
            val ticketId = "SR-${(10000..99999).random()}"
            val legsText = journey.legs.joinToString(" + ") { "${it.origin} -> ${it.destination}" }
            
            val ticket = Ticket(
                ticketId = ticketId,
                journeyId = journey.id,
                origin = journey.origin,
                originName = Station.findByCode(journey.origin).name,
                destination = journey.destination,
                destinationName = Station.findByCode(journey.destination).name,
                date = journey.departureDate,
                departureTime = journey.departureTime,
                arrivalTime = journey.arrivalTime,
                seatReservation = "Coach ${(listOf("A", "B", "C", "D", "E")).random()}, Seat ${(1..68).random()}",
                ticketClass = "Standard Class",
                ticketType = if (journey.changes > 0) "Split Ticket Combo" else "Advance Single",
                railcardUsed = if (searchRailcard.value == "No Railcard") null else searchRailcard.value,
                pricePaid = journey.fareCombination.totalPrice,
                qrCodePayload = "SMARTRAIL_UK_SECURE_${ticketId}_${journey.origin}_${journey.destination}_VERIFIED_GATE_NFC",
                legBreakdowns = legsText
            )

            repository.purchaseTicket(ticket)
            
            // Add to client-side analytics savings metrics
            _totalPoundsSaved.value += journey.fareCombination.savings
            _carbonReducedKg.value += (journey.legs.size * 5.8)
            _commuterScore.value = minOf(100, _commuterScore.value + 1)

            postToast("Ticket booked successfully! Saved to Wallet.")
        }
    }

    fun triggerRefundOrClaim(ticketId: String, reason: String) {
        viewModelScope.launch {
            val ticket = repository.getTicketById(ticketId)
            if (ticket != null) {
                val updated = ticket.copy(status = "DELAY_REPAID")
                repository.purchaseTicket(updated)
                // Add claim return
                _totalPoundsSaved.value += ticket.pricePaid // full payout representation
                postToast("Refund Approved! Delay Repay automatic claim generated £${String.format("%.2f", ticket.pricePaid)} credited.")
            }
        }
    }

    // --- Live Departures & Station Search ---

    fun loadLiveDepartures(stationCode: String) {
        _currentStationCode.value = stationCode.uppercase()
        viewModelScope.launch {
            _liveDepartures.value = repository.getLiveDepartures(stationCode)
        }
    }

    // --- Modern Live Journey GPS Progression Tracker Simulator ---

    fun startTrackingJourney(journey: Journey) {
        trackingJob?.cancel()
        _activeTrackingJourney.value = journey
        _trackingProgress.value = 0.0f
        
        trackingJob = viewModelScope.launch {
            postToast("Tracking activated. Live GPS link established.")
            // Simulate progression
            while (_trackingProgress.value < 1.0f) {
                delay(3500) // update speed
                _trackingProgress.value += 0.15f
            }
            _trackingProgress.value = 1.0f
            postToast("Journey completed. eTicket marked as USED.")
            // Automatically complete ticket if saved in local history Database
            markJourneyCompleted(journey.id)
        }
    }

    private suspend fun markJourneyCompleted(journeyId: String) {
        val tickets = _savedTickets.value
        val matches = tickets.firstOrNull { it.journeyId == journeyId && it.status == "ACTIVE" }
        if (matches != null) {
            val updated = matches.copy(status = "USED")
            repository.purchaseTicket(updated)
        }
    }

    fun stopTracking() {
        trackingJob?.cancel()
        _activeTrackingJourney.value = null
        _trackingProgress.value = 0.0f
    }

    fun simulateDisruption(journeyId: String) {
        viewModelScope.launch {
            val active = _activeTrackingJourney.value
            if (active != null && active.id == journeyId) {
                // Modify simulated route with an active emergency overhead block
                _activeTrackingJourney.value = active.copy(
                    isDelayed = true,
                    delayMinutes = 45,
                    disruptionAlert = "🚨 Delay: +45M. Overhead wire block near Milton Keynes. Instantly eligible for 100% Delay Repay compensation."
                )
                postToast("Telemetry alert: +45M delay registered. Refund claiming engine online!")
            }
        }
    }

    // Common toaster
    private fun postToast(msg: String) {
        _notification.value = msg
    }

    fun clearNotification() {
        _notification.value = null
    }
}

// ViewModel Factory boilerplate to avoid standard init failures
class RailViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RailViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return RailViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
