package com.example.data

import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

class RailRepository(private val railDao: RailDao) {

    // --- Database Operations ---

    val allTickets: Flow<List<Ticket>> = railDao.getAllTickets()
    val savedRoutes: Flow<List<SavedRoute>> = railDao.getSavedRoutes()

    suspend fun purchaseTicket(ticket: Ticket) {
        railDao.insertTicket(ticket)
    }

    suspend fun updateTicketStatus(ticket: Ticket) {
        railDao.updateTicket(ticket)
    }

    suspend fun getTicketById(id: String): Ticket? {
        return railDao.getTicketById(id)
    }

    suspend fun deleteTicket(id: String) {
        railDao.deleteTicketById(id)
    }

    suspend fun saveRoute(origin: String, destination: String, frequency: String, favTime: String) {
        railDao.insertSavedRoute(SavedRoute(
            originCode = origin.uppercase(),
            destinationCode = destination.uppercase(),
            frequency = frequency,
            favoriteDepartureTime = favTime
        ))
    }

    suspend fun removeSavedRoute(origin: String, destination: String) {
        railDao.deleteSavedRouteByCodes(origin.uppercase(), destination.uppercase())
    }


    // --- Price Prediction / Historical System Model ---

    fun getPriceHistoryAndForecast(origin: String, destination: String): List<Pair<String, Double>> {
        val basePrice = estimateBasePrice(origin, destination)
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -14)

        val historyAndForecast = mutableListOf<Pair<String, Double>>()
        val sdf = SimpleDateFormat("dd MMM", Locale.UK)

        // Historical - last 14 days
        for (i in 0..13) {
            val dateStr = sdf.format(calendar.time)
            // Use sin wave to make a beautiful, realistic fluctuation pattern
            val multiplier = 0.8 + 0.35 * abs(sin(i.toDouble() / 2.0))
            historyAndForecast.add(Pair(dateStr, basePrice * multiplier))
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }

        // Current price indicator mark
        val currentStr = "Today"
        historyAndForecast.add(Pair(currentStr, basePrice * 1.1)) // peak pricing today
        calendar.add(Calendar.DAY_OF_YEAR, 1)

        // Forecast - next 7 days (shows demand increases)
        for (i in 1..7) {
            val dateStr = sdf.format(calendar.time)
            val multiplier = 1.0 + (i * 0.12) + 0.1 * abs(sin(i.toDouble()))
            historyAndForecast.add(Pair(dateStr, basePrice * multiplier))
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }

        return historyAndForecast
    }

    // --- Live Departure Boards & Real-Time Tracking Simulator ---

    fun getLiveDepartures(stationCode: String): List<Journey> {
        val targets = Station.PRESETS.filter { it.code != stationCode }
        if (targets.isEmpty()) return emptyList()

        val sdf = SimpleDateFormat("HH:mm", Locale.UK)
        val now = Calendar.getInstance()

        return List(8) { i ->
            val dest = targets[i % targets.size]
            val minutesOffset = 5 + (i * 12)
            now.add(Calendar.MINUTE, minutesOffset)
            val depTime = sdf.format(now.time)

            now.add(Calendar.MINUTE, 45 + (i * 15))
            val arrTime = sdf.format(now.time)
            now.add(Calendar.MINUTE, -(45 + (i * 15))) // Reset offset

            val basePrice = estimateBasePrice(stationCode, dest.code)
            val isDelayed = i == 2 || i == 5
            val delayMins = if (isDelayed) (if (i == 2) 8 else 22) else 0

            createJourneyStructure(
                id = "${stationCode}_${dest.code}_DEP_$i",
                origin = stationCode,
                destination = dest.code,
                depTime = depTime,
                arrTime = arrTime,
                basePrice = basePrice,
                isDelayed = isDelayed,
                delayMins = delayMins,
                date = "2026-05-27"
            )
        }
    }


    // --- Advanced Split Ticket & Low-Fare Discovery Engine Algorithm ---

    fun searchJourneys(
        origin: String,
        destination: String,
        date: String,
        time: String,
        railcard: String? = null
    ): List<Journey> {
        val o = origin.uppercase()
        val d = destination.uppercase()
        val basePrice = estimateBasePrice(o, d)

        // Generate combinations side-by-side to allow easy direct savings comparison.
        val results = mutableListOf<Journey>()

        // 1. CHEAPEST LEGAL SPLIT BUILDER
        val splitPoints = findSplitPoints(o, d)
        val hasSplit = splitPoints.isNotEmpty()

        val splitCombination = if (hasSplit) {
            val splitPrice = basePrice * 0.58 // ~42% average split savings
            val savings = basePrice - splitPrice
            FareCombination(
                type = "SplitTicket",
                description = "Split tickets via ${splitPoints.joinToString(" & ") { CodeToName(it) }}",
                totalPrice = splitPrice,
                standardPrice = basePrice,
                savings = savings,
                splitPoints = splitPoints,
                adviceText = "No physical changes needed. You just sit in the same seat while ticket boundaries split!"
            )
        } else {
            FareCombination(
                type = "StandardSplit",
                description = "Standard ticketing fare for this route",
                totalPrice = basePrice * 0.95,
                standardPrice = basePrice,
                savings = basePrice * 0.05,
                adviceText = "No optimal split point found. Direct booking remains optimal."
            )
        }

        // Create cheapest path
        val splitDepCalendar = parseTime(time)
        val splitArrCalendar = splitDepCalendar.clone() as Calendar
        splitArrCalendar.add(Calendar.MINUTE, estimateMinutes(o, d))

        results.add(
            createJourneyStructure(
                id = "${o}_${d}_SPLIT_${date}_${time.replace(":", "")}",
                origin = o,
                destination = d,
                depTime = formatTime(splitDepCalendar),
                arrTime = formatTime(splitArrCalendar),
                basePrice = basePrice,
                customCombination = splitCombination,
                isDelayed = false,
                delayMins = 0,
                date = date
            )
        )

        // 2. ALTERNATIVE PEAK-AVOIDANCE / STATION SWAP RECOMMENDATION
        // Suggest leaving slightly different time (avoid peak)
        val peakDepTime = parseTime(time)
        peakDepTime.add(Calendar.MINUTE, 18) // Leave 18 mins later matches prompt

        val offPeakPrice = basePrice * 0.40 // 60% savings
        val offPeakCombination = FareCombination(
            type = "AlternativeRoute",
            description = "Avoid peak: Leave 18 mins later",
            totalPrice = offPeakPrice,
            standardPrice = basePrice,
            savings = basePrice - offPeakPrice,
            adviceText = "Avoids peak-hour network rates on Avanti West Coast."
        )

        val altArrCalendar = peakDepTime.clone() as Calendar
        altArrCalendar.add(Calendar.MINUTE, estimateMinutes(o, d))

        results.add(
            createJourneyStructure(
                id = "${o}_${d}_ALTP_${date}_OFFPEAK",
                origin = o,
                destination = d,
                depTime = formatTime(peakDepTime),
                arrTime = formatTime(altArrCalendar),
                basePrice = basePrice,
                customCombination = offPeakCombination,
                isDelayed = false,
                delayMins = 0,
                date = date
            )
        )

        // 3. STATION SWAP OFFER
        val nearbyOffer = getNearbyStationOffer(o, d, basePrice)
        if (nearbyOffer != null) {
            results.add(nearbyOffer)
        }

        // Apply any railcard reductions to all generated prices
        val finalResults = if (!railcard.isNullOrEmpty() && railcard != "No Railcard") {
            results.map { journey ->
                val discPrice = journey.fareCombination.totalPrice * 0.66 // 34% railcard savings standard
                val discSavings = journey.fareCombination.standardPrice - discPrice
                journey.copy(
                    fareCombination = journey.fareCombination.copy(
                        totalPrice = discPrice,
                        savings = discSavings,
                        description = "${journey.fareCombination.description} + $railcard applied"
                    )
                )
            }
        } else {
            results
        }

        return finalResults.sortedBy { it.fareCombination.totalPrice }
    }

    // --- Private Helper Helpers to keep simulation extremely robust ---

    private fun estimateBasePrice(origin: String, dest: String): Double {
        val o = origin.uppercase()
        val d = dest.uppercase()
        if (o == d) return 5.0
        val sum = o.hashCode() + d.hashCode()
        val deterministicRandom = abs(sum) % 100
        return 20.0 + deterministicRandom.toDouble() + (estimateMinutes(o, d) * 0.3)
    }

    private fun estimateMinutes(origin: String, dest: String): Int {
        val o = origin.uppercase()
        val d = dest.uppercase()
        return when {
            (o == "EUS" && d == "MAN") || (o == "MAN" && d == "EUS") -> 126
            (o == "EUS" && d == "BHM") || (o == "BHM" && d == "EUS") -> 82
            (o == "EUS" && d == "EDI") || (o == "EDI" && d == "EUS") -> 265
            (o == "EUS" && d == "CRE") || (o == "CRE" && d == "EUS") -> 95
            (o == "MAN" && d == "EDI") || (o == "EDI" && d == "MAN") -> 195
            (o == "MAN" && d == "CRE") || (o == "CRE" && d == "MAN") -> 38
            (o == "BHM" && d == "CRE") || (o == "CRE" && d == "BHM") -> 52
            (o == "MAN" && d == "YRK") || (o == "YRK" && d == "MAN") -> 74
            (o == "YRK" && d == "EDI") || (o == "EDI" && d == "YRK") -> 145
            else -> 110
        }
    }

    private fun findSplitPoints(origin: String, dest: String): List<String> {
        val o = origin.uppercase()
        val d = dest.uppercase()
        return when {
            o == "EUS" && d == "MAN" -> listOf("CRE")
            o == "EUS" && d == "EDI" -> listOf("YRK")
            o == "MAN" && d == "EDI" -> listOf("YRK")
            o == "EUS" && d == "BHM" -> listOf("CRE")
            else -> listOf("CRE")
        }
    }

    private fun getNearbyStationOffer(origin: String, dest: String, basePrice: Double): Journey? {
        val o = origin.uppercase()
        val d = dest.uppercase()
        
        // Example swaps: Walking instead of expensive rail sectors
        if (o == "EUS") {
            val altPrice = basePrice * 0.65
            val altCombination = FareCombination(
                type = "AlternativeRoute",
                description = "Walk 8 mins to King's Cross (KGX) and take alternative operator",
                totalPrice = altPrice,
                standardPrice = basePrice,
                savings = basePrice - altPrice,
                adviceText = "Saves £19 with LNER service from neighboring station."
            )
            return createJourneyStructure(
                id = "EUS_KGX_ALT_SWAP",
                origin = "KGX",
                destination = d,
                depTime = "08:15",
                arrTime = "10:35",
                basePrice = basePrice,
                customCombination = altCombination,
                isDelayed = false,
                delayMins = 0,
                date = "2026-05-27"
            )
        }
        return null
    }

    private fun createJourneyStructure(
        id: String,
        origin: String,
        destination: String,
        depTime: String,
        arrTime: String,
        basePrice: Double,
        customCombination: FareCombination? = null,
        isDelayed: Boolean = false,
        delayMins: Int = 0,
        date: String
    ): Journey {
        val combination = customCombination ?: FareCombination(
            type = "Standard",
            description = "Standard Route",
            totalPrice = basePrice,
            standardPrice = basePrice,
            savings = 0.0,
            adviceText = "Standard single route"
        )

        // Build segment legs depending on splitting points
        val legs = mutableListOf<JourneyLeg>()
        val splits = combination.splitPoints

        if (splits.isEmpty()) {
            legs.add(
                JourneyLeg(
                    origin = origin,
                    destination = destination,
                    departureTime = depTime,
                    arrivalTime = arrTime,
                    durationText = "${estimateMinutes(origin, destination)} mins",
                    carrier = getCarrier(origin),
                    platform = "Platform ${(1..18).random()}",
                    trainNo = "9S${(10..99).random()}"
                )
            )
        } else {
            var currentOrigin = origin
            var currentDep = depTime
            splits.forEachIndexed { index, split ->
                val splMinutes = estimateMinutes(currentOrigin, split)
                val legDepCal = parseTime(currentDep)
                val legArrCal = legDepCal.clone() as Calendar
                legArrCal.add(Calendar.MINUTE, splMinutes)
                
                legs.add(
                    JourneyLeg(
                        origin = currentOrigin,
                        destination = split,
                        departureTime = currentDep,
                        arrivalTime = formatTime(legArrCal),
                        durationText = "$splMinutes mins",
                        carrier = getCarrier(currentOrigin),
                        platform = "Platform ${(1..12).random()}",
                        trainNo = "9S${(10..99).random() + index}"
                    )
                )
                currentOrigin = split
                // 5 mins padding transfer
                legArrCal.add(Calendar.MINUTE, 5)
                currentDep = formatTime(legArrCal)
            }
            val lastMin = estimateMinutes(currentOrigin, destination)
            val legDepCal = parseTime(currentDep)
            val legArrCal = legDepCal.clone() as Calendar
            legArrCal.add(Calendar.MINUTE, lastMin)

            legs.add(
                JourneyLeg(
                    origin = currentOrigin,
                    destination = destination,
                    departureTime = currentDep,
                    arrivalTime = formatTime(legArrCal),
                    durationText = "$lastMin mins",
                    carrier = getCarrier(currentOrigin),
                    platform = "Platform ${(1..12).random()}",
                    trainNo = "9S73"
                )
            )
        }

        val totalEstMins = estimateMinutes(origin, destination)
        val hrs = totalEstMins / 60
        val mins = totalEstMins % 60
        val durationText = if (hrs > 0) "${hrs}h ${mins}m" else "${mins}m"

        val disMessage = if (isDelayed) {
            "Delayed by $delayMins mins due to overhead wire fault near Rugby."
        } else null

        return Journey(
            id = id,
            origin = origin,
            destination = destination,
            departureDate = date,
            departureTime = depTime,
            arrivalTime = arrTime,
            durationText = durationText,
            changes = if (splits.isEmpty()) 0 else splits.size,
            fareCombination = combination,
            legs = legs,
            isDelayed = isDelayed,
            delayMinutes = delayMins,
            disruptionAlert = disMessage
        )
    }

    private fun getCarrier(origin: String): String {
        return when (origin.uppercase()) {
            "EUS" -> "Avanti West Coast"
            "MAN" -> "TransPennine Express"
            "BHM" -> "CrossCountry"
            "EDI" -> "LNER"
            "YRK" -> "Grand Central"
            else -> "National Rail"
        }
    }

    private fun parseTime(timeStr: String): Calendar {
        val cal = Calendar.getInstance()
        val parts = timeStr.split(":")
        if (parts.size >= 2) {
            cal.set(Calendar.HOUR_OF_DAY, parts[0].toIntOrNull() ?: 8)
            cal.set(Calendar.MINUTE, parts[1].toIntOrNull() ?: 0)
        } else {
            cal.set(Calendar.HOUR_OF_DAY, 8)
            cal.set(Calendar.MINUTE, 0)
        }
        return cal
    }

    private fun formatTime(cal: Calendar): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.UK)
        return sdf.format(cal.time)
    }

    private fun CodeToName(code: String): String {
        return Station.findByCode(code).name
    }
}
