package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Journey
import com.example.model.Station
import com.example.ui.components.SmartRailIcons
import com.example.ui.theme.*
import com.example.viewmodel.RailViewModel

@Composable
fun TrackerScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val liveDepartures by viewModel.liveDepartures.collectAsState()
    val activeTrackingJourney by viewModel.activeTrackingJourney.collectAsState()
    val trackingProgress by viewModel.trackingProgress.collectAsState()
    val currentStationCode by viewModel.currentStationCode.collectAsState()

    var stationExpanded by remember { mutableStateOf(false) }
    val selectedStationStats = Station.findByCode(currentStationCode)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Tracker module header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column {
                    Text(
                        text = "REAL-TIME TELEMETRY SYSTEM",
                        fontSize = 10.sp,
                        color = SteelGrey,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Live Tracker",
                        fontSize = 22.sp,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Geometric Balance badge (circle + square)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(DarkSurface, shape = RoundedCornerShape(20.dp))
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)), shape = RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .border(BorderStroke(2.dp, Color.White.copy(alpha = 0.40f)), shape = RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        // 1. LIVE STATION CHANGER AND PHYSICAL LED BOARD
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LIVE STATION BOARD",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Station Dropdown Toggle Selection
                    Box {
                        Button(
                            onClick = { stationExpanded = true },
                            colors = ButtonDefaults.buttonColors(containerColor = RailNavy),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("station_selection_button")
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = RailOrange)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Board: ${selectedStationStats.code} - ${selectedStationStats.name}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = stationExpanded,
                            onDismissRequest = { stationExpanded = false },
                            modifier = Modifier.background(StationAmethyst)
                        ) {
                            Station.PRESETS.forEach { st ->
                                DropdownMenuItem(
                                    text = { Text("${st.code} - ${st.name}", color = Color.White) },
                                    onClick = {
                                        viewModel.loadLiveDepartures(st.code)
                                        stationExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // LED Timetable board representation
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black, RoundedCornerShape(6.dp))
                            .border(1.dp, SteelGrey.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            // Headers
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text("DEP", color = SteelGrey, fontSize = 10.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                                Text("DESTINATION", color = SteelGrey, fontSize = 10.sp, modifier = Modifier.weight(4f), fontWeight = FontWeight.Bold)
                                Text("PLAT", color = SteelGrey, fontSize = 10.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                Text("STATUS", color = SteelGrey, fontSize = 10.sp, modifier = Modifier.weight(1.8f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Divider(color = SteelGrey.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(6.dp))

                            if (liveDepartures.isEmpty()) {
                                Text(
                                    "NO SERVICES ON BOARD",
                                    color = StationLedAmber,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                )
                            } else {
                                liveDepartures.forEach { departure ->
                                    val leg = departure.legs.firstOrNull()
                                    val statusText = if (departure.isDelayed) "Delayed ${departure.delayMinutes}m" else "On Time"
                                    val statusColor = if (departure.isDelayed) StationRed else StationGreen

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = departure.departureTime,
                                            color = StationLedAmber,
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.weight(1.2f),
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = Station.findByCode(departure.destination).name.uppercase(),
                                            color = StationLedAmber,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            maxLines = 1,
                                            modifier = Modifier.weight(4f)
                                        )
                                        Text(
                                            text = leg?.platform ?: "--",
                                            color = StationLedAmber,
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.weight(1.2f),
                                            textAlign = TextAlign.Center
                                        )
                                        Text(
                                            text = statusText.uppercase(),
                                            color = statusColor,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1.8f),
                                            textAlign = TextAlign.End
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. ACTIVE GPS PROGRESSION TRACKER MAP
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LIVE PROGRESSION ENGINE",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        if (activeTrackingJourney != null) {
                            Badge(containerColor = RailOrange, contentColor = Color.White) {
                                Text("CONNECTED", fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    if (activeTrackingJourney == null) {
                        // Empty State for Tracker
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = null,
                                tint = SteelGrey.copy(alpha = 0.5f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No active GPS link active",
                                subtitle = "Search and book an optimised fare, then initiate Live Tracking on purchase receipt to monitor movement telemetries offline.",
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    } else {
                        // Active GPS Tracking Screen
                        val journey = activeTrackingJourney!!
                        val legs = journey.legs

                        Text(
                            text = "${Station.findByCode(journey.origin).name} to ${Station.findByCode(journey.destination).name}",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp
                        )

                        Text(
                            text = "Departure date: ${journey.departureDate} at ${journey.departureTime}",
                            fontSize = 11.sp,
                            color = SteelGrey,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // Draw Custom Connection Node Map (from specifications)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(90.dp)
                                .padding(vertical = 8.dp)
                        ) {
                            NodeProgressionBar(legs = legs, progress = trackingProgress)
                        }

                        // Status Info
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Current Segment: ${legs.getOrNull((trackingProgress * legs.size).toInt().coerceIn(0, legs.size - 1))?.origin ?: journey.origin}",
                                fontSize = 11.sp,
                                color = SteelGrey,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Progress: ${(trackingProgress * 100).toInt().coerceAtMost(100)}%",
                                fontSize = 11.sp,
                                color = RailOrange,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Delay overlay indicator block
                        if (journey.isDelayed) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = StationRed.copy(alpha = 0.15f)),
                                border = BorderStroke(1.dp, StationRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Alert",
                                        tint = StationRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = journey.disruptionAlert ?: "Severe telemetry displacement detected.",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }

                        // Bottom action buttons for simulating / stop
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.simulateDisruption(journey.id) },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StationRed),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("simulate_disruption_button")
                            ) {
                                Text("Incur +45m Delay", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { viewModel.stopTracking() },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = BorderStroke(1.dp, SteelGrey),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                            ) {
                                Text("Stop GPS Tracking", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 3. STATION INTELLIGENCE MODULE & OCCUPANCY HEATMAP
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "STATION METADATA INTELLIGENCE",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Facilities, accessibility, and dynamic passenger crowding forecasts.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SteelGrey,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Amenities Row chips
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "FACILITIES & COFFEE CARRIER BRANDING:", fontSize = 11.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (selectedStationStats.facilities + selectedStationStats.foodCoffee).take(4).forEach { option ->
                            SuggestionChip(
                                onClick = {},
                                label = { Text(option, fontSize = 10.sp, color = Color.White) },
                                colors = SuggestionChipDefaults.suggestionChipColors(containerColor = RailNavy)
                            )
                        }
                    }

                    // Accessibility & connections metadata text info
                    Card(
                        colors = CardDefaults.cardColors(containerColor = StationAmethyst.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = RailYellow, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Accessibility: ${selectedStationStats.accessibility}", fontSize = 11.sp, color = Color.White)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = RailYellow, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Interconnections: ${selectedStationStats.transitConnections.joinToString(", ")}",
                                    fontSize = 11.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Occupancy Dynamic Heatmap (glowing operational design)
                    Text(
                        text = "LIVE STATION OCCUPANCY HEATMAP (24h Index):",
                        fontSize = 11.sp,
                        color = SteelGrey,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(55.dp)
                            .background(Color.Black, RoundedCornerShape(6.dp))
                            .padding(6.dp)
                    ) {
                        OccupancyHeatmapCanvas(heatmapValues = selectedStationStats.occupancyHeatmap)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("00:00 (Quiet)", fontSize = 9.sp, color = SteelGrey)
                        Text("12:00 (Peak)", fontSize = 9.sp, color = SteelGrey)
                        Text("23:59 (Quiet)", fontSize = 9.sp, color = SteelGrey)
                    }
                }
            }
        }
    }
}

// Helpers Composable for active progression line drawing
@Composable
fun NodeProgressionBar(legs: List<com.example.model.JourneyLeg>, progress: Float) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val centerY = height / 2f
        
        val segments = legs.size
        val stepX = width / segments.toFloat()

        // Draw track base slate line
        drawLine(
            color = SteelGrey.copy(alpha = 0.3f),
            start = Offset(0f, centerY),
            end = Offset(width, centerY),
            strokeWidth = 4.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Draw tracked progressive colored path
        val activeLimitX = progress * width
        drawLine(
            color = RailOrange,
            start = Offset(0f, centerY),
            end = Offset(activeLimitX, centerY),
            strokeWidth = 5.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Draw circles for nodes
        // First node
        val firstPassed = activeLimitX >= 0f
        drawCircle(
            color = if (firstPassed) RailOrange else SteelGrey,
            radius = 6.dp.toPx(),
            center = Offset(0f, centerY)
        )
        drawCircle(
            color = Color.Black,
            radius = 3.dp.toPx(),
            center = Offset(0f, centerY)
        )

        legs.forEachIndexed { i, leg ->
            val nodeX = (i + 1) * stepX
            val passed = activeLimitX >= nodeX
            
            drawCircle(
                color = if (passed) RailOrange else SteelGrey,
                radius = 6.dp.toPx(),
                center = Offset(nodeX, centerY)
            )
            drawCircle(
                color = Color.Black,
                radius = 3.dp.toPx(),
                center = Offset(nodeX, centerY)
            )
        }

        // Draw pulsating train icon on active tracker location
        val infiniteTransition = null // no need complex animations, simply locate point
        drawCircle(
            color = StationLedAmber,
            radius = 9.dp.toPx(),
            center = Offset(activeLimitX, centerY)
        )
        drawCircle(
            color = Color.Black,
            radius = 4.dp.toPx(),
            center = Offset(activeLimitX, centerY)
        )
    }
}

// Draw beautiful custom heat bars on Canvas
@Composable
fun OccupancyHeatmapCanvas(heatmapValues: List<Int>) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val barCount = heatmapValues.size
        val barSpacing = 4f
        val totalSpacing = barSpacing * (barCount - 1)
        val barWidth = (width - totalSpacing) / barCount

        heatmapValues.forEachIndexed { idx, valPercent ->
            val barHeight = (valPercent / 100f) * height
            val x = idx * (barWidth + barSpacing)
            val y = height - barHeight

            // Heat color mapping from quiet (cyan) to heavy peak (bright orange-red)
            val barColor = when {
                valPercent < 30 -> Color(0xFF00D2FF)
                valPercent < 70 -> StationLedAmber
                else -> RailOrange
            }

            drawRect(
                color = barColor,
                topLeft = Offset(x, y),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
            )
        }
    }
}

// Bullet subtitle text helper
@Composable
fun Text(text: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = text, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            color = SteelGrey,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            lineHeight = 15.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}
