package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent { 
      MyApplicationTheme { 
        com.example.ui.screens.JourneyFareItem(
          journey = com.example.model.Journey(
            id = "test_run",
            origin = "EUS",
            destination = "MAN",
            departureDate = "2026-05-28",
            departureTime = "08:15",
            arrivalTime = "10:21",
            durationText = "2h 06m",
            changes = 1,
            legs = emptyList(),
            fareCombination = com.example.model.FareCombination(
              type = "SplitTicket",
              description = "Split Ticket via Crewe",
              totalPrice = 26.90,
              standardPrice = 68.50,
              savings = 41.60,
              adviceText = "Saves £41.60 and requires no seat changes!"
            )
          ),
          onBookClick = {}
        )
      } 
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
