package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- Room Entities ---

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val origin: String,
    val destination: String,
    val date: String,
    val time: String,
    val ticketType: String, // e.g., "Off-Peak Single", "Advance", "Anytime Return", "Flexipass", "Season Ticket"
    val price: Double,
    val isActivated: Boolean = false,
    val activationTime: Long? = null,
    val duration: String = "49 min",
    val isSeason: Boolean = false,
    val expiryDate: String? = null,
    val scanCode: String = "SCT-RAIL-${(100000..999999).random()}"
)

@Entity(tableName = "passport_stations")
data class PassportStationEntity(
    @PrimaryKey val stationName: String,
    val visitedCount: Int = 1,
    val lastVisited: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_routes")
data class FavoriteRouteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val origin: String,
    val destination: String
)

@Entity(tableName = "recent_searches")
data class RecentSearchEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val origin: String,
    val destination: String,
    val timestamp: Long = System.currentTimeMillis()
)

// --- DAOs ---

@Dao
interface TicketDao {
    @Query("SELECT * FROM tickets ORDER BY id DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Update
    suspend fun updateTicket(ticket: TicketEntity)

    @Delete
    suspend fun deleteTicket(ticket: TicketEntity)

    @Query("DELETE FROM tickets")
    suspend fun clearAll()
}

@Dao
interface PassportDao {
    @Query("SELECT * FROM passport_stations ORDER BY lastVisited DESC")
    fun getVisitedStations(): Flow<List<PassportStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVisitedStation(station: PassportStationEntity)

    @Query("DELETE FROM passport_stations")
    suspend fun clearAll()
}

@Dao
interface FavoriteRouteDao {
    @Query("SELECT * FROM favorite_routes ORDER BY id DESC")
    fun getAllFavorites(): Flow<List<FavoriteRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(route: FavoriteRouteEntity)

    @Query("DELETE FROM favorite_routes WHERE origin = :origin AND destination = :destination")
    suspend fun deleteFavoriteByRoute(origin: String, destination: String)

    @Query("SELECT COUNT(*) FROM favorite_routes WHERE origin = :origin AND destination = :destination")
    fun isFavorite(origin: String, destination: String): Flow<Int>
}

@Dao
interface RecentSearchDao {
    @Query("SELECT * FROM recent_searches ORDER BY timestamp DESC LIMIT 10")
    fun getRecentSearches(): Flow<List<RecentSearchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearch(search: RecentSearchEntity)

    @Query("DELETE FROM recent_searches")
    suspend fun clearAll()
}

// --- Room Database ---

@Database(
    entities = [
        TicketEntity::class,
        PassportStationEntity::class,
        FavoriteRouteEntity::class,
        RecentSearchEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun ticketDao(): TicketDao
    abstract fun passportDao(): PassportDao
    abstract fun favoriteRouteDao(): FavoriteRouteDao
    abstract fun recentSearchDao(): RecentSearchDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "scotrail_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
