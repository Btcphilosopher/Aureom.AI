package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TrainService
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@Composable
fun PlannerScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier,
    onNavigateToService: (TrainService) -> Unit
) {
    val origin by viewModel.originInput.collectAsState()
    val destination by viewModel.destinationInput.collectAsState()
    val journeys by viewModel.plannedJourneys.collectAsState()

    val cheapest by viewModel.filterCheapest.collectAsState()
    val fastest by viewModel.filterFastest.collectAsState()
    val directOnly by viewModel.filterDirectOnly.collectAsState()
    val accessible by viewModel.filterAccessible.collectAsState()
    val bikeFriendly by viewModel.filterBikeFriendly.collectAsState()

    var showBuySuccessDialog by remember { mutableStateOf(false) }
    var selectedJourneyForBuy by remember { mutableStateOf<TrainService?>(null) }
    var purchaseTypeSelected by remember { mutableStateOf("Single") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Header Journey Banner ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ScotRailNavy),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("JOURNEY PLANNER", style = MaterialTheme.typography.labelSmall, color = SaltireBlue, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(origin, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color.LightGray, modifier = Modifier.padding(horizontal = 6.dp).size(16.dp))
                                Text(destination, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
                            }
                        }
                        IconButton(onClick = { viewModel.setTab("home") }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit search", tint = Color.White)
                        }
                    }
                }
            }
        }

        // --- Filter Chips Panel ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("FILTERS & PREFERENCES", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color.Gray)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = cheapest,
                        onClick = {
                            viewModel.filterCheapest.value = !cheapest
                            if (cheapest) viewModel.filterFastest.value = false
                            viewModel.searchJourneys()
                        },
                        label = { Text("Cheapest") },
                        leadingIcon = { if (cheapest) Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }
                    )
                    FilterChip(
                        selected = fastest,
                        onClick = {
                            viewModel.filterFastest.value = !fastest
                            if (fastest) viewModel.filterCheapest.value = false
                            viewModel.searchJourneys()
                        },
                        label = { Text("Fastest") },
                        leadingIcon = { if (fastest) Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }
                    )
                    FilterChip(
                        selected = directOnly,
                        onClick = {
                            viewModel.filterDirectOnly.value = !directOnly
                            viewModel.searchJourneys()
                        },
                        label = { Text("Direct") },
                        leadingIcon = { if (directOnly) Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = accessible,
                        onClick = {
                            viewModel.filterAccessible.value = !accessible
                            viewModel.searchJourneys()
                        },
                        label = { Text("Step-Free") },
                        leadingIcon = { Icon(Icons.Default.Accessible, null, modifier = Modifier.size(16.dp)) }
                    )
                    FilterChip(
                        selected = bikeFriendly,
                        onClick = {
                            viewModel.filterBikeFriendly.value = !bikeFriendly
                            viewModel.searchJourneys()
                        },
                        label = { Text("Bike Space") },
                        leadingIcon = { Icon(Icons.Default.DirectionsBike, null, modifier = Modifier.size(16.dp)) }
                    )
                }
            }
        }

        // --- Active Journey Results ---
        if (journeys.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.RailwayAlert, contentDescription = null, tint = RailwayRed, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No direct services found", fontWeight = FontWeight.Bold)
                        Text("Try adjusting your filters or search criteria.", color = Color.Gray, textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            items(journeys) { journey ->
                ElevatedCard(
                    onClick = { onNavigateToService(journey) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Top row with status & times
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = journey.departureTime,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = ScotRailNavy
                                )
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.padding(horizontal = 6.dp).size(14.dp), tint = Color.Gray)
                                Text(
                                    text = journey.expectedArrival,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            StatusChip(status = journey.status, delayedMinutes = journey.delayedMinutes)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Info row: Duration, Platform, Direct
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Duration: 49 min • Direct",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Platform ${journey.platform}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = SaltireBlue
                            )
                        }

                        // Facilities summary icons
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Wifi, null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                            Icon(Icons.Default.Bolt, null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                            Icon(Icons.Default.DirectionsBike, null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                            Icon(Icons.Default.Accessible, null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                            Spacer(modifier = Modifier.weight(1f))
                            Text("Class 385 eExpress", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }

                        // Connection Protection Warning
                        if (journey.connectionsRisk) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = ColorCancelled.copy(alpha = 0.08f)),
                                border = BorderStroke(1.dp, ColorCancelled.copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = "Connection Risk", tint = ColorCancelled, modifier = Modifier.size(16.dp))
                                    Text(
                                        text = "CONNECTION RISK: TIGHT CONNECTION DUE TO DELAY",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = ColorCancelled
                                    )
                                }
                            }
                        }

                        // Buy Ticket Action Panel
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (cheapest) "OFF-PEAK FARE" else "ANYTIME FARE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray
                                )
                                Text(
                                    text = if (cheapest) "£14.20" else "£24.80",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = ColorOnTime
                                )
                            }
                            Button(
                                onClick = {
                                    selectedJourneyForBuy = journey
                                    purchaseTypeSelected = "Single"
                                    showBuySuccessDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RailwayRed),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.ShoppingCart, null, modifier = Modifier.size(16.dp).padding(end = 4.dp))
                                Text("BUY TICKET")
                            }
                        }
                    }
                }
            }
        }
    }

    // --- Secure Purchase Simulation Dialog ---
    if (showBuySuccessDialog && selectedJourneyForBuy != null) {
        val journey = selectedJourneyForBuy!!
        val price = if (cheapest) 14.20 else 24.80

        AlertDialog(
            onDismissRequest = { showBuySuccessDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.purchaseTicket(
                            origin = journey.origin,
                            destination = journey.destination,
                            type = "Off-Peak $purchaseTypeSelected",
                            price = if (purchaseTypeSelected == "Single") price else price * 1.8,
                            time = journey.departureTime
                        )
                        showBuySuccessDialog = false
                        viewModel.setTab("tickets")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ScotRailNavy)
                ) {
                    Text("CONFIRM PURCHASE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBuySuccessDialog = false }) {
                    Text("CANCEL")
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Payment, contentDescription = null, tint = SaltireBlue)
                    Text("SECURE PAYMENT", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select Ticket Type:", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ElevatedCard(
                            onClick = { purchaseTypeSelected = "Single" },
                            colors = CardDefaults.cardColors(
                                containerColor = if (purchaseTypeSelected == "Single") ScotRailNavy.copy(alpha = 0.1f) else Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SINGLE", fontWeight = FontWeight.Bold)
                                Text("£${String.format("%.2f", price)}", color = ColorOnTime)
                            }
                        }
                        ElevatedCard(
                            onClick = { purchaseTypeSelected = "Return" },
                            colors = CardDefaults.cardColors(
                                containerColor = if (purchaseTypeSelected == "Return") ScotRailNavy.copy(alpha = 0.1f) else Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("RETURN", fontWeight = FontWeight.Bold)
                                Text("£${String.format("%.2f", price * 1.8)}", color = ColorOnTime)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Payments processed securely via Scotland Rail Tokenized Gateway. Your card data is encrypted and never stored.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        )
    }
}
