package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TrainService
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@Composable
fun LiveScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier,
    onNavigateToService: (TrainService) -> Unit
) {
    val selectedBoard by viewModel.selectedBoardStation.collectAsState()
    val departures by viewModel.stationDepartures.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()

    var activeLiveTab by remember { mutableStateOf("board") } // board, map, operations

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- Live Board Sub-Tabs Selector ---
        TabRow(
            selectedTabIndex = when (activeLiveTab) {
                "board" -> 0
                "map" -> 1
                "operations" -> 2
                else -> 0
            },
            containerColor = ScotRailNavy,
            contentColor = Color.White
        ) {
            Tab(
                selected = activeLiveTab == "board",
                onClick = { activeLiveTab = "board" },
                text = { Text("DEPARTURE BOARD", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.FormatListBulleted, null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = activeLiveTab == "map",
                onClick = { activeLiveTab = "map" },
                text = { Text("LIVE TRAIN MAP", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Map, null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = activeLiveTab == "operations",
                onClick = { activeLiveTab = "operations" },
                text = { Text("OPS DASHBOARD", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.DeveloperMode, null, modifier = Modifier.size(16.dp)) }
            )
        }

        // --- Active Sub-View ---
        Box(modifier = Modifier.weight(1f)) {
            when (activeLiveTab) {
                "board" -> DepartureBoardView(
                    viewModel = viewModel,
                    departures = departures,
                    selectedBoard = selectedBoard,
                    onNavigateToService = onNavigateToService
                )
                "map" -> LiveTrainMapView(viewModel = viewModel, onNavigateToService = onNavigateToService)
                "operations" -> LiveOperationsView(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun DepartureBoardView(
    viewModel: RailViewModel,
    departures: List<TrainService>,
    selectedBoard: String,
    onNavigateToService: (TrainService) -> Unit
) {
    var showBoardSelect by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Board Selector Button
        OutlinedCard(
            onClick = { showBoardSelect = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = SaltireBlue)
                    Column {
                        Text("CURRENT BOARD STATION", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text(selectedBoard, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
        }

        // Departures List Box styled as classical railway board
        Card(
            colors = CardDefaults.cardColors(containerColor = RailDarkBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header of Board
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("DEP TIME / DESTINATION", color = Color.Yellow.copy(alpha = 0.7f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    Text("PLAT / STATUS", color = Color.Yellow.copy(alpha = 0.7f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                }
                HorizontalDivider(color = Color.Yellow.copy(alpha = 0.3f))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().padding(vertical = 12.dp)
                ) {
                    items(departures) { dep ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToService(dep) }
                                .border(BorderStroke(1.dp, Color.Yellow.copy(alpha = 0.1f)), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = dep.departureTime,
                                        color = Color.Yellow,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 18.sp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = dep.destination.uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        maxLines = 1
                                    )
                                }
                                Text(
                                    text = dep.trainType,
                                    color = Color.Gray,
                                    fontSize = 12.sp
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "PLAT ${dep.platform}",
                                    color = Color.Yellow,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = dep.status,
                                    color = when (dep.status) {
                                        "ON TIME" -> ColorOnTime
                                        "BOARDING" -> ColorBoarding
                                        "DELAYED" -> ColorDelayed
                                        "CANCELLED" -> ColorCancelled
                                        else -> Color.Gray
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showBoardSelect) {
        LocationSelectorDialog(
            title = "Choose Board Station",
            stations = viewModel.stations,
            onDismiss = { showBoardSelect = false },
            onSelect = {
                viewModel.selectBoard(it.name)
                showBoardSelect = false
            }
        )
    }
}

@Composable
fun LiveTrainMapView(
    viewModel: RailViewModel,
    onNavigateToService: (TrainService) -> Unit
) {
    // Basic Animated train tracking pulse
    val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
    val pulseRatio by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseRatio"
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = RailLightSurface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SCOTTISH RAILWAY NETWORK",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = ScotRailNavy
                )
                Text(
                    text = "Interactive geographic node representation. Tap nodes to select as active search.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Custom Canvas Drawing the Map of Scotland Railway lines
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(RailLightBg, RoundedCornerShape(12.dp))
                        .border(BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)), RoundedCornerShape(12.dp))
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Map projection calculations (scaling lat/lng coordinates roughly to fit canvas)
                        val pointsMap = mapOf(
                            "EDB" to Offset(w * 0.70f, h * 0.75f), // Edinburgh
                            "GLQ" to Offset(w * 0.40f, h * 0.75f), // Glasgow
                            "STG" to Offset(w * 0.45f, h * 0.55f), // Stirling
                            "PTH" to Offset(w * 0.55f, h * 0.45f), // Perth
                            "DEE" to Offset(w * 0.72f, h * 0.40f), // Dundee
                            "ABD" to Offset(w * 0.85f, h * 0.20f), // Aberdeen
                            "INV" to Offset(w * 0.45f, h * 0.15f), // Inverness
                            "OBN" to Offset(w * 0.20f, h * 0.60f), // Oban
                            "FTW" to Offset(w * 0.25f, h * 0.42f)  // Fort William
                        )

                        // Draw lines (tracks)
                        fun drawTrackLine(from: String, to: String, isDisrupted: Boolean = false) {
                            val p1 = pointsMap[from]
                            val p2 = pointsMap[to]
                            if (p1 != null && p2 != null) {
                                drawLine(
                                    color = if (isDisrupted) RailwayRed else SaltireBlue.copy(alpha = 0.5f),
                                    start = p1,
                                    end = p2,
                                    strokeWidth = if (isDisrupted) 5f else 3f
                                )
                            }
                        }

                        // Connect railway grid
                        drawTrackLine("GLQ", "EDB")
                        drawTrackLine("GLQ", "STG")
                        drawTrackLine("EDB", "STG")
                        drawTrackLine("STG", "PTH")
                        drawTrackLine("PTH", "DEE")
                        drawTrackLine("DEE", "ABD")
                        drawTrackLine("PTH", "INV")
                        drawTrackLine("GLQ", "OBN", isDisrupted = true) // Disrupted Oban path
                        drawTrackLine("GLQ", "FTW")

                        // Draw Station Nodes
                        pointsMap.forEach { (code, pos) ->
                            drawCircle(
                                color = if (code == "OBN") RailwayRed else ScotRailNavy,
                                radius = 8f,
                                center = pos
                            )
                            drawCircle(
                                color = (if (code == "OBN") RailwayRed else SaltireBlue).copy(alpha = 0.3f),
                                radius = 12f,
                                center = pos
                            )
                        }
                    }

                    // Clickable Overlay buttons positioning stations labels on map
                    val stationsMapped = listOf(
                        Triple("Edinburgh", "EDB", Alignment.BottomEnd),
                        Triple("Glasgow", "GLQ", Alignment.BottomStart),
                        Triple("Stirling", "STG", Alignment.Center),
                        Triple("Perth", "PTH", Alignment.CenterEnd),
                        Triple("Dundee", "DEE", Alignment.TopEnd),
                        Triple("Aberdeen", "ABD", Alignment.TopEnd),
                        Triple("Inverness", "INV", Alignment.TopCenter),
                        Triple("Oban", "OBN", Alignment.BottomStart),
                        Triple("Fort William", "FTW", Alignment.CenterStart)
                    )

                    stationsMapped.forEach { (name, code, align) ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                        ) {
                            // Render label corresponding to positions
                            val offsetModifier = when (code) {
                                "EDB" -> Modifier.align(Alignment.BottomEnd).padding(bottom = 60.dp, end = 20.dp)
                                "GLQ" -> Modifier.align(Alignment.BottomStart).padding(bottom = 60.dp, start = 80.dp)
                                "STG" -> Modifier.align(Alignment.Center).padding(bottom = 80.dp, end = 60.dp)
                                "PTH" -> Modifier.align(Alignment.Center).padding(bottom = 120.dp, start = 60.dp)
                                "DEE" -> Modifier.align(Alignment.Center).padding(bottom = 140.dp, start = 180.dp)
                                "ABD" -> Modifier.align(Alignment.TopEnd).padding(top = 60.dp, end = 10.dp)
                                "INV" -> Modifier.align(Alignment.TopCenter).padding(top = 30.dp, start = 40.dp)
                                "OBN" -> Modifier.align(Alignment.CenterStart).padding(top = 100.dp, start = 10.dp)
                                "FTW" -> Modifier.align(Alignment.CenterStart).padding(bottom = 50.dp, start = 30.dp)
                                else -> Modifier.align(align)
                            }

                            Row(
                                modifier = offsetModifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.White.copy(alpha = 0.9f))
                                    .border(BorderStroke(1.dp, Color.LightGray), RoundedCornerShape(6.dp))
                                    .clickable {
                                        viewModel.updateSearchInputs(name + " Waverley", "Glasgow Queen Street")
                                        viewModel.selectBoard(name)
                                    }
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (code == "OBN") RailwayRed else ColorOnTime)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(code, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ScotRailNavy)
                            }
                        }
                    }

                    // Dynamic Moving train markers
                    Box(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 110.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(RailwayRed)
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Train, null, modifier = Modifier.size(12.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SR258 LIVE (Class 385)", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiveOperationsView(viewModel: RailViewModel) {
    val activeCount by viewModel.liveOpsTrainsActive.collectAsState()
    val onTimeRatio by viewModel.liveOpsOnTimeRatio.collectAsState()
    val delayedCount by viewModel.liveOpsDelayedCount.collectAsState()
    val cancelledCount by viewModel.liveOpsCancelledCount.collectAsState()
    val regionStatus by viewModel.liveOpsRegionStatus.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = RailDarkSurface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "LIVE CONTROL CENTRE METRICS",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Yellow,
                        fontWeight = FontWeight.Bold
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Card(modifier = Modifier.weight(1f).height(100.dp), colors = CardDefaults.cardColors(containerColor = RailDarkBg)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.Center) {
                                Text("ACTIVE SERVICES", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                Text("$activeCount", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Card(modifier = Modifier.weight(1f).height(100.dp), colors = CardDefaults.cardColors(containerColor = RailDarkBg)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.Center) {
                                Text("ON TIME KPI", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                Text("$onTimeRatio%", color = ColorOnTime, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Card(modifier = Modifier.weight(1f).height(100.dp), colors = CardDefaults.cardColors(containerColor = RailDarkBg)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.Center) {
                                Text("DELAYED", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                Text("$delayedCount", color = ColorDelayed, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Card(modifier = Modifier.weight(1f).height(100.dp), colors = CardDefaults.cardColors(containerColor = RailDarkBg)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.Center) {
                                Text("CANCELLED", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                Text("$cancelledCount", color = ColorCancelled, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }
        }

        item {
            Text("REGIONAL OPERATIONS STATUS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = RailLightSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    regionStatus.forEach { (region, status) ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(region, fontWeight = FontWeight.SemiBold, color = ScotRailNavy)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (status.contains("MINOR")) ColorDelayed else ColorOnTime)
                                )
                                Text(status, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = if (status.contains("MINOR")) ColorDelayed else ColorOnTime)
                            }
                        }
                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                    }
                }
            }
        }
    }
}
