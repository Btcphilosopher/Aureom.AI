package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@Composable
fun StationScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val stationModeActive by viewModel.stationModeActive.collectAsState()
    val nearStationName by viewModel.simulatedNearStation.collectAsState()

    val assistStepFree by viewModel.assistStepFree.collectAsState()
    val assistWheelchair by viewModel.assistWheelchair.collectAsState()
    val assistVisual by viewModel.assistVisualImpairment.collectAsState()
    val assistHearing by viewModel.assistHearingImpairment.collectAsState()
    val assistAnimal by viewModel.assistAnimal.collectAsState()
    val assistStatus by viewModel.assistStatus.collectAsState()

    val selectedWayfindingRoute by viewModel.selectedWayfindingRoute.collectAsState()

    val currentStation = viewModel.stations.find { it.name.lowercase().contains(nearStationName.lowercase().take(5)) }
        ?: viewModel.stations.first()

    var activeSubTab by remember { mutableStateOf("amenities") } // amenities, wayfinding, assist

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Station Title Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ScotRailNavy),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "STATION MODE ACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            color = ColorOnTime,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Icon(Icons.Default.CellTower, contentDescription = null, tint = ColorOnTime)
                    }
                    Text(
                        currentStation.name,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        currentStation.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.LightGray
                    )
                }
            }
        }

        // Inner Mode Selection Chips
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = activeSubTab == "amenities",
                    onClick = { activeSubTab = "amenities" },
                    label = { Text("SERVICES") },
                    leadingIcon = { Icon(Icons.Default.Info, null, modifier = Modifier.size(16.dp)) }
                )
                FilterChip(
                    selected = activeSubTab == "wayfinding",
                    onClick = { activeSubTab = "wayfinding" },
                    label = { Text("WAYFINDING") },
                    leadingIcon = { Icon(Icons.Default.Directions, null, modifier = Modifier.size(16.dp)) }
                )
                FilterChip(
                    selected = activeSubTab == "assist",
                    onClick = { activeSubTab = "assist" },
                    label = { Text("ASSIST") },
                    leadingIcon = { Icon(Icons.Default.AccessibleForward, null, modifier = Modifier.size(16.dp)) }
                )
            }
        }

        when (activeSubTab) {
            "amenities" -> {
                item {
                    Text("STATION AMENITIES", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScotRailNavy)
                    Spacer(modifier = Modifier.height(4.dp))
                }

                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(12.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            AmenityRow("Toilets", currentStation.hasToilet, Icons.Default.Wc)
                            AmenityRow("Cafés & Shops", currentStation.hasCafe, Icons.Default.LocalCafe)
                            AmenityRow("Taxis Outside", currentStation.hasTaxi, Icons.Default.LocalTaxi)
                            AmenityRow("Bicycle Racks & Storage", currentStation.hasBikeFacilities, Icons.Default.DirectionsBike)
                            AmenityRow("Step-Free Access Lift", currentStation.hasStepFreeAccess, Icons.Default.Elevator)
                            AmenityRow("Passenger Assistance Help Points", currentStation.hasHelpPoint, Icons.Default.HelpCenter)
                        }
                    }
                }

                item {
                    Text("BUS CONNECIONS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScotRailNavy)
                    Spacer(modifier = Modifier.height(4.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(12.dp)) {
                        Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DirectionsBus, null, tint = SaltireBlue)
                            Text(currentStation.busConnections, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            "wayfinding" -> {
                item {
                    Text("SIMPLE WAYFINDING ROUTES", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScotRailNavy)
                    Spacer(modifier = Modifier.height(4.dp))
                }

                val wayfindingOptions = listOf(
                    "Platform 4 → Princes St Exit",
                    "Princes St Entrance → Platform 11 Lifts",
                    "Platform 19 → Station Toilets",
                    "Main Ticket Hall → Taxi Rank"
                )

                items(wayfindingOptions) { route ->
                    val isSelected = selectedWayfindingRoute == route
                    Card(
                        onClick = { viewModel.selectedWayfindingRoute.value = route },
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) SaltireBlue.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, if (isSelected) SaltireBlue else Color.LightGray.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(Icons.Default.Navigation, null, tint = if (isSelected) SaltireBlue else Color.Gray, modifier = Modifier.size(20.dp))
                                Text(route, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }
                            if (isSelected) {
                                Icon(Icons.Default.CheckCircle, null, tint = SaltireBlue)
                            }
                        }
                    }
                }

                item {
                    // Wayfinding steps visualizer
                    Card(colors = CardDefaults.cardColors(containerColor = RailLightBg), shape = RoundedCornerShape(12.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("ROUTE STEPS GUIDE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                            WayfindingStep("1", "Depart the train on Platform 4 and walk towards the terminal buffers.", true)
                            WayfindingStep("2", "Pass through the automated ticket barriers using your mTICKET barcode.", true)
                            WayfindingStep("3", "Turn left and take the escalators or adjacent lifts up to Princes Street exit.", false)
                        }
                    }
                }
            }

            "assist" -> {
                item {
                    Text("TRAVEL ASSIST: REQUEST ASSISTANCE", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScotRailNavy)
                    Spacer(modifier = Modifier.height(4.dp))
                }

                if (assistStatus == "NONE") {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Check your specific mobility requirements to notify station staff immediately:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                                AssistCheckbox("Step-Free Access Lift required", assistStepFree) { viewModel.assistStepFree.value = it }
                                AssistCheckbox("Wheelchair Space booking", assistWheelchair) { viewModel.assistWheelchair.value = it }
                                AssistCheckbox("Visual impairment assistance", assistVisual) { viewModel.assistVisualImpairment.value = it }
                                AssistCheckbox("Hearing loop / assistance", assistHearing) { viewModel.assistHearingImpairment.value = it }
                                AssistCheckbox("Assistance guide animal", assistAnimal) { viewModel.assistAnimal.value = it }

                                Button(
                                    onClick = { viewModel.submitTravelAssist() },
                                    colors = ButtonDefaults.buttonColors(containerColor = RailwayRed),
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                                ) {
                                    Icon(Icons.Default.Send, null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("SUBMIT REQUEST TO STAFF")
                                }
                            }
                        }
                    }
                } else {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ColorOnTime.copy(alpha = 0.08f)),
                            border = BorderStroke(1.dp, ColorOnTime.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Verified, null, tint = ColorOnTime, modifier = Modifier.size(48.dp))
                                Text("STAFF ASSIST CONFIRMED", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ColorOnTime)

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    StatusTimelineItem("Requested", true)
                                    StatusTimelineItem("Station Staff Notified", assistStatus == "CONFIRMED" || assistStatus == "READY")
                                    StatusTimelineItem("Staff Ready on Platform 4", assistStatus == "READY")
                                }

                                Button(
                                    onClick = { viewModel.cancelTravelAssist() },
                                    colors = ButtonDefaults.buttonColors(containerColor = ColorCancelled),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("CANCEL REQUEST")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AmenityRow(name: String, available: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = SaltireBlue, modifier = Modifier.size(20.dp))
            Text(name, fontWeight = FontWeight.SemiBold)
        }
        Text(
            text = if (available) "AVAILABLE" else "NOT AVAILABLE",
            color = if (available) ColorOnTime else ColorCancelled,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
fun WayfindingStep(num: String, desc: String, done: Boolean) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(if (done) ColorOnTime else Color.LightGray),
            contentAlignment = Alignment.Center
        ) {
            Text(num, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Text(desc, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun AssistCheckbox(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun StatusTimelineItem(label: String, completed: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(
            imageVector = if (completed) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (completed) ColorOnTime else Color.LightGray
        )
        Text(label, fontWeight = if (completed) FontWeight.Bold else FontWeight.Normal, color = if (completed) ColorOnTime else Color.Gray)
    }
}
