package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Scotland Rail Color Palette (Saltire Navy, Sky Blue, Railway Red, Slate)
val ScotRailNavy = Color(0xFF002D62)
val SaltireBlue = Color(0xFF0072C6)
val RailwayRed = Color(0xFFC60C30)

// Light Theme Surface Colors
val RailLightBg = Color(0xFFF8FAFC)
val RailLightSurface = Color(0xFFFFFFFF)
val RailLightOnSurface = Color(0xFF0F172A)
val RailLightOnSurfaceVariant = Color(0xFF475569)

// Dark Theme Surface Colors (Live Operations Mode)
val RailDarkBg = Color(0xFF0F172A)
val RailDarkSurface = Color(0xFF1E293B)
val RailDarkOnSurface = Color(0xFFF8FAFC)
val RailDarkOnSurfaceVariant = Color(0xFF94A3B8)

// Status colors
val ColorOnTime = Color(0xFF10B981) // Green
val ColorDelayed = Color(0xFFF59E0B) // Amber
val ColorCancelled = Color(0xFFEF4444) // Red
val ColorBoarding = Color(0xFF3B82F6) // Blue
val ColorPlatform = Color(0xFF8B5CF6) // Purple

