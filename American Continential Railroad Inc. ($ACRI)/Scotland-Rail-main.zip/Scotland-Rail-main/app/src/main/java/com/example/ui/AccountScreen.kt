package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@Composable
fun AccountScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableStateOf("profile") } // profile, help

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sub tabs
        TabRow(
            selectedTabIndex = if (activeSubTab == "profile") 0 else 1,
            containerColor = ScotRailNavy,
            contentColor = Color.White
        ) {
            Tab(
                selected = activeSubTab == "profile",
                onClick = { activeSubTab = "profile" },
                text = { Text("MY PROFILE", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.AccountBox, null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = activeSubTab == "help",
                onClick = { activeSubTab = "help" },
                text = { Text("HELP & SUPPORT", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.SupportAgent, null, modifier = Modifier.size(16.dp)) }
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeSubTab) {
                "profile" -> ProfileView(viewModel = viewModel)
                "help" -> HelpSupportView()
            }
        }
    }
}

@Composable
fun ProfileView(viewModel: RailViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User Profile Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(SaltireBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("TC", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Column {
                        Text("Thomas Campbell", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                        Text("thomas.campbell@scotrail.scot", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(ColorOnTime.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("LOYALTY MEMBER", color = ColorOnTime, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                    }
                }
            }
        }

        // Tokenized Security Indicator Info
        item {
            Text("SECURE PAYMENT ARCHITECTURE", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScotRailNavy)
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.Security, null, tint = ColorOnTime)
                        Text("Secure Apple Pay & Google Pay Tokenization Active", fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "Credit card credentials are fully encrypted at the transport system level. Payment gateway tokens are swapped automatically during checkout to protect against interception.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        }

        // Accessibility Settings Checkbox Shortcuts
        item {
            Text("ACCESSIBILITY PREFERENCES", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScotRailNavy)
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = true, onCheckedChange = {})
                        Text("Auto-request wheelchair ramp assistance")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = false, onCheckedChange = {})
                        Text("Increase text scale & high contrast ratios")
                    }
                }
            }
        }
    }
}

@Composable
fun HelpSupportView() {
    val faqs = listOf(
        "How do I activate my digital ticket?" to "Simply find your bought ticket in the 'My Tickets' wallet tab and tap the large red 'ACTIVATE TICKET' button before boarding. Your ticket's secure validation barcode will be revealed instantly.",
        "What is the Delay Repay process?" to "If your train service has been delayed by 30 minutes or more, select the ticket inside our 'Delay Repay' tab. Our Intelligent Claim Assistant will automatically extract your journey history, pre-calculate the qualifying refund, and submit the claim.",
        "Can I load tickets onto my Smartcard?" to "Yes! Our digital companion allows you to link your physical Scotland Smartcard, view valid loaded seasonal contracts, and top up contracts seamlessly using the unified tickets dashboard.",
        "How do I report Lost Property?" to "If you have forgotten baggage or personal items on a Scottish railway train, contact the station ticket desk helper inside the HELP section, or submit a lost luggage registry online. Our agents will scan central depots immediately."
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("SUPPORT HELPDESK & FAQS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScotRailNavy)
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(faqs) { (q, a) ->
            var expanded by remember { mutableStateOf(false) }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(q, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = ScotRailNavy, modifier = Modifier.weight(1f))
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null
                        )
                    }
                    if (expanded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(a, style = MaterialTheme.typography.bodySmall, color = Color.Gray, lineHeight = 18.sp)
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaltireBlue.copy(alpha = 0.08f)),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, SaltireBlue.copy(alpha = 0.3f))
            ) {
                Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Phone, null, tint = SaltireBlue)
                    Column {
                        Text("Need live support?", fontWeight = FontWeight.Bold, color = SaltireBlue)
                        Text("Call our 24/7 passenger assistance desk at +44 141 335 4000.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
