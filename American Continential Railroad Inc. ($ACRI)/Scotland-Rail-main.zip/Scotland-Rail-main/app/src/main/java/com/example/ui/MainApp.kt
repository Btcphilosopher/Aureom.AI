package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TrainService
import com.example.model.RouteStop
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentMainTab.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()
    val stationModeActive by viewModel.stationModeActive.collectAsState()
    val selectedService by viewModel.selectedService.collectAsState()

    val coroutineScope = rememberCoroutineScope()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "SCOTLAND'S RAILWAY",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaltireBlue,
                                letterSpacing = 1.5.sp
                            )
                            Text(
                                text = when (currentTab) {
                                    "home" -> "Scotland Rail"
                                    "planner" -> "Journey Planner"
                                    "departures" -> "Live Departures"
                                    "tickets" -> "Ticket Wallet"
                                    "explore" -> "Scenic & Journal"
                                    "station" -> "Station Guide"
                                    "account" -> "My Account"
                                    else -> "Scotland Rail"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = ScotRailNavy
                            )
                        }
                    },
                    navigationIcon = {
                        if (isOffline) {
                            Icon(
                                imageVector = Icons.Default.CloudOff,
                                contentDescription = "Offline Mode Active",
                                tint = RailwayRed,
                                modifier = Modifier
                                    .padding(start = 16.dp)
                                    .size(20.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.CellTower,
                                contentDescription = "Network Connected",
                                tint = ColorOnTime,
                                modifier = Modifier
                                    .padding(start = 16.dp)
                                    .size(20.dp)
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.setTab("account") },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("top_bar_account_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "View Profile",
                                tint = ScotRailNavy,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Color.White,
                        titleContentColor = ScotRailNavy
                    )
                )
            },
            bottomBar = {
                if (!isWideScreen) {
                    NavigationBar(
                        containerColor = Color.White,
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("bottom_nav_bar")
                    ) {
                        val navItems = listOf(
                            Triple("home", "Home", Icons.Default.Home),
                            Triple("planner", "Planner", Icons.Default.Directions),
                            Triple("departures", "Live", Icons.Default.Schedule),
                            Triple("tickets", "Tickets", Icons.Default.ConfirmationNumber),
                            Triple("explore", "Explore", Icons.Default.Explore)
                        )

                        navItems.forEach { (tab, label, icon) ->
                            NavigationBarItem(
                                selected = currentTab == tab,
                                onClick = { viewModel.setTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        modifier = Modifier.size(24.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = label,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = ScotRailNavy,
                                    indicatorColor = ScotRailNavy,
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray
                                ),
                                modifier = Modifier.testTag("nav_item_$tab")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isWideScreen) {
                    NavigationRail(
                        containerColor = Color.White,
                        modifier = Modifier
                            .fillMaxHeight()
                            .testTag("side_nav_rail")
                    ) {
                        val railItems = listOf(
                            Triple("home", "Home", Icons.Default.Home),
                            Triple("planner", "Planner", Icons.Default.Directions),
                            Triple("departures", "Live Boards", Icons.Default.Schedule),
                            Triple("tickets", "My Tickets", Icons.Default.ConfirmationNumber),
                            Triple("explore", "Scenic routes", Icons.Default.Explore),
                            Triple("station", "Station Guide", Icons.Default.Storefront),
                            Triple("account", "My Profile", Icons.Default.AccountCircle)
                        )

                        railItems.forEach { (tab, label, icon) ->
                            NavigationRailItem(
                                selected = currentTab == tab,
                                onClick = { viewModel.setTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        modifier = Modifier.size(24.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = ScotRailNavy,
                                    indicatorColor = ScotRailNavy,
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray
                                ),
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .testTag("rail_item_$tab")
                            )
                        }
                    }
                }

                // Main screen routing with animated transitions
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(Color(0xFFF2F4F7)) // Sleek interface background
                ) {
                    when (currentTab) {
                        "home" -> HomeScreen(
                            viewModel = viewModel,
                            onNavigateToService = { service ->
                                viewModel.selectedService.value = service
                                viewModel.setTab("departures")
                            }
                        )
                        "planner" -> PlannerScreen(
                            viewModel = viewModel,
                            onNavigateToService = { service ->
                                viewModel.selectedService.value = service
                                viewModel.setTab("departures")
                            }
                        )
                        "departures" -> LiveScreen(
                            viewModel = viewModel,
                            onNavigateToService = { service ->
                                viewModel.selectedService.value = service
                            }
                        )
                        "tickets" -> WalletScreen(
                            viewModel = viewModel
                        )
                        "explore" -> ExploreScreen(
                            viewModel = viewModel
                        )
                        "station" -> StationScreen(
                            viewModel = viewModel
                        )
                        "account" -> AccountScreen(
                            viewModel = viewModel
                        )
                        else -> HomeScreen(
                            viewModel = viewModel,
                            onNavigateToService = { service ->
                                viewModel.selectedService.value = service
                                viewModel.setTab("departures")
                            }
                        )
                    }
                }
            }
        }
    }

    // --- Dynamic High Fidelity Service Tracker & Detail Dialog ---
    if (selectedService != null) {
        val s = selectedService!!
        AlertDialog(
            onDismissRequest = { viewModel.selectedService.value = null },
            confirmButton = {
                Button(
                    onClick = { viewModel.selectedService.value = null },
                    colors = ButtonDefaults.buttonColors(containerColor = ScotRailNavy),
                    modifier = Modifier.testTag("service_details_close")
                ) {
                    Text("CLOSE TRACKER", fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = s.serviceId,
                            style = MaterialTheme.typography.labelMedium,
                            color = SaltireBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    when (s.status) {
                                        "ON TIME" -> ColorOnTime.copy(alpha = 0.15f)
                                        "BOARDING" -> ColorBoarding.copy(alpha = 0.15f)
                                        "DELAYED" -> ColorDelayed.copy(alpha = 0.15f)
                                        "CANCELLED" -> ColorCancelled.copy(alpha = 0.15f)
                                        else -> Color.LightGray
                                    }
                                )
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = s.status,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = when (s.status) {
                                    "ON TIME" -> ColorOnTime
                                    "BOARDING" -> ColorBoarding
                                    "DELAYED" -> ColorDelayed
                                    "CANCELLED" -> ColorCancelled
                                    else -> Color.DarkGray
                                }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Real-Time Train Tracker",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = ScotRailNavy
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TripOrigin, null, tint = SaltireBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(s.origin, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Place, null, tint = RailwayRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(s.destination, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("DEPARTURE TIME", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                                    Text(s.departureTime, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.bodyLarge, color = ScotRailNavy)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("EXPECTED ARRIVAL", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                                    Text(s.expectedArrival, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.bodyLarge, color = if (s.status == "DELAYED") ColorDelayed else ColorOnTime)
                                }
                            }
                            if (s.delayReason != null) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = ColorCancelled.copy(alpha = 0.08f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Default.Warning, null, tint = ColorCancelled, modifier = Modifier.size(14.dp))
                                        Text(s.delayReason!!, style = MaterialTheme.typography.bodySmall, color = ColorCancelled, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }

                    Text(
                        text = "JOURNEY SCHEDULE & STOPS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = ScotRailNavy,
                        letterSpacing = 0.5.sp
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                    ) {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(s.stops) { stop ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(if (stop.isCompleted) ColorOnTime else Color.LightGray)
                                        )
                                        Text(
                                            text = stop.stationName,
                                            fontWeight = if (stop.isCompleted) FontWeight.Bold else FontWeight.Normal,
                                            color = if (stop.isCompleted) ColorOnTime else Color.DarkGray,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                    Text(
                                        text = stop.scheduledTime,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (stop.isCompleted) ColorOnTime else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        )
    }
}
