package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DisruptionAlert
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@Composable
fun DisruptionScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val disruptions = viewModel.disruptions
    val temp by viewModel.localWeatherTemp.collectAsState()
    val condition by viewModel.localWeatherCondition.collectAsState()
    val windSpeed by viewModel.localWeatherWindSpeed.collectAsState()
    val warnings by viewModel.weatherWarnings.collectAsState()

    var showReplannerWizard by remember { mutableStateOf(false) }
    var selectedDisruptionForReplanning by remember { mutableStateOf<DisruptionAlert?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Disruption Hub Title ---
        item {
            Text(
                "LIVE DISRUPTION CENTRE",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = ScotRailNavy
            )
            Text(
                "Live network operations feedback. View delays, cancellations, and replacement facilities.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // --- Weather Alerts Panel ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, ColorDelayed.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Cloud, null, tint = SaltireBlue)
                            Text("WEATHER & NETWORK CONDITIONS", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(ColorDelayed.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("WEATHER WARNING", color = ColorDelayed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("TEMPERATURE", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(temp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("CONDITIONS", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(condition, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("WIND SPEED", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(windSpeed, fontWeight = FontWeight.Bold)
                        }
                    }

                    warnings.forEach { warn ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.Warning, null, tint = ColorDelayed, modifier = Modifier.size(16.dp))
                            Text(warn, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }
            }
        }

        // --- Disruption alerts feed ---
        item {
            Text("CURRENT ACTIVE DISRUPTIONS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScotRailNavy)
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(disruptions) { alert ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, if (alert.severity == "SEVERE") RailwayRed.copy(alpha = 0.3f) else ColorDelayed.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            alert.routeName,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = ScotRailNavy
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (alert.severity == "SEVERE") RailwayRed else ColorDelayed)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(alert.severity, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Text("CAUSE: ${alert.cause}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Text(alert.description, style = MaterialTheme.typography.bodyMedium)

                    if (alert.replacementBusActive) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SaltireBlue.copy(alpha = 0.1f))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.DirectionsBus, null, tint = SaltireBlue, modifier = Modifier.size(16.dp))
                            Text("REPLACEMENT BUSES DEPLOYED", color = SaltireBlue, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = {
                            selectedDisruptionForReplanning = alert
                            showReplannerWizard = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ScotRailNavy),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Route, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("FIND ME ANOTHER WAY HOME")
                    }
                }
            }
        }
    }

    // --- Disruption Route Replanner Dialog Wizard ---
    if (showReplannerWizard && selectedDisruptionForReplanning != null) {
        val alert = selectedDisruptionForReplanning!!
        AlertDialog(
            onDismissRequest = { showReplannerWizard = false },
            confirmButton = {
                Button(onClick = { showReplannerWizard = false }, colors = ButtonDefaults.buttonColors(containerColor = ScotRailNavy)) {
                    Text("ACCEPT ALTERNATIVE")
                }
            },
            title = {
                Text("DISRUPTION REPLANNER ALTERNATIVES", fontWeight = FontWeight.Bold, color = ScotRailNavy)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("We've recalculated alternative routes for: ${alert.routeName}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                    // Option 1: Next available train
                    ReplannerOption(
                        title = "1. Next available train service",
                        desc = "Currently on time, departing in 18 minutes from Platform 6.",
                        isConfirmed = true,
                        icon = Icons.Default.Train
                    )

                    // Option 2: Replacement bus details
                    if (alert.replacementBusActive) {
                        ReplannerOption(
                            title = "2. Replacement Bus Service",
                            desc = "Running every 20 minutes from the front forecourt stance 2. Confirmed rail ticket accepted.",
                            isConfirmed = true,
                            icon = Icons.Default.DirectionsBus
                        )
                    }

                    // Option 3: Walking diversion
                    ReplannerOption(
                        title = "3. Walking link to alternate platform",
                        desc = "12 min walking link connection recommended between terminals.",
                        isConfirmed = false,
                        icon = Icons.Default.DirectionsWalk
                    )
                }
            }
        )
    }
}

@Composable
fun ReplannerOption(
    title: String,
    desc: String,
    isConfirmed: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(icon, null, tint = SaltireBlue, modifier = Modifier.size(16.dp))
                    Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background((if (isConfirmed) ColorOnTime else Color.Gray).copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isConfirmed) "CONFIRMED" else "INFO ONLY",
                        color = if (isConfirmed) ColorOnTime else Color.Gray,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
    }
}
