package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class RailRepository(
    private val ticketDao: TicketDao,
    private val passportDao: PassportDao,
    private val favoriteRouteDao: FavoriteRouteDao,
    private val recentSearchDao: RecentSearchDao
) {

    // --- Local DB Operations ---

    val allTickets: Flow<List<TicketEntity>> = ticketDao.getAllTickets()
    val visitedStations: Flow<List<PassportStationEntity>> = passportDao.getVisitedStations()
    val favoriteRoutes: Flow<List<FavoriteRouteEntity>> = favoriteRouteDao.getAllFavorites()
    val recentSearches: Flow<List<RecentSearchEntity>> = recentSearchDao.getRecentSearches()

    suspend fun insertTicket(ticket: TicketEntity) = ticketDao.insertTicket(ticket)
    suspend fun updateTicket(ticket: TicketEntity) = ticketDao.updateTicket(ticket)
    suspend fun deleteTicket(ticket: TicketEntity) = ticketDao.deleteTicket(ticket)
    suspend fun clearAllTickets() = ticketDao.clearAll()

    suspend fun visitStation(stationName: String) {
        val lastVisited = System.currentTimeMillis()
        passportDao.insertVisitedStation(PassportStationEntity(stationName, 1, lastVisited))
    }
    suspend fun clearPassport() = passportDao.clearAll()

    suspend fun insertFavorite(origin: String, destination: String) {
        favoriteRouteDao.insertFavorite(FavoriteRouteEntity(origin = origin, destination = destination))
    }
    suspend fun removeFavorite(origin: String, destination: String) {
        favoriteRouteDao.deleteFavoriteByRoute(origin, destination)
    }
    fun isFavorite(origin: String, destination: String): Flow<Int> = favoriteRouteDao.isFavorite(origin, destination)

    suspend fun insertRecentSearch(origin: String, destination: String) {
        recentSearchDao.insertSearch(RecentSearchEntity(origin = origin, destination = destination))
    }
    suspend fun clearRecentSearches() = recentSearchDao.clearAll()

    // --- Simulated Scottish Network Data ---

    val stations = listOf(
        RailStation("Edinburgh Waverley", "EDB", 55.9520f, -3.1890f, description = "Scotland's second busiest station, situated in a valley between the Old and New Towns of Edinburgh.", busConnections = "Airlink 100 from Waverley Bridge, local buses on Princes St"),
        RailStation("Glasgow Queen Street", "GLQ", 55.8625f, -4.2510f, description = "The gateway to the North and East of Scotland, fully modernised with a stunning glass facade overlooking George Square.", busConnections = "Buchanan Bus Station is a 5-minute walk, Airport bus 500 stops nearby"),
        RailStation("Haymarket", "HYM", 55.9455f, -3.2185f, description = "A major interchange station in the west end of Edinburgh, key for commuters.", busConnections = "Tram line and major bus routes stop directly outside"),
        RailStation("Falkirk High", "FKK", 55.9920f, -3.7840f, description = "A busy commuter station on the Edinburgh-Glasgow main line."),
        RailStation("Linlithgow", "LIN", 55.9760f, -3.6000f, description = "A historic station serving Linlithgow Palace, birthplace of Mary Queen of Scots."),
        RailStation("Polmont", "PLT", 55.9890f, -3.7140f, description = "Serves the large village of Polmont and surrounding commuter area."),
        RailStation("Croy", "CRO", 55.9550f, -4.0410f, description = "Important park-and-ride station serving Cumbernauld and Kilsyth."),
        RailStation("Stirling", "STG", 56.1190f, -3.9350f, description = "A historic station at the foot of Stirling Castle, serving the Gateway to the Highlands."),
        RailStation("Perth", "PTH", 56.3910f, -3.4400f, description = "A grand Victorian railway junction linking the Central Belt to the Highlands and Dundee."),
        RailStation("Dundee", "DEE", 56.4570f, -2.9730f, description = "A modern waterfront station located directly across from the V&A Dundee museum.", busConnections = "Local bus interchange directly in front"),
        RailStation("Aberdeen", "ABD", 57.1430f, -2.0990f, description = "The Granite City's key rail terminus, integrated with Union Square shopping center.", busConnections = "Direct links to ferries to Orkney and Shetland"),
        RailStation("Inverness", "INV", 57.4800f, -4.2230f, description = "The capital of the Highlands rail terminus, connecting to the scenic far north lines."),
        RailStation("Fort William", "FTW", 56.8205f, -5.1050f, description = "A scenic Highlands terminus located at the base of Ben Nevis.", busConnections = "Highland bus terminal adjacent"),
        RailStation("Oban", "OBN", 56.4125f, -5.4740f, description = "Gateway to the Isles, with train tracks terminating right next to the CalMac ferry terminal."),
        RailStation("Ayr", "AYR", 55.4590f, -4.6240f, description = "A busy coastal terminal serving South Ayrshire and links to ferry ports."),
        RailStation("Kilmarnock", "KMK", 55.6105f, -4.4965f, description = "A major station in East Ayrshire serving rich industrial and social history.")
    )

    fun getStationByCode(code: String): RailStation? {
        return stations.find { it.code.uppercase() == code.uppercase() }
    }

    fun getStationByName(name: String): RailStation? {
        return stations.find { it.name.lowercase() == name.lowercase() }
    }

    // High fidelity dynamic train simulation
    fun getSimulatedTrainServices(): List<TrainService> {
        val calendar = Calendar.getInstance()
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMin = calendar.get(Calendar.MINUTE)

        return listOf(
            TrainService(
                serviceId = "SR258",
                departureTime = String.format("%02d:42", currentHour),
                origin = "Edinburgh Waverley",
                destination = "Glasgow Queen Street",
                finalDestination = "Glasgow Queen Street",
                status = "ON TIME",
                platform = "4",
                expectedArrival = String.format("%02d:31", (currentHour + 1) % 24),
                trainType = "Class 385 eExpress",
                stops = listOf(
                    RouteStop("Edinburgh Waverley", String.format("%02d:42", currentHour), isCompleted = true),
                    RouteStop("Haymarket", String.format("%02d:46", currentHour)),
                    RouteStop("Linlithgow", String.format("%02d:58", currentHour)),
                    RouteStop("Falkirk High", String.format("%02d:06", (currentHour + 1) % 24)),
                    RouteStop("Polmont", String.format("%02d:12", (currentHour + 1) % 24)),
                    RouteStop("Croy", String.format("%02d:20", (currentHour + 1) % 24)),
                    RouteStop("Glasgow Queen Street", String.format("%02d:31", (currentHour + 1) % 24))
                ),
                progressPercent = (currentMin / 60f)
            ),
            TrainService(
                serviceId = "SR104",
                departureTime = String.format("%02d:47", currentHour),
                origin = "Edinburgh Waverley",
                destination = "Stirling",
                finalDestination = "Stirling",
                status = "ON TIME",
                platform = "7",
                expectedArrival = String.format("%02d:38", (currentHour + 1) % 24),
                trainType = "Class 170 Turbostar",
                stops = listOf(
                    RouteStop("Edinburgh Waverley", String.format("%02d:47", currentHour), isCompleted = true),
                    RouteStop("Haymarket", String.format("%02d:52", currentHour)),
                    RouteStop("Polmont", String.format("%02d:14", (currentHour + 1) % 24)),
                    RouteStop("Falkirk Grahamston", String.format("%02d:22", (currentHour + 1) % 24)),
                    RouteStop("Stirling", String.format("%02d:38", (currentHour + 1) % 24))
                )
            ),
            TrainService(
                serviceId = "SR882",
                departureTime = String.format("%02d:55", currentHour),
                origin = "Edinburgh Waverley",
                destination = "Aberdeen",
                finalDestination = "Aberdeen",
                status = "DELAYED",
                delayedMinutes = 5,
                platform = "11",
                expectedArrival = String.format("%02d:12", (currentHour + 2) % 24),
                trainType = "Inter7City High Speed Train",
                delayReason = "Signal faults near Kirkcaldy",
                stops = listOf(
                    RouteStop("Edinburgh Waverley", String.format("%02d:55", currentHour)),
                    RouteStop("Haymarket", String.format("%02d:59", currentHour)),
                    RouteStop("Perth", String.format("%02d:58", (currentHour + 1) % 24)),
                    RouteStop("Dundee", String.format("%02d:24", (currentHour + 1) % 24)),
                    RouteStop("Aberdeen", String.format("%02d:12", (currentHour + 2) % 24))
                ),
                connectionsRisk = true
            ),
            TrainService(
                serviceId = "SR310",
                departureTime = String.format("%02d:02", (currentHour + 1) % 24),
                origin = "Edinburgh Waverley",
                destination = "Dundee",
                finalDestination = "Dundee",
                status = "BOARDING",
                platform = "2",
                expectedArrival = String.format("%02d:18", (currentHour + 2) % 24),
                stops = listOf(
                    RouteStop("Edinburgh Waverley", String.format("%02d:02", (currentHour + 1) % 24)),
                    RouteStop("Dundee", String.format("%02d:18", (currentHour + 2) % 24))
                )
            ),
            TrainService(
                serviceId = "SR412",
                departureTime = String.format("%02d:15", (currentHour + 1) % 24),
                origin = "Glasgow Queen Street",
                destination = "Fort William",
                finalDestination = "Fort William",
                status = "ON TIME",
                platform = "1",
                expectedArrival = String.format("%02d:45", (currentHour + 4) % 24),
                trainType = "Class 156 Super Sprinter",
                stops = listOf(
                    RouteStop("Glasgow Queen Street", String.format("%02d:15", (currentHour + 1) % 24)),
                    RouteStop("Croy", String.format("%02d:30", (currentHour + 1) % 24)),
                    RouteStop("Dumbarton Central", String.format("%02d:55", (currentHour + 1) % 24)),
                    RouteStop("Loch Lomond", String.format("%02d:20", (currentHour + 2) % 24)),
                    RouteStop("Fort William", String.format("%02d:45", (currentHour + 4) % 24))
                )
            ),
            TrainService(
                serviceId = "SR550",
                departureTime = String.format("%02d:30", (currentHour + 1) % 24),
                origin = "Glasgow Queen Street",
                destination = "Oban",
                finalDestination = "Oban",
                status = "CANCELLED",
                platform = "3",
                expectedArrival = String.format("%02d:35", (currentHour + 4) % 24),
                delayReason = "Landslip near Falls of Cruachan due to heavy rainfall",
                stops = listOf(
                    RouteStop("Glasgow Queen Street", String.format("%02d:30", (currentHour + 1) % 24)),
                    RouteStop("Oban", String.format("%02d:35", (currentHour + 4) % 24))
                )
            )
        )
    }

    // Scenic Tourism journeys
    val scenicJourneys = listOf(
        ScenicJourney(
            id = "scenic_west_highland",
            name = "The West Highland Line",
            regions = listOf("Highlands", "Argyll & Bute"),
            description = "Consistently voted one of the most beautiful rail journeys in the world. Traverse the spectacular Glenfinnan Viaduct, cross Rannoch Moor, and skim the edge of Loch Lomond.",
            startStation = "Glasgow Queen Street",
            endStation = "Fort William",
            onwardFerryOrBus = "Ferry to Isle of Skye / Armadale from Mallaig terminal, direct connections at end of line.",
            imagePrompt = "The West Highland Line train traversing the famous Glenfinnan Viaduct surrounded by green hills and Loch Shiel",
            landmarks = listOf(
                ScenicLandmark("Loch Lomond", 25.5f, "Skirting the gorgeous western shores of Britain's largest surface-area freshwater loch.", "First opened to rail in 1894, cutting through hard granite.", "Sit on the left for magnificent loch views.", "LOCH"),
                ScenicLandmark("Rannoch Moor", 72.1f, "An immense, untamed wilderness of peat bogs, lochans and heather-clad moorland entirely inaccessible by road.", "The tracks were laid directly over a mattress of brushwood and soil.", "The loneliest train station in Britain, look out for wild red deer.", "MOUNTAIN"),
                ScenicLandmark("Glenfinnan Viaduct", 110.0f, "A historic concrete arch viaduct curving gracefully with 21 spans over the Glenfinnan valley.", "Built by Sir Robert McAlpine, affectionately known as 'Concrete Bob' in 1898.", "Get your camera ready on the left side as the train curves around the horseshoe.", "BRIDGE")
            )
        ),
        ScenicJourney(
            id = "scenic_highland_main",
            name = "The Highland Main Line",
            regions = listOf("Perthshire", "Highlands"),
            description = "Travel from the lowlands of Edinburgh through the heart of the Cairngorms National Park up to the Highland Capital of Inverness.",
            startStation = "Edinburgh Waverley",
            endStation = "Inverness",
            onwardFerryOrBus = "Highland explorer buses and Inverness airport connectors.",
            imagePrompt = "Scenic Highlands train running through autumn colored trees with the Cairngorm mountains in the background",
            landmarks = listOf(
                ScenicLandmark("Forth Bridge", 9.5f, "The world-famous red cantilever railway bridge over the Firth of Forth, a UNESCO World Heritage site.", "Opened in 1890, it uses 53,000 tonnes of steel and 6.5 million rivets.", "Look down at the water 150 feet below. Truly breathtaking.", "BRIDGE"),
                ScenicLandmark("Pass of Killiecrankie", 62.4f, "A deep, heavily wooded gorge where the Jacobite army fought government forces in 1689.", "The railway was forced to construct a 460-yard tunnel and high retaining walls here.", "A stunning gorge of oak and beech trees, especially vibrant in autumn.", "MOUNTAIN"),
                ScenicLandmark("Cairngorms National Park", 88.0f, "High-altitude views of the magnificent Cairngorms range, home to Britain's highest rail summit at Druimuachdar Pass.", "The railway crosses the summit at 1,484 feet above sea level.", "You are at the highest point of Scotland's active passenger rail network.", "MOUNTAIN")
            )
        )
    )

    // Disruptions feed
    val disruptions = listOf(
        DisruptionAlert(
            id = "DIS001",
            routeName = "Glasgow to Oban / Mallaig",
            severity = "SEVERE",
            cause = "Heavy Rain & Landslip",
            description = "A landslip near Falls of Cruachan has blocked the line. Track teams are on site, but trains are currently suspended. Bus replacements are active between Dalmally and Oban.",
            affectedTrains = listOf("SR550"),
            replacementBusActive = true,
            isWeatherRelated = true
        ),
        DisruptionAlert(
            id = "DIS002",
            routeName = "Firth of Forth Crossing",
            severity = "MINOR",
            cause = "High Winds",
            description = "High wind speed restrictions are in place over the Forth Bridge. Trains are running at reduced speeds, causing minor delays of up to 10 minutes on services between Edinburgh and Dundee/Aberdeen.",
            affectedTrains = listOf("SR882"),
            replacementBusActive = false,
            isWeatherRelated = true
        )
    )

    // Season ticket rates calculator
    fun calculateSeasonTicket(origin: String, destination: String): SeasonTicketCalculation {
        // Simple mock calculations based on a representative commuter fare
        val baseSingle = when {
            origin.contains("Edinburgh") && destination.contains("Glasgow") -> 14.20
            origin.contains("Glasgow") && destination.contains("Edinburgh") -> 14.20
            else -> 8.50
        }

        val weekly = baseSingle * 5 * 1.5 // 5 return trips, with standard bulk discount (e.g. pay for 7.5 singles)
        val monthly = weekly * 3.8 // Pay for 3.8 weeks
        val annual = monthly * 10.0 // 12 months for price of 10
        val flexi = baseSingle * 10 * 0.9 // 10 pack (10% off)

        val dailyCommuteCost = baseSingle * 2
        val annualSavingsVsDaily = (dailyCommuteCost * 5 * 48) - annual // 48 working weeks

        return SeasonTicketCalculation(
            route = "$origin ↔ $destination",
            weeklyCost = weekly,
            monthlyCost = monthly,
            annualCost = annual,
            flexiCost = flexi,
            dailyCommuteCost = dailyCommuteCost,
            annualSavingsVsDaily = annualSavingsVsDaily
        )
    }
}
