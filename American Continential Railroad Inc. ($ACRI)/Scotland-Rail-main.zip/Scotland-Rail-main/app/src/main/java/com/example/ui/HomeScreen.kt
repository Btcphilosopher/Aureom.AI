package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TrainService
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier,
    onNavigateToService: (TrainService) -> Unit
) {
    val origin by viewModel.originInput.collectAsState()
    val destination by viewModel.destinationInput.collectAsState()
    val favoriteRoutes by viewModel.favoriteRoutes.collectAsState()
    val recentSearches by viewModel.recentSearches.collectAsState()
    val departures by viewModel.stationDepartures.collectAsState()
    val tickets by viewModel.tickets.collectAsState()
    val activeDisruptions = viewModel.disruptions

    var showOriginSelect by remember { mutableStateOf(false) }
    var showDestSelect by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // --- Premium Scotland Welcome Banner ---
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = ScotRailNavy,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "SCOTLAND'S RAILWAY",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SaltireBlue.copy(alpha = 0.9f),
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "Welcome to your digital rail companion",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 32.sp
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.15f))
                            .clickable { viewModel.toggleOfflineMode() }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (viewModel.isOfflineMode.collectAsState().value) Icons.Default.CloudOff else Icons.Default.CloudQueue,
                            contentDescription = "Connection Mode",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (viewModel.isOfflineMode.collectAsState().value) "Offline Mode (Cached Data)" else "Live Operations Connected",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // --- WHERE ARE YOU GOING? Search Hub ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "WHERE ARE YOU GOING?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ScotRailNavy,
                        letterSpacing = 0.5.sp
                    )

                    // Origin Input Row
                    Box {
                        OutlinedCard(
                            onClick = { showOriginSelect = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.TripOrigin, contentDescription = "From", tint = SaltireBlue)
                                Column {
                                    Text("FROM", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text(origin, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    // Pivot Button & Connection line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = { viewModel.swapSearchInputs() },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Icon(
                                Icons.Default.SwapVert,
                                contentDescription = "Swap Locations",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    // Destination Input Row
                    Box {
                        OutlinedCard(
                            onClick = { showDestSelect = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.Place, contentDescription = "To", tint = RailwayRed)
                                Column {
                                    Text("TO", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text(destination, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    // Search Button
                    Button(
                        onClick = {
                            viewModel.searchJourneys()
                            viewModel.setTab("planner")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ScotRailNavy),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                        Text("FIND TRAINS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // --- RECENT / FAVORITE ROUTES ---
        if (favoriteRoutes.isNotEmpty()) {
            item {
                Text(
                    text = "FAVOURITE ROUTES",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    favoriteRoutes.take(3).forEach { fav ->
                        Card(
                            onClick = {
                                viewModel.updateSearchInputs(fav.origin, fav.destination)
                                viewModel.searchJourneys()
                                viewModel.setTab("planner")
                            },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = ColorDelayed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(fav.origin.split(" ").first(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                Text(fav.destination.split(" ").first(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        // --- MY NEXT JOURNEY (Next Active Ticket) ---
        val upcomingTickets = tickets.filter { !it.isActivated }
        if (upcomingTickets.isNotEmpty()) {
            item {
                val nextTicket = upcomingTickets.first()
                Text(
                    text = "MY NEXT JOURNEY",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    onClick = { viewModel.setTab("tickets") },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = nextTicket.ticketType.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = SaltireBlue,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(nextTicket.origin, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, modifier = Modifier.size(14.dp).padding(horizontal = 4.dp), tint = Color.Gray)
                                Text(nextTicket.destination, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("${nextTicket.date} at ${nextTicket.time}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        IconButton(
                            onClick = { viewModel.activateTicket(nextTicket) },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = RailwayRed.copy(alpha = 0.1f))
                        ) {
                            Icon(Icons.Default.QrCode, contentDescription = "Open ticket", tint = RailwayRed)
                        }
                    }
                }
            }
        }

        // --- LIVE DISRUPTIONS SUMMARY ---
        item {
            val hasSevere = activeDisruptions.any { it.severity == "SEVERE" }
            Card(
                onClick = { viewModel.setTab("departures") },
                colors = CardDefaults.cardColors(
                    containerColor = if (hasSevere) RailwayRed.copy(alpha = 0.08f) else ColorOnTime.copy(alpha = 0.05f)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, if (hasSevere) RailwayRed.copy(alpha = 0.3f) else ColorOnTime.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (hasSevere) RailwayRed else ColorOnTime),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (hasSevere) Icons.Default.Warning else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (hasSevere) "LIVE DISRUPTIONS ACTIVE" else "NETWORK RUNNING SMOOTHLY",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (hasSevere) RailwayRed else ColorOnTime
                        )
                        Text(
                            text = if (hasSevere) "Delays and alternative services active. Tap to view disruption desk." else "91% of services on time. Clear skies across central Scotland.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color.Gray)
                }
            }
        }

        // --- DEPARTURES FROM NEARBY ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DEPARTURES FROM NEARBY",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                TextButton(onClick = { viewModel.setTab("departures") }) {
                    Text("FULL BOARD", color = SaltireBlue)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            ElevatedCard(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Edinburgh Waverley Board",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.Gray,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    departures.take(3).forEach { dep ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToService(dep) }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = dep.departureTime,
                                        fontWeight = FontWeight.ExtraBold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = ScotRailNavy
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = dep.destination,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Text(
                                    text = "Platform ${dep.platform} • ${dep.trainType}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                            StatusChip(status = dep.status, delayedMinutes = dep.delayedMinutes)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                    }
                }
            }
        }
    }

    // --- Destination / Origin selectors dialog / list simulated ---
    if (showOriginSelect) {
        LocationSelectorDialog(
            title = "Choose Origin Station",
            stations = viewModel.stations,
            onDismiss = { showOriginSelect = false },
            onSelect = {
                viewModel.originInput.value = it.name
                showOriginSelect = false
            }
        )
    }

    if (showDestSelect) {
        LocationSelectorDialog(
            title = "Choose Destination Station",
            stations = viewModel.stations,
            onDismiss = { showDestSelect = false },
            onSelect = {
                viewModel.destinationInput.value = it.name
                showDestSelect = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationSelectorDialog(
    title: String,
    stations: List<com.example.model.RailStation>,
    onDismiss: () -> Unit,
    onSelect: (com.example.model.RailStation) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = { Text(title, fontWeight = FontWeight.Bold, color = ScotRailNavy) },
        text = {
            Column(modifier = Modifier.heightIn(max = 400.dp)) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(stations) { station ->
                        ListItem(
                            headlineContent = { Text(station.name, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Code: ${station.code}", color = Color.Gray) },
                            leadingContent = { Icon(Icons.Default.Train, contentDescription = null, tint = SaltireBlue) },
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelect(station) }
                        )
                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                    }
                }
            }
        }
    )
}

@Composable
fun StatusChip(status: String, delayedMinutes: Int) {
    val color = when (status.uppercase()) {
        "ON TIME" -> ColorOnTime
        "BOARDING" -> ColorBoarding
        "DEPARTED" -> Color.Gray
        "DELAYED" -> ColorDelayed
        "CANCELLED" -> ColorCancelled
        else -> ColorPlatform
    }
    val text = if (status == "DELAYED") "${delayedMinutes}m Late" else status

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.1f))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.3f)), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
