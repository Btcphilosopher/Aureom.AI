package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TicketEntity
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@Composable
fun WalletScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val tickets by viewModel.tickets.collectAsState()
    val smartcardStatus by viewModel.smartcardStatus.collectAsState()
    val smartcardProducts by viewModel.smartcardProducts.collectAsState()
    val smartcardExpiry by viewModel.smartcardExpiry.collectAsState()
    val smartcardHistory by viewModel.smartcardHistory.collectAsState()

    val seasonOrigin by viewModel.seasonOrigin.collectAsState()
    val seasonDestination by viewModel.seasonDestination.collectAsState()
    val calculatedSeason by viewModel.calculatedSeason.collectAsState()

    var activeWalletSubTab by remember { mutableStateOf("wallet") } // wallet, smartcard, calculator
    var selectedTicketForViewing by remember { mutableStateOf<TicketEntity?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sub-Tab Row
        TabRow(
            selectedTabIndex = when (activeWalletSubTab) {
                "wallet" -> 0
                "smartcard" -> 1
                "calculator" -> 2
                else -> 0
            },
            containerColor = ScotRailNavy,
            contentColor = Color.White
        ) {
            Tab(
                selected = activeWalletSubTab == "wallet",
                onClick = { activeWalletSubTab = "wallet" },
                text = { Text("MY WALLET", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Wallet, null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = activeWalletSubTab == "smartcard",
                onClick = { activeWalletSubTab = "smartcard" },
                text = { Text("SMARTCARD", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.CreditCard, null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = activeWalletSubTab == "calculator" || calculatedSeason == null,
                onClick = {
                    activeWalletSubTab = "calculator"
                    viewModel.calculateSeasonPrice()
                },
                text = { Text("SEASON CALCULATOR", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                icon = { Icon(Icons.Default.Calculate, null, modifier = Modifier.size(16.dp)) }
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeWalletSubTab) {
                "wallet" -> TicketWalletView(
                    tickets = tickets,
                    onSelectTicket = { selectedTicketForViewing = it },
                    onActivate = { viewModel.activateTicket(it) }
                )
                "smartcard" -> SmartcardView(
                    status = smartcardStatus,
                    products = smartcardProducts,
                    expiry = smartcardExpiry,
                    history = smartcardHistory
                )
                "calculator" -> SeasonCalculatorView(
                    origin = seasonOrigin,
                    destination = seasonDestination,
                    calculation = calculatedSeason,
                    onOriginChange = { viewModel.seasonOrigin.value = it },
                    onDestChange = { viewModel.seasonDestination.value = it },
                    onCalculate = { viewModel.calculateSeasonPrice() }
                )
            }
        }
    }

    // --- Ticket Fullscreen Code View ---
    if (selectedTicketForViewing != null) {
        val t = selectedTicketForViewing!!
        AlertDialog(
            onDismissRequest = { selectedTicketForViewing = null },
            confirmButton = {
                Button(onClick = { selectedTicketForViewing = null }, colors = ButtonDefaults.buttonColors(containerColor = ScotRailNavy)) {
                    Text("CLOSE")
                }
            },
            title = {
                Text(
                    text = "DIGITAL mTICKET",
                    fontWeight = FontWeight.Bold,
                    color = ScotRailNavy,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Fake Ticket Receipt styled ticket card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(2.dp, SaltireBlue),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "SCOTLAND RAILWAY mTICKET",
                                style = MaterialTheme.typography.labelSmall,
                                color = SaltireBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                                Text(t.origin, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, modifier = Modifier.size(16.dp).padding(horizontal = 4.dp))
                                Text(t.destination, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = Color.LightGray)
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("TYPE: ${t.ticketType.uppercase()}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                Text("PRICE: £${String.format("%.2f", t.price)}", style = MaterialTheme.typography.labelMedium, color = ColorOnTime, fontWeight = FontWeight.Bold)
                            }
                            Text("DATE: ${t.date} | DEPART: ${t.time}", style = MaterialTheme.typography.bodySmall, color = Color.Gray, modifier = Modifier.padding(top = 4.dp))
                        }
                    }

                    // QR / Barcode representation
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, Color.LightGray), RoundedCornerShape(12.dp))
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (t.isActivated) {
                            // Active barcode representation (lines)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .padding(horizontal = 24.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                val barColors = listOf(0.4f, 0.8f, 0.2f, 0.9f, 0.3f, 0.6f, 0.1f, 0.8f, 0.2f, 0.7f, 0.4f)
                                barColors.forEach { ratio ->
                                    Box(
                                        modifier = Modifier
                                            .width((ratio * 12).dp)
                                            .fillMaxHeight()
                                            .background(Color.Black)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .width(4.dp)
                                            .fillMaxHeight()
                                            .background(Color.White)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = t.scanCode,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ColorOnTime.copy(alpha = 0.15f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, null, tint = ColorOnTime, modifier = Modifier.size(16.dp))
                                Text("TICKET ACTIVE & READY", color = ColorOnTime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        } else {
                            // Offline or inactive barcode representation
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .background(Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = Color.Gray)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("Barcode Hidden", fontWeight = FontWeight.Bold, color = Color.Gray)
                                    Text("Activate ticket before boarding", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    viewModel.activateTicket(t)
                                    selectedTicketForViewing = t.copy(isActivated = true)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RailwayRed),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Text("ACTIVATE TICKET NOW")
                            }
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun TicketWalletView(
    tickets: List<TicketEntity>,
    onSelectTicket: (TicketEntity) -> Unit,
    onActivate: (TicketEntity) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (tickets.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().padding(top = 40.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Wallet, contentDescription = null, modifier = Modifier.size(48.dp), tint = SaltireBlue)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Your ticket wallet is empty", fontWeight = FontWeight.Bold)
                        Text("Search and purchase tickets inside the Journey Planner.", color = Color.Gray, textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            items(tickets) { ticket ->
                Card(
                    onClick = { onSelectTicket(ticket) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (ticket.isActivated) Color.White else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    border = BorderStroke(1.dp, if (ticket.isActivated) ColorOnTime else Color.LightGray.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = if (ticket.isActivated) ColorOnTime else Color.Gray)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = ticket.ticketType.uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (ticket.isActivated) ColorOnTime else Color.Gray
                                )
                            }
                            if (ticket.isActivated) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(ColorOnTime.copy(alpha = 0.1f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(ColorOnTime))
                                    Text("ACTIVE", color = ColorOnTime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(ColorDelayed.copy(alpha = 0.1f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("INACTIVE", color = ColorDelayed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(ticket.origin, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null, modifier = Modifier.padding(horizontal = 6.dp).size(16.dp), tint = Color.Gray)
                                    Text(ticket.destination, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Travel Date: ${ticket.date} at ${ticket.time} | Price: £${String.format("%.2f", ticket.price)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }

                        // Activation button if not activated
                        if (!ticket.isActivated) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    onActivate(ticket)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = RailwayRed),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ACTIVATE TICKET", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SmartcardView(
    status: String,
    products: List<String>,
    expiry: String,
    history: List<String>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Smartcard representation
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ScotRailNavy),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("SCOTLAND SMARTCARD", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(ColorOnTime.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(status.uppercase(), color = ColorOnTime, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Column {
                        Text("CARD HOLDER", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                        Text("THOMAS CAMPBELL", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("CARD NUMBER", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                            Text("633597 1024589 45", color = Color.White, fontFamily = FontFamily.Monospace)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("EXPIRES", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                            Text(expiry, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Active Products Section
        item {
            Text("WHAT PRODUCTS DO I HAVE?", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    products.forEach { prod ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CheckCircle, null, tint = ColorOnTime)
                            Text(prod, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        // History Section
        item {
            Text("RECENT TRAVEL HISTORY", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    history.forEach { hist ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(hist, style = MaterialTheme.typography.bodyMedium)
                            Text("VALIDATED", color = ColorOnTime, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                    }
                }
            }
        }
    }
}

@Composable
fun SeasonCalculatorView(
    origin: String,
    destination: String,
    calculation: com.example.model.SeasonTicketCalculation?,
    onOriginChange: (String) -> Unit,
    onDestChange: (String) -> Unit,
    onCalculate: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("COMPARE SEASON TICKET COSTS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ScotRailNavy)

                    OutlinedTextField(
                        value = origin,
                        onValueChange = onOriginChange,
                        label = { Text("FROM") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = destination,
                        onValueChange = onDestChange,
                        label = { Text("TO") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = onCalculate,
                        colors = ButtonDefaults.buttonColors(containerColor = ScotRailNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CALCULATE & COMPARE")
                    }
                }
            }
        }

        if (calculation != null) {
            item {
                Text("RECOMMENDED PRODUCTS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Weekly rates
                    SeasonRateCard("Weekly Season", calculation.weeklyCost, "Valid for 7 days consecutive travel")
                    SeasonRateCard("Monthly Season", calculation.monthlyCost, "Valid for 1 calendar month")
                    SeasonRateCard("Annual Season (Best Value)", calculation.annualCost, "Best value! Equivalent of 12 months for the price of 10")
                    SeasonRateCard("10-Journey Flexipass", calculation.flexiCost, "Valid for 10 single journeys inside 28 days")

                    // Annual Savings highlight card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ColorOnTime.copy(alpha = 0.08f)),
                        border = BorderStroke(1.dp, ColorOnTime.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("ANNUAL COMMUTE SAVINGS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = ColorOnTime)
                            Text("£${String.format("%.2f", calculation.annualSavingsVsDaily)} SAVED", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = ColorOnTime)
                            Text("compared to buying standard daily anytime return tickets across 48 working weeks.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SeasonRateCard(title: String, price: Double, desc: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Text("£${String.format("%.2f", price)}", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, color = ScotRailNavy)
        }
    }
}
