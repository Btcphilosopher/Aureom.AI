package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SaltireBlue,
    secondary = ScotRailNavy,
    tertiary = RailwayRed,
    background = RailDarkBg,
    surface = RailDarkSurface,
    onPrimary = RailDarkOnSurface,
    onSecondary = RailDarkOnSurface,
    onTertiary = RailDarkOnSurface,
    onBackground = RailDarkOnSurface,
    onSurface = RailDarkOnSurface,
    onSurfaceVariant = RailDarkOnSurfaceVariant
  )

private val LightColorScheme =
  lightColorScheme(
    primary = ScotRailNavy,
    secondary = SaltireBlue,
    tertiary = RailwayRed,
    background = RailLightBg,
    surface = RailLightSurface,
    onPrimary = RailLightSurface,
    onSecondary = RailLightSurface,
    onTertiary = RailLightSurface,
    onBackground = RailLightOnSurface,
    onSurface = RailLightOnSurface,
    onSurfaceVariant = RailLightOnSurfaceVariant
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Use our gorgeous signature Scottish branding by default instead of general system colors
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
