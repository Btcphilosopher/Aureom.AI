package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ScenicJourney
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@Composable
fun ExploreScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val scenicRoutes = viewModel.scenicRoutes
    val selectedScenic by viewModel.selectedScenicJourney.collectAsState()
    val visitedStations by viewModel.visitedStations.collectAsState()

    var activeExploreTab by remember { mutableStateOf("scenic") } // scenic, passport

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Headers
        TabRow(
            selectedTabIndex = if (activeExploreTab == "scenic") 0 else 1,
            containerColor = ScotRailNavy,
            contentColor = Color.White
        ) {
            Tab(
                selected = activeExploreTab == "scenic",
                onClick = { activeExploreTab = "scenic" },
                text = { Text("SCENIC ROUTES", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Landscape, null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = activeExploreTab == "passport",
                onClick = { activeExploreTab = "passport" },
                text = { Text("TRAVEL JOURNAL", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Book, null, modifier = Modifier.size(16.dp)) }
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeExploreTab) {
                "scenic" -> ScenicRoutesView(
                    routes = scenicRoutes,
                    selectedScenic = selectedScenic,
                    onSelectRoute = { viewModel.selectedScenicJourney.value = it }
                )
                "passport" -> TravelPassportView(
                    visited = visitedStations,
                    allStations = viewModel.stations,
                    onStamp = { viewModel.visitStation(it) },
                    onReset = { viewModel.clearPassport() }
                )
            }
        }
    }
}

@Composable
fun ScenicRoutesView(
    routes: List<ScenicJourney>,
    selectedScenic: ScenicJourney?,
    onSelectRoute: (ScenicJourney) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "EXPLORE SCOTLAND BY RAIL",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = ScotRailNavy
            )
            Text(
                "Let the railway guide you through valleys, peaks, castles, and coastal horizons.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // Horizontal Selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                routes.forEach { route ->
                    val isSelected = selectedScenic?.id == route.id
                    Card(
                        onClick = { onSelectRoute(route) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) ScotRailNavy else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                route.name,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isSelected) Color.White else ScotRailNavy
                            )
                            Text(
                                "${route.startStation} to ${route.endStation}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) Color.LightGray else Color.Gray
                            )
                        }
                    }
                }
            }
        }

        if (selectedScenic != null) {
            val r = selectedScenic

            // Journey Highlight Banner Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "JOURNEY DESCRIPTION",
                            style = MaterialTheme.typography.labelSmall,
                            color = SaltireBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = r.description,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Normal,
                            lineHeight = 22.sp
                        )

                        if (r.onwardFerryOrBus != null) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SaltireBlue.copy(alpha = 0.08f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.DirectionsBoat, null, tint = SaltireBlue)
                                    Text(
                                        text = r.onwardFerryOrBus,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SaltireBlue,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Landmarks list along route
            item {
                Text(
                    "SCENIC LANDMARKS & MILESTONES",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = ScotRailNavy
                )
                Spacer(modifier = Modifier.height(4.dp))
            }

            items(r.landmarks) { landmark ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                landmark.name,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.bodyLarge,
                                color = ScotRailNavy
                            )
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SaltireBlue.copy(alpha = 0.12f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = when (landmark.type) {
                                        "CASTLE" -> Icons.Default.Fort
                                        "LOCH" -> Icons.Default.Waves
                                        "BRIDGE" -> Icons.Default.Architecture
                                        else -> Icons.Default.FilterHdr
                                    },
                                    contentDescription = null,
                                    tint = SaltireBlue,
                                    modifier = Modifier.size(12.dp).align(Alignment.CenterVertically)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(landmark.type, color = SaltireBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(
                            landmark.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Default.History, null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                            Text(landmark.historyFact, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Default.CameraAlt, null, tint = RailwayRed, modifier = Modifier.size(16.dp))
                            Text(landmark.photoHint, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = RailwayRed)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TravelPassportView(
    visited: List<com.example.data.PassportStationEntity>,
    allStations: List<com.example.model.RailStation>,
    onStamp: (String) -> Unit,
    onReset: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Summary Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ScotRailNavy),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "SCOTLAND RAIL PASSPORT",
                        style = MaterialTheme.typography.labelSmall,
                        color = SaltireBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        "Track your footprints across Scotland's rail network. Stamp stations as you visit them.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        PassportStat("STATIONS", "${visited.size} / 350+")
                        PassportStat("ROUTES", "${if (visited.size > 2) 3 else 1} / 60+")
                        PassportStat("REGIONS", "${if (visited.size > 4) 4 else 2} / 12")
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("STAMP MY JOURNAL", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                TextButton(onClick = onReset) {
                    Text("CLEAR ALL", color = RailwayRed, fontSize = 12.sp)
                }
            }
        }

        items(allStations) { station ->
            val hasVisited = visited.any { it.stationName.uppercase() == station.name.uppercase() }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (hasVisited) ColorOnTime.copy(alpha = 0.05f) else MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (hasVisited) ColorOnTime.copy(alpha = 0.3f) else Color.LightGray.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (hasVisited) ColorOnTime else Color.LightGray.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (hasVisited) Icons.Default.Verified else Icons.Default.Place,
                                contentDescription = null,
                                tint = if (hasVisited) Color.White else Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(station.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text("Code: ${station.code}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                    }

                    if (!hasVisited) {
                        Button(
                            onClick = { onStamp(station.name) },
                            colors = ButtonDefaults.buttonColors(containerColor = ScotRailNavy),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("STAMP", fontSize = 11.sp)
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = ColorOnTime, modifier = Modifier.size(14.dp))
                            Text("STAMPED", color = ColorOnTime, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PassportStat(label: String, valStr: String) {
    Column {
        Text(label, color = Color.LightGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(valStr, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    }
}
