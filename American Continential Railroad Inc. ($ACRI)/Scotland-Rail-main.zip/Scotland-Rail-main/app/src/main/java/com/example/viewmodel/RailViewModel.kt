package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class RailViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = RailRepository(
        database.ticketDao(),
        database.passportDao(),
        database.favoriteRouteDao(),
        database.recentSearchDao()
    )

    // --- Station Search / Planning States ---
    val originInput = MutableStateFlow("Edinburgh Waverley")
    val destinationInput = MutableStateFlow("Glasgow Queen Street")
    val passengersCount = MutableStateFlow(1)
    val hasRailcard = MutableStateFlow(true)
    val travelDate = MutableStateFlow("Today")
    val travelTime = MutableStateFlow("09:42")

    // Filter modes
    val filterCheapest = MutableStateFlow(false)
    val filterFastest = MutableStateFlow(true)
    val filterFewestChanges = MutableStateFlow(false)
    val filterDirectOnly = MutableStateFlow(true)
    val filterAccessible = MutableStateFlow(false)
    val filterBikeFriendly = MutableStateFlow(false)

    // Simulated Active Results
    private val _plannedJourneys = MutableStateFlow<List<TrainService>>(emptyList())
    val plannedJourneys: StateFlow<List<TrainService>> = _plannedJourneys.asStateFlow()

    // --- Station Board / Departure Boards ---
    val selectedBoardStation = MutableStateFlow("Edinburgh Waverley")
    private val _stationDepartures = MutableStateFlow<List<TrainService>>(emptyList())
    val stationDepartures: StateFlow<List<TrainService>> = _stationDepartures.asStateFlow()

    // --- Detailed Service ---
    val selectedService = MutableStateFlow<TrainService?>(null)

    // --- Database-backed Flows ---
    val tickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val visitedStations: StateFlow<List<PassportStationEntity>> = repository.visitedStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteRoutes: StateFlow<List<FavoriteRouteEntity>> = repository.favoriteRoutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentSearches: StateFlow<List<RecentSearchEntity>> = repository.recentSearches
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Smartcard State ---
    val smartcardStatus = MutableStateFlow("Active")
    val smartcardProducts = MutableStateFlow(listOf("ScotRail 10-Journey Flexipass", "Edinburgh Zone 1-2 Monthly"))
    val smartcardExpiry = MutableStateFlow("15 SEP 2026")
    val smartcardHistory = MutableStateFlow(listOf("Edinburgh Waverley (14 AUG 08:31)", "Glasgow Queen St (14 AUG 17:15)", "Haymarket (12 AUG 08:45)"))

    // --- Tourism & Scenic Modes ---
    val scenicRoutes = repository.scenicJourneys
    val selectedScenicJourney = MutableStateFlow<ScenicJourney?>(repository.scenicJourneys.firstOrNull())
    val stations = repository.stations

    // --- Disruption Centre & Weather Feed ---
    val disruptions = repository.disruptions
    val localWeatherTemp = MutableStateFlow("14°C")
    val localWeatherCondition = MutableStateFlow("Scotch Mist & Showers")
    val localWeatherWindSpeed = MutableStateFlow("24 mph SW")
    val weatherWarnings = MutableStateFlow(listOf("Yellow Warning: High winds over Forth Crossing and east coast"))

    // --- Station Mode & Wayfinding Guide ---
    val stationModeActive = MutableStateFlow(false) // Triggered near EDB or GLQ
    val simulatedNearStation = MutableStateFlow("Edinburgh Waverley")
    val selectedWayfindingRoute = MutableStateFlow("Platform 4 → Princes St Exit")

    // --- Travel Assist state ---
    val assistStepFree = MutableStateFlow(false)
    val assistWheelchair = MutableStateFlow(false)
    val assistVisualImpairment = MutableStateFlow(false)
    val assistHearingImpairment = MutableStateFlow(false)
    val assistAnimal = MutableStateFlow(false)
    val assistStatus = MutableStateFlow("NONE") // NONE, REQUESTED, CONFIRMED, READY

    // --- Delay Repay States ---
    val selectedTicketForRepay = MutableStateFlow<TicketEntity?>(null)
    val repayClaimStatus = MutableStateFlow("NOT_STARTED") // NOT_STARTED, SUBMITTED, APPROVED
    val delayMinutesClaimed = MutableStateFlow(38)
    val refundAmountClaimed = MutableStateFlow(14.20)

    // --- Season Ticket Calculator State ---
    val seasonOrigin = MutableStateFlow("Edinburgh Waverley")
    val seasonDestination = MutableStateFlow("Glasgow Queen Street")
    val calculatedSeason = MutableStateFlow<SeasonTicketCalculation?>(null)

    // --- Network Live Operations View Stats ---
    val liveOpsTrainsActive = MutableStateFlow(142)
    val liveOpsOnTimeRatio = MutableStateFlow(91) // 91%
    val liveOpsDelayedCount = MutableStateFlow(9)
    val liveOpsCancelledCount = MutableStateFlow(1)
    val liveOpsRegionStatus = MutableStateFlow(mapOf(
        "NORTH" to "NORMAL",
        "CENTRAL" to "NORMAL",
        "WEST" to "MINOR DELAYS (Landslip)",
        "HIGHLANDS" to "NORMAL",
        "BORDERS" to "NORMAL"
    ))

    // --- Navigation Flow ---
    val isOfflineMode = MutableStateFlow(false) // toggle simulation
    val currentMainTab = MutableStateFlow("home") // home, planner, departures, tickets, explore, station, account

    init {
        // Pre-populate the local DB on launch if empty to make the app feel rich and realistic immediately
        viewModelScope.launch {
            repository.allTickets.first().let { currentList ->
                if (currentList.isEmpty()) {
                    // Pre-populate realistic Scottish tickets
                    repository.insertTicket(
                        TicketEntity(
                            origin = "Edinburgh Waverley",
                            destination = "Glasgow Queen Street",
                            date = "TODAY",
                            time = "09:42",
                            ticketType = "Off-Peak Single",
                            price = 14.20,
                            isActivated = false
                        )
                    )
                    repository.insertTicket(
                        TicketEntity(
                            origin = "Glasgow Queen Street",
                            destination = "Fort William",
                            date = "22 AUG 2026",
                            time = "12:15",
                            ticketType = "Advance Single",
                            price = 28.50,
                            isActivated = false
                        )
                    )
                    repository.insertTicket(
                        TicketEntity(
                            origin = "Edinburgh Waverley",
                            destination = "Stirling",
                            date = "15 AUG 2026",
                            time = "10:45",
                            ticketType = "Anytime Day Return",
                            price = 11.20,
                            isActivated = true,
                            activationTime = System.currentTimeMillis() - 86400000
                        )
                    )
                }
            }

            // Pre-populate favorites
            repository.favoriteRoutes.first().let { favList ->
                if (favList.isEmpty()) {
                    repository.insertFavorite("Edinburgh Waverley", "Glasgow Queen Street")
                    repository.insertFavorite("Stirling", "Edinburgh Waverley")
                }
            }

            // Pre-populate some visited stations for the Rail Passport journal
            repository.visitedStations.first().let { visitList ->
                if (visitList.isEmpty()) {
                    repository.visitStation("Edinburgh Waverley")
                    repository.visitStation("Glasgow Queen Street")
                    repository.visitStation("Haymarket")
                    repository.visitStation("Linlithgow")
                    repository.visitStation("Stirling")
                }
            }

            // Pre-populate recent searches
            repository.recentSearches.first().let { searchList ->
                if (searchList.isEmpty()) {
                    repository.insertRecentSearch("Edinburgh Waverley", "Glasgow Queen Street")
                    repository.insertRecentSearch("Glasgow Queen Street", "Oban")
                    repository.insertRecentSearch("Edinburgh Waverley", "Aberdeen")
                }
            }

            // Initialize departures and journeys
            updateStationDepartures()
            searchJourneys()
            calculateSeasonPrice()
        }
    }

    // --- Action Handlers ---

    fun setTab(tab: String) {
        currentMainTab.value = tab
    }

    fun toggleOfflineMode() {
        isOfflineMode.value = !isOfflineMode.value
    }

    fun triggerStationMode(nearStation: String) {
        simulatedNearStation.value = nearStation
        stationModeActive.value = true
        currentMainTab.value = "station"
    }

    fun dismissStationMode() {
        stationModeActive.value = false
    }

    fun updateSearchInputs(origin: String, dest: String) {
        originInput.value = origin
        destinationInput.value = dest
    }

    fun swapSearchInputs() {
        val temp = originInput.value
        originInput.value = destinationInput.value
        destinationInput.value = temp
    }

    fun searchJourneys() {
        viewModelScope.launch {
            repository.insertRecentSearch(originInput.value, destinationInput.value)

            val rawServices = repository.getSimulatedTrainServices()
            // Filter based on origin / destination match if possible, otherwise use base list
            val filtered = rawServices.filter {
                it.origin.lowercase().contains(originInput.value.lowercase().take(4)) ||
                it.destination.lowercase().contains(destinationInput.value.lowercase().take(4)) ||
                true // default fallback
            }.map { service ->
                // Apply filter criteria tweaks
                var finalStatus = service.status
                var platform = service.platform
                var delayed = service.delayedMinutes

                if (filterAccessible.value && !service.facilities.contains("Accessible Toilet")) {
                    // Tweak details to represent filter
                }
                service.copy(
                    origin = originInput.value,
                    destination = destinationInput.value,
                    status = finalStatus,
                    platform = platform,
                    delayedMinutes = delayed
                )
            }
            _plannedJourneys.value = filtered
        }
    }

    fun updateStationDepartures() {
        val departuresList = repository.getSimulatedTrainServices().filter {
            it.origin.lowercase().contains(selectedBoardStation.value.lowercase().take(4)) ||
            true // fallback
        }
        _stationDepartures.value = departuresList
    }

    fun selectBoard(stationName: String) {
        selectedBoardStation.value = stationName
        updateStationDepartures()
    }

    fun purchaseTicket(origin: String, destination: String, type: String, price: Double, date: String = "TODAY", time: String = "12:00") {
        viewModelScope.launch {
            val newTicket = TicketEntity(
                origin = origin,
                destination = destination,
                date = date,
                time = time,
                ticketType = type,
                price = price,
                isActivated = false
            )
            repository.insertTicket(newTicket)
            // Save visited stations when purchasing/traveling
            repository.visitStation(origin)
            repository.visitStation(destination)
        }
    }

    fun activateTicket(ticket: TicketEntity) {
        viewModelScope.launch {
            val updated = ticket.copy(isActivated = true, activationTime = System.currentTimeMillis())
            repository.updateTicket(updated)
        }
    }

    fun visitStation(stationName: String) {
        viewModelScope.launch {
            repository.visitStation(stationName)
        }
    }

    fun clearPassport() {
        viewModelScope.launch {
            repository.clearPassport()
        }
    }

    fun toggleFavorite(origin: String, destination: String, isFav: Boolean) {
        viewModelScope.launch {
            if (isFav) {
                repository.insertFavorite(origin, destination)
            } else {
                repository.removeFavorite(origin, destination)
            }
        }
    }

    fun calculateSeasonPrice() {
        calculatedSeason.value = repository.calculateSeasonTicket(seasonOrigin.value, seasonDestination.value)
    }

    fun submitTravelAssist() {
        assistStatus.value = "REQUESTED"
        viewModelScope.launch {
            // Simulate delay to CONFIRMED, then READY
            kotlinx.coroutines.delay(1500)
            assistStatus.value = "CONFIRMED"
            kotlinx.coroutines.delay(1500)
            assistStatus.value = "READY"
        }
    }

    fun cancelTravelAssist() {
        assistStatus.value = "NONE"
    }

    fun selectTicketForRepayClaim(ticket: TicketEntity) {
        selectedTicketForRepay.value = ticket
        repayClaimStatus.value = "NOT_STARTED"
        // Pre-fill estimates
        delayMinutesClaimed.value = (25..45).random()
        refundAmountClaimed.value = ticket.price * (if (delayMinutesClaimed.value > 30) 1.0 else 0.5)
    }

    fun submitDelayRepayClaim() {
        repayClaimStatus.value = "SUBMITTED"
        viewModelScope.launch {
            kotlinx.coroutines.delay(2000)
            repayClaimStatus.value = "APPROVED"
        }
    }
}
