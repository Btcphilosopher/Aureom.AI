package com.example.model

import androidx.compose.ui.graphics.vector.ImageVector

data class RailStation(
    val name: String,
    val code: String,
    val lat: Float,
    val lng: Float,
    val hasToilet: Boolean = true,
    val hasCafe: Boolean = true,
    val hasTaxi: Boolean = true,
    val hasBikeFacilities: Boolean = true,
    val hasStepFreeAccess: Boolean = true,
    val hasHelpPoint: Boolean = true,
    val busConnections: String = "Stance 1-4 adjacent to main entrance",
    val description: String = "A key hub on Scotland's Railway network."
)

data class RouteStop(
    val stationName: String,
    val scheduledTime: String,
    val actualTime: String? = null,
    val isCompleted: Boolean = false
)

data class TrainService(
    val serviceId: String,
    val departureTime: String,
    val origin: String,
    val destination: String,
    val finalDestination: String,
    val status: String, // "ON TIME", "BOARDING", "DEPARTED", "DELAYED", "CANCELLED", "PLATFORM CHANGE"
    val delayedMinutes: Int = 0,
    val platform: String,
    val expectedArrival: String,
    val trainType: String = "Class 385 eExpress",
    val stops: List<RouteStop>,
    val facilities: List<String> = listOf("WiFi", "Power Sockets", "Cycle Spaces", "Accessible Toilet"),
    val connectionsRisk: Boolean = false,
    val delayReason: String? = null,
    val progressPercent: Float = 0f
)

data class ScenicJourney(
    val id: String,
    val name: String,
    val regions: List<String>,
    val description: String,
    val startStation: String,
    val endStation: String,
    val landmarks: List<ScenicLandmark>,
    val onwardFerryOrBus: String? = null,
    val imagePrompt: String // For illustrative design
)

data class ScenicLandmark(
    val name: String,
    val distanceMiles: Float,
    val description: String,
    val historyFact: String,
    val photoHint: String,
    val type: String // "CASTLE", "LOCH", "BRIDGE", "MOUNTAIN"
)

data class DisruptionAlert(
    val id: String,
    val routeName: String,
    val severity: String, // "MINOR", "MAJOR", "SEVERE"
    val cause: String, // e.g. "Severe Weather - High Winds", "Signal Failure"
    val description: String,
    val affectedTrains: List<String>,
    val replacementBusActive: Boolean = false,
    val isWeatherRelated: Boolean = false
)

data class SeasonTicketCalculation(
    val route: String,
    val weeklyCost: Double,
    val monthlyCost: Double,
    val annualCost: Double,
    val flexiCost: Double, // 10 tickets in 28 days
    val dailyCommuteCost: Double,
    val annualSavingsVsDaily: Double
)
