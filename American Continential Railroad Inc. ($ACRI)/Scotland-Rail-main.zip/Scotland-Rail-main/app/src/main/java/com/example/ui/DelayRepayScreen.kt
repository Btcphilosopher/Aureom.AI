package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TicketEntity
import com.example.viewmodel.RailViewModel
import com.example.ui.theme.*

@Composable
fun DelayRepayScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val tickets by viewModel.tickets.collectAsState()
    val selectedTicket by viewModel.selectedTicketForRepay.collectAsState()
    val claimStatus by viewModel.repayClaimStatus.collectAsState()
    val delayMinutes by viewModel.delayMinutesClaimed.collectAsState()
    val refundAmount by viewModel.refundAmountClaimed.collectAsState()

    // Filter tickets that are activated or complete (traveled) for delay repay eligibility
    val eligibleTickets = tickets

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Header Banner ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ScotRailNavy),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "DELAY REPAY SERVICE",
                        style = MaterialTheme.typography.labelSmall,
                        color = SaltireBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        "Intelligent Claims Assistant",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        "If your train journey across Scotland was delayed by 30 minutes or more, you are eligible for compensation. Our assistant pre-populates details for you.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.LightGray
                    )
                }
            }
        }

        if (selectedTicket == null) {
            item {
                Text("CHOOSE ELIGIBLE JOURNEY TICKET", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
            }

            if (eligibleTickets.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.History, null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("No recent journeys found", fontWeight = FontWeight.Bold)
                            Text("Your purchased tickets will appear here for Delay Repay calculations.", color = Color.Gray, textAlign = TextAlign.Center)
                        }
                    }
                }
            } else {
                items(eligibleTickets) { ticket ->
                    Card(
                        onClick = { viewModel.selectTicketForRepayClaim(ticket) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${ticket.origin} ↔ ${ticket.destination}", fontWeight = FontWeight.Bold)
                                Text("Travel Date: ${ticket.date} | Cost: £${String.format("%.2f", ticket.price)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = SaltireBlue)
                        }
                    }
                }
            }
        } else {
            // Claim Form Setup
            val t = selectedTicket!!

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CLAIM CONTEXT DETAILS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { viewModel.selectedTicketForRepay.value = null }) {
                        Text("CHANGE TICKET", color = SaltireBlue)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("TICKET TYPE", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                            Text(t.ticketType.uppercase(), fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("PLANNED ROUTE", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                            Text("${t.origin} to ${t.destination}", fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("PLANNED DEPARTURE", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                            Text(t.time, fontWeight = FontWeight.Bold)
                        }

                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))

                        if (claimStatus == "NOT_STARTED") {
                            // Editable Delay slider simulation
                            Text("ESTIMATED DELAY COMPENSATON", fontWeight = FontWeight.Bold, color = ScotRailNavy)
                            Text("Drag the slider to define your actual service delay duration:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("DELAY MINUTES: $delayMinutes MIN", fontWeight = FontWeight.Bold, color = RailwayRed)
                                Text("REFUND ESTIMATE: £${String.format("%.2f", refundAmount)}", fontWeight = FontWeight.Bold, color = ColorOnTime)
                            }

                            Slider(
                                value = delayMinutes.toFloat(),
                                onValueChange = {
                                    viewModel.delayMinutesClaimed.value = it.toInt()
                                    viewModel.refundAmountClaimed.value = t.price * (if (it >= 60) 1.0 else 0.5)
                                },
                                valueRange = 30f..120f,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Button(
                                onClick = { viewModel.submitDelayRepayClaim() },
                                colors = ButtonDefaults.buttonColors(containerColor = RailwayRed),
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Check, null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("SUBMIT COMPENSATION CLAIM")
                            }
                        } else {
                            // Progress bar / status view
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(color = ColorOnTime)
                                Text(
                                    text = if (claimStatus == "SUBMITTED") "PROCESSING CLAIM RECORD..." else "CLAIM APPROVED & DISPATCHED",
                                    fontWeight = FontWeight.Bold,
                                    color = if (claimStatus == "APPROVED") ColorOnTime else ScotRailNavy
                                )
                                if (claimStatus == "APPROVED") {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = ColorOnTime.copy(alpha = 0.08f)),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("REFUND VALUE OF £${String.format("%.2f", refundAmount)} APPROVED", fontWeight = FontWeight.ExtraBold, color = ColorOnTime)
                                            Text("Payment returned securely to your tokenized payment gateway. Funds will settle within 3-5 days.", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
