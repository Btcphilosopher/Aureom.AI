'use client';

import React, { useState, useEffect } from 'react';
import { Train, Clock, MapPin, Gauge, ShieldAlert, ArrowRight, Moon, Coffee, Sparkles, AlertCircle, Radio } from 'lucide-react';
import { Booking, LiveTrainStatus } from '@/lib/types';
import { INITIAL_LIVE_STATUS } from '@/lib/mock-data';

interface MyJourneyViewProps {
  booking: Booking;
  onOpenOnboardMode: () => void;
  onOpenTicket: () => void;
}

export const MyJourneyView: React.FC<MyJourneyViewProps> = ({
  booking,
  onOpenOnboardMode,
  onOpenTicket
}) => {
  const [liveStatus, setLiveStatus] = useState<LiveTrainStatus>(INITIAL_LIVE_STATUS);
  const [countdownSeconds, setCountdownSeconds] = useState(15480); // 04h 18m approx

  // Live countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdownSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (totalSecs: number) => {
    const hours = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    return `${String(hours).padStart(2, '0')}h ${String(mins).padStart(2, '0')}m ${String(secs).padStart(2, '0')}s`;
  };

  // Intermediate stops from timetable
  const stops = booking.train.stops || [];

  return (
    <div className="w-full space-y-8">
      {/* Top Banner: Central Journey Headline & Countdown */}
      <div className="bg-gradient-to-r from-[#0B132B] via-[#101D36] to-[#0B132B] border border-[#C8A86B]/50 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded bg-[#C8A86B]/20 text-[#DFBF83] border border-[#C8A86B]/40 text-xs font-mono-tabular font-bold tracking-widest uppercase">
                TONIGHT · {booking.train.trainNumber}
              </span>
              <span className="text-xs text-[#E8E2D4]/50">·</span>
              <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                <Radio className="w-3.5 h-3.5 animate-pulse" />
                Live Telemetry Active
              </span>
            </div>

            <h1 className="font-serif-luxury text-3xl sm:text-5xl font-bold text-white tracking-wide">
              London St Pancras → Zürich HB
            </h1>
            <p className="text-sm text-[#E8E2D4]/70 mt-1">
              {booking.train.trainName} · International Sleeper Corridor · Direct Overnight
            </p>
          </div>

          {/* Large Countdown Box */}
          <div className="bg-[#070B18]/90 border border-[#253358] rounded-xl p-4 sm:p-5 text-center min-w-[260px] shadow-inner">
            <span className="text-[11px] font-mono-tabular tracking-wider text-[#C8A86B] uppercase block mb-1">
              TIME UNTIL DEPARTURE
            </span>
            <div className="font-mono-tabular text-2xl sm:text-3xl font-bold text-white tracking-wider">
              {formatCountdown(countdownSeconds)}
            </div>
            <span className="text-[11px] text-[#E8E2D4]/60 block mt-1">
              Departure 20:40 · Platform 9
            </span>
          </div>
        </div>

        {/* Quick Launch to Onboard Mode */}
        <div className="mt-6 pt-5 border-t border-[#1E294B] flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#152244] border border-[#C8A86B]/40 flex items-center justify-center text-[#C8A86B]">
              <Moon className="w-4 h-4 fill-[#C8A86B]/20" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">
                Boarding Tonight? Switch to Onboard Carriage Mode
              </span>
              <span className="text-[11px] text-[#E8E2D4]/70">
                Control cabin reading lights, temperature, DND, breakfast order, and wake-up calls.
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenTicket}
              className="px-4 py-2 bg-[#152244] hover:bg-[#1E2E5C] text-white border border-[#253358] text-xs font-bold uppercase tracking-wider rounded transition-colors"
            >
              View Ticket Pass
            </button>
            <button
              onClick={onOpenOnboardMode}
              className="px-5 py-2 bg-[#C8A86B] hover:bg-[#DFBF83] text-[#070B18] text-xs font-bold uppercase tracking-wider rounded transition-colors shadow-md flex items-center gap-1.5"
            >
              <Moon className="w-3.5 h-3.5" />
              <span>Launch Onboard Mode</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2-Column Dashboard: Route Progression Timeline + Live Telemetry & Cabin */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column (7 cols): Route Stops & Timetable Progression */}
        <div className="lg:col-span-7 bg-[#0B132B] border border-[#253358] rounded-xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#1E294B]">
            <div>
              <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
                JOURNEY ITINERARY
              </span>
              <h3 className="text-xl font-bold text-white mt-0.5">
                Overnight Route Progression
              </h3>
            </div>
            <span className="text-xs text-[#E8E2D4]/60">Total distance: 1,065 km</span>
          </div>

          {/* Stops List */}
          <div className="space-y-6 relative before:absolute before:left-3.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-[#253358]">
            {stops.map((stop, index) => {
              const isFirst = index === 0;
              const isLast = index === stops.length - 1;
              const isCurrent = stop.stationCode === 'PAR';

              return (
                <div key={stop.stationCode} className="relative flex items-start gap-4 pl-8">
                  {/* Step indicator node */}
                  <div
                    className={`absolute left-1.5 top-1 -translate-x-1/2 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                      isCurrent
                        ? 'bg-[#C8A86B] border-[#DFBF83] ring-4 ring-[#C8A86B]/30'
                        : isFirst || stop.isCompleted
                        ? 'bg-emerald-500 border-emerald-400'
                        : 'bg-[#101D36] border-[#253358]'
                    }`}
                  >
                    {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-[#070B18]" />}
                  </div>

                  <div className="flex-1 bg-[#101D36] border border-[#253358] rounded-lg p-3.5 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-white">{stop.stationName}</h4>
                        {isCurrent && (
                          <span className="px-1.5 py-0.5 bg-[#C8A86B]/20 text-[#DFBF83] text-[10px] font-bold rounded">
                            NEXT STOP
                          </span>
                        )}
                        {stop.isCompleted && (
                          <span className="text-[10px] text-emerald-400 font-medium">Completed</span>
                        )}
                      </div>
                      <div className="text-xs text-[#E8E2D4]/60 mt-0.5">
                        {stop.platform || 'Platform assigned 1h before arrival'}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-mono-tabular text-sm font-bold text-white">
                        {stop.departureTime !== '—' ? stop.departureTime : stop.arrivalTime}
                      </div>
                      <div className="text-[10px] text-[#E8E2D4]/50">
                        {isFirst ? 'Departure' : isLast ? 'Final Arrival' : 'Scheduled Stop'}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Operational Checkpoints Box */}
          <div className="p-4 bg-[#101D36] border border-[#253358] rounded-lg">
            <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block mb-2">
              BEFORE DEPARTURE SCHEDULE
            </span>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 rounded bg-[#070B18] border border-[#253358]">
                <span className="text-[10px] text-[#E8E2D4]/50 block">Check-in Opens</span>
                <span className="font-mono-tabular font-bold text-white">18:40</span>
              </div>
              <div className="p-2 rounded bg-[#070B18] border border-[#253358]">
                <span className="text-[10px] text-[#E8E2D4]/50 block">Carriage Boarding</span>
                <span className="font-mono-tabular font-bold text-[#C8A86B]">20:05</span>
              </div>
              <div className="p-2 rounded bg-[#070B18] border border-[#253358]">
                <span className="text-[10px] text-[#E8E2D4]/50 block">Departure</span>
                <span className="font-mono-tabular font-bold text-white">20:40</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Live Train Telemetry + Your Cabin */}
        <div className="lg:col-span-5 space-y-6">
          {/* Your Cabin Card */}
          <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-5 shadow-xl">
            <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block mb-1">
              YOUR RESERVATION
            </span>
            <h4 className="text-lg font-bold text-white">
              Sleeper Compartment 204
            </h4>
            <div className="text-xs text-[#DFBF83] font-medium mt-0.5">
              Lower Berth (Window View) · Carriage 14
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded bg-[#101D36] border border-[#253358]">
                <span className="text-[10px] text-[#E8E2D4]/50 block">Car Attendant</span>
                <span className="font-medium text-white">Marco V. (Steward 4)</span>
              </div>
              <div className="p-2.5 rounded bg-[#101D36] border border-[#253358]">
                <span className="text-[10px] text-[#E8E2D4]/50 block">Breakfast</span>
                <span className="font-medium text-emerald-400">Reserved 07:00</span>
              </div>
            </div>

            <div className="mt-3 p-3 bg-[#152244]/50 border border-[#C8A86B]/30 rounded-lg text-xs text-[#E8E2D4]/80 flex items-center justify-between">
              <span>Smart Cabin Controls Active</span>
              <button
                onClick={onOpenOnboardMode}
                className="text-[#DFBF83] font-bold hover:underline"
              >
                Adjust Cabin →
              </button>
            </div>
          </div>

          {/* Live Train Status Telemetry */}
          <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1E294B]">
              <div className="flex items-center gap-2">
                <Gauge className="w-4 h-4 text-[#C8A86B]" />
                <h4 className="text-sm font-bold text-white">Live Train Status</h4>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[11px] font-bold">
                {liveStatus.status}
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-[10px] text-[#E8E2D4]/50 block">CURRENT POSITION</span>
                <div className="font-semibold text-white mt-0.5">
                  {liveStatus.currentLocationName}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded bg-[#101D36] border border-[#253358]">
                  <span className="text-[10px] text-[#E8E2D4]/50 block">CURRENT SPEED</span>
                  <span className="font-mono-tabular font-bold text-white text-sm">
                    {liveStatus.currentSpeedKmH} km/h
                  </span>
                </div>
                <div className="p-2.5 rounded bg-[#101D36] border border-[#253358]">
                  <span className="text-[10px] text-[#E8E2D4]/50 block">OUTSIDE TEMP</span>
                  <span className="font-mono-tabular font-bold text-white text-sm">
                    {liveStatus.outdoorTempCelsius}°C
                  </span>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-[#E8E2D4]/50 block">NEXT STOP</span>
                <div className="font-semibold text-white mt-0.5">
                  {liveStatus.nextStation} (Est. {liveStatus.estimatedArrival})
                </div>
              </div>

              <div>
                <span className="text-[10px] text-[#E8E2D4]/50 block">FINAL ARRIVAL</span>
                <div className="font-semibold text-white mt-0.5">
                  Zürich HB · 08:15 · Gleis 7 (Track 7)
                </div>
              </div>

              {/* Operational Alert */}
              {liveStatus.serviceAlert && (
                <div className="p-3 rounded-lg bg-[#152244]/80 border border-[#C8A86B]/40 text-xs text-[#E8E2D4] flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-[#C8A86B] shrink-0 mt-0.5" />
                  <p>{liveStatus.serviceAlert}</p>
                </div>
              )}
            </div>

            {/* Note distinguishing real-time telemetry from simulated dev mode */}
            <div className="pt-2 text-[10px] text-[#E8E2D4]/40 text-center font-mono-tabular">
              Telemetric GPS positioning provided by Nightline European Operations Hub.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
