'use client';

import React from 'react';
import { Train, Clock, ArrowRight, ShieldCheck, Leaf, Sparkles } from 'lucide-react';
import { Currency } from '@/lib/types';
import { formatPrice } from '@/lib/storage';

interface TonightNetworkStripProps {
  currency: Currency;
  onSelectRoute: (fromCode: string, toCode: string) => void;
  onViewMyJourney: () => void;
  activeBookingReference?: string;
}

export const TonightNetworkStrip: React.FC<TonightNetworkStripProps> = ({
  currency,
  onSelectRoute,
  onViewMyJourney,
  activeBookingReference
}) => {
  const departures = [
    {
      fromCode: 'STP',
      toCode: 'ZUR',
      fromCity: 'London',
      toCity: 'Zürich HB',
      trainNumber: 'NL 402',
      depTime: '20:40',
      arrTime: '08:15',
      duration: '11h 35m',
      status: 'BOARDING IN 3H',
      priceGbp: 89,
      direct: true
    },
    {
      fromCode: 'PAR',
      toCode: 'MIL',
      fromCity: 'Paris',
      toCity: 'Milan Centrale',
      trainNumber: 'NL 220',
      depTime: '21:35',
      arrTime: '07:20',
      duration: '9h 45m',
      status: 'ON TIME',
      priceGbp: 95,
      direct: true
    },
    {
      fromCode: 'AMS',
      toCode: 'PRG',
      fromCity: 'Amsterdam',
      toCity: 'Prague hl.n.',
      trainNumber: 'NL 108',
      depTime: '19:55',
      arrTime: '07:45',
      duration: '11h 50m',
      status: 'ON TIME',
      priceGbp: 85,
      direct: true
    },
    {
      fromCode: 'BRU',
      toCode: 'BER',
      fromCity: 'Brussels',
      toCity: 'Berlin Hbf',
      trainNumber: 'NL 315',
      depTime: '20:15',
      arrTime: '06:50',
      duration: '10h 35m',
      status: 'PLATFORM READY',
      priceGbp: 79,
      direct: true
    }
  ];

  return (
    <div className="w-full space-y-6">
      {/* Active Booking Reminder Card if passenger has a booking */}
      {activeBookingReference && (
        <div className="bg-gradient-to-r from-[#101D36] via-[#152244] to-[#101D36] border border-[#C8A86B]/40 rounded-xl p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-[#070B18] border border-[#C8A86B]/50 flex items-center justify-center text-[#C8A86B]">
              <Train className="w-5 h-5 text-[#C8A86B]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold tracking-wider text-[#C8A86B] uppercase">
                  ACTIVE BOOKING · REF {activeBookingReference}
                </span>
                <span className="text-xs text-[#E8E2D4]/50">·</span>
                <span className="text-xs text-emerald-400 font-medium">Ticket Stored Offline</span>
              </div>
              <h4 className="text-base font-bold text-white mt-0.5">
                London St Pancras → Zürich HB · 20:40 Tonight
              </h4>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onViewMyJourney}
              className="w-full sm:w-auto px-4 py-2 bg-[#C8A86B] hover:bg-[#DFBF83] text-[#070B18] font-bold text-xs uppercase tracking-wider rounded transition-colors"
            >
              Open My Journey
            </button>
          </div>
        </div>
      )}

      {/* TONIGHT'S NETWORK SECTION */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs font-bold tracking-[0.2em] text-[#C8A86B] uppercase">
              LIVE DEPARTURES
            </h3>
            <h2 className="font-serif-luxury text-2xl text-white font-bold mt-0.5">
              Tonight’s European Network
            </h2>
          </div>
          <span className="text-xs text-[#E8E2D4]/60 hidden sm:inline">
            Direct sleeper services departing between 19:55 and 22:45
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {departures.map((train) => (
            <div
              key={train.trainNumber}
              className="bg-[#0B132B]/90 border border-[#253358] hover:border-[#C8A86B]/60 rounded-xl p-4 transition-all duration-200 group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-[#E8E2D4]/70 mb-2">
                  <span className="font-bold text-[#C8A86B] tracking-wider">{train.trainNumber}</span>
                  <span className="text-[11px] px-2 py-0.5 rounded bg-[#152244] text-[#E8E2D4]/90 font-medium">
                    {train.status}
                  </span>
                </div>

                <div className="flex items-center justify-between my-2">
                  <div>
                    <div className="text-lg font-bold text-white">{train.fromCity}</div>
                    <div className="font-mono-tabular text-sm text-[#C8A86B] font-semibold">{train.depTime}</div>
                  </div>

                  <div className="flex flex-col items-center px-2">
                    <span className="text-[10px] text-[#E8E2D4]/60 font-medium">{train.duration}</span>
                    <ArrowRight className="w-4 h-4 text-[#C8A86B]/70 group-hover:translate-x-1 transition-transform" />
                    <span className="text-[9px] text-emerald-400">Direct</span>
                  </div>

                  <div className="text-right">
                    <div className="text-lg font-bold text-white">{train.toCity}</div>
                    <div className="font-mono-tabular text-sm text-[#C8A86B] font-semibold">{train.arrTime}</div>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#1E294B] flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-[#E8E2D4]/60 block leading-tight">From</span>
                  <span className="font-bold text-white text-sm">
                    {formatPrice(train.priceGbp, currency)}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => onSelectRoute(train.fromCode, train.toCode)}
                  className="px-3 py-1.5 bg-[#152244] group-hover:bg-[#C8A86B] group-hover:text-[#070B18] text-[#C8A86B] text-xs font-semibold rounded transition-colors"
                >
                  View Cabins →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
