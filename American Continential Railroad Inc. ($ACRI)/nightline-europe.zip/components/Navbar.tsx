'use client';

import React from 'react';
import { Ticket, Train, Moon, Wifi, MapPin, Globe } from 'lucide-react';
import { Currency, Language } from '@/lib/types';
import { formatPrice } from '@/lib/storage';

interface NavbarProps {
  activeTab: 'search' | 'my-journey' | 'onboard' | 'network' | 'stations' | 'dining' | 'bookings';
  onSelectTab: (tab: 'search' | 'my-journey' | 'onboard' | 'network' | 'stations' | 'dining' | 'bookings') => void;
  currency: Currency;
  onCurrencyChange: (c: Currency) => void;
  language: Language;
  onLanguageChange: (l: Language) => void;
  hasActiveBooking: boolean;
  onOpenTicket: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  currency,
  onCurrencyChange,
  language,
  onLanguageChange,
  hasActiveBooking,
  onOpenTicket
}) => {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#253358]/50 bg-[#070B18]/90 backdrop-blur-md transition-colors">
      {/* Top operational announcement bar */}
      <div className="w-full bg-[#0B132B] border-b border-[#1E294B] px-4 py-1.5 text-xs text-[#E8E2D4]/70 flex items-center justify-between">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 text-[#C8A86B] font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C8A86B]" />
              TONIGHT’S SLEEPER FLEET
            </span>
            <span className="hidden sm:inline text-[#E8E2D4]/50">·</span>
            <span className="hidden sm:inline">NL 402 London → Zürich boarding in 3h 40m</span>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium">
            {/* Currency Selector */}
            <div className="flex items-center gap-1 bg-[#152244] px-2 py-0.5 rounded border border-[#253358]">
              {(['GBP', 'EUR', 'CHF'] as Currency[]).map((c) => (
                <button
                  key={c}
                  onClick={() => onCurrencyChange(c)}
                  className={`px-1.5 py-0.5 rounded text-[11px] transition-colors ${
                    currency === c ? 'bg-[#C8A86B] text-[#070B18] font-bold' : 'text-[#E8E2D4]/70 hover:text-white'
                  }`}
                >
                  {c === 'GBP' ? '£' : c === 'EUR' ? '€' : 'CHF'}
                </button>
              ))}
            </div>

            {/* Language Selector */}
            <div className="hidden md:flex items-center gap-1 text-[11px] text-[#E8E2D4]/70">
              <Globe className="w-3 h-3 text-[#C8A86B]" />
              {(['en', 'de', 'fr', 'it'] as Language[]).map((l) => (
                <button
                  key={l}
                  onClick={() => onLanguageChange(l)}
                  className={`px-1 uppercase transition-colors ${
                    language === l ? 'text-[#C8A86B] font-bold underline' : 'hover:text-white'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1 text-[#C8A86B]/90 text-[11px]">
              <Wifi className="w-3 h-3 text-emerald-400" />
              <span className="hidden lg:inline">Offline Cached</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Top Bar strictly obeying Top Bar Contract: 3 zones separated by gap-8 */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element wordmark in display face) */}
        <button
          onClick={() => onSelectTab('search')}
          className="flex items-center gap-2.5 text-left group whitespace-nowrap shrink-0 focus:outline-none"
        >
          <div className="w-8 h-8 rounded bg-[#101D36] border border-[#C8A86B]/40 flex items-center justify-center text-[#C8A86B] shadow-inner">
            <Moon className="w-4 h-4 fill-[#C8A86B]/20" />
          </div>
          <div className="flex flex-col">
            <span className="font-serif-luxury text-2xl tracking-[0.18em] font-bold text-white group-hover:text-[#DFBF83] transition-colors leading-none">
              NIGHTLINE
            </span>
            <span className="text-[9px] tracking-[0.25em] text-[#C8A86B] font-medium uppercase mt-0.5 leading-none">
              Europe While You Sleep
            </span>
          </div>
        </button>

        {/* Zone 2: 4-5 concise single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#E8E2D4]/80">
          <button
            onClick={() => onSelectTab('search')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
              activeTab === 'search' ? 'text-[#C8A86B] font-semibold' : 'hover:text-white'
            }`}
          >
            Sleeper Search
            {activeTab === 'search' && (
              <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C8A86B]" />
            )}
          </button>

          <button
            onClick={() => onSelectTab('network')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
              activeTab === 'network' ? 'text-[#C8A86B] font-semibold' : 'hover:text-white'
            }`}
          >
            Night Map & Routes
            {activeTab === 'network' && (
              <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C8A86B]" />
            )}
          </button>

          <button
            onClick={() => onSelectTab('dining')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
              activeTab === 'dining' ? 'text-[#C8A86B] font-semibold' : 'hover:text-white'
            }`}
          >
            Dining & Bar Car
            {activeTab === 'dining' && (
              <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C8A86B]" />
            )}
          </button>

          <button
            onClick={() => onSelectTab('my-journey')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 relative flex items-center gap-1.5 ${
              activeTab === 'my-journey' ? 'text-[#C8A86B] font-semibold' : 'hover:text-white'
            }`}
          >
            <Train className="w-3.5 h-3.5 text-[#C8A86B]" />
            Live Train NL 402
            {activeTab === 'my-journey' && (
              <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C8A86B]" />
            )}
          </button>

          <button
            onClick={() => onSelectTab('onboard')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 relative flex items-center gap-1.5 ${
              activeTab === 'onboard' ? 'text-[#C8A86B] font-semibold' : 'hover:text-white'
            }`}
          >
            <Moon className="w-3.5 h-3.5 text-[#DFBF83]" />
            Onboard Mode
            {activeTab === 'onboard' && (
              <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C8A86B]" />
            )}
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenTicket}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold tracking-wider uppercase text-[#070B18] bg-[#C8A86B] hover:bg-[#DFBF83] transition-all rounded shadow-md whitespace-nowrap shrink-0"
          >
            <Ticket className="w-4 h-4 text-[#070B18]" />
            <span>Digital Ticket</span>
          </button>

          <button
            onClick={() => onSelectTab('bookings')}
            className="hidden sm:inline-flex px-3 py-2 text-xs font-medium text-[#E8E2D4] hover:text-white border border-[#253358] hover:border-[#C8A86B]/40 rounded transition-colors whitespace-nowrap shrink-0"
          >
            My Bookings
          </button>
        </div>
      </div>

      {/* Mobile navigation bar */}
      <div className="md:hidden flex items-center justify-around bg-[#0B132B]/95 border-t border-[#1E294B] py-2 px-2 text-xs overflow-x-auto">
        <button
          onClick={() => onSelectTab('search')}
          className={`px-2 py-1 rounded whitespace-nowrap ${activeTab === 'search' ? 'text-[#C8A86B] font-semibold bg-[#152244]' : 'text-[#E8E2D4]/70'}`}
        >
          Search
        </button>
        <button
          onClick={() => onSelectTab('my-journey')}
          className={`px-2 py-1 rounded whitespace-nowrap ${activeTab === 'my-journey' ? 'text-[#C8A86B] font-semibold bg-[#152244]' : 'text-[#E8E2D4]/70'}`}
        >
          Live Train
        </button>
        <button
          onClick={() => onSelectTab('onboard')}
          className={`px-2 py-1 rounded whitespace-nowrap ${activeTab === 'onboard' ? 'text-[#C8A86B] font-semibold bg-[#152244]' : 'text-[#E8E2D4]/70'}`}
        >
          Cabin Controls
        </button>
        <button
          onClick={() => onSelectTab('network')}
          className={`px-2 py-1 rounded whitespace-nowrap ${activeTab === 'network' ? 'text-[#C8A86B] font-semibold bg-[#152244]' : 'text-[#E8E2D4]/70'}`}
        >
          Night Map
        </button>
        <button
          onClick={() => onSelectTab('dining')}
          className={`px-2 py-1 rounded whitespace-nowrap ${activeTab === 'dining' ? 'text-[#C8A86B] font-semibold bg-[#152244]' : 'text-[#E8E2D4]/70'}`}
        >
          Dining
        </button>
      </div>
    </header>
  );
};
