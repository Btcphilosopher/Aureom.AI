'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import {
  Moon,
  Sun,
  Lightbulb,
  Thermometer,
  Bell,
  Coffee,
  UtensilsCrossed,
  Clock,
  Check,
  Compass,
  Train,
  Sparkles,
  Wifi,
  Navigation,
  Car,
  Footprints
} from 'lucide-react';
import { CabinSmartControlState } from '@/lib/types';
import { getStoredCabinControls, saveCabinControls } from '@/lib/storage';
import { DINING_MENU } from '@/lib/mock-data';

interface OnboardModeProps {
  cabinNumber?: string;
  destinationCity?: string;
  onExitToJourney?: () => void;
}

export const OnboardMode: React.FC<OnboardModeProps> = ({
  cabinNumber = 'Compartment 204',
  destinationCity = 'Zürich',
  onExitToJourney
}) => {
  const [controls, setControls] = useState<CabinSmartControlState>(getStoredCabinControls());
  const [activeTab, setActiveTab] = useState<'cabin' | 'wakeup' | 'breakfast' | 'dining' | 'arrival'>('cabin');
  const [diningReserved, setDiningReserved] = useState(false);
  const [diningTime, setDiningTime] = useState('20:30');
  const [diningGuests, setDiningGuests] = useState('2');
  const [attendantToast, setAttendantToast] = useState(false);

  const updateControl = (partial: Partial<CabinSmartControlState>) => {
    const updated = saveCabinControls(partial);
    setControls(updated);
  };

  const handleCallAttendant = () => {
    updateControl({ attendantCalled: true });
    setAttendantToast(true);
    setTimeout(() => setAttendantToast(false), 4000);
  };

  const handleRequestWakeUp = (option: 'specific_time' | '30_min_before', time?: string) => {
    updateControl({
      wakeUpOption: option,
      wakeUpTime: time || (option === '30_min_before' ? '07:45' : '06:30'),
      wakeUpConfirmed: true
    });
  };

  const handleSelectBreakfast = (choice: 'continental' | 'vegetarian' | 'vegan') => {
    updateControl({
      breakfastSelected: choice,
      breakfastDelivered: false
    });
  };

  return (
    <div className="w-full space-y-8">
      {/* Onboard Header Banner */}
      <div className="bg-[#0B132B] border border-[#C8A86B]/50 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#C8A86B] animate-pulse" />
              <span className="text-xs font-mono-tabular tracking-widest text-[#C8A86B] uppercase font-bold">
                ONBOARD MODE · TRAIN NL 402
              </span>
            </div>
            <h1 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-white tracking-wide">
              Good Evening. You are travelling to {destinationCity}.
            </h1>
            <p className="text-xs text-[#E8E2D4]/70 mt-1">
              Currently in {cabinNumber} · Carriage 14 · Passing Champagne region at 195 km/h
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleCallAttendant}
              className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-2 ${
                controls.attendantCalled
                  ? 'bg-emerald-900 border border-emerald-500 text-emerald-200'
                  : 'bg-[#152244] hover:bg-[#1E2E5C] border border-[#253358] text-[#C8A86B]'
              }`}
            >
              <Bell className="w-4 h-4 text-[#C8A86B]" />
              <span>{controls.attendantCalled ? 'Steward Notified' : 'Call Attendant'}</span>
            </button>

            {onExitToJourney && (
              <button
                onClick={onExitToJourney}
                className="px-3.5 py-2.5 rounded-lg bg-[#101D36] hover:bg-[#152244] text-[#E8E2D4] border border-[#253358] text-xs font-medium"
              >
                Journey View
              </button>
            )}
          </div>
        </div>

        {/* Attendant Alert Toast */}
        {attendantToast && (
          <div className="mt-4 p-3 rounded-lg bg-emerald-950 border border-emerald-600 text-xs text-emerald-200 flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>Cabin Attendant Marco V. has been notified and will attend to Compartment 204 shortly.</span>
          </div>
        )}

        {/* Tonight's onboard roadmap strip */}
        <div className="mt-6 pt-5 border-t border-[#1E294B] grid grid-cols-3 gap-3 text-center text-xs">
          <div className="p-2.5 rounded bg-[#070B18] border border-[#253358]">
            <span className="text-[10px] text-[#E8E2D4]/50 block">Tonight</span>
            <span className="font-semibold text-white">Dinner Service (18:30–22:00)</span>
          </div>
          <div className="p-2.5 rounded bg-[#070B18] border border-[#253358]">
            <span className="text-[10px] text-[#E8E2D4]/50 block">Quiet Hours</span>
            <span className="font-semibold text-[#DFBF83]">Sleep (22:00–06:30)</span>
          </div>
          <div className="p-2.5 rounded bg-[#070B18] border border-[#253358]">
            <span className="text-[10px] text-[#E8E2D4]/50 block">Morning</span>
            <span className="font-semibold text-white">Breakfast (06:30–07:30)</span>
          </div>
        </div>
      </div>

      {/* Onboard Service Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-[#253358]">
        {[
          { id: 'cabin', label: 'Cabin Smart Controls', icon: Lightbulb },
          { id: 'wakeup', label: 'Wake-Up Service', icon: Clock },
          { id: 'breakfast', label: 'Breakfast Selection', icon: Coffee },
          { id: 'dining', label: 'Dining Car & Wine', icon: UtensilsCrossed },
          { id: 'arrival', label: 'Arriving in Zürich HB', icon: Navigation }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-2 ${
                isActive
                  ? 'bg-[#C8A86B] text-[#070B18] shadow'
                  : 'bg-[#0B132B] text-[#E8E2D4]/70 hover:text-white border border-[#253358]'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#070B18]' : 'text-[#C8A86B]'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: CABIN SMART CONTROLS */}
      {activeTab === 'cabin' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Reading Light Intensity */}
          <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-[#C8A86B]" />
                <h4 className="text-sm font-bold text-white">Reading Lamp Dimmer</h4>
              </div>
              <span className="font-mono-tabular font-bold text-sm text-[#DFBF83]">
                {controls.readingLightBrightness}%
              </span>
            </div>

            <p className="text-xs text-[#E8E2D4]/70">
              Warm 2700K brass directional reading spotlight above the lower berth.
            </p>

            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={controls.readingLightBrightness}
              onChange={(e) => updateControl({ readingLightBrightness: Number(e.target.value) })}
              className="w-full accent-[#C8A86B] cursor-pointer"
            />

            <div className="flex justify-between text-[11px] text-[#E8E2D4]/50">
              <button
                onClick={() => updateControl({ readingLightBrightness: 0 })}
                className="hover:text-white"
              >
                Off (0%)
              </button>
              <button
                onClick={() => updateControl({ readingLightBrightness: 50 })}
                className="hover:text-white"
              >
                Soft Glow (50%)
              </button>
              <button
                onClick={() => updateControl({ readingLightBrightness: 100 })}
                className="hover:text-white"
              >
                Reading (100%)
              </button>
            </div>
          </div>

          {/* Cabin Temperature */}
          <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Thermometer className="w-5 h-5 text-sky-400" />
                <h4 className="text-sm font-bold text-white">Cabin Temperature</h4>
              </div>
              <span className="font-mono-tabular font-bold text-sm text-sky-300">
                {controls.cabinTemperatureCelsius.toFixed(1)}°C
              </span>
            </div>

            <p className="text-xs text-[#E8E2D4]/70">
              Quiet zoned ventilation with particulate air filtration.
            </p>

            <div className="flex items-center justify-center gap-4 py-2">
              <button
                type="button"
                onClick={() => updateControl({
                  cabinTemperatureCelsius: Math.max(18, Number((controls.cabinTemperatureCelsius - 0.5).toFixed(1)))
                })}
                className="w-10 h-10 rounded-full bg-[#101D36] border border-[#253358] text-white hover:border-[#C8A86B] text-lg font-bold"
              >
                –
              </button>
              <div className="font-mono-tabular text-2xl font-bold text-white">
                {controls.cabinTemperatureCelsius.toFixed(1)}°C
              </div>
              <button
                type="button"
                onClick={() => updateControl({
                  cabinTemperatureCelsius: Math.min(24, Number((controls.cabinTemperatureCelsius + 0.5).toFixed(1)))
                })}
                className="w-10 h-10 rounded-full bg-[#101D36] border border-[#253358] text-white hover:border-[#C8A86B] text-lg font-bold"
              >
                +
              </button>
            </div>

            <div className="text-center text-[11px] text-[#E8E2D4]/50">
              Optimal sleeping temperature: 19.5°C – 20.5°C
            </div>
          </div>

          {/* Privacy & DND Indicator */}
          <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Moon className="w-5 h-5 text-[#C8A86B]" />
                <h4 className="text-sm font-bold text-white">Privacy Indicator</h4>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                controls.privacyMode === 'dnd'
                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                  : controls.privacyMode === 'make_up_berth'
                  ? 'bg-blue-950 text-blue-300 border border-blue-800'
                  : 'bg-[#101D36] text-[#E8E2D4]/70'
              }`}>
                {controls.privacyMode === 'dnd' ? 'Do Not Disturb' : controls.privacyMode === 'make_up_berth' ? 'Make Up Berth' : 'Normal'}
              </span>
            </div>

            <p className="text-xs text-[#E8E2D4]/70">
              External electronic door indicator in the corridor.
            </p>

            <div className="grid grid-cols-3 gap-1.5 pt-1">
              <button
                type="button"
                onClick={() => updateControl({ privacyMode: 'normal' })}
                className={`py-2 px-1 text-[11px] font-medium rounded border transition-colors ${
                  controls.privacyMode === 'normal'
                    ? 'bg-[#152244] border-[#C8A86B] text-[#C8A86B]'
                    : 'bg-[#101D36] border-[#253358] text-[#E8E2D4]/70 hover:text-white'
                }`}
              >
                Normal
              </button>
              <button
                type="button"
                onClick={() => updateControl({ privacyMode: 'dnd' })}
                className={`py-2 px-1 text-[11px] font-medium rounded border transition-colors ${
                  controls.privacyMode === 'dnd'
                    ? 'bg-rose-950 border-rose-600 text-rose-200'
                    : 'bg-[#101D36] border-[#253358] text-[#E8E2D4]/70 hover:text-white'
                }`}
              >
                Do Not Disturb
              </button>
              <button
                type="button"
                onClick={() => updateControl({ privacyMode: 'make_up_berth' })}
                className={`py-2 px-1 text-[11px] font-medium rounded border transition-colors ${
                  controls.privacyMode === 'make_up_berth'
                    ? 'bg-sky-950 border-sky-600 text-sky-200'
                    : 'bg-[#101D36] border-[#253358] text-[#E8E2D4]/70 hover:text-white'
                }`}
              >
                Make Up Berth
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: WAKE-UP SERVICE */}
      {activeTab === 'wakeup' && (
        <div className="max-w-2xl mx-auto bg-[#0B132B] border border-[#253358] rounded-xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="text-center">
            <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
              GENTLE MORNING NOTIFICATION
            </span>
            <h3 className="font-serif-luxury text-2xl font-bold text-white mt-1">
              Wake Me Service
            </h3>
            <p className="text-xs text-[#E8E2D4]/70 mt-1">
              Your car steward will gently knock at your door and provide your selected morning hot beverage.
            </p>
          </div>

          {/* Wake-Up Option Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div
              onClick={() => handleRequestWakeUp('specific_time', '06:30')}
              className={`p-5 rounded-xl border text-center cursor-pointer transition-all ${
                controls.wakeUpOption === 'specific_time'
                  ? 'bg-[#152244] border-[#C8A86B] ring-1 ring-[#C8A86B]'
                  : 'bg-[#101D36] border-[#253358] hover:border-[#C8A86B]/50'
              }`}
            >
              <Clock className="w-6 h-6 text-[#C8A86B] mx-auto mb-2" />
              <div className="font-mono-tabular text-xl font-bold text-white">06:30</div>
              <div className="text-xs text-[#E8E2D4]/70 mt-1">Fixed Morning Time</div>
              <div className="text-[11px] text-[#C8A86B] font-semibold mt-2">
                {controls.wakeUpOption === 'specific_time' ? '✓ Wake-up Requested' : 'Select 06:30'}
              </div>
            </div>

            <div
              onClick={() => handleRequestWakeUp('30_min_before', '07:45')}
              className={`p-5 rounded-xl border text-center cursor-pointer transition-all ${
                controls.wakeUpOption === '30_min_before'
                  ? 'bg-[#152244] border-[#C8A86B] ring-1 ring-[#C8A86B]'
                  : 'bg-[#101D36] border-[#253358] hover:border-[#C8A86B]/50'
              }`}
            >
              <Compass className="w-6 h-6 text-[#C8A86B] mx-auto mb-2" />
              <div className="font-mono-tabular text-xl font-bold text-white">07:45</div>
              <div className="text-xs text-[#E8E2D4]/70 mt-1">30 Minutes Before Arrival</div>
              <div className="text-[11px] text-[#C8A86B] font-semibold mt-2">
                {controls.wakeUpOption === '30_min_before' ? '✓ Wake-up Requested' : 'Select 30m Prior'}
              </div>
            </div>
          </div>

          {/* Confirmed status card */}
          {controls.wakeUpConfirmed && (
            <div className="p-4 rounded-xl bg-emerald-950/70 border border-emerald-600 text-xs text-emerald-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Check className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <div className="font-bold text-white">Wake-up requested: {controls.wakeUpTime}</div>
                  <div className="text-[11px] text-emerald-300">
                    Steward Marco V. has registered your wake-up call for Compartment 204.
                  </div>
                </div>
              </div>
              <button
                onClick={() => updateControl({ wakeUpConfirmed: false, wakeUpOption: null })}
                className="text-[11px] text-rose-300 hover:text-white underline ml-3"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BREAKFAST SELECTION */}
      {activeTab === 'breakfast' && (
        <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-[#1E294B]">
            <div>
              <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
                MORNING HOSPITALITY
              </span>
              <h3 className="font-serif-luxury text-2xl font-bold text-white mt-0.5">
                Onboard Breakfast Selection
              </h3>
              <p className="text-xs text-[#E8E2D4]/70 mt-1">
                Served in your cabin or in the Restaurant Car between 06:30 and 07:30.
              </p>
            </div>
            <div className="px-3 py-1.5 rounded bg-[#152244] border border-[#253358] text-xs font-semibold text-[#DFBF83]">
              Delivery Window: 06:30 – 07:30
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              {
                id: 'continental',
                title: 'Continental Breakfast',
                desc: 'Warm croissant, French baguette, butter, Bonne Maman preserves, Swiss Gruyère cheese, freshly pressed orange juice.',
                allergens: 'Contains gluten, dairy'
              },
              {
                id: 'vegetarian',
                title: 'Alpine Vegetarian',
                desc: 'Swiss Birchermüesli with grated apples, toasted almonds, Greek yogurt, organic honey, hard-boiled free-range egg, artisan rye bread.',
                allergens: 'Contains nuts, dairy, egg'
              },
              {
                id: 'vegan',
                title: 'Plant-Based Vegan',
                desc: 'Chia seed coconut bowl with winter berries, avocado sourdough toast, cold-pressed green juice, oat milk café au lait.',
                allergens: 'Contains gluten, sesame'
              }
            ].map((option) => {
              const isSelected = controls.breakfastSelected === option.id;
              return (
                <div
                  key={option.id}
                  onClick={() => handleSelectBreakfast(option.id as any)}
                  className={`p-5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-[#152244] border-[#C8A86B] ring-1 ring-[#C8A86B]'
                      : 'bg-[#101D36] border-[#253358] hover:border-[#C8A86B]/50'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <h4 className="text-base font-bold text-white">{option.title}</h4>
                      {isSelected && <Check className="w-4 h-4 text-[#C8A86B]" />}
                    </div>
                    <p className="text-xs text-[#E8E2D4]/70 mt-2 leading-relaxed">
                      {option.desc}
                    </p>
                    <div className="mt-3 text-[10px] text-[#C8A86B]/80 font-mono-tabular">
                      Allergens: {option.allergens}
                    </div>
                  </div>

                  <button
                    type="button"
                    className={`mt-4 w-full py-2 text-xs font-bold uppercase rounded transition-colors ${
                      isSelected
                        ? 'bg-[#C8A86B] text-[#070B18]'
                        : 'bg-[#0B132B] text-[#E8E2D4]/70 hover:text-white border border-[#253358]'
                    }`}
                  >
                    {isSelected ? '✓ Selected for 07:00' : 'Select This Breakfast'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: DINING CAR & WINE */}
      {activeTab === 'dining' && (
        <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="relative h-56 w-full rounded-xl overflow-hidden border border-[#253358]">
            <Image
              src="/images/dining_car.jpg"
              alt="Restaurant Carriage Evening"
              fill
              className="object-cover"
              sizes="100vw"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0B132B] via-black/40 to-transparent" />
            <div className="absolute bottom-4 left-5 right-5 flex flex-col sm:flex-row sm:items-end justify-between gap-3 text-white">
              <div>
                <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
                  CARRIAGE 9 · RESTAURANT VOITURE
                </span>
                <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold">
                  Nightline Dining Car Service
                </h3>
                <span className="text-xs text-[#E8E2D4]/80">
                  Dinner service 18:30–22:00 · Bar open until midnight
                </span>
              </div>

              {/* Table reservation toggle */}
              <div className="bg-[#070B18]/90 border border-[#C8A86B]/50 p-3 rounded-lg flex items-center gap-2">
                <span className="text-xs text-[#E8E2D4]/80">Reserve Table:</span>
                <select
                  value={diningTime}
                  onChange={(e) => setDiningTime(e.target.value)}
                  className="bg-[#101D36] text-white text-xs rounded px-2 py-1 border border-[#253358]"
                >
                  <option value="19:00">19:00</option>
                  <option value="19:45">19:45</option>
                  <option value="20:30">20:30</option>
                  <option value="21:15">21:15</option>
                </select>
                <button
                  type="button"
                  onClick={() => setDiningReserved(!diningReserved)}
                  className="px-3 py-1 bg-[#C8A86B] text-[#070B18] text-xs font-bold rounded"
                >
                  {diningReserved ? '✓ Table Reserved' : 'Book Table'}
                </button>
              </div>
            </div>
          </div>

          {/* Dinner Menu Preview */}
          <div>
            <h4 className="text-sm font-bold tracking-wider text-[#C8A86B] uppercase mb-4">
              Tonight’s 3-Course Winter Menu
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {DINING_MENU.slice(0, 6).map((item) => (
                <div key={item.id} className="p-3.5 bg-[#101D36] border border-[#253358] rounded-lg">
                  <div className="flex items-baseline justify-between">
                    <h5 className="text-sm font-bold text-white">{item.name}</h5>
                    <span className="font-mono-tabular text-xs text-[#DFBF83] font-bold">
                      £{item.priceGbp}
                    </span>
                  </div>
                  <p className="text-xs text-[#E8E2D4]/70 mt-1 leading-relaxed">
                    {item.description}
                  </p>
                  {item.pairing && (
                    <div className="mt-2 text-[11px] text-[#C8A86B]/90 font-medium">
                      Sommelier Pairing: {item.pairing}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: ARRIVAL & ONWARD TRANSIT */}
      {activeTab === 'arrival' && (
        <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
              FINAL APPROACH
            </span>
            <h3 className="font-serif-luxury text-3xl font-bold text-white mt-1">
              Arriving in Zürich HB
            </h3>
            <p className="text-xs text-[#E8E2D4]/70 mt-1">
              Scheduled Arrival: 08:15 · Track 7 (Gleis 7) · Weather: Crisp & Clear 10°C
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-[#101D36] border border-[#253358] rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-[#C8A86B]">
                <Train className="w-5 h-5" />
                <h4 className="text-sm font-bold text-white">Zürich S-Bahn</h4>
              </div>
              <p className="text-xs text-[#E8E2D4]/70">
                Direct connections to Zürich Airport every 6 mins on S2 & S16 (9 mins travel time).
              </p>
              <div className="text-[10px] text-emerald-400 font-semibold">Underground Tracks 31–34</div>
            </div>

            <div className="p-4 bg-[#101D36] border border-[#253358] rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-[#C8A86B]">
                <Navigation className="w-5 h-5" />
                <h4 className="text-sm font-bold text-white">VBZ Tram Lines</h4>
              </div>
              <p className="text-xs text-[#E8E2D4]/70">
                Trams 3, 4, 10, 11, 13, 14 stop at Bahnhofplatz directly outside the main exit.
              </p>
              <div className="text-[10px] text-emerald-400 font-semibold">Street Level Main Portal</div>
            </div>

            <div className="p-4 bg-[#101D36] border border-[#253358] rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-[#C8A86B]">
                <Car className="w-5 h-5" />
                <h4 className="text-sm font-bold text-white">Taxi & Transfers</h4>
              </div>
              <p className="text-xs text-[#E8E2D4]/70">
                Dedicated taxi ranks at Bahnhofplatz and Museumstrasse. Pre-booked valets meet on Track 7.
              </p>
              <div className="text-[10px] text-emerald-400 font-semibold">North & South Exits</div>
            </div>

            <div className="p-4 bg-[#101D36] border border-[#253358] rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-[#C8A86B]">
                <Footprints className="w-5 h-5" />
                <h4 className="text-sm font-bold text-white">Old Town Walk</h4>
              </div>
              <p className="text-xs text-[#E8E2D4]/70">
                Bahnhofstrasse luxury shopping and historic Altstadt are within 5 minutes walking distance.
              </p>
              <div className="text-[10px] text-emerald-400 font-semibold">Pedestrian Zone Direct</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
