'use client';

import React, { useState } from 'react';
import { User, Plus, Trash2, Check, ShieldCheck, Coffee, Utensils, Wine, Sparkles, Bike, Heart, ShowerHead, Car, ChevronRight, ArrowLeft } from 'lucide-react';
import { Passenger, BookingExtra, CabinClass, TrainSchedule, Currency } from '@/lib/types';
import { BOOKING_EXTRAS } from '@/lib/mock-data';
import { formatPrice } from '@/lib/storage';

interface PassengerAndExtrasFormProps {
  passengers: Passenger[];
  selectedExtras: BookingExtra[];
  train: TrainSchedule;
  cabin: CabinClass;
  selectedBerth: string;
  currency: Currency;
  onUpdatePassengers: (passengers: Passenger[]) => void;
  onToggleExtra: (extra: BookingExtra) => void;
  onBack: () => void;
  onProceedToPayment: () => void;
}

export const PassengerAndExtrasForm: React.FC<PassengerAndExtrasFormProps> = ({
  passengers,
  selectedExtras,
  train,
  cabin,
  selectedBerth,
  currency,
  onUpdatePassengers,
  onToggleExtra,
  onBack,
  onProceedToPayment
}) => {
  const [passengerList, setPassengerList] = useState<Passenger[]>(
    passengers.length > 0
      ? passengers
      : [
          {
            id: 'p-1',
            type: 'adult',
            title: 'Mr',
            firstName: 'Thomas',
            lastName: 'Harding',
            passportNumber: 'GB98234812',
            railcard: 'Eurail / Interrail Pass',
            dietaryPreference: 'continental',
            berthSelection: selectedBerth
          }
        ]
  );

  const handlePassengerChange = (index: number, field: keyof Passenger, value: any) => {
    const updated = [...passengerList];
    updated[index] = { ...updated[index], [field]: value };
    setPassengerList(updated);
    onUpdatePassengers(updated);
  };

  const handleAddPassenger = () => {
    if (passengerList.length >= cabin.maxOccupancy) return;
    const newPassenger: Passenger = {
      id: `p-${passengerList.length + 1}`,
      type: 'adult',
      title: 'Ms',
      firstName: '',
      lastName: '',
      dietaryPreference: 'continental'
    };
    const updated = [...passengerList, newPassenger];
    setPassengerList(updated);
    onUpdatePassengers(updated);
  };

  const handleRemovePassenger = (index: number) => {
    if (passengerList.length <= 1) return;
    const updated = passengerList.filter((_, i) => i !== index);
    setPassengerList(updated);
    onUpdatePassengers(updated);
  };

  // Calculate pricing breakdown
  const cabinBaseTotal = cabin.priceFromGbp * passengerList.length;
  const extrasTotal = selectedExtras.reduce((sum, item) => sum + item.priceGbp, 0);
  const totalGbp = cabinBaseTotal + extrasTotal;

  // Icon mapping helper
  const renderExtraIcon = (iconName: string) => {
    switch (iconName) {
      case 'Coffee': return <Coffee className="w-5 h-5 text-[#C8A86B]" />;
      case 'Utensils': return <Utensils className="w-5 h-5 text-[#C8A86B]" />;
      case 'Wine': return <Wine className="w-5 h-5 text-[#C8A86B]" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-[#C8A86B]" />;
      case 'Bike': return <Bike className="w-5 h-5 text-[#C8A86B]" />;
      case 'Heart': return <Heart className="w-5 h-5 text-[#C8A86B]" />;
      case 'ShowerHead': return <ShowerHead className="w-5 h-5 text-[#C8A86B]" />;
      case 'Car': return <Car className="w-5 h-5 text-[#C8A86B]" />;
      default: return <Sparkles className="w-5 h-5 text-[#C8A86B]" />;
    }
  };

  return (
    <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Left 8 Columns: Passenger Details & Extras Selection */}
      <div className="lg:col-span-8 space-y-8">
        {/* Passenger Information */}
        <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-6 shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-[#1E294B] mb-5">
            <div>
              <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
                STEP 3 OF 4
              </span>
              <h3 className="text-xl font-bold text-white mt-0.5">
                Passenger Details
              </h3>
            </div>
            {passengerList.length < cabin.maxOccupancy && (
              <button
                type="button"
                onClick={handleAddPassenger}
                className="px-3 py-1.5 bg-[#152244] hover:bg-[#1E2E5C] text-[#C8A86B] text-xs font-semibold rounded flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Passenger ({passengerList.length}/{cabin.maxOccupancy})</span>
              </button>
            )}
          </div>

          <div className="space-y-6">
            {passengerList.map((passenger, idx) => (
              <div key={passenger.id} className="p-4 bg-[#101D36] border border-[#253358] rounded-lg space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#C8A86B] uppercase tracking-wider">
                    Passenger {idx + 1} ({passenger.type})
                  </span>
                  {idx > 0 && (
                    <button
                      type="button"
                      onClick={() => handleRemovePassenger(idx)}
                      className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">Title</label>
                    <select
                      value={passenger.title}
                      onChange={(e) => handlePassengerChange(idx, 'title', e.target.value)}
                      className="w-full bg-[#0B132B] border border-[#253358] text-white rounded px-2.5 py-2 text-xs focus:outline-none"
                    >
                      <option value="Mr">Mr</option>
                      <option value="Ms">Ms</option>
                      <option value="Mrs">Mrs</option>
                      <option value="Dr">Dr</option>
                    </select>
                  </div>

                  <div className="sm:col-span-5">
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">First Name</label>
                    <input
                      type="text"
                      value={passenger.firstName}
                      placeholder="e.g. Thomas"
                      onChange={(e) => handlePassengerChange(idx, 'firstName', e.target.value)}
                      className="w-full bg-[#0B132B] border border-[#253358] text-white rounded px-2.5 py-2 text-xs focus:border-[#C8A86B] focus:outline-none"
                      required
                    />
                  </div>

                  <div className="sm:col-span-5">
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">Last Name</label>
                    <input
                      type="text"
                      value={passenger.lastName}
                      placeholder="e.g. Harding"
                      onChange={(e) => handlePassengerChange(idx, 'lastName', e.target.value)}
                      className="w-full bg-[#0B132B] border border-[#253358] text-white rounded px-2.5 py-2 text-xs focus:border-[#C8A86B] focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">Passport / European National ID</label>
                    <input
                      type="text"
                      value={passenger.passportNumber || ''}
                      placeholder="e.g. GB98234812"
                      onChange={(e) => handlePassengerChange(idx, 'passportNumber', e.target.value)}
                      className="w-full bg-[#0B132B] border border-[#253358] text-white rounded px-2.5 py-2 text-xs focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">Dietary Preference</label>
                    <select
                      value={passenger.dietaryPreference || 'continental'}
                      onChange={(e) => handlePassengerChange(idx, 'dietaryPreference', e.target.value)}
                      className="w-full bg-[#0B132B] border border-[#253358] text-white rounded px-2.5 py-2 text-xs focus:outline-none"
                    >
                      <option value="continental">Continental Bakery</option>
                      <option value="vegetarian">Alpine Vegetarian</option>
                      <option value="vegan">Plant-Based Vegan</option>
                      <option value="gluten_free">Gluten-Free</option>
                    </select>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tailored Overnight Extras */}
        <div className="bg-[#0B132B] border border-[#253358] rounded-xl p-6 shadow-xl">
          <div className="pb-4 border-b border-[#1E294B] mb-5">
            <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
              ONBOARD SERVICES & AMENITIES
            </span>
            <h3 className="text-xl font-bold text-white mt-0.5">
              Personalise Your Sleeper Journey
            </h3>
            <p className="text-xs text-[#E8E2D4]/70 mt-1">
              Carefully curated dining, luggage, and arrival transfers. All options remain fully modifiable until departure.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {BOOKING_EXTRAS.map((extra) => {
              const isSelected = selectedExtras.some(e => e.id === extra.id);
              const isIncludedInCabin = extra.includedForCabins?.includes(cabin.id);

              return (
                <div
                  key={extra.id}
                  onClick={() => !isIncludedInCabin && onToggleExtra(extra)}
                  className={`p-4 rounded-xl border transition-all flex items-start gap-3.5 cursor-pointer ${
                    isIncludedInCabin
                      ? 'bg-[#152244]/40 border-[#C8A86B]/30 cursor-default'
                      : isSelected
                      ? 'bg-[#152244] border-[#C8A86B] ring-1 ring-[#C8A86B]'
                      : 'bg-[#101D36] border-[#253358] hover:border-[#C8A86B]/40'
                  }`}
                >
                  <div className="p-2 rounded-lg bg-[#070B18] border border-[#253358] shrink-0">
                    {renderExtraIcon(extra.iconName)}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-white">{extra.name}</h4>
                      <span className="text-xs font-bold text-[#C8A86B] font-mono-tabular ml-2">
                        {isIncludedInCabin ? 'INCLUDED' : formatPrice(extra.priceGbp, currency)}
                      </span>
                    </div>

                    <p className="text-[11px] text-[#E8E2D4]/70 mt-1 leading-snug">
                      {extra.description}
                    </p>

                    <div className="mt-2 flex items-center justify-between">
                      {isIncludedInCabin ? (
                        <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                          ✓ Complimentary with {cabin.name}
                        </span>
                      ) : (
                        <span className="text-[10px] text-[#E8E2D4]/60">
                          {isSelected ? '✓ Added to booking' : '+ Click to add'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right 4 Columns: Persistent Sticky Journey Summary */}
      <div className="lg:col-span-4 sticky top-24 space-y-4">
        <div className="bg-[#0B132B] border border-[#C8A86B]/40 rounded-xl p-5 shadow-2xl">
          <div className="pb-3 border-b border-[#1E294B]">
            <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
              JOURNEY SUMMARY
            </span>
            <h4 className="text-lg font-bold text-white mt-0.5">
              {train.trainName} ({train.trainNumber})
            </h4>
          </div>

          <div className="py-4 space-y-3 text-xs border-b border-[#1E294B]">
            <div className="flex justify-between items-center">
              <span className="text-[#E8E2D4]/60">Route:</span>
              <span className="font-semibold text-white">London St Pancras → Zürich HB</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#E8E2D4]/60">Departure:</span>
              <span className="font-mono-tabular text-white font-medium">Tonight, 20:40</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#E8E2D4]/60">Arrival:</span>
              <span className="font-mono-tabular text-white font-medium">Tomorrow, 08:15 (Track 7)</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#E8E2D4]/60">Cabin Class:</span>
              <span className="font-semibold text-[#DFBF83]">{cabin.name}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#E8E2D4]/60">Berth:</span>
              <span className="font-mono-tabular text-white">{selectedBerth || 'Carriage 14'}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#E8E2D4]/60">Passengers:</span>
              <span className="text-white font-medium">{passengerList.length} Traveler{passengerList.length > 1 ? 's' : ''}</span>
            </div>
          </div>

          {/* Pricing Breakdown */}
          <div className="py-4 space-y-2 text-xs border-b border-[#1E294B]">
            <div className="flex justify-between">
              <span className="text-[#E8E2D4]/70">
                Cabin ({passengerList.length} × {formatPrice(cabin.priceFromGbp, currency)}):
              </span>
              <span className="font-mono-tabular text-white">
                {formatPrice(cabinBaseTotal, currency)}
              </span>
            </div>

            {selectedExtras.map(extra => (
              <div key={extra.id} className="flex justify-between text-[#E8E2D4]/80">
                <span className="truncate max-w-[200px]">{extra.name}:</span>
                <span className="font-mono-tabular text-white">
                  {formatPrice(extra.priceGbp, currency)}
                </span>
              </div>
            ))}

            <div className="flex justify-between text-emerald-400 pt-1">
              <span>CO₂ Saved vs Flight:</span>
              <span className="font-bold">198 kg CO₂e</span>
            </div>
          </div>

          {/* Total Amount */}
          <div className="pt-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#E8E2D4]/60 uppercase tracking-wider block">
                TOTAL PRICE
              </span>
              <span className="text-2xl font-bold font-mono-tabular text-white">
                {formatPrice(totalGbp, currency)}
              </span>
            </div>

            <button
              type="button"
              onClick={onProceedToPayment}
              className="px-6 py-3 bg-[#C8A86B] hover:bg-[#DFBF83] text-[#070B18] font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-1.5 shadow-lg"
            >
              <span>Continue to Payment</span>
              <ChevronRight className="w-4 h-4 text-[#070B18]" />
            </button>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1E294B] flex items-center gap-2 text-[10px] text-[#E8E2D4]/60">
            <ShieldCheck className="w-4 h-4 text-[#C8A86B]" />
            <span>Free cancellation up to 48 hours before scheduled departure.</span>
          </div>
        </div>

        <button
          type="button"
          onClick={onBack}
          className="w-full py-2.5 text-xs text-[#E8E2D4]/70 hover:text-white flex items-center justify-center gap-2 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Cabin Selection</span>
        </button>
      </div>
    </div>
  );
};
