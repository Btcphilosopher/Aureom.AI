'use client';

import React, { useState } from 'react';
import { CreditCard, ShieldCheck, Lock, CheckCircle2, ArrowRight, X, Smartphone, Landmark } from 'lucide-react';
import { Booking, Currency, TrainSchedule, CabinClass, BookingExtra, Passenger } from '@/lib/types';
import { formatPrice, saveBooking } from '@/lib/storage';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  train: TrainSchedule;
  cabin: CabinClass;
  selectedBerth: string;
  passengers: Passenger[];
  extras: BookingExtra[];
  travelDate: string;
  currency: Currency;
  onPaymentSuccess: (booking: Booking) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  train,
  cabin,
  selectedBerth,
  passengers,
  extras,
  travelDate,
  currency,
  onPaymentSuccess
}) => {
  const [method, setMethod] = useState<'card' | 'apple' | 'sepa'>('card');
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('10/28');
  const [cardCvc, setCardCvc] = useState('742');
  const [cardHolder, setCardHolder] = useState(
    passengers[0]?.firstName ? `${passengers[0].firstName} ${passengers[0].lastName}` : 'Thomas Harding'
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  if (!isOpen) return null;

  const cabinBaseTotal = cabin.priceFromGbp * Math.max(1, passengers.length);
  const extrasTotal = extras.reduce((sum, item) => sum + item.priceGbp, 0);
  const totalGbp = cabinBaseTotal + extrasTotal;

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Realistic seamless transport booking simulation
    setTimeout(() => {
      const newReference = `NL-${Math.floor(1000 + Math.random() * 9000)}-${train.toStationCode}`;
      const newBooking: Booking = {
        id: `book-${Date.now()}`,
        reference: newReference,
        createdAt: new Date().toISOString(),
        train,
        travelDate: travelDate || '2026-10-16',
        cabinClass: cabin,
        cabinNumber: 'Carriage 14, Cabin 204',
        selectedBerthLabels: [selectedBerth || 'Lower Berth (Comfort Access)'],
        passengers,
        extras,
        totalAmountGbp: totalGbp,
        currency,
        status: 'confirmed',
        qrCodeToken: `${train.trainNumber}-${train.fromStationCode}-${train.toStationCode}-${travelDate}-CAB204-${newReference}`
      };

      saveBooking(newBooking);
      setIsProcessing(false);
      setIsComplete(true);

      setTimeout(() => {
        onPaymentSuccess(newBooking);
      }, 1200);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="w-full max-w-lg bg-[#0B132B] border border-[#253358] rounded-2xl shadow-2xl overflow-hidden relative">
        {/* Modal Header */}
        <div className="p-5 border-b border-[#1E294B] flex items-center justify-between bg-[#070B18]">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#C8A86B]" />
            <h3 className="text-base font-bold text-white tracking-wide">
              Secure Transport Payment
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-[#E8E2D4]/60 hover:text-white p-1 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {isComplete ? (
            <div className="py-10 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-950 border-2 border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center shadow-lg animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-xl font-bold text-white">Booking Confirmed</h4>
              <p className="text-xs text-[#E8E2D4]/70 max-w-xs mx-auto">
                Payment verified. Generating your authentic digital railway ticket...
              </p>
            </div>
          ) : (
            <form onSubmit={handlePay} className="space-y-5">
              {/* Persistent Journey Summary Box */}
              <div className="p-3.5 bg-[#101D36] border border-[#253358] rounded-xl flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white">
                    {train.fromStationCode === 'STP' ? 'London St Pancras' : train.fromStationCode} → {train.toStationCode === 'ZUR' ? 'Zürich HB' : train.toStationCode}
                  </div>
                  <div className="text-[11px] text-[#E8E2D4]/70">
                    {cabin.name} · {selectedBerth || 'Berth'} · {passengers.length} Passenger{passengers.length > 1 ? 's' : ''}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-[#E8E2D4]/60 uppercase">Amount</div>
                  <div className="text-base font-bold font-mono-tabular text-[#DFBF83]">
                    {formatPrice(totalGbp, currency)}
                  </div>
                </div>
              </div>

              {/* Payment Methods tabs */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setMethod('card')}
                  className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                    method === 'card'
                      ? 'bg-[#152244] border-[#C8A86B] text-white'
                      : 'bg-[#101D36] border-[#253358] text-[#E8E2D4]/70 hover:text-white'
                  }`}
                >
                  <CreditCard className="w-3.5 h-3.5 text-[#C8A86B]" />
                  <span>Card</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('apple')}
                  className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                    method === 'apple'
                      ? 'bg-[#152244] border-[#C8A86B] text-white'
                      : 'bg-[#101D36] border-[#253358] text-[#E8E2D4]/70 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5 text-[#C8A86B]" />
                  <span>Apple Pay</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('sepa')}
                  className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                    method === 'sepa'
                      ? 'bg-[#152244] border-[#C8A86B] text-white'
                      : 'bg-[#101D36] border-[#253358] text-[#E8E2D4]/70 hover:text-white'
                  }`}
                >
                  <Landmark className="w-3.5 h-3.5 text-[#C8A86B]" />
                  <span>SEPA</span>
                </button>
              </div>

              {/* Payment Fields */}
              {method === 'card' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">Cardholder Name</label>
                    <input
                      type="text"
                      value={cardHolder}
                      onChange={(e) => setCardHolder(e.target.value)}
                      className="w-full bg-[#101D36] border border-[#253358] text-white rounded px-3 py-2 text-xs focus:border-[#C8A86B] focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">Card Number</label>
                    <div className="relative">
                      <input
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        className="w-full bg-[#101D36] border border-[#253358] text-white rounded px-3 py-2 text-xs font-mono-tabular focus:border-[#C8A86B] focus:outline-none"
                        required
                      />
                      <CreditCard className="w-4 h-4 text-[#C8A86B] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">Expiry Date</label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        className="w-full bg-[#101D36] border border-[#253358] text-white rounded px-3 py-2 text-xs font-mono-tabular focus:border-[#C8A86B] focus:outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">CVC / CVV</label>
                      <input
                        type="text"
                        value={cardCvc}
                        onChange={(e) => setCardCvc(e.target.value)}
                        className="w-full bg-[#101D36] border border-[#253358] text-white rounded px-3 py-2 text-xs font-mono-tabular focus:border-[#C8A86B] focus:outline-none"
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {method === 'apple' && (
                <div className="p-4 bg-[#101D36] border border-[#253358] rounded-xl text-center space-y-2">
                  <Smartphone className="w-8 h-8 text-[#C8A86B] mx-auto" />
                  <p className="text-xs text-[#E8E2D4]/80">
                    Authenticate using Touch ID, Face ID, or your Apple Wallet passkey.
                  </p>
                </div>
              )}

              {method === 'sepa' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">IBAN Account Number</label>
                    <input
                      type="text"
                      defaultValue="DE89 3704 0044 0532 0130 00"
                      className="w-full bg-[#101D36] border border-[#253358] text-white rounded px-3 py-2 text-xs font-mono-tabular focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-[#E8E2D4]/70 mb-1">Account Holder</label>
                    <input
                      type="text"
                      defaultValue={cardHolder}
                      className="w-full bg-[#101D36] border border-[#253358] text-white rounded px-3 py-2 text-xs focus:outline-none"
                    />
                  </div>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full py-3.5 bg-[#C8A86B] hover:bg-[#DFBF83] text-[#070B18] font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
                >
                  {isProcessing ? (
                    <span>Processing Secure Reservation...</span>
                  ) : (
                    <>
                      <span>Confirm & Issue Ticket ({formatPrice(totalGbp, currency)})</span>
                      <ArrowRight className="w-4 h-4 text-[#070B18]" />
                    </>
                  )}
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 text-[10px] text-[#E8E2D4]/50">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>256-bit SSL encrypted · European Rail Passenger Rights Certified</span>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
