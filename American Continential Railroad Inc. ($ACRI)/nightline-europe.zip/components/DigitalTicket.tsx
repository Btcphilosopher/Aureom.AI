'use client';

import React, { useState } from 'react';
import { Download, Share2, Smartphone, Check, Moon, ShieldCheck, Printer, X, Sparkles, Train } from 'lucide-react';
import { Booking } from '@/lib/types';

interface DigitalTicketProps {
  booking: Booking;
  onClose?: () => void;
  isModal?: boolean;
}

export const DigitalTicket: React.FC<DigitalTicketProps> = ({
  booking,
  onClose,
  isModal = false
}) => {
  const [walletSaved, setWalletSaved] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  const passenger = booking.passengers[0] || { firstName: 'Thomas', lastName: 'Harding' };
  const originCity = booking.train.fromStationCode === 'STP' ? 'LONDON' : booking.train.fromStationCode;
  const destinationCity = booking.train.toStationCode === 'ZUR' ? 'ZÜRICH' : booking.train.toStationCode;

  const handleSaveToWallet = () => {
    setWalletSaved(true);
    setTimeout(() => setWalletSaved(false), 3000);
  };

  const handlePrint = () => {
    setDownloaded(true);
    if (typeof window !== 'undefined') {
      window.print();
    }
    setTimeout(() => setDownloaded(false), 3000);
  };

  const ticketContent = (
    <div className="w-full max-w-xl mx-auto">
      {/* Physical-Ticket-Inspired Boarding Document */}
      <div className="bg-[#0B132B] border-2 border-[#C8A86B]/60 rounded-2xl overflow-hidden shadow-2xl relative text-white">
        {/* Ticket Header Ribbon */}
        <div className="bg-[#070B18] px-6 py-4 border-b border-[#253358] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded bg-[#101D36] border border-[#C8A86B] flex items-center justify-center text-[#C8A86B]">
              <Moon className="w-3.5 h-3.5 fill-[#C8A86B]/30" />
            </div>
            <div>
              <span className="font-serif-luxury text-lg tracking-[0.15em] font-bold text-white block leading-tight">
                NIGHTLINE EUROPE
              </span>
              <span className="text-[9px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
                INTERNATIONAL OVERNIGHT PASSENGER TICKET
              </span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-[#E8E2D4]/60 uppercase block font-mono-tabular">REF NUMBER</span>
            <span className="font-mono-tabular font-bold text-sm text-[#DFBF83]">
              {booking.reference}
            </span>
          </div>
        </div>

        {/* Core Journey Header */}
        <div className="p-6 bg-gradient-to-b from-[#101D36] to-[#0B132B]">
          <div className="flex items-baseline justify-between mb-4">
            <div>
              <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
                ORIGIN
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold font-serif-luxury tracking-wide text-white">
                {originCity}
              </h2>
              <span className="text-xs text-[#E8E2D4]/70">St Pancras Int.</span>
            </div>

            <div className="flex flex-col items-center px-4">
              <span className="text-[10px] font-mono-tabular text-[#DFBF83] tracking-wider mb-1">
                OVERNIGHT EXPRESS
              </span>
              <div className="w-24 sm:w-32 h-[1px] bg-[#C8A86B]/60 relative flex items-center justify-center">
                <Train className="w-3.5 h-3.5 text-[#C8A86B] bg-[#0B132B] px-0.5" />
              </div>
              <span className="text-[10px] text-emerald-400 font-semibold mt-1">11h 35m Direct</span>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase block">
                DESTINATION
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold font-serif-luxury tracking-wide text-white">
                {destinationCity}
              </h2>
              <span className="text-xs text-[#E8E2D4]/70">Hauptbahnhof (HB)</span>
            </div>
          </div>

          {/* Core Departure Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-[#070B18]/70 border border-[#253358] rounded-xl text-xs">
            <div>
              <span className="text-[10px] text-[#E8E2D4]/50 uppercase font-mono-tabular block">DATE</span>
              <span className="font-bold text-white text-sm">16 OCT 2026</span>
            </div>
            <div>
              <span className="text-[10px] text-[#E8E2D4]/50 uppercase font-mono-tabular block">TRAIN</span>
              <span className="font-bold text-[#C8A86B] text-sm">{booking.train.trainNumber}</span>
            </div>
            <div>
              <span className="text-[10px] text-[#E8E2D4]/50 uppercase font-mono-tabular block">DEPARTURE</span>
              <span className="font-mono-tabular font-bold text-white text-sm">20:40</span>
            </div>
            <div>
              <span className="text-[10px] text-[#E8E2D4]/50 uppercase font-mono-tabular block">ARRIVAL</span>
              <span className="font-mono-tabular font-bold text-white text-sm">08:15 (+1)</span>
            </div>
          </div>
        </div>

        {/* Perforated Tear Notch Dividers */}
        <div className="relative py-2 bg-[#0B132B]">
          <div className="border-t-2 border-dashed border-[#C8A86B]/40 w-full" />
          {/* Left Cutout */}
          <div className="w-6 h-6 rounded-full bg-[#070B18] border-r-2 border-[#C8A86B]/60 absolute -left-3 top-1/2 -translate-y-1/2" />
          {/* Right Cutout */}
          <div className="w-6 h-6 rounded-full bg-[#070B18] border-l-2 border-[#C8A86B]/60 absolute -right-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* Berth & Passenger Section with High-Contrast QR Code */}
        <div className="p-6 grid grid-cols-1 sm:grid-cols-12 gap-6 items-center bg-[#070B18]">
          <div className="sm:col-span-7 space-y-3">
            <div>
              <span className="text-[10px] text-[#E8E2D4]/50 uppercase font-mono-tabular block">PASSENGER</span>
              <span className="text-base font-bold text-white tracking-wide">
                {passenger.title ? `${passenger.title} ` : ''}{passenger.firstName} {passenger.lastName}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-[10px] text-[#E8E2D4]/50 uppercase font-mono-tabular block">CABIN ACCOMMODATION</span>
                <span className="font-semibold text-[#DFBF83]">{booking.cabinClass.name}</span>
                <span className="block text-[11px] text-[#E8E2D4]/70">Carriage 14 · Cabin 204</span>
              </div>
              <div>
                <span className="text-[10px] text-[#E8E2D4]/50 uppercase font-mono-tabular block">BERTH ALLOCATION</span>
                <span className="font-bold text-white">LOWER BERTH</span>
                <span className="block text-[11px] text-emerald-400">Window Facing (L1)</span>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3 text-[11px] text-[#E8E2D4]/70">
              <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
                <Check className="w-3.5 h-3.5" /> Checked In
              </span>
              <span>·</span>
              <span>Lounge Access Included</span>
              <span>·</span>
              <span>Starlink Wi-Fi 6</span>
            </div>
          </div>

          {/* SVG Scannable QR Code */}
          <div className="sm:col-span-5 flex flex-col items-center justify-center p-3.5 bg-white rounded-xl shadow-lg">
            <svg viewBox="0 0 120 120" className="w-28 h-28">
              {/* QR Code Matrix Elements */}
              <rect width="120" height="120" fill="white" />
              {/* Top-Left Finder */}
              <rect x="10" y="10" width="30" height="30" fill="#070B18" />
              <rect x="15" y="15" width="20" height="20" fill="white" />
              <rect x="20" y="20" width="10" height="10" fill="#070B18" />

              {/* Top-Right Finder */}
              <rect x="80" y="10" width="30" height="30" fill="#070B18" />
              <rect x="85" y="15" width="20" height="20" fill="white" />
              <rect x="90" y="20" width="10" height="10" fill="#070B18" />

              {/* Bottom-Left Finder */}
              <rect x="10" y="80" width="30" height="30" fill="#070B18" />
              <rect x="15" y="85" width="20" height="20" fill="white" />
              <rect x="20" y="90" width="10" height="10" fill="#070B18" />

              {/* Data modules */}
              <rect x="45" y="15" width="6" height="6" fill="#070B18" />
              <rect x="55" y="15" width="6" height="6" fill="#070B18" />
              <rect x="65" y="20" width="6" height="6" fill="#070B18" />
              <rect x="45" y="30" width="6" height="6" fill="#070B18" />
              <rect x="60" y="35" width="6" height="6" fill="#070B18" />

              <rect x="15" y="45" width="6" height="6" fill="#070B18" />
              <rect x="25" y="55" width="6" height="6" fill="#070B18" />
              <rect x="35" y="50" width="6" height="6" fill="#070B18" />
              <rect x="45" y="45" width="8" height="8" fill="#C8A86B" />
              <rect x="55" y="55" width="10" height="10" fill="#070B18" />
              <rect x="70" y="45" width="6" height="6" fill="#070B18" />
              <rect x="85" y="55" width="6" height="6" fill="#070B18" />
              <rect x="95" y="45" width="6" height="6" fill="#070B18" />

              <rect x="45" y="70" width="6" height="6" fill="#070B18" />
              <rect x="60" y="75" width="6" height="6" fill="#070B18" />
              <rect x="75" y="70" width="6" height="6" fill="#070B18" />
              <rect x="50" y="85" width="6" height="6" fill="#070B18" />
              <rect x="65" y="90" width="6" height="6" fill="#070B18" />
              <rect x="80" y="85" width="6" height="6" fill="#070B18" />
              <rect x="95" y="90" width="6" height="6" fill="#070B18" />
            </svg>
            <span className="text-[9px] font-mono-tabular text-slate-800 font-bold tracking-widest mt-1">
              NL-402-BOARDING-PASS
            </span>
          </div>
        </div>

        {/* Barcode & Security Strip Footer */}
        <div className="bg-[#101D36] px-6 py-3 border-t border-[#253358] flex items-center justify-between text-[10px] text-[#E8E2D4]/60 font-mono-tabular">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Valid for St Pancras Eurostar Gates & Zürich HB</span>
          </div>
          <span className="text-[#DFBF83] font-bold">ISSUED · 13 OCT 2026</span>
        </div>
      </div>

      {/* Action Controls */}
      <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
        <button
          type="button"
          onClick={handleSaveToWallet}
          className="px-4 py-2.5 bg-[#152244] hover:bg-[#1E2E5C] text-[#C8A86B] border border-[#253358] hover:border-[#C8A86B] text-xs font-semibold rounded-lg flex items-center gap-2 transition-all shadow"
        >
          <Smartphone className="w-4 h-4" />
          <span>{walletSaved ? '✓ Added to Apple / Google Wallet' : 'Add to Mobile Wallet'}</span>
        </button>

        <button
          type="button"
          onClick={handlePrint}
          className="px-4 py-2.5 bg-[#152244] hover:bg-[#1E2E5C] text-white border border-[#253358] text-xs font-semibold rounded-lg flex items-center gap-2 transition-all shadow"
        >
          <Printer className="w-4 h-4 text-[#C8A86B]" />
          <span>{downloaded ? 'Preparing Pass...' : 'Print / Save PDF Pass'}</span>
        </button>
      </div>

      <div className="mt-3 text-center text-xs text-[#E8E2D4]/50">
        Offline-Ready: This digital ticket is stored on your device and can be scanned without an active mobile network connection.
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
        <div className="relative w-full max-w-xl my-8">
          <button
            onClick={onClose}
            className="absolute -top-10 right-0 text-white/80 hover:text-white p-1 rounded-md"
          >
            <X className="w-6 h-6" />
          </button>
          {ticketContent}
        </div>
      </div>
    );
  }

  return ticketContent;
};
