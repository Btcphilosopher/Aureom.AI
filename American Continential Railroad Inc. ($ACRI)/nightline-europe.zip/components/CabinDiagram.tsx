'use client';

import React from 'react';
import { Bed, Check, Sparkles, Wind, Lightbulb, Shield, ShieldCheck } from 'lucide-react';
import { CabinClass, CabinCategory } from '@/lib/types';

interface CabinDiagramProps {
  cabin: CabinClass;
  selectedBerth: string;
  onSelectBerth: (berthId: string) => void;
  cabinNumber?: string;
}

export const CabinDiagram: React.FC<CabinDiagramProps> = ({
  cabin,
  selectedBerth,
  onSelectBerth,
  cabinNumber = 'Compartment 204'
}) => {
  return (
    <div className="w-full bg-[#080E1E] border border-[#253358] rounded-xl p-5 sm:p-6 shadow-2xl">
      {/* Architectural Diagram Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-[#1E294B]">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono-tabular tracking-widest text-[#C8A86B] uppercase">
              TECHNICAL BLUEPRINT · SCALE 1:25
            </span>
            <span className="text-xs text-[#E8E2D4]/40">·</span>
            <span className="text-xs text-[#E8E2D4]/80 font-medium">Carriage 14 · {cabinNumber}</span>
          </div>
          <h4 className="text-lg font-bold text-white mt-0.5">
            {cabin.name} Architectural Layout
          </h4>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-xs text-[#E8E2D4]/70">
            <span className="w-3 h-3 rounded bg-[#C8A86B] inline-block border border-[#C8A86B]" />
            <span>Selected</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-[#E8E2D4]/70">
            <span className="w-3 h-3 rounded bg-[#101D36] inline-block border border-[#253358]" />
            <span>Available</span>
          </div>
        </div>
      </div>

      {/* Main Architectural Blueprint Diagram */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left Column: Interactive Technical Carriage Diagram */}
        <div className="lg:col-span-7 flex justify-center">
          <div className="relative w-full max-w-md bg-[#0B132B] border-2 border-[#253358] rounded-xl p-6 shadow-inner overflow-hidden">
            {/* Subtle architectural millimeter grid background */}
            <div
              className="absolute inset-0 opacity-10 pointer-events-none"
              style={{
                backgroundImage: 'radial-gradient(#C8A86B 1px, transparent 1px)',
                backgroundSize: '16px 16px'
              }}
            />

            {/* Top Exterior Wall & WINDOW */}
            <div className="w-full relative pb-5 text-center">
              <div className="h-3 w-3/4 mx-auto bg-gradient-to-r from-sky-950 via-sky-800 to-sky-950 border border-sky-400/50 rounded-sm shadow-sm relative flex items-center justify-center">
                <span className="text-[9px] font-mono-tabular font-bold tracking-widest text-sky-200 uppercase">
                  PANORAMIC SOUNDPROOF WINDOW
                </span>
              </div>
              <div className="text-[10px] text-[#E8E2D4]/50 mt-1 font-mono-tabular">
                Exterior Side · Passing European Night Landscape
              </div>
            </div>

            {/* Cabin Compartment Body */}
            <div className="border border-dashed border-[#C8A86B]/30 rounded-lg p-4 bg-[#070B18]/70 space-y-4">
              {/* If 2-Person Private Cabin (as specified in prompt diagram) */}
              {cabin.id === 'private' && (
                <>
                  {/* LOWER BERTH */}
                  <div
                    onClick={() => onSelectBerth('P-LOW')}
                    className={`cursor-pointer rounded-lg p-3.5 border transition-all relative ${
                      selectedBerth === 'P-LOW'
                        ? 'bg-[#152244] border-[#C8A86B] shadow-lg ring-1 ring-[#C8A86B]'
                        : 'bg-[#101D36] border-[#253358] hover:border-[#C8A86B]/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-6 h-6 rounded flex items-center justify-center ${selectedBerth === 'P-LOW' ? 'bg-[#C8A86B] text-[#070B18]' : 'bg-[#152244] text-[#C8A86B]'}`}>
                          <Bed className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white tracking-wide">
                            LOWER BERTH (BERTH 1)
                          </div>
                          <div className="text-[10px] text-[#E8E2D4]/60 font-mono-tabular">
                            1950 × 750 mm · Direct Level Access & Window View
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        {selectedBerth === 'P-LOW' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#C8A86B]">
                            <Check className="w-3.5 h-3.5" /> SELECTED
                          </span>
                        ) : (
                          <span className="text-[11px] text-[#E8E2D4]/70">Available</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* FOLD-DOWN CONSOLE & READING LIGHT DIAL */}
                  <div className="flex items-center justify-between px-3 py-1 text-[10px] font-mono-tabular text-[#E8E2D4]/50 border-y border-[#253358]/50">
                    <span className="flex items-center gap-1">
                      <Lightbulb className="w-3 h-3 text-[#C8A86B]" /> Reading Lamp Console
                    </span>
                    <span className="flex items-center gap-1">
                      <Wind className="w-3 h-3 text-sky-400" /> Climate 20.5°C
                    </span>
                  </div>

                  {/* UPPER BERTH */}
                  <div
                    onClick={() => onSelectBerth('P-UPP')}
                    className={`cursor-pointer rounded-lg p-3.5 border transition-all relative ${
                      selectedBerth === 'P-UPP'
                        ? 'bg-[#152244] border-[#C8A86B] shadow-lg ring-1 ring-[#C8A86B]'
                        : 'bg-[#101D36] border-[#253358] hover:border-[#C8A86B]/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-6 h-6 rounded flex items-center justify-center ${selectedBerth === 'P-UPP' ? 'bg-[#C8A86B] text-[#070B18]' : 'bg-[#152244] text-[#C8A86B]'}`}>
                          <Bed className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white tracking-wide">
                            UPPER BERTH (BERTH 2)
                          </div>
                          <div className="text-[10px] text-[#E8E2D4]/60 font-mono-tabular">
                            1950 × 750 mm · Ladder Access · Elevated Privacy
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        {selectedBerth === 'P-UPP' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#C8A86B]">
                            <Check className="w-3.5 h-3.5" /> SELECTED
                          </span>
                        ) : (
                          <span className="text-[11px] text-[#E8E2D4]/70">Available</span>
                        )}
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* If 4-Person Couchette */}
              {cabin.id === 'couchette' && (
                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { id: 'C-LL', label: 'Lower Berth Left', side: 'Window Left', status: 'Available' },
                    { id: 'C-LR', label: 'Lower Berth Right', side: 'Window Right', status: 'Available' },
                    { id: 'C-UL', label: 'Upper Berth Left', side: 'Upper Left', status: 'Available' },
                    { id: 'C-UR', label: 'Upper Berth Right', side: 'Upper Right', status: 'Reserved' }
                  ].map((b) => (
                    <div
                      key={b.id}
                      onClick={() => b.status === 'Available' && onSelectBerth(b.id)}
                      className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                        b.status === 'Reserved'
                          ? 'opacity-40 cursor-not-allowed bg-[#070B18] border-[#1E294B]'
                          : selectedBerth === b.id
                          ? 'bg-[#152244] border-[#C8A86B] ring-1 ring-[#C8A86B]'
                          : 'bg-[#101D36] border-[#253358] hover:border-[#C8A86B]/60'
                      }`}
                    >
                      <div className="text-xs font-bold text-white">{b.label}</div>
                      <div className="text-[10px] text-[#E8E2D4]/60 font-mono-tabular mt-0.5">{b.side}</div>
                      <div className="text-[10px] mt-1 font-semibold">
                        {b.status === 'Reserved' ? (
                          <span className="text-rose-400">Reserved</span>
                        ) : selectedBerth === b.id ? (
                          <span className="text-[#C8A86B]">✓ Selected</span>
                        ) : (
                          <span className="text-emerald-400">Available</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* If Grand Sleeper Suite */}
              {cabin.id === 'grand_sleeper' && (
                <div
                  onClick={() => onSelectBerth('GS-DBL')}
                  className="p-5 rounded-lg border bg-[#152244] border-[#C8A86B] shadow-lg text-center cursor-pointer"
                >
                  <div className="w-8 h-8 mx-auto rounded-full bg-[#C8A86B] text-[#070B18] flex items-center justify-center mb-2">
                    <Bed className="w-4 h-4" />
                  </div>
                  <div className="text-sm font-bold text-white">QUEEN DOUBLE BED (SUITE MASTER)</div>
                  <div className="text-xs text-[#E8E2D4]/70 font-mono-tabular mt-1">
                    2000 × 1600 mm · Luxury Goose-Down Mattresses
                  </div>
                  <div className="mt-2 text-xs font-bold text-[#C8A86B] flex items-center justify-center gap-1">
                    <Check className="w-4 h-4" /> INCLUDED EXCLUSIVE RESERVATION
                  </div>
                </div>
              )}

              {/* If Reclining Seat */}
              {cabin.id === 'seat' && (
                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { id: 'S1', label: 'Seat 1 (Window)', side: 'Panoramic Window', avail: true },
                    { id: 'S2', label: 'Seat 2 (Aisle)', side: 'Direct Aisle', avail: true },
                    { id: 'S3', label: 'Seat 3 (Aisle)', side: 'Direct Aisle', avail: false },
                    { id: 'S4', label: 'Seat 4 (Window)', side: 'Quiet Wall', avail: true }
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      disabled={!s.avail}
                      onClick={() => onSelectBerth(s.id)}
                      className={`p-3 rounded-lg border text-left transition-all ${
                        !s.avail
                          ? 'opacity-30 cursor-not-allowed bg-[#070B18] border-[#1E294B]'
                          : selectedBerth === s.id
                          ? 'bg-[#152244] border-[#C8A86B] ring-1 ring-[#C8A86B]'
                          : 'bg-[#101D36] border-[#253358] hover:border-[#C8A86B]'
                      }`}
                    >
                      <div className="text-xs font-bold text-white">{s.label}</div>
                      <div className="text-[10px] text-[#E8E2D4]/60">{s.side}</div>
                      <div className="text-[10px] mt-1 font-semibold">
                        {!s.avail ? 'Booked' : selectedBerth === s.id ? '✓ Selected' : 'Available'}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Bottom Corridor, DOOR & STORAGE */}
            <div className="mt-4 pt-3 border-t border-[#253358] grid grid-cols-3 gap-2 text-center text-[10px] font-mono-tabular">
              <div className="bg-[#101D36] p-1.5 rounded border border-[#253358] text-[#E8E2D4]/70">
                LUGGAGE STORAGE
              </div>
              <div className="bg-[#152244] p-1.5 rounded border border-[#C8A86B]/40 text-[#C8A86B] font-semibold">
                LOCKABLE DOOR
              </div>
              <div className="bg-[#101D36] p-1.5 rounded border border-[#253358] text-[#E8E2D4]/70">
                {cabin.washbasin.split(' ')[0]} BASIN
              </div>
            </div>

            <div className="mt-2 text-center text-[9px] font-mono-tabular text-[#E8E2D4]/40 uppercase tracking-widest">
              ← Central Carriage Corridor Access →
            </div>
          </div>
        </div>

        {/* Right Column: Cabin Specifications & Berths Amenities */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#101D36] border border-[#253358] rounded-xl p-4">
            <h5 className="text-xs font-bold tracking-wider text-[#C8A86B] uppercase mb-2">
              CABIN AMENITIES & INCLUSIONS
            </h5>
            <ul className="space-y-2 text-xs text-[#E8E2D4]/90">
              <li className="flex items-start gap-2">
                <span className="text-[#C8A86B] font-bold">·</span>
                <div>
                  <strong className="text-white">Bedding:</strong> {cabin.bedding}
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#C8A86B] font-bold">·</span>
                <div>
                  <strong className="text-white">Privacy:</strong> {cabin.privacy}
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#C8A86B] font-bold">·</span>
                <div>
                  <strong className="text-white">Wash Facilities:</strong> {cabin.washbasin}
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#C8A86B] font-bold">·</span>
                <div>
                  <strong className="text-white">Breakfast:</strong>{' '}
                  {cabin.breakfastIncluded ? 'Complimentary included' : 'Available to add in extras (£16)'}
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#C8A86B] font-bold">·</span>
                <div>
                  <strong className="text-white">Power & Wi-Fi:</strong> {cabin.power} · {cabin.wifi}
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#C8A86B] font-bold">·</span>
                <div>
                  <strong className="text-white">Luggage:</strong> {cabin.luggage}
                </div>
              </li>
            </ul>
          </div>

          <div className="p-3 bg-[#152244]/60 border border-[#C8A86B]/30 rounded-lg flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-[#C8A86B] shrink-0" />
            <div className="text-xs text-[#E8E2D4]/90">
              <strong className="text-white">Night Attendant Guarantee:</strong> Dedicated car attendant available through the night for bed preparation, beverage service, and scheduled wake-up calls.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
