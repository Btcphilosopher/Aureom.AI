'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Bed, Users, Wifi, Coffee, Shield, Check, ChevronRight, Sparkles, Layers } from 'lucide-react';
import { CABIN_CLASSES } from '@/lib/mock-data';
import { CabinClass, CabinCategory, Currency } from '@/lib/types';
import { formatPrice } from '@/lib/storage';
import { CabinDiagram } from './CabinDiagram';

interface CabinSelectorProps {
  selectedCabinId: CabinCategory;
  selectedBerth: string;
  currency: Currency;
  onSelectCabin: (cabinId: CabinCategory) => void;
  onSelectBerth: (berthId: string) => void;
  onContinue: () => void;
}

export const CabinSelector: React.FC<CabinSelectorProps> = ({
  selectedCabinId,
  selectedBerth,
  currency,
  onSelectCabin,
  onSelectBerth,
  onContinue
}) => {
  const currentCabin = CABIN_CLASSES.find((c) => c.id === selectedCabinId) || CABIN_CLASSES[2];

  return (
    <div className="w-full space-y-8">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono-tabular tracking-widest text-[#C8A86B] uppercase block mb-1">
          ACCOMMODATION CLASSES
        </span>
        <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-white">
          Choose Your Cabin
        </h2>
        <p className="text-sm text-[#E8E2D4]/70 mt-2">
          From peaceful reclining seats to private suites with en-suite showers. Travel through the night in quiet European comfort.
        </p>
      </div>

      {/* 4 Cabin Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {CABIN_CLASSES.map((cabin) => {
          const isSelected = selectedCabinId === cabin.id;
          return (
            <div
              key={cabin.id}
              onClick={() => {
                onSelectCabin(cabin.id);
                // default berth selection when switching cabin
                if (cabin.id === 'private') onSelectBerth('P-LOW');
                else if (cabin.id === 'couchette') onSelectBerth('C-LL');
                else if (cabin.id === 'grand_sleeper') onSelectBerth('GS-DBL');
                else if (cabin.id === 'seat') onSelectBerth('S1');
              }}
              className={`cursor-pointer rounded-xl border transition-all duration-200 overflow-hidden flex flex-col justify-between relative group ${
                isSelected
                  ? 'bg-[#101D36] border-[#C8A86B] shadow-2xl ring-2 ring-[#C8A86B]/60'
                  : 'bg-[#0B132B] border-[#253358] hover:border-[#C8A86B]/40 hover:bg-[#0D1830]'
              }`}
            >
              {isSelected && (
                <div className="absolute top-3 right-3 z-20 px-2.5 py-1 bg-[#C8A86B] text-[#070B18] text-[10px] font-bold tracking-wider uppercase rounded shadow">
                  Selected
                </div>
              )}

              {/* Cabin Photography */}
              <div className="relative h-44 w-full overflow-hidden bg-[#070B18]">
                <Image
                  src={cabin.image}
                  alt={cabin.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                  sizes="(max-width: 768px) 100vw, 25vw"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B132B] via-transparent to-black/20" />
                <div className="absolute bottom-2.5 left-3 text-xs text-white font-semibold">
                  <span className="font-mono-tabular text-[#DFBF83] font-bold">
                    From {formatPrice(cabin.priceFromGbp, currency)}
                  </span>
                  <span className="text-[11px] text-[#E8E2D4]/60 ml-1">/ person</span>
                </div>
              </div>

              {/* Cabin Info Body */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-base font-bold text-white group-hover:text-[#DFBF83] transition-colors">
                    {cabin.name}
                  </h3>
                  <p className="text-xs text-[#E8E2D4]/70 mt-1 line-clamp-2">
                    {cabin.subtitle}
                  </p>

                  <div className="my-3 space-y-1.5 text-[11px] text-[#E8E2D4]/80 border-t border-[#1E294B] pt-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[#E8E2D4]/60">Occupancy:</span>
                      <span className="font-medium text-white">{cabin.maxOccupancy} Person{cabin.maxOccupancy > 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#E8E2D4]/60">Beds:</span>
                      <span className="font-medium text-white truncate max-w-[150px]">{cabin.beds.split('(')[0]}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#E8E2D4]/60">Washbasin:</span>
                      <span className="font-medium text-white truncate max-w-[150px]">{cabin.washbasin.split(' ')[0]}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#E8E2D4]/60">Breakfast:</span>
                      <span className="font-medium text-white">
                        {cabin.breakfastIncluded ? '✓ Included' : 'Optional (£16)'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#E8E2D4]/60">Wi-Fi:</span>
                      <span className="font-medium text-white">Starlink High-Speed</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  className={`w-full mt-2 py-2 text-xs font-bold uppercase tracking-wider rounded transition-colors ${
                    isSelected
                      ? 'bg-[#C8A86B] text-[#070B18]'
                      : 'bg-[#152244] text-[#C8A86B] hover:bg-[#1E2E5C]'
                  }`}
                >
                  {isSelected ? 'Configuring Berth' : 'Select Class'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Architectural Cabin Diagram for Berth Selection */}
      <div className="mt-8">
        <CabinDiagram
          cabin={currentCabin}
          selectedBerth={selectedBerth}
          onSelectBerth={onSelectBerth}
        />
      </div>

      {/* Action Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-[#0B132B] border border-[#253358] rounded-xl">
        <div>
          <span className="text-xs text-[#E8E2D4]/60">Selected Arrangement:</span>
          <div className="text-sm font-bold text-white">
            {currentCabin.name} · {selectedBerth || 'Berth'} · {formatPrice(currentCabin.priceFromGbp, currency)}
          </div>
        </div>

        <button
          type="button"
          onClick={onContinue}
          className="w-full sm:w-auto px-7 py-3 bg-[#C8A86B] hover:bg-[#DFBF83] text-[#070B18] font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          <span>Continue to Passengers & Extras</span>
          <ChevronRight className="w-4 h-4 text-[#070B18]" />
        </button>
      </div>
    </div>
  );
};
