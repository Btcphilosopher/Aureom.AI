'use client';

import React, { useState } from 'react';
import { ArrowRightLeft, Calendar, Users, Train, Sparkles, ChevronDown } from 'lucide-react';
import { EUROPEAN_STATIONS } from '@/lib/mock-data';
import { Currency } from '@/lib/types';

interface SearchWidgetProps {
  fromCode: string;
  toCode: string;
  travelDate: string;
  passengersCount: number;
  railcard: string;
  currency: Currency;
  onFromChange: (code: string) => void;
  onToChange: (code: string) => void;
  onDateChange: (date: string) => void;
  onPassengersCountChange: (count: number) => void;
  onRailcardChange: (railcard: string) => void;
  onSearch: () => void;
}

export const SearchWidget: React.FC<SearchWidgetProps> = ({
  fromCode,
  toCode,
  travelDate,
  passengersCount,
  railcard,
  onFromChange,
  onToChange,
  onDateChange,
  onPassengersCountChange,
  onRailcardChange,
  onSearch
}) => {
  const [isPassengerDropdownOpen, setIsPassengerDropdownOpen] = useState(false);
  const [adults, setAdults] = useState(passengersCount);
  const [children, setChildren] = useState(0);
  const [infants, setInfants] = useState(0);

  const handleSwapStations = () => {
    const temp = fromCode;
    onFromChange(toCode);
    onToChange(temp);
  };

  const handleUpdatePassengers = (newAdults: number, newChildren: number, newInfants: number) => {
    setAdults(newAdults);
    setChildren(newChildren);
    setInfants(newInfants);
    onPassengersCountChange(newAdults + newChildren);
  };

  const currentFrom = EUROPEAN_STATIONS.find(s => s.code === fromCode);
  const currentTo = EUROPEAN_STATIONS.find(s => s.code === toCode);

  return (
    <div className="w-full bg-[#0B132B]/95 border border-[#253358] rounded-xl p-5 sm:p-7 shadow-2xl relative z-20">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4 items-end">
        {/* FROM Station */}
        <div className="lg:col-span-3">
          <label className="block text-[11px] font-bold tracking-wider text-[#C8A86B] uppercase mb-1.5">
            FROM
          </label>
          <div className="relative">
            <select
              value={fromCode}
              onChange={(e) => onFromChange(e.target.value)}
              className="w-full bg-[#101D36] border border-[#253358] text-white rounded-lg px-3.5 py-3 text-sm font-medium focus:border-[#C8A86B] focus:outline-none appearance-none cursor-pointer"
            >
              {EUROPEAN_STATIONS.map((station) => (
                <option key={station.code} value={station.code} disabled={station.code === toCode}>
                  {station.city} ({station.name.split(' ')[0]}) {station.flag}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-[#C8A86B] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
          <span className="block text-[11px] text-[#E8E2D4]/60 mt-1 truncate">
            {currentFrom?.name}
          </span>
        </div>

        {/* Swap button */}
        <div className="lg:col-span-1 flex justify-center pb-4 lg:pb-6">
          <button
            type="button"
            onClick={handleSwapStations}
            className="w-10 h-10 rounded-full bg-[#152244] border border-[#253358] text-[#C8A86B] hover:bg-[#1E2E5C] hover:text-[#DFBF83] flex items-center justify-center transition-transform hover:rotate-180"
            title="Swap departure and destination"
          >
            <ArrowRightLeft className="w-4 h-4" />
          </button>
        </div>

        {/* TO Station */}
        <div className="lg:col-span-3">
          <label className="block text-[11px] font-bold tracking-wider text-[#C8A86B] uppercase mb-1.5">
            TO
          </label>
          <div className="relative">
            <select
              value={toCode}
              onChange={(e) => onToChange(e.target.value)}
              className="w-full bg-[#101D36] border border-[#253358] text-white rounded-lg px-3.5 py-3 text-sm font-medium focus:border-[#C8A86B] focus:outline-none appearance-none cursor-pointer"
            >
              {EUROPEAN_STATIONS.map((station) => (
                <option key={station.code} value={station.code} disabled={station.code === fromCode}>
                  {station.city} ({station.name.split(' ')[0]}) {station.flag}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-[#C8A86B] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
          <span className="block text-[11px] text-[#E8E2D4]/60 mt-1 truncate">
            {currentTo?.name}
          </span>
        </div>

        {/* DEPARTURE DATE */}
        <div className="lg:col-span-2">
          <label className="block text-[11px] font-bold tracking-wider text-[#C8A86B] uppercase mb-1.5">
            DEPARTURE
          </label>
          <div className="relative">
            <input
              type="date"
              value={travelDate}
              min="2026-10-13"
              onChange={(e) => onDateChange(e.target.value)}
              className="w-full bg-[#101D36] border border-[#253358] text-white rounded-lg px-3.5 py-3 text-sm font-medium focus:border-[#C8A86B] focus:outline-none"
            />
          </div>
          <span className="block text-[11px] text-[#E8E2D4]/60 mt-1">
            Friday 16 October (Default)
          </span>
        </div>

        {/* PASSENGERS & RAILCARD */}
        <div className="lg:col-span-3 relative">
          <label className="block text-[11px] font-bold tracking-wider text-[#C8A86B] uppercase mb-1.5">
            PASSENGERS
          </label>
          <button
            type="button"
            onClick={() => setIsPassengerDropdownOpen(!isPassengerDropdownOpen)}
            className="w-full bg-[#101D36] border border-[#253358] text-white rounded-lg px-3.5 py-3 text-sm font-medium flex items-center justify-between text-left focus:border-[#C8A86B]"
          >
            <span className="truncate">
              {adults} Adult{adults > 1 ? 's' : ''}
              {children > 0 ? `, ${children} Child` : ''}
              {railcard !== 'none' ? ' · Discount' : ''}
            </span>
            <ChevronDown className="w-4 h-4 text-[#C8A86B] shrink-0 ml-1" />
          </button>
          <span className="block text-[11px] text-[#E8E2D4]/60 mt-1">
            {railcard === 'none' ? 'Standard fare' : railcard}
          </span>

          {/* Passenger dropdown menu */}
          {isPassengerDropdownOpen && (
            <div className="absolute right-0 top-full mt-2 w-80 bg-[#0B132B] border border-[#253358] rounded-xl p-4 shadow-2xl z-50">
              <div className="space-y-3 pb-3 border-b border-[#253358]">
                {/* Adults */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-white">Adults</div>
                    <div className="text-[11px] text-[#E8E2D4]/60">Age 16+</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={adults <= 1}
                      onClick={() => handleUpdatePassengers(Math.max(1, adults - 1), children, infants)}
                      className="w-7 h-7 rounded border border-[#253358] text-white disabled:opacity-30"
                    >
                      -
                    </button>
                    <span className="w-6 text-center font-bold text-sm">{adults}</span>
                    <button
                      type="button"
                      disabled={adults >= 4}
                      onClick={() => handleUpdatePassengers(adults + 1, children, infants)}
                      className="w-7 h-7 rounded border border-[#253358] text-white disabled:opacity-30"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Children */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-white">Children</div>
                    <div className="text-[11px] text-[#E8E2D4]/60">Age 4–15 (50% couchette)</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={children <= 0}
                      onClick={() => handleUpdatePassengers(adults, Math.max(0, children - 1), infants)}
                      className="w-7 h-7 rounded border border-[#253358] text-white disabled:opacity-30"
                    >
                      -
                    </button>
                    <span className="w-6 text-center font-bold text-sm">{children}</span>
                    <button
                      type="button"
                      disabled={children >= 3}
                      onClick={() => handleUpdatePassengers(adults, children + 1, infants)}
                      className="w-7 h-7 rounded border border-[#253358] text-white disabled:opacity-30"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Infants */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-white">Infants</div>
                    <div className="text-[11px] text-[#E8E2D4]/60">Under 4 (sharing bed, free)</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={infants <= 0}
                      onClick={() => handleUpdatePassengers(adults, children, Math.max(0, infants - 1))}
                      className="w-7 h-7 rounded border border-[#253358] text-white disabled:opacity-30"
                    >
                      -
                    </button>
                    <span className="w-6 text-center font-bold text-sm">{infants}</span>
                    <button
                      type="button"
                      disabled={infants >= 2}
                      onClick={() => handleUpdatePassengers(adults, children, infants + 1)}
                      className="w-7 h-7 rounded border border-[#253358] text-white disabled:opacity-30"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              {/* Railcard Selection */}
              <div className="pt-3">
                <label className="block text-xs font-semibold text-[#C8A86B] mb-1.5">
                  European Railcard / Discount
                </label>
                <select
                  value={railcard}
                  onChange={(e) => onRailcardChange(e.target.value)}
                  className="w-full bg-[#101D36] border border-[#253358] text-white rounded px-2.5 py-1.5 text-xs font-medium focus:outline-none"
                >
                  <option value="none">No discount card</option>
                  <option value="Eurail / Interrail Pass">Eurail / Interrail Pass (Berth supplement only)</option>
                  <option value="Swiss Half Fare Card">Swiss Half-Fare Card (SBB)</option>
                  <option value="BahnCard 25/50">BahnCard 25 / 50 (DB)</option>
                  <option value="Carte Avantage SNCF">Carte Avantage (SNCF)</option>
                </select>
              </div>

              <div className="mt-4 flex justify-end">
                <button
                  type="button"
                  onClick={() => setIsPassengerDropdownOpen(false)}
                  className="px-3 py-1.5 bg-[#C8A86B] text-[#070B18] text-xs font-bold rounded"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Primary Search CTA & Quick Network Shortcuts */}
      <div className="mt-5 pt-4 border-t border-[#1E294B] flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Quick Route Shortcuts */}
        <div className="flex items-center gap-2 flex-wrap text-xs text-[#E8E2D4]/70">
          <span className="text-[#C8A86B] font-semibold">Popular:</span>
          {[
            { from: 'STP', to: 'ZUR', label: 'London → Zürich' },
            { from: 'PAR', to: 'MIL', label: 'Paris → Milan' },
            { from: 'AMS', to: 'PRG', label: 'Amsterdam → Prague' },
            { from: 'BRU', to: 'BER', label: 'Brussels → Berlin' },
            { from: 'MUC', to: 'VCE', label: 'Munich → Venice' }
          ].map((route) => (
            <button
              key={route.label}
              type="button"
              onClick={() => {
                onFromChange(route.from);
                onToChange(route.to);
              }}
              className="px-2.5 py-1 rounded bg-[#101D36] border border-[#253358] hover:border-[#C8A86B]/60 text-white text-xs transition-colors"
            >
              {route.label}
            </button>
          ))}
        </div>

        {/* Primary Search Button */}
        <button
          type="button"
          onClick={onSearch}
          className="w-full sm:w-auto px-8 py-3.5 bg-[#C8A86B] hover:bg-[#DFBF83] text-[#070B18] font-bold text-sm tracking-wider uppercase rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
        >
          <Train className="w-4 h-4 text-[#070B18]" />
          <span>Search Sleeper Trains</span>
        </button>
      </div>
    </div>
  );
};
