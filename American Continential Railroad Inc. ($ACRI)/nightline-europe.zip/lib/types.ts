export type Currency = 'GBP' | 'EUR' | 'CHF';

export type Language = 'en' | 'de' | 'fr' | 'it' | 'nl';

export interface Station {
  code: string;
  name: string;
  city: string;
  country: string;
  flag: string;
  mapX: number; // SVG map relative coordinate percentage (0 - 100)
  mapY: number; // SVG map relative coordinate percentage (0 - 100)
  platforms: string[];
  lounge: {
    available: boolean;
    name: string;
    hours: string;
    location: string;
    amenities: string[];
  };
  transitConnections: string[];
  stationFeatures: string[];
  showerFacilities: boolean;
  leftLuggage: boolean;
  address: string;
}

export interface IntermediateStop {
  stationCode: string;
  stationName: string;
  city: string;
  arrivalTime: string;
  departureTime: string;
  platform?: string;
  isCompleted?: boolean;
  distanceKm?: number;
}

export interface TrainSchedule {
  id: string;
  trainNumber: string; // e.g. "NL 402"
  trainName: string; // e.g. "Helvetia Express"
  fromStationCode: string;
  toStationCode: string;
  departureTime: string; // "20:40"
  arrivalTime: string; // "08:15"
  daysOffset: number; // 1 = next day arrival
  duration: string; // "11h 35m"
  isDirect: boolean;
  stops: IntermediateStop[];
  basePriceGbp: number;
  availableCabins: string[];
  carbonSavedKg: number;
}

export type CabinCategory = 'seat' | 'couchette' | 'private' | 'grand_sleeper';

export interface BerthConfig {
  id: string;
  label: string;
  tier: 'lower' | 'upper' | 'seat';
  side: 'window' | 'aisle' | 'left' | 'right';
  isAvailable: boolean;
  priceDelta: number;
}

export interface CabinClass {
  id: CabinCategory;
  name: string;
  subtitle: string;
  description: string;
  priceFromGbp: number;
  maxOccupancy: number;
  beds: string;
  bedding: string;
  privacy: string;
  washbasin: string;
  enSuite: boolean;
  breakfastIncluded: boolean;
  wifi: string;
  power: string;
  luggage: string;
  accessibility: string;
  dimensions: string;
  image: string;
  features: string[];
  berths: BerthConfig[];
}

export interface Passenger {
  id: string;
  type: 'adult' | 'child' | 'infant';
  title: string;
  firstName: string;
  lastName: string;
  passportNumber?: string;
  railcard?: string;
  dietaryPreference?: 'none' | 'continental' | 'vegetarian' | 'vegan' | 'gluten_free';
  berthSelection?: string;
}

export interface BookingExtra {
  id: string;
  name: string;
  category: 'dining' | 'comfort' | 'luggage' | 'transfer';
  description: string;
  priceGbp: number;
  iconName: string;
  includedForCabins?: CabinCategory[];
}

export interface Booking {
  id: string;
  reference: string; // e.g. "NL-8924-ZUR"
  createdAt: string;
  train: TrainSchedule;
  travelDate: string; // "2026-10-16"
  cabinClass: CabinClass;
  cabinNumber: string; // e.g. "Car 12, Compartment 204"
  selectedBerthLabels: string[];
  passengers: Passenger[];
  extras: BookingExtra[];
  totalAmountGbp: number;
  currency: Currency;
  status: 'confirmed' | 'cancelled';
  qrCodeToken: string;
  notes?: string;
}

export interface LiveTrainStatus {
  trainNumber: string;
  trainName: string;
  routeTitle: string;
  status: 'ON TIME' | 'SLIGHT DELAY (+6M)' | 'BOARDING' | 'DEPARTED';
  isEnRoute: boolean;
  currentLocationName: string;
  nextStation: string;
  estimatedArrival: string;
  delayMinutes: number;
  currentSpeedKmH: number;
  platform: string;
  outdoorTempCelsius: number;
  weatherDescription: string;
  progressPercent: number; // 0 - 100
  serviceAlert?: string;
}

export interface CabinSmartControlState {
  readingLightBrightness: number; // 0 - 100
  cabinTemperatureCelsius: number; // 18 - 24
  privacyMode: 'normal' | 'dnd' | 'make_up_berth';
  ambientLighting: 'warm_amber' | 'midnight_blue' | 'reading' | 'off';
  wakeUpTime: string | null;
  wakeUpOption: 'specific_time' | '30_min_before' | null;
  wakeUpConfirmed: boolean;
  attendantCalled: boolean;
  breakfastSelected: 'continental' | 'vegetarian' | 'vegan' | null;
  breakfastTime: string;
  breakfastDelivered: boolean;
}

export interface DiningMenuItem {
  id: string;
  course: 'starters' | 'mains' | 'desserts' | 'wines' | 'digestifs';
  name: string;
  description: string;
  priceGbp: number;
  dietary: string[];
  pairing?: string;
}
