import {
  Station,
  TrainSchedule,
  CabinClass,
  BookingExtra,
  DiningMenuItem,
  LiveTrainStatus,
  Booking
} from './types';

export const EUROPEAN_STATIONS: Station[] = [
  {
    code: 'STP',
    name: 'London St Pancras International',
    city: 'London',
    country: 'United Kingdom',
    flag: '🇬🇧',
    mapX: 18,
    mapY: 34,
    platforms: ['Platform 5', 'Platform 6', 'Platform 9', 'Platform 10'],
    lounge: {
      available: true,
      name: 'The Nightline St Pancras Club Lounge',
      hours: '17:00 – 21:30',
      location: 'First Floor, The Arcade above Eurostar concourse',
      amenities: ['Artisan British tea & espresso', 'Sommelier wine selection', 'Private shower suites', 'High-speed secure Wi-Fi', 'Luggage transfer directly to cabin']
    },
    transitConnections: ['London Underground (6 lines: Victoria, Northern, Piccadilly, Circle, H&C, Met)', 'Thameslink Cross-London rail', 'St Pancras Taxi Rank', 'E-bike docking at Pancras Square'],
    stationFeatures: ['Victorian Gothic landmark', 'Luggage lockers 24/7', 'Step-free level platform boarding', 'Bicycle storage vaults'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Euston Rd, London N1C 4QP'
  },
  {
    code: 'PAR',
    name: 'Paris Gare de Lyon / Gare du Nord',
    city: 'Paris',
    country: 'France',
    flag: '🇫🇷',
    mapX: 28,
    mapY: 48,
    platforms: ['Hall 1, Voie A-N', 'Hall 2, Voie 1-23'],
    lounge: {
      available: true,
      name: 'Salon Grand Voyageur Nightline',
      hours: '06:00 – 23:00',
      location: 'Galerie des Fresques, Hall 1',
      amenities: ['French pastries & espresso', 'Wine cellar selection', 'Shower rooms with L’Occitane amenities', 'Quiet workspaces']
    },
    transitConnections: ['Métro Lines 1, 5, 14', 'RER A & D (Châtelet 4 mins, CDG Airport 35 mins)', 'Gare de Lyon Taxi Rank', 'Vélib’ bike sharing'],
    stationFeatures: ['Historic Le Train Bleu brasserie', 'Left luggage automated lockers', 'Full accessibility assistance', 'Currency exchange'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Place Louis-Armand, 75571 Paris'
  },
  {
    code: 'ZUR',
    name: 'Zürich Hauptbahnhof (HB)',
    city: 'Zürich',
    country: 'Switzerland',
    flag: '🇨🇭',
    mapX: 47,
    mapY: 62,
    platforms: ['Gleis 3', 'Gleis 4', 'Gleis 7 (Nightline Express)', 'Gleis 8'],
    lounge: {
      available: true,
      name: 'SBB First Lounge & Nightline Salon',
      hours: '06:00 – 22:00',
      location: 'South wing, Mezzanine level near Track 7',
      amenities: ['Swiss roast coffee & Lindt confectionery', 'Swiss Alpine mineral water', 'Fresh linen towels & rainfall showers', 'High-speed business stations']
    },
    transitConnections: ['Zürich S-Bahn (S2, S16 direct to Airport in 9 mins)', 'VBZ Tram lines 3, 4, 10, 11, 13, 14', 'PostBus regional hubs', 'Bahnhofplatz Limousine & Taxi rank'],
    stationFeatures: ['ShopVille subterranean shopping (open till 21:00 daily)', 'Luggage center & bike rental', 'Elevator access to all tracks', 'Connected ferry pier at Limmat river'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Bahnhofplatz 1, 8001 Zürich'
  },
  {
    code: 'VIE',
    name: 'Wien Hauptbahnhof',
    city: 'Vienna',
    country: 'Austria',
    flag: '🇦🇹',
    mapX: 68,
    mapY: 57,
    platforms: ['Bahnsteig 5', 'Bahnsteig 6', 'Bahnsteig 9', 'Bahnsteig 10'],
    lounge: {
      available: true,
      name: 'ÖBB Lounge & Nightline Club',
      hours: '06:00 – 22:00',
      location: 'Level 1, opposite Track 6',
      amenities: ['Viennese Melange & Apfelstrudel', 'Grüner Veltliner Austrian wine', 'Private shower suites', 'Quiet relaxation booths']
    },
    transitConnections: ['U-Bahn U1 (Stephansplatz 5 mins)', 'S-Bahn S7 to Vienna Airport (25 mins)', 'Tram lines 18, D, O', 'Südtiroler Platz bus terminal'],
    stationFeatures: ['Modern multi-level hub', '24h automated luggage lockers', 'Step-free tactile guidance', 'Overnight transit concierge'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Am Hauptbahnhof 1, 1100 Wien'
  },
  {
    code: 'AMS',
    name: 'Amsterdam Centraal',
    city: 'Amsterdam',
    country: 'Netherlands',
    flag: '🇳🇱',
    mapX: 34,
    mapY: 30,
    platforms: ['Spoor 2b', 'Spoor 8a', 'Spoor 14b'],
    lounge: {
      available: true,
      name: 'Regus Express & Nightline Lounge',
      hours: '07:00 – 22:00',
      location: 'Platform 2b (Former Royal Waiting Rooms wing)',
      amenities: ['Dutch filter roast & stroopwafels', 'Canal views', 'Shower cabins', 'Fast Wi-Fi']
    },
    transitConnections: ['Metro 51, 52, 53, 54', 'Tram lines 2, 12, 13, 17, 26', 'IJ river ferries (free to North Amsterdam)', 'Schiphol Airport direct rail (14 mins)'],
    stationFeatures: ['Grand neo-Renaissance facade', 'Bicycle storage for 17,000 bikes', 'Waterfront promenade', 'Luggage storage point'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Stationsplein, 1012 AB Amsterdam'
  },
  {
    code: 'BER',
    name: 'Berlin Hauptbahnhof',
    city: 'Berlin',
    country: 'Germany',
    flag: '🇩🇪',
    mapX: 58,
    mapY: 32,
    platforms: ['Gleis 1-8 (Subterranean deep level)', 'Gleis 11-16 (Upper viaduct)'],
    lounge: {
      available: true,
      name: 'DB Premium Lounge Berlin',
      hours: '06:00 – 23:00',
      location: 'First floor, Europaplatz side',
      amenities: ['German craft beers & organic sodas', 'Fresh pretzels & hot soup', 'Spacious private bathrooms with showers', 'Quiet telephone booths']
    },
    transitConnections: ['S-Bahn S3, S5, S7, S9', 'U-Bahn U5 (Brandenburger Tor 3 mins, Alexanderplatz 7 mins)', 'BER Airport FEX express (28 mins)', 'Tram lines M5, M8, M10'],
    stationFeatures: ['Multi-level glass cathedral of rails', 'Over 80 station boutiques & cafes', 'Universal step-free access', 'Bicycle mobility center'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Europaplatz 1, 10557 Berlin'
  },
  {
    code: 'PRG',
    name: 'Praha hlavní nádraží (hl.n.)',
    city: 'Prague',
    country: 'Czech Republic',
    flag: '🇨🇿',
    mapX: 62,
    mapY: 46,
    platforms: ['Nástupiště 3', 'Nástupiště 4', 'Nástupiště 6'],
    lounge: {
      available: true,
      name: 'ČD Lounge & Nightline Salon',
      hours: '06:00 – 21:00',
      location: 'Historic Fantova budova wing',
      amenities: ['Bohemian tea selection', 'Local mineral waters', 'Rest cabins', 'Charging ports']
    },
    transitConnections: ['Metro Line C (Hlavní nádraží)', 'Airport Express AE bus (30 mins)', 'Tram lines 5, 9, 15, 26', 'Wenceslas Square walking distance (8 mins)'],
    stationFeatures: ['Art Nouveau dome cafe', 'Historic departure hall', 'Safe overnight luggage storage', 'Accessible ramps throughout'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Wilsonova 300/8, 120 00 Praha 2'
  },
  {
    code: 'BRU',
    name: 'Bruxelles-Midi / Brussel-Zuid',
    city: 'Brussels',
    country: 'Belgium',
    flag: '🇧🇪',
    mapX: 29,
    mapY: 37,
    platforms: ['Voie 3', 'Voie 4', 'Voie 6'],
    lounge: {
      available: true,
      name: 'Eurostar & Nightline Continental Lounge',
      hours: '06:00 – 22:30',
      location: 'Place Horta entrance mezzanine',
      amenities: ['Belgian chocolates & espresso', 'Local craft beers', 'Shower suites', 'Comfortable leather armchairs']
    },
    transitConnections: ['Metro Lines 2 & 6', 'Premetro Trams 3, 4', 'Brussels Airport express train (21 mins)', 'Rue de France taxi rank'],
    stationFeatures: ['Major high-speed crossroads', 'Automatic luggage vaults', 'Accessible staff assistance', 'Pharmacy & travel supply'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Avenue Fonsny 47B, 1060 Bruxelles'
  },
  {
    code: 'MIL',
    name: 'Milano Centrale',
    city: 'Milan',
    country: 'Italy',
    flag: '🇮🇹',
    mapX: 46,
    mapY: 74,
    platforms: ['Binario 7', 'Binario 8', 'Binario 11', 'Binario 12'],
    lounge: {
      available: true,
      name: 'FRECCIALounge & Nightline Milano',
      hours: '06:00 – 21:30',
      location: 'Track level, between Binario 10 and 11',
      amenities: ['Italian espresso & Illy roast', 'Prosecco DOCG aperitivo', 'Spacious dressing rooms & showers', 'Concierge desk']
    },
    transitConnections: ['Metropolitana M2 (Green) & M3 (Yellow)', 'Malpensa Express train (50 mins)', 'Milano Trams 1, 5, 9, 10', 'Piazza Duca d’Aosta taxi stand'],
    stationFeatures: ['Monumental Art Deco architecture', 'High ceilings & marble gallerias', 'Left luggage Kipoint', 'Full elevator accessibility'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Piazza Duca d’Aosta 1, 20124 Milano'
  },
  {
    code: 'VCE',
    name: 'Venezia Santa Lucia',
    city: 'Venice',
    country: 'Italy',
    flag: '🇮🇹',
    mapX: 56,
    mapY: 75,
    platforms: ['Binario 1', 'Binario 2', 'Binario 3'],
    lounge: {
      available: true,
      name: 'Sala FRECCIA Venezia',
      hours: '06:30 – 21:00',
      location: 'Grand Canal frontage, ground floor',
      amenities: ['Venetian espresso', 'Mineral water & Bellini mocktails', 'Lagoon views', 'Porter luggage service']
    },
    transitConnections: ['Vaporetto Water Bus lines 1, 2, 4.1, 5.2 (Grand Canal pier directly outside)', 'Water Taxi private dock', 'Venice Piazzale Roma (5 min walk)'],
    stationFeatures: ['Only railway station on the Venice lagoon', 'Direct boat boarding at station steps', 'Porters service', 'Storage facilities'],
    showerFacilities: false,
    leftLuggage: true,
    address: 'Fondamenta Santa Lucia, 30121 Venezia'
  },
  {
    code: 'MUC',
    name: 'München Hauptbahnhof',
    city: 'Munich',
    country: 'Germany',
    flag: '🇩🇪',
    mapX: 52,
    mapY: 53,
    platforms: ['Gleis 11', 'Gleis 12', 'Gleis 13'],
    lounge: {
      available: true,
      name: 'DB Lounge München First Class',
      hours: '06:30 – 22:00',
      location: 'First floor, south wing gallery',
      amenities: ['Bavarian roast coffee', 'Craft beverages', 'Modern shower suites', 'Workspaces']
    },
    transitConnections: ['S-Bahn trunk line (all S-lines, S1/S8 to Airport 40 mins)', 'U-Bahn U1, U2, U4, U5', 'Munich Trams 16, 17, 19, 20'],
    stationFeatures: ['Bavarian transport epicenter', 'Extensive food market halls', '24/7 luggage lockers', 'Step-free access'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Bayerstraße 10A, 80335 München'
  },
  {
    code: 'BUD',
    name: 'Budapest-Keleti',
    city: 'Budapest',
    country: 'Hungary',
    flag: '🇭🇺',
    mapX: 78,
    mapY: 63,
    platforms: ['6. vágány', '7. vágány', '8. vágány'],
    lounge: {
      available: true,
      name: 'MÁV Keleti Business Lounge',
      hours: '06:00 – 21:30',
      location: 'Main grand vestibule, Track 6',
      amenities: ['Hungarian herbal infusions', 'Tokaji dessert wine tastings', 'Private restrooms', 'Luggage transfer']
    },
    transitConnections: ['Metro Line M2 (Keleti pályaudvar) & Line M4', 'Tram lines 23, 24', 'Bus 100E to Budapest Liszt Ferenc Airport'],
    stationFeatures: ['Majestic neo-Renaissance hall', 'Automated luggage lockers', 'Restored historic ceiling frescoes', 'Tactile paving'],
    showerFacilities: false,
    leftLuggage: true,
    address: 'Baross tér 11, 1087 Budapest'
  },
  {
    code: 'CPH',
    name: 'København H (Central Station)',
    city: 'Copenhagen',
    country: 'Denmark',
    flag: '🇩🇰',
    mapX: 50,
    mapY: 16,
    platforms: ['Spor 5', 'Spor 6', 'Spor 7'],
    lounge: {
      available: true,
      name: 'DSB 7-Eleven Lounge & Nightline Nord',
      hours: '06:30 – 21:00',
      location: 'Ground floor near Bernstorffsgade exit',
      amenities: ['Danish filter coffee & pastries', 'Organic Nordic juice', 'Quiet workspace', 'Luggage storage']
    },
    transitConnections: ['Copenhagen Metro M3 Cityringen & M4', 'S-tog commuter rail (Lines A, B, C, E, H)', 'Øresundståg direct to Malmö & Sweden (35 mins)'],
    stationFeatures: ['Nordic brick hall with timber arches', 'Tivoli Gardens directly across the street', 'Bicycle parking hubs', 'Luggage lockers'],
    showerFacilities: true,
    leftLuggage: true,
    address: 'Bernstorffsgade 16, 1577 København'
  }
];

export const TIMETABLE_TRAINS: TrainSchedule[] = [
  {
    id: 'NL-402',
    trainNumber: 'NL 402',
    trainName: 'Helvetia Nocturne',
    fromStationCode: 'STP',
    toStationCode: 'ZUR',
    departureTime: '20:40',
    arrivalTime: '08:15',
    daysOffset: 1,
    duration: '11h 35m',
    isDirect: true,
    stops: [
      { stationCode: 'STP', stationName: 'London St Pancras', city: 'London', arrivalTime: '—', departureTime: '20:40', platform: 'Platform 9', isCompleted: true, distanceKm: 0 },
      { stationCode: 'LIL', stationName: 'Lille-Europe', city: 'Lille', arrivalTime: '22:15', departureTime: '22:25', platform: 'Voie 3', isCompleted: true, distanceKm: 270 },
      { stationCode: 'PAR', stationName: 'Paris Gare du Nord', city: 'Paris', arrivalTime: '23:05', departureTime: '23:25', platform: 'Voie 12', isCompleted: true, distanceKm: 495 },
      { stationCode: 'BSL', stationName: 'Basel SBB', city: 'Basel', arrivalTime: '06:40', departureTime: '06:55', platform: 'Gleis 4', isCompleted: false, distanceKm: 980 },
      { stationCode: 'ZUR', stationName: 'Zürich Hauptbahnhof', city: 'Zürich', arrivalTime: '08:15', departureTime: '—', platform: 'Gleis 7', isCompleted: false, distanceKm: 1065 }
    ],
    basePriceGbp: 89,
    availableCabins: ['seat', 'couchette', 'private', 'grand_sleeper'],
    carbonSavedKg: 198
  },
  {
    id: 'NL-405',
    trainNumber: 'NL 405',
    trainName: 'Albula Express',
    fromStationCode: 'ZUR',
    toStationCode: 'STP',
    departureTime: '21:10',
    arrivalTime: '08:05',
    daysOffset: 1,
    duration: '10h 55m',
    isDirect: true,
    stops: [
      { stationCode: 'ZUR', stationName: 'Zürich Hauptbahnhof', city: 'Zürich', arrivalTime: '—', departureTime: '21:10', platform: 'Gleis 7', distanceKm: 0 },
      { stationCode: 'BSL', stationName: 'Basel SBB', city: 'Basel', arrivalTime: '22:25', departureTime: '22:38', platform: 'Gleis 2', distanceKm: 85 },
      { stationCode: 'PAR', stationName: 'Paris Gare de Lyon', city: 'Paris', arrivalTime: '06:05', departureTime: '06:22', platform: 'Voie A', distanceKm: 570 },
      { stationCode: 'STP', stationName: 'London St Pancras', city: 'London', arrivalTime: '08:05', departureTime: '—', platform: 'Platform 10', distanceKm: 1065 }
    ],
    basePriceGbp: 89,
    availableCabins: ['seat', 'couchette', 'private', 'grand_sleeper'],
    carbonSavedKg: 198
  },
  {
    id: 'NL-220',
    trainNumber: 'NL 220',
    trainName: 'Lombardia Sleeper',
    fromStationCode: 'PAR',
    toStationCode: 'MIL',
    departureTime: '21:35',
    arrivalTime: '07:20',
    daysOffset: 1,
    duration: '9h 45m',
    isDirect: true,
    stops: [
      { stationCode: 'PAR', stationName: 'Paris Gare de Lyon', city: 'Paris', arrivalTime: '—', departureTime: '21:35', platform: 'Hall 1, Voie D', distanceKm: 0 },
      { stationCode: 'DIJ', stationName: 'Dijon-Ville', city: 'Dijon', arrivalTime: '23:20', departureTime: '23:28', platform: 'Voie E', distanceKm: 315 },
      { stationCode: 'LAU', stationName: 'Lausanne', city: 'Lausanne', arrivalTime: '04:10', departureTime: '04:22', platform: 'Voie 2', distanceKm: 510 },
      { stationCode: 'DOM', stationName: 'Domodossola', city: 'Domodossola', arrivalTime: '05:45', departureTime: '05:52', platform: 'Binario 3', distanceKm: 690 },
      { stationCode: 'MIL', stationName: 'Milano Centrale', city: 'Milan', arrivalTime: '07:20', departureTime: '—', platform: 'Binario 8', distanceKm: 850 }
    ],
    basePriceGbp: 95,
    availableCabins: ['seat', 'couchette', 'private', 'grand_sleeper'],
    carbonSavedKg: 165
  },
  {
    id: 'NL-108',
    trainNumber: 'NL 108',
    trainName: 'Bohemia Express',
    fromStationCode: 'AMS',
    toStationCode: 'PRG',
    departureTime: '19:55',
    arrivalTime: '07:45',
    daysOffset: 1,
    duration: '11h 50m',
    isDirect: true,
    stops: [
      { stationCode: 'AMS', stationName: 'Amsterdam Centraal', city: 'Amsterdam', arrivalTime: '—', departureTime: '19:55', platform: 'Spoor 8a', distanceKm: 0 },
      { stationCode: 'HAN', stationName: 'Hannover Hbf', city: 'Hannover', arrivalTime: '23:12', departureTime: '23:25', platform: 'Gleis 9', distanceKm: 380 },
      { stationCode: 'BER', stationName: 'Berlin Hauptbahnhof', city: 'Berlin', arrivalTime: '01:40', departureTime: '01:55', platform: 'Gleis 1', distanceKm: 650 },
      { stationCode: 'DRE', stationName: 'Dresden Hbf', city: 'Dresden', arrivalTime: '04:15', departureTime: '04:28', platform: 'Gleis 3', distanceKm: 840 },
      { stationCode: 'PRG', stationName: 'Praha hlavní nádraží', city: 'Prague', arrivalTime: '07:45', departureTime: '—', platform: 'Nástupiště 4', distanceKm: 990 }
    ],
    basePriceGbp: 85,
    availableCabins: ['seat', 'couchette', 'private', 'grand_sleeper'],
    carbonSavedKg: 182
  },
  {
    id: 'NL-315',
    trainNumber: 'NL 315',
    trainName: 'Brandenburg Nightline',
    fromStationCode: 'BRU',
    toStationCode: 'BER',
    departureTime: '20:15',
    arrivalTime: '06:50',
    daysOffset: 1,
    duration: '10h 35m',
    isDirect: true,
    stops: [
      { stationCode: 'BRU', stationName: 'Bruxelles-Midi', city: 'Brussels', arrivalTime: '—', departureTime: '20:15', platform: 'Voie 4', distanceKm: 0 },
      { stationCode: 'LIE', stationName: 'Liège-Guillemins', city: 'Liège', arrivalTime: '21:10', departureTime: '21:18', platform: 'Voie 2', distanceKm: 100 },
      { stationCode: 'COL', stationName: 'Köln Hbf', city: 'Cologne', arrivalTime: '22:30', departureTime: '22:45', platform: 'Gleis 6', distanceKm: 220 },
      { stationCode: 'HAN', stationName: 'Hannover Hbf', city: 'Hannover', arrivalTime: '02:15', departureTime: '02:28', platform: 'Gleis 12', distanceKm: 510 },
      { stationCode: 'BER', stationName: 'Berlin Hauptbahnhof', city: 'Berlin', arrivalTime: '06:50', departureTime: '—', platform: 'Gleis 4', distanceKm: 780 }
    ],
    basePriceGbp: 79,
    availableCabins: ['seat', 'couchette', 'private', 'grand_sleeper'],
    carbonSavedKg: 142
  },
  {
    id: 'NL-510',
    trainNumber: 'NL 510',
    trainName: 'Serenissima Sleeper',
    fromStationCode: 'MUC',
    toStationCode: 'VCE',
    departureTime: '22:45',
    arrivalTime: '07:10',
    daysOffset: 1,
    duration: '8h 25m',
    isDirect: true,
    stops: [
      { stationCode: 'MUC', stationName: 'München Hbf', city: 'Munich', arrivalTime: '—', departureTime: '22:45', platform: 'Gleis 12', distanceKm: 0 },
      { stationCode: 'ROS', stationName: 'Rosenheim', city: 'Rosenheim', arrivalTime: '23:30', departureTime: '23:38', platform: 'Gleis 3', distanceKm: 65 },
      { stationCode: 'INN', stationName: 'Innsbruck Hbf', city: 'Innsbruck', arrivalTime: '00:45', departureTime: '01:00', platform: 'Bahnsteig 2', distanceKm: 175 },
      { stationCode: 'VRN', stationName: 'Verona Porta Nuova', city: 'Verona', arrivalTime: '04:55', departureTime: '05:12', platform: 'Binario 6', distanceKm: 420 },
      { stationCode: 'VCE', stationName: 'Venezia Santa Lucia', city: 'Venice', arrivalTime: '07:10', departureTime: '—', platform: 'Binario 2', distanceKm: 535 }
    ],
    basePriceGbp: 82,
    availableCabins: ['seat', 'couchette', 'private', 'grand_sleeper'],
    carbonSavedKg: 130
  },
  {
    id: 'NL-604',
    trainNumber: 'NL 604',
    trainName: 'Danube Nocturne',
    fromStationCode: 'VIE',
    toStationCode: 'BUD',
    departureTime: '22:10',
    arrivalTime: '06:40',
    daysOffset: 1,
    duration: '8h 30m',
    isDirect: true,
    stops: [
      { stationCode: 'VIE', stationName: 'Wien Hauptbahnhof', city: 'Vienna', arrivalTime: '—', departureTime: '22:10', platform: 'Bahnsteig 9', distanceKm: 0 },
      { stationCode: 'BTS', stationName: 'Bratislava hl.st.', city: 'Bratislava', arrivalTime: '23:15', departureTime: '23:30', platform: 'Nástupište 2', distanceKm: 65 },
      { stationCode: 'GYO', stationName: 'Győr', city: 'Győr', arrivalTime: '01:20', departureTime: '01:32', platform: '2. vágány', distanceKm: 140 },
      { stationCode: 'BUD', stationName: 'Budapest-Keleti', city: 'Budapest', arrivalTime: '06:40', departureTime: '—', platform: '7. vágány', distanceKm: 275 }
    ],
    basePriceGbp: 69,
    availableCabins: ['seat', 'couchette', 'private', 'grand_sleeper'],
    carbonSavedKg: 95
  },
  {
    id: 'NL-720',
    trainNumber: 'NL 720',
    trainName: 'Kattegat Sleeper',
    fromStationCode: 'CPH',
    toStationCode: 'BER',
    departureTime: '21:10',
    arrivalTime: '07:35',
    daysOffset: 1,
    duration: '10h 25m',
    isDirect: true,
    stops: [
      { stationCode: 'CPH', stationName: 'København H', city: 'Copenhagen', arrivalTime: '—', departureTime: '21:10', platform: 'Spor 6', distanceKm: 0 },
      { stationCode: 'ODE', stationName: 'Odense', city: 'Odense', arrivalTime: '22:35', departureTime: '22:48', platform: 'Spor 3', distanceKm: 165 },
      { stationCode: 'HAM', stationName: 'Hamburg Hbf', city: 'Hamburg', arrivalTime: '04:30', departureTime: '04:45', platform: 'Gleis 13', distanceKm: 480 },
      { stationCode: 'BER', stationName: 'Berlin Hauptbahnhof', city: 'Berlin', arrivalTime: '07:35', departureTime: '—', platform: 'Gleis 2', distanceKm: 765 }
    ],
    basePriceGbp: 89,
    availableCabins: ['seat', 'couchette', 'private', 'grand_sleeper'],
    carbonSavedKg: 154
  }
];

export const CABIN_CLASSES: CabinClass[] = [
  {
    id: 'seat',
    name: 'Reclining Overnight Seat',
    subtitle: 'Quiet carriage travel with ergonomic repose',
    description: 'Generous 40-degree reclining seat in a dedicated silent sleeper coach. Designed with winged headrests, personal warm reading lamp, USB-C fast charging, and privacy shell.',
    priceFromGbp: 89,
    maxOccupancy: 1,
    beds: 'Ergonomic 40° recline padded seat with footrest',
    bedding: 'Light wool fleece blanket and ergonomic eye mask provided',
    privacy: 'High privacy winged headrest wings & footwell baffle',
    washbasin: 'Shared restroom & washroom facilities in coach vestibule',
    enSuite: false,
    breakfastIncluded: false,
    wifi: 'Complimentary High-Speed Starlink Wi-Fi',
    power: 'Individual 230V European socket + 65W USB-C',
    luggage: 'Overhead rack + lockable under-seat cavity (1 large + 1 cabin bag)',
    accessibility: 'Step-free carriage access & wheelchair accessible positions available',
    dimensions: 'Seat pitch 102 cm (40 in), width 52 cm',
    image: '/images/hero_sleeper.jpg',
    features: ['Silent carriage policy from 22:00', 'Individual dimmable brass reading light', 'USB-C 65W Power', 'Attendant assistance at vestibule'],
    berths: [
      { id: 'S1', label: 'Seat 1 (Window)', tier: 'seat', side: 'window', isAvailable: true, priceDelta: 0 },
      { id: 'S2', label: 'Seat 2 (Aisle)', tier: 'seat', side: 'aisle', isAvailable: true, priceDelta: 0 },
      { id: 'S3', label: 'Seat 3 (Aisle)', tier: 'seat', side: 'aisle', isAvailable: false, priceDelta: 0 },
      { id: 'S4', label: 'Seat 4 (Window)', tier: 'seat', side: 'window', isAvailable: true, priceDelta: 0 }
    ]
  },
  {
    id: 'couchette',
    name: '4-Person Couchette',
    subtitle: 'Social, comfortable European overnight classic',
    description: 'Shared or book-as-private 4-berth compartment. Clean architectural layout with fold-out cushioned bunks, fresh duvet bedding with crisp cotton sheets, reading spots, and lockable compartment door.',
    priceFromGbp: 149,
    maxOccupancy: 4,
    beds: '4 full-length cushioned bunks (195 cm x 72 cm)',
    bedding: 'Crisp pressed linen duvet, feather pillow, and soft wool blanket',
    privacy: 'Lockable door from inside; privacy curtains on all berths',
    washbasin: 'Washrooms and WC located at both ends of each carriage',
    enSuite: false,
    breakfastIncluded: true,
    wifi: 'Complimentary High-Speed Starlink Wi-Fi',
    power: 'Individual charging points at every berth',
    luggage: 'Under-berth storage plus dedicated overhead luggage vault',
    accessibility: 'Lower berth accessible; assist handles fitted',
    dimensions: 'Compartment 210 cm x 205 cm',
    image: '/images/cabin_couchette.jpg',
    features: ['Complimentary mineral water', 'Included Morning Bakery basket & coffee', 'Lockable compartment door', 'Individual berth curtain & light'],
    berths: [
      { id: 'C-LL', label: 'Lower Berth (Left)', tier: 'lower', side: 'left', isAvailable: true, priceDelta: 0 },
      { id: 'C-LR', label: 'Lower Berth (Right)', tier: 'lower', side: 'right', isAvailable: true, priceDelta: 0 },
      { id: 'C-UL', label: 'Upper Berth (Left)', tier: 'upper', side: 'left', isAvailable: true, priceDelta: -10 },
      { id: 'C-UR', label: 'Upper Berth (Right)', tier: 'upper', side: 'right', isAvailable: false, priceDelta: -10 }
    ]
  },
  {
    id: 'private',
    name: 'Private Sleeper Cabin',
    subtitle: 'Exclusive 2-person cabin with private washbasin',
    description: 'A sanctuary on the rails. Dedicated private 2-person cabin featuring walnut timber detailing, hotel-grade mattress, fine linen, integrated vanity washbasin with hot running water, and smart cabin temperature controls.',
    priceFromGbp: 249,
    maxOccupancy: 2,
    beds: '1 or 2 berths (convertible to single use or bunk configuration)',
    bedding: 'Luxury 300-thread Egyptian cotton, down duvets, firm/soft pillows',
    privacy: 'Completely private lockable compartment with digital keycard',
    washbasin: 'Private in-cabin porcelain washbasin with warm water & mirror',
    enSuite: false,
    breakfastIncluded: true,
    wifi: 'Premium priority satellite Wi-Fi',
    power: '2x 230V AC socket, 4x USB-C fast charge, wireless charging ledge',
    luggage: 'Spacious in-cabin luggage cavity and wardrobe with wooden hangers',
    accessibility: 'Lower berth step-free; corridor width 78 cm',
    dimensions: 'Compartment 225 cm x 180 cm',
    image: '/images/cabin_grand_sleeper.jpg',
    features: ['Hot washbasin & organic toiletries kit', 'Included Gourmet Alpine Breakfast', 'Smart cabin temperature & light dials', 'Welcome mineral water & Swiss chocolate'],
    berths: [
      { id: 'P-LOW', label: 'Lower Berth (Comfort Access)', tier: 'lower', side: 'window', isAvailable: true, priceDelta: 0 },
      { id: 'P-UPP', label: 'Upper Berth (Panoramic Night View)', tier: 'upper', side: 'window', isAvailable: true, priceDelta: 0 }
    ]
  },
  {
    id: 'grand_sleeper',
    name: 'Grand Sleeper Suite',
    subtitle: 'The pinnacle of private European rail luxury',
    description: 'Uncompromising overnight indulgence. A spacious suite featuring a permanent double bed (or twin), private en-suite bathroom with rainfall shower and WC, panoramic soundproof window, lounge seating, and dedicated steward service.',
    priceFromGbp: 449,
    maxOccupancy: 2,
    beds: 'Plush Queen double bed (160 cm x 200 cm) or twin luxury beds',
    bedding: 'Heritage European goose-down bedding, cashmere throw, silk eye-masks',
    privacy: 'Total soundproofed privacy with electronic privacy indicator',
    washbasin: 'Full private en-suite bathroom with hot rainfall shower & private WC',
    enSuite: true,
    breakfastIncluded: true,
    wifi: 'Ultra-fast dedicated Starlink gigabit stream',
    power: 'Universal international sockets, wireless pads, bedside USB-C PD',
    luggage: 'Full-height mahogany wardrobe, valet luggage transfer service',
    accessibility: 'Wide-entry door, level access shower with grab rails',
    dimensions: 'Suite 270 cm x 240 cm (6.5 m²)',
    image: '/images/cabin_grand_sleeper.jpg',
    features: ['Private rainfall shower & WC in suite', 'Complimentary Champagne welcome bottle', 'Full First-Class station lounge access', 'À la carte breakfast served in bed by steward'],
    berths: [
      { id: 'GS-DBL', label: 'Queen Double Bed (Suite Master)', tier: 'lower', side: 'window', isAvailable: true, priceDelta: 0 }
    ]
  }
];

export const BOOKING_EXTRAS: BookingExtra[] = [
  {
    id: 'ex-breakfast-gourmet',
    name: 'Artisan Alpine Breakfast Basket',
    category: 'dining',
    description: 'Freshly baked croissants, sourdough bread, Swiss Emmental, black forest ham, artisan preserves, and freshly squeezed orange juice.',
    priceGbp: 16,
    iconName: 'Coffee',
    includedForCabins: ['grand_sleeper']
  },
  {
    id: 'ex-dinner-3course',
    name: 'Restaurant Car 3-Course Dinner',
    category: 'dining',
    description: 'Reserved evening seating in the dining carriage. Includes seasonal soup/salad, signature European main course, and dessert.',
    priceGbp: 38,
    iconName: 'Utensils'
  },
  {
    id: 'ex-wine-pairing',
    name: 'Sommelier Wine & Artisan Cheese',
    category: 'dining',
    description: 'Half bottle of Burgundy Pinot Noir or Chablis paired with three regional European cheeses, grapes, and walnut crackers.',
    priceGbp: 24,
    iconName: 'Wine'
  },
  {
    id: 'ex-lounge-access',
    name: 'First-Class Station Lounge Access',
    category: 'comfort',
    description: 'Relax before departure with complimentary barista beverages, aperitifs, high-speed Wi-Fi, and private showers in London, Paris, or Zürich.',
    priceGbp: 22,
    iconName: 'Sparkles',
    includedForCabins: ['grand_sleeper']
  },
  {
    id: 'ex-bicycle-space',
    name: 'Guaranteed Bicycle Vault Reservation',
    category: 'travel',
    description: 'Secure, vertical hanging bicycle rack inside the climate-controlled baggage car with monitored access.',
    priceGbp: 15,
    iconName: 'Bike'
  },
  {
    id: 'ex-pet-accommodation',
    name: 'Pet Travel Accommodation',
    category: 'travel',
    description: 'Comfortable fleece travel mat and food bowl kit for your dog or cat in private compartments.',
    priceGbp: 28,
    iconName: 'Heart'
  },
  {
    id: 'ex-shower-kit',
    name: 'Botanical Shower & Spa Kit',
    category: 'comfort',
    description: 'Plush waffle bathrobe, spa slippers, and travel kit containing cedarwood shampoo, body wash, and face mist.',
    priceGbp: 14,
    iconName: 'ShowerHead',
    includedForCabins: ['grand_sleeper']
  },
  {
    id: 'ex-station-transfer',
    name: 'Destination Station Electric Transfer',
    category: 'transfer',
    description: 'Private chauffeur meeting you directly at the train platform for transfer to any central hotel in the arrival city.',
    priceGbp: 48,
    iconName: 'Car'
  }
];

export const DINING_MENU: DiningMenuItem[] = [
  {
    id: 'm-1',
    course: 'starters',
    name: 'Velouté of Forest Mushrooms',
    description: 'Wild chantarelles, truffle foam, roasted hazelnut crunch, served with toasted sourdough bread.',
    priceGbp: 12,
    dietary: ['Vegetarian', 'Gluten-Free upon request'],
    pairing: 'Chablis Premier Cru 2022'
  },
  {
    id: 'm-2',
    course: 'starters',
    name: 'Smoked Alpine Char Tartare',
    description: 'Lake Geneva char, pickled mustard seeds, dill emulsion, crisp rye crackers.',
    priceGbp: 15,
    dietary: ['Pescatarian'],
    pairing: 'Grüner Veltliner Smaragd'
  },
  {
    id: 'm-3',
    course: 'mains',
    name: 'Braised Beef Cheek à la Bourguignonne',
    description: 'Slow-cooked in red Burgundy wine with glazed pearl onions, smoked pancetta, and creamy potato mousseline.',
    priceGbp: 28,
    dietary: ['Gluten-Free'],
    pairing: 'Gevrey-Chambertin 2020'
  },
  {
    id: 'm-4',
    course: 'mains',
    name: 'Risotto with Swiss Mountain Herbs & Morel',
    description: 'Carnaroli rice, aged Gruyère AOP, pan-roasted morels, white wine, and fresh mountain chives.',
    priceGbp: 24,
    dietary: ['Vegetarian', 'Gluten-Free'],
    pairing: 'Pinot Bianco Alto Adige'
  },
  {
    id: 'm-5',
    course: 'mains',
    name: 'Roasted Celeriac Steak with Truffled Jus',
    description: 'Slow-roasted root celeriac, braised Puy lentils, hazelnut brown butter, winter greens.',
    priceGbp: 22,
    dietary: ['Vegan', 'Gluten-Free'],
    pairing: 'Côtes du Rhône Rouge'
  },
  {
    id: 'm-6',
    course: 'desserts',
    name: 'Valrhona Dark Chocolate Marquise',
    description: '70% Guanaja chocolate, salted caramel center, Tahitian vanilla crème anglaise.',
    priceGbp: 11,
    dietary: ['Vegetarian'],
    pairing: 'Taylor’s 10-Year Tawny Port'
  },
  {
    id: 'm-7',
    course: 'desserts',
    name: 'Warm Tarte Tatin with Clotted Cream',
    description: 'Caramelized Golden Delicious apples in puff pastry, double Jersey cream.',
    priceGbp: 10,
    dietary: ['Vegetarian'],
    pairing: 'Château d’Yquem Sauternes'
  },
  {
    id: 'w-1',
    course: 'wines',
    name: 'Billecart-Salmon Brut Réserve Champagne',
    description: 'Fine bubbles, brioche notes, ripe pear, refreshing finish. 750ml bottle.',
    priceGbp: 68,
    dietary: ['Sparkling']
  },
  {
    id: 'w-2',
    course: 'wines',
    name: 'Domaine Dujac Morey-Saint-Denis 2021',
    description: 'Complex red berries, earthy spice, velvety tannins. 750ml bottle.',
    priceGbp: 58,
    dietary: ['Red Wine']
  },
  {
    id: 'd-1',
    course: 'digestifs',
    name: 'Chartreuse V.E.P. Verte',
    description: 'Legendary Carthusian herbal liqueur aged in oak casks. 40ml pour.',
    priceGbp: 16,
    dietary: ['Liqueur']
  }
];

export const DEFAULT_ACTIVE_BOOKING: Booking = {
  id: 'b-default-zurich',
  reference: 'NL-8942-ZUR',
  createdAt: '2026-10-10T14:30:00Z',
  train: TIMETABLE_TRAINS[0], // NL 402 London -> Zurich
  travelDate: '2026-10-16',
  cabinClass: CABIN_CLASSES[2], // Private Sleeper
  cabinNumber: 'Carriage 14, Cabin 204',
  selectedBerthLabels: ['Lower Berth (Comfort Access)'],
  passengers: [
    {
      id: 'p-1',
      type: 'adult',
      title: 'Mr',
      firstName: 'Thomas',
      lastName: 'Harding',
      passportNumber: 'GB98234812',
      railcard: 'Eurail Global Pass',
      dietaryPreference: 'continental',
      berthSelection: 'Lower Berth (Comfort Access)'
    }
  ],
  extras: [
    BOOKING_EXTRAS[0], // Alpine Breakfast
    BOOKING_EXTRAS[1]  // Restaurant Car Dinner
  ],
  totalAmountGbp: 303,
  currency: 'GBP',
  status: 'confirmed',
  qrCodeToken: 'NL402-STP-ZUR-20261016-CAB204-BLOW-8942'
};

export const INITIAL_LIVE_STATUS: LiveTrainStatus = {
  trainNumber: 'NL 402',
  trainName: 'Helvetia Nocturne',
  routeTitle: 'London St Pancras → Zürich HB',
  status: 'ON TIME',
  isEnRoute: true,
  currentLocationName: 'Approaching Paris Gare du Nord (Oise Valley)',
  nextStation: 'Paris Gare du Nord',
  estimatedArrival: '23:05',
  delayMinutes: 0,
  currentSpeedKmH: 198,
  platform: 'Platform 9 (St Pancras Departure) / Track 7 (Zürich Arrival)',
  outdoorTempCelsius: 11,
  weatherDescription: 'Clear autumn night, gentle breeze (10°C)',
  progressPercent: 44,
  serviceAlert: 'Express night corridor: Quiet hours in effect until 06:30. Onboard dining car open until 23:30.'
};
