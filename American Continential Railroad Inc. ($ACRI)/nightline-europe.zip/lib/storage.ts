import { Booking, CabinSmartControlState, Currency, Language } from './types';
import { DEFAULT_ACTIVE_BOOKING } from './mock-data';

const STORAGE_KEYS = {
  BOOKINGS: 'nightline_bookings_v1',
  ACTIVE_BOOKING_ID: 'nightline_active_booking_id_v1',
  CABIN_CONTROLS: 'nightline_cabin_controls_v1',
  CURRENCY: 'nightline_currency_v1',
  LANGUAGE: 'nightline_language_v1'
};

const DEFAULT_CABIN_CONTROLS: CabinSmartControlState = {
  readingLightBrightness: 80,
  cabinTemperatureCelsius: 20.5,
  privacyMode: 'normal',
  ambientLighting: 'warm_amber',
  wakeUpTime: '06:30',
  wakeUpOption: '30_min_before',
  wakeUpConfirmed: false,
  attendantCalled: false,
  breakfastSelected: 'continental',
  breakfastTime: '07:00',
  breakfastDelivered: false
};

export const getStoredBookings = (): Booking[] => {
  if (typeof window === 'undefined') return [DEFAULT_ACTIVE_BOOKING];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify([DEFAULT_ACTIVE_BOOKING]));
      return [DEFAULT_ACTIVE_BOOKING];
    }
    return JSON.parse(raw);
  } catch {
    return [DEFAULT_ACTIVE_BOOKING];
  }
};

export const saveBooking = (newBooking: Booking): void => {
  if (typeof window === 'undefined') return;
  try {
    const current = getStoredBookings();
    const updated = [newBooking, ...current.filter(b => b.id !== newBooking.id)];
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(updated));
    localStorage.setItem(STORAGE_KEYS.ACTIVE_BOOKING_ID, newBooking.id);
  } catch (e) {
    console.error('Failed to save booking', e);
  }
};

export const cancelBookingInStorage = (bookingId: string): void => {
  if (typeof window === 'undefined') return;
  try {
    const current = getStoredBookings();
    const updated = current.map(b => b.id === bookingId ? { ...b, status: 'cancelled' as const } : b);
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to cancel booking', e);
  }
};

export const getActiveBooking = (): Booking => {
  if (typeof window === 'undefined') return DEFAULT_ACTIVE_BOOKING;
  try {
    const activeId = localStorage.getItem(STORAGE_KEYS.ACTIVE_BOOKING_ID);
    const bookings = getStoredBookings();
    const found = bookings.find(b => b.id === activeId);
    return found || bookings[0] || DEFAULT_ACTIVE_BOOKING;
  } catch {
    return DEFAULT_ACTIVE_BOOKING;
  }
};

export const setActiveBookingId = (id: string): void => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.ACTIVE_BOOKING_ID, id);
};

export const getStoredCabinControls = (): CabinSmartControlState => {
  if (typeof window === 'undefined') return DEFAULT_CABIN_CONTROLS;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CABIN_CONTROLS);
    if (!raw) return DEFAULT_CABIN_CONTROLS;
    return { ...DEFAULT_CABIN_CONTROLS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_CABIN_CONTROLS;
  }
};

export const saveCabinControls = (controls: Partial<CabinSmartControlState>): CabinSmartControlState => {
  if (typeof window === 'undefined') return { ...DEFAULT_CABIN_CONTROLS, ...controls };
  try {
    const current = getStoredCabinControls();
    const updated = { ...current, ...controls };
    localStorage.setItem(STORAGE_KEYS.CABIN_CONTROLS, JSON.stringify(updated));
    return updated;
  } catch {
    return { ...DEFAULT_CABIN_CONTROLS, ...controls };
  }
};

export const getStoredCurrency = (): Currency => {
  if (typeof window === 'undefined') return 'GBP';
  return (localStorage.getItem(STORAGE_KEYS.CURRENCY) as Currency) || 'GBP';
};

export const setStoredCurrency = (currency: Currency): void => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.CURRENCY, currency);
};

export const getStoredLanguage = (): Language => {
  if (typeof window === 'undefined') return 'en';
  return (localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language) || 'en';
};

export const setStoredLanguage = (language: Language): void => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.LANGUAGE, language);
};

export const formatPrice = (amountGbp: number, currency: Currency): string => {
  const rates: Record<Currency, { rate: number; symbol: string; suffix?: string }> = {
    GBP: { rate: 1.0, symbol: '£' },
    EUR: { rate: 1.18, symbol: '€' },
    CHF: { rate: 1.12, symbol: 'CHF ' }
  };

  const item = rates[currency] || rates.GBP;
  const converted = Math.round(amountGbp * item.rate);
  return `${item.symbol}${converted}`;
};
