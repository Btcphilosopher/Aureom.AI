import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Nightline Europe — Europe While You Sleep | Premium Overnight Sleeper Trains',
  description: 'Connecting Europe’s great cities overnight in private luxury cabins. Wake up refreshed in Zürich, Vienna, Paris, Berlin, Milan, and Prague.',
  openGraph: {
    title: 'Nightline Europe — Europe While You Sleep',
    description: 'Connecting Europe’s great cities overnight in private luxury cabins. Wake up refreshed in Zürich, Vienna, Paris, Berlin, Milan, and Prague.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nightline Europe — Europe While You Sleep',
    description: 'Connecting Europe’s great cities overnight in private luxury cabins. Wake up refreshed in Zürich, Vienna, Paris, Berlin, Milan, and Prague.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-[#070B18] text-[#F8F5EE] antialiased selection:bg-[#C8A86B]/30 selection:text-[#F8F5EE]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
