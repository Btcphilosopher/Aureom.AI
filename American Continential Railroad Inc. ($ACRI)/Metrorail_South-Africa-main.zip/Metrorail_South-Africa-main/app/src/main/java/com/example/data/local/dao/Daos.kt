package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StationDao {
    @Query("SELECT * FROM stations ORDER BY name ASC")
    fun getAllStations(): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations WHERE region = :region ORDER BY name ASC")
    fun getStationsByRegion(region: String): Flow<List<StationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    @Query("SELECT COUNT(*) FROM stations")
    suspend fun getStationCount(): Int
}

@Dao
interface TicketDao {
    @Query("SELECT * FROM tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Query("SELECT * FROM tickets WHERE status = 'Active' AND expiryTimestamp > :currentTime ORDER BY purchaseTimestamp DESC")
    fun getActiveTickets(currentTime: Long): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Update
    suspend fun updateTicket(ticket: TicketEntity)

    @Query("UPDATE tickets SET status = :status WHERE id = :ticketId")
    suspend fun updateTicketStatus(ticketId: String, status: String)
}

@Dao
interface FavoriteRouteDao {
    @Query("SELECT * FROM favorite_routes ORDER BY id DESC")
    fun getAllFavoriteRoutes(): Flow<List<FavoriteRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteRoute(route: FavoriteRouteEntity)

    @Delete
    suspend fun deleteFavoriteRoute(route: FavoriteRouteEntity)
}

@Dao
interface ServiceAlertDao {
    @Query("SELECT * FROM service_alerts ORDER BY timestamp DESC")
    fun getAllAlerts(): Flow<List<ServiceAlertEntity>>

    @Query("SELECT * FROM service_alerts WHERE region = :region AND isResolved = 0 ORDER BY timestamp DESC")
    fun getActiveAlertsByRegion(region: String): Flow<List<ServiceAlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<ServiceAlertEntity>)

    @Query("DELETE FROM service_alerts")
    suspend fun clearAllAlerts()
}

@Dao
interface SupportMessageDao {
    @Query("SELECT * FROM support_messages ORDER BY timestamp ASC")
    fun getChatHistory(): Flow<List<SupportMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: SupportMessageEntity)

    @Query("DELETE FROM support_messages")
    suspend fun clearChatHistory()
}
