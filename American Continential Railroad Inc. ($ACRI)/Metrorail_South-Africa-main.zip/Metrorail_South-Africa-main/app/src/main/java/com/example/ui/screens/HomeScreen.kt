package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entity.StationEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetrorailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MetrorailViewModel,
    modifier: Modifier = Modifier
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val selectedRegion by viewModel.selectedRegion.collectAsState()
    val regionAlerts by viewModel.regionAlerts.collectAsState()
    val favoriteRoutes by viewModel.favoriteRoutes.collectAsState()

    var showRegionMenu by remember { mutableStateOf(false) }
    var showLanguageMenu by remember { mutableStateOf(false) }

    val regions = listOf(
        "Cape Town", "Johannesburg", "Pretoria", "Durban",
        "Gqeberha", "East London", "Bloemfontein"
    )

    val languages = mapOf(
        "en" to "🇬🇧 English",
        "af" to "🇿🇦 Afrikaans",
        "zu" to "🇿🇦 isiZulu",
        "xh" to "🇿🇦 isiXhosa"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LightGrey),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Clean Top Header Bar (Geometric Balance Theme)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Geometric Square M Badge
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(DeepBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "M",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                    Column {
                        Text(
                            text = "Metrorail SA",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalGrey
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldGreen)
                            )
                            Text(
                                text = "$selectedRegion Region",
                                fontSize = 11.sp,
                                color = CharcoalGrey.copy(alpha = 0.5f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Language & Region Dropdowns
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Region Selector
                    Box {
                        TextButton(
                            onClick = { showRegionMenu = true },
                            colors = ButtonDefaults.textButtonColors(contentColor = DeepBlue),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("region_selector_button")
                        ) {
                            Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(text = selectedRegion.take(4) + "..", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        DropdownMenu(
                            expanded = showRegionMenu,
                            onDismissRequest = { showRegionMenu = false }
                        ) {
                            regions.forEach { r ->
                                DropdownMenuItem(
                                    text = { Text(r, fontWeight = if (r == selectedRegion) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                                    onClick = {
                                        viewModel.setRegion(r)
                                        showRegionMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Language Selector
                    Box {
                        TextButton(
                            onClick = { showLanguageMenu = true },
                            colors = ButtonDefaults.textButtonColors(contentColor = DeepBlue),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("language_selector_button")
                        ) {
                            Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(text = currentLanguage.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        DropdownMenu(
                            expanded = showLanguageMenu,
                            onDismissRequest = { showLanguageMenu = false }
                        ) {
                            languages.forEach { (code, label) ->
                                DropdownMenuItem(
                                    text = { Text(label, fontWeight = if (code == currentLanguage) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                                    onClick = {
                                        viewModel.setLanguage(code)
                                        showLanguageMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
            HorizontalDivider(color = Color(0xFFF2F2F7), thickness = 1.dp)
        }

        // 2. Geometric Hero Card Banner (Integrated in page with curved boundaries)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(180.dp)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_metro_hero),
                    contentDescription = "Metrorail Train",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Linear gradient overlay for high contrast and modern styling
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)),
                                startY = 100f
                            )
                        )
                )

                // Welcome text at bottom left
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = viewModel.translate("welcome"),
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = viewModel.translate("safe_commute"),
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp
                    )
                }
            }
        }

        // 3. Active Service Alerts Warning Bar
        if (regionAlerts.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (regionAlerts.any { it.severity == "Critical" }) Color(0xFFFEF2F2) else Color(0xFFFEFCE8)
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(
                        1.dp,
                        if (regionAlerts.any { it.severity == "Critical" }) Color(0xFFFCA5A5) else Color(0xFFFDE047)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Alert",
                            tint = if (regionAlerts.any { it.severity == "Critical" }) Color(0xFFEF4444) else Color(0xFFD97706),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${regionAlerts.size} ${viewModel.translate("service_alerts")} Active",
                                fontWeight = FontWeight.Bold,
                                color = CharcoalGrey,
                                fontSize = 14.sp
                            )
                            Text(
                                text = regionAlerts.first().title,
                                fontSize = 12.sp,
                                color = CharcoalGrey.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { viewModel.setScreen("LiveInfo") }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "View Alerts",
                                tint = CharcoalGrey,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        } else {
            item { Spacer(modifier = Modifier.height(4.dp)) }
        }

        // 4. Quick Action Hub (Enterprise Features styled with Geometric Balance)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "Commuter Services",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalGrey,
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FeatureCard(
                        title = viewModel.translate("buy_ticket"),
                        subtitle = "Fast QR Passes",
                        icon = Icons.Default.QrCodeScanner,
                        color = DeepBlue,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_nav_buy_ticket")
                    ) { viewModel.setScreen("BuyTicket") }

                    FeatureCard(
                        title = viewModel.translate("journey_planner"),
                        subtitle = "Schedules & Routes",
                        icon = Icons.Default.DirectionsRun,
                        color = SkyBlue,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_nav_planner")
                    ) { viewModel.setScreen("Planner") }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FeatureCard(
                        title = viewModel.translate("my_tickets"),
                        subtitle = "Offline Storage",
                        icon = Icons.Default.LocalActivity,
                        color = SkyBlue,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_nav_tickets")
                    ) { viewModel.setScreen("MyTickets") }

                    FeatureCard(
                        title = viewModel.translate("live_departures"),
                        subtitle = "Live Tracking & Map",
                        icon = Icons.Default.Train,
                        color = SkyBlue,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_nav_live")
                    ) { viewModel.setScreen("LiveInfo") }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FeatureCard(
                        title = viewModel.translate("ai_assistant"),
                        subtitle = "Multilingual Travel AI",
                        icon = Icons.Default.Psychology,
                        color = SkyBlue,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_nav_ai")
                    ) { viewModel.setScreen("AIAssistant") }

                    FeatureCard(
                        title = viewModel.translate("support"),
                        subtitle = "Chat, FAQ & Safety",
                        icon = Icons.Default.ContactSupport,
                        color = SkyBlue,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_nav_support")
                    ) { viewModel.setScreen("Support") }
                }
            }
        }

        // 5. Favourite Saved Routes (One-touch shortcuts)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "My Regular Journeys",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalGrey
                    )
                    if (favoriteRoutes.isNotEmpty()) {
                        Text(
                            text = "Tap to Plan",
                            fontSize = 11.sp,
                            color = DeepBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (favoriteRoutes.isEmpty()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, Color(0xFFF2F2F7))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Outlined.StarOutline,
                                contentDescription = null,
                                tint = DeepBlue.copy(alpha = 0.4f),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No favorite routes saved yet.",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalGrey
                            )
                            Text(
                                text = "Use Journey Planner to save regular routes for rapid planning.",
                                fontSize = 11.sp,
                                color = CharcoalGrey.copy(alpha = 0.5f),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(favoriteRoutes) { fav ->
                            Card(
                                modifier = Modifier
                                    .width(200.dp)
                                    .clickable {
                                        // Auto load into planner
                                        val originStation = viewModel.stations.value.find { it.id == fav.originStationId }
                                        val destStation = viewModel.stations.value.find { it.id == fav.destinationStationId }
                                        viewModel.setPlannerOrigin(originStation)
                                        viewModel.setPlannerDestination(destStation)
                                        viewModel.findJourney()
                                        viewModel.setScreen("Planner")
                                    },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, Color(0xFFF2F2F7))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Bookmark, contentDescription = null, tint = TransitGold, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = fav.label, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, color = CharcoalGrey)
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteFavorite(fav) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(text = fav.originStationName, fontSize = 11.sp, color = CharcoalGrey.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = DeepBlue.copy(alpha = 0.5f), modifier = Modifier.size(12.dp).padding(vertical = 1.dp))
                                    Text(text = fav.destinationStationName, fontSize = 11.sp, color = CharcoalGrey.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. System Administration Portal entry link (Footer highlight)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clickable { viewModel.setScreen("Admin") },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color(0xFFF2F2F7))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DeepBlue.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = DeepBlue, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Enterprise Command Center",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = CharcoalGrey
                            )
                            Text(
                                text = "Operations & analytics monitoring portal",
                                fontSize = 11.sp,
                                color = CharcoalGrey.copy(alpha = 0.5f)
                            )
                        }
                    }
                    Icon(Icons.Default.ArrowForward, contentDescription = "Go to Admin", tint = CharcoalGrey.copy(alpha = 0.4f), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun FeatureCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    contentTint: Color = OffWhite,
    onClick: () -> Unit
) {
    val isPrimary = color == DeepBlue
    val containerColor = if (isPrimary) DeepBlue else Color(0xFFF2F2F7)
    val textAndIconColor = if (isPrimary) Color.White else DeepBlue
    val iconBgColor = if (isPrimary) Color.White.copy(alpha = 0.15f) else DeepBlue.copy(alpha = 0.05f)
    val border = if (isPrimary) null else BorderStroke(1.dp, Color(0xFFE2E8F0))

    Card(
        modifier = modifier
            .height(115.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(24.dp),
        border = border,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Icon in circular box
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = textAndIconColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Column {
                Text(
                    text = title,
                    color = textAndIconColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    lineHeight = 16.sp
                )
                Text(
                    text = subtitle,
                    color = textAndIconColor.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    lineHeight = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
