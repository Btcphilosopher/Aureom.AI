package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val region: String, // Cape Town, Johannesburg, Pretoria, Durban, etc.
    val latitude: Double,
    val longitude: Double,
    val hasWheelchairAccess: Boolean,
    val hasLifts: Boolean,
    val hasStepFreeAccess: Boolean,
    val ticketOfficeOpen: Boolean,
    val securityLevel: String // "Standard", "Enhanced"
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val originStationId: String,
    val originStationName: String,
    val destinationStationId: String,
    val destinationStationName: String,
    val ticketType: String, // Single, Return, Weekly, Monthly, Student, Senior, Child
    val passengerType: String, // Adult, Student, Senior, Child, Group
    val fare: Double,
    val purchaseTimestamp: Long,
    val expiryTimestamp: Long,
    val status: String, // Active, Used, Expired, Refunded
    val qrCodePayload: String,
    val receiptNumber: String
)

@Entity(tableName = "favorite_routes")
data class FavoriteRouteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val label: String, // "Home", "Work", "School", etc.
    val originStationId: String,
    val originStationName: String,
    val destinationStationId: String,
    val destinationStationName: String
)

@Entity(tableName = "service_alerts")
data class ServiceAlertEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val region: String,
    val lineName: String, // "Southern Line", "Central Line", etc.
    val severity: String, // Info, Warning, Critical
    val timestamp: Long,
    val isResolved: Boolean
)

@Entity(tableName = "support_messages")
data class SupportMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val isFromUser: Boolean,
    val timestamp: Long,
    val languageCode: String // en, af, zu, xh, etc.
)
