package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.data.local.AppDatabase
import com.example.data.local.entity.*
import com.example.data.remote.Content
import com.example.data.remote.GenerateContentRequest
import com.example.data.remote.Part
import com.example.data.remote.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.UUID

class MetrorailRepository(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val stationDao = db.stationDao()
    private val ticketDao = db.ticketDao()
    private val favoriteRouteDao = db.favoriteRouteDao()
    private val serviceAlertDao = db.serviceAlertDao()
    private val supportMessageDao = db.supportMessageDao()

    // Expose flows for reactive UI observation
    val allStations: Flow<List<StationEntity>> = stationDao.getAllStations()
    val allTickets: Flow<List<TicketEntity>> = ticketDao.getAllTickets()
    val favoriteRoutes: Flow<List<FavoriteRouteEntity>> = favoriteRouteDao.getAllFavoriteRoutes()
    val allAlerts: Flow<List<ServiceAlertEntity>> = serviceAlertDao.getAllAlerts()
    val chatHistory: Flow<List<SupportMessageEntity>> = supportMessageDao.getChatHistory()

    init {
        // Run seed on database initialization asynchronously
        kotlin.concurrent.thread {
            kotlinx.coroutines.runBlocking {
                seedStationsIfNeeded()
                seedServiceAlertsIfNeeded()
            }
        }
    }

    suspend fun getStationsByRegion(region: String): List<StationEntity> = withContext(Dispatchers.IO) {
        stationDao.getStationsByRegion(region).first()
    }

    suspend fun getActiveTickets(): List<TicketEntity> = withContext(Dispatchers.IO) {
        ticketDao.getActiveTickets(System.currentTimeMillis()).first()
    }

    suspend fun purchaseTicket(
        origin: StationEntity,
        destination: StationEntity,
        ticketType: String,
        passengerType: String,
        fare: Double
    ): TicketEntity = withContext(Dispatchers.IO) {
        val ticketId = "MRZA-${UUID.randomUUID().toString().take(8).uppercase()}"
        val receiptNum = "REC-${System.currentTimeMillis().toString().takeLast(8)}"
        val validityHours = when (ticketType) {
            "Single" -> 3L
            "Return" -> 24L
            "Weekly Pass" -> 24L * 7
            "Monthly Pass" -> 24L * 30
            "Student Pass" -> 24L * 30
            "Senior Pass" -> 24L * 30
            else -> 3L
        }

        val ticket = TicketEntity(
            id = ticketId,
            originStationId = origin.id,
            originStationName = origin.name,
            destinationStationId = destination.id,
            destinationStationName = destination.name,
            ticketType = ticketType,
            passengerType = passengerType,
            fare = fare,
            purchaseTimestamp = System.currentTimeMillis(),
            expiryTimestamp = System.currentTimeMillis() + (validityHours * 60 * 60 * 1000),
            status = "Active",
            qrCodePayload = "METRORAIL_ZA|V1|$ticketId|${origin.id}|${destination.id}|$ticketType|$passengerType",
            receiptNumber = receiptNum
        )
        ticketDao.insertTicket(ticket)
        ticket
    }

    suspend fun addFavoriteRoute(label: String, origin: StationEntity, destination: StationEntity) = withContext(Dispatchers.IO) {
        favoriteRouteDao.insertFavoriteRoute(
            FavoriteRouteEntity(
                label = label,
                originStationId = origin.id,
                originStationName = origin.name,
                destinationStationId = destination.id,
                destinationStationName = destination.name
            )
        )
    }

    suspend fun deleteFavoriteRoute(route: FavoriteRouteEntity) = withContext(Dispatchers.IO) {
        favoriteRouteDao.deleteFavoriteRoute(route)
    }

    suspend fun clearChat() = withContext(Dispatchers.IO) {
        supportMessageDao.clearChatHistory()
    }

    suspend fun sendUserMessage(text: String, languageCode: String): String = withContext(Dispatchers.IO) {
        // 1. Insert user message to database
        supportMessageDao.insertMessage(
            SupportMessageEntity(text = text, isFromUser = true, timestamp = System.currentTimeMillis(), languageCode = languageCode)
        )

        // 2. Query chatbot response
        val responseText = queryGeminiAiAssistant(text, languageCode)

        // 3. Insert system response to database
        supportMessageDao.insertMessage(
            SupportMessageEntity(text = responseText, isFromUser = false, timestamp = System.currentTimeMillis(), languageCode = languageCode)
        )

        responseText
    }

    private suspend fun queryGeminiAiAssistant(userPrompt: String, languageCode: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w("MetrorailRepository", "Gemini API key is not configured. Falling back to local responder.")
            return getLocalSupportFallback(userPrompt, languageCode)
        }

        try {
            // Include helpful transit context and languages in system instruction
            val systemInstructionText = """
                You are the official Metrorail South Africa AI Travel Assistant.
                Your goal is to assist commuters with planning journeys, fares, live train info, accessibility, and general train guidelines.
                Always respond friendly, welcoming and professionally in the requested language (code: $languageCode).
                You support major SA languages: English, Afrikaans, isiZulu, isiXhosa, Sepedi, Sesotho, Setswana, siSwati, Tshivenda, Xitsonga, isiNdebele.
                
                South African Metrorail Fare Guidelines:
                - Single tickets: R12.50 (Short distance) to R24.50 (Long distance)
                - Return tickets: R22.00 to R44.00
                - Weekly Pass: R95.00 (Unlimited 7-day travel on selected route)
                - Monthly Pass: R320.00 (Unlimited 30-day travel on selected route)
                - Discounts: Student (20% off with student card), Senior (50% off for 60+ age), Children under 3 travel free.
                
                Network regions supported: Cape Town, Johannesburg, Pretoria (Tshwane), Durban, Gqeberha (Port Elizabeth), East London, Bloemfontein.
                Be concise, helpful, and formatting with bullet points where appropriate.
            """.trimIndent()

            val request = GenerateContentRequest(
                contents = listOf(
                    Content(parts = listOf(Part(text = userPrompt)))
                ),
                systemInstruction = Content(parts = listOf(Part(text = systemInstructionText)))
            )

            val response = RetrofitClient.geminiService.generateContent(apiKey, request)
            return response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: getLocalSupportFallback(userPrompt, languageCode)
        } catch (e: Exception) {
            Log.e("MetrorailRepository", "Gemini AI assistant error: ${e.message}", e)
            return getLocalSupportFallback(userPrompt, languageCode)
        }
    }

    private fun getLocalSupportFallback(prompt: String, lang: String): String {
        val lower = prompt.lowercase()
        return when (lang) {
            "af" -> { // Afrikaans
                when {
                    lower.contains("kaartjie") || lower.contains("prys") -> "Metrorail-kaartjies wissel van R12,50 vir 'n enkele reis tot R320,00 vir 'n maandelikse pas. Studente kry 20% afslag en pensioenarisse kry 50% afslag."
                    lower.contains("plan") || lower.contains("reis") || lower.contains("stasie") -> "Jy kan jou reis beplan deur ons Reisskeduleerder te gebruik. Kies jou vertrekstasie en bestemming om intydse roetes en tariewe te sien."
                    lower.contains("vertraging") || lower.contains("diens") -> "Huidige status: Die Suidelike lyn in Kaapstad ondervind tans 'n 10-minute vertraging weens seinprobleme. Ander streke is skoon."
                    else -> "Dankie dat u Metrorail Suid-Afrika gekontak het. Ek is u plaaslike reisassistent. Hoe kan ek u vandag help met u reis, kaartjies of skedules?"
                }
            }
            "zu" -> { // isiZulu
                when {
                    lower.contains("ithikithi") || lower.contains("imali") -> "Amathikithi eMetrorail aqala ku-R12.50 ohambweni olulodwa kuye ku-R320.00 wephasi lanyanga zonke. Abafundi bathola isisombululo sika-20% kanti abadala bathola u-50%."
                    lower.contains("isikhathi") || lower.contains("izitimela") -> "Ungahlela uhambo lwakho usebenzisa isihleli sethu nohlelo lwezikhathi. Khetha isiteshi osuka kuso nesiteshi oya kuso."
                    else -> "Siyakwamukela ku-Metrorail South Africa. Ngingumsizi wakho wokuhamba. Ngingakusiza ngani namuhla mayelana namathikithi, iziteshi noma izikhathi zezitimela?"
                }
            }
            "xh" -> { // isiXhosa
                when {
                    lower.contains("itikiti") || lower.contains("ixabiso") -> "Amatikiti eMetrorail aqala kwi-R12.50 yohambo olunye ukuya kwi-R320.00 yepasi yanyanga zonke. Abafundi bafumana isaphulelo se-20% kwaye abalupheleyo bafumana ama-50%."
                    else -> "Wamkelekile kwiMetrorail South Africa. Ndingumncedisi wakho wokuhamba. Ndingakunceda ngantoni namhlanje malunga namatikiti okanye izikhathi zololiwe?"
                }
            }
            else -> { // Default English
                when {
                    lower.contains("ticket") || lower.contains("fare") || lower.contains("price") || lower.contains("cost") -> {
                        "Metrorail South Africa offers affordable, distance-based travel:\n" +
                                "• **Single Ticket**: R12.50 - R24.50\n" +
                                "• **Return Ticket**: R22.00 - R44.00\n" +
                                "• **Weekly Pass**: R95.00 (Unlimited 7-day travel)\n" +
                                "• **Monthly Pass**: R320.00 (Unlimited 30-day travel)\n\n" +
                                "• *Discounts*: Students receive **20% off**, and Seniors (60+) receive **50% off** on presentation of valid ID."
                    }
                    lower.contains("plan") || lower.contains("route") || lower.contains("direction") || lower.contains("station") -> {
                        "To plan your journey, navigate to the **Journey Planner** tab. You can search for stations, view route options, estimated travel times, platform numbers, and step-free accessibility details."
                    }
                    lower.contains("delay") || lower.contains("disruption") || lower.contains("alert") || lower.contains("late") -> {
                        "Line status summary:\n" +
                                "• **Cape Town (Southern Line)**: Delayed by 10 mins due to signal upgrade at Salt River.\n" +
                                "• **Gauteng (Pretoria Line)**: Normal operations.\n" +
                                "• **Durban (North Coast Line)**: Undergoing planned maintenance, expect minor delays."
                    }
                    lower.contains("emergency") || lower.contains("police") || lower.contains("help") || lower.contains("safe") -> {
                        "For any emergency on board or at stations, please call our 24/7 Security Operations Center at **0800 21 22 23** or contact our local station security directly. Your safety is our absolute priority."
                    }
                    else -> {
                        "Welcome to Metrorail South Africa! 🇿🇦 I'm your AI Travel Assistant.\n" +
                                "I can help you:\n" +
                                "• Plan journeys across our 7 metropolitan regions\n" +
                                "• Explain fare prices and discount passes\n" +
                                "• Provide real-time line updates and alerts\n" +
                                "• Answer safety, accessibility, and refund policies\n\n" +
                                "How can I assist you today?"
                    }
                }
            }
        }
    }

    private suspend fun seedStationsIfNeeded() {
        if (stationDao.getStationCount() > 0) return

        val seededStations = listOf(
            // Cape Town
            StationEntity("CT-001", "Cape Town Station", "Cape Town", -33.9216, 18.4278, true, true, true, true, "Enhanced"),
            StationEntity("CT-002", "Woodstock", "Cape Town", -33.9261, 18.4452, true, false, true, true, "Standard"),
            StationEntity("CT-003", "Salt River", "Cape Town", -33.9312, 18.4619, true, true, true, true, "Enhanced"),
            StationEntity("CT-004", "Observatory", "Cape Town", -33.9392, 18.4715, false, false, false, true, "Standard"),
            StationEntity("CT-005", "Rondebosch", "Cape Town", -33.9631, 18.4735, true, false, true, true, "Standard"),
            StationEntity("CT-006", "Claremont", "Cape Town", -33.9803, 18.4651, true, true, true, true, "Enhanced"),
            StationEntity("CT-007", "Wynberg", "Cape Town", -34.0016, 18.4682, true, true, true, true, "Enhanced"),
            StationEntity("CT-008", "Muizenberg", "Cape Town", -34.1082, 18.4684, true, false, true, true, "Standard"),
            StationEntity("CT-009", "Kalk Bay", "Cape Town", -34.1287, 18.4497, false, false, false, true, "Standard"),
            StationEntity("CT-010", "Simon's Town", "Cape Town", -34.1856, 18.4239, true, false, true, true, "Standard"),
            StationEntity("CT-011", "Bellville", "Cape Town", -33.9022, 18.6302, true, true, true, true, "Enhanced"),
            StationEntity("CT-012", "Kraaifontein", "Cape Town", -33.8471, 18.7118, true, false, true, true, "Standard"),
            StationEntity("CT-013", "Mitchells Plain", "Cape Town", -34.0487, 18.6253, true, true, true, true, "Enhanced"),
            StationEntity("CT-014", "Khayelitsha", "Cape Town", -34.0351, 18.6756, true, true, true, true, "Enhanced"),
            StationEntity("CT-015", "Langa", "Cape Town", -33.9442, 18.5283, true, true, true, true, "Enhanced"),

            // Johannesburg
            StationEntity("JH-001", "Park Station", "Johannesburg", -26.1956, 28.0431, true, true, true, true, "Enhanced"),
            StationEntity("JH-002", "Braamfontein", "Johannesburg", -26.1944, 28.0289, true, false, true, true, "Standard"),
            StationEntity("JH-003", "Doornfontein", "Johannesburg", -26.1972, 28.0583, true, true, true, true, "Standard"),
            StationEntity("JH-004", "Jeppe", "Johannesburg", -26.2031, 28.0753, false, false, false, true, "Standard"),
            StationEntity("JH-005", "Germiston", "Johannesburg", -26.2197, 28.1692, true, true, true, true, "Enhanced"),
            StationEntity("JH-006", "Orlando", "Johannesburg", -26.2301, 27.9152, true, false, true, true, "Standard"),
            StationEntity("JH-007", "Naledi", "Johannesburg", -26.2628, 27.8183, true, true, true, true, "Standard"),
            StationEntity("JH-008", "Springs", "Johannesburg", -26.2503, 28.4352, true, false, true, true, "Standard"),
            StationEntity("JH-009", "Krugersdorp", "Johannesburg", -26.0964, 27.7716, true, true, true, true, "Enhanced"),

            // Pretoria
            StationEntity("PT-001", "Pretoria Station", "Pretoria", -25.7589, 28.1883, true, true, true, true, "Enhanced"),
            StationEntity("PT-002", "Rissik", "Pretoria", -25.7531, 28.2045, false, false, false, true, "Standard"),
            StationEntity("PT-003", "Walker Street", "Pretoria", -25.7562, 28.2136, true, false, true, true, "Standard"),
            StationEntity("PT-004", "Loftus Versfeld", "Pretoria", -25.7516, 28.2231, true, true, true, true, "Enhanced"),
            StationEntity("PT-005", "Hatfield", "Pretoria", -25.7478, 28.2378, true, true, true, true, "Enhanced"),
            StationEntity("PT-006", "Centurion", "Pretoria", -25.8522, 28.1906, true, true, true, true, "Enhanced"),

            // Durban
            StationEntity("DB-001", "Durban Station", "Durban", -29.8512, 31.0267, true, true, true, true, "Enhanced"),
            StationEntity("DB-002", "Berea Road", "Durban", -29.8587, 31.0116, true, true, true, true, "Enhanced"),
            StationEntity("DB-003", "Congella", "Durban", -29.8735, 30.9991, false, false, false, true, "Standard"),
            StationEntity("DB-004", "Rossburgh", "Durban", -29.8972, 30.9752, true, false, true, true, "Standard"),
            StationEntity("DB-005", "KwaMashu", "Durban", -29.7544, 30.9822, true, true, true, true, "Enhanced"),

            // Gqeberha
            StationEntity("GQ-001", "Port Elizabeth Station", "Gqeberha", -33.9602, 25.6264, true, true, true, true, "Enhanced"),
            StationEntity("GQ-002", "Sydenham", "Gqeberha", -33.9381, 25.6133, false, false, false, true, "Standard"),
            StationEntity("GQ-003", "Swartkops", "Gqeberha", -33.8647, 25.6102, true, false, true, true, "Standard"),
            StationEntity("GQ-004", "Uitenhage", "Gqeberha", -33.7667, 25.4002, true, true, true, true, "Enhanced"),

            // East London
            StationEntity("EL-001", "East London Station", "East London", -33.0163, 27.9076, true, true, true, true, "Enhanced"),
            StationEntity("EL-002", "Chiselhurst", "East London", -33.0012, 27.8812, false, false, false, true, "Standard"),
            StationEntity("EL-003", "Berlin", "East London", -32.8833, 27.6167, true, false, true, true, "Standard"),

            // Bloemfontein
            StationEntity("BF-001", "Bloemfontein Station", "Bloemfontein", -29.1231, 26.2289, true, true, true, true, "Enhanced"),
            StationEntity("BF-002", "Hamilton", "Bloemfontein", -29.1552, 26.2301, false, false, false, true, "Standard")
        )
        stationDao.insertStations(seededStations)
    }

    private suspend fun seedServiceAlertsIfNeeded() {
        if (serviceAlertDao.getAllAlerts().first().isNotEmpty()) return

        val seededAlerts = listOf(
            ServiceAlertEntity(
                id = "AL-001",
                title = "Southern Line: Signal Delays",
                description = "Signal maintenance at Salt River is causing minor 10-15 minute delays on all Southern Line services inbound to Cape Town. Tech crews are working to resolve this.",
                region = "Cape Town",
                lineName = "Southern Line",
                severity = "Warning",
                timestamp = System.currentTimeMillis() - 2 * 60 * 60 * 1000,
                isResolved = false
            ),
            ServiceAlertEntity(
                id = "AL-002",
                title = "Central Line: Suspended Operations",
                description = "Services between Langa and Mitchells Plain are temporarily suspended due to overhead cable theft. Bus replacements are active between stations. Security patrols deployed.",
                region = "Cape Town",
                lineName = "Central Line",
                severity = "Critical",
                timestamp = System.currentTimeMillis() - 4 * 60 * 60 * 1000,
                isResolved = false
            ),
            ServiceAlertEntity(
                id = "AL-003",
                title = "Soweto Line: Normal Service Resumed",
                description = "The technical issue at Orlando has been resolved. Train services on the Johannesburg-Naledi route are now running according to timetable schedules.",
                region = "Johannesburg",
                lineName = "Soweto Line",
                severity = "Info",
                timestamp = System.currentTimeMillis() - 6 * 60 * 60 * 1000,
                isResolved = true
            ),
            ServiceAlertEntity(
                id = "AL-004",
                title = "Pretoria-Hatfield Line: Platform Adjustments",
                description = "Trains arriving at Hatfield will use Platform 3 instead of Platform 1 due to line maintenance. Please listen for station audio announcements.",
                region = "Pretoria",
                lineName = "Pretoria-Hatfield Line",
                severity = "Info",
                timestamp = System.currentTimeMillis() - 1 * 60 * 60 * 1000,
                isResolved = false
            )
        )
        serviceAlertDao.insertAlerts(seededAlerts)
    }

    suspend fun broadcastServiceAlert(title: String, severity: String, description: String, region: String) = withContext(Dispatchers.IO) {
        val alert = ServiceAlertEntity(
            id = "AL-${System.currentTimeMillis().toString().takeLast(6)}",
            title = title,
            description = description,
            region = region,
            lineName = "All Lines",
            severity = severity,
            timestamp = System.currentTimeMillis(),
            isResolved = false
        )
        serviceAlertDao.insertAlerts(listOf(alert))
    }
}
