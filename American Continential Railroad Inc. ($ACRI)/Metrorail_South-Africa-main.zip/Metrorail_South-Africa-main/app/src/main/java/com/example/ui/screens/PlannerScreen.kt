package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.Directions
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.WheelchairPickup
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StationEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetrorailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    viewModel: MetrorailViewModel,
    modifier: Modifier = Modifier
) {
    val regionStations by viewModel.regionStations.collectAsState()
    val selectedRegion by viewModel.selectedRegion.collectAsState()
    val origin by viewModel.plannerOrigin.collectAsState()
    val destination by viewModel.plannerDestination.collectAsState()
    val isSearching by viewModel.plannerLoading.collectAsState()
    val results by viewModel.plannerResults.collectAsState()

    val selectedTicketType by viewModel.selectedTicketType.collectAsState()
    val selectedPassengerType by viewModel.selectedPassengerType.collectAsState()

    var showOriginMenu by remember { mutableStateOf(false) }
    var showDestinationMenu by remember { mutableStateOf(false) }
    var accessibilityOnly by remember { mutableStateOf(false) }

    // Save Favorite states
    var showFavoriteDialog by remember { mutableStateOf(false) }
    var favoriteLabel by remember { mutableStateOf("") }

    val ticketTypes = listOf("Single", "Return", "Weekly Pass", "Monthly Pass")
    val passengerTypes = listOf("Adult", "Student", "Senior", "Child")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title block
        item {
            Column {
                Text(
                    text = viewModel.translate("journey_planner"),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Plan your public rail travel across $selectedRegion.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }

        // Search Parameters Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Origin station selector
                    Box {
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showOriginMenu = true }
                                .testTag("origin_station_dropdown"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.MyLocation, contentDescription = null, tint = SkyBlue)
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(text = viewModel.translate("origin"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(
                                        text = origin?.name ?: "Select Departure Station",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = if (origin != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                    )
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = showOriginMenu,
                            onDismissRequest = { showOriginMenu = false },
                            modifier = Modifier.fillMaxWidth(0.85f).heightIn(max = 280.dp)
                        ) {
                            regionStations.forEach { station ->
                                val matchesAccessibility = !accessibilityOnly || station.hasStepFreeAccess
                                if (matchesAccessibility) {
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(station.name)
                                                if (station.hasStepFreeAccess) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Icon(Icons.Default.WheelchairPickup, contentDescription = "Step-free", modifier = Modifier.size(14.dp), tint = EmeraldGreen)
                                                }
                                            }
                                        },
                                        onClick = {
                                            viewModel.setPlannerOrigin(station)
                                            showOriginMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Destination station selector
                    Box {
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDestinationMenu = true }
                                .testTag("destination_station_dropdown"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Place, contentDescription = null, tint = Color.Red.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(text = viewModel.translate("destination"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(
                                        text = destination?.name ?: "Select Arrival Station",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = if (destination != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                    )
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = showDestinationMenu,
                            onDismissRequest = { showDestinationMenu = false },
                            modifier = Modifier.fillMaxWidth(0.85f).heightIn(max = 280.dp)
                        ) {
                            regionStations.forEach { station ->
                                val matchesAccessibility = !accessibilityOnly || station.hasStepFreeAccess
                                if (matchesAccessibility) {
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(station.name)
                                                if (station.hasStepFreeAccess) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Icon(Icons.Default.WheelchairPickup, contentDescription = "Step-free", modifier = Modifier.size(14.dp), tint = EmeraldGreen)
                                                }
                                            }
                                        },
                                        onClick = {
                                            viewModel.setPlannerDestination(station)
                                            showDestinationMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Accessibility Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Outlined.WheelchairPickup, contentDescription = "Accessibility", tint = EmeraldGreen, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = "Wheelchair & Step-Free Stations Only", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = "Filters only accessibility-ready railway platforms.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            }
                        }
                        Switch(
                            checked = accessibilityOnly,
                            onCheckedChange = {
                                accessibilityOnly = it
                                // Reset if selected doesn't match
                                if (it) {
                                    if (origin?.hasStepFreeAccess == false) viewModel.setPlannerOrigin(null)
                                    if (destination?.hasStepFreeAccess == false) viewModel.setPlannerDestination(null)
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldGreen, checkedTrackColor = EmeraldGreen.copy(alpha = 0.4f))
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // Config Row (Ticket Type & Passenger Type)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = viewModel.translate("passenger_type"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            Spacer(modifier = Modifier.height(4.dp))
                            passengerTypes.forEach { type ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.setPassengerType(type) }
                                ) {
                                    RadioButton(
                                        selected = (selectedPassengerType == type),
                                        onClick = { viewModel.setPassengerType(type) },
                                        colors = RadioButtonDefaults.colors(selectedColor = DeepBlue)
                                    )
                                    Text(text = type, fontSize = 12.sp)
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1.1f)) {
                            Text(text = viewModel.translate("ticket_type"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            Spacer(modifier = Modifier.height(4.dp))
                            ticketTypes.forEach { type ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.setTicketType(type) }
                                ) {
                                    RadioButton(
                                        selected = (selectedTicketType == type),
                                        onClick = { viewModel.setTicketType(type) },
                                        colors = RadioButtonDefaults.colors(selectedColor = DeepBlue)
                                    )
                                    Text(text = type, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Action Search Button
                    Button(
                        onClick = { viewModel.findJourney() },
                        enabled = origin != null && destination != null && origin?.id != destination?.id,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("planner_search_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepBlue, contentColor = OffWhite)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = viewModel.translate("search_routes"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Search Results Loading State
        if (isSearching) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = DeepBlue)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Finding optimal routes...", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                    }
                }
            }
        }

        // Journey Options List
        if (!isSearching && results.isNotEmpty() && origin != null && destination != null) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Suggested Connections",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    // Bookmark Route option
                    TextButton(
                        onClick = { showFavoriteDialog = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = TransitGold)
                    ) {
                        Icon(Icons.Outlined.BookmarkAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save Route", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            items(results) { option ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Title row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(DeepBlue.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = option.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = DeepBlue
                                    )
                                }
                                if (option.accessibilityFriendly) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(Icons.Default.WheelchairPickup, contentDescription = "Step-free", tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                                }
                            }

                            Text(
                                text = "R ${String.format("%.2f", option.fare)}",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = EmeraldGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Duration, Platform details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Column {
                                Text("Travel Time", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                                Text("${option.durationMins} mins", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Column {
                                Text("Platform", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                                Text(option.platform, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Column {
                                Text("Arrival", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                                Text(option.estimatedArrival, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Directions steps
                        Text("Directions", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        option.steps.forEachIndexed { idx, step ->
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(top = 4.dp)
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(DeepBlue)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = step, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Purchase Shortcut
                        Button(
                            onClick = {
                                viewModel.purchaseSelectedTicket(origin!!, destination!!) {
                                    viewModel.setScreen("MyTickets")
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = OffWhite),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Purchase QR Ticket — R ${String.format("%.2f", option.fare)}")
                        }
                    }
                }
            }
        }
    }

    // Save Favorite dialog
    if (showFavoriteDialog && origin != null && destination != null) {
        AlertDialog(
            onDismissRequest = { showFavoriteDialog = false },
            title = { Text("Save to Favorites", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Add a friendly label for this regular commute route:")
                    OutlinedTextField(
                        value = favoriteLabel,
                        onValueChange = { favoriteLabel = it },
                        placeholder = { Text("e.g. Work, School, Home") },
                        modifier = Modifier.fillMaxWidth().testTag("fav_route_label_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val label = favoriteLabel.ifBlank { "My Commute" }
                        viewModel.addFavorite(label, origin!!, destination!!)
                        showFavoriteDialog = false
                        favoriteLabel = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepBlue)
                ) {
                    Text("Save Route")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFavoriteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
