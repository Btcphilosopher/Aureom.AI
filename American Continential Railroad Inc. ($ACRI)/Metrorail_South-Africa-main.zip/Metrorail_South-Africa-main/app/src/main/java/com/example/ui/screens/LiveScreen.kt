package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StationEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetrorailViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScreen(
    viewModel: MetrorailViewModel,
    modifier: Modifier = Modifier
) {
    val selectedRegion by viewModel.selectedRegion.collectAsState()
    val departures by viewModel.liveDepartures.collectAsState()
    val regionStations by viewModel.regionStations.collectAsState()
    val activeAlerts by viewModel.regionAlerts.collectAsState()

    var showMapSubTab by remember { mutableStateOf(false) } // false = board, true = interactive map
    var selectedMapStation by remember { mutableStateOf<StationEntity?>(null) }

    // Simulation variables for moving trains on map
    var trainProgress by remember { mutableStateOf(0f) }
    LaunchedEffect(key1 = showMapSubTab) {
        while (true) {
            delay(50)
            trainProgress = (trainProgress + 0.003f) % 1f
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Toggle view
        TabRow(
            selectedTabIndex = if (!showMapSubTab) 0 else 1,
            containerColor = DeepBlue,
            contentColor = OffWhite,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[if (!showMapSubTab) 0 else 1]),
                    color = TransitGold
                )
            }
        ) {
            Tab(
                selected = !showMapSubTab,
                onClick = { showMapSubTab = false },
                text = { Text("Live Departure Board", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("tab_live_board")
            )
            Tab(
                selected = showMapSubTab,
                onClick = { showMapSubTab = true },
                text = { Text("Network Interactive Map", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("tab_interactive_map")
            )
        }

        if (!showMapSubTab) {
            // Live departure board
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "$selectedRegion Line Telemetry",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(EmeraldGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Live telemetry active (WebSocket updates)",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                )
                            }
                        }

                        IconButton(
                            onClick = { /* trigger refresh animation / load */ },
                            modifier = Modifier.testTag("btn_refresh_live_board")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = DeepBlue)
                        }
                    }
                }

                // Service alert notices specifically for this view
                if (activeAlerts.isNotEmpty()) {
                    items(activeAlerts) { alert ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (alert.severity == "Critical") Color(0xFFFFEBEE) else Color(0xFFFFFDE7)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Error,
                                    contentDescription = "Alert",
                                    tint = if (alert.severity == "Critical") Color.Red else Color(0xFFF57F17),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = alert.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CharcoalGrey)
                                    Text(text = alert.description, fontSize = 11.sp, color = CharcoalGrey.copy(alpha = 0.8f))
                                }
                            }
                        }
                    }
                }

                if (departures.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp), contentAlignment = Alignment.Center) {
                            Text("No live departures currently registered in this region.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                        }
                    }
                } else {
                    items(departures) { train ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1.5f)
                                ) {
                                    Icon(Icons.Default.Train, contentDescription = null, tint = DeepBlue, modifier = Modifier.size(28.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(
                                            text = train.destination,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = train.lineName,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = train.trainNumber,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TransitGold,
                                                modifier = Modifier
                                                    .background(CharcoalGrey, RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }

                                // Platform, Minutes and Status column
                                Row(
                                    modifier = Modifier.weight(1f),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Plat ${train.platform}",
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        val statusColor = when {
                                            train.status.contains("On Time") -> EmeraldGreen
                                            train.status.contains("Delayed") -> Color(0xFFF57F17)
                                            else -> Color.Red
                                        }
                                        Text(
                                            text = train.status,
                                            color = statusColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(16.dp))

                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(DeepBlue)
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "${train.minutesRemaining}",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 16.sp,
                                            color = OffWhite
                                        )
                                        Text(
                                            text = "MIN",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 8.sp,
                                            color = OffWhite.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Interactive Map drawing canvas
            Box(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Quick Map Guide
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LegendItem("Line A (Metro Express)", Color(0xFF0F2C59))
                            LegendItem("Line B (Southern Line)", Color(0xFFE5A93B))
                            LegendItem("Live Train", Color.Red)
                        }
                    }

                    // Vector Canvas plotting
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(CharcoalGrey)
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(key1 = regionStations) {
                                    detectTapGestures { offset ->
                                        // Detect if user clicked near any station coordinate node (scaled coordinates)
                                        val width = size.width
                                        val height = size.height
                                        val hubX = width / 2f
                                        val hubY = height / 2f

                                        // We map the list of stations into dynamic coordinates
                                        val stationsList = regionStations
                                        var foundStation: StationEntity? = null
                                        stationsList.forEachIndexed { idx, s ->
                                            val angle = (idx * (2 * Math.PI) / stationsList.size)
                                            val radius = (Math.min(width, height) / 2.8f)
                                            val x = hubX + (radius * Math.cos(angle)).toFloat()
                                            val y = hubY + (radius * Math.sin(angle)).toFloat()

                                            val distanceSquared = (offset.x - x) * (offset.x - x) + (offset.y - y) * (offset.y - y)
                                            if (distanceSquared < 500f) { // roughly within 22dp click zone
                                                foundStation = s
                                            }
                                        }
                                        if (foundStation != null) {
                                            selectedMapStation = foundStation
                                        } else {
                                            selectedMapStation = null
                                        }
                                    }
                                }
                        ) {
                            val width = size.width
                            val height = size.height

                            val hubX = width / 2f
                            val hubY = height / 2f

                            val radius = Math.min(width, height) / 2.8f

                            // Draw central connection hubs lines (Rail corridors)
                            // Line A (Deep blue line across nodes)
                            drawCircle(
                                color = Color(0xFF0F2C59).copy(alpha = 0.25f),
                                radius = radius,
                                center = Offset(hubX, hubY),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 8f)
                            )

                            // Cross line (Transit gold express link)
                            drawLine(
                                color = Color(0xFFE5A93B).copy(alpha = 0.6f),
                                start = Offset(hubX - radius, hubY - radius),
                                end = Offset(hubX + radius, hubY + radius),
                                strokeWidth = 6f
                            )

                            // Draw station nodes & text Labels
                            val stationsList = regionStations
                            stationsList.forEachIndexed { idx, s ->
                                val angle = (idx * (2 * Math.PI) / stationsList.size)
                                val x = hubX + (radius * Math.cos(angle)).toFloat()
                                val y = hubY + (radius * Math.sin(angle)).toFloat()

                                // Station dot
                                val isSelected = selectedMapStation?.id == s.id
                                drawCircle(
                                    color = if (isSelected) Color.White else if (s.hasStepFreeAccess) Color(0xFF2E7D32) else Color(0xFF2D82B7),
                                    radius = if (isSelected) 10f else 7f,
                                    center = Offset(x, y)
                                )

                                // Accent surrounding rings
                                if (isSelected) {
                                    drawCircle(
                                        color = Color.White.copy(alpha = 0.3f),
                                        radius = 20f,
                                        center = Offset(x, y),
                                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
                                    )
                                }
                            }

                            // Plot dynamic moving train on Line A (Blue line circular path)
                            if (stationsList.isNotEmpty()) {
                                val trainAngle = trainProgress * 2 * Math.PI
                                val trainX = hubX + (radius * Math.cos(trainAngle)).toFloat()
                                val trainY = hubY + (radius * Math.sin(trainAngle)).toFloat()

                                // Blinking Red Train Dot
                                drawCircle(
                                    color = Color.Red,
                                    radius = 8f,
                                    center = Offset(trainX, trainY)
                                )
                                drawCircle(
                                    color = Color.Red.copy(alpha = 0.4f),
                                    radius = 16f + (trainProgress % 0.1f) * 120f,
                                    center = Offset(trainX, trainY),
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
                                )
                            }
                        }

                        // Help tip overlay
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(8.dp)
                        ) {
                            Text("Tap station dots to inspect", color = Color.White, fontSize = 10.sp)
                        }
                    }
                }

                // Station info modal drawer
                androidx.compose.animation.AnimatedVisibility(
                    visible = selectedMapStation != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    selectedMapStation?.let { s ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(14.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = s.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text(text = "Metrorail ${s.region} Network Node", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    }
                                    IconButton(onClick = { selectedMapStation = null }) {
                                        Icon(Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    AccessibilityBadge("Step-free Platforms", s.hasStepFreeAccess)
                                    AccessibilityBadge("Elevators / Lifts", s.hasLifts)
                                    AccessibilityBadge("Wheelchair friendly", s.hasWheelchairAccess)
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (s.ticketOfficeOpen) "Ticket Office: OPEN" else "Ticket Office: CLOSED",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (s.ticketOfficeOpen) EmeraldGreen else Color.Red
                                    )

                                    // Quick launch Planner
                                    Button(
                                        onClick = {
                                            viewModel.setPlannerOrigin(s)
                                            viewModel.setScreen("Planner")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepBlue, contentColor = OffWhite),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Set as Origin", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = CharcoalGrey)
    }
}

@Composable
fun AccessibilityBadge(label: String, available: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (available) EmeraldGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.background)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(
                imageVector = if (available) Icons.Default.CheckCircle else Icons.Default.Cancel,
                contentDescription = null,
                tint = if (available) EmeraldGreen else Color.Red.copy(alpha = 0.6f),
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (available) EmeraldGreen else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        }
    }
}
