package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepBlue = Color(0xFF003366)
val TransitGold = Color(0xFFFFD700)
val EmeraldGreen = Color(0xFF10B981) // Matching emerald-500 from design
val CharcoalGrey = Color(0xFF1B1B1F)
val SkyBlue = Color(0xFFF2F2F7)
val LightGrey = Color(0xFFFBFBFF)
val OffWhite = Color(0xFFFFFFFF)

// Dark Theme specific colors
val DarkPrimary = Color(0xFF4A90E2)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val OnDarkPrimary = Color(0xFFFFFFFF)
val OnDarkBackground = Color(0xFFE0E0E0)
val OnDarkSurface = Color(0xFFF5F5F5)

