package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetrorailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportScreen(
    viewModel: MetrorailViewModel,
    modifier: Modifier = Modifier
) {
    var showLostForm by remember { mutableStateOf(false) }

    // Lost property form values
    var itemName by remember { mutableStateOf("") }
    var itemDate by remember { mutableStateOf("") }
    var itemLine by remember { mutableStateOf("") }
    var itemDesc by remember { mutableStateOf("") }
    var lostSuccessMsg by remember { mutableStateOf(false) }

    // Feedback values
    var feedbackType by remember { mutableStateOf("Service Improvement") }
    var feedbackText by remember { mutableStateOf("") }
    var feedbackSuccess by remember { mutableStateOf(false) }

    // FAQ state (map of expanded states)
    val expandedFaqs = remember { mutableStateMapOf<Int, Boolean>() }

    val faqs = listOf(
        FaqItem(
            "How do I use my digital QR ticket at the station gates?",
            "Open your 'My Tickets' tab, select your active ticket to display the custom secure QR code. Hold the QR code strictly under the scanner window at any enabled Metrorail RFID/QR turnstile. The scanner will read and validate your ticket instantly, even if you are entirely offline."
        ),
        FaqItem(
            "What happens if my train is significantly delayed?",
            "In accordance with Metrorail South Africa commuter charter policies, you are entitled to request alternative transport mapping (such as bus links) or file a full refund claim within 24 hours if delays exceed 45 minutes."
        ),
        FaqItem(
            "Who qualifies for concessions and discounted travel passes?",
            "Registered scholars and tertiary students are eligible for a 20% discount on all weekly and monthly passes (require student identity card). Senior citizens aged 60 and above qualify for a 50% discount on all single/return fares."
        ),
        FaqItem(
            "Is it safe to travel on Metrorail lines late at night?",
            "Metrorail is deploying security marshals and enhanced CCTV monitoring at all major stations. We strictly advise passengers to stay in populated carriages, avoid isolated platforms after hours, and contact our 24/7 Security Operations Center at 0800 21 22 23 in any urgent situation."
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title block
        item {
            Column {
                Text(
                    text = "Customer Support & Safety",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Lodge property claims, view guidelines, and access rapid safety systems.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }

        // 1. EMERGENCY CONTACTS CARD (HIGH-WEIGHT RED CARD)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFC62828)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HealthAndSafety, contentDescription = "Safety", tint = OffWhite, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("24/7 Safety & Security Dialers", fontWeight = FontWeight.Bold, color = OffWhite, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "If you witness a crime, feel threatened, or observe a medical crisis, tap to dial our rapid response operators immediately.",
                        fontSize = 12.sp,
                        color = OffWhite.copy(alpha = 0.9f)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        EmergencyDialButton("Security: 0800 21 22 23", modifier = Modifier.weight(1f)) {}
                        EmergencyDialButton("Police: 10111", modifier = Modifier.weight(1f)) {}
                    }
                }
            }
        }

        // 2. FAQ ACCORDION SECTION
        item {
            Text("Frequently Asked Questions", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        }

        items(faqs.size) { idx ->
            val faq = faqs[idx]
            val isExpanded = expandedFaqs[idx] ?: false

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedFaqs[idx] = !isExpanded },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = faq.question,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }

                    AnimatedVisibility(visible = isExpanded) {
                        Column {
                            Spacer(modifier = Modifier.height(10.dp))
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = faq.answer,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }

        // 3. LOST PROPERTY LODGEMENT ACCORDION
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showLostForm = !showLostForm },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = SkyBlue)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Lodge Lost Property Claim", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Icon(
                            imageVector = if (showLostForm) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null
                        )
                    }

                    AnimatedVisibility(visible = showLostForm) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Enter details about the missing item. Our depot cataloging system will run cross-referencing scans.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))

                            OutlinedTextField(
                                value = itemName,
                                onValueChange = { itemName = it },
                                label = { Text("What item did you lose?") },
                                placeholder = { Text("e.g. Leather Wallet, Laptop Bag, Umbrella") },
                                modifier = Modifier.fillMaxWidth().testTag("lost_item_name_input")
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = itemDate,
                                    onValueChange = { itemDate = it },
                                    label = { Text("Date Lost") },
                                    placeholder = { Text("DD/MM/YYYY") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = itemLine,
                                    onValueChange = { itemLine = it },
                                    label = { Text("Rail Line / Station") },
                                    placeholder = { Text("e.g. Southern Line") },
                                    modifier = Modifier.weight(1.1f)
                                )
                            }

                            OutlinedTextField(
                                value = itemDesc,
                                onValueChange = { itemDesc = it },
                                label = { Text("Item Description & Color") },
                                placeholder = { Text("Identify markings, colors, unique features...") },
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 3
                            )

                            Button(
                                onClick = {
                                    if (itemName.isNotBlank()) {
                                        lostSuccessMsg = true
                                        itemName = ""
                                        itemDate = ""
                                        itemLine = ""
                                        itemDesc = ""
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().testTag("lost_property_submit_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = DeepBlue, contentColor = OffWhite)
                            ) {
                                Text("Lodge Secure Report")
                            }

                            if (lostSuccessMsg) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = EmeraldGreen.copy(alpha = 0.15f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Report lodged successfully! File reference: MRZA-PROP-${System.currentTimeMillis().toString().takeLast(6)}. We will notify you immediately if a depot match is found.",
                                        color = EmeraldGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. CUSTOMER FEEDBACK PORTAL
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Feedback, contentDescription = null, tint = TransitGold)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Commuter Feedback Portal", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Text("We value your input. Share compliments, station cleanliness feedback, or layout requests with management.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Service", "Cleanliness", "Safety").forEach { fType ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (feedbackType == fType) DeepBlue else MaterialTheme.colorScheme.background)
                                    .clickable { feedbackType = fType }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = fType,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (feedbackType == fType) OffWhite else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        placeholder = { Text("Write your feedback details here...") },
                        modifier = Modifier.fillMaxWidth().testTag("feedback_text_input"),
                        maxLines = 4
                    )

                    Button(
                        onClick = {
                            if (feedbackText.isNotBlank()) {
                                feedbackSuccess = true
                                feedbackText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("feedback_submit_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepBlue, contentColor = OffWhite)
                    ) {
                        Text("Submit Feedback")
                    }

                    if (feedbackSuccess) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = EmeraldGreen.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Thank you! Your feedback has been registered. Review reference: MRZA-FEED-${System.currentTimeMillis().toString().takeLast(6)}. It has been forwarded directly to the regional Metrorail operations hub.",
                                color = EmeraldGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmergencyDialButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFFC62828)),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.height(40.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Black)
        }
    }
}

data class FaqItem(val question: String, val answer: String)
