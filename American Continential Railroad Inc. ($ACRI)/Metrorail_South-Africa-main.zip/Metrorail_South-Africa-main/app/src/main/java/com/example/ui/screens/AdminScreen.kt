package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetrorailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    viewModel: MetrorailViewModel,
    modifier: Modifier = Modifier
) {
    val selectedRegion by viewModel.selectedRegion.collectAsState()
    val regionAlerts by viewModel.regionAlerts.collectAsState()

    var showAnalyticsTab by remember { mutableStateOf(false) }

    // Broadcast form states
    var alertTitle by remember { mutableStateOf("") }
    var alertSeverity by remember { mutableStateOf("Warning") }
    var alertDesc by remember { mutableStateOf("") }
    var showFormSuccess by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title block
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Enterprise Command Center", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Text(text = "Regional Monitoring • South Africa Rail", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Red.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text = "SECURE ADMIN", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
            }
        }

        // Sub tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { showAnalyticsTab = false },
                    colors = ButtonDefaults.buttonColors(containerColor = if (!showAnalyticsTab) DeepBlue else MaterialTheme.colorScheme.surface, contentColor = if (!showAnalyticsTab) OffWhite else MaterialTheme.colorScheme.onSurface),
                    modifier = Modifier.weight(1f).testTag("admin_tab_operations")
                ) {
                    Icon(Icons.Default.Dashboard, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Operations")
                }

                Button(
                    onClick = { showAnalyticsTab = true },
                    colors = ButtonDefaults.buttonColors(containerColor = if (showAnalyticsTab) DeepBlue else MaterialTheme.colorScheme.surface, contentColor = if (showAnalyticsTab) OffWhite else MaterialTheme.colorScheme.onSurface),
                    modifier = Modifier.weight(1f).testTag("admin_tab_analytics")
                ) {
                    Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Analytics")
                }
            }
        }

        if (!showAnalyticsTab) {
            // Operations Overview
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AdminStatCard("Active Commuters", "42,890", "+12%", EmeraldGreen, modifier = Modifier.weight(1f))
                    AdminStatCard("Active Rail Lines", "18/20", "Normal", SkyBlue, modifier = Modifier.weight(1f))
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AdminStatCard("Daily Sales", "R 241,850", "+5.4%", TransitGold, modifier = Modifier.weight(1f))
                    AdminStatCard("Uptime Rating", "99.98%", "Excellent", EmeraldGreen, modifier = Modifier.weight(1f))
                }
            }

            // Broadcast alert console
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Campaign, contentDescription = null, tint = Color.Red, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Broadcast Service Disruption Alert", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Text("Broadcast safety notifications or line delays. This is seeded immediately to all consumer devices in $selectedRegion.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))

                        OutlinedTextField(
                            value = alertTitle,
                            onValueChange = { alertTitle = it },
                            label = { Text("Alert Title") },
                            placeholder = { Text("e.g. Southern Line 15 min delays") },
                            modifier = Modifier.fillMaxWidth().testTag("admin_alert_title_input")
                        )

                        // Severity row
                        Text("Select Severity Profile:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Info", "Warning", "Critical").forEach { level ->
                                val active = alertSeverity == level
                                val bColor = when (level) {
                                    "Critical" -> Color.Red
                                    "Warning" -> TransitGold
                                    else -> SkyBlue
                                }
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (active) bColor else MaterialTheme.colorScheme.background)
                                        .clickable { alertSeverity = level }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = level, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (active) Color.White else MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = alertDesc,
                            onValueChange = { alertDesc = it },
                            label = { Text("Broadcasting Message Details") },
                            placeholder = { Text("Add detail instruction or shuttle replacement guidance...") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )

                        Button(
                            onClick = {
                                if (alertTitle.isNotBlank()) {
                                    viewModel.broadcastAlert(alertTitle, alertSeverity, alertDesc)
                                    showFormSuccess = true
                                    alertTitle = ""
                                    alertDesc = ""
                                }
                            },
                            enabled = alertTitle.isNotBlank(),
                            modifier = Modifier.fillMaxWidth().testTag("admin_broadcast_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red, contentColor = OffWhite)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Publish Disruption Broadcast")
                        }

                        if (showFormSuccess) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = EmeraldGreen.copy(alpha = 0.15f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Alert published and propagated successfully!", color = EmeraldGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Analytics Dashboard (Canvas charts)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Weekly Ridership Volume", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Active daily passenger throughput (thousands)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(16.dp))

                        // Custom Drawn Bar Chart on Canvas
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                        ) {
                            val values = listOf(42f, 55f, 63f, 48f, 52f, 70f, 34f)
                            val barCount = values.size
                            val spaceBetween = 16f
                            val barWidth = (size.width - (barCount - 1) * spaceBetween) / barCount
                            val maxValue = values.maxOrNull() ?: 100f

                            for (i in 0 until barCount) {
                                val value = values[i]
                                val barHeight = (value / maxValue) * size.height
                                val left = i * (barWidth + spaceBetween)
                                val top = size.height - barHeight

                                drawRect(
                                    color = if (i == 5) DeepBlue else SkyBlue,
                                    topLeft = Offset(left, top),
                                    size = Size(barWidth, barHeight)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { day ->
                                Text(text = day, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Monthly Cumulative Revenue Trend", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Secure ticket sales performance (ZAR millions)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(16.dp))

                        // Custom Area Gradient Spline Chart
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                        ) {
                            val values = listOf(1.2f, 1.8f, 2.5f, 2.2f, 3.1f, 3.8f, 4.2f)
                            val steps = values.size
                            val segmentWidth = size.width / (steps - 1)
                            val maxValue = 5.0f

                            val path = Path()
                            val fillPath = Path()

                            values.forEachIndexed { i, value ->
                                val x = i * segmentWidth
                                val y = size.height - (value / maxValue) * size.height

                                if (i == 0) {
                                    path.moveTo(x, y)
                                    fillPath.moveTo(x, size.height)
                                    fillPath.lineTo(x, y)
                                } else {
                                    path.lineTo(x, y)
                                    fillPath.lineTo(x, y)
                                }

                                if (i == steps - 1) {
                                    fillPath.lineTo(x, size.height)
                                    fillPath.close()
                                }
                            }

                            // Draw area gradient fill
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(SkyBlue.copy(alpha = 0.4f), Color.Transparent)
                                )
                            )

                            // Draw outline stroke
                            drawPath(
                                path = path,
                                color = DeepBlue,
                                style = Stroke(width = 6f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    change: String,
    indicatorColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(indicatorColor.copy(alpha = 0.15f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(text = change, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = indicatorColor)
            }
        }
    }
}
