package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.repository.MetrorailRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.DeepBlue
import com.example.ui.theme.TransitGold
import com.example.ui.theme.OffWhite
import com.example.ui.viewmodel.MetrorailViewModel
import com.example.ui.viewmodel.MetrorailViewModelFactory

import com.example.ui.theme.CharcoalGrey

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = MetrorailRepository(applicationContext)
        val viewModelFactory = MetrorailViewModelFactory(repository)

        setContent {
            MyApplicationTheme {
                val metrorailViewModel: MetrorailViewModel = viewModel(factory = viewModelFactory)
                MetrorailApp(metrorailViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetrorailApp(viewModel: MetrorailViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            // Display clean header with Back action on non-home screens
            if (currentScreen != "Home") {
                Column {
                    TopAppBar(
                        title = {
                            val titleKey = when (currentScreen) {
                                "Planner" -> "journey_planner"
                                "BuyTicket" -> "buy_ticket"
                                "MyTickets" -> "my_tickets"
                                "LiveInfo" -> "live_departures"
                                "AIAssistant" -> "ai_assistant"
                                "Support" -> "support"
                                "Admin" -> "admin"
                                else -> "Metrorail"
                            }
                            Text(
                                text = viewModel.translate(titleKey),
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = CharcoalGrey
                            )
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = { viewModel.setScreen("Home") },
                                modifier = Modifier.testTag("nav_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back to Home",
                                    tint = DeepBlue
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.White,
                            titleContentColor = CharcoalGrey
                        )
                    )
                    HorizontalDivider(color = Color(0xFFF2F2F7), thickness = 1.dp)
                }
            }
        },
        bottomBar = {
            // Primary Bottom Nav Bar for fast switching
            val showBottomBar = currentScreen in listOf("Home", "Planner", "MyTickets", "Support")
            if (showBottomBar) {
                Column {
                    HorizontalDivider(color = Color(0xFFF2F2F7), thickness = 1.dp)
                    NavigationBar(
                        containerColor = Color.White,
                        contentColor = CharcoalGrey
                    ) {
                        NavigationBarItem(
                            selected = currentScreen == "Home",
                            onClick = { viewModel.setScreen("Home") },
                            label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            icon = { Icon(if (currentScreen == "Home") Icons.Default.Home else Icons.Outlined.Home, contentDescription = null) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = DeepBlue,
                                indicatorColor = DeepBlue,
                                unselectedIconColor = CharcoalGrey.copy(alpha = 0.4f),
                                unselectedTextColor = CharcoalGrey.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.testTag("nav_item_home")
                        )

                        NavigationBarItem(
                            selected = currentScreen == "Planner",
                            onClick = { viewModel.setScreen("Planner") },
                            label = { Text("Plan", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            icon = { Icon(if (currentScreen == "Planner") Icons.Default.DirectionsRun else Icons.Outlined.DirectionsRun, contentDescription = null) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = DeepBlue,
                                indicatorColor = DeepBlue,
                                unselectedIconColor = CharcoalGrey.copy(alpha = 0.4f),
                                unselectedTextColor = CharcoalGrey.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.testTag("nav_item_planner")
                        )

                        NavigationBarItem(
                            selected = currentScreen == "MyTickets",
                            onClick = { viewModel.setScreen("MyTickets") },
                            label = { Text("Wallet", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            icon = { Icon(if (currentScreen == "MyTickets") Icons.Default.LocalActivity else Icons.Outlined.LocalActivity, contentDescription = null) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = DeepBlue,
                                indicatorColor = DeepBlue,
                                unselectedIconColor = CharcoalGrey.copy(alpha = 0.4f),
                                unselectedTextColor = CharcoalGrey.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.testTag("nav_item_wallet")
                        )

                        NavigationBarItem(
                            selected = currentScreen == "Support",
                            onClick = { viewModel.setScreen("Support") },
                            label = { Text("Support", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            icon = { Icon(if (currentScreen == "Support") Icons.Default.ContactSupport else Icons.Outlined.ContactSupport, contentDescription = null) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = DeepBlue,
                                indicatorColor = DeepBlue,
                                unselectedIconColor = CharcoalGrey.copy(alpha = 0.4f),
                                unselectedTextColor = CharcoalGrey.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.testTag("nav_item_support")
                        )
                    }
                }
            }
        },
        contentWindowInsets = WindowInsets.navigationBars
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                "Home" -> HomeScreen(viewModel = viewModel)
                "Planner" -> PlannerScreen(viewModel = viewModel)
                "BuyTicket" -> TicketingScreen(viewModel = viewModel, subTab = "Purchase")
                "MyTickets" -> TicketingScreen(viewModel = viewModel, subTab = "Wallet")
                "LiveInfo" -> LiveScreen(viewModel = viewModel)
                "AIAssistant" -> AssistantScreen(viewModel = viewModel)
                "Support" -> SupportScreen(viewModel = viewModel)
                "Admin" -> AdminScreen(viewModel = viewModel)
                else -> HomeScreen(viewModel = viewModel)
            }
        }
    }
}
