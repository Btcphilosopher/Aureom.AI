package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.*
import com.example.data.repository.MetrorailRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MetrorailViewModel(private val repository: MetrorailRepository) : ViewModel() {

    // Language state
    private val _currentLanguage = MutableStateFlow("en")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    // Navigation & UI state
    private val _currentScreen = MutableStateFlow("Home") // Home, Planner, BuyTicket, MyTickets, LiveInfo, AIAssistant, Support, Admin
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    // Active Region for commuter
    private val _selectedRegion = MutableStateFlow("Cape Town")
    val selectedRegion: StateFlow<String> = _selectedRegion.asStateFlow()

    // Collected database flows
    val stations: StateFlow<List<StationEntity>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteRoutes: StateFlow<List<FavoriteRouteEntity>> = repository.favoriteRoutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val serviceAlerts: StateFlow<List<ServiceAlertEntity>> = repository.allAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatHistory: StateFlow<List<SupportMessageEntity>> = repository.chatHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Region-filtered stations
    val regionStations: StateFlow<List<StationEntity>> = combine(stations, _selectedRegion) { all, region ->
        all.filter { it.region == region }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Region-filtered active alerts
    val regionAlerts: StateFlow<List<ServiceAlertEntity>> = combine(serviceAlerts, _selectedRegion) { all, region ->
        all.filter { it.region == region && !it.isResolved }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Journey Planner State
    private val _plannerOrigin = MutableStateFlow<StationEntity?>(null)
    val plannerOrigin: StateFlow<StationEntity?> = _plannerOrigin.asStateFlow()

    private val _plannerDestination = MutableStateFlow<StationEntity?>(null)
    val plannerDestination: StateFlow<StationEntity?> = _plannerDestination.asStateFlow()

    private val _plannerResults = MutableStateFlow<List<JourneyOption>>(emptyList())
    val plannerResults: StateFlow<List<JourneyOption>> = _plannerResults.asStateFlow()

    private val _plannerLoading = MutableStateFlow(false)
    val plannerLoading: StateFlow<Boolean> = _plannerLoading.asStateFlow()

    // Digital Ticket Cart State
    private val _selectedTicketType = MutableStateFlow("Single") // Single, Return, Weekly Pass, Monthly Pass
    val selectedTicketType: StateFlow<String> = _selectedTicketType.asStateFlow()

    private val _selectedPassengerType = MutableStateFlow("Adult") // Adult, Student, Senior, Child
    val selectedPassengerType: StateFlow<String> = _selectedPassengerType.asStateFlow()

    // Live Train Positions & Departures (Simulated Real-time Data with fluctuations)
    private val _liveDepartures = MutableStateFlow<List<LiveDeparture>>(emptyList())
    val liveDepartures: StateFlow<List<LiveDeparture>> = _liveDepartures.asStateFlow()

    // Customer Account Stats
    private val _userProfile = MutableStateFlow(UserProfile("Sizwe Khumalo", "sizwe.k@transport.gov.za", "+27 82 123 4567"))
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    // AI Assistant state
    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    // Admin Metrics (Dynamic calculations)
    val adminMetrics: StateFlow<AdminMetrics> = tickets.map { purchasedTickets ->
        val totalSales = purchasedTickets.size
        val totalRevenue = purchasedTickets.sumOf { it.fare }
        val activeRiders = 42500 + purchasedTickets.filter { it.status == "Active" }.size * 324
        val peakPercentage = 78 + (purchasedTickets.size % 10)
        val systemUptime = 99.98
        AdminMetrics(totalSales, totalRevenue, activeRiders, peakPercentage, systemUptime)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AdminMetrics(0, 0.0, 42500, 78, 99.98))

    init {
        // Trigger departures loading when selected region changes
        viewModelScope.launch {
            _selectedRegion.collect {
                generateLiveDepartures()
            }
        }
    }

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
    }

    fun setScreen(screen: String) {
        _currentScreen.value = screen
    }

    fun setRegion(region: String) {
        _selectedRegion.value = region
        // Clear planner inputs when switching region
        _plannerOrigin.value = null
        _plannerDestination.value = null
        _plannerResults.value = emptyList()
    }

    fun setPlannerOrigin(station: StationEntity?) {
        _plannerOrigin.value = station
    }

    fun setPlannerDestination(station: StationEntity?) {
        _plannerDestination.value = station
    }

    fun setTicketType(type: String) {
        _selectedTicketType.value = type
    }

    fun setPassengerType(type: String) {
        _selectedPassengerType.value = type
    }

    fun findJourney() {
        val origin = _plannerOrigin.value ?: return
        val dest = _plannerDestination.value ?: return

        viewModelScope.launch {
            _plannerLoading.value = true
            // Small simulated loading delay
            kotlinx.coroutines.delay(800)

            val baseFare = calculateBaseFare(origin, dest)
            val results = mutableListOf<JourneyOption>()

            // Fast Route Option
            results.add(
                JourneyOption(
                    title = "Direct Express",
                    durationMins = 32,
                    transfers = 0,
                    platform = "Platform 4",
                    fare = baseFare * getPassengerFareMultiplier(_selectedPassengerType.value) * getTicketTypeFareMultiplier(_selectedTicketType.value),
                    estimatedArrival = getFutureTimeString(32),
                    steps = listOf(
                        "Board Express Rail Line towards ${dest.name}.",
                        "Travel 6 stations directly.",
                        "Arrive at destination."
                    ),
                    accessibilityFriendly = origin.hasStepFreeAccess && dest.hasStepFreeAccess
                )
            )

            // Scenic/Local Route Option
            results.add(
                JourneyOption(
                    title = "Metro Local Line",
                    durationMins = 45,
                    transfers = 1,
                    platform = "Platform 1",
                    fare = (baseFare * 0.9) * getPassengerFareMultiplier(_selectedPassengerType.value) * getTicketTypeFareMultiplier(_selectedTicketType.value),
                    estimatedArrival = getFutureTimeString(45),
                    steps = listOf(
                        "Board Metro Local Train towards Salt River (Platform 1).",
                        "Transfer at Salt River station to Platform 3.",
                        "Board Metro Connecting Train to ${dest.name}.",
                        "Arrive at destination."
                    ),
                    accessibilityFriendly = origin.hasStepFreeAccess && dest.hasStepFreeAccess
                )
            )

            _plannerResults.value = results
            _plannerLoading.value = false
        }
    }

    fun purchaseSelectedTicket(origin: StationEntity, dest: StationEntity, onComplete: () -> Unit) {
        viewModelScope.launch {
            val baseFare = calculateBaseFare(origin, dest)
            val actualFare = baseFare * getPassengerFareMultiplier(_selectedPassengerType.value) * getTicketTypeFareMultiplier(_selectedTicketType.value)
            repository.purchaseTicket(
                origin = origin,
                destination = dest,
                ticketType = _selectedTicketType.value,
                passengerType = _selectedPassengerType.value,
                fare = actualFare
            )
            onComplete()
        }
    }

    fun addFavorite(label: String, origin: StationEntity, dest: StationEntity) {
        viewModelScope.launch {
            repository.addFavoriteRoute(label, origin, dest)
        }
    }

    fun deleteFavorite(fav: FavoriteRouteEntity) {
        viewModelScope.launch {
            repository.deleteFavoriteRoute(fav)
        }
    }

    fun sendSupportMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _isAiLoading.value = true
            repository.sendUserMessage(text, _currentLanguage.value)
            _isAiLoading.value = false
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }

    fun broadcastAlert(title: String, severity: String, description: String) {
        viewModelScope.launch {
            repository.broadcastServiceAlert(title, severity, description, _selectedRegion.value)
        }
    }

    // Helper functions for fare calculation
    private fun calculateBaseFare(s1: StationEntity, s2: StationEntity): Double {
        // Distance-based approximation via latitude/longitude differences
        val latDiff = Math.abs(s1.latitude - s2.latitude)
        val lonDiff = Math.abs(s1.longitude - s2.longitude)
        val distanceFactor = (latDiff + lonDiff) * 100
        return Math.max(12.50, Math.min(24.50, 12.50 + distanceFactor * 1.50))
    }

    private fun getPassengerFareMultiplier(type: String): Double {
        return when (type) {
            "Student" -> 0.8 // 20% discount
            "Senior" -> 0.5 // 50% discount
            "Child" -> 0.5 // 50% discount
            else -> 1.0 // Standard adult
        }
    }

    private fun getTicketTypeFareMultiplier(type: String): Double {
        return when (type) {
            "Return" -> 1.8 // Return trip discount
            "Weekly Pass" -> 5.5 // Weekly pass bulk savings
            "Monthly Pass" -> 18.0 // Monthly pass bulk savings
            else -> 1.0 // Single
        }
    }

    fun getFutureTimeString(offsetMins: Int): String {
        val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val futureTime = Date(System.currentTimeMillis() + offsetMins * 60 * 1000)
        return dateFormat.format(futureTime)
    }

    // Live departures generation for active region
    private fun generateLiveDepartures() {
        val activeStations = regionStations.value.ifEmpty { return }
        val generated = mutableListOf<LiveDeparture>()
        val lines = when (_selectedRegion.value) {
            "Cape Town" -> listOf("Southern Line", "Northern Line", "Central Line", "Cape Flats Line")
            "Johannesburg" -> listOf("Soweto Line", "Rand Line", "Springs Line", "Naledi Line")
            "Pretoria" -> listOf("Pretoria-Hatfield Line", "Centurion Line", "Mamelodi Line")
            "Durban" -> listOf("North Coast Line", "South Coast Line", "Umlazi Line")
            else -> listOf("Main Metro Line", "Express Corridor")
        }

        val statuses = listOf("On Time", "Delayed 5m", "Delayed 12m", "Cancelled", "On Time", "On Time")

        for (i in 1..8) {
            val station = activeStations[i % activeStations.size]
            val line = lines[i % lines.size]
            val minutesLeft = Random.nextInt(2, 35)
            val platform = Random.nextInt(1, 6).toString()
            val status = statuses[i % statuses.size]

            generated.add(
                LiveDeparture(
                    trainNumber = "TR-${1000 + i * 42}",
                    lineName = line,
                    destination = station.name,
                    minutesRemaining = minutesLeft,
                    platform = platform,
                    status = status
                )
            )
        }
        _liveDepartures.value = generated.sortedBy { it.minutesRemaining }
    }

    // Dynamic Multi-lingual Translation Mapping
    fun translate(key: String): String {
        val lang = _currentLanguage.value
        val map = translationMatrix[key] ?: return key
        return map[lang] ?: map["en"] ?: key
    }

    private val translationMatrix = mapOf(
        "buy_ticket" to mapOf(
            "en" to "Buy Ticket", "af" to "Koop Kaartjie", "zu" to "Thenga Ithikithi", "xh" to "Thenga Itikiti"
        ),
        "my_tickets" to mapOf(
            "en" to "My Tickets", "af" to "My Kaartjies", "zu" to "Amathikithi Ami", "xh" to "Amatikiti Wam"
        ),
        "journey_planner" to mapOf(
            "en" to "Journey Planner", "af" to "Reisbeplanner", "zu" to "Isihleli Sohambo", "xh" to "Umhleli Wehambo"
        ),
        "live_departures" to mapOf(
            "en" to "Live Departures", "af" to "Intydse Vertrekke", "zu" to "Ukusuka Okubukhoma", "xh" to "Imizuzu Yokuhamba"
        ),
        "service_alerts" to mapOf(
            "en" to "Service Alerts", "af" to "Dienswaarskuwings", "zu" to "Izaziso Zomsebenzi", "xh" to "Izilumkiso Zenkonzo"
        ),
        "ai_assistant" to mapOf(
            "en" to "AI Assistant", "af" to "KI Assistent", "zu" to "Umsizi we-AI", "xh" to "Umncedisi we-AI"
        ),
        "support" to mapOf(
            "en" to "Support & FAQ", "af" to "Ondersteuning", "zu" to "Inkxaso", "xh" to "Inkxaso"
        ),
        "admin" to mapOf(
            "en" to "Admin Portal", "af" to "Admin Portaal", "zu" to "Ingosi ye-Admin", "xh" to "Iphothali ye-Admin"
        ),
        "welcome" to mapOf(
            "en" to "Welcome to Metrorail", "af" to "Welkom by Metrorail", "zu" to "Siyakwamukela eMetrorail", "xh" to "Wamkelekile eMetrorail"
        ),
        "safe_commute" to mapOf(
            "en" to "Your modern African transport partner.", "af" to "Jou moderne Afrika-vervoermaat.", "zu" to "Uzakwethu wezokuthutha wase-Afrika.", "xh" to "Iqabane lakho lothutho lwanamhlanje e-Afrika."
        ),
        "origin" to mapOf(
            "en" to "Origin Station", "af" to "Vertrekstasie", "zu" to "Isiteshi Sokuqala", "xh" to "Isiteshi Sokuqala"
        ),
        "destination" to mapOf(
            "en" to "Destination Station", "af" to "Bestemmingstasie", "zu" to "Isiteshi Sokuya", "xh" to "Isiteshi Sokuya"
        ),
        "search_routes" to mapOf(
            "en" to "Search Routes", "af" to "Soek Roetes", "zu" to "Hlola Imizila", "xh" to "Khangela Imizila"
        ),
        "passenger_type" to mapOf(
            "en" to "Passenger Type", "af" to "Passasiersoort", "zu" to "Uhlobo Lomfarisi", "xh" to "Uhlobo Lomkhweli"
        ),
        "ticket_type" to mapOf(
            "en" to "Ticket Type", "af" to "Kaartjiesoort", "zu" to "Uhlobo Lwethikithi", "xh" to "Uhlobo Letikiti"
        ),
        "total_fare" to mapOf(
            "en" to "Total Fare", "af" to "Totale Tarief", "zu" to "Inkokhelo Sekonke", "xh" to "Imali Eyonke"
        ),
        "pay_confirm" to mapOf(
            "en" to "Proceed to Payment", "af" to "Gaan voort na betaling", "zu" to "Qhubekela Ekukhokheni", "xh" to "Gqobhela Ekuhlawuleni"
        ),
        "active_pass" to mapOf(
            "en" to "Active Pass", "af" to "Aktiewe Pas", "zu" to "Iphasi Elisebenzayo", "xh" to "Ipasi Elisebenzayo"
        ),
        "offline_notice" to mapOf(
            "en" to "Offline Ticket Storage Active", "af" to "Vanlyn kaartjiestoor aktief", "zu" to "Isitolo Sethikithi Sifakwe Offline", "xh" to "Ukugcinwa kwetikiti okungaxhunyiwe kwi-intanethi kuyasebenza"
        )
    )
}

// Support classes
data class JourneyOption(
    val title: String,
    val durationMins: Int,
    val transfers: Int,
    val platform: String,
    val fare: Double,
    val estimatedArrival: String,
    val steps: List<String>,
    val accessibilityFriendly: Boolean
)

data class LiveDeparture(
    val trainNumber: String,
    val lineName: String,
    val destination: String,
    val minutesRemaining: Int,
    val platform: String,
    val status: String
)

data class UserProfile(
    val name: String,
    val email: String,
    val phone: String
)

data class AdminMetrics(
    val totalSales: Int,
    val totalRevenue: Double,
    val activeRiders: Int,
    val peakUsagePercentage: Int,
    val systemUptime: Double
)

class MetrorailViewModelFactory(private val repository: MetrorailRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MetrorailViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MetrorailViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
