package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StationEntity
import com.example.data.local.entity.TicketEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetrorailViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketingScreen(
    viewModel: MetrorailViewModel,
    subTab: String = "Purchase", // Purchase, Wallet
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableStateOf(subTab) }
    val tickets by viewModel.tickets.collectAsState()
    val regionStations by viewModel.regionStations.collectAsState()

    // Purchase workflow states
    var origin by remember { mutableStateOf<StationEntity?>(null) }
    var destination by remember { mutableStateOf<StationEntity?>(null) }
    var showOriginMenu by remember { mutableStateOf(false) }
    var showDestinationMenu by remember { mutableStateOf(false) }

    val selectedTicketType by viewModel.selectedTicketType.collectAsState()
    val selectedPassengerType by viewModel.selectedPassengerType.collectAsState()

    var showPaymentSheet by remember { mutableStateOf(false) }
    var selectedPaymentMethod by remember { mutableStateOf("Credit Card") }
    var cardNumber by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var cardCvv by remember { mutableStateOf("") }

    // Selected ticket in wallet to view details / QR
    var selectedWalletTicket by remember { mutableStateOf<TicketEntity?>(null) }

    // Fare calculation
    val basePrice = if (origin != null && destination != null) {
        val latDiff = Math.abs(origin!!.latitude - destination!!.latitude)
        val lonDiff = Math.abs(origin!!.longitude - destination!!.longitude)
        12.50 + (latDiff + lonDiff) * 150.0
    } else 0.0

    val passengerMultiplier = when (selectedPassengerType) {
        "Student" -> 0.8
        "Senior" -> 0.5
        "Child" -> 0.5
        else -> 1.0
    }

    val ticketMultiplier = when (selectedTicketType) {
        "Return" -> 1.8
        "Weekly Pass" -> 5.5
        "Monthly Pass" -> 18.0
        else -> 1.0
    }

    val finalPrice = Math.max(12.50, Math.min(320.0, basePrice * passengerMultiplier * ticketMultiplier))

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Toggle SubTabs
        TabRow(
            selectedTabIndex = if (activeSubTab == "Purchase") 0 else 1,
            containerColor = DeepBlue,
            contentColor = OffWhite,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[if (activeSubTab == "Purchase") 0 else 1]),
                    color = TransitGold
                )
            }
        ) {
            Tab(
                selected = activeSubTab == "Purchase",
                onClick = { activeSubTab = "Purchase" },
                text = { Text("Buy Ticket", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("subtab_purchase")
            )
            Tab(
                selected = activeSubTab == "Wallet",
                onClick = {
                    activeSubTab = "Wallet"
                    // Auto select first ticket if available
                    if (tickets.isNotEmpty() && selectedWalletTicket == null) {
                        selectedWalletTicket = tickets.first()
                    }
                },
                text = { Text("Ticket Wallet (${tickets.size})", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("subtab_wallet")
            )
        }

        if (activeSubTab == "Purchase") {
            // Purchase view
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        text = "Instant Ticket Purchase",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Configure and purchase your dynamic QR digital pass in under 30 seconds.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                // Station selectors
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Origin dropdown
                            Box {
                                OutlinedTextField(
                                    value = origin?.name ?: "",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Select Departure Station") },
                                    leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = null, tint = SkyBlue) },
                                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showOriginMenu = true }
                                        .testTag("buy_origin_field"),
                                    enabled = false, // delegate click to parent box
                                    colors = OutlinedTextFieldDefaults.colors(
                                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        disabledLeadingIconColor = SkyBlue,
                                        disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .clickable { showOriginMenu = true }
                                )
                                DropdownMenu(
                                    expanded = showOriginMenu,
                                    onDismissRequest = { showOriginMenu = false },
                                    modifier = Modifier.fillMaxWidth(0.85f).heightIn(max = 240.dp)
                                ) {
                                    regionStations.forEach { s ->
                                        DropdownMenuItem(
                                            text = { Text(s.name) },
                                            onClick = {
                                                origin = s
                                                showOriginMenu = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Destination dropdown
                            Box {
                                OutlinedTextField(
                                    value = destination?.name ?: "",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Select Arrival Station") },
                                    leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = Color.Red.copy(alpha = 0.7f)) },
                                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showDestinationMenu = true }
                                        .testTag("buy_destination_field"),
                                    enabled = false,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        disabledLeadingIconColor = Color.Red,
                                        disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .clickable { showDestinationMenu = true }
                                )
                                DropdownMenu(
                                    expanded = showDestinationMenu,
                                    onDismissRequest = { showDestinationMenu = false },
                                    modifier = Modifier.fillMaxWidth(0.85f).heightIn(max = 240.dp)
                                ) {
                                    regionStations.forEach { s ->
                                        DropdownMenuItem(
                                            text = { Text(s.name) },
                                            onClick = {
                                                destination = s
                                                showDestinationMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Configuration selectors
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Ticket parameters
                            Text("Ticket Options", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                val ticketsOpts = listOf("Single", "Return", "Weekly Pass", "Monthly Pass")
                                ticketsOpts.forEach { opt ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (selectedTicketType == opt) DeepBlue else MaterialTheme.colorScheme.background)
                                            .clickable { viewModel.setTicketType(opt) }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = opt,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (selectedTicketType == opt) OffWhite else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // Passenger profiles
                            Text("Passenger Profile (Discount applies)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            val passOpts = listOf("Adult", "Student", "Senior", "Child")
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                passOpts.forEach { opt ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (selectedPassengerType == opt) DeepBlue else MaterialTheme.colorScheme.background)
                                            .clickable { viewModel.setPassengerType(opt) }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = opt,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (selectedPassengerType == opt) OffWhite else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }

                            // Info notes
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = SkyBlue, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    val discountDesc = when (selectedPassengerType) {
                                        "Student" -> "20% student discount applied. Present valid student card at gates."
                                        "Senior" -> "50% senior citizen discount applied. Present identity document (60+)."
                                        "Child" -> "50% child fare applied. Valid for children aged 3 to 12 years."
                                        else -> "Standard fare. Children under 3 travel free."
                                    }
                                    Text(text = discountDesc, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // Price Summary & Buy Button
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = DeepBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total Estimated Fare", color = OffWhite, fontSize = 14.sp)
                                Text(
                                    text = "R ${String.format("%.2f", finalPrice)}",
                                    color = TransitGold,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 24.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { showPaymentSheet = true },
                                enabled = origin != null && destination != null && origin?.id != destination?.id,
                                colors = ButtonDefaults.buttonColors(containerColor = TransitGold, contentColor = CharcoalGrey),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("buy_ticket_checkout_button")
                            ) {
                                Icon(Icons.Default.Payment, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Checkout Securely", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            }
        } else {
            // Wallet view (showing offline tickets)
            Row(modifier = Modifier.fillMaxSize()) {
                if (tickets.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.ConfirmationNumber,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No Active Tickets",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Your purchased digital passes will appear here for easy offline validation at turnstiles.",
                            textAlign = TextAlign.Center,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                } else {
                    // List of tickets (left-pane on tablet/large screens, expandable list on mobile)
                    Column(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxHeight()
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "My Active Passes",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(tickets) { t ->
                                val isSelected = selectedWalletTicket?.id == t.id
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedWalletTicket = t },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) DeepBlue else MaterialTheme.colorScheme.surface
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = t.ticketType,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = if (isSelected) TransitGold else DeepBlue
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(if (t.status == "Active") EmeraldGreen.copy(alpha = 0.2f) else Color.Red.copy(alpha = 0.2f))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = t.status,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (t.status == "Active") EmeraldGreen else Color.Red
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${t.originStationName} ➔ ${t.destinationStationName}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isSelected) OffWhite else MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "ID: ${t.id}",
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp,
                                            color = if (isSelected) OffWhite.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Divider(modifier = Modifier.width(1.dp).fillMaxHeight(), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // Detail Board with Dynamic Canvas QR (Right-pane)
                    Box(
                        modifier = Modifier
                            .weight(1.8f)
                            .fillMaxHeight()
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(16.dp)
                    ) {
                        selectedWalletTicket?.let { ticket ->
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Digital Rail Pass",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = DeepBlue
                                )

                                // Gorgeous Dynamic Custom Drawn QR Code Matrix
                                Box(
                                    modifier = Modifier
                                        .size(170.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.White)
                                        .padding(12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CanvasQrCode(payload = ticket.qrCodePayload)
                                }

                                Text(
                                    text = ticket.id,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CharcoalGrey
                                )

                                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                                // Details layout
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("Fare Paid", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text("R ${String.format("%.2f", ticket.fare)}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Passenger", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text(ticket.passengerType, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("Purchased", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text(getFormattedDate(ticket.purchaseTimestamp), fontWeight = FontWeight.Medium, fontSize = 12.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Expires", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text(getFormattedDate(ticket.expiryTimestamp), fontWeight = FontWeight.Medium, fontSize = 12.sp, color = Color.Red.copy(alpha = 0.8f))
                                    }
                                }

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = EmeraldGreen.copy(alpha = 0.1f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CloudOff, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Offline active. Gate RFID-ready.",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldGreen
                                        )
                                    }
                                }
                            }
                        } ?: Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Select a ticket to display QR Code", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                        }
                    }
                }
            }
        }
    }

    // Secure Payment Sheet simulation
    if (showPaymentSheet && origin != null && destination != null) {
        AlertDialog(
            onDismissRequest = { showPaymentSheet = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Secure Gateway Checkout", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = "Payable Amount: R ${String.format("%.2f", finalPrice)}", fontWeight = FontWeight.Bold, color = EmeraldGreen, fontSize = 16.sp)

                    Text("Select Payment Type:")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Credit Card", "Apple Pay", "SA EFT").forEach { method ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (selectedPaymentMethod == method) DeepBlue else MaterialTheme.colorScheme.surface)
                                    .clickable { selectedPaymentMethod = method }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = method,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedPaymentMethod == method) OffWhite else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    if (selectedPaymentMethod == "Credit Card") {
                        OutlinedTextField(
                            value = cardNumber,
                            onValueChange = { if (it.length <= 16) cardNumber = it },
                            label = { Text("Card Number (16 digits)") },
                            placeholder = { Text("4000 1234 5678 9010") },
                            modifier = Modifier.fillMaxWidth().testTag("payment_card_input")
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = cardExpiry,
                                onValueChange = { cardExpiry = it },
                                label = { Text("Expiry") },
                                placeholder = { Text("MM/YY") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = cardCvv,
                                onValueChange = { if (it.length <= 3) cardCvv = it },
                                label = { Text("CVV") },
                                placeholder = { Text("123") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else if (selectedPaymentMethod == "SA EFT") {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("South African EFT Integration", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("This secure EFT portal communicates directly with major SA banks: ABSA, Capitec, FNB, Nedbank, Standard Bank.", fontSize = 10.sp)
                            }
                        }
                    } else {
                        Text("Apple Pay ready. Hold device near turnstile or tap below to authorize.")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.purchaseSelectedTicket(origin!!, destination!!) {
                            showPaymentSheet = false
                            activeSubTab = "Wallet"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = OffWhite),
                    modifier = Modifier.testTag("payment_submit_button")
                ) {
                    Text("Pay Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPaymentSheet = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// Custom Drawn Canvas QR Code Generator!
@Composable
fun CanvasQrCode(payload: String) {
    // We create a hash representation from the payload string to determine QR pixels deterministically.
    // Standard QR code uses finder patterns in top-left, top-right, bottom-left.
    val payloadHash = payload.hashCode()
    val size = 21 // 21x21 QR Version 1 grid size
    val matrix = Array(size) { BooleanArray(size) }

    // Seed the matrix deterministically
    val rand = java.util.Random(payloadHash.toLong())
    for (r in 0 until size) {
        for (c in 0 until size) {
            matrix[r][c] = rand.nextBoolean()
        }
    }

    // Set Finder Patterns (7x7 blocks in corners)
    // Top-Left Finder
    setFinderPattern(matrix, 0, 0)
    // Top-Right Finder
    setFinderPattern(matrix, 0, size - 7)
    // Bottom-Left Finder
    setFinderPattern(matrix, size - 7, 0)

    // Clear border zone around finders
    for (i in 0..7) {
        if (i < size) {
            matrix[7][i] = false
            matrix[i][7] = false
            matrix[size - 8][i] = false
            matrix[i][size - 8] = false
        }
    }

    Canvas(
        modifier = Modifier.fillMaxSize()
    ) {
        val squareWidth = this.size.width / size
        val squareHeight = this.size.height / size

        for (r in 0 until size) {
            for (c in 0 until size) {
                if (matrix[r][c]) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(c * squareWidth, r * squareHeight),
                        size = Size(squareWidth, squareHeight)
                    )
                }
            }
        }
    }
}

private fun setFinderPattern(matrix: Array<BooleanArray>, row: Int, col: Int) {
    for (r in 0..6) {
        for (c in 0..6) {
            val isBorder = r == 0 || r == 6 || c == 0 || c == 6
            val isCenter = r in 2..4 && c in 2..4
            matrix[row + r][col + c] = isBorder || isCenter
        }
    }
}

private fun getFormattedDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
