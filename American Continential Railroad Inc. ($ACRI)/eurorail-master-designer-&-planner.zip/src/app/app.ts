import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from './core/services/railway-state.service';
import { AppHeader } from './components/header/header';
import { AppSidebar } from './components/sidebar/sidebar';
import { AppMapCanvas } from './components/map-canvas/map-canvas';
import { AppEngineeringDrawer } from './components/engineering-drawer/engineering-drawer';
import { AppBottomStatusBar } from './components/bottom-status-bar/bottom-status-bar';
import { AppCorridorGeneratorModal } from './components/modals/corridor-generator-modal';
import { AppOptimiserModal } from './components/modals/optimiser-modal';
import { AppStationDesignerModal } from './components/modals/station-designer-modal';
import { AppConstructionGanttModal } from './components/modals/construction-gantt-modal';
import { AppRiskMatrixModal } from './components/modals/risk-matrix-modal';
import { AppDossierExportModal } from './components/modals/dossier-export-modal';
import { AppEngineeringCadView } from './views/engineering-cad-view/engineering-cad-view';
import { AppTimetableOpsView } from './views/timetable-ops-view/timetable-ops-view';
import { AppEconomicsDemandView } from './views/economics-demand-view/economics-demand-view';
import { AppExecutiveReviewView } from './views/executive-review-view/executive-review-view';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    AppHeader,
    AppSidebar,
    AppMapCanvas,
    AppEngineeringDrawer,
    AppBottomStatusBar,
    AppCorridorGeneratorModal,
    AppOptimiserModal,
    AppStationDesignerModal,
    AppConstructionGanttModal,
    AppRiskMatrixModal,
    AppDossierExportModal,
    AppEngineeringCadView,
    AppTimetableOpsView,
    AppEconomicsDemandView,
    AppExecutiveReviewView
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  public readonly state = inject(RailwayStateService);
}
