import { GeoPoint, CityNode, TerrainCrossSectionPoint, CorridorAlignment, TunnelSection, BridgeSection } from '../domain/railway.models';

export class GeospatialEngine {
  private static readonly EARTH_RADIUS_KM = 6371.0;

  /**
   * Calculate great-circle distance between two geo-coordinates in km
   */
  public static calculateDistanceKm(p1: GeoPoint, p2: GeoPoint): number {
    const lat1Rad = (p1.lat * Math.PI) / 180;
    const lat2Rad = (p2.lat * Math.PI) / 180;
    const deltaLat = ((p2.lat - p1.lat) * Math.PI) / 180;
    const deltaLng = ((p2.lng - p1.lng) * Math.PI) / 180;

    const a =
      Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
      Math.cos(lat1Rad) * Math.cos(lat2Rad) *
      Math.sin(deltaLng / 2) * Math.sin(deltaLng / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return this.EARTH_RADIUS_KM * c;
  }

  /**
   * Interpolate geodesic points along an alignment with a given step in km
   */
  public static interpolateWaypoints(points: GeoPoint[], stepKm = 2.0): GeoPoint[] {
    if (points.length < 2) return [...points];
    const result: GeoPoint[] = [];

    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      const segDist = this.calculateDistanceKm(p1, p2);
      const steps = Math.max(1, Math.round(segDist / stepKm));

      for (let s = 0; s < steps; s++) {
        const t = s / steps;
        const lat = p1.lat + (p2.lat - p1.lat) * t;
        const lng = p1.lng + (p2.lng - p1.lng) * t;
        const elev = this.getEuropeanTerrainElevation(lat, lng);
        result.push({ lat, lng, elevation: elev });
      }
    }
    const last = points[points.length - 1];
    result.push({ ...last, elevation: this.getEuropeanTerrainElevation(last.lat, last.lng) });
    return result;
  }

  /**
   * Deterministic European geographic terrain model synthesizing actual elevation
   * based on coordinates, mountain ranges (Alps, Pyrenees, Apennines, Erzgebirge),
   * water channels (English Channel, Fehmarn Belt), and river valleys (Rhine, Danube, Rhône).
   */
  public static getEuropeanTerrainElevation(lat: number, lng: number): number {
    // 1. Water crossings
    // English Channel (Dover - Calais)
    if (lat >= 50.8 && lat <= 51.2 && lng >= 1.2 && lng <= 1.9) {
      return -35;
    }
    // Fehmarn Belt (Germany - Denmark)
    if (lat >= 54.45 && lat <= 54.65 && lng >= 11.15 && lng <= 11.45) {
      return -28;
    }

    // 2. High Mountain Systems
    // The Alps (France, Italy, Switzerland, Austria, Southern Germany)
    if (lat >= 45.2 && lat <= 47.8 && lng >= 5.8 && lng <= 15.5) {
      const distFromAlpsCenter = Math.hypot((lat - 46.5) * 111, (lng - 9.5) * 75);
      const alpineCore = Math.max(0, 1 - distFromAlpsCenter / 240);
      const highRidgeNoise = Math.sin(lat * 8.5) * Math.cos(lng * 9.2) * 450;
      return Math.round(380 + alpineCore * 1850 + highRidgeNoise);
    }

    // The Pyrenees (Spain - France)
    if (lat >= 42.2 && lat <= 43.2 && lng >= -2.2 && lng <= 3.2) {
      const distFromPyreneesCenter = Math.hypot((lat - 42.7) * 111, (lng - 0.5) * 82);
      const pyreneesCore = Math.max(0, 1 - distFromPyreneesCenter / 180);
      const ridge = Math.sin(lat * 12.0) * Math.cos(lng * 10.0) * 350;
      return Math.round(300 + pyreneesCore * 1550 + ridge);
    }

    // Italian Apennines
    if (lat >= 41.5 && lat <= 44.5 && lng >= 10.5 && lng <= 15.0) {
      const apennineCore = Math.max(0, 1 - Math.abs(lng - (10.0 + (44.5 - lat) * 1.4)) / 1.8);
      return Math.round(220 + apennineCore * 950 + Math.sin(lat * 6) * 120);
    }

    // French Massif Central
    if (lat >= 44.5 && lat <= 46.2 && lng >= 2.0 && lng <= 4.2) {
      return Math.round(450 + Math.sin(lat * 5) * Math.cos(lng * 5) * 350);
    }

    // Bohemian Massif / Ore Mountains (Erzgebirge)
    if (lat >= 50.2 && lat <= 51.0 && lng >= 12.5 && lng <= 14.5) {
      return Math.round(350 + Math.sin(lat * 10) * 280);
    }

    // Spanish Meseta Central
    if (lat >= 39.5 && lat <= 42.0 && lng >= -5.5 && lng <= -1.5) {
      return Math.round(620 + Math.sin(lat * 4) * 80);
    }

    // North German & Polish plain
    if (lat >= 52.0 && lng >= 6.0 && lng <= 22.0) {
      return Math.round(25 + Math.sin(lat * 3) * 18 + Math.cos(lng * 2) * 15);
    }

    // Standard European rolling terrain baseline
    return Math.max(15, Math.round(60 + Math.sin(lat * 3.5) * 45 + Math.cos(lng * 4.0) * 40));
  }

  /**
   * Generates continuous longitudinal terrain and rail grade cross-section points along the corridor.
   * Calculates grade %, tunnel sections, bridge viaducts, cut & fills.
   */
  public static generateLongitudinalProfile(
    waypoints: GeoPoint[],
    maxGradientPercent = 3.5,
    designSpeedKmh = 320
  ): {
    crossSectionPoints: TerrainCrossSectionPoint[];
    tunnelSections: TunnelSection[];
    bridgeSections: BridgeSection[];
    totalTunnelKm: number;
    totalBridgeKm: number;
  } {
    const interpolated = this.interpolateWaypoints(waypoints, 1.5);
    const crossSectionPoints: TerrainCrossSectionPoint[] = [];
    const tunnelSections: TunnelSection[] = [];
    const bridgeSections: BridgeSection[] = [];

    let currentChainageKm = 0;
    let prevPoint = interpolated[0];
    let runningRailElevation = prevPoint.elevation ?? 50;

    let inTunnel = false;
    let tunnelStartKm = 0;
    let inBridge = false;
    let bridgeStartKm = 0;

    for (let i = 0; i < interpolated.length; i++) {
      const pt = interpolated[i];
      if (i > 0) {
        const segDist = this.calculateDistanceKm(prevPoint, pt);
        currentChainageKm += segDist;
      }
      prevPoint = pt;

      const terrainElev = pt.elevation ?? 50;
      // Rail grade smoothing with max gradient constraint
      const maxDeltaElev = (1.5 * maxGradientPercent * 10); // max meters rise/fall per 1.5km
      const targetElev = terrainElev;
      
      // If terrain drops sharply (valley), rail stays elevated on viaduct
      // If terrain rises sharply (mountain), rail stays low in tunnel
      const elevDiff = targetElev - runningRailElevation;
      if (Math.abs(elevDiff) > maxDeltaElev) {
        runningRailElevation += Math.sign(elevDiff) * maxDeltaElev;
      } else {
        runningRailElevation = targetElev;
      }

      // Check tunnel or bridge threshold
      const overburden = terrainElev - runningRailElevation;
      const isTunnel = overburden > 25 || terrainElev < 0; // 25m overburden or underwater
      const isBridge = overburden < -18; // 18m above ground on viaduct

      const gradientPercent = i === 0 ? 0 : Number((((runningRailElevation - (crossSectionPoints[i - 1]?.railElevationM ?? runningRailElevation)) / 1500) * 100).toFixed(2));

      // Track active structures
      if (isTunnel && !inTunnel) {
        inTunnel = true;
        tunnelStartKm = currentChainageKm;
      } else if (!isTunnel && inTunnel) {
        inTunnel = false;
        const len = currentChainageKm - tunnelStartKm;
        if (len > 0.8) {
          tunnelSections.push({
            id: `TUN-${tunnelSections.length + 1}`,
            name: len > 15 ? 'Base Tunnel Section' : 'Bored Mountain Tunnel',
            startKm: Number(tunnelStartKm.toFixed(1)),
            endKm: Number(currentChainageKm.toFixed(1)),
            lengthKm: Number(len.toFixed(2)),
            maxOverburdenM: Math.round(overburden + 80),
            crossSectionSqM: designSpeedKmh >= 320 ? 88 : 80,
            isBaseTunnel: len > 15,
            costEurMillion: Math.round(len * 55)
          });
        }
      }

      if (isBridge && !inBridge) {
        inBridge = true;
        bridgeStartKm = currentChainageKm;
      } else if (!isBridge && inBridge) {
        inBridge = false;
        const len = currentChainageKm - bridgeStartKm;
        if (len > 0.4) {
          bridgeSections.push({
            id: `BRG-${bridgeSections.length + 1}`,
            name: len > 2.0 ? 'High-Speed Valley Viaduct' : 'River Crossing Viaduct',
            startKm: Number(bridgeStartKm.toFixed(1)),
            endKm: Number(currentChainageKm.toFixed(1)),
            lengthKm: Number(len.toFixed(2)),
            heightM: Math.min(95, Math.round(Math.abs(overburden))),
            spanType: len > 1.5 ? 'VIADUCT' : 'CABLE_STAYED',
            costEurMillion: Math.round(len * 38)
          });
        }
      }

      crossSectionPoints.push({
        distanceKm: Number(currentChainageKm.toFixed(2)),
        terrainElevationM: Math.round(terrainElev),
        railElevationM: Math.round(runningRailElevation),
        gradientPercent,
        isTunnel,
        isBridge,
        structureName: isTunnel ? 'Tunnel Tube' : isBridge ? 'Viaduct Span' : undefined,
        maxSpeedKmh: isTunnel && designSpeedKmh > 300 ? 300 : designSpeedKmh
      });
    }

    const totalTunnelKm = tunnelSections.reduce((acc, t) => acc + t.lengthKm, 0);
    const totalBridgeKm = bridgeSections.reduce((acc, b) => acc + b.lengthKm, 0);

    return {
      crossSectionPoints,
      tunnelSections,
      bridgeSections,
      totalTunnelKm: Number(totalTunnelKm.toFixed(1)),
      totalBridgeKm: Number(totalBridgeKm.toFixed(1))
    };
  }

  /**
   * Automated Corridor Generator:
   * Generates candidate corridors (Corridor A: Direct Trunk vs Corridor B: Terrain Following)
   */
  public static generateCandidateCorridor(
    origin: CityNode,
    destination: CityNode,
    variant: 'DIRECT_TRUNK' | 'TERRAIN_FOLLOWING' = 'DIRECT_TRUNK',
    targetSpeedKmh: 250 | 300 | 320 | 350 = 320,
    maxGradientPercent = 3.5,
    intermediateCities: CityNode[] = []
  ): Partial<CorridorAlignment> {
    const rawWaypoints: GeoPoint[] = [
      { lat: origin.lat, lng: origin.lng, elevation: origin.elevation }
    ];

    if (intermediateCities.length > 0) {
      for (const city of intermediateCities) {
        rawWaypoints.push({ lat: city.lat, lng: city.lng, elevation: city.elevation });
      }
    } else {
      // Synthesize smart intermediate waypoint
      const midLat = (origin.lat + destination.lat) / 2;
      const midLng = (origin.lng + destination.lng) / 2;
      if (variant === 'TERRAIN_FOLLOWING') {
        // Curve slightly to bypass high mountain massifs
        const offset = 0.45;
        rawWaypoints.push({
          lat: midLat + (origin.lng < destination.lng ? -offset : offset),
          lng: midLng + (origin.lat < destination.lat ? offset : -offset),
          elevation: this.getEuropeanTerrainElevation(midLat, midLng)
        });
      }
    }

    rawWaypoints.push({
      lat: destination.lat,
      lng: destination.lng,
      elevation: destination.elevation
    });

    // Profile analysis
    const { crossSectionPoints, tunnelSections, bridgeSections, totalTunnelKm, totalBridgeKm } =
      this.generateLongitudinalProfile(rawWaypoints, maxGradientPercent, targetSpeedKmh);

    const totalDist = crossSectionPoints.length > 0
      ? crossSectionPoints[crossSectionPoints.length - 1].distanceKm
      : this.calculateDistanceKm(origin, destination);

    const tunnelPercentage = totalDist > 0 ? Number(((totalTunnelKm / totalDist) * 100).toFixed(1)) : 0;
    const bridgePercentage = totalDist > 0 ? Number(((totalBridgeKm / totalDist) * 100).toFixed(1)) : 0;

    // Minimum radius calculation: R = V^2 / (11.8 * (h_act + h_def))
    const appliedCant = 155; // mm
    const cantDeficiency = 95; // mm
    const minCurveRadiusM = Math.round(
      Math.pow(targetSpeedKmh, 2) / (11.8 * ((appliedCant + cantDeficiency) / 1000) * 9.81 * 0.1)
    );

    // Rough CAPEX model:
    // Base surface track: €22M/km, Tunnel: €58M/km, Bridge: €42M/km, Systems: €6M/km
    const capex = (
      (totalDist - totalTunnelKm - totalBridgeKm) * 22 +
      totalTunnelKm * 58 +
      totalBridgeKm * 42 +
      totalDist * 6 +
      (intermediateCities.length + 2) * 280
    ) / 1000;

    // Travel time estimate: accounting for acceleration, intermediate stops, and speed limits
    const avgSpeed = targetSpeedKmh * (variant === 'DIRECT_TRUNK' ? 0.88 : 0.82);
    const runMinutes = Math.round((totalDist / avgSpeed) * 60) + intermediateCities.length * 4;

    return {
      distanceKm: Math.round(totalDist),
      waypoints: rawWaypoints,
      crossSectionPoints,
      tunnelSections,
      bridgeSections,
      tunnelLengthKm: totalTunnelKm,
      tunnelPercentage,
      bridgeLengthKm: totalBridgeKm,
      bridgePercentage,
      designSpeedKmh: targetSpeedKmh,
      maxGradientPercent,
      minCurveRadiusM: Math.max(5000, minCurveRadiusM),
      appliedCantMm: appliedCant,
      cantDeficiencyMm: cantDeficiency,
      capexEurBillion: Number(capex.toFixed(2)),
      estimatedJourneyTimeMinutes: runMinutes
    };
  }

  /**
   * Export network alignment and stations to standard RFC 7946 GeoJSON
   */
  public static exportToGeoJson(corridors: CorridorAlignment[], stations: CityNode[]): object {
    const features: object[] = [];

    // Add stations
    for (const st of stations) {
      features.push({
        type: 'Feature',
        id: st.id,
        geometry: {
          type: 'Point',
          coordinates: [st.lng, st.lat]
        },
        properties: {
          type: 'STATION_HUB',
          name: st.name,
          country: st.country,
          countryCode: st.countryCode,
          population: st.population,
          gdpBillionEur: st.gdpBillionEur,
          stationType: st.stationType,
          platforms: st.platformsCount,
          hasExistingHsr: st.hasExistingHsr
        }
      });
    }

    // Add corridor lines
    for (const c of corridors) {
      features.push({
        type: 'Feature',
        id: c.id,
        geometry: {
          type: 'LineString',
          coordinates: c.waypoints.map(w => [w.lng, w.lat])
        },
        properties: {
          type: 'HSR_CORRIDOR',
          code: c.code,
          name: c.name,
          distanceKm: c.distanceKm,
          designSpeedKmh: c.designSpeedKmh,
          tunnelPercentage: c.tunnelPercentage,
          bridgePercentage: c.bridgePercentage,
          capexEurBillion: c.capexEurBillion,
          status: c.status,
          trainsPerHour: c.trainsPerHour
        }
      });
    }

    return {
      type: 'FeatureCollection',
      metadata: {
        system: 'EURORAIL Master Designer & Planner',
        generatedAt: new Date().toISOString(),
        crs: 'urn:ogc:def:crs:OGC:1.3:CRS84'
      },
      features
    };
  }
}
