export type AlignmentStatus = 
  | 'PROPOSED' 
  | 'PLANNED' 
  | 'DESIGNED' 
  | 'UNDER_CONSTRUCTION' 
  | 'OPERATIONAL';

export type StationType = 
  | 'TERMINUS' 
  | 'THROUGH' 
  | 'INTERCHANGE_HUB' 
  | 'UNDERGROUND' 
  | 'AIRPORT_INTERMODAL';

export type TrackStructure = 'SLAB_TRACK' | 'BALLASTED';

export type SignalingType = 'ETCS_L2' | 'ETCS_L3_MOVING_BLOCK' | 'CONVENTIONAL_FALLBACK';

export type ElectrificationSystem = 
  | '25KV_50HZ_AC' 
  | '15KV_16_7HZ_AC' 
  | '3KV_DC' 
  | '1_5KV_DC';

export interface GeoPoint {
  lat: number;
  lng: number;
  elevation?: number; // meters above sea level
}

export interface CityNode {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  lat: number;
  lng: number;
  elevation: number; // m
  population: number; // metropolitan area
  gdpBillionEur: number;
  annualAirportPaxMillion: number;
  stationType: StationType;
  platformsCount: number;
  hasExistingHsr: boolean;
  intermodalModes: ('METRO' | 'REGIONAL' | 'TRAM' | 'AIRPORT_RAIL' | 'BUS')[];
}

export interface TunnelSection {
  id: string;
  name: string;
  startKm: number;
  endKm: number;
  lengthKm: number;
  maxOverburdenM: number;
  crossSectionSqM: number;
  isBaseTunnel: boolean;
  costEurMillion: number;
}

export interface BridgeSection {
  id: string;
  name: string;
  startKm: number;
  endKm: number;
  lengthKm: number;
  heightM: number;
  spanType: 'VIADUCT' | 'CABLE_STAYED' | 'ARCH_STEEL';
  costEurMillion: number;
}

export interface TerrainCrossSectionPoint {
  distanceKm: number;
  terrainElevationM: number;
  railElevationM: number;
  gradientPercent: number;
  isTunnel: boolean;
  isBridge: boolean;
  structureName?: string;
  maxSpeedKmh: number;
}

export interface CorridorAlignment {
  id: string;
  code: string;
  name: string;
  originId: string;
  destinationId: string;
  intermediateStationIds: string[];
  waypoints: GeoPoint[];
  distanceKm: number;
  designSpeedKmh: 250 | 300 | 320 | 350;
  maxGradientPercent: number; // e.g. 2.5% to 4.0%
  minCurveRadiusM: number; // e.g. 5000 - 7000 m
  appliedCantMm: number; // e.g. 150 mm
  cantDeficiencyMm: number; // e.g. 80 - 100 mm
  trackStructure: TrackStructure;
  gaugeMm: 1435 | 1668; // Standard or Iberian broad gauge
  signaling: SignalingType;
  electrification: ElectrificationSystem;
  status: AlignmentStatus;
  scenarioId: string;

  // Infrastructure metrics
  tunnelSections: TunnelSection[];
  bridgeSections: BridgeSection[];
  tunnelLengthKm: number;
  tunnelPercentage: number;
  bridgeLengthKm: number;
  bridgePercentage: number;
  crossSectionPoints: TerrainCrossSectionPoint[];

  // Operational & Capacity
  headwayMinutes: number; // e.g. 3 min for ETCS L2
  trainsPerHour: number; // practical tph
  theoreticalCapacityTph: number;
  capacityUtilizationPercent: number;

  // Financial & Demand
  capexEurBillion: number;
  annualOpexEurMillion: number;
  projectedAnnualPaxMillion: number;
  co2AvoidedAnnualTonnes: number;
  estimatedJourneyTimeMinutes: number;

  // Cross-border
  countriesTraversed: string[];
  voltageSwitchCount: number;
  signalingBoundaries: number;
}

export interface TrainsetSpec {
  id: string;
  name: string;
  modelCode: string;
  manufacturer: string;
  maxSpeedKmh: number;
  tractionPowerKw: number;
  emptyMassTonnes: number;
  loadedMassTonnes: number;
  trainLengthM: number;
  passengerCapacity: number;
  startingAccelerationMPerS2: number;
  serviceDecelerationMPerS2: number;
  emergencyDecelerationMPerS2: number;
  tractionType: 'DISTRIBUTED_EMU' | 'POWER_CAR_PUSH_PULL';
  davisA: number; // Mechanical resistance (kN)
  davisB: number; // Velocity proportional (kN / (km/h))
  davisC: number; // Aerodynamic drag (kN / (km/h)^2)
  regenerativeBrakingEfficiency: number; // e.g. 0.16 (16%)
  isCustom?: boolean;
}

export interface SpeedDistanceStep {
  distanceKm: number;
  speedKmh: number;
  timeSeconds: number;
  tractiveForceKn: number;
  energyKwh: number;
  accelerationMPerS2: number;
  gradientPercent: number;
}

export interface TrainSimulationResult {
  corridorId: string;
  trainsetId: string;
  journeyTimeMinutes: number;
  averageSpeedKmh: number;
  topSpeedReachedKmh: number;
  totalEnergyConsumptionKwh: number;
  energyRecoveredKwh: number;
  netEnergyConsumptionKwh: number;
  energyPerPassengerKmWh: number;
  speedProfile: SpeedDistanceStep[];
}

export interface TimetableStop {
  stationId: string;
  stationName: string;
  distanceKm: number;
  arrivalTimeMinutes: number; // relative to 00:00 or departure
  departureTimeMinutes: number;
  dwellTimeMinutes: number;
  platform: string;
}

export interface TimetableService {
  id: string;
  serviceNumber: string;
  corridorId: string;
  trainsetId: string;
  departureTime: string; // "07:00"
  departureMinutes: number;
  stops: TimetableStop[];
  totalJourneyMinutes: number;
  frequencyPerHour: number;
  conflicts: string[];
}

export interface ConstructionPackage {
  id: string;
  corridorId: string;
  code: string;
  title: string;
  scope: string;
  startYear: number;
  endYear: number;
  costEurMillion: number;
  contractor: string;
  status: 'TENDER' | 'AWARDED' | 'IN_PROGRESS' | 'COMPLETED';
  progressPercent: number;
}

export interface RiskItem {
  id: string;
  corridorId: string;
  category: 'GEOTECHNICAL' | 'ENVIRONMENTAL' | 'CROSS_BORDER' | 'POLITICAL' | 'FINANCIAL' | 'CONSTRUCTION';
  title: string;
  description: string;
  probability: number; // 1 to 5
  impact: number; // 1 to 5
  riskScore: number; // probability * impact
  mitigationStrategy: string;
}

export interface CrossBorderConstraint {
  borderPair: string;
  countryA: string;
  countryB: string;
  voltageA: string;
  voltageB: string;
  signalingTransition: string;
  loadingGaugeDiff: string;
  operatingRulesSync: string;
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  code: string;
  targetYear: number;
  description: string;
  corridorIds: string[];
  demandMultiplier: number;
  carbonTaxEuroPerTonne: number;
}

export interface OptimiserWeights {
  travelTimeWeight: number; // e.g. 30%
  capexWeight: number; // e.g. 25%
  demandWeight: number; // e.g. 20%
  emissionsWeight: number; // e.g. 10%
  connectivityWeight: number; // e.g. 15%
}

export interface OptimisedNetworkVariant {
  versionCode: string;
  iteration: number;
  score: number;
  totalLengthKm: number;
  totalCapexEurBillion: number;
  annualPaxMillion: number;
  annualCo2AvoidedMt: number;
  averageSpeedKmh: number;
  corridorsCount: number;
  deltaSummary: string;
}
