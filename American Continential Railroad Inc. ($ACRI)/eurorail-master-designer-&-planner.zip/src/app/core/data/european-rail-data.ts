import { CityNode, CorridorAlignment, TrainsetSpec, ScenarioDefinition, ConstructionPackage, RiskItem, CrossBorderConstraint } from '../domain/railway.models';

export const EUROPEAN_CITIES: CityNode[] = [
  // United Kingdom & Ireland
  {
    id: 'LON',
    name: 'London',
    country: 'United Kingdom',
    countryCode: 'GB',
    lat: 51.5074,
    lng: -0.1278,
    elevation: 25,
    population: 9600000,
    gdpBillionEur: 680,
    annualAirportPaxMillion: 130,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 16,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'MAN',
    name: 'Manchester',
    country: 'United Kingdom',
    countryCode: 'GB',
    lat: 53.4808,
    lng: -2.2426,
    elevation: 38,
    population: 2800000,
    gdpBillionEur: 110,
    annualAirportPaxMillion: 28,
    stationType: 'THROUGH',
    platformsCount: 14,
    hasExistingHsr: false,
    intermodalModes: ['TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'EDI',
    name: 'Edinburgh',
    country: 'United Kingdom',
    countryCode: 'GB',
    lat: 55.9533,
    lng: -3.1883,
    elevation: 41,
    population: 1380000,
    gdpBillionEur: 62,
    annualAirportPaxMillion: 15,
    stationType: 'TERMINUS',
    platformsCount: 20,
    hasExistingHsr: false,
    intermodalModes: ['TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'DUB',
    name: 'Dublin',
    country: 'Ireland',
    countryCode: 'IE',
    lat: 53.3498,
    lng: -6.2603,
    elevation: 15,
    population: 1450000,
    gdpBillionEur: 140,
    annualAirportPaxMillion: 33,
    stationType: 'TERMINUS',
    platformsCount: 10,
    hasExistingHsr: false,
    intermodalModes: ['TRAM', 'REGIONAL', 'BUS']
  },

  // France & Benelux
  {
    id: 'PAR',
    name: 'Paris',
    country: 'France',
    countryCode: 'FR',
    lat: 48.8566,
    lng: 2.3522,
    elevation: 35,
    population: 11200000,
    gdpBillionEur: 820,
    annualAirportPaxMillion: 105,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 28,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'REGIONAL', 'TRAM', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'LIL',
    name: 'Lille',
    country: 'France',
    countryCode: 'FR',
    lat: 50.6292,
    lng: 3.0573,
    elevation: 20,
    population: 1200000,
    gdpBillionEur: 48,
    annualAirportPaxMillion: 2,
    stationType: 'THROUGH',
    platformsCount: 10,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'BRU',
    name: 'Brussels',
    country: 'Belgium',
    countryCode: 'BE',
    lat: 50.8503,
    lng: 4.3517,
    elevation: 28,
    population: 2100000,
    gdpBillionEur: 115,
    annualAirportPaxMillion: 26,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 22,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'AMS',
    name: 'Amsterdam',
    country: 'Netherlands',
    countryCode: 'NL',
    lat: 52.3676,
    lng: 4.9041,
    elevation: -2,
    population: 2500000,
    gdpBillionEur: 195,
    annualAirportPaxMillion: 71,
    stationType: 'TERMINUS',
    platformsCount: 15,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'RTM',
    name: 'Rotterdam',
    country: 'Netherlands',
    countryCode: 'NL',
    lat: 51.9244,
    lng: 4.4777,
    elevation: -1,
    population: 1450000,
    gdpBillionEur: 85,
    annualAirportPaxMillion: 2,
    stationType: 'THROUGH',
    platformsCount: 16,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'LUX',
    name: 'Luxembourg',
    country: 'Luxembourg',
    countryCode: 'LU',
    lat: 49.6116,
    lng: 6.1319,
    elevation: 300,
    population: 660000,
    gdpBillionEur: 80,
    annualAirportPaxMillion: 4,
    stationType: 'THROUGH',
    platformsCount: 8,
    hasExistingHsr: true,
    intermodalModes: ['TRAM', 'REGIONAL', 'BUS']
  },

  // Germany
  {
    id: 'FRA',
    name: 'Frankfurt',
    country: 'Germany',
    countryCode: 'DE',
    lat: 50.1109,
    lng: 8.6821,
    elevation: 112,
    population: 2700000,
    gdpBillionEur: 230,
    annualAirportPaxMillion: 70,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 24,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'CGN',
    name: 'Cologne',
    country: 'Germany',
    countryCode: 'DE',
    lat: 50.9375,
    lng: 6.9603,
    elevation: 53,
    population: 1100000,
    gdpBillionEur: 92,
    annualAirportPaxMillion: 12,
    stationType: 'THROUGH',
    platformsCount: 11,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'BER',
    name: 'Berlin',
    country: 'Germany',
    countryCode: 'DE',
    lat: 52.5200,
    lng: 13.4050,
    elevation: 34,
    population: 4600000,
    gdpBillionEur: 180,
    annualAirportPaxMillion: 36,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 14,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'HAM',
    name: 'Hamburg',
    country: 'Germany',
    countryCode: 'DE',
    lat: 53.5511,
    lng: 9.9937,
    elevation: 18,
    population: 2600000,
    gdpBillionEur: 145,
    annualAirportPaxMillion: 17,
    stationType: 'THROUGH',
    platformsCount: 12,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'MUC',
    name: 'Munich',
    country: 'Germany',
    countryCode: 'DE',
    lat: 48.1351,
    lng: 11.5820,
    elevation: 520,
    population: 2900000,
    gdpBillionEur: 215,
    annualAirportPaxMillion: 48,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 32,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'STR',
    name: 'Stuttgart',
    country: 'Germany',
    countryCode: 'DE',
    lat: 48.7758,
    lng: 9.1829,
    elevation: 245,
    population: 2800000,
    gdpBillionEur: 175,
    annualAirportPaxMillion: 12,
    stationType: 'UNDERGROUND',
    platformsCount: 8,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'SXB',
    name: 'Strasbourg',
    country: 'France',
    countryCode: 'FR',
    lat: 48.5734,
    lng: 7.7521,
    elevation: 142,
    population: 850000,
    gdpBillionEur: 38,
    annualAirportPaxMillion: 1,
    stationType: 'THROUGH',
    platformsCount: 9,
    hasExistingHsr: true,
    intermodalModes: ['TRAM', 'REGIONAL', 'BUS']
  },

  // Switzerland & Austria
  {
    id: 'ZRH',
    name: 'Zürich',
    country: 'Switzerland',
    countryCode: 'CH',
    lat: 47.3769,
    lng: 8.5417,
    elevation: 408,
    population: 1400000,
    gdpBillionEur: 165,
    annualAirportPaxMillion: 31,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 26,
    hasExistingHsr: true,
    intermodalModes: ['TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'GVA',
    name: 'Geneva',
    country: 'Switzerland',
    countryCode: 'CH',
    lat: 46.2044,
    lng: 6.1432,
    elevation: 375,
    population: 580000,
    gdpBillionEur: 75,
    annualAirportPaxMillion: 18,
    stationType: 'THROUGH',
    platformsCount: 8,
    hasExistingHsr: true,
    intermodalModes: ['TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'VIE',
    name: 'Vienna',
    country: 'Austria',
    countryCode: 'AT',
    lat: 48.2082,
    lng: 16.3738,
    elevation: 190,
    population: 2900000,
    gdpBillionEur: 125,
    annualAirportPaxMillion: 32,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 16,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },

  // Italy
  {
    id: 'MIL',
    name: 'Milan',
    country: 'Italy',
    countryCode: 'IT',
    lat: 45.4642,
    lng: 9.1900,
    elevation: 120,
    population: 4300000,
    gdpBillionEur: 245,
    annualAirportPaxMillion: 40,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 24,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'TRN',
    name: 'Turin',
    country: 'Italy',
    countryCode: 'IT',
    lat: 45.0703,
    lng: 7.6869,
    elevation: 240,
    population: 1750000,
    gdpBillionEur: 78,
    annualAirportPaxMillion: 4,
    stationType: 'THROUGH',
    platformsCount: 10,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'ROM',
    name: 'Rome',
    country: 'Italy',
    countryCode: 'IT',
    lat: 41.9028,
    lng: 12.4964,
    elevation: 48,
    population: 4350000,
    gdpBillionEur: 170,
    annualAirportPaxMillion: 44,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 32,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'VCE',
    name: 'Venice',
    country: 'Italy',
    countryCode: 'IT',
    lat: 45.4408,
    lng: 12.3155,
    elevation: 2,
    population: 860000,
    gdpBillionEur: 42,
    annualAirportPaxMillion: 11,
    stationType: 'TERMINUS',
    platformsCount: 14,
    hasExistingHsr: true,
    intermodalModes: ['TRAM', 'REGIONAL', 'BUS']
  },

  // Central & Eastern Europe
  {
    id: 'PRG',
    name: 'Prague',
    country: 'Czech Republic',
    countryCode: 'CZ',
    lat: 50.0755,
    lng: 14.4378,
    elevation: 212,
    population: 2700000,
    gdpBillionEur: 95,
    annualAirportPaxMillion: 18,
    stationType: 'THROUGH',
    platformsCount: 12,
    hasExistingHsr: false,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'WAW',
    name: 'Warsaw',
    country: 'Poland',
    countryCode: 'PL',
    lat: 52.2297,
    lng: 21.0122,
    elevation: 100,
    population: 3100000,
    gdpBillionEur: 115,
    annualAirportPaxMillion: 19,
    stationType: 'UNDERGROUND',
    platformsCount: 8,
    hasExistingHsr: false,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'BUD',
    name: 'Budapest',
    country: 'Hungary',
    countryCode: 'HU',
    lat: 47.4979,
    lng: 19.0402,
    elevation: 102,
    population: 3000000,
    gdpBillionEur: 88,
    annualAirportPaxMillion: 16,
    stationType: 'TERMINUS',
    platformsCount: 18,
    hasExistingHsr: false,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'BTS',
    name: 'Bratislava',
    country: 'Slovakia',
    countryCode: 'SK',
    lat: 48.1486,
    lng: 17.1077,
    elevation: 152,
    population: 670000,
    gdpBillionEur: 36,
    annualAirportPaxMillion: 2,
    stationType: 'THROUGH',
    platformsCount: 7,
    hasExistingHsr: false,
    intermodalModes: ['TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'LJU',
    name: 'Ljubljana',
    country: 'Slovenia',
    countryCode: 'SI',
    lat: 46.0569,
    lng: 14.5058,
    elevation: 295,
    population: 350000,
    gdpBillionEur: 22,
    annualAirportPaxMillion: 1,
    stationType: 'THROUGH',
    platformsCount: 6,
    hasExistingHsr: false,
    intermodalModes: ['REGIONAL', 'BUS']
  },
  {
    id: 'ZAG',
    name: 'Zagreb',
    country: 'Croatia',
    countryCode: 'HR',
    lat: 45.8150,
    lng: 15.9819,
    elevation: 158,
    population: 1100000,
    gdpBillionEur: 32,
    annualAirportPaxMillion: 3,
    stationType: 'TERMINUS',
    platformsCount: 8,
    hasExistingHsr: false,
    intermodalModes: ['TRAM', 'REGIONAL', 'BUS']
  },

  // Spain & Portugal
  {
    id: 'MAD',
    name: 'Madrid',
    country: 'Spain',
    countryCode: 'ES',
    lat: 40.4168,
    lng: -3.7038,
    elevation: 650,
    population: 6700000,
    gdpBillionEur: 270,
    annualAirportPaxMillion: 62,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 22,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'BCN',
    name: 'Barcelona',
    country: 'Spain',
    countryCode: 'ES',
    lat: 41.3851,
    lng: 2.1734,
    elevation: 32,
    population: 5500000,
    gdpBillionEur: 190,
    annualAirportPaxMillion: 53,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 16,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'LIS',
    name: 'Lisbon',
    country: 'Portugal',
    countryCode: 'PT',
    lat: 38.7223,
    lng: -9.1393,
    elevation: 45,
    population: 2900000,
    gdpBillionEur: 82,
    annualAirportPaxMillion: 33,
    stationType: 'THROUGH',
    platformsCount: 10,
    hasExistingHsr: false,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'LYS',
    name: 'Lyon',
    country: 'France',
    countryCode: 'FR',
    lat: 45.7640,
    lng: 4.8357,
    elevation: 173,
    population: 2300000,
    gdpBillionEur: 98,
    annualAirportPaxMillion: 12,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 16,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'MRS',
    name: 'Marseille',
    country: 'France',
    countryCode: 'FR',
    lat: 43.2965,
    lng: 5.3698,
    elevation: 30,
    population: 1800000,
    gdpBillionEur: 65,
    annualAirportPaxMillion: 10,
    stationType: 'TERMINUS',
    platformsCount: 16,
    hasExistingHsr: true,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'BUS']
  },
  {
    id: 'BOD',
    name: 'Bordeaux',
    country: 'France',
    countryCode: 'FR',
    lat: 44.8378,
    lng: -0.5792,
    elevation: 12,
    population: 1350000,
    gdpBillionEur: 58,
    annualAirportPaxMillion: 7,
    stationType: 'THROUGH',
    platformsCount: 15,
    hasExistingHsr: true,
    intermodalModes: ['TRAM', 'REGIONAL', 'BUS']
  },

  // Scandinavia
  {
    id: 'CPH',
    name: 'Copenhagen',
    country: 'Denmark',
    countryCode: 'DK',
    lat: 55.6761,
    lng: 12.5683,
    elevation: 14,
    population: 2100000,
    gdpBillionEur: 135,
    annualAirportPaxMillion: 30,
    stationType: 'THROUGH',
    platformsCount: 13,
    hasExistingHsr: false,
    intermodalModes: ['METRO', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'STO',
    name: 'Stockholm',
    country: 'Sweden',
    countryCode: 'SE',
    lat: 59.3293,
    lng: 18.0686,
    elevation: 28,
    population: 2400000,
    gdpBillionEur: 160,
    annualAirportPaxMillion: 26,
    stationType: 'TERMINUS',
    platformsCount: 18,
    hasExistingHsr: false,
    intermodalModes: ['METRO', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  },
  {
    id: 'OSL',
    name: 'Oslo',
    country: 'Norway',
    countryCode: 'NO',
    lat: 59.9139,
    lng: 10.7522,
    elevation: 23,
    population: 1600000,
    gdpBillionEur: 120,
    annualAirportPaxMillion: 28,
    stationType: 'INTERCHANGE_HUB',
    platformsCount: 19,
    hasExistingHsr: false,
    intermodalModes: ['METRO', 'TRAM', 'REGIONAL', 'AIRPORT_RAIL', 'BUS']
  }
];

export const FLEET_TRAINSETS: TrainsetSpec[] = [
  {
    id: 'ER-350',
    name: 'EURORAIL 350 Velocità',
    modelCode: 'ER-V350',
    manufacturer: 'Alstom–Siemens Eurorail Consortium',
    maxSpeedKmh: 350,
    tractionPowerKw: 16000,
    emptyMassTonnes: 720,
    loadedMassTonnes: 785,
    trainLengthM: 395,
    passengerCapacity: 920,
    startingAccelerationMPerS2: 0.65,
    serviceDecelerationMPerS2: 0.75,
    emergencyDecelerationMPerS2: 1.15,
    tractionType: 'DISTRIBUTED_EMU',
    davisA: 4.8,
    davisB: 0.082,
    davisC: 0.0039,
    regenerativeBrakingEfficiency: 0.18
  },
  {
    id: 'ER-320',
    name: 'EURORAIL 320 Duplex',
    modelCode: 'ER-D320',
    manufacturer: 'European Rail Systems',
    maxSpeedKmh: 320,
    tractionPowerKw: 9280,
    emptyMassTonnes: 395,
    loadedMassTonnes: 440,
    trainLengthM: 200,
    passengerCapacity: 510,
    startingAccelerationMPerS2: 0.58,
    serviceDecelerationMPerS2: 0.70,
    emergencyDecelerationMPerS2: 1.10,
    tractionType: 'POWER_CAR_PUSH_PULL',
    davisA: 3.6,
    davisB: 0.071,
    davisC: 0.0035,
    regenerativeBrakingEfficiency: 0.15
  },
  {
    id: 'ER-EXP',
    name: 'EURORAIL EXPRESS Executive',
    modelCode: 'ER-X350',
    manufacturer: 'Hitachi–CAF InterCity',
    maxSpeedKmh: 350,
    tractionPowerKw: 12000,
    emptyMassTonnes: 430,
    loadedMassTonnes: 480,
    trainLengthM: 205,
    passengerCapacity: 420,
    startingAccelerationMPerS2: 0.70,
    serviceDecelerationMPerS2: 0.80,
    emergencyDecelerationMPerS2: 1.20,
    tractionType: 'DISTRIBUTED_EMU',
    davisA: 3.2,
    davisB: 0.065,
    davisC: 0.0031,
    regenerativeBrakingEfficiency: 0.19
  },
  {
    id: 'ER-NIGHT',
    name: 'EURORAIL NIGHT Inter-Continental',
    modelCode: 'ER-N230',
    manufacturer: 'Stadler Rail Europe',
    maxSpeedKmh: 230,
    tractionPowerKw: 8000,
    emptyMassTonnes: 490,
    loadedMassTonnes: 540,
    trainLengthM: 240,
    passengerCapacity: 340,
    startingAccelerationMPerS2: 0.48,
    serviceDecelerationMPerS2: 0.65,
    emergencyDecelerationMPerS2: 0.95,
    tractionType: 'DISTRIBUTED_EMU',
    davisA: 4.2,
    davisB: 0.075,
    davisC: 0.0038,
    regenerativeBrakingEfficiency: 0.14
  }
];

export const INITIAL_CORRIDORS: CorridorAlignment[] = [
  {
    id: 'COR-LON-FRA',
    code: 'ER-C01',
    name: 'North-West European Trunk (London–Frankfurt)',
    originId: 'LON',
    destinationId: 'FRA',
    intermediateStationIds: ['LIL', 'BRU', 'CGN'],
    waypoints: [
      { lat: 51.5074, lng: -0.1278, elevation: 25 }, // London St Pancras
      { lat: 51.1279, lng: 1.3134, elevation: 15 },  // Dover portal
      { lat: 50.9328, lng: 1.8152, elevation: 12 },  // Coquelles portal
      { lat: 50.6292, lng: 3.0573, elevation: 20 },  // Lille Europe
      { lat: 50.8503, lng: 4.3517, elevation: 28 },  // Brussels Midi
      { lat: 50.7753, lng: 6.0839, elevation: 173 }, // Aachen
      { lat: 50.9375, lng: 6.9603, elevation: 53 },  // Cologne Hbf
      { lat: 50.3569, lng: 7.5890, elevation: 195 }, // Montabaur NBS
      { lat: 50.1109, lng: 8.6821, elevation: 112 }  // Frankfurt Hbf
    ],
    distanceKm: 618,
    designSpeedKmh: 320,
    maxGradientPercent: 3.5,
    minCurveRadiusM: 5200,
    appliedCantMm: 150,
    cantDeficiencyMm: 95,
    trackStructure: 'SLAB_TRACK',
    gaugeMm: 1435,
    signaling: 'ETCS_L2',
    electrification: '25KV_50HZ_AC',
    status: 'OPERATIONAL',
    scenarioId: 'EUR-2040',
    tunnelSections: [
      {
        id: 'TUN-01',
        name: 'Channel Tunnel Interlink',
        startKm: 110,
        endKm: 160.5,
        lengthKm: 50.5,
        maxOverburdenM: 75,
        crossSectionSqM: 52,
        isBaseTunnel: true,
        costEurMillion: 7800
      },
      {
        id: 'TUN-02',
        name: 'Taunus Mountain Tunnel',
        startKm: 570,
        endKm: 579.2,
        lengthKm: 9.2,
        maxOverburdenM: 180,
        crossSectionSqM: 82,
        isBaseTunnel: false,
        costEurMillion: 620
      }
    ],
    bridgeSections: [
      {
        id: 'BRG-01',
        name: 'Medway Viaduct High Speed',
        startKm: 62,
        endKm: 63.4,
        lengthKm: 1.4,
        heightM: 45,
        spanType: 'VIADUCT',
        costEurMillion: 110
      },
      {
        id: 'BRG-02',
        name: 'Rhine Crossing Cologne South',
        startKm: 420,
        endKm: 421.8,
        lengthKm: 1.8,
        heightM: 28,
        spanType: 'CABLE_STAYED',
        costEurMillion: 280
      }
    ],
    tunnelLengthKm: 59.7,
    tunnelPercentage: 9.6,
    bridgeLengthKm: 14.8,
    bridgePercentage: 2.4,
    crossSectionPoints: [], // will be generated by geospatial engine
    headwayMinutes: 3,
    trainsPerHour: 8,
    theoreticalCapacityTph: 16,
    capacityUtilizationPercent: 50,
    capexEurBillion: 18.4,
    annualOpexEurMillion: 280,
    projectedAnnualPaxMillion: 18.2,
    co2AvoidedAnnualTonnes: 1450000,
    estimatedJourneyTimeMinutes: 168,
    countriesTraversed: ['GB', 'FR', 'BE', 'DE'],
    voltageSwitchCount: 2,
    signalingBoundaries: 3
  },
  {
    id: 'COR-PAR-VIE',
    code: 'ER-C02',
    name: 'Trans-Danubian Magistrale (Paris–Vienna)',
    originId: 'PAR',
    destinationId: 'VIE',
    intermediateStationIds: ['SXB', 'STR', 'MUC'],
    waypoints: [
      { lat: 48.8566, lng: 2.3522, elevation: 35 },  // Paris Est
      { lat: 48.7300, lng: 5.5000, elevation: 280 }, // Lorraine TGV
      { lat: 48.5734, lng: 7.7521, elevation: 142 }, // Strasbourg
      { lat: 48.7758, lng: 9.1829, elevation: 245 }, // Stuttgart
      { lat: 48.4000, lng: 10.000, elevation: 470 }, // Ulm NBS
      { lat: 48.1351, lng: 11.5820, elevation: 520 },// Munich
      { lat: 47.8095, lng: 13.0550, elevation: 424 },// Salzburg
      { lat: 48.2082, lng: 16.3738, elevation: 190 } // Vienna Hbf
    ],
    distanceKm: 1045,
    designSpeedKmh: 350,
    maxGradientPercent: 3.0,
    minCurveRadiusM: 6500,
    appliedCantMm: 160,
    cantDeficiencyMm: 100,
    trackStructure: 'SLAB_TRACK',
    gaugeMm: 1435,
    signaling: 'ETCS_L2',
    electrification: '25KV_50HZ_AC',
    status: 'DESIGNED',
    scenarioId: 'EUR-2040',
    tunnelSections: [
      {
        id: 'TUN-11',
        name: 'Albaufstieg Tunnel Chain',
        startKm: 580,
        endKm: 605,
        lengthKm: 25.0,
        maxOverburdenM: 290,
        crossSectionSqM: 86,
        isBaseTunnel: false,
        costEurMillion: 2400
      },
      {
        id: 'TUN-12',
        name: 'Wienerwald Base Tunnel',
        startKm: 1010,
        endKm: 1023.3,
        lengthKm: 13.3,
        maxOverburdenM: 210,
        crossSectionSqM: 80,
        isBaseTunnel: true,
        costEurMillion: 1150
      }
    ],
    bridgeSections: [
      {
        id: 'BRG-11',
        name: 'Filstal High Viaduct',
        startKm: 592,
        endKm: 593.2,
        lengthKm: 1.2,
        heightM: 85,
        spanType: 'VIADUCT',
        costEurMillion: 185
      }
    ],
    tunnelLengthKm: 78.4,
    tunnelPercentage: 7.5,
    bridgeLengthKm: 32.1,
    bridgePercentage: 3.1,
    crossSectionPoints: [],
    headwayMinutes: 3,
    trainsPerHour: 6,
    theoreticalCapacityTph: 16,
    capacityUtilizationPercent: 38,
    capexEurBillion: 26.8,
    annualOpexEurMillion: 390,
    projectedAnnualPaxMillion: 21.5,
    co2AvoidedAnnualTonnes: 2100000,
    estimatedJourneyTimeMinutes: 285,
    countriesTraversed: ['FR', 'DE', 'AT'],
    voltageSwitchCount: 2,
    signalingBoundaries: 2
  },
  {
    id: 'COR-FRA-MIL',
    code: 'ER-C03',
    name: 'Trans-Alpine Axis (Frankfurt–Milan)',
    originId: 'FRA',
    destinationId: 'MIL',
    intermediateStationIds: ['STR', 'ZRH'],
    waypoints: [
      { lat: 50.1109, lng: 8.6821, elevation: 112 }, // Frankfurt
      { lat: 48.7758, lng: 9.1829, elevation: 245 }, // Stuttgart
      { lat: 47.3769, lng: 8.5417, elevation: 408 }, // Zürich HB
      { lat: 46.5900, lng: 8.6700, elevation: 460 }, // Gotthard Base Tunnel North
      { lat: 46.1900, lng: 8.9800, elevation: 230 }, // Gotthard South
      { lat: 45.4642, lng: 9.1900, elevation: 120 }  // Milan Centrale
    ],
    distanceKm: 585,
    designSpeedKmh: 300,
    maxGradientPercent: 2.8,
    minCurveRadiusM: 4800,
    appliedCantMm: 155,
    cantDeficiencyMm: 90,
    trackStructure: 'SLAB_TRACK',
    gaugeMm: 1435,
    signaling: 'ETCS_L2',
    electrification: '25KV_50HZ_AC',
    status: 'OPERATIONAL',
    scenarioId: 'EUR-2040',
    tunnelSections: [
      {
        id: 'TUN-21',
        name: 'Gotthard Base Tunnel Interlink',
        startKm: 420,
        endKm: 477.1,
        lengthKm: 57.1,
        maxOverburdenM: 2450,
        crossSectionSqM: 88,
        isBaseTunnel: true,
        costEurMillion: 11200
      },
      {
        id: 'TUN-22',
        name: 'Ceneri Base Tunnel',
        startKm: 510,
        endKm: 525.4,
        lengthKm: 15.4,
        maxOverburdenM: 850,
        crossSectionSqM: 82,
        isBaseTunnel: true,
        costEurMillion: 2800
      }
    ],
    bridgeSections: [
      {
        id: 'BRG-21',
        name: 'Ticino Valley Viaduct',
        startKm: 532,
        endKm: 535.1,
        lengthKm: 3.1,
        heightM: 52,
        spanType: 'VIADUCT',
        costEurMillion: 240
      }
    ],
    tunnelLengthKm: 98.2,
    tunnelPercentage: 16.8,
    bridgeLengthKm: 22.4,
    bridgePercentage: 3.8,
    crossSectionPoints: [],
    headwayMinutes: 3,
    trainsPerHour: 7,
    theoreticalCapacityTph: 15,
    capacityUtilizationPercent: 47,
    capexEurBillion: 21.2,
    annualOpexEurMillion: 310,
    projectedAnnualPaxMillion: 14.8,
    co2AvoidedAnnualTonnes: 1650000,
    estimatedJourneyTimeMinutes: 182,
    countriesTraversed: ['DE', 'CH', 'IT'],
    voltageSwitchCount: 2,
    signalingBoundaries: 2
  },
  {
    id: 'COR-MAD-PAR',
    code: 'ER-C04',
    name: 'South-Western Corridor (Madrid–Paris)',
    originId: 'MAD',
    destinationId: 'PAR',
    intermediateStationIds: ['BCN', 'LYS'],
    waypoints: [
      { lat: 40.4168, lng: -3.7038, elevation: 650 }, // Madrid Atocha
      { lat: 41.6500, lng: -0.8800, elevation: 200 }, // Zaragoza
      { lat: 41.3851, lng: 2.1734, elevation: 32 },   // Barcelona Sants
      { lat: 42.4500, lng: 3.0000, elevation: 300 },  // Pyrenees Perthus Tunnel
      { lat: 43.6000, lng: 3.8700, elevation: 45 },   // Montpellier
      { lat: 45.7640, lng: 4.8357, elevation: 173 },  // Lyon Part-Dieu
      { lat: 48.8566, lng: 2.3522, elevation: 35 }    // Paris Gare de Lyon
    ],
    distanceKm: 1280,
    designSpeedKmh: 350,
    maxGradientPercent: 3.5,
    minCurveRadiusM: 6500,
    appliedCantMm: 160,
    cantDeficiencyMm: 100,
    trackStructure: 'SLAB_TRACK',
    gaugeMm: 1435,
    signaling: 'ETCS_L2',
    electrification: '25KV_50HZ_AC',
    status: 'OPERATIONAL',
    scenarioId: 'EUR-2040',
    tunnelSections: [
      {
        id: 'TUN-31',
        name: 'Perthus International Base Tunnel',
        startKm: 760,
        endKm: 768.3,
        lengthKm: 8.3,
        maxOverburdenM: 520,
        crossSectionSqM: 80,
        isBaseTunnel: true,
        costEurMillion: 980
      }
    ],
    bridgeSections: [
      {
        id: 'BRG-31',
        name: 'Rhône Crossing Avignon',
        startKm: 990,
        endKm: 991.6,
        lengthKm: 1.6,
        heightM: 35,
        spanType: 'ARCH_STEEL',
        costEurMillion: 140
      }
    ],
    tunnelLengthKm: 42.5,
    tunnelPercentage: 3.3,
    bridgeLengthKm: 28.0,
    bridgePercentage: 2.2,
    crossSectionPoints: [],
    headwayMinutes: 3,
    trainsPerHour: 6,
    theoreticalCapacityTph: 16,
    capacityUtilizationPercent: 38,
    capexEurBillion: 24.5,
    annualOpexEurMillion: 340,
    projectedAnnualPaxMillion: 16.4,
    co2AvoidedAnnualTonnes: 1950000,
    estimatedJourneyTimeMinutes: 345,
    countriesTraversed: ['ES', 'FR'],
    voltageSwitchCount: 1,
    signalingBoundaries: 1
  },
  {
    id: 'COR-BER-PRG-VIE',
    code: 'ER-C05',
    name: 'Central European Core (Berlin–Prague–Vienna)',
    originId: 'BER',
    destinationId: 'VIE',
    intermediateStationIds: ['PRG'],
    waypoints: [
      { lat: 52.5200, lng: 13.4050, elevation: 34 },  // Berlin Hbf
      { lat: 51.0504, lng: 13.7373, elevation: 113 }, // Dresden
      { lat: 50.8500, lng: 13.9800, elevation: 320 }, // Ore Mountains Erzgebirge Base Tunnel
      { lat: 50.0755, lng: 14.4378, elevation: 212 }, // Prague hl.n.
      { lat: 49.1951, lng: 16.6068, elevation: 220 }, // Brno
      { lat: 48.2082, lng: 16.3738, elevation: 190 }  // Vienna Hbf
    ],
    distanceKm: 615,
    designSpeedKmh: 320,
    maxGradientPercent: 2.5,
    minCurveRadiusM: 5500,
    appliedCantMm: 150,
    cantDeficiencyMm: 90,
    trackStructure: 'SLAB_TRACK',
    gaugeMm: 1435,
    signaling: 'ETCS_L2',
    electrification: '25KV_50HZ_AC',
    status: 'PLANNED',
    scenarioId: 'EUR-2040',
    tunnelSections: [
      {
        id: 'TUN-41',
        name: 'Erzgebirge International Base Tunnel',
        startKm: 210,
        endKm: 240.4,
        lengthKm: 30.4,
        maxOverburdenM: 450,
        crossSectionSqM: 84,
        isBaseTunnel: true,
        costEurMillion: 3200
      }
    ],
    bridgeSections: [
      {
        id: 'BRG-41',
        name: 'Elbe Valley Viaduct',
        startKm: 185,
        endKm: 187.2,
        lengthKm: 2.2,
        heightM: 60,
        spanType: 'VIADUCT',
        costEurMillion: 210
      }
    ],
    tunnelLengthKm: 48.2,
    tunnelPercentage: 7.8,
    bridgeLengthKm: 18.5,
    bridgePercentage: 3.0,
    crossSectionPoints: [],
    headwayMinutes: 3,
    trainsPerHour: 5,
    theoreticalCapacityTph: 16,
    capacityUtilizationPercent: 31,
    capexEurBillion: 14.2,
    annualOpexEurMillion: 195,
    projectedAnnualPaxMillion: 12.8,
    co2AvoidedAnnualTonnes: 1100000,
    estimatedJourneyTimeMinutes: 175,
    countriesTraversed: ['DE', 'CZ', 'AT'],
    voltageSwitchCount: 2,
    signalingBoundaries: 2
  },
  {
    id: 'COR-HAM-CPH',
    code: 'ER-C06',
    name: 'Nordic Link (Hamburg–Copenhagen)',
    originId: 'HAM',
    destinationId: 'CPH',
    intermediateStationIds: [],
    waypoints: [
      { lat: 53.5511, lng: 9.9937, elevation: 18 },   // Hamburg Hbf
      { lat: 53.8655, lng: 10.6866, elevation: 20 },  // Lübeck
      { lat: 54.4000, lng: 11.2000, elevation: 15 },  // Puttgarden
      { lat: 54.6000, lng: 11.3500, elevation: 8 },   // Rødbyhavn
      { lat: 55.6761, lng: 12.5683, elevation: 14 }   // Copenhagen H
    ],
    distanceKm: 335,
    designSpeedKmh: 300,
    maxGradientPercent: 2.5,
    minCurveRadiusM: 5000,
    appliedCantMm: 150,
    cantDeficiencyMm: 85,
    trackStructure: 'SLAB_TRACK',
    gaugeMm: 1435,
    signaling: 'ETCS_L2',
    electrification: '25KV_50HZ_AC',
    status: 'UNDER_CONSTRUCTION',
    scenarioId: 'EUR-2040',
    tunnelSections: [
      {
        id: 'TUN-51',
        name: 'Fehmarn Belt Immersed Fixed Link',
        startKm: 145,
        endKm: 162.6,
        lengthKm: 17.6,
        maxOverburdenM: 40,
        crossSectionSqM: 95,
        isBaseTunnel: true,
        costEurMillion: 7400
      }
    ],
    bridgeSections: [
      {
        id: 'BRG-51',
        name: 'Storstrøm Link Viaduct',
        startKm: 215,
        endKm: 218.8,
        lengthKm: 3.8,
        heightM: 26,
        spanType: 'VIADUCT',
        costEurMillion: 380
      }
    ],
    tunnelLengthKm: 22.5,
    tunnelPercentage: 6.7,
    bridgeLengthKm: 9.5,
    bridgePercentage: 2.8,
    crossSectionPoints: [],
    headwayMinutes: 3,
    trainsPerHour: 6,
    theoreticalCapacityTph: 16,
    capacityUtilizationPercent: 37,
    capexEurBillion: 11.8,
    annualOpexEurMillion: 145,
    projectedAnnualPaxMillion: 10.5,
    co2AvoidedAnnualTonnes: 850000,
    estimatedJourneyTimeMinutes: 105,
    countriesTraversed: ['DE', 'DK'],
    voltageSwitchCount: 1,
    signalingBoundaries: 1
  }
];

export const INITIAL_SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'EUR-2040',
    name: 'EUROPE 2040 Core Interlink',
    code: 'SCN-2040',
    targetYear: 2040,
    description: 'Existing upgraded core HSR combined with completed Alpine and Channel fixed links connecting France, Benelux, Germany, Italy, Austria, and Spain.',
    corridorIds: ['COR-LON-FRA', 'COR-PAR-VIE', 'COR-FRA-MIL', 'COR-MAD-PAR', 'COR-BER-PRG-VIE', 'COR-HAM-CPH'],
    demandMultiplier: 1.0,
    carbonTaxEuroPerTonne: 120
  },
  {
    id: 'EUR-2050',
    name: 'EUROPE 2050 Full Inter-Europe HSR',
    code: 'SCN-2050',
    targetYear: 2050,
    description: 'Fully integrated pan-European high-speed rail mesh linking the British Isles, Iberia, Central Europe, the Balkans, and Scandinavia with 350 km/h trunk alignments.',
    corridorIds: ['COR-LON-FRA', 'COR-PAR-VIE', 'COR-FRA-MIL', 'COR-MAD-PAR', 'COR-BER-PRG-VIE', 'COR-HAM-CPH'],
    demandMultiplier: 1.65,
    carbonTaxEuroPerTonne: 250
  },
  {
    id: 'EUR-MAX350',
    name: 'MAXIMUM HSR 350 System',
    code: 'SCN-MAX350',
    targetYear: 2045,
    description: 'High-speed passenger dedicated trunks operating uniformly at 350 km/h with 7000m minimum curve radii and slab track engineering throughout.',
    corridorIds: ['COR-LON-FRA', 'COR-PAR-VIE', 'COR-FRA-MIL', 'COR-MAD-PAR', 'COR-BER-PRG-VIE', 'COR-HAM-CPH'],
    demandMultiplier: 1.35,
    carbonTaxEuroPerTonne: 180
  },
  {
    id: 'EUR-LOWCARBON',
    name: 'LOW-CARBON Modal Axis',
    code: 'SCN-CARBON',
    targetYear: 2038,
    description: 'Optimized for maximum substitution of Europe’s top 50 short-haul aviation corridors under 1000 km, maximizing GHG reduction and EU Green Deal goals.',
    corridorIds: ['COR-LON-FRA', 'COR-PAR-VIE', 'COR-FRA-MIL', 'COR-MAD-PAR'],
    demandMultiplier: 1.25,
    carbonTaxEuroPerTonne: 300
  }
];

export const INITIAL_CONSTRUCTION_PACKAGES: ConstructionPackage[] = [
  {
    id: 'PKG-01',
    corridorId: 'COR-LON-FRA',
    code: 'PKG-LON-C01',
    title: 'London Approach & HS1 Interlink Upgrades',
    scope: 'Four-track grade separation and ETCS L2 baseline 3 signaling integration at St Pancras and Ebbsfleet junctions.',
    startYear: 2026,
    endYear: 2029,
    costEurMillion: 650,
    contractor: 'Balfour Beatty–Vinci JV',
    status: 'IN_PROGRESS',
    progressPercent: 45
  },
  {
    id: 'PKG-02',
    corridorId: 'COR-LON-FRA',
    code: 'PKG-TUN-C02',
    title: 'Channel Tunnel Traction Power & Ventilation Modernization',
    scope: 'Substation upgrades to 350 km/h trainset density and aerodynamic air exchange shaft optimization.',
    startYear: 2027,
    endYear: 2030,
    costEurMillion: 920,
    contractor: 'Eurotunnel Rail Engineering',
    status: 'AWARDED',
    progressPercent: 15
  },
  {
    id: 'PKG-03',
    corridorId: 'COR-LON-FRA',
    code: 'PKG-BEL-C03',
    title: 'Brussels–Aachen High Speed Interconnection (HSL 3)',
    scope: 'Track renewal with Rheda 2000 slab track, sound barriers, and viaduct reinforcement across the Meuse basin.',
    startYear: 2028,
    endYear: 2032,
    costEurMillion: 1450,
    contractor: 'Besix–Eiffage Rail Consortium',
    status: 'TENDER',
    progressPercent: 0
  },
  {
    id: 'PKG-04',
    corridorId: 'COR-HAM-CPH',
    code: 'PKG-FEH-C01',
    title: 'Fehmarn Belt Fixed Link Rail Substructure',
    scope: '18km immersed concrete tunnel elements with twin high-speed rail tubes and 25kV catenary installations.',
    startYear: 2023,
    endYear: 2029,
    costEurMillion: 7400,
    contractor: 'Femern A/S Industrial Consortium',
    status: 'IN_PROGRESS',
    progressPercent: 68
  }
];

export const INITIAL_RISKS: RiskItem[] = [
  {
    id: 'RSK-01',
    corridorId: 'COR-LON-FRA',
    category: 'CROSS_BORDER',
    title: 'Bilateral Border Police & EES Clearance Bottle-necking',
    description: 'Post-Brexit biometric checks at St Pancras and Lille require dedicated segregated platform sterile zones.',
    probability: 4,
    impact: 4,
    riskScore: 16,
    mitigationStrategy: 'Automated biometric e-gates on trains and multi-national juxtaposed border clearance halls.'
  },
  {
    id: 'RSK-02',
    corridorId: 'COR-FRA-MIL',
    category: 'GEOTECHNICAL',
    title: 'Alpine Squeezing Ground & Fault Zone Inrushes',
    description: 'Deep overburden (over 2,000m) in high-pressure crystalline rock causes rockbursts and deformation.',
    probability: 3,
    impact: 5,
    riskScore: 15,
    mitigationStrategy: 'Extensive directional core drilling, heavy steel yielding sets, and drainage exploratory tunnels.'
  },
  {
    id: 'RSK-03',
    corridorId: 'COR-PAR-VIE',
    category: 'FINANCIAL',
    title: 'Multi-National CEF Grant Allocation Disparities',
    description: 'Phased funding delays between French SNCF Réseau, DB InfraGO, and Austrian ÖBB cross-border segments.',
    probability: 3,
    impact: 4,
    riskScore: 12,
    mitigationStrategy: 'Single European Rail Executive Joint Undertaking (SESAR-style EEIG) structure with EU bond pooling.'
  },
  {
    id: 'RSK-04',
    corridorId: 'COR-BER-PRG-VIE',
    category: 'ENVIRONMENTAL',
    title: 'Saxon Switzerland Protected Biosphere Reserve',
    description: 'Environmental opposition regarding the Elbe sandstone valley ecosystem and groundwater impact.',
    probability: 4,
    impact: 3,
    riskScore: 12,
    mitigationStrategy: '30.4 km full-length base tunnel bypassing surface biosphere completely.'
  }
];

export const CROSS_BORDER_CONSTRAINTS: CrossBorderConstraint[] = [
  {
    borderPair: 'France–Germany',
    countryA: 'France',
    countryB: 'Germany',
    voltageA: '25 kV 50 Hz AC (LGV)',
    voltageB: '15 kV 16.7 Hz AC (DB)',
    signalingTransition: 'ETCS Level 2 / TVM430 to PZB / LZB / ETCS L2',
    loadingGaugeDiff: 'UIC GC (3.15m) vs G1 / EBO',
    operatingRulesSync: 'Bilingual driver certification (French/German) or automated ETCS DMI translation'
  },
  {
    borderPair: 'France–Belgium',
    countryA: 'France',
    countryB: 'Belgium',
    voltageA: '25 kV 50 Hz AC',
    voltageB: '25 kV 50 Hz AC (HSL 1)',
    signalingTransition: 'Seamless ETCS Level 2 Handshake (RBC to RBC)',
    loadingGaugeDiff: 'Full UIC GC clearance compatibility',
    operatingRulesSync: 'Harmonized TSI Operating & Traffic Management (OPE TSI)'
  },
  {
    borderPair: 'Germany–Switzerland',
    countryA: 'Germany',
    countryB: 'Switzerland',
    voltageA: '15 kV 16.7 Hz AC',
    voltageB: '15 kV 16.7 Hz AC',
    signalingTransition: 'ETCS Level 2 Baselines 3.4 / 3.6',
    loadingGaugeDiff: 'AB-EBICAB to ETCS Eurobalise transition',
    operatingRulesSync: 'Direct mutual recognition of train drivers under Swiss FOT / German EBA'
  },
  {
    borderPair: 'France–Spain',
    countryA: 'France',
    countryB: 'Spain',
    voltageA: '25 kV 50 Hz AC',
    voltageB: '25 kV 50 Hz AC (LAV)',
    signalingTransition: 'ETCS L2 TPWS/ASFA fallback',
    loadingGaugeDiff: 'Standard 1435mm UIC on HSR (legacy Spanish network is 1668mm Iberian broad gauge)',
    operatingRulesSync: 'Bilateral TP-Ferro concession operations rules'
  }
];
