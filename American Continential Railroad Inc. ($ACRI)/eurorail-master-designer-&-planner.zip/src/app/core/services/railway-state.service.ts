import { Injectable, computed, signal } from '@angular/core';
import {
  CityNode,
  CorridorAlignment,
  TrainsetSpec,
  ScenarioDefinition,
  ConstructionPackage,
  RiskItem,
  CrossBorderConstraint,
  OptimiserWeights,
  OptimisedNetworkVariant,
  TrainSimulationResult,
  TimetableService,
  GeoPoint
} from '../domain/railway.models';
import {
  EUROPEAN_CITIES,
  FLEET_TRAINSETS,
  INITIAL_CORRIDORS,
  INITIAL_SCENARIOS,
  INITIAL_CONSTRUCTION_PACKAGES,
  INITIAL_RISKS,
  CROSS_BORDER_CONSTRAINTS
} from '../data/european-rail-data';
import { GeospatialEngine } from '../geospatial/geospatial-engine';
import { TrainPerformanceSimulator } from '../simulation/train-performance-simulator';
import { TimetableEngine } from '../simulation/timetable-engine';
import { DemandEconomicsEngine, EconomicAppraisal } from '../simulation/demand-economics-engine';
import { NetworkOptimiser } from '../simulation/network-optimiser';

export type MainNavView = 'MAP' | 'ENGINEERING' | 'TIMETABLE' | 'ECONOMICS' | 'REVIEW';

@Injectable({
  providedIn: 'root'
})
export class RailwayStateService {
  // Master Datasets
  public readonly cities = signal<CityNode[]>(EUROPEAN_CITIES);
  public readonly corridors = signal<CorridorAlignment[]>(INITIAL_CORRIDORS);
  public readonly trainsets = signal<TrainsetSpec[]>(FLEET_TRAINSETS);
  public readonly scenarios = signal<ScenarioDefinition[]>(INITIAL_SCENARIOS);
  public readonly constructionPackages = signal<ConstructionPackage[]>(INITIAL_CONSTRUCTION_PACKAGES);
  public readonly riskItems = signal<RiskItem[]>(INITIAL_RISKS);
  public readonly crossBorderConstraints = signal<CrossBorderConstraint[]>(CROSS_BORDER_CONSTRAINTS);

  // Active Selections
  public readonly activeView = signal<MainNavView>('MAP');
  public readonly activeScenarioId = signal<string>('EUR-2040');
  public readonly selectedCorridorId = signal<string>('COR-LON-FRA');
  public readonly selectedStationId = signal<string | null>(null);
  public readonly activeTrainsetId = signal<string>('ER-350');
  public readonly demandScenarioId = signal<string>('BASE');

  // Interactive Map & CAD State
  public readonly isDrawingRoute = signal<boolean>(false);
  public readonly drawnWaypoints = signal<GeoPoint[]>([]);
  public readonly mapLayers = signal({
    topography: true,
    existingHsr: true,
    proposedHsr: true,
    mountainRanges: true,
    freightCorridors: false,
    capacityHeatmap: false,
    stationLabels: true
  });

  // Optimization & Scenario Versioning State
  public readonly optimiserWeights = signal<OptimiserWeights>({
    travelTimeWeight: 30,
    capexWeight: 25,
    demandWeight: 20,
    emissionsWeight: 15,
    connectivityWeight: 10
  });
  public readonly isOptimising = signal<boolean>(false);
  public readonly optimisingProgress = signal<number>(0);
  public readonly optimisingStage = signal<string>('');
  public readonly optimisedVariants = signal<OptimisedNetworkVariant[]>([]);
  public readonly networkVersionCounter = signal<number>(14);

  // UI Modals
  public readonly showCorridorGeneratorModal = signal<boolean>(false);
  public readonly showOptimiserModal = signal<boolean>(false);
  public readonly showStationDesignerModal = signal<boolean>(false);
  public readonly showConstructionGanttModal = signal<boolean>(false);
  public readonly showRiskMatrixModal = signal<boolean>(false);
  public readonly showDossierExportModal = signal<boolean>(false);

  // Computed Derived States
  public readonly activeScenario = computed(() => {
    return this.scenarios().find(s => s.id === this.activeScenarioId()) ?? this.scenarios()[0];
  });

  public readonly activeScenarioCorridors = computed(() => {
    const scn = this.activeScenario();
    return this.corridors().filter(c => scn.corridorIds.includes(c.id));
  });

  public readonly selectedCorridor = computed(() => {
    const cor = this.corridors().find(c => c.id === this.selectedCorridorId());
    if (cor) return cor;
    return this.corridors()[0] ?? null;
  });

  public readonly selectedStation = computed(() => {
    const stId = this.selectedStationId();
    if (!stId) return null;
    return this.cities().find(c => c.id === stId) ?? null;
  });

  public readonly activeTrainset = computed(() => {
    return this.trainsets().find(t => t.id === this.activeTrainsetId()) ?? this.trainsets()[0];
  });

  // Overall Network Aggregate Metrics
  public readonly networkTotalLengthKm = computed(() => {
    return this.activeScenarioCorridors().reduce((sum, c) => sum + c.distanceKm, 0);
  });

  public readonly networkTotalCapexBillion = computed(() => {
    return Number(this.activeScenarioCorridors().reduce((sum, c) => sum + c.capexEurBillion, 0).toFixed(1));
  });

  public readonly networkTotalAnnualPaxMillion = computed(() => {
    return Number(this.activeScenarioCorridors().reduce((sum, c) => sum + c.projectedAnnualPaxMillion, 0).toFixed(1));
  });

  public readonly networkTotalCo2AvoidedMt = computed(() => {
    const tonnes = this.activeScenarioCorridors().reduce((sum, c) => sum + c.co2AvoidedAnnualTonnes, 0);
    return Number((tonnes / 1000000).toFixed(2));
  });

  public readonly networkAverageSpeedKmh = computed(() => {
    const list = this.activeScenarioCorridors();
    if (list.length === 0) return 300;
    return Math.round(list.reduce((sum, c) => sum + c.designSpeedKmh, 0) / list.length);
  });

  // Active Corridor Dynamic Physics Simulation
  public readonly activeSimulation = computed<TrainSimulationResult | null>(() => {
    const cor = this.selectedCorridor();
    const train = this.activeTrainset();
    if (!cor || !train) return null;

    // Ensure longitudinal cross-section points exist
    if (!cor.crossSectionPoints || cor.crossSectionPoints.length === 0) {
      const prof = GeospatialEngine.generateLongitudinalProfile(
        cor.waypoints,
        cor.maxGradientPercent,
        cor.designSpeedKmh
      );
      cor.crossSectionPoints = prof.crossSectionPoints;
      cor.tunnelSections = prof.tunnelSections;
      cor.bridgeSections = prof.bridgeSections;
    }

    return TrainPerformanceSimulator.simulateRun(train, cor);
  });

  // Active Corridor Timetable
  public readonly activeTimetable = computed<TimetableService[]>(() => {
    const cor = this.selectedCorridor();
    const train = this.activeTrainset();
    if (!cor || !train) return [];

    const origin = this.cities().find(c => c.id === cor.originId) ?? this.cities()[0];
    const dest = this.cities().find(c => c.id === cor.destinationId) ?? this.cities()[1];
    const intermediates = cor.intermediateStationIds
      .map(id => this.cities().find(c => c.id === id))
      .filter((c): c is CityNode => !!c);

    return TimetableEngine.generateCorridorTimetable(cor, origin, dest, intermediates, train);
  });

  // Active Corridor Economic Appraisal
  public readonly activeEconomicAppraisal = computed<EconomicAppraisal | null>(() => {
    const cor = this.selectedCorridor();
    if (!cor) return null;
    return DemandEconomicsEngine.calculateEconomicAppraisal(
      cor,
      cor.projectedAnnualPaxMillion,
      75,
      3.5
    );
  });

  constructor() {
    // Initialize cross-sections for initial corridors
    this.initializeCorridorProfiles();
  }

  private initializeCorridorProfiles(): void {
    const list = this.corridors();
    for (const cor of list) {
      if (!cor.crossSectionPoints || cor.crossSectionPoints.length === 0) {
        const { crossSectionPoints, tunnelSections, bridgeSections, totalTunnelKm, totalBridgeKm } =
          GeospatialEngine.generateLongitudinalProfile(
            cor.waypoints,
            cor.maxGradientPercent,
            cor.designSpeedKmh
          );
        cor.crossSectionPoints = crossSectionPoints;
        if (cor.tunnelSections.length === 0) cor.tunnelSections = tunnelSections;
        if (cor.bridgeSections.length === 0) cor.bridgeSections = bridgeSections;
        cor.tunnelLengthKm = totalTunnelKm;
        cor.bridgeLengthKm = totalBridgeKm;
      }
    }
  }

  // Actions
  public selectView(view: MainNavView): void {
    this.activeView.set(view);
  }

  public selectCorridor(id: string): void {
    this.selectedCorridorId.set(id);
    this.selectedStationId.set(null);
  }

  public selectStation(id: string | null): void {
    this.selectedStationId.set(id);
  }

  public selectTrainset(id: string): void {
    this.activeTrainsetId.set(id);
  }

  public selectScenario(id: string): void {
    this.activeScenarioId.set(id);
  }

  public toggleLayer(layerKey: keyof ReturnType<typeof this.mapLayers>): void {
    this.mapLayers.update(layers => ({
      ...layers,
      [layerKey]: !layers[layerKey]
    }));
  }

  public startDrawingRoute(): void {
    this.isDrawingRoute.set(true);
    this.drawnWaypoints.set([]);
  }

  public addWaypoint(point: GeoPoint): void {
    this.drawnWaypoints.update(pts => [...pts, point]);
  }

  public cancelDrawingRoute(): void {
    this.isDrawingRoute.set(false);
    this.drawnWaypoints.set([]);
  }

  public commitDrawnRoute(name: string, speedKmh: 250 | 300 | 320 | 350 = 320): void {
    const pts = this.drawnWaypoints();
    if (pts.length < 2) return;

    const originPt = pts[0];
    const destPt = pts[pts.length - 1];

    // Find closest cities
    const originCity = this.findClosestCity(originPt);
    const destCity = this.findClosestCity(destPt);

    const { crossSectionPoints, tunnelSections, bridgeSections, totalTunnelKm, totalBridgeKm } =
      GeospatialEngine.generateLongitudinalProfile(pts, 3.5, speedKmh);

    const dist = crossSectionPoints.length > 0
      ? crossSectionPoints[crossSectionPoints.length - 1].distanceKm
      : GeospatialEngine.calculateDistanceKm(originPt, destPt);

    const newId = `COR-${Date.now().toString().slice(-4)}`;
    const newCorridor: CorridorAlignment = {
      id: newId,
      code: `ER-X${this.corridors().length + 1}`,
      name: name || `${originCity.name}–${destCity.name} Custom Corridor`,
      originId: originCity.id,
      destinationId: destCity.id,
      intermediateStationIds: [],
      waypoints: pts,
      distanceKm: Math.round(dist),
      designSpeedKmh: speedKmh,
      maxGradientPercent: 3.5,
      minCurveRadiusM: 6500,
      appliedCantMm: 155,
      cantDeficiencyMm: 95,
      trackStructure: 'SLAB_TRACK',
      gaugeMm: 1435,
      signaling: 'ETCS_L2',
      electrification: '25KV_50HZ_AC',
      status: 'PROPOSED',
      scenarioId: this.activeScenarioId(),
      tunnelSections,
      bridgeSections,
      tunnelLengthKm: totalTunnelKm,
      tunnelPercentage: dist > 0 ? Number(((totalTunnelKm / dist) * 100).toFixed(1)) : 0,
      bridgeLengthKm: totalBridgeKm,
      bridgePercentage: dist > 0 ? Number(((totalBridgeKm / dist) * 100).toFixed(1)) : 0,
      crossSectionPoints,
      headwayMinutes: 3,
      trainsPerHour: 6,
      theoreticalCapacityTph: 16,
      capacityUtilizationPercent: 38,
      capexEurBillion: Number(((dist * 24 + totalTunnelKm * 35) / 1000).toFixed(2)),
      annualOpexEurMillion: Math.round(dist * 0.28),
      projectedAnnualPaxMillion: 12.5,
      co2AvoidedAnnualTonnes: Math.round(dist * 12.5 * 170),
      estimatedJourneyTimeMinutes: Math.round((dist / (speedKmh * 0.85)) * 60),
      countriesTraversed: [originCity.countryCode, destCity.countryCode],
      voltageSwitchCount: 1,
      signalingBoundaries: 1
    };

    this.corridors.update(list => [...list, newCorridor]);
    // Add to active scenario
    this.scenarios.update(scns =>
      scns.map(s => (s.id === this.activeScenarioId() ? { ...s, corridorIds: [...s.corridorIds, newId] } : s))
    );
    this.selectedCorridorId.set(newId);
    this.cancelDrawingRoute();
  }

  public addGeneratedCorridor(corridor: CorridorAlignment): void {
    this.corridors.update(list => [...list, corridor]);
    this.scenarios.update(scns =>
      scns.map(s => (s.id === this.activeScenarioId() ? { ...s, corridorIds: [...s.corridorIds, corridor.id] } : s))
    );
    this.selectedCorridorId.set(corridor.id);
  }

  public updateCorridorStatus(corridorId: string, status: CorridorAlignment['status']): void {
    this.corridors.update(list =>
      list.map(c => (c.id === corridorId ? { ...c, status } : c))
    );
  }

  public updateCorridorSpeed(corridorId: string, speedKmh: 250 | 300 | 320 | 350): void {
    this.corridors.update(list =>
      list.map(c => {
        if (c.id !== corridorId) return c;
        const estMins = Math.round((c.distanceKm / (speedKmh * 0.85)) * 60);
        return {
          ...c,
          designSpeedKmh: speedKmh,
          estimatedJourneyTimeMinutes: estMins
        };
      })
    );
  }

  public updateCorridorFrequency(corridorId: string, tph: number): void {
    this.corridors.update(list =>
      list.map(c => {
        if (c.id !== corridorId) return c;
        const util = Math.round((tph / c.theoreticalCapacityTph) * 100);
        return {
          ...c,
          trainsPerHour: tph,
          capacityUtilizationPercent: util
        };
      })
    );
  }

  public async triggerNetworkOptimisation(): Promise<void> {
    this.isOptimising.set(true);
    const ver = this.networkVersionCounter() + 1;
    this.networkVersionCounter.set(ver);

    try {
      const result = await NetworkOptimiser.runOptimisation(
        this.activeScenarioCorridors(),
        this.optimiserWeights(),
        ver,
        feedback => {
          this.optimisingProgress.set(feedback.percentage);
          this.optimisingStage.set(`${feedback.stageName} (${feedback.percentage}%)`);
        }
      );

      this.optimisedVariants.update(vars => [result, ...vars]);
    } finally {
      this.isOptimising.set(false);
      this.optimisingProgress.set(100);
    }
  }

  public exportNetworkGeoJson(): string {
    const geoObj = GeospatialEngine.exportToGeoJson(
      this.activeScenarioCorridors(),
      this.cities()
    );
    return JSON.stringify(geoObj, null, 2);
  }

  public exportNetworkCsv(): string {
    const cors = this.activeScenarioCorridors();
    const headers = [
      'Corridor Code',
      'Name',
      'Origin',
      'Destination',
      'Distance (km)',
      'Design Speed (km/h)',
      'Tunnel %',
      'Bridge %',
      'Capacity (tph)',
      'CAPEX (EUR B)',
      'Annual Pax (M)',
      'Status'
    ];
    const rows = cors.map(c => [
      c.code,
      `"${c.name}"`,
      c.originId,
      c.destinationId,
      c.distanceKm,
      c.designSpeedKmh,
      c.tunnelPercentage,
      c.bridgePercentage,
      c.trainsPerHour,
      c.capexEurBillion,
      c.projectedAnnualPaxMillion,
      c.status
    ]);
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  private findClosestCity(point: GeoPoint): CityNode {
    let closest = this.cities()[0];
    let minDist = Infinity;
    for (const city of this.cities()) {
      const d = GeospatialEngine.calculateDistanceKm(point, city);
      if (d < minDist) {
        minDist = d;
        closest = city;
      }
    }
    return closest;
  }
}
