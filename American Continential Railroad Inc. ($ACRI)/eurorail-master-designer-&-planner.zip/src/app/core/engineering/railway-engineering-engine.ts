import { SignalingType, ElectrificationSystem } from '../domain/railway.models';

export interface CurveCantAnalysis {
  designSpeedKmh: number;
  appliedCantMm: number;
  cantDeficiencyMm: number;
  minCurveRadiusM: number;
  equilibriumSpeedKmh: number;
  cantDeficiencyAccelerationMPerS2: number;
  tsiCompliance: boolean;
  notes: string;
}

export interface ElectrificationDemand {
  system: ElectrificationSystem;
  nominalVoltageKv: number;
  frequencyHz: number;
  catenarySubstationSpacingKm: number;
  peakCurrentAmperesPerTrain: number;
  totalSubstationPowerDemandMw: number;
  catenaryLossPercentage: number;
  substationsRequiredCount: number;
}

export class RailwayEngineeringEngine {
  /**
   * Calculates minimum horizontal curve radius based on European TSI High-Speed standard:
   * R_min = V^2 / (11.8 * (h_act + h_def))
   * h_act: actual applied cant on outer rail (mm)
   * h_def: cant deficiency (mm)
   */
  public static calculateCurveCantLimits(
    speedKmh: number,
    appliedCantMm = 150,
    cantDeficiencyMm = 90
  ): CurveCantAnalysis {
    // Standard gauge high speed track constant: 11.8 = 3.6^2 * s / g where s = 1435mm / 1500mm contact
    const totalCantAllowance = appliedCantMm + cantDeficiencyMm;
    const minRadiusM = Math.round(Math.pow(speedKmh, 2) / (11.8 * totalCantAllowance * 0.001 * 9.81 * 0.1));

    // Equilibrium speed where centrifugal force perfectly balances gravity component:
    // V_eq = sqrt(11.8 * h_act * R)
    const eqSpeedKmh = Math.round(Math.sqrt(11.8 * appliedCantMm * 0.001 * 9.81 * 0.1 * minRadiusM));

    // Lateral acceleration felt by passenger: a_lat = (cantDeficiency / track_gauge) * g
    const latAccel = Number(((cantDeficiencyMm / 1500) * 9.81).toFixed(2));

    const tsiCompliance = appliedCantMm <= 160 && cantDeficiencyMm <= 100 && latAccel <= 0.85;

    let notes = 'Meets TSI High-Speed (ENE/INF TSI) standards for high passenger comfort.';
    if (speedKmh >= 350) {
      notes = 'Extreme speed regime: requires continuous slab track (Rheda 2000 / Porr) to maintain 7,000m curve geometry without ballast flight.';
    } else if (appliedCantMm > 160) {
      notes = 'Warning: Applied cant exceeds TSI maximum of 160 mm. Risk of slow freight train inner-rail overturning.';
    }

    return {
      designSpeedKmh: speedKmh,
      appliedCantMm,
      cantDeficiencyMm,
      minCurveRadiusM: Math.max(4000, minRadiusM),
      equilibriumSpeedKmh: eqSpeedKmh,
      cantDeficiencyAccelerationMPerS2: latAccel,
      tsiCompliance,
      notes
    };
  }

  /**
   * Calculates high-voltage traction power grid requirements and substation spacing
   */
  public static calculateElectrificationDemand(
    corridorLengthKm: number,
    electrification: ElectrificationSystem,
    peakTrainCount = 8,
    trainPowerKw = 16000
  ): ElectrificationDemand {
    let nominalVoltageKv = 25;
    let frequencyHz = 50;
    let spacingKm = 45;
    let lossPct = 3.8;

    switch (electrification) {
      case '25KV_50HZ_AC':
        nominalVoltageKv = 25;
        frequencyHz = 50;
        spacingKm = 48;
        lossPct = 3.5;
        break;
      case '15KV_16_7HZ_AC':
        nominalVoltageKv = 15;
        frequencyHz = 16.7;
        spacingKm = 24;
        lossPct = 5.8;
        break;
      case '3KV_DC':
        nominalVoltageKv = 3;
        frequencyHz = 0;
        spacingKm = 14;
        lossPct = 12.5;
        break;
      case '1_5KV_DC':
        nominalVoltageKv = 1.5;
        frequencyHz = 0;
        spacingKm = 8;
        lossPct = 18.0;
        break;
    }

    // Peak current demand: I = P / (V * cos_phi) where cos_phi ~ 0.95
    const peakCurrent = Math.round((trainPowerKw * 1000) / (nominalVoltageKv * 1000 * 0.95));
    const substationsCount = Math.max(2, Math.ceil(corridorLengthKm / spacingKm));
    const totalPowerMw = Math.round((trainPowerKw * peakTrainCount * 0.75) / 1000);

    return {
      system: electrification,
      nominalVoltageKv,
      frequencyHz,
      catenarySubstationSpacingKm: spacingKm,
      peakCurrentAmperesPerTrain: peakCurrent,
      totalSubstationPowerDemandMw: totalPowerMw,
      catenaryLossPercentage: lossPct,
      substationsRequiredCount: substationsCount
    };
  }

  /**
   * Evaluates signaling capacity and minimum theoretical headway
   */
  public static calculateSignalingCapacity(
    signaling: SignalingType,
    speedKmh = 320
  ): {
    minHeadwaySeconds: number;
    theoreticalCapacityTph: number;
    recommendedPracticalTph: number;
    safetyOverheadSeconds: number;
    brakingDistanceMeters: number;
  } {
    let minHeadwaySec = 180; // 3 min standard ETCS L2
    let safetySec = 30;

    if (signaling === 'ETCS_L3_MOVING_BLOCK') {
      minHeadwaySec = 120; // 2 min moving block
      safetySec = 20;
    } else if (signaling === 'CONVENTIONAL_FALLBACK') {
      minHeadwaySec = 300; // 5 min fixed line-side block
      safetySec = 60;
    }

    const theoreticalTph = Math.floor(3600 / minHeadwaySec);
    const practicalTph = Math.floor(3600 / (minHeadwaySec + safetySec));
    // Supervised braking distance d = v^2 / (2 * b) where b ~ 0.75 m/s^2
    const vMPerS = speedKmh / 3.6;
    const brakingDist = Math.round((vMPerS * vMPerS) / (2 * 0.75));

    return {
      minHeadwaySeconds: minHeadwaySec,
      theoreticalCapacityTph: theoreticalTph,
      recommendedPracticalTph: practicalTph,
      safetyOverheadSeconds: safetySec,
      brakingDistanceMeters: brakingDist
    };
  }
}

