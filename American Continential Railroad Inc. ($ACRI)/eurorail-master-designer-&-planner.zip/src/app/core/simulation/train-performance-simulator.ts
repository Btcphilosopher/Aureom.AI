import { TrainsetSpec, CorridorAlignment, SpeedDistanceStep, TrainSimulationResult } from '../domain/railway.models';

export class TrainPerformanceSimulator {
  private static readonly GRAVITY_ACCEL = 9.81; // m/s^2

  /**
   * Simulates the dynamic run of a trainset along an alignment corridor using
   * the Davis train resistance equation, tractive effort limits, gradient force,
   * curve resistance, and ETCS Level 2 braking supervised deceleration curves.
   */
  public static simulateRun(
    train: TrainsetSpec,
    corridor: CorridorAlignment,
    stepDistanceKm = 0.5
  ): TrainSimulationResult {
    const totalDistKm = corridor.distanceKm;
    const maxTrackSpeed = corridor.designSpeedKmh;
    const trainMaxSpeed = train.maxSpeedKmh;
    const governedMaxSpeedKmh = Math.min(maxTrackSpeed, trainMaxSpeed);

    const steps: SpeedDistanceStep[] = [];
    const massKg = train.loadedMassTonnes * 1000;
    const maxPowerWatts = train.tractionPowerKw * 1000;

    let currentDistanceKm = 0;
    let currentSpeedMPerS = 0; // m/s
    let currentTimeSeconds = 0;
    let cumulativeEnergyJoules = 0;
    let recoveredEnergyJoules = 0;

    // Station stops chainage (origin at 0, destination at totalDistKm, plus intermediate stops)
    const stopLocationsKm: number[] = [0];
    if (corridor.intermediateStationIds && corridor.intermediateStationIds.length > 0) {
      const segLen = totalDistKm / (corridor.intermediateStationIds.length + 1);
      for (let s = 1; s <= corridor.intermediateStationIds.length; s++) {
        stopLocationsKm.push(Math.round(s * segLen));
      }
    }
    stopLocationsKm.push(totalDistKm);

    // Initial step at station
    steps.push({
      distanceKm: 0,
      speedKmh: 0,
      timeSeconds: 0,
      tractiveForceKn: 0,
      energyKwh: 0,
      accelerationMPerS2: 0,
      gradientPercent: 0
    });

    while (currentDistanceKm < totalDistKm) {
      const nextDistanceKm = Math.min(totalDistKm, currentDistanceKm + stepDistanceKm);
      const ds = (nextDistanceKm - currentDistanceKm) * 1000; // meters

      // Check distance to next required stop
      const nextStopKm = stopLocationsKm.find(st => st > currentDistanceKm) ?? totalDistKm;
      const distToStopM = (nextStopKm - currentDistanceKm) * 1000;

      // ETCS Level 2 supervised deceleration curve to stop: v_target = sqrt(2 * b * d)
      const serviceDecel = train.serviceDecelerationMPerS2; // ~0.75 m/s^2
      const etcsBrakingCeilingMPerS = Math.sqrt(2 * serviceDecel * Math.max(0, distToStopM - 50));

      // Local gradient from cross section
      const crossPoint = corridor.crossSectionPoints.find(
        p => Math.abs(p.distanceKm - currentDistanceKm) <= stepDistanceKm
      );
      const gradientPercent = crossPoint?.gradientPercent ?? 0; // in %
      const isTunnel = crossPoint?.isTunnel ?? false;

      // Speed limit target for this section
      const sectionSpeedLimitKmh = (isTunnel && governedMaxSpeedKmh > 300)
        ? 300
        : governedMaxSpeedKmh;
      const sectionSpeedLimitMPerS = sectionSpeedLimitKmh / 3.6;

      const targetSpeedMPerS = Math.min(sectionSpeedLimitMPerS, etcsBrakingCeilingMPerS);

      // Davis resistance: R = A + B*v + C*v^2 (with tunnel aerodynamic drag penalty +25%)
      const vKmh = currentSpeedMPerS * 3.6;
      const tunnelAerodynamicFactor = isTunnel ? 1.25 : 1.0;
      const davisResistanceKn =
        train.davisA +
        train.davisB * vKmh +
        train.davisC * tunnelAerodynamicFactor * Math.pow(vKmh, 2);
      const davisResistanceNewtons = davisResistanceKn * 1000;

      // Gradient resistance: F_g = m * g * sin(theta) ~ m * g * (i / 100)
      const gradientResistanceNewtons = massKg * this.GRAVITY_ACCEL * (gradientPercent / 100);

      // Curve resistance: Röckl formula F_c = 700 * m * g / R
      const curveResistanceNewtons = (700 * massKg * this.GRAVITY_ACCEL) / (corridor.minCurveRadiusM || 5500);

      const totalPassiveResistanceNewtons =
        davisResistanceNewtons + gradientResistanceNewtons + curveResistanceNewtons;

      let tractiveForceNewtons = 0;
      let accelMPerS2 = 0;

      if (currentSpeedMPerS < targetSpeedMPerS - 0.2) {
        // Accelerating
        // Available tractive effort: F = min(F_max, P / v)
        const startingForceNewtons = massKg * train.startingAccelerationMPerS2;
        const speedForPowerCalc = Math.max(8.0, currentSpeedMPerS); // avoid division by zero
        const powerLimitedForceNewtons = maxPowerWatts / speedForPowerCalc;

        tractiveForceNewtons = Math.min(startingForceNewtons, powerLimitedForceNewtons);
        const netForceNewtons = tractiveForceNewtons - totalPassiveResistanceNewtons;
        accelMPerS2 = Math.min(train.startingAccelerationMPerS2, netForceNewtons / massKg);

        // Power consumed in this step (Watts * dt)
        const vAvg = currentSpeedMPerS + (accelMPerS2 * 0.5);
        const dt = accelMPerS2 > 0 ? (Math.sqrt(Math.max(0, currentSpeedMPerS * currentSpeedMPerS + 2 * accelMPerS2 * ds)) - currentSpeedMPerS) / accelMPerS2 : ds / Math.max(1, vAvg);
        cumulativeEnergyJoules += tractiveForceNewtons * ds;
        currentTimeSeconds += dt;
        currentSpeedMPerS = Math.min(targetSpeedMPerS, Math.sqrt(Math.max(0, currentSpeedMPerS * currentSpeedMPerS + 2 * accelMPerS2 * ds)));
      } else if (currentSpeedMPerS > targetSpeedMPerS + 0.2) {
        // Decelerating under ETCS L2 curve
        accelMPerS2 = -serviceDecel;
        const newSpeedSq = currentSpeedMPerS * currentSpeedMPerS + 2 * accelMPerS2 * ds;
        const newSpeedMPerS = Math.max(0, Math.sqrt(Math.max(0, newSpeedSq)));
        const vAvg = (currentSpeedMPerS + newSpeedMPerS) / 2;
        const dt = ds / Math.max(1, vAvg);

        // Regenerative braking: kinetic energy recovered
        const deltaEkJoules = 0.5 * massKg * (Math.pow(currentSpeedMPerS, 2) - Math.pow(newSpeedMPerS, 2));
        if (deltaEkJoules > 0) {
          recoveredEnergyJoules += deltaEkJoules * train.regenerativeBrakingEfficiency;
        }

        currentTimeSeconds += dt;
        currentSpeedMPerS = newSpeedMPerS;
        tractiveForceNewtons = 0;
      } else {
        // Cruising at target speed
        accelMPerS2 = 0;
        tractiveForceNewtons = Math.max(0, totalPassiveResistanceNewtons);
        const dt = ds / Math.max(1, currentSpeedMPerS);
        cumulativeEnergyJoules += tractiveForceNewtons * ds;
        currentTimeSeconds += dt;
      }

      currentDistanceKm = nextDistanceKm;

      // If at intermediate stop, add dwell time (2.5 minutes)
      const isAtStop = stopLocationsKm.some(st => Math.abs(st - currentDistanceKm) < 0.2 && st > 0 && st < totalDistKm);
      if (isAtStop && currentSpeedMPerS < 5) {
        currentTimeSeconds += 150; // 2.5 min dwell
        currentSpeedMPerS = 0;
      }

      steps.push({
        distanceKm: Number(currentDistanceKm.toFixed(2)),
        speedKmh: Math.round(currentSpeedMPerS * 3.6),
        timeSeconds: Math.round(currentTimeSeconds),
        tractiveForceKn: Number((tractiveForceNewtons / 1000).toFixed(1)),
        energyKwh: Number(((cumulativeEnergyJoules - recoveredEnergyJoules) / 3600000).toFixed(1)),
        accelerationMPerS2: Number(accelMPerS2.toFixed(3)),
        gradientPercent
      });
    }

    const totalEnergyKwh = Math.round(cumulativeEnergyJoules / 3600000);
    const recoveredKwh = Math.round(recoveredEnergyJoules / 3600000);
    const netEnergyKwh = totalEnergyKwh - recoveredKwh;
    const totalJourneyMinutes = Math.round(currentTimeSeconds / 60);

    const passengerKm = corridor.distanceKm * train.passengerCapacity;
    const energyPerPaxKmWh = passengerKm > 0 ? Number(((netEnergyKwh * 1000) / passengerKm).toFixed(1)) : 0;
    const avgSpeedKmh = totalJourneyMinutes > 0 ? Math.round((corridor.distanceKm / (totalJourneyMinutes / 60))) : 0;
    const maxSpeedReached = Math.max(...steps.map(s => s.speedKmh));

    return {
      corridorId: corridor.id,
      trainsetId: train.id,
      journeyTimeMinutes: totalJourneyMinutes,
      averageSpeedKmh: avgSpeedKmh,
      topSpeedReachedKmh: maxSpeedReached,
      totalEnergyConsumptionKwh: totalEnergyKwh,
      energyRecoveredKwh: recoveredKwh,
      netEnergyConsumptionKwh: netEnergyKwh,
      energyPerPassengerKmWh: energyPerPaxKmWh,
      speedProfile: steps
    };
  }
}
