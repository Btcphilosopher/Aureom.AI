import { TimetableService, TimetableStop, CorridorAlignment, CityNode, TrainsetSpec } from '../domain/railway.models';

export interface MareyDiagramPath {
  serviceId: string;
  serviceNumber: string;
  color: string;
  points: { timeMinutes: number; distanceKm: number; stationName: string }[];
}

export class TimetableEngine {
  /**
   * Generates a realistic high-speed operating timetable along a corridor
   */
  public static generateCorridorTimetable(
    corridor: CorridorAlignment,
    originCity: CityNode,
    destCity: CityNode,
    intermediateCities: CityNode[],
    train: TrainsetSpec,
    startHour = 6,
    endHour = 22,
    frequencyMinutes = 60
  ): TimetableService[] {
    const services: TimetableService[] = [];
    const stations = [originCity, ...intermediateCities, destCity];
    const totalDist = corridor.distanceKm;

    // Intermediate stop distances
    const stationDistances: number[] = [0];
    if (intermediateCities.length > 0) {
      const step = totalDist / (intermediateCities.length + 1);
      for (let i = 1; i <= intermediateCities.length; i++) {
        stationDistances.push(Math.round(i * step));
      }
    }
    stationDistances.push(totalDist);

    // Speed calculation
    const avgSpeed = corridor.designSpeedKmh * 0.85;
    let serviceCounter = 101;

    for (let currentMinute = startHour * 60; currentMinute <= endHour * 60; currentMinute += frequencyMinutes) {
      const hh = Math.floor(currentMinute / 60).toString().padStart(2, '0');
      const mm = (currentMinute % 60).toString().padStart(2, '0');
      const depTimeStr = `${hh}:${mm}`;

      let runningTime = currentMinute;
      const stops: TimetableStop[] = [];

      for (let s = 0; s < stations.length; s++) {
        const dist = stationDistances[s];
        const isOrigin = s === 0;
        const isDestination = s === stations.length - 1;

        if (!isOrigin) {
          const segDist = dist - stationDistances[s - 1];
          const travelMins = Math.round((segDist / avgSpeed) * 60);
          runningTime += travelMins;
        }

        const dwell = isOrigin || isDestination ? 0 : 3; // 3 min dwell at intermediate hubs
        const arrTime = isOrigin ? runningTime : runningTime;
        const depTime = isDestination ? runningTime : runningTime + dwell;
        runningTime = depTime;

        stops.push({
          stationId: stations[s].id,
          stationName: stations[s].name,
          distanceKm: dist,
          arrivalTimeMinutes: arrTime,
          departureTimeMinutes: depTime,
          dwellTimeMinutes: dwell,
          platform: `P${(s % 4) + 1}`
        });
      }

      const totalJourneyMinutes = runningTime - currentMinute;

      services.push({
        id: `SVC-${serviceCounter}`,
        serviceNumber: `ER ${serviceCounter}`,
        corridorId: corridor.id,
        trainsetId: train.id,
        departureTime: depTimeStr,
        departureMinutes: currentMinute,
        stops,
        totalJourneyMinutes,
        frequencyPerHour: Math.round(60 / frequencyMinutes),
        conflicts: []
      });

      serviceCounter += 2;
    }

    // Check conflicts between consecutive services
    this.detectTimetableConflicts(services, corridor.headwayMinutes);

    return services;
  }

  /**
   * Scans timetable for minimum headway infractions and platform collision
   */
  public static detectTimetableConflicts(services: TimetableService[], minHeadwayMinutes = 3): void {
    for (let i = 0; i < services.length; i++) {
      for (let j = i + 1; j < services.length; j++) {
        const s1 = services[i];
        const s2 = services[j];

        // Check headway at each common stop
        for (const st1 of s1.stops) {
          const st2 = s2.stops.find(s => s.stationId === st1.stationId);
          if (st2) {
            const timeDiff = Math.abs(st1.departureTimeMinutes - st2.departureTimeMinutes);
            if (timeDiff < minHeadwayMinutes && timeDiff > 0) {
              const conflictMsg = `Headway violation at ${st1.stationName}: ${timeDiff}m < min ${minHeadwayMinutes}m`;
              s1.conflicts.push(conflictMsg);
              s2.conflicts.push(conflictMsg);
            }
          }
        }
      }
    }
  }

  /**
   * Generates polyline paths for the graphical Marey / Stringline Diagram
   */
  public static generateMareyDiagramPaths(services: TimetableService[]): MareyDiagramPath[] {
    const palette = ['#2563eb', '#38bdf8', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];

    return services.map((s, idx) => {
      const points: { timeMinutes: number; distanceKm: number; stationName: string }[] = [];

      for (const stop of s.stops) {
        if (stop.dwellTimeMinutes > 0) {
          // Point at arrival
          points.push({
            timeMinutes: stop.arrivalTimeMinutes,
            distanceKm: stop.distanceKm,
            stationName: stop.stationName
          });
          // Point at departure
          points.push({
            timeMinutes: stop.departureTimeMinutes,
            distanceKm: stop.distanceKm,
            stationName: stop.stationName
          });
        } else {
          points.push({
            timeMinutes: stop.departureTimeMinutes,
            distanceKm: stop.distanceKm,
            stationName: stop.stationName
          });
        }
      }

      return {
        serviceId: s.id,
        serviceNumber: s.serviceNumber,
        color: palette[idx % palette.length],
        points
      };
    });
  }
}
