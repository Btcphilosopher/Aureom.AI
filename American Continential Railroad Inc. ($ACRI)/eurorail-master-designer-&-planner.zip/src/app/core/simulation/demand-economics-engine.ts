import { CityNode, CorridorAlignment } from '../domain/railway.models';

export interface DemandScenario {
  id: string;
  name: string;
  multiplier: number;
  aviationShiftFactor: number; // e.g. 0.65 (65% of short-haul flights shift to HSR for trips under 3.5h)
  carShiftFactor: number;      // e.g. 0.25
  inducedDemandFactor: number; // e.g. 0.15
}

export interface DemandResult {
  originCity: string;
  destinationCity: string;
  distanceKm: number;
  journeyTimeMinutes: number;
  annualTotalPassengersMillion: number;
  airDivertedPaxMillion: number;
  carDivertedPaxMillion: number;
  inducedPaxMillion: number;
  ticketRevenueEurMillion: number;
}

export interface EconomicAppraisal {
  totalCapexBillionEur: number;
  capexCivilBillionEur: number;
  capexTunnelsBillionEur: number;
  capexViaductsBillionEur: number;
  capexSystemsBillionEur: number;
  capexStationsBillionEur: number;
  annualOpexMillionEur: number;
  annualRevenueMillionEur: number;
  annualEbitdaMillionEur: number;
  discountRatePercent: number;
  npv30YearBillionEur: number;
  irrPercent: number;
  paybackPeriodYears: number;
  costPerPassengerKmEur: number;
  annualCo2AvoidedTonnes: number;
  financingMix: {
    euCefGrantsPercent: number;
    eibGreenBondsPercent: number;
    nationalTreasuryPercent: number;
    privatePppConcessionPercent: number;
  };
}

export class DemandEconomicsEngine {
  public static readonly SCENARIOS: DemandScenario[] = [
    { id: 'BASE', name: 'Base Scenario (Current Trends)', multiplier: 1.0, aviationShiftFactor: 0.50, carShiftFactor: 0.18, inducedDemandFactor: 0.10 },
    { id: 'HIGH_GROWTH', name: 'High Economic Growth (+2.5% GDP)', multiplier: 1.35, aviationShiftFactor: 0.65, carShiftFactor: 0.25, inducedDemandFactor: 0.18 },
    { id: 'LOW_GROWTH', name: 'Conservative Fiscal / Low Growth', multiplier: 0.85, aviationShiftFactor: 0.40, carShiftFactor: 0.12, inducedDemandFactor: 0.05 },
    { id: 'CAR_SHIFT', name: 'Highway Decarbonisation & Fuel Tax', multiplier: 1.20, aviationShiftFactor: 0.50, carShiftFactor: 0.40, inducedDemandFactor: 0.12 },
    { id: 'AIR_TO_RAIL', name: 'EU Ban on Short-Haul Flights <3h', multiplier: 1.45, aviationShiftFactor: 0.85, carShiftFactor: 0.20, inducedDemandFactor: 0.15 }
  ];

  /**
   * Gravity Model for Inter-city High-Speed Rail Passenger Demand
   * T_ij = k * (P_i * P_j)^0.45 * (GDP_i * GDP_j)^0.25 / (d_ij^0.8 * t_ij^0.9)
   */
  public static calculatePassengerDemand(
    origin: CityNode,
    destination: CityNode,
    distanceKm: number,
    journeyTimeMinutes: number,
    scenarioId = 'BASE'
  ): DemandResult {
    const scenario = this.SCENARIOS.find(s => s.id === scenarioId) ?? this.SCENARIOS[0];

    // Population in millions
    const pop1 = origin.population / 1000000;
    const pop2 = destination.population / 1000000;

    // Combined economic gravity
    const gdp1 = origin.gdpBillionEur;
    const gdp2 = destination.gdpBillionEur;

    // Time impedance: high speed rail market share drops sharply above 4 hours (240 min)
    const timeHours = Math.max(0.75, journeyTimeMinutes / 60);
    const impedance = Math.pow(timeHours, 1.45);

    const baseGravity = 1.85 * (Math.pow(pop1 * pop2, 0.48) * Math.pow((gdp1 * gdp2) / 10000, 0.22)) / impedance;

    // Airport substitution pool
    const combinedAirportPax = (origin.annualAirportPaxMillion + destination.annualAirportPaxMillion) * 0.12;
    const airModalShare = timeHours <= 3.0 ? scenario.aviationShiftFactor * 0.75 : Math.max(0.1, scenario.aviationShiftFactor * (4.5 - timeHours) / 3.0);
    const airDiverted = combinedAirportPax * airModalShare;

    const carDiverted = baseGravity * scenario.carShiftFactor;
    const inducedPax = baseGravity * scenario.inducedDemandFactor;

    const totalAnnualPaxMillion = Number(
      ((baseGravity + airDiverted + carDiverted + inducedPax) * scenario.multiplier).toFixed(2)
    );

    // Yield: average €0.12 per passenger-km
    const avgFare = Math.round(distanceKm * 0.12);
    const annualRevenueEurMillion = Math.round(totalAnnualPaxMillion * avgFare);

    return {
      originCity: origin.name,
      destinationCity: destination.name,
      distanceKm,
      journeyTimeMinutes,
      annualTotalPassengersMillion: Math.max(1.5, totalAnnualPaxMillion),
      airDivertedPaxMillion: Number(airDiverted.toFixed(2)),
      carDivertedPaxMillion: Number(carDiverted.toFixed(2)),
      inducedPaxMillion: Number(inducedPax.toFixed(2)),
      ticketRevenueEurMillion: annualRevenueEurMillion
    };
  }

  /**
   * Detailed Infrastructure Economics (CAPEX, OPEX, NPV, IRR, and Carbon Avoided)
   */
  public static calculateEconomicAppraisal(
    corridor: CorridorAlignment,
    annualPaxMillion: number,
    ticketPriceEur = 75,
    discountRatePercent = 3.5
  ): EconomicAppraisal {
    const dist = corridor.distanceKm;
    const tunnelDist = corridor.tunnelLengthKm;
    const bridgeDist = corridor.bridgeLengthKm;
    const surfaceDist = Math.max(0, dist - tunnelDist - bridgeDist);

    // CAPEX items
    const capexCivil = (surfaceDist * 21.0) / 1000; // €21M/km
    const capexTunnels = (tunnelDist * 58.0) / 1000; // €58M/km average
    const capexViaducts = (bridgeDist * 42.0) / 1000; // €42M/km
    const capexSystems = (dist * 5.8) / 1000; // Electrification + ETCS L2
    const stationsCount = (corridor.intermediateStationIds?.length ?? 0) + 2;
    const capexStations = (stationsCount * 220) / 1000; // Hub terminals

    const rawCapexBillion = capexCivil + capexTunnels + capexViaducts + capexSystems + capexStations;
    const contingencyBillion = rawCapexBillion * 0.15;
    const totalCapexBillion = Number((rawCapexBillion + contingencyBillion).toFixed(2));

    // Annual OPEX (Track maintenance €140k/km, Traction energy, operations)
    const annualTrackMaint = (dist * 0.14); // €M
    const annualEnergy = (annualPaxMillion * dist * 0.028 * 0.14); // €M
    const annualOps = (dist * corridor.trainsPerHour * 18 * 365 * 0.0035); // €M
    const totalOpexMillion = Number((annualTrackMaint + annualEnergy + annualOps + 45).toFixed(1));

    // Annual Gross Revenue
    const annualRevenueMillion = Number((annualPaxMillion * ticketPriceEur).toFixed(1));
    const annualEbitdaMillion = Number((annualRevenueMillion - totalOpexMillion).toFixed(1));

    // Discounted Cash Flow over 30 years
    const r = discountRatePercent / 100;
    let npvMillion = -totalCapexBillion * 1000;
    for (let yr = 1; yr <= 30; yr++) {
      npvMillion += annualEbitdaMillion / Math.pow(1 + r, yr);
    }
    const npvBillion = Number((npvMillion / 1000).toFixed(2));

    // Payback period
    const paybackYears = annualEbitdaMillion > 0
      ? Number(((totalCapexBillion * 1000) / annualEbitdaMillion).toFixed(1))
      : 99;

    // Approximate IRR
    let irr = 0.04;
    if (annualEbitdaMillion > 0) {
      irr = Math.min(0.18, Math.max(0.01, (annualEbitdaMillion / (totalCapexBillion * 1000)) * 0.85));
    }

    // Cost per passenger-km (€/pax-km over 30 years)
    const totalPaxKmBillion = (annualPaxMillion * dist * 30) / 1000;
    const totalLifeCycleCostBillion = totalCapexBillion + (totalOpexMillion * 30) / 1000;
    const costPerPaxKm = totalPaxKmBillion > 0
      ? Number((totalLifeCycleCostBillion / totalPaxKmBillion).toFixed(3))
      : 0.085;

    // Environmental calculation:
    // HSR: 8.5 g CO2/pax-km
    // Avoided air (65%): 215 g CO2/pax-km -> delta 206.5 g
    // Avoided car (35%): 115 g CO2/pax-km -> delta 106.5 g
    // Weighted avg savings: ~170 g CO2 / pax-km
    const annualPaxKm = annualPaxMillion * 1000000 * dist;
    const co2AvoidedTonnes = Math.round((annualPaxKm * 0.000170));

    return {
      totalCapexBillionEur: totalCapexBillion,
      capexCivilBillionEur: Number(capexCivil.toFixed(2)),
      capexTunnelsBillionEur: Number(capexTunnels.toFixed(2)),
      capexViaductsBillionEur: Number(capexViaducts.toFixed(2)),
      capexSystemsBillionEur: Number(capexSystems.toFixed(2)),
      capexStationsBillionEur: Number(capexStations.toFixed(2)),
      annualOpexMillionEur: totalOpexMillion,
      annualRevenueMillionEur: annualRevenueMillion,
      annualEbitdaMillionEur: annualEbitdaMillion,
      discountRatePercent,
      npv30YearBillionEur: npvBillion,
      irrPercent: Number((irr * 100).toFixed(1)),
      paybackPeriodYears: paybackYears,
      costPerPassengerKmEur: costPerPaxKm,
      annualCo2AvoidedTonnes: co2AvoidedTonnes,
      financingMix: {
        euCefGrantsPercent: 25,
        eibGreenBondsPercent: 40,
        nationalTreasuryPercent: 20,
        privatePppConcessionPercent: 15
      }
    };
  }
}
