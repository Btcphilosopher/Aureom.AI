import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';
import { DecimalPipe } from '@angular/common';
import { TimetableEngine } from '../../core/simulation/timetable-engine';
import { RailwayEngineeringEngine } from '../../core/engineering/railway-engineering-engine';

@Component({
  selector: 'app-engineering-drawer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe],
  template: `
    <div
      [class.h-80]="isExpanded()"
      [class.h-10]="!isExpanded()"
      class="w-full bg-[#0b101a] border-t border-[#1e2a40] flex flex-col transition-all duration-200 select-none shrink-0 z-20"
    >
      <!-- Drawer Control Tab Bar -->
      <div class="h-10 px-4 bg-[#0e1422] border-b border-[#1b2538] flex items-center justify-between shrink-0">
        <div class="flex items-center gap-1">
          <button
            type="button"
            (click)="selectTab('PROFILE')"
            [class.bg-[#192338]]="activeTab() === 'PROFILE'"
            [class.text-white]="activeTab() === 'PROFILE'"
            [class.text-slate-400]="activeTab() !== 'PROFILE'"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded hover:text-white transition-colors cursor-pointer"
          >
            <mat-icon class="text-[16px] w-4 h-4 leading-none text-sky-400">landscape</mat-icon>
            Longitudinal Profile
          </button>

          <button
            type="button"
            (click)="selectTab('PHYSICS')"
            [class.bg-[#192338]]="activeTab() === 'PHYSICS'"
            [class.text-white]="activeTab() === 'PHYSICS'"
            [class.text-slate-400]="activeTab() !== 'PHYSICS'"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded hover:text-white transition-colors cursor-pointer"
          >
            <mat-icon class="text-[16px] w-4 h-4 leading-none text-blue-400">speed</mat-icon>
            Train Performance (Davis Physics)
          </button>

          <button
            type="button"
            (click)="selectTab('MAREY')"
            [class.bg-[#192338]]="activeTab() === 'MAREY'"
            [class.text-white]="activeTab() === 'MAREY'"
            [class.text-slate-400]="activeTab() !== 'MAREY'"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded hover:text-white transition-colors cursor-pointer"
          >
            <mat-icon class="text-[16px] w-4 h-4 leading-none text-emerald-400">alt_route</mat-icon>
            Timetable Stringline (Marey)
          </button>

          <button
            type="button"
            (click)="selectTab('INTEROP')"
            [class.bg-[#192338]]="activeTab() === 'INTEROP'"
            [class.text-white]="activeTab() === 'INTEROP'"
            [class.text-slate-400]="activeTab() !== 'INTEROP'"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded hover:text-white transition-colors cursor-pointer"
          >
            <mat-icon class="text-[16px] w-4 h-4 leading-none text-amber-400">electrical_services</mat-icon>
            Cross-Border &amp; Interoperability
          </button>
        </div>

        <div class="flex items-center gap-3">
          @if (state.selectedCorridor(); as sel) {
            <span class="text-xs font-mono text-slate-300">
              Corridor: <strong class="text-white">{{ sel.name }}</strong> ({{ sel.distanceKm }} km)
            </span>
          }
          <button
            type="button"
            (click)="isExpanded.set(!isExpanded())"
            class="p-1 text-slate-400 hover:text-white hover:bg-[#1a2336] rounded transition-colors cursor-pointer"
            title="Expand / Collapse Drawer"
          >
            <mat-icon class="text-[18px] w-4.5 h-4.5 leading-none">
              {{ isExpanded() ? 'expand_more' : 'expand_less' }}
            </mat-icon>
          </button>
        </div>
      </div>

      <!-- Drawer Content Viewport -->
      @if (isExpanded()) {
        <div class="flex-1 p-4 overflow-hidden bg-[#090d16]">
          <!-- TAB 1: Longitudinal Terrain Profile -->
          @if (activeTab() === 'PROFILE') {
            @if (state.selectedCorridor(); as c) {
              <div class="h-full flex flex-col">
                <!-- Top Engineering Indicators -->
                <div class="flex items-center justify-between pb-2 mb-2 border-b border-[#1a2336] text-xs font-mono text-slate-300">
                  <div class="flex items-center gap-6">
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Max Track Gradient</span>
                      <span class="text-white font-semibold">{{ c.maxGradientPercent }}%</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Min Curve Radius (R_min)</span>
                      <span class="text-white font-semibold">{{ curveAnalysis().minCurveRadiusM }} m</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Cant Deficiency</span>
                      <span class="text-white font-semibold">{{ c.cantDeficiencyMm }} mm ({{ curveAnalysis().cantDeficiencyAccelerationMPerS2 }} m/s&sup2;)</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Tunnels</span>
                      <span class="text-sky-400 font-semibold">{{ c.tunnelLengthKm }} km ({{ c.tunnelPercentage }}%)</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Viaducts</span>
                      <span class="text-sky-400 font-semibold">{{ c.bridgeLengthKm }} km ({{ c.bridgePercentage }}%)</span>
                    </div>
                  </div>

                  <!-- Legend -->
                  <div class="flex items-center gap-4 text-[11px]">
                    <span class="flex items-center gap-1.5">
                      <span class="w-3 h-2 bg-slate-700 rounded-sm"></span>
                      <span class="text-slate-400">Natural Terrain</span>
                    </span>
                    <span class="flex items-center gap-1.5">
                      <span class="w-3 h-0.5 bg-blue-500"></span>
                      <span class="text-slate-400">Rail Design Alignment</span>
                    </span>
                    <span class="flex items-center gap-1.5">
                      <span class="w-3 h-2 bg-sky-950 border border-sky-400"></span>
                      <span class="text-slate-400">Base Tunnel</span>
                    </span>
                    <span class="flex items-center gap-1.5">
                      <span class="w-3 h-2 bg-amber-950 border border-amber-400"></span>
                      <span class="text-slate-400">Viaduct / Bridge</span>
                    </span>
                  </div>
                </div>

                <!-- Longitudinal SVG Chart Canvas -->
                <div class="flex-1 relative w-full overflow-hidden bg-[#0a0f1c] border border-[#1d273c] rounded p-2">
                  <svg class="w-full h-full" viewBox="0 0 1000 170" preserveAspectRatio="none">
                    <!-- Grid Lines -->
                    <line x1="0" y1="30" x2="1000" y2="30" stroke="#162032" stroke-width="1" stroke-dasharray="2,2" />
                    <line x1="0" y1="80" x2="1000" y2="80" stroke="#162032" stroke-width="1" stroke-dasharray="2,2" />
                    <line x1="0" y1="130" x2="1000" y2="130" stroke="#162032" stroke-width="1" stroke-dasharray="2,2" />

                    <!-- Y-Axis Elevation Markers -->
                    <text x="8" y="28" fill="#475569" font-size="9" font-family="monospace">2000m</text>
                    <text x="8" y="78" fill="#475569" font-size="9" font-family="monospace">1000m</text>
                    <text x="8" y="128" fill="#475569" font-size="9" font-family="monospace">200m</text>

                    <!-- Natural Terrain Shaded Polygon -->
                    <polygon
                      [attr.points]="terrainPolygonPoints()"
                      fill="rgba(30, 41, 59, 0.6)"
                      stroke="#475569"
                      stroke-width="1.2"
                    />

                    <!-- Tunnel Boxes (Base tunnels) -->
                    @for (tun of c.tunnelSections; track tun.id) {
                      <rect
                        [attr.x]="(tun.startKm / c.distanceKm) * 1000"
                        y="105"
                        [attr.width]="Math.max(12, ((tun.endKm - tun.startKm) / c.distanceKm) * 1000)"
                        height="30"
                        fill="rgba(14, 116, 144, 0.35)"
                        stroke="#38bdf8"
                        stroke-width="1"
                        stroke-dasharray="3,2"
                      />
                      <text
                        [attr.x]="(tun.startKm / c.distanceKm) * 1000 + 4"
                        y="100"
                        fill="#38bdf8"
                        font-size="8.5"
                        font-family="monospace"
                        font-weight="bold"
                      >
                        {{ tun.name }} ({{ tun.lengthKm }}km)
                      </text>
                    }

                    <!-- Viaduct Markers -->
                    @for (brg of c.bridgeSections; track brg.id) {
                      <rect
                        [attr.x]="(brg.startKm / c.distanceKm) * 1000"
                        y="110"
                        [attr.width]="Math.max(8, ((brg.endKm - brg.startKm) / c.distanceKm) * 1000)"
                        height="20"
                        fill="rgba(217, 119, 6, 0.35)"
                        stroke="#f59e0b"
                        stroke-width="1"
                      />
                      <text
                        [attr.x]="(brg.startKm / c.distanceKm) * 1000"
                        y="142"
                        fill="#f59e0b"
                        font-size="8"
                        font-family="monospace"
                      >
                        {{ brg.name }}
                      </text>
                    }

                    <!-- Rail Alignment Grade Line -->
                    <polyline
                      [attr.points]="railAlignmentPoints()"
                      fill="none"
                      stroke="#2563eb"
                      stroke-width="2.5"
                      stroke-linecap="round"
                    />
                  </svg>
                </div>
              </div>
            }
          }

          <!-- TAB 2: Train Performance Simulator (Physics Davis Model) -->
          @if (activeTab() === 'PHYSICS') {
            @if (state.activeSimulation(); as sim) {
              <div class="h-full flex flex-col">
                <div class="flex items-center justify-between pb-2 mb-2 border-b border-[#1a2336] text-xs font-mono text-slate-300">
                  <div class="flex items-center gap-6">
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Trainset</span>
                      <span class="text-white font-semibold">{{ state.activeTrainset().name }}</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Simulated Journey Time</span>
                      <span class="text-emerald-400 font-semibold">{{ sim.journeyTimeMinutes }} min</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Average Speed</span>
                      <span class="text-white font-semibold">{{ sim.averageSpeedKmh }} km/h</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Max Speed Reached</span>
                      <span class="text-sky-400 font-semibold">{{ sim.topSpeedReachedKmh }} km/h</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Energy Consumed</span>
                      <span class="text-white font-semibold">{{ sim.totalEnergyConsumptionKwh | number }} kWh</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Regenerative Recovery</span>
                      <span class="text-emerald-400 font-semibold">-{{ sim.energyRecoveredKwh | number }} kWh</span>
                    </div>
                    <div>
                      <span class="text-slate-500 uppercase text-[10px] block">Specific Energy</span>
                      <span class="text-white font-semibold">{{ sim.energyPerPassengerKmWh }} Wh / pax-km</span>
                    </div>
                  </div>

                  <span class="text-[10px] text-slate-500 font-sans">Davis Eq: R = A + Bv + Cv&sup2;</span>
                </div>

                <!-- Speed-Distance Profile Chart -->
                <div class="flex-1 relative w-full bg-[#0a0f1c] border border-[#1d273c] rounded p-2">
                  <svg class="w-full h-full" viewBox="0 0 1000 170" preserveAspectRatio="none">
                    <!-- Speed Limit Reference Lines -->
                    <line x1="0" y1="20" x2="1000" y2="20" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3" />
                    <line x1="0" y1="65" x2="1000" y2="65" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3" />
                    <line x1="0" y1="110" x2="1000" y2="110" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3" />

                    <text x="8" y="24" fill="#475569" font-size="9" font-family="monospace">350 km/h</text>
                    <text x="8" y="69" fill="#475569" font-size="9" font-family="monospace">250 km/h</text>
                    <text x="8" y="114" fill="#475569" font-size="9" font-family="monospace">150 km/h</text>

                    <!-- Speed Curve Polyline -->
                    <polyline
                      [attr.points]="speedProfilePoints(sim)"
                      fill="none"
                      stroke="#38bdf8"
                      stroke-width="2.5"
                      stroke-linecap="round"
                    />

                    <!-- Acceleration / Cruise / Braking Shaded Area -->
                    <polygon
                      [attr.points]="speedProfileAreaPoints(sim)"
                      fill="rgba(56, 189, 248, 0.12)"
                    />
                  </svg>
                </div>
              </div>
            }
          }

          <!-- TAB 3: Timetable Stringline (Marey Diagram) -->
          @if (activeTab() === 'MAREY') {
            <div class="h-full flex flex-col">
              <div class="flex items-center justify-between pb-2 mb-2 border-b border-[#1a2336] text-xs font-mono text-slate-300">
                <div class="flex items-center gap-6">
                  <span>Frequency: <strong class="text-white">{{ state.selectedCorridor().trainsPerHour }} tph</strong></span>
                  <span>Minimum Headway: <strong class="text-white">3 min (ETCS L2)</strong></span>
                  <span>Daily Services: <strong class="text-emerald-400">{{ state.activeTimetable().length }} trips</strong></span>
                </div>
                <div class="flex items-center gap-3 text-[11px]">
                  <span class="text-slate-400">X-Axis: Time (06:00 &ndash; 22:00)</span>
                  <span class="text-slate-400">Y-Axis: Stations Distance</span>
                </div>
              </div>

              <!-- Marey Diagram Canvas -->
              <div class="flex-1 relative w-full bg-[#0a0f1c] border border-[#1d273c] rounded p-2">
                <svg class="w-full h-full" viewBox="0 0 1000 170" preserveAspectRatio="none">
                  <!-- Time Vertical Axis Lines (Hourly) -->
                  @for (hr of hoursList; track hr) {
                    <line
                      [attr.x1]="((hr - 6) / 16) * 1000"
                      y1="0"
                      [attr.x2]="((hr - 6) / 16) * 1000"
                      y2="170"
                      stroke="#141c2c"
                      stroke-width="1"
                    />
                    <text
                      [attr.x]="((hr - 6) / 16) * 1000 + 4"
                      y="14"
                      fill="#334155"
                      font-size="8"
                      font-family="monospace"
                    >
                      {{ hr }}:00
                    </text>
                  }

                  <!-- Train Path Lines -->
                  @for (path of mareyPaths(); track path.serviceId) {
                    <polyline
                      [attr.points]="mareyPathToSvgPoints(path)"
                      fill="none"
                      [attr.stroke]="path.color"
                      stroke-width="2"
                      opacity="0.85"
                    />
                  }
                </svg>
              </div>
            </div>
          }

          <!-- TAB 4: Cross-Border & Interoperability -->
          @if (activeTab() === 'INTEROP') {
            <div class="h-full flex flex-col overflow-y-auto pr-2">
              <div class="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 font-mono">
                European Railway Interoperability Matrix (TSI High Speed)
              </div>
              <div class="grid grid-cols-2 gap-3 text-xs">
                @for (c of state.crossBorderConstraints(); track c.borderPair) {
                  <div class="p-3 rounded bg-[#0f1523] border border-[#202c44] space-y-2">
                    <div class="flex items-center justify-between pb-1.5 border-b border-[#1b253a]">
                      <span class="font-bold text-white">{{ c.borderPair }}</span>
                      <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                        Dual-Standard Interface
                      </span>
                    </div>

                    <div class="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-300">
                      <div>
                        <span class="text-slate-500 block text-[9px]">Electrification A</span>
                        <span>{{ c.voltageA }}</span>
                      </div>
                      <div>
                        <span class="text-slate-500 block text-[9px]">Electrification B</span>
                        <span>{{ c.voltageB }}</span>
                      </div>
                    </div>

                    <div class="text-[11px] font-mono">
                      <span class="text-slate-500 block text-[9px]">Signaling &amp; RBC Handshake:</span>
                      <span class="text-slate-300">{{ c.signalingTransition }}</span>
                    </div>

                    <div class="text-[11px] font-mono">
                      <span class="text-slate-500 block text-[9px]">Loading Gauge:</span>
                      <span class="text-slate-300">{{ c.loadingGaugeDiff }}</span>
                    </div>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      }
    </div>
  `
})
export class AppEngineeringDrawer {
  public readonly state = inject(RailwayStateService);
  protected readonly Math = Math;

  public isExpanded = signal<boolean>(true);
  public activeTab = signal<'PROFILE' | 'PHYSICS' | 'MAREY' | 'INTEROP'>('PROFILE');

  public readonly hoursList = [6, 8, 10, 12, 14, 16, 18, 20, 22];

  public readonly curveAnalysis = computed(() => {
    const cor = this.state.selectedCorridor();
    if (!cor) return RailwayEngineeringEngine.calculateCurveCantLimits(320);
    return RailwayEngineeringEngine.calculateCurveCantLimits(
      cor.designSpeedKmh,
      cor.appliedCantMm,
      cor.cantDeficiencyMm
    );
  });

  public readonly terrainPolygonPoints = computed(() => {
    const cor = this.state.selectedCorridor();
    if (!cor || !cor.crossSectionPoints || cor.crossSectionPoints.length === 0) return '';
    const pts = cor.crossSectionPoints;
    const maxDist = cor.distanceKm || 1;

    // SVG height is 170. Range: 0m elevation at y=150, 2000m elevation at y=20
    const pointsStr = pts.map(p => {
      const x = (p.distanceKm / maxDist) * 1000;
      const y = Math.max(15, 150 - (p.terrainElevationM / 2200) * 130);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');

    return `0,170 ${pointsStr} 1000,170`;
  });

  public readonly railAlignmentPoints = computed(() => {
    const cor = this.state.selectedCorridor();
    if (!cor || !cor.crossSectionPoints || cor.crossSectionPoints.length === 0) return '';
    const pts = cor.crossSectionPoints;
    const maxDist = cor.distanceKm || 1;

    return pts.map(p => {
      const x = (p.distanceKm / maxDist) * 1000;
      const y = Math.max(15, 150 - (p.railElevationM / 2200) * 130);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
  });

  public readonly mareyPaths = computed(() => {
    const tt = this.state.activeTimetable();
    return TimetableEngine.generateMareyDiagramPaths(tt);
  });

  public selectTab(tab: 'PROFILE' | 'PHYSICS' | 'MAREY' | 'INTEROP'): void {
    this.activeTab.set(tab);
    if (!this.isExpanded()) {
      this.isExpanded.set(true);
    }
  }

  public speedProfilePoints(sim: NonNullable<ReturnType<typeof this.state.activeSimulation>>): string {
    const totalDist = sim.speedProfile[sim.speedProfile.length - 1]?.distanceKm || 1;
    return sim.speedProfile.map(s => {
      const x = (s.distanceKm / totalDist) * 1000;
      const y = Math.max(15, 155 - (s.speedKmh / 370) * 135);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
  }

  public speedProfileAreaPoints(sim: NonNullable<ReturnType<typeof this.state.activeSimulation>>): string {
    const totalDist = sim.speedProfile[sim.speedProfile.length - 1]?.distanceKm || 1;
    const top = sim.speedProfile.map(s => {
      const x = (s.distanceKm / totalDist) * 1000;
      const y = Math.max(15, 155 - (s.speedKmh / 370) * 135);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
    return `0,155 ${top} 1000,155`;
  }

  public mareyPathToSvgPoints(path: ReturnType<typeof this.mareyPaths>[0]): string {
    const cor = this.state.selectedCorridor();
    const maxDist = cor?.distanceKm || 1;
    // Time from 06:00 (360 min) to 22:00 (1320 min) -> 960 min total
    return path.points.map(pt => {
      const timeFrac = Math.max(0, Math.min(1, (pt.timeMinutes - 360) / 960));
      const distFrac = Math.max(0, Math.min(1, pt.distanceKm / maxDist));
      const x = timeFrac * 1000;
      const y = 20 + distFrac * 135;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
  }
}
