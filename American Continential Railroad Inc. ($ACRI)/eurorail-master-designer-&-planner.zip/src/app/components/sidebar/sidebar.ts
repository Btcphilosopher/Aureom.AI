import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';
import { AlignmentStatus } from '../../core/domain/railway.models';

@Component({
  selector: 'app-sidebar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <aside class="w-80 h-full bg-[#0d121c] border-r border-[#1f293d] flex flex-col shrink-0 select-none overflow-hidden">
      <!-- Scenario Selector Header -->
      <div class="p-3.5 border-b border-[#1f293d] bg-[#111724]">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] font-semibold tracking-wider uppercase text-slate-400">Master Scenario</span>
          <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-950/60 border border-blue-800/40 text-blue-300">
            {{ state.activeScenario().targetYear }}
          </span>
        </div>
        <select
          [value]="state.activeScenarioId()"
          (change)="onScenarioChange($event)"
          class="w-full bg-[#090d16] border border-[#26334d] text-slate-200 text-xs rounded px-2.5 py-1.5 focus:outline-none focus:border-blue-500 font-medium cursor-pointer"
        >
          @for (s of state.scenarios(); track s.id) {
            <option [value]="s.id">{{ s.name }}</option>
          }
        </select>
        <p class="text-[11px] text-slate-400 mt-2 line-clamp-2 leading-relaxed">
          {{ state.activeScenario().description }}
        </p>
      </div>

      <!-- Quick Action Toolbox -->
      <div class="px-3 py-2 border-b border-[#1f293d] bg-[#0f1422] grid grid-cols-2 gap-1.5">
        <button
          type="button"
          (click)="toggleRouteDrawing()"
          [class.bg-emerald-950]="state.isDrawingRoute()"
          [class.border-emerald-600]="state.isDrawingRoute()"
          [class.text-emerald-300]="state.isDrawingRoute()"
          class="flex items-center gap-1.5 px-2 py-1.5 text-[11px] font-medium bg-[#141b2a] border border-[#222d42] text-slate-300 hover:text-white rounded transition-colors cursor-pointer"
        >
          <mat-icon class="text-[15px] w-3.5 h-3.5 leading-none">
            {{ state.isDrawingRoute() ? 'check' : 'gesture' }}
          </mat-icon>
          <span class="truncate">{{ state.isDrawingRoute() ? 'Drawing...' : 'Draw Route' }}</span>
        </button>

        <button
          type="button"
          (click)="state.showStationDesignerModal.set(true)"
          class="flex items-center gap-1.5 px-2 py-1.5 text-[11px] font-medium bg-[#141b2a] border border-[#222d42] text-slate-300 hover:text-white rounded transition-colors cursor-pointer"
        >
          <mat-icon class="text-[15px] w-3.5 h-3.5 leading-none text-sky-400">domain</mat-icon>
          <span class="truncate">Station Hubs</span>
        </button>

        <button
          type="button"
          (click)="state.showConstructionGanttModal.set(true)"
          class="flex items-center gap-1.5 px-2 py-1.5 text-[11px] font-medium bg-[#141b2a] border border-[#222d42] text-slate-300 hover:text-white rounded transition-colors cursor-pointer"
        >
          <mat-icon class="text-[15px] w-3.5 h-3.5 leading-none text-amber-400">timeline</mat-icon>
          <span class="truncate">Packages (Gantt)</span>
        </button>

        <button
          type="button"
          (click)="state.showRiskMatrixModal.set(true)"
          class="flex items-center gap-1.5 px-2 py-1.5 text-[11px] font-medium bg-[#141b2a] border border-[#222d42] text-slate-300 hover:text-white rounded transition-colors cursor-pointer"
        >
          <mat-icon class="text-[15px] w-3.5 h-3.5 leading-none text-rose-400">warning_amber</mat-icon>
          <span class="truncate">Risk Matrix</span>
        </button>
      </div>

      <!-- Corridor Digital Twins List -->
      <div class="flex-1 overflow-y-auto">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-[#1a2233] bg-[#0c101a] sticky top-0 z-10">
          <span class="text-[11px] font-semibold tracking-wider uppercase text-slate-400">
            Corridors ({{ state.activeScenarioCorridors().length }})
          </span>
          <button
            type="button"
            (click)="state.showCorridorGeneratorModal.set(true)"
            class="text-[11px] text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-[14px] w-3.5 h-3.5 leading-none">add</mat-icon>
            New
          </button>
        </div>

        <div class="p-2 space-y-1.5">
          @for (c of state.activeScenarioCorridors(); track c.id) {
            <button
              type="button"
              (click)="state.selectCorridor(c.id)"
              [class.bg-[#162136]]="state.selectedCorridorId() === c.id"
              [class.border-blue-500]="state.selectedCorridorId() === c.id"
              [class.shadow-md]="state.selectedCorridorId() === c.id"
              class="w-full text-left p-2.5 rounded border border-[#1d263b] bg-[#111724] hover:bg-[#141b2b] transition-all cursor-pointer group"
            >
              <div class="flex items-start justify-between gap-2 mb-1">
                <span class="text-xs font-mono font-semibold text-blue-400">{{ c.code }}</span>
                <span [class]="getStatusBadgeClass(c.status)" class="text-[9px] font-mono font-medium px-1.5 py-0.5 rounded uppercase">
                  {{ formatStatus(c.status) }}
                </span>
              </div>

              <div class="text-xs font-medium text-slate-200 line-clamp-1 group-hover:text-white transition-colors">
                {{ c.name }}
              </div>

              <div class="mt-2 pt-1.5 border-t border-[#1a2236] flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>{{ c.distanceKm }} km</span>
                <span>{{ c.designSpeedKmh }} km/h</span>
                <span class="text-emerald-400 font-medium">&euro;{{ c.capexEurBillion }}B</span>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Trainset Fleet Selector Drawer -->
      <div class="p-3 border-t border-[#1f293d] bg-[#101624]">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] font-semibold tracking-wider uppercase text-slate-400">Simulation Trainset</span>
          <span class="text-[10px] font-mono text-slate-500">Physics Davis Model</span>
        </div>
        <select
          [value]="state.activeTrainsetId()"
          (change)="onTrainsetChange($event)"
          class="w-full bg-[#090d16] border border-[#26334d] text-slate-200 text-xs rounded px-2 py-1.5 focus:outline-none focus:border-blue-500 font-mono cursor-pointer"
        >
          @for (t of state.trainsets(); track t.id) {
            <option [value]="t.id">{{ t.name }} ({{ t.maxSpeedKmh }} km/h)</option>
          }
        </select>
        <div class="mt-2 text-[10px] text-slate-400 flex items-center justify-between font-mono">
          <span>P: {{ state.activeTrainset().tractionPowerKw / 1000 }} MW</span>
          <span>Mass: {{ state.activeTrainset().loadedMassTonnes }} t</span>
          <span>Cap: {{ state.activeTrainset().passengerCapacity }} pax</span>
        </div>
      </div>
    </aside>
  `
})
export class AppSidebar {
  public readonly state = inject(RailwayStateService);

  public onScenarioChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.selectScenario(val);
  }

  public onTrainsetChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.selectTrainset(val);
  }

  public toggleRouteDrawing(): void {
    if (this.state.isDrawingRoute()) {
      this.state.cancelDrawingRoute();
    } else {
      this.state.startDrawingRoute();
    }
  }

  public formatStatus(status: AlignmentStatus): string {
    return status.replace(/_/g, ' ');
  }

  public getStatusBadgeClass(status: AlignmentStatus): string {
    switch (status) {
      case 'OPERATIONAL':
        return 'bg-emerald-950/70 border border-emerald-800 text-emerald-300';
      case 'UNDER_CONSTRUCTION':
        return 'bg-amber-950/70 border border-amber-800 text-amber-300';
      case 'DESIGNED':
        return 'bg-sky-950/70 border border-sky-800 text-sky-300';
      case 'PLANNED':
        return 'bg-indigo-950/70 border border-indigo-800 text-indigo-300';
      case 'PROPOSED':
        return 'bg-purple-950/70 border border-purple-800 text-purple-300';
      default:
        return 'bg-slate-800 text-slate-400';
    }
  }
}
