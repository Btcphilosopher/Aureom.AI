import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService, MainNavView } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <header class="flex items-center justify-between gap-8 px-6 py-3 bg-[#0d121d] border-b border-[#222d42] shrink-0 z-30 select-none">
      <!-- Zone 1: Brand title, one line -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="w-8 h-8 rounded bg-[#003399] flex items-center justify-center text-white font-bold text-sm tracking-wider shadow-sm border border-blue-400/30">
          EU
        </div>
        <div class="flex items-baseline gap-2">
          <span class="text-base font-bold tracking-tight text-white font-mono whitespace-nowrap">EURORAIL</span>
          <span class="text-xs text-slate-400 tracking-wider uppercase font-medium whitespace-nowrap">Master Designer &amp; Planner</span>
        </div>
      </div>

      <!-- Zone 2: 4-5 nav links, 1-2 word labels, single-line -->
      <nav class="hidden md:flex items-center gap-1 bg-[#131a29] p-1 rounded-lg border border-[#222d42]">
        <button
          type="button"
          (click)="setView('MAP')"
          [class.bg-[#1e293b]]="state.activeView() === 'MAP'"
          [class.text-white]="state.activeView() === 'MAP'"
          [class.shadow-sm]="state.activeView() === 'MAP'"
          class="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <mat-icon class="text-[16px] w-4 h-4 leading-none">map</mat-icon>
          Network Map
        </button>

        <button
          type="button"
          (click)="setView('ENGINEERING')"
          [class.bg-[#1e293b]]="state.activeView() === 'ENGINEERING'"
          [class.text-white]="state.activeView() === 'ENGINEERING'"
          [class.shadow-sm]="state.activeView() === 'ENGINEERING'"
          class="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <mat-icon class="text-[16px] w-4 h-4 leading-none">straighten</mat-icon>
          Engineering CAD
        </button>

        <button
          type="button"
          (click)="setView('TIMETABLE')"
          [class.bg-[#1e293b]]="state.activeView() === 'TIMETABLE'"
          [class.text-white]="state.activeView() === 'TIMETABLE'"
          [class.shadow-sm]="state.activeView() === 'TIMETABLE'"
          class="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <mat-icon class="text-[16px] w-4 h-4 leading-none">schedule</mat-icon>
          Timetable &amp; Ops
        </button>

        <button
          type="button"
          (click)="setView('ECONOMICS')"
          [class.bg-[#1e293b]]="state.activeView() === 'ECONOMICS'"
          [class.text-white]="state.activeView() === 'ECONOMICS'"
          [class.shadow-sm]="state.activeView() === 'ECONOMICS'"
          class="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <mat-icon class="text-[16px] w-4 h-4 leading-none">trending_up</mat-icon>
          Economics &amp; Demand
        </button>

        <button
          type="button"
          (click)="setView('REVIEW')"
          [class.bg-[#1e293b]]="state.activeView() === 'REVIEW'"
          [class.text-white]="state.activeView() === 'REVIEW'"
          [class.shadow-sm]="state.activeView() === 'REVIEW'"
          class="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <mat-icon class="text-[16px] w-4 h-4 leading-none">assessment</mat-icon>
          Executive Review
        </button>
      </nav>

      <!-- Zone 3: 1 primary action button with quick utilities -->
      <div class="flex items-center gap-2 shrink-0">
        <button
          type="button"
          (click)="state.showOptimiserModal.set(true)"
          class="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#162032] border border-[#2e3e5d] rounded hover:bg-[#1e2c45] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          title="Multi-Objective Network Optimiser"
        >
          <mat-icon class="text-[16px] w-4 h-4 leading-none text-blue-400">tune</mat-icon>
          Network Optimiser
        </button>

        <button
          type="button"
          (click)="state.showCorridorGeneratorModal.set(true)"
          class="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-white bg-[#003399] hover:bg-[#1e40af] rounded shadow-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <mat-icon class="text-[16px] w-4 h-4 leading-none">add_road</mat-icon>
          Generate Corridor
        </button>
      </div>
    </header>
  `
})
export class AppHeader {
  public readonly state = inject(RailwayStateService);

  public setView(view: MainNavView): void {
    this.state.selectView(view);
  }
}
