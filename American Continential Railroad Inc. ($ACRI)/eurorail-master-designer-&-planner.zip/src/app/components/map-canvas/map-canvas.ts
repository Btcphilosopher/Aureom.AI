import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  computed,
  inject,
  signal
} from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { CityNode, CorridorAlignment } from '../../core/domain/railway.models';
import { GeospatialEngine } from '../../core/geospatial/geospatial-engine';
import { MatIconModule } from '@angular/material/icon';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-map-canvas',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe],
  template: `
    <div class="relative w-full h-full bg-[#080c14] overflow-hidden select-none" #mapContainer>
      <!-- CAD Grid Background -->
      <div class="absolute inset-0 bg-cad-grid pointer-events-none opacity-40"></div>

      <!-- Main GIS SVG Map Canvas -->
      <svg
        #svgCanvas
        tabindex="0"
        role="region"
        aria-label="European Railway GIS Map Canvas"
        class="w-full h-full cursor-grab active:cursor-grabbing outline-none"
        (mousedown)="onMouseDown($event)"
        (mousemove)="onMouseMove($event)"
        (mouseup)="onMouseUp()"
        (wheel)="onWheel($event)"
        (click)="onSvgClick($event)"
        (keydown.enter)="onSvgKeyEnter()"
      >
        <g [attr.transform]="transformString()">
          <!-- 1. European Landmass Shaded Backdrop -->
          <path
            [attr.d]="europeanLandmassPath"
            fill="#0f1624"
            stroke="#1c283f"
            stroke-width="1.5"
            stroke-linejoin="round"
          />

          <!-- 2. Mountain Chains (Shaded Topographic Contours) -->
          @if (state.mapLayers().mountainRanges) {
            <!-- The Alps -->
            <path
              [attr.d]="alpsMountainPath"
              fill="rgba(45, 60, 85, 0.45)"
              stroke="rgba(80, 110, 150, 0.3)"
              stroke-width="1"
            />
            <text x="590" y="555" fill="rgba(148, 163, 184, 0.4)" font-size="11" font-family="'JetBrains Mono', monospace" letter-spacing="3">
              THE ALPS (MASSIF)
            </text>

            <!-- The Pyrenees -->
            <path
              [attr.d]="pyreneesMountainPath"
              fill="rgba(45, 60, 85, 0.45)"
              stroke="rgba(80, 110, 150, 0.3)"
              stroke-width="1"
            />
            <text x="330" y="690" fill="rgba(148, 163, 184, 0.4)" font-size="10" font-family="'JetBrains Mono', monospace" letter-spacing="2">
              PYRENEES
            </text>

            <!-- Apennines -->
            <path
              [attr.d]="apenninesMountainPath"
              fill="rgba(45, 60, 85, 0.35)"
              stroke="rgba(80, 110, 150, 0.25)"
              stroke-width="1"
            />
          }

          <!-- 3. European Major Waterways (Rhine, Danube, Rhône, Po, Seine) -->
          @if (state.mapLayers().topography) {
            <path
              [attr.d]="danubeRiverPath"
              fill="none"
              stroke="#1b3358"
              stroke-width="1.8"
              stroke-linecap="round"
            />
            <path
              [attr.d]="rhineRiverPath"
              fill="none"
              stroke="#1b3358"
              stroke-width="1.8"
              stroke-linecap="round"
            />
            <path
              [attr.d]="rhoneRiverPath"
              fill="none"
              stroke="#1b3358"
              stroke-width="1.5"
              stroke-linecap="round"
            />
          }

          <!-- 4. Existing High Speed Lines (Grey/Steel dashed) -->
          @if (state.mapLayers().existingHsr) {
            @for (line of existingHsrLines; track line.id) {
              <path
                [attr.d]="line.path"
                fill="none"
                stroke="#334155"
                stroke-width="2"
                stroke-dasharray="4,3"
                opacity="0.85"
              />
            }
          }

          <!-- 5. Proposed EURORAIL Network Corridors -->
          @if (state.mapLayers().proposedHsr) {
            @for (corridor of state.activeScenarioCorridors(); track corridor.id) {
              <!-- Outer Glow if Selected -->
              @if (state.selectedCorridorId() === corridor.id) {
                <path
                  [attr.d]="getCorridorSvgPath(corridor)"
                  fill="none"
                  stroke="#3b82f6"
                  stroke-width="9"
                  stroke-linecap="round"
                  opacity="0.3"
                  class="filter blur-[2px]"
                />
              }

              <!-- Main Alignment Path -->
              <path
                [attr.d]="getCorridorSvgPath(corridor)"
                fill="none"
                [attr.stroke]="getCorridorColor(corridor)"
                [attr.stroke-width]="state.selectedCorridorId() === corridor.id ? 4 : 2.8"
                stroke-linecap="round"
                stroke-linejoin="round"
                (click)="onCorridorClick(corridor, $event)"
                class="cursor-pointer transition-all hover:stroke-white"
              />

              <!-- Tunnel Sections Overlay (dark dotted marker) -->
              @for (tun of corridor.tunnelSections; track tun.id) {
                <circle
                  [attr.cx]="getTunnelCoord(corridor, tun.startKm).x"
                  [attr.cy]="getTunnelCoord(corridor, tun.startKm).y"
                  r="3.5"
                  fill="#0f172a"
                  stroke="#38bdf8"
                  stroke-width="1.5"
                />
              }
            }
          }

          <!-- 6. Active Drawing Path (if user is drawing route) -->
          @if (state.isDrawingRoute() && state.drawnWaypoints().length > 0) {
            <path
              [attr.d]="getDrawnPathSvg()"
              fill="none"
              stroke="#10b981"
              stroke-width="3"
              stroke-dasharray="6,4"
              stroke-linecap="round"
            />
            @for (pt of state.drawnWaypoints(); track $index) {
              <circle
                [attr.cx]="projectLngToX(pt.lng)"
                [attr.cy]="projectLatToY(pt.lat)"
                r="4.5"
                fill="#10b981"
                stroke="#ffffff"
                stroke-width="1.5"
              />
            }
          }

          <!-- 7. Station Nodes & Hub Cities -->
          @for (city of state.cities(); track city.id) {
            <g
              [attr.transform]="'translate(' + projectLngToX(city.lng) + ',' + projectLatToY(city.lat) + ')'"
              (click)="onStationClick(city, $event)"
              class="cursor-pointer group"
            >
              <!-- Outer pulse for major interchange hubs -->
              @if (city.stationType === 'INTERCHANGE_HUB') {
                <circle
                  r="9"
                  fill="none"
                  stroke="rgba(56, 189, 248, 0.4)"
                  stroke-width="1"
                  class="animate-ping"
                />
              }

              <!-- Station Node Circle -->
              <circle
                [attr.r]="getStationRadius(city)"
                [attr.fill]="getStationFill(city)"
                [attr.stroke]="getStationStroke(city)"
                stroke-width="2"
                class="transition-transform group-hover:scale-125"
              />

              <!-- Station Label -->
              @if (state.mapLayers().stationLabels) {
                <text
                  x="8"
                  y="4"
                  [attr.fill]="state.selectedStationId() === city.id ? '#38bdf8' : '#e2e8f0'"
                  [attr.font-weight]="city.stationType === 'INTERCHANGE_HUB' ? '700' : '500'"
                  font-size="11"
                  font-family="'Plus Jakarta Sans', sans-serif"
                  class="pointer-events-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]"
                >
                  {{ city.name }}
                </text>
              }
            </g>
          }
        </g>
      </svg>

      <!-- Map Floating Overlay Controls -->
      <div class="absolute top-4 left-4 z-20 flex flex-col gap-2">
        <!-- Layer Controls Island -->
        <div class="bg-[#0f1523]/90 backdrop-blur border border-[#222d42] p-2.5 rounded-lg shadow-xl text-xs space-y-1.5 min-w-[170px]">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold mb-1">
            GIS Layers
          </div>
          <label class="flex items-center justify-between gap-3 text-slate-300 hover:text-white cursor-pointer">
            <span>Proposed HSR</span>
            <input
              type="checkbox"
              [checked]="state.mapLayers().proposedHsr"
              (change)="state.toggleLayer('proposedHsr')"
              class="rounded bg-[#1a2336] border-[#314161] text-blue-600 focus:ring-0"
            />
          </label>
          <label class="flex items-center justify-between gap-3 text-slate-300 hover:text-white cursor-pointer">
            <span>Existing HSR</span>
            <input
              type="checkbox"
              [checked]="state.mapLayers().existingHsr"
              (change)="state.toggleLayer('existingHsr')"
              class="rounded bg-[#1a2336] border-[#314161] text-blue-600 focus:ring-0"
            />
          </label>
          <label class="flex items-center justify-between gap-3 text-slate-300 hover:text-white cursor-pointer">
            <span>Mountain Relinquish</span>
            <input
              type="checkbox"
              [checked]="state.mapLayers().mountainRanges"
              (change)="state.toggleLayer('mountainRanges')"
              class="rounded bg-[#1a2336] border-[#314161] text-blue-600 focus:ring-0"
            />
          </label>
          <label class="flex items-center justify-between gap-3 text-slate-300 hover:text-white cursor-pointer">
            <span>Capacity Heatmap</span>
            <input
              type="checkbox"
              [checked]="state.mapLayers().capacityHeatmap"
              (change)="state.toggleLayer('capacityHeatmap')"
              class="rounded bg-[#1a2336] border-[#314161] text-blue-600 focus:ring-0"
            />
          </label>
          <label class="flex items-center justify-between gap-3 text-slate-300 hover:text-white cursor-pointer">
            <span>Station Labels</span>
            <input
              type="checkbox"
              [checked]="state.mapLayers().stationLabels"
              (change)="state.toggleLayer('stationLabels')"
              class="rounded bg-[#1a2336] border-[#314161] text-blue-600 focus:ring-0"
            />
          </label>
        </div>

        <!-- Zoom & Nav Controls -->
        <div class="bg-[#0f1523]/90 backdrop-blur border border-[#222d42] p-1 rounded-lg shadow-xl flex items-center gap-1 w-fit">
          <button
            type="button"
            (click)="zoomIn()"
            class="p-1.5 text-slate-300 hover:text-white hover:bg-[#1f2b42] rounded transition-colors cursor-pointer"
            title="Zoom In"
          >
            <mat-icon class="text-[18px] w-4.5 h-4.5 leading-none">add</mat-icon>
          </button>
          <button
            type="button"
            (click)="zoomOut()"
            class="p-1.5 text-slate-300 hover:text-white hover:bg-[#1f2b42] rounded transition-colors cursor-pointer"
            title="Zoom Out"
          >
            <mat-icon class="text-[18px] w-4.5 h-4.5 leading-none">remove</mat-icon>
          </button>
          <button
            type="button"
            (click)="resetView()"
            class="p-1.5 text-slate-300 hover:text-white hover:bg-[#1f2b42] rounded transition-colors cursor-pointer"
            title="Reset Pan &amp; Zoom"
          >
            <mat-icon class="text-[18px] w-4.5 h-4.5 leading-none">center_focus_strong</mat-icon>
          </button>
        </div>
      </div>

      <!-- Route Drawing Active HUD -->
      @if (state.isDrawingRoute()) {
        <div class="absolute top-4 left-1/2 -translate-x-1/2 z-30 bg-[#0b1424] border border-emerald-500/80 px-4 py-2.5 rounded-lg shadow-2xl flex items-center gap-4 text-xs">
          <div class="flex items-center gap-2 text-emerald-400 font-medium">
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Route Drafting Mode ({{ state.drawnWaypoints().length }} Waypoints)</span>
          </div>
          <span class="text-slate-400 font-mono text-[11px]">Click map nodes to plot alignment</span>
          <div class="flex items-center gap-2">
            <button
              type="button"
              (click)="commitDrawnAlignment()"
              [disabled]="state.drawnWaypoints().length < 2"
              class="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded font-medium transition-colors cursor-pointer"
            >
              Commit Corridor
            </button>
            <button
              type="button"
              (click)="state.cancelDrawingRoute()"
              class="px-2.5 py-1 bg-[#1a2336] hover:bg-[#25324b] text-slate-300 rounded transition-colors cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      }

      <!-- Top Right Technical Inspection HUD Card -->
      @if (state.selectedCorridor(); as sel) {
        <div class="absolute top-4 right-4 z-20 w-80 bg-[#0d1422]/95 backdrop-blur border border-[#23304a] rounded-lg shadow-2xl p-3.5 text-xs select-none">
          <div class="flex items-start justify-between gap-2 mb-2 pb-2 border-b border-[#1c273e]">
            <div>
              <span class="text-[10px] font-mono text-blue-400 uppercase font-semibold">{{ sel.code }}</span>
              <h3 class="text-sm font-bold text-white leading-snug">{{ sel.name }}</h3>
            </div>
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950 border border-blue-700 text-blue-300">
              {{ sel.designSpeedKmh }} km/h
            </span>
          </div>

          <div class="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-300 mb-3">
            <div class="p-1.5 rounded bg-[#121b2d] border border-[#1d2940]">
              <span class="text-[9px] uppercase text-slate-400 block font-sans">Distance</span>
              <span class="text-white font-semibold">{{ sel.distanceKm }} km</span>
            </div>
            <div class="p-1.5 rounded bg-[#121b2d] border border-[#1d2940]">
              <span class="text-[9px] uppercase text-slate-400 block font-sans">Journey Time</span>
              <span class="text-white font-semibold">{{ sel.estimatedJourneyTimeMinutes }} min</span>
            </div>
            <div class="p-1.5 rounded bg-[#121b2d] border border-[#1d2940]">
              <span class="text-[9px] uppercase text-slate-400 block font-sans">Tunnels</span>
              <span class="text-sky-300 font-semibold">{{ sel.tunnelPercentage }}% ({{ sel.tunnelLengthKm }} km)</span>
            </div>
            <div class="p-1.5 rounded bg-[#121b2d] border border-[#1d2940]">
              <span class="text-[9px] uppercase text-slate-400 block font-sans">Viaducts</span>
              <span class="text-sky-300 font-semibold">{{ sel.bridgePercentage }}% ({{ sel.bridgeLengthKm }} km)</span>
            </div>
            <div class="p-1.5 rounded bg-[#121b2d] border border-[#1d2940]">
              <span class="text-[9px] uppercase text-slate-400 block font-sans">CAPEX</span>
              <span class="text-emerald-400 font-semibold">&euro;{{ sel.capexEurBillion }}B</span>
            </div>
            <div class="p-1.5 rounded bg-[#121b2d] border border-[#1d2940]">
              <span class="text-[9px] uppercase text-slate-400 block font-sans">Annual Pax</span>
              <span class="text-emerald-400 font-semibold">{{ sel.projectedAnnualPaxMillion }} M</span>
            </div>
          </div>

          <!-- Speed & Capacity Quick Modifiers -->
          <div class="space-y-2 pt-2 border-t border-[#1c273e]">
            <div class="flex items-center justify-between text-[11px]">
              <span class="text-slate-400">Design Speed:</span>
              <div class="flex items-center gap-1">
                @for (spd of availableSpeeds; track spd) {
                  <button
                    type="button"
                    (click)="state.updateCorridorSpeed(sel.id, spd)"
                    [class.bg-blue-600]="sel.designSpeedKmh === spd"
                    [class.text-white]="sel.designSpeedKmh === spd"
                    [class.bg-[#162032]]="sel.designSpeedKmh !== spd"
                    [class.text-slate-400]="sel.designSpeedKmh !== spd"
                    class="px-1.5 py-0.5 text-[10px] font-mono rounded border border-[#2b3a56] hover:text-white transition-colors cursor-pointer"
                  >
                    {{ spd }}
                  </button>
                }
              </div>
            </div>

            <div class="flex items-center justify-between text-[11px]">
              <span class="text-slate-400">Frequency (TPH):</span>
              <div class="flex items-center gap-2">
                <input
                  type="range"
                  min="2"
                  max="16"
                  [value]="sel.trainsPerHour"
                  (input)="onFrequencyInput(sel.id, $event)"
                  class="w-24 accent-blue-500 cursor-pointer"
                />
                <span class="font-mono text-white font-semibold">{{ sel.trainsPerHour }} tph</span>
              </div>
            </div>
          </div>
        </div>
      }

      <!-- Selected Station Inspector HUD -->
      @if (state.selectedStation(); as st) {
        <div class="absolute bottom-4 right-4 z-20 w-72 bg-[#0d1422]/95 backdrop-blur border border-sky-500/50 rounded-lg shadow-2xl p-3 text-xs select-none">
          <div class="flex items-start justify-between pb-1.5 mb-2 border-b border-[#1c273e]">
            <div>
              <span class="text-[10px] font-mono text-sky-400 uppercase font-semibold">{{ st.country }} ({{ st.countryCode }})</span>
              <h4 class="text-sm font-bold text-white">{{ st.name }} Central</h4>
            </div>
            <button
              type="button"
              (click)="state.selectStation(null)"
              class="text-slate-400 hover:text-white cursor-pointer"
            >
              <mat-icon class="text-[16px] w-4 h-4 leading-none">close</mat-icon>
            </button>
          </div>
          <div class="space-y-1.5 text-[11px] font-mono text-slate-300">
            <div class="flex justify-between">
              <span class="text-slate-400">Station Type:</span>
              <span class="text-white">{{ st.stationType }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Platforms:</span>
              <span class="text-white">{{ st.platformsCount }} tracks (400m UIC)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Metro Population:</span>
              <span class="text-white">{{ (st.population / 1000000) | number:'1.1-2' }} M</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Airport Traffic:</span>
              <span class="text-white">{{ st.annualAirportPaxMillion }} M pax/yr</span>
            </div>
          </div>
          <div class="mt-2.5 pt-2 border-t border-[#1c273e] flex items-center gap-1 flex-wrap">
            @for (mode of st.intermodalModes; track mode) {
              <span class="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#162136] text-sky-300 border border-[#273857]">
                {{ mode }}
              </span>
            }
          </div>
        </div>
      }
    </div>
  `
})
export class AppMapCanvas {
  @ViewChild('mapContainer', { static: true }) mapContainer!: ElementRef<HTMLDivElement>;
  public readonly state = inject(RailwayStateService);
  public readonly availableSpeeds: (250 | 300 | 320 | 350)[] = [250, 300, 320, 350];

  // SVG Pan & Zoom State
  public panX = signal<number>(-120);
  public panY = signal<number>(-40);
  public zoom = signal<number>(1.15);
  private isDragging = false;
  private dragStartX = 0;
  private dragStartY = 0;

  public readonly transformString = computed(() => {
    return `translate(${this.panX()}, ${this.panY()}) scale(${this.zoom()})`;
  });

  // Reference Geographic Bounds for Europe Projection
  // X: Lng from -11 (Lisbon) to +24 (Warsaw/Budapest)
  // Y: Lat from 61 (Oslo) to 36 (Gibraltar)
  private readonly minLng = -11.0;
  private readonly maxLng = 24.0;
  private readonly minLat = 36.0;
  private readonly maxLat = 61.0;
  private readonly canvasWidth = 1400;
  private readonly canvasHeight = 980;

  // Authentic European Coastline Landmass Approximation Path (SVG polygon)
  public readonly europeanLandmassPath = `
    M 30,730 
    L 120,680 L 180,670 L 260,780 L 320,770 L 380,720 L 440,680 L 490,660 
    L 520,690 L 560,730 L 610,750 L 670,720 L 720,690 L 760,650 L 810,630 
    L 850,580 L 890,540 L 920,490 L 950,430 L 980,360 L 990,290 L 950,220 
    L 910,180 L 870,160 L 830,190 L 790,240 L 750,290 L 700,320 L 660,340 
    L 620,330 L 590,300 L 560,250 L 530,220 L 480,240 L 450,280 L 420,330 
    L 380,360 L 340,390 L 300,430 L 260,470 L 220,520 L 170,560 L 120,620 
    L 70,680 Z
    M 280,260 L 340,240 L 390,260 L 410,310 L 380,360 L 330,380 L 290,340 Z
    M 210,280 L 250,270 L 260,320 L 230,350 L 200,320 Z
  `;

  // Mountain range shaded vectors
  public readonly alpsMountainPath = `
    M 460,540 Q 520,500 620,520 Q 720,530 780,560 Q 750,600 670,600 Q 560,590 480,570 Z
  `;
  public readonly pyreneesMountainPath = `
    M 270,685 Q 350,670 420,680 Q 400,705 320,705 Q 280,700 270,685 Z
  `;
  public readonly apenninesMountainPath = `
    M 630,600 Q 670,650 710,730 Q 690,740 650,680 Q 620,620 630,600 Z
  `;

  // Rivers paths
  public readonly danubeRiverPath = `
    M 580,520 Q 650,510 740,530 Q 820,540 890,570 Q 940,580 980,590
  `;
  public readonly rhineRiverPath = `
    M 570,540 Q 560,460 540,410 Q 530,360 500,330
  `;
  public readonly rhoneRiverPath = `
    M 540,550 Q 510,580 490,640 Q 485,670 490,690
  `;

  // Existing high speed lines dataset (grey background reference)
  public readonly existingHsrLines = [
    { id: 'ex-1', path: 'M 370,355 L 430,420 L 490,560' }, // Paris - Lyon
    { id: 'ex-2', path: 'M 370,355 L 440,320 L 490,310' }, // Paris - Lille - Brussels
    { id: 'ex-3', path: 'M 540,380 L 580,440 L 660,530' }, // Cologne - Frankfurt - Munich
    { id: 'ex-4', path: 'M 160,730 L 260,680 L 410,690' }, // Madrid - Zaragoza - Barcelona
    { id: 'ex-5', path: 'M 640,580 L 680,630 L 710,700' }  // Milan - Florence - Rome
  ];

  public projectLngToX(lng: number): number {
    return Math.round(((lng - this.minLng) / (this.maxLng - this.minLng)) * this.canvasWidth);
  }

  public projectLatToY(lat: number): number {
    return Math.round(((this.maxLat - lat) / (this.maxLat - this.minLat)) * this.canvasHeight);
  }

  public getCorridorSvgPath(corridor: CorridorAlignment): string {
    if (!corridor.waypoints || corridor.waypoints.length === 0) return '';
    const pts = corridor.waypoints.map(w => ({
      x: this.projectLngToX(w.lng),
      y: this.projectLatToY(w.lat)
    }));

    if (pts.length < 2) return '';

    let d = `M ${pts[0].x},${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
      // Curve smoothing
      const pPrev = pts[i - 1];
      const pCurr = pts[i];
      const midX = (pPrev.x + pCurr.x) / 2;
      const midY = (pPrev.y + pCurr.y) / 2;
      d += ` Q ${pPrev.x},${pPrev.y} ${midX},${midY} T ${pCurr.x},${pCurr.y}`;
    }
    return d;
  }

  public getDrawnPathSvg(): string {
    const pts = this.state.drawnWaypoints().map(w => ({
      x: this.projectLngToX(w.lng),
      y: this.projectLatToY(w.lat)
    }));
    if (pts.length === 0) return '';
    return pts.reduce((acc, p, i) => (i === 0 ? `M ${p.x},${p.y}` : `${acc} L ${p.x},${p.y}`), '');
  }

  public getTunnelCoord(corridor: CorridorAlignment, startKm: number): { x: number; y: number } {
    const ratio = Math.min(1, Math.max(0, startKm / (corridor.distanceKm || 1)));
    const pts = corridor.waypoints;
    const idx = Math.min(pts.length - 1, Math.floor(ratio * (pts.length - 1)));
    return {
      x: this.projectLngToX(pts[idx].lng),
      y: this.projectLatToY(pts[idx].lat)
    };
  }

  public getCorridorColor(corridor: CorridorAlignment): string {
    if (this.state.mapLayers().capacityHeatmap) {
      if (corridor.capacityUtilizationPercent > 80) return '#ef4444'; // Red
      if (corridor.capacityUtilizationPercent > 55) return '#f59e0b'; // Amber
      return '#10b981'; // Green
    }

    if (this.state.selectedCorridorId() === corridor.id) {
      return '#38bdf8'; // Sky cyan focus
    }

    switch (corridor.status) {
      case 'OPERATIONAL':
        return '#10b981';
      case 'UNDER_CONSTRUCTION':
        return '#f59e0b';
      case 'DESIGNED':
        return '#2563eb';
      default:
        return '#818cf8';
    }
  }

  public getStationRadius(city: CityNode): number {
    if (city.stationType === 'INTERCHANGE_HUB') return 6.5;
    if (city.population > 3000000) return 5.5;
    return 4.2;
  }

  public getStationFill(city: CityNode): string {
    if (this.state.selectedStationId() === city.id) return '#38bdf8';
    if (city.stationType === 'INTERCHANGE_HUB') return '#003399';
    return '#1e293b';
  }

  public getStationStroke(city: CityNode): string {
    if (this.state.selectedStationId() === city.id) return '#ffffff';
    if (city.stationType === 'INTERCHANGE_HUB') return '#38bdf8';
    return '#64748b';
  }

  // Pan & Zoom Interactions
  public onMouseDown(event: MouseEvent): void {
    if (event.button !== 0) return;
    this.isDragging = true;
    this.dragStartX = event.clientX - this.panX();
    this.dragStartY = event.clientY - this.panY();
  }

  public onMouseMove(event: MouseEvent): void {
    if (!this.isDragging) return;
    this.panX.set(event.clientX - this.dragStartX);
    this.panY.set(event.clientY - this.dragStartY);
  }

  public onMouseUp(): void {
    this.isDragging = false;
  }

  public onWheel(event: WheelEvent): void {
    event.preventDefault();
    const factor = event.deltaY < 0 ? 1.1 : 0.9;
    const newZoom = Math.min(3.5, Math.max(0.6, this.zoom() * factor));
    this.zoom.set(Number(newZoom.toFixed(2)));
  }

  public zoomIn(): void {
    this.zoom.update(z => Math.min(3.5, Number((z * 1.2).toFixed(2))));
  }

  public zoomOut(): void {
    this.zoom.update(z => Math.max(0.6, Number((z / 1.2).toFixed(2))));
  }

  public resetView(): void {
    this.panX.set(-120);
    this.panY.set(-40);
    this.zoom.set(1.15);
  }

  public onCorridorClick(corridor: CorridorAlignment, event: MouseEvent): void {
    event.stopPropagation();
    this.state.selectCorridor(corridor.id);
  }

  public onStationClick(city: CityNode, event: MouseEvent): void {
    event.stopPropagation();
    if (this.state.isDrawingRoute()) {
      this.state.addWaypoint({ lat: city.lat, lng: city.lng, elevation: city.elevation });
    } else {
      this.state.selectStation(city.id);
    }
  }

  public onSvgClick(event: MouseEvent): void {
    if (!this.state.isDrawingRoute()) return;
    const target = event.currentTarget as SVGSVGElement;
    const rect = target.getBoundingClientRect();
    const clickX = (event.clientX - rect.left - this.panX()) / this.zoom();
    const clickY = (event.clientY - rect.top - this.panY()) / this.zoom();

    const lng = Number((this.minLng + (clickX / this.canvasWidth) * (this.maxLng - this.minLng)).toFixed(4));
    const lat = Number((this.maxLat - (clickY / this.canvasHeight) * (this.maxLat - this.minLat)).toFixed(4));
    const elevation = GeospatialEngine.getEuropeanTerrainElevation(lat, lng);

    this.state.addWaypoint({ lat, lng, elevation });
  }

  public onSvgKeyEnter(): void {
    // Accessible keyboard affordance
  }

  public commitDrawnAlignment(): void {
    this.state.commitDrawnRoute('New Custom European Corridor', 320);
  }

  public onFrequencyInput(corridorId: string, event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateCorridorFrequency(corridorId, val);
  }
}
