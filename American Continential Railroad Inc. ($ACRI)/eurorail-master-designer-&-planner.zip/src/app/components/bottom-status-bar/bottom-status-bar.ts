import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-bottom-status-bar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe],
  template: `
    <footer class="h-9 px-4 bg-[#090d16] border-t border-[#1a2336] flex items-center justify-between text-xs font-mono text-slate-300 shrink-0 select-none z-30">
      <!-- Left: Status Indicator -->
      <div class="flex items-center gap-4">
        <div class="flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
          <span class="text-[11px] font-sans font-semibold text-slate-200">
            EURORAIL TWIN: {{ state.activeScenario().code }}
          </span>
        </div>
        <span class="text-slate-600">|</span>
        <div class="flex items-center gap-1.5 text-[11px]">
          <span class="text-slate-500">CORRIDORS:</span>
          <span class="font-bold text-white">{{ state.activeScenarioCorridors().length }}</span>
        </div>
      </div>

      <!-- Center: Key Aggregate Network Metrics -->
      <div class="hidden lg:flex items-center gap-6 text-[11px]">
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">NETWORK DISTANCE:</span>
          <span class="text-white font-bold">{{ state.networkTotalLengthKm() | number }} km</span>
        </div>

        <span class="text-slate-700">&bull;</span>

        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">CAPEX:</span>
          <span class="text-emerald-400 font-bold">&euro;{{ state.networkTotalCapexBillion() | number:'1.1-1' }}B</span>
        </div>

        <span class="text-slate-700">&bull;</span>

        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">PROJECTED DEMAND:</span>
          <span class="text-sky-400 font-bold">{{ state.networkTotalAnnualPaxMillion() | number:'1.1-1' }} M pax/yr</span>
        </div>

        <span class="text-slate-700">&bull;</span>

        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">AVG SPEED:</span>
          <span class="text-white font-bold">{{ state.networkAverageSpeedKmh() }} km/h</span>
        </div>

        <span class="text-slate-700">&bull;</span>

        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">ANNUAL CO&sup2; AVOIDED:</span>
          <span class="text-emerald-400 font-bold">{{ state.networkTotalCo2AvoidedMt() | number:'1.2-2' }} Mt/yr</span>
        </div>
      </div>

      <!-- Right: Export & Engineering Dossier Trigger -->
      <div class="flex items-center gap-2">
        <button
          type="button"
          (click)="downloadGeoJson()"
          class="flex items-center gap-1 px-2 py-0.5 text-[10px] bg-[#141b2a] hover:bg-[#1f293d] border border-[#232e44] text-slate-300 hover:text-white rounded transition-colors cursor-pointer"
          title="Download RFC 7946 GeoJSON"
        >
          <mat-icon class="text-[13px] w-3.5 h-3.5 leading-none text-sky-400">file_download</mat-icon>
          GeoJSON
        </button>

        <button
          type="button"
          (click)="state.showDossierExportModal.set(true)"
          class="flex items-center gap-1 px-2.5 py-0.5 text-[10px] font-semibold bg-[#003399] hover:bg-[#1e40af] text-white rounded transition-colors cursor-pointer"
        >
          <mat-icon class="text-[13px] w-3.5 h-3.5 leading-none">article</mat-icon>
          Dossier Export
        </button>
      </div>
    </footer>
  `
})
export class AppBottomStatusBar {
  public readonly state = inject(RailwayStateService);

  public downloadGeoJson(): void {
    const jsonStr = this.state.exportNetworkGeoJson();
    const blob = new Blob([jsonStr], { type: 'application/geo+json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `EURORAIL-${this.state.activeScenario().code}-Network.geojson`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
