import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-risk-matrix-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4">
      <div class="w-full max-w-4xl bg-[#0c121e] border border-[#22314d] rounded-xl shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
        <!-- Header -->
        <div class="px-6 py-4 bg-[#0f1726] border-b border-[#202d45] flex items-center justify-between shrink-0">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded bg-[#ef4444]/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <mat-icon class="text-[18px]">warning_amber</mat-icon>
            </div>
            <div>
              <h2 class="text-sm font-bold text-white uppercase font-mono tracking-wide">Infrastructure Risk Engine &amp; Matrix</h2>
              <p class="text-xs text-slate-400">Quantitative assessment: Geotechnical, Cross-Border, Environmental, and Financing</p>
            </div>
          </div>
          <button
            type="button"
            (click)="state.showRiskMatrixModal.set(false)"
            class="text-slate-400 hover:text-white cursor-pointer"
          >
            <mat-icon class="text-[20px]">close</mat-icon>
          </button>
        </div>

        <!-- Body -->
        <div class="p-6 overflow-y-auto space-y-4 flex-1 text-xs text-slate-200">
          <div class="space-y-3">
            @for (risk of state.riskItems(); track risk.id) {
              <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1f2c44] space-y-2">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span [class]="getCategoryClass(risk.category)" class="text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                      {{ risk.category }}
                    </span>
                    <span class="font-bold text-white text-xs">{{ risk.title }}</span>
                  </div>

                  <!-- Risk Score Badge -->
                  <div class="flex items-center gap-2 font-mono text-[11px]">
                    <span class="text-slate-400">P: {{ risk.probability }}/5 &bull; I: {{ risk.impact }}/5</span>
                    <span [class]="getRiskScoreClass(risk.riskScore)" class="px-2 py-0.5 rounded font-bold">
                      SCORE: {{ risk.riskScore }}
                    </span>
                  </div>
                </div>

                <p class="text-[11px] text-slate-300 leading-relaxed font-sans">
                  {{ risk.description }}
                </p>

                <div class="p-2.5 rounded bg-[#131b2c] border border-[#1d273c] text-[11px]">
                  <span class="text-sky-400 font-mono font-semibold block text-[10px] uppercase mb-0.5">Mitigation Strategy:</span>
                  <span class="text-slate-300">{{ risk.mitigationStrategy }}</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Footer -->
        <div class="px-6 py-4 bg-[#0e1524] border-t border-[#1f2c44] flex items-center justify-between shrink-0">
          <span class="text-xs font-mono text-slate-400">
            Governing Directive: <strong class="text-white">EU Trans-European Transport Network (TEN-T) Risk Framework</strong>
          </span>
          <button
            type="button"
            (click)="state.showRiskMatrixModal.set(false)"
            class="px-4 py-2 text-xs font-semibold text-white bg-[#003399] hover:bg-[#1e40af] rounded shadow transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  `
})
export class AppRiskMatrixModal {
  public readonly state = inject(RailwayStateService);

  public getCategoryClass(category: string): string {
    switch (category) {
      case 'GEOTECHNICAL':
        return 'bg-amber-950 text-amber-300 border border-amber-800';
      case 'CROSS_BORDER':
        return 'bg-blue-950 text-blue-300 border border-blue-800';
      case 'ENVIRONMENTAL':
        return 'bg-emerald-950 text-emerald-300 border border-emerald-800';
      case 'FINANCIAL':
        return 'bg-purple-950 text-purple-300 border border-purple-800';
      default:
        return 'bg-slate-800 text-slate-300 border border-slate-700';
    }
  }

  public getRiskScoreClass(score: number): string {
    if (score >= 15) return 'bg-red-950 border border-red-700 text-red-300';
    if (score >= 10) return 'bg-amber-950 border border-amber-700 text-amber-300';
    return 'bg-blue-950 border border-blue-700 text-blue-300';
  }
}
