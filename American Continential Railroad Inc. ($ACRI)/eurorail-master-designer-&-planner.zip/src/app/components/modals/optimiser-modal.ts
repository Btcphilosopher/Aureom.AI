import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-optimiser-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4">
      <div class="w-full max-w-3xl bg-[#0c121e] border border-[#22314d] rounded-xl shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
        <!-- Header -->
        <div class="px-6 py-4 bg-[#0f1726] border-b border-[#202d45] flex items-center justify-between shrink-0">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded bg-[#003399] flex items-center justify-center text-white">
              <mat-icon class="text-[18px]">tune</mat-icon>
            </div>
            <div>
              <h2 class="text-sm font-bold text-white uppercase font-mono tracking-wide">Multi-Objective Network Optimiser</h2>
              <p class="text-xs text-slate-400">Algorithmic Pareto search across European rail alignment topology</p>
            </div>
          </div>
          <button
            type="button"
            (click)="state.showOptimiserModal.set(false)"
            class="text-slate-400 hover:text-white cursor-pointer"
          >
            <mat-icon class="text-[20px]">close</mat-icon>
          </button>
        </div>

        <!-- Body -->
        <div class="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-slate-200">
          <!-- Active Progress Bar if Optimising -->
          @if (state.isOptimising()) {
            <div class="p-4 rounded-lg bg-[#0e1729] border border-blue-500/50 space-y-2">
              <div class="flex items-center justify-between text-xs font-mono">
                <span class="text-blue-400 font-semibold uppercase">
                  OPTIMISING NETWORK... {{ state.optimisingProgress() }}%
                </span>
                <span class="text-slate-400">{{ state.optimisingStage() }}</span>
              </div>
              <div class="w-full bg-[#172238] rounded-full h-2.5 overflow-hidden">
                <div
                  class="bg-blue-500 h-2.5 rounded-full transition-all duration-300"
                  [style.width.%]="state.optimisingProgress()"
                ></div>
              </div>
            </div>
          }

          <!-- Objective Weightings Sliders -->
          <div>
            <div class="flex items-center justify-between mb-3">
              <h3 class="text-xs font-mono uppercase text-slate-400 tracking-wider font-semibold">
                Objective Function Weights (Sum: 100%)
              </h3>
              <button
                type="button"
                (click)="resetDefaultWeights()"
                class="text-[11px] text-blue-400 hover:text-blue-300 cursor-pointer"
              >
                Reset Defaults
              </button>
            </div>

            <div class="space-y-3.5 bg-[#0e1524] border border-[#1e2a42] p-4 rounded-lg">
              <!-- Travel Time Weight -->
              <div>
                <div class="flex justify-between text-[11px] font-mono mb-1">
                  <span class="text-slate-300">MINIMUM TRAVEL TIME</span>
                  <span class="text-blue-400 font-bold">{{ state.optimiserWeights().travelTimeWeight }}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  [value]="state.optimiserWeights().travelTimeWeight"
                  (input)="updateWeight('travelTimeWeight', $event)"
                  class="w-full accent-blue-500 cursor-pointer"
                />
              </div>

              <!-- CAPEX Weight -->
              <div>
                <div class="flex justify-between text-[11px] font-mono mb-1">
                  <span class="text-slate-300">MINIMUM CAPEX &amp; INFRASTRUCTURE COST</span>
                  <span class="text-emerald-400 font-bold">{{ state.optimiserWeights().capexWeight }}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  [value]="state.optimiserWeights().capexWeight"
                  (input)="updateWeight('capexWeight', $event)"
                  class="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <!-- Demand Weight -->
              <div>
                <div class="flex justify-between text-[11px] font-mono mb-1">
                  <span class="text-slate-300">MAXIMUM PASSENGER DEMAND &amp; AIRPORT SHIFT</span>
                  <span class="text-sky-400 font-bold">{{ state.optimiserWeights().demandWeight }}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  [value]="state.optimiserWeights().demandWeight"
                  (input)="updateWeight('demandWeight', $event)"
                  class="w-full accent-sky-500 cursor-pointer"
                />
              </div>

              <!-- Emissions Weight -->
              <div>
                <div class="flex justify-between text-[11px] font-mono mb-1">
                  <span class="text-slate-300">MINIMUM CO&sup2; EMISSIONS &amp; DECARBONISATION</span>
                  <span class="text-emerald-400 font-bold">{{ state.optimiserWeights().emissionsWeight }}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  [value]="state.optimiserWeights().emissionsWeight"
                  (input)="updateWeight('emissionsWeight', $event)"
                  class="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <!-- Connectivity Weight -->
              <div>
                <div class="flex justify-between text-[11px] font-mono mb-1">
                  <span class="text-slate-300">MAXIMUM TRANS-EUROPEAN CONNECTIVITY</span>
                  <span class="text-purple-400 font-bold">{{ state.optimiserWeights().connectivityWeight }}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  [value]="state.optimiserWeights().connectivityWeight"
                  (input)="updateWeight('connectivityWeight', $event)"
                  class="w-full accent-purple-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          <!-- Optimisation History & Comparative Versions -->
          <div>
            <h3 class="text-xs font-mono uppercase text-slate-400 mb-3 tracking-wider font-semibold">
              Optimised Network Variants
            </h3>

            @if (state.optimisedVariants().length === 0) {
              <div class="p-6 text-center text-slate-500 bg-[#0e1524] rounded-lg border border-[#1e2a42]">
                <p>No optimization runs executed yet. Adjust weights above and click "Run Optimiser".</p>
              </div>
            } @else {
              <div class="space-y-2.5">
                @for (v of state.optimisedVariants(); track v.versionCode) {
                  <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#202e48] space-y-2">
                    <div class="flex items-center justify-between pb-1.5 border-b border-[#1b273e]">
                      <div class="flex items-center gap-2">
                        <span class="font-bold text-white font-mono">{{ v.versionCode }}</span>
                        <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                          Score: {{ v.score }} / 100
                        </span>
                      </div>
                      <span class="text-[11px] font-mono text-emerald-400 font-semibold">
                        &euro;{{ v.totalCapexEurBillion }}B &bull; {{ v.totalLengthKm }} km
                      </span>
                    </div>

                    <p class="text-[11px] text-slate-300 leading-relaxed font-sans">
                      {{ v.deltaSummary }}
                    </p>

                    <div class="grid grid-cols-3 gap-2 text-[10px] font-mono text-slate-400 pt-1">
                      <span>Demand: <strong class="text-white">{{ v.annualPaxMillion }} M pax/yr</strong></span>
                      <span>CO&sup2; Avoided: <strong class="text-emerald-400">{{ v.annualCo2AvoidedMt }} Mt/yr</strong></span>
                      <span>Avg Speed: <strong class="text-white">{{ v.averageSpeedKmh }} km/h</strong></span>
                    </div>
                  </div>
                }
              </div>
            }
          </div>
        </div>

        <!-- Footer -->
        <div class="px-6 py-4 bg-[#0e1524] border-t border-[#1f2c44] flex items-center justify-between shrink-0">
          <span class="text-xs font-mono text-slate-400">
            Next Version: <strong class="text-white">EURORAIL-OPT-v{{ state.networkVersionCounter() + 1 }}</strong>
          </span>
          <div class="flex items-center gap-3">
            <button
              type="button"
              (click)="state.showOptimiserModal.set(false)"
              class="px-4 py-2 text-xs text-slate-300 hover:text-white rounded transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              (click)="runSolver()"
              [disabled]="state.isOptimising()"
              class="px-4 py-2 text-xs font-semibold text-white bg-[#003399] hover:bg-[#1e40af] disabled:opacity-50 rounded shadow transition-colors cursor-pointer flex items-center gap-2"
            >
              <mat-icon class="text-[16px] leading-none">play_arrow</mat-icon>
              Run Network Optimisation
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AppOptimiserModal {
  public readonly state = inject(RailwayStateService);

  public updateWeight(key: keyof ReturnType<typeof this.state.optimiserWeights>, event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.optimiserWeights.update(w => ({
      ...w,
      [key]: val
    }));
  }

  public resetDefaultWeights(): void {
    this.state.optimiserWeights.set({
      travelTimeWeight: 30,
      capexWeight: 25,
      demandWeight: 20,
      emissionsWeight: 15,
      connectivityWeight: 10
    });
  }

  public runSolver(): void {
    this.state.triggerNetworkOptimisation();
  }
}
