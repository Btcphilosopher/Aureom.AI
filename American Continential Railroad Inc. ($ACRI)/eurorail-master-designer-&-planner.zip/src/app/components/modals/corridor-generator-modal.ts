import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { CityNode, CorridorAlignment } from '../../core/domain/railway.models';
import { GeospatialEngine } from '../../core/geospatial/geospatial-engine';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-corridor-generator-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4">
      <div class="w-full max-w-4xl bg-[#0c121e] border border-[#22314d] rounded-xl shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
        <!-- Modal Header -->
        <div class="px-6 py-4 bg-[#0f1726] border-b border-[#202d45] flex items-center justify-between shrink-0">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded bg-[#003399] flex items-center justify-center text-white">
              <mat-icon class="text-[18px]">add_road</mat-icon>
            </div>
            <div>
              <h2 class="text-sm font-bold text-white uppercase font-mono tracking-wide">Automated Corridor Generator</h2>
              <p class="text-xs text-slate-400">Multi-criteria alignment synthesis and terrain profiling</p>
            </div>
          </div>
          <button
            type="button"
            (click)="state.showCorridorGeneratorModal.set(false)"
            class="text-slate-400 hover:text-white cursor-pointer"
          >
            <mat-icon class="text-[20px]">close</mat-icon>
          </button>
        </div>

        <!-- Generator Controls -->
        <div class="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-slate-200">
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label for="origin-select" class="block text-slate-400 font-mono text-[11px] uppercase mb-1">Origin Node</label>
              <select
                id="origin-select"
                [value]="originId()"
                (change)="onOriginChange($event)"
                class="w-full bg-[#121929] border border-[#26344d] rounded px-3 py-2 text-white font-medium focus:outline-none focus:border-blue-500 cursor-pointer"
              >
                @for (c of state.cities(); track c.id) {
                  <option [value]="c.id">{{ c.name }} ({{ c.countryCode }})</option>
                }
              </select>
            </div>

            <div>
              <label for="dest-select" class="block text-slate-400 font-mono text-[11px] uppercase mb-1">Destination Node</label>
              <select
                id="dest-select"
                [value]="destinationId()"
                (change)="onDestinationChange($event)"
                class="w-full bg-[#121929] border border-[#26344d] rounded px-3 py-2 text-white font-medium focus:outline-none focus:border-blue-500 cursor-pointer"
              >
                @for (c of state.cities(); track c.id) {
                  <option [value]="c.id">{{ c.name }} ({{ c.countryCode }})</option>
                }
              </select>
            </div>
          </div>

          <!-- Engineering Constraints Grid -->
          <div class="grid grid-cols-3 gap-4 p-4 rounded-lg bg-[#0e1524] border border-[#1d293f]">
            <div>
              <label for="speed-select" class="block text-slate-400 text-[11px] mb-1">Target Speed</label>
              <select
                id="speed-select"
                [value]="targetSpeed()"
                (change)="onSpeedChange($event)"
                class="w-full bg-[#141c2c] border border-[#2a3850] rounded px-2.5 py-1.5 text-white font-mono focus:outline-none cursor-pointer"
              >
                <option [value]="250">250 km/h (Mixed Traffic)</option>
                <option [value]="300">300 km/h (Standard HSR)</option>
                <option [value]="320">320 km/h (High-Speed Trunk)</option>
                <option [value]="350">350 km/h (Ultra High-Speed)</option>
              </select>
            </div>

            <div>
              <label for="gradient-select" class="block text-slate-400 text-[11px] mb-1">Max Gradient</label>
              <select
                id="gradient-select"
                [value]="maxGradient()"
                (change)="onGradientChange($event)"
                class="w-full bg-[#141c2c] border border-[#2a3850] rounded px-2.5 py-1.5 text-white font-mono focus:outline-none cursor-pointer"
              >
                <option [value]="2.5">2.5% (Freight Compatible)</option>
                <option [value]="3.5">3.5% (Passenger HSR)</option>
                <option [value]="4.0">4.0% (Dedicated Alpine HSR)</option>
              </select>
            </div>

            <div>
              <label for="track-select" class="block text-slate-400 text-[11px] mb-1">Track Superstructure</label>
              <select id="track-select" class="w-full bg-[#141c2c] border border-[#2a3850] rounded px-2.5 py-1.5 text-white font-mono focus:outline-none cursor-pointer">
                <option>Slab Track (Rheda 2000)</option>
                <option>Ballasted Track (Heavy UIC 60)</option>
              </select>
            </div>
          </div>

          <!-- Candidate Alignment Comparison (Corridor A vs Corridor B) -->
          <div>
            <h3 class="text-xs font-mono uppercase text-slate-400 mb-3 tracking-wider font-semibold">
              Candidate Alignment Alternatives
            </h3>

            <div class="grid grid-cols-2 gap-4">
              <!-- CORRIDOR A: Direct High-Speed Trunk -->
              <button
                type="button"
                (click)="selectedVariant.set('A')"
                [class.border-blue-500]="selectedVariant() === 'A'"
                [class.bg-[#121c2e]]="selectedVariant() === 'A'"
                class="w-full text-left p-4 rounded-lg bg-[#0e1626] border border-[#202e47] hover:border-blue-400 transition-all cursor-pointer relative"
              >
                <div class="flex items-center justify-between mb-2">
                  <span class="text-xs font-mono font-bold text-blue-400">CORRIDOR A (Direct Trunk)</span>
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950 border border-blue-800 text-blue-300">
                    Optimal Journey Time
                  </span>
                </div>
                <p class="text-[11px] text-slate-400 mb-3">
                  Direct tangent alignment with deep base tunnels through mountain passes.
                </p>

                <div class="space-y-1.5 font-mono text-[11px] text-slate-300">
                  <div class="flex justify-between">
                    <span class="text-slate-500">Distance:</span>
                    <span class="text-white font-bold">{{ candidateA().distanceKm }} km</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-500">Est. Travel Time:</span>
                    <span class="text-emerald-400 font-bold">{{ candidateA().estimatedJourneyTimeMinutes }} min</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-500">Tunnel Section:</span>
                    <span class="text-sky-300">{{ candidateA().tunnelPercentage }}% ({{ candidateA().tunnelLengthKm }} km)</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-500">Viaduct Section:</span>
                    <span class="text-sky-300">{{ candidateA().bridgePercentage }}% ({{ candidateA().bridgeLengthKm }} km)</span>
                  </div>
                  <div class="flex justify-between pt-1 border-t border-[#1a253a]">
                    <span class="text-slate-500">Estimated CAPEX:</span>
                    <span class="text-emerald-400 font-bold">&euro;{{ candidateA().capexEurBillion }}B</span>
                  </div>
                </div>
              </button>

              <!-- CORRIDOR B: Terrain-Following Alternative -->
              <button
                type="button"
                (click)="selectedVariant.set('B')"
                [class.border-blue-500]="selectedVariant() === 'B'"
                [class.bg-[#121c2e]]="selectedVariant() === 'B'"
                class="w-full text-left p-4 rounded-lg bg-[#0e1626] border border-[#202e47] hover:border-blue-400 transition-all cursor-pointer relative"
              >
                <div class="flex items-center justify-between mb-2">
                  <span class="text-xs font-mono font-bold text-sky-400">CORRIDOR B (Terrain-Following)</span>
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-300">
                    Lower Civil Cost
                  </span>
                </div>
                <p class="text-[11px] text-slate-400 mb-3">
                  Valley-conforming alignment minimizing deep tunneling at slight travel time penalty.
                </p>

                <div class="space-y-1.5 font-mono text-[11px] text-slate-300">
                  <div class="flex justify-between">
                    <span class="text-slate-500">Distance:</span>
                    <span class="text-white font-bold">{{ candidateB().distanceKm }} km</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-500">Est. Travel Time:</span>
                    <span class="text-emerald-400 font-bold">{{ candidateB().estimatedJourneyTimeMinutes }} min</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-500">Tunnel Section:</span>
                    <span class="text-sky-300">{{ candidateB().tunnelPercentage }}% ({{ candidateB().tunnelLengthKm }} km)</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-slate-500">Viaduct Section:</span>
                    <span class="text-sky-300">{{ candidateB().bridgePercentage }}% ({{ candidateB().bridgeLengthKm }} km)</span>
                  </div>
                  <div class="flex justify-between pt-1 border-t border-[#1a253a]">
                    <span class="text-slate-500">Estimated CAPEX:</span>
                    <span class="text-emerald-400 font-bold">&euro;{{ candidateB().capexEurBillion }}B</span>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>

        <!-- Modal Footer -->
        <div class="px-6 py-4 bg-[#0e1524] border-t border-[#1f2c44] flex items-center justify-between shrink-0">
          <div class="text-xs text-slate-400 font-mono">
            Selected Alternative: <strong class="text-white">Corridor {{ selectedVariant() }}</strong>
          </div>
          <div class="flex items-center gap-3">
            <button
              type="button"
              (click)="state.showCorridorGeneratorModal.set(false)"
              class="px-4 py-2 text-xs text-slate-300 hover:text-white hover:bg-[#1a2336] rounded font-medium transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              (click)="adoptCorridor()"
              class="px-4 py-2 text-xs font-semibold text-white bg-[#003399] hover:bg-[#1e40af] rounded shadow transition-colors cursor-pointer"
            >
              Adopt Alignment into Network
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AppCorridorGeneratorModal {
  public readonly state = inject(RailwayStateService);

  public originId = signal<string>('PAR');
  public destinationId = signal<string>('BER');
  public targetSpeed = signal<250 | 300 | 320 | 350>(320);
  public maxGradient = signal<number>(3.5);
  public selectedVariant = signal<'A' | 'B'>('A');

  public readonly originNode = computed<CityNode>(() => {
    return this.state.cities().find(c => c.id === this.originId()) ?? this.state.cities()[0];
  });

  public readonly destNode = computed<CityNode>(() => {
    return this.state.cities().find(c => c.id === this.destinationId()) ?? this.state.cities()[1];
  });

  public readonly candidateA = computed(() => {
    return GeospatialEngine.generateCandidateCorridor(
      this.originNode(),
      this.destNode(),
      'DIRECT_TRUNK',
      this.targetSpeed(),
      this.maxGradient()
    );
  });

  public readonly candidateB = computed(() => {
    return GeospatialEngine.generateCandidateCorridor(
      this.originNode(),
      this.destNode(),
      'TERRAIN_FOLLOWING',
      this.targetSpeed(),
      this.maxGradient()
    );
  });

  public onOriginChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.originId.set(val);
  }

  public onDestinationChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.destinationId.set(val);
  }

  public onSpeedChange(event: Event): void {
    const val = Number((event.target as HTMLSelectElement).value) as 250 | 300 | 320 | 350;
    this.targetSpeed.set(val);
  }

  public onGradientChange(event: Event): void {
    const val = Number((event.target as HTMLSelectElement).value);
    this.maxGradient.set(val);
  }

  public adoptCorridor(): void {
    const chosen = this.selectedVariant() === 'A' ? this.candidateA() : this.candidateB();
    const orig = this.originNode();
    const dest = this.destNode();

    const newId = `COR-${orig.id}-${dest.id}`;
    const newCorridor: CorridorAlignment = {
      id: newId,
      code: `ER-C${this.state.corridors().length + 1}`,
      name: `${orig.name}–${dest.name} High-Speed Corridor`,
      originId: orig.id,
      destinationId: dest.id,
      intermediateStationIds: [],
      waypoints: chosen.waypoints ?? [
        { lat: orig.lat, lng: orig.lng, elevation: orig.elevation },
        { lat: dest.lat, lng: dest.lng, elevation: dest.elevation }
      ],
      distanceKm: chosen.distanceKm ?? 500,
      designSpeedKmh: chosen.designSpeedKmh ?? 320,
      maxGradientPercent: chosen.maxGradientPercent ?? 3.5,
      minCurveRadiusM: chosen.minCurveRadiusM ?? 6500,
      appliedCantMm: chosen.appliedCantMm ?? 150,
      cantDeficiencyMm: chosen.cantDeficiencyMm ?? 95,
      trackStructure: 'SLAB_TRACK',
      gaugeMm: 1435,
      signaling: 'ETCS_L2',
      electrification: '25KV_50HZ_AC',
      status: 'PROPOSED',
      scenarioId: this.state.activeScenarioId(),
      tunnelSections: chosen.tunnelSections ?? [],
      bridgeSections: chosen.bridgeSections ?? [],
      tunnelLengthKm: chosen.tunnelLengthKm ?? 0,
      tunnelPercentage: chosen.tunnelPercentage ?? 0,
      bridgeLengthKm: chosen.bridgeLengthKm ?? 0,
      bridgePercentage: chosen.bridgePercentage ?? 0,
      crossSectionPoints: chosen.crossSectionPoints ?? [],
      headwayMinutes: 3,
      trainsPerHour: 6,
      theoreticalCapacityTph: 16,
      capacityUtilizationPercent: 38,
      capexEurBillion: chosen.capexEurBillion ?? 12.5,
      annualOpexEurMillion: Math.round((chosen.distanceKm ?? 500) * 0.28),
      projectedAnnualPaxMillion: 14.5,
      co2AvoidedAnnualTonnes: Math.round((chosen.distanceKm ?? 500) * 14.5 * 170),
      estimatedJourneyTimeMinutes: chosen.estimatedJourneyTimeMinutes ?? 150,
      countriesTraversed: [orig.countryCode, dest.countryCode],
      voltageSwitchCount: 1,
      signalingBoundaries: 1
    };

    this.state.addGeneratedCorridor(newCorridor);
    this.state.showCorridorGeneratorModal.set(false);
  }
}
