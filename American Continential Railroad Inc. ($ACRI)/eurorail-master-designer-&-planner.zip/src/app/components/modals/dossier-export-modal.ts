import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-dossier-export-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4">
      <div class="w-full max-w-4xl bg-[#0c121e] border border-[#22314d] rounded-xl shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
        <!-- Header -->
        <div class="px-6 py-4 bg-[#0f1726] border-b border-[#202d45] flex items-center justify-between shrink-0">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded bg-[#003399] flex items-center justify-center text-white">
              <mat-icon class="text-[18px]">assessment</mat-icon>
            </div>
            <div>
              <h2 class="text-sm font-bold text-white uppercase font-mono tracking-wide">EURORAIL Engineering Master Dossier</h2>
              <p class="text-xs text-slate-400">Executive Technical Review, Environmental Auditing &amp; Multi-Format Export</p>
            </div>
          </div>
          <button
            type="button"
            (click)="state.showDossierExportModal.set(false)"
            class="text-slate-400 hover:text-white cursor-pointer"
          >
            <mat-icon class="text-[20px]">close</mat-icon>
          </button>
        </div>

        <!-- Body -->
        <div class="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-slate-200">
          <!-- Executive Network KPI Scorecard -->
          <div class="grid grid-cols-4 gap-3">
            <div class="p-3 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Network Length</span>
              <span class="text-lg font-bold font-mono text-white">{{ state.networkTotalLengthKm() | number }} km</span>
            </div>

            <div class="p-3 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Total CAPEX</span>
              <span class="text-lg font-bold font-mono text-emerald-400">&euro;{{ state.networkTotalCapexBillion() }}B</span>
            </div>

            <div class="p-3 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Annual Passengers</span>
              <span class="text-lg font-bold font-mono text-sky-400">{{ state.networkTotalAnnualPaxMillion() }} M pax</span>
            </div>

            <div class="p-3 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Annual CO&sup2; Avoided</span>
              <span class="text-lg font-bold font-mono text-emerald-400">{{ state.networkTotalCo2AvoidedMt() }} Mt / yr</span>
            </div>
          </div>

          <!-- Corridors Breakdown Table -->
          <div>
            <h3 class="text-xs font-mono uppercase text-slate-400 mb-2 tracking-wider font-semibold">
              Active Corridors Technical Inventory
            </h3>
            <div class="border border-[#1e2a42] rounded-lg overflow-hidden">
              <table class="w-full text-left text-xs font-mono">
                <thead class="bg-[#111828] text-slate-400 text-[10px] uppercase border-b border-[#1e2a42]">
                  <tr>
                    <th class="px-3 py-2">Code</th>
                    <th class="px-3 py-2">Name</th>
                    <th class="px-3 py-2 text-right">Distance</th>
                    <th class="px-3 py-2 text-right">Speed</th>
                    <th class="px-3 py-2 text-right">Tunnels</th>
                    <th class="px-3 py-2 text-right">Bridges</th>
                    <th class="px-3 py-2 text-right">CAPEX</th>
                    <th class="px-3 py-2 text-center">Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#182236] bg-[#0c121e]">
                  @for (c of state.activeScenarioCorridors(); track c.id) {
                    <tr class="hover:bg-[#131b2b]">
                      <td class="px-3 py-2 font-bold text-blue-400">{{ c.code }}</td>
                      <td class="px-3 py-2 text-slate-200">{{ c.name }}</td>
                      <td class="px-3 py-2 text-right">{{ c.distanceKm }} km</td>
                      <td class="px-3 py-2 text-right">{{ c.designSpeedKmh }} km/h</td>
                      <td class="px-3 py-2 text-right text-sky-300">{{ c.tunnelPercentage }}%</td>
                      <td class="px-3 py-2 text-right text-sky-300">{{ c.bridgePercentage }}%</td>
                      <td class="px-3 py-2 text-right text-emerald-400 font-semibold">&euro;{{ c.capexEurBillion }}B</td>
                      <td class="px-3 py-2 text-center">
                        <span class="text-[9px] px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                          {{ c.status }}
                        </span>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- Engineering Model Assumptions & Standards -->
          <div class="p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-2 text-[11px] font-mono text-slate-300">
            <div class="font-bold text-white uppercase text-xs">Governing Equations &amp; SI Model Constants</div>
            <div class="grid grid-cols-2 gap-4 pt-1">
              <div>
                <span class="text-slate-500 block">Curve Radius Minimum (TSI):</span>
                <span>R_min = V&sup2; / [11.8 &times; (h_act + h_def)] &rarr; 6,500m @ 350 km/h</span>
              </div>
              <div>
                <span class="text-slate-500 block">Aerodynamic Train Drag (Davis):</span>
                <span>R = 4.8 + 0.082v + 0.0039v&sup2; (kN)</span>
              </div>
              <div>
                <span class="text-slate-500 block">Signaling &amp; Headway:</span>
                <span>ETCS Level 2 / FRMCS moving block; min headway 180s</span>
              </div>
              <div>
                <span class="text-slate-500 block">Social Discount Rate:</span>
                <span>EU DG-REGIO standard: 3.5% over 30-year operational horizon</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Footer with Multi-Format Export Buttons -->
        <div class="px-6 py-4 bg-[#0e1524] border-t border-[#1f2c44] flex items-center justify-between shrink-0">
          <div class="flex items-center gap-2">
            <button
              type="button"
              (click)="exportGeoJson()"
              class="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-[#141d2e] hover:bg-[#1f2c44] border border-[#263756] text-slate-200 rounded transition-colors cursor-pointer"
            >
              <mat-icon class="text-[16px] w-4 h-4 leading-none text-sky-400">code</mat-icon>
              Export GeoJSON (RFC 7946)
            </button>

            <button
              type="button"
              (click)="exportCsv()"
              class="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-[#141d2e] hover:bg-[#1f2c44] border border-[#263756] text-slate-200 rounded transition-colors cursor-pointer"
            >
              <mat-icon class="text-[16px] w-4 h-4 leading-none text-emerald-400">table_chart</mat-icon>
              Export CSV Inventory
            </button>

            <button
              type="button"
              (click)="exportJson()"
              class="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-[#141d2e] hover:bg-[#1f2c44] border border-[#263756] text-slate-200 rounded transition-colors cursor-pointer"
            >
              <mat-icon class="text-[16px] w-4 h-4 leading-none text-purple-400">data_object</mat-icon>
              Export Full JSON
            </button>
          </div>

          <button
            type="button"
            (click)="printDossier()"
            class="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#003399] hover:bg-[#1e40af] rounded shadow transition-colors cursor-pointer"
          >
            <mat-icon class="text-[16px] w-4 h-4 leading-none">print</mat-icon>
            Print / PDF Report
          </button>
        </div>
      </div>
    </div>
  `
})
export class AppDossierExportModal {
  public readonly state = inject(RailwayStateService);

  public exportGeoJson(): void {
    const jsonStr = this.state.exportNetworkGeoJson();
    this.downloadFile(jsonStr, `EURORAIL-${this.state.activeScenario().code}-Dossier.geojson`, 'application/geo+json');
  }

  public exportCsv(): void {
    const csvStr = this.state.exportNetworkCsv();
    this.downloadFile(csvStr, `EURORAIL-${this.state.activeScenario().code}-Inventory.csv`, 'text/csv');
  }

  public exportJson(): void {
    const fullState = {
      scenario: this.state.activeScenario(),
      corridors: this.state.activeScenarioCorridors(),
      fleet: this.state.trainsets(),
      packages: this.state.constructionPackages(),
      risks: this.state.riskItems()
    };
    this.downloadFile(JSON.stringify(fullState, null, 2), `EURORAIL-${this.state.activeScenario().code}-FullData.json`, 'application/json');
  }

  public printDossier(): void {
    window.print();
  }

  private downloadFile(content: string, filename: string, type: string): void {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
