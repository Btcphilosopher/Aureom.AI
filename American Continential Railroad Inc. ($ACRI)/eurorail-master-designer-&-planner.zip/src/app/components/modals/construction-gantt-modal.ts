import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-construction-gantt-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4">
      <div class="w-full max-w-4xl bg-[#0c121e] border border-[#22314d] rounded-xl shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
        <!-- Header -->
        <div class="px-6 py-4 bg-[#0f1726] border-b border-[#202d45] flex items-center justify-between shrink-0">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded bg-[#003399] flex items-center justify-center text-white">
              <mat-icon class="text-[18px]">timeline</mat-icon>
            </div>
            <div>
              <h2 class="text-sm font-bold text-white uppercase font-mono tracking-wide">Infrastructure Work Packages &amp; Gantt Schedule</h2>
              <p class="text-xs text-slate-400">Civil works, base tunnel boring, superstructure, and ETCS commissioning</p>
            </div>
          </div>
          <button
            type="button"
            (click)="state.showConstructionGanttModal.set(false)"
            class="text-slate-400 hover:text-white cursor-pointer"
          >
            <mat-icon class="text-[20px]">close</mat-icon>
          </button>
        </div>

        <!-- Body -->
        <div class="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-slate-200">
          <!-- Timeline Year Header Strip -->
          <div class="flex items-center justify-between px-4 py-2 rounded bg-[#0e1626] border border-[#1d293f] text-xs font-mono text-slate-400">
            <span>Package ID &amp; Contractor</span>
            <div class="flex items-center gap-6">
              <span>2024</span>
              <span>2026</span>
              <span>2028</span>
              <span>2030</span>
              <span>2032</span>
              <span>2034</span>
            </div>
          </div>

          <!-- Packages List -->
          <div class="space-y-3">
            @for (pkg of state.constructionPackages(); track pkg.id) {
              <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1f2c44] space-y-2">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="font-mono font-bold text-blue-400 text-xs">{{ pkg.code }}</span>
                    <span class="font-semibold text-white text-xs">{{ pkg.title }}</span>
                  </div>
                  <span [class]="getStatusClass(pkg.status)" class="text-[10px] font-mono font-medium px-2 py-0.5 rounded uppercase">
                    {{ pkg.status }} ({{ pkg.progressPercent }}%)
                  </span>
                </div>

                <p class="text-[11px] text-slate-400">
                  {{ pkg.scope }}
                </p>

                <!-- Gantt Bar Representation -->
                <div class="pt-2">
                  <div class="w-full bg-[#141d2e] rounded h-5 p-0.5 relative overflow-hidden flex items-center">
                    <div
                      class="h-4 rounded bg-gradient-to-r from-blue-700 to-sky-500 flex items-center px-2 text-[10px] font-mono text-white font-semibold transition-all"
                      [style.margin-left.%]="getYearOffsetPercent(pkg.startYear)"
                      [style.width.%]="getYearWidthPercent(pkg.startYear, pkg.endYear)"
                    >
                      <span class="truncate">{{ pkg.startYear }} &ndash; {{ pkg.endYear }}</span>
                    </div>
                  </div>
                </div>

                <div class="flex items-center justify-between pt-1 border-t border-[#182338] text-[11px] font-mono text-slate-400">
                  <span>Contractor: <strong class="text-slate-200">{{ pkg.contractor }}</strong></span>
                  <span>CAPEX: <strong class="text-emerald-400">&euro;{{ pkg.costEurMillion | number }}M</strong></span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Footer -->
        <div class="px-6 py-4 bg-[#0e1524] border-t border-[#1f2c44] flex items-center justify-between shrink-0">
          <span class="text-xs font-mono text-slate-400">
            Total Committed Contract Value: <strong class="text-emerald-400">&euro;10,420M</strong>
          </span>
          <button
            type="button"
            (click)="state.showConstructionGanttModal.set(false)"
            class="px-4 py-2 text-xs font-semibold text-white bg-[#003399] hover:bg-[#1e40af] rounded shadow transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  `
})
export class AppConstructionGanttModal {
  public readonly state = inject(RailwayStateService);

  public getYearOffsetPercent(startYear: number): number {
    return Math.max(0, Math.min(80, ((startYear - 2023) / 12) * 100));
  }

  public getYearWidthPercent(startYear: number, endYear: number): number {
    return Math.max(15, Math.min(80, ((endYear - startYear) / 12) * 100));
  }

  public getStatusClass(status: string): string {
    switch (status) {
      case 'IN_PROGRESS':
        return 'bg-blue-950 text-blue-300 border border-blue-800';
      case 'AWARDED':
        return 'bg-amber-950 text-amber-300 border border-amber-800';
      case 'COMPLETED':
        return 'bg-emerald-950 text-emerald-300 border border-emerald-800';
      default:
        return 'bg-slate-800 text-slate-300 border border-slate-700';
    }
  }
}
