import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { CityNode, StationType } from '../../core/domain/railway.models';
import { MatIconModule } from '@angular/material/icon';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-station-designer-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4">
      <div class="w-full max-w-4xl bg-[#0c121e] border border-[#22314d] rounded-xl shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
        <!-- Header -->
        <div class="px-6 py-4 bg-[#0f1726] border-b border-[#202d45] flex items-center justify-between shrink-0">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded bg-[#003399] flex items-center justify-center text-white">
              <mat-icon class="text-[18px]">domain</mat-icon>
            </div>
            <div>
              <h2 class="text-sm font-bold text-white uppercase font-mono tracking-wide">Station Hub &amp; Interchange Designer</h2>
              <p class="text-xs text-slate-400">Platform capacity, passenger circulation throughput, and intermodal connectivity</p>
            </div>
          </div>
          <button
            type="button"
            (click)="state.showStationDesignerModal.set(false)"
            class="text-slate-400 hover:text-white cursor-pointer"
          >
            <mat-icon class="text-[20px]">close</mat-icon>
          </button>
        </div>

        <!-- Body -->
        <div class="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-slate-200">
          <!-- Station Selector -->
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label for="hub-select" class="block text-slate-400 font-mono text-[11px] uppercase mb-1">Select Station Hub</label>
              <select
                id="hub-select"
                [value]="selectedStationId()"
                (change)="onStationChange($event)"
                class="w-full bg-[#121929] border border-[#26344d] rounded px-3 py-2 text-white font-medium focus:outline-none cursor-pointer"
              >
                @for (c of state.cities(); track c.id) {
                  <option [value]="c.id">{{ c.name }} Central ({{ c.country }})</option>
                }
              </select>
            </div>

            <div>
              <label for="topology-select" class="block text-slate-400 font-mono text-[11px] uppercase mb-1">Hub Topology Configuration</label>
              <select
                id="topology-select"
                [value]="currentStation().stationType"
                (change)="onTypeChange($event)"
                class="w-full bg-[#121929] border border-[#26344d] rounded px-3 py-2 text-white font-medium focus:outline-none cursor-pointer"
              >
                <option value="INTERCHANGE_HUB">Major European Interchange Hub</option>
                <option value="TERMINUS">High-Capacity Terminus</option>
                <option value="THROUGH">Four-Track Through Station</option>
                <option value="UNDERGROUND">Sub-surface Underground Station</option>
                <option value="AIRPORT_INTERMODAL">Airport Intermodal Station</option>
              </select>
            </div>
          </div>

          <!-- Capacity & Platform Metrics Cards -->
          <div class="grid grid-cols-4 gap-3">
            <div class="p-3 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Platforms</span>
              <div class="flex items-baseline gap-2 mt-1">
                <span class="text-xl font-bold font-mono text-white">{{ platformCount() }}</span>
                <span class="text-[11px] text-slate-400">tracks (400m UIC)</span>
              </div>
            </div>

            <div class="p-3 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Peak Throughput</span>
              <div class="flex items-baseline gap-2 mt-1">
                <span class="text-xl font-bold font-mono text-emerald-400">{{ peakThroughputPaxPerHour() | number }}</span>
                <span class="text-[11px] text-slate-400">pax / hr</span>
              </div>
            </div>

            <div class="p-3 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Dwell Time Target</span>
              <div class="flex items-baseline gap-2 mt-1">
                <span class="text-xl font-bold font-mono text-sky-400">{{ dwellMinutes() }}</span>
                <span class="text-[11px] text-slate-400">minutes</span>
              </div>
            </div>

            <div class="p-3 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Platform Utilisation</span>
              <div class="flex items-baseline gap-2 mt-1">
                <span class="text-xl font-bold font-mono text-amber-400">{{ platformUtilisationPercent() }}%</span>
                <span class="text-[11px] text-slate-400">nominal peak</span>
              </div>
            </div>
          </div>

          <!-- Platform Layout CAD Schematic -->
          <div>
            <div class="flex items-center justify-between mb-2">
              <h3 class="text-xs font-mono uppercase text-slate-400 tracking-wider font-semibold">
                Platform Tracks &amp; Concourse Schematic (400m UIC High-Speed Standard)
              </h3>
              <div class="flex items-center gap-2">
                <button
                  type="button"
                  (click)="adjustPlatforms(-2)"
                  class="px-2 py-0.5 bg-[#141b2a] hover:bg-[#1f293d] border border-[#222d42] text-slate-300 rounded font-mono cursor-pointer"
                >
                  -2 Tracks
                </button>
                <button
                  type="button"
                  (click)="adjustPlatforms(2)"
                  class="px-2 py-0.5 bg-[#141b2a] hover:bg-[#1f293d] border border-[#222d42] text-slate-300 rounded font-mono cursor-pointer"
                >
                  +2 Tracks
                </button>
              </div>
            </div>

            <div class="bg-[#0a0f1c] border border-[#1e293f] rounded-lg p-4 space-y-2">
              <!-- Concourse Bar -->
              <div class="h-8 bg-[#182338] border border-[#263757] rounded flex items-center justify-between px-4 text-xs font-mono text-sky-300">
                <span class="flex items-center gap-2">
                  <mat-icon class="text-[16px]">stairs</mat-icon>
                  CENTRAL CONCOURSE &amp; TICKETING HALL
                </span>
                <span class="text-[10px] text-slate-400">Vertical circulation: 16 high-speed escalators &bull; 8 lifts</span>
              </div>

              <!-- Tracks Graphic -->
              <div class="space-y-1.5 pt-2">
                @for (p of trackList(); track p) {
                  <div class="flex items-center gap-3">
                    <span class="w-12 text-[10px] font-mono text-slate-400 text-right">T-{{ p }}</span>
                    <div class="flex-1 h-3.5 bg-[#121929] border-y border-[#26334d] flex items-center px-2 relative rounded-xs">
                      <!-- Railway sleeper track ticks -->
                      <div class="w-full h-0.5 bg-slate-600"></div>
                      <span class="absolute right-3 text-[9px] font-mono text-slate-500">400m UIC / 25kV Catenary</span>
                    </div>
                    <span class="w-20 text-[10px] font-mono text-emerald-400">P{{ Math.ceil(p / 2) }}</span>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- Intermodal Connectivity Matrix -->
          <div>
            <h3 class="text-xs font-mono uppercase text-slate-400 mb-2 tracking-wider font-semibold">
              Intermodal Urban Links
            </h3>
            <div class="grid grid-cols-5 gap-2">
              <div class="p-2.5 rounded bg-[#0e1626] border border-[#1e2a42] text-center">
                <mat-icon class="text-[20px] text-sky-400 mb-1">subway</mat-icon>
                <div class="text-[11px] font-semibold text-white">Metro Network</div>
                <div class="text-[10px] text-slate-400 font-mono">Lines: 4 connections</div>
              </div>

              <div class="p-2.5 rounded bg-[#0e1626] border border-[#1e2a42] text-center">
                <mat-icon class="text-[20px] text-blue-400 mb-1">train</mat-icon>
                <div class="text-[11px] font-semibold text-white">RER / S-Bahn</div>
                <div class="text-[10px] text-slate-400 font-mono">Lines: 3 regional</div>
              </div>

              <div class="p-2.5 rounded bg-[#0e1626] border border-[#1e2a42] text-center">
                <mat-icon class="text-[20px] text-emerald-400 mb-1">tram</mat-icon>
                <div class="text-[11px] font-semibold text-white">Surface Tramway</div>
                <div class="text-[10px] text-slate-400 font-mono">Platform level: 2</div>
              </div>

              <div class="p-2.5 rounded bg-[#0e1626] border border-[#1e2a42] text-center">
                <mat-icon class="text-[20px] text-purple-400 mb-1">flight</mat-icon>
                <div class="text-[11px] font-semibold text-white">Airport Rail Link</div>
                <div class="text-[10px] text-slate-400 font-mono">Direct 18 min shuttle</div>
              </div>

              <div class="p-2.5 rounded bg-[#0e1626] border border-[#1e2a42] text-center">
                <mat-icon class="text-[20px] text-amber-400 mb-1">directions_bus</mat-icon>
                <div class="text-[11px] font-semibold text-white">Intercity Coach</div>
                <div class="text-[10px] text-slate-400 font-mono">Terminal: 14 bays</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div class="px-6 py-4 bg-[#0e1524] border-t border-[#1f2c44] flex items-center justify-between shrink-0">
          <span class="text-xs font-mono text-slate-400">
            Station Status: <strong class="text-emerald-400">Fully Interoperable TSI PRM / High Speed</strong>
          </span>
          <button
            type="button"
            (click)="state.showStationDesignerModal.set(false)"
            class="px-4 py-2 text-xs font-semibold text-white bg-[#003399] hover:bg-[#1e40af] rounded shadow transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  `
})
export class AppStationDesignerModal {
  public readonly state = inject(RailwayStateService);
  protected readonly Math = Math;

  public selectedStationId = signal<string>('PAR');
  public platformCount = signal<number>(24);

  public readonly currentStation = computed<CityNode>(() => {
    return this.state.cities().find(c => c.id === this.selectedStationId()) ?? this.state.cities()[0];
  });

  public readonly trackList = computed(() => {
    const count = this.platformCount();
    return Array.from({ length: count }, (_, i) => i + 1);
  });

  public readonly dwellMinutes = computed(() => {
    const type = this.currentStation().stationType;
    if (type === 'TERMINUS') return 18;
    if (type === 'INTERCHANGE_HUB') return 4;
    return 2.5;
  });

  public readonly peakThroughputPaxPerHour = computed(() => {
    return this.platformCount() * 1250;
  });

  public readonly platformUtilisationPercent = computed(() => {
    return Math.min(88, Math.round(55 + (this.currentStation().population / 10000000) * 18));
  });

  public onStationChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.selectedStationId.set(val);
    const st = this.state.cities().find(c => c.id === val);
    if (st) {
      this.platformCount.set(st.platformsCount);
    }
  }

  public onTypeChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as StationType;
    this.state.cities.update(cities =>
      cities.map(c => (c.id === this.selectedStationId() ? { ...c, stationType: val } : c))
    );
  }

  public adjustPlatforms(delta: number): void {
    const newCount = Math.max(4, Math.min(36, this.platformCount() + delta));
    this.platformCount.set(newCount);
    this.state.cities.update(cities =>
      cities.map(c => (c.id === this.selectedStationId() ? { ...c, platformsCount: newCount } : c))
    );
  }
}
