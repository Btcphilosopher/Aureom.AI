import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { RailwayEngineeringEngine } from '../../core/engineering/railway-engineering-engine';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-engineering-cad-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="w-full h-full bg-[#0a0f19] flex flex-col p-6 overflow-y-auto select-none space-y-6 text-slate-200">
      <!-- Title Bar -->
      <div class="flex items-center justify-between pb-4 border-b border-[#1f2b42]">
        <div>
          <span class="text-xs font-mono uppercase text-blue-400 font-semibold tracking-wider">Civil Infrastructure &amp; Dynamic Physics</span>
          <h1 class="text-xl font-bold text-white tracking-tight">Railway Engineering CAD Console</h1>
        </div>

        <div class="flex items-center gap-3">
          <span class="text-xs font-mono text-slate-400">Target Corridor:</span>
          <select
            [value]="state.selectedCorridorId()"
            (change)="onCorridorSelect($event)"
            class="bg-[#121929] border border-[#26344d] text-white text-xs rounded px-3 py-1.5 font-medium cursor-pointer focus:outline-none"
          >
            @for (c of state.activeScenarioCorridors(); track c.id) {
              <option [value]="c.id">{{ c.code }} &ndash; {{ c.name }}</option>
            }
          </select>
        </div>
      </div>

      @if (state.selectedCorridor(); as cor) {
        <!-- Key Technical Specs Strip -->
        <div class="grid grid-cols-5 gap-3">
          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Design Speed</span>
            <span class="text-xl font-bold font-mono text-blue-400">{{ cor.designSpeedKmh }} km/h</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">TSI High Speed</span>
          </div>

          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Min Curve Radius (R_min)</span>
            <span class="text-xl font-bold font-mono text-white">{{ curveLimits().minCurveRadiusM }} m</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">Cant Def: {{ cor.cantDeficiencyMm }}mm</span>
          </div>

          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Max Gradient</span>
            <span class="text-xl font-bold font-mono text-emerald-400">{{ cor.maxGradientPercent }}%</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">Compensated Grade</span>
          </div>

          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Electrification</span>
            <span class="text-xl font-bold font-mono text-sky-400">25 kV AC</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">50 Hz / 48km spacing</span>
          </div>

          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Signaling System</span>
            <span class="text-xl font-bold font-mono text-purple-400">ETCS L2</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">Moving Block &bull; 180s Headway</span>
          </div>
        </div>

        <!-- Engineering Analysis Grid -->
        <div class="grid grid-cols-2 gap-6">
          <!-- Curvature & Track Geometry Model -->
          <div class="p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[18px] text-sky-400">straighten</mat-icon>
                <h3 class="text-xs font-bold uppercase font-mono text-white">Track Geometry &amp; Cant Deficiencies</h3>
              </div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                TSI Compliant
              </span>
            </div>

            <div class="space-y-3 font-mono text-xs">
              <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                <span class="text-slate-400">Actual Applied Cant (h_act):</span>
                <span class="text-white font-semibold">{{ cor.appliedCantMm }} mm</span>
              </div>
              <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                <span class="text-slate-400">Cant Deficiency (h_def):</span>
                <span class="text-white font-semibold">{{ cor.cantDeficiencyMm }} mm</span>
              </div>
              <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                <span class="text-slate-400">Equilibrium Velocity:</span>
                <span class="text-white font-semibold">{{ curveLimits().equilibriumSpeedKmh }} km/h</span>
              </div>
              <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                <span class="text-slate-400">Lateral Centrifugal Acceleration:</span>
                <span class="text-sky-400 font-semibold">{{ curveLimits().cantDeficiencyAccelerationMPerS2 }} m/s&sup2; (&le; 0.85 m/s&sup2;)</span>
              </div>
            </div>

            <div class="p-3 rounded bg-[#111724] border border-[#1a2336] text-[11px] text-slate-400 font-sans leading-relaxed">
              <strong>TSI Engineering Rule:</strong> At 350 km/h, the minimum radius must not fall below 6,500m to eliminate ballast displacement caused by aerodynamic train suction. Continuous slab track (Rheda 2000 system) is applied.
            </div>
          </div>

          <!-- Traction Power Demand & Substation Load -->
          <div class="p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[18px] text-amber-400">bolt</mat-icon>
                <h3 class="text-xs font-bold uppercase font-mono text-white">25kV Traction Power &amp; Substation Grid</h3>
              </div>
              <span class="text-[10px] font-mono text-slate-400">IEC 60850 Standard</span>
            </div>

            @if (electrificationSpec(); as elec) {
              <div class="space-y-3 font-mono text-xs">
                <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                  <span class="text-slate-400">Feeder Substations Required:</span>
                  <span class="text-white font-semibold">{{ elec.substationsRequiredCount }} substations</span>
                </div>
                <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                  <span class="text-slate-400">Substation Spacing:</span>
                  <span class="text-white font-semibold">{{ elec.catenarySubstationSpacingKm }} km</span>
                </div>
                <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                  <span class="text-slate-400">Peak Current Demand per Train:</span>
                  <span class="text-amber-400 font-semibold">{{ elec.peakCurrentAmperesPerTrain }} A @ 25kV</span>
                </div>
                <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                  <span class="text-slate-400">Catenary Transmission Loss:</span>
                  <span class="text-emerald-400 font-semibold">{{ elec.catenaryLossPercentage }}%</span>
                </div>
              </div>
            }

            <div class="p-3 rounded bg-[#111724] border border-[#1a2336] text-[11px] text-slate-400 font-sans leading-relaxed">
              <strong>Regenerative Grid Return:</strong> 16-18% of kinetic energy is returned to the European 400kV transmission grid during deceleration into hub stations through bidirectional autotransformers.
            </div>
          </div>
        </div>

        <!-- Train Dynamics Physics Verification (Davis Equation) -->
        <div class="p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
            <div class="flex items-center gap-2">
              <mat-icon class="text-[18px] text-blue-400">speed</mat-icon>
              <h3 class="text-xs font-bold uppercase font-mono text-white">Trainset Dynamics Verification: {{ state.activeTrainset().name }}</h3>
            </div>
            <span class="text-xs font-mono text-slate-400">Mass: {{ state.activeTrainset().loadedMassTonnes }}t &bull; Power: {{ state.activeTrainset().tractionPowerKw / 1000 }} MW</span>
          </div>

          <div class="grid grid-cols-4 gap-4 text-xs font-mono">
            <div class="p-3 rounded bg-[#131b2c]">
              <span class="text-slate-500 block text-[10px]">Mechanical Rolling Drag (A)</span>
              <span class="text-white font-bold">{{ state.activeTrainset().davisA }} kN</span>
            </div>
            <div class="p-3 rounded bg-[#131b2c]">
              <span class="text-slate-500 block text-[10px]">Velocity Proportional Drag (B)</span>
              <span class="text-white font-bold">{{ state.activeTrainset().davisB }} kN / (km/h)</span>
            </div>
            <div class="p-3 rounded bg-[#131b2c]">
              <span class="text-slate-500 block text-[10px]">Aerodynamic Suction Drag (C)</span>
              <span class="text-sky-400 font-bold">{{ state.activeTrainset().davisC }} kN / (km/h)&sup2;</span>
            </div>
            <div class="p-3 rounded bg-[#131b2c]">
              <span class="text-slate-500 block text-[10px]">Starting Acceleration Limit</span>
              <span class="text-emerald-400 font-bold">{{ state.activeTrainset().startingAccelerationMPerS2 }} m/s&sup2;</span>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class AppEngineeringCadView {
  public readonly state = inject(RailwayStateService);

  public readonly curveLimits = computed(() => {
    const cor = this.state.selectedCorridor();
    if (!cor) return RailwayEngineeringEngine.calculateCurveCantLimits(320);
    return RailwayEngineeringEngine.calculateCurveCantLimits(
      cor.designSpeedKmh,
      cor.appliedCantMm,
      cor.cantDeficiencyMm
    );
  });

  public readonly electrificationSpec = computed(() => {
    const cor = this.state.selectedCorridor();
    if (!cor) return null;
    return RailwayEngineeringEngine.calculateElectrificationDemand(
      cor.distanceKm,
      cor.electrification,
      cor.trainsPerHour,
      this.state.activeTrainset().tractionPowerKw
    );
  });

  public onCorridorSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.selectCorridor(val);
  }
}
