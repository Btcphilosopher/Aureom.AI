import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-executive-review-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe],
  template: `
    <div class="w-full h-full bg-[#0a0f19] flex flex-col p-6 overflow-y-auto select-none space-y-6 text-slate-200">
      <!-- Title Bar -->
      <div class="flex items-center justify-between pb-4 border-b border-[#1f2b42]">
        <div>
          <span class="text-xs font-mono uppercase text-purple-400 font-semibold tracking-wider">TEN-T High-Speed Executive Audit</span>
          <h1 class="text-xl font-bold text-white tracking-tight">Programme Strategic Review &amp; Digital Twin</h1>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="state.showDossierExportModal.set(true)"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#003399] hover:bg-[#1e40af] rounded shadow transition-colors cursor-pointer"
          >
            <mat-icon class="text-[16px] w-4 h-4 leading-none">article</mat-icon>
            Generate Comprehensive Dossier
          </button>
        </div>
      </div>

      <!-- Macro Executive KPI Scoreboard -->
      <div class="grid grid-cols-4 gap-4">
        <div class="p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
          <span class="text-[10px] uppercase text-slate-500 font-mono block">Active Corridors</span>
          <div class="text-2xl font-bold font-mono text-white mt-1">{{ state.activeScenarioCorridors().length }}</div>
          <span class="text-[11px] text-slate-400 font-mono">{{ state.networkTotalLengthKm() | number }} route-km</span>
        </div>

        <div class="p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
          <span class="text-[10px] uppercase text-slate-500 font-mono block">Committed Capital Expenditure</span>
          <div class="text-2xl font-bold font-mono text-emerald-400 mt-1">&euro;{{ state.networkTotalCapexBillion() }}B</div>
          <span class="text-[11px] text-slate-400 font-mono">Connecting Europe Facility (CEF) pooled</span>
        </div>

        <div class="p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
          <span class="text-[10px] uppercase text-slate-500 font-mono block">Annual Passenger Traffic</span>
          <div class="text-2xl font-bold font-mono text-sky-400 mt-1">{{ state.networkTotalAnnualPaxMillion() }} M</div>
          <span class="text-[11px] text-slate-400 font-mono">Gravity-model modal substitution</span>
        </div>

        <div class="p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
          <span class="text-[10px] uppercase text-slate-500 font-mono block">GHG Emissions Abatement</span>
          <div class="text-2xl font-bold font-mono text-emerald-400 mt-1">{{ state.networkTotalCo2AvoidedMt() }} Mt / yr</div>
          <span class="text-[11px] text-slate-400 font-mono">Net carbon displacement</span>
        </div>
      </div>

      <!-- Digital Twin Lifecycle Status Grid -->
      <div class="p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-4">
        <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
          <h3 class="text-xs font-bold uppercase font-mono text-white">Digital Twin Asset Lifecycle Governance</h3>
          <span class="text-[10px] font-mono text-slate-400">Stable ISO 19650 BIM Schema</span>
        </div>

        <div class="grid grid-cols-5 gap-3">
          <div class="p-3 rounded bg-[#121b2b] border border-emerald-900/40">
            <span class="text-[10px] font-mono font-bold text-emerald-400 block uppercase">Operational</span>
            <div class="text-xl font-bold font-mono text-white mt-1">{{ countStatus('OPERATIONAL') }}</div>
            <span class="text-[10px] text-slate-400 block mt-1">In active revenue service</span>
          </div>

          <div class="p-3 rounded bg-[#121b2b] border border-amber-900/40">
            <span class="text-[10px] font-mono font-bold text-amber-400 block uppercase">Under Construction</span>
            <div class="text-xl font-bold font-mono text-white mt-1">{{ countStatus('UNDER_CONSTRUCTION') }}</div>
            <span class="text-[10px] text-slate-400 block mt-1">Civil &amp; tunneling works live</span>
          </div>

          <div class="p-3 rounded bg-[#121b2b] border border-blue-900/40">
            <span class="text-[10px] font-mono font-bold text-sky-400 block uppercase">Designed &amp; Approved</span>
            <div class="text-xl font-bold font-mono text-white mt-1">{{ countStatus('DESIGNED') }}</div>
            <span class="text-[10px] text-slate-400 block mt-1">Environmental permits validated</span>
          </div>

          <div class="p-3 rounded bg-[#121b2b] border border-indigo-900/40">
            <span class="text-[10px] font-mono font-bold text-indigo-400 block uppercase">Planned Core Axis</span>
            <div class="text-xl font-bold font-mono text-white mt-1">{{ countStatus('PLANNED') }}</div>
            <span class="text-[10px] text-slate-400 block mt-1">Corridor study in progress</span>
          </div>

          <div class="p-3 rounded bg-[#121b2b] border border-purple-900/40">
            <span class="text-[10px] font-mono font-bold text-purple-400 block uppercase">Strategic Proposed</span>
            <div class="text-xl font-bold font-mono text-white mt-1">{{ countStatus('PROPOSED') }}</div>
            <span class="text-[10px] text-slate-400 block mt-1">Horizon feasibility draft</span>
          </div>
        </div>
      </div>

      <!-- Quick Action Buttons: Gantt, Risk, Optimiser -->
      <div class="grid grid-cols-3 gap-4">
        <button
          type="button"
          (click)="state.showConstructionGanttModal.set(true)"
          class="w-full text-left p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42] hover:border-blue-500 transition-colors cursor-pointer group"
        >
          <div class="flex items-center gap-3 mb-2">
            <mat-icon class="text-amber-400">timeline</mat-icon>
            <h4 class="text-xs font-bold text-white group-hover:text-blue-400">Construction Packages &amp; Gantt</h4>
          </div>
          <p class="text-[11px] text-slate-400">
            Audit work packages (civil, base tunnels, superstructure, ETCS) and contractors.
          </p>
        </button>

        <button
          type="button"
          (click)="state.showRiskMatrixModal.set(true)"
          class="w-full text-left p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42] hover:border-blue-500 transition-colors cursor-pointer group"
        >
          <div class="flex items-center gap-3 mb-2">
            <mat-icon class="text-rose-400">warning_amber</mat-icon>
            <h4 class="text-xs font-bold text-white group-hover:text-blue-400">Infrastructure Risk Matrix</h4>
          </div>
          <p class="text-[11px] text-slate-400">
            Quantitative matrix across geological, environmental, political, and financial hazards.
          </p>
        </button>

        <button
          type="button"
          (click)="state.showOptimiserModal.set(true)"
          class="w-full text-left p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42] hover:border-blue-500 transition-colors cursor-pointer group"
        >
          <div class="flex items-center gap-3 mb-2">
            <mat-icon class="text-blue-400">tune</mat-icon>
            <h4 class="text-xs font-bold text-white group-hover:text-blue-400">Multi-Objective Optimiser</h4>
          </div>
          <p class="text-[11px] text-slate-400">
            Re-run Pareto multi-criteria solver to maximize connectivity and minimize CAPEX.
          </p>
        </button>
      </div>
    </div>
  `
})
export class AppExecutiveReviewView {
  public readonly state = inject(RailwayStateService);

  public countStatus(status: string): number {
    return this.state.activeScenarioCorridors().filter(c => c.status === status).length;
  }
}
