import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { DemandEconomicsEngine } from '../../core/simulation/demand-economics-engine';
import { MatIconModule } from '@angular/material/icon';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-economics-demand-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, DecimalPipe],
  template: `
    <div class="w-full h-full bg-[#0a0f19] flex flex-col p-6 overflow-y-auto select-none space-y-6 text-slate-200">
      <!-- Title Bar -->
      <div class="flex items-center justify-between pb-4 border-b border-[#1f2b42]">
        <div>
          <span class="text-xs font-mono uppercase text-sky-400 font-semibold tracking-wider">Transport Economics &amp; Carbon Accounting</span>
          <h1 class="text-xl font-bold text-white tracking-tight">Demand Gravity &amp; Infrastructure Finance Model</h1>
        </div>

        <div class="flex items-center gap-4">
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono text-slate-400">Demand Scenario:</span>
            <select
              [value]="state.demandScenarioId()"
              (change)="onScenarioChange($event)"
              class="bg-[#121929] border border-[#26344d] text-white text-xs rounded px-3 py-1.5 font-medium cursor-pointer focus:outline-none"
            >
              @for (s of scenarios; track s.id) {
                <option [value]="s.id">{{ s.name }}</option>
              }
            </select>
          </div>

          <div class="flex items-center gap-2">
            <span class="text-xs font-mono text-slate-400">Corridor:</span>
            <select
              [value]="state.selectedCorridorId()"
              (change)="onCorridorSelect($event)"
              class="bg-[#121929] border border-[#26344d] text-white text-xs rounded px-3 py-1.5 font-medium cursor-pointer focus:outline-none"
            >
              @for (c of state.activeScenarioCorridors(); track c.id) {
                <option [value]="c.id">{{ c.code }} &ndash; {{ c.name }}</option>
              }
            </select>
          </div>
        </div>
      </div>

      @if (state.activeEconomicAppraisal(); as eco) {
        <!-- Macro Financial Indicators Strip -->
        <div class="grid grid-cols-5 gap-3">
          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Total CAPEX</span>
            <span class="text-xl font-bold font-mono text-emerald-400">&euro;{{ eco.totalCapexBillionEur }}B</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">15% Contingency Included</span>
          </div>

          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Net Present Value (NPV)</span>
            <span class="text-xl font-bold font-mono text-white">&euro;{{ eco.npv30YearBillionEur }}B</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">30-Year Horizon @ 3.5%</span>
          </div>

          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Economic IRR</span>
            <span class="text-xl font-bold font-mono text-sky-400">{{ eco.irrPercent }}%</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">Social Return Metric</span>
          </div>

          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Capital Payback Period</span>
            <span class="text-xl font-bold font-mono text-amber-400">{{ eco.paybackPeriodYears }} yrs</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">Break-even Horizon</span>
          </div>

          <div class="p-3.5 rounded-lg bg-[#0e1626] border border-[#1e2a42]">
            <span class="text-[10px] uppercase text-slate-500 font-mono block">Annual CO&sup2; Avoided</span>
            <span class="text-xl font-bold font-mono text-emerald-400">{{ (eco.annualCo2AvoidedTonnes / 1000000) | number:'1.2-2' }} Mt</span>
            <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">Modal Substitution</span>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-6">
          <!-- CAPEX Breakdown -->
          <div class="p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
              <h3 class="text-xs font-bold uppercase font-mono text-white">Capital Expenditure Breakdown (CAPEX)</h3>
              <span class="text-[10px] font-mono text-emerald-400 font-bold">&euro;{{ eco.totalCapexBillionEur }} Billion</span>
            </div>

            <div class="space-y-3 font-mono text-xs">
              <div>
                <div class="flex justify-between mb-1">
                  <span class="text-slate-400">Civil Earthworks &amp; Surface Slab Track</span>
                  <span class="text-white font-semibold">&euro;{{ eco.capexCivilBillionEur }}B</span>
                </div>
                <div class="w-full bg-[#151f33] h-2 rounded-full overflow-hidden">
                  <div class="bg-blue-500 h-2 rounded-full" [style.width.%]="(eco.capexCivilBillionEur / eco.totalCapexBillionEur) * 100"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between mb-1">
                  <span class="text-slate-400">Deep Base Tunnels &amp; Boring Tubes</span>
                  <span class="text-white font-semibold">&euro;{{ eco.capexTunnelsBillionEur }}B</span>
                </div>
                <div class="w-full bg-[#151f33] h-2 rounded-full overflow-hidden">
                  <div class="bg-sky-400 h-2 rounded-full" [style.width.%]="(eco.capexTunnelsBillionEur / eco.totalCapexBillionEur) * 100"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between mb-1">
                  <span class="text-slate-400">High Viaducts &amp; Major Bridges</span>
                  <span class="text-white font-semibold">&euro;{{ eco.capexViaductsBillionEur }}B</span>
                </div>
                <div class="w-full bg-[#151f33] h-2 rounded-full overflow-hidden">
                  <div class="bg-amber-400 h-2 rounded-full" [style.width.%]="(eco.capexViaductsBillionEur / eco.totalCapexBillionEur) * 100"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between mb-1">
                  <span class="text-slate-400">25kV Traction Power &amp; ETCS L2 Systems</span>
                  <span class="text-white font-semibold">&euro;{{ eco.capexSystemsBillionEur }}B</span>
                </div>
                <div class="w-full bg-[#151f33] h-2 rounded-full overflow-hidden">
                  <div class="bg-purple-400 h-2 rounded-full" [style.width.%]="(eco.capexSystemsBillionEur / eco.totalCapexBillionEur) * 100"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between mb-1">
                  <span class="text-slate-400">Station Interchange Hub Upgrades</span>
                  <span class="text-white font-semibold">&euro;{{ eco.capexStationsBillionEur }}B</span>
                </div>
                <div class="w-full bg-[#151f33] h-2 rounded-full overflow-hidden">
                  <div class="bg-emerald-400 h-2 rounded-full" [style.width.%]="(eco.capexStationsBillionEur / eco.totalCapexBillionEur) * 100"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Financing Package Mix -->
          <div class="p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
              <h3 class="text-xs font-bold uppercase font-mono text-white">Sovereign &amp; Institutional Financing Mix</h3>
              <span class="text-[10px] font-mono text-slate-400">EU TEN-T Financial Structure</span>
            </div>

            <div class="space-y-3 font-mono text-xs">
              <div class="p-3 rounded bg-[#131b2c] flex items-center justify-between">
                <div>
                  <span class="text-white font-semibold block">Connecting Europe Facility (CEF) Grants</span>
                  <span class="text-[10px] text-slate-400">EU non-repayable cross-border funding</span>
                </div>
                <span class="text-emerald-400 font-bold text-sm">{{ eco.financingMix.euCefGrantsPercent }}%</span>
              </div>

              <div class="p-3 rounded bg-[#131b2c] flex items-center justify-between">
                <div>
                  <span class="text-white font-semibold block">EIB European Green Rail Bonds</span>
                  <span class="text-[10px] text-slate-400">Long-term concessional AAA-rated debt</span>
                </div>
                <span class="text-blue-400 font-bold text-sm">{{ eco.financingMix.eibGreenBondsPercent }}%</span>
              </div>

              <div class="p-3 rounded bg-[#131b2c] flex items-center justify-between">
                <div>
                  <span class="text-white font-semibold block">National Infrastructure Treasuries</span>
                  <span class="text-[10px] text-slate-400">Co-financing from traversed member states</span>
                </div>
                <span class="text-sky-400 font-bold text-sm">{{ eco.financingMix.nationalTreasuryPercent }}%</span>
              </div>

              <div class="p-3 rounded bg-[#131b2c] flex items-center justify-between">
                <div>
                  <span class="text-white font-semibold block">Public-Private Partnership (PPP Concession)</span>
                  <span class="text-[10px] text-slate-400">Availability-payment track concessionaire</span>
                </div>
                <span class="text-purple-400 font-bold text-sm">{{ eco.financingMix.privatePppConcessionPercent }}%</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Environmental Decarbonisation Modal Benchmark -->
        <div class="p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
            <h3 class="text-xs font-bold uppercase font-mono text-white">Specific Passenger Transport Emissions Benchmark</h3>
            <span class="text-xs font-mono text-emerald-400 font-bold">8.5 g CO&sup2; / pax-km (HSR)</span>
          </div>

          <div class="grid grid-cols-4 gap-4 text-xs font-mono">
            <div class="p-3 rounded bg-[#121c2e] border border-blue-500/40">
              <span class="text-blue-400 font-bold block mb-1">EURORAIL High-Speed</span>
              <div class="text-2xl font-bold text-white">8.5 <span class="text-xs font-normal text-slate-400">g/pax-km</span></div>
              <span class="text-[10px] text-slate-400 block mt-1">100% clean EU traction grid</span>
            </div>

            <div class="p-3 rounded bg-[#131b2c]">
              <span class="text-slate-400 font-bold block mb-1">Conventional Regional Rail</span>
              <div class="text-2xl font-bold text-white">28.0 <span class="text-xs font-normal text-slate-400">g/pax-km</span></div>
              <span class="text-[10px] text-slate-400 block mt-1">Mixed diesel &amp; overhead catenary</span>
            </div>

            <div class="p-3 rounded bg-[#131b2c]">
              <span class="text-amber-400 font-bold block mb-1">Motorway Passenger Car</span>
              <div class="text-2xl font-bold text-white">112.0 <span class="text-xs font-normal text-slate-400">g/pax-km</span></div>
              <span class="text-[10px] text-slate-400 block mt-1">Average 1.4 occupancy</span>
            </div>

            <div class="p-3 rounded bg-[#131b2c] border border-red-900/40">
              <span class="text-red-400 font-bold block mb-1">Short-Haul Commercial Jet</span>
              <div class="text-2xl font-bold text-white">215.0 <span class="text-xs font-normal text-slate-400">g/pax-km</span></div>
              <span class="text-[10px] text-slate-400 block mt-1">Includes high-altitude radiative forcing</span>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class AppEconomicsDemandView {
  public readonly state = inject(RailwayStateService);
  public readonly scenarios = DemandEconomicsEngine.SCENARIOS;

  public onScenarioChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.demandScenarioId.set(val);
  }

  public onCorridorSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.selectCorridor(val);
  }
}
