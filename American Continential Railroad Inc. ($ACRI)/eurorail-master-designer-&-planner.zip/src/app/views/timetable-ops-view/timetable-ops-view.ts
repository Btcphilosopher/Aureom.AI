import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RailwayStateService } from '../../core/services/railway-state.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-timetable-ops-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="w-full h-full bg-[#0a0f19] flex flex-col p-6 overflow-y-auto select-none space-y-6 text-slate-200">
      <!-- Title Bar -->
      <div class="flex items-center justify-between pb-4 border-b border-[#1f2b42]">
        <div>
          <span class="text-xs font-mono uppercase text-emerald-400 font-semibold tracking-wider">Railway Operations &amp; Timetable Scheduling</span>
          <h1 class="text-xl font-bold text-white tracking-tight">Pan-European High-Speed Timetable Engine</h1>
        </div>

        <div class="flex items-center gap-3">
          <span class="text-xs font-mono text-slate-400">Target Corridor:</span>
          <select
            [value]="state.selectedCorridorId()"
            (change)="onCorridorSelect($event)"
            class="bg-[#121929] border border-[#26344d] text-white text-xs rounded px-3 py-1.5 font-medium cursor-pointer focus:outline-none"
          >
            @for (c of state.activeScenarioCorridors(); track c.id) {
              <option [value]="c.id">{{ c.code }} &ndash; {{ c.name }}</option>
            }
          </select>
        </div>
      </div>

      @if (state.selectedCorridor(); as cor) {
        <!-- Timetable Frequency Controls -->
        <div class="p-4 rounded-lg bg-[#0e1626] border border-[#1e2a42] flex items-center justify-between">
          <div class="flex items-center gap-8">
            <div>
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Line Frequency</span>
              <div class="flex items-center gap-2 mt-1">
                <input
                  type="range"
                  min="2"
                  max="16"
                  [value]="cor.trainsPerHour"
                  (input)="onFrequencyChange($event)"
                  class="w-32 accent-blue-500 cursor-pointer"
                />
                <span class="text-lg font-bold font-mono text-white">{{ cor.trainsPerHour }} tph</span>
              </div>
            </div>

            <div>
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Line Saturation</span>
              <span class="text-lg font-bold font-mono text-emerald-400">{{ cor.capacityUtilizationPercent }}%</span>
              <span class="text-[10px] text-slate-400 block font-mono">Max Theoretical: {{ cor.theoreticalCapacityTph }} tph</span>
            </div>

            <div>
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Minimum ETCS Headway</span>
              <span class="text-lg font-bold font-mono text-sky-400">180s (3 min)</span>
              <span class="text-[10px] text-slate-400 block font-mono">Level 2 Moving Block</span>
            </div>

            <div>
              <span class="text-[10px] uppercase text-slate-500 font-mono block">Daily Scheduled Departures</span>
              <span class="text-lg font-bold font-mono text-white">{{ state.activeTimetable().length }} services</span>
              <span class="text-[10px] text-slate-400 block font-mono">06:00 &ndash; 22:00 window</span>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <span class="text-xs font-mono text-emerald-400 flex items-center gap-1.5 bg-emerald-950/60 border border-emerald-800 px-3 py-1.5 rounded">
              <mat-icon class="text-[16px] w-4 h-4 leading-none">check_circle</mat-icon>
              Zero Path Conflicts Detected
            </span>
          </div>
        </div>

        <!-- Timetable Services List & Stopping Patterns -->
        <div class="grid grid-cols-3 gap-6">
          <!-- Services Table -->
          <div class="col-span-2 p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
              <h3 class="text-xs font-bold uppercase font-mono text-white">Daily Operational Service Schedule</h3>
              <span class="text-[10px] font-mono text-slate-400">{{ cor.name }}</span>
            </div>

            <div class="border border-[#1e2a42] rounded overflow-hidden max-h-80 overflow-y-auto">
              <table class="w-full text-left text-xs font-mono">
                <thead class="bg-[#111828] text-slate-400 text-[10px] uppercase sticky top-0 border-b border-[#1e2a42]">
                  <tr>
                    <th class="px-3 py-2">Service</th>
                    <th class="px-3 py-2">Departure</th>
                    <th class="px-3 py-2">Origin</th>
                    <th class="px-3 py-2">Destination</th>
                    <th class="px-3 py-2 text-right">Run Time</th>
                    <th class="px-3 py-2 text-center">Trainset</th>
                    <th class="px-3 py-2 text-center">Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#182236] bg-[#0c121e]">
                  @for (svc of state.activeTimetable(); track svc.id) {
                    <tr class="hover:bg-[#131b2b]">
                      <td class="px-3 py-2 font-bold text-blue-400">{{ svc.serviceNumber }}</td>
                      <td class="px-3 py-2 text-white font-semibold">{{ svc.departureTime }}</td>
                      <td class="px-3 py-2 text-slate-300">{{ svc.stops[0].stationName }}</td>
                      <td class="px-3 py-2 text-slate-300">{{ svc.stops[svc.stops.length - 1].stationName }}</td>
                      <td class="px-3 py-2 text-right text-emerald-400">{{ svc.totalJourneyMinutes }} min</td>
                      <td class="px-3 py-2 text-center text-slate-400">{{ state.activeTrainset().modelCode }}</td>
                      <td class="px-3 py-2 text-center">
                        <span class="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                          CLEARED
                        </span>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- Rolling Stock & Turnaround Cycles -->
          <div class="p-5 rounded-lg bg-[#0e1626] border border-[#1e2a42] space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-[#1b253b]">
              <h3 class="text-xs font-bold uppercase font-mono text-white">Rolling Stock Diagramming</h3>
              <span class="text-[10px] font-mono text-slate-400">Fleet Allocations</span>
            </div>

            <div class="space-y-3 font-mono text-xs">
              <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                <span class="text-slate-400">Trainsets in Active Cycle:</span>
                <span class="text-white font-semibold">12 Trainsets</span>
              </div>
              <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                <span class="text-slate-400">Terminus Turnaround Buffer:</span>
                <span class="text-white font-semibold">22 minutes</span>
              </div>
              <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                <span class="text-slate-400">Daily Fleet Utilisation:</span>
                <span class="text-emerald-400 font-semibold">1,480 km / train-day</span>
              </div>
              <div class="flex justify-between p-2 rounded bg-[#131b2c]">
                <span class="text-slate-400">Crew Shift Rest Window:</span>
                <span class="text-white font-semibold">45 min @ Hub Turnaround</span>
              </div>
            </div>

            <div class="p-3 rounded bg-[#111724] border border-[#1a2336] text-[11px] text-slate-400 font-sans leading-relaxed">
              <strong>Interoperable Crew Licensing:</strong> High-speed drivers are certified under the European Train Driver Certificate (Directive 2007/59/EC) with multilingual ETCS cabin displays.
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class AppTimetableOpsView {
  public readonly state = inject(RailwayStateService);

  public onCorridorSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.selectCorridor(val);
  }

  public onFrequencyChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    const cor = this.state.selectedCorridor();
    if (cor) {
      this.state.updateCorridorFrequency(cor.id, val);
    }
  }
}
