from datetime import datetime, timedelta, timezone
from fastapi.testclient import TestClient

from app.main import app
from app.models import SearchInput
from app.timezone_utils import (
    add_minutes_in_london,
    detect_dst_transition,
    london_local_to_utc,
    validate_search_rules,
)
from app.security import validate_seller_url

client = TestClient(app)


def future_date(days: int = 3) -> str:
    return (datetime.now(timezone.utc) + timedelta(days=days)).strftime("%Y-%m-%d")


def test_station_group_lookup():
    res = client.get("/api/v1/stations?q=London")
    assert res.status_code == 200
    ids = {s["id"] for s in res.json()["matched_stations"]}
    assert "LON" in ids
    assert "STP" in ids
    assert "KGX" in ids


def test_railcard_validation_rejects_invalid_two_together():
    search = SearchInput(
        origin_id="SHF",
        destination_id="STP",
        outward_date=future_date(2),
        outward_time="10:00",
        adults=1,
        children=0,
        railcards=["TWO_TOGETHER"],
    )
    errors = validate_search_rules(search)
    assert any("Two Together" in e for e in errors)


def test_overnight_and_dst_transitions():
    # Spring forward in GB: last Sunday of March 2027 (2027-03-28) at 01:00 UTC
    dep_utc = london_local_to_utc("2027-03-27", "22:45")
    arr_utc, arr_local, overnight = add_minutes_in_london(dep_utc, 420)
    assert overnight == 1
    assert arr_local.hour == 6  # 22:45 GMT + 7h = 06:45 BST
    assert detect_dst_transition(dep_utc, arr_utc) is not None


def test_search_provider_timeout_marks_partial():
    res = client.post(
        "/api/v1/journeys/search",
        json={
            "origin_id": "SHF",
            "destination_id": "STP",
            "outward_date": future_date(2),
            "outward_time": "08:30",
            "adults": 1,
            "children": 0,
            "scenario_mode": "provider_timeout",
        },
    )
    assert res.status_code == 200
    data = res.json()
    assert data["is_partial_coverage"] is True


def test_open_redirect_protection():
    ok, _ = validate_seller_url("https://checkout.pennine-rail-demo.example/checkout?ref=1")
    assert ok is True
    bad, _ = validate_seller_url("https://evil-phishing.example/redirect")
    assert bad is False
    bad_scheme, _ = validate_seller_url("javascript:alert(1)")
    assert bad_scheme is False
