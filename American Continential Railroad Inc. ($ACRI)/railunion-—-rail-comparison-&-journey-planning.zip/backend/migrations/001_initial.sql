-- Railunion PostgreSQL Initial Schema (Migration 001)
-- Covers stations, station groups, provider metadata, search references,
-- user accounts, saved journeys, price alerts, and seller handoffs.

CREATE TABLE IF NOT EXISTS stations (
    id TEXT PRIMARY KEY,
    crs VARCHAR(3) NOT NULL,
    nlc VARCHAR(4) NOT NULL,
    tiploc VARCHAR(12) NOT NULL,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    region TEXT NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('individual', 'station_group', 'city_group')),
    city_group_id TEXT NULL,
    member_station_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    nearby_station_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    accessibility JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_stations_crs ON stations (crs);
CREATE INDEX IF NOT EXISTS idx_stations_city_group ON stations (city_group_id);

CREATE TABLE IF NOT EXISTS provider_metadata (
    provider_id TEXT PRIMARY KEY,
    provider_name TEXT NOT NULL,
    seller_host TEXT NOT NULL,
    is_fictional_fixture BOOLEAN NOT NULL DEFAULT TRUE,
    limitations JSONB NOT NULL DEFAULT '[]'::jsonb,
    last_health_status TEXT NOT NULL DEFAULT 'healthy',
    last_checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS search_references (
    search_reference TEXT PRIMARY KEY,
    cache_key_hash TEXT NOT NULL,
    search_input JSONB NOT NULL,
    responding_providers INTEGER NOT NULL,
    is_partial BOOLEAN NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_search_references_created_at ON search_references (created_at DESC);

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS saved_searches (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    search_input JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS favourite_stations (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    station_id TEXT NOT NULL REFERENCES stations(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (user_id, station_id)
);

CREATE TABLE IF NOT EXISTS saved_itineraries (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    itinerary_snapshot JSONB NOT NULL,
    offer_snapshot JSONB NULL,
    note TEXT NOT NULL DEFAULT '',
    source_label TEXT NOT NULL,
    verification_status TEXT NOT NULL DEFAULT 'saved_concept_only_not_a_ticket',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS price_alerts (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    search_input JSONB NOT NULL,
    target_max_total_pence INTEGER NOT NULL CHECK (target_max_total_pence > 0),
    last_observed_lowest_pence INTEGER NULL,
    last_checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    check_cadence_disclosure TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'triggered', 'paused')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS handoff_references (
    handoff_reference TEXT PRIMARY KEY,
    offer_id TEXT NOT NULL,
    provider_id TEXT NOT NULL REFERENCES provider_metadata(provider_id),
    seller_host TEXT NOT NULL,
    validated_seller_url TEXT NOT NULL,
    accepted_total_pence INTEGER NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'GBP',
    accepted_material_change BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
