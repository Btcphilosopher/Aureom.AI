from datetime import date, datetime, time, timedelta, timezone
from typing import Optional
from zoneinfo import ZoneInfo

from .models import SearchInput

LONDON_TZ = ZoneInfo("Europe/London")
MAX_BOOKING_HORIZON_DAYS = 84


def london_local_to_utc(date_str: str, time_str: str) -> datetime:
    d = date.fromisoformat(date_str)
    hh, mm = map(int, time_str.split(":"))
    local_dt = datetime.combine(d, time(hh, mm), tzinfo=LONDON_TZ)
    return local_dt.astimezone(timezone.utc)


def add_minutes_in_london(start_utc: datetime, minutes: int) -> tuple[datetime, datetime, int]:
    start_local = start_utc.astimezone(LONDON_TZ)
    end_utc = start_utc + timedelta(minutes=minutes)
    end_local = end_utc.astimezone(LONDON_TZ)
    overnight_days = (end_local.date() - start_local.date()).days
    return end_utc, end_local, overnight_days


def detect_dst_transition(start_utc: datetime, end_utc: datetime) -> Optional[str]:
    start_offset = start_utc.astimezone(LONDON_TZ).utcoffset()
    end_offset = end_utc.astimezone(LONDON_TZ).utcoffset()
    if start_offset == end_offset:
        return None
    if end_offset and start_offset and end_offset > start_offset:
        return "Clocks spring forward 1 hour (GMT to BST) during this journey."
    return "Clocks go back 1 hour (BST to GMT) during this journey."


def validate_search_rules(search: SearchInput, now_utc: Optional[datetime] = None) -> list[str]:
    errors: list[str] = []
    now = now_utc or datetime.now(timezone.utc)
    today_london = now.astimezone(LONDON_TZ).date()
    max_date = today_london + timedelta(days=MAX_BOOKING_HORIZON_DAYS)

    if search.adults + search.children > 9:
        errors.append("Maximum 9 passengers per enquiry.")

    unique_cards = set(search.railcards)
    if len(unique_cards) > search.adults + search.children:
        errors.append("Cannot apply more railcards than passengers.")
    if "TWO_TOGETHER" in unique_cards and (search.adults != 2 or search.children > 0):
        errors.append("Two Together Railcard requires exactly 2 adults and 0 children.")
    if "FAMILY_FRIENDS" in unique_cards and (search.adults < 1 or search.children < 1):
        errors.append("Family & Friends Railcard requires at least 1 adult and 1 child.")

    outward_d = date.fromisoformat(search.outward_date)
    if outward_d < today_london:
        errors.append("Outward date cannot be in the past.")
    if outward_d > max_date:
        errors.append(f"Outward date exceeds {MAX_BOOKING_HORIZON_DAYS}-day booking horizon.")

    if search.journey_type == "return":
        if not search.return_date:
            errors.append("Return date is required for return journeys.")
        else:
            ret_d = date.fromisoformat(search.return_date)
            if ret_d < outward_d:
                errors.append("Return date cannot precede outward date.")
            if ret_d > max_date:
                errors.append(f"Return date exceeds {MAX_BOOKING_HORIZON_DAYS}-day booking horizon.")

    return errors
