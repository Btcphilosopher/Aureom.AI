from collections import defaultdict
from .models import FareOffer


def group_equivalent_offers(offers: list[FareOffer]) -> list[dict]:
    buckets: dict[str, list[FareOffer]] = defaultdict(list)
    for offer in offers:
        buckets[offer.equivalence_key].append(offer)

    groups: list[dict] = []
    for eq_key, group_offers in buckets.items():
        sorted_offers = sorted(
            group_offers,
            key=lambda o: (
                0 if o.fee_completeness == "complete" else 1,
                o.total_known_payable_pence if o.total_known_payable_pence is not None else 10**9,
            ),
        )
        complete_offers = [
            o
            for o in sorted_offers
            if o.fee_completeness == "complete" and o.total_known_payable_pence is not None
        ]
        lowest_complete = complete_offers[0] if complete_offers else None
        groups.append(
            {
                "equivalence_key": eq_key,
                "ticket_product": sorted_offers[0].ticket_product,
                "offers": [o.model_dump() for o in sorted_offers],
                "lowest_comparable_offer_id": lowest_complete.offer_id if lowest_complete else None,
                "lowest_comparable_total_pence": (
                    lowest_complete.total_known_payable_pence if lowest_complete else None
                ),
                "has_incomplete_fees_only": len(complete_offers) == 0,
            }
        )
    return groups
