from datetime import datetime, timezone
import uuid
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel

from .cache import BoundedSearchCache
from .comparison import group_equivalent_offers
from .models import DemoScenarioMode, FareOffer, SearchInput
from .providers import FIXTURE_STATIONS, PROVIDERS, build_sample_itineraries
from .security import validate_seller_url
from .timezone_utils import validate_search_rules

app = FastAPI(
    title="Railunion GB Rail Comparison API",
    version="0.1.0",
    description="Modular FastAPI backend for Great Britain rail comparison, fare revalidation, and allowlisted seller handoffs.",
)

search_cache = BoundedSearchCache()


class RevalidateRequest(BaseModel):
    offer: FareOffer
    scenario_mode: DemoScenarioMode = "normal"


class HandoffRequest(BaseModel):
    offer: FareOffer
    accepted_material_change: bool = False
    requires_customer_acceptance: bool = False
    target_url_override: str | None = None


@app.get("/api/v1/stations")
async def lookup_stations(q: str = Query(default="")) -> dict:
    needle = q.strip().lower()
    if not needle:
        return {"matched_stations": [s.model_dump() for s in FIXTURE_STATIONS]}
    matched = [
        s.model_dump()
        for s in FIXTURE_STATIONS
        if needle in s.id.lower() or needle in s.crs.lower() or needle in s.name.lower()
    ]
    return {"query": q, "matched_stations": matched}


@app.post("/api/v1/journeys/search")
async def search_journeys(payload: SearchInput) -> dict:
    errors = validate_search_rules(payload)
    if errors:
        raise HTTPException(status_code=400, detail=errors)

    cached = search_cache.get(payload)
    if cached:
        cached["cache_hit"] = True
        return cached

    now = datetime.now(timezone.utc)
    itineraries = build_sample_itineraries(payload, now)
    all_offers: list[FareOffer] = []
    reports: list[dict] = []

    for provider in PROVIDERS:
        offers, report = await provider.fetch_offers(itineraries, payload, now)
        all_offers.extend(offers)
        reports.append(report)

    groups = group_equivalent_offers(all_offers)
    responding = sum(1 for r in reports if r["status"] == "healthy" and r["offers_returned"] > 0)
    response = {
        "search_reference": f"SR-{uuid.uuid4().hex[:10].upper()}",
        "cache_hit": False,
        "itineraries": [it.model_dump() for it in itineraries],
        "offer_groups": groups,
        "provider_reports": reports,
        "is_partial_coverage": responding < len(PROVIDERS),
    }
    search_cache.set(payload, response)
    return response


@app.post("/api/v1/offers/revalidate")
async def revalidate_offer(req: RevalidateRequest) -> dict:
    provider = next((p for p in PROVIDERS if p.provider_id == req.offer.provider_id), None)
    if not provider:
        raise HTTPException(status_code=404, detail="Unknown provider")
    res = await provider.revalidate_offer(req.offer, req.scenario_mode)
    return res.model_dump()


@app.post("/api/v1/handoff")
async def create_handoff(req: HandoffRequest) -> dict:
    if req.requires_customer_acceptance and not req.accepted_material_change:
        raise HTTPException(
            status_code=400,
            detail="Customer acceptance of material fare or condition change is required.",
        )

    candidate_url = req.target_url_override or (
        f"https://{req.offer.seller_host}/checkout?ref={req.offer.seller_handoff_reference}"
    )
    ok, result_or_err = validate_seller_url(candidate_url)
    if not ok:
        raise HTTPException(status_code=400, detail=result_or_err)

    handoff_ref = f"{req.offer.seller_handoff_reference}-{uuid.uuid4().hex[:6].upper()}"
    return {
        "handoff_reference": handoff_ref,
        "validated_seller_url": result_or_err,
        "seller_name": req.offer.seller_name,
        "disclaimer": f"You'll complete your purchase with {req.offer.seller_name}. Railunion does not issue tickets.",
    }


@app.get("/api/v1/providers/health")
async def provider_health() -> dict:
    return {
        "providers": [
            {
                "provider_id": p.provider_id,
                "provider_name": p.provider_name,
                "seller_host": p.seller_host,
                "status": "healthy",
            }
            for p in PROVIDERS
        ]
    }
