from __future__ import annotations

from typing import Literal, Optional
from pydantic import BaseModel, Field, field_validator


RailcardCode = Literal[
    "16-25",
    "26-30",
    "TWO_TOGETHER",
    "SENIOR",
    "FAMILY_FRIENDS",
    "NETWORK",
    "DISABLED_PERSONS",
    "HM_FORCES",
]

DemoScenarioMode = Literal[
    "normal",
    "provider_timeout",
    "provider_no_fares",
    "expired_offer",
    "missing_fee",
    "price_change",
]


class StationAccessibility(BaseModel):
    step_free_access: Literal["full", "partial", "none", "unknown"]
    assistance_available: Literal["yes", "no", "unknown"]
    tactile_paving: Literal["yes", "no", "unknown"]
    accessible_toilets: Literal["yes", "no", "unknown"]
    summary: str
    source: str
    updated_at: str
    official_assistance_url: str


class Station(BaseModel):
    id: str
    crs: str
    nlc: str
    tiploc: str
    name: str
    city: str
    region: str
    kind: Literal["individual", "station_group", "city_group"]
    city_group_id: Optional[str] = None
    member_station_ids: list[str] = Field(default_factory=list)
    nearby_station_ids: list[str] = Field(default_factory=list)
    latitude: float
    longitude: float
    accessibility: StationAccessibility


class SearchInput(BaseModel):
    journey_type: Literal["one_way", "return"] = "one_way"
    origin_id: str = Field(..., min_length=2, max_length=16)
    destination_id: str = Field(..., min_length=2, max_length=16)
    outward_date: str = Field(..., pattern=r"^\d{4}-\d{2}-\d{2}$")
    outward_time: str = Field(..., pattern=r"^\d{2}:\d{2}$")
    outward_time_mode: Literal["depart_at", "arrive_by"] = "depart_at"
    return_date: Optional[str] = Field(default=None, pattern=r"^\d{4}-\d{2}-\d{2}$")
    return_time: Optional[str] = Field(default=None, pattern=r"^\d{2}:\d{2}$")
    return_time_mode: Literal["depart_at", "arrive_by"] = "depart_at"
    adults: int = Field(default=1, ge=1, le=9)
    children: int = Field(default=0, ge=0, le=9)
    railcards: list[RailcardCode] = Field(default_factory=list)
    travel_class: Literal["standard", "first"] = "standard"
    scenario_mode: DemoScenarioMode = "normal"

    @field_validator("destination_id")
    @classmethod
    def origin_dest_distinct(cls, v: str, info) -> str:
        if "origin_id" in info.data and v == info.data["origin_id"]:
            raise ValueError("Origin and destination must be different.")
        return v


class PassengerComposition(BaseModel):
    adults: int
    children: int
    summary: str


class JourneyLeg(BaseModel):
    leg_id: str
    origin_station_id: str
    origin_name: str
    origin_crs: str
    destination_station_id: str
    destination_name: str
    destination_crs: str
    scheduled_departure_local: str
    scheduled_arrival_local: str
    scheduled_departure_utc: str
    scheduled_arrival_utc: str
    estimated_departure_local: Optional[str] = None
    estimated_arrival_local: Optional[str] = None
    duration_minutes: int
    operator_code: str
    operator_name: str
    service_id: str
    headcode: str
    walking_transfer_minutes: Optional[int] = None
    transfer_note: Optional[str] = None


class JourneyItinerary(BaseModel):
    journey_id: str
    direction: Literal["outward", "return"]
    provider_id: str
    search_time_utc: str
    origin_station_id: str
    origin_name: str
    origin_crs: str
    destination_station_id: str
    destination_name: str
    destination_crs: str
    departure_local: str
    arrival_local: str
    departure_utc: str
    arrival_utc: str
    overnight_days: int
    dst_transition_notice: Optional[str] = None
    duration_minutes: int
    changes_count: int
    interchange_station_ids: list[str]
    transfer_durations_minutes: list[int]
    legs: list[JourneyLeg]
    timetable_source: str
    timetable_freshness_utc: str


class FareOffer(BaseModel):
    offer_id: str
    provider_id: str
    provider_name: str
    journey_reference: str
    passenger_composition: PassengerComposition
    railcards_applied: list[RailcardCode]
    travel_class: Literal["standard", "first"]
    ticket_product: str
    ticket_category: Literal["advance", "off_peak", "anytime", "return_product"]
    route_restrictions: str
    operator_restrictions: str
    time_restrictions: str
    train_binding: Literal["booked_train_only", "flexible_any_permitted", "operator_specific", "unknown"]
    reservation_status: Literal[
        "included_compulsory", "optional_recommended", "not_available", "not_applicable", "unknown"
    ]
    refund_conditions: str
    change_conditions: str
    ticket_price: int  # integer pence
    mandatory_fees: Optional[int]  # None when unknown
    fulfilment_fees: Optional[int]
    total_known_payable_pence: Optional[int]
    fee_completeness: Literal["complete", "missing_mandatory_fee", "unknown"]
    currency: Literal["GBP"] = "GBP"
    quoted_at: str
    expires_at: str
    seller_handoff_reference: str
    seller_name: str
    seller_host: str
    equivalence_key: str
    availability_status: Literal["available", "limited", "expired", "unavailable"] = "available"
    price_change_on_revalidate_pence: int = 0


class RevalidationResult(BaseModel):
    offer_id: str
    provider_id: str
    status: Literal["unchanged", "price_changed", "expired", "unavailable"]
    original_total_pence: Optional[int]
    revalidated_total_pence: Optional[int]
    price_delta_pence: Optional[int]
    condition_changes: list[str]
    requires_customer_acceptance: bool
    revalidated_at_utc: str
    expires_at_utc: str
    message: str
    updated_offer: Optional[FareOffer] = None
