import hashlib
import hmac
import os
import secrets
from urllib.parse import urlparse

ALLOWED_SELLER_HOSTS = {
    "checkout.pennine-rail-demo.example",
    "tickets.albion-rail-demo.example",
}

_FALLBACK_SECRET = secrets.token_hex(32)


def get_session_secret() -> str:
    configured = os.environ.get("SESSION_SECRET", "").strip()
    return configured if len(configured) >= 16 else _FALLBACK_SECRET


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    derived = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=16384, r=8, p=1, dklen=64)
    return f"{salt.hex()}:{derived.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    parts = stored_hash.split(":")
    if len(parts) != 2:
        return False
    salt_hex, expected_hex = parts
    derived = hashlib.scrypt(
        password.encode("utf-8"),
        salt=bytes.fromhex(salt_hex),
        n=16384,
        r=8,
        p=1,
        dklen=64,
    )
    return hmac.compare_digest(derived, bytes.fromhex(expected_hex))


def validate_seller_url(raw_url: str) -> tuple[bool, str]:
    try:
        parsed = urlparse(raw_url)
    except Exception:
        return False, "Malformed seller URL."
    if parsed.scheme != "https":
        return False, "Only HTTPS seller URLs are permitted."
    if parsed.username or parsed.password:
        return False, "Embedded credentials are not permitted."
    if parsed.hostname not in ALLOWED_SELLER_HOSTS:
        return False, f"Host '{parsed.hostname}' is not on the authorised seller allowlist."
    return True, raw_url


def redact_log_fields(payload: dict) -> dict:
    sensitive = {"password", "password_hash", "token", "secret", "email", "authorization"}
    return {k: ("[REDACTED]" if k in sensitive else v) for k, v in payload.items()}
