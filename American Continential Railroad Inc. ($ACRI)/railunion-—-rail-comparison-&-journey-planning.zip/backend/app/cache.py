import hashlib
import json
import os
import time
from typing import Optional

from .models import SearchInput

try:
    import redis  # type: ignore
except ImportError:
    redis = None  # type: ignore

DEFAULT_TTL_SECONDS = 120


def build_cache_key(search: SearchInput) -> str:
    canonical = {
        "journey_type": search.journey_type,
        "origin_id": search.origin_id,
        "destination_id": search.destination_id,
        "outward_date": search.outward_date,
        "outward_time": search.outward_time,
        "outward_time_mode": search.outward_time_mode,
        "return_date": search.return_date if search.journey_type == "return" else None,
        "return_time": search.return_time if search.journey_type == "return" else None,
        "adults": search.adults,
        "children": search.children,
        "railcards": sorted(search.railcards),
        "travel_class": search.travel_class,
        "scenario_mode": search.scenario_mode,
    }
    digest = hashlib.sha256(json.dumps(canonical, sort_keys=True).encode()).hexdigest()[:24]
    return f"railunion:search:{digest}"


class BoundedSearchCache:
    def __init__(self, redis_url: Optional[str] = None) -> None:
        self._local: dict[str, tuple[float, dict]] = {}
        self._client = None
        url = redis_url or os.environ.get("REDIS_URL")
        if url and redis is not None:
            try:
                self._client = redis.Redis.from_url(url, decode_responses=True, socket_timeout=0.5)
            except Exception:
                self._client = None

    def get(self, search: SearchInput) -> Optional[dict]:
        key = build_cache_key(search)
        if self._client is not None:
            try:
                raw = self._client.get(key)
                if raw:
                    return json.loads(raw)
            except Exception:
                pass
        entry = self._local.get(key)
        if not entry:
            return None
        expires_at, payload = entry
        if expires_at <= time.time():
            self._local.pop(key, None)
            return None
        return payload

    def set(self, search: SearchInput, payload: dict, ttl_seconds: int = DEFAULT_TTL_SECONDS) -> None:
        key = build_cache_key(search)
        if self._client is not None:
            try:
                self._client.setex(key, ttl_seconds, json.dumps(payload))
                return
            except Exception:
                pass
        if len(self._local) >= 200:
            oldest = next(iter(self._local))
            self._local.pop(oldest, None)
        self._local[key] = (time.time() + ttl_seconds, payload)
