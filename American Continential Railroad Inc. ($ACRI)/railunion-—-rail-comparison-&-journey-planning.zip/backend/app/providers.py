from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone
import hashlib
from typing import Optional
import httpx

from .models import (
    DemoScenarioMode,
    FareOffer,
    JourneyItinerary,
    JourneyLeg,
    PassengerComposition,
    RevalidationResult,
    SearchInput,
    Station,
    StationAccessibility,
)
from .timezone_utils import add_minutes_in_london, detect_dst_transition, london_local_to_utc

FIXTURE_STATIONS: list[Station] = [
    Station(
        id="SHF",
        crs="SHF",
        nlc="6607",
        tiploc="SHEFFLD",
        name="Sheffield",
        city="Sheffield",
        region="South Yorkshire",
        kind="individual",
        nearby_station_ids=["DBY", "DON"],
        latitude=53.3781,
        longitude=-1.4622,
        accessibility=StationAccessibility(
            step_free_access="full",
            assistance_available="yes",
            tactile_paving="yes",
            accessible_toilets="yes",
            summary="Step-free access to all platforms via lifts.",
            source="National Rail Station Accessibility Catalogue (demonstration extract)",
            updated_at="2026-11-01T09:00:00Z",
            official_assistance_url="https://www.nationalrail.co.uk/stations/shf/",
        ),
    ),
    Station(
        id="LON",
        crs="LON",
        nlc="1072",
        tiploc="LONDON",
        name="London Terminals (Station Group)",
        city="London",
        region="Greater London",
        kind="station_group",
        city_group_id="LON",
        member_station_ids=["STP", "KGX", "EUS", "PAD"],
        nearby_station_ids=["STP", "KGX", "EUS"],
        latitude=51.5308,
        longitude=-0.1238,
        accessibility=StationAccessibility(
            step_free_access="unknown",
            assistance_available="unknown",
            tactile_paving="unknown",
            accessible_toilets="unknown",
            summary="Station group covering multiple London termini.",
            source="Railunion Station Group Metadata",
            updated_at="2026-11-01T09:00:00Z",
            official_assistance_url="https://www.nationalrail.co.uk/help-and-assistance/passenger-assist/",
        ),
    ),
    Station(
        id="STP",
        crs="STP",
        nlc="1555",
        tiploc="STPANCS",
        name="London St Pancras International",
        city="London",
        region="Greater London",
        kind="individual",
        city_group_id="LON",
        nearby_station_ids=["KGX", "EUS"],
        latitude=51.5319,
        longitude=-0.1263,
        accessibility=StationAccessibility(
            step_free_access="full",
            assistance_available="yes",
            tactile_paving="yes",
            accessible_toilets="yes",
            summary="Step-free access across concourse and domestic platforms.",
            source="National Rail Station Accessibility Catalogue (demonstration extract)",
            updated_at="2026-11-01T09:00:00Z",
            official_assistance_url="https://www.nationalrail.co.uk/stations/stp/",
        ),
    ),
    Station(
        id="KGX",
        crs="KGX",
        nlc="6121",
        tiploc="KNGX",
        name="London King's Cross",
        city="London",
        region="Greater London",
        kind="individual",
        city_group_id="LON",
        nearby_station_ids=["STP", "EUS"],
        latitude=51.5308,
        longitude=-0.1238,
        accessibility=StationAccessibility(
            step_free_access="full",
            assistance_available="yes",
            tactile_paving="yes",
            accessible_toilets="yes",
            summary="Step-free throughout main concourse and platforms 0-11.",
            source="National Rail Station Accessibility Catalogue (demonstration extract)",
            updated_at="2026-11-01T09:00:00Z",
            official_assistance_url="https://www.nationalrail.co.uk/stations/kgx/",
        ),
    ),
    Station(
        id="EDB",
        crs="EDB",
        nlc="9328",
        tiploc="EDINBUR",
        name="Edinburgh Waverley",
        city="Edinburgh",
        region="Scotland",
        kind="individual",
        nearby_station_ids=["YRK"],
        latitude=55.952,
        longitude=-3.1899,
        accessibility=StationAccessibility(
            step_free_access="full",
            assistance_available="yes",
            tactile_paving="yes",
            accessible_toilets="yes",
            summary="Step-free access via Waverley Bridge and Market Street lifts.",
            source="National Rail Station Accessibility Catalogue (demonstration extract)",
            updated_at="2026-11-01T09:00:00Z",
            official_assistance_url="https://www.nationalrail.co.uk/stations/edb/",
        ),
    ),
]


class RailProviderAdapter(ABC):
    provider_id: str
    provider_name: str
    seller_host: str

    def __init__(self, timeout_seconds: float = 2.5, max_retries: int = 1) -> None:
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries
        self._http_client = httpx.AsyncClient(timeout=timeout_seconds)

    @abstractmethod
    async def fetch_offers(
        self, itineraries: list[JourneyItinerary], search: SearchInput, now_utc: datetime
    ) -> tuple[list[FareOffer], dict]:
        ...

    @abstractmethod
    async def revalidate_offer(
        self, offer: FareOffer, scenario_mode: DemoScenarioMode = "normal"
    ) -> RevalidationResult:
        ...


def build_sample_itineraries(search: SearchInput, now_utc: datetime) -> list[JourneyItinerary]:
    anchor_utc = london_local_to_utc(search.outward_date, search.outward_time)
    dep_utc, dep_local, _ = add_minutes_in_london(anchor_utc, 0)
    arr_utc, arr_local, overnight = add_minutes_in_london(dep_utc, 124)
    dst_notice = detect_dst_transition(dep_utc, arr_utc)

    leg = JourneyLeg(
        leg_id="shf-stp-direct-0",
        origin_station_id=search.origin_id,
        origin_name=search.origin_id,
        origin_crs=search.origin_id[:3],
        destination_station_id=search.destination_id,
        destination_name=search.destination_id,
        destination_crs=search.destination_id[:3],
        scheduled_departure_local=dep_local.strftime("%Y-%m-%dT%H:%M"),
        scheduled_arrival_local=arr_local.strftime("%Y-%m-%dT%H:%M"),
        scheduled_departure_utc=dep_utc.isoformat(),
        scheduled_arrival_utc=arr_utc.isoformat(),
        duration_minutes=124,
        operator_code="EM",
        operator_name="East Midlands Railway",
        service_id=f"EM-{search.outward_date.replace('-', '')}-1F10",
        headcode="1F10",
    )

    return [
        JourneyItinerary(
            journey_id=f"JRN-OUT-{search.origin_id}-{search.destination_id}",
            direction="outward",
            provider_id="pennine_retail",
            search_time_utc=now_utc.isoformat(),
            origin_station_id=search.origin_id,
            origin_name=search.origin_id,
            origin_crs=search.origin_id[:3],
            destination_station_id=search.destination_id,
            destination_name=search.destination_id,
            destination_crs=search.destination_id[:3],
            departure_local=dep_local.strftime("%Y-%m-%dT%H:%M"),
            arrival_local=arr_local.strftime("%Y-%m-%dT%H:%M"),
            departure_utc=dep_utc.isoformat(),
            arrival_utc=arr_utc.isoformat(),
            overnight_days=overnight,
            dst_transition_notice=dst_notice,
            duration_minutes=124,
            changes_count=0,
            interchange_station_ids=[],
            transfer_durations_minutes=[],
            legs=[leg],
            timetable_source="Railunion Synthetic GB Timetable Fixture",
            timetable_freshness_utc=now_utc.isoformat(),
        )
    ]


class FixtureProviderAdapter(RailProviderAdapter):
    def __init__(self, provider_id: str, provider_name: str, seller_host: str) -> None:
        super().__init__()
        self.provider_id = provider_id
        self.provider_name = provider_name
        self.seller_host = seller_host

    async def fetch_offers(
        self, itineraries: list[JourneyItinerary], search: SearchInput, now_utc: datetime
    ) -> tuple[list[FareOffer], dict]:
        if self.provider_id == "albion_dist" and search.scenario_mode == "provider_timeout":
            return [], {
                "provider_id": self.provider_id,
                "provider_name": self.provider_name,
                "status": "timeout",
                "offers_returned": 0,
            }
        if self.provider_id == "albion_dist" and search.scenario_mode == "provider_no_fares":
            return [], {
                "provider_id": self.provider_id,
                "provider_name": self.provider_name,
                "status": "no_fares",
                "offers_returned": 0,
            }

        offers: list[FareOffer] = []
        is_pennine = self.provider_id == "pennine_retail"
        for it in itineraries:
            base_pence = 3400 if search.travel_class == "standard" else 5400
            if search.railcards:
                base_pence = round(base_pence * 0.66)
            ticket_price = (base_pence + 150) if is_pennine else base_pence
            mandatory_fee: Optional[int] = (
                0 if is_pennine else (None if search.scenario_mode == "missing_fee" else 100)
            )
            fee_completeness = "complete" if mandatory_fee is not None else "missing_mandatory_fee"
            total_known = None if mandatory_fee is None else ticket_price + mandatory_fee

            expires_at = (
                now_utc - timedelta(minutes=2)
                if (not is_pennine and search.scenario_mode == "expired_offer")
                else now_utc + timedelta(minutes=15)
            )

            eq_key = hashlib.sha1(
                f"{it.journey_id}|{search.adults}|{search.children}|{','.join(sorted(search.railcards))}|{search.travel_class}|advance|{fee_completeness}".encode()
            ).hexdigest()[:14]

            offers.append(
                FareOffer(
                    offer_id=f"OFR-{self.provider_id}-{it.journey_id}-ADV",
                    provider_id=self.provider_id,
                    provider_name=self.provider_name,
                    journey_reference=it.journey_id,
                    passenger_composition=PassengerComposition(
                        adults=search.adults,
                        children=search.children,
                        summary=f"{search.adults} adult(s)",
                    ),
                    railcards_applied=search.railcards,
                    travel_class=search.travel_class,
                    ticket_product="Advance Single",
                    ticket_category="advance",
                    route_restrictions="Direct booked route only.",
                    operator_restrictions="Booked operator only.",
                    time_restrictions=f"Must travel on {it.departure_local[11:16]} service.",
                    train_binding="booked_train_only",
                    reservation_status="included_compulsory",
                    refund_conditions="Non-refundable.",
                    change_conditions="Exchangeable before departure for £10.00 fee plus fare difference.",
                    ticket_price=ticket_price,
                    mandatory_fees=mandatory_fee,
                    fulfilment_fees=0,
                    total_known_payable_pence=total_known,
                    fee_completeness=fee_completeness,
                    quoted_at=now_utc.isoformat(),
                    expires_at=expires_at.isoformat(),
                    seller_handoff_reference=f"HO-{self.provider_id[:3].upper()}-ADV",
                    seller_name=self.provider_name,
                    seller_host=self.seller_host,
                    equivalence_key=eq_key,
                    availability_status="expired"
                    if expires_at <= now_utc
                    else "available",
                    price_change_on_revalidate_pence=450
                    if (not is_pennine and search.scenario_mode == "price_change")
                    else 0,
                )
            )

        return offers, {
            "provider_id": self.provider_id,
            "provider_name": self.provider_name,
            "status": "healthy",
            "offers_returned": len(offers),
        }

    async def revalidate_offer(
        self, offer: FareOffer, scenario_mode: DemoScenarioMode = "normal"
    ) -> RevalidationResult:
        now = datetime.now(timezone.utc)
        expires_dt = datetime.fromisoformat(offer.expires_at)
        if expires_dt <= now or offer.availability_status == "expired" or (
            self.provider_id == "albion_dist" and scenario_mode == "expired_offer"
        ):
            return RevalidationResult(
                offer_id=offer.offer_id,
                provider_id=self.provider_id,
                status="expired",
                original_total_pence=offer.total_known_payable_pence,
                revalidated_total_pence=None,
                price_delta_pence=None,
                condition_changes=[],
                requires_customer_acceptance=False,
                revalidated_at_utc=now.isoformat(),
                expires_at_utc=offer.expires_at,
                message="Offer expired. Run a fresh search.",
                updated_offer=None,
            )

        delta = offer.price_change_on_revalidate_pence
        if delta != 0:
            new_ticket = offer.ticket_price + delta
            new_total = None if offer.mandatory_fees is None else new_ticket + offer.mandatory_fees
            updated = offer.model_copy(
                update={
                    "ticket_price": new_ticket,
                    "total_known_payable_pence": new_total,
                    "price_change_on_revalidate_pence": 0,
                }
            )
            return RevalidationResult(
                offer_id=offer.offer_id,
                provider_id=self.provider_id,
                status="price_changed",
                original_total_pence=offer.total_known_payable_pence,
                revalidated_total_pence=new_total,
                price_delta_pence=delta,
                condition_changes=[f"Price updated by +{delta}p during revalidation."],
                requires_customer_acceptance=True,
                revalidated_at_utc=now.isoformat(),
                expires_at_utc=(now + timedelta(minutes=10)).isoformat(),
                message="Fare changed during revalidation; customer acceptance required.",
                updated_offer=updated,
            )

        return RevalidationResult(
            offer_id=offer.offer_id,
            provider_id=self.provider_id,
            status="unchanged",
            original_total_pence=offer.total_known_payable_pence,
            revalidated_total_pence=offer.total_known_payable_pence,
            price_delta_pence=0,
            condition_changes=[],
            requires_customer_acceptance=False,
            revalidated_at_utc=now.isoformat(),
            expires_at_utc=(now + timedelta(minutes=15)).isoformat(),
            message="Fare verified unchanged.",
            updated_offer=offer,
        )


PROVIDERS = [
    FixtureProviderAdapter(
        provider_id="pennine_retail",
        provider_name="Pennine & Southern Rail Retail",
        seller_host="checkout.pennine-rail-demo.example",
    ),
    FixtureProviderAdapter(
        provider_id="albion_dist",
        provider_name="Albion Rail Distribution",
        seller_host="tickets.albion-rail-demo.example",
    ),
]
