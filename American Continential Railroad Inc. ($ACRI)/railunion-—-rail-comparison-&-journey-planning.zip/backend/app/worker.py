import asyncio
from datetime import datetime, timezone
import os
from typing import Any

from .providers import FIXTURE_STATIONS, PROVIDERS, build_sample_itineraries
from .models import SearchInput

ALERT_CHECK_CADENCE_SECONDS = 900  # 15 minutes


async def run_station_fixture_sync() -> dict[str, Any]:
    """
    Imports authorised station metadata fixtures into PostgreSQL when DATABASE_URL is configured.
    """
    db_url = os.environ.get("DATABASE_URL")
    synced_count = len(FIXTURE_STATIONS)
    if db_url:
        try:
            import psycopg  # type: ignore
            import json

            with psycopg.connect(db_url) as conn:
                with conn.cursor() as cur:
                    for st in FIXTURE_STATIONS:
                        cur.execute(
                            """
                            INSERT INTO stations (
                                id, crs, nlc, tiploc, name, city, region, kind,
                                city_group_id, member_station_ids, nearby_station_ids,
                                latitude, longitude, accessibility
                            ) VALUES (
                                %s, %s, %s, %s, %s, %s, %s, %s,
                                %s, %s::jsonb, %s::jsonb, %s, %s, %s::jsonb
                            )
                            ON CONFLICT (id) DO UPDATE SET
                                name = EXCLUDED.name,
                                accessibility = EXCLUDED.accessibility,
                                updated_at = NOW();
                            """,
                            (
                                st.id,
                                st.crs,
                                st.nlc,
                                st.tiploc,
                                st.name,
                                st.city,
                                st.region,
                                st.kind,
                                st.city_group_id,
                                json.dumps(st.member_station_ids),
                                json.dumps(st.nearby_station_ids),
                                st.latitude,
                                st.longitude,
                                st.accessibility.model_dump_json(),
                            ),
                        )
                conn.commit()
        except Exception as exc:
            return {"status": "skipped_db_unavailable", "error": str(exc), "fixtures": synced_count}

    return {"status": "synced", "fixtures": synced_count, "checked_at_utc": datetime.now(timezone.utc).isoformat()}


async def check_saved_alert_once(search_input: SearchInput, target_max_pence: int) -> dict[str, Any]:
    now = datetime.now(timezone.utc)
    itineraries = build_sample_itineraries(search_input, now)
    all_totals: list[int] = []
    for provider in PROVIDERS:
        offers, _ = await provider.fetch_offers(itineraries, search_input, now)
        for o in offers:
            if o.fee_completeness == "complete" and o.total_known_payable_pence is not None:
                all_totals.append(o.total_known_payable_pence)

    observed_lowest = min(all_totals) if all_totals else None
    triggered = observed_lowest is not None and observed_lowest <= target_max_pence
    return {
        "observed_lowest_pence": observed_lowest,
        "triggered": triggered,
        "checked_at_utc": now.isoformat(),
        "cadence_disclosure": f"Checked periodically every {ALERT_CHECK_CADENCE_SECONDS // 60} minutes.",
    }


async def worker_loop() -> None:
    await run_station_fixture_sync()
    while True:
        await asyncio.sleep(ALERT_CHECK_CADENCE_SECONDS)


if __name__ == "__main__":
    asyncio.run(worker_loop())
