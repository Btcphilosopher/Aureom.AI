import test from 'node:test';
import assert from 'node:assert/strict';

import {
  addMinutesInLondon,
  detectDstTransitionNotice,
  getDefaultLondonSearchDate,
  londonLocalToUtc,
  validateSearchInput,
} from '../lib/railunion/timezone';
import { GB_STATIONS, lookupStations, resolveStationSelection } from '../lib/railunion/stations';
import { clearSearchCache, buildPriceRelevantCacheKey } from '../lib/railunion/cache';
import { executeJourneySearch } from '../lib/railunion/search-service';
import { groupComparableOffers } from '../lib/railunion/comparison';
import { albionDistributionProvider } from '../lib/railunion/providers';
import { validateSellerHandoffUrl } from '../lib/railunion/security';
import {
  addSavedSearch,
  deleteUserAccount,
  exportUserData,
  getUserWorkspaceData,
  registerUser,
  removeSavedSearch,
} from '../lib/railunion/store';

test('1. Station-group handling does not silently substitute selected individual terminals', () => {
  const stp = resolveStationSelection('STP');
  assert.equal(stp.isGroup, false);
  assert.deepEqual(stp.expandedStationIds, ['STP']);

  const lon = resolveStationSelection('LON');
  assert.equal(lon.isGroup, true);
  assert.ok(lon.expandedStationIds.includes('STP'));
  assert.ok(lon.expandedStationIds.includes('KGX'));

  const placeSearch = lookupStations('Peak District');
  assert.ok(placeSearch.unresolvedPlaceNotice?.includes('Peak District'));
  assert.ok(placeSearch.nearbySuggestions.some((s) => s.id === 'SHF'));
});

test('2. Passenger and railcard validation enforces GB Railcard eligibility rules', () => {
  const dateStr = getDefaultLondonSearchDate(3);

  const badTwoTogether = validateSearchInput({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '10:00',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: ['TWO_TOGETHER'],
    travelClass: 'standard',
  });
  assert.equal(badTwoTogether.valid, false);
  assert.ok(badTwoTogether.errors.some((e) => e.includes('Two Together')));

  const badFamily = validateSearchInput({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '10:00',
    outwardTimeMode: 'depart_at',
    adults: 2,
    children: 0,
    railcards: ['FAMILY_FRIENDS'],
    travelClass: 'standard',
  });
  assert.equal(badFamily.valid, false);
  assert.ok(badFamily.errors.some((e) => e.includes('Family & Friends')));

  const tooManyCards = validateSearchInput({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '10:00',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: ['16-25', 'SENIOR'],
    travelClass: 'standard',
  });
  assert.equal(tooManyCards.valid, false);
});

test('3. Overnight journeys and Europe/London DST transitions calculate elapsed duration accurately', () => {
  // Spring forward: 2027-03-27 22:45 GMT + 420m (7h) => 2027-03-28 06:45 BST (+1 day)
  const depSpring = londonLocalToUtc('2027-03-27', '22:45');
  const arrSpring = addMinutesInLondon(depSpring, 420);
  assert.equal(arrSpring.dayDifference, 1);
  assert.equal(arrSpring.localDate, '2027-03-28');
  assert.equal(arrSpring.localTime, '06:45');
  assert.equal(arrSpring.tzLabel, 'BST');
  assert.ok(detectDstTransitionNotice(depSpring, arrSpring.utc)?.includes('spring forward'));

  // Fall back: 2027-10-30 22:45 BST + 420m (7h) => 2027-10-31 04:45 GMT (+1 day)
  const depAutumn = londonLocalToUtc('2027-10-30', '22:45');
  const arrAutumn = addMinutesInLondon(depAutumn, 420);
  assert.equal(arrAutumn.dayDifference, 1);
  assert.equal(arrAutumn.localTime, '04:45');
  assert.equal(arrAutumn.tzLabel, 'GMT');
  assert.ok(detectDstTransitionNotice(depAutumn, arrAutumn.utc)?.includes('go back'));
});

test('4. Price arithmetic, fee completeness, and offer equivalence exclude incomplete fees from cheapest', async () => {
  clearSearchCache();
  const dateStr = getDefaultLondonSearchDate(2);
  const res = await executeJourneySearch({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '08:30',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: [],
    travelClass: 'standard',
    scenarioMode: 'missing_fee',
  });

  assert.equal(res.ok, true);
  if (!res.ok) return;

  const firstItem = res.data.directionResults.outward[0];
  const albionMissing = firstItem.allOffers.find(
    (o) => o.provider_id === 'albion_dist' && o.ticket_category === 'advance'
  );
  assert.ok(albionMissing);
  assert.equal(albionMissing.mandatory_fees, null);
  assert.equal(albionMissing.total_known_payable_pence, null);
  assert.equal(albionMissing.fee_completeness, 'missing_mandatory_fee');

  // Group containing missing-fee offer must NOT mark it as lowestComparableOfferId
  const groups = groupComparableOffers(firstItem.allOffers);
  const missingOnlyGroup = groups.find((g) => g.hasIncompleteFeesOnly);
  assert.ok(missingOnlyGroup);
  assert.equal(missingOnlyGroup.lowestComparableOfferId, null);
});

test('5. Provider timeouts report partial coverage honestly', async () => {
  clearSearchCache();
  const dateStr = getDefaultLondonSearchDate(2);
  const res = await executeJourneySearch({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '08:30',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: [],
    travelClass: 'standard',
    scenarioMode: 'provider_timeout',
  });
  assert.equal(res.ok, true);
  if (!res.ok) return;
  assert.equal(res.data.coverageSummary.isPartial, true);
  assert.equal(res.data.coverageSummary.respondingProviders, 1);
  assert.ok(res.data.coverageSummary.disclosure.includes('not an exhaustive market comparison'));
});

test('6. Cache-key isolation prevents leaking quotes across railcard or passenger configs', async () => {
  clearSearchCache();
  const dateStr = getDefaultLondonSearchDate(2);

  const keyNoCard = buildPriceRelevantCacheKey({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '10:30',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: [],
    travelClass: 'standard',
  });

  const keyWithCard = buildPriceRelevantCacheKey({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '10:30',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: ['16-25'],
    travelClass: 'standard',
  });

  assert.notEqual(keyNoCard, keyWithCard);

  const r1 = await executeJourneySearch({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '10:30',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: [],
    travelClass: 'standard',
  });
  const r2 = await executeJourneySearch({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '10:30',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: ['16-25'],
    travelClass: 'standard',
  });
  assert.equal(r1.ok, true);
  assert.equal(r2.ok, true);
  if (r1.ok && r2.ok) {
    assert.equal(r2.data.cacheMetadata.cacheHit, false);
    const p1 = r1.data.directionResults.outward[0].lowestCompletePricePence!;
    const p2 = r2.data.directionResults.outward[0].lowestCompletePricePence!;
    assert.ok(p2 < p1);
  }
});

test('7. Expired offers and revalidation price changes behave deterministically', async () => {
  clearSearchCache();
  const dateStr = getDefaultLondonSearchDate(2);

  const expiredSearch = await executeJourneySearch({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '08:30',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: [],
    travelClass: 'standard',
    scenarioMode: 'expired_offer',
  });
  assert.equal(expiredSearch.ok, true);
  if (!expiredSearch.ok) return;

  const expOffer = expiredSearch.data.directionResults.outward[0].allOffers.find(
    (o) => o.provider_id === 'albion_dist' && o.ticket_category === 'advance'
  )!;
  const expReval = await albionDistributionProvider.revalidateOffer(expOffer, 'expired_offer');
  assert.equal(expReval.status, 'expired');
  assert.equal(expReval.updatedOffer, null);

  const priceChgSearch = await executeJourneySearch({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: dateStr,
    outwardTime: '08:30',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: [],
    travelClass: 'standard',
    scenarioMode: 'price_change',
  });
  assert.equal(priceChgSearch.ok, true);
  if (!priceChgSearch.ok) return;

  const chgOffer = priceChgSearch.data.directionResults.outward[0].allOffers.find(
    (o) => o.provider_id === 'albion_dist' && o.ticket_category === 'advance'
  )!;
  const chgReval = await albionDistributionProvider.revalidateOffer(chgOffer, 'price_change');
  assert.equal(chgReval.status, 'price_changed');
  assert.equal(chgReval.requiresCustomerAcceptance, true);
  assert.equal(chgReval.priceDeltaPence, 450);
});

test('8. Seller redirect security blocks non-allowlisted hosts, bad schemes, and credentials', () => {
  const valid = validateSellerHandoffUrl('https://checkout.pennine-rail-demo.example/checkout?ref=123');
  assert.equal(valid.valid, true);

  const untrusted = validateSellerHandoffUrl('https://evil.example/steal?ref=123');
  assert.equal(untrusted.valid, false);

  const jsScheme = validateSellerHandoffUrl('javascript:alert(1)');
  assert.equal(jsScheme.valid, false);

  const httpScheme = validateSellerHandoffUrl('http://checkout.pennine-rail-demo.example/checkout');
  assert.equal(httpScheme.valid, false);

  const creds = validateSellerHandoffUrl('https://user:pass@checkout.pennine-rail-demo.example/checkout');
  assert.equal(creds.valid, false);
});

test('9. Account-scoped permissions isolate saved searches, export, and deletion', () => {
  const uniqueA = `alice-${Date.now()}@example.com`;
  const uniqueB = `bob-${Date.now()}@example.com`;
  const userA = registerUser(uniqueA, 'SecurePass123!', 'Alice');
  const userB = registerUser(uniqueB, 'SecurePass123!', 'Bob');

  const saved = addSavedSearch(userA.id, 'Alice SHF-STP', {
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: getDefaultLondonSearchDate(2),
    outwardTime: '09:00',
    outwardTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: [],
    travelClass: 'standard',
  });

  // User B cannot delete User A's saved search
  const crossDelete = removeSavedSearch(userB.id, saved.id);
  assert.equal(crossDelete, false);

  const wsB = getUserWorkspaceData(userB.id);
  assert.equal(wsB.savedSearches.length, 0);

  const exportedA = exportUserData(userA.id);
  assert.ok(exportedA);
  assert.equal(exportedA.savedSearches.length, 1);

  assert.equal(deleteUserAccount(userA.id), true);
  assert.equal(deleteUserAccount(userB.id), true);
  assert.equal(exportUserData(userA.id), null);
});

test('10. Stations catalogue includes attributed accessibility metadata with explicit unknown states', () => {
  const lon = GB_STATIONS.find((s) => s.id === 'LON')!;
  assert.equal(lon.accessibility.stepFreeAccess, 'unknown');
  const shf = GB_STATIONS.find((s) => s.id === 'SHF')!;
  assert.equal(shf.accessibility.stepFreeAccess, 'full');
  assert.ok(shf.accessibility.source.length > 0);
});
