# Railunion — Rail Comparison & Journey Planning

**Independent Great Britain Rail Comparison & Journey Planning Concept**  
Fictional service times, deterministic fixture providers, and illustrative GBP (£) prices. Railunion separates comparison from booking and does **not** issue tickets or confirm seat reservations.

---

## Architecture & Stack

- **Website**: Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS v4, `motion/react`, `lucide-react`.
- **Next.js API Layer (`/app/api/*`)**: Full working server-side routes for station lookup, journey search, offer revalidation, allowlisted seller handoff, provider health, account sessions (`scrypt` + HMAC Bearer / `HttpOnly; SameSite=None; Partitioned` cookies), saved journeys, price alerts, JSON export, and account deletion.
- **Python Backend Service (`/backend`)**: Modular FastAPI service (`backend/app/main.py`) with Pydantic v2 models, `Europe/London` timezone/DST handling (`zoneinfo`), typed provider adapters (`Pennine & Southern Rail Retail`, `Albion Rail Distribution`), Redis bounded cache (`backend/app/cache.py`), PostgreSQL schema migrations (`backend/migrations/001_initial.sql`), and background worker (`backend/app/worker.py`) for fixture imports and periodic 15-minute price-alert checks.
- **Local Orchestration**: `docker-compose.yml` running `postgres`, `redis`, `backend` (FastAPI on `:8000`), `worker`, and `web` (Next.js on `:3000`).

---

## Running Locally

### Option 1: Next.js Full-Stack App (Standalone Preview)
```bash
npm install
npm run dev
```
Open `http://localhost:3000`.

### Option 2: Full Docker Compose Stack (PostgreSQL + Redis + FastAPI + Worker + Next.js)
```bash
docker compose up --build
```
- Web UI: `http://localhost:3000`
- FastAPI OpenAPI Docs: `http://localhost:8000/docs`

### Running Automated Tests
```bash
# TypeScript domain, comparison, cache, security & account tests
npx tsx --test tests/railunion.test.ts

# Python FastAPI backend tests
cd backend && pytest tests/test_railunion.py
```

---

## API Documentation

### Next.js Routes
- `GET /api/stations?q=...` — Station, station-group, and nearby-station lookup (preserving individual terminals vs groups).
- `POST /api/journeys/search` — Validates passenger/railcard/horizon rules, checks isolated price-relevant cache, queries both provider adapters, groups comparable offers, and reports partial coverage.
- `POST /api/offers/revalidate` — Revalidates an offer prior to handoff (`unchanged`, `price_changed`, `expired`, `unavailable`).
- `GET /api/handoff?ref=...` & `POST /api/handoff` — Enforces material-change acceptance and strict host allowlist validation, recording the handoff reference.
- `GET /api/providers/health` — Returns adapter status and documented limitations.
- `GET/POST/DELETE /api/account` — Account registration, sign-in, demo traveller login, sign-out, and account deletion.
- `GET /api/account/export` — Account-scoped JSON export.
- `POST/DELETE /api/saved` — Saved searches, favourite stations, saved itineraries, and price alerts.
- `POST /api/alerts/check` — On-demand equivalent-offer check mirroring the 15-minute worker cadence.

---

## Capability Summary

### Implemented
- Reference-aligned Railunion homepage, navy/ivory/coral/turquoise visual design, responsive header, hero search panel, Popular Journeys, Fit Guides, Scenic Routes, and Travel Guides.
- Station & station-group model (`CRS`, `NLC`, `TIPLOC`), explicit distinction between individual London terminals (`STP`, `KGX`, `EUS`, `PAD`) and `London Terminals (LON)`, nearby-station suggestions, and attributed accessibility metadata with explicit `unknown` states.
- `Europe/London` scheduling, DST spring/autumn transition detection, overnight `+1 day` arrival markers, and 84-day booking horizon & GB Railcard validation.
- Integer-pence fare arithmetic, full 19-field `FareOffer` inspection modal, like-for-like offer equivalence grouping, exclusion of incomplete-fee offers from "Cheapest", and documented `Recommended` ranking formula.
- 6-step offer revalidation & allowlisted seller handoff workflow (`/seller-handoff/[ref]`) with open-redirect protection and no silent substitution on expiry.
- Account-scoped authentication (`scrypt` + HMAC sessions), saved searches, favourite stations, saved itineraries (explicitly distinguished from tickets), price alerts (with 15-minute cadence disclosure), JSON export, and account deletion.
- Complete FastAPI backend, PostgreSQL schema migration, Redis cache layer, background worker, and `docker-compose.yml`.

### Simulated / Deterministic Fixtures
- Two clearly labelled fictional provider adapters (`Pennine & Southern Rail Retail` and `Albion Rail Distribution`) with synthetic GB schedules and illustrative GBP fares.
- Reproducible scenario modes: normal, provider timeout (partial coverage), provider returning no fares, expired offer, missing mandatory fee, and price change on revalidation.
- Simulated seller checkout screen at `/seller-handoff/[ref]`.
- Split-ticket combinations are explicitly marked **deferred** until an authorised Rail Delivery Group (RDG) fare-routing validator is integrated.

### Externally Integrated
- Links to official National Rail station and Passenger Assist pages (`nationalrail.co.uk`) for accessibility assistance channels.
- Ready for PostgreSQL (`DATABASE_URL`) and Redis (`REDIS_URL`) via `docker-compose.yml` (no unverified external commercial rail APIs fabricated).

### Tested
- Executed automated TypeScript test suite (`tests/railunion.test.ts`) verifying station groups, railcard rules, DST/overnight math, fee completeness, provider timeouts, cache-key isolation, expired & price-changed revalidation, redirect allowlist security, and account permissions.
- Included Python `pytest` suite (`backend/tests/test_railunion.py`).
