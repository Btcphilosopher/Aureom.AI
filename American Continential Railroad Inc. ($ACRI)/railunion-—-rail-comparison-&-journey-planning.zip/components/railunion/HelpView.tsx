'use client';

import React, { useEffect, useState } from 'react';
import { Activity, BookOpen, CheckCircle2, Play, ShieldCheck } from 'lucide-react';
import { getDefaultLondonSearchDate } from '@/lib/railunion/timezone';
import type { ProviderStatusReport, SearchInput } from '@/lib/railunion/types';

interface HelpViewProps {
  focusedTopic: 'flexible' | 'lowest' | 'first' | 'luggage' | null;
  onRunScenarioSearch: (partial: Partial<SearchInput>) => void;
}

export default function HelpView({ focusedTopic, onRunScenarioSearch }: HelpViewProps) {
  const [providers, setProviders] = useState<ProviderStatusReport[]>([]);
  const [loadingHealth, setLoadingHealth] = useState(false);

  const loadHealth = async () => {
    setLoadingHealth(true);
    try {
      const res = await fetch('/api/providers/health');
      if (res.ok) {
        const data = (await res.json()) as { providers: ProviderStatusReport[] };
        setProviders(data.providers);
      }
    } finally {
      setLoadingHealth(false);
    }
  };

  useEffect(() => {
    let active = true;
    fetch('/api/providers/health')
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { providers: ProviderStatusReport[] } | null) => {
        if (active && data?.providers) {
          setProviders(data.providers);
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, []);

  const demoDate = getDefaultLondonSearchDate(2);

  const demoActions: { title: string; description: string; input: Partial<SearchInput> }[] = [
    {
      title: '1–3. Sheffield → London (1 Adult, 2 providers)',
      description: 'Compare direct EMR and connecting LNER/Northern itineraries across both fixture providers.',
      input: {
        originId: 'SHF',
        destinationId: 'STP',
        outwardDate: demoDate,
        outwardTime: '08:30',
        adults: 1,
        children: 0,
        railcards: [],
        travelClass: 'standard',
        scenarioMode: 'normal',
      },
    },
    {
      title: '4. Apply 16–25 Railcard on Sheffield → London',
      description: 'Validates Railcard eligibility and applies discounted fare calculation.',
      input: {
        originId: 'SHF',
        destinationId: 'STP',
        outwardDate: demoDate,
        outwardTime: '10:15',
        adults: 1,
        children: 0,
        railcards: ['16-25'],
        travelClass: 'standard',
        scenarioMode: 'normal',
      },
    },
    {
      title: '9–10. Price change during revalidation → Seller handoff',
      description: 'Triggers a +£4.50 fare update when you click Continue to seller on an Albion Rail Distribution offer.',
      input: {
        originId: 'SHF',
        destinationId: 'STP',
        outwardDate: demoDate,
        outwardTime: '08:30',
        adults: 1,
        children: 0,
        railcards: [],
        travelClass: 'standard',
        scenarioMode: 'price_change',
      },
    },
    {
      title: '11. Partial results when 1 provider times out',
      description: 'Simulates an Albion Rail Distribution timeout and shows explicit partial-coverage disclosure.',
      input: {
        originId: 'SHF',
        destinationId: 'STP',
        outwardDate: demoDate,
        outwardTime: '08:30',
        adults: 1,
        children: 0,
        railcards: [],
        travelClass: 'standard',
        scenarioMode: 'provider_timeout',
      },
    },
    {
      title: '12. Expired offer recovery flow',
      description: 'Click Continue to seller on an Albion Advance offer to test expired quote recovery without silent substitution.',
      input: {
        originId: 'SHF',
        destinationId: 'STP',
        outwardDate: demoDate,
        outwardTime: '08:30',
        adults: 1,
        children: 0,
        railcards: [],
        travelClass: 'standard',
        scenarioMode: 'expired_offer',
      },
    },
    {
      title: 'Missing mandatory fee honesty test',
      description: 'Marks Albion Advance offer fee as unknown so it is never misleadingly labelled Cheapest.',
      input: {
        originId: 'SHF',
        destinationId: 'STP',
        outwardDate: demoDate,
        outwardTime: '08:30',
        adults: 1,
        children: 0,
        railcards: [],
        travelClass: 'standard',
        scenarioMode: 'missing_fee',
      },
    },
  ];

  return (
    <section className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-8">
      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-2">
        <h1 className="text-2xl font-bold text-[#0B1E36]">
          Ticket condition guides, provider transparency & demo runner
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl">
          Understand Great Britain rail ticket rules before choosing a seller, inspect live adapter limitations, and launch reproducible demonstration scenarios.
        </p>
      </div>

      {/* Ticket Condition Guides */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div
          className={`bg-white border rounded-2xl p-5 space-y-2 ${
            focusedTopic === 'lowest' ? 'border-[#EF4B42] ring-2 ring-[#EF4B42]/20' : 'border-slate-200'
          }`}
        >
          <h2 className="text-base font-bold text-[#0B1E36] flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#EF4B42]" />
            <span>Advance tickets (Lowest fare)</span>
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Valid strictly on the booked date, time, and operator shown. Non-refundable; changes prior to departure incur a £10.00 admin fee plus any fare difference. Seat reservations are included automatically where offered.
          </p>
        </div>

        <div
          className={`bg-white border rounded-2xl p-5 space-y-2 ${
            focusedTopic === 'flexible' ? 'border-[#00B59A] ring-2 ring-[#00B59A]/20' : 'border-slate-200'
          }`}
        >
          <h2 className="text-base font-bold text-[#0B1E36] flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#008C77]" />
            <span>Off-Peak & Anytime (Flexible)</span>
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Off-Peak tickets let you board any eligible train outside morning/evening peak restriction windows. Anytime tickets carry zero time restrictions. Both are refundable prior to expiry under National Rail terms.
          </p>
        </div>

        <div
          className={`bg-white border rounded-2xl p-5 space-y-2 ${
            focusedTopic === 'first' ? 'border-[#00B59A] ring-2 ring-[#00B59A]/20' : 'border-slate-200'
          }`}
        >
          <h2 className="text-base font-bold text-[#0B1E36] flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#008C77]" />
            <span>First Class travel</span>
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Offers wider reclining seats, power sockets, and quieter carriages on participating intercity services. Complimentary refreshments and station lounge access vary by train operator and ticket type.
          </p>
        </div>

        <div
          className={`bg-white border rounded-2xl p-5 space-y-2 ${
            focusedTopic === 'luggage' ? 'border-[#EF4B42] ring-2 ring-[#EF4B42]/20' : 'border-slate-200'
          }`}
        >
          <h2 className="text-base font-bold text-[#0B1E36] flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#EF4B42]" />
            <span>Luggage, changes & reservations</span>
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Bring up to two large items plus hand luggage free of charge. Bicycle spaces require advance booking on intercity operators. Railunion separates comparison from booking—seller checkout confirms final seats.
          </p>
        </div>
      </div>

      {/* Interactive Reproducible Demonstration Scenarios */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
        <div>
          <h2 className="text-lg font-bold text-[#0B1E36]">Reproducible demonstration runner</h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Launch any demonstration scenario directly against Railunion’s deterministic provider adapters.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {demoActions.map((act) => (
            <div
              key={act.title}
              className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between gap-3"
            >
              <div>
                <h3 className="text-sm font-bold text-[#0B1E36]">{act.title}</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">{act.description}</p>
              </div>
              <button
                type="button"
                onClick={() => onRunScenarioSearch(act.input)}
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] rounded-lg transition-colors"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Run scenario</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Provider Health & Limitations */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-[#0B1E36] flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#008C77]" />
              <span>Connected provider adapters & limitations</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Fictional deterministic providers used for transparent comparison testing.
            </p>
          </div>
          <button
            type="button"
            onClick={loadHealth}
            disabled={loadingHealth}
            className="px-3.5 py-2 text-xs font-semibold text-[#0B1E36] bg-slate-100 hover:bg-slate-200 rounded-lg"
          >
            {loadingHealth ? 'Checking…' : 'Refresh status'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {providers.map((p) => (
            <div key={p.providerId} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="text-sm font-bold text-[#0B1E36]">{p.providerName}</div>
                <span className="font-mono text-xs font-semibold text-[#007A68] uppercase">
                  {p.status}
                </span>
              </div>
              <p className="text-xs text-slate-600">{p.message}</p>
              <ul className="list-disc pl-4 space-y-1 text-xs text-slate-600">
                {p.limitations.map((lim) => (
                  <li key={lim}>{lim}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
