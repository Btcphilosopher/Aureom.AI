'use client';

import React, { useEffect, useRef, useState } from 'react';
import { ChevronDown, MapPin, Star, Train } from 'lucide-react';
import type { FavouriteStationRecord, Station, StationLookupResult } from '@/lib/railunion/types';

interface StationPickerProps {
  label: string;
  selectedId: string;
  stations: Station[];
  favourites: FavouriteStationRecord[];
  onSelect: (station: Station) => void;
  inputId: string;
}

export default function StationPicker({
  label,
  selectedId,
  stations,
  favourites,
  onSelect,
  inputId,
}: StationPickerProps) {
  const selectedStation = stations.find((s) => s.id === selectedId) ?? null;
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [lookupResult, setLookupResult] = useState<StationLookupResult | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!open) return;
    let active = true;
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/stations?q=${encodeURIComponent(query)}`, {
          signal: controller.signal,
        });
        if (!res.ok) return;
        const data = (await res.json()) as StationLookupResult;
        if (active) setLookupResult(data);
      } catch {
        // Ignore aborted lookups
      }
    }, 80);

    return () => {
      active = false;
      controller.abort();
      clearTimeout(timer);
    };
  }, [open, query]);

  const displayedMatches = lookupResult?.matchedStations ?? stations.slice(0, 8);
  const nearbySuggestions = lookupResult?.nearbySuggestions ?? [];

  return (
    <div ref={containerRef} className="relative min-w-0">
      <button
        id={inputId}
        type="button"
        onClick={() => {
          setOpen((v) => !v);
          setQuery('');
        }}
        aria-expanded={open}
        className="w-full h-14 px-3.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl flex items-center justify-between gap-2 text-left transition-colors focus-visible:outline-2 focus-visible:outline-[#00B59A]"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <MapPin className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
          <div className="min-w-0">
            <div className="text-[11px] font-medium text-slate-500 leading-tight">{label}</div>
            <div className="text-sm font-semibold text-[#0B1E36] truncate">
              {selectedStation ? selectedStation.name : 'Choose station'}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {selectedStation && (
            <span className="font-mono text-[11px] font-semibold text-slate-500">
              {selectedStation.crs}
            </span>
          )}
          <ChevronDown className="w-4 h-4 text-slate-400" aria-hidden="true" />
        </div>
      </button>

      {open && (
        <div className="absolute left-0 right-0 sm:w-[360px] top-16 z-50 bg-white border border-slate-200 rounded-xl shadow-xl p-3">
          <label htmlFor={`${inputId}-search`} className="sr-only">
            Search stations or station groups
          </label>
          <input
            id={`${inputId}-search`}
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Station, CRS code (e.g. SHF, STP) or place..."
            className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#00B59A]"
          />

          {favourites.length > 0 && !query.trim() && (
            <div className="mt-2.5 pb-2 border-b border-slate-100">
              <div className="text-[11px] font-semibold text-slate-500 mb-1.5 px-1">
                Favourite stations
              </div>
              <div className="flex flex-wrap gap-1.5">
                {favourites.map((fav) => {
                  const st = stations.find((s) => s.id === fav.stationId);
                  if (!st) return null;
                  return (
                    <button
                      key={fav.id}
                      type="button"
                      onClick={() => {
                        onSelect(st);
                        setOpen(false);
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-100 hover:bg-[#CFF7EE] text-[#0B1E36] rounded-md transition-colors"
                    >
                      <Star className="w-3 h-3 text-[#EF4B42]" aria-hidden="true" />
                      <span>{st.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {lookupResult?.unresolvedPlaceNotice && (
            <div className="mt-2 p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900">
              {lookupResult.unresolvedPlaceNotice}
            </div>
          )}

          <div className="mt-2 max-h-64 overflow-y-auto divide-y divide-slate-100">
            {displayedMatches.map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => {
                  onSelect(st);
                  setOpen(false);
                }}
                className={`w-full px-2.5 py-2 text-left flex items-center justify-between gap-3 rounded-lg hover:bg-slate-50 transition-colors ${
                  st.id === selectedId ? 'bg-[#CFF7EE]/45' : ''
                }`}
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-[#0B1E36] truncate flex items-center gap-1.5">
                    <Train className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                    <span className="truncate">{st.name}</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {st.kind === 'individual' ? 'Individual station' : 'City / station group'} ·{' '}
                    {st.region}
                  </div>
                </div>
                <span className="font-mono text-xs font-semibold text-slate-600 shrink-0">
                  {st.crs}
                </span>
              </button>
            ))}

            {nearbySuggestions.length > 0 && (
              <div className="pt-2">
                <div className="px-2.5 py-1 text-[11px] font-semibold text-slate-500">
                  Nearby stations
                </div>
                {nearbySuggestions.map((st) => (
                  <button
                    key={`nearby-${st.id}`}
                    type="button"
                    onClick={() => {
                      onSelect(st);
                      setOpen(false);
                    }}
                    className="w-full px-2.5 py-2 text-left flex items-center justify-between gap-3 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-[#0B1E36] truncate">
                        {st.name}
                      </div>
                      <div className="text-xs text-slate-500">
                        Nearby · {st.region}
                      </div>
                    </div>
                    <span className="font-mono text-xs font-semibold text-slate-500 shrink-0">
                      {st.crs}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
