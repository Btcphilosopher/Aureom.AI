'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  RefreshCw,
  ShieldCheck,
  X,
} from 'lucide-react';
import { formatPence } from '@/lib/railunion/timezone';
import type {
  DemoScenarioMode,
  FareOffer,
  JourneyItinerary,
  RevalidationResult,
  SellerHandoffRecord,
} from '@/lib/railunion/types';

interface RevalidateHandoffModalProps {
  offer: FareOffer | null;
  itinerary: JourneyItinerary | null;
  scenarioMode: DemoScenarioMode;
  onClose: () => void;
  onRunFreshSearch: () => void;
}

export default function RevalidateHandoffModal({
  offer,
  itinerary,
  scenarioMode,
  onClose,
  onRunFreshSearch,
}: RevalidateHandoffModalProps) {
  const [loading, setLoading] = useState(true);
  const [revalidation, setRevalidation] = useState<RevalidationResult | null>(null);
  const [acceptedChange, setAcceptedChange] = useState(false);
  const [handoffRecord, setHandoffRecord] = useState<SellerHandoffRecord | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!offer) return;

    let cancelled = false;
    fetch('/api/offers/revalidate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ offer, scenarioMode }),
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) {
          if (!cancelled) setErrorMsg(data.error || 'Could not revalidate offer.');
          return;
        }
        if (!cancelled) setRevalidation(data as RevalidationResult);
      })
      .catch(() => {
        if (!cancelled) setErrorMsg('Network error during offer revalidation.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [offer, scenarioMode]);

  if (!offer || !itinerary) return null;

  const itinerarySummary = `${itinerary.originName} (${itinerary.originCrs}) → ${itinerary.destinationName} (${itinerary.destinationCrs}) · ${itinerary.departureLocal.replace('T', ' ')}`;

  const handleConfirmHandoff = async () => {
    if (!revalidation || !revalidation.updatedOffer) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/handoff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          offer: revalidation.updatedOffer,
          itinerarySummary,
          requiresCustomerAcceptance: revalidation.requiresCustomerAcceptance,
          acceptedMaterialChange: acceptedChange,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || 'Seller handoff could not be created.');
        return;
      }
      setHandoffRecord(data as SellerHandoffRecord);
    } catch {
      setErrorMsg('Failed to prepare seller handoff.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="handoff-modal-title"
      className="fixed inset-0 z-50 bg-[#0B1E36]/65 backdrop-blur-[2px] flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-xl w-full overflow-hidden">
        <div className="px-6 py-4 bg-[#0B1E36] text-white flex items-center justify-between gap-4">
          <div className="min-w-0">
            <h2 id="handoff-modal-title" className="text-lg font-bold truncate">
              Seller revalidation & handoff
            </h2>
            <p className="text-xs text-slate-300 truncate">{itinerarySummary}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close seller handoff"
            className="p-1.5 rounded-lg text-slate-300 hover:bg-white/10 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {loading && !revalidation && (
            <div className="py-8 text-center space-y-2">
              <RefreshCw className="w-6 h-6 text-[#00B59A] animate-spin mx-auto" />
              <p className="text-sm font-medium text-[#0B1E36]">
                Revalidating fare and availability with {offer.provider_name}…
              </p>
            </div>
          )}

          {errorMsg && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-sm text-red-900">
              {errorMsg}
            </div>
          )}

          {revalidation && !handoffRecord && (
            <>
              {revalidation.status === 'expired' && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-3">
                  <div className="flex items-start gap-2.5">
                    <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-amber-950 text-sm">Offer expired</div>
                      <p className="text-sm text-amber-900 mt-1">{revalidation.message}</p>
                      <p className="text-xs text-amber-800 mt-1.5">
                        Railunion will not silently substitute a different train or ticket.
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                    >
                      Close
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onRunFreshSearch();
                      }}
                      className="px-4 py-2 text-xs font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] rounded-lg"
                    >
                      Run fresh search
                    </button>
                  </div>
                </div>
              )}

              {revalidation.status === 'price_changed' && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-3">
                  <div className="flex items-start gap-2.5">
                    <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                    <div className="space-y-1.5">
                      <div className="font-semibold text-amber-950 text-sm">
                        Price updated during revalidation
                      </div>
                      <p className="text-sm text-amber-900">{revalidation.message}</p>
                      <div className="flex items-center gap-3 text-sm font-semibold tabular-nums pt-1">
                        <span className="line-through text-slate-500">
                          {formatPence(revalidation.originalTotalPence)}
                        </span>
                        <ArrowRight className="w-4 h-4 text-amber-700" />
                        <span className="text-amber-950">
                          {formatPence(revalidation.revalidatedTotalPence)}
                        </span>
                      </div>
                      {revalidation.conditionChanges.map((chg) => (
                        <p key={chg} className="text-xs text-amber-800">
                          {chg}
                        </p>
                      ))}
                    </div>
                  </div>

                  <label className="flex items-start gap-2.5 pt-2 border-t border-amber-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={acceptedChange}
                      onChange={(e) => setAcceptedChange(e.target.checked)}
                      className="mt-0.5 h-4 w-4 rounded border-amber-400 text-[#00B59A] focus:ring-[#00B59A]"
                    />
                    <span className="text-xs font-medium text-amber-950">
                      I accept the updated total of {formatPence(revalidation.revalidatedTotalPence)} and ticket conditions before continuing to {offer.seller_name}.
                    </span>
                  </label>
                </div>
              )}

              {revalidation.status === 'unchanged' && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-emerald-950 text-sm">
                      Fare verified unchanged
                    </div>
                    <p className="text-sm text-emerald-900 mt-0.5">
                      Total known payable:{' '}
                      <span className="font-bold tabular-nums">
                        {revalidation.revalidatedTotalPence === null
                          ? 'Mandatory fee undisclosed by seller'
                          : formatPence(revalidation.revalidatedTotalPence)}
                      </span>{' '}
                      ({offer.ticket_product} · {offer.passenger_composition.summary})
                    </p>
                  </div>
                </div>
              )}

              {(revalidation.status === 'unchanged' || revalidation.status === 'price_changed') && (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                    <div className="flex items-center gap-2 text-sm font-semibold text-[#0B1E36]">
                      <ShieldCheck className="w-4 h-4 text-[#00B59A]" />
                      <span>You’ll complete your purchase with {offer.seller_name}.</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Railunion is an independent comparison platform and does not issue tickets or confirm seat reservations. Continuing records an auditable handoff reference and opens the simulated authorised seller checkout.
                    </p>
                    <p className="text-[11px] font-mono text-slate-500">
                      Allowlisted seller host: {offer.seller_host}
                    </p>
                  </div>

                  <div className="flex items-center justify-end gap-3">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={loading || (revalidation.requiresCustomerAcceptance && !acceptedChange)}
                      onClick={handleConfirmHandoff}
                      className="px-5 py-2.5 text-sm font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors"
                    >
                      {loading ? 'Preparing handoff…' : `Continue to ${offer.seller_name}`}
                    </button>
                  </div>
                </div>
              )}
            </>
          )}

          {handoffRecord && (
            <div className="space-y-4">
              <div className="p-4 bg-[#CFF7EE]/40 border border-[#00B59A]/40 rounded-xl space-y-2">
                <div className="text-sm font-bold text-[#0B1E36]">
                  Seller handoff prepared
                </div>
                <p className="text-xs text-slate-700">{handoffRecord.disclaimer}</p>
                <div className="pt-2 text-xs space-y-1 font-mono text-slate-700">
                  <div>Handoff reference: {handoffRecord.handoffReference}</div>
                  <div>Allowlisted target: {handoffRecord.validatedSellerUrl}</div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Stay on Railunion
                </button>
                <Link
                  href={`/seller-handoff/${encodeURIComponent(handoffRecord.handoffReference)}`}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] rounded-lg transition-colors"
                >
                  <span>Open simulated seller checkout</span>
                  <ExternalLink className="w-4 h-4" />
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
