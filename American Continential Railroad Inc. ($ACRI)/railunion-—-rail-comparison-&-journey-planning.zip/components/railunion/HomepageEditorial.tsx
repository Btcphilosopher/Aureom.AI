'use client';

import React from 'react';
import Image from 'next/image';
import {
  Armchair,
  Bookmark,
  ChevronRight,
  Luggage,
  Repeat,
  Star,
  Tag,
} from 'lucide-react';
import { getDefaultLondonSearchDate } from '@/lib/railunion/timezone';
import type { SavedSearchRecord, SearchInput } from '@/lib/railunion/types';

interface HomepageEditorialProps {
  savedSearches: SavedSearchRecord[];
  onQuickSearch: (partial: Partial<SearchInput>) => void;
  onOpenGuide: (topic?: 'flexible' | 'lowest' | 'first' | 'luggage') => void;
  onOpenSavedTab: () => void;
}

const POPULAR_ROUTES = [
  {
    title: 'Sheffield → London',
    subtitle: 'Direct & connecting via Doncaster',
    image: '/images/dest_london_pancras_1795607707873.jpg',
    alt: 'London St Pancras International Victorian red-brick facade and clocktower',
    originId: 'SHF',
    destinationId: 'STP',
  },
  {
    title: 'London → Edinburgh',
    subtitle: 'East Coast express & sleeper options',
    image: '/images/dest_edinburgh_castle_1795607708218.jpg',
    alt: 'Edinburgh Castle rising above railway tracks in Princes Street Gardens',
    originId: 'KGX',
    destinationId: 'EDB',
  },
  {
    title: 'York → London',
    subtitle: 'Frequent intercity services',
    image: '/images/dest_york_minster_1795607708240.jpg',
    alt: 'York Minster cathedral and stone bridge over the River Ouse',
    originId: 'YRK',
    destinationId: 'KGX',
  },
];

const SCENIC_CATEGORIES = [
  {
    title: 'City breaks',
    subtitle: 'Direct intercity arrivals into central London, York & Manchester',
    image: '/images/dest_london_pancras_1795607707873.jpg',
    alt: 'Victorian railway architecture at London St Pancras',
    originId: 'MAN',
    destinationId: 'EUS',
  },
  {
    title: 'Scenic Highland rail',
    subtitle: 'Historic stone viaducts, lochs & mountain passes north of Edinburgh',
    image: '/images/cat_highland_viaduct_1795607708583.jpg',
    alt: 'Curved stone arch railway viaduct crossing a Scottish Highland valley and loch',
    originId: 'EDB',
    destinationId: 'INV',
  },
  {
    title: 'Coastal getaways',
    subtitle: 'Dramatic sea-wall lines across Devon & Cornwall to Penzance',
    image: '/images/cat_coastal_line_1795607709190.jpg',
    alt: 'British coastal railway line beside turquoise ocean waves on the Devon seawall',
    originId: 'PAD',
    destinationId: 'PNZ',
  },
];

export default function HomepageEditorial({
  savedSearches,
  onQuickSearch,
  onOpenGuide,
  onOpenSavedTab,
}: HomepageEditorialProps) {
  const demoDate = getDefaultLondonSearchDate(2);

  return (
    <div className="space-y-12 py-10">
      {/* Popular Journeys + Find the Journey That Fits (Matching Reference Layout) */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left 8 cols: Popular Journeys */}
          <div className="lg:col-span-8 flex flex-col">
            <h2 className="text-2xl font-bold text-[#0B1E36] mb-5">
              <span className="relative inline-block">
                Popular
                <span
                  aria-hidden="true"
                  className="absolute left-0 right-0 -bottom-1 h-[3px] bg-[#EF4B42] rounded-full"
                />
              </span>{' '}
              journeys
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 flex-1">
              {POPULAR_ROUTES.map((route) => (
                <div
                  key={route.title}
                  className="group relative min-h-[240px] rounded-2xl overflow-hidden shadow-sm border border-slate-200 flex flex-col justify-end"
                >
                  <Image
                    src={route.image}
                    alt={route.alt}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                  />
                  <div
                    aria-hidden="true"
                    className="absolute inset-0 bg-gradient-to-t from-[#0B1E36]/90 via-[#0B1E36]/30 to-transparent"
                  />
                  <div className="relative z-10 p-4 space-y-2.5">
                    <div>
                      <h3 className="text-lg font-bold text-white leading-snug">{route.title}</h3>
                      <p className="text-xs text-slate-200">{route.subtitle}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        onQuickSearch({
                          originId: route.originId,
                          destinationId: route.destinationId,
                          outwardDate: demoDate,
                          outwardTime: '08:30',
                          adults: 1,
                          children: 0,
                          railcards: [],
                          travelClass: 'standard',
                          journeyType: 'one_way',
                          scenarioMode: 'normal',
                        })
                      }
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-white hover:bg-[#CFF7EE] text-[#0B1E36] text-xs font-semibold rounded-lg transition-colors"
                    >
                      <span>Explore trains</span>
                      <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right 4 cols: Find the journey that fits */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between shadow-xs">
            <div>
              <h2 className="text-xl font-bold text-[#0B1E36] mb-4">Find the journey that fits</h2>
              <div className="divide-y divide-slate-100">
                <button
                  type="button"
                  onClick={() => onOpenGuide('flexible')}
                  className="w-full py-3.5 flex items-center justify-between gap-3 text-left hover:bg-slate-50 rounded-lg px-2 -mx-2 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-[#CFF7EE] flex items-center justify-center shrink-0">
                      <Armchair className="w-5 h-5 text-[#008C77]" aria-hidden="true" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-[#0B1E36]">Flexible</div>
                      <div className="text-xs text-slate-500">
                        Off-Peak & Anytime ticket freedom
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                </button>

                <button
                  type="button"
                  onClick={() => onOpenGuide('lowest')}
                  className="w-full py-3.5 flex items-center justify-between gap-3 text-left hover:bg-slate-50 rounded-lg px-2 -mx-2 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
                      <Tag className="w-5 h-5 text-[#EF4B42]" aria-hidden="true" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-[#0B1E36]">Lowest fare</div>
                      <div className="text-xs text-slate-500">
                        Advance singles bound to one train
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                </button>

                <button
                  type="button"
                  onClick={() => onOpenGuide('first')}
                  className="w-full py-3.5 flex items-center justify-between gap-3 text-left hover:bg-slate-50 rounded-lg px-2 -mx-2 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-[#CFF7EE] flex items-center justify-center shrink-0">
                      <Star className="w-5 h-5 text-[#008C77]" aria-hidden="true" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-[#0B1E36]">First class</div>
                      <div className="text-xs text-slate-500">
                        Wider seating, tables & lounge rules
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                </button>
              </div>
            </div>

            <div className="pt-3 mt-2 border-t border-slate-100 text-xs text-slate-500">
              All fare conditions shown clearly before seller redirect.
            </div>
          </div>
        </div>
      </section>

      {/* Saved-Search Shortcut Strip */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#CFF7EE] flex items-center justify-center shrink-0">
              <Bookmark className="w-4 h-4 text-[#008C77]" aria-hidden="true" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#0B1E36]">Saved-search shortcuts</h3>
              <p className="text-xs text-slate-500">
                Re-run saved routes or launch the Sheffield → London demonstration enquiry.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() =>
                onQuickSearch({
                  originId: 'SHF',
                  destinationId: 'STP',
                  outwardDate: demoDate,
                  outwardTime: '08:30',
                  adults: 1,
                  children: 0,
                  railcards: [],
                  travelClass: 'standard',
                  journeyType: 'one_way',
                  scenarioMode: 'normal',
                })
              }
              className="px-3.5 py-2 text-xs font-semibold text-[#072434] bg-[#CFF7EE] hover:bg-[#14D1B5] rounded-lg transition-colors"
            >
              Demo: Sheffield → London (1 Adult)
            </button>

            {savedSearches.slice(0, 2).map((ss) => (
              <button
                key={ss.id}
                type="button"
                onClick={() => onQuickSearch(ss.input)}
                className="px-3.5 py-2 text-xs font-semibold text-[#0B1E36] bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                {ss.label}
              </button>
            ))}

            <button
              type="button"
              onClick={onOpenSavedTab}
              className="px-3 py-2 text-xs font-semibold text-[#008C77] hover:underline"
            >
              Manage saved journeys →
            </button>
          </div>
        </div>
      </section>

      {/* From City Centres to Scenic Coastlines (Matching Reference Bottom Band) */}
      <section className="bg-white border-y border-slate-200 py-12">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-3 space-y-3">
              <h2 className="text-2xl font-bold text-[#0B1E36] leading-tight [text-wrap:balance]">
                From city centres to scenic coastlines
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Explore direct intercity routes, Highland viaducts, and coastal railways across Great Britain with transparent ticket rules.
              </p>
            </div>

            <div className="lg:col-span-9 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {SCENIC_CATEGORIES.map((cat) => (
                <button
                  key={cat.title}
                  type="button"
                  onClick={() =>
                    onQuickSearch({
                      originId: cat.originId,
                      destinationId: cat.destinationId,
                      outwardDate: demoDate,
                      outwardTime: '09:15',
                      adults: 1,
                      children: 0,
                      railcards: [],
                      travelClass: 'standard',
                      journeyType: 'one_way',
                      scenarioMode: 'normal',
                    })
                  }
                  className="group relative h-44 rounded-2xl overflow-hidden text-left shadow-xs border border-slate-200 flex flex-col justify-end"
                >
                  <Image
                    src={cat.image}
                    alt={cat.alt}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                  />
                  <div
                    aria-hidden="true"
                    className="absolute inset-0 bg-gradient-to-t from-[#0B1E36]/90 via-[#0B1E36]/35 to-transparent"
                  />
                  <div className="relative z-10 p-4 flex items-end justify-between gap-2">
                    <div>
                      <div className="text-base font-bold text-white">{cat.title}</div>
                      <div className="text-xs text-slate-200 line-clamp-2">{cat.subtitle}</div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-white shrink-0" />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Luggage, Changes & Reservations Practical Guide */}
          <div className="pt-8 border-t border-slate-200 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-bold text-[#0B1E36]">
                <Luggage className="w-4 h-4 text-[#EF4B42]" aria-hidden="true" />
                <span>Luggage allowances</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                National Rail conditions generally allow up to two large bags and one small item of hand luggage free of charge, subject to operator space and cycle reservation rules.
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-bold text-[#0B1E36]">
                <Repeat className="w-4 h-4 text-[#EF4B42]" aria-hidden="true" />
                <span>Changes & refunds</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Advance fares are non-refundable and tied to the booked train; Off-Peak and Anytime fares allow travel on other eligible trains and refunds before expiry.
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-bold text-[#0B1E36]">
                <Armchair className="w-4 h-4 text-[#EF4B42]" aria-hidden="true" />
                <span>Seat reservations</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Advance tickets include a compulsory reservation where offered. Railunion displays reservation status honestly and never claims a seat is reserved prior to seller checkout.
              </p>
              <button
                type="button"
                onClick={() => onOpenGuide('luggage')}
                className="text-xs font-semibold text-[#008C77] hover:underline pt-1"
              >
                Read full ticket & travel guides →
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
