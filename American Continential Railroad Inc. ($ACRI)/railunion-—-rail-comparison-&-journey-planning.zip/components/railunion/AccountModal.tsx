'use client';

import React, { useState } from 'react';
import { Download, LogOut, ShieldCheck, Trash2, User, X } from 'lucide-react';

interface AccountModalProps {
  open: boolean;
  authenticated: boolean;
  user: { id: string; email: string; displayName: string } | null;
  onClose: () => void;
  onAuthSuccess: (payload: {
    token?: string;
    user: { id: string; email: string; displayName: string };
    workspace: unknown;
  }) => void;
  onLogout: () => Promise<void>;
  onExportData: () => void;
  onDeleteAccount: () => Promise<void>;
}

export default function AccountModal({
  open,
  authenticated,
  user,
  onClose,
  onAuthSuccess,
  onLogout,
  onExportData,
  onDeleteAccount,
}: AccountModalProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const submitAuth = async (action: 'login' | 'register' | 'demo') => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/account', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'Railunion',
        },
        body: JSON.stringify(
          action === 'demo'
            ? { action: 'demo' }
            : { action, email, password, displayName }
        ),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Authentication failed.');
        return;
      }
      onAuthSuccess(data);
      onClose();
    } catch {
      setError('Network error while connecting to account service.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="account-modal-title"
      className="fixed inset-0 z-50 bg-[#0B1E36]/60 backdrop-blur-[2px] flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden">
        <div className="px-6 py-4 bg-[#0B1E36] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-[#14D1B5]" />
            <h2 id="account-modal-title" className="text-lg font-bold">
              {authenticated ? 'Your Railunion account' : 'Sign in to Railunion'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close account modal"
            className="p-1.5 rounded-lg text-slate-300 hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {authenticated && user ? (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <div className="text-sm font-bold text-[#0B1E36]">{user.displayName}</div>
                <div className="text-xs text-slate-600">{user.email}</div>
                <div className="flex items-center gap-1.5 text-[11px] text-[#007A68] pt-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Session active · Saved items scoped strictly to this account</span>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  onClick={onExportData}
                  className="w-full py-2.5 px-4 text-xs font-semibold text-[#0B1E36] bg-slate-100 hover:bg-slate-200 rounded-xl inline-flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Export account data (JSON)</span>
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await onLogout();
                    onClose();
                  }}
                  className="w-full py-2.5 px-4 text-xs font-semibold text-[#0B1E36] border border-slate-300 hover:bg-slate-50 rounded-xl inline-flex items-center justify-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign out</span>
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await onDeleteAccount();
                    onClose();
                  }}
                  className="w-full py-2.5 px-4 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-xl inline-flex items-center justify-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete account & saved journeys</span>
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="flex p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setError(null);
                  }}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
                    mode === 'login' ? 'bg-white text-[#0B1E36] shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Sign in
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setError(null);
                  }}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
                    mode === 'register' ? 'bg-white text-[#0B1E36] shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Create account
                </button>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  submitAuth(mode);
                }}
                className="space-y-3"
              >
                {mode === 'register' && (
                  <div>
                    <label htmlFor="auth-display-name" className="block text-xs font-semibold text-[#0B1E36] mb-1">
                      Your name
                    </label>
                    <input
                      id="auth-display-name"
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="e.g. Sam Patel"
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:outline-none focus:border-[#00B59A]"
                    />
                  </div>
                )}

                <div>
                  <label htmlFor="auth-email" className="block text-xs font-semibold text-[#0B1E36] mb-1">
                    Email address
                  </label>
                  <input
                    id="auth-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:outline-none focus:border-[#00B59A]"
                  />
                </div>

                <div>
                  <label htmlFor="auth-password" className="block text-xs font-semibold text-[#0B1E36] mb-1">
                    Password (min 8 characters)
                  </label>
                  <input
                    id="auth-password"
                    type="password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:outline-none focus:border-[#00B59A]"
                  />
                </div>

                {error && (
                  <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-900">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 text-sm font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] rounded-xl transition-colors"
                >
                  {loading ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}
                </button>
              </form>

              <div className="pt-3 border-t border-slate-200 space-y-2">
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => submitAuth('demo')}
                  className="w-full py-2.5 px-4 text-xs font-semibold text-[#0B1E36] bg-[#CFF7EE]/60 hover:bg-[#CFF7EE] rounded-xl transition-colors"
                >
                  Sign in as Demo Traveller (demo@railunion.example)
                </button>
                <p className="text-[11px] text-slate-500 text-center">
                  Demo account includes a pre-saved Sheffield → London search and price alert.
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
