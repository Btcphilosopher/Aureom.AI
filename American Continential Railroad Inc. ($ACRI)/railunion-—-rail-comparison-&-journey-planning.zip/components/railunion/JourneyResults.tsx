'use client';

import React, { useMemo, useState } from 'react';
import {
  Accessibility,
  AlertCircle,
  ArrowRight,
  Bell,
  Bookmark,
  ChevronDown,
  ChevronUp,
  Clock,
  ExternalLink,
  Filter,
  Info,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { sortJourneyResults, type SortMode } from '@/lib/railunion/comparison';
import { formatPence } from '@/lib/railunion/timezone';
import type {
  FareOffer,
  JourneyItinerary,
  JourneySearchResultItem,
  SearchResponse,
  Station,
} from '@/lib/railunion/types';

interface JourneyResultsProps {
  searchResponse: SearchResponse;
  stations: Station[];
  onInspectConditions: (offer: FareOffer) => void;
  onSelectOfferForHandoff: (offer: FareOffer, itinerary: JourneyItinerary) => void;
  onSaveItinerary: (itinerary: JourneyItinerary, offer: FareOffer | null) => void;
  onSaveCurrentSearch: () => void;
  onCreatePriceAlert: (observedLowestPence: number | null) => void;
}

export default function JourneyResults({
  searchResponse,
  stations,
  onInspectConditions,
  onSelectOfferForHandoff,
  onSaveItinerary,
  onSaveCurrentSearch,
  onCreatePriceAlert,
}: JourneyResultsProps) {
  const [activeDirection, setActiveDirection] = useState<'outward' | 'return'>('outward');
  const [sortBy, setSortBy] = useState<SortMode>('recommended');
  const [showRankingRule, setShowRankingRule] = useState(false);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  // Filters
  const [maxChanges, setMaxChanges] = useState<'any' | '0' | '1'>('any');
  const [flexFilter, setFlexFilter] = useState<'all' | 'flexible' | 'advance'>('all');
  const [providerFilter, setProviderFilter] = useState<string>('all');
  const [operatorFilter, setOperatorFilter] = useState<string>('all');
  const [classFilter, setClassFilter] = useState<'all' | 'standard' | 'first'>('all');

  // Expanded details per journey
  const [expandedLegs, setExpandedLegs] = useState<Record<string, boolean>>({});
  const [expandedAccess, setExpandedAccess] = useState<Record<string, boolean>>({});

  const rawItems =
    activeDirection === 'outward'
      ? searchResponse.directionResults.outward
      : searchResponse.directionResults.return;

  const availableOperators = useMemo(() => {
    const map = new Map<string, string>();
    for (const item of rawItems) {
      for (const op of item.itinerary.operators) {
        map.set(op.code, op.name);
      }
    }
    return Array.from(map.entries()).map(([code, name]) => ({ code, name }));
  }, [rawItems]);

  const filteredItems = useMemo(() => {
    const filtered = rawItems
      .filter((item) => {
        if (maxChanges === '0' && item.itinerary.changesCount !== 0) return false;
        if (maxChanges === '1' && item.itinerary.changesCount > 1) return false;
        if (
          operatorFilter !== 'all' &&
          !item.itinerary.operators.some((o) => o.code === operatorFilter)
        ) {
          return false;
        }
        return true;
      })
      .map((item): JourneySearchResultItem => {
        const filteredGroups = item.offerGroups.filter((grp) => {
          if (classFilter !== 'all' && grp.travelClass !== classFilter) return false;
          if (flexFilter === 'flexible' && grp.trainBinding === 'booked_train_only') return false;
          if (flexFilter === 'advance' && grp.trainBinding !== 'booked_train_only') return false;
          if (
            providerFilter !== 'all' &&
            !grp.offers.some((o) => o.provider_id === providerFilter)
          ) {
            return false;
          }
          return true;
        });

        return {
          ...item,
          offerGroups: filteredGroups,
        };
      })
      .filter((item) => item.offerGroups.length > 0 || item.allOffers.length === 0);

    return sortJourneyResults(filtered, sortBy);
  }, [rawItems, maxChanges, operatorFilter, classFilter, flexFilter, providerFilter, sortBy]);

  const lowestObservedPence = useMemo(() => {
    const prices = filteredItems
      .map((i) => i.lowestCompletePricePence)
      .filter((p): p is number => p !== null);
    return prices.length > 0 ? Math.min(...prices) : null;
  }, [filteredItems]);

  const formatDuration = (mins: number) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${m.toString().padStart(2, '0')}m`;
  };

  const renderFilterControls = () => (
    <div className="space-y-5 text-sm">
      <div>
        <div className="text-xs font-bold text-[#0B1E36] mb-2">Changes</div>
        <div className="space-y-1.5">
          {[
            { value: 'any', label: 'Any number of changes' },
            { value: '0', label: 'Direct trains only' },
            { value: '1', label: 'Maximum 1 change' },
          ].map((opt) => (
            <label key={opt.value} className="flex items-center gap-2 cursor-pointer text-slate-700">
              <input
                type="radio"
                name="changes-filter"
                checked={maxChanges === opt.value}
                onChange={() => setMaxChanges(opt.value as 'any' | '0' | '1')}
                className="text-[#00B59A] focus:ring-[#00B59A]"
              />
              <span>{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="pt-4 border-t border-slate-200">
        <div className="text-xs font-bold text-[#0B1E36] mb-2">Travel class</div>
        <div className="space-y-1.5">
          {[
            { value: 'all', label: 'All classes in search' },
            { value: 'standard', label: 'Standard' },
            { value: 'first', label: 'First class' },
          ].map((opt) => (
            <label key={opt.value} className="flex items-center gap-2 cursor-pointer text-slate-700">
              <input
                type="radio"
                name="class-filter"
                checked={classFilter === opt.value}
                onChange={() => setClassFilter(opt.value as 'all' | 'standard' | 'first')}
                className="text-[#00B59A] focus:ring-[#00B59A]"
              />
              <span>{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="pt-4 border-t border-slate-200">
        <div className="text-xs font-bold text-[#0B1E36] mb-2">Ticket flexibility</div>
        <div className="space-y-1.5">
          {[
            { value: 'all', label: 'All ticket types' },
            { value: 'flexible', label: 'Flexible (Off-Peak / Anytime)' },
            { value: 'advance', label: 'Advance (booked train only)' },
          ].map((opt) => (
            <label key={opt.value} className="flex items-center gap-2 cursor-pointer text-slate-700">
              <input
                type="radio"
                name="flex-filter"
                checked={flexFilter === opt.value}
                onChange={() => setFlexFilter(opt.value as 'all' | 'flexible' | 'advance')}
                className="text-[#00B59A] focus:ring-[#00B59A]"
              />
              <span>{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="pt-4 border-t border-slate-200">
        <label htmlFor="provider-filter-select" className="block text-xs font-bold text-[#0B1E36] mb-2">
          Provider
        </label>
        <select
          id="provider-filter-select"
          value={providerFilter}
          onChange={(e) => setProviderFilter(e.target.value)}
          className="w-full px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#00B59A]"
        >
          <option value="all">All connected providers</option>
          {searchResponse.providerReports.map((p) => (
            <option key={p.providerId} value={p.providerId}>
              {p.providerName}
            </option>
          ))}
        </select>
      </div>

      <div className="pt-4 border-t border-slate-200">
        <label htmlFor="operator-filter-select" className="block text-xs font-bold text-[#0B1E36] mb-2">
          Train operator
        </label>
        <select
          id="operator-filter-select"
          value={operatorFilter}
          onChange={(e) => setOperatorFilter(e.target.value)}
          className="w-full px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#00B59A]"
        >
          <option value="all">All train operators</option>
          {availableOperators.map((op) => (
            <option key={op.code} value={op.code}>
              {op.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );

  return (
    <section id="search-results-section" className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Coverage, Freshness & Actions Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-[#0B1E36]">
              Journey comparison results
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              {searchResponse.demonstrationNotice} · Search ref{' '}
              <span className="font-mono">{searchResponse.searchReference}</span> ·{' '}
              {searchResponse.cacheMetadata.cacheHit
                ? `Cached quote (${searchResponse.cacheMetadata.ttlSeconds}s TTL)`
                : 'Fresh provider quote'}{' '}
              at{' '}
              {new Date(searchResponse.cacheMetadata.cachedAtUtc).toLocaleTimeString('en-GB', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                timeZone: 'Europe/London',
              })}{' '}
              (Europe/London)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onSaveCurrentSearch}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#0B1E36] bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <Bookmark className="w-3.5 h-3.5 text-[#EF4B42]" />
              <span>Save search</span>
            </button>
            <button
              type="button"
              onClick={() => onCreatePriceAlert(lowestObservedPence)}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#0B1E36] bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <Bell className="w-3.5 h-3.5 text-[#008C77]" />
              <span>Create price alert</span>
            </button>
          </div>
        </div>

        {/* Provider Coverage & Partial Warning */}
        <div
          className={`p-3 rounded-xl border text-xs flex flex-wrap items-start justify-between gap-2 ${
            searchResponse.coverageSummary.isPartial
              ? 'bg-amber-50 border-amber-200 text-amber-950'
              : 'bg-slate-50 border-slate-200 text-slate-700'
          }`}
        >
          <div className="flex items-start gap-2">
            <AlertCircle
              className={`w-4 h-4 shrink-0 mt-0.5 ${
                searchResponse.coverageSummary.isPartial ? 'text-amber-700' : 'text-slate-500'
              }`}
            />
            <div>
              <span className="font-semibold">{searchResponse.coverageSummary.disclosure}</span>
              <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-[11px]">
                {searchResponse.providerReports.map((rep) => (
                  <span key={rep.providerId}>
                    <strong>{rep.providerName}</strong>: {rep.status.replace('_', ' ')} ({rep.offersReturned} offers,{' '}
                    {rep.responseTimeMs}ms)
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Split-ticketing Honest Status */}
        <div className="text-xs text-slate-600 flex items-center gap-2">
          <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>{searchResponse.returnCombinationsNote.splitTicketingReason}</span>
        </div>
      </div>

      {/* Return Direction Switcher if applicable */}
      {searchResponse.input.journeyType === 'return' && (
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveDirection('outward')}
            className={`px-4 py-2 text-sm font-semibold rounded-xl border transition-colors ${
              activeDirection === 'outward'
                ? 'bg-[#0B1E36] text-white border-[#0B1E36]'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            Outward trains ({searchResponse.directionResults.outward.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveDirection('return')}
            className={`px-4 py-2 text-sm font-semibold rounded-xl border transition-colors ${
              activeDirection === 'return'
                ? 'bg-[#0B1E36] text-white border-[#0B1E36]'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            Return trains ({searchResponse.directionResults.return.length})
          </button>
        </div>
      )}

      {/* Desktop Filters Sidebar + Results Column */}
      <div className="flex flex-col lg:flex-row gap-6 items-start">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:block w-72 shrink-0 bg-white border border-slate-200 rounded-2xl p-5 sticky top-20">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-[#0B1E36] flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-[#EF4B42]" />
              <span>Filter journeys</span>
            </h3>
            <button
              type="button"
              onClick={() => {
                setMaxChanges('any');
                setFlexFilter('all');
                setProviderFilter('all');
                setOperatorFilter('all');
                setClassFilter('all');
              }}
              className="text-xs font-medium text-[#008C77] hover:underline"
            >
              Reset
            </button>
          </div>
          {renderFilterControls()}
        </aside>

        {/* Main Column */}
        <div className="flex-1 min-w-0 w-full space-y-4">
          {/* Mobile Filter Trigger + Sort Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-3.5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setMobileFiltersOpen(true)}
                  className="lg:hidden inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#0B1E36] bg-slate-100 rounded-lg"
                >
                  <Filter className="w-3.5 h-3.5" />
                  <span>Filters</span>
                </button>
                <span className="text-xs font-semibold text-slate-600 tabular-nums">
                  {filteredItems.length} {filteredItems.length === 1 ? 'journey' : 'journeys'} shown
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {(
                  [
                    { id: 'recommended', label: 'Recommended' },
                    { id: 'lowest_comparable_total', label: 'Lowest comparable total' },
                    { id: 'earliest_arrival', label: 'Earliest arrival' },
                    { id: 'shortest_duration', label: 'Shortest duration' },
                    { id: 'fewest_changes', label: 'Fewest changes' },
                  ] as { id: SortMode; label: string }[]
                ).map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSortBy(s.id)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                      sortBy === s.id
                        ? 'bg-[#CFF7EE] text-[#0B1E36]'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {sortBy === 'recommended' && (
              <div className="pt-2 border-t border-slate-100 flex items-start justify-between gap-2 text-xs text-slate-600">
                <div>
                  <span className="font-semibold text-[#0B1E36]">Ranking rule: </span>
                  {showRankingRule
                    ? searchResponse.rankingRuleDisclosure
                    : 'Balances total comparable fare, duration, changes, and train flexibility.'}
                </div>
                <button
                  type="button"
                  onClick={() => setShowRankingRule((v) => !v)}
                  className="text-xs font-semibold text-[#008C77] hover:underline shrink-0"
                >
                  {showRankingRule ? 'Hide formula' : 'How Recommended works'}
                </button>
              </div>
            )}
          </div>

          {/* Empty State */}
          {filteredItems.length === 0 && (
            <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center space-y-2">
              <p className="text-base font-bold text-[#0B1E36]">No journeys match your active filters</p>
              <p className="text-sm text-slate-600">
                Try clearing class, flexibility, or change filters to view all available services.
              </p>
            </div>
          )}

          {/* Journey Cards */}
          {filteredItems.map((item) => {
            const it = item.itinerary;
            const depTime = it.departureLocal.slice(11, 16);
            const arrTime = it.arrivalLocal.slice(11, 16);
            const legsExpanded = Boolean(expandedLegs[it.journeyId]);
            const accessExpanded = Boolean(expandedAccess[it.journeyId]);
            const origStation = stations.find((s) => s.id === it.originStationId);
            const destStation = stations.find((s) => s.id === it.destinationStationId);

            return (
              <article
                key={it.journeyId}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs"
              >
                {/* Journey Header Row */}
                <div className="p-5 space-y-4">
                  {it.stationGroupNotice && (
                    <div className="text-xs text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                      {it.stationGroupNotice}
                    </div>
                  )}

                  {it.dstTransitionNotice && (
                    <div className="text-xs text-amber-900 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200">
                      {it.dstTransitionNotice}
                    </div>
                  )}

                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-3 flex-wrap">
                        <span className="text-2xl font-bold text-[#0B1E36] tabular-nums">
                          {depTime}
                        </span>
                        <ArrowRight className="w-4 h-4 text-slate-400" aria-hidden="true" />
                        <span className="text-2xl font-bold text-[#0B1E36] tabular-nums">
                          {arrTime}
                        </span>
                        {it.overnightDays > 0 && (
                          <span className="text-xs font-bold text-[#EF4B42] tabular-nums">
                            +{it.overnightDays} day{it.overnightDays > 1 ? 's' : ''} (overnight)
                          </span>
                        )}
                      </div>

                      <div className="text-sm font-semibold text-[#0B1E36]">
                        {it.originName} ({it.originCrs}) → {it.destinationName} ({it.destinationCrs})
                      </div>

                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 tabular-nums">
                        <span className="inline-flex items-center gap-1 font-medium">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          {formatDuration(it.durationMinutes)}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {it.changesCount === 0
                            ? 'Direct'
                            : `${it.changesCount} change${it.changesCount > 1 ? 's' : ''} (${it.interchangeNames.join(', ')})`}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{it.operators.map((o) => o.name).join(' + ')}</span>
                      </div>
                    </div>

                    <div className="flex flex-col sm:items-end gap-1.5 shrink-0">
                      <div className="text-xs text-slate-500">Lowest complete comparable fare</div>
                      <div className="text-2xl font-bold text-[#0B1E36] tabular-nums">
                        {item.lowestCompletePricePence !== null
                          ? formatPence(item.lowestCompletePricePence)
                          : 'Incomplete fee'}
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onSaveItinerary(it, item.offerGroups[0]?.offers[0] ?? null)}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-[#0B1E36] hover:text-[#EF4B42] transition-colors"
                        >
                          <Bookmark className="w-3.5 h-3.5" />
                          <span>Save journey</span>
                        </button>
                        <span aria-hidden="true" className="text-slate-300">
                          |
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedLegs((prev) => ({
                              ...prev,
                              [it.journeyId]: !prev[it.journeyId],
                            }))
                          }
                          className="inline-flex items-center gap-1 text-xs font-semibold text-[#008C77] hover:underline"
                        >
                          <span>{legsExpanded ? 'Hide legs' : 'Journey legs'}</span>
                          {legsExpanded ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Disruption notice separated cleanly from fare availability */}
                  {it.disruptions.length > 0 && (
                    <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-950 space-y-1">
                      {it.disruptions.map((d) => (
                        <div key={d.id}>
                          <span className="font-semibold">Live running notice: </span>
                          {d.headline} — {d.detail} ({d.source}, reported{' '}
                          {new Date(d.reportedAtUtc).toLocaleTimeString('en-GB', {
                            hour: '2-digit',
                            minute: '2-digit',
                            timeZone: 'Europe/London',
                          })}
                          )
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Expanded Legs & Accessibility */}
                  {legsExpanded && (
                    <div className="pt-3 border-t border-slate-100 space-y-3">
                      <div className="text-xs font-bold text-[#0B1E36]">
                        Service itinerary ({it.timetableSource})
                      </div>
                      <div className="space-y-2">
                        {it.legs.map((leg, idx) => (
                          <div
                            key={leg.legId}
                            className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-2 font-semibold text-[#0B1E36] tabular-nums">
                              <span>
                                Leg {idx + 1}: {leg.scheduledDepartureLocal.slice(11, 16)}{' '}
                                {leg.originName} ({leg.originCrs}) →{' '}
                                {leg.scheduledArrivalLocal.slice(11, 16)} {leg.destinationName} (
                                {leg.destinationCrs})
                              </span>
                              <span className="font-mono text-slate-500">
                                {leg.operatorName} · {leg.headcode} · Platform {leg.platform ?? 'TBC'}
                              </span>
                            </div>
                            <div className="text-slate-600 tabular-nums">
                              Scheduled {leg.durationMinutes}m · Estimated departure{' '}
                              {leg.estimatedDepartureLocal ?? 'Unavailable'} ·{' '}
                              {leg.callingPointsCount} intermediate stops
                            </div>
                            {leg.transferNote && (
                              <div className="text-slate-700 font-medium pt-1">
                                Interchange: {leg.transferNote}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>

                      <div>
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedAccess((prev) => ({
                              ...prev,
                              [it.journeyId]: !prev[it.journeyId],
                            }))
                          }
                          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0B1E36] hover:text-[#008C77]"
                        >
                          <Accessibility className="w-4 h-4 text-[#008C77]" />
                          <span>
                            {accessExpanded
                              ? 'Hide station accessibility details'
                              : 'Inspect station accessibility & Passenger Assist'}
                          </span>
                        </button>

                        {accessExpanded && (
                          <div className="mt-2 p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-2 text-slate-700">
                            {[origStation, destStation].map((st) =>
                              st ? (
                                <div key={st.id} className="space-y-0.5">
                                  <div className="font-semibold text-[#0B1E36]">
                                    {st.name} ({st.crs}): Step-free access ={' '}
                                    <span className="uppercase">{st.accessibility.stepFreeAccess}</span> ·
                                    Tactile paving = {st.accessibility.tactilePaving}
                                  </div>
                                  <div>{st.accessibility.summary}</div>
                                  <div className="text-[11px] text-slate-500">
                                    Source: {st.accessibility.source} ·{' '}
                                    <a
                                      href={st.accessibility.officialAssistanceUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="inline-flex items-center gap-1 text-[#008C77] font-semibold hover:underline"
                                    >
                                      National Rail Passenger Assist
                                      <ExternalLink className="w-3 h-3" />
                                    </a>
                                  </div>
                                </div>
                              ) : null
                            )}
                            <p className="text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                              Saving a journey in Railunion does not book or confirm Passenger Assist.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Comparable Offer Groups */}
                <div className="border-t border-slate-200 bg-[#F8FAFC] divide-y divide-slate-200">
                  {item.offerGroups.length === 0 ? (
                    <div className="p-4 text-xs text-slate-600">
                      No purchasable fare offers were returned by connected providers for this journey under the current scenario/filters.
                    </div>
                  ) : (
                    item.offerGroups.map((group) => (
                      <div key={group.equivalenceKey} className="p-4 space-y-2.5">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <div className="text-sm font-bold text-[#0B1E36]">
                              {group.ticketProduct}{' '}
                              <span className="text-xs font-medium text-slate-500">
                                · {group.flexibilityLabel} ·{' '}
                                {group.travelClass === 'first' ? 'First Class' : 'Standard'}
                              </span>
                            </div>
                            {group.plainDifferenceNote && (
                              <p className="text-xs text-[#007A68] font-medium mt-0.5">
                                {group.plainDifferenceNote}
                              </p>
                            )}
                          </div>
                          <div className="text-xs text-slate-500">
                            {group.offers.length} equivalent seller{' '}
                            {group.offers.length === 1 ? 'offer' : 'offers'}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                          {group.offers.map((offer) => {
                            const isLowestComplete =
                              offer.offer_id === group.lowestComparableOfferId &&
                              offer.fee_completeness === 'complete';

                            return (
                              <div
                                key={offer.offer_id}
                                className="bg-white border border-slate-200 rounded-xl p-3.5 flex flex-col justify-between gap-3"
                              >
                                <div className="flex items-start justify-between gap-3">
                                  <div className="min-w-0">
                                    <div className="text-xs font-bold text-[#0B1E36] truncate">
                                      {offer.seller_name}
                                    </div>
                                    <div className="text-[11px] text-slate-500 mt-0.5">
                                      {offer.condition_summary_short}
                                    </div>
                                    <div className="text-[11px] text-slate-500 mt-0.5 tabular-nums">
                                      Ticket {formatPence(offer.ticket_price)} · Fee{' '}
                                      {offer.mandatory_fees === null
                                        ? 'Unknown'
                                        : formatPence(offer.mandatory_fees)}
                                    </div>
                                    <div className="text-[11px] text-slate-400 mt-0.5">
                                      Quoted{' '}
                                      {new Date(offer.quoted_at).toLocaleTimeString('en-GB', {
                                        hour: '2-digit',
                                        minute: '2-digit',
                                        timeZone: 'Europe/London',
                                      })}
                                      {offer.availability_status === 'expired'
                                        ? ' · Expired quote'
                                        : ''}
                                    </div>
                                  </div>

                                  <div className="text-right shrink-0">
                                    <div className="text-lg font-bold text-[#0B1E36] tabular-nums">
                                      {offer.total_known_payable_pence === null
                                        ? `${formatPence(offer.ticket_price)} + fee?`
                                        : formatPence(offer.total_known_payable_pence)}
                                    </div>
                                    {isLowestComplete && (
                                      <div className="text-[11px] font-semibold text-[#007A68]">
                                        Lowest comparable total
                                      </div>
                                    )}
                                    {offer.fee_completeness !== 'complete' && (
                                      <div className="text-[11px] font-semibold text-amber-700">
                                        Mandatory fee unknown
                                      </div>
                                    )}
                                  </div>
                                </div>

                                <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
                                  <button
                                    type="button"
                                    onClick={() => onInspectConditions(offer)}
                                    className="text-xs font-semibold text-[#0B1E36] hover:text-[#008C77] underline underline-offset-2"
                                  >
                                    Ticket conditions
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => onSelectOfferForHandoff(offer, it)}
                                    className="px-3.5 py-1.5 text-xs font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] rounded-lg transition-colors whitespace-nowrap"
                                  >
                                    Continue to seller
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </div>

      {/* Adaptive Mobile Filter Sheet */}
      {mobileFiltersOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Filter train journeys"
          className="fixed inset-0 z-50 bg-[#0B1E36]/60 flex justify-end lg:hidden"
        >
          <div className="w-80 max-w-full bg-white h-full p-5 overflow-y-auto shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="text-base font-bold text-[#0B1E36]">Filter journeys</h3>
              <button
                type="button"
                onClick={() => setMobileFiltersOpen(false)}
                aria-label="Close filters"
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {renderFilterControls()}
            <button
              type="button"
              onClick={() => setMobileFiltersOpen(false)}
              className="w-full py-2.5 text-sm font-semibold text-[#072434] bg-[#14D1B5] rounded-xl"
            >
              Show {filteredItems.length} results
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
