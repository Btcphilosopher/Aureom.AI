'use client';

import React from 'react';
import { FileText, X } from 'lucide-react';
import { formatPence } from '@/lib/railunion/timezone';
import type { FareOffer } from '@/lib/railunion/types';

interface TicketConditionsModalProps {
  offer: FareOffer | null;
  onClose: () => void;
  onProceedToSeller: (offer: FareOffer) => void;
}

export default function TicketConditionsModal({
  offer,
  onClose,
  onProceedToSeller,
}: TicketConditionsModalProps) {
  if (!offer) return null;

  const formatFee = (pence: number | null) => {
    if (pence === null) return 'Unknown (not disclosed by provider)';
    return formatPence(pence);
  };

  const rows: { label: string; value: string }[] = [
    { label: 'Offer identifier', value: offer.offer_id },
    { label: 'Provider / Seller', value: `${offer.provider_name} (${offer.provider_id})` },
    { label: 'Journey reference', value: offer.journey_reference },
    { label: 'Passenger coverage', value: offer.passenger_composition.summary },
    {
      label: 'Railcards applied',
      value: offer.railcards_applied.length > 0 ? offer.railcards_applied.join(', ') : 'None',
    },
    { label: 'Travel class', value: offer.travel_class === 'first' ? 'First Class' : 'Standard' },
    { label: 'Ticket product', value: offer.ticket_product },
    { label: 'Route restrictions', value: offer.route_restrictions },
    { label: 'Operator restrictions', value: offer.operator_restrictions },
    { label: 'Time restrictions', value: offer.time_restrictions },
    {
      label: 'Train binding',
      value:
        offer.train_binding === 'booked_train_only'
          ? 'Valid only on booked train'
          : offer.train_binding === 'flexible_any_permitted'
            ? 'Flexible across any permitted train'
            : offer.train_binding,
    },
    {
      label: 'Reservation status',
      value:
        offer.reservation_status === 'included_compulsory'
          ? 'Included / compulsory on booked service'
          : offer.reservation_status === 'optional_recommended'
            ? 'Optional / recommended'
            : offer.reservation_status,
    },
    { label: 'Refund conditions', value: offer.refund_conditions },
    { label: 'Change conditions', value: offer.change_conditions },
    { label: 'Ticket price', value: formatPence(offer.ticket_price) },
    { label: 'Mandatory booking fees', value: formatFee(offer.mandatory_fees) },
    {
      label: `Fulfilment (${offer.fulfilment_method.replace('_', ' ')})`,
      value: formatFee(offer.fulfilment_fees),
    },
    {
      label: 'Total known payable',
      value:
        offer.total_known_payable_pence === null
          ? 'Incomplete — mandatory fee unknown'
          : `${formatPence(offer.total_known_payable_pence)} (${offer.currency})`,
    },
    {
      label: 'Quote freshness & expiry',
      value: `Quoted ${new Date(offer.quoted_at).toLocaleTimeString('en-GB', {
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Europe/London',
      })} · Expires ${new Date(offer.expires_at).toLocaleTimeString('en-GB', {
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Europe/London',
      })} (Europe/London)`,
    },
    { label: 'Seller handoff reference', value: offer.seller_handoff_reference },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ticket-conditions-title"
      className="fixed inset-0 z-50 bg-[#0B1E36]/60 backdrop-blur-[2px] flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[88vh] flex flex-col">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 min-w-0">
            <FileText className="w-5 h-5 text-[#EF4B42] shrink-0" aria-hidden="true" />
            <div className="min-w-0">
              <h2 id="ticket-conditions-title" className="text-lg font-bold text-[#0B1E36] truncate">
                Ticket conditions — {offer.ticket_product}
              </h2>
              <p className="text-xs text-slate-500">
                {offer.provider_name} · {offer.passenger_composition.summary}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close ticket conditions"
            className="p-2 rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto divide-y divide-slate-100 text-sm">
          {rows.map((row) => (
            <div key={row.label} className="py-2.5 grid grid-cols-1 sm:grid-cols-3 gap-1 sm:gap-4">
              <dt className="font-medium text-slate-500">{row.label}</dt>
              <dd className="sm:col-span-2 text-[#0B1E36] font-medium tabular-nums break-words">
                {row.value}
              </dd>
            </div>
          ))}
        </div>

        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 rounded-b-2xl flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-slate-600">
            Railunion compares fares and conditions; tickets are issued solely by the authorised seller.
          </p>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onProceedToSeller(offer);
              }}
              className="px-4 py-2 text-sm font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] rounded-lg transition-colors"
            >
              Continue to seller
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
