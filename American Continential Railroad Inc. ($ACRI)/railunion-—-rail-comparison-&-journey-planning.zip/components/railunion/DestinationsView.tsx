'use client';

import React, { useState } from 'react';
import { Accessibility, ExternalLink, Search, Star, Train } from 'lucide-react';
import { getDefaultLondonSearchDate } from '@/lib/railunion/timezone';
import type { FavouriteStationRecord, SearchInput, Station } from '@/lib/railunion/types';

interface DestinationsViewProps {
  stations: Station[];
  favourites: FavouriteStationRecord[];
  onToggleFavourite: (station: Station) => void;
  onPlanFromStation: (partial: Partial<SearchInput>) => void;
}

export default function DestinationsView({
  stations,
  favourites,
  onToggleFavourite,
  onPlanFromStation,
}: DestinationsViewProps) {
  const [filterQuery, setFilterQuery] = useState('');
  const [kindFilter, setKindFilter] = useState<'all' | 'individual' | 'group'>('all');

  const filtered = stations.filter((st) => {
    if (kindFilter === 'individual' && st.kind !== 'individual') return false;
    if (kindFilter === 'group' && st.kind === 'individual') return false;
    const q = filterQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      st.name.toLowerCase().includes(q) ||
      st.crs.toLowerCase().includes(q) ||
      st.region.toLowerCase().includes(q)
    );
  });

  const demoDate = getDefaultLondonSearchDate(2);

  return (
    <section className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-[#0B1E36]">
              Great Britain destinations & stations
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Inspect stable CRS, NLC, and TIPLOC identifiers, distinguish individual terminals from station groups, and check attributed accessibility data.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'individual', label: 'Individual stations' },
                { id: 'group', label: 'Station / city groups' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setKindFilter(tab.id)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
                  kindFilter === tab.id
                    ? 'bg-[#CFF7EE] text-[#0B1E36]'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="relative max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" aria-hidden="true" />
          <input
            type="text"
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            placeholder="Filter by station name, CRS code, or region…"
            className="w-full pl-9 pr-4 py-2 text-sm border border-slate-300 rounded-xl focus:outline-none focus:border-[#00B59A]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((st) => {
          const isFav = favourites.some((f) => f.stationId === st.id);
          return (
            <article
              key={st.id}
              className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between gap-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-xs font-medium text-slate-500">
                      {st.kind === 'individual' ? 'Individual station' : 'City / station group'} ·{' '}
                      {st.region}
                    </div>
                    <h2 className="text-lg font-bold text-[#0B1E36] mt-0.5 flex items-center gap-2">
                      <Train className="w-4 h-4 text-[#EF4B42] shrink-0" />
                      <span>{st.name}</span>
                    </h2>
                  </div>

                  <button
                    type="button"
                    onClick={() => onToggleFavourite(st)}
                    aria-label={isFav ? `Remove ${st.name} from favourites` : `Save ${st.name} as favourite`}
                    className={`p-2 rounded-lg border transition-colors ${
                      isFav
                        ? 'bg-red-50 border-red-200 text-[#EF4B42]'
                        : 'bg-white border-slate-200 text-slate-400 hover:text-[#EF4B42]'
                    }`}
                  >
                    <Star className="w-4 h-4" fill={isFav ? 'currentColor' : 'none'} />
                  </button>
                </div>

                <div className="flex flex-wrap gap-3 text-xs font-mono text-slate-600 tabular-nums">
                  <span>CRS: {st.crs}</span>
                  <span>·</span>
                  <span>NLC: {st.nlc}</span>
                  <span>·</span>
                  <span>TIPLOC: {st.tiploc}</span>
                </div>

                {st.memberStationIds.length > 0 && (
                  <div className="text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-xl p-2.5">
                    Covers terminals: {st.memberStationIds.join(', ')}. Selecting a specific terminal instead will never silently substitute another terminal.
                  </div>
                )}

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-[#0B1E36]">
                    <Accessibility className="w-3.5 h-3.5 text-[#008C77]" />
                    <span>
                      Step-free access: {st.accessibility.stepFreeAccess.toUpperCase()} · Tactile
                      paving: {st.accessibility.tactilePaving.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-slate-600">{st.accessibility.summary}</p>
                  <div className="text-[11px] text-slate-500 flex flex-wrap items-center justify-between gap-2 pt-1">
                    <span>Source: {st.accessibility.source}</span>
                    <a
                      href={st.accessibility.officialAssistanceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[#008C77] font-semibold hover:underline"
                    >
                      Passenger Assist
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                <div className="text-xs text-slate-500">
                  Nearby: {st.nearbyStationIds.length > 0 ? st.nearbyStationIds.join(', ') : 'None listed'}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onPlanFromStation({
                        originId: st.id,
                        destinationId: st.id === 'STP' || st.id === 'LON' ? 'SHF' : 'STP',
                        outwardDate: demoDate,
                      })
                    }
                    className="px-3.5 py-1.5 text-xs font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] rounded-lg transition-colors"
                  >
                    Trains from {st.crs}
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
