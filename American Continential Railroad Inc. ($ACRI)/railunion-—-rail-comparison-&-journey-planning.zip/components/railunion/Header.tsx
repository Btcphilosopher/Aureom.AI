'use client';

import React, { useState } from 'react';
import { Menu, TrainFront, User, X } from 'lucide-react';

export type ActiveNavTab = 'trains' | 'destinations' | 'saved' | 'help';

interface HeaderProps {
  activeTab: ActiveNavTab;
  onSelectTab: (tab: ActiveNavTab) => void;
  userDisplayName: string | null;
  onOpenAccount: () => void;
  onResetHome: () => void;
}

const NAV_ITEMS: { id: ActiveNavTab; label: string }[] = [
  { id: 'trains', label: 'Trains' },
  { id: 'destinations', label: 'Destinations' },
  { id: 'saved', label: 'Saved journeys' },
  { id: 'help', label: 'Help' },
];

export default function Header({
  activeTab,
  onSelectTab,
  userDisplayName,
  onOpenAccount,
  onResetHome,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#0B1E36] text-white border-b border-white/10">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <button
          type="button"
          onClick={onResetHome}
          className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#14D1B5] rounded-md"
        >
          <TrainFront className="w-6 h-6 text-[#EF4B42] shrink-0" aria-hidden="true" />
          <span className="text-xl font-bold tracking-tight lowercase text-white">railunion</span>
        </button>

        {/* Zone 2: 4 concise single-line nav links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-7">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`relative py-5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#14D1B5] ${
                  isActive ? 'text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute left-0 right-0 bottom-2.5 h-[2.5px] bg-[#EF4B42] rounded-full"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Account Action */}
        <div className="flex items-center gap-4 shrink-0">
          <span className="hidden sm:inline text-xs font-medium text-slate-300 whitespace-nowrap">
            GBP £
          </span>
          <button
            type="button"
            onClick={onOpenAccount}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white border border-white/25 rounded-lg hover:bg-white/10 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#14D1B5]"
          >
            <User className="w-4 h-4 text-[#14D1B5]" aria-hidden="true" />
            <span className="truncate max-w-[140px]">
              {userDisplayName ? userDisplayName : 'Account'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((v) => !v)}
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="md:hidden p-2 rounded-lg text-slate-200 hover:bg-white/10"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0F2744] border-t border-white/10 px-4 py-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-white/10 text-white border-b-2 border-[#EF4B42]'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
}
