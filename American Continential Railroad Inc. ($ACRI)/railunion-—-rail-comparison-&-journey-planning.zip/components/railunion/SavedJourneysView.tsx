'use client';

import React, { useState } from 'react';
import {
  Bell,
  Bookmark,
  Download,
  RefreshCw,
  Search,
  Star,
  Trash2,
  UserCheck,
} from 'lucide-react';
import { formatPence } from '@/lib/railunion/timezone';
import type {
  FavouriteStationRecord,
  PriceAlertRecord,
  SavedItineraryRecord,
  SavedSearchRecord,
  SearchInput,
} from '@/lib/railunion/types';

interface SavedJourneysViewProps {
  authenticated: boolean;
  userEmail: string | null;
  savedSearches: SavedSearchRecord[];
  favouriteStations: FavouriteStationRecord[];
  savedItineraries: SavedItineraryRecord[];
  priceAlerts: PriceAlertRecord[];
  onOpenAccount: () => void;
  onRunSavedSearch: (input: SearchInput) => void;
  onDeleteItem: (kind: 'search' | 'itinerary' | 'alert', id: string) => void;
  onRunAlertCheck: () => Promise<void>;
  onExportData: () => void;
  onDeleteAccount: () => void;
}

export default function SavedJourneysView({
  authenticated,
  userEmail,
  savedSearches,
  favouriteStations,
  savedItineraries,
  priceAlerts,
  onOpenAccount,
  onRunSavedSearch,
  onDeleteItem,
  onRunAlertCheck,
  onExportData,
  onDeleteAccount,
}: SavedJourneysViewProps) {
  const [checkingAlerts, setCheckingAlerts] = useState(false);
  const [confirmDeleteAccount, setConfirmDeleteAccount] = useState(false);

  if (!authenticated) {
    return (
      <section className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center space-y-4">
          <UserCheck className="w-10 h-10 text-[#008C77] mx-auto" />
          <h1 className="text-2xl font-bold text-[#0B1E36]">Sign in to access saved journeys</h1>
          <p className="text-sm text-slate-600 max-w-md mx-auto">
            Save train searches, favourite stations, itineraries, and price alerts scoped strictly to your Railunion account.
          </p>
          <button
            type="button"
            onClick={onOpenAccount}
            className="px-6 py-2.5 text-sm font-semibold text-[#072434] bg-[#14D1B5] hover:bg-[#0FC0A5] rounded-xl transition-colors"
          >
            Sign in or use demo account
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#0B1E36]">Saved journeys & alerts</h1>
          <p className="text-xs text-slate-600 mt-1">
            Signed in as <span className="font-semibold">{userEmail}</span>. Saved itineraries are comparison snapshots only — never boarding credentials or confirmed tickets.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onExportData}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#0B1E36] bg-slate-100 hover:bg-slate-200 rounded-lg"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>

          {!confirmDeleteAccount ? (
            <button
              type="button"
              onClick={() => setConfirmDeleteAccount(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-lg"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete account</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-1.5">
              <span className="text-xs font-semibold text-red-900">Confirm permanent deletion?</span>
              <button
                type="button"
                onClick={onDeleteAccount}
                className="px-2.5 py-1 text-xs font-bold bg-red-600 text-white rounded-md"
              >
                Delete
              </button>
              <button
                type="button"
                onClick={() => setConfirmDeleteAccount(false)}
                className="px-2 py-1 text-xs font-medium text-slate-700"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Saved Searches */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
          <h2 className="text-base font-bold text-[#0B1E36] flex items-center gap-2">
            <Search className="w-4 h-4 text-[#EF4B42]" />
            <span>Saved searches ({savedSearches.length})</span>
          </h2>

          {savedSearches.length === 0 ? (
            <p className="text-sm text-slate-500">No saved searches yet. Run a search and click Save search.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {savedSearches.map((ss) => (
                <div key={ss.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-[#0B1E36] truncate">{ss.label}</div>
                    <div className="text-xs text-slate-500 tabular-nums">
                      {ss.input.originId} → {ss.input.destinationId} · {ss.input.outwardDate} {ss.input.outwardTime} ·{' '}
                      {ss.input.adults} adult{ss.input.adults > 1 ? 's' : ''}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onRunSavedSearch(ss.input)}
                      className="px-3 py-1.5 text-xs font-semibold text-[#072434] bg-[#CFF7EE] hover:bg-[#14D1B5] rounded-lg"
                    >
                      Re-run
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteItem('search', ss.id)}
                      aria-label={`Delete saved search ${ss.label}`}
                      className="p-1.5 text-slate-400 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Favourite Stations */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
          <h2 className="text-base font-bold text-[#0B1E36] flex items-center gap-2">
            <Star className="w-4 h-4 text-[#EF4B42]" />
            <span>Favourite stations ({favouriteStations.length})</span>
          </h2>

          {favouriteStations.length === 0 ? (
            <p className="text-sm text-slate-500">Star any station in Destinations to keep it handy here.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {favouriteStations.map((fav) => (
                <div
                  key={fav.id}
                  className="px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-[#0B1E36] flex items-center gap-2"
                >
                  <span className="font-mono text-[#008C77]">{fav.crs}</span>
                  <span>{fav.stationName}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Saved Itineraries */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
          <h2 className="text-base font-bold text-[#0B1E36] flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-[#EF4B42]" />
            <span>Saved itineraries ({savedItineraries.length})</span>
          </h2>

          {savedItineraries.length === 0 ? (
            <p className="text-sm text-slate-500">
              No saved itineraries yet. Click Save journey on any search result card.
            </p>
          ) : (
            <div className="space-y-3">
              {savedItineraries.map((item) => (
                <div key={item.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="text-sm font-bold text-[#0B1E36]">
                      {item.itinerary.originName} ({item.itinerary.originCrs}) →{' '}
                      {item.itinerary.destinationName} ({item.itinerary.destinationCrs})
                    </div>
                    <button
                      type="button"
                      onClick={() => onDeleteItem('itinerary', item.id)}
                      aria-label="Remove saved itinerary"
                      className="text-slate-400 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-xs text-slate-600 tabular-nums">
                    {item.itinerary.departureLocal.replace('T', ' ')} →{' '}
                    {item.itinerary.arrivalLocal.slice(11, 16)} ·{' '}
                    {item.snapshotOffer
                      ? `Snapshot: ${formatPence(item.snapshotOffer.total_known_payable_pence)} (${item.snapshotOffer.ticket_product})`
                      : 'Timetable snapshot'}
                  </div>
                  <div className="text-[11px] font-medium text-amber-900">
                    Saved planning reference only — not a purchased ticket, reservation, or barcode.
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Price Alerts */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-base font-bold text-[#0B1E36] flex items-center gap-2">
              <Bell className="w-4 h-4 text-[#008C77]" />
              <span>Price alerts ({priceAlerts.length})</span>
            </h2>
            <button
              type="button"
              disabled={checkingAlerts || priceAlerts.length === 0}
              onClick={async () => {
                setCheckingAlerts(true);
                await onRunAlertCheck();
                setCheckingAlerts(false);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#072434] bg-[#CFF7EE] hover:bg-[#14D1B5] disabled:opacity-50 rounded-lg"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${checkingAlerts ? 'animate-spin' : ''}`} />
              <span>Run equivalent check</span>
            </button>
          </div>

          <p className="text-xs text-slate-500">
            Alerts compare equivalent offers and run periodically every 15 minutes (not real-time continuous polling).
          </p>

          {priceAlerts.length === 0 ? (
            <p className="text-sm text-slate-500">No price alerts configured.</p>
          ) : (
            <div className="space-y-3">
              {priceAlerts.map((alt) => (
                <div key={alt.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="text-sm font-bold text-[#0B1E36]">{alt.label}</div>
                    <button
                      type="button"
                      onClick={() => onDeleteItem('alert', alt.id)}
                      aria-label="Delete price alert"
                      className="text-slate-400 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-xs text-slate-700 tabular-nums">
                    Target: ≤ {formatPence(alt.targetMaxTotalPence)} · Last observed:{' '}
                    {alt.lastObservedLowestPence !== null
                      ? formatPence(alt.lastObservedLowestPence)
                      : 'Unavailable'}{' '}
                    · Status: <span className="font-semibold uppercase">{alt.status}</span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {alt.checkCadenceDisclosure} Last checked{' '}
                    {new Date(alt.lastCheckedAtUtc).toLocaleTimeString('en-GB', {
                      hour: '2-digit',
                      minute: '2-digit',
                      timeZone: 'Europe/London',
                    })}
                    .
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
