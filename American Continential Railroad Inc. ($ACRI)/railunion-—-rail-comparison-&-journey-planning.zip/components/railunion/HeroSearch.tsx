'use client';

import React, { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import {
  ArrowLeftRight,
  Calendar,
  ChevronDown,
  FlaskConical,
  Search,
  ShieldCheck,
  Ticket,
  Users,
} from 'lucide-react';
import StationPicker from './StationPicker';
import { RAILCARD_DEFINITIONS } from '@/lib/railunion/timezone';
import type {
  DemoScenarioMode,
  FavouriteStationRecord,
  RailcardCode,
  SearchInput,
  Station,
} from '@/lib/railunion/types';

interface HeroSearchProps {
  input: SearchInput;
  stations: Station[];
  favourites: FavouriteStationRecord[];
  isSearching: boolean;
  validationError: string | null;
  onChangeInput: (updater: (prev: SearchInput) => SearchInput) => void;
  onSubmitSearch: (overrideInput?: SearchInput) => void;
}

const SCENARIO_OPTIONS: { value: DemoScenarioMode; label: string }[] = [
  { value: 'normal', label: 'Standard fixtures (2 providers)' },
  { value: 'provider_timeout', label: 'Simulate provider timeout (partial)' },
  { value: 'provider_no_fares', label: 'Simulate 1 provider returning no fares' },
  { value: 'expired_offer', label: 'Simulate expired offer recovery' },
  { value: 'missing_fee', label: 'Simulate missing mandatory fee' },
  { value: 'price_change', label: 'Simulate price change on revalidation' },
];

export default function HeroSearch({
  input,
  stations,
  favourites,
  isSearching,
  validationError,
  onChangeInput,
  onSubmitSearch,
}: HeroSearchProps) {
  const [passengersOpen, setPassengersOpen] = useState(false);
  const passRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (passRef.current && !passRef.current.contains(e.target as Node)) {
        setPassengersOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSwapStations = () => {
    onChangeInput((prev) => ({
      ...prev,
      originId: prev.destinationId,
      destinationId: prev.originId,
    }));
  };

  const toggleRailcard = (code: RailcardCode) => {
    onChangeInput((prev) => {
      const exists = prev.railcards.includes(code);
      const nextCards = exists
        ? prev.railcards.filter((c) => c !== code)
        : [...prev.railcards, code];
      return { ...prev, railcards: nextCards };
    });
  };

  const passengerLabel = `${input.adults} adult${input.adults === 1 ? '' : 's'}${
    input.children > 0 ? `, ${input.children} child${input.children === 1 ? '' : 'ren'}` : ''
  }${input.railcards.length > 0 ? ` · ${input.railcards.length} railcard` : ''}`;

  return (
    <section className="relative bg-[#0B1E36]">
      {/* Hero Photography + Measured Navy Contrast Scrim */}
      <div className="relative min-h-[340px] sm:min-h-[390px] flex items-start overflow-hidden">
        <Image
          src="/images/hero_gb_railway_1795607707369.jpg"
          alt="British intercity express train curving across a sunlit countryside viaduct towards London"
          fill
          priority
          referrerPolicy="no-referrer"
          className="object-cover object-center"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-r from-[#0B1E36]/95 via-[#0B1E36]/65 to-[#0B1E36]/20"
        />
        <div
          aria-hidden="true"
          className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-[#0B1E36] to-transparent"
        />

        <div className="relative z-10 max-w-[1280px] w-full mx-auto px-4 sm:px-6 pt-10 sm:pt-14 pb-24">
          <p className="text-xs font-medium text-[#CFF7EE] tracking-wide mb-3">
            Great Britain rail comparison · Independent concept · GBP (£)
          </p>
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-white max-w-2xl leading-[1.12] [text-wrap:balance]">
            <span className="relative inline-block">
              Your next
              <span
                aria-hidden="true"
                className="absolute left-0 right-0 -bottom-1 h-1 bg-[#EF4B42] rounded-full"
              />
            </span>{' '}
            great journey starts here.
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-200 max-w-xl font-normal">
            Compare trains. Understand your ticket. Travel your way.
          </p>
        </div>
      </div>

      {/* Floating Search Panel overlapping Hero Bottom Edge */}
      <div className="relative z-20 max-w-[1280px] mx-auto px-4 sm:px-6 -mt-16">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            onSubmitSearch();
          }}
          className="bg-white rounded-2xl shadow-xl border border-slate-200/90 p-4 sm:p-6 space-y-4"
        >
          {/* Top Search Controls Row */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3">
              {/* One way / Return segmented toggle */}
              <div
                role="group"
                aria-label="Journey type"
                className="inline-flex items-center p-1 bg-slate-100 rounded-xl"
              >
                <button
                  type="button"
                  onClick={() => onChangeInput((p) => ({ ...p, journeyType: 'one_way' }))}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    input.journeyType === 'one_way'
                      ? 'bg-[#CFF7EE] text-[#0B1E36] shadow-xs'
                      : 'text-slate-600 hover:text-[#0B1E36]'
                  }`}
                >
                  One way
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onChangeInput((p) => ({
                      ...p,
                      journeyType: 'return',
                      returnDate: p.returnDate || p.outwardDate,
                      returnTime: p.returnTime || '17:30',
                      returnTimeMode: p.returnTimeMode || 'depart_at',
                    }))
                  }
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    input.journeyType === 'return'
                      ? 'bg-[#CFF7EE] text-[#0B1E36] shadow-xs'
                      : 'text-slate-600 hover:text-[#0B1E36]'
                  }`}
                >
                  Return
                </button>
              </div>

              {input.journeyType === 'one_way' && (
                <button
                  type="button"
                  onClick={() =>
                    onChangeInput((p) => ({
                      ...p,
                      journeyType: 'return',
                      returnDate: p.returnDate || p.outwardDate,
                      returnTime: p.returnTime || '17:30',
                      returnTimeMode: p.returnTimeMode || 'depart_at',
                    }))
                  }
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#008C77] hover:text-[#0B1E36] transition-colors whitespace-nowrap shrink-0"
                >
                  <Calendar className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Add return</span>
                </button>
              )}

              {/* Standard / First Class segmented toggle */}
              <div
                role="group"
                aria-label="Travel class"
                className="inline-flex items-center p-1 bg-slate-100 rounded-xl"
              >
                <button
                  type="button"
                  onClick={() => onChangeInput((p) => ({ ...p, travelClass: 'standard' }))}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    input.travelClass === 'standard'
                      ? 'bg-white text-[#0B1E36] shadow-xs'
                      : 'text-slate-600 hover:text-[#0B1E36]'
                  }`}
                >
                  Standard
                </button>
                <button
                  type="button"
                  onClick={() => onChangeInput((p) => ({ ...p, travelClass: 'first' }))}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    input.travelClass === 'first'
                      ? 'bg-white text-[#0B1E36] shadow-xs'
                      : 'text-slate-600 hover:text-[#0B1E36]'
                  }`}
                >
                  First class
                </button>
              </div>
            </div>

            {/* Scenario Fixture Selector for Demonstration */}
            <div className="flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
              <label htmlFor="demo-scenario-select" className="text-xs font-medium text-slate-600 whitespace-nowrap">
                Fixture mode:
              </label>
              <select
                id="demo-scenario-select"
                value={input.scenarioMode ?? 'normal'}
                onChange={(e) =>
                  onChangeInput((p) => ({
                    ...p,
                    scenarioMode: e.target.value as DemoScenarioMode,
                  }))
                }
                className="text-xs font-medium text-[#0B1E36] bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#00B59A]"
              >
                {SCENARIO_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Primary Station, Date, Passenger, and CTA Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-stretch">
            {/* Origin + Swap + Destination */}
            <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-[1fr_auto_1fr] gap-2 items-center">
              <StationPicker
                inputId="origin-station-picker"
                label="From"
                selectedId={input.originId}
                stations={stations}
                favourites={favourites}
                onSelect={(st) => onChangeInput((p) => ({ ...p, originId: st.id }))}
              />

              <button
                type="button"
                onClick={handleSwapStations}
                aria-label="Swap origin and destination stations"
                className="mx-auto w-10 h-10 rounded-full border border-slate-300 bg-white hover:bg-slate-50 flex items-center justify-center text-slate-600 hover:text-[#0B1E36] transition-colors shrink-0 focus-visible:outline-2 focus-visible:outline-[#00B59A]"
              >
                <ArrowLeftRight className="w-4 h-4" />
              </button>

              <StationPicker
                inputId="destination-station-picker"
                label="To"
                selectedId={input.destinationId}
                stations={stations}
                favourites={favourites}
                onSelect={(st) => onChangeInput((p) => ({ ...p, destinationId: st.id }))}
              />
            </div>

            {/* Outward Date & Time */}
            <div className="lg:col-span-3 h-14 px-3 bg-white border border-slate-300 rounded-xl flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
                  <span>Outward</span>
                  <span aria-hidden="true">·</span>
                  <select
                    aria-label="Outward time mode"
                    value={input.outwardTimeMode}
                    onChange={(e) =>
                      onChangeInput((p) => ({
                        ...p,
                        outwardTimeMode: e.target.value as 'depart_at' | 'arrive_by',
                      }))
                    }
                    className="bg-transparent font-semibold text-[#0B1E36] focus:outline-none cursor-pointer"
                  >
                    <option value="depart_at">Depart at</option>
                    <option value="arrive_by">Arrive by</option>
                  </select>
                </div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <input
                    type="date"
                    aria-label="Outward date"
                    value={input.outwardDate}
                    onChange={(e) => onChangeInput((p) => ({ ...p, outwardDate: e.target.value }))}
                    className="text-xs font-semibold text-[#0B1E36] bg-transparent focus:outline-none w-[112px] tabular-nums"
                  />
                  <input
                    type="time"
                    aria-label="Outward time"
                    value={input.outwardTime}
                    onChange={(e) => onChangeInput((p) => ({ ...p, outwardTime: e.target.value }))}
                    className="text-xs font-semibold text-[#0B1E36] bg-transparent focus:outline-none w-[72px] tabular-nums"
                  />
                </div>
              </div>
            </div>

            {/* Passengers & Railcards Popover */}
            <div ref={passRef} className="lg:col-span-2 relative">
              <button
                type="button"
                onClick={() => setPassengersOpen((v) => !v)}
                aria-expanded={passengersOpen}
                className="w-full h-14 px-3.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl flex items-center justify-between gap-2 text-left transition-colors focus-visible:outline-2 focus-visible:outline-[#00B59A]"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <Users className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
                  <div className="min-w-0">
                    <div className="text-[11px] font-medium text-slate-500">Passengers</div>
                    <div className="text-xs font-semibold text-[#0B1E36] truncate">
                      {passengerLabel}
                    </div>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
              </button>

              {passengersOpen && (
                <div className="absolute right-0 top-16 z-50 w-80 bg-white border border-slate-200 rounded-xl shadow-xl p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold text-[#0B1E36]">Adults</div>
                      <div className="text-xs text-slate-500">Age 16+</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        aria-label="Decrease adults"
                        onClick={() =>
                          onChangeInput((p) => ({ ...p, adults: Math.max(1, p.adults - 1) }))
                        }
                        className="w-8 h-8 rounded-lg border border-slate-300 text-sm font-bold hover:bg-slate-50"
                      >
                        −
                      </button>
                      <span className="w-6 text-center text-sm font-semibold tabular-nums">
                        {input.adults}
                      </span>
                      <button
                        type="button"
                        aria-label="Increase adults"
                        onClick={() =>
                          onChangeInput((p) => ({
                            ...p,
                            adults: Math.min(9 - p.children, p.adults + 1),
                          }))
                        }
                        className="w-8 h-8 rounded-lg border border-slate-300 text-sm font-bold hover:bg-slate-50"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold text-[#0B1E36]">Children</div>
                      <div className="text-xs text-slate-500">Ages 5–15</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        aria-label="Decrease children"
                        onClick={() =>
                          onChangeInput((p) => ({ ...p, children: Math.max(0, p.children - 1) }))
                        }
                        className="w-8 h-8 rounded-lg border border-slate-300 text-sm font-bold hover:bg-slate-50"
                      >
                        −
                      </button>
                      <span className="w-6 text-center text-sm font-semibold tabular-nums">
                        {input.children}
                      </span>
                      <button
                        type="button"
                        aria-label="Increase children"
                        onClick={() =>
                          onChangeInput((p) => ({
                            ...p,
                            children: Math.min(9 - p.adults, p.children + 1),
                          }))
                        }
                        className="w-8 h-8 rounded-lg border border-slate-300 text-sm font-bold hover:bg-slate-50"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-200 space-y-2">
                    <div className="text-xs font-semibold text-[#0B1E36]">
                      Apply Railcards (demonstration)
                    </div>
                    <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1">
                      {(Object.keys(RAILCARD_DEFINITIONS) as RailcardCode[]).map((code) => {
                        const def = RAILCARD_DEFINITIONS[code];
                        const checked = input.railcards.includes(code);
                        return (
                          <label
                            key={code}
                            className="flex items-start gap-2 p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer"
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => toggleRailcard(code)}
                              className="mt-0.5 rounded border-slate-300 text-[#00B59A] focus:ring-[#00B59A]"
                            />
                            <div className="text-xs">
                              <div className="font-semibold text-[#0B1E36]">{def.name}</div>
                              <div className="text-slate-500 leading-snug">{def.note}</div>
                            </div>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Search Trains CTA */}
            <div className="lg:col-span-2">
              <button
                type="submit"
                disabled={isSearching}
                className="w-full h-14 px-5 bg-[#14D1B5] hover:bg-[#0FC0A5] disabled:opacity-60 text-[#072434] font-bold text-sm rounded-xl inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B1E36]"
              >
                <Search className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{isSearching ? 'Searching…' : 'Search trains'}</span>
              </button>
            </div>
          </div>

          {/* Return Date & Time Row when Return is selected */}
          {input.journeyType === 'return' && (
            <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-3">
              <div className="h-12 px-3.5 bg-slate-50 border border-slate-300 rounded-xl flex items-center gap-2.5">
                <Calendar className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
                <span className="text-xs font-medium text-slate-500">Return</span>
                <select
                  aria-label="Return time mode"
                  value={input.returnTimeMode ?? 'depart_at'}
                  onChange={(e) =>
                    onChangeInput((p) => ({
                      ...p,
                      returnTimeMode: e.target.value as 'depart_at' | 'arrive_by',
                    }))
                  }
                  className="text-xs font-semibold text-[#0B1E36] bg-transparent focus:outline-none"
                >
                  <option value="depart_at">Depart at</option>
                  <option value="arrive_by">Arrive by</option>
                </select>
                <input
                  type="date"
                  aria-label="Return date"
                  value={input.returnDate ?? input.outwardDate}
                  onChange={(e) => onChangeInput((p) => ({ ...p, returnDate: e.target.value }))}
                  className="text-xs font-semibold text-[#0B1E36] bg-transparent focus:outline-none tabular-nums"
                />
                <input
                  type="time"
                  aria-label="Return time"
                  value={input.returnTime ?? '17:30'}
                  onChange={(e) => onChangeInput((p) => ({ ...p, returnTime: e.target.value }))}
                  className="text-xs font-semibold text-[#0B1E36] bg-transparent focus:outline-none tabular-nums"
                />
              </div>
              <span className="text-xs text-slate-500">
                All timetable and fare checks use Europe/London local time.
              </span>
            </div>
          )}

          {validationError && (
            <div
              role="alert"
              className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-medium text-red-900"
            >
              {validationError}
            </div>
          )}
        </form>
      </div>

      {/* Navy Trust Strip directly beneath Search Panel matching Reference */}
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-0 sm:divide-x sm:divide-white/15 text-center">
          <div className="flex items-center justify-center gap-2.5 text-sm font-medium text-slate-100">
            <Ticket className="w-5 h-5 text-[#EF4B42] shrink-0" aria-hidden="true" />
            <span>Compare available fares</span>
          </div>
          <div className="flex items-center justify-center gap-2.5 text-sm font-medium text-slate-100">
            <ShieldCheck className="w-5 h-5 text-[#EF4B42] shrink-0" aria-hidden="true" />
            <span>Clear ticket conditions</span>
          </div>
          <div className="flex items-center justify-center gap-2.5 text-sm font-medium text-slate-100">
            <Search className="w-5 h-5 text-[#EF4B42] shrink-0" aria-hidden="true" />
            <span>Authorised seller handoffs</span>
          </div>
        </div>
      </div>
    </section>
  );
}
