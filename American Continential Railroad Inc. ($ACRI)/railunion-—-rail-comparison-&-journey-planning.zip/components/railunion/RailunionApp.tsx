'use client';

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Header, { type ActiveNavTab } from './Header';
import HeroSearch from './HeroSearch';
import JourneyResults from './JourneyResults';
import HomepageEditorial from './HomepageEditorial';
import DestinationsView from './DestinationsView';
import SavedJourneysView from './SavedJourneysView';
import HelpView from './HelpView';
import TicketConditionsModal from './TicketConditionsModal';
import RevalidateHandoffModal from './RevalidateHandoffModal';
import AccountModal from './AccountModal';
import { formatPence } from '@/lib/railunion/timezone';
import type {
  FareOffer,
  FavouriteStationRecord,
  JourneyItinerary,
  PriceAlertRecord,
  SavedItineraryRecord,
  SavedSearchRecord,
  SearchInput,
  SearchResponse,
  Station,
} from '@/lib/railunion/types';

interface RailunionAppProps {
  initialStations: Station[];
  defaultOutwardDate: string;
}

interface WorkspaceState {
  savedSearches: SavedSearchRecord[];
  favouriteStations: FavouriteStationRecord[];
  savedItineraries: SavedItineraryRecord[];
  priceAlerts: PriceAlertRecord[];
}

const EMPTY_WORKSPACE: WorkspaceState = {
  savedSearches: [],
  favouriteStations: [],
  savedItineraries: [],
  priceAlerts: [],
};

export default function RailunionApp({
  initialStations,
  defaultOutwardDate,
}: RailunionAppProps) {
  const [activeTab, setActiveTab] = useState<ActiveNavTab>('trains');
  const [stations] = useState<Station[]>(initialStations);

  const [searchInput, setSearchInput] = useState<SearchInput>({
    journeyType: 'one_way',
    originId: 'SHF',
    destinationId: 'STP',
    outwardDate: defaultOutwardDate,
    outwardTime: '08:30',
    outwardTimeMode: 'depart_at',
    returnDate: defaultOutwardDate,
    returnTime: '17:30',
    returnTimeMode: 'depart_at',
    adults: 1,
    children: 0,
    railcards: [],
    travelClass: 'standard',
    scenarioMode: 'normal',
  });

  const [isSearching, setIsSearching] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [searchResponse, setSearchResponse] = useState<SearchResponse | null>(null);

  // Modals & drawers
  const [conditionsOffer, setConditionsOffer] = useState<FareOffer | null>(null);
  const [handoffTarget, setHandoffTarget] = useState<{
    offer: FareOffer;
    itinerary: JourneyItinerary;
  } | null>(null);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [focusedHelpTopic, setFocusedHelpTopic] = useState<
    'flexible' | 'lowest' | 'first' | 'luggage' | null
  >(null);

  // Auth & workspace state (Bearer token stored solely in React memory)
  const [bearerToken, setBearerToken] = useState<string | null>(null);
  const [user, setUser] = useState<{
    id: string;
    email: string;
    displayName: string;
  } | null>(null);
  const [workspace, setWorkspace] = useState<WorkspaceState>(EMPTY_WORKSPACE);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const notify = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((curr) => (curr === msg ? null : curr));
    }, 4000);
  };

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/account');
        if (!res.ok) return;
        const data = await res.json();
        if (data.authenticated && data.user) {
          setUser(data.user);
          setWorkspace(data.workspace ?? EMPTY_WORKSPACE);
        }
      } catch {
        // Ignore initial session check errors
      }
    })();
  }, []);

  const authHeaders = (): Record<string, string> => {
    const h: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Requested-With': 'Railunion',
    };
    if (bearerToken) h.Authorization = `Bearer ${bearerToken}`;
    return h;
  };

  const runSearch = async (overrideInput?: SearchInput) => {
    const payload = overrideInput ?? searchInput;
    if (overrideInput) setSearchInput(overrideInput);
    setActiveTab('trains');
    setIsSearching(true);
    setValidationError(null);

    try {
      const res = await fetch('/api/journeys/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setValidationError(data.error || 'Unable to complete journey search.');
        return;
      }
      setSearchResponse(data as SearchResponse);
      setTimeout(() => {
        const el = document.getElementById('search-results-section');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 60);
    } catch {
      setValidationError('Network error while searching train journeys.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleQuickSearch = (partial: Partial<SearchInput>) => {
    const merged: SearchInput = { ...searchInput, ...partial };
    runSearch(merged);
  };

  const handleSaveSearch = async () => {
    if (!user) {
      setAccountModalOpen(true);
      notify('Sign in to save searches to your Railunion account.');
      return;
    }
    const orig = stations.find((s) => s.id === searchInput.originId)?.name ?? searchInput.originId;
    const dest =
      stations.find((s) => s.id === searchInput.destinationId)?.name ?? searchInput.destinationId;
    const res = await fetch('/api/saved', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({
        kind: 'search',
        label: `${orig} → ${dest} (${searchInput.adults} adult${searchInput.adults > 1 ? 's' : ''})`,
        input: searchInput,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      setWorkspace(data.workspace);
      notify('Search saved to your Saved journeys.');
    }
  };

  const handleSaveItinerary = async (itinerary: JourneyItinerary, offer: FareOffer | null) => {
    if (!user) {
      setAccountModalOpen(true);
      notify('Sign in to save itineraries.');
      return;
    }
    const res = await fetch('/api/saved', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({
        kind: 'itinerary',
        itinerary,
        snapshotOffer: offer,
        note: 'Saved from Railunion comparison results.',
      }),
    });
    if (res.ok) {
      const data = await res.json();
      setWorkspace(data.workspace);
      notify('Itinerary saved (comparison snapshot only, not a ticket).');
    }
  };

  const handleCreatePriceAlert = async (observedLowestPence: number | null) => {
    if (!user) {
      setAccountModalOpen(true);
      notify('Sign in to create price alerts.');
      return;
    }
    const targetPence =
      observedLowestPence !== null ? Math.max(500, observedLowestPence - 300) : 4500;
    const orig = stations.find((s) => s.id === searchInput.originId)?.crs ?? searchInput.originId;
    const dest =
      stations.find((s) => s.id === searchInput.destinationId)?.crs ?? searchInput.destinationId;
    const res = await fetch('/api/saved', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({
        kind: 'alert',
        label: `${orig} → ${dest} under ${formatPence(targetPence)}`,
        input: searchInput,
        targetMaxTotalPence: targetPence,
        observedLowestPence,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      setWorkspace(data.workspace);
      notify(`Price alert created (checked every 15 minutes).`);
    }
  };

  const handleToggleFavouriteStation = async (station: Station) => {
    if (!user) {
      setAccountModalOpen(true);
      notify('Sign in to save favourite stations.');
      return;
    }
    const res = await fetch('/api/saved', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({
        kind: 'station',
        stationId: station.id,
        stationName: station.name,
        crs: station.crs,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      setWorkspace(data.workspace);
      notify(
        data.action === 'added'
          ? `${station.name} added to favourites.`
          : `${station.name} removed from favourites.`
      );
    }
  };

  const handleDeleteSavedItem = async (kind: 'search' | 'itinerary' | 'alert', id: string) => {
    const res = await fetch(`/api/saved?kind=${encodeURIComponent(kind)}&id=${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: authHeaders(),
    });
    if (res.ok) {
      const data = await res.json();
      setWorkspace(data.workspace);
      notify('Item removed.');
    }
  };

  const handleRunAlertCheck = async () => {
    const res = await fetch('/api/alerts/check', {
      method: 'POST',
      headers: authHeaders(),
    });
    if (res.ok) {
      const data = await res.json();
      setWorkspace(data.workspace);
      notify('Equivalent-offer alert check completed.');
    }
  };

  const handleExportData = () => {
    window.location.href = '/api/account/export';
  };

  const handleLogout = async () => {
    await fetch('/api/account', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ action: 'logout' }),
    });
    setBearerToken(null);
    setUser(null);
    setWorkspace(EMPTY_WORKSPACE);
    notify('Signed out.');
  };

  const handleDeleteAccount = async () => {
    const res = await fetch('/api/account', {
      method: 'DELETE',
      headers: authHeaders(),
    });
    if (res.ok) {
      setBearerToken(null);
      setUser(null);
      setWorkspace(EMPTY_WORKSPACE);
      notify('Account and saved data deleted.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F7FA]">
      <Header
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'help') setFocusedHelpTopic(null);
        }}
        userDisplayName={user?.displayName ?? null}
        onOpenAccount={() => setAccountModalOpen(true)}
        onResetHome={() => {
          setActiveTab('trains');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Toast Notification */}
      {toastMsg && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 bg-[#0B1E36] text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl border border-white/15"
        >
          {toastMsg}
        </div>
      )}

      <main className="flex-1">
        <AnimatePresence mode="wait">
          {activeTab === 'trains' && (
            <motion.div
              key="tab-trains"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.16 }}
            >
              <HeroSearch
                input={searchInput}
                stations={stations}
                favourites={workspace.favouriteStations}
                isSearching={isSearching}
                validationError={validationError}
                onChangeInput={setSearchInput}
                onSubmitSearch={runSearch}
              />

              {searchResponse && (
                <JourneyResults
                  searchResponse={searchResponse}
                  stations={stations}
                  onInspectConditions={(offer) => setConditionsOffer(offer)}
                  onSelectOfferForHandoff={(offer, itinerary) =>
                    setHandoffTarget({ offer, itinerary })
                  }
                  onSaveItinerary={handleSaveItinerary}
                  onSaveCurrentSearch={handleSaveSearch}
                  onCreatePriceAlert={handleCreatePriceAlert}
                />
              )}

              <HomepageEditorial
                savedSearches={workspace.savedSearches}
                onQuickSearch={handleQuickSearch}
                onOpenGuide={(topic) => {
                  setFocusedHelpTopic(topic ?? null);
                  setActiveTab('help');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onOpenSavedTab={() => {
                  setActiveTab('saved');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            </motion.div>
          )}

          {activeTab === 'destinations' && (
            <motion.div
              key="tab-destinations"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.16 }}
            >
              <DestinationsView
                stations={stations}
                favourites={workspace.favouriteStations}
                onToggleFavourite={handleToggleFavouriteStation}
                onPlanFromStation={handleQuickSearch}
              />
            </motion.div>
          )}

          {activeTab === 'saved' && (
            <motion.div
              key="tab-saved"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.16 }}
            >
              <SavedJourneysView
                authenticated={Boolean(user)}
                userEmail={user?.email ?? null}
                savedSearches={workspace.savedSearches}
                favouriteStations={workspace.favouriteStations}
                savedItineraries={workspace.savedItineraries}
                priceAlerts={workspace.priceAlerts}
                onOpenAccount={() => setAccountModalOpen(true)}
                onRunSavedSearch={(input) => runSearch(input)}
                onDeleteItem={handleDeleteSavedItem}
                onRunAlertCheck={handleRunAlertCheck}
                onExportData={handleExportData}
                onDeleteAccount={handleDeleteAccount}
              />
            </motion.div>
          )}

          {activeTab === 'help' && (
            <motion.div
              key="tab-help"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.16 }}
            >
              <HelpView
                focusedTopic={focusedHelpTopic}
                onRunScenarioSearch={handleQuickSearch}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Navy Footer matching Reference */}
      <footer className="bg-[#0B1E36] text-slate-300 border-t border-white/10 py-6">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="text-center sm:text-left">
            <span className="font-bold text-white">railunion</span>
            <span aria-hidden="true" className="mx-2 text-slate-500">
              ·
            </span>
            <span>Independent rail comparison & journey planning concept</span>
            <span aria-hidden="true" className="mx-2 text-slate-500">
              ·
            </span>
            <span>Fictional schedules & illustrative GBP (£) prices</span>
          </div>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => setActiveTab('trains')}
              className="hover:text-white transition-colors"
            >
              Trains
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('destinations')}
              className="hover:text-white transition-colors"
            >
              Destinations
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('saved')}
              className="hover:text-white transition-colors"
            >
              Saved journeys
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('help')}
              className="hover:text-white transition-colors"
            >
              Help & demo scenarios
            </button>
          </div>
        </div>
      </footer>

      {/* Ticket Conditions Drawer/Modal */}
      <TicketConditionsModal
        offer={conditionsOffer}
        onClose={() => setConditionsOffer(null)}
        onProceedToSeller={(offer) => {
          if (!searchResponse) return;
          const allItems = [
            ...searchResponse.directionResults.outward,
            ...searchResponse.directionResults.return,
          ];
          const match = allItems.find((i) => i.itinerary.journeyId === offer.journey_reference);
          if (match) {
            setHandoffTarget({ offer, itinerary: match.itinerary });
          }
        }}
      />

      {/* Revalidation & Seller Handoff Modal */}
      {handoffTarget && (
        <RevalidateHandoffModal
          key={handoffTarget.offer.offer_id}
          offer={handoffTarget.offer}
          itinerary={handoffTarget.itinerary}
          scenarioMode={searchInput.scenarioMode ?? 'normal'}
          onClose={() => setHandoffTarget(null)}
          onRunFreshSearch={() =>
            runSearch({ ...searchInput, scenarioMode: 'normal' })
          }
        />
      )}

      {/* Account Modal */}
      <AccountModal
        open={accountModalOpen}
        authenticated={Boolean(user)}
        user={user}
        onClose={() => setAccountModalOpen(false)}
        onAuthSuccess={(payload) => {
          if (payload.token) setBearerToken(payload.token);
          setUser(payload.user);
          setWorkspace((payload.workspace as WorkspaceState) ?? EMPTY_WORKSPACE);
          notify(`Signed in as ${payload.user.displayName}.`);
        }}
        onLogout={handleLogout}
        onExportData={handleExportData}
        onDeleteAccount={handleDeleteAccount}
      />
    </div>
  );
}
