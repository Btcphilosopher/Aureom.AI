export type TriStateValue = 'yes' | 'no' | 'partial' | 'unknown' | 'not_applicable';

export type StationKind = 'individual' | 'station_group' | 'city_group';

export interface StationAccessibility {
  stepFreeAccess: 'full' | 'partial' | 'none' | 'unknown';
  assistanceAvailable: 'yes' | 'no' | 'unknown';
  tactilePaving: 'yes' | 'no' | 'unknown';
  accessibleToilets: 'yes' | 'no' | 'unknown';
  summary: string;
  source: string;
  updatedAt: string;
  officialAssistanceUrl: string;
}

export interface Station {
  id: string;
  crs: string;
  nlc: string;
  tiploc: string;
  name: string;
  city: string;
  region: string;
  kind: StationKind;
  cityGroupId: string | null;
  memberStationIds: string[];
  nearbyStationIds: string[];
  latitude: number;
  longitude: number;
  aliases: string[];
  accessibility: StationAccessibility;
}

export interface StationLookupResult {
  query: string;
  matchedStations: Station[];
  nearbySuggestions: Station[];
  unresolvedPlaceNotice: string | null;
}

export type RailcardCode =
  | '16-25'
  | '26-30'
  | 'TWO_TOGETHER'
  | 'SENIOR'
  | 'FAMILY_FRIENDS'
  | 'NETWORK'
  | 'DISABLED_PERSONS'
  | 'HM_FORCES';

export interface RailcardDefinition {
  code: RailcardCode;
  name: string;
  discountPercent: number;
  summaryRule: string;
  minAdults: number;
  maxAdults?: number;
  minChildren?: number;
  note: string;
}

export type TimeMode = 'depart_at' | 'arrive_by';
export type TravelClass = 'standard' | 'first';
export type JourneyType = 'one_way' | 'return';

export type DemoScenarioMode =
  | 'normal'
  | 'provider_timeout'
  | 'provider_no_fares'
  | 'expired_offer'
  | 'missing_fee'
  | 'price_change';

export interface SearchInput {
  journeyType: JourneyType;
  originId: string;
  destinationId: string;
  originEnteredText?: string;
  destinationEnteredText?: string;
  outwardDate: string; // YYYY-MM-DD in Europe/London
  outwardTime: string; // HH:MM in Europe/London
  outwardTimeMode: TimeMode;
  returnDate?: string;
  returnTime?: string;
  returnTimeMode?: TimeMode;
  adults: number;
  children: number;
  railcards: RailcardCode[];
  travelClass: TravelClass;
  scenarioMode?: DemoScenarioMode;
}

export interface DisruptionNotice {
  id: string;
  severity: 'info' | 'minor' | 'major';
  category: 'timetable_change' | 'live_running' | 'engineering_work';
  headline: string;
  detail: string;
  source: string;
  reportedAtUtc: string;
}

export interface JourneyLeg {
  legId: string;
  originStationId: string;
  originName: string;
  originCrs: string;
  destinationStationId: string;
  destinationName: string;
  destinationCrs: string;
  scheduledDepartureLocal: string;
  scheduledArrivalLocal: string;
  scheduledDepartureUtc: string;
  scheduledArrivalUtc: string;
  estimatedDepartureLocal: string | null;
  estimatedArrivalLocal: string | null;
  actualDepartureLocal: string | null;
  actualArrivalLocal: string | null;
  durationMinutes: number;
  operatorCode: string;
  operatorName: string;
  serviceId: string;
  headcode: string;
  platform: string | null;
  walkingTransferMinutes: number | null;
  transferNote: string | null;
  callingPointsCount: number;
  disruptions: DisruptionNotice[];
}

export interface JourneyItinerary {
  journeyId: string;
  direction: 'outward' | 'return';
  providerId: string;
  searchTimeUtc: string;
  originStationId: string;
  originName: string;
  originCrs: string;
  destinationStationId: string;
  destinationName: string;
  destinationCrs: string;
  departureLocal: string;
  arrivalLocal: string;
  departureUtc: string;
  arrivalUtc: string;
  overnightDays: number;
  dstTransitionNotice: string | null;
  durationMinutes: number;
  changesCount: number;
  interchangeStationIds: string[];
  interchangeNames: string[];
  transferDurationsMinutes: number[];
  operators: { code: string; name: string }[];
  legs: JourneyLeg[];
  disruptions: DisruptionNotice[];
  timetableSource: string;
  timetableFreshnessUtc: string;
  stationGroupNotice: string | null;
}

export type FeeCompleteness = 'complete' | 'missing_mandatory_fee' | 'unknown';
export type TrainBinding = 'booked_train_only' | 'flexible_any_permitted' | 'operator_specific' | 'unknown';
export type ReservationStatus = 'included_compulsory' | 'optional_recommended' | 'not_available' | 'not_applicable' | 'unknown';

export interface PassengerComposition {
  adults: number;
  children: number;
  summary: string;
}

export interface FareOffer {
  offer_id: string;
  provider_id: string;
  provider_name: string;
  journey_reference: string;
  passenger_composition: PassengerComposition;
  railcards_applied: RailcardCode[];
  travel_class: TravelClass;
  ticket_product: string;
  ticket_category: 'advance' | 'off_peak' | 'anytime' | 'return_product';
  route_restrictions: string;
  operator_restrictions: string;
  time_restrictions: string;
  train_binding: TrainBinding;
  reservation_status: ReservationStatus;
  refund_conditions: string;
  change_conditions: string;
  ticket_price: number; // integer pence
  mandatory_fees: number | null; // null when unknown/missing
  fulfilment_fees: number | null; // null when unknown
  fulfilment_method: 'e_ticket' | 'kiosk_collection' | 'postal' | 'unknown';
  total_known_payable_pence: number | null; // null if mandatory_fees is null
  fee_completeness: FeeCompleteness;
  currency: 'GBP';
  quoted_at: string;
  expires_at: string;
  seller_handoff_reference: string;
  seller_name: string;
  seller_host: string;
  is_sponsored: boolean;
  sponsored_label: string | null;
  equivalence_key: string;
  condition_summary_short: string;
  availability_status: 'available' | 'limited' | 'expired' | 'unavailable';
  price_change_on_revalidate_pence?: number;
}

export interface ComparableOfferGroup {
  equivalenceKey: string;
  ticketProduct: string;
  ticketCategory: FareOffer['ticket_category'];
  travelClass: TravelClass;
  trainBinding: TrainBinding;
  flexibilityLabel: string;
  offers: FareOffer[];
  lowestComparableOfferId: string | null;
  lowestComparableTotalPence: number | null;
  hasIncompleteFeesOnly: boolean;
  plainDifferenceNote: string | null;
}

export interface JourneySearchResultItem {
  itinerary: JourneyItinerary;
  offerGroups: ComparableOfferGroup[];
  allOffers: FareOffer[];
  lowestCompletePricePence: number | null;
  recommendedScorePence: number | null;
  recommendedExplanation: string;
}

export interface ProviderStatusReport {
  providerId: string;
  providerName: string;
  isFictionalFixture: boolean;
  status: 'healthy' | 'timeout' | 'no_fares' | 'degraded';
  responseTimeMs: number;
  offersReturned: number;
  message: string;
  limitations: string[];
  checkedAtUtc: string;
}

export interface SearchResponse {
  searchReference: string;
  input: SearchInput;
  directionResults: {
    outward: JourneySearchResultItem[];
    return: JourneySearchResultItem[];
  };
  returnCombinationsNote: {
    supportsSingleAndReturnProducts: boolean;
    splitTicketingStatus: 'deferred';
    splitTicketingReason: string;
  };
  providerReports: ProviderStatusReport[];
  coverageSummary: {
    isPartial: boolean;
    respondingProviders: number;
    totalConfiguredProviders: number;
    disclosure: string;
  };
  cacheMetadata: {
    cacheKeyHash: string;
    cacheHit: boolean;
    cachedAtUtc: string;
    expiresAtUtc: string;
    ttlSeconds: number;
  };
  rankingRuleDisclosure: string;
  demonstrationNotice: string;
}

export interface RevalidationResult {
  offerId: string;
  providerId: string;
  status: 'unchanged' | 'price_changed' | 'expired' | 'unavailable';
  originalTotalPence: number | null;
  revalidatedTotalPence: number | null;
  priceDeltaPence: number | null;
  conditionChanges: string[];
  requiresCustomerAcceptance: boolean;
  revalidatedAtUtc: string;
  expiresAtUtc: string;
  message: string;
  updatedOffer: FareOffer | null;
}

export interface SellerHandoffRecord {
  handoffReference: string;
  offerId: string;
  providerId: string;
  sellerName: string;
  sellerHost: string;
  validatedSellerUrl: string;
  journeySummary: string;
  passengerSummary: string;
  travelClass: TravelClass;
  ticketProduct: string;
  acceptedTotalPence: number | null;
  currency: 'GBP';
  acceptedMaterialChange: boolean;
  createdAtUtc: string;
  disclaimer: string;
}

export interface SavedSearchRecord {
  id: string;
  userId: string;
  label: string;
  input: SearchInput;
  createdAtUtc: string;
}

export interface FavouriteStationRecord {
  id: string;
  userId: string;
  stationId: string;
  stationName: string;
  crs: string;
  createdAtUtc: string;
}

export interface SavedItineraryRecord {
  id: string;
  userId: string;
  itinerary: JourneyItinerary;
  snapshotOffer: FareOffer | null;
  note: string;
  sourceLabel: string;
  verificationStatus: 'saved_concept_only_not_a_ticket';
  createdAtUtc: string;
}

export interface PriceAlertRecord {
  id: string;
  userId: string;
  label: string;
  input: SearchInput;
  targetMaxTotalPence: number;
  lastCheckedAtUtc: string;
  lastObservedLowestPence: number | null;
  checkCadenceDisclosure: string;
  status: 'active' | 'triggered' | 'paused';
  createdAtUtc: string;
}

export interface UserAccount {
  id: string;
  email: string;
  displayName: string;
  passwordHash: string;
  createdAtUtc: string;
}
