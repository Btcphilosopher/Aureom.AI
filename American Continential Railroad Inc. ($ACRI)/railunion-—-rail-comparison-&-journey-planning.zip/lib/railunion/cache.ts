import crypto from 'crypto';
import type { SearchInput, SearchResponse } from './types';

interface CacheEntry {
  keyHash: string;
  response: SearchResponse;
  cachedAtMs: number;
  expiresAtMs: number;
}

const DEFAULT_TTL_MS = 120_000; // 2 minutes bounded short-lived cache
const MAX_CACHE_ENTRIES = 200;

const searchCache = new Map<string, CacheEntry>();

/**
 * Computes a deterministic cache key incorporating ALL price-relevant search inputs,
 * strictly isolating passenger counts, railcard combinations, class, dates, and scenario modes.
 */
export function buildPriceRelevantCacheKey(input: SearchInput): string {
  const canonical = {
    journeyType: input.journeyType,
    originId: input.originId,
    destinationId: input.destinationId,
    outwardDate: input.outwardDate,
    outwardTime: input.outwardTime,
    outwardTimeMode: input.outwardTimeMode,
    returnDate: input.journeyType === 'return' ? input.returnDate ?? '' : '',
    returnTime: input.journeyType === 'return' ? input.returnTime ?? '' : '',
    returnTimeMode: input.journeyType === 'return' ? input.returnTimeMode ?? 'depart_at' : '',
    adults: input.adults,
    children: input.children,
    railcards: [...input.railcards].sort(),
    travelClass: input.travelClass,
    scenarioMode: input.scenarioMode ?? 'normal',
  };
  return crypto.createHash('sha256').update(JSON.stringify(canonical)).digest('hex').slice(0, 24);
}

export function getCachedSearchResponse(
  input: SearchInput,
  nowMs: number = Date.now()
): SearchResponse | null {
  const keyHash = buildPriceRelevantCacheKey(input);
  const entry = searchCache.get(keyHash);
  if (!entry) return null;
  if (entry.expiresAtMs <= nowMs) {
    searchCache.delete(keyHash);
    return null;
  }
  return {
    ...entry.response,
    cacheMetadata: {
      ...entry.response.cacheMetadata,
      cacheHit: true,
    },
  };
}

export function setCachedSearchResponse(
  input: SearchInput,
  response: SearchResponse,
  ttlMs: number = DEFAULT_TTL_MS,
  nowMs: number = Date.now()
): SearchResponse {
  const keyHash = buildPriceRelevantCacheKey(input);
  const expiresAtMs = nowMs + ttlMs;

  if (searchCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = searchCache.keys().next().value;
    if (oldestKey) searchCache.delete(oldestKey);
  }

  const stamped: SearchResponse = {
    ...response,
    cacheMetadata: {
      cacheKeyHash: keyHash,
      cacheHit: false,
      cachedAtUtc: new Date(nowMs).toISOString(),
      expiresAtUtc: new Date(expiresAtMs).toISOString(),
      ttlSeconds: Math.round(ttlMs / 1000),
    },
  };

  searchCache.set(keyHash, {
    keyHash,
    response: stamped,
    cachedAtMs: nowMs,
    expiresAtMs,
  });

  return stamped;
}

export function clearSearchCache(): void {
  searchCache.clear();
}
