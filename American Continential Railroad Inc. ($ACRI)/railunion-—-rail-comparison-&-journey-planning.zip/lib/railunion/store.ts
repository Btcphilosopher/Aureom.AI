import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { hashPassword, verifyPassword } from './security';
import { getDefaultLondonSearchDate } from './timezone';
import type {
  FareOffer,
  FavouriteStationRecord,
  JourneyItinerary,
  PriceAlertRecord,
  SavedItineraryRecord,
  SavedSearchRecord,
  SearchInput,
  SellerHandoffRecord,
  UserAccount,
} from './types';

interface StoreData {
  users: UserAccount[];
  savedSearches: SavedSearchRecord[];
  favouriteStations: FavouriteStationRecord[];
  savedItineraries: SavedItineraryRecord[];
  priceAlerts: PriceAlertRecord[];
  handoffs: SellerHandoffRecord[];
}

const DATA_DIR = path.resolve(process.cwd(), '.railunion-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

export const DEMO_USER_ID = 'usr-demo-traveller';
export const DEMO_USER_EMAIL = 'demo@railunion.example';

function createInitialStore(): StoreData {
  const now = new Date().toISOString();
  const demoDate = getDefaultLondonSearchDate(2);
  return {
    users: [
      {
        id: DEMO_USER_ID,
        email: DEMO_USER_EMAIL,
        displayName: 'Alex Turner (Demo)',
        passwordHash: hashPassword('RailunionDemo2026!'),
        createdAtUtc: now,
      },
    ],
    savedSearches: [
      {
        id: 'ss-demo-shf-stp',
        userId: DEMO_USER_ID,
        label: 'Sheffield → London St Pancras (1 Adult)',
        input: {
          journeyType: 'one_way',
          originId: 'SHF',
          destinationId: 'STP',
          outwardDate: demoDate,
          outwardTime: '08:30',
          outwardTimeMode: 'depart_at',
          adults: 1,
          children: 0,
          railcards: [],
          travelClass: 'standard',
          scenarioMode: 'normal',
        },
        createdAtUtc: now,
      },
    ],
    favouriteStations: [
      {
        id: 'fav-demo-shf',
        userId: DEMO_USER_ID,
        stationId: 'SHF',
        stationName: 'Sheffield',
        crs: 'SHF',
        createdAtUtc: now,
      },
      {
        id: 'fav-demo-stp',
        userId: DEMO_USER_ID,
        stationId: 'STP',
        stationName: 'London St Pancras International',
        crs: 'STP',
        createdAtUtc: now,
      },
    ],
    savedItineraries: [],
    priceAlerts: [
      {
        id: 'alt-demo-shf-stp',
        userId: DEMO_USER_ID,
        label: 'Sheffield → London St Pancras under £35.00',
        input: {
          journeyType: 'one_way',
          originId: 'SHF',
          destinationId: 'STP',
          outwardDate: demoDate,
          outwardTime: '09:00',
          outwardTimeMode: 'depart_at',
          adults: 1,
          children: 0,
          railcards: ['16-25'],
          travelClass: 'standard',
          scenarioMode: 'normal',
        },
        targetMaxTotalPence: 3500,
        lastCheckedAtUtc: now,
        lastObservedLowestPence: 2950,
        checkCadenceDisclosure: 'Checked periodically every 15 minutes by the background worker (not real-time).',
        status: 'triggered',
        createdAtUtc: now,
      },
    ],
    handoffs: [],
  };
}

let memoryStore: StoreData | null = null;

function readStore(): StoreData {
  if (memoryStore) return memoryStore;
  try {
    if (fs.existsSync(STORE_PATH)) {
      const raw = fs.readFileSync(STORE_PATH, 'utf8');
      memoryStore = JSON.parse(raw) as StoreData;
      return memoryStore;
    }
  } catch {
    // Fallback to initial store if file unreadable
  }
  memoryStore = createInitialStore();
  persistStore(memoryStore);
  return memoryStore;
}

function persistStore(data: StoreData): void {
  memoryStore = data;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tmpPath = `${STORE_PATH}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmpPath, STORE_PATH);
  } catch {
    // Read-only filesystem safe fallback: keep in memoryStore
  }
}

export function findUserByEmail(email: string): UserAccount | null {
  const store = readStore();
  return store.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase()) ?? null;
}

export function findUserById(userId: string): UserAccount | null {
  const store = readStore();
  return store.users.find((u) => u.id === userId) ?? null;
}

export function registerUser(email: string, password: string, displayName: string): UserAccount {
  const store = readStore();
  const normalized = email.trim().toLowerCase();
  if (store.users.some((u) => u.email.toLowerCase() === normalized)) {
    throw new Error('An account with that email address already exists.');
  }
  const user: UserAccount = {
    id: `usr-${crypto.randomBytes(6).toString('hex')}`,
    email: normalized,
    displayName: displayName.trim() || normalized.split('@')[0],
    passwordHash: hashPassword(password),
    createdAtUtc: new Date().toISOString(),
  };
  store.users.push(user);
  persistStore(store);
  return user;
}

export function authenticateUser(email: string, password: string): UserAccount | null {
  const user = findUserByEmail(email);
  if (!user) return null;
  if (!verifyPassword(password, user.passwordHash)) return null;
  return user;
}

export function getDemoUser(): UserAccount {
  const existing = findUserById(DEMO_USER_ID);
  if (existing) return existing;
  const fresh = createInitialStore();
  const store = readStore();
  store.users.push(fresh.users[0]);
  persistStore(store);
  return fresh.users[0];
}

export function getUserWorkspaceData(userId: string) {
  const store = readStore();
  return {
    savedSearches: store.savedSearches.filter((s) => s.userId === userId),
    favouriteStations: store.favouriteStations.filter((f) => f.userId === userId),
    savedItineraries: store.savedItineraries.filter((i) => i.userId === userId),
    priceAlerts: store.priceAlerts.filter((a) => a.userId === userId),
  };
}

export function addSavedSearch(userId: string, label: string, input: SearchInput): SavedSearchRecord {
  const store = readStore();
  const record: SavedSearchRecord = {
    id: `ss-${crypto.randomBytes(5).toString('hex')}`,
    userId,
    label: label.trim().slice(0, 120),
    input,
    createdAtUtc: new Date().toISOString(),
  };
  store.savedSearches.unshift(record);
  persistStore(store);
  return record;
}

export function removeSavedSearch(userId: string, recordId: string): boolean {
  const store = readStore();
  const idx = store.savedSearches.findIndex((s) => s.id === recordId && s.userId === userId);
  if (idx === -1) return false;
  store.savedSearches.splice(idx, 1);
  persistStore(store);
  return true;
}

export function toggleFavouriteStation(
  userId: string,
  stationId: string,
  stationName: string,
  crs: string
): { action: 'added' | 'removed'; record?: FavouriteStationRecord } {
  const store = readStore();
  const idx = store.favouriteStations.findIndex(
    (f) => f.userId === userId && f.stationId === stationId
  );
  if (idx !== -1) {
    store.favouriteStations.splice(idx, 1);
    persistStore(store);
    return { action: 'removed' };
  }
  const record: FavouriteStationRecord = {
    id: `fav-${crypto.randomBytes(5).toString('hex')}`,
    userId,
    stationId,
    stationName,
    crs,
    createdAtUtc: new Date().toISOString(),
  };
  store.favouriteStations.unshift(record);
  persistStore(store);
  return { action: 'added', record };
}

export function saveItineraryForUser(
  userId: string,
  itinerary: JourneyItinerary,
  snapshotOffer: FareOffer | null,
  note: string
): SavedItineraryRecord {
  const store = readStore();
  const record: SavedItineraryRecord = {
    id: `itn-${crypto.randomBytes(5).toString('hex')}`,
    userId,
    itinerary,
    snapshotOffer,
    note: note.trim().slice(0, 240),
    sourceLabel: `${itinerary.timetableSource}${snapshotOffer ? ` · Snapshot offer via ${snapshotOffer.provider_name}` : ''}`,
    verificationStatus: 'saved_concept_only_not_a_ticket',
    createdAtUtc: new Date().toISOString(),
  };
  store.savedItineraries.unshift(record);
  persistStore(store);
  return record;
}

export function removeSavedItinerary(userId: string, recordId: string): boolean {
  const store = readStore();
  const idx = store.savedItineraries.findIndex((i) => i.id === recordId && i.userId === userId);
  if (idx === -1) return false;
  store.savedItineraries.splice(idx, 1);
  persistStore(store);
  return true;
}

export function createPriceAlert(
  userId: string,
  label: string,
  input: SearchInput,
  targetMaxTotalPence: number,
  observedLowestPence: number | null
): PriceAlertRecord {
  const store = readStore();
  const now = new Date().toISOString();
  const triggered =
    observedLowestPence !== null && observedLowestPence <= targetMaxTotalPence;
  const record: PriceAlertRecord = {
    id: `alt-${crypto.randomBytes(5).toString('hex')}`,
    userId,
    label: label.trim().slice(0, 120),
    input,
    targetMaxTotalPence,
    lastCheckedAtUtc: now,
    lastObservedLowestPence: observedLowestPence,
    checkCadenceDisclosure:
      'Checked periodically every 15 minutes by the background worker (equivalent offers compared; not real-time).',
    status: triggered ? 'triggered' : 'active',
    createdAtUtc: now,
  };
  store.priceAlerts.unshift(record);
  persistStore(store);
  return record;
}

export function removePriceAlert(userId: string, recordId: string): boolean {
  const store = readStore();
  const idx = store.priceAlerts.findIndex((a) => a.id === recordId && a.userId === userId);
  if (idx === -1) return false;
  store.priceAlerts.splice(idx, 1);
  persistStore(store);
  return true;
}

export function updatePriceAlertObservation(
  userId: string,
  alertId: string,
  observedLowestPence: number | null
): PriceAlertRecord | null {
  const store = readStore();
  const alert = store.priceAlerts.find((a) => a.id === alertId && a.userId === userId);
  if (!alert) return null;
  alert.lastCheckedAtUtc = new Date().toISOString();
  alert.lastObservedLowestPence = observedLowestPence;
  alert.status =
    observedLowestPence !== null && observedLowestPence <= alert.targetMaxTotalPence
      ? 'triggered'
      : 'active';
  persistStore(store);
  return alert;
}

export function exportUserData(userId: string) {
  const user = findUserById(userId);
  if (!user) return null;
  const workspace = getUserWorkspaceData(userId);
  return {
    exportedAtUtc: new Date().toISOString(),
    account: {
      id: user.id,
      email: user.email,
      displayName: user.displayName,
      createdAtUtc: user.createdAtUtc,
    },
    ...workspace,
  };
}

export function deleteUserAccount(userId: string): boolean {
  const store = readStore();
  const idx = store.users.findIndex((u) => u.id === userId);
  if (idx === -1) return false;
  store.users.splice(idx, 1);
  store.savedSearches = store.savedSearches.filter((s) => s.userId !== userId);
  store.favouriteStations = store.favouriteStations.filter((f) => f.userId !== userId);
  store.savedItineraries = store.savedItineraries.filter((i) => i.userId !== userId);
  store.priceAlerts = store.priceAlerts.filter((a) => a.userId !== userId);
  persistStore(store);
  return true;
}

export function recordHandoff(record: SellerHandoffRecord): void {
  const store = readStore();
  store.handoffs.unshift(record);
  if (store.handoffs.length > 500) {
    store.handoffs = store.handoffs.slice(0, 500);
  }
  persistStore(store);
}

export function getHandoffByReference(handoffReference: string): SellerHandoffRecord | null {
  const store = readStore();
  return store.handoffs.find((h) => h.handoffReference === handoffReference) ?? null;
}
