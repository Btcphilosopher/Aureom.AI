import type { RailcardCode, RailcardDefinition, SearchInput } from './types';

export const LONDON_TIMEZONE = 'Europe/London';
export const MAX_BOOKING_HORIZON_DAYS = 84; // 12 weeks standard GB timetable horizon

export const RAILCARD_DEFINITIONS: Record<RailcardCode, RailcardDefinition> = {
  '16-25': {
    code: '16-25',
    name: '16–25 Railcard',
    discountPercent: 34,
    summaryRule: '1/3 off eligible Standard & Advance fares for 16–25 year olds (min fare rules apply before 10:00 Mon–Fri).',
    minAdults: 1,
    note: '1/3 off eligible fares; £12 minimum fare 04:30–09:59 Mon–Fri except July–August & public holidays.',
  },
  '26-30': {
    code: '26-30',
    name: '26–30 Railcard',
    discountPercent: 34,
    summaryRule: '1/3 off eligible Standard & Advance fares for ages 26–30.',
    minAdults: 1,
    note: '1/3 off eligible fares; £12 minimum fare 04:30–09:59 Mon–Fri.',
  },
  TWO_TOGETHER: {
    code: 'TWO_TOGETHER',
    name: 'Two Together Railcard',
    discountPercent: 34,
    summaryRule: '1/3 off for two named adults travelling together after 09:30 Mon–Fri.',
    minAdults: 2,
    maxAdults: 2,
    note: 'Requires exactly 2 adults travelling together; not valid 04:30–09:29 Mon–Fri.',
  },
  SENIOR: {
    code: 'SENIOR',
    name: 'Senior Railcard',
    discountPercent: 34,
    summaryRule: '1/3 off Standard & First Class leisure fares for ages 60+.',
    minAdults: 1,
    note: 'Valid across Great Britain; regional peak restrictions apply in London/South East.',
  },
  FAMILY_FRIENDS: {
    code: 'FAMILY_FRIENDS',
    name: 'Family & Friends Railcard',
    discountPercent: 34,
    summaryRule: '1/3 off adult fares and 60% off child fares when at least 1 adult travels with 1+ child.',
    minAdults: 1,
    minChildren: 1,
    note: 'Requires at least 1 adult and 1 child (ages 5–15) on the same journey.',
  },
  NETWORK: {
    code: 'NETWORK',
    name: 'Network Railcard',
    discountPercent: 34,
    summaryRule: '1/3 off Standard fares in the London & South East Network area after 10:00 Mon–Fri.',
    minAdults: 1,
    note: 'Valid only within the Network Railcard area (not valid for Sheffield–London long-distance journeys).',
  },
  DISABLED_PERSONS: {
    code: 'DISABLED_PERSONS',
    name: 'Disabled Persons Railcard',
    discountPercent: 34,
    summaryRule: '1/3 off for cardholder plus one adult companion.',
    minAdults: 1,
    note: 'No morning peak time restrictions on National Rail services.',
  },
  HM_FORCES: {
    code: 'HM_FORCES',
    name: 'HM Forces Railcard',
    discountPercent: 34,
    summaryRule: '1/3 off eligible Standard & First Class fares for Armed Forces personnel.',
    minAdults: 1,
    note: '£12 minimum fare may apply Mon–Fri before 10:00 on selected products.',
  },
};

export function getLondonOffsetMinutes(utcDate: Date): number {
  const formatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: LONDON_TIMEZONE,
    timeZoneName: 'shortOffset',
  });
  const parts = formatter.formatToParts(utcDate);
  const tzName = parts.find((p) => p.type === 'timeZoneName')?.value ?? 'GMT';
  if (tzName === 'GMT' || tzName === 'UTC') return 0;
  const match = tzName.match(/GMT([+-])(\d{1,2})(?::(\d{2}))?/);
  if (!match) return 0;
  const sign = match[1] === '-' ? -1 : 1;
  const hours = parseInt(match[2], 10);
  const mins = match[3] ? parseInt(match[3], 10) : 0;
  return sign * (hours * 60 + mins);
}

/**
 * Converts a local Europe/London date (YYYY-MM-DD) and time (HH:MM) into an exact UTC Date,
 * respecting BST/GMT daylight-saving transitions.
 */
export function londonLocalToUtc(dateStr: string, timeStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  const [hour, minute] = timeStr.split(':').map(Number);
  // First guess assuming UTC
  const guessUtc = new Date(Date.UTC(year, month - 1, day, hour, minute, 0, 0));
  const offset1 = getLondonOffsetMinutes(guessUtc);
  const adjusted1 = new Date(guessUtc.getTime() - offset1 * 60_000);
  // Re-evaluate offset at adjusted timestamp for DST transition boundaries
  const offset2 = getLondonOffsetMinutes(adjusted1);
  if (offset2 !== offset1) {
    return new Date(guessUtc.getTime() - offset2 * 60_000);
  }
  return adjusted1;
}

export function formatUtcToLondonParts(utcDate: Date): {
  date: string;
  time: string;
  tzLabel: string;
  isoUtc: string;
} {
  const dtf = new Intl.DateTimeFormat('en-CA', {
    timeZone: LONDON_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  const parts = dtf.formatToParts(utcDate);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '00';
  const offset = getLondonOffsetMinutes(utcDate);
  return {
    date: `${get('year')}-${get('month')}-${get('day')}`,
    time: `${get('hour')}:${get('minute')}`,
    tzLabel: offset === 60 ? 'BST' : 'GMT',
    isoUtc: utcDate.toISOString(),
  };
}

export function addMinutesInLondon(
  baseUtc: Date,
  minutesToAdd: number
): {
  utc: Date;
  localDate: string;
  localTime: string;
  tzLabel: string;
  dayDifference: number;
} {
  const startParts = formatUtcToLondonParts(baseUtc);
  const targetUtc = new Date(baseUtc.getTime() + minutesToAdd * 60_000);
  const endParts = formatUtcToLondonParts(targetUtc);

  const [sy, sm, sd] = startParts.date.split('-').map(Number);
  const [ey, em, ed] = endParts.date.split('-').map(Number);
  const startDayMs = Date.UTC(sy, sm - 1, sd);
  const endDayMs = Date.UTC(ey, em - 1, ed);
  const dayDifference = Math.round((endDayMs - startDayMs) / 86_400_000);

  return {
    utc: targetUtc,
    localDate: endParts.date,
    localTime: endParts.time,
    tzLabel: endParts.tzLabel,
    dayDifference,
  };
}

export function detectDstTransitionNotice(startUtc: Date, endUtc: Date): string | null {
  const startOffset = getLondonOffsetMinutes(startUtc);
  const endOffset = getLondonOffsetMinutes(endUtc);
  if (startOffset === endOffset) return null;
  if (endOffset > startOffset) {
    return 'Clocks spring forward 1 hour (GMT to BST) during this journey. Elapsed duration reflects actual UTC travel time.';
  }
  return 'Clocks go back 1 hour (BST to GMT) during this journey. Elapsed duration reflects actual UTC travel time.';
}

export function getDefaultLondonSearchDate(daysAhead = 2): string {
  const target = new Date(Date.now() + daysAhead * 86_400_000);
  return formatUtcToLondonParts(target).date;
}

export function validateSearchInput(
  input: SearchInput,
  referenceNowUtc: Date = new Date()
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!input.originId || !input.destinationId) {
    errors.push('Choose both an origin and destination station or station group.');
  } else if (input.originId === input.destinationId) {
    errors.push('Origin and destination must be different.');
  }

  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.outwardDate)) {
    errors.push('Enter a valid outward travel date (YYYY-MM-DD).');
  }
  if (!/^\d{2}:\d{2}$/.test(input.outwardTime)) {
    errors.push('Enter a valid outward time (HH:MM).');
  }

  if (input.adults < 1 || input.adults > 9) {
    errors.push('Select between 1 and 9 adults.');
  }
  if (input.children < 0 || input.children > 9) {
    errors.push('Select between 0 and 9 children.');
  }
  if (input.adults + input.children > 9) {
    errors.push('National Rail online searches support up to 9 passengers per enquiry.');
  }

  // Railcard validation
  const uniqueRailcards = Array.from(new Set(input.railcards));
  if (uniqueRailcards.length > input.adults + input.children) {
    errors.push('You cannot apply more railcards than passengers.');
  }
  if (uniqueRailcards.includes('TWO_TOGETHER') && (input.adults !== 2 || input.children > 0)) {
    errors.push('A Two Together Railcard is valid only for 2 adults travelling together (0 children on this card).');
  }
  if (uniqueRailcards.includes('FAMILY_FRIENDS') && (input.adults < 1 || input.children < 1)) {
    errors.push('A Family & Friends Railcard requires at least 1 adult and 1 child.');
  }

  // Date & booking horizon checks in Europe/London
  if (/^\d{4}-\d{2}-\d{2}$/.test(input.outwardDate) && /^\d{2}:\d{2}$/.test(input.outwardTime)) {
    const todayLondon = formatUtcToLondonParts(referenceNowUtc).date;
    const maxDateLondon = formatUtcToLondonParts(
      new Date(referenceNowUtc.getTime() + MAX_BOOKING_HORIZON_DAYS * 86_400_000)
    ).date;

    if (input.outwardDate < todayLondon) {
      errors.push('Outward date cannot be in the past.');
    }
    if (input.outwardDate > maxDateLondon) {
      errors.push(`Outward date is beyond the ${MAX_BOOKING_HORIZON_DAYS}-day Great Britain booking horizon.`);
    }

    if (input.journeyType === 'return') {
      if (!input.returnDate || !/^\d{4}-\d{2}-\d{2}$/.test(input.returnDate)) {
        errors.push('Select a valid return date.');
      } else {
        if (input.returnDate < input.outwardDate) {
          errors.push('Return date cannot be earlier than the outward date.');
        }
        if (input.returnDate > maxDateLondon) {
          errors.push(`Return date is beyond the ${MAX_BOOKING_HORIZON_DAYS}-day Great Britain booking horizon.`);
        }
        if (input.returnDate === input.outwardDate && input.returnTime && input.returnTime <= input.outwardTime) {
          errors.push('On same-day returns, return time should be later than outward departure time.');
        }
      }
    }
  }

  return { valid: errors.length === 0, errors };
}

export function formatPence(pence: number | null | undefined): string {
  if (pence === null || pence === undefined) return 'Unknown';
  return `£${(pence / 100).toFixed(2)}`;
}
