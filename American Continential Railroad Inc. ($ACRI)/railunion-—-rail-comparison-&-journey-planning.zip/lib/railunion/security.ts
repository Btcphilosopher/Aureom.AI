import crypto from 'crypto';
import type { NextRequest } from 'next/server';

const FALLBACK_SECRET = crypto.randomBytes(32).toString('hex');

function getSessionSecret(): string {
  const configured = process.env.SESSION_SECRET?.trim();
  return configured && configured.length >= 16 ? configured : FALLBACK_SECRET;
}

export const SESSION_COOKIE_NAME = 'railunion_session';

export const ALLOWED_SELLER_HOSTS = new Set<string>([
  'checkout.pennine-rail-demo.example',
  'tickets.albion-rail-demo.example',
]);

export const OFFICIAL_ASSISTANCE_HOSTS = new Set<string>([
  'www.nationalrail.co.uk',
  'nationalrail.co.uk',
]);

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, originalHex] = parts;
  if (!salt || !originalHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const original = Buffer.from(originalHex, 'hex');
  if (derived.length !== original.length) return false;
  return crypto.timingSafeEqual(derived, original);
}

interface SessionPayload {
  uid: string;
  email: string;
  exp: number;
}

export function signSessionToken(userId: string, email: string, ttlSeconds = 60 * 60 * 24 * 7): string {
  const payload: SessionPayload = {
    uid: userId,
    email,
    exp: Math.floor(Date.now() / 1000) + ttlSeconds,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', getSessionSecret()).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): SessionPayload | null {
  if (!token || !token.includes('.')) return null;
  const [encoded, sig] = token.split('.');
  if (!encoded || !sig) return null;
  const expectedSig = crypto.createHmac('sha256', getSessionSecret()).update(encoded).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionPayload;
    if (!payload.uid || !payload.exp || payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

export function extractSessionFromRequest(req: NextRequest): SessionPayload | null {
  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    const verified = verifySessionToken(token);
    if (verified) return verified;
  }
  const cookieToken = req.cookies.get(SESSION_COOKIE_NAME)?.value;
  return verifySessionToken(cookieToken);
}

export function verifyCsrfHeaderOrOrigin(req: NextRequest): boolean {
  const requestedWith = req.headers.get('x-requested-with');
  if (requestedWith === 'Railunion') return true;
  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) return true;
  const origin = req.headers.get('origin');
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host');
  if (origin && host) {
    try {
      const originHost = new URL(origin).host;
      return originHost === host;
    } catch {
      return false;
    }
  }
  return false;
}

/**
 * Validates and constructs a safe seller handoff URL against the strict host allowlist.
 * Blocks open redirects, non-HTTPS schemes, credentials in URLs, IP literals, and unallowlisted hosts.
 */
export function validateSellerHandoffUrl(rawUrl: string): { valid: boolean; url: string | null; reason?: string } {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:') {
      return { valid: false, url: null, reason: 'Only HTTPS seller handoff URLs are permitted.' };
    }
    if (parsed.username || parsed.password) {
      return { valid: false, url: null, reason: 'Embedded credentials are not permitted in seller URLs.' };
    }
    if (!ALLOWED_SELLER_HOSTS.has(parsed.hostname)) {
      return { valid: false, url: null, reason: `Host "${parsed.hostname}" is not on the authorised seller allowlist.` };
    }
    return { valid: true, url: parsed.toString() };
  } catch {
    return { valid: false, url: null, reason: 'Malformed seller URL.' };
  }
}

// Simple bounded in-memory sliding window rate limiter
const rateBuckets = new Map<string, number[]>();

export function checkRateLimit(key: string, maxRequests = 60, windowMs = 60_000): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const windowStart = now - windowMs;
  const timestamps = (rateBuckets.get(key) ?? []).filter((t) => t > windowStart);
  if (timestamps.length >= maxRequests) {
    rateBuckets.set(key, timestamps);
    return { allowed: false, remaining: 0 };
  }
  timestamps.push(now);
  rateBuckets.set(key, timestamps);
  if (rateBuckets.size > 2000) {
    // Bound memory usage
    const firstKey = rateBuckets.keys().next().value;
    if (firstKey) rateBuckets.delete(firstKey);
  }
  return { allowed: true, remaining: maxRequests - timestamps.length };
}

export function redactSensitiveForLog(record: Record<string, unknown>): Record<string, unknown> {
  const redacted: Record<string, unknown> = {};
  const sensitiveKeys = new Set(['password', 'passwordHash', 'token', 'secret', 'authorization', 'cookie', 'email']);
  for (const [k, v] of Object.entries(record)) {
    if (sensitiveKeys.has(k)) {
      redacted[k] = '[REDACTED]';
    } else {
      redacted[k] = v;
    }
  }
  return redacted;
}
