import crypto from 'crypto';
import {
  addMinutesInLondon,
  detectDstTransitionNotice,
  londonLocalToUtc,
  RAILCARD_DEFINITIONS,
} from './timezone';
import { getStationById, lookupStations, resolveStationSelection } from './stations';
import type {
  DemoScenarioMode,
  DisruptionNotice,
  FareOffer,
  JourneyItinerary,
  JourneyLeg,
  PassengerComposition,
  ProviderStatusReport,
  RailcardCode,
  RevalidationResult,
  SearchInput,
  SellerHandoffRecord,
  StationLookupResult,
  TravelClass,
} from './types';
import { validateSellerHandoffUrl } from './security';

export interface RailProviderAdapter {
  readonly providerId: string;
  readonly providerName: string;
  readonly sellerHost: string;
  readonly isFictionalFixture: boolean;
  lookupStations(query: string): Promise<StationLookupResult>;
  searchJourneys(input: SearchInput, direction: 'outward' | 'return', searchTimeUtc: Date): Promise<JourneyItinerary[]>;
  fetchFareOffers(
    itineraries: JourneyItinerary[],
    input: SearchInput,
    searchTimeUtc: Date
  ): Promise<{ offers: FareOffer[]; statusReport: ProviderStatusReport }>;
  revalidateOffer(offer: FareOffer, scenarioMode?: DemoScenarioMode): Promise<RevalidationResult>;
  createSellerHandoff(
    offer: FareOffer,
    itinerarySummary: string,
    acceptedMaterialChange: boolean
  ): Promise<SellerHandoffRecord>;
  getHealthAndLimitations(): ProviderStatusReport;
}

interface RouteTemplate {
  id: string;
  originGroupOrId: string;
  destinationGroupOrId: string;
  originCrs: string;
  destinationCrs: string;
  departureOffsetsMin: number[];
  legs: {
    originId: string;
    destinationId: string;
    durationMin: number;
    operatorCode: string;
    operatorName: string;
    headcodePrefix: string;
    callingPoints: number;
    waitBeforeNextMin?: number;
    walkingTransferMin?: number;
    transferNote?: string;
  }[];
  baseSinglePence: number;
  hasDisruptionSample?: boolean;
}

const ROUTE_TEMPLATES: RouteTemplate[] = [
  // Sheffield -> London St Pancras (Direct EMR + Connecting via Doncaster LNER)
  {
    id: 'shf-stp-direct',
    originGroupOrId: 'SHF',
    destinationGroupOrId: 'STP',
    originCrs: 'SHF',
    destinationCrs: 'STP',
    departureOffsetsMin: [0, 32, 62, 122],
    legs: [
      {
        originId: 'SHF',
        destinationId: 'STP',
        durationMin: 124,
        operatorCode: 'EM',
        operatorName: 'East Midlands Railway',
        headcodePrefix: '1F',
        callingPoints: 5,
      },
    ],
    baseSinglePence: 4850,
  },
  {
    id: 'shf-kgx-via-don',
    originGroupOrId: 'SHF',
    destinationGroupOrId: 'KGX',
    originCrs: 'SHF',
    destinationCrs: 'KGX',
    departureOffsetsMin: [14, 74],
    legs: [
      {
        originId: 'SHF',
        destinationId: 'DON',
        durationMin: 26,
        operatorCode: 'NT',
        operatorName: 'Northern',
        headcodePrefix: '2R',
        callingPoints: 3,
        waitBeforeNextMin: 14,
        walkingTransferMin: 3,
        transferNote: 'Allow 3 min step-free lift transfer between platforms 1 and 4 at Doncaster.',
      },
      {
        originId: 'DON',
        destinationId: 'KGX',
        durationMin: 98,
        operatorCode: 'GR',
        operatorName: 'LNER',
        headcodePrefix: '1A',
        callingPoints: 2,
      },
    ],
    baseSinglePence: 4400,
    hasDisruptionSample: true,
  },
  {
    id: 'shf-stp-via-dby',
    originGroupOrId: 'SHF',
    destinationGroupOrId: 'STP',
    originCrs: 'SHF',
    destinationCrs: 'STP',
    departureOffsetsMin: [48],
    legs: [
      {
        originId: 'SHF',
        destinationId: 'DBY',
        durationMin: 31,
        operatorCode: 'XC',
        operatorName: 'CrossCountry',
        headcodePrefix: '1V',
        callingPoints: 1,
        waitBeforeNextMin: 12,
        walkingTransferMin: 2,
        transferNote: '2 min footbridge lift transfer at Derby.',
      },
      {
        originId: 'DBY',
        destinationId: 'STP',
        durationMin: 94,
        operatorCode: 'EM',
        operatorName: 'East Midlands Railway',
        headcodePrefix: '1C',
        callingPoints: 4,
      },
    ],
    baseSinglePence: 4600,
  },
  // London King's Cross -> Edinburgh Waverley
  {
    id: 'kgx-edb-direct',
    originGroupOrId: 'KGX',
    destinationGroupOrId: 'EDB',
    originCrs: 'KGX',
    destinationCrs: 'EDB',
    departureOffsetsMin: [0, 60, 120],
    legs: [
      {
        originId: 'KGX',
        destinationId: 'EDB',
        durationMin: 268,
        operatorCode: 'GR',
        operatorName: 'LNER',
        headcodePrefix: '1S',
        callingPoints: 6,
      },
    ],
    baseSinglePence: 7900,
  },
  {
    id: 'kgx-edb-via-yrk',
    originGroupOrId: 'KGX',
    destinationGroupOrId: 'EDB',
    originCrs: 'KGX',
    destinationCrs: 'EDB',
    departureOffsetsMin: [30],
    legs: [
      {
        originId: 'KGX',
        destinationId: 'YRK',
        durationMin: 112,
        operatorCode: 'GR',
        operatorName: 'LNER',
        headcodePrefix: '1N',
        callingPoints: 2,
        waitBeforeNextMin: 16,
        walkingTransferMin: 4,
        transferNote: '4 min transfer via York station subway.',
      },
      {
        originId: 'YRK',
        destinationId: 'EDB',
        durationMin: 158,
        operatorCode: 'TP',
        operatorName: 'TransPennine Express',
        headcodePrefix: '1E',
        callingPoints: 5,
      },
    ],
    baseSinglePence: 7200,
  },
  // York -> London King's Cross
  {
    id: 'yrk-kgx-direct',
    originGroupOrId: 'YRK',
    destinationGroupOrId: 'KGX',
    originCrs: 'YRK',
    destinationCrs: 'KGX',
    departureOffsetsMin: [5, 35, 95],
    legs: [
      {
        originId: 'YRK',
        destinationId: 'KGX',
        durationMin: 114,
        operatorCode: 'GR',
        operatorName: 'LNER',
        headcodePrefix: '1A',
        callingPoints: 3,
      },
    ],
    baseSinglePence: 5200,
  },
  // Manchester Piccadilly -> London Euston
  {
    id: 'man-eus-direct',
    originGroupOrId: 'MAN',
    destinationGroupOrId: 'EUS',
    originCrs: 'MAN',
    destinationCrs: 'EUS',
    departureOffsetsMin: [0, 20, 60],
    legs: [
      {
        originId: 'MAN',
        destinationId: 'EUS',
        durationMin: 127,
        operatorCode: 'VT',
        operatorName: 'Avanti West Coast',
        headcodePrefix: '1A',
        callingPoints: 4,
      },
    ],
    baseSinglePence: 5450,
  },
  // Manchester Victoria -> Leeds -> King's Cross (Connecting alternative)
  {
    id: 'mcv-kgx-via-lds',
    originGroupOrId: 'MCV',
    destinationGroupOrId: 'KGX',
    originCrs: 'MCV',
    destinationCrs: 'KGX',
    departureOffsetsMin: [15],
    legs: [
      {
        originId: 'MCV',
        destinationId: 'LDS',
        durationMin: 56,
        operatorCode: 'TP',
        operatorName: 'TransPennine Express',
        headcodePrefix: '1E',
        callingPoints: 4,
        waitBeforeNextMin: 15,
        walkingTransferMin: 3,
        transferNote: '3 min level concourse transfer at Leeds.',
      },
      {
        originId: 'LDS',
        destinationId: 'KGX',
        durationMin: 133,
        operatorCode: 'GR',
        operatorName: 'LNER',
        headcodePrefix: '1A',
        callingPoints: 5,
      },
    ],
    baseSinglePence: 4950,
  },
  // Sheffield -> Edinburgh Waverley (via Doncaster)
  {
    id: 'shf-edb-via-don',
    originGroupOrId: 'SHF',
    destinationGroupOrId: 'EDB',
    originCrs: 'SHF',
    destinationCrs: 'EDB',
    departureOffsetsMin: [10, 70],
    legs: [
      {
        originId: 'SHF',
        destinationId: 'DON',
        durationMin: 25,
        operatorCode: 'NT',
        operatorName: 'Northern',
        headcodePrefix: '2R',
        callingPoints: 3,
        waitBeforeNextMin: 15,
        walkingTransferMin: 3,
        transferNote: '3 min lift transfer at Doncaster.',
      },
      {
        originId: 'DON',
        destinationId: 'EDB',
        durationMin: 185,
        operatorCode: 'GR',
        operatorName: 'LNER',
        headcodePrefix: '1S',
        callingPoints: 4,
      },
    ],
    baseSinglePence: 6350,
  },
  // Sheffield -> Edinburgh direct CrossCountry
  {
    id: 'shf-edb-direct',
    originGroupOrId: 'SHF',
    destinationGroupOrId: 'EDB',
    originCrs: 'SHF',
    destinationCrs: 'EDB',
    departureOffsetsMin: [40],
    legs: [
      {
        originId: 'SHF',
        destinationId: 'EDB',
        durationMin: 215,
        operatorCode: 'XC',
        operatorName: 'CrossCountry',
        headcodePrefix: '1S',
        callingPoints: 7,
      },
    ],
    baseSinglePence: 6850,
  },
  // London Paddington -> Exeter St Davids -> Penzance (Coastal)
  {
    id: 'pad-pnz-direct',
    originGroupOrId: 'PAD',
    destinationGroupOrId: 'PNZ',
    originCrs: 'PAD',
    destinationCrs: 'PNZ',
    departureOffsetsMin: [0, 60],
    legs: [
      {
        originId: 'PAD',
        destinationId: 'PNZ',
        durationMin: 305,
        operatorCode: 'GW',
        operatorName: 'Great Western Railway',
        headcodePrefix: '1A',
        callingPoints: 11,
      },
    ],
    baseSinglePence: 7400,
  },
  {
    id: 'pad-exd-direct',
    originGroupOrId: 'PAD',
    destinationGroupOrId: 'EXD',
    originCrs: 'PAD',
    destinationCrs: 'EXD',
    departureOffsetsMin: [0, 60],
    legs: [
      {
        originId: 'PAD',
        destinationId: 'EXD',
        durationMin: 124,
        operatorCode: 'GW',
        operatorName: 'Great Western Railway',
        headcodePrefix: '1C',
        callingPoints: 4,
      },
    ],
    baseSinglePence: 5100,
  },
  // Edinburgh -> Inverness (Highland route)
  {
    id: 'edb-inv-direct',
    originGroupOrId: 'EDB',
    destinationGroupOrId: 'INV',
    originCrs: 'EDB',
    destinationCrs: 'INV',
    departureOffsetsMin: [15, 75],
    legs: [
      {
        originId: 'EDB',
        destinationId: 'INV',
        durationMin: 212,
        operatorCode: 'SR',
        operatorName: 'ScotRail',
        headcodePrefix: '1H',
        callingPoints: 9,
      },
    ],
    baseSinglePence: 4650,
  },
  // London Euston -> Edinburgh (Overnight Caledonian Sleeper style)
  {
    id: 'eus-edb-overnight',
    originGroupOrId: 'EUS',
    destinationGroupOrId: 'EDB',
    originCrs: 'EUS',
    destinationCrs: 'EDB',
    departureOffsetsMin: [0],
    legs: [
      {
        originId: 'EUS',
        destinationId: 'EDB',
        durationMin: 435, // 7h15m overnight crossing midnight
        operatorCode: 'CS',
        operatorName: 'Caledonian Sleeper',
        headcodePrefix: '1S',
        callingPoints: 3,
      },
    ],
    baseSinglePence: 8900,
  },
];

function buildReverseTemplate(tpl: RouteTemplate): RouteTemplate {
  const reversedLegs = [...tpl.legs].reverse().map((leg, idx, arr) => ({
    originId: leg.destinationId,
    destinationId: leg.originId,
    durationMin: leg.durationMin,
    operatorCode: leg.operatorCode,
    operatorName: leg.operatorName,
    headcodePrefix: leg.headcodePrefix,
    callingPoints: leg.callingPoints,
    waitBeforeNextMin: idx < arr.length - 1 ? 14 : undefined,
    walkingTransferMin: idx < arr.length - 1 ? 3 : undefined,
    transferNote: idx < arr.length - 1 ? `3 min transfer at ${getStationById(leg.originId)?.name ?? leg.originId}.` : undefined,
  }));

  return {
    ...tpl,
    id: `${tpl.id}-rev`,
    originGroupOrId: tpl.destinationGroupOrId,
    destinationGroupOrId: tpl.originGroupOrId,
    originCrs: tpl.destinationCrs,
    destinationCrs: tpl.originCrs,
    legs: reversedLegs,
  };
}

const ALL_ROUTE_TEMPLATES: RouteTemplate[] = [
  ...ROUTE_TEMPLATES,
  ...ROUTE_TEMPLATES.map(buildReverseTemplate),
];

function findMatchingTemplates(originId: string, destinationId: string): {
  templates: RouteTemplate[];
  groupNotice: string | null;
} {
  const originResolved = resolveStationSelection(originId);
  const destResolved = resolveStationSelection(destinationId);

  const originIds = new Set(originResolved.expandedStationIds);
  const destIds = new Set(destResolved.expandedStationIds);

  const exact = ALL_ROUTE_TEMPLATES.filter(
    (tpl) => originIds.has(tpl.originGroupOrId) && destIds.has(tpl.destinationGroupOrId)
  );

  let groupNotice: string | null = null;
  if (originResolved.isGroup || destResolved.isGroup) {
    const groupParts: string[] = [];
    if (originResolved.isGroup && originResolved.station) {
      groupParts.push(`${originResolved.station.name} covers ${originResolved.expandedStationIds.join(', ')}`);
    }
    if (destResolved.isGroup && destResolved.station) {
      groupParts.push(`${destResolved.station.name} covers ${destResolved.expandedStationIds.join(', ')}`);
    }
    groupNotice = `Station group search active: ${groupParts.join('; ')}. Individual terminal names are preserved on each itinerary.`;
  }

  if (exact.length > 0) {
    return { templates: exact, groupNotice };
  }

  // Deterministic synthetic intercity fallback for any valid GB station pair in our catalogue
  const originStation = getStationById(originResolved.expandedStationIds[0] ?? originId);
  const destStation = getStationById(destResolved.expandedStationIds[0] ?? destinationId);
  if (!originStation || !destStation) return { templates: [], groupNotice };

  // Distance estimate via Haversine for realistic duration & base fare
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(destStation.latitude - originStation.latitude);
  const dLon = toRad(destStation.longitude - originStation.longitude);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(originStation.latitude)) *
      Math.cos(toRad(destStation.latitude)) *
      Math.sin(dLon / 2) ** 2;
  const km = 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const totalMin = Math.max(48, Math.round(km * 0.62 + 18));
  const basePence = Math.max(1850, Math.round(km * 24 + 900));

  const hubId = originStation.id !== 'DBY' && destStation.id !== 'DBY' ? 'DBY' : 'DON';
  const leg1Min = Math.max(24, Math.round(totalMin * 0.42));
  const leg2Min = Math.max(24, totalMin - leg1Min);

  const synthetic: RouteTemplate[] = [
    {
      id: `syn-${originStation.id.toLowerCase()}-${destStation.id.toLowerCase()}-1`,
      originGroupOrId: originStation.id,
      destinationGroupOrId: destStation.id,
      originCrs: originStation.crs,
      destinationCrs: destStation.crs,
      departureOffsetsMin: [8, 68],
      legs: [
        {
          originId: originStation.id,
          destinationId: destStation.id,
          durationMin: totalMin,
          operatorCode: 'XC',
          operatorName: 'CrossCountry',
          headcodePrefix: '1M',
          callingPoints: 5,
        },
      ],
      baseSinglePence: basePence,
    },
    {
      id: `syn-${originStation.id.toLowerCase()}-${destStation.id.toLowerCase()}-2`,
      originGroupOrId: originStation.id,
      destinationGroupOrId: destStation.id,
      originCrs: originStation.crs,
      destinationCrs: destStation.crs,
      departureOffsetsMin: [28],
      legs: [
        {
          originId: originStation.id,
          destinationId: hubId,
          durationMin: leg1Min,
          operatorCode: 'NT',
          operatorName: 'Northern',
          headcodePrefix: '2D',
          callingPoints: 3,
          waitBeforeNextMin: 14,
          walkingTransferMin: 3,
          transferNote: `3 min step-free transfer at ${getStationById(hubId)?.name ?? hubId}.`,
        },
        {
          originId: hubId,
          destinationId: destStation.id,
          durationMin: leg2Min,
          operatorCode: 'EM',
          operatorName: 'East Midlands Railway',
          headcodePrefix: '1C',
          callingPoints: 4,
        },
      ],
      baseSinglePence: Math.max(1650, basePence - 350),
    },
  ];

  return { templates: synthetic, groupNotice };
}

function buildItinerariesForDirection(
  providerId: string,
  input: SearchInput,
  direction: 'outward' | 'return',
  searchTimeUtc: Date
): JourneyItinerary[] {
  const originId = direction === 'outward' ? input.originId : input.destinationId;
  const destinationId = direction === 'outward' ? input.destinationId : input.originId;
  const dateStr = direction === 'outward' ? input.outwardDate : input.returnDate ?? input.outwardDate;
  const timeStr = direction === 'outward' ? input.outwardTime : input.returnTime ?? '16:30';
  const timeMode = direction === 'outward' ? input.outwardTimeMode : input.returnTimeMode ?? 'depart_at';

  const { templates, groupNotice } = findMatchingTemplates(originId, destinationId);
  const anchorUtc = londonLocalToUtc(dateStr, timeStr);

  const itineraries: JourneyItinerary[] = [];

  for (const tpl of templates) {
    for (let idx = 0; idx < tpl.departureOffsetsMin.length; idx++) {
      const offsetMin = tpl.departureOffsetsMin[idx];
      const totalScheduledDuration = tpl.legs.reduce(
        (acc, leg) => acc + leg.durationMin + (leg.waitBeforeNextMin ?? 0),
        0
      );

      // If arrive_by, anchor arrival around requested time minus offset
      const departureUtc =
        timeMode === 'arrive_by'
          ? new Date(anchorUtc.getTime() - (totalScheduledDuration + offsetMin) * 60_000)
          : new Date(anchorUtc.getTime() + offsetMin * 60_000);

      let cursorMin = 0;
      const builtLegs: JourneyLeg[] = [];
      const interchangeIds: string[] = [];
      const interchangeNames: string[] = [];
      const transferDurations: number[] = [];
      const operatorsMap = new Map<string, string>();
      const allDisruptions: DisruptionNotice[] = [];

      for (let lIdx = 0; lIdx < tpl.legs.length; lIdx++) {
        const legSpec = tpl.legs[lIdx];
        const legStart = addMinutesInLondon(departureUtc, cursorMin);
        const legEnd = addMinutesInLondon(departureUtc, cursorMin + legSpec.durationMin);

        const origSt = getStationById(legSpec.originId);
        const destSt = getStationById(legSpec.destinationId);

        const legDisruptions: DisruptionNotice[] = [];
        if (tpl.hasDisruptionSample && lIdx === 0) {
          const notice: DisruptionNotice = {
            id: `dis-${tpl.id}-${idx}`,
            severity: 'minor',
            category: 'live_running',
            headline: `Minor signalling delay near ${origSt?.name ?? legSpec.originId}`,
            detail: 'Trains may run up to 6 minutes later than timetabled. Fare availability is unaffected.',
            source: 'National Rail Darwin Demonstration Feed',
            reportedAtUtc: searchTimeUtc.toISOString(),
          };
          legDisruptions.push(notice);
          allDisruptions.push(notice);
        }

        const estDep =
          legDisruptions.length > 0
            ? addMinutesInLondon(legStart.utc, 4).localTime
            : legStart.localTime;
        const estArr =
          legDisruptions.length > 0
            ? addMinutesInLondon(legEnd.utc, 4).localTime
            : legEnd.localTime;

        const headcodeNum = (10 + idx * 14 + lIdx * 3) % 90 + 10;
        const serviceId = `${legSpec.operatorCode}-${dateStr.replace(/-/g, '')}-${legSpec.headcodePrefix}${headcodeNum}`;

        builtLegs.push({
          legId: `${tpl.id}-${direction}-${idx}-leg-${lIdx}`,
          originStationId: legSpec.originId,
          originName: origSt?.name ?? legSpec.originId,
          originCrs: origSt?.crs ?? legSpec.originId,
          destinationStationId: legSpec.destinationId,
          destinationName: destSt?.name ?? legSpec.destinationId,
          destinationCrs: destSt?.crs ?? legSpec.destinationId,
          scheduledDepartureLocal: `${legStart.localDate}T${legStart.localTime}`,
          scheduledArrivalLocal: `${legEnd.localDate}T${legEnd.localTime}`,
          scheduledDepartureUtc: legStart.utc.toISOString(),
          scheduledArrivalUtc: legEnd.utc.toISOString(),
          estimatedDepartureLocal: estDep,
          estimatedArrivalLocal: estArr,
          actualDepartureLocal: null,
          actualArrivalLocal: null,
          durationMinutes: legSpec.durationMin,
          operatorCode: legSpec.operatorCode,
          operatorName: legSpec.operatorName,
          serviceId,
          headcode: `${legSpec.headcodePrefix}${headcodeNum}`,
          platform: `${((idx + lIdx) % 7) + 1}`,
          walkingTransferMinutes: legSpec.walkingTransferMin ?? null,
          transferNote: legSpec.transferNote ?? null,
          callingPointsCount: legSpec.callingPoints,
          disruptions: legDisruptions,
        });

        operatorsMap.set(legSpec.operatorCode, legSpec.operatorName);
        cursorMin += legSpec.durationMin;

        if (lIdx < tpl.legs.length - 1 && legSpec.waitBeforeNextMin) {
          interchangeIds.push(legSpec.destinationId);
          interchangeNames.push(destSt?.name ?? legSpec.destinationId);
          transferDurations.push(legSpec.waitBeforeNextMin);
          cursorMin += legSpec.waitBeforeNextMin;
        }
      }

      const finalEnd = addMinutesInLondon(departureUtc, cursorMin);
      const depStart = addMinutesInLondon(departureUtc, 0);
      const dstNotice = detectDstTransitionNotice(depStart.utc, finalEnd.utc);

      const firstLeg = builtLegs[0];
      const lastLeg = builtLegs[builtLegs.length - 1];

      const journeyId = `JRN-${direction.toUpperCase()}-${tpl.id}-${idx}-${dateStr}-${depStart.localTime.replace(':', '')}`;

      itineraries.push({
        journeyId,
        direction,
        providerId,
        searchTimeUtc: searchTimeUtc.toISOString(),
        originStationId: firstLeg.originStationId,
        originName: firstLeg.originName,
        originCrs: firstLeg.originCrs,
        destinationStationId: lastLeg.destinationStationId,
        destinationName: lastLeg.destinationName,
        destinationCrs: lastLeg.destinationCrs,
        departureLocal: `${depStart.localDate}T${depStart.localTime}`,
        arrivalLocal: `${finalEnd.localDate}T${finalEnd.localTime}`,
        departureUtc: depStart.utc.toISOString(),
        arrivalUtc: finalEnd.utc.toISOString(),
        overnightDays: finalEnd.dayDifference,
        dstTransitionNotice: dstNotice,
        durationMinutes: cursorMin,
        changesCount: Math.max(0, builtLegs.length - 1),
        interchangeStationIds: interchangeIds,
        interchangeNames,
        transferDurationsMinutes: transferDurations,
        operators: Array.from(operatorsMap.entries()).map(([code, name]) => ({ code, name })),
        legs: builtLegs,
        disruptions: allDisruptions,
        timetableSource: 'Railunion Synthetic GB Timetable Fixture (Fictional Times)',
        timetableFreshnessUtc: searchTimeUtc.toISOString(),
        stationGroupNotice: groupNotice,
      });
    }
  }

  // Sort chronologically by departureUtc
  itineraries.sort((a, b) => a.departureUtc.localeCompare(b.departureUtc));
  return itineraries;
}

function computePassengerMultiplier(
  adults: number,
  children: number,
  railcards: RailcardCode[],
  travelClass: TravelClass,
  isAdvance: boolean,
  departureLocalTime: string
): number {
  const classMultiplier = travelClass === 'first' ? 1.58 : 1.0;

  let adultRate = 1.0;
  let childRate = 0.5;

  const hasCard = railcards.length > 0;
  if (hasCard) {
    const primaryCard = railcards[0];
    const hour = parseInt(departureLocalTime.slice(11, 13), 10);
    const min = parseInt(departureLocalTime.slice(14, 16), 10);
    const totalMins = hour * 60 + min;

    const isEligibleTime =
      primaryCard === 'TWO_TOGETHER'
        ? totalMins >= 9 * 60 + 30
        : primaryCard === 'NETWORK'
          ? totalMins >= 10 * 60
          : true;

    const cardDef = RAILCARD_DEFINITIONS[primaryCard];
    const eligibleClass = travelClass === 'standard' || primaryCard === 'SENIOR' || primaryCard === 'HM_FORCES' || isAdvance;

    if (isEligibleTime && eligibleClass && cardDef) {
      adultRate = 1 - cardDef.discountPercent / 100;
      if (primaryCard === 'FAMILY_FRIENDS') {
        childRate = 0.4; // 60% off child fare
      }
    }
  }

  const totalFactor = adults * adultRate + children * childRate;
  return totalFactor * classMultiplier;
}

function buildPassengerSummary(adults: number, children: number, railcards: RailcardCode[]): PassengerComposition {
  const parts: string[] = [`${adults} adult${adults === 1 ? '' : 's'}`];
  if (children > 0) parts.push(`${children} child${children === 1 ? '' : 'ren'}`);
  if (railcards.length > 0) parts.push(`${railcards.length} railcard${railcards.length === 1 ? '' : 's'}`);
  return {
    adults,
    children,
    summary: parts.join(', '),
  };
}

function makeEquivalenceKey(params: {
  journeyId: string;
  passengerSummary: string;
  railcards: RailcardCode[];
  travelClass: TravelClass;
  ticketCategory: FareOffer['ticket_category'];
  trainBinding: FareOffer['train_binding'];
  routeRestrictions: string;
  operatorRestrictions: string;
  refundConditions: string;
  changeConditions: string;
  fulfilmentMethod: FareOffer['fulfilment_method'];
  feeCompleteness: FareOffer['fee_completeness'];
}): string {
  const canonical = [
    params.journeyId,
    params.passengerSummary,
    [...params.railcards].sort().join(','),
    params.travelClass,
    params.ticketCategory,
    params.trainBinding,
    params.routeRestrictions,
    params.operatorRestrictions,
    params.refundConditions,
    params.changeConditions,
    params.fulfilmentMethod,
    params.feeCompleteness,
  ].join('|');
  return crypto.createHash('sha1').update(canonical).digest('hex').slice(0, 14);
}

function buildFixtureOffersForItinerary(
  providerId: string,
  providerName: string,
  sellerHost: string,
  itinerary: JourneyItinerary,
  input: SearchInput,
  searchTimeUtc: Date
): FareOffer[] {
  const passengerComp = buildPassengerSummary(input.adults, input.children, input.railcards);
  const isReturn = input.journeyType === 'return';
  const baseRoutePence = itinerary.changesCount === 0 ? 4850 : 4400;
  const distanceWeight = Math.max(1, itinerary.durationMinutes / 120);
  const anchorSinglePence = Math.round(baseRoutePence * (0.72 + 0.28 * distanceWeight));

  const primaryOperator = itinerary.operators.map((o) => o.name).join(' & ');
  const isPennine = providerId === 'pennine_retail';
  const scenario = input.scenarioMode ?? 'normal';

  const offers: FareOffer[] = [];

  // 1. Advance Single (booked train only)
  const advFactor = computePassengerMultiplier(
    input.adults,
    input.children,
    input.railcards,
    input.travelClass,
    true,
    itinerary.departureLocal
  );
  const advBase = Math.round(anchorSinglePence * 0.64 * advFactor);
  // Albion slightly lower ticket price on Advance, Pennine charges £0 fee
  const advTicketPrice = isPennine ? advBase + 150 : advBase;
  const advBookingFee = isPennine ? 0 : scenario === 'missing_fee' ? null : 100;
  const advFeeCompleteness = advBookingFee === null ? 'missing_mandatory_fee' : 'complete';
  const advTotalKnown = advBookingFee === null ? null : advTicketPrice + advBookingFee;

  const isExpiredScenario = !isPennine && scenario === 'expired_offer';
  const quoteExpires = isExpiredScenario
    ? new Date(searchTimeUtc.getTime() - 120_000).toISOString()
    : new Date(searchTimeUtc.getTime() + 15 * 60_000).toISOString();

  const advHandoffRef = `HO-${providerId.slice(0, 3).toUpperCase()}-${itinerary.journeyId.slice(-6)}-ADV`;
  offers.push({
    offer_id: `OFR-${providerId}-${itinerary.journeyId}-ADV`,
    provider_id: providerId,
    provider_name: providerName,
    journey_reference: itinerary.journeyId,
    passenger_composition: passengerComp,
    railcards_applied: input.railcards,
    travel_class: input.travelClass,
    ticket_product: `${input.travelClass === 'first' ? 'First ' : ''}Advance Single`,
    ticket_category: 'advance',
    route_restrictions: `Valid only via ${itinerary.interchangeNames.length > 0 ? itinerary.interchangeNames.join(' & ') : 'direct booked route'}.`,
    operator_restrictions: `Valid only on ${primaryOperator} services shown.`,
    time_restrictions: `Must travel on the ${itinerary.departureLocal.slice(11, 16)} departure only.`,
    train_binding: 'booked_train_only',
    reservation_status: 'included_compulsory',
    refund_conditions: 'Non-refundable.',
    change_conditions: 'Exchangeable before departure for a £10.00 admin fee plus fare difference.',
    ticket_price: advTicketPrice,
    mandatory_fees: advBookingFee,
    fulfilment_fees: 0,
    fulfilment_method: 'e_ticket',
    total_known_payable_pence: advTotalKnown,
    fee_completeness: advFeeCompleteness,
    currency: 'GBP',
    quoted_at: searchTimeUtc.toISOString(),
    expires_at: quoteExpires,
    seller_handoff_reference: advHandoffRef,
    seller_name: providerName,
    seller_host: sellerHost,
    is_sponsored: false,
    sponsored_label: null,
    equivalence_key: makeEquivalenceKey({
      journeyId: itinerary.journeyId,
      passengerSummary: passengerComp.summary,
      railcards: input.railcards,
      travelClass: input.travelClass,
      ticketCategory: 'advance',
      trainBinding: 'booked_train_only',
      routeRestrictions: `Valid only via ${itinerary.interchangeNames.length > 0 ? itinerary.interchangeNames.join(' & ') : 'direct booked route'}.`,
      operatorRestrictions: `Valid only on ${primaryOperator} services shown.`,
      refundConditions: 'Non-refundable.',
      changeConditions: 'Exchangeable before departure for a £10.00 admin fee plus fare difference.',
      fulfilmentMethod: 'e_ticket',
      feeCompleteness: advFeeCompleteness,
    }),
    condition_summary_short: 'Booked train only · Non-refundable · E-ticket',
    availability_status: isExpiredScenario ? 'expired' : 'available',
    price_change_on_revalidate_pence: !isPennine && scenario === 'price_change' ? 450 : 0,
  });

  // 2. Off-Peak Single (or Off-Peak Return when return journey selected)
  const offFactor = computePassengerMultiplier(
    input.adults,
    input.children,
    input.railcards,
    input.travelClass,
    false,
    itinerary.departureLocal
  );
  const offBase = Math.round(anchorSinglePence * (isReturn ? 1.45 : 1.0) * offFactor);
  const offTicketPrice = isPennine ? offBase : offBase + 100;
  const offFee = isPennine ? 0 : 125;

  const offProduct = isReturn
    ? `${input.travelClass === 'first' ? 'First ' : ''}Off-Peak Return`
    : `${input.travelClass === 'first' ? 'First ' : ''}Off-Peak Single`;

  offers.push({
    offer_id: `OFR-${providerId}-${itinerary.journeyId}-OFF`,
    provider_id: providerId,
    provider_name: providerName,
    journey_reference: itinerary.journeyId,
    passenger_composition: passengerComp,
    railcards_applied: input.railcards,
    travel_class: input.travelClass,
    ticket_product: offProduct,
    ticket_category: isReturn ? 'return_product' : 'off_peak',
    route_restrictions: 'Any Permitted route.',
    operator_restrictions: 'Any permitted National Rail operator.',
    time_restrictions: 'Valid on off-peak services (typically arriving into London Terminals at or after 10:00 Mon–Fri).',
    train_binding: 'flexible_any_permitted',
    reservation_status: 'optional_recommended',
    refund_conditions: 'Refundable prior to expiry with £5.00 administration fee.',
    change_conditions: 'Travel on any eligible off-peak train on the ticket date without fee.',
    ticket_price: offTicketPrice,
    mandatory_fees: offFee,
    fulfilment_fees: 0,
    fulfilment_method: 'e_ticket',
    total_known_payable_pence: offTicketPrice + offFee,
    fee_completeness: 'complete',
    currency: 'GBP',
    quoted_at: searchTimeUtc.toISOString(),
    expires_at: new Date(searchTimeUtc.getTime() + 20 * 60_000).toISOString(),
    seller_handoff_reference: `HO-${providerId.slice(0, 3).toUpperCase()}-${itinerary.journeyId.slice(-6)}-OFF`,
    seller_name: providerName,
    seller_host: sellerHost,
    is_sponsored: false,
    sponsored_label: null,
    equivalence_key: makeEquivalenceKey({
      journeyId: itinerary.journeyId,
      passengerSummary: passengerComp.summary,
      railcards: input.railcards,
      travelClass: input.travelClass,
      ticketCategory: isReturn ? 'return_product' : 'off_peak',
      trainBinding: 'flexible_any_permitted',
      routeRestrictions: 'Any Permitted route.',
      operatorRestrictions: 'Any permitted National Rail operator.',
      refundConditions: 'Refundable prior to expiry with £5.00 administration fee.',
      changeConditions: 'Travel on any eligible off-peak train on the ticket date without fee.',
      fulfilmentMethod: 'e_ticket',
      feeCompleteness: 'complete',
    }),
    condition_summary_short: isReturn
      ? 'Flexible Off-Peak Return · Any permitted train · Refundable'
      : 'Flexible Off-Peak · Any permitted train · Refundable',
    availability_status: 'available',
    price_change_on_revalidate_pence: !isPennine && scenario === 'price_change' ? 450 : 0,
  });

  // 3. Anytime Single (Pennine offers standard Anytime; full flexibility)
  if (isPennine) {
    const anyBase = Math.round(anchorSinglePence * (isReturn ? 1.95 : 1.38) * offFactor);
    const anyProduct = isReturn
      ? `${input.travelClass === 'first' ? 'First ' : ''}Anytime Return`
      : `${input.travelClass === 'first' ? 'First ' : ''}Anytime Single`;

    offers.push({
      offer_id: `OFR-${providerId}-${itinerary.journeyId}-ANY`,
      provider_id: providerId,
      provider_name: providerName,
      journey_reference: itinerary.journeyId,
      passenger_composition: passengerComp,
      railcards_applied: input.railcards,
      travel_class: input.travelClass,
      ticket_product: anyProduct,
      ticket_category: 'anytime',
      route_restrictions: 'Any Permitted route.',
      operator_restrictions: 'Any National Rail operator.',
      time_restrictions: 'No time restrictions. Travel at any time of day.',
      train_binding: 'flexible_any_permitted',
      reservation_status: 'optional_recommended',
      refund_conditions: 'Fully refundable before departure (subject to standard National Rail terms).',
      change_conditions: 'Board any train on valid dates without amendment fee.',
      ticket_price: anyBase,
      mandatory_fees: 0,
      fulfilment_fees: 0,
      fulfilment_method: 'e_ticket',
      total_known_payable_pence: anyBase,
      fee_completeness: 'complete',
      currency: 'GBP',
      quoted_at: searchTimeUtc.toISOString(),
      expires_at: new Date(searchTimeUtc.getTime() + 25 * 60_000).toISOString(),
      seller_handoff_reference: `HO-${providerId.slice(0, 3).toUpperCase()}-${itinerary.journeyId.slice(-6)}-ANY`,
      seller_name: providerName,
      seller_host: sellerHost,
      is_sponsored: false,
      sponsored_label: null,
      equivalence_key: makeEquivalenceKey({
        journeyId: itinerary.journeyId,
        passengerSummary: passengerComp.summary,
        railcards: input.railcards,
        travelClass: input.travelClass,
        ticketCategory: 'anytime',
        trainBinding: 'flexible_any_permitted',
        routeRestrictions: 'Any Permitted route.',
        operatorRestrictions: 'Any National Rail operator.',
        refundConditions: 'Fully refundable before departure (subject to standard National Rail terms).',
        changeConditions: 'Board any train on valid dates without amendment fee.',
        fulfilmentMethod: 'e_ticket',
        feeCompleteness: 'complete',
      }),
      condition_summary_short: 'No time restrictions · Fully flexible · Refundable',
      availability_status: 'available',
    });
  }

  return offers;
}

class FixtureRailProvider implements RailProviderAdapter {
  readonly providerId: string;
  readonly providerName: string;
  readonly sellerHost: string;
  readonly isFictionalFixture = true;
  private readonly limitations: string[];

  constructor(opts: {
    providerId: string;
    providerName: string;
    sellerHost: string;
    limitations: string[];
  }) {
    this.providerId = opts.providerId;
    this.providerName = opts.providerName;
    this.sellerHost = opts.sellerHost;
    this.limitations = opts.limitations;
  }

  async lookupStations(query: string): Promise<StationLookupResult> {
    return lookupStations(query);
  }

  async searchJourneys(
    input: SearchInput,
    direction: 'outward' | 'return',
    searchTimeUtc: Date
  ): Promise<JourneyItinerary[]> {
    return buildItinerariesForDirection(this.providerId, input, direction, searchTimeUtc);
  }

  async fetchFareOffers(
    itineraries: JourneyItinerary[],
    input: SearchInput,
    searchTimeUtc: Date
  ): Promise<{ offers: FareOffer[]; statusReport: ProviderStatusReport }> {
    const startMs = Date.now();
    const scenario = input.scenarioMode ?? 'normal';

    // Simulate bounded timeout or empty fares on Albion Distribution
    if (this.providerId === 'albion_dist' && scenario === 'provider_timeout') {
      return {
        offers: [],
        statusReport: {
          providerId: this.providerId,
          providerName: this.providerName,
          isFictionalFixture: true,
          status: 'timeout',
          responseTimeMs: 2500,
          offersReturned: 0,
          message: 'Albion Rail Distribution exceeded the 2,500ms request timeout budget. Partial results shown from responding providers.',
          limitations: this.limitations,
          checkedAtUtc: searchTimeUtc.toISOString(),
        },
      };
    }

    if (this.providerId === 'albion_dist' && scenario === 'provider_no_fares') {
      return {
        offers: [],
        statusReport: {
          providerId: this.providerId,
          providerName: this.providerName,
          isFictionalFixture: true,
          status: 'no_fares',
          responseTimeMs: 42,
          offersReturned: 0,
          message: 'Albion Rail Distribution returned no purchasable fares for this enquiry.',
          limitations: this.limitations,
          checkedAtUtc: searchTimeUtc.toISOString(),
        },
      };
    }

    const offers: FareOffer[] = [];
    for (const itinerary of itineraries) {
      offers.push(
        ...buildFixtureOffersForItinerary(
          this.providerId,
          this.providerName,
          this.sellerHost,
          itinerary,
          input,
          searchTimeUtc
        )
      );
    }

    const elapsed = Math.max(18, Date.now() - startMs + (this.providerId === 'pennine_retail' ? 24 : 38));

    return {
      offers,
      statusReport: {
        providerId: this.providerId,
        providerName: this.providerName,
        isFictionalFixture: true,
        status: 'healthy',
        responseTimeMs: elapsed,
        offersReturned: offers.length,
        message: `Returned ${offers.length} illustrative fare offers.`,
        limitations: this.limitations,
        checkedAtUtc: searchTimeUtc.toISOString(),
      },
    };
  }

  async revalidateOffer(
    offer: FareOffer,
    scenarioMode: DemoScenarioMode = 'normal'
  ): Promise<RevalidationResult> {
    const now = new Date();
    const expiredByTimestamp = new Date(offer.expires_at).getTime() <= now.getTime();
    const shouldExpire =
      expiredByTimestamp ||
      offer.availability_status === 'expired' ||
      (this.providerId === 'albion_dist' && scenarioMode === 'expired_offer');

    if (shouldExpire) {
      return {
        offerId: offer.offer_id,
        providerId: this.providerId,
        status: 'expired',
        originalTotalPence: offer.total_known_payable_pence,
        revalidatedTotalPence: null,
        priceDeltaPence: null,
        conditionChanges: [],
        requiresCustomerAcceptance: false,
        revalidatedAtUtc: now.toISOString(),
        expiresAtUtc: offer.expires_at,
        message: 'This quoted offer has expired and can no longer be sent to the seller. Run a fresh search for current availability.',
        updatedOffer: null,
      };
    }

    const deltaPence =
      offer.price_change_on_revalidate_pence ??
      (this.providerId === 'albion_dist' && scenarioMode === 'price_change' ? 450 : 0);

    if (deltaPence !== 0) {
      const baseTotal = offer.total_known_payable_pence ?? offer.ticket_price;
      const newTicketPrice = offer.ticket_price + deltaPence;
      const newTotal = offer.mandatory_fees === null ? null : newTicketPrice + offer.mandatory_fees;
      const updatedOffer: FareOffer = {
        ...offer,
        ticket_price: newTicketPrice,
        total_known_payable_pence: newTotal,
        quoted_at: now.toISOString(),
        expires_at: new Date(now.getTime() + 10 * 60_000).toISOString(),
        price_change_on_revalidate_pence: 0,
      };
      return {
        offerId: offer.offer_id,
        providerId: this.providerId,
        status: 'price_changed',
        originalTotalPence: baseTotal,
        revalidatedTotalPence: newTotal,
        priceDeltaPence: deltaPence,
        conditionChanges: [
          `Advance allocation tier updated during seller revalidation (+£${(deltaPence / 100).toFixed(2)}).`,
        ],
        requiresCustomerAcceptance: true,
        revalidatedAtUtc: now.toISOString(),
        expiresAtUtc: updatedOffer.expires_at,
        message: `Price updated from £${(baseTotal / 100).toFixed(2)} to £${((newTotal ?? newTicketPrice) / 100).toFixed(2)} during live revalidation. Confirm acceptance to continue.`,
        updatedOffer,
      };
    }

    const refreshed: FareOffer = {
      ...offer,
      quoted_at: now.toISOString(),
      expires_at: new Date(now.getTime() + 15 * 60_000).toISOString(),
    };

    return {
      offerId: offer.offer_id,
      providerId: this.providerId,
      status: 'unchanged',
      originalTotalPence: offer.total_known_payable_pence,
      revalidatedTotalPence: offer.total_known_payable_pence,
      priceDeltaPence: 0,
      conditionChanges: [],
      requiresCustomerAcceptance: false,
      revalidatedAtUtc: now.toISOString(),
      expiresAtUtc: refreshed.expires_at,
      message: 'Fare and ticket conditions verified unchanged.',
      updatedOffer: refreshed,
    };
  }

  async createSellerHandoff(
    offer: FareOffer,
    itinerarySummary: string,
    acceptedMaterialChange: boolean
  ): Promise<SellerHandoffRecord> {
    const handoffReference = `${offer.seller_handoff_reference}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const candidateUrl = `https://${this.sellerHost}/checkout?ref=${encodeURIComponent(handoffReference)}&offer=${encodeURIComponent(offer.offer_id)}`;
    const validated = validateSellerHandoffUrl(candidateUrl);
    if (!validated.valid || !validated.url) {
      throw new Error(validated.reason ?? 'Seller handoff URL failed allowlist validation.');
    }

    return {
      handoffReference,
      offerId: offer.offer_id,
      providerId: this.providerId,
      sellerName: this.providerName,
      sellerHost: this.sellerHost,
      validatedSellerUrl: validated.url,
      journeySummary: itinerarySummary,
      passengerSummary: offer.passenger_composition.summary,
      travelClass: offer.travel_class,
      ticketProduct: offer.ticket_product,
      acceptedTotalPence: offer.total_known_payable_pence,
      currency: 'GBP',
      acceptedMaterialChange,
      createdAtUtc: new Date().toISOString(),
      disclaimer: `You’ll complete your purchase with ${this.providerName}. Railunion does not issue tickets or confirm seat reservations.`,
    };
  }

  getHealthAndLimitations(): ProviderStatusReport {
    return {
      providerId: this.providerId,
      providerName: this.providerName,
      isFictionalFixture: true,
      status: 'healthy',
      responseTimeMs: this.providerId === 'pennine_retail' ? 24 : 38,
      offersReturned: 0,
      message: 'Deterministic demonstration fixture adapter active.',
      limitations: this.limitations,
      checkedAtUtc: new Date().toISOString(),
    };
  }
}

export const pennineRetailProvider = new FixtureRailProvider({
  providerId: 'pennine_retail',
  providerName: 'Pennine & Southern Rail Retail',
  sellerHost: 'checkout.pennine-rail-demo.example',
  limitations: [
    'Fictional demonstration retailer using synthetic GB timetable & fare fixtures.',
    'Split-ticket combinations are deferred until an authorised RDG fare-routing validator is integrated.',
    'No live booking or ticket issuance occurs.',
  ],
});

export const albionDistributionProvider = new FixtureRailProvider({
  providerId: 'albion_dist',
  providerName: 'Albion Rail Distribution',
  sellerHost: 'tickets.albion-rail-demo.example',
  limitations: [
    'Fictional independent distribution fixture; models booking fees and scenario failure modes.',
    'May omit Anytime products or return incomplete fees in demonstration edge-case modes.',
    'No live booking or ticket issuance occurs.',
  ],
});

export const ALL_PROVIDERS: RailProviderAdapter[] = [
  pennineRetailProvider,
  albionDistributionProvider,
];

export function getProviderById(providerId: string): RailProviderAdapter | null {
  return ALL_PROVIDERS.find((p) => p.providerId === providerId) ?? null;
}
