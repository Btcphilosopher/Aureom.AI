import type { Station, StationLookupResult } from './types';

export const GB_STATIONS: Station[] = [
  {
    id: 'SHF',
    crs: 'SHF',
    nlc: '6607',
    tiploc: 'SHEFFLD',
    name: 'Sheffield',
    city: 'Sheffield',
    region: 'South Yorkshire',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['DBY', 'DON', 'LDS'],
    latitude: 53.3781,
    longitude: -1.4622,
    aliases: ['sheffield station', 'sheffield midland', 'shf'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access to all platforms via lifts and overbridge. Staffed assistance available.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/shf/',
    },
  },
  {
    id: 'LON',
    crs: 'LON',
    nlc: '1072',
    tiploc: 'LONDON',
    name: 'London Terminals (Station Group)',
    city: 'London',
    region: 'Greater London',
    kind: 'station_group',
    cityGroupId: 'LON',
    memberStationIds: ['STP', 'KGX', 'EUS', 'PAD', 'VIC', 'WAT'],
    nearbyStationIds: ['STP', 'KGX', 'EUS'],
    latitude: 51.5308,
    longitude: -0.1238,
    aliases: ['london', 'london terminals', 'london all stations', 'lon'],
    accessibility: {
      stepFreeAccess: 'unknown',
      assistanceAvailable: 'unknown',
      tactilePaving: 'unknown',
      accessibleToilets: 'unknown',
      summary: 'Station group covering multiple London termini. Select a specific terminal (e.g. St Pancras or King’s Cross) for verified platform accessibility.',
      source: 'Railunion Station Group Metadata',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/help-and-assistance/passenger-assist/',
    },
  },
  {
    id: 'STP',
    crs: 'STP',
    nlc: '1555',
    tiploc: 'STPANCS',
    name: 'London St Pancras International',
    city: 'London',
    region: 'Greater London',
    kind: 'individual',
    cityGroupId: 'LON',
    memberStationIds: [],
    nearbyStationIds: ['KGX', 'EUS'],
    latitude: 51.5319,
    longitude: -0.1263,
    aliases: ['st pancras', 'london st pancras', 'stp', 'pancras'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access across concourse and domestic EMR/Southeastern platforms via lifts.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/stp/',
    },
  },
  {
    id: 'KGX',
    crs: 'KGX',
    nlc: '6121',
    tiploc: 'KNGX',
    name: "London King's Cross",
    city: 'London',
    region: 'Greater London',
    kind: 'individual',
    cityGroupId: 'LON',
    memberStationIds: [],
    nearbyStationIds: ['STP', 'EUS'],
    latitude: 51.5308,
    longitude: -0.1238,
    aliases: ['kings cross', "king's cross", 'london kings cross', 'kgx'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free throughout main concourse and platforms 0–11. Changing Places facility available.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/kgx/',
    },
  },
  {
    id: 'EUS',
    crs: 'EUS',
    nlc: '1444',
    tiploc: 'EUSTON',
    name: 'London Euston',
    city: 'London',
    region: 'Greater London',
    kind: 'individual',
    cityGroupId: 'LON',
    memberStationIds: [],
    nearbyStationIds: ['STP', 'KGX'],
    latitude: 51.5282,
    longitude: -0.1337,
    aliases: ['euston', 'london euston', 'eus'],
    accessibility: {
      stepFreeAccess: 'partial',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access via ramps to main platforms; Underground interchange has partial step-free limits.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/eus/',
    },
  },
  {
    id: 'PAD',
    crs: 'PAD',
    nlc: '3087',
    tiploc: 'PADTON',
    name: 'London Paddington',
    city: 'London',
    region: 'Greater London',
    kind: 'individual',
    cityGroupId: 'LON',
    memberStationIds: [],
    nearbyStationIds: ['VIC', 'EUS'],
    latitude: 51.5154,
    longitude: -0.1755,
    aliases: ['paddington', 'london paddington', 'pad'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access from street level to all mainline platforms and Elizabeth line.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/pad/',
    },
  },
  {
    id: 'EDB',
    crs: 'EDB',
    nlc: '9328',
    tiploc: 'EDINBUR',
    name: 'Edinburgh Waverley',
    city: 'Edinburgh',
    region: 'Scotland',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['YRK', 'INV'],
    latitude: 55.952,
    longitude: -3.1899,
    aliases: ['edinburgh', 'edinburgh waverley', 'waverley', 'edb'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access via Waverley Bridge and Market Street lifts to all mainline platforms.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/edb/',
    },
  },
  {
    id: 'YRK',
    crs: 'YRK',
    nlc: '8263',
    tiploc: 'YORK',
    name: 'York',
    city: 'York',
    region: 'North Yorkshire',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['DON', 'LDS', 'SHF'],
    latitude: 53.9579,
    longitude: -1.0931,
    aliases: ['york', 'york station', 'yrk'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access to all platforms via lifts and subway ramps.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/yrk/',
    },
  },
  {
    id: 'DON',
    crs: 'DON',
    nlc: '6535',
    tiploc: 'DONCSTR',
    name: 'Doncaster',
    city: 'Doncaster',
    region: 'South Yorkshire',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['SHF', 'YRK'],
    latitude: 53.5223,
    longitude: -1.1394,
    aliases: ['doncaster', 'don'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'unknown',
      accessibleToilets: 'yes',
      summary: 'Step-free access via lifts; tactile paving status unconfirmed in latest extract.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/don/',
    },
  },
  {
    id: 'DBY',
    crs: 'DBY',
    nlc: '1823',
    tiploc: 'DERBY',
    name: 'Derby',
    city: 'Derby',
    region: 'East Midlands',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['SHF', 'BHM'],
    latitude: 52.9162,
    longitude: -1.4631,
    aliases: ['derby', 'dby'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access to all platforms via main footbridge lifts.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/dby/',
    },
  },
  {
    id: 'MAN_GRP',
    crs: 'MAN',
    nlc: '2968',
    tiploc: 'MNCRGRP',
    name: 'Manchester Stations (City Group)',
    city: 'Manchester',
    region: 'Greater Manchester',
    kind: 'city_group',
    cityGroupId: 'MAN_GRP',
    memberStationIds: ['MAN', 'MCV'],
    nearbyStationIds: ['MAN', 'MCV'],
    latitude: 53.4774,
    longitude: -2.2309,
    aliases: ['manchester', 'manchester all stations', 'manchester group'],
    accessibility: {
      stepFreeAccess: 'unknown',
      assistanceAvailable: 'unknown',
      tactilePaving: 'unknown',
      accessibleToilets: 'unknown',
      summary: 'City group covering Manchester Piccadilly and Manchester Victoria. Choose a specific station for verified step-free details.',
      source: 'Railunion Station Group Metadata',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/help-and-assistance/passenger-assist/',
    },
  },
  {
    id: 'MAN',
    crs: 'MAN',
    nlc: '2968',
    tiploc: 'MNCRPIC',
    name: 'Manchester Piccadilly',
    city: 'Manchester',
    region: 'Greater Manchester',
    kind: 'individual',
    cityGroupId: 'MAN_GRP',
    memberStationIds: [],
    nearbyStationIds: ['MCV', 'SHF'],
    latitude: 53.4774,
    longitude: -2.2309,
    aliases: ['manchester piccadilly', 'piccadilly', 'man'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access throughout concourse and all 14 platforms.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/man/',
    },
  },
  {
    id: 'MCV',
    crs: 'MCV',
    nlc: '2970',
    tiploc: 'MNCRVIC',
    name: 'Manchester Victoria',
    city: 'Manchester',
    region: 'Greater Manchester',
    kind: 'individual',
    cityGroupId: 'MAN_GRP',
    memberStationIds: [],
    nearbyStationIds: ['MAN', 'LDS'],
    latitude: 53.4875,
    longitude: -2.2422,
    aliases: ['manchester victoria', 'mcv'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'unknown',
      accessibleToilets: 'yes',
      summary: 'Step-free access via footbridge lifts to platforms 1–6.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/mcv/',
    },
  },
  {
    id: 'LDS',
    crs: 'LDS',
    nlc: '8487',
    tiploc: 'LEEDS',
    name: 'Leeds',
    city: 'Leeds',
    region: 'West Yorkshire',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['SHF', 'YRK'],
    latitude: 53.7949,
    longitude: -1.5478,
    aliases: ['leeds', 'lds'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access via southern entrance and main concourse lifts.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/lds/',
    },
  },
  {
    id: 'BHM',
    crs: 'BHM',
    nlc: '1127',
    tiploc: 'BHAMNEW',
    name: 'Birmingham New Street',
    city: 'Birmingham',
    region: 'West Midlands',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['DBY', 'OXF'],
    latitude: 52.4778,
    longitude: -1.8989,
    aliases: ['birmingham', 'birmingham new street', 'bhm'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'yes',
      accessibleToilets: 'yes',
      summary: 'Step-free access to all platforms via escalators and lifts from Grand Central concourse.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/bhm/',
    },
  },
  {
    id: 'EXD',
    crs: 'EXD',
    nlc: '3410',
    tiploc: 'EXETRSD',
    name: 'Exeter St Davids',
    city: 'Exeter',
    region: 'Devon',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['PNZ', 'PAD'],
    latitude: 50.7292,
    longitude: -3.5436,
    aliases: ['exeter', 'exeter st davids', 'exd'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'unknown',
      accessibleToilets: 'yes',
      summary: 'Step-free access across platforms via lifts.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/exd/',
    },
  },
  {
    id: 'PNZ',
    crs: 'PNZ',
    nlc: '3550',
    tiploc: 'PENZANC',
    name: 'Penzance',
    city: 'Penzance',
    region: 'Cornwall',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['EXD', 'PAD'],
    latitude: 50.1219,
    longitude: -5.5326,
    aliases: ['penzance', 'cornwall', 'pnz'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'unknown',
      accessibleToilets: 'yes',
      summary: 'Terminus station with level concourse access to all platforms.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/pnz/',
    },
  },
  {
    id: 'INV',
    crs: 'INV',
    nlc: '9601',
    tiploc: 'INVRNSS',
    name: 'Inverness',
    city: 'Inverness',
    region: 'Scottish Highlands',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['EDB'],
    latitude: 57.4804,
    longitude: -4.2229,
    aliases: ['inverness', 'highlands', 'inv'],
    accessibility: {
      stepFreeAccess: 'full',
      assistanceAvailable: 'yes',
      tactilePaving: 'unknown',
      accessibleToilets: 'yes',
      summary: 'Level access from Station Square to platforms 1–7.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/inv/',
    },
  },
  {
    id: 'OXF',
    crs: 'OXF',
    nlc: '3131',
    tiploc: 'OXFD',
    name: 'Oxford',
    city: 'Oxford',
    region: 'Oxfordshire',
    kind: 'individual',
    cityGroupId: null,
    memberStationIds: [],
    nearbyStationIds: ['PAD', 'BHM'],
    latitude: 51.7535,
    longitude: -1.27,
    aliases: ['oxford', 'oxf'],
    accessibility: {
      stepFreeAccess: 'partial',
      assistanceAvailable: 'yes',
      tactilePaving: 'unknown',
      accessibleToilets: 'yes',
      summary: 'Step-free access to platforms 1–4; check local lift notices prior to travel.',
      source: 'National Rail Station Accessibility Catalogue (demonstration extract)',
      updatedAt: '2026-11-01T09:00:00Z',
      officialAssistanceUrl: 'https://www.nationalrail.co.uk/stations/oxf/',
    },
  },
];

const STATION_BY_ID = new Map(GB_STATIONS.map((s) => [s.id, s]));

export function getStationById(id: string): Station | null {
  return STATION_BY_ID.get(id) ?? null;
}

/**
 * Resolves a station or station group strictly without silently replacing a specific terminal
 * (e.g. STP is never silently rewritten to KGX).
 */
export function resolveStationSelection(id: string): {
  station: Station | null;
  expandedStationIds: string[];
  isGroup: boolean;
} {
  const station = getStationById(id);
  if (!station) {
    return { station: null, expandedStationIds: [], isGroup: false };
  }
  if (station.kind !== 'individual' && station.memberStationIds.length > 0) {
    return {
      station,
      expandedStationIds: station.memberStationIds,
      isGroup: true,
    };
  }
  return {
    station,
    expandedStationIds: [station.id],
    isGroup: false,
  };
}

export function lookupStations(rawQuery: string): StationLookupResult {
  const q = rawQuery.trim().toLowerCase();
  if (!q) {
    return {
      query: rawQuery,
      matchedStations: GB_STATIONS.slice(0, 8),
      nearbySuggestions: [],
      unresolvedPlaceNotice: null,
    };
  }

  const matched = GB_STATIONS.filter((st) => {
    return (
      st.id.toLowerCase() === q ||
      st.crs.toLowerCase() === q ||
      st.name.toLowerCase().includes(q) ||
      st.city.toLowerCase().includes(q) ||
      st.aliases.some((a) => a.includes(q))
    );
  });

  // Sort exact CRS / station group matches cleanly
  matched.sort((a, b) => {
    const aExact = a.crs.toLowerCase() === q || a.id.toLowerCase() === q ? 0 : 1;
    const bExact = b.crs.toLowerCase() === q || b.id.toLowerCase() === q ? 0 : 1;
    if (aExact !== bExact) return aExact - bExact;
    return a.name.localeCompare(b.name);
  });

  const nearbyIds = new Set<string>();
  for (const st of matched) {
    for (const n of st.nearbyStationIds) {
      if (!matched.some((m) => m.id === n)) {
        nearbyIds.add(n);
      }
    }
  }

  // Handle user-entered place names that aren't direct stations (e.g. "Peak District", "Bath", "Heathrow")
  let unresolvedPlaceNotice: string | null = null;
  const fallbackNearby: Station[] = [];
  if (matched.length === 0) {
    if (q.includes('peak') || q.includes('bakewell') || q.includes('chesterfield')) {
      unresolvedPlaceNotice = `"${rawQuery}" is a place name rather than a listed Railunion station. Nearest served stations shown below.`;
      ['SHF', 'DBY', 'MAN'].forEach((id) => {
        const s = getStationById(id);
        if (s) fallbackNearby.push(s);
      });
    } else if (q.includes('cornwall') || q.includes('st ives')) {
      unresolvedPlaceNotice = `"${rawQuery}" is a region/place name. Nearest served stations shown below.`;
      ['PNZ', 'EXD'].forEach((id) => {
        const s = getStationById(id);
        if (s) fallbackNearby.push(s);
      });
    } else {
      unresolvedPlaceNotice = `No station matched "${rawQuery}" in the Railunion demonstration dataset.`;
    }
  }

  const nearbySuggestions =
    fallbackNearby.length > 0
      ? fallbackNearby
      : Array.from(nearbyIds)
          .map((id) => getStationById(id))
          .filter((s): s is Station => s !== null);

  return {
    query: rawQuery,
    matchedStations: matched,
    nearbySuggestions,
    unresolvedPlaceNotice,
  };
}
