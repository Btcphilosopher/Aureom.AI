import { formatPence } from './timezone';
import type {
  ComparableOfferGroup,
  FareOffer,
  JourneyItinerary,
  JourneySearchResultItem,
} from './types';

export type SortMode =
  | 'recommended'
  | 'lowest_comparable_total'
  | 'earliest_arrival'
  | 'shortest_duration'
  | 'fewest_changes';

export const RECOMMENDED_RANKING_RULE =
  'Recommended score = lowest complete comparable fare + £0.25 per minute of journey time + £4.00 per interchange + £3.00 when bound to a single booked train. Sponsored placements are always excluded from this ranking.';

function getFlexibilityLabel(offer: FareOffer): string {
  if (offer.train_binding === 'booked_train_only') return 'Booked train only';
  if (offer.ticket_category === 'anytime') return 'Anytime flexible';
  if (offer.ticket_category === 'off_peak' || offer.ticket_category === 'return_product') {
    return 'Off-Peak flexible';
  }
  return 'Conditional flexibility';
}

export function groupComparableOffers(offers: FareOffer[]): ComparableOfferGroup[] {
  const buckets = new Map<string, FareOffer[]>();

  for (const offer of offers) {
    const list = buckets.get(offer.equivalence_key) ?? [];
    list.push(offer);
    buckets.set(offer.equivalence_key, list);
  }

  const groups: ComparableOfferGroup[] = [];
  for (const [equivalenceKey, groupOffers] of buckets.entries()) {
    const sorted = [...groupOffers].sort((a, b) => {
      // Complete offers strictly precede incomplete offers
      if (a.fee_completeness === 'complete' && b.fee_completeness !== 'complete') return -1;
      if (a.fee_completeness !== 'complete' && b.fee_completeness === 'complete') return 1;
      const ap = a.total_known_payable_pence ?? Number.MAX_SAFE_INTEGER;
      const bp = b.total_known_payable_pence ?? Number.MAX_SAFE_INTEGER;
      return ap - bp;
    });

    const completeOffers = sorted.filter(
      (o) => o.fee_completeness === 'complete' && o.total_known_payable_pence !== null
    );
    const lowestComplete = completeOffers[0] ?? null;
    const sample = sorted[0];

    groups.push({
      equivalenceKey,
      ticketProduct: sample.ticket_product,
      ticketCategory: sample.ticket_category,
      travelClass: sample.travel_class,
      trainBinding: sample.train_binding,
      flexibilityLabel: getFlexibilityLabel(sample),
      offers: sorted,
      lowestComparableOfferId: lowestComplete?.offer_id ?? null,
      lowestComparableTotalPence: lowestComplete?.total_known_payable_pence ?? null,
      hasIncompleteFeesOnly: completeOffers.length === 0,
      plainDifferenceNote: null,
    });
  }

  // Sort groups by lowest comparable total (complete first)
  groups.sort((a, b) => {
    const ap = a.lowestComparableTotalPence ?? Number.MAX_SAFE_INTEGER;
    const bp = b.lowestComparableTotalPence ?? Number.MAX_SAFE_INTEGER;
    return ap - bp;
  });

  // Add plain-language structured difference explanations ONLY when structured conditions support them
  const flexibleGroup = groups.find(
    (g) =>
      g.trainBinding === 'flexible_any_permitted' &&
      g.lowestComparableTotalPence !== null &&
      !g.hasIncompleteFeesOnly
  );

  for (const group of groups) {
    if (
      group.trainBinding === 'booked_train_only' &&
      group.lowestComparableTotalPence !== null &&
      flexibleGroup &&
      flexibleGroup.lowestComparableTotalPence !== null
    ) {
      const diff = flexibleGroup.lowestComparableTotalPence - group.lowestComparableTotalPence;
      if (diff > 0) {
        group.plainDifferenceNote = `${formatPence(diff)} less than ${flexibleGroup.ticketProduct}, but valid only on the selected train.`;
      }
    } else if (group.hasIncompleteFeesOnly) {
      group.plainDifferenceNote =
        'Mandatory seller fee unknown — excluded from "Cheapest" comparison until verified.';
    }
  }

  return groups;
}

export function buildJourneyResults(
  itineraries: JourneyItinerary[],
  allOffers: FareOffer[]
): JourneySearchResultItem[] {
  const offersByJourney = new Map<string, FareOffer[]>();
  for (const offer of allOffers) {
    const list = offersByJourney.get(offer.journey_reference) ?? [];
    list.push(offer);
    offersByJourney.set(offer.journey_reference, list);
  }

  return itineraries.map((itinerary) => {
    const journeyOffers = offersByJourney.get(itinerary.journeyId) ?? [];
    const offerGroups = groupComparableOffers(journeyOffers);

    const completeTotals = journeyOffers
      .filter((o) => !o.is_sponsored && o.fee_completeness === 'complete' && o.total_known_payable_pence !== null)
      .map((o) => ({
        pence: o.total_known_payable_pence as number,
        binding: o.train_binding,
      }));

    completeTotals.sort((a, b) => a.pence - b.pence);
    const lowestComplete = completeTotals[0] ?? null;

    let recommendedScorePence: number | null = null;
    let recommendedExplanation = 'No complete comparable fare available for ranking.';

    if (lowestComplete) {
      const durationPenalty = itinerary.durationMinutes * 25;
      const changePenalty = itinerary.changesCount * 400;
      const bindingPenalty = lowestComplete.binding === 'booked_train_only' ? 300 : 0;
      recommendedScorePence = lowestComplete.pence + durationPenalty + changePenalty + bindingPenalty;
      recommendedExplanation = `Score ${formatPence(recommendedScorePence)} (${formatPence(lowestComplete.pence)} fare + ${formatPence(durationPenalty)} for ${itinerary.durationMinutes}m + ${formatPence(changePenalty)} for ${itinerary.changesCount} change${itinerary.changesCount === 1 ? '' : 's'}${bindingPenalty > 0 ? ' + £3.00 train-specific restriction' : ''}).`;
    }

    return {
      itinerary,
      offerGroups,
      allOffers: journeyOffers,
      lowestCompletePricePence: lowestComplete?.pence ?? null,
      recommendedScorePence,
      recommendedExplanation,
    };
  });
}

export function sortJourneyResults(
  items: JourneySearchResultItem[],
  sortBy: SortMode
): JourneySearchResultItem[] {
  const copy = [...items];
  copy.sort((a, b) => {
    switch (sortBy) {
      case 'lowest_comparable_total': {
        const ap = a.lowestCompletePricePence ?? Number.MAX_SAFE_INTEGER;
        const bp = b.lowestCompletePricePence ?? Number.MAX_SAFE_INTEGER;
        if (ap !== bp) return ap - bp;
        return a.itinerary.durationMinutes - b.itinerary.durationMinutes;
      }
      case 'earliest_arrival':
        return a.itinerary.arrivalUtc.localeCompare(b.itinerary.arrivalUtc);
      case 'shortest_duration':
        if (a.itinerary.durationMinutes !== b.itinerary.durationMinutes) {
          return a.itinerary.durationMinutes - b.itinerary.durationMinutes;
        }
        return (a.lowestCompletePricePence ?? Number.MAX_SAFE_INTEGER) - (b.lowestCompletePricePence ?? Number.MAX_SAFE_INTEGER);
      case 'fewest_changes':
        if (a.itinerary.changesCount !== b.itinerary.changesCount) {
          return a.itinerary.changesCount - b.itinerary.changesCount;
        }
        return a.itinerary.durationMinutes - b.itinerary.durationMinutes;
      case 'recommended':
      default: {
        const as = a.recommendedScorePence ?? Number.MAX_SAFE_INTEGER;
        const bs = b.recommendedScorePence ?? Number.MAX_SAFE_INTEGER;
        if (as !== bs) return as - bs;
        return a.itinerary.departureUtc.localeCompare(b.itinerary.departureUtc);
      }
    }
  });
  return copy;
}
