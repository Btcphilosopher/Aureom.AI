import crypto from 'crypto';
import { getCachedSearchResponse, setCachedSearchResponse } from './cache';
import { buildJourneyResults, RECOMMENDED_RANKING_RULE } from './comparison';
import { ALL_PROVIDERS } from './providers';
import { validateSearchInput } from './timezone';
import type {
  FareOffer,
  JourneyItinerary,
  ProviderStatusReport,
  SearchInput,
  SearchResponse,
} from './types';

export async function executeJourneySearch(
  input: SearchInput,
  opts?: { bypassCache?: boolean }
): Promise<{ ok: true; data: SearchResponse } | { ok: false; errors: string[] }> {
  const validation = validateSearchInput(input);
  if (!validation.valid) {
    return { ok: false, errors: validation.errors };
  }

  if (!opts?.bypassCache) {
    const cached = getCachedSearchResponse(input);
    if (cached) {
      return { ok: true, data: cached };
    }
  }

  const searchTimeUtc = new Date();
  const searchReference = `SR-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;

  // Use primary timetable fixture from Pennine (or first healthy provider) so both providers quote on matching itineraries
  const outwardItineraries = await ALL_PROVIDERS[0].searchJourneys(input, 'outward', searchTimeUtc);
  const returnItineraries =
    input.journeyType === 'return'
      ? await ALL_PROVIDERS[0].searchJourneys(input, 'return', searchTimeUtc)
      : [];

  const allItineraries: JourneyItinerary[] = [...outwardItineraries, ...returnItineraries];

  const providerCalls = await Promise.all(
    ALL_PROVIDERS.map((provider) =>
      provider.fetchFareOffers(allItineraries, input, searchTimeUtc)
    )
  );

  const allOffers: FareOffer[] = [];
  const providerReports: ProviderStatusReport[] = [];

  for (const res of providerCalls) {
    allOffers.push(...res.offers);
    providerReports.push(res.statusReport);
  }

  const outwardOffers = allOffers.filter((o) =>
    outwardItineraries.some((i) => i.journeyId === o.journey_reference)
  );
  const returnOffers = allOffers.filter((o) =>
    returnItineraries.some((i) => i.journeyId === o.journey_reference)
  );

  const outwardResults = buildJourneyResults(outwardItineraries, outwardOffers);
  const returnResults = buildJourneyResults(returnItineraries, returnOffers);

  const respondingWithOffers = providerReports.filter((p) => p.status === 'healthy' && p.offersReturned > 0).length;
  const isPartial = respondingWithOffers < ALL_PROVIDERS.length;

  const coverageDisclosure = isPartial
    ? `Partial provider coverage: ${respondingWithOffers} of ${ALL_PROVIDERS.length} configured providers returned offers. This is not an exhaustive market comparison.`
    : `All ${ALL_PROVIDERS.length} demonstration providers responded. Results cover Railunion’s connected demonstration fixtures only, not the entire GB retail market.`;

  const response: SearchResponse = {
    searchReference,
    input,
    directionResults: {
      outward: outwardResults,
      return: returnResults,
    },
    returnCombinationsNote: {
      supportsSingleAndReturnProducts: true,
      splitTicketingStatus: 'deferred',
      splitTicketingReason:
        'Split-ticket combinations are deferred until an authorised Rail Delivery Group (RDG) fare-routing validator is connected. Railunion does not invent route validity rules.',
    },
    providerReports,
    coverageSummary: {
      isPartial,
      respondingProviders: respondingWithOffers,
      totalConfiguredProviders: ALL_PROVIDERS.length,
      disclosure: coverageDisclosure,
    },
    cacheMetadata: {
      cacheKeyHash: '',
      cacheHit: false,
      cachedAtUtc: searchTimeUtc.toISOString(),
      expiresAtUtc: searchTimeUtc.toISOString(),
      ttlSeconds: 120,
    },
    rankingRuleDisclosure: RECOMMENDED_RANKING_RULE,
    demonstrationNotice:
      'Independent concept demonstration using fictional GB service times and illustrative GBP prices.',
  };

  const stamped = setCachedSearchResponse(input, response);
  return { ok: true, data: stamped };
}
