import { NextRequest, NextResponse } from 'next/server';
import { checkRateLimit, redactSensitiveForLog } from '@/lib/railunion/security';
import { executeJourneySearch } from '@/lib/railunion/search-service';
import type { SearchInput } from '@/lib/railunion/types';

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`search:${ip}`, 60, 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Search rate limit exceeded. Please pause briefly before searching again.' },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON request body.' }, { status: 400 });
  }

  const input = body as SearchInput;
  if (!input || typeof input !== 'object') {
    return NextResponse.json({ error: 'Search payload is required.' }, { status: 400 });
  }

  const result = await executeJourneySearch({
    journeyType: input.journeyType === 'return' ? 'return' : 'one_way',
    originId: String(input.originId ?? ''),
    destinationId: String(input.destinationId ?? ''),
    originEnteredText: input.originEnteredText ? String(input.originEnteredText) : undefined,
    destinationEnteredText: input.destinationEnteredText ? String(input.destinationEnteredText) : undefined,
    outwardDate: String(input.outwardDate ?? ''),
    outwardTime: String(input.outwardTime ?? ''),
    outwardTimeMode: input.outwardTimeMode === 'arrive_by' ? 'arrive_by' : 'depart_at',
    returnDate: input.returnDate ? String(input.returnDate) : undefined,
    returnTime: input.returnTime ? String(input.returnTime) : undefined,
    returnTimeMode: input.returnTimeMode === 'arrive_by' ? 'arrive_by' : 'depart_at',
    adults: Number(input.adults ?? 1),
    children: Number(input.children ?? 0),
    railcards: Array.isArray(input.railcards) ? input.railcards : [],
    travelClass: input.travelClass === 'first' ? 'first' : 'standard',
    scenarioMode: input.scenarioMode ?? 'normal',
  });

  if (!result.ok) {
    console.info('railunion.search.validation_failed', redactSensitiveForLog({ errors: result.errors }));
    return NextResponse.json({ error: result.errors[0], errors: result.errors }, { status: 400 });
  }

  return NextResponse.json(result.data);
}
