import { NextResponse } from 'next/server';
import { ALL_PROVIDERS } from '@/lib/railunion/providers';

export async function GET() {
  const reports = ALL_PROVIDERS.map((p) => p.getHealthAndLimitations());
  return NextResponse.json({
    providers: reports,
    checkedAtUtc: new Date().toISOString(),
  });
}
