import { NextRequest, NextResponse } from 'next/server';
import { extractSessionFromRequest, verifyCsrfHeaderOrOrigin } from '@/lib/railunion/security';
import {
  addSavedSearch,
  createPriceAlert,
  getUserWorkspaceData,
  removePriceAlert,
  removeSavedItinerary,
  removeSavedSearch,
  saveItineraryForUser,
  toggleFavouriteStation,
} from '@/lib/railunion/store';
import type { FareOffer, JourneyItinerary, SearchInput } from '@/lib/railunion/types';

export async function POST(req: NextRequest) {
  if (!verifyCsrfHeaderOrOrigin(req)) {
    return NextResponse.json({ error: 'Missing required request verification header.' }, { status: 403 });
  }
  const session = extractSessionFromRequest(req);
  if (!session) {
    return NextResponse.json({ error: 'Please sign in to save journeys and alerts.' }, { status: 401 });
  }

  let body: {
    kind?: 'search' | 'station' | 'itinerary' | 'alert';
    label?: string;
    input?: SearchInput;
    stationId?: string;
    stationName?: string;
    crs?: string;
    itinerary?: JourneyItinerary;
    snapshotOffer?: FareOffer | null;
    note?: string;
    targetMaxTotalPence?: number;
    observedLowestPence?: number | null;
  };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON request body.' }, { status: 400 });
  }

  if (body.kind === 'search' && body.input) {
    addSavedSearch(session.uid, body.label || 'Saved rail search', body.input);
    return NextResponse.json({ workspace: getUserWorkspaceData(session.uid) }, { status: 201 });
  }

  if (body.kind === 'station' && body.stationId && body.stationName && body.crs) {
    const result = toggleFavouriteStation(session.uid, body.stationId, body.stationName, body.crs);
    return NextResponse.json({
      action: result.action,
      workspace: getUserWorkspaceData(session.uid),
    });
  }

  if (body.kind === 'itinerary' && body.itinerary) {
    saveItineraryForUser(
      session.uid,
      body.itinerary,
      body.snapshotOffer ?? null,
      body.note ?? ''
    );
    return NextResponse.json({ workspace: getUserWorkspaceData(session.uid) }, { status: 201 });
  }

  if (body.kind === 'alert' && body.input && typeof body.targetMaxTotalPence === 'number') {
    createPriceAlert(
      session.uid,
      body.label || 'Fare alert',
      body.input,
      Math.max(100, Math.round(body.targetMaxTotalPence)),
      body.observedLowestPence ?? null
    );
    return NextResponse.json({ workspace: getUserWorkspaceData(session.uid) }, { status: 201 });
  }

  return NextResponse.json({ error: 'Unsupported save request payload.' }, { status: 400 });
}

export async function DELETE(req: NextRequest) {
  if (!verifyCsrfHeaderOrOrigin(req)) {
    return NextResponse.json({ error: 'Missing required request verification header.' }, { status: 403 });
  }
  const session = extractSessionFromRequest(req);
  if (!session) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }

  const kind = req.nextUrl.searchParams.get('kind');
  const id = req.nextUrl.searchParams.get('id');
  if (!kind || !id) {
    return NextResponse.json({ error: 'Missing kind or id parameter.' }, { status: 400 });
  }

  let removed = false;
  if (kind === 'search') removed = removeSavedSearch(session.uid, id);
  else if (kind === 'itinerary') removed = removeSavedItinerary(session.uid, id);
  else if (kind === 'alert') removed = removePriceAlert(session.uid, id);

  if (!removed) {
    return NextResponse.json({ error: 'Saved item not found for this account.' }, { status: 404 });
  }

  return NextResponse.json({ workspace: getUserWorkspaceData(session.uid) });
}
