import { NextRequest, NextResponse } from 'next/server';
import { executeJourneySearch } from '@/lib/railunion/search-service';
import { extractSessionFromRequest, verifyCsrfHeaderOrOrigin } from '@/lib/railunion/security';
import { getUserWorkspaceData, updatePriceAlertObservation } from '@/lib/railunion/store';

export async function POST(req: NextRequest) {
  if (!verifyCsrfHeaderOrOrigin(req)) {
    return NextResponse.json({ error: 'Missing required request verification header.' }, { status: 403 });
  }
  const session = extractSessionFromRequest(req);
  if (!session) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }

  const workspace = getUserWorkspaceData(session.uid);
  for (const alert of workspace.priceAlerts) {
    const res = await executeJourneySearch(alert.input, { bypassCache: true });
    if (res.ok) {
      const prices = res.data.directionResults.outward
        .map((r) => r.lowestCompletePricePence)
        .filter((p): p is number => p !== null);
      const lowest = prices.length > 0 ? Math.min(...prices) : null;
      updatePriceAlertObservation(session.uid, alert.id, lowest);
    }
  }

  return NextResponse.json({
    checkedAtUtc: new Date().toISOString(),
    workspace: getUserWorkspaceData(session.uid),
  });
}
