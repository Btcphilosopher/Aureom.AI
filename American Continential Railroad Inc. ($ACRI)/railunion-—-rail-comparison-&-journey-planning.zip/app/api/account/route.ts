import { NextRequest, NextResponse } from 'next/server';
import {
  checkRateLimit,
  extractSessionFromRequest,
  redactSensitiveForLog,
  SESSION_COOKIE_NAME,
  signSessionToken,
  verifyCsrfHeaderOrOrigin,
} from '@/lib/railunion/security';
import {
  authenticateUser,
  deleteUserAccount,
  findUserById,
  getDemoUser,
  getUserWorkspaceData,
  registerUser,
} from '@/lib/railunion/store';

function setSessionCookie(res: NextResponse, token: string) {
  res.cookies.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    partitioned: true,
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function GET(req: NextRequest) {
  const session = extractSessionFromRequest(req);
  if (!session) {
    return NextResponse.json({ authenticated: false, user: null, workspace: null });
  }
  const user = findUserById(session.uid);
  if (!user) {
    return NextResponse.json({ authenticated: false, user: null, workspace: null });
  }
  return NextResponse.json({
    authenticated: true,
    user: {
      id: user.id,
      email: user.email,
      displayName: user.displayName,
      createdAtUtc: user.createdAtUtc,
    },
    workspace: getUserWorkspaceData(user.id),
  });
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`auth:${ip}`, 30, 60_000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Too many authentication requests.' }, { status: 429 });
  }

  let body: {
    action?: 'login' | 'register' | 'demo' | 'logout';
    email?: string;
    password?: string;
    displayName?: string;
  };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON request body.' }, { status: 400 });
  }

  if (body.action === 'logout') {
    const res = NextResponse.json({ authenticated: false, user: null, workspace: null });
    res.cookies.set(SESSION_COOKIE_NAME, '', {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      partitioned: true,
      path: '/',
      maxAge: 0,
    });
    return res;
  }

  if (body.action === 'demo') {
    const demoUser = getDemoUser();
    const token = signSessionToken(demoUser.id, demoUser.email);
    const res = NextResponse.json({
      authenticated: true,
      token,
      user: {
        id: demoUser.id,
        email: demoUser.email,
        displayName: demoUser.displayName,
        createdAtUtc: demoUser.createdAtUtc,
      },
      workspace: getUserWorkspaceData(demoUser.id),
    });
    setSessionCookie(res, token);
    return res;
  }

  const email = String(body.email ?? '').trim();
  const password = String(body.password ?? '');

  if (!email || !email.includes('@') || password.length < 8) {
    return NextResponse.json(
      { error: 'Enter a valid email address and a password of at least 8 characters.' },
      { status: 400 }
    );
  }

  if (body.action === 'register') {
    try {
      const user = registerUser(email, password, String(body.displayName ?? ''));
      const token = signSessionToken(user.id, user.email);
      console.info('railunion.account.registered', redactSensitiveForLog({ userId: user.id, email: user.email }));
      const res = NextResponse.json(
        {
          authenticated: true,
          token,
          user: {
            id: user.id,
            email: user.email,
            displayName: user.displayName,
            createdAtUtc: user.createdAtUtc,
          },
          workspace: getUserWorkspaceData(user.id),
        },
        { status: 201 }
      );
      setSessionCookie(res, token);
      return res;
    } catch (err) {
      return NextResponse.json(
        { error: err instanceof Error ? err.message : 'Unable to register account.' },
        { status: 409 }
      );
    }
  }

  // Login
  const user = authenticateUser(email, password);
  if (!user) {
    return NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 });
  }
  const token = signSessionToken(user.id, user.email);
  const res = NextResponse.json({
    authenticated: true,
    token,
    user: {
      id: user.id,
      email: user.email,
      displayName: user.displayName,
      createdAtUtc: user.createdAtUtc,
    },
    workspace: getUserWorkspaceData(user.id),
  });
  setSessionCookie(res, token);
  return res;
}

export async function DELETE(req: NextRequest) {
  if (!verifyCsrfHeaderOrOrigin(req)) {
    return NextResponse.json({ error: 'Missing required request verification header.' }, { status: 403 });
  }
  const session = extractSessionFromRequest(req);
  if (!session) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }
  const deleted = deleteUserAccount(session.uid);
  if (!deleted) {
    return NextResponse.json({ error: 'Account not found.' }, { status: 404 });
  }
  const res = NextResponse.json({ deleted: true });
  res.cookies.set(SESSION_COOKIE_NAME, '', {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    partitioned: true,
    path: '/',
    maxAge: 0,
  });
  return res;
}
