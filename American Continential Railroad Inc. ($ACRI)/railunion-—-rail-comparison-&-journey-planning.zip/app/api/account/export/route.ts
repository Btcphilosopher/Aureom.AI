import { NextRequest, NextResponse } from 'next/server';
import { extractSessionFromRequest } from '@/lib/railunion/security';
import { exportUserData } from '@/lib/railunion/store';

export async function GET(req: NextRequest) {
  const session = extractSessionFromRequest(req);
  if (!session) {
    return NextResponse.json({ error: 'Sign in required to export account data.' }, { status: 401 });
  }

  const exported = exportUserData(session.uid);
  if (!exported) {
    return NextResponse.json({ error: 'Account not found.' }, { status: 404 });
  }

  return new NextResponse(JSON.stringify(exported, null, 2), {
    status: 200,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Disposition': 'attachment; filename="railunion-account-export.json"',
    },
  });
}
