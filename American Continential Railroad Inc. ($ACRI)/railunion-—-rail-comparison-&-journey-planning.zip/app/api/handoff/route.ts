import { NextRequest, NextResponse } from 'next/server';
import { getProviderById } from '@/lib/railunion/providers';
import { checkRateLimit, validateSellerHandoffUrl } from '@/lib/railunion/security';
import { getHandoffByReference, recordHandoff } from '@/lib/railunion/store';
import type { FareOffer } from '@/lib/railunion/types';

export async function GET(req: NextRequest) {
  const ref = req.nextUrl.searchParams.get('ref');
  if (!ref) {
    return NextResponse.json({ error: 'Missing handoff reference.' }, { status: 400 });
  }
  const record = getHandoffByReference(ref);
  if (!record) {
    return NextResponse.json({ error: 'Handoff reference not found.' }, { status: 404 });
  }
  return NextResponse.json(record);
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`handoff:${ip}`, 40, 60_000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Too many handoff requests.' }, { status: 429 });
  }

  let body: {
    offer?: FareOffer;
    itinerarySummary?: string;
    acceptedMaterialChange?: boolean;
    requiresCustomerAcceptance?: boolean;
    targetUrlOverride?: string;
  };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON request body.' }, { status: 400 });
  }

  const offer = body.offer;
  if (!offer || !offer.offer_id || !offer.provider_id) {
    return NextResponse.json({ error: 'Valid offer payload is required.' }, { status: 400 });
  }

  if (body.requiresCustomerAcceptance && !body.acceptedMaterialChange) {
    return NextResponse.json(
      { error: 'Please accept the updated fare or condition change before continuing to the seller.' },
      { status: 400 }
    );
  }

  // Open-redirect guard: if a custom URL is supplied, reject non-allowlisted hosts explicitly
  if (body.targetUrlOverride) {
    const check = validateSellerHandoffUrl(body.targetUrlOverride);
    if (!check.valid) {
      return NextResponse.json({ error: check.reason ?? 'Blocked untrusted seller redirect URL.' }, { status: 400 });
    }
  }

  const provider = getProviderById(offer.provider_id);
  if (!provider) {
    return NextResponse.json({ error: 'Unknown provider.' }, { status: 404 });
  }

  const handoff = await provider.createSellerHandoff(
    offer,
    body.itinerarySummary || offer.journey_reference,
    Boolean(body.acceptedMaterialChange)
  );

  recordHandoff(handoff);
  return NextResponse.json(handoff, { status: 201 });
}
