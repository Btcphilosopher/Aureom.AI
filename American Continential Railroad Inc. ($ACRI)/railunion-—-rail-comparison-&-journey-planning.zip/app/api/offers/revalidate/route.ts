import { NextRequest, NextResponse } from 'next/server';
import { getProviderById } from '@/lib/railunion/providers';
import { checkRateLimit } from '@/lib/railunion/security';
import type { DemoScenarioMode, FareOffer } from '@/lib/railunion/types';

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`revalidate:${ip}`, 60, 60_000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Rate limit exceeded.' }, { status: 429 });
  }

  let body: { offer?: FareOffer; scenarioMode?: DemoScenarioMode };
  try {
    body = (await req.json()) as { offer?: FareOffer; scenarioMode?: DemoScenarioMode };
  } catch {
    return NextResponse.json({ error: 'Invalid JSON request body.' }, { status: 400 });
  }

  const offer = body.offer;
  if (!offer || !offer.offer_id || !offer.provider_id) {
    return NextResponse.json({ error: 'A valid fare offer is required for revalidation.' }, { status: 400 });
  }

  const provider = getProviderById(offer.provider_id);
  if (!provider) {
    return NextResponse.json({ error: 'Unknown provider.' }, { status: 404 });
  }

  const result = await provider.revalidateOffer(offer, body.scenarioMode ?? 'normal');
  return NextResponse.json(result);
}
