import { NextRequest, NextResponse } from 'next/server';
import { GB_STATIONS, lookupStations } from '@/lib/railunion/stations';
import { checkRateLimit } from '@/lib/railunion/security';

export async function GET(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`stations:${ip}`, 120, 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many station lookup requests. Please wait a moment and try again.' },
      { status: 429 }
    );
  }

  const q = req.nextUrl.searchParams.get('q') ?? '';
  if (!q.trim()) {
    return NextResponse.json({
      query: '',
      matchedStations: GB_STATIONS,
      nearbySuggestions: [],
      unresolvedPlaceNotice: null,
    });
  }

  const result = lookupStations(q);
  return NextResponse.json(result);
}
