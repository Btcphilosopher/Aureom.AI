import RailunionApp from '@/components/railunion/RailunionApp';
import { GB_STATIONS } from '@/lib/railunion/stations';
import { getDefaultLondonSearchDate } from '@/lib/railunion/timezone';

export default function HomePage() {
  const defaultOutwardDate = getDefaultLondonSearchDate(2);
  return <RailunionApp initialStations={GB_STATIONS} defaultOutwardDate={defaultOutwardDate} />;
}
