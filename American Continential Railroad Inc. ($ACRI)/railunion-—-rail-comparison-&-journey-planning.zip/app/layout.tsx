import type { Metadata } from 'next';
import { Plus_Jakarta_Sans, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-plus-jakarta',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-jetbrains-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Railunion — Rail Comparison & Journey Planning',
  description:
    'Independent Great Britain rail comparison and journey planning concept. Compare trains, inspect ticket restrictions, revalidate fares, and continue to an authorised seller.',
  openGraph: {
    title: 'Railunion — Rail Comparison & Journey Planning',
    description:
      'Compare Great Britain train journeys, inspect ticket conditions, and continue to an authorised seller.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Railunion — Rail Comparison & Journey Planning',
    description:
      'Compare Great Britain train journeys, inspect ticket conditions, and continue to an authorised seller.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB" className={`${plusJakarta.variable} ${jetbrainsMono.variable}`}>
      <body className="min-h-screen bg-[#F4F7FA] text-[#0B1E36] antialiased" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
