import Link from 'next/link';
import { ArrowLeft, CheckCircle2, ShieldAlert, TrainFront } from 'lucide-react';
import { getHandoffByReference } from '@/lib/railunion/store';
import { formatPence } from '@/lib/railunion/timezone';

export default async function SimulatedSellerHandoffPage({
  params,
}: {
  params: Promise<{ ref: string }>;
}) {
  const { ref } = await params;
  const record = getHandoffByReference(decodeURIComponent(ref));

  return (
    <main className="min-h-screen bg-[#F4F7FA] py-12 px-4 sm:px-6">
      <div className="max-w-2xl mx-auto space-y-6">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm font-semibold text-[#0B1E36] hover:text-[#008C77]"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Railunion comparison</span>
        </Link>

        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
          <div className="bg-[#0B1E36] text-white px-6 py-5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <TrainFront className="w-6 h-6 text-[#EF4B42]" />
              <div>
                <div className="text-xs text-[#CFF7EE] font-medium">
                  Simulated Authorised Seller Handoff
                </div>
                <h1 className="text-lg font-bold">
                  {record ? record.sellerName : 'Seller handoff reference not found'}
                </h1>
              </div>
            </div>
            <span className="font-mono text-xs text-slate-300">{ref}</span>
          </div>

          <div className="p-6 space-y-5">
            {!record ? (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-950">
                No recorded handoff matched reference <span className="font-mono">{ref}</span>. Start a new comparison on Railunion to revalidate an offer before continuing to a seller.
              </div>
            ) : (
              <>
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                  <div className="text-sm text-emerald-950 space-y-1">
                    <div className="font-bold">{record.disclaimer}</div>
                    <p className="text-xs text-emerald-900">
                      Handoff validated against the Railunion seller allowlist ({record.sellerHost}).
                    </p>
                  </div>
                </div>

                <dl className="divide-y divide-slate-100 text-sm">
                  <div className="py-2.5 flex justify-between gap-4">
                    <dt className="text-slate-500">Journey</dt>
                    <dd className="font-semibold text-[#0B1E36] text-right">{record.journeySummary}</dd>
                  </div>
                  <div className="py-2.5 flex justify-between gap-4">
                    <dt className="text-slate-500">Ticket product</dt>
                    <dd className="font-semibold text-[#0B1E36]">
                      {record.ticketProduct} ({record.travelClass === 'first' ? 'First Class' : 'Standard'})
                    </dd>
                  </div>
                  <div className="py-2.5 flex justify-between gap-4">
                    <dt className="text-slate-500">Passengers</dt>
                    <dd className="font-semibold text-[#0B1E36]">{record.passengerSummary}</dd>
                  </div>
                  <div className="py-2.5 flex justify-between gap-4">
                    <dt className="text-slate-500">Revalidated payable total</dt>
                    <dd className="font-bold text-[#0B1E36] tabular-nums">
                      {record.acceptedTotalPence === null
                        ? 'Fee undisclosed by seller'
                        : `${formatPence(record.acceptedTotalPence)} (${record.currency})`}
                    </dd>
                  </div>
                  <div className="py-2.5 flex justify-between gap-4">
                    <dt className="text-slate-500">Allowlisted target URL</dt>
                    <dd className="font-mono text-xs text-slate-600 break-all text-right">
                      {record.validatedSellerUrl}
                    </dd>
                  </div>
                </dl>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-2.5 text-xs text-slate-700">
                  <ShieldAlert className="w-4 h-4 text-[#EF4B42] shrink-0 mt-0.5" />
                  <p>
                    <strong>Demonstration boundary:</strong> This screen represents the external authorised seller checkout after handoff. Railunion has not collected payment, issued a ticket, or booked a seat reservation.
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
