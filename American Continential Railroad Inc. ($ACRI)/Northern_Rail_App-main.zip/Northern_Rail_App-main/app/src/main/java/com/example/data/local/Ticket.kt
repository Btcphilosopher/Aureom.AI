package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fromStation: String,
    val toStation: String,
    val date: String,
    val time: String,
    val price: Double,
    val status: String, // "ACTIVE", "EXPIRED"
    val classType: String, // "Standard", "First Class"
    val ticketType: String, // "Single", "Return", "Season"
    val qrCodeData: String,
    val loyaltyPoints: Int = 10,
    val timestamp: Long = System.currentTimeMillis()
)
