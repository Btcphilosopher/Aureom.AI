package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hypermodernist "Northern" Design Palette
val GraphiteDark = Color(0xFF0F1113)
val GraphiteMedium = Color(0xFF141517)
val GraphiteLight = Color(0xFF1E2025)

val ElectricBlue = Color(0xFF3B82F6)       // Primary action & active state (Bento Blue)
val DeepElectricBlue = Color(0xFF2563EB)   // Medium/darker blue
val EmeraldGreen = Color(0xFF10B981)       // Sustainability & on-time stats (Bento Green)
val SilverMetallic = Color(0xFF94A3B8)     // Body/Label text (Slate 400)
val WhiteGlass = Color(0x0DFFFFFF)         // 5% White Glassmorphic / Bento panel background
val GlassBorder = Color(0x1AFFFFFF)        // 10% White border

// Retrofitting legacy defaults for compatibility
val Purple80 = ElectricBlue
val PurpleGrey80 = SilverMetallic
val Pink80 = EmeraldGreen

val Purple40 = DeepElectricBlue
val PurpleGrey40 = GraphiteLight
val Pink40 = EmeraldGreen

