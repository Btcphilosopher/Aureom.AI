package com.example.data.repository

import com.example.data.api.GeminiClient
import com.example.data.local.ChatMessage
import com.example.data.local.RailwayDao
import com.example.data.local.Ticket
import kotlinx.coroutines.flow.Flow

class RailwayRepository(private val railwayDao: RailwayDao) {
    val allMessages: Flow<List<ChatMessage>> = railwayDao.getAllMessages()
    val allTickets: Flow<List<Ticket>> = railwayDao.getAllTickets()

    suspend fun insertMessage(message: ChatMessage) {
        railwayDao.insertMessage(message)
    }

    suspend fun clearChatHistory() {
        railwayDao.clearChatHistory()
    }

    suspend fun insertTicket(ticket: Ticket) {
        railwayDao.insertTicket(ticket)
    }

    suspend fun deleteTicket(ticketId: Int) {
        railwayDao.deleteTicket(ticketId)
    }

    suspend fun askNora(prompt: String, chatHistory: List<ChatMessage>): String {
        return GeminiClient.generateResponse(prompt, chatHistory)
    }
}
