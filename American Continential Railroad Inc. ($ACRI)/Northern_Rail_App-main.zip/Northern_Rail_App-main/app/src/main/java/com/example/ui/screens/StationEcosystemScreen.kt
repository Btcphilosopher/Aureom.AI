package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.DirectionsBike
import androidx.compose.material.icons.outlined.DirectionsWalk
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassPanel
import com.example.ui.components.GlowLine
import com.example.ui.theme.*
import com.example.viewmodel.RailwayViewModel
import com.example.viewmodel.StationNodeInfo

@Composable
fun StationEcosystemScreen(
    viewModel: RailwayViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val activeStationName = viewModel.selectedStationNode
    val stationList = viewModel.stationNodes
    
    val selectedStation = stationList.find { it.name == activeStationName } ?: stationList.first()

    // Inner ecosystem navigation tab
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("LIVE DEP", "HERITAGE", "LOCAL COFFEE", "ECO TRANSIT")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // --- HEADER STATION CHIP LIST ---
        Text(
            text = "STATION COMMUNITY INTELLIGENCE",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            stationList.forEach { node ->
                val isActive = node.name == activeStationName
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isActive) ElectricBlue else WhiteGlass)
                        .clickable { viewModel.selectStation(node.name) }
                        .border(1.dp, if (isActive) ElectricBlue else GlassBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("station_chip_${node.code}")
                ) {
                    Text(
                        text = node.code,
                        color = if (isActive) GraphiteDark else Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        GlowLine(color = ElectricBlue)
        Spacer(modifier = Modifier.height(16.dp))

        // --- SUB HERO: COGNITIVE NODE INFO ---
        Text(
            text = "ACTIVE TERMINUS NODE",
            color = ElectricBlue,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = selectedStation.name.uppercase(),
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.SansSerif
        )
        Text(
            text = "City: ${selectedStation.city} • Capacity Status: Optimal",
            color = SilverMetallic,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Glassmorphic node brief
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = selectedStation.modernIdentity,
                color = Color.White,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- ECOSYSTEM DETAILED TABS ---
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = GraphiteMedium,
            contentColor = ElectricBlue,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = ElectricBlue
                )
            },
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    modifier = Modifier.testTag("station_tab_$index")
                ) {
                    Text(
                        text = title,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = if (selectedTab == index) ElectricBlue else SilverMetallic
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- TAB CONTENT ---
        AnimatedContent(
            targetState = selectedTab,
            label = "tab_fade"
        ) { tabIndex ->
            when (tabIndex) {
                0 -> DeparturesTabContent(selectedStation = selectedStation, viewModel = viewModel)
                1 -> HeritageTabContent(selectedStation = selectedStation)
                2 -> LocalCoffeeTabContent(selectedStation = selectedStation)
                3 -> EcoTransitTabContent(selectedStation = selectedStation)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun DeparturesTabContent(selectedStation: StationNodeInfo, viewModel: RailwayViewModel) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        selectedStation.departures.forEach { dep ->
            GlassPanel(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.simulateTicketPurchase(
                            from = selectedStation.name,
                            to = dep.destination,
                            ticketType = "Single",
                            price = 11.80
                        )
                    }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = dep.time,
                            color = ElectricBlue,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = dep.destination,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Platform ${dep.platform} • Std Corridor",
                                color = SilverMetallic,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val color = if (dep.status == "ON TIME") EmeraldGreen else Color(0xFFFFD54F)
                        Text(
                            text = dep.status,
                            color = color,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Buy",
                            tint = ElectricBlue,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HeritageTabContent(selectedStation: StationNodeInfo) {
    GlassPanel(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.History, contentDescription = "History", tint = ElectricBlue, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("ENGINEERING HERITAGE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = selectedStation.heritage,
            color = SilverMetallic,
            fontSize = 13.sp,
            lineHeight = 18.sp
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LocationOn, contentDescription = "Districts", tint = EmeraldGreen, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("CULTURAL MATRIX", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = selectedStation.culturalHighlights,
            color = SilverMetallic,
            fontSize = 13.sp,
            lineHeight = 18.sp
        )
    }
}

@Composable
fun LocalCoffeeTabContent(selectedStation: StationNodeInfo) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        selectedStation.localRecs.forEach { rec ->
            GlassPanel(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ElectricBlue.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Storefront,
                            contentDescription = "Retailer",
                            tint = ElectricBlue
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = rec,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Northern Commuter Multiplier: Save 10% with active digital wallet pass.",
                            color = SilverMetallic,
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EcoTransitTabContent(selectedStation: StationNodeInfo) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.DirectionsBike, contentDescription = "Bikes", tint = EmeraldGreen, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("ECO-CYCLE HIRE LOCKER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${selectedStation.bicycleHireAvailable} cycles active & ready to deploy", color = EmeraldGreen, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Instant, touchless bicycle deployment via your active Northern ticket. Integrated with Leeds & Manchester cycle highway networks.",
                color = SilverMetallic,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.DirectionsWalk, contentDescription = "Walk", tint = ElectricBlue, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("OPTIMAL COATING & WALKING TRAILS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Sheffield Botanical & University trails connected", color = SilverMetallic, fontSize = 11.sp)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Explore scenic historical walking loops from the station exit. High-fidelity maps are stored in your offline-pass data package.",
                color = SilverMetallic,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }
    }
}
