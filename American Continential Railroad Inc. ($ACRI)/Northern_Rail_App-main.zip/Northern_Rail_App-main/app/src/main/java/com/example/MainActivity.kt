package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GraphiteDark
import com.example.ui.theme.GraphiteMedium
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SilverMetallic
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.components.GlowLine
import com.example.viewmodel.RailwayViewModel
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Alignment

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppStructure()
            }
        }
    }
}

// Representing Bottom Nav Items
sealed class NavigationItem(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Dashboard : NavigationItem("dashboard", "Command", Icons.Default.Dataset)
    object Nora : NavigationItem("nora", "Nora AI", Icons.Default.SmartToy)
    object Wallet : NavigationItem("wallet", "Wallet", Icons.Default.ConfirmationNumber)
    object Map : NavigationItem("map", "Live Map", Icons.Default.Map)
    object Hubs : NavigationItem("hubs", "Hubs Portal", Icons.Default.SpaceDashboard)
}

@Composable
fun MainAppStructure() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val viewModel: RailwayViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val app = context.applicationContext as android.app.Application
                return RailwayViewModel(app) as T
            }
        }
    )
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomNavItems = listOf(
        NavigationItem.Dashboard,
        NavigationItem.Nora,
        NavigationItem.Wallet,
        NavigationItem.Map,
        NavigationItem.Hubs
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Only show bottom navigation on primary screens
            val isPrimaryScreen = bottomNavItems.any { it.route == currentRoute } || currentRoute == "hubs"
            if (isPrimaryScreen) {
                NavigationBar(
                    containerColor = GraphiteMedium,
                    contentColor = ElectricBlue,
                    tonalElevation = 8.dp,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("app_bottom_navigation_bar")
                ) {
                    bottomNavItems.forEach { item ->
                        val selected = currentRoute == item.route || (item.route == "hubs" && (currentRoute == "stations" || currentRoute == "journey" || currentRoute == "community" || currentRoute == "economic"))
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,
                                    tint = if (selected) GraphiteDark else Color.White
                                )
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = FontFamily.SansSerif,
                                    color = if (selected) ElectricBlue else Color.White.copy(alpha = 0.6f)
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = ElectricBlue
                            ),
                            modifier = Modifier.testTag("nav_item_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavigationItem.Dashboard.route,
            modifier = Modifier
                .fillMaxSize()
                .background(GraphiteDark)
                .padding(bottom = if (bottomNavItems.any { it.route == currentRoute } || currentRoute == "hubs" || currentRoute == "stations" || currentRoute == "journey" || currentRoute == "community" || currentRoute == "economic") innerPadding.calculateBottomPadding() else 0.dp)
        ) {
            composable(NavigationItem.Dashboard.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToNora = { navController.navigate(NavigationItem.Nora.route) },
                    onNavigateToWallet = { navController.navigate(NavigationItem.Wallet.route) },
                    onNavigateToMap = { navController.navigate(NavigationItem.Map.route) },
                    onNavigateToStations = { navController.navigate("stations") },
                    onNavigateToJourney = { navController.navigate("journey") },
                    onNavigateToCommunity = { navController.navigate("community") },
                    onNavigateToEconomic = { navController.navigate("economic") }
                )
            }
            
            composable(NavigationItem.Nora.route) {
                NoraScreen(viewModel = viewModel)
            }
            
            composable(NavigationItem.Wallet.route) {
                WalletScreen(viewModel = viewModel)
            }
            
            composable(NavigationItem.Map.route) {
                NetworkMapScreen(viewModel = viewModel)
            }

            composable(NavigationItem.Hubs.route) {
                HubsPortalScreen(
                    onNavigateToStations = { navController.navigate("stations") },
                    onNavigateToJourney = { navController.navigate("journey") },
                    onNavigateToCommunity = { navController.navigate("community") },
                    onNavigateToEconomic = { navController.navigate("economic") }
                )
            }

            // Deep-dive dashboards
            composable("stations") {
                StationEcosystemScreen(viewModel = viewModel)
            }

            composable("journey") {
                JourneyModeScreen(viewModel = viewModel)
            }

            composable("community") {
                CommunityScreen(viewModel = viewModel)
            }

            composable("economic") {
                BusinessModeScreen(viewModel = viewModel)
            }
        }
    }
}

// Hubs Portal Screen representing category navigation lists
@Composable
fun HubsPortalScreen(
    onNavigateToStations: () -> Unit,
    onNavigateToJourney: () -> Unit,
    onNavigateToCommunity: () -> Unit,
    onNavigateToEconomic: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Text(
            text = "COGNITIVE REGIONAL PORTAL",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Text(
            text = "Northern Hubs",
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.SansSerif
        )
        Spacer(modifier = Modifier.height(8.dp))
        GlowLine(color = ElectricBlue)
        Spacer(modifier = Modifier.height(20.dp))

        // Navigation cards grid/list
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            HubCard(
                title = "STATION ECOSYSTEMS",
                desc = "Transform stations into local economic & clean-energy hubs. Live arrivals, coffee shops, bike hire.",
                icon = Icons.Default.Storefront,
                color = ElectricBlue,
                onClick = onNavigateToStations,
                testTag = "portal_stations_card"
            )

            HubCard(
                title = "JOURNEY MODE HUD",
                desc = "Active in-transit telemetry. Live carriage loads, seat allocations, quiet zone status, nearby attractions.",
                icon = Icons.Default.SettingsSystemDaydream,
                color = EmeraldGreen,
                onClick = onNavigateToJourney,
                testTag = "portal_journey_card"
            )

            HubCard(
                title = "COMMUNITY NETWORK",
                desc = "Social mobility metrics, commuter logs, city guides, active carbon-saving achievements.",
                icon = Icons.Default.Groups,
                color = Color(0xFFFFD54F),
                onClick = onNavigateToCommunity,
                testTag = "portal_community_card"
            )

            HubCard(
                title = "BUSINESS CORRIDOR",
                desc = "Corporate accounts expense logs, co-working boardroom hubs, dynamic quiet/productivity toggles.",
                icon = Icons.Default.BusinessCenter,
                color = Color(0xFFE040FB),
                onClick = onNavigateToEconomic,
                testTag = "portal_business_card"
            )
        }
    }
}

@Composable
fun HubCard(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GraphiteMedium),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = color,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = desc,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 18.sp
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Open",
                tint = SilverMetallic
            )
        }
    }
}
