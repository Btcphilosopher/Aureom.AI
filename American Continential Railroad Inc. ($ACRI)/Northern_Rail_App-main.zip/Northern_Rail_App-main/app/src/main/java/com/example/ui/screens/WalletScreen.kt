package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.Ticket
import com.example.ui.components.GlassPanel
import com.example.ui.components.GlowLine
import com.example.ui.theme.*
import com.example.viewmodel.RailwayViewModel
import kotlin.random.Random

@Composable
fun WalletScreen(
    viewModel: RailwayViewModel,
    modifier: Modifier = Modifier
) {
    val ticketList by viewModel.tickets.collectAsState()
    val scrollState = rememberScrollState()

    // Animation for the holographic glare sweeping across the cards
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val sweepProgress by infiniteTransition.animateFloat(
        initialValue = -0.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // --- HEADER ---
        Text(
            text = "DIGITAL WALLET ENGINE",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Text(
            text = "Holographic Identity",
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.SansSerif
        )
        Spacer(modifier = Modifier.height(8.dp))
        GlowLine(color = ElectricBlue)
        Spacer(modifier = Modifier.height(16.dp))

        // --- HOLOGRAPHIC PASS CARD ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
        ) {
            // Draw gradient background
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            GraphiteMedium,
                            GraphiteLight,
                            Color(0xFF0F1E36)
                        ),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height)
                    )
                )

                // Holographic glare line sweep representation
                val sweepX = size.width * sweepProgress
                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            ElectricBlue.copy(alpha = 0.4f),
                            Color.White.copy(alpha = 0.6f),
                            ElectricBlue.copy(alpha = 0.4f),
                            Color.Transparent
                        ),
                        start = Offset(sweepX - 80f, 0f),
                        end = Offset(sweepX + 80f, size.height)
                    ),
                    start = Offset(sweepX - 100f, -50f),
                    end = Offset(sweepX + 100f, size.height + 50f),
                    strokeWidth = 60f
                )
            }

            // Passive overlay contents
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "NORTHERN PASS",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "Sheffield → Leeds Corridor Grid",
                            color = SilverMetallic,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(
                                Brush.linearGradient(colors = listOf(ElectricBlue, EmeraldGreen)),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "ACTIVE",
                            color = GraphiteDark,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "COMMUTER ID",
                            color = SilverMetallic,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "HYP-LN-09923",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "MOBILITY STATUS",
                            color = SilverMetallic,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = viewModel.activeMobilityStatus,
                            color = ElectricBlue,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- REWARDS & SAVINGS LOG ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GlassPanel(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Stars, contentDescription = "Points", tint = ElectricBlue, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("GREEN POINTS", color = SilverMetallic, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text("${viewModel.pointsBalance} PTS", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            GlassPanel(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalActivity, contentDescription = "Loyalty", tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ACTIVE PASSES", color = SilverMetallic, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Spacer(modifier = Modifier.height(6.dp))
                val activeCount = ticketList.count { it.status == "ACTIVE" }
                Text("$activeCount ACTIVE", color = EmeraldGreen, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- AUTOMATIC TICKET OPTIMIZER SECTION ---
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SettingsSuggest, contentDescription = "Optimize", tint = ElectricBlue, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "AI AUTO-FARE OPTIMIZATION",
                    color = ElectricBlue,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "PAY-AS-YOU-TRAVEL (PAYT) is active. The system will automatically monitor your trips and cap your daily fares at standard regional off-peak ticket thresholds.",
                color = SilverMetallic,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- TICKETS LIST ---
        Text(
            text = "DIGITAL DISPATCHES",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (ticketList.isEmpty()) {
            GlassPanel(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.ConfirmationNumber, contentDescription = "None", tint = SilverMetallic.copy(alpha = 0.3f), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No tickets loaded.", color = SilverMetallic, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Go to the Command Centre or ask NORA to generate active routes.", color = SilverMetallic.copy(alpha = 0.6f), fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ticketList.forEach { ticket ->
                    TicketCard(
                        ticket = ticket,
                        onDeleteClick = { viewModel.deleteTicket(ticket.id) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun TicketCard(
    ticket: Ticket,
    onDeleteClick: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    GlassPanel(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("ticket_card_${ticket.id}"),
        borderStroke = BorderStroke(
            width = 1.dp,
            color = if (ticket.status == "ACTIVE") ElectricBlue.copy(alpha = 0.4f) else GlassBorder
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = ticket.ticketType.uppercase(),
                        color = if (ticket.status == "ACTIVE") ElectricBlue else SilverMetallic,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = ticket.classType,
                        color = SilverMetallic,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${ticket.fromStation} → ${ticket.toStation}",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${ticket.date} • Departs ${ticket.time}",
                    color = SilverMetallic,
                    fontSize = 12.sp
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "£${String.format("%.2f", ticket.price)}",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (ticket.status == "ACTIVE") EmeraldGreen.copy(alpha = 0.15f)
                            else Color.White.copy(alpha = 0.05f)
                        )
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = ticket.status,
                        color = if (ticket.status == "ACTIVE") EmeraldGreen else SilverMetallic,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Expand to show high-fidelity vector QR Code scanner
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GlowLine(color = ElectricBlue, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "COMMUTER SCAN INTERFACE",
                    color = ElectricBlue,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Custom Canvas-drawn QR Code block for extreme premium modernist visual styling
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val gridSize = 10
                        val cellSize = size.width / gridSize
                        
                        // Seed random grids to draw realistic hypermodern blocks
                        val seed = ticket.qrCodeData.hashCode()
                        val random = Random(seed)

                        // Draw QR outer markers
                        // Top-left
                        drawRect(color = Color.Black, topLeft = Offset(0f, 0f), size = Size(cellSize * 3, cellSize * 3))
                        drawRect(color = Color.White, topLeft = Offset(cellSize, cellSize), size = Size(cellSize, cellSize))
                        // Top-right
                        drawRect(color = Color.Black, topLeft = Offset(cellSize * 7, 0f), size = Size(cellSize * 3, cellSize * 3))
                        drawRect(color = Color.White, topLeft = Offset(cellSize * 8, cellSize), size = Size(cellSize, cellSize))
                        // Bottom-left
                        drawRect(color = Color.Black, topLeft = Offset(0f, cellSize * 7), size = Size(cellSize * 3, cellSize * 3))
                        drawRect(color = Color.White, topLeft = Offset(cellSize, cellSize * 8), size = Size(cellSize, cellSize))

                        // Draw random intermediate dots representing data payloads
                        for (r in 0 until gridSize) {
                            for (c in 0 until gridSize) {
                                // Skip corners already drawn
                                if ((r < 3 && c < 3) || (r < 3 && c >= 7) || (r >= 7 && c < 3)) {
                                    continue
                                }
                                if (random.nextBoolean()) {
                                    drawRect(
                                        color = Color.Black,
                                        topLeft = Offset(c * cellSize, r * cellSize),
                                        size = Size(cellSize, cellSize)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = ticket.qrCodeData,
                    color = SilverMetallic,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                
                Spacer(modifier = Modifier.height(12.dp))

                TextButton(
                    onClick = onDeleteClick,
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF5350))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("REFUND & TERMINATE DISPATCH")
                    }
                }
            }
        }
    }
}
