package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassPanel
import com.example.ui.components.GlowLine
import com.example.ui.components.NetworkBadge
import com.example.ui.theme.*
import com.example.viewmodel.RailwayViewModel

@Composable
fun DashboardScreen(
    viewModel: RailwayViewModel,
    onNavigateToNora: () -> Unit,
    onNavigateToWallet: () -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToStations: () -> Unit,
    onNavigateToJourney: () -> Unit,
    onNavigateToCommunity: () -> Unit,
    onNavigateToEconomic: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    
    // Pulse animation for critical alerts or active states
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    // Drawing flowing neural lines in background
    val neuralProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "neuralPath"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // --- BENTO TOP HEADER & STATUS BAR ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SYSTEM STATUS: OPTIMAL",
                    color = ElectricBlue,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "NORTHERN ",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "// ",
                        color = ElectricBlue,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "HYPERLINK",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp
                    )
                }
            }

            // User Avatar / JD
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(ElectricBlue, EmeraldGreen)
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                    .clickable { onNavigateToStations() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "JD",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // --- HERO COMMAND CENTRE SECTION ---
        Column(modifier = Modifier.padding(bottom = 20.dp)) {
            Text(
                text = "Good morning, James.",
                color = SilverMetallic,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = buildAnnotatedString {
                    append("The North is ")
                    withStyle(
                        style = SpanStyle(
                            fontFamily = FontFamily.Serif,
                            fontStyle = FontStyle.Italic,
                            color = EmeraldGreen
                        )
                    ) {
                        append("moving.")
                    }
                },
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = (-0.5).sp
            )
        }

        // --- NEXT RECOMMENDED JOURNEY WIDGET (Bento Wide) ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(WhiteGlass)
                .border(1.dp, GlassBorder, RoundedCornerShape(24.dp))
                .padding(20.dp)
                .testTag("recommended_journey_panel")
        ) {
            // Background Neural Graphics Draw
            Canvas(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(width = 120.dp, height = 80.dp)
                    .alpha(0.12f)
            ) {
                val path1 = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, size.height * 0.75f)
                    cubicTo(
                        size.width * 0.25f, size.height * 0.25f,
                        size.width * 0.5f, size.height * 0.5f,
                        size.width, size.height * 0.125f
                    )
                }
                drawPath(
                    path = path1,
                    color = ElectricBlue,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                )

                val path2 = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, size.height * 0.875f)
                    cubicTo(
                        size.width * 0.33f, size.height * 0.375f,
                        size.width * 0.67f, size.height * 0.625f,
                        size.width, size.height * 0.25f
                    )
                }
                drawPath(
                    path = path2,
                    color = EmeraldGreen,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                )
            }

            // Top-right ON TIME badge
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .background(EmeraldGreen.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                    .border(1.dp, EmeraldGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "ON TIME",
                    color = EmeraldGreen,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Content Column
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "NEXT RECOMMENDED",
                    color = SilverMetallic,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    Text(
                        text = "07:42",
                        color = Color.White,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-1).sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "to Manchester Picc",
                        color = SilverMetallic,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                Divider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 4.dp))

                // Platform, Carriage, Crowd Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Column {
                            Text(
                                text = "PLATFORM",
                                color = SilverMetallic,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "04",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column {
                            Text(
                                text = "CARRIAGE",
                                color = SilverMetallic,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Quiet Zone",
                                color = ElectricBlue,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "CROWD LEVEL",
                            color = SilverMetallic,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(modifier = Modifier.size(width = 12.dp, height = 6.dp).clip(RoundedCornerShape(3.dp)).background(EmeraldGreen))
                            Box(modifier = Modifier.size(width = 12.dp, height = 6.dp).clip(RoundedCornerShape(3.dp)).background(EmeraldGreen))
                            Box(modifier = Modifier.size(width = 12.dp, height = 6.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = 0.2f)))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Booking Button inside widget
                Button(
                    onClick = {
                        viewModel.simulateTicketPurchase(
                            from = "Sheffield Central",
                            to = "Manchester Piccadilly",
                            ticketType = "Single",
                            price = 14.50
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("book_recommended_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricBlue,
                        contentColor = GraphiteDark
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ConfirmationNumber, contentDescription = "Book", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("OPTIMIZE & BOOK PASS // £14.50", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- BENTO GRID ROW 1: NORA AI & REGIONAL NET MAP ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // NORA AI Card
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF1E2025), Color(0xFF141517))
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp))
                    .clickable { onNavigateToNora() }
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(ElectricBlue)
                    )
                    Text(
                        text = "NORA AI",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "\"Sheffield route optimization active. Save £4.20 by switching to the 07:55.\"",
                    color = Color(0xFFCBD5E1),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    lineHeight = 15.sp
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "OPEN CHAT",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Live Map Preview Card
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF141517))
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp))
                    .clickable { onNavigateToMap() }
                    .padding(16.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    drawCircle(color = ElectricBlue, radius = 6f, center = Offset(w * 0.3f, h * 0.4f))
                    drawCircle(color = ElectricBlue, radius = 6f, center = Offset(w * 0.7f, h * 0.25f))
                    drawCircle(color = EmeraldGreen, radius = 6f, center = Offset(w * 0.5f, h * 0.75f))

                    drawLine(color = ElectricBlue.copy(alpha = 0.3f), start = Offset(w * 0.3f, h * 0.4f), end = Offset(w * 0.7f, h * 0.25f), strokeWidth = 2f)
                    drawLine(color = ElectricBlue.copy(alpha = 0.3f), start = Offset(w * 0.3f, h * 0.4f), end = Offset(w * 0.5f, h * 0.75f), strokeWidth = 2f)

                    drawCircle(color = Color.White.copy(alpha = 0.8f), radius = 4f, center = Offset(w * 0.45f, h * 0.35f))
                }

                Text(
                    text = "REGIONAL NET",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.align(Alignment.TopStart)
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.08f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "LIVE",
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- BENTO GRID ROW 2: DIGITAL WALLET & ECO OUTPUT ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Digital Wallet Card
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(24.dp))
                    .background(ElectricBlue)
                    .clickable { onNavigateToWallet() }
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "WALLET",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Column {
                    Text(
                        text = "GOLD PASS",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "NFC ACTIVE",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Eco Output Card
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(24.dp))
                    .background(EmeraldGreen.copy(alpha = 0.1f))
                    .border(1.dp, EmeraldGreen.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                    .clickable { onNavigateToCommunity() }
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "ECO OUTPUT",
                    color = EmeraldGreen,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Column {
                    Text(
                        text = "-${"%.1f".format(viewModel.co2SavedKg)}kg",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "CO2 Saved",
                        color = SilverMetallic,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- THE DYNAMIC NEURAL PATH CANVAS ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(GraphiteMedium)
                .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height
                val midY = height / 2

                drawLine(
                    color = Color.White.copy(alpha = 0.08f),
                    start = Offset(0f, midY),
                    end = Offset(width, midY),
                    strokeWidth = 4f
                )

                val x1 = width * neuralProgress
                val x2 = width * ((neuralProgress + 0.3f) % 1.0f)
                val x3 = width * ((neuralProgress + 0.65f) % 1.0f)

                drawCircle(color = ElectricBlue, radius = 5f, center = Offset(x1, midY))
                drawCircle(color = EmeraldGreen, radius = 4f, center = Offset(x2, midY))
                drawCircle(color = DeepElectricBlue, radius = 6f, center = Offset(x3, midY))
            }

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "PENNINE ENERGY MATRIX",
                    color = ElectricBlue.copy(alpha = 0.8f),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "CONNECTED GRID",
                    color = SilverMetallic,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- LIVE DEPARTURES BOARD ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LIVE REGIONAL CORRIDORS",
                color = SilverMetallic,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(WhiteGlass)
                    .clickable { onNavigateToStations() }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location",
                        tint = ElectricBlue,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = viewModel.selectedStationNode,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val currentStationInfo = viewModel.stationNodes.firstOrNull { it.name == viewModel.selectedStationNode }
        if (currentStationInfo != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteMedium, RoundedCornerShape(24.dp))
                    .border(1.dp, GlassBorder, RoundedCornerShape(24.dp))
                    .padding(8.dp)
            ) {
                currentStationInfo.departures.forEach { dep ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                            .clickable {
                                viewModel.simulateTicketPurchase(
                                    from = viewModel.selectedStationNode,
                                    to = dep.destination,
                                    ticketType = "Single",
                                    price = 12.00
                                )
                            },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = dep.time,
                                color = ElectricBlue,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = dep.destination,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Platform ${dep.platform} • Std Class",
                                    color = SilverMetallic,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val statusColor = if (dep.status == "ON TIME") EmeraldGreen else Color(0xFFFFD54F)
                            Text(
                                text = dep.status,
                                color = statusColor,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.ConfirmationNumber,
                                contentDescription = "Buy",
                                tint = ElectricBlue.copy(alpha = 0.6f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Divider(color = Color.White.copy(alpha = 0.05f))
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
