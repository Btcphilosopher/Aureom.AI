package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BusinessCenter
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassPanel
import com.example.ui.components.GlowLine
import com.example.ui.theme.*
import com.example.viewmodel.RailwayViewModel

@Composable
fun BusinessModeScreen(
    viewModel: RailwayViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    
    var productivityModeEnabled by remember { mutableStateOf(false) }
    var corporateAccountLinked by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "REGIONAL ECONOMIC ENGINE",
                    color = SilverMetallic,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Business Corridor",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.SansSerif
                )
            }
            Icon(Icons.Outlined.BusinessCenter, contentDescription = "Business", tint = ElectricBlue)
        }

        Spacer(modifier = Modifier.height(8.dp))
        GlowLine(color = ElectricBlue)
        Spacer(modifier = Modifier.height(16.dp))

        // --- SUB HERO BRIEF ---
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Connecting the economic clusters of the North. Managing corporate commutes, flexible tax expenses, and productivity pods seamlessly.",
                color = Color.White,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- CORPORATE PROFILE HUD ---
        Text(
            text = "CORPORATE DISPATCH IDENTITY",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ElectricBlue.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CardTravel, contentDescription = "Card", tint = ElectricBlue)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Northern Tech Corp (Linked)",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Account: NTC-CORP-4819",
                            color = SilverMetallic,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                
                Switch(
                    checked = corporateAccountLinked,
                    onCheckedChange = { corporateAccountLinked = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GraphiteDark,
                        checkedTrackColor = ElectricBlue,
                        uncheckedThumbColor = SilverMetallic,
                        uncheckedTrackColor = GraphiteLight
                    ),
                    modifier = Modifier.testTag("corporate_profile_switch")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = Color.White.copy(alpha = 0.05f))
            Spacer(modifier = Modifier.height(12.dp))

            // Billing limits
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("EXPENSED THIS MONTH", color = SilverMetallic, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("£185.20", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("MONTHLY CAP LIMIT", color = SilverMetallic, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("£500.00 (Standard)", color = SilverMetallic, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- PRODUCTIVITY CONTROL HUB ---
        Text(
            text = "PRODUCTIVITY MATRIX",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            borderStroke = BorderStroke(
                width = 1.dp,
                color = if (productivityModeEnabled) EmeraldGreen.copy(alpha = 0.5f) else GlassBorder
            )
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (productivityModeEnabled) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Sound",
                        tint = if (productivityModeEnabled) EmeraldGreen else ElectricBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Active Focus Mode", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Auto-route calls to voicemail during transit", color = SilverMetallic, fontSize = 11.sp)
                    }
                }

                Switch(
                    checked = productivityModeEnabled,
                    onCheckedChange = { productivityModeEnabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GraphiteDark,
                        checkedTrackColor = EmeraldGreen,
                        uncheckedThumbColor = SilverMetallic,
                        uncheckedTrackColor = GraphiteLight
                    ),
                    modifier = Modifier.testTag("productivity_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- SUGGESTED CO-WORKING MEETING NODES ---
        Text(
            text = "TRANSIT-HUB MEETING NODES",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Workspace Node 1
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "LEEDS ARCH CO-WORKING (NODE 2)",
                        color = ElectricBlue,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text("The Arcades Boardroom", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Location: 2 mins from Leeds Innovation Exit North. Acoustic pods, high-speed quantum links, and organic roasters.", color = SilverMetallic, fontSize = 11.sp)
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Button(
                    onClick = { /* Simulated booking */ },
                    colors = ButtonDefaults.buttonColors(containerColor = WhiteGlass, contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("SECURE", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Workspace Node 2
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "SHEFFIELD STEEL-LABS (NODE 4)",
                        color = ElectricBlue,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Crucible Innovation Suite", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Location: Platform 1 Mezzanine, Sheffield Central. Dynamic whiteboard panes, ergonomic standing docks, and local tea bars.", color = SilverMetallic, fontSize = 11.sp)
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Button(
                    onClick = { /* Simulated booking */ },
                    colors = ButtonDefaults.buttonColors(containerColor = WhiteGlass, contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("SECURE", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- EXPENSES SUMMARY EXPORT ---
        Text(
            text = "AUTOMATED EXPENSE COMPILER",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Export quarterly commuter tax reports", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Sends approved receipts directly to accounting@company.com", color = SilverMetallic, fontSize = 11.sp)
                }
                
                Button(
                    onClick = { /* Simulated export */ },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = GraphiteDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("export_expenses_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Download, contentDescription = "Export", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("EXPORT", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
