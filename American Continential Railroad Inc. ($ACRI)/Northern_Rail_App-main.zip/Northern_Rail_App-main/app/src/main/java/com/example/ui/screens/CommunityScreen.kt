package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassPanel
import com.example.ui.components.GlowLine
import com.example.ui.theme.*
import com.example.viewmodel.RailwayViewModel

@Composable
fun CommunityScreen(
    viewModel: RailwayViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // --- HEADER ---
        Text(
            text = "NORTHERN MOBILITY HUB",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Text(
            text = "Community Grid",
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.SansSerif
        )
        Spacer(modifier = Modifier.height(8.dp))
        GlowLine(color = ElectricBlue)
        Spacer(modifier = Modifier.height(16.dp))

        // --- ECO CARBON RADIAL INSIGHTS ---
        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            testTag = "community_sustainability_panel"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circular Canvas gauge for carbon savings progress
                Box(
                    modifier = Modifier.size(90.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 14f
                        val radius = (size.width - strokeWidth) / 2
                        
                        // Grey background arc
                        drawArc(
                            color = Color.White.copy(alpha = 0.08f),
                            startAngle = 135f,
                            sweepAngle = 270f,
                            useCenter = false,
                            topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                            size = Size(radius * 2, radius * 2),
                            style = Stroke(width = strokeWidth)
                        )

                        // Glowing green achievement arc
                        drawArc(
                            brush = Brush.sweepGradient(
                                colors = listOf(ElectricBlue, EmeraldGreen, ElectricBlue)
                            ),
                            startAngle = 135f,
                            sweepAngle = 180f, // 180 out of 270 degrees filled (66%)
                            useCenter = false,
                            topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                            size = Size(radius * 2, radius * 2),
                            style = Stroke(width = strokeWidth)
                        )
                    }
                    
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${viewModel.co2SavedKg.toInt()}",
                            color = EmeraldGreen,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "KG CO2",
                            color = SilverMetallic,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = "SUSTAINABILITY PROGRESS",
                        color = ElectricBlue,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Carbon Offset Target",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Your rail activity has saved ${viewModel.co2SavedKg}kg CO2 this month. You have out-performed 85% of standard regional drivers.",
                        color = SilverMetallic,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- ACTIVE RAIL CHALLENGES ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACTIVE CHALLENGES",
                color = SilverMetallic,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Icon(Icons.Outlined.EmojiEvents, contentDescription = "Challenges", tint = ElectricBlue, modifier = Modifier.size(16.dp))
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Challenge card 1
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ElectricBlue.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Terrain, contentDescription = "Peak", tint = ElectricBlue, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Peak District Eco-Explorer", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Visit 3 Peak District eco-stops using electric trains.", color = SilverMetallic, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(progress = 0.66f, color = ElectricBlue, trackColor = Color.White.copy(alpha = 0.05f), modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text("2/3", color = ElectricBlue, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Challenge card 2
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(EmeraldGreen.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.AccessTime, contentDescription = "Off-Peak", tint = EmeraldGreen, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Off-Peak Carbon Master", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Complete 5 off-peak trips during quieter intervals.", color = SilverMetallic, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(progress = 0.8f, color = EmeraldGreen, trackColor = Color.White.copy(alpha = 0.05f), modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text("4/5", color = EmeraldGreen, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- REGIONAL COMMUNITY CHAT BOARD ---
        Text(
            text = "REGIONAL COMMUNITY BULLETINS",
            color = SilverMetallic,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Post 1
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Person, contentDescription = "U", tint = SilverMetallic, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("Sarah M. • Commuter Leeds Corridor", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("20 mins ago in #LeedsInnovationNode", color = SilverMetallic, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Absolutely love the new quiet zone carriage configurations in the Pennine Bullet! Managed to review my entire medical startup pitch deck between Leeds and Manchester without any disruption.",
                color = Color.White,
                fontSize = 13.sp,
                lineHeight = 17.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Post 2
        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Person, contentDescription = "U", tint = SilverMetallic, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("James K. • Node Volunteer", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("2 hours ago in #SheffieldCentralNode", color = SilverMetallic, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Steam & Steel Espresso is running a local coffee workshop today! If you have an active train ticket on your pass, they are offering double loyalty stamps. Truly the best coffee in South Yorkshire.",
                color = Color.White,
                fontSize = 13.sp,
                lineHeight = 17.sp
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
