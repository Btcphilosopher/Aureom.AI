package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassPanel
import com.example.ui.components.GlowLine
import com.example.ui.components.NetworkBadge
import com.example.ui.theme.*
import com.example.viewmodel.LiveTrain
import com.example.viewmodel.RailwayViewModel

@Composable
fun NetworkMapScreen(
    viewModel: RailwayViewModel,
    modifier: Modifier = Modifier
) {
    val liveTrains = viewModel.liveTrains
    var selectedTrainId by remember { mutableStateOf<String?>(null) }
    var selectedCityName by remember { mutableStateOf<String?>(null) }

    // Pulse animation for map nodes
    val infiniteTransition = rememberInfiniteTransition(label = "mapPulse")
    val radiusAnim by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "radius"
    )

    // Cities configuration coords (scaled between 0f and 1f for the canvas)
    val cities = listOf(
        MapCity("Lancaster", 0.15f, 0.25f, "LNC"),
        MapCity("Liverpool", 0.15f, 0.65f, "LIV"),
        MapCity("Manchester", 0.35f, 0.55f, "MAN"),
        MapCity("Sheffield", 0.48f, 0.72f, "SHF"),
        MapCity("Leeds", 0.55f, 0.45f, "LDS"),
        MapCity("York", 0.70f, 0.35f, "YRK"),
        MapCity("Bradford", 0.48f, 0.42f, "BDF"),
        MapCity("Newcastle", 0.75f, 0.10f, "NCL")
    )

    // Connections between cities (rail corridors)
    val connections = listOf(
        Pair("Liverpool", "Manchester"),
        Pair("Manchester", "Sheffield"),
        Pair("Manchester", "Leeds"),
        Pair("Bradford", "Leeds"),
        Pair("Leeds", "York"),
        Pair("York", "Newcastle"),
        Pair("Lancaster", "Manchester")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NETWORK COGNITIVE MATRIX",
                    color = SilverMetallic,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Live Neural Map",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.SansSerif
                )
            }
            NetworkBadge(status = "ACTIVE")
        }

        Spacer(modifier = Modifier.height(8.dp))
        GlowLine(color = ElectricBlue)
        Spacer(modifier = Modifier.height(12.dp))

        // --- MAP MAIN CANVAS CARD ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(GraphiteMedium)
                .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
        ) {
            // Interactive custom topology drawing
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable {
                        selectedTrainId = null
                        selectedCityName = null
                    }
            ) {
                val w = size.width
                val h = size.height

                // Draw coordinate alignment grid lines
                val gridStroke = Stroke(width = 1f, pathEffect = null)
                for (i in 1..10) {
                    val gridX = w * (i / 10f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.03f),
                        start = Offset(gridX, 0f),
                        end = Offset(gridX, h),
                        strokeWidth = 1f
                    )
                    val gridY = h * (i / 10f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.03f),
                        start = Offset(0f, gridY),
                        end = Offset(w, gridY),
                        strokeWidth = 1f
                    )
                }

                // Draw Rail Corridor lines (connections)
                connections.forEach { conn ->
                    val c1 = cities.find { it.name == conn.first }
                    val c2 = cities.find { it.name == conn.second }
                    if (c1 != null && c2 != null) {
                        drawLine(
                            color = ElectricBlue.copy(alpha = 0.2f),
                            start = Offset(c1.x * w, c1.y * h),
                            end = Offset(c2.x * w, c2.y * h),
                            strokeWidth = 3f
                        )
                    }
                }

                // Draw Stations (Nodes)
                cities.forEach { city ->
                    val cx = city.x * w
                    val cy = city.y * h

                    // Pulse outer halo
                    drawCircle(
                        color = ElectricBlue.copy(alpha = 0.05f),
                        radius = radiusAnim * 2,
                        center = Offset(cx, cy)
                    )

                    // Core point
                    drawCircle(
                        color = ElectricBlue,
                        radius = 6f,
                        center = Offset(cx, cy)
                    )
                }

                // Draw active trains gliding on lines
                liveTrains.forEach { train ->
                    val tx = train.xOffsetFactor * w
                    val ty = train.yOffsetFactor * h

                    // Draw glow behind active trains
                    drawCircle(
                        color = EmeraldGreen.copy(alpha = 0.25f),
                        radius = 10f,
                        center = Offset(tx, ty)
                    )

                    drawCircle(
                        color = EmeraldGreen,
                        radius = 5f,
                        center = Offset(tx, ty)
                    )
                }
            }

            // Labels overlay
            cities.forEach { city ->
                Box(
                    modifier = Modifier
                        .offset(
                            x = (city.x * 280).dp - 25.dp, // manual placement scaling
                            y = (city.y * 420).dp - 15.dp
                        )
                        .clip(RoundedCornerShape(4.dp))
                        .background(GraphiteDark.copy(alpha = 0.8f))
                        .clickable { selectedCityName = city.name }
                        .border(0.5.dp, GlassBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = city.code,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Train icons or list trigger buttons overlay on map edge
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
            ) {
                liveTrains.take(4).forEach { train ->
                    IconButton(
                        onClick = {
                            selectedTrainId = train.id
                            selectedCityName = null
                        },
                        modifier = Modifier
                            .padding(bottom = 6.dp)
                            .size(28.dp)
                            .background(
                                if (selectedTrainId == train.id) EmeraldGreen else WhiteGlass,
                                RoundedCornerShape(6.dp)
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Train,
                            contentDescription = "Train",
                            tint = if (selectedTrainId == train.id) GraphiteDark else ElectricBlue,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Map Legends Overlay (Bottom Left)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
                    .background(GraphiteDark.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                    .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(ElectricBlue, RoundedCornerShape(4.dp)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("COGNITIVE NODE", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(EmeraldGreen, RoundedCornerShape(4.dp)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ACTIVE DISPATCH", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // --- CONTEXT DETAILS BAR (BOTTOM INTERACTION) ---
        AnimatedVisibility(
            visible = selectedTrainId != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            val train = liveTrains.find { it.id == selectedTrainId }
            if (train != null) {
                GlassPanel(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("map_train_details_panel"),
                    borderStroke = BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "TRAIN DECODER // ${train.id}",
                                color = EmeraldGreen,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = train.name,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${train.origin} → ${train.destination}",
                                color = SilverMetallic,
                                fontSize = 12.sp
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${train.speedKmph} KM/H",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Load: ${train.capacityPercent}%",
                                color = SilverMetallic,
                                fontSize = 12.sp
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Quick ticket booking trigger for selected train
                    Button(
                        onClick = {
                            viewModel.simulateTicketPurchase(
                                from = train.origin,
                                to = train.destination,
                                ticketType = "Single",
                                price = 12.50
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = GraphiteDark),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("INTERCEPT ROUTE & ACQUIRE PASS", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = selectedCityName != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            val cityNode = viewModel.stationNodes.find { it.city == selectedCityName }
            if (cityNode != null) {
                GlassPanel(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("map_station_details_panel")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "NODE INTELLIGENCE // ${cityNode.code}",
                                color = ElectricBlue,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = cityNode.name,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        
                        // Select Station as active node
                        TextButton(
                            onClick = {
                                viewModel.selectStation(cityNode.name)
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = ElectricBlue)
                        ) {
                            Text("SET ACTIVE NODE", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = cityNode.modernIdentity,
                        color = SilverMetallic,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Catch-all prompt if nothing selected
        if (selectedTrainId == null && selectedCityName == null) {
            GlassPanel(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TouchApp, contentDescription = "Tap", tint = ElectricBlue, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CONSOLE OPTION: Tap station markers or trains on the grid to open high-fidelity data nodes, speeds, and direct corridor bookings.",
                        color = SilverMetallic,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}

data class MapCity(
    val name: String,
    val x: Float,
    val y: Float,
    val code: String
)
