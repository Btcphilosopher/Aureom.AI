package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessage
import com.example.data.local.Ticket
import com.example.data.repository.RailwayRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

// Data representation of a live train on our hypermodernist map
data class LiveTrain(
    val id: String,
    val name: String,
    val origin: String,
    val destination: String,
    val progress: Float, // 0.0f to 1.0f
    val speedKmph: Int,
    val capacityPercent: Int,
    val status: String, // "ON TIME", "SLIGHT DELAY", "EXPRESS"
    val xOffsetFactor: Float, // path coordinates representation
    val yOffsetFactor: Float
)

// Data representation for station nodes
data class StationNodeInfo(
    val name: String,
    val city: String,
    val code: String,
    val heritage: String,
    val modernIdentity: String,
    val bicycleHireAvailable: Int,
    val localRecs: List<String>,
    val culturalHighlights: String,
    val departures: List<LiveDeparture>
)

data class LiveDeparture(
    val time: String,
    val destination: String,
    val platform: String,
    val status: String,
    val delayMins: Int = 0
)

class RailwayViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = RailwayRepository(database.railwayDao())

    // Flows from repository
    val chatHistory: StateFlow<List<ChatMessage>> = repository.allMessages
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val tickets: StateFlow<List<Ticket>> = repository.allTickets
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Live state variables
    var isNoraTyping by mutableStateOf(false)
        private set

    // Live train positions for interactive live map
    var liveTrains by mutableStateOf<List<LiveTrain>>(emptyList())
        private set

    // Active Journey Mode details
    var activeJourneyProgress by mutableStateOf(0.42f)
        private set
    
    var activeJourneyNextStation by mutableStateOf("Leeds Innovation District")
        private set

    var activeJourneySecondsToArrival by mutableStateOf(480) // 8 minutes
        private set

    // Sustainability metrics
    var co2SavedKg by mutableStateOf(42.5f)
        private set

    var pointsBalance by mutableStateOf(850)
        private set

    var activeMobilityStatus by mutableStateOf("GOLD")
        private set

    // Weather simulation
    var currentTemperature by mutableStateOf(19) // °C
    var currentWeatherCondition by mutableStateOf("Partly Clear")

    // Active Station Node selected
    var selectedStationNode by mutableStateOf("Sheffield Central")
        private set

    init {
        // Populate initial data if empty
        viewModelScope.launch {
            val tickets = repository.allTickets.first()
            if (tickets.isEmpty()) {
                prepopulateDatabase()
            }
        }
        
        // Start live train position updating loop
        startLiveTrainUpdates()
    }

    // Stations static data
    val stationNodes = listOf(
        StationNodeInfo(
            name = "Sheffield Central",
            city = "Sheffield",
            code = "SHF",
            heritage = "Founded in 1870, once the central arterial shipping node for the world's finest crucible steel.",
            modernIdentity = "Reborn as the Clean Energy Innovation Hub. Powering zero-emission ultra-high-speed magnetic spines across the Peak District.",
            bicycleHireAvailable = 24,
            localRecs = listOf("Steam & Steel Espresso (Platform 1)", "The Cutlery Works Express", "Kelham Island Eco-Brews"),
            culturalHighlights = "Sits directly on the historic Sheaf Valley. Surrounded by the advanced manufacturing park, universities, and instant Peak District national trails.",
            departures = listOf(
                LiveDeparture("07:42", "Manchester Piccadilly", "5", "ON TIME"),
                LiveDeparture("07:55", "Leeds Innovation", "2B", "ON TIME"),
                LiveDeparture("08:12", "London Kings Cross", "1A", "SLIGHT DELAY", 4),
                LiveDeparture("08:30", "Liverpool Lime St", "6", "ON TIME")
            )
        ),
        StationNodeInfo(
            name = "Manchester Piccadilly",
            city = "Manchester",
            code = "MAN",
            heritage = "The birthplace of the industrial revolution, linking Victorian cotton grids to global commerce.",
            modernIdentity = "Digital Nervous Core of the North. Connecting MediaCityUK and the Turing AI institutes via holographic terminal halls.",
            bicycleHireAvailable = 45,
            localRecs = listOf("Turing Coffee Labs", "Northern Quarter Micro-bites", "Ancoats Green Market"),
            culturalHighlights = "Renowned for musical innovation, computer science heritage, and community-driven street art festivals.",
            departures = listOf(
                LiveDeparture("07:50", "Liverpool Lime St", "14", "ON TIME"),
                LiveDeparture("08:05", "Newcastle Cyber", "11", "ON TIME"),
                LiveDeparture("08:24", "York Heritage", "8", "ON TIME"),
                LiveDeparture("08:42", "Sheffield Central", "3", "ON TIME")
            )
        ),
        StationNodeInfo(
            name = "Leeds Innovation",
            city = "Leeds",
            code = "LDS",
            heritage = "Major Yorkshire wool textile exchange built atop Victorian circular arches.",
            modernIdentity = "Hyper-growth financial and health-tech corridor, featuring integrated carbon-neutral architectural biodomes.",
            bicycleHireAvailable = 38,
            localRecs = listOf("The Arcades Espresso", "Corn Exchange Vegan Bites", "Granary Wharf Water-Taxi"),
            culturalHighlights = "Home of the royal armouries, modern dance companies, and Leeds university research parks.",
            departures = listOf(
                LiveDeparture("07:55", "Sheffield Central", "4", "ON TIME"),
                LiveDeparture("08:10", "York Heritage", "1C", "ON TIME"),
                LiveDeparture("08:15", "Newcastle Cyber", "2", "SLIGHT DELAY", 3),
                LiveDeparture("08:35", "Manchester Piccadilly", "5", "ON TIME")
            )
        ),
        StationNodeInfo(
            name = "Newcastle Cyber",
            city = "Newcastle",
            code = "NCL",
            heritage = "Victorian engineering icon bridging the Tyne with George Stephenson's original locomotive architecture.",
            modernIdentity = "The coastal renewable intelligence and quantum cryptography hub of Northern Britain.",
            bicycleHireAvailable = 15,
            localRecs = listOf("Grey Street Micro-roasters", "Quayside Baltic Eats", "Ouseburn Creative Valley"),
            culturalHighlights = "Dramatic Tyne Bridge views, coastal marine reserves nearby, and a thriving digital start-up community.",
            departures = listOf(
                LiveDeparture("08:00", "York Heritage", "3", "ON TIME"),
                LiveDeparture("08:20", "Edinburgh Waverley", "2", "ON TIME"),
                LiveDeparture("08:45", "Manchester Piccadilly", "4", "ON TIME")
            )
        )
    )

    fun selectStation(stationName: String) {
        if (stationNodes.any { it.name == stationName }) {
            selectedStationNode = stationName
        }
    }

    // Interactive journey planning purchase simulator
    fun simulateTicketPurchase(from: String, to: String, ticketType: String, price: Double) {
        viewModelScope.launch {
            val formattedDate = "14 JUL 2026"
            val formattedTime = "08:15"
            val classType = "Standard"
            val newTicket = Ticket(
                fromStation = from,
                toStation = to,
                date = formattedDate,
                time = formattedTime,
                price = price,
                status = "ACTIVE",
                classType = classType,
                ticketType = ticketType,
                qrCodeData = "NORTHERN_PASS_${System.currentTimeMillis()}",
                loyaltyPoints = (price * 2).toInt()
            )
            repository.insertTicket(newTicket)
            
            // Add user benefits
            co2SavedKg += 11.2f
            pointsBalance += (price * 2).toInt()
            if (pointsBalance > 1000) {
                activeMobilityStatus = "PLATINUM"
            }
        }
    }

    fun deleteTicket(id: Int) {
        viewModelScope.launch {
            repository.deleteTicket(id)
        }
    }

    // Conversational NORA client trigger
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        
        viewModelScope.launch {
            // Save user message
            val userMsg = ChatMessage(text = text, isFromUser = true)
            repository.insertMessage(userMsg)
            
            isNoraTyping = true
            
            // Artificial delay to look like thinking / generating content
            delay(1200)
            
            // Get history to provide conversational context
            val currentHistory = chatHistory.value
            
            val aiResponse = repository.askNora(text, currentHistory)
            
            // Save NORA response
            val aiMsg = ChatMessage(text = aiResponse, isFromUser = false)
            repository.insertMessage(aiMsg)
            
            isNoraTyping = false
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChatHistory()
            // Add introductory message back
            repository.insertMessage(
                ChatMessage(
                    text = "Welcome to the **NORTHERN // HYPERLINK** network. I am NORA, your cognitive transit coordinator. How can I guide your journey today across the North?",
                    isFromUser = false
                )
            )
        }
    }

    // Prepopulate DB for incredible user out-of-the-box experience
    private suspend fun prepopulateDatabase() {
        // Welcome Chat
        repository.insertMessage(
            ChatMessage(
                text = "Welcome to the **NORTHERN // HYPERLINK** network. I am NORA, your cognitive transit coordinator. How can I guide your journey today across the North?",
                isFromUser = false
            )
        )
        repository.insertMessage(
            ChatMessage(
                text = "Sheffield to Manchester tomorrow morning before 9",
                isFromUser = true
            )
        )
        repository.insertMessage(
            ChatMessage(
                text = "**NORA // TRANSIT ROUTING ENGINE ACTIVE**\n\nThree optimal routes detected for tomorrow morning:\n\n1. 🟢 **07:42 Direct Service** — fastest (51 mins)\n2. 🔋 **07:55 Quiet-Eco Service** — quieter carriage, low crowd (58 mins)\n3. 🪙 **08:10 Network Saver** — cheapest, smart-optimized fare (£8.40)\n\nLet me know which option matches your flow!",
                isFromUser = false
            )
        )

        // Prepopulate standard Active Ticket
        repository.insertTicket(
            Ticket(
                fromStation = "Sheffield Central",
                toStation = "Manchester Piccadilly",
                date = "13 JUL 2026",
                time = "07:42",
                price = 14.50,
                status = "ACTIVE",
                classType = "Standard",
                ticketType = "Single",
                qrCodeData = "NORTHERN_PASS_773919",
                loyaltyPoints = 29
            )
        )
        
        repository.insertTicket(
            Ticket(
                fromStation = "Leeds Innovation",
                toStation = "York Heritage",
                date = "10 JUL 2026",
                time = "14:15",
                price = 9.20,
                status = "EXPIRED",
                classType = "Standard",
                ticketType = "Single",
                qrCodeData = "NORTHERN_PASS_552123",
                loyaltyPoints = 18
            )
        )
    }

    // Simulates live train coordinates moving on a schedule for the Live Map Screen
    private fun startLiveTrainUpdates() {
        // Initialize 6 live trains on map
        liveTrains = listOf(
            LiveTrain("NT101", "Pennine Bullet", "Manchester", "Leeds", 0.35f, 185, 45, "ON TIME", 0.2f, 0.4f),
            LiveTrain("NT102", "Trans-Mersey Liner", "Liverpool", "Manchester", 0.72f, 160, 80, "ON TIME", 0.5f, 0.6f),
            LiveTrain("NT103", "Sheaf Valley Express", "Sheffield", "Manchester", 0.42f, 140, 35, "ON TIME", 0.35f, 0.48f),
            LiveTrain("NT104", "Yorkshire Heritage", "Leeds", "York", 0.15f, 120, 20, "ON TIME", 0.7f, 0.25f),
            LiveTrain("NT105", "Tyne Coastal Shuttl", "Newcastle", "York", 0.82f, 210, 60, "ON TIME", 0.8f, 0.15f),
            LiveTrain("NT106", "Cumbrian Gateway", "Lancaster", "Manchester", 0.55f, 150, 48, "SLIGHT DELAY", 0.15f, 0.3f)
        )

        viewModelScope.launch {
            while (true) {
                delay(3000) // Update coordinates every 3s
                
                // Animate trains
                liveTrains = liveTrains.map { train ->
                    var nextProgress = train.progress + 0.015f
                    if (nextProgress > 1.0f) {
                        nextProgress = 0.0f
                    }
                    
                    // Simulate speed variations slightly
                    val speedVariation = Random.nextInt(-5, 6)
                    val nextSpeed = (train.speedKmph + speedVariation).coerceIn(110, 240)
                    
                    // Path coordinate offsets representation
                    val (x, y) = getCoordinatesOnPath(train.origin, train.destination, nextProgress)
                    
                    train.copy(
                        progress = nextProgress,
                        speedKmph = nextSpeed,
                        xOffsetFactor = x,
                        yOffsetFactor = y
                    )
                }

                // Simulate Journey Mode changes
                activeJourneySecondsToArrival = (activeJourneySecondsToArrival - 3).coerceAtLeast(0)
                if (activeJourneySecondsToArrival == 0) {
                    activeJourneySecondsToArrival = 600
                    activeJourneyProgress = 0.0f
                } else {
                    activeJourneyProgress = (600 - activeJourneySecondsToArrival) / 600.0f
                }
            }
        }
    }

    // Helper map route drawing coords
    private fun getCoordinatesOnPath(origin: String, destination: String, progress: Float): Pair<Float, Float> {
        val startCoords = getStationAnchorCoords(origin)
        val endCoords = getStationAnchorCoords(destination)
        val x = startCoords.first + (endCoords.first - startCoords.first) * progress
        val y = startCoords.second + (endCoords.second - startCoords.second) * progress
        return Pair(x, y)
    }

    private fun getStationAnchorCoords(station: String): Pair<Float, Float> {
        return when (station) {
            "Lancaster" -> Pair(0.15f, 0.25f)
            "Liverpool" -> Pair(0.15f, 0.65f)
            "Manchester" -> Pair(0.35f, 0.55f)
            "Sheffield" -> Pair(0.48f, 0.72f)
            "Leeds" -> Pair(0.55f, 0.45f)
            "York" -> Pair(0.70f, 0.35f)
            "Newcastle" -> Pair(0.75f, 0.10f)
            else -> Pair(0.5f, 0.5f)
        }
    }
}
