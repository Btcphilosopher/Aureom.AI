package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = ElectricBlue,
    onPrimary = GraphiteDark,
    secondary = EmeraldGreen,
    onSecondary = GraphiteDark,
    tertiary = DeepElectricBlue,
    background = GraphiteDark,
    onBackground = Color.White,
    surface = GraphiteMedium,
    onSurface = SilverMetallic,
    surfaceVariant = GraphiteLight,
    onSurfaceVariant = Color.White
  )

private val LightColorScheme = DarkColorScheme // Default to high-contrast hypermodern dark theme for both to preserve the unique 2035 rail command deck aesthetic


@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
