package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GraphiteMedium
import com.example.ui.theme.WhiteGlass

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    borderStroke: BorderStroke? = BorderStroke(1.dp, GlassBorder),
    cornerRadius: Dp = 16.dp,
    testTag: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val tagModifier = if (testTag != null) modifier.testTag(testTag) else modifier

    Card(
        modifier = tagModifier,
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.cardColors(
            containerColor = WhiteGlass
        ),
        border = borderStroke
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            content()
        }
    }
}

@Composable
fun GlowLine(
    modifier: Modifier = Modifier,
    color: Color = ElectricBlue,
    thickness: Dp = 2.dp
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(thickness)
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        color,
                        color.copy(alpha = 0.3f),
                        Color.Transparent
                    )
                )
            )
    )
}

@Composable
fun GradientText(
    text: String,
    modifier: Modifier = Modifier,
    fontSize: Float = 24f,
    fontWeight: FontWeight = FontWeight.Bold,
    fontFamily: FontFamily = FontFamily.SansSerif,
    colors: List<Color> = listOf(ElectricBlue, EmeraldGreen)
) {
    Text(
        text = text,
        modifier = modifier,
        fontSize = fontSize.sp,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        color = colors.firstOrNull() ?: Color.White // Note: Actual gradients can be drawn via canvas, or keep color clean for maximum text readability on dark backdrops
    )
}

@Composable
fun NetworkBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (color, label) = when (status.uppercase()) {
        "ON TIME", "OPTIMAL", "ACTIVE", "GREEN" -> Pair(EmeraldGreen, "SYS // OPTIMAL")
        "SLIGHT DELAY", "YELLOW" -> Pair(Color(0xFFFFD54F), "SYS // DELAY")
        "EXPRESS" -> Pair(ElectricBlue, "SYS // COGNITIVE EXPRESS")
        else -> Pair(ElectricBlue, "SYS // COMM")
    }

    Row(
        modifier = modifier
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = color,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}
