# RailOS — Railway Intelligence & Operations Platform

> A production-grade railway network simulation, scheduling, and real-time dispatch optimisation system.

```
╔══════════════════════════════════════════════════════════════╗
║         RAILOS  //  NATIONAL OPERATIONS CONTROL  //  v1.0   ║
╚══════════════════════════════════════════════════════════════╝
```

---

## Table of Contents

1. [Overview](#overview)
2. [System Architecture](#system-architecture)
3. [Installation](#installation)
4. [Quick Start](#quick-start)
5. [Operating Modes](#operating-modes)
6. [Module Reference](#module-reference)
7. [Railway Network Model](#railway-network-model)
8. [Timetable Generation](#timetable-generation)
9. [Simulation Engine](#simulation-engine)
10. [Disruption Model](#disruption-model)
11. [Optimisation Engine](#optimisation-engine)
12. [Dispatch & Control](#dispatch--control)
13. [Analytics](#analytics)
14. [API Reference](#api-reference)
15. [Control Dashboard](#control-dashboard)
16. [Modelling Assumptions](#modelling-assumptions)
17. [Scheduling Logic](#scheduling-logic)
18. [Example Scenarios](#example-scenarios)
19. [Testing](#testing)
20. [Extension Points](#extension-points)

---

## Overview

RailOS is a **dynamic railway operating system** that models infrastructure, trains, demand, and disruptions to continuously generate and optimise schedules in real time.

It is **not** a static timetable display. It is a live simulation environment with:

- **Graph-based network modelling** using NetworkX
- **Physics-informed travel time computation** (acceleration, deceleration, cruising)
- **Probabilistic delay generation** with configurable severity distributions
- **Cascade propagation** of delays across dependent services
- **Constraint-based optimisation** with priority rules and conflict resolution
- **Disruption handling** with automated recovery planning
- **Decision support** with human-readable dispatch recommendations
- **Real-time control dashboard** (Plotly Dash)
- **FastAPI REST interface** for external integration
- **Full test suite** with 40+ tests across all subsystems

---

## System Architecture

```
railos/
├── core/
│   ├── time_model.py        # SimClock, service periods, time utilities
│   └── config.py            # SimulationConfig, Priority, ServiceType enums
│
├── network/
│   ├── graph_model.py       # RailNetwork — directed weighted graph
│   ├── stations.py          # Station, Platform models
│   ├── tracks.py            # TrackSegment, SignalBlock, TrackClass
│   └── capacity_model.py    # CapacityMonitor, real-time utilisation
│
├── rolling_stock/
│   ├── train_model.py       # Train state machine, RollingStockClass
│   └── performance.py       # Physics-based journey time calculation
│
├── timetable/
│   ├── service_definition.py  # ServiceDefinition, ServiceInstance, ScheduledStop
│   ├── timetable_generator.py # TimetableGenerator, Timetable
│   └── schedule_store.py      # ScheduleStore — central timetable registry
│
├── simulation/
│   ├── engine.py            # SimulationEngine — main tick loop
│   ├── train_dynamics.py    # Per-train state machine
│   ├── delay_model.py       # Stochastic delay generation + cascade
│   └── congestion_model.py  # Network congestion assessment
│
├── optimisation/
│   ├── scheduler.py         # OptimisationScheduler — main optimisation loop
│   ├── conflict_resolver.py # ConflictResolver — platform + track conflicts
│   └── priority_rules.py    # PriorityRuleEngine — configurable ranking
│
├── disruption/
│   ├── incident_model.py    # Incident, IncidentRegistry
│   └── recovery_planner.py  # RecoveryPlanner — automated recovery strategies
│
├── dispatch/
│   ├── decision_engine.py   # DecisionEngine — recommendation generation
│   └── control_tower.py     # ControlTower — unified operational brain
│
├── analytics/
│   ├── performance_metrics.py  # KPI computation, delay statistics
│   └── punctuality_reports.py  # Full-day performance reports
│
├── api/
│   └── server.py            # FastAPI REST server
│
├── ui/
│   ├── control_dashboard.py # Plotly Dash control room interface
│   └── network_visualiser.py # Static/animated Plotly network diagrams
│
├── scenarios/
│   └── example_network.py   # Pre-built British national rail network
│
├── utils/
│   ├── logging.py           # SimLogger with sim-time context
│   └── math_utils.py        # Haversine, percentile, normalise helpers
│
├── tests/
│   └── test_railos.py       # 40+ tests across all modules
│
├── main.py                  # CLI entry point
├── requirements.txt
└── setup.py
```

### Data Flow

```
ServiceDefinitions ──► TimetableGenerator ──► Timetable
                                                   │
                                           ScheduleStore
                                                   │
                                        SimulationEngine (tick loop)
                                         │         │
                                TrainDynamics  DelayModel
                                         │         │
                                    CongestionModel
                                         │
                               OptimisationScheduler
                                    │         │
                         ConflictResolver  PriorityRules
                                         │
                             IncidentRegistry
                                    │
                            RecoveryPlanner
                                    │
                           DecisionEngine ──► Recommendations
                                    │
                            ControlTower ──► ControlSnapshot
                                    │
                         ┌──────────┴──────────┐
                    FastAPI Server       Dash Dashboard
```

---

## Installation

### Requirements

- Python 3.11+
- pip

### Setup

```bash
# Clone / extract
cd railos

# Install dependencies
pip install -r requirements.txt

# Or install as package
pip install -e .
```

---

## Quick Start

### Headless simulation

```bash
python main.py --mode sim --ticks 200 --seed 42
```

Sample output:
```
► Building network...
  24 stations | 58 segments | connected=True
► Generating timetable...
  847 services | types: {'EXPRESS': 142, 'INTERCITY': 98, ...}
► Running 200 ticks...
  [05:00] trains=  0 | delayed=  0 | OTR=100.0% | flow=100.0%
  [05:10] trains=  4 | delayed=  0 | OTR=100.0% | flow= 98.2%
  [06:20] trains= 23 | delayed=  3 | OTR= 87.0% | flow= 91.4%
  ...
```

### Disruption scenario

```bash
python main.py --mode disruption
```

### Launch API server

```bash
python main.py --mode api --port 8000
# Docs at http://localhost:8000/docs
```

### Launch control dashboard

```bash
python main.py --mode dashboard --port 8050
# Open http://localhost:8050
```

### Programmatic usage

```python
from railos.scenarios.example_network import build_example_network, build_example_timetable
from railos.timetable.schedule_store import ScheduleStore
from railos.dispatch.control_tower import ControlTower
from railos.core.config import SimulationConfig

net   = build_example_network()
store = ScheduleStore()
store.load_timetable(build_example_timetable(net))
tower = ControlTower(net, store, SimulationConfig(random_seed=42))

for _ in range(100):
    snap = tower.tick()
    print(f"{snap.time_str} | OTR={snap.on_time_rate:.1%}")
```

---

## Operating Modes

| Mode | Description | Entry Point |
|------|-------------|-------------|
| `PLANNING_MODE` | Static timetable generation, no simulation | `TimetableGenerator` |
| `SIMULATION_MODE` | Full stochastic simulation with delays | `SimulationEngine` |
| `LIVE_OPERATIONS` | Real-time dispatch optimisation loop | `ControlTower` |

Set via `SimulationConfig(mode=OperatingMode.SIMULATION_MODE)`.

---

## Module Reference

### `core.time_model`

- `SimClock(start_seconds, tick_seconds)` — discrete sim clock
- `hhmm_to_seconds("HH:MM")` / `seconds_to_hhmm(int)`
- `ServicePeriod` — named period with headway and time window
- `ALL_PERIODS` — standard operating day periods

### `core.config`

- `SimulationConfig` — all tunable system parameters
- `Priority(EXPRESS=1 … FREIGHT=5)` — service priority enum
- `ServiceType` — EXPRESS, INTERCITY, REGIONAL, LOCAL, FREIGHT
- `PerformanceThresholds` — on-time window, target punctuality

---

## Railway Network Model

The network is modelled as a **directed weighted graph** using NetworkX:

```
Nodes   = Stations | Junctions | Depots
Edges   = TrackSegments (travel time as weight)
```

### Station model

```python
Station(
    station_id, name, crp_code,
    platforms=[Platform(...)],
    lat, lon,
    is_major, is_terminus,
    demand_weight,
)
```

### Track segment model

```python
TrackSegment(
    from_node, to_node,
    distance_km,
    track_class=TrackClass.MAIN_LINE,   # MAIN_LINE | HIGH_SPEED | REGIONAL | BRANCH | YARD
    max_trains=2,           # simultaneous occupancy
    bidirectional=True,
)
```

**Speed limits by class:**

| Class | Max Speed |
|-------|-----------|
| HIGH_SPEED | 250 km/h |
| MAIN_LINE  | 160 km/h |
| REGIONAL   | 110 km/h |
| BRANCH     |  70 km/h |
| YARD       |  25 km/h |

### Example network

`build_example_network()` constructs a British-style national network:

```
WCML:      London Euston → Watford → Milton Keynes → Coventry → Birmingham → Crewe → Manchester
GWR:       London Paddington → Reading → Swindon → Bristol
ECML:      London Kings Cross → Doncaster → Leeds → York → Newcastle → Edinburgh
MML:       Kings Cross → Leicester → Nottingham
Cross:     Birmingham → Sheffield → Leeds
Commuter:  Euston → Northampton
```

24 stations, 58 directed segments, fully connected.

---

## Timetable Generation

### Service definition

```python
ServiceDefinition(
    service_def_id="WCML_EXP",
    name="West Coast Express",
    service_type=ServiceType.EXPRESS,
    priority=Priority.EXPRESS,
    origin_id="STA_EUS",
    destination_id="STA_BHM",
    route=["STA_EUS", "STA_MKC", "STA_BHM"],
    stops=[StopSpec("STA_EUS", dwell_seconds=120), ...],
    rolling_stock_class=CLASS_395,
    headway_seconds=1800,
)
```

### Generation

```python
gen = TimetableGenerator(network)
timetable = gen.generate_full_day(service_def)
```

**Period-aware scheduling:**

| Period | Window | Headway |
|--------|--------|---------|
| EARLY_MORNING | 05:00–06:29 | 30 min |
| MORNING_PEAK  | 06:30–09:29 | 10 min |
| INTER_PEAK    | 09:30–16:29 | 20 min |
| EVENING_PEAK  | 16:30–19:29 | 10 min |
| EVENING       | 19:30–22:29 | 30 min |
| LATE_NIGHT    | 22:30–04:59 | 60 min |

Stop times are computed from **physics-based travel times** plus dwell times at each stop. Downstream stops are propagated automatically.

---

## Simulation Engine

### Architecture

The engine uses a **time-stepped** model with 30-second ticks (configurable):

```
Each tick:
  1. Activate services due for departure
  2. For each train: advance state machine
  3. Assess network congestion
  4. Build SimulationFrame snapshot
```

### Train state machine

```
DEPOT → IDLE → BOARDING → DEPARTING → EN_ROUTE → ARRIVING
                                          ↓
                                    (next segment)
                                          ↓
                                    TERMINATED | FAILED
```

### Delay model

Primary delays are sampled stochastically:
- 60% minor (30–180 s)
- 25% moderate (3–10 min)
- 10% severe (10–30 min)
- 5% critical (30–60 min)

**Cascade propagation:** each hop transmits 70% of the source delay:
```
delay_at_hop_n = source_delay × 0.7^n
```
Cascade stops when propagated delay falls below 30 seconds or `max_cascade_depth` is reached.

### Congestion

Segment congestion factor: `1.0 + occupancy_fraction`

At full occupancy, travel times double. Queuing behaviour holds trains at segment entry until capacity is available.

---

## Disruption Model

### Incident types

| Type | Effect |
|------|--------|
| `TRACK_CLOSURE` | Closes segment, triggers rerouting |
| `PLATFORM_FAULT` | Reduces available platforms at station |
| `ROLLING_STOCK_FAIL` | Injects delay, flags train |
| `SIGNAL_FAILURE` | Triggers speed restriction |
| `WEATHER` | Global delay probability increase |

### Creating incidents

```python
tower.apply_track_closure("STA_EUS", "STA_WFJ", duration_seconds=3600)
tower.apply_platform_fault("STA_BHM", "STA_BHM_P1", duration_seconds=900)
tower.apply_rolling_stock_failure("TRN_SVC00001", delay_injection=1800)
```

### Auto-recovery

Incidents auto-clear when `sim_time >= start + duration`. On clearance, segments are reopened and the planner reassesses affected services.

---

## Optimisation Engine

### Strategy

The scheduler uses a **multi-pass heuristic**:

1. **Conflict detection** — scan all stations for platform conflicts, all segments for capacity violations
2. **Priority resolution** — rank competing trains using `PriorityRuleEngine`, hold lower-priority services
3. **Rerouting** — attempt alternative paths avoiding congested/closed segments; reject if overhead > 30%
4. **Rescheduling** — propagate updated departure times downstream for delayed services
5. **Headway regulation** — detect bunched services and hold following train to restore spacing
6. **Cancellation** — flag services delayed beyond `cancellation_threshold_seconds` (default 30 min)

### Priority rules

| Rule | Condition | Effect |
|------|-----------|--------|
| R001 | Express service | −10 priority score |
| R002 | Intercity service | −5 priority score |
| R003 | Delay > 10 min | −8 priority score (recovery priority) |
| R004 | Freight | +20 priority score (lowest) |
| R005 | Load factor > 85% | −3 priority score |

Rules are configurable at runtime:
```python
tower.optimiser.priority_engine.disable_rule("R004")
```

---

## Dispatch & Control

The `ControlTower` is the unified operational brain:

```python
tower = ControlTower(network, store, config)
snap = tower.tick()

print(snap.on_time_rate)          # 0.0–1.0
print(snap.recommendations)       # list[Recommendation]
print(snap.recovery_actions)      # list[RecoveryAction]
```

### Recommendation categories

| Category | Urgency | Example |
|----------|---------|---------|
| `CRITICAL_DELAY` | CRITICAL | "Train TRN_XXX is 31 min late. Consider cancellation." |
| `HOLD` | WARNING | "Hold train for 8 min to avoid platform conflict at STA_BHM." |
| `REROUTE` | WARNING | "Reroute SVC via alternate line due to congestion." |
| `CANCEL` | CRITICAL | "Cancel TRN_XXX — delay exceeds threshold." |
| `ALERT` | WARNING | "Segment SEG_X is congested. Hold entry services." |

### What-if analysis

```python
result = tower.simulate_outcome("REROUTE", train_id="TRN_SVC00042")
# → {"current_otr": 0.87, "projected_otr": 0.92, "recommendation": "APPLY"}
```

---

## Analytics

```python
from railos.analytics.punctuality_reports import PunctualityReporter

reporter = PunctualityReporter(network)
report = reporter.generate_full_day_report(trains, frames, incident_count=3)
print(report.summary_text)
```

### KPIs computed

| KPI | Description |
|-----|-------------|
| `punctuality_rate` | Fraction of services departing ≤3 min late |
| `cancellation_rate` | Fraction of services cancelled |
| `mean_delay_seconds` | Average delay across all services |
| `median_delay_seconds` | Median delay |
| `p95_delay_seconds` | 95th-percentile delay |
| `trains_per_hour` | Network throughput |
| `peak_active_trains` | Maximum simultaneous trains |
| `total_delay_minutes` | Total passenger-facing delay |

---

## API Reference

All endpoints return JSON. Docs available at `/docs` (Swagger UI).

### Network

| Method | Path | Description |
|--------|------|-------------|
| GET | `/network/load` | Network summary + stations |
| GET | `/network/path?origin=&destination=` | Shortest path |
| GET | `/network/bottlenecks?top_n=5` | Top bottleneck nodes |

### Timetable

| Method | Path | Description |
|--------|------|-------------|
| GET | `/timetable/generate` | Full timetable summary |
| GET | `/timetable/station/{id}` | Departures at station |

### Simulation

| Method | Path | Description |
|--------|------|-------------|
| POST | `/simulate/run` | Run N ticks |
| GET | `/simulate/state` | Current sim state |
| GET | `/simulate/trains` | All active trains |

### Disruption

| Method | Path | Description |
|--------|------|-------------|
| POST | `/disruption/apply` | Inject disruption |
| GET | `/disruption/active` | Active incidents |

**Disruption payload:**
```json
{
  "type": "TRACK_CLOSURE",
  "from_node": "STA_EUS",
  "to_node": "STA_WFJ",
  "duration_seconds": 3600,
  "severity": "HIGH"
}
```

### Optimisation

| Method | Path | Description |
|--------|------|-------------|
| POST | `/optimize/run` | Trigger optimisation pass |

### Dispatch

| Method | Path | Description |
|--------|------|-------------|
| GET | `/dispatch/recommendations?n=20` | Latest recommendations |
| POST | `/dispatch/whatif` | What-if scenario analysis |

### Metrics

| Method | Path | Description |
|--------|------|-------------|
| GET | `/metrics/report` | Full performance report |
| GET | `/metrics/delays` | Delay distribution |
| GET | `/health` | System health |

---

## Control Dashboard

Launch with `python main.py --mode dashboard` then visit `http://localhost:8050`.

### Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│ RAILOS // NATIONAL OPERATIONS CONTROL                    SIM: 07:42 │
├──────────────────────────────────────────────────────────────────────┤
│ TRAINS: 47  DELAYED: 8  ON TIME: 83.0%  FLOW: 91%  INCIDENTS: 2    │
├───────────────────────┬──────────────────────┬───────────────────────┤
│  NETWORK MAP          │  DELAY DISTRIBUTION  │  DISPATCH RECS        │
│  [geo scatter plot]   │  [bar chart]         │  [live feed]          │
│                       │                      │                       │
│  ACTIVE TRAINS        │  TIMELINE CHART      │  DISRUPTION CONTROLS  │
│  [tabular list]       │  [area chart]        │  [form + button]      │
│                       │                      │                       │
│                       │  INCIDENTS           │  EVENT LOG            │
│                       │  [list]              │  [scrolling text]     │
└───────────────────────┴──────────────────────┴───────────────────────┘
```

### Disruption controls

From the dashboard you can inject:
- **Track closure** — specify from/to node IDs
- **Platform fault** — specify station ID
- **Rolling stock failure** — specify train ID
- **Delay injection** — specify train ID + delay seconds

All disruptions are applied live to the running simulation.

---

## Modelling Assumptions

### Physics
- Trains accelerate and decelerate linearly at class-specific rates
- Cruising speed = min(train max speed, track speed limit)
- Dwell time = base dwell + 15s per 100 passengers boarding
- Congestion linearly increases travel time: factor = 1 + (occupancy / capacity)

### Demand
- Passenger load is not explicitly modelled; boarding counts are approximated
- `demand_weight` on stations scales relative platform pressure

### Signalling
- Simplified block signalling: each track segment is a single block
- `max_trains` per segment controls simultaneous occupancy
- No aspect signalling, cab signalling, or ETCS modelled

### Scheduling
- All times are wall-clock seconds from midnight (integer)
- Services do not run past midnight by default (day boundary not modelled)
- Turnaround at terminus is not explicitly modelled

### Stochasticity
- Primary delays are i.i.d. per-segment traversal (Bernoulli trial + exponential-like sample)
- Cascade factor (0.7 per hop) is fixed, not drawn from a distribution
- With `random_seed` set, the simulation is fully deterministic

---

## Scheduling Logic

### Timetable construction

1. For each `ServiceDefinition`, compute stop times by walking the route:
   - At origin: departure = scheduled time
   - At each stop: arrival = prev_departure + segment_journey_time; departure = arrival + dwell
2. Repeat for each departure in the service period (using `headway_seconds`)
3. Optionally generate reverse-direction services

### Conflict resolution

**Platform conflict** (more trains than platforms):
1. Rank trains by priority score
2. Highest-priority train gets the first free platform
3. Remaining trains are held or diverted

**Track conflict** (more trains than segment capacity):
1. Rank competing trains
2. Lower-priority trains are held at segment entry
3. Held trains accumulate delay at 30s per tick

### Rerouting decision

Rerouting is attempted when:
- A service is delayed > 5 minutes, AND
- At least one segment on its remaining route is congested (factor > 1.5) or closed

The alternative route is accepted only if:
- It exists and reaches the destination
- Its total travel time overhead is ≤ 30% above the original route

---

## Example Scenarios

### Scenario 1: Morning peak demand

```python
tower = ControlTower(net, store, SimulationConfig(random_seed=42))

# Run through morning peak (06:30–09:30)
# ~200 ticks × 30s = 100 min of sim time
snapshots = tower.run(ticks=200)

# Examine peak congestion
peak_snap = max(snapshots, key=lambda s: s.active_trains)
print(f"Peak: {peak_snap.active_trains} trains at {peak_snap.time_str}")
```

### Scenario 2: WCML overhead line failure

```python
tower.run(ticks=30)                            # Normal operations

# Inject failure at Wembley
tower.apply_track_closure(
    "STA_EUS", "STA_WFJ",
    duration_seconds=3600,
    severity=IncidentSeverity.CRITICAL,
    description="Overhead line failure at Wembley"
)

# Watch system respond
for snap in tower.run(ticks=60):
    if snap.recommendations:
        print(snap.recommendations[0].message)
```

Expected output:
```
[CRITICAL] Train TRN_SVC00003 is 12 min late. Consider cancellation or substitution.
[REROUTE] Reroute TRN_SVC00007 via STA_EUS → STA_KGX → ... (overhead +18%)
[HOLD] Hold TRN_SVC00009 2 min — bunching with TRN_SVC00008 at STA_MKC
```

### Scenario 3: What-if — cancel vs reroute

```python
result_cancel  = tower.simulate_outcome("CANCEL",  train_id="TRN_SVC00005")
result_reroute = tower.simulate_outcome("REROUTE", train_id="TRN_SVC00005")

print(result_cancel["impact_summary"])
# → "Low disruption — service absorbed by adjacent departures."

print(result_reroute["impact_summary"])
# → "Rerouting clears bottleneck and may improve cascade delays."

print(result_reroute["recommendation"])
# → "APPLY"
```

### Scenario 4: Rolling stock cascade failure

```python
tower.run(ticks=20)
trains = tower.engine.active_trains()

# Fail three trains in sequence
for t in trains[:3]:
    tower.apply_rolling_stock_failure(t.train_id, delay_injection=1200)

# Observe cascade
for snap in tower.run(ticks=40):
    critical = [r for r in snap.recommendations if r.urgency == "CRITICAL"]
    if critical:
        print(f"[{snap.time_str}] {len(critical)} critical alerts")
```

---

## Testing

```bash
# Run all tests
pytest railos/tests/ -v

# Run specific test class
pytest railos/tests/test_railos.py::TestNetworkGraph -v
pytest railos/tests/test_railos.py::TestSimulationDeterminism -v
pytest railos/tests/test_railos.py::TestDisruptionRecovery -v

# Run with coverage
pip install pytest-cov
pytest railos/tests/ --cov=railos --cov-report=term-missing
```

### Test coverage

| Class | Tests | Coverage area |
|-------|-------|---------------|
| `TestNetworkGraph` | 13 | Graph connectivity, routing, segment ops, centrality |
| `TestTimetableGeneration` | 11 | Stop times, ordering, store operations, cancellation |
| `TestSimulationDeterminism` | 7 | Determinism, clock, train spawning, delay injection |
| `TestOptimisationStability` | 7 | Conflict detection, priority ranking, rerouting |
| `TestDisruptionRecovery` | 8 | All incident types, auto-clear, recovery planning |
| `TestAnalytics` | 5 | KPI computation, distribution, report generation |
| `TestControlTowerIntegration` | 6 | Tick loop, snapshots, decision engine |
| `TestPhysics` | 5 | Travel times, haversine, utilities |

---

## Extension Points

### Custom priority rules

```python
from railos.optimisation.priority_rules import PriorityRule

my_rule = PriorityRule(
    rule_id="R010",
    description="Night services get recovery priority",
    condition=lambda t: t.planned_departure > 79200,   # after 22:00
    priority_boost=-15,
)
tower.optimiser.priority_engine.add_rule(my_rule)
```

### Custom rolling stock

```python
from railos.rolling_stock.train_model import RollingStockClass

CLASS_374 = RollingStockClass(
    class_id="374",
    name="Eurostar e320",
    max_speed_kmh=320,
    seating_capacity=900,
    length_metres=400,
    acceleration_ms2=0.7,
)
```

### Custom service definitions

Any route through the network graph can become a `ServiceDefinition`. Use `make_station()` and `make_segment()` to extend the network, then define services on top.

### Simulation callbacks

```python
def on_delay(train, sim_time):
    print(f"Alert: {train.train_id} delayed at {sim_time}")

tower.engine.on_train_delayed = on_delay
```

---

## Performance Notes

- A 200-tick simulation of the example network (~850 services) runs in < 2 seconds
- Memory: ~15 MB for the full example network + timetable
- For larger networks (500+ stations), consider reducing `tick_seconds` to 60 or 120
- The dashboard auto-advances every 2 seconds; reduce `dcc.Interval` for faster playback

---

## Licence

RailOS is provided as a demonstration platform. All code is original and may be freely adapted.

---

*RailOS v1.0.0 — Railway Intelligence Platform*
