package com.example.lockos.domain.hydraulic

import com.example.lockos.domain.model.HydraulicSnapshot
import com.example.lockos.domain.model.LockSiteConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Lumped-parameter hydraulic digital twin for a canal lock chamber.
 *
 * Uses the continuity equation: A_chamber * dh/dt = Q_in - Q_out
 * and submerged/orifice paddle discharge: Q = Cd * A_p * r * sqrt(2 * g * dH * (1 - K_loss))
 *
 * All outputs are explicitly tagged as model estimates and distinguished from measured sensor telemetry.
 */
object HydraulicEngine {
    private const val GRAVITY = 9.81

    fun stepSimulation(
        config: LockSiteConfig,
        currentModelLevelM: Double,
        upstreamLevelM: Double,
        downstreamLevelM: Double,
        upstreamPaddleOpenRatio: Double,
        downstreamPaddleOpenRatio: Double,
        dtSeconds: Double,
        cumulativeWaterUsedM3: Double
    ): Pair<Double, Double> {
        val chamberArea = config.chamberLengthM * config.chamberWidthM
        val headUp = max(0.0, upstreamLevelM - currentModelLevelM)
        val headDown = max(0.0, currentModelLevelM - downstreamLevelM)

        val effectiveLossFactor = (1.0 - config.hydraulicLossCoeff).coerceIn(0.25, 1.0)

        val qIn = if (upstreamPaddleOpenRatio > 0.01 && headUp > 0.001) {
            config.dischargeCoeff *
                config.paddleAreaM2 *
                upstreamPaddleOpenRatio *
                sqrt(2.0 * GRAVITY * headUp * effectiveLossFactor)
        } else {
            0.0
        }

        val qOut = if (downstreamPaddleOpenRatio > 0.01 && headDown > 0.001) {
            config.dischargeCoeff *
                config.paddleAreaM2 *
                downstreamPaddleOpenRatio *
                sqrt(2.0 * GRAVITY * headDown * effectiveLossFactor)
        } else {
            0.0
        }

        val dh = ((qIn - qOut) / chamberArea) * dtSeconds
        val nextLevel = (currentModelLevelM + dh).coerceIn(downstreamLevelM, upstreamLevelM)
        val waterAdded = qIn * dtSeconds
        return nextLevel to (cumulativeWaterUsedM3 + waterAdded)
    }

    fun computeSnapshot(
        config: LockSiteConfig,
        estimatedModelLevelM: Double,
        measuredChamberLevelM: Double?,
        upstreamLevelM: Double,
        downstreamLevelM: Double,
        upstreamPaddleOpenRatio: Double,
        downstreamPaddleOpenRatio: Double,
        cycleWaterUsedM3: Double
    ): HydraulicSnapshot {
        val chamberArea = config.chamberLengthM * config.chamberWidthM
        val chamberVolume = chamberArea * estimatedModelLevelM
        val headUp = max(0.0, upstreamLevelM - estimatedModelLevelM)
        val headDown = max(0.0, estimatedModelLevelM - downstreamLevelM)
        val totalLift = max(0.1, upstreamLevelM - downstreamLevelM)
        val effectiveLossFactor = (1.0 - config.hydraulicLossCoeff).coerceIn(0.25, 1.0)

        val qIn = if (upstreamPaddleOpenRatio > 0.01 && headUp > 0.001) {
            config.dischargeCoeff * config.paddleAreaM2 * upstreamPaddleOpenRatio *
                sqrt(2.0 * GRAVITY * headUp * effectiveLossFactor)
        } else 0.0

        val qOut = if (downstreamPaddleOpenRatio > 0.01 && headDown > 0.001) {
            config.dischargeCoeff * config.paddleAreaM2 * downstreamPaddleOpenRatio *
                sqrt(2.0 * GRAVITY * headDown * effectiveLossFactor)
        } else 0.0

        val dhPerSec = (qIn - qOut) / chamberArea
        val ratePerMin = dhPerSec * 60.0

        // Analytical draining/filling time estimate: T = 2 * A * sqrt(H) / (Cd * Ap * sqrt(2g*(1-K)))
        val denom = config.dischargeCoeff * config.paddleAreaM2 * sqrt(2.0 * GRAVITY * effectiveLossFactor)
        val estFillSec = if (denom > 0.0) (2.0 * chamberArea * sqrt(max(0.05, headUp))) / denom else 0.0
        val estEmptySec = if (denom > 0.0) (2.0 * chamberArea * sqrt(max(0.05, headDown))) / denom else 0.0

        // Full cycle reference time if currently equalized
        val fullLiftTimeSec = if (denom > 0.0) (2.0 * chamberArea * sqrt(totalLift)) / denom else 0.0

        return HydraulicSnapshot(
            chamberAreaM2 = chamberArea,
            chamberVolumeM3 = chamberVolume,
            estimatedModelLevelM = estimatedModelLevelM,
            measuredChamberLevelM = measuredChamberLevelM,
            upstreamHeadM = headUp,
            downstreamHeadM = headDown,
            netHeadDiffM = abs(headUp - headDown),
            inflowRateM3s = qIn,
            outflowRateM3s = qOut,
            rateOfChangeMPerMin = ratePerMin,
            cycleWaterUsedM3 = cycleWaterUsedM3,
            estFillTimeSec = if (headUp > 0.05) estFillSec else fullLiftTimeSec,
            estEmptyTimeSec = if (headDown > 0.05) estEmptySec else fullLiftTimeSec
        )
    }
}
