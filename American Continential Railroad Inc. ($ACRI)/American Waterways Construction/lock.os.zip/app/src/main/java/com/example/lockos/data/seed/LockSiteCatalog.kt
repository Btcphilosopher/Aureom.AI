package com.example.lockos.data.seed

import com.example.lockos.domain.model.LockSiteConfig

object LockSiteCatalog {
    val sites: List<LockSiteConfig> = listOf(
        LockSiteConfig(
            lockId = "LOCK-AST-04",
            name = "Lock 04 · Aston Flight",
            waterway = "Birmingham & Fazeley Canal",
            region = "West Midlands Basin",
            chamberLengthM = 28.5,
            chamberWidthM = 5.2,
            normalUpstreamM = 5.40,
            normalDownstreamM = 2.10,
            paddleAreaM2 = 1.35,
            dischargeCoeff = 0.68,
            hydraulicLossCoeff = 0.14,
            controllerId = "PLC-AST-04",
            gatewayId = "GW-AST-01",
            commissionedForAuto = false, // Requires site-specific commissioning; Simulation mode allowed
            assignedOperatorGroup = "Midlands East Control",
            mapNormalizedX = 0.28f,
            mapNormalizedY = 0.34f,
            elevationOrder = 1
        ),
        LockSiteConfig(
            lockId = "LOCK-THM-07",
            name = "Lock 07 · Thamesmead Tidal",
            waterway = "Lower Lea Navigation",
            region = "Thames Estuary Sector",
            chamberLengthM = 34.0,
            chamberWidthM = 6.4,
            normalUpstreamM = 6.20,
            normalDownstreamM = 2.60,
            paddleAreaM2 = 1.75,
            dischargeCoeff = 0.70,
            hydraulicLossCoeff = 0.16,
            controllerId = "PLC-THM-07",
            gatewayId = "GW-THM-02",
            commissionedForAuto = false,
            assignedOperatorGroup = "Estuary Marine Control",
            mapNormalizedX = 0.62f,
            mapNormalizedY = 0.56f,
            elevationOrder = 2
        ),
        LockSiteConfig(
            lockId = "LOCK-GUS-11",
            name = "Lock 11 · Grand Union Summit",
            waterway = "Grand Union Trunk",
            region = "Chiltern Ridge",
            chamberLengthM = 25.0,
            chamberWidthM = 4.8,
            normalUpstreamM = 4.95,
            normalDownstreamM = 1.85,
            paddleAreaM2 = 1.15,
            dischargeCoeff = 0.65,
            hydraulicLossCoeff = 0.12,
            controllerId = "PLC-GUS-11",
            gatewayId = "GW-GUS-04",
            commissionedForAuto = false,
            assignedOperatorGroup = "Summit Water Control",
            mapNormalizedX = 0.78f,
            mapNormalizedY = 0.24f,
            elevationOrder = 3
        )
    )
}
