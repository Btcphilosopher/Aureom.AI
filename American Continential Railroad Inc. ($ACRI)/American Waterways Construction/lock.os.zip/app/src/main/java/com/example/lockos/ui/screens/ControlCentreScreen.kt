package com.example.lockos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.lockos.domain.model.FaultInjectionFlags
import com.example.lockos.domain.model.LockCycleState
import com.example.lockos.domain.model.SavedSimulationItem
import com.example.lockos.domain.model.TravelDirection
import com.example.lockos.domain.model.TwinViewMode
import com.example.lockos.ui.components.ActuatorStatusCard
import com.example.lockos.ui.components.DigitalTwinPanel
import com.example.lockos.ui.components.InterlockChecklistPanel
import com.example.lockos.ui.components.RbacNoticeBanner
import com.example.lockos.ui.components.StatusPill
import com.example.lockos.ui.state.LockOsUiState
import com.example.ui.theme.LocalLockOsColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ControlCentreScreen(
    uiState: LockOsUiState,
    savedSimulations: List<SavedSimulationItem>,
    onSelectTwinView: (TwinViewMode) -> Unit,
    onToggleSensorOverlay: () -> Unit,
    onToggleFaultOverlay: () -> Unit,
    onSpawnApproach: (TravelDirection) -> Unit,
    onOpenRegisterArrival: () -> Unit,
    onRequestCycle: () -> Unit,
    onServicePause: () -> Unit,
    onMaintenanceLockout: () -> Unit,
    onOpenSaveSimulation: () -> Unit,
    onGenerateReport: () -> Unit,
    onFaultToggle: ((FaultInjectionFlags) -> FaultInjectionFlags, String) -> Unit,
    onLoadSnapshot: (SavedSimulationItem) -> Unit,
    onDeleteSnapshot: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    val runtime = uiState.activeRuntime
    val hyd = uiState.hydraulics
    val canControl = uiState.operatorRole.canRequestCycle

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 860.dp)
                .fillMaxSize()
                .padding(horizontal = 12.dp)
                .testTag("control_centre_list"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // 1. System Dashboard Strip
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = runtime.config.waterway.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = sem.mutedLabel
                            )
                            Text(
                                text = runtime.state.cycleState.label,
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        StatusPill(
                            text = if (runtime.commHealthy && !runtime.faults.injectGatewayCommLoss) {
                                "GW ${runtime.gatewayLatencyMs}ms"
                            } else "GW LOST",
                            fg = if (runtime.commHealthy && !runtime.faults.injectGatewayCommLoss) sem.safeGreen else sem.alarmRed,
                            bg = if (runtime.commHealthy && !runtime.faults.injectGatewayCommLoss) sem.safeGreenBg else sem.alarmRedBg
                        )
                    }

                    val stepFraction = if (runtime.state.cycleState.stepNumber > 0) {
                        runtime.state.cycleState.stepNumber / 10f
                    } else 0f
                    LinearProgressIndicator(
                        progress = { stepFraction },
                        modifier = Modifier.fillMaxWidth().height(6.dp),
                        color = sem.telemetryCyan,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricMini("DELTA HEAD", "${"%.2f".format(hyd.upstreamHeadM)} m")
                        MetricMini("RATE dh/dt", "${"%+.2f".format(hyd.rateOfChangeMPerMin)} m/m")
                        MetricMini("CYCLE WATER", "${"%.0f".format(hyd.cycleWaterUsedM3)} m3")
                        MetricMini("VESSEL", runtime.state.vesselPresence.label.take(12))
                    }
                }
            }

            // 2. Interactive Hydraulic Digital Twin
            item {
                DigitalTwinPanel(
                    runtime = runtime,
                    viewMode = uiState.twinViewMode,
                    showSensorOverlay = uiState.showSensorOverlay,
                    showFaultOverlay = uiState.showFaultOverlay,
                    onSelectViewMode = onSelectTwinView,
                    onToggleSensors = onToggleSensorOverlay,
                    onToggleFaults = onToggleFaultOverlay
                )
            }

            // 3. Supervisory Control Deck
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "SUPERVISORY REQUESTS & ORCHESTRATION",
                        style = MaterialTheme.typography.titleSmall,
                        color = sem.telemetryCyan
                    )
                    Text(
                        text = "Supervisory requests never energise hardware directly; ${runtime.config.controllerId} evaluates interlocks before executing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = sem.mutedLabel
                    )

                    if (!canControl) {
                        RbacNoticeBanner(uiState.operatorRole.label)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onRequestCycle,
                            enabled = canControl,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("request_cycle_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("Request Cycle", style = MaterialTheme.typography.labelLarge)
                        }

                        OutlinedButton(
                            onClick = onOpenRegisterArrival,
                            enabled = canControl,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("register_arrival_button")
                        ) {
                            Icon(Icons.Filled.DirectionsBoat, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("Register Arrival", style = MaterialTheme.typography.labelLarge)
                        }
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onSpawnApproach(TravelDirection.UPSTREAM_BOUND) },
                            modifier = Modifier.testTag("spawn_approach_up")
                        ) {
                            Text("Sim Approach (UP)", style = MaterialTheme.typography.labelMedium)
                        }
                        OutlinedButton(
                            onClick = { onSpawnApproach(TravelDirection.DOWNSTREAM_BOUND) },
                            modifier = Modifier.testTag("spawn_approach_dn")
                        ) {
                            Text("Sim Approach (DN)", style = MaterialTheme.typography.labelMedium)
                        }
                        OutlinedButton(
                            onClick = onServicePause,
                            enabled = canControl,
                            modifier = Modifier.testTag("service_pause_button")
                        ) {
                            Icon(Icons.Filled.PauseCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.size(4.dp))
                            Text(
                                if (runtime.state.cycleState == LockCycleState.Paused) "Resume Service" else "Service Pause",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        OutlinedButton(
                            onClick = onMaintenanceLockout,
                            modifier = Modifier.testTag("maintenance_lockout_button")
                        ) {
                            Icon(Icons.Filled.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.size(4.dp))
                            Text("Maint Lockout", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onOpenSaveSimulation,
                            modifier = Modifier.weight(1f).testTag("save_simulation_button")
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("Save Snapshot", style = MaterialTheme.typography.labelMedium)
                        }
                        Button(
                            onClick = onGenerateReport,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary,
                                contentColor = MaterialTheme.colorScheme.onSecondary
                            ),
                            modifier = Modifier.weight(1f).testTag("generate_report_button")
                        ) {
                            Icon(Icons.Filled.Assessment, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("Eng. Report", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            // 4. Local Safety Controller Interlock Evaluation
            item {
                InterlockChecklistPanel(evaluation = uiState.safetyEvaluation)
            }

            // 5. Gate & Paddle Actuators (Commanded vs Measured)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "GATE & PADDLE ACTUATORS (COMMANDED VS MEASURED)",
                        style = MaterialTheme.typography.titleSmall,
                        color = sem.telemetryCyan
                    )
                    val acts = uiState.actuators
                    for (pair in acts.chunked(2)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            pair.forEach { act ->
                                ActuatorStatusCard(
                                    actuator = act,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // 6. Simulation Fault Injection Lab
            item {
                val f = runtime.faults
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = sem.warningAmber, modifier = Modifier.size(18.dp))
                        Text(
                            text = "SIMULATION FAULT INJECTION LAB",
                            style = MaterialTheme.typography.titleSmall,
                            color = sem.warningAmber
                        )
                    }
                    Text(
                        text = "Test how ${runtime.config.controllerId} withholds movement on sensor dropout, mismatch, comm loss, or perimeter intrusion.",
                        style = MaterialTheme.typography.bodySmall,
                        color = sem.mutedLabel
                    )

                    FaultToggleRow(
                        label = "Chamber Water-Level Sensor Dropout (Unknown)",
                        checked = f.injectLevelSensorDropout,
                        tag = "fault_toggle_level",
                        onToggle = {
                            onFaultToggle({ it.copy(injectLevelSensorDropout = !it.injectLevelSensorDropout) }, "Water-level sensor dropout toggled")
                        }
                    )
                    FaultToggleRow(
                        label = "Upstream Gate Position Mismatch",
                        checked = f.injectGatePositionMismatch,
                        tag = "fault_toggle_gate",
                        onToggle = {
                            onFaultToggle({ it.copy(injectGatePositionMismatch = !it.injectGatePositionMismatch) }, "Gate position mismatch toggled")
                        }
                    )
                    FaultToggleRow(
                        label = "Gateway Communication Loss",
                        checked = f.injectGatewayCommLoss,
                        tag = "fault_toggle_comm",
                        onToggle = {
                            onFaultToggle({ it.copy(injectGatewayCommLoss = !it.injectGatewayCommLoss) }, "Gateway communication loss toggled")
                        }
                    )
                    FaultToggleRow(
                        label = "Pedestrian Perimeter Intrusion",
                        checked = f.injectPedestrianIntrusion,
                        tag = "fault_toggle_pedestrian",
                        onToggle = {
                            onFaultToggle({ it.copy(injectPedestrianIntrusion = !it.injectPedestrianIntrusion) }, "Pedestrian protected-zone intrusion toggled")
                        }
                    )
                    FaultToggleRow(
                        label = "Upstream Paddle Torque Jam",
                        checked = f.injectPaddleJam,
                        tag = "fault_toggle_paddle",
                        onToggle = {
                            onFaultToggle({ it.copy(injectPaddleJam = !it.injectPaddleJam) }, "Upstream paddle jam toggled")
                        }
                    )
                }
            }

            // 7. Saved Simulations List
            item {
                Text(
                    text = "SAVED SIMULATION SNAPSHOTS (${savedSimulations.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = sem.telemetryCyan
                )
            }

            if (savedSimulations.isEmpty()) {
                item {
                    Text(
                        text = "No saved snapshots yet. Tap 'Save Snapshot' above to store a deterministic scenario.",
                        style = MaterialTheme.typography.bodySmall,
                        color = sem.mutedLabel,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
            } else {
                items(savedSimulations, key = { it.id }) { snap ->
                    SavedSnapshotRow(
                        item = snap,
                        onLoad = { onLoadSnapshot(snap) },
                        onDelete = { onDeleteSnapshot(snap.id) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun MetricMini(label: String, value: String) {
    val sem = LocalLockOsColors.current
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sem.mutedLabel)
        Text(value, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FaultToggleRow(
    label: String,
    checked: Boolean,
    tag: String,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f).padding(end = 8.dp)
        )
        Switch(
            checked = checked,
            onCheckedChange = { onToggle() },
            modifier = Modifier.testTag(tag)
        )
    }
}

@Composable
private fun SavedSnapshotRow(
    item: SavedSimulationItem,
    onLoad: () -> Unit,
    onDelete: () -> Unit
) {
    val sem = LocalLockOsColors.current
    val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium)
            .border(1.dp, sem.panelBorder, MaterialTheme.shapes.medium)
            .clickable { onLoad() }
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(item.title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
            Text(
                text = "${item.lockId} · Seed #${item.seed} · Ch=${"%.2f".format(item.chamberLevelM)}m · ${item.activeFaultSummary} · ${fmt.format(Date(item.savedAtMs))}",
                style = MaterialTheme.typography.labelSmall,
                color = sem.mutedLabel
            )
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete snapshot", tint = sem.mutedLabel)
        }
    }
}
