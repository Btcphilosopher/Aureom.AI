package com.example.lockos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.lockos.domain.model.QueuePriority
import com.example.lockos.domain.model.QueueStatus
import com.example.lockos.domain.model.VesselArrivalItem
import com.example.lockos.ui.components.RbacNoticeBanner
import com.example.lockos.ui.components.StatusPill
import com.example.lockos.ui.state.LockOsUiState
import com.example.ui.theme.LocalLockOsColors

@Composable
fun QueueScreen(
    uiState: LockOsUiState,
    queueEntries: List<VesselArrivalItem>,
    onOpenRegisterArrival: () -> Unit,
    onRequestCycle: () -> Unit,
    onPromoteEntry: (VesselArrivalItem) -> Unit,
    onCancelEntry: (VesselArrivalItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    var showAllLocks by remember { mutableStateOf(false) }
    val lockId = uiState.selectedLockId
    val canControl = uiState.operatorRole.canRequestCycle

    val displayed = remember(queueEntries, lockId, showAllLocks) {
        val scoped = if (showAllLocks) queueEntries else queueEntries.filter { it.lockId == lockId }
        scoped.filter { it.status != QueueStatus.CANCELLED && it.status != QueueStatus.COMPLETED }
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 860.dp)
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Vessel Detection & Fusion Banner
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "VESSEL DETECTION & QUEUE ORCHESTRATION",
                            style = MaterialTheme.typography.titleSmall,
                            color = sem.telemetryCyan
                        )
                        StatusPill(
                            text = uiState.activeRuntime.state.vesselPresence.label,
                            fg = sem.telemetryCyan,
                            bg = MaterialTheme.colorScheme.primaryContainer
                        )
                    }
                    Text(
                        text = "Radar, LiDAR, Optical, and AIS fusion reports confidence vs certainty. Queue position does not guarantee cycle start; ${uiState.activeRuntime.config.controllerId} enforces physical interlocks.",
                        style = MaterialTheme.typography.bodySmall,
                        color = sem.mutedLabel
                    )

                    if (!canControl) {
                        RbacNoticeBanner(uiState.operatorRole.label)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onOpenRegisterArrival,
                            enabled = canControl,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("queue_register_arrival_btn")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(Modifier.padding(2.dp))
                            Text("Register Arrival")
                        }
                        OutlinedButton(
                            onClick = onRequestCycle,
                            enabled = canControl,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("queue_request_cycle_btn")
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Spacer(Modifier.padding(2.dp))
                            Text("Cycle Next")
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !showAllLocks,
                            onClick = { showAllLocks = false },
                            label = { Text("$lockId Only") },
                            modifier = Modifier.testTag("queue_filter_current")
                        )
                        FilterChip(
                            selected = showAllLocks,
                            onClick = { showAllLocks = true },
                            label = { Text("All Network Locks") },
                            modifier = Modifier.testTag("queue_filter_all")
                        )
                    }
                }
            }

            if (displayed.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                            .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.DirectionsBoat, contentDescription = null, tint = sem.mutedLabel)
                        Text("No Active Vessels Queued", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "Tap 'Register Arrival' or trigger a simulated vessel approach from the Control Centre.",
                            style = MaterialTheme.typography.bodySmall,
                            color = sem.mutedLabel
                        )
                    }
                }
            } else {
                items(displayed, key = { it.id }) { entry ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                            .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                            .padding(12.dp)
                            .testTag("queue_item_${entry.id}"),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                StatusPill(
                                    text = "#${entry.queuePosition}",
                                    fg = sem.telemetryCyan,
                                    bg = MaterialTheme.colorScheme.primaryContainer
                                )
                                Column {
                                    Text(entry.vesselName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = "${entry.lockId} · ${entry.registrationCode} · ${"%.1f".format(entry.lengthM)}m",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = sem.mutedLabel
                                    )
                                }
                            }
                            StatusPill(
                                text = entry.status.label,
                                fg = if (entry.status == QueueStatus.IN_LOCK) sem.safeGreen else sem.warningAmber,
                                bg = if (entry.status == QueueStatus.IN_LOCK) sem.safeGreenBg else sem.warningAmberBg
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${entry.direction.label} · ${entry.priority.label} · Est Wait ${entry.estimatedWaitMin} min",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = entry.detectionSource,
                                style = MaterialTheme.typography.labelSmall,
                                color = sem.mutedLabel,
                                modifier = Modifier.weight(1f)
                            )
                            if (canControl && entry.status == QueueStatus.WAITING) {
                                Row {
                                    if (entry.priority != QueuePriority.EMERGENCY_VESSEL) {
                                        IconButton(
                                            onClick = { onPromoteEntry(entry) },
                                            modifier = Modifier.testTag("promote_queue_${entry.id}")
                                        ) {
                                            Icon(Icons.Filled.ArrowUpward, contentDescription = "Promote vessel priority", tint = sem.telemetryCyan)
                                        }
                                    }
                                    IconButton(
                                        onClick = { onCancelEntry(entry) },
                                        modifier = Modifier.testTag("cancel_queue_${entry.id}")
                                    ) {
                                        Icon(Icons.Filled.Cancel, contentDescription = "Cancel queue entry", tint = sem.alarmRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
