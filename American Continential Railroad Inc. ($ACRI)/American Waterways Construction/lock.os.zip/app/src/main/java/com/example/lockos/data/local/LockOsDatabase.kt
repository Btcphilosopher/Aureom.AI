package com.example.lockos.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SavedSimulationEntity::class,
        QueueEntryEntity::class,
        AlarmEntity::class,
        WorkOrderEntity::class,
        AuditEventEntity::class,
        TelemetrySampleEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LockOsDatabase : RoomDatabase() {
    abstract fun lockOsDao(): LockOsDao

    companion object {
        @Volatile
        private var INSTANCE: LockOsDatabase? = null

        fun getInstance(context: Context): LockOsDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LockOsDatabase::class.java,
                    "lock_os_workstation.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
