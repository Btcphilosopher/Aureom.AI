package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

data class LockOsSemanticColors(
    val safeGreen: Color,
    val safeGreenBg: Color,
    val warningAmber: Color,
    val warningAmberBg: Color,
    val alarmRed: Color,
    val alarmRedBg: Color,
    val telemetryCyan: Color,
    val waterSurface: Color,
    val waterDeep: Color,
    val panelBorder: Color,
    val mutedLabel: Color
)

val LocalLockOsColors = staticCompositionLocalOf {
    LockOsSemanticColors(
        safeGreen = WaterwayGreen,
        safeGreenBg = WaterwayGreenBg,
        warningAmber = AmberWarning,
        warningAmberBg = AmberWarningBg,
        alarmRed = RedAlarm,
        alarmRedBg = RedAlarmBg,
        telemetryCyan = TelemetryCyan,
        waterSurface = WaterwayWater,
        waterDeep = WaterwayDeep,
        panelBorder = SteelBorder,
        mutedLabel = SteelLight
    )
}

private val IndustrialDarkColorScheme = darkColorScheme(
    primary = EngineeringBlue,
    onPrimary = CrispWhite,
    primaryContainer = ElevatedNavy,
    onPrimaryContainer = TelemetryCyan,
    secondary = WaterwayGreen,
    onSecondary = DeepNavy,
    secondaryContainer = WaterwayGreenBg,
    onSecondaryContainer = WaterwayGreen,
    tertiary = TelemetryCyan,
    onTertiary = DeepNavy,
    background = DeepNavy,
    onBackground = CrispWhite,
    surface = PanelNavy,
    onSurface = CrispWhite,
    surfaceVariant = SteelSurface,
    onSurfaceVariant = SteelLight,
    outline = SteelBorder,
    outlineVariant = SteelMuted,
    error = RedAlarm,
    onError = CrispWhite,
    errorContainer = RedAlarmBg,
    onErrorContainer = RedAlarm
)

private val DaylightFieldColorScheme = lightColorScheme(
    primary = EngineeringBlue,
    onPrimary = CrispWhite,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = Color(0xFF059669),
    onSecondary = CrispWhite,
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = Color(0xFF065F46),
    tertiary = WaterwayDeep,
    onTertiary = CrispWhite,
    background = FieldBackground,
    onBackground = FieldNavyInk,
    surface = FieldSurface,
    onSurface = FieldNavyInk,
    surfaceVariant = FieldSurfaceVariant,
    onSurfaceVariant = FieldMutedInk,
    outline = FieldBorder,
    outlineVariant = Color(0xFF94A3B8),
    error = Color(0xFFDC2626),
    onError = CrispWhite,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF991B1B)
)

private val LockOsShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(14.dp),
    extraLarge = RoundedCornerShape(18.dp)
)

@Composable
fun LockOsTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) IndustrialDarkColorScheme else DaylightFieldColorScheme
    val semanticColors = if (darkTheme) {
        LockOsSemanticColors(
            safeGreen = WaterwayGreen,
            safeGreenBg = WaterwayGreenBg,
            warningAmber = AmberWarning,
            warningAmberBg = AmberWarningBg,
            alarmRed = RedAlarm,
            alarmRedBg = RedAlarmBg,
            telemetryCyan = TelemetryCyan,
            waterSurface = WaterwayWater,
            waterDeep = WaterwayDeep,
            panelBorder = SteelBorder,
            mutedLabel = SteelLight
        )
    } else {
        LockOsSemanticColors(
            safeGreen = Color(0xFF059669),
            safeGreenBg = Color(0xFFD1FAE5),
            warningAmber = Color(0xFFD97706),
            warningAmberBg = Color(0xFFFEF3C7),
            alarmRed = Color(0xFFDC2626),
            alarmRedBg = Color(0xFFFEE2E2),
            telemetryCyan = Color(0xFF0284C7),
            waterSurface = Color(0xFF0EA5E9),
            waterDeep = Color(0xFF0369A1),
            panelBorder = FieldBorder,
            mutedLabel = FieldMutedInk
        )
    }

    CompositionLocalProvider(LocalLockOsColors provides semanticColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = LockOsTypography,
            shapes = LockOsShapes,
            content = content
        )
    }
}
