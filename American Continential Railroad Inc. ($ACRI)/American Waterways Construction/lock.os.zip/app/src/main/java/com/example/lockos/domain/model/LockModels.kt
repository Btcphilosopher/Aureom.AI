package com.example.lockos.domain.model

// Section 4: Central Digital Lock Model
data class CanalLockState(
    val lockId: String,
    val upstreamLevelM: Double?,
    val chamberLevelM: Double?,
    val downstreamLevelM: Double?,
    val upstreamGateState: GateState,
    val downstreamGateState: GateState,
    val upstreamPaddleState: PaddleState,
    val downstreamPaddleState: PaddleState,
    val vesselPresence: PresenceState,
    val safetyStatus: SafetyStatus,
    val operatingMode: OperatingMode,
    val cycleState: LockCycleState,
    val lastUpdatedEpochMs: Long
)

enum class GateState(val label: String) {
    Open("OPEN"),
    Closed("CLOSED"),
    Opening("OPENING"),
    Closing("CLOSING"),
    Unknown("UNKNOWN"),
    Faulted("FAULTED")
}

enum class PaddleState(val label: String) {
    Open("OPEN"),
    Closed("CLOSED"),
    Opening("OPENING"),
    Closing("CLOSING"),
    Unknown("UNKNOWN"),
    Faulted("FAULTED")
}

enum class PresenceState(val label: String) {
    Vacant("VACANT"),
    ApproachingUpstream("APPROACHING UPSTREAM"),
    ApproachingDownstream("APPROACHING DOWNSTREAM"),
    OccupiedConfirmed("CHAMBER OCCUPIED"),
    Departing("VESSEL DEPARTING"),
    Uncertain("OCCUPANCY UNCERTAIN"),
    Obstructed("GATE OBSTRUCTED"),
    Unknown("SENSOR UNKNOWN")
}

enum class SafetyStatus(val label: String) {
    SafeAuthorised("SAFE / INTERLOCKS CLEAR"),
    InterlockHold("INTERLOCK HOLD"),
    SensorUncertaintyHold("SENSOR UNCERTAINTY HOLD"),
    FaultLatched("FAULT LATCHED"),
    EmergencyStopLatched("E-STOP LATCHED"),
    MaintenanceLockout("MAINTENANCE LOCKOUT")
}

enum class OperatingMode(val label: String) {
    Simulation("SIMULATION"),
    CommissionedAuto("COMMISSIONED AUTO"),
    LocalManual("LOCAL MANUAL"),
    MaintenanceOutOfService("MAINTENANCE OUT OF SERVICE")
}

enum class LockCycleState(val stepNumber: Int, val label: String) {
    Idle(1, "Idle"),
    VesselApproaching(2, "Vessel Approaching"),
    ArrivalRegistered(3, "Arrival Registered"),
    QueuePositionAssigned(4, "Queue Position Assigned"),
    LocalControllerEvaluating(5, "Controller Evaluating Readiness"),
    AuthorisedCycleInProgress(6, "Authorised Cycle In Progress"),
    ChamberTransitionInProgress(7, "Chamber Transition In Progress"),
    LocalControllerCompleted(8, "Controller Reports Completion"),
    VesselDepartureObserved(9, "Vessel Departure Observed"),
    CycleComplete(10, "Cycle Complete"),
    Cancelled(0, "Cancelled"),
    Paused(0, "Paused"),
    Faulted(0, "Faulted"),
    MaintenanceUnavailable(0, "Maintenance Unavailable"),
    ManualOperation(0, "Manual Operation")
}

enum class TravelDirection(val label: String, val code: String) {
    UPSTREAM_BOUND("Upstream (Ascending)", "UP"),
    DOWNSTREAM_BOUND("Downstream (Descending)", "DN")
}

data class ActuatorTelemetry(
    val id: String,
    val name: String,
    val commandedState: String,
    val measuredState: String,
    val positionPercent: Float,
    val motorHealthPercent: Int,
    val motorCurrentAmps: Double,
    val controllerAvailable: Boolean,
    val faultCode: String? = null,
    val provenance: String
) {
    val hasPositionMismatch: Boolean
        get() = commandedState != measuredState &&
            measuredState != "OPENING" &&
            measuredState != "CLOSING" &&
            faultCode != null
}

enum class SensorType(val label: String) {
    Radar("Radar"),
    LiDAR("LiDAR"),
    Ultrasonic("Ultrasonic"),
    Optical("Optical"),
    Inductive("Inductive"),
    CameraAI("Camera Vision"),
    AIS("AIS Transponder"),
    HydrostaticLevel("Hydrostatic Pressure")
}

enum class SensorZone(val label: String) {
    UpstreamApproach("Upstream Approach"),
    DownstreamApproach("Downstream Approach"),
    Chamber("Lock Chamber"),
    GateThreshold("Gate Threshold"),
    PedestrianPerimeter("Pedestrian Perimeter"),
    MaintenanceZone("Maintenance Zone")
}

enum class SensorHealth(val label: String) {
    Nominal("NOMINAL"),
    Degraded("DEGRADED"),
    Stale("STALE"),
    Faulted("FAULTED"),
    Offline("OFFLINE")
}

data class SensorReading(
    val sensorId: String,
    val name: String,
    val sensorType: SensorType,
    val zone: SensorZone,
    val valueText: String,
    val numericValue: Double?,
    val unit: String,
    val confidence: Double,
    val isCertain: Boolean,
    val health: SensorHealth,
    val isStale: Boolean,
    val redundancyGroup: String,
    val provenanceLabel: String,
    val timestampMs: Long
)

data class LockSiteConfig(
    val lockId: String,
    val name: String,
    val waterway: String,
    val region: String,
    val chamberLengthM: Double,
    val chamberWidthM: Double,
    val normalUpstreamM: Double,
    val normalDownstreamM: Double,
    val paddleAreaM2: Double,
    val dischargeCoeff: Double,
    val hydraulicLossCoeff: Double,
    val controllerId: String,
    val gatewayId: String,
    val commissionedForAuto: Boolean,
    val assignedOperatorGroup: String,
    val mapNormalizedX: Float,
    val mapNormalizedY: Float,
    val elevationOrder: Int
)

data class HydraulicSnapshot(
    val chamberAreaM2: Double,
    val chamberVolumeM3: Double,
    val estimatedModelLevelM: Double,
    val measuredChamberLevelM: Double?,
    val upstreamHeadM: Double,
    val downstreamHeadM: Double,
    val netHeadDiffM: Double,
    val inflowRateM3s: Double,
    val outflowRateM3s: Double,
    val rateOfChangeMPerMin: Double,
    val cycleWaterUsedM3: Double,
    val estFillTimeSec: Double,
    val estEmptyTimeSec: Double,
    val modelNote: String = "Lumped-parameter continuity model (ESTIMATE — not a substitute for site-specific CFD/hydraulic sign-off)"
)

data class InterlockCheck(
    val code: String,
    val title: String,
    val passed: Boolean,
    val detail: String,
    val isCritical: Boolean = true
)

data class SafetyEvaluationResult(
    val controllerId: String,
    val timestampMs: Long,
    val movementPermitted: Boolean,
    val safetyStatus: SafetyStatus,
    val summary: String,
    val checks: List<InterlockCheck>
)

enum class QueuePriority(val label: String) {
    STANDARD("Standard"),
    COMMERCIAL_FREIGHT("Commercial Freight"),
    EMERGENCY_VESSEL("Emergency / Patrol")
}

enum class QueueStatus(val label: String) {
    WAITING("Waiting"),
    CALLED_FORWARD("Called to Approach"),
    IN_LOCK("In Chamber"),
    COMPLETED("Departed"),
    CANCELLED("Cancelled")
}

data class VesselArrivalItem(
    val id: Long = 0,
    val lockId: String,
    val vesselName: String,
    val registrationCode: String,
    val lengthM: Double,
    val direction: TravelDirection,
    val priority: QueuePriority,
    val queuePosition: Int,
    val estimatedWaitMin: Int,
    val status: QueueStatus,
    val detectionSource: String,
    val registeredAtMs: Long
)

enum class AlarmSeverity(val label: String) {
    CRITICAL("CRITICAL"),
    WARNING("WARNING"),
    ADVISORY("ADVISORY")
}

data class AlarmItem(
    val id: Long = 0,
    val lockId: String,
    val code: String,
    val severity: AlarmSeverity,
    val source: String,
    val description: String,
    val timestampMs: Long,
    val acknowledged: Boolean,
    val acknowledgedBy: String? = null,
    val acknowledgedAtMs: Long? = null,
    val resolved: Boolean = false,
    val resolutionNotes: String? = null
)

enum class AssetCategory(val label: String) {
    GATE_MOTOR("Gate Motor"),
    GEARBOX("Gearbox"),
    HYDRAULIC_ACTUATOR("Hydraulic Actuator"),
    PADDLE_MECHANISM("Paddle Mechanism"),
    WATER_LEVEL_SENSOR("Water-Level Sensor"),
    PROXIMITY_SENSOR("Proximity Sensor"),
    LOCAL_CONTROLLER("Local Controller"),
    GATEWAY("Comm Gateway"),
    POWER_SUPPLY("Power Supply")
}

enum class WorkOrderStatus(val label: String) {
    OPEN("Open"),
    IN_PROGRESS("In Progress"),
    LOCKOUT_ACTIVE("LOTO Active"),
    COMPLETED("Completed")
}

data class MaintenanceOrderItem(
    val id: Long = 0,
    val lockId: String,
    val assetCategory: AssetCategory,
    val assetTag: String,
    val title: String,
    val priority: String,
    val status: WorkOrderStatus,
    val physicalLotoRequired: Boolean,
    val technicianNotes: String,
    val scheduledDate: String,
    val createdAtMs: Long
)

enum class OperatorRole(val label: String, val canRequestCycle: Boolean, val canConfigureSystem: Boolean) {
    SENIOR_CONTROL_ENGINEER("Senior Control Engineer", true, true),
    LOCK_OPERATOR("Duty Lock Operator", true, false),
    MAINTENANCE_TECH("Field Maintenance Technician", false, false),
    PUBLIC_OBSERVER("Public Observer (Read-Only)", false, false)
}

data class AuditLogItem(
    val id: Long = 0,
    val timestampMs: Long,
    val actorName: String,
    val actorRole: String,
    val action: String,
    val lockId: String,
    val controllerVerdict: String,
    val provenance: String
)

data class FaultInjectionFlags(
    val injectLevelSensorDropout: Boolean = false,
    val injectGatePositionMismatch: Boolean = false,
    val injectGatewayCommLoss: Boolean = false,
    val injectPedestrianIntrusion: Boolean = false,
    val injectPaddleJam: Boolean = false,
    val eStopLatched: Boolean = false
) {
    val activeCount: Int
        get() = listOf(
            injectLevelSensorDropout,
            injectGatePositionMismatch,
            injectGatewayCommLoss,
            injectPedestrianIntrusion,
            injectPaddleJam,
            eStopLatched
        ).count { it }
}

enum class TwinViewMode(val label: String) {
    TOP_DOWN("Top-Down Plan"),
    SIDE_ELEVATION("Side Elevation"),
    CROSS_SECTION("Cross-Section")
}

data class TelemetryPoint(
    val timestampMs: Long,
    val lockId: String,
    val upstreamM: Double,
    val chamberM: Double,
    val downstreamM: Double,
    val flowRateM3s: Double,
    val isSimulated: Boolean
)

data class SavedSimulationItem(
    val id: Long = 0,
    val title: String,
    val lockId: String,
    val seed: Long,
    val cycleStateLabel: String,
    val chamberLevelM: Double,
    val upstreamLevelM: Double,
    val downstreamLevelM: Double,
    val totalWaterUsedM3: Double,
    val activeFaultSummary: String,
    val savedAtMs: Long
)

data class NetworkLockSummary(
    val config: LockSiteConfig,
    val state: CanalLockState,
    val queueCount: Int,
    val activeAlarmCount: Int,
    val activeFaultsCount: Int,
    val maintenanceNotice: String?,
    val estWaitMin: Int,
    val gatewayLatencyMs: Int?,
    val commHealthy: Boolean
)
