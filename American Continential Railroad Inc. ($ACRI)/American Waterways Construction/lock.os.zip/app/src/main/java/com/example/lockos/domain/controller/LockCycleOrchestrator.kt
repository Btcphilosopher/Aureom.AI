package com.example.lockos.domain.controller

import com.example.lockos.domain.hydraulic.HydraulicEngine
import com.example.lockos.domain.model.ActuatorTelemetry
import com.example.lockos.domain.model.CanalLockState
import com.example.lockos.domain.model.FaultInjectionFlags
import com.example.lockos.domain.model.GateState
import com.example.lockos.domain.model.LockCycleState
import com.example.lockos.domain.model.LockSiteConfig
import com.example.lockos.domain.model.OperatingMode
import com.example.lockos.domain.model.PaddleState
import com.example.lockos.domain.model.PresenceState
import com.example.lockos.domain.model.SafetyStatus
import com.example.lockos.domain.model.SensorHealth
import com.example.lockos.domain.model.SensorReading
import com.example.lockos.domain.model.SensorType
import com.example.lockos.domain.model.SensorZone
import com.example.lockos.domain.model.TravelDirection
import kotlin.math.abs
import kotlin.random.Random

enum class CyclePhase {
    IDLE,
    EVALUATING_INTERLOCKS,
    EQUALIZING_FOR_ENTRY,
    OPENING_ENTRY_GATE,
    VESSEL_ENTERING,
    CLOSING_ENTRY_GATE,
    CHAMBER_TRANSITION,
    OPENING_EXIT_GATE,
    VESSEL_DEPARTING,
    CLOSING_EXIT_GATE,
    COMPLETED_HOLD
}

data class SimulatedLockRuntime(
    val config: LockSiteConfig,
    val state: CanalLockState,
    val estimatedModelLevelM: Double,
    val upstreamGatePercent: Float,
    val downstreamGatePercent: Float,
    val upstreamPaddlePercent: Float,
    val downstreamPaddlePercent: Float,
    val commandedUpGate: GateState,
    val commandedDnGate: GateState,
    val commandedUpPaddle: PaddleState,
    val commandedDnPaddle: PaddleState,
    val cycleWaterUsedM3: Double,
    val totalWaterUsedM3: Double,
    val completedCyclesCount: Int,
    val phase: CyclePhase,
    val phaseElapsedSec: Double,
    val activeDirection: TravelDirection,
    val activeVesselName: String?,
    val vesselProgress: Float, // 0f upstream approach -> 0.5f chamber -> 1.0f downstream exit (or vice versa)
    val approachingVesselDetected: Boolean,
    val approachingDirection: TravelDirection,
    val faults: FaultInjectionFlags,
    val gatewayLatencyMs: Int,
    val commHealthy: Boolean,
    val seed: Long,
    val lastCycleDurationSec: Double,
    val avgCycleDurationSec: Double
) {
    fun buildSensors(nowMs: Long): List<SensorReading> {
        val prng = Random(seed + (nowMs / 1000L))
        val levelNoise = (prng.nextDouble() - 0.5) * 0.006
        val upVal = state.upstreamLevelM
        val chVal = state.chamberLevelM?.let { it + levelNoise }
        val dnVal = state.downstreamLevelM

        val levelHealth = when {
            faults.injectLevelSensorDropout -> SensorHealth.Faulted
            faults.injectGatewayCommLoss -> SensorHealth.Stale
            else -> SensorHealth.Nominal
        }

        val commStale = faults.injectGatewayCommLoss || !commHealthy

        return listOf(
            SensorReading(
                sensorId = "LVL-${config.lockId.takeLast(2)}-UP",
                name = "Upstream Hydrostatic Head",
                sensorType = SensorType.HydrostaticLevel,
                zone = SensorZone.UpstreamApproach,
                valueText = upVal?.let { "%.2f m".format(it) } ?: "UNKNOWN",
                numericValue = upVal,
                unit = "m",
                confidence = if (upVal != null && !commStale) 0.99 else 0.0,
                isCertain = upVal != null && !commStale,
                health = if (commStale) SensorHealth.Stale else SensorHealth.Nominal,
                isStale = commStale,
                redundancyGroup = "RG-UP-LVL (2oo2)",
                provenanceLabel = "SIMULATION: Virtual Pressure Transducer #PT-01",
                timestampMs = nowMs
            ),
            SensorReading(
                sensorId = "LVL-${config.lockId.takeLast(2)}-CH",
                name = "Chamber Dual Water Level",
                sensorType = SensorType.HydrostaticLevel,
                zone = SensorZone.Chamber,
                valueText = if (faults.injectLevelSensorDropout || chVal == null) "UNKNOWN / FAULT" else "%.2f m".format(chVal),
                numericValue = if (faults.injectLevelSensorDropout) null else chVal,
                unit = "m",
                confidence = if (faults.injectLevelSensorDropout || chVal == null) 0.12 else if (commStale) 0.45 else 0.98,
                isCertain = !faults.injectLevelSensorDropout && chVal != null && !commStale,
                health = levelHealth,
                isStale = commStale,
                redundancyGroup = "RG-CH-LVL (Dual Redundant)",
                provenanceLabel = "SIMULATION: Virtual Bubbler + Radar #PT-02A/B",
                timestampMs = nowMs
            ),
            SensorReading(
                sensorId = "LVL-${config.lockId.takeLast(2)}-DN",
                name = "Downstream Tailwater Level",
                sensorType = SensorType.HydrostaticLevel,
                zone = SensorZone.DownstreamApproach,
                valueText = dnVal?.let { "%.2f m".format(it) } ?: "UNKNOWN",
                numericValue = dnVal,
                unit = "m",
                confidence = if (dnVal != null && !commStale) 0.99 else 0.0,
                isCertain = dnVal != null && !commStale,
                health = if (commStale) SensorHealth.Stale else SensorHealth.Nominal,
                isStale = commStale,
                redundancyGroup = "RG-DN-LVL (2oo2)",
                provenanceLabel = "SIMULATION: Virtual Pressure Transducer #PT-03",
                timestampMs = nowMs
            ),
            SensorReading(
                sensorId = "RAD-${config.lockId.takeLast(2)}-AP",
                name = "Approach Radar + AIS Fusion",
                sensorType = SensorType.Radar,
                zone = if (approachingDirection == TravelDirection.UPSTREAM_BOUND) SensorZone.DownstreamApproach else SensorZone.UpstreamApproach,
                valueText = when {
                    approachingVesselDetected -> "TARGET (${approachingDirection.code})"
                    activeVesselName != null -> "TRACKING $activeVesselName"
                    else -> "CLEAR"
                },
                numericValue = if (approachingVesselDetected || activeVesselName != null) 1.0 else 0.0,
                unit = "target",
                confidence = if (commStale) 0.40 else if (approachingVesselDetected) 0.94 else 0.97,
                isCertain = !commStale,
                health = if (commStale) SensorHealth.Stale else SensorHealth.Nominal,
                isStale = commStale,
                redundancyGroup = "RG-APP-FUSION (Radar+AIS)",
                provenanceLabel = "SIMULATION: Virtual 77GHz Radar + AIS",
                timestampMs = nowMs
            ),
            SensorReading(
                sensorId = "LDR-${config.lockId.takeLast(2)}-CH",
                name = "Chamber LiDAR + Ultrasonic Occupancy",
                sensorType = SensorType.LiDAR,
                zone = SensorZone.Chamber,
                valueText = state.vesselPresence.label,
                numericValue = if (state.vesselPresence == PresenceState.OccupiedConfirmed) 1.0 else 0.0,
                unit = "state",
                confidence = if (commStale) 0.35 else 0.96,
                isCertain = !commStale && state.vesselPresence != PresenceState.Uncertain && state.vesselPresence != PresenceState.Unknown,
                health = if (commStale) SensorHealth.Stale else SensorHealth.Nominal,
                isStale = commStale,
                redundancyGroup = "RG-CH-OCC (LiDAR+Ultrasonic)",
                provenanceLabel = "SIMULATION: Virtual 3D LiDAR Curtain",
                timestampMs = nowMs
            ),
            SensorReading(
                sensorId = "PER-${config.lockId.takeLast(2)}-PD",
                name = "Pedestrian & Maintenance Zone Curtain",
                sensorType = SensorType.Optical,
                zone = SensorZone.PedestrianPerimeter,
                valueText = if (faults.injectPedestrianIntrusion) "INTRUSION DETECTED" else "ZONE CLEAR",
                numericValue = if (faults.injectPedestrianIntrusion) 1.0 else 0.0,
                unit = "zone",
                confidence = if (faults.injectPedestrianIntrusion) 0.99 else 0.98,
                isCertain = !commStale,
                health = if (faults.injectPedestrianIntrusion) SensorHealth.Degraded else SensorHealth.Nominal,
                isStale = commStale,
                redundancyGroup = "RG-SIL2-PERIM",
                provenanceLabel = "SIMULATION: Virtual Safety Light Curtain",
                timestampMs = nowMs
            )
        )
    }

    fun buildActuators(): List<ActuatorTelemetry> {
        val controllerOk = !faults.eStopLatched && !faults.injectGatewayCommLoss && commHealthy
        return listOf(
            ActuatorTelemetry(
                id = "ACT-UG-${config.lockId.takeLast(2)}",
                name = "Upstream Miter Gates",
                commandedState = commandedUpGate.label,
                measuredState = state.upstreamGateState.label,
                positionPercent = upstreamGatePercent,
                motorHealthPercent = if (faults.injectGatePositionMismatch) 62 else 97,
                motorCurrentAmps = if (state.upstreamGateState == GateState.Opening || state.upstreamGateState == GateState.Closing) 14.8 else 0.4,
                controllerAvailable = controllerOk,
                faultCode = if (faults.injectGatePositionMismatch) "ERR-IND-MISMATCH" else null,
                provenance = "SIMULATION: Inductive Limit Switches + VFD"
            ),
            ActuatorTelemetry(
                id = "ACT-DG-${config.lockId.takeLast(2)}",
                name = "Downstream Miter Gates",
                commandedState = commandedDnGate.label,
                measuredState = state.downstreamGateState.label,
                positionPercent = downstreamGatePercent,
                motorHealthPercent = 96,
                motorCurrentAmps = if (state.downstreamGateState == GateState.Opening || state.downstreamGateState == GateState.Closing) 15.2 else 0.4,
                controllerAvailable = controllerOk,
                faultCode = null,
                provenance = "SIMULATION: Inductive Limit Switches + VFD"
            ),
            ActuatorTelemetry(
                id = "ACT-UP-${config.lockId.takeLast(2)}",
                name = "Upstream Filling Paddles",
                commandedState = commandedUpPaddle.label,
                measuredState = state.upstreamPaddleState.label,
                positionPercent = upstreamPaddlePercent,
                motorHealthPercent = if (faults.injectPaddleJam) 54 else 98,
                motorCurrentAmps = if (state.upstreamPaddleState == PaddleState.Open || state.upstreamPaddleState == PaddleState.Opening) 8.4 else 0.1,
                controllerAvailable = controllerOk,
                faultCode = if (faults.injectPaddleJam) "ERR-PDL-TORQUE-JAM" else null,
                provenance = "SIMULATION: Hydraulic Cylinder LVDT"
            ),
            ActuatorTelemetry(
                id = "ACT-DP-${config.lockId.takeLast(2)}",
                name = "Downstream Emptying Paddles",
                commandedState = commandedDnPaddle.label,
                measuredState = state.downstreamPaddleState.label,
                positionPercent = downstreamPaddlePercent,
                motorHealthPercent = 95,
                motorCurrentAmps = if (state.downstreamPaddleState == PaddleState.Open || state.downstreamPaddleState == PaddleState.Opening) 8.1 else 0.1,
                controllerAvailable = controllerOk,
                faultCode = null,
                provenance = "SIMULATION: Hydraulic Cylinder LVDT"
            )
        )
    }
}

object LockCycleOrchestrator {

    private const val EQUALIZE_TOLERANCE_M = 0.05
    private const val GATE_RATE_PER_SEC = 0.34f
    private const val PADDLE_RATE_PER_SEC = 0.55f

    fun createInitialRuntime(config: LockSiteConfig, seed: Long, nowMs: Long, withApproachingVessel: Boolean): SimulatedLockRuntime {
        val initialChamber = config.normalDownstreamM
        return SimulatedLockRuntime(
            config = config,
            state = CanalLockState(
                lockId = config.lockId,
                upstreamLevelM = config.normalUpstreamM,
                chamberLevelM = initialChamber,
                downstreamLevelM = config.normalDownstreamM,
                upstreamGateState = GateState.Closed,
                downstreamGateState = GateState.Closed,
                upstreamPaddleState = PaddleState.Closed,
                downstreamPaddleState = PaddleState.Closed,
                vesselPresence = if (withApproachingVessel) PresenceState.ApproachingDownstream else PresenceState.Vacant,
                safetyStatus = SafetyStatus.SafeAuthorised,
                operatingMode = OperatingMode.Simulation,
                cycleState = if (withApproachingVessel) LockCycleState.VesselApproaching else LockCycleState.Idle,
                lastUpdatedEpochMs = nowMs
            ),
            estimatedModelLevelM = initialChamber,
            upstreamGatePercent = 0f,
            downstreamGatePercent = 0f,
            upstreamPaddlePercent = 0f,
            downstreamPaddlePercent = 0f,
            commandedUpGate = GateState.Closed,
            commandedDnGate = GateState.Closed,
            commandedUpPaddle = PaddleState.Closed,
            commandedDnPaddle = PaddleState.Closed,
            cycleWaterUsedM3 = 0.0,
            totalWaterUsedM3 = 1480.0,
            completedCyclesCount = 4,
            phase = CyclePhase.IDLE,
            phaseElapsedSec = 0.0,
            activeDirection = TravelDirection.UPSTREAM_BOUND,
            activeVesselName = null,
            vesselProgress = if (withApproachingVessel) 0.88f else 0.0f,
            approachingVesselDetected = withApproachingVessel,
            approachingDirection = TravelDirection.UPSTREAM_BOUND,
            faults = FaultInjectionFlags(),
            gatewayLatencyMs = 18,
            commHealthy = true,
            seed = seed,
            lastCycleDurationSec = 420.0,
            avgCycleDurationSec = 435.0
        )
    }

    fun tick(
        runtime: SimulatedLockRuntime,
        dtPhysicsSec: Double,
        dtRealSec: Double,
        nowMs: Long
    ): SimulatedLockRuntime {
        var r = runtime
        val cfg = r.config
        val upLevel = cfg.normalUpstreamM
        val dnLevel = cfg.normalDownstreamM

        // Check faults & safety state first
        val sensors = r.buildSensors(nowMs)
        val actuators = r.buildActuators()
        val safetyEval = SafetyLocalController.evaluate(
            config = cfg,
            lockState = r.state,
            sensors = sensors,
            actuators = actuators,
            faults = r.faults,
            commHealthy = r.commHealthy,
            nowMs = nowMs
        )

        // Apply injected fault effects to measured sensor/actuator views
        val measuredChamberLevel: Double? = if (r.faults.injectLevelSensorDropout || r.faults.injectGatewayCommLoss) {
            null
        } else {
            r.estimatedModelLevelM
        }
        val measuredUpLevel: Double? = if (r.faults.injectGatewayCommLoss) null else upLevel
        val measuredDnLevel: Double? = if (r.faults.injectGatewayCommLoss) null else dnLevel

        val measuredUpGate = when {
            r.faults.injectGatePositionMismatch -> GateState.Faulted
            r.faults.injectGatewayCommLoss -> GateState.Unknown
            r.upstreamGatePercent >= 0.99f -> GateState.Open
            r.upstreamGatePercent <= 0.01f -> GateState.Closed
            r.commandedUpGate == GateState.Open -> GateState.Opening
            else -> GateState.Closing
        }
        val measuredDnGate = when {
            r.faults.injectGatewayCommLoss -> GateState.Unknown
            r.downstreamGatePercent >= 0.99f -> GateState.Open
            r.downstreamGatePercent <= 0.01f -> GateState.Closed
            r.commandedDnGate == GateState.Open -> GateState.Opening
            else -> GateState.Closing
        }
        val measuredUpPaddle = when {
            r.faults.injectPaddleJam -> PaddleState.Faulted
            r.faults.injectGatewayCommLoss -> PaddleState.Unknown
            r.upstreamPaddlePercent >= 0.99f -> PaddleState.Open
            r.upstreamPaddlePercent <= 0.01f -> PaddleState.Closed
            r.commandedUpPaddle == PaddleState.Open -> PaddleState.Opening
            else -> PaddleState.Closing
        }
        val measuredDnPaddle = when {
            r.faults.injectGatewayCommLoss -> PaddleState.Unknown
            r.downstreamPaddlePercent >= 0.99f -> PaddleState.Open
            r.downstreamPaddlePercent <= 0.01f -> PaddleState.Closed
            r.commandedDnPaddle == PaddleState.Open -> PaddleState.Opening
            else -> PaddleState.Closing
        }

        // If safety hold / faulted / paused / maintenance, freeze physical actuators safely!
        val isHeldOrPaused = !safetyEval.movementPermitted ||
            r.state.cycleState == LockCycleState.Paused ||
            r.state.cycleState == LockCycleState.MaintenanceUnavailable ||
            r.state.operatingMode == OperatingMode.MaintenanceOutOfService

        if (isHeldOrPaused && r.phase != CyclePhase.IDLE && r.phase != CyclePhase.COMPLETED_HOLD) {
            // De-energize paddles/gates on safety trip (paddles close fail-safe on E-stop)
            val safeUpPaddle = if (r.faults.eStopLatched) (r.upstreamPaddlePercent - 0.8f * dtRealSec.toFloat()).coerceAtLeast(0f) else r.upstreamPaddlePercent
            val safeDnPaddle = if (r.faults.eStopLatched) (r.downstreamPaddlePercent - 0.8f * dtRealSec.toFloat()).coerceAtLeast(0f) else r.downstreamPaddlePercent
            return r.copy(
                upstreamPaddlePercent = safeUpPaddle,
                downstreamPaddlePercent = safeDnPaddle,
                state = r.state.copy(
                    upstreamLevelM = measuredUpLevel,
                    chamberLevelM = measuredChamberLevel,
                    downstreamLevelM = measuredDnLevel,
                    upstreamGateState = measuredUpGate,
                    downstreamGateState = measuredDnGate,
                    upstreamPaddleState = measuredUpPaddle,
                    downstreamPaddleState = measuredDnPaddle,
                    safetyStatus = safetyEval.safetyStatus,
                    cycleState = when {
                        r.state.operatingMode == OperatingMode.MaintenanceOutOfService -> LockCycleState.MaintenanceUnavailable
                        r.state.cycleState == LockCycleState.Paused -> LockCycleState.Paused
                        else -> LockCycleState.Faulted
                    },
                    vesselPresence = if (r.faults.injectPedestrianIntrusion) PresenceState.Obstructed else r.state.vesselPresence,
                    lastUpdatedEpochMs = nowMs
                )
            )
        }

        // Step active cycle state machine
        var phase = r.phase
        var phaseElapsed = r.phaseElapsedSec + dtRealSec
        var cycleState = r.state.cycleState
        var cmdUpGate = r.commandedUpGate
        var cmdDnGate = r.commandedDnGate
        var cmdUpPaddle = r.commandedUpPaddle
        var cmdDnPaddle = r.commandedDnPaddle
        var upGatePct = r.upstreamGatePercent
        var dnGatePct = r.downstreamGatePercent
        var upPaddlePct = r.upstreamPaddlePercent
        var dnPaddlePct = r.downstreamPaddlePercent
        var modelLevel = r.estimatedModelLevelM
        var cycleWater = r.cycleWaterUsedM3
        var totalWater = r.totalWaterUsedM3
        var completedCount = r.completedCyclesCount
        var vesselProg = r.vesselProgress
        var vesselPresence = when {
            r.faults.injectPedestrianIntrusion -> PresenceState.Obstructed
            r.faults.injectGatewayCommLoss -> PresenceState.Unknown
            else -> r.state.vesselPresence
        }
        var activeVessel = r.activeVesselName
        var approaching = r.approachingVesselDetected

        val isUpstreamBound = r.activeDirection == TravelDirection.UPSTREAM_BOUND

        when (phase) {
            CyclePhase.IDLE -> {
                if (approaching && vesselPresence != PresenceState.Obstructed) {
                    vesselPresence = if (r.approachingDirection == TravelDirection.UPSTREAM_BOUND) {
                        PresenceState.ApproachingDownstream
                    } else {
                        PresenceState.ApproachingUpstream
                    }
                    // Gentle approach drift near waiting pontoon
                    val targetApproach = if (r.approachingDirection == TravelDirection.UPSTREAM_BOUND) 0.85f else 0.15f
                    vesselProg += ((targetApproach - vesselProg) * 0.25f * dtRealSec.toFloat())
                }
            }

            CyclePhase.EVALUATING_INTERLOCKS -> {
                cycleState = LockCycleState.LocalControllerEvaluating
                if (phaseElapsed >= 1.6 && safetyEval.movementPermitted) {
                    phase = CyclePhase.EQUALIZING_FOR_ENTRY
                    phaseElapsed = 0.0
                    cycleState = LockCycleState.AuthorisedCycleInProgress
                    cycleWater = 0.0
                }
            }

            CyclePhase.EQUALIZING_FOR_ENTRY -> {
                cycleState = LockCycleState.ChamberTransitionInProgress
                val targetLevel = if (isUpstreamBound) dnLevel else upLevel
                if (abs(modelLevel - targetLevel) <= EQUALIZE_TOLERANCE_M) {
                    cmdUpPaddle = PaddleState.Closed
                    cmdDnPaddle = PaddleState.Closed
                    upPaddlePct = (upPaddlePct - PADDLE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtLeast(0f)
                    dnPaddlePct = (dnPaddlePct - PADDLE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtLeast(0f)
                    if (upPaddlePct <= 0.01f && dnPaddlePct <= 0.01f) {
                        phase = CyclePhase.OPENING_ENTRY_GATE
                        phaseElapsed = 0.0
                    }
                } else if (modelLevel < targetLevel) {
                    cmdUpPaddle = PaddleState.Open
                    cmdDnPaddle = PaddleState.Closed
                    upPaddlePct = (upPaddlePct + PADDLE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtMost(1f)
                    dnPaddlePct = 0f
                } else {
                    cmdDnPaddle = PaddleState.Open
                    cmdUpPaddle = PaddleState.Closed
                    dnPaddlePct = (dnPaddlePct + PADDLE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtMost(1f)
                    upPaddlePct = 0f
                }
            }

            CyclePhase.OPENING_ENTRY_GATE -> {
                cycleState = LockCycleState.AuthorisedCycleInProgress
                if (isUpstreamBound) {
                    if (SafetyLocalController.canOpenGate(false, upLevel, modelLevel, dnLevel, measuredUpGate, measuredUpPaddle)) {
                        cmdDnGate = GateState.Open
                        dnGatePct = (dnGatePct + GATE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtMost(1f)
                        if (dnGatePct >= 0.99f) {
                            phase = CyclePhase.VESSEL_ENTERING
                            phaseElapsed = 0.0
                        }
                    }
                } else {
                    if (SafetyLocalController.canOpenGate(true, upLevel, modelLevel, dnLevel, measuredDnGate, measuredDnPaddle)) {
                        cmdUpGate = GateState.Open
                        upGatePct = (upGatePct + GATE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtMost(1f)
                        if (upGatePct >= 0.99f) {
                            phase = CyclePhase.VESSEL_ENTERING
                            phaseElapsed = 0.0
                        }
                    }
                }
            }

            CyclePhase.VESSEL_ENTERING -> {
                cycleState = LockCycleState.AuthorisedCycleInProgress
                vesselPresence = PresenceState.OccupiedConfirmed
                val targetProg = 0.50f
                val step = 0.22f * dtRealSec.toFloat()
                vesselProg = if (isUpstreamBound) {
                    (vesselProg - step).coerceAtLeast(targetProg)
                } else {
                    (vesselProg + step).coerceAtMost(targetProg)
                }
                if (abs(vesselProg - targetProg) < 0.02f) {
                    vesselProg = 0.50f
                    phase = CyclePhase.CLOSING_ENTRY_GATE
                    phaseElapsed = 0.0
                }
            }

            CyclePhase.CLOSING_ENTRY_GATE -> {
                cycleState = LockCycleState.AuthorisedCycleInProgress
                if (isUpstreamBound) {
                    cmdDnGate = GateState.Closed
                    dnGatePct = (dnGatePct - GATE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtLeast(0f)
                    if (dnGatePct <= 0.01f) {
                        phase = CyclePhase.CHAMBER_TRANSITION
                        phaseElapsed = 0.0
                    }
                } else {
                    cmdUpGate = GateState.Closed
                    upGatePct = (upGatePct - GATE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtLeast(0f)
                    if (upGatePct <= 0.01f) {
                        phase = CyclePhase.CHAMBER_TRANSITION
                        phaseElapsed = 0.0
                    }
                }
            }

            CyclePhase.CHAMBER_TRANSITION -> {
                cycleState = LockCycleState.ChamberTransitionInProgress
                val targetLevel = if (isUpstreamBound) upLevel else dnLevel
                if (abs(modelLevel - targetLevel) <= EQUALIZE_TOLERANCE_M) {
                    cmdUpPaddle = PaddleState.Closed
                    cmdDnPaddle = PaddleState.Closed
                    upPaddlePct = (upPaddlePct - PADDLE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtLeast(0f)
                    dnPaddlePct = (dnPaddlePct - PADDLE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtLeast(0f)
                    if (upPaddlePct <= 0.01f && dnPaddlePct <= 0.01f) {
                        phase = CyclePhase.OPENING_EXIT_GATE
                        phaseElapsed = 0.0
                    }
                } else if (isUpstreamBound) {
                    cmdUpPaddle = PaddleState.Open
                    upPaddlePct = (upPaddlePct + PADDLE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtMost(1f)
                } else {
                    cmdDnPaddle = PaddleState.Open
                    dnPaddlePct = (dnPaddlePct + PADDLE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtMost(1f)
                }
            }

            CyclePhase.OPENING_EXIT_GATE -> {
                cycleState = LockCycleState.LocalControllerCompleted
                if (isUpstreamBound) {
                    if (SafetyLocalController.canOpenGate(true, upLevel, modelLevel, dnLevel, measuredDnGate, measuredDnPaddle)) {
                        cmdUpGate = GateState.Open
                        upGatePct = (upGatePct + GATE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtMost(1f)
                        if (upGatePct >= 0.99f) {
                            phase = CyclePhase.VESSEL_DEPARTING
                            phaseElapsed = 0.0
                        }
                    }
                } else {
                    if (SafetyLocalController.canOpenGate(false, upLevel, modelLevel, dnLevel, measuredUpGate, measuredUpPaddle)) {
                        cmdDnGate = GateState.Open
                        dnGatePct = (dnGatePct + GATE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtMost(1f)
                        if (dnGatePct >= 0.99f) {
                            phase = CyclePhase.VESSEL_DEPARTING
                            phaseElapsed = 0.0
                        }
                    }
                }
            }

            CyclePhase.VESSEL_DEPARTING -> {
                cycleState = LockCycleState.VesselDepartureObserved
                vesselPresence = PresenceState.Departing
                val exitTarget = if (isUpstreamBound) 0.05f else 0.95f
                val step = 0.24f * dtRealSec.toFloat()
                vesselProg = if (isUpstreamBound) {
                    (vesselProg - step).coerceAtLeast(exitTarget)
                } else {
                    (vesselProg + step).coerceAtMost(exitTarget)
                }
                if (abs(vesselProg - exitTarget) < 0.03f) {
                    vesselPresence = PresenceState.Vacant
                    phase = CyclePhase.CLOSING_EXIT_GATE
                    phaseElapsed = 0.0
                }
            }

            CyclePhase.CLOSING_EXIT_GATE -> {
                cycleState = LockCycleState.VesselDepartureObserved
                if (isUpstreamBound) {
                    cmdUpGate = GateState.Closed
                    upGatePct = (upGatePct - GATE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtLeast(0f)
                    if (upGatePct <= 0.01f) {
                        phase = CyclePhase.COMPLETED_HOLD
                        phaseElapsed = 0.0
                        cycleState = LockCycleState.CycleComplete
                        completedCount += 1
                    }
                } else {
                    cmdDnGate = GateState.Closed
                    dnGatePct = (dnGatePct - GATE_RATE_PER_SEC * dtRealSec.toFloat()).coerceAtLeast(0f)
                    if (dnGatePct <= 0.01f) {
                        phase = CyclePhase.COMPLETED_HOLD
                        phaseElapsed = 0.0
                        cycleState = LockCycleState.CycleComplete
                        completedCount += 1
                    }
                }
            }

            CyclePhase.COMPLETED_HOLD -> {
                cycleState = LockCycleState.CycleComplete
                if (phaseElapsed >= 2.2) {
                    phase = CyclePhase.IDLE
                    phaseElapsed = 0.0
                    cycleState = LockCycleState.Idle
                    activeVessel = null
                    approaching = false
                    vesselPresence = PresenceState.Vacant
                }
            }
        }

        // Step hydraulic digital twin physics
        val (nextLevel, nextCycleWater) = HydraulicEngine.stepSimulation(
            config = cfg,
            currentModelLevelM = modelLevel,
            upstreamLevelM = upLevel,
            downstreamLevelM = dnLevel,
            upstreamPaddleOpenRatio = upPaddlePct.toDouble(),
            downstreamPaddleOpenRatio = dnPaddlePct.toDouble(),
            dtSeconds = dtPhysicsSec,
            cumulativeWaterUsedM3 = cycleWater
        )
        val deltaWater = nextCycleWater - cycleWater
        totalWater += deltaWater

        val nextMeasuredChamber = if (r.faults.injectLevelSensorDropout || r.faults.injectGatewayCommLoss) {
            null
        } else {
            nextLevel
        }

        val updatedState = r.state.copy(
            upstreamLevelM = measuredUpLevel,
            chamberLevelM = nextMeasuredChamber,
            downstreamLevelM = measuredDnLevel,
            upstreamGateState = measuredUpGate,
            downstreamGateState = measuredDnGate,
            upstreamPaddleState = measuredUpPaddle,
            downstreamPaddleState = measuredDnPaddle,
            vesselPresence = vesselPresence,
            safetyStatus = safetyEval.safetyStatus,
            cycleState = cycleState,
            lastUpdatedEpochMs = nowMs
        )

        return r.copy(
            state = updatedState,
            estimatedModelLevelM = nextLevel,
            upstreamGatePercent = upGatePct,
            downstreamGatePercent = dnGatePct,
            upstreamPaddlePercent = upPaddlePct,
            downstreamPaddlePercent = dnPaddlePct,
            commandedUpGate = cmdUpGate,
            commandedDnGate = cmdDnGate,
            commandedUpPaddle = cmdUpPaddle,
            commandedDnPaddle = cmdDnPaddle,
            cycleWaterUsedM3 = nextCycleWater,
            totalWaterUsedM3 = totalWater,
            completedCyclesCount = completedCount,
            phase = phase,
            phaseElapsedSec = phaseElapsed,
            vesselProgress = vesselProg,
            activeVesselName = activeVessel,
            approachingVesselDetected = approaching,
            gatewayLatencyMs = if (r.faults.injectGatewayCommLoss) 9999 else 16 + Random(r.seed + nowMs / 2000L).nextInt(14),
            lastCycleDurationSec = if (phase == CyclePhase.COMPLETED_HOLD && phaseElapsed < 0.3) 385.0 else r.lastCycleDurationSec
        )
    }
}
