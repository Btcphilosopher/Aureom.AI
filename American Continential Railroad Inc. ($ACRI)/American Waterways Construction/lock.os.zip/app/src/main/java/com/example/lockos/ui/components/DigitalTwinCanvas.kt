package com.example.lockos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.lockos.domain.controller.SimulatedLockRuntime
import com.example.lockos.domain.model.GateState
import com.example.lockos.domain.model.PaddleState
import com.example.lockos.domain.model.PresenceState
import com.example.lockos.domain.model.TwinViewMode
import com.example.ui.theme.LocalLockOsColors
import kotlin.math.sin

@Composable
fun DigitalTwinPanel(
    runtime: SimulatedLockRuntime,
    viewMode: TwinViewMode,
    showSensorOverlay: Boolean,
    showFaultOverlay: Boolean,
    onSelectViewMode: (TwinViewMode) -> Unit,
    onToggleSensors: () -> Unit,
    onToggleFaults: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    val twinCd = stringResource(R.string.cd_digital_twin)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
            .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "HYDRAULIC DIGITAL TWIN · ${runtime.config.lockId}",
                    style = MaterialTheme.typography.titleSmall,
                    color = sem.telemetryCyan
                )
                Text(
                    text = "${viewMode.label} · ${runtime.state.cycleState.label}",
                    style = MaterialTheme.typography.bodySmall,
                    color = sem.mutedLabel
                )
            }
            Box(
                modifier = Modifier
                    .background(sem.warningAmberBg, MaterialTheme.shapes.small)
                    .border(1.dp, sem.warningAmber.copy(alpha = 0.6f), MaterialTheme.shapes.small)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "SIMULATION",
                    style = MaterialTheme.typography.labelSmall,
                    color = sem.warningAmber,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TwinViewMode.entries.forEach { mode ->
                FilterChip(
                    selected = viewMode == mode,
                    onClick = { onSelectViewMode(mode) },
                    label = {
                        Text(
                            text = when (mode) {
                                TwinViewMode.TOP_DOWN -> "Top-Down"
                                TwinViewMode.SIDE_ELEVATION -> "Elevation"
                                TwinViewMode.CROSS_SECTION -> "Cross-Sec"
                            },
                            style = MaterialTheme.typography.labelSmall
                        )
                    },
                    modifier = Modifier.testTag("twin_mode_${mode.name.lowercase()}"),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = showSensorOverlay,
                onClick = onToggleSensors,
                label = { Text("Sensors", style = MaterialTheme.typography.labelSmall) },
                modifier = Modifier.testTag("toggle_sensor_overlay")
            )
            FilterChip(
                selected = showFaultOverlay,
                onClick = onToggleFaults,
                label = { Text("Faults (${runtime.faults.activeCount})", style = MaterialTheme.typography.labelSmall) },
                modifier = Modifier.testTag("toggle_fault_overlay")
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .background(Color(0xFF050D18), MaterialTheme.shapes.medium)
                .border(1.dp, sem.panelBorder, MaterialTheme.shapes.medium)
                .semantics { contentDescription = twinCd }
                .testTag("digital_twin_canvas")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                when (viewMode) {
                    TwinViewMode.SIDE_ELEVATION -> drawSideElevation(runtime, showSensorOverlay, showFaultOverlay)
                    TwinViewMode.TOP_DOWN -> drawTopDownPlan(runtime, showSensorOverlay, showFaultOverlay)
                    TwinViewMode.CROSS_SECTION -> drawCrossSection(runtime, showSensorOverlay, showFaultOverlay)
                }
            }

            // Telemetry corner legend overlay
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .background(Color(0xCC07111F), MaterialTheme.shapes.small)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val chTxt = runtime.state.chamberLevelM?.let { "%.2fm".format(it) } ?: "UNKNOWN"
                Text(
                    text = "UP ${runtime.state.upstreamLevelM?.let { "%.2fm".format(it) } ?: "UNK"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF38BDF8)
                )
                Text(
                    text = "CH $chTxt (Est ${"%.2fm".format(runtime.estimatedModelLevelM)})",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (runtime.state.chamberLevelM == null) Color(0xFFEF4444) else Color(0xFF10B981)
                )
                Text(
                    text = "DN ${runtime.state.downstreamLevelM?.let { "%.2fm".format(it) } ?: "UNK"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}

private fun DrawScope.drawSideElevation(
    runtime: SimulatedLockRuntime,
    showSensors: Boolean,
    showFaults: Boolean
) {
    val w = size.width
    val h = size.height
    val maxHead = (runtime.config.normalUpstreamM + 1.5).toFloat()

    // Grid lines
    for (i in 1..4) {
        val gy = h * (i / 5f)
        drawLine(Color(0xFF13263E), Offset(0f, gy), Offset(w, gy), strokeWidth = 1f)
    }

    val upZoneEnd = w * 0.28f
    val dnZoneStart = w * 0.72f
    val bedY = h * 0.86f
    val wallTopY = h * 0.14f

    fun levelToY(levelM: Double): Float {
        val ratio = (levelM / maxHead).toFloat().coerceIn(0.05f, 0.95f)
        return bedY - ratio * (bedY - wallTopY)
    }

    val upY = levelToY(runtime.config.normalUpstreamM)
    val dnY = levelToY(runtime.config.normalDownstreamM)
    val chY = levelToY(runtime.estimatedModelLevelM)

    // Upstream water body
    drawRect(
        brush = Brush.verticalGradient(listOf(Color(0xAA0EA5E9), Color(0xDD0369A1))),
        topLeft = Offset(0f, upY),
        size = Size(upZoneEnd, bedY - upY)
    )

    // Chamber water body (striped/warning if level sensor unknown)
    val chamberBrush = if (runtime.state.chamberLevelM == null) {
        Brush.verticalGradient(listOf(Color(0x66EF4444), Color(0x887F1D1D)))
    } else {
        Brush.verticalGradient(listOf(Color(0xBB38BDF8), Color(0xEE0284C7)))
    }
    drawRect(
        brush = chamberBrush,
        topLeft = Offset(upZoneEnd, chY),
        size = Size(dnZoneStart - upZoneEnd, bedY - chY)
    )

    // Turbulent paddle flow jets when paddles open
    if (runtime.upstreamPaddlePercent > 0.05f) {
        for (i in 0..4) {
            val jetX = upZoneEnd + 8f + i * 16f
            drawCircle(
                color = Color(0x99BAE6FD),
                radius = 3f + runtime.upstreamPaddlePercent * 4f,
                center = Offset(jetX, chY + 12f + (i % 2) * 8f)
            )
        }
    }
    if (runtime.downstreamPaddlePercent > 0.05f) {
        for (i in 0..4) {
            val jetX = dnZoneStart + 8f + i * 14f
            drawCircle(
                color = Color(0x99BAE6FD),
                radius = 3f + runtime.downstreamPaddlePercent * 4f,
                center = Offset(jetX, dnY + 10f + (i % 2) * 8f)
            )
        }
    }

    // Downstream water body
    drawRect(
        brush = Brush.verticalGradient(listOf(Color(0xAA0284C7), Color(0xDD075985))),
        topLeft = Offset(dnZoneStart, dnY),
        size = Size(w - dnZoneStart, bedY - dnY)
    )

    // Concrete lock sills & bed
    val concrete = Color(0xFF334155)
    drawRect(concrete, Offset(0f, upY + (bedY - upY) * 0.55f), Size(upZoneEnd, bedY - (upY + (bedY - upY) * 0.55f)))
    drawRect(concrete, Offset(0f, bedY), Size(w, h - bedY))
    drawRect(Color(0xFF475569), Offset(upZoneEnd - 6f, wallTopY), Size(12f, bedY - wallTopY))
    drawRect(Color(0xFF475569), Offset(dnZoneStart - 6f, wallTopY), Size(12f, bedY - wallTopY))

    // Upstream Gate (lifts/fades open)
    val upGateColor = when (runtime.state.upstreamGateState) {
        GateState.Faulted, GateState.Unknown -> Color(0xFFEF4444)
        GateState.Open -> Color(0xFF10B981)
        GateState.Opening, GateState.Closing -> Color(0xFFF59E0B)
        GateState.Closed -> Color(0xFFE2E8F0)
    }
    val upGateHeight = (bedY - wallTopY) * (1f - runtime.upstreamGatePercent * 0.85f)
    drawRect(upGateColor, Offset(upZoneEnd - 4f, wallTopY), Size(8f, upGateHeight))

    // Downstream Gate
    val dnGateColor = when (runtime.state.downstreamGateState) {
        GateState.Faulted, GateState.Unknown -> Color(0xFFEF4444)
        GateState.Open -> Color(0xFF10B981)
        GateState.Opening, GateState.Closing -> Color(0xFFF59E0B)
        GateState.Closed -> Color(0xFFE2E8F0)
    }
    val dnGateHeight = (bedY - wallTopY) * (1f - runtime.downstreamGatePercent * 0.85f)
    drawRect(dnGateColor, Offset(dnZoneStart - 4f, wallTopY), Size(8f, dnGateHeight))

    // Paddle indicators at gate base
    val upPaddleColor = if (runtime.state.upstreamPaddleState == PaddleState.Faulted) Color(0xFFEF4444)
    else if (runtime.upstreamPaddlePercent > 0.1f) Color(0xFF38BDF8) else Color(0xFF64748B)
    drawCircle(upPaddleColor, radius = 6f, center = Offset(upZoneEnd, bedY - 14f))

    val dnPaddleColor = if (runtime.state.downstreamPaddleState == PaddleState.Faulted) Color(0xFFEF4444)
    else if (runtime.downstreamPaddlePercent > 0.1f) Color(0xFF38BDF8) else Color(0xFF64748B)
    drawCircle(dnPaddleColor, radius = 6f, center = Offset(dnZoneStart, bedY - 14f))

    // Vessel rendering if approaching or inside chamber
    if (runtime.approachingVesselDetected || runtime.activeVesselName != null ||
        runtime.state.vesselPresence != PresenceState.Vacant
    ) {
        val vx = w * (0.10f + runtime.vesselProgress * 0.80f)
        val waterAtVesselY = when {
            vx < upZoneEnd -> upY
            vx > dnZoneStart -> dnY
            else -> chY
        }
        val hullW = 54f
        val hullH = 16f
        val hullPath = Path().apply {
            moveTo(vx - hullW / 2f, waterAtVesselY - hullH)
            lineTo(vx + hullW / 2f, waterAtVesselY - hullH)
            lineTo(vx + hullW / 2.4f, waterAtVesselY + 4f)
            lineTo(vx - hullW / 2.4f, waterAtVesselY + 4f)
            close()
        }
        drawPath(hullPath, color = Color(0xFFF8FAFC))
        drawRect(Color(0xFF1E6FD9), Offset(vx - 14f, waterAtVesselY - hullH - 8f), Size(22f, 8f))
    }

    // Sensor overlay markers
    if (showSensors) {
        val sensorColor = Color(0xFF10B981)
        // Radar towers
        drawCircle(sensorColor, 5f, Offset(w * 0.16f, wallTopY))
        drawCircle(sensorColor, 5f, Offset(w * 0.84f, wallTopY))
        // Chamber LiDAR scan cone
        drawLine(
            color = Color(0x6638BDF8),
            start = Offset(w * 0.50f, wallTopY),
            end = Offset(w * 0.40f, chY),
            strokeWidth = 1.5f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
        )
        drawLine(
            color = Color(0x6638BDF8),
            start = Offset(w * 0.50f, wallTopY),
            end = Offset(w * 0.60f, chY),
            strokeWidth = 1.5f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
        )
        // Hydrostatic probe
        drawCircle(
            color = if (runtime.faults.injectLevelSensorDropout) Color(0xFFEF4444) else Color(0xFF38BDF8),
            radius = 5f,
            center = Offset(w * 0.50f, bedY - 8f)
        )
    }

    // Fault & Intrusion overlays
    if (showFaults && runtime.faults.activeCount > 0) {
        drawRect(
            color = Color(0xFFEF4444),
            topLeft = Offset(3f, 3f),
            size = Size(w - 6f, h - 6f),
            style = Stroke(width = 3f)
        )
        if (runtime.faults.injectPedestrianIntrusion) {
            drawCircle(Color(0x99EF4444), radius = 22f, center = Offset(upZoneEnd, wallTopY + 12f))
        }
    }
}

private fun DrawScope.drawTopDownPlan(
    runtime: SimulatedLockRuntime,
    showSensors: Boolean,
    showFaults: Boolean
) {
    val w = size.width
    val h = size.height
    val cy = h * 0.5f
    val canalHalf = h * 0.24f

    // Canal water channel
    drawRect(
        color = Color(0xFF0369A1),
        topLeft = Offset(0f, cy - canalHalf),
        size = Size(w, canalHalf * 2f)
    )
    // Lock chamber walls
    val chStart = w * 0.28f
    val chEnd = w * 0.72f
    drawRect(Color(0xFF334155), Offset(chStart, cy - canalHalf - 16f), Size(chEnd - chStart, 16f))
    drawRect(Color(0xFF334155), Offset(chStart, cy + canalHalf), Size(chEnd - chStart, 16f))

    // Upstream Miter Gate Leaves (swing open into wall recesses)
    val upSwing = runtime.upstreamGatePercent * 0.9f
    val leafLen = canalHalf * 1.05f
    val upColor = if (runtime.state.upstreamGateState == GateState.Faulted) Color(0xFFEF4444) else Color(0xFFF8FAFC)
    drawLine(
        upColor,
        Offset(chStart, cy - canalHalf),
        Offset(chStart - (1f - upSwing) * 14f - upSwing * leafLen * 0.7f, cy - upSwing * canalHalf * 0.75f),
        strokeWidth = 6f
    )
    drawLine(
        upColor,
        Offset(chStart, cy + canalHalf),
        Offset(chStart - (1f - upSwing) * 14f - upSwing * leafLen * 0.7f, cy + upSwing * canalHalf * 0.75f),
        strokeWidth = 6f
    )

    // Downstream Miter Gate Leaves
    val dnSwing = runtime.downstreamGatePercent * 0.9f
    val dnColor = if (runtime.state.downstreamGateState == GateState.Faulted) Color(0xFFEF4444) else Color(0xFFF8FAFC)
    drawLine(
        dnColor,
        Offset(chEnd, cy - canalHalf),
        Offset(chEnd - (1f - dnSwing) * 14f + dnSwing * leafLen * 0.7f, cy - dnSwing * canalHalf * 0.75f),
        strokeWidth = 6f
    )
    drawLine(
        dnColor,
        Offset(chEnd, cy + canalHalf),
        Offset(chEnd - (1f - dnSwing) * 14f + dnSwing * leafLen * 0.7f, cy + dnSwing * canalHalf * 0.75f),
        strokeWidth = 6f
    )

    // Vessel top-down footprint
    if (runtime.approachingVesselDetected || runtime.activeVesselName != null ||
        runtime.state.vesselPresence != PresenceState.Vacant
    ) {
        val vx = w * (0.10f + runtime.vesselProgress * 0.80f)
        drawRoundRect(
            color = Color(0xFFF8FAFC),
            topLeft = Offset(vx - 30f, cy - 11f),
            size = Size(60f, 22f),
            cornerRadius = CornerRadius(10f, 10f)
        )
        drawRoundRect(
            color = Color(0xFF1E6FD9),
            topLeft = Offset(vx - 16f, cy - 7f),
            size = Size(24f, 14f),
            cornerRadius = CornerRadius(4f, 4f)
        )
    }

    if (showSensors) {
        // Radar arcs
        drawCircle(Color(0x3310B981), radius = 38f, center = Offset(chStart, cy - canalHalf - 8f))
        drawCircle(Color(0x3310B981), radius = 38f, center = Offset(chEnd, cy + canalHalf + 8f))
    }

    if (showFaults && runtime.faults.activeCount > 0) {
        drawRect(
            color = Color(0xFFEF4444),
            topLeft = Offset(4f, 4f),
            size = Size(w - 8f, h - 8f),
            style = Stroke(width = 3f)
        )
    }
}

private fun DrawScope.drawCrossSection(
    runtime: SimulatedLockRuntime,
    showSensors: Boolean,
    showFaults: Boolean
) {
    val w = size.width
    val h = size.height
    val leftWall = w * 0.22f
    val rightWall = w * 0.78f
    val floorY = h * 0.82f
    val topY = h * 0.16f
    val maxHead = (runtime.config.normalUpstreamM + 1.2).toFloat()

    // U-channel concrete walls
    drawRect(Color(0xFF334155), Offset(leftWall - 24f, topY), Size(24f, floorY - topY + 20f))
    drawRect(Color(0xFF334155), Offset(rightWall, topY), Size(24f, floorY - topY + 20f))
    drawRect(Color(0xFF334155), Offset(leftWall - 24f, floorY), Size(rightWall - leftWall + 48f, 20f))

    // Water height inside chamber
    val ratio = (runtime.estimatedModelLevelM / maxHead).toFloat().coerceIn(0.06f, 0.94f)
    val waterY = floorY - ratio * (floorY - topY)

    val fillColor = if (runtime.state.chamberLevelM == null) Color(0x66EF4444) else Color(0xCC0EA5E9)
    drawRect(fillColor, Offset(leftWall, waterY), Size(rightWall - leftWall, floorY - waterY))

    // Normal upstream & downstream datum reference lines
    val upRefY = floorY - (runtime.config.normalUpstreamM / maxHead).toFloat() * (floorY - topY)
    val dnRefY = floorY - (runtime.config.normalDownstreamM / maxHead).toFloat() * (floorY - topY)
    drawLine(
        Color(0xFF38BDF8),
        Offset(leftWall - 32f, upRefY),
        Offset(rightWall + 32f, upRefY),
        strokeWidth = 2f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
    )
    drawLine(
        Color(0xFF94A3B8),
        Offset(leftWall - 32f, dnRefY),
        Offset(rightWall + 32f, dnRefY),
        strokeWidth = 2f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
    )

    // Vessel cross section if inside chamber
    if (runtime.vesselProgress in 0.28f..0.72f &&
        (runtime.activeVesselName != null || runtime.state.vesselPresence == PresenceState.OccupiedConfirmed)
    ) {
        val vw = (rightWall - leftWall) * 0.42f
        val cx = w * 0.5f
        drawRect(Color(0xFFF8FAFC), Offset(cx - vw / 2f, waterY - 22f), Size(vw, 28f))
        drawRect(Color(0xFF1E6FD9), Offset(cx - vw / 3f, waterY - 34f), Size(vw * 0.66f, 12f))
    }

    // Side culverts
    val culvertColor = if (runtime.upstreamPaddlePercent > 0.1f || runtime.downstreamPaddlePercent > 0.1f) {
        Color(0xFF38BDF8)
    } else Color(0xFF1E293B)
    drawCircle(culvertColor, 10f, Offset(leftWall - 12f, floorY - 12f))
    drawCircle(culvertColor, 10f, Offset(rightWall + 12f, floorY - 12f))

    if (showSensors) {
        val probeColor = if (runtime.faults.injectLevelSensorDropout) Color(0xFFEF4444) else Color(0xFF10B981)
        drawCircle(probeColor, 6f, Offset(leftWall + 8f, floorY - 10f))
        drawCircle(probeColor, 6f, Offset(rightWall - 8f, floorY - 10f))
    }

    if (showFaults && runtime.faults.activeCount > 0) {
        drawRect(Color(0xFFEF4444), Offset(4f, 4f), Size(w - 8f, h - 8f), style = Stroke(3f))
    }
}
