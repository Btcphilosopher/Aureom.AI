package com.example.lockos.data.report

import com.example.lockos.domain.model.AlarmItem
import com.example.lockos.domain.model.AuditLogItem
import com.example.lockos.domain.model.CanalLockState
import com.example.lockos.domain.model.HydraulicSnapshot
import com.example.lockos.domain.model.LockSiteConfig
import com.example.lockos.domain.model.SafetyEvaluationResult
import com.example.lockos.domain.model.SensorReading
import com.example.lockos.domain.model.VesselArrivalItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EngineeringReportGenerator {

    fun generateMarkdownReport(
        site: LockSiteConfig,
        state: CanalLockState,
        hydraulics: HydraulicSnapshot,
        safety: SafetyEvaluationResult,
        sensors: List<SensorReading>,
        queue: List<VesselArrivalItem>,
        alarms: List<AlarmItem>,
        recentAudit: List<AuditLogItem>,
        simulationSeed: Long,
        completedCyclesCount: Int
    ): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US)
        val generatedTime = fmt.format(Date(state.lastUpdatedEpochMs))

        return buildString {
            appendLine("# LOCK.OS — AUTOMATED CANAL LOCK ENGINEERING REPORT")
            appendLine("Generated: $generatedTime")
            appendLine("Classification: ${state.operatingMode.label} (Deterministic Seed: $simulationSeed)")
            appendLine("Authority Notice: Safety-rated local controller (${site.controllerId}) retains exclusive physical actuator authority.")
            appendLine()
            appendLine("## 1. SITE & INFRASTRUCTURE IDENTITY")
            appendLine("- Lock ID: ${site.lockId} (${site.name})")
            appendLine("- Waterway / Region: ${site.waterway} / ${site.region}")
            appendLine("- Local Controller / Gateway: ${site.controllerId} via ${site.gatewayId}")
            appendLine("- Commissioned for Live Auto: ${if (site.commissionedForAuto) "YES" else "NO (Simulation / Supervised Only)"}")
            appendLine("- Current Cycle State: ${state.cycleState.label}")
            appendLine("- Safety Status: ${state.safetyStatus.label}")
            appendLine()
            appendLine("## 2. HYDRAULIC DIGITAL TWIN (LUMPED-PARAMETER CONTINUITY MODEL)")
            appendLine("Note: Estimated model values are mathematically derived and clearly separated from measured telemetry.")
            appendLine("- Chamber Geometry: ${"%.1f".format(site.chamberLengthM)}m L x ${"%.1f".format(site.chamberWidthM)}m W (Area = ${"%.1f".format(hydraulics.chamberAreaM2)} m^2)")
            appendLine("- Discharge Coefficient (Cd): ${"%.2f".format(site.dischargeCoeff)} | Head Loss Factor (K): ${"%.2f".format(site.hydraulicLossCoeff)}")
            appendLine("- Upstream Level (Measured/Sim): ${state.upstreamLevelM?.let { "%.2f m".format(it) } ?: "UNKNOWN"}")
            appendLine("- Chamber Level (Measured/Sim): ${state.chamberLevelM?.let { "%.2f m".format(it) } ?: "UNKNOWN"}")
            appendLine("- Chamber Level (Model Estimate): ${"%.2f m".format(hydraulics.estimatedModelLevelM)}")
            appendLine("- Downstream Level (Measured/Sim): ${state.downstreamLevelM?.let { "%.2f m".format(it) } ?: "UNKNOWN"}")
            appendLine("- Active Inflow / Outflow: +${"%.2f".format(hydraulics.inflowRateM3s)} m^3/s / -${"%.2f".format(hydraulics.outflowRateM3s)} m^3/s")
            appendLine("- Rate of Level Change: ${"%.2f".format(hydraulics.rateOfChangeMPerMin)} m/min")
            appendLine("- Estimated Fill Time / Empty Time: ${"%.0f".format(hydraulics.estFillTimeSec)}s / ${"%.0f".format(hydraulics.estEmptyTimeSec)}s")
            appendLine("- Cumulative Water Consumption: ${"%.1f".format(hydraulics.cycleWaterUsedM3)} m^3 ($completedCyclesCount completed cycles)")
            appendLine()
            appendLine("## 3. SAFETY CONTROLLER INTERLOCK VERIFICATION (${safety.controllerId})")
            appendLine("- Overall Movement Verdict: ${if (safety.movementPermitted) "PERMITTED" else "WITHHELD"}")
            appendLine("- Summary: ${safety.summary}")
            safety.checks.forEach { check ->
                val mark = if (check.passed) "PASS" else "FAIL"
                appendLine("  - [${check.code}] $mark — ${check.title}: ${check.detail}")
            }
            appendLine()
            appendLine("## 4. SENSOR PROVENANCE & HEALTH")
            sensors.forEach { s ->
                appendLine("- ${s.sensorId} (${s.sensorType.label} / ${s.zone.label}): ${s.valueText} | Conf=${(s.confidence * 100).toInt()}% | Certain=${s.isCertain} | Health=${s.health.label} | ${s.provenanceLabel}")
            }
            appendLine()
            appendLine("## 5. QUEUE & TRAFFIC SUMMARY (${queue.size} active entries for ${site.lockId})")
            if (queue.isEmpty()) {
                appendLine("- No vessels currently queued.")
            } else {
                queue.forEach { v ->
                    appendLine("- #${v.queuePosition} ${v.vesselName} (${v.registrationCode}) | ${v.direction.code} | ${v.priority.label} | Status=${v.status.label}")
                }
            }
            appendLine()
            appendLine("## 6. ALARMS (${alarms.count { !it.resolved }} active)")
            if (alarms.isEmpty()) {
                appendLine("- No active alarms.")
            } else {
                alarms.take(10).forEach { a ->
                    val ackText = if (a.acknowledged) "ACK by ${a.acknowledgedBy}" else "UNACK"
                    appendLine("- [${a.severity.label}] ${a.code} ($ackText): ${a.description} (${a.source})")
                }
            }
            appendLine()
            appendLine("## 7. IMMUTABLE AUDIT TRAIL (LATEST 10 EVENTS)")
            recentAudit.take(10).forEach { ev ->
                appendLine("- ${fmt.format(Date(ev.timestampMs))} | ${ev.actorName} (${ev.actorRole}) | ${ev.action} -> ${ev.controllerVerdict}")
            }
            appendLine()
            appendLine("--- END OF LOCK.OS ENGINEERING REPORT ---")
        }
    }
}
