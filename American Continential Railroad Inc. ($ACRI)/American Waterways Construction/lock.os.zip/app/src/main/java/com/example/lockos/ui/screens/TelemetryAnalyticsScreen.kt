package com.example.lockos.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.lockos.domain.model.SensorHealth
import com.example.lockos.domain.model.TelemetryPoint
import com.example.lockos.ui.components.StatusPill
import com.example.lockos.ui.state.LockOsUiState
import com.example.ui.theme.LocalLockOsColors

@Composable
fun TelemetryAnalyticsScreen(
    uiState: LockOsUiState,
    telemetryHistory: List<TelemetryPoint>,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    val hyd = uiState.hydraulics
    val runtime = uiState.activeRuntime

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 860.dp)
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // 1. Historical Water-Level Telemetry Chart
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "HISTORICAL WATER-LEVEL TELEMETRY",
                            style = MaterialTheme.typography.titleSmall,
                            color = sem.telemetryCyan
                        )
                        StatusPill(
                            text = "${telemetryHistory.size} SAMPLES · SIM",
                            fg = sem.warningAmber,
                            bg = sem.warningAmberBg
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                            .background(Color(0xFF050D18), MaterialTheme.shapes.medium)
                            .border(1.dp, sem.panelBorder, MaterialTheme.shapes.medium)
                            .padding(8.dp)
                            .testTag("telemetry_history_chart")
                    ) {
                        if (telemetryHistory.size < 2) {
                            Text(
                                text = "Collecting simulated telemetry samples...",
                                style = MaterialTheme.typography.bodySmall,
                                color = sem.mutedLabel,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val w = size.width
                                val h = size.height
                                val maxVal = (runtime.config.normalUpstreamM + 0.8).toFloat()
                                val minVal = (runtime.config.normalDownstreamM - 0.5).coerceAtLeast(0.0).toFloat()
                                val span = (maxVal - minVal).coerceAtLeast(1f)

                                for (i in 1..3) {
                                    val gy = h * (i / 4f)
                                    drawLine(Color(0xFF13263E), Offset(0f, gy), Offset(w, gy), 1f)
                                }

                                fun yFor(v: Double): Float {
                                    val norm = ((v.toFloat() - minVal) / span).coerceIn(0.05f, 0.95f)
                                    return h - norm * h
                                }

                                val stepX = w / (telemetryHistory.size - 1).coerceAtLeast(1)

                                val upPath = Path()
                                val chPath = Path()
                                val dnPath = Path()

                                telemetryHistory.forEachIndexed { idx, pt ->
                                    val x = idx * stepX
                                    val yu = yFor(pt.upstreamM)
                                    val yc = yFor(pt.chamberM)
                                    val yd = yFor(pt.downstreamM)
                                    if (idx == 0) {
                                        upPath.moveTo(x, yu)
                                        chPath.moveTo(x, yc)
                                        dnPath.moveTo(x, yd)
                                    } else {
                                        upPath.lineTo(x, yu)
                                        chPath.lineTo(x, yc)
                                        dnPath.lineTo(x, yd)
                                    }
                                }

                                drawPath(upPath, Color(0xFF38BDF8), style = Stroke(width = 2.5f))
                                drawPath(dnPath, Color(0xFF64748B), style = Stroke(width = 2.5f))
                                drawPath(chPath, Color(0xFF10B981), style = Stroke(width = 4f))
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("— Upstream", style = MaterialTheme.typography.labelSmall, color = Color(0xFF38BDF8))
                        Text("— Chamber", style = MaterialTheme.typography.labelSmall, color = Color(0xFF10B981))
                        Text("— Downstream", style = MaterialTheme.typography.labelSmall, color = Color(0xFF94A3B8))
                    }
                }
            }

            // 2. Hydraulic Digital Twin Model (Measured vs Estimated)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "HYDRAULIC MODEL VS MEASURED TELEMETRY",
                        style = MaterialTheme.typography.titleSmall,
                        color = sem.telemetryCyan
                    )
                    Text(
                        text = hyd.modelNote,
                        style = MaterialTheme.typography.bodySmall,
                        color = sem.mutedLabel
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        HydMetric("CHAMBER GEOMETRY", "${runtime.config.chamberLengthM}m x ${runtime.config.chamberWidthM}m")
                        HydMetric("AREA / VOLUME", "${"%.1f".format(hyd.chamberAreaM2)}m2 / ${"%.0f".format(hyd.chamberVolumeM3)}m3")
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        HydMetric("MEASURED LEVEL", hyd.measuredChamberLevelM?.let { "%.2f m".format(it) } ?: "UNKNOWN (FAULT)")
                        HydMetric("MODEL ESTIMATE", "${"%.2f".format(hyd.estimatedModelLevelM)} m (EST)")
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        HydMetric("INFLOW / OUTFLOW (EST)", "+${"%.2f".format(hyd.inflowRateM3s)} / -${"%.2f".format(hyd.outflowRateM3s)} m3/s")
                        HydMetric("FILL / EMPTY TIME (EST)", "${"%.0f".format(hyd.estFillTimeSec)}s / ${"%.0f".format(hyd.estEmptyTimeSec)}s")
                    }
                }
            }

            // 3. Enterprise Analytics KPIs
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "ANALYTICS (MEASURED VS ESTIMATED)",
                        style = MaterialTheme.typography.titleSmall,
                        color = sem.telemetryCyan
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        HydMetric("CYCLES COMPLETED", "${runtime.completedCyclesCount} (SIM)")
                        HydMetric("AVG DURATION", "${"%.0f".format(runtime.avgCycleDurationSec)}s (EST)")
                        HydMetric("TOTAL WATER", "${"%.0f".format(runtime.totalWaterUsedM3)} m3 (EST)")
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        val sensorUptime = (uiState.sensors.count { it.health == SensorHealth.Nominal }.toFloat() /
                            uiState.sensors.size.coerceAtLeast(1) * 100f)
                        HydMetric("SENSOR UPTIME", "${"%.0f".format(sensorUptime)}% (MEAS)")
                        HydMetric("EQUIP AVAILABILITY", if (runtime.faults.activeCount == 0) "99.2% (MEAS)" else "DEGRADED")
                        HydMetric("ACTIVE FAULTS", "${runtime.faults.activeCount}")
                    }
                }
            }

            // 4. Sensor Monitoring & Provenance Matrix
            item {
                Text(
                    text = "FIELD SENSORS & PROVENANCE (${uiState.sensors.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = sem.telemetryCyan
                )
            }

            items(uiState.sensors, key = { it.sensorId }) { sensor ->
                val healthColor = when (sensor.health) {
                    SensorHealth.Nominal -> sem.safeGreen
                    SensorHealth.Degraded, SensorHealth.Stale -> sem.warningAmber
                    SensorHealth.Faulted, SensorHealth.Offline -> sem.alarmRed
                }
                val healthBg = when (sensor.health) {
                    SensorHealth.Nominal -> sem.safeGreenBg
                    SensorHealth.Degraded, SensorHealth.Stale -> sem.warningAmberBg
                    SensorHealth.Faulted, SensorHealth.Offline -> sem.alarmRedBg
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.medium)
                        .padding(10.dp)
                        .testTag("sensor_card_${sensor.sensorId}"),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${sensor.sensorId} · ${sensor.name}",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        StatusPill(text = sensor.health.label, fg = healthColor, bg = healthBg)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Value: ${sensor.valueText}",
                            style = MaterialTheme.typography.labelMedium,
                            color = sem.telemetryCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Conf: ${(sensor.confidence * 100).toInt()}% · Certain: ${if (sensor.isCertain) "YES" else "NO"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (sensor.isCertain) sem.safeGreen else sem.alarmRed
                        )
                    }
                    Text(
                        text = "${sensor.sensorType.label} | ${sensor.zone.label} | ${sensor.redundancyGroup}",
                        style = MaterialTheme.typography.labelSmall,
                        color = sem.mutedLabel
                    )
                    Text(
                        text = sensor.provenanceLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = sem.warningAmber
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun HydMetric(label: String, value: String) {
    val sem = LocalLockOsColors.current
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sem.mutedLabel)
        Text(value, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
    }
}
