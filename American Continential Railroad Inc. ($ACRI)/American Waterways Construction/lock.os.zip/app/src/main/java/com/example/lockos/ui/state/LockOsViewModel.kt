package com.example.lockos.ui.state

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lockos.data.local.LockOsDatabase
import com.example.lockos.data.local.LockOsRepository
import com.example.lockos.data.report.EngineeringReportGenerator
import com.example.lockos.data.seed.LockSiteCatalog
import com.example.lockos.domain.controller.CyclePhase
import com.example.lockos.domain.controller.LockCycleOrchestrator
import com.example.lockos.domain.controller.SafetyLocalController
import com.example.lockos.domain.controller.SimulatedLockRuntime
import com.example.lockos.domain.hydraulic.HydraulicEngine
import com.example.lockos.domain.model.ActuatorTelemetry
import com.example.lockos.domain.model.AlarmItem
import com.example.lockos.domain.model.AlarmSeverity
import com.example.lockos.domain.model.AssetCategory
import com.example.lockos.domain.model.AuditLogItem
import com.example.lockos.domain.model.FaultInjectionFlags
import com.example.lockos.domain.model.HydraulicSnapshot
import com.example.lockos.domain.model.LockCycleState
import com.example.lockos.domain.model.MaintenanceOrderItem
import com.example.lockos.domain.model.NetworkLockSummary
import com.example.lockos.domain.model.OperatingMode
import com.example.lockos.domain.model.OperatorRole
import com.example.lockos.domain.model.PresenceState
import com.example.lockos.domain.model.QueuePriority
import com.example.lockos.domain.model.QueueStatus
import com.example.lockos.domain.model.SafetyEvaluationResult
import com.example.lockos.domain.model.SavedSimulationItem
import com.example.lockos.domain.model.SensorReading
import com.example.lockos.domain.model.TelemetryPoint
import com.example.lockos.domain.model.TravelDirection
import com.example.lockos.domain.model.TwinViewMode
import com.example.lockos.domain.model.VesselArrivalItem
import com.example.lockos.domain.model.WorkOrderStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class LockOsUiState(
    val selectedLockId: String = "LOCK-AST-04",
    val activeRuntime: SimulatedLockRuntime,
    val allRuntimes: Map<String, SimulatedLockRuntime>,
    val hydraulics: HydraulicSnapshot,
    val safetyEvaluation: SafetyEvaluationResult,
    val sensors: List<SensorReading>,
    val actuators: List<ActuatorTelemetry>,
    val twinViewMode: TwinViewMode = TwinViewMode.SIDE_ELEVATION,
    val showSensorOverlay: Boolean = true,
    val showFaultOverlay: Boolean = true,
    val simulationSpeedMultiplier: Float = 8.0f,
    val operatorName: String = "E. Mercer",
    val operatorRole: OperatorRole = OperatorRole.SENIOR_CONTROL_ENGINEER,
    val darkTheme: Boolean = true,
    val bannerFeedback: String? = null,
    val generatedReportMarkdown: String? = null
)

class LockOsViewModel(application: Application) : AndroidViewModel(application) {

    private val database = LockOsDatabase.getInstance(application)
    private val repository = LockOsRepository(database.lockOsDao())

    private val initialSeed = 40219L
    private val initialNow = System.currentTimeMillis()
    private val initialRuntimes: Map<String, SimulatedLockRuntime> =
        LockSiteCatalog.sites.associate { site ->
            site.lockId to LockCycleOrchestrator.createInitialRuntime(
                config = site,
                seed = initialSeed + site.elevationOrder * 101L,
                nowMs = initialNow,
                withApproachingVessel = site.lockId == "LOCK-AST-04"
            )
        }

    private val _selectedLockId = MutableStateFlow("LOCK-AST-04")
    private val _runtimes = MutableStateFlow(initialRuntimes)
    private val _twinViewMode = MutableStateFlow(TwinViewMode.SIDE_ELEVATION)
    private val _showSensorOverlay = MutableStateFlow(true)
    private val _showFaultOverlay = MutableStateFlow(true)
    private val _speedMultiplier = MutableStateFlow(8.0f)
    private val _operatorRole = MutableStateFlow(OperatorRole.SENIOR_CONTROL_ENGINEER)
    private val _darkTheme = MutableStateFlow(true)
    private val _bannerFeedback = MutableStateFlow<String?>(null)
    private val _generatedReport = MutableStateFlow<String?>(null)

    val queueEntries: StateFlow<List<VesselArrivalItem>> = repository.queueEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alarms: StateFlow<List<AlarmItem>> = repository.alarms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workOrders: StateFlow<List<MaintenanceOrderItem>> = repository.workOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditEvents: StateFlow<List<AuditLogItem>> = repository.auditEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedSimulations: StateFlow<List<SavedSimulationItem>> = repository.savedSimulations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val telemetryHistory: StateFlow<List<TelemetryPoint>> = _selectedLockId
        .flatMapLatest { lockId -> repository.observeTelemetry(lockId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uiState: StateFlow<LockOsUiState> = combine(
        _selectedLockId,
        _runtimes,
        _twinViewMode,
        _showSensorOverlay,
        _showFaultOverlay,
        _speedMultiplier,
        _operatorRole,
        _darkTheme,
        _bannerFeedback,
        _generatedReport
    ) { values ->
        val lockId = values[0] as String
        @Suppress("UNCHECKED_CAST")
        val runtimes = values[1] as Map<String, SimulatedLockRuntime>
        val viewMode = values[2] as TwinViewMode
        val sensorOverlay = values[3] as Boolean
        val faultOverlay = values[4] as Boolean
        val speed = values[5] as Float
        val role = values[6] as OperatorRole
        val dark = values[7] as Boolean
        val feedback = values[8] as String?
        val report = values[9] as String?

        val active = runtimes[lockId] ?: runtimes.values.first()
        val now = active.state.lastUpdatedEpochMs
        val sensors = active.buildSensors(now)
        val actuators = active.buildActuators()
        val safety = SafetyLocalController.evaluate(
            config = active.config,
            lockState = active.state,
            sensors = sensors,
            actuators = actuators,
            faults = active.faults,
            commHealthy = active.commHealthy,
            nowMs = now
        )
        val hydraulics = HydraulicEngine.computeSnapshot(
            config = active.config,
            estimatedModelLevelM = active.estimatedModelLevelM,
            measuredChamberLevelM = active.state.chamberLevelM,
            upstreamLevelM = active.config.normalUpstreamM,
            downstreamLevelM = active.config.normalDownstreamM,
            upstreamPaddleOpenRatio = active.upstreamPaddlePercent.toDouble(),
            downstreamPaddleOpenRatio = active.downstreamPaddlePercent.toDouble(),
            cycleWaterUsedM3 = active.cycleWaterUsedM3
        )

        LockOsUiState(
            selectedLockId = lockId,
            activeRuntime = active,
            allRuntimes = runtimes,
            hydraulics = hydraulics,
            safetyEvaluation = safety,
            sensors = sensors,
            actuators = actuators,
            twinViewMode = viewMode,
            showSensorOverlay = sensorOverlay,
            showFaultOverlay = faultOverlay,
            simulationSpeedMultiplier = speed,
            operatorRole = role,
            darkTheme = dark,
            bannerFeedback = feedback,
            generatedReportMarkdown = report
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = run {
            val active = initialRuntimes.getValue("LOCK-AST-04")
            val sensors = active.buildSensors(initialNow)
            val actuators = active.buildActuators()
            LockOsUiState(
                activeRuntime = active,
                allRuntimes = initialRuntimes,
                hydraulics = HydraulicEngine.computeSnapshot(
                    active.config,
                    active.estimatedModelLevelM,
                    active.state.chamberLevelM,
                    active.config.normalUpstreamM,
                    active.config.normalDownstreamM,
                    0.0,
                    0.0,
                    0.0
                ),
                safetyEvaluation = SafetyLocalController.evaluate(
                    active.config,
                    active.state,
                    sensors,
                    actuators,
                    active.faults,
                    active.commHealthy,
                    initialNow
                ),
                sensors = sensors,
                actuators = actuators
            )
        }
    )

    val networkSummaries: StateFlow<List<NetworkLockSummary>> = combine(
        _runtimes,
        queueEntries,
        alarms,
        workOrders
    ) { runtimes, qList, aList, wList ->
        LockSiteCatalog.sites.map { site ->
            val rt = runtimes.getValue(site.lockId)
            val qCount = qList.count { it.lockId == site.lockId && it.status == QueueStatus.WAITING }
            val activeAlarms = aList.count { it.lockId == site.lockId && !it.resolved }
            val openOrder = wList.firstOrNull { it.lockId == site.lockId && it.status != WorkOrderStatus.COMPLETED }
            NetworkLockSummary(
                config = site,
                state = rt.state,
                queueCount = qCount,
                activeAlarmCount = activeAlarms,
                activeFaultsCount = rt.faults.activeCount,
                maintenanceNotice = openOrder?.title,
                estWaitMin = qCount * 11,
                gatewayLatencyMs = if (rt.commHealthy && !rt.faults.injectGatewayCommLoss) rt.gatewayLatencyMs else null,
                commHealthy = rt.commHealthy && !rt.faults.injectGatewayCommLoss
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.seedInitialEnterpriseDataIfEmpty(System.currentTimeMillis())
        }
        startSimulationLoop()
    }

    private fun startSimulationLoop() {
        viewModelScope.launch {
            var tickCounter = 0
            while (isActive) {
                delay(200L)
                val now = System.currentTimeMillis()
                val speed = _speedMultiplier.value.toDouble()
                val dtReal = 0.2
                val dtPhysics = dtReal * speed

                _runtimes.update { currentMap ->
                    currentMap.mapValues { (_, rt) ->
                        LockCycleOrchestrator.tick(rt, dtPhysics, dtReal, now)
                    }
                }

                tickCounter++
                if (tickCounter % 5 == 0) {
                    val active = _runtimes.value[_selectedLockId.value] ?: continue
                    val hyd = HydraulicEngine.computeSnapshot(
                        active.config,
                        active.estimatedModelLevelM,
                        active.state.chamberLevelM,
                        active.config.normalUpstreamM,
                        active.config.normalDownstreamM,
                        active.upstreamPaddlePercent.toDouble(),
                        active.downstreamPaddlePercent.toDouble(),
                        active.cycleWaterUsedM3
                    )
                    repository.recordTelemetry(
                        TelemetryPoint(
                            timestampMs = now,
                            lockId = active.config.lockId,
                            upstreamM = active.state.upstreamLevelM ?: active.config.normalUpstreamM,
                            chamberM = active.estimatedModelLevelM,
                            downstreamM = active.state.downstreamLevelM ?: active.config.normalDownstreamM,
                            flowRateM3s = hyd.inflowRateM3s - hyd.outflowRateM3s,
                            isSimulated = true
                        )
                    )
                }
            }
        }
    }

    fun selectLock(lockId: String) {
        if (_runtimes.value.containsKey(lockId)) {
            _selectedLockId.value = lockId
            _bannerFeedback.value = "Switched workstation view to $lockId"
        }
    }

    fun setTwinViewMode(mode: TwinViewMode) {
        _twinViewMode.value = mode
    }

    fun toggleSensorOverlay() {
        _showSensorOverlay.update { !it }
    }

    fun toggleFaultOverlay() {
        _showFaultOverlay.update { !it }
    }

    fun setSimulationSpeed(speed: Float) {
        _speedMultiplier.value = speed
    }

    fun setDarkTheme(enabled: Boolean) {
        _darkTheme.value = enabled
    }

    fun setOperatorRole(role: OperatorRole) {
        _operatorRole.value = role
        logAudit("Role switched to ${role.label}", "RBAC Policy Updated")
    }

    fun clearBannerFeedback() {
        _bannerFeedback.value = null
    }

    fun spawnSimulatedVesselApproach(direction: TravelDirection = TravelDirection.UPSTREAM_BOUND) {
        val lockId = _selectedLockId.value
        val now = System.currentTimeMillis()
        _runtimes.update { map ->
            val rt = map.getValue(lockId)
            map + (lockId to rt.copy(
                approachingVesselDetected = true,
                approachingDirection = direction,
                vesselProgress = if (direction == TravelDirection.UPSTREAM_BOUND) 0.92f else 0.08f,
                state = rt.state.copy(
                    vesselPresence = if (direction == TravelDirection.UPSTREAM_BOUND) {
                        PresenceState.ApproachingDownstream
                    } else {
                        PresenceState.ApproachingUpstream
                    },
                    cycleState = if (rt.phase == CyclePhase.IDLE) LockCycleState.VesselApproaching else rt.state.cycleState,
                    lastUpdatedEpochMs = now
                )
            ))
        }
        _bannerFeedback.value = "SIMULATION: Vessel radar target spawned (${direction.code})"
        logAudit("Simulated vessel approach triggered (${direction.label})", "Approach Radar Target Active")
    }

    fun registerVesselArrival(
        vesselName: String,
        registrationCode: String,
        lengthM: Double,
        direction: TravelDirection,
        priority: QueuePriority
    ) {
        val lockId = _selectedLockId.value
        val now = System.currentTimeMillis()
        val currentForLock = queueEntries.value.count { it.lockId == lockId && it.status == QueueStatus.WAITING }
        val nextPos = currentForLock + 1

        viewModelScope.launch {
            repository.registerArrival(
                VesselArrivalItem(
                    lockId = lockId,
                    vesselName = vesselName.ifBlank { "Vessel-${now % 1000}" },
                    registrationCode = registrationCode.ifBlank { "SIM-${now % 9999}" },
                    lengthM = lengthM.coerceIn(5.0, 45.0),
                    direction = direction,
                    priority = priority,
                    queuePosition = nextPos,
                    estimatedWaitMin = nextPos * 9,
                    status = QueueStatus.WAITING,
                    detectionSource = "SIMULATION: Operator Queue Registration + Approach Radar",
                    registeredAtMs = now
                )
            )
            _runtimes.update { map ->
                val rt = map.getValue(lockId)
                if (rt.phase == CyclePhase.IDLE) {
                    map + (lockId to rt.copy(
                        approachingVesselDetected = true,
                        approachingDirection = direction,
                        state = rt.state.copy(
                            cycleState = LockCycleState.QueuePositionAssigned,
                            lastUpdatedEpochMs = now
                        )
                    ))
                } else map
            }
            _bannerFeedback.value = "Arrival registered: $vesselName (Queue #$nextPos)"
            logAudit("Registered arrival $vesselName ($registrationCode) for ${direction.code}", "Queue #$nextPos Assigned")
        }
    }

    fun requestLockCycle(directionOverride: TravelDirection? = null) {
        val role = _operatorRole.value
        if (!role.canRequestCycle) {
            _bannerFeedback.value = "RBAC DENIED: ${role.label} cannot submit lock cycle requests."
            logAudit("Blocked cycle request by ${role.label}", "RBAC ACCESS DENIED")
            return
        }

        val lockId = _selectedLockId.value
        val rt = _runtimes.value.getValue(lockId)
        val now = System.currentTimeMillis()
        val sensors = rt.buildSensors(now)
        val actuators = rt.buildActuators()
        val eval = SafetyLocalController.evaluate(
            rt.config,
            rt.state,
            sensors,
            actuators,
            rt.faults,
            rt.commHealthy,
            now
        )

        if (!eval.movementPermitted) {
            _bannerFeedback.value = eval.summary
            logAudit("Submitted simulated cycle request", "WITHHELD BY ${rt.config.controllerId}: ${eval.summary}")
            viewModelScope.launch {
                repository.recordAlarm(
                    AlarmItem(
                        lockId = lockId,
                        code = "INT-HOLD-${now % 900 + 100}",
                        severity = AlarmSeverity.CRITICAL,
                        source = "SIMULATION: ${rt.config.controllerId}",
                        description = eval.summary,
                        timestampMs = now,
                        acknowledged = false
                    )
                )
            }
            return
        }

        if (rt.phase != CyclePhase.IDLE && rt.phase != CyclePhase.COMPLETED_HOLD) {
            _bannerFeedback.value = "Cycle already active (${rt.state.cycleState.label})"
            return
        }

        val nextWaiting = queueEntries.value.firstOrNull {
            it.lockId == lockId && it.status == QueueStatus.WAITING
        }
        val chosenDir = directionOverride ?: nextWaiting?.direction ?: rt.approachingDirection
        val vesselTitle = nextWaiting?.vesselName ?: "SIM-VESSEL-${(rt.completedCyclesCount + 1)}"

        if (nextWaiting != null) {
            viewModelScope.launch {
                repository.updateQueueStatus(nextWaiting.id, QueueStatus.IN_LOCK)
            }
        }

        _runtimes.update { map ->
            val current = map.getValue(lockId)
            map + (lockId to current.copy(
                phase = CyclePhase.EVALUATING_INTERLOCKS,
                phaseElapsedSec = 0.0,
                activeDirection = chosenDir,
                activeVesselName = vesselTitle,
                approachingVesselDetected = true,
                approachingDirection = chosenDir,
                vesselProgress = if (chosenDir == TravelDirection.UPSTREAM_BOUND) 0.88f else 0.12f,
                state = current.state.copy(
                    cycleState = LockCycleState.LocalControllerEvaluating,
                    lastUpdatedEpochMs = now
                )
            ))
        }
        _bannerFeedback.value = "Cycle request sent to ${rt.config.controllerId} — evaluating 7 interlocks..."
        logAudit("Submitted lock cycle request for $vesselTitle (${chosenDir.code})", "PLC Evaluating Readiness")
    }

    fun requestServicePause() {
        val lockId = _selectedLockId.value
        val now = System.currentTimeMillis()
        _runtimes.update { map ->
            val rt = map.getValue(lockId)
            val paused = rt.state.cycleState != LockCycleState.Paused
            map + (lockId to rt.copy(
                state = rt.state.copy(
                    cycleState = if (paused) LockCycleState.Paused else LockCycleState.AuthorisedCycleInProgress,
                    lastUpdatedEpochMs = now
                )
            ))
        }
        logAudit("Requested service pause toggle", "Controller State Updated")
    }

    fun triggerEmergencyStop(latch: Boolean) {
        val lockId = _selectedLockId.value
        val now = System.currentTimeMillis()
        _runtimes.update { map ->
            val rt = map.getValue(lockId)
            map + (lockId to rt.copy(
                faults = rt.faults.copy(eStopLatched = latch),
                state = rt.state.copy(lastUpdatedEpochMs = now)
            ))
        }
        if (latch) {
            _bannerFeedback.value = "EMERGENCY STOP LATCHED — all physical actuators de-energised"
            viewModelScope.launch {
                repository.recordAlarm(
                    AlarmItem(
                        lockId = lockId,
                        code = "ALM-ESTOP-001",
                        severity = AlarmSeverity.CRITICAL,
                        source = "Hardwired Safety Relay (${lockId})",
                        description = "Emergency Stop loop opened. Independent local interlock prevents restart until physical reset.",
                        timestampMs = now,
                        acknowledged = false
                    )
                )
            }
            logAudit("E-STOP activated", "SAFETY RELAY OPEN / LATCHED")
        } else {
            _bannerFeedback.value = "E-Stop latch cleared — PLC re-verifying interlocks"
            logAudit("E-Stop latch reset requested", "PLC Re-Evaluating Interlocks")
        }
    }

    fun toggleMaintenanceLockout() {
        val lockId = _selectedLockId.value
        val now = System.currentTimeMillis()
        _runtimes.update { map ->
            val rt = map.getValue(lockId)
            val enteringMaint = rt.state.operatingMode != OperatingMode.MaintenanceOutOfService
            map + (lockId to rt.copy(
                state = rt.state.copy(
                    operatingMode = if (enteringMaint) OperatingMode.MaintenanceOutOfService else OperatingMode.Simulation,
                    cycleState = if (enteringMaint) LockCycleState.MaintenanceUnavailable else LockCycleState.Idle,
                    lastUpdatedEpochMs = now
                )
            ))
        }
        logAudit("Toggled Maintenance Lockout status", "Mode Updated")
    }

    fun updateFaultInjection(transform: (FaultInjectionFlags) -> FaultInjectionFlags, description: String) {
        val lockId = _selectedLockId.value
        val now = System.currentTimeMillis()
        _runtimes.update { map ->
            val rt = map.getValue(lockId)
            val nextFaults = transform(rt.faults)
            map + (lockId to rt.copy(
                faults = nextFaults,
                state = rt.state.copy(lastUpdatedEpochMs = now)
            ))
        }
        _bannerFeedback.value = "SIMULATION FAULT: $description"
        viewModelScope.launch {
            repository.recordAlarm(
                AlarmItem(
                    lockId = lockId,
                    code = "SIM-FLT-${now % 900 + 100}",
                    severity = AlarmSeverity.WARNING,
                    source = "SIMULATION Fault Injector",
                    description = description,
                    timestampMs = now,
                    acknowledged = false
                )
            )
        }
        logAudit("Fault scenario toggled: $description", "Interlocks Re-Evaluated")
    }

    fun setDeterministicSeed(newSeed: Long) {
        val lockId = _selectedLockId.value
        val now = System.currentTimeMillis()
        _runtimes.update { map ->
            val rt = map.getValue(lockId)
            map + (lockId to LockCycleOrchestrator.createInitialRuntime(
                config = rt.config,
                seed = newSeed,
                nowMs = now,
                withApproachingVessel = true
            ))
        }
        _bannerFeedback.value = "Simulation reset with deterministic seed #$newSeed"
        logAudit("Reset simulation with seed #$newSeed", "SIMULATION RE-SEEDED")
    }

    fun saveCurrentSimulation(customTitle: String) {
        val active = uiState.value.activeRuntime
        val now = System.currentTimeMillis()
        val title = customTitle.ifBlank { "${active.config.lockId} · ${active.state.cycleState.label}" }
        viewModelScope.launch {
            repository.saveSimulation(
                SavedSimulationItem(
                    title = title,
                    lockId = active.config.lockId,
                    seed = active.seed,
                    cycleStateLabel = active.state.cycleState.label,
                    chamberLevelM = active.estimatedModelLevelM,
                    upstreamLevelM = active.config.normalUpstreamM,
                    downstreamLevelM = active.config.normalDownstreamM,
                    totalWaterUsedM3 = active.totalWaterUsedM3,
                    activeFaultSummary = if (active.faults.activeCount == 0) "Nominal (0 faults)" else "${active.faults.activeCount} active fault(s)",
                    savedAtMs = now
                )
            )
            _bannerFeedback.value = "Saved simulation snapshot: $title"
            logAudit("Saved simulation snapshot '$title'", "Persisted to Local Repository")
        }
    }

    fun loadSavedSimulation(item: SavedSimulationItem) {
        val now = System.currentTimeMillis()
        _selectedLockId.value = item.lockId
        _runtimes.update { map ->
            val current = map.getValue(item.lockId)
            map + (item.lockId to current.copy(
                seed = item.seed,
                estimatedModelLevelM = item.chamberLevelM,
                totalWaterUsedM3 = item.totalWaterUsedM3,
                faults = FaultInjectionFlags(),
                phase = CyclePhase.IDLE,
                state = current.state.copy(
                    chamberLevelM = item.chamberLevelM,
                    cycleState = LockCycleState.Idle,
                    lastUpdatedEpochMs = now
                )
            ))
        }
        _bannerFeedback.value = "Loaded snapshot '${item.title}' (Seed #${item.seed})"
        logAudit("Loaded saved snapshot '${item.title}'", "State Restored")
    }

    fun deleteSavedSimulation(id: Long) {
        viewModelScope.launch { repository.deleteSavedSimulation(id) }
    }

    fun generateEngineeringReport() {
        val st = uiState.value
        val lockId = st.selectedLockId
        val report = EngineeringReportGenerator.generateMarkdownReport(
            site = st.activeRuntime.config,
            state = st.activeRuntime.state,
            hydraulics = st.hydraulics,
            safety = st.safetyEvaluation,
            sensors = st.sensors,
            queue = queueEntries.value.filter { it.lockId == lockId },
            alarms = alarms.value.filter { it.lockId == lockId },
            recentAudit = auditEvents.value,
            simulationSeed = st.activeRuntime.seed,
            completedCyclesCount = st.activeRuntime.completedCyclesCount
        )
        _generatedReport.value = report
        logAudit("Generated engineering & safety report", "Report Compiled")
    }

    fun dismissEngineeringReport() {
        _generatedReport.value = null
    }

    fun acknowledgeAlarm(alarmId: Long) {
        val actor = "${uiState.value.operatorName} (${_operatorRole.value.label})"
        viewModelScope.launch {
            repository.acknowledgeAlarm(alarmId, actor, System.currentTimeMillis())
            logAudit("Acknowledged alarm #$alarmId", "Alarm Acknowledged")
        }
    }

    fun resolveAlarm(alarmId: Long) {
        viewModelScope.launch {
            repository.resolveAlarm(alarmId, "Verified clear by operator inspection.")
            logAudit("Resolved alarm #$alarmId", "Alarm Resolved")
        }
    }

    fun promoteQueueEntry(entry: VesselArrivalItem) {
        viewModelScope.launch {
            repository.promoteQueueEntry(entry.id, QueuePriority.EMERGENCY_VESSEL, 1)
            logAudit("Elevated priority for ${entry.vesselName}", "Queue Re-Ordered")
        }
    }

    fun cancelQueueEntry(entry: VesselArrivalItem) {
        viewModelScope.launch {
            repository.updateQueueStatus(entry.id, QueueStatus.CANCELLED)
            logAudit("Cancelled queue entry ${entry.vesselName}", "Queue Updated")
        }
    }

    fun createWorkOrder(
        category: AssetCategory,
        assetTag: String,
        title: String,
        priority: String,
        lotoRequired: Boolean,
        notes: String
    ) {
        val lockId = _selectedLockId.value
        val now = System.currentTimeMillis()
        viewModelScope.launch {
            repository.addWorkOrder(
                MaintenanceOrderItem(
                    lockId = lockId,
                    assetCategory = category,
                    assetTag = assetTag.ifBlank { "${category.name.take(3)}-${lockId.takeLast(2)}" },
                    title = title.ifBlank { "Scheduled engineering inspection" },
                    priority = priority,
                    status = if (lotoRequired) WorkOrderStatus.LOCKOUT_ACTIVE else WorkOrderStatus.OPEN,
                    physicalLotoRequired = lotoRequired,
                    technicianNotes = notes.ifBlank { "Follow physical LOTO isolation protocol before accessing machinery." },
                    scheduledDate = "2026-11-23",
                    createdAtMs = now
                )
            )
            _bannerFeedback.value = "Created maintenance work order for $lockId"
            logAudit("Created maintenance order: $title", "Maintenance Logged")
        }
    }

    fun advanceWorkOrderStatus(order: MaintenanceOrderItem) {
        val next = when (order.status) {
            WorkOrderStatus.OPEN -> WorkOrderStatus.IN_PROGRESS
            WorkOrderStatus.IN_PROGRESS -> WorkOrderStatus.COMPLETED
            WorkOrderStatus.LOCKOUT_ACTIVE -> WorkOrderStatus.COMPLETED
            WorkOrderStatus.COMPLETED -> WorkOrderStatus.OPEN
        }
        viewModelScope.launch {
            repository.updateWorkOrderStatus(order.id, next)
            logAudit("Updated work order #${order.id} -> ${next.label}", "Maintenance Updated")
        }
    }

    private fun logAudit(action: String, verdict: String) {
        val role = _operatorRole.value
        val lockId = _selectedLockId.value
        viewModelScope.launch {
            repository.appendAudit(
                AuditLogItem(
                    timestampMs = System.currentTimeMillis(),
                    actorName = uiState.value.operatorName,
                    actorRole = role.label,
                    action = action,
                    lockId = lockId,
                    controllerVerdict = verdict,
                    provenance = "SIMULATION: Seed #${uiState.value.activeRuntime.seed}"
                )
            )
        }
    }
}
