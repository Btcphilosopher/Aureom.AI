package com.example.lockos.domain.controller

import com.example.lockos.domain.model.ActuatorTelemetry
import com.example.lockos.domain.model.CanalLockState
import com.example.lockos.domain.model.FaultInjectionFlags
import com.example.lockos.domain.model.GateState
import com.example.lockos.domain.model.InterlockCheck
import com.example.lockos.domain.model.LockSiteConfig
import com.example.lockos.domain.model.OperatingMode
import com.example.lockos.domain.model.PaddleState
import com.example.lockos.domain.model.PresenceState
import com.example.lockos.domain.model.SafetyEvaluationResult
import com.example.lockos.domain.model.SafetyStatus
import com.example.lockos.domain.model.SensorHealth
import com.example.lockos.domain.model.SensorReading
import com.example.lockos.domain.model.SensorZone
import kotlin.math.abs

/**
 * Safety-rated local controller model.
 *
 * Supervisory software (LOCK.OS mobile/control centre) submits requests only.
 * This controller independently evaluates hardware interlocks, sensor certainty,
 * gate/paddle mechanical constraints, E-Stop loop state, and commissioning mode.
 */
object SafetyLocalController {

    private const val LEVEL_EQUALIZATION_TOLERANCE_M = 0.06

    fun evaluate(
        config: LockSiteConfig,
        lockState: CanalLockState,
        sensors: List<SensorReading>,
        actuators: List<ActuatorTelemetry>,
        faults: FaultInjectionFlags,
        commHealthy: Boolean,
        nowMs: Long
    ): SafetyEvaluationResult {
        val checks = mutableListOf<InterlockCheck>()

        // 1. Hardwired Emergency-Stop Circuit
        val eStopOk = !faults.eStopLatched
        checks += InterlockCheck(
            code = "INT-01",
            title = "Hardwired E-Stop Loop",
            passed = eStopOk,
            detail = if (eStopOk) {
                "Dual-channel safety relay closed (24V DC loop verified)"
            } else {
                "E-STOP LATCHED — independent safety relay open; all actuators de-energised"
            }
        )

        // 2. Gateway & Controller Heartbeat
        val heartbeatOk = commHealthy && !faults.injectGatewayCommLoss
        checks += InterlockCheck(
            code = "INT-02",
            title = "Gateway & PLC Heartbeat",
            passed = heartbeatOk,
            detail = if (heartbeatOk) {
                "Authorised gateway ${config.gatewayId} synchronized with ${config.controllerId}"
            } else {
                "COMM LOSS — gateway telemetry stale; remote movement requests withheld"
            }
        )

        // 3. Water-Level Sensor Certainty & Redundancy
        val up = lockState.upstreamLevelM
        val ch = lockState.chamberLevelM
        val dn = lockState.downstreamLevelM
        val levelSensors = sensors.filter { it.zone == SensorZone.Chamber || it.sensorId.contains("LVL") }
        val anyLevelFault = levelSensors.any {
            it.health == SensorHealth.Faulted || it.health == SensorHealth.Offline || it.isStale || !it.isCertain
        }
        val levelsValid = up != null && ch != null && dn != null && !anyLevelFault && !faults.injectLevelSensorDropout
        checks += InterlockCheck(
            code = "INT-03",
            title = "Water-Level Sensor Certainty",
            passed = levelsValid,
            detail = if (levelsValid) {
                "Redundant hydrostatic transducers nominal (Up=${"%.2f".format(up)}m, Ch=${"%.2f".format(ch)}m, Dn=${"%.2f".format(dn)}m)"
            } else {
                "SENSOR UNCERTAINTY — missing/faulted level reading; unknown values never treated as safe"
            }
        )

        // 4. Pedestrian & Maintenance Zone Protection
        val perimeterSensors = sensors.filter {
            it.zone == SensorZone.PedestrianPerimeter || it.zone == SensorZone.MaintenanceZone
        }
        val perimeterClear = !faults.injectPedestrianIntrusion &&
            lockState.vesselPresence != PresenceState.Obstructed &&
            perimeterSensors.none { it.numericValue == 1.0 || it.health == SensorHealth.Faulted || !it.isCertain }
        checks += InterlockCheck(
            code = "INT-04",
            title = "Protected Zone & Gate Threshold",
            passed = perimeterClear,
            detail = if (perimeterClear) {
                "LiDAR/Optical perimeter and gate thresholds clear of personnel & obstructions"
            } else {
                "PROTECTED ZONE INTRUSION — pedestrian or gate obstruction detected; motion inhibited"
            }
        )

        // 5. Gate-vs-Gate & Gate-vs-Paddle Mechanical Interlock
        val simultaneousGates = (lockState.upstreamGateState == GateState.Open || lockState.upstreamGateState == GateState.Opening) &&
            (lockState.downstreamGateState == GateState.Open || lockState.downstreamGateState == GateState.Opening)
        val crossFlow = (lockState.upstreamPaddleState == PaddleState.Open || lockState.upstreamPaddleState == PaddleState.Opening) &&
            (lockState.downstreamPaddleState == PaddleState.Open || lockState.downstreamPaddleState == PaddleState.Opening)
        val unequalUpGate = up != null && ch != null &&
            (lockState.upstreamGateState == GateState.Open || lockState.upstreamGateState == GateState.Opening) &&
            abs(up - ch) > LEVEL_EQUALIZATION_TOLERANCE_M
        val unequalDnGate = dn != null && ch != null &&
            (lockState.downstreamGateState == GateState.Open || lockState.downstreamGateState == GateState.Opening) &&
            abs(ch - dn) > LEVEL_EQUALIZATION_TOLERANCE_M
        val mechInterlockOk = !simultaneousGates && !crossFlow && !unequalUpGate && !unequalDnGate
        checks += InterlockCheck(
            code = "INT-05",
            title = "Hydraulic & Gate Cross-Interlocks",
            passed = mechInterlockOk,
            detail = when {
                simultaneousGates -> "VIOLATION: Upstream and downstream gates cannot open concurrently"
                crossFlow -> "VIOLATION: Upstream and downstream paddles cannot open concurrently"
                unequalUpGate || unequalDnGate -> "VIOLATION: Gate cannot unmitre while differential head exceeds ${LEVEL_EQUALIZATION_TOLERANCE_M}m"
                else -> "Gate-to-gate isolation and differential-head interlocks verified"
            }
        )

        // 6. Actuator Position Feedback Consistency
        val actuatorFault = faults.injectGatePositionMismatch ||
            faults.injectPaddleJam ||
            actuators.any { it.faultCode != null || !it.controllerAvailable } ||
            lockState.upstreamGateState == GateState.Faulted ||
            lockState.upstreamGateState == GateState.Unknown ||
            lockState.downstreamGateState == GateState.Faulted ||
            lockState.downstreamGateState == GateState.Unknown ||
            lockState.upstreamPaddleState == PaddleState.Faulted ||
            lockState.downstreamPaddleState == PaddleState.Faulted
        checks += InterlockCheck(
            code = "INT-06",
            title = "Actuator Feedback & Drive Health",
            passed = !actuatorFault,
            detail = if (!actuatorFault) {
                "All gate motors and sluice paddle limit switches agree with local PLC feedback"
            } else {
                "ACTUATOR FAULT — position mismatch, unknown limit state, or paddle jam latched"
            }
        )

        // 7. Operating Mode & Commissioning Gate
        val modeOk = lockState.operatingMode == OperatingMode.Simulation ||
            (lockState.operatingMode == OperatingMode.CommissionedAuto && config.commissionedForAuto)
        checks += InterlockCheck(
            code = "INT-07",
            title = "Operating Mode & Commissioning Gate",
            passed = modeOk,
            detail = when (lockState.operatingMode) {
                OperatingMode.Simulation -> "Authorized SIMULATION sandbox active (no physical field energisation)"
                OperatingMode.CommissionedAuto -> if (config.commissionedForAuto) {
                    "Site-commissioned automatic mode active"
                } else {
                    "BLOCKED: Site lacks formal engineering commissioning sign-off"
                }
                OperatingMode.LocalManual -> "LOCAL MANUAL ONLY — remote supervisory cycle requests disabled"
                OperatingMode.MaintenanceOutOfService -> "MAINTENANCE LOCKOUT — lock isolated from automated service"
            }
        )

        val derivedStatus = when {
            !eStopOk -> SafetyStatus.EmergencyStopLatched
            lockState.operatingMode == OperatingMode.MaintenanceOutOfService -> SafetyStatus.MaintenanceLockout
            !heartbeatOk || !levelsValid -> SafetyStatus.SensorUncertaintyHold
            !perimeterClear || !mechInterlockOk || actuatorFault -> SafetyStatus.FaultLatched
            !modeOk -> SafetyStatus.InterlockHold
            else -> SafetyStatus.SafeAuthorised
        }

        val permitted = checks.all { it.passed }
        val summary = if (permitted) {
            "${config.controllerId}: All 7 safety interlocks verified. Ready for controlled sequencing."
        } else {
            val failed = checks.first { !it.passed }
            "${config.controllerId} HOLD [${failed.code}]: ${failed.detail}"
        }

        return SafetyEvaluationResult(
            controllerId = config.controllerId,
            timestampMs = nowMs,
            movementPermitted = permitted,
            safetyStatus = derivedStatus,
            summary = summary,
            checks = checks
        )
    }

    /**
     * Checks whether a specific gate can be commanded to open safely.
     */
    fun canOpenGate(
        isUpstream: Boolean,
        upstreamLevelM: Double?,
        chamberLevelM: Double?,
        downstreamLevelM: Double?,
        oppositeGateState: GateState,
        oppositePaddleState: PaddleState
    ): Boolean {
        if (upstreamLevelM == null || chamberLevelM == null || downstreamLevelM == null) return false
        if (oppositeGateState != GateState.Closed) return false
        if (oppositePaddleState != PaddleState.Closed) return false
        val diff = if (isUpstream) abs(upstreamLevelM - chamberLevelM) else abs(chamberLevelM - downstreamLevelM)
        return diff <= LEVEL_EQUALIZATION_TOLERANCE_M
    }
}
