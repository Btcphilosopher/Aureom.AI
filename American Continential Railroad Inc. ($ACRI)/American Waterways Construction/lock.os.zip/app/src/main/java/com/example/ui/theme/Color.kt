package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LOCK.OS Industrial SCADA Palette
val DeepNavy = Color(0xFF07111F)
val PanelNavy = Color(0xFF0D1B2E)
val ElevatedNavy = Color(0xFF13263E)
val SteelSurface = Color(0xFF1B2B41)
val SteelBorder = Color(0xFF2B3E58)
val SteelMuted = Color(0xFF64748B)
val SteelLight = Color(0xFF94A3B8)

val EngineeringBlue = Color(0xFF1E6FD9)
val TelemetryCyan = Color(0xFF38BDF8)
val WaterwayWater = Color(0xFF0EA5E9)
val WaterwayDeep = Color(0xFF0369A1)

val CrispWhite = Color(0xFFF8FAFC)
val WaterwayGreen = Color(0xFF10B981)
val WaterwayGreenBg = Color(0xFF064E3B)

val AmberWarning = Color(0xFFF59E0B)
val AmberWarningBg = Color(0xFF451A03)

val RedAlarm = Color(0xFFEF4444)
val RedAlarmBg = Color(0xFF450A0A)

// Daylight Field Mode Palette (High-contrast outdoor inspection)
val FieldBackground = Color(0xFFF1F5F9)
val FieldSurface = Color(0xFFFFFFFF)
val FieldSurfaceVariant = Color(0xFFE2E8F0)
val FieldNavyInk = Color(0xFF0F172A)
val FieldMutedInk = Color(0xFF475569)
val FieldBorder = Color(0xFFCBD5E1)
