package com.example.lockos.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.lockos.domain.model.NetworkLockSummary
import com.example.lockos.domain.model.OperatingMode
import com.example.lockos.domain.model.SafetyStatus
import com.example.lockos.ui.components.StatusPill
import com.example.ui.theme.LocalLockOsColors
import kotlin.math.hypot

private enum class NetworkFilter(val label: String) {
    ALL("All Locks"),
    AVAILABLE("Available"),
    FAULTS("Active Faults"),
    MAINTENANCE("Maintenance")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WaterwayNetworkScreen(
    summaries: List<NetworkLockSummary>,
    selectedLockId: String,
    onSelectLock: (String) -> Unit,
    onOpenLockControl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    var filter by remember { mutableStateOf(NetworkFilter.ALL) }
    var waterwayFilter by remember { mutableStateOf("All") }
    val mapCd = stringResource(R.string.cd_waterway_map)

    val waterways = remember(summaries) {
        listOf("All") + summaries.map { it.config.waterway }.distinct()
    }

    val filtered = remember(summaries, filter, waterwayFilter) {
        summaries.filter { item ->
            val matchWaterway = waterwayFilter == "All" || item.config.waterway == waterwayFilter
            val matchStatus = when (filter) {
                NetworkFilter.ALL -> true
                NetworkFilter.AVAILABLE -> item.state.safetyStatus == SafetyStatus.SafeAuthorised &&
                    item.state.operatingMode != OperatingMode.MaintenanceOutOfService
                NetworkFilter.FAULTS -> item.activeFaultsCount > 0 || item.activeAlarmCount > 0 ||
                    item.state.safetyStatus != SafetyStatus.SafeAuthorised
                NetworkFilter.MAINTENANCE -> item.maintenanceNotice != null ||
                    item.state.operatingMode == OperatingMode.MaintenanceOutOfService
            }
            matchWaterway && matchStatus
        }
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 860.dp)
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "WATERWAY NETWORK MAP (SIMULATION)",
                                style = MaterialTheme.typography.titleSmall,
                                color = sem.telemetryCyan
                            )
                            Text(
                                text = "Tap any lock node on the basin schematic to inspect or switch workstation focus.",
                                style = MaterialTheme.typography.bodySmall,
                                color = sem.mutedLabel
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                            .background(Color(0xFF050D18), MaterialTheme.shapes.medium)
                            .border(1.dp, sem.panelBorder, MaterialTheme.shapes.medium)
                            .semantics { contentDescription = mapCd }
                            .testTag("waterway_network_canvas")
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(summaries) {
                                    detectTapGestures { offset ->
                                        val hit = summaries.minByOrNull { s ->
                                            val nx = s.config.mapNormalizedX * size.width
                                            val ny = s.config.mapNormalizedY * size.height
                                            hypot(offset.x - nx, offset.y - ny)
                                        }
                                        if (hit != null) {
                                            val nx = hit.config.mapNormalizedX * size.width
                                            val ny = hit.config.mapNormalizedY * size.height
                                            if (hypot(offset.x - nx, offset.y - ny) < 70f) {
                                                onSelectLock(hit.config.lockId)
                                            }
                                        }
                                    }
                                }
                        ) {
                            val w = size.width
                            val h = size.height

                            // Background topo grid
                            for (i in 1..5) {
                                drawLine(Color(0xFF0F2036), Offset(0f, h * i / 6f), Offset(w, h * i / 6f), 1f)
                                drawLine(Color(0xFF0F2036), Offset(w * i / 6f, 0f), Offset(w * i / 6f, h), 1f)
                            }

                            // Main canal trunk path connecting locks
                            val sorted = summaries.sortedBy { it.config.elevationOrder }
                            if (sorted.size >= 2) {
                                val canalPath = Path().apply {
                                    moveTo(w * 0.08f, h * 0.45f)
                                    sorted.forEach { s ->
                                        lineTo(s.config.mapNormalizedX * w, s.config.mapNormalizedY * h)
                                    }
                                    lineTo(w * 0.94f, h * 0.30f)
                                }
                                drawPath(canalPath, color = Color(0x440EA5E9), style = Stroke(width = 16f))
                                drawPath(
                                    canalPath,
                                    color = Color(0xFF38BDF8),
                                    style = Stroke(width = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f)))
                                )
                            }

                            // Lock nodes
                            summaries.forEach { summary ->
                                val cx = summary.config.mapNormalizedX * w
                                val cy = summary.config.mapNormalizedY * h
                                val isSelected = summary.config.lockId == selectedLockId
                                val nodeColor = when {
                                    summary.state.safetyStatus == SafetyStatus.EmergencyStopLatched ||
                                        summary.activeFaultsCount > 0 -> Color(0xFFEF4444)
                                    summary.activeAlarmCount > 0 ||
                                        summary.state.operatingMode == OperatingMode.MaintenanceOutOfService -> Color(0xFFF59E0B)
                                    else -> Color(0xFF10B981)
                                }
                                if (isSelected) {
                                    drawCircle(Color(0x5538BDF8), radius = 28f, center = Offset(cx, cy))
                                    drawCircle(Color(0xFF38BDF8), radius = 26f, center = Offset(cx, cy), style = Stroke(width = 2.5f))
                                }
                                drawCircle(Color(0xFF0D1B2E), radius = 16f, center = Offset(cx, cy))
                                drawCircle(nodeColor, radius = 11f, center = Offset(cx, cy))
                            }
                        }

                        // Node labels overlay
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                                .background(Color(0xCC07111F), MaterialTheme.shapes.small)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Selected: $selectedLockId · ${summaries.size} Monitored Sites",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        NetworkFilter.entries.forEach { f ->
                            FilterChip(
                                selected = filter == f,
                                onClick = { filter = f },
                                label = { Text(f.label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("network_filter_${f.name.lowercase()}")
                            )
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        waterways.forEach { ww ->
                            FilterChip(
                                selected = waterwayFilter == ww,
                                onClick = { waterwayFilter = ww },
                                label = { Text(ww, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }

            // Water Management Summary
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "WATER MANAGEMENT & BASIN BALANCE",
                        style = MaterialTheme.typography.titleSmall,
                        color = sem.telemetryCyan
                    )
                    Text(
                        text = "Upstream summit storage nominal. Lumped-parameter telemetry monitors net basin drawdown across ${summaries.size} lock chambers.",
                        style = MaterialTheme.typography.bodySmall,
                        color = sem.mutedLabel
                    )
                }
            }

            items(filtered, key = { it.config.lockId }) { summary ->
                val isSelected = summary.config.lockId == selectedLockId
                val statusColor = when {
                    summary.activeFaultsCount > 0 || summary.state.safetyStatus == SafetyStatus.EmergencyStopLatched -> sem.alarmRed
                    summary.activeAlarmCount > 0 || summary.state.operatingMode == OperatingMode.MaintenanceOutOfService -> sem.warningAmber
                    else -> sem.safeGreen
                }
                val statusBg = when {
                    summary.activeFaultsCount > 0 || summary.state.safetyStatus == SafetyStatus.EmergencyStopLatched -> sem.alarmRedBg
                    summary.activeAlarmCount > 0 || summary.state.operatingMode == OperatingMode.MaintenanceOutOfService -> sem.warningAmberBg
                    else -> sem.safeGreenBg
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) sem.telemetryCyan else sem.panelBorder,
                            shape = MaterialTheme.shapes.large
                        )
                        .clickable { onSelectLock(summary.config.lockId) }
                        .padding(12.dp)
                        .testTag("network_card_${summary.config.lockId}"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(summary.config.name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                            Text(
                                text = "${summary.config.lockId} · ${summary.config.waterway} · ${summary.config.region}",
                                style = MaterialTheme.typography.bodySmall,
                                color = sem.mutedLabel
                            )
                        }
                        StatusPill(
                            text = summary.state.safetyStatus.label.take(18),
                            fg = statusColor,
                            bg = statusBg
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Queue: ${summary.queueCount} (~${summary.estWaitMin}m)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface)
                        Text("Alarms: ${summary.activeAlarmCount} · Faults: ${summary.activeFaultsCount}", style = MaterialTheme.typography.labelSmall, color = sem.mutedLabel)
                        Text(
                            text = summary.gatewayLatencyMs?.let { "GW ${it}ms" } ?: "GW OFFLINE",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (summary.commHealthy) sem.safeGreen else sem.alarmRed
                        )
                    }

                    if (summary.maintenanceNotice != null) {
                        Text(
                            text = "Maint Notice: ${summary.maintenanceNotice}",
                            style = MaterialTheme.typography.bodySmall,
                            color = sem.warningAmber
                        )
                    }

                    Button(
                        onClick = { onOpenLockControl(summary.config.lockId) },
                        modifier = Modifier.fillMaxWidth().testTag("open_lock_${summary.config.lockId}")
                    ) {
                        Text("Open in Lock Control Centre", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
