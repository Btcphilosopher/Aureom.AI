package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.DirectionsBoat
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.lockos.ui.components.EngineeringReportDialog
import com.example.lockos.ui.components.RegisterArrivalDialog
import com.example.lockos.ui.components.SaveSimulationDialog
import com.example.lockos.ui.components.TopSupervisoryBar
import com.example.lockos.ui.screens.ControlCentreScreen
import com.example.lockos.ui.screens.OperationsHubScreen
import com.example.lockos.ui.screens.QueueScreen
import com.example.lockos.ui.screens.TelemetryAnalyticsScreen
import com.example.lockos.ui.screens.WaterwayNetworkScreen
import com.example.lockos.ui.state.LockOsViewModel
import com.example.ui.theme.LockOsTheme

const val ROUTE_CONTROL = "control"
const val ROUTE_NETWORK = "network"
const val ROUTE_QUEUE = "queue"
const val ROUTE_TELEMETRY = "telemetry"
const val ROUTE_OPERATIONS = "operations"

private data class NavDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val destinations = listOf(
    NavDestination(ROUTE_CONTROL, R.string.nav_control, Icons.Filled.Tune, Icons.Outlined.Tune),
    NavDestination(ROUTE_NETWORK, R.string.nav_network, Icons.Filled.Map, Icons.Outlined.Map),
    NavDestination(ROUTE_QUEUE, R.string.nav_queue, Icons.Filled.DirectionsBoat, Icons.Outlined.DirectionsBoat),
    NavDestination(ROUTE_TELEMETRY, R.string.nav_telemetry, Icons.Filled.ShowChart, Icons.Outlined.ShowChart),
    NavDestination(ROUTE_OPERATIONS, R.string.nav_operations, Icons.Filled.Build, Icons.Outlined.Build)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: LockOsViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            LockOsTheme(darkTheme = uiState.darkTheme) {
                LockOsRootShell(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun LockOsRootShell(viewModel: LockOsViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val queueEntries by viewModel.queueEntries.collectAsStateWithLifecycle()
    val alarms by viewModel.alarms.collectAsStateWithLifecycle()
    val workOrders by viewModel.workOrders.collectAsStateWithLifecycle()
    val auditEvents by viewModel.auditEvents.collectAsStateWithLifecycle()
    val savedSimulations by viewModel.savedSimulations.collectAsStateWithLifecycle()
    val telemetryHistory by viewModel.telemetryHistory.collectAsStateWithLifecycle()
    val networkSummaries by viewModel.networkSummaries.collectAsStateWithLifecycle()

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_CONTROL

    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    var showRegisterArrivalDialog by remember { mutableStateOf(false) }
    var showSaveSnapshotDialog by remember { mutableStateOf(false) }

    val activeAlarmCount = remember(alarms) { alarms.count { !it.resolved } }

    LaunchedEffect(uiState.bannerFeedback) {
        val msg = uiState.bannerFeedback
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBannerFeedback()
        }
    }

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    NavigationBar {
                        destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            val label = stringResource(dest.labelRes)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    if (dest.route == ROUTE_OPERATIONS && activeAlarmCount > 0) {
                                        BadgedBox(badge = { Badge { Text("$activeAlarmCount") } }) {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = label
                                            )
                                        }
                                    } else {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = label
                                        )
                                    }
                                },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("nav_${dest.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            val label = stringResource(dest.labelRes)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    if (dest.route == ROUTE_OPERATIONS && activeAlarmCount > 0) {
                                        BadgedBox(badge = { Badge { Text("$activeAlarmCount") } }) {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = label
                                            )
                                        }
                                    } else {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = label
                                        )
                                    }
                                },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("nav_${dest.route}")
                            )
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f).fillMaxSize()) {
                    TopSupervisoryBar(
                        uiState = uiState,
                        activeAlarmCount = activeAlarmCount,
                        onSelectLock = { viewModel.selectLock(it) },
                        onToggleEStop = { viewModel.triggerEmergencyStop(it) }
                    )

                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_CONTROL,
                        modifier = Modifier.weight(1f).fillMaxSize()
                    ) {
                        composable(ROUTE_CONTROL) {
                            ControlCentreScreen(
                                uiState = uiState,
                                savedSimulations = savedSimulations,
                                onSelectTwinView = viewModel::setTwinViewMode,
                                onToggleSensorOverlay = viewModel::toggleSensorOverlay,
                                onToggleFaultOverlay = viewModel::toggleFaultOverlay,
                                onSpawnApproach = viewModel::spawnSimulatedVesselApproach,
                                onOpenRegisterArrival = { showRegisterArrivalDialog = true },
                                onRequestCycle = { viewModel.requestLockCycle() },
                                onServicePause = viewModel::requestServicePause,
                                onMaintenanceLockout = viewModel::toggleMaintenanceLockout,
                                onOpenSaveSimulation = { showSaveSnapshotDialog = true },
                                onGenerateReport = viewModel::generateEngineeringReport,
                                onFaultToggle = viewModel::updateFaultInjection,
                                onLoadSnapshot = viewModel::loadSavedSimulation,
                                onDeleteSnapshot = viewModel::deleteSavedSimulation
                            )
                        }
                        composable(ROUTE_NETWORK) {
                            WaterwayNetworkScreen(
                                summaries = networkSummaries,
                                selectedLockId = uiState.selectedLockId,
                                onSelectLock = viewModel::selectLock,
                                onOpenLockControl = { id ->
                                    viewModel.selectLock(id)
                                    navigateTo(ROUTE_CONTROL)
                                }
                            )
                        }
                        composable(ROUTE_QUEUE) {
                            QueueScreen(
                                uiState = uiState,
                                queueEntries = queueEntries,
                                onOpenRegisterArrival = { showRegisterArrivalDialog = true },
                                onRequestCycle = { viewModel.requestLockCycle() },
                                onPromoteEntry = viewModel::promoteQueueEntry,
                                onCancelEntry = viewModel::cancelQueueEntry
                            )
                        }
                        composable(ROUTE_TELEMETRY) {
                            TelemetryAnalyticsScreen(
                                uiState = uiState,
                                telemetryHistory = telemetryHistory
                            )
                        }
                        composable(ROUTE_OPERATIONS) {
                            OperationsHubScreen(
                                uiState = uiState,
                                alarms = alarms,
                                workOrders = workOrders,
                                auditEvents = auditEvents,
                                onAckAlarm = viewModel::acknowledgeAlarm,
                                onResolveAlarm = viewModel::resolveAlarm,
                                onCreateWorkOrder = viewModel::createWorkOrder,
                                onAdvanceWorkOrder = viewModel::advanceWorkOrderStatus,
                                onSelectRole = viewModel::setOperatorRole,
                                onSetSeed = viewModel::setDeterministicSeed,
                                onSetSpeed = viewModel::setSimulationSpeed,
                                onSetDarkTheme = viewModel::setDarkTheme
                            )
                        }
                    }
                }
            }
        }
    }

    if (showRegisterArrivalDialog) {
        RegisterArrivalDialog(
            lockId = uiState.selectedLockId,
            onDismiss = { showRegisterArrivalDialog = false },
            onConfirm = { name, reg, len, dir, prio ->
                viewModel.registerVesselArrival(name, reg, len, dir, prio)
                showRegisterArrivalDialog = false
            }
        )
    }

    if (showSaveSnapshotDialog) {
        val rt = uiState.activeRuntime
        SaveSimulationDialog(
            defaultTitle = "${rt.config.lockId} · ${rt.state.cycleState.label}",
            onDismiss = { showSaveSnapshotDialog = false },
            onConfirm = { title ->
                viewModel.saveCurrentSimulation(title)
                showSaveSnapshotDialog = false
            }
        )
    }

    val reportText = uiState.generatedReportMarkdown
    if (reportText != null) {
        EngineeringReportDialog(
            reportText = reportText,
            onDismiss = viewModel::dismissEngineeringReport,
            onCopy = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("LOCK.OS Engineering Report", reportText))
            },
            onShare = {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "LOCK.OS Engineering Report — ${uiState.selectedLockId}")
                    putExtra(Intent.EXTRA_TEXT, reportText)
                }
                context.startActivity(Intent.createChooser(sendIntent, "Share Engineering Report"))
            }
        )
    }
}
