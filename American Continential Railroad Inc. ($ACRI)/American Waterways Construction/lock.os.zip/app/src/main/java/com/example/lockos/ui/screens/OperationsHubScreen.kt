package com.example.lockos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.lockos.data.seed.LockSiteCatalog
import com.example.lockos.domain.model.AlarmItem
import com.example.lockos.domain.model.AlarmSeverity
import com.example.lockos.domain.model.AssetCategory
import com.example.lockos.domain.model.AuditLogItem
import com.example.lockos.domain.model.MaintenanceOrderItem
import com.example.lockos.domain.model.OperatorRole
import com.example.lockos.domain.model.WorkOrderStatus
import com.example.lockos.ui.components.StatusPill
import com.example.lockos.ui.state.LockOsUiState
import com.example.ui.theme.LocalLockOsColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class OpsTab(val title: String) {
    ALARMS("Alarms"),
    MAINTENANCE("Maint"),
    AUDIT("Audit"),
    ADMIN("Admin")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OperationsHubScreen(
    uiState: LockOsUiState,
    alarms: List<AlarmItem>,
    workOrders: List<MaintenanceOrderItem>,
    auditEvents: List<AuditLogItem>,
    onAckAlarm: (Long) -> Unit,
    onResolveAlarm: (Long) -> Unit,
    onCreateWorkOrder: (AssetCategory, String, String, String, Boolean, String) -> Unit,
    onAdvanceWorkOrder: (MaintenanceOrderItem) -> Unit,
    onSelectRole: (OperatorRole) -> Unit,
    onSetSeed: (Long) -> Unit,
    onSetSpeed: (Float) -> Unit,
    onSetDarkTheme: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    var selectedTab by remember { mutableStateOf(OpsTab.ALARMS) }
    var showCreateWorkOrder by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        TabRow(
            selectedTabIndex = selectedTab.ordinal,
            modifier = Modifier.widthIn(max = 860.dp)
        ) {
            OpsTab.entries.forEach { tab ->
                Tab(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    text = { Text(tab.title, style = MaterialTheme.typography.labelLarge) },
                    modifier = Modifier.testTag("ops_tab_${tab.name.lowercase()}")
                )
            }
        }

        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 860.dp)
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Spacer(modifier = Modifier.height(6.dp)) }

                when (selectedTab) {
                    OpsTab.ALARMS -> {
                        item {
                            Text(
                                text = "ENTERPRISE ALARM CENTRE (${alarms.count { !it.resolved }} ACTIVE)",
                                style = MaterialTheme.typography.titleSmall,
                                color = sem.telemetryCyan
                            )
                        }
                        items(alarms, key = { it.id }) { alarm ->
                            val sevColor = when (alarm.severity) {
                                AlarmSeverity.CRITICAL -> sem.alarmRed
                                AlarmSeverity.WARNING -> sem.warningAmber
                                AlarmSeverity.ADVISORY -> sem.telemetryCyan
                            }
                            val sevBg = when (alarm.severity) {
                                AlarmSeverity.CRITICAL -> sem.alarmRedBg
                                AlarmSeverity.WARNING -> sem.warningAmberBg
                                AlarmSeverity.ADVISORY -> MaterialTheme.colorScheme.primaryContainer
                            }
                            val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium)
                                    .border(1.dp, if (alarm.resolved) sem.panelBorder else sevColor.copy(alpha = 0.6f), MaterialTheme.shapes.medium)
                                    .padding(10.dp)
                                    .testTag("alarm_card_${alarm.id}"),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${alarm.code} · ${alarm.lockId}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    StatusPill(
                                        text = if (alarm.resolved) "RESOLVED" else alarm.severity.label,
                                        fg = if (alarm.resolved) sem.safeGreen else sevColor,
                                        bg = if (alarm.resolved) sem.safeGreenBg else sevBg
                                    )
                                }
                                Text(alarm.description, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "${alarm.source} · ${fmt.format(Date(alarm.timestampMs))}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = sem.mutedLabel
                                )
                                if (alarm.acknowledged && alarm.acknowledgedBy != null) {
                                    Text(
                                        text = "ACK by ${alarm.acknowledgedBy}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = sem.safeGreen
                                    )
                                }
                                if (!alarm.resolved) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (!alarm.acknowledged) {
                                            OutlinedButton(
                                                onClick = { onAckAlarm(alarm.id) },
                                                modifier = Modifier.testTag("ack_alarm_${alarm.id}")
                                            ) {
                                                Text("Acknowledge", style = MaterialTheme.typography.labelMedium)
                                            }
                                        }
                                        Button(
                                            onClick = { onResolveAlarm(alarm.id) },
                                            modifier = Modifier.testTag("resolve_alarm_${alarm.id}")
                                        ) {
                                            Text("Resolve", style = MaterialTheme.typography.labelMedium)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    OpsTab.MAINTENANCE -> {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "MAINTENANCE & ASSET WORK ORDERS",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = sem.telemetryCyan
                                    )
                                    Text(
                                        text = "Software lockout tracking never replaces physical LOTO isolation.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = sem.warningAmber
                                    )
                                }
                                Button(
                                    onClick = { showCreateWorkOrder = true },
                                    modifier = Modifier.testTag("new_work_order_button")
                                ) {
                                    Text("+ Work Order")
                                }
                            }
                        }

                        items(workOrders, key = { it.id }) { order ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium)
                                    .border(1.dp, sem.panelBorder, MaterialTheme.shapes.medium)
                                    .padding(10.dp)
                                    .testTag("work_order_${order.id}"),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${order.assetTag} · ${order.assetCategory.label}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = sem.telemetryCyan
                                    )
                                    StatusPill(
                                        text = order.status.label,
                                        fg = if (order.status == WorkOrderStatus.COMPLETED) sem.safeGreen else sem.warningAmber,
                                        bg = if (order.status == WorkOrderStatus.COMPLETED) sem.safeGreenBg else sem.warningAmberBg
                                    )
                                }
                                Text(order.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(order.technicianNotes, style = MaterialTheme.typography.bodySmall, color = sem.mutedLabel)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${order.lockId} · Due ${order.scheduledDate} · LOTO: ${if (order.physicalLotoRequired) "REQUIRED" else "NO"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (order.physicalLotoRequired) sem.alarmRed else sem.mutedLabel
                                    )
                                    OutlinedButton(onClick = { onAdvanceWorkOrder(order) }) {
                                        Text("Advance", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }

                    OpsTab.AUDIT -> {
                        item {
                            Text(
                                text = "IMMUTABLE SAFETY & OPERATOR AUDIT TRAIL",
                                style = MaterialTheme.typography.titleSmall,
                                color = sem.telemetryCyan
                            )
                        }
                        items(auditEvents, key = { it.id }) { ev ->
                            val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.small)
                                    .border(1.dp, sem.panelBorder, MaterialTheme.shapes.small)
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${ev.actorName} (${ev.actorRole})", style = MaterialTheme.typography.labelMedium, color = sem.telemetryCyan)
                                    Text(fmt.format(Date(ev.timestampMs)), style = MaterialTheme.typography.labelSmall, color = sem.mutedLabel)
                                }
                                Text(ev.action, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "${ev.lockId} · Verdict: ${ev.controllerVerdict} · ${ev.provenance}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = sem.mutedLabel
                                )
                            }
                        }
                    }

                    OpsTab.ADMIN -> {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                                    .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("OPERATOR ADMINISTRATION & RBAC", style = MaterialTheme.typography.titleSmall, color = sem.telemetryCyan)
                                Text(
                                    text = "Active Role: ${uiState.operatorRole.label}. Public observers cannot trigger physical/simulated cycles.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = sem.mutedLabel
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OperatorRole.entries.forEach { role ->
                                        FilterChip(
                                            selected = uiState.operatorRole == role,
                                            onClick = { onSelectRole(role) },
                                            label = { Text(role.label, style = MaterialTheme.typography.labelSmall) },
                                            modifier = Modifier.testTag("role_chip_${role.name.lowercase()}")
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            var seedInput by remember(uiState.activeRuntime.seed) {
                                mutableStateOf(uiState.activeRuntime.seed.toString())
                            }
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                                    .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("SIMULATION ENGINE & DISPLAY SETTINGS", style = MaterialTheme.typography.titleSmall, color = sem.telemetryCyan)

                                Text(
                                    text = "Simulation Time Scale: ${uiState.simulationSpeedMultiplier.toInt()}x",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Slider(
                                    value = uiState.simulationSpeedMultiplier,
                                    onValueChange = onSetSpeed,
                                    valueRange = 2f..16f,
                                    steps = 6
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = seedInput,
                                        onValueChange = { seedInput = it.filter { ch -> ch.isDigit() } },
                                        label = { Text("Deterministic Seed") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        onClick = {
                                            seedInput.toLongOrNull()?.let { onSetSeed(it) }
                                        },
                                        modifier = Modifier.testTag("apply_seed_button")
                                    ) {
                                        Text("Apply Seed")
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Industrial Dark Control Centre Theme", style = MaterialTheme.typography.bodyMedium)
                                    Switch(
                                        checked = uiState.darkTheme,
                                        onCheckedChange = onSetDarkTheme,
                                        modifier = Modifier.testTag("theme_switch")
                                    )
                                }
                            }
                        }

                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
                                    .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("SITE COMMISSIONING & SECURITY GATE", style = MaterialTheme.typography.titleSmall, color = sem.telemetryCyan)
                                LockSiteCatalog.sites.forEach { site ->
                                    Text(
                                        text = "${site.lockId} · ${site.controllerId} · ${site.gatewayId} · Auto Commissioned: ${if (site.commissionedForAuto) "YES" else "NO (Simulation Only)"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = sem.mutedLabel
                                    )
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }

    if (showCreateWorkOrder) {
        CreateWorkOrderDialog(
            lockId = uiState.selectedLockId,
            onDismiss = { showCreateWorkOrder = false },
            onConfirm = { cat, tag, title, prio, loto, notes ->
                onCreateWorkOrder(cat, tag, title, prio, loto, notes)
                showCreateWorkOrder = false
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CreateWorkOrderDialog(
    lockId: String,
    onDismiss: () -> Unit,
    onConfirm: (AssetCategory, String, String, String, Boolean, String) -> Unit
) {
    var category by remember { mutableStateOf(AssetCategory.GATE_MOTOR) }
    var tag by remember { mutableStateOf("MTR-${lockId.takeLast(2)}-01") }
    var title by remember { mutableStateOf("Inspect miter gate drive torque & limit switch alignment") }
    var loto by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("Verify physical isolation padlock before entering gate recess.") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Work Order ($lockId)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Asset Category", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    AssetCategory.entries.take(6).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Asset Tag") }, singleLine = true)
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Work Description") })
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Technician Notes") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = loto, onCheckedChange = { loto = it })
                    Text("Physical LOTO Isolation Required", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(category, tag, title, "HIGH", loto, notes) }) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
