package com.example.lockos.data.local

import com.example.lockos.domain.model.AlarmItem
import com.example.lockos.domain.model.AlarmSeverity
import com.example.lockos.domain.model.AssetCategory
import com.example.lockos.domain.model.AuditLogItem
import com.example.lockos.domain.model.MaintenanceOrderItem
import com.example.lockos.domain.model.QueuePriority
import com.example.lockos.domain.model.QueueStatus
import com.example.lockos.domain.model.SavedSimulationItem
import com.example.lockos.domain.model.TelemetryPoint
import com.example.lockos.domain.model.TravelDirection
import com.example.lockos.domain.model.VesselArrivalItem
import com.example.lockos.domain.model.WorkOrderStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LockOsRepository(private val dao: LockOsDao) {

    val savedSimulations: Flow<List<SavedSimulationItem>> =
        dao.observeSavedSimulations().map { list ->
            list.map {
                SavedSimulationItem(
                    id = it.id,
                    title = it.title,
                    lockId = it.lockId,
                    seed = it.seed,
                    cycleStateLabel = it.cycleStateLabel,
                    chamberLevelM = it.chamberLevelM,
                    upstreamLevelM = it.upstreamLevelM,
                    downstreamLevelM = it.downstreamLevelM,
                    totalWaterUsedM3 = it.totalWaterUsedM3,
                    activeFaultSummary = it.activeFaultSummary,
                    savedAtMs = it.savedAtMs
                )
            }
        }

    val queueEntries: Flow<List<VesselArrivalItem>> =
        dao.observeQueueEntries().map { list ->
            list.map {
                VesselArrivalItem(
                    id = it.id,
                    lockId = it.lockId,
                    vesselName = it.vesselName,
                    registrationCode = it.registrationCode,
                    lengthM = it.lengthM,
                    direction = runCatching { TravelDirection.valueOf(it.directionName) }
                        .getOrDefault(TravelDirection.UPSTREAM_BOUND),
                    priority = runCatching { QueuePriority.valueOf(it.priorityName) }
                        .getOrDefault(QueuePriority.STANDARD),
                    queuePosition = it.queuePosition,
                    estimatedWaitMin = it.estimatedWaitMin,
                    status = runCatching { QueueStatus.valueOf(it.statusName) }
                        .getOrDefault(QueueStatus.WAITING),
                    detectionSource = it.detectionSource,
                    registeredAtMs = it.registeredAtMs
                )
            }
        }

    val alarms: Flow<List<AlarmItem>> =
        dao.observeAlarms().map { list ->
            list.map {
                AlarmItem(
                    id = it.id,
                    lockId = it.lockId,
                    code = it.code,
                    severity = runCatching { AlarmSeverity.valueOf(it.severityName) }
                        .getOrDefault(AlarmSeverity.WARNING),
                    source = it.source,
                    description = it.description,
                    timestampMs = it.timestampMs,
                    acknowledged = it.acknowledged,
                    acknowledgedBy = it.acknowledgedBy,
                    acknowledgedAtMs = it.acknowledgedAtMs,
                    resolved = it.resolved,
                    resolutionNotes = it.resolutionNotes
                )
            }
        }

    val workOrders: Flow<List<MaintenanceOrderItem>> =
        dao.observeWorkOrders().map { list ->
            list.map {
                MaintenanceOrderItem(
                    id = it.id,
                    lockId = it.lockId,
                    assetCategory = runCatching { AssetCategory.valueOf(it.assetCategoryName) }
                        .getOrDefault(AssetCategory.GATE_MOTOR),
                    assetTag = it.assetTag,
                    title = it.title,
                    priority = it.priority,
                    status = runCatching { WorkOrderStatus.valueOf(it.statusName) }
                        .getOrDefault(WorkOrderStatus.OPEN),
                    physicalLotoRequired = it.physicalLotoRequired,
                    technicianNotes = it.technicianNotes,
                    scheduledDate = it.scheduledDate,
                    createdAtMs = it.createdAtMs
                )
            }
        }

    val auditEvents: Flow<List<AuditLogItem>> =
        dao.observeAuditEvents().map { list ->
            list.map {
                AuditLogItem(
                    id = it.id,
                    timestampMs = it.timestampMs,
                    actorName = it.actorName,
                    actorRole = it.actorRole,
                    action = it.action,
                    lockId = it.lockId,
                    controllerVerdict = it.controllerVerdict,
                    provenance = it.provenance
                )
            }
        }

    fun observeTelemetry(lockId: String): Flow<List<TelemetryPoint>> =
        dao.observeTelemetryForLock(lockId).map { list ->
            list.reversed().map {
                TelemetryPoint(
                    timestampMs = it.timestampMs,
                    lockId = it.lockId,
                    upstreamM = it.upstreamM,
                    chamberM = it.chamberM,
                    downstreamM = it.downstreamM,
                    flowRateM3s = it.flowRateM3s,
                    isSimulated = it.isSimulated
                )
            }
        }

    suspend fun seedInitialEnterpriseDataIfEmpty(nowMs: Long) {
        if (dao.countQueueEntries() == 0) {
            dao.insertQueueEntry(
                QueueEntryEntity(
                    lockId = "LOCK-AST-04",
                    vesselName = "MV Severn Carrier",
                    registrationCode = "AIS-235091842",
                    lengthM = 21.4,
                    directionName = TravelDirection.UPSTREAM_BOUND.name,
                    priorityName = QueuePriority.COMMERCIAL_FREIGHT.name,
                    queuePosition = 1,
                    estimatedWaitMin = 6,
                    statusName = QueueStatus.WAITING.name,
                    detectionSource = "SIMULATION: Virtual Radar R-DS01 + AIS",
                    registeredAtMs = nowMs - 420_000L
                )
            )
            dao.insertQueueEntry(
                QueueEntryEntity(
                    lockId = "LOCK-AST-04",
                    vesselName = "NB Kingfisher",
                    registrationCode = "CRT-88412",
                    lengthM = 17.5,
                    directionName = TravelDirection.DOWNSTREAM_BOUND.name,
                    priorityName = QueuePriority.STANDARD.name,
                    queuePosition = 2,
                    estimatedWaitMin = 18,
                    statusName = QueueStatus.WAITING.name,
                    detectionSource = "SIMULATION: Virtual Optical Gate Cam-US02",
                    registeredAtMs = nowMs - 210_000L
                )
            )
            dao.insertQueueEntry(
                QueueEntryEntity(
                    lockId = "LOCK-THM-07",
                    vesselName = "Tug Borealis",
                    registrationCode = "AIS-235771204",
                    lengthM = 24.0,
                    directionName = TravelDirection.UPSTREAM_BOUND.name,
                    priorityName = QueuePriority.STANDARD.name,
                    queuePosition = 1,
                    estimatedWaitMin = 9,
                    statusName = QueueStatus.WAITING.name,
                    detectionSource = "SIMULATION: Gateway GW-THM-02",
                    registeredAtMs = nowMs - 300_000L
                )
            )
        }

        if (dao.countAlarms() == 0) {
            dao.insertAlarm(
                AlarmEntity(
                    lockId = "LOCK-GUS-11",
                    code = "ALM-PDL-402",
                    severityName = AlarmSeverity.WARNING.name,
                    source = "SIMULATION: Downstream Paddle Actuator #P-DN02",
                    description = "Elevated hydraulic relief pressure (+14% over nominal curve) during last cycle.",
                    timestampMs = nowMs - 1_800_000L,
                    acknowledged = false
                )
            )
            dao.insertAlarm(
                AlarmEntity(
                    lockId = "LOCK-THM-07",
                    code = "ALM-SEN-209",
                    severityName = AlarmSeverity.ADVISORY.name,
                    source = "SIMULATION: Ultrasonic Approach Array #U-DS01",
                    description = "Transient acoustic scatter observed during tidal surge; redundant LiDAR nominal.",
                    timestampMs = nowMs - 3_600_000L,
                    acknowledged = true,
                    acknowledgedBy = "Duty Operator (M. Vance)",
                    acknowledgedAtMs = nowMs - 3_100_000L
                )
            )
        }

        if (dao.countWorkOrders() == 0) {
            dao.insertWorkOrder(
                WorkOrderEntity(
                    lockId = "LOCK-GUS-11",
                    assetCategoryName = AssetCategory.PADDLE_MECHANISM.name,
                    assetTag = "PDL-GUS11-DN02",
                    title = "Inspect downstream sluice paddle rack & seal clearance",
                    priority = "HIGH",
                    statusName = WorkOrderStatus.IN_PROGRESS.name,
                    physicalLotoRequired = true,
                    technicianNotes = "Physical mechanical isolation & padlock verification required prior to pit entry.",
                    scheduledDate = "2026-11-22",
                    createdAtMs = nowMs - 7_200_000L
                )
            )
            dao.insertWorkOrder(
                WorkOrderEntity(
                    lockId = "LOCK-AST-04",
                    assetCategoryName = AssetCategory.WATER_LEVEL_SENSOR.name,
                    assetTag = "LVL-AST04-CHB",
                    title = "Quarterly hydrostatic transducer zero-datum calibration check",
                    priority = "ROUTINE",
                    statusName = WorkOrderStatus.OPEN.name,
                    physicalLotoRequired = false,
                    technicianNotes = "Verify redundant transducers A & B agree within +/- 5 mm against staff gauge.",
                    scheduledDate = "2026-11-25",
                    createdAtMs = nowMs - 14_400_000L
                )
            )
            dao.insertWorkOrder(
                WorkOrderEntity(
                    lockId = "LOCK-THM-07",
                    assetCategoryName = AssetCategory.GATE_MOTOR.name,
                    assetTag = "MTR-THM07-USL",
                    title = "Check VFD thermal margin & gearbox oil sample",
                    priority = "MEDIUM",
                    statusName = WorkOrderStatus.OPEN.name,
                    physicalLotoRequired = true,
                    technicianNotes = "Confirm local disconnect switch locked before opening motor housing.",
                    scheduledDate = "2026-11-24",
                    createdAtMs = nowMs - 21_600_000L
                )
            )
        }

        if (dao.countAuditEvents() == 0) {
            dao.insertAuditEvent(
                AuditEventEntity(
                    timestampMs = nowMs - 900_000L,
                    actorName = "SYSTEM BOOT",
                    actorRole = "Supervisory Kernel",
                    action = "Initialized LOCK.OS in verified SIMULATION MODE (no physical PLC energisation)",
                    lockId = "ALL",
                    controllerVerdict = "AUTHORISED SIMULATION SANDBOX",
                    provenance = "Deterministic Seed #40219"
                )
            )
            dao.insertAuditEvent(
                AuditEventEntity(
                    timestampMs = nowMs - 600_000L,
                    actorName = "PLC-AST-04",
                    actorRole = "Safety-Rated Local Controller",
                    action = "Completed startup self-test of 7 safety interlocks & dual E-Stop loop",
                    lockId = "LOCK-AST-04",
                    controllerVerdict = "SAFE / INTERLOCKS CLEAR",
                    provenance = "SIMULATION: Virtual Safety PLC"
                )
            )
        }
    }

    suspend fun saveSimulation(item: SavedSimulationItem): Long {
        return dao.insertSavedSimulation(
            SavedSimulationEntity(
                title = item.title,
                lockId = item.lockId,
                seed = item.seed,
                cycleStateLabel = item.cycleStateLabel,
                chamberLevelM = item.chamberLevelM,
                upstreamLevelM = item.upstreamLevelM,
                downstreamLevelM = item.downstreamLevelM,
                totalWaterUsedM3 = item.totalWaterUsedM3,
                activeFaultSummary = item.activeFaultSummary,
                savedAtMs = item.savedAtMs
            )
        )
    }

    suspend fun deleteSavedSimulation(id: Long) = dao.deleteSavedSimulation(id)

    suspend fun registerArrival(item: VesselArrivalItem): Long {
        return dao.insertQueueEntry(
            QueueEntryEntity(
                lockId = item.lockId,
                vesselName = item.vesselName,
                registrationCode = item.registrationCode,
                lengthM = item.lengthM,
                directionName = item.direction.name,
                priorityName = item.priority.name,
                queuePosition = item.queuePosition,
                estimatedWaitMin = item.estimatedWaitMin,
                statusName = item.status.name,
                detectionSource = item.detectionSource,
                registeredAtMs = item.registeredAtMs
            )
        )
    }

    suspend fun updateQueueStatus(id: Long, status: QueueStatus) {
        dao.updateQueueStatus(id, status.name)
    }

    suspend fun promoteQueueEntry(id: Long, priority: QueuePriority, newPosition: Int) {
        dao.updateQueuePriorityAndPos(id, priority.name, newPosition)
    }

    suspend fun recordAlarm(alarm: AlarmItem): Long {
        return dao.insertAlarm(
            AlarmEntity(
                lockId = alarm.lockId,
                code = alarm.code,
                severityName = alarm.severity.name,
                source = alarm.source,
                description = alarm.description,
                timestampMs = alarm.timestampMs,
                acknowledged = alarm.acknowledged,
                acknowledgedBy = alarm.acknowledgedBy,
                acknowledgedAtMs = alarm.acknowledgedAtMs,
                resolved = alarm.resolved,
                resolutionNotes = alarm.resolutionNotes
            )
        )
    }

    suspend fun acknowledgeAlarm(id: Long, actor: String, nowMs: Long) {
        dao.acknowledgeAlarm(id, actor, nowMs)
    }

    suspend fun resolveAlarm(id: Long, notes: String) {
        dao.resolveAlarm(id, notes)
    }

    suspend fun addWorkOrder(order: MaintenanceOrderItem): Long {
        return dao.insertWorkOrder(
            WorkOrderEntity(
                lockId = order.lockId,
                assetCategoryName = order.assetCategory.name,
                assetTag = order.assetTag,
                title = order.title,
                priority = order.priority,
                statusName = order.status.name,
                physicalLotoRequired = order.physicalLotoRequired,
                technicianNotes = order.technicianNotes,
                scheduledDate = order.scheduledDate,
                createdAtMs = order.createdAtMs
            )
        )
    }

    suspend fun updateWorkOrderStatus(id: Long, status: WorkOrderStatus) {
        dao.updateWorkOrderStatus(id, status.name)
    }

    suspend fun appendAudit(event: AuditLogItem): Long {
        return dao.insertAuditEvent(
            AuditEventEntity(
                timestampMs = event.timestampMs,
                actorName = event.actorName,
                actorRole = event.actorRole,
                action = event.action,
                lockId = event.lockId,
                controllerVerdict = event.controllerVerdict,
                provenance = event.provenance
            )
        )
    }

    suspend fun recordTelemetry(point: TelemetryPoint) {
        dao.insertTelemetrySample(
            TelemetrySampleEntity(
                timestampMs = point.timestampMs,
                lockId = point.lockId,
                upstreamM = point.upstreamM,
                chamberM = point.chamberM,
                downstreamM = point.downstreamM,
                flowRateM3s = point.flowRateM3s,
                isSimulated = point.isSimulated
            )
        )
        dao.trimOldTelemetry()
    }
}
