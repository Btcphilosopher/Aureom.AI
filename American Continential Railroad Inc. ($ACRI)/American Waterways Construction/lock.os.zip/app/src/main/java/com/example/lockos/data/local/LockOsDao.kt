package com.example.lockos.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LockOsDao {

    @Query("SELECT * FROM saved_simulations ORDER BY savedAtMs DESC")
    fun observeSavedSimulations(): Flow<List<SavedSimulationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedSimulation(entity: SavedSimulationEntity): Long

    @Query("DELETE FROM saved_simulations WHERE id = :id")
    suspend fun deleteSavedSimulation(id: Long)

    @Query("SELECT * FROM queue_entries ORDER BY queuePosition ASC, registeredAtMs ASC")
    fun observeQueueEntries(): Flow<List<QueueEntryEntity>>

    @Query("SELECT COUNT(*) FROM queue_entries")
    suspend fun countQueueEntries(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQueueEntry(entity: QueueEntryEntity): Long

    @Query("UPDATE queue_entries SET statusName = :statusName WHERE id = :id")
    suspend fun updateQueueStatus(id: Long, statusName: String)

    @Query("UPDATE queue_entries SET priorityName = :priorityName, queuePosition = :newPos WHERE id = :id")
    suspend fun updateQueuePriorityAndPos(id: Long, priorityName: String, newPos: Int)

    @Query("SELECT * FROM alarms ORDER BY timestampMs DESC")
    fun observeAlarms(): Flow<List<AlarmEntity>>

    @Query("SELECT COUNT(*) FROM alarms")
    suspend fun countAlarms(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarm(entity: AlarmEntity): Long

    @Query(
        "UPDATE alarms SET acknowledged = 1, acknowledgedBy = :actor, acknowledgedAtMs = :ackTimeMs WHERE id = :id"
    )
    suspend fun acknowledgeAlarm(id: Long, actor: String, ackTimeMs: Long)

    @Query(
        "UPDATE alarms SET resolved = 1, acknowledged = 1, resolutionNotes = :notes WHERE id = :id"
    )
    suspend fun resolveAlarm(id: Long, notes: String)

    @Query("SELECT * FROM work_orders ORDER BY createdAtMs DESC")
    fun observeWorkOrders(): Flow<List<WorkOrderEntity>>

    @Query("SELECT COUNT(*) FROM work_orders")
    suspend fun countWorkOrders(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkOrder(entity: WorkOrderEntity): Long

    @Query("UPDATE work_orders SET statusName = :statusName WHERE id = :id")
    suspend fun updateWorkOrderStatus(id: Long, statusName: String)

    @Query("SELECT * FROM audit_events ORDER BY timestampMs DESC LIMIT 200")
    fun observeAuditEvents(): Flow<List<AuditEventEntity>>

    @Query("SELECT COUNT(*) FROM audit_events")
    suspend fun countAuditEvents(): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAuditEvent(entity: AuditEventEntity): Long

    @Query("SELECT * FROM telemetry_samples WHERE lockId = :lockId ORDER BY timestampMs DESC LIMIT 60")
    fun observeTelemetryForLock(lockId: String): Flow<List<TelemetrySampleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetrySample(entity: TelemetrySampleEntity)

    @Query("DELETE FROM telemetry_samples WHERE id NOT IN (SELECT id FROM telemetry_samples ORDER BY timestampMs DESC LIMIT 240)")
    suspend fun trimOldTelemetry()
}
