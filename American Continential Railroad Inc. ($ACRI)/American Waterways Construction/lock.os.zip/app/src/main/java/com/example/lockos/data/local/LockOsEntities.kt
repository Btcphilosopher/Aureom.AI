package com.example.lockos.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_simulations")
data class SavedSimulationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val lockId: String,
    val seed: Long,
    val cycleStateLabel: String,
    val chamberLevelM: Double,
    val upstreamLevelM: Double,
    val downstreamLevelM: Double,
    val totalWaterUsedM3: Double,
    val activeFaultSummary: String,
    val savedAtMs: Long
)

@Entity(tableName = "queue_entries")
data class QueueEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lockId: String,
    val vesselName: String,
    val registrationCode: String,
    val lengthM: Double,
    val directionName: String,
    val priorityName: String,
    val queuePosition: Int,
    val estimatedWaitMin: Int,
    val statusName: String,
    val detectionSource: String,
    val registeredAtMs: Long
)

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lockId: String,
    val code: String,
    val severityName: String,
    val source: String,
    val description: String,
    val timestampMs: Long,
    val acknowledged: Boolean,
    val acknowledgedBy: String? = null,
    val acknowledgedAtMs: Long? = null,
    val resolved: Boolean = false,
    val resolutionNotes: String? = null
)

@Entity(tableName = "work_orders")
data class WorkOrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lockId: String,
    val assetCategoryName: String,
    val assetTag: String,
    val title: String,
    val priority: String,
    val statusName: String,
    val physicalLotoRequired: Boolean,
    val technicianNotes: String,
    val scheduledDate: String,
    val createdAtMs: Long
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    val actorName: String,
    val actorRole: String,
    val action: String,
    val lockId: String,
    val controllerVerdict: String,
    val provenance: String
)

@Entity(tableName = "telemetry_samples")
data class TelemetrySampleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    val lockId: String,
    val upstreamM: Double,
    val chamberM: Double,
    val downstreamM: Double,
    val flowRateM3s: Double,
    val isSimulated: Boolean
)
