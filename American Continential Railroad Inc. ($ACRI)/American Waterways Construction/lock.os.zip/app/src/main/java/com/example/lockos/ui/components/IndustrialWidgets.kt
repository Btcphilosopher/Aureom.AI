package com.example.lockos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.lockos.data.seed.LockSiteCatalog
import com.example.lockos.domain.model.ActuatorTelemetry
import com.example.lockos.domain.model.OperatingMode
import com.example.lockos.domain.model.QueuePriority
import com.example.lockos.domain.model.SafetyEvaluationResult
import com.example.lockos.domain.model.SafetyStatus
import com.example.lockos.domain.model.TravelDirection
import com.example.lockos.ui.state.LockOsUiState
import com.example.ui.theme.LocalLockOsColors

@Composable
fun TopSupervisoryBar(
    uiState: LockOsUiState,
    activeAlarmCount: Int,
    onSelectLock: (String) -> Unit,
    onToggleEStop: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    val runtime = uiState.activeRuntime
    val isEStopped = runtime.faults.eStopLatched
    var lockMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, sem.panelBorder)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = stringResource(R.string.cd_safety_shield),
                    tint = when (runtime.state.safetyStatus) {
                        SafetyStatus.SafeAuthorised -> sem.safeGreen
                        SafetyStatus.InterlockHold, SafetyStatus.MaintenanceLockout -> sem.warningAmber
                        else -> sem.alarmRed
                    },
                    modifier = Modifier.size(20.dp)
                )
                Column {
                    Text(
                        text = "LOCK.OS",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${runtime.state.operatingMode.label} · SEED #${runtime.seed}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (runtime.state.operatingMode == OperatingMode.Simulation) sem.warningAmber else sem.safeGreen
                    )
                }
            }

            Button(
                onClick = { onToggleEStop(!isEStopped) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isEStopped) sem.warningAmber else sem.alarmRed,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("estop_button")
            ) {
                Text(
                    text = if (isEStopped) "RESET E-STOP" else "E-STOP",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                Row(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.small)
                        .border(1.dp, sem.panelBorder, MaterialTheme.shapes.small)
                        .clickable { lockMenuExpanded = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("lock_selector_dropdown"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = runtime.config.name,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Icon(
                        imageVector = Icons.Filled.ArrowDropDown,
                        contentDescription = "Select lock",
                        tint = sem.telemetryCyan
                    )
                }

                DropdownMenu(
                    expanded = lockMenuExpanded,
                    onDismissRequest = { lockMenuExpanded = false }
                ) {
                    LockSiteCatalog.sites.forEach { site ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(site.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text("${site.lockId} · ${site.waterway}", style = MaterialTheme.typography.bodySmall)
                                }
                            },
                            onClick = {
                                onSelectLock(site.lockId)
                                lockMenuExpanded = false
                            },
                            modifier = Modifier.testTag("select_lock_${site.lockId}")
                        )
                    }
                }
            }

            StatusPill(
                text = if (activeAlarmCount > 0) "ALM: $activeAlarmCount" else "NO ALARMS",
                fg = if (activeAlarmCount > 0) sem.alarmRed else sem.safeGreen,
                bg = if (activeAlarmCount > 0) sem.alarmRedBg else sem.safeGreenBg
            )
        }
    }
}

@Composable
fun StatusPill(
    text: String,
    fg: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(bg, MaterialTheme.shapes.small)
            .border(1.dp, fg.copy(alpha = 0.55f), MaterialTheme.shapes.small)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ActuatorStatusCard(
    actuator: ActuatorTelemetry,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    val hasFault = actuator.faultCode != null || !actuator.controllerAvailable

    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium)
            .border(1.dp, if (hasFault) sem.alarmRed else sem.panelBorder, MaterialTheme.shapes.medium)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = actuator.name,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "${(actuator.positionPercent * 100).toInt()}%",
                style = MaterialTheme.typography.labelMedium,
                color = sem.telemetryCyan
            )
        }

        LinearProgressIndicator(
            progress = { actuator.positionPercent.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = if (hasFault) sem.alarmRed else sem.telemetryCyan,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("COMMANDED", style = MaterialTheme.typography.labelSmall, color = sem.mutedLabel)
                Text(actuator.commandedState, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("MEASURED", style = MaterialTheme.typography.labelSmall, color = sem.mutedLabel)
                Text(
                    text = actuator.measuredState,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (hasFault) sem.alarmRed else sem.safeGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text(
            text = "Motor ${actuator.motorHealthPercent}% · ${"%.1f".format(actuator.motorCurrentAmps)} A · ${if (actuator.controllerAvailable) "PLC Online" else "PLC Hold"}",
            style = MaterialTheme.typography.labelSmall,
            color = sem.mutedLabel
        )

        if (actuator.faultCode != null) {
            Text(
                text = "FAULT: ${actuator.faultCode}",
                style = MaterialTheme.typography.labelSmall,
                color = sem.alarmRed,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun InterlockChecklistPanel(
    evaluation: SafetyEvaluationResult,
    modifier: Modifier = Modifier
) {
    val sem = LocalLockOsColors.current
    val bannerColor = if (evaluation.movementPermitted) sem.safeGreen else sem.alarmRed
    val bannerBg = if (evaluation.movementPermitted) sem.safeGreenBg else sem.alarmRedBg

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.large)
            .border(1.dp, sem.panelBorder, MaterialTheme.shapes.large)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SAFETY CONTROLLER (${evaluation.controllerId})",
                style = MaterialTheme.typography.titleSmall,
                color = sem.telemetryCyan
            )
            StatusPill(
                text = if (evaluation.movementPermitted) "INTERLOCKS PASS" else "MOVEMENT WITHHELD",
                fg = bannerColor,
                bg = bannerBg
            )
        }

        Text(
            text = evaluation.summary,
            style = MaterialTheme.typography.bodySmall,
            color = bannerColor
        )

        evaluation.checks.forEach { check ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), MaterialTheme.shapes.small)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (check.passed) Icons.Filled.CheckCircle else Icons.Filled.Error,
                    contentDescription = if (check.passed) "Interlock pass" else "Interlock fail",
                    tint = if (check.passed) sem.safeGreen else sem.alarmRed,
                    modifier = Modifier.size(18.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${check.code} · ${check.title}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = check.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = sem.mutedLabel
                    )
                }
            }
        }
    }
}

@Composable
fun RegisterArrivalDialog(
    lockId: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, Double, TravelDirection, QueuePriority) -> Unit
) {
    var name by remember { mutableStateOf("MV Trent Mariner") }
    var reg by remember { mutableStateOf("AIS-235401992") }
    var lengthStr by remember { mutableStateOf("20.5") }
    var direction by remember { mutableStateOf(TravelDirection.UPSTREAM_BOUND) }
    var priority by remember { mutableStateOf(QueuePriority.STANDARD) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Register Vessel Arrival ($lockId)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Vessel Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("arrival_vessel_name_input")
                )
                OutlinedTextField(
                    value = reg,
                    onValueChange = { reg = it },
                    label = { Text("AIS / CRT Registration") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("arrival_reg_input")
                )
                OutlinedTextField(
                    value = lengthStr,
                    onValueChange = { lengthStr = it },
                    label = { Text("Vessel Length (m)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Travel Direction", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TravelDirection.entries.forEach { dir ->
                        FilterChip(
                            selected = direction == dir,
                            onClick = { direction = dir },
                            label = { Text(dir.code) }
                        )
                    }
                }
                Text("Priority Rule", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QueuePriority.entries.forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p.label.substringBefore(" "), style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val len = lengthStr.toDoubleOrNull() ?: 18.0
                    onConfirm(name, reg, len, direction, priority)
                },
                modifier = Modifier.testTag("confirm_register_arrival")
            ) {
                Text("Register")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SaveSimulationDialog(
    defaultTitle: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var title by remember { mutableStateOf(defaultTitle) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Save Simulation Snapshot") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Persists deterministic seed, hydraulic chamber state, water consumption, and active fault profile locally.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Snapshot Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("save_snapshot_title_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title) },
                modifier = Modifier.testTag("confirm_save_snapshot")
            ) {
                Text("Save Snapshot")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun EngineeringReportDialog(
    reportText: String,
    onDismiss: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Engineering Report", style = MaterialTheme.typography.titleMedium)
                Row {
                    IconButton(onClick = onCopy, modifier = Modifier.testTag("copy_report_button")) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = "Copy engineering report")
                    }
                    IconButton(onClick = onShare, modifier = Modifier.testTag("share_report_button")) {
                        Icon(Icons.Filled.Share, contentDescription = "Share engineering report")
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState())
                    .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.small)
                    .padding(10.dp)
            ) {
                Text(
                    text = reportText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, modifier = Modifier.testTag("close_report_button")) {
                Text("Close")
            }
        }
    )
}

@Composable
fun RbacNoticeBanner(roleLabel: String) {
    val sem = LocalLockOsColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(sem.warningAmberBg, MaterialTheme.shapes.small)
            .border(1.dp, sem.warningAmber.copy(alpha = 0.6f), MaterialTheme.shapes.small)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(Icons.Filled.Lock, contentDescription = "Access restricted", tint = sem.warningAmber)
        Text(
            text = "RBAC Policy: $roleLabel has read-only supervisory privileges. Physical/cycle requests disabled.",
            style = MaterialTheme.typography.bodySmall,
            color = sem.warningAmber
        )
    }
}
