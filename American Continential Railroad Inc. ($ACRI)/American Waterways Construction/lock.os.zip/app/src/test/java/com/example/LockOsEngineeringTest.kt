package com.example

import com.example.lockos.data.seed.LockSiteCatalog
import com.example.lockos.domain.controller.LockCycleOrchestrator
import com.example.lockos.domain.controller.SafetyLocalController
import com.example.lockos.domain.hydraulic.HydraulicEngine
import com.example.lockos.domain.model.FaultInjectionFlags
import com.example.lockos.domain.model.GateState
import com.example.lockos.domain.model.OperatingMode
import com.example.lockos.domain.model.PaddleState
import com.example.lockos.domain.model.SafetyStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LockOsEngineeringTest {

    private val site = LockSiteCatalog.sites.first()

    @Test
    fun `hydraulic engine raises chamber level when upstream paddle open`() {
        val (nextLevel, waterUsed) = HydraulicEngine.stepSimulation(
            config = site,
            currentModelLevelM = site.normalDownstreamM,
            upstreamLevelM = site.normalUpstreamM,
            downstreamLevelM = site.normalDownstreamM,
            upstreamPaddleOpenRatio = 1.0,
            downstreamPaddleOpenRatio = 0.0,
            dtSeconds = 5.0,
            cumulativeWaterUsedM3 = 0.0
        )
        assertTrue(nextLevel > site.normalDownstreamM)
        assertTrue(waterUsed > 0.0)
    }

    @Test
    fun `safety controller withholds movement when level sensor unknown`() {
        val now = 1_700_000_000_000L
        val rt = LockCycleOrchestrator.createInitialRuntime(site, 42L, now, true)
            .copy(faults = FaultInjectionFlags(injectLevelSensorDropout = true))
        val badState = rt.state.copy(chamberLevelM = null)

        val eval = SafetyLocalController.evaluate(
            config = site,
            lockState = badState,
            sensors = rt.buildSensors(now),
            actuators = rt.buildActuators(),
            faults = rt.faults,
            commHealthy = true,
            nowMs = now
        )

        assertFalse(eval.movementPermitted)
        assertEquals(SafetyStatus.SensorUncertaintyHold, eval.safetyStatus)
    }

    @Test
    fun `safety controller blocks simultaneous upstream and downstream gates`() {
        val now = 1_700_000_000_000L
        val rt = LockCycleOrchestrator.createInitialRuntime(site, 42L, now, false)
        val unsafeState = rt.state.copy(
            upstreamGateState = GateState.Open,
            downstreamGateState = GateState.Open
        )

        val eval = SafetyLocalController.evaluate(
            config = site,
            lockState = unsafeState,
            sensors = rt.buildSensors(now),
            actuators = rt.buildActuators(),
            faults = rt.faults,
            commHealthy = true,
            nowMs = now
        )

        assertFalse(eval.movementPermitted)
        assertEquals(SafetyStatus.FaultLatched, eval.safetyStatus)
    }

    @Test
    fun `safety controller blocks uncommissioned auto mode`() {
        val now = 1_700_000_000_000L
        val rt = LockCycleOrchestrator.createInitialRuntime(site, 42L, now, false)
        val autoState = rt.state.copy(operatingMode = OperatingMode.CommissionedAuto)

        val eval = SafetyLocalController.evaluate(
            config = site,
            lockState = autoState,
            sensors = rt.buildSensors(now),
            actuators = rt.buildActuators(),
            faults = rt.faults,
            commHealthy = true,
            nowMs = now
        )

        assertFalse(eval.movementPermitted)
        assertEquals(SafetyStatus.InterlockHold, eval.safetyStatus)
    }

    @Test
    fun `safety controller enforces e-stop latch and differential head gate lock`() {
        assertFalse(
            SafetyLocalController.canOpenGate(
                isUpstream = true,
                upstreamLevelM = 5.4,
                chamberLevelM = 2.1,
                downstreamLevelM = 2.1,
                oppositeGateState = GateState.Closed,
                oppositePaddleState = PaddleState.Closed
            )
        )
        assertTrue(
            SafetyLocalController.canOpenGate(
                isUpstream = true,
                upstreamLevelM = 5.4,
                chamberLevelM = 5.38,
                downstreamLevelM = 2.1,
                oppositeGateState = GateState.Closed,
                oppositePaddleState = PaddleState.Closed
            )
        )
    }
}
