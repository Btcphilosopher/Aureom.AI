package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToIndex
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LOCK.OS", appName)
    }

    @Test
    fun `control centre displays digital twin and safety controls`() {
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("LOCK.OS").assertIsDisplayed()
        composeTestRule.onNodeWithTag("estop_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("control_centre_list").performScrollToIndex(2)
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("digital_twin_canvas").assertIsDisplayed()
        composeTestRule.onNodeWithTag("control_centre_list").performScrollToIndex(3)
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("request_cycle_button").assertIsDisplayed()
    }

    @Test
    fun `navigating to network and telemetry tabs works`() {
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("nav_network").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("waterway_network_canvas").assertIsDisplayed()

        composeTestRule.onNodeWithTag("nav_telemetry").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("telemetry_history_chart").assertIsDisplayed()
    }
}
