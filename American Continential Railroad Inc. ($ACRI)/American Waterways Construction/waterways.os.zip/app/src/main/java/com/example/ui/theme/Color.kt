package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// British Waterways Aesthetic Palette
val CanalNavy = Color(0xFF0B253A)
val CanalNavyContainer = Color(0xFFD2E4F5)
val CanalNavyLight = Color(0xFF1A3F5C)

val WaterBlue = Color(0xFF1B6CA8)
val WaterBlueContainer = Color(0xFFD6E9F8)
val WaterBlueBright = Color(0xFF4BA3E3)

val HeritageGreen = Color(0xFF235D3A)
val HeritageGreenContainer = Color(0xFFD5EADF)
val HeritageGreenBright = Color(0xFF56B47D)

val CreamCanvas = Color(0xFFF9F6EE)
val CreamElevated = Color(0xFFFFFFFF)
val StoneGreySurface = Color(0xFFEDE9DE)
val StoneGreyOutline = Color(0xFFC4BFB2)
val StoneGreyText = Color(0xFF4A535C)

val SoftAmber = Color(0xFFC7771A)
val SoftAmberContainer = Color(0xFFFCECD4)
val SoftAmberBright = Color(0xFFF0A84B)

val StoppageRed = Color(0xFFB3261E)
val StoppageRedContainer = Color(0xFFFCE8E6)

// Dark mode variants for dusk/night cruising
val DarkCanalBackground = Color(0xFF071622)
val DarkCanalSurface = Color(0xFF0E2436)
val DarkCanalSurfaceVariant = Color(0xFF17344B)
val DarkCanalText = Color(0xFFF2EFE6)
val DarkStoneText = Color(0xFFB7C2CC)
