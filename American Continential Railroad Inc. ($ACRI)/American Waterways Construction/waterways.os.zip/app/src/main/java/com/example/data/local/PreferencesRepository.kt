package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.waterwaysDataStore by preferencesDataStore(name = "waterways_os_prefs")

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val LARGE_TEXT = booleanPreferencesKey("large_text")
        val USE_IMPERIAL = booleanPreferencesKey("use_imperial")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val DAILY_CRUISING_HOURS = doublePreferencesKey("daily_cruising_hours")
        val NOTIFY_LOCK = booleanPreferencesKey("notify_lock")
        val NOTIFY_JUNCTION = booleanPreferencesKey("notify_junction")
        val NOTIFY_CLOSURE = booleanPreferencesKey("notify_closure")
        val NOTIFY_LOW_BRIDGE = booleanPreferencesKey("notify_low_bridge")
        val NOTIFY_OVERNIGHT = booleanPreferencesKey("notify_overnight")
        val IS_SIGNED_IN = booleanPreferencesKey("is_signed_in")
        val ACCOUNT_EMAIL = stringPreferencesKey("account_email")
    }

    val preferencesFlow: Flow<UserPreferences> = context.waterwaysDataStore.data.map { prefs ->
        UserPreferences(
            darkMode = prefs[Keys.DARK_MODE] ?: false,
            largeText = prefs[Keys.LARGE_TEXT] ?: false,
            useImperialUnits = prefs[Keys.USE_IMPERIAL] ?: true,
            languageCode = prefs[Keys.LANGUAGE_CODE] ?: "en",
            dailyCruisingHours = prefs[Keys.DAILY_CRUISING_HOURS] ?: 5.0,
            notifyApproachingLock = prefs[Keys.NOTIFY_LOCK] ?: true,
            notifyJunction = prefs[Keys.NOTIFY_JUNCTION] ?: true,
            notifyClosure = prefs[Keys.NOTIFY_CLOSURE] ?: true,
            notifyLowBridge = prefs[Keys.NOTIFY_LOW_BRIDGE] ?: true,
            notifyOvernightStop = prefs[Keys.NOTIFY_OVERNIGHT] ?: true,
            isSignedIn = prefs[Keys.IS_SIGNED_IN] ?: false,
            accountEmail = prefs[Keys.ACCOUNT_EMAIL] ?: "Guest Boater"
        )
    }

    suspend fun updatePreferences(transform: (UserPreferences) -> UserPreferences) {
        context.waterwaysDataStore.edit { prefs ->
            val current = UserPreferences(
                darkMode = prefs[Keys.DARK_MODE] ?: false,
                largeText = prefs[Keys.LARGE_TEXT] ?: false,
                useImperialUnits = prefs[Keys.USE_IMPERIAL] ?: true,
                languageCode = prefs[Keys.LANGUAGE_CODE] ?: "en",
                dailyCruisingHours = prefs[Keys.DAILY_CRUISING_HOURS] ?: 5.0,
                notifyApproachingLock = prefs[Keys.NOTIFY_LOCK] ?: true,
                notifyJunction = prefs[Keys.NOTIFY_JUNCTION] ?: true,
                notifyClosure = prefs[Keys.NOTIFY_CLOSURE] ?: true,
                notifyLowBridge = prefs[Keys.NOTIFY_LOW_BRIDGE] ?: true,
                notifyOvernightStop = prefs[Keys.NOTIFY_OVERNIGHT] ?: true,
                isSignedIn = prefs[Keys.IS_SIGNED_IN] ?: false,
                accountEmail = prefs[Keys.ACCOUNT_EMAIL] ?: "Guest Boater"
            )
            val updated = transform(current)
            prefs[Keys.DARK_MODE] = updated.darkMode
            prefs[Keys.LARGE_TEXT] = updated.largeText
            prefs[Keys.USE_IMPERIAL] = updated.useImperialUnits
            prefs[Keys.LANGUAGE_CODE] = updated.languageCode
            prefs[Keys.DAILY_CRUISING_HOURS] = updated.dailyCruisingHours
            prefs[Keys.NOTIFY_LOCK] = updated.notifyApproachingLock
            prefs[Keys.NOTIFY_JUNCTION] = updated.notifyJunction
            prefs[Keys.NOTIFY_CLOSURE] = updated.notifyClosure
            prefs[Keys.NOTIFY_LOW_BRIDGE] = updated.notifyLowBridge
            prefs[Keys.NOTIFY_OVERNIGHT] = updated.notifyOvernightStop
            prefs[Keys.IS_SIGNED_IN] = updated.isSignedIn
            prefs[Keys.ACCOUNT_EMAIL] = updated.accountEmail
        }
    }

    suspend fun resetAccount() {
        context.waterwaysDataStore.edit { it.clear() }
    }
}
