package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Anchor
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.LocalHospital
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.CommunityReport
import com.example.domain.model.CommunityReportType
import com.example.domain.model.FacilityCategory
import com.example.domain.model.Mooring
import com.example.domain.model.MooringType
import com.example.domain.model.NavigationNotice
import com.example.domain.model.NoticeSeverity
import com.example.domain.model.Waterway
import com.example.domain.model.WaterwayFacility
import com.example.domain.model.WaterwayNode
import com.example.ui.WaterwaysUiState
import com.example.ui.components.DataFreshnessFooter
import com.example.ui.components.SafetyCalloutCard
import com.example.ui.components.SeverityBadge
import com.example.ui.components.StatusPillBadge
import com.example.ui.theme.CanalNavy
import com.example.ui.theme.HeritageGreen
import com.example.ui.theme.SoftAmber
import com.example.ui.theme.SoftAmberContainer
import com.example.ui.theme.StoppageRed
import com.example.ui.theme.StoppageRedContainer
import com.example.ui.theme.WaterBlue

@Composable
fun ExploreScreen(
    uiState: WaterwaysUiState,
    waterways: List<Waterway>,
    nodes: List<WaterwayNode>,
    filteredNotices: List<NavigationNotice>,
    moorings: List<Mooring>,
    facilities: List<WaterwayFacility>,
    communityReports: List<CommunityReport>,
    onUpdateNoticeFilters: (waterwayId: String?, severity: NoticeSeverity?, savedRouteOnly: Boolean) -> Unit,
    onAddCommunityReport: (waterwayId: String, targetName: String, type: CommunityReportType, alias: String, comment: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var subTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Notices", "Moorings", "Facilities", "Community", "Safety")

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("explore_screen")
    ) {
        ScrollableTabRow(selectedTabIndex = subTab, edgePadding = 12.dp) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = subTab == index,
                    onClick = { subTab = index },
                    text = { Text(title) },
                    modifier = Modifier.testTag("explore_tab_${title.lowercase()}")
                )
            }
        }

        when (subTab) {
            0 -> NoticesSubTab(uiState, waterways, filteredNotices, onUpdateNoticeFilters)
            1 -> MooringsSubTab(moorings, waterways)
            2 -> FacilitiesSubTab(facilities, waterways)
            3 -> CommunitySubTab(uiState, communityReports, onAddCommunityReport)
            4 -> SafetySubTab(uiState.selectedWaterway, nodes)
        }
    }
}

@Composable
private fun NoticesSubTab(
    uiState: WaterwaysUiState,
    waterways: List<Waterway>,
    notices: List<NavigationNotice>,
    onUpdateFilters: (String?, NoticeSeverity?, Boolean) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Waterway Notices & Stoppages", style = MaterialTheme.typography.titleLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = uiState.noticeFilterSavedRouteOnly,
                        onClick = {
                            onUpdateFilters(
                                uiState.noticeFilterWaterwayId,
                                uiState.noticeFilterSeverity,
                                !uiState.noticeFilterSavedRouteOnly
                            )
                        },
                        label = { Text("Active Route Only") }
                    )
                    NoticeSeverity.entries.forEach { sev ->
                        FilterChip(
                            selected = uiState.noticeFilterSeverity == sev,
                            onClick = {
                                onUpdateFilters(
                                    uiState.noticeFilterWaterwayId,
                                    if (uiState.noticeFilterSeverity == sev) null else sev,
                                    uiState.noticeFilterSavedRouteOnly
                                )
                            },
                            label = { Text(sev.label) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = uiState.noticeFilterWaterwayId == null,
                        onClick = { onUpdateFilters(null, uiState.noticeFilterSeverity, uiState.noticeFilterSavedRouteOnly) },
                        label = { Text("All Waterways") }
                    )
                    waterways.forEach { w ->
                        FilterChip(
                            selected = uiState.noticeFilterWaterwayId == w.id,
                            onClick = { onUpdateFilters(w.id, uiState.noticeFilterSeverity, uiState.noticeFilterSavedRouteOnly) },
                            label = { Text(w.name.substringBefore(" (")) }
                        )
                    }
                }
            }
        }

        if (notices.isEmpty()) {
            item {
                Text(
                    "No notices match the selected filters.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(notices, key = { it.id }) { notice ->
                ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(notice.waterwayName, style = MaterialTheme.typography.labelSmall, color = WaterBlue)
                            SeverityBadge(notice.severity)
                        }
                        Text(notice.title, style = MaterialTheme.typography.titleMedium)
                        Text(notice.summary, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "${notice.type.label} • ${notice.startDateIso} to ${notice.endDateIso} • ${notice.region}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        DataFreshnessFooter(
                            sourceName = notice.meta.sourceName,
                            lastUpdatedIso = notice.meta.lastUpdatedIso,
                            isSimulated = notice.meta.isSimulated
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MooringsSubTab(moorings: List<Mooring>, waterways: List<Waterway>) {
    var selectedType by remember { mutableStateOf<MooringType?>(null) }
    val filtered = remember(moorings, selectedType) {
        if (selectedType == null) moorings else moorings.filter { it.type == selectedType }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Mooring Finder", style = MaterialTheme.typography.titleLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedType == null,
                        onClick = { selectedType = null },
                        label = { Text("All Types") }
                    )
                    MooringType.entries.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = if (selectedType == type) null else type },
                            label = { Text(type.label) }
                        )
                    }
                }
            }
        }

        items(filtered, key = { it.id }) { m ->
            val wName = waterways.firstOrNull { it.id == m.waterwayId }?.name ?: m.waterwayId
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.Anchor, contentDescription = null, tint = HeritageGreen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(m.name, style = MaterialTheme.typography.titleMedium)
                        }
                        StatusPillBadge(m.type.label, MaterialTheme.colorScheme.secondaryContainer, HeritageGreen)
                    }
                    Text(wName, style = MaterialTheme.typography.labelSmall, color = WaterBlue)
                    Text("Max stay: ${m.maxStayHours} hrs • ${m.feesSummary}", style = MaterialTheme.typography.bodyMedium)
                    Text("Availability: ${m.availabilityStatus.label}", style = MaterialTheme.typography.labelSmall, color = SoftAmber)
                    Text("Facilities: ${m.facilities.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                    Text("Restrictions: ${m.restrictions}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Accessibility: ${m.accessibilityNotes}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    DataFreshnessFooter(m.meta.sourceName, m.meta.lastUpdatedIso, m.meta.isSimulated)
                }
            }
        }
    }
}

@Composable
private fun FacilitiesSubTab(facilities: List<WaterwayFacility>, waterways: List<Waterway>) {
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<FacilityCategory?>(null) }

    val filtered = remember(facilities, query, selectedCategory) {
        facilities.filter { f ->
            val matchesCat = selectedCategory == null || f.category == selectedCategory
            val matchesQuery = query.isBlank() ||
                f.name.contains(query, ignoreCase = true) ||
                f.category.label.contains(query, ignoreCase = true) ||
                f.directionsNote.contains(query, ignoreCase = true)
            matchesCat && matchesQuery
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Waterway Facilities Directory", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    label = { Text("Search water, Elsan, pump-out, fuel, pubs...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { selectedCategory = null },
                        label = { Text("All (${facilities.size})") }
                    )
                    FacilityCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                            label = { Text(cat.label) }
                        )
                    }
                }
            }
        }

        items(filtered, key = { it.id }) { fac ->
            val wName = waterways.firstOrNull { it.id == fac.waterwayId }?.name ?: fac.waterwayId
            ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.WaterDrop, contentDescription = null, tint = WaterBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(fac.name, style = MaterialTheme.typography.titleMedium)
                    }
                    Text("${fac.category.label} • $wName", style = MaterialTheme.typography.labelSmall, color = WaterBlue)
                    Text("Directions: ${fac.directionsNote}", style = MaterialTheme.typography.bodyMedium)
                    Text("Access: ${fac.accessInfo}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    DataFreshnessFooter(fac.meta.sourceName, fac.meta.lastUpdatedIso, fac.meta.isSimulated)
                }
            }
        }
    }
}

@Composable
private fun CommunitySubTab(
    uiState: WaterwaysUiState,
    reports: List<CommunityReport>,
    onAddReport: (String, String, CommunityReportType, String, String) -> Unit
) {
    var targetName by remember { mutableStateOf(uiState.selectedWaterway.name) }
    var comment by remember { mutableStateOf("") }
    var alias by remember { mutableStateOf("Cruiser") }
    var type by remember { mutableStateOf(CommunityReportType.NAVIGATION_TIP) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SafetyCalloutCard(
                title = "Community Moderation & Disclaimer",
                body = "User-submitted tips and reviews are NOT official navigation notices. Verify stoppages and lock status with official notices before cruising."
            )
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Forum, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Share Community Note", style = MaterialTheme.typography.titleMedium)
                    }
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CommunityReportType.entries.forEach { t ->
                            FilterChip(
                                selected = type == t,
                                onClick = { type = t },
                                label = { Text(t.label) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = targetName,
                        onValueChange = { targetName = it },
                        label = { Text("Location / Lock / Mooring") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = alias,
                        onValueChange = { alias = it },
                        label = { Text("Boat / Display Alias") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = comment,
                        onValueChange = { comment = it },
                        label = { Text("Tip, facility update, or issue note") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (comment.isNotBlank()) {
                                onAddReport(uiState.selectedWaterway.id, targetName, type, alias, comment)
                                comment = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Post Unverified Community Note")
                    }
                }
            }
        }

        items(reports, key = { it.id }) { report ->
            ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(report.targetName, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPillBadge("UNVERIFIED COMMUNITY", SoftAmberContainer, CanalNavy)
                    }
                    Text(report.comment, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = "${report.type.label} • by ${report.authorAlias} • ${report.timestampIso}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SafetySubTab(
    selectedWaterway: Waterway,
    nodes: List<WaterwayNode>
) {
    val referenceNode = nodes.firstOrNull { it.waterwayId == selectedWaterway.id }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SafetyCalloutCard(
                title = "Not an Emergency Response Service",
                body = "WATERWAYS.OS provides reference coordinates and guidance only. In a life-threatening emergency on any UK waterway, dial 999 or 112 immediately.",
                isWarning = true
            )
        }
        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.LocalHospital, contentDescription = null, tint = StoppageRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Current Corridor Reference", style = MaterialTheme.typography.titleMedium)
                    }
                    Text("Waterway: ${selectedWaterway.name}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    if (referenceNode != null) {
                        Text(
                            text = "Reference Coordinates (Selected Corridor): %.5f, %.5f".format(referenceNode.lat, referenceNode.lon),
                            style = MaterialTheme.typography.labelSmall,
                            color = WaterBlue
                        )
                    }
                    Text("Nearest Recognised Access Point: ${selectedWaterway.nearestAccessPoint}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("UK Waterway Safety & Incident Contacts", style = MaterialTheme.typography.titleMedium)
                    Text("• Life-threatening / medical / fire emergency: Call 999 or 112", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Text("• Canal & River Trust Emergency (England & Wales): 0800 47 999 47 (for lock failures, breaches, fallen trees)", style = MaterialTheme.typography.bodySmall)
                    Text("• Tunnel Safety: Switch on headlamp, sound horn before entry, verify ventilation and life jackets in deep locks.", style = MaterialTheme.typography.bodySmall)
                    Text("• Lock Cill Warning: Keep stern clear of top gate cill markers when descending.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
