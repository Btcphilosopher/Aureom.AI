package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf

data class WaterwaysStrings(
    val navHome: String,
    val navMap: String,
    val navJourney: String,
    val navLocks: String,
    val navExplore: String,
    val navProfile: String,
    val tagline: String,
    val demoBanner: String,
    val planJourney: String,
    val viewMap: String,
    val findNextLock: String,
    val checkIn: String,
    val currentWaterway: String,
    val nextLock: String,
    val activeJourney: String,
    val stoppagesAndNotices: String,
    val nearbyMoorings: String,
    val nearbyFacilities: String,
    val favourites: String,
    val weatherUnavailable: String,
    val safetySteeringWarning: String,
    val lockOsDisclaimer: String
)

val EnglishStrings = WaterwaysStrings(
    navHome = "Home",
    navMap = "Map",
    navJourney = "Journey",
    navLocks = "Locks",
    navExplore = "Explore",
    navProfile = "Profile",
    tagline = "YOUR WATERWAY. YOUR JOURNEY. YOUR LOCKS.",
    demoBanner = "Independent Concept • Demo Mode (Simulated Operational Data)",
    planJourney = "PLAN JOURNEY",
    viewMap = "VIEW MAP",
    findNextLock = "FIND NEXT LOCK",
    checkIn = "CHECK IN",
    currentWaterway = "Current Waterway",
    nextLock = "Next Lock",
    activeJourney = "Current Journey",
    stoppagesAndNotices = "Stoppages & Notices",
    nearbyMoorings = "Nearby Moorings",
    nearbyFacilities = "Nearby Facilities",
    favourites = "Favourite Destinations",
    weatherUnavailable = "No live weather service connected (offline-safe mode).",
    safetySteeringWarning = "Helmsman Safety: Glanceable view only. Do not operate while actively steering.",
    lockOsDisclaimer = "Check-in never triggers physical gates or paddles. Remote service requests are evaluated by the independent local safety controller."
)

val WelshStrings = WaterwaysStrings(
    navHome = "Cartref",
    navMap = "Map",
    navJourney = "Taith",
    navLocks = "Cloeon",
    navExplore = "Archwilio",
    navProfile = "Proffil",
    tagline = "EICH DYFRFFORDD. EICH TAITH. EICH CLOEON.",
    demoBanner = "Cysyniad Annibynnol • Modd Demo (Data Gweithredol Efelychiedig)",
    planJourney = "CYNLLUNIO TAITH",
    viewMap = "GWELD MAP",
    findNextLock = "CLOE NESAF",
    checkIn = "COFRESTRU",
    currentWaterway = "Dyfrffordd Gyfredol",
    nextLock = "Cloe Nesaf",
    activeJourney = "Taith Gyfredol",
    stoppagesAndNotices = "Hysbysiadau ac Ataliadau",
    nearbyMoorings = "Angorfeydd Gerllaw",
    nearbyFacilities = "Cyfleusterau Gerllaw",
    favourites = "Cyrchfannau Ffefryn",
    weatherUnavailable = "Dim gwasanaeth tywydd byw wedi'i gysylltu.",
    safetySteeringWarning = "Diogelwch Llywio: Peidiwch â defnyddio'r ffôn wrth lywio'n weithredol.",
    lockOsDisclaimer = "Nid yw cofrestru byth yn symud gatiau na phadlau yn awtomatig. Mae ceisiadau yn cael eu gwerthuso gan y rheolydd diogelwch lleol."
)

val LocalWaterwaysStrings = compositionLocalOf { EnglishStrings }

@Composable
@ReadOnlyComposable
fun wStrings(): WaterwaysStrings = LocalWaterwaysStrings.current
