package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Accessible
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ExitToApp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SettingsRemote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.SavedPlaceEntity
import com.example.domain.model.CheckInMethod
import com.example.domain.model.LockCheckIn
import com.example.domain.model.LockOperationalStatus
import com.example.domain.model.LockQueueState
import com.example.domain.model.LockServiceState
import com.example.domain.model.LockServiceStatus
import com.example.domain.model.NodeType
import com.example.domain.model.TravelDirection
import com.example.domain.model.UnitFormatter
import com.example.domain.model.UserPreferences
import com.example.domain.model.VesselProfile
import com.example.domain.model.Waterway
import com.example.domain.model.WaterwayNode
import com.example.ui.WaterwaysUiState
import com.example.ui.components.DataFreshnessFooter
import com.example.ui.components.LockChamberDiagram
import com.example.ui.components.OperationalStatusBadge
import com.example.ui.components.SafetyCalloutCard
import com.example.ui.components.StatusPillBadge
import com.example.ui.theme.CanalNavy
import com.example.ui.theme.HeritageGreen
import com.example.ui.theme.HeritageGreenContainer
import com.example.ui.theme.SoftAmber
import com.example.ui.theme.SoftAmberContainer
import com.example.ui.theme.WaterBlue
import com.example.ui.theme.WaterBlueContainer
import com.example.ui.theme.wStrings

@Composable
fun LocksScreen(
    uiState: WaterwaysUiState,
    preferences: UserPreferences,
    vessel: VesselProfile,
    waterways: List<Waterway>,
    allNodes: List<WaterwayNode>,
    savedPlaces: List<SavedPlaceEntity>,
    activeCheckIn: LockCheckIn?,
    activeQueue: LockQueueState?,
    activeServiceStatus: LockServiceStatus?,
    onSelectLock: (String) -> Unit,
    onRegisterCheckIn: (WaterwayNode, TravelDirection, CheckInMethod) -> Unit,
    onSubmitLockOsRequest: (WaterwayNode) -> Unit,
    onAdvanceSimulatedLockState: () -> Unit,
    onLeaveQueue: () -> Unit,
    onToggleSavePlace: (WaterwayNode, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = wStrings()
    val locks = remember(allNodes) { allNodes.filter { it.type == NodeType.LOCK } }
    var filterLockOsOnly by remember { mutableStateOf(false) }

    val displayedLocks = remember(locks, filterLockOsOnly) {
        if (filterLockOsOnly) locks.filter { it.isLockOsEnabled } else locks
    }

    val selectedLock = locks.firstOrNull { it.id == uiState.selectedLockId } ?: locks.first()
    val waterwayName = waterways.firstOrNull { it.id == selectedLock.waterwayId }?.name ?: "Waterway"
    val imperial = preferences.useImperialUnits
    val isSaved = savedPlaces.any { it.id == selectedLock.id }

    var direction by remember { mutableStateOf(TravelDirection.ASCENDING) }
    var method by remember { mutableStateOf(CheckInMethod.MANUAL) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("locks_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Lock Directory Picker
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Smart Lock Directory", style = MaterialTheme.typography.titleLarge)
                    FilterChip(
                        selected = filterLockOsOnly,
                        onClick = { filterLockOsOnly = !filterLockOsOnly },
                        label = { Text("LOCK.OS Only") }
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    displayedLocks.forEach { lock ->
                        FilterChip(
                            selected = lock.id == selectedLock.id,
                            onClick = { onSelectLock(lock.id) },
                            label = { Text(lock.name) },
                            modifier = Modifier.testTag("lock_chip_${lock.id}")
                        )
                    }
                }
            }
        }

        // 2. Selected Lock Detail Card
        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(waterwayName, style = MaterialTheme.typography.labelSmall, color = WaterBlue)
                            Text(selectedLock.name, style = MaterialTheme.typography.headlineSmall)
                        }
                        IconButton(onClick = { onToggleSavePlace(selectedLock, waterwayName) }) {
                            Icon(
                                imageVector = if (isSaved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                contentDescription = "Save lock favourite"
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        OperationalStatusBadge(selectedLock.operationalStatus)
                        if (selectedLock.isLockOsEnabled) {
                            StatusPillBadge("LOCK.OS", SoftAmberContainer, CanalNavy)
                        }
                        if (selectedLock.automationAvailable) {
                            StatusPillBadge("Automated Demo", WaterBlueContainer, CanalNavy)
                        }
                        if (selectedLock.queueAvailable) {
                            StatusPillBadge("Queue Supported", HeritageGreenContainer, HeritageGreen)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CHAMBER", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val l = selectedLock.chamberLengthFt?.let { UnitFormatter.formatDimension(it, imperial) } ?: "--"
                            val w = selectedLock.chamberWidthFt?.let { UnitFormatter.formatDimension(it, imperial) } ?: "--"
                            Text("$l × $w", style = MaterialTheme.typography.titleMedium)
                        }
                        Column {
                            Text("RISE / FALL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val rf = selectedLock.riseFallFt?.let { UnitFormatter.formatDimension(it, imperial) } ?: "--"
                            Text(rf, style = MaterialTheme.typography.titleMedium)
                        }
                        Column {
                            Text("LOCK NO.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(selectedLock.lockNumber ?: "--", style = MaterialTheme.typography.titleMedium)
                        }
                    }

                    Text(selectedLock.restrictionsNote, style = MaterialTheme.typography.bodyMedium)

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Accessible, contentDescription = null, tint = HeritageGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(selectedLock.accessibilityNotes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    LockChamberDiagram(lock = selectedLock)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_lock_diagram_bg),
                            contentDescription = "Canal basin architectural schematic",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    DataFreshnessFooter(
                        sourceName = selectedLock.meta.sourceName,
                        lastUpdatedIso = selectedLock.meta.lastUpdatedIso,
                        isSimulated = selectedLock.meta.isSimulated
                    )
                }
            }
        }

        // 3. Smart Lock Arrival Check-In
        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Lock Arrival Check-In", style = MaterialTheme.typography.titleLarge)
                    }

                    SafetyCalloutCard(
                        title = "Actuator Safety Boundary",
                        body = strings.lockOsDisclaimer
                    )

                    Text("Vessel: ${vessel.name} (${if (vessel.isPrivateByDefault) "Private ID protected" else "Visible"})", style = MaterialTheme.typography.bodyMedium)

                    Text("Direction of Travel", style = MaterialTheme.typography.titleSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TravelDirection.entries.forEach { dir ->
                            FilterChip(
                                selected = direction == dir,
                                onClick = { direction = dir },
                                label = { Text(if (dir == TravelDirection.ASCENDING) "Ascending" else "Descending") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Text("Check-In Method", style = MaterialTheme.typography.titleSmall)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CheckInMethod.entries.forEach { m ->
                            FilterChip(
                                selected = method == m,
                                onClick = { method = m },
                                label = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (m == CheckInMethod.QR_CODE) {
                                            Icon(Icons.Rounded.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        Text(m.label)
                                    }
                                }
                            )
                        }
                    }

                    Button(
                        onClick = { onRegisterCheckIn(selectedLock, direction, method) },
                        enabled = selectedLock.checkInSupported && selectedLock.operationalStatus != LockOperationalStatus.CLOSED,
                        colors = ButtonDefaults.buttonColors(containerColor = HeritageGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("lock_check_in_button")
                    ) {
                        Icon(Icons.Rounded.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (selectedLock.operationalStatus == LockOperationalStatus.CLOSED) {
                                "LOCK CLOSED — CHECK-IN DISABLED"
                            } else if (!selectedLock.checkInSupported) {
                                "CHECK-IN NOT SUPPORTED HERE"
                            } else {
                                "CHECK IN AT ${selectedLock.name.uppercase()}"
                            }
                        )
                    }
                }
            }
        }

        // 4. Live Simulated Queue & LOCK.OS Service Status
        if (activeCheckIn != null && activeQueue != null) {
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("live_queue_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Live Lock Queue", style = MaterialTheme.typography.titleLarge)
                            StatusPillBadge("SIMULATED QUEUE", SoftAmberContainer, CanalNavy)
                        }

                        Text("Registered at ${activeQueue.lockName} (${activeCheckIn.method.label})", style = MaterialTheme.typography.bodyMedium)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("POSITION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("#${activeQueue.queuePosition}", style = MaterialTheme.typography.headlineMedium, color = WaterBlue)
                            }
                            Column {
                                Text("VESSELS AHEAD", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${activeQueue.vesselsAhead}", style = MaterialTheme.typography.headlineMedium)
                            }
                            Column {
                                Text("EST. WAIT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${activeQueue.estimatedWaitMinutes}m", style = MaterialTheme.typography.headlineMedium)
                            }
                        }

                        Text(
                            text = "${activeQueue.queueStatus} • ${activeQueue.direction.label}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )

                        HorizontalDivider()

                        // LOCK.OS Service Request Section
                        if (activeServiceStatus != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.SettingsRemote, contentDescription = null, tint = CanalNavy)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("LOCK.OS Service Status", style = MaterialTheme.typography.titleMedium)
                                }
                                StatusPillBadge(
                                    text = activeServiceStatus.state.title,
                                    containerColor = if (activeServiceStatus.state == LockServiceState.SERVICE_COMPLETE) HeritageGreenContainer else WaterBlueContainer,
                                    contentColor = CanalNavy
                                )
                            }

                            Text(activeServiceStatus.statusDetail, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "Controller: ${activeServiceStatus.localControllerNotice}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (activeServiceStatus.state == LockServiceState.IDLE && selectedLock.automationAvailable) {
                                Button(
                                    onClick = { onSubmitLockOsRequest(selectedLock) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("submit_lock_os_request_button")
                                ) {
                                    Text("Request Authorised Lock Service (LOCK.OS)")
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FilledTonalButton(
                                onClick = onAdvanceSimulatedLockState,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("simulate_advance_lock_button")
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Simulate Update")
                            }
                            OutlinedButton(
                                onClick = onLeaveQueue,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("leave_queue_button")
                            ) {
                                Icon(Icons.Rounded.ExitToApp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Leave Queue")
                            }
                        }
                    }
                }
            }
        }
    }
}
