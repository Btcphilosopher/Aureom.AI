package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.BookmarkAdded
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DirectionsBoat
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.ActiveJourney
import com.example.domain.model.Mooring
import com.example.domain.model.PlannedRoute
import com.example.domain.model.RouteCalculationResult
import com.example.domain.model.UnitFormatter
import com.example.domain.model.UserPreferences
import com.example.domain.model.VesselProfile
import com.example.domain.model.WaterwayNode
import com.example.ui.WaterwaysUiState
import com.example.ui.components.SafetyCalloutCard
import com.example.ui.theme.HeritageGreen
import com.example.ui.theme.SoftAmber
import com.example.ui.theme.StoppageRed
import com.example.ui.theme.StoppageRedContainer
import com.example.ui.theme.WaterBlue
import com.example.ui.theme.wStrings

@Composable
fun JourneyScreen(
    uiState: WaterwaysUiState,
    preferences: UserPreferences,
    vessel: VesselProfile,
    allNodes: List<WaterwayNode>,
    moorings: List<Mooring>,
    savedRoutes: List<PlannedRoute>,
    activeJourney: ActiveJourney?,
    onSetRouteEndpoints: (startId: String?, endId: String?, viaId: String?) -> Unit,
    onSetAvoidances: (Boolean, Boolean, Boolean) -> Unit,
    onSaveRouteOffline: (PlannedRoute) -> Unit,
    onDeleteSavedRoute: (String) -> Unit,
    onStartJourney: (PlannedRoute) -> Unit,
    onAdvanceWaypoint: () -> Unit,
    onStopJourney: () -> Unit,
    onOpenLockForCheckIn: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = wStrings()
    var selectedMode by remember(activeJourney != null) {
        mutableIntStateOf(if (activeJourney != null) 1 else 0)
    }
    val imperial = preferences.useImperialUnits

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("journey_screen")
    ) {
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            SegmentedButton(
                selected = selectedMode == 0,
                onClick = { selectedMode = 0 },
                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                modifier = Modifier.testTag("tab_route_planner")
            ) {
                Text("Route Planner")
            }
            SegmentedButton(
                selected = selectedMode == 1,
                onClick = { selectedMode = 1 },
                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                modifier = Modifier.testTag("tab_active_dashboard")
            ) {
                Text("Live Dashboard")
            }
        }

        if (selectedMode == 0) {
            RoutePlannerTab(
                uiState = uiState,
                preferences = preferences,
                vessel = vessel,
                allNodes = allNodes,
                savedRoutes = savedRoutes,
                imperial = imperial,
                onSetRouteEndpoints = onSetRouteEndpoints,
                onSetAvoidances = onSetAvoidances,
                onSaveRouteOffline = onSaveRouteOffline,
                onDeleteSavedRoute = onDeleteSavedRoute,
                onStartJourney = {
                    onStartJourney(it)
                    selectedMode = 1
                }
            )
        } else {
            ActiveJourneyDashboardTab(
                activeJourney = activeJourney,
                moorings = moorings,
                imperial = imperial,
                safetyWarning = strings.safetySteeringWarning,
                onAdvanceWaypoint = onAdvanceWaypoint,
                onStopJourney = onStopJourney,
                onOpenLockForCheckIn = onOpenLockForCheckIn,
                onSwitchToPlanner = { selectedMode = 0 }
            )
        }
    }
}

@Composable
private fun RoutePlannerTab(
    uiState: WaterwaysUiState,
    preferences: UserPreferences,
    vessel: VesselProfile,
    allNodes: List<WaterwayNode>,
    savedRoutes: List<PlannedRoute>,
    imperial: Boolean,
    onSetRouteEndpoints: (String?, String?, String?) -> Unit,
    onSetAvoidances: (Boolean, Boolean, Boolean) -> Unit,
    onSaveRouteOffline: (PlannedRoute) -> Unit,
    onDeleteSavedRoute: (String) -> Unit,
    onStartJourney: (PlannedRoute) -> Unit
) {
    val startNode = allNodes.firstOrNull { it.id == uiState.routeStartId } ?: allNodes.first()
    val endNode = allNodes.firstOrNull { it.id == uiState.routeEndId } ?: allNodes.last()
    val viaNode = allNodes.firstOrNull { it.id == uiState.routeViaId }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Waterway-Aware Route Planner", style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = "Vessel: ${vessel.name} (${UnitFormatter.formatDimension(vessel.lengthFt, imperial)} × ${UnitFormatter.formatDimension(vessel.beamFt, imperial)} • Draft ${UnitFormatter.formatDimension(vessel.draughtFt, imperial)})",
                        style = MaterialTheme.typography.labelSmall,
                        color = WaterBlue
                    )

                    NodeSelectorDropdown(
                        label = "Start Location",
                        selectedNode = startNode,
                        nodes = allNodes,
                        onSelect = { onSetRouteEndpoints(it.id, null, uiState.routeViaId) },
                        testTag = "route_start_selector"
                    )

                    NodeSelectorDropdown(
                        label = "Via Point (Optional)",
                        selectedNode = viaNode,
                        nodes = allNodes,
                        allowNone = true,
                        onSelect = { onSetRouteEndpoints(null, null, it.id) },
                        onClear = { onSetRouteEndpoints(null, null, null) },
                        testTag = "route_via_selector"
                    )

                    NodeSelectorDropdown(
                        label = "Destination",
                        selectedNode = endNode,
                        nodes = allNodes,
                        onSelect = { onSetRouteEndpoints(null, it.id, uiState.routeViaId) },
                        testTag = "route_dest_selector"
                    )

                    OutlinedButton(
                        onClick = { onSetRouteEndpoints(endNode.id, startNode.id, uiState.routeViaId) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.SwapVert, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reverse Start & Destination")
                    }

                    HorizontalDivider()

                    Text(
                        text = "Avoidances & Daily Pace (${preferences.dailyCruisingHours.toInt()}h/day)",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = uiState.avoidTunnels,
                            onCheckedChange = { onSetAvoidances(it, uiState.avoidLowBridges, uiState.avoidClosedSegments) }
                        )
                        Text("Avoid tunnels", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = uiState.avoidLowBridges,
                            onCheckedChange = { onSetAvoidances(uiState.avoidTunnels, it, uiState.avoidClosedSegments) }
                        )
                        Text("Avoid tight low bridges", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = uiState.avoidClosedSegments,
                            onCheckedChange = { onSetAvoidances(uiState.avoidTunnels, uiState.avoidLowBridges, it) }
                        )
                        Text("Avoid closed stoppages (recommended)", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        // Calculated Route Result
        when (val result = uiState.routeResult) {
            is RouteCalculationResult.Incompatible -> {
                item {
                    Surface(
                        color = StoppageRedContainer,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("route_incompatible_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Warning, contentDescription = null, tint = StoppageRed)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Route Incompatible / Blocked", style = MaterialTheme.typography.titleMedium, color = StoppageRed)
                            }
                            Text(result.reason, style = MaterialTheme.typography.bodyMedium, color = StoppageRed)
                            result.blockingRestrictions.take(4).forEach { msg ->
                                Text("• $msg", style = MaterialTheme.typography.bodySmall, color = StoppageRed)
                            }
                        }
                    }
                }
            }

            is RouteCalculationResult.Success -> {
                val route = result.route
                item {
                    ElevatedCard(
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("route_result_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Calculated Canal Route", style = MaterialTheme.typography.titleLarge)
                                if (route.isSavedOffline) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.DownloadDone, contentDescription = null, tint = HeritageGreen, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Offline", style = MaterialTheme.typography.labelSmall, color = HeritageGreen)
                                    }
                                }
                            }

                            Text(route.name, style = MaterialTheme.typography.titleMedium, color = WaterBlue)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                MetricStat("Distance", UnitFormatter.formatDistance(route.totalDistanceKm, imperial))
                                MetricStat("Locks", "${route.lockCount}")
                                MetricStat("Cruise", UnitFormatter.formatDuration(route.cruisingMinutes))
                                MetricStat("Lock Time", UnitFormatter.formatDuration(route.lockTimeMinutes))
                            }

                            Text(
                                text = "Estimated Total: ${UnitFormatter.formatDuration(route.totalMinutes)} • Overnight Stops: ${route.overnightStops}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )

                            if (route.compatibilityWarnings.isNotEmpty() || route.uncertainRestrictions.isNotEmpty()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("ESTIMATE & RESTRICTION NOTES", style = MaterialTheme.typography.labelSmall, color = SoftAmber)
                                        (route.compatibilityWarnings + route.uncertainRestrictions).forEach { w ->
                                            Text("• $w", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                FilledTonalButton(
                                    onClick = { onSaveRouteOffline(route) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("save_route_offline_button")
                                ) {
                                    Icon(Icons.Rounded.BookmarkAdded, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Save Offline")
                                }
                                Button(
                                    onClick = { onStartJourney(route) },
                                    colors = ButtonDefaults.buttonColors(containerColor = HeritageGreen),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("start_journey_button")
                                ) {
                                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Start Journey")
                                }
                            }

                            HorizontalDivider()
                            Text("Multi-Day Cruising Itinerary", style = MaterialTheme.typography.titleMedium)
                            route.dailyItinerary.forEach { day ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            text = "DAY ${day.dayNumber}: ${day.startLabel} → ${day.endLabel}",
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = "Cruise: %.1f hrs • Locks: %d • Distance: %s".format(
                                                day.cruisingHours,
                                                day.lockCount,
                                                UnitFormatter.formatDistance(day.distanceKm, imperial)
                                            ),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(
                                            text = "Overnight: ${day.overnightSuggestion}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            null -> Unit
        }

        // Saved Offline Routes Section
        item {
            Text("Saved Offline Routes", style = MaterialTheme.typography.titleMedium)
        }
        if (savedRoutes.isEmpty()) {
            item {
                Text(
                    text = "No routes saved offline yet. Calculate a route above and tap Save Offline.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(savedRoutes, key = { it.id }) { saved ->
                ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(saved.name, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "${UnitFormatter.formatDistance(saved.totalDistanceKm, imperial)} • ${saved.lockCount} locks • ${UnitFormatter.formatDuration(saved.totalMinutes)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { onStartJourney(saved) }) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = "Start saved route", tint = HeritageGreen)
                        }
                        IconButton(onClick = { onDeleteSavedRoute(saved.id) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete saved route")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveJourneyDashboardTab(
    activeJourney: ActiveJourney?,
    moorings: List<Mooring>,
    imperial: Boolean,
    safetyWarning: String,
    onAdvanceWaypoint: () -> Unit,
    onStopJourney: () -> Unit,
    onOpenLockForCheckIn: (String) -> Unit,
    onSwitchToPlanner: () -> Unit
) {
    if (activeJourney == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Rounded.Route, contentDescription = null, modifier = Modifier.size(56.dp), tint = WaterBlue)
            Spacer(modifier = Modifier.height(12.dp))
            Text("No Active Journey", style = MaterialTheme.typography.headlineSmall)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Plan or select an offline route in the Route Planner to launch the glanceable helmsman dashboard.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onSwitchToPlanner) {
                Text("Go to Route Planner")
            }
        }
        return
    }

    val nearbyMoorings = moorings.filter { activeJourney.route.waterwayIds.contains(it.waterwayId) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.testTag("active_journey_dashboard")
    ) {
        item {
            SafetyCalloutCard(
                title = "Helmsman Notice",
                body = safetyWarning,
                isWarning = true
            )
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.DirectionsBoat, contentDescription = null, tint = WaterBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(activeJourney.route.name, style = MaterialTheme.typography.titleMedium)
                        }
                    }

                    LinearProgressIndicator(
                        progress = { activeJourney.progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricStat("Remaining", UnitFormatter.formatDistance(activeJourney.remainingDistanceKm, imperial))
                        MetricStat("Est. Time Left", UnitFormatter.formatDuration(activeJourney.remainingMinutes))
                        MetricStat("Progress", "${(activeJourney.progressFraction * 100).toInt()}%")
                    }

                    Text(
                        text = "Current Waypoint: ${activeJourney.currentNode.name}",
                        style = MaterialTheme.typography.titleSmall,
                        color = HeritageGreen
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onAdvanceWaypoint,
                            enabled = activeJourney.remainingNodes.isNotEmpty(),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("advance_waypoint_button")
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (activeJourney.remainingNodes.isEmpty()) "Arrived" else "Continue Journey")
                        }
                        OutlinedButton(
                            onClick = onStopJourney,
                            modifier = Modifier.height(50.dp)
                        ) {
                            Icon(Icons.Rounded.Stop, contentDescription = "End journey")
                        }
                    }
                }
            }
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Upcoming Features Along Route", style = MaterialTheme.typography.titleMedium)

                    val nextLock = activeJourney.nextLock
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("NEXT LOCK", style = MaterialTheme.typography.labelSmall, color = WaterBlue)
                            Text(nextLock?.name ?: "None remaining", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        }
                        if (nextLock != null) {
                            FilledTonalButton(
                                onClick = { onOpenLockForCheckIn(nextLock.id) },
                                modifier = Modifier.testTag("journey_check_in_next_lock")
                            ) {
                                Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Check In")
                            }
                        }
                    }

                    HorizontalDivider()

                    Text("NEXT BRIDGE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(activeJourney.nextBridge?.name ?: "No bridges ahead in segment", style = MaterialTheme.typography.bodyMedium)

                    Text("NEXT JUNCTION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(activeJourney.nextJunction?.name ?: "No junctions ahead in segment", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        if (activeJourney.route.compatibilityWarnings.isNotEmpty()) {
            item {
                SafetyCalloutCard(
                    title = "Upcoming Route Restrictions",
                    body = activeJourney.route.compatibilityWarnings.joinToString("\n"),
                    isWarning = true
                )
            }
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Nearby Moorings Along Route", style = MaterialTheme.typography.titleMedium)
                    nearbyMoorings.forEach { m ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = HeritageGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("${m.name} (${m.maxStayHours}h max)", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NodeSelectorDropdown(
    label: String,
    selectedNode: WaterwayNode?,
    nodes: List<WaterwayNode>,
    allowNone: Boolean = false,
    onSelect: (WaterwayNode) -> Unit,
    onClear: () -> Unit = {},
    testTag: String
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = true }
                .testTag(testTag),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = selectedNode?.name ?: "None selected",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            if (allowNone) {
                DropdownMenuItem(
                    text = { Text("No via point") },
                    onClick = {
                        expanded = false
                        onClear()
                    }
                )
            }
            nodes.forEach { node ->
                DropdownMenuItem(
                    text = { Text("${node.name} (${node.type.label})") },
                    onClick = {
                        expanded = false
                        onSelect(node)
                    }
                )
            }
        }
    }
}

@Composable
private fun MetricStat(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}
