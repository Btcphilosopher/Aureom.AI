package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Anchor
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.DirectionsBoat
import androidx.compose.material.icons.rounded.LocationSearching
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.SavedPlaceEntity
import com.example.domain.model.ActiveJourney
import com.example.domain.model.Mooring
import com.example.domain.model.NavigationNotice
import com.example.domain.model.NodeType
import com.example.domain.model.UnitFormatter
import com.example.domain.model.UserPreferences
import com.example.domain.model.Waterway
import com.example.domain.model.WaterwayFacility
import com.example.domain.model.WaterwayNode
import com.example.ui.WaterwaysUiState
import com.example.ui.components.DataFreshnessFooter
import com.example.ui.components.DemoAndOfflineHeaderBanner
import com.example.ui.components.OperationalStatusBadge
import com.example.ui.components.SeverityBadge
import com.example.ui.theme.CanalNavy
import com.example.ui.theme.HeritageGreen
import com.example.ui.theme.SoftAmber
import com.example.ui.theme.WaterBlue
import com.example.ui.theme.wStrings

@Composable
fun HomeScreen(
    uiState: WaterwaysUiState,
    preferences: UserPreferences,
    waterways: List<Waterway>,
    nodes: List<WaterwayNode>,
    moorings: List<Mooring>,
    facilities: List<WaterwayFacility>,
    notices: List<NavigationNotice>,
    savedPlaces: List<SavedPlaceEntity>,
    activeJourney: ActiveJourney?,
    onSelectWaterway: (Waterway) -> Unit,
    onPlanJourneyClick: () -> Unit,
    onViewMapClick: () -> Unit,
    onFindNextLockClick: (String) -> Unit,
    onCheckInClick: (String) -> Unit,
    onOpenNoticesClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = wStrings()
    val waterway = uiState.selectedWaterway
    val waterwayNodes = nodes.filter { it.waterwayId == waterway.id }
    val nextLock = activeJourney?.nextLock ?: waterwayNodes.firstOrNull { it.type == NodeType.LOCK }
    val nearbyMoorings = moorings.filter { it.waterwayId == waterway.id }
    val nearbyFacilities = facilities.filter { it.waterwayId == waterway.id }
    val activeStoppages = notices.filter { it.waterwayId == waterway.id }
    val imperial = preferences.useImperialUnits

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Card with custom illustration
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = CanalNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.height(186.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.img_waterway_hero),
                        contentDescription = "British narrowboat cruising through stone lock",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        CanalNavy.copy(alpha = 0.25f),
                                        CanalNavy.copy(alpha = 0.88f)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color.White.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = "WATERWAYS.OS",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                            Surface(
                                color = SoftAmber.copy(alpha = 0.92f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = "DEMO MODE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CanalNavy,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = if (preferences.languageCode == "cy") waterway.welshName else waterway.name,
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = strings.tagline,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.88f)
                            )
                        }
                    }
                }
            }
        }

        // 2. Demo & Location Honesty Banner
        item {
            DemoAndOfflineHeaderBanner(
                isOfflineSimulated = uiState.isOfflineSimulated,
                bannerText = strings.demoBanner
            )
        }

        // 3. Waterway Selector
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.currentWaterway,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.LocationSearching,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Manual corridor selection",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    waterways.forEach { w ->
                        FilterChip(
                            selected = w.id == waterway.id,
                            onClick = { onSelectWaterway(w) },
                            label = {
                                Text(
                                    text = if (preferences.languageCode == "cy") w.welshName else w.name,
                                    maxLines = 1
                                )
                            },
                            modifier = Modifier.testTag("waterway_chip_${w.id}")
                        )
                    }
                }
            }
        }

        // 4. Primary 4 Actions Grid (PLAN JOURNEY, VIEW MAP, FIND NEXT LOCK, CHECK IN)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onPlanJourneyClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("action_plan_journey"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.Route, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.planJourney, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    FilledTonalButton(
                        onClick = onViewMapClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("action_view_map"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.Map, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.viewMap, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = { nextLock?.let { onFindNextLockClick(it.id) } },
                        enabled = nextLock != null,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("action_find_next_lock"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.findNextLock, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        onClick = { nextLock?.let { onCheckInClick(it.id) } },
                        enabled = nextLock != null && nextLock.checkInSupported,
                        colors = ButtonDefaults.buttonColors(containerColor = HeritageGreen),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("action_quick_check_in"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.checkIn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        // 5. Current Journey Card (if started)
        if (activeJourney != null) {
            item {
                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPlanJourneyClick() },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.DirectionsBoat, contentDescription = null, tint = WaterBlue)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strings.activeJourney, style = MaterialTheme.typography.titleMedium)
                            }
                            Text(
                                text = UnitFormatter.formatDistance(activeJourney.remainingDistanceKm, imperial) + " left",
                                style = MaterialTheme.typography.labelSmall,
                                color = WaterBlue
                            )
                        }
                        Text(activeJourney.route.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        LinearProgressIndicator(
                            progress = { activeJourney.progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                        Text(
                            text = "Current point: ${activeJourney.currentNode.name}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 6. Next Lock & Distance Card
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.nextLock, style = MaterialTheme.typography.titleMedium)
                        if (nextLock != null) {
                            OperationalStatusBadge(nextLock.operationalStatus)
                        }
                    }
                    if (nextLock != null) {
                        Text(nextLock.name, style = MaterialTheme.typography.titleLarge)
                        val distanceText = if (activeJourney != null) {
                            "Next lock along active route"
                        } else {
                            "Corridor marker: ${UnitFormatter.formatDistance(nextLock.distanceAlongKm, imperial)} from start"
                        }
                        Text(distanceText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FilledTonalButton(
                                onClick = { onFindNextLockClick(nextLock.id) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Lock Details")
                            }
                            Button(
                                onClick = { onCheckInClick(nextLock.id) },
                                enabled = nextLock.checkInSupported,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Quick Check-In")
                            }
                        }
                        DataFreshnessFooter(
                            sourceName = nextLock.meta.sourceName,
                            lastUpdatedIso = nextLock.meta.lastUpdatedIso,
                            isSimulated = nextLock.meta.isSimulated
                        )
                    } else {
                        Text("No lock nodes listed on this corridor.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        // 7. Active Stoppages & Weather Summary Row
        item {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenNoticesClick() },
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Warning, contentDescription = null, tint = SoftAmber)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.stoppagesAndNotices, style = MaterialTheme.typography.titleMedium)
                        }
                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "Open notices")
                    }
                    if (activeStoppages.isEmpty()) {
                        Text(
                            text = "No simulated stoppages on ${waterway.name} in the demo dataset.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        activeStoppages.forEach { notice ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = notice.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                SeverityBadge(notice.severity)
                            }
                        }
                    }
                }
            }
        }

        // 8. Honest Weather Status Card
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CloudOff,
                        contentDescription = "Weather service status",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = strings.weatherUnavailable,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 9. Nearby Moorings & Facilities
        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Anchor, contentDescription = null, tint = HeritageGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.nearbyMoorings, style = MaterialTheme.typography.titleMedium)
                    }
                    if (nearbyMoorings.isEmpty()) {
                        Text("No moorings indexed on this corridor.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        nearbyMoorings.forEach { mooring ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(mooring.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Text(
                                        text = "${mooring.type.label} • Max ${mooring.maxStayHours}h • ${mooring.availabilityStatus.label}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.WaterDrop, contentDescription = null, tint = WaterBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.nearbyFacilities, style = MaterialTheme.typography.titleMedium)
                    }
                    nearbyFacilities.take(3).forEach { fac ->
                        Text(
                            text = "• ${fac.name} (${fac.category.label}) — ${fac.accessInfo}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 10. Favourite Destinations
        item {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bookmark, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.favourites, style = MaterialTheme.typography.titleMedium)
                    }
                    if (savedPlaces.isEmpty()) {
                        Text(
                            text = "Tap the bookmark icon on any lock or map point to save favourite destinations offline.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        savedPlaces.forEach { place ->
                            Text(
                                text = "★ ${place.name} (${place.waterwayName})",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }
    }
}
