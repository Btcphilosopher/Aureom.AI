package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DirectionsBoat
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.CheckInHistoryEntity
import com.example.domain.model.BoatType
import com.example.domain.model.OfflineRegion
import com.example.domain.model.UserPreferences
import com.example.domain.model.VesselProfile
import com.example.ui.components.SafetyCalloutCard
import com.example.ui.components.StatusPillBadge
import com.example.ui.theme.CanalNavy
import com.example.ui.theme.HeritageGreen
import com.example.ui.theme.HeritageGreenContainer
import com.example.ui.theme.SoftAmber
import com.example.ui.theme.SoftAmberContainer
import com.example.ui.theme.StoppageRed
import com.example.ui.theme.WaterBlue

@Composable
fun ProfileScreen(
    preferences: UserPreferences,
    vessel: VesselProfile,
    offlineRegions: List<OfflineRegion>,
    checkInHistory: List<CheckInHistoryEntity>,
    isOfflineSimulated: Boolean,
    onSaveVessel: (VesselProfile) -> Unit,
    onToggleOfflineRegion: (OfflineRegion) -> Unit,
    onToggleOfflineSimulation: () -> Unit,
    onUpdatePreferences: ((UserPreferences) -> UserPreferences) -> Unit,
    onDeleteLocalAccountData: () -> Unit,
    modifier: Modifier = Modifier
) {
    var boatName by remember(vessel.name) { mutableStateOf(vessel.name) }
    var boatType by remember(vessel.boatType) { mutableStateOf(vessel.boatType) }
    var lengthStr by remember(vessel.lengthFt) { mutableStateOf(vessel.lengthFt.toString()) }
    var beamStr by remember(vessel.beamFt) { mutableStateOf(vessel.beamFt.toString()) }
    var draughtStr by remember(vessel.draughtFt) { mutableStateOf(vessel.draughtFt.toString()) }
    var airDraughtStr by remember(vessel.airDraughtFt) { mutableStateOf(vessel.airDraughtFt.toString()) }
    var speedStr by remember(vessel.preferredSpeedMph) { mutableStateOf(vessel.preferredSpeedMph.toString()) }
    var homeMooring by remember(vessel.homeMooring) { mutableStateOf(vessel.homeMooring) }
    var accessibilityNeeds by remember(vessel.accessibilityNeeds) { mutableStateOf(vessel.accessibilityNeeds) }
    var isPrivate by remember(vessel.isPrivateByDefault) { mutableStateOf(vessel.isPrivateByDefault) }

    var emailInput by remember(preferences.accountEmail) {
        mutableStateOf(if (preferences.isSignedIn) preferences.accountEmail else "")
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        onUpdatePreferences { it.copy(notifyApproachingLock = granted) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("profile_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Vessel Profile Editor
        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.DirectionsBoat, contentDescription = null, tint = WaterBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Boat Profile & Dimensions", style = MaterialTheme.typography.titleLarge)
                    }
                    Text(
                        text = "Used by the waterway router to validate lock chambers, bridges, and tunnels.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BoatType.entries.forEach { t ->
                            FilterChip(
                                selected = boatType == t,
                                onClick = { boatType = t },
                                label = { Text(t.label) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = boatName,
                        onValueChange = { boatName = it },
                        label = { Text("Boat Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = lengthStr,
                            onValueChange = { lengthStr = it },
                            label = { Text("Length (ft)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = beamStr,
                            onValueChange = { beamStr = it },
                            label = { Text("Beam (ft)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("vessel_beam_input")
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = draughtStr,
                            onValueChange = { draughtStr = it },
                            label = { Text("Draught (ft)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = airDraughtStr,
                            onValueChange = { airDraughtStr = it },
                            label = { Text("Air Draught (ft)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = speedStr,
                            onValueChange = { speedStr = it },
                            label = { Text("Speed (mph)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = homeMooring,
                            onValueChange = { homeMooring = it },
                            label = { Text("Home Mooring") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = accessibilityNeeds,
                        onValueChange = { accessibilityNeeds = it },
                        label = { Text("Accessibility Needs") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Keep vessel identity private by default", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = isPrivate, onCheckedChange = { isPrivate = it })
                    }

                    Button(
                        onClick = {
                            onSaveVessel(
                                vessel.copy(
                                    name = boatName.ifBlank { "Private Vessel" },
                                    boatType = boatType,
                                    lengthFt = lengthStr.toDoubleOrNull() ?: vessel.lengthFt,
                                    beamFt = beamStr.toDoubleOrNull() ?: vessel.beamFt,
                                    draughtFt = draughtStr.toDoubleOrNull() ?: vessel.draughtFt,
                                    airDraughtFt = airDraughtStr.toDoubleOrNull() ?: vessel.airDraughtFt,
                                    preferredSpeedMph = speedStr.toDoubleOrNull() ?: vessel.preferredSpeedMph,
                                    homeMooring = homeMooring,
                                    accessibilityNeeds = accessibilityNeeds,
                                    isPrivateByDefault = isPrivate
                                )
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_vessel_profile_button")
                    ) {
                        Text("Save Boat Profile & Validate Routes")
                    }
                }
            }
        }

        // 2. Offline Navigation & Regions
        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Offline Navigation Packs", style = MaterialTheme.typography.titleLarge)
                    SafetyCalloutCard(
                        title = "Offline Integrity Rule",
                        body = "Downloaded packs cache waterway graphs, locks, and facilities. Offline mode never implies live lock availability."
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Simulate Offline Mode", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = isOfflineSimulated, onCheckedChange = { onToggleOfflineSimulation() })
                    }
                    HorizontalDivider()
                    offlineRegions.forEach { reg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(reg.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = "${reg.lockCount} locks • ${reg.sizeMb} MB • Synced ${reg.lastSyncedIso}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (reg.isStale) {
                                    Text("Stale cache warning — sync when online", style = MaterialTheme.typography.labelSmall, color = SoftAmber)
                                }
                            }
                            FilledTonalButton(onClick = { onToggleOfflineRegion(reg) }) {
                                Icon(
                                    imageVector = if (reg.isDownloaded) Icons.Rounded.DownloadDone else Icons.Rounded.Download,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (reg.isDownloaded) "Cached" else "Download")
                            }
                        }
                    }
                }
            }
        }

        // 3. Personalisation & Accessibility
        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Personalisation & Units", style = MaterialTheme.typography.titleLarge)
                    }

                    PreferenceToggleRow("Dark Mode (Dusk Cruising)", preferences.darkMode) { v ->
                        onUpdatePreferences { it.copy(darkMode = v) }
                    }
                    PreferenceToggleRow("Large Accessible Text", preferences.largeText) { v ->
                        onUpdatePreferences { it.copy(largeText = v) }
                    }
                    PreferenceToggleRow("Imperial Units (mi / ft / in)", preferences.useImperialUnits) { v ->
                        onUpdatePreferences { it.copy(useImperialUnits = v) }
                    }
                    PreferenceToggleRow("Welsh Localisation (Cymraeg)", preferences.languageCode == "cy") { v ->
                        onUpdatePreferences { it.copy(languageCode = if (v) "cy" else "en") }
                    }

                    Text("Daily Cruising Hours: ${preferences.dailyCruisingHours.toInt()} hrs/day", style = MaterialTheme.typography.titleSmall)
                    Slider(
                        value = preferences.dailyCruisingHours.toFloat(),
                        onValueChange = { hours ->
                            onUpdatePreferences { it.copy(dailyCruisingHours = hours.toDouble()) }
                        },
                        valueRange = 2f..10f,
                        steps = 7
                    )

                    HorizontalDivider()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Notifications, contentDescription = null, tint = WaterBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Navigation Alerts", style = MaterialTheme.typography.titleMedium)
                    }
                    PreferenceToggleRow("Approaching Lock Alerts", preferences.notifyApproachingLock) { v ->
                        if (v && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            onUpdatePreferences { it.copy(notifyApproachingLock = v) }
                        }
                    }
                    PreferenceToggleRow("Upcoming Junction Alerts", preferences.notifyJunction) { v ->
                        onUpdatePreferences { it.copy(notifyJunction = v) }
                    }
                    PreferenceToggleRow("Known Closure Ahead Alerts", preferences.notifyClosure) { v ->
                        onUpdatePreferences { it.copy(notifyClosure = v) }
                    }
                    PreferenceToggleRow("Low Bridge Warnings", preferences.notifyLowBridge) { v ->
                        onUpdatePreferences { it.copy(notifyLowBridge = v) }
                    }
                }
            }
        }

        // 4. Account, Check-in History & GDPR
        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Account & Privacy", style = MaterialTheme.typography.titleLarge)
                        }
                        StatusPillBadge(
                            text = if (preferences.isSignedIn) "DEMO SIGNED IN" else "GUEST BROWSING",
                            containerColor = if (preferences.isSignedIn) HeritageGreenContainer else SoftAmberContainer,
                            contentColor = CanalNavy
                        )
                    }

                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Boater Email (Demo Local Account)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                if (emailInput.contains("@")) {
                                    onUpdatePreferences { it.copy(isSignedIn = true, accountEmail = emailInput.trim()) }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Sign In (Demo)")
                        }
                        OutlinedButton(
                            onClick = {
                                onUpdatePreferences { it.copy(isSignedIn = false, accountEmail = "Guest Boater") }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Guest Mode")
                        }
                    }

                    if (checkInHistory.isNotEmpty()) {
                        HorizontalDivider()
                        Text("Recent Lock Check-In History", style = MaterialTheme.typography.titleSmall)
                        checkInHistory.take(5).forEach { chk ->
                            Text(
                                text = "• ${chk.lockName} (${chk.direction}) — ${chk.checkedInAtIso}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    HorizontalDivider()
                    OutlinedButton(
                        onClick = onDeleteLocalAccountData,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StoppageRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.DeleteForever, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Delete Local Account & Saved Data (GDPR)")
                    }
                }
            }
        }
    }
}

@Composable
private fun PreferenceToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
