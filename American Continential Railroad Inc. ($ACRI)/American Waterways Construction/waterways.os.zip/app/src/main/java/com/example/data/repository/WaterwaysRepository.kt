package com.example.data.repository

import android.content.Context
import com.example.data.local.CheckInHistoryEntity
import com.example.data.local.CommunityReportEntity
import com.example.data.local.OfflineRegionEntity
import com.example.data.local.PreferencesRepository
import com.example.data.local.SavedPlaceEntity
import com.example.data.local.SavedRouteEntity
import com.example.data.local.VesselEntity
import com.example.data.local.WaterwaysDatabase
import com.example.data.remote.LockOsDemoEngine
import com.example.data.seed.WaterwaysSeedData
import com.example.domain.model.ActiveJourney
import com.example.domain.model.BoatType
import com.example.domain.model.CheckInMethod
import com.example.domain.model.CommunityReport
import com.example.domain.model.CommunityReportType
import com.example.domain.model.LockCheckIn
import com.example.domain.model.LockQueueState
import com.example.domain.model.LockServiceStatus
import com.example.domain.model.Mooring
import com.example.domain.model.NavigationNotice
import com.example.domain.model.OfflineRegion
import com.example.domain.model.PlannedRoute
import com.example.domain.model.RouteCalculationResult
import com.example.domain.model.RoutePlanRequest
import com.example.domain.model.TravelDirection
import com.example.domain.model.UserPreferences
import com.example.domain.model.VesselProfile
import com.example.domain.model.Waterway
import com.example.domain.model.WaterwayFacility
import com.example.domain.model.WaterwayNode
import com.example.domain.routing.WaterwayRouter
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.util.UUID

class WaterwaysRepository(
    context: Context,
    private val db: WaterwaysDatabase = WaterwaysDatabase.getInstance(context),
    private val prefsRepo: PreferencesRepository = PreferencesRepository(context),
    private val router: WaterwayRouter = WaterwayRouter(),
    val lockOsEngine: LockOsDemoEngine = LockOsDemoEngine()
) {
    private val dao = db.waterwaysDao()
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val routeAdapter = moshi.adapter(PlannedRoute::class.java)

    val waterways: List<Waterway> = WaterwaysSeedData.waterways
    val nodes: List<WaterwayNode> = WaterwaysSeedData.nodes
    val edges = WaterwaysSeedData.edges
    val notices: List<NavigationNotice> = WaterwaysSeedData.notices
    val moorings: List<Mooring> = WaterwaysSeedData.moorings
    val facilities: List<WaterwayFacility> = WaterwaysSeedData.facilities

    val preferences: Flow<UserPreferences> = prefsRepo.preferencesFlow

    val vesselProfile: Flow<VesselProfile> = dao.observeVessel().map { entity ->
        if (entity == null) VesselProfile()
        else VesselProfile(
            id = entity.id,
            name = entity.name,
            boatType = runCatching { BoatType.valueOf(entity.boatType) }.getOrDefault(BoatType.NARROWBOAT),
            lengthFt = entity.lengthFt,
            beamFt = entity.beamFt,
            draughtFt = entity.draughtFt,
            airDraughtFt = entity.airDraughtFt,
            homeMooring = entity.homeMooring,
            preferredSpeedMph = entity.preferredSpeedMph,
            accessibilityNeeds = entity.accessibilityNeeds,
            isPrivateByDefault = entity.isPrivateByDefault
        )
    }

    val savedRoutes: Flow<List<PlannedRoute>> = dao.observeSavedRoutes().map { list ->
        list.mapNotNull { entity ->
            runCatching { routeAdapter.fromJson(entity.routeJson) }.getOrNull()?.copy(
                isSavedOffline = true,
                savedAtIso = entity.savedAtIso
            )
        }
    }

    val checkInHistory: Flow<List<CheckInHistoryEntity>> = dao.observeCheckIns()
    val savedPlaces: Flow<List<SavedPlaceEntity>> = dao.observeSavedPlaces()

    val offlineRegions: Flow<List<OfflineRegion>> = dao.observeOfflineRegions().map { list ->
        if (list.isEmpty()) WaterwaysSeedData.initialOfflineRegions
        else list.map {
            OfflineRegion(
                id = it.id,
                name = it.name,
                waterwayIds = it.waterwayIdsCsv.split(",").filter { s -> s.isNotBlank() },
                sizeMb = it.sizeMb,
                lockCount = it.lockCount,
                isDownloaded = it.isDownloaded,
                lastSyncedIso = it.lastSyncedIso,
                isStale = it.isStale
            )
        }
    }

    val communityReports: Flow<List<CommunityReport>> = dao.observeCommunityReports().map { list ->
        val dbReports = list.map {
            CommunityReport(
                id = it.id,
                waterwayId = it.waterwayId,
                targetName = it.targetName,
                type = runCatching { CommunityReportType.valueOf(it.type) }.getOrDefault(CommunityReportType.NAVIGATION_TIP),
                authorAlias = it.authorAlias,
                comment = it.comment,
                timestampIso = it.timestampIso,
                isVerifiedOfficial = false
            )
        }
        dbReports + WaterwaysSeedData.initialCommunityReports
    }

    val activeCheckIn: StateFlow<LockCheckIn?> = lockOsEngine.activeCheckIn
    val activeQueue: StateFlow<LockQueueState?> = lockOsEngine.activeQueue
    val activeServiceStatus: StateFlow<LockServiceStatus?> = lockOsEngine.serviceStatus

    private val _activeJourney = MutableStateFlow<ActiveJourney?>(null)
    val activeJourney: StateFlow<ActiveJourney?> = _activeJourney.asStateFlow()

    suspend fun ensureSeeded() {
        dao.upsertOfflineRegions(
            WaterwaysSeedData.initialOfflineRegions.map {
                OfflineRegionEntity(
                    id = it.id,
                    name = it.name,
                    waterwayIdsCsv = it.waterwayIds.joinToString(","),
                    sizeMb = it.sizeMb,
                    lockCount = it.lockCount,
                    isDownloaded = it.isDownloaded,
                    lastSyncedIso = it.lastSyncedIso,
                    isStale = it.isStale
                )
            }
        )
    }

    fun calculateRoute(request: RoutePlanRequest): RouteCalculationResult {
        return router.planRoute(request, nodes, edges)
    }

    suspend fun saveRouteOffline(route: PlannedRoute): PlannedRoute {
        val now = lockOsEngine.currentIsoTimestamp()
        val offlineRoute = route.copy(isSavedOffline = true, savedAtIso = now)
        val json = routeAdapter.toJson(offlineRoute)
        dao.saveRoute(
            SavedRouteEntity(
                id = offlineRoute.id,
                name = offlineRoute.name,
                startNodeId = offlineRoute.startNode.id,
                destinationNodeId = offlineRoute.destinationNode.id,
                viaNodeId = offlineRoute.viaNode?.id,
                routeJson = json,
                totalDistanceKm = offlineRoute.totalDistanceKm,
                lockCount = offlineRoute.lockCount,
                totalMinutes = offlineRoute.totalMinutes,
                savedAtIso = now
            )
        )
        return offlineRoute
    }

    suspend fun deleteSavedRoute(id: String) = dao.deleteSavedRoute(id)

    fun startJourney(route: PlannedRoute) {
        _activeJourney.value = ActiveJourney(
            route = route,
            currentNodeIndex = 0,
            isActive = true,
            startedAtIso = lockOsEngine.currentIsoTimestamp()
        )
    }

    fun advanceJourneyWaypoint() {
        val current = _activeJourney.value ?: return
        if (current.currentNodeIndex < current.route.orderedNodes.lastIndex) {
            _activeJourney.value = current.copy(currentNodeIndex = current.currentNodeIndex + 1)
        }
    }

    fun stopJourney() {
        _activeJourney.value = null
    }

    suspend fun registerLockCheckIn(
        lock: WaterwayNode,
        vesselName: String,
        direction: TravelDirection,
        method: CheckInMethod,
        idempotencyKey: String
    ): Result<LockCheckIn> {
        val result = lockOsEngine.registerArrival(lock, vesselName, direction, method, idempotencyKey)
        result.onSuccess { checkIn ->
            dao.insertCheckIn(
                CheckInHistoryEntity(
                    id = checkIn.id,
                    lockId = checkIn.lockId,
                    lockName = checkIn.lockName,
                    vesselName = checkIn.vesselName,
                    direction = checkIn.direction.label,
                    method = checkIn.method.label,
                    idempotencyKey = checkIn.idempotencyKey,
                    checkedInAtIso = checkIn.checkedInAtIso,
                    statusSummary = "Simulated Check-In Logged"
                )
            )
        }
        return result
    }

    fun submitLockOsServiceRequest(lock: WaterwayNode) = lockOsEngine.submitLockOsServiceRequest(lock)

    fun advanceSimulatedLockState() = lockOsEngine.advanceSimulatedQueueAndService()

    fun leaveLockQueue() = lockOsEngine.leaveQueueAndCancel()

    suspend fun saveVesselProfile(profile: VesselProfile) {
        dao.saveVessel(
            VesselEntity(
                id = profile.id,
                name = profile.name,
                boatType = profile.boatType.name,
                lengthFt = profile.lengthFt,
                beamFt = profile.beamFt,
                draughtFt = profile.draughtFt,
                airDraughtFt = profile.airDraughtFt,
                homeMooring = profile.homeMooring,
                preferredSpeedMph = profile.preferredSpeedMph,
                accessibilityNeeds = profile.accessibilityNeeds,
                isPrivateByDefault = profile.isPrivateByDefault
            )
        )
    }

    suspend fun toggleOfflineRegion(region: OfflineRegion) {
        val now = lockOsEngine.currentIsoTimestamp()
        dao.upsertOfflineRegions(
            listOf(
                OfflineRegionEntity(
                    id = region.id,
                    name = region.name,
                    waterwayIdsCsv = region.waterwayIds.joinToString(","),
                    sizeMb = region.sizeMb,
                    lockCount = region.lockCount,
                    isDownloaded = !region.isDownloaded,
                    lastSyncedIso = now,
                    isStale = false
                )
            )
        )
    }

    suspend fun toggleSavedPlace(id: String, name: String, category: String, waterwayName: String, currentlySaved: Boolean) {
        if (currentlySaved) {
            dao.deleteSavedPlace(id)
        } else {
            dao.savePlace(
                SavedPlaceEntity(
                    id = id,
                    name = name,
                    category = category,
                    waterwayName = waterwayName,
                    savedAtIso = lockOsEngine.currentIsoTimestamp()
                )
            )
        }
    }

    suspend fun addCommunityReport(
        waterwayId: String,
        targetName: String,
        type: CommunityReportType,
        authorAlias: String,
        comment: String
    ): Result<Unit> {
        val blockedTerms = listOf("http://", "https://", "spam", "<script")
        if (comment.isBlank() || blockedTerms.any { comment.contains(it, ignoreCase = true) }) {
            return Result.failure(IllegalArgumentException("Report flagged by community moderation filter. Keep notes concise and link-free."))
        }
        dao.insertCommunityReport(
            CommunityReportEntity(
                id = "cr_${UUID.randomUUID().toString().take(8)}",
                waterwayId = waterwayId,
                targetName = targetName,
                type = type.name,
                authorAlias = authorAlias.ifBlank { "Boater" },
                comment = comment.trim(),
                timestampIso = lockOsEngine.currentIsoTimestamp()
            )
        )
        return Result.success(Unit)
    }

    suspend fun updatePreferences(transform: (UserPreferences) -> UserPreferences) {
        prefsRepo.updatePreferences(transform)
    }

    suspend fun deleteLocalAccountData() {
        dao.clearAllSavedRoutes()
        dao.clearAllCheckIns()
        dao.clearAllSavedPlaces()
        prefsRepo.resetAccount()
    }
}
