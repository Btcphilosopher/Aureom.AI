package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.SavedPlaceEntity
import com.example.domain.model.LockOperationalStatus
import com.example.domain.model.Mooring
import com.example.domain.model.NodeType
import com.example.domain.model.PlannedRoute
import com.example.domain.model.RouteCalculationResult
import com.example.domain.model.Waterway
import com.example.domain.model.WaterwayEdge
import com.example.domain.model.WaterwayFacility
import com.example.domain.model.WaterwayNode
import com.example.ui.WaterwaysUiState
import com.example.ui.components.DataFreshnessFooter
import com.example.ui.components.OperationalStatusBadge
import com.example.ui.theme.CanalNavy
import com.example.ui.theme.HeritageGreen
import com.example.ui.theme.SoftAmber
import com.example.ui.theme.StoppageRed
import com.example.ui.theme.WaterBlue
import com.example.ui.theme.WaterBlueBright
import kotlin.math.hypot

@Composable
fun MapScreen(
    uiState: WaterwaysUiState,
    waterways: List<Waterway>,
    nodes: List<WaterwayNode>,
    edges: List<WaterwayEdge>,
    moorings: List<Mooring>,
    facilities: List<WaterwayFacility>,
    savedPlaces: List<SavedPlaceEntity>,
    onSelectWaterway: (Waterway) -> Unit,
    onSelectMapNode: (String?) -> Unit,
    onOpenLockDetail: (String) -> Unit,
    onSetRouteStart: (String) -> Unit,
    onSetRouteEnd: (String) -> Unit,
    onToggleSavePlace: (WaterwayNode) -> Unit,
    modifier: Modifier = Modifier
) {
    var showLocks by remember { mutableStateOf(true) }
    var showStructures by remember { mutableStateOf(true) }
    var showMoorings by remember { mutableStateOf(true) }
    var showFacilities by remember { mutableStateOf(false) }

    var zoom by remember { mutableFloatStateOf(1.15f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }

    val minLat = 51.25
    val maxLat = 53.20
    val minLon = -3.20
    val maxLon = 0.05

    val plannedRoute: PlannedRoute? = (uiState.routeResult as? RouteCalculationResult.Success)?.route
    val routeEdgeIds = plannedRoute?.legs?.map { it.edgeId }?.toSet() ?: emptySet()
    val selectedNode = nodes.firstOrNull { it.id == uiState.selectedMapNodeId }

    fun projectPoint(lat: Double, lon: Double, w: Float, h: Float): Offset {
        val normX = ((lon - minLon) / (maxLon - minLon)).toFloat()
        val normY = (1.0 - (lat - minLat) / (maxLat - minLat)).toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val x = cx + ((normX * w) - cx) * zoom + panX
        val y = cy + ((normY * h) - cy) * zoom + panY
        return Offset(x, y)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("map_screen")
    ) {
        val bgColor = MaterialTheme.colorScheme.background
        val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
        val canalBaseColor = WaterBlue

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .background(bgColor)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        panX += dragAmount.x
                        panY += dragAmount.y
                    }
                }
                .pointerInput(nodes, zoom, panX, panY) {
                    detectTapGestures { tapOffset ->
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        var nearest: WaterwayNode? = null
                        var bestDist = 56f
                        for (node in nodes) {
                            val pt = projectPoint(node.lat, node.lon, w, h)
                            val d = hypot(pt.x - tapOffset.x, pt.y - tapOffset.y)
                            if (d < bestDist) {
                                bestDist = d
                                nearest = node
                            }
                        }
                        onSelectMapNode(nearest?.id)
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // Subtle nautical latitude/longitude grid lines
            val step = 90f
            var gx = 0f
            while (gx < w) {
                drawLine(gridColor, Offset(gx, 0f), Offset(gx, h), strokeWidth = 1f)
                gx += step
            }
            var gy = 0f
            while (gy < h) {
                drawLine(gridColor, Offset(0f, gy), Offset(w, gy), strokeWidth = 1f)
                gy += step
            }

            val nodeMap = nodes.associateBy { it.id }

            // Draw waterway edges
            for (edge in edges) {
                val from = nodeMap[edge.fromNodeId] ?: continue
                val to = nodeMap[edge.toNodeId] ?: continue
                val p1 = projectPoint(from.lat, from.lon, w, h)
                val p2 = projectPoint(to.lat, to.lon, w, h)

                val isSelectedCorridor = edge.waterwayId == uiState.selectedWaterway.id
                val isRouteEdge = routeEdgeIds.contains(edge.id)

                val strokeColor = when {
                    edge.isClosed -> StoppageRed
                    isRouteEdge -> SoftAmber
                    isSelectedCorridor -> WaterBlueBright
                    else -> canalBaseColor.copy(alpha = 0.55f)
                }
                val strokeWidth = when {
                    isRouteEdge -> 11f
                    isSelectedCorridor -> 7.5f
                    else -> 4.5f
                }

                drawLine(
                    color = strokeColor,
                    start = p1,
                    end = p2,
                    strokeWidth = strokeWidth,
                    cap = StrokeCap.Round,
                    pathEffect = if (edge.isClosed) PathEffect.dashPathEffect(floatArrayOf(16f, 10f)) else null
                )
            }

            // Draw Facilities
            if (showFacilities) {
                for (fac in facilities) {
                    val p = projectPoint(fac.lat, fac.lon, w, h)
                    drawCircle(color = Color(0xFF00838F), radius = 8f, center = p)
                }
            }

            // Draw Moorings
            if (showMoorings) {
                for (m in moorings) {
                    val p = projectPoint(m.lat, m.lon, w, h)
                    drawCircle(color = HeritageGreen, radius = 10f, center = p)
                    drawCircle(color = Color.White, radius = 4f, center = p)
                }
            }

            // Draw Waterway Nodes (Locks, Bridges, Tunnels, Aqueducts, Junctions, Basins)
            for (node in nodes) {
                val isLock = node.type == NodeType.LOCK
                if (isLock && !showLocks) continue
                if (!isLock && !showStructures) continue

                val p = projectPoint(node.lat, node.lon, w, h)
                val isSelected = node.id == uiState.selectedMapNodeId
                val color = when {
                    node.operationalStatus == LockOperationalStatus.CLOSED -> StoppageRed
                    node.isLockOsEnabled -> SoftAmber
                    isLock -> CanalNavy
                    node.type == NodeType.AQUEDUCT -> HeritageGreen
                    node.type == NodeType.TUNNEL -> Color(0xFF5D4037)
                    else -> WaterBlue
                }

                if (isSelected) {
                    drawCircle(color = SoftAmber.copy(alpha = 0.35f), radius = 28f, center = p)
                }
                drawCircle(color = Color.White, radius = 15f, center = p)
                drawCircle(color = color, radius = 11.5f, center = p)
            }
        }

        // Top Filter & Waterway Quick-Focus Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                tonalElevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        waterways.forEach { w ->
                            FilterChip(
                                selected = w.id == uiState.selectedWaterway.id,
                                onClick = {
                                    onSelectWaterway(w)
                                    val first = nodes.firstOrNull { it.waterwayId == w.id }
                                    if (first != null) {
                                        onSelectMapNode(first.id)
                                    }
                                },
                                label = { Text(w.name.substringBefore(" (")) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(selected = showLocks, onClick = { showLocks = !showLocks }, label = { Text("Locks") })
                        FilterChip(selected = showStructures, onClick = { showStructures = !showStructures }, label = { Text("Bridges/Tunnels") })
                        FilterChip(selected = showMoorings, onClick = { showMoorings = !showMoorings }, label = { Text("Moorings") })
                        FilterChip(selected = showFacilities, onClick = { showFacilities = !showFacilities }, label = { Text("Facilities") })
                    }
                    Text(
                        text = "OSM-compatible Demo Graph • Freshness: ${uiState.selectedWaterway.meta.lastUpdatedIso} • Tap any marker",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Map Zoom & Reset Controls
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SmallFloatingActionButton(
                onClick = { zoom = (zoom * 1.25f).coerceAtMost(4.5f) },
                modifier = Modifier.testTag("map_zoom_in")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Zoom in")
            }
            SmallFloatingActionButton(
                onClick = { zoom = (zoom / 1.25f).coerceAtLeast(0.75f) },
                modifier = Modifier.testTag("map_zoom_out")
            ) {
                Icon(Icons.Rounded.Remove, contentDescription = "Zoom out")
            }
            FloatingActionButton(
                onClick = {
                    zoom = 1.15f
                    panX = 0f
                    panY = 0f
                },
                modifier = Modifier.size(44.dp)
            ) {
                Icon(Icons.Rounded.MyLocation, contentDescription = "Reset map view")
            }
        }

        // Selected Node Bottom Sheet Card
        if (selectedNode != null) {
            val isSaved = savedPlaces.any { it.id == selectedNode.id }
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(12.dp)
                    .testTag("map_node_detail_card"),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(selectedNode.type.label.uppercase(), style = MaterialTheme.typography.labelSmall, color = WaterBlue)
                            Text(selectedNode.name, style = MaterialTheme.typography.titleLarge)
                        }
                        IconButton(onClick = { onToggleSavePlace(selectedNode) }) {
                            Icon(
                                imageVector = if (isSaved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                contentDescription = "Toggle favourite"
                            )
                        }
                        IconButton(onClick = { onSelectMapNode(null) }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close details")
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OperationalStatusBadge(selectedNode.operationalStatus)
                        if (selectedNode.isLockOsEnabled) {
                            Surface(color = Color(0xFFFCECD4), shape = CircleShape) {
                                Text(
                                    text = "LOCK.OS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CanalNavy,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Text(
                            text = "%.4f, %.4f".format(selectedNode.lat, selectedNode.lon),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(selectedNode.restrictionsNote, style = MaterialTheme.typography.bodySmall)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onSetRouteStart(selectedNode.id) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Set Start", maxLines = 1)
                        }
                        Button(
                            onClick = { onSetRouteEnd(selectedNode.id) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Route, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Set Dest", maxLines = 1)
                        }
                        if (selectedNode.type == NodeType.LOCK) {
                            Button(
                                onClick = { onOpenLockDetail(selectedNode.id) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Lock", maxLines = 1)
                            }
                        }
                    }

                    DataFreshnessFooter(
                        sourceName = selectedNode.meta.sourceName,
                        lastUpdatedIso = selectedNode.meta.lastUpdatedIso,
                        isSimulated = selectedNode.meta.isSimulated
                    )
                }
            }
        }
    }
}
