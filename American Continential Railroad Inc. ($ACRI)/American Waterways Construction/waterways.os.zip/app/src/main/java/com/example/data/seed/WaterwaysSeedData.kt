package com.example.data.seed

import com.example.domain.model.CommunityReport
import com.example.domain.model.CommunityReportType
import com.example.domain.model.DataSourceMeta
import com.example.domain.model.FacilityCategory
import com.example.domain.model.LockOperationalStatus
import com.example.domain.model.Mooring
import com.example.domain.model.MooringAvailabilityStatus
import com.example.domain.model.MooringType
import com.example.domain.model.NavigationNotice
import com.example.domain.model.NodeType
import com.example.domain.model.NoticeSeverity
import com.example.domain.model.NoticeType
import com.example.domain.model.OfflineRegion
import com.example.domain.model.Waterway
import com.example.domain.model.WaterwayEdge
import com.example.domain.model.WaterwayFacility
import com.example.domain.model.WaterwayGaugeType
import com.example.domain.model.WaterwayNode

object WaterwaysSeedData {

    private val demoGeoMeta = DataSourceMeta(
        sourceName = "OpenStreetMap & WATERWAYS.OS Demo Graph",
        lastUpdatedIso = "2026-11-21T08:00:00Z",
        isSimulated = true,
        licenceNote = "Independent demo dataset • ODbL-compatible geometry • Not official CRT feed"
    )

    private val demoOpsMeta = DataSourceMeta(
        sourceName = "LOCK.OS Demo Telemetry Simulator",
        lastUpdatedIso = "2026-11-21T10:15:00Z",
        isSimulated = true,
        licenceNote = "Simulated operational data for demonstration only"
    )

    val waterways: List<Waterway> = listOf(
        Waterway(
            id = "gu_main",
            name = "Grand Union Canal (Midlands)",
            welshName = "Camlas Grand Union (Canolbarth)",
            region = "Midlands",
            lengthKm = 74.0,
            lockCount = 34,
            gaugeType = WaterwayGaugeType.BROAD,
            maxLengthFt = 72.0,
            maxBeamFt = 12.5,
            maxDraughtFt = 3.5,
            maxAirDraughtFt = 7.2,
            description = "Broad-beam trunk route linking Braunston Junction, Hatton Flight, and Birmingham Gas Street Basin.",
            nearestAccessPoint = "Hatton Locks Visitor Car Park (CV35 7JL)",
            meta = demoGeoMeta
        ),
        Waterway(
            id = "oxford_canal",
            name = "Oxford Canal",
            welshName = "Camlas Rhydychen",
            region = "Midlands & Oxfordshire",
            lengthKm = 125.0,
            lockCount = 46,
            gaugeType = WaterwayGaugeType.NARROW,
            maxLengthFt = 70.0,
            maxBeamFt = 6.9,
            maxDraughtFt = 3.0,
            maxAirDraughtFt = 6.8,
            description = "Scenic narrow canal connecting Braunston & Napton Junctions southwards through Banbury to Oxford.",
            nearestAccessPoint = "Napton Bridge 112 Access (CV47 8NQ)",
            meta = demoGeoMeta
        ),
        Waterway(
            id = "kennet_avon",
            name = "Kennet & Avon Canal",
            welshName = "Camlas Kennet ac Avon",
            region = "South West",
            lengthKm = 140.0,
            lockCount = 105,
            gaugeType = WaterwayGaugeType.BROAD,
            maxLengthFt = 70.0,
            maxBeamFt = 13.5,
            maxDraughtFt = 3.5,
            maxAirDraughtFt = 7.5,
            description = "Broad canal featuring Caen Hill Flight at Devizes, Dundas Aqueduct, and Bath Deep Lock.",
            nearestAccessPoint = "Devizes Wharf Access Point (SN10 1EU)",
            meta = demoGeoMeta
        ),
        Waterway(
            id = "llangollen",
            name = "Llangollen Canal",
            welshName = "Camlas Llangollen",
            region = "Wales & Shropshire",
            lengthKm = 74.0,
            lockCount = 21,
            gaugeType = WaterwayGaugeType.NARROW,
            maxLengthFt = 70.0,
            maxBeamFt = 6.85,
            maxDraughtFt = 2.8,
            maxAirDraughtFt = 6.5,
            description = "Cross-border heritage canal famous for Pontcysyllte and Chirk Aqueducts into North Wales.",
            nearestAccessPoint = "Trevor Basin Visitor Point (LL20 7TY)",
            meta = demoGeoMeta
        ),
        Waterway(
            id = "lee_navigation",
            name = "Lee Navigation (London)",
            welshName = "Dyfrffordd Lee (Llundain)",
            region = "London & South East",
            lengthKm = 45.0,
            lockCount = 19,
            gaugeType = WaterwayGaugeType.BROAD,
            maxLengthFt = 80.0,
            maxBeamFt = 14.0,
            maxDraughtFt = 4.0,
            maxAirDraughtFt = 8.0,
            description = "Urban river-canal navigation from Limehouse Basin north through LOCK.OS-enabled demonstration locks.",
            nearestAccessPoint = "Limehouse Basin Lock Office (E14 8JT)",
            meta = demoGeoMeta
        )
    )

    val nodes: List<WaterwayNode> = listOf(
        // Grand Union Canal (connected to Oxford via Braunston & Napton)
        WaterwayNode(
            id = "gu_braunston_jct",
            waterwayId = "gu_main",
            name = "Braunston Junction",
            type = NodeType.JUNCTION,
            lat = 52.2905,
            lon = -1.2089,
            distanceAlongKm = 0.0,
            restrictionsNote = "Sharp turn onto Oxford Canal; watch emerging boats.",
            accessibilityNotes = "Level towpath bridge and surfaced apron.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "gu_braunston_tunnel",
            waterwayId = "gu_main",
            name = "Braunston Tunnel",
            type = NodeType.TUNNEL,
            lat = 52.2921,
            lon = -1.1865,
            distanceAlongKm = 2.8,
            tunnelLengthYards = 2042,
            bridgeHeadroomFt = 7.4,
            restrictionsNote = "Two-way broad tunnel; use tunnel headlamp and horn before entry.",
            accessibilityNotes = "No towpath inside tunnel; mooring rings at both portals.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "gu_napton_jct",
            waterwayId = "gu_main",
            name = "Napton Junction",
            type = NodeType.JUNCTION,
            lat = 52.2630,
            lon = -1.3235,
            distanceAlongKm = 8.4,
            restrictionsNote = "Junction with South Oxford Canal.",
            accessibilityNotes = "Surfaced towpath with seating.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "gu_hatton_bottom",
            waterwayId = "gu_main",
            name = "Hatton Bottom Lock (No. 46)",
            type = NodeType.LOCK,
            lat = 52.2874,
            lon = -1.6152,
            distanceAlongKm = 26.2,
            lockNumber = "46",
            chamberLengthFt = 74.0,
            chamberWidthFt = 13.0,
            riseFallFt = 7.2,
            restrictionsNote = "Start of Hatton Flight (21 broad locks). Share locks where feasible.",
            accessibilityNotes = "Steep side ramps; anti-slip lock landings installed.",
            isLockOsEnabled = true,
            automationAvailable = true,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.OPEN,
            meta = demoOpsMeta
        ),
        WaterwayNode(
            id = "gu_hatton_top",
            waterwayId = "gu_main",
            name = "Hatton Top Lock (No. 26)",
            type = NodeType.LOCK,
            lat = 52.2981,
            lon = -1.6448,
            distanceAlongKm = 29.8,
            lockNumber = "26",
            chamberLengthFt = 74.0,
            chamberWidthFt = 13.0,
            riseFallFt = 7.5,
            restrictionsNote = "Top of Hatton Flight; café & water point adjacent.",
            accessibilityNotes = "Level visitor terrace and accessible WC nearby.",
            isLockOsEnabled = true,
            automationAvailable = false,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.OPEN,
            meta = demoOpsMeta
        ),
        WaterwayNode(
            id = "gu_knowle_bridge",
            waterwayId = "gu_main",
            name = "Knowle Low Accommodation Bridge 74",
            type = NodeType.BRIDGE,
            lat = 52.3820,
            lon = -1.7240,
            distanceAlongKm = 43.0,
            bridgeHeadroomFt = 6.9,
            restrictionsNote = "Slightly tight arch profile; check chimney/roof boxes.",
            dimensionUncertainty = true,
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "gu_gas_street",
            waterwayId = "gu_main",
            name = "Gas Street Basin (Birmingham)",
            type = NodeType.BASIN,
            lat = 52.4754,
            lon = -1.9061,
            distanceAlongKm = 61.5,
            restrictionsNote = "48-hour visitor moorings; no running generators 20:00–08:00.",
            accessibilityNotes = "Step-free paved promenade and city access.",
            meta = demoGeoMeta
        ),

        // Oxford Canal
        WaterwayNode(
            id = "ox_napton_lock",
            waterwayId = "oxford_canal",
            name = "Napton Bottom Lock (No. 8)",
            type = NodeType.LOCK,
            lat = 52.2442,
            lon = -1.3204,
            distanceAlongKm = 3.2,
            lockNumber = "8",
            chamberLengthFt = 72.0,
            chamberWidthFt = 7.0,
            riseFallFt = 6.8,
            restrictionsNote = "Narrow lock (max beam 7ft). Watch cill marker on descent.",
            accessibilityNotes = "Grass towpath; firm gravel around lock gates.",
            isLockOsEnabled = false,
            automationAvailable = false,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.OPEN,
            meta = demoOpsMeta
        ),
        WaterwayNode(
            id = "ox_banbury_lock",
            waterwayId = "oxford_canal",
            name = "Banbury Lock (No. 28)",
            type = NodeType.LOCK,
            lat = 52.0628,
            lon = -1.3338,
            distanceAlongKm = 27.6,
            lockNumber = "28",
            chamberLengthFt = 72.0,
            chamberWidthFt = 7.0,
            riseFallFt = 6.5,
            restrictionsNote = "Lift bridge adjacent; Castle Quay marina entrance.",
            accessibilityNotes = "Paved town-centre quay and step-free access.",
            isLockOsEnabled = true,
            automationAvailable = false,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.OPEN,
            meta = demoOpsMeta
        ),
        WaterwayNode(
            id = "ox_thrupp_bridge",
            waterwayId = "oxford_canal",
            name = "Thrupp Lift Bridge 223",
            type = NodeType.BRIDGE,
            lat = 51.8351,
            lon = -1.3002,
            distanceAlongKm = 54.0,
            bridgeHeadroomFt = 6.4,
            restrictionsNote = "Manual windlass-operated lift bridge when closed.",
            accessibilityNotes = "Firm gravel approach.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "ox_isis_lock",
            waterwayId = "oxford_canal",
            name = "Isis Lock (No. 46, Oxford)",
            type = NodeType.LOCK,
            lat = 51.7535,
            lon = -1.2699,
            distanceAlongKm = 65.4,
            lockNumber = "46",
            chamberLengthFt = 72.0,
            chamberWidthFt = 7.0,
            riseFallFt = 5.4,
            restrictionsNote = "Link towards River Thames via Sheepwash Channel.",
            accessibilityNotes = "Level towpath to Oxford station.",
            isLockOsEnabled = false,
            automationAvailable = false,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.RESTRICTED,
            meta = demoOpsMeta
        ),

        // Kennet & Avon Canal
        WaterwayNode(
            id = "ka_devizes_wharf",
            waterwayId = "kennet_avon",
            name = "Devizes Wharf Basin",
            type = NodeType.BASIN,
            lat = 51.3547,
            lon = -1.9958,
            distanceAlongKm = 0.0,
            restrictionsNote = "Preparation point before Caen Hill Flight.",
            accessibilityNotes = "Surfaced wharf with café and museum access.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "ka_caen_hill_top",
            waterwayId = "kennet_avon",
            name = "Caen Hill Lock 44 (Top of Flight)",
            type = NodeType.LOCK,
            lat = 51.3519,
            lon = -2.0124,
            distanceAlongKm = 1.4,
            lockNumber = "44",
            chamberLengthFt = 73.0,
            chamberWidthFt = 13.8,
            riseFallFt = 8.0,
            restrictionsNote = "Flight passage window 08:00–16:00 (side ponds conservation).",
            accessibilityNotes = "Steep gradient; volunteer lock keepers often assist.",
            isLockOsEnabled = true,
            automationAvailable = false,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.RESTRICTED,
            meta = demoOpsMeta
        ),
        WaterwayNode(
            id = "ka_bradford_lock",
            waterwayId = "kennet_avon",
            name = "Bradford on Avon Lock (No. 14)",
            type = NodeType.LOCK,
            lat = 51.3446,
            lon = -2.2535,
            distanceAlongKm = 21.8,
            lockNumber = "14",
            chamberLengthFt = 73.0,
            chamberWidthFt = 13.8,
            riseFallFt = 10.2,
            restrictionsNote = "Heavy guillotine/mitre gates; keep centre line clear.",
            accessibilityNotes = "Good paved wharf on offside.",
            isLockOsEnabled = false,
            automationAvailable = false,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.OPEN,
            meta = demoOpsMeta
        ),
        WaterwayNode(
            id = "ka_dundas_aqueduct",
            waterwayId = "kennet_avon",
            name = "Dundas Aqueduct",
            type = NodeType.AQUEDUCT,
            lat = 51.3672,
            lon = -2.3106,
            distanceAlongKm = 27.9,
            restrictionsNote = "Historic stone aqueduct over River Avon; single-file slow passage.",
            accessibilityNotes = "Wide flagged walkway along aqueduct.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "ka_bath_deep_lock",
            waterwayId = "kennet_avon",
            name = "Bath Deep Lock (No. 8/9)",
            type = NodeType.LOCK,
            lat = 51.3771,
            lon = -2.3526,
            distanceAlongKm = 34.4,
            lockNumber = "8/9",
            chamberLengthFt = 73.0,
            chamberWidthFt = 13.8,
            riseFallFt = 19.4,
            restrictionsNote = "Second deepest lock in England (19ft 5in). Use long centre line!",
            accessibilityNotes = "Steep steps on lock wall; handrail provided.",
            isLockOsEnabled = true,
            automationAvailable = true,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.OPEN,
            meta = demoOpsMeta
        ),

        // Llangollen Canal
        WaterwayNode(
            id = "ll_hurleston_jct",
            waterwayId = "llangollen",
            name = "Hurleston Junction",
            type = NodeType.JUNCTION,
            lat = 53.0955,
            lon = -2.5594,
            distanceAlongKm = 0.0,
            restrictionsNote = "Entrance to Llangollen branch from Shropshire Union.",
            accessibilityNotes = "Gravel path.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "ll_grindley_brook",
            waterwayId = "llangollen",
            name = "Grindley Brook Staircase Locks",
            type = NodeType.LOCK,
            lat = 52.9781,
            lon = -2.7073,
            distanceAlongKm = 21.5,
            lockNumber = "1–3",
            chamberLengthFt = 71.0,
            chamberWidthFt = 6.95,
            riseFallFt = 19.0,
            restrictionsNote = "3-rise staircase; follow lock keeper instructions when manned.",
            accessibilityNotes = "Cafe & surfaced area at lockside.",
            isLockOsEnabled = false,
            automationAvailable = false,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.OPEN,
            meta = demoOpsMeta
        ),
        WaterwayNode(
            id = "ll_chirk_aqueduct",
            waterwayId = "llangollen",
            name = "Chirk Aqueduct & Tunnel",
            type = NodeType.TUNNEL,
            lat = 52.9317,
            lon = -3.0598,
            distanceAlongKm = 54.0,
            tunnelLengthYards = 459,
            bridgeHeadroomFt = 6.7,
            restrictionsNote = "Single-file narrow tunnel immediately north of Chirk Aqueduct.",
            accessibilityNotes = "Towpath runs alongside inside tunnel with rail.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "ll_pontcysyllte",
            waterwayId = "llangollen",
            name = "Pontcysyllte Aqueduct",
            type = NodeType.AQUEDUCT,
            lat = 52.9704,
            lon = -3.0878,
            distanceAlongKm = 61.2,
            restrictionsNote = "UNESCO World Heritage trough (126ft above River Dee). Tick-over speed only.",
            accessibilityNotes = "Narrow iron towpath with safety rail.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "ll_trevor_basin",
            waterwayId = "llangollen",
            name = "Trevor Basin",
            type = NodeType.BASIN,
            lat = 52.9752,
            lon = -3.0890,
            distanceAlongKm = 62.1,
            restrictionsNote = "Turn before narrow section towards Llangollen.",
            accessibilityNotes = "Visitor centre and accessible pathways.",
            meta = demoGeoMeta
        ),

        // Lee Navigation (London LOCK.OS Demo Corridor)
        WaterwayNode(
            id = "lee_limehouse",
            waterwayId = "lee_navigation",
            name = "Limehouse Basin",
            type = NodeType.MARINA,
            lat = 51.5112,
            lon = -0.0368,
            distanceAlongKm = 0.0,
            restrictionsNote = "Tidal Thames lock booking required for river exit.",
            accessibilityNotes = "Modern paved marina walkways.",
            meta = demoGeoMeta
        ),
        WaterwayNode(
            id = "lee_old_ford",
            waterwayId = "lee_navigation",
            name = "Old Ford Lock (No. 19)",
            type = NodeType.LOCK,
            lat = 51.5396,
            lon = -0.0229,
            distanceAlongKm = 4.5,
            lockNumber = "19",
            chamberLengthFt = 85.0,
            chamberWidthFt = 18.0,
            riseFallFt = 6.4,
            restrictionsNote = "Mechanised twin-chamber demo site compatible with LOCK.OS service requests.",
            accessibilityNotes = "Step-free Olympic Park towpath landing.",
            isLockOsEnabled = true,
            automationAvailable = true,
            queueAvailable = true,
            checkInSupported = true,
            operationalStatus = LockOperationalStatus.OPEN,
            meta = demoOpsMeta
        ),
        WaterwayNode(
            id = "lee_tottenham",
            waterwayId = "lee_navigation",
            name = "Tottenham Lock (No. 17)",
            type = NodeType.LOCK,
            lat = 51.5924,
            lon = -0.0569,
            distanceAlongKm = 12.1,
            lockNumber = "17",
            chamberLengthFt = 85.0,
            chamberWidthFt = 18.0,
            riseFallFt = 7.1,
            restrictionsNote = "Currently closed in Demo Mode for simulated winter gate maintenance.",
            accessibilityNotes = "Towpath diversion around lock island.",
            isLockOsEnabled = true,
            automationAvailable = true,
            queueAvailable = false,
            checkInSupported = false,
            operationalStatus = LockOperationalStatus.CLOSED,
            meta = demoOpsMeta
        )
    )

    val edges: List<WaterwayEdge> = listOf(
        // Grand Union edges
        WaterwayEdge("e_gu_1", "gu_braunston_jct", "gu_braunston_tunnel", "gu_main", 2.8, 0, 72.0, 12.5, 3.5, 7.2, hasTunnel = true),
        WaterwayEdge("e_gu_2", "gu_braunston_tunnel", "gu_napton_jct", "gu_main", 5.6, 3, 72.0, 12.5, 3.5, 7.2),
        WaterwayEdge("e_gu_3", "gu_napton_jct", "gu_hatton_bottom", "gu_main", 17.8, 5, 72.0, 12.5, 3.5, 7.2),
        WaterwayEdge("e_gu_4", "gu_hatton_bottom", "gu_hatton_top", "gu_main", 3.6, 21, 72.0, 12.5, 3.5, 7.2),
        WaterwayEdge("e_gu_5", "gu_hatton_top", "gu_knowle_bridge", "gu_main", 13.2, 5, 72.0, 12.5, 3.5, 6.9, hasLowBridge = true),
        WaterwayEdge("e_gu_6", "gu_knowle_bridge", "gu_gas_street", "gu_main", 18.5, 0, 72.0, 12.5, 3.5, 6.9),

        // Oxford Canal edges (joins Grand Union at Napton Junction!)
        WaterwayEdge("e_ox_1", "gu_napton_jct", "ox_napton_lock", "oxford_canal", 3.2, 1, 70.0, 6.9, 3.0, 6.8),
        WaterwayEdge("e_ox_2", "ox_napton_lock", "ox_banbury_lock", "oxford_canal", 24.4, 20, 70.0, 6.9, 3.0, 6.8),
        WaterwayEdge("e_ox_3", "ox_banbury_lock", "ox_thrupp_bridge", "oxford_canal", 26.4, 15, 70.0, 6.9, 3.0, 6.4, hasLowBridge = true),
        WaterwayEdge("e_ox_4", "ox_thrupp_bridge", "ox_isis_lock", "oxford_canal", 11.4, 10, 70.0, 6.9, 3.0, 6.4),

        // Kennet & Avon edges
        WaterwayEdge("e_ka_1", "ka_devizes_wharf", "ka_caen_hill_top", "kennet_avon", 1.4, 1, 70.0, 13.5, 3.5, 7.5),
        WaterwayEdge("e_ka_2", "ka_caen_hill_top", "ka_bradford_lock", "kennet_avon", 20.4, 29, 70.0, 13.5, 3.5, 7.5),
        WaterwayEdge("e_ka_3", "ka_bradford_lock", "ka_dundas_aqueduct", "kennet_avon", 6.1, 1, 70.0, 13.5, 3.5, 7.5),
        WaterwayEdge("e_ka_4", "ka_dundas_aqueduct", "ka_bath_deep_lock", "kennet_avon", 6.5, 4, 70.0, 13.5, 3.5, 7.5),

        // Llangollen Canal edges
        WaterwayEdge("e_ll_1", "ll_hurleston_jct", "ll_grindley_brook", "llangollen", 21.5, 9, 70.0, 6.85, 2.8, 6.5),
        WaterwayEdge("e_ll_2", "ll_grindley_brook", "ll_chirk_aqueduct", "llangollen", 32.5, 12, 70.0, 6.85, 2.8, 6.5, hasTunnel = true),
        WaterwayEdge("e_ll_3", "ll_chirk_aqueduct", "ll_pontcysyllte", "llangollen", 7.2, 0, 70.0, 6.85, 2.8, 6.5),
        WaterwayEdge("e_ll_4", "ll_pontcysyllte", "ll_trevor_basin", "llangollen", 0.9, 0, 70.0, 6.85, 2.8, 6.5),

        // Lee Navigation edges (one closed demo stoppage segment at Tottenham Lock)
        WaterwayEdge("e_lee_1", "lee_limehouse", "lee_old_ford", "lee_navigation", 4.5, 1, 80.0, 14.0, 4.0, 8.0),
        WaterwayEdge(
            id = "e_lee_2",
            fromNodeId = "lee_old_ford",
            toNodeId = "lee_tottenham",
            waterwayId = "lee_navigation",
            distanceKm = 7.6,
            lockCount = 2,
            maxLengthFt = 80.0,
            maxBeamFt = 14.0,
            maxDraughtFt = 4.0,
            maxAirDraughtFt = 8.0,
            isClosed = true,
            closureReason = "Simulated winter lock gate inspection at Tottenham Lock"
        )
    )

    val notices: List<NavigationNotice> = listOf(
        NavigationNotice(
            id = "n_1",
            waterwayId = "lee_navigation",
            waterwayName = "Lee Navigation (London)",
            region = "London & South East",
            title = "Simulated Stoppage: Tottenham Lock (No. 17) Gate Inspection",
            summary = "Demo notice: Lock 17 chamber dewatered for scheduled winter oak gate seal inspection. No through navigation.",
            type = NoticeType.PLANNED_CLOSURE,
            severity = NoticeSeverity.CRITICAL,
            affectedNodeId = "lee_tottenham",
            startDateIso = "2026-11-18",
            endDateIso = "2026-11-28",
            meta = demoOpsMeta
        ),
        NavigationNotice(
            id = "n_2",
            waterwayId = "kennet_avon",
            waterwayName = "Kennet & Avon Canal",
            region = "South West",
            title = "Caen Hill Flight Restricted Passage Hours",
            summary = "Demo notice: Lock passage open 08:00–16:00 daily to conserve summit water levels and side ponds.",
            type = NoticeType.LOW_WATER,
            severity = NoticeSeverity.HIGH,
            affectedNodeId = "ka_caen_hill_top",
            startDateIso = "2026-11-01",
            endDateIso = "2026-12-15",
            meta = demoOpsMeta
        ),
        NavigationNotice(
            id = "n_3",
            waterwayId = "oxford_canal",
            waterwayName = "Oxford Canal",
            region = "Midlands & Oxfordshire",
            title = "Isis Lock Water Conservation Advisory",
            summary = "Demo notice: Boaters asked to pair up through Isis Lock where possible due to seasonal low flow.",
            type = NoticeType.RESTRICTED_NAVIGATION,
            severity = NoticeSeverity.MODERATE,
            affectedNodeId = "ox_isis_lock",
            startDateIso = "2026-11-15",
            endDateIso = "2026-11-30",
            meta = demoOpsMeta
        ),
        NavigationNotice(
            id = "n_4",
            waterwayId = "gu_main",
            waterwayName = "Grand Union Canal (Midlands)",
            region = "Midlands",
            title = "Knowle Bridge 74 — Verify Air Draught",
            summary = "Demo notice: Arch profile narrows sharply at edges; keep centre channel.",
            type = NoticeType.BRIDGE_RESTRICTION,
            severity = NoticeSeverity.ADVISORY,
            affectedNodeId = "gu_knowle_bridge",
            startDateIso = "2026-11-10",
            endDateIso = "2026-12-31",
            meta = demoOpsMeta
        )
    )

    val moorings: List<Mooring> = listOf(
        Mooring(
            id = "m_1",
            waterwayId = "gu_main",
            name = "Braunston Turn Visitor Moorings",
            type = MooringType.VISITOR,
            lat = 52.2901,
            lon = -1.2102,
            maxStayHours = 48,
            feesSummary = "Free up to 48 hrs (demo)",
            facilities = listOf("Water Point", "Pub Nearby", "Towpath Rings"),
            restrictions = "No double mooring near junction.",
            accessibilityNotes = "Level paved edge with mooring rings.",
            nearbyServices = "Village shop 0.4 mi, chandlery at marina.",
            availabilityStatus = MooringAvailabilityStatus.UNCONFIRMED,
            meta = demoGeoMeta
        ),
        Mooring(
            id = "m_2",
            waterwayId = "gu_main",
            name = "Hatton Top Accessible Visitor Moorings",
            type = MooringType.ACCESSIBLE,
            lat = 52.2984,
            lon = -1.6462,
            maxStayHours = 48,
            feesSummary = "Free up to 48 hrs",
            facilities = listOf("Accessible WC", "Drinking Water", "Café"),
            restrictions = "Priority accessible berth clearly signed.",
            accessibilityNotes = "Step-free timber & stone wharf edge with bollards.",
            nearbyServices = "Hatton Locks Café 50 yards.",
            availabilityStatus = MooringAvailabilityStatus.UNCONFIRMED,
            meta = demoGeoMeta
        ),
        Mooring(
            id = "m_3",
            waterwayId = "gu_main",
            name = "Gas Street Basin Marina",
            type = MooringType.MARINA,
            lat = 52.4751,
            lon = -1.9068,
            maxStayHours = 168,
            feesSummary = "Overnight berthing fee £18/night (demo)",
            facilities = listOf("Shore Power", "Showers", "Water", "Pump-Out"),
            restrictions = "Pre-book via basin office for stays >48h.",
            accessibilityNotes = "Full paved promenade access.",
            nearbyServices = "Supermarkets, rail station, boat services within 0.3 mi.",
            availabilityStatus = MooringAvailabilityStatus.PROVIDER_CONFIRMED_AVAILABLE,
            meta = demoOpsMeta
        ),
        Mooring(
            id = "m_4",
            waterwayId = "oxford_canal",
            name = "Thrupp Village Overnight Moorings",
            type = MooringType.OVERNIGHT,
            lat = 51.8358,
            lon = -1.3010,
            maxStayHours = 48,
            feesSummary = "Free up to 48 hrs",
            facilities = listOf("Tea Rooms", "Pub", "Water Point 0.2 mi"),
            restrictions = "Keep clear of winding hole.",
            accessibilityNotes = "Grass bank; piling edge.",
            nearbyServices = "Village pub & tea room.",
            availabilityStatus = MooringAvailabilityStatus.UNCONFIRMED,
            meta = demoGeoMeta
        ),
        Mooring(
            id = "m_5",
            waterwayId = "kennet_avon",
            name = "Devizes Wharf Service & Overnight",
            type = MooringType.SERVICE,
            lat = 51.3545,
            lon = -1.9950,
            maxStayHours = 24,
            feesSummary = "Free service berth (30m) / 24h overnight nearby",
            facilities = listOf("Drinking Water", "Elsan", "Waste", "Pump-Out"),
            restrictions = "Service point berth limited to active servicing.",
            accessibilityNotes = "Firm surfaced towpath.",
            nearbyServices = "Town centre & grocery shops 0.2 mi.",
            availabilityStatus = MooringAvailabilityStatus.UNCONFIRMED,
            meta = demoGeoMeta
        ),
        Mooring(
            id = "m_6",
            waterwayId = "llangollen",
            name = "Trevor Basin Visitor Moorings",
            type = MooringType.LONG_STAY,
            lat = 52.9756,
            lon = -3.0894,
            maxStayHours = 72,
            feesSummary = "Free up to 72 hrs (winter demo)",
            facilities = listOf("Toilets", "Water", "Visitor Centre"),
            restrictions = "Turn in basin before narrow section.",
            accessibilityNotes = "Paved basin edge.",
            nearbyServices = "Trevor shops 0.3 mi.",
            availabilityStatus = MooringAvailabilityStatus.UNCONFIRMED,
            meta = demoGeoMeta
        )
    )

    val facilities: List<WaterwayFacility> = listOf(
        WaterwayFacility("f_1", "gu_main", "Braunston Water & Elsan Point", FacilityCategory.DRINKING_WATER, 52.2904, -1.2095, "Just east of Braunston Junction bridge.", "Key required (standard waterways key).", demoGeoMeta),
        WaterwayFacility("f_2", "gu_main", "Braunston Sanitary Station", FacilityCategory.ELSAN, 52.2906, -1.2098, "Adjacent to water tap at junction.", "Standard waterways key.", demoGeoMeta),
        WaterwayFacility("f_3", "gu_main", "Hatton Top Refuse & Recycling", FacilityCategory.WASTE_DISPOSAL, 52.2983, -1.6451, "Behind lock cottage by Lock 26.", "Unlocked compound.", demoGeoMeta),
        WaterwayFacility("f_4", "gu_main", "Hatton Locks Café & Provisions", FacilityCategory.CAFE_PUB, 52.2980, -1.6445, "At Hatton Top Lock terrace.", "Open 09:00–16:30.", demoGeoMeta),
        WaterwayFacility("f_5", "gu_main", "Gas Street Diesel & Pump-Out", FacilityCategory.PUMP_OUT, 52.4750, -1.9058, "West side of Gas Street Basin.", "Card / token during marina hours.", demoGeoMeta),
        WaterwayFacility("f_6", "gu_main", "Birmingham Basin Shore Power", FacilityCategory.ELECTRICITY, 52.4752, -1.9062, "Visitor pontoons 1–8.", "Pre-paid meter card.", demoGeoMeta),
        WaterwayFacility("f_7", "gu_main", "Gas Street Showers & Toilets", FacilityCategory.SHOWERS, 52.4753, -1.9063, "Basin facilities block.", "Standard key + marina code.", demoGeoMeta),
        WaterwayFacility("f_8", "oxford_canal", "Banbury Castle Quay Boat Fuel", FacilityCategory.FUEL, 52.0630, -1.3340, "Just south of Lock 28.", "Red diesel & solid fuel.", demoGeoMeta),
        WaterwayFacility("f_9", "oxford_canal", "Banbury Chandlery & Repairs", FacilityCategory.CHANDLER, 52.0625, -1.3335, "Tooley's Historic Boatyard.", "Mon–Sat 09:00–17:00.", demoGeoMeta),
        WaterwayFacility("f_10", "kennet_avon", "Devizes Boatyard Engineering", FacilityCategory.BOAT_REPAIRS, 51.3549, -1.9961, "Devizes Wharf slipway.", "Engine & hull servicing by appointment.", demoGeoMeta),
        WaterwayFacility("f_11", "kennet_avon", "Devizes Market Grocery", FacilityCategory.GROCERY, 51.3532, -1.9942, "3 mins walk south from Wharf.", "Daily 07:00–22:00.", demoGeoMeta),
        WaterwayFacility("f_12", "llangollen", "Trevor Basin Accessible WCs", FacilityCategory.TOILETS, 52.9753, -3.0891, "Next to visitor centre.", "Step-free Radar key / public access.", demoGeoMeta)
    )

    val initialOfflineRegions: List<OfflineRegion> = listOf(
        OfflineRegion("reg_midlands", "Midlands Canal Ring (GU & Oxford)", listOf("gu_main", "oxford_canal"), 14.2, 80, isDownloaded = true, lastSyncedIso = "2026-11-21T08:00:00Z", isStale = false),
        OfflineRegion("reg_southwest", "Kennet & Avon Corridor", listOf("kennet_avon"), 11.8, 105, isDownloaded = false, lastSyncedIso = "2026-11-12T14:00:00Z", isStale = true),
        OfflineRegion("reg_wales", "North Wales & Llangollen", listOf("llangollen"), 8.4, 21, isDownloaded = false, lastSyncedIso = "2026-11-18T09:30:00Z", isStale = false),
        OfflineRegion("reg_london", "London Lee & Thames Link", listOf("lee_navigation"), 6.1, 19, isDownloaded = false, lastSyncedIso = "2026-11-19T12:00:00Z", isStale = false)
    )

    val initialCommunityReports: List<CommunityReport> = listOf(
        CommunityReport(
            id = "cr_1",
            waterwayId = "gu_main",
            targetName = "Hatton Bottom Lock (No. 46)",
            type = CommunityReportType.NAVIGATION_TIP,
            authorAlias = "NB_Heron",
            comment = "Bottom paddle stiff on offside gate; works smoothly if wound steadily.",
            timestampIso = "2026-11-20T15:20:00Z",
            isVerifiedOfficial = false
        ),
        CommunityReport(
            id = "cr_2",
            waterwayId = "oxford_canal",
            targetName = "Thrupp Village Overnight Moorings",
            type = CommunityReportType.MOORING_REVIEW,
            authorAlias = "WillowCruiser",
            comment = "Quiet overnight spot with good mooring pins and level bank near Bridge 223.",
            timestampIso = "2026-11-19T18:45:00Z",
            isVerifiedOfficial = false
        )
    )
}
