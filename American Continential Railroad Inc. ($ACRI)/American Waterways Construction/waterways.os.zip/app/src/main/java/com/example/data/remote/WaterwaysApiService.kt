package com.example.data.remote

import com.example.domain.model.CheckInMethod
import com.example.domain.model.LockCheckIn
import com.example.domain.model.LockOperationalStatus
import com.example.domain.model.LockQueueState
import com.example.domain.model.LockServiceState
import com.example.domain.model.LockServiceStatus
import com.example.domain.model.TravelDirection
import com.example.domain.model.WaterwayNode
import com.squareup.moshi.JsonClass
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

@JsonClass(generateAdapter = true)
data class CheckInRequestDto(
    val vesselName: String,
    val direction: String,
    val method: String,
    val idempotencyKey: String
)

@JsonClass(generateAdapter = true)
data class CheckInResponseDto(
    val checkInId: String,
    val lockId: String,
    val queuePosition: Int,
    val vesselsAhead: Int,
    val estimatedWaitMinutes: Int,
    val status: String,
    val isSimulated: Boolean
)

@JsonClass(generateAdapter = true)
data class LockStatusDto(
    val lockId: String,
    val operatingStatus: String,
    val automationAvailable: Boolean,
    val queueAvailable: Boolean,
    val serviceState: String,
    val localControllerNotice: String,
    val isSimulated: Boolean
)

@JsonClass(generateAdapter = true)
data class RoutePlanDto(
    val startNodeId: String,
    val destinationNodeId: String,
    val viaNodeId: String?,
    val lengthFt: Double,
    val beamFt: Double,
    val draughtFt: Double,
    val airDraughtFt: Double
)

/**
 * Retrofit contract defining the WATERWAYS.OS & LOCK.OS API boundary.
 * All physical actuator control remains isolated behind the independent local safety controller.
 */
interface WaterwaysApiService {
    @GET("/api/v1/waterways")
    suspend fun getWaterways(): List<Map<String, Any>>

    @GET("/api/v1/locks")
    suspend fun getLocks(): List<LockStatusDto>

    @GET("/api/v1/locks/{id}")
    suspend fun getLockDetail(@Path("id") id: String): LockStatusDto

    @GET("/api/v1/locks/{id}/status")
    suspend fun getLockStatus(@Path("id") id: String): LockStatusDto

    @POST("/api/v1/locks/{id}/check-in")
    suspend fun submitCheckIn(
        @Path("id") id: String,
        @Body body: CheckInRequestDto
    ): CheckInResponseDto

    @GET("/api/v1/locks/{id}/queue")
    suspend fun getLockQueue(@Path("id") id: String): CheckInResponseDto

    @POST("/api/v1/routes/plan")
    suspend fun planRoute(@Body request: RoutePlanDto): Map<String, Any>

    @GET("/api/v1/notices")
    suspend fun getNotices(): List<Map<String, Any>>

    @GET("/api/v1/moorings")
    suspend fun getMoorings(): List<Map<String, Any>>

    @GET("/api/v1/facilities")
    suspend fun getFacilities(): List<Map<String, Any>>

    @GET("/api/v1/journeys/{id}")
    suspend fun getJourney(@Path("id") id: String): Map<String, Any>
}

/**
 * Deterministic LOCK.OS Demo Engine.
 * Handles idempotent arrival registration, simulated queue progression, and
 * strictly separated service-request states (never displaying GATE OPEN on request acceptance).
 */
class LockOsDemoEngine {

    private val seenIdempotencyKeys = mutableMapOf<String, LockCheckIn>()

    private val _activeCheckIn = MutableStateFlow<LockCheckIn?>(null)
    val activeCheckIn: StateFlow<LockCheckIn?> = _activeCheckIn.asStateFlow()

    private val _activeQueue = MutableStateFlow<LockQueueState?>(null)
    val activeQueue: StateFlow<LockQueueState?> = _activeQueue.asStateFlow()

    private val _serviceStatus = MutableStateFlow<LockServiceStatus?>(null)
    val serviceStatus: StateFlow<LockServiceStatus?> = _serviceStatus.asStateFlow()

    fun registerArrival(
        lock: WaterwayNode,
        vesselName: String,
        direction: TravelDirection,
        method: CheckInMethod,
        idempotencyKey: String
    ): Result<LockCheckIn> {
        if (lock.operationalStatus == LockOperationalStatus.CLOSED) {
            return Result.failure(IllegalStateException("${lock.name} is currently closed due to a stoppage notice."))
        }
        if (!lock.checkInSupported) {
            return Result.failure(IllegalStateException("${lock.name} does not support digital arrival check-in."))
        }

        // Prevent duplicate submissions using idempotency key
        seenIdempotencyKeys[idempotencyKey]?.let { existing ->
            _activeCheckIn.value = existing
            return Result.success(existing)
        }

        val now = currentIsoTimestamp()
        val checkIn = LockCheckIn(
            id = "chk_${UUID.randomUUID().toString().take(8)}",
            lockId = lock.id,
            lockName = lock.name,
            vesselName = vesselName.ifBlank { "Private Vessel" },
            direction = direction,
            method = method,
            idempotencyKey = idempotencyKey,
            checkedInAtIso = now,
            isSimulated = true
        )
        seenIdempotencyKeys[idempotencyKey] = checkIn
        _activeCheckIn.value = checkIn

        val initialVesselsAhead = if (lock.isLockOsEnabled) 2 else 1
        _activeQueue.value = LockQueueState(
            lockId = lock.id,
            lockName = lock.name,
            checkInId = checkIn.id,
            queuePosition = initialVesselsAhead + 1,
            vesselsAhead = initialVesselsAhead,
            direction = direction,
            estimatedWaitMinutes = (initialVesselsAhead + 1) * 12,
            queueStatus = "Active in Demo Queue",
            lockAvailability = lock.operationalStatus.label,
            isSimulated = true,
            lastUpdatedIso = now
        )

        _serviceStatus.value = if (lock.automationAvailable && lock.isLockOsEnabled) {
            LockServiceStatus(
                lockId = lock.id,
                state = LockServiceState.IDLE,
                statusDetail = "LOCK.OS site ready. Arrival logged; no actuator command issued.",
                localControllerNotice = "Local safety controller online (Demo simulation).",
                isSimulated = true,
                updatedAtIso = now
            )
        } else {
            LockServiceStatus(
                lockId = lock.id,
                state = LockServiceState.SERVICE_UNAVAILABLE,
                statusDetail = LockServiceState.SERVICE_UNAVAILABLE.description,
                localControllerNotice = "Manual lock operation site.",
                isSimulated = true,
                updatedAtIso = now
            )
        }

        return Result.success(checkIn)
    }

    fun submitLockOsServiceRequest(lock: WaterwayNode) {
        val now = currentIsoTimestamp()
        if (!lock.automationAvailable || !lock.isLockOsEnabled) {
            _serviceStatus.value = LockServiceStatus(
                lockId = lock.id,
                state = LockServiceState.SERVICE_UNAVAILABLE,
                statusDetail = LockServiceState.SERVICE_UNAVAILABLE.description,
                localControllerNotice = "Remote service requests are not supported at ${lock.name}.",
                isSimulated = true,
                updatedAtIso = now
            )
            return
        }

        _serviceStatus.value = LockServiceStatus(
            lockId = lock.id,
            state = LockServiceState.REQUEST_SUBMITTED,
            statusDetail = LockServiceState.REQUEST_SUBMITTED.description,
            localControllerNotice = "Awaiting LOCK.OS gateway acknowledgement.",
            isSimulated = true,
            updatedAtIso = now
        )
    }

    fun advanceSimulatedQueueAndService() {
        val now = currentIsoTimestamp()
        _activeQueue.value?.let { q ->
            if (q.vesselsAhead > 0) {
                val nextAhead = q.vesselsAhead - 1
                _activeQueue.value = q.copy(
                    vesselsAhead = nextAhead,
                    queuePosition = nextAhead + 1,
                    estimatedWaitMinutes = (nextAhead + 1) * 10,
                    queueStatus = if (nextAhead == 0) "Next for Lock Passage (Simulated)" else "Advancing in Demo Queue",
                    lastUpdatedIso = now
                )
            }
        }

        _serviceStatus.value?.let { s ->
            val nextState = when (s.state) {
                LockServiceState.IDLE -> LockServiceState.IDLE
                LockServiceState.REQUEST_SUBMITTED -> LockServiceState.REQUEST_ACCEPTED
                LockServiceState.REQUEST_ACCEPTED -> LockServiceState.WAITING_LOCAL_AUTHORISATION
                LockServiceState.WAITING_LOCAL_AUTHORISATION -> LockServiceState.SERVICE_IN_PROGRESS
                LockServiceState.SERVICE_IN_PROGRESS -> LockServiceState.SERVICE_COMPLETE
                LockServiceState.SERVICE_COMPLETE -> LockServiceState.SERVICE_COMPLETE
                LockServiceState.SERVICE_UNAVAILABLE -> LockServiceState.SERVICE_UNAVAILABLE
            }
            _serviceStatus.value = s.copy(
                state = nextState,
                statusDetail = nextState.description,
                localControllerNotice = when (nextState) {
                    LockServiceState.REQUEST_ACCEPTED -> "Server accepted request. Physical gates remain under local controller interlock."
                    LockServiceState.WAITING_LOCAL_AUTHORISATION -> "Local PLC verifying chamber water level & vessel sensors."
                    LockServiceState.SERVICE_IN_PROGRESS -> "Local safety controller authorised automated cycle."
                    LockServiceState.SERVICE_COMPLETE -> "Cycle finished. Check physical lock signals before entering."
                    else -> s.localControllerNotice
                },
                updatedAtIso = now
            )
        }
    }

    fun leaveQueueAndCancel() {
        _activeCheckIn.value = null
        _activeQueue.value = null
        _serviceStatus.value = null
    }

    fun currentIsoTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.UK)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }
}
