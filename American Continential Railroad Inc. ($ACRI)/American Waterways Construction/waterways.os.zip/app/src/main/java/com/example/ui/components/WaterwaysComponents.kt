package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.LockOperationalStatus
import com.example.domain.model.NoticeSeverity
import com.example.domain.model.WaterwayNode
import com.example.ui.theme.CanalNavy
import com.example.ui.theme.HeritageGreen
import com.example.ui.theme.HeritageGreenContainer
import com.example.ui.theme.SoftAmber
import com.example.ui.theme.SoftAmberContainer
import com.example.ui.theme.StoppageRed
import com.example.ui.theme.StoppageRedContainer
import com.example.ui.theme.WaterBlue
import com.example.ui.theme.WaterBlueContainer

@Composable
fun DemoAndOfflineHeaderBanner(
    isOfflineSimulated: Boolean,
    bannerText: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = if (isOfflineSimulated) SoftAmberContainer else MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (isOfflineSimulated) SoftAmber.copy(alpha = 0.5f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isOfflineSimulated) Icons.Rounded.WifiOff else Icons.Rounded.Science,
                contentDescription = null,
                tint = if (isOfflineSimulated) SoftAmber else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isOfflineSimulated) {
                    "Offline Mode Active — Cached graph only; live lock availability & conditions are unknown."
                } else {
                    bannerText
                },
                style = MaterialTheme.typography.labelMedium,
                color = if (isOfflineSimulated) CanalNavy else MaterialTheme.colorScheme.onPrimaryContainer,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun StatusPillBadge(
    text: String,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = containerColor,
        shape = CircleShape
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = contentColor,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun OperationalStatusBadge(status: LockOperationalStatus) {
    val (bg, fg) = when (status) {
        LockOperationalStatus.OPEN -> HeritageGreenContainer to HeritageGreen
        LockOperationalStatus.RESTRICTED -> SoftAmberContainer to SoftAmber
        LockOperationalStatus.MAINTENANCE -> SoftAmberContainer to SoftAmber
        LockOperationalStatus.CLOSED -> StoppageRedContainer to StoppageRed
    }
    StatusPillBadge(text = status.label, containerColor = bg, contentColor = fg)
}

@Composable
fun SeverityBadge(severity: NoticeSeverity) {
    val (bg, fg) = when (severity) {
        NoticeSeverity.CRITICAL -> StoppageRedContainer to StoppageRed
        NoticeSeverity.HIGH -> SoftAmberContainer to SoftAmber
        NoticeSeverity.MODERATE -> WaterBlueContainer to WaterBlue
        NoticeSeverity.ADVISORY -> HeritageGreenContainer to HeritageGreen
    }
    StatusPillBadge(text = severity.label.uppercase(), containerColor = bg, contentColor = fg)
}

@Composable
fun SafetyCalloutCard(
    title: String,
    body: String,
    isWarning: Boolean = false,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = if (isWarning) SoftAmberContainer else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (isWarning) SoftAmber else MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = if (isWarning) Icons.Rounded.Warning else Icons.Rounded.Shield,
                contentDescription = title,
                tint = if (isWarning) SoftAmber else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isWarning) CanalNavy else MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isWarning) CanalNavy else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun DataFreshnessFooter(
    sourceName: String,
    lastUpdatedIso: String,
    isSimulated: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(
                imageVector = Icons.Rounded.Info,
                contentDescription = "Source attribution",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$sourceName • Updated $lastUpdatedIso",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (isSimulated) {
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "SIMULATED",
                style = MaterialTheme.typography.labelSmall,
                color = SoftAmber,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Custom architectural Canvas cross-section diagram of a canal lock chamber.
 * Visualises upper pound, mitre gates, chamber water level, cill step, and lower pound.
 */
@Composable
fun LockChamberDiagram(
    lock: WaterwayNode,
    modifier: Modifier = Modifier
) {
    val navy = CanalNavy
    val water = WaterBlue
    val green = HeritageGreen
    val amber = SoftAmber

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CHAMBER CROSS-SECTION SCHEMATIC",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Rise/Fall: ${lock.riseFallFt ?: "--"} ft",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(124.dp)
        ) {
            val w = size.width
            val h = size.height

            // Upper pound water (left)
            drawRect(
                color = water.copy(alpha = 0.78f),
                topLeft = Offset(0f, h * 0.28f),
                size = Size(w * 0.25f, h * 0.42f)
            )
            // Chamber water (middle)
            drawRect(
                color = water.copy(alpha = 0.55f),
                topLeft = Offset(w * 0.27f, h * 0.44f),
                size = Size(w * 0.46f, h * 0.44f)
            )
            // Lower pound water (right)
            drawRect(
                color = water.copy(alpha = 0.85f),
                topLeft = Offset(w * 0.75f, h * 0.64f),
                size = Size(w * 0.25f, h * 0.24f)
            )

            // Masonry bed and cill step
            val masonryPath = Path().apply {
                moveTo(0f, h * 0.70f)
                lineTo(w * 0.25f, h * 0.70f)
                lineTo(w * 0.25f, h * 0.88f)
                lineTo(w * 0.75f, h * 0.88f)
                lineTo(w * 0.75f, h * 0.96f)
                lineTo(w, h * 0.96f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(masonryPath, color = navy.copy(alpha = 0.85f))

            // Top gate (left)
            drawLine(
                color = amber,
                start = Offset(w * 0.26f, h * 0.16f),
                end = Offset(w * 0.26f, h * 0.88f),
                strokeWidth = 8f
            )
            // Bottom gate (right)
            drawLine(
                color = amber,
                start = Offset(w * 0.74f, h * 0.16f),
                end = Offset(w * 0.74f, h * 0.90f),
                strokeWidth = 8f
            )

            // Cill hazard highlight inside top gate
            drawRect(
                color = StoppageRed.copy(alpha = 0.85f),
                topLeft = Offset(w * 0.27f, h * 0.68f),
                size = Size(w * 0.06f, h * 0.20f)
            )

            // Narrowboat silhouette inside chamber
            drawRoundRect(
                color = green,
                topLeft = Offset(w * 0.36f, h * 0.35f),
                size = Size(w * 0.30f, h * 0.12f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
            )
            drawRect(
                color = navy,
                topLeft = Offset(w * 0.39f, h * 0.29f),
                size = Size(w * 0.21f, h * 0.06f)
            )

            // Chamber boundary outline
            drawRect(
                color = navy.copy(alpha = 0.2f),
                topLeft = Offset(0f, 0f),
                size = size,
                style = Stroke(width = 2f)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Upper Pound • Mind Cill Step",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "${lock.chamberLengthFt ?: "--"}ft × ${lock.chamberWidthFt ?: "--"}ft",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
