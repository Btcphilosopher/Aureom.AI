package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CheckInHistoryEntity
import com.example.data.local.SavedPlaceEntity
import com.example.data.repository.WaterwaysRepository
import com.example.domain.model.ActiveJourney
import com.example.domain.model.CheckInMethod
import com.example.domain.model.CommunityReport
import com.example.domain.model.CommunityReportType
import com.example.domain.model.LockCheckIn
import com.example.domain.model.LockQueueState
import com.example.domain.model.LockServiceStatus
import com.example.domain.model.Mooring
import com.example.domain.model.NavigationNotice
import com.example.domain.model.NodeType
import com.example.domain.model.NoticeSeverity
import com.example.domain.model.OfflineRegion
import com.example.domain.model.PlannedRoute
import com.example.domain.model.RouteCalculationResult
import com.example.domain.model.RoutePlanRequest
import com.example.domain.model.TravelDirection
import com.example.domain.model.UserPreferences
import com.example.domain.model.VesselProfile
import com.example.domain.model.Waterway
import com.example.domain.model.WaterwayEdge
import com.example.domain.model.WaterwayFacility
import com.example.domain.model.WaterwayNode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class PrimaryTab(val route: String) {
    HOME("home"),
    MAP("map"),
    JOURNEY("journey"),
    LOCKS("locks"),
    EXPLORE("explore"),
    PROFILE("profile")
}

data class WaterwaysUiState(
    val selectedWaterway: Waterway,
    val selectedLockId: String? = null,
    val selectedMapNodeId: String? = null,
    val isOfflineSimulated: Boolean = false,
    val statusBannerMessage: String? = null,
    val routeStartId: String = "gu_braunston_jct",
    val routeEndId: String = "gu_gas_street",
    val routeViaId: String? = null,
    val avoidTunnels: Boolean = false,
    val avoidLowBridges: Boolean = false,
    val avoidClosedSegments: Boolean = true,
    val routeResult: RouteCalculationResult? = null,
    val noticeFilterSeverity: NoticeSeverity? = null,
    val noticeFilterSavedRouteOnly: Boolean = false,
    val noticeFilterWaterwayId: String? = null
)

class WaterwaysViewModel(application: Application) : AndroidViewModel(application) {

    val repository = WaterwaysRepository(application)

    val waterways: List<Waterway> = repository.waterways
    val allNodes: List<WaterwayNode> = repository.nodes
    val allEdges: List<WaterwayEdge> = repository.edges
    val allNotices: List<NavigationNotice> = repository.notices
    val allMoorings: List<Mooring> = repository.moorings
    val allFacilities: List<WaterwayFacility> = repository.facilities

    private val _uiState = MutableStateFlow(
        WaterwaysUiState(
            selectedWaterway = waterways.first(),
            selectedLockId = allNodes.firstOrNull { it.type == NodeType.LOCK }?.id
        )
    )
    val uiState: StateFlow<WaterwaysUiState> = _uiState.asStateFlow()

    val preferences: StateFlow<UserPreferences> = repository.preferences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    val vesselProfile: StateFlow<VesselProfile> = repository.vesselProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VesselProfile())

    val savedRoutes: StateFlow<List<PlannedRoute>> = repository.savedRoutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val offlineRegions: StateFlow<List<OfflineRegion>> = repository.offlineRegions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val checkInHistory: StateFlow<List<CheckInHistoryEntity>> = repository.checkInHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedPlaces: StateFlow<List<SavedPlaceEntity>> = repository.savedPlaces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val communityReports: StateFlow<List<CommunityReport>> = repository.communityReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeJourney: StateFlow<ActiveJourney?> = repository.activeJourney
    val activeCheckIn: StateFlow<LockCheckIn?> = repository.activeCheckIn
    val activeQueue: StateFlow<LockQueueState?> = repository.activeQueue
    val activeServiceStatus: StateFlow<LockServiceStatus?> = repository.activeServiceStatus

    val filteredNotices: StateFlow<List<NavigationNotice>> = combine(
        _uiState,
        activeJourney
    ) { state, journey ->
        allNotices.filter { notice ->
            val matchesWaterway = state.noticeFilterWaterwayId == null || notice.waterwayId == state.noticeFilterWaterwayId
            val matchesSeverity = state.noticeFilterSeverity == null || notice.severity == state.noticeFilterSeverity
            val matchesRoute = !state.noticeFilterSavedRouteOnly ||
                (journey != null && journey.route.waterwayIds.contains(notice.waterwayId))
            matchesWaterway && matchesSeverity && matchesRoute
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), allNotices)

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
            planCurrentRoute()
        }
    }

    fun selectWaterway(waterway: Waterway) {
        val nodesOnWaterway = allNodes.filter { it.waterwayId == waterway.id }
        val firstLock = nodesOnWaterway.firstOrNull { it.type == NodeType.LOCK }
        val startNode = nodesOnWaterway.firstOrNull() ?: allNodes.first()
        val endNode = nodesOnWaterway.lastOrNull() ?: allNodes.last()
        _uiState.update {
            it.copy(
                selectedWaterway = waterway,
                selectedLockId = firstLock?.id ?: it.selectedLockId,
                routeStartId = startNode.id,
                routeEndId = if (endNode.id != startNode.id) endNode.id else it.routeEndId,
                routeViaId = null
            )
        }
        planCurrentRoute()
    }

    fun selectLock(lockId: String) {
        _uiState.update { it.copy(selectedLockId = lockId) }
    }

    fun selectMapNode(nodeId: String?) {
        _uiState.update { it.copy(selectedMapNodeId = nodeId) }
    }

    fun setRouteEndpoints(startId: String? = null, endId: String? = null, viaId: String? = _uiState.value.routeViaId) {
        _uiState.update {
            it.copy(
                routeStartId = startId ?: it.routeStartId,
                routeEndId = endId ?: it.routeEndId,
                routeViaId = viaId
            )
        }
        planCurrentRoute()
    }

    fun setRouteAvoidances(avoidTunnels: Boolean, avoidLowBridges: Boolean, avoidClosed: Boolean) {
        _uiState.update {
            it.copy(
                avoidTunnels = avoidTunnels,
                avoidLowBridges = avoidLowBridges,
                avoidClosedSegments = avoidClosed
            )
        }
        planCurrentRoute()
    }

    fun planCurrentRoute() {
        val state = _uiState.value
        val vessel = vesselProfile.value
        val prefs = preferences.value
        val result = repository.calculateRoute(
            RoutePlanRequest(
                startNodeId = state.routeStartId,
                destinationNodeId = state.routeEndId,
                viaNodeId = state.routeViaId,
                vessel = vessel,
                dailyCruisingHours = prefs.dailyCruisingHours,
                avoidTunnels = state.avoidTunnels,
                avoidLowBridges = state.avoidLowBridges,
                avoidClosedSegments = state.avoidClosedSegments
            )
        )
        _uiState.update { it.copy(routeResult = result) }
    }

    fun savePlannedRouteOffline(route: PlannedRoute) {
        viewModelScope.launch {
            val saved = repository.saveRouteOffline(route)
            _uiState.update {
                it.copy(
                    routeResult = RouteCalculationResult.Success(saved),
                    statusBannerMessage = "Route saved offline: ${saved.name}"
                )
            }
        }
    }

    fun deleteSavedRoute(id: String) {
        viewModelScope.launch {
            repository.deleteSavedRoute(id)
        }
    }

    fun startJourney(route: PlannedRoute) {
        repository.startJourney(route)
        _uiState.update { it.copy(statusBannerMessage = "Journey started: ${route.name}") }
    }

    fun advanceJourneyWaypoint() {
        repository.advanceJourneyWaypoint()
    }

    fun stopJourney() {
        repository.stopJourney()
    }

    fun registerLockArrival(
        lock: WaterwayNode,
        direction: TravelDirection,
        method: CheckInMethod
    ) {
        viewModelScope.launch {
            val key = "${lock.id}_${direction.name}_${UUID.randomUUID().toString().take(6)}"
            val result = repository.registerLockCheckIn(
                lock = lock,
                vesselName = vesselProfile.value.name,
                direction = direction,
                method = method,
                idempotencyKey = key
            )
            result.onSuccess {
                _uiState.update {
                    it.copy(statusBannerMessage = "Simulated arrival registered at ${lock.name}")
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(statusBannerMessage = err.message ?: "Check-in unavailable")
                }
            }
        }
    }

    fun submitLockOsServiceRequest(lock: WaterwayNode) {
        repository.submitLockOsServiceRequest(lock)
        _uiState.update {
            it.copy(statusBannerMessage = "LOCK.OS request submitted (awaiting local safety controller).")
        }
    }

    fun advanceSimulatedLockState() {
        repository.advanceSimulatedLockState()
    }

    fun leaveLockQueue() {
        repository.leaveLockQueue()
        _uiState.update { it.copy(statusBannerMessage = "Removed from simulated lock queue.") }
    }

    fun saveVesselProfile(profile: VesselProfile) {
        viewModelScope.launch {
            repository.saveVesselProfile(profile)
            planCurrentRoute()
            _uiState.update { it.copy(statusBannerMessage = "Vessel dimensions updated & route re-validated.") }
        }
    }

    fun toggleOfflineRegion(region: OfflineRegion) {
        viewModelScope.launch {
            repository.toggleOfflineRegion(region)
        }
    }

    fun toggleOfflineModeSimulation() {
        _uiState.update { it.copy(isOfflineSimulated = !it.isOfflineSimulated) }
    }

    fun toggleSavedPlace(id: String, name: String, category: String, waterwayName: String) {
        viewModelScope.launch {
            val exists = savedPlaces.value.any { it.id == id }
            repository.toggleSavedPlace(id, name, category, waterwayName, exists)
        }
    }

    fun addCommunityReport(
        waterwayId: String,
        targetName: String,
        type: CommunityReportType,
        authorAlias: String,
        comment: String
    ) {
        viewModelScope.launch {
            val result = repository.addCommunityReport(waterwayId, targetName, type, authorAlias, comment)
            result.onSuccess {
                _uiState.update { it.copy(statusBannerMessage = "Community note posted (marked unverified).") }
            }.onFailure { err ->
                _uiState.update { it.copy(statusBannerMessage = err.message) }
            }
        }
    }

    fun updateNoticeFilters(
        waterwayId: String? = _uiState.value.noticeFilterWaterwayId,
        severity: NoticeSeverity? = _uiState.value.noticeFilterSeverity,
        savedRouteOnly: Boolean = _uiState.value.noticeFilterSavedRouteOnly
    ) {
        _uiState.update {
            it.copy(
                noticeFilterWaterwayId = waterwayId,
                noticeFilterSeverity = severity,
                noticeFilterSavedRouteOnly = savedRouteOnly
            )
        }
    }

    fun updatePreferences(transform: (UserPreferences) -> UserPreferences) {
        viewModelScope.launch {
            repository.updatePreferences(transform)
            planCurrentRoute()
        }
    }

    fun deleteLocalAccountData() {
        viewModelScope.launch {
            repository.deleteLocalAccountData()
            _uiState.update { it.copy(statusBannerMessage = "Local account data cleared.") }
        }
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }
}
