package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "vessel_profiles")
data class VesselEntity(
    @PrimaryKey val id: String,
    val name: String,
    val boatType: String,
    val lengthFt: Double,
    val beamFt: Double,
    val draughtFt: Double,
    val airDraughtFt: Double,
    val homeMooring: String,
    val preferredSpeedMph: Double,
    val accessibilityNeeds: String,
    val isPrivateByDefault: Boolean
)

@Entity(tableName = "saved_routes")
data class SavedRouteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val startNodeId: String,
    val destinationNodeId: String,
    val viaNodeId: String?,
    val routeJson: String,
    val totalDistanceKm: Double,
    val lockCount: Int,
    val totalMinutes: Int,
    val savedAtIso: String
)

@Entity(tableName = "check_in_history")
data class CheckInHistoryEntity(
    @PrimaryKey val id: String,
    val lockId: String,
    val lockName: String,
    val vesselName: String,
    val direction: String,
    val method: String,
    val idempotencyKey: String,
    val checkedInAtIso: String,
    val statusSummary: String
)

@Entity(tableName = "offline_regions")
data class OfflineRegionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val waterwayIdsCsv: String,
    val sizeMb: Double,
    val lockCount: Int,
    val isDownloaded: Boolean,
    val lastSyncedIso: String,
    val isStale: Boolean
)

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val waterwayName: String,
    val savedAtIso: String
)

@Entity(tableName = "community_reports")
data class CommunityReportEntity(
    @PrimaryKey val id: String,
    val waterwayId: String,
    val targetName: String,
    val type: String,
    val authorAlias: String,
    val comment: String,
    val timestampIso: String
)

@Dao
interface WaterwaysDao {
    @Query("SELECT * FROM vessel_profiles LIMIT 1")
    fun observeVessel(): Flow<VesselEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveVessel(vessel: VesselEntity)

    @Query("SELECT * FROM saved_routes ORDER BY savedAtIso DESC")
    fun observeSavedRoutes(): Flow<List<SavedRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveRoute(route: SavedRouteEntity)

    @Query("DELETE FROM saved_routes WHERE id = :id")
    suspend fun deleteSavedRoute(id: String)

    @Query("SELECT * FROM check_in_history ORDER BY checkedInAtIso DESC")
    fun observeCheckIns(): Flow<List<CheckInHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheckIn(entry: CheckInHistoryEntity)

    @Query("SELECT * FROM offline_regions")
    fun observeOfflineRegions(): Flow<List<OfflineRegionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOfflineRegions(regions: List<OfflineRegionEntity>)

    @Query("SELECT * FROM saved_places ORDER BY savedAtIso DESC")
    fun observeSavedPlaces(): Flow<List<SavedPlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlace(place: SavedPlaceEntity)

    @Query("DELETE FROM saved_places WHERE id = :id")
    suspend fun deleteSavedPlace(id: String)

    @Query("SELECT * FROM community_reports ORDER BY timestampIso DESC")
    fun observeCommunityReports(): Flow<List<CommunityReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommunityReport(report: CommunityReportEntity)

    @Query("DELETE FROM saved_routes")
    suspend fun clearAllSavedRoutes()

    @Query("DELETE FROM check_in_history")
    suspend fun clearAllCheckIns()

    @Query("DELETE FROM saved_places")
    suspend fun clearAllSavedPlaces()
}

@Database(
    entities = [
        VesselEntity::class,
        SavedRouteEntity::class,
        CheckInHistoryEntity::class,
        OfflineRegionEntity::class,
        SavedPlaceEntity::class,
        CommunityReportEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class WaterwaysDatabase : RoomDatabase() {
    abstract fun waterwaysDao(): WaterwaysDao

    companion object {
        @Volatile
        private var INSTANCE: WaterwaysDatabase? = null

        fun getInstance(context: Context): WaterwaysDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    WaterwaysDatabase::class.java,
                    "waterways_os_local.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build().also { INSTANCE = it }
            }
        }
    }
}
