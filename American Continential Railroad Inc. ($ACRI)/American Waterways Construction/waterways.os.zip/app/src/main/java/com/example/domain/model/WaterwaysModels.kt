package com.example.domain.model

import kotlin.math.roundToInt

enum class WaterwayGaugeType(val label: String) {
    NARROW("Narrow Canal (7 ft max beam)"),
    BROAD("Broad Canal (14 ft max beam)"),
    RIVER("Navigable River")
}

enum class NodeType(val label: String) {
    LOCK("Lock"),
    BRIDGE("Bridge"),
    TUNNEL("Tunnel"),
    AQUEDUCT("Aqueduct"),
    JUNCTION("Junction"),
    BASIN("Canal Basin"),
    MARINA("Marina")
}

enum class LockOperationalStatus(val label: String) {
    OPEN("Operational (Demo)"),
    RESTRICTED("Restricted Hours"),
    MAINTENANCE("Maintenance Notice"),
    CLOSED("Closed / Stoppage")
}

enum class TravelDirection(val label: String) {
    ASCENDING("Ascending (Upstream / Uphill)"),
    DESCENDING("Descending (Downstream / Downhill)")
}

enum class CheckInMethod(val label: String) {
    MANUAL("Manual Registration"),
    QR_CODE("QR Post Scan (Demo)"),
    GEOFENCE("Geofenced Approach")
}

/**
 * Strictly separates remote service request lifecycle from physical actuator states.
 * Never exposes "GATE OPEN" solely from server acceptance.
 */
enum class LockServiceState(val title: String, val description: String) {
    IDLE("Ready for Request", "No active LOCK.OS service request submitted."),
    REQUEST_SUBMITTED("Request Submitted", "Service request logged by LOCK.OS gateway. Awaiting acknowledgement."),
    REQUEST_ACCEPTED("Request Accepted", "LOCK.OS queued the request. Local safety controller has NOT yet authorised movement."),
    WAITING_LOCAL_AUTHORISATION("Waiting for Local Authorisation", "Independent local safety controller is verifying chamber sensors and visual clearance."),
    SERVICE_IN_PROGRESS("Service in Progress", "Authorised lock cycle is underway under local safety controller supervision."),
    SERVICE_COMPLETE("Service Complete", "Lock cycle completed. Observe local signals before entering chamber."),
    SERVICE_UNAVAILABLE("Service Unavailable", "Automated LOCK.OS service unavailable at this site. Operate manually if permitted.")
}

enum class NoticeType(val label: String) {
    PLANNED_CLOSURE("Planned Closure"),
    EMERGENCY_STOPPAGE("Emergency Stoppage"),
    RESTRICTED_NAVIGATION("Restricted Navigation"),
    LOW_WATER("Low Water Levels"),
    LOCK_MAINTENANCE("Lock Maintenance"),
    BRIDGE_RESTRICTION("Bridge Restriction"),
    WARNING("Navigation Warning")
}

enum class NoticeSeverity(val label: String) {
    CRITICAL("Critical"),
    HIGH("High"),
    MODERATE("Moderate"),
    ADVISORY("Advisory")
}

enum class MooringType(val label: String) {
    VISITOR("Visitor Mooring"),
    OVERNIGHT("Overnight Mooring"),
    LONG_STAY("Long-Stay Mooring"),
    MARINA("Marina"),
    SERVICE("Service Mooring"),
    ACCESSIBLE("Accessible Mooring")
}

enum class MooringAvailabilityStatus(val label: String) {
    UNCONFIRMED("Spaces unconfirmed (no live sensor)"),
    PROVIDER_CONFIRMED_AVAILABLE("Provider confirmed spaces"),
    PROVIDER_FULL("Provider reported full")
}

enum class FacilityCategory(val label: String) {
    DRINKING_WATER("Drinking Water"),
    WASTE_DISPOSAL("Waste Disposal"),
    ELSAN("Elsan Disposal"),
    PUMP_OUT("Pump-Out"),
    FUEL("Fuel & Diesel"),
    ELECTRICITY("Shore Power"),
    SHOWERS("Showers"),
    TOILETS("Toilets"),
    CHANDLER("Chandlers"),
    BOAT_REPAIRS("Boat Repairs"),
    GROCERY("Grocery Shops"),
    CAFE_PUB("Cafés & Pubs")
}

enum class BoatType(val label: String) {
    NARROWBOAT("Narrowboat"),
    WIDEBEAM("Widebeam"),
    CRUISER("Motor Cruiser"),
    HERITAGE("Heritage Boat")
}

enum class CommunityReportType(val label: String) {
    FACILITY_UPDATE("Facility Update"),
    MOORING_REVIEW("Mooring Review"),
    NAVIGATION_TIP("Navigation Tip"),
    ISSUE_REPORT("Reported Issue")
}

data class DataSourceMeta(
    val sourceName: String,
    val lastUpdatedIso: String,
    val isSimulated: Boolean,
    val licenceNote: String
)

data class Waterway(
    val id: String,
    val name: String,
    val welshName: String,
    val region: String,
    val lengthKm: Double,
    val lockCount: Int,
    val gaugeType: WaterwayGaugeType,
    val maxLengthFt: Double,
    val maxBeamFt: Double,
    val maxDraughtFt: Double,
    val maxAirDraughtFt: Double,
    val description: String,
    val nearestAccessPoint: String,
    val meta: DataSourceMeta
)

data class WaterwayNode(
    val id: String,
    val waterwayId: String,
    val name: String,
    val type: NodeType,
    val lat: Double,
    val lon: Double,
    val distanceAlongKm: Double,
    val lockNumber: String? = null,
    val chamberLengthFt: Double? = null,
    val chamberWidthFt: Double? = null,
    val riseFallFt: Double? = null,
    val bridgeHeadroomFt: Double? = null,
    val tunnelLengthYards: Int? = null,
    val restrictionsNote: String = "Standard navigation rules apply.",
    val accessibilityNotes: String = "Towpath access; uneven cobbles near lock tail.",
    val isLockOsEnabled: Boolean = false,
    val automationAvailable: Boolean = false,
    val queueAvailable: Boolean = false,
    val checkInSupported: Boolean = false,
    val operationalStatus: LockOperationalStatus = LockOperationalStatus.OPEN,
    val dimensionUncertainty: Boolean = false,
    val meta: DataSourceMeta
)

data class WaterwayEdge(
    val id: String,
    val fromNodeId: String,
    val toNodeId: String,
    val waterwayId: String,
    val distanceKm: Double,
    val lockCount: Int,
    val maxLengthFt: Double,
    val maxBeamFt: Double,
    val maxDraughtFt: Double,
    val maxAirDraughtFt: Double,
    val isClosed: Boolean = false,
    val closureReason: String? = null,
    val verifiedNavigable: Boolean = true,
    val hasTunnel: Boolean = false,
    val hasLowBridge: Boolean = false
)

data class VesselProfile(
    val id: String = "default_vessel",
    val name: String = "NB Kingfisher",
    val boatType: BoatType = BoatType.NARROWBOAT,
    val lengthFt: Double = 57.0,
    val beamFt: Double = 6.83,
    val draughtFt: Double = 2.2,
    val airDraughtFt: Double = 6.2,
    val homeMooring: String = "Braunston Basin (Demo)",
    val preferredSpeedMph: Double = 3.2,
    val accessibilityNeeds: String = "Step-free landing preferred",
    val isPrivateByDefault: Boolean = true
)

data class NavigationNotice(
    val id: String,
    val waterwayId: String,
    val waterwayName: String,
    val region: String,
    val title: String,
    val summary: String,
    val type: NoticeType,
    val severity: NoticeSeverity,
    val affectedNodeId: String? = null,
    val startDateIso: String,
    val endDateIso: String,
    val meta: DataSourceMeta
)

data class Mooring(
    val id: String,
    val waterwayId: String,
    val name: String,
    val type: MooringType,
    val lat: Double,
    val lon: Double,
    val maxStayHours: Int,
    val feesSummary: String,
    val facilities: List<String>,
    val restrictions: String,
    val accessibilityNotes: String,
    val nearbyServices: String,
    val availabilityStatus: MooringAvailabilityStatus,
    val meta: DataSourceMeta
)

data class WaterwayFacility(
    val id: String,
    val waterwayId: String,
    val name: String,
    val category: FacilityCategory,
    val lat: Double,
    val lon: Double,
    val directionsNote: String,
    val accessInfo: String,
    val meta: DataSourceMeta
)

data class RoutePlanRequest(
    val startNodeId: String,
    val destinationNodeId: String,
    val viaNodeId: String? = null,
    val vessel: VesselProfile,
    val dailyCruisingHours: Double = 5.0,
    val avoidTunnels: Boolean = false,
    val avoidLowBridges: Boolean = false,
    val avoidClosedSegments: Boolean = true
)

data class RouteLeg(
    val edgeId: String,
    val fromNode: WaterwayNode,
    val toNode: WaterwayNode,
    val waterwayId: String,
    val distanceKm: Double,
    val lockCount: Int,
    val cruisingMinutes: Int,
    val lockMinutes: Int,
    val warnings: List<String>
)

data class DailyItineraryDay(
    val dayNumber: Int,
    val startLabel: String,
    val endLabel: String,
    val cruisingHours: Double,
    val lockCount: Int,
    val distanceKm: Double,
    val overnightSuggestion: String
)

data class PlannedRoute(
    val id: String,
    val name: String,
    val waterwayIds: List<String>,
    val startNode: WaterwayNode,
    val destinationNode: WaterwayNode,
    val viaNode: WaterwayNode? = null,
    val legs: List<RouteLeg>,
    val orderedNodes: List<WaterwayNode>,
    val totalDistanceKm: Double,
    val lockCount: Int,
    val cruisingMinutes: Int,
    val lockTimeMinutes: Int,
    val totalMinutes: Int,
    val overnightStops: Int,
    val dailyItinerary: List<DailyItineraryDay>,
    val compatibilityWarnings: List<String>,
    val uncertainRestrictions: List<String>,
    val isSavedOffline: Boolean = false,
    val savedAtIso: String? = null
)

sealed interface RouteCalculationResult {
    data class Success(val route: PlannedRoute) : RouteCalculationResult
    data class Incompatible(
        val reason: String,
        val blockingRestrictions: List<String>
    ) : RouteCalculationResult
}

data class ActiveJourney(
    val route: PlannedRoute,
    val currentNodeIndex: Int = 0,
    val isActive: Boolean = false,
    val startedAtIso: String = ""
) {
    val currentNode: WaterwayNode get() = route.orderedNodes.getOrElse(currentNodeIndex) { route.startNode }
    val progressFraction: Float
        get() = if (route.orderedNodes.size <= 1) 1f
        else (currentNodeIndex.toFloat() / (route.orderedNodes.size - 1).toFloat()).coerceIn(0f, 1f)

    val remainingNodes: List<WaterwayNode>
        get() = if (currentNodeIndex + 1 < route.orderedNodes.size) {
            route.orderedNodes.subList(currentNodeIndex + 1, route.orderedNodes.size)
        } else emptyList()

    val nextLock: WaterwayNode?
        get() = remainingNodes.firstOrNull { it.type == NodeType.LOCK }

    val nextBridge: WaterwayNode?
        get() = remainingNodes.firstOrNull { it.type == NodeType.BRIDGE }

    val nextJunction: WaterwayNode?
        get() = remainingNodes.firstOrNull { it.type == NodeType.JUNCTION }

    val remainingDistanceKm: Double
        get() = route.legs.drop(currentNodeIndex).sumOf { it.distanceKm }

    val remainingMinutes: Int
        get() = route.legs.drop(currentNodeIndex).sumOf { it.cruisingMinutes + it.lockMinutes }
}

data class LockCheckIn(
    val id: String,
    val lockId: String,
    val lockName: String,
    val vesselName: String,
    val direction: TravelDirection,
    val method: CheckInMethod,
    val idempotencyKey: String,
    val checkedInAtIso: String,
    val isSimulated: Boolean = true
)

data class LockQueueState(
    val lockId: String,
    val lockName: String,
    val checkInId: String,
    val queuePosition: Int,
    val vesselsAhead: Int,
    val direction: TravelDirection,
    val estimatedWaitMinutes: Int,
    val queueStatus: String,
    val lockAvailability: String,
    val isSimulated: Boolean = true,
    val lastUpdatedIso: String
)

data class LockServiceStatus(
    val lockId: String,
    val state: LockServiceState,
    val statusDetail: String,
    val localControllerNotice: String,
    val isSimulated: Boolean = true,
    val updatedAtIso: String
)

data class CommunityReport(
    val id: String,
    val waterwayId: String,
    val targetName: String,
    val type: CommunityReportType,
    val authorAlias: String,
    val comment: String,
    val timestampIso: String,
    val isModeratedOk: Boolean = true,
    val isVerifiedOfficial: Boolean = false
)

data class OfflineRegion(
    val id: String,
    val name: String,
    val waterwayIds: List<String>,
    val sizeMb: Double,
    val lockCount: Int,
    val isDownloaded: Boolean,
    val lastSyncedIso: String,
    val isStale: Boolean
)

data class UserPreferences(
    val darkMode: Boolean = false,
    val largeText: Boolean = false,
    val useImperialUnits: Boolean = true,
    val languageCode: String = "en",
    val dailyCruisingHours: Double = 5.0,
    val notifyApproachingLock: Boolean = true,
    val notifyJunction: Boolean = true,
    val notifyClosure: Boolean = true,
    val notifyLowBridge: Boolean = true,
    val notifyOvernightStop: Boolean = true,
    val isSignedIn: Boolean = false,
    val accountEmail: String = "Guest Boater"
)

object UnitFormatter {
    fun formatDistance(km: Double, imperial: Boolean): String {
        return if (imperial) {
            val miles = km * 0.621371
            "%.1f mi".format(miles)
        } else {
            "%.1f km".format(km)
        }
    }

    fun formatDimension(feet: Double, imperial: Boolean): String {
        return if (imperial) {
            val wholeFt = feet.toInt()
            val inches = ((feet - wholeFt) * 12.0).roundToInt()
            if (inches == 12) "${wholeFt + 1}ft 0in" else "${wholeFt}ft ${inches}in"
        } else {
            val meters = feet * 0.3048
            "%.2f m".format(meters)
        }
    }

    fun formatDuration(minutes: Int): String {
        val hrs = minutes / 60
        val mins = minutes % 60
        return when {
            hrs == 0 -> "${mins}m"
            mins == 0 -> "${hrs}h"
            else -> "${hrs}h ${mins}m"
        }
    }
}
