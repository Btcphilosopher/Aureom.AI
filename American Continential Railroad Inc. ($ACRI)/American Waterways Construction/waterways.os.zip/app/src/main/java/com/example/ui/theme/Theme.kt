package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val WaterwaysLightColorScheme = lightColorScheme(
    primary = CanalNavy,
    onPrimary = Color.White,
    primaryContainer = CanalNavyContainer,
    onPrimaryContainer = CanalNavy,
    secondary = HeritageGreen,
    onSecondary = Color.White,
    secondaryContainer = HeritageGreenContainer,
    onSecondaryContainer = HeritageGreen,
    tertiary = WaterBlue,
    onTertiary = Color.White,
    tertiaryContainer = WaterBlueContainer,
    onTertiaryContainer = CanalNavy,
    background = CreamCanvas,
    onBackground = CanalNavy,
    surface = CreamElevated,
    onSurface = CanalNavy,
    surfaceVariant = StoneGreySurface,
    onSurfaceVariant = StoneGreyText,
    outline = StoneGreyOutline,
    error = StoppageRed,
    onError = Color.White,
    errorContainer = StoppageRedContainer,
    onErrorContainer = StoppageRed
)

private val WaterwaysDarkColorScheme = darkColorScheme(
    primary = WaterBlueBright,
    onPrimary = CanalNavy,
    primaryContainer = CanalNavyLight,
    onPrimaryContainer = DarkCanalText,
    secondary = HeritageGreenBright,
    onSecondary = DarkCanalBackground,
    secondaryContainer = HeritageGreen,
    onSecondaryContainer = DarkCanalText,
    tertiary = SoftAmberBright,
    onTertiary = DarkCanalBackground,
    tertiaryContainer = Color(0xFF4A3010),
    onTertiaryContainer = SoftAmberContainer,
    background = DarkCanalBackground,
    onBackground = DarkCanalText,
    surface = DarkCanalSurface,
    onSurface = DarkCanalText,
    surfaceVariant = DarkCanalSurfaceVariant,
    onSurfaceVariant = DarkStoneText,
    outline = Color(0xFF34526A),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410),
    errorContainer = Color(0xFF8C1D18),
    onErrorContainer = Color(0xFFF9DEDC)
)

val WaterwaysShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun WaterwaysTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    largeText: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) WaterwaysDarkColorScheme else WaterwaysLightColorScheme
    val typography = buildWaterwaysTypography(largeText = largeText)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = WaterwaysShapes,
        content = content
    )
}
