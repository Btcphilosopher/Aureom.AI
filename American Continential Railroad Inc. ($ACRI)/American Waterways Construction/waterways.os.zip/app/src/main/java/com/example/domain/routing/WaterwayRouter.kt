package com.example.domain.routing

import com.example.domain.model.DailyItineraryDay
import com.example.domain.model.LockOperationalStatus
import com.example.domain.model.NodeType
import com.example.domain.model.PlannedRoute
import com.example.domain.model.RouteCalculationResult
import com.example.domain.model.RouteLeg
import com.example.domain.model.RoutePlanRequest
import com.example.domain.model.WaterwayEdge
import com.example.domain.model.WaterwayNode
import java.util.PriorityQueue
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Constrained waterway graph router using Dijkstra shortest-path.
 * Enforces vessel physical dimensions (length, beam, draught, air draught),
 * lock chamber suitability, bridge clearances, and active stoppage closures.
 */
class WaterwayRouter {

    fun planRoute(
        request: RoutePlanRequest,
        nodes: List<WaterwayNode>,
        edges: List<WaterwayEdge>
    ): RouteCalculationResult {
        val nodeMap = nodes.associateBy { it.id }
        val startNode = nodeMap[request.startNodeId]
            ?: return RouteCalculationResult.Incompatible("Start location not found in waterway graph.", emptyList())
        val endNode = nodeMap[request.destinationNodeId]
            ?: return RouteCalculationResult.Incompatible("Destination location not found in waterway graph.", emptyList())

        if (startNode.id == endNode.id) {
            return RouteCalculationResult.Incompatible("Start and destination cannot be the same point.", emptyList())
        }

        val viaNode = request.viaNodeId?.let { nodeMap[it] }

        // Build bidirectional adjacency list (navigable canal segments are two-way unless marked otherwise)
        val adjacency = mutableMapOf<String, MutableList<Pair<String, WaterwayEdge>>>()
        val blockingReasons = mutableListOf<String>()

        for (edge in edges) {
            if (!edge.verifiedNavigable) continue
            val fromNode = nodeMap[edge.fromNodeId] ?: continue
            val toNode = nodeMap[edge.toNodeId] ?: continue

            val edgeIssue = checkEdgeSuitability(edge, fromNode, toNode, request)
            if (edgeIssue != null) {
                blockingReasons.add(edgeIssue)
                continue
            }

            adjacency.getOrPut(edge.fromNodeId) { mutableListOf() }.add(edge.toNodeId to edge)
            adjacency.getOrPut(edge.toNodeId) { mutableListOf() }.add(edge.fromNodeId to edge)
        }

        val pathEdges: List<Pair<String, WaterwayEdge>> = if (viaNode != null && viaNode.id != startNode.id && viaNode.id != endNode.id) {
            val leg1 = dijkstra(startNode.id, viaNode.id, adjacency)
            val leg2 = dijkstra(viaNode.id, endNode.id, adjacency)
            if (leg1 == null || leg2 == null) {
                return RouteCalculationResult.Incompatible(
                    reason = "No compatible navigable route found via ${viaNode.name} for ${request.vessel.name}.",
                    blockingRestrictions = blockingReasons.distinct().ifEmpty {
                        listOf("No verified navigable waterway connection between selected points.")
                    }
                )
            }
            leg1 + leg2
        } else {
            val direct = dijkstra(startNode.id, endNode.id, adjacency)
            if (direct == null) {
                return RouteCalculationResult.Incompatible(
                    reason = "No compatible navigable route found for ${request.vessel.name} (${request.vessel.lengthFt}ft × ${request.vessel.beamFt}ft).",
                    blockingRestrictions = blockingReasons.distinct().ifEmpty {
                        listOf("No verified navigable waterway connection between ${startNode.name} and ${endNode.name}.")
                    }
                )
            }
            direct
        }

        val routeLegs = mutableListOf<RouteLeg>()
        val orderedNodes = mutableListOf(startNode)
        val compatibilityWarnings = mutableListOf<String>()
        val uncertainRestrictions = mutableListOf<String>()

        var currentId = startNode.id
        val speedKmh = (request.vessel.preferredSpeedMph * 1.60934).coerceAtLeast(2.0)

        for ((nextId, edge) in pathEdges) {
            val from = nodeMap.getValue(currentId)
            val to = nodeMap.getValue(nextId)
            orderedNodes.add(to)

            val legWarnings = mutableListOf<String>()
            if (to.dimensionUncertainty || from.dimensionUncertainty) {
                val msg = "${to.name}: Published dimensions carry uncertainty — verify locally before proceeding."
                uncertainRestrictions.add(msg)
                legWarnings.add(msg)
            }
            if (to.operationalStatus == LockOperationalStatus.RESTRICTED) {
                val msg = "${to.name}: ${to.restrictionsNote}"
                compatibilityWarnings.add(msg)
                legWarnings.add(msg)
            }
            if (to.bridgeHeadroomFt != null && (to.bridgeHeadroomFt - request.vessel.airDraughtFt) < 1.2) {
                val margin = "%.1f".format(to.bridgeHeadroomFt - request.vessel.airDraughtFt)
                val msg = "Tight air clearance at ${to.name} (${margin}ft margin)."
                compatibilityWarnings.add(msg)
                legWarnings.add(msg)
            }
            if (edge.isClosed) {
                val msg = "Closed segment on ${edge.closureReason ?: "stoppage"} (included because closure avoidance was disabled)."
                compatibilityWarnings.add(msg)
                legWarnings.add(msg)
            }

            val cruiseMins = ((edge.distanceKm / speedKmh) * 60.0).roundToInt().coerceAtLeast(3)
            val lockMins = edge.lockCount * 15 // 15 minutes average per lock passage

            routeLegs.add(
                RouteLeg(
                    edgeId = edge.id,
                    fromNode = from,
                    toNode = to,
                    waterwayId = edge.waterwayId,
                    distanceKm = edge.distanceKm,
                    lockCount = edge.lockCount,
                    cruisingMinutes = cruiseMins,
                    lockMinutes = lockMins,
                    warnings = legWarnings
                )
            )
            currentId = nextId
        }

        val totalDistance = routeLegs.sumOf { it.distanceKm }
        val totalLocks = routeLegs.sumOf { it.lockCount }
        val cruisingMins = routeLegs.sumOf { it.cruisingMinutes }
        val lockMins = routeLegs.sumOf { it.lockMinutes }
        val totalMins = cruisingMins + lockMins

        val itinerary = buildDailyItinerary(
            legs = routeLegs,
            dailyHoursLimit = request.dailyCruisingHours.coerceIn(1.0, 12.0)
        )

        val plannedRoute = PlannedRoute(
            id = "route_${UUID.randomUUID().toString().take(8)}",
            name = "${startNode.name} → ${endNode.name}",
            waterwayIds = routeLegs.map { it.waterwayId }.distinct(),
            startNode = startNode,
            destinationNode = endNode,
            viaNode = viaNode,
            legs = routeLegs,
            orderedNodes = orderedNodes,
            totalDistanceKm = totalDistance,
            lockCount = totalLocks,
            cruisingMinutes = cruisingMins,
            lockTimeMinutes = lockMins,
            totalMinutes = totalMins,
            overnightStops = (itinerary.size - 1).coerceAtLeast(0),
            dailyItinerary = itinerary,
            compatibilityWarnings = compatibilityWarnings.distinct(),
            uncertainRestrictions = uncertainRestrictions.distinct(),
            isSavedOffline = false
        )

        return RouteCalculationResult.Success(plannedRoute)
    }

    private fun checkEdgeSuitability(
        edge: WaterwayEdge,
        fromNode: WaterwayNode,
        toNode: WaterwayNode,
        request: RoutePlanRequest
    ): String? {
        val vessel = request.vessel
        if (request.avoidClosedSegments && edge.isClosed) {
            return "Closure on ${fromNode.name}–${toNode.name}: ${edge.closureReason ?: "Active stoppage"}"
        }
        if (request.avoidClosedSegments &&
            (fromNode.operationalStatus == LockOperationalStatus.CLOSED || toNode.operationalStatus == LockOperationalStatus.CLOSED)
        ) {
            val closedName = if (fromNode.operationalStatus == LockOperationalStatus.CLOSED) fromNode.name else toNode.name
            return "$closedName is closed due to an active stoppage."
        }
        if (request.avoidTunnels && (edge.hasTunnel || fromNode.type == NodeType.TUNNEL || toNode.type == NodeType.TUNNEL)) {
            return "Tunnel avoided by route preferences (${fromNode.name}–${toNode.name})."
        }
        if (request.avoidLowBridges && (edge.hasLowBridge || fromNode.type == NodeType.BRIDGE || toNode.type == NodeType.BRIDGE)) {
            val minHeadroom = listOfNotNull(fromNode.bridgeHeadroomFt, toNode.bridgeHeadroomFt).minOrNull()
            if (minHeadroom != null && minHeadroom < vessel.airDraughtFt + 1.5) {
                return "Low bridge avoided near ${toNode.name} (${minHeadroom}ft headroom)."
            }
        }
        if (vessel.lengthFt > edge.maxLengthFt) {
            return "Vessel length (${vessel.lengthFt}ft) exceeds limit (${edge.maxLengthFt}ft) between ${fromNode.name} and ${toNode.name}."
        }
        if (vessel.beamFt > edge.maxBeamFt) {
            return "Vessel beam (${vessel.beamFt}ft) exceeds limit (${edge.maxBeamFt}ft) between ${fromNode.name} and ${toNode.name}."
        }
        if (vessel.draughtFt > edge.maxDraughtFt) {
            return "Vessel draught (${vessel.draughtFt}ft) exceeds channel depth (${edge.maxDraughtFt}ft) between ${fromNode.name} and ${toNode.name}."
        }
        if (vessel.airDraughtFt > edge.maxAirDraughtFt) {
            return "Vessel air draught (${vessel.airDraughtFt}ft) exceeds bridge/tunnel clearance (${edge.maxAirDraughtFt}ft)."
        }

        // Also validate individual lock chamber dimensions on endpoint nodes
        listOf(fromNode, toNode).forEach { node ->
            if (node.type == NodeType.LOCK) {
                if (node.chamberLengthFt != null && vessel.lengthFt > node.chamberLengthFt) {
                    return "${node.name} chamber length (${node.chamberLengthFt}ft) is too short for ${vessel.name} (${vessel.lengthFt}ft)."
                }
                if (node.chamberWidthFt != null && vessel.beamFt > node.chamberWidthFt) {
                    return "${node.name} chamber width (${node.chamberWidthFt}ft) is too narrow for ${vessel.name} (${vessel.beamFt}ft)."
                }
            }
            if (node.bridgeHeadroomFt != null && vessel.airDraughtFt > node.bridgeHeadroomFt) {
                return "${node.name} headroom (${node.bridgeHeadroomFt}ft) is lower than vessel air draught (${vessel.airDraughtFt}ft)."
            }
        }

        return null
    }

    private fun dijkstra(
        startId: String,
        targetId: String,
        adjacency: Map<String, List<Pair<String, WaterwayEdge>>>
    ): List<Pair<String, WaterwayEdge>>? {
        data class State(val nodeId: String, val costMinutes: Double)

        val dist = mutableMapOf(startId to 0.0)
        val prev = mutableMapOf<String, Pair<String, WaterwayEdge>>()
        val queue = PriorityQueue<State>(compareBy { it.costMinutes })
        queue.add(State(startId, 0.0))

        while (queue.isNotEmpty()) {
            val current = queue.poll() ?: break
            if (current.nodeId == targetId) break
            if (current.costMinutes > (dist[current.nodeId] ?: Double.MAX_VALUE)) continue

            for ((neighborId, edge) in adjacency[current.nodeId].orEmpty()) {
                val edgeWeight = (edge.distanceKm * 12.0) + (edge.lockCount * 15.0) + if (edge.isClosed) 1000.0 else 0.0
                val newCost = current.costMinutes + edgeWeight
                if (newCost < (dist[neighborId] ?: Double.MAX_VALUE)) {
                    dist[neighborId] = newCost
                    prev[neighborId] = current.nodeId to edge
                    queue.add(State(neighborId, newCost))
                }
            }
        }

        if (startId != targetId && !prev.containsKey(targetId)) return null

        val path = mutableListOf<Pair<String, WaterwayEdge>>()
        var cursor = targetId
        while (cursor != startId) {
            val step = prev[cursor] ?: return null
            path.add(cursor to step.second)
            cursor = step.first
        }
        return path.reversed()
    }

    private fun buildDailyItinerary(
        legs: List<RouteLeg>,
        dailyHoursLimit: Double
    ): List<DailyItineraryDay> {
        if (legs.isEmpty()) return emptyList()
        val dailyMinutesLimit = (dailyHoursLimit * 60.0).roundToInt().coerceAtLeast(60)
        val days = mutableListOf<DailyItineraryDay>()

        var dayNumber = 1
        var dayStartLabel = legs.first().fromNode.name
        var accMinutes = 0
        var accLocks = 0
        var accDistance = 0.0
        var lastStopNode = legs.first().fromNode

        for ((index, leg) in legs.withIndex()) {
            val legMinutes = leg.cruisingMinutes + leg.lockMinutes
            if (accMinutes > 0 && accMinutes + legMinutes > dailyMinutesLimit) {
                days.add(
                    DailyItineraryDay(
                        dayNumber = dayNumber,
                        startLabel = dayStartLabel,
                        endLabel = lastStopNode.name,
                        cruisingHours = (accMinutes / 60.0),
                        lockCount = accLocks,
                        distanceKm = accDistance,
                        overnightSuggestion = "Visitor / overnight mooring near ${lastStopNode.name} (verify local signage)"
                    )
                )
                dayNumber++
                dayStartLabel = lastStopNode.name
                accMinutes = 0
                accLocks = 0
                accDistance = 0.0
            }

            accMinutes += legMinutes
            accLocks += leg.lockCount
            accDistance += leg.distanceKm
            lastStopNode = leg.toNode

            if (index == legs.lastIndex) {
                days.add(
                    DailyItineraryDay(
                        dayNumber = dayNumber,
                        startLabel = dayStartLabel,
                        endLabel = leg.toNode.name,
                        cruisingHours = (accMinutes / 60.0),
                        lockCount = accLocks,
                        distanceKm = accDistance,
                        overnightSuggestion = "Arrival at ${leg.toNode.name}"
                    )
                )
            }
        }

        return days
    }
}
