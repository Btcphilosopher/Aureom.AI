import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from './services/railway-state.service';
import { EngineeringTab } from './models/railway.models';

import { Viewport3D } from './components/viewport-3d/viewport-3d';
import { AlignmentEditor } from './components/alignment-editor/alignment-editor';
import { CrossSection } from './components/cross-section/cross-section';
import { StationsEditor } from './components/stations-editor/stations-editor';
import { ElectrificationView } from './components/electrification-view/electrification-view';
import { SignallingSim } from './components/signalling-sim/signalling-sim';
import { GanttSchedule } from './components/gantt-schedule/gantt-schedule';
import { BoQEstimator } from './components/boq-estimator/boq-estimator';
import { ClashDetector } from './components/clash-detector/clash-detector';
import { ReportsExport } from './components/reports-export/reports-export';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    Viewport3D,
    AlignmentEditor,
    CrossSection,
    StationsEditor,
    ElectrificationView,
    SignallingSim,
    GanttSchedule,
    BoQEstimator,
    ClashDetector,
    ReportsExport
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly state = inject(RailwayStateService);
  readonly isSidebarCollapsed = signal<boolean>(false);
  readonly showNewProjectModal = signal<boolean>(false);

  toggleSidebar(): void {
    this.isSidebarCollapsed.update((v) => !v);
  }

  setTab(tab: EngineeringTab): void {
    this.state.setTab(tab);
  }

  saveRevision(): void {
    const rev = `Rev 3.4.${Math.floor(Math.random() * 90) + 10}`;
    this.state.project.update((p) => ({
      ...p,
      engineeringVersion: rev,
      lastUpdated: new Date().toISOString().slice(0, 10)
    }));
  }
}
