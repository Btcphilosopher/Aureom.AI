import { Injectable } from '@angular/core';
import { AlignmentPoint, ClashDetectionResult } from '../models/railway.models';

export interface InterpolatedTrackPoint {
  chainage: number;
  x: number;
  y: number; // Elevation
  z: number;
  tangentX: number;
  tangentY: number;
  tangentZ: number;
  normalX: number;
  normalZ: number;
  gradePercent: number;
  cantMm: number;
}

@Injectable({
  providedIn: 'root'
})
export class GeometryCalcService {

  /**
   * Calculates equilibrium railway cant (superelevation in mm)
   * Formula: Cant (mm) = 11.8 * V^2 / R (where V is km/h, R is curve radius in meters)
   * Maximum allowed deficiency in standard European/Israel railway practice is typically ~130-150mm.
   */
  calculateCant(speedKmh: number, radiusM: number): number {
    if (radiusM <= 0 || !isFinite(radiusM)) return 0;
    const theoreticalCant = (11.8 * (speedKmh * speedKmh)) / radiusM;
    // Standard railway cant is capped at 160mm in ballasted track
    return Math.min(160, Math.round(theoreticalCant));
  }

  /**
   * Interpolate 3D position and orientation along the railway alignment at any chainage (meters)
   */
  interpolateAlignment(points: AlignmentPoint[], targetChainage: number): InterpolatedTrackPoint {
    if (!points || points.length === 0) {
      return {
        chainage: targetChainage,
        x: 0,
        y: 0,
        z: targetChainage,
        tangentX: 0,
        tangentY: 0,
        tangentZ: 1,
        normalX: -1,
        normalZ: 0,
        gradePercent: 0,
        cantMm: 0
      };
    }

    if (points.length === 1) {
      const p = points[0];
      return {
        chainage: p.chainage,
        x: p.x,
        y: p.elevation,
        z: p.z,
        tangentX: 0,
        tangentY: 0,
        tangentZ: 1,
        normalX: -1,
        normalZ: 0,
        gradePercent: p.gradePercent,
        cantMm: p.cantMm
      };
    }

    // Clamp or find bounding points
    if (targetChainage <= points[0].chainage) {
      const p0 = points[0];
      const p1 = points[1];
      const dx = p1.x - p0.x;
      const dz = p1.z - p0.z;
      const len = Math.hypot(dx, dz) || 1;
      return {
        chainage: targetChainage,
        x: p0.x + (dx / len) * (targetChainage - p0.chainage),
        y: p0.elevation,
        z: p0.z + (dz / len) * (targetChainage - p0.chainage),
        tangentX: dx / len,
        tangentY: 0,
        tangentZ: dz / len,
        normalX: -(dz / len),
        normalZ: dx / len,
        gradePercent: p0.gradePercent,
        cantMm: 0
      };
    }

    const lastIdx = points.length - 1;
    if (targetChainage >= points[lastIdx].chainage) {
      const pPrev = points[lastIdx - 1];
      const pLast = points[lastIdx];
      const dx = pLast.x - pPrev.x;
      const dz = pLast.z - pPrev.z;
      const len = Math.hypot(dx, dz) || 1;
      const diff = targetChainage - pLast.chainage;
      return {
        chainage: targetChainage,
        x: pLast.x + (dx / len) * diff,
        y: pLast.elevation,
        z: pLast.z + (dz / len) * diff,
        tangentX: dx / len,
        tangentY: 0,
        tangentZ: dz / len,
        normalX: -(dz / len),
        normalZ: dx / len,
        gradePercent: pLast.gradePercent,
        cantMm: 0
      };
    }

    // Find the pair of points surrounding the target chainage
    let i = 0;
    for (let k = 0; k < points.length - 1; k++) {
      if (targetChainage >= points[k].chainage && targetChainage <= points[k + 1].chainage) {
        i = k;
        break;
      }
    }

    const p0 = points[i];
    const p1 = points[i + 1];
    const segLength = p1.chainage - p0.chainage;
    const t = segLength > 0 ? (targetChainage - p0.chainage) / segLength : 0;

    // Cubic smooth interpolation for geometry transition
    const smoothT = t * t * (3 - 2 * t);

    const x = p0.x + (p1.x - p0.x) * smoothT;
    const y = p0.elevation + (p1.elevation - p0.elevation) * smoothT;
    const z = p0.z + (p1.z - p0.z) * smoothT;

    const dx = p1.x - p0.x;
    const dy = p1.elevation - p0.elevation;
    const dz = p1.z - p0.z;
    const horizLen = Math.hypot(dx, dz) || 1;

    const tangentX = dx / horizLen;
    const tangentY = dy / (segLength || 1);
    const tangentZ = dz / horizLen;

    const normalX = -tangentZ;
    const normalZ = tangentX;

    const gradePercent = p0.gradePercent + (p1.gradePercent - p0.gradePercent) * t;
    const cantMm = p0.cantMm + (p1.cantMm - p0.cantMm) * t;

    return {
      chainage: targetChainage,
      x,
      y,
      z,
      tangentX,
      tangentY,
      tangentZ,
      normalX,
      normalZ,
      gradePercent,
      cantMm
    };
  }

  /**
   * Evaluates natural ground terrain height (Z/X function) to compare with track formation
   */
  getNaturalGroundElevation(x: number, z: number): number {
    // Topography modeling an undulating Israeli coastal to foothills corridor:
    // Base elevation ~40m, gentle rolling valleys, hills near chainage 5k-6k
    const wave1 = Math.sin(z * 0.0008) * 14;
    const wave2 = Math.cos(x * 0.0012 + z * 0.0004) * 8;
    const localHill = Math.exp(-Math.pow((z - 5400) / 700, 2)) * 32; // Mountain ridge at tunnel
    const valley = Math.exp(-Math.pow((z - 3200) / 600, 2)) * -22; // Valley at bridge
    return 35 + wave1 + wave2 + localHill + valley;
  }

  /**
   * Automated Clash Detection Engine
   * Checks clearances against standard kinematic clearance envelopes (EN 15273 / Israel Railways)
   */
  runClashDetection(
    points: AlignmentPoint[],
    catenarySpacingM: number,
    bridgeClearanceM: number,
    platformHeightMm: number
  ): ClashDetectionResult[] {
    const clashes: ClashDetectionResult[] = [];

    // Check 1: Platform Edge vs Gauge Clearance
    // Nominal platform height is 760mm or 960mm; edge must maintain 1750mm offset from track centerline
    if (platformHeightMm > 1000) {
      clashes.push({
        id: 'CLASH-PL-01',
        chainageM: 1200,
        componentA: 'שפת רציף תחנת מסדרון דרום',
        componentB: 'מעטפת קינמטית של רכבת נוסעים (TSI)',
        severity: 'קריטי',
        description: `גובה רציף מוגדר ${platformHeightMm} מ"מ חורג מהתקן המרבי (960 מ"מ), סכנת פגיעה במדרכי דלתות רכבת`,
        clearanceMm: 960 - platformHeightMm,
        requiredClearanceMm: 0,
        status: 'פתוח',
        designerNote: 'יש להנמיך את גובה מדרך הרציף ל-760 מ"מ או 960 מ"מ תקני'
      });
    }

    // Check 2: Catenary mast spacing vs wind deflection
    if (catenarySpacingM > 65) {
      clashes.push({
        id: 'CLASH-CAT-02',
        chainageM: 2450,
        componentA: 'עמוד חשמול תיל מגע OCS',
        componentB: 'מעטפת סטיית רוח של פנטוגרף (Wind Sway)',
        severity: 'גבוה',
        description: `מרווח עמודים מוגדר ${catenarySpacingM} מ' עולה על המרחק המרבי (65 מ'). תיל המגע עלול לחרוג מקרן הפנטוגרף`,
        clearanceMm: 65 - catenarySpacingM,
        requiredClearanceMm: 0,
        status: 'פתוח',
        designerNote: 'מומלץ לצמצם מרווח עמודים ל-55-60 מטר בעקומות'
      });
    }

    // Check 3: Bridge vertical clearance under deck
    if (bridgeClearanceM < 5.8) {
      clashes.push({
        id: 'CLASH-BR-03',
        chainageM: 3250,
        componentA: 'תחתית קורת גשר עמק מסילה',
        componentB: 'כביש שירות ורכבי חירום מתחת לגשר',
        severity: 'קריטי',
        description: `מרווח אנכי מתחת לגשר ${bridgeClearanceM.toFixed(1)} מ' קטן מהמינימום התקני (5.80 מ') לתנועת משאיות תשתית`,
        clearanceMm: Math.round((bridgeClearanceM - 5.8) * 1000),
        requiredClearanceMm: 0,
        status: 'בבדיקה',
        designerNote: 'הגבהת סמכי הגשר או העמקת מעביר המים/דרך הגישה'
      });
    }

    // Check 4: Curve Radius vs Cant Deficiency at Design Speed
    points.forEach((p) => {
      if (p.curveRadius > 0 && p.curveRadius < 800 && p.designSpeedKmh >= 160) {
        clashes.push({
          id: `CLASH-GEO-${p.id}`,
          chainageM: p.chainage,
          componentA: `עקומה אופקית ציר מסילה R=${p.curveRadius}m`,
          componentB: `מהירות תכן נדרשת ${p.designSpeedKmh} קמ"ש`,
          severity: 'בינוני',
          description: `רדיוס העקומה (${p.curveRadius} מ') מחייב עודף או חסר הגבהה מעבר לגבול הנוחות (130 מ"מ)`,
          clearanceMm: -35,
          requiredClearanceMm: 0,
          status: 'פתוח',
          designerNote: 'הגדלת רדיוס העקומה ל-1200 מ\' או הפחתת מהירות ל-140 קמ"ש'
        });
      }
    });

    // Check 5: Drainage Culvert crossing
    clashes.push({
      id: 'CLASH-DR-04',
      chainageM: 4100,
      componentA: 'מעביר מים מבטון בקוטר 1200 מ"מ',
      componentB: 'שוקת כבלי תקשורת ואיתות GSM-R',
      severity: 'בינוני',
      description: 'הצטלבות במפלס זהה בין שוקת התקשורת לקדקוד מעביר הניקוז',
      clearanceMm: 45,
      requiredClearanceMm: 300,
      status: 'נפתר',
      designerNote: 'בוצע שרוול הגנה מוגבה מעל המעביר באישור מהנדס ניקוז'
    });

    return clashes;
  }
}
