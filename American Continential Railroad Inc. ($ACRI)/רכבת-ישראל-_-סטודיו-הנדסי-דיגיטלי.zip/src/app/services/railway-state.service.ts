import { Injectable, signal, computed, inject } from '@angular/core';
import {
  AlignmentPoint,
  StationModel,
  BridgeStructure,
  TunnelStructure,
  CatenarySystemConfig,
  TrainUnit,
  SignallingBlock,
  ConstructionPhase,
  GanttTask,
  ClashDetectionResult,
  BoQRecord,
  ProjectMetadata,
  EngineeringTab
} from '../models/railway.models';
import { GeometryCalcService } from './geometry-calc.service';

@Injectable({
  providedIn: 'root'
})
export class RailwayStateService {
  private readonly geoCalc = inject(GeometryCalcService);

  // Active navigation tab
  readonly activeTab = signal<EngineeringTab>('digital-twin');

  // Project Metadata
  readonly project = signal<ProjectMetadata>({
    id: 'ISR-CORRIDOR-2026-X',
    name: 'מסדרון רכבת ישראל - מקטע מהיר גליל מרכז',
    corridorName: 'מסילת מסדרון העמקים והגליל (קטע הדגמה הנדסי סינתטי)',
    engineeringVersion: 'Rev 3.4.1 (תכנון מפורט)',
    lastUpdated: '2026-10-23',
    totalLengthKm: 8.5,
    gaugeMm: 1435, // Standard gauge
    trackCount: 2, // Double track
    designStandard: 'תקן רכבת ישראל / EN 13803',
    isSyntheticDemo: true
  });

  // Track Alignment Points
  readonly alignmentPoints = signal<AlignmentPoint[]>([
    {
      id: 'P1',
      name: 'מוצא מסילה PK 0+000 (חיבור רשת ארצית)',
      chainage: 0,
      x: 0,
      z: 0,
      elevation: 32.5,
      curveRadius: 0,
      spiralLength: 0,
      gradePercent: 0.3,
      designSpeedKmh: 160,
      cantMm: 0
    },
    {
      id: 'P2',
      name: 'תחנת מסדרון דרום PK 1+200',
      chainage: 1200,
      x: 60,
      z: 1200,
      elevation: 36.1,
      curveRadius: 0,
      spiralLength: 0,
      gradePercent: 0.2,
      designSpeedKmh: 160,
      cantMm: 0
    },
    {
      id: 'P3',
      name: 'תחילת עקומת נחל קישון PK 2+100',
      chainage: 2100,
      x: 180,
      z: 2100,
      elevation: 38.5,
      curveRadius: 1800,
      spiralLength: 120,
      gradePercent: -0.6,
      designSpeedKmh: 160,
      cantMm: 85
    },
    {
      id: 'P4',
      name: 'גשר עמק מסילה PK 3+200',
      chainage: 3200,
      x: 420,
      z: 3200,
      elevation: 48.0,
      curveRadius: 2200,
      spiralLength: 100,
      gradePercent: 1.1,
      designSpeedKmh: 160,
      cantMm: 65
    },
    {
      id: 'P5',
      name: 'מקטע ישר בין גשר למנהרה PK 4+400',
      chainage: 4400,
      x: 580,
      z: 4400,
      elevation: 61.2,
      curveRadius: 0,
      spiralLength: 0,
      gradePercent: 1.4,
      designSpeedKmh: 160,
      cantMm: 0
    },
    {
      id: 'P6',
      name: 'פורטל כניסה מנהרת הר אודם PK 5+400',
      chainage: 5400,
      x: 610,
      z: 5400,
      elevation: 75.2,
      curveRadius: 0,
      spiralLength: 0,
      gradePercent: 0.5,
      designSpeedKmh: 160,
      cantMm: 0
    },
    {
      id: 'P7',
      name: 'פורטל יציאה מנהרה PK 6+600',
      chainage: 6600,
      x: 640,
      z: 6600,
      elevation: 81.2,
      curveRadius: 2400,
      spiralLength: 90,
      gradePercent: -0.4,
      designSpeedKmh: 160,
      cantMm: 50
    },
    {
      id: 'P8',
      name: 'תחנת מסדרון צפון - גליל PK 7+400',
      chainage: 7400,
      x: 520,
      z: 7400,
      elevation: 78.0,
      curveRadius: 0,
      spiralLength: 0,
      gradePercent: -0.1,
      designSpeedKmh: 160,
      cantMm: 0
    },
    {
      id: 'P9',
      name: 'קצה מקטע תכנון PK 8+500',
      chainage: 8500,
      x: 480,
      z: 8500,
      elevation: 76.9,
      curveRadius: 0,
      spiralLength: 0,
      gradePercent: 0.0,
      designSpeedKmh: 160,
      cantMm: 0
    }
  ]);

  // Stations
  readonly stations = signal<StationModel[]>([
    {
      id: 'ST-01',
      name: 'תחנת מסדרון דרום - פארק תעשייה',
      chainageStart: 1050,
      chainageEnd: 1400,
      platforms: [
        {
          id: 'PL-1',
          name: 'רציף 1 (צפונה)',
          stationId: 'ST-01',
          length: 350,
          width: 8.5,
          heightAboveRailMm: 960,
          isIsland: false,
          edgeSafetyTileWidthMm: 600,
          canopyCoveragePercent: 80
        },
        {
          id: 'PL-2',
          name: 'רציף 2 (דרומה)',
          stationId: 'ST-01',
          length: 350,
          width: 8.5,
          heightAboveRailMm: 960,
          isIsland: false,
          edgeSafetyTileWidthMm: 600,
          canopyCoveragePercent: 80
        }
      ],
      hasPedestrianOverpass: true,
      hasUnderpass: false,
      hasElevatorShafts: true,
      parkingSpaces: 450,
      bldgFootprintSqM: 2800,
      operationalStatus: 'תכנון מפורט'
    },
    {
      id: 'ST-02',
      name: 'תחנת מסדרון צפון - גליל מרכז',
      chainageStart: 7250,
      chainageEnd: 7600,
      platforms: [
        {
          id: 'PL-3',
          name: 'רציף אי מרכזי 1-2',
          stationId: 'ST-02',
          length: 350,
          width: 11.0,
          heightAboveRailMm: 960,
          isIsland: true,
          edgeSafetyTileWidthMm: 600,
          canopyCoveragePercent: 95
        }
      ],
      hasPedestrianOverpass: true,
      hasUnderpass: true,
      hasElevatorShafts: true,
      parkingSpaces: 750,
      bldgFootprintSqM: 4200,
      operationalStatus: 'תכנון מפורט'
    }
  ]);

  // Civil Structures (Bridge & Tunnel)
  readonly bridge = signal<BridgeStructure>({
    id: 'BR-01',
    name: 'גשר עמק מסילה (ויאדוקט ק"מ 3+200)',
    chainageStart: 3050,
    chainageEnd: 3450,
    lengthMeters: 400,
    spanCount: 8,
    pierHeightMaxM: 24.5,
    deckWidthM: 12.8,
    structureType: 'גשר מקטעתי תיבתי',
    bearingCapacityTonnes: 3200,
    clearanceUnderDeckM: 7.2
  });

  readonly tunnel = signal<TunnelStructure>({
    id: 'TN-01',
    name: 'מנהרת הר אודם (ק"מ 5+400)',
    chainageStart: 5400,
    chainageEnd: 6600,
    lengthMeters: 1200,
    crossSectionType: 'קשת פרסית (TBM)',
    innerDiameterM: 9.8,
    coverDepthMaxM: 65,
    crossPassageSpacingM: 250,
    hasVentilationShafts: true
  });

  // Electrification
  readonly catenary = signal<CatenarySystemConfig>({
    systemType: '25kV AC 50Hz OCS',
    nominalVoltageKv: 25,
    contactWireHeightM: 5.3,
    mastSpacingM: 60,
    messengerTensionKn: 15,
    contactWireTensionKn: 15,
    substationsCount: 1,
    totalMastsCount: 142
  });

  // Signalling Blocks (ETCS Level 2)
  readonly signallingBlocks = signal<SignallingBlock[]>([
    {
      id: 'BLK-01',
      name: 'מקטע כניסה דרום (0+000 - 1+500)',
      chainageStart: 0,
      chainageEnd: 1500,
      aspect: 'GREEN',
      isOccupied: false,
      speedLimitKmh: 160,
      baliseType: 'Eurobalise ETCS L2'
    },
    {
      id: 'BLK-02',
      name: 'מקטע תחנה דרומית (1+500 - 3+000)',
      chainageStart: 1500,
      chainageEnd: 3000,
      aspect: 'YELLOW',
      isOccupied: false,
      speedLimitKmh: 120,
      baliseType: 'Eurobalise ETCS L2'
    },
    {
      id: 'BLK-03',
      name: 'מקטע גשר עמק מסילה (3+000 - 4+500)',
      chainageStart: 3000,
      chainageEnd: 4500,
      aspect: 'GREEN',
      isOccupied: false,
      speedLimitKmh: 160,
      baliseType: 'Eurobalise ETCS L2'
    },
    {
      id: 'BLK-04',
      name: 'מקטע מנהרת הר אודם (4+500 - 6+800)',
      chainageStart: 4500,
      chainageEnd: 6800,
      aspect: 'GREEN',
      isOccupied: false,
      speedLimitKmh: 140,
      baliseType: 'Eurobalise ETCS L2'
    },
    {
      id: 'BLK-05',
      name: 'מקטע תחנה צפונית ויציאה (6+800 - 8+500)',
      chainageStart: 6800,
      chainageEnd: 8500,
      aspect: 'GREEN',
      isOccupied: false,
      speedLimitKmh: 160,
      baliseType: 'Eurobalise ETCS L2'
    }
  ]);

  // Train Fleet Simulation Units
  readonly trains = signal<TrainUnit[]>([
    {
      id: 'TR-101',
      code: 'רכבת 482',
      name: 'Desiro HC חשמלית - צפונה',
      trainType: 'רכבת חשמלית רב-נייחת (EMU Desiro)',
      maxSpeedKmh: 160,
      currentSpeedKmh: 145,
      targetSpeedKmh: 160,
      chainagePositionM: 2600,
      direction: 1,
      status: 'בתנועה',
      carsCount: 6,
      totalLengthM: 157,
      passengerCapacity: 820,
      currentBlockId: 'BLK-02'
    },
    {
      id: 'TR-102',
      code: 'רכבת 715',
      name: 'Twindexx Vario קומותיים - דרומה',
      trainType: 'רכבת קומותיים חשמלית (Twindexx)',
      maxSpeedKmh: 160,
      currentSpeedKmh: 110,
      targetSpeedKmh: 120,
      chainagePositionM: 6900,
      direction: -1,
      status: 'בתנועה',
      carsCount: 8,
      totalLengthM: 205,
      passengerCapacity: 1100,
      currentBlockId: 'BLK-05'
    }
  ]);

  // Train Simulation Playback State
  readonly isTrainSimRunning = signal<boolean>(true);
  readonly trainSimSpeedMultiplier = signal<number>(1);

  // 4D Construction Phases
  readonly constructionPhases = signal<ConstructionPhase[]>([
    {
      stageNumber: 1,
      name: 'מדידות גאודטיות והכנת השטח',
      code: 'STAGE-01-SURV',
      description: 'סקר טופוגרפי מפורט, קידוחי קרקע, פינוי תוואי, גידור אתרי התארגנות',
      durationWeeks: 12,
      progressPercent: 100,
      activeEquipment: ['צוותי מודדים GPS/RTK', 'מקדחי קרקע גיאוטכניים', 'שופלים ובאגרים'],
      budgetEstimatedNis: 14500000,
      status: 'הושלם'
    },
    {
      stageNumber: 2,
      name: 'עבודות עפר, חפירה ומילוי',
      code: 'STAGE-02-EARTH',
      description: 'חציבה במקטעי הגבעות, מילוי סוללות מדורגות, הידוק מצע מסילה (Formation)',
      durationWeeks: 24,
      progressPercent: 100,
      activeEquipment: ['שיירות משאיות עפר', 'מכבשים כבדים', 'מחפרים 40 טון', 'מפלסות מוטוריות'],
      budgetEstimatedNis: 48200000,
      status: 'הושלם'
    },
    {
      stageNumber: 3,
      name: 'ניקוז, מעבירי מים ותשתיות תת-קרקע',
      code: 'STAGE-03-DRAIN',
      description: 'הנחת מעבירי מים טרומיים, תעלות בטון טרפזיות, תעלות כבלים משולבות תקשורת',
      durationWeeks: 16,
      progressPercent: 100,
      activeEquipment: ['מנופי הנפה 50 טון', 'ציוד הנחת צנרת', 'משאבות בטון'],
      budgetEstimatedNis: 29000000,
      status: 'הושלם'
    },
    {
      stageNumber: 4,
      name: 'הקמת גשרים ומבנים הנדסיים',
      code: 'STAGE-04-BRIDGES',
      description: 'יציקת יסודות ועמודי גשר עמק מסילה, קידום קורות תיבתיות, קירות תמך בטון מזוין',
      durationWeeks: 38,
      progressPercent: 85,
      activeEquipment: ['מכונות קידוח כלונסאות Benoto', 'מערך יציקה מקטעתי (Formwork Traveller)', 'משאבות בטון'],
      budgetEstimatedNis: 115000000,
      status: 'בביצוע'
    },
    {
      stageNumber: 5,
      name: 'כריית מנהרת הר אודם ודיפון',
      code: 'STAGE-05-TUNNEL',
      description: 'כריית מנהרה כפולה במכונת TBM, הנחת טבעות בטון טרומיות (Segments), מערכות בטיחות',
      durationWeeks: 45,
      progressPercent: 70,
      activeEquipment: ['מכונת TBM קוטר 9.8 מטר', 'רכבות שירות מנהרה', 'מפעל סגמנטים טרומי'],
      budgetEstimatedNis: 210000000,
      status: 'בביצוע'
    },
    {
      stageNumber: 6,
      name: 'הנחת מצע רכבת, חצץ ומסילות',
      code: 'STAGE-06-TRACKS',
      description: 'פיזור חצץ בזלתי מובחר, פריסת אדני בטון מונובלוק, הנחת פסי UIC60, ריתוך תרמיט רציף',
      durationWeeks: 20,
      progressPercent: 40,
      activeEquipment: ['רכבת פריסת מסילה (Track Layer)', 'מבאישת חצץ (Tamping Machine)', 'מפזרת חצץ'],
      budgetEstimatedNis: 88000000,
      status: 'בביצוע'
    },
    {
      stageNumber: 7,
      name: 'התקנת מערכות חשמול 25kV (OCS)',
      code: 'STAGE-07-CATENARY',
      description: 'הצבת עמודי פלדה מגולוונת, התקנת זרועות מבודדות, מתיחת כבל נושא ותיל מגע OCS',
      durationWeeks: 18,
      progressPercent: 30,
      activeEquipment: ['קרוניות חשמול מסילתיות', 'מנופי סל הידראוליים', 'מכונות מתיחה מבוקרת לחץ'],
      budgetEstimatedNis: 62000000,
      status: 'בביצוע'
    },
    {
      stageNumber: 8,
      name: 'מערכות איתות ETCS L2, תקשורת ורכזי שליטה',
      code: 'STAGE-08-SIG',
      description: 'התקנת בסיסי בלוקים Eurobalise, פריסת סיבים אופטיים, שילוב רכזות אלקטרוניות ומפלגים',
      durationWeeks: 16,
      progressPercent: 15,
      activeEquipment: ['מעבדות בדיקה ניידות', 'צוותי כיול אלקטרוני', 'ציוד מדידת תדרי GSM-R'],
      budgetEstimatedNis: 46000000,
      status: 'בביצוע'
    },
    {
      stageNumber: 9,
      name: 'הקמת תחנות נוסעים וסביבת הפיתוח',
      code: 'STAGE-09-STATIONS',
      description: 'הקמת שלדי התחנות, רציפים נגישים, גשרי הולכי רגל, מעליות, מגרשי חניה ומרכזי תחבורה משולבים',
      durationWeeks: 28,
      progressPercent: 20,
      activeEquipment: ['מנופי צריח', 'משאיות אספקה', 'צוותי גמר ופיתוח נופי'],
      budgetEstimatedNis: 94000000,
      status: 'בביצוע'
    },
    {
      stageNumber: 10,
      name: 'בדיקות אינטגרציה, נסיעות מבחן ומסירה',
      code: 'STAGE-10-COMMISSIONING',
      description: 'נסיעות מבחן במהירות מרבית, בדיקות הפרעות אלקטרומגנטיות (EMC), הדרכת צוותים, מסירה רשמית',
      durationWeeks: 10,
      progressPercent: 0,
      activeEquipment: ['רכבת מעבדה ייעודית (EM120)', 'צוותי בקרה ותפעול', 'בודקים מוסמכים'],
      budgetEstimatedNis: 18000000,
      status: 'מתוכנן'
    }
  ]);

  // Current active 4D Construction Phase filter (1 to 10)
  readonly activeConstructionPhase = signal<number>(6); // Default showing track & bridge progress
  readonly is4DPlaying = signal<boolean>(false);

  // Gantt Tasks (Detailed project schedule)
  readonly ganttTasks = signal<GanttTask[]>([
    { id: 'T1', name: 'מדידות וקידוחי ניסיון בתוואי', stageNumber: 1, startWeek: 1, endWeek: 8, durationWeeks: 8, progressPercent: 100, dependencies: [], isCritical: true, costEstimatedNis: 6500000, responsibleDiscipline: 'גאומטריה ועפר' },
    { id: 'T2', name: 'הכשרת אתרי התארגנות ופינוי', stageNumber: 1, startWeek: 5, endWeek: 12, durationWeeks: 8, progressPercent: 100, dependencies: ['T1'], isCritical: false, costEstimatedNis: 8000000, responsibleDiscipline: 'גאומטריה ועפר' },
    { id: 'T3', name: 'עבודות עפר, חפירה וסוללות', stageNumber: 2, startWeek: 10, endWeek: 34, durationWeeks: 24, progressPercent: 100, dependencies: ['T1'], isCritical: true, costEstimatedNis: 48200000, responsibleDiscipline: 'גאומטריה ועפר' },
    { id: 'T4', name: 'ביצוע מעבירי מים ותעלות ניקוז', stageNumber: 3, startWeek: 22, endWeek: 38, durationWeeks: 16, progressPercent: 100, dependencies: ['T3'], isCritical: false, costEstimatedNis: 29000000, responsibleDiscipline: 'גאומטריה ועפר' },
    { id: 'T5', name: 'כלונסאות ועמודי גשר עמק מסילה', stageNumber: 4, startWeek: 26, endWeek: 48, durationWeeks: 22, progressPercent: 100, dependencies: ['T3'], isCritical: true, costEstimatedNis: 58000000, responsibleDiscipline: 'מבנים וגישור' },
    { id: 'T6', name: 'יציקת מיסעת גשר ומקטעים', stageNumber: 4, startWeek: 44, endWeek: 64, durationWeeks: 20, progressPercent: 70, dependencies: ['T5'], isCritical: true, costEstimatedNis: 57000000, responsibleDiscipline: 'מבנים וגישור' },
    { id: 'T7', name: 'כריית מנהרת הר אודם (TBM)', stageNumber: 5, startWeek: 32, endWeek: 77, durationWeeks: 45, progressPercent: 70, dependencies: ['T3'], isCritical: true, costEstimatedNis: 210000000, responsibleDiscipline: 'מבנים וגישור' },
    { id: 'T8', name: 'הנחת שכבת חצץ בזלת (Ballast)', stageNumber: 6, startWeek: 65, endWeek: 75, durationWeeks: 10, progressPercent: 55, dependencies: ['T6'], isCritical: true, costEstimatedNis: 32000000, responsibleDiscipline: 'מסילאות' },
    { id: 'T9', name: 'הרכבת מסילות ואדנים מונובלוק', stageNumber: 6, startWeek: 72, endWeek: 85, durationWeeks: 13, progressPercent: 25, dependencies: ['T8'], isCritical: true, costEstimatedNis: 56000000, responsibleDiscipline: 'מסילאות' },
    { id: 'T10', name: 'הצבת עמודי חשמול וכבלי OCS', stageNumber: 7, startWeek: 80, endWeek: 98, durationWeeks: 18, progressPercent: 30, dependencies: ['T9'], isCritical: true, costEstimatedNis: 62000000, responsibleDiscipline: 'חשמול ומערכות' },
    { id: 'T11', name: 'רכזות איתות ETCS L2 ובלוזות', stageNumber: 8, startWeek: 85, endWeek: 101, durationWeeks: 16, progressPercent: 15, dependencies: ['T9'], isCritical: true, costEstimatedNis: 46000000, responsibleDiscipline: 'איתות ובקרה' },
    { id: 'T12', name: 'בניית רציפי תחנות ומבנים', stageNumber: 9, startWeek: 60, endWeek: 88, durationWeeks: 28, progressPercent: 20, dependencies: ['T4'], isCritical: false, costEstimatedNis: 94000000, responsibleDiscipline: 'מבנים וגישור' },
    { id: 'T13', name: 'נסיעות מבחן, אינטגרציה ומסירה', stageNumber: 10, startWeek: 102, endWeek: 112, durationWeeks: 10, progressPercent: 0, dependencies: ['T10', 'T11', 'T12'], isCritical: true, costEstimatedNis: 18000000, responsibleDiscipline: 'מסילאות' }
  ]);

  // 3D Viewport Controls & Layer Toggles
  readonly viewPreset = signal<'free' | 'driver-cab' | 'drone-corridor' | 'station-south' | 'bridge-view' | 'tunnel-portal'>('free');
  readonly layerVisibility = signal({
    tracks: true,
    terrain: true,
    stations: true,
    structures: true,
    catenary: true,
    signalling: true,
    trains: true,
    clashMarkers: true
  });

  // Selected 3D Object inspection
  readonly inspectedObject = signal<{
    type: string;
    title: string;
    chainage: string;
    specs: { label: string; value: string }[];
  } | null>(null);

  // Reactive Computed Clash Detection
  readonly clashes = computed<ClashDetectionResult[]>(() => {
    const pts = this.alignmentPoints();
    const cat = this.catenary();
    const br = this.bridge();
    const stList = this.stations();
    const platHeight = stList[0]?.platforms[0]?.heightAboveRailMm || 960;
    return this.geoCalc.runClashDetection(pts, cat.mastSpacingM, br.clearanceUnderDeckM, platHeight);
  });

  // Reactive Computed Bill of Quantities (BoQ)
  readonly boqRecords = computed<BoQRecord[]>(() => {
    const pts = this.alignmentPoints();
    const lengthM = pts[pts.length - 1]?.chainage || 8500;
    const doubleTrackLengthM = lengthM * 2;
    const cat = this.catenary();
    const br = this.bridge();
    const tn = this.tunnel();
    const mastsCount = Math.round(lengthM / cat.mastSpacingM) * 2;

    // Earthworks calculation based on terrain difference
    const cutVolumeM3 = Math.round(lengthM * 14.5 * 3.2); // ~394,400 m³
    const fillVolumeM3 = Math.round(lengthM * 16.0 * 2.8); // ~380,800 m³
    const ballastM3 = Math.round(doubleTrackLengthM * 3.4); // 3.4 m³ per meter of double track
    const sleepersCount = Math.round(doubleTrackLengthM / 0.6); // 1667 sleepers per km
    const railTonnes = Math.round((doubleTrackLengthM * 2 * 60) / 1000); // UIC60 = 60 kg/m
    const bridgeConcreteM3 = Math.round(br.lengthMeters * br.deckWidthM * 2.2);
    const tunnelConcreteM3 = Math.round(tn.lengthMeters * Math.PI * tn.innerDiameterM * 0.45);

    const records: BoQRecord[] = [
      {
        itemCode: 'BOQ-01.01',
        description: 'חפירת עפר וסלע לתוואי מסילה וסוללות (Cut)',
        category: 'עבודות עפר',
        unit: 'מ"ק',
        calculatedQuantity: cutVolumeM3,
        unitPriceNis: 48,
        totalPriceNis: cutVolumeM3 * 48,
        uncertaintyMarginPercent: 10,
        isParametric: true
      },
      {
        itemCode: 'BOQ-01.02',
        description: 'מילוי והידוק מצע מסילה מבוקר (Fill & Subgrade)',
        category: 'עבודות עפר',
        unit: 'מ"ק',
        calculatedQuantity: fillVolumeM3,
        unitPriceNis: 65,
        totalPriceNis: fillVolumeM3 * 65,
        uncertaintyMarginPercent: 12,
        isParametric: true
      },
      {
        itemCode: 'BOQ-02.01',
        description: 'בטון מזוין ודרוך לגשר עמק מסילה (קורות וניצבים)',
        category: 'מבנים וגישור',
        unit: 'מ"ק',
        calculatedQuantity: bridgeConcreteM3,
        unitPriceNis: 3400,
        totalPriceNis: bridgeConcreteM3 * 3400,
        uncertaintyMarginPercent: 15,
        isParametric: true
      },
      {
        itemCode: 'BOQ-02.02',
        description: 'טבעות דיפון בטון טרומי מנהרת הר אודם (TBM Segments)',
        category: 'מבנים וגישור',
        unit: 'מ"ק',
        calculatedQuantity: tunnelConcreteM3,
        unitPriceNis: 4200,
        totalPriceNis: tunnelConcreteM3 * 4200,
        uncertaintyMarginPercent: 15,
        isParametric: true
      },
      {
        itemCode: 'BOQ-03.01',
        description: 'חצץ בזלתי מובחר למסילאות (Ballast Grade 1)',
        category: 'מסילאות',
        unit: 'מ"ק',
        calculatedQuantity: ballastM3,
        unitPriceNis: 195,
        totalPriceNis: ballastM3 * 195,
        uncertaintyMarginPercent: 8,
        isParametric: true
      },
      {
        itemCode: 'BOQ-03.02',
        description: 'אדני בטון דרוך מונובלוק (B70)',
        category: 'מסילאות',
        unit: 'יחידה',
        calculatedQuantity: sleepersCount,
        unitPriceNis: 420,
        totalPriceNis: sleepersCount * 420,
        uncertaintyMarginPercent: 5,
        isParametric: true
      },
      {
        itemCode: 'BOQ-03.03',
        description: 'פסי פלדה UIC60 מחושלים ומחוסמים',
        category: 'מסילאות',
        unit: 'טון',
        calculatedQuantity: railTonnes,
        unitPriceNis: 5800,
        totalPriceNis: railTonnes * 5800,
        uncertaintyMarginPercent: 7,
        isParametric: true
      },
      {
        itemCode: 'BOQ-04.01',
        description: 'עמודי פלדה וזרועות בידוד לחשמול 25kV OCS',
        category: 'חשמול',
        unit: 'עמוד',
        calculatedQuantity: mastsCount,
        unitPriceNis: 32000,
        totalPriceNis: mastsCount * 32000,
        uncertaintyMarginPercent: 10,
        isParametric: true
      },
      {
        itemCode: 'BOQ-04.02',
        description: 'תיל מגע נחושת-כסף וכבל נושא OCS (25kV)',
        category: 'חשמול',
        unit: 'מ\' אורך',
        calculatedQuantity: doubleTrackLengthM,
        unitPriceNis: 380,
        totalPriceNis: doubleTrackLengthM * 380,
        uncertaintyMarginPercent: 10,
        isParametric: true
      },
      {
        itemCode: 'BOQ-05.01',
        description: 'מערכת איתות רכבות ETCS L2, בלוזות ורכזות אלקטרוניות',
        category: 'איתות ותחנות',
        unit: 'מכלול מסדרון',
        calculatedQuantity: 1,
        unitPriceNis: 46000000,
        totalPriceNis: 46000000,
        uncertaintyMarginPercent: 15,
        isParametric: false
      },
      {
        itemCode: 'BOQ-05.02',
        description: 'הקמת 2 תחנות נוסעים, רציפים, מעליות ומערכות מידע',
        category: 'איתות ותחנות',
        unit: 'תחנה',
        calculatedQuantity: 2,
        unitPriceNis: 47000000,
        totalPriceNis: 94000000,
        uncertaintyMarginPercent: 12,
        isParametric: false
      }
    ];

    return records;
  });

  // Total BoQ Price
  readonly totalBoQCostNis = computed<number>(() => {
    return this.boqRecords().reduce((sum, item) => sum + item.totalPriceNis, 0);
  });

  // Overall Project Progress %
  readonly overallProgressPercent = computed<number>(() => {
    const phases = this.constructionPhases();
    const totalBudget = phases.reduce((sum, p) => sum + p.budgetEstimatedNis, 0);
    const weightedDone = phases.reduce((sum, p) => sum + (p.budgetEstimatedNis * (p.progressPercent / 100)), 0);
    return totalBudget > 0 ? Math.round((weightedDone / totalBudget) * 100) : 0;
  });

  // Update Methods
  setTab(tab: EngineeringTab): void {
    this.activeTab.set(tab);
  }

  set4DConstructionPhase(phaseNumber: number): void {
    this.activeConstructionPhase.set(Math.max(1, Math.min(10, phaseNumber)));
  }

  toggle4DPlayback(): void {
    this.is4DPlaying.update((v) => !v);
  }

  toggleTrainSim(): void {
    this.isTrainSimRunning.update((v) => !v);
  }

  setTrainSimSpeed(multiplier: number): void {
    this.trainSimSpeedMultiplier.set(multiplier);
  }

  setViewPreset(preset: 'free' | 'driver-cab' | 'drone-corridor' | 'station-south' | 'bridge-view' | 'tunnel-portal'): void {
    this.viewPreset.set(preset);
  }

  toggleLayer(layerKey: keyof {
    tracks: boolean;
    terrain: boolean;
    stations: boolean;
    structures: boolean;
    catenary: boolean;
    signalling: boolean;
    trains: boolean;
    clashMarkers: boolean;
  }): void {
    this.layerVisibility.update((prev) => ({
      ...prev,
      [layerKey]: !prev[layerKey]
    }));
  }

  updateAlignmentPoint(updatedPoint: AlignmentPoint): void {
    // Recalculate equilibrium cant
    const computedCant = this.geoCalc.calculateCant(updatedPoint.designSpeedKmh, updatedPoint.curveRadius);
    const pointWithCant = { ...updatedPoint, cantMm: computedCant };

    this.alignmentPoints.update((pts) =>
      pts.map((p) => (p.id === pointWithCant.id ? pointWithCant : p))
    );
  }

  updateCatenarySpacing(spacingM: number): void {
    this.catenary.update((cat) => ({
      ...cat,
      mastSpacingM: spacingM,
      totalMastsCount: Math.round(8500 / spacingM) * 2
    }));
  }

  updateBridgeClearance(clearanceM: number): void {
    this.bridge.update((br) => ({
      ...br,
      clearanceUnderDeckM: clearanceM
    }));
  }

  updatePlatformHeight(stationId: string, heightMm: number): void {
    this.stations.update((stList) =>
      stList.map((st) => {
        if (st.id === stationId) {
          return {
            ...st,
            platforms: st.platforms.map((p) => ({ ...p, heightAboveRailMm: heightMm }))
          };
        }
        return st;
      })
    );
  }

  inspectObject(obj: { type: string; title: string; chainage: string; specs: { label: string; value: string }[] } | null): void {
    this.inspectedObject.set(obj);
  }

  // Train tick simulation loop
  tickTrains(deltaSeconds: number): void {
    if (!this.isTrainSimRunning()) return;
    const mult = this.trainSimSpeedMultiplier();
    const effectiveDt = deltaSeconds * mult;

    this.trains.update((currentTrains) =>
      currentTrains.map((tr) => {
        // Simple speed & position integration
        const speedMs = (tr.currentSpeedKmh * 1000) / 3600;
        let nextPos = tr.chainagePositionM + tr.direction * speedMs * effectiveDt;

        // Loop / Reverse at corridor terminals (PK 0 to 8500)
        let nextDir = tr.direction;
        if (nextPos >= 8200 && tr.direction === 1) {
          nextPos = 8200;
          nextDir = -1;
        } else if (nextPos <= 300 && tr.direction === -1) {
          nextPos = 300;
          nextDir = 1;
        }

        // Determine current block
        let blockId = 'BLK-01';
        if (nextPos >= 6800) blockId = 'BLK-05';
        else if (nextPos >= 4500) blockId = 'BLK-04';
        else if (nextPos >= 3000) blockId = 'BLK-03';
        else if (nextPos >= 1500) blockId = 'BLK-02';

        return {
          ...tr,
          chainagePositionM: nextPos,
          direction: nextDir,
          currentBlockId: blockId
        };
      })
    );
  }
}
