import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';
import { ClashDetectionResult } from '../../models/railway.models';

@Component({
  selector: 'app-clash-detector',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-rose-400">warning</mat-icon>
            <h2 class="text-xl font-bold text-white">בדיקת התנגשויות ותיאום מערכות (BIM Clash Detection)</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            זיהוי אוטומטי של חריגות מעטפת מבנה פנוי (Kinematic Clearance), עמודי חשמול, שפות רציפים ותשתיות סמוכות
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1 rounded-xl bg-rose-950/70 border border-rose-600/50 text-rose-300 font-bold text-xs">
            {{ state.clashes().length }} ממצאים פעילים
          </span>
        </div>
      </div>

      <!-- Quick Severity Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="bg-rose-950/30 border border-rose-700/50 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span class="text-xs text-rose-300 block">חומרה קריטית (סכנת פגיעה)</span>
            <span class="text-2xl font-bold font-mono text-rose-400">
              {{ countBySeverity('קריטי') }}
            </span>
          </div>
          <mat-icon class="text-rose-500 text-3xl">error</mat-icon>
        </div>

        <div class="bg-amber-950/30 border border-amber-700/50 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span class="text-xs text-amber-300 block">חומרה גבוהה (מרווחי רוח וחשמל)</span>
            <span class="text-2xl font-bold font-mono text-amber-400">
              {{ countBySeverity('גבוה') }}
            </span>
          </div>
          <mat-icon class="text-amber-500 text-3xl">warning</mat-icon>
        </div>

        <div class="bg-sky-950/30 border border-sky-700/50 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span class="text-xs text-sky-300 block">חומרה בינונית (חציות תשתית ורדיוס)</span>
            <span class="text-2xl font-bold font-mono text-sky-400">
              {{ countBySeverity('בינוני') }}
            </span>
          </div>
          <mat-icon class="text-sky-500 text-3xl">info</mat-icon>
        </div>
      </div>

      <!-- Clash Items Audit Table -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl overflow-hidden shadow">
        <div class="p-4 bg-slate-800/90 border-b border-slate-700/60 flex items-center justify-between">
          <span class="font-bold text-sm text-white">יומן תיאום מערכות וממצאי בדיקות</span>
          <span class="text-xs text-slate-400">עודכן אוטומטית בהתאם למודל</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-right text-xs">
            <thead class="bg-slate-900/80 text-slate-400 uppercase text-[10px] border-b border-slate-700/60 font-mono">
              <tr>
                <th class="p-3 w-28">מזהה</th>
                <th class="p-3 w-28">מיקום (Chainage)</th>
                <th class="p-3 w-40">רכיב א׳</th>
                <th class="p-3 w-40">רכיב ב׳</th>
                <th class="p-3 w-24">חומרה</th>
                <th class="p-3">תיאור והערת מתכנן לפתרון</th>
                <th class="p-3 w-24">סטטוס</th>
                <th class="p-3 w-28 text-center">תצוגה ב-3D</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-700/40">
              @for (clash of state.clashes(); track clash.id) {
                <tr class="hover:bg-slate-750/50 transition-colors">
                  <td class="p-3 font-mono text-rose-400 font-bold">{{ clash.id }}</td>
                  <td class="p-3 font-mono text-sky-300">
                    PK {{ Math.floor(clash.chainageM / 1000) }}+{{ (clash.chainageM % 1000).toString().padStart(3, '0') }}
                  </td>
                  <td class="p-3 font-medium text-white">{{ clash.componentA }}</td>
                  <td class="p-3 font-medium text-slate-300">{{ clash.componentB }}</td>
                  <td class="p-3">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                          [class.bg-rose-950]="clash.severity === 'קריטי'"
                          [class.text-rose-300]="clash.severity === 'קריטי'"
                          [class.border]="true"
                          [class.border-rose-600]="clash.severity === 'קריטי'"
                          [class.bg-amber-950]="clash.severity === 'גבוה'"
                          [class.text-amber-300]="clash.severity === 'גבוה'"
                          [class.border-amber-600]="clash.severity === 'גבוה'"
                          [class.bg-sky-950]="clash.severity === 'בינוני'"
                          [class.text-sky-300]="clash.severity === 'בינוני'"
                          [class.border-sky-600]="clash.severity === 'בינוני'">
                      {{ clash.severity }}
                    </span>
                  </td>
                  <td class="p-3">
                    <div class="text-white">{{ clash.description }}</div>
                    <div class="text-[11px] text-emerald-400 mt-0.5">
                      הנחיה: {{ clash.designerNote }}
                    </div>
                  </td>
                  <td class="p-3">
                    <span class="px-2 py-0.5 rounded text-[10px] font-medium"
                          [class.bg-rose-900/60]="clash.status === 'פתוח'"
                          [class.text-rose-200]="clash.status === 'פתוח'"
                          [class.bg-amber-900/60]="clash.status === 'בבדיקה'"
                          [class.text-amber-200]="clash.status === 'בבדיקה'"
                          [class.bg-emerald-900/60]="clash.status === 'נפתר'"
                          [class.text-emerald-200]="clash.status === 'נפתר'">
                      {{ clash.status }}
                    </span>
                  </td>
                  <td class="p-3 text-center">
                    <button
                      type="button"
                      (click)="jumpTo3D(clash)"
                      class="px-2.5 py-1 rounded bg-[#245B85] hover:bg-sky-600 text-white font-medium text-[11px] flex items-center justify-center gap-1 mx-auto transition-colors">
                      <mat-icon class="text-xs w-3.5 h-3.5 leading-none">visibility</mat-icon>
                      צפה ב-3D
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ClashDetector {
  readonly state = inject(RailwayStateService);
  readonly Math = Math;

  countBySeverity(sev: string): number {
    return this.state.clashes().filter((c) => c.severity === sev).length;
  }

  jumpTo3D(clash: ClashDetectionResult): void {
    this.state.inspectObject({
      type: 'התנגשות הנדסית (BIM Clash)',
      title: clash.description,
      chainage: `PK ${Math.floor(clash.chainageM / 1000)}+${(clash.chainageM % 1000).toString().padStart(3, '0')}`,
      specs: [
        { label: 'מזהה התנגשות', value: clash.id },
        { label: 'רכיב א׳', value: clash.componentA },
        { label: 'רכיב ב׳', value: clash.componentB },
        { label: 'חומרה', value: clash.severity },
        { label: 'הערת מתכנן', value: clash.designerNote }
      ]
    });
    this.state.setTab('digital-twin');
  }
}
