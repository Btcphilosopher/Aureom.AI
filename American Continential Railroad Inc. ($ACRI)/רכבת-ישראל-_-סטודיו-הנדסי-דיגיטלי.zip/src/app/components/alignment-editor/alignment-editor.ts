import { Component, inject, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';
import { AlignmentPoint } from '../../models/railway.models';

@Component({
  selector: 'app-alignment-editor',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-sky-400">route</mat-icon>
            <h2 class="text-xl font-bold text-white">תכנון תוואי וגאומטריית מסילה</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            הגדרת ציר מסילה, רדיוסי עקומות אופקיות (R), מעברים ספירליים, שיפועי אורך והגבהת מסילה (Cant)
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="openAddPointModal()"
            class="bg-[#245B85] hover:bg-sky-700 text-white px-3.5 py-1.5 rounded-xl font-medium text-xs flex items-center gap-1.5 shadow transition-colors">
            <mat-icon class="text-sm w-4 h-4 leading-none">add</mat-icon>
            הוסף נקודת ציר (PI)
          </button>
        </div>
      </div>

      <!-- Quick Engineering Stats Ribbon -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3">
          <span class="text-[11px] text-slate-400 block">אורך תוואי כולל</span>
          <span class="text-lg font-bold font-mono text-white">{{ (state.alignmentPoints()[state.alignmentPoints().length - 1].chainage / 1000).toFixed(2) }} ק"מ</span>
          <span class="text-[10px] text-emerald-400 block mt-0.5">מסילה כפולה (Double Track)</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3">
          <span class="text-[11px] text-slate-400 block">רדיוס עקומה מינימלי</span>
          <span class="text-lg font-bold font-mono text-white">1,800 מ'</span>
          <span class="text-[10px] text-sky-400 block mt-0.5">תואם תכן 160 קמ"ש</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3">
          <span class="text-[11px] text-slate-400 block">שיפוע מרבי (Ruling Grade)</span>
          <span class="text-lg font-bold font-mono text-white">1.4% (14‰)</span>
          <span class="text-[10px] text-emerald-400 block mt-0.5">תקני למסילת נוסעים כבדה</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3">
          <span class="text-[11px] text-slate-400 block">הגבהה מרבית מחושבת (Cant)</span>
          <span class="text-lg font-bold font-mono text-white">85 מ"מ</span>
          <span class="text-[10px] text-slate-400 block mt-0.5">תחום שיווי משקל (EN 13803)</span>
        </div>
      </div>

      <!-- Alignment Points Table -->
      <div class="bg-slate-800/60 border border-slate-700/60 rounded-2xl overflow-hidden shadow">
        <div class="p-3 bg-slate-800/90 border-b border-slate-700/60 flex items-center justify-between">
          <span class="font-bold text-sm text-slate-200">טבלת נקודות ציר ותחנות שרשור (Chainage Stationing)</span>
          <span class="text-xs text-slate-400">{{ state.alignmentPoints().length }} נקודות ייחוס</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-right text-xs">
            <thead class="bg-slate-900/60 text-slate-400 uppercase text-[10px] border-b border-slate-700/60 font-mono">
              <tr>
                <th class="p-3">מזהה ושם מקטע</th>
                <th class="p-3">ק"מ (Chainage)</th>
                <th class="p-3">מזרח X (מ')</th>
                <th class="p-3">צפון Z (מ')</th>
                <th class="p-3">רום מסילה (m ASL)</th>
                <th class="p-3">רדיוס עקומה R (מ')</th>
                <th class="p-3">ספירלה (מ')</th>
                <th class="p-3">שיפוע אורך (%)</th>
                <th class="p-3">מהירות (קמ"ש)</th>
                <th class="p-3">הגבהה Cant (מ"מ)</th>
                <th class="p-3 text-center">פעולות</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-700/40">
              @for (p of state.alignmentPoints(); track p.id) {
                <tr class="hover:bg-slate-750/50 transition-colors">
                  <td class="p-3 font-medium text-white flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-sky-400"></span>
                    {{ p.name }}
                  </td>
                  <td class="p-3 font-mono text-sky-300">
                    PK {{ Math.floor(p.chainage / 1000) }}+{{ (p.chainage % 1000).toString().padStart(3, '0') }}
                  </td>
                  <td class="p-3 font-mono text-slate-300">{{ p.x.toFixed(1) }}</td>
                  <td class="p-3 font-mono text-slate-300">{{ p.z.toFixed(1) }}</td>
                  <td class="p-3 font-mono text-emerald-400">{{ p.elevation.toFixed(2) }}</td>
                  <td class="p-3 font-mono">
                    @if (p.curveRadius > 0) {
                      <span class="text-amber-400 font-bold">{{ p.curveRadius }} מ'</span>
                    } @else {
                      <span class="text-slate-400">ישר (Tangent)</span>
                    }
                  </td>
                  <td class="p-3 font-mono text-slate-300">{{ p.spiralLength > 0 ? p.spiralLength + ' מטר' : '-' }}</td>
                  <td class="p-3 font-mono" [class.text-amber-400]="p.gradePercent > 1" [class.text-slate-300]="p.gradePercent <= 1">
                    {{ p.gradePercent > 0 ? '+' : '' }}{{ p.gradePercent.toFixed(2) }}%
                  </td>
                  <td class="p-3 font-mono text-slate-200">{{ p.designSpeedKmh }}</td>
                  <td class="p-3 font-mono">
                    <span class="px-2 py-0.5 rounded bg-sky-900/60 text-sky-200 font-bold border border-sky-700/40">
                      {{ p.cantMm }} מ"מ
                    </span>
                  </td>
                  <td class="p-3 text-center">
                    <button
                      type="button"
                      (click)="editPoint(p)"
                      class="text-sky-400 hover:text-white p-1 rounded hover:bg-slate-700 transition-colors"
                      title="ערוך פרמטרים הנדסיים">
                      <mat-icon class="text-sm w-4 h-4 leading-none">edit</mat-icon>
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Point Edit Form Modal (When active) -->
      @if (editingPoint()) {
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div class="bg-[#142B45] border border-sky-600/70 rounded-2xl w-full max-w-lg p-5 shadow-2xl text-xs space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-slate-700">
              <span class="font-bold text-white text-sm flex items-center gap-1.5">
                <mat-icon class="text-sky-400">tune</mat-icon>
                עריכת פרמטרי ציר מסילה: {{ editingPoint()?.name }}
              </span>
              <button
                type="button"
                (click)="cancelEdit()"
                class="text-slate-400 hover:text-white">
                <mat-icon class="text-sm w-4 h-4 leading-none">close</mat-icon>
              </button>
            </div>

            <form [formGroup]="editForm" (ngSubmit)="savePoint()" class="space-y-3">
              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label for="align-name" class="block text-slate-300 mb-1">שם המקטע / נקודת ייחוס</label>
                  <input
                    id="align-name"
                    type="text"
                    formControlName="name"
                    class="w-full bg-slate-800 border border-slate-600 rounded-lg px-2.5 py-1.5 text-white" />
                </div>
                <div>
                  <label for="align-chainage" class="block text-slate-300 mb-1">ק"מ מסילה (Chainage מטר)</label>
                  <input
                    id="align-chainage"
                    type="number"
                    formControlName="chainage"
                    class="w-full bg-slate-800 border border-slate-600 rounded-lg px-2.5 py-1.5 text-white font-mono" />
                </div>
              </div>

              <div class="grid grid-cols-3 gap-3">
                <div>
                  <label for="align-radius" class="block text-slate-300 mb-1">רדיוס עקומה R (מ')</label>
                  <input
                    id="align-radius"
                    type="number"
                    formControlName="curveRadius"
                    class="w-full bg-slate-800 border border-slate-600 rounded-lg px-2.5 py-1.5 text-white font-mono" />
                  <span class="text-[10px] text-slate-400">0 לקטע ישר</span>
                </div>
                <div>
                  <label for="align-elevation" class="block text-slate-300 mb-1">רום מסילה (Elevation m)</label>
                  <input
                    id="align-elevation"
                    type="number"
                    step="0.1"
                    formControlName="elevation"
                    class="w-full bg-slate-800 border border-slate-600 rounded-lg px-2.5 py-1.5 text-white font-mono" />
                </div>
                <div>
                  <label for="align-grade" class="block text-slate-300 mb-1">שיפוע אורך (%)</label>
                  <input
                    id="align-grade"
                    type="number"
                    step="0.1"
                    formControlName="gradePercent"
                    class="w-full bg-slate-800 border border-slate-600 rounded-lg px-2.5 py-1.5 text-white font-mono" />
                </div>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label for="align-speed" class="block text-slate-300 mb-1">מהירות תכן (קמ"ש)</label>
                  <input
                    id="align-speed"
                    type="number"
                    formControlName="designSpeedKmh"
                    class="w-full bg-slate-800 border border-slate-600 rounded-lg px-2.5 py-1.5 text-white font-mono" />
                </div>
                <div>
                  <label for="align-spiral" class="block text-slate-300 mb-1">אורך מעבר ספירלי (מ')</label>
                  <input
                    id="align-spiral"
                    type="number"
                    formControlName="spiralLength"
                    class="w-full bg-slate-800 border border-slate-600 rounded-lg px-2.5 py-1.5 text-white font-mono" />
                </div>
              </div>

              <div class="pt-3 flex justify-end gap-2 border-t border-slate-700">
                <button
                  type="button"
                  (click)="cancelEdit()"
                  class="px-3 py-1.5 rounded-lg bg-slate-700 text-slate-200 hover:bg-slate-600">
                  ביטול
                </button>
                <button
                  type="submit"
                  class="px-4 py-1.5 rounded-lg bg-[#245B85] hover:bg-sky-600 text-white font-medium flex items-center gap-1">
                  <mat-icon class="text-sm w-4 h-4 leading-none">check</mat-icon>
                  שמור שינויים ועדכן מודל 3D
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `
})
export class AlignmentEditor {
  readonly state = inject(RailwayStateService);
  private readonly fb = inject(FormBuilder);
  readonly Math = Math;

  readonly editingPoint = signal<AlignmentPoint | null>(null);

  readonly editForm: FormGroup = this.fb.group({
    id: [''],
    name: ['', Validators.required],
    chainage: [0, [Validators.required, Validators.min(0)]],
    elevation: [0, Validators.required],
    curveRadius: [0, [Validators.required, Validators.min(0)]],
    spiralLength: [0],
    gradePercent: [0],
    designSpeedKmh: [160, [Validators.required, Validators.min(60)]]
  });

  openAddPointModal(): void {
    const pts = this.state.alignmentPoints();
    const last = pts[pts.length - 1];
    const newPt: AlignmentPoint = {
      id: `P${pts.length + 1}`,
      name: `נקודת ציר חדשה PK ${Math.floor((last.chainage + 500) / 1000)}+${((last.chainage + 500) % 1000).toString().padStart(3, '0')}`,
      chainage: last.chainage + 500,
      x: last.x + 30,
      z: last.z + 500,
      elevation: last.elevation + 1.2,
      curveRadius: 1800,
      spiralLength: 80,
      gradePercent: 0.2,
      designSpeedKmh: 160,
      cantMm: 0
    };
    this.editPoint(newPt);
  }

  editPoint(p: AlignmentPoint): void {
    this.editingPoint.set(p);
    this.editForm.patchValue({
      id: p.id,
      name: p.name,
      chainage: p.chainage,
      elevation: p.elevation,
      curveRadius: p.curveRadius,
      spiralLength: p.spiralLength,
      gradePercent: p.gradePercent,
      designSpeedKmh: p.designSpeedKmh
    });
  }

  cancelEdit(): void {
    this.editingPoint.set(null);
  }

  savePoint(): void {
    if (this.editForm.invalid) return;
    const formVal = this.editForm.value;
    const current = this.editingPoint();
    if (!current) return;

    const updated: AlignmentPoint = {
      ...current,
      name: formVal.name,
      chainage: Number(formVal.chainage),
      elevation: Number(formVal.elevation),
      curveRadius: Number(formVal.curveRadius),
      spiralLength: Number(formVal.spiralLength),
      gradePercent: Number(formVal.gradePercent),
      designSpeedKmh: Number(formVal.designSpeedKmh)
    };

    // Check if new or existing
    const exists = this.state.alignmentPoints().some((p) => p.id === updated.id);
    if (exists) {
      this.state.updateAlignmentPoint(updated);
    } else {
      this.state.alignmentPoints.update((pts) => [...pts, updated].sort((a, b) => a.chainage - b.chainage));
    }

    this.editingPoint.set(null);
  }
}
