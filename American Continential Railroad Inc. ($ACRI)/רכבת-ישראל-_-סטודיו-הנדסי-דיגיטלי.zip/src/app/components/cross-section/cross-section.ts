import { Component, inject, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';
import { GeometryCalcService } from '../../services/geometry-calc.service';

@Component({
  selector: 'app-cross-section',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-sky-400">stacked_line_chart</mat-icon>
            <h2 class="text-xl font-bold text-white">חתך אורך וחתך רוחב הנדסי</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            השוואת רום מסילה לפני שטח טבעיים (חפירה ומילוי), חתך מבנה עליון ותחתון, תעלות ניקוז ומעטפת גבול פנוי
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs text-slate-400">בדיקת חתך בק"מ:</span>
          <span class="font-mono text-sky-300 font-bold bg-slate-800 px-3 py-1 rounded-lg border border-slate-700">
            PK {{ Math.floor(inspectedChainage() / 1000) }}+{{ (inspectedChainage() % 1000).toString().padStart(3, '0') }}
          </span>
        </div>
      </div>

      <!-- 1. Longitudinal Profile Chart (חתך אורך) -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-4 shadow space-y-3">
        <div class="flex items-center justify-between">
          <span class="font-bold text-sm text-white flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-base leading-none">show_chart</mat-icon>
            חתך אורך - השוואת רום פסי מסילה מול מפלס קרקע טבעי
          </span>
          <div class="flex items-center gap-4 text-xs">
            <span class="flex items-center gap-1.5 text-sky-400">
              <span class="w-3 h-0.5 bg-sky-400"></span> רום מסילה (Track Bed)
            </span>
            <span class="flex items-center gap-1.5 text-amber-500">
              <span class="w-3 h-0.5 bg-amber-500 border-dashed"></span> קרקע טבעית (Natural Ground)
            </span>
            <span class="flex items-center gap-1.5 text-indigo-400">
              <span class="w-2.5 h-2.5 rounded bg-indigo-900/60 border border-indigo-500"></span> גשר / מנהרה
            </span>
          </div>
        </div>

        <!-- SVG Profile Canvas -->
        <div class="w-full h-56 bg-slate-900/80 rounded-xl border border-slate-700/80 p-2 relative overflow-hidden">
          <svg class="w-full h-full" viewBox="0 0 900 200" preserveAspectRatio="none">
            <!-- Grid lines -->
            <line x1="0" y1="40" x2="900" y2="40" stroke="#334155" stroke-width="0.5" stroke-dasharray="4" />
            <line x1="0" y1="80" x2="900" y2="80" stroke="#334155" stroke-width="0.5" stroke-dasharray="4" />
            <line x1="0" y1="120" x2="900" y2="120" stroke="#334155" stroke-width="0.5" stroke-dasharray="4" />
            <line x1="0" y1="160" x2="900" y2="160" stroke="#334155" stroke-width="0.5" stroke-dasharray="4" />

            <!-- Structure zones highlight -->
            <!-- Bridge PK 3+050 to 3+450 -> X: ~322 to 365 -->
            <rect x="323" y="10" width="42" height="180" fill="rgba(99, 102, 241, 0.15)" stroke="#6366f1" stroke-width="1" stroke-dasharray="3" />
            <text x="344" y="24" fill="#a5b4fc" font-size="9" text-anchor="middle" font-family="Assistant">גשר עמק מסילה</text>

            <!-- Tunnel PK 5+400 to 6+600 -> X: ~571 to 698 -->
            <rect x="571" y="10" width="127" height="180" fill="rgba(14, 165, 233, 0.12)" stroke="#0ea5e9" stroke-width="1" stroke-dasharray="3" />
            <text x="634" y="24" fill="#7dd3fc" font-size="9" text-anchor="middle" font-family="Assistant">מנהרת הר אודם</text>

            <!-- Ground elevation path -->
            <path [attr.d]="groundProfileSvgPath()" fill="none" stroke="#d97706" stroke-width="1.8" stroke-dasharray="2 2" />

            <!-- Track alignment elevation path -->
            <path [attr.d]="trackProfileSvgPath()" fill="none" stroke="#38bdf8" stroke-width="2.5" />

            <!-- Stations indicators -->
            <circle cx="127" cy="120" r="4" fill="#3b82f6" />
            <text x="127" y="108" fill="#93c5fd" font-size="8" text-anchor="middle" font-family="Assistant">תחנת דרום</text>

            <circle cx="783" cy="50" r="4" fill="#3b82f6" />
            <text x="783" y="38" fill="#93c5fd" font-size="8" text-anchor="middle" font-family="Assistant">תחנת צפון</text>

            <!-- Chainage probe cursor line -->
            <line [attr.x1]="probeSvgX()" y1="0" [attr.x2]="probeSvgX()" y2="200" stroke="#f43f5e" stroke-width="2" />
            <circle [attr.cx]="probeSvgX()" [attr.cy]="probeSvgY()" r="5" fill="#f43f5e" />
          </svg>
        </div>

        <!-- Chainage Probe Slider -->
        <div class="flex items-center gap-3 pt-1">
          <span class="text-xs text-slate-400">הזז סמן חתך:</span>
          <input
            type="range"
            min="0"
            max="8500"
            step="50"
            [value]="inspectedChainage()"
            (input)="onChainageInput($event)"
            class="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-400" />
          <span class="font-mono text-xs text-slate-300 w-24 text-left">8,500 מטר</span>
        </div>
      </div>

      <!-- 2. Parametric Cross-Section Diagram (חתך רוחב טיפוסי) -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- SVG Cross Section View -->
        <div class="lg:col-span-2 bg-slate-800/70 border border-slate-700/60 rounded-2xl p-4 shadow space-y-3">
          <div class="flex items-center justify-between">
            <span class="font-bold text-sm text-white flex items-center gap-2">
              <mat-icon class="text-sky-400 text-base leading-none">straighten</mat-icon>
              חתך רוחב מבנה מסילה כפולה (קנ״מ פרמטרי)
            </span>
            <span class="text-xs text-slate-400">תקן רכבת ישראל - 1435 מ"מ</span>
          </div>

          <!-- Cross section vector visualization -->
          <div class="w-full h-72 bg-slate-900/90 rounded-xl border border-slate-700/80 p-3 relative flex items-center justify-center">
            <svg class="w-full h-full max-w-xl" viewBox="0 0 600 300">
              <!-- Subgrade / Formation layer base (מפלס תת-מבנה) -->
              <polygon points="50,250 550,250 500,210 100,210" fill="#334155" stroke="#475569" stroke-width="1.5" />
              <text x="300" y="235" fill="#94a3b8" font-size="10" text-anchor="middle" font-family="Assistant">שכבת תת-מצע מהודקת (Subgrade Formation 1:1.5)</text>

              <!-- Ballast Bed prism (מצע חצץ בזלתי 350 מ"מ) -->
              <polygon points="100,210 500,210 460,165 140,165" fill="#475569" stroke="#64748b" stroke-width="1.5" />
              <text x="300" y="192" fill="#cbd5e1" font-size="11" text-anchor="middle" font-weight="bold" font-family="Assistant">חצץ מובחר (Ballast Bed 350mm)</text>

              <!-- Track 1 Sleepers & Rails (Center X = 230) -->
              <rect x="180" y="152" width="100" height="13" rx="2" fill="#cbd5e1" stroke="#94a3b8" stroke-width="1" />
              <!-- Rail left & right -->
              <rect x="202" y="138" width="6" height="14" fill="#38bdf8" />
              <rect x="252" y="138" width="6" height="14" fill="#38bdf8" />
              <text x="230" y="132" fill="#38bdf8" font-size="9" text-anchor="middle" font-mono>מסילה 1 (1435mm)</text>

              <!-- Track 2 Sleepers & Rails (Center X = 370) -->
              <rect x="320" y="152" width="100" height="13" rx="2" fill="#cbd5e1" stroke="#94a3b8" stroke-width="1" />
              <!-- Rail left & right -->
              <rect x="342" y="138" width="6" height="14" fill="#38bdf8" />
              <rect x="392" y="138" width="6" height="14" fill="#38bdf8" />
              <text x="370" y="132" fill="#38bdf8" font-size="9" text-anchor="middle" font-mono>מסילה 2 (1435mm)</text>

              <!-- Center spacing dimension line (4.50m) -->
              <line x1="230" y1="125" x2="370" y2="125" stroke="#f59e0b" stroke-width="1.5" marker-start="url(#dot)" marker-end="url(#dot)" />
              <text x="300" y="120" fill="#f59e0b" font-size="10" text-anchor="middle" font-family="Assistant" font-weight="bold">מרווח צירים 4.50 מ'</text>

              <!-- Kinematic clearance envelope (מעטפת מבנה פנוי TSI/GC) -->
              <path d="M 195 138 L 195 65 L 230 45 L 265 65 L 265 138 Z" fill="none" stroke="#ef4444" stroke-width="1.2" stroke-dasharray="4" />
              <path d="M 335 138 L 335 65 L 370 45 L 405 65 L 405 138 Z" fill="none" stroke="#ef4444" stroke-width="1.2" stroke-dasharray="4" />

              <!-- Catenary Pole on Right (עמוד חשמול OCS) -->
              <line x1="480" y1="210" x2="480" y2="30" stroke="#94a3b8" stroke-width="5" />
              <!-- Cantilever arm -->
              <line x1="480" y1="40" x2="230" y2="40" stroke="#64748b" stroke-width="2.5" />
              <!-- Contact wire drops -->
              <circle cx="230" cy="55" r="2.5" fill="#f59e0b" />
              <circle cx="370" cy="55" r="2.5" fill="#f59e0b" />
              <text x="495" y="45" fill="#94a3b8" font-size="9" font-family="Assistant">עמוד חשמול 25kV</text>

              <!-- Drainage Ditch on Left (תעלת ניקוז) -->
              <polygon points="50,250 80,275 100,250" fill="#1e293b" stroke="#0284c7" stroke-width="1.5" />
              <text x="75" y="290" fill="#38bdf8" font-size="9" text-anchor="middle" font-family="Assistant">תעלת ניקוז בטון</text>
            </svg>
          </div>
        </div>

        <!-- Probe Section Analysis Specs -->
        <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-4 shadow space-y-4">
          <span class="font-bold text-sm text-white flex items-center gap-1.5 pb-2 border-b border-slate-700">
            <mat-icon class="text-amber-400 text-sm">analytics</mat-icon>
            נתוני חתך בנקודת הבדיקה
          </span>

          <div class="space-y-2 text-xs">
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">מיקום שרשור:</span>
              <span class="font-mono text-white font-bold">
                PK {{ Math.floor(inspectedChainage() / 1000) }}+{{ (inspectedChainage() % 1000).toString().padStart(3, '0') }}
              </span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">רום מסילה מתוכנן:</span>
              <span class="font-mono text-sky-400 font-bold">{{ currentTrackElevation().toFixed(2) }} מטר</span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">רום קרקע טבעית:</span>
              <span class="font-mono text-amber-400 font-bold">{{ currentGroundElevation().toFixed(2) }} מטר</span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">סטטוס עבודות עפר:</span>
              @if (currentElevationDiff() > 0) {
                <span class="font-bold text-emerald-400">מילוי סוללה (Fill) +{{ currentElevationDiff().toFixed(2) }} מ'</span>
              } @else {
                <span class="font-bold text-amber-400">חפירה / חציבה (Cut) {{ currentElevationDiff().toFixed(2) }} מ'</span>
              }
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">שיפוע אורכי:</span>
              <span class="font-mono text-slate-200 font-bold">{{ currentPoint().gradePercent.toFixed(2) }}%</span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">הגבהת מסילה (Cant):</span>
              <span class="font-mono text-sky-300 font-bold">{{ currentPoint().cantMm }} מ"מ</span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">רוחב כתר מצע מסילה:</span>
              <span class="font-mono text-slate-200">8.80 מטר</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CrossSection {
  readonly state = inject(RailwayStateService);
  private readonly geoCalc = inject(GeometryCalcService);
  readonly Math = Math;

  readonly inspectedChainage = signal<number>(2400);

  onChainageInput(e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    this.inspectedChainage.set(val);
  }

  readonly currentPoint = computed(() => {
    return this.geoCalc.interpolateAlignment(this.state.alignmentPoints(), this.inspectedChainage());
  });

  readonly currentTrackElevation = computed(() => {
    return this.currentPoint().y;
  });

  readonly currentGroundElevation = computed(() => {
    const pt = this.currentPoint();
    return this.geoCalc.getNaturalGroundElevation(pt.x, pt.z);
  });

  readonly currentElevationDiff = computed(() => {
    return this.currentTrackElevation() - this.currentGroundElevation();
  });

  readonly probeSvgX = computed(() => {
    const ch = this.inspectedChainage();
    return (ch / 8500) * 900;
  });

  readonly probeSvgY = computed(() => {
    // Map track elevation (range ~20m to 90m) to SVG height 180 to 20
    const elev = this.currentTrackElevation();
    return 190 - ((elev - 20) / 75) * 160;
  });

  readonly trackProfileSvgPath = computed(() => {
    const points = this.state.alignmentPoints();
    let d = '';
    const samples = 120;
    for (let i = 0; i <= samples; i++) {
      const ch = (i / samples) * 8500;
      const pt = this.geoCalc.interpolateAlignment(points, ch);
      const x = (ch / 8500) * 900;
      const y = 190 - ((pt.y - 20) / 75) * 160;
      d += i === 0 ? `M ${x.toFixed(1)} ${y.toFixed(1)}` : ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
    }
    return d;
  });

  readonly groundProfileSvgPath = computed(() => {
    const points = this.state.alignmentPoints();
    let d = '';
    const samples = 120;
    for (let i = 0; i <= samples; i++) {
      const ch = (i / samples) * 8500;
      const pt = this.geoCalc.interpolateAlignment(points, ch);
      const gY = this.geoCalc.getNaturalGroundElevation(pt.x, pt.z);
      const x = (ch / 8500) * 900;
      const y = 190 - ((gY - 20) / 75) * 160;
      d += i === 0 ? `M ${x.toFixed(1)} ${y.toFixed(1)}` : ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
    }
    return d;
  });
}
