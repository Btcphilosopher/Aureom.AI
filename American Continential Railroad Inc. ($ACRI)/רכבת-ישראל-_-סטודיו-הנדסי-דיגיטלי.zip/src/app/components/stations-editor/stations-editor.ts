import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';

@Component({
  selector: 'app-stations-editor',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-sky-400">domain</mat-icon>
            <h2 class="text-xl font-bold text-white">תחנות נוסעים ומבנים הנדסיים</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            תכנון רציפים, גבהי מדרך מעל ראש מסילה (760/960 מ"מ), גשרי הולכי רגל, גשר עמק מסילה ומנהרת הר אודם
          </p>
        </div>
      </div>

      <!-- Stations Cards Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        @for (st of state.stations(); track st.id) {
          <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-slate-700">
              <div class="flex items-center gap-2">
                <mat-icon class="text-sky-400">apartment</mat-icon>
                <div>
                  <h3 class="font-bold text-white text-base">{{ st.name }}</h3>
                  <span class="text-xs text-slate-400 font-mono">
                    מיקום: ק"מ {{ (st.chainageStart / 1000).toFixed(3) }} - {{ (st.chainageEnd / 1000).toFixed(3) }}
                  </span>
                </div>
              </div>
              <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-900/60 text-emerald-300 border border-emerald-700/40">
                {{ st.operationalStatus }}
              </span>
            </div>

            <!-- Platform Configuration -->
            <div class="space-y-3">
              <span class="text-xs font-bold text-slate-300 block">תצורת רציפים וגובה מדרך:</span>
              @for (pl of st.platforms; track pl.id) {
                <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-700/60 space-y-2 text-xs">
                  <div class="flex justify-between items-center">
                    <span class="font-bold text-white">{{ pl.name }}</span>
                    <span class="text-slate-400">{{ pl.isIsland ? 'רציף אי מרכזי' : 'רציף צד' }}</span>
                  </div>

                  <div class="grid grid-cols-3 gap-2 text-[11px]">
                    <div>
                      <span class="text-slate-400 block">אורך רציף</span>
                      <span class="font-mono text-white font-bold">{{ pl.length }} מטר</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block">רוחב רציף</span>
                      <span class="font-mono text-white font-bold">{{ pl.width }} מטר</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block">גובה מדרך מעל פס</span>
                      <span class="font-mono text-amber-400 font-bold">{{ pl.heightAboveRailMm }} מ"מ</span>
                    </div>
                  </div>

                  <!-- Quick platform height selector standard buttons -->
                  <div class="flex items-center gap-2 pt-1 border-t border-slate-800">
                    <span class="text-slate-400 text-[10px]">החלף גובה תקני:</span>
                    <button
                      type="button"
                      (click)="setPlatformHeight(st.id, 760)"
                      [class.bg-[#245B85]]="pl.heightAboveRailMm === 760"
                      [class.text-white]="pl.heightAboveRailMm === 760"
                      class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 text-[10px]">
                      760 מ"מ (אירופי/TSI)
                    </button>
                    <button
                      type="button"
                      (click)="setPlatformHeight(st.id, 960)"
                      [class.bg-[#245B85]]="pl.heightAboveRailMm === 960"
                      [class.text-white]="pl.heightAboveRailMm === 960"
                      class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 text-[10px]">
                      960 מ"מ (רכבת ישראל)
                    </button>
                  </div>
                </div>
              }
            </div>

            <!-- Facilities checklist -->
            <div class="grid grid-cols-2 gap-2 text-xs pt-2">
              <div class="flex items-center gap-1.5 text-slate-300">
                <mat-icon class="text-emerald-400 text-sm">check_circle</mat-icon>
                <span>גשר הולכי רגל מקורה: {{ st.hasPedestrianOverpass ? 'כלול' : 'ללא' }}</span>
              </div>
              <div class="flex items-center gap-1.5 text-slate-300">
                <mat-icon class="text-emerald-400 text-sm">check_circle</mat-icon>
                <span>מעליות שקופות נגישות: {{ st.hasElevatorShafts ? 'מתוכנן' : 'ללא' }}</span>
              </div>
              <div class="flex items-center gap-1.5 text-slate-300">
                <mat-icon class="text-sky-400 text-sm">local_parking</mat-icon>
                <span>חניון רכבים: {{ st.parkingSpaces }} מקומות</span>
              </div>
              <div class="flex items-center gap-1.5 text-slate-300">
                <mat-icon class="text-amber-400 text-sm">square_foot</mat-icon>
                <span>שטח טרמינל: {{ st.bldgFootprintSqM }} מ"ר</span>
              </div>
            </div>
          </div>
        }
      </div>

      <!-- Civil Engineering Structures (Bridge & Tunnel) -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        <!-- Bridge Structure Card -->
        <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-700">
            <div class="flex items-center gap-2">
              <mat-icon class="text-indigo-400">architecture</mat-icon>
              <div>
                <h3 class="font-bold text-white text-base">{{ state.bridge().name }}</h3>
                <span class="text-xs text-slate-400 font-mono">
                  ק"מ {{ (state.bridge().chainageStart / 1000).toFixed(3) }} - {{ (state.bridge().chainageEnd / 1000).toFixed(3) }}
                </span>
              </div>
            </div>
            <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-900/60 text-indigo-300 border border-indigo-700/40">
              {{ state.bridge().structureType }}
            </span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">אורך גשר</span>
              <span class="font-mono text-white font-bold text-sm">{{ state.bridge().lengthMeters }} מטר</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">מספר מפתחים</span>
              <span class="font-mono text-white font-bold text-sm">{{ state.bridge().spanCount }}</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">רוחב מיסעה</span>
              <span class="font-mono text-white font-bold text-sm">{{ state.bridge().deckWidthM }} מטר</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">גובה עמוד מרבי</span>
              <span class="font-mono text-white font-bold text-sm">{{ state.bridge().pierHeightMaxM }} מטר</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">כושר נשיאה תכן</span>
              <span class="font-mono text-white font-bold text-sm">{{ state.bridge().bearingCapacityTonnes }} טון</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">מרווח מתחת לגשר</span>
              <span class="font-mono text-emerald-400 font-bold text-sm">{{ state.bridge().clearanceUnderDeckM.toFixed(1) }} מטר</span>
            </div>
          </div>

          <!-- Bridge Clearance adjustment slider -->
          <div class="space-y-1.5 pt-2 border-t border-slate-700/60 text-xs">
            <div class="flex justify-between">
              <span class="text-slate-300">כוונון מרווח אנכי תחת הגשר (Clearance):</span>
              <span class="font-mono font-bold text-sky-400">{{ state.bridge().clearanceUnderDeckM.toFixed(1) }} מטר</span>
            </div>
            <input
              type="range"
              min="5.0"
              max="9.0"
              step="0.2"
              [value]="state.bridge().clearanceUnderDeckM"
              (input)="onBridgeClearanceChange($event)"
              class="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-400" />
            <span class="text-[10px] text-slate-400 block">ערך קטן מ-5.8 מ' יפעיל התרעת התנגשות אוטומטית במנוע הבדיקות</span>
          </div>
        </div>

        <!-- Tunnel Structure Card -->
        <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-700">
            <div class="flex items-center gap-2">
              <mat-icon class="text-sky-400">tunnel</mat-icon>
              <div>
                <h3 class="font-bold text-white text-base">{{ state.tunnel().name }}</h3>
                <span class="text-xs text-slate-400 font-mono">
                  ק"מ {{ (state.tunnel().chainageStart / 1000).toFixed(3) }} - {{ (state.tunnel().chainageEnd / 1000).toFixed(3) }}
                </span>
              </div>
            </div>
            <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-sky-900/60 text-sky-300 border border-sky-700/40">
              {{ state.tunnel().crossSectionType }}
            </span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">אורך מנהרה</span>
              <span class="font-mono text-white font-bold text-sm">{{ state.tunnel().lengthMeters }} מטר</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">קוטר פנימי (TBM)</span>
              <span class="font-mono text-white font-bold text-sm">{{ state.tunnel().innerDiameterM }} מטר</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">עומק כיסוי סלע מרבי</span>
              <span class="font-mono text-white font-bold text-sm">{{ state.tunnel().coverDepthMaxM }} מטר</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">מעברי מילוט (Cross-Passages)</span>
              <span class="font-mono text-white font-bold text-sm">כל {{ state.tunnel().crossPassageSpacingM }} מ'</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">מערכת אוורור</span>
              <span class="font-mono text-emerald-400 font-bold text-sm">מפוחי סילון תקניים</span>
            </div>
            <div class="bg-slate-900/50 p-2.5 rounded-xl border border-slate-700/60">
              <span class="text-slate-400 block text-[10px]">דיפון בטון</span>
              <span class="font-mono text-white font-bold text-sm">טבעות טרומיות B60</span>
            </div>
          </div>

          <div class="bg-slate-900/40 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-300">
            <span class="font-bold text-sky-400 block mb-1">הנחיות בטיחות מנהרות רכבת:</span>
            התוואי מתוכנן בהתאם לתקן TSI SRT (בטיחות במנהרות רכבת). כולל שבילי פינוי מוארים, קווי מים לכיבוי אש ורשת תקשורת חירום אלחוטית GSM-R.
          </div>
        </div>
      </div>
    </div>
  `
})
export class StationsEditor {
  readonly state = inject(RailwayStateService);

  setPlatformHeight(stationId: string, heightMm: number): void {
    this.state.updatePlatformHeight(stationId, heightMm);
  }

  onBridgeClearanceChange(e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.updateBridgeClearance(val);
  }
}
