import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';

@Component({
  selector: 'app-gantt-schedule',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400">calendar_month</mat-icon>
            <h2 class="text-xl font-bold text-white">ניהול פרויקט, לוח זמנים ותרשים גאנט (4D)</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            מעקב 10 שלבי הקמה, תלויות הנדסיות, נתיב קריטי (Critical Path), התקדמות שבועית וקישור לתאום הדיגיטלי
          </p>
        </div>

        <div class="flex items-center gap-3">
          <div class="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs">
            <span class="text-slate-400">התקדמות פרויקט כוללת:</span>
            <span class="font-bold text-emerald-400 font-mono mr-1.5 text-sm">{{ state.overallProgressPercent() }}%</span>
          </div>
        </div>
      </div>

      <!-- 10 Phases Grid / Stage Selector Ribbon -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-4 shadow space-y-3">
        <span class="text-xs font-bold text-slate-200 block">בחר שלב ביצוע להצגה במודל 3D (סימולטור 4D):</span>
        <div class="grid grid-cols-2 sm:grid-cols-5 gap-2">
          @for (phase of state.constructionPhases(); track phase.stageNumber) {
            <button
              type="button"
              (click)="selectPhase(phase.stageNumber)"
              class="p-2.5 rounded-xl border text-right transition-all flex flex-col justify-between"
              [class.bg-[#245B85]]="state.activeConstructionPhase() === phase.stageNumber"
              [class.border-sky-400]="state.activeConstructionPhase() === phase.stageNumber"
              [class.bg-slate-900/60]="state.activeConstructionPhase() !== phase.stageNumber"
              [class.border-slate-700]="state.activeConstructionPhase() !== phase.stageNumber">
              <div>
                <span class="text-[10px] text-slate-400 font-mono block">שלב {{ phase.stageNumber }}</span>
                <span class="text-xs font-bold text-white block truncate">{{ phase.name }}</span>
              </div>
              <div class="flex items-center justify-between mt-2 pt-1 border-t border-slate-700/60 text-[10px]">
                <span [class.text-emerald-400]="phase.status === 'הושלם'"
                      [class.text-amber-400]="phase.status === 'בביצוע'"
                      [class.text-slate-400]="phase.status === 'מתוכנן'">
                  {{ phase.status }}
                </span>
                <span class="font-mono text-slate-300">{{ phase.progressPercent }}%</span>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Interactive Gantt Chart Table & Timeline Bars -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl overflow-hidden shadow">
        <div class="p-4 bg-slate-800/90 border-b border-slate-700/60 flex items-center justify-between">
          <div>
            <span class="font-bold text-sm text-white block">תרשים גאנט לפרויקט (112 שבועות הקמה)</span>
            <span class="text-xs text-slate-400">אבני דרך, משכי פעילויות ותלויות בין דיסציפלינות</span>
          </div>
          <div class="flex items-center gap-4 text-xs">
            <span class="flex items-center gap-1.5 text-rose-400">
              <span class="w-3 h-2 rounded bg-rose-500"></span> נתיב קריטי (Critical Path)
            </span>
            <span class="flex items-center gap-1.5 text-sky-400">
              <span class="w-3 h-2 rounded bg-sky-500"></span> פעילות רגילה
            </span>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-right text-xs">
            <thead class="bg-slate-900/80 text-slate-400 uppercase text-[10px] border-b border-slate-700/60 font-mono">
              <tr>
                <th class="p-3 w-48">שם פעילות</th>
                <th class="p-3 w-28">תחום מקצועי</th>
                <th class="p-3 w-16">שלב</th>
                <th class="p-3 w-16">שבועות</th>
                <th class="p-3 w-16">התקדמות</th>
                <th class="p-3 w-24">אומדן (₪)</th>
                <th class="p-3 min-w-[360px]">ציר זמן (שבועות 1 עד 112)</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-700/40">
              @for (task of state.ganttTasks(); track task.id) {
                <tr class="hover:bg-slate-750/50 transition-colors">
                  <td class="p-3 font-medium text-white flex items-center gap-1.5">
                    @if (task.isCritical) {
                      <span class="w-1.5 h-1.5 rounded-full bg-rose-500" title="נתיב קריטי"></span>
                    }
                    {{ task.name }}
                  </td>
                  <td class="p-3 text-slate-300 text-[11px]">{{ task.responsibleDiscipline }}</td>
                  <td class="p-3 font-mono text-slate-400">{{ task.stageNumber }}</td>
                  <td class="p-3 font-mono text-slate-300">{{ task.durationWeeks }} שבועות</td>
                  <td class="p-3 font-mono">
                    <span [class.text-emerald-400]="task.progressPercent === 100"
                          [class.text-amber-400]="task.progressPercent > 0 && task.progressPercent < 100"
                          [class.text-slate-400]="task.progressPercent === 0"
                          class="font-bold">
                      {{ task.progressPercent }}%
                    </span>
                  </td>
                  <td class="p-3 font-mono text-slate-300">{{ (task.costEstimatedNis / 1000000).toFixed(1) }}M ₪</td>
                  <td class="p-3">
                    <!-- Gantt Bar -->
                    <div class="relative w-full h-5 bg-slate-900 rounded overflow-hidden">
                      <div
                        class="absolute top-0.5 bottom-0.5 rounded shadow text-[9px] font-mono flex items-center px-1.5 text-white"
                        [class.bg-rose-600]="task.isCritical"
                        [class.bg-[#245B85]]="!task.isCritical"
                        [style.left.%]="(task.startWeek / 112) * 100"
                        [style.width.%]="(task.durationWeeks / 112) * 100">
                        {{ task.startWeek }}-{{ task.endWeek }}
                      </div>
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class GanttSchedule {
  readonly state = inject(RailwayStateService);

  selectPhase(stageNumber: number): void {
    this.state.set4DConstructionPhase(stageNumber);
  }
}
