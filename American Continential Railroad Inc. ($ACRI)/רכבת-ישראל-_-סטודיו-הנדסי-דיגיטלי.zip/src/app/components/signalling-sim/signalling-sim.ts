import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';

@Component({
  selector: 'app-signalling-sim',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400">traffic</mat-icon>
            <h2 class="text-xl font-bold text-white">איתות ובקרה — סימולציית תנועת רכבות (ETCS L2)</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            מעקב תפוסת מקטעי מסילה (Block Sections), היבטי אותות רמזורים, מהירות תנועה ומרווחי בטיחות (Headway)
          </p>
        </div>

        <!-- Simulation master control bar -->
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="state.toggleTrainSim()"
            [class.bg-emerald-600]="!state.isTrainSimRunning()"
            [class.bg-amber-600]="state.isTrainSimRunning()"
            class="px-3.5 py-1.5 rounded-xl text-white font-medium text-xs flex items-center gap-1.5 shadow transition-colors">
            <mat-icon class="text-sm w-4 h-4 leading-none">
              {{ state.isTrainSimRunning() ? 'pause' : 'play_arrow' }}
            </mat-icon>
            <span>{{ state.isTrainSimRunning() ? 'השהה תנועה' : 'הפעל תנועה' }}</span>
          </button>

          <div class="flex items-center bg-slate-800 border border-slate-700 rounded-xl p-0.5 text-xs">
            <button
              type="button"
              (click)="state.setTrainSimSpeed(1)"
              [class.bg-[#245B85]]="state.trainSimSpeedMultiplier() === 1"
              class="px-2 py-1 rounded-lg text-slate-300">1x</button>
            <button
              type="button"
              (click)="state.setTrainSimSpeed(2)"
              [class.bg-[#245B85]]="state.trainSimSpeedMultiplier() === 2"
              class="px-2 py-1 rounded-lg text-slate-300">2x</button>
            <button
              type="button"
              (click)="state.setTrainSimSpeed(4)"
              [class.bg-[#245B85]]="state.trainSimSpeedMultiplier() === 4"
              class="px-2 py-1 rounded-lg text-slate-300">4x</button>
          </div>
        </div>
      </div>

      <!-- Safety Disclaimer Banner (Mandatory as per instructions) -->
      <div class="bg-amber-950/40 border border-amber-600/60 rounded-xl p-3 flex items-start gap-2.5 text-xs text-amber-200">
        <mat-icon class="text-amber-400 shrink-0 text-base">gpp_maybe</mat-icon>
        <div>
          <span class="font-bold block">הבהרת בטיחות הנדסית:</span>
          מנוע סימולציה זה מיועד לצורכי תכנון, הדרכה, בדיקת קיבולת והמחשה חזותית בלבד. המערכת אינה מחוברת למערכות איתות, נעילה (Interlocking), פיקוד רכבות ארצי או תשתית תפעולית חיה, ואין להציגה כמערכת בטיחות מוסמכת.
        </div>
      </div>

      <!-- Live Signalling Track Block Schematic Diagram -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
        <div class="flex items-center justify-between">
          <span class="font-bold text-sm text-white flex items-center gap-2">
            <mat-icon class="text-sky-400 text-sm">linear_scale</mat-icon>
            סכמת מקטעי חסימה ואיתות בלוקים (ETCS Level 2 Block Occupancy)
          </span>
          <span class="text-xs text-slate-400">אורך מסדרון: 8.5 ק"מ (מסילה כפולה)</span>
        </div>

        <!-- Schematic Visualizer -->
        <div class="space-y-3">
          @for (blk of state.signallingBlocks(); track blk.id) {
            <div class="bg-slate-900/80 border border-slate-700/70 rounded-xl p-3.5 space-y-2">
              <div class="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div class="flex items-center gap-2">
                  <!-- Signal Lamp Aspect Graphic -->
                  <div class="flex items-center gap-1 bg-black px-2 py-1 rounded-md border border-slate-700">
                    <span class="w-3 h-3 rounded-full"
                          [class.bg-emerald-500]="blk.aspect === 'GREEN'"
                          [class.bg-slate-700]="blk.aspect !== 'GREEN'"></span>
                    <span class="w-3 h-3 rounded-full"
                          [class.bg-yellow-400]="blk.aspect === 'YELLOW' || blk.aspect === 'DOUBLE_YELLOW'"
                          [class.bg-slate-700]="blk.aspect !== 'YELLOW' && blk.aspect !== 'DOUBLE_YELLOW'"></span>
                    <span class="w-3 h-3 rounded-full"
                          [class.bg-red-500]="blk.aspect === 'RED'"
                          [class.bg-slate-700]="blk.aspect !== 'RED'"></span>
                  </div>

                  <span class="font-bold text-white text-sm">{{ blk.name }}</span>
                  <span class="text-slate-400 font-mono text-[11px]">
                    (ק"מ {{ (blk.chainageStart / 1000).toFixed(1) }} - {{ (blk.chainageEnd / 1000).toFixed(1) }})
                  </span>
                </div>

                <div class="flex items-center gap-3">
                  <span class="text-slate-400 text-[11px]">מהירות מותרת:</span>
                  <span class="font-mono text-emerald-400 font-bold text-xs">{{ blk.speedLimitKmh }} קמ"ש</span>
                  <span class="text-slate-400 text-[11px]">מערכת:</span>
                  <span class="text-sky-300 font-medium text-xs">{{ blk.baliseType }}</span>
                </div>
              </div>

              <!-- Occupancy Bar -->
              <div class="relative w-full h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <!-- Check if any train is currently in this block -->
                @for (tr of state.trains(); track tr.id) {
                  @if (tr.chainagePositionM >= blk.chainageStart && tr.chainagePositionM <= blk.chainageEnd) {
                    <div
                      class="absolute top-0 bottom-0 rounded-full shadow transition-all duration-300"
                      [class.bg-blue-500]="tr.id === 'TR-101'"
                      [class.bg-purple-500]="tr.id === 'TR-102'"
                      [style.left.%]="((tr.chainagePositionM - blk.chainageStart) / (blk.chainageEnd - blk.chainageStart)) * 100"
                      style="width: 18px; transform: translateX(-50%);">
                    </div>
                  }
                }
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Live Trains Fleet Table & Telemetry -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-700">
          <div class="flex items-center gap-2">
            <mat-icon class="text-sky-400">train</mat-icon>
            <h3 class="font-bold text-white text-base">מעקב צי רכבות חי בסימולציה</h3>
          </div>
          <span class="text-xs text-slate-400">{{ state.trains().length }} רכבות פעילות בתוואי</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          @for (tr of state.trains(); track tr.id) {
            <div class="bg-slate-900/70 border border-slate-700/70 rounded-xl p-4 space-y-3 text-xs">
              <div class="flex items-center justify-between">
                <div>
                  <span class="font-bold text-white text-sm block">{{ tr.name }}</span>
                  <span class="text-sky-400 font-mono text-[11px]">{{ tr.code }} • {{ tr.trainType }}</span>
                </div>
                <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-900/60 text-emerald-300 border border-emerald-700/40">
                  {{ tr.status }}
                </span>
              </div>

              <div class="grid grid-cols-3 gap-2">
                <div class="bg-slate-800/60 p-2 rounded">
                  <span class="text-slate-400 block text-[10px]">מיקום נוכחי</span>
                  <span class="font-mono text-white font-bold text-xs">
                    PK {{ Math.floor(tr.chainagePositionM / 1000) }}+{{ Math.floor(tr.chainagePositionM % 1000).toString().padStart(3, '0') }}
                  </span>
                </div>
                <div class="bg-slate-800/60 p-2 rounded">
                  <span class="text-slate-400 block text-[10px]">מהירות נסיעה</span>
                  <span class="font-mono text-emerald-400 font-bold text-xs">{{ tr.currentSpeedKmh }} קמ"ש</span>
                </div>
                <div class="bg-slate-800/60 p-2 rounded">
                  <span class="text-slate-400 block text-[10px]">כיוון תנועה</span>
                  <span class="font-mono text-sky-300 font-bold text-xs">{{ tr.direction === 1 ? 'צפונה (גליל)' : 'דרומה (מרכז)' }}</span>
                </div>
              </div>

              <div class="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800">
                <span>אורך רכבת: {{ tr.totalLengthM }} מ' ({{ tr.carsCount }} קרונות)</span>
                <span>קיבולת: {{ tr.passengerCapacity }} נוסעים</span>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class SignallingSim {
  readonly state = inject(RailwayStateService);
  readonly Math = Math;
}
