import { Component, inject, ChangeDetectionStrategy, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';

@Component({
  selector: 'app-boq-estimator',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400">calculate</mat-icon>
            <h2 class="text-xl font-bold text-white">כמויות, עלויות ואומדן תקציבי הנדסי (BoQ)</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            חישוב פרמטרי ישיר מתוך הגאומטריה והמודל: נפחי עפר, חצץ, מסילות, בטון לגשר ומנהרה, עמודי חשמול ואיתות
          </p>
        </div>

        <div class="flex items-center gap-3">
          <div class="bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-right">
            <span class="text-[11px] text-slate-400 block">אומדן עלות ישירה כוללת:</span>
            <span class="font-bold text-emerald-400 font-mono text-xl leading-tight">
              {{ (state.totalBoQCostNis() / 1000000).toFixed(1) }} מיליון ₪
            </span>
          </div>
        </div>
      </div>

      <!-- Cost Breakdown by Engineering Discipline -->
      <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">עבודות עפר וקרקע</span>
          <span class="text-base font-bold font-mono text-white">{{ (categoryCosts()['עבודות עפר'] / 1000000).toFixed(1) }}M ₪</span>
          <span class="text-[10px] text-sky-400 block">{{ ((categoryCosts()['עבודות עפר'] / state.totalBoQCostNis()) * 100).toFixed(1) }}% מהפרויקט</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">מבנים, גשר ומנהרה</span>
          <span class="text-base font-bold font-mono text-white">{{ (categoryCosts()['מבנים וגישור'] / 1000000).toFixed(1) }}M ₪</span>
          <span class="text-[10px] text-sky-400 block">{{ ((categoryCosts()['מבנים וגישור'] / state.totalBoQCostNis()) * 100).toFixed(1) }}% מהפרויקט</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">מסילאות ומבנה עליון</span>
          <span class="text-base font-bold font-mono text-white">{{ (categoryCosts()['מסילאות'] / 1000000).toFixed(1) }}M ₪</span>
          <span class="text-[10px] text-sky-400 block">{{ ((categoryCosts()['מסילאות'] / state.totalBoQCostNis()) * 100).toFixed(1) }}% מהפרויקט</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">מערך חשמול 25kV</span>
          <span class="text-base font-bold font-mono text-white">{{ (categoryCosts()['חשמול'] / 1000000).toFixed(1) }}M ₪</span>
          <span class="text-[10px] text-sky-400 block">{{ ((categoryCosts()['חשמול'] / state.totalBoQCostNis()) * 100).toFixed(1) }}% מהפרויקט</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">איתות ותחנות נוסעים</span>
          <span class="text-base font-bold font-mono text-white">{{ (categoryCosts()['איתות ותחנות'] / 1000000).toFixed(1) }}M ₪</span>
          <span class="text-[10px] text-sky-400 block">{{ ((categoryCosts()['איתות ותחנות'] / state.totalBoQCostNis()) * 100).toFixed(1) }}% מהפרויקט</span>
        </div>
      </div>

      <!-- Bill of Quantities Items Table -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl overflow-hidden shadow">
        <div class="p-4 bg-slate-800/90 border-b border-slate-700/60 flex items-center justify-between">
          <span class="font-bold text-sm text-white">כתב כמויות מפורט לפרויקט (Bill of Quantities)</span>
          <span class="text-xs text-slate-400">כולל מקדם אי-ודאות הנדסי (Uncertainty Buffer)</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-right text-xs">
            <thead class="bg-slate-900/80 text-slate-400 uppercase text-[10px] border-b border-slate-700/60 font-mono">
              <tr>
                <th class="p-3 w-28">סעיף BoQ</th>
                <th class="p-3">תיאור העבודה / החומר</th>
                <th class="p-3 w-32">קטגוריה</th>
                <th class="p-3 w-20">יחידה</th>
                <th class="p-3 w-28">כמות מחושבת</th>
                <th class="p-3 w-28">מחיר יח' (₪)</th>
                <th class="p-3 w-36">סה״כ עלות (₪)</th>
                <th class="p-3 w-24">אי-ודאות</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-700/40">
              @for (item of state.boqRecords(); track item.itemCode) {
                <tr class="hover:bg-slate-750/50 transition-colors">
                  <td class="p-3 font-mono text-sky-400 font-bold">{{ item.itemCode }}</td>
                  <td class="p-3 font-medium text-white">
                    {{ item.description }}
                    @if (item.isParametric) {
                      <span class="mr-1.5 px-1.5 py-0.2 rounded bg-sky-950 text-sky-300 border border-sky-800 text-[9px]">
                        פרמטרי
                      </span>
                    }
                  </td>
                  <td class="p-3 text-slate-300 text-[11px]">{{ item.category }}</td>
                  <td class="p-3 font-mono text-slate-400">{{ item.unit }}</td>
                  <td class="p-3 font-mono text-white font-bold">{{ item.calculatedQuantity.toLocaleString() }}</td>
                  <td class="p-3 font-mono text-slate-300">{{ item.unitPriceNis.toLocaleString() }} ₪</td>
                  <td class="p-3 font-mono text-emerald-400 font-bold">{{ item.totalPriceNis.toLocaleString() }} ₪</td>
                  <td class="p-3 font-mono text-amber-400">±{{ item.uncertaintyMarginPercent }}%</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class BoQEstimator {
  readonly state = inject(RailwayStateService);

  readonly categoryCosts = computed(() => {
    const records = this.state.boqRecords();
    const map: Record<string, number> = {
      'עבודות עפר': 0,
      'מבנים וגישור': 0,
      'מסילאות': 0,
      'חשמול': 0,
      'איתות ותחנות': 0
    };
    records.forEach((r) => {
      if (map[r.category] !== undefined) {
        map[r.category] += r.totalPriceNis;
      }
    });
    return map;
  });
}
