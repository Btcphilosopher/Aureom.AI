import { Component, inject, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';

@Component({
  selector: 'app-reports-export',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-sky-400">assessment</mat-icon>
            <h2 class="text-xl font-bold text-white">דוחות הנדסיים, ייצוא נתונים וארכיטקטורת אנדרואיד</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            הפקת דוח מסכם בעברית, ייצוא נתוני תאום דיגיטלי ל-JSON ו-CSV, ומפרט ארכיטקטורת Kotlin/Jetpack Compose
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="exportJson()"
            class="bg-[#245B85] hover:bg-sky-600 text-white px-3.5 py-1.5 rounded-xl font-medium text-xs flex items-center gap-1.5 shadow transition-colors">
            <mat-icon class="text-sm w-4 h-4 leading-none">download</mat-icon>
            ייצא מודל מלא (JSON)
          </button>
          <button
            type="button"
            (click)="exportCsv()"
            class="bg-slate-700 hover:bg-slate-600 text-white px-3.5 py-1.5 rounded-xl font-medium text-xs flex items-center gap-1.5 shadow transition-colors">
            <mat-icon class="text-sm w-4 h-4 leading-none">table_view</mat-icon>
            ייצא כתב כמויות (CSV)
          </button>
        </div>
      </div>

      <!-- Engineering Summary Dossier -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-700">
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400">verified</mat-icon>
            <h3 class="font-bold text-white text-base">תמצית תיק תכנון הנדסי — רכבת ישראל</h3>
          </div>
          <span class="text-xs font-mono text-slate-400">גרסה: {{ state.project().engineeringVersion }}</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div class="bg-slate-900/50 p-3 rounded-xl border border-slate-800 space-y-1.5">
            <span class="text-slate-400 block font-bold text-[11px]">מפרט מסדרון ומסילאות</span>
            <div class="flex justify-between"><span class="text-slate-400">שם הפרויקט:</span><span class="text-white font-medium">{{ state.project().name }}</span></div>
            <div class="flex justify-between"><span class="text-slate-400">אורך כולל:</span><span class="font-mono text-sky-400 font-bold">8.50 ק"מ</span></div>
            <div class="flex justify-between"><span class="text-slate-400">רוחב מסילה:</span><span class="font-mono text-white">1,435 מ"מ (Standard Gauge)</span></div>
            <div class="flex justify-between"><span class="text-slate-400">תצורת מסילה:</span><span class="text-white">מסילה כפולה (Double Track)</span></div>
            <div class="flex justify-between"><span class="text-slate-400">תקן תכן:</span><span class="text-white">{{ state.project().designStandard }}</span></div>
          </div>

          <div class="bg-slate-900/50 p-3 rounded-xl border border-slate-800 space-y-1.5">
            <span class="text-slate-400 block font-bold text-[11px]">מבנים הנדסיים ותחנות</span>
            <div class="flex justify-between"><span class="text-slate-400">תחנות נוסעים:</span><span class="text-white font-bold">2 תחנות (דרום וצפון)</span></div>
            <div class="flex justify-between"><span class="text-slate-400">רציפי נוסעים:</span><span class="text-white">350 מטר (גובה 960 מ"מ)</span></div>
            <div class="flex justify-between"><span class="text-slate-400">גשר עמק מסילה:</span><span class="font-mono text-white font-bold">400 מטר (8 מפתחים)</span></div>
            <div class="flex justify-between"><span class="text-slate-400">מנהרת הר אודם:</span><span class="font-mono text-white font-bold">1,200 מטר (TBM 9.8m)</span></div>
            <div class="flex justify-between"><span class="text-slate-400">מרווח תחת גשר:</span><span class="font-mono text-emerald-400 font-bold">{{ state.bridge().clearanceUnderDeckM.toFixed(1) }} מטר</span></div>
          </div>

          <div class="bg-slate-900/50 p-3 rounded-xl border border-slate-800 space-y-1.5">
            <span class="text-slate-400 block font-bold text-[11px]">מערכות, שלד ותקציב</span>
            <div class="flex justify-between"><span class="text-slate-400">מערכת חשמול:</span><span class="text-amber-400 font-bold">25kV AC (50Hz) OCS</span></div>
            <div class="flex justify-between"><span class="text-slate-400">עמודי חשמול:</span><span class="font-mono text-white">{{ state.catenary().totalMastsCount }} עמודים</span></div>
            <div class="flex justify-between"><span class="text-slate-400">מערכת איתות:</span><span class="text-white font-bold">ETCS Level 2 + GSM-R</span></div>
            <div class="flex justify-between"><span class="text-slate-400">התקדמות 4D:</span><span class="font-mono text-emerald-400 font-bold">{{ state.overallProgressPercent() }}% הושלם</span></div>
            <div class="flex justify-between"><span class="text-slate-400">אומדן ישיר BoQ:</span><span class="font-mono text-emerald-400 font-bold">{{ (state.totalBoQCostNis() / 1000000).toFixed(1) }}M ₪</span></div>
          </div>
        </div>
      </div>

      <!-- Android Architecture & Native Kotlin Module Blueprint -->
      <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-700">
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400">android</mat-icon>
            <div>
              <h3 class="font-bold text-white text-base">ארכיטקטורת אנדרואיד מקורית (Kotlin / Jetpack Compose / MVVM)</h3>
              <span class="text-xs text-slate-400">מודולריות מלאה: core, features, Room persistence, Hilt DI ו-OpenGL ES</span>
            </div>
          </div>
          <span class="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-xs font-mono text-slate-300">
            Target: Android 14+ / Tablet & Mobile RTL
          </span>
        </div>

        <!-- Code Architecture Tabs -->
        <div class="flex gap-2 border-b border-slate-700 pb-2 text-xs">
          <button
            type="button"
            (click)="activeCodeTab.set('architecture')"
            [class.text-sky-400]="activeCodeTab() === 'architecture'"
            [class.border-b-2]="activeCodeTab() === 'architecture'"
            [class.border-sky-400]="activeCodeTab() === 'architecture'"
            class="pb-1 font-bold">
            מבנה פרויקט ומודולים
          </button>
          <button
            type="button"
            (click)="activeCodeTab.set('room-entity')"
            [class.text-sky-400]="activeCodeTab() === 'room-entity'"
            [class.border-b-2]="activeCodeTab() === 'room-entity'"
            [class.border-sky-400]="activeCodeTab() === 'room-entity'"
            class="pb-1 font-bold">
            Room Entity & DataStore
          </button>
          <button
            type="button"
            (click)="activeCodeTab.set('compose-ui')"
            [class.text-sky-400]="activeCodeTab() === 'compose-ui'"
            [class.border-b-2]="activeCodeTab() === 'compose-ui'"
            [class.border-sky-400]="activeCodeTab() === 'compose-ui'"
            class="pb-1 font-bold">
            Jetpack Compose RTL Screen
          </button>
        </div>

        <!-- Code Snippet Area -->
        <div class="bg-slate-950 rounded-xl p-4 border border-slate-800 font-mono text-xs overflow-x-auto text-slate-300 leading-relaxed whitespace-pre">
          <code>{{ currentCodeContent() }}</code>
        </div>
      </div>
    </div>
  `
})
export class ReportsExport {
  readonly state = inject(RailwayStateService);
  readonly activeCodeTab = signal<'architecture' | 'room-entity' | 'compose-ui'>('architecture');

  readonly codeArchitecture = `// Android Project Module Structure (Gradle Multi-Module)
// Israel Railways Engineering Studio - Digital Twin APK

settings.gradle.kts:
include(":app")
include(":core:geometry")       // Railway Cant, Spiral Transitions, 3D Alignments
include(":core:simulation")     // ETCS L2 Block logic, Train dynamics
include(":core:digitaltwin")    // 3D Scene Graph & Component Model
include(":core:terrain")        // DEM / Elevation grids
include(":core:construction")   // 4D Stage phasing & timeline
include(":core:validation")     // Clearance envelope & Clash detector
include(":core:storage")        // Room Database & DataStore Preferences
include(":feature:network")     // Track Alignment UI
include(":feature:stations")    // Platform & Station 3D configurator
include(":feature:structures")  // Bridges & Tunnels CAD Inspector
include(":feature:electrification") // 25kV Catenary system
include(":feature:signalling")  // Operations Dispatcher
include(":feature:schedule")    // Gantt Timeline
include(":feature:analytics")   // BoQ & Project Health Dashboard`;

  readonly codeRoomEntity = `// Room Entity: TrackAlignmentEntity.kt
package il.gov.railways.core.storage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "track_alignments")
data class TrackAlignmentEntity(
    @PrimaryKey val pointId: String,
    val nameHe: String,
    val chainageMeters: Double,
    val xCoord: Double,
    val zCoord: Double,
    val elevationMeters: Double,
    val curveRadiusMeters: Double,
    val spiralLengthMeters: Double,
    val gradePercent: Double,
    val designSpeedKmh: Int,
    val calculatedCantMm: Int
)

// DAO Interface with Kotlin Flow
package il.gov.railways.core.storage.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackAlignmentDao {
    @Query("SELECT * FROM track_alignments ORDER BY chainageMeters ASC")
    fun getAllPoints(): Flow<List<TrackAlignmentEntity>>

    @Upsert
    suspend fun upsertPoint(point: TrackAlignmentEntity)
}`;

  readonly codeComposeUi = `// Jetpack Compose RTL Main Screen: RailwayStudioScreen.kt
package il.gov.railways.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection

@Composable
fun RailwayStudioScreen(
    viewModel: RailwayStudioViewModel = hiltViewModel()
) {
    // Enforce Full Right-to-Left (RTL) for Israel Railways Studio
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                RailwayStudioTopBar(
                    title = "רכבת ישראל | סטודיו הנדסי דיגיטלי",
                    projectVersion = "Rev 3.4.1"
                )
            },
            bottomBar = {
                Construction4DControlDock(
                    currentPhase = viewModel.activePhase.collectAsState().value,
                    onPhaseChange = { viewModel.setPhase(it) }
                )
            }
        ) { paddingValues ->
            Row(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
                // Right Navigation Rail (Hebrew RTL)
                RailwayNavigationDrawer(
                    activeTab = viewModel.activeTab.collectAsState().value,
                    onTabSelected = { viewModel.selectTab(it) }
                )
                // Main 3D Digital Twin Viewport (SurfaceView / OpenGL ES)
                DigitalTwinViewport(
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
    }
}`;

  readonly currentCodeContent = computed(() => {
    const tab = this.activeCodeTab();
    if (tab === 'architecture') return this.codeArchitecture;
    if (tab === 'room-entity') return this.codeRoomEntity;
    return this.codeComposeUi;
  });

  exportJson(): void {
    const data = {
      project: this.state.project(),
      alignmentPoints: this.state.alignmentPoints(),
      stations: this.state.stations(),
      bridge: this.state.bridge(),
      tunnel: this.state.tunnel(),
      catenary: this.state.catenary(),
      signallingBlocks: this.state.signallingBlocks(),
      trains: this.state.trains(),
      constructionPhases: this.state.constructionPhases(),
      ganttTasks: this.state.ganttTasks(),
      clashes: this.state.clashes(),
      boqRecords: this.state.boqRecords()
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Israel_Railways_Digital_Twin_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  }

  exportCsv(): void {
    const records = this.state.boqRecords();
    let csv = 'Item Code,Description,Category,Unit,Quantity,Unit Price (NIS),Total Price (NIS),Uncertainty\n';
    records.forEach((r) => {
      csv += `"${r.itemCode}","${r.description}","${r.category}","${r.unit}",${r.calculatedQuantity},${r.unitPriceNis},${r.totalPriceNis},${r.uncertaintyMarginPercent}%\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Israel_Railways_BoQ_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }
}
