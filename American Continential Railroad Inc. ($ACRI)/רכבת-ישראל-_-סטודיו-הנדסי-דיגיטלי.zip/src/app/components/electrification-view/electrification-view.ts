import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RailwayStateService } from '../../services/railway-state.service';

@Component({
  selector: 'app-electrification-view',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 h-full overflow-y-auto space-y-6">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400">bolt</mat-icon>
            <h2 class="text-xl font-bold text-white">מערכות חשמול רכבת 25kV AC (OCS)</h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            תכנון רשת עילית (Catenary), עמודי פלדה מגולוונת, מרווחים, תיל מגע, כבל נושא ותחנות השנאה (TSS)
          </p>
        </div>
      </div>

      <!-- Electrical Parameter Cards -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">מתח נומינלי</span>
          <span class="text-lg font-bold font-mono text-amber-400">25,000V AC</span>
          <span class="text-[10px] text-slate-400 block">תדר רשת: 50Hz תלת-מופעי</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">מרווח עמודים מוגדר</span>
          <span class="text-lg font-bold font-mono text-white">{{ state.catenary().mastSpacingM }} מטר</span>
          <span class="text-[10px] text-emerald-400 block">תחום תקני: 50-65 מטר</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">גובה תיל מגע מעל מסילה</span>
          <span class="text-lg font-bold font-mono text-sky-400">5.30 מטר</span>
          <span class="text-[10px] text-slate-400 block">גובה מינימלי במעברים: 4.80 מ'</span>
        </div>
        <div class="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3.5 space-y-1">
          <span class="text-[11px] text-slate-400 block">כמות עמודי OCS במסדרון</span>
          <span class="text-lg font-bold font-mono text-white">{{ state.catenary().totalMastsCount }} עמודים</span>
          <span class="text-[10px] text-sky-300 block">מחושב פרמטרית למסילה כפולה</span>
        </div>
      </div>

      <!-- Interactive Mast Spacing & Catenary Configuration -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
          <span class="font-bold text-sm text-white flex items-center gap-2 pb-2 border-b border-slate-700">
            <mat-icon class="text-sky-400 text-sm">tune</mat-icon>
            כוונון פרמטרים הנדסיים של הרשת העילית
          </span>

          <div class="space-y-4 text-xs">
            <div>
              <div class="flex justify-between mb-1.5">
                <span class="text-slate-300">מרווח בין עמודי חשמול (Span Length):</span>
                <span class="font-mono font-bold text-amber-400 text-sm">{{ state.catenary().mastSpacingM }} מטר</span>
              </div>
              <input
                type="range"
                min="45"
                max="75"
                step="5"
                [value]="state.catenary().mastSpacingM"
                (input)="onSpacingChange($event)"
                class="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500" />
              <div class="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>45 מ' (עקומות חדות)</span>
                <span>60 מ' (תקני בקטע ישר)</span>
                <span>75 מ' (מעבר לגבול מותר)</span>
              </div>
              @if (state.catenary().mastSpacingM > 65) {
                <div class="mt-2 p-2 rounded bg-amber-950/60 border border-amber-600/50 text-amber-300 text-[11px] flex items-center gap-1.5">
                  <mat-icon class="text-xs w-4 h-4 text-amber-400">warning</mat-icon>
                  <span>שים לב: מרווח מעל 65 מטר מייצר התרעת התנגשות סטיית רוח (Wind Sway) במנוע הבדיקות</span>
                </div>
              }
            </div>

            <div class="grid grid-cols-2 gap-3 pt-2">
              <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                <span class="text-slate-400 block text-[11px]">מתיחת כבל נושא (Messenger)</span>
                <span class="font-mono text-white font-bold text-sm">15.0 kN</span>
                <span class="text-[10px] text-slate-400 block mt-1">משקולות מתיחה מבוקרת טמפרטורה</span>
              </div>
              <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                <span class="text-slate-400 block text-[11px]">מתיחת תיל מגע (Contact Wire)</span>
                <span class="font-mono text-white font-bold text-sm">15.0 kN</span>
                <span class="text-[10px] text-slate-400 block mt-1">סגסוגת CuAg (נחושת-כסף 120 מ"מ)</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Traction Substation & Power Feeding Info -->
        <div class="bg-slate-800/70 border border-slate-700/60 rounded-2xl p-5 shadow space-y-4">
          <span class="font-bold text-sm text-white flex items-center gap-2 pb-2 border-b border-slate-700">
            <mat-icon class="text-emerald-400 text-sm">power</mat-icon>
            תחנת השנאה והזנה (TSS) - מסדרון רכבת ישראל
          </span>

          <div class="space-y-2 text-xs">
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">מיקום תחנת השנאה:</span>
              <span class="font-mono text-white font-bold">ק"מ 3+800 (מרכז המסדרון)</span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">חיבור לרשת הארצית (חח"י):</span>
              <span class="font-mono text-sky-400 font-bold">161kV מתח עליון</span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">הספק שנאי הזנה:</span>
              <span class="font-mono text-slate-200 font-bold">2 x 40 MVA</span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">מקטע ניטרלי מבודד (Neutral Section):</span>
              <span class="font-mono text-amber-400 font-bold">ק"מ 4+100 (אורך 35 מטר)</span>
            </div>
            <div class="flex justify-between p-2 rounded bg-slate-900/50">
              <span class="text-slate-400">מערכת הגנות והארקות:</span>
              <span class="font-mono text-emerald-400 font-bold">חזרה דרך פסי המסילה (Return Rail)</span>
            </div>
          </div>

          <div class="p-3 bg-slate-900/70 rounded-xl border border-slate-800 text-[11px] text-slate-400">
            תכנון מערכת החשמול עומד במפרט רכבת ישראל ובדרישות תקן אירופי EN 50119 ו-EN 50122 להגנה מפני זרמי תועים ומתחי מגע.
          </div>
        </div>
      </div>
    </div>
  `
})
export class ElectrificationView {
  readonly state = inject(RailwayStateService);

  onSpacingChange(e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.updateCatenarySpacing(val);
  }
}
