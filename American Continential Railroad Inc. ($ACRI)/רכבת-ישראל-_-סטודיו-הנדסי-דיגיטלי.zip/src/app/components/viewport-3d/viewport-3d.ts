import {
  Component,
  ElementRef,
  OnInit,
  OnDestroy,
  NgZone,
  inject,
  viewChild,
  ChangeDetectionStrategy,
  effect,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RailwayStateService } from '../../services/railway-state.service';
import { GeometryCalcService } from '../../services/geometry-calc.service';
import {
  AlignmentPoint,
  BridgeStructure,
  TunnelStructure,
  StationModel,
  PlatformConfig,
  ClashDetectionResult
} from '../../models/railway.models';

@Component({
  selector: 'app-viewport-3d',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full overflow-hidden bg-[#0d1c2d] select-none">
      <!-- 3D WebGL Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay: Status, View Modes & Coordinate Display -->
      <div class="absolute top-3 right-3 left-3 flex flex-wrap items-center justify-between pointer-events-none gap-2">
        <!-- Right side (RTL Start): Project & Camera Badge -->
        <div class="flex items-center gap-2 pointer-events-auto bg-[#142B45]/90 border border-slate-700/60 rounded-xl px-3 py-1.5 shadow-md text-xs">
          <mat-icon class="text-sky-400 text-base leading-none w-4 h-4">view_in_ar</mat-icon>
          <span class="font-bold text-white tracking-wide">תאום דיגיטלי תלת-ממדי</span>
          <span class="w-1 h-1 rounded-full bg-slate-500"></span>
          <span class="text-slate-300 font-mono text-[11px]">{{ currentCameraLabel() }}</span>
          <span class="w-1 h-1 rounded-full bg-slate-500"></span>
          <span class="text-emerald-400 font-medium">קנ״מ 1:1 הנדסי</span>
        </div>

        <!-- Left side (RTL End): Camera Presets Quick Switch -->
        <div class="flex items-center gap-1 pointer-events-auto bg-[#142B45]/90 border border-slate-700/60 rounded-xl p-1 shadow-md text-xs">
          <button
            type="button"
            (click)="setPreset('free')"
            [class.bg-[#245B85]]="state.viewPreset() === 'free'"
            [class.text-white]="state.viewPreset() === 'free'"
            class="px-2.5 py-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700/50 transition-colors flex items-center gap-1"
            title="מבט חופשי מסלולי">
            <mat-icon class="text-sm w-3.5 h-3.5 leading-none">videocam</mat-icon>
            חופשי
          </button>
          <button
            type="button"
            (click)="setPreset('driver-cab')"
            [class.bg-[#245B85]]="state.viewPreset() === 'driver-cab'"
            [class.text-white]="state.viewPreset() === 'driver-cab'"
            class="px-2.5 py-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700/50 transition-colors flex items-center gap-1"
            title="תא נהג רכבת (POV)">
            <mat-icon class="text-sm w-3.5 h-3.5 leading-none">train</mat-icon>
            תא נהג
          </button>
          <button
            type="button"
            (click)="setPreset('station-south')"
            [class.bg-[#245B85]]="state.viewPreset() === 'station-south'"
            [class.text-white]="state.viewPreset() === 'station-south'"
            class="px-2.5 py-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700/50 transition-colors flex items-center gap-1"
            title="תחנת דרום">
            <mat-icon class="text-sm w-3.5 h-3.5 leading-none">apartment</mat-icon>
            תחנה
          </button>
          <button
            type="button"
            (click)="setPreset('bridge-view')"
            [class.bg-[#245B85]]="state.viewPreset() === 'bridge-view'"
            [class.text-white]="state.viewPreset() === 'bridge-view'"
            class="px-2.5 py-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700/50 transition-colors flex items-center gap-1"
            title="גשר עמק מסילה">
            <mat-icon class="text-sm w-3.5 h-3.5 leading-none">architecture</mat-icon>
            גשר
          </button>
          <button
            type="button"
            (click)="setPreset('tunnel-portal')"
            [class.bg-[#245B85]]="state.viewPreset() === 'tunnel-portal'"
            [class.text-white]="state.viewPreset() === 'tunnel-portal'"
            class="px-2.5 py-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700/50 transition-colors flex items-center gap-1"
            title="פורטל מנהרת הר אודם">
            <mat-icon class="text-sm w-3.5 h-3.5 leading-none">tunnel</mat-icon>
            מנהרה
          </button>
          <button
            type="button"
            (click)="setPreset('drone-corridor')"
            [class.bg-[#245B85]]="state.viewPreset() === 'drone-corridor'"
            [class.text-white]="state.viewPreset() === 'drone-corridor'"
            class="px-2.5 py-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700/50 transition-colors flex items-center gap-1"
            title="מבט רחפן על כל המסדרון">
            <mat-icon class="text-sm w-3.5 h-3.5 leading-none">flight</mat-icon>
            רחפן
          </button>
        </div>
      </div>

      <!-- Selected Component Inspector Card (Floating top-left in RTL) -->
      @if (state.inspectedObject(); as obj) {
        <div class="absolute top-16 left-4 z-20 w-72 bg-[#142B45]/95 border border-sky-600/50 rounded-xl p-3 shadow-xl backdrop-blur-none text-xs pointer-events-auto animate-fade-in">
          <div class="flex items-center justify-between pb-2 mb-2 border-b border-slate-700">
            <div class="flex items-center gap-1.5">
              <mat-icon class="text-sky-400 text-sm w-4 h-4 leading-none">info</mat-icon>
              <span class="font-bold text-white">{{ obj.title }}</span>
            </div>
            <button
              type="button"
              (click)="closeInspector()"
              class="text-slate-400 hover:text-white p-0.5 rounded hover:bg-slate-700">
              <mat-icon class="text-sm w-3.5 h-3.5 leading-none">close</mat-icon>
            </button>
          </div>
          <div class="text-[11px] text-sky-300 mb-2 font-mono flex items-center gap-1">
            <mat-icon class="text-xs w-3 h-3 leading-none">place</mat-icon>
            מיקום: {{ obj.chainage }}
          </div>
          <div class="space-y-1.5">
            @for (spec of obj.specs; track spec.label) {
              <div class="flex justify-between items-center text-[11px] bg-slate-800/60 px-2 py-1 rounded">
                <span class="text-slate-400">{{ spec.label }}:</span>
                <span class="font-mono text-slate-200 font-medium">{{ spec.value }}</span>
              </div>
            }
          </div>
        </div>
      }

      <!-- Collapsible Bottom Dock (Zero Viewport Occlusion as per Three.js skill) -->
      <div class="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 w-[95%] max-w-4xl pointer-events-auto transition-transform duration-300"
           [class.translate-y-[calc(100%-28px)]]="isDockCollapsed()">
        
        <!-- Toggle button on top of dock -->
        <div class="flex justify-center -mb-2">
          <button
            type="button"
            (click)="toggleDock()"
            class="bg-[#142B45] hover:bg-[#245B85] text-slate-200 hover:text-white px-3 py-0.5 rounded-t-lg border-t border-x border-slate-700 shadow text-[11px] flex items-center gap-1 transition-colors">
            <mat-icon class="text-sm w-3.5 h-3.5 leading-none">
              {{ isDockCollapsed() ? 'expand_less' : 'expand_more' }}
            </mat-icon>
            <span>{{ isDockCollapsed() ? 'הצג סרגל שליטה ו-4D' : 'הסתר סרגל (תצוגת מסך מלא)' }}</span>
          </button>
        </div>

        <!-- Main Dock Container -->
        <div class="bg-[#142B45]/95 border border-slate-700/80 rounded-2xl p-3 shadow-2xl backdrop-blur-none text-xs space-y-2.5">
          <!-- Row 1: 4D Construction Phase Timeline & Controls -->
          <div class="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-700/70">
            <div class="flex items-center gap-2">
              <span class="font-bold text-white flex items-center gap-1">
                <mat-icon class="text-amber-400 text-sm w-4 h-4 leading-none">history_toggle_off</mat-icon>
                סימולציית שלבי בנייה 4D:
              </span>
              <span class="bg-[#245B85] text-white px-2 py-0.5 rounded text-[11px] font-bold">
                שלב {{ state.activeConstructionPhase() }} מתוך 10: {{ currentPhaseName() }}
              </span>
            </div>

            <div class="flex items-center gap-2">
              <button
                type="button"
                (click)="prevPhase()"
                [disabled]="state.activeConstructionPhase() <= 1"
                class="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors flex items-center"
                title="שלב קודם">
                <mat-icon class="text-sm w-3.5 h-3.5 leading-none">chevron_right</mat-icon>
              </button>
              <button
                type="button"
                (click)="toggle4DPlay()"
                class="px-3 py-1 rounded font-medium flex items-center gap-1 transition-colors"
                [class.bg-emerald-700]="!state.is4DPlaying()"
                [class.bg-amber-600]="state.is4DPlaying()">
                <mat-icon class="text-sm w-3.5 h-3.5 leading-none">
                  {{ state.is4DPlaying() ? 'pause' : 'play_arrow' }}
                </mat-icon>
                <span>{{ state.is4DPlaying() ? 'עצור הדמיה' : 'הרץ 4D' }}</span>
              </button>
              <button
                type="button"
                (click)="nextPhase()"
                [disabled]="state.activeConstructionPhase() >= 10"
                class="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors flex items-center"
                title="שלב הבא">
                <mat-icon class="text-sm w-3.5 h-3.5 leading-none">chevron_left</mat-icon>
              </button>
            </div>
          </div>

          <!-- Slider across 10 stages -->
          <div class="flex items-center gap-3">
            <span class="text-[11px] text-slate-400 font-mono w-14 text-left">הכנת שטח</span>
            <input
              type="range"
              min="1"
              max="10"
              step="1"
              [value]="state.activeConstructionPhase()"
              (input)="onPhaseSliderChange($event)"
              class="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500" />
            <span class="text-[11px] text-slate-400 font-mono w-14 text-right">הפעלה</span>
          </div>

          <!-- Row 2: Layer Visibility Toggles & Train Sim control -->
          <div class="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px]">
            <div class="flex flex-wrap items-center gap-1.5">
              <span class="text-slate-400 ml-1">שכבות מודל:</span>
              <button
                type="button"
                (click)="state.toggleLayer('tracks')"
                [class.bg-[#245B85]]="state.layerVisibility().tracks"
                [class.text-white]="state.layerVisibility().tracks"
                [class.opacity-50]="!state.layerVisibility().tracks"
                class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-opacity">
                מסילות
              </button>
              <button
                type="button"
                (click)="state.toggleLayer('terrain')"
                [class.bg-[#245B85]]="state.layerVisibility().terrain"
                [class.text-white]="state.layerVisibility().terrain"
                [class.opacity-50]="!state.layerVisibility().terrain"
                class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-opacity">
                קרקע ועפר
              </button>
              <button
                type="button"
                (click)="state.toggleLayer('structures')"
                [class.bg-[#245B85]]="state.layerVisibility().structures"
                [class.text-white]="state.layerVisibility().structures"
                [class.opacity-50]="!state.layerVisibility().structures"
                class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-opacity">
                גשרים ומנהרות
              </button>
              <button
                type="button"
                (click)="state.toggleLayer('stations')"
                [class.bg-[#245B85]]="state.layerVisibility().stations"
                [class.text-white]="state.layerVisibility().stations"
                [class.opacity-50]="!state.layerVisibility().stations"
                class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-opacity">
                תחנות
              </button>
              <button
                type="button"
                (click)="state.toggleLayer('catenary')"
                [class.bg-[#245B85]]="state.layerVisibility().catenary"
                [class.text-white]="state.layerVisibility().catenary"
                [class.opacity-50]="!state.layerVisibility().catenary"
                class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-opacity">
                חשמול 25kV
              </button>
              <button
                type="button"
                (click)="state.toggleLayer('trains')"
                [class.bg-[#245B85]]="state.layerVisibility().trains"
                [class.text-white]="state.layerVisibility().trains"
                [class.opacity-50]="!state.layerVisibility().trains"
                class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-opacity">
                רכבות
              </button>
              <button
                type="button"
                (click)="state.toggleLayer('clashMarkers')"
                [class.bg-red-800]="state.layerVisibility().clashMarkers"
                [class.text-white]="state.layerVisibility().clashMarkers"
                [class.opacity-50]="!state.layerVisibility().clashMarkers"
                class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-opacity">
                סמני התנגשות
              </button>
            </div>

            <!-- Train sim speed toggle -->
            <div class="flex items-center gap-1.5">
              <span class="text-slate-400">סימולציית רכבות:</span>
              <button
                type="button"
                (click)="state.toggleTrainSim()"
                [class.bg-emerald-700]="state.isTrainSimRunning()"
                [class.bg-slate-700]="!state.isTrainSimRunning()"
                class="px-2 py-0.5 rounded text-white font-medium flex items-center gap-1">
                <mat-icon class="text-xs w-3 h-3 leading-none">{{ state.isTrainSimRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
                {{ state.isTrainSimRunning() ? 'פועלת' : 'מושהית' }}
              </button>
              <div class="flex items-center bg-slate-800 rounded border border-slate-700 p-0.5">
                <button
                  type="button"
                  (click)="state.setTrainSimSpeed(1)"
                  [class.bg-[#245B85]]="state.trainSimSpeedMultiplier() === 1"
                  class="px-1.5 py-0.5 rounded text-[10px] text-slate-300">1x</button>
                <button
                  type="button"
                  (click)="state.setTrainSimSpeed(2)"
                  [class.bg-[#245B85]]="state.trainSimSpeedMultiplier() === 2"
                  class="px-1.5 py-0.5 rounded text-[10px] text-slate-300">2x</button>
                <button
                  type="button"
                  (click)="state.setTrainSimSpeed(4)"
                  [class.bg-[#245B85]]="state.trainSimSpeedMultiplier() === 4"
                  class="px-1.5 py-0.5 rounded text-[10px] text-slate-300">4x</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class Viewport3D implements OnInit, OnDestroy {
  readonly state = inject(RailwayStateService);
  private readonly geoCalc = inject(GeometryCalcService);
  private readonly ngZone = inject(NgZone);

  readonly canvasContainer = viewChild<ElementRef<HTMLDivElement>>('canvasContainer');

  // Local UI state
  readonly isDockCollapsed = signal<boolean>(false);

  // Three.js instances
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private controls!: OrbitControls;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  private animationFrameId = 0;
  private lastTime = performance.now();

  // Procedural 3D Model Groups
  private rootGroup = new THREE.Group();
  private terrainGroup = new THREE.Group();
  private tracksGroup = new THREE.Group();
  private bridgeGroup = new THREE.Group();
  private tunnelGroup = new THREE.Group();
  private stationsGroup = new THREE.Group();
  private catenaryGroup = new THREE.Group();
  private trainsGroup = new THREE.Group();
  private clashMarkersGroup = new THREE.Group();

  // Train meshes
  private trainMeshes: { id: string; group: THREE.Group }[] = [];

  // 4D timeline timer
  private timelineTimer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    // React to camera preset changes
    effect(() => {
      const preset = this.state.viewPreset();
      this.applyCameraPreset(preset);
    });

    // React to 4D phase changes
    effect(() => {
      const phase = this.state.activeConstructionPhase();
      this.update4DVisibility(phase);
    });

    // React to layer visibility changes
    effect(() => {
      const layers = this.state.layerVisibility();
      this.tracksGroup.visible = layers.tracks;
      this.terrainGroup.visible = layers.terrain;
      this.bridgeGroup.visible = layers.structures;
      this.tunnelGroup.visible = layers.structures;
      this.stationsGroup.visible = layers.stations;
      this.catenaryGroup.visible = layers.catenary;
      this.trainsGroup.visible = layers.trains;
      this.clashMarkersGroup.visible = layers.clashMarkers;
    });

    // React to 4D play state
    effect(() => {
      const isPlaying = this.state.is4DPlaying();
      if (isPlaying) {
        this.start4DAutoPlay();
      } else {
        this.stop4DAutoPlay();
      }
    });

    // React to geometry changes
    effect(() => {
      // Re-trigger rebuild when points change
      this.state.alignmentPoints();
      this.state.catenary();
      this.state.bridge();
      if (this.scene) {
        this.rebuildDynamicStructures();
      }
    });
  }

  ngOnInit(): void {
    // WebGL initialization inside NgZone runOutsideAngular
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.initThree();
      }, 50);
    });
  }

  ngOnDestroy(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.stop4DAutoPlay();
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  toggleDock(): void {
    this.isDockCollapsed.update((v) => !v);
  }

  closeInspector(): void {
    this.state.inspectObject(null);
  }

  setPreset(preset: 'free' | 'driver-cab' | 'drone-corridor' | 'station-south' | 'bridge-view' | 'tunnel-portal'): void {
    this.state.setViewPreset(preset);
  }

  currentCameraLabel(): string {
    const p = this.state.viewPreset();
    switch (p) {
      case 'free': return 'מבט מסלולי חופשי';
      case 'driver-cab': return 'מצלמת תא נהג (רכבת 482)';
      case 'drone-corridor': return 'מבט רחפן פנורמי';
      case 'station-south': return 'תחנת מסדרון דרום (ק"מ 1+200)';
      case 'bridge-view': return 'גשר עמק מסילה (ק"מ 3+200)';
      case 'tunnel-portal': return 'פורטל מנהרת הר אודם (ק"מ 5+400)';
    }
  }

  currentPhaseName(): string {
    const phaseNum = this.state.activeConstructionPhase();
    const phase = this.state.constructionPhases().find((p) => p.stageNumber === phaseNum);
    return phase ? phase.name : '';
  }

  prevPhase(): void {
    this.state.set4DConstructionPhase(this.state.activeConstructionPhase() - 1);
  }

  nextPhase(): void {
    this.state.set4DConstructionPhase(this.state.activeConstructionPhase() + 1);
  }

  onPhaseSliderChange(e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    this.state.set4DConstructionPhase(val);
  }

  toggle4DPlay(): void {
    this.state.toggle4DPlayback();
  }

  private start4DAutoPlay(): void {
    this.stop4DAutoPlay();
    this.timelineTimer = setInterval(() => {
      const cur = this.state.activeConstructionPhase();
      if (cur >= 10) {
        this.state.set4DConstructionPhase(1);
      } else {
        this.state.set4DConstructionPhase(cur + 1);
      }
    }, 2800);
  }

  private stop4DAutoPlay(): void {
    if (this.timelineTimer) {
      clearInterval(this.timelineTimer);
      this.timelineTimer = null;
    }
  }

  private initThree(): void {
    const container = this.canvasContainer()?.nativeElement;
    if (!container) return;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Detect software GL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x102133);
    this.scene.fog = new THREE.FogExp2(0x142b45, 0.0006);

    // Camera
    this.camera = new THREE.PerspectiveCamera(50, width / height, 0.5, 9000);
    this.camera.position.set(400, 180, 2400);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // Environment Lighting (PMREM)
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Natural Israeli Outdoor Lighting Rig
    const sunLight = new THREE.DirectionalLight(0xfff6e5, 2.4);
    sunLight.position.set(800, 1200, 1000);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 100;
    sunLight.shadow.camera.far = 4000;
    const d = 1500;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0004;
    this.scene.add(sunLight);

    const hemiLight = new THREE.HemisphereLight(0x7da4c4, 0x475569, 0.8);
    this.scene.add(hemiLight);

    // Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !isSoftwareGl;
    this.controls.dampingFactor = 0.05;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.02; // Keep above ground
    this.controls.target.set(200, 40, 2600);

    // Add Groups
    this.rootGroup.add(this.terrainGroup);
    this.rootGroup.add(this.tracksGroup);
    this.rootGroup.add(this.bridgeGroup);
    this.rootGroup.add(this.tunnelGroup);
    this.rootGroup.add(this.stationsGroup);
    this.rootGroup.add(this.catenaryGroup);
    this.rootGroup.add(this.trainsGroup);
    this.rootGroup.add(this.clashMarkersGroup);
    this.scene.add(this.rootGroup);

    // Build Initial Procedural Geometry
    this.buildTerrain();
    this.rebuildDynamicStructures();
    this.buildTrains();

    // Resize listener
    window.addEventListener('resize', this.onWindowResize.bind(this));

    // Pointer click for raycast inspection
    container.addEventListener('pointerdown', this.onPointerDown.bind(this));

    // Animation Loop
    this.tick();
  }

  private onWindowResize(): void {
    const container = this.canvasContainer()?.nativeElement;
    if (!container || !this.renderer || !this.camera) return;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private onPointerDown(e: MouseEvent): void {
    const container = this.canvasContainer()?.nativeElement;
    if (!container || !this.camera) return;

    const rect = container.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.rootGroup.children, true);

    if (intersects.length > 0) {
      // Find object with userData
      let hitObj: THREE.Object3D | null = intersects[0].object;
      while (hitObj && !hitObj.userData?.['componentType'] && hitObj.parent && hitObj.parent !== this.rootGroup) {
        hitObj = hitObj.parent;
      }

      if (hitObj && hitObj.userData?.['componentType']) {
        const data = hitObj.userData;
        this.ngZone.run(() => {
          this.state.inspectObject({
            type: data['componentType'],
            title: data['name'] || 'רכיב תשתית',
            chainage: data['chainage'] || 'PK תוואי',
            specs: data['specs'] || []
          });
        });
      }
    }
  }

  private buildTerrain(): void {
    this.terrainGroup.clear();

    // Create a 8.5km x 1.5km terrain ribbon along the railway corridor
    const width = 1600; // Across track
    const length = 9200; // Along corridor
    const segmentsX = 40;
    const segmentsZ = 120;

    const geo = new THREE.PlaneGeometry(width, length, segmentsX, segmentsZ);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes['position'];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i) + 4250; // Align from 0 to 8500
      const elev = this.geoCalc.getNaturalGroundElevation(x, z);
      pos.setY(i, elev);
      pos.setZ(i, z);
    }
    geo.computeVertexNormals();

    // Earth/rock material
    const mat = new THREE.MeshStandardMaterial({
      color: 0x5b654a,
      roughness: 0.95,
      metalness: 0.05,
      flatShading: true
    });

    const terrainMesh = new THREE.Mesh(geo, mat);
    terrainMesh.receiveShadow = true;
    terrainMesh.userData = {
      componentType: 'קרקע וטופוגרפיה',
      name: 'פני שטח טבעיים - גבעות מסדרון העמקים',
      chainage: 'PK 0+000 עד 8+500',
      specs: [
        { label: 'סוג מסלע', value: 'קרטון, גיר וסחף אלוביאלי' },
        { label: 'גובה פני שטח ממוצע', value: '45.0 מטר מעל פני הים' },
        { label: 'שיפועי יציבות סוללה', value: '1:1.5 מילוי, 1:1 חפירה' }
      ]
    };

    this.terrainGroup.add(terrainMesh);

    // Add grid wireframe for CAD engineering appearance
    const gridHelper = new THREE.GridHelper(9000, 90, 0x3b82f6, 0x1e3a5f);
    gridHelper.position.set(300, 15, 4250);
    this.terrainGroup.add(gridHelper);
  }

  private rebuildDynamicStructures(): void {
    this.tracksGroup.clear();
    this.bridgeGroup.clear();
    this.tunnelGroup.clear();
    this.stationsGroup.clear();
    this.catenaryGroup.clear();
    this.clashMarkersGroup.clear();

    const points = this.state.alignmentPoints();
    const cat = this.state.catenary();
    const br = this.state.bridge();
    const tn = this.state.tunnel();
    const stList = this.state.stations();
    const clashes = this.state.clashes();

    // 1. Build Tracks & Ballast Formation
    this.buildTracksGeometry(points);

    // 2. Build Bridge (Viaduct)
    this.buildBridgeGeometry(br);

    // 3. Build Tunnel
    this.buildTunnelGeometry(tn);

    // 4. Build Stations
    this.buildStationsGeometry(stList);

    // 5. Build Catenary Masts & OCS Wires
    this.buildCatenaryGeometry(points, cat.mastSpacingM);

    // 6. Build Clash Markers
    this.buildClashMarkers(clashes);

    // Update 4D visibility based on current phase
    this.update4DVisibility(this.state.activeConstructionPhase());
  }

  private buildTracksGeometry(points: AlignmentPoint[]): void {
    const totalLength = points[points.length - 1]?.chainage || 8500;
    const step = 8; // Every 8m sample alignment
    const sampleCount = Math.floor(totalLength / step);

    // Materials
    const railMat = new THREE.MeshStandardMaterial({
      color: 0x8fa3b0,
      metalness: 0.95,
      roughness: 0.15
    });

    const sleeperMat = new THREE.MeshStandardMaterial({
      color: 0xd9dee3,
      roughness: 0.85,
      metalness: 0.05
    });

    const ballastMat = new THREE.MeshStandardMaterial({
      color: 0x4a4f54,
      roughness: 0.98,
      metalness: 0.02
    });

    // Double Track Spacing = 4.5m
    const trackOffsets = [-2.25, 2.25];
    const railGaugeHalf = 1.435 / 2;

    // Track Group Container with 4D phase = 6
    const group = new THREE.Group();
    group.userData = { minStage: 6 };

    // Build Ballast Embankment Prisms along the curve
    const ballastGeo = new THREE.BufferGeometry();
    const ballastPositions: number[] = [];

    for (let i = 0; i < sampleCount - 1; i++) {
      const ch1 = i * step;
      const ch2 = (i + 1) * step;

      const pt1 = this.geoCalc.interpolateAlignment(points, ch1);
      const pt2 = this.geoCalc.interpolateAlignment(points, ch2);

      // Width of ballast crown ~8.5m, base ~12m
      const wCrownHalf = 4.6;
      const wBaseHalf = 6.2;
      const depth = 0.65;

      // 4 points cross-section at pt1
      const cL1 = [pt1.x + pt1.normalX * -wCrownHalf, pt1.y, pt1.z + pt1.normalZ * -wCrownHalf];
      const cR1 = [pt1.x + pt1.normalX * wCrownHalf, pt1.y, pt1.z + pt1.normalZ * wCrownHalf];
      const bL1 = [pt1.x + pt1.normalX * -wBaseHalf, pt1.y - depth, pt1.z + pt1.normalZ * -wBaseHalf];
      const bR1 = [pt1.x + pt1.normalX * wBaseHalf, pt1.y - depth, pt1.z + pt1.normalZ * wBaseHalf];

      // 4 points cross-section at pt2
      const cL2 = [pt2.x + pt2.normalX * -wCrownHalf, pt2.y, pt2.z + pt2.normalZ * -wCrownHalf];
      const cR2 = [pt2.x + pt2.normalX * wCrownHalf, pt2.y, pt2.z + pt2.normalZ * wCrownHalf];
      const bL2 = [pt2.x + pt2.normalX * -wBaseHalf, pt2.y - depth, pt2.z + pt2.normalZ * -wBaseHalf];
      const bR2 = [pt2.x + pt2.normalX * wBaseHalf, pt2.y - depth, pt2.z + pt2.normalZ * wBaseHalf];

      // Top face
      ballastPositions.push(...cL1, ...cR1, ...cR2, ...cL1, ...cR2, ...cL2);
      // Left side slope
      ballastPositions.push(...bL1, ...cL1, ...cL2, ...bL1, ...cL2, ...bL2);
      // Right side slope
      ballastPositions.push(...cR1, ...bR1, ...bR2, ...cR1, ...bR2, ...cR2);
    }

    ballastGeo.setAttribute('position', new THREE.Float32BufferAttribute(ballastPositions, 3));
    ballastGeo.computeVertexNormals();
    const ballastMesh = new THREE.Mesh(ballastGeo, ballastMat);
    ballastMesh.receiveShadow = true;
    group.add(ballastMesh);

    // Rails: Create continuous extruded tubes for UIC60 rails (4 rails total for double track)
    trackOffsets.forEach((trackOffset) => {
      // Left and right rail offsets
      [-railGaugeHalf, railGaugeHalf].forEach((railOffset) => {
        const railCurvePoints: THREE.Vector3[] = [];
        for (let i = 0; i <= sampleCount; i++) {
          const ch = i * step;
          const pt = this.geoCalc.interpolateAlignment(points, ch);
          const totalNormalOffset = trackOffset + railOffset;
          const rx = pt.x + pt.normalX * totalNormalOffset;
          const ry = pt.y + 0.18; // Rail head height above ballast
          const rz = pt.z + pt.normalZ * totalNormalOffset;
          railCurvePoints.push(new THREE.Vector3(rx, ry, rz));
        }

        const railCurve = new THREE.CatmullRomCurve3(railCurvePoints);
        const railTubeGeo = new THREE.TubeGeometry(railCurve, sampleCount, 0.045, 6, false);
        const railMesh = new THREE.Mesh(railTubeGeo, railMat);
        railMesh.castShadow = true;
        group.add(railMesh);
      });

      // Concrete Sleepers (Instanced mesh spaced every 1.8m in 3D sample for performance)
      const sleeperStep = 1.8;
      const sleeperCount = Math.floor(totalLength / sleeperStep);
      const sleeperGeo = new THREE.BoxGeometry(2.6, 0.16, 0.26);
      const instancedSleepers = new THREE.InstancedMesh(sleeperGeo, sleeperMat, sleeperCount);
      instancedSleepers.castShadow = true;

      const dummy = new THREE.Object3D();
      for (let s = 0; s < sleeperCount; s++) {
        const ch = s * sleeperStep;
        const pt = this.geoCalc.interpolateAlignment(points, ch);
        const sx = pt.x + pt.normalX * trackOffset;
        const sy = pt.y + 0.08;
        const sz = pt.z + pt.normalZ * trackOffset;

        dummy.position.set(sx, sy, sz);
        const rotY = Math.atan2(pt.tangentX, pt.tangentZ);
        dummy.rotation.set(0, rotY, 0);
        dummy.updateMatrix();
        instancedSleepers.setMatrixAt(s, dummy.matrix);
      }
      instancedSleepers.computeBoundingSphere();
      group.add(instancedSleepers);
    });

    group.userData = {
      componentType: 'מבנה עליון ומסילאות',
      name: 'מסילה כפולה תקנית 1435 מ"מ (UIC60 על אדני בטון מונובלוק)',
      chainage: 'PK 0+000 עד 8+500',
      minStage: 6,
      specs: [
        { label: 'פרופיל מסילה', value: 'UIC60 (60 ק"ג/מטר רץ)' },
        { label: 'רוחב מסילה תקני', value: '1,435 מ"מ (Standard Gauge)' },
        { label: 'מרווח בין צירים', value: '4.50 מטר' },
        { label: 'עובי מצע חצץ מובחר', value: '350 מ"מ תחת אדן' },
        { label: 'מהירות תכן', value: '160 קמ"ש' }
      ]
    };

    this.tracksGroup.add(group);
  }

  private buildBridgeGeometry(br: BridgeStructure): void {
    const points = this.state.alignmentPoints();
    const bridgeGroup = new THREE.Group();
    bridgeGroup.userData = { minStage: 4 };

    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0xc8cdd2,
      roughness: 0.7,
      metalness: 0.1
    });

    const steelRailingMat = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      roughness: 0.4,
      metalness: 0.8
    });

    // Bridge Deck Box Girder
    const sampleStep = 10;
    const samples = Math.floor((br.chainageEnd - br.chainageStart) / sampleStep);
    const deckWidth = br.deckWidthM;
    const deckDepth = 2.4;

    for (let i = 0; i < samples; i++) {
      const ch = br.chainageStart + i * sampleStep;
      const pt = this.geoCalc.interpolateAlignment(points, ch);

      // Concrete box girder segment
      const segGeo = new THREE.BoxGeometry(deckWidth, deckDepth, sampleStep + 0.1);
      const segMesh = new THREE.Mesh(segGeo, concreteMat);
      segMesh.position.set(pt.x, pt.y - deckDepth / 2, pt.z);
      const rotY = Math.atan2(pt.tangentX, pt.tangentZ);
      segMesh.rotation.set(0, rotY, 0);
      segMesh.castShadow = true;
      segMesh.receiveShadow = true;
      bridgeGroup.add(segMesh);

      // Parapet / Safety Railing on left and right
      [-deckWidth / 2 + 0.2, deckWidth / 2 - 0.2].forEach((sideOffset) => {
        const railGeo = new THREE.BoxGeometry(0.2, 1.1, sampleStep);
        const railMesh = new THREE.Mesh(railGeo, steelRailingMat);
        const rx = pt.x + pt.normalX * sideOffset;
        const ry = pt.y + 0.55;
        const rz = pt.z + pt.normalZ * sideOffset;
        railMesh.position.set(rx, ry, rz);
        railMesh.rotation.set(0, rotY, 0);
        bridgeGroup.add(railMesh);
      });
    }

    // Concrete Piers
    const pierSpacing = (br.chainageEnd - br.chainageStart) / br.spanCount;
    for (let p = 1; p < br.spanCount; p++) {
      const ch = br.chainageStart + p * pierSpacing;
      const pt = this.geoCalc.interpolateAlignment(points, ch);
      const groundY = this.geoCalc.getNaturalGroundElevation(pt.x, pt.z);
      const pierHeight = Math.max(8, pt.y - groundY - deckDepth);

      const pierGeo = new THREE.CylinderGeometry(1.6, 2.2, pierHeight, 16);
      const pierMesh = new THREE.Mesh(pierGeo, concreteMat);
      pierMesh.position.set(pt.x, pt.y - deckDepth - pierHeight / 2, pt.z);
      pierMesh.castShadow = true;
      pierMesh.receiveShadow = true;
      bridgeGroup.add(pierMesh);

      // Pile Cap & Pier Table
      const capGeo = new THREE.BoxGeometry(deckWidth - 1, 1.2, 3.5);
      const capMesh = new THREE.Mesh(capGeo, concreteMat);
      capMesh.position.set(pt.x, pt.y - deckDepth - 0.6, pt.z);
      const rotY = Math.atan2(pt.tangentX, pt.tangentZ);
      capMesh.rotation.set(0, rotY, 0);
      bridgeGroup.add(capMesh);
    }

    bridgeGroup.userData = {
      componentType: 'מבנה הנדסי - גשר',
      name: br.name,
      chainage: `PK ${Math.round(br.chainageStart / 1000)}+${br.chainageStart % 1000} עד PK ${Math.round(br.chainageEnd / 1000)}+${br.chainageEnd % 1000}`,
      minStage: 4,
      specs: [
        { label: 'אורך הגשר הכולל', value: `${br.lengthMeters} מטר` },
        { label: 'סוג מבנה', value: br.structureType },
        { label: 'מספר מפתחים', value: `${br.spanCount} מפתחי בטון דרוך` },
        { label: 'גובה עמוד מרבי', value: `${br.pierHeightMaxM} מטר` },
        { label: 'מרווח אנכי תחת הגשר', value: `${br.clearanceUnderDeckM.toFixed(1)} מטר` },
        { label: 'כושר נשיאה תכן', value: `${br.bearingCapacityTonnes} טון (רכבת משא כבדה)` }
      ]
    };

    this.bridgeGroup.add(bridgeGroup);
  }

  private buildTunnelGeometry(tn: TunnelStructure): void {
    const points = this.state.alignmentPoints();
    const tunnelGroup = new THREE.Group();
    tunnelGroup.userData = { minStage: 5 };

    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0x8a9299,
      roughness: 0.85,
      metalness: 0.1,
      side: THREE.DoubleSide
    });

    const portalMat = new THREE.MeshStandardMaterial({
      color: 0x5a636b,
      roughness: 0.75,
      metalness: 0.2
    });

    // Tunnel Portals (South & North Entrance Structures)
    [tn.chainageStart, tn.chainageEnd].forEach((ch, idx) => {
      const pt = this.geoCalc.interpolateAlignment(points, ch);
      const rotY = Math.atan2(pt.tangentX, pt.tangentZ);

      // Portal Wingwall Façade
      const portalGeo = new THREE.BoxGeometry(18, 14, 4);
      const portalMesh = new THREE.Mesh(portalGeo, portalMat);
      portalMesh.position.set(pt.x, pt.y + 5, pt.z);
      portalMesh.rotation.set(0, rotY, 0);
      tunnelGroup.add(portalMesh);

      // Arch cutout accent
      const archGeo = new THREE.TorusGeometry(tn.innerDiameterM / 2 + 0.5, 0.6, 12, 24, Math.PI);
      const archMesh = new THREE.Mesh(archGeo, portalMat);
      archMesh.position.set(pt.x, pt.y + 1, pt.z + (idx === 0 ? -2 : 2));
      archMesh.rotation.set(0, rotY, 0);
      tunnelGroup.add(archMesh);
    });

    // Bored Horseshoe Rings (Segments) along the tunnel length
    const sampleStep = 15;
    const count = Math.floor((tn.chainageEnd - tn.chainageStart) / sampleStep);

    for (let i = 0; i <= count; i++) {
      const ch = tn.chainageStart + i * sampleStep;
      const pt = this.geoCalc.interpolateAlignment(points, ch);
      const rotY = Math.atan2(pt.tangentX, pt.tangentZ);

      const ringGeo = new THREE.CylinderGeometry(
        tn.innerDiameterM / 2,
        tn.innerDiameterM / 2,
        sampleStep - 0.5,
        16,
        1,
        true
      );
      ringGeo.rotateZ(Math.PI / 2);
      const ringMesh = new THREE.Mesh(ringGeo, concreteMat);
      ringMesh.position.set(pt.x, pt.y + tn.innerDiameterM / 2 - 1, pt.z);
      ringMesh.rotation.set(0, rotY, 0);
      tunnelGroup.add(ringMesh);
    }

    tunnelGroup.userData = {
      componentType: 'מבנה הנדסי - מנהרה',
      name: tn.name,
      chainage: `PK ${Math.round(tn.chainageStart / 1000)}+${tn.chainageStart % 1000} עד PK ${Math.round(tn.chainageEnd / 1000)}+${tn.chainageEnd % 1000}`,
      minStage: 5,
      specs: [
        { label: 'אורך המנהרה', value: `${tn.lengthMeters} מטר` },
        { label: 'שיטת כרייה', value: `${tn.crossSectionType} קוטר ${tn.innerDiameterM} מ'` },
        { label: 'עומק כיסוי סלע מרבי', value: `${tn.coverDepthMaxM} מטר תחת הר אודם` },
        { label: 'פתחי מילוט ובטיחות', value: `מעברים מקשרים כל ${tn.crossPassageSpacingM} מ'` },
        { label: 'מערכות אוורור', value: 'מפוחי סילון (Jet Fans) ופיר אנכי' }
      ]
    };

    this.tunnelGroup.add(tunnelGroup);
  }

  private buildStationsGeometry(stList: StationModel[]): void {
    const points = this.state.alignmentPoints();

    const platformMat = new THREE.MeshStandardMaterial({
      color: 0xd9dee3,
      roughness: 0.8,
      metalness: 0.05
    });

    const tactileTileMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b, // Yellow tactile paving
      roughness: 0.5,
      metalness: 0.1
    });

    const canopySteelMat = new THREE.MeshStandardMaterial({
      color: 0x142b45,
      metalness: 0.8,
      roughness: 0.3
    });

    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x67e8f9,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.45
    });

    stList.forEach((st) => {
      const stationGroup = new THREE.Group();
      stationGroup.userData = { minStage: 9 };

      const centerChainage = (st.chainageStart + st.chainageEnd) / 2;
      const ptCenter = this.geoCalc.interpolateAlignment(points, centerChainage);
      const rotY = Math.atan2(ptCenter.tangentX, ptCenter.tangentZ);

      // Station Main Terminal Building
      const bldgGeo = new THREE.BoxGeometry(45, 12, 28);
      const bldgMesh = new THREE.Mesh(bldgGeo, canopySteelMat);
      // Place building offset from track
      const bldgX = ptCenter.x + ptCenter.normalX * 32;
      const bldgY = ptCenter.y + 6;
      const bldgZ = ptCenter.z + ptCenter.normalZ * 32;
      bldgMesh.position.set(bldgX, bldgY, bldgZ);
      bldgMesh.rotation.set(0, rotY, 0);
      bldgMesh.castShadow = true;
      stationGroup.add(bldgMesh);

      // Glass facade
      const glassFacadeGeo = new THREE.PlaneGeometry(42, 9);
      const glassFacade = new THREE.Mesh(glassFacadeGeo, glassMat);
      glassFacade.position.set(bldgX - ptCenter.normalX * 14.1, bldgY, bldgZ - ptCenter.normalZ * 14.1);
      glassFacade.rotation.set(0, rotY + Math.PI / 2, 0);
      stationGroup.add(glassFacade);

      // Platforms (Length = 350m for 12-car train)
      st.platforms.forEach((pl: PlatformConfig, plIdx: number) => {
        const platOffset = pl.isIsland ? 0 : (plIdx === 0 ? -5.8 : 5.8);
        const platHeightM = pl.heightAboveRailMm / 1000;
        const platLen = pl.length;
        const platWidth = pl.width;

        const platGeo = new THREE.BoxGeometry(platWidth, platHeightM, platLen);
        const platMesh = new THREE.Mesh(platGeo, platformMat);
        const px = ptCenter.x + ptCenter.normalX * platOffset;
        const py = ptCenter.y + platHeightM / 2;
        const pz = ptCenter.z + ptCenter.normalZ * platOffset;
        platMesh.position.set(px, py, pz);
        platMesh.rotation.set(0, rotY, 0);
        platMesh.receiveShadow = true;
        stationGroup.add(platMesh);

        // Tactile yellow safety strip on platform edge
        const tactileGeo = new THREE.BoxGeometry(0.6, 0.05, platLen);
        const tactileMesh = new THREE.Mesh(tactileGeo, tactileTileMat);
        const edgeOffset = pl.isIsland ? platWidth / 2 - 0.4 : (plIdx === 0 ? platWidth / 2 - 0.4 : -platWidth / 2 + 0.4);
        tactileMesh.position.set(px + ptCenter.normalX * edgeOffset, py + platHeightM / 2 + 0.03, pz + ptCenter.normalZ * edgeOffset);
        tactileMesh.rotation.set(0, rotY, 0);
        stationGroup.add(tactileMesh);

        // Modern Canopy Shelter
        const canopyGeo = new THREE.BoxGeometry(platWidth + 1.5, 0.4, platLen * 0.7);
        const canopyMesh = new THREE.Mesh(canopyGeo, glassMat);
        canopyMesh.position.set(px, py + 4.8, pz);
        canopyMesh.rotation.set(0, rotY, 0);
        stationGroup.add(canopyMesh);

        // Canopy Columns
        for (let col = -120; col <= 120; col += 30) {
          const colGeo = new THREE.CylinderGeometry(0.2, 0.2, 4.8, 8);
          const colMesh = new THREE.Mesh(colGeo, canopySteelMat);
          colMesh.position.set(px, py + 2.4, pz + col);
          colMesh.rotation.set(0, rotY, 0);
          stationGroup.add(colMesh);
        }
      });

      // Pedestrian Overpass (Footbridge) with elevators
      if (st.hasPedestrianOverpass) {
        const bridgeSpan = 38;
        const bridgeGeo = new THREE.BoxGeometry(bridgeSpan, 3.5, 4.5);
        const footBridge = new THREE.Mesh(bridgeGeo, canopySteelMat);
        footBridge.position.set(ptCenter.x + ptCenter.normalX * 6, ptCenter.y + 7.5, ptCenter.z);
        footBridge.rotation.set(0, rotY, 0);
        stationGroup.add(footBridge);

        // Glass side walls on overpass
        const fGlassGeo = new THREE.BoxGeometry(bridgeSpan, 2.2, 0.1);
        const fGlass = new THREE.Mesh(fGlassGeo, glassMat);
        fGlass.position.set(ptCenter.x + ptCenter.normalX * 6, ptCenter.y + 7.5, ptCenter.z + 2.2);
        fGlass.rotation.set(0, rotY, 0);
        stationGroup.add(fGlass);
      }

      stationGroup.userData = {
        componentType: 'תחנת נוסעים',
        name: st.name,
        chainage: `PK ${Math.round(st.chainageStart / 1000)}+${st.chainageStart % 1000} עד PK ${Math.round(st.chainageEnd / 1000)}+${st.chainageEnd % 1000}`,
        minStage: 9,
        specs: [
          { label: 'סטטוס תכנון', value: st.operationalStatus },
          { label: 'אורך רציפים', value: '350 מטר (מתאים ל-12 קרונות)' },
          { label: 'גובה מדרך רציף', value: `${st.platforms[0]?.heightAboveRailMm || 960} מ"מ מעל ראש מסילה` },
          { label: 'נגישות מלאה', value: 'מעליות וגשר הולכי רגל מקורה' },
          { label: 'חניות ומסוף', value: `${st.parkingSpaces} מקומות חניה + תחבורה משולבת` }
        ]
      };

      this.stationsGroup.add(stationGroup);
    });
  }

  private buildCatenaryGeometry(points: AlignmentPoint[], mastSpacingM: number): void {
    const totalLength = points[points.length - 1]?.chainage || 8500;
    const mastsCount = Math.floor(totalLength / mastSpacingM);

    const mastSteelMat = new THREE.MeshStandardMaterial({
      color: 0x697783,
      metalness: 0.85,
      roughness: 0.35
    });

    const copperWireMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.9,
      roughness: 0.2
    });

    const catGroup = new THREE.Group();
    catGroup.userData = { minStage: 7 };

    // Continuous Contact Wire (25kV) and Messenger Wire
    const wirePointsLeft: THREE.Vector3[] = [];
    const wirePointsRight: THREE.Vector3[] = [];

    const wireStep = 15;
    const wireSamples = Math.floor(totalLength / wireStep);

    for (let w = 0; w <= wireSamples; w++) {
      const ch = w * wireStep;
      const pt = this.geoCalc.interpolateAlignment(points, ch);
      const contactH = pt.y + 5.3; // 5.3m contact wire height

      wirePointsLeft.push(new THREE.Vector3(pt.x + pt.normalX * -2.25, contactH, pt.z + pt.normalZ * -2.25));
      wirePointsRight.push(new THREE.Vector3(pt.x + pt.normalX * 2.25, contactH, pt.z + pt.normalZ * 2.25));
    }

    const curveL = new THREE.CatmullRomCurve3(wirePointsLeft);
    const curveR = new THREE.CatmullRomCurve3(wirePointsRight);

    const wireGeoL = new THREE.TubeGeometry(curveL, wireSamples, 0.02, 4, false);
    const wireGeoR = new THREE.TubeGeometry(curveR, wireSamples, 0.02, 4, false);

    catGroup.add(new THREE.Mesh(wireGeoL, copperWireMat));
    catGroup.add(new THREE.Mesh(wireGeoR, copperWireMat));

    // Masts (H-beam steel columns with cantilevers)
    for (let m = 0; m <= mastsCount; m++) {
      const ch = m * mastSpacingM;
      // Skip masts inside tunnel
      if (ch >= 5400 && ch <= 6600) continue;

      const pt = this.geoCalc.interpolateAlignment(points, ch);
      const rotY = Math.atan2(pt.tangentX, pt.tangentZ);

      // Mast column placed on right side of double track (+4.2m offset)
      const mastH = 8.2;
      const mx = pt.x + pt.normalX * 4.6;
      const my = pt.y + mastH / 2;
      const mz = pt.z + pt.normalZ * 4.6;

      const colGeo = new THREE.BoxGeometry(0.35, mastH, 0.35);
      const colMesh = new THREE.Mesh(colGeo, mastSteelMat);
      colMesh.position.set(mx, my, mz);
      colMesh.rotation.set(0, rotY, 0);
      colMesh.castShadow = true;
      catGroup.add(colMesh);

      // Cantilever Arm spanning across both tracks
      const armLength = 7.5;
      const armGeo = new THREE.BoxGeometry(armLength, 0.18, 0.18);
      const armMesh = new THREE.Mesh(armGeo, mastSteelMat);
      armMesh.position.set(pt.x + pt.normalX * 1.0, pt.y + 6.2, pt.z + pt.normalZ * 1.0);
      armMesh.rotation.set(0, rotY, 0);
      catGroup.add(armMesh);

      // Insulator Drop Arms
      [-2.25, 2.25].forEach((offset) => {
        const dropGeo = new THREE.CylinderGeometry(0.06, 0.06, 1.1, 6);
        const dropMesh = new THREE.Mesh(dropGeo, mastSteelMat);
        dropMesh.position.set(pt.x + pt.normalX * offset, pt.y + 5.7, pt.z + pt.normalZ * offset);
        catGroup.add(dropMesh);
      });
    }

    catGroup.userData = {
      componentType: 'מערכת חשמול רכבת',
      name: 'מערך רשת עילית OCS 25kV AC (50Hz)',
      chainage: 'PK 0+000 עד 8+500',
      minStage: 7,
      specs: [
        { label: 'מתח הזנה נומינלי', value: '25,000V AC' },
        { label: 'גובה תיל מגע מעל מסילה', value: '5.30 מטר' },
        { label: 'מרווח תקני בין עמודים', value: `${mastSpacingM} מטר` },
        { label: 'מתיחה מכנית מבוקרת', value: '15 kN (כבל נושא ותיל מגע)' },
        { label: 'תחנת השנאה והזנה (TSS)', value: 'חיבור לרשת החשמל הארצית ב-161kV' }
      ]
    };

    this.catenaryGroup.add(catGroup);
  }

  private buildClashMarkers(clashes: ClashDetectionResult[]): void {
    const points = this.state.alignmentPoints();

    clashes.forEach((clash) => {
      const pt = this.geoCalc.interpolateAlignment(points, clash.chainageM);

      // 3D Visual indicator (Glowing diamond / octahedron)
      const geo = new THREE.OctahedronGeometry(1.6);
      const mat = new THREE.MeshStandardMaterial({
        color: clash.severity === 'קריטי' ? 0xc94d4d : (clash.severity === 'גבוה' ? 0xd99638 : 0x3b82f6),
        emissive: clash.severity === 'קריטי' ? 0x7f1d1d : 0x78350f,
        roughness: 0.2,
        metalness: 0.8
      });

      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(pt.x, pt.y + 4.5, pt.z);

      mesh.userData = {
        componentType: 'התנגשות הנדסית (BIM Clash)',
        name: clash.description,
        chainage: `PK ${Math.round(clash.chainageM / 1000)}+${clash.chainageM % 1000}`,
        specs: [
          { label: 'מזהה התנגשות', value: clash.id },
          { label: 'רכיב א׳', value: clash.componentA },
          { label: 'רכיב ב׳', value: clash.componentB },
          { label: 'חומרה', value: clash.severity },
          { label: 'סטטוס', value: clash.status },
          { label: 'הערת מתכנן', value: clash.designerNote }
        ]
      };

      this.clashMarkersGroup.add(mesh);
    });
  }

  private buildTrains(): void {
    this.trainsGroup.clear();
    this.trainMeshes = [];

    const trains = this.state.trains();
    const trainMatDesiro = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8, // Blue Israel Railways EMU
      metalness: 0.7,
      roughness: 0.3
    });

    const trainMatTwindexx = new THREE.MeshStandardMaterial({
      color: 0x2563eb,
      metalness: 0.7,
      roughness: 0.3
    });

    const windowMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.9,
      roughness: 0.1
    });

    const lightMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      emissive: 0xfef08a,
      emissiveIntensity: 1.2
    });

    trains.forEach((tr) => {
      const trainGroup = new THREE.Group();
      trainGroup.userData = { minStage: 10 };

      const carCount = tr.carsCount;
      const carLength = tr.totalLengthM / carCount;
      const isTwindexx = tr.trainType.includes('קומותיים');
      const carHeight = isTwindexx ? 4.6 : 3.8;
      const carWidth = 3.0;

      // Build train cars (locomotive front + coaches)
      for (let c = 0; c < carCount; c++) {
        const carGeo = new THREE.BoxGeometry(carWidth, carHeight, carLength - 0.4);
        const carMesh = new THREE.Mesh(carGeo, isTwindexx ? trainMatTwindexx : trainMatDesiro);
        carMesh.position.set(0, carHeight / 2 + 0.4, -c * carLength);
        carMesh.castShadow = true;
        trainGroup.add(carMesh);

        // Window strips on both sides
        const winGeo = new THREE.BoxGeometry(carWidth + 0.05, isTwindexx ? 2.2 : 1.2, carLength - 3);
        const winMesh = new THREE.Mesh(winGeo, windowMat);
        winMesh.position.set(0, carHeight / 2 + 0.5, -c * carLength);
        trainGroup.add(winMesh);

        // Headlights on leading car
        if (c === 0) {
          [-0.9, 0.9].forEach((lx) => {
            const lightGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.2, 12);
            lightGeo.rotateX(Math.PI / 2);
            const lightMesh = new THREE.Mesh(lightGeo, lightMat);
            lightMesh.position.set(lx, 1.2, carLength / 2);
            trainGroup.add(lightMesh);
          });

          // Pantograph touching overhead contact wire
          const pantoGeo = new THREE.BoxGeometry(1.6, 0.8, 1.8);
          const pantoMesh = new THREE.Mesh(pantoGeo, new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9 }));
          pantoMesh.position.set(0, carHeight + 0.7, 0);
          trainGroup.add(pantoMesh);
        }
      }

      trainGroup.userData = {
        componentType: 'צי נייד - רכבת נוסעים',
        name: tr.name,
        chainage: `PK ${Math.round(tr.chainagePositionM / 1000)}+${Math.round(tr.chainagePositionM % 1000)}`,
        specs: [
          { label: 'קוד רכבת', value: tr.code },
          { label: 'דגם', value: tr.trainType },
          { label: 'מהירות נוכחית', value: `${tr.currentSpeedKmh} קמ"ש` },
          { label: 'מספר קרונות', value: `${tr.carsCount} יחידות` },
          { label: 'קיבולת נוסעים', value: `${tr.passengerCapacity} מקומות ישיבה` },
          { label: 'מקטע איתות תפוס', value: tr.currentBlockId }
        ]
      };

      this.trainsGroup.add(trainGroup);
      this.trainMeshes.push({ id: tr.id, group: trainGroup });
    });
  }

  private update4DVisibility(activePhase: number): void {
    // Traverse groups and check minStage
    const groups = [
      this.terrainGroup,
      this.bridgeGroup,
      this.tunnelGroup,
      this.tracksGroup,
      this.catenaryGroup,
      this.stationsGroup,
      this.trainsGroup
    ];

    groups.forEach((g) => {
      g.traverse((child) => {
        if (child.userData && typeof child.userData['minStage'] === 'number') {
          const minStage = child.userData['minStage'];
          child.visible = activePhase >= minStage;
        }
      });
    });
  }

  private applyCameraPreset(preset: string): void {
    if (!this.camera || !this.controls) return;

    switch (preset) {
      case 'free':
        this.camera.position.set(380, 160, 2600);
        this.controls.target.set(220, 40, 2600);
        break;
      case 'station-south':
        this.camera.position.set(160, 48, 1180);
        this.controls.target.set(60, 36, 1220);
        break;
      case 'bridge-view':
        this.camera.position.set(560, 85, 3180);
        this.controls.target.set(420, 46, 3200);
        break;
      case 'tunnel-portal':
        this.camera.position.set(690, 115, 5320);
        this.controls.target.set(610, 75, 5420);
        break;
      case 'drone-corridor':
        this.camera.position.set(1400, 750, 4200);
        this.controls.target.set(400, 50, 4250);
        break;
      case 'driver-cab':
        // Updated dynamically in the animation loop
        break;
    }
  }

  private tick(): void {
    this.animationFrameId = requestAnimationFrame(this.tick.bind(this));

    const now = performance.now();
    const delta = Math.min((now - this.lastTime) / 1000, 0.1);
    this.lastTime = now;

    const points = this.state.alignmentPoints();

    // Advance train simulation state
    this.state.tickTrains(delta);

    // Update 3D train positions along the track
    const currentTrains = this.state.trains();
    currentTrains.forEach((tr) => {
      const entry = this.trainMeshes.find((m) => m.id === tr.id);
      if (entry) {
        const pt = this.geoCalc.interpolateAlignment(points, tr.chainagePositionM);
        const trackOffset = tr.direction === 1 ? -2.25 : 2.25;

        entry.group.position.set(pt.x + pt.normalX * trackOffset, pt.y, pt.z + pt.normalZ * trackOffset);

        let rotY = Math.atan2(pt.tangentX, pt.tangentZ);
        if (tr.direction === -1) rotY += Math.PI;
        entry.group.rotation.set(0, rotY, 0);

        // Driver Cab Camera POV update
        if (this.state.viewPreset() === 'driver-cab' && tr.id === 'TR-101') {
          const cabX = pt.x + pt.normalX * trackOffset;
          const cabY = pt.y + 3.4;
          const cabZ = pt.z + pt.normalZ * trackOffset;
          this.camera.position.set(cabX, cabY, cabZ);

          const lookDist = 180;
          const targetPt = this.geoCalc.interpolateAlignment(points, tr.chainagePositionM + tr.direction * lookDist);
          this.controls.target.set(targetPt.x + targetPt.normalX * trackOffset, targetPt.y + 2.5, targetPt.z + targetPt.normalZ * trackOffset);
        }
      }
    });

    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }
}
