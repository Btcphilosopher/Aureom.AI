// Models for Israel Railways Digital Twin & Engineering Simulation Studio

export type EngineeringTab = 
  | 'digital-twin' 
  | 'alignment' 
  | 'cross-section' 
  | 'stations-structures' 
  | 'electrification' 
  | 'signalling' 
  | 'construction-4d' 
  | 'boq-cost' 
  | 'clash-detection' 
  | 'reports-export';

export interface AlignmentPoint {
  id: string;
  name: string;
  chainage: number; // Stationing in meters (e.g. 0 = PK 0+000)
  x: number; // Local Easting (m)
  z: number; // Local Northing (m)
  elevation: number; // Elevation in meters above sea level (m ASL)
  curveRadius: number; // 0 for tangent (straight), or radius in meters (e.g. 1200m)
  spiralLength: number; // Transition spiral / clothoid length (m)
  gradePercent: number; // Longitudinal slope %
  designSpeedKmh: number; // Design speed (km/h)
  cantMm: number; // Superelevation / Cant (mm)
}

export interface PlatformConfig {
  id: string;
  name: string;
  stationId: string;
  length: number; // m (e.g. 350m for 12-car double-deck train)
  width: number; // m (e.g. 8.5m)
  heightAboveRailMm: number; // 760mm or 960mm standard Israel Railways platform
  isIsland: boolean;
  edgeSafetyTileWidthMm: number; // 600mm tactile yellow warning band
  canopyCoveragePercent: number; // % covered by shelter
}

export interface StationModel {
  id: string;
  name: string;
  chainageStart: number;
  chainageEnd: number;
  platforms: PlatformConfig[];
  hasPedestrianOverpass: boolean;
  hasUnderpass: boolean;
  hasElevatorShafts: boolean;
  parkingSpaces: number;
  bldgFootprintSqM: number;
  operationalStatus: 'תכנון ראשוני' | 'תכנון מפורט' | 'בביצוע' | 'פעיל';
}

export interface BridgeStructure {
  id: string;
  name: string;
  chainageStart: number;
  chainageEnd: number;
  lengthMeters: number;
  spanCount: number;
  pierHeightMaxM: number;
  deckWidthM: number;
  structureType: 'קורות בטון דרוך' | 'גשר מקטעתי תיבתי' | 'גשר מסבך פלדה';
  bearingCapacityTonnes: number;
  clearanceUnderDeckM: number;
}

export interface TunnelStructure {
  id: string;
  name: string;
  chainageStart: number;
  chainageEnd: number;
  lengthMeters: number;
  crossSectionType: 'קשת פרסית (TBM)' | 'חתך מעגלי כפול' | 'חתך NATM';
  innerDiameterM: number;
  coverDepthMaxM: number;
  crossPassageSpacingM: number;
  hasVentilationShafts: boolean;
}

export interface CatenarySystemConfig {
  systemType: '25kV AC 50Hz OCS';
  nominalVoltageKv: number; // 25
  contactWireHeightM: number; // 5.3m
  mastSpacingM: number; // Standard 55m to 65m
  messengerTensionKn: number; // 15 kN
  contactWireTensionKn: number; // 15 kN
  substationsCount: number;
  totalMastsCount: number;
}

export interface TrainUnit {
  id: string;
  code: string;
  name: string;
  trainType: 'רכבת חשמלית רב-נייחת (EMU Desiro)' | 'רכבת קומותיים חשמלית (Twindexx)' | 'רכבת משא כבדה';
  maxSpeedKmh: number;
  currentSpeedKmh: number;
  targetSpeedKmh: number;
  chainagePositionM: number;
  direction: 1 | -1; // 1 = Northbound, -1 = Southbound
  status: 'בתנועה' | 'עצירה בתחנה' | 'ממתין לאיתות' | 'בלימת חירום';
  carsCount: number;
  totalLengthM: number;
  passengerCapacity: number;
  currentBlockId: string;
}

export interface SignallingBlock {
  id: string;
  name: string;
  chainageStart: number;
  chainageEnd: number;
  aspect: 'GREEN' | 'DOUBLE_YELLOW' | 'YELLOW' | 'RED';
  isOccupied: boolean;
  occupyingTrainId?: string;
  speedLimitKmh: number;
  baliseType: 'Eurobalise ETCS L2' | 'PZB';
}

export interface ConstructionPhase {
  stageNumber: number;
  name: string;
  code: string;
  description: string;
  durationWeeks: number;
  progressPercent: number;
  activeEquipment: string[];
  budgetEstimatedNis: number;
  status: 'הושלם' | 'בביצוע' | 'מתוכנן' | 'מעוכב';
}

export interface GanttTask {
  id: string;
  name: string;
  stageNumber: number;
  startWeek: number;
  endWeek: number;
  durationWeeks: number;
  progressPercent: number;
  dependencies: string[];
  isCritical: boolean;
  costEstimatedNis: number;
  responsibleDiscipline: 'גאומטריה ועפר' | 'מבנים וגישור' | 'מסילאות' | 'חשמול ומערכות' | 'איתות ובקרה';
}

export interface ClashDetectionResult {
  id: string;
  chainageM: number;
  componentA: string;
  componentB: string;
  severity: 'קריטי' | 'גבוה' | 'בינוני' | 'מידע';
  description: string;
  clearanceMm: number;
  requiredClearanceMm: number;
  status: 'פתוח' | 'בבדיקה' | 'נפתר';
  designerNote: string;
}

export interface BoQRecord {
  itemCode: string;
  description: string;
  category: 'עבודות עפר' | 'מבנים וגישור' | 'מסילאות' | 'חשמול' | 'איתות ותחנות';
  unit: string;
  calculatedQuantity: number;
  unitPriceNis: number;
  totalPriceNis: number;
  uncertaintyMarginPercent: number;
  isParametric: boolean;
}

export interface ProjectMetadata {
  id: string;
  name: string;
  corridorName: string;
  engineeringVersion: string;
  lastUpdated: string;
  totalLengthKm: number;
  gaugeMm: number; // 1435 mm standard
  trackCount: number; // 2 double track
  designStandard: 'תקן רכבת ישראל / EN 13803' | 'TSI High Speed';
  isSyntheticDemo: boolean;
}
