package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatMessage(
    val sender: String, // "User" or "AI"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

class TrailAtlasViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TrailAtlasDatabase.getDatabase(application)
    private val repository = TrailAtlasRepository(db.dao())

    // UI state flows
    val user: StateFlow<User?> = repository.userFlow.stateIn(viewModelScope, SharingStarted.Lazily, null)
    val trails: StateFlow<List<Trail>> = repository.trails.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val parks: StateFlow<List<Park>> = repository.parks.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val reviews: StateFlow<List<Review>> = repository.reviews.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val hikingLogs: StateFlow<List<HikingLog>> = repository.hikingLogs.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val challenges: StateFlow<List<Challenge>> = repository.challenges.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val trailLists: StateFlow<List<TrailList>> = repository.trailLists.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Search and Filter States
    val searchQuery = MutableStateFlow("")
    val filterDifficulty = MutableStateFlow("All") // "All", "Easy", "Moderate", "Hard"
    val filterType = MutableStateFlow("All") // "All", "Loop", "Out & Back", "Point to Point"
    val filterPetFriendly = MutableStateFlow(false)
    val filterAccessible = MutableStateFlow(false)

    // Filtered Trails
    val filteredTrails: StateFlow<List<Trail>> = combine(
        trails, searchQuery, filterDifficulty, filterType, filterPetFriendly, filterAccessible
    ) { array ->
        val trailsList = array[0] as List<Trail>
        val query = array[1] as String
        val diff = array[2] as String
        val type = array[3] as String
        val pet = array[4] as Boolean
        val acc = array[5] as Boolean

        trailsList.filter { trail ->
            val matchesQuery = trail.name.contains(query, ignoreCase = true) || 
                               trail.parkName.contains(query, ignoreCase = true) ||
                               trail.state.contains(query, ignoreCase = true)
            val matchesDiff = diff == "All" || trail.difficulty.equals(diff, ignoreCase = true)
            val matchesType = type == "All" || trail.type.equals(type, ignoreCase = true)
            val matchesPet = !pet || trail.isPetFriendly
            val matchesAcc = !acc || trail.isAccessible
            matchesQuery && matchesDiff && matchesType && matchesPet && matchesAcc
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Selected Trail Details (Reactive)
    private val _selectedTrailId = MutableStateFlow<Int?>(null)
    val selectedTrail: StateFlow<Trail?> = _selectedTrailId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getTrailById(id)
    }.stateIn(viewModelScope, SharingStarted.Lazily, null)

    val selectedTrailReviews: StateFlow<List<Review>> = _selectedTrailId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getReviewsForTrail(id)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Selected Park Details
    private val _selectedParkId = MutableStateFlow<Int?>(null)
    val selectedPark: StateFlow<Park?> = _selectedParkId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getParkById(id)
    }.stateIn(viewModelScope, SharingStarted.Lazily, null)

    val selectedParkTrails: StateFlow<List<Trail>> = combine(trails, selectedPark) { trailsList, park ->
        if (park == null) emptyList() else trailsList.filter { it.parkName.equals(park.name, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // AtlasAI Chat Assistant State
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage("AI", "Hi there! I'm **AtlasAI**, your smart outdoor discovery assistant. Describe your ideal hiking spot, ask for safety tips, or request custom checklists across the USA!")
        )
    )
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()
    val isChatLoading = MutableStateFlow(false)

    // AI Summary State
    val aiSummaryText = MutableStateFlow("")
    val isSummaryLoading = MutableStateFlow(false)

    // Simulated GPS Hike Recording State
    val isRecording = MutableStateFlow(false)
    val recordingTrail = MutableStateFlow<Trail?>(null)
    val durationSeconds = MutableStateFlow(0)
    val distanceMiles = MutableStateFlow(0.0)
    val elevationGainFeet = MutableStateFlow(0.0)
    val gpsPoints = MutableStateFlow<List<Pair<Double, Double>>>(emptyList())
    private var recordingJob: Job? = null

    init {
        // Seed database immediately on launch
        viewModelScope.launch {
            repository.seedIfNeeded()
        }
    }

    fun selectTrail(id: Int) {
        _selectedTrailId.value = id
        aiSummaryText.value = "" // clear previous summary
    }

    fun selectPark(id: Int) {
        _selectedParkId.value = id
    }

    // AI Summary Generation
    fun generateAISummary(trail: Trail) {
        viewModelScope.launch {
            isSummaryLoading.value = true
            aiSummaryText.value = "Consulting AtlasAI wilderness journals..."
            try {
                val summary = repository.generateTrailAISummary(trail.name, trail.parkName)
                aiSummaryText.value = summary
            } catch (e: Exception) {
                aiSummaryText.value = "Unable to fetch summary: ${e.localizedMessage}"
            } finally {
                isSummaryLoading.value = false
            }
        }
    }

    // Chat operations
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = ChatMessage("User", text)
        _chatHistory.update { it + userMsg }

        viewModelScope.launch {
            isChatLoading.value = true
            try {
                val aiResponse = repository.queryAtlasAI(text)
                _chatHistory.update { it + ChatMessage("AI", aiResponse) }
            } catch (e: Exception) {
                _chatHistory.update { it + ChatMessage("AI", "I hit a snag on the trail: ${e.localizedMessage}") }
            } finally {
                isChatLoading.value = false
            }
        }
    }

    fun clearChat() {
        _chatHistory.value = listOf(
            ChatMessage("AI", "Hi there! I'm **AtlasAI**, your smart outdoor discovery assistant. Describe your ideal hiking spot, ask for safety tips, or request custom checklists across the USA!")
        )
    }

    // Simulated GPS Hike Recording Loop
    fun startHikeRecording(trail: Trail?) {
        if (isRecording.value) return
        isRecording.value = true
        recordingTrail.value = trail
        durationSeconds.value = 0
        distanceMiles.value = 0.0
        elevationGainFeet.value = 0.0
        
        val startLat = trail?.latitude ?: 37.0902
        val startLng = trail?.longitude ?: -95.7129
        gpsPoints.value = listOf(startLat to startLng)

        recordingJob = viewModelScope.launch {
            var elapsed = 0
            var dist = 0.0
            var elev = 0.0
            var currentLat = startLat
            var currentLng = startLng

            while (isRecording.value) {
                delay(1000) // update every second
                elapsed++
                durationSeconds.value = elapsed

                // Simulated hiking speeds and climbs (approx 0.0005 miles per second, i.e., ~2 mph)
                val distanceTick = 0.0004 + (Math.random() * 0.0002)
                dist += distanceTick
                distanceMiles.value = Math.round(dist * 100.0) / 100.0

                // Simulated elevation tick (climbing)
                if (trail != null && elev < trail.elevationGainFeet) {
                    val elevTick = 0.5 + (Math.random() * 0.8)
                    elev += elevTick
                    elevationGainFeet.value = Math.round(elev * 10.0) / 10.0
                } else if (trail == null) {
                    elev += (if (Math.random() > 0.4) 0.5 else -0.2) // random path
                    elevationGainFeet.value = Math.round(elev * 10.0) / 10.0
                }

                // Simulate GPS latitude/longitude movement
                currentLat += (Math.random() - 0.5) * 0.0002
                currentLng += (Math.random() - 0.5) * 0.0002
                gpsPoints.update { it + (currentLat to currentLng) }
            }
        }
    }

    fun stopHikeRecordingAndSave(notes: String) {
        recordingJob?.cancel()
        val trail = recordingTrail.value
        val logName = trail?.name ?: "Custom Explorer Hike"
        val dist = distanceMiles.value
        val elev = elevationGainFeet.value
        val dur = durationSeconds.value / 60 // convert to minutes
        val pointsStr = gpsPoints.value.joinToString(";") { "${it.first},${it.second}" }

        viewModelScope.launch {
            repository.saveCompletedHike(
                trailId = trail?.id,
                trailName = logName,
                distance = dist,
                duration = if (dur <= 0) 1 else dur,
                elevation = elev,
                notes = notes,
                gpsPoints = pointsStr
            )
            // Reset states
            isRecording.value = false
            recordingTrail.value = null
        }
    }

    fun cancelHikeRecording() {
        recordingJob?.cancel()
        isRecording.value = false
        recordingTrail.value = null
    }

    // Community additions & moderation
    fun submitTrailReview(rating: Int, comment: String, dogFriendlyRating: Int, hazardReported: Boolean, hazardDesc: String) {
        val trailId = _selectedTrailId.value ?: return
        val currentUserName = user.value?.name ?: "Trail Explorer"
        val review = Review(
            trailId = trailId,
            userName = currentUserName,
            rating = rating,
            comment = comment,
            dogFriendlyRating = dogFriendlyRating,
            hazardReported = hazardReported,
            hazardDescription = if (hazardReported) hazardDesc else "",
            timestamp = System.currentTimeMillis()
        )
        viewModelScope.launch {
            repository.addReview(review)
        }
    }

    fun deleteReview(reviewId: Int) {
        viewModelScope.launch {
            repository.deleteReview(reviewId)
        }
    }

    fun addNewTrail(name: String, parkName: String, state: String, desc: String, diff: String, miles: Double, feet: Double, mins: Int, type: String, lat: Double, lng: Double) {
        val newTrail = Trail(
            name = name,
            parkName = parkName,
            state = state,
            description = desc,
            difficulty = diff,
            lengthMiles = miles,
            elevationGainFeet = feet,
            estimatedTimeMins = mins,
            type = type,
            latitude = lat,
            longitude = lng,
            imageUrl = "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80",
            safetyNotes = "Newly registered community trail. Walk with care."
        )
        viewModelScope.launch {
            repository.addTrail(newTrail)
        }
    }

    fun resetProfile() {
        viewModelScope.launch {
            repository.resetUserProfile()
        }
    }

    fun deleteHikingLog(logId: Int) {
        viewModelScope.launch {
            repository.deleteHikingLog(logId)
        }
    }
}
