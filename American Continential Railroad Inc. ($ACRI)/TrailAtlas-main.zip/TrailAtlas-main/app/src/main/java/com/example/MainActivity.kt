package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.TrailAtlasViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContainer()
            }
        }
    }
}

@Composable
fun MainAppContainer() {
    val viewModel: TrailAtlasViewModel = viewModel()
    
    // Custom Navigation State Manager
    var currentTab by remember { mutableStateOf("explore") }
    var previousTabStack by remember { mutableStateOf(listOf<String>()) }
    var currentScreenState by remember { mutableStateOf("dashboard") } // "dashboard" or "trail_detail"

    // Custom back handler to support clean natural Android system Back gestures
    BackHandler(enabled = currentScreenState == "trail_detail" || previousTabStack.isNotEmpty()) {
        if (currentScreenState == "trail_detail") {
            currentScreenState = "dashboard"
        } else if (previousTabStack.isNotEmpty()) {
            currentTab = previousTabStack.last()
            previousTabStack = previousTabStack.dropLast(1)
        }
    }

    val tabsList = listOf(
        NavigationTabItem("explore", "Explore", Icons.Default.Explore),
        NavigationTabItem("discover", "Discovery", Icons.Default.Search),
        NavigationTabItem("map", "Track & Map", Icons.Default.Map),
        NavigationTabItem("journal", "Journal", Icons.Default.Book),
        NavigationTabItem("ai_guide", "AtlasAI", Icons.Default.AutoAwesome),
        NavigationTabItem("admin", "Admin", Icons.Default.AdminPanelSettings)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (currentScreenState == "dashboard") {
                NavigationBar {
                    tabsList.forEach { tab ->
                        NavigationBarItem(
                            selected = currentTab == tab.route,
                            onClick = {
                                if (currentTab != tab.route) {
                                    previousTabStack = previousTabStack + currentTab
                                    currentTab = tab.route
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 11.sp) },
                            modifier = Modifier.testTag("nav_${tab.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (currentScreenState == "trail_detail") {
                TrailDetailScreen(
                    viewModel = viewModel,
                    onBack = { currentScreenState = "dashboard" },
                    onRecordHikeOnTrail = { trail ->
                        viewModel.cancelHikeRecording()
                        viewModel.startHikeRecording(trail)
                        currentScreenState = "dashboard"
                        currentTab = "map"
                    }
                )
            } else {
                when (currentTab) {
                    "explore" -> ExploreScreen(
                        viewModel = viewModel,
                        onNavigateToTrail = { id ->
                            viewModel.selectTrail(id)
                            currentScreenState = "trail_detail"
                        },
                        onNavigateToTab = { tab ->
                            previousTabStack = previousTabStack + currentTab
                            currentTab = tab
                        }
                    )
                    "discover" -> DiscoverScreen(
                        viewModel = viewModel,
                        onNavigateToTrail = { id ->
                            viewModel.selectTrail(id)
                            currentScreenState = "trail_detail"
                        }
                    )
                    "map" -> MapScreen(
                        viewModel = viewModel,
                        onNavigateToTab = { tab ->
                            previousTabStack = previousTabStack + currentTab
                            currentTab = tab
                        }
                    )
                    "journal" -> JournalScreen(
                        viewModel = viewModel,
                        onNavigateToTab = { tab ->
                            previousTabStack = previousTabStack + currentTab
                            currentTab = tab
                        }
                    )
                    "ai_guide" -> AiGuideScreen(
                        viewModel = viewModel
                    )
                    "admin" -> AdminScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

data class NavigationTabItem(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
