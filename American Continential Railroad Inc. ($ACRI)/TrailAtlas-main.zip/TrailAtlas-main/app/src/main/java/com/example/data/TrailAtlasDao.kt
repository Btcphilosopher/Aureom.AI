package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TrailAtlasDao {

    // User Operations
    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserFlow(id: Int = 1): Flow<User?>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserSync(id: Int = 1): User?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)


    // Trail Operations
    @Query("SELECT * FROM trails ORDER BY name ASC")
    fun getAllTrails(): Flow<List<Trail>>

    @Query("SELECT * FROM trails WHERE id = :id LIMIT 1")
    fun getTrailById(id: Int): Flow<Trail?>

    @Query("SELECT * FROM trails WHERE id = :id LIMIT 1")
    suspend fun getTrailByIdSync(id: Int): Trail?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrails(trails: List<Trail>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrail(trail: Trail)

    @Query("DELETE FROM trails WHERE id = :id")
    suspend fun deleteTrail(id: Int)


    // Park Operations
    @Query("SELECT * FROM parks ORDER BY name ASC")
    fun getAllParks(): Flow<List<Park>>

    @Query("SELECT * FROM parks WHERE id = :id LIMIT 1")
    fun getParkById(id: Int): Flow<Park?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParks(parks: List<Park>)


    // Review Operations
    @Query("SELECT * FROM reviews WHERE trailId = :trailId ORDER BY timestamp DESC")
    fun getReviewsForTrail(trailId: Int): Flow<List<Review>>

    @Query("SELECT * FROM reviews ORDER BY timestamp DESC")
    fun getAllReviews(): Flow<List<Review>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: Review)

    @Query("DELETE FROM reviews WHERE id = :id")
    suspend fun deleteReviewById(id: Int)


    // Hiking Log Operations
    @Query("SELECT * FROM hiking_logs ORDER BY date DESC")
    fun getAllHikingLogs(): Flow<List<HikingLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHikingLog(log: HikingLog)

    @Query("DELETE FROM hiking_logs WHERE id = :id")
    suspend fun deleteHikingLogById(id: Int)


    // Challenge Operations
    @Query("SELECT * FROM challenges ORDER BY id ASC")
    fun getAllChallenges(): Flow<List<Challenge>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChallenges(challenges: List<Challenge>)

    @Update
    suspend fun updateChallenge(challenge: Challenge)


    // Trail List Operations
    @Query("SELECT * FROM trail_lists ORDER BY name ASC")
    fun getAllTrailLists(): Flow<List<TrailList>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrailList(list: TrailList)

    @Update
    suspend fun updateTrailList(list: TrailList)

    @Query("DELETE FROM trail_lists WHERE id = :id")
    suspend fun deleteTrailListById(id: Int)
}
