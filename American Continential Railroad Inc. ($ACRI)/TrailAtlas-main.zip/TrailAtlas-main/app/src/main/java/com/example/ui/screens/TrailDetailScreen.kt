package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.*
import com.example.ui.TrailAtlasViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrailDetailScreen(
    viewModel: TrailAtlasViewModel,
    onBack: () -> Unit,
    onRecordHikeOnTrail: (Trail) -> Unit
) {
    val trail by viewModel.selectedTrail.collectAsState()
    val reviews by viewModel.selectedTrailReviews.collectAsState()
    val aiSummary by viewModel.aiSummaryText.collectAsState()
    val isSummaryLoading by viewModel.isSummaryLoading.collectAsState()

    var showReviewDialog by remember { mutableStateOf(false) }
    var ratingVal by remember { mutableStateOf(5) }
    var reviewComment by remember { mutableStateOf("") }
    var dogFriendlyVal by remember { mutableStateOf(5) }
    var hazardReported by remember { mutableStateOf(false) }
    var hazardDesc by remember { mutableStateOf("") }

    if (trail == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val selectedTrail = trail!!

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("trail_detail_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // Hero Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            ) {
                AsyncImage(
                    model = selectedTrail.imageUrl,
                    contentDescription = selectedTrail.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Gradient Overlays
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Black.copy(alpha = 0.4f), Color.Transparent, Color.Black.copy(alpha = 0.8f))
                            )
                        )
                )

                // Top Controls
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Box(
                        modifier = Modifier
                            .background(
                                color = when (selectedTrail.difficulty.lowercase()) {
                                    "easy" -> Color(0xFF4CAF50)
                                    "moderate" -> Color(0xFFFF9800)
                                    else -> Color(0xFFF44336)
                                },
                                shape = RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = selectedTrail.difficulty,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Bottom Title HUD
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = selectedTrail.name,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(14.dp))
                        Text(
                            text = "${selectedTrail.parkName}, ${selectedTrail.state}",
                            fontSize = 14.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Central content layout
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Quick Stats Hub
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.04f), RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    QuickStatItem(title = "Distance", value = "${selectedTrail.lengthMiles} mi", subValue = selectedTrail.type, icon = Icons.Default.DirectionsWalk)
                    QuickStatItem(title = "Elev. Gain", value = "+${selectedTrail.elevationGainFeet.toInt()} ft", subValue = "Vertical", icon = Icons.Default.Terrain)
                    QuickStatItem(title = "Est. Duration", value = "${selectedTrail.estimatedTimeMins}m", subValue = "Paced", icon = Icons.Default.Timer)
                }

                // Action Buttons (GPS shortcut and AI Summary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onRecordHikeOnTrail(selectedTrail) },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(50.dp)
                            .testTag("record_shortcut_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Navigation, contentDescription = "Navigate")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Record on Map", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.generateAISummary(selectedTrail) },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("ai_summary_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI Summary")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("AI Guide Summary", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // AI Guide Summary Container
                if (aiSummary.isNotEmpty() || isSummaryLoading) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.04f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = "AI summary", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Text("AtlasAI Guide Summary", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            if (isSummaryLoading) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                    Text("Generating smart guidebook details...", fontSize = 12.sp, color = Color.Gray)
                                }
                            } else {
                                Text(
                                    text = aiSummary,
                                    fontSize = 13.sp,
                                    style = LocalTextStyle.current.copy(lineHeight = 18.sp),
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f)
                                )
                            }
                        }
                    }
                }

                // Trail Description
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Guidebook Description", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        text = selectedTrail.description,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                        style = LocalTextStyle.current.copy(lineHeight = 20.sp)
                    )
                }

                // Safety Notes Alert Card
                if (selectedTrail.safetyNotes.isNotEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.12f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = "Safety Alert", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                            Column {
                                Text("Trail Advisory", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                                Text(selectedTrail.safetyNotes, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f))
                            }
                        }
                    }
                }

                // Custom Canvas Altitude Elevation Profile
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Altitude Elevation Profile", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            
                            // Draw Grid Lines
                            val gridColor = Color.LightGray.copy(alpha = 0.4f)
                            drawLine(gridColor, start = Offset(0f, h * 0.25f), end = Offset(w, h * 0.25f), strokeWidth = 1f)
                            drawLine(gridColor, start = Offset(0f, h * 0.5f), end = Offset(w, h * 0.5f), strokeWidth = 1f)
                            drawLine(gridColor, start = Offset(0f, h * 0.75f), end = Offset(w, h * 0.75f), strokeWidth = 1f)

                            // Generate Altitude Profile Spline Path
                            // Easy hikes rise and fall slightly; hard hikes rise sharply
                            val isHard = selectedTrail.difficulty.lowercase() == "hard"
                            val isEasy = selectedTrail.difficulty.lowercase() == "easy"
                            
                            val profilePath = Path().apply {
                                moveTo(0f, h * 0.8f)
                                if (isHard) {
                                    cubicTo(w * 0.3f, h * 0.7f, w * 0.6f, h * 0.2f, w * 0.8f, h * 0.2f)
                                    lineTo(w, h * 0.25f)
                                } else if (isEasy) {
                                    cubicTo(w * 0.3f, h * 0.75f, w * 0.6f, h * 0.65f, w * 0.8f, h * 0.75f)
                                    lineTo(w, h * 0.8f)
                                } else { // Moderate
                                    cubicTo(w * 0.3f, h * 0.75f, w * 0.6f, h * 0.4f, w * 0.8f, h * 0.45f)
                                    lineTo(w, h * 0.55f)
                                }
                            }

                            // Draw Altitude Gradient Fill under spline
                            drawPath(
                                path = profilePath,
                                color = Color(0xFF4CAF50).copy(alpha = 0.15f)
                            )
                            // Draw Altitude Outline Line
                            drawPath(
                                path = profilePath,
                                color = Color(0xFF2E7D32),
                                style = Stroke(width = 4f)
                            )

                            // Markers
                            drawCircle(Color(0xFF2E7D32), radius = 6f, center = Offset(0f, h * 0.8f))
                            if (isHard) {
                                drawCircle(Color(0xFFD32F2F), radius = 8f, center = Offset(w * 0.8f, h * 0.2f))
                            } else if (isEasy) {
                                drawCircle(Color(0xFFFF9800), radius = 8f, center = Offset(w * 0.6f, h * 0.65f))
                            } else {
                                drawCircle(Color(0xFFFF9800), radius = 8f, center = Offset(w * 0.6f, h * 0.4f))
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Trailhead: 0.0 mi", fontSize = 10.sp, color = Color.Gray)
                        Text("Peak Ascent altitude", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("Summit: ${selectedTrail.lengthMiles} mi", fontSize = 10.sp, color = Color.Gray)
                    }
                }

                // Community Ratings Distribution & write button
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Community Reviews", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Button(
                            onClick = { showReviewDialog = true },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(34.dp).testTag("write_review_button")
                        ) {
                            Icon(Icons.Default.RateReview, contentDescription = "Write", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Write Review", fontSize = 11.sp)
                        }
                    }

                    if (reviews.isEmpty()) {
                        Text(
                            text = "No reviews yet. Be the first to add hiking report details!",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 300.dp)
                        ) {
                            items(reviews) { review ->
                                ReviewItem(review = review)
                            }
                        }
                    }
                }
            }
        }
    }

    // Write Review Dialog
    if (showReviewDialog) {
        Dialog(onDismissRequest = { showReviewDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Write Trail Review", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)

                    // Rating Star Row
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Overall Trail Rating", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            (1..5).forEach { star ->
                                IconButton(
                                    onClick = { ratingVal = star },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = if (star <= ratingVal) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "$star Stars",
                                        tint = if (star <= ratingVal) Color(0xFFFFC107) else Color.Gray,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Dog Friendliness Star Row
                    if (selectedTrail.isPetFriendly) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Dog-Friendliness Rating", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                (1..5).forEach { star ->
                                    IconButton(
                                        onClick = { dogFriendlyVal = star },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (star <= dogFriendlyVal) Icons.Default.Pets else Icons.Outlined.Pets,
                                            contentDescription = "$star Stars",
                                            tint = if (star <= dogFriendlyVal) MaterialTheme.colorScheme.primary else Color.Gray,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Hazard toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = "Hazard warning", tint = Color.Red, modifier = Modifier.size(16.dp))
                            Text("Report Safety Hazard / Closures", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                        Switch(checked = hazardReported, onCheckedChange = { hazardReported = it })
                    }

                    if (hazardReported) {
                        TextField(
                            value = hazardDesc,
                            onValueChange = { hazardDesc = it },
                            placeholder = { Text("Describe obstacle (fallen tree, ice, flooding)...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("hazard_desc_field"),
                            shape = RoundedCornerShape(8.dp),
                            colors = TextFieldDefaults.colors(
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            )
                        )
                    }

                    // General comments
                    TextField(
                        value = reviewComment,
                        onValueChange = { reviewComment = it },
                        placeholder = { Text("Share tips about trail conditions, packing, or parking...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("review_comment_field"),
                        shape = RoundedCornerShape(10.dp),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showReviewDialog = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.submitTrailReview(
                                    rating = ratingVal,
                                    comment = reviewComment,
                                    dogFriendlyRating = dogFriendlyVal,
                                    hazardReported = hazardReported,
                                    hazardDesc = hazardDesc
                                )
                                showReviewDialog = false
                                reviewComment = ""
                                hazardDesc = ""
                                hazardReported = false
                            },
                            modifier = Modifier.testTag("submit_review_confirm")
                        ) {
                            Text("Submit Review")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickStatItem(
    title: String,
    value: String,
    subValue: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onBackground)
        Text(title, fontSize = 10.sp, color = Color.Gray)
        Text(subValue, fontSize = 9.sp, color = Color.LightGray)
    }
}

@Composable
fun ReviewItem(review: Review) {
    val dateStr = remember(review.timestamp) {
        SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(review.timestamp))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.03f))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(review.userName.firstOrNull()?.toString() ?: "T", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Text(review.userName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Text(dateStr, fontSize = 10.sp, color = Color.Gray)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(5) { star ->
                    Icon(
                        imageVector = if (star < review.rating) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Star",
                        tint = if (star < review.rating) Color(0xFFFFC107) else Color.Gray,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Text(
                text = review.comment,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )

            if (review.hazardReported) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Red.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Warning, contentDescription = "Closure Hazard", tint = Color.Red, modifier = Modifier.size(14.dp))
                    Text(
                        text = "Reported Obstacle: ${review.hazardDescription}",
                        color = Color.Red,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
