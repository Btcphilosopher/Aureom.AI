package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: Int = 1,
    val name: String = "John Doe",
    val email: String = "john.doe@trailatlas.com",
    val profileImage: String = "avatar_placeholder",
    val totalDistance: Double = 0.0,
    val totalElevation: Double = 0.0,
    val hikesCompleted: Int = 0
)

@Entity(tableName = "trails")
data class Trail(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val parkName: String,
    val state: String,
    val description: String,
    val difficulty: String, // "Easy", "Moderate", "Hard"
    val lengthMiles: Double,
    val elevationGainFeet: Double,
    val estimatedTimeMins: Int,
    val type: String, // "Loop", "Out & Back", "Point to Point"
    val latitude: Double,
    val longitude: Double,
    val imageUrl: String,
    val safetyNotes: String = "",
    val isPetFriendly: Boolean = true,
    val isAccessible: Boolean = false
)

@Entity(tableName = "parks")
data class Park(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val state: String,
    val description: String,
    val visitorInfo: String,
    val facilities: String, // Comma separated e.g., "Parking, Restrooms, Campground"
    val imageUrl: String,
    val type: String // "National Park", "State Park", "National Forest", "Wilderness Area"
)

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val trailId: Int,
    val userName: String,
    val rating: Int, // 1 to 5
    val comment: String,
    val sceneryRating: Int = 5,
    val qualityRating: Int = 5,
    val accessibilityRating: Int = 5,
    val wildlifeRating: Int = 5,
    val dogFriendlyRating: Int = 5,
    val hazardReported: Boolean = false,
    val hazardDescription: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "hiking_logs")
data class HikingLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val trailId: Int?,
    val trailName: String,
    val date: Long = System.currentTimeMillis(),
    val distance: Double,
    val durationMinutes: Int,
    val elevationGain: Double,
    val notes: String = "",
    val gpsTrackPoints: String = "", // Format: "lat,lng;lat,lng;lat,lng" for simplified offline drawing
    val isCompleted: Boolean = true
)

@Entity(tableName = "challenges")
data class Challenge(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val targetValue: Double,
    val currentValue: Double,
    val unit: String, // "hikes", "miles", "feet", "parks"
    val isCompleted: Boolean = false
)

@Entity(tableName = "trail_lists")
data class TrailList(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val iconName: String, // "star", "bookmark", "favorite", "forest"
    val trailIds: String = "" // Comma separated list of trail IDs e.g. "1,2,5"
)
