package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TrailAtlasRepository(private val dao: TrailAtlasDao) {

    companion object {
        private const val TAG = "TrailAtlasRepository"
    }

    // Expose flows from DAO
    val userFlow: Flow<User?> = dao.getUserFlow()
    val trails: Flow<List<Trail>> = dao.getAllTrails()
    val parks: Flow<List<Park>> = dao.getAllParks()
    val reviews: Flow<List<Review>> = dao.getAllReviews()
    val hikingLogs: Flow<List<HikingLog>> = dao.getAllHikingLogs()
    val challenges: Flow<List<Challenge>> = dao.getAllChallenges()
    val trailLists: Flow<List<TrailList>> = dao.getAllTrailLists()

    fun getReviewsForTrail(trailId: Int): Flow<List<Review>> = dao.getReviewsForTrail(trailId)
    fun getTrailById(id: Int): Flow<Trail?> = dao.getTrailById(id)
    fun getParkById(id: Int): Flow<Park?> = dao.getParkById(id)

    // Seeding database
    suspend fun seedIfNeeded() = withContext(Dispatchers.IO) {
        val existingTrails = trails.first()
        if (existingTrails.isEmpty()) {
            Log.d(TAG, "Seeding default parks, trails, challenges, and user profile...")

            // 1. Insert default user
            dao.insertUser(
                User(
                    id = 1,
                    name = "Tom Walker",
                    email = "tom@ahyx.org",
                    profileImage = "avatar_placeholder",
                    totalDistance = 14.5,
                    totalElevation = 3200.0,
                    hikesCompleted = 3
                )
            )

            // 2. Insert Parks
            val defaultParks = listOf(
                Park(
                    name = "Zion National Park",
                    state = "Utah",
                    description = "An outdoor wonderland with massive, shear sandstone cliffs, narrow deep canyons, and winding rivers.",
                    visitorInfo = "Visitor Center open 8 AM - 5 PM. Shuttle service mandatory for canyon scenic drive from spring to fall.",
                    facilities = "Visitor Center, Restrooms, Shuttle Stop, Campgrounds, Drinking Water",
                    imageUrl = "https://images.unsplash.com/photo-1538964173425-93884d738596?auto=format&fit=crop&w=800&q=80",
                    type = "National Park"
                ),
                Park(
                    name = "Yosemite National Park",
                    state = "California",
                    description = "Famous for its spectacular granite cliffs, giant sequoia groves, massive waterfalls, and stunning valley views.",
                    visitorInfo = "Open 24 hours. Reservations required during peak summer weekends. Carry snow chains in winter.",
                    facilities = "Lodging, Campgrounds, Visitor Center, Restrooms, Shuttle, Dining",
                    imageUrl = "https://images.unsplash.com/photo-1426604966848-d7adac402bff?auto=format&fit=crop&w=800&q=80",
                    type = "National Park"
                ),
                Park(
                    name = "Mount Rainier National Park",
                    state = "Washington",
                    description = "Surrounding an active 14,411-foot volcano capped by 26 glaciers, offering pristine subalpine meadows and deep forests.",
                    visitorInfo = "Timed-entry reservations required during mid-summer. Snow tires required during winter.",
                    facilities = "Visitor Center, Restrooms, Picnic Area, Wilderness Permits, Camping",
                    imageUrl = "https://images.unsplash.com/photo-1544198365-f5d60b6d8190?auto=format&fit=crop&w=800&q=80",
                    type = "National Park"
                ),
                Park(
                    name = "Acadia National Park",
                    state = "Maine",
                    description = "Where rugged rocky coastlines meet dense pine woodlands and glacier-sculpted granite domes, overlooking the Atlantic Ocean.",
                    visitorInfo = "Vehicle reservation required for Cadillac Mountain Summit Road. Park pass required year-round.",
                    facilities = "Gift Shop, Visitor Center, Restrooms, Carriage Roads, Campgrounds",
                    imageUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80",
                    type = "National Park"
                ),
                Park(
                    name = "Grand Canyon National Park",
                    state = "Arizona",
                    description = "One of the Seven Natural Wonders of the world, containing a breathtakingly massive gorge carved by the Colorado River.",
                    visitorInfo = "South Rim open year-round. North Rim open seasonally (May-Oct). Use shuttle buses during peak seasons.",
                    facilities = "Visitor Center, Restrooms, Drinking Water, Museum, Shuttle, Lodging",
                    imageUrl = "https://images.unsplash.com/photo-1615551043360-33de8b5f410c?auto=format&fit=crop&w=800&q=80",
                    type = "National Park"
                ),
                Park(
                    name = "Sedona Red Rock Country",
                    state = "Arizona",
                    description = "A gorgeous desert landscape surrounded by towering red sandstone formations, spires, and spiritual vortexes.",
                    visitorInfo = "Red Rock Pass required for parking at most trailheads. Bring at least 3 liters of water per hiker.",
                    facilities = "Parking, Trailheads, Information Kiosks, Restrooms at major trails",
                    imageUrl = "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80",
                    type = "Recreation Area"
                ),
                Park(
                    name = "Great Smoky Mountains",
                    state = "Tennessee",
                    description = "America's most visited national park, featuring rich deciduous forests, rolling ridge-lines covered in smoky mist, and diverse wildlife.",
                    visitorInfo = "No entrance fee, but parking tags are required for vehicles parking longer than 15 minutes. Heavy summer congestion.",
                    facilities = "Visitor Center, Campgrounds, Restrooms, Historical Cabins, Hiking Trails",
                    imageUrl = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
                    type = "National Park"
                )
            )
            dao.insertParks(defaultParks)

            // 3. Insert Trails
            val defaultTrails = listOf(
                Trail(
                    name = "Angels Landing",
                    parkName = "Zion National Park",
                    state = "Utah",
                    description = "An iconic, thrilling hike along a narrow sandstone ridge with steep drop-offs on both sides. Fixed metal chains help you navigate the final spine to an unforgettable 360-degree overlook of Zion Canyon.",
                    difficulty = "Hard",
                    lengthMiles = 5.4,
                    elevationGainFeet = 1488.0,
                    estimatedTimeMins = 240,
                    type = "Out & Back",
                    latitude = 37.2691,
                    longitude = -112.9474,
                    imageUrl = "https://images.unsplash.com/photo-1538964173425-93884d738596?auto=format&fit=crop&w=800&q=80",
                    safetyNotes = "Extremely steep. Not recommended for children or anyone fearful of heights. An Angels Landing permit is strictly required to hike the chained ridge section. Beware of high desert heat and carrying at least 3L of water.",
                    isPetFriendly = false,
                    isAccessible = false
                ),
                Trail(
                    name = "Half Dome Trail",
                    parkName = "Yosemite National Park",
                    state = "California",
                    description = "The ultimate Yosemite challenge. Trek past Vernal and Nevada Falls, climbing steep granite steps to the sub-dome before ascending the famous steel cable path directly up the sheer granite face to the summit.",
                    difficulty = "Hard",
                    lengthMiles = 15.0,
                    elevationGainFeet = 4800.0,
                    estimatedTimeMins = 720,
                    type = "Out & Back",
                    latitude = 37.7422,
                    longitude = -119.5332,
                    imageUrl = "https://images.unsplash.com/photo-1426604966848-d7adac402bff?auto=format&fit=crop&w=800&q=80",
                    safetyNotes = "Extremely strenuous. Do not attempt if storm clouds or wet conditions are present, as the wet granite is lethal. Steel cable ascent requires heavy-duty grip gloves. Start before 5 AM to complete in daylight.",
                    isPetFriendly = false,
                    isAccessible = false
                ),
                Trail(
                    name = "Skyline Trail Loop",
                    parkName = "Mount Rainier National Park",
                    state = "Washington",
                    description = "Provides sweeping, close-up vistas of Mount Rainier, active glaciers, cascading waterfalls, and vibrant subalpine wildflower meadows. On clear days, Mount Adams, Mount St. Helens, and Mount Hood pierce the horizon.",
                    difficulty = "Moderate",
                    lengthMiles = 5.5,
                    elevationGainFeet = 1700.0,
                    estimatedTimeMins = 200,
                    type = "Loop",
                    latitude = 46.7861,
                    longitude = -121.7350,
                    imageUrl = "https://images.unsplash.com/photo-1544198365-f5d60b6d8190?auto=format&fit=crop&w=800&q=80",
                    safetyNotes = "Snow can persist on the trail well into late July. Microspikes and trekking poles are recommended in early summer. Sudden mountain fog can obscure navigation markers.",
                    isPetFriendly = false,
                    isAccessible = false
                ),
                Trail(
                    name = "Precipice Trail Loop",
                    parkName = "Acadia National Park",
                    state = "Maine",
                    description = "A thrilling vertical climb on the rugged face of Champlain Mountain using iron rungs, ladders, wooden bridges, and handholds anchored directly into the granite cliffside. Incredible ocean and island views.",
                    difficulty = "Hard",
                    lengthMiles = 3.2,
                    elevationGainFeet = 1000.0,
                    estimatedTimeMins = 150,
                    type = "Loop",
                    latitude = 44.3491,
                    longitude = -68.1831,
                    imageUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80",
                    safetyNotes = "Not for those afraid of heights. Descending the iron rung section is extremely dangerous and strictly forbidden; return via the Champlain North Ridge Trail. Closed in spring for Peregrine Falcon nesting.",
                    isPetFriendly = false,
                    isAccessible = false
                ),
                Trail(
                    name = "Bright Angel Trail",
                    parkName = "Grand Canyon National Park",
                    state = "Arizona",
                    description = "The premier canyon hiking trail, descending steep switchbacks along the Bright Angel Fault into the dramatic inner gorge of the Grand Canyon. Features multiple water stations and shade houses.",
                    difficulty = "Hard",
                    lengthMiles = 9.5,
                    elevationGainFeet = 3080.0,
                    estimatedTimeMins = 360,
                    type = "Out & Back",
                    latitude = 36.0573,
                    longitude = -112.1439,
                    imageUrl = "https://images.unsplash.com/photo-1615551043360-33de8b5f410c?auto=format&fit=crop&w=800&q=80",
                    safetyNotes = "Hiking down is optional, hiking up is mandatory! Canyon heat can exceed 110°F. NEVER attempt to hike to the river and back in a single day during summer. Carry electrolyte drinks and drink continuously.",
                    isPetFriendly = false,
                    isAccessible = false
                ),
                Trail(
                    name = "Devil's Bridge Trail",
                    parkName = "Sedona Red Rock Country",
                    state = "Arizona",
                    description = "A beautiful red rock walk leading to the largest natural sandstone arch in Sedona. Perfect for families, offering picturesque desert flora, junipers, and an opportunities to walk across the bridge.",
                    difficulty = "Moderate",
                    lengthMiles = 3.9,
                    elevationGainFeet = 520.0,
                    estimatedTimeMins = 120,
                    type = "Out & Back",
                    latitude = 34.9028,
                    longitude = -111.8138,
                    imageUrl = "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80",
                    safetyNotes = "The bridge is wider than it appears, but extreme care is needed at the edges. No shade along the route. Arrive before 7 AM as dry creek parking sells out.",
                    isPetFriendly = true,
                    isAccessible = false
                ),
                Trail(
                    name = "Alum Cave Trail to Mt LeConte",
                    parkName = "Great Smoky Mountains",
                    state = "Tennessee",
                    description = "Climb through old-growth hardwood forests, walking through Arch Rock, past the historic Alum Cave bluffs, and ascending up to the high rustic cabins of Mount LeConte Lodge with endless mountain vistas.",
                    difficulty = "Moderate",
                    lengthMiles = 10.5,
                    elevationGainFeet = 2760.0,
                    estimatedTimeMins = 360,
                    type = "Out & Back",
                    latitude = 35.6295,
                    longitude = -83.4514,
                    imageUrl = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
                    safetyNotes = "Slippery rock sections and narrow ledge trails are secured by cable handrails. Black bear encounters are common; pack out all food remnants and never feed wildlife.",
                    isPetFriendly = false,
                    isAccessible = false
                )
            )
            dao.insertTrails(defaultTrails)

            // 4. Insert Default Reviews
            val seededTrails = dao.getAllTrails().first()
            seededTrails.forEach { trail ->
                dao.insertReview(
                    Review(
                        trailId = trail.id,
                        userName = "Alex Outdoors",
                        rating = 5,
                        comment = "Spectacular views, well-marked trail! Did it in dry weather, which is perfect. Highly recommend early mornings.",
                        sceneryRating = 5,
                        qualityRating = 5,
                        accessibilityRating = 4,
                        wildlifeRating = 4,
                        dogFriendlyRating = if (trail.isPetFriendly) 5 else 1,
                        hazardReported = false
                    )
                )
                dao.insertReview(
                    Review(
                        trailId = trail.id,
                        userName = "Sierra Ranger",
                        rating = 4,
                        comment = "Amazing experience but the elevation gain is no joke. Make sure to pack extra water and wear shoes with good traction.",
                        sceneryRating = 5,
                        qualityRating = 4,
                        accessibilityRating = 3,
                        wildlifeRating = 3,
                        dogFriendlyRating = if (trail.isPetFriendly) 4 else 1,
                        hazardReported = false
                    )
                )
            }

            // 5. Insert Challenges
            val defaultChallenges = listOf(
                Challenge(
                    name = "National Park Explorer",
                    description = "Log hikes in 3 different legendary US National Parks.",
                    targetValue = 3.0,
                    currentValue = 1.0,
                    unit = "parks",
                    isCompleted = false
                ),
                Challenge(
                    name = "100-Mile Club",
                    description = "Walk, trek, or backpack 100 cumulative miles on American trails.",
                    targetValue = 100.0,
                    currentValue = 14.5,
                    unit = "miles",
                    isCompleted = false
                ),
                Challenge(
                    name = "Summit Elevation Climb",
                    description = "Climb a total of 10,000 feet of cumulative elevation gain.",
                    targetValue = 10000.0,
                    currentValue = 3200.0,
                    unit = "feet",
                    isCompleted = false
                ),
                Challenge(
                    name = "Trail Enthusiast",
                    description = "Complete and log 10 separate hikes in your journal.",
                    targetValue = 10.0,
                    currentValue = 3.0,
                    unit = "hikes",
                    isCompleted = false
                )
            )
            dao.insertChallenges(defaultChallenges)

            // 6. Insert Lists
            val defaultLists = listOf(
                TrailList(
                    name = "Bucket List Hikes",
                    description = "Must-do, once-in-a-lifetime trails across America.",
                    iconName = "star",
                    trailIds = "1,2,5"
                ),
                TrailList(
                    name = "Weekend Excursions",
                    description = "Perfect scenic, shorter trips for weekend escapes.",
                    iconName = "forest",
                    trailIds = "3,6"
                ),
                TrailList(
                    name = "Vertical Alpine Challenges",
                    description = "Steep climbs that push your lungs and reward you with sky-high views.",
                    iconName = "bookmark",
                    trailIds = "1,2,4,7"
                )
            )
            defaultLists.forEach { dao.insertTrailList(it) }

            // 7. Insert Initial completed logs
            dao.insertHikingLog(
                HikingLog(
                    trailId = 6,
                    trailName = "Devil's Bridge Trail",
                    distance = 3.9,
                    durationMinutes = 110,
                    elevationGain = 520.0,
                    notes = "Beautiful sunny hike, went early. Walked all the way onto the sandstone bridge! Highly recommended.",
                    gpsTrackPoints = "34.901,-111.813;34.902,-111.813;34.903,-111.814",
                    isCompleted = true
                )
            )
            dao.insertHikingLog(
                HikingLog(
                    trailId = 3,
                    trailName = "Skyline Trail Loop",
                    distance = 5.5,
                    durationMinutes = 180,
                    elevationGain = 1700.0,
                    notes = "Spectacular view of Mount Rainier. Meadows are in full bloom. Encountered a tiny black bear, kept our distance.",
                    gpsTrackPoints = "46.786,-121.735;46.787,-121.736;46.788,-121.737",
                    isCompleted = true
                )
            )
        }
    }

    // Add Review
    suspend fun addReview(review: Review) = withContext(Dispatchers.IO) {
        dao.insertReview(review)
    }

    // Delete review
    suspend fun deleteReview(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteReviewById(id)
    }

    // Add custom Trail
    suspend fun addTrail(trail: Trail) = withContext(Dispatchers.IO) {
        dao.insertTrail(trail)
    }

    // Log a new Hike and update user statistics + check challenges
    suspend fun saveCompletedHike(
        trailId: Int?,
        trailName: String,
        distance: Double,
        duration: Int,
        elevation: Double,
        notes: String,
        gpsPoints: String
    ) = withContext(Dispatchers.IO) {
        // 1. Insert hiking log
        val newLog = HikingLog(
            trailId = trailId,
            trailName = trailName,
            distance = distance,
            durationMinutes = duration,
            elevationGain = elevation,
            notes = notes,
            gpsTrackPoints = gpsPoints,
            isCompleted = true
        )
        dao.insertHikingLog(newLog)

        // 2. Fetch current user & update stats
        val currentUser = dao.getUserSync(1) ?: User(id = 1)
        val updatedUser = currentUser.copy(
            totalDistance = currentUser.totalDistance + distance,
            totalElevation = currentUser.totalElevation + elevation,
            hikesCompleted = currentUser.hikesCompleted + 1
        )
        dao.insertUser(updatedUser)

        // 3. Update challenges
        val activeChallenges = dao.getAllChallenges().first()
        activeChallenges.forEach { challenge ->
            var changed = false
            var currentVal = challenge.currentValue
            var isComp = challenge.isCompleted

            if (!isComp) {
                when (challenge.unit) {
                    "miles" -> {
                        currentVal += distance
                        changed = true
                    }
                    "feet" -> {
                        currentVal += elevation
                        changed = true
                    }
                    "hikes" -> {
                        currentVal += 1.0
                        changed = true
                    }
                    "parks" -> {
                        // If hiking in a registered park, increment
                        if (trailId != null) {
                            currentVal += 0.5 // mock progression
                            changed = true
                        }
                    }
                }

                if (changed) {
                    if (currentVal >= challenge.targetValue) {
                        currentVal = challenge.targetValue
                        isComp = true
                    }
                    dao.updateChallenge(challenge.copy(currentValue = currentVal, isCompleted = isComp))
                }
            }
        }
    }

    // Delete a hiking log
    suspend fun deleteHikingLog(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteHikingLogById(id)
    }

    // Customize Trail Lists
    suspend fun addTrailList(list: TrailList) = withContext(Dispatchers.IO) {
        dao.insertTrailList(list)
    }

    suspend fun updateTrailList(list: TrailList) = withContext(Dispatchers.IO) {
        dao.updateTrailList(list)
    }

    suspend fun deleteTrailList(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteTrailListById(id)
    }

    // Reset all database stats to zero (useful for testing or profile reset)
    suspend fun resetUserProfile() = withContext(Dispatchers.IO) {
        dao.insertUser(
            User(
                id = 1,
                name = "Tom Walker",
                email = "tom@ahyx.org",
                profileImage = "avatar_placeholder",
                totalDistance = 0.0,
                totalElevation = 0.0,
                hikesCompleted = 0
            )
        )
        val list = dao.getAllChallenges().first()
        list.forEach {
            dao.updateChallenge(it.copy(currentValue = 0.0, isCompleted = false))
        }
    }

    // --- Gemini Interactive Features ---
    suspend fun queryAtlasAI(userPrompt: String): String {
        val systemInstruction = """
            You are "AtlasAI", the premier hiking counselor, outdoor safety guide, and recreation expert for the United States.
            You provide descriptive, high-quality, encouraging, and accurate answers regarding hiking routes, parks, gear lists, and wilderness safety.
            Always maintain a warm, conversational, inspiring outdoor vibe. Recommend trails with actual difficulty levels, mileage, and specific scenic landmarks.
            Reference Leave No Trace principles, appropriate safety gear (hydration, microspikes, topography maps), and seasonal constraints where appropriate.
            Keep your answers beautifully formatted with bullet points and bold headers.
        """.trimIndent()
        return GeminiService.generateContent(userPrompt, systemInstruction)
    }

    suspend fun generateTrailAISummary(trailName: String, parkName: String): String {
        val prompt = "Provide a comprehensive, high-fidelity AI summary for the trail '$trailName' in '$parkName'. Highlight scenic sights, historical details, safety notes, packing suggestions, and the best time of year to visit."
        val systemInstruction = "You are a senior National Geographic wilderness guide. Write a brief, breathtaking, and informative summary. Max 4 short paragraphs. Use bullet points."
        return GeminiService.generateContent(prompt, systemInstruction)
    }
}
