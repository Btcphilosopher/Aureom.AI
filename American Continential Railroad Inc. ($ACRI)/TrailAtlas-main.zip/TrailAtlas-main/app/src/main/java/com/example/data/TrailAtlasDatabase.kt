package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        User::class,
        Trail::class,
        Park::class,
        Review::class,
        HikingLog::class,
        Challenge::class,
        TrailList::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TrailAtlasDatabase : RoomDatabase() {
    abstract fun dao(): TrailAtlasDao

    companion object {
        @Volatile
        private var INSTANCE: TrailAtlasDatabase? = null

        fun getDatabase(context: Context): TrailAtlasDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TrailAtlasDatabase::class.java,
                    "trail_atlas_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
