package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme - Warm Organic / Cultural
val OrganicDarkGreen = Color(0xFF2D4B37)    // Rich dark green
val OrganicSage = Color(0xFF5A634E)         // Soft sage
val OrganicOchre = Color(0xFFD4A373)        // Warm earthy clay
val OrganicBackground = Color(0xFFF8F9F3)   // Creamy background
val OrganicTextDark = Color(0xFF1A1C19)     // Almost black text
val OrganicLightContainer = Color(0xFFE7EDD1)// Soft green-yellow alert highlight
val OrganicWarmGray = Color(0xFFF4F1ED)     // Light warm gray/tan card background
val OrganicBorder = Color(0xFFE1E3D3)        // Sage/cream light border

// Dark Theme - Warm Organic / Cultural Dark
val OrganicDarkGreenDark = Color(0xFF8BAE8E)   // Desaturated soft light green for dark mode primary
val OrganicSageDark = Color(0xFFA1AC91)        // Soft desaturated sage
val OrganicOchreDark = Color(0xFFE4C09A)       // Warm earthy clay desaturated
val OrganicBackgroundDark = Color(0xFF1A1C19)  // Deep dark olive/charcoal background
val OrganicSurfaceDark = Color(0xFF232621)     // Deep card background
val OrganicTextLight = Color(0xFFE1E3D3)       // Soft cream/sage text
val OrganicLightContainerDark = Color(0xFF2D4B37) // Deep green alert highlight in dark mode
val OrganicWarmGrayDark = Color(0xFF2D322A)    // Muted dark warm gray/olive
val OrganicBorderDark = Color(0xFF3B4136)      // Dark sage border

// Status colors
val AlertRed = Color(0xFFD32F2F)
val WarningOrange = Color(0xFFF57C00)
val InfoBlue = Color(0xFF1976D2)
