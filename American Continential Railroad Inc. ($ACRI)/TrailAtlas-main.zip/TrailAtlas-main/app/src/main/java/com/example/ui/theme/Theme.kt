package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = OrganicDarkGreenDark,
    secondary = OrganicSageDark,
    tertiary = OrganicOchreDark,
    background = OrganicBackgroundDark,
    surface = OrganicSurfaceDark,
    surfaceVariant = OrganicWarmGrayDark,
    onPrimary = OrganicBackgroundDark,
    onSecondary = OrganicBackgroundDark,
    onTertiary = OrganicBackgroundDark,
    onBackground = OrganicTextLight,
    onSurface = OrganicTextLight,
    onSurfaceVariant = OrganicTextLight,
    primaryContainer = OrganicLightContainerDark,
    onPrimaryContainer = OrganicTextLight,
    outline = OrganicBorderDark,
    error = AlertRed
)

private val LightColorScheme = lightColorScheme(
    primary = OrganicDarkGreen,
    secondary = OrganicSage,
    tertiary = OrganicOchre,
    background = OrganicBackground,
    surface = Color.White,
    surfaceVariant = OrganicWarmGray,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = OrganicTextDark,
    onSurface = OrganicTextDark,
    onSurfaceVariant = OrganicSage,
    primaryContainer = OrganicLightContainer,
    onPrimaryContainer = OrganicDarkGreen,
    outline = OrganicBorder,
    error = AlertRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Set dynamic color to false by default to showcase the beautiful earth branding
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
