#!/usr/bin/env bash
set -euo pipefail

echo "=== BRITISH RAIL — AutoDriver Build & Verification ==="

if command -v cargo >/dev/null 2>&1; then
  echo "[1/3] Running Rust workspace tests (11 crates, 12 acceptance scenarios)..."
  (cd rust && cargo test --workspace)
  echo "[2/3] Executing Rust headless scenario suite..."
  (cd rust && cargo run -p br_simulation > /tmp/br_baseline_scenarios.json)
else
  echo "[WARN] Rust toolchain (cargo) not installed in this container; using TypeScript twin engine."
fi

if command -v Rscript >/dev/null 2>&1; then
  echo "[3/3] Running R analytics parity and scenario evaluation..."
  Rscript -e "source('r_analytics/R/07_verify_rust_parity.R'); verify_rust_parity('models/br_class_395_residual_v1.json')"
else
  echo "[WARN] Rscript not installed in this container; skipping live R batch execution."
fi

echo "=== Starting Diagnostic Web Console on port 3000 ==="
npm run dev
