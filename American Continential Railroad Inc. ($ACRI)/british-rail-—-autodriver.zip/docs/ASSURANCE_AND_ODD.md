# BRITISH RAIL — AutoDriver: Operational Design Domain, Manufacturer Interfaces & Railway Assurance

## 1. Simulation Success vs. Evidence Required for Physical Deployment

Passing all 12 simulation acceptance scenarios demonstrates algorithmic soundness, state-machine completeness, supervisor fault isolation, and deterministic replay inside a software-in-the-loop (SIL-0) simulation environment. **Simulation success is NOT safety evidence for physical mainline operation.**

Before physical track trials or passenger service (GoA2 / GoA3 / GoA4 under IEC 62290), the following evidence is mandatory:

1. **SIL-4 Train Protection Separation (EN 50126 / EN 50128 / EN 50129)**
   - Independent hardware-enforced Automatic Train Protection (ETCS Level 2 / AWS / TPWS) must remain physically and electrically isolated from the AutoDriver software stack.
   - AutoDriver runs as an **ATO (Automatic Train Operation)** overlay (SIL-2 or lower) subordinate to SIL-4 vital ATP braking curves.
2. **Real-Time Target Execution & WCET Evidence**
   - This codebase avoids unbounded heap allocations in the core control loop (`BoundedQueue<T, N>`) and measures loop latency, jitter, and missed deadlines.
   - Physical deployment requires Worst-Case Execution Time (WCET) static analysis and deterministic RTOS scheduling evidence (e.g., QNX Neutrino / VxWorks / PREEMPT_RT Linux on certified railway traction hardware) with zero missed 100ms / 20ms deadlines.
3. **Hardware-in-the-Loop (HIL) & Trackside Validation**
   - Validated braking curve curves across worn wheel profiles, leaf-fall adhesion (`μ < 0.08`), wet rail, gradients, and real pneumatic/electro-pneumatic brake-pipe lag.
   - Eurobalise telegram decoding certification and certified odometer pulse-generator calibration.
4. **Independent Railway Assurance (AsBo / ISA / NoBo)**
   - Common Safety Method for Risk Evaluation and Assessment (CSM-RA) hazard log closure.
   - Independent Safety Assessor (ISA) audit of software configuration, build provenance (`Cargo.lock`, `renv.lock`), and formal verification of the 13-state behaviour FSM and supervisor latch rules.

## 2. Operational Design Domain (ODD)

- **Corridor Topology**: Standard-gauge (1,435 mm) segregated mainline with Eurobalise spacing $\le 1,200\text{ m}$ and known Route Atlas geometry.
- **Signalling Interface**: Authoritative ETCS / digital Movement Authority (MA) with explicit `end_of_authority_m`, `ceiling_speed_mps`, and expiry timestamp.
- **Speed Envelope**: $0$ to $35\text{ m/s}$ ($126\text{ km/h}$) within this demonstration corridor.
- **Adhesion Envelope**: Nominal $\mu \in [0.45, 1.0]$. Below $\mu < 0.60$, `LongitudinalPlanner` scales deceleration curves and `RuntimeSupervisor` enforces `DegradedCautious` speed limits.
- **Perception Scope**: Forward-facing camera + range sensor are **bounded research overlays** for platform edge / stop marker / corridor object evaluation. They **never** grant movement authority or override signalling.
- **Unattended Door Operation**: Explicitly disabled by default (`unattended_door_operation_enabled = false`) and requires platform screen doors or certified obstacle-detection interlocks before enabling.

## 3. Manufacturer-Adapter Boundary (`br_vehicle_adapter`)

- **Default Lockout**: `PhysicalActuationConfig.enabled` is `false` by default.
- **Command Boundary**:
  - `supports_effort_command`: Normalized traction effort `%` $[0, 1]$ and service brake `%` $[0, 1]$ (mutually exclusive).
  - `supports_position_command`: Disabled unless vehicle TCMS supports closed-loop berth targeting.
  - Emergency brake loop is wired via hardware vital relay; software may request emergency brake (`emergency_brake = true`), never inhibit it.
- **Door Interlock**: Platform-side door release is permitted **only** when `speed <= 0.05 m/s`, train nose/tail within platform bounds, `position_uncertainty_m <= 3.0 m`, and platform `available == true`.

## 4. Runtime Twin Note

In environments where `rustc`/`cargo` and `Rscript` are not installed (such as the web preview container), the Express backend executes a deterministic TypeScript twin (`src/sim/engine.ts`) implementing the identical equations, state machine, supervisor latch logic, and `models/br_class_395_residual_v1.json` inference rules. On a Rust + R workstation, execute `./scripts/run_all.sh` to run the native Cargo workspace tests and R analytics parity checks.
