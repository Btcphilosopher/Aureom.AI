use br_behaviour::{BehaviourConfig, BehaviourPlanner, BehaviourState};
use br_localisation::{LocalisationConfig, LocalisationFilter};
use br_perception::PerceptionPipeline;
use br_recorder::{BoundedRecorder, OnboardRecordFrame};
use br_route_model::{
    BaliseEntry, DoorSide, GradientSegment, MovementAuthority, OperationalWorldModel, RouteAtlas,
    SourcedField, SpeedSegment, StationStop, TunnelZone,
};
use br_sensors::{
    BaliseReference, CameraDetectionFixture, CameraPerceptionInput, CoordinateFrame, DataSource,
    DoorInterlockState, GnssFix, ImuMeasurement, Kilograms, Metres, MetresPerSecond,
    MetresPerSecondSquared, Newtons, RangeSensorInput, SpeedSensor, TimestampMs, VehicleTelemetry,
    WheelOdometry,
};
use br_supervisor::{RecoveryAuthorisation, RuntimeSupervisor, SupervisorConfig, SupervisorDisposition};
use br_trajectory::LongitudinalPlanner;
use br_vehicle_adapter::{MockVehicleInterface, PhysicalActuationConfig, VehicleInterface};
use br_vehicle_control::{DrivingController, ResidualModelArtifact};
use serde::{Deserialize, Serialize};
use std::time::Instant;

/// Strictly separated from DriverWorldView / OperationalWorldModel.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulatorTruth {
    pub position_m: f64,
    pub speed_mps: f64,
    pub accel_mps2: f64,
    pub adhesion: f64,
    pub energy_consumed_kwh: f64,
    pub regen_energy_kwh: f64,
    pub actual_brake_effectiveness: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ScenarioId {
    NominalMultiStation,
    SpeedAdaptationRestriction,
    EnergyEfficientCoasting,
    AccuratePlatformStopping,
    ShortenedMovementAuthority,
    SyntheticTrackObstruction,
    GnssLossInTunnel,
    OdometryDisagreement,
    ReducedBrakingPerformance,
    DoorInterlockFailure,
    SensorLatencyExceedance,
    ControllerRestartRecovery,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioMetrics {
    pub scenario: ScenarioId,
    pub driver_mode: String,
    pub passed: bool,
    pub constraint_violations: u32,
    pub stop_position_error_m: f64,
    pub arrival_time_deviation_s: f64,
    pub energy_consumed_kwh: f64,
    pub regen_energy_accepted_kwh: f64,
    pub peak_accel_mps2: f64,
    pub peak_jerk_mps3: f64,
    pub intervention_count: u32,
    pub fault_response_time_ms: Option<u64>,
    pub max_localisation_uncertainty_m: f64,
    pub perception_false_positives: u32,
    pub perception_missed_detections: u32,
    pub obstruction_detection_distance_m: Option<f64>,
    pub obstruction_stopping_feasible: Option<bool>,
    pub notes: String,
}

pub fn default_demo_route() -> RouteAtlas {
    RouteAtlas {
        route_id: "BR-KENT-01".into(),
        route_name: "Kent Coast High Speed Demonstration Corridor".into(),
        total_length_m: 8600.0,
        track_id: "UP_MAIN_01".into(),
        speed_segments: vec![
            SpeedSegment { start_m: 0.0, end_m: 450.0, limit_mps: 18.0, reason: "Terminal throat".into() },
            SpeedSegment { start_m: 450.0, end_m: 2050.0, limit_mps: 35.0, reason: "Mainline".into() },
            SpeedSegment { start_m: 2050.0, end_m: 2650.0, limit_mps: 22.0, reason: "Stratford approach".into() },
            SpeedSegment { start_m: 2650.0, end_m: 4600.0, limit_mps: 35.0, reason: "Thames Tunnel".into() },
            SpeedSegment { start_m: 4600.0, end_m: 5450.0, limit_mps: 20.0, reason: "Ebbsfleet PSR".into() },
            SpeedSegment { start_m: 5450.0, end_m: 7750.0, limit_mps: 32.0, reason: "North Downs".into() },
            SpeedSegment { start_m: 7750.0, end_m: 8600.0, limit_mps: 16.0, reason: "Ashford approach".into() },
        ],
        gradients: vec![
            GradientSegment { start_m: 0.0, end_m: 1100.0, per_mille: 4.5 },
            GradientSegment { start_m: 1100.0, end_m: 2700.0, per_mille: 0.0 },
            GradientSegment { start_m: 2700.0, end_m: 3800.0, per_mille: -11.5 },
            GradientSegment { start_m: 3800.0, end_m: 5300.0, per_mille: 8.0 },
            GradientSegment { start_m: 5300.0, end_m: 8600.0, per_mille: 1.5 },
        ],
        tunnels: vec![
            TunnelZone { id: "TUN-THAMES-01".into(), name: "Thames Underpass".into(), start_m: 3050.0, end_m: 4300.0, gnss_available: false },
        ],
        stations: vec![
            StationStop {
                station_id: "BR-STP".into(), name: "St Pancras International".into(), platform: "Platform 4".into(),
                stop_berth_m: 140.0, platform_start_m: 10.0, platform_end_m: 230.0,
                door_side: DoorSide::Left, scheduled_arrival_s: 0.0, scheduled_departure_s: 5.0,
                min_dwell_s: 5.0, available: true, berth_tolerance_m: 1.5,
            },
            StationStop {
                station_id: "BR-STR".into(), name: "Stratford Parkway".into(), platform: "Platform 2".into(),
                stop_berth_m: 2380.0, platform_start_m: 2230.0, platform_end_m: 2470.0,
                door_side: DoorSide::Right, scheduled_arrival_s: 105.0, scheduled_departure_s: 120.0,
                min_dwell_s: 15.0, available: true, berth_tolerance_m: 1.5,
            },
            StationStop {
                station_id: "BR-EBS".into(), name: "Ebbsfleet Valley".into(), platform: "Platform 1".into(),
                stop_berth_m: 5150.0, platform_start_m: 5000.0, platform_end_m: 5240.0,
                door_side: DoorSide::Left, scheduled_arrival_s: 235.0, scheduled_departure_s: 250.0,
                min_dwell_s: 15.0, available: true, berth_tolerance_m: 1.5,
            },
            StationStop {
                station_id: "BR-ASH".into(), name: "Ashford Central".into(), platform: "Platform 3".into(),
                stop_berth_m: 8220.0, platform_start_m: 8070.0, platform_end_m: 8310.0,
                door_side: DoorSide::Right, scheduled_arrival_s: 375.0, scheduled_departure_s: 400.0,
                min_dwell_s: 20.0, available: true, berth_tolerance_m: 1.5,
            },
        ],
        balises: vec![
            BaliseEntry { balise_id: "EB-001".into(), position_m: 140.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-002".into(), position_m: 600.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-003".into(), position_m: 1400.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-004".into(), position_m: 2240.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-005".into(), position_m: 2380.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-006".into(), position_m: 3020.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-007".into(), position_m: 4330.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-008".into(), position_m: 5010.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-009".into(), position_m: 5150.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-010".into(), position_m: 6200.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-011".into(), position_m: 7400.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-012".into(), position_m: 8080.0, track_id: "UP_MAIN_01".into() },
            BaliseEntry { balise_id: "EB-013".into(), position_m: 8220.0, track_id: "UP_MAIN_01".into() },
        ],
    }
}

/// Deterministic LCG PRNG for reproducible simulation runs.
struct LcgRng(u64);
impl LcgRng {
    fn next_f64(&mut self) -> f64 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1);
        ((self.0 >> 33) as f64) / ((1u64 << 31) as f64)
    }
    fn signed_noise(&mut self, amp: f64) -> f64 {
        (self.next_f64() * 2.0 - 1.0) * amp
    }
}

pub fn run_scenario(
    scenario: ScenarioId,
    seed: u64,
    residual_model: Option<&ResidualModelArtifact>,
) -> ScenarioMetrics {
    let atlas = default_demo_route();
    let mut rng = LcgRng(seed);
    let dt_s = 0.1_f64;
    let max_steps = 4500_usize; // up to 450s

    let mut truth = SimulatorTruth {
        position_m: 140.0,
        speed_mps: 0.0,
        accel_mps2: 0.0,
        adhesion: if scenario == ScenarioId::ReducedBrakingPerformance { 0.52 } else { 0.92 },
        energy_consumed_kwh: 0.0,
        regen_energy_kwh: 0.0,
        actual_brake_effectiveness: if scenario == ScenarioId::ReducedBrakingPerformance { 0.55 } else { 1.0 },
    };

    let mut loc = LocalisationFilter::new("UP_MAIN_01", 140.0, LocalisationConfig::default());
    let perception = PerceptionPipeline::new(0.70, 0.35);
    let mut behaviour = BehaviourPlanner::new(BehaviourConfig::default());
    let planner = LongitudinalPlanner::default();
    let mut controller = DrivingController::default();
    let mut supervisor = RuntimeSupervisor::new(
        SupervisorConfig::default(),
        scenario == ScenarioId::ControllerRestartRecovery,
    );
    let mut vehicle = MockVehicleInterface::new(PhysicalActuationConfig::default());
    let mut recorder: BoundedRecorder<256> = BoundedRecorder::new(25_000);

    let mut last_balise_idx: Option<usize> = None;
    let mut prev_accel = 0.0_f64;
    let mut peak_accel = 0.0_f64;
    let mut peak_jerk = 0.0_f64;
    let mut constraint_violations = 0_u32;
    let mut interventions = 0_u32;
    let mut max_unc_m = 0.0_f64;
    let mut fault_injected_ms: Option<u64> = None;
    let mut fault_response_ms: Option<u64> = None;
    let mut obstruction_det_m: Option<f64> = None;
    let mut obstruction_feasible: Option<bool> = None;
    let mut str_stop_error_m = 0.0_f64;
    let mut str_arrival_s = 105.0_f64;
    let mut recorded_str_stop = false;
    let mut entered_controlled_stop = false;
    let mut entered_await_recovery = false;
    let mut auth_recovered = false;

    for step in 0..max_steps {
        let loop_start = Instant::now();
        let now_ms = TimestampMs((step as u64) * 100);
        let t_s = (step as f64) * dt_s;

        // Movement authority logic per scenario
        let mut eoa_m = 8400.0;
        let mut ma_ceiling_mps = 35.0;
        if scenario == ScenarioId::ShortenedMovementAuthority && t_s >= 45.0 {
            eoa_m = 1850.0;
            fault_injected_ms.get_or_insert(now_ms.0);
        }
        if scenario == ScenarioId::SpeedAdaptationRestriction && t_s >= 30.0 {
            ma_ceiling_mps = 20.0;
        }

        let ma = MovementAuthority {
            track_id: "UP_MAIN_01".into(),
            end_of_authority_m: Metres(eoa_m),
            ceiling_speed_mps: MetresPerSecond(ma_ceiling_mps),
            dispatch_permitted: t_s >= 1.0,
            issued_at_ms: TimestampMs(now_ms.0),
            expires_at_ms: TimestampMs(now_ms.0 + 1500),
            source: DataSource::SignallingEtcs,
        };

        // Scenario fault injections
        let sensor_lag_ms = if scenario == ScenarioId::SensorLatencyExceedance && t_s >= 35.0 {
            fault_injected_ms.get_or_insert(now_ms.0);
            1200
        } else {
            20
        };
        let odom_slip = scenario == ScenarioId::OdometryDisagreement && t_s >= 35.0 && t_s <= 42.0;
        if odom_slip {
            fault_injected_ms.get_or_insert(now_ms.0);
        }
        if scenario == ScenarioId::DoorInterlockFailure && t_s >= 32.0 && t_s <= 35.0 {
            vehicle.inject_door_state(DoorInterlockState::FaultInterlockOpen);
            fault_injected_ms.get_or_insert(now_ms.0);
        } else {
            vehicle.inject_door_state(DoorInterlockState::LockedAndProven);
        }
        if scenario == ScenarioId::ControllerRestartRecovery && t_s >= 3.0 && !auth_recovered {
            // Operator explicitly authorises recovery at t=3.0s only when stationary
            auth_recovered = supervisor.authorise_recovery(
                &RecoveryAuthorisation {
                    operator_id: "BR-SIGNALLER-04".into(),
                    authorised_at_ms: now_ms,
                },
                &OperationalWorldModel {
                    timestamp_ms: now_ms,
                    authorised_track_id: SourcedField { value: "UP_MAIN_01".into(), source: DataSource::SignallingEtcs, updated_at_ms: now_ms, valid: true },
                    position_m: SourcedField { value: Metres(loc.state().position_m.0), source: DataSource::WheelOdometry, updated_at_ms: now_ms, valid: true },
                    position_uncertainty_m: loc.state().position_sigma_m,
                    speed_mps: SourcedField { value: MetresPerSecond(truth.speed_mps), source: DataSource::DopplerRadarSpeed, updated_at_ms: now_ms, valid: true },
                    speed_uncertainty_mps: MetresPerSecond(0.1),
                    applicable_speed_limit_mps: SourcedField { value: MetresPerSecond(18.0), source: DataSource::RouteAtlas, updated_at_ms: now_ms, valid: true },
                    movement_authority: Some(ma.clone()),
                    next_station: atlas.next_station_from(truth.position_m, 1.5).cloned(),
                    gradient: SourcedField { value: atlas.gradient_at(truth.position_m), source: DataSource::RouteAtlas, updated_at_ms: now_ms, valid: true },
                    train_length_m: Metres(121.2),
                    train_mass_kg: Kilograms(268000.0),
                    braking_capability_mps2: SourcedField { value: MetresPerSecondSquared(1.05), source: DataSource::VehicleTcms, updated_at_ms: now_ms, valid: true },
                    estimated_adhesion: truth.adhesion,
                    door_interlock: SourcedField { value: vehicle.door_interlock_state(), source: DataSource::VehicleTcms, updated_at_ms: now_ms, valid: true },
                    relevant_objects: vec![],
                    visibility_m: Metres(300.0),
                    occluded_ahead: false,
                },
            );
        }

        // Simulated sensors (strictly derived from SimulatorTruth + noise/faults)
        let sensor_ts = TimestampMs(now_ms.0.saturating_sub(sensor_lag_ms));
        let odom = WheelOdometry {
            timestamp_ms: sensor_ts,
            source: DataSource::WheelOdometry,
            frame: CoordinateFrame::TrackChainage { track_id: "UP_MAIN_01".into() },
            delta_distance_m: Metres((truth.speed_mps + if odom_slip { 8.0 } else { 0.0 }) * dt_s),
            speed_mps: MetresPerSecond((truth.speed_mps + if odom_slip { 8.0 } else { rng.signed_noise(0.08) }).max(0.0)),
            wheel_slip_suspected: odom_slip,
            valid: true,
        };
        let speed_s = SpeedSensor {
            timestamp_ms: sensor_ts,
            source: DataSource::DopplerRadarSpeed,
            speed_mps: MetresPerSecond((truth.speed_mps + rng.signed_noise(0.05)).max(0.0)),
            uncertainty_mps: MetresPerSecond(0.1),
            valid: true,
        };
        let imu = ImuMeasurement {
            timestamp_ms: sensor_ts,
            source: DataSource::InertialUnit,
            frame: CoordinateFrame::VehicleBodyForward,
            longitudinal_accel_mps2: MetresPerSecondSquared(truth.accel_mps2 + rng.signed_noise(0.02)),
            pitch_rad: 0.0,
            valid: true,
        };

        let mut balise_msg = None;
        for (idx, b) in atlas.balises.iter().enumerate() {
            if (truth.position_m - b.position_m).abs() < 2.0 && last_balise_idx != Some(idx) {
                last_balise_idx = Some(idx);
                balise_msg = Some(BaliseReference {
                    timestamp_ms: now_ms,
                    source: DataSource::Eurobalise,
                    balise_id: b.balise_id.clone(),
                    track_id: b.track_id.clone(),
                    chainage_m: Metres(b.position_m),
                    uncertainty_m: Metres(0.25),
                    valid: true,
                });
                break;
            }
        }

        let in_tunnel = atlas.is_in_tunnel(truth.position_m)
            || (scenario == ScenarioId::GnssLossInTunnel && t_s >= 50.0 && t_s <= 80.0);
        let gnss = GnssFix {
            timestamp_ms: sensor_ts,
            source: DataSource::GnssReceiver,
            projected_track_id: if in_tunnel { None } else { Some("UP_MAIN_01".into()) },
            projected_chainage_m: Metres(truth.position_m + rng.signed_noise(1.8)),
            horizontal_uncertainty_m: Metres(if in_tunnel { 999.0 } else { 2.5 }),
            in_tunnel_outage: in_tunnel,
            valid: !in_tunnel,
        };

        let mut cam_dets = vec![];
        if scenario == ScenarioId::SyntheticTrackObstruction && truth.position_m >= 950.0 && truth.position_m <= 1250.0 {
            let dist = (1220.0 - truth.position_m).max(1.0);
            cam_dets.push(CameraDetectionFixture {
                kind: "CorridorObject".into(),
                track_corridor: true,
                distance_m: Metres(dist),
                confidence: 0.89,
                uncertainty_m: Metres(3.0),
                occluded_fraction: 0.1,
                apparent_aspect: None,
                label: "Synthetic equipment box on track".into(),
            });
            fault_injected_ms.get_or_insert(now_ms.0);
        }
        let cam = CameraPerceptionInput {
            timestamp_ms: sensor_ts,
            source: DataSource::ForwardCamera,
            visibility_m: Metres(280.0),
            weather: "Clear".into(),
            detections: cam_dets,
            occluded_start_m: None,
            occluded_end_m: None,
            valid: true,
        };
        let range = RangeSensorInput {
            timestamp_ms: sensor_ts,
            source: DataSource::RangeLidar,
            nearest_corridor_return_m: None,
            return_confidence: 0.0,
            uncertainty_m: Metres(1.0),
            valid: true,
        };

        let loc_state = loc.update(
            now_ms,
            dt_s,
            Some(&ma),
            Some(&odom),
            Some(&speed_s),
            Some(&imu),
            balise_msg.as_ref(),
            Some(&gnss),
        ).clone();

        max_unc_m = max_unc_m.max(loc_state.position_sigma_m.0);
        let perc = perception.process(
            now_ms,
            loc_state.speed_mps,
            MetresPerSecondSquared(1.05 * truth.adhesion),
            Some(&cam),
            Some(&range),
        );
        if let Some(obj) = perc.corridor_objects.first() {
            obstruction_det_m.get_or_insert(obj.distance_ahead_m.0);
            obstruction_feasible.get_or_insert(obj.stopping_feasible);
        }

        let est_pos = loc_state.position_m.0;
        let next_st = atlas.next_station_from(est_pos, 1.5).cloned();
        let route_lim = atlas.speed_limit_at(est_pos).unwrap_or(MetresPerSecond(0.0));
        let world = OperationalWorldModel {
            timestamp_ms: now_ms,
            authorised_track_id: SourcedField {
                value: loc_state.track_id.clone().unwrap_or_default(),
                source: DataSource::SignallingEtcs,
                updated_at_ms: now_ms,
                valid: loc_state.track_id.is_some(),
            },
            position_m: SourcedField {
                value: loc_state.position_m,
                source: DataSource::WheelOdometry,
                updated_at_ms: loc_state.last_update_ms,
                valid: true,
            },
            position_uncertainty_m: loc_state.position_sigma_m,
            speed_mps: SourcedField {
                value: loc_state.speed_mps,
                source: DataSource::DopplerRadarSpeed,
                updated_at_ms: speed_s.timestamp_ms,
                valid: true,
            },
            speed_uncertainty_mps: loc_state.speed_sigma_mps,
            applicable_speed_limit_mps: SourcedField {
                value: route_lim,
                source: DataSource::RouteAtlas,
                updated_at_ms: now_ms,
                valid: true,
            },
            movement_authority: Some(ma.clone()),
            next_station: next_st.clone(),
            gradient: SourcedField {
                value: atlas.gradient_at(est_pos),
                source: DataSource::RouteAtlas,
                updated_at_ms: now_ms,
                valid: true,
            },
            train_length_m: Metres(121.2),
            train_mass_kg: Kilograms(268000.0),
            braking_capability_mps2: SourcedField {
                value: MetresPerSecondSquared(1.05 * truth.actual_brake_effectiveness),
                source: DataSource::VehicleTcms,
                updated_at_ms: now_ms,
                valid: true,
            },
            estimated_adhesion: truth.adhesion,
            door_interlock: SourcedField {
                value: vehicle.door_interlock_state(),
                source: DataSource::VehicleTcms,
                updated_at_ms: now_ms,
                valid: true,
            },
            relevant_objects: perc.corridor_objects.clone(),
            visibility_m: perc.visibility_m,
            occluded_ahead: !perc.occluded_zones.is_empty(),
        };

        let (coast_trim, brake_trim) = if let Some(model) = residual_model {
            let dist_target = next_st.as_ref().map(|s| (s.stop_berth_m - est_pos).max(20.0)).unwrap_or(500.0);
            let (c, b, _in_dom) = model.predict_bounded(&[
                loc_state.speed_mps.0,
                world.gradient.value.0,
                dist_target,
                world.estimated_adhesion,
            ]);
            (c, b)
        } else {
            (0.0, 0.0)
        };

        let plan = planner.plan(&atlas, &world, ma_ceiling_mps, coast_trim);

        // First run supervisor on previous command state to obtain disposition
        let dummy_cmd = br_vehicle_control::ControlCommand {
            traction_effort_pct: 0.0,
            service_brake_pct: 0.0,
            emergency_brake: false,
            target_speed_mps: plan.target_speed_mps,
            tracking_error_mps: 0.0,
            residual_trim_applied: brake_trim,
        };
        let pre_sup = supervisor.evaluate(
            &world,
            &loc_state,
            &dummy_cmd,
            truth.accel_mps2.min(0.0).abs(),
            0.0,
            150,
            true,
        );

        let beh = behaviour.step(
            &world,
            &pre_sup,
            plan.feasible,
            plan.target_speed_mps,
            plan.upcoming_restriction_distance_m,
        );
        if beh.state == BehaviourState::ControlledStopping {
            entered_controlled_stop = true;
        }
        if beh.state == BehaviourState::AwaitOperatorIntervention {
            entered_await_recovery = true;
            if fault_response_ms.is_none() {
                if let Some(fi) = fault_injected_ms {
                    fault_response_ms = Some(now_ms.0.saturating_sub(fi));
                }
            }
        }
        if beh.force_controlled_stop {
            interventions += if step % 20 == 0 { 1 } else { 0 };
        }

        let cmd = controller.compute(
            dt_s,
            loc_state.speed_mps.0,
            plan.target_speed_mps,
            world.gradient.value.0,
            beh.allow_traction,
            beh.force_controlled_stop,
            pre_sup.disposition == SupervisorDisposition::EmergencyProtectionTriggered,
            brake_trim,
        );

        let loop_us = loop_start.elapsed().as_micros() as u64;
        let sup_report = supervisor.evaluate(
            &world,
            &loc_state,
            &cmd,
            truth.accel_mps2.min(0.0).abs(),
            cmd.service_brake_pct * 1.05,
            loop_us,
            true,
        );
        if sup_report.disposition != SupervisorDisposition::Nominal && fault_response_ms.is_none() {
            if let Some(fi) = fault_injected_ms {
                fault_response_ms = Some(now_ms.0.saturating_sub(fi));
            }
        }

        let door_req_str = match beh.requested_door_side {
            DoorSide::Left => Some("Left"),
            DoorSide::Right => Some("Right"),
            DoorSide::None => None,
        };
        let _env = vehicle.apply_command(now_ms, &cmd, door_req_str);

        // Advance physical simulator truth (Davis + gradient + brake effectiveness)
        let v = truth.speed_mps;
        let mass = 268000.0 * 1.06;
        let davis_n = 2950.0 + 92.0 * v + 6.8 * v * v;
        let grad_n = 268000.0 * 9.81 * (atlas.gradient_at(truth.position_m).0 / 1000.0);
        let traction_n = cmd.traction_effort_pct * 255000.0 * truth.adhesion;
        let brake_n = cmd.service_brake_pct * 268000.0 * 1.05 * truth.actual_brake_effectiveness * truth.adhesion;
        let net_f = if v <= 0.01 && traction_n <= davis_n + grad_n {
            0.0
        } else {
            traction_n - brake_n - davis_n - grad_n
        };

        let next_accel = net_f / mass;
        let jerk = (next_accel - prev_accel).abs() / dt_s;
        peak_accel = peak_accel.max(next_accel.abs());
        peak_jerk = peak_jerk.max(jerk);
        prev_accel = next_accel;

        truth.accel_mps2 = next_accel;
        truth.speed_mps = (truth.speed_mps + next_accel * dt_s).max(0.0);
        truth.position_m += truth.speed_mps * dt_s;

        if traction_n > 0.0 {
            truth.energy_consumed_kwh += (traction_n * truth.speed_mps * dt_s) / 3_600_000.0;
        }
        if brake_n > 0.0 && truth.speed_mps > 1.0 {
            truth.regen_energy_kwh += (brake_n * truth.speed_mps * dt_s * 0.72 * 0.85) / 3_600_000.0;
        }

        let actual_ceiling = atlas
            .speed_limit_at(truth.position_m)
            .map(|l| l.0)
            .unwrap_or(0.0)
            .min(ma_ceiling_mps);
        if truth.speed_mps > actual_ceiling + 1.0 || truth.position_m > eoa_m + 1.0 {
            constraint_violations += 1;
        }

        if !recorded_str_stop && (truth.position_m - 2380.0).abs() < 15.0 && truth.speed_mps < 0.05 {
            str_stop_error_m = (truth.position_m - 2380.0).abs();
            str_arrival_s = t_s;
            recorded_str_stop = true;
        }

        recorder.record(OnboardRecordFrame {
            timestamp_ms: now_ms,
            est_position_m: est_pos,
            est_position_sigma_m: loc_state.position_sigma_m.0,
            est_speed_mps: loc_state.speed_mps.0,
            target_speed_mps: plan.target_speed_mps,
            ceiling_speed_mps: actual_ceiling,
            gradient_per_mille: world.gradient.value.0,
            estimated_adhesion: world.estimated_adhesion,
            traction_effort_pct: cmd.traction_effort_pct,
            requested_brake_pct: cmd.service_brake_pct,
            achieved_brake_mps2: truth.accel_mps2.min(0.0).abs(),
            behaviour_state: beh.state,
            localisation_mode: loc_state.mode,
            supervisor_disposition: sup_report.disposition,
            loop_latency_us: loop_us,
        });
    }

    let passed = match scenario {
        ScenarioId::NominalMultiStation
        | ScenarioId::SpeedAdaptationRestriction
        | ScenarioId::EnergyEfficientCoasting
        | ScenarioId::AccuratePlatformStopping
        | ScenarioId::GnssLossInTunnel => constraint_violations == 0 && recorded_str_stop && str_stop_error_m <= 1.5,
        ScenarioId::ShortenedMovementAuthority => constraint_violations == 0 && truth.position_m <= 1650.0,
        ScenarioId::SyntheticTrackObstruction => obstruction_det_m.is_some() && entered_controlled_stop,
        ScenarioId::OdometryDisagreement
        | ScenarioId::ReducedBrakingPerformance => constraint_violations == 0,
        ScenarioId::DoorInterlockFailure
        | ScenarioId::SensorLatencyExceedance => entered_controlled_stop || entered_await_recovery,
        ScenarioId::ControllerRestartRecovery => auth_recovered && constraint_violations == 0,
    };

    ScenarioMetrics {
        scenario,
        driver_mode: if residual_model.is_some() { "R-Optimised".into() } else { "Baseline".into() },
        passed,
        constraint_violations,
        stop_position_error_m: str_stop_error_m,
        arrival_time_deviation_s: str_arrival_s - 105.0,
        energy_consumed_kwh: truth.energy_consumed_kwh,
        regen_energy_accepted_kwh: truth.regen_energy_kwh,
        peak_accel_mps2: peak_accel,
        peak_jerk_mps3: peak_jerk,
        intervention_count: interventions,
        fault_response_time_ms: fault_response_ms,
        max_localisation_uncertainty_m: max_unc_m,
        perception_false_positives: 0,
        perception_missed_detections: 0,
        obstruction_detection_distance_m: obstruction_det_m,
        obstruction_stopping_feasible: obstruction_feasible,
        notes: format!("Frames recorded: {}, ring drops: {}", recorder.frames().len(), recorder.ring_dropped()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn milestone_nominal_multi_station_and_all_acceptance_scenarios() {
        let scenarios = [
            ScenarioId::NominalMultiStation,
            ScenarioId::SpeedAdaptationRestriction,
            ScenarioId::EnergyEfficientCoasting,
            ScenarioId::AccuratePlatformStopping,
            ScenarioId::ShortenedMovementAuthority,
            ScenarioId::SyntheticTrackObstruction,
            ScenarioId::GnssLossInTunnel,
            ScenarioId::OdometryDisagreement,
            ScenarioId::ReducedBrakingPerformance,
            ScenarioId::DoorInterlockFailure,
            ScenarioId::SensorLatencyExceedance,
            ScenarioId::ControllerRestartRecovery,
        ];
        for sc in scenarios {
            let res = run_scenario(sc, 42, None);
            assert!(res.passed, "Scenario {:?} failed: {:?}", sc, res);
        }
    }
}
