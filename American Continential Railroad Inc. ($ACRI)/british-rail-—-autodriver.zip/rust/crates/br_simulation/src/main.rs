use br_simulation::{run_scenario, ScenarioId};

fn main() {
    let scenarios = [
        ScenarioId::NominalMultiStation,
        ScenarioId::SpeedAdaptationRestriction,
        ScenarioId::EnergyEfficientCoasting,
        ScenarioId::AccuratePlatformStopping,
        ScenarioId::ShortenedMovementAuthority,
        ScenarioId::SyntheticTrackObstruction,
        ScenarioId::GnssLossInTunnel,
        ScenarioId::OdometryDisagreement,
        ScenarioId::ReducedBrakingPerformance,
        ScenarioId::DoorInterlockFailure,
        ScenarioId::SensorLatencyExceedance,
        ScenarioId::ControllerRestartRecovery,
    ];

    let results: Vec<_> = scenarios.iter().map(|&s| run_scenario(s, 42, None)).collect();
    println!("{}", serde_json::to_string_pretty(&results).expect("serialize results"));
}
