use br_route_model::PerceivedCorridorObject;
use br_sensors::{
    CameraPerceptionInput, DataSource, Metres, MetresPerSecond, MetresPerSecondSquared,
    RangeSensorInput, TimestampMs,
};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OccludedZone {
    pub start_m: Metres,
    pub end_m: Metres,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerceptionOutput {
    pub timestamp_ms: TimestampMs,
    pub platform_detected_m: Option<Metres>,
    pub stopping_marker_m: Option<Metres>,
    pub corridor_objects: Vec<PerceivedCorridorObject>,
    pub visibility_m: Metres,
    pub occluded_zones: Vec<OccludedZone>,
    pub stopping_within_sight_feasible: bool,
    pub required_stopping_distance_m: Metres,
    /// Camera signal aspect candidate is logged strictly for research diagnostics; NEVER used for movement authority!
    pub ignored_camera_signal_aspect: Option<String>,
}

pub struct PerceptionPipeline {
    min_confidence: f64,
    actuator_reaction_s: f64,
}

impl PerceptionPipeline {
    pub fn new(min_confidence: f64, actuator_reaction_s: f64) -> Self {
        Self {
            min_confidence,
            actuator_reaction_s,
        }
    }

    /// Evaluates required stopping distance against available detection/visibility distance.
    pub fn required_stopping_distance_m(
        &self,
        speed_mps: MetresPerSecond,
        effective_decel_mps2: MetresPerSecondSquared,
        uncertainty_margin_m: f64,
    ) -> f64 {
        let v = speed_mps.0.max(0.0);
        let a = effective_decel_mps2.0.max(0.25);
        v * self.actuator_reaction_s + (v * v) / (2.0 * a) + uncertainty_margin_m
    }

    pub fn process(
        &self,
        now_ms: TimestampMs,
        speed_mps: MetresPerSecond,
        effective_decel_mps2: MetresPerSecondSquared,
        camera: Option<&CameraPerceptionInput>,
        range: Option<&RangeSensorInput>,
    ) -> PerceptionOutput {
        let mut platform_detected_m = None;
        let mut stopping_marker_m = None;
        let mut corridor_objects = Vec::new();
        let mut occluded_zones = Vec::new();
        let mut visibility_m = Metres(0.0);
        let mut ignored_camera_signal_aspect = None;

        if let Some(cam) = camera.filter(|c| c.valid && now_ms.0.saturating_sub(c.timestamp_ms.0) <= 500) {
            visibility_m = cam.visibility_m;
            if let (Some(s), Some(e)) = (cam.occluded_start_m, cam.occluded_end_m) {
                occluded_zones.push(OccludedZone {
                    start_m: s,
                    end_m: e,
                    reason: format!("Camera visibility ceiling / occlusion ({})", cam.weather),
                });
            }

            for det in &cam.detections {
                if det.confidence < self.min_confidence {
                    continue;
                }
                match det.kind.as_str() {
                    "PlatformEdge" => platform_detected_m = Some(det.distance_m),
                    "StoppingMarker" => stopping_marker_m = Some(det.distance_m),
                    "SignalAspectCandidate" => {
                        // CRITICAL SAFETY INVARIANT:
                        // A green-looking camera detection NEVER grants movement authority.
                        ignored_camera_signal_aspect = det.apparent_aspect.clone();
                    }
                    "CorridorObject" if det.track_corridor => {
                        let req_stop = self.required_stopping_distance_m(
                            speed_mps,
                            effective_decel_mps2,
                            det.uncertainty_m.0 + 10.0,
                        );
                        let feasible = det.distance_m.0 >= req_stop;
                        corridor_objects.push(PerceivedCorridorObject {
                            distance_ahead_m: det.distance_m,
                            confidence: det.confidence,
                            uncertainty_m: det.uncertainty_m,
                            requires_stop: true,
                            stopping_feasible: feasible,
                            timestamp_ms: cam.timestamp_ms,
                            source: DataSource::ForwardCamera,
                        });
                    }
                    _ => {}
                }
            }
        }

        if let Some(rng) = range.filter(|r| r.valid && now_ms.0.saturating_sub(r.timestamp_ms.0) <= 500) {
            if let Some(d) = rng.nearest_corridor_return_m {
                if rng.return_confidence >= self.min_confidence {
                    let req_stop = self.required_stopping_distance_m(
                        speed_mps,
                        effective_decel_mps2,
                        rng.uncertainty_m.0 + 10.0,
                    );
                    corridor_objects.push(PerceivedCorridorObject {
                        distance_ahead_m: d,
                        confidence: rng.return_confidence,
                        uncertainty_m: rng.uncertainty_m,
                        requires_stop: true,
                        stopping_feasible: d.0 >= req_stop,
                        timestamp_ms: rng.timestamp_ms,
                        source: DataSource::RangeLidar,
                    });
                }
            }
        }

        let req_stop_vis = self.required_stopping_distance_m(speed_mps, effective_decel_mps2, 12.0);
        let sight_feasible = visibility_m.0 >= req_stop_vis
            && corridor_objects.iter().all(|o| o.stopping_feasible);

        PerceptionOutput {
            timestamp_ms: now_ms,
            platform_detected_m,
            stopping_marker_m,
            corridor_objects,
            visibility_m,
            occluded_zones,
            stopping_within_sight_feasible: sight_feasible,
            required_stopping_distance_m: Metres(req_stop_vis),
            ignored_camera_signal_aspect,
        }
    }
}
