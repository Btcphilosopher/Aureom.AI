use br_route_model::{DoorSide, OperationalWorldModel};
use br_sensors::{DoorInterlockState, TimestampMs};
use br_supervisor::{SupervisorDisposition, SupervisorReport};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BehaviourState {
    AwaitDispatchPermission,
    DepartStation,
    Accelerate,
    Cruise,
    Coast,
    ApproachRestriction,
    ConstrainedEnvelope,
    ApproachPlatform,
    StopAndSecure,
    Dwell,
    PrepareDeparture,
    ControlledStopping,
    AwaitOperatorIntervention,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BehaviourOutput {
    pub state: BehaviourState,
    pub requested_door_side: DoorSide,
    pub allow_traction: bool,
    pub force_controlled_stop: bool,
    pub target_stop_m: Option<f64>,
    pub rationale: String,
}

#[derive(Debug, Clone)]
pub struct BehaviourConfig {
    pub unattended_door_operation_enabled: bool,
    pub max_stale_ms: u64,
    pub platform_approach_window_m: f64,
    pub berth_stop_tolerance_m: f64,
}

impl Default for BehaviourConfig {
    fn default() -> Self {
        Self {
            unattended_door_operation_enabled: false,
            max_stale_ms: 600,
            platform_approach_window_m: 450.0,
            berth_stop_tolerance_m: 1.5,
        }
    }
}

pub struct BehaviourPlanner {
    cfg: BehaviourConfig,
    state: BehaviourState,
    dwell_started_ms: Option<TimestampMs>,
    served_station_ids: Vec<String>,
}

impl BehaviourPlanner {
    pub fn new(cfg: BehaviourConfig) -> Self {
        Self {
            cfg,
            state: BehaviourState::AwaitDispatchPermission,
            dwell_started_ms: None,
            served_station_ids: vec!["BR-STP".to_string()],
        }
    }

    pub fn state(&self) -> BehaviourState {
        self.state
    }

    pub fn step(
        &mut self,
        world: &OperationalWorldModel,
        supervisor: &SupervisorReport,
        trajectory_feasible: bool,
        target_speed_mps: f64,
        upcoming_restriction_within_m: Option<f64>,
    ) -> BehaviourOutput {
        let speed = world.speed_mps.value.0;
        let pos = world.position_m.value.0;

        // 1. Train protection / supervisor overrides everything
        if matches!(
            supervisor.disposition,
            SupervisorDisposition::AwaitingExplicitRecovery
        ) || (supervisor.recovery_required && speed <= 0.05)
        {
            self.state = BehaviourState::AwaitOperatorIntervention;
            return BehaviourOutput {
                state: self.state,
                requested_door_side: DoorSide::None,
                allow_traction: false,
                force_controlled_stop: true,
                target_stop_m: None,
                rationale: "Supervisor requires explicit operator recovery authorisation".into(),
            };
        }

        if matches!(
            supervisor.disposition,
            SupervisorDisposition::ControlledStopRequired
                | SupervisorDisposition::EmergencyProtectionTriggered
        ) || !trajectory_feasible
            || world.relevant_objects.iter().any(|o| o.requires_stop)
        {
            self.state = BehaviourState::ControlledStopping;
            return BehaviourOutput {
                state: self.state,
                requested_door_side: DoorSide::None,
                allow_traction: false,
                force_controlled_stop: true,
                target_stop_m: None,
                rationale: if !trajectory_feasible {
                    "Trajectory infeasible — fallback controlled stop".into()
                } else {
                    "Supervisor or corridor obstruction requires controlled stop".into()
                },
            };
        }

        let ma = match world.valid_movement_authority(self.cfg.max_stale_ms) {
            Some(m) => m,
            None => {
                self.state = BehaviourState::ControlledStopping;
                return BehaviourOutput {
                    state: self.state,
                    requested_door_side: DoorSide::None,
                    allow_traction: false,
                    force_controlled_stop: true,
                    target_stop_m: None,
                    rationale: "No valid movement authority".into(),
                };
            }
        };

        let next_station = world
            .next_station
            .as_ref()
            .filter(|s| !self.served_station_ids.contains(&s.station_id));

        let mut door_request = DoorSide::None;

        match self.state {
            BehaviourState::AwaitDispatchPermission => {
                if ma.dispatch_permitted
                    && world.door_interlock.value == DoorInterlockState::LockedAndProven
                    && ma.end_of_authority_m.0 > pos + 5.0
                {
                    self.state = BehaviourState::DepartStation;
                }
            }
            BehaviourState::DepartStation => {
                if speed > 3.0 {
                    self.state = BehaviourState::Accelerate;
                }
            }
            BehaviourState::Accelerate | BehaviourState::Cruise | BehaviourState::Coast | BehaviourState::ApproachRestriction | BehaviourState::ConstrainedEnvelope => {
                if let Some(st) = next_station {
                    let dist_to_berth = st.stop_berth_m - pos;
                    if dist_to_berth <= self.cfg.platform_approach_window_m && st.available {
                        self.state = BehaviourState::ApproachPlatform;
                    }
                }
                if self.state != BehaviourState::ApproachPlatform {
                    if supervisor.disposition == SupervisorDisposition::DegradedCautious {
                        self.state = BehaviourState::ConstrainedEnvelope;
                    } else if upcoming_restriction_within_m.is_some() {
                        self.state = BehaviourState::ApproachRestriction;
                    } else if target_speed_mps < speed - 0.5 && speed > 12.0 {
                        self.state = BehaviourState::Coast;
                    } else if (target_speed_mps - speed).abs() <= 0.8 && speed > 5.0 {
                        self.state = BehaviourState::Cruise;
                    } else {
                        self.state = BehaviourState::Accelerate;
                    }
                }
            }
            BehaviourState::ApproachPlatform => {
                if let Some(st) = next_station {
                    let err = (st.stop_berth_m - pos).abs();
                    if speed <= 0.08 && err <= st.berth_tolerance_m + world.position_uncertainty_m.0 {
                        self.state = BehaviourState::StopAndSecure;
                    } else if speed <= 0.08 && pos > st.stop_berth_m + st.berth_tolerance_m {
                        // Overshoot beyond berth tolerance: require intervention rather than blind door release
                        self.state = BehaviourState::AwaitOperatorIntervention;
                    }
                }
            }
            BehaviourState::StopAndSecure => {
                if let Some(st) = next_station {
                    let within_platform = pos >= st.platform_start_m
                        && pos <= st.platform_end_m
                        && st.available
                        && world.position_uncertainty_m.0 <= 3.0;
                    if speed <= 0.05 && within_platform {
                        if self.cfg.unattended_door_operation_enabled || ma.dispatch_permitted {
                            door_request = st.door_side;
                        }
                        self.dwell_started_ms = Some(world.timestamp_ms);
                        self.state = BehaviourState::Dwell;
                    }
                }
            }
            BehaviourState::Dwell => {
                if let Some(st) = next_station {
                    door_request = st.door_side;
                    let elapsed_s = self
                        .dwell_started_ms
                        .map(|t| world.timestamp_ms.0.saturating_sub(t.0) as f64 / 1000.0)
                        .unwrap_or(0.0);
                    if elapsed_s >= st.min_dwell_s {
                        door_request = DoorSide::None;
                        self.state = BehaviourState::PrepareDeparture;
                    }
                }
            }
            BehaviourState::PrepareDeparture => {
                if world.door_interlock.value == DoorInterlockState::LockedAndProven
                    && ma.dispatch_permitted
                    && ma.end_of_authority_m.0 > pos + 15.0
                {
                    if let Some(st) = next_station {
                        self.served_station_ids.push(st.station_id.clone());
                    }
                    self.dwell_started_ms = None;
                    self.state = BehaviourState::DepartStation;
                }
            }
            BehaviourState::ControlledStopping => {
                if speed <= 0.05 {
                    self.state = BehaviourState::AwaitOperatorIntervention;
                }
            }
            BehaviourState::AwaitOperatorIntervention => {}
        }

        let target_stop_m = next_station
            .filter(|s| s.available)
            .map(|s| s.stop_berth_m.min(ma.end_of_authority_m.0))
            .or(Some(ma.end_of_authority_m.0));

        let allow_traction = matches!(
            self.state,
            BehaviourState::DepartStation
                | BehaviourState::Accelerate
                | BehaviourState::Cruise
                | BehaviourState::ApproachRestriction
                | BehaviourState::ApproachPlatform
                | BehaviourState::ConstrainedEnvelope
        ) && world.door_interlock.value == DoorInterlockState::LockedAndProven;

        BehaviourOutput {
            state: self.state,
            requested_door_side: door_request,
            allow_traction,
            force_controlled_stop: false,
            target_stop_m,
            rationale: format!("FSM state {:?}", self.state),
        }
    }
}
