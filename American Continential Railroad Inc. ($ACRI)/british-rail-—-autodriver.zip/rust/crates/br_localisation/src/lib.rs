use br_route_model::MovementAuthority;
use br_sensors::{
    BaliseReference, GnssFix, ImuMeasurement, Metres, MetresPerSecond, SpeedSensor, TimestampMs,
    WheelOdometry,
};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LocalisationMode {
    NominalFused,
    TunnelDeadReckoning,
    DegradedUncertaintyExceeded,
    SensorDisagreement,
    InvalidStale,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LocalisationConfig {
    pub max_position_uncertainty_m: f64,
    pub max_sensor_age_ms: u64,
    pub max_odometry_speed_disagreement_mps: f64,
    pub process_drift_m_per_m: f64,
}

impl Default for LocalisationConfig {
    fn default() -> Self {
        Self {
            max_position_uncertainty_m: 12.0,
            max_sensor_age_ms: 600,
            max_odometry_speed_disagreement_mps: 2.5,
            process_drift_m_per_m: 0.004,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LocalisationState {
    pub track_id: Option<String>,
    pub position_m: Metres,
    pub speed_mps: MetresPerSecond,
    pub position_sigma_m: Metres,
    pub speed_sigma_mps: MetresPerSecond,
    pub mode: LocalisationMode,
    pub last_update_ms: TimestampMs,
    pub last_balise_ms: TimestampMs,
    pub odometry_disagreement_count: u32,
    pub gnss_available: bool,
}

pub struct LocalisationFilter {
    cfg: LocalisationConfig,
    state: LocalisationState,
}

impl LocalisationFilter {
    pub fn new(initial_track: &str, initial_pos_m: f64, cfg: LocalisationConfig) -> Self {
        Self {
            cfg,
            state: LocalisationState {
                track_id: Some(initial_track.to_string()),
                position_m: Metres(initial_pos_m),
                speed_mps: MetresPerSecond(0.0),
                position_sigma_m: Metres(0.5),
                speed_sigma_mps: MetresPerSecond(0.1),
                mode: LocalisationMode::NominalFused,
                last_update_ms: TimestampMs(0),
                last_balise_ms: TimestampMs(0),
                odometry_disagreement_count: 0,
                gnss_available: true,
            },
        }
    }

    pub fn state(&self) -> &LocalisationState {
        &self.state
    }

    /// Resolves track identity strictly from authorised movement authority + balise references.
    /// Never snaps to nearest geographic track without route authorisation.
    pub fn update(
        &mut self,
        now_ms: TimestampMs,
        dt_s: f64,
        ma: Option<&MovementAuthority>,
        odom: Option<&WheelOdometry>,
        speed_sensor: Option<&SpeedSensor>,
        imu: Option<&ImuMeasurement>,
        balise: Option<&BaliseReference>,
        gnss: Option<&GnssFix>,
    ) -> &LocalisationState {
        // Track identity resolution must be grounded in authorised MA
        let authorised_track = ma.map(|m| m.track_id.as_str());
        if let Some(auth_tid) = authorised_track {
            self.state.track_id = Some(auth_tid.to_string());
        } else {
            self.state.mode = LocalisationMode::InvalidStale;
            return &self.state;
        }

        let odom_fresh = odom
            .filter(|o| o.valid && now_ms.0.saturating_sub(o.timestamp_ms.0) <= self.cfg.max_sensor_age_ms);
        let speed_fresh = speed_sensor
            .filter(|s| s.valid && now_ms.0.saturating_sub(s.timestamp_ms.0) <= self.cfg.max_sensor_age_ms);
        let imu_fresh = imu
            .filter(|i| i.valid && now_ms.0.saturating_sub(i.timestamp_ms.0) <= self.cfg.max_sensor_age_ms);

        if odom_fresh.is_none() && speed_fresh.is_none() {
            self.state.position_sigma_m.0 += (self.state.speed_mps.0.abs() * dt_s * 0.25).max(0.2 * dt_s);
            self.state.mode = LocalisationMode::InvalidStale;
            return &self.state;
        }

        // Check disagreement between wheel odometry and Doppler/radar speed sensor (e.g. wheel slip/slide)
        let mut disagreement = false;
        if let (Some(o), Some(s)) = (odom_fresh, speed_fresh) {
            if (o.speed_mps.0 - s.speed_mps.0).abs() > self.cfg.max_odometry_speed_disagreement_mps
                || o.wheel_slip_suspected
            {
                disagreement = true;
                self.state.odometry_disagreement_count =
                    self.state.odometry_disagreement_count.saturating_add(1);
            } else {
                self.state.odometry_disagreement_count = 0;
            }
        }

        // Speed fusion: prefer radar/speed sensor when wheel slip is suspected
        let v_pred = match (odom_fresh, speed_fresh, imu_fresh) {
            (Some(o), Some(s), _) if disagreement => {
                // Weight Doppler radar higher during wheel slip
                0.2 * o.speed_mps.0 + 0.8 * s.speed_mps.0
            }
            (Some(o), Some(s), _) => 0.45 * o.speed_mps.0 + 0.55 * s.speed_mps.0,
            (None, Some(s), _) => s.speed_mps.0,
            (Some(o), None, _) => o.speed_mps.0,
            _ => self.state.speed_mps.0,
        };

        let accel_term = imu_fresh
            .map(|i| 0.5 * i.longitudinal_accel_mps2.0 * dt_s * dt_s)
            .unwrap_or(0.0);
        let ds_pred = if disagreement {
            v_pred * dt_s + accel_term
        } else if let Some(o) = odom_fresh {
            0.6 * o.delta_distance_m.0 + 0.4 * (v_pred * dt_s + accel_term)
        } else {
            v_pred * dt_s + accel_term
        };

        self.state.position_m.0 += ds_pred.max(0.0);
        self.state.speed_mps.0 = v_pred.max(0.0);
        self.state.position_sigma_m.0 += ds_pred.abs() * self.cfg.process_drift_m_per_m
            + if disagreement { 0.35 * dt_s } else { 0.02 * dt_s };

        // Absolute Eurobalise update (only if track_id matches authorised track!)
        if let Some(b) = balise.filter(|b| b.valid && now_ms.0.saturating_sub(b.timestamp_ms.0) <= self.cfg.max_sensor_age_ms) {
            if Some(b.track_id.as_str()) == authorised_track {
                let innovation = b.chainage_m.0 - self.state.position_m.0;
                // Kalman-like scalar update
                let r_var = b.uncertainty_m.0.powi(2).max(0.04);
                let p_var = self.state.position_sigma_m.0.powi(2);
                let k = p_var / (p_var + r_var);
                self.state.position_m.0 += k * innovation;
                self.state.position_sigma_m.0 = ((1.0 - k) * p_var).sqrt().max(0.25);
                self.state.last_balise_ms = b.timestamp_ms;
            }
        }

        // GNSS update only if outside tunnel, fresh, and track projection matches authorised track
        let mut tunnel_outage = false;
        if let Some(g) = gnss {
            if g.in_tunnel_outage || !g.valid {
                tunnel_outage = true;
                self.state.gnss_available = false;
            } else if now_ms.0.saturating_sub(g.timestamp_ms.0) <= self.cfg.max_sensor_age_ms {
                self.state.gnss_available = true;
                if g.projected_track_id.as_deref() == authorised_track {
                    let r_var = g.horizontal_uncertainty_m.0.powi(2).max(4.0);
                    let p_var = self.state.position_sigma_m.0.powi(2);
                    let k = p_var / (p_var + r_var);
                    self.state.position_m.0 += k * (g.projected_chainage_m.0 - self.state.position_m.0);
                    self.state.position_sigma_m.0 = ((1.0 - k) * p_var).sqrt().max(0.35);
                }
            }
        }

        self.state.last_update_ms = now_ms;
        self.state.mode = if self.state.odometry_disagreement_count >= 3 {
            LocalisationMode::SensorDisagreement
        } else if self.state.position_sigma_m.0 > self.cfg.max_position_uncertainty_m {
            LocalisationMode::DegradedUncertaintyExceeded
        } else if tunnel_outage {
            LocalisationMode::TunnelDeadReckoning
        } else {
            LocalisationMode::NominalFused
        };

        &self.state
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use br_sensors::{CoordinateFrame, DataSource, MetresPerSecondSquared};

    fn test_ma() -> MovementAuthority {
        MovementAuthority {
            track_id: "UP_MAIN_01".to_string(),
            end_of_authority_m: Metres(5000.0),
            ceiling_speed_mps: MetresPerSecond(35.0),
            dispatch_permitted: true,
            issued_at_ms: TimestampMs(0),
            expires_at_ms: TimestampMs(10_000),
            source: DataSource::SignallingEtcs,
        }
    }

    #[test]
    fn tunnel_gnss_loss_stays_bounded_with_odometry_and_balise() {
        let mut loc = LocalisationFilter::new("UP_MAIN_01", 3000.0, LocalisationConfig::default());
        let ma = test_ma();
        let odom = WheelOdometry {
            timestamp_ms: TimestampMs(100),
            source: DataSource::WheelOdometry,
            frame: CoordinateFrame::TrackChainage { track_id: "UP_MAIN_01".into() },
            delta_distance_m: Metres(2.5),
            speed_mps: MetresPerSecond(25.0),
            wheel_slip_suspected: false,
            valid: true,
        };
        let speed = SpeedSensor {
            timestamp_ms: TimestampMs(100),
            source: DataSource::DopplerRadarSpeed,
            speed_mps: MetresPerSecond(25.0),
            uncertainty_mps: MetresPerSecond(0.1),
            valid: true,
        };
        let gnss = GnssFix {
            timestamp_ms: TimestampMs(100),
            source: DataSource::GnssReceiver,
            projected_track_id: None,
            projected_chainage_m: Metres(0.0),
            horizontal_uncertainty_m: Metres(999.0),
            in_tunnel_outage: true,
            valid: false,
        };
        let imu = ImuMeasurement {
            timestamp_ms: TimestampMs(100),
            source: DataSource::InertialUnit,
            frame: CoordinateFrame::VehicleBodyForward,
            longitudinal_accel_mps2: MetresPerSecondSquared(0.0),
            pitch_rad: 0.0,
            valid: true,
        };
        let st = loc.update(TimestampMs(100), 0.1, Some(&ma), Some(&odom), Some(&speed), Some(&imu), None, Some(&gnss));
        assert_eq!(st.mode, LocalisationMode::TunnelDeadReckoning);
        assert!(st.position_sigma_m.0 < 2.0);
    }

    #[test]
    fn detects_odometry_disagreement_after_repeated_slip() {
        let mut loc = LocalisationFilter::new("UP_MAIN_01", 1000.0, LocalisationConfig::default());
        let ma = test_ma();
        for i in 1..=4 {
            let t = TimestampMs(i * 100);
            let odom = WheelOdometry {
                timestamp_ms: t,
                source: DataSource::WheelOdometry,
                frame: CoordinateFrame::TrackChainage { track_id: "UP_MAIN_01".into() },
                delta_distance_m: Metres(3.8),
                speed_mps: MetresPerSecond(38.0),
                wheel_slip_suspected: true,
                valid: true,
            };
            let speed = SpeedSensor {
                timestamp_ms: t,
                source: DataSource::DopplerRadarSpeed,
                speed_mps: MetresPerSecond(22.0),
                uncertainty_mps: MetresPerSecond(0.2),
                valid: true,
            };
            loc.update(t, 0.1, Some(&ma), Some(&odom), Some(&speed), None, None, None);
        }
        assert_eq!(loc.state().mode, LocalisationMode::SensorDisagreement);
    }
}
