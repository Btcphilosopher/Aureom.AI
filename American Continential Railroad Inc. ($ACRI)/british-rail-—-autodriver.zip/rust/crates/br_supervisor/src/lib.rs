use br_localisation::{LocalisationMode, LocalisationState};
use br_route_model::OperationalWorldModel;
use br_sensors::{DoorInterlockState, TimestampMs};
use br_vehicle_control::ControlCommand;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SupervisorDisposition {
    Nominal,
    DegradedCautious,
    ControlledStopRequired,
    EmergencyProtectionTriggered,
    AwaitingExplicitRecovery,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum FaultCode {
    PositionUncertaintyExceeded,
    SensorFreshnessExpired,
    InvalidOrExpiredAuthority,
    SpeedEnvelopeViolation,
    TrackingErrorExceeded,
    BrakingResponseDegraded,
    DoorInterlockFaultWhileMovingOrDeparting,
    CommunicationTimeout,
    ExecutionDeadlineMissed,
    CommandValidityFailed,
    ControllerRestartedRequiresAuth,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecoveryAuthorisation {
    pub operator_id: String,
    pub authorised_at_ms: TimestampMs,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SupervisorReport {
    pub disposition: SupervisorDisposition,
    pub active_faults: Vec<FaultCode>,
    pub recovery_required: bool,
    pub max_permitted_speed_mps: f64,
    pub fault_detected_at_ms: Option<TimestampMs>,
}

#[derive(Debug, Clone)]
pub struct SupervisorConfig {
    pub max_uncertainty_m: f64,
    pub max_stale_ms: u64,
    pub max_tracking_error_mps: f64,
    pub max_deadline_us: u64,
    pub min_braking_ratio: f64,
}

impl Default for SupervisorConfig {
    fn default() -> Self {
        Self {
            max_uncertainty_m: 12.0,
            max_stale_ms: 600,
            max_tracking_error_mps: 3.5,
            max_deadline_us: 25_000,
            min_braking_ratio: 0.65,
        }
    }
}

pub struct RuntimeSupervisor {
    cfg: SupervisorConfig,
    latched_recovery_required: bool,
    first_fault_ms: Option<TimestampMs>,
}

impl RuntimeSupervisor {
    pub fn new(cfg: SupervisorConfig, require_initial_auth_after_restart: bool) -> Self {
        Self {
            cfg,
            latched_recovery_required: require_initial_auth_after_restart,
            first_fault_ms: if require_initial_auth_after_restart {
                Some(TimestampMs(0))
            } else {
                None
            },
        }
    }

    pub fn notify_controller_restart(&mut self, now_ms: TimestampMs) {
        self.latched_recovery_required = true;
        self.first_fault_ms.get_or_insert(now_ms);
    }

    /// Explicit recovery authorisation required: restart, reconnection or fault clearance NEVER auto-resumes movement.
    pub fn authorise_recovery(
        &mut self,
        auth: &RecoveryAuthorisation,
        world: &OperationalWorldModel,
    ) -> bool {
        if world.speed_mps.value.0.abs() > 0.05 {
            return false;
        }
        if !world.inputs_fresh(self.cfg.max_stale_ms) {
            return false;
        }
        if auth.operator_id.trim().is_empty() {
            return false;
        }
        self.latched_recovery_required = false;
        self.first_fault_ms = None;
        true
    }

    pub fn evaluate(
        &mut self,
        world: &OperationalWorldModel,
        loc: &LocalisationState,
        cmd: &ControlCommand,
        achieved_brake_mps2: f64,
        requested_brake_mps2: f64,
        loop_duration_us: u64,
        comm_healthy: bool,
    ) -> SupervisorReport {
        let mut faults = Vec::new();

        if self.latched_recovery_required {
            faults.push(FaultCode::ControllerRestartedRequiresAuth);
        }

        if world.position_uncertainty_m.0 > self.cfg.max_uncertainty_m
            || loc.mode == LocalisationMode::DegradedUncertaintyExceeded
        {
            faults.push(FaultCode::PositionUncertaintyExceeded);
        }

        if !world.inputs_fresh(self.cfg.max_stale_ms) || loc.mode == LocalisationMode::InvalidStale {
            faults.push(FaultCode::SensorFreshnessExpired);
        }

        if world.valid_movement_authority(self.cfg.max_stale_ms).is_none() {
            faults.push(FaultCode::InvalidOrExpiredAuthority);
        }

        let ceiling = world
            .valid_movement_authority(self.cfg.max_stale_ms)
            .map(|ma| ma.ceiling_speed_mps.0.min(world.applicable_speed_limit_mps.value.0))
            .unwrap_or(0.0);

        if world.speed_mps.value.0 > ceiling + 1.2 {
            faults.push(FaultCode::SpeedEnvelopeViolation);
        }

        if (cmd.target_speed_mps - world.speed_mps.value.0).abs() > self.cfg.max_tracking_error_mps
            && world.speed_mps.value.0 > 2.0
        {
            faults.push(FaultCode::TrackingErrorExceeded);
        }

        if requested_brake_mps2 > 0.45 && achieved_brake_mps2 < requested_brake_mps2 * self.cfg.min_braking_ratio {
            faults.push(FaultCode::BrakingResponseDegraded);
        }

        if world.door_interlock.value != DoorInterlockState::LockedAndProven
            && (world.speed_mps.value.0 > 0.1 || cmd.traction_effort_pct > 0.01)
        {
            faults.push(FaultCode::DoorInterlockFaultWhileMovingOrDeparting);
        }

        if !comm_healthy {
            faults.push(FaultCode::CommunicationTimeout);
        }

        if loop_duration_us > self.cfg.max_deadline_us {
            faults.push(FaultCode::ExecutionDeadlineMissed);
        }

        if !cmd.traction_effort_pct.is_finite()
            || !cmd.service_brake_pct.is_finite()
            || (cmd.traction_effort_pct > 0.0 && cmd.service_brake_pct > 0.0)
        {
            faults.push(FaultCode::CommandValidityFailed);
        }

        let critical = faults.iter().any(|f| {
            matches!(
                f,
                FaultCode::SpeedEnvelopeViolation
                    | FaultCode::DoorInterlockFaultWhileMovingOrDeparting
                    | FaultCode::InvalidOrExpiredAuthority
                    | FaultCode::SensorFreshnessExpired
                    | FaultCode::CommandValidityFailed
                    | FaultCode::PositionUncertaintyExceeded
                    | FaultCode::CommunicationTimeout
            )
        });

        if critical || !faults.is_empty() {
            self.first_fault_ms.get_or_insert(world.timestamp_ms);
        }

        if critical {
            self.latched_recovery_required = true;
        }

        let disposition = if self.latched_recovery_required && world.speed_mps.value.0 <= 0.05 {
            SupervisorDisposition::AwaitingExplicitRecovery
        } else if faults.contains(&FaultCode::SpeedEnvelopeViolation)
            || faults.contains(&FaultCode::CommandValidityFailed)
        {
            SupervisorDisposition::EmergencyProtectionTriggered
        } else if critical {
            SupervisorDisposition::ControlledStopRequired
        } else if !faults.is_empty() {
            SupervisorDisposition::DegradedCautious
        } else {
            SupervisorDisposition::Nominal
        };

        let max_permitted_speed_mps = match disposition {
            SupervisorDisposition::Nominal => ceiling,
            SupervisorDisposition::DegradedCautious => ceiling.min(14.0),
            _ => 0.0,
        };

        SupervisorReport {
            disposition,
            active_faults: faults,
            recovery_required: self.latched_recovery_required,
            max_permitted_speed_mps,
            fault_detected_at_ms: self.first_fault_ms,
        }
    }
}
