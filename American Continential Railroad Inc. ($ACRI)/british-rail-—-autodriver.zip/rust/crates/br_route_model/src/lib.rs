use br_sensors::{
    DataSource, DoorInterlockState, GradientPerMille, Kilograms, Metres, MetresPerSecond,
    MetresPerSecondSquared, TimestampMs,
};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpeedSegment {
    pub start_m: f64,
    pub end_m: f64,
    pub limit_mps: f64,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GradientSegment {
    pub start_m: f64,
    pub end_m: f64,
    pub per_mille: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TunnelZone {
    pub id: String,
    pub name: String,
    pub start_m: f64,
    pub end_m: f64,
    pub gnss_available: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DoorSide {
    Left,
    Right,
    None,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StationStop {
    pub station_id: String,
    pub name: String,
    pub platform: String,
    pub stop_berth_m: f64,
    pub platform_start_m: f64,
    pub platform_end_m: f64,
    pub door_side: DoorSide,
    pub scheduled_arrival_s: f64,
    pub scheduled_departure_s: f64,
    pub min_dwell_s: f64,
    pub available: bool,
    pub berth_tolerance_m: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BaliseEntry {
    pub balise_id: String,
    pub position_m: f64,
    pub track_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteAtlas {
    pub route_id: String,
    pub route_name: String,
    pub total_length_m: f64,
    pub track_id: String,
    pub speed_segments: Vec<SpeedSegment>,
    pub gradients: Vec<GradientSegment>,
    pub tunnels: Vec<TunnelZone>,
    pub stations: Vec<StationStop>,
    pub balises: Vec<BaliseEntry>,
}

impl RouteAtlas {
    pub fn speed_limit_at(&self, chainage_m: f64) -> Option<MetresPerSecond> {
        self.speed_segments
            .iter()
            .find(|s| chainage_m >= s.start_m && chainage_m < s.end_m)
            .map(|s| MetresPerSecond(s.limit_mps))
    }

    pub fn gradient_at(&self, chainage_m: f64) -> GradientPerMille {
        self.gradients
            .iter()
            .find(|g| chainage_m >= g.start_m && chainage_m < g.end_m)
            .map(|g| GradientPerMille(g.per_mille))
            .unwrap_or(GradientPerMille(0.0))
    }

    pub fn is_in_tunnel(&self, chainage_m: f64) -> bool {
        self.tunnels
            .iter()
            .any(|t| chainage_m >= t.start_m && chainage_m <= t.end_m)
    }

    pub fn next_station_from(&self, chainage_m: f64, tolerance_m: f64) -> Option<&StationStop> {
        self.stations
            .iter()
            .find(|st| st.stop_berth_m >= chainage_m - tolerance_m)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MovementAuthority {
    pub track_id: String,
    pub end_of_authority_m: Metres,
    pub ceiling_speed_mps: MetresPerSecond,
    pub dispatch_permitted: bool,
    pub issued_at_ms: TimestampMs,
    pub expires_at_ms: TimestampMs,
    pub source: DataSource,
}

impl MovementAuthority {
    pub fn is_fresh(&self, now_ms: TimestampMs) -> bool {
        now_ms.0 >= self.issued_at_ms.0 && now_ms.0 <= self.expires_at_ms.0
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SourcedField<T> {
    pub value: T,
    pub source: DataSource,
    pub updated_at_ms: TimestampMs,
    pub valid: bool,
}

impl<T> SourcedField<T> {
    pub fn freshness_age_ms(&self, now_ms: TimestampMs) -> u64 {
        now_ms.0.saturating_sub(self.updated_at_ms.0)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerceivedCorridorObject {
    pub distance_ahead_m: Metres,
    pub confidence: f64,
    pub uncertainty_m: Metres,
    pub requires_stop: bool,
    pub stopping_feasible: bool,
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
}

/// Continuously updated operational world model with provenance and freshness on every critical field.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperationalWorldModel {
    pub timestamp_ms: TimestampMs,
    pub authorised_track_id: SourcedField<String>,
    pub position_m: SourcedField<Metres>,
    pub position_uncertainty_m: Metres,
    pub speed_mps: SourcedField<MetresPerSecond>,
    pub speed_uncertainty_mps: MetresPerSecond,
    pub applicable_speed_limit_mps: SourcedField<MetresPerSecond>,
    pub movement_authority: Option<MovementAuthority>,
    pub next_station: Option<StationStop>,
    pub gradient: SourcedField<GradientPerMille>,
    pub train_length_m: Metres,
    pub train_mass_kg: Kilograms,
    pub braking_capability_mps2: SourcedField<MetresPerSecondSquared>,
    pub estimated_adhesion: f64,
    pub door_interlock: SourcedField<DoorInterlockState>,
    pub relevant_objects: Vec<PerceivedCorridorObject>,
    pub visibility_m: Metres,
    pub occluded_ahead: bool,
}

impl OperationalWorldModel {
    /// Rejects missing, expired, or invalid authority. Never treats missing data as clear track.
    pub fn valid_movement_authority(&self, max_stale_ms: u64) -> Option<&MovementAuthority> {
        let ma = self.movement_authority.as_ref()?;
        if !ma.is_fresh(self.timestamp_ms) {
            return None;
        }
        if self.timestamp_ms.0.saturating_sub(ma.issued_at_ms.0) > max_stale_ms {
            return None;
        }
        if ma.track_id != self.authorised_track_id.value || !self.authorised_track_id.valid {
            return None;
        }
        Some(ma)
    }

    pub fn inputs_fresh(&self, max_stale_ms: u64) -> bool {
        self.authorised_track_id.valid
            && self.position_m.valid
            && self.speed_mps.valid
            && self.applicable_speed_limit_mps.valid
            && self.braking_capability_mps2.valid
            && self.door_interlock.valid
            && self.position_m.freshness_age_ms(self.timestamp_ms) <= max_stale_ms
            && self.speed_mps.freshness_age_ms(self.timestamp_ms) <= max_stale_ms
            && self.door_interlock.freshness_age_ms(self.timestamp_ms) <= max_stale_ms
            && self.valid_movement_authority(max_stale_ms).is_some()
    }
}
