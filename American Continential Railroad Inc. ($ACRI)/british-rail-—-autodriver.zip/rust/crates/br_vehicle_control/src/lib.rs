use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ControlCommand {
    pub traction_effort_pct: f64,
    pub service_brake_pct: f64,
    pub emergency_brake: bool,
    pub target_speed_mps: f64,
    pub tracking_error_mps: f64,
    pub residual_trim_applied: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResidualModelFeature {
    pub name: String,
    pub mean: f64,
    pub sd: f64,
    pub min: f64,
    pub max: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResidualModelArtifact {
    pub model_id: String,
    pub version: String,
    pub features: Vec<ResidualModelFeature>,
    pub intercept: f64,
    pub coast_bias_coeffs: Vec<f64>,
    pub brake_trim_coeffs: Vec<f64>,
    pub max_coast_speed_trim_mps: f64,
    pub max_brake_effort_trim: f64,
}

impl ResidualModelArtifact {
    /// Evaluates R-exported residual model with strict domain checking.
    /// Returns (coast_trim_mps, brake_effort_trim) or (0.0, 0.0) if out-of-domain.
    pub fn predict_bounded(&self, raw_features: &[f64; 4]) -> (f64, f64, bool) {
        if self.features.len() != 4
            || self.coast_bias_coeffs.len() != 4
            || self.brake_trim_coeffs.len() != 4
        {
            return (0.0, 0.0, false);
        }
        let mut z = [0.0_f64; 4];
        for (i, feat) in self.features.iter().enumerate() {
            let x = raw_features[i];
            if !x.is_finite() || x < feat.min || x > feat.max {
                return (0.0, 0.0, false);
            }
            z[i] = (x - feat.mean) / feat.sd.max(1e-6);
        }

        let mut coast = self.intercept;
        let mut brake = 0.0;
        for i in 0..4 {
            coast += self.coast_bias_coeffs[i] * z[i];
            brake += self.brake_trim_coeffs[i] * z[i];
        }
        (
            coast.clamp(0.0, self.max_coast_speed_trim_mps),
            brake.clamp(-self.max_brake_effort_trim, self.max_brake_effort_trim),
            true,
        )
    }
}

pub struct DrivingController {
    kp: f64,
    ki: f64,
    integral: f64,
    last_net_cmd: f64,
    max_cmd_rate_per_s: f64,
}

impl Default for DrivingController {
    fn default() -> Self {
        Self {
            kp: 0.45,
            ki: 0.08,
            integral: 0.0,
            last_net_cmd: 0.0,
            max_cmd_rate_per_s: 1.15,
        }
    }
}

impl DrivingController {
    pub fn reset(&mut self) {
        self.integral = 0.0;
        self.last_net_cmd = 0.0;
    }

    pub fn compute(
        &mut self,
        dt_s: f64,
        actual_speed_mps: f64,
        target_speed_mps: f64,
        gradient_per_mille: f64,
        allow_traction: bool,
        force_stop: bool,
        emergency: bool,
        brake_trim: f64,
    ) -> ControlCommand {
        if emergency {
            self.integral = 0.0;
            self.last_net_cmd = -1.0;
            return ControlCommand {
                traction_effort_pct: 0.0,
                service_brake_pct: 1.0,
                emergency_brake: true,
                target_speed_mps: 0.0,
                tracking_error_mps: -actual_speed_mps,
                residual_trim_applied: 0.0,
            };
        }

        if force_stop {
            let desired = -0.85;
            let max_step = self.max_cmd_rate_per_s * dt_s;
            let cmd = (desired - self.last_net_cmd).clamp(-max_step, max_step) + self.last_net_cmd;
            self.last_net_cmd = cmd.clamp(-1.0, 0.0);
            self.integral = 0.0;
            return ControlCommand {
                traction_effort_pct: 0.0,
                service_brake_pct: (-self.last_net_cmd).clamp(0.0, 1.0),
                emergency_brake: false,
                target_speed_mps: 0.0,
                tracking_error_mps: -actual_speed_mps,
                residual_trim_applied: 0.0,
            };
        }

        let err = target_speed_mps - actual_speed_mps;
        let kp = if err < 0.0 { 0.78 } else { self.kp };
        // Feedforward for track gradient resistance
        let grad_ff = (gradient_per_mille * 0.012).clamp(-0.25, 0.25);

        let raw_p = kp * err + grad_ff;
        let tentative = raw_p + self.ki * self.integral;
        let saturated = tentative.clamp(-1.0, 1.0);

        // Conditional-integration anti-windup
        if (tentative - saturated).abs() < 1e-6 || err * tentative < 0.0 {
            self.integral = (self.integral + err * dt_s).clamp(-2.5, 2.5);
        }

        let mut desired = (kp * err + self.ki * self.integral + grad_ff).clamp(-1.0, 1.0);
        if desired < 0.0 {
            desired = (desired + brake_trim).clamp(-1.0, 0.0);
        }
        if !allow_traction && desired > 0.0 {
            desired = 0.0;
        }

        // Command-rate & jerk constraint
        let max_step = self.max_cmd_rate_per_s * dt_s;
        let rate_limited =
            (desired - self.last_net_cmd).clamp(-max_step, max_step) + self.last_net_cmd;
        self.last_net_cmd = rate_limited.clamp(-1.0, 1.0);

        let (traction_effort_pct, service_brake_pct) = if self.last_net_cmd >= 0.0 {
            (self.last_net_cmd, 0.0)
        } else {
            (0.0, -self.last_net_cmd)
        };

        ControlCommand {
            traction_effort_pct,
            service_brake_pct,
            emergency_brake: false,
            target_speed_mps,
            tracking_error_mps: err,
            residual_trim_applied: brake_trim,
        }
    }
}
