use br_sensors::{DoorInterlockState, TimestampMs};
use br_vehicle_control::ControlCommand;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PhysicalActuationConfig {
    /// Physical actuation MUST remain disabled in the default configuration.
    pub enabled: bool,
    pub lockout_reason: String,
}

impl Default for PhysicalActuationConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            lockout_reason: "Physical actuation disabled by default: SIL-4 railway homologation required.".to_string(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VehicleCommandEnvelope {
    pub timestamp_ms: TimestampMs,
    pub traction_effort_pct: f64,
    pub service_brake_pct: f64,
    pub emergency_brake: bool,
    pub door_release_side: Option<String>,
    pub physical_actuation_sent: bool,
}

/// Manufacturer-adapter boundary: abstracts TCMS / ETCS-ATO interface without coupling onboard planning to hardware buses.
pub trait VehicleInterface {
    fn supports_effort_command(&self) -> bool;
    fn supports_position_command(&self) -> bool;
    fn apply_command(
        &mut self,
        now_ms: TimestampMs,
        cmd: &ControlCommand,
        door_release_side: Option<&str>,
    ) -> VehicleCommandEnvelope;
    fn door_interlock_state(&self) -> DoorInterlockState;
}

pub struct MockVehicleInterface {
    cfg: PhysicalActuationConfig,
    supports_effort: bool,
    supports_position: bool,
    door_state: DoorInterlockState,
    pub last_envelope: Option<VehicleCommandEnvelope>,
}

impl MockVehicleInterface {
    pub fn new(cfg: PhysicalActuationConfig) -> Self {
        Self {
            cfg,
            supports_effort: true,
            supports_position: false,
            door_state: DoorInterlockState::LockedAndProven,
            last_envelope: None,
        }
    }

    pub fn inject_door_state(&mut self, state: DoorInterlockState) {
        self.door_state = state;
    }
}

impl VehicleInterface for MockVehicleInterface {
    fn supports_effort_command(&self) -> bool {
        self.supports_effort
    }

    fn supports_position_command(&self) -> bool {
        self.supports_position
    }

    fn apply_command(
        &mut self,
        now_ms: TimestampMs,
        cmd: &ControlCommand,
        door_release_side: Option<&str>,
    ) -> VehicleCommandEnvelope {
        let env = VehicleCommandEnvelope {
            timestamp_ms: now_ms,
            traction_effort_pct: cmd.traction_effort_pct,
            service_brake_pct: cmd.service_brake_pct,
            emergency_brake: cmd.emergency_brake,
            door_release_side: door_release_side.map(|s| s.to_string()),
            physical_actuation_sent: self.cfg.enabled,
        };
        self.last_envelope = Some(env.clone());
        env
    }

    fn door_interlock_state(&self) -> DoorInterlockState {
        self.door_state
    }
}
