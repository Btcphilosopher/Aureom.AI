use br_route_model::{OperationalWorldModel, RouteAtlas};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrajectoryPoint {
    pub chainage_m: f64,
    pub target_speed_mps: f64,
    pub ceiling_speed_mps: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrajectoryPlan {
    pub feasible: bool,
    pub target_speed_mps: f64,
    pub target_accel_mps2: f64,
    pub stopping_distance_required_m: f64,
    pub upcoming_restriction_distance_m: Option<f64>,
    pub coast_recommended: bool,
    pub points: Vec<TrajectoryPoint>,
}

pub struct LongitudinalPlanner {
    pub comfort_decel_mps2: f64,
    pub actuator_lag_s: f64,
    pub horizon_m: f64,
    pub step_m: f64,
}

impl Default for LongitudinalPlanner {
    fn default() -> Self {
        Self {
            comfort_decel_mps2: 0.72,
            actuator_lag_s: 0.35,
            horizon_m: 1400.0,
            step_m: 50.0,
        }
    }
}

impl LongitudinalPlanner {
    /// Generates a continuously checked longitudinal speed/stopping trajectory using backward braking integration.
    /// Never generates lateral avoidance manoeuvres.
    pub fn plan(
        &self,
        atlas: &RouteAtlas,
        world: &OperationalWorldModel,
        supervisor_max_speed_mps: f64,
        optimised_coast_bias_mps: f64,
    ) -> TrajectoryPlan {
        let ma = match world.valid_movement_authority(600) {
            Some(m) => m,
            None => {
                return TrajectoryPlan {
                    feasible: false,
                    target_speed_mps: 0.0,
                    target_accel_mps2: -self.comfort_decel_mps2,
                    stopping_distance_required_m: f64::INFINITY,
                    upcoming_restriction_distance_m: None,
                    coast_recommended: false,
                    points: vec![],
                }
            }
        };

        let pos = world.position_m.value.0;
        let speed = world.speed_mps.value.0;
        let sigma_buffer = 3.0 * world.position_uncertainty_m.0;
        let eff_decel = (self.comfort_decel_mps2 * world.estimated_adhesion)
            .min(world.braking_capability_mps2.value.0 * 0.85)
            .max(0.25);

        // Hard stopping target: minimum of End of Authority, next station berth, and any detected corridor object
        let mut hard_stop_m = ma.end_of_authority_m.0 - sigma_buffer - 8.0;
        if let Some(st) = &world.next_station {
            if st.available && st.stop_berth_m >= pos - 25.0 {
                hard_stop_m = hard_stop_m.min(st.stop_berth_m);
            }
        }
        for obj in &world.relevant_objects {
            if obj.requires_stop {
                hard_stop_m = hard_stop_m.min(pos + obj.distance_ahead_m.0 - obj.uncertainty_m.0 - 8.0);
            }
        }

        let steps = ((self.horizon_m / self.step_m).ceil() as usize).max(4);
        let mut pts = Vec::with_capacity(steps + 1);
        for i in 0..=steps {
            let s = pos + (i as f64) * self.step_m;
            let route_limit = atlas
                .speed_limit_at(s)
                .map(|v| v.0)
                .unwrap_or(0.0)
                .min(atlas.speed_limit_at(s + sigma_buffer + 6.0).map(|v| v.0).unwrap_or(0.0));
            let ceiling = route_limit
                .min(ma.ceiling_speed_mps.0)
                .min(supervisor_max_speed_mps);
            let dist_rem = (hard_stop_m - s).max(0.0);
            let v_stop = (2.0 * eff_decel * dist_rem).sqrt();
            let target = ceiling.min(v_stop);
            pts.push(TrajectoryPoint {
                chainage_m: s,
                target_speed_mps: target,
                ceiling_speed_mps: ceiling,
            });
        }

        // Backward kinematic pass accounting for gradient and actuator lag
        for i in (0..pts.len() - 1).rev() {
            let s_mid = 0.5 * (pts[i].chainage_m + pts[i + 1].chainage_m);
            let grad_per_mille = atlas.gradient_at(s_mid).0;
            let grad_accel = -9.81 * (grad_per_mille / 1000.0);
            let net_decel = (eff_decel - grad_accel).max(0.20);
            let v_next = pts[i + 1].target_speed_mps;
            let ds = (pts[i + 1].chainage_m - pts[i].chainage_m).max(1.0);
            let v_allow = (v_next * v_next + 2.0 * net_decel * ds).sqrt();
            if v_allow < pts[i].target_speed_mps {
                pts[i].target_speed_mps = v_allow;
            }
        }

        let stopping_dist = speed * self.actuator_lag_s + (speed * speed) / (2.0 * eff_decel);
        let dist_to_stop = (hard_stop_m - pos).max(0.0);
        let feasible = dist_to_stop + 2.0 >= stopping_dist || speed <= 0.2;

        let mut target_v = pts[0].target_speed_mps;
        let upcoming_restriction_distance_m = pts
            .iter()
            .skip(1)
            .find(|p| p.ceiling_speed_mps < pts[0].ceiling_speed_mps - 1.0)
            .map(|p| p.chainage_m - pos);

        // Energy-optimal coasting band (subordinate to limits and stopping feasibility)
        let coast_recommended = optimised_coast_bias_mps > 0.1
            && target_v > 14.0
            && dist_to_stop > stopping_dist * 1.45
            && (target_v - speed).abs() < 2.0;
        if coast_recommended {
            target_v = (target_v - optimised_coast_bias_mps).max(0.0);
        }

        let target_accel = if pts.len() >= 2 {
            ((pts[1].target_speed_mps * pts[1].target_speed_mps - speed * speed)
                / (2.0 * self.step_m))
                .clamp(-eff_decel, 0.75)
        } else {
            0.0
        };

        TrajectoryPlan {
            feasible,
            target_speed_mps: target_v,
            target_accel_mps2: target_accel,
            stopping_distance_required_m: stopping_dist,
            upcoming_restriction_distance_m,
            coast_recommended,
            points: pts,
        }
    }
}
