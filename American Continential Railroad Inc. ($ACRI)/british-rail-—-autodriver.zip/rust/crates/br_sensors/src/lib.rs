use serde::{Deserialize, Serialize};

/// Explicit physical units (newtype wrappers prevent unit confusion at compile time).
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize, Default)]
pub struct Metres(pub f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize, Default)]
pub struct MetresPerSecond(pub f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize, Default)]
pub struct MetresPerSecondSquared(pub f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize, Default)]
pub struct Kilograms(pub f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize, Default)]
pub struct Newtons(pub f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize, Default)]
pub struct Seconds(pub f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Serialize, Deserialize, Default)]
pub struct TimestampMs(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize, Default)]
pub struct GradientPerMille(pub f64);

/// Explicit coordinate frames.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CoordinateFrame {
    TrackChainage { track_id: String },
    VehicleBodyForward,
    Wgs84Geodetic,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TrackPosition {
    pub track_id: String,
    pub chainage_m: Metres,
}

/// Bounded fixed-capacity ring buffer queue for deterministic, allocation-free onboard messaging.
#[derive(Debug, Clone)]
pub struct BoundedQueue<T, const N: usize> {
    buf: [Option<T>; N],
    head: usize,
    len: usize,
    dropped_oldest: u64,
}

impl<T: Clone, const N: usize> BoundedQueue<T, N> {
    pub fn new() -> Self {
        Self {
            buf: std::array::from_fn(|_| None),
            head: 0,
            len: 0,
            dropped_oldest: 0,
        }
    }

    pub fn push(&mut self, item: T) {
        if N == 0 {
            return;
        }
        if self.len == N {
            self.buf[self.head] = Some(item);
            self.head = (self.head + 1) % N;
            self.dropped_oldest += 1;
        } else {
            let idx = (self.head + self.len) % N;
            self.buf[idx] = Some(item);
            self.len += 1;
        }
    }

    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            return None;
        }
        let item = self.buf[self.head].take();
        self.head = (self.head + 1) % N;
        self.len -= 1;
        item
    }

    pub fn latest(&self) -> Option<&T> {
        if self.len == 0 {
            return None;
        }
        let idx = (self.head + self.len - 1) % N;
        self.buf[idx].as_ref()
    }

    pub fn len(&self) -> usize {
        self.len
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn dropped_count(&self) -> u64 {
        self.dropped_oldest
    }
}

impl<T: Clone, const N: usize> Default for BoundedQueue<T, N> {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DataSource {
    WheelOdometry,
    DopplerRadarSpeed,
    InertialUnit,
    Eurobalise,
    GnssReceiver,
    ForwardCamera,
    RangeLidar,
    VehicleTcms,
    SignallingEtcs,
    RouteAtlas,
    TrafficManagement,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WheelOdometry {
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
    pub frame: CoordinateFrame,
    pub delta_distance_m: Metres,
    pub speed_mps: MetresPerSecond,
    pub wheel_slip_suspected: bool,
    pub valid: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpeedSensor {
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
    pub speed_mps: MetresPerSecond,
    pub uncertainty_mps: MetresPerSecond,
    pub valid: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImuMeasurement {
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
    pub frame: CoordinateFrame,
    pub longitudinal_accel_mps2: MetresPerSecondSquared,
    pub pitch_rad: f64,
    pub valid: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BaliseReference {
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
    pub balise_id: String,
    pub track_id: String,
    pub chainage_m: Metres,
    pub uncertainty_m: Metres,
    pub valid: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GnssFix {
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
    pub projected_track_id: Option<String>,
    pub projected_chainage_m: Metres,
    pub horizontal_uncertainty_m: Metres,
    pub in_tunnel_outage: bool,
    pub valid: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CameraDetectionFixture {
    pub kind: String,
    pub track_corridor: bool,
    pub distance_m: Metres,
    pub confidence: f64,
    pub uncertainty_m: Metres,
    pub occluded_fraction: f64,
    pub apparent_aspect: Option<String>,
    pub label: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CameraPerceptionInput {
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
    pub visibility_m: Metres,
    pub weather: String,
    pub detections: Vec<CameraDetectionFixture>,
    pub occluded_start_m: Option<Metres>,
    pub occluded_end_m: Option<Metres>,
    pub valid: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RangeSensorInput {
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
    pub nearest_corridor_return_m: Option<Metres>,
    pub return_confidence: f64,
    pub uncertainty_m: Metres,
    pub valid: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DoorInterlockState {
    LockedAndProven,
    ReleasedLeft,
    ReleasedRight,
    FaultInterlockOpen,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VehicleTelemetry {
    pub timestamp_ms: TimestampMs,
    pub source: DataSource,
    pub achieved_traction_n: Newtons,
    pub achieved_brake_decel_mps2: MetresPerSecondSquared,
    pub requested_brake_decel_mps2: MetresPerSecondSquared,
    pub brake_pipe_pressure_bar: f64,
    pub door_interlock: DoorInterlockState,
    pub emergency_brake_active: bool,
    pub valid: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SensorBusSnapshot {
    pub timestamp_ms: TimestampMs,
    pub odometry: Option<WheelOdometry>,
    pub speed: Option<SpeedSensor>,
    pub imu: Option<ImuMeasurement>,
    pub balise: Option<BaliseReference>,
    pub gnss: Option<GnssFix>,
    pub camera: Option<CameraPerceptionInput>,
    pub range: Option<RangeSensorInput>,
    pub vehicle: Option<VehicleTelemetry>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bounded_queue_drops_oldest_without_allocating() {
        let mut q: BoundedQueue<u32, 3> = BoundedQueue::new();
        q.push(1);
        q.push(2);
        q.push(3);
        q.push(4);
        assert_eq!(q.len(), 3);
        assert_eq!(q.dropped_count(), 1);
        assert_eq!(q.pop(), Some(2));
        assert_eq!(q.latest(), Some(&4));
    }
}
