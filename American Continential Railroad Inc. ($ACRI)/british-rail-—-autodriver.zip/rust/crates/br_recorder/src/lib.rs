use br_behaviour::BehaviourState;
use br_localisation::LocalisationMode;
use br_sensors::{BoundedQueue, TimestampMs};
use br_supervisor::SupervisorDisposition;
use serde::{Deserialize, Serialize};

/// Onboard-only recorded frame (strictly excludes SimulatorTruth to prevent R data leakage!).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OnboardRecordFrame {
    pub timestamp_ms: TimestampMs,
    pub est_position_m: f64,
    pub est_position_sigma_m: f64,
    pub est_speed_mps: f64,
    pub target_speed_mps: f64,
    pub ceiling_speed_mps: f64,
    pub gradient_per_mille: f64,
    pub estimated_adhesion: f64,
    pub traction_effort_pct: f64,
    pub requested_brake_pct: f64,
    pub achieved_brake_mps2: f64,
    pub behaviour_state: BehaviourState,
    pub localisation_mode: LocalisationMode,
    pub supervisor_disposition: SupervisorDisposition,
    pub loop_latency_us: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimingStats {
    pub samples: u64,
    pub max_latency_us: u64,
    pub mean_latency_us: f64,
    pub jitter_us: f64,
    pub missed_deadlines: u64,
}

pub struct BoundedRecorder<const N: usize> {
    ring: BoundedQueue<OnboardRecordFrame, N>,
    history: Vec<OnboardRecordFrame>,
    deadline_us: u64,
    missed_deadlines: u64,
    max_latency_us: u64,
    sum_latency_us: u64,
    sum_sq_diff: f64,
    count: u64,
}

impl<const N: usize> BoundedRecorder<N> {
    pub fn new(deadline_us: u64) -> Self {
        Self {
            ring: BoundedQueue::new(),
            history: Vec::with_capacity(N),
            deadline_us,
            missed_deadlines: 0,
            max_latency_us: 0,
            sum_latency_us: 0,
            sum_sq_diff: 0.0,
            count: 0,
        }
    }

    pub fn record(&mut self, frame: OnboardRecordFrame) {
        let lat = frame.loop_latency_us;
        self.count += 1;
        self.sum_latency_us += lat;
        if lat > self.max_latency_us {
            self.max_latency_us = lat;
        }
        if lat > self.deadline_us {
            self.missed_deadlines += 1;
        }
        let mean = self.sum_latency_us as f64 / self.count as f64;
        self.sum_sq_diff += (lat as f64 - mean).powi(2);

        self.ring.push(frame.clone());
        self.history.push(frame);
    }

    pub fn timing_stats(&self) -> TimingStats {
        let mean = if self.count > 0 {
            self.sum_latency_us as f64 / self.count as f64
        } else {
            0.0
        };
        let jitter = if self.count > 1 {
            (self.sum_sq_diff / self.count as f64).sqrt()
        } else {
            0.0
        };
        TimingStats {
            samples: self.count,
            max_latency_us: self.max_latency_us,
            mean_latency_us: mean,
            jitter_us: jitter,
            missed_deadlines: self.missed_deadlines,
        }
    }

    pub fn frames(&self) -> &[OnboardRecordFrame] {
        &self.history
    }

    pub fn ring_dropped(&self) -> u64 {
        self.ring.dropped_count()
    }
}
