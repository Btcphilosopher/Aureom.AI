# 05_residual_model_export.R
# Trains bounded residual trim models with strict time-separated validation (Runs 1..14 train, 15..20 val).
# Verifies zero future measurement leakage and zero SimulatorTruth fields.

library(jsonlite)

train_and_export_residual_model <- function(recorded_runs_df, output_path = "../models/br_class_395_residual_v1.json") {
  forbidden_cols <- c("truth_position_m", "truth_speed_mps", "future_speed_mps", "future_ma_m")
  if (any(forbidden_cols %in% names(recorded_runs_df))) {
    stop("LEAKAGE GUARD TRIGGERED: Forbidden ground-truth or future columns detected.")
  }

  # Strict out-of-time split by run_timestamp_index
  train_df <- subset(recorded_runs_df, run_index <= 14)
  val_df   <- subset(recorded_runs_df, run_index > 14)

  feats <- c("speed_mps", "gradient_per_mille", "distance_to_target_m", "estimated_adhesion")
  means <- sapply(train_df[, feats], mean)
  sds   <- sapply(train_df[, feats], sd)
  mins  <- sapply(train_df[, feats], min)
  maxs  <- sapply(train_df[, feats], max)

  z_train <- as.data.frame(scale(train_df[, feats], center = means, scale = sds))
  z_val   <- as.data.frame(scale(val_df[, feats], center = means, scale = sds))

  coast_fit <- lm(optimal_coast_trim_mps ~ speed_mps + gradient_per_mille + distance_to_target_m + estimated_adhesion, data = z_train)
  brake_fit <- lm(optimal_brake_trim ~ speed_mps + gradient_per_mille + distance_to_target_m + estimated_adhesion - 1, data = z_train)

  val_pred <- predict(coast_fit, newdata = z_val)
  val_rmse <- sqrt(mean((val_df$optimal_coast_trim_mps - val_pred)^2))

  artifact <- list(
    model_id = "br_class_395_residual_v1",
    version = "1.0.0",
    trained_by = "r_analytics/R/05_residual_model_export.R",
    features = lapply(seq_along(feats), function(i) {
      list(name = feats[i], mean = unname(means[i]), sd = unname(sds[i]), min = unname(mins[i]), max = unname(maxs[i]))
    }),
    weights = list(
      intercept = unname(coef(coast_fit)[1]),
      coast_bias_coeffs = unname(coef(coast_fit)[2:5]),
      brake_trim_coeffs = unname(coef(brake_fit)[1:4])
    ),
    bounds = list(
      max_coast_speed_trim_mps = 0.85,
      max_brake_effort_trim = 0.08,
      fallback_on_out_of_domain = "RevertToBaselineZeroTrim"
    ),
    uncertainty = list(
      residual_sigma_mps2 = val_rmse,
      validation_rmse_mps2 = val_rmse
    )
  )

  write_json(artifact, output_path, auto_unbox = TRUE, pretty = TRUE)
  artifact
}
