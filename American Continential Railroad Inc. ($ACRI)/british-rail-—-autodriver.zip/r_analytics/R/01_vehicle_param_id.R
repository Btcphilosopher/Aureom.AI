# 01_vehicle_param_id.R
# Identifies Davis rolling-resistance coefficients (A, B, C) from recorded onboard coasting telemetry.
# Strictly uses onboard-recorded estimates (never SimulatorTruth).

identify_davis_parameters <- function(coasting_df) {
  stopifnot(all(c("est_speed_mps", "achieved_accel_mps2", "gradient_per_mille") %in% names(coasting_df)))
  mass_eff_kg <- 268000.0 * 1.06
  g <- 9.81

  # Net resistive force inferred during coasting (traction == 0, brake == 0)
  resistive_force_n <- -mass_eff_kg * coasting_df$achieved_accel_mps2 -
    268000.0 * g * (coasting_df$gradient_per_mille / 1000.0)

  v <- coasting_df$est_speed_mps
  fit <- lm(resistive_force_n ~ v + I(v^2))
  coefs <- coef(fit)

  list(
    davis_a_n = unname(coefs[1]),
    davis_b_n_per_mps = unname(coefs[2]),
    davis_c_n_per_mps2 = unname(coefs[3]),
    r_squared = summary(fit)$r.squared,
    residual_se_n = summary(fit)$sigma
  )
}
