# 03_energy_modelling.R
# Models tractive energy consumption and regenerative braking acceptance.

model_energy_and_coasting <- function(runs_df) {
  stopifnot(all(c("run_id", "coast_speed_trim_mps", "energy_consumed_kwh", "regen_energy_accepted_kwh", "stop_position_error_m") %in% names(runs_df)))
  fit <- lm(energy_consumed_kwh ~ coast_speed_trim_mps + regen_energy_accepted_kwh, data = runs_df)
  list(
    baseline_mean_kwh = mean(runs_df$energy_consumed_kwh[runs_df$coast_speed_trim_mps == 0]),
    optimised_mean_kwh = mean(runs_df$energy_consumed_kwh[runs_df$coast_speed_trim_mps > 0]),
    model_r2 = summary(fit)$r.squared,
    max_stop_error_m = max(runs_df$stop_position_error_m)
  )
}
