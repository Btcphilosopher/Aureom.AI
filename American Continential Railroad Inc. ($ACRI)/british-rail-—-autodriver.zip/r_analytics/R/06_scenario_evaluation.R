# 06_scenario_evaluation.R
# Evaluates Baseline vs R-Optimised drivers across identical scenario runs and all 10 required KPIs.

library(jsonlite)

evaluate_driver_comparison <- function(baseline_json_path, optimised_json_path) {
  base <- fromJSON(baseline_json_path)
  opt  <- fromJSON(optimised_json_path)

  stopifnot(nrow(base) == nrow(opt))

  comparison <- data.frame(
    scenario = base$scenario,
    base_violations = base$constraint_violations,
    opt_violations = opt$constraint_violations,
    base_stop_err_m = base$stop_position_error_m,
    opt_stop_err_m = opt$stop_position_error_m,
    base_energy_kwh = base$energy_consumed_kwh,
    opt_energy_kwh = opt$energy_consumed_kwh,
    energy_delta_pct = round(100 * (opt$energy_consumed_kwh - base$energy_consumed_kwh) / pmax(base$energy_consumed_kwh, 1e-6), 2),
    base_passed = base$passed,
    opt_passed = opt$passed
  )

  # Safety gate: Energy improvement must NEVER conceal worse stopping performance or constraint violations
  safety_regression <- any(opt$constraint_violations > base$constraint_violations) ||
    any(opt$stop_position_error_m > base$stop_position_error_m + 0.25)

  list(
    comparison = comparison,
    safety_regression_detected = safety_regression,
    all_passed = all(base$passed) && all(opt$passed) && !safety_regression
  )
}
