# 02_braking_analysis.R
# Analyses achieved vs requested braking deceleration across adhesion regimes.

analyse_braking_performance <- function(braking_df) {
  stopifnot(all(c("requested_brake_pct", "achieved_brake_mps2", "estimated_adhesion") %in% names(braking_df)))
  active <- subset(braking_df, requested_brake_pct > 0.05)

  expected_mps2 <- active$requested_brake_pct * 1.05
  ratio <- active$achieved_brake_mps2 / pmax(expected_mps2, 1e-4)

  fit <- lm(achieved_brake_mps2 ~ requested_brake_pct + estimated_adhesion, data = active)
  list(
    mean_effectiveness_ratio = mean(ratio),
    p05_effectiveness_ratio = unname(quantile(ratio, 0.05)),
    adhesion_sensitivity = unname(coef(fit)["estimated_adhesion"]),
    rmse_mps2 = sqrt(mean(residuals(fit)^2))
  )
}
