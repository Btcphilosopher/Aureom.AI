# 07_verify_rust_parity.R
# Cross-verifies R reference inference against Rust ResidualModelArtifact::predict_bounded outputs.

library(jsonlite)

verify_rust_parity <- function(artifact_path = "../models/br_class_395_residual_v1.json") {
  art <- fromJSON(artifact_path)
  test_vec <- c(24.0, 4.5, 580.0, 0.90)

  z <- mapply(function(x, m, s) (x - m) / s, test_vec, art$features$mean, art$features$sd)
  coast_r <- min(max(art$weights$intercept + sum(art$weights$coast_bias_coeffs * z), 0.0), art$bounds$max_coast_speed_trim_mps)
  brake_r <- min(max(sum(art$weights$brake_trim_coeffs * z), -art$bounds$max_brake_effort_trim), art$bounds$max_brake_effort_trim)

  cat(sprintf("Parity test point: coast_trim=%.6f m/s, brake_trim=%.6f\n", coast_r, brake_r))
  list(coast_trim_mps = coast_r, brake_effort_trim = brake_r)
}
