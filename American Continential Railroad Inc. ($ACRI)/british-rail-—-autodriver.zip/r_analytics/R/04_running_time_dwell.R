# 04_running_time_dwell.R
# Predicts inter-station running time and station dwell variation.

predict_running_and_dwell <- function(station_df) {
  stopifnot(all(c("station_id", "scheduled_dwell_s", "observed_dwell_s", "segment_run_s") %in% names(station_df)))
  dwell_err <- station_df$observed_dwell_s - station_df$scheduled_dwell_s
  list(
    mean_dwell_deviation_s = mean(dwell_err),
    p95_dwell_deviation_s = unname(quantile(dwell_err, 0.95)),
    mean_segment_run_s = mean(station_df$segment_run_s),
    sd_segment_run_s = sd(station_df$segment_run_s)
  )
}
