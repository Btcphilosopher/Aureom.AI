import {HttpClient} from '@angular/common/http';
import {Injectable, PLATFORM_ID, computed, inject, signal} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {firstValueFrom} from 'rxjs';
import type {
  ComparisonResult,
  FaultInjections,
  LiveTelemetryFrame,
  ResidualModelArtifact,
  RouteAtlas,
  ScenarioId,
  ScenarioMetrics,
} from '../sim/types';

export interface ScenarioCatalogItem {
  id: ScenarioId;
  title: string;
  focus: string;
}

export interface ArtifactsPayload {
  model: ResidualModelArtifact;
  parityProbe: [number, number, number, number];
  inference: {coastTrimMps: number; brakeTrim: number; inDomain: boolean};
  scenes: {
    fixture_set_id: string;
    description: string;
    scenes: {
      scene_id: string;
      chainage_range_m: [number, number];
      visibility_m: number;
      weather: string;
      detections: {
        kind: string;
        track_corridor: boolean;
        distance_m: number;
        confidence: number;
        uncertainty_m: number;
        label: string;
      }[];
    }[];
  };
  route: RouteAtlas;
}

@Injectable({providedIn: 'root'})
export class AutoDriverStore {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);

  readonly atlas = signal<RouteAtlas | null>(null);
  readonly frame = signal<LiveTelemetryFrame | null>(null);
  readonly isRunning = signal(false);
  readonly speedMultiplier = signal<1 | 4 | 10>(4);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);

  readonly catalog = signal<ScenarioCatalogItem[]>([]);
  readonly comparison = signal<ComparisonResult | null>(null);
  readonly singleScenarioResult = signal<ScenarioMetrics | null>(null);
  readonly scenariosLoading = signal(false);

  readonly artifacts = signal<ArtifactsPayload | null>(null);
  readonly codebaseFiles = signal<string[]>([]);
  readonly selectedFilePath = signal<string>('rust/crates/br_behaviour/src/lib.rs');
  readonly selectedFileContent = signal<string>('');

  private timerId: ReturnType<typeof setInterval> | null = null;

  readonly speedKmh = computed(() => {
    const f = this.frame();
    return f ? (f.est_speed_mps * 3.6).toFixed(1) : '0.0';
  });

  readonly ceilingKmh = computed(() => {
    const f = this.frame();
    return f ? (f.ceiling_speed_mps * 3.6).toFixed(1) : '0.0';
  });

  async init(): Promise<void> {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    try {
      const [simRes, catRes, artRes, listRes] = await Promise.all([
        firstValueFrom(this.http.get<{atlas: RouteAtlas; frame: LiveTelemetryFrame}>('/api/sim/state')),
        firstValueFrom(this.http.get<{scenarios: ScenarioCatalogItem[]}>('/api/scenarios/catalog')),
        firstValueFrom(this.http.get<ArtifactsPayload>('/api/artifacts/model')),
        firstValueFrom(this.http.get<{files: string[]}>('/api/codebase/list')),
      ]);
      this.atlas.set(simRes.atlas);
      this.frame.set(simRes.frame);
      this.catalog.set(catRes.scenarios);
      this.artifacts.set(artRes);
      this.codebaseFiles.set(listRes.files);
      await this.loadCodebaseFile(this.selectedFilePath());
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed to connect to simulation server');
    } finally {
      this.loading.set(false);
    }
  }

  togglePlay(): void {
    if (this.isRunning()) {
      this.pause();
    } else {
      this.play();
    }
  }

  play(): void {
    if (!isPlatformBrowser(this.platformId) || this.isRunning()) return;
    this.isRunning.set(true);
    this.timerId = setInterval(() => {
      void this.step(this.speedMultiplier());
    }, 150);
  }

  pause(): void {
    this.isRunning.set(false);
    if (this.timerId !== null) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  setSpeedMultiplier(mult: 1 | 4 | 10): void {
    this.speedMultiplier.set(mult);
  }

  async step(steps = 1): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.post<{frame: LiveTelemetryFrame}>('/api/sim/step', {steps})
      );
      this.frame.set(res.frame);
    } catch (e) {
      this.pause();
      this.error.set(e instanceof Error ? e.message : 'Step request failed');
    }
  }

  async reset(driverMode: 'Baseline' | 'R-Optimised' = 'Baseline', seed = 42): Promise<void> {
    this.pause();
    const res = await firstValueFrom(
      this.http.post<{atlas: RouteAtlas; frame: LiveTelemetryFrame}>('/api/sim/reset', {
        driverMode,
        seed,
      })
    );
    this.atlas.set(res.atlas);
    this.frame.set(res.frame);
  }

  async setDriverMode(driverMode: 'Baseline' | 'R-Optimised'): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{frame: LiveTelemetryFrame}>('/api/sim/mode', {driverMode})
    );
    this.frame.set(res.frame);
  }

  async updateFaults(partial: Partial<FaultInjections>): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{frame: LiveTelemetryFrame}>('/api/sim/faults', partial)
    );
    this.frame.set(res.frame);
  }

  async triggerRestart(): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{frame: LiveTelemetryFrame}>('/api/sim/restart', {})
    );
    this.frame.set(res.frame);
  }

  async authoriseRecovery(operatorId: string): Promise<boolean> {
    const res = await firstValueFrom(
      this.http.post<{ok: boolean; frame: LiveTelemetryFrame}>('/api/sim/recover', {operatorId})
    );
    this.frame.set(res.frame);
    return res.ok;
  }

  async runSingleScenario(scenarioId: ScenarioId, driverMode: 'Baseline' | 'R-Optimised'): Promise<void> {
    this.scenariosLoading.set(true);
    try {
      const res = await firstValueFrom(
        this.http.post<{result: ScenarioMetrics}>('/api/scenarios/run', {
          scenarioId,
          driverMode,
          seed: 42,
        })
      );
      this.singleScenarioResult.set(res.result);
    } finally {
      this.scenariosLoading.set(false);
    }
  }

  async runComparisonSuite(seed = 42): Promise<void> {
    this.scenariosLoading.set(true);
    try {
      const res = await firstValueFrom(
        this.http.post<ComparisonResult>('/api/scenarios/compare', {seed})
      );
      this.comparison.set(res);
    } finally {
      this.scenariosLoading.set(false);
    }
  }

  async loadCodebaseFile(filePath: string): Promise<void> {
    this.selectedFilePath.set(filePath);
    const res = await firstValueFrom(
      this.http.get<{path: string; content: string}>('/api/codebase/file', {
        params: {path: filePath},
      })
    );
    this.selectedFileContent.set(res.content);
  }

  downloadComparisonCsv(): void {
    const cmp = this.comparison();
    if (!cmp || !isPlatformBrowser(this.platformId)) return;
    const header = [
      'scenario',
      'driver_mode',
      'passed',
      'constraint_violations',
      'stop_position_error_m',
      'arrival_time_deviation_s',
      'energy_consumed_kwh',
      'regen_energy_accepted_kwh',
      'peak_accel_mps2',
      'peak_jerk_mps3',
      'intervention_count',
      'fault_response_time_ms',
      'max_localisation_uncertainty_m',
      'obstruction_detection_distance_m',
      'obstruction_stopping_feasible',
    ].join(',');

    const rows = [...cmp.baseline, ...cmp.optimised].map((r) =>
      [
        r.scenario,
        r.driver_mode,
        r.passed,
        r.constraint_violations,
        r.stop_position_error_m,
        r.arrival_time_deviation_s,
        r.energy_consumed_kwh,
        r.regen_energy_accepted_kwh,
        r.peak_accel_mps2,
        r.peak_jerk_mps3,
        r.intervention_count,
        r.fault_response_time_ms ?? '',
        r.max_localisation_uncertainty_m,
        r.obstruction_detection_distance_m ?? '',
        r.obstruction_stopping_feasible ?? '',
      ].join(',')
    );

    const blob = new Blob([[header, ...rows].join('\n')], {type: 'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `br_autodriver_evaluation_seed_${cmp.seed}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
