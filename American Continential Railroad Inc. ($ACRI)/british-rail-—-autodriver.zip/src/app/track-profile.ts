import {ChangeDetectionStrategy, Component, computed, input} from '@angular/core';
import type {LiveTelemetryFrame, RouteAtlas} from '../sim/types';

@Component({
  selector: 'app-track-profile',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (atlas() && frame(); as f) {
      <div class="space-y-4">
        <!-- Route Schematic Corridor (0 - 8600 m) -->
        <div>
          <div class="flex items-center justify-between text-xs text-slate-500 mb-1.5">
            <span>Corridor Geometry &amp; Movement Authority ({{ atlas()!.route_id }})</span>
            <span class="font-mono tabular-nums">
              Est: {{ f.est_position_m.toFixed(1) }} m (±{{ (f.est_position_sigma_m * 3).toFixed(1) }} m 3σ) · EOA: {{ f.end_of_authority_m.toFixed(0) }} m
            </span>
          </div>
          <svg viewBox="0 0 920 116" class="w-full h-28 bg-slate-50 border border-slate-200 rounded-lg">
            <!-- Tunnel Shading -->
            @for (tun of atlas()!.tunnels; track tun.id) {
              <rect
                [attr.x]="xMap(tun.start_m)"
                y="14"
                [attr.width]="xMap(tun.end_m) - xMap(tun.start_m)"
                height="58"
                fill="#E2E8F0"
                opacity="0.7"
              />
              <text
                [attr.x]="xMap(tun.start_m) + 4"
                y="26"
                font-size="9"
                fill="#475569"
                class="font-mono"
              >
                {{ tun.name }} (No GNSS)
              </text>
            }

            <!-- Main Track Line -->
            <line x1="20" y1="52" x2="900" y2="52" stroke="#94A3B8" stroke-width="3" />

            <!-- Authorised Movement Authority Span -->
            <line
              x1="20"
              y1="52"
              [attr.x2]="xMap(f.end_of_authority_m)"
              y2="52"
              stroke="#0B2D48"
              stroke-width="4"
            />

            <!-- End of Movement Authority Marker -->
            <line
              [attr.x1]="xMap(f.end_of_authority_m)"
              y1="26"
              [attr.x2]="xMap(f.end_of_authority_m)"
              y2="74"
              stroke="#DC2626"
              stroke-width="2"
            />
            <text
              [attr.x]="xMap(f.end_of_authority_m) - 24"
              y="22"
              font-size="9"
              fill="#DC2626"
              class="font-mono font-semibold"
            >
              EOA
            </text>

            <!-- Stations & Platforms -->
            @for (st of atlas()!.stations; track st.station_id) {
              <rect
                [attr.x]="xMap(st.platform_start_m)"
                y="56"
                [attr.width]="Math.max(8, xMap(st.platform_end_m) - xMap(st.platform_start_m))"
                height="8"
                fill="#0B2D48"
                opacity="0.25"
              />
              <line
                [attr.x1]="xMap(st.stop_berth_m)"
                y1="44"
                [attr.x2]="xMap(st.stop_berth_m)"
                y2="66"
                stroke="#0B2D48"
                stroke-width="1.5"
              />
              <text
                [attr.x]="xMap(st.stop_berth_m)"
                y="88"
                text-anchor="middle"
                font-size="9"
                fill="#0F172A"
                class="font-medium"
              >
                {{ st.station_id }}
              </text>
              <text
                [attr.x]="xMap(st.stop_berth_m)"
                y="100"
                text-anchor="middle"
                font-size="8"
                fill="#64748B"
                class="font-mono"
              >
                {{ st.stop_berth_m }}m
              </text>
            }

            <!-- Corridor Obstruction if present -->
            @if (f.faults.track_obstruction_m !== null) {
              <rect
                [attr.x]="xMap(f.faults.track_obstruction_m) - 4"
                y="43"
                width="8"
                height="16"
                fill="#DC2626"
              />
            }

            <!-- 3-Sigma Uncertainty Envelope -->
            <rect
              [attr.x]="xMap(Math.max(0, f.est_position_m - f.est_position_sigma_m * 3))"
              y="39"
              [attr.width]="Math.max(4, xMap(f.est_position_m + f.est_position_sigma_m * 3) - xMap(Math.max(0, f.est_position_m - f.est_position_sigma_m * 3)))"
              height="26"
              fill="#D97706"
              opacity="0.22"
            />

            <!-- Train Consist (121.2m) -->
            <rect
              [attr.x]="xMap(Math.max(0, f.est_position_m - 121.2))"
              y="45"
              [attr.width]="Math.max(12, xMap(f.est_position_m) - xMap(Math.max(0, f.est_position_m - 121.2)))"
              height="14"
              rx="2"
              fill="#0B2D48"
            />
          </svg>
        </div>

        <!-- Longitudinal Rolling Trajectory Horizon (+1400 m) -->
        <div>
          <div class="flex items-center justify-between text-xs text-slate-500 mb-1.5">
            <span>Rolling Longitudinal Trajectory (+1,400 m Horizon)</span>
            <span class="font-mono tabular-nums">
              Target: {{ (f.target_speed_mps * 3.6).toFixed(1) }} km/h · Actual: {{ (f.est_speed_mps * 3.6).toFixed(1) }} km/h · Stopping Req: {{ f.stopping_distance_required_m.toFixed(0) }} m
            </span>
          </div>
          <svg viewBox="0 0 920 175" class="w-full h-44 bg-white border border-slate-200 rounded-lg">
            <!-- Horizontal grid lines (0, 45, 90, 126 km/h) -->
            @for (tick of speedTicks; track tick.mps) {
              <line
                x1="44"
                [attr.y1]="ySpeed(tick.mps)"
                x2="900"
                [attr.y2]="ySpeed(tick.mps)"
                stroke="#E2E8F0"
                stroke-width="1"
              />
              <text
                x="38"
                [attr.y]="ySpeed(tick.mps) + 3"
                text-anchor="end"
                font-size="9"
                fill="#64748B"
                class="font-mono"
              >
                {{ tick.label }}
              </text>
            }

            <!-- Ceiling Speed Step Envelope -->
            @if (ceilingPolyline()) {
              <polyline
                [attr.points]="ceilingPolyline()"
                fill="none"
                stroke="#DC2626"
                stroke-width="1.5"
                stroke-dasharray="4 3"
              />
            }

            <!-- Planned Speed Trajectory -->
            @if (targetPolyline()) {
              <polyline
                [attr.points]="targetPolyline()"
                fill="none"
                stroke="#0B2D48"
                stroke-width="2.5"
              />
            }

            <!-- Current Speed Marker at x=44 -->
            <circle
              cx="44"
              [attr.cy]="ySpeed(f.est_speed_mps)"
              r="4.5"
              fill="#0B2D48"
              stroke="#FFFFFF"
              stroke-width="1.5"
            />
          </svg>
          <div class="flex items-center gap-6 mt-1.5 text-xs text-slate-500">
            <span>Solid Navy: Planned Trajectory</span>
            <span>Dashed Red: Route &amp; Authority Ceiling</span>
            <span>Amber Band: ±3σ Position Uncertainty</span>
          </div>
        </div>
      </div>
    }
  `,
})
export class TrackProfile {
  readonly atlas = input<RouteAtlas | null>(null);
  readonly frame = input<LiveTelemetryFrame | null>(null);

  protected readonly Math = Math;
  protected readonly speedTicks = [
    {mps: 0, label: '0'},
    {mps: 12.5, label: '45'},
    {mps: 25, label: '90'},
    {mps: 35, label: '126'},
  ];

  protected xMap(chainageM: number): number {
    const total = this.atlas()?.total_length_m ?? 8600;
    const clamped = Math.max(0, Math.min(total, chainageM));
    return 20 + (clamped / total) * 880;
  }

  protected ySpeed(mps: number): number {
    const clamped = Math.max(0, Math.min(38, mps));
    return 155 - (clamped / 38) * 135;
  }

  protected readonly ceilingPolyline = computed(() => {
    const f = this.frame();
    if (!f || f.trajectory_points.length === 0) return '';
    const baseM = f.trajectory_points[0].chainage_m;
    return f.trajectory_points
      .map((p) => {
        const x = 44 + ((p.chainage_m - baseM) / 1400) * 856;
        const y = this.ySpeed(p.ceiling_speed_mps);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });

  protected readonly targetPolyline = computed(() => {
    const f = this.frame();
    if (!f || f.trajectory_points.length === 0) return '';
    const baseM = f.trajectory_points[0].chainage_m;
    return f.trajectory_points
      .map((p) => {
        const x = 44 + ((p.chainage_m - baseM) / 1400) * 856;
        const y = this.ySpeed(p.target_speed_mps);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });
}
