import {ChangeDetectionStrategy, Component, OnDestroy, OnInit, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {AutoDriverStore} from './autodriver.store';
import {TrackProfile} from './track-profile';
import type {ScenarioId} from '../sim/types';

type NavTab = 'console' | 'scenarios' | 'analytics' | 'architecture';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [MatIconModule, TrackProfile],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  protected readonly store = inject(AutoDriverStore);
  protected readonly activeTab = signal<NavTab>('console');
  protected readonly selectedScenarioId = signal<ScenarioId>('NominalMultiStation');
  protected readonly selectedScenarioDriver = signal<'Baseline' | 'R-Optimised'>('Baseline');

  ngOnInit(): void {
    void this.store.init();
  }

  ngOnDestroy(): void {
    this.store.pause();
  }

  protected setTab(tab: NavTab): void {
    this.activeTab.set(tab);
  }

  protected async runMilestoneQuick(): Promise<void> {
    this.activeTab.set('console');
    await this.store.reset(this.store.frame()?.driver_mode ?? 'Baseline', 42);
    this.store.setSpeedMultiplier(10);
    this.store.play();
  }

  protected async toggleShortenedMa(): Promise<void> {
    const f = this.store.frame();
    if (!f) return;
    const next = f.faults.shortened_ma_m === null ? Math.round(f.est_position_m + 380) : null;
    await this.store.updateFaults({shortened_ma_m: next});
  }

  protected async toggleObstruction(): Promise<void> {
    const f = this.store.frame();
    if (!f) return;
    const next = f.faults.track_obstruction_m === null ? Math.round(f.est_position_m + 185) : null;
    await this.store.updateFaults({track_obstruction_m: next});
  }

  protected async toggleReducedBraking(): Promise<void> {
    const f = this.store.frame();
    if (!f) return;
    const next = f.faults.reduced_braking_factor < 1 ? 1.0 : 0.55;
    await this.store.updateFaults({reduced_braking_factor: next});
  }

  protected async toggleLatency(): Promise<void> {
    const f = this.store.frame();
    if (!f) return;
    const next = f.faults.sensor_latency_ms > 600 ? 20 : 1200;
    await this.store.updateFaults({sensor_latency_ms: next});
  }

  protected onSelectScenario(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as ScenarioId;
    this.selectedScenarioId.set(val);
  }

  protected onSelectScenarioDriver(mode: 'Baseline' | 'R-Optimised'): void {
    this.selectedScenarioDriver.set(mode);
  }
}
