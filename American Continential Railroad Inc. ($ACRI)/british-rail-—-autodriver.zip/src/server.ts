import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import {join} from 'node:path';
import {
  AutoDriverSimulation,
  SCENARIO_CATALOG,
  getResidualModel,
  getRouteAtlas,
  getSyntheticScenes,
  predictResidualBounded,
  runFullComparison,
  runScenarioBatch,
} from './sim/engine';
import type {FaultInjections, ScenarioId} from './sim/types';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

let activeSim = new AutoDriverSimulation('Baseline', 42, false);

app.get('/api/sim/state', (_req, res) => {
  res.json({
    atlas: activeSim.atlas,
    frame: activeSim.getFrame(),
  });
});

app.post('/api/sim/reset', (req, res) => {
  const driverMode = req.body?.driverMode === 'R-Optimised' ? 'R-Optimised' : 'Baseline';
  const seed = Number(req.body?.seed) || 42;
  const requireInitialAuth = Boolean(req.body?.requireInitialAuth);
  activeSim = new AutoDriverSimulation(driverMode, seed, requireInitialAuth);
  res.json({
    atlas: activeSim.atlas,
    frame: activeSim.getFrame(),
  });
});

app.post('/api/sim/step', (req, res) => {
  const steps = Math.max(1, Math.min(200, Number(req.body?.steps) || 1));
  const frame = activeSim.stepN(steps);
  res.json({frame});
});

app.post('/api/sim/mode', (req, res) => {
  const driverMode = req.body?.driverMode === 'R-Optimised' ? 'R-Optimised' : 'Baseline';
  activeSim.setDriverMode(driverMode);
  res.json({frame: activeSim.getFrame()});
});

app.post('/api/sim/faults', (req, res) => {
  const partial = (req.body ?? {}) as Partial<FaultInjections>;
  const frame = activeSim.updateFaults(partial);
  res.json({frame});
});

app.post('/api/sim/restart', (_req, res) => {
  const frame = activeSim.triggerControllerRestart();
  res.json({frame});
});

app.post('/api/sim/recover', (req, res) => {
  const operatorId = typeof req.body?.operatorId === 'string' ? req.body.operatorId : '';
  const result = activeSim.authoriseRecovery(operatorId);
  res.json(result);
});

app.get('/api/scenarios/catalog', (_req, res) => {
  res.json({scenarios: SCENARIO_CATALOG});
});

app.post('/api/scenarios/run', (req, res) => {
  const scenarioId = req.body?.scenarioId as ScenarioId;
  const driverMode = req.body?.driverMode === 'R-Optimised' ? 'R-Optimised' : 'Baseline';
  const seed = Number(req.body?.seed) || 42;
  if (!SCENARIO_CATALOG.some((s) => s.id === scenarioId)) {
    res.status(400).json({error: 'Unknown scenarioId'});
    return;
  }
  const result = runScenarioBatch(scenarioId, driverMode, seed);
  res.json({result});
});

app.post('/api/scenarios/compare', (req, res) => {
  const seed = Number(req.body?.seed) || 42;
  const comparison = runFullComparison(seed);
  res.json(comparison);
});

app.get('/api/artifacts/model', (_req, res) => {
  const model = getResidualModel();
  const parityProbe: [number, number, number, number] = [24.0, 4.5, 580.0, 0.9];
  const inference = predictResidualBounded(model, parityProbe);
  res.json({
    model,
    parityProbe,
    inference,
    scenes: getSyntheticScenes(),
    route: getRouteAtlas(),
  });
});

const ALLOWED_ROOTS = ['rust', 'r_analytics', 'configs', 'fixtures', 'models', 'docs', 'scripts'];

function collectFiles(dirRel: string, out: string[]): void {
  const abs = path.resolve(process.cwd(), dirRel);
  if (!fs.existsSync(abs)) return;
  for (const entry of fs.readdirSync(abs, {withFileTypes: true})) {
    if (entry.name === 'target' || entry.name === 'node_modules') continue;
    const childRel = path.posix.join(dirRel, entry.name);
    if (entry.isDirectory()) {
      collectFiles(childRel, out);
    } else {
      out.push(childRel);
    }
  }
}

app.get('/api/codebase/list', (_req, res) => {
  const files: string[] = [];
  for (const root of ALLOWED_ROOTS) {
    collectFiles(root, files);
  }
  res.json({files: files.sort()});
});

app.get('/api/codebase/file', (req, res) => {
  const rel = typeof req.query['path'] === 'string' ? req.query['path'] : '';
  const normalized = path.posix.normalize(rel).replace(/^\/+/, '');
  const allowed = ALLOWED_ROOTS.some((r) => normalized === r || normalized.startsWith(r + '/'));
  if (!allowed || normalized.includes('..')) {
    res.status(403).json({error: 'Access denied'});
    return;
  }
  const abs = path.resolve(process.cwd(), normalized);
  if (!fs.existsSync(abs) || fs.statSync(abs).isDirectory()) {
    res.status(404).json({error: 'File not found'});
    return;
  }
  res.json({
    path: normalized,
    content: fs.readFileSync(abs, 'utf-8'),
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
