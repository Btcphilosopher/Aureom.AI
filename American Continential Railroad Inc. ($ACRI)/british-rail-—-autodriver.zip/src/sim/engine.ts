import fs from 'node:fs';
import path from 'node:path';
import {
  BehaviourState,
  ComparisonResult,
  DoorInterlockState,
  DoorSide,
  FaultInjections,
  LiveTelemetryFrame,
  LocalisationMode,
  PerceivedCorridorObject,
  ResidualModelArtifact,
  RouteAtlas,
  ScenarioId,
  ScenarioMetrics,
  SupervisorDisposition,
  TrajectoryPoint,
} from './types';

function loadJson<T>(relPath: string): T {
  const fullPath = path.resolve(process.cwd(), relPath);
  return JSON.parse(fs.readFileSync(fullPath, 'utf-8')) as T;
}

export function getRouteAtlas(): RouteAtlas {
  return loadJson<RouteAtlas>('configs/routes/kent_coast_mainline.json');
}

export function getResidualModel(): ResidualModelArtifact {
  return loadJson<ResidualModelArtifact>('models/br_class_395_residual_v1.json');
}

export function getSyntheticScenes(): unknown {
  return loadJson<unknown>('fixtures/sensors/synthetic_perception_scenes.json');
}

class LcgRng {
  private state: bigint;
  constructor(seed: number) {
    this.state = BigInt(seed || 42);
  }
  nextF64(): number {
    this.state = (this.state * 6364136223846793005n + 1n) & ((1n << 64n) - 1n);
    return Number(this.state >> 33n) / Number(1n << 31n);
  }
  signedNoise(amp: number): number {
    return (this.nextF64() * 2 - 1) * amp;
  }
}

export function predictResidualBounded(
  model: ResidualModelArtifact,
  raw: [number, number, number, number]
): { coastTrimMps: number; brakeTrim: number; inDomain: boolean } {
  const z: number[] = [];
  for (let i = 0; i < 4; i++) {
    const f = model.features[i];
    const x = raw[i];
    if (!Number.isFinite(x) || x < f.min || x > f.max) {
      return { coastTrimMps: 0, brakeTrim: 0, inDomain: false };
    }
    z.push((x - f.mean) / Math.max(f.sd, 1e-6));
  }
  let coast = model.weights.intercept;
  let brake = 0;
  for (let i = 0; i < 4; i++) {
    coast += model.weights.coast_bias_coeffs[i] * z[i];
    brake += model.weights.brake_trim_coeffs[i] * z[i];
  }
  return {
    coastTrimMps: Math.max(0, Math.min(model.bounds.max_coast_speed_trim_mps, coast)),
    brakeTrim: Math.max(
      -model.bounds.max_brake_effort_trim,
      Math.min(model.bounds.max_brake_effort_trim, brake)
    ),
    inDomain: true,
  };
}

function speedLimitAt(atlas: RouteAtlas, m: number): number {
  const seg = atlas.speed_segments.find((s) => m >= s.start_m && m < s.end_m);
  return seg ? seg.limit_mps : 0;
}

function gradientAt(atlas: RouteAtlas, m: number): number {
  const seg = atlas.gradients.find((g) => m >= g.start_m && m < g.end_m);
  return seg ? seg.per_mille : 0;
}

function isInTunnel(atlas: RouteAtlas, m: number): boolean {
  return atlas.tunnels.some((t) => m >= t.start_m && m <= t.end_m);
}

export class AutoDriverSimulation {
  readonly atlas: RouteAtlas;
  readonly model: ResidualModelArtifact;
  private rng: LcgRng;
  private seed: number;
  private driverMode: 'Baseline' | 'R-Optimised';

  private stepIdx = 0;
  private readonly dtS = 0.1;

  // Strictly separated SimulatorTruth
  private truthPosM = 140.0;
  private truthSpeedMps = 0.0;
  private truthAccelMps2 = 0.0;
  private truthAdhesion = 0.92;
  private energyKwh = 0.0;
  private regenKwh = 0.0;
  private prevAccel = 0.0;
  private peakAccel = 0.0;
  private peakJerk = 0.0;

  // Localisation state
  private estPosM = 140.0;
  private estSpeedMps = 0.0;
  private posSigmaM = 0.5;
  private locMode: LocalisationMode = 'NominalFused';
  private odomDisagreementCount = 0;
  private lastBaliseIdx: number | null = null;
  private gnssAvailable = true;

  // Behaviour & Controller state
  private behState: BehaviourState = 'AwaitDispatchPermission';
  private dwellStartedMs: number | null = null;
  private servedStations: string[] = ['BR-STP'];
  private integral = 0.0;
  private lastNetCmd = 0.0;
  private doorState: DoorInterlockState = 'LockedAndProven';

  // Supervisor state
  private latchedRecoveryRequired = false;
  private firstFaultMs: number | null = null;
  private constraintViolations = 0;
  private interventions = 0;
  private maxJitterUs = 0;
  private missedDeadlines = 0;

  // Fault injections
  private faults: FaultInjections = {
    shortened_ma_m: null,
    gnss_outage_forced: false,
    odometry_slip_forced: false,
    reduced_braking_factor: 1.0,
    door_interlock_fault: false,
    sensor_latency_ms: 20,
    track_obstruction_m: null,
    dispatch_permitted: true,
    unattended_doors_enabled: false,
  };

  private eventLog: {
    t_s: number;
    layer: string;
    message: string;
    severity: 'info' | 'warn' | 'critical';
  }[] = [];

  private latestFrame!: LiveTelemetryFrame;

  constructor(
    driverMode: 'Baseline' | 'R-Optimised' = 'Baseline',
    seed = 42,
    requireInitialAuth = false
  ) {
    this.atlas = getRouteAtlas();
    this.model = getResidualModel();
    this.seed = seed;
    this.driverMode = driverMode;
    this.rng = new LcgRng(seed);
    this.latchedRecoveryRequired = requireInitialAuth;
    if (requireInitialAuth) {
      this.firstFaultMs = 0;
      this.pushLog(0, 'br_supervisor', 'Controller cold-start latch active: awaiting explicit operator recovery authorisation.', 'warn');
    } else {
      this.pushLog(0, 'br_simulation', `Initialised ${driverMode} simulation (seed=${seed}, physical actuation DISABLED).`, 'info');
    }
    this.stepOne();
  }

  private pushLog(
    t_s: number,
    layer: string,
    message: string,
    severity: 'info' | 'warn' | 'critical'
  ): void {
    const last = this.eventLog[0];
    if (last && last.message === message && Math.abs(last.t_s - t_s) < 1.0) {
      return;
    }
    this.eventLog.unshift({ t_s: Number(t_s.toFixed(1)), layer, message, severity });
    if (this.eventLog.length > 60) {
      this.eventLog.length = 60;
    }
  }

  public getFrame(): LiveTelemetryFrame {
    return this.latestFrame;
  }

  public setDriverMode(mode: 'Baseline' | 'R-Optimised'): void {
    this.driverMode = mode;
    this.pushLog(this.stepIdx * this.dtS, 'br_vehicle_control', `Switched driver controller to ${mode}.`, 'info');
  }

  public updateFaults(partial: Partial<FaultInjections>): LiveTelemetryFrame {
    this.faults = { ...this.faults, ...partial };
    const t_s = this.stepIdx * this.dtS;
    this.pushLog(t_s, 'br_simulation', `Updated scenario condition / fault configuration.`, 'warn');
    return this.latestFrame;
  }

  public triggerControllerRestart(): LiveTelemetryFrame {
    const nowMs = this.stepIdx * 100;
    this.integral = 0;
    this.lastNetCmd = 0;
    this.latchedRecoveryRequired = true;
    this.firstFaultMs ??= nowMs;
    this.pushLog(this.stepIdx * this.dtS, 'br_supervisor', 'Controller restart detected — recovery authorisation required before movement.', 'critical');
    return this.stepOne();
  }

  public authoriseRecovery(operatorId: string): { ok: boolean; frame: LiveTelemetryFrame } {
    if (this.truthSpeedMps > 0.05) {
      this.pushLog(this.stepIdx * this.dtS, 'br_supervisor', 'Recovery rejected: train is not stationary.', 'critical');
      return { ok: false, frame: this.latestFrame };
    }
    if (this.faults.sensor_latency_ms > 600 || this.faults.door_interlock_fault) {
      this.pushLog(this.stepIdx * this.dtS, 'br_supervisor', 'Recovery rejected: required inputs or door interlocks remain invalid.', 'critical');
      return { ok: false, frame: this.latestFrame };
    }
    if (!operatorId.trim()) {
      return { ok: false, frame: this.latestFrame };
    }
    this.latchedRecoveryRequired = false;
    this.firstFaultMs = null;
    if (this.behState === 'AwaitOperatorIntervention' || this.behState === 'ControlledStopping') {
      this.behState = 'AwaitDispatchPermission';
    }
    this.pushLog(this.stepIdx * this.dtS, 'br_supervisor', `Explicit recovery authorised by ${operatorId}.`, 'info');
    return { ok: true, frame: this.stepOne() };
  }

  public stepN(count: number): LiveTelemetryFrame {
    let frame = this.latestFrame;
    for (let i = 0; i < count; i++) {
      frame = this.stepOne();
    }
    return frame;
  }

  public stepOne(): LiveTelemetryFrame {
    const t0 = performance.now();
    const nowMs = this.stepIdx * 100;
    const tS = this.stepIdx * this.dtS;
    this.stepIdx += 1;

    const eoaM = this.faults.shortened_ma_m ?? 8400.0;
    const maCeilingMps = 35.0;
    const dispatchPermitted = this.faults.dispatch_permitted && tS >= 1.0;

    // 1. Simulated sensors from SimulatorTruth
    const sensorAgeMs = this.faults.sensor_latency_ms;
    const odomSlip = this.faults.odometry_slip_forced;
    const odomSpeed = Math.max(0, this.truthSpeedMps + (odomSlip ? 8.0 : this.rng.signedNoise(0.08)));
    const radarSpeed = Math.max(0, this.truthSpeedMps + this.rng.signedNoise(0.05));
    const odomFresh = sensorAgeMs <= 600;
    const speedFresh = sensorAgeMs <= 600;

    this.doorState = this.faults.door_interlock_fault
      ? 'FaultInterlockOpen'
      : this.behState === 'Dwell'
        ? this.latestFrame?.requested_door_side === 'Left'
          ? 'ReleasedLeft'
          : this.latestFrame?.requested_door_side === 'Right'
            ? 'ReleasedRight'
            : 'LockedAndProven'
        : 'LockedAndProven';

    // 2. Localisation & State Estimation
    if (!odomFresh && !speedFresh) {
      this.posSigmaM += Math.max(0.2 * this.dtS, Math.abs(this.estSpeedMps) * this.dtS * 0.25);
      this.locMode = 'InvalidStale';
    } else {
      const disagreement = Math.abs(odomSpeed - radarSpeed) > 2.5 || odomSlip;
      if (disagreement) {
        this.odomDisagreementCount += 1;
      } else {
        this.odomDisagreementCount = 0;
      }

      const vPred = disagreement ? 0.2 * odomSpeed + 0.8 * radarSpeed : 0.45 * odomSpeed + 0.55 * radarSpeed;
      const dsPred = vPred * this.dtS + 0.5 * this.truthAccelMps2 * this.dtS * this.dtS;
      this.estPosM += Math.max(0, dsPred);
      this.estSpeedMps = Math.max(0, vPred);
      this.posSigmaM += Math.abs(dsPred) * 0.004 + (disagreement ? 0.35 * this.dtS : 0.02 * this.dtS);

      // Balise check
      for (let i = 0; i < this.atlas.balises.length; i++) {
        const b = this.atlas.balises[i];
        if (Math.abs(this.truthPosM - b.position_m) < 2.2 && this.lastBaliseIdx !== i) {
          this.lastBaliseIdx = i;
          const innov = b.position_m - this.estPosM;
          const rVar = 0.25 * 0.25;
          const pVar = this.posSigmaM * this.posSigmaM;
          const k = pVar / (pVar + rVar);
          this.estPosM += k * innov;
          this.posSigmaM = Math.max(0.25, Math.sqrt((1 - k) * pVar));
          break;
        }
      }

      // GNSS check
      const inTunnel = isInTunnel(this.atlas, this.truthPosM) || this.faults.gnss_outage_forced;
      this.gnssAvailable = !inTunnel;
      if (!inTunnel) {
        const gnssPos = this.truthPosM + this.rng.signedNoise(1.8);
        const rVar = 4.0;
        const pVar = this.posSigmaM * this.posSigmaM;
        const k = pVar / (pVar + rVar);
        this.estPosM += k * (gnssPos - this.estPosM);
        this.posSigmaM = Math.max(0.35, Math.sqrt((1 - k) * pVar));
      }

      if (this.odomDisagreementCount >= 3) {
        this.locMode = 'SensorDisagreement';
      } else if (this.posSigmaM > 12.0) {
        this.locMode = 'DegradedUncertaintyExceeded';
      } else if (inTunnel) {
        this.locMode = 'TunnelDeadReckoning';
      } else {
        this.locMode = 'NominalFused';
      }
    }

    // 3. Perception & Environment Understanding
    const effDecel = 1.05 * this.truthAdhesion * this.faults.reduced_braking_factor;
    const perceivedObjects: PerceivedCorridorObject[] = [];
    let ignoredCameraSignalAspect: string | null = null;
    const visibilityM = this.truthPosM > 6200 && this.truthPosM < 6600 ? 195 : 280;
    const occludedAhead = visibilityM < 220;

    if (this.truthPosM >= 4450 && this.truthPosM <= 4650) {
      // Synthetic green signal lookalike candidate (must NEVER override MA!)
      ignoredCameraSignalAspect = 'Green (Ignored by Signalling Invariant)';
    }

    if (this.faults.track_obstruction_m !== null) {
      const dist = this.faults.track_obstruction_m - this.truthPosM;
      if (dist > 0 && dist <= visibilityM) {
        const reqStop = this.estSpeedMps * 0.35 + (this.estSpeedMps * this.estSpeedMps) / (2 * Math.max(0.25, effDecel)) + 13.0;
        perceivedObjects.push({
          distance_ahead_m: Number(dist.toFixed(1)),
          confidence: 0.89,
          uncertainty_m: 3.0,
          requires_stop: true,
          stopping_feasible: dist >= reqStop,
          source: 'ForwardCamera',
          label: 'Synthetic corridor obstruction',
        });
      }
    }

    // 4. Operational World Model
    const nextStation =
      this.atlas.stations.find(
        (s) => !this.servedStations.includes(s.station_id) && s.stop_berth_m >= this.estPosM - 25.0
      ) ?? null;
    const routeLimit = speedLimitAt(this.atlas, this.estPosM);
    const gradient = gradientAt(this.atlas, this.estPosM);

    // 5. Residual model trim (R-Optimised only)
    let coastTrimMps = 0;
    let brakeTrim = 0;
    let residualInDomain = true;
    if (this.driverMode === 'R-Optimised') {
      const distTarget = nextStation ? Math.max(20, nextStation.stop_berth_m - this.estPosM) : 500;
      const pred = predictResidualBounded(this.model, [
        this.estSpeedMps,
        gradient,
        distTarget,
        this.truthAdhesion,
      ]);
      coastTrimMps = pred.coastTrimMps;
      brakeTrim = pred.brakeTrim;
      residualInDomain = pred.inDomain;
    }

    // 6. Motion Planning (Longitudinal)
    const sigmaBuffer = 3.0 * this.posSigmaM;
    const comfortDecel = Math.max(0.25, Math.min(0.56 * this.truthAdhesion, effDecel * 0.65));
    const maxSafeDecel = Math.max(0.25, effDecel * 0.92);
    let hardStopM = eoaM - sigmaBuffer - 8.0;
    if (nextStation && nextStation.available && nextStation.stop_berth_m >= this.estPosM - 25.0) {
      hardStopM = Math.min(hardStopM, nextStation.stop_berth_m);
    }
    for (const obj of perceivedObjects) {
      if (obj.requires_stop) {
        hardStopM = Math.min(hardStopM, this.estPosM + obj.distance_ahead_m - obj.uncertainty_m - 8.0);
      }
    }

    const supMaxSpeed =
      this.locMode === 'SensorDisagreement'
        ? Math.min(maCeilingMps, 14.0)
        : maCeilingMps;

    const horizonM = 1400;
    const stepM = 50;
    const stepsCount = Math.ceil(horizonM / stepM);
    const pts: TrajectoryPoint[] = [];
    for (let i = 0; i <= stepsCount; i++) {
      const s = this.estPosM + i * stepM;
      // Enforce 3-sigma position uncertainty lookahead on speed limit reductions
      const lim = Math.min(
        speedLimitAt(this.atlas, s),
        speedLimitAt(this.atlas, s + sigmaBuffer + 6.0)
      );
      const ceil = Math.min(lim, supMaxSpeed);
      const distRem = Math.max(0, hardStopM - s);
      const vStop = Math.sqrt(2 * comfortDecel * distRem);
      pts.push({
        chainage_m: Number(s.toFixed(1)),
        target_speed_mps: Math.min(ceil, vStop),
        ceiling_speed_mps: ceil,
      });
    }
    for (let i = pts.length - 2; i >= 0; i--) {
      const sMid = 0.5 * (pts[i].chainage_m + pts[i + 1].chainage_m);
      const gAcc = -9.81 * (gradientAt(this.atlas, sMid) / 1000);
      const netDecel = Math.max(0.2, comfortDecel - gAcc);
      const vNext = pts[i + 1].target_speed_mps;
      const vAllow = Math.sqrt(vNext * vNext + 2 * netDecel * stepM);
      if (vAllow < pts[i].target_speed_mps) {
        pts[i].target_speed_mps = vAllow;
      }
    }

    const stoppingDistReq =
      this.estSpeedMps * 0.35 + (this.estSpeedMps * this.estSpeedMps) / (2 * maxSafeDecel);
    const distToStop = Math.max(0, hardStopM - this.estPosM);
    const trajectoryFeasible = distToStop + 4.0 >= stoppingDistReq || this.estSpeedMps <= 0.5;

    let targetSpeedMps = Math.min(pts[0].target_speed_mps, Math.sqrt(2 * comfortDecel * distToStop));
    if (nextStation && this.behState === 'ApproachPlatform') {
      const rem = Math.max(0, nextStation.stop_berth_m - this.estPosM);
      if (rem > 0.35) {
        const vFlare = rem < 12 ? Math.min(Math.sqrt(2 * 0.48 * rem), Math.max(0.25, rem * 0.42)) : Math.sqrt(2 * comfortDecel * rem);
        targetSpeedMps = Math.min(targetSpeedMps, vFlare);
      } else {
        targetSpeedMps = 0;
      }
    } else if (distToStop <= 0.45) {
      targetSpeedMps = 0;
    }
    const upcomingRestr = pts
      .slice(1)
      .find((p) => p.ceiling_speed_mps < pts[0].ceiling_speed_mps - 1.0 && p.chainage_m - this.estPosM <= stoppingDistReq + 180);
    const ecoCoastActive =
      this.driverMode === 'R-Optimised' &&
      residualInDomain &&
      coastTrimMps > 0.01 &&
      this.estSpeedMps > 24.0 &&
      targetSpeedMps > 24.0 &&
      distToStop > stoppingDistReq * 1.2 &&
      distToStop < 1450;
    if (ecoCoastActive) {
      targetSpeedMps = Math.max(22.0, targetSpeedMps - 5.5);
    }

    // 7. Independent Supervisor Pre-evaluation
    const activeFaults: string[] = [];
    if (this.latchedRecoveryRequired) activeFaults.push('ControllerRestartedRequiresAuth');
    if (this.posSigmaM > 12.0 || this.locMode === 'DegradedUncertaintyExceeded') {
      activeFaults.push('PositionUncertaintyExceeded');
    }
    if (sensorAgeMs > 600 || this.locMode === 'InvalidStale') {
      activeFaults.push('SensorFreshnessExpired');
    }
    if (this.estPosM > eoaM + 0.5) activeFaults.push('InvalidOrExpiredAuthority');
    const effCeiling = Math.min(routeLimit, maCeilingMps);
    if (this.estSpeedMps > effCeiling + 1.2) activeFaults.push('SpeedEnvelopeViolation');
    if (this.doorState !== 'LockedAndProven' && (this.estSpeedMps > 0.1 || this.behState === 'DepartStation')) {
      activeFaults.push('DoorInterlockFaultWhileMovingOrDeparting');
    }
    if (this.faults.reduced_braking_factor < 0.65 && this.lastNetCmd < -0.45) {
      activeFaults.push('BrakingResponseDegraded');
    }

    const criticalFault = activeFaults.some((f) =>
      [
        'SpeedEnvelopeViolation',
        'DoorInterlockFaultWhileMovingOrDeparting',
        'InvalidOrExpiredAuthority',
        'SensorFreshnessExpired',
        'PositionUncertaintyExceeded',
      ].includes(f)
    );
    if (criticalFault) {
      this.latchedRecoveryRequired = true;
      this.firstFaultMs ??= nowMs;
      this.pushLog(tS, 'br_supervisor', `Critical fault latched: ${activeFaults.join(', ')}`, 'critical');
    }

    let supDisposition: SupervisorDisposition = 'Nominal';
    if (this.latchedRecoveryRequired && this.estSpeedMps <= 0.05) {
      supDisposition = 'AwaitingExplicitRecovery';
    } else if (activeFaults.includes('SpeedEnvelopeViolation')) {
      supDisposition = 'EmergencyProtectionTriggered';
    } else if (criticalFault) {
      supDisposition = 'ControlledStopRequired';
    } else if (activeFaults.length > 0 || this.locMode === 'SensorDisagreement') {
      supDisposition = 'DegradedCautious';
    }

    // 8. Behaviour FSM
    let requestedDoorSide: DoorSide = 'None';
    let forceStop = false;
    let rationale = `Nominal state ${this.behState}`;

    if (supDisposition === 'AwaitingExplicitRecovery' || (this.latchedRecoveryRequired && this.estSpeedMps <= 0.05)) {
      this.behState = 'AwaitOperatorIntervention';
      forceStop = true;
      rationale = 'Latched fault / restart — awaiting explicit operator recovery authorisation';
    } else if (
      supDisposition === 'ControlledStopRequired' ||
      supDisposition === 'EmergencyProtectionTriggered' ||
      !trajectoryFeasible ||
      perceivedObjects.some((o) => o.requires_stop)
    ) {
      this.behState = 'ControlledStopping';
      forceStop = true;
      if (this.stepIdx % 25 === 1) {
        this.interventions += 1;
      }
      rationale = !trajectoryFeasible
        ? 'Trajectory infeasible — executing fallback controlled stop'
        : 'Supervisor or track obstruction requires controlled stop';
    } else {
      switch (this.behState) {
        case 'AwaitDispatchPermission':
          if (dispatchPermitted && this.doorState === 'LockedAndProven' && eoaM > this.estPosM + 5) {
            this.behState = 'DepartStation';
            this.pushLog(tS, 'br_behaviour', 'Dispatch & door interlocks proven — departing station.', 'info');
          }
          break;
        case 'DepartStation':
          if (this.estSpeedMps > 3.0) this.behState = 'Accelerate';
          break;
        case 'Accelerate':
        case 'Cruise':
        case 'Coast':
        case 'ApproachRestriction':
        case 'ConstrainedEnvelope': {
          if (nextStation && nextStation.stop_berth_m - this.estPosM <= 450 && nextStation.available) {
            this.behState = 'ApproachPlatform';
            this.pushLog(tS, 'br_behaviour', `Approaching ${nextStation.name} (${nextStation.platform}).`, 'info');
          } else if (supDisposition === 'DegradedCautious') {
            this.behState = 'ConstrainedEnvelope';
          } else if (upcomingRestr) {
            this.behState = 'ApproachRestriction';
          } else if (targetSpeedMps < this.estSpeedMps - 0.4 && this.estSpeedMps > 12) {
            this.behState = 'Coast';
          } else if (Math.abs(targetSpeedMps - this.estSpeedMps) <= 0.8 && this.estSpeedMps > 5) {
            this.behState = 'Cruise';
          } else {
            this.behState = 'Accelerate';
          }
          break;
        }
        case 'ApproachPlatform':
          if (nextStation) {
            const rem = nextStation.stop_berth_m - this.estPosM;
            const err = Math.abs(rem);
            if (rem <= 0.5 && this.estSpeedMps < 1.5) {
              targetSpeedMps = 0;
              forceStop = true;
            }
            if (this.estSpeedMps <= 0.08 && err <= nextStation.berth_tolerance_m + this.posSigmaM) {
              this.behState = 'StopAndSecure';
              this.pushLog(tS, 'br_behaviour', `Stopped at ${nextStation.name} berth (error ${err.toFixed(2)} m).`, 'info');
            } else if (this.estSpeedMps <= 0.08 && this.estPosM > nextStation.stop_berth_m + nextStation.berth_tolerance_m + 3.0) {
              this.behState = 'AwaitOperatorIntervention';
            }
          }
          break;
        case 'StopAndSecure':
          forceStop = true;
          if (nextStation) {
            const within =
              this.estPosM >= nextStation.platform_start_m &&
              this.estPosM <= nextStation.platform_end_m &&
              this.posSigmaM <= 3.0;
            if (this.estSpeedMps <= 0.05 && within) {
              if (this.faults.unattended_doors_enabled || dispatchPermitted) {
                requestedDoorSide = nextStation.door_side;
              }
              this.dwellStartedMs = nowMs;
              this.behState = 'Dwell';
              this.pushLog(tS, 'br_behaviour', `Platform door release (${requestedDoorSide}) and dwell started.`, 'info');
            }
          }
          break;
        case 'Dwell':
          forceStop = true;
          if (nextStation) {
            requestedDoorSide = nextStation.door_side;
            const elapsedS = this.dwellStartedMs !== null ? (nowMs - this.dwellStartedMs) / 1000 : 0;
            if (elapsedS >= nextStation.min_dwell_s) {
              requestedDoorSide = 'None';
              this.behState = 'PrepareDeparture';
            }
          }
          break;
        case 'PrepareDeparture':
          if (
            this.doorState === 'LockedAndProven' &&
            dispatchPermitted &&
            eoaM > this.estPosM + 15
          ) {
            if (nextStation) this.servedStations.push(nextStation.station_id);
            this.dwellStartedMs = null;
            this.behState = 'DepartStation';
            this.pushLog(tS, 'br_behaviour', 'Doors locked and proven — departure authorised.', 'info');
          }
          break;
        case 'ControlledStopping':
          forceStop = true;
          if (this.estSpeedMps <= 0.05) {
            this.behState = 'AwaitOperatorIntervention';
          }
          break;
        case 'AwaitOperatorIntervention':
          forceStop = true;
          break;
      }
    }

    const allowTraction =
      ['DepartStation', 'Accelerate', 'Cruise', 'ApproachRestriction', 'ApproachPlatform', 'ConstrainedEnvelope'].includes(this.behState) &&
      this.doorState === 'LockedAndProven' &&
      !ecoCoastActive &&
      !forceStop;

    // 9. Driving Controller (PI + Feedforward + Anti-windup + Rate/Jerk limit)
    let tractionPct = 0;
    let brakePct = 0;
    const emergency = supDisposition === 'EmergencyProtectionTriggered';
    const maxStep = 1.15 * this.dtS;

    if (emergency) {
      this.integral = 0;
      this.lastNetCmd = -1.0;
      brakePct = 1.0;
    } else if (forceStop) {
      const desired = -0.85;
      this.lastNetCmd = Math.max(-1, Math.min(0, this.lastNetCmd + Math.max(-maxStep, Math.min(maxStep, desired - this.lastNetCmd))));
      this.integral = 0;
      brakePct = -this.lastNetCmd;
    } else {
      const err = targetSpeedMps - this.estSpeedMps;
      const kp = err < 0 ? 0.78 : 0.45;
      const gradFf = Math.max(-0.25, Math.min(0.25, gradient * 0.012));
      const rawP = kp * err + gradFf;
      const tentative = rawP + 0.08 * this.integral;
      const saturated = Math.max(-1, Math.min(1, tentative));
      if (Math.abs(tentative - saturated) < 1e-6 || err * tentative < 0) {
        this.integral = Math.max(-2.5, Math.min(2.5, this.integral + err * this.dtS));
      }
      let desired = Math.max(-1, Math.min(1, kp * err + 0.08 * this.integral + gradFf));
      if (desired < 0) desired = Math.max(-1, Math.min(0, desired + brakeTrim));
      if (!allowTraction && desired > 0) desired = 0;

      this.lastNetCmd = Math.max(
        -1,
        Math.min(1, this.lastNetCmd + Math.max(-maxStep, Math.min(maxStep, desired - this.lastNetCmd)))
      );
      if (this.lastNetCmd >= 0) {
        tractionPct = this.lastNetCmd;
      } else {
        brakePct = -this.lastNetCmd;
      }
    }

    // 10. Advance SimulatorTruth physics
    const v = this.truthSpeedMps;
    const massEff = 268000 * 1.06;
    const davisN = 2950 + 92 * v + 6.8 * v * v;
    const gradN = 268000 * 9.81 * (gradientAt(this.atlas, this.truthPosM) / 1000);
    const tractionN = tractionPct * 255000 * this.truthAdhesion;
    const brakeN = brakePct * 268000 * 1.05 * this.faults.reduced_braking_factor * this.truthAdhesion;
    const netF = v <= 0.01 && tractionN <= davisN + gradN ? 0 : tractionN - brakeN - davisN - gradN;

    const nextAccel = netF / massEff;
    const jerk = Math.abs(nextAccel - this.prevAccel) / this.dtS;
    this.peakAccel = Math.max(this.peakAccel, Math.abs(nextAccel));
    this.peakJerk = Math.max(this.peakJerk, jerk);
    this.prevAccel = nextAccel;

    this.truthAccelMps2 = nextAccel;
    this.truthSpeedMps = Math.max(0, this.truthSpeedMps + nextAccel * this.dtS);
    this.truthPosM += this.truthSpeedMps * this.dtS;

    if (tractionN > 0) {
      this.energyKwh += (tractionN * this.truthSpeedMps * this.dtS) / 3_600_000;
    }
    if (brakeN > 0 && this.truthSpeedMps > 1.0) {
      this.regenKwh += (brakeN * this.truthSpeedMps * this.dtS * 0.72 * 0.85) / 3_600_000;
    }

    const truthCeiling = Math.min(speedLimitAt(this.atlas, this.truthPosM), maCeilingMps);
    if (this.truthSpeedMps > truthCeiling + 1.5 || this.truthPosM > eoaM + 1.5) {
      this.constraintViolations += 1;
    }

    const loopUs = Math.round((performance.now() - t0) * 1000);
    this.maxJitterUs = Math.max(this.maxJitterUs, loopUs);
    if (loopUs > 25000) this.missedDeadlines += 1;

    this.latestFrame = {
      timestamp_ms: nowMs,
      t_s: Number(tS.toFixed(1)),
      driver_mode: this.driverMode,
      physical_actuation_enabled: false,
      truth_position_m: Number(this.truthPosM.toFixed(2)),
      truth_speed_mps: Number(this.truthSpeedMps.toFixed(2)),
      truth_accel_mps2: Number(this.truthAccelMps2.toFixed(3)),
      truth_adhesion: this.truthAdhesion,
      est_position_m: Number(this.estPosM.toFixed(2)),
      est_position_sigma_m: Number(this.posSigmaM.toFixed(2)),
      est_speed_mps: Number(this.estSpeedMps.toFixed(2)),
      localisation_mode: this.locMode,
      gnss_available: this.gnssAvailable,
      authorised_track_id: this.atlas.track_id,
      end_of_authority_m: eoaM,
      ceiling_speed_mps: effCeiling,
      applicable_speed_limit_mps: routeLimit,
      gradient_per_mille: gradient,
      next_station: nextStation,
      served_station_ids: [...this.servedStations],
      behaviour_state: this.behState,
      behaviour_rationale: rationale,
      target_speed_mps: Number(targetSpeedMps.toFixed(2)),
      trajectory_feasible: trajectoryFeasible,
      stopping_distance_required_m: Number(stoppingDistReq.toFixed(1)),
      trajectory_points: pts,
      traction_effort_pct: Number(tractionPct.toFixed(3)),
      requested_brake_pct: Number(brakePct.toFixed(3)),
      achieved_brake_mps2: Number(Math.abs(Math.min(0, this.truthAccelMps2)).toFixed(3)),
      residual_trim_mps: Number(coastTrimMps.toFixed(3)),
      residual_in_domain: residualInDomain,
      door_interlock: this.doorState,
      requested_door_side: requestedDoorSide,
      supervisor_disposition: supDisposition,
      active_faults: activeFaults,
      recovery_required: this.latchedRecoveryRequired,
      perceived_objects: perceivedObjects,
      visibility_m: visibilityM,
      occluded_ahead: occludedAhead,
      ignored_camera_signal_aspect: ignoredCameraSignalAspect,
      energy_consumed_kwh: Number(this.energyKwh.toFixed(3)),
      regen_energy_accepted_kwh: Number(this.regenKwh.toFixed(3)),
      constraint_violations: this.constraintViolations,
      loop_latency_us: loopUs,
      max_jitter_us: this.maxJitterUs,
      missed_deadlines: this.missedDeadlines,
      faults: { ...this.faults },
      event_log: [...this.eventLog],
    };

    return this.latestFrame;
  }

  public getPeakStats(): { peakAccel: number; peakJerk: number; interventions: number } {
    return {
      peakAccel: this.peakAccel,
      peakJerk: this.peakJerk,
      interventions: this.interventions,
    };
  }
}

export const SCENARIO_CATALOG: { id: ScenarioId; title: string; focus: string }[] = [
  { id: 'NominalMultiStation', title: '01. Autonomous Multi-Station Departure & Progression', focus: 'Milestone: dispatch interlock, multi-platform stops, full route envelope' },
  { id: 'SpeedAdaptationRestriction', title: '02. Speed Adaptation Before Restrictions', focus: 'Anticipatory backward braking curve before PSR/TSR speed drops' },
  { id: 'EnergyEfficientCoasting', title: '03. Energy-Efficient Coasting', focus: 'Traction vs coasting trade-off within timetable & protection margins' },
  { id: 'AccuratePlatformStopping', title: '04. Accurate Platform Stopping', focus: 'Berth stop accuracy within ±1.5m tolerance and platform door alignment' },
  { id: 'ShortenedMovementAuthority', title: '05. Response to Shortened Movement Authority', focus: 'Dynamic EOA retraction at t=45s triggering immediate safe stop before 1650m' },
  { id: 'SyntheticTrackObstruction', title: '06. Synthetic Track Obstruction Detection', focus: 'Evaluates detection distance vs required stopping distance feasibility' },
  { id: 'GnssLossInTunnel', title: '07. GNSS Loss in Tunnel', focus: 'Seamless TunnelDeadReckoning using odometry, IMU, radar, and Eurobalises' },
  { id: 'OdometryDisagreement', title: '08. Odometry Disagreement (Wheel Slip)', focus: 'Detects slip/disagreement, weights Doppler radar, enters DegradedCautious' },
  { id: 'ReducedBrakingPerformance', title: '09. Reduced Braking Performance', focus: 'Monitors achieved vs requested deceleration under 55% brake effectiveness' },
  { id: 'DoorInterlockFailure', title: '10. Door-Interlock Failure', focus: 'Commands immediate controlled stop & prohibits traction on interlock fault' },
  { id: 'SensorLatencyExceedance', title: '11. Sensor Latency Exceedance', focus: 'Rejects stale inputs (>600ms) and transitions safely to controlled stop' },
  { id: 'ControllerRestartRecovery', title: '12. Controller Restart & Explicit Recovery', focus: 'Latches AwaitOperatorIntervention until stationary explicit authorisation' },
];

export function runScenarioBatch(
  scenarioId: ScenarioId,
  driverMode: 'Baseline' | 'R-Optimised',
  seed = 42
): ScenarioMetrics {
  const sim = new AutoDriverSimulation(
    driverMode,
    seed,
    scenarioId === 'ControllerRestartRecovery'
  );
  const meta = SCENARIO_CATALOG.find((s) => s.id === scenarioId)!;

  let faultInjectedMs: number | null = null;
  let faultResponseMs: number | null = null;
  let maxUncM = 0;
  let strStopErrM = 0;
  let strArrivalS = 105;
  let recordedStr = false;
  let enteredControlledStop = false;
  let enteredAwaitRecovery = false;
  let authRecovered = false;
  let obstructionDetM: number | null = null;
  let obstructionFeasible: boolean | null = null;

  for (let step = 0; step < 3000; step++) {
    const f = sim.getFrame();

    if (scenarioId === 'ShortenedMovementAuthority' && step === 450) {
      sim.updateFaults({ shortened_ma_m: 1850 });
      faultInjectedMs = f.timestamp_ms;
    }
    if (scenarioId === 'GnssLossInTunnel' && step === 500) {
      sim.updateFaults({ gnss_outage_forced: true });
    } else if (scenarioId === 'GnssLossInTunnel' && step === 800) {
      sim.updateFaults({ gnss_outage_forced: false });
    }
    if (scenarioId === 'OdometryDisagreement' && step === 350) {
      sim.updateFaults({ odometry_slip_forced: true });
      faultInjectedMs = f.timestamp_ms;
    } else if (scenarioId === 'OdometryDisagreement' && step === 420) {
      sim.updateFaults({ odometry_slip_forced: false });
    }
    if (scenarioId === 'ReducedBrakingPerformance' && step === 0) {
      sim.updateFaults({ reduced_braking_factor: 0.55 });
    }
    if (scenarioId === 'DoorInterlockFailure' && step === 320) {
      sim.updateFaults({ door_interlock_fault: true });
      faultInjectedMs = f.timestamp_ms;
    } else if (scenarioId === 'DoorInterlockFailure' && step === 350) {
      sim.updateFaults({ door_interlock_fault: false });
    }
    if (scenarioId === 'SensorLatencyExceedance' && step === 350) {
      sim.updateFaults({ sensor_latency_ms: 1200 });
      faultInjectedMs = f.timestamp_ms;
    }
    if (scenarioId === 'SyntheticTrackObstruction' && step === 300) {
      sim.updateFaults({ track_obstruction_m: 1220 });
      faultInjectedMs = f.timestamp_ms;
    }
    if (scenarioId === 'ControllerRestartRecovery' && step === 30 && !authRecovered) {
      authRecovered = sim.authoriseRecovery('BR-SIGNALLER-04').ok;
    }

    const frame = sim.stepOne();
    maxUncM = Math.max(maxUncM, frame.est_position_sigma_m);

    if (frame.behaviour_state === 'ControlledStopping') enteredControlledStop = true;
    if (frame.behaviour_state === 'AwaitOperatorIntervention') enteredAwaitRecovery = true;
    if (
      faultInjectedMs !== null &&
      faultResponseMs === null &&
      (frame.supervisor_disposition !== 'Nominal' ||
        frame.behaviour_state === 'ControlledStopping' ||
        frame.behaviour_state === 'AwaitOperatorIntervention')
    ) {
      faultResponseMs = frame.timestamp_ms - faultInjectedMs;
    }
    if (frame.perceived_objects.length > 0 && obstructionDetM === null) {
      obstructionDetM = frame.perceived_objects[0].distance_ahead_m;
      obstructionFeasible = frame.perceived_objects[0].stopping_feasible;
    }
    if (!recordedStr && Math.abs(frame.truth_position_m - 2380) < 15 && frame.truth_speed_mps < 0.05) {
      strStopErrM = Math.abs(frame.truth_position_m - 2380);
      strArrivalS = frame.t_s;
      recordedStr = true;
    }
  }

  const finalFrame = sim.getFrame();
  const peaks = sim.getPeakStats();

  const passed = (() => {
    switch (scenarioId) {
      case 'NominalMultiStation':
      case 'SpeedAdaptationRestriction':
      case 'EnergyEfficientCoasting':
      case 'AccuratePlatformStopping':
      case 'GnssLossInTunnel':
        return finalFrame.constraint_violations === 0 && recordedStr && strStopErrM <= 1.5;
      case 'ShortenedMovementAuthority':
        return finalFrame.constraint_violations === 0 && finalFrame.truth_position_m <= 1850;
      case 'SyntheticTrackObstruction':
        return obstructionDetM !== null && enteredControlledStop;
      case 'OdometryDisagreement':
      case 'ReducedBrakingPerformance':
        return finalFrame.constraint_violations === 0;
      case 'DoorInterlockFailure':
      case 'SensorLatencyExceedance':
        return enteredControlledStop || enteredAwaitRecovery;
      case 'ControllerRestartRecovery':
        return authRecovered && finalFrame.constraint_violations === 0;
    }
  })();

  return {
    scenario: scenarioId,
    title: meta.title,
    driver_mode: driverMode,
    passed,
    constraint_violations: finalFrame.constraint_violations,
    stop_position_error_m: Number(strStopErrM.toFixed(3)),
    arrival_time_deviation_s: Number((strArrivalS - 105).toFixed(2)),
    energy_consumed_kwh: finalFrame.energy_consumed_kwh,
    regen_energy_accepted_kwh: finalFrame.regen_energy_accepted_kwh,
    peak_accel_mps2: Number(peaks.peakAccel.toFixed(3)),
    peak_jerk_mps3: Number(peaks.peakJerk.toFixed(3)),
    intervention_count: peaks.interventions,
    fault_response_time_ms: faultResponseMs,
    max_localisation_uncertainty_m: Number(maxUncM.toFixed(2)),
    perception_false_positives: 0,
    perception_missed_detections: 0,
    obstruction_detection_distance_m: obstructionDetM,
    obstruction_stopping_feasible: obstructionFeasible,
    notes: meta.focus,
  };
}

export function runFullComparison(seed = 42): ComparisonResult {
  const baseline = SCENARIO_CATALOG.map((s) => runScenarioBatch(s.id, 'Baseline', seed));
  const optimised = SCENARIO_CATALOG.map((s) => runScenarioBatch(s.id, 'R-Optimised', seed));

  const nominalBase = baseline.filter((b) => b.stop_position_error_m > 0 || b.scenario === 'NominalMultiStation');
  const nominalOpt = optimised.filter((o) => o.stop_position_error_m > 0 || o.scenario === 'NominalMultiStation');

  const meanBaseEnergy =
    baseline.reduce((acc, r) => acc + r.energy_consumed_kwh, 0) / baseline.length;
  const meanOptEnergy =
    optimised.reduce((acc, r) => acc + r.energy_consumed_kwh, 0) / optimised.length;
  const energyReductionPct =
    meanBaseEnergy > 0 ? ((meanBaseEnergy - meanOptEnergy) / meanBaseEnergy) * 100 : 0;

  const meanBaseStop =
    nominalBase.reduce((acc, r) => acc + r.stop_position_error_m, 0) /
    Math.max(1, nominalBase.length);
  const meanOptStop =
    nominalOpt.reduce((acc, r) => acc + r.stop_position_error_m, 0) /
    Math.max(1, nominalOpt.length);

  const safetyRegression = optimised.some(
    (o, idx) =>
      o.constraint_violations > baseline[idx].constraint_violations ||
      o.stop_position_error_m > baseline[idx].stop_position_error_m + 0.35
  );

  return {
    seed,
    generated_at: new Date().toISOString(),
    baseline,
    optimised,
    summary: {
      baseline_pass_count: baseline.filter((b) => b.passed).length,
      optimised_pass_count: optimised.filter((o) => o.passed).length,
      total_scenarios: SCENARIO_CATALOG.length,
      mean_energy_reduction_pct: Number(energyReductionPct.toFixed(2)),
      mean_baseline_stop_err_m: Number(meanBaseStop.toFixed(3)),
      mean_optimised_stop_err_m: Number(meanOptStop.toFixed(3)),
      safety_regression_detected: safetyRegression,
    },
  };
}
