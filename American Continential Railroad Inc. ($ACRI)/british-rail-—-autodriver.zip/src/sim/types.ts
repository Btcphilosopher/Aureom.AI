export type BehaviourState =
  | 'AwaitDispatchPermission'
  | 'DepartStation'
  | 'Accelerate'
  | 'Cruise'
  | 'Coast'
  | 'ApproachRestriction'
  | 'ConstrainedEnvelope'
  | 'ApproachPlatform'
  | 'StopAndSecure'
  | 'Dwell'
  | 'PrepareDeparture'
  | 'ControlledStopping'
  | 'AwaitOperatorIntervention';

export type LocalisationMode =
  | 'NominalFused'
  | 'TunnelDeadReckoning'
  | 'DegradedUncertaintyExceeded'
  | 'SensorDisagreement'
  | 'InvalidStale';

export type SupervisorDisposition =
  | 'Nominal'
  | 'DegradedCautious'
  | 'ControlledStopRequired'
  | 'EmergencyProtectionTriggered'
  | 'AwaitingExplicitRecovery';

export type DoorInterlockState =
  | 'LockedAndProven'
  | 'ReleasedLeft'
  | 'ReleasedRight'
  | 'FaultInterlockOpen';

export type DoorSide = 'Left' | 'Right' | 'None';

export type ScenarioId =
  | 'NominalMultiStation'
  | 'SpeedAdaptationRestriction'
  | 'EnergyEfficientCoasting'
  | 'AccuratePlatformStopping'
  | 'ShortenedMovementAuthority'
  | 'SyntheticTrackObstruction'
  | 'GnssLossInTunnel'
  | 'OdometryDisagreement'
  | 'ReducedBrakingPerformance'
  | 'DoorInterlockFailure'
  | 'SensorLatencyExceedance'
  | 'ControllerRestartRecovery';

export interface SpeedSegment {
  start_m: number;
  end_m: number;
  limit_mps: number;
  reason: string;
}

export interface GradientSegment {
  start_m: number;
  end_m: number;
  per_mille: number;
}

export interface TunnelZone {
  id: string;
  name: string;
  start_m: number;
  end_m: number;
  gnss_available: boolean;
}

export interface StationStop {
  station_id: string;
  name: string;
  platform: string;
  stop_berth_m: number;
  platform_start_m: number;
  platform_end_m: number;
  door_side: DoorSide;
  scheduled_arrival_s: number;
  scheduled_departure_s: number;
  min_dwell_s: number;
  available: boolean;
  berth_tolerance_m: number;
}

export interface BaliseEntry {
  balise_id: string;
  position_m: number;
  track_id: string;
}

export interface RouteAtlas {
  route_id: string;
  route_name: string;
  total_length_m: number;
  track_id: string;
  speed_segments: SpeedSegment[];
  gradients: GradientSegment[];
  tunnels: TunnelZone[];
  stations: StationStop[];
  balises: BaliseEntry[];
}

export interface ResidualModelArtifact {
  model_id: string;
  version: string;
  trained_by: string;
  training_protocol: {
    split_strategy: string;
    leakage_checks: string[];
  };
  target: string;
  features: {
    name: string;
    mean: number;
    sd: number;
    min: number;
    max: number;
  }[];
  weights: {
    intercept: number;
    coast_bias_coeffs: number[];
    brake_trim_coeffs: number[];
  };
  bounds: {
    max_coast_speed_trim_mps: number;
    max_brake_effort_trim: number;
    fallback_on_out_of_domain: string;
  };
  uncertainty: {
    residual_sigma_mps2: number;
    validation_r2: number;
    validation_rmse_mps2: number;
  };
  validation_summary: {
    train_runs: number;
    validation_runs: number;
    baseline_energy_kwh_mean: number;
    optimised_energy_kwh_mean: number;
    energy_reduction_pct: number;
    baseline_stop_error_m_mean: number;
    optimised_stop_error_m_mean: number;
    constraint_violations_validation: number;
  };
}

export interface FaultInjections {
  shortened_ma_m: number | null;
  gnss_outage_forced: boolean;
  odometry_slip_forced: boolean;
  reduced_braking_factor: number; // 1.0 nominal, 0.55 degraded
  door_interlock_fault: boolean;
  sensor_latency_ms: number;
  track_obstruction_m: number | null;
  dispatch_permitted: boolean;
  unattended_doors_enabled: boolean;
}

export interface TrajectoryPoint {
  chainage_m: number;
  target_speed_mps: number;
  ceiling_speed_mps: number;
}

export interface PerceivedCorridorObject {
  distance_ahead_m: number;
  confidence: number;
  uncertainty_m: number;
  requires_stop: boolean;
  stopping_feasible: boolean;
  source: string;
  label: string;
}

export interface LiveTelemetryFrame {
  timestamp_ms: number;
  t_s: number;
  driver_mode: 'Baseline' | 'R-Optimised';
  physical_actuation_enabled: boolean;
  truth_position_m: number;
  truth_speed_mps: number;
  truth_accel_mps2: number;
  truth_adhesion: number;
  est_position_m: number;
  est_position_sigma_m: number;
  est_speed_mps: number;
  localisation_mode: LocalisationMode;
  gnss_available: boolean;
  authorised_track_id: string;
  end_of_authority_m: number;
  ceiling_speed_mps: number;
  applicable_speed_limit_mps: number;
  gradient_per_mille: number;
  next_station: StationStop | null;
  served_station_ids: string[];
  behaviour_state: BehaviourState;
  behaviour_rationale: string;
  target_speed_mps: number;
  trajectory_feasible: boolean;
  stopping_distance_required_m: number;
  trajectory_points: TrajectoryPoint[];
  traction_effort_pct: number;
  requested_brake_pct: number;
  achieved_brake_mps2: number;
  residual_trim_mps: number;
  residual_in_domain: boolean;
  door_interlock: DoorInterlockState;
  requested_door_side: DoorSide;
  supervisor_disposition: SupervisorDisposition;
  active_faults: string[];
  recovery_required: boolean;
  perceived_objects: PerceivedCorridorObject[];
  visibility_m: number;
  occluded_ahead: boolean;
  ignored_camera_signal_aspect: string | null;
  energy_consumed_kwh: number;
  regen_energy_accepted_kwh: number;
  constraint_violations: number;
  loop_latency_us: number;
  max_jitter_us: number;
  missed_deadlines: number;
  faults: FaultInjections;
  event_log: { t_s: number; layer: string; message: string; severity: 'info' | 'warn' | 'critical' }[];
}

export interface ScenarioMetrics {
  scenario: ScenarioId;
  title: string;
  driver_mode: 'Baseline' | 'R-Optimised';
  passed: boolean;
  constraint_violations: number;
  stop_position_error_m: number;
  arrival_time_deviation_s: number;
  energy_consumed_kwh: number;
  regen_energy_accepted_kwh: number;
  peak_accel_mps2: number;
  peak_jerk_mps3: number;
  intervention_count: number;
  fault_response_time_ms: number | null;
  max_localisation_uncertainty_m: number;
  perception_false_positives: number;
  perception_missed_detections: number;
  obstruction_detection_distance_m: number | null;
  obstruction_stopping_feasible: boolean | null;
  notes: string;
}

export interface ComparisonResult {
  seed: number;
  generated_at: string;
  baseline: ScenarioMetrics[];
  optimised: ScenarioMetrics[];
  summary: {
    baseline_pass_count: number;
    optimised_pass_count: number;
    total_scenarios: number;
    mean_energy_reduction_pct: number;
    mean_baseline_stop_err_m: number;
    mean_optimised_stop_err_m: number;
    safety_regression_detected: boolean;
  };
}
