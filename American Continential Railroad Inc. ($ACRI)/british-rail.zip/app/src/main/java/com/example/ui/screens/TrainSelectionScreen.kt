package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.JourneyOption
import com.example.data.model.ServiceFare
import com.example.ui.TerminalUiState
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrSchematicLine
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

/**
 * Screen 2: Train selection screen.
 * Closely matches the attached British Rail reference mockup.
 */
@Composable
fun TrainSelectionScreen(
    state: TerminalUiState,
    onSelectJourney: (JourneyOption, ServiceFare?) -> Unit,
    onSelectFare: (ServiceFare) -> Unit,
    onContinueToPayment: () -> Unit,
    onChangeJourney: () -> Unit,
    onSwapStations: () -> Unit,
    onSingleReturnToggle: (Boolean) -> Unit,
    onStepFreeClick: () -> Unit,
    onNeedHelpClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val isWelsh = lang == AppLanguage.CYMRAEG

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(BritishRailWhite)
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("train_selection_screen")
    ) {
        // ================= LEFT COLUMN: "Your journey" =================
        Column(
            modifier = Modifier
                .width(280.dp)
                .fillMaxHeight()
                .padding(end = 12.dp)
        ) {
            // Heading: "Your journey"
            Text(
                text = if (isWelsh) "Eich taith" else "Your journey",
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = BritishRailBlack
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Boxed table: From / To with vertical swap button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, BritishRailBlack)
                    .background(BritishRailWhite)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // "From" row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isWelsh) "O" else "From",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BritishRailBlack,
                            modifier = Modifier.width(42.dp)
                        )
                        Text(
                            text = state.fromStation.name,
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = BritishRailBlack,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.5.dp)
                            .background(BritishRailBlack)
                    )

                    // "To" row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isWelsh) "I" else "To",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BritishRailBlack,
                            modifier = Modifier.width(42.dp)
                        )
                        Text(
                            text = state.toStation.name,
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = BritishRailBlack,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Vertical swap stations button on the right
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 6.dp)
                        .size(36.dp)
                        .border(1.5.dp, BritishRailBlack)
                        .background(BritishRailWhite)
                        .clickable { onSwapStations() }
                        .testTag("swap_stations_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapVert,
                        contentDescription = "Swap Origin and Destination",
                        tint = BritishRailBlack,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Box with Date and Depart
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, BritishRailBlack)
                    .background(BritishRailWhite)
            ) {
                // Date row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = BritishRailBlack,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isWelsh) "Dyddiad" else "Date",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BritishRailBlack,
                        modifier = Modifier.width(50.dp)
                    )
                    Text(
                        text = state.travelDate,
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BritishRailBlack
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(RailGreyBorder)
                )

                // Depart row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = BritishRailBlack,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isWelsh) "Gadael" else "Depart",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BritishRailBlack,
                        modifier = Modifier.width(50.dp)
                    )
                    Text(
                        text = state.departTimeText,
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BritishRailBlack
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Single / Return toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
            ) {
                // Single button
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(if (!state.isReturn) BritishRailRed else BritishRailWhite)
                        .border(1.5.dp, if (!state.isReturn) BritishRailRed else BritishRailBlack)
                        .clickable { onSingleReturnToggle(false) }
                        .testTag("toggle_single_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isWelsh) "Sengl" else "Single",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (!state.isReturn) BritishRailWhite else BritishRailBlack
                    )
                }

                // Return button
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(if (state.isReturn) BritishRailRed else BritishRailWhite)
                        .border(1.5.dp, if (state.isReturn) BritishRailRed else BritishRailBlack)
                        .clickable { onSingleReturnToggle(true) }
                        .testTag("toggle_return_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isWelsh) "Dychwelyd" else "Return",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (state.isReturn) BritishRailWhite else BritishRailBlack
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Box with Person icon: "1 adult • No railcard"
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, BritishRailBlack)
                    .background(BritishRailWhite)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = BritishRailBlack,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = state.passengers.summary(lang),
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = BritishRailBlack
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Button: "Change journey"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .border(1.5.dp, BritishRailBlack)
                    .background(BritishRailWhite)
                    .clickable { onChangeJourney() }
                    .testTag("change_journey_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isWelsh) "Newid taith" else "Change journey",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = BritishRailBlack
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Secondary links at bottom of left column
            // "♿ Step-free preferences >"
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, BritishRailBlack)
                    .background(BritishRailWhite)
                    .clickable { onStepFreeClick() }
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .testTag("step_free_pref_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Accessible,
                        contentDescription = null,
                        tint = BritishRailBlack,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isWelsh) "Dewisiadau di-risiau" else "Step-free preferences",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BritishRailBlack
                    )
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = BritishRailBlack,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // "❓ Need help? >"
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, BritishRailBlack)
                    .background(BritishRailWhite)
                    .clickable { onNeedHelpClick() }
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .testTag("need_help_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                        contentDescription = null,
                        tint = BritishRailBlack,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isWelsh) "Angen cymorth?" else "Need help?",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BritishRailBlack
                    )
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = BritishRailBlack,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Vertical divider separating Left column from Right section
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(BritishRailBlack)
        )

        // ================= RIGHT SECTION: "Choose your train" =================
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(start = 14.dp)
        ) {
            // Heading & Subtitle
            Text(
                text = if (isWelsh) "Dewiswch eich trên" else "Choose your train",
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp,
                color = BritishRailBlack
            )
            Text(
                text = if (isWelsh) "Gwasanaethau a phrisiau darluniadol" else "Illustrative services and fares",
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Normal,
                fontSize = 14.sp,
                color = RailGreySubtext
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Train Result Rows List
            if (state.isLoadingJourneys) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BritishRailRed)
                }
            } else if (state.availableJourneys.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .border(2.dp, BritishRailBlack)
                        .background(RailGreyPanel)
                        .padding(24.dp)
                        .testTag("no_services_empty_state"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isWelsh) "Dim gwasanaethau ar gael" else "No train services found",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            color = BritishRailBlack
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "No scheduled services match ${state.fromStation.name} → ${state.toStation.name} (${state.departTimeText}) on ${state.travelDate}.",
                            fontSize = 14.sp,
                            color = RailGreySubtext
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        BrButton(
                            text = if (isWelsh) "Newid manylion y daith →" else "Change journey details →",
                            onClick = onChangeJourney,
                            style = BrButtonStyle.PRIMARY_RED,
                            testTag = "no_service_change_journey_button"
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(state.availableJourneys) { journey ->
                        val isSelected = state.selectedJourney?.id == journey.id
                        val displayFare = if (isSelected && state.selectedFare != null && journey.fares.any { it.id == state.selectedFare.id }) {
                            state.selectedFare
                        } else {
                            journey.fares.firstOrNull { it.isAvailable } ?: journey.fares.firstOrNull()
                        } ?: return@items

                        TrainRowItem(
                            journey = journey,
                            displayFare = displayFare,
                            selectedFareId = state.selectedFare?.id,
                            isSelected = isSelected,
                            language = lang,
                            onSelect = { onSelectJourney(journey, displayFare) },
                            onSelectFare = onSelectFare
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ================= PERSISTENT BOTTOM SUMMARY BOX =================
            val selJourney = state.selectedJourney
            val selFare = state.selectedFare
            val totalFormatted = state.fareBreakdown?.formattedTotal
                ?: selFare?.formattedPrice
                ?: "£0.00"

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min)
                    .background(RailGreyPanel)
                    .border(2.dp, BritishRailBlack)
                    .testTag("persistent_selection_summary"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left summary section
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = if (isWelsh) "Eich dewis" else "Your selection",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = BritishRailBlack
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    if (selJourney != null && selFare != null) {
                        Text(
                            text = "${selJourney.departureTime} ${selJourney.origin.name} → ${selJourney.destination.name}",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = "${selFare.ticketType.getLocalizedName(lang)} • ${selFare.travelClass.getLocalizedName(lang)}",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = if (selFare.ticketType.isTrainSpecific) {
                                if (isWelsh) "Tocyn trên-benodol" else "Train-specific ticket"
                            } else {
                                if (isWelsh) "Tocyn hyblyg" else "Flexible ticket"
                            },
                            fontFamily = RailAlphabetFontFamily,
                            fontSize = 12.sp,
                            color = RailGreySubtext
                        )
                    } else {
                        Text(
                            text = if (isWelsh) "Dewiswch trên uchod" else "Please select a train above",
                            fontFamily = RailAlphabetFontFamily,
                            fontSize = 14.sp,
                            color = RailGreySubtext
                        )
                    }
                }

                // Vertical divider
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(BritishRailBlack)
                )

                // Right total and continue section
                Row(
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.padding(end = 16.dp)
                    ) {
                        Text(
                            text = if (isWelsh) "Cyfanswm" else "Total",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = totalFormatted,
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            color = BritishRailBlack
                        )
                    }

                    // Continue to payment -> button
                    BrButton(
                        text = if (isWelsh) "Parhau i dalu →" else "Continue to payment →",
                        onClick = onContinueToPayment,
                        style = BrButtonStyle.PRIMARY_RED,
                        enabled = selJourney != null && selFare != null,
                        height = 46.dp,
                        testTag = "continue_to_payment_button"
                    )
                }
            }
        }
    }
}

/**
 * Individual Train Result Row matching reference layout.
 */
@Composable
fun TrainRowItem(
    journey: JourneyOption,
    displayFare: ServiceFare,
    selectedFareId: String?,
    isSelected: Boolean,
    language: AppLanguage,
    onSelect: () -> Unit,
    onSelectFare: (ServiceFare) -> Unit
) {
    val borderColor = if (isSelected) BritishRailRed else BritishRailBlack
    val borderWidth = if (isSelected) 2.5.dp else 1.5.dp
    val isWelsh = language == AppLanguage.CYMRAEG
    val hasSoldOutFare = journey.fares.any { !it.isAvailable }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(borderWidth, borderColor)
            .background(BritishRailWhite)
            .clickable { onSelect() }
            .testTag("train_row_${journey.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Service Times & Route Schematic
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                // Times: 13:45 -> 15:52
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${journey.departureTime} → ${journey.arrivalTime}",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = BritishRailBlack
                    )
                    if (journey.isOvernight) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .border(1.dp, BritishRailBlack)
                                .background(RailGreyPanel)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "+1 day • Overnight",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = BritishRailBlack
                            )
                        }
                    }
                    if (hasSoldOutFare) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .border(1.dp, RailGreyBorder)
                                .background(RailGreyPanel)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Advance sold out",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = RailGreySubtext
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Duration and route note: "2h 07m • Direct"
                Text(
                    text = "${journey.durationStr} • ${journey.routeSummary}",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = BritishRailBlack
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Schematic Red Track Line: Sheffield O=====O London St Pancras
                val interchangeName = if (journey.changes > 0) {
                    journey.legs.getOrNull(0)?.destinationStation
                } else null

                BrSchematicLine(
                    originName = journey.origin.name,
                    destinationName = journey.destination.name,
                    interchangeName = interchangeName,
                    modifier = Modifier.fillMaxWidth(0.95f)
                )
            }

            // Vertical divider
            Box(
                modifier = Modifier
                    .width(1.5.dp)
                    .fillMaxHeight()
                    .background(BritishRailBlack)
            )

            // Class & Price Section
            Column(
                modifier = Modifier
                    .width(140.dp)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = displayFare.travelClass.getLocalizedName(language),
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = BritishRailBlack
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = displayFare.formattedPrice,
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = BritishRailBlack
                )
            }

            // Action Button: [ Selected ] or [ Select ]
            Box(
                modifier = Modifier
                    .padding(end = 14.dp)
            ) {
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .height(38.dp)
                            .background(BritishRailRed)
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isWelsh) "Dewiswyd" else "Selected",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = BritishRailWhite
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .height(38.dp)
                            .background(BritishRailBlack)
                            .clickable { onSelect() }
                            .padding(horizontal = 18.dp)
                            .testTag("select_train_${journey.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isWelsh) "Dewis" else "Select",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = BritishRailWhite
                        )
                    }
                }
            }
        }

        // Expanded Fare / Class Strip when train is selected
        if (isSelected && journey.fares.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(RailGreyBorder)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RailGreyPanel)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isWelsh) "TOCYN:" else "FARE:",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = BritishRailBlack
                )
                journey.fares.forEach { fareOption ->
                    val isFareSelected = fareOption.id == selectedFareId
                    val chipBg = when {
                        !fareOption.isAvailable -> Color(0xFFE0E0E0)
                        isFareSelected -> BritishRailRed
                        else -> BritishRailWhite
                    }
                    val chipBorder = when {
                        !fareOption.isAvailable -> RailGreyBorder
                        isFareSelected -> BritishRailRed
                        else -> BritishRailBlack
                    }
                    val chipTextColor = when {
                        !fareOption.isAvailable -> RailGreySubtext
                        isFareSelected -> BritishRailWhite
                        else -> BritishRailBlack
                    }
                    Box(
                        modifier = Modifier
                            .border(1.dp, chipBorder)
                            .background(chipBg)
                            .clickable(enabled = fareOption.isAvailable) { onSelectFare(fareOption) }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                            .testTag("fare_chip_${fareOption.id}")
                    ) {
                        Text(
                            text = if (fareOption.isAvailable) {
                                "${fareOption.ticketType.getLocalizedName(language)} • ${fareOption.travelClass.getLocalizedName(language)} (${fareOption.formattedPrice})"
                            } else {
                                "${fareOption.ticketType.getLocalizedName(language)} • Sold out"
                            },
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = if (isFareSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp,
                            color = chipTextColor
                        )
                    }
                }
            }
        }
    }
}
