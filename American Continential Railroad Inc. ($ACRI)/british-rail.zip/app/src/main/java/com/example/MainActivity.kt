package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.TerminalScreen
import com.example.ui.TerminalViewModel
import com.example.ui.components.AccessibilityInfoDialog
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrFooter
import com.example.ui.components.BrHeader
import com.example.ui.components.BrStepProgress
import com.example.ui.components.PassengerConfigDialog
import com.example.ui.components.StationSearchDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HelpScreen
import com.example.ui.screens.PaymentScreen
import com.example.ui.screens.TicketCollectionScreen
import com.example.ui.screens.TicketScreen
import com.example.ui.screens.TrainSelectionScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailTheme
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

class MainActivity : ComponentActivity() {
    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            // Text scaling accessibility support
            val baseDensity = LocalDensity.current
            val fontScaleMultiplier = when (state.textSizeLevel) {
                1 -> 1.15f
                2 -> 1.30f
                else -> 1.0f
            }
            val customDensity = remember(baseDensity, fontScaleMultiplier) {
                Density(
                    density = baseDensity.density,
                    fontScale = baseDensity.fontScale * fontScaleMultiplier
                )
            }

            CompositionLocalProvider(LocalDensity provides customDensity) {
                BritishRailTheme {
                    BritishRailTerminalApp(
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BritishRailTerminalApp(
    viewModel: TerminalViewModel
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var showFromStationPicker by remember { mutableStateOf(false) }
    var showToStationPicker by remember { mutableStateOf(false) }
    var showPassengerPicker by remember { mutableStateOf(false) }
    var showAccessibilityGuide by remember { mutableStateOf(false) }

    // Hardware back navigation handler
    BackHandler {
        when (state.currentScreen) {
            TerminalScreen.CHOOSE_TRAIN -> viewModel.navigateToScreen(TerminalScreen.JOURNEY_FORM)
            TerminalScreen.PAYMENT -> viewModel.navigateToScreen(TerminalScreen.CHOOSE_TRAIN)
            TerminalScreen.YOUR_TICKET -> viewModel.resetKioskSession()
            TerminalScreen.COLLECT_TICKET,
            TerminalScreen.VIEW_WALLET,
            TerminalScreen.ACCESSIBILITY_GUIDE,
            TerminalScreen.HELP -> viewModel.navigateToScreen(TerminalScreen.JOURNEY_FORM)
            TerminalScreen.JOURNEY_FORM -> {
                // Already at home
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column {
                BrHeader(
                    currentTime = state.currentTimeString,
                    onTitleClick = { viewModel.resetKioskSession() }
                )
                if (state.currentScreen in listOf(
                        TerminalScreen.JOURNEY_FORM,
                        TerminalScreen.CHOOSE_TRAIN,
                        TerminalScreen.PAYMENT,
                        TerminalScreen.YOUR_TICKET
                    )
                ) {
                    BrStepProgress(
                        currentStep = state.currentStep,
                        language = state.language
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.5.dp)
                            .background(BritishRailBlack)
                    )
                }
            }
        },
        bottomBar = {
            BrFooter(
                language = state.language,
                onLanguageToggle = { viewModel.toggleLanguage() },
                textSizeLevel = state.textSizeLevel,
                onTextSizeChange = { viewModel.setTextSizeLevel(it) },
                isLowerScreenMode = state.isLowerScreenMode,
                onToggleLowerScreen = { viewModel.toggleLowerScreenMode() }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BritishRailWhite)
        ) {
            // Seated / Lower Screen Mode container handling
            if (state.isLowerScreenMode) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Upper 28% decorative information pane for seated users
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.28f)
                            .background(RailGreyPanel)
                            .border(1.dp, BritishRailBlack)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "♿ SEATED ACCESSIBLE INTERACTION MODE ENABLED",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = BritishRailRed,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "All touch targets and actions have been shifted to the lower half of the terminal for comfortable seated reach.",
                                fontSize = 12.sp,
                                color = BritishRailBlack
                            )
                        }
                    }

                    // Lower 72% screen area containing the interactive content
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.72f)
                    ) {
                        TerminalScreenRouter(
                            state = state,
                            viewModel = viewModel,
                            onOpenFromPicker = { showFromStationPicker = true },
                            onOpenToPicker = { showToStationPicker = true },
                            onOpenPassengerPicker = { showPassengerPicker = true },
                            onOpenAccessibilityGuide = { showAccessibilityGuide = true }
                        )
                    }
                }
            } else {
                TerminalScreenRouter(
                    state = state,
                    viewModel = viewModel,
                    onOpenFromPicker = { showFromStationPicker = true },
                    onOpenToPicker = { showToStationPicker = true },
                    onOpenPassengerPicker = { showPassengerPicker = true },
                    onOpenAccessibilityGuide = { showAccessibilityGuide = true }
                )
            }

            // Kiosk Inactivity Expiry Warning Dialog
            if (state.showInactivityWarning) {
                BasicAlertDialog(
                    onDismissRequest = { viewModel.extendKioskSession() },
                    modifier = Modifier
                        .fillMaxWidth(0.65f)
                        .background(BritishRailWhite)
                        .border(3.dp, BritishRailRed)
                        .padding(20.dp)
                        .testTag("kiosk_inactivity_dialog")
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = BritishRailRed,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Are you still there?",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            color = BritishRailBlack
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "To protect your personal privacy, this kiosk terminal session will reset in ${state.kioskCountdownSeconds} seconds.",
                            fontSize = 14.sp,
                            color = RailGreySubtext,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            BrButton(
                                text = "I'm still here! (+2 mins)",
                                onClick = { viewModel.extendKioskSession() },
                                modifier = Modifier.weight(1.2f),
                                style = BrButtonStyle.PRIMARY_RED,
                                testTag = "extend_session_button"
                            )
                            BrButton(
                                text = "Reset now",
                                onClick = { viewModel.resetKioskSession() },
                                modifier = Modifier.weight(0.8f),
                                style = BrButtonStyle.OUTLINED,
                                testTag = "reset_session_button"
                            )
                        }
                    }
                }
            }

            // Station Picker: From
            if (showFromStationPicker) {
                StationSearchDialog(
                    title = "Choose departure station",
                    stations = state.allStations,
                    recentStations = state.recentStations,
                    onStationSelected = {
                        viewModel.setFromStation(it)
                        showFromStationPicker = false
                    },
                    onDismiss = { showFromStationPicker = false }
                )
            }

            // Station Picker: To
            if (showToStationPicker) {
                StationSearchDialog(
                    title = "Choose arrival station",
                    stations = state.allStations,
                    recentStations = state.recentStations,
                    onStationSelected = {
                        viewModel.setToStation(it)
                        showToStationPicker = false
                    },
                    onDismiss = { showToStationPicker = false }
                )
            }

            // Passenger Configuration Dialog
            if (showPassengerPicker) {
                PassengerConfigDialog(
                    initialConfig = state.passengers,
                    language = state.language,
                    onConfirmed = {
                        viewModel.setPassengers(it)
                        showPassengerPicker = false
                    },
                    onDismiss = { showPassengerPicker = false }
                )
            }

            // Accessibility Guide Dialog
            if (showAccessibilityGuide) {
                AccessibilityInfoDialog(
                    infoList = state.accessibilityInfoList,
                    onDismiss = { showAccessibilityGuide = false }
                )
            }
        }
    }
}

@Composable
fun TerminalScreenRouter(
    state: com.example.ui.TerminalUiState,
    viewModel: TerminalViewModel,
    onOpenFromPicker: () -> Unit,
    onOpenToPicker: () -> Unit,
    onOpenPassengerPicker: () -> Unit,
    onOpenAccessibilityGuide: () -> Unit
) {
    when (state.currentScreen) {
        TerminalScreen.JOURNEY_FORM -> {
            HomeScreen(
                state = state,
                onOpenFromStationPicker = onOpenFromPicker,
                onOpenToStationPicker = onOpenToPicker,
                onSwapStations = { viewModel.swapStations() },
                onToggleReturn = { viewModel.setSingleReturn(it) },
                onCycleTravelDate = { viewModel.cycleTravelDate() },
                onCycleDepartTime = { viewModel.cycleDepartTime() },
                onToggleArriveBy = { viewModel.toggleArriveBy() },
                onCycleReturnDate = { viewModel.cycleReturnDate() },
                onOpenPassengerPicker = onOpenPassengerPicker,
                onFindTrains = { viewModel.searchTrains() },
                onCollectTicketClick = { viewModel.navigateToScreen(TerminalScreen.COLLECT_TICKET) },
                onViewTicketsClick = { viewModel.navigateToScreen(TerminalScreen.VIEW_WALLET) },
                onAccessibleJourneyClick = onOpenAccessibilityGuide,
                onHelpClick = { viewModel.navigateToScreen(TerminalScreen.HELP) },
                onToggleKioskMode = { viewModel.toggleKioskMode() },
                onQuickJourneySelected = { origin, dest ->
                    viewModel.setFromStation(origin)
                    viewModel.setToStation(dest)
                }
            )
        }

        TerminalScreen.CHOOSE_TRAIN -> {
            TrainSelectionScreen(
                state = state,
                onSelectJourney = { journey, fare -> viewModel.selectJourney(journey, fare) },
                onSelectFare = { fare -> viewModel.selectFare(fare) },
                onContinueToPayment = { viewModel.proceedToPayment() },
                onChangeJourney = { viewModel.navigateToScreen(TerminalScreen.JOURNEY_FORM) },
                onSwapStations = { viewModel.swapStations() },
                onSingleReturnToggle = { viewModel.setSingleReturn(it) },
                onStepFreeClick = onOpenAccessibilityGuide,
                onNeedHelpClick = { viewModel.navigateToScreen(TerminalScreen.HELP) }
            )
        }

        TerminalScreen.PAYMENT -> {
            PaymentScreen(
                state = state,
                onSelectPaymentMethod = { viewModel.setPaymentMethod(it) },
                onSelectOutcome = { viewModel.setSimulatedOutcome(it) },
                onToggleIssuancePending = { viewModel.setForceIssuancePending(it) },
                onConfirmPayment = { viewModel.processPayment() },
                onBackToTrains = { viewModel.navigateToScreen(TerminalScreen.CHOOSE_TRAIN) }
            )
        }

        TerminalScreen.YOUR_TICKET -> {
            TicketScreen(
                state = state,
                onPrintTicket = { viewModel.printCurrentTicket() },
                onPrintReceipt = { viewModel.printCurrentReceipt() },
                onShowReceiptDialog = { viewModel.setShowReceiptDialog(true) },
                onDismissReceiptDialog = { viewModel.setShowReceiptDialog(false) },
                onRetryIssuance = { viewModel.retryTicketIssuance() },
                onFinishSession = { viewModel.resetKioskSession() }
            )
        }

        TerminalScreen.COLLECT_TICKET -> {
            TicketCollectionScreen(
                state = state,
                onReferenceChange = { viewModel.setCollectionRef(it) },
                onCardLast4Change = { viewModel.setCardLast4(it) },
                onSubmit = { viewModel.submitTicketCollection() },
                onBack = { viewModel.navigateToScreen(TerminalScreen.JOURNEY_FORM) },
                onPrintCollected = { booking ->
                    viewModel.navigateToScreen(TerminalScreen.YOUR_TICKET)
                }
            )
        }

        TerminalScreen.VIEW_WALLET -> {
            WalletScreen(
                state = state,
                onBack = { viewModel.navigateToScreen(TerminalScreen.JOURNEY_FORM) }
            )
        }

        TerminalScreen.HELP -> {
            HelpScreen(
                state = state,
                onBack = { viewModel.navigateToScreen(TerminalScreen.JOURNEY_FORM) }
            )
        }

        TerminalScreen.ACCESSIBILITY_GUIDE -> {
            // Handled via modal dialog
        }
    }
}
