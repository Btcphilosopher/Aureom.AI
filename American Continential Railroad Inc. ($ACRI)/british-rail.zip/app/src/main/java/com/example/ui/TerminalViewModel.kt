package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppLanguage
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.FareBreakdown
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentRequest
import com.example.data.model.PaymentResult
import com.example.data.model.RailcardType
import com.example.data.model.ServiceFare
import com.example.data.model.SimulatedPaymentOutcome
import com.example.data.model.Station
import com.example.data.model.StationAccessibilityInfo
import com.example.data.model.TicketIssuanceResult
import com.example.data.model.TicketType
import com.example.data.model.TravelClass
import com.example.data.repository.AccessibilityDataProviderImpl
import com.example.data.repository.BookingServiceImpl
import com.example.data.repository.FareProviderImpl
import com.example.data.repository.JourneyPlannerImpl
import com.example.data.repository.PaymentAdapterImpl
import com.example.data.repository.PrinterAdapterImpl
import com.example.data.repository.StationRepositoryImpl
import com.example.data.repository.TicketCollectionServiceImpl
import com.example.data.repository.TicketIssuerImpl
import com.example.data.repository.TimetableProviderImpl
import com.example.domain.AccessibilityDataProvider
import com.example.domain.BookingService
import com.example.domain.FareProvider
import com.example.domain.JourneyPlanner
import com.example.domain.PaymentAdapter
import com.example.domain.PrinterAdapter
import com.example.domain.StationRepository
import com.example.domain.TicketCollectionService
import com.example.domain.TicketIssuer
import com.example.domain.TimetableProvider
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class TerminalScreen {
    JOURNEY_FORM,      // Step 1
    CHOOSE_TRAIN,      // Step 2 (mockup screen)
    PAYMENT,           // Step 3
    YOUR_TICKET,       // Step 4
    COLLECT_TICKET,    // Ticket collection flow
    VIEW_WALLET,       // Saved tickets
    ACCESSIBILITY_GUIDE, // Step-free planner
    HELP               // Kiosk assistance
}

data class TerminalUiState(
    val currentScreen: TerminalScreen = TerminalScreen.JOURNEY_FORM,
    val currentStep: Int = 1, // 1 to 4
    val currentTimeString: String = "12:45",
    val language: AppLanguage = AppLanguage.ENGLISH,
    val textSizeLevel: Int = 0, // 0 = standard, 1 = large, 2 = extra large
    val isLowerScreenMode: Boolean = false,
    val isKioskMode: Boolean = true,
    val kioskCountdownSeconds: Int = 90,
    val showInactivityWarning: Boolean = false,

    // Journey inputs
    val fromStation: Station = Station("SHF", "Sheffield", isStepFree = true, isPopular = true),
    val toStation: Station = Station("STP", "London St Pancras", isStepFree = true, isPopular = true),
    val travelDate: String = "Thu 12 Nov",
    val isArriveBy: Boolean = false,
    val departTimeText: String = "After 13:00",
    val isReturn: Boolean = false,
    val returnDate: String = "Fri 13 Nov",
    val returnTimeText: String = "After 17:00",
    val passengers: PassengerConfig = PassengerConfig(1, 0, RailcardType.NONE),
    val stepFreeOnly: Boolean = false,
    val assistanceRequested: Boolean = false,

    // Search results & selection
    val availableJourneys: List<JourneyOption> = emptyList(),
    val selectedJourney: JourneyOption? = null,
    val selectedFare: ServiceFare? = null,
    val isLoadingJourneys: Boolean = false,
    val fareBreakdown: FareBreakdown? = null,

    // Payment step
    val selectedPaymentMethod: PaymentMethod = PaymentMethod.CONTACTLESS,
    val simulatedOutcome: SimulatedPaymentOutcome = SimulatedPaymentOutcome.SUCCESS,
    val forceIssuancePending: Boolean = false,
    val paymentStatusMessage: String? = null,
    val isProcessingPayment: Boolean = false,
    val paymentError: String? = null,

    // Ticket confirmation step
    val activeBooking: Booking? = null,
    val ticketIssuanceResult: TicketIssuanceResult? = null,
    val isRetryingIssuance: Boolean = false,
    val isPrinting: Boolean = false,
    val printMessage: String? = null,
    val showReceiptDialog: Boolean = false,

    // Ticket Collection flow
    val collectionRefInput: String = "BR77102A",
    val cardLast4Input: String = "1234",
    val collectionLoading: Boolean = false,
    val collectionError: String? = null,
    val collectedBooking: Booking? = null,

    // Saved bookings list
    val allBookings: List<Booking> = emptyList(),

    // Station list
    val allStations: List<Station> = emptyList(),
    val recentStations: List<Station> = emptyList(),
    val accessibilityInfoList: List<StationAccessibilityInfo> = emptyList()
)

class TerminalViewModel(
    val stationRepository: StationRepository = StationRepositoryImpl(),
    val fareProvider: FareProvider = FareProviderImpl(),
    val timetableProvider: TimetableProvider = TimetableProviderImpl(stationRepository, fareProvider),
    val journeyPlanner: JourneyPlanner = JourneyPlannerImpl(timetableProvider),
    val bookingService: BookingService = BookingServiceImpl(),
    val paymentAdapter: PaymentAdapter = PaymentAdapterImpl(),
    val ticketIssuer: TicketIssuer = TicketIssuerImpl(),
    val ticketCollectionService: TicketCollectionService = TicketCollectionServiceImpl(bookingService),
    val printerAdapter: PrinterAdapter = PrinterAdapterImpl(),
    val accessibilityDataProvider: AccessibilityDataProvider = AccessibilityDataProviderImpl()
) : ViewModel() {

    private val _uiState = MutableStateFlow(TerminalUiState())
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    private var clockJob: Job? = null
    private var inactivityJob: Job? = null

    init {
        startClock()
        loadInitialData()
        startInactivityTimer()
    }

    private fun startClock() {
        clockJob?.cancel()
        clockJob = viewModelScope.launch {
            val formatter = SimpleDateFormat("HH:mm", Locale.UK)
            while (isActive) {
                val nowStr = formatter.format(Date())
                _uiState.update { it.copy(currentTimeString = nowStr) }
                delay(30000)
            }
        }
    }

    private fun startInactivityTimer() {
        inactivityJob?.cancel()
        inactivityJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                val state = _uiState.value
                // Do not silently abandon a payment in progress or on home screen
                if (state.isKioskMode && !state.isProcessingPayment && state.currentScreen != TerminalScreen.JOURNEY_FORM) {
                    val currentRemaining = state.kioskCountdownSeconds
                    if (currentRemaining > 0) {
                        val next = currentRemaining - 1
                        val showWarning = next in 1..15
                        _uiState.update {
                            it.copy(
                                kioskCountdownSeconds = next,
                                showInactivityWarning = showWarning
                            )
                        }
                    } else {
                        // Inactivity expired -> safe cleanup
                        resetKioskSession()
                    }
                }
            }
        }
    }

    fun userInteracted() {
        _uiState.update {
            it.copy(
                kioskCountdownSeconds = 90,
                showInactivityWarning = false
            )
        }
    }

    fun extendKioskSession() {
        _uiState.update {
            it.copy(
                kioskCountdownSeconds = 120,
                showInactivityWarning = false
            )
        }
    }

    private fun loadInitialData() {
        viewModelScope.launch {
            val stations = stationRepository.getStations()
            val recents = stationRepository.getRecentStations()
            val accessInfo = accessibilityDataProvider.getAllStationAccessibility()
            val allBookings = bookingService.getAllBookings()

            _uiState.update {
                it.copy(
                    allStations = stations,
                    recentStations = recents,
                    accessibilityInfoList = accessInfo,
                    allBookings = allBookings
                )
            }

            // Load default services for Sheffield -> London St Pancras
            searchTrainsInternal()
        }
    }

    fun searchTrains() {
        userInteracted()
        searchTrainsInternal()
        _uiState.update {
            it.copy(
                currentScreen = TerminalScreen.CHOOSE_TRAIN,
                currentStep = 2
            )
        }
    }

    private fun searchTrainsInternal() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingJourneys = true) }
            val state = _uiState.value
            val services = journeyPlanner.planJourney(
                origin = state.fromStation,
                destination = state.toStation,
                date = state.travelDate,
                departAfterTime = state.departTimeText,
                isReturn = state.isReturn,
                returnDate = state.returnDate
            )

            // Auto-select the 13:45 service by default to match the mockup!
            val defaultSelection = services.find { it.departureTime == "13:45" }
                ?: services.firstOrNull()

            val defaultFare = defaultSelection?.fares?.firstOrNull { it.isAvailable }
            val breakdown = if (defaultFare != null) {
                fareProvider.getBreakdownForServiceFare(
                    fare = defaultFare,
                    passengers = state.passengers,
                    isReturn = state.isReturn
                )
            } else null

            _uiState.update {
                it.copy(
                    availableJourneys = services,
                    selectedJourney = defaultSelection,
                    selectedFare = defaultFare,
                    fareBreakdown = breakdown,
                    isLoadingJourneys = false
                )
            }
        }
    }

    fun selectJourney(journey: JourneyOption, fare: ServiceFare? = null) {
        userInteracted()
        val chosenFare = fare?.takeIf { it.isAvailable }
            ?: journey.fares.firstOrNull { it.isAvailable }
        val breakdown = if (chosenFare != null) {
            fareProvider.getBreakdownForServiceFare(
                fare = chosenFare,
                passengers = _uiState.value.passengers,
                isReturn = _uiState.value.isReturn
            )
        } else null

        _uiState.update {
            it.copy(
                selectedJourney = journey,
                selectedFare = chosenFare,
                fareBreakdown = breakdown
            )
        }
    }

    fun selectFare(fare: ServiceFare) {
        userInteracted()
        if (!fare.isAvailable) return
        val breakdown = fareProvider.getBreakdownForServiceFare(
            fare = fare,
            passengers = _uiState.value.passengers,
            isReturn = _uiState.value.isReturn
        )
        _uiState.update {
            it.copy(
                selectedFare = fare,
                fareBreakdown = breakdown
            )
        }
    }

    fun cycleTravelDate() {
        userInteracted()
        val dates = listOf("Thu 12 Nov", "Fri 13 Nov", "Sat 14 Nov", "Sun 15 Nov")
        val nextIdx = (dates.indexOf(_uiState.value.travelDate) + 1) % dates.size
        _uiState.update { it.copy(travelDate = dates[nextIdx]) }
    }

    fun cycleDepartTime() {
        userInteracted()
        val times = listOf("After 13:00", "After 14:00", "After 17:00", "After 23:45")
        val nextIdx = (times.indexOf(_uiState.value.departTimeText) + 1) % times.size
        _uiState.update { it.copy(departTimeText = times[nextIdx]) }
    }

    fun toggleArriveBy() {
        userInteracted()
        val nextArriveBy = !_uiState.value.isArriveBy
        val timeLabel = if (nextArriveBy) {
            _uiState.value.departTimeText.replace("After", "By")
        } else {
            _uiState.value.departTimeText.replace("By", "After")
        }
        _uiState.update { it.copy(isArriveBy = nextArriveBy, departTimeText = timeLabel) }
    }

    fun cycleReturnDate() {
        userInteracted()
        val dates = listOf("Fri 13 Nov", "Sat 14 Nov", "Sun 15 Nov", "Mon 16 Nov")
        val nextIdx = (dates.indexOf(_uiState.value.returnDate) + 1) % dates.size
        _uiState.update { it.copy(returnDate = dates[nextIdx]) }
    }

    fun toggleStepFreeOnly() {
        userInteracted()
        _uiState.update { it.copy(stepFreeOnly = !it.stepFreeOnly) }
    }

    fun toggleAssistanceRequested() {
        userInteracted()
        _uiState.update { it.copy(assistanceRequested = !it.assistanceRequested) }
    }

    fun setFromStation(station: Station) {
        userInteracted()
        if (station.crsCode == _uiState.value.toStation.crsCode) {
            // Prevent identical origin and destination
            return
        }
        _uiState.update { it.copy(fromStation = station) }
        viewModelScope.launch { stationRepository.saveRecentStation(station) }
    }

    fun setToStation(station: Station) {
        userInteracted()
        if (station.crsCode == _uiState.value.fromStation.crsCode) {
            // Prevent identical origin and destination
            return
        }
        _uiState.update { it.copy(toStation = station) }
        viewModelScope.launch { stationRepository.saveRecentStation(station) }
    }

    fun swapStations() {
        userInteracted()
        val currentFrom = _uiState.value.fromStation
        val currentTo = _uiState.value.toStation
        _uiState.update {
            it.copy(
                fromStation = currentTo,
                toStation = currentFrom
            )
        }
        searchTrainsInternal()
    }

    fun setSingleReturn(isReturn: Boolean) {
        userInteracted()
        _uiState.update { it.copy(isReturn = isReturn) }
        _uiState.value.selectedFare?.let { fare ->
            selectFare(fare)
        }
    }

    fun setPassengers(config: PassengerConfig) {
        userInteracted()
        _uiState.update { it.copy(passengers = config) }
        _uiState.value.selectedFare?.let { fare ->
            selectFare(fare)
        }
    }

    fun navigateToScreen(screen: TerminalScreen) {
        userInteracted()
        val step = when (screen) {
            TerminalScreen.JOURNEY_FORM -> 1
            TerminalScreen.CHOOSE_TRAIN -> 2
            TerminalScreen.PAYMENT -> 3
            TerminalScreen.YOUR_TICKET -> 4
            else -> _uiState.value.currentStep
        }
        _uiState.update {
            it.copy(
                currentScreen = screen,
                currentStep = step
            )
        }
    }

    fun proceedToPayment() {
        userInteracted()
        val journey = _uiState.value.selectedJourney
        val fare = _uiState.value.selectedFare
        if (journey == null || fare == null || !fare.isAvailable) return

        val totalPence = _uiState.value.fareBreakdown?.totalPence ?: fare.pricePence
        viewModelScope.launch {
            val pendingBooking = bookingService.createPendingBooking(
                journey = journey,
                fare = fare,
                passengers = _uiState.value.passengers,
                travelDate = _uiState.value.travelDate,
                totalPence = totalPence
            )
            _uiState.update {
                it.copy(
                    activeBooking = pendingBooking,
                    currentScreen = TerminalScreen.PAYMENT,
                    currentStep = 3,
                    paymentError = null,
                    paymentStatusMessage = null
                )
            }
        }
    }

    fun setPaymentMethod(method: PaymentMethod) {
        userInteracted()
        _uiState.update { it.copy(selectedPaymentMethod = method) }
    }

    fun setSimulatedOutcome(outcome: SimulatedPaymentOutcome) {
        userInteracted()
        _uiState.update { it.copy(simulatedOutcome = outcome) }
    }

    fun setForceIssuancePending(forcePending: Boolean) {
        userInteracted()
        _uiState.update { it.copy(forceIssuancePending = forcePending) }
    }

    fun processPayment() {
        userInteracted()
        val booking = _uiState.value.activeBooking ?: return
        val outcome = _uiState.value.simulatedOutcome
        val forcePending = _uiState.value.forceIssuancePending

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessingPayment = true,
                    paymentError = null,
                    paymentStatusMessage = "Connecting to banking terminal... Present card or phone"
                )
            }

            val request = PaymentRequest(
                bookingReference = booking.bookingReference,
                amountPence = booking.totalPence,
                method = _uiState.value.selectedPaymentMethod,
                simulatedOutcome = outcome
            )

            val result = paymentAdapter.processPayment(request)

            when (result) {
                is PaymentResult.Success -> {
                    _uiState.update { it.copy(paymentStatusMessage = "Authorising... Payment Approved!") }
                    val confirmed = bookingService.confirmBooking(
                        bookingReference = booking.bookingReference,
                        paymentAuthCode = result.authCode
                    )

                    // Issue demonstration ticket (supports pending scenario for demonstration)
                    val ticketResult = ticketIssuer.issueTicket(confirmed, forcePendingForDemo = forcePending)
                    val updatedBooking = if (ticketResult is TicketIssuanceResult.Pending) {
                        confirmed.copy(status = BookingStatus.PENDING_ISSUANCE).also {
                            bookingService.updateBooking(it)
                        }
                    } else {
                        confirmed.copy(status = BookingStatus.TICKET_ISSUED).also {
                            bookingService.updateBooking(it)
                        }
                    }

                    val updatedAll = bookingService.getAllBookings()
                    _uiState.update {
                        it.copy(
                            isProcessingPayment = false,
                            activeBooking = updatedBooking,
                            ticketIssuanceResult = ticketResult,
                            currentScreen = TerminalScreen.YOUR_TICKET,
                            currentStep = 4,
                            allBookings = updatedAll,
                            paymentStatusMessage = null,
                            printMessage = null
                        )
                    }
                }
                is PaymentResult.Declined -> {
                    _uiState.update {
                        it.copy(
                            isProcessingPayment = false,
                            paymentError = result.reason,
                            paymentStatusMessage = null
                        )
                    }
                }
                is PaymentResult.Timeout -> {
                    _uiState.update {
                        it.copy(
                            isProcessingPayment = false,
                            paymentError = "Payment terminal timed out. No charge was made. Please tap card again.",
                            paymentStatusMessage = null
                        )
                    }
                }
                is PaymentResult.Cancelled -> {
                    _uiState.update {
                        it.copy(
                            isProcessingPayment = false,
                            paymentError = "Payment cancelled on customer PIN pad.",
                            paymentStatusMessage = null
                        )
                    }
                }
            }
        }
    }

    fun retryTicketIssuance() {
        userInteracted()
        val booking = _uiState.value.activeBooking ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isRetryingIssuance = true) }
            val result = ticketIssuer.issueTicket(booking, forcePendingForDemo = false)
            val updatedBooking = booking.copy(status = BookingStatus.TICKET_ISSUED)
            bookingService.updateBooking(updatedBooking)
            val updatedAll = bookingService.getAllBookings()
            _uiState.update {
                it.copy(
                    isRetryingIssuance = false,
                    activeBooking = updatedBooking,
                    ticketIssuanceResult = result,
                    forceIssuancePending = false,
                    allBookings = updatedAll
                )
            }
        }
    }

    fun printCurrentTicket() {
        userInteracted()
        val booking = _uiState.value.activeBooking ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isPrinting = true, printMessage = "Printing magnetic British Rail card ticket...") }
            printerAdapter.printTicket(booking)
            _uiState.update { it.copy(isPrinting = false, printMessage = "Ticket printed! Please collect from dispenser tray below.") }
        }
    }

    fun printCurrentReceipt() {
        userInteracted()
        val booking = _uiState.value.activeBooking ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isPrinting = true, printMessage = "Printing itemized VAT receipt...") }
            printerAdapter.printReceipt(booking)
            _uiState.update { it.copy(isPrinting = false, printMessage = "Receipt printed! Please collect.") }
        }
    }

    fun setShowReceiptDialog(show: Boolean) {
        userInteracted()
        _uiState.update { it.copy(showReceiptDialog = show) }
    }

    // Ticket Collection methods
    fun setCollectionRef(ref: String) {
        userInteracted()
        _uiState.update { it.copy(collectionRefInput = ref.uppercase()) }
    }

    fun setCardLast4(card: String) {
        userInteracted()
        _uiState.update { it.copy(cardLast4Input = card.take(4)) }
    }

    fun submitTicketCollection() {
        userInteracted()
        val ref = _uiState.value.collectionRefInput
        val card = _uiState.value.cardLast4Input

        viewModelScope.launch {
            _uiState.update { it.copy(collectionLoading = true, collectionError = null) }
            val res = ticketCollectionService.retrieveTicketForCollection(ref, card)
            res.fold(
                onSuccess = { booking ->
                    ticketCollectionService.markCollected(booking.bookingReference)
                    val updatedAll = bookingService.getAllBookings()
                    _uiState.update {
                        it.copy(
                            collectionLoading = false,
                            collectedBooking = booking,
                            allBookings = updatedAll
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            collectionLoading = false,
                            collectionError = error.message ?: "Failed to retrieve booking"
                        )
                    }
                }
            )
        }
    }

    fun toggleLanguage() {
        userInteracted()
        val next = if (_uiState.value.language == AppLanguage.ENGLISH) AppLanguage.CYMRAEG else AppLanguage.ENGLISH
        _uiState.update { it.copy(language = next) }
    }

    fun setTextSizeLevel(level: Int) {
        userInteracted()
        _uiState.update { it.copy(textSizeLevel = level) }
    }

    fun toggleLowerScreenMode() {
        userInteracted()
        _uiState.update { it.copy(isLowerScreenMode = !it.isLowerScreenMode) }
    }

    fun toggleKioskMode() {
        userInteracted()
        _uiState.update { it.copy(isKioskMode = !it.isKioskMode) }
    }

    fun resetKioskSession() {
        _uiState.update {
            it.copy(
                currentScreen = TerminalScreen.JOURNEY_FORM,
                currentStep = 1,
                fromStation = Station("SHF", "Sheffield", isStepFree = true, isPopular = true),
                toStation = Station("STP", "London St Pancras", isStepFree = true, isPopular = true),
                travelDate = "Thu 12 Nov",
                isArriveBy = false,
                departTimeText = "After 13:00",
                isReturn = false,
                passengers = PassengerConfig(1, 0, RailcardType.NONE),
                activeBooking = null,
                ticketIssuanceResult = null,
                forceIssuancePending = false,
                simulatedOutcome = SimulatedPaymentOutcome.SUCCESS,
                paymentError = null,
                paymentStatusMessage = null,
                printMessage = null,
                collectedBooking = null,
                collectionError = null,
                collectionRefInput = "",
                cardLast4Input = "",
                showReceiptDialog = false,
                kioskCountdownSeconds = 90,
                showInactivityWarning = false
            )
        }
        searchTrainsInternal()
    }
}
