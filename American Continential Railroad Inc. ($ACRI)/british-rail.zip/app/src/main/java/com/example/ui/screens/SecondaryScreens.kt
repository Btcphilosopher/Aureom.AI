package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Booking
import com.example.data.model.StationAccessibilityInfo
import com.example.ui.TerminalUiState
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.QrCodeView
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext
import com.example.ui.theme.RailTicketBuff

/**
 * Screen for collecting pre-booked tickets with 8-character reference and secondary verification.
 */
@Composable
fun TicketCollectionScreen(
    state: TerminalUiState,
    onReferenceChange: (String) -> Unit,
    onCardLast4Change: (String) -> Unit,
    onSubmit: () -> Unit,
    onBack: () -> Unit,
    onPrintCollected: (Booking) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val isWelsh = lang == AppLanguage.CYMRAEG
    val collected = state.collectedBooking

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(BritishRailWhite)
            .padding(18.dp)
            .testTag("ticket_collection_screen")
    ) {
        // Left Column: Entry Form
        Column(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight()
                .padding(end = 16.dp)
        ) {
            Text(
                text = if (isWelsh) "Casglu tocynnau a archebwyd" else "Collect pre-booked tickets",
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                color = BritishRailBlack
            )
            Text(
                text = if (isWelsh) "Rhowch eich cyfeirnod archebu a 4 digid olaf y cerdyn talu" else "Enter your 8-digit collection reference and payment card verification digits",
                fontSize = 13.sp,
                color = RailGreySubtext
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Reference input
            Text(
                text = "1. COLLECTION REFERENCE (8 CHARACTERS)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BritishRailBlack,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = state.collectionRefInput,
                onValueChange = onReferenceChange,
                placeholder = { Text("e.g. BR77102A") },
                leadingIcon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = BritishRailBlack) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("collection_ref_input"),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BritishRailBlack,
                    unfocusedBorderColor = RailGreyBorder,
                    focusedTextColor = BritishRailBlack,
                    unfocusedTextColor = BritishRailBlack
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Secondary Verification: Card Last 4 Digits
            Text(
                text = "2. PAYMENT CARD VERIFICATION (LAST 4 DIGITS)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BritishRailBlack,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = state.cardLast4Input,
                onValueChange = onCardLast4Change,
                placeholder = { Text("e.g. 1234") },
                leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null, tint = BritishRailBlack) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("collection_card_input"),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BritishRailBlack,
                    unfocusedBorderColor = RailGreyBorder,
                    focusedTextColor = BritishRailBlack,
                    unfocusedTextColor = BritishRailBlack
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (state.collectionError != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, BritishRailRed)
                        .background(Color(0xFFFFECEE))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = BritishRailRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = state.collectionError,
                            fontSize = 13.sp,
                            color = BritishRailRed,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Submit Button
            if (state.collectionLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BritishRailRed)
                }
            } else {
                BrButton(
                    text = if (isWelsh) "Canfod a chasglu tocyn →" else "Find & collect ticket →",
                    onClick = onSubmit,
                    modifier = Modifier.fillMaxWidth(),
                    style = BrButtonStyle.PRIMARY_RED,
                    testTag = "submit_collection_button"
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            BrButton(
                text = if (isWelsh) "← Yn ôl i'r hafan" else "← Back to home",
                onClick = onBack,
                style = BrButtonStyle.OUTLINED,
                modifier = Modifier.fillMaxWidth(0.6f),
                testTag = "back_from_collection_button"
            )
        }

        // Vertical divider
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(BritishRailBlack)
        )

        // Right Column: Result / Preview
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(start = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (collected != null) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ticket Found & Ready to Print",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = BritishRailBlack
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Mini Ticket Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, BritishRailBlack)
                            .background(RailTicketBuff)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "${collected.journey.origin.name} → ${collected.journey.destination.name}",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text("Date: ${collected.travelDate} (${collected.journey.departureTime})", fontSize = 13.sp)
                        Text("Class: ${collected.selectedFare.travelClass.displayName}", fontSize = 13.sp)
                        Text("Passengers: ${collected.passengers.summary(lang)}", fontSize = 13.sp)
                        Text("Ref: ${collected.bookingReference}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    BrButton(
                        text = "Print collected ticket now",
                        onClick = { onPrintCollected(collected) },
                        modifier = Modifier.fillMaxWidth(),
                        style = BrButtonStyle.PRIMARY_RED,
                        testTag = "print_collected_button"
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RailGreyPanel)
                        .border(1.dp, BritishRailBlack)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "TESTING HINT FOR EXAMINERS",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = BritishRailBlack,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Pre-loaded demonstration collection credentials:\n• Reference: BR77102A\n• Card last 4 digits: 1234\n\nOr book any ticket on this terminal and use its 8-character code!",
                        fontSize = 13.sp,
                        color = BritishRailBlack
                    )
                }
            }

            BrButton(
                text = "Close",
                onClick = onBack,
                style = BrButtonStyle.SECONDARY_BLACK,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * Screen displaying stored / saved tickets on the device.
 */
@Composable
fun WalletScreen(
    state: TerminalUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BritishRailWhite)
            .padding(18.dp)
            .testTag("wallet_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Demonstration Ticket Wallet",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                    color = BritishRailBlack
                )
                Text(
                    text = "All tickets created and saved on this terminal",
                    fontSize = 13.sp,
                    color = RailGreySubtext
                )
            }
            BrButton(
                text = "← Back",
                onClick = onBack,
                style = BrButtonStyle.OUTLINED,
                modifier = Modifier.width(100.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (state.allBookings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("No tickets found. Book a journey from the home page!", color = RailGreySubtext, fontSize = 16.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(state.allBookings) { booking ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, BritishRailBlack)
                            .background(RailTicketBuff)
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${booking.journey.origin.name} → ${booking.journey.destination.name}",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = BritishRailBlack
                            )
                            Text(
                                text = "${booking.travelDate} • Dep ${booking.journey.departureTime} • ${booking.selectedFare.travelClass.displayName}",
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Ref: ${booking.bookingReference} | Coll Code: ${booking.collectionCode} | Price: ${booking.formattedPrice}",
                                fontWeight = FontWeight.Medium,
                                fontSize = 12.sp,
                                color = RailGreySubtext
                            )
                        }

                        QrCodeView(
                            dataPayload = "BR-WALLET-${booking.bookingReference}",
                            qrBoxSize = 70.dp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Terminal Help Screen.
 */
@Composable
fun HelpScreen(
    state: TerminalUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BritishRailWhite)
            .padding(18.dp)
            .verticalScroll(rememberScrollState())
            .testTag("help_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Terminal Help & Instructions",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                    color = BritishRailBlack
                )
                Text(
                    text = "How to use this British Rail touchscreen ticket machine",
                    fontSize = 13.sp,
                    color = RailGreySubtext
                )
            }
            BrButton(
                text = "← Back",
                onClick = onBack,
                style = BrButtonStyle.OUTLINED,
                modifier = Modifier.width(100.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        HelpSectionCard(
            title = "1. Searching for trains",
            content = "Tap 'From' or 'To' on the home page to select your departure and arrival stations. Tap the vertical arrows ⇅ to swap stations at any time. Choose whether you need a Single or Return ticket, and tap the Passengers field to specify adults, children, and eligible Railcards."
        )

        Spacer(modifier = Modifier.height(10.dp))

        HelpSectionCard(
            title = "2. Choosing your train",
            content = "The train selection screen shows illustrative services with departure times, arrival times, durations, and interchange details. The selected train is highlighted with a British Rail red border. Review your selection in the bottom summary box and tap 'Continue to payment'."
        )

        Spacer(modifier = Modifier.height(10.dp))

        HelpSectionCard(
            title = "3. Payment & Security",
            content = "We accept Contactless cards, smartphones, Chip & PIN cards, and cash. Card details are processed through external secure banking terminals and are never stored on this machine. For demonstration testing, you can simulate approval, decline, timeout, and cancellation."
        )

        Spacer(modifier = Modifier.height(10.dp))

        HelpSectionCard(
            title = "4. Accessibility & Seated Mode",
            content = "Tap 'A- A A+' in the bottom bar to adjust font size. Tap 'Seated mode' in the footer to shift all interactive buttons into the lower half of the screen for wheelchair or seated user reach. TalkBack screen readers and Welsh language are fully supported."
        )
    }
}

@Composable
private fun HelpSectionCard(title: String, content: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, BritishRailBlack)
            .padding(14.dp)
    ) {
        Text(
            text = title,
            fontFamily = RailAlphabetFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp,
            color = BritishRailBlack
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = content,
            fontSize = 14.sp,
            color = BritishRailBlack,
            lineHeight = 20.sp
        )
    }
}
