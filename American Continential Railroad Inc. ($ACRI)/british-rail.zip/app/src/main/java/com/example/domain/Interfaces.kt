package com.example.domain

import com.example.data.model.Booking
import com.example.data.model.FareBreakdown
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.PaymentRequest
import com.example.data.model.PaymentResult
import com.example.data.model.ServiceFare
import com.example.data.model.Station
import com.example.data.model.StationAccessibilityInfo
import com.example.data.model.TicketIssuanceResult
import com.example.data.model.TicketType
import com.example.data.model.TravelClass

interface StationRepository {
    suspend fun getStations(): List<Station>
    suspend fun searchStations(query: String): List<Station>
    suspend fun getStationByCrs(crs: String): Station?
    suspend fun getRecentStations(): List<Station>
    suspend fun saveRecentStation(station: Station)
}

interface TimetableProvider {
    suspend fun getServices(
        originCrs: String,
        destCrs: String,
        date: String,
        departAfterTime: String
    ): List<JourneyOption>
}

interface JourneyPlanner {
    suspend fun planJourney(
        origin: Station,
        destination: Station,
        date: String,
        departAfterTime: String,
        isReturn: Boolean,
        returnDate: String? = null
    ): List<JourneyOption>
}

interface FareProvider {
    fun calculateFare(
        baseSinglePence: Int,
        passengers: PassengerConfig,
        ticketType: TicketType,
        travelClass: TravelClass
    ): Int

    fun getFareBreakdown(
        baseFarePence: Int,
        passengers: PassengerConfig,
        ticketType: TicketType,
        travelClass: TravelClass
    ): FareBreakdown

    fun getBreakdownForServiceFare(
        fare: ServiceFare,
        passengers: PassengerConfig,
        isReturn: Boolean
    ): FareBreakdown
}

interface BookingService {
    suspend fun createPendingBooking(
        journey: JourneyOption,
        fare: ServiceFare,
        passengers: PassengerConfig,
        travelDate: String,
        totalPence: Int = fare.pricePence
    ): Booking

    suspend fun confirmBooking(
        bookingReference: String,
        paymentAuthCode: String
    ): Booking

    suspend fun getBooking(bookingReference: String): Booking?
    suspend fun getAllBookings(): List<Booking>
    suspend fun updateBooking(booking: Booking)
}

interface PaymentAdapter {
    suspend fun processPayment(request: PaymentRequest): PaymentResult
}

interface TicketIssuer {
    suspend fun issueTicket(booking: Booking, forcePendingForDemo: Boolean = false): TicketIssuanceResult
}

interface TicketCollectionService {
    suspend fun retrieveTicketForCollection(reference: String, cardLast4: String): Result<Booking>
    suspend fun markCollected(reference: String): Boolean
}

interface PrinterAdapter {
    suspend fun printTicket(booking: Booking): Boolean
    suspend fun printReceipt(booking: Booking): Boolean
}

interface AccessibilityDataProvider {
    fun getStationAccessibility(stationCrs: String): StationAccessibilityInfo?
    fun getAllStationAccessibility(): List<StationAccessibilityInfo>
}
