package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Classic British Rail Corporate Identity Colors (1965 Manual)
val BritishRailRed = Color(0xFFD41E26)
val BritishRailRedDark = Color(0xFFB5151C)
val BritishRailRedLight = Color(0xFFFFECEE)

val BritishRailBlack = Color(0xFF000000)
val BritishRailOffBlack = Color(0xFF161616)
val BritishRailWhite = Color(0xFFFFFFFF)

// Rail Neutral Greys
val RailGreyBackground = Color(0xFFF4F4F4)
val RailGreyPanel = Color(0xFFEEEEEE)
val RailGreyBorder = Color(0xFFCCCCCC)
val RailGreyDark = Color(0xFF555555)
val RailGreySubtext = Color(0xFF767676)

// Functional & Alert Colors
val RailGreen = Color(0xFF1E824C)
val RailAmber = Color(0xFFD35400)
val RailOrangeTicket = Color(0xFFF39C12)
val RailTicketBuff = Color(0xFFFFF3CD)
val RailTicketOrangeHeader = Color(0xFFE67E22)
