package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Station
import com.example.ui.TerminalUiState
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrSchematicLine
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

/**
 * Step 1: British Rail Terminal Home Page & Journey Planner.
 */
@Composable
fun HomeScreen(
    state: TerminalUiState,
    onOpenFromStationPicker: () -> Unit,
    onOpenToStationPicker: () -> Unit,
    onSwapStations: () -> Unit,
    onToggleReturn: (Boolean) -> Unit,
    onCycleTravelDate: () -> Unit,
    onCycleDepartTime: () -> Unit,
    onToggleArriveBy: () -> Unit,
    onCycleReturnDate: () -> Unit,
    onOpenPassengerPicker: () -> Unit,
    onFindTrains: () -> Unit,
    onCollectTicketClick: () -> Unit,
    onViewTicketsClick: () -> Unit,
    onAccessibleJourneyClick: () -> Unit,
    onHelpClick: () -> Unit,
    onToggleKioskMode: () -> Unit,
    onQuickJourneySelected: (Station, Station) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val isWelsh = lang == AppLanguage.CYMRAEG

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(BritishRailWhite)
            .padding(horizontal = 18.dp, vertical = 10.dp)
            .testTag("home_journey_screen")
    ) {
        // ================= LEFT / MAIN JOURNEY PLANNER =================
        Column(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(end = 16.dp)
        ) {
            // Main Heading
            Text(
                text = if (isWelsh) "Ble hoffech chi fynd?" else "Where would you like to go?",
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 30.sp,
                color = BritishRailBlack
            )
            Text(
                text = if (isWelsh) "Cynlluniwch eich taith a phrynwch docynnau trên ar unwaith" else "Plan your journey and buy train tickets instantly",
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Normal,
                fontSize = 14.sp,
                color = RailGreySubtext
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Origin / Destination Form Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, BritishRailBlack)
                    .background(BritishRailWhite)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // From Station
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenFromStationPicker() }
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                            .testTag("home_from_station_field"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isWelsh) "O (Gorsaf gychwyn)" else "From (Origin station)",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = RailGreySubtext,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = state.fromStation.displayName,
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = BritishRailBlack
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .background(BritishRailBlack)
                    )

                    // To Station
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenToStationPicker() }
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                            .testTag("home_to_station_field"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isWelsh) "I (Gorsaf gyrraedd)" else "To (Destination station)",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = RailGreySubtext,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = state.toStation.displayName,
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = BritishRailBlack
                            )
                        }
                    }
                }

                // Swap stations button on the right edge
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 12.dp)
                        .size(44.dp)
                        .border(2.dp, BritishRailBlack)
                        .background(BritishRailWhite)
                        .clickable { onSwapStations() }
                        .testTag("home_swap_stations_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapVert,
                        contentDescription = "Swap Origin and Destination",
                        tint = BritishRailBlack,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Date / Depart / Return controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Single / Return toggle
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(if (!state.isReturn) BritishRailRed else BritishRailWhite)
                            .border(2.dp, if (!state.isReturn) BritishRailRed else BritishRailBlack)
                            .clickable { onToggleReturn(false) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isWelsh) "Sengl" else "Single",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (!state.isReturn) BritishRailWhite else BritishRailBlack
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(if (state.isReturn) BritishRailRed else BritishRailWhite)
                            .border(2.dp, if (state.isReturn) BritishRailRed else BritishRailBlack)
                            .clickable { onToggleReturn(true) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isWelsh) "Dychwelyd" else "Return",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (state.isReturn) BritishRailWhite else BritishRailBlack
                        )
                    }
                }

                // Date & Time boxes (interactive)
                Row(
                    modifier = Modifier
                        .weight(1.4f)
                        .height(44.dp)
                        .border(2.dp, BritishRailBlack)
                        .background(BritishRailWhite),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { onCycleTravelDate() }
                            .padding(horizontal = 8.dp)
                            .testTag("home_travel_date_button"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = "Travel date",
                            tint = BritishRailBlack,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = state.travelDate,
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BritishRailBlack
                        )
                    }
                    Box(
                        modifier = Modifier
                            .width(1.5.dp)
                            .fillMaxHeight()
                            .background(BritishRailBlack)
                    )
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { onCycleDepartTime() }
                            .padding(horizontal = 8.dp)
                            .testTag("home_depart_time_button"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = "Travel time",
                            tint = BritishRailBlack,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = state.departTimeText,
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BritishRailBlack
                        )
                    }
                    Box(
                        modifier = Modifier
                            .width(1.5.dp)
                            .fillMaxHeight()
                            .background(BritishRailBlack)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .background(RailGreyPanel)
                            .clickable { onToggleArriveBy() }
                            .padding(horizontal = 8.dp)
                            .testTag("home_arrive_by_toggle"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (state.isArriveBy) "Arrive by" else "Depart",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = BritishRailBlack
                        )
                    }
                }
            }

            if (state.isReturn) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .border(2.dp, BritishRailBlack)
                        .background(RailGreyPanel)
                        .clickable { onCycleReturnDate() }
                        .padding(horizontal = 12.dp)
                        .testTag("home_return_date_row"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isWelsh) "Taith yn ôl: ${state.returnDate} • ${state.returnTimeText}"
                        else "Return journey: ${state.returnDate} • ${state.returnTimeText}",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BritishRailBlack
                    )
                    Text(
                        text = if (isWelsh) "Newid dyddiad >" else "Change date >",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = BritishRailRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Passengers & Railcard Selector (Tap to configure)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, BritishRailBlack)
                    .background(BritishRailWhite)
                    .clickable { onOpenPassengerPicker() }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .testTag("home_passengers_field"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = BritishRailBlack,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isWelsh) "TEITHWYR A CHERDYN RHEILFFORDD" else "PASSENGERS & RAILCARD",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = RailGreySubtext,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = state.passengers.summary(lang),
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = BritishRailBlack
                        )
                    }
                }
                Text(
                    text = if (isWelsh) "Newid >" else "Edit >",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = BritishRailRed
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Big Red Primary Action Button: "Find trains →"
            BrButton(
                text = if (isWelsh) "Canfod trenau →" else "Find trains →",
                onClick = onFindTrains,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                style = BrButtonStyle.PRIMARY_RED,
                testTag = "find_trains_button"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Restrained schematic railway line graphic accent
            BrSchematicLine(
                originName = state.fromStation.name,
                destinationName = state.toStation.name,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Vertical divider
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(BritishRailBlack)
        )

        // ================= RIGHT COLUMN: SECONDARY ACTIONS & QUICK TRIPS =================
        Column(
            modifier = Modifier
                .weight(0.9f)
                .fillMaxHeight()
                .padding(start = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isWelsh) "Gwasanaethau eraill" else "Terminal services",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = if (isWelsh) "Casglu, gweld tocynnau a chymorth" else "Collection, saved tickets and assistance",
                            fontSize = 12.sp,
                            color = RailGreySubtext
                        )
                    }

                    // Shared Kiosk vs Personal Device mode switch
                    Box(
                        modifier = Modifier
                            .border(1.5.dp, BritishRailBlack)
                            .background(if (state.isKioskMode) BritishRailBlack else BritishRailWhite)
                            .clickable { onToggleKioskMode() }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("toggle_kiosk_mode_button")
                    ) {
                        Text(
                            text = if (state.isKioskMode) "Shared Kiosk" else "Personal Device",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (state.isKioskMode) BritishRailWhite else BritishRailBlack
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Secondary Action 1: Collect a ticket
                SecondaryServiceCard(
                    title = if (isWelsh) "Casglu tocyn a archebwyd" else "Collect a pre-booked ticket",
                    subtitle = if (isWelsh) "Rhowch eich cod 8-llythyren" else "Enter your 8-digit reference",
                    icon = Icons.Default.ConfirmationNumber,
                    onClick = onCollectTicketClick,
                    testTag = "service_collect_ticket"
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Secondary Action 2: View my tickets
                SecondaryServiceCard(
                    title = if (isWelsh) "Gweld fy nhocynnau" else "View my tickets & wallet",
                    subtitle = if (isWelsh) "${state.allBookings.size} tocyn wedi'u harchebu" else "${state.allBookings.size} demonstration tickets stored",
                    icon = Icons.Default.FolderShared,
                    onClick = onViewTicketsClick,
                    testTag = "service_view_tickets"
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Secondary Action 3: Plan an accessible journey
                SecondaryServiceCard(
                    title = if (isWelsh) "Cynllunio taith ddi-risiau" else "Plan an accessible journey",
                    subtitle = if (isWelsh) "Gwybodaeth mynediad a chymorth" else "Station lifts, hearing loops & assistance",
                    icon = Icons.Default.Accessible,
                    onClick = onAccessibleJourneyClick,
                    testTag = "service_accessible_journey"
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Secondary Action 4: Help
                SecondaryServiceCard(
                    title = if (isWelsh) "Cymorth a chyngor terfynell" else "Terminal help & instructions",
                    subtitle = if (isWelsh) "Canllaw defnyddio'r peiriant tocynnau" else "How to use this touchscreen terminal",
                    icon = Icons.AutoMirrored.Filled.HelpOutline,
                    onClick = onHelpClick,
                    testTag = "service_terminal_help"
                )
            }

            // Quick popular route shortcuts at bottom
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RailGreyPanel)
                    .border(1.5.dp, BritishRailBlack)
                    .padding(10.dp)
            ) {
                Text(
                    text = if (isWelsh) "TEITHIAU CYFLYM" else "QUICK POPULAR JOURNEYS",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = BritishRailBlack,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                val quickTrips = listOf(
                    Station("SHF", "Sheffield") to Station("STP", "London St Pancras"),
                    Station("SHF", "Sheffield") to Station("MAN", "Manchester Piccadilly"),
                    Station("SHF", "Sheffield") to Station("LDS", "Leeds"),
                    Station("SHF", "Sheffield") to Station("YRK", "York")
                )

                quickTrips.forEach { (origin, dest) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onQuickJourneySelected(origin, dest)
                                onFindTrains()
                            }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${origin.name} → ${dest.name}",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = "Select →",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = BritishRailRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SecondaryServiceCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, BritishRailBlack)
            .background(BritishRailWhite)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 9.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(RailGreyPanel)
                .border(1.dp, BritishRailBlack),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = BritishRailBlack, modifier = Modifier.size(22.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = BritishRailBlack
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = RailGreySubtext
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = BritishRailBlack,
            modifier = Modifier.size(16.dp)
        )
    }
}
