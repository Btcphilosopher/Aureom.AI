package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.Booking
import com.example.data.model.TicketIssuanceResult
import com.example.ui.TerminalUiState
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.components.BrLogo
import com.example.ui.components.QrCodeView
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext
import com.example.ui.theme.RailOrangeTicket
import com.example.ui.theme.RailTicketBuff

/**
 * Step 4: Your Ticket & Receipt Screen.
 */
@Composable
fun TicketScreen(
    state: TerminalUiState,
    onPrintTicket: () -> Unit,
    onPrintReceipt: () -> Unit,
    onShowReceiptDialog: () -> Unit,
    onDismissReceiptDialog: () -> Unit,
    onRetryIssuance: () -> Unit,
    onFinishSession: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val isWelsh = lang == AppLanguage.CYMRAEG
    val booking = state.activeBooking
    val ticketResult = state.ticketIssuanceResult
    val isPendingIssuance = ticketResult is TicketIssuanceResult.Pending

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(BritishRailWhite)
            .padding(horizontal = 18.dp, vertical = 10.dp)
            .testTag("ticket_screen")
    ) {
        // ================= LEFT: AUTHENTIC BRITISH RAIL TICKET CARD =================
        Column(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(end = 16.dp)
        ) {
            Text(
                text = when {
                    isPendingIssuance -> if (isWelsh) "Taliad wedi'i gadarnhau — cyhoeddi tocyn yn aros" else "Payment confirmed — ticket issuance pending"
                    else -> if (isWelsh) "Mae eich tocyn yn barod" else "Your ticket is ready"
                },
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                color = BritishRailBlack
            )
            Text(
                text = when {
                    isPendingIssuance -> "Your payment succeeded (${booking?.paymentAuthCode ?: ""}), but ticket generation is queued. Retry below without paying again."
                    else -> if (isWelsh) "Cymerwch eich tocyn printiedig isod neu sganiwch y cod QR" else "Collect printed card ticket from dispenser or use QR code at automatic gates"
                },
                fontSize = 13.sp,
                color = RailGreySubtext
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (isPendingIssuance && booking != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, BritishRailRed)
                        .background(Color(0xFFFFECEE))
                        .padding(16.dp)
                        .testTag("ticket_issuance_pending_card")
                ) {
                    Text(
                        text = "BOOKING CONFIRMED • ISSUANCE PENDING",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = BritishRailRed
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = (ticketResult as TicketIssuanceResult.Pending).reason,
                        fontSize = 14.sp,
                        color = BritishRailBlack
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Reference: ${booking.bookingReference} • Auth: ${booking.paymentAuthCode} • Total Paid: ${booking.formattedPrice}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BritishRailBlack
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    BrButton(
                        text = if (state.isRetryingIssuance) "Retrying ticket issuance..." else "Retry ticket issuance →",
                        onClick = onRetryIssuance,
                        enabled = !state.isRetryingIssuance,
                        style = BrButtonStyle.PRIMARY_RED,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "retry_issuance_button"
                    )
                }
            } else if (booking != null) {
                // Classic British Rail Ticket Design Card (Buff & Orange Header)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, BritishRailBlack)
                        .background(RailTicketBuff)
                        .testTag("british_rail_ticket_card")
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Ticket Header Bar: British Rail Double Arrow + Watermark
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(RailOrangeTicket)
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BrLogo(size = 28.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "BRITISH RAILWAYS BOARD",
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = BritishRailBlack,
                                    letterSpacing = 1.sp
                                )
                            }
                            Text(
                                text = "NOT VALID FOR TRAVEL (DEMO)",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = BritishRailRed,
                                letterSpacing = 0.5.sp
                            )
                        }

                        // Ticket Main Body
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Left Details
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${booking.selectedFare.travelClass.displayName.uppercase()} CLASS",
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = BritishRailBlack
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${booking.journey.origin.name.uppercase()} [${booking.journey.origin.crsCode}]",
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    color = BritishRailBlack
                                )
                                Text(
                                    text = "TO ${booking.journey.destination.name.uppercase()} [${booking.journey.destination.crsCode}]",
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    color = BritishRailBlack
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "DATE: ${booking.travelDate.uppercase()} • ${booking.journey.departureTime} SERVICE",
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = BritishRailBlack
                                )
                                Text(
                                    text = "TICKET: ${booking.selectedFare.ticketType.displayName.uppercase()}",
                                    fontSize = 12.sp,
                                    color = BritishRailBlack
                                )
                                Text(
                                    text = "PASSENGERS: ${booking.passengers.summary(lang).uppercase()}",
                                    fontSize = 12.sp,
                                    color = BritishRailBlack
                                )
                                Text(
                                    text = "SEAT: ${booking.seatReservation.uppercase()}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B5E20)
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                    Column {
                                        Text("BOOKING REF", fontSize = 10.sp, color = RailGreySubtext, fontWeight = FontWeight.Bold)
                                        Text(booking.bookingReference, fontFamily = RailAlphabetFontFamily, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                    Column {
                                        Text("COLLECTION CODE", fontSize = 10.sp, color = RailGreySubtext, fontWeight = FontWeight.Bold)
                                        Text(booking.collectionCode, fontFamily = RailAlphabetFontFamily, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                    Column {
                                        Text("PRICE", fontSize = 10.sp, color = RailGreySubtext, fontWeight = FontWeight.Bold)
                                        Text(booking.formattedPrice, fontFamily = RailAlphabetFontFamily, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Right: High-contrast 2D QR Code Canvas
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                val qrPayload = (ticketResult as? TicketIssuanceResult.Issued)?.qrData
                                    ?: "BR-DEMO-${booking.bookingReference}"
                                QrCodeView(
                                    dataPayload = qrPayload,
                                    qrBoxSize = 130.dp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("SCAN AT GATE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BritishRailBlack)
                            }
                        }

                        // Bottom magnetic stripe band simulation
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(16.dp)
                                .background(Color(0xFF222222))
                        )
                    }
                }
            }
        }

        // Vertical divider
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(BritishRailBlack)
        )

        // ================= RIGHT: FULFILLMENT & ACTIONS =================
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(start = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = if (isWelsh) "Argraffu a Chwblhau" else "Print & options",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    color = BritishRailBlack
                )
                Text(
                    text = if (isWelsh) "Argraffwch eich tocyn a chael derbynneb TAW" else "Choose how you want your physical demonstration ticket",
                    fontSize = 13.sp,
                    color = RailGreySubtext
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Print Ticket Action
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, BritishRailBlack)
                        .background(BritishRailWhite)
                        .clickable { onPrintTicket() }
                        .padding(12.dp)
                        .testTag("action_print_ticket"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Print, contentDescription = null, tint = BritishRailBlack, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isWelsh) "Argraffu tocyn cardbord" else "Print physical ticket",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = BritishRailBlack
                        )
                        Text("Dispatches to terminal collection tray", fontSize = 12.sp, color = RailGreySubtext)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // View & Print Receipt Action
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, BritishRailBlack)
                        .background(BritishRailWhite)
                        .clickable { onShowReceiptDialog() }
                        .padding(12.dp)
                        .testTag("action_view_receipt"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Receipt, contentDescription = null, tint = BritishRailBlack, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isWelsh) "Gweld derbynneb TAW" else "View itemized VAT receipt",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = BritishRailBlack
                        )
                        Text("Contains merchant details and VAT breakdown", fontSize = 12.sp, color = RailGreySubtext)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Printer Animation / Status Feedback
                if (state.isPrinting) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, BritishRailRed)
                            .background(Color(0xFFFFECEE))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(color = BritishRailRed, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = state.printMessage ?: "Printing...",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = BritishRailRed
                            )
                        }
                    }
                } else if (state.printMessage != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, Color(0xFF2E7D32))
                            .background(Color(0xFFE8F5E9))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = state.printMessage,
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF2E7D32)
                            )
                        }
                    }
                }
            }

            // Finish session button
            Column {
                BrButton(
                    text = if (isWelsh) "Gorffen a dychwelyd i'r hafan" else "Finish & return to home",
                    onClick = onFinishSession,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    style = BrButtonStyle.PRIMARY_RED,
                    testTag = "finish_session_button"
                )
            }
        }
    }

    // Itemized VAT Receipt Modal Dialog
    if (state.showReceiptDialog && booking != null) {
        ReceiptModalDialog(
            booking = booking,
            onDismiss = onDismissReceiptDialog,
            onPrint = onPrintReceipt
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiptModalDialog(
    booking: Booking,
    onDismiss: () -> Unit,
    onPrint: () -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth(0.75f)
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(20.dp)
            .testTag("vat_receipt_dialog")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Customer VAT Receipt",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = BritishRailBlack
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.5.dp)
                    .background(BritishRailBlack)
            )
            Spacer(modifier = Modifier.height(10.dp))

            Text("BRITISH RAILWAYS BOARD", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("Terminal #4029 - Sheffield Station Concourse", fontSize = 12.sp, color = RailGreySubtext)
            Text("VAT Registration No: GB 239 8810 44", fontSize = 12.sp, color = RailGreySubtext)

            Spacer(modifier = Modifier.height(12.dp))

            Text("Booking Ref: ${booking.bookingReference}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Journey: ${booking.journey.origin.name} to ${booking.journey.destination.name}", fontSize = 13.sp)
            Text("Date: ${booking.travelDate} (${booking.journey.departureTime})", fontSize = 13.sp)
            Text("Class: ${booking.selectedFare.travelClass.displayName}", fontSize = 13.sp)
            Text("Ticket: ${booking.selectedFare.ticketType.displayName}", fontSize = 13.sp)

            Spacer(modifier = Modifier.height(8.dp))
            Text("Payment: CONTACTLESS (Auth Code: ${booking.paymentAuthCode})", fontSize = 13.sp)
            Text("Total Paid (VAT 0% Rail Passenger Fare): ${booking.formattedPrice}", fontWeight = FontWeight.Bold, fontSize = 16.sp)

            Spacer(modifier = Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrButton(
                    text = "Print receipt",
                    onClick = {
                        onPrint()
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                    style = BrButtonStyle.SECONDARY_BLACK
                )
                BrButton(
                    text = "Close",
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    style = BrButtonStyle.OUTLINED
                )
            }
        }
    }
}
