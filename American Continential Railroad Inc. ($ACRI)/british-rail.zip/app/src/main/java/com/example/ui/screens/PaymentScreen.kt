package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.PaymentMethod
import com.example.data.model.SimulatedPaymentOutcome
import com.example.ui.TerminalUiState
import com.example.ui.components.BrButton
import com.example.ui.components.BrButtonStyle
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

/**
 * Step 3: Payment Screen.
 * Implements kiosk payment terminal interface with test adapters.
 */
@Composable
fun PaymentScreen(
    state: TerminalUiState,
    onSelectPaymentMethod: (PaymentMethod) -> Unit,
    onSelectOutcome: (SimulatedPaymentOutcome) -> Unit,
    onToggleIssuancePending: (Boolean) -> Unit,
    onConfirmPayment: () -> Unit,
    onBackToTrains: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val isWelsh = lang == AppLanguage.CYMRAEG
    val booking = state.activeBooking
    val fare = state.selectedFare
    val breakdown = state.fareBreakdown

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(BritishRailWhite)
            .padding(horizontal = 18.dp, vertical = 10.dp)
            .testTag("payment_screen")
    ) {
        // ================= LEFT COLUMN: JOURNEY & TICKET CONDITIONS =================
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(end = 16.dp)
        ) {
            Text(
                text = if (isWelsh) "Adolygu eich archeb" else "Review your journey",
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                color = BritishRailBlack
            )
            Text(
                text = if (isWelsh) "Gwiriwch fanylion y daith a thelerau'r tocyn" else "Check service details and ticket restrictions before payment",
                fontSize = 13.sp,
                color = RailGreySubtext
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Journey summary box
            if (booking != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, BritishRailBlack)
                        .background(BritishRailWhite)
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${booking.journey.origin.name} → ${booking.journey.destination.name}",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = BritishRailBlack
                        )
                        Text(
                            text = booking.formattedPrice,
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = BritishRailBlack
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${booking.travelDate} • Depart ${booking.journey.departureTime} → Arrive ${booking.journey.arrivalTime} (${booking.journey.durationStr})",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp,
                        color = BritishRailBlack
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Seat: ${booking.seatReservation}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B5E20)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Ticket conditions box
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RailGreyPanel)
                        .border(1.5.dp, BritishRailBlack)
                        .padding(14.dp)
                ) {
                    Text(
                        text = if (isWelsh) "TELERAU A CHYFYNGIADAU'R TOCYN" else "TICKET CONDITIONS & RESTRICTIONS",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = BritishRailBlack,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• ${booking.selectedFare.ticketType.displayName} (${booking.selectedFare.travelClass.displayName})",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = BritishRailBlack
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "• ${booking.selectedFare.restrictions}",
                        fontSize = 13.sp,
                        color = BritishRailBlack
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "• ${booking.selectedFare.ticketType.defaultRefundPolicy}",
                        fontSize = 13.sp,
                        color = RailGreySubtext
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Itemized Price Breakdown
                if (breakdown != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, BritishRailBlack)
                            .padding(14.dp)
                    ) {
                        Text(
                            text = if (isWelsh) "DADRANIAD PRIS" else "PRICE BREAKDOWN",
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = RailGreySubtext,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        BreakdownRow("Base adult fare (${state.passengers.adults} adult)", breakdown.baseAdultPence)
                        if (state.passengers.children > 0) {
                            BreakdownRow("Child fare (${state.passengers.children} child)", breakdown.baseChildPence)
                        }
                        if (breakdown.railcardDiscountPence > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Railcard discount (${state.passengers.railcard.englishName})",
                                    fontSize = 13.sp,
                                    color = BritishRailRed,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "-${com.example.data.model.formatPence(breakdown.railcardDiscountPence)}",
                                    fontSize = 13.sp,
                                    color = BritishRailRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        BreakdownRow("Seat reservation", 0, "Free")
                        BreakdownRow("Kiosk booking fee", 0, "£0.00")

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.5.dp)
                                .padding(vertical = 4.dp)
                                .background(BritishRailBlack)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isWelsh) "Cyfanswm i'w dalu" else "Total payable",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = BritishRailBlack
                            )
                            Text(
                                text = breakdown.formattedTotal,
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = BritishRailBlack
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Back button
            BrButton(
                text = if (isWelsh) "← Yn ôl i ddewis trên" else "← Back to train selection",
                onClick = onBackToTrains,
                style = BrButtonStyle.OUTLINED,
                modifier = Modifier.fillMaxWidth(0.6f),
                testTag = "back_to_trains_button"
            )
        }

        // Vertical divider
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(BritishRailBlack)
        )

        // ================= RIGHT COLUMN: PAYMENT TERMINAL INTERFACE =================
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(start = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = if (isWelsh) "Dull talu" else "Payment method",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    color = BritishRailBlack
                )
                Text(
                    text = if (isWelsh) "Dewiswch sut hoffech chi dalu" else "Select how you would like to pay at this kiosk",
                    fontSize = 13.sp,
                    color = RailGreySubtext
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Payment method choices
                PaymentMethodOption(
                    title = if (isWelsh) "Taliad digyswllt" else "Contactless Card / Device",
                    subtitle = "Visa, Mastercard, Apple Pay, Google Pay",
                    icon = Icons.Default.Contactless,
                    isSelected = state.selectedPaymentMethod == PaymentMethod.CONTACTLESS,
                    onSelect = { onSelectPaymentMethod(PaymentMethod.CONTACTLESS) },
                    testTag = "pay_method_contactless"
                )

                Spacer(modifier = Modifier.height(8.dp))

                PaymentMethodOption(
                    title = if (isWelsh) "Cerdyn Chip & PIN" else "Chip & PIN card",
                    subtitle = "Insert card into terminal slot below",
                    icon = Icons.Default.CreditCard,
                    isSelected = state.selectedPaymentMethod == PaymentMethod.CHIP_PIN,
                    onSelect = { onSelectPaymentMethod(PaymentMethod.CHIP_PIN) },
                    testTag = "pay_method_chip_pin"
                )

                Spacer(modifier = Modifier.height(8.dp))

                PaymentMethodOption(
                    title = if (isWelsh) "Arian parod / Taleb" else "Cash / Terminal voucher",
                    subtitle = "Notes and coins accepted at machine base",
                    icon = Icons.Default.Payments,
                    isSelected = state.selectedPaymentMethod == PaymentMethod.CASH_KIOSK,
                    onSelect = { onSelectPaymentMethod(PaymentMethod.CASH_KIOSK) },
                    testTag = "pay_method_cash"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Demonstration Outcome Selector (Required by Section 7 & 13)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RailGreyPanel)
                        .border(1.dp, Color(0xFF888888))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "DEMONSTRATION PAYMENT OUTCOME",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BritishRailBlack,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutcomeChip("Approved", SimulatedPaymentOutcome.SUCCESS, state.simulatedOutcome, onSelectOutcome)
                        OutcomeChip("Decline", SimulatedPaymentOutcome.DECLINED, state.simulatedOutcome, onSelectOutcome)
                        OutcomeChip("Timeout", SimulatedPaymentOutcome.TIMEOUT, state.simulatedOutcome, onSelectOutcome)
                        OutcomeChip("Cancel", SimulatedPaymentOutcome.CANCELLED, state.simulatedOutcome, onSelectOutcome)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (state.forceIssuancePending) BritishRailRed else RailGreyBorder)
                            .background(if (state.forceIssuancePending) Color(0xFFFFECEE) else BritishRailWhite)
                            .clickable { onToggleIssuancePending(!state.forceIssuancePending) }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("toggle_issuance_pending"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Simulate delayed ticket issuance after approval",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.forceIssuancePending) BritishRailRed else BritishRailBlack
                        )
                        Text(
                            text = if (state.forceIssuancePending) "ON" else "OFF",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.forceIssuancePending) BritishRailRed else RailGreySubtext
                        )
                    }
                }
            }

            // Payment Action Box / Status
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // If error occurred (e.g. decline or timeout)
                if (state.paymentError != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(2.dp, BritishRailRed)
                            .background(Color(0xFFFFECEE))
                            .padding(12.dp)
                            .testTag("payment_error_banner")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = BritishRailRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Payment unsuccesful",
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = BritishRailRed
                                )
                                Text(
                                    text = state.paymentError,
                                    fontSize = 12.sp,
                                    color = BritishRailBlack
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // If processing payment
                if (state.isProcessingPayment) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(2.dp, BritishRailBlack)
                            .background(BritishRailWhite)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = BritishRailRed, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = state.paymentStatusMessage ?: "Communicating with payment terminal...",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = BritishRailBlack
                            )
                        }
                    }
                } else {
                    // Main Pay Button
                    val totalStr = booking?.formattedPrice ?: "£56.00"
                    BrButton(
                        text = if (isWelsh) "Talu $totalStr nawr →" else "Pay $totalStr now →",
                        onClick = onConfirmPayment,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        style = BrButtonStyle.PRIMARY_RED,
                        testTag = "confirm_payment_button"
                    )
                }
            }
        }
    }
}

@Composable
private fun BreakdownRow(label: String, pence: Int, overrideText: String? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 13.sp, color = BritishRailBlack)
        Text(
            text = overrideText ?: com.example.data.model.formatPence(pence),
            fontSize = 13.sp,
            color = BritishRailBlack,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun PaymentMethodOption(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onSelect: () -> Unit,
    testTag: String
) {
    val borderColor = if (isSelected) BritishRailRed else BritishRailBlack
    val borderWidth = if (isSelected) 2.5.dp else 1.5.dp
    val bg = if (isSelected) Color(0xFFFFECEE) else BritishRailWhite

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(borderWidth, borderColor)
            .background(bg)
            .clickable { onSelect() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isSelected) BritishRailRed else BritishRailBlack,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = if (isSelected) BritishRailRed else BritishRailBlack
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = RailGreySubtext
            )
        }
        if (isSelected) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Selected",
                tint = BritishRailRed,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun OutcomeChip(
    label: String,
    outcome: SimulatedPaymentOutcome,
    selectedOutcome: SimulatedPaymentOutcome,
    onSelect: (SimulatedPaymentOutcome) -> Unit
) {
    val isSel = outcome == selectedOutcome
    Box(
        modifier = Modifier
            .border(1.dp, if (isSel) BritishRailRed else RailGreyBorder)
            .background(if (isSel) BritishRailRed else BritishRailWhite)
            .clickable { onSelect(outcome) }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("outcome_${outcome.name}"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSel) BritishRailWhite else BritishRailBlack
        )
    }
}
