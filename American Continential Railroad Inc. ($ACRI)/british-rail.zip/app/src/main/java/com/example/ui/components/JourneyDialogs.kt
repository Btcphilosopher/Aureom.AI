package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.PassengerConfig
import com.example.data.model.RailcardType
import com.example.data.model.Station
import com.example.data.model.StationAccessibilityInfo
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

/**
 * Station search dialog for terminal touchscreen use.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationSearchDialog(
    title: String,
    stations: List<Station>,
    recentStations: List<Station>,
    onStationSelected: (Station) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredStations = remember(searchQuery, stations) {
        if (searchQuery.isBlank()) stations
        else stations.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.crsCode.contains(searchQuery, ignoreCase = true)
        }
    }

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth(0.85f)
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(20.dp)
            .testTag("station_search_dialog")
    ) {
        Column {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = BritishRailBlack
                )
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_station_dialog")) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search text box
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Type station name or 3-letter code (e.g. SHF, STP)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BritishRailBlack) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("station_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BritishRailBlack,
                    unfocusedBorderColor = RailGreyBorder,
                    focusedTextColor = BritishRailBlack,
                    unfocusedTextColor = BritishRailBlack
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Quick picks / Recents
            if (searchQuery.isBlank()) {
                Text(
                    text = "RECENT & POPULAR STATIONS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = RailGreySubtext,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    recentStations.take(4).forEach { station ->
                        Box(
                            modifier = Modifier
                                .border(1.dp, BritishRailBlack)
                                .clickable {
                                    onStationSelected(station)
                                    onDismiss()
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = station.name,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = BritishRailBlack
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Results list
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 280.dp)
            ) {
                if (filteredStations.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No stations found matching \"$searchQuery\"",
                                color = RailGreySubtext,
                                fontSize = 15.sp
                            )
                        }
                    }
                } else {
                    items(filteredStations) { station ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(0.5.dp, RailGreyBorder)
                                .clickable {
                                    onStationSelected(station)
                                    onDismiss()
                                }
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                                .testTag("station_item_${station.crsCode}"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = station.name,
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = BritishRailBlack
                                )
                                if (station.isStepFree) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "♿ Step-free",
                                        fontSize = 12.sp,
                                        color = Color(0xFF2E7D32),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .background(RailGreyPanel)
                                    .border(1.dp, BritishRailBlack)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = station.crsCode,
                                    fontFamily = RailAlphabetFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = BritishRailBlack
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Passenger and Railcard configuration dialog.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PassengerConfigDialog(
    initialConfig: PassengerConfig,
    language: AppLanguage,
    onConfirmed: (PassengerConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var adults by remember { mutableIntStateOf(initialConfig.adults) }
    var children by remember { mutableIntStateOf(initialConfig.children) }
    var railcard by remember { mutableStateOf(initialConfig.railcard) }

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth(0.85f)
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(20.dp)
            .testTag("passenger_dialog")
    ) {
        Column {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (language == AppLanguage.CYMRAEG) "Teithwyr a Cherdyn Rheilffordd" else "Passengers & Railcards",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = BritishRailBlack
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Adults row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Oedolion (16+ oed)" else "Adults (aged 16+)",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = BritishRailBlack
                    )
                    Text("Standard passenger fare", fontSize = 12.sp, color = RailGreySubtext)
                }
                StepperControl(
                    value = adults,
                    minValue = 1,
                    maxValue = 8,
                    onValueChange = { adults = it },
                    tagPrefix = "adults"
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(RailGreyBorder)
            )

            // Children row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Plant (5-15 oed)" else "Children (aged 5-15)",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = BritishRailBlack
                    )
                    Text("50% discount on standard fares", fontSize = 12.sp, color = RailGreySubtext)
                }
                StepperControl(
                    value = children,
                    minValue = 0,
                    maxValue = 8,
                    onValueChange = { children = it },
                    tagPrefix = "children"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Railcard Selection
            Text(
                text = if (language == AppLanguage.CYMRAEG) "DEWIS CERDYN RHEILFFORDD" else "SELECT RAILCARD (1/3 OFF FARES)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = RailGreySubtext,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 180.dp)
            ) {
                items(RailcardType.values()) { card ->
                    val isSelected = railcard == card
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (isSelected) BritishRailRed else RailGreyBorder)
                            .background(if (isSelected) Color(0xFFFFEEEE) else BritishRailWhite)
                            .clickable { railcard = card }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("railcard_option_${card.name}"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = card.getLocalizedName(language),
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 15.sp,
                            color = if (isSelected) BritishRailRed else BritishRailBlack
                        )
                        if (isSelected) {
                            Text("✓ Selected", color = BritishRailRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Confirm Button
            BrButton(
                text = if (language == AppLanguage.CYMRAEG) "Cadarnhau teithwyr" else "Confirm passengers",
                onClick = {
                    onConfirmed(PassengerConfig(adults = adults, children = children, railcard = railcard))
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                testTag = "confirm_passengers_button"
            )
        }
    }
}

@Composable
fun StepperControl(
    value: Int,
    minValue: Int,
    maxValue: Int,
    onValueChange: (Int) -> Unit,
    tagPrefix: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .border(2.dp, BritishRailBlack)
                .background(if (value > minValue) BritishRailWhite else RailGreyPanel)
                .clickable(enabled = value > minValue) { onValueChange(value - 1) }
                .testTag("${tagPrefix}_minus"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "−",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = if (value > minValue) BritishRailBlack else RailGreyBorder
            )
        }

        Box(
            modifier = Modifier
                .width(44.dp)
                .height(40.dp)
                .border(2.dp, BritishRailBlack)
                .background(BritishRailWhite),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = value.toString(),
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = BritishRailBlack
            )
        }

        Box(
            modifier = Modifier
                .size(40.dp)
                .border(2.dp, BritishRailBlack)
                .background(if (value < maxValue) BritishRailWhite else RailGreyPanel)
                .clickable(enabled = value < maxValue) { onValueChange(value + 1) }
                .testTag("${tagPrefix}_plus"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "+",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = if (value < maxValue) BritishRailBlack else RailGreyBorder
            )
        }
    }
}

/**
 * Station Accessibility Guide dialog.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessibilityInfoDialog(
    infoList: List<StationAccessibilityInfo>,
    onDismiss: () -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth(0.9f)
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "♿ Step-Free Station Accessibility & Assistance",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = BritishRailBlack
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = BritishRailBlack)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RailGreyPanel)
                    .border(1.dp, BritishRailBlack)
                    .padding(10.dp)
            ) {
                Column {
                    Text(
                        text = "ROUTE PREFERENCE VS. CONFIRMED PASSENGER ASSISTANCE",
                        fontFamily = RailAlphabetFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = BritishRailBlack
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Selecting a step-free route preference filters stations with verified step-free data. Stations not listed below have UNKNOWN access status. This terminal does not create a confirmed Passenger Assist booking.",
                        fontSize = 12.sp,
                        color = BritishRailBlack
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 300.dp)
            ) {
                items(infoList) { info ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BritishRailBlack)
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${info.stationName} [${info.stationCrs}]",
                                fontFamily = RailAlphabetFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = BritishRailBlack
                            )
                            Text(
                                text = "Category A",
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = info.stepFreeCategory, fontSize = 13.sp, color = BritishRailBlack)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (info.staffAssistanceAvailable) Text("• Staff Assistance", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            if (info.inductionLoop) Text("• Hearing Loop", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            if (info.accessibleToilets) Text("• Accessible WC", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = info.notes, fontSize = 12.sp, color = RailGreySubtext)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            BrButton(
                text = "Close guide",
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                style = BrButtonStyle.SECONDARY_BLACK
            )
        }
    }
}
