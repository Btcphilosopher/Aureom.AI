package com.example.data.model

import java.util.Locale

/**
 * Representation of a British Rail station.
 */
data class Station(
    val crsCode: String, // 3-letter CRS code, e.g. "SHF", "STP"
    val name: String,
    val isStepFree: Boolean = true,
    val hasHearingLoop: Boolean = true,
    val hasAccessibleToilet: Boolean = true,
    val interchangeTimeMinutes: Int = 5,
    val isPopular: Boolean = false
) {
    val displayName: String get() = "$name [$crsCode]"
}

enum class RailcardType(
    val englishName: String,
    val welshName: String,
    val discountPercent: Int
) {
    NONE("No railcard", "Dim cerdyn rheilffordd", 0),
    SIXTEEN_TO_TWENTY_FIVE("16-25 Railcard", "Cerdyn Rheilffordd 16-25", 34),
    TWO_TOGETHER("Two Together Railcard", "Cerdyn Rheilffordd Dau Gyda'n Gilydd", 34),
    SENIOR("Senior Railcard", "Cerdyn Rheilffordd Hŷn", 34),
    DISABLED_PERSONS("Disabled Persons Railcard", "Cerdyn Rheilffordd Personau Anabl", 34),
    NETWORK("Network Railcard", "Cerdyn Rheilffordd Network", 34),
    FAMILY_AND_FRIENDS("Family & Friends Railcard", "Cerdyn Rheilffordd Teulu a Ffrindiau", 34);

    fun getLocalizedName(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshName else englishName
}

enum class TravelClass(val displayName: String, val welshName: String) {
    STANDARD("Standard", "Safonol"),
    FIRST("First Class", "Dosbarth Cyntaf");

    fun getLocalizedName(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshName else displayName
}

enum class TicketType(
    val displayName: String,
    val welshName: String,
    val isTrainSpecific: Boolean,
    val isReturn: Boolean,
    val defaultRestrictions: String,
    val defaultRefundPolicy: String
) {
    ADVANCE_SINGLE(
        displayName = "Advance single",
        welshName = "Sengl Ymlaen Llaw",
        isTrainSpecific = true,
        isReturn = false,
        defaultRestrictions = "Valid only on the booked date and specified train service.",
        defaultRefundPolicy = "Non-refundable. Changes allowed before departure for an administration fee."
    ),
    OFF_PEAK_SINGLE(
        displayName = "Off-Peak single",
        welshName = "Sengl Oriau Tawel",
        isTrainSpecific = false,
        isReturn = false,
        defaultRestrictions = "Valid on any off-peak service via booked route.",
        defaultRefundPolicy = "Refundable before travel minus £10 administration fee."
    ),
    ANYTIME_SINGLE(
        displayName = "Anytime single",
        welshName = "Sengl Unrhyw Bryd",
        isTrainSpecific = false,
        isReturn = false,
        defaultRestrictions = "Valid on any train on the travel date.",
        defaultRefundPolicy = "Fully refundable before travel with no fee."
    ),
    OFF_PEAK_RETURN(
        displayName = "Off-Peak return",
        welshName = "Dychwelyd Oriau Tawel",
        isTrainSpecific = false,
        isReturn = true,
        defaultRestrictions = "Outward valid on date shown off-peak; return valid within 1 calendar month off-peak.",
        defaultRefundPolicy = "Refundable before outward journey minus fee."
    ),
    ANYTIME_RETURN(
        displayName = "Anytime return",
        welshName = "Dychwelyd Unrhyw Bryd",
        isTrainSpecific = false,
        isReturn = true,
        defaultRestrictions = "Outward valid 5 days; return valid within 1 calendar month on any train.",
        defaultRefundPolicy = "Fully refundable before travel."
    );

    fun getLocalizedName(language: AppLanguage): String =
        if (language == AppLanguage.CYMRAEG) welshName else displayName
}

data class PassengerConfig(
    val adults: Int = 1,
    val children: Int = 0,
    val railcard: RailcardType = RailcardType.NONE
) {
    val totalPassengers: Int get() = adults + children

    fun summary(language: AppLanguage = AppLanguage.ENGLISH): String {
        val adultStr = if (adults == 1) {
            if (language == AppLanguage.CYMRAEG) "1 oedolyn" else "1 adult"
        } else {
            if (language == AppLanguage.CYMRAEG) "$adults oedolion" else "$adults adults"
        }

        val childStr = if (children > 0) {
            if (children == 1) {
                if (language == AppLanguage.CYMRAEG) " • 1 plentyn" else " • 1 child"
            } else {
                if (language == AppLanguage.CYMRAEG) " • $children plant" else " • $children children"
            }
        } else ""

        val railcardStr = if (railcard != RailcardType.NONE) {
            " • " + railcard.getLocalizedName(language)
        } else {
            if (language == AppLanguage.CYMRAEG) " • Dim cerdyn" else " • No railcard"
        }

        return "$adultStr$childStr$railcardStr"
    }
}

data class JourneyLeg(
    val originStation: String,
    val destinationStation: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationStr: String,
    val operator: String = "East Midlands Railway",
    val platform: String = "2"
)

data class ServiceFare(
    val id: String,
    val ticketType: TicketType,
    val travelClass: TravelClass,
    val pricePence: Int,
    val isAvailable: Boolean = true,
    val quotaRemaining: Int = 8,
    val customRestrictions: String? = null
) {
    val formattedPrice: String get() = formatPence(pricePence)
    val restrictions: String get() = customRestrictions ?: ticketType.defaultRestrictions
}

data class JourneyOption(
    val id: String,
    val origin: Station,
    val destination: Station,
    val departureTime: String, // e.g. "13:15"
    val arrivalTime: String,   // e.g. "15:20"
    val durationStr: String,   // e.g. "2h 05m"
    val changes: Int = 0,      // 0 = Direct
    val legs: List<JourneyLeg> = emptyList(),
    val fares: List<ServiceFare> = emptyList(),
    val isOvernight: Boolean = false,
    val callingPoints: List<String> = emptyList()
) {
    val routeSummary: String
        get() = if (changes == 0) "Direct" else if (changes == 1) "1 change" else "$changes changes"
}

data class FareBreakdown(
    val baseAdultPence: Int,
    val baseChildPence: Int,
    val railcardDiscountPence: Int,
    val ticketFarePence: Int,
    val seatReservationPence: Int = 0,
    val bookingFeePence: Int = 0,
    val totalPence: Int
) {
    val formattedTotal: String get() = formatPence(totalPence)
}

enum class BookingStatus {
    PENDING_PAYMENT,
    CONFIRMED,
    TICKET_ISSUED,
    PENDING_ISSUANCE,
    COLLECTED,
    CANCELLED
}

data class Booking(
    val bookingReference: String, // e.g. "BR-89241-SHF"
    val collectionCode: String,   // 8 chars, e.g. "BR89241S"
    val journey: JourneyOption,
    val selectedFare: ServiceFare,
    val passengers: PassengerConfig,
    val travelDate: String,       // e.g. "Thu 12 Nov 2026"
    val totalPence: Int,
    val paymentAuthCode: String = "",
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val isCollected: Boolean = false,
    val status: BookingStatus = BookingStatus.CONFIRMED,
    val seatReservation: String = "Coach C, Seat 42 (Window, Forward-facing)"
) {
    val formattedPrice: String get() = formatPence(totalPence)
}

enum class PaymentMethod(val displayName: String, val welshName: String) {
    CONTACTLESS("Contactless payment", "Taliad digyswllt"),
    CHIP_PIN("Chip & PIN card", "Cerdyn Chip & PIN"),
    CASH_KIOSK("Cash / Terminal voucher", "Arian parod / Taleb terfynell")
}

enum class SimulatedPaymentOutcome {
    SUCCESS,
    DECLINED,
    TIMEOUT,
    CANCELLED
}

data class PaymentRequest(
    val bookingReference: String,
    val amountPence: Int,
    val method: PaymentMethod,
    val simulatedOutcome: SimulatedPaymentOutcome = SimulatedPaymentOutcome.SUCCESS
)

sealed class PaymentResult {
    data class Success(val authCode: String, val transactionId: String) : PaymentResult()
    data class Declined(val reason: String) : PaymentResult()
    object Timeout : PaymentResult()
    object Cancelled : PaymentResult()
}

sealed class TicketIssuanceResult {
    data class Issued(val ticketPayload: String, val qrData: String) : TicketIssuanceResult()
    data class Pending(val reason: String) : TicketIssuanceResult()
    data class Failed(val error: String) : TicketIssuanceResult()
}

data class StationAccessibilityInfo(
    val stationCrs: String,
    val stationName: String,
    val stepFreeCategory: String, // "Category A: Step-free access to all platforms via lifts"
    val staffAssistanceAvailable: Boolean,
    val inductionLoop: Boolean,
    val accessibleToilets: Boolean,
    val rampAvailable: Boolean,
    val tactilePaving: Boolean,
    val notes: String
)

enum class AppLanguage {
    ENGLISH,
    CYMRAEG
}

/**
 * Monetary formatting utility for integer pence values.
 */
fun formatPence(pence: Int): String {
    val pounds = pence / 100
    val remainder = kotlin.math.abs(pence % 100)
    return String.format(Locale.UK, "£%d.%02d", pounds, remainder)
}
