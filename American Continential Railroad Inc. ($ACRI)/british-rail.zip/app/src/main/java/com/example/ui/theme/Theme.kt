package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val BritishRailColorScheme = lightColorScheme(
    primary = BritishRailRed,
    onPrimary = BritishRailWhite,
    primaryContainer = BritishRailRedLight,
    onPrimaryContainer = BritishRailBlack,
    secondary = BritishRailBlack,
    onSecondary = BritishRailWhite,
    tertiary = BritishRailOffBlack,
    onTertiary = BritishRailWhite,
    background = BritishRailWhite,
    onBackground = BritishRailBlack,
    surface = BritishRailWhite,
    onSurface = BritishRailBlack,
    surfaceVariant = RailGreyPanel,
    onSurfaceVariant = BritishRailBlack,
    outline = BritishRailBlack,
    outlineVariant = RailGreyBorder
)

@Composable
fun BritishRailTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = BritishRailColorScheme,
        typography = RailTypography,
        content = content
    )
}
