package com.example.data.repository

import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.FareBreakdown
import com.example.data.model.JourneyLeg
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.PaymentRequest
import com.example.data.model.PaymentResult
import com.example.data.model.RailcardType
import com.example.data.model.ServiceFare
import com.example.data.model.SimulatedPaymentOutcome
import com.example.data.model.Station
import com.example.data.model.StationAccessibilityInfo
import com.example.data.model.TicketIssuanceResult
import com.example.data.model.TicketType
import com.example.data.model.TravelClass
import com.example.domain.AccessibilityDataProvider
import com.example.domain.BookingService
import com.example.domain.FareProvider
import com.example.domain.JourneyPlanner
import com.example.domain.PaymentAdapter
import com.example.domain.PrinterAdapter
import com.example.domain.StationRepository
import com.example.domain.TicketCollectionService
import com.example.domain.TicketIssuer
import com.example.domain.TimetableProvider
import kotlinx.coroutines.delay
import java.util.UUID

class StationRepositoryImpl : StationRepository {
    private val stations = listOf(
        Station("SHF", "Sheffield", isStepFree = true, isPopular = true),
        Station("STP", "London St Pancras", isStepFree = true, isPopular = true),
        Station("MAN", "Manchester Piccadilly", isStepFree = true, isPopular = true),
        Station("LDS", "Leeds", isStepFree = true, isPopular = true),
        Station("YRK", "York", isStepFree = true, isPopular = true),
        Station("BHM", "Birmingham New Street", isStepFree = true, isPopular = true),
        Station("EDB", "Edinburgh Waverley", isStepFree = true, isPopular = true),
        Station("DBY", "Derby", isStepFree = true, isPopular = true),
        Station("NOT", "Nottingham", isStepFree = true, isPopular = true),
        Station("NCL", "Newcastle", isStepFree = true, isPopular = true),
        Station("BRI", "Bristol Temple Meads", isStepFree = true, isPopular = true),
        Station("CDF", "Cardiff Central", isStepFree = true, isPopular = true),
        Station("GLC", "Glasgow Central", isStepFree = true, isPopular = false),
        Station("LIV", "Liverpool Lime Street", isStepFree = true, isPopular = false),
        Station("CTR", "Chester", isStepFree = true, isPopular = false),
        Station("CRE", "Crewe", isStepFree = true, isPopular = false),
        Station("DON", "Doncaster", isStepFree = true, isPopular = false),
        Station("LEI", "Leicester", isStepFree = true, isPopular = false),
        Station("RDG", "Reading", isStepFree = true, isPopular = false),
        Station("CBG", "Cambridge", isStepFree = true, isPopular = false)
    )

    private val recentStations = mutableListOf(
        stations[0], // Sheffield
        stations[1], // London St Pancras
        stations[2], // Manchester Piccadilly
        stations[3]  // Leeds
    )

    override suspend fun getStations(): List<Station> = stations

    override suspend fun searchStations(query: String): List<Station> {
        val trimmed = query.trim().lowercase()
        if (trimmed.isEmpty()) return stations
        return stations.filter {
            it.name.lowercase().contains(trimmed) || it.crsCode.lowercase().contains(trimmed)
        }
    }

    override suspend fun getStationByCrs(crs: String): Station? {
        return stations.find { it.crsCode.equals(crs, ignoreCase = true) }
    }

    override suspend fun getRecentStations(): List<Station> = recentStations

    override suspend fun saveRecentStation(station: Station) {
        recentStations.removeAll { it.crsCode == station.crsCode }
        recentStations.add(0, station)
        if (recentStations.size > 6) {
            recentStations.removeAt(recentStations.lastIndex)
        }
    }
}

class FareProviderImpl : FareProvider {
    override fun calculateFare(
        baseSinglePence: Int,
        passengers: PassengerConfig,
        ticketType: TicketType,
        travelClass: TravelClass
    ): Int {
        val breakdown = getFareBreakdown(baseSinglePence, passengers, ticketType, travelClass)
        return breakdown.totalPence
    }

    override fun getFareBreakdown(
        baseFarePence: Int,
        passengers: PassengerConfig,
        ticketType: TicketType,
        travelClass: TravelClass
    ): FareBreakdown {
        var unitAdultPence = baseFarePence
        if (travelClass == TravelClass.FIRST) {
            unitAdultPence = (unitAdultPence * 16) / 10
        }
        if (ticketType.isReturn) {
            unitAdultPence = (unitAdultPence * 17) / 10
        }

        // Child fare is 50% of adult fare
        val unitChildPence = (unitAdultPence + 1) / 2

        var totalAdultPence = unitAdultPence * passengers.adults
        var totalChildPence = unitChildPence * passengers.children

        // Railcard discount applies to adults, and family/friends gives child discount
        var discountPence = 0
        if (passengers.railcard != RailcardType.NONE && passengers.railcard.discountPercent > 0) {
            val adultDiscount = (totalAdultPence * passengers.railcard.discountPercent) / 100
            val childDiscount = if (passengers.railcard == RailcardType.FAMILY_AND_FRIENDS) {
                (totalChildPence * 60) / 100 // Family & Friends gives 60% off child fares
            } else 0
            discountPence = adultDiscount + childDiscount
        }

        val ticketFarePence = (totalAdultPence + totalChildPence) - discountPence
        val totalPence = maxOf(0, ticketFarePence)

        return FareBreakdown(
            baseAdultPence = totalAdultPence,
            baseChildPence = totalChildPence,
            railcardDiscountPence = discountPence,
            ticketFarePence = ticketFarePence,
            seatReservationPence = 0,
            bookingFeePence = 0,
            totalPence = totalPence
        )
    }

    override fun getBreakdownForServiceFare(
        fare: ServiceFare,
        passengers: PassengerConfig,
        isReturn: Boolean
    ): FareBreakdown {
        // ServiceFare.pricePence already reflects ticketType & travelClass for 1 adult single.
        var unitAdultPence = fare.pricePence
        if (isReturn) {
            unitAdultPence = (unitAdultPence * 17) / 10
        }

        val unitChildPence = (unitAdultPence + 1) / 2
        val totalAdultPence = unitAdultPence * passengers.adults
        val totalChildPence = unitChildPence * passengers.children

        // Check railcard eligibility rules (never assume every railcard applies to every booking)
        var discountPence = 0
        val railcard = passengers.railcard
        val isEligible = when (railcard) {
            RailcardType.NONE -> false
            RailcardType.TWO_TOGETHER -> passengers.adults >= 2 && fare.travelClass == TravelClass.STANDARD
            RailcardType.FAMILY_AND_FRIENDS -> passengers.adults >= 1 && passengers.children >= 1
            RailcardType.NETWORK -> fare.ticketType != TicketType.ADVANCE_SINGLE
            RailcardType.SIXTEEN_TO_TWENTY_FIVE,
            RailcardType.SENIOR,
            RailcardType.DISABLED_PERSONS -> true
        }

        if (isEligible && railcard.discountPercent > 0) {
            val adultDiscount = (totalAdultPence * railcard.discountPercent) / 100
            val childDiscount = if (railcard == RailcardType.FAMILY_AND_FRIENDS) {
                (totalChildPence * 60) / 100
            } else 0
            discountPence = adultDiscount + childDiscount
        }

        val ticketFarePence = (totalAdultPence + totalChildPence) - discountPence
        val totalPence = maxOf(0, ticketFarePence)

        return FareBreakdown(
            baseAdultPence = totalAdultPence,
            baseChildPence = totalChildPence,
            railcardDiscountPence = discountPence,
            ticketFarePence = ticketFarePence,
            seatReservationPence = 0,
            bookingFeePence = 0,
            totalPence = totalPence
        )
    }
}

class TimetableProviderImpl(
    private val stationRepository: StationRepository,
    private val fareProvider: FareProvider
) : TimetableProvider {

    override suspend fun getServices(
        originCrs: String,
        destCrs: String,
        date: String,
        departAfterTime: String
    ): List<JourneyOption> {
        val origin = stationRepository.getStationByCrs(originCrs)
            ?: Station(originCrs, originCrs)
        val dest = stationRepository.getStationByCrs(destCrs)
            ?: Station(destCrs, destCrs)

        // Demonstrate explicit no-service state for late night cutoff or unsupported cross-country pair
        if (departAfterTime.contains("23:45") ||
            (originCrs.equals("GLC", ignoreCase = true) && destCrs.equals("CBG", ignoreCase = true))
        ) {
            return emptyList()
        }

        // If Sheffield -> London St Pancras, provide the exact services from the mockup reference
        val isSheffieldToLondon = originCrs.equals("SHF", ignoreCase = true) &&
                destCrs.equals("STP", ignoreCase = true)

        val rawServices = if (isSheffieldToLondon) {
            listOf(
                createService(
                    id = "SHF-STP-1315",
                    origin = origin,
                    dest = dest,
                    dep = "13:15",
                    arr = "15:20",
                    duration = "2h 05m",
                    changes = 0,
                    legs = listOf(JourneyLeg(origin.name, dest.name, "13:15", "15:20", "2h 05m")),
                    basePricePence = 4850,
                    callingPoints = listOf("Chesterfield", "Derby", "Leicester")
                ),
                createService(
                    id = "SHF-STP-1345",
                    origin = origin,
                    dest = dest,
                    dep = "13:45",
                    arr = "15:52",
                    duration = "2h 07m",
                    changes = 0,
                    legs = listOf(JourneyLeg(origin.name, dest.name, "13:45", "15:52", "2h 07m")),
                    basePricePence = 5600,
                    callingPoints = listOf("Chesterfield", "Derby", "Long Eaton", "Loughborough", "Leicester")
                ),
                createService(
                    id = "SHF-STP-1415",
                    origin = origin,
                    dest = dest,
                    dep = "14:15",
                    arr = "16:23",
                    duration = "2h 08m",
                    changes = 0,
                    legs = listOf(JourneyLeg(origin.name, dest.name, "14:15", "16:23", "2h 08m")),
                    basePricePence = 4400,
                    callingPoints = listOf("Chesterfield", "Derby", "Leicester")
                ),
                createService(
                    id = "SHF-STP-1445",
                    origin = origin,
                    dest = dest,
                    dep = "14:45",
                    arr = "17:10",
                    duration = "2h 25m",
                    changes = 1,
                    legs = listOf(
                        JourneyLeg(origin.name, "Derby", "14:45", "15:15", "30m", platform = "1B"),
                        JourneyLeg("Derby", dest.name, "15:30", "17:10", "1h 40m", platform = "2")
                    ),
                    basePricePence = 3950,
                    advanceSoldOut = true,
                    callingPoints = listOf("Chesterfield", "Derby [Change]", "Leicester", "Kettering")
                ),
                createService(
                    id = "SHF-STP-1515",
                    origin = origin,
                    dest = dest,
                    dep = "15:15",
                    arr = "17:22",
                    duration = "2h 07m",
                    changes = 0,
                    legs = listOf(JourneyLeg(origin.name, dest.name, "15:15", "17:22", "2h 07m")),
                    basePricePence = 5800,
                    callingPoints = listOf("Chesterfield", "Derby", "Leicester")
                ),
                createService(
                    id = "SHF-STP-2320",
                    origin = origin,
                    dest = dest,
                    dep = "23:20",
                    arr = "06:15",
                    duration = "6h 55m",
                    changes = 1,
                    legs = listOf(
                        JourneyLeg(origin.name, "Doncaster", "23:20", "23:50", "30m"),
                        JourneyLeg("Doncaster", dest.name, "00:45", "06:15", "5h 30m", operator = "Caledonian Sleeper Connect")
                    ),
                    basePricePence = 7200,
                    isOvernight = true,
                    callingPoints = listOf("Doncaster [Change]", "Peterborough", "London Kings Cross / St Pancras")
                )
            )
        } else {
            // General dynamic schedule generator for any UK city pair
            listOf(
                createService(
                    id = "${originCrs}-${destCrs}-1315",
                    origin = origin,
                    dest = dest,
                    dep = "13:15",
                    arr = "14:45",
                    duration = "1h 30m",
                    changes = 0,
                    legs = listOf(JourneyLeg(origin.name, dest.name, "13:15", "14:45", "1h 30m")),
                    basePricePence = 3250
                ),
                createService(
                    id = "${originCrs}-${destCrs}-1400",
                    origin = origin,
                    dest = dest,
                    dep = "14:00",
                    arr = "15:30",
                    duration = "1h 30m",
                    changes = 0,
                    legs = listOf(JourneyLeg(origin.name, dest.name, "14:00", "15:30", "1h 30m")),
                    basePricePence = 4100
                ),
                createService(
                    id = "${originCrs}-${destCrs}-1430",
                    origin = origin,
                    dest = dest,
                    dep = "14:30",
                    arr = "16:15",
                    duration = "1h 45m",
                    changes = 1,
                    legs = listOf(
                        JourneyLeg(origin.name, "Interchange Station", "14:30", "15:05", "35m"),
                        JourneyLeg("Interchange Station", dest.name, "15:20", "16:15", "55m")
                    ),
                    basePricePence = 2800
                )
            )
        }

        return rawServices
    }

    private fun createService(
        id: String,
        origin: Station,
        dest: Station,
        dep: String,
        arr: String,
        duration: String,
        changes: Int,
        legs: List<JourneyLeg>,
        basePricePence: Int,
        isOvernight: Boolean = false,
        advanceSoldOut: Boolean = false,
        callingPoints: List<String> = emptyList()
    ): JourneyOption {
        val standardFare = ServiceFare(
            id = "${id}-std-adv",
            ticketType = TicketType.ADVANCE_SINGLE,
            travelClass = TravelClass.STANDARD,
            pricePence = basePricePence,
            isAvailable = !advanceSoldOut,
            quotaRemaining = if (advanceSoldOut) 0 else 9
        )
        val offPeakFare = ServiceFare(
            id = "${id}-std-offpeak",
            ticketType = TicketType.OFF_PEAK_SINGLE,
            travelClass = TravelClass.STANDARD,
            pricePence = (basePricePence * 125) / 100,
            isAvailable = true,
            quotaRemaining = 20
        )
        val firstFare = ServiceFare(
            id = "${id}-first-adv",
            ticketType = TicketType.ADVANCE_SINGLE,
            travelClass = TravelClass.FIRST,
            pricePence = (basePricePence * 160) / 100,
            isAvailable = true,
            quotaRemaining = 4
        )

        return JourneyOption(
            id = id,
            origin = origin,
            destination = dest,
            departureTime = dep,
            arrivalTime = arr,
            durationStr = duration,
            changes = changes,
            legs = legs,
            fares = listOf(standardFare, offPeakFare, firstFare),
            isOvernight = isOvernight,
            callingPoints = callingPoints
        )
    }
}

class JourneyPlannerImpl(
    private val timetableProvider: TimetableProvider
) : JourneyPlanner {
    override suspend fun planJourney(
        origin: Station,
        destination: Station,
        date: String,
        departAfterTime: String,
        isReturn: Boolean,
        returnDate: String?
    ): List<JourneyOption> {
        return timetableProvider.getServices(
            originCrs = origin.crsCode,
            destCrs = destination.crsCode,
            date = date,
            departAfterTime = departAfterTime
        )
    }
}

class BookingServiceImpl : BookingService {
    private val bookings = mutableMapOf<String, Booking>()

    init {
        // Pre-populate a test booking for collection testing as requested in Section 9!
        val seedOrigin = Station("SHF", "Sheffield")
        val seedDest = Station("STP", "London St Pancras")
        val seedOption = JourneyOption(
            id = "SEED-01",
            origin = seedOrigin,
            destination = seedDest,
            departureTime = "13:45",
            arrivalTime = "15:52",
            durationStr = "2h 07m",
            changes = 0,
            legs = listOf(JourneyLeg(seedOrigin.name, seedDest.name, "13:45", "15:52", "2h 07m"))
        )
        val seedFare = ServiceFare(
            id = "SEED-FARE",
            ticketType = TicketType.ADVANCE_SINGLE,
            travelClass = TravelClass.STANDARD,
            pricePence = 5600
        )
        val seedBooking = Booking(
            bookingReference = "BR-77102-SHF",
            collectionCode = "BR77102A",
            journey = seedOption,
            selectedFare = seedFare,
            passengers = PassengerConfig(1, 0, RailcardType.NONE),
            travelDate = "Thu 12 Nov 2026",
            totalPence = 5600,
            paymentAuthCode = "AUTH-SEED-9912",
            isCollected = false,
            status = BookingStatus.CONFIRMED
        )
        bookings[seedBooking.bookingReference] = seedBooking
    }

    override suspend fun createPendingBooking(
        journey: JourneyOption,
        fare: ServiceFare,
        passengers: PassengerConfig,
        travelDate: String,
        totalPence: Int
    ): Booking {
        val randNum = (10000..99999).random()
        val ref = "BR-$randNum-${journey.origin.crsCode}"
        val collCode = "BR${randNum}S"
        val booking = Booking(
            bookingReference = ref,
            collectionCode = collCode,
            journey = journey,
            selectedFare = fare,
            passengers = passengers,
            travelDate = travelDate,
            totalPence = totalPence,
            status = BookingStatus.PENDING_PAYMENT
        )
        bookings[ref] = booking
        return booking
    }

    override suspend fun confirmBooking(
        bookingReference: String,
        paymentAuthCode: String
    ): Booking {
        val current = bookings[bookingReference]
            ?: throw IllegalStateException("Booking $bookingReference not found")
        val confirmed = current.copy(
            paymentAuthCode = paymentAuthCode,
            status = BookingStatus.CONFIRMED,
            timestampEpochMs = System.currentTimeMillis()
        )
        bookings[bookingReference] = confirmed
        return confirmed
    }

    override suspend fun getBooking(bookingReference: String): Booking? = bookings[bookingReference]

    override suspend fun getAllBookings(): List<Booking> = bookings.values.toList().reversed()

    override suspend fun updateBooking(booking: Booking) {
        bookings[booking.bookingReference] = booking
    }
}

class PaymentAdapterImpl : PaymentAdapter {
    private val processedIdempotencyKeys = mutableSetOf<String>()

    override suspend fun processPayment(request: PaymentRequest): PaymentResult {
        // Simulate hardware PIN pad communication
        delay(900)

        // Idempotency check: if this booking has already been successfully charged, return idempotent success
        if (processedIdempotencyKeys.contains(request.bookingReference)) {
            return PaymentResult.Success(
                authCode = "AUTH-RECON-IDEMPOTENT",
                transactionId = "TXN-${UUID.randomUUID().toString().take(8).uppercase()}"
            )
        }

        return when (request.simulatedOutcome) {
            SimulatedPaymentOutcome.SUCCESS -> {
                processedIdempotencyKeys.add(request.bookingReference)
                PaymentResult.Success(
                    authCode = "AUTH-BR-${(10000..99999).random()}",
                    transactionId = "TXN-${UUID.randomUUID().toString().take(8).uppercase()}"
                )
            }
            SimulatedPaymentOutcome.DECLINED -> {
                PaymentResult.Declined("Card declined by issuing bank [Code: 51 - Insufficient funds / Transaction not permitted]")
            }
            SimulatedPaymentOutcome.TIMEOUT -> {
                PaymentResult.Timeout
            }
            SimulatedPaymentOutcome.CANCELLED -> {
                PaymentResult.Cancelled
            }
        }
    }
}

class TicketIssuerImpl : TicketIssuer {
    override suspend fun issueTicket(
        booking: Booking,
        forcePendingForDemo: Boolean
    ): TicketIssuanceResult {
        delay(500)
        if (forcePendingForDemo) {
            return TicketIssuanceResult.Pending(
                "National Rail ticketing inventory service returned temporary queuing state. Retrying ticket fulfillment..."
            )
        }

        val qrPayload = "BR-TICKET|REF:${booking.bookingReference}|COLL:${booking.collectionCode}|" +
                "${booking.journey.origin.crsCode}->${booking.journey.destination.crsCode}|" +
                "${booking.travelDate}|${booking.selectedFare.travelClass.name}|${booking.selectedFare.ticketType.name}|" +
                "PRICE:${booking.totalPence}|AUTH:${booking.paymentAuthCode}|DEMO_NOT_VALID_FOR_TRAVEL"

        return TicketIssuanceResult.Issued(
            ticketPayload = "BR-ELECTRONIC-TICKET-V1-${booking.bookingReference}",
            qrData = qrPayload
        )
    }
}

class TicketCollectionServiceImpl(
    private val bookingService: BookingService
) : TicketCollectionService {
    private var attemptsCount = 0

    override suspend fun retrieveTicketForCollection(
        reference: String,
        cardLast4: String
    ): Result<Booking> {
        delay(600)
        attemptsCount++
        if (attemptsCount > 4) {
            return Result.failure(
                IllegalStateException("Maximum verification attempts exceeded. For security, please visit a staffed ticket office.")
            )
        }

        // Secondary verification: Must provide a 4-digit card number
        if (cardLast4.trim().length != 4 || !cardLast4.all { it.isDigit() }) {
            return Result.failure(
                IllegalArgumentException("Invalid payment card verification digits. Enter the last 4 digits of your payment card.")
            )
        }

        val all = bookingService.getAllBookings()
        val found = all.find {
            it.collectionCode.equals(reference.trim(), ignoreCase = true) ||
                    it.bookingReference.equals(reference.trim(), ignoreCase = true)
        }

        if (found == null) {
            return Result.failure(
                IllegalArgumentException("Booking reference not found. Please check your confirmation email or message.")
            )
        }

        if (found.isCollected) {
            return Result.failure(
                IllegalStateException("Tickets for booking ${found.bookingReference} have already been printed and collected.")
            )
        }

        attemptsCount = 0 // reset on success
        return Result.success(found)
    }

    override suspend fun markCollected(reference: String): Boolean {
        val all = bookingService.getAllBookings()
        val found = all.find {
            it.collectionCode.equals(reference, ignoreCase = true) ||
                    it.bookingReference.equals(reference, ignoreCase = true)
        } ?: return false

        bookingService.updateBooking(found.copy(isCollected = true, status = BookingStatus.COLLECTED))
        return true
    }
}

class PrinterAdapterImpl : PrinterAdapter {
    override suspend fun printTicket(booking: Booking): Boolean {
        delay(1200) // thermal printer simulation
        return true
    }

    override suspend fun printReceipt(booking: Booking): Boolean {
        delay(800)
        return true
    }
}

class AccessibilityDataProviderImpl : AccessibilityDataProvider {
    private val stationMap = mapOf(
        "SHF" to StationAccessibilityInfo(
            stationCrs = "SHF",
            stationName = "Sheffield",
            stepFreeCategory = "Category A: Step-free access to all platforms via lifts from the footbridge.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Assisted travel meeting point located at Customer Information Point on Island Platform 2/3."
        ),
        "STP" to StationAccessibilityInfo(
            stationCrs = "STP",
            stationName = "London St Pancras",
            stepFreeCategory = "Category A: Full step-free access throughout international and domestic concourses.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Dedicated Assisted Travel Lounge situated opposite Platform 11."
        ),
        "MAN" to StationAccessibilityInfo(
            stationCrs = "MAN",
            stationName = "Manchester Piccadilly",
            stepFreeCategory = "Category A: Level access to all concourse areas and lifts to Platforms 13 & 14.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Mobility assistance buggies available on main concourse."
        ),
        "DBY" to StationAccessibilityInfo(
            stationCrs = "DBY",
            stationName = "Derby",
            stepFreeCategory = "Category A: Step-free access between platforms via accessible footbridge and lifts.",
            staffAssistanceAvailable = true,
            inductionLoop = true,
            accessibleToilets = true,
            rampAvailable = true,
            tactilePaving = true,
            notes = "Ramp boarding available with staff assistance on all platforms."
        )
    )

    override fun getStationAccessibility(stationCrs: String): StationAccessibilityInfo? {
        return stationMap[stationCrs.uppercase()]
    }

    override fun getAllStationAccessibility(): List<StationAccessibilityInfo> = stationMap.values.toList()
}
