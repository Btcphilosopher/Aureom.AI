package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.ui.theme.BritishRailBlack
import com.example.ui.theme.BritishRailOffBlack
import com.example.ui.theme.BritishRailRed
import com.example.ui.theme.BritishRailWhite
import com.example.ui.theme.RailAlphabetFontFamily
import com.example.ui.theme.RailGreyBorder
import com.example.ui.theme.RailGreyPanel
import com.example.ui.theme.RailGreySubtext

/**
 * British Rail double arrow logo.
 */
@Composable
fun BrLogo(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .background(BritishRailRed)
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Image(
            painter = painterResource(id = R.drawable.ic_br_logo_1794486819321),
            contentDescription = "British Rail Double Arrow Logo",
            modifier = Modifier.size(size - 8.dp)
        )
    }
}

/**
 * Top header of the British Rail terminal.
 */
@Composable
fun BrHeader(
    currentTime: String,
    onTitleClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(BritishRailBlack)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Logo & Brand Box
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clickable(onClick = onTitleClick)
                .testTag("br_brand_header")
        ) {
            BrLogo(size = 40.dp)
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .border(2.dp, BritishRailWhite, RoundedCornerShape(0.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "British Rail",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = BritishRailWhite,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(28.dp))

        // Center Title
        Text(
            text = "Tickets & journeys",
            fontFamily = RailAlphabetFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = BritishRailWhite,
            modifier = Modifier.weight(1f)
        )

        // Right side: Demonstration indicator & Clock
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .border(1.dp, Color(0xFF666666))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "DEMO",
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = BritishRailWhite,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.width(16.dp))
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(24.dp)
                    .background(Color(0xFF555555))
            )
            Spacer(modifier = Modifier.width(16.dp))

            Text(
                text = currentTime,
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = BritishRailWhite
            )
        }
    }
}

/**
 * 4-step progress indicator:
 * 1 Journey -> 2 Choose train -> 3 Payment -> 4 Your ticket
 */
@Composable
fun BrStepProgress(
    currentStep: Int, // 1 to 4
    language: AppLanguage = AppLanguage.ENGLISH
) {
    val steps = if (language == AppLanguage.CYMRAEG) {
        listOf(
            1 to "Taith",
            2 to "Dewis trên",
            3 to "Taliad",
            4 to "Eich tocyn"
        )
    } else {
        listOf(
            1 to "Journey",
            2 to "Choose train",
            3 to "Payment",
            4 to "Your ticket"
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailWhite)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        steps.forEachIndexed { index, (stepNumber, label) ->
            val isActive = currentStep == stepNumber
            val isCompleted = currentStep > stepNumber

            val circleColor = when {
                isActive -> BritishRailRed
                isCompleted -> BritishRailBlack
                else -> Color(0xFF888888)
            }
            val textColor = when {
                isActive -> BritishRailRed
                isCompleted -> BritishRailBlack
                else -> Color(0xFF888888)
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.testTag("step_indicator_$stepNumber")
            ) {
                // Circle with step number
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .background(circleColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Completed",
                            tint = BritishRailWhite,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Text(
                            text = stepNumber.toString(),
                            fontFamily = RailAlphabetFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = BritishRailWhite
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = label,
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = textColor
                )
            }

            // Connector rule between steps
            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .padding(horizontal = 14.dp)
                        .background(BritishRailBlack)
                )
            }
        }
    }
}

/**
 * Bottom information & accessibility bar matching reference footer.
 */
@Composable
fun BrFooter(
    language: AppLanguage,
    onLanguageToggle: () -> Unit,
    textSizeLevel: Int, // 0 = standard, 1 = large, 2 = extra large
    onTextSizeChange: (Int) -> Unit,
    isLowerScreenMode: Boolean,
    onToggleLowerScreen: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(BritishRailBlack)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left indicators
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Contactless,
                        contentDescription = "Contactless payment supported",
                        tint = BritishRailWhite,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Taliad digyswllt" else "Contactless payment",
                        color = BritishRailWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(16.dp)
                        .background(Color(0xFF555555))
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.QrCode2,
                        contentDescription = "QR ticket supported",
                        tint = BritishRailWhite,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Tocyn QR" else "QR ticket",
                        color = BritishRailWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(16.dp)
                        .background(Color(0xFF555555))
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Print,
                        contentDescription = "Ticket print available",
                        tint = BritishRailWhite,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (language == AppLanguage.CYMRAEG) "Argraffu lle bo ar gael" else "Print where available",
                        color = BritishRailWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Right accessibility & language controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Lower screen wheelchair mode toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onToggleLowerScreen() }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .testTag("lower_screen_toggle")
                ) {
                    Icon(
                        imageVector = Icons.Default.Accessible,
                        contentDescription = "Lower-screen mode",
                        tint = if (isLowerScreenMode) BritishRailRed else BritishRailWhite,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isLowerScreenMode) "Seated mode: ON" else "Seated mode",
                        color = if (isLowerScreenMode) BritishRailRed else BritishRailWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(16.dp)
                        .background(Color(0xFF555555))
                )

                // Language Selector
                Text(
                    text = "English / Cymraeg",
                    color = BritishRailWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onLanguageToggle() }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                        .testTag("language_toggle")
                )

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(16.dp)
                        .background(Color(0xFF555555))
                )

                // Text Size Controls: A- A A+
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "A-",
                        fontSize = 12.sp,
                        color = if (textSizeLevel == 0) BritishRailRed else BritishRailWhite,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onTextSizeChange(0) }
                            .padding(2.dp)
                            .testTag("text_size_small")
                    )
                    Text(
                        text = "A",
                        fontSize = 15.sp,
                        color = if (textSizeLevel == 1) BritishRailRed else BritishRailWhite,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onTextSizeChange(1) }
                            .padding(2.dp)
                            .testTag("text_size_medium")
                    )
                    Text(
                        text = "A+",
                        fontSize = 18.sp,
                        color = if (textSizeLevel == 2) BritishRailRed else BritishRailWhite,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onTextSizeChange(2) }
                            .padding(2.dp)
                            .testTag("text_size_large")
                    )
                }
            }
        }

        // Subtitle line
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A0A0A))
                .padding(vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Concept interface • Demonstration fares and services",
                color = Color(0xFFAAAAAA),
                fontSize = 11.sp,
                fontFamily = RailAlphabetFontFamily
            )
        }
    }
}

/**
 * British Rail schematic railway line with station nodes.
 * Sheffield O=======O London St Pancras
 */
@Composable
fun BrSchematicLine(
    originName: String,
    destinationName: String,
    modifier: Modifier = Modifier,
    interchangeName: String? = null
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Station Names Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = originName,
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = BritishRailBlack
            )
            if (interchangeName != null) {
                Text(
                    text = interchangeName,
                    fontFamily = RailAlphabetFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp,
                    color = RailGreySubtext
                )
            }
            Text(
                text = destinationName,
                fontFamily = RailAlphabetFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = BritishRailBlack
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Schematic Graphic: Circle - Line - Circle
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(14.dp)
        ) {
            val circleRadius = 5.dp.toPx()
            val strokeW = 3.dp.toPx()
            val centerY = size.height / 2

            val startX = circleRadius + 2.dp.toPx()
            val endX = size.width - circleRadius - 2.dp.toPx()

            // Red connecting track line
            drawLine(
                color = BritishRailRed,
                start = Offset(startX, centerY),
                end = Offset(endX, centerY),
                strokeWidth = strokeW
            )

            // Origin station node (hollow circle)
            drawCircle(
                color = BritishRailWhite,
                radius = circleRadius,
                center = Offset(startX, centerY)
            )
            drawCircle(
                color = BritishRailBlack,
                radius = circleRadius,
                center = Offset(startX, centerY),
                style = Stroke(width = 2.dp.toPx())
            )

            // Optional interchange intermediate node
            if (interchangeName != null) {
                val midX = size.width / 2
                drawCircle(
                    color = BritishRailWhite,
                    radius = circleRadius - 1.dp.toPx(),
                    center = Offset(midX, centerY)
                )
                drawCircle(
                    color = BritishRailBlack,
                    radius = circleRadius - 1.dp.toPx(),
                    center = Offset(midX, centerY),
                    style = Stroke(width = 2.dp.toPx())
                )
            }

            // Destination station node (hollow circle)
            drawCircle(
                color = BritishRailWhite,
                radius = circleRadius,
                center = Offset(endX, centerY)
            )
            drawCircle(
                color = BritishRailBlack,
                radius = circleRadius,
                center = Offset(endX, centerY),
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

/**
 * Rectangular British Rail button.
 */
enum class BrButtonStyle {
    PRIMARY_RED,
    SECONDARY_BLACK,
    OUTLINED,
    SELECTED_RED
}

@Composable
fun BrButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: BrButtonStyle = BrButtonStyle.PRIMARY_RED,
    enabled: Boolean = true,
    height: Dp = 48.dp,
    testTag: String = ""
) {
    val bg = when (style) {
        BrButtonStyle.PRIMARY_RED -> if (enabled) BritishRailRed else RailGreyBorder
        BrButtonStyle.SECONDARY_BLACK -> if (enabled) BritishRailBlack else RailGreyBorder
        BrButtonStyle.OUTLINED -> BritishRailWhite
        BrButtonStyle.SELECTED_RED -> BritishRailRed
    }

    val contentColor = when (style) {
        BrButtonStyle.PRIMARY_RED -> BritishRailWhite
        BrButtonStyle.SECONDARY_BLACK -> BritishRailWhite
        BrButtonStyle.OUTLINED -> BritishRailBlack
        BrButtonStyle.SELECTED_RED -> BritishRailWhite
    }

    val borderMod = if (style == BrButtonStyle.OUTLINED) {
        Modifier.border(2.dp, BritishRailBlack, RoundedCornerShape(0.dp))
    } else Modifier

    Box(
        modifier = modifier
            .then(borderMod)
            .height(height)
            .background(bg, RoundedCornerShape(0.dp))
            .clickable(
                enabled = enabled,
                onClick = onClick,
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple()
            )
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontFamily = RailAlphabetFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = contentColor
        )
    }
}

/**
 * 2D Canvas QR Code generator for demonstration tickets.
 * Draws high-contrast square matrix cells.
 */
@Composable
fun QrCodeView(
    dataPayload: String,
    modifier: Modifier = Modifier,
    qrBoxSize: Dp = 140.dp
) {
    Canvas(
        modifier = modifier
            .size(qrBoxSize)
            .background(BritishRailWhite)
            .border(2.dp, BritishRailBlack)
            .padding(8.dp)
            .testTag("qr_ticket_canvas")
    ) {
        val matrixSize = 25
        val cellSize = this.size.width / matrixSize

        // Draw 3 standard corner alignment markers (top-left, top-right, bottom-left)
        fun drawPositionMarker(startCol: Int, startRow: Int) {
            // Outer 7x7 black box
            drawRect(
                color = BritishRailBlack,
                topLeft = Offset(startCol * cellSize, startRow * cellSize),
                size = androidx.compose.ui.geometry.Size(7 * cellSize, 7 * cellSize)
            )
            // Inner 5x5 white box
            drawRect(
                color = BritishRailWhite,
                topLeft = Offset((startCol + 1) * cellSize, (startRow + 1) * cellSize),
                size = androidx.compose.ui.geometry.Size(5 * cellSize, 5 * cellSize)
            )
            // Center 3x3 black box
            drawRect(
                color = BritishRailBlack,
                topLeft = Offset((startCol + 2) * cellSize, (startRow + 2) * cellSize),
                size = androidx.compose.ui.geometry.Size(3 * cellSize, 3 * cellSize)
            )
        }

        drawPositionMarker(0, 0)
        drawPositionMarker(matrixSize - 7, 0)
        drawPositionMarker(0, matrixSize - 7)

        // Seeded pseudorandom matrix pattern based on dataPayload hash
        val hash = dataPayload.hashCode()
        for (row in 0 until matrixSize) {
            for (col in 0 until matrixSize) {
                // Skip corner marker zones
                val inTopLeft = row < 8 && col < 8
                val inTopRight = row < 8 && col >= matrixSize - 8
                val inBottomLeft = row >= matrixSize - 8 && col < 8

                if (!inTopLeft && !inTopRight && !inBottomLeft) {
                    val bit = ((hash + row * 31 + col * 17) xor (row * col + 7)) % 3 == 0
                    if (bit) {
                        drawRect(
                            color = BritishRailBlack,
                            topLeft = Offset(col * cellSize, row * cellSize),
                            size = androidx.compose.ui.geometry.Size(cellSize, cellSize)
                        )
                    }
                }
            }
        }
    }
}
