package com.example

import com.example.data.model.BookingStatus
import com.example.data.model.JourneyLeg
import com.example.data.model.JourneyOption
import com.example.data.model.PassengerConfig
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentRequest
import com.example.data.model.PaymentResult
import com.example.data.model.RailcardType
import com.example.data.model.ServiceFare
import com.example.data.model.SimulatedPaymentOutcome
import com.example.data.model.Station
import com.example.data.model.TicketType
import com.example.data.model.TravelClass
import com.example.data.model.formatPence
import com.example.data.repository.AccessibilityDataProviderImpl
import com.example.data.repository.BookingServiceImpl
import com.example.data.repository.FareProviderImpl
import com.example.data.repository.PaymentAdapterImpl
import com.example.data.repository.StationRepositoryImpl
import com.example.data.repository.TicketCollectionServiceImpl
import com.example.data.repository.TicketIssuerImpl
import com.example.data.repository.TimetableProviderImpl
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BritishRailTerminalTest {

    private val fareProvider = FareProviderImpl()
    private val stationRepo = StationRepositoryImpl()
    private val timetableProvider = TimetableProviderImpl(stationRepo, fareProvider)
    private val bookingService = BookingServiceImpl()
    private val paymentAdapter = PaymentAdapterImpl()
    private val ticketIssuer = TicketIssuerImpl()
    private val ticketCollectionService = TicketCollectionServiceImpl(bookingService)
    private val accessibilityProvider = AccessibilityDataProviderImpl()

    @Test
    fun testMonetaryPenceFormatting() {
        assertEquals("£56.00", formatPence(5600))
        assertEquals("£48.50", formatPence(4850))
        assertEquals("£0.00", formatPence(0))
        assertEquals("£1.05", formatPence(105))
    }

    @Test
    fun testFareCalculationsAndRailcardDiscounts() {
        // Base adult single fare: 5600 pence (£56.00)
        val singleAdultNoCard = PassengerConfig(adults = 1, children = 0, railcard = RailcardType.NONE)
        val breakdown1 = fareProvider.getFareBreakdown(5600, singleAdultNoCard, TicketType.ADVANCE_SINGLE, TravelClass.STANDARD)
        assertEquals(5600, breakdown1.totalPence)
        assertEquals(0, breakdown1.railcardDiscountPence)

        // 16-25 Railcard gives 34% discount off eligible adult fare
        val singleAdultWith1625 = PassengerConfig(adults = 1, children = 0, railcard = RailcardType.SIXTEEN_TO_TWENTY_FIVE)
        val breakdown2 = fareProvider.getFareBreakdown(5600, singleAdultWith1625, TicketType.ADVANCE_SINGLE, TravelClass.STANDARD)
        val expectedDiscount = (5600 * 34) / 100 // 1904 pence discount
        assertEquals(expectedDiscount, breakdown2.railcardDiscountPence)
        assertEquals(5600 - expectedDiscount, breakdown2.totalPence)

        // Child fare is 50% of adult fare
        val adultAndChild = PassengerConfig(adults = 1, children = 1, railcard = RailcardType.NONE)
        val breakdown3 = fareProvider.getFareBreakdown(5600, adultAndChild, TicketType.ADVANCE_SINGLE, TravelClass.STANDARD)
        val expectedChild = (5600 + 1) / 2 // 2800 pence
        assertEquals(5600, breakdown3.baseAdultPence)
        assertEquals(expectedChild, breakdown3.baseChildPence)
        assertEquals(5600 + expectedChild, breakdown3.totalPence)
    }

    @Test
    fun testBookingCreationAndConfirmation() = runTest {
        val origin = Station("SHF", "Sheffield")
        val dest = Station("STP", "London St Pancras")
        val journey = JourneyOption(
            id = "SHF-STP-1345",
            origin = origin,
            destination = dest,
            departureTime = "13:45",
            arrivalTime = "15:52",
            durationStr = "2h 07m"
        )
        val fare = ServiceFare(
            id = "FARE-1",
            ticketType = TicketType.ADVANCE_SINGLE,
            travelClass = TravelClass.STANDARD,
            pricePence = 5600
        )
        val passengers = PassengerConfig(1, 0, RailcardType.NONE)

        val pending = bookingService.createPendingBooking(journey, fare, passengers, "Thu 12 Nov")
        assertEquals(BookingStatus.PENDING_PAYMENT, pending.status)
        assertTrue(pending.bookingReference.startsWith("BR-"))
        assertEquals(5600, pending.totalPence)

        val confirmed = bookingService.confirmBooking(pending.bookingReference, "AUTH-TEST-123")
        assertEquals(BookingStatus.CONFIRMED, confirmed.status)
        assertEquals("AUTH-TEST-123", confirmed.paymentAuthCode)
    }

    @Test
    fun testPaymentIdempotencyAndDuplicatePrevention() = runTest {
        val req = PaymentRequest(
            bookingReference = "BR-TEST-DUP-01",
            amountPence = 5600,
            method = PaymentMethod.CONTACTLESS,
            simulatedOutcome = SimulatedPaymentOutcome.SUCCESS
        )

        // First attempt
        val res1 = paymentAdapter.processPayment(req)
        assertTrue(res1 is PaymentResult.Success)

        // Second attempt with exact same booking reference (idempotency token)
        val res2 = paymentAdapter.processPayment(req)
        assertTrue(res2 is PaymentResult.Success)
        assertEquals("AUTH-RECON-IDEMPOTENT", (res2 as PaymentResult.Success).authCode)
    }

    @Test
    fun testOvernightJourneyModeling() = runTest {
        val services = timetableProvider.getServices("SHF", "STP", "Thu 12 Nov", "After 13:00")
        val overnight = services.find { it.isOvernight }
        assertNotNull(overnight)
        assertEquals("23:20", overnight?.departureTime)
        assertEquals("06:15", overnight?.arrivalTime)
        assertTrue(overnight?.changes ?: 0 > 0)
    }

    @Test
    fun testTicketCollectionVerificationAndBoundedAttempts() = runTest {
        // Pre-seeded test booking: BR-77102-SHF, collectionCode BR77102A, card 1234
        val successRes = ticketCollectionService.retrieveTicketForCollection("BR77102A", "1234")
        assertTrue(successRes.isSuccess)
        val booking = successRes.getOrNull()
        assertEquals("BR-77102-SHF", booking?.bookingReference)

        // Invalid reference
        val failRef = ticketCollectionService.retrieveTicketForCollection("INVALID99", "1234")
        assertTrue(failRef.isFailure)

        // Invalid card last 4 (wrong secondary verification)
        val failCard = ticketCollectionService.retrieveTicketForCollection("BR77102A", "99")
        assertTrue(failCard.isFailure)
    }

    @Test
    fun testStationAccessibilityCoverage() {
        val shfAccess = accessibilityProvider.getStationAccessibility("SHF")
        assertNotNull(shfAccess)
        assertTrue(shfAccess?.staffAssistanceAvailable == true)
        assertTrue(shfAccess?.inductionLoop == true)
        assertTrue(shfAccess?.accessibleToilets == true)

        val stpAccess = accessibilityProvider.getStationAccessibility("STP")
        assertNotNull(stpAccess)
        assertTrue(stpAccess?.stepFreeCategory?.contains("Category A") == true)

        // Unknown station access must remain unknown (null) rather than guessed
        val unknownAccess = accessibilityProvider.getStationAccessibility("CBG")
        assertEquals(null, unknownAccess)
    }

    @Test
    fun testRailcardEligibilityRules() {
        val stdFare = ServiceFare(
            id = "TEST-STD",
            ticketType = TicketType.ADVANCE_SINGLE,
            travelClass = TravelClass.STANDARD,
            pricePence = 5000
        )
        // Two Together railcard does NOT apply to 1 adult alone
        val oneAdultTwoTogether = PassengerConfig(adults = 1, children = 0, railcard = RailcardType.TWO_TOGETHER)
        val b1 = fareProvider.getBreakdownForServiceFare(stdFare, oneAdultTwoTogether, isReturn = false)
        assertEquals(0, b1.railcardDiscountPence)
        assertEquals(5000, b1.totalPence)

        // Two Together railcard DOES apply to 2 adults on Standard class
        val twoAdultsTwoTogether = PassengerConfig(adults = 2, children = 0, railcard = RailcardType.TWO_TOGETHER)
        val b2 = fareProvider.getBreakdownForServiceFare(stdFare, twoAdultsTwoTogether, isReturn = false)
        assertEquals(3400, b2.railcardDiscountPence)
        assertEquals(6600, b2.totalPence)
    }

    @Test
    fun testNoServiceAndUnavailableFareScenarios() = runTest {
        val noServices = timetableProvider.getServices("GLC", "CBG", "Thu 12 Nov", "After 13:00")
        assertTrue(noServices.isEmpty())

        val shfServices = timetableProvider.getServices("SHF", "STP", "Thu 12 Nov", "After 13:00")
        val service1445 = shfServices.find { it.departureTime == "14:45" }
        assertNotNull(service1445)
        val soldOutFare = service1445?.fares?.find { it.ticketType == TicketType.ADVANCE_SINGLE }
        assertNotNull(soldOutFare)
        assertFalse(soldOutFare!!.isAvailable)
        assertEquals(0, soldOutFare.quotaRemaining)
    }

    @Test
    fun testTicketIssuancePendingRecoverableState() = runTest {
        val origin = Station("SHF", "Sheffield")
        val dest = Station("STP", "London St Pancras")
        val journey = JourneyOption("SHF-STP-1345", origin, dest, "13:45", "15:52", "2h 07m")
        val fare = ServiceFare("F1", TicketType.ADVANCE_SINGLE, TravelClass.STANDARD, 5600)
        val pending = bookingService.createPendingBooking(journey, fare, PassengerConfig(), "Thu 12 Nov")
        val confirmed = bookingService.confirmBooking(pending.bookingReference, "AUTH-999")

        val pendingResult = ticketIssuer.issueTicket(confirmed, forcePendingForDemo = true)
        assertTrue(pendingResult is com.example.data.model.TicketIssuanceResult.Pending)

        val retryResult = ticketIssuer.issueTicket(confirmed, forcePendingForDemo = false)
        assertTrue(retryResult is com.example.data.model.TicketIssuanceResult.Issued)
    }
}
