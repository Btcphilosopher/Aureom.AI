package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.PassengerConfig
import com.example.data.model.RailcardType
import com.example.data.model.Station
import com.example.ui.TerminalScreen
import com.example.ui.TerminalViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("British Rail", appName)
    }

    @Test
    @Config(qualifiers = "cy")
    fun `read welsh string resources`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Tocynnau a theithiau", context.getString(R.string.header_title))
        assertEquals("Ble hoffech chi fynd?", context.getString(R.string.home_heading))
    }

    @Test
    fun `kiosk session cleanup clears sensitive state and resets to home`() {
        val vm = TerminalViewModel()
        vm.setFromStation(Station("MAN", "Manchester Piccadilly"))
        vm.setToStation(Station("YRK", "York"))
        vm.setPassengers(PassengerConfig(adults = 2, children = 1, railcard = RailcardType.FAMILY_AND_FRIENDS))
        vm.setCollectionRef("BR77102A")
        vm.setCardLast4("1234")
        vm.setShowReceiptDialog(true)
        vm.navigateToScreen(TerminalScreen.PAYMENT)

        vm.resetKioskSession()

        val resetState = vm.uiState.value
        assertEquals(TerminalScreen.JOURNEY_FORM, resetState.currentScreen)
        assertEquals(1, resetState.currentStep)
        assertEquals("SHF", resetState.fromStation.crsCode)
        assertEquals("STP", resetState.toStation.crsCode)
        assertEquals(1, resetState.passengers.adults)
        assertEquals(0, resetState.passengers.children)
        assertEquals(RailcardType.NONE, resetState.passengers.railcard)
        assertEquals("", resetState.collectionRefInput)
        assertEquals("", resetState.cardLast4Input)
        assertFalse(resetState.showReceiptDialog)
        assertNull(resetState.activeBooking)
    }
}
