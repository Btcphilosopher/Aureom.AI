package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Palette
val PrimaryRed = Color(0xFFE60012)
val PrimaryRedLight = Color(0xFFFFEBEC)

val DeepBlueDark = Color(0xFF003366)
val DeepBlueLight = Color(0xFF004A99)

val Slate900 = Color(0xFF0F172A)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate100 = Color(0xFFE2E8F0)

val BackgroundGray = Color(0xFFF7F8FA)
val SurfaceWhite = Color(0xFFFFFFFF)

