package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.Announcement
import com.example.data.model.Passenger
import com.example.data.model.PromoActivity
import com.example.data.model.RailNotification
import com.example.data.model.RouteSegment
import com.example.data.model.SearchHistory
import com.example.data.model.Station
import com.example.data.model.TicketOrder
import com.example.data.model.TrainSchedule
import com.example.data.model.TransferPlan
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

// --- Mock Retrofit API Structure for Enterprise Design ---
interface RailApiService {
    @GET("api/trains/query")
    suspend fun queryTrains(
        @Query("from") from: String,
        @Query("to") to: String,
        @Query("date") date: String
    ): List<TrainSchedule>

    @GET("api/stations/all")
    suspend fun getAllStations(): List<Station>
}

class RailRepository(private val db: AppDatabase) {

    // DAOs
    private val passengerDao = db.passengerDao()
    private val ticketOrderDao = db.ticketOrderDao()
    private val searchHistoryDao = db.searchHistoryDao()
    private val stationDao = db.stationDao()
    private val trainDao = db.trainDao()
    private val notificationDao = db.railNotificationDao()
    private val announcementDao = db.announcementDao()
    private val promoActivityDao = db.promoActivityDao()

    // Exposed Flows
    val allPassengers: Flow<List<Passenger>> = passengerDao.getAllPassengers()
    val allOrders: Flow<List<TicketOrder>> = ticketOrderDao.getAllOrders()
    val searchHistory: Flow<List<SearchHistory>> = searchHistoryDao.getSearchHistory()
    val allStations: Flow<List<Station>> = stationDao.getAllStations()
    val allTrainSchedules: Flow<List<TrainSchedule>> = trainDao.getAllTrainSchedules()
    val allNotifications: Flow<List<RailNotification>> = notificationDao.getAllNotifications()
    val announcements: Flow<List<Announcement>> = announcementDao.getAnnouncements()
    val promos: Flow<List<PromoActivity>> = promoActivityDao.getPromos()

    // Initialization: Seed mock data if empty
    suspend fun seedDatabaseIfEmpty() {
        // Seed Stations
        val currentStations = stationDao.getAllStations().first()
        if (currentStations.isEmpty()) {
            val defaultStations = listOf(
                Station("BJP", "北京南", "北京", true, "中国高科技铁路地标，服务京沪高铁、京津城际。", "候车大厅3楼A1-B24检票口", "12B, 13B", "6, 7", listOf("华为体验店", "小米之家", "Costa Coffee", "星巴克"), listOf("永和大王", "肯德基", "庆丰包子铺", "真功夫"), listOf("地铁4号线", "地铁14号线", "公交300路", "地下出租车调度站"), listOf("无障碍电梯", "盲道系统", "爱心候车区")),
                Station("AHP", "上海虹桥", "上海", true, "超大型综合交通枢纽，无缝对接航空、地铁及高速路网。", "候车厅2层1-30号检票口", "10B, 11A", "4, 5", listOf("Apple Store", "全家便利店", "上海故事"), listOf("麦当劳", "老乡鸡", "大娘水饺", "西少爷"), listOf("地铁2号线", "地铁10号线", "地铁17号线", "虹桥机场T2航站楼"), listOf("轮椅预约服务", "母婴哺乳室", "低位自助购票机")),
                Station("IZQ", "广州南", "广州", true, "华南地区最繁忙的客运中心，连接粤港澳大湾区高速线。", "候车厅2层检票口", "08A, 09B", "8, 9", listOf("屈臣氏", "名创优品", "华润万家"), listOf("真功夫", "肯德基", "广州酒家", "星巴克"), listOf("地铁2号线", "地铁7号线", "地铁22号线", "佛山地铁2号线"), listOf("垂直电梯", "轮椅斜坡", "重点旅客候车区")),
                Station("IOQ", "深圳北", "深圳", true, "大湾区核心高速换乘点，连接广深港高速铁路直通香港。", "二楼候车区西侧", "15A, 15B", "11, 12", listOf("华为智能生活馆", "7-Eleven", "深圳特产"), listOf("麦当劳", "八合里牛肉火锅", "都可奶茶"), listOf("地铁4号线", "地铁5号线", "地铁6号线"), listOf("爱心接力热线", "无障碍卫生间")),
                Station("ICW", "成都东", "成都", true, "西南首屈一指的交通重镇，蜀道不再难的现代化写照。", "候车大厅中心区域", "05B, 06A", "3", listOf("廖记棒棒鸡", "红旗连锁", "成都非遗"), listOf("李先生牛肉面", "海底捞单人食", "肯德基"), listOf("地铁2号线", "地铁7号线", "长途汽车客运站"), listOf("爱心服务哨点", "母婴专用候车室")),
                Station("EAY", "西安北", "西安", true, "丝绸之路高铁起点，极具盛唐古风的宏伟站房建筑。", "二楼候车大厅A8-B18", "16A, 17B", "13", listOf("陕拾叁冰淇淋", "全家", "西安特产超市"), listOf("魏家凉皮", "肯德基", "肉夹馍铺"), listOf("地铁2号线", "地铁4号线", "地铁14号线机场线"), listOf("重点旅客急客绿色通道", "无障碍电梯")),
                Station("WHN", "武汉", "武汉", true, "九省通衢，中国首座迈入三千公里高铁网的核心车站。", "候车大厅东侧", "07A, 08B", "6", listOf("周黑鸭", "全家", "武汉文创"), listOf("蔡林记热干面", "麦当劳", "良品铺子"), listOf("地铁4号线", "地铁19号线"), listOf("轮椅推送服务", "无障碍自助服务台")),
                Station("HZH", "杭州东", "杭州", true, "动车车次最多的现代枢纽，体现江南美学与科技互联。", "候车层中心区", "20B, 21A", "14, 15", listOf("知味观", "华为", "罗森"), listOf("外婆家小馆", "肯德基", "新丰小吃"), listOf("地铁1号线", "地铁4号线", "地铁6号线", "地铁19号线"), listOf("残疾人专用停车位", "低位窗口")),
                Station("NKP", "南京南", "南京", true, "华东区高规格铁路枢纽，完美契合古城建筑美学。", "候车厅二层A12-B20", "14B, 15A", "10", listOf("科沃斯", "南京特产云锦", "7-Eleven"), listOf("回味鸭血粉丝汤", "肯德基", "老乡鸡"), listOf("地铁1号线", "地铁3号线", "地铁S1号线机场线", "地铁S3号线"), listOf("无障碍卫生间", "轮椅绿色通道"))
            )
            stationDao.insertStations(defaultStations)
        }

        // Seed Train Schedules
        val currentTrains = trainDao.getAllTrainSchedules().first()
        if (currentTrains.isEmpty()) {
            val defaultTrains = listOf(
                TrainSchedule("G1", "复兴号 CR400AF", "北京南", "上海虹桥", "07:00", "11:18", "4h18m", true, "99.8%", "北京南;济南西;南京南;上海虹桥", "07:00;08:32;10:11;11:18", 553.0, 933.0, 1748.0, 0.0, 0.0, 0.0),
                TrainSchedule("G2", "复兴号 CR400AF-A", "上海虹桥", "北京南", "07:00", "11:18", "4h18m", true, "99.5%", "上海虹桥;南京南;济南西;北京南", "07:00;08:08;09:47;11:18", 553.0, 933.0, 1748.0, 0.0, 0.0, 0.0),
                TrainSchedule("G3", "复兴号 CR400BF", "北京南", "上海虹桥", "14:00", "18:18", "4h18m", true, "99.6%", "北京南;南京南;上海虹桥", "14:00;17:11;18:18", 553.0, 933.0, 1748.0, 0.0, 0.0, 0.0),
                TrainSchedule("G101", "和谐号 CRH380A", "北京南", "上海虹桥", "06:40", "12:35", "5h55m", true, "98.4%", "北京南;天津南;沧州西;德州东;济南西;泰安;徐州东;蚌埠南;滁州;南京南;镇江;常州;无锡;苏州;上海虹桥", "06:40;07:12;07:38;08:05;08:34;09:01;10:02;10:45;11:12;11:35;11:58;12:12;12:22;12:35", 553.0, 933.0, 1748.0, 0.0, 0.0, 0.0),
                TrainSchedule("G102", "和谐号 CRH380A", "上海虹桥", "北京南", "06:40", "12:35", "5h55m", true, "98.9%", "上海虹桥;昆山南;苏州;无锡;常州;镇江;南京南;滁州;蚌埠南;徐州东;泰安;济南西;德州东;沧州西;天津南;北京南", "06:40;06:58;07:11;07:22;07:35;07:58;08:21;08:44;09:12;09:55;10:56;11:23;11:52;12:19;12:35", 553.0, 933.0, 1748.0, 0.0, 0.0, 0.0),
                TrainSchedule("G11", "复兴号 CR400BF-Z", "北京南", "上海虹桥", "08:00", "12:38", "4h38m", true, "99.2%", "北京南;济南西;南京南;无锡东;上海虹桥", "08:00;09:32;11:11;11:55;12:38", 553.0, 933.0, 1748.0, 0.0, 0.0, 0.0),
                TrainSchedule("G12", "复兴号 CR400BF-Z", "上海虹桥", "北京南", "08:00", "12:38", "4h38m", true, "99.0%", "上海虹桥;苏州北;南京南;徐州东;济南西;北京南", "08:00;08:25;09:15;10:12;11:10;12:38", 553.0, 933.0, 1748.0, 0.0, 0.0, 0.0),
                TrainSchedule("G73", "复兴号 CR400AF", "北京南", "广州南", "09:00", "17:39", "8h39m", true, "98.5%", "北京南;石家庄;郑州东;武汉;长沙南;广州南", "09:00;10:05;11:58;13:42;15:15;17:39", 862.0, 1383.0, 2727.5, 0.0, 0.0, 0.0),
                TrainSchedule("G74", "复兴号 CR400AF", "广州南", "北京南", "09:00", "17:39", "8h39m", true, "98.2%", "广州南;长沙南;武汉;郑州东;石家庄;北京南", "09:00;11:12;12:45;14:32;16:25;17:39", 862.0, 1383.0, 2727.5, 0.0, 0.0, 0.0),
                TrainSchedule("G1301", "复兴号 CR400BF", "上海虹桥", "广州南", "10:00", "17:15", "7h15m", true, "99.1%", "上海虹桥;杭州东;金华;南昌西;长沙南;韶关;广州南", "10:00;10:45;11:32;13:10;14:48;16:25;17:15", 793.0, 1302.5, 2492.5, 0.0, 0.0, 0.0),
                TrainSchedule("D35", "和谐号 CRH2E", "北京南", "杭州东", "20:30", "06:15", "9h45m", true, "97.5%", "北京南;南京南;苏州;上海虹桥;杭州东", "20:30;02:15;04:45;05:25;06:15", 328.0, 520.0, 0.0, 780.0, 580.0, 0.0),
                TrainSchedule("K101", "25G 客车", "北京", "上海", "13:15", "11:50", "22h35m", true, "93.0%", "北京;沧州;德州;济南;泰山;兖州;徐州;宿州;蚌埠;南京;镇江;常州;无锡;苏州;上海", "13:15;15:02;16:15;17:45;18:45;19:55;22:05;23:12;00:45;03:15;04:45;06:32;07:55;09:12;11:50", 0.0, 0.0, 0.0, 415.5, 268.5, 156.5)
            )
            trainDao.insertTrainSchedules(defaultTrains)
        }

        // Seed default passengers
        val currentPassengers = passengerDao.getAllPassengers().first()
        if (currentPassengers.isEmpty()) {
            passengerDao.insertPassenger(Passenger(name = "张铁通", type = "成人", idType = "二代身份证", idNumber = "110101199001011234", phoneNumber = "13800138000", isVerified = true, isCommon = true))
            passengerDao.insertPassenger(Passenger(name = "李快捷", type = "学生", idType = "二代身份证", idNumber = "310115200205054321", phoneNumber = "13912345678", isVerified = true, isCommon = true))
            passengerDao.insertPassenger(Passenger(name = "王小童", type = "儿童", idType = "二代身份证", idNumber = "440106201809099876", phoneNumber = "13766668888", isVerified = true, isCommon = true))
        }

        // Seed initial notifications
        val currentNotifications = notificationDao.getAllNotifications().first()
        if (currentNotifications.isEmpty()) {
            notificationDao.insertNotification(RailNotification(title = "欢迎使用中国铁路通！", content = "您的个人实名注册信息已成功通过审核。即刻开启您的高速、舒适出行体验吧！", type = "系统公告"))
            notificationDao.insertNotification(RailNotification(title = "客票候补成功通知", content = "恭喜！您候补的2026年7月8日G1次二等座票（北京南-上海虹桥）已兑现成功，请在我的行程中查看详情。", type = "行程提醒"))
            notificationDao.insertNotification(RailNotification(title = "京沪高铁夏季大促", content = "凭铁路积分兑换指定车次（G3, G11）尊享75折优惠。商务出行，积分无忧！", type = "优惠活动"))
        }

        // Seed announcements
        val currentAnnouncements = announcementDao.getAnnouncements().first()
        if (currentAnnouncements.isEmpty()) {
            announcementDao.insertAnnouncement(Announcement(title = "关于实行2026年夏季列车运行图的公告", summary = "自2026年7月1日0时起，全国铁路将实行新的列车运行图，多条高铁大干线增开直达动车组。", content = "为进一步提升客运供给质量，全国铁路将于7月1日零时起实行新一轮列车运行图。京沪高铁、京广高铁增开多趟复兴号智能动车组；长三角、珠三角城际密集增开，实现城际间30分钟互通圈。详情请通过中国铁路通APP车次查询实时掌握。", publishDate = "2026-06-25"))
            announcementDao.insertAnnouncement(Announcement(title = "电子客票核验系统全面升级通知", summary = "全国高铁车站电子闸机系统全面引入非接触式NFC碰一碰及生物识别安全审核。", content = "为了给旅客提供极速、无感的登乘体验，中国铁路全面完成对闸机电子客票读取终端的硬件改造。旅客无需出示纸质车票或调出二维码，只需将手机靠近闸机感应区，或进行快速生物面部比对，便可于0.2秒内安全通过检票口。", publishDate = "2026-07-02"))
        }

        // Seed promos
        val currentPromos = promoActivityDao.getPromos().first()
        if (currentPromos.isEmpty()) {
            promoActivityDao.insertPromo(PromoActivity(title = "新注册旅客购票首单立减 ¥15", description = "首次注册并通过实名认证的铁路通会员，购买任意动车组二等座车票，结算时输入专享码立即减免 15 元现金！", promoCode = "NEWRAIL15", discountRate = 15.0, expireDate = "2026-12-31"))
            promoActivityDao.insertPromo(PromoActivity(title = "积分兑换商务座专享大礼包", description = "凡使用10000积分兑换商务客票的白金卡旅客，均可额外获赠价值50元的高铁到站尊享专车接送券。", promoCode = "VIPSPINNER", discountRate = 50.0, expireDate = "2026-08-31"))
        }
    }

    // --- Core Operations ---

    // 1. Live Query train schedule
    suspend fun queryTrains(fromCity: String, toCity: String, isHighSpeedOnly: Boolean = false): List<TrainSchedule> {
        val schedules = trainDao.getAllTrainSchedules().first()
        
        // Find matching schedules based on city/station mapping
        return schedules.filter { schedule ->
            val matchesFrom = schedule.fromStation.contains(fromCity) || fromCity.contains(schedule.fromStation) ||
                    getCityOfStation(schedule.fromStation).contains(fromCity) || fromCity.contains(getCityOfStation(schedule.fromStation))
            val matchesTo = schedule.toStation.contains(toCity) || toCity.contains(schedule.toStation) ||
                    getCityOfStation(schedule.toStation).contains(toCity) || toCity.contains(getCityOfStation(schedule.toStation))
            
            val matchesSpeed = !isHighSpeedOnly || schedule.trainNumber.startsWith("G") || schedule.trainNumber.startsWith("D")
            
            matchesFrom && matchesTo && matchesSpeed
        }
    }

    private fun getCityOfStation(stationName: String): String {
        return when {
            stationName.contains("北京") -> "北京"
            stationName.contains("上海") -> "上海"
            stationName.contains("广州") -> "广州"
            stationName.contains("深圳") -> "深圳"
            stationName.contains("成都") -> "成都"
            stationName.contains("西安") -> "西安"
            stationName.contains("武汉") -> "武汉"
            stationName.contains("杭州") -> "杭州"
            stationName.contains("南京") -> "南京"
            else -> stationName
        }
    }

    // 2. Add search query history
    suspend fun saveSearchQuery(fromCity: String, toCity: String) {
        val id = "${fromCity}_${toCity}"
        searchHistoryDao.insertHistory(SearchHistory(id, fromCity, toCity))
    }

    suspend fun deleteSearchHistory(id: String) {
        searchHistoryDao.deleteHistory(id)
    }

    // 3. Purchase ticket booking
    suspend fun createOrder(
        trainNumber: String,
        fromStation: String,
        toStation: String,
        date: String,
        seatClass: String,
        passenger: Passenger,
        price: Double
    ): TicketOrder {
        val train = trainDao.getTrainByNumber(trainNumber)
        val depTime = train?.departureTime ?: "12:00"
        val arrTime = train?.arrivalTime ?: "16:00"
        val dur = train?.duration ?: "4h00m"

        val orderId = "CRN" + (10000000..99999999).random()
        val carriageNum = (1..16).random().toString().padStart(2, '0') + "车"
        val seatLetter = when(seatClass) {
            "商务座" -> listOf("A", "C", "F").random()
            else -> listOf("A", "B", "C", "D", "F").random()
        }
        val seatNum = (1..20).random().toString() + seatLetter

        val order = TicketOrder(
            orderId = orderId,
            trainNumber = trainNumber,
            fromStation = fromStation,
            toStation = toStation,
            departureDate = date,
            departureTime = depTime,
            arrivalTime = arrTime,
            duration = dur,
            passengerName = passenger.name,
            passengerIdNumber = passenger.idNumber,
            seatClass = seatClass,
            carriage = carriageNum,
            seatNumber = seatNum,
            price = price,
            boardingGate = train?.let { getStationBoardingGate(fromStation) } ?: "08B",
            platform = train?.let { getStationPlatform(fromStation) } ?: "5",
            status = "待支付",
            qrCodePayload = "CR-TICKET|$orderId|$trainNumber|$carriageNum|$seatNum|$date|SECURE-PASS"
        )

        ticketOrderDao.insertOrder(order)
        return order
    }

    private fun getStationBoardingGate(station: String): String {
        return when(station) {
            "北京南" -> "12B, 13B"
            "上海虹桥" -> "10B, 11A"
            "广州南" -> "08A, 09B"
            "深圳北" -> "15A, 15B"
            "成都东" -> "05B, 06A"
            "西安北" -> "16A, 17B"
            else -> "02A, 03B"
        }
    }

    private fun getStationPlatform(station: String): String {
        return when(station) {
            "北京南" -> "6"
            "上海虹桥" -> "4"
            "广州南" -> "8"
            "深圳北" -> "11"
            "成都东" -> "3"
            "西安北" -> "13"
            else -> "2"
        }
    }

    suspend fun saveOrder(order: TicketOrder) {
        ticketOrderDao.insertOrder(order)
    }

    // 4. Passenger list maintenance
    suspend fun addPassenger(passenger: Passenger) {
        passengerDao.insertPassenger(passenger)
    }

    suspend fun updatePassenger(passenger: Passenger) {
        passengerDao.updatePassenger(passenger)
    }

    suspend fun deletePassenger(passenger: Passenger) {
        passengerDao.deletePassenger(passenger)
    }

    // 5. Send Notification
    suspend fun pushNotification(title: String, content: String, type: String) {
        notificationDao.insertNotification(RailNotification(title = title, content = content, type = type))
    }

    suspend fun markAllNotificationsRead() {
        notificationDao.markAllAsRead()
    }

    // 6. Admin functions
    suspend fun addTrainSchedule(train: TrainSchedule) {
        trainDao.insertTrainSchedules(listOf(train))
    }

    suspend fun publishAnnouncement(title: String, summary: String, content: String) {
        announcementDao.insertAnnouncement(
            Announcement(title = title, summary = summary, content = content, publishDate = "2026-07-07", author = "系统后台管理员")
        )
    }

    // 7. Auto Transit Route Planning (Smart Multimodal Recommendations)
    fun planTransfer(start: String, dest: String): List<TransferPlan> {
        // Mock calculations for route planning if direct route lacks or to support the feature requested
        val intermediate = "南京南" // Example transfer hub
        val seg1 = RouteSegment(
            segmentNum = 1,
            trainNumber = "G11",
            fromStation = start,
            toStation = intermediate,
            departureTime = "08:00",
            arrivalTime = "11:11",
            duration = "3h11m",
            seatClass = "二等座",
            price = 443.0
        )
        val seg2 = RouteSegment(
            segmentNum = 2,
            trainNumber = "G1301",
            fromStation = intermediate,
            toStation = dest,
            departureTime = "11:55",
            arrivalTime = "17:15",
            duration = "5h20m",
            seatClass = "二等座",
            price = 550.0
        )

        return listOf(
            TransferPlan(
                id = "TP-01",
                planType = "最快路线",
                startStation = start,
                transferStation = intermediate,
                endStation = dest,
                segments = listOf(seg1, seg2),
                totalDuration = "9h15m",
                transferBuffer = "44分钟",
                totalCost = 993.0
            ),
            TransferPlan(
                id = "TP-02",
                planType = "最低票价",
                startStation = start,
                transferStation = "济南西",
                endStation = dest,
                segments = listOf(
                    RouteSegment(1, "K101", start, "济南", "13:15", "17:45", "4h30m", "硬座", 72.0),
                    RouteSegment(2, "G73", "济南西", dest, "19:15", "23:55", "4h40m", "二等座", 380.0)
                ),
                totalDuration = "10h40m",
                transferBuffer = "1h30m",
                totalCost = 452.0
            )
        )
    }
}
