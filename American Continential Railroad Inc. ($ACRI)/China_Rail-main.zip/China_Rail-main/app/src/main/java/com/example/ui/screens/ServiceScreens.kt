package com.example.ui.screens

import com.example.ui.theme.*

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RailNotification
import com.example.data.model.Station
import com.example.data.model.TrainSchedule
import com.example.data.model.TransferPlan
import com.example.ui.viewmodel.RailViewModel

// --- 1. Station Guide Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationGuideScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit
) {
    val stations by viewModel.allStations.collectAsState()
    var query by remember { mutableStateOf("") }
    var selectedStation by remember { mutableStateOf<Station?>(null) }

    val filtered = stations.filter { it.name.contains(query) || it.city.contains(query) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "车站特服与接驳指南", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
                .padding(16.dp)
        ) {
            if (selectedStation != null) {
                // Display specific detailed guide
                val s = selectedStation!!
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = s.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Slate900)
                                IconButton(onClick = { selectedStation = null }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color.Gray)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = s.desc, fontSize = 13.sp, color = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    StationDetailCard(title = "站房导向", content = s.mapInfo, color = DeepBlueDark)
                    StationDetailCard(title = "推荐检票口", content = s.boardingGate, color = PrimaryRed)
                    StationDetailCard(title = "站台轨道", content = s.platform, color = Color(0xFF333333))

                    StationListDetailCard(title = "商铺百货", items = s.shops)
                    StationListDetailCard(title = "特色餐饮", items = s.dining)
                    StationListDetailCard(title = "换乘交通接驳", items = s.transfers)
                    StationListDetailCard(title = "无障碍爱心服务", items = s.accessibility)
                }
            } else {
                // Standard searchable index list
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("搜索城市或车站名称 (例如: 北京)") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered) { station ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStation = station },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = station.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333))
                                    Text(text = "所在城市: ${station.city}", fontSize = 12.sp, color = Color.Gray)
                                }
                                Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = Color.LightGray)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StationDetailCard(title: String, content: String, color: Color) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(24.dp)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, fontSize = 12.sp, color = Color.Gray)
                Text(text = content, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333))
            }
        }
    }
}

@Composable
fun StationListDetailCard(title: String, items: List<String>) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start
            ) {
                items.forEach { item ->
                    Box(
                        modifier = Modifier
                            .padding(end = 6.dp, bottom = 4.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(PrimaryRedLight)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = item, fontSize = 11.sp, color = PrimaryRed)
                    }
                }
            }
        }
    }
}

// --- 2. Train stop tracking / Live details Tracker ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainTrackerScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit
) {
    val queryNum by viewModel.trackedTrainNumber.collectAsState()
    val searchResult by viewModel.trackedTrainResult.collectAsState()
    val history by viewModel.trackerSearchHistory.collectAsState()
    val isLoading by viewModel.isQueryLoading.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "列车停靠时刻表核验", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
                .padding(16.dp)
        ) {
            // Search Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = queryNum,
                    onValueChange = { viewModel.trackedTrainNumber.value = it },
                    placeholder = { Text("输入车次 (例如: G1, K101)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = { viewModel.searchTrainTracker() },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed),
                    modifier = Modifier.height(56.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "查询")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search History Chips
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "常用搜索：", fontSize = 11.sp, color = Color.Gray)
                history.forEach { hist ->
                    Box(
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFE0E0E0))
                            .clickable {
                                viewModel.trackedTrainNumber.value = hist
                                viewModel.searchTrainTracker()
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(text = hist, fontSize = 11.sp, color = Color.DarkGray, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (isLoading) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryRed)
                }
            } else if (searchResult != null) {
                val t = searchResult!!
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = t.trainNumber, fontSize = 24.sp, fontWeight = FontWeight.Black, color = Slate900)
                                Text(text = "机型：${t.trainModel}  |  正点率：${t.onTimeRate}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFE8F5E9))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = "正点运行", fontSize = 11.sp, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = "沿途停靠时刻明细", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Stops Timelines
                        val stopList = t.stopStations.split(";")
                        val timeList = t.stopTimes.split(";")

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(stopList.indices.toList()) { index ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(30.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(if (index == 0 || index == stopList.size - 1) PrimaryRed else DeepBlueDark)
                                        )
                                        if (index < stopList.size - 1) {
                                            Box(
                                                modifier = Modifier
                                                    .width(2.dp)
                                                    .height(30.dp)
                                                    .background(Color.LightGray)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = stopList[index],
                                            fontSize = 15.sp,
                                            fontWeight = if (index == 0 || index == stopList.size - 1) FontWeight.Bold else FontWeight.Normal,
                                            color = Color(0xFF333333)
                                        )
                                        Text(
                                            text = timeList.getOrNull(index) ?: "--:--",
                                            fontSize = 14.sp,
                                            color = Color.Gray,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(text = "请输入并查询车次时刻线路", fontSize = 13.sp, color = Color.LightGray)
                }
            }
        }
    }
}

// --- 3. Smart Multimodal Transfer Planner ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferPlannerScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit
) {
    val fromCity by viewModel.searchFromCity.collectAsState()
    val toCity by viewModel.searchToCity.collectAsState()
    val plans by viewModel.transferPlans.collectAsState()
    val isLoading by viewModel.isTransferLoading.collectAsState()

    // Trigger calculation automatically
    LaunchedEffect(key1 = fromCity, key2 = toCity) {
        viewModel.queryTransferPlans()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "智能公铁联运换乘", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(PrimaryRedLight)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "当前规划线路：", fontSize = 11.sp, color = Color.Gray)
                    Text(text = "$fromCity ⇌ $toCity", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Slate900)
                }
                Icon(imageVector = Icons.Default.AltRoute, contentDescription = null, tint = PrimaryRed)
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryRed)
                }
            } else if (plans.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = "未找到合适的联运换乘推荐方案", fontSize = 13.sp, color = Color.Gray)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(plans) { plan ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(PrimaryRed)
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = plan.planType, fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    Text(text = "中转枢纽: ${plan.transferStation}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryRed)
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Visual multi segments flow
                                plan.segments.forEachIndexed { idx, seg ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = "${seg.fromStation} → ${seg.toStation}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                            Text(text = "${seg.trainNumber} | 二等座", fontSize = 11.sp, color = Color.Gray)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = "${seg.departureTime} - ${seg.arrivalTime}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            Text(text = "历时 ${seg.duration}", fontSize = 11.sp, color = Color.LightGray)
                                        }
                                    }
                                    if (idx < plan.segments.size - 1) {
                                        // Intersect block
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 6.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFFFFF9C4))
                                                .padding(horizontal = 8.dp, vertical = 4.dp),
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Text(text = "站内便捷换乘时间: ${plan.transferBuffer}", fontSize = 10.sp, color = Color(0xFFF57F17), fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = Color(0xFFF0F0F0))
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "联运总历时：${plan.totalDuration}", fontSize = 12.sp, color = Color.Gray)
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(text = "合计 ", fontSize = 11.sp, color = Color.Gray)
                                        Text(text = "¥${plan.totalCost.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = PrimaryRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 4. Service Help Center, Live Chat AI Support, FAQs, and Feedback ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceCenterScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit
) {
    var activeSubTab by remember { mutableStateOf(0) } // 0: AI Assistant Chat, 1: FAQ Guides, 2: Feedback Submission
    val chatFeeds by viewModel.chatMessages.collectAsState()
    val chatInput by viewModel.currentChatInput.collectAsState()

    var feedbackTitle by remember { mutableStateOf("") }
    var feedbackDesc by remember { mutableStateOf("") }
    var isSubmitted by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "铁路12306客服中心", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
        ) {
            // Horizontal Tab Row
            Row(modifier = Modifier.fillMaxWidth().background(Color.White)) {
                listOf("智能客服", "常见问题", "意见反馈").forEachIndexed { index, title ->
                    val isSelected = activeSubTab == index
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { activeSubTab = index }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) PrimaryRed else Color.Gray
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                when (activeSubTab) {
                    0 -> {
                        // AI Live Chat panel
                        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                            LazyColumn(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(bottom = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(chatFeeds) { chat ->
                                    val isUser = chat.second
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                                    ) {
                                        Card(
                                            modifier = Modifier.fillMaxWidth(0.82f),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isUser) PrimaryRed else Color.White
                                            )
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Text(
                                                    text = chat.first,
                                                    fontSize = 13.sp,
                                                    color = if (isUser) Color.White else Color(0xFF333333)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Chat input panel
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = chatInput,
                                    onValueChange = { viewModel.currentChatInput.value = it },
                                    placeholder = { Text("咨询退票手续费、改签等问题...") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = { viewModel.sendChatMessage() },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(PrimaryRed)
                                ) {
                                    Icon(imageVector = Icons.Default.Send, contentDescription = null, tint = Color.White)
                                }
                            }
                        }
                    }
                    1 -> {
                        // FAQ directory accordion mockup
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            item { FAQRow(q = "如何办理电子客票退票手续？", a = "在‘我的车票’中，选择未来行程，直接点击‘退票’按钮即可。发车前未打印报销凭证的均支持网上退款。") }
                            item { FAQRow(q = "车票改签有什么规定和次数限制？", a = "一张车票仅支持免费改签一次。改签不收取手续费，但若产生票价差额将多退少补。") }
                            item { FAQRow(q = "打印报销凭证有期限吗？", a = "自开车之日起 180 天内，旅客凭购票实名身份证件在车站自助取票机打印报销发票。") }
                            item { FAQRow(q = "学生、儿童半价优惠资格如何验证？", a = "学生证需在每学年首次乘车前至车站自助机完成‘学生资质核验’；儿童按年龄计价，6-14周岁购买优惠票。") }
                        }
                    }
                    2 -> {
                        // Feedback Form inputs
                        if (isSubmitted) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(56.dp))
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(text = "提交成功！我们已收到您的反馈", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "意见审核进度将在1-2天发送至您的注册手机。", fontSize = 11.sp, color = Color.Gray)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = { isSubmitted = false },
                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed)
                                    ) {
                                        Text(text = "再次填写")
                                    }
                                }
                            }
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(text = "提交您的宝贵改进意见", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = feedbackTitle,
                                    onValueChange = { feedbackTitle = it },
                                    label = { Text("意见简述 (e.g. 刷脸闸机故障)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = feedbackDesc,
                                    onValueChange = { feedbackDesc = it },
                                    label = { Text("详细描述") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 4
                                )
                                Spacer(modifier = Modifier.height(20.dp))
                                Button(
                                    onClick = {
                                        if (feedbackTitle.isNotEmpty() && feedbackDesc.isNotEmpty()) {
                                            viewModel.submitFeedback(feedbackTitle, feedbackDesc)
                                            feedbackTitle = ""
                                            feedbackDesc = ""
                                            isSubmitted = true
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed)
                                ) {
                                    Text(text = "提交反馈")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FAQRow(q: String, a: String) {
    var expanded by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Q: $q", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate900, modifier = Modifier.weight(1f))
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color.LightGray
                )
            }
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = Color(0xFFF0F0F0))
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "A: $a", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

// --- 5. Notifications List Center ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationCenterScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit
) {
    val list by viewModel.allNotifications.collectAsState()

    LaunchedEffect(key1 = true) {
        viewModel.markAllNotificationsRead()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "消息通知中心", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
                .padding(16.dp)
        ) {
            if (list.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = "暂无系统和行程通知", fontSize = 13.sp, color = Color.LightGray)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { alert ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.NotificationsActive,
                                            contentDescription = null,
                                            tint = PrimaryRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = alert.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate900)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFFEFEFEF))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = alert.type, fontSize = 9.sp, color = Color.Gray)
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = alert.content, fontSize = 12.sp, color = Color.DarkGray)
                            }
                        }
                    }
                }
            }
        }
    }
}
