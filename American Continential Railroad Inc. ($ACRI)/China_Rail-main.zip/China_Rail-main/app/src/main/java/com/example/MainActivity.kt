package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.Divider
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.model.TicketOrder
import com.example.data.repository.RailRepository
import com.example.ui.screens.AdminStaffPortalScreen
import com.example.ui.screens.ETicketViewScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.MyTicketsScreen
import com.example.ui.screens.NotificationCenterScreen
import com.example.ui.screens.OrderConfirmPayScreen
import com.example.ui.screens.PassengerSelectorScreen
import com.example.ui.screens.SeatSelectionScreen
import com.example.ui.screens.ServiceCenterScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.StationGuideScreen
import com.example.ui.screens.TrainResultsScreen
import com.example.ui.screens.TrainTrackerScreen
import com.example.ui.screens.TransferPlannerScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailViewModel

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase
    private lateinit var repository: RailRepository
    private lateinit var viewModel: RailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize Room Local Persistence SQLite
        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "china_rail_db"
        ).fallbackToDestructiveMigration().build()

        // 2. Initialize Repos & State Manager
        repository = RailRepository(db)
        viewModel = RailViewModel(repository)

        setContent {
            MyApplicationTheme {
                var showSplash by remember { mutableStateOf(true) }

                if (showSplash) {
                    SplashScreen(onDismiss = { showSplash = false })
                } else {
                    MainAppScaffold(viewModel = viewModel)
                }
            }
        }
    }
}

// --- Main App Coordinator with Scaffold ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(viewModel: RailViewModel) {
    var currentScreen by remember { mutableStateOf("Home") } // Home, MyTickets, Profile, etc.
    var selectedOrderForTicketDetail by remember { mutableStateOf<TicketOrder?>(null) }
    val staffMode by viewModel.isStaffMode.collectAsState()

    // Screen stack controller to support nested detail actions
    val onNavigate = { target: String ->
        currentScreen = target
    }

    Scaffold(
        bottomBar = {
            // Keep bottom nav visible on primary roots: Home, MyTickets, Profile, AdminStaff
            val showBottomNav = currentScreen in listOf("Home", "MyTickets", "Profile", "AdminStaff")
            if (showBottomNav) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentScreen == "Home",
                        onClick = { currentScreen = "Home" },
                        icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("首页", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PrimaryRed,
                            selectedTextColor = PrimaryRed,
                            indicatorColor = PrimaryRedLight,
                            unselectedIconColor = Slate400,
                            unselectedTextColor = Slate600
                        ),
                        modifier = Modifier.testTag("nav_home_tab")
                    )
                    NavigationBarItem(
                        selected = currentScreen == "MyTickets",
                        onClick = { currentScreen = "MyTickets" },
                        icon = { Icon(imageVector = Icons.Default.QrCode, contentDescription = "Tickets") },
                        label = { Text("我的行程", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PrimaryRed,
                            selectedTextColor = PrimaryRed,
                            indicatorColor = PrimaryRedLight,
                            unselectedIconColor = Slate400,
                            unselectedTextColor = Slate600
                        ),
                        modifier = Modifier.testTag("nav_tickets_tab")
                    )
                    NavigationBarItem(
                        selected = currentScreen == "Profile",
                        onClick = { currentScreen = "Profile" },
                        icon = { Icon(imageVector = Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("个人中心", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PrimaryRed,
                            selectedTextColor = PrimaryRed,
                            indicatorColor = PrimaryRedLight,
                            unselectedIconColor = Slate400,
                            unselectedTextColor = Slate600
                        ),
                        modifier = Modifier.testTag("nav_profile_tab")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Check if staff toggle was explicitly activated in the header!
            LaunchedEffect(staffMode) {
                if (staffMode) {
                    currentScreen = "AdminStaff"
                } else if (currentScreen == "AdminStaff") {
                    currentScreen = "Home"
                }
            }

            // Crossfade animated transition between screens
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    "Home" -> HomeDashboardScreen(
                        viewModel = viewModel,
                        onNavigateToResults = { onNavigate("TrainResults") },
                        onQuickActionClick = { tag -> onNavigate(tag) }
                    )
                    "TrainResults" -> TrainResultsScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("Home") },
                        onNavigateToSeatSelection = { onNavigate("SeatSelection") }
                    )
                    "SeatSelection" -> SeatSelectionScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("TrainResults") },
                        onNavigateToPassengers = { onNavigate("PassengerSelect") }
                    )
                    "PassengerSelect" -> PassengerSelectorScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("SeatSelection") },
                        onNavigateToConfirm = { onNavigate("OrderConfirm") }
                    )
                    "OrderConfirm" -> OrderConfirmPayScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("PassengerSelect") },
                        onNavigateToTicket = { onNavigate("ETicket") }
                    )
                    "ETicket" -> {
                        val pendingOrder by viewModel.pendingOrder.collectAsState()
                        pendingOrder?.let { order ->
                            ETicketViewScreen(
                                order = order,
                                onBack = { onNavigate("MyTickets") }
                            )
                        } ?: onNavigate("MyTickets")
                    }
                    "MyTickets" -> MyTicketsScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("Home") },
                        onNavigateToTicket = { order ->
                            selectedOrderForTicketDetail = order
                            onNavigate("TicketDetail")
                        }
                    )
                    "TicketDetail" -> {
                        selectedOrderForTicketDetail?.let { order ->
                            ETicketViewScreen(
                                order = order,
                                onBack = { onNavigate("MyTickets") }
                            )
                        } ?: onNavigate("MyTickets")
                    }
                    "StationGuide" -> StationGuideScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("Home") }
                    )
                    "TrainTracker" -> TrainTrackerScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("Home") }
                    )
                    "TransferPlanner" -> TransferPlannerScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("Home") }
                    )
                    "ServiceCenter" -> ServiceCenterScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("Home") }
                    )
                    "Notifications" -> NotificationCenterScreen(
                        viewModel = viewModel,
                        onBack = { onNavigate("Home") }
                    )
                    "AdminStaff" -> AdminStaffPortalScreen(
                        viewModel = viewModel,
                        onBack = {
                            viewModel.isStaffMode.value = false
                            onNavigate("Home")
                        }
                    )
                    "Profile" -> ProfileCenterScreen(
                        viewModel = viewModel,
                        onNavigate = onNavigate
                    )
                }
            }
        }
    }
}

// --- 3. User Personal Profile Center Composable ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileCenterScreen(
    viewModel: RailViewModel,
    onNavigate: (String) -> Unit
) {
    val user by viewModel.userProfile.collectAsState()
    val passengers by viewModel.allPassengers.collectAsState()
    val allOrders by viewModel.allOrders.collectAsState()
    val notifications by viewModel.allNotifications.collectAsState()

    val pendingCount = allOrders.count { it.status == "待支付" }
    val paidCount = allOrders.count { it.status == "已出票" || it.status == "已改签" }
    val unreadAlerts = notifications.count { !it.isRead }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundGray)
            .verticalScroll(rememberScrollState())
    ) {
        // Deep Blue Header with avatar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(DeepBlueDark, DeepBlueLight)
                    )
                )
                .padding(horizontal = 20.dp, vertical = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User Avatar",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = user.realName, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF4CAF50))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, tint = Color.White, modifier = Modifier.size(10.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(text = "已实名", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Text(text = "身份证: ${user.idCardHidden}", fontSize = 12.sp, color = Color.White.copy(alpha = 0.75f))
                }
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // Loyalty Rewards Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "铁路常旅客会员积分", fontSize = 11.sp, color = Slate600)
                        Text(text = "${user.memberPoints} 分", fontSize = 24.sp, fontWeight = FontWeight.Black, color = PrimaryRed)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFFFFF9C4))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = Color(0xFFF57F17), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "黄金权益", fontSize = 11.sp, color = Color(0xFFF57F17), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Quick Access Tabs: Orders counter
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    ProfileBadgeItem(label = "全部行程", count = allOrders.size, icon = Icons.Default.Train) {
                        onNavigate("MyTickets")
                    }
                    ProfileBadgeItem(label = "未出行车票", count = paidCount, icon = Icons.Default.ConfirmationNumber) {
                        onNavigate("MyTickets")
                    }
                    ProfileBadgeItem(label = "消息通知", count = unreadAlerts, icon = Icons.Default.Notifications) {
                        onNavigate("Notifications")
                    }
                }
            }

            // List of Frequent Passengers
            Text(text = "您的常用乘车人 (${passengers.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    passengers.forEachIndexed { index, pass ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = pass.name, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFFE8F5E9))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = pass.type, fontSize = 9.sp, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text(text = "身份证：${pass.idNumber.take(4)}**********${pass.idNumber.takeLast(4)}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(16.dp))
                        }
                        if (index < passengers.size - 1) {
                            Divider(color = Color(0xFFF5F5F5))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileBadgeItem(label: String, count: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(4.dp)
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(PrimaryRedLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = label, tint = PrimaryRed, modifier = Modifier.size(20.dp))
            }
            if (count > 0) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(PrimaryRed),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = count.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = label, fontSize = 12.sp, color = Slate600)
    }
}
