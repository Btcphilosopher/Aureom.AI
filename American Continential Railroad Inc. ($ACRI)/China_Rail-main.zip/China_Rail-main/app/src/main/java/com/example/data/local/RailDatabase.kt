package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.Update
import com.example.data.model.Announcement
import com.example.data.model.Passenger
import com.example.data.model.PromoActivity
import com.example.data.model.RailNotification
import com.example.data.model.SearchHistory
import com.example.data.model.Station
import com.example.data.model.TicketOrder
import com.example.data.model.TrainSchedule
import kotlinx.coroutines.flow.Flow

// --- Room Type Converters for Lists ---
class RoomConverters {
    @TypeConverter
    fun fromString(value: String): List<String> {
        return if (value.isEmpty()) emptyList() else value.split(";")
    }

    @TypeConverter
    fun fromList(list: List<String>): String {
        return list.joinToString(";")
    }
}

// --- DAOs ---

@Dao
interface PassengerDao {
    @Query("SELECT * FROM passengers ORDER BY id DESC")
    fun getAllPassengers(): Flow<List<Passenger>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPassenger(passenger: Passenger): Long

    @Update
    suspend fun updatePassenger(passenger: Passenger)

    @Delete
    suspend fun deletePassenger(passenger: Passenger)
}

@Dao
interface TicketOrderDao {
    @Query("SELECT * FROM orders ORDER BY orderTime DESC")
    fun getAllOrders(): Flow<List<TicketOrder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: TicketOrder)

    @Update
    suspend fun updateOrder(order: TicketOrder)
}

@Dao
interface SearchHistoryDao {
    @Query("SELECT * FROM search_history ORDER BY timestamp DESC LIMIT 6")
    fun getSearchHistory(): Flow<List<SearchHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: SearchHistory)

    @Query("DELETE FROM search_history WHERE id = :id")
    suspend fun deleteHistory(id: String)
}

@Dao
interface StationDao {
    @Query("SELECT * FROM stations")
    fun getAllStations(): Flow<List<Station>>

    @Query("SELECT * FROM stations WHERE code = :code LIMIT 1")
    suspend fun getStationByCode(code: String): Station?

    @Query("SELECT * FROM stations WHERE name = :name LIMIT 1")
    suspend fun getStationByName(name: String): Station?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<Station>)
}

@Dao
interface TrainDao {
    @Query("SELECT * FROM train_schedules")
    fun getAllTrainSchedules(): Flow<List<TrainSchedule>>

    @Query("SELECT * FROM train_schedules WHERE trainNumber = :trainNumber LIMIT 1")
    suspend fun getTrainByNumber(trainNumber: String): TrainSchedule?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrainSchedules(schedules: List<TrainSchedule>)
}

@Dao
interface RailNotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<RailNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: RailNotification)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()
}

@Dao
interface AnnouncementDao {
    @Query("SELECT * FROM announcements ORDER BY id DESC")
    fun getAnnouncements(): Flow<List<Announcement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement)
}

@Dao
interface PromoActivityDao {
    @Query("SELECT * FROM promos ORDER BY id DESC")
    fun getPromos(): Flow<List<PromoActivity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromo(promo: PromoActivity)
}

// --- App Database ---
@Database(
    entities = [
        Passenger::class,
        TicketOrder::class,
        SearchHistory::class,
        Station::class,
        TrainSchedule::class,
        RailNotification::class,
        Announcement::class,
        PromoActivity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(RoomConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun passengerDao(): PassengerDao
    abstract fun ticketOrderDao(): TicketOrderDao
    abstract fun searchHistoryDao(): SearchHistoryDao
    abstract fun stationDao(): StationDao
    abstract fun trainDao(): TrainDao
    abstract fun railNotificationDao(): RailNotificationDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun promoActivityDao(): PromoActivityDao
}
