package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Announcement
import com.example.data.model.Passenger
import com.example.data.model.PromoActivity
import com.example.data.model.RailNotification
import com.example.data.model.SearchHistory
import com.example.data.model.Station
import com.example.data.model.TicketOrder
import com.example.data.model.TrainSchedule
import com.example.data.model.TransferPlan
import com.example.data.model.UserProfile
import com.example.data.repository.RailRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class RailViewModel(private val repository: RailRepository) : ViewModel() {

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    // --- 1. Reactive Streams from Repository ---
    val allPassengers: StateFlow<List<Passenger>> = repository.allPassengers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<TicketOrder>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchHistory: StateFlow<List<SearchHistory>> = repository.searchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStations: StateFlow<List<Station>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotifications: StateFlow<List<RailNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<Announcement>> = repository.announcements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val promos: StateFlow<List<PromoActivity>> = repository.promos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- 2. Local UI States ---
    val userProfile = MutableStateFlow(UserProfile())

    // Search query parameters
    val searchFromCity = MutableStateFlow("北京")
    val searchToCity = MutableStateFlow("上海")
    val searchDate = MutableStateFlow(getTomorrowDateString())
    val searchIsRoundTrip = MutableStateFlow(false)
    val searchHighSpeedOnly = MutableStateFlow(true)

    // Query Results State
    private val _queriedTrains = MutableStateFlow<List<TrainSchedule>>(emptyList())
    val queriedTrains: StateFlow<List<TrainSchedule>> = _queriedTrains.asStateFlow()

    private val _isQueryLoading = MutableStateFlow(false)
    val isQueryLoading: StateFlow<Boolean> = _isQueryLoading.asStateFlow()

    // Booking Process States
    val selectedTrain = MutableStateFlow<TrainSchedule?>(null)
    val selectedSeatClass = MutableStateFlow("二等座")
    val selectedPassengers = MutableStateFlow<List<Passenger>>(emptyList())
    val pendingOrder = MutableStateFlow<TicketOrder?>(null)

    // Payment Processing
    private val _isPaying = MutableStateFlow(false)
    val isPaying: StateFlow<Boolean> = _isPaying.asStateFlow()

    private val _paySuccess = MutableStateFlow(false)
    val paySuccess: StateFlow<Boolean> = _paySuccess.asStateFlow()

    // Train Status / Timeline Tracker
    val trackedTrainNumber = MutableStateFlow("")
    val trackedTrainResult = MutableStateFlow<TrainSchedule?>(null)
    val trackerSearchHistory = MutableStateFlow<List<String>>(listOf("G1", "G101", "D35"))

    // Transit Planner
    val transferPlans = MutableStateFlow<List<TransferPlan>>(emptyList())
    val isTransferLoading = MutableStateFlow(false)

    // Station Guide Search
    val stationSearchQuery = MutableStateFlow("")
    val selectedStationDetails = MutableStateFlow<Station?>(null)

    // Service Center State
    val chatMessages = MutableStateFlow<List<Pair<String, Boolean>>>(listOf( // text to isUser
        Pair("您好！我是12306智能客运助手，请问有什么可以帮您？", false)
    ))
    val currentChatInput = MutableStateFlow("")

    // Admin / Staff State
    val isStaffMode = MutableStateFlow(false)
    val activeStaffTab = MutableStateFlow(0) // 0: Dashboard, 1: Add Train, 2: Post Announce

    // Mock Admin Dashboard Data (Canvas drawings inputs)
    val hourlyTicketSales = listOf(350, 480, 520, 680, 1100, 1500, 1850, 1200, 980, 1340, 1450, 750)
    val stationPassengerFlow = listOf(
        Pair("北京南", 45000),
        Pair("上海虹桥", 52000),
        Pair("广州南", 61000),
        Pair("深圳北", 38000),
        Pair("成都东", 29000)
    )

    // --- 3. Business Methods ---

    // Swap cities
    fun swapSearchCities() {
        val temp = searchFromCity.value
        searchFromCity.value = searchToCity.value
        searchToCity.value = temp
    }

    // Load trains based on parameters
    fun searchTrains() {
        _isQueryLoading.value = true
        viewModelScope.launch {
            // Simulate smooth network delay
            kotlinx.coroutines.delay(600)
            val results = repository.queryTrains(
                searchFromCity.value,
                searchToCity.value,
                searchHighSpeedOnly.value
            )
            _queriedTrains.value = results
            _isQueryLoading.value = false

            // Save search history
            repository.saveSearchQuery(searchFromCity.value, searchToCity.value)
        }
    }

    // Toggle passenger selection
    fun togglePassengerSelection(passenger: Passenger) {
        val current = selectedPassengers.value.toMutableList()
        if (current.any { it.id == passenger.id }) {
            current.removeAll { it.id == passenger.id }
        } else {
            current.add(passenger)
        }
        selectedPassengers.value = current
    }

    // Confirm Selection & Create Order
    fun createPendingOrder() {
        val train = selectedTrain.value ?: return
        val passengerList = selectedPassengers.value
        if (passengerList.isEmpty()) return

        val price = when(selectedSeatClass.value) {
            "商务座" -> train.businessClassPrice
            "一等座" -> train.firstClassPrice
            "二等座" -> train.secondClassPrice
            "软卧" -> train.softSleeperPrice
            "硬卧" -> train.hardSleeperPrice
            else -> train.hardSeatPrice
        }

        viewModelScope.launch {
            // For simplicity in single passenger representation, or we create multiple orders for multiple passengers.
            // Let's create an order for the first passenger.
            val passenger = passengerList.first()
            val order = repository.createOrder(
                trainNumber = train.trainNumber,
                fromStation = train.fromStation,
                toStation = train.toStation,
                date = searchDate.value,
                seatClass = selectedSeatClass.value,
                passenger = passenger,
                price = price
            )
            pendingOrder.value = order
        }
    }

    // Pay Order
    fun executePayment(methodName: String) {
        val order = pendingOrder.value ?: return
        _isPaying.value = true
        _paySuccess.value = false

        viewModelScope.launch {
            // Simulated secure network payment bank processing
            kotlinx.coroutines.delay(1200)
            
            // Update order in database to Paid
            val paidOrder = order.copy(status = "已出票")
            repository.saveOrder(paidOrder)
            
            // Add loyalty points
            val gainedPoints = (order.price / 10).toInt()
            userProfile.value = userProfile.value.copy(
                memberPoints = userProfile.value.memberPoints + gainedPoints
            )

            // Send notification
            repository.pushNotification(
                title = "出票成功提醒 (${order.trainNumber})",
                content = "您已成功购买 ${order.departureDate} ${order.trainNumber}次列车电子客票（${order.fromStation}-${order.toStation}，${order.carriage}${order.seatNumber}座）。祝您旅途愉快！",
                type = "行程提醒"
            )

            _isPaying.value = false
            _paySuccess.value = true
            pendingOrder.value = paidOrder
        }
    }

    // Refund Order
    fun refundTicket(order: TicketOrder) {
        viewModelScope.launch {
            val updated = order.copy(status = "已退票")
            repository.saveOrder(updated)
            repository.pushNotification(
                title = "车票退款成功通知",
                content = "您申请退订的 ${order.departureDate} ${order.trainNumber}次（${order.fromStation}-${order.toStation}）车票已成功办理退票，退款金额 ¥${order.price} 将按原支付渠道退回。",
                type = "行程提醒"
            )
        }
    }

    // Change / Reschedule Ticket
    fun changeTicket(order: TicketOrder, newDate: String) {
        viewModelScope.launch {
            val updated = order.copy(departureDate = newDate, status = "已改签")
            repository.saveOrder(updated)
            repository.pushNotification(
                title = "车票改签成功通知",
                content = "您的车票已成功改签至 ${newDate} 发车。新座位信息请查看您的电子客票。",
                type = "行程提醒"
            )
        }
    }

    // Add Passenger Profile
    fun addPassengerProfile(name: String, idType: String, idNumber: String, phone: String, type: String = "成人") {
        viewModelScope.launch {
            val passenger = Passenger(
                name = name,
                type = type,
                idType = idType,
                idNumber = idNumber,
                phoneNumber = phone,
                isVerified = true,
                isCommon = true
            )
            repository.addPassenger(passenger)
        }
    }

    // Delete Passenger Profile
    fun deletePassengerProfile(passenger: Passenger) {
        viewModelScope.launch {
            repository.deletePassenger(passenger)
        }
    }

    // Search Train Route Details (Live Tracker)
    fun searchTrainTracker() {
        val num = trackedTrainNumber.value.trim().uppercase()
        if (num.isEmpty()) return

        viewModelScope.launch {
            _isQueryLoading.value = true
            kotlinx.coroutines.delay(400)
            val allSchedules = repository.allTrainSchedules.first()
            val matched = allSchedules.find { it.trainNumber.equals(num, ignoreCase = true) }
            trackedTrainResult.value = matched
            _isQueryLoading.value = false

            if (!trackerSearchHistory.value.contains(num)) {
                trackerSearchHistory.value = listOf(num) + trackerSearchHistory.value.take(4)
            }
        }
    }

    // Smart Transfer query
    fun queryTransferPlans() {
        isTransferLoading.value = true
        viewModelScope.launch {
            kotlinx.coroutines.delay(600)
            val plans = repository.planTransfer(searchFromCity.value, searchToCity.value)
            transferPlans.value = plans
            isTransferLoading.value = false
        }
    }

    // Custom Live Chat support answers
    fun sendChatMessage() {
        val text = currentChatInput.value.trim()
        if (text.isEmpty()) return

        val current = chatMessages.value.toMutableList()
        current.add(Pair(text, true)) // user message
        chatMessages.value = current
        currentChatInput.value = ""

        viewModelScope.launch {
            kotlinx.coroutines.delay(800)
            val response = getHelperResponse(text)
            val updated = chatMessages.value.toMutableList()
            updated.add(Pair(response, false)) // bot response
            chatMessages.value = updated
        }
    }

    private fun getHelperResponse(query: String): String {
        return when {
            query.contains("退票") || query.contains("退钱") -> "旅客可在发车前在应用内快捷办理退票。开车前48小时以上退票免费，24-48小时收取5%手续费，不足24小时收取10%手续费。电子退款将于1-3个工作日内原路返还。"
            query.contains("改签") -> "车票可免费办理一次改签，改签可选范围为开车前及开车后当天的其他列车（有余票情况下）。改签后的新客票同样支持电子退票。"
            query.contains("报销") || query.contains("凭证") -> "购票成功后，可在发车起180天内，凭购票身份证件到任意高铁站自助取票机打印报销凭证。亦可在本软件‘行程管理’中一键下载电子发票。"
            query.contains("带孩子") || query.contains("儿童") -> "自2023年起，实行车票实名制儿童计价。未满6周岁的儿童且不单独占用席位的，可免费乘车（需提前申明关联）；年满6周岁且未满14周岁的儿童应当购买儿童优惠票。"
            query.contains("丢东西") || query.contains("遗失") || query.contains("失物") -> "我们提供全方位的失物招领服务。您可以通过‘客服中心’登记遗失物品描述，我们的工作人员一旦找到，会第一时间与您核对并顺丰邮寄给您。"
            query.contains("积分") || query.contains("会员") -> "中国铁路会员购票每消费 ¥1 可累积 5 积分。当积分首次达到 10000 分时，可直接在购票时勾选‘积分兑换’，兑换指定‘尊’字样车次的车票。"
            else -> "收到您的问题了。如需人工服务，可在下方选择‘人工客服’，全国客服专线：12306。"
        }
    }

    fun submitFeedback(title: String, desc: String) {
        viewModelScope.launch {
            repository.pushNotification(
                title = "意见反馈已受理",
                content = "感谢您提交的问题：【$title】。我们的客运技术保障团队正在核实，将尽快向您的注册手机号发送回复短信。",
                type = "系统公告"
            )
        }
    }

    // Admin / Staff Controls
    fun addNewTrainSchedule(
        trainNumber: String,
        model: String,
        from: String,
        to: String,
        depTime: String,
        arrTime: String,
        duration: String,
        stops: String,
        stopTimes: String,
        price2: Double,
        price1: Double,
        priceB: Double
    ) {
        viewModelScope.launch {
            val train = TrainSchedule(
                trainNumber = trainNumber.uppercase(),
                trainModel = model,
                fromStation = from,
                toStation = to,
                departureTime = depTime,
                arrivalTime = arrTime,
                duration = duration,
                isOriginating = true,
                onTimeRate = "100.0%",
                stopStations = stops,
                stopTimes = stopTimes,
                secondClassPrice = price2,
                firstClassPrice = price1,
                businessClassPrice = priceB
            )
            repository.addTrainSchedule(train)
            repository.pushNotification(
                title = "新列车运行发布 ($trainNumber)",
                content = "铁路总调度发布：新增 ${trainNumber}次 列车运营时刻线（$from 至 $to），已加入实时售票系统供全网客流选购。",
                type = "变动通知"
            )
        }
    }

    fun publishSystemAnnouncement(title: String, summary: String, content: String) {
        viewModelScope.launch {
            repository.publishAnnouncement(title, summary, content)
            repository.pushNotification(title = "【系统公告】$title", content = summary, type = "系统公告")
        }
    }

    // Helper: Dates generator
    private fun getTomorrowDateString(): String {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.SIMPLIFIED_CHINESE)
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 1)
        return format.format(cal.time)
    }

    fun getDayOfWeekLabel(dateStr: String): String {
        try {
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.SIMPLIFIED_CHINESE)
            val date = format.parse(dateStr) ?: return ""
            val cal = Calendar.getInstance()
            cal.time = date
            return when (cal.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SUNDAY -> "周日"
                Calendar.MONDAY -> "周一"
                Calendar.TUESDAY -> "周二"
                Calendar.WEDNESDAY -> "周三"
                Calendar.THURSDAY -> "周四"
                Calendar.FRIDAY -> "周五"
                Calendar.SATURDAY -> "周六"
                else -> ""
            }
        } catch (e: Exception) {
            return ""
        }
    }

    fun deleteSearchHistory(id: String) {
        viewModelScope.launch {
            repository.deleteSearchHistory(id)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }
}
