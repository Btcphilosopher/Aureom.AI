package com.example.ui.screens

import com.example.ui.theme.*

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Passenger
import com.example.data.model.TicketOrder
import com.example.data.model.TrainSchedule
import com.example.ui.viewmodel.RailViewModel

// --- 1. Train Query Results Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainResultsScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit,
    onNavigateToSeatSelection: () -> Unit
) {
    val fromCity by viewModel.searchFromCity.collectAsState()
    val toCity by viewModel.searchToCity.collectAsState()
    val searchDate by viewModel.searchDate.collectAsState()
    val trainsList by viewModel.queriedTrains.collectAsState()
    val isLoading by viewModel.isQueryLoading.collectAsState()

    var sortByTime by remember { mutableStateOf(true) } // true: dep time, false: duration

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "$fromCity ⇌ $toCity", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(text = "$searchDate ${viewModel.getDayOfWeekLabel(searchDate)}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
        ) {
            // Sorting Selector Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(vertical = 10.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "为您找到 ${trainsList.size} 趟列车", fontSize = 12.sp, color = Color.Gray)
                Row {
                    OutlinedButton(
                        onClick = { sortByTime = true },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (sortByTime) PrimaryRedLight else Color.Transparent
                        ),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text(text = "出发时间", fontSize = 11.sp, color = if (sortByTime) PrimaryRed else Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = { sortByTime = false },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (!sortByTime) PrimaryRedLight else Color.Transparent
                        ),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text(text = "历时最短", fontSize = 11.sp, color = if (!sortByTime) PrimaryRed else Color.Gray)
                    }
                }
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryRed)
                }
            } else if (trainsList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Train, contentDescription = "Empty", tint = Color.LightGray, modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "未查询到直达列车", fontSize = 15.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(text = "可尝试调整车次筛选条件或使用‘智能换乘规划’", fontSize = 12.sp, color = Color.LightGray, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp))
                    }
                }
            } else {
                val sortedList = if (sortByTime) {
                    trainsList.sortedBy { it.departureTime }
                } else {
                    trainsList.sortedBy { it.duration }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(sortedList) { train ->
                        TrainItemCard(
                            train = train,
                            onClick = {
                                viewModel.selectedTrain.value = train
                                onNavigateToSeatSelection()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrainItemCard(train: TrainSchedule, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("train_card_${train.trainNumber}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Train number and originating symbol
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = train.trainNumber,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Slate900
                    )
                    if (train.isOriginating) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF4CAF50).copy(alpha = 0.15f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(text = "始", fontSize = 10.sp, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(
                    text = train.trainModel,
                    fontSize = 11.sp,
                    color = Color.LightGray
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Time schedule mapping
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.Start, modifier = Modifier.weight(1.5f)) {
                    Text(text = train.departureTime, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333))
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = train.fromStation, fontSize = 13.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }

                // Center arrow and duration
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1.2f)) {
                    Text(text = train.duration, fontSize = 11.sp, color = Color.Gray)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Divider(modifier = Modifier.width(50.dp), color = Color.LightGray, thickness = 1.dp)
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(12.dp))
                    }
                    Text(text = "正点率 ${train.onTimeRate}", fontSize = 10.sp, color = Color(0xFF4CAF50))
                }

                Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1.5f)) {
                    Text(text = train.arrivalTime, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333))
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = train.toStation, fontSize = 13.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = Color(0xFFF0F0F0))
            Spacer(modifier = Modifier.height(10.dp))

            // Seating classes and pricing summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (train.businessClassPrice > 0) {
                    SeatPriceCol(name = "商务座", price = train.businessClassPrice, seats = "有票")
                }
                if (train.firstClassPrice > 0) {
                    SeatPriceCol(name = "一等座", price = train.firstClassPrice, seats = "有票")
                }
                if (train.secondClassPrice > 0) {
                    SeatPriceCol(name = "二等座", price = train.secondClassPrice, seats = "有票")
                }
                if (train.softSleeperPrice > 0) {
                    SeatPriceCol(name = "动卧", price = train.softSleeperPrice, seats = "有票")
                }
            }
        }
    }
}

@Composable
fun SeatPriceCol(name: String, price: Double, seats: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = name, fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = "¥${price.toInt()}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PrimaryRed)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = seats, fontSize = 11.sp, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
    }
}

// --- 2. Seat Selection Grid Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeatSelectionScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit,
    onNavigateToPassengers: () -> Unit
) {
    val train by viewModel.selectedTrain.collectAsState()
    var selectedSeatLetter by remember { mutableStateOf("A") } // Custom seating selection option
    val seatTypes = listOf("商务座", "一等座", "二等座")
    var activeType by remember { mutableStateOf("二等座") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "选择席别", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        train?.let { t ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(Color(0xFFF6F8FA))
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    // Recap Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = t.trainNumber, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Slate900)
                                Text(text = "${t.fromStation} ⇌ ${t.toStation}", fontSize = 12.sp, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "历时: ${t.duration}", fontSize = 12.sp, color = Color.Gray)
                                Text(text = t.trainModel, fontSize = 11.sp, color = Color.LightGray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(text = "选择您的车座等级", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Horizontal Seating type picker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        seatTypes.forEach { type ->
                            val isSelected = activeType == type
                            val price = when(type) {
                                "商务座" -> t.businessClassPrice
                                "一等座" -> t.firstClassPrice
                                else -> t.secondClassPrice
                            }
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        activeType = type
                                        viewModel.selectedSeatClass.value = type
                                    }
                                    .border(
                                        width = if (isSelected) 1.5.dp else 0.dp,
                                        color = if (isSelected) PrimaryRed else Color.Transparent,
                                        shape = RoundedCornerShape(10.dp)
                                    ),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = if (isSelected) SurfaceWhite else Color(0xFFEFEFEF))
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(text = type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isSelected) PrimaryRed else Color.Gray)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "¥${price.toInt()}", fontSize = 13.sp, color = PrimaryRed, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(text = "极速选座偏好 (二等座布局)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Simulated interactive carriage seats map
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "05号车厢 (二等座静音车厢)", fontSize = 11.sp, color = Color.LightGray)
                            Spacer(modifier = Modifier.height(16.dp))

                            // Seating layout row representation
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SeatIndicator(label = "A", isSelected = selectedSeatLetter == "A", desc = "靠窗") { selectedSeatLetter = "A" }
                                SeatIndicator(label = "B", isSelected = selectedSeatLetter == "B", desc = "过道") { selectedSeatLetter = "B" }
                                SeatIndicator(label = "C", isSelected = selectedSeatLetter == "C", desc = "靠窗") { selectedSeatLetter = "C" }
                                Spacer(modifier = Modifier.width(20.dp)) // aisle
                                SeatIndicator(label = "D", isSelected = selectedSeatLetter == "D", desc = "靠窗") { selectedSeatLetter = "D" }
                                SeatIndicator(label = "F", isSelected = selectedSeatLetter == "F", desc = "靠窗") { selectedSeatLetter = "F" }
                            }

                            Spacer(modifier = Modifier.height(20.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "我们将优先为您安排该座号，若余票不足则自动分配。", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        viewModel.selectedSeatClass.value = activeType
                        onNavigateToPassengers()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("seat_confirm_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed),
                    shape = RoundedCornerShape(25.dp)
                ) {
                    Text(text = "下一步：添加乘车人", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SeatIndicator(label: String, isSelected: Boolean, desc: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) PrimaryRed else Color(0xFFEBEBEB))
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 15.sp,
                color = if (isSelected) Color.White else Color.DarkGray,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = desc, fontSize = 9.sp, color = Color.Gray)
    }
}

// --- 3. Passenger Profiles Selector ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PassengerSelectorScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit,
    onNavigateToConfirm: () -> Unit
) {
    val passengersList by viewModel.allPassengers.collectAsState()
    val selectedList by viewModel.selectedPassengers.collectAsState()

    var showAddForm by remember { mutableStateOf(false) }
    var inputName by remember { mutableStateOf("") }
    var inputPhone by remember { mutableStateOf("") }
    var inputIdCard by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "乘车人选择", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { showAddForm = true }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add New", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (showAddForm) {
                // Form input to append a Passenger profile
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "添加常用乘车人 (实名认证)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Slate900)
                            IconButton(onClick = { showAddForm = false }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color.Gray)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = inputName,
                            onValueChange = { inputName = it },
                            label = { Text("姓名") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = inputIdCard,
                            onValueChange = { inputIdCard = it },
                            label = { Text("二代身份证号") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = inputPhone,
                            onValueChange = { inputPhone = it },
                            label = { Text("手机号") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                if (inputName.isNotEmpty() && inputIdCard.length == 18 && inputPhone.isNotEmpty()) {
                                    viewModel.addPassengerProfile(inputName, "二代身份证", inputIdCard, inputPhone)
                                    inputName = ""
                                    inputIdCard = ""
                                    inputPhone = ""
                                    showAddForm = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed)
                        ) {
                            Text(text = "提交实名认证并添加")
                        }
                    }
                }
            } else {
                Column {
                    Text(text = "选择本次乘车旅客", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(passengersList) { passenger ->
                            val isChecked = selectedList.any { it.id == passenger.id }
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.togglePassengerSelection(passenger) },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isChecked) 1.5.dp else 0.dp,
                                    color = if (isChecked) PrimaryRed else Color.Transparent
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(20.dp)
                                                .clip(CircleShape)
                                                .background(if (isChecked) PrimaryRed else Color.LightGray),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isChecked) {
                                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(text = passenger.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(Color(0xFFE8F5E9))
                                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                                ) {
                                                    Text(text = passenger.type, fontSize = 9.sp, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(text = "身份证：${passenger.idNumber.take(4)}**********${passenger.idNumber.takeLast(4)}", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    }
                                    IconButton(onClick = { viewModel.deletePassengerProfile(passenger) }) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color.LightGray)
                                    }
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        if (selectedList.isNotEmpty()) {
                            viewModel.createPendingOrder()
                            onNavigateToConfirm()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("passenger_confirm_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedList.isNotEmpty()) PrimaryRed else Color.LightGray
                    ),
                    shape = RoundedCornerShape(25.dp),
                    enabled = selectedList.isNotEmpty()
                ) {
                    Text(text = "核对车票订单", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// --- 4. Order Confirmation & Cashier Pay ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderConfirmPayScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit,
    onNavigateToTicket: () -> Unit
) {
    val pendingOrder by viewModel.pendingOrder.collectAsState()
    val isPaying by viewModel.isPaying.collectAsState()
    val paySuccess by viewModel.paySuccess.collectAsState()

    var paymentMethod by remember { mutableStateOf("Alipay") } // Alipay or WeChat

    LaunchedEffect(paySuccess) {
        if (paySuccess) {
            onNavigateToTicket()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "支付订单", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        pendingOrder?.let { order ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(Color(0xFFF6F8FA))
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    // Summary billing details
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = order.trainNumber, fontSize = 20.sp, fontWeight = FontWeight.Black, color = Slate900)
                                Text(text = order.departureDate, fontSize = 12.sp, color = Color.Gray)
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = order.departureTime, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(text = order.fromStation, fontSize = 12.sp, color = Color.Gray)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = order.duration, fontSize = 10.sp, color = Color.LightGray)
                                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(12.dp))
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = order.arrivalTime, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(text = order.toStation, fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = Color(0xFFF0F0F0))
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "乘车人: ${order.passengerName}", fontSize = 13.sp, color = Color.DarkGray)
                                Text(text = "${order.seatClass}  ${order.carriage}${order.seatNumber}座", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryRed)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(text = "选择支付渠道", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Simulated Alipay vs WeChat Pay
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { paymentMethod = "Alipay" }
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF02A9F4)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = "支", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(text = "支付宝支付 (Alipay)", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                }
                                RadioButton(
                                    selected = paymentMethod == "Alipay",
                                    onClick = { paymentMethod = "Alipay" },
                                    colors = RadioButtonDefaults.colors(selectedColor = PrimaryRed)
                                )
                            }
                            Divider(color = Color(0xFFF0F0F0), modifier = Modifier.padding(horizontal = 14.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { paymentMethod = "WeChat" }
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF09BB07)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = "微", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(text = "微信支付 (WeChat Pay)", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                }
                                RadioButton(
                                    selected = paymentMethod == "WeChat",
                                    onClick = { paymentMethod = "WeChat" },
                                    colors = RadioButtonDefaults.colors(selectedColor = PrimaryRed)
                                )
                            }
                        }
                    }
                }

                // Final Pay button with total
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "票价总额", fontSize = 14.sp, color = Color.Gray)
                        Text(text = "¥${order.price}", fontSize = 24.sp, fontWeight = FontWeight.Black, color = PrimaryRed)
                    }

                    Button(
                        onClick = { viewModel.executePayment(paymentMethod) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("pay_submit_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed),
                        shape = RoundedCornerShape(25.dp),
                        enabled = !isPaying
                    ) {
                        if (isPaying) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        } else {
                            Text(text = "确认并在线支付 ¥${order.price}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// --- 5. E-Ticket View Details Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ETicketViewScreen(
    order: TicketOrder,
    onBack: () -> Unit
) {
    var isNfcSimulating by remember { mutableStateOf(false) }
    var nfcComplete by remember { mutableStateOf(false) }

    LaunchedEffect(isNfcSimulating) {
        if (isNfcSimulating) {
            kotlinx.coroutines.delay(1200)
            isNfcSimulating = false
            nfcComplete = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "我的电子客票", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DeepBlueDark) // Royal blue background for tickets
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Cutout Paper Ticket Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(bottom = 20.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Title Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "中国高速铁路 (CHINA RAIL)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryRed
                        )
                        Icon(imageVector = Icons.Default.ConfirmationNumber, contentDescription = null, tint = PrimaryRed, modifier = Modifier.size(16.dp))
                    }

                    // Journey Details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.Start) {
                            Text(text = order.fromStation, fontSize = 24.sp, fontWeight = FontWeight.Black, color = Slate900)
                            Text(text = "DEPARTURE", fontSize = 9.sp, color = Color.LightGray)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = order.trainNumber, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = PrimaryRed)
                            Icon(imageVector = Icons.Default.Train, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(18.dp))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = order.toStation, fontSize = 24.sp, fontWeight = FontWeight.Black, color = Slate900)
                            Text(text = "DESTINATION", fontSize = 9.sp, color = Color.LightGray)
                        }
                    }

                    Divider(color = Color(0xFFF0F0F0), thickness = 1.dp)

                    // Boarding gate and seat details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TicketMetaCol(label = "出发日期", value = order.departureDate)
                        TicketMetaCol(label = "开车时间", value = order.departureTime)
                        TicketMetaCol(label = "检票口", value = order.boardingGate)
                        TicketMetaCol(label = "站台", value = "台${order.platform}")
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TicketMetaCol(label = "席别", value = order.seatClass)
                        TicketMetaCol(label = "车厢", value = order.carriage)
                        TicketMetaCol(label = "席位号", value = order.seatNumber)
                        TicketMetaCol(label = "客票状态", value = order.status)
                    }

                    Divider(color = Color(0xFFF0F0F0), thickness = 1.dp)

                    // QR Code Drawing (Canvas based to make it robust!)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                // Draw stylized QR Code boxes
                                val qrWidth = size.width
                                val qrHeight = size.height
                                val grid = 12
                                val cellW = qrWidth / grid
                                val cellH = qrHeight / grid
                                
                                for (r in 0 until grid) {
                                    for (c in 0 until grid) {
                                        // Draw alignment targets in corners
                                        val isTarget = (r < 3 && c < 3) || (r < 3 && c >= grid - 3) || (r >= grid - 3 && c < 3)
                                        val isRandomDot = (r + c) % 3 == 0 || (r * c) % 5 == 2
                                        
                                        if (isTarget) {
                                            drawRect(
                                                color = DeepBlueDark,
                                                topLeft = Offset(c * cellW, r * cellH),
                                                size = Size(cellW, cellH)
                                            )
                                        } else if (isRandomDot && r > 2 && r < grid - 2) {
                                            drawRect(
                                                color = Color(0xFF333333),
                                                topLeft = Offset(c * cellW, r * cellH),
                                                size = Size(cellW, cellH)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = order.passengerName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF333333)
                        )
                        Text(
                            text = "身份证: ${order.passengerIdNumber.take(4)}**********${order.passengerIdNumber.takeLast(4)}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            // NFC / Gate simulator
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                if (isNfcSimulating) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "正在感应闸机 NFC ...", fontSize = 12.sp, color = Color.White)
                } else if (nfcComplete) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF4CAF50))
                            .padding(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "碰一碰检票成功！闸机已开启", fontSize = 12.sp, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
                } else {
                    Button(
                        onClick = { isNfcSimulating = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.height(44.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Nfc, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "模拟刷手机过闸机 (NFC 碰一碰)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TicketMetaCol(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(4.dp)) {
        Text(text = label, fontSize = 9.sp, color = Color.LightGray)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333))
    }
}

// --- 6. My Tickets List Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyTicketsScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit,
    onNavigateToTicket: (TicketOrder) -> Unit
) {
    val orders by viewModel.allOrders.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: upcoming, 1: history

    val activeTrips = orders.filter { it.status == "已出票" || it.status == "已改签" }
    val historicalTrips = orders.filter { it.status == "已退票" || it.status == "已完成" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "我的车票行程", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
        ) {
            // Horizontal Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { selectedTab = 0 }
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "未来行程 (${activeTrips.size})",
                        fontSize = 14.sp,
                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedTab == 0) PrimaryRed else Color.Gray
                    )
                }
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { selectedTab = 1 }
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "历史订单 (${historicalTrips.size})",
                        fontSize = 14.sp,
                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedTab == 1) PrimaryRed else Color.Gray
                    )
                }
            }

            val listToDisplay = if (selectedTab == 0) activeTrips else historicalTrips

            if (listToDisplay.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.QrCode, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "暂无相关行程记录", fontSize = 14.sp, color = Color.Gray)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(listToDisplay) { order ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (order.status == "已出票" || order.status == "已改签") {
                                        onNavigateToTicket(order)
                                    }
                                },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = order.trainNumber, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Slate900)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = order.departureDate, fontSize = 12.sp, color = Color.Gray)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                when (order.status) {
                                                    "已出票", "已改签" -> Color(0xFFE8F5E9)
                                                    "已退票" -> PrimaryRedLight
                                                    else -> Color(0xFFF0F0F0)
                                                }
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = order.status,
                                            fontSize = 10.sp,
                                            color = when (order.status) {
                                                "已出票", "已改签" -> Color(0xFF4CAF50)
                                                "已退票" -> PrimaryRed
                                                else -> Color.DarkGray
                                            },
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = "${order.fromStation} ⇌ ${order.toStation}", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "乘车人：${order.passengerName}", fontSize = 12.sp, color = Color.Gray)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(text = "${order.carriage}${order.seatNumber}座", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Slate900)
                                        Text(text = "¥${order.price.toInt()}", fontSize = 14.sp, color = PrimaryRed, fontWeight = FontWeight.Black)
                                    }
                                }

                                if (order.status == "已出票" || order.status == "已改签") {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Divider(color = Color(0xFFF0F0F0))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        OutlinedButton(
                                            onClick = { viewModel.refundTicket(order) },
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text(text = "退票", fontSize = 11.sp, color = PrimaryRed)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        OutlinedButton(
                                            onClick = {
                                                // Simulates rescheduling tomorrow
                                                val tomorrow = "2026-07-09"
                                                viewModel.changeTicket(order, tomorrow)
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text(text = "改签明天的票", fontSize = 11.sp, color = PrimaryRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
