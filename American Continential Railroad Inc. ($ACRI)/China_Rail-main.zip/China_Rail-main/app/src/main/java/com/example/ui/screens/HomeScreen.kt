package com.example.ui.screens

import com.example.ui.theme.*

import java.text.SimpleDateFormat
import java.util.Locale
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Announcement
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.viewmodel.RailViewModel

// --- 1. Splash Screen Component ---
@Composable
fun SplashScreen(onDismiss: () -> Unit) {
    var startAnim by remember { mutableStateOf(false) }
    LaunchedEffect(key1 = true) {
        startAnim = true
        kotlinx.coroutines.delay(1800)
        onDismiss()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F2C59), Color(0xFF1D5C96))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = startAnim,
            enter = fadeIn(animationSpec = tween(1000)),
            exit = fadeOut(animationSpec = tween(500))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Large styled train silhouette / logo
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White.copy(alpha = 0.95f))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_rail_logo_1783413198493),
                        contentDescription = "Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "中国铁路通",
                    fontSize = 32.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "CHINA HIGH-SPEED RAIL",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.7f),
                    fontWeight = FontWeight.Light,
                    letterSpacing = 4.sp
                )
                Spacer(modifier = Modifier.height(48.dp))
                CircularProgressIndicator(
                    color = PrimaryRed, // China Crimson Red
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}

// --- 2. Home Dashboard Screen ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeDashboardScreen(
    viewModel: RailViewModel,
    onNavigateToResults: () -> Unit,
    onQuickActionClick: (String) -> Unit
) {
    val context = LocalContext.current
    val fromCity by viewModel.searchFromCity.collectAsState()
    val toCity by viewModel.searchToCity.collectAsState()
    val searchDate by viewModel.searchDate.collectAsState()
    val isRoundTrip by viewModel.searchIsRoundTrip.collectAsState()
    val highSpeedOnly by viewModel.searchHighSpeedOnly.collectAsState()
    val recentHistory by viewModel.searchHistory.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val activeOrders by viewModel.allOrders.collectAsState()

    // Find if there is an active trip departing today/tomorrow
    val todayDateString = SimpleDateFormat("yyyy-MM-dd", Locale.SIMPLIFIED_CHINESE).format(java.util.Date())
    val activeTrip = activeOrders.find { it.status == "已出票" && (it.departureDate == todayDateString || it.departureDate >= todayDateString) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F8FA)) // Clean light gray/white background
            .verticalScroll(rememberScrollState())
    ) {
        // Upper Header Block: Clean White Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Logo Box with CR
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(PrimaryRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CR",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "中国铁路通",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                        Text(
                            text = "您好，${userProfile.realName}",
                            fontSize = 11.sp,
                            color = Slate600
                        )
                    }
                }

                // Right side: Staff admin mode portal toggle and Notification icon
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onQuickActionClick("Notifications") },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BackgroundGray)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = Slate600,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    val staffMode by viewModel.isStaffMode.collectAsState()
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (staffMode) PrimaryRed else PrimaryRedLight)
                            .clickable { viewModel.isStaffMode.value = !staffMode }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Train,
                            contentDescription = "Staff Mode",
                            tint = if (staffMode) Color.White else PrimaryRed,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (staffMode) "员工后台" else "工作入口",
                            fontSize = 11.sp,
                            color = if (staffMode) Color.White else PrimaryRed,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Hero Slider Carousel Area (Moved here to maintain visual balance with white header)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .height(130.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.DarkGray)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.img_rail_hero_1783413183800),
                    contentDescription = "Fuxing Hao High Speed Train",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Decorative overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                            )
                        )
                )
                Text(
                    text = "向新而行，复兴号智能动车组全面升级出新",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                )
            }
        }

        // 3. Central Query Train Ticket Box
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .background(Color.Transparent),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Trip Category Selectors (Single vs Round)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isRoundTrip) PrimaryRedLight else Color.Transparent)
                            .clickable { viewModel.searchIsRoundTrip.value = false }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "单程",
                            color = if (!isRoundTrip) PrimaryRed else Slate600,
                            fontWeight = if (!isRoundTrip) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isRoundTrip) PrimaryRedLight else Color.Transparent)
                            .clickable { viewModel.searchIsRoundTrip.value = true }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "往返",
                            color = if (isRoundTrip) PrimaryRed else Slate600,
                            fontWeight = if (isRoundTrip) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                }

                // Origin / Destination Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { /* Could support popup city picker */ }
                    ) {
                        Text(text = "出发地", fontSize = 11.sp, color = Slate400, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = fromCity,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate900
                        )
                    }

                    // Swap Circle Button
                    IconButton(
                        onClick = { viewModel.swapSearchCities() },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(BackgroundGray)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "Swap Cities",
                            tint = PrimaryRed
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { /* Pop-up target city picker */ },
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(text = "到达地", fontSize = 11.sp, color = Slate400, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = toCity,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate900
                        )
                    }
                }

                // Travel Date Selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { /* Opens dates helper */ }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "Calendar",
                        tint = PrimaryRed,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(text = "出发日期", fontSize = 11.sp, color = Slate400, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = searchDate,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Slate900
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(PrimaryRedLight)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = viewModel.getDayOfWeekLabel(searchDate),
                                    fontSize = 11.sp,
                                    color = PrimaryRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Filter / High-speed only check
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = highSpeedOnly,
                            onCheckedChange = { viewModel.searchHighSpeedOnly.value = it },
                            colors = CheckboxDefaults.colors(checkedColor = PrimaryRed, uncheckedColor = Slate400)
                        )
                        Text(text = "仅看高铁/动车", fontSize = 13.sp, color = Slate900, fontWeight = FontWeight.Medium)
                    }

                    // Large Red Action Ticket Button (Modern style)
                    Button(
                        onClick = {
                            viewModel.searchTrains()
                            onNavigateToResults()
                        },
                        modifier = Modifier
                            .height(48.dp)
                            .width(130.dp)
                            .testTag("search_trains_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Query", tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "查询车票", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Today's Trip Widget (Dynamic Alert) - Styled to match "Today's Journey Card"
        if (activeTrip != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable { onQuickActionClick("MyTickets") },
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(DeepBlueDark, DeepBlueLight)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        // Top row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "今日行程 TODAY",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    letterSpacing = 1.sp
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "车次", fontSize = 10.sp, color = Color.White.copy(alpha = 0.8f))
                                Text(text = activeTrip.trainNumber, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Middle row: Stations and progress line
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(text = activeTrip.departureTime, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(text = activeTrip.fromStation, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                            }
                            
                            // Line in middle
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.6f)
                                        .height(1.dp)
                                        .background(Color.White.copy(alpha = 0.4f))
                                )
                                Text(text = activeTrip.duration, fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(top = 4.dp))
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = activeTrip.arrivalTime, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(text = activeTrip.toStation, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Bottom row: Gate and seat details
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.1f))
                                .padding(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "检票口", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                Text(text = activeTrip.boardingGate.ifEmpty { "12A" }, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "座位", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                Text(text = "${activeTrip.carriage}车 ${activeTrip.seatNumber}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Quick Utilities Action Circle Matrix
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Text(
                text = "智慧客运服务",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Slate900,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                QuickActionItem(
                    title = "车站信息",
                    icon = Icons.Default.Map,
                    tag = "StationGuide",
                    onClick = onQuickActionClick
                )
                QuickActionItem(
                    title = "换乘规划",
                    icon = Icons.Default.AltRoute,
                    tag = "TransferPlanner",
                    onClick = onQuickActionClick
                )
                QuickActionItem(
                    title = "列车详情",
                    icon = Icons.Default.TrackChanges,
                    tag = "TrainTracker",
                    onClick = onQuickActionClick
                )
                QuickActionItem(
                    title = "客服中心",
                    icon = Icons.Default.HeadsetMic,
                    tag = "ServiceCenter",
                    onClick = onQuickActionClick
                )
            }
        }

        // 4. Recent Searches
        if (recentHistory.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "历史查询记录",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate600
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(recentHistory) { history ->
                        Card(
                            modifier = Modifier.clickable {
                                viewModel.searchFromCity.value = history.fromCity
                                viewModel.searchToCity.value = history.toCity
                                viewModel.searchTrains()
                                onNavigateToResults()
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Slate100)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${history.fromCity} ⇌ ${history.toCity}",
                                    fontSize = 12.sp,
                                    color = Slate600,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "✕",
                                    fontSize = 10.sp,
                                    color = Slate400,
                                    modifier = Modifier.clickable {
                                        viewModel.deleteSearchHistory(history.id)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Promotional Events & Announcement Cards
        val promosList by viewModel.promos.collectAsState()
        if (promosList.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "特惠与铁路讯息",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate900,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                promosList.forEach { promo ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = promo.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Slate900
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(PrimaryRed)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = promo.promoCode,
                                        fontSize = 9.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = promo.description,
                                fontSize = 12.sp,
                                color = Slate600
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "截止有效期至：${promo.expireDate}",
                                fontSize = 10.sp,
                                color = Slate400
                            )
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun QuickActionItem(
    title: String,
    icon: ImageVector,
    tag: String,
    onClick: (String) -> Unit
) {
    val (bgColor, iconColor) = when (tag) {
        "StationGuide" -> Pair(Color(0xFFEFF6FF), Color(0xFF2563EB)) // Blue
        "TransferPlanner" -> Pair(Color(0xFFFFF7ED), Color(0xFFEA580C)) // Orange
        "TrainTracker" -> Pair(Color(0xFFF0FDF4), Color(0xFF16A34A)) // Green
        "ServiceCenter" -> Pair(Color(0xFFFAF5FF), Color(0xFF9333EA)) // Purple
        else -> Pair(PrimaryRedLight, PrimaryRed)
    }

    Card(
        modifier = Modifier
            .width(82.dp)
            .clickable { onClick(tag) },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate100),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Slate600,
                textAlign = TextAlign.Center
            )
        }
    }
}
