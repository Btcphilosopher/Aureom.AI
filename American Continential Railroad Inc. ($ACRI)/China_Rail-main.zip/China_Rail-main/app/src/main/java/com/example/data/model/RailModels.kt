package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- 1. User / Passenger Profile ---
@Entity(tableName = "passengers")
data class Passenger(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String, // 成人 (Adult), 儿童 (Child), 学生 (Student), 残疾军人 (Disabled Veteran)
    val idType: String, // 二代身份证 (ID Card), 护照 (Passport), 港澳居民来往内地通行证 (HK/Macau Permit)
    val idNumber: String,
    val phoneNumber: String,
    val isVerified: Boolean = true,
    val isCommon: Boolean = true // Frequent contact
)

data class UserProfile(
    val id: String = "U10086",
    val username: String = "高铁旅客_2026",
    val realName: String = "张铁通",
    val idCardHidden: String = "1101**********1234",
    val isRealNameVerified: Boolean = true,
    val memberPoints: Int = 12500, // Member integration loyalty points
    val level: String = "黄金会员 (Gold)"
)

// --- 2. Cities & Stations ---
@Entity(tableName = "stations")
data class Station(
    @PrimaryKey val code: String, // e.g., "BJP"
    val name: String, // e.g., "北京南"
    val city: String, // e.g., "北京"
    val isHighSpeed: Boolean = true,
    val desc: String = "",
    val mapInfo: String = "",
    val boardingGate: String = "12B, 13B",
    val platform: String = "6, 7",
    val shops: List<String> = emptyList(),
    val dining: List<String> = emptyList(),
    val transfers: List<String> = emptyList(), // e.g., ["地铁4号线", "地铁14号线", "公交300路", "地下停车场"]
    val accessibility: List<String> = emptyList() // e.g., ["无障碍电梯", "轮椅服务", "盲道"]
) {
    // Convenience constructor for Room compatibility, or we handle list conversions in TypeConverters
}

// Custom converter helper since Room does not support List<String> directly
object ListConverter {
    fun fromList(list: List<String>): String = list.joinToString(";")
    fun toList(str: String): List<String> = if (str.isEmpty()) emptyList() else str.split(";")
}

// --- 3. Railway Lines & Train Models ---
data class RailwayLine(
    val id: String, // e.g., "京沪高铁"
    val name: String,
    val fromCity: String,
    val toCity: String,
    val speedKmh: Int = 350
)

data class TrainModel(
    val id: String, // e.g., "CR400AF"
    val name: String, // e.g., "复兴号 CR400AF"
    val capacity: Int = 576,
    val features: List<String> = listOf("智能5G车厢", "静音车厢", "全车充电口 (Type-C)", "无障碍卫生间", "餐车咖啡阁")
)

// --- 4. Train Schedules (车次) ---
@Entity(tableName = "train_schedules")
data class TrainSchedule(
    @PrimaryKey val trainNumber: String, // e.g., "G1"
    val trainModel: String, // e.g., "复兴号"
    val fromStation: String, // e.g., "北京南"
    val toStation: String, // e.g., "上海虹桥"
    val departureTime: String, // e.g., "07:00"
    val arrivalTime: String, // e.g., "11:18"
    val duration: String, // e.g., "4h18m"
    val isOriginating: Boolean = true, // 是否始发
    val onTimeRate: String = "99.8%", // 正点率
    val stopStations: String, // Semicolon-delimited sequence, e.g., "北京南;济南西;南京南;上海虹桥"
    val stopTimes: String, // Semicolon-delimited, e.g., "07:00;08:30;10:10;11:18"
    val secondClassPrice: Double = 553.0,
    val firstClassPrice: Double = 933.0,
    val businessClassPrice: Double = 1748.0,
    val softSleeperPrice: Double = 0.0,
    val hardSleeperPrice: Double = 0.0,
    val hardSeatPrice: Double = 0.0
)

// --- 5. Booking Order & E-Tickets ---
@Entity(tableName = "orders")
data class TicketOrder(
    @PrimaryKey val orderId: String, // e.g., "CRN12345678"
    val trainNumber: String,
    val fromStation: String,
    val toStation: String,
    val departureDate: String, // e.g., "2026-07-08"
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val passengerName: String,
    val passengerIdNumber: String,
    val seatClass: String, // 商务座, 一等座, 二等座, etc.
    val carriage: String, // 车厢号 e.g., "05车"
    val seatNumber: String, // 座位号 e.g., "12D"
    val price: Double,
    val boardingGate: String = "15A",
    val platform: String = "9",
    val orderTime: Long = System.currentTimeMillis(),
    val status: String, // 待支付 (Pending), 已出票 (Paid), 已退票 (Refunded), 已改签 (Changed), 已完成 (Completed)
    val qrCodePayload: String = "" // Code representing digital security signature
)

// --- 6. Notifications & News ---
@Entity(tableName = "notifications")
data class RailNotification(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String, // 行程提醒 (Trip), 变动通知 (Update), 优惠活动 (Promo), 系统公告 (System)
    val isRead: Boolean = false
)

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val summary: String,
    val content: String,
    val publishDate: String,
    val author: String = "中国铁路调度中心"
)

@Entity(tableName = "promos")
data class PromoActivity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String,
    val promoCode: String,
    val discountRate: Double,
    val bannerUrl: String = "",
    val expireDate: String
)

// --- 7. Search History ---
@Entity(tableName = "search_history")
data class SearchHistory(
    @PrimaryKey val id: String, // fromStation + "_" + toStation
    val fromCity: String,
    val toCity: String,
    val timestamp: Long = System.currentTimeMillis()
)

// --- 8. Seating layout simulation ---
data class SeatAvailability(
    val carriageNum: String,
    val seatClass: String,
    val totalSeats: Int,
    val availableSeats: Int,
    val layoutMap: List<List<Boolean>> // Row x Col: true = free, false = booked
)

// --- 9. Transit Planner Routing ---
data class RouteSegment(
    val segmentNum: Int,
    val trainNumber: String,
    val fromStation: String,
    val toStation: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val seatClass: String,
    val price: Double
)

data class TransferPlan(
    val id: String,
    val planType: String, // 最快路线 (Fastest), 最少换乘 (Fewest), 最低票价 (Cheapest), 舒适首选 (Comfort)
    val startStation: String,
    val transferStation: String,
    val endStation: String,
    val segments: List<RouteSegment>,
    val totalDuration: String,
    val transferBuffer: String, // e.g. "45m"
    val totalCost: Double
)
