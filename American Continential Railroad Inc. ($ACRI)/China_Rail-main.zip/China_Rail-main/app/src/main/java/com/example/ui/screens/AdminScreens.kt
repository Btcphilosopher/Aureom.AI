package com.example.ui.screens

import com.example.ui.theme.*

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.LineWeight
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.RailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminStaffPortalScreen(
    viewModel: RailViewModel,
    onBack: () -> Unit
) {
    val activeTab by viewModel.activeStaffTab.collectAsState()

    // Form states for adding train
    var trainNum by remember { mutableStateOf("") }
    var trainModel by remember { mutableStateOf("复兴号 CR400AF-B") }
    var depStat by remember { mutableStateOf("") }
    var arrStat by remember { mutableStateOf("") }
    var depTime by remember { mutableStateOf("") }
    var arrTime by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("") }
    var stops by remember { mutableStateOf("") }
    var stopTimes by remember { mutableStateOf("") }
    var price2 by remember { mutableStateOf("") }
    var price1 by remember { mutableStateOf("") }
    var priceB by remember { mutableStateOf("") }
    var addTrainSuccess by remember { mutableStateOf(false) }

    // Form states for announcement
    var annTitle by remember { mutableStateOf("") }
    var annSummary by remember { mutableStateOf("") }
    var annContent by remember { mutableStateOf("") }
    var annSuccess by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "中国铁路调度与运营后台", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryRed) // Staff is crimson-red theme
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF6F8FA))
        ) {
            // Horizontal Admin Sub-tabs
            Row(modifier = Modifier.fillMaxWidth().background(Color.White)) {
                listOf("客流监控", "开行调度", "公告发布").forEachIndexed { index, title ->
                    val isSelected = activeTab == index
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.activeStaffTab.value = index }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) PrimaryRed else Color.Gray
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                when (activeTab) {
                    0 -> {
                        // Operational statistics dashboards using custom Jetpack Canvas drawings
                        Text(text = "客流量与售票实时监测", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Hourly Seat Sales Chart (Canvas drawn!)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .padding(bottom = 16.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "今日售票走势 (按小时)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "单位：张", fontSize = 10.sp, color = Color.LightGray)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val sales = viewModel.hourlyTicketSales
                                    val maxVal = sales.maxOrNull() ?: 2000
                                    val width = size.width
                                    val height = size.height - 20f
                                    val pointsCount = sales.size
                                    val spacing = width / (pointsCount - 1)

                                    // Draw background horizontal lines
                                    val lines = 4
                                    for (i in 0..lines) {
                                        val y = (height / lines) * i
                                        drawLine(
                                            color = Color.LightGray.copy(alpha = 0.5f),
                                            start = Offset(0f, y),
                                            end = Offset(width, y),
                                            strokeWidth = 1f
                                        )
                                    }

                                    // Plot the ticket sales lines
                                    for (idx in 0 until pointsCount - 1) {
                                        val x1 = idx * spacing
                                        val y1 = height - (sales[idx].toFloat() / maxVal * height)
                                        val x2 = (idx + 1) * spacing
                                        val y2 = height - (sales[idx + 1].toFloat() / maxVal * height)

                                        drawLine(
                                            color = PrimaryRed,
                                            start = Offset(x1, y1),
                                            end = Offset(x2, y2),
                                            strokeWidth = 3f
                                        )
                                        drawCircle(
                                            color = DeepBlueDark,
                                            radius = 4f,
                                            center = Offset(x1, y1)
                                        )
                                    }
                                }
                            }
                        }

                        // Station volumes bar chart
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .padding(bottom = 16.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "核心高铁站吞吐量排行 (今日)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "单位：人次", fontSize = 10.sp, color = Color.LightGray)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val flows = viewModel.stationPassengerFlow
                                    val maxVal = 70000f
                                    val height = size.height
                                    val barWidth = 35f
                                    val spacing = size.width / flows.size

                                    flows.forEachIndexed { idx, pair ->
                                        val barHeight = (pair.second.toFloat() / maxVal) * (height - 30f)
                                        val x = idx * spacing + (spacing - barWidth) / 2
                                        val y = height - barHeight - 15f

                                        // Draw the rounded bar
                                        drawRect(
                                            color = DeepBlueDark,
                                            topLeft = Offset(x, y),
                                            size = Size(barWidth, barHeight)
                                        )
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        //開行調度: Form inputs to insert a new train schedule directly to Room DB
                        if (addTrainSuccess) {
                            AdminSuccessCard(title = "开行命令发布成功！", desc = "该新增高铁车次已成功下发各客运站售票系统。") {
                                addTrainSuccess = false
                            }
                        } else {
                            Text(text = "增开或调整临时高铁列车", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = trainNum,
                                onValueChange = { trainNum = it },
                                label = { Text("车次 (如：G18)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = depStat,
                                onValueChange = { depStat = it },
                                label = { Text("出发车站 (如：北京南)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = arrStat,
                                onValueChange = { arrStat = it },
                                label = { Text("到达车站 (如：上海虹桥)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = depTime,
                                onValueChange = { depTime = it },
                                label = { Text("出发时刻 (如：09:45)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = arrTime,
                                onValueChange = { arrTime = it },
                                label = { Text("到达时刻 (如：14:12)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = duration,
                                onValueChange = { duration = it },
                                label = { Text("全程历时 (如：4h27m)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = stops,
                                onValueChange = { stops = it },
                                label = { Text("停靠序列（分号隔开，如：北京南;南京南;上海虹桥）") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = stopTimes,
                                onValueChange = { stopTimes = it },
                                label = { Text("到发时刻（分号隔开，如：09:45;12:15;14:12）") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = price2,
                                    onValueChange = { price2 = it },
                                    label = { Text("二等价") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                OutlinedTextField(
                                    value = price1,
                                    onValueChange = { price1 = it },
                                    label = { Text("一等价") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                OutlinedTextField(
                                    value = priceB,
                                    onValueChange = { priceB = it },
                                    label = { Text("商务价") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    if (trainNum.isNotEmpty() && depStat.isNotEmpty() && arrStat.isNotEmpty() && depTime.isNotEmpty() && arrTime.isNotEmpty()) {
                                        viewModel.addNewTrainSchedule(
                                            trainNumber = trainNum,
                                            model = trainModel,
                                            from = depStat,
                                            to = arrStat,
                                            depTime = depTime,
                                            arrTime = arrTime,
                                            duration = duration.ifEmpty { "4h00m" },
                                            stops = stops,
                                            stopTimes = stopTimes,
                                            price2 = price2.toDoubleOrNull() ?: 553.0,
                                            price1 = price1.toDoubleOrNull() ?: 933.0,
                                            priceB = priceB.toDoubleOrNull() ?: 1748.0
                                        )
                                        trainNum = ""
                                        depStat = ""
                                        arrStat = ""
                                        depTime = ""
                                        arrTime = ""
                                        duration = ""
                                        stops = ""
                                        stopTimes = ""
                                        price2 = ""
                                        price1 = ""
                                        priceB = ""
                                        addTrainSuccess = true
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("admin_add_train_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Publish, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "下达车次开行指令")
                            }
                        }
                    }
                    2 -> {
                        //公告发布: Forms to submit an announcement/notice
                        if (annSuccess) {
                            AdminSuccessCard(title = "客运调度公告已全网发布！", desc = "消息已即时推送至所有铁路通旅客端通知中心。") {
                                annSuccess = false
                            }
                        } else {
                            Text(text = "撰写发布全国/区域调度运行公告", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = annTitle,
                                onValueChange = { annTitle = it },
                                label = { Text("公告标题") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = annSummary,
                                onValueChange = { annSummary = it },
                                label = { Text("消息摘要") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = annContent,
                                onValueChange = { annContent = it },
                                label = { Text("公告正文内容") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 5
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    if (annTitle.isNotEmpty() && annContent.isNotEmpty()) {
                                        viewModel.publishSystemAnnouncement(annTitle, annSummary, annContent)
                                        annTitle = ""
                                        annSummary = ""
                                        annContent = ""
                                        annSuccess = true
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("admin_publish_ann_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Campaign, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "发布调度命令公告")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminSuccessCard(title: String, desc: String, onDismiss: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFC8E6C9))
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF4CAF50)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.Campaign, contentDescription = null, tint = Color.White)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = desc, fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
            ) {
                Text(text = "好的")
            }
        }
    }
}
