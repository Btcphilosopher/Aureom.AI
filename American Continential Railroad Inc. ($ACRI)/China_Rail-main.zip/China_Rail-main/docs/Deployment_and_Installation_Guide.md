# 中国铁路通 (China Rail) 部署与安装手册
### 适合：运维人员、系统开发人员

本指南详细说明了本系统的微服务后端（Spring Boot + PostgreSQL）和客户端（Kotlin Android App）的安装、运行及打包发布流程。

---

## 1. 客户端 Android APP 构建

### 1.1 开发环境要求
* **Android Studio:** Ladybug (2024.2.1) 或更高版本
* **JDK:** Java Development Kit 17
* **Android SDK:** API Level 34 (Android 14) / Min SDK API Level 26

### 1.2 编译与运行
1. **导入项目:** 启动 Android Studio，选择 `Open` 导入根目录文件夹。
2. **本地配置 (Secrets Gradle):**
   * 如有外部网关 API 秘钥，请在 AI Studio 的 Secrets 面板配置，或直接写入根目录下 `.env` 文件：
     ```env
     GEMINI_API_KEY=AIzaSy...
     ```
   * 本系统配置了安全的 `BuildConfig` 读取，保证密钥在代码库中不被硬编码泄露。
3. **Gradle 同步:** 点击 **Sync Project with Gradle Files** 确保所有 Ksp, Room, Compose 依赖下载完毕。
4. **编译调试:**
   * 本系统采用 Gradle Kotlin DSL。可在 Terminal 运行以下指令检查编译：
     ```bash
     # 进行编译验证
     gradle assembleDebug
     ```
   * 打包正式版 AAB / APK:
     ```bash
     gradle :app:bundleRelease
     ```

---

## 2. 后端微服务部署 (Docker & PostgreSQL)

后端核心组件采用 Spring Boot 3 + PostgreSQL，采用 Docker 容器化编排实现快速部署。

### 2.1 基础依赖
* **Docker:** Engine 24+ 与 Compose v2+

### 2.2 启动编排实例
1. **进入后端目录:**
   ```bash
   cd backend/
   ```
2. **使用 Docker Compose 一键拉起微服务与数据库:**
   ```bash
   docker-compose up -d --build
   ```
3. **监控服务状态:**
   ```bash
   docker-compose ps
   docker-compose logs -f app
   ```

### 2.3 数据库自动配置与初始化
* 在 PostgreSQL 容器拉起后，本地数据库初始化配置会自动读取宿主机的 `/docs/PostgreSQL_Schema_and_SampleData.sql` 完成表结构创建及高保真样板车次数据注入。
* **默认数据库端口:** `5432`
* **默认连接用户名:** `chinarail` / 密码: `railpass321`

---

## 3. 生产就绪型 Kubernetes 编排建议

对于大型公网多可用区部署，建议将应用组件打包上传至云端私有仓库（如阿里云 ACR），并使用标准 Helm 或 YAML 部署：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: chinarail-backend
  namespace: prod-rail
spec:
  replicas: 3
  selector:
    matchLabels:
      app: rail-api
  template:
    metadata:
      labels:
        app: rail-api
    spec:
      containers:
      - name: spring-boot-app
        image: registry.cn-beijing.aliyuncs.com/chinarail/api:v2.1
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_DATASOURCE_URL
          value: "jdbc:postgresql://postgres-svc:5432/chinarail_db"
        - name: SPRING_DATASOURCE_USERNAME
          valueFrom:
            secretKeyRef:
              name: db-secrets
              key: username
```
