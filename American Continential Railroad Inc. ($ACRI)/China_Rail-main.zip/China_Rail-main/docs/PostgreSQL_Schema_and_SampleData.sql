-- ==========================================
-- CHINA RAILWAY (中国铁路通) DATABASE DESIGN
-- Production Schema for PostgreSQL
-- Target Architecture: Cloud Native Cluster
-- ==========================================

-- CREATE TABLES

-- 1. Users & Contacts
CREATE TABLE users (
    user_id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    real_name VARCHAR(100),
    id_type VARCHAR(50) DEFAULT '二代身份证',
    id_number VARCHAR(18) UNIQUE,
    phone_number VARCHAR(20) NOT NULL,
    is_realname_verified BOOLEAN DEFAULT FALSE,
    member_points INT DEFAULT 0,
    membership_level VARCHAR(50) DEFAULT '普通会员',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE passengers (
    passenger_id SERIAL PRIMARY KEY,
    user_id VARCHAR(50) REFERENCES users(user_id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    passenger_type VARCHAR(50) DEFAULT '成人', -- 成人, 儿童, 学生, 残疾军人
    id_type VARCHAR(50) DEFAULT '二代身份证',
    id_number VARCHAR(18) NOT NULL,
    phone_number VARCHAR(20),
    is_verified BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Cities & Stations
CREATE TABLE cities (
    city_code VARCHAR(10) PRIMARY KEY,
    city_name VARCHAR(100) NOT NULL UNIQUE,
    province VARCHAR(100)
);

CREATE TABLE stations (
    station_code VARCHAR(10) PRIMARY KEY,
    station_name VARCHAR(100) NOT NULL UNIQUE,
    city_code VARCHAR(10) REFERENCES cities(city_code) ON DELETE CASCADE,
    is_high_speed BOOLEAN DEFAULT TRUE,
    description TEXT,
    boarding_gate VARCHAR(100),
    platform_info VARCHAR(100),
    shops_list TEXT, -- Semi-colon delimited
    dining_list TEXT, -- Semi-colon delimited
    transfers_list TEXT, -- Semi-colon delimited
    accessibility_services TEXT -- Semi-colon delimited
);

-- 3. Railway Lines & Train Models
CREATE TABLE railway_lines (
    line_id VARCHAR(50) PRIMARY KEY,
    line_name VARCHAR(100) NOT NULL,
    from_city_code VARCHAR(10) REFERENCES cities(city_code),
    to_city_code VARCHAR(10) REFERENCES cities(city_code),
    max_speed_kmh INT DEFAULT 350
);

CREATE TABLE train_models (
    model_id VARCHAR(50) PRIMARY KEY,
    model_name VARCHAR(100) NOT NULL,
    capacity INT NOT NULL,
    amenities TEXT -- JSON or Semi-colon list
);

-- 4. Train Schedules (车次开行时刻)
CREATE TABLE train_schedules (
    train_number VARCHAR(20) PRIMARY KEY, -- e.g., G1
    model_id VARCHAR(50) REFERENCES train_models(model_id),
    from_station_code VARCHAR(10) REFERENCES stations(station_code),
    to_station_code VARCHAR(10) REFERENCES stations(station_code),
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    duration VARCHAR(20) NOT NULL,
    is_originating BOOLEAN DEFAULT TRUE,
    on_time_rate NUMERIC(5,2) DEFAULT 99.5,
    stop_sequence TEXT, -- Semicolon stations sequence
    stop_timestamps TEXT -- Semicolon timestamps sequence
);

-- Seating Prices Matrix
CREATE TABLE seat_prices (
    train_number VARCHAR(20) REFERENCES train_schedules(train_number) ON DELETE CASCADE,
    seat_class VARCHAR(50) NOT NULL, -- 商务座, 一等座, 二等座, 软卧, 硬卧, 硬座
    base_price NUMERIC(10,2) NOT NULL,
    PRIMARY KEY (train_number, seat_class)
);

-- 5. Seat Inventories
CREATE TABLE seat_inventory (
    seat_id SERIAL PRIMARY KEY,
    train_number VARCHAR(20) REFERENCES train_schedules(train_number) ON DELETE CASCADE,
    carriage_number VARCHAR(10) NOT NULL, -- e.g., 05车
    seat_number VARCHAR(10) NOT NULL, -- e.g., 12A
    seat_class VARCHAR(50) NOT NULL,
    travel_date DATE NOT NULL,
    is_booked BOOLEAN DEFAULT FALSE
);

-- 6. Ticketing Orders & E-Tickets
CREATE TABLE ticket_orders (
    order_id VARCHAR(50) PRIMARY KEY, -- e.g. CRN123456
    user_id VARCHAR(50) REFERENCES users(user_id),
    train_number VARCHAR(20) REFERENCES train_schedules(train_number),
    departure_date DATE NOT NULL,
    passenger_name VARCHAR(100) NOT NULL,
    passenger_id_number VARCHAR(18) NOT NULL,
    seat_class VARCHAR(50) NOT NULL,
    carriage VARCHAR(10) NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    price NUMERIC(10,2) NOT NULL,
    boarding_gate VARCHAR(50),
    platform VARCHAR(20),
    status VARCHAR(50) DEFAULT '待支付', -- 待支付, 已出票, 已退票, 已改签
    order_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE payments (
    payment_id VARCHAR(50) PRIMARY KEY,
    order_id VARCHAR(50) REFERENCES ticket_orders(order_id) ON DELETE CASCADE,
    payment_method VARCHAR(50) NOT NULL, -- 支付宝, 微信支付, 银联
    amount NUMERIC(10,2) NOT NULL,
    transaction_status VARCHAR(50) DEFAULT 'SUCCESS',
    pay_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. Marketing, Feeds & Broadcast Bulletins
CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(50) REFERENCES users(user_id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    notification_type VARCHAR(50) DEFAULT '系统公告', -- 行程提醒, 变动通知, 优惠活动, 系统公告
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE announcements (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    summary TEXT,
    content TEXT NOT NULL,
    publish_date DATE DEFAULT CURRENT_DATE,
    author VARCHAR(100) DEFAULT '中国铁路总调度中心'
);

CREATE TABLE promo_activities (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    promo_code VARCHAR(50) UNIQUE,
    discount_rate NUMERIC(10,2), -- flat cash rate deduction
    expire_date DATE NOT NULL
);


-- ==========================================
-- PREPOPULATE HIGH-FIDELITY SAMPLE SEED DATA
-- ==========================================

-- Cities
INSERT INTO cities (city_code, city_name, province) VALUES
('BJS', '北京', '北京'),
('SHA', '上海', '上海'),
('CAN', '广州', '广东'),
('SZX', '深圳', '广东'),
('CTU', '成都', '四川'),
('SIA', '西安', '陕西'),
('WUH', '武汉', '湖北'),
('HGH', '杭州', '浙江'),
('NKG', '南京', '江苏');

-- Stations
INSERT INTO stations (station_code, station_name, city_code, is_high_speed, description, boarding_gate, platform_info, shops_list, dining_list, transfers_list, accessibility_services) VALUES
('BJP', '北京南', 'BJS', true, '京沪高铁主要起点站，华北高铁客运龙头。', '12B, 13B', '6, 7', '华为体验店;米家;Costa', '永和大王;肯德基;庆丰包子', '地铁4号线;地铁14号线;公交300路', '无障碍电梯;盲道系统;爱心候车区'),
('AHP', '上海虹桥', 'SHA', true, '世界级超大型陆空联运综合枢纽。', '10B, 11A', '4, 5', 'Apple Store;罗森;上海故事', '麦当劳;老乡鸡;大娘水饺', '地铁2号线;地铁10号线;虹桥机场', '轮椅预约;母婴专用室;自助降位窗口'),
('IZQ', '广州南', 'CAN', true, '华南铁网心脏，连接粤港澳核心通道。', '08A, 09B', '8, 9', '屈臣氏;名创优品', '真功夫;广州酒家;星巴克', '地铁2号线;地铁7号线', '垂直电梯;轮椅坡道');

-- Train Models
INSERT INTO train_models (model_id, model_name, capacity, amenities) VALUES
('CR400AF', '复兴号智能动车组 CR400AF', 576, '智能5G车厢;静音车厢;Type-C接口;餐车咖啡阁'),
('CRH380A', '和谐号高速动车组 CRH380A', 480, '标准充电接口;温控洗漱室;液晶电视');

-- Train Schedules
INSERT INTO train_schedules (train_number, model_id, from_station_code, to_station_code, departure_time, arrival_time, duration, is_originating, on_time_rate, stop_sequence, stop_timestamps) VALUES
('G1', 'CR400AF', 'BJP', 'AHP', '07:00:00', '11:18:00', '4h18m', true, 99.8, '北京南;济南西;南京南;上海虹桥', '07:00;08:32;10:11;11:18'),
('G2', 'CR400AF', 'AHP', 'BJP', '07:00:00', '11:18:00', '4h18m', true, 99.5, '上海虹桥;南京南;济南西;北京南', '07:00;08:08;09:47;11:18');

-- Seating Prices
INSERT INTO seat_prices (train_number, seat_class, base_price) VALUES
('G1', '二等座', 553.00),
('G1', '一等座', 933.00),
('G1', '商务座', 1748.00),
('G2', '二等座', 553.00),
('G2', '一等座', 933.00),
('G2', '商务座', 1748.00);

-- Promo activities
INSERT INTO promo_activities (title, description, promo_code, discount_rate, expire_date) VALUES
('新注册会员购票立减 ¥15', '新注册并完成实名验证的用户，首单立减 ¥15 现金。', 'NEWRAIL15', 15.00, '2026-12-31');
