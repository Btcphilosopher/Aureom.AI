# 中国铁路通 (China Rail) REST API 规范文档
### 版本: v2.1 (Enterprise Ready)
### 传输格式: JSON

---

## 1. 认证接口 (Authentication & Security)

### 1.1 手机验证码/密码登录 (Login)
* **URL:** `/api/v1/auth/login`
* **Method:** `POST`
* **Request Body:**
```json
{
  "phoneNumber": "13800000000",
  "password": "hashed_password"
}
```
* **Response (Success 200 OK):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": "usr_99831",
  "realName": "王铁运",
  "membershipLevel": "黄金会员",
  "memberPoints": 2450
}
```

---

## 2. 车次查询与预订 (Train Schedule Search & Booking)

### 2.1 车次查询 (Query Train Schedules)
* **URL:** `/api/v1/trains/query`
* **Method:** `GET`
* **Query Parameters:**
  * `fromCity`: `北京`
  * `toCity`: `上海`
  * `date`: `2026-07-08`
* **Response (Success 200 OK):**
```json
[
  {
    "trainNumber": "G1",
    "trainModel": "复兴号智能动车组 CR400AF",
    "fromStation": "北京南",
    "toStation": "上海虹桥",
    "departureTime": "07:00",
    "arrivalTime": "11:18",
    "duration": "4h18m",
    "isOriginating": true,
    "onTimeRate": "99.8%",
    "secondClassPrice": 553.0,
    "firstClassPrice": 933.0,
    "businessClassPrice": 1748.0
  }
]
```

### 2.2 席别剩余库存与选座布局 (Seat Matrix Layout)
* **URL:** `/api/v1/trains/{trainNumber}/seats`
* **Method:** `GET`
* **Query Parameters:**
  * `date`: `2026-07-08`
  * `seatClass`: `二等座`
* **Response (Success 200 OK):**
```json
{
  "trainNumber": "G1",
  "carriage": "05车",
  "seatsLayout": [
    { "seat": "1A", "status": "AVAILABLE", "desc": "靠窗" },
    { "seat": "1B", "status": "OCCUPIED", "desc": "过道" },
    { "seat": "1C", "status": "AVAILABLE", "desc": "过道" },
    { "seat": "1D", "status": "OCCUPIED", "desc": "靠窗" }
  ]
}
```

---

## 3. 行程订单与退改签 (Order & Ticketing Lifecycle)

### 3.1 创建行程预订单 (Create Ticket Order)
* **URL:** `/api/v1/orders/create`
* **Method:** `POST`
* **Headers:** `Authorization: Bearer <JWT_TOKEN>`
* **Request Body:**
```json
{
  "trainNumber": "G1",
  "departureDate": "2026-07-08",
  "passengerId": 5,
  "seatClass": "二等座",
  "seatLetterPreference": "A"
}
```
* **Response (Success 201 Created):**
```json
{
  "orderId": "CRN8830129",
  "status": "待支付",
  "price": 553.00,
  "carriage": "05车",
  "seatNumber": "12A",
  "boardingGate": "12B",
  "platform": "6"
}
```

### 3.2 在线收银台支付 (Online Cashier Payment)
* **URL:** `/api/v1/orders/{orderId}/pay`
* **Method:** `POST`
* **Request Body:**
```json
{
  "paymentMethod": "Alipay",
  "amount": 553.00
}
```
* **Response (Success 200 OK):**
```json
{
  "paymentId": "PAY_901382",
  "status": "PAID",
  "transactionTime": "2026-07-07T12:00:04Z"
}
```

### 3.3 车票退票 (Ticket Refund)
* **URL:** `/api/v1/orders/{orderId}/refund`
* **Method:** `POST`
* **Response (200 OK):**
```json
{
  "orderId": "CRN8830129",
  "status": "已退票",
  "refundAmount": 553.00,
  "handlingFee": 0.00
}
```

### 3.4 快速改签 (Ticket Reschedule)
* **URL:** `/api/v1/orders/{orderId}/reschedule`
* **Method:** `POST`
* **Request Body:**
```json
{
  "newDate": "2026-07-09",
  "newTrainNumber": "G1"
}
```
* **Response (200 OK):**
```json
{
  "orderId": "CRN8830129",
  "status": "已改签",
  "newDepartureDate": "2026-07-09"
}
```

---

## 4. 客服、接驳与特服指南 (Services, Stations & Guides)

### 4.1 车站交通接驳导览 (Station Transfers Directories)
* **URL:** `/api/v1/stations`
* **Method:** `GET`
* **Response (200 OK):**
```json
[
  {
    "stationCode": "BJP",
    "name": "北京南",
    "city": "北京",
    "boardingGate": "12B, 13B",
    "shops": ["华为体验店", "Costa"],
    "dining": ["永和大王", "肯德基"],
    "transfers": ["地铁4号线", "地铁14号线"],
    "accessibility": ["盲道系统", "爱心专座区"]
  }
]
```

---

## 5. 行政调度后台系统 (Admin Staff Schedulers Center)

### 5.1 增开、调整临时列车 (Register / Add New Train Schedule)
* **URL:** `/api/v1/admin/trains`
* **Method:** `POST`
* **Headers:** `Authorization: Bearer <STAFF_JWT_TOKEN>`
* **Request Body:**
```json
{
  "trainNumber": "G99",
  "trainModel": "复兴号 CR400AF-B",
  "fromStation": "北京南",
  "toStation": "上海虹桥",
  "departureTime": "09:45",
  "arrivalTime": "14:12",
  "duration": "4h27m",
  "stopSequence": "北京南;济南西;上海虹桥",
  "stopTimestamps": "09:45;11:12;14:12",
  "secondClassPrice": 553.00,
  "firstClassPrice": 933.00,
  "businessClassPrice": 1748.00
}
```
* **Response (Success 201 Created):**
```json
{
  "success": true,
  "message": "车次 G99 已成功录入全国铁路编组系统并开售。"
}
```

### 5.2 全网发布客运、极端天气公告 (Publish Notices Bulletin)
* **URL:** `/api/v1/admin/announcements`
* **Method:** `POST`
* **Request Body:**
```json
{
  "title": "防汛预警：京广线部分普速列车临时降速运行",
  "summary": "受南方大范围降雨影响，京广、沪昆沿线多趟普客预计晚点。",
  "content": "中国铁路总调度中心接气象部门通报，因暴雨侵袭，现对沿途部分段落执行降速30%安全预案。具体晚点信息请密切留意本客户端消息推送..."
}
```
* **Response (Success 201 Created):**
```json
{
  "announcementId": 14,
  "published": true
}
```
