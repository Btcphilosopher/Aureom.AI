package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.GridMarketApp
import com.example.ui.MarketViewModel
import com.example.ui.theme.CypherpunkTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CypherpunkTheme {
                val factory = ViewModelProvider.AndroidViewModelFactory.getInstance(application)
                val viewModel: MarketViewModel = viewModel(factory = factory)
                GridMarketApp(viewModel = viewModel)
            }
        }
    }
}
