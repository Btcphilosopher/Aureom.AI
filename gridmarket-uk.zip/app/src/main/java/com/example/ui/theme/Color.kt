package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BitcoinOrange = Color(0xFFF7931A)
val TerminalGreen = Color(0xFF00FF41)
val BackgroundDark = Color(0xFF0D0F12)
val SurfaceDark = Color(0xFF16181D)
val SurfaceInner = Color(0xFF22262E)
val BorderDark = Color(0xFF2A2D32)
val TextPrimary = Color(0xFFE0E0E0)
val TextSecondary = Color(0xFF8892A0)
val TextMuted = Color(0xFF555555)
