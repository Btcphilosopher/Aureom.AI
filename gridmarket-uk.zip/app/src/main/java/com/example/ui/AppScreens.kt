package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.CartItemWithProduct
import com.example.data.Product
import com.example.ui.theme.*

@Composable
fun GridMarketApp(viewModel: MarketViewModel) {
    val navController = rememberNavController()
    
    val cartWithProducts by viewModel.cartWithProducts.collectAsStateWithLifecycle()
    val totalItems = cartWithProducts.sumOf { it.quantity }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BackgroundDark)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "N0de_Established: LDN_020",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = BitcoinOrange,
                            letterSpacing = 2.sp
                        )
                        Text(
                            "ANGLO_CRYPT",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = Color.White,
                            letterSpacing = (-1).sp
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BadgedBox(
                            badge = {
                                if (totalItems > 0) {
                                    Badge(
                                        containerColor = BitcoinOrange,
                                        contentColor = Color.Black
                                    ) { Text("$totalItems") }
                                }
                            },
                            modifier = Modifier.clickable { navController.navigate("cart") }
                        ) {
                            Icon(
                                Icons.Filled.ShoppingCart,
                                contentDescription = "Cart",
                                tint = TextPrimary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(TerminalGreen, CircleShape)
                        )
                        Text(
                            "SYNC_OK",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = TerminalGreen
                        )
                    }
                }
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BorderDark))
            }
        },
        containerColor = BackgroundDark,
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BorderDark))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BackgroundDark)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("VAULT", color = BitcoinOrange, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp)
                    Text("LEDGER", color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp)
                    Text("WALLET", color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp)
                    Text("DEBUG", color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp)
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController, 
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") {
                HomeScreen(viewModel, navController)
            }
            composable("cart") {
                CartScreen(viewModel, navController)
            }
            composable("checkout") {
                CheckoutScreen(viewModel, navController)
            }
        }
    }
}

@Composable
fun HomeScreen(viewModel: MarketViewModel, navController: NavController) {
    val products by viewModel.products.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(products) { product ->
            ProductCard(product = product) {
                viewModel.addToCart(product.id)
            }
        }
    }
}

@Composable
fun ProductCard(product: Product, onAddToCart: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BorderDark)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF1C1F26), SurfaceDark)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "LIMITED_EDITION_1/50",
                    color = BitcoinOrange,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                        .border(1.dp, BitcoinOrange.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
                
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .background(SurfaceInner, CircleShape)
                        .border(1.dp, BorderDark, CircleShape)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = product.imageResId),
                        contentDescription = product.name,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
                
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = product.name.uppercase(),
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 20.sp,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = product.description.uppercase(),
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }
            
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BackgroundDark.copy(alpha = 0.5f))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text("SATOSHIS_REQUIRED", color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "%.4f".format(product.priceBtc),
                                color = BitcoinOrange,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("BTC", color = BitcoinOrange.copy(alpha = 0.6f), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = onAddToCart,
                    colors = ButtonDefaults.buttonColors(containerColor = BitcoinOrange),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Text("ADD TO CART", color = Color.Black, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                }
            }
        }
    }
}

@Composable
fun CartScreen(viewModel: MarketViewModel, navController: NavController) {
    val cartWithProducts by viewModel.cartWithProducts.collectAsStateWithLifecycle()
    val totalBtc by viewModel.cartTotalBtc.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Text(
                "YOUR CART",
                fontFamily = FontFamily.SansSerif,
                fontSize = 20.sp,
                color = Color.White,
                fontWeight = FontWeight.Black,
                letterSpacing = (-1).sp
            )
        }

        if (cartWithProducts.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Cart is empty.", color = TextMuted, fontFamily = FontFamily.Monospace)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(cartWithProducts) { item ->
                    CartItemRow(item = item, onRemove = { viewModel.removeFromCart(item.product.id) })
                }
            }
            
            Surface(
                color = BackgroundDark,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TOTAL", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 16.sp)
                        Text("₿ ${"%.4f".format(totalBtc)}", color = BitcoinOrange, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { navController.navigate("checkout") },
                        colors = ButtonDefaults.buttonColors(containerColor = BitcoinOrange),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        Text("PAY_VIA_LIGHTNING", color = Color.Black, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemRow(item: CartItemWithProduct, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceDark, RoundedCornerShape(12.dp))
            .border(1.dp, BorderDark, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .background(SurfaceInner, CircleShape)
                .border(1.dp, BorderDark, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = item.product.imageResId),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(4.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(item.product.name.uppercase(), color = Color.White, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold)
            Text("QTY: ${item.quantity}", color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }
        Text("₿ ${"%.4f".format(item.product.priceBtc * item.quantity)}", color = BitcoinOrange, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.width(12.dp))
        TextButton(onClick = onRemove) {
            Text("X", color = TextMuted, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CheckoutScreen(viewModel: MarketViewModel, navController: NavController) {
    var btcAddress by remember { mutableStateOf<String?>(null) }
    val totalBtc by viewModel.cartTotalBtc.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.placeOrder { address ->
            btcAddress = address
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (btcAddress == null) {
            CircularProgressIndicator(color = BitcoinOrange)
            Spacer(modifier = Modifier.height(16.dp))
            Text("ESTABLISHING_SECURE_NODE...", color = BitcoinOrange, fontFamily = FontFamily.Monospace)
        } else {
            Text(
                "AWAITING PAYMENT",
                fontFamily = FontFamily.SansSerif,
                fontSize = 24.sp,
                color = Color.White,
                fontWeight = FontWeight.Black,
                letterSpacing = (-1).sp
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "█▀▀▀▀▀█ ▀▀▀█▀ █▀▀▀▀▀█\n█ ███ █ █ █▀▀ █ ███ █\n█ ▀▀▀ █ █ ▀▀█ █ ▀▀▀ █\n▀▀▀▀▀▀▀ ▀ ▀ ▀ ▀▀▀▀▀▀▀\n▀█▀▀▀ ▀█ ▀▀ ▀ ▀█  █▀█\n▀ ▀▀ ▀▀  █ ▀█ ▀▀  █ ▀\n▀▀▀▀▀▀▀ ▀▀▀ █ ▀█ ▀█▀█\n█▀▀▀▀▀█ ▀ █▀  █ ▀ █ █\n█ ███ █ ▀▀█ ▀ ▀▀▀▀█▀█\n█ ▀▀▀ █ ▀ ▀██ ▀▀ █▀ █\n▀▀▀▀▀▀▀ ▀▀▀▀▀ ▀▀▀  ▀▀",
                    fontFamily = FontFamily.Monospace,
                    color = Color.Black,
                    lineHeight = 12.sp,
                    fontSize = 12.sp
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Text("SEND_EXACTLY:", color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("₿ ${"%.4f".format(totalBtc)}", color = BitcoinOrange, fontSize = 28.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text("TO_ADDRESS:", color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Surface(
                color = SurfaceInner,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                Text(
                    text = btcAddress ?: "",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center
                )
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            
            Button(
                onClick = { navController.navigate("home") { popUpTo(0) } },
                colors = ButtonDefaults.buttonColors(containerColor = SurfaceInner),
                border = BorderStroke(1.dp, BorderDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(16.dp)
            ) {
                Text("RETURN_TO_MARKET", color = TextPrimary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }
    }
}
