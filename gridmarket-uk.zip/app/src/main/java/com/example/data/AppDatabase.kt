package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.R
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

@Database(entities = [Product::class, CartItem::class, Order::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun marketDao(): MarketDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "market_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class MarketRepository(private val dao: MarketDao) {
    val allProducts: Flow<List<Product>> = dao.getAllProducts()
    val cartItems: Flow<List<CartItem>> = dao.getCartItems()
    val allOrders: Flow<List<Order>> = dao.getAllOrders()

    val cartWithProducts: Flow<List<CartItemWithProduct>> = 
        allProducts.combine(cartItems) { products, cart ->
            cart.mapNotNull { cartItem ->
                val product = products.find { it.id == cartItem.productId }
                if (product != null) CartItemWithProduct(product, cartItem.quantity) else null
            }
        }

    val cartTotalBtc: Flow<Double> = cartWithProducts.combine(cartItems) { cartWithProd, _ ->
        cartWithProd.sumOf { it.product.priceBtc * it.quantity }
    }

    suspend fun initializeProductsIfEmpty() {
        // Pre-populate with our generated Anglo-futurist items
        val currentProducts = dao.getCartItems() // Just to check DB access
        // We actually need a one-time check for products
    }
    
    suspend fun seedProducts() {
        val defaultProducts = listOf(
            Product(
                id = "p1",
                name = "Cybernetic Pocket Watch",
                description = "A steampunk Victorian cybernetic pocket watch with glowing neon green digital numbers and gear mechanisms.",
                priceBtc = 0.015,
                imageResId = R.drawable.product_pocket_watch_1787317002179
            ),
            Product(
                id = "p2",
                name = "Neural Tweed Coat",
                description = "A futuristic tweed coat infused with glowing fiber optic cables and neon circuit patterns.",
                priceBtc = 0.082,
                imageResId = R.drawable.product_tweed_coat_1787317013673
            ),
            Product(
                id = "p3",
                name = "Holographic Monocle",
                description = "A copper and steel cybernetic monocle with a red glowing laser eye overlay.",
                priceBtc = 0.045,
                imageResId = R.drawable.product_monocle_1787317023941
            )
        )
        dao.insertProducts(defaultProducts)
    }

    suspend fun getProduct(id: String) = dao.getProductById(id)

    suspend fun addToCart(productId: String) {
        val qty = dao.getCartItemQuantity(productId)
        if (qty != null) {
            dao.incrementCartItem(productId)
        } else {
            dao.insertCartItem(CartItem(productId, 1))
        }
    }

    suspend fun removeFromCart(productId: String) {
        dao.removeCartItem(productId)
    }

    suspend fun placeOrder(totalBtc: Double): String {
        val btcAddress = "bc1q" + (1..38).map { "0123456789abcdefghijklmnopqrstuvwxyz".random() }.joinToString("")
        val order = Order(btcAddress = btcAddress, totalBtc = totalBtc, status = "PENDING")
        dao.insertOrder(order)
        dao.clearCart()
        return btcAddress
    }
}
