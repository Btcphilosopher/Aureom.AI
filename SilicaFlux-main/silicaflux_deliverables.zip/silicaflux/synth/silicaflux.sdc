set sdc_version 2.1

# ---------------------------------------------------------------------------
# SilicaFlux SoC cluster (silicaflux_top) - 100 MHz
# ---------------------------------------------------------------------------

set sfx_clk_period          10.000
set sfx_clk_unc_setup        0.400
set sfx_clk_unc_hold         0.150
set sfx_clk_transition       0.150

set sfx_ctl_in_max           3.000
set sfx_ctl_in_min           0.500
set sfx_dbg_out_max          3.000
set sfx_dbg_out_min         -0.300
set sfx_link_in_max          3.500
set sfx_link_in_min          0.500
set sfx_link_out_max         3.500
set sfx_link_out_min        -0.300

set sfx_in_tran_max          0.250
set sfx_in_tran_min          0.050
set sfx_out_load             0.020
set sfx_max_tran             0.500
set sfx_max_fanout           32

# ---------------------------------------------------------------------------
# Clocks
# ---------------------------------------------------------------------------

create_clock -name clk -period $sfx_clk_period \
    -waveform [list 0.000 [expr {$sfx_clk_period / 2.0}]] \
    [get_ports clk]

set_clock_uncertainty -setup $sfx_clk_unc_setup [get_clocks clk]
set_clock_uncertainty -hold  $sfx_clk_unc_hold  [get_clocks clk]
set_clock_transition         $sfx_clk_transition [get_clocks clk]

# ---------------------------------------------------------------------------
# I/O timing - program-load / control port
# ---------------------------------------------------------------------------

set_input_delay  -clock [get_clocks clk] -max $sfx_ctl_in_max \
    [get_ports {rst_n imem_wr_en imem_wr_addr[*] imem_wr_data[*]}]
set_input_delay  -clock [get_clocks clk] -min $sfx_ctl_in_min \
    [get_ports {rst_n imem_wr_en imem_wr_addr[*] imem_wr_data[*]}]

# ---------------------------------------------------------------------------
# I/O timing - status / debug observation port
# ---------------------------------------------------------------------------

set_output_delay -clock [get_clocks clk] -max $sfx_dbg_out_max \
    [get_ports {halt debug_scalar_r1[*]}]
set_output_delay -clock [get_clocks clk] -min $sfx_dbg_out_min \
    [get_ports {halt debug_scalar_r1[*]}]

# ---------------------------------------------------------------------------
# I/O timing - chiplet NoC boundary (tile_interface PHY link)
# ---------------------------------------------------------------------------

set_input_delay  -clock [get_clocks clk] -max $sfx_link_in_max \
    [get_ports {tile_phy_tx_credit tile_phy_rx_data[*] tile_phy_rx_valid}]
set_input_delay  -clock [get_clocks clk] -min $sfx_link_in_min \
    [get_ports {tile_phy_tx_credit tile_phy_rx_data[*] tile_phy_rx_valid}]

set_output_delay -clock [get_clocks clk] -max $sfx_link_out_max \
    [get_ports {tile_phy_tx_data[*] tile_phy_tx_valid tile_phy_rx_credit}]
set_output_delay -clock [get_clocks clk] -min $sfx_link_out_min \
    [get_ports {tile_phy_tx_data[*] tile_phy_tx_valid tile_phy_rx_credit}]

# ---------------------------------------------------------------------------
# Boundary electrical environment and design rules
# ---------------------------------------------------------------------------

set_input_transition -max $sfx_in_tran_max \
    [get_ports {rst_n imem_wr_en imem_wr_addr[*] imem_wr_data[*] tile_phy_tx_credit tile_phy_rx_data[*] tile_phy_rx_valid}]
set_input_transition -min $sfx_in_tran_min \
    [get_ports {rst_n imem_wr_en imem_wr_addr[*] imem_wr_data[*] tile_phy_tx_credit tile_phy_rx_data[*] tile_phy_rx_valid}]

set_load $sfx_out_load [all_outputs]

set_max_transition $sfx_max_tran   [current_design]
set_max_fanout     $sfx_max_fanout [current_design]

# ---------------------------------------------------------------------------
# False paths - asynchronous reset, asynchronous chiplet RX link (2-FF sync)
# ---------------------------------------------------------------------------

set_false_path -from [get_ports rst_n]

set_false_path \
    -from [get_ports {tile_phy_rx_data[*] tile_phy_rx_valid}] \
    -to   [get_cells -hierarchical {*phy_rx_data_s1_reg* *phy_rx_valid_s1_reg*}]

# ---------------------------------------------------------------------------
# Multicycle paths - tensor_unit (operands held from LOAD through CALC,
# result held from FINISH until compute_tile capture on tensor_done)
# ---------------------------------------------------------------------------

set_multicycle_path -setup 2 \
    -from [get_cells -hierarchical {*A_flat_reg* *B_flat_reg*}] \
    -to   [get_cells -hierarchical {*C_flat_reg*}]
set_multicycle_path -hold  1 \
    -from [get_cells -hierarchical {*A_flat_reg* *B_flat_reg*}] \
    -to   [get_cells -hierarchical {*C_flat_reg*}]

set_multicycle_path -setup 2 \
    -from [get_cells -hierarchical {*C_flat_reg*}] \
    -to   [get_cells -hierarchical {*tile_result_vector_reg* *tile_result_scalar_reg*}]
set_multicycle_path -hold  1 \
    -from [get_cells -hierarchical {*C_flat_reg*}] \
    -to   [get_cells -hierarchical {*tile_result_vector_reg* *tile_result_scalar_reg*}]

# ---------------------------------------------------------------------------
# Multicycle paths - memory_controller burst write (vector write data held
# by compute_tile for the whole VSTORE/DFSTORE burst, first beat at +2)
# ---------------------------------------------------------------------------

set_multicycle_path -setup 2 \
    -from [get_cells -hierarchical {*mem_req_vwdata_reg*}] \
    -to   [get_cells -hierarchical {*sram_reg*}]
set_multicycle_path -hold  1 \
    -from [get_cells -hierarchical {*mem_req_vwdata_reg*}] \
    -to   [get_cells -hierarchical {*sram_reg*}]
