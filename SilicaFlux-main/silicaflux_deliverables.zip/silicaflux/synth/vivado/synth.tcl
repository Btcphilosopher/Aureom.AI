# =============================================================================
# SilicaFlux FPGA build - Digilent Arty A7-100T (Artix-7 xc7a100tcsg324-1)
#
#   vivado -mode batch -nojournal -log silicaflux_fpga.log -source synth.tcl \
#          [-tclargs KEY=VALUE ...]
#
# KEY=VALUE overrides (also read from the environment as SFX_<KEY>):
#   RTL_DIR  SDC  XDC  BUILD_DIR  PART  TOP  JOBS
#   STOP_AFTER=synth|impl|bitstream      TIMING_GATE=core|all|none
#   RETIMING=0|1  POWER_OPT=1|0          BOARD_XDC_TIMING=strip|keep
#   ALLOW_CRITICAL_WARNINGS=0|1  ALLOW_LATCHES=0|1  ALLOW_UNCONSTRAINED_IO=0|1
#   SYNTH_DIRECTIVE  OPT_DIRECTIVE  PLACE_DIRECTIVE  PHYS_OPT_DIRECTIVE
#   ROUTE_DIRECTIVE  POST_ROUTE_PHYS_OPT_DIRECTIVE
# =============================================================================

namespace eval ::sfx {
    variable kv
    variable cfg
    variable logfh ""
    variable cw_base 0
    variable t_start [clock seconds]
    array set kv  {}
    array set cfg {}

    variable known_keys {
        RTL_DIR SDC XDC BUILD_DIR PART TOP JOBS STOP_AFTER TIMING_GATE RETIMING
        POWER_OPT BOARD_XDC_TIMING ALLOW_CRITICAL_WARNINGS ALLOW_LATCHES
        ALLOW_UNCONSTRAINED_IO SYNTH_DIRECTIVE OPT_DIRECTIVE PLACE_DIRECTIVE
        PHYS_OPT_DIRECTIVE ROUTE_DIRECTIVE POST_ROUTE_PHYS_OPT_DIRECTIVE
    }

    variable source_modules {
        silicaflux_pkg
        fetch_unit
        decoder
        alu
        forwarding_unit
        control_core
        register_bank
        vector_engine
        tensor_unit
        memory_controller
        scheduler
        compute_tile
        noc_router
        noc_interconnect
        tile_interface
        silicaflux_top
    }

    variable required_modules {
        fetch_unit decoder control_core register_bank scheduler memory_controller
        compute_tile vector_engine tensor_unit noc_interconnect noc_router
        tile_interface
    }

    variable asic_only_sdc_cmds {
        set_clock_transition set_input_transition set_load set_driving_cell
        set_drive set_max_transition set_max_fanout set_max_capacitance
        set_min_capacitance set_fanout_load set_ideal_network set_ideal_net
        set_ideal_latency set_ideal_transition set_wire_load_model
        set_wire_load_mode set_wire_load_selection_group set_operating_conditions
        set_units current_design set_max_area set_dont_touch
        set_dont_touch_network set_max_dynamic_power set_max_leakage_power
        set_timing_derate set_resistance set_port_fanout_number
    }

    variable timing_cmds {
        create_clock create_generated_clock set_clock_uncertainty
        set_clock_latency set_clock_groups set_clock_sense set_input_jitter
        set_system_jitter set_input_delay set_output_delay set_false_path
        set_multicycle_path set_max_delay set_min_delay set_bus_skew
        set_max_time_borrow set_disable_timing set_case_analysis group_path
        set_external_delay set_data_check
    }
}

# -----------------------------------------------------------------------------
# Logging, failure handling, stage control
# -----------------------------------------------------------------------------

proc ::sfx::log {msg} {
    variable logfh
    set line "SFX [clock format [clock seconds] -format {%Y-%m-%d %H:%M:%S}] | $msg"
    puts $line
    flush stdout
    if {$logfh ne ""} {
        puts $logfh $line
        flush $logfh
    }
}

proc ::sfx::fail {stage msg} {
    variable cfg
    ::sfx::log "FATAL   \[$stage\] $msg"
    if {[info exists cfg(build_dir)] && [file isfile [file join $cfg(build_dir) .sfx_build_dir]]} {
        set fh [open [file join $cfg(build_dir) FAILED] w]
        puts $fh "stage : $stage"
        puts $fh "error : $msg"
        puts $fh "time  : [clock format [clock seconds] -format {%Y-%m-%d %H:%M:%S}]"
        close $fh
    }
    return -code error -errorcode [list SFX FAIL $stage] \
        "SilicaFlux build failed in stage '$stage': $msg"
}

proc ::sfx::elapsed {secs} {
    format "%02d:%02d:%02d" [expr {$secs / 3600}] [expr {($secs % 3600) / 60}] [expr {$secs % 60}]
}

proc ::sfx::stage {name body} {
    variable cfg
    set cfg(stage) $name
    ::sfx::log "BEGIN   $name"
    set t0 [clock seconds]
    set rc [catch {apply [list {} "upvar #0 ::sfx::cfg cfg\n$body" ::]} result opts]
    if {$rc == 1} {
        set ec [dict get $opts -errorcode]
        if {[lindex $ec 0] eq "SFX" && [lindex $ec 1] eq "FAIL"} {
            return -options $opts $result
        }
        ::sfx::fail $name "Vivado/Tcl error: $result"
    } elseif {$rc != 0 && $rc != 2} {
        ::sfx::fail $name "unexpected control flow (code $rc)"
    }
    ::sfx::log "END     $name ([::sfx::elapsed [expr {[clock seconds] - $t0}]])"
    return $result
}

proc ::sfx::rpt {required file script} {
    if {[catch {uplevel 1 $script} err]} {
        if {$required} {
            ::sfx::fail $::sfx::cfg(stage) "required report [file tail $file] failed: $err"
        }
        ::sfx::log "WARN    optional report [file tail $file] skipped: $err"
        return 0
    }
    return 1
}

# -----------------------------------------------------------------------------
# Options
# -----------------------------------------------------------------------------

proc ::sfx::parse_args {argv} {
    variable kv
    variable known_keys
    foreach a $argv {
        if {![regexp {^([A-Za-z][A-Za-z0-9_]*)=(.*)$} $a -> k v]} {
            ::sfx::fail configure "malformed -tclargs entry '$a' (expected KEY=VALUE)"
        }
        set k [string toupper $k]
        if {[lsearch -exact $known_keys $k] < 0} {
            ::sfx::fail configure "unknown option '$k' (known: [join $known_keys {, }])"
        }
        set kv($k) $v
    }
}

proc ::sfx::opt {key default} {
    variable kv
    if {[info exists kv($key)]} {
        return $kv($key)
    }
    if {[info exists ::env(SFX_$key)] && $::env(SFX_$key) ne ""} {
        return $::env(SFX_$key)
    }
    return $default
}

proc ::sfx::opt_bool {key default} {
    set v [::sfx::opt $key $default]
    if {![string is boolean -strict $v]} {
        ::sfx::fail configure "option $key expects a boolean, got '$v'"
    }
    return [expr {[string is true -strict $v] ? 1 : 0}]
}

proc ::sfx::opt_enum {key default allowed} {
    set v [string tolower [::sfx::opt $key $default]]
    if {[lsearch -exact $allowed $v] < 0} {
        ::sfx::fail configure "option $key='$v' not in {[join $allowed {|}]}"
    }
    return $v
}

# -----------------------------------------------------------------------------
# Source / file resolution
# -----------------------------------------------------------------------------

proc ::sfx::find_rtl_dir {script_dir} {
    foreach d [list [file join $script_dir rtl] [file join $script_dir .. rtl] \
                    [file join $script_dir .. .. rtl] $script_dir] {
        foreach ext {sf sv} {
            if {[file isfile [file join $d silicaflux_top.$ext]]} {
                return [file normalize $d]
            }
        }
    }
    return ""
}

proc ::sfx::find_source {rtl_dir module} {
    foreach ext {sf sv} {
        set f [file join $rtl_dir $module.$ext]
        if {[file isfile $f]} {
            return [file normalize $f]
        }
    }
    return ""
}

proc ::sfx::first_file {candidates} {
    foreach c $candidates {
        if {$c ne "" && [file isfile $c]} {
            return [file normalize $c]
        }
    }
    return ""
}

proc ::sfx::read_text {path} {
    set fh [open $path r]
    set txt [read $fh]
    close $fh
    return $txt
}

proc ::sfx::write_text {path txt} {
    set fh [open $path w]
    puts -nonewline $fh $txt
    close $fh
}

proc ::sfx::unresolved_includes {files incdirs} {
    set missing {}
    foreach f $files {
        foreach {full inc} [regexp -all -inline {`include\s+"([^"]+)"} [::sfx::read_text $f]] {
            set found 0
            foreach d [concat [list [file dirname $f]] $incdirs] {
                if {[file isfile [file join $d $inc]]} {
                    set found 1
                    break
                }
            }
            if {!$found} {
                lappend missing "[file tail $f] -> \"$inc\""
            }
        }
    }
    return [lsort -unique $missing]
}

proc ::sfx::pkg_param {pkg_file name} {
    set v ""
    regexp "parameter\\s+int\\s+${name}\\s*=\\s*(\\d+)\\s*;" [::sfx::read_text $pkg_file] -> v
    return $v
}

proc ::sfx::prepare_build_dir {dir} {
    set marker [file join $dir .sfx_build_dir]
    if {[file exists $dir]} {
        if {![file isdirectory $dir]} {
            ::sfx::fail configure "BUILD_DIR '$dir' exists and is not a directory"
        }
        if {[file isfile $marker]} {
            file delete -force $dir
        } else {
            set entries {}
            foreach e [concat [glob -nocomplain -directory $dir *] \
                              [glob -nocomplain -types hidden -directory $dir *]] {
                if {[file tail $e] ni {. ..}} {
                    lappend entries $e
                }
            }
            if {[llength $entries] > 0} {
                ::sfx::fail configure "refusing to clean '$dir': not a SilicaFlux build directory (no .sfx_build_dir marker)"
            }
        }
    }
    file mkdir $dir
    foreach sub {reports checkpoints netlist bitstream constraints} {
        file mkdir [file join $dir $sub]
    }
    ::sfx::write_text $marker "silicaflux_fpga build directory - safe to delete\n"
}

# -----------------------------------------------------------------------------
# Constraint processing
# -----------------------------------------------------------------------------

proc ::sfx::logical_commands {path} {
    set cmds {}
    set buf ""
    foreach line [split [::sfx::read_text $path] "\n"] {
        if {$buf eq ""} {
            set buf $line
        } else {
            append buf "\n" $line
        }
        if {[regexp {\\$} $line]} {
            continue
        }
        if {![info complete "$buf\n"]} {
            continue
        }
        lappend cmds $buf
        set buf ""
    }
    if {[string trim $buf] ne ""} {
        lappend cmds $buf
    }
    return $cmds
}

proc ::sfx::command_name {cmd} {
    set name ""
    regexp {^\s*([A-Za-z_][A-Za-z0-9_:]*)} $cmd -> name
    return $name
}

proc ::sfx::filter_constraints {src dst drop_cmds banner} {
    set out [list "# $banner" "# source: $src"]
    set kept 0
    set dropped {}
    foreach c [::sfx::logical_commands $src] {
        set name [::sfx::command_name $c]
        if {$name ne "" && [lsearch -exact $drop_cmds $name] >= 0} {
            lappend dropped $name
            regsub -all {\\\n\s*} [string trim $c] " " flat
            lappend out "# \[not applied in this flow\] $flat"
            continue
        }
        lappend out $c
        if {$name ne "" && $name ne "set"} {
            incr kept
        }
    }
    ::sfx::write_text $dst "[join $out \n]\n"
    return [list $kept $dropped]
}

proc ::sfx::object_queries {cmd} {
    set res {}
    set n [string length $cmd]
    set i 0
    while {[set s [string first {[get_} $cmd $i]] >= 0} {
        set depth 0
        set brace 0
        for {set j $s} {$j < $n} {incr j} {
            set ch [string index $cmd $j]
            if {$ch eq "\\"} {
                incr j
                continue
            }
            if {$ch eq "\{"} {
                incr brace
            } elseif {$ch eq "\}"} {
                incr brace -1
            } elseif {$brace == 0 && $ch eq "\["} {
                incr depth
            } elseif {$brace == 0 && $ch eq "\]"} {
                incr depth -1
                if {$depth == 0} {
                    break
                }
            }
        }
        lappend res [string range $cmd [expr {$s + 1}] [expr {$j - 1}]]
        set i [expr {$j + 1}]
    }
    return $res
}

proc ::sfx::audit_constraints {files} {
    set empty {}
    set partial {}
    set checked 0
    foreach f $files {
        foreach c [::sfx::logical_commands $f] {
            if {[regexp {^\s*#} $c] || [::sfx::command_name $c] eq ""} {
                continue
            }
            foreach q [::sfx::object_queries $c] {
                if {[string first "\$" $q] >= 0} {
                    continue
                }
                if {[catch {llength $q}] || ![regexp {^get_(cells|ports|pins|nets|clocks)$} [lindex $q 0]]} {
                    continue
                }
                if {[catch {llength [uplevel #0 [linsert $q 1 -quiet]]} n]} {
                    continue
                }
                incr checked
                set cmd   [lindex $q 0]
                set words [lrange $q 1 end]
                if {$n == 0} {
                    lappend empty "[file tail $f]: \[$q\]"
                    continue
                }
                set flags [lrange $words 0 end-1]
                if {[lsearch -regexp $flags {^-(filter|of_objects|regexp|nocase)$}] >= 0} {
                    continue
                }
                set pats [lindex $words end]
                if {[llength $pats] > 1} {
                    foreach p $pats {
                        if {[llength [uplevel #0 [concat [list $cmd -quiet] $flags [list $p]]]] == 0} {
                            lappend partial "$p (in \[$q\])"
                        }
                    }
                }
            }
        }
    }
    return [list $checked [lsort -unique $empty] [lsort -unique $partial]]
}

# -----------------------------------------------------------------------------
# Design queries
# -----------------------------------------------------------------------------

proc ::sfx::module_census {} {
    array set count {}
    set cells [get_cells -quiet -hierarchical]
    if {[llength $cells] == 0} {
        return {}
    }
    set refs  [get_property -quiet REF_NAME $cells]
    set orefs [get_property -quiet ORIG_REF_NAME $cells]
    foreach r $refs o $orefs {
        set m [expr {$o ne "" ? $o : $r}]
        regsub {__parameterized[0-9]+$} $m "" m
        if {$m eq ""} {
            continue
        }
        if {[info exists count($m)]} {
            incr count($m)
        } else {
            set count($m) 1
        }
    }
    return [array get count]
}

proc ::sfx::cw_count {} {
    if {[catch {get_msg_config -severity {CRITICAL WARNING} -count} n] || ![string is integer -strict $n]} {
        return -1
    }
    return $n
}

proc ::sfx::check_critical_warnings {stage} {
    variable cw_base
    variable cfg
    set n [::sfx::cw_count]
    if {$n < 0} {
        ::sfx::log "WARN    critical-warning accounting unavailable in this Vivado release"
        return
    }
    set new [expr {$n - $cw_base}]
    set cw_base $n
    if {$new <= 0} {
        return
    }
    if {$cfg(allow_cw)} {
        ::sfx::log "WARN    $new critical warning(s) during $stage (ALLOW_CRITICAL_WARNINGS=1)"
    } else {
        ::sfx::fail $stage "$new critical warning(s) issued - inspect the Vivado log; set ALLOW_CRITICAL_WARNINGS=1 only after review"
    }
}

proc ::sfx::worst_slack {delay_type args} {
    set paths [get_timing_paths -quiet -delay_type $delay_type -max_paths 1 -nworst 1 {*}$args]
    if {[llength $paths] == 0} {
        return ""
    }
    set s [get_property SLACK [lindex $paths 0]]
    if {![string is double -strict $s] || [string match -nocase *inf* $s]} {
        return ""
    }
    return $s
}

proc ::sfx::fmt_slack {s} {
    if {$s eq ""} {
        return "n/a"
    }
    return [format "%+.3f ns" $s]
}

proc ::sfx::slack_ok {s} {
    return [expr {$s eq "" || $s >= 0.0}]
}

proc ::sfx::timing_snapshot {} {
    set regs [all_registers]
    return [dict create \
        all_setup  [::sfx::worst_slack max] \
        all_hold   [::sfx::worst_slack min] \
        core_setup [::sfx::worst_slack max -from $regs -to $regs] \
        core_hold  [::sfx::worst_slack min -from $regs -to $regs] \
        in_setup   [::sfx::worst_slack max -from [all_inputs]] \
        in_hold    [::sfx::worst_slack min -from [all_inputs]] \
        out_setup  [::sfx::worst_slack max -to [all_outputs]] \
        out_hold   [::sfx::worst_slack min -to [all_outputs]]]
}

proc ::sfx::log_timing {label snap} {
    ::sfx::log [format "TIMING  %-10s all  WNS %-12s WHS %s" $label \
        [::sfx::fmt_slack [dict get $snap all_setup]]  [::sfx::fmt_slack [dict get $snap all_hold]]]
    ::sfx::log [format "TIMING  %-10s core WNS %-12s WHS %s" $label \
        [::sfx::fmt_slack [dict get $snap core_setup]] [::sfx::fmt_slack [dict get $snap core_hold]]]
    ::sfx::log [format "TIMING  %-10s in   WNS %-12s WHS %s" $label \
        [::sfx::fmt_slack [dict get $snap in_setup]]   [::sfx::fmt_slack [dict get $snap in_hold]]]
    ::sfx::log [format "TIMING  %-10s out  WNS %-12s WHS %s" $label \
        [::sfx::fmt_slack [dict get $snap out_setup]]  [::sfx::fmt_slack [dict get $snap out_hold]]]
}

proc ::sfx::port_groups {ports} {
    array set g {}
    foreach p $ports {
        set base $p
        regsub {\[[0-9]+\]$} $p {[*]} base
        if {[info exists g($base)]} {
            incr g($base)
        } else {
            set g($base) 1
        }
    }
    set out {}
    foreach b [lsort [array names g]] {
        lappend out [expr {$g($b) > 1 ? "$b ($g($b))" : $b}]
    }
    return [join $out ", "]
}

proc ::sfx::io_audit {} {
    set unplaced {}
    set nostd {}
    foreach p [get_ports -quiet] {
        if {[get_property PACKAGE_PIN $p] eq ""} {
            lappend unplaced $p
        }
        set std [get_property IOSTANDARD $p]
        if {$std eq "" || $std eq "DEFAULT"} {
            lappend nostd $p
        }
    }
    return [list $unplaced $nostd]
}

proc ::sfx::unrouted_nets {} {
    return [get_nets -quiet -hierarchical \
        -filter {ROUTE_STATUS == UNROUTED || ROUTE_STATUS == PARTIAL || ROUTE_STATUS == CONFLICTS}]
}

proc ::sfx::util_metric {pattern} {
    if {[catch {report_utilization -return_string} txt]} {
        return "n/a"
    }
    if {[regexp "\\|\\s*${pattern}\\s*\\|\\s*(\[0-9.\]+)\\s*\\|" $txt -> v]} {
        return $v
    }
    return "n/a"
}

proc ::sfx::standard_reports {dir tag} {
    variable cfg
    set p [file join $dir $cfg(name)_$tag]
    ::sfx::rpt 1 ${p}_utilization.rpt  { report_utilization -file ${p}_utilization.rpt }
    ::sfx::rpt 0 ${p}_utilization_hier.rpt { report_utilization -hierarchical -file ${p}_utilization_hier.rpt }
    ::sfx::rpt 1 ${p}_timing_summary.rpt {
        report_timing_summary -delay_type min_max -max_paths 20 -report_unconstrained \
            -check_timing_verbose -input_pins -file ${p}_timing_summary.rpt
    }
    ::sfx::rpt 0 ${p}_wns_setup.rpt {
        report_timing -delay_type max -max_paths 50 -nworst 1 -sort_by slack \
            -input_pins -file ${p}_wns_setup.rpt
    }
    ::sfx::rpt 0 ${p}_whs_hold.rpt {
        report_timing -delay_type min -max_paths 50 -nworst 1 -sort_by slack \
            -input_pins -file ${p}_whs_hold.rpt
    }
}

proc ::sfx::finish {} {
    variable cfg
    variable t_start
    variable logfh
    set s [list \
        "design        : $cfg(top) on $cfg(part)" \
        "vivado        : [version -short]" \
        "stop_after    : $cfg(stop_after)" \
        "timing_gate   : $cfg(gate)" \
        "elapsed       : [::sfx::elapsed [expr {[clock seconds] - $t_start}]]"]
    if {[info exists cfg(util_synth)]} {
        lappend s "util_synth    : [join $cfg(util_synth) { }]"
    }
    if {[info exists cfg(util_impl)]} {
        lappend s "util_impl     : [join $cfg(util_impl) { }]"
    }
    if {[info exists cfg(timing)]} {
        foreach k {all_setup all_hold core_setup core_hold in_setup in_hold out_setup out_hold} {
            lappend s [format "%-14s: %s" $k [::sfx::fmt_slack [dict get $cfg(timing) $k]]]
        }
    }
    if {[info exists cfg(bitfile)]} {
        lappend s "bitstream     : $cfg(bitfile)"
    }
    lappend s "checkpoints   : $cfg(dcp)" "reports       : $cfg(rpt)"
    ::sfx::write_text [file join $cfg(build_dir) $cfg(name)_summary.txt] "[join $s \n]\n"
    foreach l $s {
        ::sfx::log "SUMMARY $l"
    }
    ::sfx::log "DONE    $cfg(name) flow completed successfully"
    if {$logfh ne ""} {
        close $logfh
        set logfh ""
    }
}

# =============================================================================
# Flow
# =============================================================================

upvar #0 ::sfx::cfg cfg

::sfx::stage configure {
    ::sfx::parse_args $::argv

    set cfg(name)       silicaflux_fpga
    set cfg(script_dir) [file dirname [file normalize [info script]]]
    set cfg(top)        [::sfx::opt TOP  silicaflux_top]
    set cfg(part)       [::sfx::opt PART xc7a100tcsg324-1]
    set cfg(jobs)       [::sfx::opt JOBS 4]
    set cfg(stop_after) [::sfx::opt_enum STOP_AFTER bitstream {synth impl bitstream}]
    set cfg(gate)       [::sfx::opt_enum TIMING_GATE core {core all none}]
    set cfg(board_tim)  [::sfx::opt_enum BOARD_XDC_TIMING strip {strip keep}]
    set cfg(retiming)   [::sfx::opt_bool RETIMING 0]
    set cfg(power_opt)  [::sfx::opt_bool POWER_OPT 1]
    set cfg(allow_cw)   [::sfx::opt_bool ALLOW_CRITICAL_WARNINGS 0]
    set cfg(allow_latch) [::sfx::opt_bool ALLOW_LATCHES 0]
    set cfg(allow_io)   [::sfx::opt_bool ALLOW_UNCONSTRAINED_IO 0]

    set cfg(dir_synth)    [::sfx::opt SYNTH_DIRECTIVE              Default]
    set cfg(dir_opt)      [::sfx::opt OPT_DIRECTIVE                Explore]
    set cfg(dir_place)    [::sfx::opt PLACE_DIRECTIVE              Explore]
    set cfg(dir_physopt)  [::sfx::opt PHYS_OPT_DIRECTIVE           Explore]
    set cfg(dir_route)    [::sfx::opt ROUTE_DIRECTIVE              Explore]
    set cfg(dir_prphys)   [::sfx::opt POST_ROUTE_PHYS_OPT_DIRECTIVE AggressiveExplore]

    if {![string is integer -strict $cfg(jobs)] || $cfg(jobs) < 1 || $cfg(jobs) > 32} {
        ::sfx::fail configure "JOBS must be an integer in 1..32, got '$cfg(jobs)'"
    }

    set rtl [::sfx::opt RTL_DIR ""]
    set cfg(rtl_dir) [expr {$rtl ne "" ? [file normalize $rtl] : [::sfx::find_rtl_dir $cfg(script_dir)]}]
    if {$cfg(rtl_dir) eq "" || ![file isdirectory $cfg(rtl_dir)]} {
        ::sfx::fail configure "RTL directory not found (set RTL_DIR=<dir containing silicaflux_top.sf>)"
    }

    set sdc [::sfx::opt SDC ""]
    set cfg(sdc) [::sfx::first_file [expr {$sdc ne "" ? [list $sdc] : [list \
        [file join $cfg(script_dir) silicaflux.sdc] \
        [file join $cfg(script_dir) .. silicaflux.sdc] \
        [file join $cfg(rtl_dir) .. synth silicaflux.sdc] \
        [file join $cfg(rtl_dir) silicaflux.sdc]]}]]
    if {$cfg(sdc) eq ""} {
        ::sfx::fail configure "silicaflux.sdc not found (set SDC=<path>)"
    }

    set xdc [::sfx::opt XDC ""]
    if {$xdc ne ""} {
        set cfg(xdc) [::sfx::first_file [list $xdc]]
        if {$cfg(xdc) eq ""} {
            ::sfx::fail configure "board XDC '$xdc' not found"
        }
    } else {
        set cfg(xdc) [::sfx::first_file [list \
            [file join $cfg(script_dir) silicaflux_arty.xdc] \
            [file join $cfg(rtl_dir) .. synth vivado silicaflux_arty.xdc]]]
    }

    set bd [::sfx::opt BUILD_DIR ""]
    set cfg(build_dir) [file normalize [expr {$bd ne "" ? $bd : [file join $cfg(script_dir) build $cfg(name)]}]]
    ::sfx::prepare_build_dir $cfg(build_dir)
    foreach {k sub} {rpt reports dcp checkpoints net netlist bit bitstream xdcdir constraints} {
        set cfg($k) [file join $cfg(build_dir) $sub]
    }
    set ::sfx::logfh [open [file join $cfg(build_dir) $cfg(name)_flow.log] w]

    ::sfx::log "Vivado      : [version -short]"
    ::sfx::log "Part / top  : $cfg(part) / $cfg(top)"
    ::sfx::log "RTL         : $cfg(rtl_dir)"
    ::sfx::log "SDC         : $cfg(sdc)"
    ::sfx::log "Board XDC   : [expr {$cfg(xdc) ne {} ? $cfg(xdc) : {(none)}}]"
    ::sfx::log "Build       : $cfg(build_dir)"
    ::sfx::log "Flow        : stop_after=$cfg(stop_after) gate=$cfg(gate) retiming=$cfg(retiming) power_opt=$cfg(power_opt) jobs=$cfg(jobs)"
    ::sfx::log "Directives  : synth=$cfg(dir_synth) opt=$cfg(dir_opt) place=$cfg(dir_place) phys_opt=$cfg(dir_physopt) route=$cfg(dir_route) post_route_phys_opt=$cfg(dir_prphys)"
}

::sfx::stage sources {
    set cfg(sources) {}
    set cfg(sf_sources) {}
    set missing {}
    foreach m $::sfx::source_modules {
        set f [::sfx::find_source $cfg(rtl_dir) $m]
        if {$f eq ""} {
            lappend missing "$m.sf|.sv"
            continue
        }
        lappend cfg(sources) $f
        if {[file extension $f] eq ".sf"} {
            lappend cfg(sf_sources) $f
        }
        ::sfx::log "source      : [file tail $f]"
    }
    if {[llength $missing] > 0} {
        ::sfx::fail sources "missing RTL in $cfg(rtl_dir): [join $missing {, }]"
    }
    set bad [::sfx::unresolved_includes $cfg(sources) [list $cfg(rtl_dir)]]
    if {[llength $bad] > 0} {
        ::sfx::fail sources "unresolved `include directives: [join $bad {; }]"
    }
    set pkg [lindex $cfg(sources) 0]
    set cfg(num_tiles) [::sfx::pkg_param $pkg NUM_TILES]
    set rows [::sfx::pkg_param $pkg NOC_ROWS]
    set cols [::sfx::pkg_param $pkg NOC_COLS]
    set cfg(num_routers) [expr {$rows ne "" && $cols ne "" ? $rows * $cols : ""}]
}

::sfx::stage project {
    set_param general.maxThreads $cfg(jobs)
    if {[llength [get_parts -quiet $cfg(part)]] == 0} {
        ::sfx::fail project "part $cfg(part) is not installed in this Vivado"
    }
    create_project -in_memory -part $cfg(part)
    set_property target_language Verilog [current_project]
    set_property default_lib xil_defaultlib [current_project]
    set bps [lsort [get_board_parts -quiet {digilentinc.com:arty-a7-100:*}]]
    if {[llength $bps] > 0} {
        set_property board_part [lindex $bps end] [current_project]
        ::sfx::log "board part  : [lindex $bps end]"
    } else {
        ::sfx::log "board part  : Digilent board files not installed - using bare part $cfg(part)"
    }
}

::sfx::stage read_rtl {
    read_verilog -library xil_defaultlib -sv $cfg(sources)
    foreach f $cfg(sf_sources) {
        set fo [get_files -quiet $f]
        if {[llength $fo] == 0} {
            ::sfx::fail read_rtl "source $f not registered in the project"
        }
        set_property FILE_TYPE SystemVerilog $fo
    }
    foreach f $cfg(sources) {
        set ft [get_property FILE_TYPE [get_files -quiet $f]]
        if {$ft ne "SystemVerilog"} {
            ::sfx::fail read_rtl "[file tail $f] has FILE_TYPE '$ft', expected SystemVerilog"
        }
    }
    ::sfx::log "read [llength $cfg(sources)] RTL files ([llength $cfg(sf_sources)] .sf retyped to SystemVerilog)"
}

::sfx::stage elaborate {
    synth_design -rtl -name rtl_1 -top $cfg(top) -part $cfg(part) -include_dirs [list $cfg(rtl_dir)]

    array set census [::sfx::module_census]
    set bb [get_cells -quiet -hierarchical -filter {IS_BLACKBOX == 1}]
    if {[llength $bb] > 0} {
        ::sfx::fail elaborate "black-box instances after elaboration: [join $bb {, }]"
    }
    set absent {}
    foreach m $::sfx::required_modules {
        set n [expr {[info exists census($m)] ? $census($m) : 0}]
        ::sfx::log [format "hierarchy   : %-18s x%d" $m $n]
        if {$n == 0} {
            lappend absent $m
        }
    }
    if {[llength $absent] > 0} {
        ::sfx::fail elaborate "modules not instantiated under $cfg(top): [join $absent {, }]"
    }
    set expect {}
    if {$cfg(num_tiles) ne ""} {
        lappend expect compute_tile $cfg(num_tiles) vector_engine $cfg(num_tiles) \
                       tensor_unit $cfg(num_tiles) memory_controller [expr {$cfg(num_tiles) + 1}]
    }
    if {$cfg(num_routers) ne ""} {
        lappend expect noc_router $cfg(num_routers)
    }
    foreach {m n} $expect {
        if {$census($m) != $n} {
            ::sfx::fail elaborate "expected $n x $m (from silicaflux_pkg), found $census($m)"
        }
    }
    foreach m $::sfx::source_modules {
        if {$m ne "silicaflux_pkg" && $m ne $cfg(top) && ![info exists census($m)]} {
            ::sfx::log "hierarchy   : $m is not instantiated by $cfg(top) (library module, not synthesized)"
        }
    }
    set cfg(census_rtl) [array get census]
    close_design
    ::sfx::check_critical_warnings elaborate
}

::sfx::stage constraints {
    set cfg(xdc_sdc) [file join $cfg(xdcdir) $cfg(name)_sdc.xdc]
    lassign [::sfx::filter_constraints $cfg(sdc) $cfg(xdc_sdc) $::sfx::asic_only_sdc_cmds \
        "silicaflux.sdc for Vivado: ASIC-only electrical/DRV commands retained as comments"] kept dropped
    ::sfx::log "SDC         : $kept constraint(s) applied, [llength $dropped] ASIC-only not applicable to FPGA ([join [lsort -unique $dropped] {, }])"
    set cfg(xdc_files) [list $cfg(xdc_sdc)]

    if {$cfg(xdc) ne ""} {
        set cfg(xdc_board) [file join $cfg(xdcdir) $cfg(name)_board.xdc]
        if {$cfg(board_tim) eq "strip"} {
            lassign [::sfx::filter_constraints $cfg(xdc) $cfg(xdc_board) $::sfx::timing_cmds \
                "board XDC, physical constraints only (timing owned by silicaflux.sdc)"] bkept bdropped
            ::sfx::log "board XDC   : $bkept physical constraint(s), [llength $bdropped] timing command(s) superseded by silicaflux.sdc"
        } else {
            file copy -force $cfg(xdc) $cfg(xdc_board)
            ::sfx::log "board XDC   : used verbatim (BOARD_XDC_TIMING=keep)"
        }
        lappend cfg(xdc_files) $cfg(xdc_board)
    } else {
        ::sfx::log "board XDC   : none - pin mapping must be supplied before bitstream generation"
    }

    set cfg(xdc_impl) [file join $cfg(xdcdir) $cfg(name)_impl.xdc]
    ::sfx::write_text $cfg(xdc_impl) [join [list \
        "# FPGA implementation properties for SilicaFlux synchronisers" \
        "set_property ASYNC_REG TRUE \[get_cells -hierarchical {*phy_rx_valid_s1_reg* *phy_rx_valid_sync_reg* *phy_rx_data_s1_reg* *phy_rx_data_sync_reg*}\]" \
        ""] \n]
    lappend cfg(xdc_files) $cfg(xdc_impl)

    foreach x $cfg(xdc_files) {
        read_xdc $x
    }
}

::sfx::stage synthesize {
    set synth_args [list -top $cfg(top) -part $cfg(part) -include_dirs [list $cfg(rtl_dir)] \
        -directive $cfg(dir_synth) -flatten_hierarchy rebuilt -fsm_extraction auto \
        -resource_sharing auto -keep_equivalent_registers]
    if {$cfg(retiming)} {
        lappend synth_args -retiming
    }
    ::sfx::log "synth_design [join $synth_args { }]"
    synth_design {*}$synth_args
    ::sfx::check_critical_warnings synthesize
}

::sfx::stage post_synth_checks {
    set clks [get_clocks -quiet clk]
    if {[llength $clks] != 1} {
        ::sfx::fail post_synth_checks "primary clock 'clk' from silicaflux.sdc was not created"
    }
    set per [get_property PERIOD $clks]
    if {abs($per - 10.0) > 1e-6} {
        ::sfx::fail post_synth_checks "clock 'clk' period is $per ns, expected 10.000 ns"
    }
    ::sfx::log "clock       : clk period $per ns on [get_property SOURCE_PINS $clks]"

    lassign [::sfx::audit_constraints [list $cfg(xdc_sdc)]] checked empty partial
    if {[llength $empty] > 0} {
        ::sfx::fail post_synth_checks "SDC object queries resolve to nothing (constraint would be dropped): [join $empty {; }]"
    }
    ::sfx::log "SDC audit   : $checked object queries resolved"
    foreach p $partial {
        ::sfx::log "SDC audit   : pattern matched no cells after synthesis (logic pruned as unobservable): $p"
    }

    set latches [get_cells -quiet -hierarchical -filter {REF_NAME =~ LD*}]
    if {[llength $latches] > 0} {
        if {$cfg(allow_latch)} {
            ::sfx::log "WARN    [llength $latches] latch(es) inferred (ALLOW_LATCHES=1)"
        } else {
            ::sfx::fail post_synth_checks "[llength $latches] latch(es) inferred, e.g. [lindex $latches 0]"
        }
    }

    array set elab $cfg(census_rtl)
    array set kept [::sfx::module_census]
    foreach m $::sfx::required_modules {
        set n [expr {[info exists kept($m)] ? $kept($m) : 0}]
        if {$n < $elab($m)} {
            ::sfx::log "WARN    $m: $elab($m) instance(s) elaborated, $n retained after synthesis (unobservable logic pruned)"
        }
    }

    lassign [::sfx::io_audit] cfg(io_unplaced) cfg(io_nostd)
    if {[llength $cfg(io_unplaced)] > 0} {
        ::sfx::log "WARN    [llength $cfg(io_unplaced)] port(s) without PACKAGE_PIN: [::sfx::port_groups $cfg(io_unplaced)]"
    }
    if {[llength $cfg(io_nostd)] > 0} {
        ::sfx::log "WARN    [llength $cfg(io_nostd)] port(s) without IOSTANDARD: [::sfx::port_groups $cfg(io_nostd)]"
    }

    group_path -name sfx_in2reg  -from [all_inputs]
    group_path -name sfx_reg2out -to   [all_outputs]

    set d [file join $cfg(rpt) 02_synth]
    file mkdir $d
    write_checkpoint -force [file join $cfg(dcp) $cfg(name)_post_synth.dcp]
    write_verilog -force -mode funcsim [file join $cfg(net) $cfg(name)_post_synth_funcsim.v]
    ::sfx::standard_reports $d post_synth
    set p [file join $d $cfg(name)_post_synth]
    ::sfx::rpt 1 ${p}_check_timing.rpt     { check_timing -verbose -file ${p}_check_timing.rpt }
    ::sfx::rpt 0 ${p}_clocks.rpt           { report_clocks -file ${p}_clocks.rpt }
    ::sfx::rpt 0 ${p}_exceptions.rpt       { report_exceptions -file ${p}_exceptions.rpt }
    ::sfx::rpt 0 ${p}_exceptions_ignored.rpt { report_exceptions -ignored -file ${p}_exceptions_ignored.rpt }
    ::sfx::rpt 0 ${p}_control_sets.rpt     { report_control_sets -verbose -file ${p}_control_sets.rpt }
    set cfg(util_synth) [list LUT [::sfx::util_metric {Slice LUTs\*?}] FF [::sfx::util_metric {Slice Registers}] \
                              BRAM [::sfx::util_metric {Block RAM Tile}] DSP [::sfx::util_metric DSPs]]
    ::sfx::log "utilization : post-synth [join $cfg(util_synth) { }]"
    ::sfx::log_timing post_synth [::sfx::timing_snapshot]
    ::sfx::check_critical_warnings post_synth_checks
}

if {$cfg(stop_after) eq "synth"} {
    ::sfx::finish
    return
}

::sfx::stage optimize {
    opt_design -directive $cfg(dir_opt)
    if {$cfg(power_opt)} {
        power_opt_design
    }
    write_checkpoint -force [file join $cfg(dcp) $cfg(name)_post_opt.dcp]
    set d [file join $cfg(rpt) 03_opt]
    file mkdir $d
    ::sfx::rpt 0 [file join $d drc.rpt] { report_drc -file [file join $d $cfg(name)_post_opt_drc.rpt] }
    ::sfx::check_critical_warnings optimize
}

::sfx::stage place {
    place_design -directive $cfg(dir_place)
    set d [file join $cfg(rpt) 04_place]
    file mkdir $d
    ::sfx::rpt 0 congestion.rpt { report_design_analysis -congestion -file [file join $d $cfg(name)_post_place_congestion.rpt] }
    ::sfx::rpt 0 clock_util.rpt { report_clock_utilization -file [file join $d $cfg(name)_post_place_clock_utilization.rpt] }
    ::sfx::rpt 1 util.rpt       { report_utilization -file [file join $d $cfg(name)_post_place_utilization.rpt] }
    phys_opt_design -directive $cfg(dir_physopt)
    write_checkpoint -force [file join $cfg(dcp) $cfg(name)_post_place.dcp]
    ::sfx::log_timing post_place [::sfx::timing_snapshot]
    ::sfx::check_critical_warnings place
}

::sfx::stage route {
    route_design -directive $cfg(dir_route)
    set bad [::sfx::unrouted_nets]
    if {[llength $bad] > 0} {
        ::sfx::fail route "[llength $bad] net(s) unrouted or with routing conflicts, e.g. [lindex $bad 0]"
    }
    set wns [::sfx::worst_slack max]
    if {$wns ne "" && $wns < 0.0} {
        ::sfx::log "post-route setup WNS [::sfx::fmt_slack $wns] - running post-route phys_opt_design"
        phys_opt_design -directive $cfg(dir_prphys)
        set bad [::sfx::unrouted_nets]
        if {[llength $bad] > 0} {
            ::sfx::fail route "post-route phys_opt left [llength $bad] net(s) unrouted"
        }
    }
    write_checkpoint -force [file join $cfg(dcp) $cfg(name)_post_route.dcp]
    ::sfx::check_critical_warnings route
}

::sfx::stage signoff_reports {
    set d [file join $cfg(rpt) 05_route]
    file mkdir $d
    ::sfx::standard_reports $d post_route
    set p [file join $d $cfg(name)_post_route]
    ::sfx::rpt 1 ${p}_route_status.rpt      { report_route_status -file ${p}_route_status.rpt }
    ::sfx::rpt 1 ${p}_drc.rpt               { report_drc -file ${p}_drc.rpt }
    ::sfx::rpt 0 ${p}_power.rpt             { report_power -file ${p}_power.rpt }
    ::sfx::rpt 0 ${p}_methodology.rpt       { report_methodology -file ${p}_methodology.rpt }
    ::sfx::rpt 0 ${p}_clock_interaction.rpt { report_clock_interaction -delay_type min_max -file ${p}_clock_interaction.rpt }
    ::sfx::rpt 0 ${p}_cdc.rpt               { report_cdc -details -file ${p}_cdc.rpt }
    ::sfx::rpt 0 ${p}_io.rpt                { report_io -file ${p}_io.rpt }
    ::sfx::rpt 0 ${p}_congestion.rpt        { report_design_analysis -congestion -file ${p}_congestion.rpt }
    ::sfx::rpt 0 ${p}_exceptions.rpt        { report_exceptions -file ${p}_exceptions.rpt }
    write_xdc -force [file join $cfg(xdcdir) $cfg(name)_post_route_applied.xdc]
    write_verilog -force -mode funcsim [file join $cfg(net) $cfg(name)_post_route_funcsim.v]
    set cfg(util_impl) [list LUT [::sfx::util_metric {Slice LUTs\*?}] FF [::sfx::util_metric {Slice Registers}] \
                             BRAM [::sfx::util_metric {Block RAM Tile}] DSP [::sfx::util_metric DSPs]]
    ::sfx::log "utilization : post-route [join $cfg(util_impl) { }]"
}

::sfx::stage timing_gate {
    set cfg(timing) [::sfx::timing_snapshot]
    ::sfx::log_timing post_route $cfg(timing)
    set t $cfg(timing)
    switch -- $cfg(gate) {
        core {
            set ok [expr {[::sfx::slack_ok [dict get $t core_setup]] && [::sfx::slack_ok [dict get $t core_hold]]}]
            if {$ok && !([::sfx::slack_ok [dict get $t all_setup]] && [::sfx::slack_ok [dict get $t all_hold]])} {
                ::sfx::log "WARN    board I/O paths miss the silicaflux.sdc boundary budget (in WNS [::sfx::fmt_slack [dict get $t in_setup]], out WNS [::sfx::fmt_slack [dict get $t out_setup]]); core timing is closed"
            }
        }
        all {
            set ok [expr {[::sfx::slack_ok [dict get $t all_setup]] && [::sfx::slack_ok [dict get $t all_hold]]}]
        }
        none {
            set ok 1
            ::sfx::log "WARN    timing gate disabled (TIMING_GATE=none)"
        }
    }
    if {!$ok} {
        ::sfx::fail timing_gate "timing not closed at 100 MHz (gate=$cfg(gate)): see [file join $cfg(rpt) 05_route]"
    }
    ::sfx::log "timing gate : PASS ($cfg(gate))"
}

if {$cfg(stop_after) eq "impl"} {
    ::sfx::finish
    return
}

::sfx::stage bitstream {
    set unplaced $cfg(io_unplaced)
    set nostd    $cfg(io_nostd)
    if {[llength $unplaced] > 0 || [llength $nostd] > 0} {
        set what "[llength $unplaced] port(s) without PACKAGE_PIN, [llength $nostd] without IOSTANDARD: [::sfx::port_groups [lsort -unique [concat $unplaced $nostd]]]"
        if {!$cfg(allow_io)} {
            ::sfx::fail bitstream "incomplete Arty A7 pin mapping - $what. Supply a complete XDC (XDC=<file>) or a board wrapper"
        }
        ::sfx::log "WARN    ALLOW_UNCONSTRAINED_IO=1: $what - pins auto-assigned, DO NOT load this bitstream on hardware"
        set_property SEVERITY {Warning} [get_drc_checks {NSTD-1 UCIO-1}]
    }
    foreach {prop val} {CFGBVS VCCO CONFIG_VOLTAGE 3.3} {
        if {[get_property $prop [current_design]] eq ""} {
            set_property $prop $val [current_design]
        }
    }
    set d [file join $cfg(rpt) 06_bitstream]
    file mkdir $d
    ::sfx::rpt 1 drc.rpt { report_drc -file [file join $d $cfg(name)_pre_bitstream_drc.rpt] }
    set cfg(bitfile) [file join $cfg(bit) $cfg(name).bit]
    write_bitstream -force $cfg(bitfile)
    if {![file isfile $cfg(bitfile)] || [file size $cfg(bitfile)] == 0} {
        ::sfx::fail bitstream "write_bitstream reported success but $cfg(bitfile) is missing or empty"
    }
    ::sfx::log "bitstream   : $cfg(bitfile) ([file size $cfg(bitfile)] bytes)"
    ::sfx::check_critical_warnings bitstream
}

::sfx::finish
