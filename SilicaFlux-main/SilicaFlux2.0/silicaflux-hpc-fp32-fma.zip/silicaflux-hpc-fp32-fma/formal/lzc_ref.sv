// Specification model for formal/lzc_equiv.ys: the obvious priority loop.
// Not used in the design. cnt = number of leading zeros, W when x == 0.
`default_nettype none
module lzc_ref #(
  parameter int W  = 24,
  parameter int CW = 5
) (
  input  wire logic [W-1:0]  x,
  output logic      [CW-1:0] cnt,
  output logic               zero
);
  always_comb begin
    cnt = W;
    for (int i = 0; i < W; i++)
      if (x[i]) cnt = W - 1 - i;   // last (most significant) one wins
  end
  assign zero = (x == '0);
endmodule
`default_nettype wire
