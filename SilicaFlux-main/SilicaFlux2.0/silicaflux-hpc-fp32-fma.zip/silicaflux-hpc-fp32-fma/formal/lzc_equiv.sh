#!/usr/bin/env bash
# Combinational equivalence proof: rtl/fp32_fma_lzc.sv (log-depth tree) versus
# formal/lzc_ref.sv (priority loop), for every width the datapath instantiates
# (W=24 multiplicand pre-normalisation, W=75 sum normalisation), plus a few
# extra widths that exercise the padding logic. Uses Yosys miter + SAT: the
# proof covers all 2^W inputs, not a sample.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/formal"; mkdir -p "$OUT"
LOG="$OUT/lzc_equiv.log"; : > "$LOG"
pass=0; fail=0
for wc in "24 5" "75 7" "31 5" "8 4" "63 6"; do
  set -- $wc; W=$1; CW=$2
  if yosys -q -l "$OUT/lzc_equiv_W$W.log" -p "
      read_verilog -sv $ROOT/rtl/fp32_fma_lzc.sv;
      read_verilog -sv $ROOT/formal/lzc_ref.sv;
      chparam -set W $W -set CW $CW fp32_fma_lzc lzc_ref;
      hierarchy -check; proc; flatten; opt_clean;
      miter -equiv -flatten -make_assert fp32_fma_lzc lzc_ref miter;
      hierarchy -top miter;
      sat -verify -prove-asserts -show-ports -set-def-inputs miter" >/dev/null 2>&1; then
    echo "lzc W=$W CW=$CW: equivalent to priority-loop spec (SAT proof, all 2^$W inputs) PASS" | tee -a "$LOG"
    pass=$((pass+1))
  else
    echo "lzc W=$W CW=$CW: NOT equivalent -- see $OUT/lzc_equiv_W$W.log FAIL" | tee -a "$LOG"
    fail=$((fail+1))
  fi
done
echo "lzc equivalence: $pass passed, $fail failed" | tee -a "$LOG"
[ "$fail" = 0 ]
