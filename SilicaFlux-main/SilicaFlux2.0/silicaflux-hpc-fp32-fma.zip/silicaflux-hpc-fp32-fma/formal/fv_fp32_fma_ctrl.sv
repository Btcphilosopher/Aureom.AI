// =============================================================================
// Formal harness: fp32_fma pipeline control (read with `read_verilog -formal`)
//
// The real fp32_fma top is instantiated; the arithmetic step modules are
// replaced by unconstrained cut points (formal/run_ctrl.sh), so the proof
// covers the actual handshake, stage registers, tag path and reset for any
// datapath values.
//
// The environment issues tags equal to the issue sequence number (mod 16;
// at most 6 operations are ever outstanding, so the number is unambiguous).
// Properties:
//   P1 in-order, no loss, no duplication : every delivered tag equals the
//      delivery sequence number
//   P2 occupancy                         : outstanding operations <= LATENCY
//   P3 stability                         : stalled output keeps valid and
//      payload (result, flags, tag)
//   P4 no stall without back-pressure    : out_ready -> in_ready
//   P5 exact latency                     : an operation accepted in cycle t
//      is presented in cycle t+LATENCY when out_ready was high in between
//   P6 reset                             : while rst_n is low, out_valid = 0
//      and in_ready = 1; nothing accepted before a reset is delivered after it
//      (P1 with the sequence counters cleared by reset)
// Proof status: bounded (BMC from reset, depth 16 by default, every input
// sequence) -- see formal/run_ctrl.sh. k-induction does not close without
// strengthening invariants on the internal stage tags (not written).
// =============================================================================
`default_nettype none

module fv_fp32_fma_ctrl #(
  parameter bit [4:0] PIPE_CFG = 5'b11110
) (
  input wire logic        clk,
  input wire logic        rst_n,
  input wire logic        in_valid,
  input wire logic        out_ready,
  input wire logic [31:0] in_a,
  input wire logic [31:0] in_b,
  input wire logic [31:0] in_c,
  input wire logic [2:0]  in_rm
);
  localparam int LAT = 1 + PIPE_CFG[0] + PIPE_CFG[1] + PIPE_CFG[2] + PIPE_CFG[3] + PIPE_CFG[4];

  logic        in_ready, out_valid;
  logic [31:0] out_result;
  logic [4:0]  out_flags;
  logic [3:0]  out_tag, in_seq, out_seq;
  logic [3:0]  outstanding;

  fp32_fma #(.TAG_W(4), .PIPE_CFG(PIPE_CFG)) dut (
    .clk(clk), .rst_n(rst_n),
    .in_valid(in_valid), .in_ready(in_ready), .in_a(in_a), .in_b(in_b), .in_c(in_c),
    .in_rm(in_rm), .in_tag(in_seq),
    .out_valid(out_valid), .out_ready(out_ready), .out_result(out_result),
    .out_flags(out_flags), .out_tag(out_tag));

  wire in_fire  = in_valid && in_ready;
  wire out_fire = out_valid && out_ready;

  // the formal run starts in reset
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  always @(posedge clk) begin
    if (!rst_n) begin
      in_seq <= 4'd0;
      out_seq <= 4'd0;
      outstanding <= 4'd0;
    end else begin
      if (in_fire)  in_seq  <= in_seq + 4'd1;
      if (out_fire) out_seq <= out_seq + 4'd1;
      outstanding <= outstanding + {3'd0, in_fire} - {3'd0, out_fire};
    end
  end

  // history for P5
  reg [7:0] fire_h, rdy_h, rst_h;
  reg [3:0] tag_h [0:7];
  integer i;
  always @(posedge clk) begin
    fire_h <= {fire_h[6:0], in_fire && rst_n};
    rdy_h  <= {rdy_h[6:0], out_ready};
    rst_h  <= {rst_h[6:0], !rst_n};
    tag_h[0] <= in_seq;
    for (i = 1; i < 8; i = i + 1) tag_h[i] <= tag_h[i-1];
  end

  // hold the presented request stable until accepted (environment rule)
  reg       prev_pending;
  always @(posedge clk) prev_pending <= in_valid && !in_ready && rst_n;
  always @(*) if (!init && prev_pending && rst_n) assume (in_valid);

  always @(*) begin
    if (!init) begin
      // P6 (combinational part): asynchronous reset empties the pipeline
      if (!rst_n) begin
        assert (!out_valid);
        assert (in_ready);
      end
      // P4
      if (out_ready) assert (in_ready);
      if (rst_n) begin
        // P1
        if (out_valid) assert (out_tag == out_seq);
        // P2
        assert (outstanding <= LAT);
      end
    end
  end

  always @(posedge clk) begin
    if (!init && !$past(init) && rst_n && $past(rst_n)) begin
      // P3
      if ($past(out_valid && !out_ready)) begin
        assert (out_valid);
        assert (out_tag == $past(out_tag));
        assert (out_result == $past(out_result));
        assert (out_flags == $past(out_flags));
      end
    end
  end

  // P5: accepted LAT cycles ago, out_ready high for the LAT-1 cycles in
  // between, no reset in the window -> presented now with that tag
  wire [7:0] win = (8'd1 << LAT) - 8'd1;           // LAT ones
  wire       window_ok = fire_h[LAT-1] && ((rdy_h & (win >> 1)) == (win >> 1)) &&
                         ((rst_h & win) == 8'd0);
  always @(*) begin
    if (!init && rst_n && window_ok) begin
      assert (out_valid);
      assert (out_tag == tag_h[LAT-1]);
    end
  end

  // reachability (guards against vacuous proofs)
  always @(posedge clk) begin
    if (!init && rst_n) begin
      cover (outstanding == LAT && !out_ready);         // full and stalled
      cover (out_fire && in_fire && outstanding == LAT); // full and streaming
      cover (out_fire && rst_h != 8'd0);                // delivery soon after a reset
    end
  end
endmodule

`default_nettype wire
