#!/usr/bin/env bash
# Formal verification of the fp32_fma pipeline control (formal/fv_fp32_fma_ctrl.sv)
# with Yosys + yosys-smtbmc + z3, for several PIPE_CFG values:
#   BMC        : all properties hold for every input sequence of DEPTH cycles
#                from reset (DEPTH=16 > 2 x max latency 6: covers every
#                fill / stall / drain / reset interleaving of that length)
#   induction  : k-induction attempt with a time limit (unbounded proof only
#                if it succeeds; reported as-is otherwise)
#   cover      : every cover goal is reachable (non-vacuity)
# The arithmetic step modules are cut points: their outputs are unconstrained.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/formal"; mkdir -p "$OUT"
DEPTH=${DEPTH:-16}
IND_DEPTH=${IND_DEPTH:-8}
IND_TIMEOUT=${IND_TIMEOUT:-600}
RTL=$(sed "s|^|$ROOT/rtl/|" "$ROOT/rtl/files.f" | tr '\n' ' ')
CUT="*/u_unpack_a */u_unpack_b */u_unpack_c */u_prep */u_mul */u_align */u_add */u_norm */u_round */u_except */u_pack"
SUM="$OUT/ctrl_summary.txt"
echo "# yosys $(yosys -V | awk '{print $2}'), yosys-smtbmc, solver: $(z3 --version)" > "$SUM"
rc=0
for cfg in ${CFGS:-11110 11111 00000 01010 10101}; do
  smt="$OUT/ctrl_$cfg.smt2"
  yosys -q -l "$OUT/ctrl_${cfg}_yosys.log" -p "
    read_verilog -sv $RTL
    read_verilog -sv -formal $ROOT/formal/fv_fp32_fma_ctrl.sv
    chparam -set PIPE_CFG $((2#$cfg)) fv_fp32_fma_ctrl
    hierarchy -check -top fv_fp32_fma_ctrl
    proc
    cutpoint $CUT
    flatten; async2sync; opt_clean; dffunmap
    write_smt2 -wires $smt" >/dev/null 2>&1 || { echo "PIPE_CFG=$cfg: yosys FAILED" | tee -a "$SUM"; rc=1; continue; }
  b=FAIL; i=FAIL; c=FAIL
  timeout 1800 yosys-smtbmc -s z3 --presat -t "$DEPTH" "$smt" > "$OUT/ctrl_${cfg}_bmc.log" 2>&1 && b=PASS
  timeout "$IND_TIMEOUT" yosys-smtbmc -s z3 -i -t "$IND_DEPTH" "$smt" > "$OUT/ctrl_${cfg}_induction.log" 2>&1 && i=PASS
  [ "$i" = FAIL ] && grep -q 'Status: FAILED' "$OUT/ctrl_${cfg}_induction.log" && i="FAIL(counterexample to induction)"
  [ "$i" = FAIL ] && i="not concluded (timeout ${IND_TIMEOUT}s)"
  timeout 1800 yosys-smtbmc -s z3 -c -t "$DEPTH" "$smt" > "$OUT/ctrl_${cfg}_cover.log" 2>&1 && c=PASS
  ncov=$(grep -c 'Reached cover statement' "$OUT/ctrl_${cfg}_cover.log")
  printf "PIPE_CFG=%s  BMC depth %s: %s   cover: %s (%s/3 goals reached)   k-induction (k=%s): %s\n" \
    "$cfg" "$DEPTH" "$b" "$c" "$ncov" "$IND_DEPTH" "$i" | tee -a "$SUM"
  [ $b = PASS ] && [ $c = PASS ] || rc=1
done
exit $rc
