// =============================================================================
// SilicaFlux-HPC :: Module 01 :: fp32_fma high-volume differential testbench
//
// Verilator C++ harness. Every operation accepted by the DUT is recomputed by
// Berkeley SoftFloat-3e f32_mulAdd (linked in-process through
// ref/fp32ref_shim.c; RISCV specialisation for NAN_PROPAGATE=0, ARM-VFPv2 for
// NAN_PROPAGATE=1) and the DUT output is compared bit-exactly: 32 result bits
// (NaNs included), 5 flags, and the tag.
//
// Stimulus sources
//   --random N        N biased random triples (deterministic, --seed)
//   --stdin           triples from testfloat_gen ("A B C ..." hex per line)
// Rounding: --rm R (0..7) or --rm all (each triple issued once per mode 0..4)
// Flow control: --pin P / --pout P  probability of in_valid / out_ready
//                                     per cycle (1.0 = no stalls)
// Reset:        --reset-every N      assert rst_n for 1..3 cycles at random
//                                     points (mean interval N cycles);
//                                     outstanding operations are expected to
//                                     be discarded, nothing stale may emerge
// Output:       --tfver               print "A B C RESULT FLAGS" lines for
//                                     testfloat_ver (only with a single --rm)
// Checks on every cycle
//   * output payload/tag stable while out_valid && !out_ready
//   * out_valid never drops without a handshake
//   * in-order delivery, tag match, bit-exact result and flags
//   * latency (accept -> deliver) and throughput statistics
// Exit status 0 only if every check passed.
// =============================================================================
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <memory>
#include <string>

#include "Vfp32_fma.h"
#include "verilated.h"

#ifndef CFG_TININESS_AFTER
#define CFG_TININESS_AFTER 1
#endif
#ifndef CFG_LATENCY
#error "CFG_LATENCY must be defined (1 + popcount(PIPE_CFG))"
#endif

extern "C" uint32_t fp32ref_fma(uint32_t a, uint32_t b, uint32_t c, unsigned rm,
                                unsigned tininess_after, unsigned *flags);
extern "C" const char *fp32ref_specialization(void);

// ---------------------------------------------------------------- PRNG
struct Rng {
  uint64_t s;
  explicit Rng(uint64_t seed) : s(seed ? seed : 0x9E3779B97F4A7C15ull) {}
  uint64_t next() {  // splitmix64
    uint64_t z = (s += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
  }
  uint32_t u32() { return (uint32_t)next(); }
  uint32_t range(uint32_t n) { return (uint32_t)(next() % n); }
  double uni() { return (next() >> 11) * (1.0 / 9007199254740992.0); }
};

static const uint32_t SPECIALS[] = {
  0x00000000, 0x80000000, 0x3F800000, 0xBF800000, 0x7F800000, 0xFF800000,
  0x7FC00000, 0xFFC00001, 0x7FA00000, 0xFF800001, 0x7F7FFFFF, 0xFF7FFFFF,
  0x00800000, 0x80800000, 0x007FFFFF, 0x00000001, 0x80000001, 0x00400000,
  0x3F7FFFFF, 0x3F800001, 0x7F000000, 0x01000000, 0x00800001, 0x7EFFFFFF};
static const int EXPS[] = {1, 2, 3, 24, 25, 26, 100, 126, 127, 128, 228, 252, 253, 254};

static uint32_t rand_operand(Rng &r) {
  double p = r.uni();
  uint32_t s = r.u32() & 0x80000000u;
  if (p < 0.10) return SPECIALS[r.range(sizeof(SPECIALS) / 4)];
  if (p < 0.25) return s | (1 + r.range((1u << 23) - 1));                    // subnormal
  if (p < 0.40) return s | ((uint32_t)EXPS[r.range(14)] << 23) | (r.u32() & 0x7FFFFF);
  if (p < 0.50) {                                                            // bit runs
    uint32_t e = 1 + r.range(254), k = r.range(24);
    uint32_t f = (r.u32() & 1) ? (0x7FFFFFu ^ ((1u << k) - 1)) : ((1u << k) - 1);
    return s | (e << 23) | (f & 0x7FFFFF);
  }
  if (p < 0.60) return s | ((64 + r.range(126)) << 23) | (r.u32() & 0x7FFFFF);
  return r.u32();
}

static void rand_triple(Rng &r, uint32_t &a, uint32_t &b, uint32_t &c) {
  a = rand_operand(r);
  b = rand_operand(r);
  double p = r.uni();
  int ea = (a >> 23) & 0xFF, eb = (b >> 23) & 0xFF;
  if (ea == 0) ea = 1;
  if (eb == 0) eb = 1;
  if (p < 0.25) {  // cancellation: addend ~ -(a*b)
    int ec = ea + eb - 127 + (int)r.range(5) - 2;
    if (ec >= 1 && ec <= 254) {
      uint32_t sp = (a ^ b) >> 31;
      c = ((sp ^ 1) << 31) | ((uint32_t)ec << 23) | (r.u32() & 0x7FFFFF);
      if (r.uni() < 0.3) {
        uint32_t keep = ~((1u << r.range(23)) - 1);
        c = (c & ~0x7FFFFFu) | (((a | b) & 0x7FFFFF) & keep);
      }
      return;
    }
  } else if (p < 0.35) {  // far alignment
    static const int D[] = {-60, -50, -49, -48, -26, -25, -24, 24, 25, 26, 27, 50};
    int ec = ea + eb - 127 + D[r.range(12)];
    if (ec >= 1 && ec <= 254) {
      c = (r.u32() & 0x80000000u) | ((uint32_t)ec << 23) | (r.u32() & 0x7FFFFF);
      return;
    }
  }
  c = rand_operand(r);
}

// ---------------------------------------------------------------- harness
struct Op {
  uint32_t a, b, c, tag;
  uint8_t rm;
  uint64_t t_accept;
};

struct Stats {
  uint64_t issued = 0, checked = 0, errors = 0, proto_errors = 0, resets = 0,
           discarded = 0, cycles = 0, lat_min = ~0ull, lat_max = 0, lat_sum = 0;
};

int main(int argc, char **argv) {
  uint64_t n_random = 0, seed = 1, reset_every = 0;
  bool from_stdin = false, tfver = false, rm_all = false, quiet = false;
  int rm_fixed = 0;
  double pin = 1.0, pout = 1.0;
  uint64_t max_err_print = 20;
  for (int i = 1; i < argc; i++) {
    std::string s = argv[i];
    auto nxt = [&]() { return std::string(i + 1 < argc ? argv[++i] : ""); };
    if (s == "--random") n_random = strtoull(nxt().c_str(), nullptr, 0);
    else if (s == "--stdin") from_stdin = true;
    else if (s == "--seed") seed = strtoull(nxt().c_str(), nullptr, 0);
    else if (s == "--rm") { std::string v = nxt(); if (v == "all") rm_all = true; else rm_fixed = atoi(v.c_str()); }
    else if (s == "--pin") pin = atof(nxt().c_str());
    else if (s == "--pout") pout = atof(nxt().c_str());
    else if (s == "--reset-every") reset_every = strtoull(nxt().c_str(), nullptr, 0);
    else if (s == "--tfver") tfver = true;
    else if (s == "--quiet") quiet = true;
    else if (s[0] == '+') continue;  // verilator plusargs
    else { fprintf(stderr, "unknown option %s\n", s.c_str()); return 2; }
  }
  if (tfver && rm_all) { fprintf(stderr, "--tfver needs a single --rm\n"); return 2; }

  Verilated::commandArgs(argc, argv);
  auto ctx = std::make_unique<VerilatedContext>();
  auto dut = std::make_unique<Vfp32_fma>(ctx.get());
  Rng rng(seed), flow(seed ^ 0xF10Full), rst_rng(seed ^ 0x5E5E7ull);

  const unsigned TAG_MASK = 0xFF;  // TAG_W = 8 in the regression builds
  std::deque<Op> expect;
  Stats st;

  // source of triples
  uint32_t cur_a = 0, cur_b = 0, cur_c = 0;
  int cur_rm_idx = 5;  // >= 5 forces a fetch of the next triple in rm_all mode
  bool have_triple = false, src_done = false;
  uint64_t produced_triples = 0;
  auto fetch_triple = [&]() -> bool {
    if (from_stdin) {
      char line[512];
      while (fgets(line, sizeof line, stdin)) {
        unsigned a, b, c;
        if (sscanf(line, "%x %x %x", &a, &b, &c) == 3) { cur_a = a; cur_b = b; cur_c = c; return true; }
      }
      return false;
    }
    if (produced_triples >= n_random) return false;
    rand_triple(rng, cur_a, cur_b, cur_c);
    produced_triples++;
    return true;
  };

  // presented transaction (held stable until accepted)
  bool presenting = false;
  Op pres{};
  uint32_t next_tag = 0;

  // previous-cycle output observation for the stability check
  bool prev_stall = false;
  uint32_t prev_res = 0, prev_flags = 0, prev_tag = 0;

  int reset_left = 0;
  bool shown = false;  // current transaction has been driven with in_valid=1
  dut->clk = 0;
  dut->rst_n = 0;
  dut->in_valid = 0;
  dut->out_ready = 0;
  dut->eval();
  dut->rst_n = 1;  // async reset pulse at time 0
  dut->eval();
  dut->rst_n = 0;
  for (int i = 0; i < 3; i++) { dut->clk = 1; dut->eval(); dut->clk = 0; dut->eval(); }
  dut->rst_n = 1;
  dut->eval();

  if (!quiet)
    fprintf(stderr, "fp32_fma tb: ref=%s latency=%d tininess_after=%d pin=%.2f pout=%.2f seed=%llu\n",
            fp32ref_specialization(), CFG_LATENCY, CFG_TININESS_AFTER, pin, pout,
            (unsigned long long)seed);

  uint64_t cyc = 0, idle_after_done = 0;
  while (true) {
    // ---------------- obtain next transaction to present
    if (!presenting && !src_done) {
      bool ok = true;
      if (rm_all) {
        if (cur_rm_idx >= 5) { ok = fetch_triple(); cur_rm_idx = 0; }
      } else {
        ok = fetch_triple();
      }
      if (!ok) src_done = true;
      else {
        pres.a = cur_a; pres.b = cur_b; pres.c = cur_c;
        pres.rm = (uint8_t)(rm_all ? cur_rm_idx++ : rm_fixed);
        pres.tag = next_tag++ & TAG_MASK;
        presenting = true;
        have_triple = true;
      }
    }
    if (src_done && !presenting && expect.empty()) {
      if (++idle_after_done > 4) break;
    }

    // ---------------- reset injection
    if (reset_every && reset_left == 0 && rst_rng.range((uint32_t)reset_every) == 0 && cyc > 0) {
      reset_left = 1 + (int)rst_rng.range(3);
      st.resets++;
    }
    bool in_reset = reset_left > 0;

    // ---------------- drive (between edges)
    bool drive_valid = presenting && !in_reset && (pin >= 1.0 || flow.uni() < pin);
    // a presented transaction stays valid until accepted once it was shown
    if (shown && presenting) drive_valid = !in_reset;
    dut->in_valid = drive_valid;
    dut->in_a = pres.a; dut->in_b = pres.b; dut->in_c = pres.c;
    dut->in_rm = pres.rm; dut->in_tag = pres.tag;
    dut->out_ready = (pout >= 1.0 || flow.uni() < pout);
    dut->rst_n = in_reset ? 0 : 1;
    dut->eval();

    if (in_reset) {
      // everything outstanding is discarded; output must be idle
      st.discarded += expect.size();
      expect.clear();
      shown = false;  // the presented op is re-presented after reset
      prev_stall = false;
      if (dut->out_valid) { st.proto_errors++; fprintf(stderr, "PROTO: out_valid during reset\n"); }
      reset_left--;
    } else {
      // ---------------- protocol: stability under back-pressure
      if (prev_stall) {
        if (!dut->out_valid) { st.proto_errors++; fprintf(stderr, "PROTO: out_valid dropped while stalled (cycle %llu)\n", (unsigned long long)cyc); }
        else if (dut->out_result != prev_res || dut->out_flags != prev_flags || dut->out_tag != prev_tag) {
          st.proto_errors++; fprintf(stderr, "PROTO: payload changed while stalled (cycle %llu)\n", (unsigned long long)cyc);
        }
      }
      bool in_fire = dut->in_valid && dut->in_ready;
      bool out_fire = dut->out_valid && dut->out_ready;
      prev_stall = dut->out_valid && !dut->out_ready;
      prev_res = dut->out_result; prev_flags = dut->out_flags; prev_tag = dut->out_tag;

      if (out_fire) {
        if (expect.empty()) {
          st.errors++;
          fprintf(stderr, "ERROR: unexpected output tag %02X result %08X (cycle %llu)\n",
                  dut->out_tag, dut->out_result, (unsigned long long)cyc);
        } else {
          Op op = expect.front();
          expect.pop_front();
          unsigned ef;
          uint32_t er = fp32ref_fma(op.a, op.b, op.c, op.rm, CFG_TININESS_AFTER, &ef);
          uint64_t lat = cyc - op.t_accept;
          st.lat_min = lat < st.lat_min ? lat : st.lat_min;
          st.lat_max = lat > st.lat_max ? lat : st.lat_max;
          st.lat_sum += lat;
          st.checked++;
          bool bad = dut->out_result != er || dut->out_flags != ef || dut->out_tag != op.tag;
          if (bad) {
            st.errors++;
            if (st.errors <= max_err_print)
              fprintf(stderr, "MISMATCH a=%08X b=%08X c=%08X rm=%u tag=%02X: dut %08X/%02X tag %02X, ref %08X/%02X\n",
                      op.a, op.b, op.c, op.rm, op.tag, dut->out_result, dut->out_flags,
                      dut->out_tag, er, ef);
          }
          if (tfver)
            printf("%08X %08X %08X %08X %02X\n", op.a, op.b, op.c, dut->out_result, dut->out_flags);
        }
      }
      if (dut->in_valid) shown = true;
      if (in_fire) {
        pres.t_accept = cyc;
        expect.push_back(pres);
        st.issued++;
        presenting = false;
        shown = false;
      }
    }

    // ---------------- clock edge
    dut->clk = 1; dut->eval();
    dut->clk = 0; dut->eval();
    cyc++;
    if (cyc > 50ull * 1000 * 1000 * 1000) { fprintf(stderr, "timeout\n"); return 3; }
  }
  st.cycles = cyc;
  dut->final();

  bool pass = st.issued > 0 && st.checked > 0 && st.errors == 0 && st.proto_errors == 0 &&
              (st.checked + st.discarded == st.issued);
  fprintf(stderr,
          "SUMMARY ref=%s latency_cfg=%d issued=%llu checked=%llu discarded_by_reset=%llu resets=%llu "
          "mismatches=%llu protocol_errors=%llu cycles=%llu ops_per_cycle=%.4f latency[min/avg/max]=%llu/%.2f/%llu %s\n",
          fp32ref_specialization(), CFG_LATENCY, (unsigned long long)st.issued,
          (unsigned long long)st.checked, (unsigned long long)st.discarded,
          (unsigned long long)st.resets, (unsigned long long)st.errors,
          (unsigned long long)st.proto_errors, (unsigned long long)st.cycles,
          st.cycles ? (double)st.checked / (double)st.cycles : 0.0,
          (unsigned long long)(st.checked ? st.lat_min : 0),
          st.checked ? (double)st.lat_sum / (double)st.checked : 0.0,
          (unsigned long long)st.lat_max, pass ? "PASS" : "FAIL");
  return pass ? 0 : 1;
}
