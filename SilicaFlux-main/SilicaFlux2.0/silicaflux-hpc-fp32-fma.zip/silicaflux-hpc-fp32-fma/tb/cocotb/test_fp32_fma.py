"""cocotb tests for the SilicaFlux-HPC fp32_fma unit.

Every DUT result is compared bit-exactly (32 result bits incl. NaN payloads,
5 flags, tag) against Berkeley SoftFloat-3e f32_mulAdd configured like the DUT
(see fma_tb.py). Directed vectors additionally carry hand-derived
expectations, so the directed suite does not rely on the reference library
alone.
"""
from __future__ import annotations

import random

import cocotb
from cocotb.triggers import FallingEdge, ReadOnly, RisingEdge, Timer

import vectors as V
from fma_tb import (LATENCY, NAN_PROPAGATE, PIPE_CFG, SCALE, TAG_MASK,
                    TININESS_AFTER, FmaTB, Op)

NX, UF, OF, DZ, NV = 1, 2, 4, 8, 16
CAN = 0x7FC00000
RNE, RTZ, RDN, RUP, RMM = range(5)
ALL = (RNE, RTZ, RDN, RUP, RMM)


def same(res, flags=0):
    """Same expected (result, flags) in all five rounding modes."""
    return {rm: (res, flags) for rm in ALL}


def nan(propagated: int, nv: bool):
    """Expected NaN result for both NaN policies."""
    return same(propagated if NAN_PROPAGATE else CAN, NV if nv else 0)


# -----------------------------------------------------------------------------
# Directed vectors: category -> [(name, a, b, c, {rm: (result, flags)} | None)]
# -----------------------------------------------------------------------------
MAX, MIN_N, MAX_S, MIN_S = V.MAX_F, V.MIN_N, V.MAX_S, V.MIN_S
NMAX = MAX | 0x80000000
P_INF, N_INF = V.PINF, V.NINF
HALF, ONEP5, TWO, QUART = 0x3F000000, 0x3FC00000, 0x40000000, 0x3E800000
ONE_U = 0x3F800001                     # 1 + 2^-23
TWO_M24, THREE_M24 = 0x33800000, 0x34400000
P2_127, P2_M63 = 0x7F000000, 0x20000000

DIRECTED = {
    "zeros": [
        ("0*0+0", 0, 0, 0, same(0x00000000)),
        ("-0*0+0", 0x80000000, 0, 0, {**same(0x00000000), RDN: (0x80000000, 0)}),
        ("0*0+-0", 0, 0, 0x80000000, {**same(0x00000000), RDN: (0x80000000, 0)}),
        ("-0*0+-0", 0x80000000, 0, 0x80000000, same(0x80000000)),
        ("-0*-0+-0", 0x80000000, 0x80000000, 0x80000000, {**same(0x00000000), RDN: (0x80000000, 0)}),
        ("0*1+-0", 0, V.ONE, 0x80000000, {**same(0x00000000), RDN: (0x80000000, 0)}),
        ("0*MAX+MIN_S", 0, MAX, MIN_S, same(MIN_S)),       # c returned exactly
    ],
    "ones": [
        ("1*1+1", V.ONE, V.ONE, V.ONE, same(0x40000000)),
        ("2*1.5+0.25", TWO, ONEP5, QUART, same(0x40500000)),   # 3.25
        ("1*1+0", V.ONE, V.ONE, 0, same(V.ONE)),
    ],
    "negative": [
        ("-2*3+1", 0xC0000000, 0x40400000, V.ONE, same(0xC0A00000)),      # -5
        ("-1.5*-1.5-0.25", 0xBFC00000, 0xBFC00000, 0xBE800000, same(TWO)),
        ("2*-3+-4", TWO, 0xC0400000, 0xC0800000, same(0xC1200000)),       # -10
        ("-1*1+0", V.NEG_ONE, V.ONE, 0, same(V.NEG_ONE)),
    ],
    "cancellation": [
        ("1*1-1", V.ONE, V.ONE, V.NEG_ONE, {**same(0), RDN: (0x80000000, 0)}),
        ("(1+u)^2-(1+2u)", ONE_U, ONE_U, 0xBF800002, same(0x28800000)),   # 2^-46 exact
        ("3*(1/3)-1", 0x40400000, 0x3EAAAAAB, V.NEG_ONE, same(0x33000000)),  # 2^-25
        ("1.5*1.5-2.25", ONEP5, ONEP5, 0xC0100000, {**same(0), RDN: (0x80000000, 0)}),
        ("(1+u)*MIN_N-MIN_N", ONE_U, MIN_N, MIN_N | 0x80000000, same(MIN_S)),  # exact subnormal
        ("MAX*1-MAX", MAX, V.ONE, NMAX, {**same(0), RDN: (0x80000000, 0)}),
    ],
    "exact_inexact": [
        ("1.5*1.5+0.25", ONEP5, ONEP5, QUART, same(0x40200000)),          # 2.5 exact
        ("3*(1/3)+0", 0x40400000, 0x3EAAAAAB, 0,                          # 1+2^-25
         {RNE: (V.ONE, NX), RTZ: (V.ONE, NX), RDN: (V.ONE, NX),
          RUP: (ONE_U, NX), RMM: (V.ONE, NX)}),
        ("(1+u)*(1+u)+0", ONE_U, ONE_U, 0,                                # 1+2^-22+2^-46
         {RNE: (0x3F800002, NX), RTZ: (0x3F800002, NX), RDN: (0x3F800002, NX),
          RUP: (0x3F800003, NX), RMM: (0x3F800002, NX)}),
    ],
    "exponent_boundaries": [
        ("2^127*1+0", P2_127, V.ONE, 0, same(P2_127)),
        ("2^-63*2^-63+0", P2_M63, P2_M63, 0, same(MIN_N)),                 # = 2^-126
        ("MIN_N*0.5+0", MIN_N, HALF, 0, same(0x00400000)),                 # exact subnormal
        ("2^127*2-2^127", P2_127, TWO, P2_127 | 0x80000000, same(P2_127)), # fused: no overflow
        ("MIN_N*1-MIN_S", MIN_N, V.ONE, MIN_S | 0x80000000, same(MAX_S)),
    ],
    "largest_finite": [
        ("MAX*1+0", MAX, V.ONE, 0, same(MAX)),
        ("MAX*-1+0", MAX, V.NEG_ONE, 0, same(NMAX)),
        ("MAX*2-MAX", MAX, TWO, NMAX, same(MAX)),                          # fused: exact
        ("MAX*1+MAX", MAX, V.ONE, MAX,
         {RNE: (P_INF, OF | NX), RTZ: (MAX, OF | NX), RDN: (MAX, OF | NX),
          RUP: (P_INF, OF | NX), RMM: (P_INF, OF | NX)}),
    ],
    "smallest_normal": [
        ("MIN_N*1+0", MIN_N, V.ONE, 0, same(MIN_N)),
        ("MAX_S*1+MIN_S", MAX_S, V.ONE, MIN_S, same(MIN_N)),               # exact carry into normal
        ("-MIN_N*1+MIN_S", MIN_N | 0x80000000, V.ONE, MIN_S, same(MAX_S | 0x80000000)),
    ],
    "subnormals": [
        ("MIN_S*1+0", MIN_S, V.ONE, 0, same(MIN_S)),
        ("MIN_S*2^127+0", MIN_S, P2_127, 0, same(0x34800000)),             # 2^-22
        ("MAX_S*2+0", MAX_S, TWO, 0, same(0x00FFFFFE)),                    # sub -> normal
        ("MIN_S*0.5+0", MIN_S, HALF, 0,                                     # 2^-150 tie
         {RNE: (0, UF | NX), RTZ: (0, UF | NX), RDN: (0, UF | NX),
          RUP: (MIN_S, UF | NX), RMM: (MIN_S, UF | NX)}),
        ("MIN_S*MIN_S+0", MIN_S, MIN_S, 0,
         {RNE: (0, UF | NX), RTZ: (0, UF | NX), RDN: (0, UF | NX),
          RUP: (MIN_S, UF | NX), RMM: (0, UF | NX)}),
        ("-MIN_S*MIN_S+0", MIN_S | 0x80000000, MIN_S, 0,
         {RNE: (0x80000000, UF | NX), RTZ: (0x80000000, UF | NX),
          RDN: (MIN_S | 0x80000000, UF | NX), RUP: (0x80000000, UF | NX),
          RMM: (0x80000000, UF | NX)}),
        ("MIN_S*MIN_S+MIN_S", MIN_S, MIN_S, MIN_S,
         {RNE: (MIN_S, UF | NX), RTZ: (MIN_S, UF | NX), RDN: (MIN_S, UF | NX),
          RUP: (0x00000002, UF | NX), RMM: (MIN_S, UF | NX)}),
    ],
    "overflow": [
        ("MAX*MAX+0", MAX, MAX, 0,
         {RNE: (P_INF, OF | NX), RTZ: (MAX, OF | NX), RDN: (MAX, OF | NX),
          RUP: (P_INF, OF | NX), RMM: (P_INF, OF | NX)}),
        ("-MAX*MAX+0", NMAX, MAX, 0,
         {RNE: (N_INF, OF | NX), RTZ: (NMAX, OF | NX), RDN: (N_INF, OF | NX),
          RUP: (NMAX, OF | NX), RMM: (N_INF, OF | NX)}),
        ("2^127*2+0", P2_127, TWO, 0,
         {RNE: (P_INF, OF | NX), RTZ: (MAX, OF | NX), RDN: (MAX, OF | NX),
          RUP: (P_INF, OF | NX), RMM: (P_INF, OF | NX)}),
    ],
    "underflow": [
        # exact value 2^-126 * (1 - 2^-26): tiny before rounding, but rounds to
        # 2^-126 with unbounded exponent -> UF depends on the tininess rule
        ("tininess discriminator", 0x3F7FF800, 0x00800400, 0,
         {RNE: (MIN_N, (UF | NX) if not TININESS_AFTER else NX),
          RTZ: (MAX_S, UF | NX), RDN: (MAX_S, UF | NX),
          RUP: (MIN_N, (UF | NX) if not TININESS_AFTER else NX),
          RMM: (MIN_N, (UF | NX) if not TININESS_AFTER else NX)}),
        ("(1+u)*0.5+0", ONE_U, HALF, 0, same(0x3F000001)),                 # normal, exact
        ("(1+u)*MIN_N*0.5", ONE_U, 0x00400000, 0,                          # 2^-127 + 2^-150 tie
         {RNE: (0x00400000, UF | NX), RTZ: (0x00400000, UF | NX), RDN: (0x00400000, UF | NX),
          RUP: (0x00400001, UF | NX), RMM: (0x00400001, UF | NX)}),
        ("MIN_N*0.5 exact (no UF)", MIN_N, HALF, 0, same(0x00400000, 0)),
    ],
    "infinity": [
        ("inf*1+1", P_INF, V.ONE, V.ONE, same(P_INF)),
        ("inf*-1+1", P_INF, V.NEG_ONE, V.ONE, same(N_INF)),
        ("1*1+inf", V.ONE, V.ONE, P_INF, same(P_INF)),
        ("1*1-inf", V.ONE, V.ONE, N_INF, same(N_INF)),
        ("inf*1+inf", P_INF, V.ONE, P_INF, same(P_INF)),
        ("inf*1-inf", P_INF, V.ONE, N_INF, nan(CAN, True)),
        ("inf*inf-inf", P_INF, P_INF, N_INF, nan(CAN, True)),
        ("0*1+inf", 0, V.ONE, P_INF, same(P_INF)),
        ("MAX*MAX-inf", MAX, MAX, N_INF, same(N_INF)),                     # no overflow flag
    ],
    "nan_propagation": [
        ("qNaN*1+1", 0x7FC00123, V.ONE, V.ONE, nan(0x7FC00123, False)),
        ("1*qNaN+1", V.ONE, 0xFFC00456, V.ONE, nan(0xFFC00456, False)),
        ("1*1+qNaN", V.ONE, V.ONE, 0x7FC00789, nan(0x7FC00789, False)),
        ("sNaN*1+1", 0x7F800123, V.ONE, V.ONE, nan(0x7FC00123, True)),
        ("1*sNaN+1", V.ONE, 0xFF800456, V.ONE, nan(0xFFC00456, True)),
        ("1*1+sNaN", V.ONE, V.ONE, 0x7F800789, nan(0x7FC00789, True)),
        ("qNaN*sNaN+1", 0x7FC00001, 0x7F800002, V.ONE, nan(0x7FC00002, True)),
        ("qNaN*qNaN+qNaN", 0x7FC00001, 0x7FC00002, 0x7FC00003, nan(0x7FC00001, False)),
        ("sNaN*sNaN+qNaN", 0x7F800001, 0x7F800002, 0x7FC00003, nan(0x7FC00001, True)),
        ("qNaN*1+sNaN", 0x7FC00001, V.ONE, 0x7F800003, nan(0x7FC00003, True)),
        ("inf*1+qNaN", P_INF, V.ONE, 0x7FC00005, nan(0x7FC00005, False)),
        ("0*qNaN+inf", 0, 0x7FC00006, P_INF, nan(0x7FC00006, False)),
    ],
    "invalid_0xinf": [
        ("0*inf+1", 0, P_INF, V.ONE, nan(CAN, True)),
        ("inf*0+1", P_INF, 0, V.ONE, nan(CAN, True)),
        ("-0*inf+qNaN", 0x80000000, P_INF, 0x7FC00007, nan(CAN, True)),   # NV even with qNaN c
        ("0*inf+sNaN", 0, P_INF, 0x7F800008, nan(0x7FC00008, True)),
        ("0*-inf+inf", 0, N_INF, P_INF, nan(CAN, True)),
        ("MIN_S*inf+0", MIN_S, P_INF, 0, same(P_INF)),                    # subnormal is not zero
    ],
    "rounding_halfway": [
        ("1*1+2^-24", V.ONE, V.ONE, TWO_M24,
         {RNE: (V.ONE, NX), RTZ: (V.ONE, NX), RDN: (V.ONE, NX), RUP: (ONE_U, NX), RMM: (ONE_U, NX)}),
        ("1*1+3*2^-24", V.ONE, V.ONE, THREE_M24,
         {RNE: (0x3F800002, NX), RTZ: (ONE_U, NX), RDN: (ONE_U, NX), RUP: (0x3F800002, NX),
          RMM: (0x3F800002, NX)}),
        ("-1*1-2^-24", V.NEG_ONE, V.ONE, TWO_M24 | 0x80000000,
         {RNE: (V.NEG_ONE, NX), RTZ: (V.NEG_ONE, NX), RDN: (0xBF800001, NX),
          RUP: (V.NEG_ONE, NX), RMM: (0xBF800001, NX)}),
        ("(1+u)*1.5+0", ONE_U, ONEP5, 0,                                   # 1.5+1.5*2^-23
         {RNE: (0x3FC00002, NX), RTZ: (0x3FC00001, NX), RDN: (0x3FC00001, NX),
          RUP: (0x3FC00002, NX), RMM: (0x3FC00002, NX)}),
    ],
}


def directed_ops(cat: str) -> list[Op]:
    ops = []
    tag = 0
    for name, a, b, c, exp in DIRECTED[cat]:
        for rm in ALL:
            e = exp.get(rm) if exp else None
            ops.append(Op(a, b, c, rm, tag & TAG_MASK, f"{cat}:{name}:rm{rm}", e))
            tag += 1
        # reserved rounding encodings 5..7 must behave as RNE
        e = exp.get(RNE) if exp else None
        ops.append(Op(a, b, c, 5 + (tag % 3), tag & TAG_MASK, f"{cat}:{name}:rm-reserved", e))
        tag += 1
    return ops


def make_directed_test(cat: str):
    async def _test(dut):
        tb = FmaTB(dut, seed=hash(cat) & 0xFFFF)
        await tb.start()
        ops = directed_ops(cat)
        await tb.run(ops)
        n_hand = sum(1 for o in ops if o.expect is not None)
        tb.assert_clean(f"directed[{cat}] ({len(ops)} ops, {n_hand} with hand-derived expectations)")
    _test.__name__ = f"test_directed_{cat}"
    _test.__qualname__ = _test.__name__
    return cocotb.test()(_test)


for _cat in DIRECTED:
    globals()[f"test_directed_{_cat}"] = make_directed_test(_cat)


# -----------------------------------------------------------------------------
# Random differential testing
# -----------------------------------------------------------------------------
def random_ops(rng: random.Random, n: int, tag0: int = 0) -> list[Op]:
    ops = []
    for i in range(n):
        a, b, c = V.gen_random(rng)
        ops.append(Op(a, b, c, rng.randrange(5), (tag0 + i) & TAG_MASK, f"rand#{i}"))
    return ops


@cocotb.test()
async def test_halfway_cases(dut):
    """Exact rounding midpoints (generated), all five rounding modes."""
    tb = FmaTB(dut, seed=11)
    await tb.start()
    ops = []
    for i, (a, b, c) in enumerate(V.halfway_cases(random.Random(11), int(200 * SCALE))):
        for rm in ALL:
            ops.append(Op(a, b, c, rm, len(ops) & TAG_MASK, f"half#{i}"))
    await tb.run(ops)
    tb.assert_clean(f"halfway ({len(ops)} ops)")


@cocotb.test()
async def test_random_differential(dut):
    """Deterministic biased-random differential test with mild back-pressure."""
    tb = FmaTB(dut, seed=1)
    await tb.start()
    ops = random_ops(random.Random(1001), int(6000 * SCALE))
    await tb.run(ops, p_in=0.9, p_out=0.85)
    tb.assert_clean(f"random differential ({len(ops)} ops)")


# -----------------------------------------------------------------------------
# Pipeline behaviour
# -----------------------------------------------------------------------------
@cocotb.test()
async def test_back_to_back_ii1(dut):
    """Unstalled stream: in_ready stays high, one result per cycle, fixed latency."""
    tb = FmaTB(dut, seed=2)
    await tb.start()
    n = int(1000 * SCALE)
    ops = random_ops(random.Random(2002), n)
    st = await tb.run(ops, p_in=1.0, p_out=1.0)
    lat = {r.latency for r in st.results}
    span = st.last_out - st.first_out + 1
    dut._log.info(f"back-to-back: {n} ops, in_ready low {st.in_ready_low_cycles} cycles, "
                  f"outputs over {span} consecutive cycles, latency {sorted(lat)} "
                  f"(configured {LATENCY}), II = {span / n:.4f}")
    assert st.in_ready_low_cycles == 0, "in_ready dropped in an unstalled stream"
    assert span == n, f"{n} results took {span} cycles: initiation interval is not 1"
    assert lat == {LATENCY}, f"latency {lat} != {LATENCY}"
    tb.assert_clean("back-to-back")


@cocotb.test()
async def test_random_stalls(dut):
    """Heavy random stalls on both sides; monitor checks payload stability."""
    tb = FmaTB(dut, seed=3)
    await tb.start()
    ops = random_ops(random.Random(3003), int(3000 * SCALE))
    st = await tb.run(ops, p_in=0.55, p_out=0.35)
    dut._log.info(f"random stalls: {len(st.results)} results in {st.cycles} cycles, "
                  f"in_ready low {st.in_ready_low_cycles} cycles")
    assert len(st.results) == len(ops)
    tb.assert_clean("random stalls")


@cocotb.test()
async def test_backpressure_fill_and_drain(dut):
    """out_ready held low: the pipeline must fill to exactly LATENCY entries,
    deassert in_ready, hold its output, then drain everything in order."""
    tb = FmaTB(dut, seed=4)
    await tb.start()
    ops = random_ops(random.Random(4004), LATENCY + 6)
    hold = 30
    st = await tb.run(ops, p_in=1.0, out_ready_fn=lambda n: n >= hold)
    accepted_before_release = sum(1 for r in st.results if r.op.t_in < hold)
    dut._log.info(f"fill: {accepted_before_release} ops accepted while out_ready=0 "
                  f"(capacity {LATENCY}), in_ready low {st.in_ready_low_cycles} cycles")
    assert accepted_before_release == LATENCY, \
        f"accepted {accepted_before_release} ops into a {LATENCY}-entry pipeline"
    assert [r.tag for r in st.results] == [o.tag for o in ops], "order/tag violated"
    tb.assert_clean("fill and drain")


@cocotb.test()
async def test_reset_outstanding(dut):
    """Asynchronous reset while operations are outstanding (stalled and
    moving): every outstanding op is discarded, nothing stale emerges, the
    unit accepts new work immediately and computes it correctly."""
    tb = FmaTB(dut, seed=5)
    await tb.start()
    # 1) pipeline full and stalled: LATENCY ops accepted, one more blocked on
    #    the input bus when reset hits
    old = random_ops(random.Random(5005), LATENCY + 1, tag0=0x10)
    st = await tb.run(old, p_in=1.0, out_ready_fn=lambda n: False,
                      reset_at=LATENCY + 4, max_cycles=LATENCY + 12, check=False)
    assert not st.results, "result delivered although out_ready was never asserted"
    # 2) post-reset idle state
    await FallingEdge(dut.clk)
    await ReadOnly()
    assert int(dut.out_valid.value) == 0, "out_valid set after reset"
    assert int(dut.in_ready.value) == 1, "in_ready low after reset"
    # 3) reset while flowing with stalls
    mid = random_ops(random.Random(5006), 40, tag0=0x40)
    await tb.run(mid, p_in=0.8, p_out=0.6, reset_at=17, reset_len=3, check=True)
    # 4) new operations after reset: only these tags may come out
    new = random_ops(random.Random(5007), 200, tag0=0x80)
    st2 = await tb.run(new, p_in=0.9, p_out=0.7)
    tags = [r.tag for r in st2.results]
    assert tags == [o.tag for o in new], "stale or reordered result after reset"
    tb.assert_clean("reset during outstanding operations")


@cocotb.test()
async def test_tag_preservation(dut):
    """Random (non-sequential) tags under random stalls are returned with the
    matching result, in issue order."""
    tb = FmaTB(dut, seed=6)
    await tb.start()
    rng = random.Random(6006)
    ops = random_ops(rng, int(2000 * SCALE))
    for o in ops:
        o.tag = rng.getrandbits(32) & TAG_MASK
    st = await tb.run(ops, p_in=0.7, p_out=0.5)
    assert [r.tag for r in st.results] == [o.tag for o in ops]
    tb.assert_clean(f"tag preservation ({len(ops)} ops, TAG_W={TAG_MASK.bit_length()})")


@cocotb.test()
async def test_config_report(dut):
    """Records the configuration under test in the log/results."""
    tb = FmaTB(dut)
    await tb.start()
    dut._log.info(f"configuration: PIPE_CFG={PIPE_CFG} latency={LATENCY} "
                  f"NAN_PROPAGATE={int(NAN_PROPAGATE)} TININESS_AFTER={int(TININESS_AFTER)} "
                  f"reference={tb.ref.specialization}")
