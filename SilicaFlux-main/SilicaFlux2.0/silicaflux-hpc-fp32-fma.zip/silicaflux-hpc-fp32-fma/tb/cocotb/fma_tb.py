"""cocotb environment for fp32_fma: cycle-accurate driver, back-pressure
generator, protocol monitor and scoreboard against SoftFloat-3e.

Timing discipline (identical for Icarus and Verilator): inputs are driven
on the falling clock edge; handshakes are sampled in the ReadOnly phase that
follows, i.e. with exactly the values the DUT sees at the next rising edge.
"""
from __future__ import annotations

import os
import random
from collections import deque
from dataclasses import dataclass, field

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import FallingEdge, ReadOnly, RisingEdge, Timer

from fp32_ref import SoftFloatFMA, flags_str, fmt

PIPE_CFG = os.environ.get("FMA_PIPE_CFG", "11110")
NAN_PROPAGATE = os.environ.get("FMA_NAN_PROPAGATE", "0") == "1"
TININESS_AFTER = os.environ.get("FMA_TININESS_AFTER", "1") == "1"
TAG_W = int(os.environ.get("FMA_TAG_W", "8"))
SCALE = float(os.environ.get("FMA_SCALE", "1"))
SEED_BASE = int(os.environ.get("FMA_SEED_BASE", "20261106"))
LATENCY = 1 + PIPE_CFG.count("1")
TAG_MASK = (1 << TAG_W) - 1


@dataclass
class Op:
    a: int
    b: int
    c: int
    rm: int = 0
    tag: int = 0
    name: str = ""
    expect: tuple | None = None     # optional hand-derived (result, flags)
    t_in: int = -1


@dataclass
class Result:
    op: Op
    result: int
    flags: int
    tag: int
    latency: int


@dataclass
class RunStats:
    results: list = field(default_factory=list)
    cycles: int = 0
    in_ready_low_cycles: int = 0
    first_out: int = -1
    last_out: int = -1


class FmaTB:
    def __init__(self, dut, seed: int = 0):
        self.dut = dut
        self.ref = SoftFloatFMA(nan_propagate=NAN_PROPAGATE)
        self.rng = random.Random(SEED_BASE + seed)
        self.cycle = 0
        self.errors: list[str] = []
        self.checked = 0
        dut.in_valid.value = 0
        dut.out_ready.value = 0
        dut.in_a.value = 0
        dut.in_b.value = 0
        dut.in_c.value = 0
        dut.in_rm.value = 0
        dut.in_tag.value = 0

    # ------------------------------------------------------------------ setup
    async def start(self, reset_cycles: int = 3):
        try:
            clk = Clock(self.dut.clk, 10, units="ns")
        except TypeError:  # cocotb >= 2.0
            clk = Clock(self.dut.clk, 10, unit="ns")
        cocotb.start_soon(clk.start())
        self.dut.rst_n.value = 0
        for _ in range(reset_cycles):
            await RisingEdge(self.dut.clk)
        await FallingEdge(self.dut.clk)
        self.dut.rst_n.value = 1

    # -------------------------------------------------------------- checking
    def expected(self, op: Op) -> tuple[int, int]:
        return self.ref.fma(op.a, op.b, op.c, op.rm, TININESS_AFTER)

    def check(self, r: Result):
        self.checked += 1
        er, ef = self.expected(r.op)
        ok = (r.result, r.flags) == (er, ef) and r.tag == r.op.tag
        if ok and r.op.expect is not None:
            ok = (r.result, r.flags) == tuple(r.op.expect)
            if not ok:
                self.errors.append(
                    f"HAND-EXPECTATION {r.op.name}: dut {fmt(r.result)} {flags_str(r.flags)} "
                    f"hand {fmt(r.op.expect[0])} {flags_str(r.op.expect[1])}")
                return
        if not ok:
            self.errors.append(
                f"MISMATCH {r.op.name} a={r.op.a:08X} b={r.op.b:08X} c={r.op.c:08X} rm={r.op.rm} "
                f"tag={r.op.tag:X}: dut {r.result:08X} {flags_str(r.flags)} tag={r.tag:X} | "
                f"ref {er:08X} {flags_str(ef)}")

    def assert_clean(self, what: str):
        if self.errors:
            for e in self.errors[:25]:
                self.dut._log.error(e)
            raise AssertionError(f"{what}: {len(self.errors)} error(s), first: {self.errors[0]}")
        self.dut._log.info(f"{what}: {self.checked} results checked bit-exactly "
                           f"(result, flags, tag) against {self.ref.specialization}")

    # ---------------------------------------------------------- main engine
    async def run(self, ops: list[Op], p_in: float = 1.0, p_out: float = 1.0,
                  reset_at: int | None = None, reset_len: int = 2,
                  out_ready_fn=None, max_cycles: int | None = None,
                  check: bool = True) -> RunStats:
        """Stream ops through the DUT.

        p_in / p_out : per-cycle probability of offering in_valid / out_ready
        out_ready_fn : optional f(cycle_index) -> bool overriding p_out
        reset_at     : cycle index (relative to this run) at which rst_n is
                       asserted asynchronously (mid-cycle) for reset_len cycles;
                       all accepted-but-undelivered ops are then discarded
        Returns RunStats; results are scoreboarded when check=True.
        """
        dut, rng = self.dut, self.rng
        pending = deque(ops)
        inflight: deque[Op] = deque()
        st = RunStats()
        presenting = False          # a valid op is on the input bus
        prev_stall = None           # (result, flags, tag) when stalled last cycle
        limit = max_cycles or (len(ops) * (LATENCY + 4) * 20 + 2000)
        n = 0
        rst_left = 0
        while (pending or inflight or presenting) and n < limit:
            await FallingEdge(dut.clk)
            # -------- asynchronous reset injection (mid-cycle, not on an edge)
            if reset_at is not None and n == reset_at:
                await Timer(2, units="ns")
                dut.rst_n.value = 0
                rst_left = reset_len
            if rst_left:
                rst_left -= 1
                if rst_left == 0:
                    dut.rst_n.value = 1
                dut.in_valid.value = 0
                dut.out_ready.value = 0
                await ReadOnly()
                if int(dut.out_valid.value) != 0:
                    self.errors.append("out_valid high while rst_n asserted")
                if int(dut.in_ready.value) != 1:
                    self.errors.append("in_ready low while rst_n asserted")
                inflight.clear()     # everything outstanding is discarded
                prev_stall = None
                if presenting:       # op on the bus was not accepted
                    presenting = False
                n += 1
                continue
            # -------- drive
            if not presenting and pending and rng.random() < p_in:
                op = pending.popleft()
                dut.in_a.value, dut.in_b.value, dut.in_c.value = op.a, op.b, op.c
                dut.in_rm.value, dut.in_tag.value = op.rm, op.tag & TAG_MASK
                dut.in_valid.value = 1
                presenting, cur = True, op
            elif not presenting:
                dut.in_valid.value = 0
            if out_ready_fn is not None:
                rdy = 1 if out_ready_fn(n) else 0
            else:
                rdy = 1 if rng.random() < p_out else 0
            dut.out_ready.value = rdy
            # -------- sample (values seen by the next rising edge)
            await ReadOnly()
            in_rdy = int(dut.in_ready.value)
            o_val = int(dut.out_valid.value)
            if prev_stall is not None:
                cur_payload = (int(dut.out_result.value), int(dut.out_flags.value), int(dut.out_tag.value))
                if not o_val:
                    self.errors.append(f"cycle {n}: out_valid dropped while stalled")
                elif cur_payload != prev_stall:
                    self.errors.append(f"cycle {n}: output payload changed while stalled")
            if not in_rdy:
                st.in_ready_low_cycles += 1
            if o_val and rdy:
                if not inflight:
                    self.errors.append(f"cycle {n}: unexpected output tag {int(dut.out_tag.value):X}")
                else:
                    op = inflight.popleft()
                    res = Result(op, int(dut.out_result.value), int(dut.out_flags.value),
                                 int(dut.out_tag.value), n - op.t_in)
                    st.results.append(res)
                    if st.first_out < 0:
                        st.first_out = n
                    st.last_out = n
                    if check:
                        self.check(res)
            prev_stall = ((int(dut.out_result.value), int(dut.out_flags.value),
                           int(dut.out_tag.value)) if (o_val and not rdy) else None)
            if presenting and in_rdy:
                cur.t_in = n
                inflight.append(cur)
                presenting = False
            n += 1
        await FallingEdge(dut.clk)
        dut.in_valid.value = 0
        st.cycles = n
        if n >= limit:
            self.errors.append(f"run did not drain within {limit} cycles "
                               f"({len(pending)} pending, {len(inflight)} in flight)")
        return st
