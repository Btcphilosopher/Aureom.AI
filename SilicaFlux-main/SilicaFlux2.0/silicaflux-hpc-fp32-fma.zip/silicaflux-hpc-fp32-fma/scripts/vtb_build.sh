#!/usr/bin/env bash
# Build the Verilator C++ differential testbench for one DUT configuration.
#   scripts/vtb_build.sh <name> <PIPE_CFG 5-bit binary> <NAN_PROPAGATE> <TININESS_AFTER>
# Output: build/vtb/<name>/Vfp32_fma
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME=$1; PIPE=$2; NANP=$3; TIN=$4
"$ROOT/ref/build_ref.sh" >/dev/null
SPEC=$([ "$NANP" = 1 ] && echo ARM-VFPv2 || echo RISCV)
LAT=$(( 1 + $(echo "$PIPE" | tr -cd 1 | wc -c) ))
OUT="$ROOT/build/vtb/$NAME"; mkdir -p "$OUT"
SF="$ROOT/third_party/berkeley-softfloat-3"
SHIM="$OUT/fp32ref_shim.o"
gcc -O2 -c -DFP32REF_SPEC_NAME="\"SoftFloat-3e/$SPEC\"" -I"$SF/source/include" \
  -I"$ROOT/build/ref/softfloat-$SPEC" "$ROOT/ref/fp32ref_shim.c" -o "$SHIM"
RTL=$(sed "s|^|$ROOT/rtl/|" "$ROOT/rtl/files.f" | tr '\n' ' ')
verilator --cc --exe --build -j "$(nproc)" -O3 --x-assign fast --x-initial unique \
  --assert +define+FP32_FMA_ASSERT -Wno-fatal \
  --top-module fp32_fma -GTAG_W=8 -GPIPE_CFG=5\'b$PIPE -GNAN_PROPAGATE=1\'b$NANP -GTININESS_AFTER_ROUNDING=1\'b$TIN \
  -Mdir "$OUT/obj" -o "$OUT/Vfp32_fma" \
  -CFLAGS "-O2 -DCFG_LATENCY=$LAT -DCFG_TININESS_AFTER=$TIN -I$SF/source/include -I$ROOT/build/ref/softfloat-$SPEC" \
  -LDFLAGS "$SHIM $ROOT/build/ref/softfloat-$SPEC/softfloat.a" \
  $RTL "$ROOT/tb/verilator/tb_fp32_fma.cpp" > "$OUT/build.log" 2>&1 \
  || { tail -30 "$OUT/build.log"; exit 1; }
echo "built $OUT/Vfp32_fma (PIPE_CFG=$PIPE NAN_PROPAGATE=$NANP TININESS_AFTER=$TIN latency=$LAT ref=$SPEC)"
