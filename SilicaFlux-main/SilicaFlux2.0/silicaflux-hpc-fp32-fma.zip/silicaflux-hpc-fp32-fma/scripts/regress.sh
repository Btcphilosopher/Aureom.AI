#!/usr/bin/env bash
# =============================================================================
# Full regression for SilicaFlux-HPC Module 01 (fp32_fma). Writes per-step
# logs under reports/ and reports/REGRESSION_SUMMARY.md. Exit 0 only if every
# step passes.
#   QUICK=1  : smaller vector counts (smoke run, ~5 min)
# =============================================================================
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
QUICK=${QUICK:-0}
SUM="$ROOT/reports/REGRESSION_SUMMARY.md"; mkdir -p reports
declare -a NAMES RESULTS
step() {  # title command...
  local title=$1; shift
  local t0=$SECONDS
  echo "=== $title"
  if "$@"; then r=PASS; else r=FAIL; fi
  NAMES+=("$title"); RESULTS+=("$r ($((SECONDS-t0)) s)")
  echo "=== $title: $r"
}
step "reference build (SoftFloat-3e, TestFloat-3e)"      ref/build_ref.sh
step "lint/elaboration/latch check (8 configurations)"   scripts/lint.sh
step "formal: LZC tree == priority-loop spec (Yosys SAT)" formal/lzc_equiv.sh
step "formal: pipeline control BMC depth 16 (5 PIPE_CFGs)" formal/run_ctrl.sh
if [ "$QUICK" = 1 ]; then
  step "oracle cross-check SoftFloat vs MPFR"             python3 ref/crosscheck_oracle.py --n 5000 --out reports/oracle_crosscheck.txt
  step "Verilator differential stress (6 configurations)" env N=20000 scripts/vtb_stress.sh
  step "cocotb (Verilator x6, Icarus x2)"                 env SCALE=0.25 scripts/cocotb_regress.sh
  step "TestFloat level 1 (default configuration)"        scripts/testfloat_run.sh default 0 1 1
else
  step "oracle cross-check SoftFloat vs MPFR"             python3 ref/crosscheck_oracle.py --n 200000 --out reports/oracle_crosscheck.txt
  step "Verilator differential stress (6 configurations)" scripts/vtb_stress.sh
  step "cocotb (Verilator x6, Icarus x2)"                 env SCALE=2 scripts/cocotb_regress.sh
  for c in "default 0 1" "full 0 1" "comb 0 1" "arm 1 0" "mix_a 1 1" "mix_b 0 0"; do
    set -- $c
    step "TestFloat level 1, 5 rounding modes ($1)"        scripts/testfloat_run.sh $1 $2 $3 1
  done
  # level 2 needs >= 14.5e9 f32_mulAdd cases (infeasible here); instead re-run
  # level 1 with other generator seeds (~5.4M new unique triples per seed)
  step "TestFloat level 1, seed 2, 5 rounding modes (default)" scripts/testfloat_run.sh default 0 1 1 -seed 2
  step "TestFloat level 1, seed 3, 5 rounding modes (arm)"     scripts/testfloat_run.sh arm 1 0 1 -seed 3
fi
step "synthesis smoke tests (generic, ECP5, Xilinx 7)"   synth/run_synth.sh
{
  echo "# fp32_fma regression summary"
  echo
  echo "Run: $(date -u +%Y-%m-%dT%H:%M:%SZ) on $(uname -sm), $(nproc) CPUs. QUICK=$QUICK"
  echo
  echo "Formal solver: $(z3 --version) (yosys-smtbmc)"
  echo
  echo "Tools: Verilator $(verilator --version | awk '{print $2}'), Icarus $(iverilog -V 2>/dev/null | head -1 | awk '{print $4}'), Yosys $(yosys -V | awk '{print $2}'), cocotb $(python3 -c 'import cocotb;print(cocotb.__version__)'), Python $(python3 -c 'import sys;print(sys.version.split()[0])'), gmpy2 $(python3 -c 'import gmpy2;print(gmpy2.version(), "/", gmpy2.mpfr_version())'), gcc $(gcc -dumpversion)"
  echo
  echo "| step | result |"
  echo "|---|---|"
  for i in "${!NAMES[@]}"; do echo "| ${NAMES[$i]} | ${RESULTS[$i]} |"; done
  echo
  echo "Detailed logs: reports/lint, reports/formal, reports/vtb, reports/cocotb, reports/testfloat, reports/synth, reports/oracle_crosscheck.txt"
} > "$SUM"
cat "$SUM"
! grep -q '| FAIL' "$SUM"
