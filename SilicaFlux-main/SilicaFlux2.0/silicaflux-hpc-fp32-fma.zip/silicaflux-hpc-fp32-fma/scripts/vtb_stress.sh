#!/usr/bin/env bash
# Random differential + flow-control + reset stress on every configuration
# (Verilator C++ harness, SoftFloat in-process). Writes reports/vtb/stress.txt.
#   N=<triples> scales the main run (default 400000 triples x 5 rounding modes)
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/vtb"; mkdir -p "$OUT"; SUM="$OUT/stress.txt"; : > "$SUM"
N=${N:-400000}; H=$((N/2)); Q=$((N/8))
rc=0
while read -r name pipe nanp tin; do
  [[ -z "$name" || "$name" == \#* ]] && continue
  "$ROOT/scripts/vtb_build.sh" "$name" "$pipe" "$nanp" "$tin" > /dev/null || { echo "build $name FAILED" | tee -a "$SUM"; rc=1; continue; }
  B="$ROOT/build/vtb/$name/Vfp32_fma"
  i=0
  for args in "--random $N --rm all --seed 7" \
              "--random $H --rm all --seed 8 --pin 0.5 --pout 0.3" \
              "--random $H --rm all --seed 9 --pin 0.95 --pout 0.6 --reset-every 5000" \
              "--random $Q --rm 5 --seed 10 --pin 0.7 --pout 0.9" \
              "--random $Q --rm 7 --seed 12 --pin 0.8 --pout 0.95 --reset-every 300"; do
    i=$((i+1))
    line=$("$B" $args --quiet 2>&1 | grep SUMMARY | sed 's/^SUMMARY //')
    printf "%-8s run%d %-66s %s\n" "$name" "$i" "[$args]" "${line:-NO SUMMARY}" | tee -a "$SUM"
    grep -q ' PASS$' <<<"$line" || rc=1
  done
done < "$ROOT/scripts/vtb_configs.txt"
exit $rc
