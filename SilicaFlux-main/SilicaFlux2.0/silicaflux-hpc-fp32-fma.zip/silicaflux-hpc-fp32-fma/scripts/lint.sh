#!/usr/bin/env bash
# Lint and elaboration checks for every configuration in scripts/vtb_configs.txt
# plus TAG_W = 1 and 32 (SilicaFlux-V lint.sh convention):
#   1. Verilator --lint-only -Wall (with and without FP32_FMA_ASSERT):
#      0 errors and 0 warnings required (no waivers outside the RTL's own
#      documented lint_off pragmas)
#   2. Icarus 12 -g2012 elaboration: must succeed
#   3. Yosys 0.33 read/hierarchy/proc/flatten: must succeed, 0 latches
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/lint"; mkdir -p "$OUT"
FILES=$(sed "s|^|$ROOT/rtl/|" "$ROOT/rtl/files.f" | tr '\n' ' ')
SUM="$OUT/summary.txt"
{ echo "# Verilator $(verilator --version | awk '{print $2}'), Icarus $(iverilog -V 2>/dev/null | head -1 | awk '{print $4}'), Yosys $(yosys -V | awk '{print $2}')"; } > "$SUM"
rc=0
check() {  # name pipe nanp tin tagw
  local n=$1 p=$2 a=$3 t=$4 w=$5 log="$OUT/$1"
  local g="-GPIPE_CFG=5'b$p -GNAN_PROPAGATE=1'b$a -GTININESS_AFTER_ROUNDING=1'b$t -GTAG_W=$w"
  verilator --lint-only -Wall --top-module fp32_fma $g $FILES > "$log.verilator.log" 2>&1
  local vw; vw=$(grep -cE '^%(Warning|Error)' "$log.verilator.log")
  verilator --lint-only -Wall --assert +define+FP32_FMA_ASSERT --top-module fp32_fma $g $FILES > "$log.verilator_assert.log" 2>&1
  local va; va=$(grep -cE '^%(Warning|Error)' "$log.verilator_assert.log")
  iverilog -g2012 -s fp32_fma -Pfp32_fma.PIPE_CFG=$((2#$p)) -Pfp32_fma.NAN_PROPAGATE=$a \
    -Pfp32_fma.TININESS_AFTER_ROUNDING=$t -Pfp32_fma.TAG_W=$w -o /dev/null $FILES > "$log.icarus.log" 2>&1
  local irc=$? iw; iw=$(grep -v 'sorry: constant selects in always_\* processes' "$log.icarus.log" | grep -ciE 'warning|error')
  yosys -p "read_verilog -sv $FILES; chparam -set PIPE_CFG $((2#$p)) -set NAN_PROPAGATE $a \
      -set TININESS_AFTER_ROUNDING $t -set TAG_W $w fp32_fma; hierarchy -check -top fp32_fma; \
      proc; flatten; opt -purge; tee -o $log.latches.txt select -list t:\$dlatch t:\$adlatch t:\$dlatchsr; stat" \
      > "$log.yosys.log" 2>&1
  local yrc=$? nl; nl=$(grep -c 'latch' "$log.latches.txt" 2>/dev/null); nl=${nl:-0}
  local st=PASS
  if [ "$vw" != 0 ] || [ "$va" != 0 ] || [ $irc != 0 ] || [ "$iw" != 0 ] || [ $yrc != 0 ] || [ "$nl" != 0 ]; then st=FAIL; rc=1; fi
  printf "%-10s PIPE_CFG=%s NANP=%s TIN=%s TAG_W=%-2s | verilator -Wall: %s msgs (+assert: %s) | icarus: rc=%s, %s msgs | yosys: rc=%s, latches=%s | %s\n" \
    "$n" "$p" "$a" "$t" "$w" "$vw" "$va" "$irc" "$iw" "$yrc" "$nl" "$st" | tee -a "$SUM"
}
while read -r name pipe nanp tin; do
  [[ -z "$name" || "$name" == \#* ]] && continue
  check "$name" "$pipe" "$nanp" "$tin" 8
done < "$ROOT/scripts/vtb_configs.txt"
check tagw1  11110 0 1 1
check tagw32 11110 1 0 32
echo "icarus note: 'sorry: constant selects in always_* processes' is an Icarus sensitivity-list limitation (it over-approximates sensitivity), filtered above" >> "$SUM"
exit $rc
