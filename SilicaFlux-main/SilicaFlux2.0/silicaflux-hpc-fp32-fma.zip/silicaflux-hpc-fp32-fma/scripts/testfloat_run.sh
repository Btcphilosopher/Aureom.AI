#!/usr/bin/env bash
# TestFloat-3e flow for one DUT configuration:
#   testfloat_gen -level L -r<mode> [-tininess*] f32_mulAdd
#     | Vfp32_fma --stdin --rm <rm> --tfver     (DUT, also self-checks vs SoftFloat)
#     | testfloat_ver -r<mode> [-tininess*] -checkNaNs f32_mulAdd
# usage: scripts/testfloat_run.sh <vtb-name> <NAN_PROPAGATE> <TININESS_AFTER> [level] [extra gen args]
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME=$1; NANP=$2; TIN=$3; LEVEL=${4:-1}; shift 4 || true; EXTRA="$*"
B="$ROOT/build/vtb/$NAME/Vfp32_fma"
TFD="$ROOT/build/ref/$([ "$NANP" = 1 ] && echo testfloat-armvfp || echo testfloat)"
TINARG=$([ "$TIN" = 1 ] && echo -tininessafter || echo -tininessbefore)
OUT="$ROOT/reports/testfloat"; mkdir -p "$OUT"
rc=0
for m in "0 rnear_even" "1 rminMag" "2 rmin" "3 rmax" "4 rnear_maxMag"; do
  set -- $m; RM=$1; MODE=$2
  LOG="$OUT/${NAME}_L${LEVEL}$(echo "$EXTRA" | tr -d ' -')_${MODE}.log"
  "$TFD/testfloat_gen" -level "$LEVEL" -$MODE $TINARG $EXTRA f32_mulAdd \
    | "$B" --stdin --rm "$RM" --tfver --pin 0.9 --pout 0.8 --seed $((RM+11)) 2> "$LOG.dut" \
    | "$TFD/testfloat_ver" -$MODE $TINARG -checkNaNs -errors 20 f32_mulAdd > "$LOG" 2>&1
  st=("${PIPESTATUS[@]}")
  ver=$(grep -E 'tests performed|errors? found' "$LOG" | tail -1)
  dut=$(grep SUMMARY "$LOG.dut" | sed 's/.*issued=\([0-9]*\).*mismatches=\([0-9]*\) protocol_errors=\([0-9]*\).*\(PASS\|FAIL\)$/issued=\1 mismatches=\2 protocol_errors=\3 \4/')
  echo "$NAME level=$LEVEL $EXTRA $MODE: testfloat_ver: $ver | dut-vs-softfloat: $dut"
  # pass only if testfloat_ver ran a nonzero number of tests with no errors,
  # the DUT self-check passed, and both saw the same number of operations
  ntf=$(sed -nE 's/^In ([0-9]+) tests, no errors found.*/\1/p' "$LOG" | tail -1)
  ndut=$(sed -nE 's/.*issued=([0-9]+) .*/\1/p' "$LOG.dut" | tail -1)
  if [ "${st[1]}" != 0 ] || [ -z "$ntf" ] || [ "$ntf" = 0 ] || [ "$ntf" != "$ndut" ] \
     || ! grep -q ' PASS$' "$LOG.dut"; then
    echo "  -> FAIL (testfloat_ver tests=${ntf:-none}, dut issued=${ndut:-none})"; rc=1
  fi
done
exit $rc
