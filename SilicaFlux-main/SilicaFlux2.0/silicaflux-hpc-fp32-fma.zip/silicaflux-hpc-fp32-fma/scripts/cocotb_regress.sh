#!/usr/bin/env bash
# cocotb regression: Verilator over every configuration in scripts/vtb_configs.txt,
# Icarus over a subset (cross-simulator check). Writes reports/cocotb/summary.txt.
#   SCALE=<k> multiplies the random-vector counts (default 1)
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/cocotb"; mkdir -p "$OUT"
SCALE=${SCALE:-1}
ICARUS_CFGS=${ICARUS_CFGS:-"default arm"}
SUM="$OUT/summary.txt"; : > "$SUM"
rc=0
run() {  # sim name pipe nanp tin
  local sim=$1 name=$2 pipe=$3 nanp=$4 tin=$5 log="$OUT/${1}_${2}.log"
  make -C "$ROOT/tb/cocotb" SIM=$sim PIPE_CFG=$pipe NAN_PROPAGATE=$nanp TININESS_AFTER=$tin \
       SCALE=$SCALE > "$log" 2>&1
  local line; line=$(grep -E 'TESTS=[0-9]+ PASS=' "$log" | tail -1 | sed -E 's/^[ *]+//; s/ +\*\*$//')
  printf "%-9s %-8s PIPE_CFG=%s NAN_PROPAGATE=%s TININESS_AFTER=%s : %s\n" \
         "$sim" "$name" "$pipe" "$nanp" "$tin" "${line:-NO RESULT}" | tee -a "$SUM"
  grep -qE 'FAIL=0 ' <<<"$line" || rc=1
}
while read -r name pipe nanp tin; do
  [[ -z "$name" || "$name" == \#* ]] && continue
  run verilator "$name" "$pipe" "$nanp" "$tin"
  for ic in $ICARUS_CFGS; do [ "$ic" = "$name" ] && run icarus "$name" "$pipe" "$nanp" "$tin"; done
done < "$ROOT/scripts/vtb_configs.txt"
exit $rc
