# SilicaFlux-HPC · Module 01 · FP32 fused multiply-add engine

Aureom.AI | SilicaFlux-HPC compute tile

A synthesizable, pipelined IEEE 754 binary32 fused multiply-add unit,
`result = round(a × b + c)` with a single rounding, in SystemVerilog
(`rtl/fp32_fma.sv`), with a valid/ready interface, transaction tags,
back-pressure, all five IEEE rounding attributes, exact subnormal handling and
the five IEEE exception flags — verified bit-exactly against Berkeley
SoftFloat-3e and TestFloat-3e.

## Acceptance criteria

| criterion | status | evidence |
|---|---|---|
| RTL elaborates | met: Verilator 5.020, Icarus 12, Yosys 0.33; 8 parameter sets | `reports/lint/summary.txt` |
| Lint passes | met: Verilator `-Wall`, 0 warnings, with and without assertions | `reports/lint/` |
| Arithmetic matches an independent reference | met: 0 mismatches vs SoftFloat-3e `f32_mulAdd` on all 32 result bits incl. NaNs; TestFloat level 1 (30.7 M cases/configuration) in 6 configurations plus 2 extra seeds; 24.6 M biased-random operations under stalls and resets | `reports/testfloat/`, `reports/vtb/stress.txt` |
| Exception flags verified | met: all 5 flags compared on every operation; both tininess conventions | same |
| Back-pressure preserves all transactions | met: random stalls (in simulation, millions of ops) and BMC proof (depth 16) of in-order, no-loss, no-duplication delivery and payload stability | `reports/vtb/`, `reports/cocotb/`, `reports/formal/ctrl_summary.txt` |
| Reset behaviour deterministic | met: asynchronous resets injected at random points of stalled/flowing traffic; outstanding operations discarded, nothing stale emerges; BMC property P6 | same |
| Synthesis completes | met: generic gates, Lattice ECP5, Xilinx 7-series (Yosys) | `reports/synth/summary.txt` |
| No unintended latches | met: 0 latches after `proc` and after full synthesis, all configurations | `reports/lint/`, `reports/synth/` |

Full run: `reports/REGRESSION_SUMMARY.md`. No clock frequency, area or power
figure is claimed anywhere (see `docs/KNOWN_LIMITATIONS.md`).

## Quick start

Prerequisites (versions used): Verilator 5.020, Icarus Verilog 12, Yosys
0.33 (with `yosys-smtbmc`), gcc, Python 3 with cocotb 1.9.2, numpy, gmpy2
(MPFR 4.2), z3 ≥ 4.12 for the formal control proof (PyPI `z3-solver` 5.3.3
was used). On Ubuntu 24.04:

```bash
sudo apt-get install -y verilator iverilog yosys build-essential
```

```bash
pip install "cocotb==1.9.2" gmpy2 numpy z3-solver
```

Then:

```bash
make quick       # ~5 min smoke regression (4 CPUs)
```

```bash
make regress     # full regression -> reports/REGRESSION_SUMMARY.md
```

Individual targets: `make ref lint formal oracle vtb testfloat cocotb synth`.
SoftFloat and TestFloat are vendored (pinned Release 3e) and built locally by
`ref/build_ref.sh`; no network access is needed.

## Interface (summary)

```
fp32_fma #(TAG_W=8, PIPE_CFG=5'b11110, NAN_PROPAGATE=0, TININESS_AFTER_ROUNDING=1)
  clk, rst_n (async assert, active low)
  in_valid  -> in_ready  : in_a, in_b, in_c [31:0], in_rm [2:0], in_tag [TAG_W-1:0]
  out_valid -> out_ready : out_result [31:0], out_flags [4:0] = {NV,DZ,OF,UF,NX}, out_tag
```

* Latency `1 + popcount(PIPE_CFG)`: 5 cycles by default (1…6 available),
  initiation interval 1 (verified).
* `in_rm`: 0 RNE, 1 RTZ, 2 RDN, 3 RUP, 4 RMM (RISC-V `frm`); 5–7 → RNE.
* NaN results: canonical `0x7FC00000` (default, RISC-V) or payload
  propagation (`NAN_PROPAGATE=1`, SoftFloat ARM-VFPv2 rules).
* Tininess after rounding (default, RISC-V/x86) or before (Arm).

Details: `docs/PIPELINE.md`.

## Repository inspection (what existed, what was reused)

The Aureom.AI repository holds SilicaFlux material mostly as archives
(`SilicaFlux-main/*.zip`, `silicaflux*.zip`) and `.sf` SystemVerilog sources.
They were extracted read-only and inspected:

* **Floating-point RTL / FP reference models:** none. The SilicaFlux 2.5
  `vector_engine.sf` reserves opcode class `7x` ("floating-point fusion
  class, steered to the FP datapath") and exports `iss_fpx_o`, but no FP
  datapath exists — this module is that missing unit. No existing arithmetic
  module was modified.
* **Arithmetic units:** integer ALUs, fixed-point DSP (`dsp_arithmetic`), a
  `digital_lib` with adders/multipliers (Wallace multiplier limited to
  4/8/16-bit operands, so not usable for 24 × 24), integer MAC/systolic
  arrays (`silicafluxai`), SHA-256 datapaths.
* **Conventions adopted** (from `silicaflux-v`, the most complete flow, and
  `silicafluxai`): `clk` / active-low `rst_n` with asynchronous assertion and
  externally synchronised release; only valid/pointer state is reset, datapath
  flops are not; `in_valid/in_ready/out_valid/out_ready` naming as in
  `sfx_skid_buffer`; `` `default_nettype none ``; lint = Verilator `-Wall`
  plus Yosys elaboration with a latch check; cocotb 1.9 unit tests; Yosys
  synthesis; the same tool versions (Verilator 5.020, Icarus 12, Yosys 0.33).
* **Missing dependencies → isolated implementation:** there is no integrated
  SilicaFlux build tree to plug into, so the module is self-contained with
  its own references, testbenches and scripts.

## Layout

```
rtl/            fp32_fma.sv (top) + one module per functional step, files.f
  fp32_fma_pkg.sv     constants, payload structs, rounding functions
  fp32_fma_unpack.sv  step 1  classification / unpacking
  fp32_fma_prep.sv    step 2  pre-normalisation, exponents, special cases
  fp32_fma_mul.sv     step 3  24x24 multiplier (generic; swappable)
  fp32_fma_align.sv   step 4  addend alignment (shift-right-jam)
  fp32_fma_add.sv     step 5  signed accumulation
  fp32_fma_norm.sv    step 6  LZC + normalisation + exponent classification
  fp32_fma_round.sv   step 7  denormalisation + rounding + tininess
  fp32_fma_except.sv  step 8  exception flags
  fp32_fma_pack.sv    step 9  output packing
  fp32_fma_lzc.sv     log-depth leading-zero counter
  fp32_fma_stage.sv   elastic valid/ready boundary (optional register)
ref/            SoftFloat adapter (C shim + Python), MPFR cross-check, vectors, REFERENCE.md
tb/cocotb/      cocotb tests (Icarus/Verilator), scoreboard vs SoftFloat
tb/verilator/   high-volume C++ differential harness (SoftFloat in-process, TestFloat stream)
formal/         LZC equivalence proof; pipeline-control BMC harness
synth/          Yosys synthesis smoke tests
scripts/        lint, regressions, builds
docs/           PIPELINE.md, LATENCY_THROUGHPUT.md, VERIFICATION_REPORT.md, KNOWN_LIMITATIONS.md
third_party/    Berkeley SoftFloat-3e and TestFloat-3e (BSD-3-Clause, unmodified)
reports/        logs and summaries of the last regression
```

## Deliverables

| requested | file(s) |
|---|---|
| `fp32_fma.sv` | `rtl/fp32_fma.sv` |
| supporting RTL | `rtl/fp32_fma_*.sv` |
| floating-point reference adapter | `ref/fp32ref_shim.c`, `ref/fp32_ref.py`, `ref/mpfr_ref.py`, `ref/REFERENCE.md` |
| unit tests | `tb/cocotb/`, `tb/verilator/`, `formal/` |
| synthesis smoke test | `synth/run_synth.sh` |
| pipeline documentation | `docs/PIPELINE.md` |
| latency/throughput report | `docs/LATENCY_THROUGHPUT.md` |
| known limitations | `docs/KNOWN_LIMITATIONS.md` |
| verification evidence | `docs/VERIFICATION_REPORT.md`, `reports/` |

## Licensing

Third-party code: Berkeley SoftFloat Release 3e and Berkeley TestFloat
Release 3e, © The Regents of the University of California, BSD-3-Clause
(licence texts in `third_party/*/COPYING.txt`), vendored unmodified. GNU MPFR /
GMP / gmpy2 (LGPL-3.0-or-later) are used as installed Python dependencies and
are not redistributed. The SilicaFlux-HPC sources in this package carry no
separate licence statement; they follow the licensing of the Aureom.AI
repository.
