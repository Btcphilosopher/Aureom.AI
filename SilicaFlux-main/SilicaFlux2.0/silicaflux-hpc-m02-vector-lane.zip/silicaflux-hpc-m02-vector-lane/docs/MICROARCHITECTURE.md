# `hpc_vector_lane` — microarchitecture

## 1. Block diagram and pipeline

```
            in_valid/ready  op a b c rm tag lane_en
                   |
   ACC  +----------v-----------------------------------------------+
        | accept (in_valid & in_ready)   decode (op, rm legality)  |
        | lane_en=0 -> consume only       allocate slot = tail     |
        | illegal   -> slot marked done+illegal, no unit           |
        +----------+-----------------------------------------------+
                   | issue = accept & lane_en & legal
   ISS  +----------v-----------------------------------------------+
        | issue register: one-hot unit valid, slot id, a b c, rm,  |
        | sub/neg_prod/neg_add, misc-op       (operand routing)     |
        +--+---------+----------+-----------+-----------+-----------+
           |         |          |           |           |
   EXE   FADD      FMUL       FMA         MISC        IMUL      (fixed latency,
         A|B1|B2   A|B1|B2    A|B|C1|C2   1 seg       1 seg      fully pipelined,
         L=3       L=3        L=4         L=1         L=2        never stall)
           |         |          |           |           |
           +----+----+-----+----+-----+-----+-----+-----+
                | (valid, slot id, result, flags) per unit
   ROB  +-------v--------------------------------------------------+
        | ROB_DEPTH slots: done, illegal, tag, result, flags       |
        | completion: unit u writes slot id_u (any order)          |
        | retire: head slot when done, strictly oldest first       |
        +----------+-----------------------------------------------+
                   |
            out_valid/ready  result flags tag illegal
```

The brief's seven pipeline functions map onto these stages as follows:

| Brief | Stage |
|---|---|
| 1. input acceptance | ACC |
| 2. opcode decoding | ACC |
| 3. operand routing | ACC → ISS |
| 4. arithmetic execution | EXE |
| 5. result selection | EXE (unit result mux) and ROB write |
| 6. exception propagation | flags travel with the result through the unit pipeline into the slot |
| 7. output completion | RET |

## 2. Ordering policy: in-order completion through a reorder buffer

**Chosen:** in-order completion with a small reorder buffer (ROB). Tagged out-of-order completion
was rejected.

* **Why.** The SilicaFlux vector sequencers and the RISC-V `fflags` model expect results and
  exceptions in program order. Out-of-order delivery would push reordering, `fflags` accumulation
  ordering and precise illegal-instruction reporting onto every consumer. A per-lane ROB of a few
  entries is cheap. In the default configuration it is about 2.7k generic cells including control,
  out of 22.4k for the whole lane.
* **Allocation.**
  * At acceptance an enabled operation takes the slot at `tail`, which advances.
  * The tag is written into the slot at that moment.
  * A legal operation's `done` bit is cleared. An illegal operation's `done` and `illegal` bits are
    set immediately.
* **Completion.** Each unit carries the slot id through its pipeline alongside the data. On exit
  it writes `result`/`flags` into that slot and sets `done`.
  * Several units can complete in the same cycle. They always target different slots, because one
    operation issues per cycle and each operation goes to exactly one unit.
  * The ROB therefore has one write port per unit. No arbitration is needed and no unit ever waits.
* **Retirement.**
  * `out_valid_o = done[head]`; the outputs are a mux of the head slot.
  * On handover, `head` advances and `done[head]` clears.
  * Retirement is strictly oldest-first.
* **Credit rule.** `in_ready_o = init_done && count != ROB_DEPTH`.
  * Each accepted enabled operation already owns its slot, so a completing unit always has a
    destination.
  * That is why the execution pipelines have **no stall logic**: they are plain valid/data shift
    registers (`hpc_pipe`).
* **Throughput.**
  * A slot is held from the cycle after acceptance (*t*+1) up to and including the retirement cycle
    (*t*+L+1). It can be refilled at *t*+L+2.
  * A stream of latency-L operations therefore sustains `min(1, ROB_DEPTH/(L+2))` operations per
    cycle. Measurement matches this exactly (`docs/LATENCY_THROUGHPUT.md`).
  * A combinational `out_ready_i → in_ready_o` bypass would buy one slot. It was deliberately not
    added, to keep both interfaces registered.
* **Simulation-only structural assertions** (`` `ifndef SYNTHESIS ``) fire `$fatal` on:
  * two completions into one slot;
  * completion into a free or already-complete slot;
  * retirement or allocation of the wrong slot;
  * counter overflow or underflow.

  They were never triggered in any run.

## 3. Execution-unit contract

Every unit has the ports `valid_i, id_i, operands, control → valid_o, id_o, res_o, flags_o` with a
**fixed** latency parameter `LAT`. "Latency" counts cycles from the issue register to the ROB
write, inclusive:

* the unit has `LAT − 1` internal register stages;
* its final combinational segment writes the ROB directly, so the ROB slot is the last pipeline
  register;
* end to end, accepted in cycle *t* means visible in cycle *t* + LAT + 1.

Each unit is built from fixed combinational *segments*:

| Unit | Segments (minimum latency) | What `LAT` above the minimum buys |
|---|---|---|
| `hpc_fp32_add` | A: unpack, specials, magnitude swap, exact alignment, add/sub · B: LZC, normalise, round (2) | +1: cuts B into B1 (normalise) and B2 (round). Further stages are output registers (retiming slack). |
| `hpc_fp32_mul` | A: unpack, specials, 24×24 product · B: LZC, normalise, round (2) | +1: B1/B2 split, then output registers. |
| `hpc_fp32_fma` | A: unpack, specials, normalise a/b, 24×24 product ∥ addend alignment · B: 82-bit add/sub, absolute value · C: LZC, normalise, round (3) | +1: C1/C2 split, then output registers. |
| `hpc_fp32_misc` | one segment (1) | output registers |
| `hpc_int32_mul` | one segment (1) | output registers |

The defaults (FADD 3, FMUL 3, FMA 4, MISC 1, IMUL 2) use the split everywhere. They give four
distinct latencies, so the reorder path is exercised all the time. The data registers in `hpc_pipe`
load only when their stage is valid; this acts as a clock enable, so idle units do not toggle.

## 4. FP32 datapaths

All three FP units share `hpc_fp32_round` (round, denormalise, pack, OF/UF/NX) and `hpc_lzc`
(log-depth leading-zero counter, exhaustively tested at width 24 and over ~1.7M structured inputs
at widths 48, 51 and 81). Special operands (NaN, ∞, invalid combinations, exact zeros) are resolved
in segment A and bypass the rounder.

### 4.1 Adder: exactness of the 50-bit alignment

* The larger-magnitude operand *X* is placed at bits `[49:26]`.
* The smaller operand *Y* is shifted right by the exponent difference *d*.
* For *d* ≤ 26 every bit of *Y* stays inside the 50-bit field, so the sum is **exact**.
* For *d* ≥ 27, *Y* < 2²⁴·2⁻²⁷ = ⅛ ulp(*X*). The exact result lies strictly inside
  (*X* − ulp/8, *X* + ulp/8). The only rounding boundary in that interval is *X* itself: the
  nearest midpoints sit at ±ulp/4 even when the result drops into the binade below.
* So *Y* can be replaced by any value in (0, ulp/8). The RTL uses one sticky bit at bit 0 and gets
  the identical result and NX flag.
* Mutant M09 (collapsing *Y* already at *d* > 20) is caught by the tests.

### 4.2 Multiplier

* The 48-bit product of the two 24-bit significands is exact. Subnormal operands enter with a 0
  hidden bit.
* Normalisation: LZC on the product, shift, and exponent `ea + eb − 126 − lz`.
* Rounding needs only the top 24 bits, the guard bit and an OR (sticky) of the remaining 23 bits.

### 4.3 FMA alignment frame

* a and b are first normalised (leading one at bit 23), so P = sig_a·sig_b ∈ [2⁴⁶, 2⁴⁸).
* P sits at frame bits `[49:2]` of an 80-bit frame. The addend significand C goes at bit
  `2 + d`, where d = exponent(LSB of c) − exponent(LSB of P).
* The sum is computed in 82 bits as `P·4 ± C_frame − sticky`.

Three cases:

* **0 ≤ shift ≤ 80.** C is exact in the frame, except for bits below bit 0. Those occur only when
  d ≤ −3, i.e. C < 2²³ while P·4 ≥ 2⁴⁸. The result then has its leading one at bit ≥ 47, so the
  spilled bits lie ≥ 24 positions below the rounding point. They are collapsed into a sticky bit
  that is subtracted as a borrow for effective subtraction:
  `P − (C_hi + c_lo) = (P − C_hi − 1) + (1 − c_lo)`.
* **shift < 0** (c dominates). C is clamped to `[79:56]`. P·4 < 2⁵⁰ is then more than six binades
  below C's LSB, i.e. inside (0, ulp_C/8). By the same argument as §4.1 it affects only sticky and
  borrow, and gives the identical rounding and NX.
* **Negative sum** (|C| > |P|). This implies no spilled bits, so the exact two's complement is
  correct. A simulation assertion checks this, and it never fired.

Zero product, zero addend, ∞ and NaN cases are resolved before the frame. A zero addend forces the
unclamped frame. Mutants M06 (sticky dropped), M07 (frame off by one bit) and M25 (product
negation lost) are all caught.

### 4.4 Rounder (`hpc_fp32_round`)

* **Input.** A normalised `1.sig × 2^(exp−127)` with an unbounded 12-bit signed exponent, plus
  guard and sticky.
* **Tininess.** Detected *after* rounding: the value is tiny if rounding to 24 bits with an
  unbounded exponent leaves it below 2⁻¹²⁶.
* **Subnormal results.** For `exp < 1` the value is shifted right with sticky collection, then
  rounded once on the subnormal grid. A carry out of the subnormal field produces the smallest
  normal number without extra logic, because rounding adds the increment to `{exp_field, frac}`.
* **Overflow.** `exp ≥ 255` before or after rounding raises OF and NX. The result is ±∞ or ±max
  finite according to rounding mode and sign.

## 5. Implementation figures (Yosys 0.33, generic gates; see `docs/SYNTHESIS.md`)

| Block (standalone, flattened, default latency) | Generic cells | Longest path (generic cells) and where |
|---|---|---|
| `hpc_fp32_add` (LAT 3) | 2,751 | 51 — segment A (alignment and add) |
| `hpc_fp32_mul` (LAT 3) | 5,083 | 45 — segment B2 (round) |
| `hpc_fp32_fma` (LAT 4) | 8,824 | 53 — segment A (normalise a/b, 24×24 product) |
| `hpc_fp32_misc` (LAT 2) | 1,000 | 30 |
| `hpc_int32_mul` (LAT 2) | 3,101 | 36 |
| **`hpc_vector_lane`** (defaults, flattened) | **22,444** (1,177 flip-flops, 40 with asynchronous reset) | **51** — issue register → FMA segment A |

"Generic cells" and "path length" are structural indicators. They are **not** area in µm² and
**not** timing (§ no-frequency statement in `docs/SYNTHESIS.md`).
