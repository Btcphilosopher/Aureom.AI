# `hpc_vector_lane` — interface specification

SilicaFlux-HPC Module 02 · source `rtl/hpc_vector_lane.sv` · encodings `rtl/hpc_vector_pkg.sv`

## 1. Parameters

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `DATA_W` | 32 | 32 | Operand and result width. This version is FP32/INT32 only; any other value fails elaboration. |
| `TAG_W` | 8 | ≥ 1 | Transaction tag width. |
| `ROB_DEPTH` | 8 | ≥ 1 | Completion slots, i.e. the maximum number of operations accepted but not yet retired. Full throughput for unit latency L needs `ROB_DEPTH ≥ L + 2` (§5). |
| `LAT_FADD` | 3 | ≥ 2 | FADD/FSUB pipeline latency (§4). |
| `LAT_FMUL` | 3 | ≥ 2 | FMUL latency. |
| `LAT_FMA` | 4 | ≥ 3 | FMADD/FMSUB/FNMSUB/FNMADD latency. |
| `LAT_MISC` | 1 | ≥ 1 | FMV/FMIN/FMAX/FEQ/FLT/FLE/IADD latency. |
| `LAT_IMUL` | 2 | ≥ 1 | IMUL latency. |
| `EN_FCMP` | 1 | 0/1 | When 0, FMIN/FMAX/FEQ/FLT/FLE logic is removed and those opcodes are illegal. |
| `EN_INT` | 1 | 0/1 | When 0, IADD/IMUL logic is removed and those opcodes are illegal. |

An out-of-range parameter instantiates a deliberately undefined module named
`hpc_param_error_<reason>`, so elaboration fails in every tool.

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk_i` | in | 1 | Clock. All state is rising-edge triggered. |
| `rst_ni` | in | 1 | Active-low reset. Assertion is asynchronous; de-assertion must be synchronous to `clk_i` (the SoC reset synchroniser, e.g. `sfv_rst_sync`). |
| `in_valid_i` | in | 1 | An operation is offered. |
| `in_ready_o` | out | 1 | The lane can accept an operation this cycle. |
| `in_op_i` | in | 5 | Operation code (§3). |
| `in_a_i`, `in_b_i`, `in_c_i` | in | `DATA_W` | Operands a, b, c (§3). |
| `in_rm_i` | in | 3 | Rounding mode: RNE=0, RTZ=1, RDN=2, RUP=3, RMM=4 (`silicaflux_pkg::fp_rm_e`). |
| `in_tag_i` | in | `TAG_W` | Transaction tag, returned unchanged with the result. |
| `lane_en_i` | in | 1 | Lane enable for this operation (§8). |
| `out_valid_o` | out | 1 | A result is presented. |
| `out_ready_i` | in | 1 | The consumer takes the result this cycle. |
| `out_result_o` | out | `DATA_W` | Result. |
| `out_flags_o` | out | 5 | IEEE exception flags `{NV,DZ,OF,UF,NX}` (RISC-V `fflags` order; DZ is never set). |
| `out_tag_o` | out | `TAG_W` | Tag of the operation the result belongs to. |
| `out_illegal_o` | out | 1 | The operation was illegal (§9). |
| `busy_o` | out | 1 | At least one accepted operation has not yet retired. |
| `ev_accept_o` | out | 1 | Event: enabled operation accepted (§7). |
| `ev_retire_o` | out | 1 | Event: result handed over. |
| `ev_pipe_stall_o` | out | 1 | Event: operation offered but not accepted because no completion slot is free. |
| `ev_backpressure_o` | out | 1 | Event: result presented but not taken. |
| `ev_illegal_o` | out | 1 | Event: illegal operation accepted. |
| `ev_masked_o` | out | 1 | Event: disabled operation consumed. |

## 3. Operations (`hpc_vector_pkg`)

| `in_op_i` | Name | Result | Operands used | Uses `in_rm_i` | Flags it can raise | Unit (default latency) |
|---|---|---|---|---|---|---|
| `0x00` | FMV | `a`, bit-exact (NaN payload kept) | a | no | none | MISC (1) |
| `0x01` | FADD | a + b | a, b | yes | NV OF UF NX | FADD (3) |
| `0x02` | FSUB | a − b | a, b | yes | NV OF UF NX | FADD (3) |
| `0x03` | FMUL | a × b | a, b | yes | NV OF UF NX | FMUL (3) |
| `0x04` | FMADD | (a×b) + c, one rounding | a, b, c | yes | NV OF UF NX | FMA (4) |
| `0x05` | FMSUB | (a×b) − c | a, b, c | yes | NV OF UF NX | FMA (4) |
| `0x06` | FNMSUB | −(a×b) + c | a, b, c | yes | NV OF UF NX | FMA (4) |
| `0x07` | FNMADD | −(a×b) − c | a, b, c | yes | NV OF UF NX | FMA (4) |
| `0x08` | FMIN | minimumNumber(a, b) | a, b | no | NV | MISC (1) |
| `0x09` | FMAX | maximumNumber(a, b) | a, b | no | NV | MISC (1) |
| `0x0A` | FEQ | 1 if a = b (quiet) else 0 | a, b | no | NV (sNaN only) | MISC (1) |
| `0x0B` | FLT | 1 if a < b (signalling) else 0 | a, b | no | NV (any NaN) | MISC (1) |
| `0x0C` | FLE | 1 if a ≤ b (signalling) else 0 | a, b | no | NV (any NaN) | MISC (1) |
| `0x10` | IADD | (a + b) mod 2³² | a, b | no | none | MISC (1) |
| `0x11` | IMUL | (a × b) mod 2³² (low half, signed = unsigned) | a, b | no | none | IMUL (2) |
| others | reserved | illegal (§9) | none | n/a | none | none |

Operands not listed for an opcode are ignored, and the testbench randomises them. Floating-point
behaviour (NaN, flags, tininess, zero signs) is specified in `docs/FP_SEMANTICS.md`.

## 4. Timing and handshake contract

* **Acceptance.** An operation is accepted at a rising edge where `in_valid_i && in_ready_o`. All
  `in_*` fields and `lane_en_i` are sampled at that edge only. The lane puts no stability
  requirement on `in_*` while it is not ready; AXI-Stream-style producers that hold the payload
  stable are fully compatible.
* **`in_ready_o`** is a function of registered state only:
  `in_ready_o = init_done && (occupied_slots != ROB_DEPTH)`. It never depends combinationally on
  any input, including `in_valid_i`, `in_op_i`, `lane_en_i` and `out_ready_i`.
* **Result handover** happens at a rising edge where `out_valid_o && out_ready_i`.
  * `out_valid_o`, `out_result_o`, `out_flags_o`, `out_tag_o` and `out_illegal_o` are functions of
    registered state only.
  * While `out_valid_o && !out_ready_i`, the outputs stay valid and every payload bit stays
    constant.
  * `out_valid_o` never falls without a handover.
  * When `out_valid_o = 0`, every payload output is driven to 0. The interface is deterministic and
    X-free even though datapath registers are not reset.
* **No combinational path** exists from any input to `in_ready_o` or to any `out_*` output. The
  `ev_*` outputs are deliberately combinational from the handshake signals so a counter block sees
  each event in the same cycle (§7).
* **Latency.** If an operation is accepted in cycle *t*, the earliest cycle in which its result can
  be presented is *t* + `LAT_unit` + 1. Illegal operations take *t* + 1. A result is presented
  later than that only while an older operation is still incomplete (in-order completion) or while
  results are backpressured. Measured values are in `docs/LATENCY_THROUGHPUT.md`.

## 5. Completion semantics: in-order

* Every accepted **enabled** operation produces **exactly one** result, and results are delivered
  in **acceptance order**. There are no drops, no duplicates and no reordering, whatever the mix of
  unit latencies, stalls or backpressure.
* `out_tag_o` is the `in_tag_i` that was sampled with that operation. Because order is preserved,
  tags do not need to be unique for correct association. They are returned purely for the
  consumer's bookkeeping.
* Execution units of different latencies finish out of order. Each operation owns a completion
  slot from acceptance until retirement, its result is written into that slot, and slots retire
  strictly oldest-first (`docs/MICROARCHITECTURE.md`).
* Throughput: a slot is reusable `LAT + 2` cycles after its operation was accepted, so a stream of
  latency-L operations sustains `min(1, ROB_DEPTH / (L + 2))` operations per cycle. The defaults
  (`ROB_DEPTH = 8`, largest latency 4) sustain 1 operation per cycle for any mix.

## 6. Stall semantics

* **Input stall.** `in_ready_o = 0` while all `ROB_DEPTH` slots are occupied, whether by operations
  executing or by results awaiting handover, and during reset and the initialisation cycle (§7a).
  `ev_pipe_stall_o` pulses for each cycle in which an operation is offered but cannot be accepted
  for that reason.
* **Execution pipelines never stall.** An operation is accepted only when it owns a slot, so a
  unit result always has somewhere to go. Backpressure therefore cannot stall, drop or corrupt
  arithmetic in flight; it only fills slots with completed results.
* **Output backpressure.** Holding `out_ready_i = 0` holds the oldest result (`ev_backpressure_o`
  pulses). Younger operations keep executing and completing into their slots. Once every slot is
  occupied the input stalls. Releasing `out_ready_i` drains results in order at one per cycle.

## 7. Reset, initialisation and performance events

**a. Reset**
* Asserting `rst_ni` (asynchronously, at any time) immediately forces:
  `in_ready_o = 0`, `out_valid_o = 0`, `busy_o = 0`, every `ev_*` = 0, and all payload
  outputs = 0.
* **All operations in flight are discarded.** No result is ever produced for an operation
  accepted before the reset.
* `in_valid_i` is ignored while reset is asserted.
* After de-assertion, `in_ready_o` stays 0 during the first clock cycle (an initialisation
  register), so the first acceptance can happen at the **second** rising edge after reset release.
  No transfer can coincide with reset recovery.
* Reset is deterministic. Every control register is reset to a constant: occupancy counter, head
  and tail pointers, completion and illegal bits, issue valids and pipeline valids. Datapath
  registers (operands, intermediate values, stored results) are not reset. That follows the
  SilicaFlux rule that valid-qualified datapath state needs no reset. They are never observable,
  as shown by 4-state simulation of the RTL and the netlist.

**b. Events** (single-cycle pulses, intended for an `hpc_perf_counters`-style counter block)

| Output | Asserted in a cycle where … | Exact definition |
|---|---|---|
| `ev_accept_o` | an **enabled** operation is accepted. Illegal operations count, disabled ones do not. | `in_valid_i & in_ready_o & lane_en_i` |
| `ev_retire_o` | a result is handed over | `out_valid_o & out_ready_i` |
| `ev_pipe_stall_o` | an operation is offered but no completion slot is free (not counted in the initialisation cycle) | `in_valid_i & ~in_ready_o & init_done` |
| `ev_backpressure_o` | a result is presented but not taken | `out_valid_o & ~out_ready_i` |
| `ev_illegal_o` | an enabled illegal operation is accepted | `ev_accept_o & illegal` |
| `ev_masked_o` | a disabled operation is consumed | `in_valid_i & in_ready_o & ~lane_en_i` |

Invariant once the lane is idle (`busy_o = 0`) with no reset in between: Σ `ev_accept_o` =
Σ `ev_retire_o`. The testbench checks every pulse every cycle, plus these totals.

## 8. Lane masking (`lane_en_i`)

* `lane_en_i` is sampled together with the operation, so it acts as a per-operation mask bit.
* A **disabled** operation (`lane_en_i = 0` at acceptance):
  * is consumed by the same `in_valid_i`/`in_ready_o` handshake as an enabled one; `in_ready_o`
    does not depend on `lane_en_i`;
  * is **not decoded, not executed and takes no completion slot**; no execution unit toggles;
  * produces **no result**: no `out_valid_o`, no flags, no `out_illegal_o`, no `ev_illegal_o`,
    even if its opcode is reserved;
  * changes no lane state at all, and pulses `ev_masked_o`.
* Operations already in flight are unaffected by later values of `lane_en_i`.
* **Why the handshake still completes.** A lock-step multi-lane sequencer broadcasts one operation
  to N lanes and ANDs their ready signals. A disabled lane occupies no slot, so its `in_ready_o` is
  high whenever the enabled lanes' is. Masking a lane therefore never stalls the group.
* Merge/undisturbed policy for masked vector elements (e.g. `MPOL_PASS`/`MPOL_ZERO` in
  `vector_engine.sf`) belongs to the vector register-file write mask in the sequencer. The lane
  only guarantees that a masked element produces nothing.

## 9. Illegal operations

An enabled operation is illegal if **any** of the following holds:
* its opcode is reserved;
* its opcode is removed by `EN_FCMP = 0` / `EN_INT = 0`;
* it is a rounding operation (FADD, FSUB, FMUL, FMA family) with `in_rm_i` ∈ {5, 6, 7}. Dynamic
  rounding (`RM_DYN = 7`) must be resolved by the issuing core.

An illegal operation:
* is accepted and takes a completion slot;
* pulses `ev_illegal_o`;
* completes **in order** one cycle after acceptance, with `out_illegal_o = 1`,
  `out_result_o = 0` and `out_flags_o = 0`;
* never reaches an execution unit.

The issuing core uses `out_illegal_o` to raise its illegal-instruction trap at the correct point
in program order.

## 10. Integration checklist

1. Synchronise the de-assertion of `rst_ni` to `clk_i`.
2. Resolve dynamic rounding before issue.
3. Size `ROB_DEPTH ≥ max(LAT_*) + 2` for full throughput (the default 8 covers latencies up to 6).
4. Connect `ev_*` to a counter block, or leave them open; they have no internal side effects.
5. Accumulate `out_flags_o` into `fflags` in retirement order (results already arrive in program
   order).
