# Synthesis smoke test

**Script:** `syn/run_synth.sh` (Yosys 0.33)
**Raw outputs:** `reports/synth/` (logs, `stat_*.txt`, `ltp_*.txt`, `unit_depth.txt`)

## What is checked

For each of four parameter sets, all from unmodified RTL:

1. `read_verilog -sv` of the RTL, then `hierarchy -check`: every module resolves and every
   parameter is legal.
2. `synth -flatten`: Yosys generic synthesis with ABC technology mapping to the internal gate
   library.
3. `check -assert`: no combinational loops, no multiple drivers, no used undriven nets.
4. `select -assert-none` on every latch cell type: **no latches inferred**.
5. `stat` for cell counts, and `ltp -noff` for the longest combinational path counted in generic
   cells.
6. For the default configuration, `write_verilog` of the netlist. It is then simulated with the
   same self-checking testbench (`scripts/gatesim.py`, `reports/gatesim.md`).

## Results

| Configuration | Parameters | Generic cells | Latches | `check -assert` | Longest path (generic cells) |
|---|---|---|---|---|---|
| default | D=8, T=8, FADD 3, FMUL 3, FMA 4, MISC 1, IMUL 2 | 22,444 | 0 | pass | 51 (issue reg → FMA seg. A) |
| minlat_d2_t4 | D=2, T=4, all latencies at minimum (no normalise/round split) | 20,332 | 0 | pass | 64 (FMA seg. C → ROB) |
| deep_d16_t12 | D=16, T=12, FADD 4, FMUL 5, FMA 8, MISC 3, IMUL 4 | 26,004 | 0 | pass | 53 |
| nofcmp_noint_d5 | D=5, T=6, `EN_FCMP=0`, `EN_INT=0`, MISC 2, FMA 5 | 18,262 | 0 | pass | 53 |

Default configuration flip-flops: 1,177. Only 40 are asynchronously reset (control state). The
rest are enable-loaded datapath registers, per SilicaFlux coding rule 4.

Per-unit depth (standalone, one spare output stage) is in `reports/synth/unit_depth.txt` and
`docs/MICROARCHITECTURE.md` §5.

### Effect of the structural work done during this module

| Change | FMA longest path | Lane (default) longest path |
|---|---|---|
| Initial RTL: priority-chain LZC, latency only adds output registers | 134 | 134 |
| `LAT > minimum` splits normalise \| round | 94 | 106 (FADD at LAT 2) |
| Log-depth `hpc_lzc` tree, default `LAT_FADD = 3` | **53** | **51** |

Each change was re-verified with the full regression, the mutation campaign and gate-level
simulation.

## No clock-frequency claim

**No clock frequency, timing slack or silicon area is claimed for this module.**

* Generic-cell counts and topological path lengths come from a technology-independent flow. They
  rank pipeline segments against each other and nothing more.
* They do not account for cell delays, fan-out, wires or a real adder or multiplier architecture.
  Yosys's default mapping is not timing-driven: it uses ripple carries and an array multiplier.
* A frequency figure requires synthesis against a characterised standard-cell library (e.g.
  sky130hd or IHP SG13G2, already targeted by the SilicaFlux ASIC flows), SDC constraints and
  static timing analysis on a placed netlist.

## Recommended next steps for an implementation flow

1. Run the SilicaFlux ASIC flow (`silicaflux-v/asic`, OpenROAD) on `hpc_vector_lane` with sky130hd
   or IHP SG13G2 and report post-route timing.
2. If FMA segment A or the 24×24 multipliers are critical, map the significand products to a
   Booth or carry-save structure (e.g. the TimingLab `sf_csa_tree`) and/or raise `LAT_FMA` /
   `LAT_FMUL` with register retiming enabled. The extra output stages are already in place.
3. Leading-zero anticipation in parallel with the FMA adder (segment B) would remove the LZC from
   segment C1. This is an optimisation, not a correctness item.
