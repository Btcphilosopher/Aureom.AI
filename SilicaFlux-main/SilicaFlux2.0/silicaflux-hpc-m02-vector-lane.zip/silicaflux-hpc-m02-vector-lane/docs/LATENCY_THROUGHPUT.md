# Latency and throughput characterisation

Every number below is **measured** in cycle-level RTL simulation (Verilator 5.020,
`scripts/characterize.py`). Each measurement run also passes the self-checking testbench, so the
results are bit-exact and in order. These are **cycle counts only**; no clock frequency is implied
(`docs/SYNTHESIS.md`).

## Analytical model

| Quantity | Formula |
|---|---|
| Latency of an operation accepted in cycle *t* (no older operation pending, no backpressure) | `out_valid_o` first high in cycle *t* + `LAT_unit` + 1. Illegal operations: *t* + 1. |
| Completion-slot occupancy per operation | from *t*+1 through its retirement cycle *t*+L+1; the slot is reusable for an acceptance in cycle *t*+L+2 |
| Sustained throughput, stream of latency-L operations | `min(1, ROB_DEPTH / (L + 2))` operations per cycle |
| Full throughput for any mix | `ROB_DEPTH ≥ max(LAT_*) + 2` (defaults: 8 ≥ 4 + 2) |
| Throughput under output backpressure | bounded by the consumer: retirements ≤ cycles with `out_ready_i = 1` |
| Execution-unit initiation interval | 1 (every unit fully pipelined, no structural hazard between units) |
| Extra latency from in-order completion | an operation retires no earlier than every older operation; the young-after-old penalty is at most `max(LAT) − LAT_young` cycles |

Default latencies: FADD/FSUB 3, FMUL 3, FMA family 4, MISC (FMV, FMIN, FMAX, FEQ, FLT, FLE, IADD)
1, IMUL 2. End-to-end latencies are therefore 4, 4, 5, 2 and 3 cycles, plus 1 cycle for illegal
operations.

## Measured


Default parameters: TAG_W=8, ROB_DEPTH=8, LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2, EN_FCMP=1, EN_INT=1.
All runs PASS the self-checking testbench (bit-exact results, in-order tags).  No clock frequency is implied by any number here.

### 1. Isolated latency (acceptance cycle to retirement cycle)

Every operation is followed by 12 forced idle cycles (`+GAP=12` > any latency), so no operation waits behind another.  Legal-only stream; illegal operations measured separately.

Latency L means: accepted in cycle t (in_valid & in_ready), `out_valid_o` first high in cycle t + L with `out_ready_i` held high.

| opcode | unit latency param | expected (LAT+1) | measured min | measured max | samples |
|---|---|---|---|---|---|
| FMV | LAT_MISC=1 | 2 | 2 | 2 | 1322 |
| FADD | LAT_FADD=3 | 4 | 4 | 4 | 1369 |
| FSUB | LAT_FADD=3 | 4 | 4 | 4 | 1370 |
| FMUL | LAT_FMUL=3 | 4 | 4 | 4 | 1362 |
| FMADD | LAT_FMA=4 | 5 | 5 | 5 | 1322 |
| FMSUB | LAT_FMA=4 | 5 | 5 | 5 | 1311 |
| FNMSUB | LAT_FMA=4 | 5 | 5 | 5 | 1325 |
| FNMADD | LAT_FMA=4 | 5 | 5 | 5 | 1328 |
| FMIN | LAT_MISC=1 | 2 | 2 | 2 | 1354 |
| FMAX | LAT_MISC=1 | 2 | 2 | 2 | 1275 |
| FEQ | LAT_MISC=1 | 2 | 2 | 2 | 1325 |
| FLT | LAT_MISC=1 | 2 | 2 | 2 | 1392 |
| FLE | LAT_MISC=1 | 2 | 2 | 2 | 1333 |
| IADD | LAT_MISC=1 | 2 | 2 | 2 | 1280 |
| IMUL | LAT_IMUL=2 | 3 | 3 | 3 | 1332 |
| illegal opcode / reserved rm | (no unit) | 1 | 1 | 1 | 2432 |

### 2. Back-to-back throughput per operation class vs ROB_DEPTH

Measured retired operations per cycle (P_VALID = P_READY = 100 %), analytical bound min(1, ROB_DEPTH / (LAT + 2)) in brackets.

| class (LAT) | D=1 | D=2 | D=3 | D=4 | D=5 | D=6 | D=8 |
|---|---|---|---|---|---|---|---|
| FMV/FMIN/FEQ (MISC) (LAT_MISC=1) | 0.333 [0.333] | 0.667 [0.667] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] |
| FADD/FSUB (LAT_FADD=3) | 0.200 [0.200] | 0.400 [0.400] | 0.600 [0.600] | 0.800 [0.800] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] |
| FMUL (LAT_FMUL=3) | 0.200 [0.200] | 0.400 [0.400] | 0.600 [0.600] | 0.800 [0.800] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] |
| FMA family (LAT_FMA=4) | 0.167 [0.167] | 0.333 [0.333] | 0.500 [0.500] | 0.667 [0.667] | 0.833 [0.833] | 1.000 [1.000] | 1.000 [1.000] |
| IMUL (LAT_IMUL=2) | 0.250 [0.250] | 0.500 [0.500] | 0.750 [0.750] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] |

### 3. Mixed stream (all opcodes, 5 % illegal) vs ROB_DEPTH

| ROB_DEPTH | ops/cycle | input-stall cycles | OoO completions | max occupancy |
|---|---|---|---|---|
| 1 | 0.240 | 157861 | 0 | 1 |
| 2 | 0.438 | 64162 | 5675 | 2 |
| 3 | 0.609 | 32125 | 8997 | 3 |
| 4 | 0.753 | 16368 | 10680 | 4 |
| 5 | 0.890 | 6198 | 12253 | 5 |
| 6 | 1.000 | 0 | 13663 | 5 |
| 8 | 1.000 | 0 | 13663 | 5 |

### 4. Mixed stream vs output-ready probability (ROB_DEPTH = 8)

| P(out_ready) | ops/cycle | backpressure cycles | input-stall cycles |
|---|---|---|---|
| 100 % | 1.000 | 0 | 0 |
| 75 % | 0.749 | 16791 | 16788 |
| 50 % | 0.500 | 50074 | 50064 |
| 25 % | 0.251 | 149243 | 149228 |

## Observations

* The measured isolated latency equals `LAT + 1` for every opcode, with min = max, and 1 cycle for
  illegal operations.
* Per-class back-to-back throughput matches the analytical bound **exactly** for every ROB depth
  from 1 to 8.
* A mixed stream needs `ROB_DEPTH ≥ 6` (= max latency 4 + 2) for one operation per cycle. Peak
  occupancy is then 5 = max latency + 1, so `ROB_DEPTH = 6` is the minimum full-rate depth for the
  default latencies. The default of 8 leaves headroom for `LAT_FMA` up to 6.
* Under output backpressure, throughput tracks the consumer's acceptance rate exactly (75 % →
  0.749 op/cycle) and no result is lost. The scoreboard checks every result.
