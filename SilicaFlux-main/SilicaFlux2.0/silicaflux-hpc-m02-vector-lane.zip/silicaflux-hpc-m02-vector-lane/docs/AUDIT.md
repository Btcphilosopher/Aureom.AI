# Module 02 — Repository source audit

Audit of `btcphilosopher/aureom.ai` (branch `claude/adoring-faraday-q0qrub`, HEAD `579de89`), done
before any RTL was written. The repository has no loose HDL. All SilicaFlux material is in
archives (`*.zip`, including zips inside zips) and in SystemVerilog-syntax `.sf` files. I extracted
every SilicaFlux and Aardvark archive into a private scratch area, recursing up to three levels
deep, and scanned it. Nothing from those archives was executed.

| Item | Count |
|---|---|
| Archives extracted and scanned (including nested) | 55 |
| `.sv` / `.v` / `.svh` files inside them | 1,404 |
| Unique module names (archives + repository `.sf` files) | 629 |
| `.sf` files in the repository tree | 33 |

## 1. Floating-point arithmetic: **missing**

* **No `fp32_fma.sv` exists.** No file or module anywhere in the repository has `fma`, `fpu`,
  `float`, `fp32` or `ieee` in its name. None of the 629 module names is an FP datapath.
* `SilicaFlux-main/silicaflux_pkg.sf` (the architectural package) contains FP **encodings only**:
  * `fp_op_e` (`FPU_FADD`, `FPU_FMADD`, …, 29 entries)
  * `fp_rm_e` (RISC-V `frm` encoding)
  * `fflags_t` (`{nv,dz,of,uf,nx}`)
  * `FU_FMA`, `VEC_VFMACC`, `TDT_FP32`

  Nothing implements them.
* `SilicaFlux2.0/SilicaFlux2.5/vector_engine.sf` decodes an opcode class `7x` ("floating-point
  fusion class") and steers it out through `iss_fpx_o` to "the FP datapath". **No such datapath
  exists** in the repository.
* `SilicaFluxML/rtl/action_selector.sv` mentions floating point only to say it is used for
  *software-side* comparison.

**Blocker (reported as the brief requires):** there is no FP32 FMA, FP32 adder or FP32 multiplier
to reuse, validated or not.

**Resolution in this deliverable.** I took both routes the brief allows:

1. The lane control path does not depend on any particular arithmetic core. It talks to its
   execution units through one contract: valid, slot-id, result and flags out after a fixed
   latency. It is verified under six parameter sets with latencies from 1 to 8 cycles.
2. I also built and verified the missing arithmetic myself as separate datapaths:
   * `hpc_fp32_add` (ADD/SUB)
   * `hpc_fp32_mul` (MUL)
   * `hpc_fp32_fma` (FMADD/FMSUB/FNMSUB/FNMADD)

   ADD and MUL are **not** derived from the FMA.

   The arithmetic is checked bit for bit, including all exception flags, against an exact
   reference model. That model is itself checked against the host CPU's IEEE-754 hardware.
   Nothing here relies on a "pretend" FP result.

## 2. Existing vector RTL — integer only

| Source | What it is | Relevance |
|---|---|---|
| `silicaflux-v` `rtl/accel/sfv_vec_engine.sv` (`silicaflux-v-release1.zip`, also vendored into datafabric, floorplanlab and timingflow) | LANES-wide **integer** SIMD engine, memory to memory over the tile scratchpad. Ops: `VOP_ADD … VOP_DOT` (`sfv_pkg`) | Integer only; register-bus programmed. Could later drive a stream of lane operations. |
| `SilicaFlux2.5/vector_engine.sf`, `silicaflux.zip` `rtl/vector_engine.sv` | Integer lane-parallel engine with masking (`active[l] = (l < vl) & (mask[l] \| ~mask_en)`), speculation and flush. FP class is steered out (`iss_fpx_o`) | Its masking semantics influenced the `lane_en_i` design. FP is explicitly external. |
| `silicaflux-timinglab` `rtl/opt/sf_vector_engine_pipe.sv` | 3-stage re-pipelined version of `vector_engine` | Integer only. |
| `silicaflux-memoryflow` `rtl/accel/sf_vec_unit.sv` | Small integer vector unit | Integer only. |

## 3. CPU arithmetic units

* `silicaflux-v` `sfv_cpu.sv` is **RV32I + Zicsr**: no M extension and no F extension.
* The integer building blocks are in `digital_lib`, `dsp_arithmetic`, `cpu_core`, `pipelined_cpu`
  and `RISC-V CPU`: adders (ripple, CLA, carry-select), `array_multiplier`, `wallace_tree`,
  `barrel_shifter`, `mac_unit`, `sat_arith`, `alu`.
* SilicaFlux TimingLab provides `sf_mul_lo_csa` + `sf_csa_tree` and `sf_mul_lo_pp/sum`. These are
  carry-save low-half multipliers, equivalence-checked against `vector_engine` (`tb_eq_vector.sv`).
  **Reuse decision:** `hpc_int32_mul` keeps an inferred `*` behind a wrapper. The TimingLab
  multiplier is documented as a drop-in replacement for a timing-driven build. It only exists
  inside an archived lab snapshot, which would make this module depend on archive extraction.

## 4. Memory interfaces

The TSPM engine port (`sfv_vec_engine`), the SilicaFlux bus (`docs/BUS.md`) and the DataFabric
crossbar/DMA exist. The lane takes **register operands**, so loading and storing operands is the
job of the sequencer or vector engine that feeds it. No memory interface was needed.

## 5. Performance counters

`silicaflux-datafabric` `rtl/interconnect/sfb_perf_counters.sv` sets the house pattern:
saturating counters, snapshot and clear. The lane exposes single-cycle event pulses designed to
feed a counter block of that style (`docs/LANE_INTERFACE.md` §7). `hpc_perf_counters.sv` itself is
out of scope, as the brief allows.

## 6. Verification infrastructure and house rules adopted

From `silicaflux-v` `docs/RTL_CODING_RULES.md` and `docs/TOOL_VERSIONS.md`:

* **Tools:** Verilator 5.020, Icarus 12.0, Yosys 0.33. I installed exactly these versions and used
  them for every result in this deliverable.
* **Coding subset:**
  * no `import` (use `pkg::NAME`)
  * no `return`, no `inside`, no interfaces, structs or unions, no unpacked-array ports
  * functions assign to their own name
  * `always_ff` uses non-blocking assignments only
  * `always_comb` assigns every output fully
  * async active-low reset with synchronous de-assert supplied externally
  * datapath flops qualified by a valid bit are not reset; control state always is
  * simulation-only code goes under `` `ifndef SYNTHESIS ``

  All of these are followed.
* **Naming and encodings:** `clk_i` / `rst_ni`. Rounding-mode and flag encodings follow
  `silicaflux_pkg.sf` (§7 of that file).
* **What this module adds:** cocotb is listed in `TOOL_VERSIONS.md` but is not installed in this
  environment. The testbenches are plain SystemVerilog, run identically on Verilator, Icarus and
  the post-synthesis netlist, and are driven by Python scripts.

## 7. Independent IEEE reference

Berkeley SoftFloat/TestFloat could not be built here: compiling and running downloaded third-party
code was not permitted in this session. Instead I used two references that I wrote and reviewed:

* **`ref/fp32_hwref.c`.** Drives the host CPU's IEEE-754 hardware (x86-64 SSE + FMA3) through
  `fesetround()` and `fetestexcept()`. It covers RNE, RTZ, RDN and RUP for ADD, SUB, MUL, all four
  FMA forms and the comparisons. It checks that MXCSR DAZ/FTZ are off.
* **`ref/fp32_ref.py`.** An exact model using arbitrary-precision dyadic rationals. It covers every
  opcode and all five rounding modes, RMM included. **2,092,835** vectors were cross-checked
  against the hardware oracle with **0** mismatches. The only differences are 129 vectors of
  `fma(∞, 0, qNaN)`: RISC-V and this lane raise NV, x86 does not. IEEE 754-2019 §7.2 leaves this
  implementation-defined; see `docs/FP_SEMANTICS.md`.

A natural follow-on is TestFloat (`testfloat_gen -tininessafter`, RISC-V specialisation) once a
permitted build environment is available. The vector format is already compatible.
