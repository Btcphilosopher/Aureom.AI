# Verification report

All results below were produced by the scripts in this package (`scripts/run_all.sh`) with
Verilator 5.020, Icarus Verilog 12.0 and Yosys 0.33 on the final RTL. Raw results are in
`reports/`.

## 1. Strategy

```
  ref/gen_vectors.py ── corner-biased operands ──► ref/fp32_ref.py (exact model) ──► expected
          │                                              ▲
          │                                              │ 2,092,835 vectors agree, 0 mismatches
          └──────────────► ref/fp32_hwref.c (x86 SSE/FMA3 hardware, fesetround/fetestexcept)
  expected vectors ──► tb/tb_hpc_vector_lane.sv (scoreboard + protocol/event/X checks)
                         ├─ RTL on Verilator (2-state, full sets, 6 parameter configurations)
                         ├─ RTL on Icarus (4-state, subsets, same 6 configurations)
                         ├─ post-synthesis netlist on Verilator and Icarus
                         └─ 27 RTL mutants + 1 X mutant (verification of the verification)
```

### 1.1 Independent IEEE reference

* **`ref/fp32_ref.py`** computes each operation **exactly** on arbitrary-precision integers and
  rounds once. It has no guard/sticky shortcuts and no alignment frame, so it shares no algorithm
  with the RTL.
* **`ref/fp32_hwref.c`** obtains results and flags from the host CPU's IEEE-754 hardware. FMA uses
  the hardware `VFMADD/VFMSUB/VFNMADD/VFNMSUB` instructions (single rounding). DAZ/FTZ are checked
  to be off.
* **Cross-check** (`reports/crosscheck_hw.txt`): **2,092,835** vectors (FADD, FSUB, FMUL, FMA×4 in
  RNE/RTZ/RDN/RUP, plus FEQ, FLT, FLE, IADD and IMUL) agree in both result and flags, with **0
  mismatches**.
  * 129 FMA vectors of the form ∞·0 + qNaN differ **only** in NV. This is the documented
    RISC-V-versus-x86 choice (`docs/FP_SEMANTICS.md`).
  * RMM, FMIN, FMAX and FMV have no x86 equivalent. They rely on the exact model, whose rounding
    code path the hardware validates in the other four modes. RMM-specific self-tests cover ties.
* Berkeley TestFloat could not be built in this environment (third-party code execution was not
  permitted); see `docs/AUDIT.md` §7.

### 1.2 Vector set (`build/vec`, 3.1 M lines; regenerate with `make vectors`)

| Class | Content | Vectors |
|---|---|---|
| `rand_<op>` × 7 rounding ops | 60,000 per op × rm. TestFloat-style biased exponents and structured significands (runs of ones/zeros, single set/clear bits), plus constructed hard cases: massive cancellation, exponent differences across the alignment window, products straddling overflow/underflow, FMA addend ≈ −product, addend negligible vs. dominant, subnormal products | 2,100,000 |
| `spec_<op>` | Full cross products of 34 special/boundary encodings (±0, ±∞, qNaN/sNaN with payloads, min/max subnormal and normal, 1±ulp, 2^±24, 2^±64 …), 18³ for FMA, all 5 rm | 136,140 |
| `misc` | FMV, FMIN, FMAX, FEQ, FLT, FLE, IADD, IMUL: special cross product + 60,000 random each (incl. equal / ±0 / adjacent pairs) | 489,248 |
| `illegal` | All 17 reserved opcodes and reserved rm 5/6/7 on every rounding op | 2,432 |
| `mixed` | 300,000 operations sampled uniformly over all legal opcodes, 5 % reserved | 300,000 |
| `order` | 100,005 latency-inversion bursts: each long-latency op followed by 1–6 short or illegal ops | 100,005 |

**Functional coverage** (`reports/coverage.md`): for every one of the 35 opcode × rounding-mode
bins, NV, OF, UF, NX, exact results, exact rounding ties, tininess, subnormal / zero / ∞ / NaN
results are all hit. Ties number 300–2,200 per bin; UF reaches about 10,000 per bin for FMUL. The
**only** zero bins are FADD/FSUB × UF. Those are mathematically infeasible: a subnormal sum is
always exact.

### 1.3 Lane testbench (`tb/tb_hpc_vector_lane.sv`)

**Stimulus**
* Random `in_valid` gaps; the payload is held while not ready and replaced by random garbage while
  invalid.
* Random `out_ready`, random `lane_en`, unique incrementing tags.
* Asynchronous `rst_ni` assertion at a random point within the cycle, with synchronous release.
* Random garbage requests while reset is asserted.

**Checked every cycle**
1. **Scoreboard.** Every retired result must equal the oldest outstanding **enabled** operation in
   result, flags, tag and illegal bit. This detects drops, duplicates, reordering and
   misassociation. Disabled operations must never produce a result.
2. **Protocol.**
   * Output payload stays stable while stalled; `out_valid` never falls without a handover.
   * Payload is 0 when not valid.
   * No acceptance in the first cycle after reset; garbage offered during reset is never accepted.
   * Immediately after asynchronous reset assertion the outputs are at their reset values.
3. **Events.** Each `ev_*` pulse equals its exact definition (`docs/LANE_INTERFACE.md` §7) on every
   cycle. The totals match the handshake totals.
4. **`busy_o`** equals "operations outstanding".
5. **X/Z.** On Icarus (4-state), all outputs are checked every cycle.
6. **Liveness.** No 5,000-cycle window without progress.
7. **Coverage probes** (RTL only):
   * simultaneous multi-unit completions;
   * completion inversions (an operation completes while an older one is still executing);
   * ROB-full cycles and peak occupancy.

The RTL also has simulation-only `$fatal` assertions on slot accounting. None fired in any run.

## 2. Regression results (`reports/regression.md`): **132 / 132 PASS**

Configurations:

| Name | Key parameters | Purpose |
|---|---|---|
| default | D=8, T=8, lat FADD 3 / FMUL 3 / FMA 4 / MISC 1 / IMUL 2 | Shipping default, full throughput |
| minlat_d2_t4 | D=2, T=4, every latency at its minimum (no normalise/round split) | Tiny ROB, constant stalls, unsplit datapaths |
| skew_d3_t1 | D=3, **TAG_W=1**, FADD 5 / FMUL 2 / FMA 7 / IMUL 6 | Extreme latency skew, 1-bit tags |
| d1_t16 | **D=1**, T=16 | Degenerate single slot |
| nofcmp_noint_d5 | D=5 (non-power-of-2 wrap), `EN_FCMP=0`, `EN_INT=0`, MISC 2 / FMA 5 | Optional ops removed (become illegal) |
| deep_d16_t12 | D=16, T=12, FADD 4 / FMUL 5 / FMA 8 / MISC 3 / IMUL 4 | Deep pipelines, many in flight |

Tests (each configuration × each simulator):

| Test | Knobs | Requirement exercised |
|---|---|---|
| `arith:<file>` (default and deep_d16 on Verilator; default on Icarus) | full rate | every opcode, FP corner cases, exception flags, operand routing |
| mixed_b2b | P_VALID = P_READY = 100 % | back-to-back mixed operations, result ordering |
| order_b2b | full rate, latency-inversion bursts | result ordering, OoO completion → in-order retirement |
| stall | P_VALID 70 %, P_READY 40 % | pipeline stalls, ROB full |
| backpressure | P_READY 5 % | sustained output backpressure |
| disabled | P_EN 55 % | disabled lane |
| reset | P_RESET 0.3 %/cycle, P_EN 80 % | reset (asynchronous, mid-stream), deterministic recovery |
| illegal | illegal vectors, random knobs | invalid opcode and reserved rm |

Totals:

| Simulator | Runs | Vectors driven | Enabled ops retired and checked | Masked ops | Illegal ops | Resets | Ops flushed by reset | Cycles |
|---|---|---|---|---|---|---|---|---|
| Verilator (RTL) | 74 | 13,865,972 | 12,657,942 | 1,172,071 | 946,473 | 11,825 | 35,959 | 35.0 M |
| Icarus (RTL, 4-state) | 58 | 994,364 | 912,891 | 79,327 | 101,638 | 719 | 2,146 | 4.0 M |

Accounting closes exactly in both simulators: accepted − retired = flushed by reset
(12,693,901 − 12,657,942 = 35,959; 915,037 − 912,891 = 2,146).

Structural coverage reached on Verilator:
* 930,149 completion inversions, all reordered correctly;
* 556,251 cycles with two or more units completing simultaneously;
* 20.3 M ROB-full cycles;
* peak occupancy equal to `ROB_DEPTH` in every configuration that can fill.

## 3. Unit test: `hpc_lzc`

`tb/tb_hpc_lzc.sv` runs W=24 exhaustively (16,777,216 inputs). For W=48, 51 and 81 it tests zero
and every leading-one position with 2,000 random lower patterns each. **17,137,219 checks, 0
errors** (`reports/lzc_unit_test.txt`).

## 4. Mutation testing (`reports/mutation.md`): **28 / 28 mutants killed**

Each mutant injects one bug and is compiled with `SYNTHESIS` defined, which removes the RTL's own
assertions. Only the black-box testbench can catch it.

| Area | Mutants |
|---|---|
| Rounding | RNE/RMM tie handling, RDN sign, RTZ overflow value |
| Flags | tininess before rounding, FMA ∞·0+qNaN NV, FEQ signalling on a quiet NaN |
| Datapath | FMA sticky dropped, FMA frame misaligned by 1 bit, adder sticky collapse too early, subnormal hidden bit, multiplier bias, exact-zero sign, min/max ordering, INT add |
| Operand routing | FNMADD/FNMSUB negation |
| Lane control | disabled lane executes; accepts when full; retires before oldest completes; tag in wrong slot; result in wrong slot; completion bits not reset; reserved rm accepted; illegal returns stale data; ready during reset |
| Events | stall counted in the initialisation cycle, backpressure without valid |
| X detection (Icarus) | uninitialised storage driven out |

The unmodified control passes every run. During development this campaign exposed one testbench
gap (M21): garbage requests were not driven during reset. The testbench was fixed and all mutants
re-run.

## 5. Post-synthesis gate-level simulation (`reports/gatesim.md`): **22 / 22 PASS**

The Yosys netlist (default configuration) runs the same testbench on Verilator, with full vector
files including 300k mixed / stall / disabled / reset streams, and on Icarus with 4-state 4k
subsets of every test. There is no simulation/synthesis mismatch, and no X escapes the unreset
datapath registers.

## 6. Issues found and fixed during verification

| # | Found by | Issue | Fix |
|---|---|---|---|
| 1 | model vs. smoke vectors | Reference model crashed on a rounding carry to 2²⁴ | Normalise after carry in `round_pack` (model only) |
| 2 | coverage review | "OoO completion" probe only counted inversions against the head | Probe redefined: any completion while an older op is incomplete |
| 3 | coverage review | Mixed stream was 53 % illegal (uniform over 32 code points) | 95 % legal / 5 % reserved weighting |
| 4 | mutation M21 | TB never offered requests during reset | TB drives random garbage requests in reset; must not be accepted |
| 5 | synthesis | Normalise+round in one segment; priority-chain LZCs (lane depth 134) | `LAT > min` now splits normalise \| round; log-depth `hpc_lzc` (depth 51) |
| 6 | Icarus gate-level sim | Icarus 12 `$isunknown()` returns 1 for fully known concatenations | TB uses the reduction-XOR X idiom; mutant MX1 proves real X is still caught |
| 7 | characterisation | Isolated-latency figures polluted by overlapping ops and reserved-rm vectors | Deterministic `+GAP` spacing, legal-only stream |

No RTL functional bug was found by the regression after the first integration. Every arithmetic
and control result matched the references from the first full run onward. That is also why the
mutation campaign was added: to show that the checks are able to fail.

## 7. Requirement traceability (brief §7 and §9)

| Requirement | Evidence |
|---|---|
| Every opcode | `arith:*` and `misc` runs; `reports/coverage.md` |
| FP corner cases | `spec_*` cross products, constructed hard cases, flag/tie/tiny coverage |
| Operand routing | unused operands randomised; asymmetric FMA forms (FMSUB/FNMSUB/FNMADD); mutant M25 |
| Tag preservation | unique tags checked on every result; TAG_W = 1 / 4 / 6 / 8 / 12 / 16 |
| Disabled lane | `disabled` runs (1.17 M masked ops, no result); mutant M14 |
| Invalid opcode | `illegal` runs, reserved rm; mutants M20, M23 |
| Pipeline stalls | `stall` / `backpressure`; ROB depths 1–16; mutant M15 |
| Back-to-back mixed | `mixed_b2b` / `order_b2b` at 1 op/cycle |
| Reset | 12,544 asynchronous mid-stream resets; mutants M19, M27; gate-level reset runs |
| Result ordering | scoreboard; 930 k completion inversions; mutants M16, M17, M18 |
| Exception propagation | flags compared on every result; per-bin flag coverage |
| No dropped / duplicate / misassociated ops | scoreboard + exact accounting (accepted − retired = flushed) |
| Correct arithmetic and flags | 2.09 M hardware-confirmed reference vectors, bit-exact |
| Deterministic reset | reset-state check after every assertion; Icarus 4-state RTL and netlist |
| Successful synthesis | `docs/SYNTHESIS.md`: 4 configurations, no latches, `check -assert` |
