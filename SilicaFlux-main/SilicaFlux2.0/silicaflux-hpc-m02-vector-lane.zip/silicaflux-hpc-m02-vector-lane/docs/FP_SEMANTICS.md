# Floating-point semantics

The lane implements IEEE 754-2019 binary32 arithmetic with default (non-trapping) exception
handling. Where IEEE leaves a choice, the lane follows the RISC-V F extension, the convention of
`silicaflux_pkg.sf`. The executable specification is `ref/fp32_ref.py`, an exact model.

## Rounding

* Five rounding attributes, `in_rm_i` encoded as in `silicaflux_pkg::fp_rm_e`:

  | Code | Mode |
  |---|---|
  | 0 | RNE: nearest, ties to even |
  | 1 | RTZ: toward zero |
  | 2 | RDN: toward −∞ |
  | 3 | RUP: toward +∞ |
  | 4 | RMM: nearest, ties away from zero |

  Codes 5–7 on a rounding operation make it illegal.
* FADD, FSUB, FMUL and the FMA family round **once**. The FMA family is fused: the product is not
  rounded before the addition.
* **FNMADD / FNMSUB** are −(a·b)∓c, computed by negating the *inputs* (product and/or addend)
  before the single rounding, as RISC-V defines. Rounding the result and then negating it would
  differ in the directed rounding modes.

## Exception flags `{NV, DZ, OF, UF, NX}`

| Flag | Raised when |
|---|---|
| NV | Any signalling-NaN input to an arithmetic op; ∞ − ∞ (incl. in FMA); 0 × ∞ (FMUL, and FMA **even if the addend is a quiet NaN**); FMIN/FMAX/FEQ with an sNaN input; FLT/FLE with any NaN input |
| DZ | Never (no division in this lane); bit position reserved |
| OF | Rounded result's exponent exceeds the format; NX is always set with it |
| UF | Result is **tiny after rounding** AND inexact |
| NX | Delivered result differs from the exact result (incl. overflow) |

* **Tininess after rounding** (RISC-V, x86): a non-zero result is tiny if rounding it to 24 bits
  with an unbounded exponent range gives a magnitude below 2⁻¹²⁶. Example:
  `(2²⁴−1)·2⁻¹⁵⁰` rounds (RNE) to the smallest normal `0x00800000` and *is* tiny, so the flags are
  UF and NX. `(2²⁵−1)·2⁻¹⁵¹` also rounds to `0x00800000`, but is *not* tiny, so only NX is raised.
  Both cases are self-tests in `fp32_ref.py`.
* Exact results (including exact subnormal results) raise no flags.
* Overflow returns ±∞ under RNE and RMM. It also returns ±∞ under RUP for positive results and
  RDN for negative results. Otherwise (RTZ, and the opposite directed mode) it returns ±max finite
  (`0x7F7FFFFF`).

## NaN policy

* Every NaN produced by FADD, FSUB, FMUL, the FMA family, FMIN and FMAX is the **canonical quiet
  NaN `0x7FC00000`**. Input payloads are not propagated (RISC-V).
* **FMV** is a bit-exact move: NaN payloads, signalling NaNs and the sign are preserved, and no
  flags are raised.

## Zeros

* An exact zero sum of operands with opposite signs, an exact difference of operands with like
  signs, and an exact cancellation in FMA all give +0. The exception is RDN, which gives −0.
* (±0) + (±0) with equal signs keeps the sign.
* FMA with an exact zero product returns the addend (sign included; `−c` for FMSUB/FNMADD) exactly.
  If the addend is also zero, the same sign rule applies.

## FMIN / FMAX

IEEE 754-2019 `minimumNumber` / `maximumNumber`, which is RISC-V FMIN.S / FMAX.S:

* if both operands are NaN, the result is the canonical NaN;
* if only one is NaN, the result is the other operand;
* −0 is ordered below +0;
* NV is raised if either input is a signalling NaN, even when the result is not a NaN.

## Comparisons

* FEQ, FLT and FLE return the integer 1 or 0 in `out_result_o`.
* NaN operands compare false, and +0 = −0.
* FEQ is quiet (NV only for signalling NaNs). FLT and FLE are signalling (NV for any NaN).

## Subnormals

Full support on inputs and outputs. There is no flush-to-zero and no denormals-are-zero mode.

## Known difference from the x86 reference

For `fma(∞, 0, qNaN)` and `fma(0, ∞, qNaN)`, RISC-V requires NV and the lane raises it. x86 FMA3
does not. IEEE 754-2019 §7.2 leaves this implementation-defined. `ref/crosscheck.py` counts these
vectors separately and checks that they differ **only** in NV. Every other vector is compared
exactly against the hardware.
