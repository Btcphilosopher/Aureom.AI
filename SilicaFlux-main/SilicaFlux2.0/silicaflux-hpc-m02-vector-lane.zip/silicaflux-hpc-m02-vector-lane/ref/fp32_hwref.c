/* =============================================================================
 * SilicaFlux-HPC :: fp32_hwref -- hardware IEEE-754 oracle (x86-64 SSE + FMA3)
 *
 * Independent reference: computes binary32 results and exception flags with
 * the host CPU's IEEE-754 floating-point unit.  Rounding direction is set with
 * fesetround(); flags are read with fetestexcept().  FMA uses the hardware
 * VFMADD/VFMSUB/VFNMADD/VFNMSUB instructions (single rounding).
 *
 *   stdin : one vector per line  "op rm a b c"  (hex, rtl/hpc_vector_pkg.sv)
 *   stdout: "res flags" (hex) or "NA" when the hardware cannot provide the
 *           reference (rm = RMM: x86 has no ties-to-away mode; FMIN/FMAX:
 *           x86 MINSS/MAXSS are not IEEE minimumNumber/maximumNumber).
 *
 * NaN results are reported as the canonical NaN 0x7FC00000 (the lane's
 * documented NaN policy); the oracle itself only decides NaN-ness.
 *
 * Build:  cc -O1 -mfma -frounding-math -fsignaling-nans fp32_hwref.c -lm
 * The MXCSR DAZ/FTZ bits are checked to be clear (full subnormal support) and
 * x86 tininess detection is after rounding (same as RISC-V / this lane).
 * ========================================================================== */
#include <fenv.h>
#include <immintrin.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma STDC FENV_ACCESS ON   /* GCC: ignored; -frounding-math + volatile provide the same guarantee */

enum { OP_FMV = 0x00, OP_FADD, OP_FSUB, OP_FMUL, OP_FMADD, OP_FMSUB, OP_FNMSUB,
       OP_FNMADD, OP_FMIN, OP_FMAX, OP_FEQ, OP_FLT, OP_FLE,
       OP_IADD = 0x10, OP_IMUL = 0x11 };

static float b2f(uint32_t u) { float f; memcpy(&f, &u, 4); return f; }
static uint32_t f2b(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }

static unsigned map_flags(int ex) {
  unsigned fl = 0;
  if (ex & FE_INVALID)   fl |= 0x10;
  if (ex & FE_DIVBYZERO) fl |= 0x08;
  if (ex & FE_OVERFLOW)  fl |= 0x04;
  if (ex & FE_UNDERFLOW) fl |= 0x02;
  if (ex & FE_INEXACT)   fl |= 0x01;
  return fl;
}

static int is_nan32(uint32_t u) { return (u & 0x7F800000u) == 0x7F800000u && (u & 0x7FFFFFu); }

int main(void) {
  unsigned csr = _mm_getcsr();
  if (csr & ((1u << 6) | (1u << 15))) {
    fprintf(stderr, "fp32_hwref: DAZ/FTZ set in MXCSR (0x%08x)\n", csr);
    return 2;
  }
  static const int rmode[4] = { FE_TONEAREST, FE_TOWARDZERO, FE_DOWNWARD, FE_UPWARD };
  char line[256];
  while (fgets(line, sizeof line, stdin)) {
    unsigned op, rm, a, b, c;
    if (sscanf(line, "%x %x %x %x %x", &op, &rm, &a, &b, &c) != 5) continue;
    int rounding = (op >= OP_FADD && op <= OP_FNMADD);
    if ((rounding && rm > 3) || op == OP_FMIN || op == OP_FMAX || op == OP_FMV) {
      puts("NA");
      continue;
    }
    if (op == OP_IADD) { printf("%08x %02x\n", (uint32_t)(a + b), 0); continue; }
    if (op == OP_IMUL) { printf("%08x %02x\n", (uint32_t)((uint64_t)a * b), 0); continue; }
    if (!rounding && !(op == OP_FEQ || op == OP_FLT || op == OP_FLE)) { puts("NA"); continue; }

    volatile float fa = b2f(a), fb = b2f(b), fc = b2f(c);
    __m128 va = _mm_set_ss(fa), vb = _mm_set_ss(fb), vc = _mm_set_ss(fc);
    volatile float r = 0.0f;
    volatile int ri = 0;
    int is_cmp = 0;

    fesetround(rounding ? rmode[rm] : FE_TONEAREST);
    feclearexcept(FE_ALL_EXCEPT);
    switch (op) {
      case OP_FADD:   r = fa + fb; break;
      case OP_FSUB:   r = fa - fb; break;
      case OP_FMUL:   r = fa * fb; break;
      case OP_FMADD:  r = _mm_cvtss_f32(_mm_fmadd_ss (va, vb, vc)); break;  /*  a*b + c */
      case OP_FMSUB:  r = _mm_cvtss_f32(_mm_fmsub_ss (va, vb, vc)); break;  /*  a*b - c */
      case OP_FNMSUB: r = _mm_cvtss_f32(_mm_fnmadd_ss(va, vb, vc)); break;  /* -a*b + c */
      case OP_FNMADD: r = _mm_cvtss_f32(_mm_fnmsub_ss(va, vb, vc)); break;  /* -a*b - c */
      case OP_FEQ:    ri = _mm_ucomieq_ss(va, vb); is_cmp = 1; break;       /* quiet  */
      case OP_FLT:    ri = _mm_comilt_ss (va, vb); is_cmp = 1; break;       /* signal */
      case OP_FLE:    ri = _mm_comile_ss (va, vb); is_cmp = 1; break;       /* signal */
    }
    int ex = fetestexcept(FE_ALL_EXCEPT);
    fesetround(FE_TONEAREST);
    unsigned fl = map_flags(ex);
    if (is_cmp) {
      /* COMISS/UCOMISS report "unordered" as ZF=PF=CF=1; the IEEE predicate
       * is false for unordered operands, so decide the value explicitly. */
      int unordered = is_nan32(a) || is_nan32(b);
      (void)ri;
      int v = 0;
      if (!unordered) {
        float x = b2f(a), y = b2f(b);
        v = (op == OP_FEQ) ? (x == y) : (op == OP_FLT) ? (x < y) : (x <= y);
      }
      printf("%08x %02x\n", (uint32_t)v, fl);
    } else {
      uint32_t res = f2b(r);
      if (is_nan32(res)) res = 0x7FC00000u;
      printf("%08x %02x\n", res, fl);
    }
  }
  return 0;
}
