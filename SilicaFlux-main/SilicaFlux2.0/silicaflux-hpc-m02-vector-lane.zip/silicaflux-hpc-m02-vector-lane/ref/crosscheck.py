#!/usr/bin/env python3
"""
SilicaFlux-HPC :: crosscheck -- validate the exact model against hardware

Feeds every vector of the given .vec files to the hardware oracle
(fp32_hwref, x86-64 SSE/FMA3) and compares its result and flags with the
expected values produced by fp32_ref.py.

Known, documented semantic difference (IEEE 754-2019 7.2: implementation
defined): for fusedMultiplyAdd(inf, 0, qNaN) RISC-V -- and this lane --
raise NV, x86 FMA3 does not.  Such vectors are counted separately and checked
to differ ONLY in the NV flag.  Any other disagreement is a failure.

Usage: crosscheck.py HWREF FILE.vec [FILE.vec ...]
"""
import os
import subprocess
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fp32_ref as R  # noqa: E402


def inf_times_zero_plus_qnan(op, a, b, c):
    if op not in (R.OP_FMADD, R.OP_FMSUB, R.OP_FNMSUB, R.OP_FNMADD):
        return False
    inv = (R.is_inf(a) and R.is_zero(b)) or (R.is_zero(a) and R.is_inf(b))
    return inv and R.is_nan(c) and not R.is_snan(c)


def main():
    hw = sys.argv[1]
    checked, skipped, known, bad = Counter(), Counter(), Counter(), 0
    for path in sys.argv[2:]:
        with open(path) as fh:
            rows = [l.split() for l in fh if l.strip()]
        inp = "".join(f"{r[0]} {r[1]} {r[2]} {r[3]} {r[4]}\n" for r in rows)
        out = subprocess.run([hw], input=inp, capture_output=True, text=True, check=True)
        outs = out.stdout.splitlines()
        assert len(outs) == len(rows), path
        for r, o in zip(rows, outs):
            op, rm = int(r[0], 16), int(r[1], 16)
            key = f"{R.OP_NAMES.get(op, 'ILL')}/{R.RM_NAMES.get(rm, rm) if op in R.ROUNDING_OPS else '-'}"
            if o == "NA" or r[7] == "1":
                skipped[key] += 1
                continue
            hres, hfl = (int(x, 16) for x in o.split())
            eres, efl = int(r[5], 16), int(r[6], 16)
            a, b, c = int(r[2], 16), int(r[3], 16), int(r[4], 16)
            if inf_times_zero_plus_qnan(op, a, b, c):
                if hres == eres and (hfl | R.NV) == efl:
                    known[key] += 1
                    continue
            checked[key] += 1
            if hres != eres or hfl != efl:
                bad += 1
                if bad <= 20:
                    print(f"MISMATCH {path}: {' '.join(r[:5])} model={eres:08x}/{efl:02x} "
                          f"hw={hres:08x}/{hfl:02x}")
    for k in sorted(checked):
        print(f"  {k:12s} hw-checked {checked[k]:8d}")
    print(f"crosscheck: {sum(checked.values())} vectors agree with hardware, "
          f"{sum(known.values())} known inf*0+qNaN NV differences, "
          f"{sum(skipped.values())} not hardware-checkable (RMM, FMIN/FMAX, FMV, illegal), "
          f"{bad} mismatches")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
