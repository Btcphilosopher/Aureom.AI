#!/usr/bin/env python3
"""
SilicaFlux-HPC :: gen_vectors -- corner-biased test-vector generator

Generates operation vectors for every lane opcode and every rounding mode and
annotates them with the expected result from the exact reference model
(fp32_ref.py).  Output line format (hex, space separated):

    op rm a b c exp_result exp_flags exp_illegal

Vector classes (per rounding operation and rounding mode):
  * special   : full cross product of special/boundary encodings
  * random    : TestFloat-style operands -- biased exponents (subnormal,
                boundary, mid-range) and structured significands (runs of
                ones/zeros, single set/clear bits, all-ones, random)
  * related   : operands constructed to hit hard cases -- massive
                cancellation, exponent differences around the alignment
                limits, products straddling the overflow/underflow
                thresholds, FMA addend ~= -product, addend negligible vs.
                product and vice versa, subnormal products
  * misc ops  : FMV / FMIN / FMAX / FEQ / FLT / FLE / IADD / IMUL
  * illegal   : reserved opcodes, reserved rounding modes on rounding ops

Usage: gen_vectors.py OUTDIR [--seed N] [--per-rm N] [--jobs N]
"""
import argparse
import multiprocessing as mp
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fp32_ref as R  # noqa: E402

SPECIALS = [
    0x00000000, 0x80000000,             # +-0
    0x7F800000, 0xFF800000,             # +-inf
    0x7FC00000, 0xFFFFFFFF, 0x7FC00001, # qNaN (canonical, all-ones, payload)
    0x7F800001, 0xFFBFFFFF,             # sNaN
    0x00000001, 0x80000001,             # +-min subnormal
    0x007FFFFF, 0x807FFFFF,             # +-max subnormal
    0x00400000,                         # mid subnormal
    0x00800000, 0x80800000,             # +-min normal
    0x00800001, 0x00FFFFFF,             # just above min normal
    0x7F7FFFFF, 0xFF7FFFFF,             # +-max normal
    0x7F000000, 0x7EFFFFFF,             # 2^127, just below
    0x3F800000, 0xBF800000,             # +-1
    0x3F800001, 0x3F7FFFFF,             # 1+ulp, 1-ulp/2
    0x40000000, 0x3F000000,             # 2, 0.5
    0x33800000, 0x34000000,             # 2^-24, 2^-23
    0x4B800000, 0x5F800000,             # 2^24, 2^64
    0x1F800000, 0x20000000,             # 2^-64, 2^-63
]
# smaller set for the 3-operand cross product
SPECIALS3 = [0x00000000, 0x80000000, 0x7F800000, 0xFF800000, 0x7FC00000, 0x7F800001,
             0x00000001, 0x807FFFFF, 0x00800000, 0x7F7FFFFF, 0xFF7FFFFF, 0x3F800000,
             0xBF800000, 0x3F800001, 0x33800000, 0x00400000, 0x5F800000, 0x1F800000]

ROUND_OPS = [R.OP_FADD, R.OP_FSUB, R.OP_FMUL, R.OP_FMADD, R.OP_FMSUB, R.OP_FNMSUB, R.OP_FNMADD]
FMA_OPS = [R.OP_FMADD, R.OP_FMSUB, R.OP_FNMSUB, R.OP_FNMADD]
MISC_OPS = [R.OP_FMV, R.OP_FMIN, R.OP_FMAX, R.OP_FEQ, R.OP_FLT, R.OP_FLE, R.OP_IADD, R.OP_IMUL]
ILLEGAL_OPS = [0x0D, 0x0E, 0x0F] + list(range(0x12, 0x20))
M23 = (1 << 23) - 1


# ----------------------------------------------------------------- operands
def rand_frac(r):
    k = r.random()
    if k < 0.25:
        return r.getrandbits(23)
    if k < 0.33:
        return 0
    if k < 0.41:
        return M23
    if k < 0.56:
        n = r.randrange(24)
        return (((1 << n) - 1) << (23 - n)) & M23 if r.random() < 0.5 else (1 << n) - 1
    if k < 0.70:
        bit = 1 << r.randrange(23)
        return bit if r.random() < 0.5 else M23 ^ bit
    v, pos = 0, 0
    while pos < 23:
        run = r.randrange(1, 9)
        if r.random() < 0.5:
            v |= ((1 << run) - 1) << pos
        pos += run
    return v & M23


def rand_exp(r):
    k = r.random()
    if k < 0.08:
        return 0
    if k < 0.10:
        return 255
    if k < 0.22:
        return r.choice([1, 2, 3, 24, 25, 126, 127, 128, 228, 229, 252, 253, 254])
    if k < 0.50:
        return r.randrange(96, 160)
    return r.randrange(1, 255)


def mk(s, e, f):
    return ((s & 1) << 31) | ((e & 0xFF) << 23) | (f & M23)


def rand_fp(r):
    if r.random() < 0.03:
        return r.choice(SPECIALS)
    if r.random() < 0.05:
        return r.getrandbits(32)
    return mk(r.getrandbits(1), rand_exp(r), rand_frac(r))


def exp_of(x):
    return (x >> 23) & 0xFF


def nudge(x, r, span=3):
    """Move an encoding by a few ulps (stays a valid bit pattern)."""
    return (x + r.randrange(-span, span + 1)) & 0xFFFFFFFF


def related_add(r, op):
    a = mk(r.getrandbits(1), r.randrange(1, 255), rand_frac(r))
    k = r.random()
    if k < 0.35:      # cancellation: b ~= a (FADD: opposite sign, FSUB: same sign)
        b = nudge(a, r, 4)
        if op == R.OP_FADD:
            b ^= 0x80000000
    elif k < 0.75:    # exponent difference around the alignment window
        d = r.choice(list(range(0, 32)) + [r.randrange(32, 260)])
        eb = exp_of(a) - d
        b = mk(r.getrandbits(1), eb if eb > 0 else 0, rand_frac(r))
    else:             # subnormal / boundary pairs
        a = mk(r.getrandbits(1), r.choice([0, 1, 2]), rand_frac(r))
        b = mk(r.getrandbits(1), r.choice([0, 1, 2, 254]), rand_frac(r))
    if r.random() < 0.5:
        a, b = b, a
    return a, b


def related_mul(r):
    # choose exponents so the product lands near a threshold
    k = r.random()
    if k < 0.35:      # around the overflow threshold (ea+eb-127 ~ 254)
        t = r.randrange(250, 258)
    elif k < 0.75:    # around the normal/subnormal boundary and below
        t = r.randrange(-26, 4)
    else:
        t = r.randrange(-40, 300)
    ea = r.randrange(1, 255)
    eb = t + 127 - ea
    eb = min(max(eb, 0), 254)
    return (mk(r.getrandbits(1), ea, rand_frac(r)),
            mk(r.getrandbits(1), eb, rand_frac(r)))


def related_fma(r):
    a, b = related_mul(r) if r.random() < 0.3 else (rand_fp(r), rand_fp(r))
    p, _ = R.fmul(a, b, R.RNE)
    k = r.random()
    if k < 0.40 and not (R.is_nan(p) or R.is_inf(p)):   # c ~= -(a*b): cancellation
        c = nudge(p ^ 0x80000000, r, 2)
        if r.random() < 0.3:
            c ^= 0x80000000                              # also ~= +(a*b)
    elif k < 0.75 and not (R.is_nan(p) or R.is_inf(p)):  # exponent offset from product
        d = r.choice(list(range(-30, 31)) + [r.randrange(-200, 200)])
        ec = min(max(exp_of(p) + d, 0), 254)
        c = mk(r.getrandbits(1), ec, rand_frac(r))
    else:
        c = rand_fp(r)
    return a, b, c


# ----------------------------------------------------------------- jobs
def gen_round_job(args):
    op, rm, n, seed = args
    r = random.Random(seed)
    out = []
    for _ in range(n):
        k = r.random()
        if op in (R.OP_FADD, R.OP_FSUB):
            if k < 0.5:
                a, b = related_add(r, op)
            else:
                a, b = rand_fp(r), rand_fp(r)
            c = r.getrandbits(32)                        # unused operand: random
        elif op == R.OP_FMUL:
            if k < 0.5:
                a, b = related_mul(r)
            else:
                a, b = rand_fp(r), rand_fp(r)
            c = r.getrandbits(32)
        else:
            if k < 0.6:
                a, b, c = related_fma(r)
            else:
                a, b, c = rand_fp(r), rand_fp(r), rand_fp(r)
        out.append((op, rm, a, b, c))
    return annotate(out)


def gen_special_job(args):
    op, rm = args
    out = []
    if op in FMA_OPS:
        for a in SPECIALS3:
            for b in SPECIALS3:
                for c in SPECIALS3:
                    out.append((op, rm, a, b, c))
    else:
        for a in SPECIALS:
            for b in SPECIALS:
                out.append((op, rm, a, b, 0x5A5A5A5A))
    return annotate(out)


def gen_misc_job(args):
    op, n, seed = args
    r = random.Random(seed)
    out = []
    for a in SPECIALS:
        for b in SPECIALS:
            out.append((op, r.randrange(8), a, b, r.getrandbits(32)))
    for _ in range(n):
        if r.random() < 0.3:
            a = rand_fp(r)
            b = a if r.random() < 0.3 else nudge(a, r, 2) ^ (0x80000000 if r.random() < 0.3 else 0)
        else:
            a, b = rand_fp(r), rand_fp(r)
        if op in (R.OP_IADD, R.OP_IMUL) and r.random() < 0.5:
            a, b = r.getrandbits(32), r.getrandbits(32)
        out.append((op, r.randrange(8), a, b, r.getrandbits(32)))
    return annotate(out)


def gen_illegal_job(args):
    n, seed = args
    r = random.Random(seed)
    out = []
    for op in ILLEGAL_OPS:
        for _ in range(n):
            out.append((op, r.randrange(8), r.getrandbits(32), r.getrandbits(32), r.getrandbits(32)))
    for op in ROUND_OPS:                                  # reserved rounding modes
        for rm in (5, 6, 7):
            for _ in range(n):
                out.append((op, rm, rand_fp(r), rand_fp(r), rand_fp(r)))
    return annotate(out)


def annotate(vecs):
    lines = []
    for (op, rm, a, b, c) in vecs:
        res, fl, ill = R.execute(op, rm, a, b, c)
        lines.append(f"{op:02x} {rm:x} {a:08x} {b:08x} {c:08x} {res:08x} {fl:02x} {ill:x}")
    return lines


def write(path, lines):
    with open(path, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    return len(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("--seed", type=int, default=20261106)
    ap.add_argument("--per-rm", type=int, default=40000,
                    help="random+related vectors per rounding op and rounding mode")
    ap.add_argument("--misc", type=int, default=40000, help="random vectors per misc op")
    ap.add_argument("--jobs", type=int, default=os.cpu_count())
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    chunk = 10000
    with mp.Pool(args.jobs) as pool:
        total = 0
        for op in ROUND_OPS:
            name = R.OP_NAMES[op].lower()
            jobs = []
            for rm in range(5):
                for i in range(0, args.per_rm, chunk):
                    jobs.append((op, rm, min(chunk, args.per_rm - i),
                                 (args.seed * 1000003 + op * 7919 + rm * 104729 + i) & 0xFFFFFFFF))
            lines = [l for part in pool.map(gen_round_job, jobs) for l in part]
            total += write(os.path.join(args.outdir, f"rand_{name}.vec"), lines)
            lines = [l for part in pool.map(gen_special_job, [(op, rm) for rm in range(5)])
                     for l in part]
            total += write(os.path.join(args.outdir, f"spec_{name}.vec"), lines)
        jobs = [(op, args.misc, (args.seed * 31 + op) & 0xFFFFFFFF) for op in MISC_OPS]
        lines = [l for part in pool.map(gen_misc_job, jobs) for l in part]
        total += write(os.path.join(args.outdir, "misc.vec"), lines)
        lines = gen_illegal_job((64, args.seed ^ 0xBAD))
        total += write(os.path.join(args.outdir, "illegal.vec"), lines)
    print(f"gen_vectors: {total} vectors in {args.outdir}")


if __name__ == "__main__":
    main()
