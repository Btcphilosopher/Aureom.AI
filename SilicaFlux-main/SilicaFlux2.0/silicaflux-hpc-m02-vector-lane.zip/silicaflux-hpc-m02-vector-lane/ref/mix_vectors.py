#!/usr/bin/env python3
"""
SilicaFlux-HPC :: mix_vectors -- interleaved streams for lane-level tests

  mixed.vec  : N vectors sampled from all .vec files and shuffled, so every
               opcode / latency class follows every other back-to-back
  order.vec  : directed latency-inversion patterns: each long-latency op
               (FMA, FMUL, FADD, IMUL) immediately followed by bursts of
               short-latency ops (FMV, IADD, FEQ, illegal), so younger
               operations complete before older ones and must be held back
               by the in-order completion buffer.  Operands are taken from
               the reference-annotated pool, so results stay exact.

Usage: mix_vectors.py INDIR OUTDIR [--n N] [--seed S]
"""
import argparse
import glob
import os
import random


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("indir")
    ap.add_argument("outdir")
    ap.add_argument("--n", type=int, default=300000)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    r = random.Random(args.seed)
    pools = {}
    for path in sorted(glob.glob(os.path.join(args.indir, "*.vec"))):
        with open(path) as fh:
            for line in fh:
                if line.strip():
                    pools.setdefault(int(line.split()[0], 16), []).append(line.rstrip("\n"))
    ops = sorted(pools)
    legal = [o for o in ops if o <= 0x0C or o in (0x10, 0x11)]
    illegal = [o for o in ops if o not in legal]
    # mixed: 95% uniform over legal opcodes, 5% reserved opcodes (reserved
    # rounding modes on legal opcodes are already inside the legal pools)
    def pick():
        if illegal and r.random() < 0.05:
            return r.choice(pools[r.choice(illegal)])
        return r.choice(pools[r.choice(legal)])
    mixed = [pick() for _ in range(args.n)]
    with open(os.path.join(args.outdir, "mixed.vec"), "w") as fh:
        fh.write("\n".join(mixed) + "\n")
    # order: long op followed by a burst of short ops
    long_ops = [o for o in (0x04, 0x05, 0x06, 0x07, 0x03, 0x01, 0x02, 0x11) if o in pools]
    short_ops = [o for o in (0x00, 0x10, 0x0A, 0x0B, 0x08, 0x09, 0x0C) if o in pools]
    order = []
    while len(order) < args.n // 3:
        order.append(r.choice(pools[r.choice(long_ops)]))
        for _ in range(r.randrange(1, 7)):
            if illegal and r.random() < 0.05:
                order.append(r.choice(pools[r.choice(illegal)]))   # completes at once
            else:
                order.append(r.choice(pools[r.choice(short_ops)]))
    with open(os.path.join(args.outdir, "order.vec"), "w") as fh:
        fh.write("\n".join(order) + "\n")
    print(f"mix_vectors: mixed={len(mixed)} order={len(order)} from {len(ops)} opcodes")


if __name__ == "__main__":
    main()
