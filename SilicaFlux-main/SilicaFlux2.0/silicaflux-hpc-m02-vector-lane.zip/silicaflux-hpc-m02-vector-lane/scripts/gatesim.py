#!/usr/bin/env python3
"""
SilicaFlux-HPC :: gatesim -- post-synthesis gate-level simulation

Runs the lane testbench (compiled with GATE defined, i.e. no internal probes)
against the Yosys netlist build/syn/hpc_vector_lane_netlist.v (default
parameters) produced by syn/run_synth.sh.  Proves that the synthesized logic
behaves exactly like the RTL on the same self-checking tests (no
simulation/synthesis mismatch, no latch or X issues).
  * Verilator 5.020 : full vector files
  * Icarus 12       : 4-state subsets (X propagation from unreset datapath
                      flops would be flagged by the TB's X checks)
Writes reports/gatesim.md.
"""
import concurrent.futures as cf
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import regress as RG  # noqa: E402

NET = os.path.join(ROOT, "build", "syn", "hpc_vector_lane_netlist.v")
TESTS = [
    ("arith:rand_fmadd", "rand_fmadd", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("arith:rand_fadd", "rand_fadd", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("arith:rand_fmul", "rand_fmul", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("arith:spec_fnmadd", "spec_fnmadd", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("arith:misc", "misc", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("mixed_b2b", "mixed", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("order_b2b", "order", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("stall", "mixed", "+P_VALID=70 +P_READY=40 +P_EN=100"),
    ("disabled", "mixed", "+P_VALID=85 +P_READY=75 +P_EN=55"),
    ("reset", "mixed", "+P_VALID=80 +P_READY=60 +P_EN=80 +P_RESET=30"),
    ("illegal", "illegal", "+P_VALID=90 +P_READY=70 +P_EN=90"),
]


def main():
    vec = os.path.join(ROOT, "build", "vec")
    bdir = os.path.join(ROOT, "build", "gate")
    logdir = os.path.join(ROOT, "reports", "logs_gate")
    os.makedirs(bdir, exist_ok=True)
    os.makedirs(logdir, exist_ok=True)
    vl = subprocess.run(["verilator", "--binary", "--timing", "-O3", "-j", "4", "--timescale", "1ns/1ps",
                         "-Wno-fatal", "-Wno-lint", "-Wno-style", "-DGATE", "--top-module",
                         "tb_hpc_vector_lane", "--Mdir", os.path.join(bdir, "vl"), "-o", "tb",
                         NET, RG.TB], capture_output=True, text=True)
    if vl.returncode:
        sys.exit("verilator gate build failed:\n" + vl.stderr[-3000:])
    iv = subprocess.run(["iverilog", "-g2012", "-DGATE", "-o", os.path.join(bdir, "iv.vvp"),
                         "-s", "tb_hpc_vector_lane", NET, RG.TB], capture_output=True, text=True)
    if iv.returncode:
        sys.exit("icarus gate build failed:\n" + iv.stderr[-3000:])
    jobs = []
    for i, (tn, vf, plus) in enumerate(TESTS):
        jobs.append(("verilator", tn, [os.path.join(bdir, "vl", "tb")],
                     os.path.join(vec, vf + ".vec"), plus, 500 + i))
        sub = RG.head_file(os.path.join(vec, vf + ".vec"), os.path.join(bdir, vf + ".head.vec"), 4000)
        jobs.append(("icarus", tn, ["vvp", "-n", os.path.join(bdir, "iv.vvp")], sub, plus, 600 + i))
    res = []
    with cf.ThreadPoolExecutor(os.cpu_count()) as ex:
        futs = {ex.submit(RG.run, exe, v, p, sd, os.path.join(logdir, f"{s}__{tn.replace(':', '_')}.log")):
                (s, tn, p, sd) for (s, tn, exe, v, p, sd) in jobs}
        for f in cf.as_completed(futs):
            s, tn, p, sd = futs[f]
            r = f.result()
            res.append((s, tn, p, sd, r))
            print(f"{r['status']:4s} gate/{s:9s} {tn:18s} vectors={r.get('vectors', '?'):>7s} "
                  f"errors={r.get('errors', '?')} ({r['time']:.1f}s)", flush=True)
    res.sort(key=lambda x: (x[0], x[1]))
    npass = sum(1 for x in res if x[4]["status"] == "PASS")
    with open(os.path.join(ROOT, "reports", "gatesim.md"), "w") as fh:
        fh.write("# Post-synthesis gate-level simulation\n\n"
                 "Netlist: Yosys 0.33 `synth -flatten` of `hpc_vector_lane` (default parameters), "
                 "`write_verilog -noattr` (`build/syn/hpc_vector_lane_netlist.v`).  Testbench: "
                 "`tb/tb_hpc_vector_lane.sv` compiled with `GATE` (no internal probes).  Icarus runs "
                 "are 4-state, so any X escaping the unreset datapath registers would fail the "
                 "testbench's per-cycle X checks.\n\n")
        fh.write(f"## {npass}/{len(res)} PASS\n\n| sim | test | knobs | seed | vectors | accepted | "
                 "retired | masked | illegal | resets | cycles | errors | result |\n"
                 "|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
        for (s, tn, p, sd, r) in res:
            fh.write(f"| {s} | {tn} | {p.replace('+', '')} | {sd} | {r.get('vectors', '')} | "
                     f"{r.get('accepted', '')} | {r.get('retired', '')} | {r.get('masked', '')} | "
                     f"{r.get('illegal', '')} | {r.get('resets', '')} | {r.get('cycles', '')} | "
                     f"{r.get('errors', '?')} | **{r['status']}** |\n")
    print(f"gatesim: {npass}/{len(res)} PASS")
    sys.exit(0 if npass == len(res) else 1)


if __name__ == "__main__":
    main()
