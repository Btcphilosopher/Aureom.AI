#!/usr/bin/env python3
"""
SilicaFlux-HPC :: mutate -- verification-of-verification (mutation testing)

Each mutant injects ONE deliberate bug into a private copy of the RTL.  The
mutant is compiled with SYNTHESIS defined, i.e. WITHOUT the RTL's internal
simulation assertions, so only the black-box testbench (scoreboard, protocol,
event and X checks) can detect it.  A mutant must make at least one run FAIL.

Usage: mutate.py [--vec DIR] [--jobs N]
"""
import argparse
import concurrent.futures as cf
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import regress as RG  # noqa: E402

MUTANTS = [
    # id, file, old, new, description
    ("M01", "hpc_vector_pkg.sv", "RM_RNE:  round_inc = g & (s | lsb);", "RM_RNE:  round_inc = g;",
     "RNE ties rounded away from zero"),
    ("M02", "hpc_vector_pkg.sv", "RM_RMM:  round_inc = g;", "RM_RMM:  round_inc = g & (s | lsb);",
     "RMM ties rounded to even"),
    ("M03", "hpc_vector_pkg.sv", "RM_RDN:  round_inc = sign & (g | s);", "RM_RDN:  round_inc = ~sign & (g | s);",
     "RDN rounds the wrong sign"),
    ("M04", "hpc_fp32_round.sv", "wire logic tiny      = exp_lt1 & ~(exp_eq0 & carry_unb);",
     "wire logic tiny      = exp_lt1;", "tininess detected before rounding"),
    ("M05", "hpc_fp32_round.sv", "hpc_vector_pkg::RM_RTZ: to_inf = 1'b0;", "hpc_vector_pkg::RM_RTZ: to_inf = 1'b1;",
     "RTZ overflow returns inf instead of max finite"),
    ("M06", "hpc_fp32_fma.sv", "(|norm[SW-26:0]) | sticky_c, rm_c}", "(|norm[SW-26:0]), rm_c}",
     "FMA drops collapsed-addend sticky bit"),
    ("M07", "hpc_fp32_fma.sv", "wire logic [11:0] sh_raw = 12'd54 - dd;", "wire logic [11:0] sh_raw = 12'd55 - dd;",
     "FMA addend misaligned by one bit"),
    ("M08", "hpc_fp32_fma.sv", "spec_nv = any_snan | inv_mul;", "spec_nv = any_snan;",
     "FMA inf*0+qNaN does not raise NV"),
    ("M09", "hpc_fp32_add.sv", "if (dexp > 8'd26) ya = {49'd0, |sigy};", "if (dexp > 8'd20) ya = {49'd0, |sigy};",
     "adder collapses operand to sticky too early"),
    ("M10", "hpc_vector_pkg.sv", "fp_sig = {(x[30:23] != 8'h00), x[22:0]};", "fp_sig = {1'b1, x[22:0]};",
     "subnormal operands get a hidden one"),
    ("M11", "hpc_fp32_add.sv", ": {eff_sub_b ? (rm_b == hpc_vector_pkg::RM_RDN) : sx_b, 31'd0};",
     ": {1'b0, 31'd0};", "exact-zero sum always +0"),
    ("M12", "hpc_fp32_misc.sv", "wire logic lt_mm  = (a_i[31] != b_i[31]) ? a_i[31]",
     "wire logic lt_mm  = (a_i[31] != b_i[31]) ? b_i[31]", "min/max sign ordering inverted"),
    ("M13", "hpc_fp32_misc.sv", "flags[hpc_vector_pkg::FLAG_NV] = any_snan;\n          res = {31'd0, ~any_nan & eq_num};",
     "flags[hpc_vector_pkg::FLAG_NV] = any_nan;\n          res = {31'd0, ~any_nan & eq_num};",
     "FEQ signals NV on quiet NaN"),
    ("M14", "hpc_vector_lane.sv", "wire logic alloc  = hs_in & lane_en_i;", "wire logic alloc  = hs_in;",
     "disabled lane still executes and returns a result"),
    ("M15", "hpc_vector_lane.sv", "assign in_ready_o = init_q && (cnt_q != CW'(ROB_DEPTH));",
     "assign in_ready_o = init_q;", "accepts when completion buffer is full"),
    ("M16", "hpc_vector_lane.sv", "assign out_valid_o   = h_done;", "assign out_valid_o   = |rob_done_q;",
     "retires before the oldest operation completed"),
    ("M17", "hpc_vector_lane.sv", "      if (alloc && (tail_q == IW'(e)))\n        rob_tag_q",
     "      if (alloc && (ptr_inc(tail_q) == IW'(e)))\n        rob_tag_q", "tag stored in the wrong slot"),
    ("M18", "hpc_vector_lane.sv", "iss_id_q   <= tail_q;", "iss_id_q   <= head_q;",
     "result written to the wrong completion slot"),
    ("M19", "hpc_vector_lane.sv", "      rob_done_q <= '0;\n      rob_ill_q  <= '0;", "      rob_ill_q  <= '0;",
     "completion flags not cleared by reset"),
    ("M20", "hpc_vector_lane.sv", "wire  logic                       rm_ok = hpc_vector_pkg::rm_legal(in_rm_i);",
     "wire  logic                       rm_ok = 1'b1;", "reserved rounding modes accepted"),
    ("M21", "hpc_vector_lane.sv", "assign ev_pipe_stall_o   = in_valid_i & init_q & ~in_ready_o;",
     "assign ev_pipe_stall_o   = in_valid_i & ~in_ready_o;", "stall event counts the post-reset cycle"),
    ("M22", "hpc_vector_lane.sv", "assign ev_backpressure_o = out_valid_o & ~out_ready_i;",
     "assign ev_backpressure_o = ~out_ready_i;", "backpressure event without a valid result"),
    ("M23", "hpc_vector_lane.sv", "assign out_result_o  = (h_done && !h_ill) ? h_res : '0;",
     "assign out_result_o  = h_done ? h_res : '0;", "illegal operations return stale data"),
    ("M24", "hpc_fp32_mul.sv", "wire logic [11:0] e0 = {4'd0, ea} + {4'd0, eb} - 12'd126;",
     "wire logic [11:0] e0 = {4'd0, ea} + {4'd0, eb} - 12'd127;", "multiplier exponent bias off by one"),
    ("M25", "hpc_fp32_fma.sv", "wire logic sp = a_i[31] ^ b_i[31] ^ neg_prod_i;", "wire logic sp = a_i[31] ^ b_i[31];",
     "FNMADD/FNMSUB product negation lost (operand routing)"),
    ("M26", "hpc_fp32_misc.sv", "res = EN_INT ? (a_i + b_i) : 32'd0;", "res = EN_INT ? (a_i | b_i) : 32'd0;",
     "INT32 add implemented as OR"),
    ("M27", "hpc_vector_lane.sv", "      init_q     <= 1'b0;\n      cnt_q", "      init_q     <= 1'b1;\n      cnt_q",
     "ready asserted during / right after reset"),
]

RUNS = [
    # name, vector file, plusargs
    ("fadd", "rand_fadd", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("fmul", "rand_fmul", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("fma", "rand_fnmadd", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("spec_fma", "spec_fmadd", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("misc", "misc", "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("stall_dis", "mixed", "+P_VALID=80 +P_READY=40 +P_EN=70"),
    ("reset", "mixed", "+P_VALID=80 +P_READY=60 +P_EN=80 +P_RESET=40"),
]
LINES = 30000


def build(mid, rtl_dir, out):
    cmd = (["verilator", "--binary", "--timing", "-O1", "-j", "1", "--timescale", "1ns/1ps",
            "-Wno-fatal", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-DSYNTHESIS",
            "--top-module", "tb_hpc_vector_lane", "--Mdir", out, "-o", "tb"] +
           [os.path.join(rtl_dir, os.path.basename(f)) for f in RG.RTL] + [RG.TB])
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(f"{mid} build failed: {r.stderr[-2000:]}")
    return os.path.join(out, "tb")


def run_mutant(m, vecdir, bdir):
    mid, fname, old, new, desc = m
    mdir = os.path.join(bdir, mid)
    rtl = os.path.join(mdir, "rtl")
    shutil.rmtree(mdir, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, "rtl"), rtl)
    p = os.path.join(rtl, fname)
    src = open(p).read()
    if src.count(old) != 1:
        return (m, "BAD-MUTANT", [f"pattern found {src.count(old)} times"])
    if mid != "BASE":
        open(p, "w").write(src.replace(old, new))
    exe = build(mid, rtl, os.path.join(mdir, "obj"))
    failed = []
    for (rn, vf, plus) in RUNS:
        vec = os.path.join(bdir, f"{vf}.head.vec")
        r = RG.run([exe], vec, plus + " +QUIET", 77, os.path.join(mdir, f"{rn}.log"))
        if r["status"] != "PASS":
            failed.append(rn)
    return (m, "KILLED" if failed else "SURVIVED", failed)


X_MUTANT = ("MX1", "hpc_vector_lane.sv", "assign out_result_o  = (h_done && !h_ill) ? h_res : '0;",
            "assign out_result_o  = h_res;",
            "uninitialised completion storage driven onto out_result_o (4-state X check, Icarus)")


def run_x_mutant(bdir):
    """Icarus-only: proves the testbench's X/Z detection fires on a real X."""
    mid, fname, old, new, desc = X_MUTANT
    mdir = os.path.join(bdir, mid)
    rtl = os.path.join(mdir, "rtl")
    shutil.rmtree(mdir, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, "rtl"), rtl)
    p = os.path.join(rtl, fname)
    src = open(p).read()
    assert src.count(old) == 1
    open(p, "w").write(src.replace(old, new))
    vvp = os.path.join(mdir, "tb.vvp")
    subprocess.run(["iverilog", "-g2012", "-DSYNTHESIS", "-o", vvp, "-s", "tb_hpc_vector_lane"] +
                   [os.path.join(rtl, os.path.basename(f)) for f in RG.RTL] + [RG.TB], check=True)
    vec = RG.head_file(os.path.join(bdir, "mixed.head.vec"), os.path.join(mdir, "x.vec"), 2000)
    log = os.path.join(mdir, "x.log")
    r = RG.run(["vvp", "-n", vvp], vec, "+P_VALID=80 +P_READY=60", 5, log)
    xseen = "X/Z on lane payload output" in open(log).read()
    st = "KILLED" if (r["status"] != "PASS" and xseen) else "SURVIVED"
    return (X_MUTANT, st, ["x_check"] if st == "KILLED" else [])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vec", default=os.path.join(ROOT, "build", "vec"))
    ap.add_argument("--jobs", type=int, default=os.cpu_count())
    args = ap.parse_args()
    bdir = os.path.join(ROOT, "build", "mutants")
    os.makedirs(bdir, exist_ok=True)
    for (_, vf, _) in RUNS:
        RG.head_file(os.path.join(args.vec, vf + ".vec"), os.path.join(bdir, f"{vf}.head.vec"), LINES)
    base = ("BASE", "hpc_vector_lane.sv", "assign out_valid_o   = h_done;", "", "unmodified RTL (control)")
    results = []
    with cf.ThreadPoolExecutor(args.jobs) as ex:
        futs = [ex.submit(run_mutant, m, args.vec, bdir) for m in [base] + MUTANTS]
        for f in cf.as_completed(futs):
            m, st, failed = f.result()
            results.append((m, st, failed))
            print(f"{m[0]} {st:9s} {m[4]:52s} failing runs: {','.join(failed) or '-'}", flush=True)
    xr = run_x_mutant(bdir)
    print(f"{xr[0][0]} {xr[1]:9s} {xr[0][4]:52s} failing runs: {','.join(xr[2]) or '-'}", flush=True)
    results.append(xr)
    results.sort(key=lambda x: x[0][0])
    ok = all((st == "KILLED") for (m, st, _) in results if m[0] != "BASE")
    ok = ok and all(st == "SURVIVED" for (m, st, _) in results if m[0] == "BASE")
    with open(os.path.join(ROOT, "reports", "mutation.md"), "w") as fh:
        fh.write("# Mutation testing (verification of the verification)\n\n")
        fh.write("Each mutant injects one bug into a copy of the RTL, compiled with `SYNTHESIS` "
                 "defined (RTL-internal assertions removed), and runs the black-box testbench on "
                 f"{LINES}-vector subsets: " + ", ".join(f"`{r[0]}`" for r in RUNS) + ".\n"
                 "`BASE` is the unmodified RTL and must pass every run.  `MX1` is run on Icarus "
                 "(4-state) only and must be caught by the X/Z check specifically.\n\n")
        fh.write("| id | file | injected bug | result | failing runs |\n|---|---|---|---|---|\n")
        for (m, st, failed) in results:
            shown = "PASS (control)" if (m[0] == "BASE" and st == "SURVIVED") else st
            fh.write(f"| {m[0]} | {m[1]} | {m[4]} | **{shown}** | {', '.join(failed) or '-'} |\n")
        killed = sum(1 for (m, st, _) in results if st == "KILLED")
        fh.write(f"\n{killed}/{len(MUTANTS) + 1} mutants killed (incl. Icarus X-check mutant MX1); control "
                 f"{'passes' if results[0][1] == 'SURVIVED' else 'FAILS'}.\n")
    print("mutate:", "all mutants killed, control clean" if ok else "INCOMPLETE")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
