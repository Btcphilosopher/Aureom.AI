#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC Module 02 :: run_all.sh -- reproduce every result in reports/
#
# Requires: Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python >= 3.10,
#           a C compiler, and an x86-64 host with FMA3 for the hardware oracle.
# Wall time on 4 cores: ~20 minutes (the Icarus regression dominates).
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p build reports
step() { echo; echo "=================== $*"; }

step "tool versions"
{ verilator --version; iverilog -V 2>&1 | head -1; yosys -V; python3 --version; cc --version | head -1; } | tee reports/tool_versions.txt

step "reference model self-test + hardware oracle build"
python3 -I ref/fp32_ref.py
cc -O1 -mfma -frounding-math -fsignaling-nans -Wall -Wno-unknown-pragmas ref/fp32_hwref.c -lm -o build/fp32_hwref

step "test vectors (exact model) + mixed/ordering streams"
python3 -I ref/gen_vectors.py build/vec --per-rm 60000 --misc 60000
python3 -I ref/mix_vectors.py build/vec build/vec --n 300000

step "cross-check exact model against the hardware FPU"
python3 -I ref/crosscheck.py build/fp32_hwref build/vec/rand_*.vec build/vec/spec_*.vec \
        build/vec/misc.vec build/vec/illegal.vec | tee reports/crosscheck_hw.txt

step "lint"
bash scripts/lint.sh > /dev/null && echo "lint clean (reports/lint.txt)"

step "hpc_lzc unit test"
verilator --binary --timing -O3 --timescale 1ns/1ps -Wno-fatal -Wno-WIDTHEXPAND -Wno-WIDTHTRUNC \
  --top-module tb_hpc_lzc --Mdir build/obj_lzc -o tb rtl/hpc_lzc.sv tb/tb_hpc_lzc.sv > /dev/null
./build/obj_lzc/tb | grep TB_RESULT | tee reports/lzc_unit_test.txt
grep -q "TB_RESULT PASS" reports/lzc_unit_test.txt

step "lane regression (Verilator full vectors + Icarus 4-state subsets)"
python3 -I scripts/regress.py --sim both | tee reports/regress_console.txt | tail -1

step "mutation testing"
python3 -I scripts/mutate.py | tee reports/mutate_console.txt | tail -1

step "synthesis smoke test"
bash syn/run_synth.sh

step "post-synthesis gate-level simulation"
python3 -I scripts/gatesim.py | tee reports/gatesim_console.txt | tail -1

step "latency / throughput characterisation"
python3 -I scripts/characterize.py

step "ALL STEPS PASSED"
