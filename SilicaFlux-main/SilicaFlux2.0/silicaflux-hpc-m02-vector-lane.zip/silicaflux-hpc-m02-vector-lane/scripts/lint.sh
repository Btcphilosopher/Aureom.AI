#!/usr/bin/env bash
# SilicaFlux-HPC :: lint.sh -- Verilator -Wall (several parameter sets), Icarus
# elaboration and Yosys elaboration of the RTL.  Fails on any warning.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
RTL="rtl/hpc_vector_pkg.sv rtl/hpc_pipe.sv rtl/hpc_lzc.sv rtl/hpc_fp32_round.sv rtl/hpc_fp32_add.sv \
     rtl/hpc_fp32_mul.sv rtl/hpc_fp32_fma.sv rtl/hpc_fp32_misc.sv rtl/hpc_int32_mul.sv rtl/hpc_vector_lane.sv"
mkdir -p reports
OUT=reports/lint.txt
{
  echo "# lint: $(verilator --version); $(iverilog -V 2>&1 | head -1); $(yosys -V)"
  for cfg in "" "-GLAT_FADD=2 -GLAT_FMUL=2 -GLAT_FMA=3 -GLAT_IMUL=1 -GROB_DEPTH=2 -GTAG_W=4" \
             "-GLAT_FADD=6 -GLAT_FMUL=7 -GLAT_FMA=9 -GLAT_MISC=3 -GROB_DEPTH=5 -GTAG_W=1" \
             "-GEN_FCMP=0 -GEN_INT=0 -GROB_DEPTH=1"; do
    echo "== verilator --lint-only -Wall ${cfg:-(defaults)}"
    verilator --lint-only -Wall --top-module hpc_vector_lane $cfg $RTL 2>&1
    echo "   exit=$? (no output = clean)"
  done
  echo "== verilator --lint-only -Wall hpc_lzc W=81"
  verilator --lint-only -Wall --top-module hpc_lzc -GW=81 rtl/hpc_lzc.sv 2>&1
  echo "== iverilog -g2012 elaboration"
  iverilog -g2012 -o /dev/null -s hpc_vector_lane $RTL 2>&1
  echo "== yosys read_verilog -sv; hierarchy -check; proc"
  yosys -q -p "read_verilog -sv $RTL; hierarchy -check -top hpc_vector_lane; proc" 2>&1
  echo "== lint clean"
} > "$OUT" 2>&1
if grep -qE '^%(Warning|Error)|error|warning' "$OUT"; then cat "$OUT"; echo "LINT FAILED"; exit 1; fi
cat "$OUT"
