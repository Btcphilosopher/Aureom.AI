#!/usr/bin/env python3
"""
SilicaFlux-HPC :: characterize -- measured latency / throughput (cycle-level)

All numbers are MEASURED in RTL simulation (Verilator) with the self-checking
testbench (every run must PASS; results are bit-exact against the reference):
  1. isolated latency per opcode: sparse issue (P_VALID=2%) so no operation
     waits behind another; latency = acceptance cycle -> retirement cycle
  2. back-to-back throughput per opcode class vs ROB_DEPTH (P_VALID=P_READY=100)
     compared with the analytical bound min(1, ROB_DEPTH / (LAT + 2))
  3. mixed-stream throughput vs ROB_DEPTH and vs output-ready probability
These are cycle counts only; no clock frequency is implied.
Writes reports/characterisation.md.
"""
import concurrent.futures as cf
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import regress as RG  # noqa: E402

DEPTHS = [1, 2, 3, 4, 5, 6, 8]
CLASSES = [  # name, vector file, unit latency parameter (default config)
    ("FMV/FMIN/FEQ (MISC)", "misc_fp", "LAT_MISC"),
    ("FADD/FSUB", "rand_fadd", "LAT_FADD"),
    ("FMUL", "rand_fmul", "LAT_FMUL"),
    ("FMA family", "rand_fmadd", "LAT_FMA"),
    ("IMUL", "imul", "LAT_IMUL"),
]
LAT_RE = re.compile(r"op (\w\w)\s+n=(\d+)\s+lat min=(\d+) max=(\d+) avg=([\d.]+)")


def build(depth, bdir):
    p = dict(RG.BASE)
    p["ROB_DEPTH"] = depth
    mdir = os.path.join(bdir, f"d{depth}")
    cmd = (["verilator", "--binary", "--timing", "-O3", "-j", "2", "--timescale", "1ns/1ps",
            "-Wno-fatal", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "--top-module", "tb_hpc_vector_lane",
            "--Mdir", mdir, "-o", "tb"] + [f"-G{k}={v}" for k, v in p.items()] + RG.RTL + [RG.TB])
    subprocess.run(cmd, check=True, capture_output=True)
    return [os.path.join(mdir, "tb")]


def filt(src, dst, ops, n):
    out = []
    with open(src) as fh:
        for line in fh:
            if int(line.split()[0], 16) in ops and line.split()[7] == "0":
                out.append(line)
                if len(out) >= n:
                    break
    with open(dst, "w") as fh:
        fh.writelines(out)
    return dst


def main():
    vec = os.path.join(ROOT, "build", "vec")
    bdir = os.path.join(ROOT, "build", "char")
    logd = os.path.join(bdir, "logs")
    os.makedirs(logd, exist_ok=True)
    files = {
        "misc_fp": filt(os.path.join(vec, "misc.vec"), os.path.join(bdir, "misc_fp.vec"), {0x00, 0x08, 0x0A}, 20000),
        "imul": filt(os.path.join(vec, "misc.vec"), os.path.join(bdir, "imul.vec"), {0x11}, 20000),
        "rand_fadd": RG.head_file(os.path.join(vec, "rand_fadd.vec"), os.path.join(bdir, "fadd.vec"), 20000),
        "rand_fmul": RG.head_file(os.path.join(vec, "rand_fmul.vec"), os.path.join(bdir, "fmul.vec"), 20000),
        "rand_fmadd": RG.head_file(os.path.join(vec, "rand_fmadd.vec"), os.path.join(bdir, "fma.vec"), 20000),
        "mixed": RG.head_file(os.path.join(vec, "mixed.vec"), os.path.join(bdir, "mixed.vec"), 50000),
        "legal": filt(os.path.join(vec, "mixed.vec"), os.path.join(bdir, "legal.vec"),
                      set(range(0x0D)) | {0x10, 0x11}, 20000),
        "illegal": os.path.join(vec, "illegal.vec"),
    }
    with cf.ThreadPoolExecutor(os.cpu_count()) as ex:
        exes = dict(zip(DEPTHS, ex.map(lambda d: build(d, bdir), DEPTHS)))

    def run(exe, f, plus, tag):
        log = os.path.join(logd, tag + ".log")
        r = RG.run(exe, files[f], plus, 3, log)
        if r["status"] != "PASS":
            raise SystemExit(f"characterisation run {tag} failed (see {log})")
        r["lat"] = {m.group(1): m.groups()[1:] for m in LAT_RE.finditer(open(log).read())}
        return r

    jobs = {}
    with cf.ThreadPoolExecutor(os.cpu_count()) as ex:
        jobs["iso_mixed"] = ex.submit(run, exes[8], "legal", "+P_VALID=100 +P_READY=100 +GAP=12", "iso_legal")
        jobs["iso_ill"] = ex.submit(run, exes[8], "illegal", "+P_VALID=100 +P_READY=100 +GAP=12", "iso_illegal")
        for (cn, f, lp) in CLASSES:
            for d in DEPTHS:
                jobs[(cn, d)] = ex.submit(run, exes[d], f, "+P_VALID=100 +P_READY=100", f"b2b_{f}_d{d}")
        for d in DEPTHS:
            jobs[("mixed", d)] = ex.submit(run, exes[d], "mixed", "+P_VALID=100 +P_READY=100", f"mixed_d{d}")
        for pr in (100, 75, 50, 25):
            jobs[("ready", pr)] = ex.submit(run, exes[8], "mixed", f"+P_VALID=100 +P_READY={pr}", f"ready{pr}")
        res = {k: v.result() for k, v in jobs.items()}

    names = {0x00: "FMV", 0x01: "FADD", 0x02: "FSUB", 0x03: "FMUL", 0x04: "FMADD", 0x05: "FMSUB",
             0x06: "FNMSUB", 0x07: "FNMADD", 0x08: "FMIN", 0x09: "FMAX", 0x0A: "FEQ", 0x0B: "FLT",
             0x0C: "FLE", 0x10: "IADD", 0x11: "IMUL"}
    unit_lat = {0x00: "LAT_MISC", 0x08: "LAT_MISC", 0x09: "LAT_MISC", 0x0A: "LAT_MISC", 0x0B: "LAT_MISC",
                0x0C: "LAT_MISC", 0x10: "LAT_MISC", 0x01: "LAT_FADD", 0x02: "LAT_FADD", 0x03: "LAT_FMUL",
                0x04: "LAT_FMA", 0x05: "LAT_FMA", 0x06: "LAT_FMA", 0x07: "LAT_FMA", 0x11: "LAT_IMUL"}
    with open(os.path.join(ROOT, "reports", "characterisation.md"), "w") as fh:
        fh.write("# Measured latency and throughput (default latencies, cycle-level RTL simulation)\n\n")
        fh.write("Default parameters: " + ", ".join(f"{k}={v}" for k, v in RG.BASE.items()) + ".\n"
                 "All runs PASS the self-checking testbench (bit-exact results, in-order tags).  "
                 "No clock frequency is implied by any number here.\n\n")
        fh.write("## 1. Isolated latency (acceptance cycle to retirement cycle)\n\n"
                 "Every operation is followed by 12 forced idle cycles (`+GAP=12` > any latency), so no "
                 "operation waits behind another.  Legal-only stream; illegal operations measured "
                 "separately.\n\n")
        fh.write("Latency L means: accepted in cycle t (in_valid & in_ready), `out_valid_o` first high in "
                 "cycle t + L with `out_ready_i` held high.\n\n| opcode | unit latency param | "
                 "expected (LAT+1) | measured min | measured max | samples |\n|---|---|---|---|---|---|\n")
        iso = res["iso_mixed"]["lat"]
        for op in sorted(names):
            k = f"{op:02x}"
            if k in iso:
                n, mn, mx, avg = iso[k]
                exp = RG.BASE[unit_lat[op]] + 1
                fh.write(f"| {names[op]} | {unit_lat[op]}={RG.BASE[unit_lat[op]]} | {exp} | {mn} | {mx} | {n} |\n")
        ill = list(res["iso_ill"]["lat"].values())
        mn = min(int(v[1]) for v in ill)
        mx = max(int(v[2]) for v in ill)
        fh.write(f"| illegal opcode / reserved rm | (no unit) | 1 | {mn} | {mx} | "
                 f"{sum(int(v[0]) for v in ill)} |\n\n")
        fh.write("## 2. Back-to-back throughput per operation class vs ROB_DEPTH\n\n"
                 "Measured retired operations per cycle (P_VALID = P_READY = 100 %), "
                 "analytical bound min(1, ROB_DEPTH / (LAT + 2)) in brackets.\n\n")
        fh.write("| class (LAT) | " + " | ".join(f"D={d}" for d in DEPTHS) + " |\n|---|" + "---|" * len(DEPTHS) + "\n")
        for (cn, f, lp) in CLASSES:
            lat = RG.BASE[lp]
            cells = []
            for d in DEPTHS:
                thr = float(res[(cn, d)]["throughput"])
                cells.append(f"{thr:.3f} [{min(1.0, d / (lat + 2)):.3f}]")
            fh.write(f"| {cn} ({lp}={lat}) | " + " | ".join(cells) + " |\n")
        fh.write("\n## 3. Mixed stream (all opcodes, 5 % illegal) vs ROB_DEPTH\n\n| ROB_DEPTH | ops/cycle | "
                 "input-stall cycles | OoO completions | max occupancy |\n|---|---|---|---|---|\n")
        for d in DEPTHS:
            r = res[("mixed", d)]
            fh.write(f"| {d} | {float(r['throughput']):.3f} | {r['input_stall_cycles']} | {r.get('ooo', '-')} | "
                     f"{r.get('maxocc', '-')} |\n")
        fh.write("\n## 4. Mixed stream vs output-ready probability (ROB_DEPTH = 8)\n\n| P(out_ready) | ops/cycle | "
                 "backpressure cycles | input-stall cycles |\n|---|---|---|---|\n")
        for pr in (100, 75, 50, 25):
            r = res[("ready", pr)]
            fh.write(f"| {pr} % | {float(r['throughput']):.3f} | {r['backpressure_cycles']} | "
                     f"{r['input_stall_cycles']} |\n")
    print("characterize: done -> reports/characterisation.md")


if __name__ == "__main__":
    main()
