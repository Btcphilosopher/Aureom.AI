#!/usr/bin/env python3
"""
SilicaFlux-HPC :: regress -- lane regression runner

Builds the testbench for each parameter configuration (Verilator 5.020 and/or
Icarus 12), runs the test matrix in parallel, parses TB_RESULT lines and
writes reports/regression.md plus one log per run in reports/logs/.

Usage:
  regress.py [--vec DIR] [--sim verilator|icarus|both] [--quick] [--jobs N]
"""
import argparse
import concurrent.futures as cf
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["hpc_vector_pkg.sv", "hpc_pipe.sv", "hpc_lzc.sv", "hpc_fp32_round.sv", "hpc_fp32_add.sv",
       "hpc_fp32_mul.sv", "hpc_fp32_fma.sv", "hpc_fp32_misc.sv", "hpc_int32_mul.sv",
       "hpc_vector_lane.sv"]
RTL = [os.path.join(ROOT, "rtl", f) for f in RTL]
TB = os.path.join(ROOT, "tb", "tb_hpc_vector_lane.sv")

BASE = dict(TAG_W=8, ROB_DEPTH=8, LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1,
            LAT_IMUL=2, EN_FCMP=1, EN_INT=1)
CONFIGS = {
    # name: overrides of BASE
    "default":         {},
    "minlat_d2_t4":    dict(TAG_W=4, ROB_DEPTH=2, LAT_FADD=2, LAT_FMUL=2, LAT_FMA=3, LAT_IMUL=1),
    "skew_d3_t1":      dict(TAG_W=1, ROB_DEPTH=3, LAT_FADD=5, LAT_FMUL=2, LAT_FMA=7,
                            LAT_MISC=1, LAT_IMUL=6),
    "d1_t16":          dict(TAG_W=16, ROB_DEPTH=1),
    "nofcmp_noint_d5": dict(TAG_W=6, ROB_DEPTH=5, LAT_MISC=2, LAT_FMA=5, EN_FCMP=0, EN_INT=0),
    "deep_d16_t12":    dict(TAG_W=12, ROB_DEPTH=16, LAT_FADD=4, LAT_FMUL=5, LAT_FMA=8,
                            LAT_MISC=3, LAT_IMUL=4),
}
ARITH_FILES = ["rand_fadd", "rand_fsub", "rand_fmul", "rand_fmadd", "rand_fmsub",
               "rand_fnmsub", "rand_fnmadd", "spec_fadd", "spec_fsub", "spec_fmul",
               "spec_fmadd", "spec_fmsub", "spec_fnmsub", "spec_fnmadd", "misc", "illegal"]
LANE_TESTS = [
    # name, vector file, plusargs
    ("mixed_b2b",    "mixed",   "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("order_b2b",    "order",   "+P_VALID=100 +P_READY=100 +P_EN=100"),
    ("stall",        "mixed",   "+P_VALID=70 +P_READY=40 +P_EN=100"),
    ("backpressure", "order",   "+P_VALID=100 +P_READY=5 +P_EN=100"),
    ("disabled",     "mixed",   "+P_VALID=85 +P_READY=75 +P_EN=55"),
    ("reset",        "mixed",   "+P_VALID=80 +P_READY=60 +P_EN=80 +P_RESET=30"),
    ("illegal",      "illegal", "+P_VALID=90 +P_READY=70 +P_EN=90"),
]


def cfg_params(name):
    p = dict(BASE)
    p.update(CONFIGS[name])
    return p


def build_verilator(name, outdir):
    p = cfg_params(name)
    mdir = os.path.join(outdir, f"vl_{name}")
    exe = os.path.join(mdir, "tb")
    gargs = [f"-G{k}={v}" for k, v in p.items()]
    cmd = ["verilator", "--binary", "--timing", "-O3", "-j", "2", "--timescale", "1ns/1ps",
           "-Wno-fatal", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC",
           "--top-module", "tb_hpc_vector_lane", "--Mdir", mdir, "-o", "tb"] + gargs + RTL + [TB]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"verilator build {name} failed:\n{r.stdout}\n{r.stderr}")
    return [exe]


def build_icarus(name, outdir):
    p = cfg_params(name)
    os.makedirs(outdir, exist_ok=True)
    out = os.path.join(outdir, f"iv_{name}.vvp")
    pargs = []
    for k, v in p.items():
        pargs += ["-P", f"tb_hpc_vector_lane.{k}={v}"]
    cmd = ["iverilog", "-g2012", "-o", out, "-s", "tb_hpc_vector_lane"] + pargs + RTL + [TB]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"icarus build {name} failed:\n{r.stdout}\n{r.stderr}")
    return ["vvp", "-n", out]


RES_RE = re.compile(r"TB_RESULT (\w+) (.*)")
COV_RE = re.compile(r"multi-unit-completion cycles=(\d+) out-of-order-completions=(\d+) "
                    r"rob-full cycles=(\d+) max occupancy=(\d+)")


def run(exe, vec, plus, seed, log):
    t0 = time.time()
    cmd = exe + [f"+VEC={vec}", f"+SEED={seed}"] + plus.split()
    r = subprocess.run(cmd, capture_output=True, text=True)
    dt = time.time() - t0
    with open(log, "w") as fh:
        fh.write(" ".join(cmd) + "\n" + r.stdout + r.stderr)
    m = RES_RE.search(r.stdout)
    res = {"status": "FAIL", "time": dt}
    if m:
        res["status"] = m.group(1)
        for kv in m.group(2).split():
            if "=" in kv:
                k, v = kv.split("=", 1)
                res[k] = v
    c = COV_RE.search(r.stdout)
    if c:
        res.update(multi=c.group(1), ooo=c.group(2), full=c.group(3), maxocc=c.group(4))
    return res


def head_file(src, dst, n):
    with open(src) as fi, open(dst, "w") as fo:
        for i, line in enumerate(fi):
            if i >= n:
                break
            fo.write(line)
    return dst


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vec", default=os.path.join(ROOT, "build", "vec"))
    ap.add_argument("--sim", default="both")
    ap.add_argument("--quick", action="store_true", help="truncate every vector file")
    ap.add_argument("--jobs", type=int, default=os.cpu_count())
    ap.add_argument("--icarus-lines", type=int, default=20000)
    args = ap.parse_args()
    bdir = os.path.join(ROOT, "build", "regress")
    logdir = os.path.join(ROOT, "reports", "logs")
    os.makedirs(bdir, exist_ok=True)
    os.makedirs(logdir, exist_ok=True)

    sims = ["verilator", "icarus"] if args.sim == "both" else [args.sim]
    exes = {}
    with cf.ThreadPoolExecutor(args.jobs) as ex:
        futs = {}
        for s in sims:
            for c in CONFIGS:
                fn = build_verilator if s == "verilator" else build_icarus
                futs[ex.submit(fn, c, bdir)] = (s, c)
        for f in cf.as_completed(futs):
            exes[futs[f]] = f.result()

    def vecpath(name, sim):
        p = os.path.join(args.vec, name + ".vec")
        limit = args.icarus_lines if sim == "icarus" else (20000 if args.quick else None)
        if limit:
            q = os.path.join(bdir, f"{name}.head{limit}.vec")
            if not os.path.exists(q):
                head_file(p, q, limit)
            return q
        return p

    jobs = []
    seed = 1000
    for s in sims:
        # arithmetic correctness: every opcode file at full rate
        for c in (["default", "deep_d16_t12"] if s == "verilator" else ["default"]):
            for f in ARITH_FILES:
                seed += 1
                jobs.append((s, c, "arith:" + f, vecpath(f, s),
                             "+P_VALID=100 +P_READY=100 +P_EN=100", seed))
        for c in CONFIGS:
            for (tn, f, plus) in LANE_TESTS:
                seed += 1
                jobs.append((s, c, tn, vecpath(f, s), plus, seed))

    results = []
    with cf.ThreadPoolExecutor(args.jobs) as ex:
        futs = {}
        for (s, c, tn, vec, plus, sd) in jobs:
            log = os.path.join(logdir, f"{s}__{c}__{tn.replace(':', '_')}.log")
            futs[ex.submit(run, exes[(s, c)], vec, plus, sd, log)] = (s, c, tn, plus, sd)
        for f in cf.as_completed(futs):
            s, c, tn, plus, sd = futs[f]
            r = f.result()
            results.append((s, c, tn, plus, sd, r))
            print(f"{r['status']:4s} {s:9s} {c:16s} {tn:22s} vectors={r.get('vectors','?'):>8s} "
                  f"errors={r.get('errors','?')} ({r['time']:.1f}s)", flush=True)

    order = {c: i for i, c in enumerate(CONFIGS)}
    results.sort(key=lambda x: (x[0], order[x[1]], x[2]))
    npass = sum(1 for x in results if x[5]["status"] == "PASS")
    with open(os.path.join(ROOT, "reports", "regression.md"), "w") as fh:
        fh.write("# Lane regression results\n\n")
        fh.write("Generated by `scripts/regress.py`.  Every row is one simulation; "
                 "`errors` counts scoreboard/protocol/event/X-check failures.\n\n")
        fh.write("## Configurations\n\n| config | parameters |\n|---|---|\n")
        for c in CONFIGS:
            fh.write(f"| {c} | " + ", ".join(f"{k}={v}" for k, v in cfg_params(c).items()) + " |\n")
        fh.write(f"\n## Runs: {npass}/{len(results)} PASS\n\n")
        fh.write("| sim | config | test | knobs | seed | vectors | accepted | retired | masked | "
                 "illegal | flushed (reset) | resets | cycles | in-stall cyc | backpr. cyc | "
                 "ops/cycle | multi-cmpl cyc | OoO completions | ROB-full cyc | max occ | errors | result |\n")
        fh.write("|" + "---|" * 22 + "\n")
        for (s, c, tn, plus, sd, r) in results:
            knobs = plus.replace("+", "").replace(" ", " ")
            fh.write(f"| {s} | {c} | {tn} | {knobs} | {sd} | {r.get('vectors','')} | "
                     f"{r.get('accepted','')} | {r.get('retired','')} | {r.get('masked','')} | "
                     f"{r.get('illegal','')} | {r.get('flushed_by_reset','')} | {r.get('resets','')} | "
                     f"{r.get('cycles','')} | {r.get('input_stall_cycles','')} | "
                     f"{r.get('backpressure_cycles','')} | {r.get('throughput','')} | "
                     f"{r.get('multi','-')} | {r.get('ooo','-')} | {r.get('full','-')} | "
                     f"{r.get('maxocc','-')} | {r.get('errors','?')} | **{r['status']}** |\n")
    print(f"regress: {npass}/{len(results)} PASS")
    sys.exit(0 if npass == len(results) else 1)


if __name__ == "__main__":
    main()
