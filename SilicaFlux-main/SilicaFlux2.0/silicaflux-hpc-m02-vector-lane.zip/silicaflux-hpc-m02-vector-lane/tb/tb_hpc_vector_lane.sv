// =============================================================================
// SilicaFlux-HPC :: tb_hpc_vector_lane -- self-checking lane testbench
//
// Drives a vector file (ref/gen_vectors.py format, expected values from the
// exact IEEE reference model) through hpc_vector_lane with randomized
// valid / ready / lane-enable / asynchronous reset injection and checks, on
// every cycle:
//   * results, flags, tags and illegal bits retire EXACTLY ONCE and IN
//     ACCEPTANCE ORDER (scoreboard queue: no drop, no duplicate, no
//     misassociation); disabled operations produce no result
//   * valid/ready protocol: output payload stable while out_valid & ~ready,
//     in_ready is never asserted during reset or the first cycle after it
//   * every performance event pulse matches the handshake it reports
//   * busy_o matches the number of in-flight operations
//   * no X/Z on any lane output (4-state simulators)
// and measures per-opcode latency, throughput and structural coverage.
//
// Plusargs: +VEC=file +SEED=n +P_VALID=% +P_READY=% +P_EN=% +P_RESET=1/10000
//           +GAP=n (idle cycles forced after every acceptance; latency
//           characterisation) +MAX_CYCLES=n +QUIET +TRACE
// Define GATE to simulate the synthesized netlist (no internal probes).
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module tb_hpc_vector_lane;
  parameter int TAG_W     = 8;
  parameter int ROB_DEPTH = 8;
  parameter int LAT_FADD  = 3;
  parameter int LAT_FMUL  = 3;
  parameter int LAT_FMA   = 4;
  parameter int LAT_MISC  = 1;
  parameter int LAT_IMUL  = 2;
  parameter bit EN_FCMP   = 1'b1;
  parameter bit EN_INT    = 1'b1;

  localparam int QD = 4096;                  // scoreboard depth (>> ROB_DEPTH)

  // ------------------------------------------------------------ DUT wiring
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  logic             in_valid = 1'b0;
  wire              in_ready;
  logic [4:0]       in_op = '0;
  logic [31:0]      in_a = '0, in_b = '0, in_c = '0;
  logic [2:0]       in_rm = '0;
  logic [TAG_W-1:0] in_tag = '0;
  logic             lane_en = 1'b0;
  wire              out_valid;
  logic             out_ready = 1'b0;
  wire [31:0]       out_result;
  wire [4:0]        out_flags;
  wire [TAG_W-1:0]  out_tag;
  wire              out_illegal;
  wire              busy;
  wire              ev_accept, ev_retire, ev_pipe_stall, ev_backpressure, ev_illegal, ev_masked;

`ifdef GATE
  hpc_vector_lane dut (
`else
  hpc_vector_lane #(
    .DATA_W(32), .TAG_W(TAG_W), .ROB_DEPTH(ROB_DEPTH),
    .LAT_FADD(LAT_FADD), .LAT_FMUL(LAT_FMUL), .LAT_FMA(LAT_FMA),
    .LAT_MISC(LAT_MISC), .LAT_IMUL(LAT_IMUL), .EN_FCMP(EN_FCMP), .EN_INT(EN_INT)
  ) dut (
`endif
    .clk_i(clk), .rst_ni(rst_n),
    .in_valid_i(in_valid), .in_ready_o(in_ready), .in_op_i(in_op),
    .in_a_i(in_a), .in_b_i(in_b), .in_c_i(in_c), .in_rm_i(in_rm),
    .in_tag_i(in_tag), .lane_en_i(lane_en),
    .out_valid_o(out_valid), .out_ready_i(out_ready), .out_result_o(out_result),
    .out_flags_o(out_flags), .out_tag_o(out_tag), .out_illegal_o(out_illegal),
    .busy_o(busy),
    .ev_accept_o(ev_accept), .ev_retire_o(ev_retire), .ev_pipe_stall_o(ev_pipe_stall),
    .ev_backpressure_o(ev_backpressure), .ev_illegal_o(ev_illegal), .ev_masked_o(ev_masked));

  // ------------------------------------------------------------ config
  reg [8*512-1:0] vec_file;
  int seed, p_valid, p_ready, p_en, p_reset, max_cycles, quiet, trace, gap, gap_cnt;

  function automatic logic [31:0] xs(input logic [31:0] x);
    logic [31:0] y;
    y = x;
    y = y ^ (y << 13);
    y = y ^ (y >> 17);
    y = y ^ (y << 5);
    xs = y;
  endfunction

  logic [31:0] rng_drv, rng_rdy, rng_rst;     // independent per-process streams

  // ------------------------------------------------------------ scoreboard
  logic [31:0]      q_res  [QD];
  logic [4:0]       q_flg  [QD];
  logic [TAG_W-1:0] q_tag  [QD];
  logic             q_ill  [QD];
  logic [4:0]       q_op   [QD];
  longint           q_cyc  [QD];
  longint           q_vno  [QD];
  int q_head = 0, q_tail = 0, q_cnt = 0;

  // ------------------------------------------------------------ stimulus state
  int     fd;
  logic   have_txn = 1'b0, eof = 1'b0, drv_is_txn = 1'b0;
  logic [4:0]  c_op;  logic [2:0] c_rm;  logic [31:0] c_a, c_b, c_c, c_res;
  logic [4:0]  c_flg; logic c_ill, c_en;  logic [TAG_W-1:0] c_tag;
  longint c_vno = 0;
  logic [TAG_W-1:0] tag_ctr = '0;

  // ------------------------------------------------------------ statistics
  longint cyc = 0, cyc_since_rst = 0, n_vec = 0;
  longint n_acc = 0, n_ret = 0, n_mask = 0, n_ill = 0, n_stall = 0, n_bp = 0, n_flush = 0;
  longint ev_acc_cnt = 0, ev_ret_cnt = 0, ev_mask_cnt = 0, ev_ill_cnt = 0, ev_stall_cnt = 0, ev_bp_cnt = 0;
  longint first_acc = -1, last_ret = 0, last_progress = 0;
  longint lat_min [32], lat_max [32], lat_sum [32], op_cnt [32];
  longint flag_cnt [5];
  longint n_resets = 0, n_errors = 0, n_multi_cmp = 0, n_ooo_cmp = 0, n_rob_full = 0;
  int     max_occ = 0;
  logic   prev_hold = 1'b0;
  logic [31:0] prev_res; logic [4:0] prev_flg; logic [TAG_W-1:0] prev_tag; logic prev_ill;

  // X/Z detection.  The reduction XOR of a vector containing any X/Z bit is
  // X.  (Icarus 12 returns 1 from $isunknown() on a concatenation even when
  // every bit is known, so $isunknown is not used.)
  function automatic logic has_x(input logic [127:0] v);
    has_x = ((^v) === 1'bx);
  endfunction

  task automatic fail(input [8*200-1:0] msg);
    n_errors = n_errors + 1;
    if (n_errors <= 20) $display("ERROR @cyc %0d: %0s", cyc, msg);
  endtask

  // expected-value adjustment for configurations with optional ops removed
  function automatic logic op_disabled_by_cfg(input logic [4:0] op);
    op_disabled_by_cfg = (!EN_FCMP && op >= 5'h08 && op <= 5'h0C) ||
                         (!EN_INT  && (op == 5'h10 || op == 5'h11));
  endfunction

  task automatic load_next();
    int rc;
    logic [31:0] f_op, f_rm, f_a, f_b, f_c, f_res, f_flg, f_ill;
    rc = $fscanf(fd, "%h %h %h %h %h %h %h %h\n", f_op, f_rm, f_a, f_b, f_c, f_res, f_flg, f_ill);
    if (rc != 8) begin
      eof = 1'b1;
      have_txn = 1'b0;
    end else begin
      c_op = f_op[4:0]; c_rm = f_rm[2:0]; c_a = f_a; c_b = f_b; c_c = f_c;
      c_res = f_res; c_flg = f_flg[4:0]; c_ill = f_ill[0];
      if (op_disabled_by_cfg(c_op)) begin c_res = '0; c_flg = '0; c_ill = 1'b1; end
      rng_drv = xs(rng_drv);
      c_en  = (rng_drv % 100) < p_en;
      c_tag = tag_ctr;
      tag_ctr = tag_ctr + 1'b1;
      c_vno = n_vec;
      n_vec = n_vec + 1;
      have_txn = 1'b1;
    end
  endtask

  // ------------------------------------------------------------ main process
  always @(posedge clk) begin : main
    logic [31:0] r;
    if (!rst_n) begin
      // reset: everything in flight is discarded by design
      if (q_cnt != 0) n_flush = n_flush + q_cnt;
      q_head = 0; q_tail = 0; q_cnt = 0;
      prev_hold = 1'b0;
      cyc_since_rst = 0;
      // the lane must ignore in_valid during reset and at the first edge
      // after release: drive random garbage requests in this window
      drv_is_txn = 1'b0;
      rng_drv = xs(rng_drv);
      in_valid <= rng_drv[0];
      in_op <= rng_drv[5:1]; in_rm <= rng_drv[8:6]; lane_en <= rng_drv[9];
      in_a <= xs(rng_drv); in_tag <= rng_drv[10 +: TAG_W];
      out_ready <= rng_drv[31];
    end else begin
      cyc = cyc + 1;
      cyc_since_rst = cyc_since_rst + 1;

      // ---------------------------------------------------- X checks
      if (has_x({in_ready, out_valid, busy, ev_accept, ev_retire, ev_pipe_stall,
                 ev_backpressure, ev_illegal, ev_masked}))
        fail("X/Z on lane control output");
      if (has_x({out_result, out_flags, out_tag, out_illegal}))
        fail("X/Z on lane payload output");

      // ---------------------------------------------------- protocol checks
      if (cyc_since_rst == 1 && in_ready) fail("in_ready high in first cycle after reset");
      if (prev_hold) begin
        if (!out_valid) fail("out_valid dropped without handshake");
        else if (out_result !== prev_res || out_flags !== prev_flg || out_tag !== prev_tag ||
                 out_illegal !== prev_ill)
          fail("output payload changed while stalled");
      end
      if (!out_valid && (out_result != 0 || out_flags != 0 || out_tag != 0 || out_illegal))
        fail("payload not zero while out_valid=0");
      if ((busy != 0) != (q_cnt != 0)) fail("busy_o does not match in-flight operations");

      // ---------------------------------------------------- event checks
      if (ev_accept != (in_valid && in_ready && lane_en)) fail("ev_accept mismatch");
      if (ev_masked != (in_valid && in_ready && !lane_en)) fail("ev_masked mismatch");
      if (ev_retire != (out_valid && out_ready)) fail("ev_retire mismatch");
      if (ev_backpressure != (out_valid && !out_ready)) fail("ev_backpressure mismatch");
      if (ev_pipe_stall != (in_valid && !in_ready && cyc_since_rst > 1)) fail("ev_pipe_stall mismatch");
      if (ev_illegal != (in_valid && in_ready && lane_en && c_ill)) fail("ev_illegal mismatch");
      ev_acc_cnt += ev_accept; ev_ret_cnt += ev_retire; ev_mask_cnt += ev_masked;
      ev_ill_cnt += ev_illegal; ev_stall_cnt += ev_pipe_stall; ev_bp_cnt += ev_backpressure;
      if (in_valid && !in_ready) n_stall = n_stall + 1;
      if (out_valid && !out_ready) n_bp = n_bp + 1;

`ifndef GATE
      // ---------------------------------------------------- structural coverage
      begin
        int nv;
        nv = 0;
        for (int u = 0; u < 5; u++) nv = nv + int'(dut.u_vld[u]);
        if (nv > 1) n_multi_cmp = n_multi_cmp + 1;
        // completion inversion: an op completes while an OLDER in-flight op
        // (between head and its slot) has not completed yet
        for (int e = 0; e < ROB_DEPTH; e++) begin
          if (dut.cmp_hit[e]) begin
            int k;
            logic inv;
            k = int'(dut.head_q);
            inv = 1'b0;
            while (k != e) begin
              if (!dut.rob_done_q[k] && !dut.cmp_hit[k]) inv = 1'b1;
              k = (k + 1) % ROB_DEPTH;
            end
            if (inv) n_ooo_cmp = n_ooo_cmp + 1;
          end
        end
        if (int'(dut.cnt_q) > max_occ) max_occ = int'(dut.cnt_q);
        if (int'(dut.cnt_q) == ROB_DEPTH) n_rob_full = n_rob_full + 1;
        if (trace)
          $display("TRACE cyc=%0d in_v=%0b rdy=%0b op=%02h en=%0b | iss_v=%05b u_vld=%05b cmp_hit=%b head=%0d tail=%0d cnt=%0d done=%b | out_v=%0b rdy=%0b tag=%0h res=%08h",
                   cyc, in_valid, in_ready, in_op, lane_en, dut.iss_v_q, dut.u_vld, dut.cmp_hit,
                   dut.head_q, dut.tail_q, dut.cnt_q, dut.rob_done_q, out_valid, out_ready, out_tag, out_result);
      end
`endif

      // ---------------------------------------------------- retirement
      if (out_valid && out_ready) begin
        n_ret = n_ret + 1;
        last_ret = cyc;
        last_progress = cyc;
        if (q_cnt == 0) begin
          fail("result retired with no operation outstanding (duplicate/spurious)");
        end else begin
          if (out_tag !== q_tag[q_head] || out_result !== q_res[q_head] ||
              out_flags !== q_flg[q_head] || out_illegal !== q_ill[q_head]) begin
            n_errors = n_errors + 1;
            if (n_errors <= 20)
              $display("ERROR @cyc %0d vec#%0d op=%02h: got tag=%0h res=%08h flg=%02h ill=%0b exp tag=%0h res=%08h flg=%02h ill=%0b",
                       cyc, q_vno[q_head], q_op[q_head], out_tag, out_result, out_flags, out_illegal,
                       q_tag[q_head], q_res[q_head], q_flg[q_head], q_ill[q_head]);
          end
          begin
            longint l;
            l = cyc - q_cyc[q_head];
            if (op_cnt[q_op[q_head]] == 0 || l < lat_min[q_op[q_head]]) lat_min[q_op[q_head]] = l;
            if (l > lat_max[q_op[q_head]]) lat_max[q_op[q_head]] = l;
            lat_sum[q_op[q_head]] += l;
            op_cnt[q_op[q_head]] += 1;
          end
          for (int f = 0; f < 5; f++) if (out_flags[f]) flag_cnt[f] += 1;
          q_head = (q_head + 1) % QD;
          q_cnt = q_cnt - 1;
        end
      end
      prev_hold = out_valid && !out_ready;
      prev_res = out_result; prev_flg = out_flags; prev_tag = out_tag; prev_ill = out_illegal;

      // ---------------------------------------------------- acceptance
      if (in_valid && in_ready && !drv_is_txn) fail("garbage request accepted (reset window)");
      if (in_valid && in_ready && drv_is_txn) begin
        last_progress = cyc;
        if (first_acc < 0) first_acc = cyc;
        if (lane_en) begin
          n_acc = n_acc + 1;
          if (c_ill) n_ill = n_ill + 1;
          if (q_cnt == QD) fail("scoreboard overflow");
          q_res[q_tail] = c_ill ? 32'd0 : c_res;
          q_flg[q_tail] = c_ill ? 5'd0 : c_flg;
          q_ill[q_tail] = c_ill;
          q_tag[q_tail] = c_tag;
          q_op [q_tail] = c_op;
          q_cyc[q_tail] = cyc;
          q_vno[q_tail] = c_vno;
          q_tail = (q_tail + 1) % QD;
          q_cnt = q_cnt + 1;
        end else begin
          n_mask = n_mask + 1;
        end
        have_txn = 1'b0;
        gap_cnt = gap;
      end

      // ---------------------------------------------------- next drive
      if (!have_txn && !eof) load_next();
      if (in_valid && !in_ready && have_txn && drv_is_txn) begin
        in_valid <= 1'b1;                     // hold: payload stays stable
      end else begin
        rng_drv = xs(rng_drv);
        drv_is_txn = 1'b0;
        if (gap_cnt > 0) begin
          gap_cnt = gap_cnt - 1;
          in_valid <= 1'b0;                   // forced idle (latency measurement)
        end else if (have_txn && (rng_drv % 100) < p_valid) begin
          drv_is_txn = 1'b1;
          in_valid <= 1'b1;
          in_op <= c_op; in_rm <= c_rm; in_a <= c_a; in_b <= c_b; in_c <= c_c;
          in_tag <= c_tag; lane_en <= c_en;
        end else begin
          // idle: random garbage on the payload must be ignored
          in_valid <= 1'b0;
          rng_drv = xs(rng_drv); in_a <= rng_drv;
          rng_drv = xs(rng_drv); in_b <= rng_drv;
          rng_drv = xs(rng_drv); in_c <= rng_drv;
          in_op <= rng_drv[4:0]; in_rm <= rng_drv[7:5]; lane_en <= rng_drv[8];
          in_tag <= rng_drv[9 +: TAG_W];
        end
      end
      rng_rdy = xs(rng_rdy);
      r = rng_rdy % 100;
      out_ready <= (r < p_ready);

      // ---------------------------------------------------- termination
      if (eof && !have_txn && q_cnt == 0 && !busy) finish_test();
      if (cyc - last_progress > 5000) begin
        fail("no progress for 5000 cycles (deadlock)");
        finish_test();
      end
      if (cyc >= max_cycles) begin
        fail("MAX_CYCLES reached");
        finish_test();
      end
    end
  end

  // ------------------------------------------------------------ reset process
  initial begin : reset_proc
    rst_n = 1'b0;
    repeat (4) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    if (p_reset > 0) begin
      forever begin
        @(posedge clk);
        rng_rst = xs(rng_rst);
        if ((rng_rst % 10000) < p_reset && !eof) begin
          #(1 + rng_rst[18:16]);              // asynchronous assertion mid-cycle
          rst_n = 1'b0;
          n_resets = n_resets + 1;
          #0.1;
          if (out_valid !== 1'b0 || in_ready !== 1'b0 || busy !== 1'b0 ||
              ev_accept !== 1'b0 || ev_retire !== 1'b0)
            fail("outputs not in reset state immediately after rst_ni assertion");
          repeat (1 + rng_rst[21:20]) @(posedge clk);
          @(negedge clk) rst_n = 1'b1;          // synchronous-style de-assertion
        end
      end
    end
  end

  // ------------------------------------------------------------ report
  task automatic finish_test();
    longint span;
    $fclose(fd);
    if (ev_acc_cnt != n_acc || ev_ret_cnt != n_ret || ev_mask_cnt != n_mask || ev_ill_cnt != n_ill)
      fail("event pulse totals do not match handshake totals");
    if (p_reset == 0 && n_acc != n_ret) fail("accepted != retired");
    if (n_acc + n_mask + n_flush < 0) fail("impossible");
    span = (first_acc >= 0) ? (last_ret - first_acc + 1) : 1;
    if (!quiet) begin
      $display("---- per-opcode latency (accept cycle -> retire cycle), count");
      for (int o = 0; o < 32; o++)
        if (op_cnt[o] > 0)
          $display("  op %02h  n=%0d  lat min=%0d max=%0d avg=%0.2f", o, op_cnt[o], lat_min[o],
                   lat_max[o], real'(lat_sum[o]) / real'(op_cnt[o]));
      $display("---- flags raised: NV=%0d DZ=%0d OF=%0d UF=%0d NX=%0d",
               flag_cnt[4], flag_cnt[3], flag_cnt[2], flag_cnt[1], flag_cnt[0]);
      $display("---- coverage: multi-unit-completion cycles=%0d out-of-order-completions=%0d rob-full cycles=%0d max occupancy=%0d",
               n_multi_cmp, n_ooo_cmp, n_rob_full, max_occ);
    end
    $display("TB_RESULT %s vectors=%0d accepted=%0d retired=%0d masked=%0d illegal=%0d flushed_by_reset=%0d resets=%0d cycles=%0d input_stall_cycles=%0d backpressure_cycles=%0d throughput=%0.4f ops/cycle errors=%0d",
             (n_errors == 0) ? "PASS" : "FAIL", n_vec, n_acc, n_ret, n_mask, n_ill, n_flush,
             n_resets, cyc, n_stall, n_bp, real'(n_ret) / real'(span), n_errors);
    $finish;
  endtask

  initial begin : config_proc
    if (!$value$plusargs("VEC=%s", vec_file)) begin
      $display("TB_RESULT FAIL missing +VEC=<file>");
      $finish;
    end
    if (!$value$plusargs("SEED=%d", seed))          seed = 1;
    if (!$value$plusargs("P_VALID=%d", p_valid))    p_valid = 100;
    if (!$value$plusargs("P_READY=%d", p_ready))    p_ready = 100;
    if (!$value$plusargs("P_EN=%d", p_en))          p_en = 100;
    if (!$value$plusargs("P_RESET=%d", p_reset))    p_reset = 0;
    if (!$value$plusargs("MAX_CYCLES=%d", max_cycles)) max_cycles = 2000000000;
    if (!$value$plusargs("GAP=%d", gap))            gap = 0;
    gap_cnt = 0;
    quiet = $test$plusargs("QUIET");
    trace = $test$plusargs("TRACE");
    rng_drv = 32'h9E3779B9 ^ seed;
    rng_rdy = 32'h85EBCA6B ^ (seed * 3 + 1);
    rng_rst = 32'hC2B2AE35 ^ (seed * 7 + 5);
    for (int o = 0; o < 32; o++) begin lat_min[o] = 0; lat_max[o] = 0; lat_sum[o] = 0; op_cnt[o] = 0; end
    for (int f = 0; f < 5; f++) flag_cnt[f] = 0;
    fd = $fopen(vec_file, "r");
    if (fd == 0) begin
      $display("TB_RESULT FAIL cannot open %0s", vec_file);
      $finish;
    end
  end
endmodule
