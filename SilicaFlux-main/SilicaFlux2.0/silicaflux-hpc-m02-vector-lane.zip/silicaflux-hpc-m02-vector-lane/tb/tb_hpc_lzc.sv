// =============================================================================
// SilicaFlux-HPC :: tb_hpc_lzc -- unit test of the log-depth leading-zero counter
//   W = 24 : exhaustive (all 2^24 inputs)
//   W = 48, 51, 81 : zero, and for every leading-one position 2000 random
//                    lower-bit patterns
// Reference: linear scan.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps
module tb_hpc_lzc;
  logic [23:0] x24; wire [4:0] c24;
  logic [47:0] x48; wire [5:0] c48;
  logic [50:0] x51; wire [5:0] c51;
  logic [80:0] x81; wire [6:0] c81;
  hpc_lzc #(.W(24)) u24 (.x_i(x24), .cnt_o(c24));
  hpc_lzc #(.W(48)) u48 (.x_i(x48), .cnt_o(c48));
  hpc_lzc #(.W(51)) u51 (.x_i(x51), .cnt_o(c51));
  hpc_lzc #(.W(81)) u81 (.x_i(x81), .cnt_o(c81));
  int errors = 0;
  longint checks = 0;
  logic [31:0] r = 32'h1234567;
  function automatic int ref_lzc(input logic [127:0] x, input int w);
    ref_lzc = w;
    for (int i = 0; i < w; i++) if (x[i]) ref_lzc = w - 1 - i;
  endfunction
  function automatic logic [31:0] xs(input logic [31:0] v);
    logic [31:0] y; y = v; y = y ^ (y << 13); y = y ^ (y >> 17); y = y ^ (y << 5); xs = y;
  endfunction
  task automatic chk(input int got, input int exp, input int w, input logic [127:0] x);
    checks = checks + 1;
    if (got != exp) begin
      errors = errors + 1;
      if (errors < 10) $display("ERROR W=%0d x=%h got %0d exp %0d", w, x, got, exp);
    end
  endtask
  initial begin
    for (int i = 0; i < (1 << 24); i++) begin
      x24 = i[23:0]; #1;
      chk(int'(c24), ref_lzc(128'(i), 24), 24, 128'(i));
    end
    x48 = '0; x51 = '0; x81 = '0; #1;
    chk(int'(c48), 48, 48, 0); chk(int'(c51), 51, 51, 0); chk(int'(c81), 81, 81, 0);
    for (int p = 0; p < 81; p++) begin
      for (int k = 0; k < 2000; k++) begin
        logic [127:0] rnd;
        r = xs(r); rnd[31:0] = r; r = xs(r); rnd[63:32] = r; r = xs(r); rnd[95:64] = r; r = xs(r); rnd[127:96] = r;
        rnd = rnd & ((128'd1 << p) - 1);
        rnd = rnd | (128'd1 << p);
        if (p < 48) begin x48 = rnd[47:0]; end
        if (p < 51) begin x51 = rnd[50:0]; end
        x81 = rnd[80:0];
        #1;
        if (p < 48) chk(int'(c48), ref_lzc(rnd, 48), 48, rnd);
        if (p < 51) chk(int'(c51), ref_lzc(rnd, 51), 51, rnd);
        chk(int'(c81), ref_lzc(rnd, 81), 81, rnd);
      end
    end
    $display("TB_RESULT %s hpc_lzc checks=%0d errors=%0d", errors == 0 ? "PASS" : "FAIL", checks, errors);
    $finish;
  end
endmodule
