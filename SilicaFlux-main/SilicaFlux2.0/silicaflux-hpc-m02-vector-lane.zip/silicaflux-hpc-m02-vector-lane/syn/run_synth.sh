#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC :: run_synth.sh -- Yosys 0.33 synthesis smoke test
#
# Technology-independent synthesis of hpc_vector_lane (generic Yosys gate
# library, ABC mapping) for several parameter sets.  For each configuration:
#   * elaboration with hierarchy -check (no missing modules / bad parameters)
#   * synth -flatten, then `check -assert` (no combinational loops, no
#     multiple drivers, no undriven nets in use)
#   * assertion that NO latches were inferred
#   * cell statistics (flattened, and per module for the default config)
#   * longest combinational path in generic cells (`ltp -noff`): a STRUCTURAL
#     depth indicator only -- NOT a timing or frequency result
#   * gate-level netlist for post-synthesis simulation (default config)
#
# No clock frequency is claimed: that requires a standard-cell library,
# constraints and static timing analysis on an implemented netlist.
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/synth"
BLD="$ROOT/build/syn"
mkdir -p "$OUT" "$BLD"
RTL="hpc_vector_pkg.sv hpc_pipe.sv hpc_lzc.sv hpc_fp32_round.sv hpc_fp32_add.sv hpc_fp32_mul.sv \
     hpc_fp32_fma.sv hpc_fp32_misc.sv hpc_int32_mul.sv hpc_vector_lane.sv"
READ=""
for f in $RTL; do READ="$READ $ROOT/rtl/$f"; done

declare -A CFG
CFG[default]=""
CFG[minlat_d2_t4]="-chparam TAG_W 4 -chparam ROB_DEPTH 2 -chparam LAT_FADD 2 -chparam LAT_FMUL 2 -chparam LAT_FMA 3 -chparam LAT_IMUL 1"
CFG[deep_d16_t12]="-chparam TAG_W 12 -chparam ROB_DEPTH 16 -chparam LAT_FADD 4 -chparam LAT_FMUL 5 -chparam LAT_FMA 8 -chparam LAT_MISC 3 -chparam LAT_IMUL 4"
CFG[nofcmp_noint_d5]="-chparam TAG_W 6 -chparam ROB_DEPTH 5 -chparam LAT_MISC 2 -chparam LAT_FMA 5 -chparam EN_FCMP 0 -chparam EN_INT 0"

for name in default minlat_d2_t4 deep_d16_t12 nofcmp_noint_d5; do
  echo "== synth $name"
  NETLIST=""
  if [ "$name" = default ]; then
    NETLIST="write_verilog -noattr $BLD/hpc_vector_lane_netlist.v"
  fi
  yosys -q -l "$OUT/yosys_$name.log" -p "
    read_verilog -sv $READ
    hierarchy -check -top hpc_vector_lane ${CFG[$name]}
    synth -top hpc_vector_lane -flatten
    check -assert
    select -assert-none t:\$dlatch t:\$adlatch t:\$dlatchsr t:\$_DLATCH_* t:\$_DLATCHSR_*
    tee -q -o $OUT/stat_$name.txt stat
    tee -q -o $OUT/ltp_$name.txt ltp -noff
    $NETLIST
  "
  echo "   cells: $(grep -m1 'Number of cells' "$OUT/stat_$name.txt" | awk '{print $NF}')" \
       " longest path: $(grep -m1 -o 'Longest topological path.*' "$OUT/ltp_$name.txt" || true)"
done

# per-module breakdown (hierarchical, default parameters)
yosys -q -l "$OUT/yosys_hier_default.log" -p "
  read_verilog -sv $READ
  hierarchy -check -top hpc_vector_lane
  synth -top hpc_vector_lane
  check -assert
  tee -q -o $OUT/stat_hier_default.txt stat
"
# structural depth per execution unit (each unit given one spare output stage
# so that every combinational segment is bounded by registers)
: > "$OUT/unit_depth.txt"
for u in "hpc_fp32_add LAT 3" "hpc_fp32_mul LAT 3" "hpc_fp32_fma LAT 4" "hpc_fp32_misc LAT 2" "hpc_int32_mul LAT 2"; do
  set -- $u
  yosys -q -p "
    read_verilog -sv $READ
    hierarchy -check -top $1 -chparam $2 $3
    synth -top $1 -flatten
    check -assert
    tee -q -o $BLD/ltp_$1.txt ltp -noff
    tee -q -o $BLD/stat_$1.txt stat
  "
  printf "%-16s %s=%s  cells=%-7s %s\n" "$1" "$2" "$3" \
    "$(grep -m1 'Number of cells' $BLD/stat_$1.txt | awk '{print $NF}')" \
    "$(grep -m1 -o 'length=[0-9]*' $BLD/ltp_$1.txt) from=$(grep -m1 -E '^ +0:' $BLD/ltp_$1.txt | awk '{print $2}') to=$(grep -m1 -E '^ +ff:' $BLD/ltp_$1.txt | awk '{print $2}')" \
    | tee -a "$OUT/unit_depth.txt"
done
echo "== synthesis smoke test passed (no latches, check -assert clean)"
