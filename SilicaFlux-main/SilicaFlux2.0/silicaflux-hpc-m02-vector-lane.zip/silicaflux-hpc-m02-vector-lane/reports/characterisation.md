# Measured latency and throughput (default latencies, cycle-level RTL simulation)

Default parameters: TAG_W=8, ROB_DEPTH=8, LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2, EN_FCMP=1, EN_INT=1.
All runs PASS the self-checking testbench (bit-exact results, in-order tags).  No clock frequency is implied by any number here.

## 1. Isolated latency (acceptance cycle to retirement cycle)

Every operation is followed by 12 forced idle cycles (`+GAP=12` > any latency), so no operation waits behind another.  Legal-only stream; illegal operations measured separately.

Latency L means: accepted in cycle t (in_valid & in_ready), `out_valid_o` first high in cycle t + L with `out_ready_i` held high.

| opcode | unit latency param | expected (LAT+1) | measured min | measured max | samples |
|---|---|---|---|---|---|
| FMV | LAT_MISC=1 | 2 | 2 | 2 | 1322 |
| FADD | LAT_FADD=3 | 4 | 4 | 4 | 1369 |
| FSUB | LAT_FADD=3 | 4 | 4 | 4 | 1370 |
| FMUL | LAT_FMUL=3 | 4 | 4 | 4 | 1362 |
| FMADD | LAT_FMA=4 | 5 | 5 | 5 | 1322 |
| FMSUB | LAT_FMA=4 | 5 | 5 | 5 | 1311 |
| FNMSUB | LAT_FMA=4 | 5 | 5 | 5 | 1325 |
| FNMADD | LAT_FMA=4 | 5 | 5 | 5 | 1328 |
| FMIN | LAT_MISC=1 | 2 | 2 | 2 | 1354 |
| FMAX | LAT_MISC=1 | 2 | 2 | 2 | 1275 |
| FEQ | LAT_MISC=1 | 2 | 2 | 2 | 1325 |
| FLT | LAT_MISC=1 | 2 | 2 | 2 | 1392 |
| FLE | LAT_MISC=1 | 2 | 2 | 2 | 1333 |
| IADD | LAT_MISC=1 | 2 | 2 | 2 | 1280 |
| IMUL | LAT_IMUL=2 | 3 | 3 | 3 | 1332 |
| illegal opcode / reserved rm | (no unit) | 1 | 1 | 1 | 2432 |

## 2. Back-to-back throughput per operation class vs ROB_DEPTH

Measured retired operations per cycle (P_VALID = P_READY = 100 %), analytical bound min(1, ROB_DEPTH / (LAT + 2)) in brackets.

| class (LAT) | D=1 | D=2 | D=3 | D=4 | D=5 | D=6 | D=8 |
|---|---|---|---|---|---|---|---|
| FMV/FMIN/FEQ (MISC) (LAT_MISC=1) | 0.333 [0.333] | 0.667 [0.667] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] |
| FADD/FSUB (LAT_FADD=3) | 0.200 [0.200] | 0.400 [0.400] | 0.600 [0.600] | 0.800 [0.800] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] |
| FMUL (LAT_FMUL=3) | 0.200 [0.200] | 0.400 [0.400] | 0.600 [0.600] | 0.800 [0.800] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] |
| FMA family (LAT_FMA=4) | 0.167 [0.167] | 0.333 [0.333] | 0.500 [0.500] | 0.667 [0.667] | 0.833 [0.833] | 1.000 [1.000] | 1.000 [1.000] |
| IMUL (LAT_IMUL=2) | 0.250 [0.250] | 0.500 [0.500] | 0.750 [0.750] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] | 1.000 [1.000] |

## 3. Mixed stream (all opcodes, 5 % illegal) vs ROB_DEPTH

| ROB_DEPTH | ops/cycle | input-stall cycles | OoO completions | max occupancy |
|---|---|---|---|---|
| 1 | 0.240 | 157861 | 0 | 1 |
| 2 | 0.438 | 64162 | 5675 | 2 |
| 3 | 0.609 | 32125 | 8997 | 3 |
| 4 | 0.753 | 16368 | 10680 | 4 |
| 5 | 0.890 | 6198 | 12253 | 5 |
| 6 | 1.000 | 0 | 13663 | 5 |
| 8 | 1.000 | 0 | 13663 | 5 |

## 4. Mixed stream vs output-ready probability (ROB_DEPTH = 8)

| P(out_ready) | ops/cycle | backpressure cycles | input-stall cycles |
|---|---|---|---|
| 100 % | 1.000 | 0 | 0 |
| 75 % | 0.749 | 16791 | 16788 |
| 50 % | 0.500 | 50074 | 50064 |
| 25 % | 0.251 | 149243 | 149228 |
