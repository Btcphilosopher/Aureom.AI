# Post-synthesis gate-level simulation

Netlist: Yosys 0.33 `synth -flatten` of `hpc_vector_lane` (default parameters), `write_verilog -noattr` (`build/syn/hpc_vector_lane_netlist.v`).  Testbench: `tb/tb_hpc_vector_lane.sv` compiled with `GATE` (no internal probes).  Icarus runs are 4-state, so any X escaping the unreset datapath registers would fail the testbench's per-cycle X checks.

## 22/22 PASS

| sim | test | knobs | seed | vectors | accepted | retired | masked | illegal | resets | cycles | errors | result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| icarus | arith:misc | P_VALID=100 P_READY=100 P_EN=100 | 604 | 4000 | 4000 | 4000 | 0 | 0 | 0 | 4004 | 0 | **PASS** |
| icarus | arith:rand_fadd | P_VALID=100 P_READY=100 P_EN=100 | 601 | 4000 | 4000 | 4000 | 0 | 0 | 0 | 4006 | 0 | **PASS** |
| icarus | arith:rand_fmadd | P_VALID=100 P_READY=100 P_EN=100 | 600 | 4000 | 4000 | 4000 | 0 | 0 | 0 | 4007 | 0 | **PASS** |
| icarus | arith:rand_fmul | P_VALID=100 P_READY=100 P_EN=100 | 602 | 4000 | 4000 | 4000 | 0 | 0 | 0 | 4006 | 0 | **PASS** |
| icarus | arith:spec_fnmadd | P_VALID=100 P_READY=100 P_EN=100 | 603 | 4000 | 4000 | 4000 | 0 | 0 | 0 | 4007 | 0 | **PASS** |
| icarus | disabled | P_VALID=85 P_READY=75 P_EN=55 | 608 | 4000 | 2208 | 2208 | 1792 | 112 | 0 | 4756 | 0 | **PASS** |
| icarus | illegal | P_VALID=90 P_READY=70 P_EN=90 | 610 | 2432 | 2203 | 2203 | 229 | 2203 | 0 | 3217 | 0 | **PASS** |
| icarus | mixed_b2b | P_VALID=100 P_READY=100 P_EN=100 | 605 | 4000 | 4000 | 4000 | 0 | 216 | 0 | 4007 | 0 | **PASS** |
| icarus | order_b2b | P_VALID=100 P_READY=100 P_EN=100 | 606 | 4000 | 4000 | 4000 | 0 | 141 | 0 | 4007 | 0 | **PASS** |
| icarus | reset | P_VALID=80 P_READY=60 P_EN=80 P_RESET=30 | 609 | 4000 | 3235 | 3134 | 765 | 179 | 17 | 5490 | 0 | **PASS** |
| icarus | stall | P_VALID=70 P_READY=40 P_EN=100 | 607 | 4000 | 4000 | 4000 | 0 | 216 | 0 | 10065 | 0 | **PASS** |
| verilator | arith:misc | P_VALID=100 P_READY=100 P_EN=100 | 504 | 489248 | 489248 | 489248 | 0 | 0 | 0 | 489253 | 0 | **PASS** |
| verilator | arith:rand_fadd | P_VALID=100 P_READY=100 P_EN=100 | 501 | 300000 | 300000 | 300000 | 0 | 0 | 0 | 300006 | 0 | **PASS** |
| verilator | arith:rand_fmadd | P_VALID=100 P_READY=100 P_EN=100 | 500 | 300000 | 300000 | 300000 | 0 | 0 | 0 | 300007 | 0 | **PASS** |
| verilator | arith:rand_fmul | P_VALID=100 P_READY=100 P_EN=100 | 502 | 300000 | 300000 | 300000 | 0 | 0 | 0 | 300006 | 0 | **PASS** |
| verilator | arith:spec_fnmadd | P_VALID=100 P_READY=100 P_EN=100 | 503 | 29160 | 29160 | 29160 | 0 | 0 | 0 | 29167 | 0 | **PASS** |
| verilator | disabled | P_VALID=85 P_READY=75 P_EN=55 | 508 | 300000 | 165258 | 165258 | 134742 | 8400 | 0 | 352971 | 0 | **PASS** |
| verilator | illegal | P_VALID=90 P_READY=70 P_EN=90 | 510 | 2432 | 2211 | 2211 | 221 | 2211 | 0 | 3164 | 0 | **PASS** |
| verilator | mixed_b2b | P_VALID=100 P_READY=100 P_EN=100 | 505 | 300000 | 300000 | 300000 | 0 | 15103 | 0 | 300007 | 0 | **PASS** |
| verilator | order_b2b | P_VALID=100 P_READY=100 P_EN=100 | 506 | 100005 | 100005 | 100005 | 0 | 3909 | 0 | 100012 | 0 | **PASS** |
| verilator | reset | P_VALID=80 P_READY=60 P_EN=80 P_RESET=30 | 509 | 300000 | 239860 | 233072 | 60140 | 12069 | 1297 | 413729 | 0 | **PASS** |
| verilator | stall | P_VALID=70 P_READY=40 P_EN=100 | 507 | 300000 | 300000 | 300000 | 0 | 15103 | 0 | 749224 | 0 | **PASS** |
