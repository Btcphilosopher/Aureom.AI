# Mutation testing (verification of the verification)

Each mutant injects one bug into a copy of the RTL, compiled with `SYNTHESIS` defined (RTL-internal assertions removed), and runs the black-box testbench on 30000-vector subsets: `fadd`, `fmul`, `fma`, `spec_fma`, `misc`, `stall_dis`, `reset`.
`BASE` is the unmodified RTL and must pass every run.  `MX1` is run on Icarus (4-state) only and must be caught by the X/Z check specifically.

| id | file | injected bug | result | failing runs |
|---|---|---|---|---|
| BASE | hpc_vector_lane.sv | unmodified RTL (control) | **PASS (control)** | - |
| M01 | hpc_vector_pkg.sv | RNE ties rounded away from zero | **KILLED** | fadd, fmul, fma, spec_fma, stall_dis, reset |
| M02 | hpc_vector_pkg.sv | RMM ties rounded to even | **KILLED** | spec_fma, stall_dis, reset |
| M03 | hpc_vector_pkg.sv | RDN rounds the wrong sign | **KILLED** | spec_fma, stall_dis, reset |
| M04 | hpc_fp32_round.sv | tininess detected before rounding | **KILLED** | fma, spec_fma, stall_dis, reset |
| M05 | hpc_fp32_round.sv | RTZ overflow returns inf instead of max finite | **KILLED** | spec_fma, stall_dis, reset |
| M06 | hpc_fp32_fma.sv | FMA drops collapsed-addend sticky bit | **KILLED** | fma, spec_fma, stall_dis, reset |
| M07 | hpc_fp32_fma.sv | FMA addend misaligned by one bit | **KILLED** | fma, spec_fma, stall_dis, reset |
| M08 | hpc_fp32_fma.sv | FMA inf*0+qNaN does not raise NV | **KILLED** | spec_fma, stall_dis, reset |
| M09 | hpc_fp32_add.sv | adder collapses operand to sticky too early | **KILLED** | fadd, stall_dis, reset |
| M10 | hpc_vector_pkg.sv | subnormal operands get a hidden one | **KILLED** | fadd, fmul, fma, spec_fma, stall_dis, reset |
| M11 | hpc_fp32_add.sv | exact-zero sum always +0 | **KILLED** | stall_dis, reset |
| M12 | hpc_fp32_misc.sv | min/max sign ordering inverted | **KILLED** | stall_dis, reset |
| M13 | hpc_fp32_misc.sv | FEQ signals NV on quiet NaN | **KILLED** | stall_dis, reset |
| M14 | hpc_vector_lane.sv | disabled lane still executes and returns a result | **KILLED** | stall_dis, reset |
| M15 | hpc_vector_lane.sv | accepts when completion buffer is full | **KILLED** | stall_dis, reset |
| M16 | hpc_vector_lane.sv | retires before the oldest operation completed | **KILLED** | stall_dis, reset |
| M17 | hpc_vector_lane.sv | tag stored in the wrong slot | **KILLED** | fadd, fmul, fma, spec_fma, misc, stall_dis, reset |
| M18 | hpc_vector_lane.sv | result written to the wrong completion slot | **KILLED** | fadd, fmul, fma, spec_fma, misc, stall_dis, reset |
| M19 | hpc_vector_lane.sv | completion flags not cleared by reset | **KILLED** | reset |
| M20 | hpc_vector_lane.sv | reserved rounding modes accepted | **KILLED** | stall_dis, reset |
| M21 | hpc_vector_lane.sv | stall event counts the post-reset cycle | **KILLED** | fadd, fmul, fma, spec_fma, misc, stall_dis, reset |
| M22 | hpc_vector_lane.sv | backpressure event without a valid result | **KILLED** | fadd, fmul, fma, spec_fma, misc, stall_dis, reset |
| M23 | hpc_vector_lane.sv | illegal operations return stale data | **KILLED** | stall_dis, reset |
| M24 | hpc_fp32_mul.sv | multiplier exponent bias off by one | **KILLED** | fmul, stall_dis, reset |
| M25 | hpc_fp32_fma.sv | FNMADD/FNMSUB product negation lost (operand routing) | **KILLED** | fma, stall_dis, reset |
| M26 | hpc_fp32_misc.sv | INT32 add implemented as OR | **KILLED** | stall_dis, reset |
| M27 | hpc_vector_lane.sv | ready asserted during / right after reset | **KILLED** | fadd, fmul, fma, spec_fma, misc, stall_dis, reset |
| MX1 | hpc_vector_lane.sv | uninitialised completion storage driven onto out_result_o (4-state X check, Icarus) | **KILLED** | x_check |

28/28 mutants killed (incl. Icarus X-check mutant MX1); control passes.
