# SilicaFlux-HPC · Module 02 — Configurable HPC Vector Execution Lane

**Primary source:** `rtl/hpc_vector_lane.sv` · Aureom.AI | SilicaFlux-HPC

This is one reusable, synthesizable vector execution lane. It takes one operation per cycle
through a valid/ready interface and executes it on one of five fully pipelined units:

* FP32 add/sub
* FP32 multiply
* FP32 fused multiply-add (four forms)
* move / min / max / compare / INT32 add
* INT32 multiply

The units have **different latencies**. Results come back **exactly once, in acceptance order**,
with their transaction tag and IEEE-754 exception flags, through a second valid/ready interface.

## Audit outcome and blocker

The repository has **no FP32 FMA (`fp32_fma.sv` does not exist), no FP adder and no FP
multiplier**. 1,404 HDL files and 629 modules inside the repository archives were scanned; the
FP-class opcodes of `vector_engine.sf` are steered to an FP datapath that does not exist. See
`docs/AUDIT.md`.

As the brief allows, the lane control is independent of any particular arithmetic core and is
verified across six latency configurations. **In addition**, the missing FP32 datapaths were
designed here as separate units: ADD and MUL are *not* FMA shortcuts. They are verified bit for bit,
flags included, against an exact IEEE reference model that was itself confirmed against the host
CPU's IEEE-754 hardware on 2.09 M vectors.

## Status against the completion criteria (brief §9)

| Criterion | Result | Evidence |
|---|---|---|
| No dropped operations | ✅ | Scoreboard on 13.6 M enabled operations; accepted − retired = flushed by reset, exactly |
| No duplicate results | ✅ | Scoreboard; mutants M14 / M16 killed |
| No transaction misassociation | ✅ | Tag + result + flags compared per result; mutants M17 / M18 killed |
| Correct arithmetic | ✅ | 2.73 M per-opcode vectors (2.24 M on the 7 rounding ops, all 5 rounding modes) bit-exact; reference ≡ x86 hardware on 2.09 M |
| Correct exception flags | ✅ | Flags compared on every result; NV/OF/UF/NX/tie/tiny hit in every feasible bin |
| Deterministic reset | ✅ | 12,544 asynchronous mid-stream resets; 4-state RTL and netlist simulation, no X |
| Successful synthesis | ✅ | Yosys 0.33, 4 configurations: no latches, `check -assert` clean, netlist passes the same TB |
| Clock frequency | **not claimed** | Needs a standard-cell library, constraints and STA (`docs/SYNTHESIS.md`) |

Headline numbers:

| Item | Result |
|---|---|
| Regression | **132 / 132 PASS** (Verilator + Icarus, 6 parameter configurations) |
| Mutation testing | **28 / 28 killed** |
| Gate-level simulation | **22 / 22 PASS** |
| Lint | clean: Verilator `-Wall`, Icarus, Yosys |

## Interface at a glance

```
hpc_vector_lane #(DATA_W=32, TAG_W=8, ROB_DEPTH=8,
                  LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2,
                  EN_FCMP=1, EN_INT=1)
  clk_i, rst_ni
  in_valid_i  / in_ready_o   in_op_i[4:0] in_a_i in_b_i in_c_i in_rm_i[2:0] in_tag_i lane_en_i
  out_valid_o / out_ready_i  out_result_o out_flags_o[4:0]{NV,DZ,OF,UF,NX} out_tag_o out_illegal_o
  busy_o
  ev_accept_o ev_retire_o ev_pipe_stall_o ev_backpressure_o ev_illegal_o ev_masked_o
```

**Operations.** FMV, FADD, FSUB, FMUL, FMADD, FMSUB, FNMSUB, FNMADD, FMIN, FMAX, FEQ, FLT, FLE,
IADD and IMUL. Every other code point is illegal.

**Policies**

* **Completion.** In-order completion through a reorder buffer.
* **Flow control.** Credit-based, so the execution pipelines never stall.
* **Interface timing.** `in_ready_o` and every `out_*` output depend on registered state only.
* **Masking.** A disabled lane consumes the operation and produces nothing.
* **Illegal operations.** They complete in order with `out_illegal_o` set.
* **Reset.** Every in-flight operation is discarded.

Full specification: `docs/LANE_INTERFACE.md`.

**Latency and throughput (measured).** Latency is LAT + 1 cycles: FMV/compare 2, IMUL 3,
FADD/FMUL 4, FMA 5. Sustained throughput is min(1, ROB_DEPTH/(LAT+2)), i.e. 1 op/cycle for any mix
at the default depth. See `docs/LATENCY_THROUGHPUT.md`.

## Contents

```
rtl/   hpc_vector_pkg.sv   opcode / rm / flag encodings, helpers (shared package)
       hpc_vector_lane.sv  the lane: accept, decode, route, ROB, in-order retire, events
       hpc_fp32_add.sv     FP32 add/sub                (segments A | B1 | B2)
       hpc_fp32_mul.sv     FP32 multiply               (A | B1 | B2)
       hpc_fp32_fma.sv     FP32 fused multiply-add x4  (A | B | C1 | C2)
       hpc_fp32_misc.sv    FMV, FMIN/FMAX, FEQ/FLT/FLE, IADD
       hpc_int32_mul.sv    INT32 multiply (low half)
       hpc_fp32_round.sv   shared round / denormalise / pack / OF-UF-NX
       hpc_lzc.sv          log-depth leading-zero counter
       hpc_pipe.sv         non-stallable valid/data delay line
tb/    tb_hpc_vector_lane.sv  self-checking lane TB (scoreboard, protocol, events, X, reset)
       tb_hpc_lzc.sv          LZC unit test (exhaustive at W=24)
ref/   fp32_ref.py         exact IEEE-754 reference model (all ops, all 5 rounding modes)
       fp32_hwref.c        x86 SSE/FMA3 hardware oracle (fesetround / fetestexcept)
       crosscheck.py       model-vs-hardware cross-check
       gen_vectors.py      corner-biased vector generator   mix_vectors.py  mixed/ordering streams
       coverage.py         functional coverage of the vector set
scripts/ run_all.sh  regress.py  mutate.py  gatesim.py  characterize.py  lint.sh
syn/   run_synth.sh        Yosys synthesis smoke test (+ netlist for gate-level simulation)
docs/  AUDIT.md  LANE_INTERFACE.md  MICROARCHITECTURE.md  FP_SEMANTICS.md
       VERIFICATION.md  LATENCY_THROUGHPUT.md  SYNTHESIS.md
reports/ regression.md  mutation.md  gatesim.md  coverage.md  characterisation.md
         crosscheck_hw.txt  lint.txt  lzc_unit_test.txt  synth/  (+ per-run logs)
```

## Reproduce

Requires Verilator 5.020, Icarus Verilog 12, Yosys 0.33 (the SilicaFlux tool baseline),
Python ≥ 3.10, a C compiler, and an x86-64 host with FMA3 for the hardware oracle.

```bash
bash scripts/run_all.sh
```

That takes about 20 minutes on 4 cores and regenerates every file in `reports/`. Individual steps
are available as Makefile targets:

```bash
make vectors && make crosscheck && make regress-verilator
```

## Known limitations and next steps

* **Timing.** Only structural depth is reported (51 generic cells on the default lane's longest
  path). A frequency number needs a library and STA. The ASIC-flow next steps are in
  `docs/SYNTHESIS.md`.
* **No `hpc_perf_counters.sv`.** The event pulses are specified for it (`docs/LANE_INTERFACE.md`
  §7) but the counter block is not built here.
* **TestFloat not run.** Berkeley TestFloat was not run in this environment. The vector format makes
  adding `testfloat_gen` vectors straightforward.
* **IMUL multiplier.** IMUL uses an inferred multiplier. The SilicaFlux TimingLab carry-save
  multiplier is the documented drop-in for a timing-driven build.
