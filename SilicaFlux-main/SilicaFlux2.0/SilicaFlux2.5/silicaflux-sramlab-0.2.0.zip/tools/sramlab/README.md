# SilicaFlux SRAMLab 0.2.0

Aureom.AI | SilicaFlux Semiconductor Systems — SRAM architecture benchmarking and digital-twin environment.

An engineer can select an SRAM architecture (banks, word width, latency, masters, outstanding transactions, arbitration, interleave, ECC, MBIST, backend, technology profile),
run a real supported workload, compare configurations, and obtain **reproducible results with every number labelled by where it came from**:
`analytical` · `simulated` · `rtl_simulated` · `synthesized` · `assumed` · `unavailable` — and never `measured`, because no SilicaFlux silicon/FPGA measurement exists.

> Start with `reports/engineering_report.md` (generated from `data/`), then `docs/00_audit.md` and `docs/03_verification.md`.

## What 0.2.0 is

0.2.0 builds on the SRAMLab already in the repository (Project 80, `silicaflux-sramlab-p80.zip`), as the brief asks (*reuse functioning analysis
infrastructure*) — but only after **running** it. On the toolchain Ubuntu 24.04 installs (Verilator 5.020, Yosys 0.33, Icarus 12.0) Project 80
failed 16 of its own tests, including its headline model-vs-RTL comparison. The causes were three Verilator 5.020 simulation defects triggered by
its testbenches, not the RTL or the model (`docs/03_verification.md`, *Harness portability*). 0.2.0:

* replaces the Verilator controller testbench with a **C++-driven harness** (no `--timing` dependency) and adds an independently written **Icarus
  testbench**, so the controller is verified three ways: **Python model = Verilator = Icarus**;
* fixes the ECC and MBIST testbenches and **cross-checks them on Icarus** (`sramlab xsim`), with a negative control proving the cross-check detects
  a simulator defect;
* recomputes the statistics **in R** from raw simulation output (`sramlab rstats`) and adds R-only analyses (Kruskal–Wallis, bank-count elasticity);
  this found and fixed an inaccurate t-quantile approximation;
* adds the **TensorCore (TC08) command stream** to the RTL verification matrix;
* regenerates **every dataset** in `data/` on this toolchain and records the simulation version (SRAMLab version, harness schemes, RTL hash and a
  source-tree hash — the delivery is not committed to git) in every experiment record.

## Verification status (Verilator 5.020, Icarus 12.0, Yosys 0.33, R 4.3.3)

| check | result | regenerate |
|---|---|---|
| cycle model vs RTL (`sf_sram_subsystem`), trace + all hardware counters | **275/275 cases identical** (198,824 cycles, 340,788 transactions, 34,568 counter values; 23 parameter sets) | `sramlab rtlcheck --icarus --dataset` |
| second simulator, controller | **112/112** cases model = Verilator = Icarus | (same) |
| second simulator, ECC + MBIST testbenches | **9/9** cases identical, 87,411 result lines; negative control detects the 5.020 defect | `sramlab xsim --full --dataset` |
| negative controls (broken models, Icarus path, cross-simulator, R comparator) | all detected | `pytest` |
| statistics recomputed in R | **305/305** quantities agree (CI half-widths to 1.2e-12) | `sramlab rstats --dataset` |
| ECC codec RTL vs independent reference | 0 mismatches over 14,980 / 67,362 / 34,612 vectors (DW 32 / 64 / 128) | `sramlab ecc` |
| MBIST cycle model / RTL coverage vs fault simulation / vs P78 committed | exact (0 cycles) / 0 mismatches / 0 differences | `sramlab mbist` |
| MemoryCore ECC synthesis (Yosys 0.33, `abc -fast`) | 315 / 1392 cells vs committed 314 / 1389; MemoryCore's own script reproduces 314 / 1389 exactly | `sramlab ecc` |

## Quick start

```bash
pip install numpy pandas pyyaml pytest          # Python side
sudo apt-get install verilator yosys iverilog r-base-core   # optional: RTL simulation, synthesis, 2nd simulator, R cross-check
cd tools/sramlab
./bin/sramlab tools                                    # which tools are available (versions are recorded in every record)
./bin/sramlab validate configs/*.yaml
./bin/sramlab simulate configs/four_bank_baseline.yaml --rtl-check --export   # model run + cycle-by-cycle comparison with the real RTL
./bin/sramlab benchmark configs/four_bank_baseline.yaml --replications 10     # mean ± 95% CI
./bin/sramlab sweep --banks 2,4,8,16                                          # bank-count sweep at constant capacity
./bin/sramlab compare configs/four_bank_baseline.yaml configs/eight_bank_mixed.yaml
python3 -m pytest tests -q
```

(pip alternatives: `pip install verilator yowasp-yosys`; the pip Verilator wheel's empty `CFG_CXXFLAGS_PCH_I` is detected and patched automatically.)

## Commands

| command | what it does |
|---|---|
| `validate`, `schema`, `tools` | validate configs (all problems at once); write the JSON schema; show tool availability |
| `simulate` | one run; `--rtl-check` compares with the RTL; `--export` writes per-transaction and counter CSVs |
| `benchmark` | replicated run with 95 % CIs and a sample-adequacy statement |
| `sweep` | bank-count sweep at constant capacity |
| `compare` | two configurations, statistically |
| `vector`, `tensor` | the vector and tensor studies |
| `ecc`, `mbist` | ECC cost and MBIST evaluation (RTL) |
| `synth`, `floorplan`, `power` | Yosys flows, area/floorplan, power provenance + thermal hand-off |
| `optimise` | goals A–E, Pareto set |
| `rtlcheck` | model-vs-RTL verification matrix + negative control; `--icarus` adds the three-way check (model = Verilator = Icarus) |
| `xsim` | second-simulator check of the ECC/MBIST testbenches (Verilator vs Icarus, identical inputs) + negative control |
| `rstats` | statistics recomputed in R from raw simulation output and compared; R-only sensitivity analyses |
| `report`, `dashboard`, `export` | engineering report + CSVs, browser dashboard, raw data export |
| `history`, `verify-repro` | experiment history; re-run and demand identical result hashes |

Every command listed here is implemented and exercised by `tests/test_cli.py` (which also fails if a command is missing from this table).

## Documentation

| doc | content |
|---|---|
| `reports/engineering_report.md` | generated engineering report (every table/finding computed from `data/`) |
| `docs/00_audit.md` | repository audit: the 0.2.0 audit of Project 80, then the audit of the SilicaFlux packages |
| `docs/01_architecture.md`, `02_methodology.md` | layers, metrics definitions, ceilings vs simulation, statistics |
| `docs/03_verification.md` | model-vs-RTL verification, second simulator, R cross-check, negative controls, *Harness portability* (Verilator 5.020 defects) |
| `docs/04_tensor_vector_studies.md` | tensor/vector method, optimisation rules |
| `docs/ecc.md`, `mbist.md` | ECC cost analysis and MBIST evaluation (RTL runs, sibling-report disagreements) |
| `docs/synthesis.md`, `physical.md`, `power.md`, `thermal.md` | Yosys flows, technology/macro data, power provenance, ThermalLab hand-off |
| `docs/dashboard.md` | the 15-view dashboard and its provenance rules |
| `docs/05_limitations.md` | what is not claimed |
| `docs/06_brief_traceability.md` | each brief section → implementation → evidence |
| `CHANGES.md` | 0.2.0 versus Project 80 |

## Reproduce everything

```bash
python3 -m pytest tests -q                     # full suite: 329 tests; cold caches ~8 min on 4 cores (builds cached under .build/ and .cache/).
                                               # On a fresh unpack the 10 Nangate45-mapped tests skip until the liberty is fetched:
./bin/sramlab synth --banks 2 --perf 0 --liberty nangate45 --fetch   # pinned SHA-256 download; not bundled
python3 scripts/generate_data.py --only bank_sweep,timeline,vector,tensor
./bin/sramlab rtlcheck --icarus --dataset      # full model-vs-RTL matrix + three-way subset (~3 min)
./bin/sramlab xsim --full --dataset            # ECC/MBIST testbenches on Verilator and Icarus
./bin/sramlab rstats --dataset                 # statistics recomputed in R
./bin/sramlab ecc && ./bin/sramlab mbist       # RTL studies (~5 min each cold)
./bin/sramlab synth --banks 2,4,8,16 --perf 0,1                    # generic gates
./bin/sramlab synth --banks 2,4,8,16 --perf 0,1 --liberty nangate45 --fetch   # + mapped logic area (downloads the pinned open Nangate45 liberty; not bundled)
./bin/sramlab floorplan configs/four_bank_sky130_macro.yaml --thermal --dataset
./bin/sramlab power configs/four_bank_sky130_macro.yaml --dataset
./bin/sramlab optimise --dataset
./bin/sramlab report --dashboard               # reports/engineering_report.md, CSV exports, dashboard/sramlab_dashboard.html
```

## Layout

`sramlab/` package · `rtl/` (testbenches: `tb/vl_ctl` C++-driven Verilator harness, `tb/ivl_ctl` Icarus testbench, study testbenches; vendored RTL with SHA-256 manifests) ·
`configs/` · `schemas/` · `data/` (committed datasets, imported reference data with provenance, macro manifests, `runs/` experiment records, `archive/`) ·
`reports/` (engineering report, CSV exports) · `dashboard/` · `docs/` · `tests/` · `scripts/` (data generation, packaging, `r/` R analysis) · `bin/sramlab`.

## Honest scope

See `docs/05_limitations.md`. In short: results are cycles of the implemented protocol, not seconds; there is no energy-per-access or die-area data for the SilicaFlux target process anywhere in the repository,
so those are reported `unavailable` unless a validated profile / real library is supplied; OpenROAD/OpenSTA are not available here, so no timing-closure or P&R result is claimed; MBIST coverage is coverage of an injected simulation fault model only;
agreement of two simulators is evidence against simulator defects, not a proof of RTL correctness.
