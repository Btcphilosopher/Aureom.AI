"""Statistical analysis: replication, confidence intervals, sample-size planning, sensitivity.

Design rules
* Latency samples inside ONE run are autocorrelated (queues), so confidence intervals are computed
  across independent replications (different seeds), never across the transactions of one run.
* Student-t intervals on replicate means; percentiles get a bootstrap interval across replications
  (seeded, so the report is reproducible).
* ``required_replications`` tells how many replications a target half-width needs; reports state the
  achieved half-width so a reader can see whether the sample was adequate.
No scipy dependency: the t quantile uses an exact table (R qt) up to 30 d.o.f. and a Cornish-Fisher expansion beyond.
"""
from __future__ import annotations

import math

import numpy as np

from .prng import SplitMix64

# two-sided 95% / 99% Student-t critical values, df = 1..30: R 4.3.3 qt(0.975, df) / qt(0.995, df), 12 significant
# digits (the Project 80 table had 3 decimals; ``sramlab rstats`` now cross-checks every CI against exact qt()).
_T95 = [12.7062047362, 4.30265272975, 3.18244630528, 2.7764451052, 2.57058183564, 2.44691185114, 2.36462425159,
        2.3060041352, 2.2621571628, 2.22813885199, 2.20098516009, 2.17881282967, 2.16036865646, 2.14478668792,
        2.13144954556, 2.11990529922, 2.10981557783, 2.10092204024, 2.09302405441, 2.08596344727, 2.07961384473,
        2.0738730679, 2.06865761042, 2.06389856163, 2.05953855275, 2.05552943864, 2.05183051648, 2.0484071418,
        2.04522964213, 2.0422724563]
_T99 = [63.6567411629, 9.92484320092, 5.84090930973, 4.60409487135, 4.03214298356, 3.70742802132, 3.49948329735,
        3.35538733133, 3.24983554159, 3.16927267262, 3.10580651554, 3.05453958939, 3.01227583872, 2.97684273437,
        2.94671288348, 2.92078162243, 2.89823051968, 2.87844047274, 2.86093460646, 2.84533970979, 2.83135955802,
        2.8187560606, 2.80733568377, 2.79693950477, 2.78743581368, 2.77871453333, 2.77068295712, 2.76326245546,
        2.75638590367, 2.74999565357]
_Z = {0.95: 1.959963984540054, 0.99: 2.5758293035489}


def t_crit(df: int, conf: float = 0.95) -> float:
    """Two-sided Student-t critical value.  df <= 30: exact table; df > 30: 4-term Cornish-Fisher expansion of the
    t quantile about the normal quantile (relative error < 1e-6 for df > 30 at 95 % and 99 %, checked against R qt())."""
    if df < 1:
        return float("nan")
    tab = {0.95: _T95, 0.99: _T99}[conf]
    if df <= 30:
        return tab[df - 1]
    z, v = _Z[conf], float(df)
    g1 = (z ** 3 + z) / 4
    g2 = (5 * z ** 5 + 16 * z ** 3 + 3 * z) / 96
    g3 = (3 * z ** 7 + 19 * z ** 5 + 17 * z ** 3 - 15 * z) / 384
    g4 = (79 * z ** 9 + 776 * z ** 7 + 1482 * z ** 5 - 1920 * z ** 3 - 945 * z) / 92160
    return z + g1 / v + g2 / v ** 2 + g3 / v ** 3 + g4 / v ** 4


def mean_ci(x, conf: float = 0.95) -> dict:
    a = np.asarray(x, dtype=float)
    n = len(a)
    if n == 0:
        return {"n": 0}
    m = float(a.mean())
    if n == 1:
        return {"n": 1, "mean": m, "half_width": float("nan"), "lo": float("nan"), "hi": float("nan"), "conf": conf}
    s = float(a.std(ddof=1))
    hw = t_crit(n - 1, conf) * s / math.sqrt(n)
    return {"n": n, "mean": m, "std": s, "half_width": hw, "lo": m - hw, "hi": m + hw, "conf": conf,
            "relative_half_width": hw / abs(m) if m else float("nan")}


def required_replications(std: float, target_half_width: float, conf: float = 0.95) -> int:
    """Smallest n with t(n-1) * std / sqrt(n) <= target (iterates because t depends on n)."""
    if target_half_width <= 0 or std == 0:
        return 2
    n = 2
    while n < 100000:
        if t_crit(n - 1, conf) * std / math.sqrt(n) <= target_half_width:
            return n
        n += 1
    return n


def bootstrap_ci(x, stat, conf: float = 0.95, iters: int = 1000, seed: int = 1) -> dict:
    a = np.asarray(x, dtype=float)
    n = len(a)
    if n < 2:
        return {"n": n}
    rng = SplitMix64(seed)
    vals = []
    for _ in range(iters):
        idx = [rng.randbelow(n) for _ in range(n)]
        vals.append(stat(a[idx]))
    lo, hi = np.percentile(vals, [(1 - conf) / 2 * 100, (1 + conf) / 2 * 100])
    return {"n": n, "estimate": float(stat(a)), "lo": float(lo), "hi": float(hi), "conf": conf, "method": "bootstrap"}


def replicate(run_fn, seeds, extract: dict[str, callable]) -> dict:
    """Run ``run_fn(seed)`` for every seed and summarise each extractor over the replications."""
    rows = [run_fn(s) for s in seeds]
    out = {"n_replications": len(rows), "seeds": list(seeds), "metrics": {}}
    for name, fn in extract.items():
        vals = [fn(r) for r in rows]
        out["metrics"][name] = {**mean_ci(vals), "values": vals}
    return out


def pooled_percentile_ci(samples_per_rep: list, q: float, conf: float = 0.95) -> dict:
    """Percentile q of each replication's latency sample, then a t interval across replications."""
    per_rep = [float(np.percentile(s, q)) for s in samples_per_rep if len(s)]
    d = mean_ci(per_rep, conf)
    d["percentile"] = q
    return d


# --------------------------------------------------------------------------- sensitivity
def spearman(x, y) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) < 3 or np.std(x) == 0 or np.std(y) == 0:
        return float("nan")
    rx = _rank(x)
    ry = _rank(y)
    return float(np.corrcoef(rx, ry)[0, 1])


def _rank(a: np.ndarray) -> np.ndarray:
    order = a.argsort(kind="mergesort")
    ranks = np.empty(len(a))
    ranks[order] = np.arange(len(a))
    # average ranks for ties
    for v in np.unique(a):
        idx = np.nonzero(a == v)[0]
        if len(idx) > 1:
            ranks[idx] = ranks[idx].mean()
    return ranks


def elasticity(x0: float, y0: float, x1: float, y1: float) -> float:
    """Arc elasticity d ln(y) / d ln(x) between two points (dimensionless sensitivity)."""
    if x0 <= 0 or x1 <= 0 or y0 <= 0 or y1 <= 0 or x0 == x1:
        return float("nan")
    return (math.log(y1) - math.log(y0)) / (math.log(x1) - math.log(x0))


def coefficient_of_variation(x) -> float:
    a = np.asarray(x, float)
    return float(a.std(ddof=1) / a.mean()) if len(a) > 1 and a.mean() else float("nan")
