"""Engineering report + CSV exports + dashboard dataset, all computed from ``data/*.json``.

Findings in the report are *derived from the data at build time* (e.g. "throughput gain from 4 to 8 banks is x %"),
never typed in.  Sections whose dataset is missing say so instead of being omitted silently.
"""
from __future__ import annotations

import csv
import datetime
import json
import os

from . import record

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")

DATASETS = ["rtl_verification", "bank_sweep", "vector_study", "tensor_study", "optimise", "ecc_study", "mbist_study",
            "synth_sweep", "phys", "power", "thermal", "xsim_verification", "r_crosscheck"]


def load_data(data_dir: str = DATA) -> dict:
    out = {}
    for n in DATASETS:
        p = os.path.join(data_dir, n + ".json")
        out[n] = json.load(open(p)) if os.path.exists(p) else None
    out["synth_sweep"] = load_synth(os.path.join(data_dir, "synth"))
    out["_history"] = record.load_history(os.path.join(data_dir, "runs"))
    return out


def load_synth(d: str):
    """Assemble the Yosys sweeps written by ``sramlab synth`` (data/synth/*.json) into one dataset."""
    if not os.path.isdir(d):
        return None
    res = {"sweeps": {}, "singles": {}}
    for fn in sorted(os.listdir(d)):
        if not fn.endswith(".json"):
            continue
        try:
            j = json.load(open(os.path.join(d, fn)))
        except Exception:
            continue
        if isinstance(j, dict) and isinstance(j.get("rows"), list):
            res["sweeps"][fn[:-5]] = {k: v for k, v in j.items() if k not in ("results",)}
        else:
            res["singles"][fn[:-5]] = j
    return res if (res["sweeps"] or res["singles"]) else None


def _ci(d, nd=3):
    if not isinstance(d, dict) or not d.get("n"):
        return "n/a"
    hw = d.get("half_width")
    s = f"{d['mean']:.{nd}f}"
    return s + (f" ±{hw:.{nd}f}" if hw is not None and hw == hw else "")


def _tbl(header, rows):
    out = ["| " + " | ".join(header) + " |", "|" + "|".join("---" for _ in header) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


# ------------------------------------------------------------------------------ findings (computed)
def bank_findings(bs: dict) -> list[str]:
    out = []
    for key, sw in bs.items():
        mo = key.split("_")[-1]
        rows = sw["rows"]
        by = {}
        for r in rows:
            by.setdefault(r["workload"], {})[r["banks"]] = r["throughput_txn_per_cycle"]["mean"]
        for wl, d in by.items():
            if 4 in d and 16 in d and 8 in d:
                g48 = (d[8] / d[4] - 1) * 100
                g816 = (d[16] / d[8] - 1) * 100
                if abs(g48) < 1 and abs(g816) < 1:
                    out.append(f"MAX_OUT={mo}, {wl}: throughput is flat from 4 to 16 banks ({d[4]:.2f} → {d[16]:.2f} txn/cycle): more banks add nothing for this workload.")
                else:
                    out.append(f"MAX_OUT={mo}, {wl}: 4→8 banks {g48:+.1f} %, 8→16 banks {g816:+.1f} % throughput ({d[4]:.2f} → {d[8]:.2f} → {d[16]:.2f} txn/cycle).")
    return out


def vector_findings(vs: dict) -> list[str]:
    rows = [r for r in vs["study"]["rows"] if r["vector_bits"] == 128 and r["banks"] == 8]
    out = []
    by = {(r["word_bits"], r["case"]): r for r in rows}
    for ww in sorted({r["word_bits"] for r in rows}):
        a, b = by.get((ww, "aligned_load")), by.get((ww, "byte_misaligned_load"))
        if a and b:
            ua, ub = a["useful_bytes_per_cycle"]["mean"], b["useful_bytes_per_cycle"]["mean"]
            pure = 1 - 1 / b["alignment_overhead"]
            out.append(f"{ww}-bit words, 128-bit vectors, 1-byte misalignment: **alignment cost** = {b['alignment_overhead']:.2f}x fetched bytes per useful byte "
                       f"(a single master loses {pure * 100:.0f} % useful bandwidth). In this 4-master run useful bandwidth falls from {ua:.2f} to {ub:.2f} B/cycle "
                       f"({(ub / ua - 1) * 100:+.0f} %); the loss beyond the pure alignment cost comes from bank conflicts "
                       f"({b['conflict_rate_per_access']['mean']:.2f}/access vs {a['conflict_rate_per_access']['mean']:.2f} aligned) because the masters stream in the same bank phase and "
                       "re-fetch the shared boundary word - that component depends on the masters' relative phase, not on alignment alone.")
        al, st = by.get((ww, "aligned_load")), by.get((ww, "strided_load_bank_stride"))
        if al and st:
            dc = st["conflict_rate_per_access"]["mean"] - al["conflict_rate_per_access"]["mean"]
            if dc > 0.05:
                out.append(f"{ww}-bit words: the 256-byte stride maps every vector start onto the same bank and adds {dc:.2f} conflicts/access; useful bandwidth falls from "
                           f"{al['useful_bytes_per_cycle']['mean']:.2f} to {st['useful_bytes_per_cycle']['mean']:.2f} B/cycle.")
            else:
                out.append(f"{ww}-bit words: the 256-byte stride adds no conflicts here (each vector spans several consecutive banks, so starting on one bank does not serialise the stream).")
    ps = [r for r in rows if r["case"] == "partial_store"]
    if ps:
        out.append("Partial stores: an entirely masked word is not accessed, so the cost is not in extra accesses; the RMW penalty of partial writes appears only with ECC (see §5).")
    return out


def tensor_findings(ts: dict) -> list[str]:
    rows = [r for r in ts["rows"] if r["word_bits"] == 32 and r["dma_duty"] == 0.0 and r["pitch"] == "padded"]
    out = []
    ideal = ts["util_ideal_reference"]
    dma_rows = [r for r in ts["rows"] if r["word_bits"] == 32 and r["dma_duty"] == 0.5 and r["pitch"] == "padded"]
    lim, tot = sum(r["memory_limited"] for r in rows), len(rows)
    dl, dt = sum(r["memory_limited"] for r in dma_rows), len(dma_rows)
    out.append(f"**Answer to \"does memory bandwidth limit compute throughput?\": it depends on the memory organisation.** {lim} of {tot} evaluated 32-bit configurations "
               f"(no DMA, padded pitches) are memory limited, and {dl} of {dt} once a DMA fill runs at 50 % duty; the array is not limited only with enough banks "
               f"AND enough outstanding transactions per port (see the smallest such configuration below).")
    mo1 = [r for r in rows if r["max_out"] == 1]
    if mo1:
        out.append(f"With MAX_OUT=1 MAC utilisation stays at {min(r['mac_utilisation'] for r in mo1):.2f}–{max(r['mac_utilisation'] for r in mo1):.2f} for every bank count "
                   f"({min(r['banks'] for r in mo1)}–{max(r['banks'] for r in mo1)}): the limit is the request/response credit loop, not SRAM bank bandwidth.")
    nat = {(r["banks"], r["max_out"]): r for r in ts["rows"] if r["word_bits"] == 32 and r["dma_duty"] == 0.0 and r["pitch"] == "natural"}
    pad = {(r["banks"], r["max_out"]): r for r in rows}
    gains = [(b, pad[(b, m)]["mac_utilisation"] - nat[(b, m)]["mac_utilisation"]) for (b, m) in pad if (b, m) in nat and m == 4]
    if gains:
        out.append("Padding the matrix pitches changes MAC utilisation at MAX_OUT=4 by " + ", ".join(f"{b} banks {g:+.2f}" for b, g in sorted(gains)) + " (pitch-induced bank aliasing).")
    free = [r for r in rows if not r["memory_limited"]]
    if free:
        r0 = min(free, key=lambda r: (r["banks"], r["max_out"]))
        out.append(f"Smallest configuration that is NOT memory limited (≥95 % of the ideal {ideal:.2f}): {r0['banks']} banks, MAX_OUT={r0['max_out']} (utilisation {r0['mac_utilisation']:.2f}).")
    dma = {(r["banks"], r["max_out"]): r for r in ts["rows"] if r["word_bits"] == 32 and r["dma_duty"] == 0.5 and r["pitch"] == "padded"}
    d = [(k, rows_k) for k, rows_k in dma.items() if k in pad and k[1] == 4]
    if d:
        out.append("Concurrent DMA fill at 50 % duty lowers utilisation at MAX_OUT=4 by " + ", ".join(
            f"{k[0]} banks {pad[k]['mac_utilisation'] - v['mac_utilisation']:.2f}" for k, v in sorted(d)) + ".")
    return out


# ------------------------------------------------------------------------------ CSV exports
def write_csvs(data: dict, outdir: str) -> list[str]:
    os.makedirs(outdir, exist_ok=True)
    files = []

    def w(name, header, rows):
        p = os.path.join(outdir, name)
        with open(p, "w", newline="") as f:
            cw = csv.writer(f)
            cw.writerow(header)
            cw.writerows(rows)
        files.append(p)

    if data.get("bank_sweep"):
        rows = []
        for key, sw in data["bank_sweep"].items():
            for r in sw["rows"]:
                rows.append([key, r["workload"], r["banks"], r["capacity_bytes"], r["replications"],
                             r["throughput_txn_per_cycle"]["mean"], r["throughput_txn_per_cycle"]["half_width"],
                             r["useful_bytes_per_cycle"]["mean"], r["read_latency_mean"]["mean"], r["read_latency_mean"]["half_width"],
                             r["read_latency_p99"]["mean"], r["conflict_rate_per_access"]["mean"], r["bank_utilisation_mean"]["mean"],
                             r["arbitration_delay_mean"]["mean"], r["analytical_peak_txn_per_cycle"],
                             r["analytical_random_estimate_txn_per_cycle"], "simulated (analytical columns: analytical)"])
        w("bank_sweep.csv", ["config", "workload", "banks", "capacity_bytes", "replications", "txn_per_cycle", "txn_ci95_half", "useful_B_per_cycle",
                             "read_lat_e2e_mean", "read_lat_ci95_half", "read_lat_p99", "conflicts_per_access", "bank_util_mean",
                             "arb_delay_mean", "analytical_peak_txn_per_cycle", "analytical_random_estimate", "provenance"], rows)
    if data.get("vector_study"):
        rows = [[r["word_bits"], r["vector_bits"], r["banks"], r["case"], r["useful_bytes_per_cycle"]["mean"], r["fetched_bytes_per_cycle"],
                 r["alignment_overhead"], r["conflict_rate_per_access"]["mean"], r["read_latency_e2e_mean"]["mean"], "simulated"]
                for r in data["vector_study"]["study"]["rows"]]
        w("vector_study.csv", ["word_bits", "vector_bits", "banks", "case", "useful_B_per_cycle", "fetched_B_per_cycle", "alignment_overhead",
                               "conflicts_per_access", "read_lat_e2e_mean", "provenance"], rows)
    if data.get("tensor_study"):
        rows = [[r["word_bits"], r["banks"], r["max_out"], r["pitch"], r["dma_duty"], r["mac_utilisation"], r["starvation_fraction"],
                 r["operand_bytes_per_cycle"], r["required_operand_bytes_per_cycle"], r["acc_traffic_words_per_cycle"],
                 r["buffer_occupancy_a_mean"], r["buffer_occupancy_b_mean"], r["dma_overlap_fraction"], r["bank_conflict_events"],
                 r["memory_limited"], "simulated"] for r in data["tensor_study"]["rows"]]
        w("tensor_study.csv", ["word_bits", "banks", "max_out", "pitch", "dma_duty", "mac_utilisation", "starvation_fraction", "operand_B_per_cycle",
                               "required_B_per_cycle", "acc_words_per_cycle", "buf_occ_A", "buf_occ_B", "dma_overlap", "conflict_events",
                               "memory_limited", "provenance"], rows)
    if data.get("optimise"):
        rows = [[c["id"], c["latency"], c["bandwidth"], c["energy_proxy"], c["area"]["value"], c["area"]["label"], c["pareto"], c["balanced_score"]]
                for c in data["optimise"]["candidates"]]
        w("optimise.csv", ["candidate", "mean_read_latency_e2e", "useful_B_per_cycle", "bit_activations_per_useful_byte(proxy)", "area", "area_label",
                           "pareto", "balanced_score"], rows)
    if data.get("rtl_verification"):
        rows = [[r["label"], r.get("ok"), r.get("cycles_compared"), r.get("transactions"), r.get("counters_compared")] for r in data["rtl_verification"]["results"]]
        w("rtl_verification.csv", ["case", "identical", "cycles", "transactions", "counters"], rows)
    return files


# ------------------------------------------------------------------------------ engineering report
def build_report(data: dict) -> str:
    L = []
    A = L.append
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    from . import tools
    env = tools.environment()
    A("# SilicaFlux SRAMLab — Engineering Report")
    A(f"\n_Generated {now} from `data/*.json` by `sramlab report`. Tools: Python {env['python']}, Verilator {env['verilator']}, Yosys {env['yosys']}; "
      f"OpenROAD/OpenSTA: {'available' if env['openroad'] else 'NOT available'}._\n")
    A("Every figure is labelled **analytical** (closed form), **simulated** (cycle model verified against the RTL), **rtl_simulated** (Verilator run of, or imported "
      "committed results of, the real RTL), **synthesized** (Yosys), **assumed**, or **unavailable**. **No figure here is a silicon or FPGA measurement; none exists.**\n")

    # ------------------------------------------------ 1 verification
    A("## 1. Model vs RTL verification (start of the programme)")
    v = data.get("rtl_verification")
    if v:
        A(f"The Python cycle model of `sf_sram_subsystem` (SRAMController P73 + SRAMCore P71) was compared with the Verilator simulation of the real RTL: "
          f"**{v['passed']}/{v['cases']} cases identical** over {v['cycles_compared']:,} cycles, {v['transactions']:,} transactions and {v['counters_compared']:,} hardware-counter values "
          f"({v['parameter_sets']} parameter sets). Negative control (deliberately broken models): "
          + ", ".join(f"{m['mutation']} → {'detected' if m['detected'] else 'MISSED'}" for m in v["mutation_check"]) + ". *(rtl_simulated vs simulated)*\n")
        tw = v.get("three_way")
        if tw:
            A(f"**Second simulator.** An independently written Icarus Verilog testbench replays the same stimulus: **{tw['passed']}/{tw['cases']} cases "
              f"Python model = Verilator = Icarus**, cycle for cycle and counter for counter. *(rtl_simulated, two simulators)*\n")
    else:
        A("_dataset `rtl_verification` not generated — run `sramlab rtlcheck`._\n")
    xs = data.get("xsim_verification")
    if xs:
        nc = xs.get("negative_control", {})
        import re as _re
        ivm = _re.search(r"(\d+\.\d+)", str(xs["simulators"].get("icarus") or ""))
        iv = f"Icarus {ivm.group(1)}" if ivm else "Icarus"
        txt = (f"**Study testbenches on two simulators** (`sramlab xsim`): the ECC codec, ECC bank and MBIST testbenches were run with byte-identical inputs on "
               f"Verilator {xs['simulators']['verilator']} and {iv}: **{xs['identical']}/{xs['cases']} cases identical** "
               f"({xs['lines_compared']:,} tagged result lines). Negative control — the MBIST testbench rebuilt without the Verilator optimiser workaround: "
               f"{nc.get('interpretation', 'not run')}")
        if nc.get("first_difference"):
            fd = nc["first_difference"]
            cy = lambda t: (t.split("cycles=")[1].split()[0] if "cycles=" in t else "?")
            txt += f" (first difference: Verilator `cycles={cy(fd['verilator'])}` vs Icarus `cycles={cy(fd['icarus'])}`)"
        A(txt + ". See `docs/03_verification.md` (*Harness portability*) for the three Verilator 5.020 defects this exposed.\n")
    rc = data.get("r_crosscheck")
    if rc and rc.get("status") in ("agree", "DISAGREE"):
        c = rc["comparison"]
        A(f"**Statistics recomputed in R** (`sramlab rstats`, {rc.get('rscript', 'R')}): **{c['agree']}/{c['compared']} quantities agree** with the Python "
          f"statistics (per-replication mean/median/P95/P99 and throughput exactly; Student-t CI half-widths within {rc['tolerances']['t_ci_half_width_rel']:.0e} relative; Spearman). "
          "*(simulated data, statistics cross-checked)*\n")

    # ------------------------------------------------ 2 bank sweep
    A("## 2. Bank-count comparison (constant 64 KiB, 4 masters, 32-bit words) — *simulated*, analytical ceilings labelled")
    bs = data.get("bank_sweep")
    if bs:
        for key, sw in bs.items():
            mo = key.split("_")[-1]
            A(f"\n### MAX_OUT = {mo} (10 replications, mean ± 95 % CI half-width)")
            rows = []
            for r in sw["rows"]:
                rows.append([r["workload"], r["banks"], _ci(r["throughput_txn_per_cycle"]), f"{r['analytical_peak_txn_per_cycle']:.2f}",
                             f"{r['analytical_random_estimate_txn_per_cycle']:.2f}", _ci(r["read_latency_mean"], 2), f"{r['read_latency_p99']['mean']:.1f}",
                             _ci(r["conflict_rate_per_access"]), f"{r['bank_utilisation_mean']['mean']:.2f}"])
            A(_tbl(["workload", "banks", "txn/cycle (sim)", "peak (analytical)", "random est. (analytical)", "read latency e2e (sim)", "p99", "conflicts/access", "bank util"], rows))
        A("\n**Findings (computed from the table):**")
        for f in bank_findings(bs):
            A(f"- {f}")
        A("- More banks do **not** always help: the benefit exists only when requests spread over banks *and* masters can keep more than one transaction in flight; "
          "the hardware cost of more banks is in §7 (synthesis) and §8 (area).")
    else:
        A("_dataset `bank_sweep` not generated._")
    rc = data.get("r_crosscheck")
    an = (rc or {}).get("analysis_r", {}).get("values", {})
    if an:
        d = rc["design"]
        A(f"\n**Sensitivity to bank count — computed in R** (`sramlab rstats`; {d['config']}, {', '.join(map(str, d['sweep_banks']))} banks at constant capacity, "
          f"{d['sweep_replications']} replications each, {d['requests_per_master']} requests/master): elasticity = slope of ln(throughput) on ln(banks) "
          "(a one-number summary over 2–16 banks; the relation need not be log-linear).")
        rows = []
        for w in d["workloads"]:
            sl = an.get(f"elasticity.{w}.slope")
            if sl is None:
                continue
            lo, hi, r2 = an.get(f"elasticity.{w}.ci_lo"), an.get(f"elasticity.{w}.ci_hi"), an.get(f"elasticity.{w}.r_squared")
            rows.append([w, f"{sl:.3f}", f"{lo:.3f} … {hi:.3f}" if isinstance(lo, float) else "—",
                         f"{r2:.3f}" if isinstance(r2, float) else an.get(f"elasticity.{w}.note", "—")])
        A(_tbl(["workload", "elasticity d ln(txn/cycle) / d ln(banks)", "95 % CI", "R² / note"], rows))
        if "kruskal_throughput_by_workload.p_value" in an:
            A(f"\nVariation between workloads (Kruskal–Wallis on per-replication throughput at the baseline configuration, {d['replications']} replications per workload): "
              f"H = {an['kruskal_throughput_by_workload.statistic']:.2f}, df = {an['kruskal_throughput_by_workload.df']:.0f}, p = {an['kruskal_throughput_by_workload.p_value']:.2g} "
              + ("— throughput differs between workloads well beyond seed-to-seed variation (p < 0.05). "
                 if an["kruskal_throughput_by_workload.p_value"] < 0.05 else
                 "— no significant between-workload difference at the 5 % level. ")
              + "*(simulated data, analysis in R)*")

    # ------------------------------------------------ 3 tensor
    A("\n## 3. Tensor memory study — *simulated* (TensorCore 4×4 INT8, output-stationary, direct-fed from banked SRAM)")
    ts = data.get("tensor_study")
    if ts:
        A(f"Operand requirement at peak: 4 A + 4 B bytes per k-step = 8 B/cycle for 16 MAC/cycle. Ideal-resource reference utilisation of this model: **{ts['util_ideal_reference']:.2f}**. "
          f"Verdict rule: {ts['verdict_rule']}.\n")
        sel = [r for r in ts["rows"] if r["word_bits"] == 32 and r["pitch"] == "padded" and r["dma_duty"] in (0.0, 0.5)]
        A(_tbl(["banks", "MAX_OUT", "DMA duty", "MAC util", "starved", "operand B/c (need 8)", "acc words/c", "buf occ A/B", "DMA overlap", "verdict"],
               [[r["banks"], r["max_out"], r["dma_duty"], f"{r['mac_utilisation']:.2f}", f"{r['starvation_fraction']:.2f}", f"{r['operand_bytes_per_cycle']:.2f}",
                 f"{r['acc_traffic_words_per_cycle']:.3f}", f"{r['buffer_occupancy_a_mean']:.1f}/{r['buffer_occupancy_b_mean']:.1f}",
                 "n/a" if r["dma_overlap_fraction"] != r["dma_overlap_fraction"] else f"{r['dma_overlap_fraction']:.2f}",
                 "MEMORY-limited" if r["memory_limited"] else "not memory-limited"] for r in sel]))
        A("\n**Findings (computed):**")
        for f in tensor_findings(ts):
            A(f"- {f}")
        ch = ts["chunked"]
        rv = data.get("rtl_verification") or {}
        tcases = [r for r in rv.get("results", []) if r.get("workload") == "tensor"]
        rtl_note = (f"replayed on the RTL in the §1 matrix at a scaled size: {sum(1 for r in tcases if r.get('ok'))}/{len(tcases)} cases cycle-identical"
                    if tcases else "open-loop, replayable on the RTL")
        A(f"\nTENSORCORE 08 DMA command stream ({rtl_note}): {ch['bytes_per_mac']:.3f} bytes/MAC (= 512 B per 1024 MAC chunk, as documented); sustained operand bandwidth "
          f"{ch['rows'][0]['operand_bytes_per_cycle']:.2f} B/cycle through one master → MAC/cycle roof {ch['rows'][0]['mac_per_cycle_roof']:.1f} of 16 *(analytical from simulated bandwidth)*. "
          f"{ch['note']}.")
    else:
        A("_dataset `tensor_study` not generated._")

    # ------------------------------------------------ 4 vector
    A("\n## 4. Vector memory study — *simulated*, cross-checked against RTL-simulation data")
    vs = data.get("vector_study")
    if vs:
        cc = vs["p76_crosscheck"]["value"]
        A(f"Alignment arithmetic and bank-slot cycle model vs the imported VectorScratch (P76) RTL-simulation bench: **{cc['cycles_exact_match']}/{cc['rows_checked']} rows cycle-exact**, "
          f"word-access counts {cc['word_access_count_match']} *(rtl_simulated reference)*. Scope: {cc['scope']}.\n")
        rows = [r for r in vs["study"]["rows"] if r["banks"] == 8 and r["word_bits"] in (32, 128) and r["vector_bits"] == 128]
        A("Controller study (single-port-per-master word accesses, 8 banks, 128-bit vectors, 4 vector masters):\n")
        A(_tbl(["word bits", "case", "useful B/c", "fetched B/c", "alignment overhead", "conflicts/access", "read lat e2e"],
               [[r["word_bits"], r["case"], _ci(r["useful_bytes_per_cycle"], 2), f"{r['fetched_bytes_per_cycle']:.2f}", f"{r['alignment_overhead']:.2f}×",
                 f"{r['conflict_rate_per_access']['mean']:.2f}", f"{r['read_latency_e2e_mean']['mean']:.2f}"] for r in rows]))
        A("\n**Findings (computed):**")
        for f in vector_findings(vs):
            A(f"- {f}")
    else:
        A("_dataset `vector_study` not generated._")

    # ------------------------------------------------ ECC / MBIST / synth / phys / power
    renderers = {"synth_sweep": _render_synth, "phys": _render_phys, "power": _render_power,
                 "ecc_study": _render_ecc, "mbist_study": _render_mbist}
    for title, key in (("5. ECC cost analysis", "ecc_study"), ("6. MBIST evaluation", "mbist_study"), ("7. Synthesis", "synth_sweep"),
                       ("8. Physical area", "phys"), ("9. Power and energy provenance", "power"), ("10. Thermal hand-off", "thermal")):
        A(f"\n## {title}")
        d = data.get(key)
        if d is None:
            A(f"_dataset `{key}` not generated._")
        else:
            A(renderers.get(key, lambda x, k: _render_generic(x, k))(d, key))

    # ------------------------------------------------ optimisation
    A("\n## 11. Optimisation — goals A–E, Pareto frontier")
    o = data.get("optimise")
    if o:
        A(o["statement"])
        for c in o["caveats"]:
            A(f"- **Caveat:** {c}")
        A("")
        rows = []
        for g, v in o["goals"].items():
            rows.append([g, v if isinstance(v, str) else (v["winners"][0] + (f" (+{v['n_tied'] - 1} tied)" if v["n_tied"] > 1 else ""))])
        A(_tbl(["goal", "best candidate(s)"], rows))
        A(f"\nBalanced-PPA winner under {o['weight_trials']} random weightings: " + ", ".join(f"`{k}` {n}×" for k, n in list(o["balanced_weight_stability"].items())[:4]))
    else:
        A("_dataset `optimise` not generated._")

    A("\n## 12. What this report does not claim")
    for s in ("No silicon, FPGA or board measurement exists for SilicaFlux; nothing here is `measured`.",
              "No clock frequency is claimed; cycles are exact for the modelled protocol, MB/s only appear under an explicitly assumed clock.",
              "No pJ/access, mW or temperature is reported unless a validated profile/model with provenance was supplied (see §9–§10).",
              "Die area is reported only where real macro manifests and (for logic) a real library were available; otherwise it is `unavailable`.",
              "MBIST coverage is coverage of the *injected simulation fault model*, not manufacturing defect coverage.",
              "OpenROAD / OpenSTA are not installed: no timing-closure or placed-and-routed result is claimed."):
        A(f"- {s}")
    return "\n".join(L) + "\n"


def _val(x):
    return x["value"] if isinstance(x, dict) and "value" in x else x


def _render_ecc(d, key) -> str:
    h = d.get("headline", {})
    out = ["Measured on the real MemoryCore RTL (`sf_ecc_enc/dec`, `sf_sram_bank` with and without SECDED) in Verilator, cross-checked against an independent Python SECDED reference. "
           "Gate counts are Yosys *generic* counts before technology mapping (this Yosys build cannot run ABC), so they are **not area**. *rtl_simulated / synthesized*\n"]
    cols = sorted(h, key=lambda k: int(k[2:]))
    def row(label, fn):
        return [label] + [fn(h[c]) for c in cols]
    rows = [
        row("stored bits per word (ECC on)", lambda x: x["stored_bits_ecc_on"]),
        row("storage overhead", lambda x: f"{x['storage_overhead_pct']:.3f} %"),
        row("encoder / decoder generic cells", lambda x: f"{x['enc_generic_cells']} / {x['dec_generic_cells']}"),
        row("bank generic cells, ECC off → on", lambda x: f"{x['bank_cells_ecc_off']} → {x['bank_cells_ecc_on']} ({x['bank_cells_ecc_on'] / x['bank_cells_ecc_off']:.1f}x)"),
        row("decoder latency added (RL 1 / RL 2)", lambda x: f"+{x['decoder_added_cycles_RL1']} / +{x['decoder_added_cycles_RL2']} cycle"),
        row("partial-write accept interval, ECC on (RL 1 / RL 2)", lambda x: f"{x['partial_write_accept_interval_RL1_ecc_on']:g} / {x['partial_write_accept_interval_RL2_ecc_on']:g} cycles (ECC off: 1)"),
        row("single-bit errors corrected", lambda x: x["single_bit_corrected"]),
        row("double-bit errors detected", lambda x: x["double_bit_detected"]),
        row("random 3-bit errors silently miscorrected", lambda x: f"{x['triple_bit_silently_miscorrected_rate'] * 100:.1f} %"),
        row("RTL vs independent reference", lambda x: f"{x['rtl_vs_reference_mismatches']} mismatches / {x['rtl_vs_reference_vectors']:,} vectors"),
    ]
    out.append(_tbl(["item"] + [f"{c[2:]}-bit words" for c in cols], rows))
    out.append("\nSECDED does **not** protect against 3-bit errors: most are silently miscorrected, as measured. Scrubbing consumes a measurable share of bank bandwidth "
               "(see the ECC study record, `scrub`). Fault injection shows what the logic does with a bit flip, not how often flips occur.")
    return "\n".join(out)


def _render_mbist(d, key) -> str:
    h = d.get("headline", {})
    out = [f"**{h.get('coverage_statement', 'coverage of the injected fault model in simulation; this is NOT manufacturing/physical defect coverage')}**\n",
           "Real RTL (P78 `sf_sram_mbist`, Verilator) plus an independent Python March simulator on an enumerated fault population. *rtl_simulated*; parallel-bank figures are *analytical* and not RTL-verified.\n"]
    rows = [
        ["March C- total test cycles, 16 banks × 256 words", f"{h['March C-_cycles_16_banks_x_256_words']:,}", "rtl_simulated"],
        ["MATS+ total test cycles, 16 banks × 256 words", f"{h['MATS+_cycles_16_banks_x_256_words']:,}", "rtl_simulated"],
        ["exact cycle model error vs RTL (45 runs)", f"{h['cycle_model_max_abs_error_cycles']} cycles", "analytical vs rtl_simulated"],
        ["plain 10N / 5N model error (16 banks)", f"{h['March C-_ops_only_model_error_pct']:.2f} % / {h['MATS+_ops_only_model_error_pct']:.2f} %", "analytical vs rtl_simulated"],
        ["banks tested one at a time (verified)", h["one_bank_at_a_time_verified"], "rtl_simulated"],
        ["failure registers vs independent prediction", h["failure_registers_match_python"], "rtl_simulated"],
        ["RTL vs Python simulator, per-fault mismatches (4×32)", h["coverage_4x32_rtl_vs_python_mismatches"], "rtl_simulated vs simulated"],
    ]
    out.append(_tbl(["item", "value", "provenance"], rows))
    cov = h.get("coverage_4x32_same_word_pct", {})
    if cov:
        out.append("\nSame-word coupling-fault coverage of the injected model (4 × 32 array, exhaustive; *injected simulation fault model only*):\n")
        out.append(_tbl(["test", "coverage"], [[k, f"{v:.2f} %"] for k, v in cov.items()]))
    out.append("\nThe RTL implements **sequential** bank testing only; parallel testing time is an analytical model in the study record. "
               "Test-mode overhead (functional masters refused for the whole test) and the sibling-report disagreements are documented in `docs/mbist.md`.")
    return "\n".join(out)


def _render_synth(d, key) -> str:
    out = ["Yosys synthesis of the **controller logic only** (the SRAM arrays are not synthesized to gates). *synthesized*. "
           "Generic gate counts are **not area**; logic depth is pre-mapping gate levels, **not a frequency**. "
           "Mapped area uses the open educational **Nangate45 45 nm** library and is not transferable to the SilicaFlux target process.\n"]
    gen = next((v for k, v in d["sweeps"].items() if k == "controller_sweep_generic"), None)
    nan = next((v for k, v in d["sweeps"].items() if k == "controller_sweep_nangate45"), None)
    if gen:
        mapped = {(r["banks"], r["perf"]): r.get("mapped_area_um2") for r in (nan or {}).get("rows", [])}
        rows = []
        for r in gen["rows"]:
            m = mapped.get((r["banks"], r["perf"]))
            rows.append([r["banks"], "on" if r["perf"] else "off", r["masters"], r["max_out"], f"{r['cells']:,}" if r["cells"] else "n/a",
                         f"{r['flip_flops']:,}" if r["flip_flops"] else "n/a", r["logic_depth_levels"] or "n/a",
                         "latch-free" if r.get("latch_free") else "?", f"{m:,.0f}" if m else "unavailable"])
        out.append(_tbl(["banks", "perf counters", "masters", "MAX_OUT", "generic cells", "flip-flops", "logic depth (levels)", "latches", "Nangate45 logic area um² (synthesized)"], rows))
        base = {r["banks"]: r["cells"] for r in gen["rows"] if not r["perf"] and r["cells"]}
        withp = {r["banks"]: r["cells"] for r in gen["rows"] if r["perf"] and r["cells"]}
        if 2 in base and 16 in base:
            msg = (f"\n**Hardware overhead of more banks (computed):** controller cells grow {base[16] / base[2]:.1f}x from 2 to 16 banks "
                   f"({base[2]:,} → {base[16]:,} generic cells, performance counters off).")
            if 4 in base and 4 in withp:
                msg += (f" Enabling the hardware performance-counter block multiplies the 4-bank controller by {withp[4] / base[4]:.1f}x "
                        f"({base[4]:,} → {withp[4]:,} cells): the counters used for every measurement in this report are not free.")
            out.append(msg)
    for k, v in d["singles"].items():
        if k.startswith(("subsystem", "noc_interface")):
            parts = v.get("parts") or {}
            if parts:
                out.append(f"\n`{k}`: " + "; ".join(f"{n}: {_val(p.get('total_cells'))} cells, {_val(p.get('flip_flops'))} FFs" for n, p in parts.items()))
            elif "generic" in v or "total_cells" in v:
                g = v.get("generic", v)
                out.append(f"\n`{k}`: {g.get('total_cells')} cells, {g.get('flip_flops')} FFs, status {v.get('status', 'ok')}")
    return "\n".join(out)


def _render_phys(d, key) -> str:
    ar = d.get("area_report", d)
    mf = ar.get("memory_footprint", {})
    out = [f"Configuration backend `{ar.get('backend')}`, technology profile `{ar.get('technology_profile')}`. All footprint values come from real vendor macro manifests (LEF-derived) *analytical (vendor dimensions)*; "
           "this is geometry arithmetic, not a layout.\n"]
    rows = []
    for k in ("macro", "process", "instances_total", "total_macro_area_mm2", "bit_utilisation", "wasted_bits_total"):
        v = mf.get(k)
        rows.append([k, _val(v), v.get("provenance", "") if isinstance(v, dict) else ""])
    ec = ar.get("ecc_overhead", {})
    rows.append(["ECC stored-bit ratio (this config)", _val(ec.get("stored_bit_ratio")), "analytical"])
    rc = ar.get("routing_estimate", {})
    rows.append(["routing estimate (mean Manhattan, um)", rc.get("mean_manhattan_centre_um"), "analytical (NOT routed)"])
    da = ar.get("die_area", {})
    rows.append(["die area", _val(da) if _val(da) is not None else "UNAVAILABLE", da.get("reason", "")[:90] if isinstance(da, dict) else ""])
    ha = ar.get("placement_constraints", {}).get("halo_keepout", {})
    rows.append(["halo / keep-out", _val(ha) if _val(ha) is not None else "UNAVAILABLE", ha.get("reason", "")[:90] if isinstance(ha, dict) else ""])
    out.append(_tbl(["item", "value", "provenance / reason"], rows))
    out.append("\n**Die area is unknown:** it needs controller logic area in the SAME technology as the macros plus layout margins; no such library/rule is available for the macro process here, "
               "so nothing is estimated. (The Nangate45 logic area is never added to 130 nm macro area.)")
    return "\n".join(out)


def _render_power(d, key) -> str:
    out = [d.get("statement", ""), ""]
    act = d.get("activity", {})
    rows = [[k, _val(v), "simulated"] for k, v in act.items() if isinstance(v, dict) and "value" in v]
    out.append(_tbl(["activity figure (parameter-free)", "value", "provenance"], rows))
    out.append("")
    sec = []
    for name in ("analytical_energy", "activity_based_estimate", "fpga_vendor_estimate", "asic_library_estimate", "hardware_measurement"):
        v = d.get(name, {})
        status = (v.get("provenance") or v.get("label") or "?") if isinstance(v, dict) else "?"
        why = v.get("reason") or v.get("note") or "" if isinstance(v, dict) else ""
        sec.append([name, "UNAVAILABLE" if (isinstance(v, dict) and v.get("value") is None and "reason" in v) else status, str(why)[:100]])
    out.append(_tbl(["energy class (kept separate)", "status", "reason / note"], sec))
    return "\n".join(out)


def _render_generic(d, key, depth=0, maxrows=40):
    """Fallback renderer for study datasets: lists scalar leaves with their provenance labels."""
    rows = []

    def walk(x, path):
        if len(rows) >= maxrows:
            return
        if isinstance(x, dict):
            if "provenance" in x and "value" in x and not isinstance(x["value"], (dict, list)):
                rows.append([path, x["value"], x["provenance"], x.get("source", x.get("reason", ""))])
                return
            for k, v in x.items():
                walk(v, f"{path}.{k}" if path else k)
        elif isinstance(x, list):
            for i, v in enumerate(x[:8]):
                walk(v, f"{path}[{i}]")
        elif isinstance(x, (int, float, str, bool)) or x is None:
            if not path.endswith(("note", "source")):
                rows.append([path, x, "", ""])

    walk(d, "")
    return _tbl(["item", "value", "provenance", "source / reason"], [[str(a)[:70], str(b)[:60], c, str(e)[:70]] for a, b, c, e in rows])


def build_all(data_dir: str = DATA, out_dir: str | None = None) -> dict:
    out_dir = out_dir or os.path.join(ROOT, "reports")
    os.makedirs(out_dir, exist_ok=True)
    data = load_data(data_dir)
    md = build_report(data)
    rp = os.path.join(out_dir, "engineering_report.md")
    open(rp, "w").write(md)
    csvs = write_csvs(data, os.path.join(out_dir, "csv"))
    return {"report": rp, "csv": csvs, "datasets": {k: v is not None for k, v in data.items() if not k.startswith("_")}}
