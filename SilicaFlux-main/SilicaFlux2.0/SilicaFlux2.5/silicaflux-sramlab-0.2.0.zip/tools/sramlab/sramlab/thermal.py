"""Thermal hand-off: ThermalLab block-power files from the generated floorplan, plus a tiny analytical hotspot map.

Everything written here is an **uncalibrated model input - not a die temperature**.  ThermalLab is NOT executed (it is a
separate package); this module only writes files in its documented per-block power schema

    name, zone, x0_um, y0_um, x1_um, y1_um, power_w      (required)
    kind, layer, provenance, source                        (optional)

(see ``power_mapping.load_blocks_csv/json`` of SilicaFlux ThermalLab 0.1.0; ``validate_blocks`` below is this tool's own
re-implementation of the documented required-field rules, not ThermalLab).

Rules
-----
* SRAM bank rectangles come from the GENERATED geometry of :func:`sramlab.phys.floorplan` (not a routed layout).
* ``power_w`` is emitted only when power is available (validated energy profile -> :func:`power_by_block_from_energy`, or
  caller-supplied power with its own provenance).  Otherwise the ThermalLab file is NOT written and the result carries
  ``unavailable("no validated energy profile => no power")``; the geometry + access-activity file is still written.
* The 2-D finite-difference map (:func:`hotspot_map_2d`) is ``analytical`` and ``uncalibrated``; its conductivity, sheet
  thickness, ambient coupling and ambient temperature are REQUIRED arguments - there are no defaults presented as facts.
"""
from __future__ import annotations

import csv
import json
import math
import os

import numpy as np

from .provenance import tag, unavailable

HEADER_STATEMENT = "uncalibrated model input - not a die temperature"
REQUIRED_COLUMNS = ("name", "zone", "x0_um", "y0_um", "x1_um", "y1_um", "power_w")
COLUMNS = REQUIRED_COLUMNS + ("kind", "layer", "provenance", "source")
ACTIVITY_COLUMNS = ("name", "zone", "x0_um", "y0_um", "x1_um", "y1_um", "kind", "layer", "provenance", "source",
                    "accesses", "access_share", "utilisation_accesses_per_cycle", "access_density_per_mm2")
# ThermalLab DataStatus values (materials.DataStatus); our label -> its provenance column
THERMALLAB_PROVENANCE = {"assumed": "assumed_engineering_parameter", "simulated": "user_supplied_data",
                         "rtl_simulated": "user_supplied_data", "analytical": "user_supplied_data",
                         "synthesized": "eda_derived_data", "measured": "laboratory_measurement"}
GEOMETRY_PROVENANCE = "assumed_engineering_parameter"


def validate_blocks(blocks: list[dict], *, need_power: bool = True, need_zone: bool = True) -> list[str]:
    """The documented ThermalLab required-field rules (this tool's own check, not ThermalLab)."""
    errs, seen = [], set()
    req = tuple(c for c in REQUIRED_COLUMNS if (need_power or c != "power_w") and (need_zone or c != "zone"))
    for i, b in enumerate(blocks):
        miss = [c for c in req if b.get(c) in (None, "")]
        if miss:
            errs.append(f"block {i} ({b.get('name')!r}): missing {miss}")
            continue
        for c in ("x0_um", "y0_um", "x1_um", "y1_um") + (("power_w",) if need_power else ()):
            if not isinstance(b[c], (int, float)) or isinstance(b[c], bool) or not math.isfinite(b[c]):
                errs.append(f"block {b['name']!r}: {c} is not a finite number")
        if all(isinstance(b[c], (int, float)) for c in ("x0_um", "y0_um", "x1_um", "y1_um")) and \
                (b["x1_um"] <= b["x0_um"] or b["y1_um"] <= b["y0_um"]):
            errs.append(f"block {b['name']!r}: empty or inverted rectangle")
        if need_power and isinstance(b.get("power_w"), (int, float)) and b["power_w"] < 0:
            errs.append(f"block {b['name']!r}: power_w must be >= 0")
        if b["name"] in seen:
            errs.append(f"duplicate block name {b['name']!r}")
        seen.add(b["name"])
    return errs


# ---------------------------------------------------------------------------------------------- blocks
def _bank_accesses(run_metrics: dict | None, nbanks: int) -> tuple[list | None, int | None]:
    if not run_metrics:
        return None, None
    m = run_metrics.get("metrics") if isinstance(run_metrics.get("metrics"), dict) else run_metrics
    ba = m.get("bank_accesses")
    if ba is None or len(ba) != nbanks:
        return None, m.get("cycles")
    return [int(x) for x in ba], m.get("cycles")


def blocks_from_floorplan(fp: dict, run_metrics: dict | None = None) -> tuple[list[dict], dict]:
    """Geometry (+ access activity) blocks: one per bank region, plus the controller rectangle when it exists."""
    if fp.get("status") != "ok" or not fp.get("bank_regions"):
        raise ValueError("floorplan has no generated geometry (status != ok): " + str((fp.get("reason") or fp.get("die"))))
    regions = fp["bank_regions"]
    acc, cycles = _bank_accesses(run_metrics, len(regions))
    tot = sum(acc) if acc else None
    src = ("generated geometry (sramlab.phys.floorplan), not a routed layout; " + HEADER_STATEMENT)
    blocks = []
    for r in regions:
        w, h = r["x1"] - r["x0"], r["y1"] - r["y0"]
        b = {"name": f"SRAM_bank{r['bank']}", "zone": "SRAM", "x0_um": r["x0"], "y0_um": r["y0"], "x1_um": r["x1"],
             "y1_um": r["y1"], "kind": "cell", "layer": "active", "provenance": GEOMETRY_PROVENANCE, "source": src}
        if acc is not None:
            a = acc[r["bank"]]
            b["accesses"] = a
            b["access_share"] = (a / tot) if tot else 0.0
            b["utilisation_accesses_per_cycle"] = (a / cycles) if cycles else None
            b["access_density_per_mm2"] = a / (w * h / 1e6)
        blocks.append(b)
    c = (fp.get("controller") or {}).get("rect")
    if c:
        blocks.append({"name": "controller", "zone": "LOGIC", "x0_um": c["x0"], "y0_um": c["y0"], "x1_um": c["x1"],
                       "y1_um": c["y1"], "kind": "cell", "layer": "active", "provenance": GEOMETRY_PROVENANCE, "source": src})
    meta = {"banks": len(regions), "has_activity": acc is not None, "controller_rect": bool(c),
            "placed_bbox_um": fp.get("placed_bbox_um")}
    return blocks, meta


def power_by_block_from_energy(energy_rep: dict, fp: dict, run_metrics: dict) -> dict | None:
    """Per-bank average power (W) from the ACTIVITY-BASED energy of :func:`sramlab.power.energy_report`.

    Needs ``total_energy_J`` (so a complete validated profile) and a clock.  Dynamic read/write energy is distributed by
    each bank's access share, idle energy by its idle-cycle share, leakage evenly (identical tiling per bank).  Returns
    ``None`` when any of that is unavailable.  The controller has no energy model, so it gets no entry."""
    ab = (energy_rep or {}).get("activity_based_estimate") or {}
    if not isinstance(ab.get("total_energy_J"), dict) or ab["total_energy_J"].get("value") is None:
        return None
    terms = ab["terms"]
    lk = terms.get("leakage_energy_J") or {}
    if lk.get("value") is None or not lk.get("time_s"):
        return None
    nb = len(fp["bank_regions"])
    acc, cycles = _bank_accesses(run_metrics, nb)
    if acc is None or not cycles or not sum(acc):
        return None
    tsec = lk["time_s"]
    rw = terms["read_energy_J"]["value"] + terms["write_energy_J"]["value"]
    idle_b = [cycles - a for a in acc]
    idle_tot = sum(idle_b)
    label = ab["label"]
    out = {}
    for b in range(nb):
        e = rw * acc[b] / sum(acc) + (terms["idle_energy_J"]["value"] * idle_b[b] / idle_tot if idle_tot else 0.0) + lk["value"] / nb
        out[f"SRAM_bank{b}"] = tag(e / tsec, label, "activity-based energy distributed per bank / (cycles / assumed clock)",
                                   unit="W", coefficient_provenance=ab.get("coefficient_provenance"))
    return out


def _power_value(p) -> tuple[float | None, str, str]:
    if isinstance(p, dict) and "value" in p:
        return p["value"], p.get("provenance", "assumed"), p.get("source", "")
    return (p, "assumed", "caller-supplied power (no provenance given: treated as an assumption)")


def _write_csv(path: str, cols, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(cols), extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({c: ("" if r.get(c) is None else r[c]) for c in cols})


def thermal_handoff(floorplan: dict, power_by_block: dict | None, outdir, *, run_metrics: dict | None = None,
                    neighbours: list[dict] | None = None) -> dict:
    """Write the thermal hand-off files into ``outdir``.

    * ``block_geometry_activity.{csv,json}`` (always): bank rectangles from the generated floorplan + per-bank access
      activity (from ``run_metrics['bank_accesses']``) - NO power.
    * ``thermallab_blocks.{csv,json}`` (only when power exists): the same blocks plus ``power_w`` in the ThermalLab schema,
      plus caller-supplied ``neighbours`` (compute heat sources: dicts with name,x0_um,y0_um,x1_um,y1_um,power_w[,zone,
      provenance,source]).  ``power_by_block``: ``{block_name: watts | tagged dict}``; ``None`` or an empty mapping means
      no power: the file is omitted and ``thermallab_blocks`` is ``unavailable("no validated energy profile => no power")``.

    Every JSON carries ``_label`` = "uncalibrated model input - not a die temperature" and every CSV row repeats it in the
    ``source`` column (a leading comment line would break ThermalLab's ``csv.DictReader``)."""
    os.makedirs(os.fspath(outdir), exist_ok=True)
    out = os.fspath(outdir)
    blocks, meta = blocks_from_floorplan(floorplan, run_metrics)
    errs = validate_blocks(blocks, need_power=False)
    if errs:
        raise ValueError("generated blocks invalid: " + "; ".join(errs))
    bbox = floorplan.get("placed_bbox_um")
    head = {"_label": HEADER_STATEMENT, "_geometry": "generated geometry from vendor macro dimensions, not a routed layout",
            "_units": "um", "_origin": "lower-left of the placed objects (x right, y up); same convention as ThermalLab die origin",
            "_die_um": {"placed_bbox_width_um": bbox["width"], "placed_bbox_height_um": bbox["height"]} if bbox else None}
    files: dict = {}
    # ---- geometry + activity (always)
    ga_csv, ga_json = os.path.join(out, "block_geometry_activity.csv"), os.path.join(out, "block_geometry_activity.json")
    _write_csv(ga_csv, ACTIVITY_COLUMNS, blocks)
    with open(ga_json, "w") as fh:
        json.dump({**head, "_schema": "geometry + access activity (no power); NOT a ThermalLab power file",
                   "blocks": blocks}, fh, indent=1)
    files["geometry_activity_csv"], files["geometry_activity_json"] = ga_csv, ga_json
    res: dict = {"label": HEADER_STATEMENT, "files": files, "blocks": blocks, "meta": meta}
    # ---- neighbours
    nb_blocks = []
    for i, n in enumerate(neighbours or []):
        b = {"name": n.get("name"), "zone": n.get("zone") or "COMPUTE", "x0_um": n.get("x0_um"), "y0_um": n.get("y0_um"),
             "x1_um": n.get("x1_um"), "y1_um": n.get("y1_um"), "power_w": n.get("power_w"), "kind": n.get("kind") or "cell",
             "layer": n.get("layer") or "active", "provenance": n.get("provenance") or "assumed_engineering_parameter",
             "source": (n.get("source") or "caller-supplied neighbouring heat source") + "; " + HEADER_STATEMENT}
        nb_blocks.append(b)
    e2 = validate_blocks(nb_blocks, need_power=True)
    if e2:
        raise ValueError("neighbour blocks invalid: " + "; ".join(e2))
    # ---- power
    pw = {k: v for k, v in (power_by_block or {}).items()}
    sram_names = {b["name"] for b in blocks}
    unknown = sorted(set(pw) - sram_names)
    if unknown:
        raise ValueError(f"power_by_block names unknown blocks {unknown}; floorplan blocks are {sorted(sram_names)}")
    have = [b for b in blocks if b["name"] in pw and _power_value(pw[b["name"]])[0] is not None]
    missing_sram = [b["name"] for b in blocks if b["zone"] == "SRAM" and b not in have]
    if have and missing_sram:
        why = (f"power supplied for only {len(have)} of {len(have) + len(missing_sram)} powered blocks; missing {missing_sram}: "
               "a partial thermal input would silently treat the missing banks as cold, so no ThermalLab file is written")
        res["thermallab_blocks"] = unavailable(why)
        res["power"] = unavailable(why)
        return res
    if not have:
        res["thermallab_blocks"] = unavailable("no validated energy profile => no power")
        res["power"] = unavailable("no validated energy profile => no power")
        res["neighbours_not_emitted"] = ("neighbour heat sources are not written without SRAM power: a ThermalLab file with "
                                         "only the neighbours would hide the missing SRAM heat" if nb_blocks else None)
        return res
    tl_rows, omitted = [], []
    for b in blocks:
        if b["name"] in pw and _power_value(pw[b["name"]])[0] is not None:
            val, lab, srcs = _power_value(pw[b["name"]])
            row = {k: b[k] for k in ("name", "zone", "x0_um", "y0_um", "x1_um", "y1_um", "kind", "layer")}
            row["power_w"] = val
            row["provenance"] = THERMALLAB_PROVENANCE.get(lab, "assumed_engineering_parameter")
            row["source"] = f"{srcs or 'power ' + lab}; power label '{lab}'; bank rectangle = generated geometry; {HEADER_STATEMENT}"
            tl_rows.append(row)
        else:
            omitted.append({"name": b["name"], "reason": "no power supplied for this block (not guessed)"})
    tl_rows += nb_blocks
    e3 = validate_blocks(tl_rows, need_power=True)
    if e3:
        raise ValueError("thermal blocks invalid: " + "; ".join(e3))
    tl_csv, tl_json = os.path.join(out, "thermallab_blocks.csv"), os.path.join(out, "thermallab_blocks.json")
    _write_csv(tl_csv, COLUMNS, tl_rows)
    with open(tl_json, "w") as fh:
        json.dump({**head, "_schema": "ThermalLab block JSON: {'blocks': [name, zone, x0_um, y0_um, x1_um, y1_um, power_w, "
                                      "kind, layer, provenance, source]} (power_mapping.load_blocks_json)",
                   "_not_executed": "ThermalLab was NOT run; this is a format-level hand-off",
                   "_omitted_blocks": omitted, "blocks": tl_rows}, fh, indent=1)
    files["thermallab_csv"], files["thermallab_json"] = tl_csv, tl_json
    total = sum(r["power_w"] for r in tl_rows)
    res["thermallab_blocks"] = {"label": HEADER_STATEMENT, "blocks": len(tl_rows), "omitted": omitted, "csv": tl_csv, "json": tl_json}
    res["power"] = {"total_w": total, "provenance_labels": sorted({_power_value(v)[1] for v in pw.values()}),
                    "note": "power values are as supplied (with their labels); this module invents none"}
    return res


# ---------------------------------------------------------------------------------------------- hotspot map
def _overlap(edges: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return np.clip(np.minimum(edges[1:], hi) - np.maximum(edges[:-1], lo), 0.0, None)


def rasterise_power(blocks: list[dict], width_um: float, height_um: float, nx: int, ny: int) -> np.ndarray:
    """Conservative area-overlap deposit of block powers onto an (nx, ny) cell grid (W per cell); total power is exact."""
    xe, ye = np.linspace(0.0, width_um, nx + 1), np.linspace(0.0, height_um, ny + 1)
    P = np.zeros((nx, ny))
    for b in blocks:
        if b["x0_um"] < -1e-9 or b["y0_um"] < -1e-9 or b["x1_um"] > width_um + 1e-9 or b["y1_um"] > height_um + 1e-9:
            raise ValueError(f"block {b['name']!r} extends outside the {width_um} x {height_um} um domain")
        ox = _overlap(xe, b["x0_um"], b["x1_um"]) / (b["x1_um"] - b["x0_um"])
        oy = _overlap(ye, b["y0_um"], b["y1_um"]) / (b["y1_um"] - b["y0_um"])
        P += b["power_w"] * ox[:, None] * oy[None, :]
    return P


def _apply(theta: np.ndarray, gx: float, gy: float, ga: float) -> np.ndarray:
    """A @ theta for the 5-point finite-volume operator with adiabatic borders."""
    r = ga * theta
    dx = theta[1:, :] - theta[:-1, :]
    r[1:, :] += gx * dx
    r[:-1, :] -= gx * dx
    dy = theta[:, 1:] - theta[:, :-1]
    r[:, 1:] += gy * dy
    r[:, :-1] -= gy * dy
    return r


def hotspot_map_2d(blocks: list[dict], width_um: float, height_um: float, *, nx: int, ny: int, k_w_per_mk: float,
                   thickness_um: float, h_w_per_m2k: float, t_ambient_c: float, tol: float = 1e-12,
                   max_iter: int = 50000) -> dict:
    """Steady-state 2-D finite-volume hotspot map of a heat-spreading sheet (pure numpy, CG solver).

    Model: ``k t (T_xx + T_yy) - h (T - T_amb) + q'' = 0`` on ``width x height`` with adiabatic borders: in-plane conduction in
    a sheet of thickness ``t`` and conductivity ``k``, coupled to ambient through ``h`` per unit area.  ``blocks`` carry
    ``x0_um..y1_um`` and ``power_w``.  ALL physical parameters are required arguments (assumptions of the caller).

    Label: ``analytical`` + ``uncalibrated``.  The result is a rise map relative to the caller's assumed ambient, NOT a die
    temperature.  Verified against the closed form for uniform heating (``rise = q''/h``) and by exact power balance
    ``sum(h A rise) == total power``."""
    for name, v in (("k_w_per_mk", k_w_per_mk), ("thickness_um", thickness_um), ("h_w_per_m2k", h_w_per_m2k),
                    ("width_um", width_um), ("height_um", height_um)):
        if not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v) or v <= 0:
            raise ValueError(f"{name} must be a positive finite number (got {v!r}); no default is assumed")
    if not isinstance(t_ambient_c, (int, float)) or not math.isfinite(t_ambient_c):
        raise ValueError("t_ambient_c must be a finite number (assumed ambient)")
    if nx < 2 or ny < 2:
        raise ValueError("nx and ny must be >= 2")
    errs = validate_blocks(blocks, need_power=True, need_zone=False)
    if errs:
        raise ValueError("; ".join(errs))
    W, H, t = width_um * 1e-6, height_um * 1e-6, thickness_um * 1e-6
    dx, dy = W / nx, H / ny
    gx, gy, ga = k_w_per_mk * t * dy / dx, k_w_per_mk * t * dx / dy, h_w_per_m2k * dx * dy
    P = rasterise_power(blocks, width_um, height_um, nx, ny)
    # Jacobi-preconditioned CG on A theta = P  (A is SPD because ga > 0)
    diag = np.full((nx, ny), ga)
    diag[1:, :] += gx
    diag[:-1, :] += gx
    diag[:, 1:] += gy
    diag[:, :-1] += gy
    x = np.zeros((nx, ny))
    r = P - _apply(x, gx, gy, ga)
    z = r / diag
    p = z.copy()
    rz = float((r * z).sum())
    bnorm = max(float(np.linalg.norm(P)), 1e-300)
    it = 0
    while it < max_iter and float(np.linalg.norm(r)) > tol * bnorm:
        Ap = _apply(p, gx, gy, ga)
        alpha = rz / float((p * Ap).sum())
        x += alpha * p
        r -= alpha * Ap
        z = r / diag
        rz_new = float((r * z).sum())
        p = z + (rz_new / rz) * p
        rz = rz_new
        it += 1
    total = float(P.sum())
    balance = float((ga * x).sum())
    return {
        "label": "analytical", "calibration": "uncalibrated",
        "statement": HEADER_STATEMENT + "; rise is relative to the caller's assumed ambient",
        "model": "steady 2-D finite volume: k t laplacian(T) - h (T - T_amb) + q'' = 0, adiabatic borders, uniform in the sheet",
        "assumed_parameters": {"k_w_per_mk": k_w_per_mk, "thickness_um": thickness_um, "h_w_per_m2k": h_w_per_m2k,
                               "t_ambient_c": t_ambient_c, "provenance": "assumed (caller-supplied)"},
        "grid": {"nx": nx, "ny": ny, "dx_um": dx * 1e6, "dy_um": dy * 1e6}, "iterations": it,
        "rise_k": x, "max_rise_k": float(x.max()), "mean_rise_k": float(x.mean()),
        "hotspot_cell": [int(i) for i in np.unravel_index(int(np.argmax(x)), x.shape)],
        "total_power_w": total, "power_balance_residual_w": abs(balance - total),
    }
