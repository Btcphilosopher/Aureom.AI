"""Core performance metrics and analytical ceilings.

Provenance classes (every value carries one, see ``sramlab.provenance``):

* ``simulated``   - produced by the cycle model (which is verified against the RTL, see rtlrun/verify)
* ``analytical``  - a closed-form ceiling or estimate; never mixed into a simulated number
* ``rtl_counter`` - hardware counter value of the RTL (identical to the model's by verification)

Definitions (all per the SRAMController performance-counter documentation):

* accept time      : cycle in which ``m_req_valid & m_req_ready`` (= bank access issue)
* arbitration delay: accept cycle - first cycle the request was presented
* response latency : (cycle the response enters the response FIFO + 1) - accept cycle   [uncontended: L + 1];
                     this is the RTL-defined latency and EXCLUDES the time a request waits to be accepted
* end-to-end latency: response available - first cycle the request was presented
                     (= arbitration delay + response latency); this is what a master experiences
* total latency    : cycle the response is transferred - accept cycle   (includes master back-pressure)
* useful bytes     : bytes the *requester* asked for: full word per read/write, popcount(wstrb) per
                     write; workload studies that fetch extra bytes (misaligned vectors) subtract the
                     padding via ``useful_bytes_override``
* sustained B/cycle: useful bytes / simulated cycles
"""
from __future__ import annotations

import math

import numpy as np

from .sim.controller import (CtlParams, PB_ACCESS, PB_BUSY, PB_CONF_CYC, PB_LOSERS, PG_ACCEPTED, PG_BUSY,
                             PG_CONFLICT, PG_CYCLES, PG_ORDER_STALL, PG_RSP_STALL, PG_WAIT, ST_OK)
from .sim.driver import RunResult


def _pct(a: np.ndarray, q: float) -> float:
    return float(np.percentile(a, q)) if len(a) else float("nan")


def dist(a) -> dict:
    a = np.asarray(a, dtype=float)
    if len(a) == 0:
        return {"n": 0}
    return {"n": int(len(a)), "mean": float(a.mean()), "median": float(np.median(a)), "p95": _pct(a, 95),
            "p99": _pct(a, 99), "min": float(a.min()), "max": float(a.max()), "std": float(a.std(ddof=1)) if len(a) > 1 else 0.0}


# --------------------------------------------------------------------------- analytical ceilings
def analytical_ceilings(p: CtlParams, active_masters: int | None = None, workload: str | None = None) -> dict:
    """Closed-form ceilings.  These are bounds / estimates, NOT results of the simulation.

    array_ceiling   : NUM_BANKS single-port banks serve at most one access per bank per cycle
    master_ceiling  : a master has MAX_OUT credits and a credit returns L+1 cycles after acceptance
                      (L = bank latency, +1 for the response register), so it sustains at most
                      min(1, MAX_OUT / (L + 1)) requests per cycle (the RTL docs measure 0.799 for
                      MAX_OUT=4, L=4: 4/5 - and 0.5 for MAX_OUT=1, L=1)
    peak            : min(array_ceiling, masters * master_ceiling) transactions per cycle
    bank_lock       : with unequal bank latencies a master that has accesses in flight may only issue
                      to the same bank, so the closed-form master ceiling above is an UPPER bound only
    random_estimate : expected busy banks when `m` masters each pick a bank uniformly at random every
                      cycle = B * (1 - (1 - 1/B)^m); an approximation (ignores queueing), so it is
                      reported as an estimate and can be exceeded or undershot by the simulation
    """
    nm = active_masters or p.num_masters
    nb = p.num_banks
    lat_mean = sum(p.bank_lats) / nb
    lat_for_rate = p.min_lat
    master_rate = min(1.0, p.max_out / (lat_for_rate + 1))
    peak_txn = min(float(nb), nm * master_rate)
    out = {
        "label": "analytical",
        "array_ceiling_txn_per_cycle": float(nb),
        "master_ceiling_txn_per_cycle": master_rate,
        "peak_txn_per_cycle": peak_txn,
        "peak_bytes_per_cycle": peak_txn * p.nbyte,
        "array_peak_bytes_per_cycle": nb * p.nbyte,
        "single_bank_bytes_per_cycle": 1.0 * p.nbyte,
        "bound_kind": "tight" if p.uniform_eff == 1 else "upper bound only (bank-lock rule active)",
        "min_uncontended_latency_cycles": p.min_lat + 1,
        "max_uncontended_latency_cycles": p.max_lat + 1,
        "mean_bank_latency": lat_mean,
        "random_access_estimate_txn_per_cycle": min(nm * master_rate, nb * (1.0 - (1.0 - 1.0 / nb) ** nm)) if nb > 0 else 0.0,
    }
    out["random_access_estimate_bytes_per_cycle"] = out["random_access_estimate_txn_per_cycle"] * p.nbyte
    if workload in ("contention",):
        out["workload_ceiling_txn_per_cycle"] = 1.0
        out["workload_ceiling_note"] = "all masters target one bank: one single-port bank serves 1 access/cycle"
    return out


# --------------------------------------------------------------------------- simulated metrics
def compute(r: RunResult, *, useful_bytes_override: int | None = None, clock_mhz: float | None = None,
            workload: str | None = None, active_masters: int | None = None) -> dict:
    p, tx = r.params, r.tx
    n = len(tx)
    cyc = r.cycles
    A = lambda x, dt=np.int64: np.asarray(x, dtype=dt)
    accept, present = A(tx.accept), A(tx.present)
    push, xfer, we, st = A(tx.push), A(tx.xfer), A(tx.we), A(tx.status)
    wstrb = tx.wstrb
    done = (st == ST_OK)
    ok_mask = done & (xfer >= 0)
    arb_delay = accept - present
    lat_resp = (push + 1) - accept
    lat_total = xfer - accept
    lat_e2e = (push + 1) - present          # request presented -> response available: includes arbitration/queue wait
    rd = ok_mask & (we == 0)
    wr = ok_mask & (we == 1)
    # useful bytes
    if useful_bytes_override is not None:
        useful = int(useful_bytes_override)
    elif any(u >= 0 for u in tx.useful):
        # requester-useful bytes (vector/tensor studies): padding bytes fetched with a word are not useful
        useful = sum(tx.useful[i] if tx.useful[i] >= 0 else (p.nbyte if not tx.we[i] else bin(int(wstrb[i])).count("1"))
                     for i in np.nonzero(ok_mask)[0])
    else:
        useful = int(rd.sum()) * p.nbyte + sum(bin(int(wstrb[i])).count("1") for i in np.nonzero(wr)[0])
    pv = r.perf
    g = r.perf_dict["global"]
    per_bank = r.perf_dict["bank"]
    nb = p.num_banks
    bank_acc = [b["ACCESS"] for b in per_bank]
    bank_busy = [b["BUSY"] for b in per_bank]
    conf_cyc = [b["CONF_CYC"] for b in per_bank]
    losers = [b["LOSERS"] for b in per_bank]
    accepted = g["ACCEPTED"]
    m: dict = {
        "label": "simulated",
        "cycles": cyc, "drained": r.drained,
        "transactions_accepted": int(accepted), "transactions_ok": int(ok_mask.sum()),
        "transactions_error": int(((st != ST_OK) & (st >= 0)).sum()),
        "reads": int(rd.sum()), "writes": int(wr.sum()),
        "request_throughput_txn_per_cycle": accepted / cyc if cyc else 0.0,
        "useful_bytes": useful,
        "useful_bytes_per_cycle": useful / cyc if cyc else 0.0,
        "fetched_bytes_per_cycle": (int(ok_mask.sum()) * p.nbyte) / cyc if cyc else 0.0,
        "read_bytes_per_cycle": int(rd.sum()) * p.nbyte / cyc if cyc else 0.0,
        "write_bytes_per_cycle": sum(bin(int(wstrb[i])).count("1") for i in np.nonzero(wr)[0]) / cyc if cyc else 0.0,
        "bank_utilisation": [a / cyc if cyc else 0.0 for a in bank_acc],
        "bank_utilisation_mean": float(np.mean(bank_acc)) / cyc if cyc else 0.0,
        "bank_busy_fraction": [b / cyc if cyc else 0.0 for b in bank_busy],
        "bank_accesses": bank_acc,
        "bank_balance_cv": float(np.std(bank_acc) / np.mean(bank_acc)) if np.mean(bank_acc) > 0 else 0.0,
        "conflict_events": int(g["CONFLICT"]),
        "conflict_rate_per_access": g["CONFLICT"] / accepted if accepted else 0.0,
        "conflict_cycle_fraction_per_bank": [c / cyc if cyc else 0.0 for c in conf_cyc],
        "conflict_losers_per_bank": losers,
        "order_stall_master_cycles": int(g["ORDER_STALL"]),
        "rsp_stall_master_cycles": int(g["RSP_STALL"]),
        "waiting_masters_mean": g["WAIT"] / cyc if cyc else 0.0,
        "arbitration_delay": dist(arb_delay),
        "read_latency_e2e": dist(lat_e2e[rd]),
        "write_latency_e2e": dist(lat_e2e[wr]),
        "read_latency_response": dist(lat_resp[rd]),
        "write_latency_response": dist(lat_resp[wr]),
        "read_latency_total": dist(lat_total[rd]),
        "write_latency_total": dist(lat_total[wr]),
        "integrity_errors": len(r.integrity_errors),
        "rtl_status_flags": {"rsp_overflow": r.sts_ovf, "bank_protocol": r.sts_proto},
    }
    # queue occupancy (per-cycle sampled)
    qh = r.queue_hist
    tot = np.asarray(qh["outstanding_total"], dtype=float)
    if tot.sum() > 0:
        m["outstanding_mean"] = float((np.arange(len(tot)) * tot).sum() / tot.sum())
        m["outstanding_max"] = int(np.nonzero(tot)[0].max())
    tk = np.asarray(qh["tracker"], dtype=float)
    m["tracker_occupancy_mean_per_bank"] = [float((np.arange(tk.shape[1]) * row).sum() / row.sum()) if row.sum() else 0.0 for row in tk]
    m["tracker_occupancy_max_per_bank"] = [int(np.nonzero(row)[0].max()) if row.sum() else 0 for row in tk]
    rf = np.asarray(qh["rsp_fifo"], dtype=float)
    m["rsp_fifo_occupancy_mean"] = float((np.arange(len(rf)) * rf).sum() / rf.sum()) if rf.sum() else 0.0
    # distribution of per-cycle bank concurrency (how many banks were busy issuing each cycle)
    # derived from accesses/cycle: histogram via the trace is optional; use counters only here
    ceil = analytical_ceilings(p, active_masters, workload)
    m["analytical"] = ceil
    m["efficiency_vs_peak"] = m["request_throughput_txn_per_cycle"] / ceil["peak_txn_per_cycle"] if ceil["peak_txn_per_cycle"] else 0.0
    m["efficiency_vs_array_ceiling"] = m["useful_bytes_per_cycle"] / ceil["array_peak_bytes_per_cycle"] if ceil["array_peak_bytes_per_cycle"] else 0.0
    if clock_mhz:
        m["assumed_clock_mhz"] = clock_mhz
        m["useful_MB_per_s_at_assumed_clock"] = m["useful_bytes_per_cycle"] * clock_mhz
        m["clock_note"] = "ASSUMED clock: derived MB/s are not measured or timing-closed figures"
    # activity (parameter-free proxies for the energy axis; NOT energies)
    stored_bits = p.data_width
    m["activity"] = {
        "label": "simulated",
        "array_accesses": int(sum(bank_acc)),
        "array_bit_activations": int(sum(bank_acc)) * stored_bits,
        "array_bit_activations_per_useful_byte": (int(sum(bank_acc)) * stored_bits / useful) if useful else float("nan"),
        "bank_busy_cycles": int(sum(bank_busy)),
        "data_bus_toggles": data_bus_toggles(r),
    }
    return m


def data_bus_toggles(r: RunResult) -> int:
    """Bit toggles on the per-bank write-data input in issue order (switching-activity proxy)."""
    p, tx = r.params, r.tx
    last = [0] * p.num_banks
    tot = 0
    order = sorted(range(len(tx)), key=lambda i: tx.accept[i])
    for i in order:
        if tx.we[i] and tx.bank[i] >= 0:
            b = tx.bank[i]
            tot += bin(last[b] ^ tx.wdata[i]).count("1")
            last[b] = tx.wdata[i]
    return tot
