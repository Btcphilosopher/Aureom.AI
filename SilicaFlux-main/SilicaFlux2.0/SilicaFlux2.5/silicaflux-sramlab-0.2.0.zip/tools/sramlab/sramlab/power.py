"""Power / energy provenance: parameter-free ACTIVITY always, energy ONLY from a validated, condition-stamped profile.

Principles (brief section 13)
-----------------------------
* No package contains SRAM energy-per-access data.  This module therefore ships **no numeric defaults**: an energy
  profile is supplied by the user (library / spice / datasheet / measurement / assumption), validated here, and every
  entry carries value, unit, source, provenance and the conditions (V, T, corner, macro) it is valid for.
* :func:`energy_report` always returns the parameter-free activity figures (``simulated``: access counts, array
  bit-activations, bank busy/idle cycles, data-bus toggles, ECC read-modify-write amplification when the run provides
  it).  Energy values appear only when the profile covers every needed term; otherwise they are ``unavailable``.
* The five sections are kept separate and never summed together: ``analytical_energy``, ``activity_based_estimate``,
  ``fpga_vendor_estimate``, ``asic_library_estimate``, ``hardware_measurement``.
* A profile is applied at the conditions it states; applying it at other conditions is refused unless the caller
  explicitly allows it, and then the result carries a warning.  Nothing is ever labelled ``measured`` unless a
  user-supplied measurement file declares ``"provenance": "measured"``.
* A tiny Liberty reader (:func:`liberty_cell_power`) reads ``area`` / ``cell_leakage_power`` / ``leakage_power`` states /
  ``internal_power`` tables of ONE named cell.  It is validated against the Nangate45 library (the cell leakage equals the
  mean of its state-dependent leakage values for all 126 cells that have them).  ``internal_power`` tables are returned
  RAW: their energy unit is derived by the consuming tool, it is not converted here, and no per-access SRAM energy is
  inferred from them.
"""
from __future__ import annotations

import json
import math
import os
import re

from . import tech
from .config import normalise
from .provenance import tag, unavailable

try:  # optional
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None

PROFILE_SCHEMA = "sramlab/energy-profile/1"
PROVENANCES = ("library", "spice", "datasheet", "measurement", "assumption")
ENERGY_UNITS = {"fJ": 1e-15, "pJ": 1e-12, "nJ": 1e-9, "uJ": 1e-6, "mJ": 1e-3, "J": 1.0}
POWER_UNITS = {"pW": 1e-12, "nW": 1e-9, "uW": 1e-6, "mW": 1e-3, "W": 1.0}
CONDITION_KEYS = ("voltage_v", "temperature_c", "corner", "macro")
# entry -> (quantity kind, allowed 'per' values)
ENTRIES = {
    "read": ("energy", ("macro_access", "bank_access", "bit_activation")),
    "write": ("energy", ("macro_access", "bank_access", "bit_activation")),
    "idle": ("energy", ("macro_cycle", "bank_cycle")),
    "leakage": ("power", ("macro", "bank", "bit")),
}


class EnergyProfileError(ValueError):
    """An energy profile / measurement file is incomplete or inconsistent; ``.problems`` lists every defect."""

    def __init__(self, problems):
        if isinstance(problems, str):
            problems = [problems]
        self.problems = list(problems)
        super().__init__("invalid energy profile: " + "; ".join(self.problems))


# ---------------------------------------------------------------------------------------------- profile
def _num(x) -> bool:
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def validate_energy_profile(d: dict) -> list[str]:
    """Every problem with a profile dict (empty list = valid).  Messages name the entry and the field."""
    errs: list[str] = []
    if not isinstance(d, dict):
        return ["profile must be a mapping"]
    ent = d.get("entries")
    if not isinstance(ent, dict) or not ent:
        return ["missing 'entries' mapping (read / write / idle / leakage)"]
    for name in ent:
        if name not in ENTRIES:
            errs.append(f"entries.{name}: unknown entry (allowed: {sorted(ENTRIES)})")
    for name, (kind, pers) in ENTRIES.items():
        e = ent.get(name)
        if e is None:
            continue                       # a profile may cover only some terms; energy_report says which are missing
        w = f"entries.{name}"
        if not isinstance(e, dict):
            errs.append(f"{w}: must be a mapping")
            continue
        v = e.get("value")
        if not _num(v) or v < 0:
            errs.append(f"{w}.value: missing or not a finite non-negative number (got {v!r})")
        u = e.get("unit")
        units = ENERGY_UNITS if kind == "energy" else POWER_UNITS
        if u not in units:
            errs.append(f"{w}.unit: {u!r} is not a known {kind} unit (allowed: {sorted(units)})")
        if not (isinstance(e.get("source"), str) and e["source"].strip()):
            errs.append(f"{w}.source: missing (where does this number come from? file, table, page, report)")
        pv = e.get("provenance")
        if pv not in PROVENANCES:
            errs.append(f"{w}.provenance: {pv!r} must be one of {PROVENANCES}")
        if e.get("per") not in pers:
            errs.append(f"{w}.per: {e.get('per')!r} must be one of {pers} (what one unit of the value refers to)")
        c = e.get("conditions")
        if not isinstance(c, dict) or not c:
            errs.append(f"{w}.conditions: missing (voltage_v, temperature_c, corner, macro are all required)")
        else:
            for k in CONDITION_KEYS:
                if c.get(k) in (None, ""):
                    errs.append(f"{w}.conditions.{k}: missing")
            if "voltage_v" in c and c["voltage_v"] not in (None, "") and not _num(c["voltage_v"]):
                errs.append(f"{w}.conditions.voltage_v: must be a number in volts")
            if "temperature_c" in c and c["temperature_c"] not in (None, "") and not _num(c["temperature_c"]):
                errs.append(f"{w}.conditions.temperature_c: must be a number in degrees C")
    if not any(n in ent for n in ENTRIES):
        errs.append("no recognised entry (read / write / idle / leakage)")
    return errs


def load_energy_profile(path_or_dict) -> dict:
    """Load + validate an energy profile (JSON, or YAML if PyYAML is importable).  Raises :class:`EnergyProfileError`
    listing every defect.  Adds ``value_si`` (J or W) to each entry.  Nothing is defaulted."""
    if isinstance(path_or_dict, dict):
        try:
            d, where = json.loads(json.dumps(path_or_dict)), "<dict>"
        except (TypeError, ValueError) as e:
            raise EnergyProfileError(f"profile is not JSON-serialisable ({e})") from e
    else:
        if not isinstance(path_or_dict, (str, os.PathLike)):
            raise EnergyProfileError("profile must be a mapping or a path to a JSON/YAML file")
        where = os.fspath(path_or_dict)
        with open(where, "r", encoding="utf-8") as fh:
            text = fh.read()
        if where.lower().endswith((".yaml", ".yml")):
            if yaml is None:
                raise EnergyProfileError(f"{where}: PyYAML is not installed; supply JSON")
            d = yaml.safe_load(text)
        else:
            try:
                d = json.loads(text)
            except json.JSONDecodeError as e:
                raise EnergyProfileError(f"{where}: not valid JSON ({e})") from e
    errs = validate_energy_profile(d)
    if errs:
        raise EnergyProfileError([f"{where}: {e}" for e in errs])
    for name, e in d["entries"].items():
        kind = ENTRIES[name][0]
        e["value_si"] = e["value"] * (ENERGY_UNITS if kind == "energy" else POWER_UNITS)[e["unit"]]
        e["kind"] = kind
    d.setdefault("schema", PROFILE_SCHEMA)
    d["_where"] = where
    return d


# ---------------------------------------------------------------------------------------------- activity
def _metrics(run_metrics: dict) -> dict:
    m = run_metrics.get("metrics") if isinstance(run_metrics.get("metrics"), dict) else run_metrics
    return m


def activity_figures(run_metrics: dict, cfg: dict | None = None) -> dict:
    """Parameter-free activity figures from a run-metrics dict (``sramlab.metrics.compute``).  Label ``simulated``.

    Never needs an energy value.  ECC read-modify-write amplification needs a partial-write count in the run metrics;
    the cycle model has none, so it is ``unavailable`` unless the run provides ``partial_writes`` /
    ``activity.rmw_accesses``."""
    m = _metrics(run_metrics)
    a = m.get("activity") or {}
    src = "run metrics (cycle model, verified against the RTL)"
    cyc = m.get("cycles")
    bank_acc = list(m.get("bank_accesses") or [])
    nb = len(bank_acc) or None
    accesses = a.get("array_accesses", sum(bank_acc) if bank_acc else None)
    out: dict = {"label": "simulated", "source": src}

    def T(v, name, unit=None):
        return tag(v, "simulated", f"{src}: {name}", **({"unit": unit} if unit else {})) if v is not None else \
            unavailable(f"run metrics carry no {name}")

    out["cycles"] = T(cyc, "cycles", "cycles")
    out["reads"] = T(m.get("reads"), "reads", "accesses")
    out["writes"] = T(m.get("writes"), "writes", "accesses")
    out["array_accesses"] = T(accesses, "array_accesses", "accesses")
    stored = None
    if cfg is not None:
        c = normalise(cfg)
        ww = c["memory"]["word_width_bits"]
        stored = tech.secded_stored_bits(ww) if c["memory"]["ecc"] == "secded" else ww
    if accesses is not None and stored is not None:
        out["array_bit_activations"] = tag(accesses * stored, "simulated", f"{src}: array_accesses x stored word bits ({stored})",
                                           unit="bit-activations")
    else:
        out["array_bit_activations"] = T(a.get("array_bit_activations"), "array_bit_activations", "bit-activations")
    out["array_bit_activations_per_useful_byte"] = T(a.get("array_bit_activations_per_useful_byte"),
                                                     "array_bit_activations_per_useful_byte")
    out["bank_busy_cycles"] = T(a.get("bank_busy_cycles"), "bank_busy_cycles", "bank-cycles")
    if cyc is not None and nb and accesses is not None:
        out["bank_idle_cycles"] = tag(nb * cyc - accesses, "simulated",
                                      f"{src}: banks x cycles - array_accesses (a bank issues at most one access per cycle)",
                                      unit="bank-cycles")
    else:
        out["bank_idle_cycles"] = unavailable("needs cycles and per-bank access counts")
    out["data_bus_toggles"] = T(a.get("data_bus_toggles"), "data_bus_toggles", "bit-toggles")
    out["bank_accesses"] = T(bank_acc or None, "bank_accesses")
    pw = m.get("partial_writes", a.get("partial_writes", a.get("rmw_accesses")))
    if cfg is not None and normalise(cfg)["memory"]["ecc"] == "secded":
        if pw is not None and accesses:
            out["ecc_rmw_amplification"] = tag((accesses + pw) / accesses, "simulated",
                                               f"{src}: (accesses + partial-write RMW read accesses) / accesses",
                                               partial_writes=pw)
        else:
            out["ecc_rmw_amplification"] = unavailable(
                "ECC is on but the run metrics carry no partial-write count (the cycle model has no ECC RMW; see the ECC study)")
    else:
        out["ecc_rmw_amplification"] = tag(1.0, "analytical", "ECC disabled: no read-modify-write", ) if cfg is not None else \
            unavailable("no config supplied")
    if m.get("reads") is not None and m.get("writes") is not None and accesses is not None and m["reads"] + m["writes"] != accesses:
        out["note"] = (f"reads+writes ({m['reads'] + m['writes']}) != array_accesses ({accesses}): "
                       "responses that never reached an array (errors) or in-flight accesses at the end of the run")
    return out


# ---------------------------------------------------------------------------------------------- energy arithmetic
def _same(a, b) -> bool:
    if isinstance(a, str) or isinstance(b, str):
        return str(a).strip().lower() == str(b).strip().lower()
    return abs(float(a) - float(b)) <= 1e-9 * max(1.0, abs(float(a)), abs(float(b)))


def _cond_mismatch(profile_cond: dict, requested: dict | None) -> list[str]:
    if not requested:
        return []
    out = []
    for k in CONDITION_KEYS:
        if requested.get(k) not in (None, "") and not _same(profile_cond.get(k), requested[k]):
            out.append(f"{k}: profile {profile_cond.get(k)!r} vs requested {requested[k]!r}")
    return out


def _multipliers(cfg: dict | None) -> dict:
    """What 'per macro / per bank / per bit' multiplies by for this configuration (None when it cannot be known)."""
    out = {"banks": None, "stored_word": None, "macro_cols": None, "macros_per_bank": None}
    if cfg is None:
        return out
    c = normalise(cfg)
    mem = c["memory"]
    ww = mem["word_width_bits"]
    stored = tech.secded_stored_bits(ww) if mem["ecc"] == "secded" else ww
    out.update({"banks": mem["banks"], "stored_word": stored, "stored_bits_total": mem["banks"] * mem["bank_depth_words"] * stored})
    if c["physical"]["backend"] == "asic_macro" and c["physical"].get("macro"):
        try:
            t = tech.tile_memory(mem["bank_depth_words"] * stored, stored, c["physical"]["macro"])
            out["macro_cols"], out["macros_per_bank"], out["macro_name"] = t["cols"], t["instances"], t["macro_name"]
        except tech.TechError:
            pass
    return out


def _term(entry: dict, count, per_mult, what: str, conds_warn: list[str]) -> dict:
    """energy (J) or power (W) of one term: count x value x multiplier; tagged with the profile provenance."""
    if per_mult is None:
        return unavailable(f"{what}: per={entry['per']!r} needs a configuration/macro tiling that was not supplied")
    return {"value": count * entry["value_si"] * per_mult, "entry_provenance": entry["provenance"],
            "source": entry["source"], "conditions": entry["conditions"], "per": entry["per"],
            "formula": f"{count} x {entry['value']} {entry['unit']} x {per_mult}"}


def _label_for(entries: list[dict]) -> str:
    """Counts are simulated; if any coefficient is an assumption the whole figure is an assumed illustration."""
    return "assumed" if any(e["provenance"] == "assumption" for e in entries) else "simulated"


def _activity_based(act: dict, profile: dict | None, cfg: dict | None, clock_mhz: float | None,
                    operating_conditions: dict | None, allow_condition_mismatch: bool) -> dict:
    if profile is None:
        return unavailable("no validated energy profile => no energy (activity figures are still reported)",
                           needed=sorted(ENTRIES))
    ent = profile["entries"]
    warnings: list[str] = []
    mult = _multipliers(cfg)
    # --- conditions
    for name, e in ent.items():
        mm = _cond_mismatch(e["conditions"], operating_conditions)
        if cfg is not None and e["conditions"].get("macro") and mult.get("macro_name") and \
                not _same(e["conditions"]["macro"], mult["macro_name"]):
            mm.append(f"macro: profile {e['conditions']['macro']!r} vs configuration {mult['macro_name']!r}")
        if mm:
            if not allow_condition_mismatch:
                return unavailable(
                    f"profile entry {name!r} is valid only at its stated conditions; requested differ: " + "; ".join(mm)
                    + " (pass allow_condition_mismatch=True to apply it anyway, with a warning)", conditions_profile=e["conditions"])
            warnings.append(f"entry {name!r} applied at different conditions than stated: " + "; ".join(mm))

    def cnt(key):
        v = act.get(key)
        return v.get("value") if isinstance(v, dict) else None

    reads, writes = cnt("reads"), cnt("writes")
    idle, cyc = cnt("bank_idle_cycles"), cnt("cycles")
    terms: dict = {}
    used: list[dict] = []
    missing = []

    def per_mult(e, kind):
        p = e["per"]
        if p == "bank_access" or p == "bank_cycle" or p == "bank":
            return 1 if kind != "leakage" else mult["banks"]
        if p == "macro_access":
            return mult["macro_cols"]
        if p == "macro_cycle":
            return mult["macros_per_bank"]
        if p == "bit_activation":
            return mult["stored_word"]
        if p == "macro":
            return (mult["macros_per_bank"] * mult["banks"]) if mult["macros_per_bank"] and mult["banks"] else None
        if p == "bit":
            return mult.get("stored_bits_total")
        return None

    for name, count, key in (("read", reads, "reads"), ("write", writes, "writes"), ("idle", idle, "bank_idle_cycles")):
        if count is None:
            terms[name + "_energy_J"] = unavailable(f"run metrics carry no {key}")
            missing.append(name)
        elif name in ent:
            t = _term(ent[name], count, per_mult(ent[name], name), name, warnings)
            terms[name + "_energy_J"] = t
            used.append(ent[name])
            if t.get("value") is None:
                missing.append(name)
        else:
            terms[name + "_energy_J"] = unavailable(f"profile has no '{name}' entry")
            missing.append(name)
    # leakage power / energy
    if "leakage" in ent:
        e = ent["leakage"]
        lm = per_mult(e, "leakage")
        if lm is None:
            terms["leakage_power_W"] = unavailable("per-unit leakage needs a configuration / macro tiling that was not supplied")
            missing.append("leakage")
        else:
            terms["leakage_power_W"] = {"value": e["value_si"] * lm, "entry_provenance": e["provenance"], "source": e["source"],
                                        "conditions": e["conditions"], "per": e["per"]}
            used.append(e)
            if clock_mhz and cyc is not None:
                tsec = cyc / (clock_mhz * 1e6)
                terms["leakage_energy_J"] = {"value": e["value_si"] * lm * tsec, "entry_provenance": e["provenance"],
                                             "time_s": tsec, "clock_mhz": clock_mhz,
                                             "note": "time = cycles / ASSUMED clock"}
            else:
                terms["leakage_energy_J"] = unavailable("needs a clock frequency (physical.clock_mhz is an assumption) and cycles")
                missing.append("leakage_energy")
    else:
        terms["leakage_power_W"] = unavailable("profile has no 'leakage' entry")
        terms["leakage_energy_J"] = unavailable("profile has no 'leakage' entry")
        missing.append("leakage")
    label = _label_for(used) if used else "simulated"
    # subtotal of the dynamic terms and total only when COMPLETE
    dyn_parts = [terms.get(k) for k in ("read_energy_J", "write_energy_J", "idle_energy_J")]
    dyn_ok = all(isinstance(p, dict) and p.get("value") is not None for p in dyn_parts)
    out = {"label": label, "profile": profile.get("id") or profile.get("_where"), "terms": terms, "warnings": warnings,
           "coefficient_provenance": sorted({e["provenance"] for e in used}),
           "basis": "simulated activity counts x profile coefficients (never 'measured')"}
    if label == "assumed":
        out["warning_assumed"] = ("at least one coefficient has provenance 'assumption': these figures illustrate an "
                                  "assumption, they are not a result")
    if dyn_ok:
        out["dynamic_energy_J"] = tag(sum(p["value"] for p in dyn_parts), label, "read + write + idle terms", unit="J")
    else:
        out["dynamic_energy_J"] = unavailable("not every dynamic term is covered by the profile / run: missing "
                                              + ", ".join(sorted(set(missing) & {"read", "write", "idle"})))
    lk = terms.get("leakage_energy_J")
    if dyn_ok and isinstance(lk, dict) and lk.get("value") is not None:
        tot = out["dynamic_energy_J"]["value"] + lk["value"]
        out["total_energy_J"] = tag(tot, label, "dynamic + leakage (all four profile terms and a clock)", unit="J")
        uh = act.get("useful_bytes")
        useful = uh.get("value") if isinstance(uh, dict) else None
        if useful:
            out["energy_per_useful_byte_J"] = tag(tot / useful, label, "total / useful bytes", unit="J/B")
    else:
        out["total_energy_J"] = unavailable("energy is reported only when the profile covers every needed term "
                                            f"(read, write, idle, leakage + clock); missing: {sorted(set(missing))}")
    return out


# ---------------------------------------------------------------------------------------------- analytical section
def _analytical(act: dict, cfg: dict | None, profile: dict | None) -> dict:
    out: dict = {"label": "analytical",
                 "note": "closed-form, workload-independent relations; absolute energies need a profile (section "
                         "activity_based_estimate) and are never defaulted"}
    if cfg is not None:
        c = normalise(cfg)
        ww = c["memory"]["word_width_bits"]
        stored = tech.secded_stored_bits(ww) if c["memory"]["ecc"] == "secded" else ww
        out["bit_activation_ratio_vs_no_ecc"] = tag(stored / ww, "analytical", f"{stored}/{ww} stored bits activated per access")
        out["relations"] = [
            "E_dynamic = N_read*E_read + N_write*E_write + N_idle_bank_cycles*E_idle   (E_x from a validated profile)",
            "E_leakage = P_leak * cycles / f_clk   (f_clk is an assumption unless a timing report supports it)",
            "ECC partial write = read + write of the whole stored word (RMW): accesses x (1 + partial-write fraction)"]
    else:
        out["bit_activation_ratio_vs_no_ecc"] = unavailable("no config supplied")
    out["absolute_energy"] = unavailable("no validated energy profile" if profile is None else
                                         "see activity_based_estimate (absolute energy needs simulated counts)")
    return out


# ---------------------------------------------------------------------------------------------- vendor / liberty / measurement
_VIVADO_TOTAL = re.compile(r"^\|\s*Total On-Chip Power \(W\)\s*\|\s*([0-9.]+)\s*\|", re.M)
_VIVADO_DYN = re.compile(r"^\|\s*Dynamic \(W\)\s*\|\s*([0-9.]+)\s*\|", re.M)
_VIVADO_STAT = re.compile(r"^\|\s*Device Static \(W\)\s*\|\s*([0-9.]+)\s*\|", re.M)
_VIVADO_CONF = re.compile(r"^\|\s*Confidence Level\s*\|\s*(\w+)\s*\|", re.M)


def fpga_vendor_estimate(report_path: str | None) -> dict:
    """FPGA vendor power-estimator report.  ``unavailable`` unless a file is given.  A given file is hashed and is parsed
    ONLY if it is a recognisable Vivado ``report_power`` summary whose numbers are internally consistent (dynamic + static
    == total); anything else is recorded (hash/size) with the values left unavailable.  Parser validation: internal
    consistency on a synthetic fixture only - no real vendor report was available in this tree."""
    if not report_path:
        return unavailable("no vendor power report supplied (e.g. Vivado report_power output); none exists in this tree")
    p = os.fspath(report_path)
    if not os.path.isfile(p):
        return unavailable(f"vendor report not found: {p}")
    with open(p, "r", encoding="utf-8", errors="replace") as fh:
        text = fh.read()
    meta = {"file": p, "sha256": tech.sha256_file(p), "bytes": os.path.getsize(p)}
    mt, md, ms, mc = (r.search(text) for r in (_VIVADO_TOTAL, _VIVADO_DYN, _VIVADO_STAT, _VIVADO_CONF))
    if not (mt and md and ms and "Power Report" in text):
        return {**unavailable("file is not a recognised Vivado report_power summary: nothing parsed", **meta)}
    tot, dyn, st = float(mt.group(1)), float(md.group(1)), float(ms.group(1))
    if abs(dyn + st - tot) > 0.0015:
        return {**unavailable(f"report is internally inconsistent (dynamic {dyn} + static {st} != total {tot}): rejected", **meta)}
    conf = mc.group(1) if mc else "unknown"
    src = f"vendor report {os.path.basename(p)} (sha256 {meta['sha256'][:16]}...)"
    return {"label": "synthesized", "tool": "Vivado report_power (vendor estimator, NOT a measurement)", "confidence_level": conf,
            "total_on_chip_power_W": tag(tot, "synthesized", src, unit="W", confidence=conf),
            "dynamic_W": tag(dyn, "synthesized", src, unit="W"), "device_static_W": tag(st, "synthesized", src, unit="W"),
            **meta, "parser_validation": "internal-consistency check only (no real vendor report was available)"}


def load_measurement(path: str) -> dict:
    """User-supplied hardware measurement file.  It must say ``"provenance": "measured"`` itself; otherwise rejected."""
    with open(path, "r", encoding="utf-8") as fh:
        d = json.load(fh)
    errs = []
    for k in ("provenance", "quantity", "value", "unit", "instrument", "conditions", "date"):
        if d.get(k) in (None, ""):
            errs.append(f"missing '{k}'")
    if d.get("provenance") != "measured":
        errs.append("file does not declare \"provenance\": \"measured\" (only a measurement file may produce a measured label)")
    if d.get("unit") not in {**ENERGY_UNITS, **POWER_UNITS}:
        errs.append(f"unit {d.get('unit')!r} unknown")
    if not _num(d.get("value")):
        errs.append("value is not a finite number")
    if errs:
        raise EnergyProfileError([f"{path}: {e}" for e in errs])
    return d


def hardware_measurement(measurement_path: str | None) -> dict:
    if not measurement_path:
        return unavailable("no user-supplied measurement file: no SilicaFlux silicon / FPGA measurement exists")
    try:
        d = load_measurement(measurement_path)
    except (EnergyProfileError, OSError, json.JSONDecodeError) as e:
        return unavailable(f"measurement file rejected: {e}")
    return tag(d["value"], "measured", f"user-supplied measurement file {os.path.basename(measurement_path)} "
               f"(sha256 {tech.sha256_file(measurement_path)[:16]}...)", unit=d["unit"], quantity=d["quantity"],
               instrument=d["instrument"], conditions=d["conditions"], date=d["date"])


# ---------------------------------------------------------------------------------------------- liberty reader
def _strip_comments(s: str) -> str:
    return re.sub(r"/\*.*?\*/", "", s, flags=re.S)


def _block_from(txt: str, start: int) -> str:
    """Balanced-brace group text beginning at the '{' found at/after ``start`` (quotes and comments respected)."""
    i = txt.index("{", start)
    depth, j, n, in_str = 0, i, len(txt), False
    while j < n:
        ch = txt[j]
        if in_str:
            if ch == "\\":
                j += 1
            elif ch == '"':
                in_str = False
        elif ch == '"':
            in_str = True
        elif ch == "/" and txt.startswith("/*", j):
            j = txt.index("*/", j) + 1
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return txt[i:j + 1]
        j += 1
    raise ValueError("unbalanced braces in liberty group")


def _floats(s: str) -> list[float]:
    return [float(x) for x in re.findall(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", s)]


def liberty_header(text_head: str) -> dict:
    """Units and nominal conditions from the library-level attributes (read from the first part of the file)."""
    t = _strip_comments(text_head)
    g = lambda pat: (re.search(pat, t) or [None, None])[1]
    cl = re.search(r"capacitive_load_unit\s*\(\s*([0-9.]+)\s*,\s*(\w+)\s*\)", t)
    return {"library": g(r"library\s*\(\s*\"?([\w.$]+)\"?\s*\)"), "time_unit": g(r'time_unit\s*:\s*"([^"]+)"'),
            "leakage_power_unit": g(r'leakage_power_unit\s*:\s*"([^"]+)"'), "voltage_unit": g(r'voltage_unit\s*:\s*"([^"]+)"'),
            "current_unit": g(r'current_unit\s*:\s*"([^"]+)"'),
            "capacitive_load_unit": f"{cl.group(1)}{cl.group(2)}" if cl else None,
            "nom_voltage": (lambda v: float(v) if v else None)(g(r"nom_voltage\s*:\s*([0-9.]+)")),
            "nom_temperature": (lambda v: float(v) if v else None)(g(r"nom_temperature\s*:\s*([0-9.]+)")),
            "nom_process": (lambda v: float(v) if v else None)(g(r"nom_process\s*:\s*([0-9.]+)"))}


_LEAK_UNITS = {"1pW": 1e-12, "1nW": 1e-9, "1uW": 1e-6, "1mW": 1e-3, "1W": 1.0}


def liberty_cell_power(path: str, cell: str) -> dict:
    """Read ``area``, ``cell_leakage_power``, state-dependent ``leakage_power`` and ``internal_power`` tables of ONE cell.

    Raises ``KeyError`` for an unknown cell.  Leakage is converted to W using the library's ``leakage_power_unit``;
    ``internal_power`` tables are returned RAW (no unit conversion).  ``leakage_state_mean`` is returned so the caller
    can check the library's own consistency (cell_leakage_power == mean of the states for the Nangate45 cells)."""
    with open(path, "r", encoding="latin-1") as fh:
        txt = fh.read()
    hdr = liberty_header(txt[:20000])
    m = re.search(r"^\s*cell\s*\(\s*\"?" + re.escape(cell) + r"\"?\s*\)\s*\{", txt, flags=re.M)
    if not m:
        raise KeyError(f"cell {cell!r} not found in {os.path.basename(path)}")
    blk = _strip_comments(_block_from(txt, m.start()))
    area = re.search(r"\barea\s*:\s*([0-9.eE+-]+)\s*;", blk)
    clp = re.search(r"cell_leakage_power\s*:\s*([0-9.eE+-]+)\s*;", blk)
    # state-dependent leakage groups: leakage_power () { when : "..."; value : x; }
    states = []
    for sm in re.finditer(r"leakage_power\s*\(\s*\)\s*\{", blk):
        sb = _block_from(blk, sm.start())
        w = re.search(r'when\s*:\s*"([^"]*)"', sb)
        v = re.search(r"value\s*:\s*([0-9.eE+-]+)\s*;", sb)
        if v:
            states.append({"when": w.group(1) if w else None, "value": float(v.group(1))})
    unit = _LEAK_UNITS.get((hdr["leakage_power_unit"] or "").replace(" ", ""))
    out = {"cell": cell, "library": hdr["library"], "library_sha256": tech.sha256_file(path), "header": hdr,
           "area": float(area.group(1)) if area else None,
           "cell_leakage_power_raw": float(clp.group(1)) if clp else None,
           "cell_leakage_power_W": (float(clp.group(1)) * unit) if (clp and unit) else None,
           "leakage_states": states,
           "leakage_state_mean_raw": (sum(s["value"] for s in states) / len(states)) if states else None,
           "internal_power": [], "internal_power_unit": "RAW liberty values: the energy unit is derived by the consuming tool "
                                                        "from voltage/current/time units; NOT converted here"}
    for pm in re.finditer(r"\bpin\s*\(\s*\"?([\w\[\]]+)\"?\s*\)\s*\{", blk):
        pb = _block_from(blk, pm.start())
        for im in re.finditer(r"internal_power\s*\(\s*\)\s*\{", pb):
            ib = _block_from(pb, im.start())
            rp = re.search(r'related_pin\s*:\s*"([^"]*)"', ib)
            wh = re.search(r'\bwhen\s*:\s*"([^"]*)"', ib)
            tables = {}
            for tm in re.finditer(r"\b(rise_power|fall_power|power)\s*\(\s*\"?([\w]+)\"?\s*\)\s*\{", ib):
                tb = _block_from(ib, tm.start())
                i1 = re.search(r'index_1\s*\(\s*"([^"]*)"\s*\)', tb)
                i2 = re.search(r'index_2\s*\(\s*"([^"]*)"\s*\)', tb)
                vals = re.search(r"values\s*\((.*?)\)\s*;", tb, flags=re.S)
                rows = [_floats(r) for r in re.findall(r'"([^"]*)"', vals.group(1))] if vals else []
                tables[tm.group(1)] = {"template": tm.group(2), "index_1": _floats(i1.group(1)) if i1 else [],
                                       "index_2": _floats(i2.group(1)) if i2 else [], "values": rows}
            out["internal_power"].append({"pin": pm.group(1), "related_pin": rp.group(1) if rp else None,
                                          "when": wh.group(1) if wh else None, "tables": tables})
    return out


def asic_library_estimate(liberty: dict | None) -> dict:
    """ASIC library section.  ``liberty = {"path": ..., "cell": ...}`` of a MACRO/cell Liberty.  Reports the cell's
    leakage power (library numbers at the library's own nominal conditions) and the raw internal-power table summary;
    per-access energy of an SRAM macro is NOT inferred from ``internal_power`` (mapping not validated)."""
    if not liberty:
        return unavailable("no Liberty for the SRAM macro supplied: the vendored manifests list macro Liberty views but "
                           "the .lib files are not part of this tree (library needed for internal_power / leakage tables)")
    try:
        r = liberty_cell_power(liberty["path"], liberty["cell"])
    except (KeyError, OSError, ValueError) as e:
        return unavailable(f"liberty could not be read: {e}")
    h = r["header"]
    cond = {"voltage_v": h["nom_voltage"], "temperature_c": h["nom_temperature"], "process": h["nom_process"]}
    src = f"{os.path.basename(liberty['path'])} sha256 {r['library_sha256'][:16]}... cell {r['cell']}"
    out = {"label": "analytical", "data_provenance": "library", "cell": r["cell"], "conditions": cond,
           "area_um2": tag(r["area"], "analytical", src, unit="um^2") if r["area"] is not None else unavailable("no area"),
           "leakage_power_W": (tag(r["cell_leakage_power_W"], "analytical", src, unit="W", conditions=cond)
                               if r["cell_leakage_power_W"] is not None else unavailable("no cell_leakage_power / unit")),
           "internal_power_arcs": len(r["internal_power"]),
           "energy_per_access": unavailable("per-access energy of an SRAM macro is not inferred from internal_power tables "
                                            "(table-to-event mapping and unit not validated); supply an energy profile "
                                            "with source=library for the macro")}
    return out


# ---------------------------------------------------------------------------------------------- the report
def energy_report(run_metrics: dict, profile: dict | None = None, *, cfg: dict | None = None,
                  clock_mhz: float | None = None, operating_conditions: dict | None = None,
                  allow_condition_mismatch: bool = False, vendor_report: str | None = None,
                  liberty: dict | None = None, measurement: str | None = None) -> dict:
    """Energy / power provenance report for one run.

    ``run_metrics``: ``sramlab.metrics.compute`` output.  ``profile``: a validated profile from
    :func:`load_energy_profile` (``None`` -> every energy value is ``unavailable``).  Always present: ``activity``
    (parameter-free, ``simulated``).  Separate sections: ``analytical_energy``, ``activity_based_estimate``,
    ``fpga_vendor_estimate``, ``asic_library_estimate``, ``hardware_measurement``."""
    if profile is not None and "entries" not in profile:
        raise EnergyProfileError("profile was not produced by load_energy_profile(): validate it first")
    if profile is not None and any("value_si" not in e for e in profile["entries"].values()):
        profile = load_energy_profile(profile)
    act = activity_figures(run_metrics, cfg)
    m = _metrics(run_metrics)
    if m.get("useful_bytes") is not None:
        act["useful_bytes"] = tag(m["useful_bytes"], "simulated", "run metrics: useful_bytes", unit="bytes")
    if clock_mhz is None and cfg is not None:
        clock_mhz = normalise(cfg)["physical"].get("clock_mhz")
    return {
        "label": "energy_report",
        "statement": ("activity figures are parameter-free (simulated); energy values exist only when a validated profile "
                      "covers every needed term; nothing here is measured unless a user-supplied measurement file says so"),
        "activity": act,
        "analytical_energy": _analytical(act, cfg, profile),
        "activity_based_estimate": _activity_based(act, profile, cfg, clock_mhz, operating_conditions, allow_condition_mismatch),
        "fpga_vendor_estimate": fpga_vendor_estimate(vendor_report),
        "asic_library_estimate": asic_library_estimate(liberty),
        "hardware_measurement": hardware_measurement(measurement),
        "assumed_clock_mhz": (tag(clock_mhz, "assumed", "physical.clock_mhz is an assumption", unit="MHz") if clock_mhz else
                              unavailable("no clock supplied: cycles only, no time-based quantities")),
    }
