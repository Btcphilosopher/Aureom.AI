"""Experiment runners shared by the CLI and the studies: single run, replicated benchmark, bank sweep, compare.

Layering (brief section 2): ``model`` = analytical ceilings (metrics.analytical_ceilings), ``simulation`` =
the verified cycle model, ``measured results`` = RTL runs (rtlcheck) and imported sibling-package RTL reports.
They are kept in separate result sections and never averaged together.
"""
from __future__ import annotations

import copy
import time

import numpy as np

from . import metrics, stats
from .config import controller_params, load_config, normalise, validate_config, ConfigError
from .sim.driver import run_scripts
from .sim.workloads import generate_scripts, make_ready


def run_once(cfg: dict, *, trace: bool = False, track_data: bool = True, rtl_check: bool = False):
    """One simulation of a validated config.  Returns (RunResult, metrics dict, rtl verdict | None)."""
    p = controller_params(cfg)
    wl = cfg["workload"]
    scripts = generate_scripts(p, wl)
    ready = make_ready(p, wl)
    rr = run_scripts(p, scripts, ready, trace=trace, track_data=track_data)
    m = metrics.compute(rr, clock_mhz=cfg["physical"].get("clock_mhz"), workload=wl["kind"])
    verdict = None
    if rtl_check:
        from . import rtlrun
        verdict = rtlrun.compare(p, scripts, ready, label=cfg.get("name", ""))
    return rr, m, verdict


def with_seed(cfg: dict, seed: int) -> dict:
    c = copy.deepcopy(cfg)
    c["workload"]["seed"] = int(seed)
    return c


def key_metrics(m: dict) -> dict:
    """Scalar metrics used for replication statistics and sweeps."""
    return {
        "throughput_txn_per_cycle": m["request_throughput_txn_per_cycle"],
        "useful_bytes_per_cycle": m["useful_bytes_per_cycle"],
        "conflict_rate_per_access": m["conflict_rate_per_access"],
        "bank_utilisation_mean": m["bank_utilisation_mean"],
        "read_latency_mean": m["read_latency_e2e"].get("mean", float("nan")),
        "read_latency_median": m["read_latency_e2e"].get("median", float("nan")),
        "read_latency_p95": m["read_latency_e2e"].get("p95", float("nan")),
        "read_latency_p99": m["read_latency_e2e"].get("p99", float("nan")),
        "read_latency_accept_mean": m["read_latency_response"].get("mean", float("nan")),
        "write_latency_mean": m["write_latency_e2e"].get("mean", float("nan")),
        "arbitration_delay_mean": m["arbitration_delay"].get("mean", float("nan")),
        "arbitration_delay_p95": m["arbitration_delay"].get("p95", float("nan")),
        "outstanding_mean": m.get("outstanding_mean", float("nan")),
        "efficiency_vs_peak": m["efficiency_vs_peak"],
        "bit_activations_per_useful_byte": m["activity"]["array_bit_activations_per_useful_byte"],
        "read_bytes_per_cycle": m["read_bytes_per_cycle"],
        "write_bytes_per_cycle": m["write_bytes_per_cycle"],
        "cycles": m["cycles"],
    }


def benchmark(cfg: dict, replications: int = 10, seed0: int | None = None) -> dict:
    """Replicated benchmark: independent seeds -> mean, Student-t 95% CI, percentile intervals."""
    seed0 = cfg["workload"]["seed"] if seed0 is None else seed0
    rows, lat_rep = [], []
    hist: dict[int, int] = {}
    first_m = None
    for r in range(replications):
        rr, m, _ = run_once(with_seed(cfg, seed0 + r), track_data=(r == 0))
        if first_m is None:
            first_m = m
        rows.append(key_metrics(m))
        tx = rr.tx
        a = np.asarray(tx.push) + 1 - np.asarray(tx.present)
        sel = a[(np.asarray(tx.we) == 0) & (np.asarray(tx.status) == 0)]
        lat_rep.append(sel)
        for v, c in zip(*np.unique(sel, return_counts=True)):
            hist[int(v)] = hist.get(int(v), 0) + int(c)
    summary = {}
    for k in rows[0]:
        vals = [row[k] for row in rows]
        summary[k] = stats.mean_ci(vals)
    summary["read_latency_p99_pooled"] = stats.pooled_percentile_ci(lat_rep, 99)
    # adequacy of the sample: replications needed for 2% relative half-width on throughput
    thr = summary["throughput_txn_per_cycle"]
    need = stats.required_replications(thr.get("std", 0.0), 0.02 * abs(thr["mean"])) if replications > 1 and thr["mean"] else None
    return {"label": "simulated", "replications": replications, "seeds": [seed0 + r for r in range(replications)],
            "summary": summary, "replications_needed_for_2pct_throughput_ci": need,
            "sample_adequate_for_2pct": (need is not None and replications >= need),
            "first_run_metrics": first_m, "per_replication": rows,
            "pooled_read_latency_e2e_histogram": dict(sorted(hist.items()))}


def sweep_banks(base: dict, banks=(2, 4, 8, 16), workloads=("rand_read", "mixed", "seq_read", "contention", "hotspot"),
                replications: int = 5, capacity_bytes: int | None = None, progress=None) -> dict:
    """Bank-count sweep at CONSTANT capacity (depth shrinks as banks grow) so only the organisation changes."""
    cap = capacity_bytes or base["memory"]["capacity_bytes"] or (base["memory"]["banks"] * base["memory"]["bank_depth_words"]
                                                                  * base["memory"]["word_width_bits"] // 8)
    rows = []
    for wl in workloads:
        for nb in banks:
            c = copy.deepcopy(base)
            c["memory"]["banks"] = nb
            c["memory"]["capacity_bytes"] = None
            c["memory"]["bank_depth_words"] = cap // (nb * c["memory"]["word_width_bits"] // 8)
            if isinstance(c["memory"]["read_latency"], list):
                c["memory"]["read_latency"] = c["memory"]["read_latency"][0]
            c["workload"]["kind"] = wl
            c["name"] = f"{base.get('name', 'sweep')}_{nb}b_{wl}"
            v = validate_config(c)
            if not v.ok:
                raise ConfigError(v.errors)
            if progress:
                progress(f"{wl} banks={nb}")
            b = benchmark(c, replications)
            s = b["summary"]
            ceil = b["first_run_metrics"]["analytical"]
            rows.append({
                "workload": wl, "banks": nb, "label": "simulated", "replications": replications,
                "throughput_txn_per_cycle": s["throughput_txn_per_cycle"], "useful_bytes_per_cycle": s["useful_bytes_per_cycle"],
                "read_latency_mean": s["read_latency_mean"], "read_latency_p99": s["read_latency_p99"],
                "conflict_rate_per_access": s["conflict_rate_per_access"], "bank_utilisation_mean": s["bank_utilisation_mean"],
                "arbitration_delay_mean": s["arbitration_delay_mean"], "efficiency_vs_peak": s["efficiency_vs_peak"],
                "bit_activations_per_useful_byte": s["bit_activations_per_useful_byte"],
                "read_bytes_per_cycle": s["read_bytes_per_cycle"], "write_bytes_per_cycle": s["write_bytes_per_cycle"],
                "latency_histogram": b["pooled_read_latency_e2e_histogram"],
                "conflict_cycle_fraction_per_bank": b["first_run_metrics"]["conflict_cycle_fraction_per_bank"],
                "bank_utilisation_per_bank": b["first_run_metrics"]["bank_utilisation"],
                "tracker_occupancy_mean_per_bank": b["first_run_metrics"]["tracker_occupancy_mean_per_bank"],
                "outstanding_mean": s["outstanding_mean"],
                "analytical_peak_txn_per_cycle": ceil["peak_txn_per_cycle"],
                "analytical_random_estimate_txn_per_cycle": ceil["random_access_estimate_txn_per_cycle"],
                "capacity_bytes": cap, "bank_depth_words": c["memory"]["bank_depth_words"],
            })
    return {"label": "simulated", "capacity_bytes": cap, "rows": rows,
            "note": "constant total capacity; more banks adds concurrency only where requests spread across banks; "
                    "hardware overhead (arbiters, trackers) grows with the bank count - see synth sweep"}


def compare(cfg_a: dict, cfg_b: dict, replications: int = 8) -> dict:
    a, b = benchmark(cfg_a, replications), benchmark(cfg_b, replications)
    out = {"a": cfg_a.get("name"), "b": cfg_b.get("name"), "metrics": {}}
    for k in ("throughput_txn_per_cycle", "useful_bytes_per_cycle", "read_latency_mean", "read_latency_p99",
              "conflict_rate_per_access", "arbitration_delay_mean", "bit_activations_per_useful_byte"):
        ma, mb = a["summary"][k], b["summary"][k]
        # Welch-style: non-overlap of 95% CIs -> "distinguishable"
        distinguishable = not (ma["lo"] <= mb["hi"] and mb["lo"] <= ma["hi"]) if ma.get("lo") == ma.get("lo") else None
        out["metrics"][k] = {"a": ma, "b": mb, "delta": mb["mean"] - ma["mean"],
                             "relative_delta": (mb["mean"] - ma["mean"]) / ma["mean"] if ma["mean"] else float("nan"),
                             "ci_distinguishable": distinguishable}
    return out


def timeline_trace(cfg: dict, ncycles: int = 160) -> dict:
    """Recorded cycle trace for the dashboard's transaction-timeline replay (a replay of a simulation, not a live system)."""
    p = controller_params(cfg)
    wl = cfg["workload"]
    rr = run_scripts(p, generate_scripts(p, wl), make_ready(p, wl), trace=True, fixed_cycles=ncycles)
    cyc = []
    for o in rr.trace:
        cyc.append({"t": o.cyc,
                    "m": [("a" if o.accepted[m] else ("w" if o.req_valid[m] else ".")) for m in range(p.num_masters)],
                    "g": o.granted_master, "r": [1 if o.transferred[m] else 0 for m in range(p.num_masters)],
                    "e": o.elig_count})
    return {"label": "simulated", "config": cfg.get("name"), "masters": p.num_masters, "banks": p.num_banks,
            "legend": {"a": "request accepted (= bank access issued)", "w": "request presented, waiting (lost arbitration / no credit)",
                       ".": "idle", "g": "master granted per bank (-1 = idle)", "r": "response transferred", "e": "eligible masters per bank"},
            "cycles": cyc, "note": "recorded simulation trace replayed in the browser"}
