"""External tool discovery with real version strings (recorded in every experiment record).

SRAMLab never pretends a tool ran: ``detect()`` returns ``None`` for a missing tool and callers
must report the corresponding result as 'not available' rather than substituting a model.
"""
from __future__ import annotations

import functools
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                      # tools/sramlab


def _run(cmd, timeout=60):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout + r.stderr).strip()
    except Exception:
        return None


@functools.lru_cache(maxsize=None)
def verilator() -> dict | None:
    exe = shutil.which("verilator") or shutil.which("verilator-cli")
    if not exe:
        return None
    out = _run([exe, "--version"]) or ""
    m = re.search(r"Verilator\s+([\w.\-]+)", out)
    ver = m.group(1) if m else out.splitlines()[0] if out else "unknown"
    # The pip Verilator wheel ships verilated.mk with an empty CFG_CXXFLAGS_PCH_I, which breaks the
    # C++ build with gcc; detect that precisely instead of guessing from the install path.
    pch_broken = False
    root = (_run([exe, "--getenv", "VERILATOR_ROOT"]) or "").strip().splitlines()
    mk = os.path.join(root[-1], "include", "verilated.mk") if root else ""
    if mk and os.path.exists(mk):
        with open(mk, errors="replace") as fh:
            pch_broken = re.search(r"^CFG_CXXFLAGS_PCH_I\s*=\s*$", fh.read(), re.M) is not None
    return {"exe": exe, "version": ver, "raw": out.splitlines()[0] if out else "", "pip_wheel": pch_broken}


@functools.lru_cache(maxsize=None)
def yosys() -> dict | None:
    for name in ("yosys", "yowasp-yosys"):
        exe = shutil.which(name)
        if exe:
            out = _run([exe, "-V"], timeout=180) or ""
            m = re.search(r"Yosys\s+([\w.+\-]+)", out)
            return {"exe": exe, "version": m.group(1) if m else out, "raw": out.splitlines()[-1] if out else ""}
    return None


@functools.lru_cache(maxsize=None)
def iverilog() -> dict | None:
    exe = shutil.which("iverilog")
    if not exe:
        return None
    raw = ((_run([exe, "-V"]) or "").splitlines() or [""])[0]
    m = re.search(r"version\s+(\d+(?:\.\d+)*)", raw)
    return {"exe": exe, "version": m.group(1) if m else raw, "raw": raw}


def openroad() -> dict | None:
    exe = shutil.which("openroad")
    return {"exe": exe, "version": (_run([exe, "-version"]) or "").splitlines()[0]} if exe else None


def opensta() -> dict | None:
    exe = shutil.which("sta") or shutil.which("opensta")
    return {"exe": exe, "version": (_run([exe, "-version"]) or "").splitlines()[0]} if exe else None


def rscript() -> dict | None:
    exe = shutil.which("Rscript")
    if not exe:
        return None
    raw = (_run([exe, "--version"]) or "").strip()
    m = re.search(r"version\s+(\d+(?:\.\d+)*)", raw)
    return {"exe": exe, "version": m.group(1) if m else raw, "raw": raw}


def git_info(path: str | None = None) -> dict:
    path = path or ROOT
    def g(*a):
        return _run(["git", "-C", path, *a])
    rev = g("rev-parse", "HEAD")
    if not rev or "fatal" in rev:
        return {"revision": None, "dirty": None, "branch": None}
    dirty = bool((g("status", "--porcelain", "--", ROOT) or "").strip())
    return {"revision": rev, "branch": g("rev-parse", "--abbrev-ref", "HEAD"), "dirty": dirty}


def environment() -> dict:
    import platform
    try:
        import numpy, pandas
        npv, pdv = numpy.__version__, pandas.__version__
    except Exception:
        npv = pdv = None
    return {
        "python": sys.version.split()[0], "platform": platform.platform(), "machine": platform.machine(),
        "cpu_count": os.cpu_count(), "numpy": npv, "pandas": pdv,
        "verilator": (verilator() or {}).get("version"), "yosys": (yosys() or {}).get("version"),
        "iverilog": (iverilog() or {}).get("version"),
        "openroad": (openroad() or {}).get("version"), "opensta": (opensta() or {}).get("version"),
        "Rscript": (rscript() or {}).get("version"),
    }


def status() -> list[dict]:
    rows = []
    for name, fn in (("verilator", verilator), ("yosys", yosys), ("iverilog", iverilog),
                     ("openroad", openroad), ("opensta", opensta), ("Rscript", rscript)):
        d = fn()
        rows.append({"tool": name, "available": d is not None, "version": (d or {}).get("version"),
                     "path": (d or {}).get("exe")})
    return rows
