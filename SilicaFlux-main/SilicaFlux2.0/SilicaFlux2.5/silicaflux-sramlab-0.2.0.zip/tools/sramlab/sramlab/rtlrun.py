"""Build and run the Verilator testbench and compare it with the Python model, cycle by cycle.

Layer: **measured-RTL-simulation** (what the Verilator run of the real RTL produces) versus
**simulation** (the Python model).  ``compare()`` returns a structured verdict: the number of
cycles compared, the first divergence (cycle, field, both values) and the counter diffs.
A comparison only counts as passed when the trace is identical in every cycle AND all
hardware performance counters are equal AND no RTL assertion fired.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass

from . import tools
from .sim.controller import CtlParams, CycleOut
from .sim.driver import ReadyMasks, ReqSpec, RunResult, run_scripts

RTL_DIR = os.path.join(tools.ROOT, "rtl")
P71 = os.path.join(RTL_DIR, "third_party", "p71_sramcore")
P73 = os.path.join(RTL_DIR, "third_party", "p73_sramcontroller")
TB = os.path.join(RTL_DIR, "tb", "tb_sramlab_ctl.sv")                 # SV testbench (Icarus; Verilator --timing legacy)
VL_TOP = os.path.join(RTL_DIR, "tb", "vl_ctl", "sramlab_ctl_top.sv")  # Verilator: pass-through top ...
VL_MAIN = os.path.join(RTL_DIR, "tb", "vl_ctl", "sim_ctl.cpp")        # ... driven cycle by cycle from C++
IVL_TB = os.path.join(RTL_DIR, "tb", "ivl_ctl", "tb_sramlab_ctl_ivl.sv")  # Icarus: independent second simulator
SIMULATORS = ("verilator", "icarus")
RTL_FILES = [
    os.path.join(P71, "sf_sram_array.sv"), os.path.join(P71, "sf_sram_core.sv"),
    os.path.join(P73, "sf_sramc_fifo.sv"), os.path.join(P73, "sf_sramc_arb.sv"),
    os.path.join(P73, "sf_sramc_perf.sv"), os.path.join(P73, "sf_sram_controller.sv"),
    os.path.join(P73, "sf_sramc_bank.sv"), os.path.join(P73, "sf_sram_subsystem.sv"),
]
# 3: the Verilator harness is C++-driven (no --timing).  The scheme-2 harness (SV testbench driving the
#    DUT from a timed initial block) mis-simulated under Verilator 5.020: the controller's always_comb
#    decode was not re-evaluated after the testbench changed m_req_addr (docs/03_verification.md).
BUILD_SCHEME = 3
BUILD_ROOT = os.environ.get("SRAMLAB_BUILD", os.path.join(tools.ROOT, ".build"))


def _lats_int(lats: list[int]) -> int:
    v = 0
    for b, l in enumerate(lats):
        v |= (l & 0xF) << (4 * b)
    return v


def _gval(name: str, val: int) -> str:
    """-G value text.  The 64-bit BANK_LATS vector must be given as a sized hex literal: a bare 19-digit
    decimal is truncated to 32 bits by Verilator's -G parser, which silently zeroed the latency nibbles of
    banks 8..15 (found by the 16-bank RTL comparison)."""
    if name == "LATS":
        return f"64'h{val:016x}"
    return str(val)


def tb_generics(p: CtlParams) -> dict:
    return {
        "NM": p.num_masters, "NB": p.num_banks, "DW": p.data_width, "BD": p.bank_depth, "MAXOUT": p.max_out,
        "BANKOUT": p.bank_out, "IDW": p.id_width, "ILV": 0 if p.interleave == "low" else 1,
        "MASKMODE": 0 if p.mask_mode == "any" else 1, "IDCHK": p.id_check, "SRCCHK": p.src_check,
        "PRIO": p.prio_en, "HPM": p.hp_mask, "HPL": p.hp_limit, "LATS": _lats_int(p.bank_lats),
        "UNI": p.uniform_lat,
    }


def rtl_hash() -> str:
    h = hashlib.sha256()
    for f in RTL_FILES + [VL_TOP, VL_MAIN]:
        with open(f, "rb") as fh:
            h.update(fh.read())
    return h.hexdigest()


_BUILD_LOCKS: dict = {}
_BUILD_GUARD = threading.Lock()


def build(p: CtlParams, force: bool = False, verbose: bool = False) -> str:
    """Compile the testbench for this parameter set (cached); returns the simulator binary path."""
    v = tools.verilator()
    if v is None:
        raise RuntimeError("Verilator is not installed: RTL comparison is unavailable (`pip install verilator`)")
    gen = tb_generics(p)
    key = hashlib.sha256(json.dumps([{k: _gval(k, x) for k, x in gen.items()}, rtl_hash(), v["version"], BUILD_SCHEME],
                                    sort_keys=True).encode()).hexdigest()[:16]
    mdir = os.path.join(BUILD_ROOT, f"ctl_{key}")
    exe = os.path.join(mdir, "simv")
    if os.path.exists(exe) and not force:
        return exe
    with _BUILD_GUARD:
        lock = _BUILD_LOCKS.setdefault(mdir, threading.Lock())
    with lock:                                         # concurrent callers wait for the first build of the same testbench
        if os.path.exists(exe) and not force:
            return exe
        return _build_locked(v, gen, mdir, exe, key, verbose)


def _build_locked(v, gen, mdir, exe, key, verbose) -> str:
    os.makedirs(mdir, exist_ok=True)
    defs = f"-DNM={gen['NM']} -DNB={gen['NB']} -DDW={gen['DW']} -DIDW={gen['IDW']}"
    cmd = [v["exe"], "--cc", "--exe", "--build", "-j", str(min(4, os.cpu_count() or 1)),
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", "sramlab_ctl_top",
           "-Mdir", mdir, "-o", "simv", f"-I{P71}", f"-I{P73}", "+define+SFC_ASSERT",
           # the fairness checker (SFC_ASSERT) loops over NUM_BANKS*NUM_MASTERS (up to 256) with array NBAs,
           # which Verilator only supports when unrolled
           "--unroll-count", "1024", "--unroll-stmts", "1000000",
           "-CFLAGS", defs, "--x-assign", "0", "--x-initial", "0"]
    if v.get("pip_wheel"):
        # the pip Verilator wheel ships CFG_CXXFLAGS_PCH_I empty, so gcc would get the precompiled
        # header as a bare linker input; pass -include explicitly
        cmd += ["-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include"]
    cmd += [f"-G{k}={_gval(k, val)}" for k, val in gen.items()]
    cmd += RTL_FILES + [VL_TOP, VL_MAIN]
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(exe):
        raise RuntimeError("Verilator build failed:\n" + (r.stdout + r.stderr)[-4000:])
    if verbose:
        print(f"[rtl] built {key} in {time.time() - t0:.1f}s")
    return exe


def build_icarus(p: CtlParams, force: bool = False) -> str:
    """Compile the Icarus testbench for this parameter set (cached); returns the .vvp path."""
    iv = tools.iverilog()
    if iv is None:
        raise RuntimeError("Icarus Verilog is not installed: the second-simulator comparison is unavailable")
    gen = tb_generics(p)
    h = hashlib.sha256()
    for f in RTL_FILES + [VL_TOP, IVL_TB]:
        with open(f, "rb") as fh:
            h.update(fh.read())
    key = hashlib.sha256(json.dumps([{k: _gval(k, x) for k, x in gen.items()}, h.hexdigest(), iv["version"]],
                                    sort_keys=True).encode()).hexdigest()[:16]
    mdir = os.path.join(BUILD_ROOT, f"ivl_{key}")
    vvp = os.path.join(mdir, "sim.vvp")
    if os.path.exists(vvp) and not force:
        return vvp
    with _BUILD_GUARD:
        lock = _BUILD_LOCKS.setdefault(mdir, threading.Lock())
    with lock:
        if os.path.exists(vvp) and not force:
            return vvp
        os.makedirs(mdir, exist_ok=True)
        top = "tb_sramlab_ctl_ivl"
        cmd = [iv["exe"], "-g2012", "-DSFC_ASSERT", f"-I{P71}", f"-I{P73}", "-s", top, "-o", vvp]
        cmd += [f"-P{top}.{k}={_gval(k, val)}" for k, val in gen.items()]
        cmd += RTL_FILES + [VL_TOP, IVL_TB]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(vvp):
            raise RuntimeError("Icarus build failed:\n" + (r.stdout + r.stderr)[-4000:])
        return vvp


def write_stimulus(path: str, p: CtlParams, scripts: list[list[ReqSpec]]):
    with open(path, "w") as f:
        for m, s in enumerate(scripts):
            f.write(f"0 {m} {len(s)}\n")
        for m, s in enumerate(scripts):
            for r in s:
                f.write(f"1 {m} {r.we} {r.addr:x} {r.wdata:x} {r.wstrb:x} {r.err} {r.delay}\n")


def write_ready(path: str, ready: ReadyMasks, ncycles: int):
    with open(path, "w") as f:
        for c, mask in enumerate(ready.dump(ncycles)):
            f.write(f"{c} {mask:x}\n")


def format_trace_line(p: CtlParams, o: CycleOut) -> str:
    nm = p.num_masters
    mask = lambda xs: sum(1 << i for i, x in enumerate(xs) if x)
    s = f"T {o.cyc} {mask(o.req_valid):x} {mask(o.req_ready):x} {mask(o.rsp_valid):x} {mask(o.rsp_ready):x} " \
        f"{mask(o.bk_issue):x} {1 if o.idle else 0}"
    for m in range(nm):
        if o.rsp_valid[m]:
            rid, we, st, rdata = o.rsp[m]
            s += f" {m}:{rid}:{we}:{st}:{rdata:x}"
    return s


@dataclass
class RtlResult:
    trace_lines: list
    perf: list
    ovf: int
    proto: int
    stdout: str
    returncode: int
    seconds: float


def run_rtl(p: CtlParams, scripts, ready: ReadyMasks, ncycles: int, workdir: str | None = None,
            keep: bool = False, flush_cycles=(), simulator: str = "verilator") -> RtlResult:
    if simulator not in SIMULATORS:
        raise ValueError(f"unknown simulator {simulator!r}; one of {SIMULATORS}")
    if simulator == "verilator":
        launch = [build(p)]
    else:
        vvp_exe = shutil.which("vvp")
        if vvp_exe is None:
            raise RuntimeError("Icarus 'vvp' runtime not found")
        launch = [vvp_exe, "-n", build_icarus(p)]
    import tempfile
    wd = workdir or tempfile.mkdtemp(prefix="sramlab_rtl_")
    os.makedirs(wd, exist_ok=True)
    stim, rdy, trace = (os.path.join(wd, n) for n in ("stim.txt", "rdy.txt", "trace.txt"))
    write_stimulus(stim, p, scripts)
    args = launch + [f"+stim={stim}", f"+cycles={ncycles}", f"+trace={trace}"]
    if ready.rate < 1.0:
        write_ready(rdy, ready, ncycles)
        args.append(f"+rdy={rdy}")
    if flush_cycles:
        fl = os.path.join(wd, "flush.txt")
        with open(fl, "w") as f:
            f.write("".join(f"{c}\n" for c in sorted(set(flush_cycles))))
        args.append(f"+flush={fl}")
    t0 = time.time()
    r = subprocess.run(args, capture_output=True, text=True, cwd=wd)
    dt = time.time() - t0
    lines, perf, ovf, proto = [], [0] * p.nperf, 0, 0
    if os.path.exists(trace):
        with open(trace) as f:
            for ln in f:
                ln = ln.rstrip("\n")
                if ln.startswith("T "):
                    lines.append(ln)
                elif ln.startswith("P "):
                    _, i, v = ln.split()
                    perf[int(i)] = int(v)
                elif ln.startswith("S "):
                    _, a, b = ln.split()
                    ovf, proto = int(a), int(b)
    out = r.stdout + r.stderr
    if not keep and workdir is None:
        shutil.rmtree(wd, ignore_errors=True)
    return RtlResult(lines, perf, ovf, proto, out, r.returncode, dt)


def compare(p: CtlParams, scripts, ready: ReadyMasks, *, label: str = "", ncycles: int | None = None,
            flush_cycles=(), simulator: str = "verilator") -> dict:
    """Run the model and the RTL on the same scripts; return the verdict."""
    model = run_scripts(p, scripts, ready, trace=True, track_data=True, flush_cycles=flush_cycles,
                        max_cycles=ncycles or 400_000, fixed_cycles=ncycles)
    n = ncycles or model.cycles
    rtl = run_rtl(p, scripts, ready, n, flush_cycles=flush_cycles, simulator=simulator)
    mt = [format_trace_line(p, o) for o in model.trace]
    first_diff = None
    for i, (a, b) in enumerate(zip(mt, rtl.trace_lines)):
        if a != b:
            first_diff = {"cycle": i, "model": a, "rtl": b}
            break
    if first_diff is None and len(mt) != len(rtl.trace_lines):
        first_diff = {"cycle": min(len(mt), len(rtl.trace_lines)), "model": f"{len(mt)} lines", "rtl": f"{len(rtl.trace_lines)} lines"}
    perf_diff = [(i, a, b) for i, (a, b) in enumerate(zip(model.perf, rtl.perf)) if a != b]
    asserts = [ln for ln in rtl.stdout.splitlines()
               if ("SFC_ASSERT" in ln or "SFC_ENV_ASSUMPTION" in ln or "%Error" in ln or ln.startswith("ERROR"))]
    cfg_line = next((ln for ln in rtl.stdout.splitlines() if ln.startswith("CFG ")), "")
    rtl_cfg = dict(kv.split("=") for kv in cfg_line.split()[1:]) if cfg_line else {}
    cfg_mismatch = []
    if rtl_cfg:
        want = {"uniform": p.uniform_eff, "bank_out": p.bank_out_eff, "max_lat": p.max_lat, "min_lat": p.min_lat}
        cfg_mismatch = [f"{k}: model {want[k]} != rtl {rtl_cfg.get(k)}" for k in want if str(want[k]) != rtl_cfg.get(k)]
    else:
        cfg_mismatch = ["RTL did not report its derived configuration"]
    ok = (first_diff is None and not cfg_mismatch and not perf_diff and not asserts and rtl.returncode == 0 and "SRAMLAB_DONE" in rtl.stdout
          and rtl.ovf == int(model.sts_ovf) and rtl.proto == int(model.sts_proto))
    return {
        "label": label, "simulator": simulator, "ok": ok, "cycles_compared": min(len(mt), len(rtl.trace_lines)),
        "transactions": len(model.tx), "counters_compared": p.nperf, "counter_mismatches": perf_diff[:10],
        "first_trace_divergence": first_diff, "rtl_assertions": asserts[:5], "config_mismatch": cfg_mismatch,
        "rtl_effective_config": rtl_cfg, "rtl_returncode": rtl.returncode,
        "rtl_seconds": round(rtl.seconds, 2), "model_integrity_errors": len(model.integrity_errors),
        "drained": model.drained,
    }
