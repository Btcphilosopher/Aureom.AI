"""Yosys synthesis of the SRAMController logic (and the integrated subsystem), with an optional real Liberty.

Scope and honesty
-----------------
* ``synth_controller`` synthesizes **controller logic only** (``sf_sram_controller`` = arbiters, response FIFOs,
  trackers, performance counters).  The bank SRAM **arrays are NOT synthesized to gates** here; the bits they would
  hold are reported separately as an analytical count (``memory_bits_analytical``).  ``synth_subsystem``
  synthesizes the integrated ``sf_sram_subsystem`` once, with a small depth, only to prove that the integrated top
  elaborates and synthesizes (its tiny arrays become flip-flops through Yosys ``memory_map``; that is not a macro
  and says nothing about a real SRAM).
* Without a Liberty the result is generic-gate counts (label ``synthesized``): cells by type, total cells,
  flip-flops, latches.  Gate counts are NOT area.
* With a real Liberty (``dfflibmap -liberty`` + ``abc -liberty`` + ``stat -liberty``) the mapped cell area in um^2 of
  the controller logic is reported, labelled ``synthesized`` and bound to THAT library's technology string.  Without
  one the area is ``unavailable("no technology library")``.
* Yosys gives no signoff timing.  The only depth figure reported is ``ltp``: "pre-mapping logic depth (gate levels),
  not a frequency".  OpenROAD / OpenSTA are not used (not installed): no STA is performed or implied.

Yosys here is typically ``yowasp-yosys`` (WASI): it cannot read absolute ``/tmp`` paths, so every run stages the RTL
(and the Liberty) into its own work directory and uses relative paths; the results are cached under
``sramlab/.cache/synth/`` keyed on (RTL hash, parameters, Yosys version, flow script, Liberty hash).
"""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor

from . import tech, tools
from .provenance import tag, unavailable

RTL_DIR = os.path.join(tools.ROOT, "rtl")
P71 = os.path.join(RTL_DIR, "third_party", "p71_sramcore")
P73 = os.path.join(RTL_DIR, "third_party", "p73_sramcontroller")

CONTROLLER_FILES = [os.path.join(P73, f) for f in ("sf_sramc_fifo.sv", "sf_sramc_arb.sv", "sf_sramc_perf.sv",
                                                   "sf_sram_controller.sv")]
# same file set / order as rtlrun.RTL_FILES (array, core, controller package, bank, subsystem)
SUBSYSTEM_FILES = [os.path.join(P71, "sf_sram_array.sv"), os.path.join(P71, "sf_sram_core.sv"),
                   os.path.join(P73, "sf_sramc_fifo.sv"), os.path.join(P73, "sf_sramc_arb.sv"),
                   os.path.join(P73, "sf_sramc_perf.sv"), os.path.join(P73, "sf_sram_controller.sv"),
                   os.path.join(P73, "sf_sramc_bank.sv"), os.path.join(P73, "sf_sram_subsystem.sv")]
INCLUDE_DIRS = [P71, P73]

FLOW_VERSION = 4          # bump when the generated Yosys script changes (invalidates the cache)

# parameters accepted per top (typo protection) and the defaults SRAMLab uses for the controller.  BANK_OUT=2 and
# UNIFORM_LAT=1 are what sf_sram_subsystem derives automatically for the sramlab default (every bank read latency 1:
# BANK_OUT = max latency + 1, UNIFORM_LAT = 1 when all bank latencies are equal); the RTL's own defaults are 4 and 0.
CONTROLLER_PARAMS = ("NUM_MASTERS", "NUM_BANKS", "DATA_WIDTH", "BANK_DEPTH", "ADDR_WIDTH", "ID_WIDTH", "MAX_OUT",
                     "BANK_OUT", "UNIFORM_LAT", "INTERLEAVE", "ID_CHECK", "SRC_CHECK", "MASK_MODE", "PRIO_EN",
                     "HP_LIMIT", "PERF_EN", "CNT_W")
SUBSYSTEM_PARAMS = tuple(p for p in CONTROLLER_PARAMS if p not in ("BANK_OUT", "UNIFORM_LAT")) + (
    "BANK_OUT", "UNIFORM_LAT", "INIT_MODE")
CONTROLLER_DEFAULTS = {"NUM_MASTERS": 4, "NUM_BANKS": 4, "DATA_WIDTH": 32, "BANK_DEPTH": 1024, "MAX_OUT": 1,
                       "BANK_OUT": 2, "UNIFORM_LAT": 1, "PRIO_EN": 0, "PERF_EN": 1, "CNT_W": 32}
SUBSYSTEM_DEFAULTS = {"NUM_MASTERS": 4, "NUM_BANKS": 4, "DATA_WIDTH": 32, "BANK_DEPTH": 16, "MAX_OUT": 1,
                      "BANK_OUT": 0, "UNIFORM_LAT": -1, "PRIO_EN": 0, "PERF_EN": 1, "CNT_W": 32}

DEPTH_LABEL = "pre-mapping logic depth (gate levels), not a frequency"
SCOPE_CONTROLLER = ("controller logic only (arbiters, FIFOs, trackers, perf counters); the bank SRAM arrays are NOT "
                    "synthesized to gates")
SCOPE_SUBSYSTEM = ("integrated top sf_sram_subsystem synthesized once with a small depth to prove it elaborates; its "
                   "tiny arrays become flip-flops via memory_map (NOT an SRAM macro, NOT representative of area)")


class YosysParseError(ValueError):
    """The Yosys ``stat`` report is malformed / inconsistent and is rejected (never partially trusted)."""


# ---------------------------------------------------------------------------------------------- stat parsing
_NUM = r"[0-9]+(?:\.[0-9]+)?(?:[eE][-+]?[0-9]+)?"
_RE_CELLS_NEW = re.compile(rf"^\s*(\d+)\s+(?:{_NUM}\s+)?cells\s*$")
_RE_CELLS_OLD = re.compile(r"^\s*Number of cells:\s+(\d+)\s*$")
_RE_TYPE_NEW = re.compile(rf"^\s*(\d+)\s+(?:{_NUM}\s+)?([$\\A-Za-z_][^\s]*)\s*$")
_RE_TYPE_OLD = re.compile(r"^\s+([$\\A-Za-z_][^\s]*)\s+(\d+)\s*$")
_RE_BLOCK = re.compile(r"^\s*===\s*(.+?)\s*===\s*$")
_RE_AREA = re.compile(r"^\s*Chip area for (?:top )?module '([^']*)':\s*(" + _NUM + r")\s*$")
_RE_SEQ_AREA = re.compile(r"^\s*of which used for sequential elements:\s*(" + _NUM + r")")
_NON_CELL_LABELS = {"wires", "wire", "bits", "ports", "port", "memories", "memory", "processes", "submodules",
                    "-", "public", "cells"}
_FF_PREFIXES = ("$_DFF", "$_SDFF", "$_ADFF", "$_DFFSR", "$_DFFE", "$_ALDFF", "$_SR_", "$dff", "$sdff", "$adff")
_LATCH_MARKERS = ("LATCH",)
_META_CELLS = ("$scopeinfo",)


def parse_yosys_stat(text: str) -> dict:
    """Parse the TEXT output of Yosys ``stat`` (new ``N cells`` / old ``Number of cells:`` layout, with or without
    ``-liberty`` areas).  Pure function.

    Returns ``{"modules": {name: {...}}, "top": name, "design": {...}}`` where each block has ``cells_total`` (as
    printed, incl. metadata cells), ``cells_by_type``, ``scopeinfo_cells``, ``cells`` (logic cells, metadata
    excluded), ``flip_flops``, ``latches`` and, when present, ``area_um2`` / ``sequential_area_um2``.
    Raises :class:`YosysParseError` when the report has no cell count, no cell-type table, or when the per-type
    counts do not add up to the printed total (a corrupted or truncated report is never accepted).
    """
    if not isinstance(text, str) or not text.strip():
        raise YosysParseError("empty Yosys stat report")
    blocks: dict[str, dict] = {}
    cur = None
    in_types = False
    for ln in text.splitlines():
        mb = _RE_BLOCK.match(ln)
        if mb:
            cur = {"name": mb.group(1), "cells_total": None, "cells_by_type": {}, "area_um2": None,
                   "sequential_area_um2": None}
            blocks[mb.group(1)] = cur
            in_types = False
            continue
        if cur is None:
            continue
        m = _RE_CELLS_NEW.match(ln) or _RE_CELLS_OLD.match(ln)
        if m and cur["cells_total"] is None:
            cur["cells_total"] = int(m.group(1))
            in_types = True
            continue
        ma = _RE_AREA.match(ln)
        if ma:
            cur["area_um2"] = float(ma.group(2))
            in_types = False
            continue
        ms = _RE_SEQ_AREA.match(ln)
        if ms:
            cur["sequential_area_um2"] = float(ms.group(1))
            continue
        if not ln.strip():
            in_types = False if cur["cells_by_type"] else in_types
            continue
        if in_types:
            m1 = _RE_TYPE_NEW.match(ln)
            if m1 and m1.group(2) not in _NON_CELL_LABELS and not m1.group(2).startswith("-"):
                name, n = m1.group(2), int(m1.group(1))
                cur["cells_by_type"][name] = cur["cells_by_type"].get(name, 0) + n
                continue
            m2 = _RE_TYPE_OLD.match(ln)
            if m2 and m2.group(1) not in _NON_CELL_LABELS:
                name, n = m2.group(1), int(m2.group(2))
                cur["cells_by_type"][name] = cur["cells_by_type"].get(name, 0) + n
                continue
    if not blocks:
        raise YosysParseError("no '=== module ===' block found in the Yosys stat report")
    for name, b in blocks.items():
        if b["cells_total"] is None:
            if name == "design hierarchy" or b["area_um2"] is None:
                raise YosysParseError(f"block {name!r}: no cell count line (report truncated or malformed)")
        if b["cells_total"] is not None:
            s = sum(b["cells_by_type"].values())
            if not b["cells_by_type"] and b["cells_total"] != 0:
                raise YosysParseError(f"block {name!r}: {b['cells_total']} cells announced but no per-type table")
            if s != b["cells_total"]:
                raise YosysParseError(f"block {name!r}: per-type cell counts sum to {s} but the report says "
                                      f"{b['cells_total']} cells (corrupted / truncated report)")
        cbt = b["cells_by_type"]
        b["scopeinfo_cells"] = sum(n for t, n in cbt.items() if t in _META_CELLS)
        b["cells"] = (b["cells_total"] or 0) - b["scopeinfo_cells"]
        b["flip_flops"] = sum(n for t, n in cbt.items() if t.startswith(_FF_PREFIXES) and "LATCH" not in t)
        b["latches"] = sum(n for t, n in cbt.items() if any(k in t for k in _LATCH_MARKERS))
    if "design hierarchy" in blocks:
        design, top = blocks["design hierarchy"], None
        tops = [k for k in blocks if k != "design hierarchy"]
        top = tops[-1] if tops else None
    else:
        mods = [k for k in blocks if blocks[k]["cells_total"] is not None]
        if len(mods) != 1:
            raise YosysParseError(f"{len(mods)} module blocks and no 'design hierarchy' block: ambiguous report "
                                  "(synthesize with -flatten)")
        top, design = mods[0], blocks[mods[0]]
    return {"modules": blocks, "top": top, "design": design}


def parse_yosys_stat_json(text: str) -> dict:
    """Parse ``stat -json`` output into the same per-block dict shape as :func:`parse_yosys_stat` (design totals)."""
    try:
        d = json.loads(text)
    except Exception as e:
        raise YosysParseError(f"stat -json output is not valid JSON ({e})") from e
    des = d.get("design") if isinstance(d, dict) else None
    if not isinstance(des, dict) or "num_cells" not in des or not isinstance(des.get("num_cells_by_type"), dict):
        raise YosysParseError("stat -json: missing design.num_cells / design.num_cells_by_type")
    cbt = {k: int(v) for k, v in des["num_cells_by_type"].items()}
    if sum(cbt.values()) != int(des["num_cells"]):
        raise YosysParseError(f"stat -json: per-type cells sum to {sum(cbt.values())} but num_cells={des['num_cells']}")
    sc = sum(n for t, n in cbt.items() if t in _META_CELLS)
    return {"cells_total": int(des["num_cells"]), "cells_by_type": cbt, "scopeinfo_cells": sc,
            "cells": int(des["num_cells"]) - sc,
            "flip_flops": sum(n for t, n in cbt.items() if t.startswith(_FF_PREFIXES) and "LATCH" not in t),
            "latches": sum(n for t, n in cbt.items() if any(k in t for k in _LATCH_MARKERS)),
            "area_um2": float(des["area"]) if des.get("area") is not None else None,
            "sequential_area_um2": float(des["sequential_area"]) if des.get("sequential_area") is not None else None}


def parse_ltp(text: str) -> dict:
    """Longest topological path from ``ltp`` output (gate levels).  ``{"levels": int}`` or ``unavailable``."""
    m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", text or "")
    if not m:
        return unavailable("ltp reported no path (design has no combinational path between registers/ports)")
    return {"levels": int(m.group(1)), "label": DEPTH_LABEL}


def parse_check(log: str) -> dict:
    """Result of ``check -assert`` from the Yosys log: the LAST 'Found and reported N problems' line."""
    ms = re.findall(r"Found and reported (\d+) problems?", log or "")
    errs = re.findall(r"^ERROR: (.*)$", log or "", flags=re.M)
    return {"problems": int(ms[-1]) if ms else None, "ok": bool(ms) and int(ms[-1]) == 0 and not errs,
            "errors": errs[:5]}


# ---------------------------------------------------------------------------------------------- helpers
def signoff_timing_status() -> dict:
    """Timing is never claimed: Yosys gives no signoff timing and OpenSTA/OpenROAD are reported as found/not found (never faked)."""
    sta, orr = tools.opensta(), tools.openroad()
    why = ("no static timing analysis was run: Yosys reports gate counts/depth only; "
           + ("OpenSTA and OpenROAD are not installed" if not (sta or orr) else
              "an STA tool exists on this machine but this flow does not invoke it"))
    return unavailable(why, opensta=bool(sta), openroad=bool(orr))


def liberty_label(path: str | None) -> str | None:
    """Technology string bound to a mapped area: the Nangate45 disclaimer for the pinned library, else a generic one."""
    if not path:
        return None
    try:
        nl = tech.profile_liberty(tech.load_profile("nangate45"), verify=False)
        if nl["path"] and os.path.abspath(nl["path"]) == os.path.abspath(path):
            return tech.NANGATE45_TECH_LABEL
    except Exception:
        pass
    return (f"user-supplied liberty {os.path.basename(path)} (sha256 {tech.sha256_file(path)[:16]}...); area is valid "
            "for THAT library only and is not transferable to another node")


def _hash_files(paths: list[str], incdirs: list[str] | None = None) -> str:
    h = hashlib.sha256()
    for p in paths:
        with open(p, "rb") as fh:
            h.update(os.path.basename(p).encode() + b"\0" + fh.read())
    for d in (INCLUDE_DIRS if incdirs is None else incdirs):
        for f in sorted(os.listdir(d)):
            if f.endswith(".svh"):
                with open(os.path.join(d, f), "rb") as fh:
                    h.update(f.encode() + b"\0" + fh.read())
    return h.hexdigest()


def rtl_hash(top: str = "sf_sram_controller") -> str:
    return _hash_files(CONTROLLER_FILES if top == "sf_sram_controller" else SUBSYSTEM_FILES)


def _norm_params(top: str, params: dict | None) -> dict:
    allowed = CONTROLLER_PARAMS if top == "sf_sram_controller" else SUBSYSTEM_PARAMS
    base = dict(CONTROLLER_DEFAULTS if top == "sf_sram_controller" else SUBSYSTEM_DEFAULTS)
    for k, v in (params or {}).items():
        if k not in allowed:
            raise ValueError(f"unknown {top} parameter {k!r}; allowed: {allowed}")
        if isinstance(v, bool):
            v = int(v)
        if not isinstance(v, int):
            raise ValueError(f"parameter {k}={v!r}: only integer parameters are supported")
        if v < 0 and not (k == "UNIFORM_LAT" and v == -1):
            raise ValueError(f"parameter {k}={v}: negative values are only meaningful for UNIFORM_LAT=-1 (automatic)")
        base[k] = v
    nb, nm, dw = base["NUM_BANKS"], base["NUM_MASTERS"], base["DATA_WIDTH"]
    if not (1 <= nb <= 16 and nb & (nb - 1) == 0):
        raise ValueError(f"NUM_BANKS={nb}: must be a power of two in 1..16 (RTL elaboration rule)")
    if not 1 <= nm <= 16:
        raise ValueError(f"NUM_MASTERS={nm}: must be 1..16")
    if dw not in (8, 16, 32, 64, 128):
        raise ValueError(f"DATA_WIDTH={dw}: must be one of 8,16,32,64,128")
    return base


def _tag_of(top: str, p: dict, mapped: bool) -> str:
    short = "ctl" if top == "sf_sram_controller" else "sub"
    s = (f"{short}_M{p['NUM_MASTERS']}_B{p['NUM_BANKS']}_W{p['DATA_WIDTH']}_D{p['BANK_DEPTH']}_O{p['MAX_OUT']}_"
         f"P{p['PRIO_EN']}_E{p['PERF_EN']}_C{p['CNT_W']}_U{p['UNIFORM_LAT']}")
    extra = [f"{k}{v}" for k, v in sorted(p.items()) if k not in CONTROLLER_DEFAULTS and k not in (
        "NUM_MASTERS", "NUM_BANKS", "DATA_WIDTH", "BANK_DEPTH", "MAX_OUT", "PRIO_EN", "PERF_EN", "CNT_W", "UNIFORM_LAT")]
    return s + ("_" + "_".join(extra) if extra else "") + ("_lib" if mapped else "_gen")


def _script(top: str, files: list[str], params: dict, liberty_rel: str | None) -> str:
    # a parameter < 0 (only UNIFORM_LAT=-1 'automatic') is the RTL default and is not passed: yosys cannot decode '-1'
    lines = [f"read_verilog -sv -Irtl {' '.join(files)}",
             f"hierarchy -check -top {top}" + "".join(f" -chparam {k} {v}" for k, v in sorted(params.items()) if v >= 0),
             f"synth -top {top} -flatten",
             "check -assert",
             "tee -o stat_generic.txt stat",
             "tee -o stat_generic.json stat -json",
             "tee -o ltp.txt ltp -noff"]
    if liberty_rel:
        lines += [f"dfflibmap -liberty {liberty_rel}", f"abc -liberty {liberty_rel}", "opt_clean -purge",
                  f"tee -o stat_mapped.txt stat -liberty {liberty_rel}",
                  f"tee -o stat_mapped.json stat -json -liberty {liberty_rel}"]
    return "\n".join(lines) + "\n"


def _stage(workdir: str, files: list[str], incs: list[str], liberty: str | None) -> tuple[list[str], str | None]:
    """Copy RTL (and the Liberty) into the work dir: WASI Yosys only sees relative paths below its cwd."""
    rtl = os.path.join(workdir, "rtl")
    os.makedirs(rtl, exist_ok=True)
    rels = []
    for f in files:
        shutil.copyfile(f, os.path.join(rtl, os.path.basename(f)))
        rels.append("rtl/" + os.path.basename(f))
    for d in incs:
        for f in os.listdir(d):
            if f.endswith(".svh"):
                shutil.copyfile(os.path.join(d, f), os.path.join(rtl, f))
    lrel = None
    if liberty:
        dst = os.path.join(workdir, "lib.lib")
        if os.path.exists(dst):
            os.remove(dst)
        try:
            os.link(liberty, dst)
        except OSError:
            shutil.copyfile(liberty, dst)
        lrel = "lib.lib"
    return rels, lrel


def _read(p: str) -> str:
    with open(p, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()


def _cache_key(top: str, params: dict, ys_version: str, liberty_sha: str | None, rtl_digest: str) -> str:
    blob = json.dumps({"top": top, "params": params, "rtl": rtl_digest, "yosys": ys_version, "flow": FLOW_VERSION,
                       "liberty": liberty_sha}, sort_keys=True)
    return hashlib.sha256(blob.encode()).hexdigest()[:24]


_ARTEFACTS = ("script.ys", "stat_generic.txt", "stat_generic.json", "ltp.txt", "stat_mapped.txt", "stat_mapped.json",
              "yosys.log.gz", "result.json")


def portable(res: dict) -> dict:
    """Copy of a result for persistence: run_dir relative to the output directory, no machine-specific paths."""
    r = json.loads(json.dumps(res, default=str))
    rd = r.get("run_dir")
    if rd:
        r["run_dir"] = "runs/" + os.path.basename(rd.rstrip("/"))
    if isinstance(r.get("yosys"), dict):
        r["yosys"].pop("exe", None)
    return r


def _copy_artefacts(src: str, dst: str):
    if os.path.abspath(src) == os.path.abspath(dst):
        return
    os.makedirs(dst, exist_ok=True)
    for a in _ARTEFACTS:
        if os.path.exists(os.path.join(src, a)):
            shutil.copyfile(os.path.join(src, a), os.path.join(dst, a))


# ---------------------------------------------------------------------------------------------- core runner
_LIB_CELLS: dict = {}


def liberty_cells(path: str) -> dict:
    """{cell: {"area": float | None, "sequential": bool}} from a Liberty file (cached per SHA-256).  A cell is sequential when
    its group contains an ``ff``/``latch`` (or bank/statetable) group.  Minimal brace-matching parser: enough for cell areas."""
    sha = tech.sha256_file(path)
    if sha in _LIB_CELLS:
        return _LIB_CELLS[sha]
    txt = _read(path)
    out = {}
    for m in re.finditer(r"\bcell\s*\(\s*\"?([^\")\s]+)\"?\s*\)\s*\{", txt):
        i, depth, j = m.end(), 1, m.end()
        while depth and j < len(txt):
            k1, k2 = txt.find("{", j), txt.find("}", j)
            if k2 < 0:
                break
            if 0 <= k1 < k2:
                depth, j = depth + 1, k1 + 1
            else:
                depth, j = depth - 1, k2 + 1
        body = txt[i:j]
        am = re.search(r"\barea\s*:\s*([0-9.eE+-]+)", body)
        out[m.group(1)] = {"area": float(am.group(1)) if am else None,
                           "sequential": re.search(r"\b(ff|latch|ff_bank|latch_bank|statetable)\s*\(", body) is not None}
    _LIB_CELLS[sha] = out
    return out


def _fill_sequential_area(res: dict, liberty: str | None) -> None:
    """Yosys >= 0.4x reports the sequential share of the mapped area; Yosys 0.33 does not.  When it is missing, compute it from
    the Liberty (cell count x cell area over sequential cells) -- accepted only if the Liberty-summed TOTAL equals Yosys's chip
    area, which validates the parse."""
    m = res.get("mapped")
    if not liberty or not isinstance(m, dict) or m.get("sequential_area_um2") is not None or not os.path.isfile(liberty):
        return
    area = (res.get("mapped_area_um2") or {}).get("value")
    if area is None:
        return
    info = liberty_cells(liberty)
    cb = m.get("cells_by_type") or {}
    if any(k not in info or info[k]["area"] is None for k in cb):
        m["sequential_area_source"] = "unavailable: a mapped cell has no area in the Liberty"
        return
    total = sum(n * info[k]["area"] for k, n in cb.items())
    if abs(total - area) > max(1e-3, 1e-6 * area):
        m["sequential_area_source"] = f"unavailable: Liberty-summed area {total:.3f} != Yosys chip area {area:.3f}"
        return
    m["sequential_area_um2"] = round(sum(n * info[k]["area"] for k, n in cb.items() if info[k]["sequential"]), 6)
    m["sequential_area_source"] = ("computed from the Liberty (cells with an ff/latch group); this Yosys does not report it; "
                                   "validated: Liberty-summed total area equals the Yosys chip area")


def _run(top: str, files: list[str], params: dict, outdir: str, liberty: str | None, scope: str, use_cache: bool,
         timeout: int, extra: dict | None = None, incdirs: list[str] | None = None, tag_prefix: str | None = None) -> dict:
    ys = tools.yosys()
    mapped = bool(liberty)
    incdirs = list(INCLUDE_DIRS if incdirs is None else incdirs)
    digest = _hash_files(files, incdirs)
    tg = (tag_prefix + ("_lib" if mapped else "_gen")) if tag_prefix else _tag_of(top, params, mapped)
    run_dir = os.path.join(os.fspath(outdir), "runs", tg)
    base = {"top": top, "scope": scope, "params": dict(params), "mode": "liberty-mapped" if mapped else "generic",
            "run_dir": run_dir, **(extra or {})}
    if ys is None:
        base.update({"status": "unavailable", "error": "yosys is not installed (pip install yowasp-yosys)",
                     "generic": unavailable("yosys not installed"),
                     "mapped_area_um2": unavailable("yosys not installed")})
        return base
    lib_sha = tech.sha256_file(liberty) if liberty else None
    key = _cache_key(top, params, ys["version"], lib_sha, digest)
    cdir = tech.cache_dir("synth", key, create=True)
    cres = os.path.join(cdir, "result.json")
    if use_cache and os.path.isfile(cres):
        try:
            res = json.loads(_read(cres))
            _fill_sequential_area(res, liberty)
            res["cached"] = True
            res["run_dir"] = run_dir
            res["cache_key"] = key
            _copy_artefacts(cdir, run_dir)
            with open(os.path.join(run_dir, "result.json"), "w") as fh:
                json.dump(portable(res), fh, indent=1)
            return res
        except Exception:
            pass  # corrupted cache entry: recompute
    shutil.rmtree(cdir, ignore_errors=True)
    os.makedirs(cdir, exist_ok=True)
    rels, lrel = _stage(cdir, files, incdirs, liberty)
    script = _script(top, rels, params, lrel)
    with open(os.path.join(cdir, "script.ys"), "w") as fh:
        fh.write(script)
    t0 = time.time()
    try:
        r = subprocess.run([ys["exe"], "-q", "-l", "yosys.log", "script.ys"], cwd=cdir, capture_output=True, text=True,
                           timeout=timeout)
        rc, serr = r.returncode, (r.stderr or "")[-2000:]
    except subprocess.TimeoutExpired:
        rc, serr = -9, f"timeout after {timeout}s"
    dt = time.time() - t0
    log = _read(os.path.join(cdir, "yosys.log")) if os.path.exists(os.path.join(cdir, "yosys.log")) else ""
    res = dict(base)
    res.update({"yosys": {"version": ys["version"], "exe": ys["exe"], "raw": ys.get("raw")},
                "signoff_timing": signoff_timing_status(),
                "rtl_sha256": digest, "flow_version": FLOW_VERSION, "cache_key": key, "cached": False,
                "runtime_s": round(dt, 2), "returncode": rc,
                "memory_bits_analytical": (
                    tag(params["NUM_BANKS"] * params["BANK_DEPTH"] * params["DATA_WIDTH"], "analytical",
                        "NUM_BANKS * BANK_DEPTH * DATA_WIDTH (bits the banks would hold; not synthesized)", unit="bits")
                    if all(k in params for k in ("NUM_BANKS", "BANK_DEPTH", "DATA_WIDTH")) else
                    unavailable("design has no NUM_BANKS/BANK_DEPTH/DATA_WIDTH parameters"))})
    if rc != 0:
        errs = re.findall(r"^ERROR: (.*)$", log, flags=re.M)
        res.update({"status": "failed", "error": (errs[-1] if errs else serr) or f"yosys exited with rc={rc}",
                    "generic": unavailable("yosys failed"),
                    "mapped_area_um2": unavailable("yosys failed")})
    else:
        try:
            gen_txt = parse_yosys_stat(_read(os.path.join(cdir, "stat_generic.txt")))["design"]
            gen_json = parse_yosys_stat_json(_read(os.path.join(cdir, "stat_generic.json")))
            if (gen_txt["cells_total"], gen_txt["cells_by_type"]) != (gen_json["cells_total"], gen_json["cells_by_type"]):
                raise YosysParseError("text and JSON stat reports disagree (cell counts differ)")
            chk = parse_check(log)
            ltp = parse_ltp(_read(os.path.join(cdir, "ltp.txt")))
            generic = {
                "label": "synthesized", "source": f"yosys {ys['version']} synth -flatten (generic gate library)",
                "total_cells": gen_json["cells"], "cells_by_type": {k: v for k, v in sorted(gen_json["cells_by_type"].items())
                                                                     if k not in _META_CELLS},
                "flip_flops": gen_json["flip_flops"], "latches": gen_json["latches"],
                "latch_free": gen_json["latches"] == 0,
                "check_assert": chk, "logic_depth": ltp,
                "note": "gate counts are not area; depth is " + DEPTH_LABEL}
            res["generic"] = generic
            res["status"] = "ok" if (chk["ok"] and generic["latch_free"]) else "ok_with_findings"
            res["error"] = None
            if not chk["ok"]:
                res["error"] = f"check -assert: {chk}"
            if mapped:
                mp_txt = parse_yosys_stat(_read(os.path.join(cdir, "stat_mapped.txt")))["design"]
                mp_json = parse_yosys_stat_json(_read(os.path.join(cdir, "stat_mapped.json")))
                if mp_json["area_um2"] is None or mp_txt["area_um2"] is None:
                    raise YosysParseError("mapped stat report has no chip area")
                if abs(mp_txt["area_um2"] - mp_json["area_um2"]) > max(1e-3, 1e-5 * mp_json["area_um2"]):
                    raise YosysParseError(f"text/JSON chip area disagree: {mp_txt['area_um2']} vs {mp_json['area_um2']}")
                unmapped = {k: v for k, v in mp_json["cells_by_type"].items() if k.startswith("$") and k not in _META_CELLS}
                tl = liberty_label(liberty)
                res["mapped"] = {"label": "synthesized", "technology": tl, "liberty_sha256": lib_sha,
                                 "liberty_file": os.path.basename(liberty), "cells": mp_json["cells"],
                                 "cells_by_type": {k: v for k, v in sorted(mp_json["cells_by_type"].items())},
                                 "sequential_area_um2": mp_json["sequential_area_um2"], "unmapped_cells": unmapped,
                                 "flow": "synth -flatten; dfflibmap -liberty; abc -liberty; opt_clean -purge; stat -liberty"}
                if unmapped:
                    res["mapped_area_um2"] = unavailable(
                        f"mapping incomplete: {sum(unmapped.values())} cells are not library cells {sorted(unmapped)[:4]}")
                    res["status"] = "ok_with_findings"
                else:
                    short = {"sf_sram_controller": "controller logic only",
                             "sf_sram_subsystem": "integrated subsystem (arrays as flops)"}.get(top, scope)
                    res["mapped_area_um2"] = tag(mp_json["area_um2"], "synthesized",
                                                 f"yosys {ys['version']} stat -liberty {os.path.basename(liberty)}",
                                                 unit="um^2", technology=tl, scope=short)
                    _fill_sequential_area(res, liberty)
            else:
                res["mapped_area_um2"] = unavailable("no technology library")
        except (YosysParseError, OSError) as e:
            res.update({"status": "failed", "error": f"stat report rejected: {e}", "generic": unavailable(str(e)),
                        "mapped_area_um2": unavailable(str(e))})
    # keep the log compressed; drop the staged copies (the cache keeps scripts/stats/result only)
    if log:
        with gzip.open(os.path.join(cdir, "yosys.log.gz"), "wt", encoding="utf-8") as fh:
            fh.write(log)
    for junk in ("yosys.log", "lib.lib"):
        pth = os.path.join(cdir, junk)
        if os.path.exists(pth):
            os.remove(pth)
    shutil.rmtree(os.path.join(cdir, "rtl"), ignore_errors=True)
    res["run_dir"] = run_dir
    with open(os.path.join(cdir, "result.json"), "w") as fh:
        json.dump(portable(res), fh, indent=1)
    _copy_artefacts(cdir, run_dir)
    if res["status"] == "failed":
        # never cache a failure: a transient problem must not become a permanent answer
        shutil.rmtree(cdir, ignore_errors=True)
    return res


# ---------------------------------------------------------------------------------------------- public API
def synth_controller(params: dict | None, outdir, liberty: str | None = None, *, use_cache: bool = True,
                     timeout: int = 1800) -> dict:
    """Synthesize ``sf_sram_controller`` (controller logic only) with Yosys.

    ``params``: any of NUM_MASTERS, NUM_BANKS, DATA_WIDTH, BANK_DEPTH, MAX_OUT, PRIO_EN, PERF_EN, CNT_W, UNIFORM_LAT,
    BANK_OUT, ... (missing ones take :data:`CONTROLLER_DEFAULTS`).  ``liberty``: path of a real Liberty file ->
    mapped area (um^2) of the controller logic, bound to that library's technology string; ``None`` -> generic gate
    counts and ``mapped_area_um2 = unavailable("no technology library")``.

    Returns a dict with ``status`` (ok | ok_with_findings | failed | unavailable), ``generic`` (cells by type, total
    cells, flip-flops, latches, ``check -assert`` verdict, ``ltp`` depth), ``mapped_area_um2`` (tagged), analytical
    ``memory_bits_analytical``, ``runtime_s`` and ``cached``.
    """
    p = _norm_params("sf_sram_controller", params)
    os.makedirs(os.fspath(outdir), exist_ok=True)
    if liberty:
        liberty = os.fspath(liberty)
        if not os.path.isfile(liberty):
            raise FileNotFoundError(f"liberty file not found: {liberty}")
    return _run("sf_sram_controller", CONTROLLER_FILES, p, outdir, liberty, SCOPE_CONTROLLER, use_cache, timeout)


def synth_subsystem(params: dict | None, outdir, liberty: str | None = None, *, use_cache: bool = True,
                    timeout: int = 3600) -> dict:
    """Synthesize the integrated ``sf_sram_subsystem`` (controller + banks of ``sf_sram_core``) once, with a small
    ``BANK_DEPTH``, to show that the integrated top elaborates and synthesizes.  Arrays become flip-flops."""
    p = _norm_params("sf_sram_subsystem", params)
    os.makedirs(os.fspath(outdir), exist_ok=True)
    if liberty:
        liberty = os.fspath(liberty)
    return _run("sf_sram_subsystem", SUBSYSTEM_FILES, p, outdir, liberty, SCOPE_SUBSYSTEM, use_cache, timeout)


def synth_design(top: str, files: list[str], incdirs: list[str], params: dict | None, outdir, liberty: str | None = None, *,
                 scope: str, name: str, use_cache: bool = True, timeout: int = 3600, extra: dict | None = None) -> dict:
    """Same flow (generic gates, ``check -assert``, latch check, ``ltp``, optional Liberty mapping, caching) for any
    Verilog top: used for the vendored SFB3 bridge / fabric top.  ``params`` are integer ``chparam`` overrides."""
    p = {}
    for k, v in (params or {}).items():
        if isinstance(v, bool):
            v = int(v)
        if not isinstance(v, int):
            raise ValueError(f"parameter {k}={v!r}: only integer parameters are supported")
        p[k] = v
    for f in files:
        if not os.path.isfile(f):
            raise FileNotFoundError(f)
    os.makedirs(os.fspath(outdir), exist_ok=True)
    lib = os.fspath(liberty) if liberty else None
    return _run(top, list(files), p, outdir, lib, scope, use_cache, timeout, extra=extra, incdirs=list(incdirs),
                tag_prefix=name)


SWEEP_FIELDS = ["mode", "status", "top", "banks", "masters", "max_out", "perf", "data_width", "bank_depth",
                "uniform_lat", "cells", "flip_flops", "latches", "latch_free", "check_ok", "logic_depth_levels",
                "mapped_area_um2", "mapped_cells", "memory_bits_analytical", "runtime_s", "cached", "error"]


def _row(res: dict) -> dict:
    p, g = res["params"], res.get("generic") or {}
    gv = g if isinstance(g, dict) and "total_cells" in g else {}
    ld = gv.get("logic_depth") or {}
    return {"mode": res["mode"], "status": res["status"], "top": res["top"], "banks": p["NUM_BANKS"],
            "masters": p["NUM_MASTERS"], "max_out": p["MAX_OUT"], "perf": p["PERF_EN"], "data_width": p["DATA_WIDTH"],
            "bank_depth": p["BANK_DEPTH"], "uniform_lat": p["UNIFORM_LAT"], "cells": gv.get("total_cells"),
            "flip_flops": gv.get("flip_flops"), "latches": gv.get("latches"), "latch_free": gv.get("latch_free"),
            "check_ok": (gv.get("check_assert") or {}).get("ok"), "logic_depth_levels": ld.get("levels"),
            "mapped_area_um2": (res.get("mapped_area_um2") or {}).get("value"),
            "mapped_cells": (res.get("mapped") or {}).get("cells"),
            "memory_bits_analytical": (res.get("memory_bits_analytical") or {}).get("value"),
            "runtime_s": res.get("runtime_s"), "cached": res.get("cached"), "error": res.get("error")}


def synth_sweep(banks=(2, 4, 8, 16), masters=(4,), max_out=(1,), perf=(0, 1), outdir=None, liberty: str | None = None,
                *, data_width: int = 32, bank_depth: int = 1024, prio_en: int = 0, jobs: int = 4,
                use_cache: bool = True, name: str | None = None) -> list[dict]:
    """Sweep the controller over bank count / masters / MAX_OUT / PERF_EN and write ``<name>.csv`` + ``<name>.json``
    into ``outdir`` (default name ``controller_sweep_generic`` or ``controller_sweep_<liberty basename>``).

    Controller logic only: the SRAM arrays are NOT synthesized to gates.  Returns the list of per-run result dicts."""
    if outdir is None:
        raise ValueError("outdir is required")
    outdir = os.fspath(outdir)
    os.makedirs(outdir, exist_ok=True)
    grid = [dict(NUM_BANKS=b, NUM_MASTERS=m, MAX_OUT=o, PERF_EN=e, DATA_WIDTH=data_width, BANK_DEPTH=bank_depth,
                 PRIO_EN=prio_en) for b in banks for m in masters for o in max_out for e in perf]

    def one(p):
        return synth_controller(p, outdir, liberty, use_cache=use_cache)

    if jobs > 1 and len(grid) > 1:
        with ThreadPoolExecutor(max_workers=jobs) as ex:
            results = list(ex.map(one, grid))
    else:
        results = [one(p) for p in grid]
    stem = name or ("controller_sweep_generic" if not liberty else
                    "controller_sweep_" + re.sub(r"\W+", "_", os.path.splitext(os.path.basename(liberty))[0]).lower())
    if liberty and name is None:
        try:
            nl = tech.nangate45_liberty()
            if nl["available"] and os.path.abspath(nl["path"]) == os.path.abspath(liberty):
                stem = "controller_sweep_nangate45"
        except Exception:
            pass
    rows = [_row(r) for r in results]
    with open(os.path.join(outdir, stem + ".csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=SWEEP_FIELDS)
        w.writeheader()
        w.writerows(rows)
    meta = {"label": "synthesized", "scope": SCOPE_CONTROLLER, "mode": "liberty-mapped" if liberty else "generic",
            "technology": liberty_label(liberty) if liberty else None,
            "area_note": ("mapped area is for THAT library only; not transferable to another node"
                          if liberty else "no technology library: area_um2 is unavailable, gate counts are not area"),
            "depth_note": DEPTH_LABEL, "signoff_timing": signoff_timing_status(),
            "yosys": (tools.yosys() or {}).get("version"), "rtl_sha256": rtl_hash(),
            "sweep": {"banks": list(banks), "masters": list(masters), "max_out": list(max_out), "perf": list(perf),
                      "data_width": data_width, "bank_depth": bank_depth, "prio_en": prio_en},
            "rows": rows, "results": [portable(r) for r in results]}
    with open(os.path.join(outdir, stem + ".json"), "w") as fh:
        json.dump(meta, fh, indent=1, default=str)
    return results
