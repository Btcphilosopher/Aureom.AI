"""Second-simulator differential check (Verilator versus Icarus Verilog) of SRAMLab's RTL testbenches.

Layer: **verification**.  Every ``rtl_simulated`` number SRAMLab reports comes from a simulator run of the
vendored RTL.  A simulator defect therefore becomes a wrong "RTL" number without any other symptom -- this
happened: Verilator 5.020 (Ubuntu 24.04) mis-simulated three of the testbenches SRAMLab inherited
(docs/03_verification.md, "Harness portability").  This module re-runs representative invocations of each
testbench, with byte-identical stimulus files and plusargs, under an independent simulator (Icarus 12) and
demands that every tagged result line is identical.

* controller (sf_sram_subsystem): handled by ``rtlrun.compare(..., simulator="icarus")`` (three-way:
  Python model = Verilator = Icarus); summarised here by :func:`controller_check`.
* ECC codec (sf_ecc_enc / sf_ecc_dec), ECC bank (MemoryCore sf_sram_bank: latency, throughput, RMW,
  scrub, fault injection), MBIST (P78 sf_sram_mbist: cycle counts, fault detection, coverage mode):
  :func:`study_tb_check`.

Nothing here decides a study result; it only states whether two simulators agree on the RTL's output.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time

from . import tools
from .prng import SplitMix64
from .studies import ecc as E
from .studies import mbist as M

BUILD_ROOT = E.BUILD_ROOT

# tagged result lines: "TAG ..." in upper case (Verilator's "- file:line: Verilog $finish" and Icarus's
# "file:line: $finish called at ..." lines do not match)
_TAG = re.compile(r"^([A-Z][A-Z_0-9]*)\s")


def tagged_lines(out: str) -> list[str]:
    return [ln.strip() for ln in out.splitlines() if _TAG.match(ln.strip())]


def icarus_build(prefix: str, top: str, srcs: list, generics: dict, incs=None) -> str:
    iv = tools.iverilog()
    if iv is None or shutil.which("vvp") is None:
        raise RuntimeError("Icarus Verilog (iverilog + vvp) is not installed: the second-simulator check is unavailable")
    h = hashlib.sha256()
    for f in srcs:
        with open(f, "rb") as fh:
            h.update(fh.read())
    key = hashlib.sha256(json.dumps([prefix, top, {k: str(v) for k, v in generics.items()}, h.hexdigest(), iv["version"]],
                                    sort_keys=True).encode()).hexdigest()[:16]
    mdir = os.path.join(BUILD_ROOT, f"ivl_{prefix}_{key}")
    vvp = os.path.join(mdir, "sim.vvp")
    if os.path.exists(vvp):
        return vvp
    os.makedirs(mdir, exist_ok=True)
    cmd = [iv["exe"], "-g2012", "-s", top, "-o", vvp] + [f"-I{i}" for i in (incs or [])]
    cmd += [f"-P{top}.{k}={v}" for k, v in generics.items()] + list(srcs)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(vvp):
        raise RuntimeError(f"Icarus build of {top} {generics} failed:\n" + (r.stdout + r.stderr)[-3000:])
    return vvp


def icarus_run(vvp: str, args: list, timeout: int = 3600) -> str:
    r = subprocess.run([shutil.which("vvp"), "-n", vvp] + list(args), capture_output=True, text=True, timeout=timeout)
    return r.stdout + r.stderr


def _diff(a: list[str], b: list[str]) -> dict | None:
    for i, (x, y) in enumerate(zip(a, b)):
        if x != y:
            return {"line": i, "verilator": x, "icarus": y}
    if len(a) != len(b):
        return {"line": min(len(a), len(b)), "verilator": f"{len(a)} lines", "icarus": f"{len(b)} lines"}
    return None


def _pair(label: str, prefix: str, top: str, srcs: list, incs: list, gen: dict, args: list, timeout=3600) -> dict:
    t0 = time.time()
    vexe = E.build_tb(prefix, top, srcs, gen, incs)
    vout = E.run_sim(vexe, args, timeout=timeout)
    t1 = time.time()
    ivvp = icarus_build(prefix, top, srcs, gen, incs)
    iout = icarus_run(ivvp, args, timeout=timeout)
    t2 = time.time()
    a, b = tagged_lines(vout), tagged_lines(iout)
    d = _diff(a, b)
    errs = [ln for ln in a + b if ln.startswith(("ERROR", "ANOMALY"))]
    return {"case": label, "testbench": top, "generics": gen, "args": [x.split("=")[0] + "=..." if "/" in x else x for x in args],
            "lines_compared": min(len(a), len(b)), "identical": d is None and not errs and len(a) > 0,
            "first_difference": d, "errors": errs[:3], "verilator_s": round(t1 - t0, 1), "icarus_s": round(t2 - t1, 1)}


# ---------------------------------------------------------------------------------------------- cases
def _codec_case(k: int, wd: str) -> dict:
    ref = E.SecdedRef(k)
    rng = SplitMix64(0xEC0DEC ^ (k * 0x9E3779B97F4A7C15 & ((1 << 64) - 1)))
    vecs = E.codec_vectors(ref, rng, True)
    vf = os.path.join(wd, f"codec{k}.vec")
    with open(vf, "w") as f:
        for kind, d, m, _ in vecs:
            f.write(f"{kind} {E._hexw(d, k)} {E._hexw(m, ref.n)}\n")
    return _pair(f"ecc_codec K={k} ({len(vecs)} vectors)", "ecc_codec", "tb_sramlab_ecc_codec", E.CODEC_RTL + [E.TB_CODEC],
                 E.INCS, {"K": k}, [f"+vec={vf}"])


def _bank_case(dw: int, ecc: int, rl: int, wd: str, quick: bool) -> dict:
    gen = {"DW": dw, "ECC_EN": ecc, "READ_LATENCY": rl, "DEPTH": 64, "SCRUB_WAIT": 64, "FAULT_INJECT": 1}
    args = ["+lat=1", f"+thr={64 if quick else 256}", "+seed=7"]
    if ecc:
        ref = E.SecdedRef(dw)
        rng = SplitMix64(0xF00D ^ dw)
        vecs = E.fault_vectors(ref, rng, 64, True)
        vecs = vecs[: (80 if quick else len(vecs))]
        vf = os.path.join(wd, f"bank{dw}_{rl}.fvec")
        with open(vf, "w") as f:
            for row, d, m, _ in vecs:
                f.write(f"{row} {E._hexw(d, dw)} {E._hexw(m, ref.n)}\n")
        args += ["+rmw=1", f"+scrub={1000 if quick else 4000}", f"+fvec={vf}"]
    return _pair(f"ecc_bank DW={dw} ECC_EN={ecc} RL={rl}", "ecc_bank", "tb_sramlab_ecc_bank", E.ECC_RTL + [E.TB_BANK],
                 E.INCS, gen, args)


def _mbist_script_case(wd: str, quick: bool) -> dict:
    nb, rows, w, rl, nf = 2, 16, 32, 1, 2
    lines = ["0"]
    tg = 0
    for algo in (M.ALG_MARCH_CM, M.ALG_MATS_P):
        for nbk in (1, 2):
            tg += 1
            lines.append(M.cmd_run(tg, algo=algo, sel=M.SEL_SEQ, bmask=(1 << nbk) - 1, lo=0, hi=rows - 1))
    tg += 1
    lines.append(M.cmd_run(tg, M.ALG_MARCH_CM, sweep=1, sel=M.SEL_SEQ, bmask=1, lo=0, hi=rows // 4 - 1))
    # injected faults (P78 fault-model memory): a stuck-at, a transition and a coupling fault, then detection runs
    pop = M.fault_population(rows, w, stride=997)
    picks = [pop[3], pop[w * 4 + 7], pop[-1]]
    for i, (_, _, fl) in enumerate(picks):
        lines.append("0")
        lines.append(M.cmd_fault(i % nb, 0, fl))
        tg += 1
        lines.append(M.cmd_run(tg, M.ALG_MARCH_CM, sel=M.SEL_SEQ, bmask=(1 << nb) - 1, lo=0, hi=rows - 1))
        tg += 1
        lines.append(M.cmd_run(tg, M.ALG_MATS_P, sel=M.SEL_SEQ, bmask=(1 << nb) - 1, lo=0, hi=rows - 1, stop=1))
    lines.append("0")
    tg += 1
    lines.append(M.cmd_run(tg, M.ALG_MARCH_CM, sel=M.SEL_SEQ, bmask=(1 << nb) - 1, lo=0, hi=rows - 1, traffic=1))
    lines.append("5 200")
    sf = os.path.join(wd, "mbist_script.txt")
    with open(sf, "w") as f:
        f.write("\n".join(lines) + "\n")
    return _pair(f"mbist_run script NBANK={nb} ROWS={rows} W={w} ({tg} runs incl. 3 injected faults + traffic)", "mbist_run",
                 "tb_sramlab_mbist_run", M.RUN_SRCS, M.RUN_INCS, {"NBANK": nb, "ROWS": rows, "W": w, "RL": rl, "NF": nf},
                 [f"+script={sf}"])


def _mbist_cov_case(wd: str, quick: bool) -> dict:
    rows, w = 4, 8
    pop = M.fault_population(rows, w, stride=7 if quick else 1)
    cf = os.path.join(wd, "cov.txt")
    with open(cf, "w") as f:
        f.write(f"{len(M.CONFIGS)}\n")
        for _, runs in M.CONFIGS:
            f.write(f"{len(runs)} " + " ".join(f"{a} {p} {int(s)}" for a, p, s in runs) + "\n")
        for _, _, fl in pop:
            f.write(f"0 {fl.t} {fl.row} {fl.bit} {fl.row2} {fl.bit2} {fl.v} {fl.v2}\n")
    return _pair(f"mbist_run coverage ROWS={rows} W={w} ({len(pop)} faults x {len(M.CONFIGS)} configurations)", "mbist_run",
                 "tb_sramlab_mbist_run", M.RUN_SRCS, M.RUN_INCS, {"NBANK": 1, "ROWS": rows, "W": w, "RL": 1, "NF": 1},
                 [f"+cov={cf}"])


STUDY_GROUPS = ("codec", "bank", "mbist_script", "mbist_cov")


def study_tb_check(quick: bool = True, progress=None, only=None) -> dict:
    """Run the ECC and MBIST testbenches under Verilator and Icarus with identical inputs; compare every tagged line.
    ``only``: subset of STUDY_GROUPS (default: all)."""
    only = set(only or STUDY_GROUPS)
    bad = only - set(STUDY_GROUPS)
    if bad:
        raise ValueError(f"unknown xsim group(s) {sorted(bad)}; choose from {STUDY_GROUPS}")
    wd = tempfile.mkdtemp(prefix="sramlab_xsim_")
    res = []

    def go(fn, *a):
        try:
            r = fn(*a)
        except Exception as e:                       # build failure etc.: reported, never hidden
            r = {"case": f"{fn.__name__}{a[:-2] if len(a) > 2 else ''}", "identical": False, "error": str(e)[-800:]}
        res.append(r)
        if progress:
            progress(f"[xsim] {r['case']}: {'identical' if r['identical'] else 'DIFFERENT'} "
                     f"({r.get('lines_compared', 0)} lines)")
    try:
        if "codec" in only:
            for k in ((32, 64) if quick else (32, 64, 128)):
                go(_codec_case, k, wd)
        if "bank" in only:
            for dw, ecc, rl in ([(32, 1, 1), (32, 0, 1)] if quick else [(32, 1, 1), (32, 0, 1), (64, 1, 2), (64, 0, 2)]):
                go(_bank_case, dw, ecc, rl, wd, quick)
        if "mbist_script" in only:
            go(_mbist_script_case, wd, quick)
        if "mbist_cov" in only:
            go(_mbist_cov_case, wd, quick)
    finally:
        shutil.rmtree(wd, ignore_errors=True)
    return {"cases": len(res), "identical": sum(1 for r in res if r["identical"]), "groups": sorted(only), "quick": quick,
            "lines_compared": sum(r.get("lines_compared", 0) for r in res), "results": res,
            "simulators": {"verilator": (tools.verilator() or {}).get("version"), "icarus": (tools.iverilog() or {}).get("version")},
            "provenance": "rtl_simulated",
            "meaning": "identical = the two simulators produced the same tagged output for the same RTL and stimulus; "
                       "it is evidence against simulator defects, not a correctness proof of the RTL"}


def controller_check(n_req: int = 150, seed: int = 11, quick: bool = True, progress=None) -> dict:
    """Three-way check of the controller: Python model = Verilator = Icarus on the same cases (quick subset by default)."""
    from . import rtlrun, verify
    cases = verify.case_list(quick=quick)
    out = []
    for pn, wn in cases:
        p, scripts, ready, flush = verify.build_case(pn, wn, n_req, seed)
        row = {"label": f"{pn}/{wn}"}
        for sim in ("verilator", "icarus"):
            try:
                v = rtlrun.compare(p, scripts, ready, label=row["label"], flush_cycles=flush, simulator=sim)
                row[sim] = {"ok": v["ok"], "cycles": v["cycles_compared"], "divergence": v["first_trace_divergence"]}
            except Exception as e:
                row[sim] = {"ok": False, "error": str(e)[-400:]}
        row["ok"] = row["verilator"]["ok"] and row["icarus"]["ok"]
        out.append(row)
        if progress:
            progress(f"[3-way] {row['label']}: {'model = verilator = icarus' if row['ok'] else 'MISMATCH'}")
    return {"cases": len(out), "passed": sum(1 for r in out if r["ok"]),
            "cycles_compared_per_simulator": sum(r["verilator"].get("cycles", 0) for r in out), "results": out,
            "provenance": "rtl_simulated"}


def workaround_negative_control() -> dict:
    """Rebuild the MBIST testbench WITHOUT the Verilator --timing optimiser workaround and re-run the MBIST script case.

    On a Verilator affected by defect B (5.020) the Verilator output must now DIFFER from Icarus -- which shows both that
    the workaround is needed and that the cross-check is able to detect a simulator defect.  On a Verilator without the
    defect the outputs stay identical and the result says so (informational, not a failure)."""
    saved = E.VL_TIMING_WORKAROUND
    wd = tempfile.mkdtemp(prefix="sramlab_xsim_nc_")
    try:
        E.VL_TIMING_WORKAROUND = ()
        r = _mbist_script_case(wd, True)
    finally:
        E.VL_TIMING_WORKAROUND = saved
        shutil.rmtree(wd, ignore_errors=True)
    return {"case": r["case"], "verilator": (tools.verilator() or {}).get("version"),
            "outputs_differ_without_workaround": not r["identical"], "first_difference": r.get("first_difference"),
            "interpretation": ("this Verilator mis-simulates the testbench without the workaround; the cross-check detected it"
                               if not r["identical"] else
                               "this Verilator simulates the testbench correctly even without the workaround (defect B not present)")}
