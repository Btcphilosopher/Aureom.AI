"""CLI commands that wrap the study modules: ecc, mbist, synth, floorplan, power, report, dashboard, export.

Each command writes its dataset into ``--dataset-dir`` (default: the package ``data/``) so ``report`` and ``dashboard``
pick it up, and an experiment record into ``--out`` like every other command.
"""
from __future__ import annotations

import json
import os
import time

from . import record as R
from .cli import _save, _say
from .config import load_config

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")


def _dd(a) -> str:
    d = getattr(a, "dataset_dir", None) or DATA
    os.makedirs(d, exist_ok=True)
    return d


def _dump(a, name, obj) -> str:
    p = os.path.join(_dd(a), name)
    with open(p, "w") as f:
        json.dump(obj, f, indent=1, default=R._json_default)
    _say(f"dataset: {p}")
    return p


def _ints(s):
    return tuple(int(x) for x in s.split(","))


# ------------------------------------------------------------------------------------------------ ecc / mbist
def cmd_ecc(a):
    from .studies import ecc
    t0 = time.time()
    res = ecc.run_ecc_study(word_bits=_ints(a.word_bits), outdir=_dd(a), quick=a.quick)
    _dump(a, "ecc_study.json", res)
    _say("ECC study sections: " + ", ".join(k for k in res if not k.startswith("_")))
    _save(a, "ecc", None, res, t0=t0)
    return 0


def cmd_mbist(a):
    from .studies import mbist
    t0 = time.time()
    res = mbist.run_mbist_study(banks=_ints(a.banks), bank_depth=a.bank_depth, word_bits=a.word_bits, outdir=_dd(a), quick=a.quick)
    _dump(a, "mbist_study.json", res)
    _say("MBIST study sections: " + ", ".join(k for k in res if not k.startswith("_")))
    _say("NOTE: coverage figures are coverage of the injected simulation fault model, not manufacturing defect coverage")
    _save(a, "mbist", None, res, t0=t0)
    return 0


# ------------------------------------------------------------------------------------------------ synth
def cmd_synth(a):
    from . import synth, tech
    t0 = time.time()
    out = os.path.join(_dd(a), "synth")
    lib = None
    if a.liberty == "nangate45":
        nl = tech.nangate45_liberty()
        if not nl.get("available"):
            if not a.fetch:
                _say("Nangate45 liberty not present. Re-run with --fetch to download it (pinned by SHA-256; not bundled), "
                     "or use --liberty none for generic gate counts. Mapped area is therefore UNAVAILABLE.")
                return 2
            tech.fetch_nangate45()
            nl = tech.nangate45_liberty()
        lib = nl["path"]
    elif a.liberty not in ("none", None):
        lib = a.liberty
    res = synth.synth_sweep(banks=_ints(a.banks), masters=_ints(a.masters), max_out=_ints(a.max_out), perf=_ints(a.perf),
                            outdir=out, liberty=lib, data_width=a.data_width, bank_depth=a.bank_depth, jobs=a.jobs)
    rows = [synth._row(r) for r in res]
    _say(f"{'banks':>5s} {'perf':>4s} {'cells':>8s} {'FFs':>6s} {'depth':>5s} {'mapped um2':>12s}   (controller logic only; "
         f"{'liberty-mapped' if lib else 'generic gates: NOT area'})")
    for r in rows:
        _say(f"{r['banks']:5d} {r['perf']:4d} {str(r['cells']):>8s} {str(r['flip_flops']):>6s} {str(r['logic_depth_levels']):>5s} "
             f"{str(r['mapped_area_um2']) if r['mapped_area_um2'] is not None else 'unavailable':>12s}")
    _save(a, "synth", None, {"rows": rows, "liberty": lib, "label": "synthesized"}, t0=t0)
    return 0


# ------------------------------------------------------------------------------------------------ floorplan / power
def cmd_floorplan(a):
    from . import phys, thermal
    t0 = time.time()
    cfg = load_config(a.config)
    rep = phys.area_report(cfg)
    fp = phys.floorplan(cfg, outdir=os.path.join(_out(a), "floorplan")) if cfg["physical"]["backend"] == "asic_macro" else None
    mf = rep["memory_footprint"]
    _say(f"[{cfg['name']}] backend {rep['backend']}, technology profile {rep['technology_profile']}")
    ta = mf.get("total_macro_area_um2")
    _say("  macro footprint: " + (f"{ta['value'] / 1e6:.4f} mm^2 ({mf['instances_total']['value']} macros, bit utilisation "
                                  f"{mf['bit_utilisation']['value']:.4f}) [{ta['provenance']}]" if isinstance(ta, dict) and ta.get("value") else "unavailable"))
    da = rep.get("die_area", {})
    _say(f"  die area: {da.get('value') if da.get('value') is not None else 'UNAVAILABLE'}" + ("" if da.get("value") is not None else f"  ({da.get('reason')})"))
    _say("  floorplan: " + (f"generated geometry written ({fp['label']})" if fp else "not generated (needs backend asic_macro)"))
    out = {"area_report": rep, "floorplan": fp}
    if a.thermal and fp:
        from . import experiments as E
        rr, m, _ = E.run_once(cfg)
        th = thermal.thermal_handoff(fp, None, os.path.join(_out(a), "thermal"), run_metrics=m)
        out["thermal_handoff"] = th
        _say("  thermal hand-off: geometry+activity written; power " + ("written" if th.get("power_file") else "NOT written (no validated energy profile)"))
    if a.dataset:
        _dump(a, "phys.json", {"area_report": rep, "floorplan_summary": {k: (fp or {}).get(k) for k in ("label", "disclaimer", "macro", "tiling", "macro_array_bbox_um2", "die", "routing_estimate")}})
        if "thermal_handoff" in out:
            _dump(a, "thermal.json", out["thermal_handoff"])
    _save(a, "floorplan", cfg, {"area_report": rep, "floorplan_label": (fp or {}).get("label")}, t0=t0)
    return 0


def cmd_power(a):
    from . import experiments as E, power
    t0 = time.time()
    cfg = load_config(a.config)
    rr, m, _ = E.run_once(cfg)
    prof = power.load_energy_profile(a.energy_profile) if a.energy_profile else None
    rep = power.energy_report(m, prof, cfg=cfg, clock_mhz=cfg["physical"].get("clock_mhz"))
    _say(rep["statement"])
    act = rep["activity"]
    for k in ("reads", "writes", "array_bit_activations", "bank_busy_cycles"):
        if k in act:
            v = act[k]
            _say(f"  {k}: {v['value'] if isinstance(v, dict) else v}  [simulated]")
    ab = rep["activity_based_estimate"]
    _say("  energy: " + ("UNAVAILABLE - " + str(ab.get("reason")) if ab.get("value") is None and "reason" in ab else "see record"))
    if a.dataset:
        _dump(a, "power.json", rep)
    _save(a, "power", cfg, {"energy_report": rep}, power={"status": "energy_report", "profile_loaded": bool(prof)}, t0=t0)
    return 0


# ------------------------------------------------------------------------------------------------ report / dashboard / export
def cmd_report(a):
    from . import report
    res = report.build_all(_dd(a), a.report_dir)
    _say(f"report: {res['report']}")
    _say(f"csv exports: {len(res['csv'])} files in {os.path.dirname(res['csv'][0]) if res['csv'] else '-'}")
    missing = [k for k, v in res["datasets"].items() if not v]
    if missing:
        _say("datasets not present (sections say so): " + ", ".join(missing))
    if a.dashboard:
        from . import dashboard
        _say("dashboard: " + dashboard.build(_dd(a), a.dashboard_out))
    return 0


def cmd_dashboard(a):
    from . import dashboard
    _say("dashboard: " + dashboard.build(_dd(a), a.output))
    return 0


def cmd_export(a):
    from . import report
    data = report.load_data(_dd(a))
    files = report.write_csvs(data, os.path.join(_out(a), "csv"))
    if a.config:
        from . import experiments as E
        cfg = load_config(a.config)
        rr, m, _ = E.run_once(cfg)
        files += [os.path.join(_out(a), f) for f in R.export_run(rr, _out(a), cfg["name"])]
        with open(os.path.join(_out(a), cfg["name"] + "_metrics.json"), "w") as f:
            json.dump(m, f, indent=1, default=R._json_default)
        files.append(os.path.join(_out(a), cfg["name"] + "_metrics.json"))
    for f in files:
        _say("exported " + f)
    return 0


def _out(a):
    return a.out or os.path.join(os.getcwd(), "sramlab_results")


def register(ap):
    sp = ap._sramlab_subparsers

    def add(name, fn, help_):
        p = sp.add_parser(name, help=help_)
        p.set_defaults(fn=fn)
        p.add_argument("--dataset-dir", dest="dataset_dir", help="where datasets are read/written (default: package data/)")
        return p

    p = add("ecc", cmd_ecc, "ECC (SECDED) cost analysis: storage, logic, latency, RMW, scrub, fault reporting (RTL)")
    p.add_argument("--word-bits", default="32,64,128", dest="word_bits"); p.add_argument("--quick", action="store_true")
    p = add("mbist", cmd_mbist, "MBIST evaluation: cycles, per-bank time, overhead, failure reporting, injected-fault coverage (RTL)")
    p.add_argument("--banks", default="2,4,8,16"); p.add_argument("--bank-depth", type=int, default=256, dest="bank_depth")
    p.add_argument("--word-bits", type=int, default=32, dest="word_bits"); p.add_argument("--quick", action="store_true")
    p = add("synth", cmd_synth, "Yosys synthesis sweep of the controller (generic gates; mapped area only with a real liberty)")
    p.add_argument("--banks", default="2,4,8,16"); p.add_argument("--masters", default="4"); p.add_argument("--max-out", default="1", dest="max_out")
    p.add_argument("--perf", default="0,1"); p.add_argument("--liberty", default="none", help="none | nangate45 | path to a .lib")
    p.add_argument("--fetch", action="store_true", help="download the pinned Nangate45 liberty if absent")
    p.add_argument("--data-width", type=int, default=32, dest="data_width"); p.add_argument("--bank-depth", type=int, default=1024, dest="bank_depth")
    p.add_argument("--jobs", type=int, default=2)
    p = add("floorplan", cmd_floorplan, "macro footprint / generated floorplan / area report; optional ThermalLab hand-off")
    p.add_argument("config"); p.add_argument("--thermal", action="store_true"); p.add_argument("--dataset", action="store_true", help="write data/phys.json (+thermal.json)")
    p = add("power", cmd_power, "power/energy provenance for a run (activity always; energy only with a validated profile)")
    p.add_argument("config"); p.add_argument("--energy-profile", dest="energy_profile"); p.add_argument("--dataset", action="store_true")
    p = add("report", cmd_report, "engineering report + CSV exports from the datasets")
    p.add_argument("--report-dir", dest="report_dir"); p.add_argument("--dashboard", action="store_true"); p.add_argument("--dashboard-out", dest="dashboard_out")
    p = add("dashboard", cmd_dashboard, "build the self-contained browser dashboard")
    p.add_argument("--output")
    p = add("export", cmd_export, "raw data export: dataset CSVs and, with a config, per-transaction/counter/metrics files")
    p.add_argument("config", nargs="?")
