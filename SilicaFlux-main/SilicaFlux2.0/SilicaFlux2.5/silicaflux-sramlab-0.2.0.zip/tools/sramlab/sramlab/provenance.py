"""Result provenance: every number SRAMLab reports carries one of these labels.

  analytical    closed-form ceiling / estimate (never mixed with simulation)
  simulated     produced by the Python cycle model (itself verified against the RTL, see verify.py)
  rtl_simulated produced by running the real RTL in Verilator (or imported from a sibling SilicaFlux
                package's committed RTL-simulation report, then ``source`` names that report)
  synthesized   produced by a synthesis tool run on the RTL (Yosys generic gates = gate counts, NOT
                area; with a real Liberty = mapped cell area for THAT library only)
  measured      measured on physical hardware.  NO SilicaFlux silicon / FPGA measurement exists, so
                nothing in SRAMLab is ever labelled ``measured`` unless a user supplies a measurement
                file with its own provenance.
  assumed       a user-/package-supplied assumption (e.g. a clock frequency)
  unavailable   cannot be produced with the tools / data present; the value is None and ``reason`` says why

Use :func:`tag` to build a labelled value and :func:`strip` to read it back.
"""
from __future__ import annotations

LABELS = ("analytical", "simulated", "rtl_simulated", "synthesized", "measured", "assumed", "unavailable")
# the four classes the dashboard must show on every graph (brief section 17); the others fold into them
DASHBOARD_CLASS = {"analytical": "analytical", "simulated": "simulated", "rtl_simulated": "simulated",
                   "synthesized": "synthesized", "measured": "measured", "assumed": "analytical",
                   "unavailable": "unavailable"}


def tag(value, label: str, source: str = "", **extra) -> dict:
    if label not in LABELS:
        raise ValueError(f"unknown provenance label {label!r}; use one of {LABELS}")
    d = {"value": value, "provenance": label, "source": source}
    d.update(extra)
    return d


def unavailable(reason: str, **extra) -> dict:
    return tag(None, "unavailable", reason=reason, **extra)


def strip(x):
    """Return the bare value of a tagged dict (or the object itself)."""
    return x["value"] if isinstance(x, dict) and "provenance" in x and "value" in x else x
