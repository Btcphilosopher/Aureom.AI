"""Vector memory study (brief section 9).

Part 1 - controller study (simulated): a single vector master issues 128-bit / 256-bit accesses through the
verified SRAMController model.  The controller is word-granular (no byte-granular reads), so a vector that is not
word-aligned fetches extra words; ``alignment_overhead = fetched bytes / useful bytes``.  Cases: aligned, word-
misaligned, byte-misaligned (cross-word), cross-bank, partial stores, strided.

Part 2 - cross-check (rtl_simulated, imported): the committed RTL-simulation benchmark of the SilicaFlux
VectorScratch (P76, ``data/imported/p76_bench.csv``) is used to validate this tool's alignment arithmetic and bank-slot
ceiling.  For every deterministic sequential workload on 32-bit banks the model predicts (a) the number of word accesses
and (b) the cycle count ``max(vectors, max_bank_slots) + READ_LATENCY + 2``; both are compared with the RTL numbers.
"""
from __future__ import annotations

import csv
import hashlib
import os

from .. import experiments as E
from ..config import load_config
from ..provenance import tag

HERE = os.path.dirname(os.path.abspath(__file__))
IMPORTED = os.path.join(os.path.dirname(os.path.dirname(HERE)), "data", "imported")


def vector_cases():
    # (name, workload options)
    return [
        ("aligned_load", {"misalign_bytes": 0}),
        ("word_misaligned_load", {"misalign_bytes": 4}),
        ("byte_misaligned_load", {"misalign_bytes": 1}),
        ("cross_bank_load", {"misalign_bytes": 12}),
        ("aligned_store", {"misalign_bytes": 0, "store_fraction": 1.0}),
        ("partial_store", {"misalign_bytes": 0, "store_fraction": 1.0, "partial_store": True}),
        ("strided_load_64B", {"misalign_bytes": 0, "stride_bytes": 64}),
        ("strided_load_bank_stride", {"misalign_bytes": 0, "stride_bytes": 256}),
    ]


def run_vector_study(word_bits=(32, 128), vector_bits=(128, 256), banks=(4, 8, 16), max_out: int = 8, masters: int = 4,
                     requests: int = 1500, replications: int = 3, capacity_bytes: int = 65536,
                     progress=None) -> dict:
    rows = []
    for ww in word_bits:
        for vb in vector_bits:
            for nb in banks:
                for name, opts in vector_cases():
                    cfg = load_config({
                        "name": f"vec_{name}_{vb}_w{ww}_b{nb}",
                        "memory": {"word_width_bits": ww, "banks": nb, "bank_depth_words": capacity_bytes // (nb * ww // 8)},
                        "controller": {"masters": masters, "max_outstanding": max_out},
                        "workload": {"kind": "vector_load", "requests_per_master": requests, "vector_bits": vb,
                                     "seed": 7, **opts}})
                    if progress:
                        progress(cfg["name"])
                    b = E.benchmark(cfg, replications)
                    s = b["summary"]
                    fm = b["first_run_metrics"]
                    useful, fetched = s["useful_bytes_per_cycle"], fm["fetched_bytes_per_cycle"]
                    rows.append({
                        "label": "simulated", "word_bits": ww, "vector_bits": vb, "banks": nb, "case": name,
                        "useful_bytes_per_cycle": useful, "fetched_bytes_per_cycle": fetched,
                        "alignment_overhead": fetched / useful["mean"] if useful["mean"] else float("nan"),
                        "conflict_rate_per_access": s["conflict_rate_per_access"],
                        "read_latency_e2e_mean": s["read_latency_mean"],
                        "peak_array_bytes_per_cycle": fm["analytical"]["array_peak_bytes_per_cycle"],
                        "master_ceiling_bytes_per_cycle": fm["analytical"]["master_ceiling_txn_per_cycle"] * ww // 8,
                    })
    return {"label": "simulated", "max_outstanding": max_out, "masters": masters, "capacity_bytes": capacity_bytes, "rows": rows,
            "note": f"{masters} vector masters, each streaming its own region; the controller accepts at most 1 request per master per "
                    "cycle, so each master is bounded by master_ceiling_bytes_per_cycle regardless of the bank count"}


# --------------------------------------------------------------------------- cross-check vs P76 RTL results
def _slots_per_bank(vec_bytes: int, offset: int, nvec: int, nb: int, bank_bytes: int = 4, store: bool = False):
    loads = [0] * nb
    words = 0
    for k in range(nvec):
        a = offset + k * vec_bytes
        first, last = a // bank_bytes, (a + vec_bytes - 1) // bank_bytes
        for w in range(first, last + 1):
            loads[w % nb] += 1
            words += 1
    return loads, words


_OFFSETS = {"aligned": 0, "off1word": 4, "off1byte": 1}


def p76_crosscheck(csv_path: str | None = None) -> dict:
    path = csv_path or os.path.join(IMPORTED, "p76_bench.csv")
    with open(path, "rb") as f:
        digest = hashlib.sha256(f.read()).hexdigest()
    rows = list(csv.DictReader(open(path)))
    checked, exact, details, worst = 0, 0, [], 0
    words_ok = words_n = 0
    for r in rows:
        w = r["workload"]
        fam = next((f for f in ("seq_load", "seq_store") if w.startswith(f)), None)
        if fam is None or r["dma_duty"] != "0" or r["BANK_MAP"] != "0" or r["BANK_BYTES"] != "4" or r["GS_EN"] != "0":
            continue
        off = next((v for k, v in _OFFSETS.items() if w.endswith(k)), None)
        if off is None:
            continue
        if off != 0 and r["ALIGN_POLICY"] != "2":
            continue                                     # policy rejects misaligned requests: not comparable
        vb, nb, nvec, lat = int(r["VEC_BYTES"]), int(r["NB"]), int(r["vec_req"]), int(r["READ_LATENCY"])
        loads, words = _slots_per_bank(vb, off, nvec, nb)
        pred = max(nvec, max(loads)) + lat + 2
        rtl_cycles = int(r["cycles"])
        checked += 1
        words_n += 1
        words_ok += int(words == int(r["v_word_acc"]))
        ok = pred == rtl_cycles
        exact += int(ok)
        worst = max(worst, abs(pred - rtl_cycles))
        if not ok and len(details) < 10:
            details.append({"config": r["config"], "workload": w, "model_cycles": pred, "rtl_cycles": rtl_cycles})
    return tag({
        "rows_checked": checked, "cycles_exact_match": exact, "max_abs_cycle_error": worst,
        "word_access_count_match": f"{words_ok}/{words_n}", "mismatches": details,
        "csv_sha256": digest,
        "model": "cycles = max(vectors, max over banks of word slots) + READ_LATENCY + 2; "
                 "words = sum over vectors of words covering [addr, addr+V)",
        "scope": "deterministic sequential load/store streams, LOW bank map, 32-bit banks, DMA idle, "
                 "split/merge alignment policy (the rows where the arithmetic is closed-form)",
    }, "rtl_simulated", "data/imported/p76_bench.csv (P76 reports/bench.csv, imported RTL-simulation rows) vs "
       "SRAMLab closed-form model")
