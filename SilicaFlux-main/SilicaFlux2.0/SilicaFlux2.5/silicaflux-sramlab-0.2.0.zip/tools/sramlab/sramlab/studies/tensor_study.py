"""Tensor memory study (brief section 8): does memory bandwidth limit TensorCore throughput?

Method
  * ``direct`` architecture (TensorScratch P75): the 4x4 INT8 output-stationary array is fed from banked single-port
    SRAM through the verified controller model (sim/tensor.py).  Requirement: 4 A bytes + 4 B bytes per k-step
    = 8 B/cycle for 16 MAC/cycle.
  * Reference run with ample resources (16 banks, MAX_OUT=8, padded pitches, no DMA) gives ``util_ideal``: what this
    model reaches when memory is not the constraint.  A configuration is **memory limited** when its MAC utilisation is
    below 95 % of that reference, **compute limited** otherwise.  The verdict is therefore relative to the same model,
    not to an external claim.
  * ``chunked`` architecture (TENSORCORE 08 DMA command stream): the open-loop LOAD_A/LOAD_B/STORE stream is replayed
    through the controller to measure the sustained operand-delivery bandwidth; the utilisation roof is derived
    analytically (labelled) as ``BW_useful / bytes_per_MAC / 16``.
Cross-reference values from the TENSORCORE 10 benchmark package (RTL-simulated, different system: 4 B/cycle DMA port
into a local buffer) are quoted as context only (``imported_reference``), never mixed with these results.
"""
from __future__ import annotations

from ..config import load_config, controller_params
from ..provenance import tag
from ..sim.controller import CtlParams
from ..sim.tensor import TensorCfg, TensorSystem
from .. import experiments as E

# TENSORCORE 10 benchmark package, docs SCALING.md / BENCHMARKS.md (RTL simulation; port fixed at 4 B/cycle)
IMPORTED_REFERENCE = tag({
    "4x4_sequential_dma_128cubed_mac_util": 0.242,
    "4x4_double_buffered_dma_mac_util": 0.400,
    "port_bound_ceiling_mac_per_cycle_4x4_4B_port": 8,
    "note": "TC08 fills local operand buffers over ONE 32-bit port (<=4 B/cycle shared); not the TensorScratch direct-feed "
            "architecture studied here, so values are context, not a comparison target",
}, "rtl_simulated", "silicaflux-tensorcore10-benchmarks-tensor SCALING.md/BENCHMARKS.md (imported; TC08 RTL under Verilator 5.020)")


def _params(nb: int, mo: int, ww: int, cap: int, nm: int = 4, lat: int = 1) -> CtlParams:
    return CtlParams(num_masters=nm, num_banks=nb, data_width=ww, bank_depth=cap // (nb * ww // 8), max_out=mo,
                     bank_lats=[lat] * nb)


def run_tensor_study(M=16, N=16, K=64, banks=(1, 2, 4, 8, 16), max_out=(1, 2, 4), word_bits=(32,), cap=65536,
                     pitches=("natural", "padded"), dma_duty=(0.0, 0.5), stage=8, progress=None) -> dict:
    ref = TensorSystem(_params(16, 8, 32, cap), TensorCfg(M=M, N=N, K=K, lda=K + 4, ldb=N + 4, a_stage=16, b_stage=16)).run()
    util_ideal = ref.mac_utilisation
    rows = []
    for ww in word_bits:
        for nb in banks:
            for mo in max_out:
                for pit in pitches:
                    lda, ldb = (K, N) if pit == "natural" else (K + 4, N + 4)
                    for duty in dma_duty:
                        if progress:
                            progress(f"w{ww} b{nb} mo{mo} {pit} dma{duty}")
                        r = TensorSystem(_params(nb, mo, ww, cap), TensorCfg(M=M, N=N, K=K, lda=lda, ldb=ldb, a_stage=stage,
                                                                         b_stage=stage, dma_duty=duty)).run()
                        mem_limited = r.mac_utilisation < 0.95 * util_ideal
                        # analytical operand ceiling for this organisation (not a result of the simulation)
                        array_B = nb * ww // 8
                        master_words = min(1.0, mo / 2.0)               # per port, L=1: MAX_OUT/(L+1)
                        ceil_words = min(nb, 2 * master_words)          # A port + B port
                        rows.append({
                            "label": "simulated", "word_bits": ww, "banks": nb, "max_out": mo, "pitch": pit, "dma_duty": duty,
                            "mac_utilisation": r.mac_utilisation, "starvation_fraction": r.starvation_fraction,
                            "a_delivery_words_per_cycle": r.a_delivery_words_per_cycle,
                            "b_delivery_words_per_cycle": r.b_delivery_words_per_cycle,
                            "acc_traffic_words_per_cycle": r.acc_traffic_words_per_cycle,
                            "operand_bytes_per_cycle": r.operand_bytes_per_cycle,
                            "required_operand_bytes_per_cycle": r.required_operand_bytes_per_cycle,
                            "buffer_occupancy_a_mean": r.buffer_occupancy_a_mean, "buffer_occupancy_b_mean": r.buffer_occupancy_b_mean,
                            "dma_overlap_fraction": r.dma_overlap_fraction, "dma_words": r.dma_words,
                            "bank_conflict_events": r.bank_conflict_events, "cycles": r.cycles,
                            "memory_limited": bool(mem_limited),
                            "analytical_operand_words_per_cycle_ceiling": ceil_words,
                            "analytical_array_bytes_per_cycle": array_B,
                        })
    return {"label": "simulated", "gemm": {"M": M, "N": N, "K": K}, "util_ideal_reference": util_ideal,
            "reference_config": "16 banks, MAX_OUT=8, 32-bit, padded pitches, deep look-ahead, no DMA",
            "verdict_rule": "memory_limited = MAC utilisation < 95% of the ideal-resource reference run of the same model",
            "rows": rows, "imported_reference": IMPORTED_REFERENCE, "chunked": run_chunked_stream(cap=cap, M=M, N=N, K=K)}


def run_chunked_stream(cap=65536, M=16, N=16, K=64, tile_k=64, banks=(1, 2, 4, 8), max_out=4) -> dict:
    """TENSORCORE 08 DMA command stream through the controller: sustained delivery bandwidth and the derived roof."""
    out = []
    bytes_per_mac = None
    for nb in banks:
        cfg = load_config({"name": f"tc08_stream_b{nb}", "memory": {"banks": nb, "bank_depth_words": cap // (4 * nb)},
                           "controller": {"masters": 1, "max_outstanding": max_out},
                           "workload": {"kind": "tensor_stream", "requests_per_master": 10 ** 9, "seed": 1,
                                        "tensor_m": M, "tensor_n": N, "tensor_k": K, "tile_k": tile_k}})
        rr, m, _ = E.run_once(cfg, track_data=False)
        reads = [i for i in range(len(rr.tx)) if rr.tx.we[i] == 0]
        read_bytes = len(reads) * 4
        macs = M * N * K
        bytes_per_mac = read_bytes / macs
        bw = read_bytes / rr.cycles                       # operand bytes delivered per cycle
        mac_roof = bw / bytes_per_mac
        out.append({"banks": nb, "stream_cycles": rr.cycles, "words": len(rr.tx), "operand_read_bytes": read_bytes,
                    "operand_bytes_per_cycle": bw, "mac_per_cycle_roof": mac_roof,
                    "util_roof_vs_16mac": min(1.0, mac_roof / 16.0), "label": "analytical-from-simulated-bandwidth"})
    return {"label": "simulated+analytical", "bytes_per_mac": bytes_per_mac, "tile_k": tile_k, "rows": out,
            "note": "roof = simulated sustained operand bandwidth / bytes-per-MAC; compute overhead (~29 cycles per chunk "
                    "per the TC10 benchmarks) would lower real utilisation further and is not modelled here"}
