"""SRAMLab browser dashboard builder (brief section 17).

``build(data_dir, out_path)`` writes ONE self-contained HTML file: inline CSS + JS + SVG, no CDN, no external
fonts or scripts, so it works offline from ``file://``.  Every dataset found under ``data_dir`` is embedded as
JSON in ``<script type="application/json" id="sramlab-data">``; the page renders from that JSON only.

Honesty contract (enforced here and in the page):
  * a dataset that is absent, unreadable or partly ``unavailable`` is embedded as absent / as-is and the page
    shows an explicit UNAVAILABLE panel that says why - nothing is invented or filled in;
  * values are never smoothed, extrapolated or re-labelled; only bulky raw arrays (per-replication rows,
    per-transaction logs, solver logs) are dropped, and every such trim is recorded in ``trim_notes``;
  * the legend states that MEASURED data does not exist (no silicon / FPGA measurement).

Usage:  ``python3 -m sramlab.dashboard [--data DIR] [--out FILE]``  (also wired as ``sramlab dashboard``).
"""
from __future__ import annotations

import argparse
import datetime
import glob
import json
import math
import os
import re
import shutil
import sys
import time
from typing import Any

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                                  # tools/sramlab
DASH_DIR = os.path.join(ROOT, "dashboard")                    # template + assets
DEFAULT_DATA = os.path.join(ROOT, "data")
DEFAULT_OUT = os.path.join(DASH_DIR, "sramlab_dashboard.html")
MAX_BYTES = 6_000_000                                         # hard cap for the finished HTML file
SCHEMA = "sramlab/dashboard/1"
DATA_ELEMENT_ID = "sramlab-data"

# dataset name -> file name under data_dir.  Anything not listed here is ignored.
DATASET_FILES = {
    "rtl_verification": "rtl_verification.json",
    "bank_sweep": "bank_sweep.json",
    "timeline_trace": "timeline_trace.json",
    "tensor_study": "tensor_study.json",
    "vector_study": "vector_study.json",
    "optimise": "optimise.json",
    "ecc_study": "ecc_study.json",
    "mbist_study": "mbist_study.json",
    "synth_sweep": "synth_sweep.json",
    "phys": "phys.json",
    "power": "power.json",
    "thermal": "thermal.json",
    "xsim_verification": "xsim_verification.json",      # second simulator (Verilator vs Icarus) for the study testbenches
    "r_crosscheck": "r_crosscheck.json",                # statistics recomputed in R
}
SYNTH_GLOB = os.path.join("synth", "*.json")                         # controller sweeps, subsystem and NoC-interface results


class DashboardTooLarge(ValueError):
    """The finished HTML would exceed ``max_bytes`` even after every permitted trim."""


# ------------------------------------------------------------------------------------------ JSON hygiene
def _sig(x: float, digits: int = 9) -> float:
    """Round to ``digits`` significant digits (display precision; keeps the embedded file small)."""
    if x == 0 or not math.isfinite(x):
        return x
    return float(f"{x:.{digits}g}")


def sanitize(o: Any) -> Any:
    """Make an object JSON-safe: NaN/Inf -> None (``JSON.parse`` rejects the bare tokens Python emits), numpy
    scalars/arrays -> Python, tuples/sets -> lists, float precision capped, non-string keys -> strings."""
    if isinstance(o, bool) or o is None or isinstance(o, str):
        return o
    if isinstance(o, int):
        return o
    if isinstance(o, float):
        return _sig(o) if math.isfinite(o) else None
    if isinstance(o, dict):
        return {str(k): sanitize(v) for k, v in o.items()}
    if isinstance(o, (list, tuple, set)):
        return [sanitize(v) for v in (sorted(o) if isinstance(o, set) else o)]
    try:                                                       # numpy without importing it eagerly
        import numpy as np
        if isinstance(o, np.generic):
            return sanitize(o.item())
        if isinstance(o, np.ndarray):
            return sanitize(o.tolist())
    except Exception:
        pass
    return str(o)


def _load_json(path: str):
    """-> (object | None, error | None).  Python's json accepts the ``NaN`` tokens json.dump wrote."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f), None
    except FileNotFoundError:
        return None, None
    except Exception as e:                                       # malformed / unreadable: report, never crash
        return None, f"{type(e).__name__}: {e}"


_STAT_KEEP = ("n", "mean", "half_width")


def _slim_stat(x):
    """replication statistics {n, mean, std, half_width, lo, hi, conf, relative_half_width} -> {n, mean, half_width}."""
    if isinstance(x, dict) and "mean" in x and ("half_width" in x or "n" in x):
        return {k: x[k] for k in _STAT_KEEP if k in x}
    return x


def _slim_stats_in(row: dict) -> dict:
    return {k: _slim_stat(v) for k, v in row.items()}


# ------------------------------------------------------------------------------------------ per-dataset slimming
def _slim_rtl(d: dict, notes: list) -> dict:
    out = {k: v for k, v in d.items() if k not in ("results", "mutation_check")}
    res = d.get("results") or []
    keep = ("label", "ok", "cycles_compared", "transactions", "counters_compared", "params", "workload", "seed",
            "counter_mismatches", "rtl_assertions", "config_mismatch", "model_integrity_errors", "drained")
    slim = []
    for r in res:
        if not isinstance(r, dict):
            continue
        s = {k: r[k] for k in keep if k in r}
        for k in ("counter_mismatches", "rtl_assertions", "config_mismatch"):       # lists -> counts
            if isinstance(s.get(k), list):
                s[k] = len(s[k])
        slim.append(s)
    out["results"] = slim
    out["mutation_check"] = [{k: m.get(k) for k in ("mutation", "detected", "counter_diffs")}
                             for m in (d.get("mutation_check") or []) if isinstance(m, dict)]
    notes.append("rtl_verification: dropped per-case RTL config echo, trace-divergence text and wall-times "
                 "(summary counts, per-case verdicts and the mutation check are kept)")
    return out


def _slim_bank_sweep(d: dict, notes: list) -> dict:
    out = {}
    for key, block in d.items():
        if isinstance(block, dict) and isinstance(block.get("rows"), list):
            b = {k: v for k, v in block.items() if k != "rows"}
            b["rows"] = [_slim_stats_in(r) for r in block["rows"] if isinstance(r, dict)]
            out[key] = b
        else:
            out[key] = block
    notes.append("bank_sweep: replication statistics reduced to {n, mean, half_width}; raw per-replication arrays are not embedded")
    return out


def _slim_vector(d: dict, notes: list) -> dict:
    out = dict(d)
    st = d.get("study")
    if isinstance(st, dict) and isinstance(st.get("rows"), list):
        out["study"] = {**st, "rows": [_slim_stats_in(r) for r in st["rows"] if isinstance(r, dict)]}
    notes.append("vector_study: replication statistics reduced to {n, mean, half_width}")
    return out


_PATH_KEYS = ("run_dir", "exe")


def _strip_paths(o: Any) -> Any:
    """Drop machine-specific absolute paths (run directories, executables) from embedded tool records."""
    if isinstance(o, dict):
        return {k: _strip_paths(v) for k, v in o.items() if k not in _PATH_KEYS}
    if isinstance(o, list):
        return [_strip_paths(v) for v in o]
    return o


def _slim_synth(d: dict, notes: list) -> dict:
    out = _strip_paths({k: v for k, v in d.items() if k != "results"})
    notes.append(f"synth sweep ({d.get('mode', '?')}): flat row table kept; per-run Yosys cell-type breakdown and run directories not embedded")
    return out


def _prune_lists(o: Any, limit: int, notes: list, path: str = "") -> Any:
    """Cap very long lists of rows (keeps the first ``limit`` and records the cut).  Used only as a size guard
    for datasets whose structure this builder does not know (ecc / mbist / phys / power / thermal)."""
    if isinstance(o, list):
        if len(o) > limit and any(isinstance(v, (dict, list)) for v in o[:3]):
            notes.append(f"{path or '<root>'}: list of {len(o)} entries truncated to the first {limit}")
            o = o[:limit]
        return [_prune_lists(v, limit, notes, f"{path}[]") for v in o]
    if isinstance(o, dict):
        return {k: _prune_lists(v, limit, notes, f"{path}.{k}" if path else k) for k, v in o.items()}
    return o


# ------------------------------------------------------------------------------------------ experiment history
def _load_experiments(data_dir: str, notes: list, limit: int = 2000) -> dict | None:
    rdir = os.path.join(data_dir, "runs")
    if not os.path.isdir(rdir):
        return None
    rows: dict[str, dict] = {}
    errors = 0
    jl = os.path.join(rdir, "experiments.jsonl")
    if os.path.isfile(jl):
        with open(jl, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                except Exception:
                    errors += 1
                    continue
                if isinstance(r, dict) and r.get("experiment_id"):
                    rows[str(r["experiment_id"])] = r
    # per-experiment JSON records add the config name / dirty flag / workload when the jsonl row lacks them
    for p in sorted(glob.glob(os.path.join(rdir, "EXP-*.json"))):
        rec, err = _load_json(p)
        if not isinstance(rec, dict):
            errors += bool(err)
            continue
        eid = str(rec.get("experiment_id") or os.path.splitext(os.path.basename(p))[0])
        r = rows.setdefault(eid, {"experiment_id": eid})
        cfg = rec.get("config") if isinstance(rec.get("config"), dict) else {}
        git = rec.get("git") if isinstance(rec.get("git"), dict) else {}
        wl = rec.get("workload") if isinstance(rec.get("workload"), dict) else {}
        for k, v in (("created_utc", rec.get("created_utc")), ("command", rec.get("command")),
                     ("config_hash", rec.get("config_hash")), ("result_hash", rec.get("result_hash")),
                     ("seed", rec.get("seed")), ("name", cfg.get("name")), ("git_revision", git.get("revision")),
                     ("headline", rec.get("headline"))):
            if r.get(k) is None and v is not None:
                r[k] = v
        r.setdefault("git_dirty", git.get("dirty"))
        r.setdefault("workload_kind", wl.get("kind"))
        r.setdefault("wall_seconds", rec.get("wall_seconds"))
    out = sorted(rows.values(), key=lambda r: str(r.get("created_utc") or r.get("experiment_id")))
    if len(out) > limit:
        notes.append(f"experiments: {len(out)} records, showing the newest {limit}")
        out = out[-limit:]
    keep = ("experiment_id", "created_utc", "command", "name", "config_hash", "result_hash", "git_revision",
            "git_dirty", "seed", "headline", "workload_kind", "wall_seconds")
    return {"rows": [{k: r.get(k) for k in keep if r.get(k) is not None} for r in out], "unreadable_lines": errors}


# ------------------------------------------------------------------------------------------ tool availability
def tool_status(probe: bool = True) -> list[dict]:
    """Real tool availability (version strings come from the tools themselves; nothing is assumed present)."""
    if probe:
        try:
            from . import tools
            rows = tools.status()
            return [{"tool": r["tool"], "available": bool(r["available"]), "version": r.get("version")} for r in rows]
        except Exception:
            pass
    rows = []
    for name in ("verilator", "yosys", "iverilog", "openroad", "opensta", "Rscript"):
        exe = shutil.which(name) or (shutil.which("yowasp-yosys") if name == "yosys" else None)
        rows.append({"tool": name, "available": exe is not None, "version": None})
    return rows


# ------------------------------------------------------------------------------------------ assembling
def load_datasets(data_dir: str, notes: list | None = None) -> tuple[dict, dict]:
    """-> (datasets, load_errors).  Absent datasets map to None; unreadable ones to None + an error string."""
    notes = notes if notes is not None else []
    ds: dict[str, Any] = {}
    errs: dict[str, str] = {}
    for name, fn in DATASET_FILES.items():
        obj, err = _load_json(os.path.join(data_dir, fn))
        if err:
            errs[fn] = err
        if obj is None:
            ds[name] = None
            continue
        if name == "rtl_verification" and isinstance(obj, dict):
            obj = _slim_rtl(obj, notes)
        elif name == "bank_sweep" and isinstance(obj, dict):
            obj = _slim_bank_sweep(obj, notes)
        elif name == "vector_study" and isinstance(obj, dict):
            obj = _slim_vector(obj, notes)
        elif name == "r_crosscheck" and isinstance(obj, dict):
            obj = {k: v for k, v in obj.items() if k != "rows"}
            notes.append("r_crosscheck: dropped the per-quantity comparison rows (counts, maximum differences, "
                         "disagreements and the R analyses are kept)")
        elif name == "xsim_verification" and isinstance(obj, dict):
            obj = _strip_paths(obj)
        elif name in ("ecc_study", "mbist_study", "phys", "power", "thermal", "synth_sweep", "optimise"):
            obj = _prune_lists(obj, 600 if name == "optimise" else 300, notes, name)
        ds[name] = obj
    synth, other = {}, {}
    for p in sorted(glob.glob(os.path.join(data_dir, SYNTH_GLOB))):       # every Yosys result under data/synth
        base = os.path.basename(p)
        obj, err = _load_json(p)
        if err:
            errs[os.path.join("synth", base)] = err
        if not isinstance(obj, dict):
            continue
        stem = os.path.splitext(base)[0]
        if stem.startswith(("subsystem_", "noc_interface")):               # integrated subsystem / NoC-interface synthesis
            other[stem] = _strip_paths(obj)
        elif isinstance(obj.get("rows"), list):                            # a sweep: flat row table
            d = _slim_synth(obj, notes)
            d["file"] = base
            synth[stem.replace("controller_sweep_", "")] = d
    ds["synth"] = synth or None
    ds["synth_other"] = _prune_lists(other, 60, notes, "synth_other") if other else None
    ds["experiments"] = _load_experiments(data_dir, notes)
    return ds, errs


def _now(now: float | None) -> str:
    if now is None and os.environ.get("SOURCE_DATE_EPOCH", "").isdigit():
        now = float(os.environ["SOURCE_DATE_EPOCH"])
    t = datetime.datetime.fromtimestamp(time.time() if now is None else now, datetime.timezone.utc)
    return t.isoformat(timespec="seconds")


def _version() -> str:
    try:
        from . import __version__
        return __version__
    except Exception:
        return "unknown"


def make_bundle(data_dir: str, *, probe_tools: bool = True, now: float | None = None) -> dict:
    notes: list[str] = []
    ds, errs = load_datasets(data_dir, notes)
    bundle = {
        "schema": SCHEMA,
        "generated_utc": _now(now),
        "package_version": _version(),
        "data_dir": os.path.basename(os.path.abspath(data_dir)) or str(data_dir),
        "datasets": ds,
        "absent": sorted(k for k, v in ds.items() if v is None),
        "load_errors": errs,
        "tools": tool_status(probe_tools),
        "trim_notes": sorted(set(notes)),
        "provenance_classes": ["analytical", "simulated", "synthesized", "measured", "unavailable"],
        "measured_exists": False,        # no SilicaFlux silicon / FPGA measurement exists; the page never labels anything MEASURED
    }
    return sanitize(bundle)


def _encode(bundle: dict) -> str:
    """JSON text safe to inline in a <script type=application/json> element."""
    txt = json.dumps(bundle, separators=(",", ":"), ensure_ascii=True, allow_nan=False)
    return txt.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _assets() -> tuple[str, str, str]:
    tpl = _read(os.path.join(DASH_DIR, "template.html"))
    css = _read(os.path.join(DASH_DIR, "dashboard.css"))
    js_files = sorted(glob.glob(os.path.join(DASH_DIR, "js", "*.js")))
    if not js_files:
        raise FileNotFoundError(f"no dashboard scripts under {os.path.join(DASH_DIR, 'js')}")
    js = "\n".join(_read(p) for p in js_files)
    return tpl, css, js


def _inline_safe(text: str, closing: str) -> str:
    """Refuse (rather than silently corrupt) asset text that would terminate its <style>/<script> element."""
    if re.search(re.escape(closing), text, flags=re.I):
        raise ValueError(f"dashboard asset contains {closing!r}; cannot be inlined")
    return text


def render(data_dir: str | None = None, *, max_bytes: int = MAX_BYTES, probe_tools: bool = True,
           now: float | None = None) -> str:
    """Build the dashboard HTML text (see :func:`build`)."""
    data_dir = data_dir or DEFAULT_DATA
    tpl, css, js = _assets()
    css, js = _inline_safe(css, "</style"), _inline_safe(js, "</script")
    bundle = make_bundle(data_dir, probe_tools=probe_tools, now=now)

    def assemble(b: dict) -> str:
        parts = {"CSS": css, "JS": js, "DATA": _encode(b)}
        return re.sub(r"@@(CSS|JS|DATA)@@", lambda m: parts[m.group(1)], tpl)

    html = assemble(bundle)
    for step in _TRIMS:                                           # size guard: documented, recorded, never silent
        if len(html.encode("utf-8")) <= max_bytes:
            break
        note = step(bundle)
        if note:
            bundle["trim_notes"] = sorted(set(bundle["trim_notes"]) | {note})
        html = assemble(bundle)
    size = len(html.encode("utf-8"))
    if size > max_bytes:
        raise DashboardTooLarge(f"dashboard is {size} bytes, over the {max_bytes}-byte cap after all permitted trims")
    return html


def _trim_rtl_cases(b: dict) -> str | None:
    r = (b["datasets"].get("rtl_verification") or {})
    if r.get("results"):
        bad = [x for x in r["results"] if not x.get("ok")]
        n = len(r["results"])
        r["results"] = bad
        r["results_trimmed_to_failures"] = True
        return f"size guard: rtl_verification per-case rows ({n}) dropped except failures; summary counts kept"
    return None


def _trim_experiments(b: dict) -> str | None:
    e = b["datasets"].get("experiments")
    if e and len(e.get("rows", [])) > 200:
        n = len(e["rows"])
        e["rows"] = e["rows"][-200:]
        return f"size guard: experiment history cut from {n} to the newest 200 records"
    return None


def _trim_histograms(b: dict) -> str | None:
    cut = 0
    for blk in (b["datasets"].get("bank_sweep") or {}).values():
        for r in (blk.get("rows") or []) if isinstance(blk, dict) else []:
            if r.pop("latency_histogram", None) is not None:
                cut += 1
    return f"size guard: {cut} latency histograms dropped (view 5 will show UNAVAILABLE)" if cut else None


def _trim_generic(b: dict) -> str | None:
    notes: list[str] = []
    for k in ("ecc_study", "mbist_study", "phys", "power", "thermal", "synth_sweep"):
        if b["datasets"].get(k) is not None:
            b["datasets"][k] = _prune_lists(b["datasets"][k], 60, notes, k)
    return ("size guard: " + "; ".join(sorted(set(notes)))) if notes else None


_TRIMS = (_trim_rtl_cases, _trim_experiments, _trim_generic, _trim_histograms)


def build(data_dir: str | None = None, out_path: str | None = None, *, max_bytes: int = MAX_BYTES,
          probe_tools: bool = True, now: float | None = None) -> str:
    """Write the self-contained dashboard HTML and return the output path (str).

    ``data_dir`` defaults to ``<package>/data``, ``out_path`` to ``<package>/dashboard/sramlab_dashboard.html``.
    Missing / unreadable datasets are tolerated (the page shows an UNAVAILABLE panel for them).  Raises
    :class:`DashboardTooLarge` if the page cannot be brought under ``max_bytes``."""
    out_path = out_path or DEFAULT_OUT
    html = render(data_dir, max_bytes=max_bytes, probe_tools=probe_tools, now=now)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
    tmp = out_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(html)
    os.replace(tmp, out_path)
    return out_path


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python3 -m sramlab.dashboard",
                                 description="Build the self-contained SRAMLab HTML dashboard.")
    ap.add_argument("--data", default=DEFAULT_DATA, help="data directory (default: <package>/data)")
    ap.add_argument("--out", default=DEFAULT_OUT, help="output HTML file (default: dashboard/sramlab_dashboard.html)")
    ap.add_argument("--max-bytes", type=int, default=MAX_BYTES, help="size cap for the HTML file")
    ap.add_argument("--no-probe", action="store_true", help="do not run external tools to read their versions")
    a = ap.parse_args(argv)
    try:
        path = build(a.data, a.out, max_bytes=a.max_bytes, probe_tools=not a.no_probe)
    except (DashboardTooLarge, OSError, ValueError) as e:
        print(f"dashboard: {e}", file=sys.stderr)
        return 1
    print(f"wrote {path} ({os.path.getsize(path) / 1e6:.2f} MB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
