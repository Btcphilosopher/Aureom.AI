"""Frozen, dependency-free pseudo random generator (SplitMix64).

Workload address streams must be reproducible bit-for-bit across machines and
library versions, so SRAMLab does not use numpy's generator streams (their
output is allowed to change between releases).  SplitMix64 is ~10 lines, has a
published reference sequence and is checked by ``tests/test_prng.py``.
"""
from __future__ import annotations

_M64 = (1 << 64) - 1


class SplitMix64:
    __slots__ = ("state",)

    def __init__(self, seed: int):
        self.state = int(seed) & _M64

    def next_u64(self) -> int:
        self.state = (self.state + 0x9E3779B97F4A7C15) & _M64
        z = self.state
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & _M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & _M64
        return z ^ (z >> 31)

    def randbelow(self, n: int) -> int:
        """Uniform integer in [0, n) without modulo bias (rejection sampling)."""
        if n <= 0:
            raise ValueError("randbelow needs n > 0")
        if n == 1:
            return 0
        limit = _M64 - ((_M64 + 1) % n)
        while True:
            v = self.next_u64()
            if v <= limit:
                return v % n

    def random(self) -> float:
        """Uniform float in [0, 1) with 53 bits."""
        return (self.next_u64() >> 11) * (1.0 / (1 << 53))

    def bernoulli(self, p: float) -> bool:
        return self.random() < p

    def fork(self, tag: int) -> "SplitMix64":
        """Independent child stream (used so adding a master never perturbs another's stream)."""
        s = SplitMix64(self.state ^ ((tag + 1) * 0xD1B54A32D192ED03))
        s.next_u64()
        return s
