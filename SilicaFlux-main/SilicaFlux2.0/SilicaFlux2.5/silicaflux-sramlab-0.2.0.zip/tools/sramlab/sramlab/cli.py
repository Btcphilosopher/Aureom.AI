"""SRAMLab command line.  Every command listed by ``sramlab --help`` is implemented and covered by tests/test_cli.py."""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

from . import __version__
from . import record as R
from .config import ConfigError, export_schema, load_config, validate_config


def _write_dataset(a, name, obj):
    """Datasets are written only on request (--dataset) so that a test or a quick run can never overwrite committed results."""
    d = getattr(a, "dataset_dir", None) or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, name)
    with open(p, "w") as f:
        json.dump(obj, f, indent=1, default=R._json_default)
    _say(f"dataset: {p}")


def _out(args) -> str:
    return args.out or os.path.join(os.getcwd(), "sramlab_results")


def _say(msg):
    print(msg, flush=True)


def _fmt_ci(d, nd=3):
    if not d or d.get("n", 0) == 0:
        return "n/a"
    hw = d.get("half_width")
    return f"{d['mean']:.{nd}f}" + (f" ± {hw:.{nd}f}" if hw == hw and hw is not None else "")


def _save(args, cmd, cfg, results, headline=None, **kw) -> str:
    t0 = kw.pop("t0", None)
    rec = R.make_record(cmd, cfg, results, wall_seconds=(time.time() - t0) if t0 else None, **kw)
    rec["headline"] = headline
    p = R.save(rec, _out(args))
    _say(f"record: {p}  (experiment {rec['experiment_id']}, result_hash {rec['result_hash'][:12]})")
    return p


# ----------------------------------------------------------------------------- commands
def cmd_validate(a):
    bad = 0
    for path in a.config:
        try:
            cfg = load_config(path, validate=False)
            v = validate_config(cfg)
        except ConfigError as e:
            _say(f"{path}: INVALID\n  - " + "\n  - ".join(e.problems))
            bad += 1
            continue
        if v.ok:
            _say(f"{path}: valid" + (f" ({len(v.warnings)} warning(s))" if v.warnings else ""))
        else:
            bad += 1
            _say(f"{path}: INVALID\n  - " + "\n  - ".join(v.errors))
        for w in v.warnings:
            _say(f"  warning: {w}")
    return 1 if bad else 0


def cmd_tools(a):
    from . import tools
    for r in tools.status():
        _say(f"{r['tool']:10s} {'available ' + str(r['version']) if r['available'] else 'NOT AVAILABLE'}")
    return 0


def cmd_schema(a):
    p = a.output or os.path.join("schemas", "experiment.schema.json")
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    json.dump(export_schema(), open(p, "w"), indent=1)
    _say(f"wrote {p}")
    return 0


def cmd_simulate(a):
    from . import experiments as E
    t0 = time.time()
    cfg = load_config(a.config)
    rr, m, verdict = E.run_once(cfg, rtl_check=a.rtl_check)
    _say(f"[{cfg['name']}] {m['cycles']} cycles, {m['transactions_accepted']} transactions, integrity errors: {m['integrity_errors']}")
    lat = m["read_latency_e2e"]
    _say(f"  throughput {m['request_throughput_txn_per_cycle']:.3f} txn/cycle  useful {m['useful_bytes_per_cycle']:.3f} B/cycle "
         f"(analytical peak {m['analytical']['peak_txn_per_cycle']:.2f} txn/cycle, {m['efficiency_vs_peak']*100:.1f}% of it)")
    if lat.get("n"):
        _say(f"  read latency end-to-end: mean {lat['mean']:.2f} median {lat['median']:.1f} p95 {lat['p95']:.1f} p99 {lat['p99']:.1f} cycles; "
             f"accept->response {m['read_latency_response']['mean']:.2f}")
    _say(f"  conflicts {m['conflict_events']} ({m['conflict_rate_per_access']:.3f}/access), bank util mean {m['bank_utilisation_mean']:.3f}")
    ver = None
    if verdict is not None:
        ver = {"rtl_comparison": verdict}
        _say(f"  RTL comparison: {'IDENTICAL' if verdict['ok'] else 'MISMATCH'} over {verdict['cycles_compared']} cycles, "
             f"{verdict['counters_compared']} counters")
        if not verdict["ok"]:
            _say("   " + json.dumps(verdict["first_trace_divergence"] or verdict["counter_mismatches"] or verdict["config_mismatch"], default=str)[:400])
    files = []
    if a.export:
        files = R.export_run(rr, _out(a), cfg["name"])
        _say("  exported " + ", ".join(files))
    _save(a, "simulate", cfg, m, headline={"throughput": m["request_throughput_txn_per_cycle"], "cycles": m["cycles"]},
          counters=rr.perf_dict, verification=ver, t0=t0, extra={"raw_files": files})
    return 0 if (verdict is None or verdict["ok"]) and m["integrity_errors"] == 0 else 1


def cmd_benchmark(a):
    from . import experiments as E
    t0 = time.time()
    cfg = load_config(a.config)
    b = E.benchmark(cfg, a.replications)
    s = b["summary"]
    _say(f"[{cfg['name']}] {a.replications} replications (seeds {b['seeds'][0]}..{b['seeds'][-1]}), mean ± 95% CI half-width:")
    for k in ("throughput_txn_per_cycle", "useful_bytes_per_cycle", "read_latency_mean", "read_latency_median", "read_latency_p95",
              "read_latency_p99", "arbitration_delay_mean", "conflict_rate_per_access", "bank_utilisation_mean", "outstanding_mean"):
        _say(f"  {k:28s} {_fmt_ci(s[k])}")
    _say(f"  sample adequate for a 2% throughput CI: {b['sample_adequate_for_2pct']} (needs >= {b['replications_needed_for_2pct_throughput_ci']} replications)")
    _save(a, "benchmark", cfg, {k: v for k, v in b.items() if k != "first_run_metrics"} | {"first_run": b["first_run_metrics"]},
          headline={"throughput": s["throughput_txn_per_cycle"]["mean"]}, t0=t0)
    return 0


def cmd_sweep(a):
    from . import experiments as E
    t0 = time.time()
    base = load_config(a.config) if a.config else load_config({"name": "sweep", "memory": {"banks": 4, "bank_depth_words": 4096},
                                                               "controller": {"masters": a.masters, "max_outstanding": a.max_out}})
    banks = tuple(int(x) for x in a.banks.split(","))
    wls = tuple(a.workloads.split(","))
    sw = E.sweep_banks(base, banks, wls, a.replications, progress=None if a.quiet else (lambda m: _say("  " + m)))
    _say(f"{'workload':11s} {'banks':>5s} {'txn/cycle':>16s} {'read lat (e2e)':>15s} {'p99':>5s} {'conflict/acc':>12s}")
    for r in sw["rows"]:
        _say(f"{r['workload']:11s} {r['banks']:5d} {_fmt_ci(r['throughput_txn_per_cycle']):>16s} {r['read_latency_mean']['mean']:15.2f} "
             f"{r['read_latency_p99']['mean']:5.1f} {r['conflict_rate_per_access']['mean']:12.3f}")
    _save(a, "sweep", base, sw, t0=t0)
    return 0


def cmd_compare(a):
    from . import experiments as E
    t0 = time.time()
    ca, cb = load_config(a.config_a), load_config(a.config_b)
    c = E.compare(ca, cb, a.replications)
    _say(f"{c['a']}  vs  {c['b']}   ({a.replications} replications each)")
    for k, v in c["metrics"].items():
        _say(f"  {k:34s} A {_fmt_ci(v['a'])}   B {_fmt_ci(v['b'])}   delta {v['relative_delta']*100:+.1f}%   "
             f"{'distinguishable' if v['ci_distinguishable'] else 'CIs overlap'}")
    _save(a, "compare", ca, c, t0=t0)
    return 0


def cmd_vector(a):
    from .studies import vector as V
    t0 = time.time()
    s = V.run_vector_study(word_bits=tuple(int(x) for x in a.word_bits.split(",")), banks=tuple(int(x) for x in a.banks.split(",")),
                           replications=a.replications, requests=a.requests, progress=None)
    x = V.p76_crosscheck()
    v = x["value"]
    for r in s["rows"]:
        _say(f"w{r['word_bits']:<3d} v{r['vector_bits']:<3d} b{r['banks']:<2d} {r['case']:26s} useful {r['useful_bytes_per_cycle']['mean']:6.2f} B/c  "
             f"overhead {r['alignment_overhead']:.2f}x  conflicts/acc {r['conflict_rate_per_access']['mean']:.2f}")
    _say(f"cross-check vs P76 RTL-simulation rows: {v['cycles_exact_match']}/{v['rows_checked']} cycle-exact, word counts {v['word_access_count_match']}")
    _save(a, "vector", None, {"study": s, "p76_crosscheck": x}, t0=t0)
    return 0


def cmd_tensor(a):
    from .studies import tensor_study as T
    t0 = time.time()
    s = T.run_tensor_study(M=a.m, N=a.n, K=a.k, banks=tuple(int(x) for x in a.banks.split(",")),
                           max_out=tuple(int(x) for x in a.max_out.split(",")), dma_duty=tuple(float(x) for x in a.dma.split(",")))
    _say(f"ideal-resource reference MAC utilisation {s['util_ideal_reference']:.3f}; rule: {s['verdict_rule']}")
    for r in s["rows"]:
        _say(f"banks {r['banks']:2d} MAX_OUT {r['max_out']} {r['pitch']:8s} dma {r['dma_duty']:.2f}: util {r['mac_utilisation']:.3f}  starved {r['starvation_fraction']:.2f}  "
             f"operand {r['operand_bytes_per_cycle']:.2f}/{r['required_operand_bytes_per_cycle']:.0f} B/c  -> {'MEMORY-limited' if r['memory_limited'] else 'not memory-limited'}")
    _save(a, "tensor", None, s, t0=t0)
    return 0


def cmd_optimise(a):
    from . import optimise as O
    t0 = time.time()
    space = dict(O.DEFAULT_SPACE)
    if a.quick:
        space = {"banks": [2, 4, 8, 16], "interleave": ["low", "high"], "max_out": [1, 4], "read_latency": [1], "word_bits": [32],
                 "arbitration": ["round_robin"]}
    area_fn = energy_fn = None
    try:
        from . import phys
        area_fn = getattr(phys, "candidate_area", None)
    except Exception:
        pass
    res = O.evaluate(space, n_req=a.requests, replications=a.replications, area_fn=area_fn, energy_fn=energy_fn,
                     progress=None if a.quiet else (lambda m: _say("  " + m)))
    _say(res["statement"])
    if a.dataset:
        _write_dataset(a, "optimise.json", res)
    for c in res["caveats"]:
        _say("  CAVEAT: " + c)
    for g, v in res["goals"].items():
        _say(f"  {g}: " + (v if isinstance(v, str) else f"{v['winners'][0]}" + (f"  (+{v['n_tied']-1} tied)" if v["n_tied"] > 1 else "")))
    _save(a, "optimise", None, res, t0=t0)
    return 0


def cmd_rtlcheck(a):
    from . import verify
    t0 = time.time()
    res = verify.run_matrix(quick=a.quick, n_req=a.requests, seed=a.seed, progress=None if a.quiet else _say)
    res["mutation_check"] = verify.mutation_check()
    if a.icarus:
        from . import xsim
        res["three_way"] = xsim.controller_check(n_req=min(a.requests, 150), seed=a.seed, quick=True,
                                                 progress=None if a.quiet else _say)
        _say(f"three-way (model = Verilator = Icarus): {res['three_way']['passed']}/{res['three_way']['cases']} cases")
    _say(f"RTL vs model: {res['passed']}/{res['cases']} cases identical over {res['cycles_compared']} cycles, "
         f"{res['transactions']} transactions, {res['counters_compared']} counter values, {res['parameter_sets']} parameter sets")
    _say("negative control: " + ", ".join(f"{m['mutation']}={'detected' if m['detected'] else 'MISSED'}" for m in res["mutation_check"]))
    for r in res["results"]:
        if not r.get("ok"):
            _say(f"  FAIL {r['label']}: {r.get('error') or r.get('first_trace_divergence') or r.get('config_mismatch')}")
    if a.dataset:
        _write_dataset(a, "rtl_verification.json", res)
    _save(a, "rtlcheck", None, res, t0=t0)
    ok3 = (not a.icarus) or res["three_way"]["passed"] == res["three_way"]["cases"]
    return 0 if res["failed"] == 0 and all(m["detected"] for m in res["mutation_check"]) and ok3 else 1


def cmd_xsim(a):
    """Second-simulator differential check: ECC / MBIST testbenches under Verilator and Icarus, identical inputs."""
    from . import xsim
    t0 = time.time()
    res = xsim.study_tb_check(quick=not a.full, progress=None if a.quiet else _say,
                              only=a.only.split(",") if a.only else None)
    res["negative_control"] = xsim.workaround_negative_control() if not a.no_negative_control else {
        "interpretation": "not run (--no-negative-control)"}
    if a.controller:
        res["controller_three_way"] = xsim.controller_check(quick=not a.full, progress=None if a.quiet else _say)
    _say(f"study testbenches: {res['identical']}/{res['cases']} identical under {res['simulators']['verilator']} and Icarus "
         f"({res['lines_compared']} tagged lines)")
    nc = res["negative_control"]
    _say(f"negative control (optimiser workaround removed): {nc['interpretation']}")
    if a.controller:
        c3 = res["controller_three_way"]
        _say(f"controller three-way (model = Verilator = Icarus): {c3['passed']}/{c3['cases']}")
    for r in res["results"]:
        if not r["identical"]:
            _say(f"  DIFFERENT {r['case']}: {r.get('error') or r.get('first_difference')}")
    if a.dataset:
        _write_dataset(a, "xsim_verification.json", res)
    _save(a, "xsim", None, res, t0=t0)
    ok = res["identical"] == res["cases"] and (not a.controller or res["controller_three_way"]["passed"] == res["controller_three_way"]["cases"])
    return 0 if ok else 1


def cmd_rstats(a):
    """Recompute SRAMLab's statistics in R from raw simulation output and compare (plus R-only analyses)."""
    from . import rstats
    t0 = time.time()
    res = rstats.crosscheck(a.config or rstats.DEFAULT_CONFIG, replications=a.replications, requests=a.requests, quick=a.quick)
    if res["status"] == "unavailable":
        _say(f"R cross-check unavailable: {res['reason']}")
        return 0
    if res["status"] == "error":
        _say("R cross-check failed to run:\n" + res["error"])
        return 1
    c = res["comparison"]
    _say(f"Python vs R ({res['rscript']}): {c['agree']}/{c['compared']} quantities agree")
    for k, v in sorted(c["by_kind"].items()):
        _say(f"  {k:18s} n={v['n']:4d}  max relative difference {v['max_rel_diff']:.2e}")
    for d in c["disagreements"]:
        _say(f"  DISAGREE {d['quantity']}: python {d['python']} R {d['r']}")
    an = res["analysis_r"]["values"]
    if "kruskal_throughput_by_workload.p_value" in an:
        _say(f"R analysis: Kruskal-Wallis (throughput ~ workload) H={an['kruskal_throughput_by_workload.statistic']:.3f}, "
             f"p={an['kruskal_throughput_by_workload.p_value']:.3g}")
    for k in sorted(an):
        if k.endswith(".slope") and k.startswith("elasticity."):
            w = k.split(".")[1]
            lo, hi = an.get(f"elasticity.{w}.ci_lo"), an.get(f"elasticity.{w}.ci_hi")
            rng_ = f" (95% CI {lo:.3f}..{hi:.3f})" if isinstance(lo, float) else " (constant throughput)"
            _say(f"  elasticity d ln(throughput)/d ln(banks), {w:10s}: {an[k]:.3f}{rng_}")
    if a.dataset:
        _write_dataset(a, "r_crosscheck.json", res)
    _save(a, "rstats", None, res, t0=t0)
    return 0 if res["status"] == "agree" else 1


def cmd_history(a):
    for h in R.load_history(_out(a))[-a.n:]:
        _say(f"{h['created_utc']}  {h['experiment_id']}  {h['command']:10s} {h.get('name') or '':24s} result {h['result_hash'][:10]}")
    return 0


def cmd_verify_repro(a):
    """Run a config twice (fresh interpreter state) and demand identical result hashes."""
    from . import experiments as E
    cfg = load_config(a.config)
    h = []
    for _ in range(2):
        rr, m, _v = E.run_once(cfg)
        h.append(R.result_hash(m))
    ok = h[0] == h[1]
    _say(f"result hashes {h[0][:16]} / {h[1][:16]}: {'REPRODUCIBLE' if ok else 'NOT REPRODUCIBLE'}")
    return 0 if ok else 1


def _lazy(modname, fname):
    def run(a):
        import importlib
        mod = importlib.import_module(f".{modname}", __package__)
        return getattr(mod, fname)(a)
    return run


def build_parser():
    ap = argparse.ArgumentParser(prog="sramlab", description="SilicaFlux SRAMLab: SRAM architecture benchmarking and digital twin")
    ap.add_argument("--version", action="version", version=f"sramlab {__version__}")
    ap.add_argument("--out", help="results directory (default ./sramlab_results)")
    ap.add_argument("--quiet", action="store_true")
    sp = ap.add_subparsers(dest="cmd", required=True)

    def add(name, fn, help_, *cfg):
        p = sp.add_parser(name, help=help_)
        p.set_defaults(fn=fn)
        return p

    p = add("validate", cmd_validate, "validate configuration files"); p.add_argument("config", nargs="+")
    add("tools", cmd_tools, "show which external tools are available")
    p = add("schema", cmd_schema, "write the JSON schema of the configuration"); p.add_argument("--output")
    p = add("simulate", cmd_simulate, "run one configuration (optionally against the RTL)")
    p.add_argument("config"); p.add_argument("--rtl-check", action="store_true"); p.add_argument("--export", action="store_true")
    p = add("benchmark", cmd_benchmark, "replicated benchmark with confidence intervals")
    p.add_argument("config"); p.add_argument("--replications", type=int, default=10)
    p = add("sweep", cmd_sweep, "bank-count sweep at constant capacity")
    p.add_argument("config", nargs="?"); p.add_argument("--banks", default="2,4,8,16")
    p.add_argument("--workloads", default="rand_read,mixed,seq_read,hotspot,contention")
    p.add_argument("--replications", type=int, default=5); p.add_argument("--masters", type=int, default=4)
    p.add_argument("--max-out", type=int, default=4, dest="max_out")
    p = add("compare", cmd_compare, "compare two configurations statistically")
    p.add_argument("config_a"); p.add_argument("config_b"); p.add_argument("--replications", type=int, default=8)
    p = add("vector", cmd_vector, "vector memory study + cross-check against the VectorScratch RTL results")
    p.add_argument("--word-bits", default="32,128", dest="word_bits"); p.add_argument("--banks", default="4,8,16")
    p.add_argument("--replications", type=int, default=3); p.add_argument("--requests", type=int, default=1500)
    p = add("tensor", cmd_tensor, "tensor memory study (does memory bandwidth limit the array?)")
    p.add_argument("--m", type=int, default=16); p.add_argument("--n", type=int, default=16); p.add_argument("--k", type=int, default=64)
    p.add_argument("--banks", default="1,2,4,8,16"); p.add_argument("--max-out", default="1,2,4", dest="max_out"); p.add_argument("--dma", default="0,0.5")
    p = add("optimise", cmd_optimise, "multi-goal optimisation and Pareto frontier")
    p.add_argument("--quick", action="store_true"); p.add_argument("--requests", type=int, default=600); p.add_argument("--replications", type=int, default=2)
    p.add_argument("--dataset", action="store_true", help="write data/optimise.json"); p.add_argument("--dataset-dir", dest="dataset_dir")
    p = add("rtlcheck", cmd_rtlcheck, "cycle-by-cycle model vs Verilator RTL verification matrix + negative control")
    p.add_argument("--quick", action="store_true"); p.add_argument("--requests", type=int, default=300); p.add_argument("--seed", type=int, default=11)
    p.add_argument("--dataset", action="store_true", help="write data/rtl_verification.json (use only for the full matrix)"); p.add_argument("--dataset-dir", dest="dataset_dir")
    p.add_argument("--icarus", action="store_true", help="also run a quick subset three-way: model = Verilator = Icarus")
    p = add("xsim", cmd_xsim, "second-simulator check: ECC/MBIST testbenches under Verilator and Icarus (+ negative control)")
    p.add_argument("--full", action="store_true", help="larger case set"); p.add_argument("--controller", action="store_true",
                                                                                         help="also the controller three-way check")
    p.add_argument("--only", help="comma-separated subset of: codec,bank,mbist_script,mbist_cov")
    p.add_argument("--no-negative-control", action="store_true", dest="no_negative_control")
    p.add_argument("--dataset", action="store_true", help="write data/xsim_verification.json"); p.add_argument("--dataset-dir", dest="dataset_dir")
    p = add("rstats", cmd_rstats, "recompute the statistics in R from raw simulation output and compare (+ R-only analyses)")
    p.add_argument("config", nargs="?"); p.add_argument("--replications", type=int, default=8); p.add_argument("--requests", type=int, default=300)
    p.add_argument("--quick", action="store_true")
    p.add_argument("--dataset", action="store_true", help="write data/r_crosscheck.json"); p.add_argument("--dataset-dir", dest="dataset_dir")
    p = add("history", cmd_history, "list the experiment history"); p.add_argument("-n", type=int, default=20)
    p = add("verify-repro", cmd_verify_repro, "re-run a configuration and demand identical results"); p.add_argument("config")
    ap._sramlab_subparsers = sp
    return ap


def register_study_commands(sp_parent=None):
    """ecc / mbist / synth / floorplan / power / report / dashboard are registered by sramlab.cli_studies."""


def main(argv=None):
    ap = build_parser()
    try:
        from . import cli_studies
        cli_studies.register(ap)
    except ImportError:
        pass
    args = ap.parse_args(argv)
    try:
        return args.fn(args)
    except ConfigError as e:
        print(str(e), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
