"""Optimisation experiments (brief section 15): several goals, a Pareto frontier, NO single universal optimum.

Candidate space (each candidate is evaluated on a workload suite, with replications):
  banks, interleave (bank mapping), word width, MAX_OUT (buffer capacity / credits), read latency, arbitration policy,
  ECC (stored-bit and latency/RMW effects taken from the measured ECC study when available), physical macro organisation
  (macro tiling area from real vendor manifests when the tech layer is available).

Goals
  A  lowest read latency          : mean end-to-end read latency over the suite            (simulated)
  B  highest useful bandwidth     : mean useful bytes/cycle over the suite                 (simulated)
  C  lowest area                  : ``area_fn`` result (macro tiling + logic where known)  (see its label)
  D  lowest energy per useful byte: energy if a validated profile exists, else the parameter-free proxy
                                    array-bit-activations per useful byte                    (simulated proxy)
  E  balanced PPA                 : geometric mean of the min-max normalised objectives; ranking stability under random
                                    weights is reported because the "best" balanced point depends on the weights

The result states, from the data, how many distinct candidates win at least one goal and per-workload winners; it never
names one configuration as universally optimal.
"""
from __future__ import annotations

import copy
import itertools
import math

import numpy as np

from . import experiments as E
from .config import load_config, validate_config
from .prng import SplitMix64

def ecc_read_latency_delta(data_dir: str | None = None):
    """Extra bank read-latency cycles of SECDED, MEASURED on the RTL by ``sramlab ecc`` (data/ecc_study.json); None if absent."""
    import json, os
    d = data_dir or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
    p = os.path.join(d, "ecc_study.json")
    if not os.path.exists(p):
        return None
    try:
        h = json.load(open(p))["headline"]
        vals = {v[k] for v in h.values() for k in v if k.startswith("decoder_added_cycles")}
        return int(vals.pop()) if len(vals) == 1 else None
    except Exception:
        return None


DEFAULT_SPACE = {
    "banks": [2, 4, 8, 16],
    "interleave": ["low", "high"],
    "max_out": [1, 4],
    "read_latency": [1, 2],
    "word_bits": [32, 128],
    "arbitration": ["round_robin"],
    "ecc": ["none", "secded"],
}
SUITE = ("rand_read", "mixed", "seq_read", "hotspot", "contention")


def candidate_cfg(c: dict, capacity: int, masters: int, wl: str, n_req: int, seed: int, ecc_delta: int = 0) -> dict:
    # SECDED: +ecc_delta cycles of bank read latency (measured on the RTL, data/ecc_study.json) and the stored-bit
    # overhead in the area axis.  Partial-write RMW and scrubbing are NOT exercised: this suite issues full-word writes.
    rl = c["read_latency"] + (ecc_delta if c.get("ecc") == "secded" else 0)
    return load_config({
        "name": "cand", "memory": {"banks": c["banks"], "bank_depth_words": capacity // (c["banks"] * c["word_bits"] // 8),
                                    "word_width_bits": c["word_bits"], "interleave": c["interleave"],
                                    "read_latency": rl, "ecc": c.get("ecc", "none")},
        "controller": {"masters": masters, "max_outstanding": c["max_out"], "arbitration": c["arbitration"]},
        "workload": {"kind": wl, "requests_per_master": n_req, "seed": seed, "write_fraction": 0.3, "hotspot_words": 8}})


def dominates(a, b) -> bool:
    """a dominates b when a <= b in every (minimised) objective and < in at least one."""
    return all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))


def pareto_front(points: list[tuple]) -> list[int]:
    idx = []
    for i, p in enumerate(points):
        if not any(dominates(q, p) for j, q in enumerate(points) if j != i):
            idx.append(i)
    return idx


def evaluate(space: dict | None = None, *, capacity: int = 65536, masters: int = 4, suite=SUITE, n_req: int = 600,
             replications: int = 2, seed: int = 1000, area_fn=None, energy_fn=None, progress=None) -> dict:
    space = dict(space or DEFAULT_SPACE)
    ecc_delta = ecc_read_latency_delta()
    dropped_ecc = False
    if "ecc" in space and "secded" in space["ecc"] and ecc_delta is None:
        space["ecc"] = [e for e in space["ecc"] if e != "secded"]       # no measurement -> do not assume one
        dropped_ecc = True
    keys = list(space)
    cands = []
    for combo in itertools.product(*(space[k] for k in keys)):
        c = dict(zip(keys, combo))
        cfg = candidate_cfg(c, capacity, masters, suite[0], n_req, seed, ecc_delta or 0)
        if not validate_config(cfg).ok:
            continue
        cands.append(c)
    rows = []
    for i, c in enumerate(cands):
        per_wl = {}
        for wl in suite:
            cfg = candidate_cfg(c, capacity, masters, wl, n_req, seed, ecc_delta or 0)
            b = E.benchmark(cfg, replications)
            s = b["summary"]
            per_wl[wl] = {
                "latency": s["read_latency_mean"]["mean"] if s["read_latency_mean"]["mean"] == s["read_latency_mean"]["mean"] else s["write_latency_mean"]["mean"],
                "latency_p99": s["read_latency_p99"]["mean"],
                "bandwidth": s["useful_bytes_per_cycle"]["mean"],
                "energy_proxy": s["bit_activations_per_useful_byte"]["mean"],
                "conflict": s["conflict_rate_per_access"]["mean"],
            }
        if progress and i % 8 == 0:
            progress(f"candidate {i + 1}/{len(cands)}")
        lat = float(np.mean([v["latency"] for v in per_wl.values()]))
        bw = float(np.mean([v["bandwidth"] for v in per_wl.values()]))
        en = float(np.mean([v["energy_proxy"] for v in per_wl.values()]))
        area = area_fn(c, capacity) if area_fn else {"value": None, "label": "unavailable", "note": "no area model supplied"}
        energy = energy_fn(c, capacity, en) if energy_fn else {"value": None, "label": "unavailable",
                                                                 "note": "no validated energy profile: activity proxy used"}
        rows.append({"candidate": c, "per_workload": per_wl, "latency": lat, "bandwidth": bw, "energy_proxy": en,
                     "area": area, "energy": energy,
                     "id": "/".join(f"{k}={c[k]}" for k in keys)})
    res = rank(rows, suite)
    if dropped_ecc:
        res["caveats"].append("ECC candidates were NOT evaluated: no data/ecc_study.json (run `sramlab ecc`), and ECC cost is never assumed")
    elif "ecc" in space and "secded" in space["ecc"]:
        res["caveats"].append(f"SECDED modelled as +{ecc_delta} cycle of bank read latency (measured on the RTL, data/ecc_study.json) and its stored-bit "
                              "overhead in the macro-footprint area; partial-write read-modify-write and scrub bandwidth are not exercised by this suite (full-word writes only)")
    return res


def _norm(v, lo, hi, invert=False):
    if hi == lo:
        return 0.0
    x = (v - lo) / (hi - lo)
    return 1 - x if invert else x


def rank(rows: list[dict], suite=SUITE, area_key=None) -> dict:
    have_area = all(r["area"]["value"] is not None for r in rows)
    have_energy = all(r["energy"]["value"] is not None for r in rows)
    for r in rows:
        r["obj"] = {
            "latency": r["latency"], "inv_bandwidth": -r["bandwidth"],
            "area": r["area"]["value"] if have_area else None,
            "energy": r["energy"]["value"] if have_energy else r["energy_proxy"],
        }
    axes = ["latency", "inv_bandwidth"] + (["area"] if have_area else []) + ["energy"]
    pts = [tuple(r["obj"][a] for a in axes) for r in rows]
    front = set(pareto_front(pts))
    for i, r in enumerate(rows):
        r["pareto"] = i in front
    # goal winners.  Ties (objective values equal within 1e-9 relative) are reported as ties, never broken
    # arbitrarily: an objective that does not discriminate between candidates must say so.
    def best(key, sign=1.0, unit=""):
        vals = [(rows[i]["obj"][key] if rows[i]["obj"][key] is not None else math.inf, i) for i in range(len(rows))]
        lo = min(v for v, _ in vals)
        tol = 1e-9 * max(1.0, abs(lo))
        win = [rows[i]["id"] for v, i in vals if v <= lo + tol]
        # best_value is reported in natural units (bandwidth is minimised internally as its negative)
        return {"best_value": sign * lo, "unit": unit, "winners": win[:8], "n_tied": len(win),
                "discriminates": len(win) < len(rows)}
    goals = {}
    goals["A_lowest_read_latency"] = best("latency", unit="cycles (suite-mean end-to-end read latency)")
    goals["B_highest_useful_bandwidth"] = best("inv_bandwidth", -1.0, "useful bytes/cycle (suite mean)")
    goals["C_lowest_area"] = best("area", unit="um^2 macro footprint") if have_area else "unavailable: no area model supplied"
    goals["D_lowest_energy_per_useful_byte" + ("" if have_energy else "_ACTIVITY_PROXY")] = best("energy", unit="array bits activated per useful byte" if not have_energy else "J/byte")
    # balanced: geometric mean of normalised objectives (lower better)
    ext = {a: (min(r["obj"][a] for r in rows), max(r["obj"][a] for r in rows)) for a in axes}
    def score(r, w=None):
        w = w or {a: 1.0 for a in axes}
        vals = [max(1e-3, _norm(r["obj"][a], *ext[a])) ** w[a] for a in axes]
        return float(np.prod(vals) ** (1.0 / sum(w.values())))
    for r in rows:
        r["balanced_score"] = score(r)
    order = sorted(range(len(rows)), key=lambda i: rows[i]["balanced_score"])
    lo = rows[order[0]]["balanced_score"]
    tied = [rows[i]["id"] for i in order if rows[i]["balanced_score"] <= lo + 1e-9]
    goals["E_balanced_ppa"] = {"best_value": lo, "winners": tied[:8], "n_tied": len(tied), "discriminates": len(tied) < len(rows)}
    # stability of the balanced winner under random weights (seeded)
    rng = SplitMix64(12345)
    wins: dict[str, int] = {}
    trials = 200
    for _ in range(trials):
        w = {a: 0.25 + 3 * rng.random() for a in axes}
        win = min(rows, key=lambda r: score(r, w))["id"]
        wins[win] = wins.get(win, 0) + 1
    # per-workload winners
    per_wl = {}
    for wl in suite:
        per_wl[wl] = {"lowest_latency": min(rows, key=lambda r: r["per_workload"][wl]["latency"])["id"],
                      "highest_bandwidth": max(rows, key=lambda r: r["per_workload"][wl]["bandwidth"])["id"]}
    distinct = {tuple(g["winners"]) for g in goals.values() if isinstance(g, dict)}
    distinct_wl = {v for d in per_wl.values() for v in d.values()}
    statement = (f"{len(distinct)} distinct configuration(s) are the top choice for the {sum(isinstance(g, dict) for g in goals.values())} "
                 f"goals evaluated (a goal whose objective does not discriminate lists all tied candidates), and {len(distinct_wl)} distinct configurations win at least one per-workload latency/bandwidth "
                 f"ranking; {sum(r['pareto'] for r in rows)} of {len(rows)} candidates are Pareto-optimal over {axes}. "
                 + ("No single configuration is optimal for every goal or workload."
                    if len(distinct) > 1 or len(distinct_wl) > 1 else
                    "In this candidate space one configuration happens to lead all goals; this is a property of the space, "
                    "not a universal result."))
    caveats = []
    if not have_area:
        caveats.append("AREA IS NOT PART OF THIS FRONT: without a cost axis more banks look better on latency/bandwidth; "
                       "this is not a recommendation")
    if have_area:
        note = next((r["area"].get("note", "") for r in rows if r["area"].get("note")), "")
        caveats.append("AREA AXIS = SRAM macro footprint only (" + note[:160] + "). Controller logic is NOT included "
                       "(its only available mapped area is in a different process family) - see the synthesis section for logic cost; "
                       "this is not a die area")
    if not have_energy:
        caveats.append("energy axis is the parameter-free activity proxy (array bits activated per useful byte); it does not "
                       "depend on bank size, so it cannot rank bank organisations - a validated energy profile is required")
    return {"label": "simulated", "caveats": caveats, "axes": axes, "area_available": have_area, "energy_is_proxy": not have_energy,
            "n_candidates": len(rows), "goals": goals, "pareto_ids": [r["id"] for r in rows if r["pareto"]],
            "balanced_weight_stability": dict(sorted(wins.items(), key=lambda kv: -kv[1])), "weight_trials": trials,
            "per_workload_winners": per_wl, "statement": statement, "candidates": rows}
