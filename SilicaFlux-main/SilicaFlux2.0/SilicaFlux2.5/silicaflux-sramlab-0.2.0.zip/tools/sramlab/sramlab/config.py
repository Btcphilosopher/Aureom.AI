"""Experiment configuration: parsing (YAML or JSON), defaults, and validation.

Every configuration is validated before anything runs; validation returns *all*
problems at once (not just the first) and distinguishes hard errors from
warnings.  The legal ranges mirror the elaboration-time checks of the real RTL
(sf_sram_controller / sf_sram_subsystem / sf_sram_core), so a configuration that
passes here elaborates in Verilator, and an illegal one is rejected here with
the same reason the RTL would give.

The same field table drives ``export_schema()`` (JSON-Schema written to
``schemas/experiment.schema.json``), so the documentation cannot drift from the
validator.
"""
from __future__ import annotations

import copy
import json
import math
import os
from dataclasses import dataclass, field
from typing import Any

try:  # PyYAML is optional: JSON always works
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None

SCHEMA_VERSION = "sramlab/experiment/1"

WORKLOAD_KINDS = (
    "seq_read", "seq_write", "rand_read", "rand_write", "mixed", "hotspot",
    "strided", "tensor_stream", "vector_load", "dma_burst", "contention",
)
ACCESS_PATTERN_ALIASES = {"sequential_read": "seq_read", "sequential_write": "seq_write",
                          "random_read": "rand_read", "random_write": "rand_write",
                          "mixed_rw": "mixed", "multi_master_contention": "contention"}
ECC_MODES = ("none", "secded")
MBIST_MODES = ("none", "march_c_minus", "mats_plus", "march_c_minus_parallel")
BACKENDS = ("generic", "fpga_bram", "asic_macro")
INTERLEAVES = ("low", "high")
ARBITRATIONS = ("round_robin", "priority")


class ConfigError(ValueError):
    """Raised when a configuration is invalid; ``.problems`` holds every message."""

    def __init__(self, problems: list[str]):
        self.problems = list(problems)
        super().__init__("invalid SRAMLab configuration:\n  - " + "\n  - ".join(problems))


@dataclass
class Validation:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


# ---------------------------------------------------------------------------
# default document
# ---------------------------------------------------------------------------
DEFAULTS: dict[str, Any] = {
    "schema": SCHEMA_VERSION,
    "name": "unnamed",
    "description": "",
    "memory": {
        "capacity_bytes": None,      # derived from banks*bank_depth_words*word_width_bits/8 when omitted
        "word_width_bits": 32,
        "banks": 4,
        "bank_depth_words": 1024,
        "interleave": "low",
        "read_latency": 1,           # int (all banks) or list (per bank)
        "ecc": "none",
        "mbist": "none",
        "dma_width_bits": 128,
        "init": "zero",
    },
    "controller": {
        "masters": 4,
        "max_outstanding": 1,
        "bank_out": 0,               # 0 = automatic (max bank latency + 1), as sf_sram_subsystem
        "arbitration": "round_robin",
        "hp_mask": 1,                # priority arbitration only: bit m = master m is HIGH class
        "hp_limit": 4,
        "id_width": 4,
        "id_check": True,
        "src_check": True,
        "mask_mode": "any",          # any | aligned
        "uniform_latency": "auto",   # auto | true | false  (bank-lock rule, see docs)
    },
    "workload": {
        "kind": "rand_read",
        "requests_per_master": 2000,
        "seed": 1,
        "request_rate": 1.0,         # probability a master is ready to present a new request each cycle
        "write_fraction": 0.5,       # mixed only
        "hotspot_fraction": 0.8,     # hotspot only
        "hotspot_words": 16,
        "stride_words": 4,
        "burst_words": 16,           # dma_burst only
        "response_ready_rate": 1.0,  # probability a master can take a response in a cycle
        "master_mix": None,          # optional list of per-master workload overrides
    },
    "physical": {
        "backend": "generic",
        "macro": None,               # asic_macro only: manifest macro_name
        "technology": "none",        # technology profile id/path ('none' = no library: area/energy unknown)
        "clock_mhz": None,           # an ASSUMPTION unless a timing report supplies it; None = report cycles only
    },
}

# (path, type-check description, allowed values) for the schema export
_FIELD_DOC = {
    "memory.word_width_bits": ("integer", [8, 16, 32, 64, 128], "bits per SRAM word (RTL: 8/16/32/64/128)"),
    "memory.banks": ("integer", None, "number of single-port banks (RTL: power of two, 1..16)"),
    "memory.bank_depth_words": ("integer", None, "words per bank (>= 2; power of two when interleave=high)"),
    "memory.capacity_bytes": ("integer|null", None, "total capacity; must equal banks*bank_depth_words*word_width_bits/8"),
    "memory.interleave": ("string", list(INTERLEAVES), "low: bank = word % banks; high: bank = word / bank_depth"),
    "memory.read_latency": ("integer|array", None, "bank read latency in cycles, 1..15, scalar or one per bank"),
    "memory.ecc": ("string", list(ECC_MODES), "none | secded"),
    "memory.mbist": ("string", list(MBIST_MODES), "MBIST algorithm / schedule"),
    "memory.dma_width_bits": ("integer", [32, 64, 128, 256, 512], "DMA beat width"),
    "controller.masters": ("integer", None, "number of request masters, 1..16"),
    "controller.max_outstanding": ("integer", None, "outstanding transactions per master, 1..16"),
    "controller.arbitration": ("string", list(ARBITRATIONS), "per-bank arbitration policy"),
    "workload.kind": ("string", list(WORKLOAD_KINDS), "access pattern"),
    "physical.backend": ("string", list(BACKENDS), "physical SRAM backend"),
}


def _deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(path_or_dict: str | os.PathLike | dict, *, validate: bool = True) -> dict:
    """Load a YAML/JSON file (or an already parsed dict), merge with defaults and validate."""
    if isinstance(path_or_dict, dict):
        raw = path_or_dict
    else:
        p = os.fspath(path_or_dict)
        with open(p, "r", encoding="utf-8") as fh:
            text = fh.read()
        if p.lower().endswith((".yaml", ".yml")):
            if yaml is None:
                raise ConfigError([f"{p}: PyYAML is not installed; use a .json configuration or `pip install pyyaml`"])
            raw = yaml.safe_load(text) or {}
        else:
            try:
                raw = json.loads(text)
            except json.JSONDecodeError as e:
                raise ConfigError([f"{p}: not valid JSON ({e})"]) from e
        if not isinstance(raw, dict):
            raise ConfigError([f"{p}: top level must be a mapping"])
    cfg = normalise(raw)
    if validate:
        v = validate_config(cfg)
        if not v.ok:
            raise ConfigError(v.errors)
    return cfg


def normalise(raw: dict) -> dict:
    """Merge defaults, resolve aliases, derive capacity/bank_depth."""
    unknown = set(raw) - set(DEFAULTS)
    cfg = _deep_merge(DEFAULTS, raw)
    cfg["_unknown_top_level_keys"] = sorted(unknown)
    wl = cfg["workload"]
    wl["kind"] = ACCESS_PATTERN_ALIASES.get(wl["kind"], wl["kind"])
    mem = cfg["memory"]
    # capacity <-> depth derivation (only when exactly one is given)
    wbytes = (mem["word_width_bits"] // 8) if isinstance(mem["word_width_bits"], int) and mem["word_width_bits"] >= 8 else None
    raw_mem = raw.get("memory", {}) if isinstance(raw.get("memory"), dict) else {}
    if wbytes and isinstance(mem["banks"], int) and mem["banks"] > 0:
        if "capacity_bytes" in raw_mem and raw_mem["capacity_bytes"] is not None and "bank_depth_words" not in raw_mem:
            cap = raw_mem["capacity_bytes"]
            if isinstance(cap, int) and cap % (mem["banks"] * wbytes) == 0:
                mem["bank_depth_words"] = cap // (mem["banks"] * wbytes)
        if mem["capacity_bytes"] is None and isinstance(mem["bank_depth_words"], int):
            mem["capacity_bytes"] = mem["banks"] * mem["bank_depth_words"] * wbytes
    return cfg


def _is_int(x) -> bool:
    return isinstance(x, int) and not isinstance(x, bool)


def _pow2(n: int) -> bool:
    return n > 0 and (n & (n - 1)) == 0


def bank_latencies(cfg: dict) -> list[int]:
    rl = cfg["memory"]["read_latency"]
    n = cfg["memory"]["banks"]
    return [int(x) for x in rl] if isinstance(rl, (list, tuple)) else [int(rl)] * n


def validate_config(cfg: dict) -> Validation:
    v = Validation()
    e, w = v.errors.append, v.warnings.append
    mem, ctl, wl, phy = cfg["memory"], cfg["controller"], cfg["workload"], cfg["physical"]

    for k in cfg.get("_unknown_top_level_keys", []):
        w(f"unknown top-level key '{k}' ignored")
    if cfg.get("schema") != SCHEMA_VERSION:
        w(f"schema is '{cfg.get('schema')}', expected '{SCHEMA_VERSION}'")

    # ---------------- memory
    ww = mem["word_width_bits"]
    if not _is_int(ww) or ww not in (8, 16, 32, 64, 128):
        e(f"memory.word_width_bits={ww!r}: must be one of 8, 16, 32, 64, 128 (sf_sram_controller DATA_WIDTH rule)")
    banks = mem["banks"]
    if not _is_int(banks) or not (1 <= banks <= 16) or not _pow2(banks):
        e(f"memory.banks={banks!r}: must be a power of two between 1 and 16 (sf_sram_controller NUM_BANKS rule)")
    depth = mem["bank_depth_words"]
    if not _is_int(depth) or depth < 2:
        e(f"memory.bank_depth_words={depth!r}: must be an integer >= 2")
    if mem["interleave"] not in INTERLEAVES:
        e(f"memory.interleave={mem['interleave']!r}: must be one of {INTERLEAVES}")
    elif mem["interleave"] == "high" and _is_int(depth) and depth >= 2 and not _pow2(depth):
        e(f"memory.interleave=high requires a power-of-two bank_depth_words (got {depth})")
    rl = mem["read_latency"]
    lats = rl if isinstance(rl, (list, tuple)) else [rl]
    if not all(_is_int(x) and 1 <= x <= 15 for x in lats):
        e(f"memory.read_latency={rl!r}: every latency must be an integer 1..15 (BANK_LATS is 4 bits per bank)")
    if isinstance(rl, (list, tuple)) and _is_int(banks) and len(rl) != banks:
        e(f"memory.read_latency has {len(rl)} entries but memory.banks={banks}")
    if mem["ecc"] not in ECC_MODES:
        e(f"memory.ecc={mem['ecc']!r}: must be one of {ECC_MODES}")
    elif mem["ecc"] == "secded" and _is_int(ww) and ww not in (32, 64, 128):
        e(f"memory.ecc=secded: the verified SECDED codecs cover 32/64/128-bit words (got {ww})")
    if mem["mbist"] not in MBIST_MODES:
        e(f"memory.mbist={mem['mbist']!r}: must be one of {MBIST_MODES}")
    if mem["dma_width_bits"] not in (32, 64, 128, 256, 512):
        e(f"memory.dma_width_bits={mem['dma_width_bits']!r}: must be one of 32/64/128/256/512")
    if mem["init"] not in ("zero",):
        e(f"memory.init={mem['init']!r}: only 'zero' is supported (reproducible; the controller never relies on initial content)")
    if _is_int(ww) and _is_int(banks) and _is_int(depth) and ww >= 8 and banks >= 1 and depth >= 2:
        cap = banks * depth * (ww // 8)
        if mem["capacity_bytes"] is not None and mem["capacity_bytes"] != cap:
            e(f"memory.capacity_bytes={mem['capacity_bytes']} != banks*bank_depth_words*word_bytes = {cap}")
        if cap > (1 << 32):
            e(f"capacity {cap} B exceeds the 32-bit byte address space")

    # ---------------- controller
    nm = ctl["masters"]
    if not _is_int(nm) or not (1 <= nm <= 16):
        e(f"controller.masters={nm!r}: must be an integer 1..16")
    mo = ctl["max_outstanding"]
    if not _is_int(mo) or not (1 <= mo <= 16):
        e(f"controller.max_outstanding={mo!r}: must be an integer 1..16")
    bo = ctl["bank_out"]
    if not _is_int(bo) or not (0 <= bo <= 32):
        e(f"controller.bank_out={bo!r}: must be 0 (automatic) or 1..32")
    if ctl["arbitration"] not in ARBITRATIONS:
        e(f"controller.arbitration={ctl['arbitration']!r}: must be one of {ARBITRATIONS}")
    if ctl["arbitration"] == "priority":
        if not _is_int(ctl["hp_limit"]) or ctl["hp_limit"] < 1:
            e("controller.hp_limit must be an integer >= 1")
        if not _is_int(ctl["hp_mask"]) or not (0 <= ctl["hp_mask"] < (1 << 16)):
            e("controller.hp_mask must be a 16-bit mask")
        elif _is_int(nm) and nm >= 1 and (ctl["hp_mask"] & ((1 << nm) - 1)) == 0:
            w("controller.hp_mask selects no existing master: arbitration degenerates to round robin")
    if not _is_int(ctl["id_width"]) or not (1 <= ctl["id_width"] <= 16):
        e("controller.id_width must be 1..16")
    if ctl["mask_mode"] not in ("any", "aligned"):
        e(f"controller.mask_mode={ctl['mask_mode']!r}: must be 'any' or 'aligned'")
    if ctl["uniform_latency"] not in ("auto", True, False):
        e(f"controller.uniform_latency={ctl['uniform_latency']!r}: must be auto/true/false")
    if ctl["uniform_latency"] is True and isinstance(rl, (list, tuple)) and len(set(rl)) > 1:
        e("controller.uniform_latency=true is only legal when every bank has the same latency "
          "(forcing it onto unequal banks violates the bank contract, see SRAMController docs/02 section 3)")

    # ---------------- workload
    if wl["kind"] not in WORKLOAD_KINDS:
        e(f"workload.kind={wl['kind']!r}: must be one of {WORKLOAD_KINDS}")
    if not _is_int(wl["requests_per_master"]) or wl["requests_per_master"] < 1:
        e("workload.requests_per_master must be an integer >= 1")
    if not _is_int(wl["seed"]):
        e("workload.seed must be an integer")
    for k in ("request_rate", "response_ready_rate", "write_fraction", "hotspot_fraction"):
        x = wl[k]
        if not isinstance(x, (int, float)) or isinstance(x, bool) or not (0.0 <= float(x) <= 1.0):
            e(f"workload.{k}={x!r}: must be a number in [0, 1]")
    if isinstance(wl["request_rate"], (int, float)) and wl["request_rate"] == 0:
        e("workload.request_rate=0 would never issue a request")
    if isinstance(wl["response_ready_rate"], (int, float)) and wl["response_ready_rate"] == 0:
        e("workload.response_ready_rate=0 would deadlock every master")
    for k in ("hotspot_words", "stride_words", "burst_words"):
        if not _is_int(wl[k]) or wl[k] < 1:
            e(f"workload.{k} must be an integer >= 1")
    if wl["master_mix"] is not None:
        mm = wl["master_mix"]
        if not isinstance(mm, list) or (_is_int(nm) and len(mm) != nm):
            e("workload.master_mix must be a list with one entry per master")
        else:
            for i, ent in enumerate(mm):
                k = ent.get("kind") if isinstance(ent, dict) else None
                if k is not None and ACCESS_PATTERN_ALIASES.get(k, k) not in WORKLOAD_KINDS:
                    e(f"workload.master_mix[{i}].kind={k!r} is not a known workload kind")

    # ---------------- physical
    if phy["backend"] not in BACKENDS:
        e(f"physical.backend={phy['backend']!r}: must be one of {BACKENDS}")
    if phy["backend"] == "asic_macro" and not phy.get("macro"):
        e("physical.backend=asic_macro requires physical.macro (a manifest macro_name)")
    if phy["backend"] != "asic_macro" and phy.get("macro"):
        w("physical.macro is ignored unless physical.backend=asic_macro")
    if phy["clock_mhz"] is not None and (not isinstance(phy["clock_mhz"], (int, float)) or phy["clock_mhz"] <= 0):
        e("physical.clock_mhz must be a positive number or null")
    if phy["clock_mhz"] is not None:
        w("physical.clock_mhz is an ASSUMPTION unless a timing report for the target technology supports it; "
          "all reports label MB/s figures derived from it as 'assumed clock'")
    return v


# ---------------------------------------------------------------------------
# derived views
# ---------------------------------------------------------------------------
def controller_params(cfg: dict):
    """Build the simulator parameter object from a validated config."""
    from .sim.controller import CtlParams  # local import: avoids cycles
    mem, ctl = cfg["memory"], cfg["controller"]
    uni = {"auto": -1, True: 1, False: 0}[ctl["uniform_latency"]]
    return CtlParams(
        num_masters=ctl["masters"], num_banks=mem["banks"], data_width=mem["word_width_bits"],
        bank_depth=mem["bank_depth_words"], id_width=ctl["id_width"], max_out=ctl["max_outstanding"],
        bank_out=ctl["bank_out"], interleave=mem["interleave"], id_check=int(ctl["id_check"]),
        src_check=int(ctl["src_check"]), mask_mode=ctl["mask_mode"],
        prio_en=int(ctl["arbitration"] == "priority"), hp_mask=ctl["hp_mask"], hp_limit=ctl["hp_limit"],
        bank_lats=bank_latencies(cfg), uniform_lat=uni,
    )


def config_hash(cfg: dict) -> str:
    import hashlib
    c = {k: v for k, v in cfg.items() if not k.startswith("_")}
    return hashlib.sha256(json.dumps(c, sort_keys=True, default=str).encode()).hexdigest()[:16]


def export_schema() -> dict:
    """JSON-Schema (draft 2020-12) generated from DEFAULTS and the field table."""
    def prop(path: str, default: Any) -> dict:
        d: dict[str, Any] = {"default": default}
        if path in _FIELD_DOC:
            typ, enum, desc = _FIELD_DOC[path]
            d["type"] = typ.split("|") if "|" in typ else typ
            if enum:
                d["enum"] = enum
            d["description"] = desc
        elif isinstance(default, bool):
            d["type"] = "boolean"
        elif isinstance(default, int):
            d["type"] = "integer"
        elif isinstance(default, float):
            d["type"] = "number"
        elif isinstance(default, str):
            d["type"] = "string"
        return d

    props: dict[str, Any] = {}
    for sec, body in DEFAULTS.items():
        if isinstance(body, dict):
            props[sec] = {"type": "object", "additionalProperties": False,
                          "properties": {k: prop(f"{sec}.{k}", v) for k, v in body.items()}}
        else:
            props[sec] = {"default": body}
    return {"$schema": "https://json-schema.org/draft/2020-12/schema", "$id": SCHEMA_VERSION,
            "title": "SRAMLab experiment configuration", "type": "object", "properties": props,
            "description": "Generated by sramlab.config.export_schema(); semantic checks (power-of-two, "
                           "capacity consistency, ...) live in validate_config()."}
