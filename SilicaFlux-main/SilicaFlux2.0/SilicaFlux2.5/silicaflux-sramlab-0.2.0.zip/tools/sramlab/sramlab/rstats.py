"""Independent R cross-check of SRAMLab's statistics (``sramlab rstats``).

Layer: **verification / analysis**.  SRAMLab's statistics are computed in Python/NumPy (``sramlab.stats``,
``sramlab.metrics``).  This module generates raw simulation output deterministically, computes the statistics in
Python, writes the RAW per-transaction and per-replication data to CSV, recomputes the same statistics in base R
(``scripts/r/sramlab_stats.R``; no R packages needed) and compares every value:

* per replication: read end-to-end latency mean / median / P95 / P99 (quantile type 7 = NumPy's linear rule),
  arbitration delay mean, request throughput            -> must agree to 1e-9 (relative)
* across replications: mean, sd and the Student-t 95 % CI half-width.  Python uses a 12-digit t table (df <= 30) and a
  Cornish-Fisher expansion beyond; R uses exact ``qt()``  -> half-widths agree to 1e-6 (relative)
* Spearman rank correlation of throughput with bank count         -> 1e-9

R also contributes two analyses Python does not do (reported, labelled ``analysis_r``, not compared):
a Kruskal-Wallis test of between-workload throughput variation and a log-log linear model of throughput on
bank count (an elasticity with a 95 % CI) per workload.  When ``Rscript`` is absent the check reports
``unavailable`` -- it never substitutes Python numbers for R numbers.
"""
from __future__ import annotations

import copy
import csv
import os
import subprocess
import tempfile

from . import experiments as E
from . import metrics, stats, tools
from .config import load_config

R_SCRIPT = os.path.join(tools.ROOT, "scripts", "r", "sramlab_stats.R")
DEFAULT_CONFIG = os.path.join(tools.ROOT, "configs", "four_bank_baseline.yaml")
WORKLOADS = ("rand_read", "mixed", "seq_read", "hotspot", "contention")
TOL_EXACT = 1e-9
TOL_TCI = 1e-6


def _cfg(base: dict, workload: str, seed: int, requests: int, banks: int | None = None) -> dict:
    c = copy.deepcopy(base)
    c["workload"]["kind"] = workload
    c["workload"]["seed"] = int(seed)
    c["workload"]["requests_per_master"] = int(requests)
    if banks is not None:
        cap = c["memory"]["banks"] * c["memory"]["bank_depth_words"]
        c["memory"]["banks"] = banks
        c["memory"]["capacity_bytes"] = None
        c["memory"]["bank_depth_words"] = cap // banks
        if isinstance(c["memory"]["read_latency"], list):
            c["memory"]["read_latency"] = c["memory"]["read_latency"][0]
    return load_config(c)


def collect(config_path: str = DEFAULT_CONFIG, replications: int = 8, requests: int = 300,
            sweep_banks=(2, 4, 8, 16), sweep_reps: int = 4) -> dict:
    base = load_config(config_path)
    tx_rows, rep_rows, sweep_rows = [], [], []
    py = {}
    seed0 = base["workload"]["seed"]
    for w in WORKLOADS:
        lat_mean, lat_p99, thr = [], [], []
        for r in range(replications):
            rr, m, _ = E.run_once(_cfg(base, w, seed0 + r, requests), track_data=False)
            t = rr.tx
            for i in range(len(t)):
                tx_rows.append((w, r, t.we[i], t.present[i], t.accept[i], t.push[i], t.xfer[i], t.status[i]))
            rep_rows.append((w, r, rr.cycles, m["transactions_accepted"]))
            le = m["read_latency_e2e"]
            pre = f"rep.{w}.{r}."
            py[pre + "read_lat_mean"] = le["mean"]
            py[pre + "read_lat_median"] = le["median"]
            py[pre + "read_lat_p95"] = le["p95"]
            py[pre + "read_lat_p99"] = le["p99"]
            py[pre + "arb_mean"] = m["arbitration_delay"]["mean"]
            py[pre + "throughput"] = m["request_throughput_txn_per_cycle"]
            lat_mean.append(le["mean"]); lat_p99.append(le["p99"]); thr.append(m["request_throughput_txn_per_cycle"])
        for nm, vals in (("lat_mean", lat_mean), ("lat_p99", lat_p99), ("thr", thr)):
            ci = stats.mean_ci(vals)
            for f, k in (("n", "n"), ("mean", "mean"), ("sd", "std"), ("half_width", "half_width")):
                py[f"ci.{w}.{nm}.{f}"] = ci.get(k)
    for w in WORKLOADS:
        xs, ys = [], []
        for nb in sweep_banks:
            for r in range(sweep_reps):
                rr, m, _ = E.run_once(_cfg(base, w, seed0 + 100 + r, requests, banks=nb), track_data=False)
                sweep_rows.append((w, nb, r, m["request_throughput_txn_per_cycle"]))
                xs.append(nb); ys.append(m["request_throughput_txn_per_cycle"])
        py[f"spearman.{w}.banks_throughput"] = stats.spearman(xs, ys)
    return {"tx": tx_rows, "reps": rep_rows, "sweep": sweep_rows, "python": py,
            "design": {"config": os.path.relpath(config_path, tools.ROOT), "workloads": list(WORKLOADS),
                       "replications": replications, "requests_per_master": requests,
                       "sweep_banks": list(sweep_banks), "sweep_replications": sweep_reps, "seed0": seed0}}


def _write(path, header, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def run_r(data: dict, workdir: str | None = None) -> dict:
    rs = tools.rscript()
    if rs is None:
        return {"available": False, "reason": "Rscript is not installed (the R cross-check is optional)"}
    wd = workdir or tempfile.mkdtemp(prefix="sramlab_r_")
    f_tx, f_rep, f_sw, f_out = (os.path.join(wd, n) for n in ("tx.csv", "reps.csv", "sweep.csv", "r_out.csv"))
    _write(f_tx, ("workload", "rep", "we", "present", "accept", "push", "xfer", "status"), data["tx"])
    _write(f_rep, ("workload", "rep", "cycles", "accepted"), data["reps"])
    _write(f_sw, ("workload", "banks", "rep", "throughput"), data["sweep"])
    p = subprocess.run([rs["exe"], "--vanilla", R_SCRIPT, f_tx, f_rep, f_sw, f_out], capture_output=True, text=True, timeout=600)
    if p.returncode != 0 or not os.path.exists(f_out):
        return {"available": True, "ok": False, "error": (p.stdout + p.stderr)[-2000:]}
    vals = {}
    with open(f_out) as f:
        for row in csv.DictReader(f):
            v = row["value"].strip()
            if v in ("NA", "NaN"):
                vals[row["key"]] = float("nan")             # R's NA / NaN (e.g. a correlation with a constant variable)
                continue
            try:
                vals[row["key"]] = float(v)
            except ValueError:
                vals[row["key"]] = v
    return {"available": True, "ok": True, "values": vals, "rscript": f"R {rs['version']}" if rs.get("version") else None}


def compare(py: dict, rv: dict) -> dict:
    rows = []
    for k, a in sorted(py.items()):
        b = rv.get(k)
        tol = TOL_TCI if k.endswith(".half_width") else TOL_EXACT
        if a is None or b is None or isinstance(b, str):
            rows.append({"quantity": k, "python": a, "r": b, "ok": False, "reason": "missing"})
            continue
        if a != a and b != b:                              # both NaN (e.g. constant samples)
            rows.append({"quantity": k, "python": a, "r": b, "abs_diff": 0.0, "rel_diff": 0.0, "tolerance": tol, "ok": True})
            continue
        d = abs(a - b)
        rel = d / max(abs(a), abs(b), 1e-300) if d else 0.0
        rows.append({"quantity": k, "python": a, "r": b, "abs_diff": d, "rel_diff": rel, "tolerance": tol,
                     "ok": rel <= tol or d <= 1e-12})
    bad = [r for r in rows if not r["ok"]]
    by_kind = {}
    for r in rows:
        kind = r["quantity"].split(".")[0] + ("." + r["quantity"].split(".")[-1] if r["quantity"].startswith("ci.") else "")
        s = by_kind.setdefault(kind, {"n": 0, "max_rel_diff": 0.0})
        s["n"] += 1
        s["max_rel_diff"] = max(s["max_rel_diff"], r.get("rel_diff", 0.0) or 0.0)
    return {"compared": len(rows), "agree": len(rows) - len(bad), "disagreements": bad[:20], "by_kind": by_kind, "rows": rows}


def crosscheck(config_path: str = DEFAULT_CONFIG, replications: int = 8, requests: int = 300, quick: bool = False) -> dict:
    if quick:
        replications, requests = 4, 120
    data = collect(config_path, replications, requests, sweep_reps=2 if quick else 4)
    r = run_r(data)
    out = {"design": data["design"], "provenance": "simulated (Python model), statistics recomputed independently in R",
           "tolerances": {"exact_quantities_rel": TOL_EXACT, "t_ci_half_width_rel": TOL_TCI,
                          "why_t_tolerance": "Python's t table has 12 significant digits (df <= 30) and a Cornish-Fisher expansion beyond; R uses exact qt()"}}
    if not r.get("available"):
        out.update({"status": "unavailable", "reason": r["reason"]})
        return out
    if not r.get("ok"):
        out.update({"status": "error", "error": r["error"]})
        return out
    cmp_ = compare(data["python"], r["values"])
    analysis = {k[len("analysis."):]: v for k, v in r["values"].items() if k.startswith("analysis.")}
    out.update({"status": "agree" if cmp_["agree"] == cmp_["compared"] else "DISAGREE", "rscript": r["rscript"],
                "comparison": {k: v for k, v in cmp_.items() if k != "rows"}, "rows": cmp_["rows"],
                "analysis_r": {"label": "analysis_r (computed in R only, not cross-checked)", "values": analysis,
                               "notes": ["kruskal_throughput_by_workload: H0 = throughput distribution is the same for every workload",
                                         "elasticity.<workload>.slope: d ln(throughput) / d ln(banks) from lm(log(thr) ~ log(banks)); "
                                         "a single slope over 2..16 banks is a summary, the relation need not be log-linear"]}})
    return out
