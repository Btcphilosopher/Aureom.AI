"""Cycle-accurate model of the SilicaFlux SRAM subsystem (SRAMController P73 + SRAMCore P71).

Layer: **simulation** (Python model, validated cycle-by-cycle against the Verilator
simulation of ``sf_sram_subsystem`` by ``sramlab rtlcheck``).

The model is a register-transfer transcription of
``rtl/third_party/p73_sramcontroller/sf_sram_controller.sv`` (+ ``sf_sramc_arb``,
``sf_sramc_fifo``, ``sf_sramc_perf``, ``sf_sramc_bank``): ``Controller.step`` evaluates
the combinational network of ONE clock cycle from the registered state and the
cycle's inputs, returns the cycle's outputs, then commits the state at the clock edge.

Cycle *t* convention (identical to the RTL docs): a signal "in cycle t" is its value
just before the rising edge that ends cycle t.  A request is accepted in cycle t when
``m_req_valid & m_req_ready``; the bank access is issued in the same cycle; an
error-free response is visible (``m_rsp_valid``) in cycle t + L + 1 for bank latency L.

Not modelled (documented, never silently): bank-reported errors (``SFC_ST_BANK``; a
valid ``sf_sram_core`` row address cannot fail), the sticky RTL status flags are
tracked but can only set on a protocol bug.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

# status codes (sf_sramc_defs.svh)
ST_OK, ST_RANGE, ST_ALIGN, ST_MASK, ST_SRC, ST_ID, ST_POISON, ST_CANCEL, ST_BANK = range(9)
STATUS_NAMES = ["OK", "RANGE", "ALIGN", "MASK", "SRC", "ID", "POISON", "CANCEL", "BANK"]

# performance counter index map (sf_sramc_defs.svh)
PG_CYCLES, PG_BUSY, PG_ACCEPTED, PG_COMPLETED, PG_RD_DONE, PG_WR_DONE, PG_ERR_DONE, PG_CONFLICT, \
    PG_ORDER_STALL, PG_CANCELLED, PG_OUT_MAX, PG_RSP_STALL, PG_WAIT = range(13)
PM_ACC, PM_CMP, PM_RD, PM_WR, PM_ERR, PM_WAIT_SUM, PM_WAIT_MAX, PM_LAT_SUM, PM_OUT_MAX, PM_RSP_STALL, \
    PM_ORDER_STALL, PM_CANCEL = range(12)
PB_ACCESS, PB_RD, PB_WR, PB_BUSY, PB_CONF_CYC, PB_LOSERS = range(6)

PG_NAMES = ["CYCLES", "BUSY", "ACCEPTED", "COMPLETED", "RD_DONE", "WR_DONE", "ERR_DONE", "CONFLICT",
            "ORDER_STALL", "CANCELLED", "OUT_MAX", "RSP_STALL", "WAIT"]
PM_NAMES = ["ACC", "CMP", "RD", "WR", "ERR", "WAIT_SUM", "WAIT_MAX", "LAT_SUM", "OUT_MAX", "RSP_STALL",
            "ORDER_STALL", "CANCEL"]
PB_NAMES = ["ACCESS", "RD", "WR", "BUSY", "CONF_CYC", "LOSERS"]

_M32 = 0xFFFFFFFF


def clog2(n: int) -> int:
    return max(0, (n - 1).bit_length())


@dataclass
class CtlParams:
    num_masters: int = 4
    num_banks: int = 4
    data_width: int = 32
    bank_depth: int = 1024
    id_width: int = 4
    max_out: int = 1
    bank_out: int = 0                 # 0 = automatic (max latency + 1), as sf_sram_subsystem
    interleave: str = "low"           # low | high
    id_check: int = 1
    src_check: int = 1
    mask_mode: str = "any"            # any | aligned
    prio_en: int = 0
    hp_mask: int = 1
    hp_limit: int = 4
    bank_lats: list = field(default_factory=list)
    uniform_lat: int = -1             # -1 auto, 0 force bank-lock, 1 force uniform

    def __post_init__(self):
        if not self.bank_lats:
            self.bank_lats = [1] * self.num_banks
        self.bank_lats = [1 if x == 0 else int(x) for x in self.bank_lats]
        assert len(self.bank_lats) == self.num_banks

    # ------ derived (mirror the localparams of sf_sram_subsystem / sf_sram_controller)
    @property
    def nbyte(self) -> int:
        return self.data_width // 8

    @property
    def off(self) -> int:
        return clog2(self.nbyte)

    @property
    def max_lat(self) -> int:
        return max(self.bank_lats)

    @property
    def min_lat(self) -> int:
        return min(self.bank_lats)

    @property
    def bank_out_eff(self) -> int:
        return self.max_lat + 1 if self.bank_out == 0 else self.bank_out

    @property
    def uniform_eff(self) -> int:
        if self.uniform_lat < 0:
            return 1 if self.min_lat == self.max_lat else 0
        return self.uniform_lat

    @property
    def total_words(self) -> int:
        return self.num_banks * self.bank_depth

    @property
    def total_bytes(self) -> int:
        return self.total_words * self.nbyte

    @property
    def bw(self) -> int:
        return clog2(self.num_banks) if self.num_banks > 1 else 1

    @property
    def raw(self) -> int:
        return clog2(self.bank_depth) if self.bank_depth > 1 else 1

    @property
    def nperf(self) -> int:
        return 16 + 16 * self.num_masters + 8 * self.num_banks


class Req:
    """One master request presented in a cycle (the m_req_* signals)."""
    __slots__ = ("we", "addr", "wdata", "wstrb", "id", "src", "err")

    def __init__(self, we=0, addr=0, wdata=0, wstrb=0, id=0, src=0, err=0):
        self.we, self.addr, self.wdata, self.wstrb, self.id, self.src, self.err = we, addr, wdata, wstrb, id, src, err


@dataclass
class CycleOut:
    cyc: int
    req_valid: list
    req_ready: list
    rsp_valid: list
    rsp_ready: list
    rsp: list            # per master: (id, we, status, rdata) of the head response or None
    bk_issue: list       # per bank: bool
    idle: bool
    # event view used by the driver / metrics
    accepted: list       # per master: bool (request accepted this cycle)
    pushed: list         # per master: bool (response entered the response FIFO at the end of this cycle)
    transferred: list    # per master: bool (response transferred this cycle)
    elig_count: list     # per bank: number of eligible masters (for conflict metrics)
    granted_master: list  # per bank: master index or -1
    order_stall: list    # per master: bool


class _Arb:
    """sf_sramc_arb: round robin with optional two-class priority and starvation guard."""
    __slots__ = ("n", "prio", "hpm", "hp_limit", "ptr_h", "ptr_l", "streak")

    def __init__(self, n, prio_en, hp_mask, hp_limit):
        self.n, self.prio, self.hp_limit = n, prio_en, hp_limit
        self.hpm = hp_mask & ((1 << n) - 1)
        self.ptr_h = self.ptr_l = self.streak = 0

    def pick(self, req_mask: int):
        """Returns (grant_index or -1, use_hp) from the pre-edge state; does not update."""
        n = self.n
        hp_req = (req_mask & self.hpm) if self.prio else 0
        lp_req = (req_mask & ~self.hpm) if self.prio else req_mask
        use_hp = bool(hp_req) and not (self.streak == self.hp_limit and lp_req != 0)
        pick_h = pick_l = -1
        if hp_req:
            for k in range(n):
                i = (self.ptr_h + k) % n
                if hp_req >> i & 1:
                    pick_h = i
                    break
        if lp_req:
            for k in range(n):
                i = (self.ptr_l + k) % n
                if lp_req >> i & 1:
                    pick_l = i
                    break
        if pick_h < 0 and pick_l < 0:
            return -1, False, lp_req
        return (pick_h if use_hp else pick_l), use_hp, lp_req

    def commit(self, g: int, use_hp: bool, lp_req: int):
        n = self.n
        if g < 0:
            return
        if use_hp:
            self.ptr_h = 0 if g == n - 1 else g + 1
            if lp_req:
                if self.streak != self.hp_limit:
                    self.streak += 1
            else:
                self.streak = 0
        else:
            self.ptr_l = 0 if g == n - 1 else g + 1
            self.streak = 0


class Controller:
    """Cycle model of sf_sram_subsystem (controller + NUM_BANKS sf_sramc_bank / sf_sram_core)."""

    def __init__(self, p: CtlParams, track_data: bool = True, perf: bool = True):
        self.p = p
        self.track_data = track_data
        nm, nb = p.num_masters, p.num_banks
        self.cyc = 0
        self.cnt = [0] * nm                      # outstanding (cnt_q)
        self.bf = [0] * nm                       # in a bank (bf_q)
        self.lkb = [0] * nm                      # bank-lock bank (lkb_q)
        self.oq = [deque() for _ in range(nm)]   # outstanding IDs in request order
        self.rf = [deque() for _ in range(nm)]   # response FIFOs: (rdata, we, id, status)
        self.tk = [deque() for _ in range(nb)]   # trackers: (master, id, we)
        self.cx = [0] * nb                       # cancel counters
        self.arb = [_Arb(nm, p.prio_en, p.hp_mask, p.hp_limit) for _ in range(nb)]
        self.pipe = [deque() for _ in range(nb)]  # bank pipelines: (due_cycle, we, rdata)
        self.mem = [dict() for _ in range(nb)] if track_data else None
        self.sts_proto = False
        self.sts_ovf = False
        # perf counters (sf_sramc_perf)
        self.perf_en = perf
        self.pg = [0] * 16
        self.pm = [[0] * 16 for _ in range(nm)]
        self.pb = [[0] * 8 for _ in range(nb)]
        self.run = [0] * nm
        self._wordmask = (1 << p.data_width) - 1
        self._lane_masks = [0xFF << (8 * l) for l in range(p.nbyte)]
        self._tot_bytes = p.total_bytes
        self._bw_mask = (1 << p.bw) - 1
        self._raw_mask = (1 << p.raw) - 1

    # ------------------------------------------------------------------ helpers
    def _mask_ok(self, w: int) -> bool:
        nbyte = self.p.nbyte
        s = 1
        while s <= nbyte:
            for pos in range(0, nbyte, s):
                if w == (((1 << s) - 1) << pos):
                    return True
            s *= 2
        return False

    def _decode(self, r: Req):
        p = self.p
        word = r.addr >> p.off
        if p.num_banks == 1:
            return 0, word & self._raw_mask
        if p.interleave == "low":
            return word & self._bw_mask, (word >> p.bw) & self._raw_mask
        return (word >> p.raw) & self._bw_mask, word & self._raw_mask

    def read_word(self, bank: int, row: int) -> int:
        return self.mem[bank].get(row, 0)

    def write_word(self, bank: int, row: int, wdata: int, wstrb: int):
        old = self.mem[bank].get(row, 0)
        new = old
        for l in range(self.p.nbyte):
            if wstrb >> l & 1:
                m = self._lane_masks[l]
                new = (new & ~m) | (wdata & m)
        self.mem[bank][row] = new

    # ------------------------------------------------------------------ one clock cycle
    def step(self, reqs, rsp_ready, src_en=None, flush=False) -> CycleOut:
        """reqs[m] is a Req (m_req_valid=1) or None; rsp_ready[m] is bool."""
        p = self.p
        nm, nb = p.num_masters, p.num_banks
        if src_en is None:
            src_en = [True] * nm
        uni = p.uniform_eff
        bank_out = p.bank_out_eff
        max_out = p.max_out

        rf_nonempty = [len(self.rf[m]) > 0 for m in range(nm)]
        pop_now = [rf_nonempty[m] and bool(rsp_ready[m]) for m in range(nm)]

        # ---- decode / checks
        d_st = [ST_OK] * nm
        d_bank = [0] * nm
        d_row = [0] * nm
        e_vb = [False] * nm
        e_bank = [False] * nm
        e_err = [False] * nm
        ord_stall = [False] * nm
        for m in range(nm):
            r = reqs[m]
            if r is None:
                continue
            st = ST_OK
            nbyte = p.nbyte
            mskbad = bool(r.we) and (r.wstrb == 0 or (p.mask_mode == "aligned" and not self._mask_ok(r.wstrb)))
            inrng = r.addr < self._tot_bytes
            aln = (r.addr & (nbyte - 1)) == 0
            srcbad = (not src_en[m]) or (p.src_check and r.src != m)
            idhit = False
            if p.id_check:
                head_popped = pop_now[m]
                for k, oid in enumerate(self.oq[m]):
                    if oid == r.id and not (head_popped and k == 0):
                        idhit = True
                        break
            if mskbad:
                st = ST_MASK
            if not aln:
                st = ST_ALIGN
            if not inrng:
                st = ST_RANGE
            if idhit:
                st = ST_ID
            if r.err:
                st = ST_POISON
            if srcbad:
                st = ST_SRC
            d_st[m] = st
            d_err = st != ST_OK
            if inrng and aln:
                d_bank[m], d_row[m] = self._decode(r)
            can_take = self.cnt[m] != max_out or pop_now[m]
            bank_ok = uni != 0 or self.bf[m] == 0 or self.lkb[m] == d_bank[m]
            e_vb[m] = (not flush) and (not d_err) and can_take
            e_bank[m] = e_vb[m] and bank_ok
            ord_stall[m] = e_vb[m] and not bank_ok
            e_err[m] = (not flush) and d_err and can_take and self.bf[m] == 0

        # ---- eligibility + per-bank arbitration (bk_req_ready is constant 1 for sf_sramc_bank)
        elig_mask = [0] * nb
        for m in range(nm):
            if e_bank[m]:
                b = d_bank[m]
                if len(self.tk[b]) < bank_out:
                    elig_mask[b] |= 1 << m
        grant = [-1] * nb
        arb_info = [None] * nb
        for b in range(nb):
            g, use_hp, lp_req = self.arb[b].pick(elig_mask[b])
            grant[b] = g
            arb_info[b] = (g, use_hp, lp_req)

        acc_bank = [False] * nm
        for b in range(nb):
            if grant[b] >= 0:
                acc_bank[grant[b]] = True
        acc_any = [acc_bank[m] or e_err[m] for m in range(nm)]
        req_ready = acc_any[:]

        # ---- bank completions due this cycle (bank latency pipeline) matched with tracker heads
        b_v = [False] * nb
        b_m = [0] * nb
        b_ent = [None] * nb
        tk_pop = [False] * nb
        for b in range(nb):
            comp = None
            if self.pipe[b] and self.pipe[b][0][0] == self.cyc:
                comp = self.pipe[b].popleft()
            if comp is not None and not self.tk[b]:
                self.sts_proto = True
            if comp is not None and self.tk[b]:
                h_m, h_id, h_we = self.tk[b][0]
                st = ST_CANCEL if self.cx[b] != 0 else ST_OK
                dat = 0 if (h_we or st != ST_OK) else comp[2]
                b_v[b] = True
                b_m[b] = h_m
                b_ent[b] = (dat, h_we, h_id, st)
                tk_pop[b] = True
        bank_push = [False] * nm
        bank_ent = [None] * nm
        for b in range(nb):
            if b_v[b]:
                bank_push[b_m[b]] = True
                bank_ent[b_m[b]] = b_ent[b]

        # ---- outputs of this cycle
        rsp = [None] * nm
        for m in range(nm):
            if rf_nonempty[m]:
                rdata, we, rid, st = self.rf[m][0]
                rsp[m] = (rid, we, st, rdata)
        idle = all(c == 0 for c in self.cnt)
        out = CycleOut(
            cyc=self.cyc, req_valid=[r is not None for r in reqs], req_ready=req_ready,
            rsp_valid=rf_nonempty, rsp_ready=[bool(x) for x in rsp_ready], rsp=rsp,
            bk_issue=[g >= 0 for g in grant], idle=idle, accepted=[False] * nm,
            pushed=[False] * nm, transferred=pop_now[:],
            elig_count=[bin(x).count("1") for x in elig_mask], granted_master=grant[:],
            order_stall=ord_stall[:],
        )
        for m in range(nm):
            out.accepted[m] = reqs[m] is not None and req_ready[m]

        # ---- performance counters (pre-edge values), sf_sramc_perf
        if self.perf_en:
            self._perf_update(reqs, req_ready, rf_nonempty, rsp_ready, pop_now, rsp, ord_stall,
                              grant, elig_mask, reqs_we=[(r.we if r is not None else 0) for r in reqs])

        # ================= clock edge: commit state =================
        # bank issue: array access at the accept edge, completion scheduled LAT cycles later
        for b in range(nb):
            g = grant[b]
            if g >= 0:
                r = reqs[g]
                rdata = 0
                if self.track_data:
                    if r.we:
                        self.write_word(b, d_row[g], r.wdata, r.wstrb)
                    else:
                        rdata = self.read_word(b, d_row[g])
                self.pipe[b].append((self.cyc + p.bank_lats[b], r.we, rdata))
                self.tk[b].append((g, r.id, r.we))      # tracker push (same edge as a possible pop)
        # trackers pop (head popped before the push above in hardware order; deque order handles it:
        # the pushed entry is appended behind the head, so popleft removes the old head)
        for b in range(nb):
            if tk_pop[b]:
                # the head is the oldest entry; a same-cycle push was appended at the tail
                self.tk[b].popleft()
        # per-master counters / queues
        for m in range(nm):
            if acc_any[m] and not pop_now[m]:
                self.cnt[m] += 1
            elif (not acc_any[m]) and pop_now[m]:
                self.cnt[m] -= 1
            if acc_bank[m] and not bank_push[m]:
                self.bf[m] += 1
            elif (not acc_bank[m]) and bank_push[m]:
                self.bf[m] -= 1
            if acc_bank[m]:
                for b in range(nb):
                    if grant[b] == m:
                        self.lkb[m] = b
            if pop_now[m]:
                self.oq[m].popleft()
            if acc_any[m]:
                self.oq[m].append(reqs[m].id)
        # cancel counters
        for b in range(nb):
            if flush:
                # tk_count (pre-edge, before this edge's push/pop) minus a pop in this cycle
                cnt_pre = len(self.tk[b]) - (1 if grant[b] >= 0 else 0) + (1 if tk_pop[b] else 0)
                self.cx[b] = cnt_pre - (1 if tk_pop[b] else 0)
            elif tk_pop[b] and self.cx[b] != 0:
                self.cx[b] -= 1
        # response FIFOs
        for m in range(nm):
            if pop_now[m]:
                self.rf[m].popleft()
            if bank_push[m] or e_err[m]:
                if e_err[m]:
                    ent = (0, reqs[m].we, reqs[m].id, d_st[m])
                else:
                    ent = bank_ent[m]
                if len(self.rf[m]) >= max_out and not pop_now[m]:
                    self.sts_ovf = True
                else:
                    self.rf[m].append(ent)
                out.pushed[m] = True
        # arbiter state
        for b in range(nb):
            g, use_hp, lp_req = arb_info[b]
            self.arb[b].commit(g, use_hp, lp_req)
        self.cyc += 1
        return out

    # ------------------------------------------------------------------ performance counters
    def _perf_update(self, reqs, req_ready, rf_nonempty, rsp_ready, pop_now, rsp, ord_stall,
                     grant, elig_mask, reqs_we):
        p = self.p
        nm, nb = p.num_masters, p.num_banks
        pg, pm, pb = self.pg, self.pm, self.pb
        n_acc = n_xfer = n_rd = n_wr = n_err = n_cancel = n_wait = n_rstall = n_ostall = n_tot_out = 0
        any_out = False
        ev_acc = [False] * nm
        for m in range(nm):
            valid = reqs[m] is not None
            ev_acc[m] = valid and req_ready[m]
            ev_xfer = pop_now[m]
            ev_wait = valid and not req_ready[m]
            ev_rstall = rf_nonempty[m] and not rsp_ready[m]
            if rsp[m] is not None:
                rid, we, st, _ = rsp[m]
            else:
                rid = we = st = 0
            r_err = st != ST_OK
            if ev_acc[m]:
                n_acc += 1
            if ev_xfer:
                n_xfer += 1
                if not we and not r_err:
                    n_rd += 1
                if we and not r_err:
                    n_wr += 1
                if r_err:
                    n_err += 1
                if st == ST_CANCEL:
                    n_cancel += 1
            if ev_wait:
                n_wait += 1
            if ev_rstall:
                n_rstall += 1
            if ord_stall[m]:
                n_ostall += 1
            n_tot_out += self.cnt[m]
            if self.cnt[m] != 0:
                any_out = True
            # per-master counters
            M = pm[m]
            if ev_acc[m]:
                M[PM_ACC] += 1
            if ev_xfer:
                M[PM_CMP] += 1
                if not we and not r_err:
                    M[PM_RD] += 1
                if we and not r_err:
                    M[PM_WR] += 1
                if r_err:
                    M[PM_ERR] += 1
                if st == ST_CANCEL:
                    M[PM_CANCEL] += 1
            if ev_wait:
                M[PM_WAIT_SUM] += 1
                self.run[m] += 1
                if self.run[m] > M[PM_WAIT_MAX]:
                    M[PM_WAIT_MAX] = self.run[m]
            else:
                self.run[m] = 0
            M[PM_LAT_SUM] += self.cnt[m]
            if self.cnt[m] > M[PM_OUT_MAX]:
                M[PM_OUT_MAX] = self.cnt[m]
            if ev_rstall:
                M[PM_RSP_STALL] += 1
            if ord_stall[m]:
                M[PM_ORDER_STALL] += 1
        n_los_tot = 0
        n_los_v = [0] * nb
        for b in range(nb):
            c = bin(elig_mask[b]).count("1")
            n_los_v[b] = c - 1 if c else 0
            n_los_tot += n_los_v[b]
        pg[PG_CYCLES] += 1
        if any_out:
            pg[PG_BUSY] += 1
        pg[PG_ACCEPTED] += n_acc
        pg[PG_COMPLETED] += n_xfer
        pg[PG_RD_DONE] += n_rd
        pg[PG_WR_DONE] += n_wr
        pg[PG_ERR_DONE] += n_err
        pg[PG_CONFLICT] += n_los_tot
        pg[PG_ORDER_STALL] += n_ostall
        pg[PG_CANCELLED] += n_cancel
        if n_tot_out > pg[PG_OUT_MAX]:
            pg[PG_OUT_MAX] = n_tot_out
        pg[PG_RSP_STALL] += n_rstall
        pg[PG_WAIT] += n_wait
        for b in range(nb):
            B = pb[b]
            if grant[b] >= 0:
                B[PB_ACCESS] += 1
                if reqs_we[grant[b]]:
                    B[PB_WR] += 1
                else:
                    B[PB_RD] += 1
            if len(self.tk[b]) != 0:
                B[PB_BUSY] += 1
            if n_los_v[b] != 0:
                B[PB_CONF_CYC] += 1
            B[PB_LOSERS] += n_los_v[b]

    def perf_vector(self) -> list[int]:
        """All NPERF counters in the hardware index order (perf_sel = 0 .. NPERF-1)."""
        p = self.p
        v = [0] * p.nperf
        for i in range(16):
            v[i] = self.pg[i] & _M32
        for m in range(p.num_masters):
            for k in range(16):
                v[16 + 16 * m + k] = self.pm[m][k] & _M32
        for b in range(p.num_banks):
            for k in range(8):
                v[16 + 16 * p.num_masters + 8 * b + k] = self.pb[b][k] & _M32
        return v

    def perf_dict(self) -> dict:
        p = self.p
        d = {"global": {PG_NAMES[i]: self.pg[i] for i in range(len(PG_NAMES))},
             "master": [{PM_NAMES[k]: self.pm[m][k] for k in range(len(PM_NAMES))} for m in range(p.num_masters)],
             "bank": [{PB_NAMES[k]: self.pb[b][k] for k in range(len(PB_NAMES))} for b in range(p.num_banks)]}
        return d
