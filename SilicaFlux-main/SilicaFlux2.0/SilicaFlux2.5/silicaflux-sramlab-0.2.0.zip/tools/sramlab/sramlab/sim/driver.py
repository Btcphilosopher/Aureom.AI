"""Master drivers, transaction log and the run loop around :class:`Controller`.

Master model (identical in this Python driver and in the RTL testbench
``rtl/tb/tb_sramlab_ctl.sv``, which is what makes cycle-by-cycle comparison possible):

* master *m* owns an ordered list of :class:`ReqSpec`;
* request *i* may be presented from cycle ``ready_at``; ``ready_at`` of request 0 is
  ``spec[0].delay``; after request *i* is accepted in cycle *t*, ``ready_at`` of
  request *i+1* is ``t + 1 + spec[i+1].delay``;
* once presented, ``m_req_valid`` and the payload stay unchanged until accepted (SFB2 R2);
* the request ID is ``i mod 2**ID_WIDTH``; ``m_req_src`` = the port index;
* ``m_rsp_ready`` is a predetermined per-cycle bit (all ones when the response-ready
  rate is 1.0), generated from a seed so the RTL testbench can replay the same bits.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..prng import SplitMix64
from .controller import Controller, CtlParams, Req, ST_OK


@dataclass
class ReqSpec:
    we: int
    addr: int            # byte address
    wdata: int = 0
    wstrb: int = 0
    delay: int = 0
    err: int = 0         # poison flag (m_req_err)
    tag: int = 0         # free-form workload tag (see sim/streams.py TAG_NAMES)
    useful: int = -1     # requester-useful bytes carried by this word access (-1 = the whole word / strobe)


class ReadyMasks:
    """Per-master, per-cycle m_rsp_ready bits; lazily generated, deterministic, replayable."""

    def __init__(self, num_masters: int, rate: float, seed: int):
        self.n = num_masters
        self.rate = rate
        self._rng = [SplitMix64(seed ^ 0x5EED5EED).fork(1000 + m) for m in range(num_masters)]
        self._bits: list[list[bool]] = [[] for _ in range(num_masters)]

    def at(self, cyc: int) -> list[bool]:
        if self.rate >= 1.0:
            return [True] * self.n
        for m in range(self.n):
            b = self._bits[m]
            while len(b) <= cyc:
                b.append(self._rng[m].random() < self.rate)
        return [self._bits[m][cyc] for m in range(self.n)]

    def dump(self, ncycles: int) -> list[int]:
        """Mask per cycle (bit m = master m), for cycles 0..ncycles-1."""
        out = []
        for c in range(ncycles):
            v = self.at(c)
            out.append(sum(1 << m for m in range(self.n) if v[m]))
        return out


@dataclass
class TxLog:
    """Per-transaction record, one entry per accepted request (parallel lists)."""
    master: list = field(default_factory=list)
    index: list = field(default_factory=list)       # request index within the master's script
    we: list = field(default_factory=list)
    addr: list = field(default_factory=list)
    bank: list = field(default_factory=list)
    tag: list = field(default_factory=list)
    present: list = field(default_factory=list)     # first cycle the request was presented
    accept: list = field(default_factory=list)      # cycle accepted (== bank access issue cycle)
    push: list = field(default_factory=list)        # cycle whose edge puts the response into the FIFO
    xfer: list = field(default_factory=list)        # cycle the response was transferred
    status: list = field(default_factory=list)
    rdata: list = field(default_factory=list)
    wdata: list = field(default_factory=list)
    wstrb: list = field(default_factory=list)
    useful: list = field(default_factory=list)

    def __len__(self):
        return len(self.master)


@dataclass
class RunResult:
    params: CtlParams
    cycles: int                 # number of simulated cycles (cycle indices 0..cycles-1)
    tx: TxLog
    perf: list                  # hardware counter vector, perf_sel order
    perf_dict: dict
    trace: list | None
    drained: bool
    integrity_errors: list      # data-integrity mismatches vs. the flat reference memory
    queue_hist: dict            # histograms collected per cycle
    sts_proto: bool
    sts_ovf: bool
    mem_final: list | None = None


def run_scripts(p: CtlParams, scripts: list[list[ReqSpec]], ready: ReadyMasks, *, max_cycles: int = 5_000_000,
                trace: bool = False, track_data: bool = True, src_en=None, flush_cycles=(),
                fixed_cycles: int | None = None) -> RunResult:
    """Run scripts to completion (or exactly ``fixed_cycles`` cycles) and collect everything."""
    nm = p.num_masters
    assert len(scripts) == nm
    ctl = Controller(p, track_data=track_data)
    idmod = 1 << p.id_width
    idx = [0] * nm
    ready_at = [scripts[m][0].delay if scripts[m] else 1 << 60 for m in range(nm)]
    first_present: list[int | None] = [None] * nm
    from collections import deque
    pend = [deque() for _ in range(nm)]      # accepted, not yet transferred: tx index
    pushq = [deque() for _ in range(nm)]     # accepted, not yet pushed
    tx = TxLog()
    tr: list | None = [] if trace else None
    flush_set = set(flush_cycles)
    # histograms (per cycle sampling)
    occ_out = [0] * (p.num_masters * p.max_out + 1)           # total outstanding
    occ_tk = [[0] * (p.bank_out_eff + 1) for _ in range(p.num_banks)]  # tracker occupancy per bank
    occ_rf = [0] * (p.max_out + 1)
    total_req = sum(len(s) for s in scripts)
    accepted_total = 0
    xfer_total = 0
    cyc = 0
    drained = False
    while cyc < max_cycles:
        reqs: list[Req | None] = [None] * nm
        for m in range(nm):
            i = idx[m]
            if i < len(scripts[m]) and cyc >= ready_at[m]:
                s = scripts[m][i]
                reqs[m] = Req(s.we, s.addr, s.wdata, s.wstrb, i % idmod, m, s.err)
                if first_present[m] is None:
                    first_present[m] = cyc
        rdy = ready.at(cyc)
        # sample occupancies before the edge (these are the registered values of cycle `cyc`)
        occ_out[min(sum(ctl.cnt), len(occ_out) - 1)] += 1
        for b in range(p.num_banks):
            occ_tk[b][min(len(ctl.tk[b]), len(occ_tk[b]) - 1)] += 1
        for m in range(nm):
            occ_rf[min(len(ctl.rf[m]), len(occ_rf) - 1)] += 1
        out = ctl.step(reqs, rdy, src_en=src_en, flush=(cyc in flush_set))
        if tr is not None:
            tr.append(out)
        for m in range(nm):
            if out.accepted[m]:
                s = scripts[m][idx[m]]
                t = len(tx)
                tx.master.append(m); tx.index.append(idx[m]); tx.we.append(s.we); tx.addr.append(s.addr)
                tx.bank.append(ctl._decode(reqs[m])[0] if (s.addr < p.total_bytes) else -1)
                tx.tag.append(s.tag)
                tx.present.append(first_present[m]); tx.accept.append(cyc)
                tx.push.append(-1); tx.xfer.append(-1); tx.status.append(-1); tx.rdata.append(0)
                tx.wdata.append(s.wdata); tx.wstrb.append(s.wstrb); tx.useful.append(s.useful)
                pend[m].append(t)
                pushq[m].append(t)
                accepted_total += 1
                idx[m] += 1
                first_present[m] = None
                if idx[m] < len(scripts[m]):
                    ready_at[m] = cyc + 1 + scripts[m][idx[m]].delay
        for m in range(nm):
            if out.pushed[m]:
                t = pushq[m].popleft()
                tx.push[t] = cyc
            if out.transferred[m]:
                t = pend[m].popleft()
                rid, we, st, rdata = out.rsp[m]
                tx.xfer[t] = cyc
                tx.status[t] = st
                tx.rdata[t] = rdata
                xfer_total += 1
        cyc += 1
        if fixed_cycles is not None:
            if cyc >= fixed_cycles:
                break
        elif accepted_total == total_req and xfer_total == accepted_total and all(c == 0 for c in ctl.cnt):
            drained = True
            break
    else:
        pass
    if fixed_cycles is not None:
        drained = accepted_total == total_req and xfer_total == accepted_total
    errs = check_integrity(p, tx) if track_data else []
    return RunResult(params=p, cycles=cyc, tx=tx, perf=ctl.perf_vector(), perf_dict=ctl.perf_dict(), trace=tr,
                     drained=drained, integrity_errors=errs,
                     queue_hist={"outstanding_total": occ_out, "tracker": occ_tk, "rsp_fifo": occ_rf},
                     sts_proto=ctl.sts_proto, sts_ovf=ctl.sts_ovf,
                     mem_final=None if ctl.mem is None else [dict(x) for x in ctl.mem])


def check_integrity(p: CtlParams, tx: TxLog, limit: int = 20) -> list:
    """Replay accepted requests against a *flat* byte-addressed memory (knows nothing about banks).

    Requests accepted in different cycles apply in accept order; two requests accepted in the same
    cycle go to different banks and therefore different words, so any order is equivalent.  A read
    must return the content of the word as of its accept cycle.  Because the oracle is flat, a
    mapping bug (aliasing, wrong bank/row) shows up as a read-data mismatch.
    """
    mem: dict[int, int] = {}
    nb = p.nbyte
    lane_masks = [0xFF << (8 * l) for l in range(nb)]
    order = sorted(range(len(tx)), key=lambda i: (tx.accept[i], i))
    errs = []
    for i in order:
        st = tx.status[i]
        if st == -1:
            continue                       # run stopped before the response (fixed-cycle runs)
        if st != ST_OK:
            continue
        word = tx.addr[i] >> p.off
        if tx.we[i]:
            old = mem.get(word, 0)
            for l in range(nb):
                if tx.wstrb[i] >> l & 1:
                    old = (old & ~lane_masks[l]) | (tx.wdata[i] & lane_masks[l])
            mem[word] = old
        else:
            exp = mem.get(word, 0)
            if tx.rdata[i] != exp:
                errs.append({"tx": i, "master": tx.master[i], "addr": tx.addr[i], "expected": exp, "got": tx.rdata[i]})
                if len(errs) >= limit:
                    break
    return errs
