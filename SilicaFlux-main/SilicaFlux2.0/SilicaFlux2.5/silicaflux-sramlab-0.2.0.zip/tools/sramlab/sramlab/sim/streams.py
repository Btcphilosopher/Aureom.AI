"""Structured request streams: DMA bursts, vector memory accesses, tensor operand streams.

These decompose a *logical* access (a vector load, a DMA burst, a tensor k-slice) into the
word-granular, word-aligned transactions the SRAMController actually accepts, and tag every
request so the metrics layer can separate useful bytes from alignment/padding overhead.

Tags (``ReqSpec.tag``): 0 generic, 1 tensor-A operand, 2 tensor-B operand, 3 accumulator
read, 4 accumulator write, 5 DMA, 6 vector load, 7 vector store.
"""
from __future__ import annotations

from ..prng import SplitMix64
from .controller import CtlParams
from .driver import ReqSpec

TAG_GENERIC, TAG_A, TAG_B, TAG_ACC_RD, TAG_ACC_WR, TAG_DMA, TAG_VLOAD, TAG_VSTORE = range(8)
TAG_NAMES = ["generic", "tensor_A", "tensor_B", "acc_read", "acc_write", "dma", "vector_load", "vector_store"]


def _data(rng: SplitMix64, bits: int) -> int:
    v = 0
    for _ in range((bits + 63) // 64):
        v = (v << 64) | rng.next_u64()
    return v & ((1 << bits) - 1)


def split_access(p: CtlParams, byte_addr: int, nbytes: int, we: int, rng: SplitMix64, tag: int,
                 byte_mask: int | None = None, delay: int = 0) -> tuple[list[ReqSpec], int]:
    """Decompose a byte-granular access into word transactions.

    Returns (requests, useful_bytes).  ``byte_mask`` (bit i = byte i of the access is valid) models
    partial stores; the controller accepts any non-zero strobe pattern (MASK_MODE=any).  Reads always
    fetch whole words (the controller has no byte-granular read), so the fetched byte count exceeds
    ``useful_bytes`` whenever the access is not word-aligned -- that excess is the alignment overhead.
    """
    nb = p.nbyte
    first = byte_addr // nb
    last = (byte_addr + nbytes - 1) // nb
    reqs: list[ReqSpec] = []
    useful = 0
    for w in range(first, last + 1):
        lo = max(byte_addr, w * nb)
        hi = min(byte_addr + nbytes, (w + 1) * nb)
        strobe = 0
        for byte in range(lo, hi):
            if byte_mask is None or (byte_mask >> (byte - byte_addr)) & 1:
                strobe |= 1 << (byte - w * nb)
                useful += 1
        if we and strobe == 0:
            continue                      # an all-masked word is not accessed (would be a MASK error)
        word_useful = bin(strobe).count("1")
        reqs.append(ReqSpec(we=we, addr=w * nb, wdata=_data(rng, p.data_width) if we else 0,
                            wstrb=strobe if we else 0, delay=0, tag=tag, useful=word_useful))
    if reqs:
        reqs[0].delay = delay
    return reqs, useful


def gen_dma(p: CtlParams, m: int, n: int, rng: SplitMix64, o: dict) -> list[ReqSpec]:
    """DMA bursts: ``burst_words`` sequential words back to back, then an idle gap, alternating
    read bursts (source) and write bursts (destination) in disjoint regions."""
    bw = int(o.get("burst_words", 16))
    gap = int(o.get("dma_gap_cycles", 8))
    tw = p.total_words
    src = (m * 2) * (tw // max(2, 2 * p.num_masters))
    dst = src + tw // max(2, 2 * p.num_masters)
    out: list[ReqSpec] = []
    k = 0
    write_phase = False
    while len(out) < n:
        base = dst if write_phase else src
        for j in range(bw):
            if len(out) >= n:
                break
            w = (base + k + j) % tw
            out.append(ReqSpec(we=int(write_phase), addr=w * p.nbyte,
                               wdata=_data(rng, p.data_width) if write_phase else 0,
                               wstrb=((1 << p.nbyte) - 1) if write_phase else 0,
                               delay=gap if j == 0 and out else 0, tag=TAG_DMA))
        if write_phase:
            k += bw
        write_phase = not write_phase
    return out


def gen_vector(p: CtlParams, m: int, n: int, rng: SplitMix64, o: dict) -> list[ReqSpec]:
    """Vector memory stream: loads of ``vector_bits`` at a configurable byte misalignment.

    Options: vector_bits (128|256), misalign_bytes (offset of every vector from a word boundary),
    stride_bytes (distance between vectors; default = vector size), store_fraction + partial_store.
    """
    vbytes = int(o.get("vector_bits", 128)) // 8
    mis = int(o.get("misalign_bytes", 0))
    stride = int(o.get("stride_bytes", vbytes))
    sf = float(o.get("store_fraction", 0.0))
    partial = bool(o.get("partial_store", False))
    total_bytes = p.total_bytes
    base = (m * (total_bytes // max(1, p.num_masters)) // 64) * 64
    out: list[ReqSpec] = []
    k = 0
    while len(out) < n:
        addr = (base + mis + k * stride) % (total_bytes - 2 * vbytes)
        store = rng.bernoulli(sf)
        mask = None
        if store and partial:
            mask = (1 << vbytes) - 1
            mask &= ~(0xF << (4 * rng.randbelow(max(1, vbytes // 4))))   # mask off one 4-byte group
        rq, _ = split_access(p, addr, vbytes, int(store), rng, TAG_VSTORE if store else TAG_VLOAD, mask)
        out.extend(rq)
        k += 1
    return out[:n]


def generate(p: CtlParams, m: int, kind: str, n: int, rng: SplitMix64, o: dict) -> list[ReqSpec]:
    if kind == "dma_burst":
        return gen_dma(p, m, n, rng, o)
    if kind == "vector_load":
        return gen_vector(p, m, n, rng, o)
    if kind == "tensor_stream":
        from . import tensor
        return tensor.gen_tensor(p, m, n, rng, o)
    raise ValueError(kind)
