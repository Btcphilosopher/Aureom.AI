"""SilicaFlux TensorCore memory study.

Two views of the real TensorCore access stream (sources: SilicaFlux TENSORCORE 02/03/08 docs and the
TensorScratch P75 design, audited in docs/00_audit.md):

``TensorSystem`` (closed loop, mode ``direct`` - the TensorScratch architecture)
    A 4x4 INT8 output-stationary array (PE(i,j) owns C[i][j]; one k-slice per cycle at II=1 = 16 MAC/cycle
    peak) is fed *directly* from the banked single-port SRAM:
      * A operand: lane i needs A[m0+i][k] every k-step, but a 32-bit word carries 4 consecutive k, so each
        lane reads one word per 4 k-steps (4 lanes -> 1 word/cycle on average, on the "A port" master)
      * B operand: row k of the B tile, B[k][n0..n0+3] = 4 bytes = one word per k-step ("B port" master)
      * accumulator: the finished 4x4 INT32 tile (16 words) is written back through the "C port" master
      * DMA fill: an independent master writes the next operands into SRAM at a configurable duty
    Every request goes through the verified Controller (per-bank round-robin arbitration, credits,
    bank-lock, response latency), so bank conflicts caused by the matrix pitches, DMA contention and
    insufficient banks emerge from the real protocol.  The array fires a k-slice only when the A word of
    all four lanes for that k-group AND the B word for that k have arrived (operand starvation otherwise).

``gen_tensor`` (open loop, kind ``tensor_stream``)
    The TENSORCORE 08 DMA command stream: per (4x4 output tile, K-chunk of TILE_K) LOAD_A = 4 rows x TILE_K
    bytes and LOAD_B = TILE_K rows x 4 bytes (128 32-bit words per 1024 MAC at TILE_K=64), then STORE of the
    4x4 INT32 tile; no operand reuse between tiles (traffic 3.3-16.2x compulsory per the TC10 benchmarks).
    Open-loop so the identical stream can be replayed on the RTL for exact comparison.

What is *not* modelled and therefore not claimed: the TC03 operand-buffer RTL internals, the array's pipeline
fill/drain beyond the explicit ``slice_overhead`` parameter, and any clock frequency or power.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..prng import SplitMix64
from .controller import Controller, CtlParams, Req
from .driver import ReqSpec, ReadyMasks
from .streams import TAG_A, TAG_ACC_WR, TAG_B, TAG_DMA

R = C = 4


@dataclass
class TensorCfg:
    M: int = 16
    N: int = 16
    K: int = 64
    lda: int | None = None          # byte pitch of A rows (default K)
    ldb: int | None = None          # byte pitch of B rows (default N)
    ldc: int | None = None          # byte pitch of C rows (INT32; default 4*N)
    a_stage: int = 8                # words of A look-ahead (in flight + buffered) per lane group
    b_stage: int = 8                # words of B look-ahead
    dma_duty: float = 0.0           # fraction of cycles the DMA master presents a fill write
    dma_reads: bool = False         # DMA also reads (copy traffic)
    tile_overhead: int = 0          # idle cycles between tiles (array launch/drain), a parameter not a fact
    seed: int = 1
    a_base_words: int = 0
    max_cycles: int = 2_000_000

    def pitches(self):
        return (self.lda or self.K, self.ldb or self.N, self.ldc or 4 * self.N)


@dataclass
class TensorResult:
    cycles: int
    macs: int
    mac_utilisation: float
    slices: int
    peak_slices_per_cycle: float
    starvation_cycles: int
    starvation_fraction: float
    a_words: int
    b_words: int
    c_words: int
    dma_words: int
    a_delivery_words_per_cycle: float
    b_delivery_words_per_cycle: float
    acc_traffic_words_per_cycle: float
    buffer_occupancy_a_mean: float
    buffer_occupancy_b_mean: float
    dma_overlap_fraction: float
    bank_conflict_events: int
    operand_bytes_per_cycle: float
    required_operand_bytes_per_cycle: float
    perf: dict = field(default_factory=dict)
    notes: list = field(default_factory=list)


class _Stream:
    """In-order word-read stream for one operand with a bounded look-ahead window."""

    def __init__(self, addrs, stage):
        self.addrs = addrs            # list of word indices in consumption order
        self.next_issue = 0           # index of next word to request
        self.arrived = 0              # words received (in order per master by the controller)
        self.consumed = 0
        self.stage = stage

    def can_issue(self):
        return self.next_issue < len(self.addrs) and (self.next_issue - self.consumed) < self.stage


class TensorSystem:
    def __init__(self, p: CtlParams, t: TensorCfg):
        if p.num_masters < 3:
            raise ValueError("tensor study needs >= 3 masters (A port, B port, C/DMA); got %d" % p.num_masters)
        self.p, self.t = p, t

    # word index helpers (32-bit-word view of byte addresses; works for any DATA_WIDTH because the
    # controller's word is p.nbyte bytes: requests are issued per *controller word* covering the bytes)
    def _words_covering(self, byte_addr, nbytes):
        nb = self.p.nbyte
        return list(range(byte_addr // nb, (byte_addr + nbytes - 1) // nb + 1))

    def build(self):
        p, t = self.p, self.t
        lda, ldb, ldc = t.pitches()
        nb = p.nbyte
        a_base = t.a_base_words * nb
        b_base = a_base + ((t.M * lda + 63) // 64) * 64
        c_base = b_base + ((t.K * ldb + 63) // 64) * 64
        dma_base = c_base + ((t.M * ldc + 63) // 64) * 64
        if dma_base + 4096 > p.total_bytes:
            raise ValueError("matrix operands do not fit the SRAM: need %d B, have %d B" % (dma_base + 4096, p.total_bytes))
        self.a_base, self.b_base, self.c_base, self.dma_base = a_base, b_base, c_base, dma_base
        tiles = [(m0, n0) for m0 in range(0, t.M, R) for n0 in range(0, t.N, C)]
        self.tiles = tiles
        return lda, ldb, ldc

    def run(self) -> TensorResult:
        p, t = self.p, self.t
        lda, ldb, ldc = self.build()
        nb = p.nbyte
        K = t.K
        ctl = Controller(p, track_data=False)
        rng = SplitMix64(t.seed)
        ntiles = len(self.tiles)
        # ---- per-tile operand word lists
        def a_words(m0):                       # per k-group g (4 k-steps), 4 lane words (rows m0..m0+3)
            out = []
            for g in range((K + 3) // 4):
                for i in range(R):
                    out.append((self.a_base + (m0 + i) * lda + 4 * g) // nb)
            return out

        def b_words(n0):                       # per k, the 4 bytes B[k][n0..n0+3]
            return [(self.b_base + k * ldb + n0) // nb for k in range(K)]

        def c_words(m0, n0):                   # 4 rows x 4 INT32 = 16 bytes per row
            ws = []
            for i in range(R):
                ws += self._words_covering(self.c_base + (m0 + i) * ldc + 4 * n0, 4 * C)
            return ws

        # NOTE: when nbyte > 4 several lane/k words fall in one controller word; the stream still issues
        # one request per needed (lane, k-group) / k word -> extra requests to the same word measure the
        # *wasted* fetch of wide words honestly (the controller has no sub-word read).
        nm = p.num_masters
        PA, PB, PC, PD = 0, 1, 2, (3 if nm > 3 else 2)
        cur = [None] * nm                      # presented request per master (held until accepted)
        # state
        tile_i = 0
        k = 0                                  # next slice to fire in the current tile
        # continuous operand streams across tiles (look-ahead keeps running over the tile boundary, as a
        # prefetching / ping-pong operand buffer does): global word lists + per-tile offsets
        A_all, B_all, a_off, b_off = [], [], [], []
        for m0, n0 in self.tiles:
            a_off.append(len(A_all)); A_all += a_words(m0)
            b_off.append(len(B_all)); B_all += b_words(n0)
        A = _Stream(A_all, t.a_stage * R)
        B = _Stream(B_all, t.b_stage)
        c_pending: list[int] = []              # words of finished tiles waiting to be written
        c_issued = 0
        c_acks = 0
        c_total = ntiles * R * ((4 * C * R) // nb if nb <= 16 else 1)
        overhead_left = 0
        slices = 0
        starv = 0
        cyc = 0
        done_tiles = 0
        occ_a = occ_b = 0
        dma_active_cycles = dma_overlap_cycles = 0
        a_recv_total = b_recv_total = c_ack_total = dma_total = 0
        # per-master outstanding queues of "what kind" for response routing (in-order per master)
        from collections import deque
        kinds = [deque() for _ in range(nm)]
        dma_ptr = 0
        dma_rng = rng.fork(99)
        first_slice_cycle = None
        total_slices = ntiles * K
        final_cycle = None
        while cyc < t.max_cycles:
            # ---- decide what each master presents this cycle (held if still pending)
            if cur[PA] is None and A.can_issue():
                w = A.addrs[A.next_issue]
                cur[PA] = (Req(0, w * nb, 0, 0, A.next_issue & ((1 << p.id_width) - 1), PA, 0), "A")
            if cur[PB] is None and B.can_issue():
                w = B.addrs[B.next_issue]
                cur[PB] = (Req(0, w * nb, 0, 0, B.next_issue & ((1 << p.id_width) - 1), PB, 0), "B")
            if cur[PC] is None and c_pending:
                w = c_pending[0]
                cur[PC] = (Req(1, w * nb, 1, (1 << nb) - 1, c_issued & ((1 << p.id_width) - 1), PC, 0), "C")
            if cur[PD] is None and PD != PC and t.dma_duty > 0 and dma_rng.random() < t.dma_duty:
                w = (self.dma_base // nb) + dma_ptr % max(1, 2048 // nb)
                cur[PD] = (Req(1 if not (t.dma_reads and dma_ptr % 2) else 0, w * nb, 5, (1 << nb) - 1,
                               dma_total & ((1 << p.id_width) - 1), PD, 0), "D")
            reqs = [c[0] if c else None for c in cur]
            out = ctl.step(reqs, [True] * nm)
            # ---- accept bookkeeping
            for m in range(nm):
                if out.accepted[m]:
                    kind = cur[m][1]
                    kinds[m].append(kind)
                    if kind == "A":
                        A.next_issue += 1
                    elif kind == "B":
                        B.next_issue += 1
                    elif kind == "C":
                        c_pending.pop(0)
                        c_issued += 1
                    elif kind == "D":
                        dma_ptr += 1
                    cur[m] = None
                if out.transferred[m]:
                    kind = kinds[m].popleft()
                    if kind == "A":
                        A.arrived += 1
                    elif kind == "B":
                        B.arrived += 1
                    elif kind == "C":
                        c_acks += 1
                    else:
                        dma_total += 1
            # ---- array: fire a slice if operands are present
            fired = False
            if overhead_left > 0:
                overhead_left -= 1
            elif done_tiles < ntiles:
                g = k // 4
                a_have = A.arrived >= a_off[tile_i] + (g + 1) * R      # all 4 lane words of k-group g
                b_have = B.arrived >= b_off[tile_i] + k + 1            # the B word of this k
                if a_have and b_have:
                    fired = True
                    slices += 1
                    if first_slice_cycle is None:
                        first_slice_cycle = cyc
                    k += 1
                    B.consumed = b_off[tile_i] + k
                    if k % 4 == 0 or k == K:
                        A.consumed = a_off[tile_i] + ((k + 3) // 4) * R
                    if k == K:                       # tile finished: queue the accumulator write-back
                        m0, n0 = self.tiles[tile_i]
                        c_pending += c_words(m0, n0)
                        done_tiles += 1
                        tile_i += 1
                        k = 0
                        overhead_left = t.tile_overhead
                else:
                    starv += 1
            if fired:
                if cur[PD] is not None or t.dma_duty > 0:
                    pass
            # DMA overlap: cycles where the array fired a slice while the DMA master had a request accepted
            if t.dma_duty > 0:
                if out.accepted[PD]:
                    dma_active_cycles += 1
                    if fired:
                        dma_overlap_cycles += 1
            occ_a += max(0, A.arrived - A.consumed)
            occ_b += max(0, B.arrived - B.consumed)
            cyc += 1
            if done_tiles == ntiles and not c_pending and c_acks >= c_issued and all(c is None for c in (cur[PC],)) and idle_all(ctl):
                final_cycle = cyc
                break
        cycles = final_cycle or cyc
        macs = t.M * t.N * K
        peak = 1.0
        # slices counted: each tile K slices; total = ntiles*K
        c_words_total = c_issued
        a_total = len(A_all)
        b_total = len(B_all)
        pf = ctl.perf_dict()
        notes = []
        if cyc >= t.max_cycles:
            notes.append("max_cycles reached before completion (deadlock or too small a budget)")
        return TensorResult(
            cycles=cycles, macs=macs, mac_utilisation=macs / (cycles * R * C * 1.0) if cycles else 0.0,
            slices=slices, peak_slices_per_cycle=peak, starvation_cycles=starv,
            starvation_fraction=starv / cycles if cycles else 0.0,
            a_words=a_total, b_words=b_total, c_words=c_words_total, dma_words=dma_total,
            a_delivery_words_per_cycle=a_total / cycles, b_delivery_words_per_cycle=b_total / cycles,
            acc_traffic_words_per_cycle=c_words_total / cycles,
            buffer_occupancy_a_mean=occ_a / cycles, buffer_occupancy_b_mean=occ_b / cycles,
            dma_overlap_fraction=(dma_overlap_cycles / dma_active_cycles) if dma_active_cycles else float("nan"),
            bank_conflict_events=pf["global"]["CONFLICT"],
            operand_bytes_per_cycle=(a_total + b_total) * nb / cycles,
            required_operand_bytes_per_cycle=float(R + C),    # 4 A bytes + 4 B bytes per k-step at peak
            perf=pf, notes=notes)


def idle_all(ctl: Controller) -> bool:
    return all(c == 0 for c in ctl.cnt)


# --------------------------------------------------------------------------- open-loop TC08 DMA stream
def gen_tensor(p: CtlParams, m: int, n: int, rng: SplitMix64, o: dict) -> list[ReqSpec]:
    """TENSORCORE 08 command stream as requests of master ``m`` (master 0 = the DMA; others idle).

    Options: M,N,K (default 16,16,64), tile_k (64), plus the usual request_rate."""
    if m != 0:
        return []
    M, N, K = int(o.get("tensor_m", 16)), int(o.get("tensor_n", 16)), int(o.get("tensor_k", 64))
    tile_k = int(o.get("tile_k", 64))
    nb = p.nbyte
    a_base = 0
    b_base = ((M * K + 63) // 64) * 64
    c_base = b_base + ((K * N + 63) // 64) * 64
    if c_base + M * N * 4 > p.total_bytes:
        raise ValueError("tensor problem does not fit the SRAM")
    out: list[ReqSpec] = []

    def rd(byte_addr, nbytes, tag):
        for w in range(byte_addr // nb, (byte_addr + nbytes - 1) // nb + 1):
            out.append(ReqSpec(we=0, addr=w * nb, tag=tag))

    def wr(byte_addr, nbytes, tag):
        for w in range(byte_addr // nb, (byte_addr + nbytes - 1) // nb + 1):
            lo, hi = max(byte_addr, w * nb), min(byte_addr + nbytes, (w + 1) * nb)
            strobe = sum(1 << (b - w * nb) for b in range(lo, hi))
            out.append(ReqSpec(we=1, addr=w * nb, wdata=rng.next_u64() & ((1 << p.data_width) - 1), wstrb=strobe, tag=tag))

    for m0 in range(0, M, 4):
        for n0 in range(0, N, 4):
            for k0 in range(0, K, tile_k):
                kk = min(tile_k, K - k0)
                for i in range(4):
                    rd(a_base + (m0 + i) * K + k0, kk, TAG_A)
                for k in range(kk):
                    rd(b_base + (k0 + k) * N + n0, 4, TAG_B)
            for i in range(4):
                wr(c_base + (m0 + i) * 4 * N + 4 * n0, 16, TAG_ACC_WR)
    return out[:n] if n and n < len(out) else out
