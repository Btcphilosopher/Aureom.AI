"""Technology profiles, the vendored SRAM macro catalogue, memory tiling and the (pinned) Nangate45 fetch.

What this module is for
-----------------------
* **Technology profiles** (``configs/tech/*.json``): a profile names a technology library (or none), the
  conditions its numbers are valid for, and where they come from.  Profile ``none`` = no library: every area
  or energy that would need one is ``unavailable``.  A profile with missing ``provenance`` or ``units`` is
  REJECTED, never defaulted.
* **Macro catalogue** (:func:`macro_catalog`): the REAL open-PDK SRAM macro manifests vendored byte-identical
  under ``data/macros/`` (SKY130 OpenRAM, IHP SG13G2, GF180MCU).  Width/height/area are vendor LEF / datasheet
  dimensions; ``timing`` is what the manifest records (clock->DOUT from the vendor datasheet/Liberty), nothing
  is invented.  The ``commercial_*_pending`` placeholders carry no data and are reported as *pending*.
* **Tiling** (:func:`tile_memory`): how many macro instances a bank of ``depth x word`` needs (width tiling across
  the stored word, depth tiling across rows), the macro area, and the bit utilisation.  Pure arithmetic on
  manifest numbers; the result is ``analytical`` (geometry), not a layout.
* **Nangate45 liberty** (:func:`fetch_nangate45`): the one permitted download.  It goes into a new empty
  directory under ``sramlab/.cache/tech/nangate45/``, its sha256/size/date are recorded, and a pinned sha256 in
  ``configs/tech/nangate45.json`` is enforced on every later use.  The ~6.7 MB file is never part of the
  release tree (``.cache`` is excluded).

Nothing here produces a pJ, mW, die area or temperature.
"""
from __future__ import annotations

import datetime as _dt
import glob
import hashlib
import json
import os
import shutil
import subprocess

from .provenance import unavailable

try:  # optional
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                                   # tools/sramlab
CONFIG_TECH_DIR = os.path.join(ROOT, "configs", "tech")
MACRO_DIR = os.path.join(ROOT, "data", "macros")

NANGATE45_URL = ("https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/master/flow/"
                 "platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib")
NANGATE45_FILE = "NangateOpenCellLibrary_typical.lib"
NANGATE45_TECH_LABEL = ("NangateOpenCellLibrary 45 nm typical (open educational library; NOT the SilicaFlux "
                        "target process; area is not transferable to another node)")

PROFILE_SCHEMA = "sramlab/tech/1"
REQUIRED_PROFILE_FIELDS = ("id", "node", "source", "provenance", "conditions", "units", "notes")
PROFILE_PROVENANCE = ("library", "datasheet", "assumption", "measurement", "none")
REQUIRED_CONDITION_FIELDS = ("corner", "voltage_v", "temperature_c")


class TechError(ValueError):
    """A technology profile / library / macro-data problem.  ``.problems`` lists every message."""

    def __init__(self, problems):
        if isinstance(problems, str):
            problems = [problems]
        self.problems = list(problems)
        super().__init__("; ".join(self.problems))


# ---------------------------------------------------------------------------------------------- paths / hashing
def cache_root() -> str:
    """``sramlab/.cache`` (overridable with ``SRAMLAB_CACHE``).  Never shipped: the release zip excludes it."""
    return os.environ.get("SRAMLAB_CACHE") or os.path.join(HERE, ".cache")


def cache_dir(*parts: str, create: bool = False) -> str:
    d = os.path.join(cache_root(), *parts)
    if create:
        os.makedirs(d, exist_ok=True)
        gi = os.path.join(cache_root(), ".gitignore")
        if not os.path.exists(gi):
            try:
                with open(gi, "w") as fh:
                    fh.write("*\n")
            except OSError:
                pass
    return d


def sha256_file(path: str, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


# ---------------------------------------------------------------------------------------------- profiles
def _read_structured(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()
    if path.lower().endswith((".yaml", ".yml")):
        if yaml is None:
            raise TechError(f"{path}: PyYAML is not installed; use a .json profile or `pip install pyyaml`")
        d = yaml.safe_load(text)
    else:
        try:
            d = json.loads(text)
        except json.JSONDecodeError as e:
            raise TechError(f"{path}: not valid JSON ({e})") from e
    if not isinstance(d, dict):
        raise TechError(f"{path}: top level must be a mapping")
    return d


def validate_profile(p: dict) -> list[str]:
    """Return every problem with a technology profile (empty list = valid)."""
    errs: list[str] = []
    if not isinstance(p, dict):
        return ["profile must be a mapping"]
    for k in REQUIRED_PROFILE_FIELDS:
        if k not in p or p[k] in (None, "", {}):
            errs.append(f"missing required field '{k}'")
    prov = p.get("provenance")
    if prov not in (None, "", {}) and prov not in PROFILE_PROVENANCE:
        errs.append(f"provenance={prov!r}: must be one of {PROFILE_PROVENANCE}")
    if p.get("id") == "none":
        return errs          # the 'none' profile has no library, so conditions may be descriptive only
    cond = p.get("conditions")
    if isinstance(cond, dict) and cond:
        for k in REQUIRED_CONDITION_FIELDS:
            if cond.get(k) in (None, ""):
                errs.append(f"conditions.{k} is missing (corner / voltage_v / temperature_c are all required)")
    elif "conditions" in p and not isinstance(cond, dict):
        errs.append("conditions must be a mapping with corner, voltage_v, temperature_c")
    units = p.get("units")
    if isinstance(units, dict) and units:
        for k in ("area", "time"):
            if not units.get(k):
                errs.append(f"units.{k} is missing: every number in a profile carries its unit")
    elif "units" in p and not isinstance(units, dict):
        errs.append("units must be a mapping (e.g. {'area': 'um^2', 'time': 'ns'})")
    lib = p.get("liberty")
    if lib is not None:
        if not isinstance(lib, dict):
            errs.append("liberty must be a mapping or null")
        else:
            if not (lib.get("path") or lib.get("cache_path")):
                errs.append("liberty needs 'path' (absolute/relative file) or 'cache_path' (below sramlab/.cache)")
            if lib.get("path") and not lib.get("sha256"):
                errs.append("liberty.path requires liberty.sha256 (the file is hashed and refused on mismatch)")
    if p.get("process_family") in (None, "") and p.get("id") != "none":
        errs.append("missing required field 'process_family' (e.g. nangate45 / sky130 / ihp_sg13g2 / gf180mcu): "
                    "area is only combined with macros of the SAME process family")
    return errs


NONE_PROFILE = {
    "schema": PROFILE_SCHEMA, "id": "none", "node": "none", "source": "no technology library selected",
    "provenance": "none", "conditions": {"corner": None, "voltage_v": None, "temperature_c": None},
    "units": {"area": "um^2", "time": "ns"}, "process_family": None, "liberty": None,
    "notes": "No technology library: logic area, energy and timing are 'unavailable'; only gate counts and bit counts exist.",
}


def _resolve_profile_path(ref: str) -> str | None:
    if os.path.isfile(ref):
        return ref
    for ext in (".json", ".yaml", ".yml"):
        cand = os.path.join(CONFIG_TECH_DIR, ref + ext)
        if os.path.isfile(cand):
            return cand
    return None


def load_profile(ref: str | dict | None) -> dict:
    """Load + validate a technology profile by id (``configs/tech/<id>.json``), file path, or dict.

    ``None`` / ``"none"`` -> the explicit *no library* profile.  Raises :class:`TechError` listing every problem
    (missing provenance, missing units, ...); a profile is never completed with defaults.
    """
    if ref is None or ref == "none":
        return dict(NONE_PROFILE)
    if isinstance(ref, dict):
        d = dict(ref)
        where = d.get("id", "<dict>")
    else:
        path = _resolve_profile_path(os.fspath(ref))
        if path is None:
            raise TechError(f"technology profile {ref!r} not found (looked for a file and in {CONFIG_TECH_DIR}); "
                            "use 'none' for no library")
        d = _read_structured(path)
        d["_path"] = path
        where = path
    errs = validate_profile(d)
    if errs:
        raise TechError([f"technology profile {where}: {e}" for e in errs])
    return d


def list_profiles() -> list[dict]:
    """Every profile under ``configs/tech/`` with its validation status (a broken file is listed, not hidden)."""
    out = []
    for f in sorted(glob.glob(os.path.join(CONFIG_TECH_DIR, "*.json")) + glob.glob(os.path.join(CONFIG_TECH_DIR, "*.y*ml"))):
        try:
            p = load_profile(f)
            out.append({"id": p["id"], "path": f, "valid": True, "node": p["node"],
                        "has_liberty": bool(p.get("liberty")), "problems": []})
        except TechError as e:
            out.append({"id": os.path.splitext(os.path.basename(f))[0], "path": f, "valid": False, "node": None,
                        "has_liberty": False, "problems": e.problems})
    return out


def profile_liberty(profile: dict, *, verify: bool = True) -> dict:
    """Resolve the Liberty file of a profile to a verified local path.

    Returns ``{"available": bool, "path": str|None, "sha256": str|None, "reason": str|None}``.  A hash mismatch
    against the pinned value is NEVER used: it raises :class:`TechError` (``verify=True``).  A library that is not
    present (e.g. Nangate45 not yet fetched) is reported as unavailable with the exact remedy.
    """
    lib = profile.get("liberty")
    if not lib:
        return {"available": False, "path": None, "sha256": None,
                "reason": "profile has no technology library (profile 'none' or macro-only profile)"}
    pinned = lib.get("pinned_sha256") or lib.get("sha256")
    if lib.get("cache_path"):
        path = os.path.join(cache_root(), lib["cache_path"])
    else:
        path = lib["path"]
        if not os.path.isabs(path):
            path = os.path.join(ROOT, path)
    if not os.path.isfile(path):
        hint = (" - run sramlab.tech.fetch_nangate45() once" if profile.get("id") == "nangate45" else "")
        return {"available": False, "path": path, "sha256": None,
                "reason": f"liberty file not present at {path}{hint}"}
    got = sha256_file(path) if verify else None
    if verify:
        if not pinned:
            raise TechError(f"profile {profile.get('id')}: no pinned sha256 for {path}; refusing to use an unpinned library "
                            "(fetch it again so the pin is recorded)")
        if got != pinned:
            raise TechError(f"profile {profile.get('id')}: liberty sha256 mismatch for {path}: pinned {pinned}, file {got}; "
                            "REFUSING to use it (delete the cache directory and fetch again, or re-pin deliberately)")
    return {"available": True, "path": path, "sha256": got or pinned, "reason": None}


# ---------------------------------------------------------------------------------------------- nangate45 fetch
def _download(url: str, dest_file: str, timeout: int = 300) -> None:
    """Download ``url`` to ``dest_file`` (curl preferred: it honours the session proxy; urllib as fallback)."""
    curl = shutil.which("curl")
    if curl:
        r = subprocess.run([curl, "-fsSL", "--max-time", str(timeout), "-o", dest_file, url],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise TechError(f"download failed (curl rc={r.returncode}): {(r.stderr or r.stdout).strip()[:400]}")
        return
    import urllib.request  # pragma: no cover
    with urllib.request.urlopen(url, timeout=timeout) as resp, open(dest_file, "wb") as out:  # pragma: no cover
        shutil.copyfileobj(resp, out)


def nangate45_profile_path() -> str:
    return os.path.join(CONFIG_TECH_DIR, "nangate45.json")


def fetch_nangate45(dest: str | None = None, *, profile_path: str | None = None, url: str = NANGATE45_URL,
                    pin: bool = True) -> dict:
    """Fetch the Nangate45 typical Liberty into a NEW EMPTY directory (default ``.cache/tech/nangate45``).

    * The directory must not exist or must be empty (or contain a previously fetched, still-matching copy, which
      is returned without a network access).
    * sha256, byte size and UTC download date are recorded in ``<dest>/FETCH.json``.
    * If the profile (``configs/tech/nangate45.json``) has no pinned sha256 yet, the first download's hash is
      written into it (``pin=True``).  If it HAS one and the download differs, the download is deleted and
      :class:`TechError` is raised: a different file is never used silently.
    """
    prof_path = profile_path or nangate45_profile_path()
    prof = _read_structured(prof_path)
    lib = prof.setdefault("liberty", {})
    pinned = lib.get("pinned_sha256")
    dest = dest or cache_dir("tech", "nangate45", create=True)
    os.makedirs(dest, exist_ok=True)
    target = os.path.join(dest, NANGATE45_FILE)
    meta_path = os.path.join(dest, "FETCH.json")
    existing = sorted(os.listdir(dest))
    if existing:
        if os.path.isfile(target) and os.path.isfile(meta_path):
            got = sha256_file(target)
            if pinned and got != pinned:
                raise TechError(f"cached {target} has sha256 {got} but the profile pins {pinned}: REFUSING to use it")
            with open(meta_path) as fh:
                meta = json.load(fh)
            meta.update({"path": target, "reused_existing_download": True, "sha256_verified": got == meta.get("sha256")})
            if got != meta.get("sha256"):
                raise TechError(f"cached {target} does not match its own FETCH.json record ({got} != {meta.get('sha256')})")
            return meta
        raise TechError(f"{dest} is not empty and holds no verified Nangate45 download: pass a NEW EMPTY directory "
                        f"(found {existing[:5]})")
    tmp = os.path.join(dest, NANGATE45_FILE + ".part")
    try:
        _download(url, tmp)
        got = sha256_file(tmp)
        size = os.path.getsize(tmp)
        if size < 1024:
            raise TechError(f"downloaded file is only {size} bytes: not a Liberty library; refusing it")
        with open(tmp, "rb") as fh:
            head = fh.read(4096).decode("latin-1", "replace")
        if "library" not in head:
            raise TechError("downloaded file does not start like a Liberty library (no 'library (' header); refusing it")
        if pinned and got != pinned:
            raise TechError(f"sha256 mismatch: downloaded {got}, profile pins {pinned}: REFUSING to use the file "
                            "(upstream changed or the transfer was altered)")
        os.replace(tmp, target)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    meta = {"url": url, "file": NANGATE45_FILE, "path": target, "sha256": got, "bytes": size,
            "downloaded_utc": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "pinned_sha256_at_download": pinned, "reused_existing_download": False}
    with open(meta_path, "w") as fh:
        json.dump(meta, fh, indent=1)
    if pin and not pinned:
        lib["pinned_sha256"] = got
        lib["pinned_bytes"] = size
        lib["pinned_on_utc"] = meta["downloaded_utc"]
        lib["pinned_url"] = url
        with open(prof_path, "w", encoding="utf-8") as fh:
            json.dump(prof, fh, indent=2)
            fh.write("\n")
        meta["pin_written_to"] = prof_path
    return meta


def nangate45_liberty() -> dict:
    """Verified local path of the Nangate45 liberty (unavailable if not fetched; TechError on hash mismatch)."""
    return profile_liberty(load_profile("nangate45"))


# ---------------------------------------------------------------------------------------------- macro data integrity
MACRO_TIMING_FILE = "timingflow_liberty_timing.json"
PENDING_MACROS = (
    {"id": "commercial_130nm", "process": "commercial 130 nm CMOS (foundry not selected)",
     "status": "PENDING_NO_MACRO", "reason": "requires a foundry/IP-vendor memory-compiler licence (typically NDA); nothing obtained"},
    {"id": "commercial_65nm", "process": "commercial 65 nm CMOS (foundry not selected)",
     "status": "PENDING_NO_MACRO", "reason": "requires a foundry/IP-vendor memory-compiler licence (typically NDA); nothing obtained"},
    {"id": "commercial_28nm", "process": "commercial 28 nm CMOS (foundry not selected)",
     "status": "PENDING_NO_MACRO", "reason": "requires a foundry/IP-vendor memory-compiler licence (typically NDA); nothing obtained"},
)


def read_sha256sums(path: str) -> dict[str, str]:
    out = {}
    with open(path, "r", encoding="utf-8") as fh:
        for ln in fh:
            ln = ln.strip()
            if not ln or ln.startswith("#"):
                continue
            h, _, name = ln.partition("  ")
            out[name.strip().lstrip("*")] = h.strip()
    return out


def verify_macro_data(macro_dir: str | None = None) -> dict:
    """Check every file in ``data/macros`` against its ``SHA256SUMS`` line.  Returns ``{ok, checked, problems}``."""
    d = macro_dir or MACRO_DIR
    sums = os.path.join(d, "SHA256SUMS")
    problems: list[str] = []
    if not os.path.isfile(sums):
        return {"ok": False, "checked": 0, "problems": [f"{sums} missing"]}
    want = read_sha256sums(sums)
    checked = 0
    for name, h in sorted(want.items()):
        p = os.path.join(d, name)
        if not os.path.isfile(p):
            problems.append(f"{name}: listed in SHA256SUMS but missing")
            continue
        checked += 1
        if sha256_file(p) != h:
            problems.append(f"{name}: sha256 mismatch (file changed since it was vendored)")
    for f in sorted(os.listdir(d)):
        if f.endswith(".json") and f not in want:
            problems.append(f"{f}: present but not listed in SHA256SUMS")
    return {"ok": not problems, "checked": checked, "problems": problems}


# ---------------------------------------------------------------------------------------------- macro catalogue
def _timing_rows(t: dict) -> list[dict]:
    """Normalise a manifest ``timing`` block into explicit rows; nothing is added that the manifest does not say."""
    rows = []
    src = t.get("source")
    for k, v in t.items():
        if k in ("source", "notes", "corner"):
            continue
        if k.endswith("_ns"):
            if isinstance(v, dict):
                for corner, x in v.items():
                    rows.append({"name": k[:-3], "value": x, "unit": "ns", "corner": corner})
            else:
                rows.append({"name": k[:-3], "value": v, "unit": "ns", "corner": t.get("corner")})
    return rows


def _catalog_entry(path: str, d: dict) -> dict:
    ph = d.get("physical") or {}
    w, h, a = ph.get("width_um"), ph.get("height_um"), ph.get("area_um2")
    dw, words = d.get("data_width"), d.get("words")
    wm = d.get("write_mask") or {}
    lib_views = (d.get("views") or {}).get("liberty") or []
    prov = d.get("provenance") or {}
    cap = dw * words if isinstance(dw, int) and isinstance(words, int) else None
    return {
        "macro_name": d["macro_name"], "family": d.get("family"), "foundry": d.get("foundry"), "process": d.get("process"),
        "status": d.get("status"), "port_topology": d.get("port_topology"),
        "data_width": dw, "words": words, "capacity_bits": cap,
        "width_um": w, "height_um": h, "area_um2": a, "area_source": ph.get("source"),
        "um2_per_bit": (a / cap) if (a and cap) else None,
        "read_latency_cycles": d.get("read_latency_cycles"),
        "write_mask_granularity_bits": wm.get("granularity_bits"), "write_mask_pin": wm.get("pin"),
        "timing": {"source": (d.get("timing") or {}).get("source"), "rows": _timing_rows(d.get("timing") or {}),
                   "notes": (d.get("timing") or {}).get("notes"), "corner": (d.get("timing") or {}).get("corner")},
        "liberty_views": lib_views, "views_lef": (d.get("views") or {}).get("lef"),
        "supply_pins": d.get("supply_pins"), "constraints": d.get("constraints") or [],
        "silicon_status": d.get("silicon_status"), "license": d.get("license"),
        "source_repo": prov.get("repo"), "source_commit": prov.get("commit"), "source_file_hashes": prov.get("files"),
        "manifest_file": os.path.basename(path), "manifest_sha256": sha256_file(path),
        "halo_keepout": unavailable("manifests carry no halo / keep-out rule; supply one explicitly"),
    }


_CATALOG_CACHE: dict[str, list[dict]] = {}


def macro_catalog(macro_dir: str | None = None, *, verify: bool = True, include_two_port: bool = True) -> list[dict]:
    """The vendored REAL macro manifests as a list of entries (sorted by process family then capacity).

    ``verify=True`` first checks ``SHA256SUMS`` and raises :class:`TechError` if any vendored file changed.
    Commercial ``*_pending`` placeholders are not vendored (they hold no data): see :data:`PENDING_MACROS`.
    """
    d = macro_dir or MACRO_DIR
    if verify:
        v = verify_macro_data(d)
        if not v["ok"]:
            raise TechError([f"vendored macro data failed verification: {p}" for p in v["problems"]])
    key = d
    if key in _CATALOG_CACHE and verify:
        cat = _CATALOG_CACHE[key]
    else:
        cat = []
        for f in sorted(glob.glob(os.path.join(d, "*.json"))):
            if os.path.basename(f) == MACRO_TIMING_FILE:
                continue
            with open(f, "r", encoding="utf-8") as fh:
                m = json.load(fh)
            if m.get("schema", "").endswith("macro-manifest/1") and m.get("status") == "OPEN_SOURCE_AVAILABLE":
                cat.append(_catalog_entry(f, m))
        cat.sort(key=lambda e: (e["family"] or "", e["data_width"] or 0, e["words"] or 0, e["macro_name"]))
        if verify:
            _CATALOG_CACHE[key] = cat
    if not include_two_port:
        return [dict(e) for e in cat if e["port_topology"] != "2RW"]
    return [dict(e) for e in cat]


def get_macro(name: str, macro_dir: str | None = None) -> dict:
    for e in macro_catalog(macro_dir):
        if e["macro_name"] == name:
            return e
    avail = [e["macro_name"] for e in macro_catalog(macro_dir)]
    pend = [p["id"] for p in PENDING_MACROS]
    raise TechError(f"unknown macro {name!r}: not among the {len(avail)} vendored open-PDK macros (commercial macros are "
                    f"pending, no data: {pend}); e.g. {avail[:3]}")


def macro_timing_liberty(macro_name: str, macro_dir: str | None = None) -> list[dict]:
    """Tool-derived (vendor Liberty -> STA-style table) clock->DOUT / setup / hold rows for a macro, if the TimingFlow
    package reported them.  These are Liberty characterisation targets, NOT silicon measurements."""
    p = os.path.join(macro_dir or MACRO_DIR, MACRO_TIMING_FILE)
    if not os.path.isfile(p):
        return []
    with open(p, "r", encoding="utf-8") as fh:
        d = json.load(fh)
    return [r for r in d.get("rows", []) if r["macro"] == macro_name]


# ---------------------------------------------------------------------------------------------- tiling
def _ceil_div(a: int, b: int) -> int:
    return -(-a // b)


def tile_memory(capacity_bits_per_bank: int, word_bits_stored: int, macro: dict | str, *, gap_um: float = 0.0) -> dict:
    """Tile ONE bank of ``capacity_bits_per_bank`` bits with ``word_bits_stored``-bit rows from ``macro``.

    * columns ``nc = ceil(word_bits_stored / macro.data_width)``  (width tiling across the stored word)
    * rows    ``nr = ceil(depth / macro.words)``                  (depth tiling; ``depth = capacity / word``)
    * ``instances = nc * nr``; ``provisioned_bits = nc*dw * nr*words``; ``bit_utilisation = required / provisioned``
    * ``total_macro_area_um2 = instances * macro.area_um2`` (vendor LEF area; NOT a layout)
    * ``grid_width_um / grid_height_um`` = abutted grid (+ ``gap_um`` between macros if given, a caller assumption)

    ``capacity_bits_per_bank`` must be a multiple of ``word_bits_stored`` (a bank is whole rows).  ``macro`` is a
    catalogue entry or a macro name.  The result is arithmetic on vendor dimensions: label ``analytical``.
    """
    m = get_macro(macro) if isinstance(macro, str) else macro
    for k in ("data_width", "words", "area_um2", "width_um", "height_um"):
        if m.get(k) in (None, 0):
            raise TechError(f"macro {m.get('macro_name')!r} has no {k}: cannot tile (placeholder / pending macro)")
    if not (isinstance(capacity_bits_per_bank, int) and capacity_bits_per_bank > 0):
        raise TechError("capacity_bits_per_bank must be a positive integer")
    if not (isinstance(word_bits_stored, int) and word_bits_stored > 0):
        raise TechError("word_bits_stored must be a positive integer")
    if capacity_bits_per_bank % word_bits_stored:
        raise TechError(f"capacity_bits_per_bank={capacity_bits_per_bank} is not a multiple of word_bits_stored="
                        f"{word_bits_stored}: a bank holds whole rows")
    depth = capacity_bits_per_bank // word_bits_stored
    dw, words = m["data_width"], m["words"]
    nc, nr = _ceil_div(word_bits_stored, dw), _ceil_div(depth, words)
    inst = nc * nr
    prov_bits = nc * dw * nr * words
    gap = float(gap_um or 0.0)
    out = {
        "label": "analytical", "kind": "geometry arithmetic on vendor macro dimensions (not a layout)",
        "macro_name": m["macro_name"], "macro_data_width": dw, "macro_words": words,
        "depth_words": depth, "word_bits_stored": word_bits_stored, "required_bits": capacity_bits_per_bank,
        "cols": nc, "rows": nr, "instances": inst,
        "provisioned_bits": prov_bits, "wasted_bits": prov_bits - capacity_bits_per_bank,
        "unused_bits_per_row": nc * dw - word_bits_stored, "unused_rows": nr * words - depth,
        "bit_utilisation": capacity_bits_per_bank / prov_bits,
        "macro_area_um2_each": m["area_um2"], "total_macro_area_um2": inst * m["area_um2"],
        "grid_width_um": nc * m["width_um"] + (nc - 1) * gap, "grid_height_um": nr * m["height_um"] + (nr - 1) * gap,
        "gap_um": gap, "gap_basis": ("abutted (gap 0): no spacing rule exists in the manifests" if gap == 0.0
                                      else "caller-supplied assumption"),
        "write_granularity_bits": m.get("write_mask_granularity_bits"),
        "port_topology": m.get("port_topology"),
        "source": f"{m.get('manifest_file')} @ {str(m.get('source_commit'))[:12]}",
    }
    if m.get("port_topology") == "1RW1R":
        out["note"] = ("1RW1R macro used as 1RW: the read-only port is paid for in every instance but unused; "
                       "its share of the macro area is not quantifiable from manifest data")
    if m.get("port_topology") == "2RW":
        out["note"] = "true dual-port macro: only one port is used by the single-port SRAMCore bank contract"
    return out


def rank_macros(capacity_bits_per_bank: int, word_bits_stored: int, *, family: str | None = None,
                topologies: tuple[str, ...] = ("1RW", "1RW1R"), macro_dir: str | None = None) -> list[dict]:
    """Every catalogue macro that can tile the bank, ranked by total macro area (tie: fewer instances, then name).

    Dual-port ``2RW`` macros are excluded by default (a single-port bank uses one port)."""
    res = []
    for m in macro_catalog(macro_dir):
        if family and m["family"] != family:
            continue
        if topologies and m["port_topology"] not in topologies:
            continue
        res.append(tile_memory(capacity_bits_per_bank, word_bits_stored, m))
    res.sort(key=lambda t: (t["total_macro_area_um2"], t["instances"], t["macro_name"]))
    return res


def macro_family_of(m: dict) -> str | None:
    """Process-family key used to decide whether a logic library may be combined with this macro."""
    p = (m.get("process") or "").lower()
    if "sky130" in p:
        return "sky130"
    if "sg13g2" in p:
        return "ihp_sg13g2"
    if "gf180" in p:
        return "gf180mcu"
    return None


# ---------------------------------------------------------------------------------------------- ECC arithmetic
def secded_stored_bits(k: int) -> int:
    """Stored bits of an extended-Hamming SECDED code over ``k`` data bits: smallest r with 2^r >= k + r + 1, plus
    one overall parity bit.  39/32, 72/64, 137/128 (matches the verified codecs); pure arithmetic."""
    if k < 1:
        raise TechError("k must be >= 1")
    r = 1
    while (1 << r) < k + r + 1:
        r += 1
    return k + r + 1
