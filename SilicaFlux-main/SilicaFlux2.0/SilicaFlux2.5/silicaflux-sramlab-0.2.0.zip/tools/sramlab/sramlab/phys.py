"""Physical-area analysis: memory footprint, logic area, ECC / arbitration / NoC overhead, generated geometry.

Provenance rules enforced here (``sramlab.provenance``):

* memory footprint of an ``asic_macro`` backend = REAL vendor macro dimensions (vendored manifests) x tiling
  arithmetic -> ``analytical`` (geometry arithmetic on vendor numbers; not a layout).  ``fpga_bram`` reports bit
  counts only (no mm^2); ``generic`` reports bit counts only.
* logic area = Yosys-mapped cell area ONLY when a real Liberty was used (``synthesized`` for THAT library only);
  otherwise gate counts and ``unavailable("no technology library")``.
* die area is **unavailable** unless every required input exists: macro dimensions, a logic area from a library of
  the SAME process family as the macros, and caller-supplied placement margins.  It is never estimated from nothing.
* the floorplan is *generated geometry, not a routed layout*; the routing figure is an analytical Manhattan
  wirelength proxy from that geometry, not a routed length.
"""
from __future__ import annotations

import json
import math
import os

from . import synth as synth_mod
from . import tech, tools
from .config import normalise
from .provenance import tag, unavailable

DATA_DIR = os.path.join(tools.ROOT, "data")
SYNTH_DIR = os.path.join(DATA_DIR, "synth")
ECC_STUDY_PATH = os.path.join(DATA_DIR, "ecc_study.json")
SWEEP_GENERIC_PATH = os.path.join(SYNTH_DIR, "controller_sweep_generic.json")
NOC_RESULT_PATH = os.path.join(SYNTH_DIR, "noc_interface.json")
P74 = os.path.join(tools.ROOT, "rtl", "third_party", "p74_sramfabric")

GEOMETRY_DISCLAIMER = "GENERATED GEOMETRY FROM VENDOR MACRO DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT"
DEFAULT_CANDIDATE_FAMILY = "IHP_1P"


# ---------------------------------------------------------------------------------------------- inputs
def _dims(cfg: dict) -> dict:
    mem = cfg["memory"]
    banks, depth, word = mem["banks"], mem["bank_depth_words"], mem["word_width_bits"]
    ecc = mem.get("ecc", "none")
    stored = tech.secded_stored_bits(word) if ecc == "secded" else word
    return {"banks": banks, "depth": depth, "word": word, "ecc": ecc, "stored_word": stored}


def memory_bits(cfg: dict) -> dict:
    """Bit counts of the memory (always available; analytical)."""
    d = _dims(cfg)
    user = d["banks"] * d["depth"] * d["word"]
    stored = d["banks"] * d["depth"] * d["stored_word"]
    src = "banks * bank_depth_words * word bits (config arithmetic)"
    return {
        "user_bits": tag(user, "analytical", src, unit="bits"),
        "stored_bits": tag(stored, "analytical", src + (f"; SECDED stores {d['stored_word']} bits per {d['word']}-bit word"
                                                       if d["ecc"] == "secded" else ""), unit="bits"),
        "stored_bits_per_bank": tag(d["depth"] * d["stored_word"], "analytical", src, unit="bits"),
        "word_bits": d["word"], "stored_word_bits": d["stored_word"], "banks": d["banks"], "bank_depth_words": d["depth"],
        "ecc": d["ecc"],
    }


def _macro_for(cfg: dict):
    """(macro entry | None, reason | None)."""
    phy = cfg["physical"]
    name = phy.get("macro")
    if phy["backend"] != "asic_macro":
        return None, f"backend={phy['backend']}: no ASIC macro selected"
    if not name:
        return None, "backend=asic_macro but physical.macro is empty"
    try:
        return tech.get_macro(name), None
    except tech.TechError as e:
        return None, str(e)


def _tile_whole(cfg: dict, macro: dict, gap_um: float = 0.0, stored_word: int | None = None) -> dict:
    d = _dims(cfg)
    sw = stored_word or d["stored_word"]
    per_bank = tech.tile_memory(d["depth"] * sw, sw, macro, gap_um=gap_um)
    total_inst = per_bank["instances"] * d["banks"]
    return {"per_bank": per_bank, "banks": d["banks"], "instances_total": total_inst,
            "total_macro_area_um2": per_bank["total_macro_area_um2"] * d["banks"],
            "provisioned_bits_total": per_bank["provisioned_bits"] * d["banks"],
            "required_bits_total": per_bank["required_bits"] * d["banks"],
            "wasted_bits_total": per_bank["wasted_bits"] * d["banks"],
            "bit_utilisation": per_bank["bit_utilisation"]}


# ---------------------------------------------------------------------------------------------- ecc / arbitration / noc
def _walk(o):
    if isinstance(o, dict):
        yield o
        for v in o.values():
            yield from _walk(v)
    elif isinstance(o, list):
        for v in o:
            yield from _walk(v)


_CELL_KEYS = ("total_cells", "cells", "num_cells", "gate_count", "gates")
_WIDTH_KEYS = ("data_bits", "data_width", "word_bits", "width", "k")


def _ecc_logic(word: int, path: str | None = None) -> dict:
    """ECC codec logic from the ECC study, if ``data/ecc_study.json`` exists and holds rows I can validate."""
    path = path or ECC_STUDY_PATH
    todo = unavailable("run `sramlab ecc` first (data/ecc_study.json not found)", TODO=True)
    if not os.path.isfile(path):
        return todo
    try:
        with open(path, "r", encoding="utf-8") as fh:
            d = json.load(fh)
    except Exception as e:
        return unavailable(f"{path} is not readable JSON ({e})", TODO=True)
    rows = []
    for r in _walk(d):
        ck = next((k for k in _CELL_KEYS if isinstance(r.get(k), (int, float)) and not isinstance(r.get(k), bool)), None)
        wk = next((k for k in _WIDTH_KEYS if isinstance(r.get(k), int) and not isinstance(r.get(k), bool)), None)
        if ck and wk and r[wk] == word:
            rows.append({k: v for k, v in r.items() if isinstance(v, (int, float, str, bool)) or v is None})
    if not rows:
        return unavailable(f"{os.path.basename(path)} exists (top-level keys: {sorted(d)[:8] if isinstance(d, dict) else 'list'}) "
                           f"but holds no synthesized-gate rows for {word}-bit words that I can validate", TODO=True)
    return {"provenance": "synthesized", "source": f"{os.path.basename(path)} (sha256 {tech.sha256_file(path)[:16]}...)",
            "word_bits": word, "rows": rows,
            "note": "rows copied as written by the ECC study; labels and units are the study's own"}


def load_sweep(path: str | None = None) -> dict | None:
    p = path or SWEEP_GENERIC_PATH
    if not os.path.isfile(p):
        return None
    with open(p, "r", encoding="utf-8") as fh:
        d = json.load(fh)
    d["_path"], d["_sha256"] = p, tech.sha256_file(p)
    return d


def _arbitration(cfg: dict, synth: dict | None, sweep: dict | None) -> dict:
    nb, nm = cfg["memory"]["banks"], cfg["controller"]["masters"]
    out: dict = {"scope": "whole controller (arbiters are not separable from FIFOs/trackers/counters in the flat netlist)"}
    g = (synth or {}).get("generic") if synth else None
    if isinstance(g, dict) and "total_cells" in g:
        out["controller_cells"] = tag(g["total_cells"], "synthesized", "supplied synth result", unit="cells")
        out["cells_per_bank"] = tag(g["total_cells"] / nb, "synthesized", "controller cells / banks (not an incremental cost)",
                                    unit="cells/bank")
        out["flip_flops"] = tag(g["flip_flops"], "synthesized", "supplied synth result", unit="flip-flops")
    else:
        out["controller_cells"] = unavailable("no synth result supplied (run sramlab.synth.synth_controller)")
    sw = sweep if sweep is not None else load_sweep()
    if sw:
        rows = [r for r in sw.get("rows", []) if r.get("masters") == nm and r.get("status", "").startswith("ok")]
        out["controller_cells_vs_banks"] = {
            "label": "synthesized", "source": f"{os.path.basename(sw['_path'])} (sha256 {sw['_sha256'][:16]}...)",
            "masters": nm, "rows": [{"banks": r["banks"], "perf_counters": r["perf"], "max_out": r["max_out"],
                                     "cells": r["cells"], "flip_flops": r["flip_flops"],
                                     "mapped_area_um2": r.get("mapped_area_um2")} for r in rows]}
        if not rows:
            out["controller_cells_vs_banks"] = unavailable(f"the controller sweep has no rows for masters={nm}")
    else:
        out["controller_cells_vs_banks"] = unavailable("no controller sweep file (run sramlab.synth.synth_sweep)")
    return out


def verify_vendored_rtl(root: str | None = None) -> dict:
    """Check the vendored P74 RTL against its ``SHA256SUMS`` (also flags unlisted .sv/.svh files)."""
    root = root or P74
    sums = os.path.join(root, "SHA256SUMS")
    if not os.path.isfile(sums):
        return {"ok": False, "checked": 0, "problems": [f"{sums} missing"]}
    want = tech.read_sha256sums(sums)
    problems, checked = [], 0
    for name, h in sorted(want.items()):
        f = os.path.join(root, name)
        if not os.path.isfile(f):
            problems.append(f"{name}: listed but missing")
            continue
        checked += 1
        if tech.sha256_file(f) != h:
            problems.append(f"{name}: sha256 mismatch (vendored file changed)")
    for dp, _, fs in os.walk(root):
        for fn in fs:
            if fn.endswith((".sv", ".svh")):
                rel = os.path.relpath(os.path.join(dp, fn), root).replace(os.sep, "/")
                if rel not in want:
                    problems.append(f"{rel}: present but not listed in SHA256SUMS")
    return {"ok": not problems, "checked": checked, "problems": problems}


def noc_interface_synth(outdir, liberty: str | None = None, *, fabric_top: bool = True, use_cache: bool = True,
                        top_timeout: int = 1500, result_name: str = "noc_interface") -> dict:
    """Synthesize the NoC-facing interface of the SRAM subsystem from the vendored P74 RTL with Yosys.

    * ``sf_sram_datafabric``: the SFB3 target -> SRAM-controller bridge (NTP=1, NP=1, DW=128, 4 banks, depth 1024)
    * ``sf_sram_fabric_top`` (optional): the shared-SRAM top (NoC crossbar + bridge + MemoryCore controller + banks +
      scratchpads) with a small DEPTH (16; SHARED_BYTES=512 and TEN_BASE_LINE=32 scaled so the tensor tile buffers fit the
      64-line aperture: the RTL's own elaboration check rejects the defaults at DEPTH=16); the arrays become flip-flops
      through ``memory_map`` (NOT macros).  Yosys (wasm) needs on the order of ten minutes for the default DEPTH=256.
    Each part reports ``status`` ok/failed with the Yosys error when something does not synthesize.  Gate counts only
    (generic) unless a Liberty is given.  No timing, no performance claim.
    """
    v = verify_vendored_rtl()
    if not v["ok"]:
        raise tech.TechError([f"vendored P74 RTL failed verification: {p}" for p in v["problems"]])
    bridge_files = [os.path.join(P74, "rtl", f) for f in (
        "sf_sdf_skid.sv", "sf_sdf_txq.sv", "sf_sdf_addr_xlate.sv", "sf_sdf_port.sv", "sf_sdf_burst_seq.sv",
        "sf_sram_datafabric.sv")]
    inc = [os.path.join(P74, "rtl"), os.path.join(P74, "third_party", "memorycore", "rtl")]
    res = {"label": "synthesized", "source": "vendored P74 RTL (rtl/third_party/p74_sramfabric)", "parts": {}}
    res["parts"]["sf_sram_datafabric"] = synth_mod.synth_design(
        "sf_sram_datafabric", bridge_files, inc, {"NM": 4, "DW": 128, "NTP": 1, "NP": 1, "NB": 4, "DEPTH": 1024},
        outdir, liberty, scope="SFB3 bridge only (NoC-facing interface); controller and banks not included",
        name="noc_sf_sram_datafabric", use_cache=use_cache)
    if fabric_top:
        tp = os.path.join(P74, "third_party")
        mc, noc, ras, mb = (os.path.join(tp, "memorycore", "rtl"), os.path.join(tp, "noc_sfb3", "rtl"),
                            os.path.join(tp, "ras_secded"), os.path.join(tp, "sramlib_mbist"))
        files = [os.path.join(mc, f) for f in ("sf_ecc_counters.sv", "sf_ecc_dec.sv", "sf_ecc_enc.sv")]
        files += [os.path.join(ras, f) for f in ("sfras_secded_dec.sv", "sfras_secded_enc.sv")]
        files += [os.path.join(mc, f) for f in ("sf_sync_fifo.sv", "sf_sram_core.sv")]
        files += [os.path.join(mc, "backends", f) for f in ("sf_sram_fpga_bram.sv", "sf_sram_asic_sky130.sv")]
        files += [os.path.join(mc, f) for f in ("sf_sram_macro_wrapper.sv", "sf_sram_mbist_ctl.sv")]
        files += [os.path.join(mb, "sram_mbist_march.sv")]
        files += [os.path.join(mc, f) for f in ("sf_sram_bank.sv", "sf_sram_controller.sv", "sf_vector_scratchpad.sv",
                                                 "sf_tensor_scratchpad.sv", "sf_ts_port.sv")]
        files += bridge_files
        files += [os.path.join(noc, f) for f in (
            "sfn_pkg.sv", "sfn_fifo.sv", "sfn_onehot_mux.sv", "sfn_arbiter.sv", "sfb_arbiter.sv", "sfb_addr_decoder.sv",
            "sfn_qos_arbiter.sv", "sfn_xbar.sv", "sfn_sbus.sv", "sfn_perf.sv", "sfn_router.sv", "sfn_mesh.sv", "sfn_ni.sv",
            "sfn_mst_port.sv", "sfn_sfb2_mst_bridge.sv", "sfn_sfb2_tgt_bridge.sv", "silicaflux_noc.sv")]
        files += [os.path.join(P74, "rtl", "sf_sram_fabric_top.sv")]
        inc2 = inc + [ras, mb]
        res["parts"]["sf_sram_fabric_top"] = synth_mod.synth_design(
            "sf_sram_fabric_top", files, inc2, {"DEPTH": 16, "SHARED_BYTES": 512, "TEN_BASE_LINE": 32}, outdir, liberty,
            scope=("shared SRAM subsystem on the DataFabric with a small DEPTH: NoC crossbar + SFB3 bridge + MemoryCore "
                   "controller + banks + scratchpads; arrays become flip-flops via memory_map (NOT macros)"),
            name="noc_sf_sram_fabric_top", use_cache=use_cache, timeout=top_timeout)
    os.makedirs(os.fspath(outdir), exist_ok=True)
    with open(os.path.join(os.fspath(outdir), result_name + ".json"), "w") as fh:
        json.dump({**res, "parts": {k: synth_mod.portable(v) for k, v in res["parts"].items()}}, fh, indent=1, default=str)
    return res


def _noc(noc: dict | None) -> dict:
    n = noc
    src = "supplied"
    if n is None and os.path.isfile(NOC_RESULT_PATH):
        with open(NOC_RESULT_PATH, "r", encoding="utf-8") as fh:
            n = json.load(fh)
        src = f"{os.path.basename(NOC_RESULT_PATH)} (sha256 {tech.sha256_file(NOC_RESULT_PATH)[:16]}...)"
    if n is None:
        return unavailable("run sramlab.phys.noc_interface_synth(outdir) (no NoC synthesis result found)")
    out = {"source": src, "parts": {}}
    for name, r in (n.get("parts") or {}).items():
        g = r.get("generic") or {}
        if r.get("status", "").startswith("ok") and "total_cells" in g:
            out["parts"][name] = {"label": "synthesized", "status": r["status"], "total_cells": g["total_cells"],
                                  "flip_flops": g["flip_flops"], "latches": g["latches"], "params": r.get("params"),
                                  "scope": r.get("scope"), "area_um2": r.get("mapped_area_um2") or unavailable("no technology library")}
        else:
            out["parts"][name] = {"label": "unavailable", "status": r.get("status"), "reason": r.get("error"),
                                  "scope": r.get("scope")}
    return out


# ---------------------------------------------------------------------------------------------- spacing / compat
def _spacing(spacing: dict | None) -> dict:
    out = {}
    for k in ("gap_um", "channel_um", "margin_um", "halo_um"):
        v = (spacing or {}).get(k)
        if v is None:
            out[k] = unavailable(f"{k} not supplied (no PDK rule in the manifests)")
        else:
            if not isinstance(v, (int, float)) or v < 0:
                raise ValueError(f"spacing.{k} must be a non-negative number (got {v!r})")
            out[k] = tag(float(v), "assumed", "caller-supplied placement parameter", unit="um")
    return out


def _sv(x, default=0.0):
    return default if (isinstance(x, dict) and x.get("value") is None) else (x["value"] if isinstance(x, dict) else x)


def _logic_area(synth: dict | None, profile: dict) -> tuple[dict, list[str]]:
    warns: list[str] = []
    if synth is None:
        return unavailable("no synthesis result supplied (sramlab.synth.synth_controller)"), warns
    a = synth.get("mapped_area_um2")
    if isinstance(a, dict) and a.get("value") is not None:
        mp = synth.get("mapped") or {}
        if profile.get("liberty"):
            try:
                pl = tech.profile_liberty(profile)
                if pl["available"] and mp.get("liberty_sha256") and pl["sha256"] != mp["liberty_sha256"]:
                    warns.append("the supplied synth result used a different liberty than the technology profile pins")
            except tech.TechError as e:
                warns.append(f"technology profile liberty problem: {e}")
        elif profile.get("id") == "none":
            warns.append("synth result is liberty-mapped but the technology profile is 'none': area reported with the "
                         "technology string of the synth run")
        return dict(a), warns
    reason = (a or {}).get("reason") if isinstance(a, dict) else None
    if profile.get("liberty") and reason == "no technology library":
        reason = (f"technology profile {profile['id']!r} names a liberty but the supplied synth result is generic: re-run "
                  "synth_controller(..., liberty=<verified path>)")
    return unavailable(reason or "synth result carries no mapped area"), warns


def _synth_mismatch(cfg: dict, synth: dict | None) -> list[str]:
    """Warnings when the supplied synth result was produced for different parameters than the configuration."""
    if not synth or not isinstance(synth.get("params"), dict):
        return []
    p, mem, ctl = synth["params"], cfg["memory"], cfg["controller"]
    pairs = (("NUM_BANKS", mem["banks"], "memory.banks"), ("NUM_MASTERS", ctl["masters"], "controller.masters"),
             ("DATA_WIDTH", mem["word_width_bits"], "memory.word_width_bits"),
             ("MAX_OUT", ctl["max_outstanding"], "controller.max_outstanding"))
    return [f"synth result has {k}={p[k]} but the configuration has {name}={v}: the logic figures belong to a different design"
            for k, v, name in pairs if k in p and p[k] != v]


def _compat(profile: dict, macro: dict | None) -> tuple[bool | None, str]:
    if macro is None:
        return None, "no macro"
    mf = tech.macro_family_of(macro)
    pf = profile.get("process_family")
    if not pf:
        return None, "technology profile has no process_family (profile 'none' or incomplete)"
    if pf == mf:
        return True, f"logic library process family {pf!r} == macro process family {mf!r}"
    return False, (f"logic library process family {pf!r} differs from the macro's {mf!r} "
                   f"({macro.get('process')}): logic area is not transferable, so it is NOT added to the macro area")


# ---------------------------------------------------------------------------------------------- floorplan
def _bank_grid(banks: int, bw: float, bh: float, channel: float) -> tuple[int, int]:
    best = None
    for cols in range(1, banks + 1):
        if banks % cols:
            continue
        rows = banks // cols
        w, h = cols * bw + (cols - 1) * channel, rows * bh + (rows - 1) * channel
        asp = max(w, h) / min(w, h)
        if best is None or asp < best[0] - 1e-12:
            best = (asp, cols, rows)
    return best[1], best[2]


def floorplan(cfg: dict, *, synth: dict | None = None, tech_profile=None, spacing: dict | None = None,
              outdir=None) -> dict:
    """Generated geometry (macro rectangles, controller reserve) for an ``asic_macro`` configuration.

    Labelled "generated geometry, not a routed layout".  ``spacing`` (caller-supplied, ``assumed``): ``gap_um``
    between macros inside a bank, ``channel_um`` between banks, ``margin_um`` die margin, ``halo_um`` (recorded).
    Omitted spacing means macros are abutted - a bounding-box convenience, not a legal placement.
    Die area is ``unavailable`` unless macro dimensions, a same-process logic area and ``margin_um`` all exist.
    """
    cfg = normalise(cfg)
    profile = tech.load_profile(tech_profile if tech_profile is not None else cfg["physical"].get("technology"))
    macro, why = _macro_for(cfg)
    base = {"schema": "sramlab/floorplan/1", "label": "generated-geometry", "disclaimer": GEOMETRY_DISCLAIMER, "units": "um",
            "coordinate_system": "origin = lower-left of the placed objects; x right, y up",
            "backend": cfg["physical"]["backend"]}
    if macro is None:
        base.update({"status": "unavailable", "reason": why, "macros": [], "bank_regions": [],
                     "die": unavailable(f"no macro geometry: {why}")})
        _write(outdir, base)
        return base
    sp = _spacing(spacing)
    gap, channel = _sv(sp["gap_um"]), _sv(sp["channel_um"])
    tl = _tile_whole(cfg, macro, gap_um=gap)
    pb = tl["per_bank"]
    d = _dims(cfg)
    banks = d["banks"]
    bw, bh = pb["grid_width_um"], pb["grid_height_um"]
    cols, rows = _bank_grid(banks, bw, bh, channel)
    logic, lwarns = _logic_area(synth, profile)
    compat, compat_msg = _compat(profile, macro)
    array_w = cols * bw + (cols - 1) * channel
    array_h = rows * bh + (rows - 1) * channel
    # controller reserve: a strip on the left whose height = array height and whose area = mapped logic area (only if
    # the logic area exists AND is from the macros' own process family)
    ctrl_w = 0.0
    controller: dict
    usable_logic = logic.get("value") is not None and compat is True
    if usable_logic:
        ctrl_w = logic["value"] / array_h
        controller = {"rect": {"x0": 0.0, "y0": 0.0, "x1": ctrl_w, "y1": array_h}, "area_um2": logic["value"],
                      "label": "generated-geometry", "basis": "strip of height = array height with area = mapped logic area"}
    else:
        why_c = (logic.get("reason") if logic.get("value") is None else compat_msg)
        controller = {"rect": None, "area_um2": unavailable(why_c),
                      "label": "generated-geometry",
                      "basis": "no reserve rectangle (logic area unavailable or from another process); the anchor is the "
                               "west edge of the macro array"}
    x_off = ctrl_w + (channel if usable_logic else 0.0)
    anchor = {"x": ctrl_w, "y": array_h / 2.0}       # east edge of the strip, or the west edge of the array when no strip
    regions, macros = [], []
    for b in range(banks):
        bc, br = b % cols, b // cols
        bx, by = x_off + bc * (bw + channel), br * (bh + channel)
        regions.append({"bank": b, "x0": bx, "y0": by, "x1": bx + bw, "y1": by + bh, "cols": pb["cols"], "rows": pb["rows"]})
        for r in range(pb["rows"]):
            for c in range(pb["cols"]):
                macros.append({
                    "inst": f"u_bank{b}_r{r}_c{c}", "macro_name": macro["macro_name"], "bank": b, "tile_row": r,
                    "tile_col": c, "x": bx + c * (macro["width_um"] + gap), "y": by + r * (macro["height_um"] + gap),
                    "w": macro["width_um"], "h": macro["height_um"], "orient": "R0",
                    "data_bit_lo": c * macro["data_width"], "data_bit_hi": min((c + 1) * macro["data_width"], d["stored_word"]) - 1,
                    "row_lo": r * macro["words"], "row_hi": min((r + 1) * macro["words"], d["depth"]) - 1})
    bbox_w, bbox_h = x_off + array_w, array_h
    margin = sp["margin_um"]
    if logic.get("value") is None:
        die = unavailable(f"logic area unknown ({logic.get('reason')}): die area is not estimated without it")
    elif compat is not True:
        die = unavailable(compat_msg)
    elif margin.get("value") is None:
        die = unavailable("margin_um not supplied: a die needs a core margin / pin keep-out, which is a placement parameter")
    else:
        m = margin["value"]
        die = tag((bbox_w + 2 * m) * (bbox_h + 2 * m), "analytical", "bbox of macros+channels+controller strip, plus margin",
                  unit="um^2", width_um=bbox_w + 2 * m, height_um=bbox_h + 2 * m, label2="generated-geometry")
    base.update({
        "status": "ok", "macro": {k: macro[k] for k in ("macro_name", "family", "process", "port_topology", "data_width",
                                                        "words", "width_um", "height_um", "area_um2")},
        "macro_source": {"manifest": macro["manifest_file"], "sha256": macro["manifest_sha256"],
                         "repo": macro["source_repo"], "commit": macro["source_commit"]},
        "tiling": tl, "parameters": sp, "bank_arrangement": {"columns": cols, "rows": rows,
                                                             "rule": "divisor pair of the bank count with the aspect ratio closest to 1"},
        "bank_regions": regions, "macros": macros, "controller": controller, "controller_anchor": {**anchor, "label": "generated-geometry"},
        "macro_array_bbox_um2": tag(array_w * array_h, "analytical", "bounding box of the macro array incl. channels; excludes "
                                    "controller strip and margins - NOT a die area", unit="um^2"),
        "macro_area_sum_um2": tag(tl["total_macro_area_um2"], "analytical", "instances x vendor macro area", unit="um^2"),
        "placed_bbox_um": {"width": bbox_w, "height": bbox_h},
        "orientation": "R0 for every macro: pin edges are not in the manifests, so no pin-aware orientation is modelled",
        "die": die, "warnings": lwarns + ([compat_msg] if compat is False else [])})
    base["routing_estimate"] = routing_estimate(base, cfg)
    _write(outdir, base)
    return base


def _write(outdir, fp: dict):
    if outdir:
        os.makedirs(os.fspath(outdir), exist_ok=True)
        with open(os.path.join(os.fspath(outdir), "floorplan.json"), "w") as fh:
            json.dump(fp, fh, indent=1, default=str)


def routing_estimate(fp: dict, cfg: dict | None = None) -> dict:
    """Analytical Manhattan (half-perimeter) bank <-> controller wirelength from the generated geometry.

    For each bank bus: HPWL of the 2-pin net (bank-region centre -> controller anchor) times the bus width
    (controller<->bank signals: wdata + wstrb + row address + valid/we + rdata + valid/err).  ``label: analytical``;
    NOT routed: no congestion, detours, layers, buffering or pin locations."""
    if not fp.get("bank_regions"):
        return unavailable("no bank geometry")
    a = fp["controller_anchor"]
    if cfg is None:
        return unavailable("config needed for the bus width")
    dims = _dims(normalise(cfg))
    word, depth = dims["word"], dims["depth"]
    raw = max(1, math.ceil(math.log2(depth))) if depth > 1 else 1
    sig = 2 * word + word // 8 + raw + 4
    per = []
    for r in fp["bank_regions"]:
        cx, cy = (r["x0"] + r["x1"]) / 2, (r["y0"] + r["y1"]) / 2
        man = abs(cx - a["x"]) + abs(cy - a["y"])
        # nearest point of the bank region to the anchor (pins are on macro edges, locations unknown)
        nx = min(max(a["x"], r["x0"]), r["x1"])
        ny = min(max(a["y"], r["y0"]), r["y1"])
        near = abs(nx - a["x"]) + abs(ny - a["y"])
        per.append({"bank": r["bank"], "manhattan_centre_um": man, "manhattan_nearest_edge_um": near})
    tot_c = sum(p["manhattan_centre_um"] for p in per) * sig
    tot_n = sum(p["manhattan_nearest_edge_um"] for p in per) * sig
    return {"label": "analytical", "kind": "Manhattan/HPWL proxy from generated geometry - NOT routed",
            "signals_per_bank_bus": sig, "signals_formula": "wdata(DW) + wstrb(DW/8) + row address + valid/we(2) + rdata(DW) + valid/err(2)",
            "per_bank": per,
            "mean_manhattan_centre_um": sum(p["manhattan_centre_um"] for p in per) / len(per),
            "max_manhattan_centre_um": max(p["manhattan_centre_um"] for p in per),
            "total_signal_um_centre": tot_c, "total_signal_um_nearest_edge": tot_n,
            "limits": "controller anchor is a generated-geometry convention; no congestion, detours, buffers or layers"}


# ---------------------------------------------------------------------------------------------- area report
def area_report(cfg: dict, synth: dict | None = None, tech_profile=None, *, ecc_study_path: str | None = None,
                noc: dict | None = None, spacing: dict | None = None, sweep: dict | None = None) -> dict:
    """Area / overhead report for one configuration.  See the module docstring for the label rules.

    ``synth``: a :func:`sramlab.synth.synth_controller` result (or ``None``).  ``tech_profile``: profile id / path /
    dict (``None`` -> ``cfg.physical.technology``).  Every figure is tagged; anything that cannot be produced is
    ``unavailable(reason)`` (never ``0`` and never an estimate)."""
    cfg = normalise(cfg)
    profile = tech.load_profile(tech_profile if tech_profile is not None else cfg["physical"].get("technology"))
    backend = cfg["physical"]["backend"]
    d = _dims(cfg)
    rep: dict = {"label": "area_report", "backend": backend, "technology_profile": profile["id"],
                 "warnings": [], "memory_bits": memory_bits(cfg)}
    # ----- memory footprint
    macro, why = _macro_for(cfg)
    if backend == "asic_macro" and macro is not None:
        tl = _tile_whole(cfg, macro)
        src = f"{macro['manifest_file']} @ {str(macro['source_commit'])[:12]} (vendor LEF/datasheet dimensions) x tiling"
        pb = tl["per_bank"]
        rep["memory_footprint"] = {
            "kind": "asic_macro", "macro": macro["macro_name"], "process": macro["process"],
            "port_topology": macro["port_topology"],
            "instances_total": tag(tl["instances_total"], "analytical", src, unit="macros"),
            "tiling_per_bank": {"cols": pb["cols"], "rows": pb["rows"], "instances": pb["instances"]},
            "total_macro_area_um2": tag(tl["total_macro_area_um2"], "analytical", src, unit="um^2"),
            "total_macro_area_mm2": tag(tl["total_macro_area_um2"] / 1e6, "analytical", src, unit="mm^2"),
            "bit_utilisation": tag(tl["bit_utilisation"], "analytical", src),
            "wasted_bits_total": tag(tl["wasted_bits_total"], "analytical", src, unit="bits"),
            "note": "macro footprint only (vendor dimensions); not a die area, no logic, no routing, no margins",
            "tiling_detail": tl}
        if pb.get("note"):
            rep["memory_footprint"]["macro_note"] = pb["note"]
        rep["memory_footprint"]["silicon_status"] = macro.get("silicon_status")
    elif backend == "asic_macro":
        rep["memory_footprint"] = {"kind": "asic_macro", "total_macro_area_um2": unavailable(why),
                                   "total_macro_area_mm2": unavailable(why)}
    elif backend == "fpga_bram":
        bram = (profile.get("fpga") or {}).get("bram_bits")
        spb = d["depth"] * d["stored_word"]
        rep["memory_footprint"] = {
            "kind": "fpga_bram", "bram_bits_total": rep["memory_bits"]["stored_bits"],
            "bram_bits_per_bank": rep["memory_bits"]["stored_bits_per_bank"],
            "bram_tiles_lower_bound": (tag(d["banks"] * math.ceil(spb / bram), "analytical",
                                           f"banks * ceil(stored bits per bank / {bram}) - perfect packing, ignores aspect ratio",
                                           unit="tiles", bram_bits=bram, device_source=(profile.get("fpga") or {}).get("source"))
                                       if bram else unavailable("device BRAM geometry not supplied (technology profile fpga.bram_bits)")),
            "area_mm2": unavailable("FPGA fabric has no die area in this tool: bit counts only")}
    else:
        rep["memory_footprint"] = {"kind": "generic", "area_um2": unavailable(
            "backend=generic: no technology or macro selected; only bit counts exist")}
    # ----- logic
    logic_area, lw = _logic_area(synth, profile)
    rep["warnings"] += lw + _synth_mismatch(cfg, synth)
    g = (synth or {}).get("generic") if synth else None
    gate = None
    if isinstance(g, dict) and "total_cells" in g:
        gate = {"total_cells": tag(g["total_cells"], "synthesized", "synth result (generic gates)", unit="cells"),
                "flip_flops": tag(g["flip_flops"], "synthesized", "synth result", unit="flip-flops"),
                "latches": tag(g["latches"], "synthesized", "synth result", unit="latches"),
                "logic_depth": g.get("logic_depth")}
    rep["logic"] = {"scope": "controller logic only (SRAM arrays excluded)",
                    "gate_counts": gate or unavailable("no synthesis result supplied"),
                    "area_um2": logic_area,
                    "technology": (synth or {}).get("mapped", {}).get("technology") if synth else None}
    # ----- ECC
    ratios = {str(k): tag(tech.secded_stored_bits(k) / k, "analytical", f"extended-Hamming SECDED {tech.secded_stored_bits(k)}/{k}")
              for k in (32, 64, 128)}
    ecc: dict = {"mode": d["ecc"], "stored_word_bits": d["stored_word"],
                 "stored_bit_ratio": tag(d["stored_word"] / d["word"], "analytical",
                                         f"{d['stored_word']}/{d['word']} stored bits per data bit"),
                 "reference_ratios": ratios}
    if d["ecc"] == "secded" and backend == "asic_macro" and macro is not None:
        try:
            base_t = _tile_whole(cfg, macro, stored_word=d["word"])
            full_t = _tile_whole(cfg, macro)
            ecc["extra_macro_area_um2"] = tag(full_t["total_macro_area_um2"] - base_t["total_macro_area_um2"], "analytical",
                                              "macro area with SECDED stored width minus the same memory without ECC", unit="um^2")
            ecc["extra_macros"] = tag(full_t["instances_total"] - base_t["instances_total"], "analytical",
                                      "tiling arithmetic", unit="macros")
        except tech.TechError as e:
            ecc["extra_macro_area_um2"] = unavailable(str(e))
    ecc["ecc_logic"] = _ecc_logic(d["word"], ecc_study_path) if d["ecc"] == "secded" else {
        "note": "ECC disabled: no codec logic", "value": 0, "provenance": "analytical", "source": "ecc=none"}
    rep["ecc_overhead"] = ecc
    # ----- arbitration, NoC
    rep["arbitration_overhead"] = _arbitration(cfg, synth, sweep)
    rep["noc_interface"] = _noc(noc)
    # ----- placement constraints
    sp = _spacing(spacing)
    rep["placement_constraints"] = {
        "halo_keepout": (macro["halo_keepout"] if macro else unavailable("no macro selected")),
        "manifest_constraints": (macro or {}).get("constraints", []) if macro else [],
        "caller_spacing": sp}
    # ----- floorplan, routing, die
    if backend == "asic_macro" and macro is not None:
        fp = floorplan(cfg, synth=synth, tech_profile=profile, spacing=spacing)
        rep["routing_estimate"] = fp.get("routing_estimate")
        rep["die_area"] = fp["die"]
        rep["macro_array_bbox_um2"] = fp.get("macro_array_bbox_um2")
        rep["warnings"] += fp.get("warnings", [])
    else:
        rep["routing_estimate"] = unavailable("no macro geometry (backend is not asic_macro)")
        rep["die_area"] = unavailable("no macro geometry and no technology library: die area is not estimated from nothing")
    return rep


# ---------------------------------------------------------------------------------------------- optimiser hook
def candidate_area(c: dict, capacity_bytes: int, macro_family: str = DEFAULT_CANDIDATE_FAMILY) -> dict:
    """Area hook for ``sramlab optimise`` (``area_fn(candidate, capacity_bytes)``): the cheapest single-port macro tiling of
    the candidate's bank, from ONE macro family so candidates are compared under the same macros.  The value is a macro
    footprint (analytical, vendor dimensions), not a die area; the family default is a documented comparison choice."""
    try:
        banks = int(c.get("banks", 4))
        word = int(c.get("word_bits", 32))
        ecc = c.get("ecc", "none")
        stored = tech.secded_stored_bits(word) if ecc == "secded" else word
        cap_bits = capacity_bytes * 8
        if cap_bits % (banks * word):
            return {"value": None, "label": "unavailable", "note": "capacity is not a whole number of rows per bank"}
        depth = cap_bits // (banks * word)
        ranked = tech.rank_macros(depth * stored, stored, family=macro_family)
        if not ranked:
            return {"value": None, "label": "unavailable", "note": f"no macro of family {macro_family!r} in the catalogue"}
        best = ranked[0]
        return {"value": banks * best["total_macro_area_um2"], "label": "analytical", "unit": "um^2",
                "note": (f"macro footprint only, family {macro_family} (comparison choice; vendor dimensions, not a die area): "
                         f"{banks} x {best['instances']} x {best['macro_name']}"),
                "macro": best["macro_name"], "instances": banks * best["instances"],
                "bit_utilisation": best["bit_utilisation"]}
    except (tech.TechError, ValueError, KeyError) as e:
        return {"value": None, "label": "unavailable", "note": str(e)}
