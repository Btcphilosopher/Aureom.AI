# Imported measured-RTL data (read-only reference, used only for cross-validation)

| file | origin | what it is |
|---|---|---|
| `p76_bench.csv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-vectorscratch-p76.zip` -> `reports/bench.csv` (unmodified) | 613 rows of **RTL-simulation** results (Verilator 5.020, per that package's own report) of `sf_vector_scratchpad`; 26 configurations x workloads |

Label in SRAMLab: `rtl_simulated` (imported). These are NOT silicon/FPGA measurements and NOT produced by this tool run;
they are used to cross-check SRAMLab's alignment / bank-slot arithmetic (`sramlab/studies/vector.py::p76_crosscheck`).
