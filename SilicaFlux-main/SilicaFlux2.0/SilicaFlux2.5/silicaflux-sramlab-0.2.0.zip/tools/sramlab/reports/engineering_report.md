# SilicaFlux SRAMLab — Engineering Report

_Generated 2026-11-26 00:28 UTC from `data/*.json` by `sramlab report`. Tools: Python 3.13.18, Verilator 5.020, Yosys 0.33; OpenROAD/OpenSTA: NOT available._

Every figure is labelled **analytical** (closed form), **simulated** (cycle model verified against the RTL), **rtl_simulated** (Verilator run of, or imported committed results of, the real RTL), **synthesized** (Yosys), **assumed**, or **unavailable**. **No figure here is a silicon or FPGA measurement; none exists.**

## 1. Model vs RTL verification (start of the programme)
The Python cycle model of `sf_sram_subsystem` (SRAMController P73 + SRAMCore P71) was compared with the Verilator simulation of the real RTL: **275/275 cases identical** over 198,824 cycles, 340,788 transactions and 34,568 hardware-counter values (23 parameter sets). Negative control (deliberately broken models): arbiter_fixed_priority → detected, bank_lock_dropped → detected, read_latency_plus_one → detected, conflict_counter_wrong → detected. *(rtl_simulated vs simulated)*

**Second simulator.** An independently written Icarus Verilog testbench replays the same stimulus: **112/112 cases Python model = Verilator = Icarus**, cycle for cycle and counter for counter. *(rtl_simulated, two simulators)*

**Study testbenches on two simulators** (`sramlab xsim`): the ECC codec, ECC bank and MBIST testbenches were run with byte-identical inputs on Verilator 5.020 and Icarus 12.0: **9/9 cases identical** (87,411 tagged result lines). Negative control — the MBIST testbench rebuilt without the Verilator optimiser workaround: this Verilator mis-simulates the testbench without the workaround; the cross-check detected it (first difference: Verilator `cycles=567` vs Icarus `cycles=195`). See `docs/03_verification.md` (*Harness portability*) for the three Verilator 5.020 defects this exposed.

**Statistics recomputed in R** (`sramlab rstats`, R 4.3.3): **305/305 quantities agree** with the Python statistics (per-replication mean/median/P95/P99 and throughput exactly; Student-t CI half-widths within 1e-06 relative; Spearman). *(simulated data, statistics cross-checked)*

## 2. Bank-count comparison (constant 64 KiB, 4 masters, 32-bit words) — *simulated*, analytical ceilings labelled

### MAX_OUT = 1 (10 replications, mean ± 95 % CI half-width)
| workload | banks | txn/cycle (sim) | peak (analytical) | random est. (analytical) | read latency e2e (sim) | p99 | conflicts/access | bank util |
|---|---|---|---|---|---|---|---|---|
| rand_read | 2 | 1.563 ±0.005 | 2.00 | 1.88 | 3.54 ±0.01 | 5.0 | 0.545 ±0.006 | 0.78 |
| rand_read | 4 | 1.811 ±0.004 | 2.00 | 2.00 | 3.20 ±0.00 | 5.0 | 0.197 ±0.003 | 0.45 |
| rand_read | 8 | 1.912 ±0.002 | 2.00 | 2.00 | 3.09 ±0.00 | 4.0 | 0.086 ±0.002 | 0.24 |
| rand_read | 16 | 1.956 ±0.002 | 2.00 | 2.00 | 3.04 ±0.00 | 4.0 | 0.040 ±0.002 | 0.12 |
| mixed | 2 | 1.563 ±0.005 | 2.00 | 1.88 | 3.55 ±0.01 | 5.0 | 0.548 ±0.007 | 0.78 |
| mixed | 4 | 1.816 ±0.003 | 2.00 | 2.00 | 3.19 ±0.00 | 5.0 | 0.193 ±0.004 | 0.45 |
| mixed | 8 | 1.910 ±0.002 | 2.00 | 2.00 | 3.09 ±0.00 | 4.0 | 0.086 ±0.002 | 0.24 |
| mixed | 16 | 1.955 ±0.003 | 2.00 | 2.00 | 3.04 ±0.00 | 4.0 | 0.040 ±0.002 | 0.12 |
| seq_read | 2 | 1.998 ±0.000 | 2.00 | 1.88 | 3.00 ±0.00 | 3.0 | 0.001 ±0.000 | 1.00 |
| seq_read | 4 | 1.998 ±0.000 | 2.00 | 2.00 | 3.00 ±0.00 | 3.0 | 0.001 ±0.000 | 0.50 |
| seq_read | 8 | 1.998 ±0.000 | 2.00 | 2.00 | 3.00 ±0.00 | 3.0 | 0.001 ±0.000 | 0.25 |
| seq_read | 16 | 1.998 ±0.000 | 2.00 | 2.00 | 3.00 ±0.00 | 3.0 | 0.001 ±0.000 | 0.12 |
| hotspot | 2 | 1.565 ±0.003 | 2.00 | 1.88 | 3.54 ±0.01 | 5.0 | 0.543 ±0.006 | 0.78 |
| hotspot | 4 | 1.814 ±0.002 | 2.00 | 2.00 | 3.20 ±0.00 | 5.0 | 0.196 ±0.003 | 0.45 |
| hotspot | 8 | 1.911 ±0.003 | 2.00 | 2.00 | 3.09 ±0.00 | 4.0 | 0.086 ±0.003 | 0.24 |
| hotspot | 16 | 1.927 ±0.003 | 2.00 | 2.00 | 3.07 ±0.00 | 4.0 | 0.069 ±0.002 | 0.12 |
| contention | 2 | 1.000 ±0.000 | 2.00 | 1.88 | 5.00 ±0.00 | 5.0 | 2.000 ±0.000 | 0.50 |
| contention | 4 | 1.000 ±0.000 | 2.00 | 2.00 | 5.00 ±0.00 | 5.0 | 2.000 ±0.000 | 0.25 |
| contention | 8 | 1.000 ±0.000 | 2.00 | 2.00 | 5.00 ±0.00 | 5.0 | 2.000 ±0.000 | 0.12 |
| contention | 16 | 1.000 ±0.000 | 2.00 | 2.00 | 5.00 ±0.00 | 5.0 | 2.000 ±0.000 | 0.06 |

### MAX_OUT = 4 (10 replications, mean ± 95 % CI half-width)
| workload | banks | txn/cycle (sim) | peak (analytical) | random est. (analytical) | read latency e2e (sim) | p99 | conflicts/access | bank util |
|---|---|---|---|---|---|---|---|---|
| rand_read | 2 | 1.745 ±0.005 | 2.00 | 1.88 | 3.27 ±0.01 | 5.0 | 1.274 ±0.005 | 0.87 |
| rand_read | 4 | 2.602 ±0.011 | 4.00 | 2.73 | 2.53 ±0.01 | 5.0 | 0.526 ±0.005 | 0.65 |
| rand_read | 8 | 3.237 ±0.012 | 4.00 | 3.31 | 2.22 ±0.00 | 4.0 | 0.225 ±0.004 | 0.40 |
| rand_read | 16 | 3.591 ±0.009 | 4.00 | 3.64 | 2.10 ±0.00 | 3.0 | 0.104 ±0.002 | 0.22 |
| mixed | 2 | 1.747 ±0.007 | 2.00 | 1.88 | 3.28 ±0.01 | 5.0 | 1.274 ±0.008 | 0.87 |
| mixed | 4 | 2.606 ±0.010 | 4.00 | 2.73 | 2.52 ±0.01 | 5.0 | 0.519 ±0.006 | 0.65 |
| mixed | 8 | 3.240 ±0.012 | 4.00 | 3.31 | 2.22 ±0.00 | 4.0 | 0.224 ±0.003 | 0.41 |
| mixed | 16 | 3.604 ±0.009 | 4.00 | 3.64 | 2.10 ±0.00 | 3.1 | 0.102 ±0.002 | 0.23 |
| seq_read | 2 | 1.999 ±0.000 | 2.00 | 1.88 | 3.00 ±0.00 | 4.0 | 1.000 ±0.000 | 1.00 |
| seq_read | 4 | 3.990 ±0.000 | 4.00 | 2.73 | 2.00 ±0.00 | 2.0 | 0.001 ±0.000 | 1.00 |
| seq_read | 8 | 3.990 ±0.000 | 4.00 | 3.31 | 2.00 ±0.00 | 2.0 | 0.001 ±0.000 | 0.50 |
| seq_read | 16 | 3.990 ±0.000 | 4.00 | 3.64 | 2.00 ±0.00 | 2.0 | 0.001 ±0.000 | 0.25 |
| hotspot | 2 | 1.747 ±0.007 | 2.00 | 1.88 | 3.27 ±0.01 | 5.0 | 1.275 ±0.009 | 0.87 |
| hotspot | 4 | 2.607 ±0.012 | 4.00 | 2.73 | 2.52 ±0.01 | 5.0 | 0.518 ±0.007 | 0.65 |
| hotspot | 8 | 3.245 ±0.011 | 4.00 | 3.31 | 2.22 ±0.01 | 4.0 | 0.223 ±0.003 | 0.41 |
| hotspot | 16 | 3.358 ±0.024 | 4.00 | 3.64 | 2.18 ±0.01 | 4.0 | 0.181 ±0.006 | 0.21 |
| contention | 2 | 1.000 ±0.000 | 2.00 | 1.88 | 5.00 ±0.00 | 5.0 | 2.999 ±0.000 | 0.50 |
| contention | 4 | 1.000 ±0.000 | 4.00 | 2.73 | 5.00 ±0.00 | 5.0 | 2.999 ±0.000 | 0.25 |
| contention | 8 | 1.000 ±0.000 | 4.00 | 3.31 | 5.00 ±0.00 | 5.0 | 2.999 ±0.000 | 0.12 |
| contention | 16 | 1.000 ±0.000 | 4.00 | 3.64 | 5.00 ±0.00 | 5.0 | 2.999 ±0.000 | 0.06 |

**Findings (computed from the table):**
- MAX_OUT=1, rand_read: 4→8 banks +5.5 %, 8→16 banks +2.3 % throughput (1.81 → 1.91 → 1.96 txn/cycle).
- MAX_OUT=1, mixed: 4→8 banks +5.2 %, 8→16 banks +2.3 % throughput (1.82 → 1.91 → 1.95 txn/cycle).
- MAX_OUT=1, seq_read: throughput is flat from 4 to 16 banks (2.00 → 2.00 txn/cycle): more banks add nothing for this workload.
- MAX_OUT=1, hotspot: 4→8 banks +5.4 %, 8→16 banks +0.8 % throughput (1.81 → 1.91 → 1.93 txn/cycle).
- MAX_OUT=1, contention: throughput is flat from 4 to 16 banks (1.00 → 1.00 txn/cycle): more banks add nothing for this workload.
- MAX_OUT=4, rand_read: 4→8 banks +24.4 %, 8→16 banks +10.9 % throughput (2.60 → 3.24 → 3.59 txn/cycle).
- MAX_OUT=4, mixed: 4→8 banks +24.3 %, 8→16 banks +11.2 % throughput (2.61 → 3.24 → 3.60 txn/cycle).
- MAX_OUT=4, seq_read: throughput is flat from 4 to 16 banks (3.99 → 3.99 txn/cycle): more banks add nothing for this workload.
- MAX_OUT=4, hotspot: 4→8 banks +24.5 %, 8→16 banks +3.5 % throughput (2.61 → 3.25 → 3.36 txn/cycle).
- MAX_OUT=4, contention: throughput is flat from 4 to 16 banks (1.00 → 1.00 txn/cycle): more banks add nothing for this workload.
- More banks do **not** always help: the benefit exists only when requests spread over banks *and* masters can keep more than one transaction in flight; the hardware cost of more banks is in §7 (synthesis) and §8 (area).

**Sensitivity to bank count — computed in R** (`sramlab rstats`; configs/four_bank_baseline.yaml, 2, 4, 8, 16 banks at constant capacity, 4 replications each, 300 requests/master): elasticity = slope of ln(throughput) on ln(banks) (a one-number summary over 2–16 banks; the relation need not be log-linear).
| workload | elasticity d ln(txn/cycle) / d ln(banks) | 95 % CI | R² / note |
|---|---|---|---|
| rand_read | 0.338 | 0.284 … 0.392 | 0.928 |
| mixed | 0.336 | 0.282 … 0.390 | 0.927 |
| seq_read | 0.295 | 0.157 … 0.433 | 0.600 |
| hotspot | 0.348 | 0.297 … 0.398 | 0.939 |
| contention | 0.000 | — | throughput is identical at every bank count (no regression fitted) |

Variation between workloads (Kruskal–Wallis on per-replication throughput at the baseline configuration, 8 replications per workload): H = 30.56, df = 4, p = 3.8e-06 — throughput differs between workloads well beyond seed-to-seed variation (p < 0.05). *(simulated data, analysis in R)*

## 3. Tensor memory study — *simulated* (TensorCore 4×4 INT8, output-stationary, direct-fed from banked SRAM)
Operand requirement at peak: 4 A + 4 B bytes per k-step = 8 B/cycle for 16 MAC/cycle. Ideal-resource reference utilisation of this model: **0.90**. Verdict rule: memory_limited = MAC utilisation < 95% of the ideal-resource reference run of the same model.

| banks | MAX_OUT | DMA duty | MAC util | starved | operand B/c (need 8) | acc words/c | buf occ A/B | DMA overlap | verdict |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 0.0 | 0.44 | 0.55 | 3.52 | 0.110 | 2.8/1.7 | n/a | MEMORY-limited |
| 1 | 1 | 0.5 | 0.32 | 0.67 | 2.53 | 0.079 | 2.4/1.6 | 0.43 | MEMORY-limited |
| 1 | 2 | 0.0 | 0.44 | 0.55 | 3.55 | 0.111 | 2.8/1.7 | n/a | MEMORY-limited |
| 1 | 2 | 0.5 | 0.32 | 0.67 | 2.54 | 0.079 | 2.4/1.6 | 0.43 | MEMORY-limited |
| 1 | 4 | 0.0 | 0.44 | 0.55 | 3.55 | 0.111 | 2.8/1.7 | n/a | MEMORY-limited |
| 1 | 4 | 0.5 | 0.32 | 0.67 | 2.54 | 0.079 | 2.4/1.6 | 0.43 | MEMORY-limited |
| 2 | 1 | 0.0 | 0.48 | 0.50 | 3.86 | 0.121 | 2.9/5.4 | n/a | MEMORY-limited |
| 2 | 1 | 0.5 | 0.45 | 0.54 | 3.57 | 0.112 | 2.8/5.5 | 0.42 | MEMORY-limited |
| 2 | 2 | 0.0 | 0.73 | 0.26 | 5.86 | 0.183 | 3.4/5.3 | n/a | MEMORY-limited |
| 2 | 2 | 0.5 | 0.58 | 0.41 | 4.60 | 0.144 | 3.0/5.3 | 0.58 | MEMORY-limited |
| 2 | 4 | 0.0 | 0.73 | 0.26 | 5.86 | 0.183 | 3.4/5.3 | n/a | MEMORY-limited |
| 2 | 4 | 0.5 | 0.58 | 0.41 | 4.60 | 0.144 | 3.0/5.3 | 0.58 | MEMORY-limited |
| 4 | 1 | 0.0 | 0.49 | 0.50 | 3.89 | 0.122 | 2.9/5.0 | n/a | MEMORY-limited |
| 4 | 1 | 0.5 | 0.47 | 0.51 | 3.74 | 0.117 | 2.8/4.7 | 0.46 | MEMORY-limited |
| 4 | 2 | 0.0 | 0.83 | 0.15 | 6.65 | 0.208 | 3.8/5.2 | n/a | MEMORY-limited |
| 4 | 2 | 0.5 | 0.78 | 0.21 | 6.20 | 0.194 | 3.8/4.9 | 0.80 | MEMORY-limited |
| 4 | 4 | 0.0 | 0.83 | 0.15 | 6.65 | 0.208 | 3.8/5.2 | n/a | MEMORY-limited |
| 4 | 4 | 0.5 | 0.78 | 0.21 | 6.20 | 0.194 | 3.8/4.9 | 0.80 | MEMORY-limited |
| 8 | 1 | 0.0 | 0.49 | 0.50 | 3.89 | 0.122 | 2.9/5.0 | n/a | MEMORY-limited |
| 8 | 1 | 0.5 | 0.48 | 0.51 | 3.83 | 0.120 | 2.9/5.2 | 0.48 | MEMORY-limited |
| 8 | 2 | 0.0 | 0.87 | 0.12 | 6.95 | 0.217 | 4.0/5.0 | n/a | not memory-limited |
| 8 | 2 | 0.5 | 0.82 | 0.16 | 6.58 | 0.206 | 3.9/4.7 | 0.85 | MEMORY-limited |
| 8 | 4 | 0.0 | 0.87 | 0.12 | 6.95 | 0.217 | 4.0/5.0 | n/a | not memory-limited |
| 8 | 4 | 0.5 | 0.82 | 0.16 | 6.58 | 0.206 | 3.9/4.7 | 0.85 | MEMORY-limited |
| 16 | 1 | 0.0 | 0.49 | 0.50 | 3.90 | 0.122 | 2.9/4.9 | n/a | MEMORY-limited |
| 16 | 1 | 0.5 | 0.48 | 0.50 | 3.87 | 0.121 | 2.9/4.5 | 0.48 | MEMORY-limited |
| 16 | 2 | 0.0 | 0.91 | 0.08 | 7.26 | 0.227 | 4.1/4.7 | n/a | not memory-limited |
| 16 | 2 | 0.5 | 0.88 | 0.10 | 7.07 | 0.221 | 4.1/4.5 | 0.89 | not memory-limited |
| 16 | 4 | 0.0 | 0.91 | 0.08 | 7.26 | 0.227 | 4.1/4.7 | n/a | not memory-limited |
| 16 | 4 | 0.5 | 0.88 | 0.10 | 7.07 | 0.221 | 4.1/4.5 | 0.89 | not memory-limited |

**Findings (computed):**
- **Answer to "does memory bandwidth limit compute throughput?": it depends on the memory organisation.** 11 of 15 evaluated 32-bit configurations (no DMA, padded pitches) are memory limited, and 13 of 15 once a DMA fill runs at 50 % duty; the array is not limited only with enough banks AND enough outstanding transactions per port (see the smallest such configuration below).
- With MAX_OUT=1 MAC utilisation stays at 0.44–0.49 for every bank count (1–16): the limit is the request/response credit loop, not SRAM bank bandwidth.
- Padding the matrix pitches changes MAC utilisation at MAX_OUT=4 by 1 banks +0.00, 2 banks +0.12, 4 banks +0.08, 8 banks +0.05, 16 banks -0.00 (pitch-induced bank aliasing).
- Smallest configuration that is NOT memory limited (≥95 % of the ideal 0.90): 8 banks, MAX_OUT=2 (utilisation 0.87).
- Concurrent DMA fill at 50 % duty lowers utilisation at MAX_OUT=4 by 1 banks 0.13, 2 banks 0.16, 4 banks 0.06, 8 banks 0.05, 16 banks 0.02.

TENSORCORE 08 DMA command stream (replayed on the RTL in the §1 matrix at a scaled size: 22/22 cases cycle-identical): 0.500 bytes/MAC (= 512 B per 1024 MAC chunk, as documented); sustained operand bandwidth 3.55 B/cycle through one master → MAC/cycle roof 7.1 of 16 *(analytical from simulated bandwidth)*. roof = simulated sustained operand bandwidth / bytes-per-MAC; compute overhead (~29 cycles per chunk per the TC10 benchmarks) would lower real utilisation further and is not modelled here.

## 4. Vector memory study — *simulated*, cross-checked against RTL-simulation data
Alignment arithmetic and bank-slot cycle model vs the imported VectorScratch (P76) RTL-simulation bench: **76/76 rows cycle-exact**, word-access counts 76/76 *(rtl_simulated reference)*. Scope: deterministic sequential load/store streams, LOW bank map, 32-bit banks, DMA idle, split/merge alignment policy (the rows where the arithmetic is closed-form).

Controller study (single-port-per-master word accesses, 8 banks, 128-bit vectors, 4 vector masters):

| word bits | case | useful B/c | fetched B/c | alignment overhead | conflicts/access | read lat e2e |
|---|---|---|---|---|---|---|
| 32 | aligned_load | 15.95 ±0.00 | 15.95 | 1.00× | 0.00 | 2.00 |
| 32 | word_misaligned_load | 15.95 ±0.00 | 15.95 | 1.00× | 0.00 | 2.00 |
| 32 | byte_misaligned_load | 7.99 ±0.00 | 9.99 | 1.25× | 0.60 | 2.60 |
| 32 | cross_bank_load | 15.95 ±0.00 | 15.95 | 1.00× | 0.00 | 2.00 |
| 32 | aligned_store | 15.95 ±0.00 | 15.95 | 1.00× | 0.00 | nan |
| 32 | partial_store | 15.36 ±0.07 | 15.33 | 1.00× | 0.04 | nan |
| 32 | strided_load_64B | 15.95 ±0.00 | 15.95 | 1.00× | 0.00 | 2.00 |
| 32 | strided_load_bank_stride | 15.95 ±0.00 | 15.95 | 1.00× | 0.00 | 2.00 |
| 128 | aligned_load | 63.70 ±0.00 | 63.70 | 1.00× | 0.00 | 2.00 |
| 128 | word_misaligned_load | 12.79 ±0.00 | 25.59 | 2.00× | 1.50 | 3.50 |
| 128 | byte_misaligned_load | 12.79 ±0.00 | 25.59 | 2.00× | 1.50 | 3.50 |
| 128 | cross_bank_load | 12.79 ±0.00 | 25.59 | 2.00× | 1.50 | 3.50 |
| 128 | aligned_store | 63.70 ±0.00 | 63.70 | 1.00× | 0.00 | nan |
| 128 | partial_store | 47.78 ±0.00 | 63.70 | 1.33× | 0.00 | nan |
| 128 | strided_load_64B | 41.42 ±0.00 | 41.42 | 1.00× | 0.49 | 2.49 |
| 128 | strided_load_bank_stride | 27.66 ±0.00 | 27.66 | 1.00× | 0.90 | 2.90 |

**Findings (computed):**
- 32-bit words, 128-bit vectors, 1-byte misalignment: **alignment cost** = 1.25x fetched bytes per useful byte (a single master loses 20 % useful bandwidth). In this 4-master run useful bandwidth falls from 15.95 to 7.99 B/cycle (-50 %); the loss beyond the pure alignment cost comes from bank conflicts (0.60/access vs 0.00 aligned) because the masters stream in the same bank phase and re-fetch the shared boundary word - that component depends on the masters' relative phase, not on alignment alone.
- 32-bit words: the 256-byte stride adds no conflicts here (each vector spans several consecutive banks, so starting on one bank does not serialise the stream).
- 128-bit words, 128-bit vectors, 1-byte misalignment: **alignment cost** = 2.00x fetched bytes per useful byte (a single master loses 50 % useful bandwidth). In this 4-master run useful bandwidth falls from 63.70 to 12.79 B/cycle (-80 %); the loss beyond the pure alignment cost comes from bank conflicts (1.50/access vs 0.00 aligned) because the masters stream in the same bank phase and re-fetch the shared boundary word - that component depends on the masters' relative phase, not on alignment alone.
- 128-bit words: the 256-byte stride maps every vector start onto the same bank and adds 0.90 conflicts/access; useful bandwidth falls from 63.70 to 27.66 B/cycle.
- Partial stores: an entirely masked word is not accessed, so the cost is not in extra accesses; the RMW penalty of partial writes appears only with ECC (see §5).

## 5. ECC cost analysis
Measured on the real MemoryCore RTL (`sf_ecc_enc/dec`, `sf_sram_bank` with and without SECDED) in Verilator, cross-checked against an independent Python SECDED reference. Gate counts are Yosys *generic* counts before technology mapping (this Yosys build cannot run ABC), so they are **not area**. *rtl_simulated / synthesized*

| item | 32-bit words | 64-bit words | 128-bit words |
|---|---|---|---|
| stored bits per word (ECC on) | 39 | 72 | 137 |
| storage overhead | 21.875 % | 12.500 % | 7.031 % |
| encoder / decoder generic cells | 84 / 434 | 176 / 812 | 315 / 1544 |
| bank generic cells, ECC off → on | 336 → 1541 (4.6x) | 480 → 2427 (5.1x) | 768 → 4054 (5.3x) |
| decoder latency added (RL 1 / RL 2) | +1 / +1 cycle | +1 / +1 cycle | +1 / +1 cycle |
| partial-write accept interval, ECC on (RL 1 / RL 2) | 2 / 3 cycles (ECC off: 1) | 2 / 3 cycles (ECC off: 1) | 2 / 3 cycles (ECC off: 1) |
| single-bit errors corrected | 39/39 | 72/72 | 137/137 |
| double-bit errors detected | 1500/1500 | 1500/1500 | 1500/1500 |
| random 3-bit errors silently miscorrected | 68.2 % | 74.9 % | 84.0 % |
| RTL vs independent reference | 0 mismatches / 14,980 vectors | 0 mismatches / 67,362 vectors | 0 mismatches / 34,612 vectors |

SECDED does **not** protect against 3-bit errors: most are silently miscorrected, as measured. Scrubbing consumes a measurable share of bank bandwidth (see the ECC study record, `scrub`). Fault injection shows what the logic does with a bit flip, not how often flips occur.

## 6. MBIST evaluation
**coverage of the injected fault model in simulation; this is NOT manufacturing/physical defect coverage**

Real RTL (P78 `sf_sram_mbist`, Verilator) plus an independent Python March simulator on an enumerated fault population. *rtl_simulated*; parallel-bank figures are *analytical* and not RTL-verified.

| item | value | provenance |
|---|---|---|
| March C- total test cycles, 16 banks × 256 words | 41,295 | rtl_simulated |
| MATS+ total test cycles, 16 banks × 256 words | 20,815 | rtl_simulated |
| exact cycle model error vs RTL (45 runs) | 0 cycles | analytical vs rtl_simulated |
| plain 10N / 5N model error (16 banks) | 0.81 % / 1.61 % | analytical vs rtl_simulated |
| banks tested one at a time (verified) | True | rtl_simulated |
| failure registers vs independent prediction | 11/11 | rtl_simulated |
| RTL vs Python simulator, per-fault mismatches (4×32) | 0 | rtl_simulated vs simulated |

Same-word coupling-fault coverage of the injected model (4 × 32 array, exhaustive; *injected simulation fault model only*):

| test | coverage |
|---|---|
| C0 March C-, solid | 60.00 % |
| C1 March C-, checkerboard | 60.00 % |
| C2 March C-, solid U checkerboard (2 runs) | 80.65 % |
| C3 March C-, background sweep (solid + stripes) | 100.00 % |
| C4 MATS+, solid | 40.00 % |
| C5 MATS+, checkerboard | 50.00 % |
| C6 MATS+, solid U checkerboard (2 runs) | 65.48 % |

The RTL implements **sequential** bank testing only; parallel testing time is an analytical model in the study record. Test-mode overhead (functional masters refused for the whole test) and the sibling-report disagreements are documented in `docs/mbist.md`.

## 7. Synthesis
Yosys synthesis of the **controller logic only** (the SRAM arrays are not synthesized to gates). *synthesized*. Generic gate counts are **not area**; logic depth is pre-mapping gate levels, **not a frequency**. Mapped area uses the open educational **Nangate45 45 nm** library and is not transferable to the SilicaFlux target process.

| banks | perf counters | masters | MAX_OUT | generic cells | flip-flops | logic depth (levels) | latches | Nangate45 logic area um² (synthesized) |
|---|---|---|---|---|---|---|---|---|
| 2 | off | 4 | 1 | 1,862 | 242 | 31 | latch-free | 2,876 |
| 2 | on | 4 | 1 | 18,201 | 2,393 | 87 | latch-free | 27,815 |
| 4 | off | 4 | 1 | 3,271 | 286 | 32 | latch-free | 4,459 |
| 4 | on | 4 | 1 | 22,725 | 2,821 | 103 | latch-free | 33,784 |
| 8 | off | 4 | 1 | 6,098 | 374 | 36 | latch-free | 6,599 |
| 8 | on | 4 | 1 | 31,828 | 3,677 | 133 | latch-free | 45,084 |
| 16 | off | 4 | 1 | 11,740 | 550 | 43 | latch-free | 11,897 |
| 16 | on | 4 | 1 | 49,923 | 5,389 | 197 | latch-free | 68,618 |

**Hardware overhead of more banks (computed):** controller cells grow 6.3x from 2 to 16 banks (1,862 → 11,740 generic cells, performance counters off). Enabling the hardware performance-counter block multiplies the 4-bank controller by 6.9x (3,271 → 22,725 cells): the counters used for every measurement in this report are not free.

`noc_interface`: sf_sram_datafabric: None cells, None FFs; sf_sram_fabric_top: None cells, None FFs

`noc_interface_nangate45`: sf_sram_datafabric: None cells, None FFs; sf_sram_fabric_top: None cells, None FFs

`subsystem_generic`: 27525 cells, 5001 FFs, status ok

`subsystem_nangate45`: 27525 cells, 5001 FFs, status ok

## 8. Physical area
Configuration backend `asic_macro`, technology profile `sky130_open_pdk`. All footprint values come from real vendor macro manifests (LEF-derived) *analytical (vendor dimensions)*; this is geometry arithmetic, not a layout.

| item | value | provenance / reason |
|---|---|---|
| macro | sky130_sram_2kbyte_1rw1r_32x512_8 |  |
| process | SKY130 (130 nm) |  |
| instances_total | 32 | analytical |
| total_macro_area_mm2 | 9.10523104 | analytical |
| bit_utilisation | 1.0 | analytical |
| wasted_bits_total | 0 | analytical |
| ECC stored-bit ratio (this config) | 1.0 | analytical |
| routing estimate (mean Manhattan, um) | 1366.2 | analytical (NOT routed) |
| die area | UNAVAILABLE | logic area unknown (no synthesis result supplied (sramlab.synth.synth_controller)): die ar |
| halo / keep-out | UNAVAILABLE | manifests carry no halo / keep-out rule; supply one explicitly |

**Die area is unknown:** it needs controller logic area in the SAME technology as the macros plus layout margins; no such library/rule is available for the macro process here, so nothing is estimated. (The Nangate45 logic area is never added to 130 nm macro area.)

## 9. Power and energy provenance
activity figures are parameter-free (simulated); energy values exist only when a validated profile covers every needed term; nothing here is measured unless a user-supplied measurement file says so

| activity figure (parameter-free) | value | provenance |
|---|---|---|
| cycles | 3093 | simulated |
| reads | 5661 | simulated |
| writes | 2339 | simulated |
| array_accesses | 8000 | simulated |
| array_bit_activations | 256000 | simulated |
| array_bit_activations_per_useful_byte | 8.0 | simulated |
| bank_busy_cycles | 8000 | simulated |
| bank_idle_cycles | 4372 | simulated |
| data_bus_toggles | 37387 | simulated |
| bank_accesses | [1999, 1915, 2024, 2062] | simulated |
| ecc_rmw_amplification | 1.0 | simulated |
| useful_bytes | 32000 | simulated |

| energy class (kept separate) | status | reason / note |
|---|---|---|
| analytical_energy | analytical | closed-form, workload-independent relations; absolute energies need a profile (section activity_base |
| activity_based_estimate | UNAVAILABLE | no validated energy profile => no energy (activity figures are still reported) |
| fpga_vendor_estimate | UNAVAILABLE | no vendor power report supplied (e.g. Vivado report_power output); none exists in this tree |
| asic_library_estimate | UNAVAILABLE | no Liberty for the SRAM macro supplied: the vendored manifests list macro Liberty views but the .lib |
| hardware_measurement | UNAVAILABLE | no user-supplied measurement file: no SilicaFlux silicon / FPGA measurement exists |

## 10. Thermal hand-off
| item | value | provenance | source / reason |
|---|---|---|---|
| label | uncalibrated model input - not a die temperature |  |  |
| files.geometry_activity_csv | /tmp/claude-0/-home-user-Aureom-AI/9984aa34-0210-511e-af22-7 |  |  |
| files.geometry_activity_json | /tmp/claude-0/-home-user-Aureom-AI/9984aa34-0210-511e-af22-7 |  |  |
| blocks[0].name | SRAM_bank0 |  |  |
| blocks[0].zone | SRAM |  |  |
| blocks[0].x0_um | 0.0 |  |  |
| blocks[0].y0_um | 0.0 |  |  |
| blocks[0].x1_um | 683.1 |  |  |
| blocks[0].y1_um | 3332.32 |  |  |
| blocks[0].kind | cell |  |  |
| blocks[0].layer | active |  |  |
| blocks[0].provenance | assumed_engineering_parameter |  |  |
| blocks[0].accesses | 1999 |  |  |
| blocks[0].access_share | 0.249875 |  |  |
| blocks[0].utilisation_accesses_per_cycle | 0.6462980924668607 |  |  |
| blocks[0].access_density_per_mm2 | 878.1764957381474 |  |  |
| blocks[1].name | SRAM_bank1 |  |  |
| blocks[1].zone | SRAM |  |  |
| blocks[1].x0_um | 683.1 |  |  |
| blocks[1].y0_um | 0.0 |  |  |
| blocks[1].x1_um | 1366.2 |  |  |
| blocks[1].y1_um | 3332.32 |  |  |
| blocks[1].kind | cell |  |  |
| blocks[1].layer | active |  |  |
| blocks[1].provenance | assumed_engineering_parameter |  |  |
| blocks[1].accesses | 1915 |  |  |
| blocks[1].access_share | 0.239375 |  |  |
| blocks[1].utilisation_accesses_per_cycle | 0.619139993533786 |  |  |
| blocks[1].access_density_per_mm2 | 841.2746319852688 |  |  |
| blocks[2].name | SRAM_bank2 |  |  |
| blocks[2].zone | SRAM |  |  |
| blocks[2].x0_um | 1366.2 |  |  |
| blocks[2].y0_um | 0.0 |  |  |
| blocks[2].x1_um | 2049.3 |  |  |
| blocks[2].y1_um | 3332.32 |  |  |
| blocks[2].kind | cell |  |  |
| blocks[2].layer | active |  |  |
| blocks[2].provenance | assumed_engineering_parameter |  |  |
| blocks[2].accesses | 2024 |  |  |
| blocks[2].access_share | 0.253 |  |  |

## 11. Optimisation — goals A–E, Pareto frontier
4 distinct configuration(s) are the top choice for the 5 goals evaluated (a goal whose objective does not discriminate lists all tied candidates), and 6 distinct configurations win at least one per-workload latency/bandwidth ranking; 7 of 128 candidates are Pareto-optimal over ['latency', 'inv_bandwidth', 'area', 'energy']. No single configuration is optimal for every goal or workload.
- **Caveat:** AREA AXIS = SRAM macro footprint only (macro footprint only, family IHP_1P (comparison choice; vendor dimensions, not a die area): 2 x 4 x RM_IHPSG13_1P_4096x16_c3_bm_bist). Controller logic is NOT included (its only available mapped area is in a different process family) - see the synthesis section for logic cost; this is not a die area
- **Caveat:** energy axis is the parameter-free activity proxy (array bits activated per useful byte); it does not depend on bank size, so it cannot rank bank organisations - a validated energy profile is required
- **Caveat:** SECDED modelled as +1 cycle of bank read latency (measured on the RTL, data/ecc_study.json) and its stored-bit overhead in the macro-footprint area; partial-write read-modify-write and scrub bandwidth are not exercised by this suite (full-word writes only)

| goal | best candidate(s) |
|---|---|
| A_lowest_read_latency | banks=16/interleave=low/max_out=4/read_latency=1/word_bits=32/arbitration=round_robin/ecc=none |
| B_highest_useful_bandwidth | banks=16/interleave=low/max_out=4/read_latency=1/word_bits=128/arbitration=round_robin/ecc=none |
| C_lowest_area | banks=2/interleave=low/max_out=1/read_latency=1/word_bits=128/arbitration=round_robin/ecc=none (+7 tied) |
| D_lowest_energy_per_useful_byte_ACTIVITY_PROXY | banks=2/interleave=low/max_out=1/read_latency=1/word_bits=32/arbitration=round_robin/ecc=none (+127 tied) |
| E_balanced_ppa | banks=16/interleave=low/max_out=4/read_latency=1/word_bits=128/arbitration=round_robin/ecc=none |

Balanced-PPA winner under 200 random weightings: `banks=16/interleave=low/max_out=4/read_latency=1/word_bits=128/arbitration=round_robin/ecc=none` 170×, `banks=2/interleave=low/max_out=4/read_latency=1/word_bits=128/arbitration=round_robin/ecc=none` 27×, `banks=16/interleave=low/max_out=4/read_latency=1/word_bits=32/arbitration=round_robin/ecc=none` 3×

## 12. What this report does not claim
- No silicon, FPGA or board measurement exists for SilicaFlux; nothing here is `measured`.
- No clock frequency is claimed; cycles are exact for the modelled protocol, MB/s only appear under an explicitly assumed clock.
- No pJ/access, mW or temperature is reported unless a validated profile/model with provenance was supplied (see §9–§10).
- Die area is reported only where real macro manifests and (for logic) a real library were available; otherwise it is `unavailable`.
- MBIST coverage is coverage of the *injected simulation fault model*, not manufacturing defect coverage.
- OpenROAD / OpenSTA are not installed: no timing-closure or placed-and-routed result is claimed.
