/* SRAMLab dashboard: hand-written SVG chart helpers (line, grouped bar + CI whiskers, histogram, scatter, heatmap,
   stacked bar).  No smoothing, no extrapolation: lines join the plotted points with straight segments only. */
(function () {
  'use strict';
  var SF = window.SF, h = SF.h, s = SF.s;
  var uid = 0;

  // ------------------------------------------------------------------ scales and ticks
  function niceStep(raw) {
    var p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p;
    return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p;
  }
  SF.niceTicks = function (lo, hi, count) {
    count = count || 5;
    if (!isFinite(lo) || !isFinite(hi)) { lo = 0; hi = 1; }
    if (hi === lo) { var pad = Math.abs(hi) * 0.1 || 1; lo -= pad; hi += pad; }
    var step = niceStep((hi - lo) / count);
    var a = Math.floor(lo / step + 1e-9) * step, b = Math.ceil(hi / step - 1e-9) * step, t = [];
    for (var v = a; v <= b + step * 1e-6; v += step) t.push(Number(v.toPrecision(12)));
    return { min: a, max: b, ticks: t, step: step };
  };
  function tickFmt(step) {
    return function (v) {
      var d = 0;
      while (d < 6 && Math.abs(step * Math.pow(10, d) - Math.round(step * Math.pow(10, d))) > 1e-7) d++;
      if (Math.abs(v) >= 1e4 && step >= 1) return v.toLocaleString('en-US');
      return v.toFixed(d);
    };
  }
  var CHW = 6.3;   // approx px per character of 11.5px text

  // ------------------------------------------------------------------ frame: svg + axes
  // o: width,height, xs {type:'linear'|'log2'|'band', domain, ticks, cats, label, fmt}, ys {domain, ticks, label, fmt}, aria
  function frame(host, o) {
    var W = o.width || SF.width(host);
    var H = o.height || Math.round(Math.max(220, Math.min(380, W * 0.5)));
    var ys = o.ys, xs = o.xs;
    var yt = ys.ticks;
    var yfmt = ys.fmt || tickFmt(yt.length > 1 ? yt[1] - yt[0] : 1);
    var ylab = Math.max.apply(null, yt.map(function (v) { return yfmt(v).length; })) * CHW;
    var m = Object.assign({ t: 14, r: 14, b: 44, l: Math.ceil(ylab + 30 + (ys.label ? 6 : 0)) }, o.margin || {});
    var plot = { x: m.l, y: m.t, w: Math.max(60, W - m.l - m.r), h: 0 };
    // rotated band labels need more bottom room
    var rotate = false;
    if (xs.type === 'band') {
      var longest = Math.max.apply(null, xs.cats.map(function (c) { return String(c).length; })) * CHW + 10;
      rotate = longest > plot.w / xs.cats.length;
      if (rotate) m.b += Math.min(70, Math.ceil(longest * 0.55));
    }
    plot.h = Math.max(80, H - m.t - m.b);
    H = plot.h + m.t + m.b;
    var id = 'sf' + (++uid);
    var svg = s('svg', { viewBox: '0 0 ' + W + ' ' + H, width: W, height: H, role: 'img', 'aria-label': o.aria || '', focusable: 'false' });
    var defs = s('defs');
    svg.appendChild(defs);
    var gGrid = s('g', { class: 'grid' }), gAxis = s('g', { class: 'axis' }), gMarks = s('g'), gOver = s('g', { 'pointer-events': 'none' });
    svg.appendChild(gGrid); svg.appendChild(gAxis); svg.appendChild(gMarks); svg.appendChild(gOver);

    var y0 = ys.domain[0], y1 = ys.domain[1];
    function Y(v) { return plot.y + plot.h - (v - y0) / (y1 - y0) * plot.h; }
    var X, bw = 0;
    if (xs.type === 'band') {
      bw = plot.w / xs.cats.length;
      X = function (i) { return plot.x + bw * (i + 0.5); };
    } else if (xs.type === 'log2') {
      var l0 = Math.log2(xs.domain[0]), l1 = Math.log2(xs.domain[1]);
      X = function (v) { return plot.x + (l1 === l0 ? 0.5 : (Math.log2(v) - l0) / (l1 - l0)) * plot.w; };
    } else {
      var x0 = xs.domain[0], x1 = xs.domain[1];
      X = function (v) { return plot.x + (x1 === x0 ? 0.5 : (v - x0) / (x1 - x0)) * plot.w; };
    }
    // y grid + ticks
    yt.forEach(function (v) {
      var yy = Y(v);
      gGrid.appendChild(s('line', { x1: plot.x, x2: plot.x + plot.w, y1: yy, y2: yy }));
      gAxis.appendChild(s('text', { x: plot.x - 8, y: yy + 4, 'text-anchor': 'end', text: yfmt(v) }));
    });
    gAxis.appendChild(s('line', { x1: plot.x, x2: plot.x + plot.w, y1: plot.y + plot.h, y2: plot.y + plot.h }));
    gAxis.appendChild(s('line', { x1: plot.x, x2: plot.x, y1: plot.y, y2: plot.y + plot.h }));
    // x ticks
    var xfmt = xs.fmt || function (v) { return String(v); };
    if (xs.type === 'band') {
      xs.cats.forEach(function (c, i) {
        var cx = X(i), ty = plot.y + plot.h + 16;
        var t = s('text', { x: cx, y: ty, 'text-anchor': rotate ? 'end' : 'middle', text: String(c) });
        if (rotate) t.setAttribute('transform', 'rotate(-35 ' + cx + ' ' + ty + ')');
        gAxis.appendChild(t);
        gAxis.appendChild(s('line', { x1: cx, x2: cx, y1: plot.y + plot.h, y2: plot.y + plot.h + 4 }));
      });
    } else {
      (xs.ticks || []).forEach(function (v) {
        var cx = X(v);
        gAxis.appendChild(s('line', { x1: cx, x2: cx, y1: plot.y + plot.h, y2: plot.y + plot.h + 4 }));
        gAxis.appendChild(s('text', { x: cx, y: plot.y + plot.h + 17, 'text-anchor': 'middle', text: xfmt(v) }));
      });
    }
    if (xs.label) gAxis.appendChild(s('text', { class: 'axl', x: plot.x + plot.w / 2, y: H - 6, 'text-anchor': 'middle', text: xs.label }));
    if (ys.label) gAxis.appendChild(s('text', { class: 'axl', transform: 'rotate(-90)', x: -(plot.y + plot.h / 2), y: 13, 'text-anchor': 'middle', text: ys.label }));
    return { svg: svg, defs: defs, plot: plot, X: X, Y: Y, bw: bw, W: W, H: H, marks: gMarks, over: gOver, grid: gGrid, axis: gAxis, id: id };
  }
  SF.frame = frame;

  function hatchPattern(fr, color, key) {
    var pid = fr.id + '-h-' + key;
    fr.defs.appendChild(s('pattern', { id: pid, width: 6, height: 6, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' },
      s('rect', { width: 6, height: 6, fill: color, 'fill-opacity': 0.10 }),
      s('line', { x1: 0, y1: 0, x2: 0, y2: 6, stroke: color, 'stroke-width': 2.2 })));
    return 'url(#' + pid + ')';
  }

  // ------------------------------------------------------------------ interaction (hover + keyboard)
  // items: [{x, y, rx, ry, rw, rh, tip(): Node, hl(layer)}]; o: {mode:'x'|'nearest'|'rect', plot, layer, radius, stride, aria}
  SF.interact = function (fr, items, o) {
    var svg = fr.svg, layer = fr.over;
    o = o || {};
    var cur = -1;
    function toSvg(e) {
      var r = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal, k = vb.width / (r.width || vb.width);
      return { x: (e.clientX - r.left) * k, y: (e.clientY - r.top) * k };
    }
    function fromSvg(x, y) {
      var r = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal, k = r.width / vb.width;
      return { x: r.left + x * k, y: r.top + y * k };
    }
    function pick(p) {
      var best = -1, bd = Infinity, pl = fr.plot;
      if (o.mode === 'x' && (p.y < pl.y - 6 || p.y > pl.y + pl.h + 6 || p.x < pl.x - 24 || p.x > pl.x + pl.w + 24)) return -1;
      for (var i = 0; i < items.length; i++) {
        var it = items[i], d;
        if (o.mode === 'x') d = Math.abs(p.x - it.x);
        else if (o.mode === 'rect') d = (p.x >= it.rx && p.x <= it.rx + it.rw && p.y >= it.ry && p.y <= it.ry + it.rh) ? 0 : Infinity;
        else d = Math.hypot(p.x - it.x, p.y - it.y);
        if (d < bd) { bd = d; best = i; }
      }
      if (o.mode !== 'x' && bd > (o.mode === 'rect' ? 0 : (o.radius || 30))) return -1;
      return best;
    }
    function setCur(i, e) {
      if (i !== cur) {
        cur = i; SF.clear(layer);
        if (i >= 0 && items[i].hl) items[i].hl(layer);
      }
      if (i < 0) { SF.tip.hide(); return; }
      var c = e ? { x: e.clientX, y: e.clientY } : fromSvg(items[i].x, items[i].y);
      SF.tip.show(items[i].tip(), c.x, c.y);
    }
    svg.setAttribute('tabindex', '0');
    svg.setAttribute('role', 'group');
    svg.setAttribute('aria-label', (svg.getAttribute('aria-label') || '') + ' - use the arrow keys to step through values; a table view follows the chart.');
    svg.classList.add('focusable');
    svg.addEventListener('pointermove', function (e) { setCur(pick(toSvg(e)), e); });
    svg.addEventListener('pointerdown', function (e) { setCur(pick(toSvg(e)), e); });
    svg.addEventListener('pointerleave', function () { setCur(-1); });
    svg.addEventListener('focus', function () { if (cur < 0 && items.length) setCur(0, null); });
    svg.addEventListener('blur', function () { setCur(-1); });
    svg.addEventListener('keydown', function (e) {
      var n = items.length, st = o.stride || 1, k = e.key, i = cur < 0 ? 0 : cur, j = i;
      if (k === 'ArrowRight') j = i + 1; else if (k === 'ArrowLeft') j = i - 1;
      else if (k === 'ArrowDown') j = i + st; else if (k === 'ArrowUp') j = i - st;
      else if (k === 'Home') j = 0; else if (k === 'End') j = n - 1;
      else if (k === 'Escape') { setCur(-1); return; }
      else return;
      e.preventDefault();
      if (j >= 0 && j < n) setCur(j, null);
    });
  };

  // ------------------------------------------------------------------ line chart (error bars = 95% CI half-widths)
  // o.series: [{id,name,color,marker,dash,sub,pts:[{x,y,hw,n}]}]; o.refLines: [{y,label,dash,color}]
  SF.lineChart = function (host, o) {
    var xsAll = SF.sortNum(SF.uniq([].concat.apply([], o.series.map(function (sr) { return sr.pts.filter(function (p) { return SF.isNum(p.y); }).map(function (p) { return p.x; }); }))));
    var ymax = 0, ymin = Infinity;
    o.series.forEach(function (sr) { sr.pts.forEach(function (p) { if (SF.isNum(p.y)) { ymax = Math.max(ymax, p.y + (p.hw || 0)); ymin = Math.min(ymin, p.y - (p.hw || 0)); } }); });
    (o.refLines || []).forEach(function (r) { if (SF.isNum(r.y)) { ymax = Math.max(ymax, r.y); ymin = Math.min(ymin, r.y); } });
    if (!isFinite(ymax)) { ymax = 1; ymin = 0; }
    var lo = o.yMin !== undefined ? o.yMin : (o.zero === false ? ymin : 0);
    var hi = o.yMax !== undefined ? o.yMax : ymax * 1.06;
    var nt = SF.niceTicks(lo, hi, o.yTickCount || 5);
    if (o.yMax !== undefined) { nt = { min: lo, max: hi, ticks: nt.ticks.filter(function (t) { return t >= lo - 1e-9 && t <= hi + 1e-9; }) }; }
    else if (o.yMin !== undefined) { nt.min = lo; nt.ticks = nt.ticks.filter(function (t) { return t >= lo - 1e-9; }); }
    var type = o.xType || 'log2';
    var xmin = xsAll.length ? xsAll[0] : 1, xmax = xsAll.length ? xsAll[xsAll.length - 1] : 2;
    var dom;
    if (type === 'log2') { dom = [xmin / Math.pow(2, 0.35), xmax * Math.pow(2, 0.35)]; if (xmin === xmax) dom = [xmin / 2, xmax * 2]; }
    else { var padx = (xmax - xmin) * 0.06 || 1; dom = [xmin - padx, xmax + padx]; }
    var fr = frame(host, { width: o.width, height: o.height, aria: o.aria, margin: o.margin,
      xs: { type: type, domain: dom, ticks: o.xTicks || xsAll, label: o.xLabel, fmt: o.xFmt },
      ys: { domain: [nt.min, nt.max], ticks: nt.ticks, label: o.yLabel, fmt: o.yFmt } });
    var pl = fr.plot;
    // reference lines (analytical ceilings): dashed, labelled
    (o.refLines || []).forEach(function (r) {
      if (!SF.isNum(r.y)) return;
      var yy = fr.Y(r.y), col = r.color || SF.SILVER;
      fr.marks.appendChild(s('line', { x1: pl.x, x2: pl.x + pl.w, y1: yy, y2: yy, stroke: col, 'stroke-width': 1.6, 'stroke-dasharray': r.dash || '7 5' }));
      if (r.label && r.label.length * CHW < pl.w - 14) fr.marks.appendChild(s('text', { x: r.anchor === 'start' ? pl.x + 6 : pl.x + pl.w - 4, y: yy - 5, 'text-anchor': r.anchor === 'start' ? 'start' : 'end', class: 'mut', text: r.label }));
    });
    o.series.forEach(function (sr) {
      var col = sr.color, seg = [];
      function flush() {
        if (seg.length > 1) fr.marks.appendChild(s('path', { d: 'M' + seg.map(function (p) { return p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join('L'), fill: 'none', stroke: col, 'stroke-width': sr.width || 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round', 'stroke-dasharray': sr.dash || null }));
        seg = [];
      }
      sr.pts.slice().sort(function (a, b) { return a.x - b.x; }).forEach(function (p) {
        if (!SF.isNum(p.y)) { flush(); return; }
        seg.push([fr.X(p.x), fr.Y(p.y)]);
      });
      flush();
      sr.pts.forEach(function (p) {
        if (!SF.isNum(p.y)) return;
        var cx = fr.X(p.x), cy = fr.Y(p.y);
        if (SF.isNum(p.hw) && p.hw > 0) {
          var a = fr.Y(p.y + p.hw), b = fr.Y(Math.max(nt.min, p.y - p.hw));
          fr.marks.appendChild(s('path', { d: 'M' + cx + ' ' + a + 'V' + b + 'M' + (cx - 4) + ' ' + a + 'H' + (cx + 4) + 'M' + (cx - 4) + ' ' + b + 'H' + (cx + 4), stroke: col, 'stroke-width': 1.5, fill: 'none' }));
        }
        if (sr.marker && !sr.dash) fr.marks.appendChild(SF.markerEl(sr.marker, cx, cy, 4.5, col));
      });
    });
    var items = xsAll.map(function (xv) {
      return {
        x: fr.X(xv), y: pl.y + pl.h / 2,
        tip: function () {
          var rows = [];
          o.series.forEach(function (sr) {
            var p = sr.pts.filter(function (q) { return q.x === xv; })[0];
            if (!p) return;
            var val = SF.isNum(p.y) ? SF.fmt(p.y, 4) + (SF.isNum(p.hw) ? ' ± ' + SF.fmt(p.hw, 2) : '') + (o.unit ? ' ' + o.unit : '') + (SF.isNum(p.n) ? ' (n=' + p.n + ')' : '') : 'unavailable';
            rows.push({ k: sr.name, v: val, key: { color: sr.color, dash: sr.dash, marker: sr.dash ? null : sr.marker } });
          });
          (o.refLines || []).forEach(function (r) { if (SF.isNum(r.y) && r.tip !== false) rows.push({ k: r.label || 'reference', v: SF.fmt(r.y, 4), key: { color: r.color || SF.SILVER, dash: r.dash || '7 5' } }); });
          return SF.tipContent((o.xTip ? o.xTip(xv) : (o.xLabel ? o.xLabel.split(' (')[0] + ' = ' : '') + (o.xFmt ? o.xFmt(xv) : xv)), rows, o.tipFoot);
        },
        hl: function (layer) {
          layer.appendChild(s('line', { x1: fr.X(xv), x2: fr.X(xv), y1: pl.y, y2: pl.y + pl.h, stroke: '#e8edf6', 'stroke-opacity': 0.55, 'stroke-width': 1 }));
          o.series.forEach(function (sr) {
            var p = sr.pts.filter(function (q) { return q.x === xv; })[0];
            if (p && SF.isNum(p.y)) layer.appendChild(s('circle', { cx: fr.X(xv), cy: fr.Y(p.y), r: 8, fill: 'none', stroke: '#e8edf6', 'stroke-width': 1.5 }));
          });
        }
      };
    });
    SF.interact(fr, items, { mode: 'x' });
    host.appendChild(h('div', { class: 'chart' }, fr.svg));
    if (o.legend !== false) host.appendChild(SF.legend(o.series.map(function (sr) { return { name: sr.name, sub: sr.sub, color: sr.color, dash: sr.dash, marker: sr.dash ? null : sr.marker }; })
      .concat((o.refLines || []).filter(function (r) { return r.legend; }).map(function (r) { return { name: r.legend, color: r.color || SF.SILVER, dash: r.dash || '7 5' }; }))));
    return fr;
  };

  // ------------------------------------------------------------------ grouped bars (CI whiskers, analytical = hatched)
  // o.cats: [label]; o.series: [{id,name,color,hatch,vals:[{y,hw,n}|number|null]}]
  SF.groupedBars = function (host, o) {
    var ymax = 0;
    o.series.forEach(function (sr) { sr.vals.forEach(function (v) { var st = SF.stat(v); if (st.m !== null) ymax = Math.max(ymax, st.m + (st.hw || 0)); }); });
    (o.refLines || []).forEach(function (r) { if (SF.isNum(r.y)) ymax = Math.max(ymax, r.y); });
    var hi = o.yMax !== undefined ? o.yMax : (ymax || 1) * 1.08;
    var nt = SF.niceTicks(0, hi, o.yTickCount || 5);
    var dom = o.yMax !== undefined ? [0, o.yMax] : [0, nt.max];
    var ticks = o.yMax !== undefined ? nt.ticks.filter(function (t) { return t <= o.yMax + 1e-9; }) : nt.ticks;
    var fr = frame(host, { width: o.width, height: o.height, aria: o.aria, margin: o.margin,
      xs: { type: 'band', cats: o.cats, label: o.xLabel }, ys: { domain: dom, ticks: ticks, label: o.yLabel, fmt: o.yFmt } });
    var pl = fr.plot, ns = o.series.length;
    var bar = Math.max(4, Math.min(24, Math.floor((fr.bw * 0.78) / ns) - 2));
    var gw = ns * bar + (ns - 1) * 2;
    var items = [];
    (o.refLines || []).forEach(function (r) {
      if (!SF.isNum(r.y)) return;
      var yy = fr.Y(r.y);
      fr.marks.appendChild(s('line', { x1: pl.x, x2: pl.x + pl.w, y1: yy, y2: yy, stroke: r.color || SF.SILVER, 'stroke-width': 1.6, 'stroke-dasharray': r.dash || '7 5' }));
      if (r.label && r.label.length * CHW < pl.w - 14) fr.marks.appendChild(s('text', { x: r.anchor === 'start' ? pl.x + 6 : pl.x + pl.w - 4, y: yy - 5, 'text-anchor': r.anchor === 'start' ? 'start' : 'end', class: 'mut', text: r.label }));
    });
    o.cats.forEach(function (cat, ci) {
      var cx = fr.X(ci), left = cx - gw / 2;
      var tipRows = [];
      o.series.forEach(function (sr, si) {
        var st = SF.stat(sr.vals[ci]);
        var bx = left + si * (bar + 2);
        if (st.m !== null) {
          var top = fr.Y(Math.max(0, st.m)), base = fr.Y(0), ht = Math.max(0, base - top);
          var r = Math.min(4, ht, bar / 2);
          var fill = sr.hatch ? hatchPattern(fr, sr.color, sr.id || si) : sr.color;
          var d = ht <= 0.5 ? '' : 'M' + bx + ' ' + base + 'V' + (top + r) + 'Q' + bx + ' ' + top + ' ' + (bx + r) + ' ' + top + 'H' + (bx + bar - r) + 'Q' + (bx + bar) + ' ' + top + ' ' + (bx + bar) + ' ' + (top + r) + 'V' + base + 'Z';
          if (d) fr.marks.appendChild(s('path', { d: d, fill: fill, stroke: sr.hatch ? sr.color : 'none', 'stroke-width': sr.hatch ? 1.4 : 0, 'stroke-dasharray': sr.hatch ? '5 3' : null }));
          else fr.marks.appendChild(s('line', { x1: bx, x2: bx + bar, y1: base, y2: base, stroke: sr.color, 'stroke-width': 2 }));
          if (SF.isNum(st.hw) && st.hw > 0) {
            var ey1 = fr.Y(st.m + st.hw), ey2 = fr.Y(Math.max(0, st.m - st.hw)), mx = bx + bar / 2;
            fr.marks.appendChild(s('path', { d: 'M' + mx + ' ' + ey1 + 'V' + ey2 + 'M' + (mx - 4) + ' ' + ey1 + 'H' + (mx + 4) + 'M' + (mx - 4) + ' ' + ey2 + 'H' + (mx + 4), stroke: '#e8edf6', 'stroke-width': 1.5, fill: 'none', 'stroke-opacity': 0.9 }));
          }
          if (o.valueLabels && bar >= 14 && ns <= 2 && SF.fmt(st.m, 3).length * CHW <= bar + 6) {
            fr.marks.appendChild(s('text', { x: bx + bar / 2, y: fr.Y(st.m + (st.hw || 0)) - 5, 'text-anchor': 'middle', text: SF.fmt(st.m, 3) }));
          }
        }
        if (st.m === null) fr.marks.appendChild(s('text', { x: bx + bar / 2, y: fr.Y(0) - 5, 'text-anchor': 'middle', class: 'mut', style: 'fill:#98a3bd;font-size:10.5px', text: 'n/a' }));
        tipRows.push({ k: sr.name, v: st.m === null ? 'unavailable (not applicable or not recorded)' : SF.fmt(st.m, 4) + (st.hw !== null ? ' ± ' + SF.fmt(st.hw, 2) : '') + (o.unit ? ' ' + o.unit : '') + (st.n !== null ? ' (n=' + st.n + ')' : ''), key: { kind: 'bar', color: sr.color, hatch: sr.hatch } });
      });
      items.push({ x: cx, y: pl.y + pl.h / 2, rx: cx - fr.bw / 2, ry: pl.y, rw: fr.bw, rh: pl.h,
        tip: function () { return SF.tipContent(String(cat), tipRows, o.tipFoot); },
        hl: function (layer) { layer.appendChild(s('rect', { x: cx - fr.bw / 2 + 1, y: pl.y, width: fr.bw - 2, height: pl.h, fill: '#e8edf6', 'fill-opacity': 0.06, stroke: '#e8edf6', 'stroke-opacity': 0.4 })); } });
    });
    SF.interact(fr, items, { mode: 'rect' });
    host.appendChild(h('div', { class: 'chart' }, fr.svg));
    if (o.legend !== false && ns > 1) host.appendChild(SF.legend(o.series.map(function (sr) { return { name: sr.name, sub: sr.sub, kind: 'bar', color: sr.color, hatch: sr.hatch }; })
      .concat((o.refLines || []).filter(function (r) { return r.legend; }).map(function (r) { return { name: r.legend, color: r.color || SF.SILVER, dash: r.dash || '7 5' }; }))));
    return fr;
  };

  // ------------------------------------------------------------------ stacked bars (2px surface gap between segments)
  SF.stackedBars = function (host, o) {
    var tot = o.cats.map(function (_, ci) { return o.series.reduce(function (a, sr) { return a + (SF.isNum(sr.vals[ci]) ? sr.vals[ci] : 0); }, 0); });
    var nt = SF.niceTicks(0, Math.max.apply(null, tot.concat([1e-9])) * 1.06, 5);
    var fr = frame(host, { width: o.width, height: o.height, aria: o.aria,
      xs: { type: 'band', cats: o.cats, label: o.xLabel }, ys: { domain: [0, nt.max], ticks: nt.ticks, label: o.yLabel, fmt: o.yFmt } });
    var pl = fr.plot, bar = Math.max(8, Math.min(40, fr.bw * 0.5)), items = [];
    o.cats.forEach(function (cat, ci) {
      var cx = fr.X(ci), acc = 0, rows = [];
      o.series.forEach(function (sr, si) {
        var v = sr.vals[ci];
        if (!SF.isNum(v) || v <= 0) { rows.push({ k: sr.name, v: SF.isNum(v) ? '0' : 'unavailable', key: { kind: 'bar', color: sr.color, hatch: sr.hatch } }); return; }
        var y1 = fr.Y(acc), y2 = fr.Y(acc + v);
        var top = y2 + (si > 0 ? 1 : 0), ht = Math.max(0.5, y1 - top - (si > 0 ? 1 : 0));
        var last = !o.series.slice(si + 1).some(function (z) { return SF.isNum(z.vals[ci]) && z.vals[ci] > 0; });
        var fill = sr.hatch ? hatchPattern(fr, sr.color, sr.id || si) : sr.color;
        var x = cx - bar / 2, r = last ? Math.min(4, ht) : 0;
        var d = 'M' + x + ' ' + (top + ht) + 'V' + (top + r) + (r ? 'Q' + x + ' ' + top + ' ' + (x + r) + ' ' + top + 'H' + (x + bar - r) + 'Q' + (x + bar) + ' ' + top + ' ' + (x + bar) + ' ' + (top + r) : 'V' + top + 'H' + (x + bar)) + 'V' + (top + ht) + 'Z';
        fr.marks.appendChild(s('path', { d: d, fill: fill, stroke: sr.hatch ? sr.color : 'none', 'stroke-width': sr.hatch ? 1.2 : 0 }));
        rows.push({ k: sr.name, v: SF.fmt(v, 4) + (o.unit ? ' ' + o.unit : ''), key: { kind: 'bar', color: sr.color, hatch: sr.hatch } });
        acc += v;
      });
      rows.push({ k: 'total', v: SF.fmt(tot[ci], 4) + (o.unit ? ' ' + o.unit : '') });
      items.push({ x: cx, y: pl.y + pl.h / 2, rx: cx - fr.bw / 2, ry: pl.y, rw: fr.bw, rh: pl.h, tip: function () { return SF.tipContent(String(cat), rows, o.tipFoot); },
        hl: function (layer) { layer.appendChild(s('rect', { x: cx - fr.bw / 2 + 1, y: pl.y, width: fr.bw - 2, height: pl.h, fill: '#e8edf6', 'fill-opacity': 0.06, stroke: '#e8edf6', 'stroke-opacity': 0.4 })); } });
    });
    SF.interact(fr, items, { mode: 'rect' });
    host.appendChild(h('div', { class: 'chart' }, fr.svg));
    if (o.series.length > 1) host.appendChild(SF.legend(o.series.map(function (sr) { return { name: sr.name, sub: sr.sub, kind: 'bar', color: sr.color, hatch: sr.hatch }; })));
    return fr;
  };

  // ------------------------------------------------------------------ histogram with marker lines
  // o.bins: [{x, y}] (integer x); o.markers: [{x, hw, label, dash, color}]; y is a fraction or a count
  SF.histogram = function (host, o) {
    var xs = o.bins.map(function (b) { return b.x; });
    var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs);
    (o.markers || []).forEach(function (m) { if (SF.isNum(m.x)) { x0 = Math.min(x0, Math.floor(m.x - (m.hw || 0))); x1 = Math.max(x1, Math.ceil(m.x + (m.hw || 0))); } });
    var ymax = Math.max.apply(null, o.bins.map(function (b) { return b.y; }).concat([1e-9]));
    var nt = SF.niceTicks(0, ymax * 1.1, 5);
    var span = x1 - x0 + 1;
    var xt = []; var stepx = Math.max(1, Math.ceil(span / 14));
    for (var v = x0; v <= x1; v += stepx) xt.push(v);
    var fr = frame(host, { width: o.width, height: o.height, aria: o.aria,
      xs: { type: 'linear', domain: [x0 - 0.6, x1 + 0.6], ticks: xt, label: o.xLabel }, ys: { domain: [0, nt.max], ticks: nt.ticks, label: o.yLabel, fmt: o.yFmt } });
    var pl = fr.plot, slot = pl.w / (span + 1.2), bar = Math.max(3, Math.min(24, slot * 0.78)), items = [];
    var byX = {}; o.bins.forEach(function (b) { byX[b.x] = b; });
    for (var xv = x0; xv <= x1; xv++) {
      (function (xv) {
        var b = byX[xv] || { x: xv, y: 0, count: 0 };
        var cx = fr.X(xv), top = fr.Y(b.y), base = fr.Y(0), ht = base - top, r = Math.min(4, ht, bar / 2);
        if (ht > 0.4) fr.marks.appendChild(s('path', { d: 'M' + (cx - bar / 2) + ' ' + base + 'V' + (top + r) + 'Q' + (cx - bar / 2) + ' ' + top + ' ' + (cx - bar / 2 + r) + ' ' + top + 'H' + (cx + bar / 2 - r) + 'Q' + (cx + bar / 2) + ' ' + top + ' ' + (cx + bar / 2) + ' ' + (top + r) + 'V' + base + 'Z', fill: o.color || SF.PAL[0], 'fill-opacity': 0.92 }));
        items.push({ x: cx, y: top, rx: cx - slot / 2, ry: pl.y, rw: slot, rh: pl.h,
          tip: function () { return SF.tipContent(o.xName + ' = ' + xv, [{ k: o.yName, v: o.yFmtTip ? o.yFmtTip(b) : SF.fmt(b.y, 4), key: { kind: 'bar', color: o.color || SF.PAL[0] } }].concat(b.count !== undefined ? [{ k: 'responses', v: SF.fmt(b.count) }] : []), o.tipFoot); },
          hl: function (layer) { layer.appendChild(s('rect', { x: cx - slot / 2, y: pl.y, width: slot, height: pl.h, fill: '#e8edf6', 'fill-opacity': 0.06, stroke: '#e8edf6', 'stroke-opacity': 0.4 })); } });
      })(xv);
    }
    (o.markers || []).forEach(function (m, mi) {
      if (!SF.isNum(m.x)) return;
      var cx = fr.X(m.x), col = m.color || '#e8edf6';
      if (SF.isNum(m.hw) && m.hw > 0) fr.marks.appendChild(s('rect', { x: fr.X(m.x - m.hw), y: pl.y, width: Math.max(1, fr.X(m.x + m.hw) - fr.X(m.x - m.hw)), height: pl.h, fill: col, 'fill-opacity': 0.14 }));
      fr.marks.appendChild(s('line', { x1: cx, x2: cx, y1: pl.y, y2: pl.y + pl.h, stroke: col, 'stroke-width': 2, 'stroke-dasharray': m.dash || null }));
      var anchor = cx > pl.x + pl.w * 0.72 ? 'end' : 'start';
      fr.marks.appendChild(s('text', { x: cx + (anchor === 'end' ? -6 : 6), y: pl.y + 13 + mi * 15, 'text-anchor': anchor, class: 'ttl', text: m.label }));
    });
    SF.interact(fr, items, { mode: 'rect' });
    host.appendChild(h('div', { class: 'chart' }, fr.svg));
    if (o.markers && o.markers.length) host.appendChild(SF.legend([{ name: o.legendName || 'fraction', kind: 'bar', color: o.color || SF.PAL[0] }].concat(o.markers.filter(function (m) { return SF.isNum(m.x); }).map(function (m) { return { name: m.legend || m.label, color: m.color || '#e8edf6', dash: m.dash }; }))));
    return fr;
  };

  // ------------------------------------------------------------------ scatter
  // o.points: [{x,y,fill,shape,r,ring,tip:()=>Node}]
  SF.scatter = function (host, o) {
    var pts = o.points.filter(function (p) { return SF.isNum(p.x) && SF.isNum(p.y); });
    var xlo = Math.min.apply(null, pts.map(function (p) { return p.x; })), xhi = Math.max.apply(null, pts.map(function (p) { return p.x; }));
    var ylo = Math.min.apply(null, pts.map(function (p) { return p.y; })), yhi = Math.max.apply(null, pts.map(function (p) { return p.y; }));
    var ntx = SF.niceTicks(xlo - (xhi - xlo) * 0.04, xhi + (xhi - xlo) * 0.04, 6), nty = SF.niceTicks(ylo - (yhi - ylo) * 0.05, yhi + (yhi - ylo) * 0.05, 5);
    var fr = frame(host, { width: o.width, height: o.height || Math.round(Math.max(280, Math.min(460, (o.width || SF.width(host)) * 0.55))), aria: o.aria, margin: o.margin,
      xs: { type: 'linear', domain: [ntx.min, ntx.max], ticks: ntx.ticks, label: o.xLabel, fmt: tickFmt(ntx.step) }, ys: { domain: [nty.min, nty.max], ticks: nty.ticks, label: o.yLabel } });
    var items = [];
    // draw non-highlighted first so highlighted points sit on top
    var order = pts.slice().sort(function (a, b) { return (a.ring ? 1 : 0) - (b.ring ? 1 : 0); });
    order.forEach(function (p) {
      var cx = fr.X(p.x), cy = fr.Y(p.y), r = p.r || 5;
      if (p.ring) fr.marks.appendChild(s('circle', { cx: cx, cy: cy, r: r + 5, fill: 'none', stroke: '#d4af37', 'stroke-width': 2 }));
      fr.marks.appendChild(SF.markerEl(p.shape || 'circle', cx, cy, r, p.fill, { stroke: p.ring ? SF.SURFACE : SF.SILVER, 'stroke-width': p.ring ? 2 : 1.2 }));
      items.push({ x: cx, y: cy, tip: p.tip, hl: function (layer) { layer.appendChild(s('circle', { cx: cx, cy: cy, r: r + 9, fill: 'none', stroke: '#e8edf6', 'stroke-width': 1.5 })); } });
    });
    SF.interact(fr, items, { mode: 'nearest', radius: 26 });
    host.appendChild(h('div', { class: 'chart' }, fr.svg));
    return fr;
  };

  // ------------------------------------------------------------------ heatmap
  // single-hue sequential ramp (dark navy -> cyan -> near white): lightness rises with magnitude
  var STOPS = [[0, [22, 41, 90]], [0.45, [10, 110, 150]], [0.8, [0, 200, 230]], [1, [190, 248, 255]]];
  SF.ramp = function (t) {
    t = Math.max(0, Math.min(1, t));
    for (var i = 1; i < STOPS.length; i++) {
      if (t <= STOPS[i][0]) {
        var a = STOPS[i - 1], b = STOPS[i], u = (t - a[0]) / (b[0] - a[0]);
        return [0, 1, 2].map(function (k) { return Math.round(a[1][k] + (b[1][k] - a[1][k]) * u); });
      }
    }
    return STOPS[STOPS.length - 1][1];
  };
  function rgb(c) { return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'; }
  function lum(c) { return (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255; }
  // o: rows[], cols[], vals[r][c], vmin, vmax, fmt(v), valueName, xLabel, yLabel, tip(r,c)
  SF.heatmap = function (host, o) {
    var W = o.width || SF.width(host), nr = o.rows.length, nc = o.cols.length;
    var lw = Math.max.apply(null, o.rows.map(function (r) { return String(r).length; })) * CHW + 18 + (o.yLabel ? 16 : 0);
    var cbH = 46;
    var m = { t: 10, r: 14, b: 40 + cbH, l: Math.ceil(lw) };
    var cw = Math.max(18, Math.min(150, (W - m.l - m.r) / nc)), chh = o.cellH || 40;
    var pw = cw * nc, H = m.t + chh * nr + m.b;
    var svg = s('svg', { viewBox: '0 0 ' + W + ' ' + H, width: W, height: H, role: 'img', 'aria-label': o.aria || '', focusable: 'false' });
    var defs = s('defs'); svg.appendChild(defs);
    var hid = 'sfhm' + (++uid);
    defs.appendChild(s('pattern', { id: hid + 'na', width: 6, height: 6, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, s('rect', { width: 6, height: 6, fill: '#0a1128' }), s('line', { x1: 0, y1: 0, x2: 0, y2: 6, stroke: '#5b6a93', 'stroke-width': 1.5 })));
    var g = s('g'), over = s('g', { 'pointer-events': 'none' }), items = [];
    var vmin = o.vmin, vmax = o.vmax;
    o.rows.forEach(function (rl, r) {
      g.appendChild(s('text', { x: m.l - 8, y: m.t + r * chh + chh / 2 + 4, 'text-anchor': 'end', text: String(rl) }));
      o.cols.forEach(function (cl, c) {
        var v = o.vals[r][c], x = m.l + c * cw, y = m.t + r * chh, na = !SF.isNum(v);
        var t = na ? 0 : (vmax === vmin ? 0.5 : (v - vmin) / (vmax - vmin)), col = na ? null : SF.ramp(t);
        g.appendChild(s('rect', { x: x + 1, y: y + 1, width: cw - 2, height: chh - 2, rx: 3, fill: na ? 'url(#' + hid + 'na)' : rgb(col), stroke: na ? '#5b6a93' : 'none', 'stroke-dasharray': na ? '3 3' : null }));
        var txt = na ? 'n/a' : (o.fmt ? o.fmt(v) : SF.fmt(v, 2));
        if (txt.length * CHW + 6 < cw) g.appendChild(s('text', { x: x + cw / 2, y: y + chh / 2 + 4, 'text-anchor': 'middle', fill: na ? '#98a3bd' : (lum(col) > 0.5 ? '#06101f' : '#f4f7fb'), style: 'fill:' + (na ? '#98a3bd' : (lum(col) > 0.5 ? '#06101f' : '#f4f7fb')), text: txt }));
        items.push({ x: x + cw / 2, y: y + chh / 2, rx: x, ry: y, rw: cw, rh: chh, tip: function () { return o.tip(r, c, v); },
          hl: function (layer) { layer.appendChild(s('rect', { x: x + 0.5, y: y + 0.5, width: cw - 1, height: chh - 1, rx: 3, fill: 'none', stroke: '#e8edf6', 'stroke-width': 2 })); } });
      });
    });
    o.cols.forEach(function (cl, c) { g.appendChild(s('text', { x: m.l + c * cw + cw / 2, y: m.t + nr * chh + 16, 'text-anchor': 'middle', text: String(cl) })); });
    if (o.xLabel) g.appendChild(s('text', { class: 'axl', x: m.l + pw / 2, y: m.t + nr * chh + 34, 'text-anchor': 'middle', text: o.xLabel }));
    if (o.yLabel) g.appendChild(s('text', { class: 'axl', transform: 'rotate(-90)', x: -(m.t + nr * chh / 2), y: 13, 'text-anchor': 'middle', text: o.yLabel }));
    // colour bar
    var cbY = m.t + nr * chh + 50, cbW = Math.min(300, pw), steps = 40, cbX = m.l;
    var lg = s('linearGradient', { id: hid + 'g', x1: 0, x2: 1, y1: 0, y2: 0 });
    for (var i = 0; i <= steps; i++) lg.appendChild(s('stop', { offset: (i / steps * 100) + '%', 'stop-color': rgb(SF.ramp(i / steps)) }));
    defs.appendChild(lg);
    g.appendChild(s('rect', { x: cbX, y: cbY, width: cbW, height: 10, rx: 2, fill: 'url(#' + hid + 'g)' }));
    g.appendChild(s('text', { x: cbX, y: cbY + 24, text: (o.fmt ? o.fmt(vmin) : SF.fmt(vmin, 3)) }));
    g.appendChild(s('text', { x: cbX + cbW, y: cbY + 24, 'text-anchor': 'end', text: (o.fmt ? o.fmt(vmax) : SF.fmt(vmax, 3)) }));
    g.appendChild(s('text', { x: cbX + cbW / 2, y: cbY + 24, 'text-anchor': 'middle', class: 'mut', text: o.valueName || '' }));
    svg.appendChild(g); svg.appendChild(over);
    var fr = { svg: svg, over: over, plot: { x: m.l, y: m.t, w: pw, h: chh * nr } };
    SF.interact(fr, items, { mode: 'rect', stride: nc });
    host.appendChild(h('div', { class: 'chart' }, svg));
    return fr;
  };
})();
