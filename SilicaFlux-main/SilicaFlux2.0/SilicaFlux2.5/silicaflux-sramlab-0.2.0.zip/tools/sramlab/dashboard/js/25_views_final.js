/* Views 14 (Pareto frontier) and 15 (experiment history). */
(function () {
  'use strict';
  var SF = window.SF, h = SF.h, s = SF.s;
  var S = SF.state;

  // ================================================================== 14. Pareto frontier
  function numAt(o, k) { return o && SF.isNum(o[k]) ? o[k] : null; }
  function cands(O) { return Array.isArray(O && O.candidates) ? O.candidates.filter(function (c) { return c && SF.isNum(c.latency) && SF.isNum(c.bandwidth); }) : []; }
  function paramText(c) { var p = c.candidate; return p && typeof p === 'object' ? Object.keys(p).map(function (k) { return k + '=' + p[k]; }).join(', ') : String(c.id || ''); }
  function renderPareto(host, refresh) {
    var O = SF.DS.optimise;
    var cs = cands(O);
    if (!O || !cs.length) {
      host.appendChild(SF.unavailableCard('Pareto frontier of memory configurations', { why: O ? 'data/optimise.json is present but holds no candidates with both latency and bandwidth.' : SF.absentReason('optimise.json'),
        detail: 'Without an optimisation run there is no frontier to draw, and no configuration is recommended. SRAMLab never names one configuration as universally optimal.',
        unlocks: ['Run the optimisation experiment (sramlab optimise) so that data/optimise.json holds the evaluated candidates, their Pareto flags and the per-goal winners.'], source: 'data/optimise.json (sramlab.optimise.evaluate)' }));
      return;
    }
    if (!S.pf) S.pf = {};
    var st = S.pf;
    var hasArea = cs.every(function (c) { return c.area && SF.isNum(c.area.value); });
    var hasEnergy = cs.every(function (c) { return c.energy && SF.isNum(c.energy.value); });
    var opts = [];
    if (hasArea) opts.push({ v: 'area', t: 'Area' });
    opts.push({ v: 'energy', t: hasEnergy ? 'Energy per useful byte' : 'Energy proxy (bit activations per useful byte)' });
    opts.push({ v: 'balanced', t: 'Balanced score (lower is better)' });
    if (!st.color || !opts.some(function (o) { return o.v === st.color; })) st.color = opts[0].v;
    // statement + caveats verbatim
    var cv = SF.card({ title: 'Read this before using the front', provs: ['simulated'], source: 'data/optimise.json statement / caveats (verbatim)' });
    host.appendChild(cv.el);
    if (O.statement) cv.body.appendChild(h('blockquote', { style: { margin: '0 0 8px', padding: '8px 12px', borderLeft: '3px solid var(--gold)', background: 'var(--surface-2)', color: 'var(--text)' }, text: O.statement }));
    if (Array.isArray(O.caveats) && O.caveats.length) {
      cv.body.appendChild(h('div', { class: 'kicker', text: 'Caveats' }));
      cv.body.appendChild(h('ul', { style: { margin: '4px 0 0 1.1em', padding: 0, color: 'var(--warn)' } }, O.caveats.map(function (t) { return h('li', { text: String(t) }); })));
    } else cv.body.appendChild(SF.note('The optimisation record lists no caveats.'));
    host.appendChild(h('div', { style: { height: '16px' } }));
    host.appendChild(SF.controls(SF.select('pf-c', 'Colour points by', opts, st.color, function (v) { st.color = v; refresh(); })));
    var valueOf = function (c) {
      if (st.color === 'area') return c.area.value;
      if (st.color === 'energy') return hasEnergy ? c.energy.value : c.energy_proxy;
      return c.balanced_score;
    };
    var vals = cs.map(valueOf).filter(SF.isNum);
    var vmin = Math.min.apply(null, vals), vmax = Math.max.apply(null, vals);
    var colName = st.color === 'area' ? 'Area' + (cs[0].area && cs[0].area.label ? ' (' + cs[0].area.label + ')' : '') : st.color === 'energy' ? (hasEnergy ? 'Energy per useful byte' : 'Energy proxy: bit activations per useful byte') : 'Balanced score';
    var areaLabels = SF.uniq(cs.map(function (c) { return c.area && c.area.label ? c.area.label : null; }).filter(Boolean));
    var provs = ['simulated'];
    if (st.color === 'area' && areaLabels.length) areaLabels.forEach(function (l) { provs.push({ label: l, sub: 'area' }); });
    if (!hasArea) provs.push({ label: 'unavailable', sub: 'area not part of this front' });
    var c = SF.card({ title: 'Latency vs bandwidth (' + cs.length + ' candidates, ' + cs.filter(function (x) { return x.pareto; }).length + ' Pareto-optimal)', provs: provs,
      note: 'Best corner is top-left: low mean read latency, high useful bandwidth. Diamonds with a gold ring are Pareto-optimal over the axes listed in the record (' + (O.axes || []).join(', ') + '); circles are dominated. Point colour: ' + colName + '.' + (hasArea ? '' : ' Area is UNAVAILABLE for these candidates, so it is not a cost axis of this front.'),
      source: 'data/optimise.json candidates (suite-mean latency and bandwidth over the workload suite; ' + (O.n_candidates || cs.length) + ' candidates; area label as recorded)' });
    host.appendChild(c.el);
    var pts = cs.map(function (x) {
      var v = valueOf(x), t = SF.isNum(v) ? (vmax === vmin ? 0.5 : (v - vmin) / (vmax - vmin)) : null, col = t === null ? [91, 106, 147] : SF.ramp(0.3 + 0.7 * t);
      return { x: x.latency, y: x.bandwidth, fill: 'rgb(' + col.join(',') + ')', shape: x.pareto ? 'diamond' : 'circle', r: x.pareto ? 6 : 5, ring: !!x.pareto,
        tip: function () {
          var rows = [{ k: 'mean read latency', v: SF.fmt(x.latency, 4) + ' cycles' }, { k: 'useful bandwidth', v: SF.fmt(x.bandwidth, 4) + ' B/cycle' }, { k: 'energy proxy', v: SF.fmt(x.energy_proxy, 4) + ' bit act./B' },
            { k: 'area', v: x.area && SF.isNum(x.area.value) ? SF.fmt(x.area.value, 5) + ' (' + (x.area.label || '?') + ')' : 'unavailable' }, { k: 'balanced score', v: SF.fmt(x.balanced_score, 3) }, { k: 'Pareto-optimal', v: x.pareto ? 'yes' : 'no' }];
          return SF.tipContent(paramText(x), rows);
        } };
    });
    SF.scatter(c.body, { aria: 'Scatter of mean read latency against useful bandwidth for each candidate configuration, Pareto points highlighted', xLabel: 'Mean read latency (cycles, lower is better)', yLabel: 'Useful bandwidth (bytes per cycle, higher is better)', points: pts });
    // colour bar
    var grad = []; for (var i = 0; i <= 10; i++) { var cc = SF.ramp(0.3 + 0.7 * i / 10); grad.push('rgb(' + cc.join(',') + ') ' + (i * 10) + '%'); }
    c.body.appendChild(h('div', { style: { display: 'flex', alignItems: 'center', gap: '10px', margin: '8px 0 2px', flexWrap: 'wrap' } },
      h('span', { class: 'muted', style: { fontSize: '12px' }, text: colName + ':' }), h('span', { class: 'num', text: SF.fmt(vmin, 4) }),
      h('span', { 'aria-hidden': 'true', style: { display: 'inline-block', width: '180px', height: '10px', borderRadius: '3px', background: 'linear-gradient(90deg,' + grad.join(',') + ')' } }), h('span', { class: 'num', text: SF.fmt(vmax, 4) }),
      h('span', { class: 'muted', style: { fontSize: '12px' }, text: '◆ Pareto-optimal (gold ring)   ● dominated' })));
    var sorted = cs.slice().sort(function (a, b) { return (a.balanced_score === null ? 1 : a.balanced_score) - (b.balanced_score === null ? 1 : b.balanced_score); });
    c.body.appendChild(SF.tableView('All candidates (table view)', [
      { label: 'Configuration', get: function (x) { return paramText(x); } }, { label: 'Pareto', get: function (x) { return x.pareto ? '◆ yes' : 'no'; }, sort: function (x) { return x.pareto ? 0 : 1; } },
      { label: 'Latency (cycles)', num: true, get: function (x) { return SF.fmt(x.latency, 4); }, sort: function (x) { return x.latency; } }, { label: 'Bandwidth (B/cycle)', num: true, get: function (x) { return SF.fmt(x.bandwidth, 4); }, sort: function (x) { return x.bandwidth; } },
      { label: 'Energy proxy', num: true, get: function (x) { return SF.fmt(x.energy_proxy, 4); }, sort: function (x) { return x.energy_proxy; } },
      { label: 'Area', num: true, get: function (x) { return x.area && SF.isNum(x.area.value) ? SF.fmt(x.area.value, 5) + ' (' + (x.area.label || '?') + ')' : 'unavailable'; }, sort: function (x) { return x.area && x.area.value; } },
      { label: 'Balanced score', num: true, get: function (x) { return SF.fmt(x.balanced_score, 3); }, sort: function (x) { return x.balanced_score; } }], sorted, { maxRows: 800, caption: 'Latency and bandwidth are means over the workload suite and replications; no confidence interval is carried by the optimisation record.' }));
    // goals
    var g = O.goals && typeof O.goals === 'object' ? Object.keys(O.goals).map(function (k) { return { k: k, v: O.goals[k] }; }) : [];
    if (g.length) {
      var cg = SF.card({ title: 'Winner per goal (ties are reported, not broken)', provs: ['simulated'], source: 'data/optimise.json goals' });
      host.appendChild(h('div', { style: { height: '16px' } })); host.appendChild(cg.el);
      cg.body.appendChild(SF.table([{ label: 'Goal', get: function (x) { return x.k.replace(/_/g, ' '); } }, { label: 'Best value', num: true, get: function (x) { return typeof x.v === 'object' ? SF.fmt(x.v.best_value, 5) : null; } },
        { label: 'Winner(s)', get: function (x) { return typeof x.v === 'object' ? (x.v.winners || []).join('  |  ') : String(x.v); } }, { label: 'Tied', num: true, get: function (x) { return typeof x.v === 'object' ? x.v.n_tied : null; } },
        { label: 'Discriminates?', get: function (x) { return typeof x.v === 'object' ? (x.v.discriminates ? 'yes' : 'no: objective does not separate the candidates') : null; } }], g));
    }
    var pw = O.per_workload_winners && typeof O.per_workload_winners === 'object' ? Object.keys(O.per_workload_winners).map(function (k) { return { k: k, v: O.per_workload_winners[k] }; }) : [];
    var ws = O.balanced_weight_stability && typeof O.balanced_weight_stability === 'object' ? Object.keys(O.balanced_weight_stability).map(function (k) { return { id: k, n: O.balanced_weight_stability[k] }; }) : [];
    if (pw.length || ws.length) {
      var grid = h('div', { class: 'grid g2', style: { marginTop: '16px' } }); host.appendChild(grid);
      if (pw.length) {
        var cp = SF.card({ title: 'Per-workload winners', provs: ['simulated'], source: 'data/optimise.json per_workload_winners' }); grid.appendChild(cp.el);
        cp.body.appendChild(SF.table([{ label: 'Workload', get: function (x) { return x.k; } }, { label: 'Lowest latency', get: function (x) { return x.v.lowest_latency; } }, { label: 'Highest bandwidth', get: function (x) { return x.v.highest_bandwidth; } }], pw));
      }
      if (ws.length) {
        var cw = SF.card({ title: 'How stable is the balanced winner under random weights?', provs: ['simulated'], note: 'The balanced-score winner depends on how the goals are weighted. Wins out of ' + (O.weight_trials || '?') + ' seeded random weightings:', source: 'data/optimise.json balanced_weight_stability' }); grid.appendChild(cw.el);
        cw.body.appendChild(SF.table([{ label: 'Configuration', get: function (x) { return x.id; } }, { label: 'Wins', num: true, get: function (x) { return x.n; } }], ws.slice(0, 12)));
      }
    }
  }
  SF.registerView(14, 'Pareto frontier', 'Pareto frontier',
    'Latency against bandwidth for every evaluated configuration, with Pareto-optimal points highlighted and colour showing area or the energy proxy. No single configuration is optimal for every goal.', renderPareto);

  // ================================================================== 15. Experiment history
  // provenance class of each CLI command's results (explicit first; pattern fallback for older records)
  var CMD_CLASS = { rtlcheck: { label: 'rtl_simulated' }, xsim: { label: 'rtl_simulated' }, ecc: { label: 'rtl_simulated' },
    mbist: { label: 'rtl_simulated' }, synth: 'synthesized', floorplan: 'analytical', power: 'simulated', rstats: 'simulated',
    optimise: 'simulated', simulate: 'simulated', benchmark: 'simulated', sweep: 'simulated', compare: 'simulated',
    vector: 'simulated', tensor: 'simulated' };
  function classOfCommand(cmd) {
    var c = String(cmd || '').toLowerCase();
    if (Object.prototype.hasOwnProperty.call(CMD_CLASS, c)) return CMD_CLASS[c];
    if (/synth|yosys|area/.test(c)) return 'synthesized';
    if (/rtl|verify/.test(c)) return { label: 'rtl_simulated' };
    if (/simulat|benchmark|sweep|compare|vector|tensor|optimi|timeline|study|run/.test(c)) return 'simulated';
    return null;
  }
  function renderHistory(host, refresh) {
    var E = SF.DS.experiments;
    var rows = E && Array.isArray(E.rows) ? E.rows : [];
    if (!E || !rows.length) {
      host.appendChild(SF.unavailableCard('Experiment history', { why: E ? 'data/runs exists but holds no experiment records.' : 'data/runs/experiments.jsonl is not present in the data directory this dashboard was built from.',
        detail: 'Each experiment (a run, benchmark, sweep or study) appends one record with its id, time, command, configuration hash, result hash and git revision. Nothing is invented when there are none.',
        unlocks: ['Run commands that write reproducibility records (for example a simulation or benchmark with an output directory) so data/runs/experiments.jsonl is created, then rebuild the dashboard.'], source: 'data/runs/experiments.jsonl' }));
      return;
    }
    if (!S.eh) S.eh = { q: '' };
    var st = S.eh;
    var clsSet = SF.uniq(rows.map(function (r) { var c = classOfCommand(r.command); return c ? (typeof c === 'string' ? c : c.label) : 'unverified'; }));
    var provs = clsSet.map(function (k) { return k === 'unverified' ? { label: 'unverified', sub: 'no class for command' } : (k === 'rtl_simulated' ? { label: k } : k); });
    var c = SF.card({ title: 'Recorded experiments (' + rows.length + ')', provs: provs,
      note: 'One row per recorded run. The config hash identifies the normalised configuration; the result hash is the SHA-256 of the deterministic result payload, so re-running the same configuration and seed must reproduce it. A "dirty" git revision means uncommitted changes existed when the run was recorded.',
      source: 'data/runs/experiments.jsonl and data/runs/EXP-*.json (sramlab.record)' });
    host.appendChild(c.el);
    var filt = h('label', { class: 'ctl', for: 'ctl-eh-q' }, 'Filter (id, command, name, hash, revision)', h('input', { id: 'ctl-eh-q', 'data-ctl': 'eh-q', type: 'text', value: st.q, placeholder: 'type to filter', on: { input: function (e) { st.q = e.target.value; drawTable(); } } }));
    c.body.appendChild(SF.controls(filt));
    var tblHost = h('div'), detail = h('div', { class: 'kv', 'aria-live': 'polite' });
    c.body.appendChild(tblHost); c.body.appendChild(detail);
    function drawTable() {
      var q = (st.q || '').toLowerCase();
      var f = rows.filter(function (r) { return !q || [r.experiment_id, r.command, r.name, r.config_hash, r.result_hash, r.git_revision].join(' ').toLowerCase().indexOf(q) >= 0; }).slice().reverse();
      SF.clear(tblHost);
      if (!f.length) { tblHost.appendChild(SF.note('No experiment matches the filter.')); return; }
      var hx = function (k, n) { return function (r) { var v = r[k]; return v ? h('span', { class: 'mono', title: v, text: String(v).slice(0, n) + (String(v).length > n ? '…' : '') }) : null; }; };
      tblHost.appendChild(SF.table([
        { label: 'Experiment id', get: function (r) { return h('span', { class: 'mono', text: r.experiment_id }); }, sort: function (r) { return r.experiment_id; } },
        { label: 'Time (UTC)', get: function (r) { return r.created_utc ? String(r.created_utc).replace('T', ' ').replace('+00:00', '') : null; }, sort: function (r) { return r.created_utc; } },
        { label: 'Command', get: function (r) { return r.command; } }, { label: 'Class', get: function (r) { var k = classOfCommand(r.command); return k ? SF.chip(typeof k === 'string' ? k : k.label) : SF.chip('unverified'); }, sort: function (r) { return r.command; } },
        { label: 'Config name', get: function (r) { return r.name; } },
        { label: 'Config hash', get: hx('config_hash', 12), sort: function (r) { return r.config_hash; } }, { label: 'Result hash', get: hx('result_hash', 12), sort: function (r) { return r.result_hash; } },
        { label: 'Git revision', get: function (r) { return r.git_revision ? h('span', { class: 'mono', title: r.git_revision, text: String(r.git_revision).slice(0, 10) + (r.git_dirty ? ' (dirty)' : '') }) : null; }, sort: function (r) { return r.git_revision; } },
        { label: 'Seed', num: true, get: function (r) { return r.seed; } },
        { label: 'Headline', get: function (r) { return r.headline && typeof r.headline === 'object' ? Object.keys(r.headline).map(function (k) { return k + ' ' + (SF.isNum(r.headline[k]) ? SF.fmt(r.headline[k], 4) : r.headline[k]); }).join(', ') : null; } }
      ], f, { sortCol: 1, sortDir: -1, caption: 'Newest first. Select a row for the full hashes and revision.', maxRows: 1000,
        onRow: function (r) {
          SF.clear(detail);
          [['experiment id', r.experiment_id], ['created (UTC)', r.created_utc], ['command', r.command], ['config name', r.name], ['config hash', r.config_hash], ['result hash', r.result_hash], ['git revision', r.git_revision + (r.git_dirty ? '  (working tree was dirty)' : '')], ['seed', r.seed], ['wall seconds', r.wall_seconds], ['workload', r.workload_kind], ['headline', r.headline ? JSON.stringify(r.headline) : null]].forEach(function (p) {
            if (p[1] === undefined || p[1] === null || p[1] === 'undefined') return;
            detail.appendChild(h('dt', { text: p[0] })); detail.appendChild(h('dd', { class: 'mono', text: String(p[1]) }));
          });
          detail.style.marginTop = '12px';
        } }));
    }
    drawTable();
    if (E.unreadable_lines) c.body.appendChild(SF.note(E.unreadable_lines + ' line(s) of experiments.jsonl could not be parsed and are not shown.', true));
  }
  SF.registerView(15, 'Experiment history', 'Experiment history',
    'Every recorded run with its experiment id, time, command, configuration name, configuration and result hashes and git revision, for reproducibility.', renderHistory);
})();
