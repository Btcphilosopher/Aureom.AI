/* Views 7 and 8: tensor-core and vector-master memory studies (data/tensor_study.json, data/vector_study.json). */
(function () {
  'use strict';
  var SF = window.SF, h = SF.h, s = SF.s;
  var S = SF.state;

  // ================================================================== 7. Tensor memory utilisation
  var TSRC = 'data/tensor_study.json (sramlab.studies.tensor_study: closed-loop 4x4 INT8 output-stationary TensorCore fed from banked SRAM, verified cycle model)';
  function numOpts(arr) { return SF.sortNum(SF.uniq(arr)).map(function (v) { return { v: v }; }); }
  function renderTensor(host, refresh) {
    var T = SF.DS.tensor_study;
    if (!T || !Array.isArray(T.rows) || !T.rows.length) {
      host.appendChild(SF.unavailableCard('Tensor memory utilisation', { why: T ? 'data/tensor_study.json is present but has no rows.' : SF.absentReason('tensor_study.json'),
        unlocks: ['Regenerate: python3 scripts/generate_data.py --only tensor'], source: 'data/tensor_study.json' }));
      return;
    }
    var rows = T.rows;
    if (!S.tn) S.tn = {};
    var st = S.tn;
    var wbs = SF.sortNum(SF.uniq(rows.map(function (r) { return r.word_bits; }))), pitches = SF.uniq(rows.map(function (r) { return r.pitch; })), duties = SF.sortNum(SF.uniq(rows.map(function (r) { return r.dma_duty; }))), mos = SF.sortNum(SF.uniq(rows.map(function (r) { return r.max_out; })));
    if (wbs.indexOf(+st.wb) < 0) st.wb = wbs[0];
    if (pitches.indexOf(st.pitch) < 0) st.pitch = pitches.indexOf('padded') >= 0 ? 'padded' : pitches[0];
    if (duties.indexOf(+st.duty) < 0) st.duty = duties[0];
    if (mos.indexOf(+st.mo) < 0) st.mo = mos[mos.length - 1];
    st.wb = +st.wb; st.duty = +st.duty; st.mo = +st.mo;
    host.appendChild(SF.controls(
      SF.select('tn-wb', 'Word width (bits)', wbs.map(function (v) { return { v: v }; }), st.wb, function (v) { st.wb = +v; refresh(); }),
      SF.select('tn-p', 'Operand pitch', pitches.map(function (v) { return { v: v }; }), st.pitch, function (v) { st.pitch = v; refresh(); }),
      SF.select('tn-d', 'DMA duty', duties.map(function (v) { return { v: v, t: v === 0 ? '0 (no DMA)' : String(v) }; }), st.duty, function (v) { st.duty = +v; refresh(); }),
      SF.select('tn-m', 'MAX_OUT for buffer / DMA charts', mos.map(function (v) { return { v: v }; }), st.mo, function (v) { st.mo = +v; refresh(); })));
    var sel = rows.filter(function (r) { return r.word_bits === st.wb && r.pitch === st.pitch && r.dma_duty === st.duty; });
    var banks = SF.sortNum(SF.uniq(sel.map(function (r) { return r.banks; })));
    var byMo = function (mo) { return sel.filter(function (r) { return r.max_out === mo; }).sort(function (a, b) { return a.banks - b.banks; }); };
    var g = T.gemm ? T.gemm.M + 'x' + T.gemm.N + 'x' + T.gemm.K : 'fixed';
    var ideal = SF.isNum(T.util_ideal_reference) ? T.util_ideal_reference : null;
    host.appendChild(h('p', { class: 'note', text: 'GEMM ' + g + '. Each point is one deterministic simulation of the TensorCore with its operands in banked SRAM (no replications, so there is no confidence interval). Selected: ' + st.wb + '-bit words, ' + st.pitch + ' pitch, DMA duty ' + st.duty + '.' }));
    function coincide(field) {
      var groups = {};
      mos.forEach(function (mo) { var k = byMo(mo).map(function (r) { return r[field]; }).join('|'); (groups[k] = groups[k] || []).push(mo); });
      var same = Object.keys(groups).map(function (k) { return groups[k]; }).filter(function (g) { return g.length > 1; });
      return same.length ? ' MAX_OUT = ' + same.map(function (g) { return g.join(' and '); }).join('; ') + ' give identical values here, so those lines lie on top of each other (hover for the values).' : '';
    }
    function series(field, mos2) {
      return (mos2 || mos).map(function (mo, i) { var sty = SF.style(i); return { id: 'mo' + mo, name: 'MAX_OUT = ' + mo, color: sty.color, marker: sty.marker, pts: byMo(mo).map(function (r) { return { x: r.banks, y: SF.isNum(r[field]) ? r[field] : null }; }) }; });
    }
    var common = { xLabel: 'Banks (log2 spacing)', xTicks: banks };
    var grid = h('div', { class: 'grid g2' }); host.appendChild(grid);
    // 1 MAC utilisation
    var c1 = SF.card({ title: 'MAC utilisation vs banks', provs: ['simulated'], note: coincide('mac_utilisation').trim() || null, source: TSRC + '; threshold from util_ideal_reference' });
    grid.appendChild(c1.el);
    var ref = [];
    if (ideal !== null) ref.push({ y: ideal * 0.95, label: 'memory-limited below 95% of the ideal reference (' + SF.fmt(ideal * 95, 3) + ' % MAC utilisation)', color: '#d4af37', dash: '1 0', anchor: 'start', legend: 'memory-limited threshold (95% of ideal reference run)', tip: true });
    SF.lineChart(c1.body, Object.assign({ aria: 'MAC utilisation versus banks for each MAX_OUT', yLabel: 'MAC utilisation (fraction of peak)', yMin: 0, yMax: 1, yFmt: function (v) { return SF.fmt(v, 2); }, series: series('mac_utilisation'), refLines: ref, height: 270 }, common));
    // 2 starvation
    var c2 = SF.card({ title: 'Operand starvation vs banks', provs: ['simulated'], note: coincide('starvation_fraction').trim() || null, source: TSRC });
    grid.appendChild(c2.el);
    SF.lineChart(c2.body, Object.assign({ aria: 'Starvation fraction versus banks', yLabel: 'Cycles starved (fraction)', yMin: 0, yMax: 1, yFmt: function (v) { return SF.fmt(v, 2); }, series: series('starvation_fraction'), height: 270 }, common));
    // 3 operand bytes per cycle vs required
    var any = byMo(mos[0]);
    var c3 = SF.card({ title: 'Delivered operand bytes per cycle vs what the array requires', provs: ['simulated', 'analytical'], note: 'The analytical array ceiling (banks x word bytes, ' + any.map(function (r) { return SF.fmt(r.analytical_array_bytes_per_cycle, 3); }).join(' / ') + ' B/cycle for ' + any.map(function (r) { return r.banks; }).join(' / ') + ' banks) rises far above the requirement and is listed in the table below instead of being plotted, so the simulated values stay readable.', source: TSRC + '; analytical = required_operand_bytes_per_cycle and analytical_array_bytes_per_cycle fields' });
    grid.appendChild(c3.el);
    var req = any.length && SF.isNum(any[0].required_operand_bytes_per_cycle) ? any[0].required_operand_bytes_per_cycle : null;
    var s3 = series('operand_bytes_per_cycle');
    SF.lineChart(c3.body, Object.assign({ aria: 'Operand bytes per cycle versus banks', yLabel: 'Bytes per cycle', unit: 'B/cycle', series: s3, height: 270,
      refLines: req !== null ? [{ y: req, label: 'required by the array: ' + SF.fmt(req, 3) + ' B/cycle', color: SF.SILVER, dash: '7 5', legend: 'analytical operand demand of the array' }] : [] }, common));
    // 4 verdict matrix
    var c4 = SF.card({ cls: 'wide', title: 'Memory-limited verdict', provs: ['simulated'], note: 'Rule from the dataset: ' + (T.verdict_rule || 'memory_limited = MAC utilisation below 95% of the ideal-resource reference run') + '. Reference run: ' + (T.reference_config || 'n/a') + (ideal !== null ? ' (MAC utilisation ' + SF.fmt(ideal * 100, 4) + ' %).' : '.'), source: TSRC });
    grid.appendChild(c4.el);
    var vt = h('table', { class: 'data' });
    var thead = h('tr', null, h('th', { text: 'Banks' }));
    mos.forEach(function (mo) { thead.appendChild(h('th', { text: 'MAX_OUT ' + mo })); });
    vt.appendChild(h('thead', null, thead));
    var vb = h('tbody');
    banks.forEach(function (b) {
      var tr = h('tr', null, h('td', { class: 'num', text: String(b) }));
      mos.forEach(function (mo) {
        var r = sel.filter(function (q) { return q.banks === b && q.max_out === mo; })[0];
        if (!r) { tr.appendChild(h('td', { class: 'muted', text: 'not simulated' })); return; }
        var lim = r.memory_limited === true, unk = typeof r.memory_limited !== 'boolean';
        tr.appendChild(h('td', null, h('span', { class: 'badge ' + (unk ? '' : lim ? 'warn' : 'ok') }, unk ? '? unknown' : lim ? '▲ memory-limited' : '● not memory-limited'), ' ', h('span', { class: 'num muted', text: SF.pct(r.mac_utilisation, 3) })));
      });
      vb.appendChild(tr);
    });
    vt.appendChild(vb);
    c4.body.appendChild(h('div', { class: 'tablewrap' }, vt));
    // 5 buffers
    var c5 = SF.card({ title: 'Operand buffer occupancy (MAX_OUT = ' + st.mo + ')', provs: ['simulated'], source: TSRC });
    grid.appendChild(c5.el);
    var cur = byMo(st.mo);
    SF.lineChart(c5.body, Object.assign({ aria: 'Mean operand buffer occupancy for A and B versus banks', yLabel: 'Mean occupancy (words)', unit: 'words', height: 250, series: [
      { id: 'A', name: 'operand A buffer', color: SF.PAL[0], marker: 'circle', pts: cur.map(function (r) { return { x: r.banks, y: SF.isNum(r.buffer_occupancy_a_mean) ? r.buffer_occupancy_a_mean : null }; }) },
      { id: 'B', name: 'operand B buffer', color: SF.PAL[1], marker: 'square', pts: cur.map(function (r) { return { x: r.banks, y: SF.isNum(r.buffer_occupancy_b_mean) ? r.buffer_occupancy_b_mean : null }; }) }] }, common));
    // 6 DMA overlap
    var c6 = SF.card({ cls: 'wide', title: 'DMA overlap (MAX_OUT = ' + st.mo + ')', provs: ['simulated'], source: TSRC });
    grid.appendChild(c6.el);
    if (st.duty === 0 || !cur.some(function (r) { return SF.isNum(r.dma_overlap_fraction); })) {
      c6.body.appendChild(SF.unavailable({ why: st.duty === 0 ? 'DMA duty is 0, so there is no DMA traffic and "overlap with compute" has no meaning; the dataset holds no value for these rows, so none is shown.' : 'No DMA overlap values were recorded for this selection.', unlocks: ['Choose a DMA duty above 0 (0.25 or 0.5) to see how much DMA traffic overlapped with compute.'] }));
    } else {
      SF.lineChart(c6.body, Object.assign({ aria: 'DMA overlap fraction versus banks', yLabel: 'DMA overlap fraction', yMin: 0, yMax: 1, yFmt: function (v) { return SF.fmt(v, 2); }, height: 250,
        series: [{ id: 'ov', name: 'DMA overlap with compute', color: SF.PAL[2], marker: 'diamond', pts: cur.map(function (r) { return { x: r.banks, y: SF.isNum(r.dma_overlap_fraction) ? r.dma_overlap_fraction : null }; }) }] }, common));
    }
    [c4.el, c1.el, c2.el, c3.el, c5.el, c6.el].forEach(function (el) { grid.appendChild(el); });   // verdict first, then the charts in pairs
    // table of the selected rows
    var tc = SF.card({ title: 'Rows behind these charts (' + sel.length + ')', provs: ['simulated'], source: TSRC });
    host.appendChild(h('div', { style: { height: '16px' } })); host.appendChild(tc.el);
    tc.body.appendChild(SF.table([
      { label: 'Banks', num: true, get: function (r) { return r.banks; } }, { label: 'MAX_OUT', num: true, get: function (r) { return r.max_out; } },
      { label: 'MAC util.', num: true, get: function (r) { return SF.pct(r.mac_utilisation, 3); }, sort: function (r) { return r.mac_utilisation; } },
      { label: 'Starvation', num: true, get: function (r) { return SF.pct(r.starvation_fraction, 3); }, sort: function (r) { return r.starvation_fraction; } },
      { label: 'Operand B/cycle', num: true, get: function (r) { return SF.fmt(r.operand_bytes_per_cycle, 4); }, sort: function (r) { return r.operand_bytes_per_cycle; } },
      { label: 'Required B/cycle (analytical)', num: true, get: function (r) { return SF.fmt(r.required_operand_bytes_per_cycle, 4); } }, { label: 'Array ceiling B/cycle (analytical)', num: true, get: function (r) { return SF.fmt(r.analytical_array_bytes_per_cycle, 4); } },
      { label: 'Buffer A', num: true, get: function (r) { return SF.fmt(r.buffer_occupancy_a_mean, 3); } }, { label: 'Buffer B', num: true, get: function (r) { return SF.fmt(r.buffer_occupancy_b_mean, 3); } },
      { label: 'DMA overlap', num: true, get: function (r) { return SF.isNum(r.dma_overlap_fraction) ? SF.pct(r.dma_overlap_fraction, 3) : null; } },
      { label: 'Conflict events', num: true, get: function (r) { return r.bank_conflict_events; } }, { label: 'Cycles', num: true, get: function (r) { return r.cycles; } },
      { label: 'Verdict', get: function (r) { return r.memory_limited === true ? 'memory-limited' : r.memory_limited === false ? 'not memory-limited' : 'unknown'; } }], sel, { caption: 'Single deterministic runs: no confidence interval exists for these values.' }));
    // chunked roof + imported reference
    var ch = T.chunked;
    var grid2 = h('div', { class: 'grid g2', style: { marginTop: '16px' } }); host.appendChild(grid2);
    if (ch && Array.isArray(ch.rows) && ch.rows.length) {
      var cc = SF.card({ title: 'Chunked-GEMM MAC roof (bytes per MAC = ' + SF.fmt(ch.bytes_per_mac, 3) + ')', provs: ['analytical', 'simulated'], note: ch.note || '',
        source: 'data/tensor_study.json chunked (label: ' + (ch.rows[0].label || 'analytical-from-simulated-bandwidth') + ')' });
      grid2.appendChild(cc.el);
      SF.groupedBars(cc.body, { aria: 'Analytical MAC per cycle roof by bank count', cats: ch.rows.map(function (r) { return r.banks + ' banks'; }), series: [{ id: 'roof', name: 'MAC/cycle roof (analytical, from simulated bandwidth)', color: SF.SILVER, hatch: true, vals: ch.rows.map(function (r) { return SF.isNum(r.mac_per_cycle_roof) ? r.mac_per_cycle_roof : null; }) }],
        yLabel: 'MAC per cycle', unit: 'MAC/cycle', height: 230, valueLabels: true, legend: false });
      cc.body.appendChild(SF.tableView('Chunked roof table', [{ label: 'Banks', num: true, get: function (r) { return r.banks; } }, { label: 'Operand B/cycle (simulated)', num: true, get: function (r) { return SF.fmt(r.operand_bytes_per_cycle, 4); } },
        { label: 'MAC/cycle roof', num: true, get: function (r) { return SF.fmt(r.mac_per_cycle_roof, 4); } }, { label: 'Utilisation roof vs 16 MAC', num: true, get: function (r) { return SF.pct(r.util_roof_vs_16mac, 3); } }], ch.rows));
    }
    var ir = T.imported_reference;
    if (ir && ir.value) {
      var ci = SF.card({ title: 'Imported reference (context only, not a comparison target)', provs: [ir.provenance || 'unavailable'], note: ir.value.note || '', source: ir.source || 'data/tensor_study.json imported_reference' });
      grid2.appendChild(ci.el);
      var kv = h('dl', { class: 'kv' });
      Object.keys(ir.value).filter(function (k) { return k !== 'note'; }).forEach(function (k) { kv.appendChild(h('dt', { text: k.replace(/_/g, ' ') })); kv.appendChild(h('dd', { text: SF.isNum(ir.value[k]) ? SF.fmt(ir.value[k], 4) : String(ir.value[k]) })); });
      ci.body.appendChild(kv);
    }
  }
  SF.registerView(7, 'Tensor memory utilisation', 'Tensor memory utilisation',
    'How well banked SRAM keeps a 4x4 TensorCore fed: MAC utilisation, starvation, operand bandwidth, buffer occupancy and DMA overlap against bank count and MAX_OUT, with the memory-limited verdict.', renderTensor);

  // ================================================================== 8. Vector memory utilisation
  var VSRC = 'data/vector_study.json (sramlab.studies.vector: vector masters streaming through the verified cycle model, 3 replications per row, 95% CI)';
  function renderVector(host, refresh) {
    var V = SF.DS.vector_study, st0 = V && V.study;
    if (!st0 || !Array.isArray(st0.rows) || !st0.rows.length) {
      host.appendChild(SF.unavailableCard('Vector memory utilisation', { why: V ? 'data/vector_study.json is present but has no study rows.' : SF.absentReason('vector_study.json'),
        unlocks: ['Regenerate: python3 scripts/generate_data.py --only vector'], source: 'data/vector_study.json' }));
      return;
    }
    var rows = st0.rows;
    if (!S.vc) S.vc = {};
    var st = S.vc;
    var wbs = SF.sortNum(SF.uniq(rows.map(function (r) { return r.word_bits; }))), vbs = SF.sortNum(SF.uniq(rows.map(function (r) { return r.vector_bits; }))), bks = SF.sortNum(SF.uniq(rows.map(function (r) { return r.banks; })));
    if (wbs.indexOf(+st.wb) < 0) st.wb = wbs[0]; if (vbs.indexOf(+st.vb) < 0) st.vb = vbs[0]; if (bks.indexOf(+st.b) < 0) st.b = bks.indexOf(4) >= 0 ? 4 : bks[0];
    st.wb = +st.wb; st.vb = +st.vb; st.b = +st.b;
    host.appendChild(SF.controls(
      SF.select('vc-wb', 'Word width (bits)', wbs.map(function (v) { return { v: v }; }), st.wb, function (v) { st.wb = +v; refresh(); }),
      SF.select('vc-vb', 'Vector width (bits)', vbs.map(function (v) { return { v: v }; }), st.vb, function (v) { st.vb = +v; refresh(); }),
      SF.select('vc-b', 'Banks', bks.map(function (v) { return { v: v }; }), st.b, function (v) { st.b = +v; refresh(); })));
    var sel = rows.filter(function (r) { return r.word_bits === st.wb && r.vector_bits === st.vb && r.banks === st.b; });
    if (!sel.length) { host.appendChild(SF.unavailableCard('Vector memory utilisation', { why: 'This word/vector/bank combination was not simulated.', source: 'data/vector_study.json' })); return; }
    var cases = sel.map(function (r) { return r.case; });
    var cl = cases.map(function (c) { return c.replace(/_/g, ' '); });
    var peak = sel[0].peak_array_bytes_per_cycle, mc = sel[0].master_ceiling_bytes_per_cycle, nm = st0.masters;
    var aggr = SF.isNum(mc) && SF.isNum(nm) ? mc * nm : null;
    var c1 = SF.card({ title: 'Useful vs fetched bytes per cycle by access case', provs: ['simulated', 'analytical'],
      note: 'Useful bytes are what the vector masters asked for; fetched bytes are what the banks actually moved. Fetched above useful is alignment overhead (split / merge accesses). ' + (st0.note || ''),
      source: VSRC + '; analytical lines = peak_array_bytes_per_cycle and masters x master_ceiling_bytes_per_cycle' });
    host.appendChild(c1.el);
    var refs = [];
    if (SF.isNum(peak)) refs.push({ y: peak, label: 'analytical array peak ' + SF.fmt(peak, 3) + ' B/cycle', color: SF.SILVER, dash: '7 5', legend: 'analytical array peak (banks x word bytes)' });
    if (aggr !== null) refs.push({ y: aggr, label: '', color: SF.SILVER, dash: '2 5', legend: 'analytical master ceiling (' + nm + ' masters x ' + SF.fmt(mc, 3) + ' B/cycle)' });
    SF.groupedBars(c1.body, { aria: 'Useful versus fetched bytes per cycle for each access case', cats: cl, yLabel: 'Bytes per cycle', unit: 'B/cycle', height: 300, refLines: refs,
      series: [{ id: 'useful', name: 'useful (simulated, 95% CI)', color: SF.PAL[0], vals: sel.map(function (r) { return r.useful_bytes_per_cycle; }) },
        { id: 'fetched', name: 'fetched (simulated)', color: SF.PAL[1], vals: sel.map(function (r) { return SF.isNum(r.fetched_bytes_per_cycle) ? r.fetched_bytes_per_cycle : null; }) }] });
    var grid = h('div', { class: 'grid g3', style: { marginTop: '16px' } }); host.appendChild(grid);
    var c2 = SF.card({ title: 'Alignment overhead', provs: ['simulated'], note: 'fetched / useful bytes; 1.0 means no extra bytes moved.', source: VSRC }); grid.appendChild(c2.el);
    SF.groupedBars(c2.body, { aria: 'Alignment overhead by access case', cats: cl, yLabel: 'Fetched / useful', height: 260, legend: false, unit: '×',
      series: [{ id: 'ov', name: 'alignment overhead', color: SF.PAL[2], vals: sel.map(function (r) { return SF.isNum(r.alignment_overhead) ? r.alignment_overhead : null; }) }] });
    var c3 = SF.card({ title: 'Bank conflicts per access', provs: ['simulated'], source: VSRC }); grid.appendChild(c3.el);
    SF.groupedBars(c3.body, { aria: 'Conflict rate per access by case', cats: cl, yLabel: 'Conflicts per access', height: 260, legend: false, unit: 'per access', yFmt: function (v) { return SF.fmt(v, 2); },
      series: [{ id: 'cf', name: 'conflict rate', color: SF.PAL[3], vals: sel.map(function (r) { return r.conflict_rate_per_access; }) }] });
    var c4 = SF.card({ title: 'End-to-end read latency', provs: ['simulated'], source: VSRC }); grid.appendChild(c4.el);
    SF.groupedBars(c4.body, { aria: 'End-to-end read latency by case', cats: cl, yLabel: 'Cycles', height: 260, legend: false, unit: 'cycles',
      series: [{ id: 'lat', name: 'mean read latency', color: SF.PAL[4], vals: sel.map(function (r) { return r.read_latency_e2e_mean; }) }] });
    var tc = SF.card({ title: 'Vector study rows (' + sel.length + ' for this selection)', provs: ['simulated', 'analytical'], source: VSRC });
    host.appendChild(h('div', { style: { height: '16px' } })); host.appendChild(tc.el);
    tc.body.appendChild(SF.table([
      { label: 'Case', get: function (r) { return r.case; } }, { label: 'Useful B/cycle', num: true, get: function (r) { return SF.pm(r.useful_bytes_per_cycle, 4); }, sort: function (r) { return SF.stat(r.useful_bytes_per_cycle).m; } },
      { label: 'Fetched B/cycle', num: true, get: function (r) { return SF.fmt(r.fetched_bytes_per_cycle, 4); } }, { label: 'Alignment overhead', num: true, get: function (r) { return SF.fmt(r.alignment_overhead, 4); } },
      { label: 'Conflict rate', num: true, get: function (r) { return SF.pm(r.conflict_rate_per_access, 3); } }, { label: 'Read latency (cycles)', num: true, get: function (r) { return SF.pm(r.read_latency_e2e_mean, 4); } },
      { label: 'Array peak B/cycle (analytical)', num: true, get: function (r) { return SF.fmt(r.peak_array_bytes_per_cycle, 4); } }], sel));
    var x = V.p76_crosscheck;
    if (x && x.value) {
      var cx = SF.card({ title: 'Cross-check against RTL simulation (P76 VectorScratch)', provs: [x.provenance || 'unavailable'],
        note: 'The closed-form access model used above reproduces the cycle counts of the imported RTL-simulation rows exactly where the arithmetic is closed-form.', source: x.source || 'data/vector_study.json p76_crosscheck' });
      host.appendChild(cx.el);
      var v = x.value;
      cx.body.appendChild(h('div', { class: 'stats' },
        h('div', { class: 'stat' }, h('div', { class: 'l', text: 'Rows checked' }), h('div', { class: 'v', text: SF.fmt(v.rows_checked) })),
        h('div', { class: 'stat' }, h('div', { class: 'l', text: 'Cycle-exact match' }), h('div', { class: 'v', text: SF.fmt(v.cycles_exact_match) + ' / ' + SF.fmt(v.rows_checked) }), h('div', { class: 's', text: 'max |cycle error| ' + SF.fmt(v.max_abs_cycle_error) })),
        h('div', { class: 'stat' }, h('div', { class: 'l', text: 'Word-access counts' }), h('div', { class: 'v', text: String(v.word_access_count_match) }))));
      var kv = h('dl', { class: 'kv' });
      [['scope', v.scope], ['model', v.model], ['csv sha256', v.csv_sha256]].forEach(function (p) { if (p[1]) { kv.appendChild(h('dt', { text: p[0] })); kv.appendChild(h('dd', { class: p[0] === 'csv sha256' ? 'mono' : '', text: String(p[1]) })); } });
      cx.body.appendChild(kv);
    } else {
      host.appendChild(SF.unavailableCard('Cross-check against RTL simulation', { why: 'vector_study.json carries no p76_crosscheck record.', source: 'data/vector_study.json p76_crosscheck' }));
    }
  }
  SF.registerView(8, 'Vector memory utilisation', 'Vector memory utilisation',
    'Useful vs fetched bytes per cycle for vector accesses, how much alignment adds, and the RTL-simulation cross-check of the access model.', renderVector);
})();
