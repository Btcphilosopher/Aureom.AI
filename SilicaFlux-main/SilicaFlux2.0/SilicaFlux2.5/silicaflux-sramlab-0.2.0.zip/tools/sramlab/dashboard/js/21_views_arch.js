/* Views 1-3: memory architecture diagram, SRAM bank map, replay of a recorded transaction timeline. */
(function () {
  'use strict';
  var SF = window.SF, h = SF.h, s = SF.s;
  var S = SF.state;

  // ================================================================== 1. Memory architecture (structure only)
  S.arch = S.arch || null;
  function archDefaults() {
    var t = SF.DS.timeline_trace;
    return { masters: (t && t.masters) || 4, banks: (t && t.banks) || 4 };
  }
  function renderArch(host, refresh) {
    if (!S.arch) S.arch = archDefaults();
    var st = S.arch;
    host.appendChild(SF.controls(
      SF.select('arch-m', 'Masters', [1, 2, 3, 4, 6, 8, 12, 16].map(function (v) { return { v: v }; }), st.masters, function (v) { st.masters = +v; refresh(); }),
      SF.select('arch-b', 'Banks', [1, 2, 4, 8, 16].map(function (v) { return { v: v }; }), st.banks, function (v) { st.banks = +v; refresh(); })));
    var M = st.masters, B = st.banks;
    var c = SF.card({ title: 'Controller structure: ' + M + ' masters, ' + B + ' banks', provs: [{ label: 'analytical', sub: 'structural' }],
      note: 'Block diagram of the SilicaFlux SRAM controller structure for the chosen master and bank counts. It shows structure only: no timing, area, power or performance number is implied.',
      source: 'rtl/third_party/p73_sramcontroller (sf_sram_controller, sf_sramc_arb, sf_sramc_txn, sf_sramc_bank, sf_sramc_fifo); structure as described in docs/01_architecture.md' });
    host.appendChild(c.el);
    var avail = SF.width(c.body);
    var minW = 640, W = Math.max(minW, avail);
    var laneH = 46, mH = 30, mGap = 10;
    var colM = 14, wM = 74;
    var xArb = Math.round(W * 0.30), wBox = Math.round(Math.min(124, (W - xArb - 120) / 3.4));
    var xTrk = xArb + wBox + 26, xBank = xTrk + wBox + 26, xFifo = xBank + wBox + 26, xBus = xFifo + wBox + 22;
    var bodyH = Math.max(B * laneH, M * (mH + mGap));
    var H = bodyH + 70;
    var svg = s('svg', { viewBox: '0 0 ' + W + ' ' + H, width: W, height: H, role: 'img', 'aria-label': 'Block diagram: ' + M + ' masters feed ' + B + ' per-bank round-robin arbiters, then per-bank transaction trackers with credits, then ' + B + ' SRAM banks and per-bank response FIFOs, returning to the masters.' });
    var defs = s('defs');
    defs.appendChild(s('marker', { id: 'arr', viewBox: '0 0 8 8', refX: 7, refY: 4, markerWidth: 7, markerHeight: 7, orient: 'auto-start-reverse' }, s('path', { d: 'M0 0L8 4L0 8z', fill: '#98a3bd' })));
    svg.appendChild(defs);
    var yTop = 36;
    var mY = function (i) { return yTop + (bodyH - M * (mH + mGap) + mGap) / 2 + i * (mH + mGap); };
    var bY = function (k) { return yTop + (bodyH - B * laneH) / 2 + k * laneH + laneH / 2; };
    // column captions
    [['Masters', colM + wM / 2], ['Per-bank arbiter', xArb + wBox / 2], ['Tracker / credits', xTrk + wBox / 2], ['SRAM bank', xBank + wBox / 2], ['Response FIFO', xFifo + wBox / 2]].forEach(function (cap) {
      svg.appendChild(s('text', { x: cap[1], y: 18, 'text-anchor': 'middle', class: 'ttl', text: cap[0] }));
    });
    // request fabric: every master can reach every bank's arbiter (low-contrast so M x B stays legible)
    var op = Math.max(0.12, Math.min(0.5, 14 / (M * B)));
    var fab = s('g', { fill: 'none', stroke: '#00e5ff', 'stroke-opacity': op, 'stroke-width': 1 });
    for (var i = 0; i < M; i++) for (var k = 0; k < B; k++) {
      var x1 = colM + wM, y1 = mY(i) + mH / 2, x2 = xArb, y2 = bY(k), xm = (x1 + x2) / 2;
      fab.appendChild(s('path', { d: 'M' + x1 + ' ' + y1 + 'C' + xm + ' ' + y1 + ' ' + xm + ' ' + y2 + ' ' + x2 + ' ' + y2 }));
    }
    svg.appendChild(fab);
    // masters
    for (i = 0; i < M; i++) {
      svg.appendChild(s('rect', { x: colM, y: mY(i), width: wM, height: mH, rx: 6, fill: '#142349', stroke: '#00e5ff', 'stroke-width': 1.4 }));
      svg.appendChild(s('text', { x: colM + wM / 2, y: mY(i) + mH / 2 + 4, 'text-anchor': 'middle', text: 'master ' + i }));
    }
    function box(x, y, w, label, sub, stroke, dash) {
      svg.appendChild(s('rect', { x: x, y: y - 17, width: w, height: 34, rx: 6, fill: '#0f1a3a', stroke: stroke, 'stroke-width': 1.5, 'stroke-dasharray': dash || null }));
      svg.appendChild(s('text', { x: x + w / 2, y: y - (sub ? 2 : -4), 'text-anchor': 'middle', text: label }));
      if (sub) svg.appendChild(s('text', { x: x + w / 2, y: y + 11, 'text-anchor': 'middle', class: 'mut', text: sub }));
    }
    function arrow(x1, y1, x2, y2) { svg.appendChild(s('path', { d: 'M' + x1 + ' ' + y1 + 'L' + x2 + ' ' + y2, stroke: '#98a3bd', 'stroke-width': 1.4, fill: 'none', 'marker-end': 'url(#arr)' })); }
    for (k = 0; k < B; k++) {
      var y = bY(k);
      svg.appendChild(s('text', { x: xArb - 8, y: y + 4, 'text-anchor': 'end', class: 'mut', text: '' }));
      box(xArb, y, wBox, 'round-robin', 'arb ' + k, '#c0c8d4');
      box(xTrk, y, wBox, 'tracker', 'MAX_OUT credits', '#8b5cf6');
      box(xBank, y, wBox, 'bank ' + k, 'SRAM array', '#d4af37');
      box(xFifo, y, wBox, 'FIFO', 'resp ' + k, '#8b5cf6', '5 3');
      arrow(xArb + wBox, y, xTrk, y); arrow(xTrk + wBox, y, xBank, y); arrow(xBank + wBox, y, xFifo, y);
      svg.appendChild(s('path', { d: 'M' + (xFifo + wBox) + ' ' + y + 'H' + xBus, stroke: '#8b5cf6', 'stroke-width': 1.4, fill: 'none' }));
    }
    // response return bus -> masters
    var busTop = bY(0), busBot = bY(B - 1);
    svg.appendChild(s('path', { d: 'M' + xBus + ' ' + busTop + 'V' + busBot, stroke: '#8b5cf6', 'stroke-width': 2, fill: 'none' }));
    var retY = H - 22;
    svg.appendChild(s('path', { d: 'M' + xBus + ' ' + ((busTop + busBot) / 2) + 'V' + retY + 'H' + (colM + wM / 2) + 'V' + (mY(M - 1) + mH + 2), stroke: '#8b5cf6', 'stroke-width': 1.6, fill: 'none', 'stroke-dasharray': '6 4', 'marker-end': 'url(#arr)' }));
    svg.appendChild(s('text', { x: (xBus + colM) / 2, y: retY - 6, 'text-anchor': 'middle', class: 'mut', text: 'response return to the requesting master (tag-matched)' }));
    svg.appendChild(s('text', { x: (colM + wM + xArb) / 2, y: 18, 'text-anchor': 'middle', class: 'mut', text: 'request fabric: ' + (M * B) + ' crosspoints' }));
    var scroller = h('div', { class: 'chart', style: { overflowX: 'auto' }, tabindex: avail < minW ? '0' : null, role: avail < minW ? 'region' : null, 'aria-label': avail < minW ? 'Block diagram (scrolls sideways)' : null }, svg);
    c.body.appendChild(scroller);
    c.body.appendChild(SF.legend([{ name: 'request path (any master to any bank arbiter)', color: '#00e5ff' }, { name: 'response path', color: '#8b5cf6', dash: '6 4' }]));
    var comp = [['Masters', M], ['Request crosspoints (masters x banks)', M * B], ['Round-robin arbiters (one per bank)', B], ['Transaction trackers with MAX_OUT credits (one per bank)', B], ['SRAM banks', B], ['Response FIFOs (one per bank)', B]];
    c.body.appendChild(SF.tableView('Component counts (table view)', [{ label: 'Component', get: function (r) { return r[0]; } }, { label: 'Count', num: true, get: function (r) { return r[1]; } }], comp));
  }
  SF.registerView(1, 'Memory architecture', 'Memory architecture',
    'Masters, per-bank round-robin arbitration, trackers with credits, banks and response FIFOs. Structure only; choose how many masters and banks to draw.', renderArch);

  // ================================================================== 2. SRAM bank map
  S.map = S.map || { banks: 4, depth: 16, inter: 'low', stride: 1, count: 16, locate: 21 };
  function bankOf(word, p) {
    if (p.banks === 1) return { bank: 0, row: word % p.depth };
    if (p.inter === 'low') return { bank: word % p.banks, row: Math.floor(word / p.banks) };
    return { bank: Math.floor(word / p.depth), row: word % p.depth };
  }
  function renderMap(host, refresh) {
    var p = S.map;
    var total = p.banks * p.depth;
    var seg = SF.segmented('map-i', 'Interleave', [{ v: 'low', t: 'low (word % banks)' }, { v: 'high', t: 'high (word / depth)' }], p.inter, function (v) { p.inter = v; refresh(); });
    host.appendChild(SF.controls(
      SF.select('map-b', 'Banks', [1, 2, 4, 8, 16].map(function (v) { return { v: v }; }), p.banks, function (v) { p.banks = +v; refresh(); }),
      SF.select('map-d', 'Words per bank', [4, 8, 16, 32, 64, 256, 1024, 4096].map(function (v) { return { v: v }; }), p.depth, function (v) { p.depth = +v; refresh(); }),
      seg,
      SF.select('map-s', 'Stream stride (words)', [1, 2, 3, 4, 8, 16, 32].map(function (v) { return { v: v }; }), p.stride, function (v) { p.stride = +v; refresh(); }),
      SF.select('map-n', 'Stream length (words)', [4, 8, 16, 32, 64].map(function (v) { return { v: v }; }), p.count, function (v) { p.count = +v; refresh(); }),
      h('label', { class: 'ctl', for: 'ctl-map-l' }, 'Locate word address',
        h('input', { id: 'ctl-map-l', 'data-ctl': 'map-l', type: 'number', min: 0, max: total - 1, step: 1, value: Math.min(p.locate, total - 1), on: { change: function (e) { var v = Math.max(0, Math.min(total - 1, parseInt(e.target.value, 10) || 0)); p.locate = v; refresh(); } } }))));
    var c = SF.card({ title: 'Which bank and row holds each word', provs: [{ label: 'analytical', sub: 'address arithmetic' }],
      note: p.inter === 'low'
        ? 'Low interleave: bank = word mod banks, row = word / banks. Consecutive words rotate across the banks.'
        : 'High interleave: bank = word / words-per-bank, row = word mod words-per-bank. Consecutive words stay inside one bank until it is full.',
      source: 'computed in this page from the bank-mapping rule in sramlab/config.py (memory.interleave) and sim/controller.py _decode(); no simulation data is used' });
    host.appendChild(c.el);
    var B = p.banks, rowsDraw = Math.min(p.depth, 16);
    var stream = [];
    for (var i = 0; i < p.count; i++) { var w = i * p.stride; if (w < total) stream.push({ i: i, w: w, loc: bankOf(w, p) }); }
    var perBank = []; for (var b = 0; b < B; b++) perBank.push(0);
    stream.forEach(function (x) { perBank[x.loc.bank]++; });
    var W = SF.width(c.body), lblW = 62, cw = Math.max(30, Math.min(112, (W - lblW - 10) / B));
    var chh = 26, topBar = 112, H = topBar + rowsDraw * chh + 30;
    var svg = s('svg', { viewBox: '0 0 ' + (lblW + cw * B + 10) + ' ' + H, width: lblW + cw * B + 10, height: H, role: 'img', 'aria-label': 'Bank map: ' + B + ' banks, ' + p.depth + ' words per bank, ' + p.inter + ' interleave' });
    var maxCnt = Math.max.apply(null, perBank.concat([1]));
    svg.appendChild(s('text', { x: 2, y: 12, class: 'ttl', text: 'Stream words per bank' }));
    var items = [], over = s('g', { 'pointer-events': 'none' });
    for (b = 0; b < B; b++) {
      var x = lblW + b * cw, bh = (perBank[b] / maxCnt) * 52, bwid = Math.min(24, cw - 8);
      if (bh > 0) svg.appendChild(s('path', { d: 'M' + (x + cw / 2 - bwid / 2) + ' ' + (38 + 56) + 'V' + (38 + 56 - bh + 3) + 'Q' + (x + cw / 2 - bwid / 2) + ' ' + (38 + 56 - bh) + ' ' + (x + cw / 2 - bwid / 2 + 3) + ' ' + (38 + 56 - bh) + 'H' + (x + cw / 2 + bwid / 2 - 3) + 'Q' + (x + cw / 2 + bwid / 2) + ' ' + (38 + 56 - bh) + ' ' + (x + cw / 2 + bwid / 2) + ' ' + (38 + 56 - bh + 3) + 'V' + (38 + 56) + 'Z', fill: '#00e5ff' }));
      svg.appendChild(s('text', { x: x + cw / 2, y: 38 + 56 - bh - 4, 'text-anchor': 'middle', text: String(perBank[b]) }));
      svg.appendChild(s('text', { x: x + cw / 2, y: topBar - 4, 'text-anchor': 'middle', class: 'ttl', text: 'bank ' + b }));
    }
    svg.appendChild(s('line', { x1: lblW, x2: lblW + cw * B, y1: 38 + 56, y2: 38 + 56, stroke: '#5b6a93' }));
    var inStream = {}; stream.forEach(function (x) { inStream[x.w] = x; });
    var loc = bankOf(Math.min(p.locate, total - 1), p);
    for (var r = 0; r < rowsDraw; r++) {
      svg.appendChild(s('text', { x: lblW - 8, y: topBar + r * chh + chh / 2 + 4, 'text-anchor': 'end', class: 'mut', text: 'row ' + r }));
      for (b = 0; b < B; b++) {
        (function (r, b) {
          var word = p.inter === 'low' ? r * B + b : b * p.depth + r;
          if (B === 1) word = r;
          var hit = inStream[word], isLoc = (loc.bank === b && loc.row === r);
          var x = lblW + b * cw, y = topBar + r * chh;
          svg.appendChild(s('rect', { x: x + 1, y: y + 1, width: cw - 2, height: chh - 2, rx: 3, fill: hit ? '#00b9d1' : '#142349', stroke: isLoc ? '#d4af37' : (hit ? 'none' : '#253563'), 'stroke-width': isLoc ? 2.5 : 1, 'stroke-dasharray': isLoc ? null : null }));
          svg.appendChild(s('text', { x: x + cw / 2, y: y + chh / 2 + 4, 'text-anchor': 'middle', style: 'fill:' + (hit ? '#06101f' : '#c0c8d4') + ';font-weight:' + (hit ? 700 : 400), text: hit ? '#' + hit.i + ' w' + word : 'w' + word }));
          items.push({ x: x + cw / 2, y: y + chh / 2, rx: x, ry: y, rw: cw, rh: chh,
            tip: function () { return SF.tipContent('word ' + word, [{ k: 'bank', v: String(b) }, { k: 'row', v: String(r) }].concat(hit ? [{ k: 'stream position', v: '#' + hit.i }] : []).concat(isLoc ? [{ k: 'located', v: 'yes' }] : [])); },
            hl: function (layer) { layer.appendChild(s('rect', { x: x + 0.5, y: y + 0.5, width: cw - 1, height: chh - 1, rx: 3, fill: 'none', stroke: '#e8edf6', 'stroke-width': 2 })); } });
        })(r, b);
      }
    }
    if (p.depth > rowsDraw) svg.appendChild(s('text', { x: lblW, y: topBar + rowsDraw * chh + 18, class: 'mut', text: 'rows ' + rowsDraw + ' .. ' + (p.depth - 1) + ' of each bank are not drawn' }));
    svg.appendChild(over);
    var fr = { svg: svg, over: over, plot: { x: lblW, y: topBar, w: cw * B, h: rowsDraw * chh } };
    SF.interact(fr, items, { mode: 'rect', stride: B });
    c.body.appendChild(h('div', { class: 'chart', style: { overflowX: 'auto' } }, svg));
    var touched = perBank.filter(function (v) { return v > 0; }).length;
    c.body.appendChild(h('div', { class: 'stats' },
      h('div', { class: 'stat' }, h('div', { class: 'l', text: 'Stream' }), h('div', { class: 'v', text: stream.length + ' words' }), h('div', { class: 's', text: 'stride ' + p.stride + ', addresses 0, ' + p.stride + ', ...' })),
      h('div', { class: 'stat' }, h('div', { class: 'l', text: 'Banks touched' }), h('div', { class: 'v', text: touched + ' of ' + B }), h('div', { class: 's', text: touched === 1 && B > 1 ? 'all words in one bank: serial access' : 'accesses can overlap across banks' })),
      h('div', { class: 'stat' }, h('div', { class: 'l', text: 'Word ' + Math.min(p.locate, total - 1) }), h('div', { class: 'v', text: 'bank ' + loc.bank + ', row ' + loc.row }), h('div', { class: 's', text: 'gold outline in the grid' }))));
    c.body.appendChild(SF.legend([{ name: 'word in the access stream (#position)', kind: 'bar', color: '#00b9d1' }, { name: 'word not in the stream', kind: 'bar', color: '#253563' }]));
    c.body.appendChild(SF.tableView('Stream words and where they land (table view)', [
      { label: '#', num: true, get: function (r) { return r.i; } }, { label: 'Word address', num: true, get: function (r) { return r.w; } },
      { label: 'Bank', num: true, get: function (r) { return r.loc.bank; } }, { label: 'Row', num: true, get: function (r) { return r.loc.row; } }], stream, { maxRows: 80 }));
  }
  SF.registerView(2, 'SRAM bank map', 'SRAM bank map',
    'Where each word lives for low and high interleave, and how an access stream spreads across banks. Computed in the browser from the banks and depth you choose.', renderMap);

  // ================================================================== 3. Live transaction timeline (replay)
  S.tl = S.tl || { cur: 0, speed: 8, win: 40, playing: false };
  function renderTimeline(host, refresh) {
    var T = SF.DS.timeline_trace;
    if (!T || !Array.isArray(T.cycles) || !T.cycles.length) {
      host.appendChild(SF.unavailableCard('Transaction timeline replay', { why: T ? 'data/timeline_trace.json is present but contains no recorded cycles.' : SF.absentReason('timeline_trace.json'),
        unlocks: ['Run the data generator (scripts/generate_data.py --only timeline) to record a cycle trace of the verified cycle model.'], source: 'data/timeline_trace.json (sramlab.experiments.timeline_trace)' }));
      return;
    }
    var st = S.tl, N = T.cycles.length, M = T.masters || (T.cycles[0].m || []).length, B = T.banks || (T.cycles[0].g || []).length;
    if (st.cur >= N) st.cur = 0;
    var c = SF.card({ title: 'Cycle-by-cycle bus activity', provs: ['simulated'],
      source: 'data/timeline_trace.json: ' + (T.config || 'recorded trace') + ', ' + N + ' cycles, ' + M + ' masters, ' + B + ' banks (sramlab.experiments.timeline_trace on the verified cycle model)' });
    c.chips.appendChild(h('span', { class: 'replay', title: 'This is a recording, played back in the browser' }, '▶ REPLAY OF A RECORDED SIMULATION'));
    host.appendChild(c.el);
    c.body.appendChild(h('p', { class: 'note', text: 'This is a replay of a recorded simulation, not a live system: nothing here is running a memory. Press Play, step one cycle at a time, or drag the slider.' }));
    var ctlRow = h('div', { class: 'tlctl' });
    var playBtn = h('button', { type: 'button', class: 'btn', 'aria-label': 'Play or pause the replay' }, st.playing ? 'Pause' : 'Play');
    var back = h('button', { type: 'button', class: 'btn', 'aria-label': 'Step back one cycle' }, '◀ step');
    var fwd = h('button', { type: 'button', class: 'btn', 'aria-label': 'Step forward one cycle' }, 'step ▶');
    var rst = h('button', { type: 'button', class: 'btn', 'aria-label': 'Restart from cycle 0' }, 'Restart');
    var speed = SF.select('tl-speed', 'Speed (cycles per second)', [2, 5, 8, 15, 30, 60].map(function (v) { return { v: v }; }), st.speed, function (v) { st.speed = +v; if (st.playing) { stop(); start(); } });
    var win = SF.select('tl-win', 'Window (cycles)', [24, 40, 64].map(function (v) { return { v: v }; }), st.win, function (v) { st.win = +v; draw(); });
    var slider = h('input', { type: 'range', min: 0, max: N - 1, step: 1, value: st.cur, 'aria-label': 'Replay position (cycle)', 'data-ctl': 'tl-scrub' });
    var cycLbl = h('span', { class: 'mono', 'aria-hidden': 'true' });
    ctlRow.appendChild(playBtn); ctlRow.appendChild(back); ctlRow.appendChild(fwd); ctlRow.appendChild(rst); ctlRow.appendChild(speed); ctlRow.appendChild(win);
    c.body.appendChild(ctlRow);
    c.body.appendChild(h('div', { class: 'ctl', style: { marginBottom: '8px' } }, h('span', null, 'Cycle ', cycLbl, ' of ' + (N - 1)), slider));
    var chartHost = h('div', { class: 'chart' }); c.body.appendChild(chartHost);
    var readout = h('div', { class: 'tlread', role: 'status', 'aria-live': 'off' }); c.body.appendChild(readout);
    c.body.appendChild(SF.legend([
      { name: 'request accepted (bank access issued)', kind: 'bar', color: '#00e5ff' },
      { name: 'request waiting (lost arbitration / no credit)', kind: 'bar', color: '#d4af37', hatch: true },
      { name: 'bank grant to master # (colour + number)', kind: 'bar', color: '#8b5cf6' },
      { name: 'response transferred', kind: 'bar', color: '#4ade80' }]));
    if (T.legend) c.body.appendChild(h('p', { class: 'note muted', text: 'Recorded legend: ' + Object.keys(T.legend).map(function (k) { return k + ' = ' + T.legend[k]; }).join(' | ') }));
    var timer = null;
    function stop() { if (timer) clearInterval(timer); timer = null; st.playing = false; playBtn.textContent = 'Play'; }
    function start() { stop(); st.playing = true; playBtn.textContent = 'Pause'; timer = setInterval(function () { if (st.cur >= N - 1) { stop(); draw(); return; } st.cur++; draw(true); }, Math.max(15, 1000 / st.speed)); }
    SF.onLeave(stop);
    playBtn.addEventListener('click', function () { if (st.playing) stop(); else { if (st.cur >= N - 1) st.cur = 0; start(); } draw(); });
    back.addEventListener('click', function () { stop(); st.cur = Math.max(0, st.cur - 1); draw(); });
    fwd.addEventListener('click', function () { stop(); st.cur = Math.min(N - 1, st.cur + 1); draw(); });
    rst.addEventListener('click', function () { stop(); st.cur = 0; draw(); });
    slider.addEventListener('input', function () { st.cur = +slider.value; draw(); });

    var lastStart = -1, svgRoot = null, playhead = null;
    function masterCol(m) { return SF.PAL[m % SF.PAL.length]; }
    function draw(fast) {
      var win = st.win, start0 = Math.max(0, Math.min(N - win, st.cur - Math.round(win * 0.3)));
      if (start0 !== lastStart || !svgRoot || !fast) buildSvg(start0);
      lastStart = start0;
      var pos = st.cur - start0;
      var W = svgRoot.__geom;
      playhead.setAttribute('x', W.l + pos * W.cw - 1); playhead.setAttribute('width', W.cw + 2);
      slider.value = st.cur; cycLbl.textContent = String(T.cycles[st.cur].t);
      var cy = T.cycles[st.cur];
      var ms = (cy.m || []).map(function (v, i) { return 'M' + i + ' ' + (v === 'a' ? 'accepted' : v === 'w' ? 'waiting' : 'idle'); }).join(', ');
      var gs = (cy.g || []).map(function (v, i) { return 'B' + i + ' ' + (v < 0 ? 'idle' : '← M' + v); }).join(', ');
      var rs = (cy.r || []).map(function (v, i) { return v ? 'M' + i : null; }).filter(Boolean).join(', ') || 'none';
      readout.textContent = 'cycle ' + cy.t + '  |  requests: ' + ms + '  |  bank grants: ' + gs + '  |  responses to: ' + rs + '  |  eligible masters per bank: [' + (cy.e || []).join(', ') + ']';
      playBtn.textContent = st.playing ? 'Pause' : 'Play';
    }
    function buildSvg(start0) {
      SF.clear(chartHost);
      var win = st.win, W = SF.width(chartHost), l = 64, cw = Math.max(5, (W - l - 8) / win), rowH = 17, gap = 8;
      var rows = [];
      for (var m = 0; m < M; m++) rows.push({ kind: 'req', i: m, label: 'M' + m + ' req' });
      for (var b = 0; b < B; b++) rows.push({ kind: 'bank', i: b, label: 'B' + b + ' grant' });
      for (m = 0; m < M; m++) rows.push({ kind: 'resp', i: m, label: 'M' + m + ' resp' });
      var secGap = 14, top = 22, H = top + rows.length * rowH + 2 * secGap + 70;
      var svg = s('svg', { viewBox: '0 0 ' + W + ' ' + H, width: W, height: H, role: 'img', 'aria-label': 'Timeline of cycles ' + start0 + ' to ' + (start0 + win - 1) + ' from the recorded simulation' });
      var hid = 'tlh' + start0;
      svg.appendChild(s('defs', null, s('pattern', { id: hid, width: 5, height: 5, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, s('rect', { width: 5, height: 5, fill: '#2a2310' }), s('line', { x1: 0, y1: 0, x2: 0, y2: 5, stroke: '#d4af37', 'stroke-width': 2 }))));
      var yOf = function (ri) { var sec = ri < M ? 0 : ri < M + B ? 1 : 2; return top + ri * rowH + sec * secGap; };
      // cycle ticks
      for (var k = 0; k < win; k++) {
        var t = start0 + k;
        if (t % 5 === 0 || cw > 22) svg.appendChild(s('text', { x: l + k * cw + cw / 2, y: 13, 'text-anchor': 'middle', class: 'mut', text: String(T.cycles[t].t) }));
      }
      rows.forEach(function (r, ri) {
        var y = yOf(ri);
        svg.appendChild(s('text', { x: l - 6, y: y + rowH / 2 + 4, 'text-anchor': 'end', text: r.label }));
        for (var k = 0; k < win; k++) {
          var cyc = T.cycles[start0 + k], x = l + k * cw, w = cw - 1.5, hh = rowH - 3;
          var el = null, txt = null;
          if (r.kind === 'req') {
            var v = (cyc.m || [])[r.i];
            if (v === 'a') el = s('rect', { x: x, y: y, width: w, height: hh, rx: 2, fill: '#00e5ff' });
            else if (v === 'w') el = s('rect', { x: x + 0.7, y: y + 0.7, width: w - 1.4, height: hh - 1.4, rx: 2, fill: 'url(#' + hid + ')', stroke: '#d4af37', 'stroke-width': 1.4 });
            else el = s('circle', { cx: x + w / 2, cy: y + hh / 2, r: 1.5, fill: '#5b6a93' });
          } else if (r.kind === 'bank') {
            var g = (cyc.g || [])[r.i];
            if (g >= 0) { el = s('rect', { x: x, y: y, width: w, height: hh, rx: 2, fill: masterCol(g) }); if (cw >= 14) txt = s('text', { x: x + w / 2, y: y + hh / 2 + 4, 'text-anchor': 'middle', style: 'fill:#06101f;font-weight:700;font-size:11px', text: String(g) }); }
            else el = s('circle', { cx: x + w / 2, cy: y + hh / 2, r: 1.5, fill: '#5b6a93' });
          } else {
            var rv = (cyc.r || [])[r.i];
            if (rv) el = s('path', { d: 'M' + (x + w / 2) + ' ' + y + 'l' + (w / 2) + ' ' + (hh / 2) + 'l' + (-w / 2) + ' ' + (hh / 2) + 'l' + (-w / 2) + ' ' + (-hh / 2) + 'z', fill: '#4ade80' });
            else el = s('circle', { cx: x + w / 2, cy: y + hh / 2, r: 1.5, fill: '#5b6a93' });
          }
          if (el) svg.appendChild(el); if (txt) svg.appendChild(txt);
        }
      });
      // minimap: accepted requests per cycle over the whole recording, with the window marked
      var mmY = top + rows.length * rowH + 2 * secGap + 16, mmH = 34, mmW = W - l - 8, bwid = mmW / N;
      svg.appendChild(s('text', { x: l - 6, y: mmY + mmH / 2 + 4, 'text-anchor': 'end', class: 'mut', text: 'all cycles' }));
      for (var i = 0; i < N; i++) {
        var acc = (T.cycles[i].m || []).filter(function (q) { return q === 'a'; }).length, bh = (acc / Math.max(1, M)) * mmH;
        svg.appendChild(s('rect', { x: l + i * bwid, y: mmY + mmH - bh, width: Math.max(1, bwid - 0.5), height: bh, fill: '#00e5ff', 'fill-opacity': 0.55 }));
      }
      svg.appendChild(s('rect', { x: l + start0 * bwid, y: mmY - 2, width: win * bwid, height: mmH + 4, fill: 'none', stroke: '#d4af37', 'stroke-width': 1.5 }));
      svg.appendChild(s('text', { x: l, y: mmY + mmH + 14, class: 'mut', text: (W > 560 ? 'accepted requests per cycle (0 to ' + M + '); gold box = window shown above' : 'accepted per cycle; gold box = window') }));
      playhead = s('rect', { x: 0, y: 18, width: cw + 2, height: top + rows.length * rowH + 2 * secGap - 14, fill: 'none', stroke: '#e8edf6', 'stroke-width': 1.5, rx: 2 });
      svg.appendChild(playhead);
      svg.__geom = { l: l, cw: cw };
      svgRoot = svg;
      chartHost.appendChild(svg);
    }
    draw();
  }
  SF.registerView(3, 'Live transaction timeline', 'Live transaction timeline (replay)',
    'A replay of a recorded simulation of the cycle model: which master was accepted or kept waiting, which master each bank served and when responses came back. Play, pause, step or scrub.', renderTimeline);
})();
