/* SRAMLab dashboard core: DOM helpers, provenance chips, formatting, tooltip, cards, tables, unavailable panels.
   Everything is hand-written; no libraries.  Labels/values from data are inserted with textContent only. */
(function (root) {
  'use strict';
  var SF = root.SF = {};
  var SVGNS = 'http://www.w3.org/2000/svg';

  // ------------------------------------------------------------------ data
  var DB = { datasets: {}, absent: [], tools: [], trim_notes: [], load_errors: {} };
  try {
    var node = document.getElementById('sramlab-data');
    DB = JSON.parse(node.textContent);
  } catch (e) {
    DB.__error = String(e);
  }
  SF.DB = DB;
  SF.DS = DB.datasets || {};

  // ------------------------------------------------------------------ DOM builders
  function setAttrs(el, attrs) {
    for (var k in attrs) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') el.setAttribute('class', v);
      else if (k === 'text') el.textContent = v;
      else if (k === 'on') { for (var ev in v) el.addEventListener(ev, v[ev]); }
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else el.setAttribute(k, v === true ? '' : String(v));
    }
  }
  function add(el, kids) {
    for (var i = 0; i < kids.length; i++) {
      var k = kids[i];
      if (k === null || k === undefined || k === false) continue;
      if (Array.isArray(k)) add(el, k);
      else el.appendChild(k instanceof Node ? k : document.createTextNode(String(k)));
    }
  }
  function mk(ns) {
    return function (tag, attrs) {
      var kids = Array.prototype.slice.call(arguments, 2);
      if (attrs && (typeof attrs === 'string' || typeof attrs === 'number' || attrs instanceof Node || Array.isArray(attrs))) { kids.unshift(attrs); attrs = null; }
      var el = ns ? document.createElementNS(SVGNS, tag) : document.createElement(tag);
      if (attrs) setAttrs(el, attrs);
      add(el, kids);
      return el;
    };
  }
  SF.h = mk(false);
  SF.s = mk(true);
  var h = SF.h, s = SF.s;
  SF.clear = function (el) { while (el.firstChild) el.removeChild(el.firstChild); return el; };

  // ------------------------------------------------------------------ number formatting
  SF.isNum = function (v) { return typeof v === 'number' && isFinite(v); };
  SF.fmt = function (v, d) {
    if (!SF.isNum(v)) return '—';
    d = d || 3;
    if (v === 0) return '0';
    var a = Math.abs(v);
    if (Number.isInteger(v)) return a >= 1e15 ? String(v) : v.toLocaleString('en-US');
    if (a >= Math.pow(10, d)) return Math.round(v).toLocaleString('en-US');
    var t = Number(v.toPrecision(d));
    if (a < 1e-4) return v.toExponential(d - 1);
    return String(t);
  };
  SF.pct = function (v, d) { return SF.isNum(v) ? SF.fmt(v * 100, d || 3) + ' %' : '—'; };
  // mean +/- half-width (n)
  SF.pm = function (st, d, unit) {
    if (!st || !SF.isNum(st.mean)) return '—';
    var out = SF.fmt(st.mean, d || 4);
    if (SF.isNum(st.half_width) && st.half_width > 0) out += ' ± ' + SF.fmt(st.half_width, 2);
    else if (SF.isNum(st.half_width)) out += ' ± 0';
    if (unit) out += ' ' + unit;
    if (SF.isNum(st.n)) out += ' (n=' + st.n + ')';
    return out;
  };
  SF.stat = function (v) {            // normalise a stat-or-scalar into {m, hw, n}
    if (v && typeof v === 'object') return { m: SF.isNum(v.mean) ? v.mean : (SF.isNum(v.value) ? v.value : null), hw: SF.isNum(v.half_width) ? v.half_width : null, n: SF.isNum(v.n) ? v.n : null };
    return { m: SF.isNum(v) ? v : null, hw: null, n: null };
  };
  SF.get = function (o) {             // safe deep get: SF.get(obj, 'a', 'b', 0)
    for (var i = 1; i < arguments.length; i++) { if (o === null || o === undefined) return undefined; o = o[arguments[i]]; }
    return o;
  };
  SF.uniq = function (arr) { var seen = {}, out = []; arr.forEach(function (v) { if (!seen[v]) { seen[v] = 1; out.push(v); } }); return out; };
  SF.sortNum = function (arr) { return arr.slice().sort(function (a, b) { return a - b; }); };
  SF.sum = function (a) { return a.reduce(function (p, c) { return p + c; }, 0); };

  // ------------------------------------------------------------------ provenance
  // Dataset label -> dashboard class (matches sramlab.provenance.DASHBOARD_CLASS).  MEASURED never exists.
  var CLASS_LABEL = { analytical: 'ANALYTICAL', simulated: 'SIMULATED', synthesized: 'SYNTHESIZED', unavailable: 'UNAVAILABLE', unverified: 'UNCLASSIFIED' };
  function glyph(kind) {
    var g = s('svg', { viewBox: '0 0 10 10', 'aria-hidden': 'true', focusable: 'false' });
    if (kind === 'analytical') g.appendChild(s('path', { d: 'M5 1 L9 5 L5 9 L1 5 Z', fill: 'none', stroke: 'currentColor', 'stroke-width': 1.3, 'stroke-dasharray': '2 1.2' }));
    else if (kind === 'simulated') g.appendChild(s('circle', { cx: 5, cy: 5, r: 3.6, fill: 'currentColor' }));
    else if (kind === 'synthesized') g.appendChild(s('rect', { x: 1.5, y: 1.5, width: 7, height: 7, fill: 'currentColor' }));
    else if (kind === 'unavailable') { g.appendChild(s('circle', { cx: 5, cy: 5, r: 3.6, fill: 'none', stroke: 'currentColor', 'stroke-width': 1.2 })); g.appendChild(s('path', { d: 'M2.4 7.6 L7.6 2.4', stroke: 'currentColor', 'stroke-width': 1.2 })); }
    else g.appendChild(s('path', { d: 'M5 1.2 L9 8.8 L1 8.8 Z', fill: 'none', stroke: 'currentColor', 'stroke-width': 1.2 }));
    return g;
  }
  SF.glyph = glyph;
  // -> {key, label, sub} for one dataset provenance word
  function classify(word) {
    var w = String(word || '').toLowerCase().trim();
    if (w === 'rtl_simulated' || w === 'rtl-simulated') return { key: 'simulated', sub: 'RTL' };
    if (w === 'assumed') return { key: 'analytical', sub: 'assumed' };
    if (w === 'analytical' || w === 'simulated' || w === 'synthesized' || w === 'unavailable') return { key: w };
    if (w.indexOf('analytical-from-simulated') === 0) return { key: 'analytical', sub: 'from simulated' };
    if (w.indexOf('synth') === 0) return { key: 'synthesized' };
    if (w.indexOf('unavail') === 0) return { key: 'unavailable' };
    if (w.indexOf('simulated') === 0) return { key: 'simulated' };
    if (w.indexOf('analytical') === 0) return { key: 'analytical' };
    return { key: 'unverified', sub: w || 'unlabelled' };
  }
  SF.classify = classify;
  // One chip for one class.  opts.sub overrides/extends the annotation.
  SF.chip = function (word, opts) {
    opts = opts || {};
    var c = classify(word);
    var sub = opts.sub || c.sub;
    var key = c.key;
    var label = CLASS_LABEL[key] || 'UNCLASSIFIED';
    if (key === 'unverified') { var w0 = String(word || '').toLowerCase(); sub = (w0 && w0 !== 'unverified' && w0 !== 'unclassified') ? 'label "' + w0.slice(0, 24) + '" is not a provenance class' : (opts.sub || 'no provenance class assigned'); }
    var chip = h('span', { class: 'chip', 'data-prov': key, title: opts.title || (label + (sub ? ' (' + sub + ')' : '')) }, glyph(key), label, sub ? h('span', { class: 'sub', text: sub }) : null);
    return chip;
  };
  // A dataset label may combine classes ("simulated+analytical"): one chip per class.
  SF.chips = function (spec) {
    var out = [];
    (Array.isArray(spec) ? spec : [spec]).forEach(function (sp) {
      if (sp && typeof sp === 'object' && !(sp instanceof Node)) { out.push(SF.chip(sp.label, sp)); return; }
      if (sp instanceof Node) { out.push(sp); return; }
      String(sp || '').split('+').forEach(function (p) { if (p.trim()) out.push(SF.chip(p.trim())); });
    });
    return out;
  };
  SF.measuredNoneChip = function () {
    return h('span', { class: 'chip', 'data-prov': 'measured-none', title: 'No silicon or FPGA measurement exists' }, glyph('x'), 'MEASURED', h('span', { class: 'sub', text: 'none exists' }));
  };
  // headline provenance class of a tagged value {value, provenance}
  SF.provOf = function (t) { return t && typeof t === 'object' ? t.provenance : undefined; };
  SF.isUnavail = function (t) { return t === null || t === undefined || (typeof t === 'object' && !Array.isArray(t) && t.provenance === 'unavailable') || (typeof t === 'object' && t !== null && 'value' in t && t.value === null); };

  // ------------------------------------------------------------------ series styling (colour follows the entity)
  SF.PAL = ['#00e5ff', '#8b5cf6', '#d4af37', '#4ade80', '#f472b6'];
  SF.MARKERS = ['circle', 'square', 'diamond', 'triangle', 'tdown'];
  SF.style = function (i) { return { color: SF.PAL[i % SF.PAL.length], marker: SF.MARKERS[i % SF.MARKERS.length] }; };
  var WL = ['rand_read', 'mixed', 'seq_read', 'hotspot', 'contention'];
  SF.workloadStyle = function (name) { var i = WL.indexOf(name); return SF.style(i < 0 ? WL.length : i); };
  SF.SURFACE = '#0f1a3a';
  SF.SILVER = '#c0c8d4';

  SF.markerEl = function (shape, cx, cy, r, color, extra) {
    var a = Object.assign({ fill: color, stroke: SF.SURFACE, 'stroke-width': 2, 'paint-order': 'stroke' }, extra || {});
    var el;
    if (shape === 'square') el = s('rect', Object.assign({ x: cx - r, y: cy - r, width: 2 * r, height: 2 * r, rx: 1 }, a));
    else if (shape === 'diamond') el = s('path', Object.assign({ d: 'M' + cx + ' ' + (cy - r * 1.3) + 'L' + (cx + r * 1.3) + ' ' + cy + 'L' + cx + ' ' + (cy + r * 1.3) + 'L' + (cx - r * 1.3) + ' ' + cy + 'Z' }, a));
    else if (shape === 'triangle') el = s('path', Object.assign({ d: 'M' + cx + ' ' + (cy - r * 1.2) + 'L' + (cx + r * 1.15) + ' ' + (cy + r * 0.95) + 'L' + (cx - r * 1.15) + ' ' + (cy + r * 0.95) + 'Z' }, a));
    else if (shape === 'tdown') el = s('path', Object.assign({ d: 'M' + cx + ' ' + (cy + r * 1.2) + 'L' + (cx + r * 1.15) + ' ' + (cy - r * 0.95) + 'L' + (cx - r * 1.15) + ' ' + (cy - r * 0.95) + 'Z' }, a));
    else el = s('circle', Object.assign({ cx: cx, cy: cy, r: r }, a));
    return el;
  };

  // small SVG key (line + marker) used in legends and tooltips
  SF.keySvg = function (st, w) {
    w = w || 28;
    var svg = s('svg', { viewBox: '0 0 ' + w + ' 12', width: w, height: 12, 'aria-hidden': 'true', focusable: 'false' });
    if (st.kind === 'bar') {
      svg.appendChild(s('rect', { x: 4, y: 1, width: w - 8, height: 10, rx: 2, fill: st.hatch ? 'url(#sfhatch-key-' + st.color.slice(1) + ')' : st.color, stroke: st.hatch ? st.color : 'none', 'stroke-width': 1.5 }));
      if (st.hatch) {
        var defs = s('defs', null, s('pattern', { id: 'sfhatch-key-' + st.color.slice(1), width: 5, height: 5, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, s('rect', { width: 5, height: 5, fill: 'transparent' }), s('line', { x1: 0, y1: 0, x2: 0, y2: 5, stroke: st.color, 'stroke-width': 2 })));
        svg.insertBefore(defs, svg.firstChild);
      }
      return svg;
    }
    svg.appendChild(s('line', { x1: 1, y1: 6, x2: w - 1, y2: 6, stroke: st.color, 'stroke-width': 2, 'stroke-linecap': 'round', 'stroke-dasharray': st.dash || null }));
    if (st.marker) svg.appendChild(SF.markerEl(st.marker, w / 2, 6, 3.6, st.color));
    return svg;
  };
  SF.legend = function (items) {
    return h('div', { class: 'legend', role: 'list' }, items.map(function (it) {
      return h('span', { class: 'it', role: 'listitem' }, SF.keySvg(it), it.name, it.sub ? h('span', { class: 'sub', text: it.sub }) : null);
    }));
  };

  // ------------------------------------------------------------------ tooltip
  var tipEl = null;
  function tipNode() { return tipEl || (tipEl = document.getElementById('tip')); }
  SF.tipContent = function (title, rows, foot) {
    var box = h('div', null, title ? h('div', { class: 'tt', text: title }) : null);
    (rows || []).forEach(function (r) {
      box.appendChild(h('div', { class: 'r' }, r.key ? SF.keySvg(r.key, 22) : null, h('span', { class: 'k', text: r.k }), h('span', { class: 'v', text: r.v })));
    });
    if (foot) box.appendChild(h('div', { class: 'f', text: foot }));
    return box;
  };
  SF.tip = {
    show: function (content, cx, cy) {
      var t = tipNode(); if (!t) return;
      SF.clear(t); t.appendChild(content); t.hidden = false;
      var r = t.getBoundingClientRect(), vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight;
      var x = cx + 14, y = cy + 14;
      if (x + r.width > vw - 6) x = Math.max(6, cx - r.width - 14);
      if (y + r.height > vh - 6) y = Math.max(6, cy - r.height - 14);
      t.style.left = x + 'px'; t.style.top = y + 'px';
    },
    hide: function () { var t = tipNode(); if (t) t.hidden = true; }
  };

  // ------------------------------------------------------------------ cards / panels
  SF.card = function (o) {
    var chips = h('div', { class: 'chips' }, SF.chips(o.provs || []));
    var body = h('div', { class: 'cbody' });
    var el = h('section', { class: 'card' + (o.cls ? ' ' + o.cls : ''), 'aria-label': o.title },
      h('div', { class: 'chead' }, h('h3', { text: o.title }), chips),
      o.note ? h('p', { class: 'note' + (o.warn ? ' warn' : ''), text: o.note }) : null,
      body,
      o.source ? h('div', { class: 'src' }, 'source: ', o.source) : null);
    return { el: el, body: body, chips: chips };
  };
  // Explicit empty state: says why, lists what would unlock it.  Never a blank chart.
  SF.unavailable = function (o) {
    var ul = (o.unlocks && o.unlocks.length) ? h('ul', null, o.unlocks.map(function (u) { return h('li', { text: u }); })) : null;
    return h('div', { class: 'unavail', role: 'note' },
      SF.chip('unavailable'),
      h('div', { class: 'why', text: o.why }),
      o.detail ? h('div', { class: 'muted', text: o.detail }) : null,
      ul ? h('div', { class: 'unlock' }, h('b', { text: 'What would unlock it' }), ul) : null,
      o.source ? h('div', { class: 'src', style: { borderTop: '0', paddingTop: '0' } }, 'expected source: ', o.source) : null);
  };
  SF.unavailableCard = function (title, o) {
    var c = SF.card({ title: title, provs: ['unavailable'], source: o.source || null });
    c.body.appendChild(SF.unavailable(Object.assign({}, o, { source: null })));
    return c.el;
  };
  SF.controls = function () { return h('div', { class: 'controls', role: 'group', 'aria-label': 'Panel controls' }, Array.prototype.slice.call(arguments)); };
  // <select> control.  opts: [{v, t}] ; onChange(valueString)
  SF.select = function (id, label, opts, value, onChange) {
    var sel = h('select', { id: 'ctl-' + id, 'data-ctl': id });
    opts.forEach(function (o) {
      var op = h('option', { value: String(o.v), text: o.t === undefined ? String(o.v) : o.t });
      if (String(o.v) === String(value)) op.selected = true;
      sel.appendChild(op);
    });
    sel.addEventListener('change', function () { onChange(sel.value); });
    return h('label', { class: 'ctl', for: 'ctl-' + id }, label, sel);
  };
  SF.segmented = function (id, label, opts, value, onChange) {
    var grp = h('div', { class: 'seg', role: 'group', 'aria-label': label });
    opts.forEach(function (o) {
      grp.appendChild(h('button', { type: 'button', 'data-ctl': id + ':' + o.v, 'aria-pressed': String(o.v) === String(value) ? 'true' : 'false', on: { click: function () { onChange(String(o.v)); } } }, o.t === undefined ? String(o.v) : o.t));
    });
    return h('div', { class: 'ctl' }, label, grp);
  };
  SF.note = function (text, warn) { return h('p', { class: 'note' + (warn ? ' warn' : ''), text: text }); };

  // ------------------------------------------------------------------ tables
  // cols: [{label, get(row) -> value|Node, num:bool, title, sort(row)->number|string}]
  SF.table = function (cols, rows, o) {
    o = o || {};
    var state = { col: o.sortCol === undefined ? -1 : o.sortCol, dir: o.sortDir || 1 };
    var wrap = h('div', { class: 'tablewrap', tabindex: '0', role: 'region', 'aria-label': o.caption || 'Data table' });
    var tbl = h('table', { class: 'data' });
    wrap.appendChild(tbl);
    function draw() {
      SF.clear(tbl);
      if (o.caption) tbl.appendChild(h('caption', { class: 'tcap', text: o.caption, style: { captionSide: 'bottom', textAlign: 'left' } }));
      var tr = h('tr');
      cols.forEach(function (c, i) {
        var th = h('th', { class: c.num ? 'r' : '', scope: 'col', title: c.title || null, 'aria-sort': state.col === i ? (state.dir > 0 ? 'ascending' : 'descending') : 'none' });
        var b = h('button', { type: 'button', class: 'thbtn', on: { click: function () { if (state.col === i) state.dir = -state.dir; else { state.col = i; state.dir = 1; } draw(); } } }, c.label, state.col === i ? (state.dir > 0 ? ' ▲' : ' ▼') : '');
        th.appendChild(b); tr.appendChild(th);
      });
      tbl.appendChild(h('thead', null, tr));
      var data = rows.slice();
      if (state.col >= 0) {
        var c = cols[state.col], key = c.sort || c.get;
        data.sort(function (a, b) {
          var x = key(a), y = key(b);
          if (x instanceof Node) x = x.textContent; if (y instanceof Node) y = y.textContent;
          var xn = typeof x === 'number', yn = typeof y === 'number';
          if (x === null || x === undefined || (xn && !isFinite(x))) return 1;
          if (y === null || y === undefined || (yn && !isFinite(y))) return -1;
          return (xn && yn ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true })) * state.dir;
        });
      }
      var more = 0, max = o.maxRows || 5000;
      if (data.length > max) { more = data.length - max; data = data.slice(0, max); }
      var tb = h('tbody');
      data.forEach(function (r) {
        var row = h('tr');
        if (o.onRow) {
          row.setAttribute('tabindex', '0'); row.style.cursor = 'pointer';
          row.addEventListener('click', function () { o.onRow(r, row); });
          row.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); o.onRow(r, row); } });
        }
        cols.forEach(function (c) {
          var v = c.get(r);
          var td = h('td', { class: (c.num ? 'r ' : '') + (c.mono ? 'mono ' : '') + (typeof v === 'string' && v.length > 40 ? 'wrap' : '') });
          if (v instanceof Node) td.appendChild(v); else td.textContent = (v === null || v === undefined || (typeof v === 'number' && !isFinite(v))) ? '—' : String(v);
          row.appendChild(td);
        });
        tb.appendChild(row);
      });
      tbl.appendChild(tb);
      if (more) tbl.appendChild(h('tfoot', null, h('tr', null, h('td', { colspan: cols.length, class: 'muted', text: more + ' more rows not shown' }))));
    }
    draw();
    return wrap;
  };
  // collapsible table view attached under a chart (a table view always exists for every chart)
  SF.tableView = function (title, cols, rows, o) {
    return h('details', { class: 'tableview' }, h('summary', { text: title || 'Table view' }), SF.table(cols, rows, o));
  };

  // ------------------------------------------------------------------ misc
  SF.reducedMotion = function () { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } };
  SF.cls = function (n) { return n; };
  SF.width = function (host, min, max) {
    var w = host.clientWidth || (host.parentElement && host.parentElement.clientWidth) || 640;
    return Math.max(min || 260, Math.min(max || 1180, Math.floor(w)));
  };
  SF.views = {};
  SF.registerView = function (n, short, title, lede, render) { SF.views[n] = { n: n, short: short, title: title, lede: lede, render: render }; };
  SF.state = {};
  SF.dsText = function (name) { return 'data/' + name; };
  SF.absentReason = function (file) {
    var le = SF.DB.load_errors || {};
    if (le[file]) return file + ' exists but could not be read (' + le[file] + ').';
    return 'data/' + file + ' is not present in the data directory this dashboard was built from.';
  };
})(window);
