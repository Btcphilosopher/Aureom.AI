/* Views 9-12: ECC overhead, MBIST results, area, power.  The ECC / MBIST / physical / power / thermal datasets are
   produced by other tools and are tagged trees ({value, provenance, source|reason}); a generic tagged-tree renderer
   shows them without assuming a layout, and anything unavailable is shown with its reason. */
(function () {
  'use strict';
  var SF = window.SF, h = SF.h, s = SF.s;
  var S = SF.state;

  // ------------------------------------------------------------------ generic tagged-tree rendering
  var HIDE = { run_dir: 1, exe: 1, files: 1, tiling_detail: 1 };
  function isTagged(o) { return o && typeof o === 'object' && !Array.isArray(o) && typeof o.provenance === 'string' && 'value' in o; }
  function prettyKey(k) { return String(k).replace(/\[\]/g, '').replace(/_/g, ' ').replace(/\./g, ' › '); }
  function short(v) {
    if (v === null || v === undefined) return '—';
    if (typeof v === 'number') return SF.fmt(v, 5);
    if (typeof v === 'boolean') return v ? 'yes' : 'no';
    if (Array.isArray(v)) return v.length > 8 ? '[' + v.slice(0, 8).map(short).join(', ') + ', … ' + v.length + ' values]' : '[' + v.map(short).join(', ') + ']';
    if (typeof v === 'object') { var j = JSON.stringify(v); return j.length > 90 ? j.slice(0, 90) + '…' : j; }
    return String(v);
  }
  function walk(o, path, out) {
    if (isTagged(o)) { out.tagged.push({ path: path, t: o }); return; }
    if (Array.isArray(o)) {
      if (o.length && o.some(function (x) { return x && typeof x === 'object' && !Array.isArray(x); })) { out.tables.push({ path: path, rows: o.filter(function (x) { return x && typeof x === 'object'; }) }); return; }
      out.scalars.push({ path: path, v: o }); return;
    }
    if (o && typeof o === 'object') { Object.keys(o).forEach(function (k) { if (!HIDE[k]) walk(o[k], path ? path + '.' + k : k, out); }); return; }
    if (typeof o === 'string' && (o.length > 70 || /(^|\.)(note|scope|statement|reason|caveat|coverage)/i.test(path))) out.notes.push({ path: path, text: o });
    else out.scalars.push({ path: path, v: o });
  }
  function docClasses(o, set) {
    set = set || {};
    if (isTagged(o)) { set[o.provenance] = 1; return set; }
    if (Array.isArray(o)) { o.forEach(function (x) { docClasses(x, set); }); return set; }
    if (o && typeof o === 'object') Object.keys(o).forEach(function (k) { if (!HIDE[k]) docClasses(o[k], set); });
    return set;
  }
  function classesOf(out, docLabel, whole) {
    var set = {};
    out.tagged.forEach(function (x) { set[x.t.provenance] = 1; });
    out.tables.forEach(function (t) { t.rows.forEach(function (r) { Object.keys(r).forEach(function (k) { if (isTagged(r[k])) set[r[k].provenance] = 1; }); if (typeof r.provenance === 'string') set[r.provenance] = 1; if (typeof r.label === 'string' && /^(analytical|simulated|rtl_simulated|synthesized|unavailable|assumed)/.test(r.label)) set[r.label] = 1; }); });
    var keys = Object.keys(set);
    if (!keys.length && whole !== undefined) keys = Object.keys(docClasses(whole));
    if (!keys.length && docLabel && /^(analytical|simulated|rtl_simulated|synthesized|unavailable|assumed)/.test(docLabel)) keys = [docLabel];
    // fold to dashboard classes, one chip per class (RTL kept as annotation)
    var seen = {}, chips = [];
    keys.forEach(function (k) { var c = SF.classify(k); var id = c.key + (c.sub || ''); if (!seen[id]) { seen[id] = 1; chips.push({ label: k }); } });
    return chips.length ? chips : ['unavailable'];
  }
  function cellNode(v) {
    if (isTagged(v)) {
      var unav = v.provenance === 'unavailable' || v.value === null;
      var span = h('span', { title: unav ? (v.reason || 'unavailable') : (v.source || '') }, unav ? 'unavailable' : short(v.value) + (v.unit ? ' ' + v.unit : ''));
      return h('span', null, span, ' ', SF.chip(v.provenance));
    }
    return h('span', { text: short(v) });
  }
  // table from rows of objects
  function rowsTable(rows, caption) {
    var cols = [];
    rows.slice(0, 40).forEach(function (r) { Object.keys(r).forEach(function (k) { if (!HIDE[k] && cols.indexOf(k) < 0) cols.push(k); }); });
    cols = cols.slice(0, 14);
    return SF.table(cols.map(function (k) {
      var numeric = rows.every(function (r) { var v = isTagged(r[k]) ? r[k].value : r[k]; return v === undefined || v === null || typeof v === 'number'; });
      return { label: prettyKey(k), num: numeric, get: function (r) { return cellNode(r[k]); }, sort: function (r) { var v = isTagged(r[k]) ? r[k].value : r[k]; return typeof v === 'object' ? JSON.stringify(v) : v; } };
    }), rows, { caption: caption, maxRows: 400 });
  }
  function taggedTable(items) {
    return SF.table([
      { label: 'Quantity', get: function (x) { return prettyKey(x.path); } },
      { label: 'Value', num: true, get: function (x) { var t = x.t; return t.provenance === 'unavailable' || t.value === null ? 'unavailable' : short(t.value) + (t.unit ? ' ' + t.unit : ''); }, sort: function (x) { return typeof x.t.value === 'number' ? x.t.value : null; } },
      { label: 'Class', get: function (x) { return SF.chip(x.t.provenance); }, sort: function (x) { return x.t.provenance; } },
      { label: 'Source / reason', get: function (x) { var t = x.t; return t.provenance === 'unavailable' ? (t.reason || 'no reason recorded') : (t.source || ''); } }], items, { caption: 'Every value carries its own provenance class; unavailable values stay unavailable and state why.', maxRows: 500 });
  }
  // numeric column auto-bar for a table (when the dataset gives no better chart)
  function autoBar(host, tbl, selId, provHint) {
    var rows = tbl.rows.slice(0, 40);
    if (rows.length < 2) return;
    var val = function (r, k) { var v = isTagged(r[k]) ? r[k].value : r[k]; return typeof v === 'number' && isFinite(v) ? v : null; };
    var cols = [];
    rows.forEach(function (r) { Object.keys(r).forEach(function (k) { if (cols.indexOf(k) < 0) cols.push(k); }); });
    var numCols = cols.filter(function (k) { return rows.filter(function (r) { return val(r, k) !== null; }).length >= rows.length * 0.6 && !/^(seed|n|banks|masters|max_out|perf|rows|k|dw|word_bits|data_width|bank_depth|depth|window|id|uniform_lat|latches|mapped_cells|status|top|runtime_s|cached)$/.test(k); });
    if (!numCols.length) return;
    var labelOf = function (r, i) {
      var parts = [];
      ['label', 'name', 'scenario', 'algorithm', 'algo', 'case', 'id', 'mode', 'ecc', 'rl', 'banks', 'word_bits', 'dw', 'k', 'words', 'rows'].forEach(function (k) { if (r[k] !== undefined && typeof r[k] !== 'object' && parts.length < 3) parts.push(String(r[k]).slice(0, 28)); });
      return parts.length ? parts.join(' · ') : '#' + (i + 1);
    };
    S.auto = S.auto || {};
    var cur = S.auto[selId]; if (numCols.indexOf(cur) < 0) cur = numCols[0];
    var box = h('div');
    function draw() {
      SF.clear(box);
      var vals = rows.map(function (r) { return val(r, cur); });
      var firstTag = rows.map(function (r) { return r[cur]; }).filter(isTagged)[0];
      var chips = firstTag ? [firstTag.provenance] : provHint;
      var card = SF.card({ title: prettyKey(tbl.path) + ': ' + prettyKey(cur), provs: chips, source: 'dataset field ' + tbl.path + '.' + cur });
      box.appendChild(card.el);
      card.body.appendChild(SF.controls(SF.select(selId, 'Column', numCols.map(function (k) { return { v: k, t: prettyKey(k) }; }), cur, function (v) { S.auto[selId] = v; cur = v; draw(); })));
      var anyHatch = chips.length && SF.classify(chips[0] && chips[0].label || chips[0]).key === 'analytical';
      SF.groupedBars(card.body, { aria: prettyKey(cur) + ' per row', cats: rows.map(labelOf), series: [{ id: 'v', name: prettyKey(cur), color: anyHatch ? SF.SILVER : SF.PAL[0], hatch: anyHatch, vals: vals }], yLabel: prettyKey(cur), legend: false, height: 260, valueLabels: rows.length <= 8 });
    }
    draw();
    host.appendChild(box);
  }
  // render a whole tagged document as cards
  function renderTree(host, doc, o) {
    o = o || {};
    var tops = Object.keys(doc).filter(function (k) { return !HIDE[k] && doc[k] !== null && typeof doc[k] === 'object'; });
    var scalars = Object.keys(doc).filter(function (k) { return doc[k] === null || typeof doc[k] !== 'object'; });
    if (o.skip) tops = tops.filter(function (k) { return o.skip.indexOf(k) < 0; });
    var head = h('dl', { class: 'kv' });
    scalars.forEach(function (k) { if (typeof doc[k] === 'string' && doc[k].length > 140) return; head.appendChild(h('dt', { text: prettyKey(k) })); head.appendChild(h('dd', { text: short(doc[k]) })); });
    var longNotes = scalars.filter(function (k) { return typeof doc[k] === 'string' && doc[k].length > 140; });
    if (head.childNodes.length || longNotes.length) {
      var c0 = SF.card({ title: o.metaTitle || 'Study record', provs: classesOf({ tagged: [], tables: [], notes: [], scalars: [] }, doc.label || o.label, doc), source: o.source });
      if (head.childNodes.length) c0.body.appendChild(head);
      longNotes.forEach(function (k) { c0.body.appendChild(h('p', { class: 'note', text: prettyKey(k) + ': ' + doc[k] })); });
      host.appendChild(c0.el);
    }
    tops.forEach(function (k) {
      var out = { tagged: [], tables: [], notes: [], scalars: [] };
      walk(doc[k], '', out);
      if (isTagged(doc[k])) out.tagged = [{ path: k, t: doc[k] }];
      if (k === 'unavailable_items' && Array.isArray(doc[k])) {
        var cu = SF.card({ title: 'Items the study could not produce', provs: ['unavailable'], source: o.source });
        cu.body.appendChild(SF.table([{ label: 'Unavailable item (path in the study record)', get: function (x) { return x; } }], doc[k].map(String)));
        host.appendChild(cu.el);
        return;
      }
      if (Array.isArray(doc[k]) ? !doc[k].length : (!isTagged(doc[k]) && !Object.keys(doc[k]).length)) return;   // empty sections are omitted
      var card = SF.card({ title: prettyKey(k), provs: classesOf(out, doc[k] && doc[k].label || doc.label || o.label, doc[k]), source: (o.source || '') + (o.source ? ' › ' : '') + k });
      host.appendChild(card.el);
      out.notes.forEach(function (n) { card.body.appendChild(h('p', { class: 'note', text: (n.path ? prettyKey(n.path) + ': ' : '') + n.text })); });
      if (out.scalars.length) {
        var kv = h('dl', { class: 'kv' });
        out.scalars.forEach(function (x) { kv.appendChild(h('dt', { text: prettyKey(x.path) })); kv.appendChild(h('dd', { text: short(x.v) })); });
        card.body.appendChild(kv);
      }
      if (out.tagged.length) { card.body.appendChild(taggedTable(out.tagged)); }
      out.tables.forEach(function (t, i) {
        card.body.appendChild(h('div', { style: { height: '10px' } }));
        card.body.appendChild(rowsTable(t.rows, prettyKey(t.path || k) + ' (' + t.rows.length + ' rows)'));
        if (i < 2) { var wrap = h('div', { style: { marginTop: '12px' } }); card.body.appendChild(wrap); autoBar(wrap, { path: (t.path || k), rows: t.rows }, 'auto-' + k + '-' + i, classesOf({ tagged: [], tables: [t], notes: [], scalars: [] }, doc.label, t.rows)); }
      });
      if (!out.tagged.length && !out.tables.length && !out.scalars.length && !out.notes.length) card.body.appendChild(SF.note('This section of the record is empty.'));
    });
  }

  function missingStudy(title, file, how, unlocks) {
    return SF.unavailableCard(title, { why: SF.absentReason(file), detail: how, unlocks: unlocks, source: 'data/' + file });
  }

  // ------------------------------------------------------------------ helpers for the ECC / MBIST record shapes
  function tv(x) { return isTagged(x) ? x.value : x; }
  function pvOf(x, dflt) { return isTagged(x) ? x.provenance : dflt; }
  function guard(host, title, fn) {
    try { fn(); } catch (e) { host.appendChild(SF.unavailableCard(title, { why: 'This section of the record has an unexpected shape and could not be drawn (' + (e && e.message ? e.message : e) + '). It is still listed in the full record below.' })); }
  }
  function verbatim(card, list, title) {
    if (!Array.isArray(list) || !list.length) return;
    card.body.appendChild(h('div', { class: 'kicker', text: title || 'Notes (verbatim from the record)' }));
    card.body.appendChild(h('ul', { style: { margin: '4px 0 0 1.1em', padding: 0, color: 'var(--silver)', fontSize: '12.5px' } }, list.map(function (t) { return h('li', { text: String(t) }); })));
  }
  function fullRecord(host, doc, skip, o) {
    var d = h('details', { class: 'tableview', style: { marginTop: '8px' } }, h('summary', { text: 'Full study record (every section, every value with its class)' }));
    var inner = h('div', { style: { marginTop: '12px' } }); d.appendChild(inner); host.appendChild(d);
    var rest = Object.assign({}, doc); (skip || []).forEach(function (k) { delete rest[k]; });
    renderTree(inner, rest, o);
  }
  function cfgName(k) { return String(k).replace(/_/g, ' '); }
  var ECC_SRC = 'data/ecc_study.json (sramlab.studies.ecc)';

  // ================================================================== 9. ECC overhead
  function secdedBits(k) { var r = 1; while ((1 << r) < k + r + 1) r++; return k + r + 1; }
  function renderEcc(host, refresh) {
    var E = SF.DS.ecc_study;
    // closed-form storage overhead: always computable, always labelled ANALYTICAL
    var ks = [8, 16, 32, 64, 128, 256], rows = ks.map(function (k) { var st = secdedBits(k); return { k: k, stored: st, check: st - k, ratio: st / k }; });
    var c = SF.card({ title: 'SECDED storage overhead vs data width', provs: [{ label: 'analytical', sub: 'closed form' }],
      note: 'Extended-Hamming SECDED: smallest r with 2^r >= k + r + 1 check bits, plus one overall parity bit. This is pure arithmetic on the code definition (39/32, 72/64, 137/128); it says nothing about area, timing or power.',
      source: 'computed in this page; same arithmetic as sramlab/tech.py secded_stored_bits()' + (E && E.storage_overhead ? '; compared with data/ecc_study.json storage_overhead below' : '') });
    host.appendChild(c.el);
    SF.stackedBars(c.body, { aria: 'Stored bits per word: data bits plus ECC check bits', cats: rows.map(function (r) { return r.k + '-bit word'; }), yLabel: 'Stored bits per word', unit: 'bits', height: 270,
      series: [{ id: 'data', name: 'data bits', color: SF.PAL[0], vals: rows.map(function (r) { return r.k; }) }, { id: 'chk', name: 'ECC check bits (analytical)', color: SF.SILVER, hatch: true, vals: rows.map(function (r) { return r.check; }) }] });
    c.body.appendChild(SF.tableView('Storage overhead table', [{ label: 'Data bits (k)', num: true, get: function (r) { return r.k; } }, { label: 'Stored bits', num: true, get: function (r) { return r.stored; } },
      { label: 'Check bits', num: true, get: function (r) { return r.check; } }, { label: 'Stored / data', num: true, get: function (r) { return SF.fmt(r.ratio, 4); } }, { label: 'Storage overhead', num: true, get: function (r) { return SF.pct(r.ratio - 1, 3); } }], rows));
    if (!E || typeof E !== 'object') {
      host.appendChild(h('div', { style: { height: '16px' } }));
      host.appendChild(missingStudy('ECC study results (decoder latency, read-modify-write, scrub, fault reporting, codec gate counts)', 'ecc_study.json',
        'The RTL-based ECC study has not been run for this dataset directory, so none of its RTL-simulated or synthesized quantities can be shown. No value is substituted.',
        ['Run the ECC study (it needs Verilator and, for gate counts, Yosys) so that data/ecc_study.json is written.', 'Codec area needs a technology library; gate counts alone are never shown as area.']));
      return;
    }
    var gap = function () { host.appendChild(h('div', { style: { height: '16px' } })); };
    // --- dataset storage section vs closed form
    guard(host, 'ECC storage widths from the study', function () {
      var so = E.storage_overhead; if (!so) return;
      var ents = Object.keys(so).map(function (k) { return { k: k, d: so[k] }; });
      var allMatch = ents.every(function (e) { return tv(e.d.ecc_on_stored_bits_per_word) === secdedBits(e.d.data_bits); });
      c.body.appendChild(h('p', { class: 'note', text: allMatch ? 'The study’s stored widths (' + ents.map(function (e) { return tv(e.d.ecc_on_stored_bits_per_word) + '/' + e.d.data_bits; }).join(', ') + ') equal this arithmetic.' : 'The study’s stored widths differ from the closed form: check the table below.', style: { marginTop: '8px' } }));
      c.body.appendChild(SF.tableView('Study storage section (ecc_study.json storage_overhead)', [{ label: 'Data bits', num: true, get: function (e) { return e.d.data_bits; } }, { label: 'Stored, ECC off', num: true, get: function (e) { return tv(e.d.ecc_off_stored_bits_per_word); } },
        { label: 'Stored, ECC on', num: true, get: function (e) { return tv(e.d.ecc_on_stored_bits_per_word); } }, { label: 'Hamming check bits', num: true, get: function (e) { return tv(e.d.check_bits_hamming); } }, { label: 'Overall parity', num: true, get: function (e) { return tv(e.d.overall_parity_bits); } },
        { label: 'Storage overhead %', num: true, get: function (e) { return tv(e.d.storage_overhead_pct); } }, { label: 'Class', get: function (e) { return SF.chip(pvOf(e.d.ecc_on_stored_bits_per_word, 'unavailable')); } }], ents));
    });
    // --- decoder latency
    guard(host, 'ECC decoder latency', function () {
      var bc = SF.get(E, 'latency', 'by_config'); if (!bc) return;
      var ops = ['read', 'write_full', 'write_partial', 'write_be0'], cats = [], off = [], on = [], rowsT = [], prov = [];
      Object.keys(bc).forEach(function (cfg) { ops.forEach(function (op) { var r = bc[cfg][op]; if (!r) return; cats.push(cfgName(cfg) + ' · ' + op.replace(/_/g, ' ')); off.push(tv(r.ecc_off_cycles)); on.push(tv(r.ecc_on_cycles)); prov.push(pvOf(r.ecc_on_cycles)); rowsT.push({ cfg: cfg, op: op, r: r }); }); });
      if (!cats.length) return;
      gap();
      var cl = SF.card({ title: 'Cycles from accepted request to visible response, ECC off vs on', provs: SF.uniq(prov.filter(Boolean)), note: SF.get(E, 'latency', 'definition') || '', source: ECC_SRC + ' latency.by_config (Verilator runs of sf_sram_bank)' });
      host.appendChild(cl.el);
      SF.groupedBars(cl.body, { aria: 'Latency in cycles with ECC off and on', cats: cats, yLabel: 'Latency (cycles)', unit: 'cycles', height: 300, valueLabels: cats.length <= 8,
        series: [{ id: 'off', name: 'ECC off', color: SF.PAL[0], vals: off }, { id: 'on', name: 'ECC on (SECDED)', color: SF.PAL[1], vals: on }] });
      cl.body.appendChild(SF.tableView('Latency table', [{ label: 'Config', get: function (x) { return cfgName(x.cfg); } }, { label: 'Operation', get: function (x) { return x.op; } }, { label: 'ECC off', num: true, get: function (x) { return tv(x.r.ecc_off_cycles); } },
        { label: 'ECC on', num: true, get: function (x) { return tv(x.r.ecc_on_cycles); } }, { label: 'Added by ECC', num: true, get: function (x) { return tv(x.r.added_by_ecc_cycles); } }], rowsT));
      var doc = Object.keys(bc).map(function (cfg) { return { cfg: cfg, off: tv(bc[cfg].documented_bank_latency_ecc_off), on: tv(bc[cfg].documented_bank_latency_ecc_on), match: bc[cfg].matches_documented }; });
      cl.body.appendChild(SF.tableView('Measured vs documented bank latency (documented values are analytical)', [{ label: 'Config', get: function (x) { return cfgName(x.cfg); } }, { label: 'Documented, ECC off', num: true, get: function (x) { return x.off; } }, { label: 'Documented, ECC on', num: true, get: function (x) { return x.on; } }, { label: 'RTL matches documented', get: function (x) { return x.match === true ? 'yes' : x.match === false ? 'NO' : null; } }], doc));
    });
    // --- partial-write / RMW throughput
    guard(host, 'ECC partial-write cost', function () {
      var bc = SF.get(E, 'partial_write', 'by_config'); if (!bc) return;
      var streams = ['wr_full', 'wr_part', 'rd', 'mix'], cats = [], off = [], on = [], rowsT = [], prov = [];
      Object.keys(bc).forEach(function (cfg) { streams.forEach(function (st) { var r = bc[cfg][st]; if (!r || !r.ecc_off || !r.ecc_on) return; cats.push(cfgName(cfg) + ' · ' + st.replace('wr_', 'write ').replace('rd', 'read').replace('mix', 'mixed')); off.push(tv(r.ecc_off.ops_per_cycle)); on.push(tv(r.ecc_on.ops_per_cycle)); prov.push(pvOf(r.ecc_on.ops_per_cycle)); rowsT.push({ cfg: cfg, st: st, r: r }); }); });
      if (!cats.length) return;
      gap();
      var cp = SF.card({ title: 'Throughput of full writes, partial writes (read-modify-write), reads and a mix', provs: SF.uniq(prov.filter(Boolean)), note: 'Operations completed per cycle over a stream of ' + (SF.get(E, 'partial_write', 'ops_per_stream') || '?') + ' operations. A partial write under ECC needs a read-modify-write, which shows up as stall cycles.', source: ECC_SRC + ' partial_write.by_config (Verilator)' });
      host.appendChild(cp.el);
      SF.groupedBars(cp.body, { aria: 'Operations per cycle with ECC off and on', cats: cats, yLabel: 'Operations per cycle', unit: 'ops/cycle', height: 300,
        series: [{ id: 'off', name: 'ECC off', color: SF.PAL[0], vals: off }, { id: 'on', name: 'ECC on (SECDED)', color: SF.PAL[1], vals: on }] });
      cp.body.appendChild(SF.tableView('Stream table', [{ label: 'Config', get: function (x) { return cfgName(x.cfg); } }, { label: 'Stream', get: function (x) { return x.st; } }, { label: 'Cycles off', num: true, get: function (x) { return tv(x.r.ecc_off.cycles); } }, { label: 'Cycles on', num: true, get: function (x) { return tv(x.r.ecc_on.cycles); } },
        { label: 'Stall cycles on', num: true, get: function (x) { return tv(x.r.ecc_on.stall_cycles); } }, { label: 'Stall cycles per op on', num: true, get: function (x) { return SF.fmt(tv(x.r.ecc_on.stall_cycles_per_op), 4); } }, { label: 'Readback mismatches (on)', num: true, get: function (x) { return x.r.ecc_on.readback_mismatches; } }], rowsT));
    });
    // --- scrub
    guard(host, 'ECC scrubbing', function () {
      var sc = E.scrub; if (!sc) return;
      Object.keys(sc).forEach(function (k) {
        var d = sc[k]; gap();
        var cs = SF.card({ title: 'Background scrubbing (' + cfgName(k) + ')', provs: SF.uniq([pvOf(d.bank_bandwidth_pct_consumed, 'rtl_simulated'), pvOf(d.full_bank_scrub_time_cycles_per_1024_rows, 'analytical')]), source: ECC_SRC + ' scrub.' + k });
        host.appendChild(cs.el);
        var tiles = [['Cycles per scrubbed word period', d.cycles_per_scrubbed_word_period, 'cycles'], ['Bank bandwidth consumed', d.bank_bandwidth_pct_consumed, '%'], ['Bank blocked per scrub step', d.bank_blocked_cycles_per_scrub_step, 'cycles'], ['Worst-case request blocking', d.request_blocking_fraction_worst_case, 'fraction'], ['Full scrub of 1024 rows', d.full_bank_scrub_time_cycles_per_1024_rows, 'cycles (analytical)']];
        cs.body.appendChild(h('div', { class: 'stats' }, tiles.filter(function (t) { return t[1] !== undefined; }).map(function (t) { return h('div', { class: 'stat' }, h('div', { class: 'l', text: t[0] }), h('div', { class: 'v', text: SF.fmt(tv(t[1]), 4) }), h('div', { class: 's' }, t[2] + ' ', SF.chip(pvOf(t[1], 'unavailable')))); })));
        if (Array.isArray(d.under_load) && d.under_load.length) cs.body.appendChild(SF.tableView('Scrub under load', [{ label: 'Offered requests per 256 cycles', num: true, get: function (r) { return r.offered_requests_per_256_cycles; } }, { label: 'Accepted without scrub', num: true, get: function (r) { return tv(r.accepted_without_scrub); } }, { label: 'Accepted with scrub', num: true, get: function (r) { return tv(r.accepted_with_scrub); } }], d.under_load));
      });
    });
    // --- fault reporting
    guard(host, 'ECC fault reporting', function () {
      var fr = SF.get(E, 'fault_reporting', 'by_word_width'); if (!fr) return;
      var dws = Object.keys(fr); if (!dws.length) return;
      S.ecc = S.ecc || {}; if (dws.indexOf(S.ecc.dw) < 0) S.ecc.dw = dws[0];
      gap();
      var cf = SF.card({ title: 'What the decoder reports when 0, 1, 2 or 3 stored bits are flipped', provs: ['rtl_simulated'], note: SF.get(E, 'fault_reporting', 'what') ? SF.get(E, 'fault_reporting', 'what') + '. This says what the logic does with an injected error, not how often such errors occur (no soft-error or defect rate data exists). SECDED does not guarantee detection of 3-bit errors: most random 3-bit patterns are silently miscorrected.' : '', source: ECC_SRC + ' fault_reporting.by_word_width (Verilator, fault-injection hook)' });
      host.appendChild(cf.el);
      cf.body.appendChild(SF.controls(SF.select('ecc-dw', 'Word width', dws.map(function (k) { return { v: k, t: k.replace('DW', '') + ' bits' }; }), S.ecc.dw, function (v) { S.ecc.dw = v; refresh(); })));
      var d = fr[S.ecc.dw], bw = d.by_weight || {}, wk = Object.keys(bw).sort();
      var ser = [['clean', 'no error reported', SF.PAL[3]], ['corrected_data_ok', 'corrected, data correct', SF.PAL[0]], ['flagged_uncorrectable', 'flagged uncorrectable', SF.PAL[2]], ['silently_miscorrected', 'silently miscorrected', SF.PAL[4]]];
      SF.stackedBars(cf.body, { aria: 'Decoder outcome counts by number of flipped bits', cats: wk.map(function (k) { return k.replace('weight_', '') + ' bit(s) flipped'; }), yLabel: 'Injected cases (count)', unit: 'cases', height: 280,
        series: ser.map(function (x) { return { id: x[0], name: x[1], color: x[2], vals: wk.map(function (k) { var v = tv(bw[k][x[0]]); return SF.isNum(v) ? v : null; }) }; }) });
      cf.body.appendChild(SF.tableView('Outcome table', [{ label: 'Flipped bits', get: function (r) { return r.k.replace('weight_', ''); } }].concat(['injected'].concat(ser.map(function (x) { return x[0]; })).concat(['silent_miscorrection_rate']).map(function (f) { return { label: f.replace(/_/g, ' '), num: true, get: function (r) { var v = tv(r.d[f]); return SF.isNum(v) ? SF.fmt(v, 4) : v; } }; })), wk.map(function (k) { return { k: k, d: bw[k] }; })));
    });
    // --- logic cost (generic gates, NOT area)
    guard(host, 'ECC logic cost', function () {
      var mods = SF.get(E, 'logic_cost', 'modules'); if (!mods) return;
      var names = Object.keys(mods).filter(function (k) { return mods[k] && mods[k].value && SF.isNum(mods[k].value.total_cells); });
      if (!names.length) return;
      gap();
      var cg = SF.card({ title: 'ECC codec and bank gate counts (Yosys generic gates)', provs: ['synthesized'], note: 'Generic gate counts before technology mapping: NOT area, NOT timing, NOT power. ' + (SF.get(E, 'logic_cost', 'flow') ? 'Flow: ' + SF.get(E, 'logic_cost', 'flow') : ''), source: ECC_SRC + ' logic_cost.modules' });
      host.appendChild(cg.el);
      SF.stackedBars(cg.body, { aria: 'Generic gate counts per module', cats: names, yLabel: 'Cells (generic gates)', unit: 'cells', height: 300,
        series: [{ id: 'logic', name: 'combinational / other cells', color: SF.PAL[0], vals: names.map(function (k) { var v = mods[k].value; return v.total_cells - (v.flip_flops || 0); }) }, { id: 'ff', name: 'flip-flops', color: SF.PAL[1], vals: names.map(function (k) { return mods[k].value.flip_flops || 0; }) }] });
      cg.body.appendChild(SF.tableView('Gate-count table', [{ label: 'Module', get: function (k) { return k; } }, { label: 'Total cells', num: true, get: function (k) { return mods[k].value.total_cells; } }, { label: 'Flip-flops', num: true, get: function (k) { return mods[k].value.flip_flops; } }, { label: 'Latches', num: true, get: function (k) { return mods[k].value.latches; } }, { label: 'Memory cells', num: true, get: function (k) { return mods[k].value.mem_cells; } }], names));
    });
    gap();
    var cn = SF.card({ title: 'Study notes and unavailable items', provs: ['unavailable'], source: ECC_SRC + ' notes, unavailable_items' });
    host.appendChild(cn.el);
    verbatim(cn, E.notes, 'Notes (verbatim)');
    cn.body.appendChild(h('p', { class: 'note', text: Array.isArray(E.unavailable_items) && E.unavailable_items.length ? 'Items the study could not produce: ' + E.unavailable_items.join('; ') : 'The study lists no unavailable items.' }));
    if (E.quick) cn.body.appendChild(SF.note('This record was produced in quick mode (fewer vectors and configurations than the full study).', true));
    gap();
    fullRecord(host, E, ['notes', 'unavailable_items', 'environment', 'files'], { metaTitle: 'ECC study record', source: ECC_SRC, label: E.label });
  }
  SF.registerView(9, 'ECC overhead', 'ECC overhead',
    'What SECDED ECC costs: stored bits, decoder latency, read-modify-write on partial writes, scrub and fault reporting, codec gate counts.', renderEcc);

  // ================================================================== 10. MBIST results
  var MB_SRC = 'data/mbist_study.json (sramlab.studies.mbist)';
  var ALGO = { 0: 'March C-', 1: 'MATS+' };
  function renderMbist(host, refresh) {
    var M = SF.DS.mbist_study;
    var stmt = (M && typeof M.coverage_statement === 'string') ? M.coverage_statement : 'coverage of the injected fault model in simulation; this is NOT manufacturing/physical defect coverage';
    host.appendChild(h('div', { class: 'card', role: 'note' }, h('div', { class: 'chead' }, h('h3', { text: 'How to read MBIST coverage' }), h('div', { class: 'chips' }, SF.chip('unavailable', { sub: 'reading guide' }))),
      h('p', { class: 'note', style: { color: 'var(--text)' }, text: stmt.charAt(0).toUpperCase() + stmt.slice(1) + '.' }),
      h('p', { class: 'note', text: 'A March test run on a behavioural fault model says how well the algorithm finds that enumerated population; it says nothing about physical defects, DPPM, retention, read-disturb or at-speed faults. No silicon exists, so nothing here is MEASURED.' })));
    if (!M || typeof M !== 'object') {
      host.appendChild(h('div', { style: { height: '16px' } }));
      host.appendChild(missingStudy('MBIST results (March cycles, test-mode overhead, failure registers, fault-model coverage)', 'mbist_study.json',
        'The RTL-based MBIST study (P78 MemoryTest controller under Verilator, with an independent Python March simulator) has not been run for this dataset directory.',
        ['Run the MBIST study (needs Verilator) so that data/mbist_study.json is written.', 'Physical defect coverage cannot be produced without silicon data.']));
      return;
    }
    var gap = function () { host.appendChild(h('div', { style: { height: '16px' } })); };
    // --- test cycles from the RTL runs
    guard(host, 'MBIST test cycles', function () {
      var runs = SF.get(M, 'test_cycles', 'runs'); if (!Array.isArray(runs) || !runs.length) return;
      gap();
      var keyOf = function (r) { return (ALGO[r.algo] || ('algo ' + r.algo)) + ', ' + r.window + ' words'; };
      var keys = SF.uniq(runs.map(keyOf));
      var cc = SF.card({ title: 'Total MBIST test cycles vs banks (RTL runs)', provs: SF.uniq(runs.map(function (r) { return pvOf(r.cycles, 'rtl_simulated'); })),
        note: 'Cycles from starting the test to done, for the banks selected. ' + (SF.get(M, 'test_cycles', 'what_the_rtl_does_with_several_banks') || '') + ' Counts, not times: no clock is assumed.', source: MB_SRC + ' test_cycles.runs (Verilator, sf_sram_mbist)' });
      host.appendChild(cc.el);
      SF.lineChart(cc.body, { aria: 'MBIST test cycles versus tested banks', xLabel: 'Banks tested', yLabel: 'Total test cycles', unit: 'cycles', xType: 'linear', height: 300,
        xTicks: SF.sortNum(SF.uniq(runs.map(function (r) { return r.banks; }))),
        series: keys.map(function (k, i) { var st = SF.style(i); return { id: 'k' + i, name: k, color: st.color, marker: st.marker, pts: runs.filter(function (r) { return keyOf(r) === k; }).sort(function (a, b) { return a.banks - b.banks; }).map(function (r) { return { x: r.banks, y: tv(r.cycles) }; }) }; }) });
      var cm = SF.get(M, 'test_cycles', 'cycle_model');
      if (cm && cm.formula) cc.body.appendChild(h('p', { class: 'note', text: 'Cycle model (analytical, fitted and checked against these runs): ' + cm.formula + '; validated on ' + cm.validated_on_runs + ' runs, maximum absolute error ' + cm.max_abs_error_cycles + ' cycles.' }));
      cc.body.appendChild(SF.tableView('Run table (RTL cycles vs analytical models)', [{ label: 'Algorithm', get: function (r) { return ALGO[r.algo] || r.algo; } }, { label: 'Banks', num: true, get: function (r) { return r.banks; } }, { label: 'Words tested', num: true, get: function (r) { return r.window; } },
        { label: 'RTL cycles', num: true, get: function (r) { return tv(r.cycles); } }, { label: 'Engine RUN cycles', num: true, get: function (r) { return r.run_cycles; } }, { label: 'Ops-only model', num: true, get: function (r) { return tv(r.ops_only_model); } }, { label: 'Refined model', num: true, get: function (r) { return tv(r.refined_model); } },
        { label: 'Refined-model error (cycles)', num: true, get: function (r) { return r.refined_model_error_cycles; } }], runs));
    });
    // --- parallel-bank model (analytical)
    guard(host, 'MBIST parallel-bank model', function () {
      var pm = SF.get(M, 'test_cycles', 'parallel_bank_model_analytical'); if (!pm) return;
      var algos = Object.keys(pm); if (!algos.length) return;
      S.mb = S.mb || {}; if (algos.indexOf(S.mb.algo) < 0) S.mb.algo = algos[0];
      gap();
      var cp = SF.card({ title: 'Sequential vs parallel bank testing', provs: ['analytical'], note: 'The RTL tests banks one after another. The sequential figure is arithmetic that equals the RTL cycle count (validated); the parallel figure is an analytical model of a design that does NOT exist in the RTL and is NOT RTL-verified.', source: MB_SRC + ' test_cycles.parallel_bank_model_analytical' });
      host.appendChild(cp.el);
      cp.body.appendChild(SF.controls(SF.select('mb-algo', 'Algorithm', algos.map(function (a) { return { v: a }; }), S.mb.algo, function (v) { S.mb.algo = v; refresh(); })));
      var bb = pm[S.mb.algo].by_banks || {}, bk = Object.keys(bb).sort(function (a, b) { return +a.slice(1) - +b.slice(1); });
      SF.groupedBars(cp.body, { aria: 'Sequential versus parallel test cycles by bank count', cats: bk.map(function (k) { return k.slice(1) + ' banks'; }), yLabel: 'Test cycles', unit: 'cycles', height: 280,
        series: [{ id: 'seq', name: 'sequential (equals RTL count, analytical)', color: SF.PAL[0], hatch: true, vals: bk.map(function (k) { return tv(bb[k].sequential_cycles); }) }, { id: 'par', name: 'parallel (analytical model, not in RTL)', color: SF.PAL[1], hatch: true, vals: bk.map(function (k) { return tv(bb[k].parallel_cycles); }) }] });
      cp.body.appendChild(SF.tableView('Parallel model table', [{ label: 'Banks', get: function (k) { return k.slice(1); }, num: true }, { label: 'Sequential cycles', num: true, get: function (k) { return tv(bb[k].sequential_cycles); } }, { label: 'Parallel cycles', num: true, get: function (k) { return tv(bb[k].parallel_cycles); } }, { label: 'Speed-up', num: true, get: function (k) { return tv(bb[k].speedup); } }, { label: 'Peak banks tested at once', num: true, get: function (k) { return bb[k].peak_simultaneously_tested_banks; } }], bk));
    });
    // --- test-mode overhead
    guard(host, 'MBIST test-mode overhead', function () {
      var rows = SF.get(M, 'test_mode_overhead', 'rows'); if (!Array.isArray(rows) || !rows.length) return;
      gap();
      var lab = function (r) { return r.banks_tested + ' bank' + (r.banks_tested === 1 ? '' : 's') + (r.functional_traffic ? ', with functional traffic' : ', no traffic'); };
      var co = SF.card({ title: 'Test-mode overhead: total test cycles with and without functional traffic', provs: SF.uniq(rows.map(function (r) { return pvOf(r.total_test_cycles, 'rtl_simulated'); })), note: SF.get(M, 'test_mode_overhead', 'model') || '', source: MB_SRC + ' test_mode_overhead (Verilator, P78 memory-group model)' });
      host.appendChild(co.el);
      SF.groupedBars(co.body, { aria: 'Total test cycles by configuration', cats: rows.map(lab), yLabel: 'Total test cycles', unit: 'cycles', height: 280, legend: false, valueLabels: rows.length <= 6,
        series: [{ id: 'tc', name: 'total test cycles', color: SF.PAL[0], vals: rows.map(function (r) { return tv(r.total_test_cycles); }) }] });
      var tra = SF.get(M, 'test_mode_overhead', 'traffic_acceptance_rate_per_cycle');
      if (tra !== undefined) co.body.appendChild(h('p', { class: 'note' }, 'Functional-traffic acceptance rate while the test is not running: ', h('b', { text: SF.fmt(tv(tra), 4) + ' requests per cycle ' }), SF.chip(pvOf(tra, 'rtl_simulated'))));
      var phases = {}; rows.forEach(function (r) { Object.keys(r.phase_cycles || {}).forEach(function (k) { phases[k] = 1; }); });
      var pk = Object.keys(phases);
      if (pk.length) co.body.appendChild(SF.tableView('Phase cycles per configuration', [{ label: 'Configuration', get: lab }].concat(pk.map(function (k) { return { label: k.replace(/_/g, ' '), num: true, get: function (r) { var v = tv((r.phase_cycles || {})[k]); return typeof v === 'object' ? JSON.stringify(v) : v; } }; })), rows));
    });
    // --- fault-model coverage
    guard(host, 'MBIST coverage', function () {
      var inst = SF.get(M, 'coverage', 'instances'); if (!inst) return;
      var names = Object.keys(inst); if (!names.length) return;
      S.mb = S.mb || {}; if (names.indexOf(S.mb.inst) < 0) S.mb.inst = names[0];
      gap();
      var d = inst[S.mb.inst], bag = d.by_algorithm_and_group;
      var cc = SF.card({ title: 'Coverage of the injected fault model by fault group (' + S.mb.inst + ' array)', provs: ['rtl_simulated'], note: stmt + '. Fault population: ' + (SF.get(M, 'coverage', 'fault_population') || '') + ' (' + SF.fmt(d.faults) + ' faults in this instance).', source: MB_SRC + ' coverage.instances.' + S.mb.inst + '.by_algorithm_and_group' });
      host.appendChild(cc.el);
      if (names.length > 1) cc.body.appendChild(SF.controls(SF.select('mb-inst', 'Memory instance (rows x word bits)', names.map(function (k) { return { v: k }; }), S.mb.inst, function (v) { S.mb.inst = v; refresh(); })));
      if (!bag) { cc.body.appendChild(SF.unavailable({ why: 'No per-group coverage in this instance record.' })); return; }
      var cfgs = Object.keys(bag), groups = SF.uniq([].concat.apply([], cfgs.map(function (c) { return Object.keys(bag[c]); })));
      SF.groupedBars(cc.body, { aria: 'Fault-model coverage percentage by fault group and test configuration', cats: groups.map(function (g) { return g.replace(/_/g, ' '); }), yLabel: 'Faults detected (% of injected population)', unit: '%', yMax: 100, height: 320,
        series: cfgs.map(function (c, i) { return { id: 'c' + i, name: c, color: SF.PAL[i % 5], vals: groups.map(function (g) { var x = tv(bag[c][g]); return x && SF.isNum(x.pct) ? x.pct : null; }) }; }) });
      var flat = []; cfgs.forEach(function (c) { groups.forEach(function (g) { var x = tv(bag[c][g]); if (x) flat.push({ c: c, g: g, x: x }); }); });
      cc.body.appendChild(SF.tableView('Coverage table (detected / injected)', [{ label: 'Test configuration', get: function (r) { return r.c; } }, { label: 'Fault group', get: function (r) { return r.g.replace(/_/g, ' '); } }, { label: 'Detected', num: true, get: function (r) { return r.x.detected; } }, { label: 'Injected', num: true, get: function (r) { return r.x.total; } }, { label: 'Coverage %', num: true, get: function (r) { return r.x.pct; } }], flat, { caption: stmt }));
      var nm = SF.get(M, 'coverage', 'not_modelled');
      if (nm) cc.body.appendChild(h('p', { class: 'note warn', text: 'Not modelled: ' + nm }));
    });
    // --- failure reporting
    guard(host, 'MBIST failure reporting', function () {
      var sc = SF.get(M, 'failure_reporting', 'scenarios'); if (!Array.isArray(sc) || !sc.length) return;
      gap();
      var fr = M.failure_reporting;
      var cf = SF.card({ title: 'Failure registers: RTL vs independent Python March simulator (' + fr.matched + ' of ' + fr.total + ' scenarios match)', provs: ['rtl_simulated', 'simulated'], note: fr.note || '', source: MB_SRC + ' failure_reporting.scenarios' });
      host.appendChild(cf.el);
      cf.body.appendChild(SF.table([{ label: 'Scenario', get: function (r) { return r.scenario; } }, { label: 'Algorithm', get: function (r) { return r.algorithm; } }, { label: 'Background', get: function (r) { return r.background; } },
        { label: 'RTL result', get: function (r) { return tv(r.rtl) && tv(r.rtl).result; } }, { label: 'RTL failing reads', num: true, get: function (r) { return tv(r.rtl) && tv(r.rtl).failure_count; } }, { label: 'RTL banks with failures', get: function (r) { return tv(r.rtl) && tv(r.rtl).banks_with_failures_mask; } },
        { label: 'Python result', get: function (r) { return tv(r.python_prediction) && tv(r.python_prediction).result; } }, { label: 'Python failing reads', num: true, get: function (r) { return tv(r.python_prediction) && tv(r.python_prediction).count; } },
        { label: 'Agree', get: function (r) { return r.rtl_matches_python === true ? '● yes' : '▲ NO'; } }], sc, { caption: 'Failing-read counts count every failing read, not distinct faults.' }));
    });
    if (!['test_cycles', 'test_mode_overhead', 'coverage', 'failure_reporting'].some(function (k) { return M[k] && typeof M[k] === 'object'; })) {
      gap();
      host.appendChild(SF.unavailableCard('MBIST results', { why: 'data/mbist_study.json is present but holds none of the sections this view draws (test_cycles, test_mode_overhead, coverage, failure_reporting). Whatever it does contain is listed in the full record below.', source: MB_SRC }));
    }
    gap();
    var cn = SF.card({ title: 'Study notes', provs: ['unavailable'], source: MB_SRC + ' notes, unavailable_items' });
    host.appendChild(cn.el);
    verbatim(cn, M.notes, 'Notes (verbatim)');
    cn.body.appendChild(h('p', { class: 'note', text: Array.isArray(M.unavailable_items) && M.unavailable_items.length ? 'Items the study could not produce: ' + M.unavailable_items.join('; ') : 'The study lists no unavailable items.' }));
    if (M.quick) cn.body.appendChild(SF.note('This record was produced in quick mode (smaller instances and fewer configurations than the full study).', true));
    gap();
    fullRecord(host, M, ['notes', 'unavailable_items', 'environment', 'files', 'coverage_statement'], { metaTitle: 'MBIST study record', source: MB_SRC, label: M.label });
  }
  SF.registerView(10, 'MBIST results', 'MBIST results',
    'The P78 MBIST controller on its real RTL: total test cycles, per-phase cycles, test-mode overhead, failure registers and coverage of the injected fault model.', renderMbist);

  // ================================================================== 11. Area
  var NG_NOTE = 'Nangate45 is an open educational 45 nm library. These areas are Yosys-mapped CONTROLLER LOGIC ONLY (arbiters, FIFOs, trackers, perf counters); SRAM arrays are not included and this is NOT SilicaFlux silicon area. Areas are not transferable to another process node.';
  function synthSets() {
    var sy = SF.DS.synth || {}, out = { ng: [], gen: [] };
    Object.keys(sy).forEach(function (k) {
      var d = sy[k]; if (!d || !Array.isArray(d.rows)) return;
      (/nangate|lib|liberty/i.test(k) || /liberty/i.test(d.mode || '') ? out.ng : out.gen).push({ key: k, d: d, rows: d.rows.filter(function (r) { return r.status === 'ok' || r.status === undefined; }) });
    });
    return out;
  }
  function pairKey(k) { return k.replace(/_?(generic|nangate45|lib|gen)$/i, ''); }
  function sweepVaries(rows, f) { return SF.uniq(rows.map(function (r) { return r[f]; })).length > 1; }
  function areaCard(title, sets, kind) {
    // kind: 'area' (nangate mapped) | 'cells' (generic gate count)
    var field = kind === 'area' ? 'mapped_area_um2' : 'cells';
    sets.forEach(function (set) {
      var rows = set.rows.filter(function (r) { return SF.isNum(r[field]); });
      var d = set.d, sw = d.sweep || {};
      var banksVary = sweepVaries(rows, 'banks'), mastersVary = sweepVaries(rows, 'masters');
      var xf = banksVary ? 'banks' : (mastersVary ? 'masters' : 'banks');
      var seriesBy = banksVary || mastersVary ? (mastersVary && !banksVary ? 'max_out' : 'perf') : 'perf';
      var xs = SF.sortNum(SF.uniq(rows.map(function (r) { return r[xf]; }))), ser = SF.sortNum(SF.uniq(rows.map(function (r) { return r[seriesBy]; })));
      var sname = function (v) { return seriesBy === 'perf' ? (v ? 'performance counters ON' : 'performance counters OFF') : 'MAX_OUT = ' + v; };
      var base = pairKey(set.key);
      var c = SF.card({ title: title + ' (' + (base === 'controller_sweep' || base === '' ? 'banks sweep' : base.replace(/_/g, ' ')) + ')', provs: ['synthesized'],
        note: (kind === 'area' ? NG_NOTE : 'Yosys generic-gate cell counts (no technology library): gate counts are NOT area, and the SRAM arrays are not synthesized.') + ' Fixed in this sweep: ' + ['masters', 'max_out', 'data_width', 'bank_depth'].filter(function (f) { return sw[f] !== undefined; }).map(function (f) { return f + ' = ' + (Array.isArray(sw[f]) ? sw[f].join('/') : sw[f]); }).join(', ') + '.',
        source: 'data/synth/' + (d.file || ('controller_sweep_' + set.key + '.json')) + '; Yosys ' + (d.yosys || '?') + (kind === 'area' && d.technology ? '; ' + d.technology : '') + '; RTL sha256 ' + String(d.rtl_sha256 || '').slice(0, 12) });
      c.__host = null;
      sets.__host.appendChild(c.el);
      if (!rows.length) { c.body.appendChild(SF.unavailable({ why: 'No successfully synthesized rows carry ' + field + '.' })); return; }
      var series = ser.map(function (v, i) { var st = SF.style(i); return { id: seriesBy + v, name: sname(v), color: st.color, vals: xs.map(function (x) { var r = rows.filter(function (q) { return q[xf] === x && q[seriesBy] === v; })[0]; return r ? r[field] : null; }) }; });
      SF.groupedBars(c.body, { aria: title, cats: xs.map(function (x) { return x + ' ' + xf.replace('_', ' '); }), series: series, yLabel: kind === 'area' ? 'Mapped area (µm², Nangate45)' : 'Cells (generic gates)', unit: kind === 'area' ? 'µm²' : 'cells', xLabel: xf === 'banks' ? 'Banks' : 'Masters', height: 290, valueLabels: xs.length * ser.length <= 8 });
      c.body.appendChild(SF.tableView('Synthesis rows (table view)', [
        { label: 'Banks', num: true, get: function (r) { return r.banks; } }, { label: 'Masters', num: true, get: function (r) { return r.masters; } }, { label: 'MAX_OUT', num: true, get: function (r) { return r.max_out; } }, { label: 'Perf counters', num: true, get: function (r) { return r.perf; } },
        { label: 'Cells', num: true, get: function (r) { return r.cells; } }, { label: 'Flip-flops', num: true, get: function (r) { return r.flip_flops; } },
        { label: 'Mapped area µm²', num: true, get: function (r) { return SF.isNum(r.mapped_area_um2) ? SF.fmt(r.mapped_area_um2, 6) : null; } }, { label: 'Logic depth (gate levels)', num: true, get: function (r) { return r.logic_depth_levels; } },
        { label: 'Latch-free', get: function (r) { return r.latch_free === true ? 'yes' : r.latch_free === false ? 'NO' : null; } }], rows));
    });
  }
  function renderArea(host, refresh) {
    var sets = synthSets(), phys = SF.DS.phys;
    host.appendChild(h('p', { class: 'note', text: 'Everything on this panel is about controller logic (and, where a physical-area record exists, vendor macro geometry). Nothing is silicon-measured and nothing is labelled as SilicaFlux silicon area.' }));
    var grid = h('div'); host.appendChild(grid);
    var any = sets.ng.length + sets.gen.length;
    if (!any) {
      host.appendChild(SF.unavailableCard('Controller logic area and gate counts', { why: SF.DS.synth ? 'The synthesis sweeps in data/synth contain no usable rows.' : 'No data/synth/controller_sweep_*.json files are present in the data directory.',
        unlocks: ['Run the Yosys controller sweep (generic gates need only Yosys; mapped area additionally needs a Liberty file such as Nangate45).'], source: 'data/synth/controller_sweep_*.json' }));
    }
    if (sets.ng.length) { sets.ng.__host = grid; areaCard('Mapped controller logic area', sets.ng, 'area'); }
    else if (any) {
      grid.appendChild(SF.unavailableCard('Mapped controller logic area (um^2)', { why: 'No Liberty-mapped synthesis result is present, so mapped area is unavailable; only generic gate counts exist (below). Gate counts are not area.',
        unlocks: ['Re-run the controller sweep with a technology library (Liberty) to obtain mapped cell area for that library.'], source: 'data/synth/controller_sweep_nangate45.json' }));
    }
    if (sets.gen.length) { var g2 = h('div', { style: { marginTop: '16px' } }); host.appendChild(g2); sets.gen.__host = g2; areaCard('Controller gate counts', sets.gen, 'cells'); }
    // logic depth (pre-mapping) when a banks sweep exists
    var depthSet = (sets.gen.concat(sets.ng)).filter(function (x) { return sweepVaries(x.rows, 'banks'); })[0];
    if (depthSet) {
      var cd = SF.card({ title: 'Controller logic depth vs banks', provs: ['synthesized'], note: 'Pre-mapping logic depth in gate levels. It is not a clock frequency and no timing analysis (STA) was run.', source: 'data/synth/' + (depthSet.d.file || ('controller_sweep_' + depthSet.key + '.json')) });
      host.appendChild(h('div', { style: { height: '16px' } })); host.appendChild(cd.el);
      var perfs = SF.sortNum(SF.uniq(depthSet.rows.map(function (r) { return r.perf; })));
      SF.lineChart(cd.body, { aria: 'Logic depth versus banks', xLabel: 'Banks (log2 spacing)', yLabel: 'Logic depth (gate levels)', unit: 'levels', height: 260, zero: true,
        series: perfs.map(function (pv, i) { var st = SF.style(i); return { id: 'p' + pv, name: pv ? 'performance counters ON' : 'performance counters OFF', color: st.color, marker: st.marker, pts: depthSet.rows.filter(function (r) { return r.perf === pv && SF.isNum(r.logic_depth_levels); }).map(function (r) { return { x: r.banks, y: r.logic_depth_levels }; }) }; }) });
    }
    // subsystem + noc interface (other synthesis results)
    var other = SF.DS.synth_other;
    if (other && Object.keys(other).length) {
      var co = SF.card({ title: 'Other synthesized blocks (integrated subsystem, NoC-facing interface)', provs: ['synthesized'], note: 'Small-depth demonstrations: arrays become flip-flops and are NOT representative of SRAM area.', source: 'data/synth/subsystem_*.json, noc_interface.json' });
      host.appendChild(h('div', { style: { height: '16px' } })); host.appendChild(co.el);
      var orows = [];
      Object.keys(other).forEach(function (k) {
        var d = other[k];
        var parts = d && d.parts ? Object.keys(d.parts).map(function (p) { return { name: k + ' › ' + p, d: d.parts[p] }; }) : [{ name: k, d: d }];
        parts.forEach(function (p) {
          var g = p.d && p.d.generic || {}, m = p.d && p.d.mapped || {}, a = p.d && p.d.mapped_area_um2;
          orows.push({ name: p.name, top: p.d && p.d.top, scope: p.d && p.d.scope, cells: g.total_cells, ff: g.flip_flops, mappedCells: m.cells, tech: m.technology, area: (a && SF.isNum(a.value)) ? a.value : null, unav: a && a.provenance === 'unavailable' ? a.reason : null, mode: p.d && p.d.mode });
        });
      });
      co.body.appendChild(SF.table([{ label: 'Block', get: function (r) { return r.name; } }, { label: 'Top module', get: function (r) { return r.top; } }, { label: 'Generic cells', num: true, get: function (r) { return r.cells; } },
        { label: 'Flip-flops', num: true, get: function (r) { return r.ff; } }, { label: 'Mapped cells', num: true, get: function (r) { return r.mappedCells; } },
        { label: 'Mapped area µm²', num: true, get: function (r) { return r.area !== null ? SF.fmt(r.area, 6) : (r.unav ? 'unavailable: ' + r.unav : (r.tech ? 'see mapped cells' : 'unavailable')); } }, { label: 'Scope', get: function (r) { return r.scope; } }], orows));
    }
    // physical: vendor macro footprint (analytical), die area (unavailable by design unless supplied)
    host.appendChild(h('div', { style: { height: '16px' } }));
    if (phys && typeof phys === 'object') {
      fullRecord(host, phys, [], { metaTitle: 'Physical-area record', source: 'data/phys.json (sramlab.phys.area_report)', label: phys.label });
    } else {
      host.appendChild(SF.unavailableCard('SRAM macro footprint and die area', { why: 'No physical-area record (data/phys.json) is present. Die area is never estimated from nothing: it needs macro dimensions, a logic area from a library of the SAME process family as the macros, and placement margins.',
        detail: 'Controller-logic area above is for the Nangate45 educational library only and cannot be added to a macro footprint from another process.',
        unlocks: ['Run the area report with a technology profile that has vendor macro manifests (they live in data/macros) so that the analytical macro tiling footprint is produced.', 'Supply logic area from a Liberty of the same process family as the chosen macros, plus placement margins, to unlock a die-area figure.'], source: 'data/phys.json' }));
    }
  }
  SF.registerView(11, 'Area', 'Area',
    'Synthesized controller logic area and gate counts (Yosys; Nangate45 mapping is an open educational library, logic only), plus vendor-macro footprint when a physical record exists. Die area stays unavailable unless every input exists.', renderArea);

  // ================================================================== 12. Power estimates
  function renderPower(host, refresh) {
    var P = SF.DS.power, Th = SF.DS.thermal;
    host.appendChild(h('div', { class: 'card', role: 'note' }, h('div', { class: 'chead' }, h('h3', { text: 'Energy and power: status' }), h('div', { class: 'chips' }, SF.chip('unavailable'))),
      h('p', { class: 'note', text: P ? 'A power/energy record is present: values below keep the provenance class they were given. Quantities it could not produce are listed with their reasons.' : 'Energy: UNAVAILABLE — no validated energy profile. Without per-event energies there is no pJ, no mW and no energy-per-byte figure; the activity counts below are parameter-free and are the only honest substitute.' }),
      h('div', { class: 'unlock muted', style: { fontSize: '12.5px' } }, h('b', { text: 'What would unlock energy: ' }), 'a validated energy profile (per-event energies with operating conditions, loaded through sramlab.power.load_energy_profile), or a Liberty file with power tables for the target library, or a vendor FPGA power report, or a user-supplied hardware measurement file with its own provenance. None of these exists in this dataset, and no silicon or FPGA measurement exists.')));
    host.appendChild(h('div', { style: { height: '16px' } }));
    // parameter-free activity proxy from the bank sweep
    var d = SF.DS.bank_sweep, keys = d ? Object.keys(d).filter(function (k) { return d[k] && Array.isArray(d[k].rows); }).sort() : [];
    var rows = keys.length ? d[keys[0]].rows.filter(function (r) { return r.bit_activations_per_useful_byte; }) : [];
    if (!rows.length) {
      host.appendChild(SF.unavailableCard('Array activity per useful byte (parameter-free)', { why: d ? 'bit_activations_per_useful_byte is not in data/bank_sweep.json.' : SF.absentReason('bank_sweep.json'), unlocks: ['Regenerate the bank sweep: python3 scripts/generate_data.py --only bank_sweep'], source: 'data/bank_sweep.json' }));
    } else {
      var c = SF.card({ title: 'Array bit activations per useful byte (activity proxy, not energy)', provs: ['simulated'],
        note: 'Counts how many array bits are activated per useful byte moved. It needs no energy parameters, but it also does not depend on bank size or technology, so it cannot rank bank organisations by energy. It is a proxy for relative switching activity only.',
        source: 'data/bank_sweep.json ' + keys[0] + ' (bit_activations_per_useful_byte, 95% CI over replications)' });
      host.appendChild(c.el);
      var wls = ['rand_read', 'mixed', 'seq_read', 'hotspot', 'contention'].filter(function (w) { return rows.some(function (r) { return r.workload === w; }); });
      var banks = SF.sortNum(SF.uniq(rows.map(function (r) { return r.banks; })));
      SF.groupedBars(c.body, { aria: 'Bit activations per useful byte by workload and bank count', cats: wls.map(function (w) { return w.replace('_', ' '); }), yLabel: 'Bit activations per useful byte', unit: 'bits/B', height: 290,
        series: banks.map(function (b, i) { return { id: 'b' + b, name: b + ' banks', color: SF.PAL[i % 5], vals: wls.map(function (w) { var r = rows.filter(function (q) { return q.workload === w && q.banks === b; })[0]; return r ? r.bit_activations_per_useful_byte : null; }) }; }) });
      c.body.appendChild(SF.tableView('Activity table (mean ± 95% CI, n)', [{ label: 'Workload', get: function (r) { return r.workload; } }, { label: 'Banks', num: true, get: function (r) { return r.banks; } }, { label: 'Bit activations per useful byte', num: true, get: function (r) { return SF.pm(r.bit_activations_per_useful_byte, 4); }, sort: function (r) { return SF.stat(r.bit_activations_per_useful_byte).m; } }], rows));
    }
    host.appendChild(h('div', { style: { height: '16px' } }));
    if (P && typeof P === 'object') fullRecord(host, P, [], { metaTitle: 'Energy / power record', source: 'data/power.json (sramlab.power.energy_report)', label: P.label });
    else host.appendChild(SF.unavailableCard('Energy, power and energy per useful byte', { why: SF.absentReason('power.json') + ' Even when it exists, every energy value is unavailable unless a validated energy profile covers all needed terms.',
      unlocks: ['Provide a validated energy profile and run the energy report.', 'Supply a Liberty with power tables or a vendor FPGA power estimate (each would be labelled with its own class, never as measured).'], source: 'data/power.json' }));
    host.appendChild(h('div', { style: { height: '16px' } }));
    if (Th && typeof Th === 'object') fullRecord(host, Th, [], { metaTitle: 'Thermal hand-off record', source: 'data/thermal.json (sramlab.thermal)', label: Th.label });
    else host.appendChild(SF.unavailableCard('Thermal hand-off', { why: SF.absentReason('thermal.json') + ' A thermal map needs block power (unavailable without an energy profile) and block geometry (generated from vendor macro dimensions only when a technology profile exists).',
      unlocks: ['Provide an energy profile and a floorplan so that block power and geometry exist; only then can the ThermalLab hand-off files be written.'], source: 'data/thermal.json' }));
  }
  SF.registerView(12, 'Power estimates', 'Power estimates',
    'Energy and power are unavailable by design without a validated energy profile. What exists is parameter-free array activity, shown as an activity proxy and never as energy.', renderPower);
})();
