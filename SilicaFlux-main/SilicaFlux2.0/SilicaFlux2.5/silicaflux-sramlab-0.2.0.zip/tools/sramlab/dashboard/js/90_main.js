/* SRAMLab dashboard shell: header strip, navigation, hash routing, footer.  Runs after every view has registered. */
(function () {
  'use strict';
  var SF = window.SF, h = SF.h, s = SF.s, DB = SF.DB, DS = SF.DS;
  var t0 = (window.performance && performance.now) ? performance.now() : 0;
  var leaveHooks = [];
  SF.onLeave = function (fn) { leaveHooks.push(fn); };
  function runLeave() { var l = leaveHooks; leaveHooks = []; l.forEach(function (f) { try { f(); } catch (e) { /* hook failures must not block navigation */ } }); }

  // ------------------------------------------------------------------ which dataset each view needs (for the nav hint)
  var NEEDS = { 3: ['timeline_trace'], 4: ['bank_sweep'], 5: ['bank_sweep'], 6: ['bank_sweep'], 7: ['tensor_study'], 8: ['vector_study'], 9: ['ecc_study'], 10: ['mbist_study'], 11: ['synth'], 12: ['power'], 13: ['bank_sweep'], 14: ['optimise'], 15: ['experiments'] };
  function hint(n) {
    var need = NEEDS[n]; if (!need) return '';
    var missing = need.filter(function (k) { return !DS[k]; });
    return missing.length === need.length ? (n === 9 || n === 11 || n === 12 ? 'partial' : 'no data') : '';
  }

  // ------------------------------------------------------------------ header strip
  function rtlBlock() {
    var R = DS.rtl_verification;
    var box = h('div', { class: 'rtl' }, h('div', { class: 'kicker', text: 'RTL verification' }));
    if (!R || !SF.isNum(R.cases)) {
      box.appendChild(h('div', { class: 'headline' }, h('span', { class: 'big', text: 'Unavailable' }), SF.chip('unavailable')));
      box.appendChild(h('div', { class: 'lbl muted', text: SF.absentReason('rtl_verification.json') + ' The cycle model is then not shown as verified against the RTL.' }));
      return box;
    }
    var ok = R.passed === R.cases && !R.failed;
    box.appendChild(h('div', { class: 'headline' }, h('span', { class: 'big ' + (ok ? 'ok' : 'bad'), text: ok ? R.cases + '/' + R.cases + ' identical' : R.passed + '/' + R.cases + ' identical, ' + R.failed + ' differ' }), SF.chip('rtl_simulated')));
    box.appendChild(h('div', { class: 'lbl', text: 'Verilator RTL vs the Python cycle model, compared cycle by cycle (trace and hardware counters)' + (R.three_way && SF.isNum(R.three_way.cases) ? '; Icarus as second simulator (' + R.three_way.passed + '/' + R.three_way.cases + ' three-way)' : '') + '. ' + SF.fmt(R.cycles_compared) + ' cycles, ' + SF.fmt(R.transactions) + ' transactions, ' + SF.fmt(R.counters_compared) + ' counter comparisons, ' + R.parameter_sets + ' parameter sets.' }));
    var det = h('details', null, h('summary', { text: 'Verification details' }));
    var mut = Array.isArray(R.mutation_check) ? R.mutation_check : [];
    var tbl = h('table', { class: 'detail' });
    if (mut.length) {
      var det_n = mut.filter(function (m) { return m.detected; }).length;
      tbl.appendChild(h('tr', null, h('td', { text: 'Negative control' }), h('td', { text: det_n + ' of ' + mut.length + ' deliberately broken models were detected: ' + mut.map(function (m) { return m.mutation + (m.detected ? ' (caught)' : ' (MISSED)'); }).join(', ') })));
    }
    if (Array.isArray(R.results) && R.results.length) {
      var by = {};
      R.results.forEach(function (r) { var k = r.params || (r.label || '').split('/')[0]; by[k] = by[k] || { n: 0, ok: 0 }; by[k].n++; if (r.ok) by[k].ok++; });
      tbl.appendChild(h('tr', null, h('td', { text: 'Per parameter set' }), h('td', { text: Object.keys(by).map(function (k) { return k + ' ' + by[k].ok + '/' + by[k].n; }).join('  ·  ') })));
    }
    var T3 = R.three_way;
    if (T3 && SF.isNum(T3.cases)) {
      tbl.appendChild(h('tr', null, h('td', { text: 'Second simulator' }), h('td', { text: T3.passed + ' of ' + T3.cases + ' cases: Python model = Verilator = Icarus (independent Icarus testbench, same stimulus)' })));
    }
    var X = DS.xsim_verification;
    if (X && SF.isNum(X.cases)) {
      var nc = X.negative_control || {};
      tbl.appendChild(h('tr', null, h('td', { text: 'ECC / MBIST testbenches' }), h('td', { text: X.identical + ' of ' + X.cases + ' cases identical on Verilator and Icarus (' + SF.fmt(X.lines_compared) + ' result lines). Negative control: ' + (nc.interpretation || 'not run') })));
    }
    var RC = DS.r_crosscheck;
    if (RC && RC.comparison && SF.isNum(RC.comparison.compared)) {
      tbl.appendChild(h('tr', null, h('td', { text: 'Statistics in R' }), h('td', { text: RC.comparison.agree + ' of ' + RC.comparison.compared + ' statistics recomputed in R agree with Python (' + (RC.rscript || 'R') + ')' })));
    }
    if (SF.isNum(R.wall_seconds)) tbl.appendChild(h('tr', null, h('td', { text: 'Wall time' }), h('td', { text: SF.fmt(R.wall_seconds, 3) + ' s' })));
    det.appendChild(h('div', { class: 'detail' }, tbl));
    box.appendChild(det);
    return box;
  }
  function toolsBlock() {
    var box = h('div', { class: 'tools' }, h('div', { class: 'kicker', text: 'Tool availability (at build time)' }));
    var row = h('div', { class: 'toolrow' });
    (DB.tools || []).forEach(function (t) {
      row.appendChild(h('span', { class: 'tool ' + (t.available ? 'yes' : 'no'), title: t.available ? 'found' + (t.version ? ': ' + t.version : '') : 'not installed: dependent results are UNAVAILABLE, never estimated' }, h('span', { class: 'dot', 'aria-hidden': 'true' }), t.tool + (t.available ? (t.version ? ' ' + String(t.version).split('\n')[0].slice(0, 24) : ' (found)') : ' — missing')));
    });
    var sy = DS.synth || {}, ng = Object.keys(sy).some(function (k) { return /nangate|liberty/i.test(k + ' ' + (sy[k].mode || '')); });
    row.appendChild(h('span', { class: 'tool ' + (ng ? 'yes' : 'no'), title: 'Technology library used for mapped area' }, h('span', { class: 'dot', 'aria-hidden': 'true' }), ng ? 'Liberty: Nangate45 (educational, 45 nm)' : 'Liberty: none — area unavailable'));
    if (!(DB.tools || []).length) row.appendChild(h('span', { class: 'tool no' }, 'tool probe not recorded in this build'));
    box.appendChild(row);
    return box;
  }
  function legendStrip() {
    var strip = h('div', { class: 'legend-strip', role: 'group', 'aria-label': 'Provenance legend' });
    strip.appendChild(h('span', { class: 'kicker', style: { margin: 0 }, text: 'Provenance' }));
    [['analytical', 'closed-form ceiling or arithmetic; drawn dashed or hatched'], ['simulated', 'verified Python cycle model; solid, with 95% CI where replicated'], ['rtl_simulated', 'Verilator run of the real RTL'], ['synthesized', 'Yosys on the RTL; Nangate45 is an educational library, logic only'], ['unavailable', 'cannot be produced; the panel says why']].forEach(function (p) {
      strip.appendChild(h('span', { class: 'item' }, SF.chip(p[0]), h('span', { class: 't', text: p[1] })));
    });
    strip.appendChild(h('span', { class: 'item measured' }, SF.measuredNoneChip(), h('span', { class: 't', text: 'MEASURED: none exists (no silicon or FPGA data). Nothing on this page is measured.' })));
    return strip;
  }
  function buildHeader() {
    var top = document.getElementById('top');
    var brand = h('div', { class: 'brand' }, h('h1', { class: 'gold', text: 'SilicaFlux SRAMLab' }), h('div', { class: 'rule' }),
      h('div', { class: 'sub', text: 'Project 80 · SRAM architecture benchmarking and digital twin' }),
      h('div', { class: 'sub', text: 'Built ' + (DB.generated_utc || '?').replace('T', ' ').replace('+00:00', ' UTC') + ' from ' + (DB.data_dir || 'data') + '/ · sramlab ' + (DB.package_version || '?') }));
    top.appendChild(h('div', { class: 'top-grid' }, brand, rtlBlock(), toolsBlock()));
    top.appendChild(legendStrip());
  }

  // ------------------------------------------------------------------ navigation + panels
  var main = document.getElementById('main'), nav = document.getElementById('nav');
  var order = Object.keys(SF.views).map(Number).sort(function (a, b) { return a - b; });
  var panels = {}, current = 0, navBtns = {};
  function buildNav() {
    var toggle = h('button', { type: 'button', class: 'navtoggle', 'aria-expanded': 'false', 'aria-controls': 'navlist' }, h('span', { id: 'navcur', text: 'Views' }), h('span', { 'aria-hidden': 'true', text: '▾' }));
    var ol = h('ol', { id: 'navlist' });
    order.forEach(function (n) {
      var v = SF.views[n], hnt = hint(n);
      var b = h('button', { type: 'button', class: 'navitem', 'data-view': n, on: { click: function () { go(n, true); } } }, h('span', { class: 'n', text: String(n) }), h('span', { text: v.short }), hnt ? h('span', { class: 'st', text: hnt.toUpperCase() }) : null);
      navBtns[n] = b; ol.appendChild(h('li', null, b));
    });
    toggle.addEventListener('click', function () { var o = nav.classList.toggle('open'); toggle.setAttribute('aria-expanded', o ? 'true' : 'false'); });
    nav.appendChild(toggle); nav.appendChild(ol);
  }
  function panelFor(n) {
    if (panels[n]) return panels[n];
    var v = SF.views[n];
    var host = h('div', { class: 'phost' });
    var sec = h('section', { class: 'panel', 'data-view': n, 'aria-labelledby': 'h-' + n, hidden: true },
      h('header', { class: 'phead' }, h('h2', { id: 'h-' + n, tabindex: '-1' }, h('span', { class: 'n', text: String(n).padStart(2, '0') }), v.title), h('p', { class: 'lede', text: v.lede })), host);
    main.appendChild(sec);
    panels[n] = { sec: sec, host: host, w: 0, ms: 0 };
    return panels[n];
  }
  function renderPanel(n) {
    var p = panelFor(n), v = SF.views[n];
    var active = document.activeElement, ctl = active && active.getAttribute && active.getAttribute('data-ctl');
    var sy = window.scrollY;
    runLeave();
    SF.clear(p.host);
    var a = performance.now();
    try {
      v.render(p.host, function () { renderPanel(n); });
    } catch (e) {
      SF.clear(p.host);
      var card = SF.card({ title: 'This panel could not be drawn', provs: ['unavailable'], source: 'dashboard script' });
      card.el.classList.add('render-error');
      card.body.appendChild(SF.unavailable({ why: 'Drawing view ' + n + ' failed: ' + (e && e.message ? e.message : String(e)) + '. The data for it is still embedded in this file (element sramlab-data).' }));
      p.host.appendChild(card.el);
    }
    p.w = main.clientWidth; p.ms = performance.now() - a;
    if (ctl) { var el = p.host.querySelector('[data-ctl="' + ctl.replace(/"/g, '') + '"]'); if (el) { try { el.focus({ preventScroll: true }); } catch (e2) { el.focus(); } } }
    window.scrollTo(0, sy);
  }
  function go(n, push) {
    if (!SF.views[n]) n = order[0];
    if (push && location.hash !== '#v' + n) { try { history.pushState(null, '', '#v' + n); } catch (e) { location.hash = '#v' + n; } }
    if (current && current !== n) runLeave();
    var first = !panels[n];
    var p = panelFor(n);
    Object.keys(panels).forEach(function (k) { panels[k].sec.hidden = (+k !== n); });
    current = n;
    p.sec.hidden = false;
    if (first || Math.abs(main.clientWidth - p.w) > 8) renderPanel(n);
    Object.keys(navBtns).forEach(function (k) { if (+k === n) navBtns[k].setAttribute('aria-current', 'page'); else navBtns[k].removeAttribute('aria-current'); });
    var cur = document.getElementById('navcur'); if (cur) cur.textContent = n + ' · ' + SF.views[n].short;
    nav.classList.remove('open'); var tg = nav.querySelector('.navtoggle'); if (tg) tg.setAttribute('aria-expanded', 'false');
    document.title = 'SRAMLab · ' + SF.views[n].short;
    if (push) { var hd = document.getElementById('h-' + n); if (hd) { try { hd.focus({ preventScroll: true }); } catch (e3) { /* ignore */ } } window.scrollTo(0, 0); }
  }
  function fromHash() { var m = /^#v(\d+)$/.exec(location.hash || ''); return m ? +m[1] : order[0]; }

  // ------------------------------------------------------------------ footer
  function buildFooter() {
    var f = document.getElementById('foot');
    f.appendChild(h('p', { text: 'Every value on this page comes from the JSON embedded in this file (element sramlab-data); nothing is fetched, smoothed or extrapolated. Cycle counts are in clock cycles: no clock frequency is assumed, so there are no MB/s or ns figures.' }));
    f.appendChild(h('p', { text: 'Provenance: ANALYTICAL = closed-form or address arithmetic (dashed or hatched); SIMULATED = verified Python cycle model; SYNTHESIZED = Yosys result (Nangate45 mapping is an open educational 45 nm library, controller logic only, not SilicaFlux silicon area); UNAVAILABLE = cannot be produced. MEASURED: none exists.' }));
    var absent = (DB.absent || []).filter(function (k) { return ['optimise', 'ecc_study', 'mbist_study', 'synth_sweep', 'phys', 'power', 'thermal', 'timeline_trace', 'rtl_verification', 'bank_sweep', 'tensor_study', 'vector_study', 'synth', 'experiments'].indexOf(k) >= 0 && k !== 'synth_sweep'; });
    f.appendChild(h('p', { text: 'Datasets not present in this build: ' + (absent.length ? absent.join(', ') : 'none') + '.' }));
    var le = DB.load_errors || {}, lk = Object.keys(le);
    if (lk.length) f.appendChild(h('p', { style: { color: 'var(--warn)' }, text: 'Unreadable files: ' + lk.map(function (k) { return k + ' (' + le[k] + ')'; }).join('; ') }));
    if ((DB.trim_notes || []).length) {
      var d = h('details', null, h('summary', { text: 'Embedded-data notes (' + DB.trim_notes.length + ')' }));
      d.appendChild(h('ul', null, DB.trim_notes.map(function (t) { return h('li', { text: t }); })));
      f.appendChild(d);
    }
    f.appendChild(h('p', { id: 'perf', class: 'mono', text: '' }));
  }

  // ------------------------------------------------------------------ boot
  try {
    buildHeader(); buildNav(); buildFooter();
    if (DB.__error) {
      main.appendChild(SF.unavailableCard('Embedded data could not be read', { why: 'The embedded JSON failed to parse: ' + DB.__error }));
    } else {
      go(fromHash(), false);
    }
  } catch (e) {
    main.appendChild(h('div', { class: 'unavail render-error', role: 'alert', text: 'The dashboard failed to start: ' + (e && e.message ? e.message : String(e)) }));
  }
  var ms = (window.performance && performance.now) ? performance.now() - t0 : 0;
  var pf = document.getElementById('perf'); if (pf) pf.textContent = 'first render ' + Math.round(ms) + ' ms';
  window.__sramlab = { firstRenderMs: ms, views: order, go: function (n) { go(n, true); }, panelMs: function () { var o = {}; Object.keys(panels).forEach(function (k) { o[k] = panels[k].ms; }); return o; }, version: DB.package_version };
  window.addEventListener('hashchange', function () { go(fromHash(), false); });
  window.addEventListener('popstate', function () { go(fromHash(), false); });
  var rz = null;
  window.addEventListener('resize', function () { if (rz) clearTimeout(rz); rz = setTimeout(function () { var p = panels[current]; if (p && Math.abs(main.clientWidth - p.w) > 8) renderPanel(current); }, 160); });
})();
