/* Views 4, 5, 6, 13: everything driven by data/bank_sweep.json (simulated; analytical peaks kept separate). */
(function () {
  'use strict';
  var SF = window.SF, h = SF.h, s = SF.s;
  var S = SF.state;
  var SRC = 'data/bank_sweep.json (sramlab.experiments.sweep_banks: verified Python cycle model, constant 64 KiB capacity, 10 replications per row, 95% Student-t CI)';
  var WLS = ['rand_read', 'mixed', 'seq_read', 'hotspot', 'contention'];

  function blocks() {
    var d = SF.DS.bank_sweep; if (!d || typeof d !== 'object') return [];
    return Object.keys(d).filter(function (k) { return d[k] && Array.isArray(d[k].rows) && d[k].rows.length; }).sort(function (a, b) { return moOf(a) - moOf(b); });
  }
  function moOf(key) { var m = /(\d+)$/.exec(key); return m ? +m[1] : 0; }
  function rowsOf(key) { var d = SF.DS.bank_sweep; return (d && d[key] && d[key].rows) || []; }
  function allRows() { var out = []; blocks().forEach(function (k) { rowsOf(k).forEach(function (r) { out.push({ r: r, key: k, mo: moOf(k) }); }); }); return out; }
  function sweepMissing(title, extra) {
    var d = SF.DS.bank_sweep;
    return SF.unavailableCard(title, { why: d ? 'data/bank_sweep.json is present but has no usable rows' + (extra ? ' (' + extra + ')' : '') + '.' : SF.absentReason('bank_sweep.json'),
      unlocks: ['Regenerate the sweep: python3 scripts/generate_data.py --only bank_sweep'], source: 'data/bank_sweep.json' });
  }
  function wordBytes(r) { var cap = r.capacity_bytes, d = r.bank_depth_words; return SF.isNum(cap) && SF.isNum(d) && d > 0 && r.banks > 0 ? cap / (r.banks * d) : null; }
  function ensure() {
    var bl = blocks();
    if (!S.sw) S.sw = {};
    var st = S.sw;
    if (!st.mo || bl.indexOf(st.mo) < 0) st.mo = bl[0];
    var rows = rowsOf(st.mo), wls = SF.uniq(rows.map(function (r) { return r.workload; })), bks = SF.sortNum(SF.uniq(rows.map(function (r) { return r.banks; })));
    if (!st.wl || (st.wl !== 'all' && wls.indexOf(st.wl) < 0)) st.wl = wls.indexOf('mixed') >= 0 ? 'mixed' : wls[0];
    if (!st.banks || bks.indexOf(+st.banks) < 0) st.banks = bks.indexOf(4) >= 0 ? 4 : bks[0];
    st.banks = +st.banks;
    return { bl: bl, st: st, wls: wls, bks: bks };
  }
  function moOpts(bl) { return bl.map(function (k) { return { v: k, t: 'MAX_OUT = ' + moOf(k) }; }); }
  function wlOrder(wls) { return WLS.filter(function (w) { return wls.indexOf(w) >= 0; }).concat(wls.filter(function (w) { return WLS.indexOf(w) < 0; })); }

  // ================================================================== 4. Read / write bandwidth
  function renderBandwidth(host, refresh) {
    var e = ensure();
    if (!e.bl.length) { host.appendChild(sweepMissing('Read/write bandwidth')); return; }
    var st = e.st, rows = rowsOf(st.mo);
    var hasRW = rows.every(function (r) { return r.read_bytes_per_cycle && r.write_bytes_per_cycle; });
    if (!hasRW) { host.appendChild(sweepMissing('Read/write bandwidth', 'read_bytes_per_cycle / write_bytes_per_cycle are missing; regenerate with the current generator')); return; }
    host.appendChild(SF.controls(
      SF.select('sw-mo', 'Outstanding requests', moOpts(e.bl), st.mo, function (v) { st.mo = v; refresh(); }),
      SF.select('sw-wl', 'Workload', [{ v: 'all', t: 'all workloads (small multiples)' }].concat(wlOrder(e.wls).map(function (w) { return { v: w }; })), st.wl, function (v) { st.wl = v; refresh(); })));
    var list = st.wl === 'all' ? wlOrder(e.wls) : [st.wl];
    var cap = SF.get(SF.DS.bank_sweep, st.mo, 'capacity_bytes');
    var grid = h('div', { class: 'grid ' + (list.length > 1 ? 'g2' : '') });
    host.appendChild(grid);
    var tableRows = [];
    list.forEach(function (wl) {
      var rs = rows.filter(function (r) { return r.workload === wl; }).sort(function (a, b) { return a.banks - b.banks; });
      var c = SF.card({ title: wl.replace('_', ' ') + ': bytes per cycle vs banks', provs: ['simulated', 'analytical'],
        source: SRC + '; analytical peak = analytical_peak_txn_per_cycle x word bytes' });
      grid.appendChild(c.el);
      var pk = rs.map(function (r) { var wb = wordBytes(r); return { x: r.banks, y: wb !== null && SF.isNum(r.analytical_peak_txn_per_cycle) ? r.analytical_peak_txn_per_cycle * wb : null }; });
      var mk = function (f) { return rs.map(function (r) { var q = SF.stat(r[f]); return { x: r.banks, y: q.m, hw: q.hw, n: q.n }; }); };
      var rd = SF.style(0), wr = SF.style(1), tt = SF.style(2);
      SF.lineChart(c.body, { aria: 'Read and write bytes per cycle versus bank count for ' + wl, xLabel: 'Banks (log2 spacing)', yLabel: 'Bytes per cycle', unit: 'B/cycle', yFmt: undefined,
        xTicks: SF.sortNum(SF.uniq(rs.map(function (r) { return r.banks; }))),
        series: [
          { id: 'read', name: 'read (simulated)', color: rd.color, marker: rd.marker, pts: mk('read_bytes_per_cycle') },
          { id: 'write', name: 'write (simulated)', color: wr.color, marker: wr.marker, pts: mk('write_bytes_per_cycle') },
          { id: 'total', name: 'read + write, useful (simulated)', color: tt.color, marker: tt.marker, pts: mk('useful_bytes_per_cycle') },
          { id: 'peak', name: 'analytical peak, read + write', color: SF.SILVER, dash: '7 5', pts: pk }
        ], height: list.length > 1 ? 250 : 320 });
      rs.forEach(function (r) { tableRows.push({ wl: wl, r: r, wb: wordBytes(r) }); });
    });
    var tcard = SF.card({ title: 'Bandwidth table (mean, 95% CI half-width, n)', provs: ['simulated', 'analytical'], source: SRC });
    host.appendChild(h('div', { style: { height: '16px' } }));
    host.appendChild(tcard.el);
    tcard.body.appendChild(SF.table([
      { label: 'Workload', get: function (x) { return x.wl; } }, { label: 'Banks', num: true, get: function (x) { return x.r.banks; } },
      { label: 'Read B/cycle', num: true, get: function (x) { return SF.pm(x.r.read_bytes_per_cycle, 4); } },
      { label: 'Write B/cycle', num: true, get: function (x) { return SF.pm(x.r.write_bytes_per_cycle, 4); } },
      { label: 'Total B/cycle', num: true, get: function (x) { return SF.pm(x.r.useful_bytes_per_cycle, 4); }, sort: function (x) { return SF.stat(x.r.useful_bytes_per_cycle).m; } },
      { label: 'Analytical peak B/cycle', num: true, get: function (x) { return x.wb !== null ? SF.fmt(x.r.analytical_peak_txn_per_cycle * x.wb, 4) : null; } },
      { label: 'Analytical random estimate B/cycle', num: true, get: function (x) { return x.wb !== null && SF.isNum(x.r.analytical_random_estimate_txn_per_cycle) ? SF.fmt(x.r.analytical_random_estimate_txn_per_cycle * x.wb, 4) : null; } }
    ], tableRows, { caption: 'Bytes per cycle (no clock is assumed, so no MB/s). Capacity ' + (cap ? cap / 1024 + ' KiB' : 'unknown') + ' held constant across bank counts.' }));
  }
  SF.registerView(4, 'Read/write bandwidth', 'Read / write bandwidth',
    'Simulated read and write bytes per cycle against bank count, with the closed-form analytical peak as a dashed line. Whiskers are 95% confidence intervals over replications.', renderBandwidth);

  // ================================================================== 5. Latency distribution
  function renderLatency(host, refresh) {
    var e = ensure();
    if (!e.bl.length) { host.appendChild(sweepMissing('Latency distribution')); return; }
    var st = e.st, rows = rowsOf(st.mo);
    if (st.wl === 'all') st.wl = e.wls.indexOf('mixed') >= 0 ? 'mixed' : e.wls[0];
    var hasHist = rows.some(function (r) { return r.latency_histogram && Object.keys(r.latency_histogram).length; });
    if (!hasHist) { host.appendChild(sweepMissing('Latency distribution', 'latency_histogram is missing; regenerate with the current generator')); return; }
    host.appendChild(SF.controls(
      SF.select('sw-mo', 'Outstanding requests', moOpts(e.bl), st.mo, function (v) { st.mo = v; refresh(); }),
      SF.select('sw-wl', 'Workload', wlOrder(e.wls).map(function (w) { return { v: w }; }), st.wl, function (v) { st.wl = v; refresh(); }),
      SF.select('sw-b', 'Banks', e.bks.map(function (b) { return { v: b }; }), st.banks, function (v) { st.banks = +v; refresh(); })));
    var r = rows.filter(function (q) { return q.workload === st.wl && q.banks === st.banks; })[0];
    if (!r || !r.latency_histogram) { host.appendChild(SF.unavailableCard('Latency distribution', { why: 'No histogram was recorded for ' + st.wl + ' at ' + st.banks + ' banks, MAX_OUT ' + moOf(st.mo) + '.', source: 'data/bank_sweep.json' })); return; }
    var keys = Object.keys(r.latency_histogram).map(Number).sort(function (a, b) { return a - b; });
    var total = SF.sum(keys.map(function (k) { return r.latency_histogram[k]; }));
    var bins = keys.map(function (k) { return { x: k, y: r.latency_histogram[k] / total, count: r.latency_histogram[k] }; });
    var mean = SF.stat(r.read_latency_mean), p99 = SF.stat(r.read_latency_p99);
    var c = SF.card({ title: 'End-to-end read latency: ' + st.wl.replace('_', ' ') + ', ' + st.banks + ' banks, MAX_OUT ' + moOf(st.mo), provs: ['simulated'],
      source: SRC + '; histogram pooled over all replications (' + (r.replications || '?') + ') of this configuration' });
    host.appendChild(c.el);
    c.body.appendChild(h('div', { class: 'stats' },
      h('div', { class: 'stat' }, h('div', { class: 'l', text: 'Mean latency' }), h('div', { class: 'v', text: SF.fmt(mean.m, 4) + ' cycles' }), h('div', { class: 's', text: mean.hw !== null ? '± ' + SF.fmt(mean.hw, 2) + ' (95% CI), n=' + mean.n : 'no CI' })),
      h('div', { class: 'stat' }, h('div', { class: 'l', text: 'p99 latency' }), h('div', { class: 'v', text: SF.fmt(p99.m, 4) + ' cycles' }), h('div', { class: 's', text: 'mean of per-replication p99' + (p99.hw !== null ? ' ± ' + SF.fmt(p99.hw, 2) : '') + ', n=' + p99.n })),
      h('div', { class: 'stat' }, h('div', { class: 'l', text: 'Reads in histogram' }), h('div', { class: 'v', text: SF.fmt(total) }), h('div', { class: 's', text: 'pooled over ' + (r.replications || '?') + ' replications' }))));
    SF.histogram(c.body, { aria: 'Histogram of end-to-end read latency in cycles', xLabel: 'End-to-end read latency (cycles)', yLabel: 'Fraction of read responses', xName: 'latency', yName: 'fraction of reads', color: SF.PAL[0],
      legendName: 'fraction of reads at each latency', yFmt: function (v) { return SF.fmt(v, 2); }, yFmtTip: function (b) { return SF.pct(b.y, 3); }, bins: bins,
      markers: [{ x: mean.m, hw: mean.hw, label: 'mean ' + SF.fmt(mean.m, 3), legend: 'mean latency (band = 95% CI)', color: '#d4af37' }, { x: p99.m, label: 'p99 ' + SF.fmt(p99.m, 3), legend: 'p99 latency', color: '#f472b6', dash: '7 5' }] });
    c.body.appendChild(SF.tableView('Histogram table (latency in cycles, response count, fraction)', [
      { label: 'Latency (cycles)', num: true, get: function (b) { return b.x; } }, { label: 'Responses', num: true, get: function (b) { return b.count; } }, { label: 'Fraction', num: true, get: function (b) { return SF.pct(b.y, 4); }, sort: function (b) { return b.y; } }], bins));
  }
  SF.registerView(5, 'Latency distribution', 'Latency distribution',
    'End-to-end read latency histogram for a chosen workload, bank count and outstanding-request limit, with mean and p99 marked.', renderLatency);

  // ================================================================== 6. Bank conflict heatmap
  S.hm = S.hm || { metric: 'conflict_cycle_fraction_per_bank' };
  var HM_METRICS = {
    conflict_cycle_fraction_per_bank: { t: 'Conflict cycle fraction', fixed: [0, 1], fmt: function (v) { return SF.fmt(v * 100, 2) + '%'; } },
    bank_utilisation_per_bank: { t: 'Bank utilisation', fixed: [0, 1], fmt: function (v) { return SF.fmt(v * 100, 2) + '%'; } },
    tracker_occupancy_mean_per_bank: { t: 'Mean tracker occupancy', fixed: null, fmt: function (v) { return SF.fmt(v, 3); } }
  };
  function renderHeatmap(host, refresh) {
    var e = ensure();
    if (!e.bl.length) { host.appendChild(sweepMissing('Bank conflict heatmap')); return; }
    var st = e.st, hm = S.hm, rows = rowsOf(st.mo);
    var key = hm.metric;
    if (!rows.some(function (r) { return Array.isArray(r[key]) && r[key].length; })) {
      host.appendChild(sweepMissing('Bank conflict heatmap', key + ' is missing; regenerate with the current generator')); return;
    }
    host.appendChild(SF.controls(
      SF.select('sw-mo', 'Outstanding requests', moOpts(e.bl), st.mo, function (v) { st.mo = v; refresh(); }),
      SF.select('sw-b', 'Banks', e.bks.map(function (b) { return { v: b }; }), st.banks, function (v) { st.banks = +v; refresh(); }),
      SF.select('hm-m', 'Per-bank metric', Object.keys(HM_METRICS).map(function (k) { return { v: k, t: HM_METRICS[k].t }; }), hm.metric, function (v) { hm.metric = v; refresh(); })));
    var wls = wlOrder(e.wls), M = HM_METRICS[key], vals = [], maxv = 0, nCells = 0;
    wls.forEach(function (w) {
      var r = rows.filter(function (q) { return q.workload === w && q.banks === st.banks; })[0];
      var arr = r && Array.isArray(r[key]) ? r[key].map(function (v) { return SF.isNum(v) ? v : null; }) : null;
      var line = []; for (var b = 0; b < st.banks; b++) { var v = arr ? arr[b] : null; line.push(v === undefined ? null : v); if (SF.isNum(v)) { maxv = Math.max(maxv, v); nCells++; } }
      vals.push(line);
    });
    if (!nCells) { host.appendChild(SF.unavailableCard('Bank conflict heatmap', { why: 'No per-bank values for ' + st.banks + ' banks at MAX_OUT ' + moOf(st.mo) + '.', source: 'data/bank_sweep.json' })); return; }
    var vmin = 0, vmax = M.fixed ? M.fixed[1] : (maxv || 1);
    if (M.fixed && maxv > 0 && maxv < 0.5) vmax = Math.max(0.05, Math.ceil(maxv * 20) / 20);   // keep contrast when every value is small; the colour bar states the range
    var c = SF.card({ title: M.t + ' by workload and bank (' + st.banks + ' banks, MAX_OUT ' + moOf(st.mo) + ')', provs: ['simulated'],
      note: 'Per-bank values come from the FIRST replication of each configuration only (n = 1), so no confidence interval exists for a cell. The colour bar shows the scale in use; gray hatched cells mean no value was recorded.',
      source: SRC + '; fields conflict_cycle_fraction_per_bank / bank_utilisation_per_bank / tracker_occupancy_mean_per_bank' });
    host.appendChild(c.el);
    SF.heatmap(c.body, { aria: M.t + ' per workload and bank', rows: wls.map(function (w) { return w.replace('_', ' '); }), cols: vals[0].map(function (_, b) { return 'bank ' + b; }), vals: vals, vmin: vmin, vmax: vmax,
      fmt: M.fmt, valueName: M.t, xLabel: 'Bank', yLabel: 'Workload', cellH: 38,
      tip: function (r, cI, v) { return SF.tipContent(wls[r].replace('_', ' ') + ', bank ' + cI, [{ k: M.t, v: SF.isNum(v) ? M.fmt(v) : 'unavailable' }], 'first replication only (n=1), no CI'); } });
    c.body.appendChild(SF.tableView('Heatmap values (table view)', [{ label: 'Workload', get: function (x) { return x.w; } }].concat(vals[0].map(function (_, b) { return { label: 'Bank ' + b, num: true, get: function (x) { return SF.isNum(x.v[b]) ? M.fmt(x.v[b]) : null; } }; })),
      wls.map(function (w, i) { return { w: w, v: vals[i] }; })));
  }
  SF.registerView(6, 'Bank conflict heatmap', 'Bank conflict heatmap',
    'Which banks lose arbitration for which workloads: per-bank conflict cycle fraction (or utilisation, or tracker occupancy) across the workload suite.', renderHeatmap);

  // ================================================================== 13. Configuration comparison
  var CMP = [
    { f: 'throughput_txn_per_cycle', t: 'Throughput', u: 'txn/cycle', better: 'higher' },
    { f: 'useful_bytes_per_cycle', t: 'Useful bandwidth', u: 'B/cycle', better: 'higher' },
    { f: 'read_latency_mean', t: 'Mean read latency', u: 'cycles', better: 'lower' },
    { f: 'read_latency_p99', t: 'p99 read latency', u: 'cycles', better: 'lower' },
    { f: 'conflict_rate_per_access', t: 'Conflict rate per access', u: 'per access', better: 'lower' },
    { f: 'bank_utilisation_mean', t: 'Mean bank utilisation', u: 'fraction', better: 'higher' },
    { f: 'arbitration_delay_mean', t: 'Mean arbitration delay', u: 'cycles', better: 'lower' },
    { f: 'bit_activations_per_useful_byte', t: 'Array bit activations per useful byte', u: 'bits/B (activity proxy, not energy)', better: 'lower' }
  ];
  function cfgId(x) { return x.key + '|' + x.r.workload + '|' + x.r.banks; }
  function cfgLabel(x) { return 'MAX_OUT ' + x.mo + ' · ' + x.r.workload.replace('_', ' ') + ' · ' + x.r.banks + ' banks'; }
  function renderCompare(host, refresh) {
    var all = allRows();
    if (!all.length) { host.appendChild(sweepMissing('Configuration comparison')); return; }
    if (!S.cmp) S.cmp = {};
    var cm = S.cmp, byId = {}; all.forEach(function (x) { byId[cfgId(x)] = x; });
    var ids = all.map(cfgId);
    var keys = blocks();
    if (!cm.a || !byId[cm.a]) cm.a = byId[keys[0] + '|mixed|4'] ? keys[0] + '|mixed|4' : ids[0];
    if (!cm.b || !byId[cm.b]) cm.b = byId[keys[keys.length - 1] + '|mixed|4'] && keys[keys.length - 1] + '|mixed|4' !== cm.a ? keys[keys.length - 1] + '|mixed|4' : (ids[1] || ids[0]);
    var opts = all.map(function (x) { return { v: cfgId(x), t: cfgLabel(x) }; });
    host.appendChild(SF.controls(
      SF.select('cmp-a', 'Configuration A', opts, cm.a, function (v) { cm.a = v; refresh(); }),
      SF.select('cmp-b', 'Configuration B', opts, cm.b, function (v) { cm.b = v; refresh(); })));
    var A = byId[cm.a], B = byId[cm.b];
    var ca = SF.PAL[0], cb = SF.PAL[1];
    var top = SF.card({ title: 'A vs B: ' + cfgLabel(A) + '  vs  ' + cfgLabel(B), provs: ['simulated'], source: SRC,
      note: 'Bars are means over replications with 95% confidence-interval whiskers. "Distinguishable" means the two 95% intervals do not overlap (a conservative test); overlapping intervals are reported as not distinguishable, never as equal.' });
    host.appendChild(top.el);
    top.body.appendChild(SF.legend([{ name: 'A: ' + cfgLabel(A), kind: 'bar', color: ca }, { name: 'B: ' + cfgLabel(B), kind: 'bar', color: cb }]));
    var grid = h('div', { class: 'grid g3', style: { marginTop: '10px' } });
    top.body.appendChild(grid);
    var cmpRows = [];
    CMP.forEach(function (m) {
      var sa = SF.stat(A.r[m.f]), sb = SF.stat(B.r[m.f]);
      var cell = h('section', { class: 'card flat', 'aria-label': m.t, style: { border: '1px solid var(--line)' } }, h('div', { class: 'chead' }, h('h3', { text: m.t, style: { fontSize: '13.5px' } }), h('span', { class: 'muted', text: m.u })));
      grid.appendChild(cell);
      var body = h('div'); cell.appendChild(body);
      if (sa.m === null || sb.m === null) { body.appendChild(SF.unavailable({ why: 'Not recorded for one of the two configurations.' })); return; }
      SF.groupedBars(body, { aria: m.t + ' for A and B', cats: [m.t], series: [{ id: 'A', name: 'A', color: ca, vals: [A.r[m.f]] }, { id: 'B', name: 'B', color: cb, vals: [B.r[m.f]] }],
        yLabel: m.u.length > 18 ? '' : m.u, unit: m.u, height: 190, legend: false, valueLabels: true, margin: { r: 8 } });
      var d = sb.m - sa.m, rel = sa.m ? d / sa.m : null;
      var haveCI = sa.hw !== null && sb.hw !== null;
      var overlap = haveCI ? !(sa.m + sa.hw < sb.m - sb.hw || sb.m + sb.hw < sa.m - sa.hw) : null;
      var verdict = !haveCI ? 'no CI available' : (overlap ? 'not distinguishable at 95% (intervals overlap)' : 'distinguishable at 95% (intervals do not overlap)');
      body.appendChild(h('p', { class: 'note', style: { marginTop: '4px' } }, 'B − A = ', h('b', { text: (d >= 0 ? '+' : '') + SF.fmt(d, 3) }), rel !== null ? ' (' + (rel >= 0 ? '+' : '') + SF.fmt(rel * 100, 3) + ' %)' : '', ' — ', verdict));
      cmpRows.push({ m: m, a: A.r[m.f], b: B.r[m.f], d: d, rel: rel, verdict: verdict });
    });
    top.body.appendChild(SF.tableView('A vs B table view', [
      { label: 'Metric', get: function (x) { return x.m.t + ' (' + x.m.u + ')'; } }, { label: 'A (mean ± 95% CI, n)', num: true, get: function (x) { return SF.pm(x.a, 4); } },
      { label: 'B (mean ± 95% CI, n)', num: true, get: function (x) { return SF.pm(x.b, 4); } }, { label: 'B − A', num: true, get: function (x) { return SF.fmt(x.d, 3); }, sort: function (x) { return x.d; } },
      { label: 'Relative', num: true, get: function (x) { return x.rel === null ? null : SF.fmt(x.rel * 100, 3) + ' %'; }, sort: function (x) { return x.rel; } }, { label: 'Verdict', get: function (x) { return x.verdict; } }], cmpRows));

    var tc = SF.card({ title: 'All configurations (' + all.length + ' rows)', provs: ['simulated', 'analytical'], source: SRC });
    host.appendChild(tc.el);
    var num = function (f, d) { return function (x) { return SF.pm(x.r[f], d || 4); }; };
    var srt = function (f) { return function (x) { return SF.stat(x.r[f]).m; }; };
    tc.body.appendChild(SF.table([
      { label: 'MAX_OUT', num: true, get: function (x) { return x.mo; } }, { label: 'Workload', get: function (x) { return x.r.workload; } }, { label: 'Banks', num: true, get: function (x) { return x.r.banks; } },
      { label: 'Throughput txn/cycle', num: true, get: num('throughput_txn_per_cycle'), sort: srt('throughput_txn_per_cycle') },
      { label: 'Useful B/cycle', num: true, get: num('useful_bytes_per_cycle'), sort: srt('useful_bytes_per_cycle') },
      { label: 'Read latency (cycles)', num: true, get: num('read_latency_mean'), sort: srt('read_latency_mean') },
      { label: 'p99 (cycles)', num: true, get: num('read_latency_p99'), sort: srt('read_latency_p99') },
      { label: 'Conflict rate', num: true, get: num('conflict_rate_per_access'), sort: srt('conflict_rate_per_access') },
      { label: 'Bank util.', num: true, get: num('bank_utilisation_mean'), sort: srt('bank_utilisation_mean') },
      { label: 'Arb. delay (cycles)', num: true, get: num('arbitration_delay_mean'), sort: srt('arbitration_delay_mean') },
      { label: 'Analytical peak txn/cycle', num: true, get: function (x) { return SF.isNum(x.r.analytical_peak_txn_per_cycle) ? SF.fmt(x.r.analytical_peak_txn_per_cycle, 4) : null; }, sort: function (x) { return x.r.analytical_peak_txn_per_cycle; } }
    ], all, { caption: 'Click a column heading to sort. Every simulated cell is mean ± 95% CI half-width (n replications); the analytical peak is a closed-form ceiling and carries no CI.' }));
  }
  SF.registerView(13, 'Configuration comparison', 'Configuration comparison',
    'Pick two simulated configurations and compare every metric side by side with 95% confidence intervals; the full table of all rows is below.', renderCompare);
})();
