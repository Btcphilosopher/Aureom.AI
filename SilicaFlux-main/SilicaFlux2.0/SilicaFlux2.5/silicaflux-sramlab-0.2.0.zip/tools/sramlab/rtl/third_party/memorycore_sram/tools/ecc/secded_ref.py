#!/usr/bin/env python3
"""Independent SECDED reference model + golden-vector generator for MemoryCore ECC verification.

Written from the DOCUMENTED code layout (third_party/ras_secded/sfras_ecc_funcs.svh header), not from the RTL:
  * extended Hamming code, K data bits, R = smallest r with 2**r >= K+r+1 check bits, 1 overall parity bit
  * Hamming position (the syndrome value naming a bit): check bit j -> 2**j; data bit i -> the (i+1)-th integer >= 3
    that is not a power of two; overall parity -> position 0 (not covered by the syndrome)
  * stored word (LSB first): data[K-1:0], check[R-1:0], parity   -> N = K+R+1 bits
  * check-bit inversion INV (R+1 bits, applied to {parity, check}): even weight 2; the first pair a<b (bit indices 0..R)
    for which BOTH the all-zero and the all-ones stored word decode as UNCORRECTABLE; if no pair does, the pair (0,1).
    The pair is found HERE by decoding candidate words with the brute-force decoder below.

Decoder (documented classification): s = recomputed checks XOR stored checks, pe = overall parity over all stored bits
(after removing INV).  (s==0,pe==0) NONE; (s==0,pe==1) CE parity bit; (s!=0,pe==1,s<=K+R) CE at position s;
(s!=0,pe==1,s>K+R) UE invalid syndrome; (s!=0,pe==0) UE double.

Outputs (deterministic, SEED fixed):
  tb/vectors/ecc_k<K>_enc.hex   one line per vector: data(hex) codeword(hex)
  tb/vectors/ecc_k<K>_err.hex   one line per corrupted word: corrupted_codeword class(0..4) data_out(hex)
  tb/vectors/ecc_k<K>_meta.txt  K R N INV and statistics (e.g. the exact miscorrection rate of random triple errors)
Self-checks (run by --selftest and always before writing): every single-bit error corrected, every double-bit error
detected (for sampled words), encode/decode round trip, all H columns distinct and odd/even structure.
"""
import argparse, os, random, sys

NONE, CE_DATA, CE_CHECK, UE_DOUBLE, UE_INVALID = 0, 1, 2, 3, 4


def rbits(k):
    r = 1
    while (1 << r) < k + r + 1:
        r += 1
    return r


def dpos(i):
    p = i + 1
    t = 0
    while (1 << t) <= p:
        p += 1
        t += 1
    return p


class Code:
    def __init__(self, k):
        self.k = k
        self.r = rbits(k)
        self.n = k + self.r + 1
        self.pos = [dpos(i) for i in range(k)]
        assert len(set(self.pos)) == k and all(p & (p - 1) for p in self.pos) and max(self.pos) <= k + self.r
        self.inv = self._pick_inv()

    # ---- raw (un-inverted) encode: returns (checks, parity)
    def _chk(self, data):
        c = 0
        for i in range(self.k):
            if (data >> i) & 1:
                c ^= self.pos[i]
        return c

    def encode(self, data, inv=None):
        inv = self.inv if inv is None else inv
        c = self._chk(data)
        p = (bin(data).count("1") + bin(c).count("1")) & 1            # even overall parity over data+checks
        word = data | (c << self.k) | (p << (self.k + self.r))
        return word ^ (inv << self.k)

    def decode(self, word, inv=None):
        """-> (class, data_out, corrected_word)"""
        inv = self.inv if inv is None else inv
        w = word ^ (inv << self.k)
        data = w & ((1 << self.k) - 1)
        c = (w >> self.k) & ((1 << self.r) - 1)
        p = (w >> (self.k + self.r)) & 1
        s = self._chk(data) ^ c
        pe = (p + bin(data).count("1") + bin(c).count("1")) & 1
        if s == 0 and pe == 0:
            return NONE, data, word
        if s == 0 and pe == 1:
            return CE_CHECK, data, word ^ (1 << (self.k + self.r))            # the parity bit itself flipped
        if pe == 0:
            return UE_DOUBLE, data, word
        if s > self.k + self.r:
            return UE_INVALID, data, word
        for i in range(self.k):                                                # position s names a data bit?
            if self.pos[i] == s:
                return CE_DATA, data ^ (1 << i), word ^ (1 << i)
        j = s.bit_length() - 1                                                 # power of two -> check bit j
        assert (1 << j) == s
        return CE_CHECK, data, word ^ (1 << (self.k + j))

    def _pick_inv(self):
        ones = (1 << self.n) - 1
        best = None
        for a in range(self.r + 1):
            for b in range(a + 1, self.r + 1):
                inv = (1 << a) | (1 << b)
                if self.decode(0, inv)[0] >= UE_DOUBLE and self.decode(ones, inv)[0] >= UE_DOUBLE:
                    return inv
        return 3                                                               # documented fallback pair (0,1)

    def all_zero_is_ue(self):
        return self.decode(0)[0] >= UE_DOUBLE


def selftest(c, rng, nwords=6):
    for _ in range(nwords):
        d = rng.getrandbits(c.k)
        w = c.encode(d)
        assert c.decode(w) == (NONE, d, w)
        for b in range(c.n):                                                   # all single errors corrected
            cls, dd, ww = c.decode(w ^ (1 << b))
            assert cls in (CE_DATA, CE_CHECK) and dd == d and ww == w, (b, cls)
        for b1 in range(c.n):                                                  # all double errors detected
            for b2 in range(b1 + 1, c.n):
                cls, _, _ = c.decode(w ^ (1 << b1) ^ (1 << b2))
                assert cls in (UE_DOUBLE,), (b1, b2, cls)
    assert c.all_zero_is_ue(), "default inversion must make the all-zero word uncorrectable"


def gen(k, outdir, seed, nenc, nerr):
    c = Code(k)
    rng = random.Random(seed)
    selftest(c, rng)
    os.makedirs(outdir, exist_ok=True)
    hexw = lambda v, bits: format(v, "0%dx" % ((bits + 3) // 4))
    words = [0, (1 << k) - 1, 0x5555555555555555 * ((k + 63) // 64) & ((1 << k) - 1),
             0xAAAAAAAAAAAAAAAA * ((k + 63) // 64) & ((1 << k) - 1)]
    words += [1 << i for i in range(k)] + [((1 << k) - 1) ^ (1 << i) for i in range(0, k, 7)]
    words += [rng.getrandbits(k) for _ in range(nenc - len(words))]
    with open(os.path.join(outdir, f"ecc_k{k}_enc.hex"), "w") as f:
        for d in words:
            f.write(f"{hexw(d, k)} {hexw(c.encode(d), c.n)}\n")
    # corrupted words of weight 3..6 (plus a few weight 1/2) with the reference decoder's verdict
    stats = {}
    with open(os.path.join(outdir, f"ecc_k{k}_err.hex"), "w") as f:
        for i in range(nerr):
            w = rng.choice(words)
            wt = rng.choice([1, 2, 3, 3, 3, 4, 4, 5, 6])
            bits = rng.sample(range(c.n), wt)
            bad = c.encode(w)
            for b in bits:
                bad ^= 1 << b
            cls, dd, _ = c.decode(bad)
            stats.setdefault(wt, {}).setdefault(cls, 0)
            stats[wt][cls] += 1
            f.write(f"{hexw(bad, c.n)} {cls:x} {hexw(dd, k)}\n")
    names = {NONE: "NONE", CE_DATA: "CE_DATA", CE_CHECK: "CE_CHECK", UE_DOUBLE: "UE_DOUBLE", UE_INVALID: "UE_INVALID"}
    with open(os.path.join(outdir, f"ecc_k{k}_meta.txt"), "w") as f:
        f.write(f"K={k} R={c.r} N={c.n} INV=0x{c.inv:x} seed={seed} enc_vectors={len(words)} err_vectors={nerr}\n")
        for wt in sorted(stats):
            f.write(f"weight {wt}: " + ", ".join(f"{names[x]}={n}" for x, n in sorted(stats[wt].items())) + "\n")
    print(f"K={k}: R={c.r} N={c.n} INV=0x{c.inv:x}  {len(words)} encode vectors, {nerr} error vectors -> {outdir}")
    return c, stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tb", "vectors"))
    ap.add_argument("--seed", type=int, default=0x5EC0DED)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    for k, ne, nr in ((128, 400, 4000), (64, 200, 2000), (32, 100, 1000)):
        gen(k, os.path.abspath(a.out), a.seed + k, ne, nr)
    if a.selftest:
        print("selftest: OK (single errors corrected, double errors detected, round trips, default inversion)")


if __name__ == "__main__":
    sys.exit(main())
