// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_fsm   (MBIST engine: algorithm sequencing, op issue, compare)
//
//   IDLE -> CHECK -> ACQ -> BSEL -> PINIT -> RUN -> DRAIN -> BEND -+-> BSEL / PINIT (next bank / next pass)
//                      |                                           +-> REL -> FIN -> IDLE
//                      +-- refused -----------------------------------------> FIN
//
// IDLE   start_i latches the configuration; nothing else is looked at.
// CHECK  start validation.  A refused start (REFUSED result, MB_ERR_* flag) never requests ownership and never
//        touches the memory.  Checks: permission, configuration sanity, selection non-empty, every selected bank
//        physically accessible (ACCESS_MASK), protected banks, unread failure data.
// ACQ    own_req_o = 1: the arbiter quiesces, drains and confirms ownership (own_ok_i).  Ownership fault,
//        permission loss, abort or watchdog leave through REL.
// BSEL   next selected bank (ascending index; one bank at a time bounds test power).
// PINIT  start of a pass over the bank: element 0, op 0; the address sequencer is loaded.
// RUN    one raw test operation per cycle.  An operation is issued only in a cycle in which own_ok_i AND
//        permit_i hold and no halt condition (abort, watchdog, stop-on-fail, ownership fault) is pending.
// DRAIN  LT cycles: reads still in flight (LT = READ_LATENCY + TEST_PIPE) are compared before anything changes.
// BEND   bank/pass bookkeeping.  A bank counts as tested only when its LAST pass completed.
// REL    own_req_o = 0: arbiter releases the bus, re-initialises the array (if the engine wrote it), then
//        reports own_idle_i.
// FIN    result: REFUSED > ERROR > ABORTED > FAIL > PASS.  PASS additionally requires that every selected bank
//        was tested -- a run that stopped early for any reason can never report PASS.
//
// Timing: op issue is combinational from registered state (op, address, element), so tst_* change in the cycle
// the operation is accepted by the memory.  Read data is compared exactly LT cycles after the issue cycle
// (the memory contract: tst_rdata is valid exactly READ_LATENCY cycles after the accepting edge and is never
// held; sf_sram_core / sf_sram_bank behave this way).  The expected word is regenerated from
// (pattern, row, polarity) at the compare stage; no wide expected-data pipeline is needed.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_mbist_defs.svh"
`default_nettype none

module sf_mbist_fsm #(
  parameter int NBANK       = 4,
  parameter int ROWS        = 64,
  parameter int ROW_W       = (ROWS > 1) ? $clog2(ROWS) : 1,
  parameter int W           = 32,
  parameter int DATA_W      = 32,
  parameter int LT          = 1,
  parameter int BW          = (NBANK > 1) ? $clog2(NBANK) : 1,
  parameter logic [NBANK-1:0] ACCESS_MASK = {NBANK{1'b1}},
  parameter logic [NBANK-1:0] SHARED_MASK = {NBANK{1'b1}},
  parameter logic [NBANK-1:0] TENSOR_MASK = '0,
  parameter logic [NBANK-1:0] VECTOR_MASK = '0,
  parameter int STRIPE_KMAX = (W > 1) ? $clog2(W) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---- commands (1-cycle pulses)
  input  wire logic                start_i,
  input  wire logic                start_clr_i,     // with start_i: ignore unread results (they are cleared by the start)
  input  wire logic                abort_i,
  input  wire logic                clear_i,
  // ---- configuration (live; latched when a start is accepted into CHECK)
  input  wire logic [3:0]          cfg_algo_i,
  input  wire logic [2:0]          cfg_pattern_i,
  input  wire logic [3:0]          cfg_stripe_k_i,
  input  wire logic                cfg_sweep_i,
  input  wire logic [1:0]          cfg_colsel_i,
  input  wire logic                cfg_stop_i,
  input  wire logic                cfg_reinit_i,
  input  wire logic [2:0]          cfg_sel_i,
  input  wire logic [7:0]          cfg_bank_i,
  input  wire logic [NBANK-1:0]    cfg_bmask_i,
  input  wire logic [31:0]         cfg_row_lo_i,    // 32 bit on purpose: an out-of-range value is REFUSED, never wrapped
  input  wire logic [31:0]         cfg_row_hi_i,
  input  wire logic [31:0]         cfg_wdog_i,
  // ---- context
  input  wire logic                permit_i,
  input  wire logic [NBANK-1:0]    protect_i,
  input  wire logic                cpu_halted_i,
  input  wire logic                results_pending_i,
  // ---- arbiter
  output logic                     own_req_o,
  input  wire logic                own_ok_i,
  input  wire logic                own_idle_i,
  input  wire logic                own_fault_i,
  output logic                     dirty_o,
  output logic                     reinit_en_o,
  // ---- raw test bus
  output logic [NBANK-1:0]         tst_sel_o,
  output logic                     tst_ce_o,
  output logic                     tst_we_o,
  output logic [ROW_W-1:0]         tst_addr_o,
  output logic [W-1:0]             tst_wdata_o,
  input  wire logic [NBANK*W-1:0]  tst_rdata_i,
  // ---- failure capture
  output logic                     f_valid_o,
  output logic [BW-1:0]            f_bank_o,
  output logic [ROW_W-1:0]         f_row_o,
  output logic [2:0]               f_elem_o,
  output logic                     f_op_o,
  output logic                     f_pol_o,
  output logic [3:0]               f_pass_o,
  output logic [2:0]               f_pat_o,
  output logic [W-1:0]             f_exp_o,
  output logic [W-1:0]             f_obs_o,
  output logic [W-1:0]             f_mask_o,
  output logic                     clr_fail_o,
  input  wire logic                fail_any_i,
  // ---- status
  output logic                     busy_o,
  output logic                     done_o,
  output logic [2:0]               result_o,
  output logic [3:0]               state_o,
  output logic [BW-1:0]            cur_bank_o,
  output logic [3:0]               cur_pass_o,
  output logic [2:0]               cur_elem_o,
  output logic [ROW_W-1:0]         cur_addr_o,
  output logic [31:0]              cycles_o,
  output logic [NBANK-1:0]         tested_o,
  output logic [`MB_NERR-1:0]      evt_o
);
  localparam logic [3:0] S_IDLE = 4'd0, S_CHECK = 4'd1, S_ACQ = 4'd2, S_BSEL = 4'd3, S_PINIT = 4'd4,
                         S_RUN = 4'd5, S_DRAIN = 4'd6, S_BEND = 4'd7, S_REL = 4'd8, S_FIN = 4'd9;

  // ------------------------------------------------------------ latched configuration
  logic [3:0]       alg_q, k_q;
  logic [2:0]       pat_q;
  logic             sweep_q, stop_q, reinit_q, startclr_q, selbad_q;
  logic [1:0]       col_q;
  logic [NBANK-1:0] mask_q, todo_q, tested_q;
  logic [31:0]      lo_q, hi_q;
  logic [31:0]      wdl_q;

  // ------------------------------------------------------------ run state
  logic [3:0]       st_q;
  logic [BW-1:0]    bank_q;
  logic             bankv_q;
  logic [3:0]       pass_q, npass_q;
  logic [2:0]       elem_q;
  logic             op_q;
  logic             abort_q, stop_req_q, wd_q, perm_lost_q, ownf_q, refused_q, internal_q, dirty_q, done_q;
  logic [7:0]       drain_q;
  logic [2:0]       res_q;
  logic [31:0]      cyc_q;
  logic [`MB_NERR-1:0] evt_q;

  // ------------------------------------------------------------ element table
  function automatic logic [5:0] elem_info(input logic [3:0] alg, input logic [2:0] e);
    // {down, two_ops, op0_is_read, op0_pol, op1_is_read, op1_pol};  op1 (when present) is a write
    if (alg == `MB_ALG_MATS_P) begin
      case (e)
        3'd0:    elem_info = 6'b000000;   // B(w0)
        3'd1:    elem_info = 6'b011001;   // U(r0,w1)
        default: elem_info = 6'b111100;   // D(r1,w0)
      endcase
    end else begin
      case (e)
        3'd0:    elem_info = 6'b000000;   // B(w0)
        3'd1:    elem_info = 6'b011001;   // U(r0,w1)
        3'd2:    elem_info = 6'b011100;   // U(r1,w0)
        3'd3:    elem_info = 6'b111001;   // D(r0,w1)
        3'd4:    elem_info = 6'b111100;   // D(r1,w0)
        default: elem_info = 6'b001000;   // B(r0)
      endcase
    end
  endfunction

  function automatic logic [NBANK-1:0] sel_mask(input logic [2:0] s, input logic [7:0] b, input logic [NBANK-1:0] bm);
    logic [NBANK-1:0] one;
    one = NBANK'(1);
    case (s)
      `MB_SEL_BANK:   sel_mask = (b < 8'(NBANK)) ? (one << b[BW-1:0]) : '0;
      `MB_SEL_SEQ:    sel_mask = bm;
      `MB_SEL_ALL:    sel_mask = ACCESS_MASK;
      `MB_SEL_SHARED: sel_mask = SHARED_MASK;
      `MB_SEL_TENSOR: sel_mask = TENSOR_MASK;
      `MB_SEL_VECTOR: sel_mask = VECTOR_MASK;
      default:        sel_mask = '0;
    endcase
  endfunction

  localparam int NELEM_C = 6, NELEM_M = 3;
  wire [2:0] nelem = (alg_q == `MB_ALG_MATS_P) ? 3'(NELEM_M) : 3'(NELEM_C);
  wire       last_elem = (elem_q == nelem - 3'd1);
  wire [5:0] ei      = elem_info(alg_q, elem_q);
  wire [5:0] ei_next = elem_info(alg_q, elem_q + 3'd1);
  wire       e_two   = ei[4];
  wire       op_rd   = op_q ? ei[1] : ei[3];
  wire       op_pol  = op_q ? ei[0] : ei[2];

  // ------------------------------------------------------------ effective background of the current pass
  wire [2:0] eff_pat = sweep_q ? ((pass_q == 4'd0) ? `MB_PAT_ALL0 : `MB_PAT_STRIPE) : pat_q;
  wire [3:0] eff_k   = sweep_q ? (pass_q - 4'd1) : k_q;

  logic [W-1:0] colmask;
  always_comb begin
    for (int i = 0; i < W; i++) begin
      case (col_q)
        `MB_COL_DATA:  colmask[i] = (i < DATA_W);
        `MB_COL_CHECK: colmask[i] = (i >= DATA_W);
        default:       colmask[i] = 1'b1;
      endcase
    end
  end

  // ------------------------------------------------------------ halt / issue
  wire bad  = abort_q | wd_q | !permit_i | !own_ok_i | own_fault_i;
  wire halt = bad | stop_req_q;
  wire issue = (st_q == S_RUN) && !halt;

  // ------------------------------------------------------------ address sequencer
  logic [ROW_W-1:0] seq_addr;
  logic             seq_last, seq_down;
  wire              last_op   = !e_two || op_q;
  wire              adv_addr  = issue && last_op && !seq_last;
  wire              adv_elem  = issue && last_op &&  seq_last && !last_elem;
  wire              pass_end  = issue && last_op &&  seq_last &&  last_elem;
  wire              seq_load  = (st_q == S_PINIT) || adv_elem;
  wire [5:0]        ei0       = elem_info(alg_q, 3'd0);
  wire              seq_ldown = (st_q == S_PINIT) ? ei0[5] : ei_next[5];

  sf_mbist_addr_seq #(.AW(ROW_W)) u_seq (
    .clk(clk), .rst_n(rst_n), .load_i(seq_load), .down_i(seq_ldown), .lo_i(lo_q[ROW_W-1:0]), .hi_i(hi_q[ROW_W-1:0]),
    .step_i(adv_addr), .addr_o(seq_addr), .last_o(seq_last), .down_o(seq_down));

  // ------------------------------------------------------------ pattern generators (issue side / compare side)
  logic [W-1:0] wdata, exp_w;
  logic [ROW_W-1:0] cmp_row;
  logic             cmp_pol;
  sf_mbist_pattern #(.W(W), .AW(ROW_W)) u_pat_iss (
    .pattern_i(eff_pat), .stripe_k_i(eff_k), .row_i(seq_addr), .pol_i(op_pol), .data_o(wdata));
  sf_mbist_pattern #(.W(W), .AW(ROW_W)) u_pat_cmp (
    .pattern_i(eff_pat), .stripe_k_i(eff_k), .row_i(cmp_row), .pol_i(cmp_pol), .data_o(exp_w));

  assign tst_sel_o   = bankv_q ? (NBANK'(1) << bank_q) : '0;
  assign tst_ce_o    = issue;
  assign tst_we_o    = issue && !op_rd;
  assign tst_addr_o  = seq_addr;
  assign tst_wdata_o = wdata;

  // ------------------------------------------------------------ compare pipeline
  logic [LT-1:0]     c_v;
  logic [ROW_W-1:0]  c_row  [LT];
  logic [2:0]        c_elem [LT];
  logic              c_op   [LT];
  logic              c_pol  [LT];
  logic [3:0]        c_pass [LT];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) c_v <= '0;
    else begin
      c_v[0] <= issue && op_rd;
      for (int k = 1; k < LT; k++) c_v[k] <= c_v[k-1];
    end
  end
  always_ff @(posedge clk) begin
    c_row[0] <= seq_addr; c_elem[0] <= elem_q; c_op[0] <= op_q; c_pol[0] <= op_pol; c_pass[0] <= pass_q;
    for (int k = 1; k < LT; k++) begin
      c_row[k] <= c_row[k-1]; c_elem[k] <= c_elem[k-1]; c_op[k] <= c_op[k-1];
      c_pol[k] <= c_pol[k-1]; c_pass[k] <= c_pass[k-1];
    end
  end
  assign cmp_row = c_row[LT-1];
  assign cmp_pol = c_pol[LT-1];

  logic [W-1:0] obs_raw, obs_s;
  assign obs_raw = tst_rdata_i[bank_q*W +: W];
`ifndef SYNTHESIS
  // simulation only: an unknown observed value must never be read as a pass
  wire obs_x = ((^obs_raw) === 1'bx);
`else
  wire obs_x = 1'b0;
`endif
  assign obs_s = obs_x ? ~exp_w : obs_raw;

  wire [W-1:0] syn_c   = (exp_w ^ obs_s) & colmask;
  wire         fail_now = c_v[LT-1] && (syn_c != '0);

  assign f_valid_o = fail_now;
  assign f_bank_o  = bank_q;
  assign f_row_o   = c_row[LT-1];
  assign f_elem_o  = c_elem[LT-1];
  assign f_op_o    = c_op[LT-1];
  assign f_pol_o   = c_pol[LT-1];
  assign f_pass_o  = c_pass[LT-1];
  assign f_pat_o   = eff_pat;
  assign f_exp_o   = exp_w & colmask;
  assign f_obs_o   = obs_s & colmask;
  assign f_mask_o  = colmask;

  // ------------------------------------------------------------ start validation (combinational from latched config)
  wire r_noperm = !permit_i;
  wire r_cfg    = (alg_q > `MB_ALG_MATS_P) || (pat_q > `MB_PAT_STRIPE) || (col_q == 2'd3) ||
                  (col_q == `MB_COL_CHECK && DATA_W >= W) || (lo_q > hi_q) || (hi_q >= 32'(ROWS)) || selbad_q;
  wire r_empty  = (mask_q == '0) && !selbad_q;
  wire r_inacc  = ((mask_q & ~ACCESS_MASK) != '0);
  wire r_prot   = ((mask_q & protect_i) != '0) && !cpu_halted_i;
  wire r_pend   = results_pending_i && !startclr_q;
  wire refuse   = r_noperm | r_cfg | r_empty | r_inacc | r_prot | r_pend;

  // ------------------------------------------------------------ sequencing
  wire [NBANK-1:0] one_bank = NBANK'(1) << bank_q;
  wire [NBANK-1:0] others   = todo_q & ~one_bank;

  logic [BW-1:0] low_bank;
  always_comb begin
    low_bank = '0;
    for (int b = NBANK - 1; b >= 0; b--) if (todo_q[b]) low_bank = BW'(b);
  end

  wire busy_now = (st_q != S_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; alg_q <= '0; k_q <= '0; pat_q <= '0; sweep_q <= 1'b0; stop_q <= 1'b0; reinit_q <= 1'b1;
      startclr_q <= 1'b0; selbad_q <= 1'b0; col_q <= '0; mask_q <= '0; todo_q <= '0; tested_q <= '0;
      lo_q <= '0; hi_q <= '0; wdl_q <= '0; bank_q <= '0; bankv_q <= 1'b0; pass_q <= '0; npass_q <= 4'd1;
      elem_q <= '0; op_q <= 1'b0; abort_q <= 1'b0; stop_req_q <= 1'b0; wd_q <= 1'b0; perm_lost_q <= 1'b0;
      ownf_q <= 1'b0; refused_q <= 1'b0; internal_q <= 1'b0; dirty_q <= 1'b0; done_q <= 1'b0; drain_q <= '0;
      res_q <= `MB_RES_NONE; cyc_q <= '0; evt_q <= '0; clr_fail_o <= 1'b0;
    end else begin
      evt_q <= '0;
      clr_fail_o <= 1'b0;

      // ---- command handling common to every state
      // an abort that arrives once the engine is already RELEASING the memory has nothing left to abort: ignored, so it cannot
      // turn a completed run into ABORTED
      if (abort_i && busy_now && !abort_q && st_q != S_REL && st_q != S_FIN) begin abort_q <= 1'b1; evt_q[`MB_ERR_ABORTED] <= 1'b1; end
      if ((start_i || clear_i) && busy_now) evt_q[`MB_ERR_CMD_BUSY] <= 1'b1;

      // ---- run-time observations
      if (busy_now) begin
        cyc_q <= cyc_q + 1'b1;
        // permission loss is only an ERROR while the engine still needs the memory (not during release)
        if ((st_q == S_ACQ || st_q == S_BSEL || st_q == S_PINIT || st_q == S_RUN || st_q == S_DRAIN || st_q == S_BEND) &&
            !permit_i && !perm_lost_q) begin
          perm_lost_q <= 1'b1; evt_q[`MB_ERR_PERM_LOSS] <= 1'b1;
        end
        if (own_fault_i && !ownf_q) ownf_q <= 1'b1;
        if (wdl_q != 32'd0 && cyc_q >= wdl_q && !wd_q) begin wd_q <= 1'b1; evt_q[`MB_ERR_WDOG] <= 1'b1; end
        if (stop_q && fail_now) stop_req_q <= 1'b1;
      end
      if (tst_we_o) dirty_q <= 1'b1;        // the first test write marks the array dirty (needs re-initialisation)

      case (st_q)
        S_IDLE: begin
          if (start_i) begin
            alg_q <= cfg_algo_i; pat_q <= cfg_pattern_i; k_q <= cfg_stripe_k_i; sweep_q <= cfg_sweep_i;
            col_q <= cfg_colsel_i; stop_q <= cfg_stop_i; reinit_q <= cfg_reinit_i; lo_q <= cfg_row_lo_i;
            hi_q <= cfg_row_hi_i; wdl_q <= cfg_wdog_i; startclr_q <= start_clr_i;
            mask_q   <= sel_mask(cfg_sel_i, cfg_bank_i, cfg_bmask_i);
            selbad_q <= (cfg_sel_i > `MB_SEL_VECTOR) || (cfg_sel_i == `MB_SEL_BANK && cfg_bank_i >= 8'(NBANK));
            done_q <= 1'b0; res_q <= `MB_RES_NONE; refused_q <= 1'b0; abort_q <= 1'b0; stop_req_q <= 1'b0;
            wd_q <= 1'b0; perm_lost_q <= 1'b0; ownf_q <= 1'b0; internal_q <= 1'b0; dirty_q <= 1'b0;
            cyc_q <= '0; tested_q <= '0; bankv_q <= 1'b0;
            st_q <= S_CHECK;
          end else if (clear_i) begin
            done_q <= 1'b0; res_q <= `MB_RES_NONE; tested_q <= '0; clr_fail_o <= 1'b1;
          end
        end

        S_CHECK: begin
          if (refuse) begin
            refused_q <= 1'b1;
            evt_q[`MB_ERR_NO_PERMIT]      <= r_noperm;
            evt_q[`MB_ERR_BAD_CFG]        <= r_cfg;
            evt_q[`MB_ERR_EMPTY_SEL]      <= r_empty;
            evt_q[`MB_ERR_NOT_ACCESSIBLE] <= r_inacc;
            evt_q[`MB_ERR_PROTECTED]      <= r_prot;
            evt_q[`MB_ERR_RESULT_PENDING] <= r_pend;
            st_q <= S_FIN;
          end else begin
            todo_q <= mask_q; tested_q <= '0; pass_q <= '0; clr_fail_o <= 1'b1;
            npass_q <= sweep_q ? 4'(1 + STRIPE_KMAX) : 4'd1;
            st_q <= S_ACQ;
          end
        end

        S_ACQ: begin
          if (abort_q || wd_q || own_fault_i || !permit_i) st_q <= S_REL;
          else if (own_ok_i) st_q <= S_BSEL;
        end

        S_BSEL: begin
          if (bad) st_q <= S_REL;
          else begin
            bank_q <= low_bank; bankv_q <= 1'b1; pass_q <= '0; st_q <= S_PINIT;
          end
        end

        S_PINIT: begin
          if (bad) st_q <= S_REL;
          else begin elem_q <= '0; op_q <= 1'b0; st_q <= S_RUN; end
        end

        S_RUN: begin
          if (halt) begin drain_q <= 8'(LT - 1); st_q <= S_DRAIN; end
          else begin
            if (!last_op)        op_q <= 1'b1;
            else begin
              op_q <= 1'b0;
              if (adv_elem)      elem_q <= elem_q + 1'b1;
              if (pass_end)    begin drain_q <= 8'(LT - 1); st_q <= S_DRAIN; end
            end
          end
        end

        S_DRAIN: begin
          if (drain_q == 8'd0) st_q <= S_BEND;
          else drain_q <= drain_q - 1'b1;
        end

        S_BEND: begin
          if (bad) st_q <= S_REL;
          else if ((pass_q + 4'd1) < npass_q) begin
            if (stop_req_q) st_q <= S_REL;
            else begin pass_q <= pass_q + 1'b1; st_q <= S_PINIT; end
          end else begin
            tested_q[bank_q] <= 1'b1;
            todo_q[bank_q]   <= 1'b0;
            if (others != '0 && !stop_req_q) st_q <= S_BSEL;
            else                              st_q <= S_REL;
          end
        end

        S_REL: begin
          bankv_q <= 1'b0;
          if (own_idle_i) st_q <= S_FIN;
        end

        S_FIN: begin
          done_q <= 1'b1;
          if (refused_q)                                      res_q <= `MB_RES_REFUSED;
          else if (perm_lost_q || ownf_q || wd_q)             res_q <= `MB_RES_ERROR;
          else if (abort_q)                                   res_q <= `MB_RES_ABORTED;
          else if (fail_any_i)                                res_q <= `MB_RES_FAIL;
          else if (tested_q != mask_q) begin
            res_q <= `MB_RES_ERROR; evt_q[`MB_ERR_INTERNAL] <= 1'b1;     // never a false PASS
          end else                                            res_q <= `MB_RES_PASS;
          abort_q <= 1'b0;
          st_q <= S_IDLE;
        end

        default: st_q <= S_IDLE;
      endcase
    end
  end

  assign own_req_o   = (st_q == S_ACQ) || (st_q == S_BSEL) || (st_q == S_PINIT) || (st_q == S_RUN) ||
                       (st_q == S_DRAIN) || (st_q == S_BEND);
  assign dirty_o     = dirty_q;
  assign reinit_en_o = reinit_q;
  assign busy_o      = busy_now;
  assign done_o      = done_q;
  assign result_o    = res_q;
  assign state_o     = st_q;
  assign cur_bank_o  = bank_q;
  assign cur_pass_o  = pass_q;
  assign cur_elem_o  = elem_q;
  assign cur_addr_o  = seq_addr;
  assign cycles_o    = cyc_q;
  assign tested_o    = tested_q;
  assign evt_o       = evt_q;

  wire unused_ok = &{1'b0, seq_down};
endmodule

`default_nettype wire
