// =============================================================================
// SilicaFlux SRAMFabric :: sf_sdf_addr_xlate -- external byte address -> SRAM coordinates (purely combinational)
//
//   addr (AW, absolute byte address as seen on the SFB3 target port)
//     |-- window test   (addr & ~(2^WIN_LOG2-1)) == WIN_BASE        else ADDR error
//     v
//   off  = addr & (2^WIN_LOG2 - 1)                                  byte offset inside the window
//     |-- range test    ALLOW_LO <= off  and  off + DW/8 <= ALLOW_HI else ADDR error  (computed with one extra bit:
//     |                                                              the end of the beat can never wrap)
//     |-- alignment     off[WB-1:0] == 0  (WB = log2(DW/8))          else ALIGN error
//     v
//   word = off >> WB         fabric word index (DW-bit words)
//   line = off >> LB         controller line index (LINE_W-bit lines, LB = log2(LINE_W/8))
//   bank = line % NB         ┐ the controller's own map (CONTRACT.md sec. 1):
//   row  = line / NB         ┘ consecutive lines rotate through the banks
//   lane = off[LB-1:WB]      which DW-wide lane of the line the beat occupies (0 when DW == LINE_W)
//
// Error precedence (same as the controller's RANGE over ALIGN): ADDR over ALIGN.  The opcode check is made by the
// caller (it does not depend on the address).  Every output other than cause is don't-care when cause != NONE.
// ALLOW_HI must not exceed the controller capacity NB*DEPTH*LINE_W/8 (checked at elaboration by sf_sdf_port).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sdf_defs.svh"
`default_nettype none

module sf_sdf_addr_xlate #(
  parameter int            AW       = 32,
  parameter int            DW       = 128,
  parameter int            LINE_W   = 128,
  parameter int            NB       = 4,
  parameter int            DEPTH    = 1024,
  parameter logic [AW-1:0] WIN_BASE = 32'h2000_0000,
  parameter int            WIN_LOG2 = 20,
  parameter int            ALLOW_LO = 0,
  parameter int            ALLOW_HI = NB * DEPTH * (LINE_W / 8),
  // ---- derived (do not override)
  parameter int            WB       = $clog2(DW / 8),
  parameter int            LB       = $clog2(LINE_W / 8),
  parameter int            BW       = (NB > 1) ? $clog2(NB) : 1,
  parameter int            ROW_W    = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int            LANEW    = (DW < LINE_W) ? $clog2(LINE_W / DW) : 1
) (
  input  wire logic [AW-1:0]    addr,
  output logic                  win_hit,
  output logic [AW-1:0]         off,
  output logic [AW-1:0]         word_addr,     // off >> WB
  output logic [AW-1:0]         line_addr,     // off with the byte-in-line bits cleared (controller request address)
  output logic [BW-1:0]         bank,
  output logic [ROW_W-1:0]      row,
  output logic [LANEW-1:0]      lane,
  output logic                  misal,
  output logic [2:0]            cause          // SDF_CAUSE_NONE / ADDR / ALIGN
);
  localparam logic [AW-1:0] ONE   = {{(AW-1){1'b0}}, 1'b1};
  localparam logic [AW-1:0] WMASK = (WIN_LOG2 >= AW) ? {AW{1'b1}} : ((ONE << WIN_LOG2) - ONE);

  assign win_hit = ((addr & ~WMASK) == (WIN_BASE & ~WMASK));
  assign off     = addr & WMASK;

  localparam int SBYTES = DW / 8;
  wire [AW:0] off_e   = {1'b0, off};
  /* verilator lint_off UNSIGNED */
  wire [AW:0] off_end = off_e + (AW + 1)'(SBYTES);
  wire        in_rng  = (off_e >= (AW + 1)'(ALLOW_LO)) && (off_end <= (AW + 1)'(ALLOW_HI));

  /* verilator lint_on UNSIGNED */
  assign misal = (WB > 0) ? (off[WB-1:0] != '0) : 1'b0;

  assign word_addr = off >> WB;
  assign line_addr = {off[AW-1:LB], {LB{1'b0}}};

  wire [AW-LB-1:0] line = off[AW-1:LB];
  if (NB > 1) begin : g_nb
    assign bank = line[BW-1:0];
    assign row  = ROW_W'(line >> BW);
  end else begin : g_1b
    assign bank = 1'b0;
    assign row  = ROW_W'(line);
  end

  if (DW < LINE_W) begin : g_lane
    assign lane = off[LB-1:WB];
  end else begin : g_nolane
    assign lane = '0;
  end

  assign cause = (!win_hit || !in_rng) ? `SDF_CAUSE_ADDR :
                 misal                 ? `SDF_CAUSE_ALIGN : `SDF_CAUSE_NONE;
endmodule

`default_nettype wire
