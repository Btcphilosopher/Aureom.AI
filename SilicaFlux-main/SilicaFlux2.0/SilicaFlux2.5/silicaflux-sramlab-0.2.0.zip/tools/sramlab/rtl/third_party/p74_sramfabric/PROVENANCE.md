# p74_sramfabric - vendored RTL for the NoC-interface synthesis (SRAMLab `phys.noc_interface_synth`)

Source: SilicaFlux SRAMFabric (Project 74) package `silicaflux-sramfabric-p74.zip`, directory `silicaflux-sramfabric/`
(`rtl/` + `third_party/`).  Copied **byte-identical**; nothing was edited.  `SHA256SUMS` (this directory) lists every file
(`sha256sum -c SHA256SUMS` from this directory).

| path here | upstream path | note |
|---|---|---|
| `rtl/sf_sdf_*.sv`, `rtl/sf_sdf_defs.svh`, `rtl/sf_sram_datafabric.sv`, `rtl/sf_sram_fabric_top.sv` | `rtl/` | P74's own RTL: SFB3 target -> SRAM controller bridge (`sf_sram_datafabric`) and the shared-SRAM top on the DataFabric (`sf_sram_fabric_top`). The verification-only `sf_sdf_tgt_chk.sv` is NOT vendored (not synthesizable, not needed) |
| `third_party/memorycore/rtl/**` | `third_party/memorycore/rtl/**` | MemoryCore controller / bank / core / ECC / scratchpads / backends the fabric top instantiates. NOTE: its `sf_sram_controller` is a DIFFERENT module from P73's `sf_sram_controller` (same name); they are never compiled together (separate Yosys runs) |
| `third_party/noc_sfb3/rtl/*.sv` | `third_party/noc_sfb3/rtl/*.sv` | the SFB3 NoC (`silicaflux_noc` and parts) instantiated by `sf_sram_fabric_top` |
| `third_party/ras_secded/*`, `third_party/sramlib_mbist/*` | same | ECC leaf codec and MBIST sources the controller package pulls in |

Integrity: the 38 files under `third_party/` were compared with the package's own `third_party/SHA256SUMS` - all 38 digests
identical.  The 8 files of P74's own `rtl/` have no upstream checksum list; their digests are recorded here at vendoring time.

Use in SRAMLab: **synthesis only** (Yosys), to report the gate count of the NoC-facing interface of the SRAM subsystem.  No
simulation, no timing, no area in um^2 (unless a real Liberty is supplied), no claim about the real fabric's performance.
