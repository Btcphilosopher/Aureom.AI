// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_regs      (register page: control, configuration, diagnostic readback)
//
// 12-bit byte address, 32-bit registers, word aligned.  The bus is the TestCore group-page bus
// (sftc_regs: req / we / addr / wdata -> gnt / rdata / err), so this page can sit behind the DFTGrid / TestCore
// JTAG TC_REG bridge or a system register port.  Zero wait states: gnt = req; rdata / err are valid in the SAME
// cycle as req (combinational read mux), a write takes effect at the clock edge.  An access that is
// misaligned, unmapped, a write to a read-only register or a read of a write-only register returns err = 1 and
// changes nothing.  Full map with fields: docs/03_register_map.md (generated from this file's localparams).
//
// Preservation contract (docs/03 section 4): FIRST record, counters, masks and FIFO are held until CLEAR or reset;
// reading never consumes them; POP advances only the FIFO head.  ERR_FLAGS are sticky until a W1C write or CLEAR.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_mbist_defs.svh"
`default_nettype none

module sf_mbist_regs #(
  parameter int NBANK      = 4,
  parameter int ROWS       = 64,
  parameter int ROW_W      = 6,
  parameter int W          = 32,
  parameter int DATA_W     = 32,
  parameter int LT         = 1,
  parameter int FIFO_DEPTH = 4,
  parameter int SR         = 2,
  parameter int SC         = 2,
  parameter bit REPAIR_EN  = 1'b0,
  parameter bit REDUNDANCY_PRESENT = 1'b0,
  parameter logic [NBANK-1:0] ACCESS_MASK = {NBANK{1'b1}},
  parameter logic [NBANK-1:0] SHARED_MASK = {NBANK{1'b1}},
  parameter logic [NBANK-1:0] TENSOR_MASK = '0,
  parameter logic [NBANK-1:0] VECTOR_MASK = '0,
  parameter int BW         = (NBANK > 1) ? $clog2(NBANK) : 1,
  parameter int BITW       = (W > 1) ? $clog2(W) : 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---- register bus
  input  wire logic                   rb_req,
  input  wire logic                   rb_we,
  input  wire logic [11:0]            rb_addr,
  input  wire logic [31:0]            rb_wdata,
  output logic                        rb_gnt,
  output logic [31:0]                 rb_rdata,
  output logic                        rb_err,
  // ---- configuration (to the engine)
  output logic [3:0]                  cfg_algo_o,
  output logic [2:0]                  cfg_pattern_o,
  output logic [3:0]                  cfg_stripe_k_o,
  output logic                        cfg_sweep_o,
  output logic [1:0]                  cfg_colsel_o,
  output logic                        cfg_stop_o,
  output logic                        cfg_reinit_o,
  output logic [2:0]                  cfg_sel_o,
  output logic [7:0]                  cfg_bank_o,
  output logic [NBANK-1:0]            cfg_bmask_o,
  output logic [31:0]                 cfg_row_lo_o,
  output logic [31:0]                 cfg_row_hi_o,
  output logic [31:0]                 cfg_wdog_o,
  // ---- command pulses
  output logic                        p_start_o,
  output logic                        p_abort_o,
  output logic                        p_clear_o,
  output logic                        p_pop_o,
  output logic                        p_startclr_o,
  output logic                        p_clrfault_o,
  // ---- sticky error flags
  input  wire logic                   clr_i,            // effective CLEAR (register or pin): acknowledges the flags
  input  wire logic [`MB_NERR-1:0]    evt_i,
  output logic [`MB_NERR-1:0]         err_flags_o,
  // ---- status
  input  wire logic                   busy_i,
  input  wire logic                   done_i,
  input  wire logic [2:0]             result_i,
  input  wire logic                   pending_i,
  input  wire logic [3:0]             fsm_state_i,
  input  wire logic [3:0]             arb_state_i,
  input  wire logic                   own_ok_i,
  input  wire logic                   tst_active_i,
  input  wire logic                   quiesce_i,
  input  wire logic                   clk_req_i,
  input  wire logic [NBANK-1:0]       tested_i,
  input  wire logic [NBANK-1:0]       bank_fail_mask_i,
  input  wire logic [31:0]            fail_count_i,
  input  wire logic [15:0]            fifo_count_i,
  input  wire logic [15:0]            fifo_lost_i,
  input  wire logic [BW-1:0]          cur_bank_i,
  input  wire logic [3:0]             cur_pass_i,
  input  wire logic [2:0]             cur_elem_i,
  input  wire logic [ROW_W-1:0]       cur_addr_i,
  input  wire logic [31:0]            cycles_i,
  input  wire logic [15:0]            intr_cnt_i,
  input  wire logic [15:0]            ras_sent_i,
  input  wire logic [15:0]            ras_lost_i,
  input  wire logic [W-1:0]           col_fail_i,
  input  wire logic [NBANK*16-1:0]    bank_cnt_i,
  // ---- first-fail record
  input  wire logic                   first_valid_i,
  input  wire logic [BW-1:0]          first_bank_i,
  input  wire logic [ROW_W-1:0]       first_row_i,
  input  wire logic [BITW-1:0]        first_bit_i,
  input  wire logic                   first_bit_v_i,
  input  wire logic                   first_in_check_i,
  input  wire logic [2:0]             first_elem_i,
  input  wire logic                   first_op_i,
  input  wire logic                   first_pol_i,
  input  wire logic [3:0]             first_pass_i,
  input  wire logic [3:0]             first_cls_i,
  input  wire logic [ROW_W-1:0]       first_alias_i,
  input  wire logic [W-1:0]           first_exp_i,
  input  wire logic [W-1:0]           first_obs_i,
  // ---- FIFO head record
  input  wire logic                   head_valid_i,
  input  wire logic [BW-1:0]          head_bank_i,
  input  wire logic [ROW_W-1:0]       head_row_i,
  input  wire logic [BITW-1:0]        head_bit_i,
  input  wire logic                   head_bit_v_i,
  input  wire logic                   head_in_check_i,
  input  wire logic [2:0]             head_elem_i,
  input  wire logic                   head_op_i,
  input  wire logic                   head_pol_i,
  input  wire logic [3:0]             head_pass_i,
  input  wire logic [3:0]             head_cls_i,
  input  wire logic [ROW_W-1:0]       head_alias_i,
  input  wire logic [W-1:0]           head_exp_i,
  input  wire logic [W-1:0]           head_obs_i,
  // ---- repair analysis (all zero when REPAIR_EN = 0)
  input  wire logic [NBANK-1:0]       rep_touched_i,
  input  wire logic [NBANK-1:0]       rep_unrep_i,
  input  wire logic [NBANK-1:0]       rep_ok_i,
  input  wire logic [NBANK*SR-1:0]    rep_row_v_i,
  input  wire logic [NBANK*SR*ROW_W-1:0] rep_row_i,
  input  wire logic [NBANK*SC-1:0]    rep_col_v_i,
  input  wire logic [NBANK*SC*BITW-1:0]  rep_col_i
);
  if (W > 160)     begin : g_err_w     `MB_CFG_FATAL("sf_mbist_regs: STORE_W > 160 does not fit the 5-word data windows") end
  if (NBANK > 32)  begin : g_err_nb    `MB_CFG_FATAL("sf_mbist_regs: NBANK > 32 does not fit the per-bank windows")      end

  // ------------------------------------------------------------ address map (byte offsets)
  localparam logic [11:0] A_ID = 12'h000, A_REV = 12'h004, A_CAPS0 = 12'h008, A_CAPS1 = 12'h00C, A_CAPS2 = 12'h010,
                          A_ACCESS = 12'h014, A_SHARED = 12'h018, A_TENSOR = 12'h01C, A_VECTOR = 12'h020,
                          A_CTRL = 12'h030, A_CFG = 12'h034, A_SELECT = 12'h038, A_BMASK = 12'h03C,
                          A_ROWLO = 12'h040, A_ROWHI = 12'h044, A_WDOG = 12'h048,
                          A_STATUS = 12'h050, A_ERR = 12'h054, A_TESTED = 12'h058, A_BFAILED = 12'h05C,
                          A_FCOUNT = 12'h060, A_FIFOST = 12'h064, A_PROG = 12'h068, A_CURADDR = 12'h06C,
                          A_CYCLES = 12'h070, A_INTR = 12'h074, A_RAS = 12'h078, A_ARB = 12'h07C,
                          A_COLF = 12'h080,                       // 5 words 0x080..0x090
                          A_FF_ADDR = 12'h0A0, A_FF_BIT = 12'h0A4, A_FF_OP = 12'h0A8, A_FF_VALID = 12'h0AC,
                          A_FF_EXP = 12'h0B0, A_FF_OBS = 12'h0D0, // 5 words each
                          A_HD_ADDR = 12'h100, A_HD_BIT = 12'h104, A_HD_OP = 12'h108, A_HD_VALID = 12'h10C,
                          A_HD_EXP = 12'h110, A_HD_OBS = 12'h130,
                          A_BCNT = 12'h200,                       // + 4*bank
                          A_REP_OK = 12'h300, A_REP_UNREP = 12'h304, A_REP_TOUCHED = 12'h308, A_REP_PHYS = 12'h30C,
                          A_REP_ROW = 12'h340,                    // + 4*(bank*SR + i)
                          A_REP_COL = 12'h3C0;                    // + 4*(bank*SC + j)

  // ------------------------------------------------------------ configuration registers
  logic [3:0]       algo_q, k_q;
  logic [2:0]       pat_q, sel_q;
  logic             sweep_q, stop_q, reinit_q;
  logic [1:0]       col_q;
  logic [7:0]       bank_q;
  logic [NBANK-1:0] bmask_q;
  logic [31:0]      lo_q, hi_q;
  logic [31:0]      wdog_q;
  logic [`MB_NERR-1:0] err_q;

  assign cfg_algo_o = algo_q; assign cfg_pattern_o = pat_q; assign cfg_stripe_k_o = k_q; assign cfg_sweep_o = sweep_q;
  assign cfg_colsel_o = col_q; assign cfg_stop_o = stop_q; assign cfg_reinit_o = reinit_q; assign cfg_sel_o = sel_q;
  assign cfg_bank_o = bank_q; assign cfg_bmask_o = bmask_q; assign cfg_row_lo_o = lo_q; assign cfg_row_hi_o = hi_q;
  assign cfg_wdog_o = wdog_q; assign err_flags_o = err_q;

  // ------------------------------------------------------------ helpers
  function automatic logic [31:0] wsel(input logic [159:0] v, input int idx);
    wsel = v[idx*32 +: 32];
  endfunction
  wire [159:0] first_exp_p = 160'(first_exp_i), first_obs_p = 160'(first_obs_i);
  wire [159:0] head_exp_p  = 160'(head_exp_i),  head_obs_p  = 160'(head_obs_i);
  wire [159:0] colf_p      = 160'(col_fail_i);

  // ------------------------------------------------------------ address decode
  wire aligned = (rb_addr[1:0] == 2'b00);
  wire in_bcnt = (rb_addr >= A_BCNT)    && (rb_addr < A_BCNT    + 12'(4 * NBANK));
  wire in_rrow = (rb_addr >= A_REP_ROW) && (rb_addr < A_REP_ROW + 12'(4 * NBANK * SR));
  wire in_rcol = (rb_addr >= A_REP_COL) && (rb_addr < A_REP_COL + 12'(4 * NBANK * SC));
  wire [11:0] colf_i  = (rb_addr - A_COLF)   >> 2;
  wire [11:0] ffexp_i = (rb_addr - A_FF_EXP) >> 2;
  wire [11:0] ffobs_i = (rb_addr - A_FF_OBS) >> 2;
  wire [11:0] hdexp_i = (rb_addr - A_HD_EXP) >> 2;
  wire [11:0] hdobs_i = (rb_addr - A_HD_OBS) >> 2;
  wire [31:0] rrow_v32 = 32'(rep_row_v_i);
  wire [31:0] rcol_v32 = 32'(rep_col_v_i);
  wire [11:0] bcnt_i = (rb_addr - A_BCNT) >> 2;
  wire [11:0] rrow_i = (rb_addr - A_REP_ROW) >> 2;
  wire [11:0] rcol_i = (rb_addr - A_REP_COL) >> 2;

  logic [31:0] rd;
  logic        rd_ok, wr_ok;           // address is mapped / writable

  // STATUS: [0] busy [1] done [2] pass [3] fail [4] aborted [5] error [6] refused [7] unread results [10:8] result
  //         [15:12] engine state [19:16] arbiter state [20] own_ok [21] tst_active [22] quiesce [23] clk_req
  //         [24] fifo head valid [25] first record valid
  wire [31:0] status_r = {6'd0, first_valid_i, head_valid_i, clk_req_i, quiesce_i, tst_active_i, own_ok_i, arb_state_i,
                          fsm_state_i, 1'b0, result_i, pending_i, (result_i == `MB_RES_REFUSED), (result_i == `MB_RES_ERROR),
                          (result_i == `MB_RES_ABORTED), (fail_count_i != 32'd0), (done_i && (result_i == `MB_RES_PASS)), done_i, busy_i};

  always_comb begin
    rd = 32'd0; rd_ok = 1'b1; wr_ok = 1'b0;
    case (rb_addr)
      A_ID:      rd = 32'h4D42_5354;                                                  // "MBST"
      A_REV:     rd = {16'h0078, 16'h0001};                                           // project 78, release 1
      A_CAPS0:   rd = {8'(W), 8'(DATA_W), 8'(ROW_W), 8'(NBANK)};
      A_CAPS1:   rd = {14'd0, 1'(REDUNDANCY_PRESENT), 1'(REPAIR_EN), 4'(SC), 4'(SR), 4'(FIFO_DEPTH), 4'(LT)};
      A_CAPS2:   rd = 32'(ROWS);
      A_ACCESS:  rd = 32'(ACCESS_MASK);
      A_SHARED:  rd = 32'(SHARED_MASK);
      A_TENSOR:  rd = 32'(TENSOR_MASK);
      A_VECTOR:  rd = 32'(VECTOR_MASK);
      A_CTRL:    begin rd_ok = 1'b0; wr_ok = 1'b1; end                                // write-only pulses
      A_CFG:     begin rd = {16'd0, reinit_q, stop_q, col_q, sweep_q, k_q, pat_q, algo_q}; wr_ok = 1'b1; end
      A_SELECT:  begin rd = {16'd0, bank_q, 5'd0, sel_q}; wr_ok = 1'b1; end
      A_BMASK:   begin rd = 32'(bmask_q); wr_ok = 1'b1; end
      A_ROWLO:   begin rd = lo_q;          wr_ok = 1'b1; end
      A_ROWHI:   begin rd = hi_q;          wr_ok = 1'b1; end
      A_WDOG:    begin rd = wdog_q;       wr_ok = 1'b1; end
      A_STATUS:  rd = status_r;
      A_ERR:     begin rd = 32'(err_q);   wr_ok = 1'b1; end
      A_TESTED:  rd = 32'(tested_i);
      A_BFAILED: rd = 32'(bank_fail_mask_i);
      A_FCOUNT:  rd = fail_count_i;
      A_FIFOST:  rd = {head_valid_i, 7'd0, fifo_lost_i[7:0], 8'd0, fifo_count_i[7:0]};
      A_PROG:    rd = {17'd0, cur_elem_i, cur_pass_i, 8'(cur_bank_i)};
      A_CURADDR: rd = 32'(cur_addr_i);
      A_CYCLES:  rd = cycles_i;
      A_INTR:    rd = 32'(intr_cnt_i);
      A_RAS:     rd = {ras_lost_i, ras_sent_i};
      A_ARB:     rd = {24'd0, clk_req_i, own_ok_i, tst_active_i, quiesce_i, arb_state_i};
      A_COLF, A_COLF + 12'd4, A_COLF + 12'd8, A_COLF + 12'd12, A_COLF + 12'd16:
                 rd = wsel(colf_p, 32'(colf_i));
      A_FF_ADDR: rd = {8'(first_bank_i), 24'(first_row_i)};
      A_FF_BIT:  rd = {14'd0, first_in_check_i, first_bit_v_i, 16'(first_bit_i)};
      A_FF_OP:   rd = {16'(first_alias_i), first_cls_i, first_pass_i, 3'd0, first_pol_i, first_op_i, first_elem_i};
      A_FF_VALID: rd = {31'd0, first_valid_i};
      A_FF_EXP, A_FF_EXP + 12'd4, A_FF_EXP + 12'd8, A_FF_EXP + 12'd12, A_FF_EXP + 12'd16:
                 rd = wsel(first_exp_p, 32'(ffexp_i));
      A_FF_OBS, A_FF_OBS + 12'd4, A_FF_OBS + 12'd8, A_FF_OBS + 12'd12, A_FF_OBS + 12'd16:
                 rd = wsel(first_obs_p, 32'(ffobs_i));
      A_HD_ADDR: rd = {8'(head_bank_i), 24'(head_row_i)};
      A_HD_BIT:  rd = {14'd0, head_in_check_i, head_bit_v_i, 16'(head_bit_i)};
      A_HD_OP:   rd = {16'(head_alias_i), head_cls_i, head_pass_i, 3'd0, head_pol_i, head_op_i, head_elem_i};
      A_HD_VALID: rd = {31'd0, head_valid_i};
      A_HD_EXP, A_HD_EXP + 12'd4, A_HD_EXP + 12'd8, A_HD_EXP + 12'd12, A_HD_EXP + 12'd16:
                 rd = wsel(head_exp_p, 32'(hdexp_i));
      A_HD_OBS, A_HD_OBS + 12'd4, A_HD_OBS + 12'd8, A_HD_OBS + 12'd12, A_HD_OBS + 12'd16:
                 rd = wsel(head_obs_p, 32'(hdobs_i));
      A_REP_OK:      rd = 32'(rep_ok_i);
      A_REP_UNREP:   rd = 32'(rep_unrep_i);
      A_REP_TOUCHED: rd = 32'(rep_touched_i);
      A_REP_PHYS:    rd = {31'd0, REDUNDANCY_PRESENT};
      default: begin
        if (in_bcnt)      rd = 32'(bank_cnt_i[bcnt_i*16 +: 16]);
        else if (in_rrow) rd = {rrow_v32[rrow_i[4:0]], 7'd0, 24'(rep_row_i[rrow_i*ROW_W +: ROW_W])};
        else if (in_rcol) rd = {rcol_v32[rcol_i[4:0]], 15'd0, 16'(rep_col_i[rcol_i*BITW +: BITW])};
        else rd_ok = 1'b0;
      end
    endcase
    if (!aligned) begin rd = 32'd0; rd_ok = 1'b0; wr_ok = 1'b0; end
  end

  assign rb_gnt   = rb_req;
  assign rb_rdata = (rb_req && !rb_we && rd_ok) ? rd : 32'd0;
  assign rb_err   = rb_req && (rb_we ? !wr_ok : !rd_ok);

  // ------------------------------------------------------------ writes, pulses, sticky flags
  wire wr = rb_req && rb_we && wr_ok;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      algo_q <= `MB_ALG_MARCH_CM; pat_q <= `MB_PAT_ALL0; k_q <= '0; sweep_q <= 1'b0; col_q <= `MB_COL_ALL;
      stop_q <= 1'b0; reinit_q <= 1'b1; sel_q <= `MB_SEL_ALL; bank_q <= '0; bmask_q <= '1;
      lo_q <= '0; hi_q <= 32'(ROWS - 1); wdog_q <= '0; err_q <= '0;
      p_start_o <= 1'b0; p_abort_o <= 1'b0; p_clear_o <= 1'b0; p_pop_o <= 1'b0; p_startclr_o <= 1'b0;
      p_clrfault_o <= 1'b0;
    end else begin
      p_start_o <= 1'b0; p_abort_o <= 1'b0; p_clear_o <= 1'b0; p_pop_o <= 1'b0; p_startclr_o <= 1'b0;
      p_clrfault_o <= 1'b0;
      err_q <= err_q | evt_i;
      if (wr) begin
        case (rb_addr)
          A_CTRL: begin
            p_start_o    <= rb_wdata[0] | rb_wdata[4];
            p_startclr_o <= rb_wdata[4];
            p_abort_o    <= rb_wdata[1];
            p_clear_o    <= rb_wdata[2];
            p_pop_o      <= rb_wdata[3];
            p_clrfault_o <= rb_wdata[5];
          end
          A_CFG: begin
            algo_q <= rb_wdata[3:0]; pat_q <= rb_wdata[6:4]; k_q <= rb_wdata[10:7]; sweep_q <= rb_wdata[11];
            col_q <= rb_wdata[13:12]; stop_q <= rb_wdata[14]; reinit_q <= rb_wdata[15];
          end
          A_SELECT: begin sel_q <= rb_wdata[2:0]; bank_q <= rb_wdata[15:8]; end
          A_BMASK:  bmask_q <= rb_wdata[NBANK-1:0];
          A_ROWLO:  lo_q <= rb_wdata;
          A_ROWHI:  hi_q <= rb_wdata;
          A_WDOG:   wdog_q <= rb_wdata;
          A_ERR:    err_q <= (err_q | evt_i) & ~rb_wdata[`MB_NERR-1:0];       // W1C (a simultaneous new event wins)
          default: ;
        endcase
      end
      if (clr_i) err_q <= evt_i;                                              // CLEAR also acknowledges the flags
    end
  end

endmodule

`default_nettype wire
