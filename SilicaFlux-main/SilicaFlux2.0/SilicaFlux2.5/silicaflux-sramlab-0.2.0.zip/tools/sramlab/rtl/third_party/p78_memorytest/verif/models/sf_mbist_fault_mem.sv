// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_fault_mem        *** VERIFICATION ONLY -- never synthesised ***
// Behavioural synchronous single-port SRAM array (ROWS x W bits) with a programmable list of up to NF
// simultaneous, EXPLICITLY DEFINED faults.  Raw (stored-word) port semantics identical to sf_sram_core /
// sf_sram_bank's test port: one access per edge, read data valid exactly READ_LATENCY cycles after the
// accepting edge, array never reset (poison pattern at time 0 so a test that depends on initial content fails).
//
// Fault type codes are the SAME numbers as MemoryCore's `SF_FT_* so a campaign can be cross-checked:
//   1 SAF    cell (row, bit) is stuck at `val`: reads return val; a write cannot change it
//   2 TF     transition fault on cell (row, bit): val=1 -> the 0->1 transition fails (cell stays 0);
//                                                  val=0 -> the 1->0 transition fails (cell stays 1)
//   3 AF_NA  address `row` reaches NO cell: writes are lost, reads return all zeros
//   4 AF_ALI address `row` reaches only the cells of row2 (own row never accessed): reads/writes act on row2
//   5 AF_MUL address `row` reaches its own row AND row2: a write updates both, a read returns the wired-OR of
//            both rows (val=0) or the wired-AND (val=1)
//   6 CFIN   inversion coupling: a transition of aggressor cell (row, bit) in direction val (1=up, 0=down)
//            INVERTS victim cell (row2, bit2)
//   7 CFID   idempotent coupling: same trigger, forces victim (row2, bit2) to val2
//   8 CFST   state coupling: while aggressor cell (row, bit) holds val, a READ of the victim cell (row2, bit2)
//            returns val2 (stored value untouched)
// Application rules (these ARE the model; docs/04_fault_models.md repeats them):
//   * Write to row r: per target row t (AF mapping first): TF is evaluated against old vs. written value, then
//     SAF forces its bit, then the row is stored, then every coupling fault whose aggressor is a transitioning
//     cell of row t acts on its victim (victim in the SAME word overrides the just-written value).
//   * Read of row r: stored row (through the AF mapping), SAF forces its bit, then CFST view, then (AF_MUL) the
//     wired-OR / AND with the second row.
//   * Only ONE address-decoder fault per address; faults on different cells combine freely.
// NOT modelled (nothing is claimed about them): retention / data-retention faults, read-disturb, write
// recovery, stuck-open, bit-line / sense-amplifier faults, neighbourhood pattern-sensitive faults,
// multi-cell/bridging defects other than the above, resistive/timing (at-speed) faults, soft errors.
// =============================================================================
`default_nettype none

module sf_mbist_fault_mem #(
  parameter int ROWS         = 64,
  parameter int W            = 32,
  parameter int READ_LATENCY = 1,
  parameter int NF           = 4,
  parameter int AW           = (ROWS > 1) ? $clog2(ROWS) : 1,
  parameter int BITW         = (W > 1) ? $clog2(W) : 1
) (
  input  wire logic              clk,
  input  wire logic              zero_i,        // init engine model: every row := 0 at this edge (no fault effects)
  input  wire logic              en,
  input  wire logic              we,
  input  wire logic [AW-1:0]     addr,
  input  wire logic [W-1:0]      wdata,
  output logic      [W-1:0]      rdata,
  // fault list (static while a test runs)
  input  wire logic [NF-1:0]     f_en,
  input  wire logic [NF*4-1:0]   f_type,
  input  wire logic [NF*AW-1:0]  f_row,
  input  wire logic [NF*AW-1:0]  f_row2,
  input  wire logic [NF*BITW-1:0] f_bit,
  input  wire logic [NF*BITW-1:0] f_bit2,
  input  wire logic [NF-1:0]     f_val,
  input  wire logic [NF-1:0]     f_val2
);
  logic [W-1:0] mem [0:ROWS-1];
  logic [W-1:0] rd0;
  logic [W-1:0] dq [1:READ_LATENCY];     // dq[1..L-1] pipeline; dq[L] unused when L == 1

  initial begin
    for (int i = 0; i < ROWS; i++) mem[i] = W'({(W/32+1){32'hA5C3_0000 ^ (32'(i) * 32'h9E37_79B1)}});
    rd0 = '0;
  end

  // ---- field access helpers
  function automatic logic [3:0]      ft (input int k); ft  = f_type[k*4 +: 4];       endfunction
  function automatic logic [AW-1:0]   fr (input int k); fr  = f_row [k*AW +: AW];     endfunction
  function automatic logic [AW-1:0]   fr2(input int k); fr2 = f_row2[k*AW +: AW];     endfunction
  function automatic int              fb (input int k); fb  = int'(f_bit [k*BITW +: BITW]);  endfunction
  function automatic int              fb2(input int k); fb2 = int'(f_bit2[k*BITW +: BITW]);  endfunction

  // stored row seen through single-cell read faults (SAF), used for coupling-state evaluation too
  function automatic logic [W-1:0] saf_view(input logic [AW-1:0] r, input logic [W-1:0] v);
    logic [W-1:0] o;
    o = v;
    for (int k = 0; k < NF; k++)
      if (f_en[k] && ft(k) == 4'd1 && fr(k) == r && fb(k) < W) o[fb(k)] = f_val[k];
    saf_view = o;
  endfunction

  // value of one cell as a read would see it (stored value through the SAF view)
  function automatic logic cell_view(input logic [AW-1:0] r, input int b);
    logic [W-1:0] v;
    begin
      v = saf_view(r, mem[r]);
      cell_view = v[b];
    end
  endfunction

  function automatic logic [W-1:0] read_row(input logic [AW-1:0] r);
    logic [W-1:0] v, v2;
    logic [AW-1:0] tgt;
    logic na, mul, mul_and;
    logic [AW-1:0] tgt2;
    begin
      tgt = r; na = 1'b0; mul = 1'b0; mul_and = 1'b0; tgt2 = r;
      for (int k = 0; k < NF; k++) if (f_en[k] && fr(k) == r) begin
        if (ft(k) == 4'd3) na = 1'b1;
        if (ft(k) == 4'd4) tgt = fr2(k);
        if (ft(k) == 4'd5) begin mul = 1'b1; tgt2 = fr2(k); mul_and = f_val[k]; end
      end
      if (na) read_row = '0;
      else begin
        v = saf_view(tgt, mem[tgt]);
        for (int k = 0; k < NF; k++)
          if (f_en[k] && ft(k) == 4'd8 && fr2(k) == tgt && fb2(k) < W && fb(k) < W &&
              cell_view(fr(k), fb(k)) == f_val[k])
            v[fb2(k)] = f_val2[k];
        if (mul) begin
          v2 = saf_view(tgt2, mem[tgt2]);
          read_row = mul_and ? (v & v2) : (v | v2);
        end else read_row = v;
      end
    end
  endfunction

  /* verilator lint_off BLKSEQ */
  task automatic write_row(input logic [AW-1:0] t, input logic [W-1:0] wd);
    logic [W-1:0] oldv, newv, vv;
    begin
      oldv = mem[t]; newv = wd;
      for (int k = 0; k < NF; k++) if (f_en[k] && ft(k) == 4'd2 && fr(k) == t && fb(k) < W) begin
        if ( f_val[k] && !oldv[fb(k)] &&  newv[fb(k)]) newv[fb(k)] = 1'b0;   // 0->1 blocked
        if (!f_val[k] &&  oldv[fb(k)] && !newv[fb(k)]) newv[fb(k)] = 1'b1;   // 1->0 blocked
      end
      for (int k = 0; k < NF; k++) if (f_en[k] && ft(k) == 4'd1 && fr(k) == t && fb(k) < W) newv[fb(k)] = f_val[k];
      mem[t] = newv;
      for (int k = 0; k < NF; k++)
        if (f_en[k] && (ft(k) == 4'd6 || ft(k) == 4'd7) && fr(k) == t && fb(k) < W && fb2(k) < W &&
            oldv[fb(k)] != newv[fb(k)] && newv[fb(k)] == f_val[k]) begin
          vv = mem[fr2(k)];
          vv[fb2(k)] = (ft(k) == 4'd6) ? ~vv[fb2(k)] : f_val2[k];
          mem[fr2(k)] = vv;
        end
    end
  endtask

  always @(posedge clk) begin : p_access
    logic [AW-1:0] tgt, tgt2;
    logic na, mul;
    if (zero_i) begin
      for (int i = 0; i < ROWS; i++) mem[i] = '0;
    end else if (en) begin
      if (we) begin
        tgt = addr; tgt2 = addr; na = 1'b0; mul = 1'b0;
        for (int k = 0; k < NF; k++) if (f_en[k] && fr(k) == addr) begin
          if (ft(k) == 4'd3) na = 1'b1;
          if (ft(k) == 4'd4) tgt = fr2(k);
          if (ft(k) == 4'd5) begin mul = 1'b1; tgt2 = fr2(k); end
        end
        if (!na) begin
          write_row(tgt, wdata);
          if (mul) write_row(tgt2, wdata);
        end
      end else begin
        rd0 <= read_row(addr);
      end
    end
    for (int s = 1; s < READ_LATENCY; s++) dq[s] <= (s == 1) ? rd0 : dq[s-1];
  end
  /* verilator lint_on BLKSEQ */

  if (READ_LATENCY == 1) begin : g_l1
    assign rdata = rd0;
  end else begin : g_ln
    assign rdata = dq[READ_LATENCY-1];
  end
endmodule

`default_nettype wire
