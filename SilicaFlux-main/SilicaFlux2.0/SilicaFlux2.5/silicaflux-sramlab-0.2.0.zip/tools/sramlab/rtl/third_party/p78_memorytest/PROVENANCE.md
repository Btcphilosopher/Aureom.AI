# p78_memorytest -- SilicaFlux MemoryTest (Project 78), copied byte-identical (never edited here)

Source archive: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-memorytest-p78.zip`
(sha256 `f613de7d692e091a6598b0f0b7e4d70e56b525f4f36c52ba9bbbf03c3dd2b3c8`).  Paths below are the paths inside the archive
(`silicaflux-memorytest/...`).  `SHA256SUMS` lists every file; check with `cd rtl/third_party/p78_memorytest && sha256sum -c SHA256SUMS`.

| Files | Used by SRAMLab for |
|---|---|
| `rtl/sf_sram_mbist.sv` + `sf_mbist_{fsm,addr_seq,pattern,arbiter,failreg,ras_if,regs,repair}.sv`, `sf_mbist_defs.svh` | the MBIST controller that is measured (March C- / MATS+, sequential banks, exclusive-ownership arbiter, failure registers) |
| `verif/models/sf_mbist_fault_mem.sv`, `sf_mbist_sram_sys.sv` | verification-only fault-injection memory and the memory-group model with a live functional master (used to inject faults and to measure the test-mode stall) |
| `verif/tb/tb_mbist_memorycore.sv`, `tb_mbist_rbus.svh`, `tb_common.svh` | P78's own real-stack integration testbench (MemoryCore controller + MBIST); re-run here to examine the Verilator `-O0` caveat on this Verilator version |
| `docs/02_march_algorithm.md`, `04_fault_models.md`, `06_verification.md` | definitions of the March tests / fault population and the caveat (reference only) |
| `reports/coverage.{json,md}`, `reports/regression.md` | P78's committed coverage numbers (4x8 and 4x32, exhaustive): the comparison baseline of `sramlab/studies/mbist.py` |

Not copied: P78's own `sim/` scripts, mutation/code-coverage reports, system testbench `tb_sf_sram_mbist.sv`, unit testbench, and its vendored MemoryCore copy
(identical to `../memorycore_sram`, see there).
