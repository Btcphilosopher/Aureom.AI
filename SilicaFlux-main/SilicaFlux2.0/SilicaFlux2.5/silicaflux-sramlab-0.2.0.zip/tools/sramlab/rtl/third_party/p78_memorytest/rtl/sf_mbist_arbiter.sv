// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_arbiter  (test-mode arbiter / memory ownership)
//
// One arbiter per memory group (= one quiesce / idle / init domain, e.g. one sf_sram_controller).  It gives the
// MBIST engine EXCLUSIVE ownership of the group's arrays for a destructive test and returns the group to
// functional use only after the arrays are re-initialised.  Normal operation and a destructive MBIST sequence
// are therefore never active at the same time.
//
//   IDLE --own_req & permit--> QUIESCE --quiesce_ack--> DRAIN --idle for IDLE_CONSEC cycles--> OWN1
//     ^                           |                        |                                      |
//     |                  timeout -> FAULT        timeout -> FAULT                                 v
//     |                                                                                       OWNED (tst_active, own_ok)
//     |                                                                                           | !own_req | !permit
//   (reinit done)--REINIT_WAIT <--REINIT <--(dirty & reinit_en)-- REL0 <------------------------+
//                                           \--(not dirty / no re-init)--> IDLE
//   FAULT: port returned to functional, test ownership denied, sticky until clr_fault_i.
//
// Step by step (the order is the safety argument; the testbench monitors every line of it):
//   1. Stop new functional accesses : quiesce_o = 1 from QUIESCE on (the memory group refuses new requests).
//   2. Confirm the group stopped     : quiesce_ack_i (tie 1 for a memory whose quiesce is immediate, e.g.
//                                      sf_sram_controller; masters that must finish a handshake delay it).
//   3. Drain                         : idle_i (nothing in flight, every bank idle) for IDLE_CONSEC consecutive
//                                      cycles WHILE quiesce_ack_i holds.  Outstanding functional transactions
//                                      are DRAINED, never cancelled: their responses are still delivered.
//   4. Confirm ownership             : OWN1 hands the array to the test bus (tst_active_o = 1) with no test
//                                      operation yet; own_ok_o rises one cycle later (OWNED).  The engine may
//                                      issue test operations only while own_ok_o AND permit_i hold in that cycle.
//   5. Disable conflicting users     : quiesce_o stays 1 for the whole ownership; a functional request that is
//                                      nevertheless seen on func_req_i is blocked by the memory group and counted
//                                      (intrusion_cnt_o, one RAS event per episode).  func_req_i must be the
//                                      ACCEPTED-request strobe (or the valid of a master that has acknowledged the
//                                      quiesce): a master merely back-pressured by ready = 0 legitimately keeps valid high.
//   6. Release                       : own_req_i low (or permit lost): tst_active_o drops (REL0); if the engine
//                                      wrote the array (dirty_i) and reinit_en_i: init_start_o is pulsed and the
//                                      arbiter waits for the init engine (busy seen, then idle) before
//                                      quiesce_o drops.  Without re-init a dirty release raises evt_reinit_req_o:
//                                      the group returns to service holding the test background.
//   Timeouts: OWN_TIMEOUT (QUIESCE + DRAIN together) and INIT_TIMEOUT / INIT_GRACE (re-init) -> FAULT; the
//   port returns to functional use and the event flags say whether the array content is undefined.
//   Permission loss (permit_i low) in OWN1/OWNED forces the release path immediately; hold_q then blocks a new
//   acquisition until own_req_i has dropped (a glitching permit cannot restart a test behind the engine's back).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_mbist_arbiter #(
  parameter int OWN_TIMEOUT   = 4096,
  parameter int IDLE_CONSEC   = 2,
  parameter int INIT_TIMEOUT  = 512,
  parameter int INIT_GRACE    = 16,
  parameter int REINIT_ENGINE = 1
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // ---- from the MBIST engine / configuration
  input  wire logic        own_req_i,
  input  wire logic        permit_i,
  input  wire logic        reinit_en_i,
  input  wire logic        dirty_i,
  input  wire logic        clr_fault_i,
  // ---- memory group side
  output logic             quiesce_o,
  input  wire logic        quiesce_ack_i,
  input  wire logic        idle_i,
  output logic             init_start_o,
  input  wire logic        init_busy_i,
  input  wire logic        func_req_i,
  // ---- to the engine / test bus
  output logic             tst_active_o,
  output logic             own_ok_o,
  output logic             own_idle_o,
  output logic             own_fault_o,
  output logic             clk_req_o,
  // ---- events (1-cycle pulses) and counters
  output logic             evt_own_timeout_o,
  output logic             evt_reinit_timeout_o,
  output logic             evt_perm_loss_o,
  output logic             evt_intrusion_o,
  output logic             evt_reinit_req_o,
  output logic [15:0]      intrusion_cnt_o,
  output logic [3:0]       state_o
);
  localparam logic [3:0] A_IDLE = 4'd0, A_QUIESCE = 4'd1, A_DRAIN = 4'd2, A_OWN1 = 4'd3, A_OWNED = 4'd4,
                         A_REL0 = 4'd5, A_REINIT = 4'd6, A_REINIT_WAIT = 4'd7, A_FAULT = 4'd8;

  logic [3:0]  st;
  logic [31:0] timer;
  logic [15:0] idle_cnt;
  logic [31:0] to_q;
  logic        seen_q, hold_q, ep_q;

  wire in_own = (st == A_DRAIN) || (st == A_OWN1) || (st == A_OWNED) || (st == A_REL0) ||
                (st == A_REINIT) || (st == A_REINIT_WAIT);
  wire intr   = func_req_i && in_own;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= A_IDLE; timer <= '0; idle_cnt <= '0; to_q <= '0; seen_q <= 1'b0; hold_q <= 1'b0; ep_q <= 1'b0;
      evt_own_timeout_o <= 1'b0; evt_reinit_timeout_o <= 1'b0; evt_perm_loss_o <= 1'b0;
      evt_intrusion_o <= 1'b0; evt_reinit_req_o <= 1'b0; intrusion_cnt_o <= '0;
    end else begin
      evt_own_timeout_o <= 1'b0; evt_reinit_timeout_o <= 1'b0; evt_perm_loss_o <= 1'b0;
      evt_intrusion_o   <= 1'b0; evt_reinit_req_o     <= 1'b0;

      // ---- intrusion accounting (a request presented while the group is owned/quiesced; it is BLOCKED by the group)
      if (intr) begin
        if (intrusion_cnt_o != 16'hFFFF) intrusion_cnt_o <= intrusion_cnt_o + 1'b1;
        if (!ep_q) begin ep_q <= 1'b1; evt_intrusion_o <= 1'b1; end
      end
      if (st == A_IDLE) ep_q <= 1'b0;

      case (st)
        A_IDLE: begin
          if (!own_req_i) hold_q <= 1'b0;
          if (own_req_i && permit_i && !hold_q) begin
            st <= A_QUIESCE; timer <= '0; idle_cnt <= '0;
          end
        end
        A_QUIESCE: begin
          timer <= timer + 1'b1;
          if (!own_req_i)                         st <= A_IDLE;                       // acquisition withdrawn, nothing dirty
          else if (!permit_i) begin st <= A_IDLE; hold_q <= 1'b1; evt_perm_loss_o <= 1'b1; end
          else if (timer >= 32'(OWN_TIMEOUT)) begin st <= A_FAULT; evt_own_timeout_o <= 1'b1; end
          else if (quiesce_ack_i) begin st <= A_DRAIN; idle_cnt <= '0; end
        end
        A_DRAIN: begin
          timer <= timer + 1'b1;
          if (!own_req_i)                         st <= A_IDLE;
          else if (!permit_i) begin st <= A_IDLE; hold_q <= 1'b1; evt_perm_loss_o <= 1'b1; end
          else if (timer >= 32'(OWN_TIMEOUT)) begin st <= A_FAULT; evt_own_timeout_o <= 1'b1; end
          else begin
            if (idle_i && quiesce_ack_i) idle_cnt <= idle_cnt + 1'b1; else idle_cnt <= '0;
            if (idle_i && quiesce_ack_i && idle_cnt >= 16'(IDLE_CONSEC - 1)) st <= A_OWN1;
          end
        end
        A_OWN1: begin                                    // array handed to the test bus; no test op yet
          if (!permit_i) begin hold_q <= 1'b1; evt_perm_loss_o <= 1'b1; st <= A_REL0; end
          else if (!own_req_i)                          st <= A_REL0;
          else                                          st <= A_OWNED;
        end
        A_OWNED: begin
          if (!permit_i) begin hold_q <= 1'b1; evt_perm_loss_o <= 1'b1; st <= A_REL0; end
          else if (!own_req_i)                          st <= A_REL0;
        end
        A_REL0: begin                                    // tst_active low, quiesce still high
          if (dirty_i && reinit_en_i && (REINIT_ENGINE != 0)) st <= A_REINIT;
          else begin
            if (dirty_i) evt_reinit_req_o <= 1'b1;
            st <= A_IDLE;
          end
        end
        A_REINIT: begin                                  // init_start_o is a 1-cycle pulse (comb on this state)
          to_q <= '0; seen_q <= 1'b0; st <= A_REINIT_WAIT;
        end
        A_REINIT_WAIT: begin
          to_q <= to_q + 1'b1;
          if (init_busy_i) seen_q <= 1'b1;
          if (seen_q && !init_busy_i && idle_i) st <= A_IDLE;
          else if ((!seen_q && !init_busy_i && to_q >= 32'(INIT_GRACE)) || to_q >= 32'(INIT_TIMEOUT)) begin
            st <= A_FAULT; evt_reinit_timeout_o <= 1'b1; evt_reinit_req_o <= 1'b1;
          end
        end
        A_FAULT: begin
          if (clr_fault_i && !own_req_i) begin st <= A_IDLE; hold_q <= 1'b0; end
        end
        default: st <= A_IDLE;
      endcase
    end
  end

  assign quiesce_o    = (st == A_QUIESCE) || in_own;
  assign tst_active_o = (st == A_OWN1) || (st == A_OWNED);
  assign own_ok_o     = (st == A_OWNED);
  assign own_idle_o   = (st == A_IDLE) || (st == A_FAULT);
  assign own_fault_o  = (st == A_FAULT);
  assign init_start_o = (st == A_REINIT);
  assign clk_req_o    = quiesce_o;
  assign state_o      = st;
endmodule

`default_nettype wire
