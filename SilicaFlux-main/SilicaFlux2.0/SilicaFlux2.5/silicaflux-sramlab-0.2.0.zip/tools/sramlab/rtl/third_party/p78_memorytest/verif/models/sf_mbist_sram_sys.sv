// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_sram_sys        *** VERIFICATION ONLY -- never synthesised ***
// A memory group as the MBIST sees it: NBANK fault-model banks (sf_mbist_fault_mem) behind the SAME handshake
// contract as sf_sram_controller (rtl/sf_sram_controller.sv of MemoryCore):
//     quiesce_i  -> functional requests refused;   idle_o -> nothing in flight;
//     init_start_i / init_busy_o -> zero every row; tst_* -> raw array bus, tst_active_i gives the array to it.
// plus a FUNCTIONAL MASTER with a scoreboard so ownership can be verified against live traffic:
//   * random read / write traffic (LFSR) while traffic_en_i; accepted only when ready
//     (ready = !quiesce & !tst_active & !init_busy & !init_pending);
//   * a normal master stops presenting requests once the quiesce is acknowledged; rogue_i makes it present a
//     request EVERY cycle regardless (func_req_o), as a master that ignores the quiesce protocol would; the
//     group must block it and the arbiter must count it as an intrusion;
//   * a reference memory records every accepted write; every accepted read is compared at READ_LATENCY.
//     init completion resets the reference to "all zero" (what init does), so a read after a test that was NOT
//     re-initialised mismatches (func_chk_err_o) -- the scoreboard cannot be satisfied by a skipped re-init;
//   * knobs to make the group misbehave: ack_delay_i / ctl_no_ack_i (quiesce acknowledge), drain_extra_i /
//     ctl_no_idle_i (idle), ctl_no_init_i (init engine absent), init_extra_i (slow init).
// Observability for safety monitors: inflight_o (accepted, not yet completed), func_acc_o (accepted this cycle).
// =============================================================================
`default_nettype none

module sf_mbist_sram_sys #(
  parameter int NBANK        = 1,
  parameter int ROWS         = 16,
  parameter int W            = 8,
  parameter int READ_LATENCY = 1,
  parameter int NF           = 4,
  parameter int FUNC_LAT     = READ_LATENCY + 1,
  parameter int AW           = (ROWS > 1) ? $clog2(ROWS) : 1,
  parameter int BITW         = (W > 1) ? $clog2(W) : 1,
  parameter int BW           = (NBANK > 1) ? $clog2(NBANK) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---- memory-group contract (to / from the MBIST)
  input  wire logic                quiesce_i,
  output logic                     quiesce_ack_o,
  output logic                     idle_o,
  input  wire logic                init_start_i,
  output logic                     init_busy_o,
  output logic                     func_req_o,
  input  wire logic                tst_active_i,
  input  wire logic [NBANK-1:0]    tst_sel_i,
  input  wire logic                tst_ce_i,
  input  wire logic                tst_we_i,
  input  wire logic [AW-1:0]       tst_addr_i,
  input  wire logic [W-1:0]        tst_wdata_i,
  output logic [NBANK*W-1:0]       tst_rdata_o,
  // ---- testbench knobs
  input  wire logic                traffic_en_i,
  input  wire logic                rogue_i,
  input  wire logic                ctl_no_ack_i,
  input  wire logic                ctl_no_idle_i,
  input  wire logic                ctl_no_init_i,
  input  wire logic                init_on_reset_i,   // platform re-initialises the arrays when reset is released
  input  wire logic [7:0]          ack_delay_i,
  input  wire logic [7:0]          drain_extra_i,
  input  wire logic [7:0]          init_extra_i,
  // ---- observability
  output logic                     func_acc_o,
  output logic [7:0]               inflight_o,
  output logic [31:0]              func_acc_cnt_o,
  output logic [31:0]              func_chk_cnt_o,
  output logic [31:0]              func_chk_err_o,
  output logic [31:0]              func_blocked_cnt_o,
  output logic [31:0]              func_acc_in_test_o
);
  // ---------------------------------------------------------------- fault descriptors (set from the testbench by task)
  logic [NBANK*NF-1:0]         fd_en, fd_val, fd_val2;
  logic [NBANK*NF*4-1:0]       fd_type;
  logic [NBANK*NF*AW-1:0]      fd_row, fd_row2;
  logic [NBANK*NF*BITW-1:0]    fd_bit, fd_bit2;

  initial begin
    fd_en = '0; fd_val = '0; fd_val2 = '0; fd_type = '0; fd_row = '0; fd_row2 = '0; fd_bit = '0; fd_bit2 = '0;
  end

  task automatic clear_faults;
    fd_en = '0;
  endtask

  task automatic set_fault(input int b, input int s, input int t, input int row, input int bit_, input int row2,
                           input int bit2, input int v, input int v2);
    int k;
    begin
      k = b * NF + s;
      fd_en[k] = 1'b1; fd_val[k] = v[0]; fd_val2[k] = v2[0];
      fd_type [k*4 +: 4]        = 4'(t);
      fd_row  [k*AW +: AW]      = AW'(row);
      fd_row2 [k*AW +: AW]      = AW'(row2);
      fd_bit  [k*BITW +: BITW]  = BITW'(bit_);
      fd_bit2 [k*BITW +: BITW]  = BITW'(bit2);
    end
  endtask

  // ---------------------------------------------------------------- functional master
  logic [31:0] lfsr;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) lfsr <= 32'hACE1_2468;
    else        lfsr <= {lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};

  // A well-behaved master obeys the quiesce protocol: once the group has ACKNOWLEDGED the quiesce it presents nothing.
  // The rogue master ignores it.  (A master merely back-pressured by ready = 0 before the acknowledge is legal.)
  wire             m_valid = (traffic_en_i && lfsr[3] && !quiesce_ack_o) || rogue_i;
  wire [BW-1:0]    m_bank  = BW'((lfsr[15:8]) % NBANK);
  wire [AW-1:0]    m_row   = AW'((lfsr[23:16]) % ROWS);
  wire             m_we    = lfsr[5] | lfsr[6];
  wire [W-1:0]     m_wdata = W'({(W/32+1){lfsr ^ 32'h5A5A_1234}});
  assign func_req_o = m_valid;

  // ---------------------------------------------------------------- init engine model
  logic        init_pend_q, init_run_q;
  logic [15:0] init_cnt_q;
  logic        init_done_pulse;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin init_pend_q <= init_on_reset_i; init_run_q <= 1'b0; init_cnt_q <= '0; init_done_pulse <= 1'b0; end
    else begin
      init_done_pulse <= 1'b0;
      if (init_start_i && !ctl_no_init_i) init_pend_q <= 1'b1;
      if (init_pend_q && !init_run_q && !tst_active_i) begin
        init_run_q <= 1'b1; init_pend_q <= 1'b0; init_cnt_q <= 16'(ROWS) + 16'(init_extra_i);
      end else if (init_run_q) begin
        if (init_cnt_q <= 16'd1) begin init_run_q <= 1'b0; init_done_pulse <= 1'b1; end
        else init_cnt_q <= init_cnt_q - 1'b1;
      end
    end
  end
  assign init_busy_o = init_run_q;

  // ---------------------------------------------------------------- ready / accept
  wire ready  = !quiesce_i && !tst_active_i && !init_run_q && !init_pend_q && !init_done_pulse;
  wire accept = m_valid && ready;
  assign func_acc_o = accept;

  logic [FUNC_LAT-1:0] pipe_v;
  logic [BW-1:0]       pipe_bank [FUNC_LAT];
  logic [AW-1:0]       pipe_row  [FUNC_LAT];
  logic                pipe_we   [FUNC_LAT];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pipe_v <= '0;
    else begin
      pipe_v[0] <= accept;
      for (int s = 1; s < FUNC_LAT; s++) pipe_v[s] <= pipe_v[s-1];
    end
  end
  always_ff @(posedge clk) begin
    pipe_bank[0] <= m_bank; pipe_row[0] <= m_row; pipe_we[0] <= m_we;
    for (int s = 1; s < FUNC_LAT; s++) begin
      pipe_bank[s] <= pipe_bank[s-1]; pipe_row[s] <= pipe_row[s-1]; pipe_we[s] <= pipe_we[s-1];
    end
  end
  always_comb begin
    inflight_o = '0;
    for (int s = 0; s < FUNC_LAT; s++) inflight_o = inflight_o + 8'(pipe_v[s]);
  end

  // idle / quiesce acknowledge
  logic [7:0] ack_cnt, drain_cnt;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin ack_cnt <= '0; drain_cnt <= '0; end
    else begin
      if (!quiesce_i) ack_cnt <= '0; else if (ack_cnt != 8'hFF) ack_cnt <= ack_cnt + 1'b1;
      if (inflight_o != 8'd0 || !quiesce_i) drain_cnt <= '0; else if (drain_cnt != 8'hFF) drain_cnt <= drain_cnt + 1'b1;
    end
  end
  assign quiesce_ack_o = quiesce_i && !ctl_no_ack_i && (ack_cnt >= ack_delay_i);
  assign idle_o        = (inflight_o == 8'd0) && !init_pend_q && !init_run_q && !ctl_no_idle_i &&
                         (!quiesce_i || drain_cnt >= drain_extra_i);

  // ---------------------------------------------------------------- banks
  logic [W-1:0] bank_rdata [NBANK];
  generate
    for (genvar b = 0; b < NBANK; b++) begin : g_bank
      wire t_en  = tst_active_i && tst_sel_i[b] && tst_ce_i;
      wire f_en_ = !tst_active_i && accept && (m_bank == BW'(b));
      wire        en_   = t_en | f_en_;
      wire        we_   = tst_active_i ? tst_we_i : m_we;
      wire [AW-1:0] ad_ = tst_active_i ? tst_addr_i : m_row;
      wire [W-1:0]  wd_ = tst_active_i ? tst_wdata_i : m_wdata;
      sf_mbist_fault_mem #(.ROWS(ROWS), .W(W), .READ_LATENCY(READ_LATENCY), .NF(NF)) u_mem (
        .clk(clk), .zero_i(init_done_pulse), .en(en_), .we(we_), .addr(ad_), .wdata(wd_), .rdata(bank_rdata[b]),
        .f_en(fd_en[b*NF +: NF]), .f_type(fd_type[b*NF*4 +: NF*4]), .f_row(fd_row[b*NF*AW +: NF*AW]),
        .f_row2(fd_row2[b*NF*AW +: NF*AW]), .f_bit(fd_bit[b*NF*BITW +: NF*BITW]),
        .f_bit2(fd_bit2[b*NF*BITW +: NF*BITW]), .f_val(fd_val[b*NF +: NF]), .f_val2(fd_val2[b*NF +: NF]));
      assign tst_rdata_o[b*W +: W] = bank_rdata[b];
    end
  endgenerate

  // ---------------------------------------------------------------- scoreboard
  logic [W-1:0] refm [NBANK][ROWS];
  logic         refv [NBANK][ROWS];
  initial begin
    for (int b = 0; b < NBANK; b++) for (int r = 0; r < ROWS; r++) begin refm[b][r] = '0; refv[b][r] = 1'b0; end
  end

  // the init engine zeroes every array at completion (zero_i of each bank) and the reference follows
`ifdef SYS_DEBUG
  always @(posedge clk) begin
    if (init_done_pulse) $display("  [sys] t=%0t INIT DONE (arrays zeroed, reference reset) quiesce=%b tst_active=%b", $time, quiesce_i, tst_active_i);
    if (accept && m_we && m_bank == 0 && m_row == 0) $display("  [sys] t=%0t functional WRITE bank0 row0 = %h (init_done_pulse=%b)", $time, m_wdata, init_done_pulse);
    if (accept && !m_we && m_bank == 0 && m_row == 0) $display("  [sys] t=%0t functional READ  bank0 row0", $time);
  end
`endif
  always @(posedge clk) begin
    if (init_done_pulse) begin
      for (int b = 0; b < NBANK; b++) for (int r = 0; r < ROWS; r++) begin refm[b][r] = '0; refv[b][r] = 1'b1; end
    end
    if (accept && m_we) begin refm[m_bank][m_row] = m_wdata; refv[m_bank][m_row] = 1'b1; end
  end

  // read check at READ_LATENCY.  The expectation is captured at ACCEPT time: a read observes exactly the writes
  // accepted before it, so a write accepted in the very next cycle must not change what the read is compared with.
  logic [BW-1:0] rd_bank [READ_LATENCY];
  logic [W-1:0]  rd_exp  [READ_LATENCY];
  logic          rd_chk  [READ_LATENCY];
  logic [READ_LATENCY-1:0] rd_v;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rd_v <= '0;
    else begin
      rd_v[0] <= accept && !m_we;
      for (int s = 1; s < READ_LATENCY; s++) rd_v[s] <= rd_v[s-1];
    end
  end
  always_ff @(posedge clk) begin
    rd_bank[0] <= m_bank; rd_exp[0] <= refm[m_bank][m_row]; rd_chk[0] <= refv[m_bank][m_row];
    for (int s = 1; s < READ_LATENCY; s++) begin rd_bank[s] <= rd_bank[s-1]; rd_exp[s] <= rd_exp[s-1]; rd_chk[s] <= rd_chk[s-1]; end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      func_acc_cnt_o <= '0; func_chk_cnt_o <= '0; func_chk_err_o <= '0; func_blocked_cnt_o <= '0; func_acc_in_test_o <= '0;
    end else begin
      if (accept) func_acc_cnt_o <= func_acc_cnt_o + 1'b1;
      if (m_valid && !ready) func_blocked_cnt_o <= func_blocked_cnt_o + 1'b1;
      if (accept && tst_active_i) func_acc_in_test_o <= func_acc_in_test_o + 1'b1;   // impossible by construction
      if (rd_v[READ_LATENCY-1]) begin
        if (rd_chk[READ_LATENCY-1]) begin
          func_chk_cnt_o <= func_chk_cnt_o + 1'b1;
          if (bank_rdata[rd_bank[READ_LATENCY-1]] !== rd_exp[READ_LATENCY-1]) begin
            func_chk_err_o <= func_chk_err_o + 1'b1;
`ifdef SYS_DEBUG
            $display("  [sys] SCOREBOARD MISMATCH t=%0t bank=%0d got=%h exp=%h tst_active=%b quiesce=%b init_run=%b",
                     $time, rd_bank[READ_LATENCY-1], bank_rdata[rd_bank[READ_LATENCY-1]], rd_exp[READ_LATENCY-1],
                     tst_active_i, quiesce_i, init_run_q);
`endif
          end
        end
      end
    end
  end
endmodule

`default_nettype wire
