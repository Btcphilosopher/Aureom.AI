// =============================================================================
// SilicaFlux SRAMController (Project 73) :: sf_sram_subsystem
// sf_sram_controller + NUM_BANKS x sf_sramc_bank (sf_sram_core, Project 71).
// This is the integrated, simulation- and synthesis-ready SilicaFlux banked
// SRAM subsystem: masters on one side, storage inside.
//
// BANK_LATS: 4 bits per bank (bank b = bits [4b +: 4]), the READ_LATENCY of that
// bank's sf_sram_core (0 is treated as 1).  Banks may have DIFFERENT latencies --
// the controller tracks completions per bank, so a slow bank never delays or
// misroutes a fast one.
// BANK_OUT = 0 : tracker depth chosen automatically = max bank latency + 1
//   (full bank rate without same-cycle tracker credit).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sramc_defs.svh"
`default_nettype none

module sf_sram_subsystem #(
  parameter int          NUM_MASTERS = 4,
  parameter int          NUM_BANKS   = 4,
  parameter int          DATA_WIDTH  = 32,
  parameter int          BANK_DEPTH  = 1024,
  parameter int          ADDR_WIDTH  = 32,
  parameter int          ID_WIDTH    = 4,
  parameter int          MAX_OUT     = 1,
  parameter int          BANK_OUT    = 0,
  parameter int          INTERLEAVE  = `SFC_ILV_LOW,
  parameter int          ID_CHECK    = 1,
  parameter int          SRC_CHECK   = 1,
  parameter int          MASK_MODE   = `SFC_MASK_ANY,
  parameter int          PRIO_EN     = 0,
  parameter logic [15:0] HP_MASK     = 16'h0001,
  parameter int          HP_LIMIT    = 4,
  parameter int          PERF_EN     = 1,
  parameter int          CNT_W       = 32,
  parameter int          INIT_MODE   = 0,
  parameter logic [63:0] BANK_LATS   = 64'h1111_1111_1111_1111,
  parameter int          UNIFORM_LAT = -1,   // -1: automatic (1 when every bank has the same latency), 0: force the bank-lock rule, 1: force uniform
  localparam int NBYTE = DATA_WIDTH / 8,
  localparam int MW    = (NUM_MASTERS > 1) ? $clog2(NUM_MASTERS) : 1,
  localparam int SRCW  = MW,
  localparam int RAW   = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  localparam int NPERF = 16 + 16 * NUM_MASTERS + 8 * NUM_BANKS,
  localparam int PSW   = $clog2(NPERF)
) (
  input  wire logic                              clk,
  input  wire logic                              rst_n,
  input  wire logic [NUM_MASTERS-1:0]            m_req_valid,
  output logic      [NUM_MASTERS-1:0]            m_req_ready,
  input  wire logic [NUM_MASTERS-1:0]            m_req_we,
  input  wire logic [NUM_MASTERS*ADDR_WIDTH-1:0] m_req_addr,
  input  wire logic [NUM_MASTERS*DATA_WIDTH-1:0] m_req_wdata,
  input  wire logic [NUM_MASTERS*NBYTE-1:0]      m_req_wstrb,
  input  wire logic [NUM_MASTERS*ID_WIDTH-1:0]   m_req_id,
  input  wire logic [NUM_MASTERS*SRCW-1:0]       m_req_src,
  input  wire logic [NUM_MASTERS-1:0]            m_req_err,
  output logic      [NUM_MASTERS-1:0]            m_rsp_valid,
  input  wire logic [NUM_MASTERS-1:0]            m_rsp_ready,
  output logic      [NUM_MASTERS*DATA_WIDTH-1:0] m_rsp_rdata,
  output logic      [NUM_MASTERS*ID_WIDTH-1:0]   m_rsp_id,
  output logic      [NUM_MASTERS*SRCW-1:0]       m_rsp_src,
  output logic      [NUM_MASTERS-1:0]            m_rsp_we,
  output logic      [NUM_MASTERS-1:0]            m_rsp_err,
  output logic      [NUM_MASTERS*4-1:0]          m_rsp_status,
  input  wire logic [NUM_MASTERS-1:0]            src_en,
  input  wire logic                              flush,
  output logic                                   idle,
  output logic                                   sts_rsp_overflow,
  output logic                                   sts_bank_proto,
  input  wire logic                              perf_clr,
  input  wire logic [PSW-1:0]                    perf_sel,
  output logic      [CNT_W-1:0]                  perf_val
);
  if (NUM_BANKS > 16) begin : g_err_num_banks_gt_16_for_bank_lats
    `SFC_CFG_FATAL("sf_sram_subsystem: BANK_LATS covers at most 16 banks")
  end

  // maximum bank latency, unrolled (Icarus 12 does not evaluate constant functions that call functions)
  localparam int L00 = (NUM_BANKS >  0) ? 32'(BANK_LATS[ 3: 0]) : 1;
  localparam int L01 = (NUM_BANKS >  1) ? 32'(BANK_LATS[ 7: 4]) : 1;
  localparam int L02 = (NUM_BANKS >  2) ? 32'(BANK_LATS[11: 8]) : 1;
  localparam int L03 = (NUM_BANKS >  3) ? 32'(BANK_LATS[15:12]) : 1;
  localparam int L04 = (NUM_BANKS >  4) ? 32'(BANK_LATS[19:16]) : 1;
  localparam int L05 = (NUM_BANKS >  5) ? 32'(BANK_LATS[23:20]) : 1;
  localparam int L06 = (NUM_BANKS >  6) ? 32'(BANK_LATS[27:24]) : 1;
  localparam int L07 = (NUM_BANKS >  7) ? 32'(BANK_LATS[31:28]) : 1;
  localparam int L08 = (NUM_BANKS >  8) ? 32'(BANK_LATS[35:32]) : 1;
  localparam int L09 = (NUM_BANKS >  9) ? 32'(BANK_LATS[39:36]) : 1;
  localparam int L10 = (NUM_BANKS > 10) ? 32'(BANK_LATS[43:40]) : 1;
  localparam int L11 = (NUM_BANKS > 11) ? 32'(BANK_LATS[47:44]) : 1;
  localparam int L12 = (NUM_BANKS > 12) ? 32'(BANK_LATS[51:48]) : 1;
  localparam int L13 = (NUM_BANKS > 13) ? 32'(BANK_LATS[55:52]) : 1;
  localparam int L14 = (NUM_BANKS > 14) ? 32'(BANK_LATS[59:56]) : 1;
  localparam int L15 = (NUM_BANKS > 15) ? 32'(BANK_LATS[63:60]) : 1;
  localparam int M01 = (L01 > L00) ? L01 : L00;
  localparam int M02 = (L02 > M01) ? L02 : M01;
  localparam int M03 = (L03 > M02) ? L03 : M02;
  localparam int M04 = (L04 > M03) ? L04 : M03;
  localparam int M05 = (L05 > M04) ? L05 : M04;
  localparam int M06 = (L06 > M05) ? L06 : M05;
  localparam int M07 = (L07 > M06) ? L07 : M06;
  localparam int M08 = (L08 > M07) ? L08 : M07;
  localparam int M09 = (L09 > M08) ? L09 : M08;
  localparam int M10 = (L10 > M09) ? L10 : M09;
  localparam int M11 = (L11 > M10) ? L11 : M10;
  localparam int M12 = (L12 > M11) ? L12 : M11;
  localparam int M13 = (L13 > M12) ? L13 : M12;
  localparam int M14 = (L14 > M13) ? L14 : M13;
  localparam int MAX_LAT = (L15 > M14) ? L15 : M14;
  localparam int BANK_OUT_EFF = (BANK_OUT == 0) ? (MAX_LAT + 1) : BANK_OUT;
  // minimum latency over the banks that EXIST (the L<k> of non-existent banks are filler 1s and must not take part)
  localparam int MIN_LAT_00 = L00;
  localparam int MIN_LAT_01 = (1 < NUM_BANKS && L01 < MIN_LAT_00) ? L01 : MIN_LAT_00;
  localparam int MIN_LAT_02 = (2 < NUM_BANKS && L02 < MIN_LAT_01) ? L02 : MIN_LAT_01;
  localparam int MIN_LAT_03 = (3 < NUM_BANKS && L03 < MIN_LAT_02) ? L03 : MIN_LAT_02;
  localparam int MIN_LAT_04 = (4 < NUM_BANKS && L04 < MIN_LAT_03) ? L04 : MIN_LAT_03;
  localparam int MIN_LAT_05 = (5 < NUM_BANKS && L05 < MIN_LAT_04) ? L05 : MIN_LAT_04;
  localparam int MIN_LAT_06 = (6 < NUM_BANKS && L06 < MIN_LAT_05) ? L06 : MIN_LAT_05;
  localparam int MIN_LAT_07 = (7 < NUM_BANKS && L07 < MIN_LAT_06) ? L07 : MIN_LAT_06;
  localparam int MIN_LAT_08 = (8 < NUM_BANKS && L08 < MIN_LAT_07) ? L08 : MIN_LAT_07;
  localparam int MIN_LAT_09 = (9 < NUM_BANKS && L09 < MIN_LAT_08) ? L09 : MIN_LAT_08;
  localparam int MIN_LAT_10 = (10 < NUM_BANKS && L10 < MIN_LAT_09) ? L10 : MIN_LAT_09;
  localparam int MIN_LAT_11 = (11 < NUM_BANKS && L11 < MIN_LAT_10) ? L11 : MIN_LAT_10;
  localparam int MIN_LAT_12 = (12 < NUM_BANKS && L12 < MIN_LAT_11) ? L12 : MIN_LAT_11;
  localparam int MIN_LAT_13 = (13 < NUM_BANKS && L13 < MIN_LAT_12) ? L13 : MIN_LAT_12;
  localparam int MIN_LAT_14 = (14 < NUM_BANKS && L14 < MIN_LAT_13) ? L14 : MIN_LAT_13;
  localparam int MIN_LAT_15 = (15 < NUM_BANKS && L15 < MIN_LAT_14) ? L15 : MIN_LAT_14;
  localparam int MIN_LAT    = MIN_LAT_15;
  localparam int UNIFORM_EFF = (UNIFORM_LAT < 0) ? ((MIN_LAT == MAX_LAT) ? 1 : 0) : UNIFORM_LAT;

  logic [NUM_BANKS-1:0]            bk_req_valid, bk_req_ready, bk_req_we, bk_rsp_valid, bk_rsp_err;
  logic [NUM_BANKS*RAW-1:0]        bk_req_addr;
  logic [NUM_BANKS*DATA_WIDTH-1:0] bk_req_wdata, bk_rsp_rdata;
  logic [NUM_BANKS*NBYTE-1:0]      bk_req_wstrb;

  sf_sram_controller #(
    .NUM_MASTERS(NUM_MASTERS), .NUM_BANKS(NUM_BANKS), .DATA_WIDTH(DATA_WIDTH), .BANK_DEPTH(BANK_DEPTH),
    .ADDR_WIDTH(ADDR_WIDTH), .ID_WIDTH(ID_WIDTH), .MAX_OUT(MAX_OUT), .BANK_OUT(BANK_OUT_EFF), .UNIFORM_LAT(UNIFORM_EFF),
    .INTERLEAVE(INTERLEAVE), .ID_CHECK(ID_CHECK), .SRC_CHECK(SRC_CHECK), .MASK_MODE(MASK_MODE),
    .PRIO_EN(PRIO_EN), .HP_MASK(HP_MASK), .HP_LIMIT(HP_LIMIT), .PERF_EN(PERF_EN), .CNT_W(CNT_W)
  ) u_ctl (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_req_id(m_req_id), .m_req_src(m_req_src),
    .m_req_err(m_req_err),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id),
    .m_rsp_src(m_rsp_src), .m_rsp_we(m_rsp_we), .m_rsp_err(m_rsp_err), .m_rsp_status(m_rsp_status),
    .src_en(src_en), .flush(flush), .idle(idle),
    .sts_rsp_overflow(sts_rsp_overflow), .sts_bank_proto(sts_bank_proto),
    .bk_req_valid(bk_req_valid), .bk_req_ready(bk_req_ready), .bk_req_we(bk_req_we),
    .bk_req_addr(bk_req_addr), .bk_req_wdata(bk_req_wdata), .bk_req_wstrb(bk_req_wstrb),
    .bk_rsp_valid(bk_rsp_valid), .bk_rsp_rdata(bk_rsp_rdata), .bk_rsp_err(bk_rsp_err),
    .perf_clr(perf_clr), .perf_sel(perf_sel), .perf_val(perf_val)
  );

  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_bank
    sf_sramc_bank #(
      .DATA_WIDTH(DATA_WIDTH), .DEPTH_WORDS(BANK_DEPTH),
      .LAT((BANK_LATS[4*b +: 4] == 4'd0) ? 1 : 32'(BANK_LATS[4*b +: 4])), .INIT_MODE(INIT_MODE)
    ) u_bank (
      .clk(clk), .rst_n(rst_n),
      .req_valid(bk_req_valid[b]), .req_ready(bk_req_ready[b]), .req_we(bk_req_we[b]),
      .req_addr(bk_req_addr[b*RAW +: RAW]), .req_wdata(bk_req_wdata[b*DATA_WIDTH +: DATA_WIDTH]),
      .req_wstrb(bk_req_wstrb[b*NBYTE +: NBYTE]),
      .rsp_valid(bk_rsp_valid[b]), .rsp_rdata(bk_rsp_rdata[b*DATA_WIDTH +: DATA_WIDTH]),
      .rsp_err(bk_rsp_err[b])
    );
  end
endmodule

`default_nettype wire
