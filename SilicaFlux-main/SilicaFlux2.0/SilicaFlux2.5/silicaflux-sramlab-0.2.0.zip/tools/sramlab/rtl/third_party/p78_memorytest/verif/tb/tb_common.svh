// Common testbench helpers (plain Verilog-2005-style so both Verilator 5.020 and Icarus 12 accept them).
// Usage: declare `integer errors, checks;` in the TB, then `CHECK(cond, "message")`.
`ifndef TB_COMMON_SVH
`define TB_COMMON_SVH

`define CHECK(cond, msg) \
  begin \
    checks = checks + 1; \
    if (!(cond)) begin \
      errors = errors + 1; \
      $display("  FAIL [%0t] %s", $time, msg); \
    end \
  end

`define CHECK_EQ(a, b, msg) \
  begin \
    checks = checks + 1; \
    if ((a) !== (b)) begin \
      errors = errors + 1; \
      $display("  FAIL [%0t] %s : got %0h expected %0h", $time, msg, (a), (b)); \
    end \
  end

`define SECTION(name) $display("-- %s", name)

`endif
