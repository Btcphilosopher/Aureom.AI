// =============================================================================
// SilicaFlux SRAMFabric (Project 74) :: sf_sdf_burst_seq -- burst command -> SFB3 single-beat transactions
//
// WHY THIS MODULE EXISTS.  SFB3 (the DataFabric protocol, third_party/noc_sfb3/PROTOCOL_SFB3.md) is single-beat: one DW-wide
// beat per transaction, byte enables, no burst fields; "a burst is a sequence of single-beat transactions" (SFB2 R10, spine
// PROTOCOL.md sec. 5).  This project does NOT add burst fields to SFB3 (that would be a second, incompatible protocol).  The
// burst subset below lives on the CLIENT side of the fabric: a DMA / tile host / ControlCore that wants to move N bytes from
// a byte address instantiates this sequencer, which turns one burst command into the legal SFB3 beats and groups their
// responses back into one completion.  Everything the SRAM bridge sees is ordinary SFB3.
//
// DOCUMENTED BURST SUBSET (docs/BURSTS.md).  NOT AXI4: there are no separate AW/W/B/AR/R channels, no WLAST, no narrow / wrap /
// fixed bursts, no cache / prot / lock attributes, no interleaving, no 4 KiB rule, one burst in flight.
//   * INCR only; byte-granular start address and byte length (1 .. MAX_BYTES); the first and last beat may be partial.
//   * every beat is a full DW word on the SFB3 port with `wstrb` marking the valid bytes (partial first / last word of a
//     write); a read beat returns the full word (SFB3 R10) and the sequencer reports the valid-byte mask beside the data.
//   * one burst = one transaction id (all beats): SFB3 O2/R5 give in-order responses, so grouping is a counter.
//   * one burst at a time: the next command is accepted after the previous completion was taken.
//   * READ, WRITE (acknowledged: completes when every beat is acknowledged) and WRITE_POSTED (completes when the last beat
//     was accepted by the fabric; failures surface as fabric events, SFB3 sec. 3).
//   * beat errors are per beat: every beat is issued, an erroring beat has no side effect (SFB3), the completion reports the
//     FIRST error class and beat index.  Writes to a range that is partly illegal therefore commit the legal beats
//     (no atomicity across beats: controller contract O4).
//   * a command that violates the subset (length, range, boundary, wrap, opcode) is REJECTED before any beat is issued.
//
// DATA STREAMS (bus-lane layout: byte b of a beat is at bits [8b+7:8b] and has address beat_base + b):
//   write data : wd_valid / wd_ready / wd_data per beat; lanes outside the burst are don't-care (masked by wstrb).  wd_ready is
//                the SFB3 request handshake of that beat; wd_lane_mask_o shows the lanes that will be written.
//   read data  : rd_valid / rd_ready / rd_data / rd_strb (valid lanes) / rd_last / rd_status per beat, buffered by an
//                RD_FIFO-deep FIFO.  Outstanding reads are credit limited so that the SFB3 response channel is always
//                drained (SFB3 M1) whatever the consumer does.
//   completion : done_valid / done_ready, {id, status, reason, beats, err beat, bytes}.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sf_sdf_defs.svh"
`default_nettype none

module sf_sdf_burst_seq #(
  parameter int            AW        = 32,
  parameter int            DW        = 128,
  parameter int            IDW       = 2,
  parameter int            MAX_BYTES = 4096,
  parameter int            RD_FIFO   = 8,          // read beats buffered (and max outstanding read beats)
  parameter int            MAX_OUT   = 8,          // max outstanding acknowledged-write beats
  parameter int            BOUNDARY  = 0,          // 0 = none, else power of two: a burst may not cross a multiple of it
  parameter logic [AW:0]   LIM_LO    = {(AW+1){1'b0}},
  parameter logic [AW:0]   LIM_HI    = {1'b1, {AW{1'b0}}},   // exclusive; 2^AW = whole address space
  parameter int            CNT_W     = 32,
  // ---- derived (do not override)
  parameter int            SB        = DW / 8,
  parameter int            WB        = $clog2(DW / 8),
  parameter int            LENW      = $clog2(MAX_BYTES + 1) + 1,
  parameter int            BEATW     = $clog2(MAX_BYTES / (DW / 8) + 2) + 1
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---------------------------------------------------------------- burst command
  input  wire logic                 cmd_valid,
  output logic                      cmd_ready,
  input  wire logic [2:0]           cmd_op,           // SDF_OP_READ / SDF_OP_WRITE / SDF_OP_WRITE_POSTED
  input  wire logic [AW-1:0]        cmd_addr,         // byte address, any alignment
  input  wire logic [LENW-1:0]      cmd_len,          // bytes, 1 .. MAX_BYTES
  input  wire logic [IDW-1:0]       cmd_id,
  input  wire logic [2:0]           cmd_qos,
  // ---------------------------------------------------------------- write data stream
  input  wire logic                 wd_valid,
  output logic                      wd_ready,
  input  wire logic [DW-1:0]        wd_data,
  output logic [SB-1:0]             wd_lane_mask_o,
  // ---------------------------------------------------------------- read data stream
  output logic                      rd_valid,
  input  wire logic                 rd_ready,
  output logic [DW-1:0]             rd_data,
  output logic [SB-1:0]             rd_strb,
  output logic                      rd_last,
  output logic [1:0]                rd_status,
  // ---------------------------------------------------------------- completion
  output logic                      done_valid,
  input  wire logic                 done_ready,
  output logic [IDW-1:0]            done_id,
  output logic [1:0]                done_status,      // SDF_BS_*
  output logic [2:0]                done_reason,      // SDF_RJ_* when REJECT
  output logic [BEATW-1:0]          done_beats,       // beats of the burst (0 when rejected)
  output logic [BEATW-1:0]          done_err_beat,    // index of the first erroring beat
  output logic [LENW-1:0]           done_bytes,       // payload bytes (the command length)
  // ---------------------------------------------------------------- SFB3 master port
  output logic                      m_req_valid,
  input  wire logic                 m_req_ready,
  output logic [2:0]                m_req_opcode,
  output logic [IDW-1:0]            m_req_id,
  output logic [2:0]                m_req_qos,
  output logic [AW-1:0]             m_req_addr,
  output logic [DW-1:0]             m_req_wdata,
  output logic [SB-1:0]             m_req_wstrb,
  input  wire logic                 m_rsp_valid,
  output logic                      m_rsp_ready,
  input  wire logic [IDW-1:0]       m_rsp_id,
  input  wire logic [2:0]           m_rsp_opcode,
  input  wire logic [1:0]           m_rsp_status,
  input  wire logic [DW-1:0]        m_rsp_rdata,
  // ---------------------------------------------------------------- statistics
  input  wire logic                 cnt_clr_i,
  output logic [CNT_W-1:0]          st_bursts_o,      // completed (accepted) bursts
  output logic [CNT_W-1:0]          st_rejected_o,
  output logic [CNT_W-1:0]          st_beats_o,       // SFB3 beats issued
  output logic [CNT_W-1:0]          st_bytes_o,       // payload bytes of completed bursts
  output logic [CNT_W-1:0]          st_wire_bytes_o,  // beats * DW/8 (bytes occupying the fabric)
  output logic [CNT_W-1:0]          st_errbeats_o,
  output logic [CNT_W-1:0]          st_busy_o,        // cycles with a burst active
  output logic [CNT_W-1:0]          st_req_stall_o,   // cycles m_req_valid && !m_req_ready
  output logic [CNT_W-1:0]          st_data_starve_o, // write: cycles a beat could issue but the data stream had none
  output logic [CNT_W-1:0]          st_credit_stall_o,// cycles issue was held by outstanding / read-FIFO credit
  output logic [CNT_W-1:0]          st_rd_stall_o,    // cycles read data waited for the consumer
  output logic [CNT_W-1:0]          st_proto_o,       // responses with unexpected id / opcode (must be 0)
  output logic                      busy_o
);
  if (DW != 32 && DW != 64 && DW != 128) begin : g_err_dw
    `SF_CFG_FATAL("sf_sdf_burst_seq: DW must be 32, 64 or 128")
  end
  if (BOUNDARY != 0 && (BOUNDARY & (BOUNDARY - 1)) != 0) begin : g_err_bnd
    `SF_CFG_FATAL("sf_sdf_burst_seq: BOUNDARY must be 0 or a power of two")
  end
  if (RD_FIFO < 1 || MAX_OUT < 1) begin : g_err_buf
    `SF_CFG_FATAL("sf_sdf_burst_seq: RD_FIFO and MAX_OUT must be >= 1")
  end

  localparam logic [2:0] OP_READ = `SDF_OP_READ, OP_WRITE = `SDF_OP_WRITE, OP_POSTED = `SDF_OP_WRITE_POSTED;
  localparam int S_IDLE = 0, S_RUN = 1, S_DONE = 2;
  localparam int FW = $clog2(RD_FIFO + 1);
  localparam int FP = (RD_FIFO > 1) ? $clog2(RD_FIFO) : 1;

  // ------------------------------------------------------------ command validation
  wire [AW:0]   a_ext   = {1'b0, cmd_addr};
  wire [AW:0]   end_ext = a_ext + (AW + 1)'(cmd_len);               // exclusive end, one bit wider than the address
  wire [AW:0]   last_ext = end_ext - 1'b1;                          // address of the last byte
  wire          op_ok   = (cmd_op == OP_READ) || (cmd_op == OP_WRITE) || (cmd_op == OP_POSTED);
  wire          len_zero = (cmd_len == '0);
  wire          len_big  = (cmd_len > LENW'(MAX_BYTES));
  wire          wrap     = (!len_zero) && last_ext[AW];
  /* verilator lint_off UNSIGNED */
  wire          out_rng  = (a_ext < LIM_LO) || (end_ext > LIM_HI);      // (a_ext < 0 is constant false when LIM_LO = 0)
  /* verilator lint_on UNSIGNED */
  wire          crosses  = (BOUNDARY != 0) && (!len_zero) && (((a_ext ^ last_ext) >> $clog2(BOUNDARY)) != '0);
  logic [2:0]   rj;
  always_comb begin
    rj = `SDF_RJ_NONE;
    if (!op_ok)         rj = `SDF_RJ_OPCODE;
    else if (len_zero)  rj = `SDF_RJ_ZERO;
    else if (len_big)   rj = `SDF_RJ_TOOLONG;
    else if (wrap)      rj = `SDF_RJ_WRAP;
    else if (out_rng)   rj = `SDF_RJ_RANGE;
    else if (crosses)   rj = `SDF_RJ_BOUNDARY;
  end

  // ------------------------------------------------------------ burst state
  logic [1:0]        st;
  logic [2:0]        op_q, qos_q;
  logic [IDW-1:0]    id_q;
  logic [AW-1:0]     base_q;                    // address of beat 0 (DW aligned)
  logic [WB:0]       first_off_q;               // first valid byte in beat 0 (0..SB-1)
  logic [WB:0]       last_cnt_q;                // valid bytes in the last beat (1..SB)
  logic [LENW-1:0]   len_q;
  logic [BEATW-1:0]  nbeats_q, ib_q, rb_q, cb_q;
  logic [1:0]        bstat_q;
  logic [BEATW-1:0]  errbeat_q;
  logic [2:0]        reason_q;
  logic              done_v;

  wire is_rd_q  = (op_q == OP_READ);
  wire is_post_q = (op_q == OP_POSTED);

  function automatic logic [SB-1:0] beat_mask(input logic [BEATW-1:0] k, input logic [BEATW-1:0] nb, input logic [WB:0] fo, input logic [WB:0] lc);
    logic [SB-1:0] m;
    begin
      m = '1;
      if (k == '0) begin
        for (int b = 0; b < SB; b++) if ((WB+1)'(b) < fo) m[b] = 1'b0;
      end
      if (k == nb - 1'b1) begin
        for (int b = 0; b < SB; b++) if ((WB+1)'(b) >= lc) m[b] = 1'b0;
      end
      beat_mask = m;
    end
  endfunction

  // ------------------------------------------------------------ read data FIFO
  logic [DW+1:0]   rf_mem [RD_FIFO];
  logic [FP-1:0]   rf_wp, rf_rp;
  logic [FW-1:0]   rf_cnt;
  wire  rf_empty = (rf_cnt == '0);

  // ------------------------------------------------------------ issue
  wire run         = (st == 2'(S_RUN));
  wire issuing     = run && (ib_q != nbeats_q);
  wire [BEATW-1:0] out_w = ib_q - rb_q;                     // issued, not yet answered (acknowledged ops)
  wire [BEATW-1:0] rdh_w = ib_q - cb_q;                     // issued reads not yet consumed
  wire credit_ok = is_post_q ? 1'b1 :
                   is_rd_q   ? (rdh_w < BEATW'(RD_FIFO)) :
                               (out_w < BEATW'(MAX_OUT));
  wire data_ok   = is_rd_q ? 1'b1 : wd_valid;
  assign m_req_valid  = issuing & credit_ok & data_ok;
  assign m_req_opcode = op_q;
  assign m_req_id     = id_q;
  assign m_req_qos    = qos_q;
  assign m_req_addr   = base_q + AW'(ib_q) * AW'(SB);
  assign m_req_wdata  = is_rd_q ? '0 : wd_data;
  wire [SB-1:0] bmask_i = beat_mask(ib_q, nbeats_q, first_off_q, last_cnt_q);
  assign m_req_wstrb  = is_rd_q ? {SB{1'b1}} : bmask_i;
  assign wd_ready     = m_req_valid & m_req_ready & ~is_rd_q;
  assign wd_lane_mask_o = bmask_i;
  wire req_fire = m_req_valid & m_req_ready;

  // ------------------------------------------------------------ responses
  assign m_rsp_ready = 1'b1;                                // always drained (SFB3 M1): credits guarantee room
  wire rsp_fire  = m_rsp_valid;
  wire rsp_bad   = rsp_fire && (m_rsp_id != id_q || m_rsp_opcode != op_q || !run || is_post_q);
  wire rsp_err   = rsp_fire && (m_rsp_status != `SDF_ST_OKAY);

  // ------------------------------------------------------------ consumer side of the read FIFO
  assign rd_valid  = ~rf_empty;
  assign rd_data   = rf_mem[rf_rp][DW+1:2];
  assign rd_status = rf_mem[rf_rp][1:0];
  assign rd_strb   = beat_mask(cb_q, nbeats_q, first_off_q, last_cnt_q);
  assign rd_last   = (cb_q == nbeats_q - 1'b1);
  wire   rd_fire   = rd_valid & rd_ready;

  // ------------------------------------------------------------ completion
  wire all_issued = (ib_q == nbeats_q);
  wire fin = run && all_issued &&
             (is_post_q ? 1'b1 :
              is_rd_q   ? (cb_q == nbeats_q) :
                          (rb_q == nbeats_q));
  assign cmd_ready  = (st == 2'(S_IDLE)) & ~done_v;
  wire   cmd_fire   = cmd_valid & cmd_ready;
  assign done_valid = done_v;
  assign busy_o     = (st != 2'(S_IDLE)) | done_v;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= 2'(S_IDLE); done_v <= 1'b0; op_q <= '0; qos_q <= '0; id_q <= '0; base_q <= '0; first_off_q <= '0; last_cnt_q <= '0;
      len_q <= '0; nbeats_q <= '0; ib_q <= '0; rb_q <= '0; cb_q <= '0; bstat_q <= `SDF_BS_OK; errbeat_q <= '0; reason_q <= '0;
      rf_wp <= '0; rf_rp <= '0; rf_cnt <= '0;
    end else begin
      // ---- read FIFO
      if (rsp_fire && !rsp_bad && is_rd_q) begin
        rf_mem[rf_wp] <= {m_rsp_rdata, m_rsp_status};
        rf_wp <= (rf_wp == FP'(RD_FIFO - 1)) ? '0 : rf_wp + 1'b1;
      end
      if (rd_fire) rf_rp <= (rf_rp == FP'(RD_FIFO - 1)) ? '0 : rf_rp + 1'b1;
      rf_cnt <= rf_cnt + FW'(rsp_fire && !rsp_bad && is_rd_q) - FW'(rd_fire);
      if (rd_fire) cb_q <= cb_q + 1'b1;
      // ---- request / response counters
      if (req_fire) ib_q <= ib_q + 1'b1;
      if (rsp_fire && !rsp_bad) begin
        rb_q <= rb_q + 1'b1;
        if (rsp_err && bstat_q == `SDF_BS_OK) begin
          bstat_q   <= (m_rsp_status == `SDF_ST_DECERR) ? `SDF_BS_DECERR : `SDF_BS_SLVERR;
          errbeat_q <= rb_q;
        end
      end
      // ---- state
      if (done_v && done_ready) begin
        done_v <= 1'b0;
        st <= 2'(S_IDLE);
      end
      if (cmd_fire) begin
        if (rj != `SDF_RJ_NONE) begin
          done_v <= 1'b1; reason_q <= rj; bstat_q <= `SDF_BS_REJECT; nbeats_q <= '0; len_q <= cmd_len; id_q <= cmd_id; errbeat_q <= '0;
          st <= 2'(S_DONE);
        end else begin
          op_q <= cmd_op; qos_q <= cmd_qos; id_q <= cmd_id;
          base_q <= {cmd_addr[AW-1:WB], {WB{1'b0}}};
          first_off_q <= (WB+1)'(cmd_addr[WB-1:0]);
          last_cnt_q  <= (WB+1)'(last_ext[WB-1:0]) + 1'b1;
          len_q <= cmd_len;
          nbeats_q <= BEATW'((last_ext >> WB) - (a_ext >> WB) + 1'b1);
          ib_q <= '0; rb_q <= '0; cb_q <= '0; bstat_q <= `SDF_BS_OK; errbeat_q <= '0; reason_q <= `SDF_RJ_NONE;
          rf_wp <= '0; rf_rp <= '0; rf_cnt <= '0;
          st <= 2'(S_RUN);
        end
      end
      if (fin) begin
        done_v <= 1'b1;
        st <= 2'(S_DONE);
      end
    end
  end
  assign done_id       = id_q;
  assign done_status   = bstat_q;
  assign done_reason   = reason_q;
  assign done_beats    = nbeats_q;
  assign done_err_beat = errbeat_q;
  assign done_bytes    = len_q;

  // ------------------------------------------------------------ statistics
  logic [CNT_W-1:0] c_bursts, c_rej, c_beats, c_bytes, c_wire, c_errb, c_busy, c_rstall, c_starve, c_cstall, c_rdst, c_proto;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      c_bursts <= '0; c_rej <= '0; c_beats <= '0; c_bytes <= '0; c_wire <= '0; c_errb <= '0; c_busy <= '0;
      c_rstall <= '0; c_starve <= '0; c_cstall <= '0; c_rdst <= '0; c_proto <= '0;
    end else if (cnt_clr_i) begin
      c_bursts <= '0; c_rej <= '0; c_beats <= '0; c_bytes <= '0; c_wire <= '0; c_errb <= '0; c_busy <= '0;
      c_rstall <= '0; c_starve <= '0; c_cstall <= '0; c_rdst <= '0; c_proto <= '0;
    end else begin
      if (done_v && done_ready) begin
        if (bstat_q == `SDF_BS_REJECT) c_rej <= c_rej + 1'b1;
        else begin
          c_bursts <= c_bursts + 1'b1;
          c_bytes  <= c_bytes + CNT_W'(len_q);
          c_wire   <= c_wire + CNT_W'(nbeats_q) * CNT_W'(SB);
        end
      end
      if (req_fire) c_beats <= c_beats + 1'b1;
      if (rsp_fire && !rsp_bad && rsp_err) c_errb <= c_errb + 1'b1;
      if (st != 2'(S_IDLE)) c_busy <= c_busy + 1'b1;
      if (m_req_valid && !m_req_ready) c_rstall <= c_rstall + 1'b1;
      if (issuing && credit_ok && !data_ok) c_starve <= c_starve + 1'b1;
      if (issuing && !credit_ok) c_cstall <= c_cstall + 1'b1;
      if (rd_valid && !rd_ready) c_rdst <= c_rdst + 1'b1;
      if (rsp_bad) c_proto <= c_proto + 1'b1;
    end
  end
  assign st_bursts_o = c_bursts; assign st_rejected_o = c_rej; assign st_beats_o = c_beats; assign st_bytes_o = c_bytes;
  assign st_wire_bytes_o = c_wire; assign st_errbeats_o = c_errb; assign st_busy_o = c_busy; assign st_req_stall_o = c_rstall;
  assign st_data_starve_o = c_starve; assign st_credit_stall_o = c_cstall; assign st_rd_stall_o = c_rdst; assign st_proto_o = c_proto;
endmodule

`default_nettype wire
