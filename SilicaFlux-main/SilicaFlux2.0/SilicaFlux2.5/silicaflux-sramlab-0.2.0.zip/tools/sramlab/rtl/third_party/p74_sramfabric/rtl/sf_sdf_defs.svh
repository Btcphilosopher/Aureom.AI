// =============================================================================
// SilicaFlux SRAMFabric (Project 74) :: sf_sdf_defs.svh
// Constants of the DataFabric -> SRAM bridge.  A `define header, not a package: the repository tool rules
// (DataFabric PROTOCOL.md sec. 9, Yosys 0.33) apply.  Values are part of the interface contract
// (docs/PROTOCOL_MAPPING.md): never renumber.
// SFB3 constants (opcodes, status) are NOT redefined here as new protocol: the SDF_OP_* / SDF_ST_* names below
// are the SAME values as sfn_pkg (third_party/noc_sfb3/rtl/sfn_pkg.sv) and are cross-checked against the
// package by tb/tb_sdf_consts.sv, so the bridge can be compiled without the package.
// =============================================================================
`ifndef SF_SDF_DEFS_SVH
`define SF_SDF_DEFS_SVH

// ---------------------------------------------------------------- SFB3 (== sfn_pkg)
`define SDF_OP_READ         3'd0
`define SDF_OP_WRITE        3'd1
`define SDF_OP_WRITE_POSTED 3'd2
`define SDF_OP_FENCE        3'd3      // fabric-local; never reaches a target
`define SDF_ST_OKAY         2'd0
`define SDF_ST_SLVERR       2'd1
`define SDF_ST_DECERR       2'd2      // fabric status; a target never produces it

// ---------------------------------------------------------------- bridge error causes (3 bits)
// Travel in the transaction queue, the error log and the optional rsp_cause sideband.  On the SFB3 response every
// cause != NONE is ST_SLVERR with rdata == 0.
`define SDF_CAUSE_NONE     3'd0
`define SDF_CAUSE_ADDR     3'd1       // illegal address: outside the window, outside the allowed range, beyond capacity
`define SDF_CAUSE_ALIGN    3'd2       // beat address not aligned to the fabric data width
`define SDF_CAUSE_OPCODE   3'd3       // opcode that is not READ / WRITE / WRITE_POSTED
`define SDF_CAUSE_SRAM     3'd4       // SRAM controller answered a status other than OK / ECC_UE for a request the bridge let through
`define SDF_CAUSE_ECC      3'd5       // uncorrectable ECC error (SF_ST_ECC_UE)
`define SDF_CAUSE_TIMEOUT  3'd6       // no controller response within TIMEOUT cycles; completed by the bridge (outcome of a write unknown)
`define SDF_CAUSE_RESET    3'd7       // controller flushed / reset while the transaction was in flight (outcome of a write unknown)

// ---------------------------------------------------------------- burst sequencer completion
`define SDF_BS_OK       2'd0
`define SDF_BS_SLVERR   2'd1          // at least one beat answered ST_SLVERR (first erroring beat reported)
`define SDF_BS_DECERR   2'd2          // at least one beat answered ST_DECERR by the fabric
`define SDF_BS_REJECT   2'd3          // command rejected before any beat was issued (reason in done_reason)

`define SDF_RJ_NONE     3'd0
`define SDF_RJ_ZERO     3'd1          // length 0
`define SDF_RJ_TOOLONG  3'd2          // length above MAX_BYTES
`define SDF_RJ_RANGE    3'd3          // [addr, addr+len) not inside [LIM_LO, LIM_HI)
`define SDF_RJ_BOUNDARY 3'd4          // crosses a BOUNDARY-byte boundary (when BOUNDARY != 0)
`define SDF_RJ_OPCODE   3'd5          // opcode not READ / WRITE / WRITE_POSTED
`define SDF_RJ_WRAP     3'd6          // addr + len wraps the address space

// ---------------------------------------------------------------- performance counter word indices (sf_sdf_port perf_o)
`define SDF_P_CYCLES    0             // free running
`define SDF_P_REQ       1             // transactions accepted by the SRAM controller (error requests included)
`define SDF_P_RD        2
`define SDF_P_WR        3             // acknowledged + posted
`define SDF_P_POSTED    4
`define SDF_P_BYTES_RD  5             // useful bytes: DW/8 per read beat
`define SDF_P_BYTES_WR  6             // useful bytes: number of set byte enables
`define SDF_P_LINE_ACC  7             // array accesses issued (requests that were legal)
`define SDF_P_RSP       8             // responses delivered on the target port
`define SDF_P_LAT_SUM   9             // sum over responses of (response handshake cycle - request acceptance cycle)
`define SDF_P_LAT_MAX   10
`define SDF_P_LAT_MIN   11            // 0xFFFFFFFF until the first response
`define SDF_P_REQ_STALL 12            // cycles t_req_valid && !t_req_ready
`define SDF_P_RSP_STALL 13            // cycles t_rsp_valid && !t_rsp_ready
`define SDF_P_CTRL_STALL 14           // cycles a request waited for the controller (bank busy / arbitration / slot)
`define SDF_P_OCC_SUM   15            // sum over cycles of outstanding transactions
`define SDF_P_OCC_MAX   16
`define SDF_P_SEQ       17            // accepted beats that continue the previous beat (same src, id, addr + DW/8)
`define SDF_P_RUNS      18            // accepted beats that do not (starts of runs)
`define SDF_P_ERR_RSP   19            // responses with a cause
`define SDF_P_CE        20            // corrected ECC events seen on responses
`define SDF_P_ORPHAN    21            // controller responses with no matching transaction (consumed, never delivered)
`define SDF_P_PROTO     22            // response / table head mismatch (must be 0)
`define SDF_P_OVF       23            // transaction queue overflow attempts (must be 0)
`define SDF_P_TIMEOUT   24            // timeout events
`define SDF_P_SYNTH     25            // responses synthesised by the bridge (TIMEOUT / RESET)
`define SDF_P_BUSY      26            // cycles with at least one outstanding transaction
`define SDF_P_STALL_BANKED 27         // (reserved) == sum of per-bank stalls
`define SDF_NPERF       28

`endif // SF_SDF_DEFS_SVH
