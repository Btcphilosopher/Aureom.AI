// =============================================================================
// Integration testbench: sf_sram_mbist on the REAL SilicaFlux MemoryCore (sf_sram_controller -> sf_sram_bank ->
// sf_sram_macro_wrapper -> sf_sram_core; SECDED ECC when ECC_EN = 1), unmodified third_party RTL.
//   * the MBIST drives the controller's own quiesce / idle / init / raw-test-bus contract
//   * two live functional masters (random read / write traffic, own scoreboard) run before, around and after tests
//   * faults come from MemoryCore's OWN simulation-only fault models (SF_FT_*), independent of this project's
//     sf_mbist_fault_mem: agreement between the two models on the first-failure signature is a cross-check
//   M01 reset / init, functional sanity      M06 re-initialisation: every line valid, no ECC event, after a test
//   M02 fault-free test with live traffic    M07 abort mid-run on the real controller
//   M03 first-failure signature, per bank    M08 reset mid-run (INIT_ON_RESET with ECC; dirty array without)
//   M04 every MemoryCore fault type          M09 ownership monitors over the whole simulation
//   M05 ECC interaction: concealment, check-column raw test, decoder bypassed by the raw bus
// =============================================================================
`timescale 1ns/1ps
`include "sf_mbist_defs.svh"
`include "sf_sram_defs.svh"
`include "tb_common.svh"

module tb_mbist_memorycore;
  parameter int ECC_EN = 1;
  parameter int READ_LATENCY = 1;
  localparam int NM = 2, NB = 4, DEPTH = 16, DW = 32, AWB = 16, IDW = 4;
  localparam int LB = $clog2(DW / 8);
  localparam int ROW_W = $clog2(DEPTH);
  localparam int BW = $clog2(NB);
  localparam int R = $clog2(DW + $clog2(DW + 1) + 1);
  localparam int STORE_W = (ECC_EN != 0) ? DW + R + 1 : DW;
  localparam int FBW = $clog2(STORE_W);
  localparam int BITW = $clog2(STORE_W);
  localparam int NLINES = NB * DEPTH;

  integer errors = 0, checks = 0;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- controller
  logic [NM-1:0] m_req_valid, m_req_we; wire [NM-1:0] m_req_ready;
  logic [NM*AWB-1:0] m_req_addr; logic [NM*DW-1:0] m_req_wdata; logic [NM*(DW/8)-1:0] m_req_be; logic [NM*IDW-1:0] m_req_id;
  wire [NM-1:0] m_rsp_valid; wire [NM*DW-1:0] m_rsp_rdata; wire [NM*IDW-1:0] m_rsp_id; wire [NM-1:0] m_rsp_we;
  wire [NM*3-1:0] m_rsp_status; wire [NM-1:0] m_rsp_ce;
  wire quiesce, c_idle, init_start, init_busy;
  wire tst_active, tst_ce, tst_we; wire [NB-1:0] tst_sel; wire [ROW_W-1:0] tst_addr; wire [STORE_W-1:0] tst_wdata;
  wire [NB*STORE_W-1:0] tst_rdata;
  wire [NB-1:0] ev_ce, ev_ue; wire [NB*16-1:0] ce_cnt, ue_cnt;
  logic [BW-1:0] fi_bank; logic [3:0] fi_type; logic [ROW_W-1:0] fi_row, fi_row2; logic [FBW-1:0] fi_bit, fi_bit2; logic fi_val, fi_val2;

  sf_sram_controller #(
    .NM(NM), .NB(NB), .DEPTH(DEPTH), .DW(DW), .AW(AWB), .IDW(IDW), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN),
    .NSLOT(8), .FAULT_INJECT(1)
  ) ctl (
    .clk(clk), .rst_n(rst_n), .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we),
    .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready({NM{1'b1}}), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id),
    .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(quiesce), .idle_o(c_idle), .init_start_i(init_start),
    .init_busy_o(init_busy), .scrub_en_i(1'b0), .ecc_clr_i(1'b0), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue),
    .ce_cnt_o(ce_cnt), .ue_cnt_o(ue_cnt), .perf_acc_o(), .perf_conf_o(), .perf_busy_o(), .perf_stall_o(), .bank_acc_o(),
    .tst_active_i(tst_active), .tst_sel_i(tst_sel), .tst_ce_i(tst_ce), .tst_we_i(tst_we), .tst_addr_i(tst_addr),
    .tst_wdata_i(tst_wdata), .tst_rdata_o(tst_rdata),
    .fi_bank(fi_bank), .fi_type(fi_type), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2),
    .fi_val(fi_val), .fi_val2(fi_val2), .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  // ---------------------------------------------------------------- MBIST
  logic rb_req, rb_we; logic [11:0] rb_addr; logic [31:0] rb_wdata; wire rb_gnt, rb_err; wire [31:0] rb_rdata;
  logic test_permit, abort_pin;
  wire busy_o, done_o, pass_o, fail_o, error_o; wire [2:0] result_o; wire [NB-1:0] bank_tested_o, bank_fail_mask_o;
  wire [`MB_NERR-1:0] err_flags_o; wire fail_valid_o; wire [BW-1:0] fail_bank_o; wire [ROW_W-1:0] fail_row_o;
  wire [BITW-1:0] fail_bit_o; wire fail_bit_v_o, fail_in_check_o; wire [2:0] fail_elem_o; wire fail_pol_o; wire [3:0] fail_cls_o;
  wire [STORE_W-1:0] fail_exp_o, fail_obs_o; wire [31:0] fail_count_o; wire [7:0] state_o;
  wire tst_active_w, mb_quiesce, mb_init_start;
  wire func_acc = |(m_req_valid & m_req_ready);       // a functional request ACCEPTED by the controller

  sf_sram_mbist #(
    .NBANK(NB), .ROWS(DEPTH), .DATA_W(DW), .STORE_W(STORE_W), .READ_LATENCY(READ_LATENCY),
    .ACCESS_MASK(4'b1111), .SHARED_MASK(4'b1111), .TENSOR_MASK(4'b0000), .VECTOR_MASK(4'b0000), .FIFO_DEPTH(4),
    .OWN_TIMEOUT(2000), .INIT_TIMEOUT(DEPTH + 200)
  ) dut (
    .clk(clk), .rst_n(rst_n), .start_i(1'b0), .start_clr_i(1'b0), .abort_i(abort_pin), .clear_i(1'b0), .fail_pop_i(1'b0),
    .clr_fault_i(1'b0), .cfg_from_pins_i(1'b0), .cfg_algo_i(4'd0), .cfg_pattern_i(3'd0), .cfg_stripe_k_i(4'd0),
    .cfg_sweep_i(1'b0), .cfg_colsel_i(2'd0), .cfg_stop_i(1'b0), .cfg_reinit_i(1'b1), .cfg_sel_i(3'd0), .cfg_bank_i(8'd0),
    .cfg_bmask_i(4'd0), .cfg_row_lo_i('0), .cfg_row_hi_i('0), .cfg_wdog_i(32'd0),
    .test_mode_i(1'b1), .test_permit_i(test_permit), .mem_inhibit_i(1'b0), .cpu_halted_i(1'b0), .protect_i(4'd0),
    .busy_o(busy_o), .done_o(done_o), .pass_o(pass_o), .fail_o(fail_o), .error_o(error_o), .result_o(result_o),
    .bank_tested_o(bank_tested_o), .bank_fail_mask_o(bank_fail_mask_o), .err_flags_o(err_flags_o), .state_o(state_o),
    .fail_valid_o(fail_valid_o), .fail_bank_o(fail_bank_o), .fail_row_o(fail_row_o), .fail_bit_o(fail_bit_o),
    .fail_bit_v_o(fail_bit_v_o), .fail_in_check_o(fail_in_check_o), .fail_elem_o(fail_elem_o), .fail_op_o(),
    .fail_pol_o(fail_pol_o), .fail_pass_o(), .fail_cls_o(fail_cls_o), .fail_alias_o(), .fail_exp_o(fail_exp_o),
    .fail_obs_o(fail_obs_o), .fail_count_o(fail_count_o),
    .quiesce_o(quiesce), .quiesce_ack_i(1'b1), .idle_i(c_idle), .init_start_o(init_start), .init_busy_i(init_busy),
    .func_req_i(func_acc), .clk_req_o(), .tst_active_o(tst_active), .tst_sel_o(tst_sel), .tst_ce_o(tst_ce),
    .tst_we_o(tst_we), .tst_addr_o(tst_addr), .tst_wdata_o(tst_wdata), .tst_rdata_i(tst_rdata),
    .rb_req(rb_req), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_gnt(rb_gnt), .rb_rdata(rb_rdata),
    .rb_err(rb_err), .ras_valid_o(), .ras_type_o(), .ras_addr_o(), .ras_addr_v_o(), .ras_info_o(), .ras_corr_o(),
    .rep_row_v_o(), .rep_row_o(), .rep_col_v_o(), .rep_col_o(), .rep_ok_o(), .rep_unrep_o(), .rep_phys_o());

  `include "tb_mbist_rbus.svh"

  // ---------------------------------------------------------------- functional masters + scoreboard
  logic [NM-1:0] traf_en;
  logic dir_mode; logic d_valid, d_we; logic [AWB-1:0] d_addr; logic [DW-1:0] d_wdata;
  logic [DW-1:0] ref_d [NLINES]; logic ref_v [NLINES];
  integer func_chk = 0, func_err = 0, func_ce = 0, func_st_err = 0;
  logic [31:0] lfsr [NM];
  integer m_st [NM]; integer m_line [NM]; logic m_isw [NM]; logic [DW-1:0] m_exp [NM]; logic m_expv [NM];
  logic t_valid [NM]; logic t_we [NM]; logic [AWB-1:0] t_addr [NM]; logic [DW-1:0] t_wd [NM];
  logic [DW-1:0] d_rdata; logic [2:0] d_status; logic d_ce; logic d_done;

  function automatic [AWB-1:0] line_addr(input integer line); begin line_addr = AWB'(line << LB); end endfunction

  always_comb begin
    for (int m = 0; m < NM; m++) begin
      m_req_valid[m]                    = (m == 0 && dir_mode) ? d_valid : t_valid[m];
      m_req_we[m]                       = (m == 0 && dir_mode) ? d_we    : t_we[m];
      m_req_addr[m*AWB +: AWB]          = (m == 0 && dir_mode) ? d_addr  : t_addr[m];
      m_req_wdata[m*DW +: DW]           = (m == 0 && dir_mode) ? d_wdata : t_wd[m];
      m_req_be[m*(DW/8) +: DW/8]        = '1;
      m_req_id[m*IDW +: IDW]            = IDW'(m);
    end
  end

  logic init_busy_q;
  always @(posedge clk) begin
    init_busy_q <= init_busy;
    if (init_busy_q && !init_busy) begin             // init engine finished: every line is zero with valid ECC
      for (int i = 0; i < NLINES; i++) begin ref_d[i] = '0; ref_v[i] = 1'b1; end
    end
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int m = 0; m < NM; m++) begin
        m_st[m] = 0; t_valid[m] = 0; t_we[m] = 0; t_addr[m] = '0; t_wd[m] = '0; lfsr[m] = 32'hC0DE_0001 + 32'(m) * 32'h1357;
      end
    end else begin
      for (int m = 0; m < NM; m++) begin
        lfsr[m] <= {lfsr[m][30:0], lfsr[m][31] ^ lfsr[m][21] ^ lfsr[m][1] ^ lfsr[m][0]};
        case (m_st[m])
          0: if (traf_en[m] && !(m == 0 && dir_mode)) begin
               m_line[m] = int'((lfsr[m] >> 4) % (NLINES / NM)) * NM + m;     // disjoint line sets per master
               m_isw[m]  = lfsr[m][1] | lfsr[m][3];
               t_valid[m] = 1'b1; t_we[m] = m_isw[m]; t_addr[m] = line_addr(m_line[m]);
               t_wd[m] = lfsr[m] ^ 32'h9E37_79B9;
               m_st[m] = 1;
             end
          1: if (m_req_ready[m]) begin
               t_valid[m] = 1'b0;
               if (m_isw[m]) begin ref_d[m_line[m]] = t_wd[m]; ref_v[m_line[m]] = 1'b1; end
               m_exp[m] = ref_d[m_line[m]]; m_expv[m] = ref_v[m_line[m]];
               m_st[m] = 2;
             end
          2: if (m_rsp_valid[m]) begin
               if (!m_isw[m] && m_expv[m]) begin
                 func_chk = func_chk + 1;
                 if (m_rsp_rdata[m*DW +: DW] !== m_exp[m] || m_rsp_status[m*3 +: 3] !== 3'd0) func_err = func_err + 1;
               end
               if (m_rsp_ce[m]) func_ce = func_ce + 1;
               if (m_rsp_status[m*3 +: 3] !== 3'd0) func_st_err = func_st_err + 1;
               m_st[m] = 0;
             end
          default: m_st[m] = 0;
        endcase
      end
    end
  end

  // directed access through master 0 (traffic of master 0 must be off)
  task automatic func_access(input logic we, input integer line, input logic [DW-1:0] wd);
    integer t;
    begin
      dir_mode = 1'b1; d_we = we; d_addr = line_addr(line); d_wdata = wd; @(posedge clk); d_valid = 1'b1;
      t = 0; while (!m_req_ready[0] && t < 2000) begin @(posedge clk); t = t + 1; end
      @(posedge clk); d_valid = 1'b0;
      t = 0; while (!m_rsp_valid[0] && t < 2000) begin @(posedge clk); t = t + 1; end
      d_rdata = m_rsp_rdata[0*DW +: DW]; d_status = m_rsp_status[0*3 +: 3]; d_ce = m_rsp_ce[0];
      @(posedge clk); dir_mode = 1'b0;
    end
  endtask
  task automatic func_write(input integer line, input logic [DW-1:0] wd);
    begin func_access(1'b1, line, wd); ref_d[line] = wd; ref_v[line] = 1'b1; end
  endtask
  task automatic func_read(input integer line); begin func_access(1'b0, line, '0); end endtask

  // fault injection into the controller's own models
  task automatic inject(input int bank, input int ty, input int row, input int bt, input int row2, input int bt2, input int v, input int v2);
    begin fi_bank = BW'(bank); fi_type = 4'(ty); fi_row = ROW_W'(row); fi_bit = FBW'(bt); fi_row2 = ROW_W'(row2); fi_bit2 = FBW'(bt2); fi_val = v[0]; fi_val2 = v2[0]; end
  endtask
  task automatic nofault; begin fi_type = 4'd0; end endtask

  // ---------------------------------------------------------------- monitors
  integer viol_busy = 0, viol_acc = 0, viol_ce = 0, viol_noq = 0, viol_permit = 0;
  logic tst_active_q;
  integer ops_n = 0, act_cycles = 0;
  always @(posedge clk) begin
    tst_active_q <= tst_active;
    if (tst_active && !tst_active_q && !c_idle) viol_busy = viol_busy + 1;   // arrays handed over while the controller was NOT idle (test ops themselves legitimately make idle_o low)
    if (tst_active && func_acc)    viol_acc  = viol_acc + 1;        // functional access accepted during test
    if (tst_ce && !tst_active)     viol_ce   = viol_ce + 1;
    if (tst_active && !quiesce)    viol_noq  = viol_noq + 1;
    if (tst_ce && !test_permit)    viol_permit = viol_permit + 1;
    if (tst_active) act_cycles = act_cycles + 1;
    if (tst_ce) ops_n = ops_n + 1;
  end
  task automatic mon_clear; begin ops_n = 0; act_cycles = 0; end endtask

  task automatic tick(input int n); begin repeat (n) @(posedge clk); end endtask
  integer run_to;
  task automatic wait_run;
    integer t;
    begin
      t = 0; run_to = 0;
      while (!busy_o && t < 60) begin @(posedge clk); t = t + 1; end
      t = 0;
      while (busy_o && t < 400000) begin @(posedge clk); t = t + 1; end
      if (t >= 400000) begin run_to = 1; `CHECK(0, "run did not complete (timeout)") end
      repeat (4) @(posedge clk);
    end
  endtask
  task automatic defcfg; begin cfgw(0, 0, 0, 0, 0, 0, 1); selw(`MB_SEL_ALL, 0, 15); winw(0, DEPTH - 1); rw(A_WDOG, 0); end endtask
  task automatic go; begin mon_clear(); rw(A_CTRL, 32'h1); wait_run(); end endtask
  task automatic do_clear; begin rw(A_CTRL, 32'h4); tick(4); end endtask
  task automatic quiet; begin traf_en = '0; tick(40); end endtask

  // read every line, expect zero + OK + no correction (re-initialised array with valid ECC)
  integer nz, nbad_st, nce;
  integer nref;
  task automatic read_all_expect_ref;        // functional traffic may have rewritten lines since the test: compare with the reference
    begin
      nref = 0; nbad_st = 0;
      for (int ln = 0; ln < NLINES; ln++) begin
        func_read(ln);
        if (ref_v[ln] && d_rdata !== ref_d[ln]) nref = nref + 1;
        if (d_status !== 3'd0) nbad_st = nbad_st + 1;
      end
    end
  endtask
  task automatic read_all_expect_zero;
    begin
      nz = 0; nbad_st = 0; nce = 0;
      for (int ln = 0; ln < NLINES; ln++) begin
        func_read(ln);
        if (d_rdata !== '0) nz = nz + 1;
        if (d_status !== 3'd0) nbad_st = nbad_st + 1;
        if (d_ce) nce = nce + 1;
      end
    end
  endtask

  integer i, ce0, ue0, b0, cnt_before; logic [NB*16-1:0] ce_snap, ue_snap; integer line;
  initial begin
    traf_en = '0; dir_mode = 0; d_valid = 0; d_we = 0; d_addr = 0; d_wdata = 0; rb_req = 0; rb_we = 0; rb_addr = 0; rb_wdata = 0;
    test_permit = 1; abort_pin = 0; nofault();
    for (int k = 0; k < NLINES; k++) begin ref_d[k] = '0; ref_v[k] = 1'b0; end
    repeat (5) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);
    while (init_busy || !c_idle) @(posedge clk);
    tick(10);

    // ============================================================ M01
    `SECTION("M01 reset / init and functional sanity");
    rr(A_ID); `CHECK_EQ(rd_val, 32'h4D425354, "MBIST register page reachable")
    rr(A_CAPS0); `CHECK_EQ(rd_val[31:24], 8'(STORE_W), "CAPS0.STORE_W matches the controller's stored word")
    func_write(21, 32'hDEAD_BEEF); func_read(21);
    `CHECK_EQ(d_rdata, 32'hDEAD_BEEF, "functional write / read through the real controller") `CHECK_EQ(d_status, 3'd0, "status OK") `CHECK(!d_ce, "no correction")
    func_read(22);
    if (ECC_EN != 0) begin `CHECK_EQ(d_rdata, 32'd0, "after init: unwritten line reads zero") `CHECK_EQ(d_status, 3'd0, "valid ECC after init (no UE)") end

    // ============================================================ M02
    `SECTION("M02 fault-free test with live functional traffic");
    defcfg(); traf_en = 2'b11; tick(400);
    ce_snap = ce_cnt; ue_snap = ue_cnt; func_ce = 0; cnt_before = func_chk;
    go();
    `CHECK_EQ(result_o, `MB_RES_PASS, "PASS on the real memory stack") `CHECK_EQ(bank_tested_o, 4'b1111, "all four banks tested")
    `CHECK_EQ(ops_n, 10 * DEPTH * NB, "640 test operations (10 N x 4 banks)")
    `CHECK_EQ(fail_count_o, 32'd0, "no failure on a fault-free memory")
    tick(600);
    `CHECK(func_chk > cnt_before + 20, "functional traffic resumed and was checked after the test")
    `CHECK_EQ(func_err, 0, "functional scoreboard clean: contents valid after the test (re-initialised)")
    `CHECK_EQ(func_st_err, 0, "no error response")
    `CHECK_EQ(ce_cnt, ce_snap, "raw test bus bypasses the ECC decoder: CE counters untouched by the test")
    `CHECK_EQ(ue_cnt, ue_snap, "raw test bus bypasses the ECC decoder: UE counters untouched by the test")
    do_clear(); quiet();

    // ============================================================ M03
    `SECTION("M03 first-failure signature against MemoryCore's own fault model");
    for (int b = 0; b < NB; b++) begin
      defcfg(); inject(b, `SF_FT_SAF, 5, 3, 0, 0, 0, 0);               // SA0 at (row 5, stored bit 3)
      go();
      `CHECK_EQ(result_o, `MB_RES_FAIL, "SA0: FAIL") `CHECK_EQ(fail_bank_o, BW'(b), "bank")
      `CHECK_EQ(fail_row_o, ROW_W'(5), "row") `CHECK_EQ(fail_bit_o, BITW'(3), "bit") `CHECK(fail_bit_v_o && !fail_in_check_o, "single data bit")
      `CHECK_EQ(fail_elem_o, 3'd2, "first failure in U(r1,w0): identical to this project's fault model (docs/04)")
      `CHECK_EQ(fail_cls_o, `MB_CLS_1TO0_BIT, "class: 1 read as 0")
      `CHECK_EQ(bank_fail_mask_o, 4'(1 << b), "only the faulty bank in the mask")
      do_clear();
      inject(b, `SF_FT_SAF, 5, 3, 0, 0, 1, 0); go();                   // SA1
      `CHECK_EQ(fail_elem_o, 3'd1, "SA1 detected in U(r0,w1)") `CHECK_EQ(fail_cls_o, `MB_CLS_0TO1_BIT, "class: 0 read as 1")
      do_clear();
    end
    nofault();

    // ============================================================ M04
    `SECTION("M04 every MemoryCore fault type is detected");
    for (int ft = 1; ft <= 8; ft++) begin
      defcfg(); selw(`MB_SEL_BANK, 2, 0);
      case (ft)
        `SF_FT_SAF:    inject(2, ft, 6, 1, 0, 0, 0, 0);
        `SF_FT_TF:     inject(2, ft, 6, 1, 0, 0, 1, 0);
        `SF_FT_AF_NA:  inject(2, ft, 6, 0, 0, 0, 0, 0);
        `SF_FT_AF_ALI: inject(2, ft, 6, 0, 10, 0, 0, 0);
        `SF_FT_AF_MUL: inject(2, ft, 6, 0, 10, 0, 0, 0);
        `SF_FT_CFIN:   inject(2, ft, 2, 0, 9, 4, 1, 0);
        `SF_FT_CFID:   inject(2, ft, 2, 0, 9, 4, 1, 1);
        `SF_FT_CFST:   inject(2, ft, 2, 0, 9, 4, 1, 1);
      endcase
      go(); $display("  fault type %0d -> result %0d (2 = FAIL), fail_count %0d", ft, result_o, fail_count_o);
      `CHECK_EQ(result_o, `MB_RES_FAIL, "fault type detected on the real stack") `CHECK_EQ(fail_bank_o, BW'(2), "in bank 2")
      do_clear();
    end
    nofault();

    // ============================================================ M05
    `SECTION("M05 ECC interaction: concealment, check columns, decoder bypass");
    quiet(); defcfg();
    begin : m05
      integer ln;
      ln = 5 * NB + 1;                                                  // line of (bank 1, row 5)
      inject(1, `SF_FT_SAF, 5, 3, 0, 0, 0, 0);                          // data bit 3 stuck at 0
      func_write(ln, 32'hFFFF_FFFF); func_read(ln);
      if (ECC_EN != 0) begin
        `CHECK_EQ(d_rdata, 32'hFFFF_FFFF, "ECC: the stuck data cell is CONCEALED from the functional reader") `CHECK(d_ce, "...only the correction flag shows it")
        `CHECK_EQ(d_status, 3'd0, "status OK (corrected)")
      end else begin
        `CHECK_EQ(d_rdata, 32'hFFFF_FFF7, "no ECC: the same fault corrupts functional data") `CHECK(!d_ce, "nothing reported")
      end
      selw(`MB_SEL_BANK, 1, 0); go();
      `CHECK_EQ(result_o, `MB_RES_FAIL, "the raw array test finds the cell that ECC hides")
      `CHECK(fail_bank_o == BW'(1) && fail_row_o == ROW_W'(5) && fail_bit_o == BITW'(3), "at the injected location")
      do_clear(); nofault();
      if (ECC_EN != 0) begin
        defcfg(); selw(`MB_SEL_BANK, 2, 0);
        inject(2, `SF_FT_SAF, 9, DW + 3, 0, 0, 1, 0);                   // stuck-at-1 in a CHECK column
        cfgw(0, 0, 0, 0, `MB_COL_DATA, 0, 1);  go(); `CHECK_EQ(result_o, `MB_RES_PASS, "data-only compare does not see a check-column defect") do_clear();
        cfgw(0, 0, 0, 0, `MB_COL_ALL, 0, 1);   go(); `CHECK_EQ(result_o, `MB_RES_FAIL, "raw full-word test finds the check-column defect")
        `CHECK(fail_in_check_o && fail_bit_o == BITW'(DW + 3), "reported as check column, index DW+3") do_clear();
        cfgw(0, 0, 0, 0, `MB_COL_CHECK, 0, 1); go(); `CHECK_EQ(result_o, `MB_RES_FAIL, "check-only compare finds it") do_clear();
        nofault();
      end
    end

    // ============================================================ M06
    `SECTION("M06 re-initialisation: all lines valid after a test (data + ECC)");
    quiet(); defcfg(); go(); `CHECK_EQ(result_o, `MB_RES_PASS, "fault-free run"); do_clear();
    ce_snap = ce_cnt; ue_snap = ue_cnt;
    read_all_expect_zero();
    `CHECK_EQ(nz, 0, "every line reads zero (the test background is gone)") `CHECK_EQ(nbad_st, 0, "no line answers an error status (ECC valid everywhere)")
    `CHECK_EQ(nce, 0, "no correction needed anywhere")
    `CHECK_EQ(ce_cnt, ce_snap, "reading back raised no CE events") `CHECK_EQ(ue_cnt, ue_snap, "reading back raised no UE events")

    // ============================================================ M07
    `SECTION("M07 abort mid-run on the real controller");
    traf_en = 2'b11; tick(200); defcfg(); mon_clear(); func_err = 0;
    rw(A_CTRL, 32'h1); while (ops_n < 200) @(posedge clk); rw(A_CTRL, 32'h2); wait_run();
    `CHECK_EQ(result_o, `MB_RES_ABORTED, "ABORTED") `CHECK(!pass_o && ops_n < 640, "not a pass, stopped early")
    tick(800); `CHECK_EQ(func_err, 0, "functional traffic is correct right after the abort (array re-initialised)")
    do_clear(); quiet(); read_all_expect_ref();
    `CHECK_EQ(nref, 0, "after the abort every line equals the scoreboard reference (array valid, test background gone)") `CHECK_EQ(nbad_st, 0, "no error status")

    // ============================================================ M08
    `SECTION("M08 reset in the middle of a test");
    quiet(); defcfg(); mon_clear(); rw(A_CTRL, 32'h1); while (ops_n < 150) @(posedge clk);
    #2 rst_n = 0; tick(3); #2 rst_n = 1; tick(10);
    `CHECK(!busy_o && !tst_active && !quiesce, "MBIST idle and released after the reset")
    while (init_busy || !c_idle) @(posedge clk);                         // ECC builds: INIT_ON_RESET sweeps the array
    tick(10); read_all_expect_zero();
    if (ECC_EN != 0) begin
      `CHECK_EQ(nz, 0, "ECC build: INIT_ON_RESET re-initialises, every line zero") `CHECK_EQ(nbad_st, 0, "...with valid ECC (no UE)")
    end else begin
      `CHECK(nz > 0, "non-ECC build: the interrupted test leaves the background (hazard H3: platform must initialise)")
    end
    // recover and confirm the DUT is fully usable afterwards
    defcfg(); go(); `CHECK_EQ(result_o, `MB_RES_PASS, "test runs after the reset"); do_clear(); quiet();

    // ============================================================ M09
    `SECTION("M09 ownership monitors over the whole simulation");
    `CHECK_EQ(viol_busy, 0, "arrays handed to the test bus only while the controller was idle")
    `CHECK_EQ(viol_acc, 0, "no functional access accepted while the test owned the arrays")
    `CHECK_EQ(viol_ce, 0, "no test operation without tst_active")
    `CHECK_EQ(viol_noq, 0, "tst_active never without quiesce")
    `CHECK_EQ(viol_permit, 0, "no test operation without permission")

    $display("RESULT tb_mbist_memorycore ECC_EN=%0d READ_LATENCY=%0d STORE_W=%0d checks=%0d errors=%0d %s", ECC_EN, READ_LATENCY, STORE_W, checks,
             errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #900000000; $display("RESULT tb_mbist_memorycore global timeout FAIL"); $finish; end
endmodule
