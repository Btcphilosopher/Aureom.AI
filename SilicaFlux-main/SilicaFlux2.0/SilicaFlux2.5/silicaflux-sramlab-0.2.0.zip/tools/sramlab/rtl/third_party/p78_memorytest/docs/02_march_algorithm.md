# 02 - March algorithms, address sequences, backgrounds, diagnosis

## 1. March C- (documented definition)

Notation: `U` ascending, `D` descending, `B` any order (executed ascending here); `rX` = read, expect X; `wX` = write X.
"0" is the data background `B(row)`, "1" is `~B(row)`, both over the whole **stored word** (`STORE_W` columns).

| Element | Notation | Order | Per address | Purpose |
|---|---|---|---|---|
| 0 | `B(w0)` | all addresses | write 0 | initialise: no reliance on the array's power-up content |
| 1 | `U(r0,w1)` | ascending | read 0, write 1 | up-transition, state-1 coupling from lower addresses |
| 2 | `U(r1,w0)` | ascending | read 1, write 0 | down-transition |
| 3 | `D(r0,w1)` | descending | read 0, write 1 | up-transition, coupling from higher addresses |
| 4 | `D(r1,w0)` | descending | read 1, write 0 | down-transition |
| 5 | `B(r0)` | all addresses | read 0 | final read of the array |

Length `10 N`.  MATS+ (`B(w0); U(r0,w1); D(r1,w0)`, `5 N`) is provided as a weaker reference.

### Address sequences (precise)

Window `[lo, hi]`, inclusive, `lo <= hi < ROWS` (validated before any access; default `[0, ROWS-1]`).

* **ascending**: `lo, lo+1, ..., hi`; the element is complete when `addr == hi`.
* **descending**: `hi, hi-1, ..., lo`; complete when `addr == lo`.  It is the exact reverse of the ascending sequence.
* every address appears **exactly once per element**; a one-address window is a valid element.
* `step` is ignored once the last address is reached, so the sequencer cannot leave the window.
* An element ends on the last operation of the last address; the next element's first address is on the bus in the **next cycle**
  (no bubble): exactly `10 N` operation cycles per pass.

Verified: the bus trace of a fault-free run equals an **independently written** golden March C- operation list (order, addresses,
write data) for `ROWS` = 12..20, `STORE_W` = 8..137 and `READ_LATENCY` = 1..4, windows, MATS+ and every background
(`tb_p1_march_one_bank`).

### Synchronous read latency

Memory contract: `tst_rdata` appears exactly `READ_LATENCY` cycles after the accepting edge and is not held.  The engine issues one
operation per cycle (a read followed by the write to the same address in the next cycle is legal: the read result was
captured at its accepting edge), keeps `{valid, row, element, op, polarity, pass}` in an `LT`-deep pipe and compares at stage
`LT`.  A pass ends with `LT` drain cycles so the last read is compared before the bank or pass changes.

## 2. Data backgrounds (`sf_mbist_pattern`) and the objective of each

Only patterns that serve a documented test objective are present; `data = B(row) ^ {W{pol}}`.

| Pattern | `B[i]` | Documented objective |
|---|---|---|
| `ALL0` | 0 | the standard solid background |
| `ALL1` | 1 | complementary start state: every cell sees its transitions in the opposite order; separates TF-up vs TF-down and SA0 vs SA1 symptoms |
| `ALT` | `i[0]` | coupling between logically adjacent columns (equals `STRIPE k=0`) |
| `CHECKER` | `i[0] ^ row[0]` | adjacent columns **and** rows.  A physical checkerboard only if logical order == physical order (**not claimed**) |
| `ADDR` | `row[i mod AW] ^ ((i / AW) & 1)` | every row stores a different word -> **address-decoder diagnosis**: the observed word of a wrong-row read is the pattern of the row really accessed, so the alias target is recovered (class `ADDR_ALIAS`, `alias_row`) |
| `STRIPE k` | `(i >> k) & 1` | **intra-word coupling coverage** (below) |

### Why the stripe sweep exists (measured, not assumed)

Two cells of the *same word* always hold equal values under a solid background and always change together, so several
(aggressor, victim) combinations are never excited.  MemoryCore's engine (solid + checkerboard) measured **80.65 %** same-word
coupling coverage and documented four classes at ~51 %.  `cfg_sweep` runs `ALL0` plus `STRIPE k = 0 .. ceil(log2 W)-1`: the
binary indexes of any two columns differ in some bit `k`, so some background gives them different values and another equal
values.  **Measured** (`reports/coverage.md`, exhaustive, 4 rows x 32 bits, 39 680 same-word coupling faults): solid 60.00 %,
checkerboard 60.00 %, solid U checkerboard **80.65 %** (identical to MemoryCore's own figure), **sweep 100 %**; the four weak
classes: 0 % / 51.61 % / 51.61 % / **100 %**.  Cost: `1 + ceil(log2 W)` passes of `10 N`.  The 100 % applies to the enumerated
model population at the measured widths (8 and 32 columns); no claim is made beyond them.

## 3. First-failure signatures (derived by hand from the March definition)

Single fault, `ROWS = 16`, 8-bit words.  "r1" = the read expected 1.  Each row below is **asserted** by the testbench
(`tb_p1_march_one_bank`, section P1.3) and re-checked through the full top level (`tb_sf_sram_mbist`, S04).

| Injected fault | First failing element | Row / bit | Reasoning |
|---|---|---|---|
| SA0 (5,3) | 2 `U(r1,w0)` | 5 / 3, class `1TO0_BIT` | the cell never holds 1; element 1 only reads 0 |
| SA1 (5,3) | 1 `U(r0,w1)` | 5 / 3, class `0TO1_BIT` | the very first read of a 0 returns 1 |
| TF up (5,3) | 2 | 5 / 3, `1TO0_BIT` | `w1` in element 1 fails; element 2 reads 0 where 1 is expected |
| TF down (5,3) | 3 `D(r0,w1)` | 5 / 3, `0TO1_BIT` | the 1->0 write of element 2 fails; first re-read is element 3 |
| address (5) reaches no cell | 2 | 5, `ALL_BITS` | reads return 0; first read expecting 1 is element 2; every bit wrong; lowest bit 0, `bit_valid = 0` |
| alias 5 -> 9 | 1 | row 9 | row 5's `w1` lands in row 9; row 9's `r0` sees 1 |
| multi-access 5 + 9 | 1 | row 9 | same, row 5's writes also hit row 9 |
| CFin up (2,0) -> victim (7,0) | 1 | 7 / 0, `0TO1_BIT` | aggressor rises at row 2 (element 1); victim flips before its own `r0` |
| CFid up (2,0) -> victim (7,0) := 1 | 1 | 7 / 0 | same, victim forced to 1 |
| CFst aggressor = 1 -> victim reads 1 | 1 | 7 / 0 | aggressor = 1 after row 2; victim's `r0` returns 1 |

**Cross-model check.**  The same SA0 / SA1 signatures are produced when the faults come from MemoryCore's *own* simulation-only
fault models in the real `sf_sram_core` (`tb_mbist_memorycore`, M03): two independently written fault models agree.

## 4. Failure classification (symptom-based; never a claimed root cause)

| Class | Condition on the failing read |
|---|---|
| `1TO0_BIT` | exactly one bit, expected 1 read 0 - **stuck-at-0 OR up-transition fault**; March tests cannot separate them |
| `0TO1_BIT` | exactly one bit, expected 0 read 1 - stuck-at-1 OR down-transition fault |
| `MULTI_1TO0` / `MULTI_0TO1` / `MULTI_MIX` | >= 2 bits, all one direction / mixed |
| `ALL_BITS` | every compared bit wrong (data-line / read-path inversion, no-access decoder fault) |
| `ADDR_ALIAS` | `ADDR` pattern only, >= 2 bits: the observed word equals the pattern of **another** row (`alias_row`) |
| `in_check` (flag) | the single failing bit is an ECC check column (`bit >= DATA_W`) |

`bit_valid` = the syndrome has exactly one bit; otherwise `bit` is the **lowest** failing bit (mutant Q05 would be killed).  The
failing **operation** is reported as March element + operation index (+ expected polarity + background pass).  Expected and
observed words are the full compared word (masked by the column select).  A fault is *located* only for single-cell faults
(measured: 100 % at 4 x 8 and 4 x 32, `reports/coverage.md`); multi-cell fault classes give the **first** failing read, not a
location of the root cause.

## 5. Column selection (what is compared)

`ALL` (data + check columns, default), `DATA` (bits < `DATA_W`), `CHECK` (bits >= `DATA_W`; refused when no check columns exist).
All columns are always written; only the compare mask changes, so a data-only run still exercises the check columns' write path.

## 6. Which fault model is actually covered

Coverage is reported against the **enumerated model population** in `docs/04_fault_models.md` (SAF, TF, address decoder,
CFin / CFid / CFst), not "memory faults".  Not modelled and therefore **not claimed**: data-retention (no pause element exists),
read-disturb, write recovery, stuck-open, bit-line / sense-amplifier, neighbourhood pattern-sensitive, multi-cell and bridging
faults other than the listed ones, resistive and at-speed (timing) faults, soft errors, faults in the test logic itself.
