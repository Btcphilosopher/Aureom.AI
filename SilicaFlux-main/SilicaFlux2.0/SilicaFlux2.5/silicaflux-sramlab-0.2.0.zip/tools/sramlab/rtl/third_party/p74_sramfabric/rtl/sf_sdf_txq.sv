// =============================================================================
// SilicaFlux SRAMFabric :: sf_sdf_txq -- outstanding-transaction queue (one per controller port)
//
// Holds the metadata of every transaction that the SRAM controller has ACCEPTED and not yet answered, in acceptance
// order.  The controller answers one port in acceptance order (controller contract O2), so the head of this queue is
// always the transaction the next controller response belongs to.  It is used to
//   * cross-check the response sideband id (a mismatch is a bridge/controller protocol error),
//   * recognise an ORPHAN response (queue empty) instead of delivering it,
//   * time out the oldest transaction,
//   * complete every in-flight transaction with an error when the controller is flushed / reset,
//   * measure latency and occupancy.
// push when !full; pop when !empty; a push while full (ovf_o) or a pop while empty (udf_o) is an error the surrounding
// logic counts (neither can happen when DEPTH >= the controller's NSLOT, which sf_sdf_port checks at elaboration).
// Reset / clr_i clear the control state; the storage array is not reset.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_sdf_txq #(
  parameter int DEPTH = 8,
  parameter int EW    = 16,
  parameter int CW    = $clog2(DEPTH + 1),
  parameter int PW    = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          clr_i,
  input  wire logic          push_i,
  input  wire logic [EW-1:0] push_d,
  input  wire logic          pop_i,
  output logic [EW-1:0]      head_d,
  output logic [CW-1:0]      count_o,
  output logic               empty_o,
  output logic               full_o,
  output logic               ovf_o,
  output logic               udf_o
);
  logic [EW-1:0] mem [DEPTH];
  logic [PW-1:0] wp, rp;
  logic [CW-1:0] cnt;

  assign empty_o = (cnt == '0);
  assign full_o  = (cnt == CW'(DEPTH));
  assign count_o = cnt;
  assign head_d  = mem[rp];
  assign ovf_o   = push_i & full_o;
  assign udf_o   = pop_i & empty_o;

  wire do_push = push_i & ~full_o;
  wire do_pop  = pop_i & ~empty_o;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; cnt <= '0;
    end else if (clr_i) begin
      wp <= '0; rp <= '0; cnt <= '0;
    end else begin
      if (do_push) wp <= (wp == PW'(DEPTH - 1)) ? '0 : wp + 1'b1;
      if (do_pop)  rp <= (rp == PW'(DEPTH - 1)) ? '0 : rp + 1'b1;
      cnt <= cnt + CW'(do_push) - CW'(do_pop);
    end
  end

  always_ff @(posedge clk) begin
    if (do_push) mem[wp] <= push_d;
  end
endmodule

`default_nettype wire
