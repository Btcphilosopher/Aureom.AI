# 04 - Verification-only SRAM fault model

`verif/models/sf_mbist_fault_mem.sv` is a behavioural synchronous single-port SRAM (ROWS x W) with up to `NF` simultaneous, **explicitly
defined** faults.  It is **simulation only** (never synthesised) and exists to prove that the controller detects what it claims to.
Its raw port has the same timing as `sf_sram_core` / `sf_sram_bank`'s test port (read data exactly `READ_LATENCY` cycles after the
accepting edge, array never reset, poison pattern at time 0 so a test that depends on initial content fails).
`verif/models/sf_mbist_sram_sys.sv` wraps `NBANK` of them behind the `sf_sram_controller` handshake contract with a functional master
and scoreboard.

## 1. Fault definitions (the model IS these rules)

Type codes are the same numbers as MemoryCore's `SF_FT_*` (so a result can be compared with MemoryCore's own model).

| Code | Fault | Definition |
|---|---|---|
| 1 | SAF (stuck-at) | cell (row, bit) is stuck at `val`: reads return `val`; a write cannot change it |
| 2 | TF (transition) | `val = 1`: the 0->1 transition of cell (row, bit) fails (stays 0); `val = 0`: the 1->0 transition fails (stays 1) |
| 3 | AF no access | address `row` reaches **no cell**: writes are lost, reads return all zeros |
| 4 | AF alias | address `row` reaches only the cells of `row2` (its own cells are never accessed): reads and writes act on `row2` |
| 5 | AF multi-access | address `row` reaches its own row **and** `row2`: a write updates both; a read returns the wired-OR (`val = 0`) or wired-AND (`val = 1`) of both |
| 6 | CFin | a transition of the aggressor cell (row, bit) in direction `val` (1 = up, 0 = down) **inverts** the victim cell (row2, bit2) |
| 7 | CFid | the same trigger **forces** the victim to `val2` |
| 8 | CFst | while the aggressor cell holds `val`, a **read** of the victim cell returns `val2` (the stored value is untouched) |

Application rules: on a write to row *r* (after the address-decoder mapping) TF is evaluated against old vs. written value, then SAF
forces its bit, then the row is stored, then every coupling fault whose aggressor is a transitioning cell of that row acts on its
victim (a victim in the **same word overrides** the just-written value).  On a read: stored row, SAF, then the CFst view, then the AF
OR / AND.  Only **one** address-decoder fault per address; cell faults combine freely.

## 2. Explicit non-coverage

Not modelled, so **nothing is claimed** about them: data-retention faults (no pause / retention element exists in the controller),
read-disturb, write-recovery, stuck-open, bit-line and sense-amplifier faults, neighbourhood pattern-sensitive faults, multi-cell and
bridging defects other than listed, resistive defects and at-speed (timing) faults, soft errors, faults in the BIST logic itself.

## 3. How the model is validated (so a campaign cannot pass because of a model artefact)

1. **Theory**: with the model, March C- detects 100 % of SAF / TF / AF / inter-word coupling, MATS+ misses TF-down and half the coupling
   variants, a solid background cannot excite four same-word classes (`reports/coverage.md`) - the textbook results.
2. **Independent hand derivation**: ten single-fault first-failure signatures were derived on paper from the March definition before
   being asserted (`docs/02` section 3).
3. **Cross-model agreement**: MemoryCore's own `sf_sram_core` fault models (written by someone else, real RTL) give the same SA0 / SA1
   signatures and detect all of its eight fault types (`tb_mbist_memorycore`, M03 / M04).  At 4 rows x 32 bits, **solid U checkerboard
   same-word coupling = 32 000 / 39 680 = 80.65 %, exactly the number MemoryCore measured with its engine and model** (a different
   implementation producing the identical figure for an identical population).
4. **Mutation testing**: 39 / 41 injected RTL bugs are killed; the two survivors are explained equivalents (`reports/mutation.md`).

## 4. Statement on coverage

A limited simulation suite cannot establish complete fault coverage, and none is claimed.  The measured numbers describe an
*enumerated list of model faults on small instances* (4 x 8 and 4 x 32 cells), exhaustively.  They do not scale automatically to
other widths (the sweep's 100 % is shown at 8 and 32 columns), to other fault classes, or to silicon.
