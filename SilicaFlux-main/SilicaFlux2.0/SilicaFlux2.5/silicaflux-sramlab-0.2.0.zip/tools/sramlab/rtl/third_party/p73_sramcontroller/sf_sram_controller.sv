// =============================================================================
// SilicaFlux SRAMController (Project 73) :: sf_sram_controller      -- primary RTL
// Multi-master, multi-bank SRAM access controller: schedules requests from
// NUM_MASTERS masters onto NUM_BANKS single-port banks and returns exactly one
// response per accepted request.
// Aureom.AI | SilicaFlux Semiconductor Systems
//
// ---------------------------------------------------------------------------
// TRANSACTION INTERFACE (SFB2-compatible superset; full text docs/01)
//   master side, per master port m (flat vectors, slice m)
//     m_req_valid/ready  request handshake (SFB2 R1).  A request is ACCEPTED at the
//                        rising edge where valid && ready.  Acceptance == the cycle
//                        the bank access is issued: the array is read/written at that
//                        edge.  Errors need no bank and are accepted when the master
//                        can take a response.
//     m_req_we           1 write, 0 read
//     m_req_addr         BYTE address (SRAM-local offset), ADDR_WIDTH bits
//     m_req_wdata/wstrb  write data / byte strobes (don't care for reads)
//     m_req_id           request ID, echoed in the response (opaque; see ID_CHECK)
//     m_req_src          source ID, must equal the port index (see SRC_CHECK)
//     m_req_err          upstream poison flag: answered with SFC_ST_POISON, no side effect
//     m_rsp_valid/ready  response handshake; a response is COMPLETED at the edge where
//                        valid && ready.  A response is never dropped: it is held
//                        (payload stable) until the master takes it.
//     m_rsp_rdata/id/src/we/err/status   read data (0 for writes and errors), echoed
//                        ID, source, request type, 1-bit error, 4-bit SFC_ST_* status
//     src_en             per-port source enable (0 -> requests answered SFC_ST_SRC)
//     flush              soft reset: stop accepting, cancel everything in a bank
//     idle               no transaction outstanding anywhere
//   bank side, per bank b (flat vectors, slice b) -- the BANK CONTRACT
//     bk_req_valid/ready one access per cycle; the controller asserts valid only in
//                        cycles where ready is high, so bank-side requests are never
//                        stalled.  ready must not depend combinationally on valid.
//     bk_req_we/addr/wdata/wstrb   addr = ROW inside the bank
//     bk_rsp_valid/rdata/err       exactly one completion per accepted access, in
//                        acceptance order PER BANK, any latency >= 1, at most one per
//                        cycle, no back-pressure (the controller reserves space).
//
// ---------------------------------------------------------------------------
// ORDERING POLICY (docs/02)
//   per master : responses are returned IN REQUEST ORDER.  A master has up to MAX_OUT
//                transactions outstanding (default 1).  While a master still has
//                accesses inside a bank it may only issue to THAT bank (bank-lock), so
//                completions of one master can never overtake each other.
//   per bank   : accesses are performed and completed in acceptance order.
//   globally   : NOT ordered.  Masters on different banks progress independently;
//                a slow bank never delays a fast one; completions across masters and
//                banks may occur in any order.  Each response is matched to its
//                originating request by the per-bank tracking queue, never by timing.
//
// ARBITRATION (docs/02): independent round-robin per bank over the masters that are
//   ELIGIBLE for that bank (valid, error-free, credit, in-order rule, bank ready,
//   tracker space).  One grant per bank per cycle; different banks proceed in the same
//   cycle.  Optional two-class priority (PRIO_EN) with a starvation guard.
//
// Classification: SYNTHESIZABLE (embedded checkers excluded unless SFC_ASSERT)
// =============================================================================
`include "sf_sramc_defs.svh"
`default_nettype none

module sf_sram_controller #(
  parameter int          NUM_MASTERS = 4,
  parameter int          NUM_BANKS   = 4,            // power of two
  parameter int          DATA_WIDTH  = 32,           // bits, power-of-two number of bytes
  parameter int          BANK_DEPTH  = 1024,         // words per bank
  parameter int          ADDR_WIDTH  = 32,           // byte address width
  parameter int          ID_WIDTH    = 4,
  parameter int          MAX_OUT     = 1,            // outstanding transactions per master
  parameter int          BANK_OUT    = 4,            // max accesses in flight per bank (bank latency + 1 for full rate)
  parameter int          UNIFORM_LAT = 0,            // 1: ALL banks complete every access exactly the same fixed number of cycles after issue
                                                     //    => accesses of one master cannot overtake each other: the bank-lock rule is not needed
  parameter int          INTERLEAVE  = `SFC_ILV_LOW,
  parameter int          ID_CHECK    = 1,            // 1: reuse of an outstanding ID -> SFC_ST_ID
  parameter int          SRC_CHECK   = 1,            // 1: src must equal the port index
  parameter int          MASK_MODE   = `SFC_MASK_ANY,
  parameter int          PRIO_EN     = 0,
  parameter logic [15:0] HP_MASK     = 16'h0001,
  parameter int          HP_LIMIT    = 4,
  parameter int          PERF_EN     = 1,
  parameter int          CNT_W       = 32,
  localparam int NBYTE       = DATA_WIDTH / 8,
  localparam int OFF         = $clog2(NBYTE),
  localparam int BW          = (NUM_BANKS > 1) ? $clog2(NUM_BANKS) : 1,
  localparam int RAW         = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  localparam int MW          = (NUM_MASTERS > 1) ? $clog2(NUM_MASTERS) : 1,
  localparam int SRCW        = MW,
  localparam int OW          = $clog2(MAX_OUT + 1),
  localparam int OPW         = (MAX_OUT > 1) ? $clog2(MAX_OUT) : 1,
  localparam int TW          = $clog2(BANK_OUT + 1),
  localparam int NPERF       = 16 + 16 * NUM_MASTERS + 8 * NUM_BANKS,
  localparam int PSW         = $clog2(NPERF)
) (
  input  wire logic                              clk,
  input  wire logic                              rst_n,
  // ---------------- masters
  input  wire logic [NUM_MASTERS-1:0]            m_req_valid,
  output logic      [NUM_MASTERS-1:0]            m_req_ready,
  input  wire logic [NUM_MASTERS-1:0]            m_req_we,
  input  wire logic [NUM_MASTERS*ADDR_WIDTH-1:0] m_req_addr,
  input  wire logic [NUM_MASTERS*DATA_WIDTH-1:0] m_req_wdata,
  input  wire logic [NUM_MASTERS*NBYTE-1:0]      m_req_wstrb,
  input  wire logic [NUM_MASTERS*ID_WIDTH-1:0]   m_req_id,
  input  wire logic [NUM_MASTERS*SRCW-1:0]       m_req_src,
  input  wire logic [NUM_MASTERS-1:0]            m_req_err,
  output logic      [NUM_MASTERS-1:0]            m_rsp_valid,
  input  wire logic [NUM_MASTERS-1:0]            m_rsp_ready,
  output logic      [NUM_MASTERS*DATA_WIDTH-1:0] m_rsp_rdata,
  output logic      [NUM_MASTERS*ID_WIDTH-1:0]   m_rsp_id,
  output logic      [NUM_MASTERS*SRCW-1:0]       m_rsp_src,
  output logic      [NUM_MASTERS-1:0]            m_rsp_we,
  output logic      [NUM_MASTERS-1:0]            m_rsp_err,
  output logic      [NUM_MASTERS*4-1:0]          m_rsp_status,
  // ---------------- control / status
  input  wire logic [NUM_MASTERS-1:0]            src_en,
  input  wire logic                              flush,
  output logic                                   idle,
  output logic                                   sts_rsp_overflow,   // sticky: response FIFO overflow (unreachable; proven)
  output logic                                   sts_bank_proto,     // sticky: bank answered with nothing outstanding / tracker overflow
  // ---------------- banks
  output logic      [NUM_BANKS-1:0]              bk_req_valid,
  input  wire logic [NUM_BANKS-1:0]              bk_req_ready,
  output logic      [NUM_BANKS-1:0]              bk_req_we,
  output logic      [NUM_BANKS*RAW-1:0]          bk_req_addr,
  output logic      [NUM_BANKS*DATA_WIDTH-1:0]   bk_req_wdata,
  output logic      [NUM_BANKS*NBYTE-1:0]        bk_req_wstrb,
  input  wire logic [NUM_BANKS-1:0]              bk_rsp_valid,
  input  wire logic [NUM_BANKS*DATA_WIDTH-1:0]   bk_rsp_rdata,
  input  wire logic [NUM_BANKS-1:0]              bk_rsp_err,
  // ---------------- performance counters
  input  wire logic                              perf_clr,
  input  wire logic [PSW-1:0]                    perf_sel,
  output logic      [CNT_W-1:0]                  perf_val
);

  // ------------------------------------------------------------ configuration checks
  if (NUM_MASTERS < 1 || NUM_MASTERS > 16) begin : g_err_num_masters_not_1_to_16
    `SFC_CFG_FATAL("sf_sram_controller: NUM_MASTERS must be 1..16")
  end
  if (NUM_BANKS < 1 || NUM_BANKS > 16 || (NUM_BANKS & (NUM_BANKS - 1)) != 0) begin : g_err_num_banks_not_power_of_2_up_to_16
    `SFC_CFG_FATAL("sf_sram_controller: NUM_BANKS must be a power of two, 1..16")
  end
  if (DATA_WIDTH < 8 || (DATA_WIDTH % 8) != 0 || (NBYTE & (NBYTE - 1)) != 0 || NBYTE > 16) begin : g_err_data_width_not_pow2_bytes_8_to_128
    `SFC_CFG_FATAL("sf_sram_controller: DATA_WIDTH must be 8, 16, 32, 64 or 128")
  end
  if (BANK_DEPTH < 2) begin : g_err_bank_depth_lt_2
    `SFC_CFG_FATAL("sf_sram_controller: BANK_DEPTH must be >= 2")
  end
  if (INTERLEAVE != `SFC_ILV_LOW && INTERLEAVE != `SFC_ILV_HIGH) begin : g_err_unknown_interleave
    `SFC_CFG_FATAL("sf_sram_controller: unknown INTERLEAVE")
  end
  if (INTERLEAVE == `SFC_ILV_HIGH && (BANK_DEPTH & (BANK_DEPTH - 1)) != 0) begin : g_err_high_interleave_needs_pow2_bank_depth
    `SFC_CFG_FATAL("sf_sram_controller: INTERLEAVE=HIGH requires a power-of-two BANK_DEPTH")
  end
  if (MAX_OUT < 1 || MAX_OUT > 16) begin : g_err_max_out_not_1_to_16
    `SFC_CFG_FATAL("sf_sram_controller: MAX_OUT must be 1..16")
  end
  if (BANK_OUT < 1 || BANK_OUT > 32) begin : g_err_bank_out_not_1_to_32
    `SFC_CFG_FATAL("sf_sram_controller: BANK_OUT must be 1..32")
  end
  if (ID_WIDTH < 1 || ID_WIDTH > 16) begin : g_err_id_width_not_1_to_16
    `SFC_CFG_FATAL("sf_sram_controller: ID_WIDTH must be 1..16")
  end
  if (ADDR_WIDTH < 8 || ADDR_WIDTH > 32) begin : g_err_addr_width_not_8_to_32
    `SFC_CFG_FATAL("sf_sram_controller: ADDR_WIDTH must be 8..32")
  end
  if (MASK_MODE != `SFC_MASK_ANY && MASK_MODE != `SFC_MASK_ALIGNED) begin : g_err_unknown_mask_mode
    `SFC_CFG_FATAL("sf_sram_controller: unknown MASK_MODE")
  end
  if (UNIFORM_LAT != 0 && UNIFORM_LAT != 1) begin : g_err_uniform_lat_not_0_or_1
    `SFC_CFG_FATAL("sf_sram_controller: UNIFORM_LAT must be 0 or 1")
  end
  if (ID_CHECK != 0 && ID_CHECK != 1) begin : g_err_id_check_not_0_or_1
    `SFC_CFG_FATAL("sf_sram_controller: ID_CHECK must be 0 or 1")
  end
  if (SRC_CHECK != 0 && SRC_CHECK != 1) begin : g_err_src_check_not_0_or_1
    `SFC_CFG_FATAL("sf_sram_controller: SRC_CHECK must be 0 or 1")
  end
  if (PERF_EN != 0 && PERF_EN != 1) begin : g_err_perf_en_not_0_or_1
    `SFC_CFG_FATAL("sf_sram_controller: PERF_EN must be 0 or 1")
  end

  localparam int TOTAL_WORDS = NUM_BANKS * BANK_DEPTH;
  localparam int TOTAL_BYTES = TOTAL_WORDS * NBYTE;
  if (TOTAL_BYTES < 1 || (ADDR_WIDTH < 31 && TOTAL_BYTES > (1 << ADDR_WIDTH))) begin : g_err_capacity_exceeds_address_space
    `SFC_CFG_FATAL("sf_sram_controller: capacity (NUM_BANKS*BANK_DEPTH*DATA_WIDTH/8 bytes) exceeds the address space")
  end
  localparam logic [ADDR_WIDTH:0] TOTAL_W = (ADDR_WIDTH+1)'(TOTAL_BYTES);

  localparam int RSP_W = DATA_WIDTH + ID_WIDTH + 1 + 4;   // {rdata, we, id, status}
  localparam int TRK_W = MW + ID_WIDTH + 1;               // {master, id, we}

  /* verilator lint_off SYNCASYNCNET */
  logic live;
  assign live = rst_n;     // rst_n is released synchronously: an ordinary qualifier (no accept during reset)

  /* verilator lint_on SYNCASYNCNET */
  // ------------------------------------------------------------ strobe support check
  function automatic logic mask_ok(input logic [NBYTE-1:0] w);
    logic [NBYTE-1:0] pat;
    logic             ok;
    ok = 1'b0;
    for (int s = 1; s <= NBYTE; s = s * 2) begin
      for (int p = 0; p < NBYTE; p = p + s) begin
        pat = '0;
        for (int k = 0; k < s; k++) pat[p + k] = 1'b1;
        if (w == pat) ok = 1'b1;
      end
    end
    mask_ok = ok;
  endfunction

  // ------------------------------------------------------------ per-master state
  logic [OW-1:0]          cnt_q   [NUM_MASTERS];    // accepted, response not yet transferred (<= MAX_OUT)
  logic [OW-1:0]          bf_q    [NUM_MASTERS];    // of which still inside a bank
  logic [BW-1:0]          lkb_q   [NUM_MASTERS];    // bank holding them (valid while bf_q != 0)
  logic [OPW-1:0]         oh_q    [NUM_MASTERS];    // order queue head / tail (outstanding IDs in request order)
  logic [OPW-1:0]         ot_q    [NUM_MASTERS];
  logic [MAX_OUT-1:0]     oq_v_q  [NUM_MASTERS];
  logic [ID_WIDTH-1:0]    oq_id_q [NUM_MASTERS*MAX_OUT];
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_MASTERS*MAX_OUT-1:0] oq_we_q;        // request type of outstanding transactions (checkers only)
  /* verilator lint_on UNUSEDSIGNAL */

  // response FIFO (one per master, DEPTH = MAX_OUT: credit == space, overflow impossible)
  logic [NUM_MASTERS-1:0]         rf_push, rf_empty, rf_ovf, rf_udf, rf_pop;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_MASTERS-1:0]         rf_full;                  // observed by the embedded checkers only
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NUM_MASTERS*RSP_W-1:0]   rf_pdata, rf_head;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_MASTERS*OW-1:0]      rf_count;
  /* verilator lint_on UNUSEDSIGNAL */

  // per-bank tracker (in-flight accesses in acceptance order) and cancel counter
  logic [NUM_BANKS-1:0]           tk_push, tk_pop, tk_empty, tk_full, tk_ovf, tk_udf;
  logic [NUM_BANKS*TRK_W-1:0]     tk_pdata, tk_head;
  logic [NUM_BANKS*TW-1:0]        tk_count;
  logic [TW-1:0]                  cx_q    [NUM_BANKS];   // oldest cx_q entries of the tracker are cancelled

  logic                           sts_ovf_q, sts_proto_q;

  // ------------------------------------------------------------ decode / checks (per master, combinational)
  logic [NUM_MASTERS-1:0] d_inrng, d_aln, d_mskbad, d_srcbad, d_idhit, d_err;
  logic [3:0]             d_st   [NUM_MASTERS];
  logic [BW-1:0]          d_bank [NUM_MASTERS];
  logic [RAW-1:0]         d_row  [NUM_MASTERS];
  logic [ADDR_WIDTH-1:0]  d_word [NUM_MASTERS];
  logic [NUM_MASTERS-1:0] pop_now, can_take, bank_ok, e_vb, e_bank, e_err, ord_stall;
  assign pop_now = ~rf_empty & m_rsp_ready;      // a response is transferred this cycle

  always_comb begin
    for (int m = 0; m < NUM_MASTERS; m++) begin
      d_word[m]   = m_req_addr[m*ADDR_WIDTH +: ADDR_WIDTH] >> OFF;
      d_inrng[m]  = ({1'b0, m_req_addr[m*ADDR_WIDTH +: ADDR_WIDTH]} < TOTAL_W);
      d_aln[m]    = ((m_req_addr[m*ADDR_WIDTH +: ADDR_WIDTH] & ADDR_WIDTH'(NBYTE - 1)) == '0);
      d_mskbad[m] = m_req_we[m] && ((m_req_wstrb[m*NBYTE +: NBYTE] == '0) ||
                                    (MASK_MODE == `SFC_MASK_ALIGNED && !mask_ok(m_req_wstrb[m*NBYTE +: NBYTE])));
      d_srcbad[m] = !src_en[m] || ((SRC_CHECK != 0) && (m_req_src[m*SRCW +: SRCW] != SRCW'(m)));
      // ID reuse: an outstanding transaction of this master carries the same ID.  The entry
      // whose response is being transferred in this very cycle no longer counts.
      d_idhit[m]  = 1'b0;
      if (ID_CHECK != 0) begin
        for (int k = 0; k < MAX_OUT; k++)
          if (oq_v_q[m][k] && !(pop_now[m] && oh_q[m] == OPW'(k)) &&
              oq_id_q[m*MAX_OUT + k] == m_req_id[m*ID_WIDTH +: ID_WIDTH])
            d_idhit[m] = 1'b1;
      end
      // status, precedence SRC > POISON > ID > RANGE > ALIGN > MASK
      d_st[m] = `SFC_ST_OK;
      if (d_mskbad[m])  d_st[m] = `SFC_ST_MASK;
      if (!d_aln[m])    d_st[m] = `SFC_ST_ALIGN;
      if (!d_inrng[m])  d_st[m] = `SFC_ST_RANGE;
      if (d_idhit[m])   d_st[m] = `SFC_ST_ID;
      if (m_req_err[m]) d_st[m] = `SFC_ST_POISON;
      if (d_srcbad[m])  d_st[m] = `SFC_ST_SRC;
      d_err[m] = (d_st[m] != `SFC_ST_OK);
      // bank / row
      if (NUM_BANKS == 1) begin
        d_bank[m] = '0;
        d_row[m]  = RAW'(d_word[m]);
      end else if (INTERLEAVE == `SFC_ILV_LOW) begin
        d_bank[m] = BW'(d_word[m]);
        d_row[m]  = RAW'(d_word[m] >> BW);
      end else begin
        d_bank[m] = BW'(d_word[m] >> RAW);
        d_row[m]  = RAW'(d_word[m]);
      end
    end
  end

  // ------------------------------------------------------------ eligibility
  // can_take : the master has a free outstanding slot (a response transferred this cycle frees one)
  // bank_ok  : in-order rule -- nothing of this master is inside a bank, or it is the same bank
  logic [NUM_MASTERS*NUM_BANKS-1:0] elig_flat;     // [b*NUM_MASTERS + m]
  always_comb begin
    for (int m = 0; m < NUM_MASTERS; m++) begin
      can_take[m]  = (cnt_q[m] != OW'(MAX_OUT)) || pop_now[m];
      bank_ok[m]   = (UNIFORM_LAT != 0) || (bf_q[m] == '0) || (lkb_q[m] == d_bank[m]);
      e_vb[m]      = m_req_valid[m] && live && !flush && !d_err[m] && can_take[m];
      e_bank[m]    = e_vb[m] && bank_ok[m];
      ord_stall[m] = e_vb[m] && !bank_ok[m];
      // an error response may only be queued once everything older is already in the response FIFO
      e_err[m]     = m_req_valid[m] && live && !flush && d_err[m] && can_take[m] && (bf_q[m] == '0);
    end
    for (int b = 0; b < NUM_BANKS; b++)
      for (int m = 0; m < NUM_MASTERS; m++)
        elig_flat[b*NUM_MASTERS + m] = e_bank[m] && (d_bank[m] == BW'(b)) && bk_req_ready[b] && !tk_full[b];
  end

  // ------------------------------------------------------------ per-bank arbitration
  logic [NUM_BANKS*NUM_MASTERS-1:0] gnt_flat;
  logic [NUM_BANKS-1:0]             gany;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_BANKS*MW-1:0]          gidx_unused;
  /* verilator lint_on UNUSEDSIGNAL */
  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_arb
    sf_sramc_arb #(.N(NUM_MASTERS), .PRIO_EN(PRIO_EN), .HP_MASK(HP_MASK), .HP_LIMIT(HP_LIMIT)) u_arb (
      .clk(clk), .rst_n(rst_n),
      .req(elig_flat[b*NUM_MASTERS +: NUM_MASTERS]),
      .grant(gnt_flat[b*NUM_MASTERS +: NUM_MASTERS]),
      .grant_idx(gidx_unused[b*MW +: MW]),
      .any(gany[b])
    );
  end

  // ------------------------------------------------------------ issue to the banks + tracker push
  logic [NUM_MASTERS-1:0] acc_bank, acc_any;
  always_comb begin
    for (int b = 0; b < NUM_BANKS; b++) begin
      bk_req_valid[b]                         = gany[b];
      bk_req_we[b]                            = 1'b0;
      bk_req_addr[b*RAW +: RAW]               = '0;
      bk_req_wdata[b*DATA_WIDTH +: DATA_WIDTH] = '0;
      bk_req_wstrb[b*NBYTE +: NBYTE]          = '0;
      tk_pdata[b*TRK_W +: TRK_W]              = '0;
      for (int m = 0; m < NUM_MASTERS; m++) begin
        if (gnt_flat[b*NUM_MASTERS + m]) begin
          bk_req_we[b]                             = m_req_we[m];
          bk_req_addr[b*RAW +: RAW]                = d_row[m];
          bk_req_wdata[b*DATA_WIDTH +: DATA_WIDTH] = m_req_wdata[m*DATA_WIDTH +: DATA_WIDTH];
          bk_req_wstrb[b*NBYTE +: NBYTE]           = m_req_wstrb[m*NBYTE +: NBYTE];
          tk_pdata[b*TRK_W +: TRK_W]               = {MW'(m), m_req_id[m*ID_WIDTH +: ID_WIDTH], m_req_we[m]};
        end
      end
      tk_push[b] = gany[b];
    end
    for (int m = 0; m < NUM_MASTERS; m++) begin
      acc_bank[m]  = 1'b0;
      for (int b = 0; b < NUM_BANKS; b++)
        if (gnt_flat[b*NUM_MASTERS + m]) acc_bank[m] = 1'b1;
      acc_any[m]   = acc_bank[m] || e_err[m];
      m_req_ready[m] = acc_any[m];
    end
  end

  // ------------------------------------------------------------ bank responses -> response entries
  logic [NUM_BANKS-1:0]            b_v;                    // a bank completion is matched with the tracker head
  logic [MW-1:0]                   b_m   [NUM_BANKS];
  logic [RSP_W-1:0]                b_ent [NUM_BANKS];
  logic [NUM_MASTERS-1:0]          bank_push;
  logic [NUM_MASTERS*RSP_W-1:0]    bank_ent;

  always_comb begin
    for (int b = 0; b < NUM_BANKS; b++) begin
      logic [MW-1:0]       h_m;
      logic [ID_WIDTH-1:0] h_id;
      logic                h_we;
      logic [3:0]          st;
      logic [DATA_WIDTH-1:0] dat;
      {h_m, h_id, h_we} = tk_head[b*TRK_W +: TRK_W];
      b_v[b] = bk_rsp_valid[b] && !tk_empty[b];
      st = `SFC_ST_OK;
      if (bk_rsp_err[b])    st = `SFC_ST_BANK;
      if (cx_q[b] != '0)    st = `SFC_ST_CANCEL;
      dat = (h_we || st != `SFC_ST_OK) ? {DATA_WIDTH{1'b0}} : bk_rsp_rdata[b*DATA_WIDTH +: DATA_WIDTH];
      b_m[b]   = h_m;
      b_ent[b] = {dat, h_we, h_id, st};
      tk_pop[b] = b_v[b];
    end
    for (int m = 0; m < NUM_MASTERS; m++) begin
      bank_push[m]   = 1'b0;
      bank_ent[m*RSP_W +: RSP_W] = '0;
      for (int b = 0; b < NUM_BANKS; b++) begin
        if (b_v[b] && b_m[b] == MW'(m)) begin
          bank_push[m] = 1'b1;
          bank_ent[m*RSP_W +: RSP_W] = bank_ent[m*RSP_W +: RSP_W] | b_ent[b];
        end
      end
    end
  end

  // ------------------------------------------------------------ response FIFOs (per master)
  always_comb begin
    for (int m = 0; m < NUM_MASTERS; m++) begin
      rf_push[m] = bank_push[m] || e_err[m];
      if (e_err[m])
        rf_pdata[m*RSP_W +: RSP_W] = {{DATA_WIDTH{1'b0}}, m_req_we[m], m_req_id[m*ID_WIDTH +: ID_WIDTH], d_st[m]};
      else
        rf_pdata[m*RSP_W +: RSP_W] = bank_ent[m*RSP_W +: RSP_W];
      rf_pop[m]  = pop_now[m];
    end
  end

  for (genvar m = 0; m < NUM_MASTERS; m++) begin : g_rf
    sf_sramc_fifo #(.WIDTH(RSP_W), .DEPTH(MAX_OUT)) u_rf (
      .clk(clk), .rst_n(rst_n),
      .push(rf_push[m]), .push_data(rf_pdata[m*RSP_W +: RSP_W]),
      .pop(rf_pop[m]), .pop_data(rf_head[m*RSP_W +: RSP_W]),
      .empty(rf_empty[m]), .full(rf_full[m]), .count(rf_count[m*OW +: OW]),
      .overflow(rf_ovf[m]), .underflow(rf_udf[m])
    );
  end

  always_comb begin
    for (int m = 0; m < NUM_MASTERS; m++) begin
      m_rsp_valid[m]                          = !rf_empty[m];
      m_rsp_status[m*4 +: 4]                  = rf_head[m*RSP_W +: 4];
      m_rsp_id[m*ID_WIDTH +: ID_WIDTH]        = rf_head[m*RSP_W + 4 +: ID_WIDTH];
      m_rsp_we[m]                             = rf_head[m*RSP_W + 4 + ID_WIDTH];
      m_rsp_rdata[m*DATA_WIDTH +: DATA_WIDTH] = rf_head[m*RSP_W + 5 + ID_WIDTH +: DATA_WIDTH];
      m_rsp_err[m]                            = (rf_head[m*RSP_W +: 4] != `SFC_ST_OK);
      m_rsp_src[m*SRCW +: SRCW]               = SRCW'(m);
    end
  end

  // ------------------------------------------------------------ per-bank trackers
  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_tk
    sf_sramc_fifo #(.WIDTH(TRK_W), .DEPTH(BANK_OUT)) u_tk (
      .clk(clk), .rst_n(rst_n),
      .push(tk_push[b]), .push_data(tk_pdata[b*TRK_W +: TRK_W]),
      .pop(tk_pop[b]), .pop_data(tk_head[b*TRK_W +: TRK_W]),
      .empty(tk_empty[b]), .full(tk_full[b]), .count(tk_count[b*TW +: TW]),
      .overflow(tk_ovf[b]), .underflow(tk_udf[b])
    );
  end

  // ------------------------------------------------------------ state update
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int m = 0; m < NUM_MASTERS; m++) begin
        cnt_q[m]  <= '0;
        bf_q[m]   <= '0;
        lkb_q[m]  <= '0;
        oh_q[m]   <= '0;
        ot_q[m]   <= '0;
        oq_v_q[m] <= '0;
      end
      for (int b = 0; b < NUM_BANKS; b++) cx_q[b] <= '0;
      sts_ovf_q   <= 1'b0;
      sts_proto_q <= 1'b0;
    end else begin
      for (int m = 0; m < NUM_MASTERS; m++) begin
        // outstanding / in-bank counters
        if (acc_any[m] && !pop_now[m])      cnt_q[m] <= cnt_q[m] + 1'b1;
        else if (!acc_any[m] && pop_now[m]) cnt_q[m] <= cnt_q[m] - 1'b1;
        if (acc_bank[m] && !bank_push[m])      bf_q[m] <= bf_q[m] + 1'b1;
        else if (!acc_bank[m] && bank_push[m]) bf_q[m] <= bf_q[m] - 1'b1;
        if (acc_bank[m]) begin
          for (int b = 0; b < NUM_BANKS; b++)
            if (gnt_flat[b*NUM_MASTERS + m]) lkb_q[m] <= BW'(b);
        end
        // order queue: IDs of outstanding transactions in request order
        if (pop_now[m]) begin
          oq_v_q[m][oh_q[m]] <= 1'b0;
          oh_q[m] <= (oh_q[m] == OPW'(MAX_OUT - 1)) ? '0 : oh_q[m] + 1'b1;
        end
        if (acc_any[m]) begin
          oq_v_q[m][ot_q[m]] <= 1'b1;
          ot_q[m] <= (ot_q[m] == OPW'(MAX_OUT - 1)) ? '0 : ot_q[m] + 1'b1;
        end
      end
      // cancel counters: on flush every access still inside the bank is cancelled
      for (int b = 0; b < NUM_BANKS; b++) begin
        if (flush)                              cx_q[b] <= tk_count[b*TW +: TW] - (tk_pop[b] ? TW'(1) : TW'(0));
        else if (tk_pop[b] && cx_q[b] != '0)    cx_q[b] <= cx_q[b] - 1'b1;
      end
      if (|rf_ovf || |rf_udf)                     sts_ovf_q   <= 1'b1;
      if (|tk_ovf || |tk_udf || |(bk_rsp_valid & tk_empty)) sts_proto_q <= 1'b1;
    end
  end

  // order-queue payload (no reset: validity is carried by oq_v_q)
  always_ff @(posedge clk) begin
    for (int m = 0; m < NUM_MASTERS; m++) begin
      if (acc_any[m]) begin
        oq_id_q[m*MAX_OUT + 32'(ot_q[m])] <= m_req_id[m*ID_WIDTH +: ID_WIDTH];
        oq_we_q[m*MAX_OUT + 32'(ot_q[m])] <= m_req_we[m];
      end
    end
  end

  assign sts_rsp_overflow = sts_ovf_q;
  assign sts_bank_proto   = sts_proto_q;

  always_comb begin
    idle = 1'b1;
    for (int m = 0; m < NUM_MASTERS; m++)
      if (cnt_q[m] != '0) idle = 1'b0;
  end

  // ------------------------------------------------------------ performance counters
  if (PERF_EN != 0) begin : g_perf
    logic [NUM_MASTERS-1:0]         p_rsp_we, p_rsp_err, p_rsp_cancel;
    logic [NUM_MASTERS*OW-1:0]      p_out;
    logic [NUM_BANKS-1:0]           p_busy;
    always_comb begin
      for (int m = 0; m < NUM_MASTERS; m++) begin
        p_rsp_we[m]     = m_rsp_we[m];
        p_rsp_err[m]    = m_rsp_err[m];
        p_rsp_cancel[m] = (m_rsp_status[m*4 +: 4] == `SFC_ST_CANCEL);
        p_out[m*OW +: OW] = cnt_q[m];
      end
      for (int b = 0; b < NUM_BANKS; b++) p_busy[b] = !tk_empty[b];
    end
    sf_sramc_perf #(.NUM_MASTERS(NUM_MASTERS), .NUM_BANKS(NUM_BANKS), .CNT_W(CNT_W), .OUT_W(OW)) u_perf (
      .clk(clk), .rst_n(rst_n), .perf_clr(perf_clr), .perf_sel(perf_sel), .perf_val(perf_val),
      .p_req_valid(m_req_valid), .p_req_ready(m_req_ready),
      .p_rsp_valid(m_rsp_valid), .p_rsp_ready(m_rsp_ready),
      .p_rsp_we(p_rsp_we), .p_rsp_err(p_rsp_err), .p_rsp_cancel(p_rsp_cancel),
      .p_order_stall(ord_stall), .p_out(p_out),
      .p_issue(bk_req_valid), .p_issue_we(bk_req_we), .p_busy(p_busy), .p_elig(elig_flat)
    );
  end else begin : g_noperf
    assign perf_val = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire noperf_unused = &{1'b0, perf_clr, perf_sel, ord_stall};    // counters compiled out
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // ------------------------------------------------------------ embedded checkers
`ifdef SFC_ASSERT
  /* verilator lint_off SYNCASYNCNET */
  // ---- environment obligations (assume in formal, $error in simulation)
  logic [NUM_MASTERS-1:0]              pr_v, pr_rdy, pr_we, pr_err;
  logic [NUM_MASTERS*ADDR_WIDTH-1:0]   pr_addr;
  logic [NUM_MASTERS*DATA_WIDTH-1:0]   pr_wdata;
  logic [NUM_MASTERS*NBYTE-1:0]        pr_wstrb;
  logic [NUM_MASTERS*ID_WIDTH-1:0]     pr_id;
  logic [NUM_MASTERS*SRCW-1:0]         pr_src;
  logic [NUM_MASTERS-1:0]              ps_v, ps_rdy;
  logic [NUM_MASTERS*RSP_W-1:0]        ps_pl;
  logic                                pr_valid_q;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pr_v <= '0; pr_rdy <= '0; ps_v <= '0; ps_rdy <= '0; pr_valid_q <= 1'b0;
      pr_we <= '0; pr_err <= '0; pr_addr <= '0; pr_wdata <= '0; pr_wstrb <= '0; pr_id <= '0; pr_src <= '0; ps_pl <= '0;
    end else begin
      pr_valid_q <= 1'b1;
      pr_v <= m_req_valid; pr_rdy <= m_req_ready; pr_we <= m_req_we; pr_err <= m_req_err;
      pr_addr <= m_req_addr; pr_wdata <= m_req_wdata; pr_wstrb <= m_req_wstrb; pr_id <= m_req_id; pr_src <= m_req_src;
      ps_v <= m_rsp_valid; ps_rdy <= m_rsp_ready; ps_pl <= rf_head;
    end
  end

  always @(posedge clk) begin
    if (rst_n && pr_valid_q) begin
      for (int m = 0; m < NUM_MASTERS; m++) begin
`ifndef SFC_NO_STABILITY
        // R2: a presented request stays, unchanged, until accepted (master obligation)
        if (pr_v[m] && !pr_rdy[m]) begin
          `SFC_ASM(m_req_valid[m], "master withdrew a request before it was accepted (SFB2 R2)")
          `SFC_ASM(m_req_we[m] == pr_we[m] && m_req_addr[m*ADDR_WIDTH +: ADDR_WIDTH] == pr_addr[m*ADDR_WIDTH +: ADDR_WIDTH] &&
                   m_req_id[m*ID_WIDTH +: ID_WIDTH] == pr_id[m*ID_WIDTH +: ID_WIDTH] &&
                   m_req_src[m*SRCW +: SRCW] == pr_src[m*SRCW +: SRCW] && m_req_err[m] == pr_err[m],
                   "request control fields changed while waiting for acceptance (SFB2 R2)")
          if (pr_we[m])
            `SFC_ASM(m_req_wdata[m*DATA_WIDTH +: DATA_WIDTH] == pr_wdata[m*DATA_WIDTH +: DATA_WIDTH] &&
                     m_req_wstrb[m*NBYTE +: NBYTE] == pr_wstrb[m*NBYTE +: NBYTE],
                     "write data/strobes changed while waiting for acceptance (SFB2 R2)")
        end
`endif
      end
    end
  end

  // bank contract: a completion only for an access that is outstanding (no history needed: valid from the first cycle after reset)
  always @(posedge clk) begin
    if (rst_n) begin
      for (int b = 0; b < NUM_BANKS; b++)
        `SFC_ASM(!(bk_rsp_valid[b] && tk_empty[b]), "bank completed an access that was never issued (bank contract)")
    end
  end

  // ---- design properties
  always @(posedge clk) begin
    if (rst_n && pr_valid_q) begin
      for (int b = 0; b < NUM_BANKS; b++) begin
        // no bank double-booking: at most one grant per bank, only to an eligible master
        `SFC_CHK(((gnt_flat[b*NUM_MASTERS +: NUM_MASTERS] & ~elig_flat[b*NUM_MASTERS +: NUM_MASTERS]) == '0), "grant without eligibility")
        `SFC_CHK((gnt_flat[b*NUM_MASTERS +: NUM_MASTERS] & (gnt_flat[b*NUM_MASTERS +: NUM_MASTERS] - 1'b1)) == '0, "bank granted to two masters in one cycle")
        `SFC_CHK(!bk_req_valid[b] || (bk_req_ready[b] && !tk_full[b]), "bank access issued while bank not ready / tracker full")
        `SFC_CHK(!tk_ovf[b] && !tk_udf[b], "tracker overflow/underflow")
        `SFC_CHK(tk_count[b*TW +: TW] <= TW'(BANK_OUT), "tracker count above BANK_OUT")
        `SFC_CHK(cx_q[b] <= tk_count[b*TW +: TW], "cancel counter above tracker count")
      end
      for (int m = 0; m < NUM_MASTERS; m++) begin
        /* verilator lint_off CMPCONST */
        `SFC_CHK(cnt_q[m] <= OW'(MAX_OUT), "outstanding count above MAX_OUT")
        /* verilator lint_on CMPCONST */
        `SFC_CHK(bf_q[m] <= cnt_q[m], "in-bank count above outstanding count")
        `SFC_CHK(!rf_ovf[m] && !rf_udf[m], "response FIFO overflow/underflow: a response was dropped")
        `SFC_CHK(rf_count[m*OW +: OW] + bf_q[m] <= cnt_q[m], "response space reservation violated (FIFO + in-bank > outstanding)")
        `SFC_CHK(!(bank_push[m] && e_err[m]), "bank response and error response pushed to one master in one cycle")
        `SFC_CHK(!(m_req_valid[m] && m_req_ready[m] && flush), "request accepted during flush")
        `SFC_CHK(!(m_req_valid[m] && m_req_ready[m] && !live), "request accepted during reset")
        `SFC_CHK(!(acc_bank[m] && e_err[m]), "request accepted as both a bank access and an error")
        `SFC_CHK(!acc_bank[m] || (UNIFORM_LAT != 0) || (bf_q[m] == '0 || lkb_q[m] == d_bank[m]), "in-order rule violated: issue to a second bank while accesses are in flight")
        // correct routing / ordering: the response at the head is the oldest outstanding request of this master
        if (!rf_empty[m]) begin
          `SFC_CHK(cnt_q[m] != '0, "response present with no outstanding transaction")
          `SFC_CHK(oq_v_q[m][oh_q[m]], "response head has no order-queue entry")
          `SFC_CHK(m_rsp_id[m*ID_WIDTH +: ID_WIDTH] == oq_id_q[m*MAX_OUT + 32'(oh_q[m])], "response ID differs from the oldest outstanding request ID (misrouted/reordered)")
          `SFC_CHK(m_rsp_we[m] == oq_we_q[m*MAX_OUT + 32'(oh_q[m])], "response type differs from the oldest outstanding request type")
        end
        // response stability under back-pressure (SFB2 R4)
        if (ps_v[m] && !ps_rdy[m]) begin
          `SFC_CHK(m_rsp_valid[m], "response withdrawn before it was accepted")
          `SFC_CHK(rf_head[m*RSP_W +: RSP_W] == ps_pl[m*RSP_W +: RSP_W], "response payload changed while held")
        end
        // bank responses of one master never arrive from two banks in one cycle
        begin : blk_one_bank
          int n;
          n = 0;
          for (int b = 0; b < NUM_BANKS; b++)
            if (b_v[b] && b_m[b] == MW'(m)) n = n + 1;
          `SFC_CHK(n <= 1, "two banks completed for the same master in one cycle")
        end
      end
      `SFC_CHK(!sts_ovf_q && !sts_proto_q, "sticky error status set")
    end
  end

  // ---- fairness of the composed system: a master that stays ELIGIBLE for a bank is granted after at most
  //      `bound` grants to others (bound from the arbiter's documented guarantee, see sf_sramc_arb.sv)
  /* verilator lint_off UNUSEDSIGNAL */
  function automatic int fair_bound(input int mm);
    int nh, nl;
    nh = 0; nl = 0;
    for (int k = 0; k < NUM_MASTERS; k++) begin
      if (PRIO_EN != 0 && HP_MASK[k]) nh = nh + 1; else nl = nl + 1;
    end
    if (PRIO_EN == 0)         fair_bound = NUM_MASTERS - 1;
    else if (HP_MASK[mm])     fair_bound = (nh - 1) + 1 + (nh - 1) / HP_LIMIT;
    else                      fair_bound = (nl - 1) + HP_LIMIT * nl;
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */
  logic [7:0] fw_q [NUM_BANKS*NUM_MASTERS];
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NUM_BANKS*NUM_MASTERS; i++) fw_q[i] <= 8'd0;
    end else begin
      for (int b = 0; b < NUM_BANKS; b++) begin
        for (int m = 0; m < NUM_MASTERS; m++) begin
          if (elig_flat[b*NUM_MASTERS + m] && !gnt_flat[b*NUM_MASTERS + m]) begin
            `SFC_CHK(32'(fw_q[b*NUM_MASTERS + m]) < fair_bound(m), "fairness: eligible master waited more than the arbiter bound")
            fw_q[b*NUM_MASTERS + m] <= fw_q[b*NUM_MASTERS + m] + 8'd1;
          end else begin
            fw_q[b*NUM_MASTERS + m] <= 8'd0;
          end
        end
        // work conserving: some eligible master => some grant
        `SFC_CHK((elig_flat[b*NUM_MASTERS +: NUM_MASTERS] == '0) == !gany[b], "bank idle although a master is eligible (not work conserving)")
      end
    end
  end
  /* verilator lint_on SYNCASYNCNET */
`endif

endmodule

`default_nettype wire
