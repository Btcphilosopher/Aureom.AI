// =============================================================================
// SilicaFlux SRAMController (Project 73) :: sf_sramc_txn   -- common transaction structure (reference)
//
// The synthesizable RTL (sf_sram_controller & co.) uses FLAT PORTS because the repository's house rules (and Yosys 0.33) forbid
// interfaces / structs / packages in synthesizable modules.  This file is the same transaction as ONE typed object, for testbenches,
// verification components and higher-level models:
//
//   sfc_req_t   {we, addr(byte), wdata, wstrb, req_id, src, err}            -- "request error status" = upstream poison
//   sfc_rsp_t   {rdata, id, src, we, err, status}                           -- status = SFC_ST_* (sf_sramc_defs.svh)
//   sf_sramc_if request channel (valid/ready) + response channel (valid/ready), master / slave / monitor modports,
//               and a protocol checker for the SFB2 rules the controller relies on (simulation only):
//                 R2  a presented request stays unchanged until accepted        R4  a response not taken stays unchanged
//                 R5  no response without a request outstanding (counted)       status/err consistency, no X on controls
// Classification: VERIFICATION / SIMULATION ONLY (not for synthesis).
// =============================================================================
`default_nettype none

package sf_sramc_txn_pkg;
  typedef enum logic [3:0] {
    SFC_OK = 4'd0, SFC_RANGE = 4'd1, SFC_ALIGN = 4'd2, SFC_MASK = 4'd3, SFC_SRC = 4'd4,
    SFC_ID = 4'd5, SFC_POISON = 4'd6, SFC_CANCEL = 4'd7, SFC_BANK = 4'd8
  } sfc_status_e;

  // widths are fixed here for the default SoC configuration (32-bit address, 32-bit data, 4-bit ID, 2-bit source);
  // use the parameterised interface below for other widths
  typedef struct packed {
    logic [1:0]  src;
    logic [3:0]  id;
    logic        err;
    logic [3:0]  wstrb;
    logic [31:0] wdata;
    logic [31:0] addr;
    logic        we;
  } sfc_req_t;

  typedef struct packed {
    sfc_status_e status;
    logic        err;
    logic        we;
    logic [1:0]  src;
    logic [3:0]  id;
    logic [31:0] rdata;
  } sfc_rsp_t;
endpackage

interface sf_sramc_if #(
  parameter int AW   = 32,
  parameter int DW   = 32,
  parameter int IDW  = 4,
  parameter int SRCW = 2
) (
  input wire logic clk,
  input wire logic rst_n
);
  /* verilator lint_off UNDRIVEN */
  /* verilator lint_off UNUSEDSIGNAL */
  // request channel
  logic             req_valid, req_ready, req_we, req_err;
  logic [AW-1:0]    req_addr;
  logic [DW-1:0]    req_wdata;
  logic [DW/8-1:0]  req_wstrb;
  logic [IDW-1:0]   req_id;
  logic [SRCW-1:0]  req_src;
  // response channel
  logic             rsp_valid, rsp_ready, rsp_we, rsp_err;
  logic [DW-1:0]    rsp_rdata;
  logic [IDW-1:0]   rsp_id;
  logic [SRCW-1:0]  rsp_src;
  logic [3:0]       rsp_status;

  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_on UNDRIVEN */

  modport master  (output req_valid, req_we, req_addr, req_wdata, req_wstrb, req_id, req_src, req_err, rsp_ready,
                   input  req_ready, rsp_valid, rsp_rdata, rsp_id, rsp_src, rsp_we, rsp_err, rsp_status);
  modport slave   (input  req_valid, req_we, req_addr, req_wdata, req_wstrb, req_id, req_src, req_err, rsp_ready,
                   output req_ready, rsp_valid, rsp_rdata, rsp_id, rsp_src, rsp_we, rsp_err, rsp_status);
  modport monitor (input  req_valid, req_ready, req_we, req_addr, req_wdata, req_wstrb, req_id, req_src, req_err,
                          rsp_valid, rsp_ready, rsp_rdata, rsp_id, rsp_src, rsp_we, rsp_err, rsp_status);

  // ------------------------------------------------------------ protocol checker (simulation only)
`ifndef SYNTHESIS
  logic            pv, pr, qv, qr;
  logic [AW+DW+DW/8+IDW+SRCW+1:0] preq;
  logic [DW+IDW+SRCW+5:0]         prsp;
  int              outstanding;
  wire [AW+DW+DW/8+IDW+SRCW+1:0]  creq = {req_we, req_err, req_addr, req_wdata, req_wstrb, req_id, req_src};
  wire [DW+IDW+SRCW+5:0]          crsp = {rsp_rdata, rsp_id, rsp_src, rsp_we, rsp_err, rsp_status};
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pv <= 1'b0; pr <= 1'b1; qv <= 1'b0; qr <= 1'b1; outstanding <= 0;
    end else begin
      if (pv && !pr) begin
        assert (req_valid) else $error("SFC_IF R2: request withdrawn before it was accepted");
        assert (creq == preq) else $error("SFC_IF R2: request payload changed before acceptance");
      end
      if (qv && !qr) begin
        assert (rsp_valid) else $error("SFC_IF R4: response withdrawn before it was accepted");
        assert (crsp == prsp) else $error("SFC_IF R4: response payload changed while held");
      end
      assert (!$isunknown({req_valid, rsp_ready, rsp_valid, req_ready})) else $error("SFC_IF: X on a handshake signal");
      if (rsp_valid) assert (rsp_err == (rsp_status != 4'd0)) else $error("SFC_IF: rsp_err inconsistent with rsp_status");
      if (rsp_valid && rsp_err) assert (rsp_rdata == '0) else $error("SFC_IF R8: rsp_rdata not zero on an error response");
      outstanding <= outstanding + ((req_valid && req_ready) ? 1 : 0) - ((rsp_valid && rsp_ready) ? 1 : 0);
      if (rsp_valid && rsp_ready) assert (outstanding > 0) else $error("SFC_IF R5: response transferred with no request outstanding");
      pv <= req_valid; pr <= req_ready; preq <= creq;
      qv <= rsp_valid; qr <= rsp_ready; prsp <= crsp;
    end
  end
`endif
endinterface

`default_nettype wire
