// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_repair    (OPTIONAL redundancy-allocation research interface)
//
// *** This is an ANALYSIS block.  It computes which spare rows / spare columns WOULD cover the failures MBIST saw.
// *** It repairs nothing.  The SilicaFlux memory macros (OpenRAM SKY130, IHP, GF180 leaves, FPGA block RAM,
// *** behavioural arrays) contain NO spare rows or columns and NO repair controls (MemoryCore KNOWN_LIMITATIONS 6),
// *** so rep_phys_o is tied to the REDUNDANCY_PRESENT parameter (0 in this repository).  A physical repair can only
// *** be claimed for a macro that (a) has redundancy, (b) has a repair-load interface and (c) is exercised with it.
//
// Per bank: SPARE_ROWS row slots and SPARE_COLS column slots.  Every miscompare (bank, row, syndrome) is
// folded in ONLINE by a greedy rule (one decision per event, no lookahead):
//   1. row already mapped to a spare row            -> covered, nothing to do
//   2. syndrome bits not already covered by a mapped spare column = "uncovered bits" U
//   3. U empty                                      -> covered
//   4. |U| >= 2 : a spare row (one resource, any number of columns) if free; else, if enough free column slots,
//                 one spare column per uncovered bit; else UNREPAIRABLE
//   5. |U| == 1 : a spare column if free (a column fault then costs ONE slot for all its rows); else a spare
//                 row if free; else UNREPAIRABLE
// Guarantee (sound): rep_ok_o[b] = 1 only if EVERY observed failing (row, bit) of bank b is covered by a mapped
// spare.  Not guaranteed (documented limitation): optimality.  An online greedy allocator can declare a pattern
// UNREPAIRABLE that an optimal (offline, e.g. must-repair + branch-and-bound) allocator could repair, and it can
// only see failures that the engine actually observed: faults masked by the algorithm, or beyond stop-on-fail,
// are not in the map.  Failures seen in several March elements are folded repeatedly (idempotent).
// Classification: SYNTHESIZABLE (analysis logic only)
// =============================================================================
`default_nettype none

module sf_mbist_repair #(
  parameter int NBANK = 4,
  parameter int AW    = 6,
  parameter int W     = 32,
  parameter int SR    = 2,
  parameter int SC    = 2,
  parameter bit REDUNDANCY_PRESENT = 1'b0,
  parameter int BW    = (NBANK > 1) ? $clog2(NBANK) : 1,
  parameter int BITW  = (W > 1) ? $clog2(W) : 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic                   clr_i,
  input  wire logic                   f_valid_i,
  input  wire logic [BW-1:0]          f_bank_i,
  input  wire logic [AW-1:0]          f_row_i,
  input  wire logic [W-1:0]           syn_i,
  output logic [NBANK*SR-1:0]         rep_row_v_o,
  output logic [NBANK*SR*AW-1:0]      rep_row_o,
  output logic [NBANK*SC-1:0]         rep_col_v_o,
  output logic [NBANK*SC*BITW-1:0]    rep_col_o,
  output logic [NBANK-1:0]            rep_touched_o,    // bank had at least one failure
  output logic [NBANK-1:0]            rep_unrep_o,      // failures exceed the allocatable spares
  output logic [NBANK-1:0]            rep_ok_o,         // touched, all failures covered by the map
  output logic                        rep_phys_o        // a macro with redundancy + repair load exists (0 in this repository)
);
  logic [NBANK*SR-1:0]         rrow_v;
  logic [NBANK*SR*AW-1:0]      rrow;
  logic [NBANK*SC-1:0]         rcol_v;
  logic [NBANK*SC*BITW-1:0]    rcol;
  logic [NBANK-1:0]            touched, unrep;

  // ---- next-state of the addressed bank
  logic [SR-1:0]         n_rv;
  logic [SR*AW-1:0]      n_rr;
  logic [SC-1:0]         n_cv;
  logic [SC*BITW-1:0]    n_cr;
  logic                  n_unrep;

  always_comb begin
    logic [W-1:0] cmask, unc;
    int           nunc, free_c, free_r_idx;
    logic         row_hit, placed;
    logic [SR-1:0]      rv;
    logic [SR*AW-1:0]   rr;
    logic [SC-1:0]      cv;
    logic [SC*BITW-1:0] cr;
    rv = rrow_v[f_bank_i*SR +: SR];
    rr = rrow  [f_bank_i*SR*AW +: SR*AW];
    cv = rcol_v[f_bank_i*SC +: SC];
    cr = rcol  [f_bank_i*SC*BITW +: SC*BITW];
    n_unrep = unrep[f_bank_i];
    row_hit = 1'b0; cmask = '0;
    for (int i = 0; i < SR; i++) if (rv[i] && rr[i*AW +: AW] == f_row_i) row_hit = 1'b1;
    for (int j = 0; j < SC; j++) if (cv[j]) cmask[cr[j*BITW +: BITW]] = 1'b1;
    unc = syn_i & ~cmask;
    nunc = 0;
    for (int i = 0; i < W; i++) if (unc[i]) nunc = nunc + 1;
    free_c = 0; for (int j = 0; j < SC; j++) if (!cv[j]) free_c = free_c + 1;
    free_r_idx = -1; for (int i = SR - 1; i >= 0; i--) if (!rv[i]) free_r_idx = i;

    placed = 1'b0;
    if (!row_hit && nunc != 0) begin
      if (nunc >= 2) begin
        if (free_r_idx >= 0) begin rv[free_r_idx] = 1'b1; rr[free_r_idx*AW +: AW] = f_row_i; end
        else if (free_c >= nunc) begin
          // one spare column per uncovered bit (free slots taken in ascending order)
          for (int i = 0; i < W; i++) if (unc[i]) begin
            placed = 1'b0;
            for (int j = 0; j < SC; j++) if (!cv[j] && !placed) begin
              cv[j] = 1'b1; cr[j*BITW +: BITW] = BITW'(i); placed = 1'b1;
            end
          end
        end else n_unrep = 1'b1;
      end else begin                                    // exactly one uncovered bit
        if (free_c > 0) begin
          for (int i = 0; i < W; i++) if (unc[i]) begin
            for (int j = 0; j < SC; j++) if (!cv[j] && !placed) begin
              cv[j] = 1'b1; cr[j*BITW +: BITW] = BITW'(i); placed = 1'b1;
            end
          end
        end else if (free_r_idx >= 0) begin rv[free_r_idx] = 1'b1; rr[free_r_idx*AW +: AW] = f_row_i; end
        else n_unrep = 1'b1;
      end
    end
    n_rv = rv; n_rr = rr; n_cv = cv; n_cr = cr;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rrow_v <= '0; rrow <= '0; rcol_v <= '0; rcol <= '0; touched <= '0; unrep <= '0;
    end else if (clr_i) begin
      rrow_v <= '0; rrow <= '0; rcol_v <= '0; rcol <= '0; touched <= '0; unrep <= '0;
    end else if (f_valid_i) begin
      rrow_v[f_bank_i*SR +: SR]            <= n_rv;
      rrow  [f_bank_i*SR*AW +: SR*AW]      <= n_rr;
      rcol_v[f_bank_i*SC +: SC]            <= n_cv;
      rcol  [f_bank_i*SC*BITW +: SC*BITW]  <= n_cr;
      touched[f_bank_i]                    <= 1'b1;
      unrep[f_bank_i]                      <= n_unrep;
    end
  end

  assign rep_row_v_o   = rrow_v;
  assign rep_row_o     = rrow;
  assign rep_col_v_o   = rcol_v;
  assign rep_col_o     = rcol;
  assign rep_touched_o = touched;
  assign rep_unrep_o   = unrep;
  assign rep_ok_o      = touched & ~unrep;
  assign rep_phys_o    = REDUNDANCY_PRESENT;
endmodule

`default_nettype wire
