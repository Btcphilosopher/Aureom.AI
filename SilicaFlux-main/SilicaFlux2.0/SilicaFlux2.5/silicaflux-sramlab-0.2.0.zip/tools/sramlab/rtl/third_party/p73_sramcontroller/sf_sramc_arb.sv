// =============================================================================
// SilicaFlux SRAMController :: sf_sramc_arb -- one-bank request arbiter
//
// Work-conserving: if any requester is asserted, exactly one is granted, in the
// same cycle.  The controller only presents requesters that can really be
// issued this cycle (bank ready, credit, ordering), so a grant is always
// consumed and the arbiter state advances on every grant.
//
// PRIO_EN = 0 : ONE class, plain ROUND ROBIN.  After a grant to requester g the
//               search starts at g+1 (mod N).  Bounded waiting: a requester that
//               keeps `req` asserted is granted after at most N-1 grants to others.
// PRIO_EN = 1 : TWO classes.  HIGH = the requesters set in HP_MASK (e.g. ControlCore),
//               LOW = all others.  Each class has its own round-robin pointer.
//               HIGH is preferred, BUT at most HP_LIMIT consecutive HIGH grants are
//               given while a LOW requester is waiting: then one LOW grant is
//               forced.  Hence there is NO starvation in either class:
//                 LOW  waits <= HP_LIMIT*(NL)  + (NL-1)  grants of others   (NL = #LOW)
//                 HIGH waits <= (NH-1) + (NH-1)/HP_LIMIT + 1 grants of others (NH = #HIGH)
//               (both bounds proven in formal/fv_sramc_arb.sv for the checked sizes).
//
// The grant is a function of `req` and the registered pointers only (no path
// from any downstream ready).  N <= 16.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sramc_defs.svh"
`default_nettype none

module sf_sramc_arb #(
  parameter int          N        = 4,
  parameter int          PRIO_EN  = 0,
  parameter logic [15:0] HP_MASK  = 16'h0001,
  parameter int          HP_LIMIT = 4,
  localparam int         IW       = (N > 1) ? $clog2(N) : 1,
  localparam int         SW       = $clog2(HP_LIMIT + 1)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic [N-1:0]  req,
  output logic      [N-1:0]  grant,
  output logic      [IW-1:0] grant_idx,
  output logic               any
);
  if (N < 1 || N > 16) begin : g_err_n_not_1_to_16
    `SFC_CFG_FATAL("sf_sramc_arb: N must be 1..16")
  end
  if (PRIO_EN != 0 && PRIO_EN != 1) begin : g_err_prio_en_not_0_or_1
    `SFC_CFG_FATAL("sf_sramc_arb: PRIO_EN must be 0 or 1")
  end
  if (HP_LIMIT < 1) begin : g_err_hp_limit_lt_1
    `SFC_CFG_FATAL("sf_sramc_arb: HP_LIMIT must be >= 1")
  end

  localparam logic [N-1:0] HPM = HP_MASK[N-1:0];

  logic [IW-1:0] ptr_h_q, ptr_l_q;     // per-class round-robin pointers
  logic [SW-1:0] streak_q;             // consecutive HIGH grants while a LOW requester waited

  logic [N-1:0] hp_req, lp_req;
  assign hp_req = (PRIO_EN != 0) ? (req & HPM)  : {N{1'b0}};
  assign lp_req = (PRIO_EN != 0) ? (req & ~HPM) : req;

  // class selection
  logic use_hp;
  assign use_hp = (hp_req != {N{1'b0}}) &&
                  !((streak_q == SW'(HP_LIMIT)) && (lp_req != {N{1'b0}}));

  // round-robin pick: first set bit of `m` at or after `p` (circular)
  logic [IW-1:0] pick_h, pick_l, pick_sel;
  logic          found_h, found_l;
  always_comb begin
    int idx;
    pick_h  = '0;
    pick_l  = '0;
    found_h = 1'b0;
    found_l = 1'b0;
    for (int k = 0; k < N; k++) begin
      idx = 32'(ptr_h_q) + k;
      if (idx >= N) idx = idx - N;
      if (!found_h && hp_req[idx]) begin
        found_h = 1'b1;
        pick_h  = IW'(idx);
      end
      idx = 32'(ptr_l_q) + k;
      if (idx >= N) idx = idx - N;
      if (!found_l && lp_req[idx]) begin
        found_l = 1'b1;
        pick_l  = IW'(idx);
      end
    end
  end

  assign pick_sel  = use_hp ? pick_h : pick_l;
  assign any       = found_h || found_l;
  assign grant_idx = any ? pick_sel : '0;
  assign grant     = any ? ({{(N-1){1'b0}}, 1'b1} << pick_sel) : {N{1'b0}};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ptr_h_q  <= '0;
      ptr_l_q  <= '0;
      streak_q <= '0;
    end else if (any) begin
      if (use_hp) begin
        ptr_h_q <= (pick_h == IW'(N - 1)) ? '0 : pick_h + 1'b1;
        if (lp_req != {N{1'b0}}) begin
          if (streak_q != SW'(HP_LIMIT)) streak_q <= streak_q + 1'b1;
        end else begin
          streak_q <= '0;
        end
      end else begin
        ptr_l_q  <= (pick_l == IW'(N - 1)) ? '0 : pick_l + 1'b1;
        streak_q <= '0;
      end
    end
  end
endmodule

`default_nettype wire
