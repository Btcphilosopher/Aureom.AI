// =============================================================================
// SilicaFlux SRAMController (Project 73) :: sf_sramc_soc4
// The four SilicaFlux masters on one banked SRAM subsystem, with named ports:
//   0 ControlCore (cc_*)   1 DMA (dma_*)   2 Vector Engine (vec_*)   3 TensorCore (tc_*)
// (index map: SFC_MST_* in sf_sramc_defs.svh).  Source IDs are tied to the port
// index inside the wrapper; src_en gates a master off (its requests are answered
// SFC_ST_SRC).  Masters that have no response back-pressure (the p40 stand-in DMA)
// tie *_rsp_ready = 1 and leave *_req_id at a constant (with MAX_OUT = 1, or
// ID_CHECK = 0 when MAX_OUT > 1).
// Defaults: 32-bit x 1024 words x 4 banks (16 KiB), word-interleaved, MAX_OUT = 4.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sramc_defs.svh"
`default_nettype none

module sf_sramc_soc4 #(
  parameter int          DATA_WIDTH  = 32,
  parameter int          NUM_BANKS   = 4,
  parameter int          BANK_DEPTH  = 1024,
  parameter int          ID_WIDTH    = 4,
  parameter int          MAX_OUT     = 4,
  parameter int          INTERLEAVE  = `SFC_ILV_LOW,
  parameter int          ID_CHECK    = 1,
  parameter int          PRIO_EN     = 0,          // 1: ControlCore is the HIGH class (HP_LIMIT guard)
  parameter int          HP_LIMIT    = 4,
  parameter int          PERF_EN     = 1,
  parameter logic [63:0] BANK_LATS   = 64'h1111_1111_1111_1111,
  localparam int NBYTE = DATA_WIDTH / 8,
  localparam int NPERF = 16 + 16 * 4 + 8 * NUM_BANKS,
  localparam int PSW   = $clog2(NPERF)
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---- ControlCore
  input  wire logic                   cc_req_valid,  output logic cc_req_ready,
  input  wire logic                   cc_req_we,     input wire logic [31:0] cc_req_addr,
  input  wire logic [DATA_WIDTH-1:0]  cc_req_wdata,  input wire logic [NBYTE-1:0] cc_req_wstrb,
  input  wire logic [ID_WIDTH-1:0]    cc_req_id,
  output logic                        cc_rsp_valid,  input wire logic cc_rsp_ready,
  output logic [DATA_WIDTH-1:0]       cc_rsp_rdata,  output logic [ID_WIDTH-1:0] cc_rsp_id,
  output logic                        cc_rsp_we,     output logic cc_rsp_err,  output logic [3:0] cc_rsp_status,
  // ---- DMA
  input  wire logic                   dma_req_valid, output logic dma_req_ready,
  input  wire logic                   dma_req_we,    input wire logic [31:0] dma_req_addr,
  input  wire logic [DATA_WIDTH-1:0]  dma_req_wdata, input wire logic [NBYTE-1:0] dma_req_wstrb,
  input  wire logic [ID_WIDTH-1:0]    dma_req_id,
  output logic                        dma_rsp_valid, input wire logic dma_rsp_ready,
  output logic [DATA_WIDTH-1:0]       dma_rsp_rdata, output logic [ID_WIDTH-1:0] dma_rsp_id,
  output logic                        dma_rsp_we,    output logic dma_rsp_err, output logic [3:0] dma_rsp_status,
  // ---- Vector Engine
  input  wire logic                   vec_req_valid, output logic vec_req_ready,
  input  wire logic                   vec_req_we,    input wire logic [31:0] vec_req_addr,
  input  wire logic [DATA_WIDTH-1:0]  vec_req_wdata, input wire logic [NBYTE-1:0] vec_req_wstrb,
  input  wire logic [ID_WIDTH-1:0]    vec_req_id,
  output logic                        vec_rsp_valid, input wire logic vec_rsp_ready,
  output logic [DATA_WIDTH-1:0]       vec_rsp_rdata, output logic [ID_WIDTH-1:0] vec_rsp_id,
  output logic                        vec_rsp_we,    output logic vec_rsp_err, output logic [3:0] vec_rsp_status,
  // ---- TensorCore
  input  wire logic                   tc_req_valid,  output logic tc_req_ready,
  input  wire logic                   tc_req_we,     input wire logic [31:0] tc_req_addr,
  input  wire logic [DATA_WIDTH-1:0]  tc_req_wdata,  input wire logic [NBYTE-1:0] tc_req_wstrb,
  input  wire logic [ID_WIDTH-1:0]    tc_req_id,
  output logic                        tc_rsp_valid,  input wire logic tc_rsp_ready,
  output logic [DATA_WIDTH-1:0]       tc_rsp_rdata,  output logic [ID_WIDTH-1:0] tc_rsp_id,
  output logic                        tc_rsp_we,     output logic tc_rsp_err,  output logic [3:0] tc_rsp_status,
  // ---- control / status / performance
  input  wire logic [3:0]             src_en,
  input  wire logic                   flush,
  output logic                        idle,
  output logic                        sts_rsp_overflow,
  output logic                        sts_bank_proto,
  input  wire logic                   perf_clr,
  input  wire logic [PSW-1:0]         perf_sel,
  output logic [31:0]                 perf_val
);
  localparam logic [15:0] HPM = 16'h0001 << `SFC_MST_CTRL;

  logic [3:0]               rq_v, rq_r, rq_we, rs_v, rs_r, rs_we, rs_err;
  logic [4*32-1:0]          rq_addr;
  logic [4*DATA_WIDTH-1:0]  rq_wd, rs_rd;
  logic [4*NBYTE-1:0]       rq_ws;
  logic [4*ID_WIDTH-1:0]    rq_id, rs_id;
  logic [4*4-1:0]           rs_st;
  logic [4*2-1:0]           rq_src;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [4*2-1:0]           rs_src;
  /* verilator lint_on UNUSEDSIGNAL */

  assign rq_v    = {tc_req_valid, vec_req_valid, dma_req_valid, cc_req_valid};
  assign rq_we   = {tc_req_we, vec_req_we, dma_req_we, cc_req_we};
  assign rq_addr = {tc_req_addr, vec_req_addr, dma_req_addr, cc_req_addr};
  assign rq_wd   = {tc_req_wdata, vec_req_wdata, dma_req_wdata, cc_req_wdata};
  assign rq_ws   = {tc_req_wstrb, vec_req_wstrb, dma_req_wstrb, cc_req_wstrb};
  assign rq_id   = {tc_req_id, vec_req_id, dma_req_id, cc_req_id};
  assign rq_src  = {2'd3, 2'd2, 2'd1, 2'd0};
  assign rs_r    = {tc_rsp_ready, vec_rsp_ready, dma_rsp_ready, cc_rsp_ready};

  assign {tc_req_ready, vec_req_ready, dma_req_ready, cc_req_ready} = rq_r;
  assign {tc_rsp_valid, vec_rsp_valid, dma_rsp_valid, cc_rsp_valid} = rs_v;
  assign {tc_rsp_we, vec_rsp_we, dma_rsp_we, cc_rsp_we}             = rs_we;
  assign {tc_rsp_err, vec_rsp_err, dma_rsp_err, cc_rsp_err}         = rs_err;
  assign {tc_rsp_rdata, vec_rsp_rdata, dma_rsp_rdata, cc_rsp_rdata} = rs_rd;
  assign {tc_rsp_id, vec_rsp_id, dma_rsp_id, cc_rsp_id}             = rs_id;
  assign {tc_rsp_status, vec_rsp_status, dma_rsp_status, cc_rsp_status} = rs_st;

  sf_sram_subsystem #(
    .NUM_MASTERS(4), .NUM_BANKS(NUM_BANKS), .DATA_WIDTH(DATA_WIDTH), .BANK_DEPTH(BANK_DEPTH),
    .ADDR_WIDTH(32), .ID_WIDTH(ID_WIDTH), .MAX_OUT(MAX_OUT), .INTERLEAVE(INTERLEAVE),
    .ID_CHECK(ID_CHECK), .SRC_CHECK(1), .PRIO_EN(PRIO_EN), .HP_MASK(HPM), .HP_LIMIT(HP_LIMIT),
    .PERF_EN(PERF_EN), .CNT_W(32), .BANK_LATS(BANK_LATS), .UNIFORM_LAT(-1)
  ) u_sub (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(rq_v), .m_req_ready(rq_r), .m_req_we(rq_we), .m_req_addr(rq_addr), .m_req_wdata(rq_wd),
    .m_req_wstrb(rq_ws), .m_req_id(rq_id), .m_req_src(rq_src), .m_req_err(4'b0000),
    .m_rsp_valid(rs_v), .m_rsp_ready(rs_r), .m_rsp_rdata(rs_rd), .m_rsp_id(rs_id), .m_rsp_src(rs_src),
    .m_rsp_we(rs_we), .m_rsp_err(rs_err), .m_rsp_status(rs_st),
    .src_en(src_en), .flush(flush), .idle(idle), .sts_rsp_overflow(sts_rsp_overflow),
    .sts_bank_proto(sts_bank_proto), .perf_clr(perf_clr), .perf_sel(perf_sel), .perf_val(perf_val)
  );
endmodule

`default_nettype wire
