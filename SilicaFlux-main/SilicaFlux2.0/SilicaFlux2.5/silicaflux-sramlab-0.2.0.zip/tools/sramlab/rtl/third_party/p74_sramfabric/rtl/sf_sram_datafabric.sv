// =============================================================================
// SilicaFlux SRAMFabric (Project 74) :: sf_sram_datafabric -- DataFabric (SFB3) -> SRAM controller bridge, top
//
//   DataFabric Request -> Protocol Adapter -> Address Decode -> SRAMController -> Banked SRAM
//                                                                              -> Response Adapter -> DataFabric Response
//
// NTP independent SFB3 TARGET ports ("slices", sf_sdf_port) share one SRAM controller.  Slice t uses controller master
// ports [t*NP .. t*NP+NP-1].  Why more than one: a single SFB3 target port moves at most one beat per cycle; with NTP
// target ports (each decoded by the fabric to its own window, WIN_BASES[t]) several masters can be served in the same
// cycle, limited only by the controller's per-bank service (one access per bank per cycle) -- measured in
// reports/PERFORMANCE.md.  Every window addresses the WHOLE shared SRAM (an alias): offset = addr & (2^WIN_LOG2 - 1).
// NTP = 1 is port-compatible with the superseded Project-71 adapter of the same name (extra ports: c_rsp_ce, c_flush_*,
// statistics), so the earlier TB/instantiation pattern still applies.
//
// Documentation (all under docs/):  PROTOCOL_MAPPING.md (every conversion), MEMORY_MAP.md (windows, offsets, banks, local
// scratchpad ports), ERRORS_AND_RECOVERY.md, PERFORMANCE_MODEL.md, BURSTS.md.
//
// Register page (rb_*, 32-bit, word addressed, one 64-word block per slice, SilicaFlux register-bus convention):
//   +0x00 ID 0x53444631 ('SDF1')  +0x01 CTRL (W: bit0 clear counters, bit1 clear error log)
//   +0x02 ERR_STATUS {sticky, code[2:0]}   +0x03 ERR_CNT   +0x04 ERR_INFO {src,id,opcode}   +0x05 ERR_ADDR
//   +0x06 {state[1:0], out_cnt[15:0]}      +0x08..0x0F responses per cause
//   +0x10..0x2B performance counters (index = SDF_P_*, sf_sdf_defs.svh)   +0x30.. per-bank legal accesses  +0x38.. per-bank stalls
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sf_sdf_defs.svh"
`default_nettype none

module sf_sram_datafabric #(
  parameter int            NM         = 4,
  parameter int            AW         = 32,
  parameter int            DW         = 128,
  parameter int            IDW        = 2,
  parameter int            NTP        = 1,           // SFB3 target ports
  parameter int            NP         = 1,           // controller master ports per target port (power of two)
  parameter int            LINE_W     = 128,
  parameter int            NB         = 4,
  parameter int            DEPTH      = 1024,
  parameter logic [NTP*AW-1:0] WIN_BASES = {NTP{32'h2000_0000}},
  parameter int            WIN_LOG2   = 20,
  parameter int            ALLOW_LO   = 0,
  parameter int            ALLOW_HI   = NB * DEPTH * (LINE_W / 8),
  parameter int            REQ_REG    = 1,
  parameter int            RSP_REG    = 1,
  parameter int            CTRL_NSLOT = 8,
  parameter int            TXQ_DEPTH  = 8,
  parameter int            TIMEOUT    = 0,
  parameter int            TO_ACTION  = 1,
  parameter int            TS_W       = 16,
  parameter int            CNT_W      = 32,
  // ---- derived (do not override)
  parameter int            SRCW       = (NM > 1) ? $clog2(NM) : 1,
  parameter int            SB         = DW / 8,
  parameter int            LANEW      = (DW < LINE_W) ? $clog2(LINE_W / DW) : 1,
  parameter int            IDC        = 3 + SRCW + IDW + LANEW + 1,
  parameter int            NCP        = NTP * NP                    // controller master ports used
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------------- SFB3 target ports (flattened NTP x)
  input  wire logic [NTP-1:0]         t_req_valid,
  output logic      [NTP-1:0]         t_req_ready,
  input  wire logic [NTP*3-1:0]       t_req_opcode,
  input  wire logic [NTP*SRCW-1:0]    t_req_src,
  input  wire logic [NTP*IDW-1:0]     t_req_id,
  input  wire logic [NTP*3-1:0]       t_req_qos,
  input  wire logic [NTP*AW-1:0]      t_req_addr,
  input  wire logic [NTP*DW-1:0]      t_req_wdata,
  input  wire logic [NTP*SB-1:0]      t_req_wstrb,
  output logic      [NTP-1:0]         t_rsp_valid,
  input  wire logic [NTP-1:0]         t_rsp_ready,
  output logic      [NTP*SRCW-1:0]    t_rsp_src,
  output logic      [NTP*IDW-1:0]     t_rsp_id,
  output logic      [NTP*3-1:0]       t_rsp_opcode,
  output logic      [NTP*2-1:0]       t_rsp_status,
  output logic      [NTP*DW-1:0]      t_rsp_rdata,
  output logic      [NTP*3-1:0]       rsp_cause_o,
  // ---------------------------------------------------------------- SRAM controller master ports (NCP = NTP*NP)
  output logic      [NCP-1:0]         c_req_valid,
  input  wire logic [NCP-1:0]         c_req_ready,
  output logic      [NCP-1:0]         c_req_we,
  output logic      [NCP*AW-1:0]      c_req_addr,
  output logic      [NCP*LINE_W-1:0]  c_req_wdata,
  output logic      [NCP*(LINE_W/8)-1:0] c_req_be,
  output logic      [NCP*IDC-1:0]     c_req_id,
  input  wire logic [NCP-1:0]         c_rsp_valid,
  output logic      [NCP-1:0]         c_rsp_ready,
  input  wire logic [NCP*LINE_W-1:0]  c_rsp_rdata,
  input  wire logic [NCP*IDC-1:0]     c_rsp_id,
  input  wire logic [NCP-1:0]         c_rsp_we,
  input  wire logic [NCP*3-1:0]       c_rsp_status,
  input  wire logic [NCP-1:0]         c_rsp_ce,
  // ---------------------------------------------------------------- controller recovery
  input  wire logic                   c_flush_i,       // controller discarding in-flight work (flush_busy_o | ~ctrl_rst_n)
  output logic                        c_flush_o,       // timeout recovery request (wire to the controller flush_i)
  // ---------------------------------------------------------------- error reporting (per slice)
  input  wire logic                   err_clr_i,
  output logic      [NTP-1:0]         err_sticky_o,
  output logic      [NTP*CNT_W-1:0]   err_cnt_o,
  output logic      [NTP*3-1:0]       err_code_o,
  output logic      [NTP*SRCW-1:0]    err_src_o,
  output logic      [NTP*IDW-1:0]     err_id_o,
  output logic      [NTP*3-1:0]       err_opcode_o,
  output logic      [NTP*AW-1:0]      err_addr_o,
  output logic                        irq_o,
  // ---------------------------------------------------------------- statistics (per slice) and register page
  output logic      [NTP*`SDF_NPERF*CNT_W-1:0] perf_o,
  output logic      [NTP*NB*CNT_W-1:0]         bank_acc_o,
  output logic      [NTP*NB*CNT_W-1:0]         bank_stall_o,
  output logic      [NTP*16-1:0]      out_cnt_o,
  input  wire logic                   rb_sel,
  input  wire logic                   rb_we,
  input  wire logic [7:0]             rb_addr,         // word address
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]            rb_wdata,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic      [31:0]            rb_rdata,
  output logic                        rb_err
);
  if (NTP < 1 || NTP > 4) begin : g_err_ntp
    `SF_CFG_FATAL("sf_sram_datafabric: NTP must be 1..4 (register page has 4 slice blocks)")
  end

  logic [NTP-1:0] cnt_clr_q, errc_q;
  logic [NTP-1:0] c_flush_o_v;
  logic [NTP-1:0] irq_v;
  logic [NTP*8*CNT_W-1:0] cause_cnt_v;
  logic [NTP*2-1:0] state_v;

  for (genvar t = 0; t < NTP; t++) begin : g_t
    sf_sdf_port #(
      .NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .NP(NP), .LINE_W(LINE_W), .NB(NB), .DEPTH(DEPTH),
      .WIN_BASE(WIN_BASES[t*AW +: AW]), .WIN_LOG2(WIN_LOG2), .ALLOW_LO(ALLOW_LO), .ALLOW_HI(ALLOW_HI),
      .REQ_REG(REQ_REG), .RSP_REG(RSP_REG), .CTRL_NSLOT(CTRL_NSLOT), .TXQ_DEPTH(TXQ_DEPTH), .TIMEOUT(TIMEOUT),
      .TO_ACTION(TO_ACTION), .TS_W(TS_W), .CNT_W(CNT_W)
    ) u_port (
      .clk(clk), .rst_n(rst_n),
      .t_req_valid(t_req_valid[t]), .t_req_ready(t_req_ready[t]), .t_req_opcode(t_req_opcode[t*3 +: 3]),
      .t_req_src(t_req_src[t*SRCW +: SRCW]), .t_req_id(t_req_id[t*IDW +: IDW]), .t_req_qos(t_req_qos[t*3 +: 3]),
      .t_req_addr(t_req_addr[t*AW +: AW]), .t_req_wdata(t_req_wdata[t*DW +: DW]), .t_req_wstrb(t_req_wstrb[t*SB +: SB]),
      .t_rsp_valid(t_rsp_valid[t]), .t_rsp_ready(t_rsp_ready[t]), .t_rsp_src(t_rsp_src[t*SRCW +: SRCW]),
      .t_rsp_id(t_rsp_id[t*IDW +: IDW]), .t_rsp_opcode(t_rsp_opcode[t*3 +: 3]), .t_rsp_status(t_rsp_status[t*2 +: 2]),
      .t_rsp_rdata(t_rsp_rdata[t*DW +: DW]), .rsp_cause_o(rsp_cause_o[t*3 +: 3]),
      .c_req_valid(c_req_valid[t*NP +: NP]), .c_req_ready(c_req_ready[t*NP +: NP]), .c_req_we(c_req_we[t*NP +: NP]),
      .c_req_addr(c_req_addr[t*NP*AW +: NP*AW]), .c_req_wdata(c_req_wdata[t*NP*LINE_W +: NP*LINE_W]),
      .c_req_be(c_req_be[t*NP*(LINE_W/8) +: NP*(LINE_W/8)]), .c_req_id(c_req_id[t*NP*IDC +: NP*IDC]),
      .c_rsp_valid(c_rsp_valid[t*NP +: NP]), .c_rsp_ready(c_rsp_ready[t*NP +: NP]),
      .c_rsp_rdata(c_rsp_rdata[t*NP*LINE_W +: NP*LINE_W]), .c_rsp_id(c_rsp_id[t*NP*IDC +: NP*IDC]),
      .c_rsp_we(c_rsp_we[t*NP +: NP]), .c_rsp_status(c_rsp_status[t*NP*3 +: NP*3]), .c_rsp_ce(c_rsp_ce[t*NP +: NP]),
      .c_flush_i(c_flush_i), .c_flush_o(c_flush_o_v[t]),
      .err_clr_i(err_clr_i | errc_q[t]), .cnt_clr_i(cnt_clr_q[t]),
      .err_sticky_o(err_sticky_o[t]), .err_cnt_o(err_cnt_o[t*CNT_W +: CNT_W]), .err_code_o(err_code_o[t*3 +: 3]),
      .err_src_o(err_src_o[t*SRCW +: SRCW]), .err_id_o(err_id_o[t*IDW +: IDW]), .err_opcode_o(err_opcode_o[t*3 +: 3]),
      .err_addr_o(err_addr_o[t*AW +: AW]), .cause_cnt_o(cause_cnt_v[t*8*CNT_W +: 8*CNT_W]),
      .perf_o(perf_o[t*`SDF_NPERF*CNT_W +: `SDF_NPERF*CNT_W]),
      .bank_acc_o(bank_acc_o[t*NB*CNT_W +: NB*CNT_W]), .bank_stall_o(bank_stall_o[t*NB*CNT_W +: NB*CNT_W]),
      .out_cnt_o(out_cnt_o[t*16 +: 16]), .state_o(state_v[t*2 +: 2]), .irq_o(irq_v[t]));
  end
  assign c_flush_o = |c_flush_o_v;
  assign irq_o     = |irq_v;

  // ------------------------------------------------------------ register page
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin cnt_clr_q <= '0; errc_q <= '0; end
    else begin
      cnt_clr_q <= '0; errc_q <= '0;
      for (int t = 0; t < NTP; t++)
        if (rb_sel && rb_we && rb_addr[5:0] == 6'h01 && rb_addr[7:6] == 2'(t)) begin
          cnt_clr_q[t] <= rb_wdata[0];
          errc_q[t]    <= rb_wdata[1];
        end
    end
  end
  localparam logic [31:0] SDF_ID = 32'h5344_4631;
  logic [31:0] rd;
  logic        hit;
  always_comb begin
    /* verilator lint_off UNUSEDSIGNAL */
    integer bi, pi;
    /* verilator lint_on UNUSEDSIGNAL */
    bi = {29'd0, rb_addr[2:0]};
    pi = {26'd0, rb_addr[5:0]} - 16;
    rd = '0; hit = 1'b0;
    for (int t = 0; t < NTP; t++) begin
      if (rb_addr[7:6] == 2'(t)) begin
        hit = 1'b1;
        case (rb_addr[5:0])
          6'h00: rd = SDF_ID;
          6'h01: rd = '0;
          6'h02: rd = {28'd0, err_sticky_o[t], err_code_o[t*3 +: 3]};
          6'h03: rd = 32'(err_cnt_o[t*CNT_W +: CNT_W]);
          6'h04: rd = 32'({err_src_o[t*SRCW +: SRCW], err_id_o[t*IDW +: IDW], err_opcode_o[t*3 +: 3]});
          6'h05: rd = 32'(err_addr_o[t*AW +: AW]);
          6'h06: rd = {14'd0, state_v[t*2 +: 2], out_cnt_o[t*16 +: 16]};
          default: begin
            hit = 1'b0;
            if (rb_addr[5:3] == 3'd1) begin
              rd = 32'(cause_cnt_v[(t*8 + bi)*CNT_W +: CNT_W]); hit = 1'b1;
            end else if (rb_addr[5:0] >= 6'h10 && rb_addr[5:0] < 6'(16 + `SDF_NPERF)) begin
              rd = 32'(perf_o[(t*`SDF_NPERF + pi)*CNT_W +: CNT_W]); hit = 1'b1;
            end else if (rb_addr[5:3] == 3'd6 && NB > bi) begin
              rd = 32'(bank_acc_o[(t*NB + bi)*CNT_W +: CNT_W]); hit = 1'b1;
            end else if (rb_addr[5:3] == 3'd7 && NB > bi) begin
              rd = 32'(bank_stall_o[(t*NB + bi)*CNT_W +: CNT_W]); hit = 1'b1;
            end
          end
        endcase
      end
    end
  end
  assign rb_rdata = rb_sel ? rd : '0;
  assign rb_err   = rb_sel & ~hit;
endmodule

`default_nettype wire
