# Provenance — vendored SilicaFlux RTL (byte-identical copies)
SRAMController (Project 73): `sf_sram_controller.sv`, `sf_sram_subsystem.sv`, `sf_sramc_{arb,bank,fifo,perf,defs,soc4,txn}`.sv/.svh from
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramcontroller-p73.zip` (`rtl/sramc/`). `soc4`/`txn` are vendored for completeness but not compiled by SRAMLab.
SHA-256 in `SHA256SUMS`. That project's own evidence: 5-phase scoreboard testbenches, formal proofs (PDR/BMC), mutation testing; SRAMLab's RTL comparison matrix (253 cases) is independent additional evidence.
