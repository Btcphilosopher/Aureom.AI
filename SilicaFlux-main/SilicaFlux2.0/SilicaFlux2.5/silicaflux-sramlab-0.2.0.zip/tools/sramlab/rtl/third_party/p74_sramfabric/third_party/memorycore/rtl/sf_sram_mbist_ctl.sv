// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_mbist_ctl
// MBIST sequencer around the EXISTING March engine (third_party/sramlib_mbist/sram_mbist_march.sv,
// Project 01, reused byte-identical).  The engine drives the controller's raw test port; this module adds
// what a safe in-system run needs and the engine does not do:
//
//   start_i ->  QUIESCE   quiesce_o = 1: the controller stops accepting requests; wait until it reports
//                         idle_i (no in-flight access, every bank FSM idle) for two consecutive cycles
//           ->  RUN       the March engine tests the selected banks ONE AFTER ANOTHER (bounded test power);
//                         while it runs the test bus owns every bank's array (functional req_ready = 0)
//           ->  REINIT    MBIST is DESTRUCTIVE (the arrays end up holding the test background; with ECC the
//                         raw patterns carry arbitrary check bits).  init_start_o re-initialises every bank
//                         (zero lines, valid ECC) and the sequencer waits for it
//           ->  DONE      quiesce released; done_o stays high until the next start
//
// Algorithms (ALGO of the engine): March C- (10N) {B(w0);U(r0,w1);U(r1,w0);D(r0,w1);D(r1,w0);B(r0)}, MATS+ (5N).
// Backgrounds: bg_checker_i = 0 solid 0/1; 1 = checkerboard (0101.., inverted on odd rows).
// The test is on the STORED word: with ECC the check bits are tested too (STORE_W = 137 for a 128-bit line).
// Coverage of the fault models is MEASURED, not claimed: tb/tb_mbist_cov.sv, reports/mbist_coverage.json.
// NOT provided: retention/pause elements, repair (no spare rows/columns exist in this design), production
// coverage sign-off.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sram_defs.svh"
`default_nettype none

module sf_sram_mbist_ctl #(
  parameter int NB           = 4,
  parameter int DEPTH        = 1024,
  parameter int STORE_W      = 128,
  parameter int READ_LATENCY = 1,
  parameter int ALGO         = `SRAM_MBIST_MARCH_CM,
  parameter int ROW_W        = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  start_i,
  input  wire logic [NB-1:0]         bank_mask_i,
  input  wire logic                  bg_checker_i,
  input  wire logic                  stop_on_fail_i,
  output logic                       busy_o,
  output logic                       done_o,
  output logic                       pass_o,
  output logic                       fail_o,
  output logic [NB-1:0]              fail_mask_o,
  output logic [ROW_W-1:0]           fail_addr_o,
  output logic [2:0]                 fail_elem_o,
  output logic [STORE_W-1:0]         fail_syndrome_o,
  output logic [15:0]                fail_count_o,
  // ---- controller side
  output logic                       quiesce_o,
  input  wire logic                  idle_i,
  output logic                       init_start_o,
  input  wire logic                  init_busy_i,
  output logic                       tst_active_o,
  output logic [NB-1:0]              tst_sel_o,
  output logic                       tst_ce_o,
  output logic                       tst_we_o,
  output logic [ROW_W-1:0]           tst_addr_o,
  output logic [STORE_W-1:0]         tst_wdata_o,
  input  wire logic [NB*STORE_W-1:0] tst_rdata_i
);
  localparam logic [NB*32-1:0] MAXA = {NB{32'(DEPTH - 1)}};
  localparam logic [NB*16-1:0] TDW  = {NB{16'(STORE_W)}};

  typedef enum logic [2:0] {W_IDLE, W_QUIESCE, W_RUN, W_REINIT, W_REINIT_WAIT, W_DONE} wstate_e;
  wstate_e st;
  logic [1:0]  idle_cnt;
  logic        eng_start, eng_busy, eng_done, eng_pass, eng_fail;
  logic [7:0]  to_cnt;
  logic        seen_busy;
  logic [NB-1:0] mask_q;
  logic        bg_q, stop_q;

  sram_mbist_march #(.NUM_TARGETS(NB), .DW(STORE_W), .AW(ROW_W), .READ_LATENCY(READ_LATENCY),
                     .TARGET_MAXADDR(MAXA), .TARGET_DW(TDW), .ALGO(ALGO)) u_march (
    .clk(clk), .rst_n(rst_n), .start(eng_start), .target_mask(mask_q), .bg_checker(bg_q), .stop_on_fail(stop_q),
    .busy(eng_busy), .done(eng_done), .pass(eng_pass), .fail(eng_fail), .fail_mask(fail_mask_o),
    .fail_target(), .fail_addr(fail_addr_o), .fail_elem(fail_elem_o), .fail_syndrome(fail_syndrome_o),
    .fail_count(fail_count_o), .tst_active(tst_active_o), .tst_sel(tst_sel_o), .tst_ce(tst_ce_o), .tst_we(tst_we_o),
    .tst_addr(tst_addr_o), .tst_wdata(tst_wdata_o), .tst_rdata(tst_rdata_i));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= W_IDLE; idle_cnt <= '0; eng_start <= 1'b0; init_start_o <= 1'b0; to_cnt <= '0; seen_busy <= 1'b0;
      mask_q <= '0; bg_q <= 1'b0; stop_q <= 1'b0;
    end else begin
      eng_start <= 1'b0; init_start_o <= 1'b0;
      case (st)
        W_IDLE, W_DONE: if (start_i) begin
          st <= W_QUIESCE; idle_cnt <= '0; mask_q <= bank_mask_i; bg_q <= bg_checker_i; stop_q <= stop_on_fail_i;
        end
        W_QUIESCE: begin
          idle_cnt <= idle_i ? ((idle_cnt == 2'd3) ? idle_cnt : idle_cnt + 1'b1) : '0;
          if (idle_i && idle_cnt >= 2'd2) begin eng_start <= 1'b1; st <= W_RUN; end
        end
        W_RUN: if (eng_start == 1'b0 && eng_done) begin st <= W_REINIT; end
        W_REINIT: begin init_start_o <= 1'b1; seen_busy <= 1'b0; to_cnt <= 8'd32; st <= W_REINIT_WAIT; end
        W_REINIT_WAIT: begin
          if (init_busy_i) seen_busy <= 1'b1;
          if (to_cnt != 0) to_cnt <= to_cnt - 1'b1;
          if ((seen_busy && !init_busy_i) || (to_cnt == 0 && !init_busy_i)) st <= W_DONE;
        end
        default: st <= W_IDLE;
      endcase
    end
  end

  assign quiesce_o = (st != W_IDLE) && (st != W_DONE);
  assign busy_o    = quiesce_o;
  assign done_o    = (st == W_DONE);
  assign fail_o    = eng_fail;
  assign pass_o    = done_o & ~eng_fail;
  wire unused_ok = &{1'b0, eng_busy, eng_pass};
endmodule

`default_nettype wire
