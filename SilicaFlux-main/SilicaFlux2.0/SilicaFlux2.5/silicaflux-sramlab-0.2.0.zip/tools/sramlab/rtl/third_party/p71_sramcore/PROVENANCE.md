# Provenance — vendored SilicaFlux RTL (byte-identical copies)
SRAMCore (Project 71): `sf_sram_core.sv`, `sf_sram_array.sv`, `sf_sram_defs.svh` from
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramcore-p71.zip` (`rtl/sram/`); identical to the copy inside the SRAMController package's `third_party/`.
SHA-256 in `SHA256SUMS` (verified by `tests/test_vendored.py`). Verification evidence for these files is that project's own; SRAMLab additionally exercises them in every RTL comparison.
