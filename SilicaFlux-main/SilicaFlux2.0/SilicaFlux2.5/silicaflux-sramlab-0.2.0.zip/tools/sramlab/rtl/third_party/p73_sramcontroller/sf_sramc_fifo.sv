// =============================================================================
// SilicaFlux SRAMController :: sf_sramc_fifo -- bounded synchronous FIFO
//
// * DEPTH >= 1 entries (any value, not only a power of two), registered
//   storage, first-word-fall-through read (pop_data is the head, valid while
//   !empty).
// * One push and one pop per cycle.  A push into a FULL fifo is accepted when
//   a pop happens in the same cycle (the pop frees the slot at the same edge);
//   a push into a full fifo without a simultaneous pop is DROPPED and
//   `overflow` pulses -- the controller's credit scheme makes that unreachable
//   (proved in formal/fv_sramc.sv) but the FIFO never corrupts itself.
// * A pop on an empty fifo is ignored and `underflow` pulses.
// * Data storage is not reset (house rule 4); only pointers/count are.
// * pop_data is stable while !empty && !pop (head only changes on a pop).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sramc_defs.svh"
`default_nettype none

module sf_sramc_fifo #(
  parameter int WIDTH = 8,
  parameter int DEPTH = 2,
  localparam int CW   = $clog2(DEPTH + 1),
  localparam int PW   = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             push,
  input  wire logic [WIDTH-1:0] push_data,
  input  wire logic             pop,
  output logic      [WIDTH-1:0] pop_data,
  output logic                  empty,
  output logic                  full,
  output logic      [CW-1:0]    count,
  output logic                  overflow,
  output logic                  underflow
);
  if (DEPTH < 1) begin : g_err_depth_lt_1
    `SFC_CFG_FATAL("sf_sramc_fifo: DEPTH must be >= 1")
  end
  if (WIDTH < 1) begin : g_err_width_lt_1
    `SFC_CFG_FATAL("sf_sramc_fifo: WIDTH must be >= 1")
  end

  logic [WIDTH-1:0] mem [DEPTH];
  logic [PW-1:0]    rp_q, wp_q;
  logic [CW-1:0]    cnt_q;

  assign count = cnt_q;
  assign empty = (cnt_q == '0);
  assign full  = (cnt_q == CW'(DEPTH));
  assign pop_data = mem[rp_q];

  wire do_pop  = pop && !empty;
  wire do_push = push && (!full || do_pop);

  assign overflow  = push && full && !do_pop;
  assign underflow = pop && empty;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rp_q  <= '0;
      wp_q  <= '0;
      cnt_q <= '0;
    end else begin
      if (do_pop)  rp_q <= (rp_q == PW'(DEPTH - 1)) ? '0 : rp_q + 1'b1;
      if (do_push) wp_q <= (wp_q == PW'(DEPTH - 1)) ? '0 : wp_q + 1'b1;
      if (do_push && !do_pop)      cnt_q <= cnt_q + 1'b1;
      else if (do_pop && !do_push) cnt_q <= cnt_q - 1'b1;
    end
  end

  always_ff @(posedge clk) begin
    if (do_push) mem[wp_q] <= push_data;
  end
endmodule

`default_nettype wire
