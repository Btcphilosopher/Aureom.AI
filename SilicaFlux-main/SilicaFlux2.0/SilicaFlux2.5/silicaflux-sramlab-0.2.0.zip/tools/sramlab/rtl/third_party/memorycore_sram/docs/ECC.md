# ECC - SECDED (137,128) per 128-bit line

Labels: behaviour below is checked by RTL-SIMULATION against an **independent Python reference** (`tools/ecc/secded_ref.py`, which shares no code with the RTL codec) and by
exhaustive single/double-error sweeps. Error *rates* of real SRAM are out of scope - no soft-error or hard-fault statistics from silicon exist in this repository.

## 1. Code

* Extended Hamming (single-error-correct, double-error-detect) over the **whole 128-bit line**: `K = 128` data bits, `R = 8` Hamming check bits + 1 overall parity bit = **137 stored bits per line** (`STORE_W`). The leaf codec
  (`sf_ecc_enc` / `sf_ecc_dec` wrap the reused `third_party/ras_secded` cells) is parametric in `K`; `K = 32, 64, 128` are tested.
* Check-bit inversion (library default): an **all-zero stored word decodes as uncorrectable**, so a row that was never written or initialised cannot be read as valid data.
* Decoder classes: `none`, `CE` (single-bit error: corrected, `rsp_ce = 1`), `UE` (double-bit or detected multi-bit error: `rsp_status = SF_ST_ECC_UE`; `rdata` is the stored, uncorrected data and is never to be treated as valid).
* Guarantee of the code (theory, verified exhaustively for 1- and 2-bit errors): every 1-bit error is corrected, every 2-bit error is detected. **3-bit errors are outside the guarantee** - see section 4.

## 2. Datapath (`rtl/sf_sram_bank.sv`, `ECC_EN = 1`)

| operation | behaviour |
|---|---|
| full-line write | encoded and written, one array cycle. Never reads the old line, so it **repairs** an uncorrectable line |
| read | decoded; 1-bit error corrected on the way (and counted); UE flagged |
| **partial write** (0 < be < all ones) | the check bits cover the whole line, so the bank performs an **atomic read-modify-write**: read, decode + correct, merge the written bytes, re-encode, write back. The bank accepts nothing else meanwhile (bank busy `READ_LATENCY + 1` cycles) - no other master can see or change the line in between |
| partial write on an **uncorrectable** old line | **aborted**: line left as found, response `SF_ST_ECC_UE` (the bytes the old line would contribute are unknown) |
| `be == 0` write | acknowledged no-op |
| `BANK_LAT` | `READ_LATENCY + 1` (the decode stage) |

## 3. Maintenance and observability

* **Init engine** (`INIT_ON_RESET`, `init_start_i`): writes every row with the all-zero line and valid ECC, one row per cycle, while `req_ready = 0`. The array is never reset (a reset would prevent RAM inference); initialisation is an explicit operation.
* **Scrubber** (`SCRUB_EN`, `scrub_en_i`): at most one step per `SCRUB_WAIT` cycles, started only in a cycle in which no request is presented to the bank. It reads one row (round robin), writes it back corrected if a 1-bit error is found (counted as a CE) and reports UEs without touching them.
* **Counters** (`sf_ecc_counters`): saturating `ce_cnt` / `ue_cnt`, first-error address capture, synchronous clear (`ecc_clr_i`); per-bank event pulses `ev_ce_o` / `ev_ue_o`.
* **Fault injection** (simulation only, `FAULT_INJECT = 1`): one-shot bit flip in the stored word (SEU), stuck-at cell, used by the tests below. Removed completely from synthesizable builds.

## 4. Verification (RTL-SIMULATION)

| test | what is checked | result file |
|---|---|---|
| `tb/tb_ecc_codec.sv`, K = 128 / 64 / 32 | encoder against Python golden codewords (`tb/vectors/`, produced by `tools/ecc/secded_ref.py`); decoder: every single-bit error of every vector, every double-bit pair of the first 24 vectors, and weight 1-6 error words compared with the **reference decoder's verdict** (class and data), which includes the weight-3 miscorrections and weight-4 aliasing; all-zero word -> uncorrectable | `sim/run_ecc_codec.sh`, `reports/ecc_codec.log`: K=128 392,786 checks (51,200 data + 3,600 check-bit single errors corrected, 223,584 double errors detected), K=64 106,946 checks, K=32 30,686 checks, 0 errors |
| `tb/tb_ecc_system.sv` E1-E8 | through the whole controller path: every one of the 137 stored bit positions flipped and read back (E1: corrected data, `rsp_ce`, counter); double errors flagged and data not presented as valid (E2); partial write onto a 1-bit-error line corrects and cleans (E3); partial write onto a UE line aborts, full write repairs (E4); scrubber (E5); stuck-at hard fault never visible functionally (E6); randomized soak with a byte-accurate model (E7); 3-bit statistics (E8) | `reports/regress_ecc.json` (3 cases: 2 banks / RL 1, 2 banks / RL 2, 4 banks / RL 3), `reports/regress_ctrl.json` (ECC controller configurations) |
| formal (bounded, `formal/`) | `ecc` configuration of the controller property set, depth 20 (see `docs/VERIFICATION.md` for the result) | `reports/formal.json` |
| mutation (`tools/mutate.py`) | mutants of the ECC bank path (see the mutant list in `tools/mutate.py`) | `reports/mutation*.json` |

**Characterised limitation (E8):** with 3 bits flipped in one stored word the distance-4 code is **not** guaranteed to flag the error. The reproducible campaign in `tb_ecc_system`
(300 triple-error cases, deterministic seed) found **57 flagged as UE and 243 silently miscorrected** (the syndrome of an odd-weight pattern looks like a single-bit error, so a wrong bit is "corrected"). That is the known
behaviour of any SEC-DED code and is stated here rather than hidden; mitigation needs a stronger code (DEC-TED) or interleaving, neither of which is implemented.

## 5. Costs (MODEL, assumed parameters - see `power/` and `reports/sramlab_energy.md`)

* Storage overhead 9 / 128 = 7.0 % (137 vs 128 columns); with the SKY130 macro tiling this is **not** free (`physical/area_report.md`: 85.6 % bit utilisation for the uniform tiling).
* Throughput: partial writes cost `1/(READ_LATENCY+1)` of a bank cycle (measured ratio 0.501 at RL=1, 0.335 at RL=2 for the partial-write benchmark - `docs/BENCHMARKS.md`); reads and full writes keep one access per cycle but add one cycle of latency.
* Logic (Yosys generic gates, `reports/synthesis.md`): `sf_ecc_enc` 314 cells, `sf_ecc_dec` 1389 cells (K = 128).
