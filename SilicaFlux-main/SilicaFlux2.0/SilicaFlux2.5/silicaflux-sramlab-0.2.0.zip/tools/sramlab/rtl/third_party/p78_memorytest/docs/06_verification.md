# 06 - Verification plan, results and test-coverage report

Everything here is **RTL simulation** (Verilator 5.020, Icarus Verilog 12) plus one Yosys 0.33 elaboration smoke test.  Exact, regenerated
numbers live in `reports/` (`regression.md`, `coverage.md/json`, `mutation.md/json`, `code_coverage.md`, `lint.md`); this document explains
what they mean and what they do not.  Run `make regress` (minutes) or `make regress-full` (adds the exhaustive fault campaign and mutation testing).

## 1. Layers

| Layer | Testbench / tool | What it establishes |
|---|---|---|
| Unit: March C- on **one bank** (Phase 1) | `tb_p1_march_one_bank` | engine + arbiter + failure register wired straight to one fault-model bank: exact `10 N` operations, bus trace == independent golden March C-, ten hand-derived first-failure signatures, windows, MATS+, all backgrounds; `READ_LATENCY` 1..4, `ROWS` 12..20, `STORE_W` 8..137 |
| System | `tb_sf_sram_mbist` (S01-S18) | the real top: selection, arbiter, live traffic, refusals, interruption, reset, diagnostics, RAS, repair, pins, register errors; safety monitors on every cycle |
| Real memory stack | `tb_mbist_memorycore` (M01-M09) | the unmodified MemoryCore `sf_sram_controller` / `sf_sram_bank` / `sf_sram_core`, ECC on and off, two live masters with a scoreboard, MemoryCore's own fault models |
| Fault-coverage campaign | `tb_mbist_cov` + `sim/run_coverage.py` | detection of an enumerated fault population (979 118 + 60 654 MBIST runs), localisation, reproducibility, theory cross-check |
| Mutation testing | `sim/run_mutants.py` | 41 injected RTL bugs; can the testbenches tell? |
| RTL code coverage | `sim/code_coverage.py` | how much of the RTL the tests execute |
| Static | Verilator `-Wall`, Yosys 0.33 `synth` | lint clean; elaborates and synthesizes with no inferred latch |
| Documentation | `sim/run_regress.py` | the register map in `docs/03` equals the RTL (48 registers) |

## 2. Required verification items -> evidence

| Required item | Evidence | Result |
|---|---|---|
| Fault-free memory | P1.1; S03 (every selection); M02 (real stack, with live traffic); coverage campaigns: 0 false alarms over every configuration | PASS |
| Every supported fault type | P1.3 (SAF0/1, TF up/down, AF none / alias / multi, CFin, CFid, CFst: first-failure signature asserted); S05; M04 (MemoryCore's 8 `SF_FT_*` types on real RTL); coverage: March C- **100 %** of SAF / TF / AF / every inter-word coupling fault, exhaustively | PASS |
| Failure detection and reporting | S04 (bank / row / bit / element / polarity / class / expected ^ observed, per bank, two faulty banks), S06 (record, FIFO, counters, overflow, alias diagnosis, check-column flag) | PASS |
| March traversal order | P1.1 golden-trace comparison (element order, ascending / descending, op order, write data) incl. windows and MATS+; S03 bank order ascending, each bank entered once | PASS |
| Multiple banks | S03 (BANK / SEQ / ALL / SHARED / TENSOR / VECTOR, accessible and not), S04, M02-M04 | PASS |
| Test interruption | S13: abort mid-run, abort / permission loss while waiting for the acknowledge or the drain, permission loss mid-run, DFT inhibit mid-run, stop-on-fail (also with a sweep), watchdog; M07 on the real controller; **every case re-initialises and the scoreboard stays clean** | PASS |
| Reset | S14 (reset mid-test: clean idle state; hazard H3 demonstrated both without and with platform init-on-reset); M08 (real controller: ECC builds re-initialise, non-ECC builds are dirty) | PASS |
| ECC interaction | M02 (raw bus leaves CE / UE counters untouched), M05 (concealment of a single stuck bit by ECC vs. detection by the raw test; check-column defect invisible to a data-only compare), M06 (every line valid after a test, no error status, no correction), M08 | PASS |
| Completion signalling | S10: `busy / done / pass / fail / error` in every outcome, held until the next start / clear, `done` falls on the next start | PASS |
| Diagnostic register readback | S01, S06 (first record, head record, FIFO pop / preservation, counters, masks, per-bank counts), S15, S16, S18 (error responses, W1C), `docs` check | PASS |
| **Unsafe functional access prevented** | monitors over *every* cycle of every run: `tst_ce` only while `tst_active & permit` (0 violations); `tst_active` never with an in-flight or accepted functional access, never without quiesce, never before the acknowledge; no functional access accepted while quiesced; real stack: ownership only taken when the controller is idle, no functional access accepted during the test.  Plus S11 (slow acknowledge / drain, **rogue master**), S12 (timeouts) | PASS |

## 3. Results

See `reports/regression.md` for the per-configuration list (currently **all green**: lint, unit x 8, system x 6, MemoryCore integration x 8,
Yosys x 2, docs check; and, with `--full`, the coverage campaign and mutation testing).  Headline figures:

* **System testbench**: 1 324 - 1 357 checks per configuration, five configurations (all four banks accessible / bank 3 without a test port, latency 1..3 with a
  test-path pipe stage, non-power-of-two depth, no check columns) plus an Icarus run (1 339 checks).  Unit testbench: 120 checks per configuration x 7 shapes + Icarus.
* **Real stack**: 290 checks (ECC, 39-bit stored word) / 265 checks (no ECC); Verilator `-O0` and Icarus, `READ_LATENCY` 1 and 2.
* **Fault coverage** (`reports/coverage.md`, exhaustive): see `docs/02` section 2 and `docs/04` section 3.  March C-: SAF / TF / AF / inter-word coupling 100 %,
  every single-cell fault located exactly; MATS+ visibly weaker (it misses TF-down by construction); same-word coupling: solid 60 %, solid U checkerboard 80.65 % (matches
  MemoryCore's own measurement digit for digit), sweep 100 %.
* **Mutation**: 39 / 41 killed; the two survivors are explained equivalents (`reports/mutation.md`).
* **Code coverage**: `reports/code_coverage.md` - **93.7 % of line / branch points** (327 / 349) and 52.7 % of toggle bits over the nine RTL files, with every unreached
  statement listed and explained in section 6.

## 4. Defects the verification itself found (and how they were resolved)

Listing these is the point: they are the evidence that the checks can fail.

| # | Found by | Defect | Resolution |
|---|---|---|---|
| 1 | system TB S02 | `ROW_HI` was stored in `ROW_W` bits: writing `ROWS` **silently wrapped to 0** and ran a one-row test instead of being refused | window registers widened to 32 bit and validated against `ROWS` |
| 2 | design of the real-stack TB | intrusion probe on raw `valid` would raise false intrusions for every legitimately back-pressured master | probe redefined on **accepted** requests (or valid after the acknowledge); stub master made quiesce-aware; a "no false intrusion" check added (S11) |
| 3 | unit TB under Icarus | testbench race: `done` of the previous run seen as completion of the new one | TB waits for `busy` to rise first |
| 4 | system TB | scoreboard compared a read against a reference updated by a write accepted in the next cycle | expectation captured at accept time; ready masked during the model's init-completion edge |
| 5 | real-stack TB | monitor used `idle_o` throughout a test, but `idle_o` is legitimately low while test operations are in flight | check moved to the moment ownership is **taken** |
| 6 | two simulators disagreeing | Verilator's default build mis-simulates MemoryCore's CFST fault model in the integrated build | real-stack TB built at `-O0` and cross-run on Icarus (section 5) |
| 7 | mutation testing | no check of the reported bit for a multi-bit failure; the W1C test cleared flags that were already clear | both checks added; both mutants now die |
| 8 | code coverage | no test of permission loss / abort while waiting for the acknowledge or the drain, stop-on-fail inside a multi-pass run, RAS event collision, multi-column repair allocation, 12 registers never read | tests added (S06, S13, S15, S16) |

## 5. Tool findings

**Verilator 5.020 and MemoryCore's CFST fault model (found while running the real stack).**  With the vendored, byte-identical `sf_sram_core`
(`FAULT_INJECT = 1`) inside the integrated design (39-bit stored word), a state-coupling (CFST) fault was *not* detected in the default Verilator build, while Icarus detected it.
Isolation: (a) the stored contents, the fault descriptors and the core's own port values were identical in both simulators at the failing read; (b) the core in isolation behaves
identically in both at widths 32 / 39 / 40 / 64; (c) an instrumented *copy* of the core printing the CFST condition showed the condition and the forced value computed correctly
inside Verilator, and that instrumented build detected the fault; (d) building the original at `-O0` detected it, `-O3` and the default did not.  Conclusion: Verilator's optimiser
changes the outcome; analysis says detection is correct (the aggressor holds 1 during the victim's `r0`).  Not reduced to an upstream bug report.  The regression builds the
MemoryCore integration at `-O0` and requires Icarus to agree.  The project's own testbenches pass in both simulators at default optimisation.

**Icarus 12** prints `constant selects in always_* processes are not currently supported` for `sf_mbist_regs.sv` (conservative sensitivity, no result difference).  **Yosys 0.33** does not
accept `int'(...)` casts (found and fixed: the repository's own RTL avoids them for the same reason).

## 6. RTL code coverage - what is and is not reached

`reports/code_coverage.md` merges every run by source location.  Statements that no run reaches, by reason:

* **Saturation guards** of the 32-bit failure counter, the 16-bit per-bank counters, the FIFO-lost counter, the RAS-lost counter and the intrusion counter: reaching them needs 2^16 .. 2^32 events;
  the logic is a compare and an increment.
* **`default:` recovery states** and the `INTERNAL` consistency check (`tested != mask` at a would-be PASS): unreachable by construction; they exist so that a corrupted state can never produce a PASS.
* **One-cycle windows**: permission loss / abort exactly in the single `OWN1` cycle, and abort exactly in the one-cycle `BSEL` / `PINIT` states.  Hitting them deterministically needs an event
  aligned to a specific clock; the multi-cycle neighbours (`QUIESCE`, `DRAIN`, `OWNED`, `RUN`) are tested.
* **RAS collision of a first-failure or summary event**: those events occur once per run and cannot collide; only the error-flag collision path is reachable (and is tested).
  The `lost`-counter saturation sub-branch of that line is among the saturation guards above.
* **Redundancy-allocation loop fall-through** (`sf_mbist_repair.sv`): the "slot already taken" iteration of the spare-column search is partially exercised (both
  columns are allocated and checked, but not every loop-iteration path is hit).

Toggle coverage is reported but is a weak indicator here (wide registers whose high bits never change in small instances).
