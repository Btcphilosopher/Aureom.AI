// =============================================================================
// SilicaFlux MemoryTest (Project 78) :: sf_mbist_defs.svh
// Constants shared by every sf_mbist_* module.  A `define header and not a
// package: the repository's tool-portability rule (Yosys 0.33 cannot resolve
// package references in parameter lists; see SilicaFlux MemoryCore
// third_party/PROVENANCE.md) applies to all synthesizable RTL here.
// Values are part of the register / pin contract (docs/03_register_map.md):
// never renumber, only append.
// =============================================================================
`ifndef SF_MBIST_DEFS_SVH
`define SF_MBIST_DEFS_SVH

// ------------------------------------------------------------ algorithms (cfg_algo)
`define MB_ALG_MARCH_CM   4'd0   // March C-  : {B(w0); U(r0,w1); U(r1,w0); D(r0,w1); D(r1,w0); B(r0)}  10N
`define MB_ALG_MATS_P     4'd1   // MATS+     : {B(w0); U(r0,w1); D(r1,w0)}                              5N

// ------------------------------------------------------------ data backgrounds (cfg_pattern)
// "0" of a March element = background B(row); "1" = ~B(row).  Definitions: rtl/sf_mbist_pattern.sv
`define MB_PAT_ALL0       3'd0   // B = 0
`define MB_PAT_ALL1       3'd1   // B = all ones (complementary start state)
`define MB_PAT_ALT        3'd2   // B[i] = i[0]                (0101.. across the word; == STRIPE k=0)
`define MB_PAT_CHECKER    3'd3   // B[i] = i[0] ^ row[0]       (ALT, inverted on odd rows)
`define MB_PAT_ADDR       3'd4   // B[i] = row[i mod AW] ^ ((i / AW) & 1)   (address-dependent, diagnosis of decoder faults)
`define MB_PAT_STRIPE     3'd5   // B[i] = (i >> k) & 1, k = cfg_stripe_k (intra-word coupling coverage; see docs/02)

// ------------------------------------------------------------ column selection (cfg_colsel): which stored columns are COMPARED
`define MB_COL_ALL        2'd0   // every stored column (data + ECC check columns when present)
`define MB_COL_DATA       2'd1   // data columns only        (bits < DATA_W)
`define MB_COL_CHECK      2'd2   // check columns only       (bits >= DATA_W; needs STORE_W > DATA_W)

// ------------------------------------------------------------ memory selection (cfg_sel)
`define MB_SEL_BANK       3'd0   // one bank: cfg_bank
`define MB_SEL_SEQ        3'd1   // sequential banks: cfg_bmask, ascending index, one at a time
`define MB_SEL_ALL        3'd2   // all physically accessible banks (ACCESS_MASK), ascending
`define MB_SEL_SHARED     3'd3   // banks of the shared SRAM (SHARED_MASK)
`define MB_SEL_TENSOR     3'd4   // banks backing tensor scratchpads (TENSOR_MASK)
`define MB_SEL_VECTOR     3'd5   // banks backing vector scratchpads (VECTOR_MASK)

// ------------------------------------------------------------ run result
`define MB_RES_NONE       3'd0   // no run since reset / clear
`define MB_RES_PASS       3'd1   // every selected bank completed, no miscompare, no error
`define MB_RES_FAIL       3'd2   // at least one miscompare
`define MB_RES_ABORTED    3'd3   // aborted by command; NOT a pass
`define MB_RES_ERROR      3'd4   // ownership fault, watchdog, permission loss, internal error; NOT a pass
`define MB_RES_REFUSED    3'd5   // start refused, memory never touched; NOT a pass

// ------------------------------------------------------------ failure classification (symptom based; see docs/02 section 7)
`define MB_CLS_NONE       4'd0
`define MB_CLS_1TO0_BIT   4'd1   // single bit, expected 1 read 0 : stuck-at-0 OR up-transition fault (March cannot separate them)
`define MB_CLS_0TO1_BIT   4'd2   // single bit, expected 0 read 1 : stuck-at-1 OR down-transition fault (same remark)
`define MB_CLS_MULTI_1TO0 4'd3   // >=2 bits, all expected 1 read 0
`define MB_CLS_MULTI_0TO1 4'd4   // >=2 bits, all expected 0 read 1
`define MB_CLS_MULTI_MIX  4'd5   // >=2 bits, both directions
`define MB_CLS_ALL_BITS   4'd6   // every compared bit wrong (data-line / read-path inversion, whole-word decoder fault)
`define MB_CLS_ADDR_ALIAS 4'd7   // ADDR pattern: observed word is the pattern of ANOTHER row (alias_row)

// ------------------------------------------------------------ sticky error flag bit positions (ERR_FLAGS register)
`define MB_ERR_NO_PERMIT      0   // start refused: test mode / permission absent (or memory inhibit)
`define MB_ERR_BAD_CFG        1   // start refused: invalid configuration
`define MB_ERR_EMPTY_SEL      2   // start refused: selection resolves to no bank
`define MB_ERR_NOT_ACCESSIBLE 3   // start refused: selection includes a bank without a raw test port
`define MB_ERR_PROTECTED      4   // start refused: bank is protected (live CPU state) and CPU not halted
`define MB_ERR_RESULT_PENDING 5   // start refused: unread failure data present (CLEAR it, or use START_CLR)
`define MB_ERR_CMD_BUSY       6   // START / CLEAR while a run is active (ignored)
`define MB_ERR_OWN_TIMEOUT    7   // quiesce / drain did not complete in time (OWNER_FAULT)
`define MB_ERR_REINIT_TIMEOUT 8   // re-initialisation did not complete: memory content undefined
`define MB_ERR_PERM_LOSS      9   // permission / test mode lost during a run
`define MB_ERR_INTRUSION      10  // a functional request was ACCEPTED / presented after the quiesce acknowledge while MBIST owned the memory (blocked by the group)
`define MB_ERR_WDOG           11  // run watchdog expired
`define MB_ERR_REINIT_REQ     12  // memory released while dirty and NOT re-initialised: software must initialise it
`define MB_ERR_FIFO_LOST      13  // failure FIFO overflowed (first record and counters still exact)
`define MB_ERR_RAS_LOST       14  // RAS event could not be queued (counted)
`define MB_ERR_ABORTED        15  // run aborted by command
`define MB_ERR_INTERNAL       16  // internal consistency check failed (never expected)
`define MB_NERR               17

// ------------------------------------------------------------ RAS event sub-kinds (ev_info[30:28])
`define MB_EVK_FIRST_FAIL 3'd1
`define MB_EVK_SUMMARY    3'd2
`define MB_EVK_ERROR      3'd3
`define MB_EVK_INTRUSION  3'd4
`define MB_EVK_REINIT     3'd5

// ------------------------------------------------------------ configuration errors (elaboration time)
`ifdef __ICARUS__
  `define MB_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define MB_CFG_FATAL(msg) $fatal(1, msg);
`endif

`endif // SF_MBIST_DEFS_SVH
