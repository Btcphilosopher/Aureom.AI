// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_failreg   (failure capture, classification, diagnostic storage)
//
// One miscompare per cycle at most arrives from the engine's compare stage (f_valid_i).  For each one this module
//   * computes the syndrome  syn = (expected ^ observed) & compare_mask
//   * derives bit index (lowest set bit), bit_valid (syndrome has EXACTLY one bit), in_check (bit >= DATA_W)
//   * classifies the SYMPTOM (rtl/sf_mbist_defs.svh MB_CLS_*; docs/02 section 7).  Classification names what was
//     observed, not a proven root cause: March C- cannot separate SA0 from up-transition faults.
//   * stores   FIRST record  : frozen at the first miscompare of the run
//              FIFO          : the first FIFO_DEPTH records in arrival order (pop with pop_i)
//              counters      : fail_count (32 bit, saturating, EVERY failing compare), per-bank 16-bit counts,
//                              bank_fail_mask, col_fail_mask (OR of all syndromes: columns that ever failed)
//
// Preservation rule (documented interface): everything above is held until clr_i (CLEAR command, or an accepted
// START) or reset.  pop_i only advances the FIFO read pointer: the first record, counters and masks are NOT
// consumed by reading, so a host can read them repeatedly.  When the FIFO is full a new record is NOT stored
// and is counted in lost_o (never silent); counters and the first record stay exact.  pending_o says "unread
// failure data exists": the engine refuses a new START while it is set (the host must CLEAR first).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_mbist_defs.svh"
`default_nettype none

module sf_mbist_failreg #(
  parameter int NBANK      = 4,
  parameter int AW         = 6,
  parameter int W          = 32,
  parameter int DATA_W     = 32,
  parameter int FIFO_DEPTH = 4,
  parameter int BW         = (NBANK > 1) ? $clog2(NBANK) : 1,
  parameter int BITW       = (W > 1) ? $clog2(W) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clr_i,
  input  wire logic              pop_i,
  // ---- from the engine compare stage
  input  wire logic              f_valid_i,
  input  wire logic [BW-1:0]     f_bank_i,
  input  wire logic [AW-1:0]     f_row_i,
  input  wire logic [2:0]        f_elem_i,
  input  wire logic              f_op_i,
  input  wire logic              f_pol_i,
  input  wire logic [3:0]        f_pass_i,
  input  wire logic [2:0]        f_pat_i,
  input  wire logic [W-1:0]      f_exp_i,
  input  wire logic [W-1:0]      f_obs_i,
  input  wire logic [W-1:0]      f_mask_i,
  // ---- combinational syndrome of the incoming miscompare (for the repair analyser)
  output logic [W-1:0]           syn_o,
  // ---- FIRST record
  output logic                   first_valid_o,
  output logic [BW-1:0]          first_bank_o,
  output logic [AW-1:0]          first_row_o,
  output logic [BITW-1:0]        first_bit_o,
  output logic                   first_bit_v_o,
  output logic                   first_in_check_o,
  output logic [2:0]             first_elem_o,
  output logic                   first_op_o,
  output logic                   first_pol_o,
  output logic [3:0]             first_pass_o,
  output logic [3:0]             first_cls_o,
  output logic [AW-1:0]          first_alias_o,
  output logic [W-1:0]           first_exp_o,
  output logic [W-1:0]           first_obs_o,
  // ---- FIFO head record
  output logic                   head_valid_o,
  output logic [BW-1:0]          head_bank_o,
  output logic [AW-1:0]          head_row_o,
  output logic [BITW-1:0]        head_bit_o,
  output logic                   head_bit_v_o,
  output logic                   head_in_check_o,
  output logic [2:0]             head_elem_o,
  output logic                   head_op_o,
  output logic                   head_pol_o,
  output logic [3:0]             head_pass_o,
  output logic [3:0]             head_cls_o,
  output logic [AW-1:0]          head_alias_o,
  output logic [W-1:0]           head_exp_o,
  output logic [W-1:0]           head_obs_o,
  // ---- counters / masks
  output logic [31:0]            fail_count_o,
  output logic [15:0]            fifo_count_o,
  output logic [15:0]            fifo_lost_o,
  output logic [NBANK*16-1:0]    bank_cnt_o,
  output logic [NBANK-1:0]       bank_fail_mask_o,
  output logic [W-1:0]           col_fail_mask_o,
  output logic                   pending_o,
  output logic                   evt_first_o,        // 1-cycle pulse when the first record is captured
  output logic                   evt_fifo_lost_o     // 1-cycle pulse when a record is dropped
);
  localparam int PCW = $clog2(W + 1);

  // ------------------------------------------------------------ syndrome and classification (combinational)
  logic [W-1:0]    syn;
  logic [PCW-1:0]  pc;
  logic [BITW-1:0] lo_idx;
  always_comb begin
    syn    = (f_exp_i ^ f_obs_i) & f_mask_i;
    pc     = '0;
    lo_idx = '0;
    for (int i = W - 1; i >= 0; i--) begin
      if (syn[i]) begin pc = pc + 1'b1; lo_idx = BITW'(i); end
    end
  end
  assign syn_o = syn;

  // alias diagnosis (ADDR background only): observed word == pattern of another row
  localparam bit ALIAS_CAPABLE = (W >= AW);
  wire [AW-1:0]  alias_row;
  logic [W-1:0]  alias_pat;
  logic          alias_ok;
  if (ALIAS_CAPABLE) begin : g_alias_row
    assign alias_row = f_obs_i[AW-1:0] ^ {AW{f_pol_i}};
  end else begin : g_no_alias_row
    assign alias_row = '0;
  end
  sf_mbist_pattern #(.W(W), .AW(AW)) u_alias_pat (
    .pattern_i(`MB_PAT_ADDR), .stripe_k_i(4'd0), .row_i(alias_row), .pol_i(f_pol_i), .data_o(alias_pat));
  assign alias_ok = ALIAS_CAPABLE && (f_pat_i == `MB_PAT_ADDR) && (pc >= PCW'(2)) && (alias_row != f_row_i) &&
                    (((alias_pat ^ f_obs_i) & f_mask_i) == '0);

  logic [3:0] cls;
  always_comb begin
    if (alias_ok)                                   cls = `MB_CLS_ADDR_ALIAS;
    else if (pc == PCW'(1))                         cls = f_exp_i[lo_idx] ? `MB_CLS_1TO0_BIT : `MB_CLS_0TO1_BIT;
    else if (pc >= PCW'(2) && syn == f_mask_i)      cls = `MB_CLS_ALL_BITS;
    else if ((syn & ~f_exp_i) == '0)                cls = `MB_CLS_MULTI_1TO0;
    else if ((syn & f_exp_i) == '0)                 cls = `MB_CLS_MULTI_0TO1;
    else                                            cls = `MB_CLS_MULTI_MIX;
  end

  // ------------------------------------------------------------ record layout (LSB first)
  localparam int O_BANK = 0;
  localparam int O_ROW  = O_BANK + BW;
  localparam int O_BIT  = O_ROW + AW;
  localparam int O_BV   = O_BIT + BITW;
  localparam int O_INC  = O_BV + 1;
  localparam int O_ELEM = O_INC + 1;
  localparam int O_OP   = O_ELEM + 3;
  localparam int O_POL  = O_OP + 1;
  localparam int O_PASS = O_POL + 1;
  localparam int O_CLS  = O_PASS + 4;
  localparam int O_ALI  = O_CLS + 4;
  localparam int O_EXP  = O_ALI + AW;
  localparam int O_OBS  = O_EXP + W;
  localparam int REC_W  = O_OBS + W;

  wire              bit_v_in = (pc == PCW'(1));
  wire              inc_in   = bit_v_in && (32'(lo_idx) >= DATA_W);
  wire [AW-1:0]     ali_in   = alias_ok ? alias_row : '0;
  // MSB-first concatenation == the LSB-first offsets above
  wire [REC_W-1:0]  rec_in   = {f_obs_i & f_mask_i, f_exp_i & f_mask_i, ali_in, cls, f_pass_i, f_pol_i, f_op_i,
                                f_elem_i, inc_in, bit_v_in, lo_idx, f_row_i, f_bank_i};

  // ------------------------------------------------------------ storage
  logic [REC_W-1:0] first_q;
  logic [REC_W-1:0] fifo_q [FIFO_DEPTH];
  logic [15:0]      wr_q, rd_q, cnt_q, lost_q;
  logic [31:0]      total_q;
  logic [NBANK*16-1:0] bank_cnt_q;
  logic [NBANK-1:0] bank_mask_q;
  logic [W-1:0]     col_q;
  logic             first_v_q;

  wire push = f_valid_i && (cnt_q != 16'(FIFO_DEPTH));
  wire drop = f_valid_i && (cnt_q == 16'(FIFO_DEPTH));
  wire popv = pop_i && (cnt_q != 16'd0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      first_v_q <= 1'b0; first_q <= '0; wr_q <= '0; rd_q <= '0; cnt_q <= '0; lost_q <= '0;
      total_q <= '0; bank_cnt_q <= '0; bank_mask_q <= '0; col_q <= '0;
      evt_first_o <= 1'b0; evt_fifo_lost_o <= 1'b0;
    end else begin
      evt_first_o <= 1'b0; evt_fifo_lost_o <= 1'b0;
      if (clr_i) begin
        first_v_q <= 1'b0; wr_q <= '0; rd_q <= '0; cnt_q <= '0; lost_q <= '0;
        total_q <= '0; bank_cnt_q <= '0; bank_mask_q <= '0; col_q <= '0;
      end else begin
        if (f_valid_i) begin
          if (!first_v_q) begin first_v_q <= 1'b1; first_q <= rec_in; evt_first_o <= 1'b1; end
          if (total_q != 32'hFFFF_FFFF) total_q <= total_q + 1'b1;
          if (bank_cnt_q[f_bank_i*16 +: 16] != 16'hFFFF)
            bank_cnt_q[f_bank_i*16 +: 16] <= bank_cnt_q[f_bank_i*16 +: 16] + 1'b1;
          bank_mask_q[f_bank_i] <= 1'b1;
          col_q <= col_q | syn;
        end
        if (push) begin
          fifo_q[32'(wr_q) % FIFO_DEPTH] <= rec_in;
          wr_q <= (wr_q == 16'(FIFO_DEPTH - 1)) ? 16'd0 : wr_q + 1'b1;
        end
        if (drop) begin
          if (lost_q != 16'hFFFF) lost_q <= lost_q + 1'b1;
          evt_fifo_lost_o <= 1'b1;
        end
        if (popv) rd_q <= (rd_q == 16'(FIFO_DEPTH - 1)) ? 16'd0 : rd_q + 1'b1;
        cnt_q <= cnt_q + 16'(push) - 16'(popv);
      end
    end
  end

  // ------------------------------------------------------------ outputs
  logic [REC_W-1:0] head_r;
  assign head_r = fifo_q[32'(rd_q) % FIFO_DEPTH];

  assign first_valid_o    = first_v_q;
  assign first_bank_o     = first_q[O_BANK +: BW];
  assign first_row_o      = first_q[O_ROW  +: AW];
  assign first_bit_o      = first_q[O_BIT  +: BITW];
  assign first_bit_v_o    = first_q[O_BV];
  assign first_in_check_o = first_q[O_INC];
  assign first_elem_o     = first_q[O_ELEM +: 3];
  assign first_op_o       = first_q[O_OP];
  assign first_pol_o      = first_q[O_POL];
  assign first_pass_o     = first_q[O_PASS +: 4];
  assign first_cls_o      = first_q[O_CLS  +: 4];
  assign first_alias_o    = first_q[O_ALI  +: AW];
  assign first_exp_o      = first_q[O_EXP  +: W];
  assign first_obs_o      = first_q[O_OBS  +: W];

  assign head_valid_o     = (cnt_q != 16'd0);
  assign head_bank_o      = head_r[O_BANK +: BW];
  assign head_row_o       = head_r[O_ROW  +: AW];
  assign head_bit_o       = head_r[O_BIT  +: BITW];
  assign head_bit_v_o     = head_r[O_BV];
  assign head_in_check_o  = head_r[O_INC];
  assign head_elem_o      = head_r[O_ELEM +: 3];
  assign head_op_o        = head_r[O_OP];
  assign head_pol_o       = head_r[O_POL];
  assign head_pass_o      = head_r[O_PASS +: 4];
  assign head_cls_o       = head_r[O_CLS  +: 4];
  assign head_alias_o     = head_r[O_ALI  +: AW];
  assign head_exp_o       = head_r[O_EXP  +: W];
  assign head_obs_o       = head_r[O_OBS  +: W];

  assign fail_count_o     = total_q;
  assign fifo_count_o     = cnt_q;
  assign fifo_lost_o      = lost_q;
  assign bank_cnt_o       = bank_cnt_q;
  assign bank_fail_mask_o = bank_mask_q;
  assign col_fail_mask_o  = col_q;
  assign pending_o        = (total_q != 32'd0) || (cnt_q != 16'd0) || (lost_q != 16'd0);
endmodule

`default_nettype wire
