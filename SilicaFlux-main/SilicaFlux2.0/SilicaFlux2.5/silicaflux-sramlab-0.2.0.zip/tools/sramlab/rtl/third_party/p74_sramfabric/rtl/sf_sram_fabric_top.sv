// =============================================================================
// SilicaFlux SRAMFabric (Project 74) :: sf_sram_fabric_top -- shared SRAM subsystem on the DataFabric
//
//   NoC masters (SFB3)                        direct local ports
//   M0 ControlCore   M1 DMA (burst)           VectorScratch  (sf_vector_scratchpad: vector / scalar / burst DMA)
//   M2 VectorTile    M3 TensorCore host       TensorScratch  (sf_tensor_scratchpad: A / B / C tiles, DMA port, ownership)
//        |                                          |
//   silicaflux_noc (crossbar, vendored, unmodified) |
//        | NTP SFB3 target ports (aliased windows)  |
//   sf_sram_datafabric (bridge) ---- NCP ports ---- +---- (VEC_LINES+1) + 4 ports ----> sf_sram_controller -> NB banks
//
// ONE controller serves everything, so the controller contract (CONTRACT.md O1-O8) holds across the NoC path and the local
// paths: a write acknowledged on one path is visible to a read accepted later on the other (O3, per line).
//
// ADDRESS PLAN (docs/MEMORY_MAP.md).  The controller aperture is [0, CAP) byte offsets.  The NoC window (WIN_BASE.., 2^WIN_LOG2
// bytes, an alias per target port) maps window offset == aperture offset, but the bridge only lets [0, SHARED_BYTES) through
// (ALLOW_HI): the part above is PRIVATE to the local scratchpads.  A NoC master that touches it gets ST_SLVERR / cause ADDR
// with no side effect, so the tensor ownership rules (enforced only on the scratchpad's own ports) cannot be bypassed from the
// fabric.  The local ports address the same aperture with the same offsets.
//
// Controller master ports: [0, NCP) bridge | [NCP, NCP+VEC_LINES] vector scratchpad (VEC_LINES vector ports + its DMA port)
//                          | next 4 tensor scratchpad (A, B, C, DMA).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sf_sdf_defs.svh"
`default_nettype none

module sf_sram_fabric_top #(
  parameter int            NM         = 4,              // NoC masters
  parameter int            AW         = 32,
  parameter int            DW         = 128,            // fabric data width
  parameter int            IDW        = 2,
  parameter int            NTP        = 1,
  parameter int            NP         = 1,
  parameter int            NB         = 4,
  parameter int            DEPTH      = 256,
  parameter int            READ_LATENCY = 1,
  parameter int            ECC_EN     = 0,
  parameter int            NSLOT      = 8,
  parameter logic [AW-1:0] SRAM_BASE  = 32'h2000_0000,
  parameter int            WIN_LOG2   = 20,
  parameter int            SHARED_BYTES = 8192,          // NoC-visible part of the aperture [0, SHARED_BYTES)
  parameter int            VEC_LINES  = 1,
  parameter int            VEC_IDW    = 4,
  parameter int            TEN_BASE_LINE = 640,           // tensor tile storage starts at line TEN_BASE_LINE (byte 16 * TEN_BASE_LINE)
  parameter int            TEN_NBUF   = 2,
  parameter int            TEN_ROWS   = 4,
  parameter int            REQ_REG    = 1,
  parameter int            RSP_REG    = 1,
  parameter int            TIMEOUT    = 1024,
  // ---- derived
  parameter int            LINE_W     = 128,
  parameter int            SRCW       = (NM > 1) ? $clog2(NM) : 1,
  parameter int            SB         = DW / 8,
  parameter int            LANEW      = (DW < LINE_W) ? $clog2(LINE_W / DW) : 1,
  parameter int            IDC        = 3 + SRCW + IDW + LANEW + 1,
  parameter int            NCP        = NTP * NP,
  parameter int            NPV        = VEC_LINES + 1,
  parameter int            NMC        = NCP + NPV + 4,
  parameter int            CAP_LINES  = NB * DEPTH,
  parameter int            BUFW       = (TEN_NBUF > 1) ? $clog2(TEN_NBUF) : 1,
  parameter int            TRW        = (TEN_ROWS > 1) ? $clog2(TEN_ROWS) : 1,
  parameter int            TLW        = $clog2(TEN_ROWS),
  parameter int            VW         = VEC_LINES * LINE_W
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // ---------------------------------------------------------------- NoC master ports (SFB3)
  input  wire logic [NM-1:0]         m_req_valid,
  output logic      [NM-1:0]         m_req_ready,
  input  wire logic [NM*3-1:0]       m_req_opcode,
  input  wire logic [NM*IDW-1:0]     m_req_id,
  input  wire logic [NM*3-1:0]       m_req_qos,
  input  wire logic [NM*AW-1:0]      m_req_addr,
  input  wire logic [NM*DW-1:0]      m_req_wdata,
  input  wire logic [NM*SB-1:0]      m_req_wstrb,
  output logic      [NM-1:0]         m_rsp_valid,
  input  wire logic [NM-1:0]         m_rsp_ready,
  output logic      [NM*IDW-1:0]     m_rsp_id,
  output logic      [NM*3-1:0]       m_rsp_opcode,
  output logic      [NM*2-1:0]       m_rsp_status,
  output logic      [NM*DW-1:0]      m_rsp_rdata,
  // ---------------------------------------------------------------- VectorScratch local port
  input  wire logic                  v_req_valid,
  output logic                       v_req_ready,
  input  wire logic                  v_req_we,
  input  wire logic [AW-1:0]         v_req_addr,
  input  wire logic [2:0]            v_req_size,
  input  wire logic                  v_req_sext,
  input  wire logic [VW-1:0]         v_req_wdata,
  input  wire logic [VEC_IDW-1:0]    v_req_id,
  output logic                       v_rsp_valid,
  input  wire logic                  v_rsp_ready,
  output logic [VW-1:0]              v_rsp_rdata,
  output logic [VEC_IDW-1:0]         v_rsp_id,
  output logic                       v_rsp_we,
  output logic [2:0]                 v_rsp_status,
  input  wire logic                  vdma_start_i,
  input  wire logic                  vdma_dir_i,
  input  wire logic [AW-1:0]         vdma_base_i,
  input  wire logic [15:0]           vdma_len_i,
  input  wire logic [AW-1:0]         vdma_stride_i,
  output logic                       vdma_busy_o,
  output logic                       vdma_done_o,
  output logic                       vdma_err_o,
  input  wire logic                  vdma_in_valid,
  output logic                       vdma_in_ready,
  input  wire logic [LINE_W-1:0]     vdma_in_data,
  output logic                       vdma_out_valid,
  input  wire logic                  vdma_out_ready,
  output logic [LINE_W-1:0]          vdma_out_data,
  // ---------------------------------------------------------------- TensorScratch local ports
  input  wire logic                  t_fill_req_i, t_fill_done_i,
  output logic                       t_fill_grant_o,
  output logic [BUFW-1:0]            t_fill_buf_o,
  input  wire logic                  t_te_req_i, t_te_done_i,
  output logic                       t_te_owned_o,
  output logic [BUFW-1:0]            t_te_buf_o,
  input  wire logic                  t_drain_req_i, t_drain_done_i,
  output logic                       t_drain_grant_o,
  output logic [BUFW-1:0]            t_drain_buf_o,
  output logic [TEN_NBUF*3-1:0]      t_buf_state_o,
  input  wire logic                  ta_req_valid,
  output logic                       ta_req_ready,
  input  wire logic [TRW-1:0]        ta_req_row,
  output logic                       ta_rsp_valid,
  input  wire logic                  ta_rsp_ready,
  output logic [LINE_W-1:0]          ta_rsp_data,
  output logic [2:0]                 ta_rsp_status,
  input  wire logic                  tb_req_valid,
  output logic                       tb_req_ready,
  input  wire logic [TRW-1:0]        tb_req_row,
  output logic                       tb_rsp_valid,
  input  wire logic                  tb_rsp_ready,
  output logic [LINE_W-1:0]          tb_rsp_data,
  output logic [2:0]                 tb_rsp_status,
  input  wire logic                  tc_req_valid,
  output logic                       tc_req_ready,
  input  wire logic                  tc_req_we,
  input  wire logic [TRW-1:0]        tc_req_row,
  input  wire logic [LINE_W-1:0]     tc_req_wdata,
  input  wire logic [LINE_W/8-1:0]   tc_req_be,
  output logic                       tc_rsp_valid,
  input  wire logic                  tc_rsp_ready,
  output logic [LINE_W-1:0]          tc_rsp_data,
  output logic                       tc_rsp_we,
  output logic [2:0]                 tc_rsp_status,
  input  wire logic                  td_req_valid,
  output logic                       td_req_ready,
  input  wire logic                  td_req_we,
  input  wire logic [1:0]            td_req_region,
  input  wire logic [BUFW-1:0]       td_req_buf,
  input  wire logic [TLW-1:0]        td_req_line,
  input  wire logic [LINE_W-1:0]     td_req_wdata,
  input  wire logic [LINE_W/8-1:0]   td_req_be,
  output logic                       td_rsp_valid,
  input  wire logic                  td_rsp_ready,
  output logic [LINE_W-1:0]          td_rsp_data,
  output logic                       td_rsp_we,
  output logic [2:0]                 td_rsp_status,
  // ---------------------------------------------------------------- bridge status / controller control
  input  wire logic                  flush_i,           // external controller flush (e.g. MBIST sequencer, error recovery)
  output logic                       irq_o,
  output logic [NTP-1:0]             err_sticky_o,
  output logic [NTP*`SDF_NPERF*32-1:0] perf_o,
  output logic [NTP*NB*32-1:0]       bank_acc_o,
  output logic [NTP*NB*32-1:0]       bank_stall_o,
  output logic [NB*32-1:0]           ctl_perf_conf_o,    // controller: cycles with >= 2 masters requesting a bank
  output logic [NMC*32-1:0]          ctl_perf_stall_o,   // controller: cycles each master port waited
  input  wire logic                  rb_sel,
  input  wire logic                  rb_we,
  input  wire logic [7:0]            rb_addr,
  input  wire logic [31:0]           rb_wdata,
  output logic [31:0]                rb_rdata,
  output logic                       rb_err
);
  localparam logic [4*AW-1:0] WB4 = {SRAM_BASE + 32'(3) * (32'd1 << WIN_LOG2), SRAM_BASE + 32'(2) * (32'd1 << WIN_LOG2),
                                     SRAM_BASE + 32'(1) * (32'd1 << WIN_LOG2), SRAM_BASE};
  localparam logic [NTP*AW-1:0] WBS = WB4[NTP*AW-1:0];
  localparam logic [AW-1:0] WMASK = (32'd1 << WIN_LOG2) - 32'd1;
  localparam int ROW_W = $clog2(DEPTH);
  localparam int BW = (NB > 1) ? $clog2(NB) : 1;
  localparam int R_ECC = $clog2(LINE_W + $clog2(LINE_W + 1) + 1);
  localparam int STORE_W = (ECC_EN != 0) ? LINE_W + R_ECC + 1 : LINE_W;
  localparam int FBW = (STORE_W > 1) ? $clog2(STORE_W) : 1;

  // ------------------------------------------------------------ fabric
  logic [NTP-1:0]    t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready;
  logic [NTP*3-1:0]  t_req_opcode, t_rsp_opcode, t_req_qos;
  logic [NTP*SRCW-1:0] t_req_src, t_rsp_src;
  logic [NTP*IDW-1:0] t_req_id, t_rsp_id;
  logic [NTP*AW-1:0] t_req_addr;
  logic [NTP*DW-1:0] t_req_wdata, t_rsp_rdata;
  logic [NTP*SB-1:0] t_req_wstrb;
  logic [NTP*2-1:0]  t_rsp_status;
  logic [31:0]       noc_rb_rdata;
  logic              noc_rb_err, noc_irq;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0]     obs_sw_valid, obs_sw_ready, obs_decerr, obs_posted_err, obs_orphan;
  logic              obs_bad_src;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_noc #(
    .TOPOLOGY(1), .NM(NM), .NT(NTP), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(2), .CHECK_ALIGN(1),
    .TGT_BASE(WBS), .TGT_MASK({NTP{~WMASK}}), .MAXO_MAX(4), .PERF(0)
  ) u_noc (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_opcode(m_req_opcode), .m_req_id(m_req_id),
    .m_req_qos(m_req_qos), .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_id(m_rsp_id), .m_rsp_opcode(m_rsp_opcode),
    .m_rsp_status(m_rsp_status), .m_rsp_rdata(m_rsp_rdata),
    .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_opcode(t_req_opcode), .t_req_src(t_req_src),
    .t_req_id(t_req_id), .t_req_qos(t_req_qos), .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata),
    .t_req_wstrb(t_req_wstrb),
    .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src), .t_rsp_id(t_rsp_id),
    .t_rsp_opcode(t_rsp_opcode), .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata),
    .rb_sel(1'b0), .rb_we(1'b0), .rb_addr(12'd0), .rb_wdata(32'd0), .rb_rdata(noc_rb_rdata), .rb_err(noc_rb_err),
    .irq_err(noc_irq), .obs_sw_valid(obs_sw_valid), .obs_sw_ready(obs_sw_ready), .obs_out_cnt(),
    .obs_decerr(obs_decerr), .obs_posted_err(obs_posted_err), .obs_orphan(obs_orphan), .obs_bad_src(obs_bad_src));
  wire unused_noc = &{1'b0, noc_rb_rdata, noc_rb_err, noc_irq};

  // ------------------------------------------------------------ bridge
  logic [NCP-1:0]         b_req_valid, b_req_ready, b_req_we, b_rsp_valid, b_rsp_ready, b_rsp_we, b_rsp_ce;
  logic [NCP*AW-1:0]      b_req_addr;
  logic [NCP*LINE_W-1:0]  b_req_wdata, b_rsp_rdata;
  logic [NCP*16-1:0]      b_req_be;
  logic [NCP*IDC-1:0]     b_req_id, b_rsp_id;
  logic [NCP*3-1:0]       b_rsp_status;
  logic                   b_flush_o, ctl_flush_busy;
  logic [NTP*3-1:0]       rsp_cause;
  wire  b_flush_i = ctl_flush_busy;
  sf_sram_datafabric #(
    .NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .NTP(NTP), .NP(NP), .NB(NB), .DEPTH(DEPTH), .WIN_BASES(WBS), .WIN_LOG2(WIN_LOG2),
    .ALLOW_LO(0), .ALLOW_HI(SHARED_BYTES), .REQ_REG(REQ_REG), .RSP_REG(RSP_REG), .CTRL_NSLOT(NSLOT), .TXQ_DEPTH(NSLOT),
    .TIMEOUT(TIMEOUT), .TO_ACTION(1)
  ) u_bridge (
    .clk(clk), .rst_n(rst_n),
    .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_opcode(t_req_opcode), .t_req_src(t_req_src),
    .t_req_id(t_req_id), .t_req_qos(t_req_qos), .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata),
    .t_req_wstrb(t_req_wstrb),
    .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src), .t_rsp_id(t_rsp_id),
    .t_rsp_opcode(t_rsp_opcode), .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata), .rsp_cause_o(rsp_cause),
    .c_req_valid(b_req_valid), .c_req_ready(b_req_ready), .c_req_we(b_req_we), .c_req_addr(b_req_addr),
    .c_req_wdata(b_req_wdata), .c_req_be(b_req_be), .c_req_id(b_req_id),
    .c_rsp_valid(b_rsp_valid), .c_rsp_ready(b_rsp_ready), .c_rsp_rdata(b_rsp_rdata), .c_rsp_id(b_rsp_id),
    .c_rsp_we(b_rsp_we), .c_rsp_status(b_rsp_status), .c_rsp_ce(b_rsp_ce),
    .c_flush_i(b_flush_i), .c_flush_o(b_flush_o),
    .err_clr_i(1'b0), .err_sticky_o(err_sticky_o), .err_cnt_o(), .err_code_o(), .err_src_o(), .err_id_o(), .err_opcode_o(),
    .err_addr_o(), .irq_o(irq_o), .perf_o(perf_o), .bank_acc_o(bank_acc_o), .bank_stall_o(bank_stall_o), .out_cnt_o(),
    .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata), .rb_err(rb_err));
  wire unused_cause = &{1'b0, rsp_cause};

  // ------------------------------------------------------------ vector scratchpad (direct local port)
  logic [NPV-1:0]         vs_req_valid, vs_req_ready, vs_req_we, vs_rsp_valid, vs_rsp_ready;
  logic [NPV*AW-1:0]      vs_req_addr;
  logic [NPV*LINE_W-1:0]  vs_req_wdata, vs_rsp_rdata;
  logic [NPV*16-1:0]      vs_req_be;
  logic [NPV*3-1:0]       vs_rsp_status;
  sf_vector_scratchpad #(.AW(AW), .IDW(VEC_IDW), .NB(NB), .CAP_LINES(CAP_LINES), .VEC_LINES(VEC_LINES), .DMA_OUT(NSLOT), .META_DEPTH(NSLOT)) u_vsp (
    .clk(clk), .rst_n(rst_n),
    .v_req_valid(v_req_valid), .v_req_ready(v_req_ready), .v_req_we(v_req_we), .v_req_addr(v_req_addr), .v_req_size(v_req_size),
    .v_req_sext(v_req_sext), .v_req_wdata(v_req_wdata), .v_req_id(v_req_id),
    .v_rsp_valid(v_rsp_valid), .v_rsp_ready(v_rsp_ready), .v_rsp_rdata(v_rsp_rdata), .v_rsp_id(v_rsp_id), .v_rsp_we(v_rsp_we),
    .v_rsp_status(v_rsp_status),
    .dma_start_i(vdma_start_i), .dma_dir_i(vdma_dir_i), .dma_base_i(vdma_base_i), .dma_len_i(vdma_len_i), .dma_stride_i(vdma_stride_i),
    .dma_busy_o(vdma_busy_o), .dma_done_o(vdma_done_o), .dma_err_o(vdma_err_o), .dma_err_code_o(), .dma_beats_o(),
    .dma_in_valid(vdma_in_valid), .dma_in_ready(vdma_in_ready), .dma_in_data(vdma_in_data),
    .dma_out_valid(vdma_out_valid), .dma_out_ready(vdma_out_ready), .dma_out_data(vdma_out_data),
    .conflict_vec_o(), .conflict_dma_o(), .conflict_cnt_o(),
    .c_req_valid(vs_req_valid), .c_req_ready(vs_req_ready), .c_req_we(vs_req_we), .c_req_addr(vs_req_addr),
    .c_req_wdata(vs_req_wdata), .c_req_be(vs_req_be), .c_rsp_valid(vs_rsp_valid), .c_rsp_ready(vs_rsp_ready),
    .c_rsp_rdata(vs_rsp_rdata), .c_rsp_status(vs_rsp_status));

  // ------------------------------------------------------------ tensor scratchpad (direct local ports)
  logic [3:0]             ts_req_valid, ts_req_ready, ts_req_we, ts_rsp_valid, ts_rsp_ready;
  logic [4*AW-1:0]        ts_req_addr;
  logic [4*LINE_W-1:0]    ts_req_wdata, ts_rsp_rdata;
  logic [4*16-1:0]        ts_req_be;
  logic [4*3-1:0]         ts_rsp_status;
  sf_tensor_scratchpad #(.AW(AW), .NB(NB), .CAP_LINES(CAP_LINES), .BASE_LINE(TEN_BASE_LINE), .NBUF(TEN_NBUF),
                         .A_ROWS(TEN_ROWS), .B_ROWS(TEN_ROWS), .C_ROWS(TEN_ROWS), .META_DEPTH(NSLOT)) u_tsp (
    .clk(clk), .rst_n(rst_n),
    .fill_req_i(t_fill_req_i), .fill_done_i(t_fill_done_i), .fill_grant_o(t_fill_grant_o), .fill_buf_o(t_fill_buf_o),
    .te_req_i(t_te_req_i), .te_done_i(t_te_done_i), .te_owned_o(t_te_owned_o), .te_buf_o(t_te_buf_o),
    .drain_req_i(t_drain_req_i), .drain_done_i(t_drain_done_i), .drain_grant_o(t_drain_grant_o), .drain_buf_o(t_drain_buf_o),
    .buf_state_o(t_buf_state_o), .ev_fill_complete_o(), .ev_compute_complete_o(), .ev_drain_complete_o(), .irq_o(),
    .owner_viol_cnt_o(), .range_viol_cnt_o(),
    .a_req_valid(ta_req_valid), .a_req_ready(ta_req_ready), .a_req_row(ta_req_row), .a_req_col(1'b0),
    .a_rsp_valid(ta_rsp_valid), .a_rsp_ready(ta_rsp_ready), .a_rsp_data(ta_rsp_data), .a_rsp_status(ta_rsp_status),
    .b_req_valid(tb_req_valid), .b_req_ready(tb_req_ready), .b_req_row(tb_req_row), .b_req_col(1'b0),
    .b_rsp_valid(tb_rsp_valid), .b_rsp_ready(tb_rsp_ready), .b_rsp_data(tb_rsp_data), .b_rsp_status(tb_rsp_status),
    .c_req_valid(tc_req_valid), .c_req_ready(tc_req_ready), .c_req_we(tc_req_we), .c_req_row(tc_req_row), .c_req_col(1'b0),
    .c_req_wdata(tc_req_wdata), .c_req_be(tc_req_be), .c_rsp_valid(tc_rsp_valid), .c_rsp_ready(tc_rsp_ready),
    .c_rsp_data(tc_rsp_data), .c_rsp_we(tc_rsp_we), .c_rsp_status(tc_rsp_status),
    .d_req_valid(td_req_valid), .d_req_ready(td_req_ready), .d_req_we(td_req_we), .d_req_region(td_req_region),
    .d_req_buf(td_req_buf), .d_req_line(td_req_line), .d_req_wdata(td_req_wdata), .d_req_be(td_req_be),
    .d_rsp_valid(td_rsp_valid), .d_rsp_ready(td_rsp_ready), .d_rsp_data(td_rsp_data), .d_rsp_we(td_rsp_we),
    .d_rsp_status(td_rsp_status),
    .m_req_valid(ts_req_valid), .m_req_ready(ts_req_ready), .m_req_we(ts_req_we), .m_req_addr(ts_req_addr),
    .m_req_wdata(ts_req_wdata), .m_req_be(ts_req_be), .m_rsp_valid(ts_rsp_valid), .m_rsp_ready(ts_rsp_ready),
    .m_rsp_rdata(ts_rsp_rdata), .m_rsp_status(ts_rsp_status));

  // ------------------------------------------------------------ controller (all masters)
  logic [NMC-1:0]         c_req_valid, c_req_ready, c_req_we, c_rsp_valid, c_rsp_ready, c_rsp_we, c_rsp_ce;
  logic [NMC*AW-1:0]      c_req_addr;
  logic [NMC*LINE_W-1:0]  c_req_wdata, c_rsp_rdata;
  logic [NMC*16-1:0]      c_req_be;
  logic [NMC*IDC-1:0]     c_req_id, c_rsp_id;
  logic [NMC*3-1:0]       c_rsp_status;
  assign c_req_valid = {ts_req_valid, vs_req_valid, b_req_valid};
  assign c_req_we    = {ts_req_we, vs_req_we, b_req_we};
  assign c_req_addr  = {ts_req_addr, vs_req_addr, b_req_addr};
  assign c_req_wdata = {ts_req_wdata, vs_req_wdata, b_req_wdata};
  assign c_req_be    = {ts_req_be, vs_req_be, b_req_be};
  assign c_req_id    = {{((NPV + 4) * IDC){1'b0}}, b_req_id};
  assign b_req_ready = c_req_ready[NCP-1:0];
  assign vs_req_ready = c_req_ready[NCP +: NPV];
  assign ts_req_ready = c_req_ready[NCP + NPV +: 4];
  assign b_rsp_valid = c_rsp_valid[NCP-1:0];
  assign vs_rsp_valid = c_rsp_valid[NCP +: NPV];
  assign ts_rsp_valid = c_rsp_valid[NCP + NPV +: 4];
  assign c_rsp_ready = {ts_rsp_ready, vs_rsp_ready, b_rsp_ready};
  assign b_rsp_rdata = c_rsp_rdata[NCP*LINE_W-1:0];
  assign vs_rsp_rdata = c_rsp_rdata[NCP*LINE_W +: NPV*LINE_W];
  assign ts_rsp_rdata = c_rsp_rdata[(NCP+NPV)*LINE_W +: 4*LINE_W];
  assign b_rsp_id    = c_rsp_id[NCP*IDC-1:0];
  assign b_rsp_we    = c_rsp_we[NCP-1:0];
  assign b_rsp_ce    = c_rsp_ce[NCP-1:0];
  assign b_rsp_status = c_rsp_status[NCP*3-1:0];
  assign vs_rsp_status = c_rsp_status[NCP*3 +: NPV*3];
  assign ts_rsp_status = c_rsp_status[(NCP+NPV)*3 +: 12];
  wire unused_ctl = &{1'b0, c_rsp_we[NMC-1:NCP], c_rsp_ce[NMC-1:NCP], c_rsp_id[NMC*IDC-1:NCP*IDC]};

  logic        ctl_idle, ctl_initbusy;
  logic [NB-1:0] ctl_ev_ce, ctl_ev_ue;
  logic [NB*STORE_W-1:0] ctl_tst;
  logic [NB*32-1:0] ctl_pacc, ctl_pbusy;
  logic [NB-1:0] ctl_bacc;
  sf_sram_controller #(
    .NM(NMC), .NB(NB), .DEPTH(DEPTH), .DW(LINE_W), .AW(AW), .IDW(IDC), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN),
    .NSLOT(NSLOT), .ARB(`SF_ARB_RR), .ALIGN_MODE(1), .INIT_ON_RESET(ECC_EN), .SIM_INIT(1), .FAULT_INJECT(0)
  ) u_ctl (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(c_req_valid), .m_req_ready(c_req_ready), .m_req_we(c_req_we), .m_req_addr(c_req_addr),
    .m_req_wdata(c_req_wdata), .m_req_be(c_req_be), .m_req_id(c_req_id),
    .m_rsp_valid(c_rsp_valid), .m_rsp_ready(c_rsp_ready), .m_rsp_rdata(c_rsp_rdata), .m_rsp_id(c_rsp_id), .m_rsp_we(c_rsp_we),
    .m_rsp_status(c_rsp_status), .m_rsp_ce(c_rsp_ce),
    .flush_i(flush_i | b_flush_o), .flush_busy_o(ctl_flush_busy), .quiesce_i(1'b0), .idle_o(ctl_idle),
    .init_start_i(1'b0), .init_busy_o(ctl_initbusy), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(ctl_ev_ce), .ev_ue_o(ctl_ev_ue), .ce_cnt_o(), .ue_cnt_o(),
    .perf_acc_o(ctl_pacc), .perf_conf_o(ctl_perf_conf_o), .perf_busy_o(ctl_pbusy), .perf_stall_o(ctl_perf_stall_o), .bank_acc_o(ctl_bacc),
    .tst_active_i(1'b0), .tst_sel_i({NB{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W{1'b0}}),
    .tst_wdata_i({STORE_W{1'b0}}), .tst_rdata_o(ctl_tst),
    .fi_bank({BW{1'b0}}), .fi_type(4'd0), .fi_row({ROW_W{1'b0}}), .fi_row2({ROW_W{1'b0}}), .fi_bit({FBW{1'b0}}),
    .fi_bit2({FBW{1'b0}}), .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row({ROW_W{1'b0}}), .seu_mask({STORE_W{1'b0}}));
  wire unused_c2 = &{1'b0, ctl_idle, ctl_initbusy, ctl_ev_ce, ctl_ev_ue, ctl_tst, ctl_pacc, ctl_pbusy, ctl_bacc};
endmodule

`default_nettype wire
