// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_pattern
// Data-background generator.  Pure function of (pattern, stripe_k, row, pol):
//
//     data = B(row) ^ {W{pol}}            pol = 0 : the March "0" data,  pol = 1 : the March "1" data
//
// Background B (bit i of a W-bit stored word, i = 0 is the LSB; "bit order" is LOGICAL -- see docs/02 section 4
// for what that does and does not say about physical adjacency):
//
//   ALL0     B[i] = 0
//   ALL1     B[i] = 1            Complementary start state: every cell sees its transitions in the opposite
//                                order.  Objective: attribute TF-up vs TF-down and SA0 vs SA1 symptoms to the
//                                March element that detects them in the other polarity (diagnosis), and
//                                expose faults that only manifest when the array powers up holding 1s.
//   ALT      B[i] = i[0]         0101..  Objective: coupling between logically adjacent columns.
//   CHECKER  B[i] = i[0]^row[0]  ALT inverted on odd rows. Objective: coupling between logically adjacent
//                                rows AND columns.  Equals a physical checkerboard only if logical order ==
//                                physical order (not claimed).
//   ADDR     B[i] = row[i mod AW] ^ ((i / AW) & 1)
//                                Every row stores a DIFFERENT word.  Objective: address-decoder fault
//                                DIAGNOSIS -- a wrong-row read returns the pattern of the row that was really
//                                accessed, so the alias target is recoverable from the observed word
//                                (sf_mbist_failreg, class MB_CLS_ADDR_ALIAS).
//   STRIPE   B[i] = (i >> k) & 1 Column stripes of period 2^(k+1).  Objective: INTRA-WORD coupling coverage.
//                                A coupling pair (i, j) inside one word is only exercised in every
//                                (aggressor, victim) state combination if some background gives bits i and j
//                                different values AND some other background gives them equal values.
//                                Backgrounds k = 0 .. ceil(log2 W)-1 plus ALL0 separate every pair of
//                                column indexes (their binary representations differ in some bit k).  The
//                                MemoryCore measurement with only {solid, checkerboard} left four same-word
//                                coupling classes at ~51 %; the sweep (cfg_sweep) runs exactly this set.
// Classification: SYNTHESIZABLE (combinational)
// =============================================================================
`include "sf_mbist_defs.svh"
`default_nettype none

module sf_mbist_pattern #(
  parameter int W  = 32,
  parameter int AW = 6
) (
  input  wire logic [2:0]    pattern_i,
  input  wire logic [3:0]    stripe_k_i,
  input  wire logic [AW-1:0] row_i,
  input  wire logic          pol_i,
  output logic      [W-1:0]  data_o
);
  wire row0 = row_i[0];
  // one bit slice per stored column; constants and the row-bit pick are resolved at elaboration
  for (genvar i = 0; i < W; i++) begin : g_bit
    localparam bit ALT_I  = ((i % 2) == 1);
    localparam bit COPY_I = (((i / AW) % 2) == 1);
    wire row_b   = row_i[i % AW];
    wire stripe  = ((i >> stripe_k_i) % 2) == 1;
    logic b;
    always_comb begin
      case (pattern_i)
        `MB_PAT_ALL0:    b = 1'b0;
        `MB_PAT_ALL1:    b = 1'b1;
        `MB_PAT_ALT:     b = ALT_I;
        `MB_PAT_CHECKER: b = ALT_I ^ row0;
        `MB_PAT_ADDR:    b = row_b ^ COPY_I;
        `MB_PAT_STRIPE:  b = stripe;
        default:         b = 1'b0;
      endcase
    end
    assign data_o[i] = b ^ pol_i;
  end
endmodule

`default_nettype wire
