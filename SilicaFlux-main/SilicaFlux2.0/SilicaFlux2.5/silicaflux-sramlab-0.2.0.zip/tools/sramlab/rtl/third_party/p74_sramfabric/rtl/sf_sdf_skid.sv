// =============================================================================
// SilicaFlux SRAMFabric :: sf_sdf_skid -- valid/ready pipeline register with REGISTERED ready (2-entry skid)
//
// Cuts the combinational path  downstream ready -> upstream ready  while keeping one transfer per cycle.
//   in_ready  = !skid_v                       (a register, never a function of out_ready)
//   out_*     come from registers
// Order is preserved; a presented out_valid/out_data is held unchanged until out_ready (SFB3 R2 / R4).
// Reset clears the valid bits only (data registers are not reset).
// Latency: 1 cycle (a transfer accepted at edge N is visible at out_* in cycle N+1).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_sdf_skid #(
  parameter int W = 8
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         clr_i,        // synchronous clear (drops everything held)
  input  wire logic         in_valid,
  output logic              in_ready,
  input  wire logic [W-1:0] in_data,
  output logic              out_valid,
  input  wire logic         out_ready,
  output logic [W-1:0]      out_data,
  output logic [1:0]        occ_o         // 0, 1 or 2 entries held
);
  logic         main_v, skid_v;
  logic [W-1:0] main_d, skid_d;

  assign in_ready  = ~skid_v;
  assign out_valid = main_v;
  assign out_data  = main_d;
  assign occ_o     = {1'b0, main_v} + {1'b0, skid_v};              // skid_v implies main_v

  wire in_fire  = in_valid & in_ready;
  wire out_fire = main_v & out_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      main_v <= 1'b0;
      skid_v <= 1'b0;
    end else if (clr_i) begin
      main_v <= 1'b0;
      skid_v <= 1'b0;
    end else begin
      if (in_fire) begin
        if (!main_v || out_fire) begin
          main_v <= 1'b1;
        end else begin
          skid_v <= 1'b1;
        end
      end else if (out_fire) begin
        if (skid_v) begin
          main_v <= 1'b1;
          skid_v <= 1'b0;
        end else begin
          main_v <= 1'b0;
        end
      end
    end
  end

  always_ff @(posedge clk) begin
    if (in_fire) begin
      if (!main_v || out_fire) main_d <= in_data;
      else                     skid_d <= in_data;
    end else if (out_fire && skid_v) begin
      main_d <= skid_d;
    end
  end
endmodule

`default_nettype wire
