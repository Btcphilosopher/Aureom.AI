// Register-bus helpers shared by the testbenches that talk to the MBIST register page.
// The including module must declare:  clk, rb_req, rb_we, rb_addr[11:0], rb_wdata[31:0], rb_rdata, rb_err,
// integer errors / checks, and `include "tb_common.svh"`.
`ifndef TB_MBIST_RBUS_SVH
`define TB_MBIST_RBUS_SVH

  localparam logic [11:0] A_ID = 12'h000, A_REV = 12'h004, A_CAPS0 = 12'h008, A_CAPS1 = 12'h00C, A_CAPS2 = 12'h010,
    A_ACCESS = 12'h014, A_SHARED = 12'h018, A_TENSOR = 12'h01C, A_VECTOR = 12'h020, A_CTRL = 12'h030, A_CFG = 12'h034,
    A_SELECT = 12'h038, A_BMASK = 12'h03C, A_ROWLO = 12'h040, A_ROWHI = 12'h044, A_WDOG = 12'h048, A_STATUS = 12'h050,
    A_ERR = 12'h054, A_TESTED = 12'h058, A_BFAILED = 12'h05C, A_FCOUNT = 12'h060, A_FIFOST = 12'h064, A_PROG = 12'h068,
    A_CURADDR = 12'h06C, A_CYCLES = 12'h070, A_INTR = 12'h074, A_RAS = 12'h078, A_ARB = 12'h07C, A_COLF = 12'h080,
    A_FF_ADDR = 12'h0A0, A_FF_BIT = 12'h0A4, A_FF_OP = 12'h0A8, A_FF_VALID = 12'h0AC, A_FF_EXP = 12'h0B0, A_FF_OBS = 12'h0D0,
    A_HD_ADDR = 12'h100, A_HD_BIT = 12'h104, A_HD_OP = 12'h108, A_HD_VALID = 12'h10C, A_HD_EXP = 12'h110, A_HD_OBS = 12'h130,
    A_BCNT = 12'h200, A_REP_OK = 12'h300, A_REP_UNREP = 12'h304, A_REP_TOUCHED = 12'h308, A_REP_PHYS = 12'h30C,
    A_REP_ROW = 12'h340, A_REP_COL = 12'h3C0;

  logic [31:0] rd_val; logic rd_err;
  task automatic rb_access(input logic we, input logic [11:0] a, input logic [31:0] d);
    begin
      @(posedge clk); rb_req <= 1'b1; rb_we <= we; rb_addr <= a; rb_wdata <= d;
      @(posedge clk); rd_val = rb_rdata; rd_err = rb_err; rb_req <= 1'b0; rb_we <= 1'b0;
    end
  endtask
  task automatic rw(input logic [11:0] a, input logic [31:0] d);
    begin rb_access(1'b1, a, d); `CHECK(!rd_err, "register write accepted") end
  endtask
  task automatic rr(input logic [11:0] a);
    begin rb_access(1'b0, a, 32'd0); `CHECK(!rd_err, "register read accepted") end
  endtask
  task automatic cfgw(input int algo, input int pat, input int k, input int sweep, input int col, input int stop, input int reinit);
    reg [31:0] v;
    begin
      v = 32'd0; v[3:0] = algo; v[6:4] = pat; v[10:7] = k; v[11] = sweep; v[13:12] = col; v[14] = stop; v[15] = reinit;
      rw(A_CFG, v);
    end
  endtask
  task automatic selw(input int sel, input int bank, input int bmask);
    reg [31:0] v;
    begin v = 32'd0; v[2:0] = sel; v[15:8] = bank; rw(A_SELECT, v); rw(A_BMASK, bmask); end
  endtask
  task automatic winw(input int lo, input int hi); begin rw(A_ROWLO, lo); rw(A_ROWHI, hi); end endtask

`endif
