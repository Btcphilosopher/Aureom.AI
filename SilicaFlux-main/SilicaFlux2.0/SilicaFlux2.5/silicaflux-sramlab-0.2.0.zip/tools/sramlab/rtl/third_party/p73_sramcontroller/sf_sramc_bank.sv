// =============================================================================
// SilicaFlux SRAMController :: sf_sramc_bank -- bank adapter over sf_sram_core
//
// Presents the controller's BANK CONTRACT on top of the verified single-port
// SRAMCore (Project 71, vendored unmodified):
//
//   * req_valid/req_ready : one access accepted per cycle when req_ready (here
//                           always 1: sf_sram_core never stalls).
//   * rsp_valid           : exactly ONE completion pulse per accepted access
//                           (reads AND writes), IN ACCEPTANCE ORDER, at most one
//                           per cycle, ACCESS_LATENCY = LAT cycles after the
//                           access was presented.  rsp_rdata is valid only with
//                           rsp_valid (0 for writes and errors).
//
// sf_sram_core acknowledges a write one cycle after it is presented while a
// read takes READ_LATENCY cycles.  With LAT > 1 a write issued right after a
// read would therefore complete BEFORE the read -- two completions out of
// acceptance order, even two in one cycle.  The write acknowledge is delayed
// by LAT-1 cycles here so every access of this bank completes after exactly
// LAT cycles: completions are in order and never collide.  (A write is still
// PERFORMED at the acceptance edge; the delay only moves its completion.)
//
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sramc_defs.svh"
`default_nettype none

module sf_sramc_bank #(
  parameter int DATA_WIDTH  = 32,
  parameter int DEPTH_WORDS = 1024,
  parameter int LAT         = 1,
  parameter int INIT_MODE   = 0,
  localparam int LANES      = DATA_WIDTH / 8,
  localparam int AW         = (DEPTH_WORDS > 1) ? $clog2(DEPTH_WORDS) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  req_valid,
  output logic                       req_ready,
  input  wire logic                  req_we,
  input  wire logic [AW-1:0]         req_addr,    // word row inside this bank
  input  wire logic [DATA_WIDTH-1:0] req_wdata,
  input  wire logic [LANES-1:0]      req_wstrb,
  output logic                       rsp_valid,
  output logic      [DATA_WIDTH-1:0] rsp_rdata,
  output logic                       rsp_err
);
  if (LAT < 1) begin : g_err_lat_lt_1
    `SFC_CFG_FATAL("sf_sramc_bank: LAT must be >= 1")
  end

  logic [DATA_WIDTH-1:0] c_rdata;
  logic                  c_rd_valid, c_rd_err, c_wr_ack, c_wr_err;

  assign req_ready = 1'b1;

  sf_sram_core #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH_WORDS(DEPTH_WORDS), .ADDR_WIDTH(AW), .BYTE_WIDTH(8),
    .READ_LATENCY(LAT), .INIT_MODE(INIT_MODE), .INIT_FILE(""), .WRITE_ACK(1), .OOB_ASSERT(0)
  ) u_core (
    .clk(clk), .rst_n(rst_n), .ce(req_valid), .we(req_we), .addr(req_addr),
    .wmask(req_wstrb), .wdata(req_wdata), .rdata(c_rdata),
    .rd_valid(c_rd_valid), .rd_err(c_rd_err), .wr_ack(c_wr_ack), .wr_err(c_wr_err)
  );

  // write completion delayed to the read latency
  logic wa_d, we_d;
  if (LAT == 1) begin : g_w1
    assign wa_d = c_wr_ack;
    assign we_d = c_wr_err;
  end else begin : g_wn
    logic [LAT-2:0] wa_q, we_q;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        wa_q <= '0;
        we_q <= '0;
      end else begin
        wa_q[0] <= c_wr_ack;
        we_q[0] <= c_wr_err;
        for (int k = 1; k < LAT - 1; k++) begin
          wa_q[k] <= wa_q[k-1];
          we_q[k] <= we_q[k-1];
        end
      end
    end
    assign wa_d = wa_q[LAT-2];
    assign we_d = we_q[LAT-2];
  end

  assign rsp_valid = c_rd_valid | wa_d;
  assign rsp_err   = (c_rd_valid & c_rd_err) | (wa_d & we_d);
  assign rsp_rdata = c_rd_valid ? c_rdata : {DATA_WIDTH{1'b0}};
endmodule

`default_nettype wire
