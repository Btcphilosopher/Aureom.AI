// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_ras_if       (RAS event port of the MBIST controller)
//
// Drives ONE event port of the RAS event controller (rtl/sfras_event_ctrl.sv of silicaflux-ras, Project 26):
//     ev_valid (1-cycle pulse), ev_type[3:0], ev_addr[31:0], ev_addr_v, ev_info[31:0], ev_corr
// The RAS side adds source id, severity, timestamp, counters and the log.  This module only decides WHAT to
// report and never loses an event silently:
//
//   FIRST_FAIL  the first miscompare of a run            type RAS_EV_FAIL   addr = {bank[7:0], row[23:0]}
//   SUMMARY     run finished with failures               type RAS_EV_FAIL   info = failure count (16 bit sat.)
//   ERROR       one event per sticky error flag (refused start, ownership / re-init timeout, permission loss,
//               watchdog, FIFO overflow ...)             type RAS_EV_TMO for the timeout-like flags, else RAS_EV_ERR
//   INTRUSION   functional request presented while MBIST owned the memory (blocked)      type RAS_EV_ERR
//   A host abort is a command, not an error, and raises no RAS event.
//
// ev_info layout:  [31] = 1 "origin: MBIST";  [30:28] sub-kind (MB_EVK_*);
//   FIRST_FAIL : [27:24] failure class, [23:16] bit index, [15:13] March element, [12] expected polarity, [11:8] pass
//   SUMMARY    : [15:0] failure count
//   ERROR/INTRUSION/REINIT : [23:16] error-flag number (MB_ERR_*)
// ev_corr is always 0: MBIST corrects nothing.
//
// The existing RAS type table (docs of silicaflux-ras 04) has NO dedicated MBIST type.  The default mapping uses
// SFRAS_EV_MEM_UE (2, hardware minimum severity ERROR) for failures, SFRAS_EV_ILLEGAL_OP (8, WARN) for refusals
// and SFRAS_EV_TIMEOUT (11) for timeouts.  This mixes MBIST failures into the runtime MEM_UE counters;
// appending a dedicated type (the RAS header allows append-only changes) is the clean fix and needs only the
// RAS_EV_* parameters here to change.  See docs/05_integration.md.
//
// Queueing: one pending slot per event kind / error flag; one event leaves per cycle (priority FIRST_FAIL,
// SUMMARY, then error flags by ascending number).  A request that finds its slot still occupied is counted
// in lost_o and raises evt_lost_o (MB_ERR_RAS_LOST).  Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_mbist_defs.svh"
`default_nettype none

module sf_mbist_ras_if #(
  parameter int AW         = 6,
  parameter int BW         = 2,
  parameter logic [3:0] RAS_EV_FAIL = 4'd2,
  parameter logic [3:0] RAS_EV_ERR  = 4'd8,
  parameter logic [3:0] RAS_EV_TMO  = 4'd11,
  // error flags that raise an event (everything except host abort and the RAS-lost flag itself)
  parameter logic [`MB_NERR-1:0] ERR_RAS_MASK = ~((`MB_NERR'(1) << `MB_ERR_ABORTED) | (`MB_NERR'(1) << `MB_ERR_RAS_LOST))
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---- requests (1-cycle pulses with payload)
  input  wire logic                 first_i,
  input  wire logic [BW-1:0]        first_bank_i,
  input  wire logic [AW-1:0]        first_row_i,
  input  wire logic [3:0]           first_cls_i,
  input  wire logic [7:0]           first_bit_i,
  input  wire logic [2:0]           first_elem_i,
  input  wire logic                 first_pol_i,
  input  wire logic [3:0]           first_pass_i,
  input  wire logic                 summary_i,
  input  wire logic [31:0]          summary_count_i,
  input  wire logic [`MB_NERR-1:0]  err_i,
  // ---- RAS event port
  output logic                      ev_valid_o,
  output logic [3:0]                ev_type_o,
  output logic [31:0]               ev_addr_o,
  output logic                      ev_addr_v_o,
  output logic [31:0]               ev_info_o,
  output logic                      ev_corr_o,
  // ---- accounting
  output logic [15:0]               sent_o,
  output logic [15:0]               lost_o,
  output logic                      evt_lost_o
);
  logic                p_first, p_sum;
  logic [`MB_NERR-1:0] p_err;
  logic [31:0]         first_addr_q, first_info_q, sum_info_q;

  wire [`MB_NERR-1:0] err_req = err_i & ERR_RAS_MASK;

  // lowest pending error flag
  logic [7:0] err_idx;
  logic       err_any;
  always_comb begin
    err_idx = 8'd0; err_any = 1'b0;
    for (int e = `MB_NERR - 1; e >= 0; e--) if (p_err[e]) begin err_idx = 8'(e); err_any = 1'b1; end
  end

  function automatic logic is_timeout_flag(input logic [7:0] e);
    is_timeout_flag = (e == 8'(`MB_ERR_OWN_TIMEOUT)) || (e == 8'(`MB_ERR_REINIT_TIMEOUT)) || (e == 8'(`MB_ERR_WDOG));
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      p_first <= 1'b0; p_sum <= 1'b0; p_err <= '0; first_addr_q <= '0; first_info_q <= '0; sum_info_q <= '0;
      ev_valid_o <= 1'b0; ev_type_o <= '0; ev_addr_o <= '0; ev_addr_v_o <= 1'b0; ev_info_o <= '0; ev_corr_o <= 1'b0;
      sent_o <= '0; lost_o <= '0; evt_lost_o <= 1'b0;
    end else begin
      ev_valid_o <= 1'b0; ev_corr_o <= 1'b0; evt_lost_o <= 1'b0;

      // ---- accept requests (a busy slot means the previous event of that kind has not left yet: counted)
      if (first_i) begin
        if (p_first) begin if (lost_o != 16'hFFFF) lost_o <= lost_o + 1'b1; evt_lost_o <= 1'b1; end
        else begin
          p_first <= 1'b1;
          first_addr_q <= {8'(first_bank_i), 24'(first_row_i)};
          first_info_q <= {1'b1, `MB_EVK_FIRST_FAIL, first_cls_i, first_bit_i, first_elem_i, first_pol_i, first_pass_i, 8'd0};
        end
      end
      if (summary_i) begin
        if (p_sum) begin if (lost_o != 16'hFFFF) lost_o <= lost_o + 1'b1; evt_lost_o <= 1'b1; end
        else begin
          p_sum <= 1'b1;
          sum_info_q <= {1'b1, `MB_EVK_SUMMARY, 12'd0, (summary_count_i > 32'd65535) ? 16'hFFFF : summary_count_i[15:0]};
        end
      end
      for (int e = 0; e < `MB_NERR; e++) if (err_req[e]) begin
        if (p_err[e]) begin if (lost_o != 16'hFFFF) lost_o <= lost_o + 1'b1; evt_lost_o <= 1'b1; end
        else p_err[e] <= 1'b1;
      end

      // ---- emit one event per cycle
      if (p_first) begin
        p_first <= 1'b0; ev_valid_o <= 1'b1; ev_type_o <= RAS_EV_FAIL; ev_addr_o <= first_addr_q;
        ev_addr_v_o <= 1'b1; ev_info_o <= first_info_q; sent_o <= sent_o + 1'b1;
      end else if (p_sum) begin
        p_sum <= 1'b0; ev_valid_o <= 1'b1; ev_type_o <= RAS_EV_FAIL; ev_addr_o <= '0;
        ev_addr_v_o <= 1'b0; ev_info_o <= sum_info_q; sent_o <= sent_o + 1'b1;
      end else if (err_any) begin
        p_err[err_idx[4:0]] <= 1'b0; ev_valid_o <= 1'b1; ev_addr_o <= '0; ev_addr_v_o <= 1'b0;
        ev_type_o <= is_timeout_flag(err_idx) ? RAS_EV_TMO : RAS_EV_ERR;
        ev_info_o <= {1'b1, (err_idx == 8'(`MB_ERR_INTRUSION)) ? `MB_EVK_INTRUSION :
                            (err_idx == 8'(`MB_ERR_REINIT_REQ)) ? `MB_EVK_REINIT : `MB_EVK_ERROR,
                      4'd0, err_idx, 16'd0};
        sent_o <= sent_o + 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
