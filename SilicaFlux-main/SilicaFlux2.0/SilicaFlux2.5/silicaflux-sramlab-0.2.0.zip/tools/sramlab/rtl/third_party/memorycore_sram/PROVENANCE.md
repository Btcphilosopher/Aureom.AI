# memorycore_sram -- SilicaFlux MemoryCore, copied byte-identical (never edited here)

Source archive: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-memorycore-sram.zip`
(sha256 `b6a9b5ed0adb51915a954f67e8a69e4915e2b515d15bb77d4797ca2398807771`; the copy at
`SilicaFlux-main/silicaflux-memorycore-sram.zip` has the same digest).  Paths below are the paths inside the archive
(`silicaflux-memorycore-sram/...`).  `SHA256SUMS` lists every file; check with `cd rtl/third_party/memorycore_sram && sha256sum -c SHA256SUMS`.

| Files | Used by SRAMLab for |
|---|---|
| `rtl/sf_sram_bank.sv`, `sf_sram_core.sv`, `sf_sram_macro_wrapper.sv`, `backends/*`, `sf_sram_defs.svh` | ECC study: the bank (SECDED optional, partial-write RMW, scrubber, `FAULT_INJECT` SEU hook) and the real-stack MBIST integration check |
| `rtl/sf_ecc_enc.sv`, `sf_ecc_dec.sv`, `sf_ecc_counters.sv` | ECC study: encoder/decoder wrappers and CE/UE counters |
| `third_party/ras_secded/*` | the SECDED leaf codec (originally Project 26 RAS) those wrappers instantiate |
| `rtl/sf_sram_controller.sv`, `sf_sync_fifo.sv` | MBIST study: real-stack integration check (`tb_mbist_memorycore`, from P78) |
| `docs/ECC.md`, `reports/ecc_codec.log`, `reports/mbist_coverage.{json,md}` | the package's own committed numbers, for comparison only (never executed) |
| `tools/ecc/secded_ref.py` | the package's own Python SECDED reference; used only as a SECOND cross-check of the independent reference in `sramlab/studies/ecc.py` |

The RTL files here are also byte-identical to the copy vendored by the P78 MemoryTest package
(`silicaflux-memorytest-p78.zip`, `third_party/silicaflux-memorycore-sram/`): its `SHA256SUMS` verifies against these files.
`sf_sram_mbist_ctl.sv`, `sim_models/`, scratchpad/datafabric RTL are NOT copied (not needed).
