// =============================================================================
// SilicaFlux MemoryTest (Project 78) :: sf_sram_mbist        (top level)
// SRAM Built-In Self-Test controller for one memory group (one sf_sram_controller: NBANK banks of ROWS x STORE_W,
// common quiesce / idle / init / raw-test-bus contract).
//
// What it is        a MANUFACTURING / DIAGNOSTIC feature.  It runs documented March tests on the raw stored word of
//                   selected banks, reports where / what failed, and hands the memory back re-initialised.  It is not a
//                   replacement for functional verification and it never alters functional behaviour.
// What it contains  sf_mbist_fsm       engine: March C- / MATS+, bank / pass sequencing, op issue, compare
//                   sf_mbist_addr_seq  address sequencer (ascending / descending over a row window)
//                   sf_mbist_pattern   data backgrounds (all-0, all-1, alternating, checkerboard, address, stripe)
//                   sf_mbist_arbiter   test-mode arbiter: exclusive ownership (quiesce, drain, confirm, release,
//                                      re-init), timeouts, intrusion accounting
//                   sf_mbist_failreg   failure capture: first record, FIFO, counters, classification
//                   sf_mbist_regs      register page (control, configuration, diagnostic readback)
//                   sf_mbist_ras_if    one event port of the RAS event controller
//                   sf_mbist_repair    OPTIONAL redundancy-allocation ANALYSIS (no physical repair, see its header)
// Control paths     direct pins (start_i / cfg_*_i with cfg_from_pins_i = 1) and the register page (rb_*).  Status
//                   and the first-failure report are on pins AND in registers.  Both paths drive the same engine; a
//                   start from either is accepted only when idle.
// Test mode         start is REFUSED (result REFUSED, memory untouched) unless
//                   test_mode_i && test_permit_i && !mem_inhibit_i.  Losing any of them during a run hard-stops the
//                   engine and releases the memory re-initialised (result ERROR, never a pass).
// Memory side       exactly the sf_sram_controller contract (rtl/sf_sram_controller.sv of MemoryCore):
//                   quiesce_o / idle_i, init_start_o / init_busy_i, tst_active_o, tst_sel_o, tst_ce_o, tst_we_o,
//                   tst_addr_o, tst_wdata_o -> tst_rdata_i.  quiesce_ack_i: tie 1 for a memory whose quiesce is
//                   immediate (the controller); a SoC with masters that must finish a handshake drives it.
//                   func_req_i: intrusion probe = OR of the functional ACCEPTED-request strobes, e.g.
//                   |(m_req_valid & m_req_ready) (not raw valid: a back-pressured master is legal); may be tied 0.
// Read timing       tst_rdata is valid exactly READ_LATENCY (+ TEST_PIPE) cycles after the accepting edge and is
//                   never held (the sf_sram_core / sf_sram_bank contract).
// Not claimed       production fault coverage, retention / read-disturb / at-speed testing, physical repair.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_mbist_defs.svh"
`default_nettype none

module sf_sram_mbist #(
  parameter int NBANK         = 4,
  parameter int ROWS          = 64,
  parameter int DATA_W        = 32,
  parameter int STORE_W       = DATA_W,       // DATA_W + ECC check columns when the bank is protected
  parameter int READ_LATENCY  = 1,
  parameter int TEST_PIPE     = 0,            // extra register stages on the test path (adapters)
  parameter logic [NBANK-1:0] ACCESS_MASK = {NBANK{1'b1}},   // banks with a raw test port
  parameter logic [NBANK-1:0] SHARED_MASK = {NBANK{1'b1}},   // banks of the shared SRAM
  parameter logic [NBANK-1:0] TENSOR_MASK = '0,              // banks backing tensor scratchpads (0 = none own an array)
  parameter logic [NBANK-1:0] VECTOR_MASK = '0,              // banks backing vector scratchpads (0 = none own an array)
  parameter int FIFO_DEPTH    = 4,
  parameter int OWN_TIMEOUT   = 4096,
  parameter int IDLE_CONSEC   = 2,
  parameter int REINIT_ENGINE = 1,
  parameter int INIT_TIMEOUT  = ROWS + 256,
  parameter int INIT_GRACE    = 16,
  parameter bit REPAIR_EN     = 1'b0,
  parameter int SPARE_ROWS    = 2,
  parameter int SPARE_COLS    = 2,
  parameter bit REDUNDANCY_PRESENT = 1'b0,    // a macro with spare rows/cols AND a repair load exists (none in this repo)
  parameter logic [3:0] RAS_EV_FAIL = 4'd2,   // SFRAS_EV_MEM_UE
  parameter logic [3:0] RAS_EV_ERR  = 4'd8,   // SFRAS_EV_ILLEGAL_OP
  parameter logic [3:0] RAS_EV_TMO  = 4'd11,  // SFRAS_EV_TIMEOUT
  // ---- derived (do not override)
  parameter int ROW_W         = (ROWS > 1) ? $clog2(ROWS) : 1,
  parameter int BW            = (NBANK > 1) ? $clog2(NBANK) : 1,
  parameter int BITW          = (STORE_W > 1) ? $clog2(STORE_W) : 1,
  parameter int LT            = READ_LATENCY + TEST_PIPE
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------------- command pins (pulses)
  input  wire logic                   start_i,
  input  wire logic                   start_clr_i,    // with start_i: clear unread results as part of the start
  input  wire logic                   abort_i,
  input  wire logic                   clear_i,        // acknowledge / erase results (only while idle)
  input  wire logic                   fail_pop_i,     // advance the failure FIFO head
  input  wire logic                   clr_fault_i,    // clear the arbiter's sticky ownership fault
  // ---------------------------------------------------------------- configuration pins (used when cfg_from_pins_i)
  input  wire logic                   cfg_from_pins_i,
  input  wire logic [3:0]             cfg_algo_i,
  input  wire logic [2:0]             cfg_pattern_i,
  input  wire logic [3:0]             cfg_stripe_k_i,
  input  wire logic                   cfg_sweep_i,
  input  wire logic [1:0]             cfg_colsel_i,
  input  wire logic                   cfg_stop_i,
  input  wire logic                   cfg_reinit_i,
  input  wire logic [2:0]             cfg_sel_i,
  input  wire logic [7:0]             cfg_bank_i,
  input  wire logic [NBANK-1:0]       cfg_bmask_i,
  input  wire logic [ROW_W-1:0]       cfg_row_lo_i,
  input  wire logic [ROW_W-1:0]       cfg_row_hi_i,
  input  wire logic [31:0]            cfg_wdog_i,
  // ---------------------------------------------------------------- test-access context
  input  wire logic                   test_mode_i,    // global MBIST mode (TestCore mode controller)
  input  wire logic                   test_permit_i,  // lifecycle / permission
  input  wire logic                   mem_inhibit_i,  // DFT memory inhibit (scan): never write macros
  input  wire logic                   cpu_halted_i,
  input  wire logic [NBANK-1:0]       protect_i,      // banks holding live state (refused unless cpu_halted_i)
  // ---------------------------------------------------------------- status
  output logic                        busy_o,
  output logic                        done_o,         // held from completion until the next start / clear
  output logic                        pass_o,         // done && result == PASS
  output logic                        fail_o,         // at least one miscompare since the last clear
  output logic                        error_o,        // done && (ERROR or REFUSED)
  output logic [2:0]                  result_o,       // MB_RES_*
  output logic [NBANK-1:0]            bank_tested_o,
  output logic [NBANK-1:0]            bank_fail_mask_o,
  output logic [`MB_NERR-1:0]         err_flags_o,
  output logic [7:0]                  state_o,        // {arbiter state, engine state}
  // ---------------------------------------------------------------- first-failure report (held until clear / reset)
  output logic                        fail_valid_o,
  output logic [BW-1:0]               fail_bank_o,
  output logic [ROW_W-1:0]            fail_row_o,     // failed address
  output logic [BITW-1:0]             fail_bit_o,     // lowest failing bit
  output logic                        fail_bit_v_o,   // exactly one bit failed (bit index is THE bit)
  output logic                        fail_in_check_o,// that bit is an ECC check column
  output logic [2:0]                  fail_elem_o,    // March element
  output logic                        fail_op_o,      // operation index inside the element (0 = first)
  output logic                        fail_pol_o,     // expected read value polarity ("r0" / "r1")
  output logic [3:0]                  fail_pass_o,    // background pass (sweep)
  output logic [3:0]                  fail_cls_o,     // MB_CLS_*
  output logic [ROW_W-1:0]            fail_alias_o,
  output logic [STORE_W-1:0]          fail_exp_o,     // expected data
  output logic [STORE_W-1:0]          fail_obs_o,     // observed data
  output logic [31:0]                 fail_count_o,
  // ---------------------------------------------------------------- memory group side
  output logic                        quiesce_o,
  input  wire logic                   quiesce_ack_i,
  input  wire logic                   idle_i,
  output logic                        init_start_o,
  input  wire logic                   init_busy_i,
  input  wire logic                   func_req_i,
  output logic                        clk_req_o,      // keep the memory's clock branch open (P35 br_clk_req)
  output logic                        tst_active_o,
  output logic [NBANK-1:0]            tst_sel_o,
  output logic                        tst_ce_o,
  output logic                        tst_we_o,
  output logic [ROW_W-1:0]            tst_addr_o,
  output logic [STORE_W-1:0]          tst_wdata_o,
  input  wire logic [NBANK*STORE_W-1:0] tst_rdata_i,
  // ---------------------------------------------------------------- register bus (TestCore group-page bus)
  input  wire logic                   rb_req,
  input  wire logic                   rb_we,
  input  wire logic [11:0]            rb_addr,
  input  wire logic [31:0]            rb_wdata,
  output logic                        rb_gnt,
  output logic [31:0]                 rb_rdata,
  output logic                        rb_err,
  // ---------------------------------------------------------------- RAS event port
  output logic                        ras_valid_o,
  output logic [3:0]                  ras_type_o,
  output logic [31:0]                 ras_addr_o,
  output logic                        ras_addr_v_o,
  output logic [31:0]                 ras_info_o,
  output logic                        ras_corr_o,
  // ---------------------------------------------------------------- redundancy analysis (zero when REPAIR_EN = 0)
  output logic [NBANK*SPARE_ROWS-1:0]        rep_row_v_o,
  output logic [NBANK*SPARE_ROWS*ROW_W-1:0]  rep_row_o,
  output logic [NBANK*SPARE_COLS-1:0]        rep_col_v_o,
  output logic [NBANK*SPARE_COLS*BITW-1:0]   rep_col_o,
  output logic [NBANK-1:0]            rep_ok_o,
  output logic [NBANK-1:0]            rep_unrep_o,
  output logic                        rep_phys_o
);
  // ------------------------------------------------------------ static configuration checks
  if (NBANK < 1)                begin : g_err_nb    `MB_CFG_FATAL("sf_sram_mbist: NBANK must be >= 1")                  end
  if (ROWS < 2)                 begin : g_err_rows  `MB_CFG_FATAL("sf_sram_mbist: ROWS must be >= 2")                   end
  if (STORE_W < DATA_W)         begin : g_err_w     `MB_CFG_FATAL("sf_sram_mbist: STORE_W must be >= DATA_W")          end
  if (LT < 1)                   begin : g_err_lat   `MB_CFG_FATAL("sf_sram_mbist: READ_LATENCY + TEST_PIPE must be >= 1") end
  if (FIFO_DEPTH < 1)           begin : g_err_fifo  `MB_CFG_FATAL("sf_sram_mbist: FIFO_DEPTH must be >= 1")             end

  // ------------------------------------------------------------ internal wires
  wire permit = test_mode_i & test_permit_i & ~mem_inhibit_i;

  // register page outputs
  wire [3:0] r_algo; wire [2:0] r_pat; wire [3:0] r_k; wire r_sweep; wire [1:0] r_col; wire r_stop, r_reinit;
  wire [2:0] r_sel; wire [7:0] r_bank; wire [NBANK-1:0] r_bmask; wire [31:0] r_lo, r_hi; wire [31:0] r_wdog;
  wire p_start, p_abort, p_clear, p_pop, p_startclr, p_clrfault;

  // configuration source mux
  wire [3:0] c_algo = cfg_from_pins_i ? cfg_algo_i : r_algo;
  wire [2:0] c_pat  = cfg_from_pins_i ? cfg_pattern_i : r_pat;
  wire [3:0] c_k    = cfg_from_pins_i ? cfg_stripe_k_i : r_k;
  wire       c_sweep = cfg_from_pins_i ? cfg_sweep_i : r_sweep;
  wire [1:0] c_col  = cfg_from_pins_i ? cfg_colsel_i : r_col;
  wire       c_stop = cfg_from_pins_i ? cfg_stop_i : r_stop;
  wire       c_reinit = cfg_from_pins_i ? cfg_reinit_i : r_reinit;
  wire [2:0] c_sel  = cfg_from_pins_i ? cfg_sel_i : r_sel;
  wire [7:0] c_bank = cfg_from_pins_i ? cfg_bank_i : r_bank;
  wire [NBANK-1:0] c_bmask = cfg_from_pins_i ? cfg_bmask_i : r_bmask;
  wire [31:0] c_lo = cfg_from_pins_i ? 32'(cfg_row_lo_i) : r_lo;
  wire [31:0] c_hi = cfg_from_pins_i ? 32'(cfg_row_hi_i) : r_hi;
  wire [31:0] c_wdog = cfg_from_pins_i ? cfg_wdog_i : r_wdog;

  wire start_any = start_i | p_start;
  wire startclr  = start_clr_i | p_startclr;
  wire abort_any = abort_i | p_abort;
  wire clear_any = clear_i | p_clear;
  wire pop_any   = fail_pop_i | p_pop;

  wire fsm_ce, fsm_we;
  wire [NBANK-1:0] rep_touched;
  wire [NBANK-1:0] rep_touched_unused;

  // engine <-> arbiter
  wire own_req, own_ok, own_idle, own_fault, dirty, reinit_en;
  wire [3:0] arb_state;
  wire e_own_to, e_re_to, e_perm_unused, e_intr, e_re_req;
  wire [15:0] intr_cnt;

  // engine <-> failure register
  wire f_valid; wire [BW-1:0] f_bank; wire [ROW_W-1:0] f_row; wire [2:0] f_elem; wire f_op, f_pol;
  wire [3:0] f_pass; wire [2:0] f_pat; wire [STORE_W-1:0] f_exp, f_obs, f_mask, f_syn; wire clr_fail;
  wire [3:0] fsm_state; wire [BW-1:0] cur_bank; wire [3:0] cur_pass; wire [2:0] cur_elem; wire [ROW_W-1:0] cur_addr;
  wire [31:0] cycles; wire [`MB_NERR-1:0] fsm_evt;
  wire fr_pending, fr_first_evt, fr_lost_evt;
  wire [BW-1:0] fr_first_bank; wire [ROW_W-1:0] fr_first_row; wire [BITW-1:0] fr_first_bit; wire fr_first_bit_v, fr_first_inc;
  wire [2:0] fr_first_elem; wire fr_first_op, fr_first_pol; wire [3:0] fr_first_pass, fr_first_cls; wire [ROW_W-1:0] fr_first_alias;
  wire [STORE_W-1:0] fr_first_exp, fr_first_obs;
  wire fr_head_valid; wire [BW-1:0] fr_head_bank; wire [ROW_W-1:0] fr_head_row; wire [BITW-1:0] fr_head_bit;
  wire fr_head_bit_v, fr_head_inc; wire [2:0] fr_head_elem; wire fr_head_op, fr_head_pol; wire [3:0] fr_head_pass, fr_head_cls;
  wire [ROW_W-1:0] fr_head_alias; wire [STORE_W-1:0] fr_head_exp, fr_head_obs;
  wire [31:0] fr_count; wire [15:0] fr_fifo_cnt, fr_fifo_lost; wire [NBANK*16-1:0] fr_bank_cnt; wire [NBANK-1:0] fr_bank_mask;
  wire [STORE_W-1:0] fr_col_mask;

  // ------------------------------------------------------------ engine
  sf_mbist_fsm #(
    .NBANK(NBANK), .ROWS(ROWS), .ROW_W(ROW_W), .W(STORE_W), .DATA_W(DATA_W), .LT(LT), .BW(BW),
    .ACCESS_MASK(ACCESS_MASK), .SHARED_MASK(SHARED_MASK), .TENSOR_MASK(TENSOR_MASK), .VECTOR_MASK(VECTOR_MASK)
  ) u_fsm (
    .clk(clk), .rst_n(rst_n), .start_i(start_any), .start_clr_i(startclr), .abort_i(abort_any), .clear_i(clear_any),
    .cfg_algo_i(c_algo), .cfg_pattern_i(c_pat), .cfg_stripe_k_i(c_k), .cfg_sweep_i(c_sweep), .cfg_colsel_i(c_col),
    .cfg_stop_i(c_stop), .cfg_reinit_i(c_reinit), .cfg_sel_i(c_sel), .cfg_bank_i(c_bank), .cfg_bmask_i(c_bmask),
    .cfg_row_lo_i(c_lo), .cfg_row_hi_i(c_hi), .cfg_wdog_i(c_wdog),
    .permit_i(permit), .protect_i(protect_i), .cpu_halted_i(cpu_halted_i), .results_pending_i(fr_pending),
    .own_req_o(own_req), .own_ok_i(own_ok), .own_idle_i(own_idle), .own_fault_i(own_fault), .dirty_o(dirty),
    .reinit_en_o(reinit_en),
    .tst_sel_o(tst_sel_o), .tst_ce_o(fsm_ce), .tst_we_o(fsm_we), .tst_addr_o(tst_addr_o), .tst_wdata_o(tst_wdata_o),
    .tst_rdata_i(tst_rdata_i),
    .f_valid_o(f_valid), .f_bank_o(f_bank), .f_row_o(f_row), .f_elem_o(f_elem), .f_op_o(f_op), .f_pol_o(f_pol),
    .f_pass_o(f_pass), .f_pat_o(f_pat), .f_exp_o(f_exp), .f_obs_o(f_obs), .f_mask_o(f_mask), .clr_fail_o(clr_fail),
    .fail_any_i(fr_count != 32'd0),
    .busy_o(busy_o), .done_o(done_o), .result_o(result_o), .state_o(fsm_state), .cur_bank_o(cur_bank),
    .cur_pass_o(cur_pass), .cur_elem_o(cur_elem), .cur_addr_o(cur_addr), .cycles_o(cycles), .tested_o(bank_tested_o),
    .evt_o(fsm_evt));

  // ------------------------------------------------------------ test-mode arbiter
  sf_mbist_arbiter #(
    .OWN_TIMEOUT(OWN_TIMEOUT), .IDLE_CONSEC(IDLE_CONSEC), .INIT_TIMEOUT(INIT_TIMEOUT), .INIT_GRACE(INIT_GRACE),
    .REINIT_ENGINE(REINIT_ENGINE)
  ) u_arb (
    .clk(clk), .rst_n(rst_n), .own_req_i(own_req), .permit_i(permit), .reinit_en_i(reinit_en), .dirty_i(dirty),
    .clr_fault_i(clr_fault_i | p_clrfault), .quiesce_o(quiesce_o), .quiesce_ack_i(quiesce_ack_i), .idle_i(idle_i),
    .init_start_o(init_start_o), .init_busy_i(init_busy_i), .func_req_i(func_req_i), .tst_active_o(tst_active_o),
    .own_ok_o(own_ok), .own_idle_o(own_idle), .own_fault_o(own_fault), .clk_req_o(clk_req_o),
    .evt_own_timeout_o(e_own_to), .evt_reinit_timeout_o(e_re_to), .evt_perm_loss_o(e_perm_unused),
    .evt_intrusion_o(e_intr), .evt_reinit_req_o(e_re_req), .intrusion_cnt_o(intr_cnt), .state_o(arb_state));

  // defence in depth: a test operation reaches the memory only while the arbiter owns the bus
  assign tst_ce_o = fsm_ce & tst_active_o;
  assign tst_we_o = fsm_we & tst_active_o;

  // ------------------------------------------------------------ failure capture
  sf_mbist_failreg #(.NBANK(NBANK), .AW(ROW_W), .W(STORE_W), .DATA_W(DATA_W), .FIFO_DEPTH(FIFO_DEPTH)) u_fr (
    .clk(clk), .rst_n(rst_n), .clr_i(clr_fail), .pop_i(pop_any),
    .f_valid_i(f_valid), .f_bank_i(f_bank), .f_row_i(f_row), .f_elem_i(f_elem), .f_op_i(f_op), .f_pol_i(f_pol),
    .f_pass_i(f_pass), .f_pat_i(f_pat), .f_exp_i(f_exp), .f_obs_i(f_obs), .f_mask_i(f_mask), .syn_o(f_syn),
    .first_valid_o(fail_valid_o), .first_bank_o(fr_first_bank), .first_row_o(fr_first_row), .first_bit_o(fr_first_bit),
    .first_bit_v_o(fr_first_bit_v), .first_in_check_o(fr_first_inc), .first_elem_o(fr_first_elem), .first_op_o(fr_first_op),
    .first_pol_o(fr_first_pol), .first_pass_o(fr_first_pass), .first_cls_o(fr_first_cls), .first_alias_o(fr_first_alias),
    .first_exp_o(fr_first_exp), .first_obs_o(fr_first_obs),
    .head_valid_o(fr_head_valid), .head_bank_o(fr_head_bank), .head_row_o(fr_head_row), .head_bit_o(fr_head_bit),
    .head_bit_v_o(fr_head_bit_v), .head_in_check_o(fr_head_inc), .head_elem_o(fr_head_elem), .head_op_o(fr_head_op),
    .head_pol_o(fr_head_pol), .head_pass_o(fr_head_pass), .head_cls_o(fr_head_cls), .head_alias_o(fr_head_alias),
    .head_exp_o(fr_head_exp), .head_obs_o(fr_head_obs),
    .fail_count_o(fr_count), .fifo_count_o(fr_fifo_cnt), .fifo_lost_o(fr_fifo_lost), .bank_cnt_o(fr_bank_cnt),
    .bank_fail_mask_o(fr_bank_mask), .col_fail_mask_o(fr_col_mask), .pending_o(fr_pending),
    .evt_first_o(fr_first_evt), .evt_fifo_lost_o(fr_lost_evt));

  assign fail_bank_o     = fr_first_bank;   assign fail_row_o   = fr_first_row;   assign fail_bit_o   = fr_first_bit;
  assign fail_bit_v_o    = fr_first_bit_v;  assign fail_in_check_o = fr_first_inc; assign fail_elem_o  = fr_first_elem;
  assign fail_op_o       = fr_first_op;     assign fail_pol_o   = fr_first_pol;   assign fail_pass_o  = fr_first_pass;
  assign fail_cls_o      = fr_first_cls;    assign fail_alias_o = fr_first_alias; assign fail_exp_o   = fr_first_exp;
  assign fail_obs_o      = fr_first_obs;    assign fail_count_o = fr_count;
  assign bank_fail_mask_o = fr_bank_mask;

  // ------------------------------------------------------------ status pins
  assign fail_o  = (fr_count != 32'd0);
  assign pass_o  = done_o && (result_o == `MB_RES_PASS);
  assign error_o = done_o && ((result_o == `MB_RES_ERROR) || (result_o == `MB_RES_REFUSED));
  assign state_o = {arb_state, fsm_state};

  // ------------------------------------------------------------ redundancy analysis
  if (REPAIR_EN) begin : g_repair
    sf_mbist_repair #(.NBANK(NBANK), .AW(ROW_W), .W(STORE_W), .SR(SPARE_ROWS), .SC(SPARE_COLS),
                      .REDUNDANCY_PRESENT(REDUNDANCY_PRESENT)) u_rep (
      .clk(clk), .rst_n(rst_n), .clr_i(clr_fail), .f_valid_i(f_valid), .f_bank_i(f_bank), .f_row_i(f_row), .syn_i(f_syn),
      .rep_row_v_o(rep_row_v_o), .rep_row_o(rep_row_o), .rep_col_v_o(rep_col_v_o), .rep_col_o(rep_col_o),
      .rep_touched_o(rep_touched_unused), .rep_unrep_o(rep_unrep_o), .rep_ok_o(rep_ok_o), .rep_phys_o(rep_phys_o));
  end else begin : g_no_repair
    assign rep_row_v_o = '0; assign rep_row_o = '0; assign rep_col_v_o = '0; assign rep_col_o = '0;
    assign rep_ok_o = '0; assign rep_unrep_o = '0; assign rep_phys_o = 1'b0;
  end

  // ------------------------------------------------------------ events: sticky error flags and RAS
  logic done_q;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) done_q <= 1'b0; else done_q <= done_o;
  wire done_rise = done_o && !done_q;
  wire run_failed_pulse = done_rise && (fr_count != 32'd0);

  wire ras_lost_evt;
  // sticky-flag events: the engine's own plus the arbiter's / failure register's / RAS interface's (no part-selects:
  // one-bit pulses are widened and shifted onto their flag number)
  wire [`MB_NERR-1:0] evt_all = fsm_evt
                              | (`MB_NERR'(e_own_to)     << `MB_ERR_OWN_TIMEOUT)
                              | (`MB_NERR'(e_re_to)      << `MB_ERR_REINIT_TIMEOUT)
                              | (`MB_NERR'(e_intr)       << `MB_ERR_INTRUSION)
                              | (`MB_NERR'(e_re_req)     << `MB_ERR_REINIT_REQ)
                              | (`MB_NERR'(fr_lost_evt)  << `MB_ERR_FIFO_LOST)
                              | (`MB_NERR'(ras_lost_evt) << `MB_ERR_RAS_LOST);

  wire [15:0] ras_sent, ras_lost;
  sf_mbist_ras_if #(.AW(ROW_W), .BW(BW), .RAS_EV_FAIL(RAS_EV_FAIL), .RAS_EV_ERR(RAS_EV_ERR), .RAS_EV_TMO(RAS_EV_TMO)) u_ras (
    .clk(clk), .rst_n(rst_n), .first_i(fr_first_evt), .first_bank_i(fr_first_bank), .first_row_i(fr_first_row),
    .first_cls_i(fr_first_cls), .first_bit_i(8'(fr_first_bit)), .first_elem_i(fr_first_elem), .first_pol_i(fr_first_pol),
    .first_pass_i(fr_first_pass), .summary_i(run_failed_pulse), .summary_count_i(fr_count), .err_i(evt_all),
    .ev_valid_o(ras_valid_o), .ev_type_o(ras_type_o), .ev_addr_o(ras_addr_o), .ev_addr_v_o(ras_addr_v_o),
    .ev_info_o(ras_info_o), .ev_corr_o(ras_corr_o), .sent_o(ras_sent), .lost_o(ras_lost), .evt_lost_o(ras_lost_evt));

  // ------------------------------------------------------------ register page
  sf_mbist_regs #(
    .NBANK(NBANK), .ROWS(ROWS), .ROW_W(ROW_W), .W(STORE_W), .DATA_W(DATA_W), .LT(LT), .FIFO_DEPTH(FIFO_DEPTH),
    .SR(SPARE_ROWS), .SC(SPARE_COLS), .REPAIR_EN(REPAIR_EN), .REDUNDANCY_PRESENT(REDUNDANCY_PRESENT),
    .ACCESS_MASK(ACCESS_MASK), .SHARED_MASK(SHARED_MASK), .TENSOR_MASK(TENSOR_MASK), .VECTOR_MASK(VECTOR_MASK)
  ) u_regs (
    .clk(clk), .rst_n(rst_n), .rb_req(rb_req), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata),
    .rb_gnt(rb_gnt), .rb_rdata(rb_rdata), .rb_err(rb_err),
    .cfg_algo_o(r_algo), .cfg_pattern_o(r_pat), .cfg_stripe_k_o(r_k), .cfg_sweep_o(r_sweep), .cfg_colsel_o(r_col),
    .cfg_stop_o(r_stop), .cfg_reinit_o(r_reinit), .cfg_sel_o(r_sel), .cfg_bank_o(r_bank), .cfg_bmask_o(r_bmask),
    .cfg_row_lo_o(r_lo), .cfg_row_hi_o(r_hi), .cfg_wdog_o(r_wdog),
    .p_start_o(p_start), .p_abort_o(p_abort), .p_clear_o(p_clear), .p_pop_o(p_pop), .p_startclr_o(p_startclr),
    .p_clrfault_o(p_clrfault),
    .clr_i(clear_any && !busy_o), .evt_i(evt_all), .err_flags_o(err_flags_o),
    .busy_i(busy_o), .done_i(done_o), .result_i(result_o), .pending_i(fr_pending), .fsm_state_i(fsm_state),
    .arb_state_i(arb_state), .own_ok_i(own_ok), .tst_active_i(tst_active_o), .quiesce_i(quiesce_o), .clk_req_i(clk_req_o),
    .tested_i(bank_tested_o), .bank_fail_mask_i(fr_bank_mask), .fail_count_i(fr_count), .fifo_count_i(fr_fifo_cnt),
    .fifo_lost_i(fr_fifo_lost), .cur_bank_i(cur_bank), .cur_pass_i(cur_pass), .cur_elem_i(cur_elem),
    .cur_addr_i(cur_addr), .cycles_i(cycles), .intr_cnt_i(intr_cnt), .ras_sent_i(ras_sent), .ras_lost_i(ras_lost),
    .col_fail_i(fr_col_mask), .bank_cnt_i(fr_bank_cnt),
    .first_valid_i(fail_valid_o), .first_bank_i(fr_first_bank), .first_row_i(fr_first_row), .first_bit_i(fr_first_bit),
    .first_bit_v_i(fr_first_bit_v), .first_in_check_i(fr_first_inc), .first_elem_i(fr_first_elem), .first_op_i(fr_first_op),
    .first_pol_i(fr_first_pol), .first_pass_i(fr_first_pass), .first_cls_i(fr_first_cls), .first_alias_i(fr_first_alias),
    .first_exp_i(fr_first_exp), .first_obs_i(fr_first_obs),
    .head_valid_i(fr_head_valid), .head_bank_i(fr_head_bank), .head_row_i(fr_head_row), .head_bit_i(fr_head_bit),
    .head_bit_v_i(fr_head_bit_v), .head_in_check_i(fr_head_inc), .head_elem_i(fr_head_elem), .head_op_i(fr_head_op),
    .head_pol_i(fr_head_pol), .head_pass_i(fr_head_pass), .head_cls_i(fr_head_cls), .head_alias_i(fr_head_alias),
    .head_exp_i(fr_head_exp), .head_obs_i(fr_head_obs),
    .rep_touched_i(rep_touched), .rep_unrep_i(rep_unrep_o), .rep_ok_i(rep_ok_o),
    .rep_row_v_i(rep_row_v_o), .rep_row_i(rep_row_o), .rep_col_v_i(rep_col_v_o), .rep_col_i(rep_col_o));

  assign rep_touched = rep_ok_o | rep_unrep_o;       // unrep is only ever set on a touched bank
endmodule

`default_nettype wire
