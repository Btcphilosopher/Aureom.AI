// =============================================================================
// SilicaFlux SRAMFabric (Project 74) :: sf_sdf_port -- ONE SFB3 target port bridged to NP SRAM-controller master ports
//
//   t_* (SFB3 target)                                                                    c_* (NP controller masters)
//   request  --> [REQ stage] --> translate / check --> lane steering --> (src,id)->port --> c_req_*
//                 (skid, opt.)    sf_sdf_addr_xlate       byte enables       txq push (on controller acceptance)
//   response <-- [RSP stage] <-- status map / lane select <-- RR pick <-- c_rsp_*  (txq head cross-check, orphan drop)
//                 (register, opt.)             synthetic TIMEOUT / RESET responses <-- txq (flush / timeout recovery)
//
// The fabric-side protocol is SFB3 exactly as documented (third_party/noc_sfb3/PROTOCOL_SFB3.md, rules R1-R5, R11,
// O2).  Nothing is added to or removed from the SFB3 signal set.  Conversions are documented in
// docs/PROTOCOL_MAPPING.md; the short form:
//   byte address  -> window test, range test, alignment test (sf_sdf_addr_xlate) -> controller line address + lane
//   wdata/wstrb   -> placed on lane `lane` of the 128-bit line, all other lanes' byte enables 0
//   read data     <- the same lane of the returned line (a read always returns a full DW word, SFB3 R10)
//   id / src / op -> carried through the controller as its transaction id {bad, op, src, id, lane}, and held in the txq
//   status        -> cause NONE = ST_OKAY; every other cause = ST_SLVERR with rdata = 0 (SFB3: errors have no side effect)
//   posted write  -> executed like a write; its response is the posted COMPLETION the fabric retires (R5)
//
// Illegal requests (cause != NONE) never touch an array: they are forwarded to the controller as a READ of an
// address that the controller itself rejects (all ones: out of range AND misaligned), so that exactly one response
// exists for them and it stays in order behind earlier requests of the same (src,id) (SFB3 R5 / O2).
//
// Ordering (SFB3 R5): every (src,id) pair is pinned to ONE controller port, port = (src + id) mod NP; the controller
// answers one port in acceptance order, so a pair's responses leave in acceptance order.  Different pairs may be
// answered out of order across ports (legal).  NP = 1 -> fully in order.
//
// Flow control: registered ready on the request side when REQ_REG = 1 (the controller's grant logic is then not in the
// t_req_ready path).  t_rsp_* come from a register when RSP_REG = 1 (required for flush recovery: the response held
// under back-pressure then stays valid and unchanged, SFB3 R4, even while the controller is flushed).  With
// RSP_REG = 0 the response mux is combinational and c_flush_i must be tied low.
//
// Recovery (docs/ERRORS_AND_RECOVERY.md):
//   c_flush_i  (controller discarding in-flight work: connect to flush_busy_o | ~controller_rst_n)
//              -> bridge stops accepting, waits for the flush to end, then completes EVERY transaction that was in
//                 flight with ST_SLVERR / cause RESET (SFB3: exactly one response per accepted request).  Writes the
//                 controller had accepted stay committed (controller O7); the response does not say so: treat the
//                 outcome of a write answered with cause RESET / TIMEOUT as unknown.
//   TIMEOUT    -> a transaction accepted by the controller but unanswered for TIMEOUT cycles (and not waiting for the
//                 bridge's own downstream) is a controller fault.  TO_ACTION = 1: pulse c_flush_o (wire it to the
//                 controller flush_i) and recover as above with cause TIMEOUT; TO_ACTION = 0: report only.
//   reset      -> asynchronous assert / synchronous release (SFB3 R11): everything in flight is cancelled, no response
//                 is delivered for it.  The controller must share the reset domain (a controller-only reset is
//                 c_flush_i).
//
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sf_sdf_defs.svh"
`default_nettype none

module sf_sdf_port #(
  parameter int            NM        = 4,          // fabric masters (source-id width)
  parameter int            AW        = 32,
  parameter int            DW        = 128,        // fabric data width: 32, 64 or 128
  parameter int            IDW       = 2,
  parameter int            NP        = 1,          // controller master ports used by this port (power of two)
  parameter int            LINE_W    = 128,
  parameter int            NB        = 4,          // controller banks (address translation, per-bank statistics)
  parameter int            DEPTH     = 1024,       // controller rows per bank
  parameter logic [AW-1:0] WIN_BASE  = 32'h2000_0000,
  parameter int            WIN_LOG2  = 20,         // window size 2^WIN_LOG2 bytes (power of two, base aligned to it)
  parameter int            ALLOW_LO  = 0,          // allowed byte offsets [ALLOW_LO, ALLOW_HI) inside the window
  parameter int            ALLOW_HI  = NB * DEPTH * (LINE_W / 8),
  parameter int            REQ_REG   = 1,
  parameter int            RSP_REG   = 1,
  parameter int            CTRL_NSLOT = 8,         // NSLOT of the controller (TXQ_DEPTH must cover it)
  parameter int            TXQ_DEPTH = 8,
  parameter int            TIMEOUT   = 0,          // 0 = disabled
  parameter int            TO_ACTION = 1,
  parameter int            FLUSH_WAIT = 32,        // cycles to wait for a requested flush to appear before giving up
  parameter int            TS_W      = 16,
  parameter int            CNT_W     = 32,
  // ---- derived (do not override)
  parameter int            SRCW      = (NM > 1) ? $clog2(NM) : 1,
  parameter int            SB        = DW / 8,
  parameter int            LANEW     = (DW < LINE_W) ? $clog2(LINE_W / DW) : 1,
  parameter int            NPW       = (NP > 1) ? $clog2(NP) : 1,
  parameter int            IDC       = 3 + SRCW + IDW + LANEW + 1,        // controller id {bad, op, src, id, lane}
  parameter int            BW        = (NB > 1) ? $clog2(NB) : 1,
  parameter int            ROW_W     = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int            EW        = AW + 3 + SRCW + IDW + LANEW + 1 + 3 + TS_W,   // txq entry
  parameter int            QCW       = $clog2(TXQ_DEPTH + 1)
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------------- SFB3 target port (from the fabric)
  input  wire logic                   t_req_valid,
  output logic                        t_req_ready,
  input  wire logic [2:0]             t_req_opcode,
  input  wire logic [SRCW-1:0]        t_req_src,
  input  wire logic [IDW-1:0]         t_req_id,
  input  wire logic [2:0]             t_req_qos,
  input  wire logic [AW-1:0]          t_req_addr,
  input  wire logic [DW-1:0]          t_req_wdata,
  input  wire logic [SB-1:0]          t_req_wstrb,
  output logic                        t_rsp_valid,
  input  wire logic                   t_rsp_ready,
  output logic [SRCW-1:0]             t_rsp_src,
  output logic [IDW-1:0]              t_rsp_id,
  output logic [2:0]                  t_rsp_opcode,
  output logic [1:0]                  t_rsp_status,
  output logic [DW-1:0]               t_rsp_rdata,
  output logic [2:0]                  rsp_cause_o,        // informational sideband (NOT part of SFB3): cause of t_rsp_status
  // ---------------------------------------------------------------- controller master ports (NP)
  output logic [NP-1:0]               c_req_valid,
  input  wire logic [NP-1:0]          c_req_ready,
  output logic [NP-1:0]               c_req_we,
  output logic [NP*AW-1:0]            c_req_addr,
  output logic [NP*LINE_W-1:0]        c_req_wdata,
  output logic [NP*(LINE_W/8)-1:0]    c_req_be,
  output logic [NP*IDC-1:0]           c_req_id,
  input  wire logic [NP-1:0]          c_rsp_valid,
  output logic [NP-1:0]               c_rsp_ready,
  input  wire logic [NP*LINE_W-1:0]   c_rsp_rdata,
  input  wire logic [NP*IDC-1:0]      c_rsp_id,
  input  wire logic [NP-1:0]          c_rsp_we,
  input  wire logic [NP*3-1:0]        c_rsp_status,
  input  wire logic [NP-1:0]          c_rsp_ce,
  // ---------------------------------------------------------------- controller recovery
  input  wire logic                   c_flush_i,          // controller is discarding in-flight work
  output logic                        c_flush_o,          // 1-cycle request to flush the controller (timeout recovery)
  // ---------------------------------------------------------------- status / statistics
  input  wire logic                   err_clr_i,
  input  wire logic                   cnt_clr_i,
  output logic                        err_sticky_o,
  output logic [CNT_W-1:0]            err_cnt_o,
  output logic [2:0]                  err_code_o,
  output logic [SRCW-1:0]             err_src_o,
  output logic [IDW-1:0]              err_id_o,
  output logic [2:0]                  err_opcode_o,
  output logic [AW-1:0]               err_addr_o,
  output logic [8*CNT_W-1:0]          cause_cnt_o,        // responses per cause (index = cause; [0] counts nothing)
  output logic [`SDF_NPERF*CNT_W-1:0] perf_o,
  output logic [NB*CNT_W-1:0]         bank_acc_o,         // legal accesses per target bank (as translated by the bridge)
  output logic [NB*CNT_W-1:0]         bank_stall_o,       // cycles a request to that bank waited for the controller
  output logic [15:0]                 out_cnt_o,          // transactions in flight (controller side + response stage)
  output logic [1:0]                  state_o,            // 0 RUN, 1 FLUSH, 2 DRAIN
  output logic                        irq_o
);
  // ------------------------------------------------------------ parameter validation
  if (DW != 32 && DW != 64 && DW != 128) begin : g_err_dw
    `SF_CFG_FATAL("sf_sdf_port: fabric DW must be 32, 64 or 128")
  end
  if (LINE_W != 128 || DW > LINE_W) begin : g_err_line
    `SF_CFG_FATAL("sf_sdf_port: LINE_W must be 128 and DW <= LINE_W")
  end
  if (NP < 1 || (NP & (NP - 1)) != 0) begin : g_err_np
    `SF_CFG_FATAL("sf_sdf_port: NP must be a power of two")
  end
  if (TXQ_DEPTH < CTRL_NSLOT) begin : g_err_txq
    `SF_CFG_FATAL("sf_sdf_port: TXQ_DEPTH must be >= the controller NSLOT (the queue mirrors the controller reorder slots)")
  end
  if (ALLOW_LO < 0 || ALLOW_HI <= ALLOW_LO || ALLOW_HI > NB * DEPTH * (LINE_W / 8)) begin : g_err_allow
    `SF_CFG_FATAL("sf_sdf_port: need 0 <= ALLOW_LO < ALLOW_HI <= controller capacity")
  end
  if (WIN_LOG2 < 4 || WIN_LOG2 > AW) begin : g_err_win
    `SF_CFG_FATAL("sf_sdf_port: WIN_LOG2 out of range")
  end
  if (64'(ALLOW_HI) > (64'd1 << WIN_LOG2)) begin : g_err_winsz
    `SF_CFG_FATAL("sf_sdf_port: ALLOW_HI exceeds the window size")
  end
  if (TS_W < 4) begin : g_err_ts
    `SF_CFG_FATAL("sf_sdf_port: TS_W must be >= 4")
  end

  localparam logic [2:0] OP_READ = `SDF_OP_READ, OP_WRITE = `SDF_OP_WRITE, OP_WRITE_POSTED = `SDF_OP_WRITE_POSTED;
  localparam int FSM_RUN = 0, FSM_FLUSH = 1, FSM_DRAIN = 2;
  localparam int NPERF = `SDF_NPERF;

  // ------------------------------------------------------------ cycle counter (timestamps)
  logic [TS_W-1:0] cyc;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) cyc <= '0;
    else        cyc <= cyc + 1'b1;
  end

  // ------------------------------------------------------------ recovery state (declared early: used by the gate)
  logic [1:0] fsm_q;
  wire        gate = (fsm_q != 2'(FSM_RUN)) | c_flush_i;

  // ------------------------------------------------------------ REQ stage
  localparam int PW = TS_W + 3 + SRCW + IDW + AW + DW + SB;
  wire [PW-1:0] in_pay = {cyc, t_req_opcode, t_req_src, t_req_id, t_req_addr, t_req_wdata, t_req_wstrb};
  logic          s_valid, s_ready;
  logic [PW-1:0] s_pay;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [1:0]    in_occ;
  /* verilator lint_on UNUSEDSIGNAL */
  if (REQ_REG != 0) begin : g_req_reg
    sf_sdf_skid #(.W(PW)) u_in (
      .clk(clk), .rst_n(rst_n), .clr_i(1'b0),
      .in_valid(t_req_valid), .in_ready(t_req_ready), .in_data(in_pay),
      .out_valid(s_valid), .out_ready(s_ready), .out_data(s_pay), .occ_o(in_occ));
  end else begin : g_req_direct
    assign s_valid     = t_req_valid;
    assign t_req_ready = s_ready;
    assign s_pay       = in_pay;
    assign in_occ      = 2'd0;
  end
  wire [TS_W-1:0]  s_ts;
  wire [2:0]       s_op;
  wire [SRCW-1:0]  s_src;
  wire [IDW-1:0]   s_id;
  wire [AW-1:0]    s_addr;
  wire [DW-1:0]    s_wdata;
  wire [SB-1:0]    s_wstrb;
  assign {s_ts, s_op, s_src, s_id, s_addr, s_wdata, s_wstrb} = s_pay;

  // ------------------------------------------------------------ translate / check
  wire             x_hit, x_misal;
  wire [AW-1:0]    x_off, x_word, x_line;
  wire [BW-1:0]    x_bank;
  wire [ROW_W-1:0] x_row;
  wire [LANEW-1:0] x_lane;
  wire [2:0]       x_cause;
  sf_sdf_addr_xlate #(.AW(AW), .DW(DW), .LINE_W(LINE_W), .NB(NB), .DEPTH(DEPTH), .WIN_BASE(WIN_BASE),
                      .WIN_LOG2(WIN_LOG2), .ALLOW_LO(ALLOW_LO), .ALLOW_HI(ALLOW_HI)) u_xl (
    .addr(s_addr), .win_hit(x_hit), .off(x_off), .word_addr(x_word), .line_addr(x_line), .bank(x_bank),
    .row(x_row), .lane(x_lane), .misal(x_misal), .cause(x_cause));

  wire is_rd  = (s_op == OP_READ);
  wire is_wr  = (s_op == OP_WRITE) || (s_op == OP_WRITE_POSTED);
  wire bad_op = ~(is_rd | is_wr);
  wire [2:0] cause = bad_op ? `SDF_CAUSE_OPCODE : x_cause;
  wire bad    = (cause != `SDF_CAUSE_NONE);
  wire do_wr  = is_wr & ~bad;

  logic [LINE_W-1:0]   wline;
  logic [LINE_W/8-1:0] bline;
  if (DW == LINE_W) begin : g_wide
    assign wline = LINE_W'(s_wdata);
    assign bline = (LINE_W/8)'(s_wstrb);
  end else begin : g_narrow
    always_comb begin
      wline = '0;
      bline = '0;
      for (int l = 0; l < LINE_W / DW; l++)
        if (x_lane == LANEW'(l)) begin
          wline[l*DW +: DW] = s_wdata;
          bline[l*SB +: SB] = s_wstrb;
        end
    end
  end

  wire [IDC-1:0] cid = {bad, s_op, s_src, s_id, x_lane};
  wire [AW-1:0]  caddr = bad ? {AW{1'b1}} : x_line;

  // (src,id) -> controller port
  wire [NPW-1:0] psel = (NP > 1) ? (NPW'(s_src) + NPW'(s_id)) : '0;

  assign s_ready = ~gate & c_req_ready[psel];
  always_comb begin
    for (int p = 0; p < NP; p++) c_req_valid[p] = s_valid & ~gate & (psel == NPW'(p));
  end
  assign c_req_we    = {NP{do_wr}};
  assign c_req_addr  = {NP{caddr}};
  assign c_req_wdata = {NP{wline}};
  assign c_req_be    = {NP{do_wr ? bline : {(LINE_W/8){1'b0}}}};
  assign c_req_id    = {NP{cid}};
  wire acc = s_valid & s_ready;                              // accepted by the controller this cycle
  wire unused_qos = &{1'b0, t_req_qos, x_hit, x_misal, x_off, x_word, x_row};

  // ------------------------------------------------------------ transaction queues (one per controller port)
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NP-1:0]        q_full;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NP-1:0]        q_push, q_pop, q_empty, q_ovf, q_udf;
  logic [NP*EW-1:0]     q_head;
  logic [NP*QCW-1:0]    q_cnt;
  wire  [EW-1:0]        q_data = {s_ts, cause, bad, x_lane, s_id, s_src, s_op, s_addr};
  logic                 q_clr;
  for (genvar p = 0; p < NP; p++) begin : g_q
    assign q_push[p] = acc & (psel == NPW'(p));
    sf_sdf_txq #(.DEPTH(TXQ_DEPTH), .EW(EW)) u_q (
      .clk(clk), .rst_n(rst_n), .clr_i(q_clr), .push_i(q_push[p]), .push_d(q_data), .pop_i(q_pop[p]),
      .head_d(q_head[p*EW +: EW]), .count_o(q_cnt[p*QCW +: QCW]), .empty_o(q_empty[p]), .full_o(q_full[p]),
      .ovf_o(q_ovf[p]), .udf_o(q_udf[p]));
  end

  // unpack helpers for the head of port h
  function automatic logic [EW-1:0] qh(input logic [NP*EW-1:0] v, input logic [NPW-1:0] h);
    qh = v[h*EW +: EW];
  endfunction
  localparam int H_ADDR = 0;
  localparam int H_OP   = H_ADDR + AW;
  localparam int H_SRC  = H_OP + 3;
  localparam int H_ID   = H_SRC + SRCW;
  localparam int H_LANE = H_ID + IDW;
  localparam int H_BAD  = H_LANE + LANEW;
  localparam int H_CAUSE = H_BAD + 1;
  localparam int H_TS   = H_CAUSE + 3;

  // ------------------------------------------------------------ response selection (real responses)
  logic [NP-1:0]  cand;
  logic [NP-1:0]  orph;
  always_comb begin
    for (int p = 0; p < NP; p++) begin
      cand[p] = c_rsp_valid[p] & ~q_empty[p] & (fsm_q == 2'(FSM_RUN));
      orph[p] = c_rsp_valid[p] &  q_empty[p];
    end
  end

  logic [NPW-1:0] rr_ptr, sel_q, sel, pick;
  logic           lock_q, pick_v;
  always_comb begin
    /* verilator lint_off UNUSEDSIGNAL */
    integer pi, kk;
    /* verilator lint_on UNUSEDSIGNAL */
    pick = '0; pick_v = 1'b0; pi = 0; kk = 0;
    for (kk = 0; kk < NP; kk = kk + 1) begin
      pi = ({{(32-NPW){1'b0}}, rr_ptr} + kk) % NP;
      if (!pick_v && cand[pi]) begin pick = NPW'(pi); pick_v = 1'b1; end
    end
  end
  assign sel = lock_q ? sel_q : pick;
  wire have_real = (lock_q | pick_v) & cand[sel];

  wire [IDC-1:0]    rid   = c_rsp_id[sel*IDC +: IDC];
  wire [LINE_W-1:0] rline = c_rsp_rdata[sel*LINE_W +: LINE_W];
  wire [2:0]        rst3  = c_rsp_status[sel*3 +: 3];
  wire              rwe   = c_rsp_we[sel];
  wire              rce   = c_rsp_ce[sel];
  wire [EW-1:0]     hd    = qh(q_head, sel);
  wire [AW-1:0]       hd_addr  = hd[H_ADDR +: AW];
  wire [2:0]          hd_op    = hd[H_OP +: 3];
  wire [SRCW-1:0]     hd_src   = hd[H_SRC +: SRCW];
  wire [IDW-1:0]      hd_id    = hd[H_ID +: IDW];
  wire [LANEW-1:0]    hd_lane  = hd[H_LANE +: LANEW];
  wire                hd_bad   = hd[H_BAD];
  wire [2:0]          hd_cause = hd[H_CAUSE +: 3];
  wire [TS_W-1:0]     hd_ts    = hd[H_TS +: TS_W];
  wire proto_mis = have_real & (rid != {hd_bad, hd_op, hd_src, hd_id, hd_lane});

  logic [2:0] cause_real;
  always_comb begin
    if (hd_cause != `SDF_CAUSE_NONE)      cause_real = hd_cause;
    else if (rst3 == `SF_ST_OK)           cause_real = `SDF_CAUSE_NONE;
    else if (rst3 == `SF_ST_ECC_UE)       cause_real = `SDF_CAUSE_ECC;
    else                                  cause_real = `SDF_CAUSE_SRAM;
  end
  logic [DW-1:0] rword;
  always_comb begin
    rword = '0;
    if (DW == LINE_W) rword = DW'(rline);
    else for (int l = 0; l < LINE_W / DW; l++) if (hd_lane == LANEW'(l)) rword = rline[l*DW +: DW];
  end
  wire [DW-1:0] rdata_real = (cause_real != `SDF_CAUSE_NONE || rwe || hd_op != OP_READ) ? '0 : rword;

  // ------------------------------------------------------------ synthetic responses (flush / timeout recovery)
  logic [NPW-1:0] sp;
  logic           synth_v;
  always_comb begin
    sp = '0; synth_v = 1'b0;
    for (int p = NP - 1; p >= 0; p--) if (!q_empty[p]) begin sp = NPW'(p); synth_v = 1'b1; end
  end
  logic [2:0]  dcause_q;
  /* verilator lint_off UNUSEDSIGNAL */
  wire  [EW-1:0] sh = qh(q_head, sp);
  /* verilator lint_on UNUSEDSIGNAL */
  wire in_synth = (fsm_q == 2'(FSM_DRAIN)) & synth_v;

  // ------------------------------------------------------------ RSP stage
  localparam int OW = 3 + SRCW + IDW + 3 + DW + TS_W + AW;     // {cause, src, id, op, rdata, ts, addr}
  logic            rin_valid, rin_ready;
  logic [OW-1:0]   rin_pay;
  assign rin_valid = in_synth | have_real;
  assign rin_pay   = in_synth ? {dcause_q, sh[H_SRC +: SRCW], sh[H_ID +: IDW], sh[H_OP +: 3], {DW{1'b0}}, sh[H_TS +: TS_W], sh[H_ADDR +: AW]}
                              : {cause_real, hd_src, hd_id, hd_op, rdata_real, hd_ts, hd_addr};
  logic            o_valid;
  logic [OW-1:0]   o_pay;
  if (RSP_REG != 0) begin : g_rsp_reg
    assign rin_ready = ~o_valid | t_rsp_ready;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) o_valid <= 1'b0;
      else if (rin_ready) o_valid <= rin_valid;
    end
    always_ff @(posedge clk) begin
      if (rin_ready && rin_valid) o_pay <= rin_pay;
    end
  end else begin : g_rsp_direct
    assign rin_ready = t_rsp_ready;
    assign o_valid   = rin_valid;
    assign o_pay     = rin_pay;
  end
  wire [2:0]       o_cause;
  wire [SRCW-1:0]  o_src;
  wire [IDW-1:0]   o_id;
  wire [2:0]       o_op;
  wire [DW-1:0]    o_rdata;
  wire [TS_W-1:0]  o_ts;
  wire [AW-1:0]    o_addr;
  assign {o_cause, o_src, o_id, o_op, o_rdata, o_ts, o_addr} = o_pay;

  assign t_rsp_valid  = o_valid;
  assign t_rsp_src    = o_src;
  assign t_rsp_id     = o_id;
  assign t_rsp_opcode = o_op;
  assign t_rsp_status = (o_cause == `SDF_CAUSE_NONE) ? `SDF_ST_OKAY : `SDF_ST_SLVERR;
  assign t_rsp_rdata  = o_rdata;
  assign rsp_cause_o  = o_cause;
  wire o_fire = o_valid & t_rsp_ready;

  // consume / pop
  always_comb begin
    for (int p = 0; p < NP; p++) begin
      c_rsp_ready[p] = orph[p] | (cand[p] & have_real & (sel == NPW'(p)) & rin_ready);
      q_pop[p]       = (c_rsp_valid[p] & c_rsp_ready[p] & ~q_empty[p] & ~orph[p])
                     | (in_synth & rin_ready & (sp == NPW'(p)));
    end
  end
  wire real_fire = have_real & rin_ready;

  // lock the selected port while its response is stalled (needed for RSP_REG = 0; harmless otherwise)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin lock_q <= 1'b0; sel_q <= '0; rr_ptr <= '0; end
    else begin
      if (have_real && !rin_ready) begin lock_q <= 1'b1; sel_q <= sel; end
      else if (real_fire) begin
        lock_q <= 1'b0;
        rr_ptr <= (sel == NPW'(NP - 1)) ? '0 : sel + 1'b1;
      end
    end
  end

  // ------------------------------------------------------------ timeout detection
  localparam int TOW = (TIMEOUT > 1) ? $clog2(TIMEOUT + 1) : 1;
  logic [NP-1:0] to_hit;
  for (genvar p = 0; p < NP; p++) begin : g_to
    logic [TOW-1:0] tcnt;
    wire waiting = ~q_empty[p] & ~c_rsp_valid[p] & (fsm_q == 2'(FSM_RUN));
    assign to_hit[p] = (TIMEOUT > 0) & waiting & (tcnt == TOW'(TIMEOUT - 1));
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n)                              tcnt <= '0;
      else if (!waiting)                       tcnt <= '0;
      else if (tcnt != TOW'(TIMEOUT))          tcnt <= tcnt + 1'b1;
    end
  end
  wire to_fire = |to_hit;
  logic [NPW-1:0] to_port;
  always_comb begin
    to_port = '0;
    for (int p = NP - 1; p >= 0; p--) if (to_hit[p]) to_port = NPW'(p);
  end

  // ------------------------------------------------------------ flush / timeout recovery FSM
  logic           seen_q, freq_q;
  logic [7:0]     fw_q;
  wire            q_all_empty = &q_empty;
  assign c_flush_o = freq_q;
  assign q_clr     = 1'b0;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fsm_q <= 2'(FSM_RUN); dcause_q <= `SDF_CAUSE_NONE; seen_q <= 1'b0; freq_q <= 1'b0; fw_q <= '0;
    end else begin
      freq_q <= 1'b0;
      case (fsm_q)
        2'(FSM_RUN): begin
          if (c_flush_i) begin
            fsm_q <= 2'(FSM_FLUSH); dcause_q <= `SDF_CAUSE_RESET; seen_q <= 1'b1; fw_q <= '0;
          end else if (TO_ACTION != 0 && to_fire) begin
            fsm_q <= 2'(FSM_FLUSH); dcause_q <= `SDF_CAUSE_TIMEOUT; seen_q <= 1'b0; freq_q <= 1'b1; fw_q <= '0;
          end
        end
        2'(FSM_FLUSH): begin
          fw_q <= (fw_q == 8'hFF) ? fw_q : fw_q + 1'b1;
          if (c_flush_i) seen_q <= 1'b1;
          else if (seen_q || fw_q >= 8'(FLUSH_WAIT)) fsm_q <= q_all_empty ? 2'(FSM_RUN) : 2'(FSM_DRAIN);
        end
        default: begin   // FSM_DRAIN
          if (q_all_empty) fsm_q <= 2'(FSM_RUN);
        end
      endcase
    end
  end
  assign state_o = fsm_q;

  // ------------------------------------------------------------ error log
  logic [CNT_W-1:0] cc [8];
  wire  log_err = o_fire & (o_cause != `SDF_CAUSE_NONE);
  wire  to_log  = (TO_ACTION == 0) & to_fire & (TIMEOUT > 0);          // report-only timeout
  /* verilator lint_off UNUSEDSIGNAL */
  wire [EW-1:0]     th = qh(q_head, to_port);
  /* verilator lint_on UNUSEDSIGNAL */
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_sticky_o <= 1'b0; err_cnt_o <= '0; err_code_o <= '0; err_src_o <= '0; err_id_o <= '0; err_opcode_o <= '0;
      err_addr_o <= '0;
    end else if (err_clr_i) begin
      err_sticky_o <= 1'b0; err_cnt_o <= '0;
    end else begin
      if (log_err || to_log) begin
        if (err_cnt_o != {CNT_W{1'b1}}) err_cnt_o <= err_cnt_o + 1'b1;
        if (!err_sticky_o) begin
          err_sticky_o <= 1'b1;
          if (log_err) begin
            err_code_o <= o_cause; err_src_o <= o_src; err_id_o <= o_id; err_opcode_o <= o_op; err_addr_o <= o_addr;
          end else begin
            err_code_o <= `SDF_CAUSE_TIMEOUT; err_src_o <= th[H_SRC +: SRCW]; err_id_o <= th[H_ID +: IDW];
            err_opcode_o <= th[H_OP +: 3]; err_addr_o <= th[H_ADDR +: AW];
          end
        end
      end
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int c = 0; c < 8; c++) cc[c] <= '0;
    end else if (cnt_clr_i) begin
      for (int c = 0; c < 8; c++) cc[c] <= '0;
    end else if (log_err) begin
      cc[o_cause] <= cc[o_cause] + 1'b1;
    end
  end
  always_comb begin
    for (int c = 0; c < 8; c++) cause_cnt_o[c*CNT_W +: CNT_W] = cc[c];
  end
  assign irq_o = err_sticky_o;

  // ------------------------------------------------------------ statistics
  logic [CNT_W-1:0] pc [NPERF];
  logic [CNT_W-1:0] bacc [NB];
  logic [CNT_W-1:0] bstall [NB];
  logic [15:0]      outst;
  logic [QCW+NPW+1:0] occ_now;
  always_comb begin
    occ_now = '0;
    for (int p = 0; p < NP; p++) occ_now = occ_now + (QCW+NPW+2)'(q_cnt[p*QCW +: QCW]);
    occ_now = occ_now + (QCW+NPW+2)'(o_valid);
  end
  assign outst     = 16'(occ_now);
  assign out_cnt_o = outst;

  wire legal   = acc & ~bad;
  wire seq_hit;
  logic            last_v;
  logic [SRCW-1:0] last_src;
  logic [IDW-1:0]  last_id;
  logic [AW-1:0]   last_addr;
  assign seq_hit = last_v & (last_src == s_src) & (last_id == s_id) & (s_addr == last_addr + AW'(DW / 8));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin last_v <= 1'b0; last_src <= '0; last_id <= '0; last_addr <= '0; end
    else if (legal) begin last_v <= 1'b1; last_src <= s_src; last_id <= s_id; last_addr <= s_addr; end
  end

  logic [CNT_W-1:0] wbytes;
  always_comb begin
    wbytes = '0;
    for (int b = 0; b < SB; b++) wbytes = wbytes + CNT_W'(s_wstrb[b]);
  end
  wire [TS_W-1:0]   lat_t = cyc - o_ts;
  wire [CNT_W-1:0]  lat   = CNT_W'(lat_t);
  logic [3:0]       orph_n;
  always_comb begin
    orph_n = '0;
    for (int p = 0; p < NP; p++) orph_n = orph_n + 4'(orph[p]);
  end
  wire any_ovf = |q_ovf;
  wire any_udf = |q_udf;
  wire ctrl_wait = s_valid & ~gate & ~c_req_ready[psel];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NPERF; i++) pc[i] <= '0;
      pc[`SDF_P_LAT_MIN] <= {CNT_W{1'b1}};
      for (int b = 0; b < NB; b++) begin bacc[b] <= '0; bstall[b] <= '0; end
    end else if (cnt_clr_i) begin
      for (int i = 0; i < NPERF; i++) pc[i] <= '0;
      pc[`SDF_P_LAT_MIN] <= {CNT_W{1'b1}};
      for (int b = 0; b < NB; b++) begin bacc[b] <= '0; bstall[b] <= '0; end
    end else begin
      pc[`SDF_P_CYCLES] <= pc[`SDF_P_CYCLES] + 1'b1;
      if (acc) pc[`SDF_P_REQ] <= pc[`SDF_P_REQ] + 1'b1;
      if (legal) begin
        pc[`SDF_P_LINE_ACC] <= pc[`SDF_P_LINE_ACC] + 1'b1;
        bacc[x_bank] <= bacc[x_bank] + 1'b1;
        if (is_rd) begin
          pc[`SDF_P_RD] <= pc[`SDF_P_RD] + 1'b1;
          pc[`SDF_P_BYTES_RD] <= pc[`SDF_P_BYTES_RD] + CNT_W'(DW / 8);
        end else begin
          pc[`SDF_P_WR] <= pc[`SDF_P_WR] + 1'b1;
          pc[`SDF_P_BYTES_WR] <= pc[`SDF_P_BYTES_WR] + wbytes;
          if (s_op == OP_WRITE_POSTED) pc[`SDF_P_POSTED] <= pc[`SDF_P_POSTED] + 1'b1;
        end
        if (seq_hit) pc[`SDF_P_SEQ] <= pc[`SDF_P_SEQ] + 1'b1;
        else         pc[`SDF_P_RUNS] <= pc[`SDF_P_RUNS] + 1'b1;
      end
      if (o_fire) begin
        pc[`SDF_P_RSP] <= pc[`SDF_P_RSP] + 1'b1;
        pc[`SDF_P_LAT_SUM] <= pc[`SDF_P_LAT_SUM] + lat;
        if (lat > pc[`SDF_P_LAT_MAX]) pc[`SDF_P_LAT_MAX] <= lat;
        if (lat < pc[`SDF_P_LAT_MIN]) pc[`SDF_P_LAT_MIN] <= lat;
        if (o_cause != `SDF_CAUSE_NONE) pc[`SDF_P_ERR_RSP] <= pc[`SDF_P_ERR_RSP] + 1'b1;
      end
      if (t_req_valid && !t_req_ready) pc[`SDF_P_REQ_STALL] <= pc[`SDF_P_REQ_STALL] + 1'b1;
      if (t_rsp_valid && !t_rsp_ready) pc[`SDF_P_RSP_STALL] <= pc[`SDF_P_RSP_STALL] + 1'b1;
      if (ctrl_wait) begin
        pc[`SDF_P_CTRL_STALL] <= pc[`SDF_P_CTRL_STALL] + 1'b1;
        if (!bad) bstall[x_bank] <= bstall[x_bank] + 1'b1;
      end
      pc[`SDF_P_OCC_SUM] <= pc[`SDF_P_OCC_SUM] + CNT_W'(occ_now);
      if (CNT_W'(occ_now) > pc[`SDF_P_OCC_MAX]) pc[`SDF_P_OCC_MAX] <= CNT_W'(occ_now);
      if (occ_now != '0) pc[`SDF_P_BUSY] <= pc[`SDF_P_BUSY] + 1'b1;
      if (real_fire && rce) pc[`SDF_P_CE] <= pc[`SDF_P_CE] + 1'b1;
      pc[`SDF_P_ORPHAN] <= pc[`SDF_P_ORPHAN] + CNT_W'(orph_n);
      if (proto_mis || any_udf) pc[`SDF_P_PROTO] <= pc[`SDF_P_PROTO] + 1'b1;
      if (any_ovf) pc[`SDF_P_OVF] <= pc[`SDF_P_OVF] + 1'b1;
      if (to_fire) pc[`SDF_P_TIMEOUT] <= pc[`SDF_P_TIMEOUT] + 1'b1;
      if (in_synth && rin_ready) pc[`SDF_P_SYNTH] <= pc[`SDF_P_SYNTH] + 1'b1;
    end
  end
  always_comb begin
    for (int i = 0; i < NPERF; i++) perf_o[i*CNT_W +: CNT_W] = pc[i];
    for (int b = 0; b < NB; b++) begin
      bank_acc_o[b*CNT_W +: CNT_W]   = bacc[b];
      bank_stall_o[b*CNT_W +: CNT_W] = bstall[b];
    end
  end

  // ------------------------------------------------------------ embedded checks (SF_ASSERT / FORMAL)
  `ifdef SF_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    `SF_CHK(!any_ovf, "sf_sdf_port: transaction queue overflow")
    `SF_CHK(!any_udf, "sf_sdf_port: transaction queue underflow")
    `SF_CHK(!proto_mis, "sf_sdf_port: controller response does not match the transaction queue head")
    `SF_CHK(!(gate && s_valid && s_ready), "sf_sdf_port: request accepted while gated (flush / drain)")
    `SF_CHK(!(o_fire && (cyc - o_ts) == '0), "sf_sdf_port: response in the acceptance cycle (SFB3 R5)")
    `SF_CHK(!(RSP_REG == 0 && c_flush_i), "sf_sdf_port: c_flush_i requires RSP_REG = 1")
    `SF_CHK(!(c_req_valid != '0 && $countones(c_req_valid) > 1), "sf_sdf_port: request presented on two controller ports")
  end
  `endif
endmodule

`default_nettype wire
