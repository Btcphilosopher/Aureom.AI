// =============================================================================
// SilicaFlux SRAMController (Project 73) :: sf_sramc_defs.svh
//
// Constants shared by the SRAM controller modules.  A `define header rather
// than a SystemVerilog package, for the same reason as SRAMCore (Project 71)
// and the SRAM Wrapper Library (Project 01): Yosys 0.33 cannot resolve package
// references in module parameter lists, and every synthesizable module here
// must elaborate unaided in Verilator, Icarus and Yosys.  All names carry the
// SFC_ prefix.  Values are part of the public contract: never renumber, only
// append.
// =============================================================================
`ifndef SF_SRAMC_DEFS_SVH
`define SF_SRAMC_DEFS_SVH

// ---------------------------------------------------------------- status codes
// 4-bit transaction status carried by every response (rsp_status).  rsp_err is
// the 1-bit SFB2 view: rsp_err = (rsp_status != SFC_ST_OK).  Precedence when a
// request has several faults is the order of the list below, top = reported.
`define SFC_ST_OK      4'd0   // transaction performed
`define SFC_ST_RANGE   4'd1   // byte address >= capacity                       (no side effect)
`define SFC_ST_ALIGN   4'd2   // byte address not aligned to the data width     (no side effect)
`define SFC_ST_MASK    4'd3   // write with unsupported byte strobes            (no side effect)
`define SFC_ST_SRC     4'd4   // invalid source: src != port, or source disabled (no side effect)
`define SFC_ST_ID      4'd5   // request ID already outstanding for this master  (no side effect)
`define SFC_ST_POISON  4'd6   // master flagged the request as poisoned (req_err) (no side effect)
`define SFC_ST_CANCEL  4'd7   // cancelled by flush (soft reset): read data discarded; a write
                              //   that was already issued to its bank WAS performed
`define SFC_ST_BANK    4'd8   // bank reported an error for this access

// ---------------------------------------------------------------- INTERLEAVE
`define SFC_ILV_LOW    0      // bank = word % NUM_BANKS      (consecutive words rotate through the banks)
`define SFC_ILV_HIGH   1      // bank = word / BANK_DEPTH     (contiguous region per bank)

// ---------------------------------------------------------------- MASK_MODE
`define SFC_MASK_ANY     0    // any non-zero write strobe pattern is supported
`define SFC_MASK_ALIGNED 1    // only naturally aligned contiguous byte runs (1,2,4,..,N bytes) are supported

// ---------------------------------------------------------------- master map (SoC wrapper)
`define SFC_MST_CTRL   0      // ControlCore
`define SFC_MST_DMA    1      // DMA
`define SFC_MST_VEC    2      // Vector Engine
`define SFC_MST_TENSOR 3      // TensorCore

// ---------------------------------------------------------------- performance counter map
// Global counters : index 0..15
`define SFC_PG_CYCLES      0   // cycles since perf_clr
`define SFC_PG_BUSY        1   // cycles with >= 1 outstanding transaction
`define SFC_PG_ACCEPTED    2   // requests accepted
`define SFC_PG_COMPLETED   3   // responses transferred
`define SFC_PG_RD_DONE     4   // read responses transferred
`define SFC_PG_WR_DONE     5   // write responses transferred
`define SFC_PG_ERR_DONE    6   // responses with status != OK transferred
`define SFC_PG_CONFLICT    7   // bank-conflict events: requesters that were eligible for a bank but lost the grant
`define SFC_PG_ORDER_STALL 8   // master-cycles held back by the per-master in-order (bank-lock) rule
`define SFC_PG_CANCELLED   9   // responses delivered with status CANCEL
`define SFC_PG_OUT_MAX    10   // high-water mark of total outstanding transactions
`define SFC_PG_RSP_STALL  11   // master-cycles with rsp_valid && !rsp_ready
`define SFC_PG_WAIT       12   // master-cycles with req_valid && !req_ready (arbitration + credit wait)
// Per master m : index 16 + 16*m + k
`define SFC_PM_ACC         0   // accepted
`define SFC_PM_CMP         1   // completed (response transferred)
`define SFC_PM_RD          2   // completed reads
`define SFC_PM_WR          3   // completed writes
`define SFC_PM_ERR         4   // completed with status != OK
`define SFC_PM_WAIT_SUM    5   // cycles req_valid && !req_ready   (avg arbitration wait = WAIT_SUM / ACC)
`define SFC_PM_WAIT_MAX    6   // longest run of consecutive wait cycles
`define SFC_PM_LAT_SUM     7   // sum over cycles of outstanding count (avg access latency = LAT_SUM / CMP once drained)
`define SFC_PM_OUT_MAX     8   // high-water mark of outstanding
`define SFC_PM_RSP_STALL   9   // cycles rsp_valid && !rsp_ready
`define SFC_PM_ORDER_STALL 10  // cycles held by the in-order (bank-lock) rule
`define SFC_PM_CANCEL      11  // CANCEL responses delivered
// Per bank b : index 16 + 16*NUM_MASTERS + 8*b + k
`define SFC_PB_ACCESS      0   // accesses issued to the bank
`define SFC_PB_RD          1   // reads issued
`define SFC_PB_WR          2   // writes issued
`define SFC_PB_BUSY        3   // cycles with >= 1 access in flight in the bank
`define SFC_PB_CONF_CYC    4   // cycles with >= 1 losing requester
`define SFC_PB_LOSERS      5   // sum of losing requesters

// ------------------------------------------------- configuration errors
// Elaboration-time failure for illegal parameterisations.  Icarus 12 does not
// evaluate elaboration-time $fatal, so it gets a time-0 $fatal instead.  Yosys
// 0.33 aborts on the $fatal but does not print the message; the message is
// therefore also encoded in the generate-block name (g_err_*).
`ifdef __ICARUS__
  `define SFC_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SFC_CFG_FATAL(msg) $fatal(1, msg);
`endif

// ------------------------------------------------- embedded checkers
// SFC_CHK : a property of the design itself (simulation: $error; formal: assert).
// SFC_ASM : an obligation on the environment (masters / banks).  Simulation:
//           $error (the testbench drivers must obey it); formal: assume.
// Enabled with SFC_ASSERT (excluded from synthesis).
`ifdef FORMAL
  `define SFC_CHK(cond, msg) assert(cond);
  `define SFC_ASM(cond, msg) assume(cond);
`else
  `define SFC_CHK(cond, msg) if (!(cond)) $error("SFC_ASSERT %m: %s", msg);
  `define SFC_ASM(cond, msg) if (!(cond)) $error("SFC_ENV_ASSUMPTION %m: %s", msg);
`endif

`endif // SF_SRAMC_DEFS_SVH
