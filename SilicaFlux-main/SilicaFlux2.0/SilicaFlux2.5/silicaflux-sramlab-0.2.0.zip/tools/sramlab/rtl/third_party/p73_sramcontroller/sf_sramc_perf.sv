// =============================================================================
// SilicaFlux SRAMController :: sf_sramc_perf -- performance counters
//
// Pure observers: nothing here feeds back into the data path.  Counters are
// CNT_W bits and WRAP on overflow (documented; clear with perf_clr).  Read any
// counter through the select port: perf_val = counter[perf_sel] (0 when the
// index is not implemented).  The index map is in sf_sramc_defs.svh
// (SFC_PG_* global, SFC_PM_* per master at 16+16*m, SFC_PB_* per bank at
// 16+16*NUM_MASTERS+8*b).
//
// Derived figures (computed by software from the raw counters):
//   average arbitration wait = PM_WAIT_SUM / PM_ACC           [cycles per accepted request]
//   average access latency   = PM_LAT_SUM  / PM_CMP           [accept -> response transfer,
//                              exact once the master has drained: LAT_SUM integrates the
//                              outstanding count, i.e. Little's law, no timestamps stored]
//   bank conflicts           = PG_CONFLICT (losers) / PB_CONF_CYC (cycles) per bank
//   busy cycles              = PG_BUSY (any outstanding), PB_BUSY (per bank)
//   read/write throughput    = PG_RD_DONE / PG_CYCLES, PG_WR_DONE / PG_CYCLES  [transactions per cycle]
//   outstanding              = PM_OUT_MAX high-water mark, PG_OUT_MAX total
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sramc_defs.svh"
`default_nettype none

module sf_sramc_perf #(
  parameter int NUM_MASTERS = 4,
  parameter int NUM_BANKS   = 4,
  parameter int CNT_W       = 32,
  parameter int OUT_W       = 4,           // width of one outstanding counter
  localparam int NPERF      = 16 + 16 * NUM_MASTERS + 8 * NUM_BANKS,
  localparam int PSW        = $clog2(NPERF)
) (
  input  wire logic                           clk,
  input  wire logic                           rst_n,
  input  wire logic                           perf_clr,
  input  wire logic [PSW-1:0]                 perf_sel,
  output logic      [CNT_W-1:0]               perf_val,
  // per-master observation points
  input  wire logic [NUM_MASTERS-1:0]         p_req_valid,
  input  wire logic [NUM_MASTERS-1:0]         p_req_ready,
  input  wire logic [NUM_MASTERS-1:0]         p_rsp_valid,
  input  wire logic [NUM_MASTERS-1:0]         p_rsp_ready,
  input  wire logic [NUM_MASTERS-1:0]         p_rsp_we,
  input  wire logic [NUM_MASTERS-1:0]         p_rsp_err,
  input  wire logic [NUM_MASTERS-1:0]         p_rsp_cancel,
  input  wire logic [NUM_MASTERS-1:0]         p_order_stall,
  input  wire logic [NUM_MASTERS*OUT_W-1:0]   p_out,           // outstanding count per master
  // per-bank observation points
  input  wire logic [NUM_BANKS-1:0]           p_issue,
  input  wire logic [NUM_BANKS-1:0]           p_issue_we,
  input  wire logic [NUM_BANKS-1:0]           p_busy,
  input  wire logic [NUM_BANKS*NUM_MASTERS-1:0] p_elig         // eligible requesters per bank
);
  localparam int NG = 16;

  // packed storage (large unpacked arrays with loop resets are not supported by every tool)
  logic [NG*CNT_W-1:0]            g_v;
  logic [NUM_MASTERS*16*CNT_W-1:0] m_v;
  logic [NUM_BANKS*8*CNT_W-1:0]   b_v;
  logic [NUM_MASTERS*CNT_W-1:0]   run_v;

  localparam logic [CNT_W-1:0] ONE = {{(CNT_W-1){1'b0}}, 1'b1};

  // ---- combinational event decode
  logic [NUM_MASTERS-1:0] ev_acc, ev_xfer, ev_wait, ev_rstall;
  logic [CNT_W-1:0]       n_acc, n_xfer, n_rd, n_wr, n_err, n_cancel, n_wait, n_rstall, n_ostall, n_tot_out;
  logic                   any_out;
  logic [NUM_BANKS*CNT_W-1:0] n_los_v;
  logic [CNT_W-1:0]       n_los_tot;
  logic [CNT_W-1:0]       n_los_b;

  always_comb begin
    n_acc = '0; n_xfer = '0; n_rd = '0; n_wr = '0; n_err = '0; n_cancel = '0;
    n_wait = '0; n_rstall = '0; n_ostall = '0; n_tot_out = '0; any_out = 1'b0;
    for (int m = 0; m < NUM_MASTERS; m++) begin
      ev_acc[m]    = p_req_valid[m] && p_req_ready[m];
      ev_xfer[m]   = p_rsp_valid[m] && p_rsp_ready[m];
      ev_wait[m]   = p_req_valid[m] && !p_req_ready[m];
      ev_rstall[m] = p_rsp_valid[m] && !p_rsp_ready[m];
      if (ev_acc[m])                 n_acc    = n_acc + ONE;
      if (ev_xfer[m])                n_xfer   = n_xfer + ONE;
      if (ev_xfer[m] && !p_rsp_we[m] && !p_rsp_err[m]) n_rd = n_rd + ONE;
      if (ev_xfer[m] &&  p_rsp_we[m] && !p_rsp_err[m]) n_wr = n_wr + ONE;
      if (ev_xfer[m] &&  p_rsp_err[m]) n_err   = n_err + ONE;
      if (ev_xfer[m] &&  p_rsp_cancel[m]) n_cancel = n_cancel + ONE;
      if (ev_wait[m])                n_wait   = n_wait + ONE;
      if (ev_rstall[m])              n_rstall = n_rstall + ONE;
      if (p_order_stall[m])          n_ostall = n_ostall + ONE;
      n_tot_out = n_tot_out + CNT_W'(p_out[m*OUT_W +: OUT_W]);
      if (p_out[m*OUT_W +: OUT_W] != '0) any_out = 1'b1;
    end
    n_los_tot = '0;
    n_los_b   = '0;
    for (int b = 0; b < NUM_BANKS; b++) begin
      n_los_b = '0;
      for (int m = 0; m < NUM_MASTERS; m++)
        if (p_elig[b*NUM_MASTERS + m]) n_los_b = n_los_b + ONE;
      if (n_los_b != '0) n_los_b = n_los_b - ONE;     // one of the eligible wins
      n_los_v[b*CNT_W +: CNT_W] = n_los_b;
      n_los_tot = n_los_tot + n_los_b;
    end
  end

  // ---- counters
`define SFC_G(i)  g_v[(i)*CNT_W +: CNT_W]
`define SFC_M(m,k) m_v[((m)*16 + (k))*CNT_W +: CNT_W]
`define SFC_B(b,k) b_v[((b)*8 + (k))*CNT_W +: CNT_W]
`define SFC_R(m)  run_v[(m)*CNT_W +: CNT_W]
`define SFC_O(m)  CNT_W'(p_out[(m)*OUT_W +: OUT_W])
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      g_v <= '0; m_v <= '0; b_v <= '0; run_v <= '0;
    end else if (perf_clr) begin
      g_v <= '0; m_v <= '0; b_v <= '0; run_v <= '0;
    end else begin
      `SFC_G(`SFC_PG_CYCLES)      <= `SFC_G(`SFC_PG_CYCLES) + ONE;
      if (any_out) `SFC_G(`SFC_PG_BUSY) <= `SFC_G(`SFC_PG_BUSY) + ONE;
      `SFC_G(`SFC_PG_ACCEPTED)    <= `SFC_G(`SFC_PG_ACCEPTED)  + n_acc;
      `SFC_G(`SFC_PG_COMPLETED)   <= `SFC_G(`SFC_PG_COMPLETED) + n_xfer;
      `SFC_G(`SFC_PG_RD_DONE)     <= `SFC_G(`SFC_PG_RD_DONE)   + n_rd;
      `SFC_G(`SFC_PG_WR_DONE)     <= `SFC_G(`SFC_PG_WR_DONE)   + n_wr;
      `SFC_G(`SFC_PG_ERR_DONE)    <= `SFC_G(`SFC_PG_ERR_DONE)  + n_err;
      `SFC_G(`SFC_PG_CONFLICT)    <= `SFC_G(`SFC_PG_CONFLICT)  + n_los_tot;
      `SFC_G(`SFC_PG_ORDER_STALL) <= `SFC_G(`SFC_PG_ORDER_STALL) + n_ostall;
      `SFC_G(`SFC_PG_CANCELLED)   <= `SFC_G(`SFC_PG_CANCELLED) + n_cancel;
      if (n_tot_out > `SFC_G(`SFC_PG_OUT_MAX)) `SFC_G(`SFC_PG_OUT_MAX) <= n_tot_out;
      `SFC_G(`SFC_PG_RSP_STALL)   <= `SFC_G(`SFC_PG_RSP_STALL) + n_rstall;
      `SFC_G(`SFC_PG_WAIT)        <= `SFC_G(`SFC_PG_WAIT) + n_wait;

      for (int m = 0; m < NUM_MASTERS; m++) begin
        if (ev_acc[m])  `SFC_M(m, `SFC_PM_ACC) <= `SFC_M(m, `SFC_PM_ACC) + ONE;
        if (ev_xfer[m]) `SFC_M(m, `SFC_PM_CMP) <= `SFC_M(m, `SFC_PM_CMP) + ONE;
        if (ev_xfer[m] && !p_rsp_we[m] && !p_rsp_err[m]) `SFC_M(m, `SFC_PM_RD) <= `SFC_M(m, `SFC_PM_RD) + ONE;
        if (ev_xfer[m] &&  p_rsp_we[m] && !p_rsp_err[m]) `SFC_M(m, `SFC_PM_WR) <= `SFC_M(m, `SFC_PM_WR) + ONE;
        if (ev_xfer[m] &&  p_rsp_err[m]) `SFC_M(m, `SFC_PM_ERR) <= `SFC_M(m, `SFC_PM_ERR) + ONE;
        if (ev_wait[m]) begin
          `SFC_M(m, `SFC_PM_WAIT_SUM) <= `SFC_M(m, `SFC_PM_WAIT_SUM) + ONE;
          `SFC_R(m) <= `SFC_R(m) + ONE;
          if (`SFC_R(m) + ONE > `SFC_M(m, `SFC_PM_WAIT_MAX)) `SFC_M(m, `SFC_PM_WAIT_MAX) <= `SFC_R(m) + ONE;
        end else begin
          `SFC_R(m) <= '0;
        end
        `SFC_M(m, `SFC_PM_LAT_SUM) <= `SFC_M(m, `SFC_PM_LAT_SUM) + `SFC_O(m);
        if (`SFC_O(m) > `SFC_M(m, `SFC_PM_OUT_MAX)) `SFC_M(m, `SFC_PM_OUT_MAX) <= `SFC_O(m);
        if (ev_rstall[m])      `SFC_M(m, `SFC_PM_RSP_STALL)   <= `SFC_M(m, `SFC_PM_RSP_STALL) + ONE;
        if (p_order_stall[m])  `SFC_M(m, `SFC_PM_ORDER_STALL) <= `SFC_M(m, `SFC_PM_ORDER_STALL) + ONE;
        if (ev_xfer[m] && p_rsp_cancel[m]) `SFC_M(m, `SFC_PM_CANCEL) <= `SFC_M(m, `SFC_PM_CANCEL) + ONE;
      end

      for (int b = 0; b < NUM_BANKS; b++) begin
        if (p_issue[b]) begin
          `SFC_B(b, `SFC_PB_ACCESS) <= `SFC_B(b, `SFC_PB_ACCESS) + ONE;
          if (p_issue_we[b]) `SFC_B(b, `SFC_PB_WR) <= `SFC_B(b, `SFC_PB_WR) + ONE;
          else               `SFC_B(b, `SFC_PB_RD) <= `SFC_B(b, `SFC_PB_RD) + ONE;
        end
        if (p_busy[b]) `SFC_B(b, `SFC_PB_BUSY) <= `SFC_B(b, `SFC_PB_BUSY) + ONE;
        if (n_los_v[b*CNT_W +: CNT_W] != '0) `SFC_B(b, `SFC_PB_CONF_CYC) <= `SFC_B(b, `SFC_PB_CONF_CYC) + ONE;
        `SFC_B(b, `SFC_PB_LOSERS) <= `SFC_B(b, `SFC_PB_LOSERS) + n_los_v[b*CNT_W +: CNT_W];
      end
    end
  end

  // ---- read port
  always_comb begin
    perf_val = '0;
    if (32'(perf_sel) < NG) perf_val = `SFC_G(perf_sel[3:0]);
    for (int m = 0; m < NUM_MASTERS; m++)
      for (int k = 0; k < 16; k++)
        if (32'(perf_sel) == 16 + 16*m + k) perf_val = `SFC_M(m, k);
    for (int b = 0; b < NUM_BANKS; b++)
      for (int k = 0; k < 8; k++)
        if (32'(perf_sel) == 16 + 16*NUM_MASTERS + 8*b + k) perf_val = `SFC_B(b, k);
  end
endmodule

`default_nettype wire
