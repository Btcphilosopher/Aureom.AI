// =============================================================================
// SilicaFlux MemoryTest :: sf_mbist_addr_seq
// Address sequencer for one March element.
//
// Precise definition (docs/02 section 3):
//   window   [lo, hi]   inclusive, lo <= hi (checked by the FSM before any access)
//   ascending (down = 0)  sequence  lo, lo+1, ..., hi            starts at lo, `last` when addr == hi
//   descending (down = 1) sequence  hi, hi-1, ..., lo            starts at hi, `last` when addr == lo
//   Every address of the window appears EXACTLY ONCE per element and descending is the exact reverse of
//   ascending.  A window of one address (lo == hi) is a one-address element: `last` is already high.
//   March elements whose order is "any" (B(...) in the March notation) are run ascending.
//
// Use:  `load` (pulse, with `down_i`, `lo_i`, `hi_i`) selects the window and puts the first address on `addr_o`
//       in the NEXT cycle.  `step` (pulse) advances one address; it is ignored while `last_o` is high, so an
//       extra step can never leave the window.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_mbist_addr_seq #(
  parameter int AW = 6
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          load_i,
  input  wire logic          down_i,
  input  wire logic [AW-1:0] lo_i,
  input  wire logic [AW-1:0] hi_i,
  input  wire logic          step_i,
  output logic      [AW-1:0] addr_o,
  output logic               last_o,
  output logic               down_o
);
  logic [AW-1:0] lo_q, hi_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      addr_o <= '0; lo_q <= '0; hi_q <= '0; down_o <= 1'b0;
    end else if (load_i) begin
      lo_q   <= lo_i;
      hi_q   <= hi_i;
      down_o <= down_i;
      addr_o <= down_i ? hi_i : lo_i;
    end else if (step_i && !last_o) begin
      addr_o <= down_o ? addr_o - 1'b1 : addr_o + 1'b1;
    end
  end

  assign last_o = down_o ? (addr_o == lo_q) : (addr_o == hi_q);
endmodule

`default_nettype wire
