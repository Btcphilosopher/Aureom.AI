// =============================================================================
// SRAMLab :: tb_sramlab_ecc_bank
// Measurement harness around ONE real MemoryCore bank (sf_sram_bank, ECC_EN = 0 or 1).  It decides nothing: it
// measures and prints tagged lines, sramlab/studies/ecc.py parses them and does the comparisons.
//
// Timing convention (identical for every number printed): `cyc` counts rising clock edges; a signal "in cycle t" is its
// value just before edge t (monitor = clocked process, so it is race free).  Stimulus is driven 1 ns after an edge.
//   latency   = cyc(rsp_valid seen) - cyc(request accepted)          [documented BANK_LAT = READ_LATENCY + ECC_EN]
//   throughput stream of N back-to-back requests (a new one is presented the cycle after the previous was accepted):
//             cycles = cyc(last accept) - cyc(first valid) + 1 ; stall = cycles with valid && !ready
//
// Sections (plusargs):
//   +lat=1            isolated read / full write / partial write / zero-byte-enable write latency
//   +thr=<N>          streams: wr_full, wr_part, rd, mix(50% rd,25% full,25% part), each followed by a read-back sweep that
//                     compares every row with a byte-accurate reference model (sweep_bad must be 0)
//   +scrub=<T>        (SCRUB_EN only) idle-bus scrub characterisation over T cycles, scrub under offered load, and a
//                     seeded-error repair test
//   +fvec=<file>      fault vectors "row data_hex mask_hex": write data, XOR mask into the STORED word (SEU hook of
//                     sf_sram_core, FAULT_INJECT=1), read the raw stored word via the MBIST test port, read functionally
//   +rmw=1            partial write onto a 1-bit-error line and onto a 2-bit-error line
//   +seed=<n>         xorshift32 seed for data / rows / byte enables
// =============================================================================
`timescale 1ns/1ps
module tb_sramlab_ecc_bank;
  parameter int DW           = 32;
  parameter int ECC_EN       = 1;
  parameter int READ_LATENCY = 1;
  parameter int DEPTH        = 64;
  parameter int SCRUB_EN     = ECC_EN;
  parameter int SCRUB_WAIT   = 64;
  parameter int FAULT_INJECT = 1;

  localparam int TAG_W   = 8;
  localparam int AW      = $clog2(DEPTH);
  localparam int BE_W    = DW / 8;
  localparam int R_EXP   = $clog2(DW + $clog2(DW + 1) + 1);
  localparam int SW      = (ECC_EN != 0) ? DW + R_EXP + 1 : DW;       // harness bus width; checked against the RTL below
  localparam int FBW     = (SW > 1) ? $clog2(SW) : 1;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT ports
  logic              req_valid = 0, req_we = 0;
  wire               req_ready;
  logic [AW-1:0]     req_row = '0;
  logic [DW-1:0]     req_wdata = '0;
  logic [BE_W-1:0]   req_be = '1;
  logic [TAG_W-1:0]  req_tag = '0;
  wire               rsp_valid, rsp_we, rsp_ce;
  wire  [DW-1:0]     rsp_rdata;
  wire  [TAG_W-1:0]  rsp_tag;
  wire  [2:0]        rsp_status;
  logic              init_start = 0, scrub_en = 0, cnt_clr = 0;
  wire               init_busy, idle_o, ev_ce, ev_ue;
  wire  [AW-1:0]     ev_row;
  wire  [1:0]        ev_kind;
  wire  [15:0]       ce_cnt, ue_cnt;
  wire  [AW-1:0]     first_ce_row, first_ue_row;
  logic              tst_active = 0, tst_ce = 0, tst_we = 0;
  logic [AW-1:0]     tst_addr = '0;
  logic [SW-1:0]     tst_wdata = '0;
  wire  [SW-1:0]     tst_rdata;
  logic [3:0]        fi_type = 0;
  logic [AW-1:0]     fi_row = '0, fi_row2 = '0;
  logic [FBW-1:0]    fi_bit = '0, fi_bit2 = '0;
  logic              fi_val = 0, fi_val2 = 0, seu_pulse = 0;
  logic [AW-1:0]     seu_row = '0;
  logic [SW-1:0]     seu_mask = '0;

  sf_sram_bank #(.DEPTH(DEPTH), .DW(DW), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN), .TAG_W(TAG_W),
                 .FAULT_INJECT(FAULT_INJECT), .SCRUB_EN(SCRUB_EN), .SCRUB_WAIT(SCRUB_WAIT)) dut (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready), .req_we(req_we), .req_row(req_row),
    .req_wdata(req_wdata), .req_be(req_be), .req_tag(req_tag), .rsp_valid(rsp_valid), .rsp_rdata(rsp_rdata),
    .rsp_tag(rsp_tag), .rsp_we(rsp_we), .rsp_status(rsp_status), .rsp_ce(rsp_ce), .init_start_i(init_start),
    .init_busy_o(init_busy), .scrub_en_i(scrub_en), .idle_o(idle_o), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue),
    .ev_row_o(ev_row), .ev_kind_o(ev_kind), .cnt_clr_i(cnt_clr), .ce_cnt_o(ce_cnt), .ue_cnt_o(ue_cnt),
    .first_ce_row_o(first_ce_row), .first_ue_row_o(first_ue_row), .tst_active_i(tst_active), .tst_ce_i(tst_ce),
    .tst_we_i(tst_we), .tst_addr_i(tst_addr), .tst_wdata_i(tst_wdata), .tst_rdata_o(tst_rdata),
    .fi_type(fi_type), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2), .fi_val(fi_val),
    .fi_val2(fi_val2), .seu_pulse(seu_pulse), .seu_row(seu_row), .seu_mask(seu_mask));

  // ---------------------------------------------------------------- race-free monitor
  longint unsigned cyc = 0, acc_cnt = 0, rsp_cnt = 0, stall_cnt = 0;
  longint unsigned last_acc_cyc = 0, last_rsp_cyc = 0, fv_cyc = 0;
  logic            acc_f = 0, fv_seen = 0;
  logic [DW-1:0]   last_rdata = '0;
  logic [2:0]      last_status = '0;
  logic            last_ce = 0, last_rsp_we = 0;
  longint unsigned scrub_cyc = 0, scrub_steps = 0, go_cyc = 0, blocked_by_scrub = 0, tot_wait = 0, max_wait = 0, cur_wait = 0;
  longint unsigned win_first = 0, win_last = 0, win_n = 0;     // scrub-step entry cycles inside a measurement window
  logic            prev_scrub = 0;
  wire             in_scrub = (dut.state == 2'd2);

  always @(posedge clk) begin
    cyc <= cyc + 1;
    acc_f <= req_valid && req_ready;
    if (req_valid && !fv_seen) begin fv_cyc <= cyc; fv_seen <= 1'b1; end
    if (req_valid && req_ready) begin
      acc_cnt <= acc_cnt + 1; last_acc_cyc <= cyc;
      tot_wait <= tot_wait + cur_wait; if (cur_wait > max_wait) max_wait <= cur_wait; cur_wait <= 0;
    end else if (req_valid) cur_wait <= cur_wait + 1;
    if (req_valid && !req_ready) stall_cnt <= stall_cnt + 1;
    if (rsp_valid) begin
      rsp_cnt <= rsp_cnt + 1; last_rsp_cyc <= cyc; last_rdata <= rsp_rdata; last_status <= rsp_status;
      last_ce <= rsp_ce; last_rsp_we <= rsp_we;
    end
    prev_scrub <= in_scrub;
    if (in_scrub) scrub_cyc <= scrub_cyc + 1;
    if (in_scrub && !prev_scrub) begin
      scrub_steps <= scrub_steps + 1;
      if (win_n == 0) win_first <= cyc;
      win_last <= cyc; win_n <= win_n + 1;
    end
    if (dut.scrub_go) go_cyc <= go_cyc + 1;
    if (req_valid && !req_ready && in_scrub) blocked_by_scrub <= blocked_by_scrub + 1;
  end

  // ---------------------------------------------------------------- helpers
  logic [31:0] rng = 32'h1;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic logic [DW-1:0] rnd_data();
    logic [DW-1:0] d;
    d = '0;
    for (int w = 0; w < (DW + 31) / 32; w++) d = (d << 32) ^ DW'(rnd());
    return d;
  endfunction
  function automatic logic [BE_W-1:0] rnd_be();        // never 0 and never all-ones: a genuine PARTIAL write
    logic [BE_W-1:0] b;
    b = BE_W'(rnd());
    if (b == '0 || b == '1) b = BE_W'(1);
    return b;
  endfunction

  task automatic wcyc(input int n);
    repeat (n) @(posedge clk);
    #1;
  endtask

  logic [DW-1:0] refm [DEPTH];
  logic [DW-1:0] pend_wd; logic [BE_W-1:0] pend_be; logic pend_we; int pend_row;

  task automatic present(input bit we, input int row, input logic [DW-1:0] wd, input logic [BE_W-1:0] be, input int tg);
    req_valid = 1'b1; req_we = we; req_row = AW'(row); req_wdata = wd; req_be = be; req_tag = TAG_W'(tg);
    pend_we = we; pend_row = row; pend_wd = wd; pend_be = be;
  endtask

  task automatic model_commit();                       // called when the pending request was accepted
    if (pend_we) for (int b = 0; b < BE_W; b++) if (pend_be[b]) refm[pend_row][b*8 +: 8] = pend_wd[b*8 +: 8];
  endtask

  // results of single()
  longint res_lat, res_acc_wait;
  logic [DW-1:0] res_rdata; logic [2:0] res_status; logic res_ce, res_rsp_we;

  // one request at a time: wait until accepted, then until its response has been seen
  task automatic single(input bit we, input int row, input logic [DW-1:0] wd, input logic [BE_W-1:0] be);
    longint unsigned a0, r0, g;
    a0 = acc_cnt; r0 = rsp_cnt; g = 0;
    present(we, row, wd, be, int'(acc_cnt & 255));
    do begin wcyc(1); g++; end while (acc_cnt == a0 && g < 100000);
    req_valid = 1'b0;
    model_commit();
    g = 0;
    while (rsp_cnt == r0 && g < 100000) begin wcyc(1); g++; end
    res_lat = longint'(last_rsp_cyc) - longint'(last_acc_cyc);
    res_rdata = last_rdata; res_status = last_status; res_ce = last_ce; res_rsp_we = last_rsp_we;
    res_acc_wait = longint'(last_acc_cyc) - longint'(fv_cyc);
  endtask

  task automatic wait_idle();
    int g;
    g = 0;
    while (!idle_o && g < 100000) begin wcyc(1); g++; end
    wcyc(2);
  endtask

  task automatic fill_all();                           // every row gets a known random word (also makes ECC-off defined)
    for (int r = 0; r < DEPTH; r++) begin fv_seen = 1'b0; single(1'b1, r, rnd_data(), '1); end
    wait_idle();
  endtask

  task automatic raw_read(input int row, output logic [SW-1:0] stored);
    tst_active = 1'b1; wcyc(2);
    tst_addr = AW'(row); tst_we = 1'b0; tst_ce = 1'b1; wcyc(1); tst_ce = 1'b0;
    wcyc(READ_LATENCY + 2);
    stored = tst_rdata;
    tst_active = 1'b0; wcyc(2);
  endtask

  task automatic inject(input int row, input logic [SW-1:0] mask);
    seu_row = AW'(row); seu_mask = mask; seu_pulse = 1'b1; wcyc(1); seu_pulse = 1'b0; seu_mask = '0; wcyc(2);
  endtask

  task automatic clear_counters();
    cnt_clr = 1'b1; wcyc(2); cnt_clr = 1'b0; wcyc(2);
  endtask

  // ---------------------------------------------------------------- sections
  task automatic sec_latency();
    logic [DW-1:0] d;
    d = rnd_data();
    fv_seen = 1'b0; single(1'b1, 3, d, '1);
    $display("LAT op=write_full cycles=%0d status=%0d ce=%0d", res_lat, res_status, res_ce); wait_idle();
    fv_seen = 1'b0; single(1'b0, 3, '0, '1);
    $display("LAT op=read cycles=%0d status=%0d ce=%0d data_ok=%0d", res_lat, res_status, res_ce, res_rdata === refm[3]); wait_idle();
    fv_seen = 1'b0; single(1'b1, 3, rnd_data(), rnd_be());
    $display("LAT op=write_partial cycles=%0d status=%0d ce=%0d", res_lat, res_status, res_ce); wait_idle();
    fv_seen = 1'b0; single(1'b0, 3, '0, '1);
    $display("LAT op=read_after_partial cycles=%0d status=%0d ce=%0d data_ok=%0d", res_lat, res_status, res_ce, res_rdata === refm[3]); wait_idle();
    fv_seen = 1'b0; single(1'b1, 3, rnd_data(), '0);
    $display("LAT op=write_be0 cycles=%0d status=%0d ce=%0d", res_lat, res_status, res_ce); wait_idle();
    fv_seen = 1'b0; single(1'b0, 3, '0, '1);
    $display("LAT op=read_after_be0 cycles=%0d status=%0d ce=%0d data_ok=%0d", res_lat, res_status, res_ce, res_rdata === refm[3]); wait_idle();
  endtask

  task automatic gen_op(input int kind, output bit we, output int row, output logic [DW-1:0] wd, output logic [BE_W-1:0] be);
    int k, pick;
    k = kind;
    if (kind == 3) begin pick = int'(rnd() % 4); k = (pick < 2) ? 2 : (pick == 2) ? 0 : 1; end
    row = int'(rnd() % DEPTH);
    wd = rnd_data();
    case (k)
      0: begin we = 1'b1; be = '1; end
      1: begin we = 1'b1; be = rnd_be(); end
      default: begin we = 1'b0; be = '1; end
    endcase
  endtask

  task automatic stream(input int kind, input int n, input string name);
    int issued, bad; bit we; int row; logic [DW-1:0] wd; logic [BE_W-1:0] be;
    longint unsigned a0, s0, cyc_total;
    wait_idle();
    a0 = acc_cnt; s0 = stall_cnt; issued = 0;
    fv_seen = 1'b0;
    gen_op(kind, we, row, wd, be); present(we, row, wd, be, 0);
    while (issued < n) begin
      wcyc(1);
      if (acc_f) begin
        model_commit(); issued++;
        if (issued < n) begin gen_op(kind, we, row, wd, be); present(we, row, wd, be, issued); end
        else req_valid = 1'b0;
      end
    end
    cyc_total = last_acc_cyc - fv_cyc + 1;
    wait_idle();
    bad = 0;
    for (int r = 0; r < DEPTH; r++) begin
      fv_seen = 1'b0; single(1'b0, r, '0, '1);
      if (res_rdata !== refm[r] || res_status != 0 || res_ce) bad++;
    end
    $display("THR kind=%s n=%0d cycles=%0d stall=%0d accepted=%0d sweep_bad=%0d", name, n, cyc_total, stall_cnt - s0, acc_cnt - a0 - DEPTH, bad);
    wait_idle();
  endtask

  // scrub under offered load: a new READ is presented with probability p/256 per idle cycle, held until accepted
  task automatic load_run(input int p, input int T, input bit scrub_on, input string name);
    longint unsigned a0, st0, sc0, g0, b0, tw0, c0;
    int pending;
    wait_idle();
    rng = 32'hC0FFEE ^ 32'(p);
    scrub_en = scrub_on;
    a0 = acc_cnt; st0 = scrub_steps; sc0 = scrub_cyc; g0 = go_cyc; b0 = blocked_by_scrub; tw0 = tot_wait; max_wait = 0; c0 = cyc;
    pending = 0;
    for (int t = 0; t < T; t++) begin
      wcyc(1);
      if (acc_f) begin pending = 0; req_valid = 1'b0; end
      if (!pending && (int'(rnd() % 256) < p)) begin
        present(1'b0, int'(rnd() % DEPTH), '0, '1, 0); pending = 1;
      end
    end
    // let a possibly pending request finish, then stop scrubbing
    while (pending) begin wcyc(1); if (acc_f) begin pending = 0; req_valid = 1'b0; end end
    scrub_en = 1'b0;
    $display("SCRUB_LOAD name=%s p=%0d T=%0d scrub=%0d accepted=%0d steps=%0d scrub_cycles=%0d go_cycles=%0d blocked_by_scrub=%0d max_wait=%0d tot_wait=%0d",
             name, p, T, scrub_on, acc_cnt - a0, scrub_steps - st0, scrub_cyc - sc0, go_cyc - g0, blocked_by_scrub - b0,
             max_wait, tot_wait - tw0);
    wait_idle();
  endtask

  task automatic sec_scrub(input int T);
    longint unsigned st0, sc0, g0, c0;
    int seeded, resid, ues, pos;
    logic [SW-1:0] raw;
    // (a) idle bus: pure scrub
    wait_idle();
    st0 = scrub_steps; sc0 = scrub_cyc; g0 = go_cyc; c0 = cyc;
    win_n = 0;
    scrub_en = 1'b1;
    wcyc(T);
    scrub_en = 1'b0;
    $display("SCRUB_IDLE T=%0d steps=%0d scrub_cycles=%0d go_cycles=%0d scrub_wait=%0d first_step_cyc=%0d last_step_cyc=%0d window_steps=%0d",
             T, scrub_steps - st0, scrub_cyc - sc0, go_cyc - g0, SCRUB_WAIT, win_first, win_last, win_n);
    wait_idle();
    // (b) offered load, scrub off / on
    foreach (PLIST[i]) begin
      load_run(PLIST[i], T, 1'b0, "off");
      load_run(PLIST[i], T, 1'b1, "on");
    end
    // (c) repair of seeded single-bit errors (+ one double-bit row that must be reported, never touched)
    fill_all();
    clear_counters();
    seeded = 0;
    for (int r = 2; r < DEPTH; r += 3) begin inject(r, SW'(1) << (int'(rnd() % SW))); seeded++; end
    inject(1, (SW'(1) << 2) | (SW'(1) << 5));
    scrub_en = 1'b1;
    wcyc(3 * DEPTH * (SCRUB_WAIT + READ_LATENCY + 3));
    scrub_en = 1'b0;
    wait_idle();
    $display("SCRUB_FIX seeded_single=%0d seeded_double=1 ce_cnt=%0d ue_cnt=%0d first_ce=%0d first_ue=%0d", seeded, ce_cnt, ue_cnt, first_ce_row, first_ue_row);
    resid = 0; ues = 0;
    for (int r = 0; r < DEPTH; r++) begin
      fv_seen = 1'b0; single(1'b0, r, '0, '1);
      if (r == 1) begin if (res_status == 3) ues++; end
      else if (res_ce || res_status != 0 || res_rdata !== refm[r]) resid++;
    end
    $display("SCRUB_READBACK residual_bad_rows=%0d double_row_still_uncorrectable=%0d", resid, ues);
    // leave the line repaired
    fv_seen = 1'b0; single(1'b1, 1, rnd_data(), '1);
    wait_idle();
  endtask

  task automatic sec_fvec(input string fname);
    int fd, rc, row, n;
    logic [DW-1:0] data; logic [SW-1:0] mask, stored;
    logic [DW-1:0] rd; logic [2:0] st; logic ce; int cec, uec, fce, fue;
    fd = $fopen(fname, "r");
    if (fd == 0) $display("ERROR cannot open %s", fname);     // (no task `return`: Icarus 12 does not support it)
    n = 0;
    while (fd != 0 && !$feof(fd)) begin
      rc = $fscanf(fd, "%d %h %h\n", row, data, mask);
      if (rc == 3) begin                                    // (no `continue`: Icarus 12 does not support it)
        clear_counters();
        fv_seen = 1'b0; single(1'b1, row, data, '1);          // full-line write (encoded by the RTL)
        wcyc(2);
        inject(row, mask);                                    // soft error: XOR into the STORED word
        raw_read(row, stored);                                // raw stored word through the MBIST test port
        fv_seen = 1'b0; single(1'b0, row, '0, '1);            // functional read through decoder
        rd = res_rdata; st = res_status; ce = res_ce;
        wcyc(4);
        cec = int'(ce_cnt); uec = int'(ue_cnt); fce = int'(first_ce_row); fue = int'(first_ue_row);
        $display("F row=%0d data=%h mask=%h stored=%h rdata=%h status=%0d ce=%0d ce_cnt=%0d ue_cnt=%0d first_ce=%0d first_ue=%0d",
                 row, data, mask, stored, rd, st, ce, cec, uec, fce, fue);
        n++;
      end
    end
    if (fd != 0) $fclose(fd);
    $display("FDONE vectors=%0d", n);
  endtask

  task automatic sec_rmw();
    logic [DW-1:0] d0, d1, rd; logic [BE_W-1:0] be; logic [SW-1:0] sb, sa;
    logic [2:0] wst; logic wce; int cec, uec;
    be = {(BE_W + 1) / 2{2'b01}};                           // bytes 0, 2, 4, ...
    // RMW1: single-bit error in the old line
    d0 = rnd_data(); d1 = rnd_data(); clear_counters();
    fv_seen = 1'b0; single(1'b1, 7, d0, '1);
    inject(7, SW'(1) << 3);
    raw_read(7, sb);
    fv_seen = 1'b0; single(1'b1, 7, d1, be); wst = res_status; wce = res_ce; wcyc(4);
    cec = int'(ce_cnt); uec = int'(ue_cnt);
    raw_read(7, sa);
    fv_seen = 1'b0; single(1'b0, 7, '0, '1); rd = res_rdata; wcyc(4);
    $display("RMW1 d0=%h d1=%h be=%h stored_before=%h stored_after=%h w_status=%0d w_ce=%0d ce_cnt=%0d ue_cnt=%0d rd=%h rd_status=%0d rd_ce=%0d ce_cnt_after_read=%0d",
             d0, d1, be, sb, sa, wst, wce, cec, uec, rd, res_status, res_ce, ce_cnt);
    // RMW2: double-bit error in the old line: the partial write must be ABORTED, the line left as found
    d0 = rnd_data(); d1 = rnd_data(); clear_counters();
    fv_seen = 1'b0; single(1'b1, 9, d0, '1);
    inject(9, (SW'(1) << 2) | (SW'(1) << 5));
    raw_read(9, sb);
    fv_seen = 1'b0; single(1'b1, 9, d1, be); wst = res_status; wce = res_ce; wcyc(4);
    cec = int'(ce_cnt); uec = int'(ue_cnt);
    raw_read(9, sa);
    fv_seen = 1'b0; single(1'b1, 9, d1, '1);                // a FULL-line write needs no old data: repairs the line
    fv_seen = 1'b0; single(1'b0, 9, '0, '1); rd = res_rdata; wcyc(4);
    $display("RMW2 d0=%h d1=%h be=%h stored_before=%h stored_after=%h w_status=%0d w_ce=%0d ce_cnt=%0d ue_cnt=%0d repair_rd=%h repair_status=%0d repair_ce=%0d",
             d0, d1, be, sb, sa, wst, wce, cec, uec, rd, res_status, res_ce);
  endtask

  // ---------------------------------------------------------------- main
  int PLIST [5];                                            // {0, 64, 128, 192, 256}, set in the initial block (Icarus 12)
  int v_lat, v_thr, v_scrub, v_rmw, v_seed;
  string s_fvec;
  initial begin
    PLIST[0] = 0; PLIST[1] = 64; PLIST[2] = 128; PLIST[3] = 192; PLIST[4] = 256;
    if (!$value$plusargs("seed=%d", v_seed)) v_seed = 1;
    rng = 32'h9E3779B9 ^ 32'(v_seed);
    if (rng == 0) rng = 32'h1;
    if (!$value$plusargs("lat=%d", v_lat)) v_lat = 0;
    if (!$value$plusargs("thr=%d", v_thr)) v_thr = 0;
    if (!$value$plusargs("scrub=%d", v_scrub)) v_scrub = 0;
    if (!$value$plusargs("rmw=%d", v_rmw)) v_rmw = 0;
    for (int i = 0; i < DEPTH; i++) refm[i] = '0;
    repeat (4) @(posedge clk);
    #1 rst_n = 1'b1;
    // widths and parameters the RTL actually elaborated (read from the DUT, not assumed)
    $display("CFG DW=%0d ECC_EN=%0d READ_LATENCY=%0d DEPTH=%0d SCRUB_EN=%0d SCRUB_WAIT=%0d FAULT_INJECT=%0d STORE_W_RTL=%0d R_RTL=%0d TST_BITS=%0d BANK_LAT_DOC=%0d",
             DW, ECC_EN, READ_LATENCY, DEPTH, SCRUB_EN, SCRUB_WAIT, FAULT_INJECT, dut.STORE_W, dut.R, $bits(dut.tst_rdata_o),
             READ_LATENCY + ((ECC_EN != 0) ? 1 : 0));
    if (dut.STORE_W != SW || $bits(dut.tst_rdata_o) != SW) begin
      $display("ERROR harness SW=%0d but RTL STORE_W=%0d", SW, dut.STORE_W); $finish;
    end
    wait_idle();                                            // ECC: the init engine writes every row with a valid zero line
    fill_all();
    if (v_lat != 0)   sec_latency();
    if (v_thr > 0) begin
      stream(0, v_thr, "wr_full");
      stream(1, v_thr, "wr_part");
      stream(2, v_thr, "rd");
      stream(3, v_thr, "mix");
    end
    if (v_rmw != 0 && ECC_EN != 0 && FAULT_INJECT != 0) sec_rmw();
    if (v_scrub > 0 && SCRUB_EN != 0) sec_scrub(v_scrub);
    if ($value$plusargs("fvec=%s", s_fvec)) begin
      if (FAULT_INJECT == 0) $display("ERROR +fvec needs FAULT_INJECT=1"); else sec_fvec(s_fvec);
    end
    $display("DONE cycles=%0d", cyc);
    $finish;
  end
  initial begin #(64'd4_000_000_000); $display("ERROR watchdog"); $finish; end
endmodule
