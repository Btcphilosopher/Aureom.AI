// =============================================================================
// SRAMLab :: tb_sramlab_ctl_ivl  -- Icarus Verilog testbench for sf_sram_subsystem
//
// Second, independent RTL simulator for the model-vs-RTL comparison.  Drives the
// same pass-through top as the Verilator harness (rtl/tb/vl_ctl/sramlab_ctl_top.sv,
// itself a wrapper of the REAL sf_sram_subsystem) and writes the SAME cycle trace
// as rtl/tb/vl_ctl/sim_ctl.cpp, so sramlab/rtlrun.py compares all three
// (Python model, Verilator, Icarus) with one comparator.
//
// Written for Icarus 12: no associative arrays, no `break`, no string building --
// stimulus is held in dynamic arrays and each trace line is emitted with $fwrite.
//
// Master model (IDENTICAL to sramlab/sim/driver.py and sim_ctl.cpp):
//   * request i may be presented from ready_at; ready_at(0) = delay(0);
//     after acceptance in cycle t: ready_at(i+1) = t + 1 + delay(i+1)
//   * once presented, valid and payload hold until accepted
//   * ID = i mod 2**IDW, src = port index
//   * m_rsp_ready from a per-cycle mask file (all ones beyond the file)
// Plusargs: +stim=<file> +cycles=<N> +trace=<file> [+rdy=<file>] [+flush=<file>]
// =============================================================================
`timescale 1ns/1ps
module tb_sramlab_ctl_ivl;
  parameter integer      NM        = 4;
  parameter integer      NB        = 4;
  parameter integer      DW        = 32;
  parameter integer      BD        = 1024;
  parameter integer      MAXOUT    = 1;
  parameter integer      BANKOUT   = 0;
  parameter integer      IDW       = 4;
  parameter integer      ILV       = 0;
  parameter integer      MASKMODE  = 0;
  parameter integer      IDCHK     = 1;
  parameter integer      SRCCHK    = 1;
  parameter integer      PRIO      = 0;
  parameter [15:0]       HPM       = 16'h0001;
  parameter integer      HPL       = 4;
  parameter [63:0]       LATS      = 64'h1111_1111_1111_1111;
  parameter integer      UNI       = -1;

  localparam integer NBYTE = DW / 8;
  localparam integer NPERF = 16 + 16 * NM + 8 * NB;
  localparam integer PSW   = $clog2(NPERF);

  reg                 clk = 1'b0;
  reg                 rst_n = 1'b0;
  reg  [NM-1:0]       m_req_valid = 0, m_req_we = 0, m_req_err = 0, m_rsp_ready = {NM{1'b1}};
  wire [NM-1:0]       m_req_ready, m_rsp_valid, m_rsp_we, m_rsp_err;
  reg  [NM*32-1:0]    m_req_addr = 0;
  reg  [NM*DW-1:0]    m_req_wdata = 0;
  wire [NM*DW-1:0]    m_rsp_rdata;
  reg  [NM*NBYTE-1:0] m_req_wstrb = 0;
  reg  [NM*IDW-1:0]   m_req_id = 0;
  wire [NM*IDW-1:0]   m_rsp_id;
  wire [NM*4-1:0]     m_rsp_status;
  wire                idle, ovf, proto;
  reg                 perf_clr = 1'b0, flush_r = 1'b0;
  reg  [PSW-1:0]      perf_sel = 0;
  wire [31:0]         perf_val;
  wire [NB-1:0]       bk_v;
  wire [31:0]         cfg_uniform, cfg_bank_out, cfg_max_lat, cfg_min_lat, cfg_nperf;

  sramlab_ctl_top #(
    .NM(NM), .NB(NB), .DW(DW), .BD(BD), .MAXOUT(MAXOUT), .BANKOUT(BANKOUT), .IDW(IDW), .ILV(ILV),
    .MASKMODE(MASKMODE), .IDCHK(IDCHK), .SRCCHK(SRCCHK), .PRIO(PRIO), .HPM(HPM), .HPL(HPL), .LATS(LATS), .UNI(UNI)
  ) dut (
    .clk(clk), .rst_n(rst_n), .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we),
    .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_req_id(m_req_id),
    .m_req_err(m_req_err), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata),
    .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we), .m_rsp_err(m_rsp_err), .m_rsp_status(m_rsp_status),
    .flush(flush_r), .idle(idle), .sts_rsp_overflow(ovf), .sts_bank_proto(proto), .perf_clr(perf_clr),
    .perf_sel(perf_sel), .perf_val(perf_val), .obs_bk_req_valid(bk_v), .cfg_uniform(cfg_uniform),
    .cfg_bank_out(cfg_bank_out), .cfg_max_lat(cfg_max_lat), .cfg_min_lat(cfg_min_lat), .cfg_nperf(cfg_nperf)
  );

  // stimulus storage (flattened over masters: entry base[m] + i)
  reg  [0:0]   s_we    [];
  reg  [0:0]   s_err   [];
  reg  [31:0]  s_addr  [];
  reg  [127:0] s_wdata [];
  reg  [15:0]  s_wstrb [];
  reg  [63:0]  s_delay [];
  reg  [15:0]  rdym    [];
  reg  [0:0]   flm     [];
  integer      cnt     [0:NM-1];
  integer      base    [0:NM-1];
  integer      i_m     [0:NM-1];
  reg  [63:0]  ready_at[0:NM-1];

  task tick;
    begin
      clk = 1'b1; #1;
      clk = 1'b0; #1;
    end
  endtask

  reg [1023:0] stim_f, rdy_f, trace_f, flush_f;
  integer fd, tfd, ncyc, op, mi, nre, wev, errv, rc, c, k, m, total, ptr, have_rdy, have_flush, done;
  reg [63:0]  dly;
  reg [31:0]  addr_v;
  reg [127:0] wd_v;
  reg [15:0]  ws_v, mk;
  reg [NM-1:0] reqv_n, reqr_n;

  initial begin
    if (!$value$plusargs("stim=%s", stim_f))   begin $display("ERROR +stim required");   $finish; end
    if (!$value$plusargs("cycles=%d", ncyc))   begin $display("ERROR +cycles required"); $finish; end
    if (!$value$plusargs("trace=%s", trace_f)) begin $display("ERROR +trace required");  $finish; end
    have_rdy   = $value$plusargs("rdy=%s", rdy_f);
    have_flush = $value$plusargs("flush=%s", flush_f);

    // ---- pass 1: header lines "0 m count" come first; then the requests in master order
    for (m = 0; m < NM; m = m + 1) cnt[m] = 0;
    fd = $fopen(stim_f, "r");
    if (fd == 0) begin $display("ERROR cannot open stim"); $finish; end
    total = 0; ptr = 0; done = 0;
    while (!done) begin
      rc = $fscanf(fd, "%d", op);
      if (rc != 1) done = 1;
      else if (op == 0) begin
        rc = $fscanf(fd, "%d %d", mi, nre);
        cnt[mi] = nre;
      end else begin
        if (total == 0) begin
          for (m = 0; m < NM; m = m + 1) begin base[m] = total; total = total + cnt[m]; end
          s_we = new[total + 1]; s_err = new[total + 1]; s_addr = new[total + 1];
          s_wdata = new[total + 1]; s_wstrb = new[total + 1]; s_delay = new[total + 1];
        end
        rc = $fscanf(fd, "%d %d %h %h %h %d %d", mi, wev, addr_v, wd_v, ws_v, errv, dly);
        s_we[ptr] = wev[0]; s_err[ptr] = errv[0]; s_addr[ptr] = addr_v; s_wdata[ptr] = wd_v;
        s_wstrb[ptr] = ws_v; s_delay[ptr] = dly;
        ptr = ptr + 1;
      end
    end
    $fclose(fd);
    if (total == 0) for (m = 0; m < NM; m = m + 1) base[m] = 0;

    rdym = new[ncyc + 1];
    flm  = new[ncyc + 1];
    for (c = 0; c <= ncyc; c = c + 1) begin rdym[c] = 16'hFFFF; flm[c] = 1'b0; end
    if (have_rdy) begin
      fd = $fopen(rdy_f, "r");
      done = (fd == 0);
      while (!done) begin
        rc = $fscanf(fd, "%d %h", c, mk);
        if (rc != 2) done = 1;
        else if (c >= 0 && c <= ncyc) rdym[c] = mk;
      end
      if (fd != 0) $fclose(fd);
    end
    if (have_flush) begin
      fd = $fopen(flush_f, "r");
      done = (fd == 0);
      while (!done) begin
        rc = $fscanf(fd, "%d", c);
        if (rc != 1) done = 1;
        else if (c >= 0 && c <= ncyc) flm[c] = 1'b1;
      end
      if (fd != 0) $fclose(fd);
    end

    for (m = 0; m < NM; m = m + 1) begin
      i_m[m] = 0;
      ready_at[m] = (cnt[m] > 0) ? s_delay[base[m]] : 64'h7fff_ffff_ffff_ffff;
    end

    tfd = $fopen(trace_f, "w");
    rst_n = 1'b0;
    repeat (5) tick;
    rst_n = 1'b1;
    $display("CFG uniform=%0d bank_out=%0d max_lat=%0d min_lat=%0d", cfg_uniform, cfg_bank_out, cfg_max_lat, cfg_min_lat);

    for (c = 0; c < ncyc; c = c + 1) begin
      for (m = 0; m < NM; m = m + 1) begin
        if (i_m[m] < cnt[m] && c >= ready_at[m]) begin
          ptr = base[m] + i_m[m];
          m_req_valid[m] = 1'b1;
          m_req_we[m]    = s_we[ptr];
          m_req_err[m]   = s_err[ptr];
          m_req_addr[m*32 +: 32]        = s_addr[ptr];
          wd_v = s_wdata[ptr];            // (Icarus 12: no part-select on a dynamic-array element)
          ws_v = s_wstrb[ptr];
          m_req_wdata[m*DW +: DW]       = wd_v[DW-1:0];
          m_req_wstrb[m*NBYTE +: NBYTE] = ws_v[NBYTE-1:0];
          m_req_id[m*IDW +: IDW]        = i_m[m];
        end else begin
          m_req_valid[m] = 1'b0; m_req_we[m] = 1'b0; m_req_err[m] = 1'b0;
          m_req_addr[m*32 +: 32] = 0; m_req_wdata[m*DW +: DW] = 0;
          m_req_wstrb[m*NBYTE +: NBYTE] = 0; m_req_id[m*IDW +: IDW] = 0;
        end
      end
      flush_r = flm[c];
      mk = rdym[c];
      for (m = 0; m < NM; m = m + 1) m_rsp_ready[m] = mk[m];
      #1;   // combinational settle

      reqv_n = m_req_valid; reqr_n = m_req_ready;
      $fwrite(tfd, "T %0d %0h %0h %0h %0h %0h %0d", c, reqv_n, reqr_n, m_rsp_valid, m_rsp_ready, bk_v, idle);
      for (m = 0; m < NM; m = m + 1)
        if (m_rsp_valid[m])
          $fwrite(tfd, " %0d:%0d:%0d:%0d:%0h", m, m_rsp_id[m*IDW +: IDW], m_rsp_we[m], m_rsp_status[m*4 +: 4],
                  m_rsp_rdata[m*DW +: DW]);
      $fwrite(tfd, "\n");

      for (m = 0; m < NM; m = m + 1) begin
        if (reqv_n[m] && reqr_n[m]) begin
          i_m[m] = i_m[m] + 1;
          if (i_m[m] < cnt[m]) ready_at[m] = c + 1 + s_delay[base[m] + i_m[m]];
        end
      end
      tick;
    end

    for (k = 0; k < NPERF; k = k + 1) begin
      perf_sel = k;
      #1;
      $fwrite(tfd, "P %0d %0d\n", k, perf_val);
    end
    $fwrite(tfd, "S %0d %0d\n", ovf, proto);
    $fclose(tfd);
    $display("SRAMLAB_DONE cycles=%0d", ncyc);
    $finish;
  end
endmodule
