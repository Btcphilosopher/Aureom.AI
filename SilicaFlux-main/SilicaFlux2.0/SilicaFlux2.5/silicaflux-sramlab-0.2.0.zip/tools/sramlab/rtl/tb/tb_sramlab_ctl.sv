// =============================================================================
// SRAMLab :: tb_sramlab_ctl
// Closed-loop replay of per-master request scripts against the real
// sf_sram_subsystem (SRAMController P73 + SRAMCore P71) and a cycle-by-cycle trace.
//
// The master model is IDENTICAL to sramlab/sim/driver.py (that identity is what makes an
// exact simulator-vs-RTL comparison meaningful):
//   * request i of a master may be presented from `ready_at`; ready_at(0) = delay(0);
//     after acceptance in cycle t:  ready_at(i+1) = t + 1 + delay(i+1)
//   * once presented, valid and payload hold until accepted (SFB2 R2)
//   * ID = i mod 2**IDW, src = port index
//   * m_rsp_ready comes from a per-cycle mask file (all ones beyond the file)
//
// Plusargs: +stim=<file> +rdy=<file> +flush=<file> +cycles=<N> +trace=<file>
//   stim lines : "0 m count"                       (script length of master m)
//                "1 m we addr wdata wstrb err delay" (hex: addr wdata wstrb)
//   rdy  lines : "<cycle> <hex mask>"              (bit m = master m can take a response)
//   flush file : one cycle number per line (flush asserted in those cycles)
// Trace line per cycle (values just before the rising edge, i.e. "in cycle t"):
//   T t reqv reqr rspv rspr bk idle [m:id:we:st:rdata ...]   (masks in hex, one entry per master with rsp_valid)
// After the last cycle: P <index> <value> for every performance counter, then S ovf proto, then SRAMLAB_DONE.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_sramlab_ctl;
  parameter int          NM        = 4;
  parameter int          NB        = 4;
  parameter int          DW        = 32;
  parameter int          BD        = 1024;
  parameter int          MAXOUT    = 1;
  parameter int          BANKOUT   = 0;
  parameter int          IDW       = 4;
  parameter int          ILV       = 0;       // 0 low, 1 high
  parameter int          MASKMODE  = 0;       // 0 any, 1 aligned
  parameter int          IDCHK     = 1;
  parameter int          SRCCHK    = 1;
  parameter int          PRIO      = 0;
  parameter logic [15:0] HPM       = 16'h0001;
  parameter int          HPL       = 4;
  parameter longint      LATS      = 64'h1111_1111_1111_1111;
  parameter int          UNI       = -1;

  localparam int NBYTE = DW / 8;
  localparam int SRCW  = (NM > 1) ? $clog2(NM) : 1;
  localparam int NPERF = 16 + 16 * NM + 8 * NB;
  localparam int PSW   = $clog2(NPERF);

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [NM-1:0]        m_req_valid = '0, m_req_we = '0, m_req_err = '0, m_rsp_ready = '1;
  logic [NM-1:0]        m_req_ready, m_rsp_valid, m_rsp_we, m_rsp_err;
  logic [NM*32-1:0]     m_req_addr = '0;
  logic [NM*DW-1:0]     m_req_wdata = '0, m_rsp_rdata;
  logic [NM*NBYTE-1:0]  m_req_wstrb = '0;
  logic [NM*IDW-1:0]    m_req_id = '0, m_rsp_id;
  logic [NM*SRCW-1:0]   m_req_src, m_rsp_src;
  logic [NM*4-1:0]      m_rsp_status;
  logic                 idle, ovf, proto, perf_clr = 1'b0;
  logic                 flush_r = 1'b0;
  logic [PSW-1:0]       perf_sel = '0;
  logic [31:0]          perf_val;

  for (genvar m = 0; m < NM; m++) begin : g_src
    assign m_req_src[m*SRCW +: SRCW] = SRCW'(m);
  end

  sf_sram_subsystem #(
    .NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .BANK_DEPTH(BD), .ID_WIDTH(IDW), .MAX_OUT(MAXOUT),
    .BANK_OUT(BANKOUT), .INTERLEAVE(ILV), .ID_CHECK(IDCHK), .SRC_CHECK(SRCCHK), .MASK_MODE(MASKMODE),
    .PRIO_EN(PRIO), .HP_MASK(HPM), .HP_LIMIT(HPL), .PERF_EN(1), .CNT_W(32), .INIT_MODE(1),
    .BANK_LATS(LATS), .UNIFORM_LAT(UNI)
  ) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_we, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_req_id, .m_req_src, .m_req_err, .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_id, .m_rsp_src,
    .m_rsp_we, .m_rsp_err, .m_rsp_status, .src_en({NM{1'b1}}), .flush(flush_r), .idle,
    .sts_rsp_overflow(ovf), .sts_bank_proto(proto), .perf_clr, .perf_sel, .perf_val
  );

  typedef struct packed {
    logic         we;
    logic         err;
    logic [31:0]  addr;
    logic [127:0] wdata;
    logic [15:0]  wstrb;
    longint       delay;
  } req_t;

  req_t       script [longint];       // key = m * 2^24 + i
  longint     nreq   [int];
  bit [15:0]  rdymask [int];
  bit         flushset [int];

  task automatic tick;
    clk = 1'b1; #1;
    clk = 1'b0; #1;
  endtask

  function automatic string hexs(input logic [127:0] v, input int bits);
    string s;
    s = $sformatf("%0h", v & ((128'd1 << bits) - 128'd1));
    return s;
  endfunction

  initial begin
    string stim_f, rdy_f, trace_f, flush_f;
    int fd, ncyc, op, mi, nre, wev, errv, rc, cyc, rdyn;
    longint dly, key;
    longint i_m [int];
    longint ready_at [int];
    logic [31:0] addr_v;
    logic [127:0] wd_v;
    logic [15:0]  ws_v;
    longint cnt_v;
    int tfd;
    logic [15:0] mk;
    logic [NM-1:0] reqv_n, reqr_n, rspv_n, rspr_n;
    string line;
    int rd_i;

    if (!$value$plusargs("stim=%s", stim_f))   $fatal(1, "+stim=<file> required");
    if (!$value$plusargs("cycles=%d", ncyc))   $fatal(1, "+cycles=<N> required");
    if (!$value$plusargs("trace=%s", trace_f)) $fatal(1, "+trace=<file> required");
    if (!$value$plusargs("rdy=%s", rdy_f))     rdy_f = "";
    if (!$value$plusargs("flush=%s", flush_f)) flush_f = "";
    if (flush_f != "") begin
      fd = $fopen(flush_f, "r");
      if (fd != 0) begin
        while (!$feof(fd)) begin
          rc = $fscanf(fd, "%d\n", cyc);
          if (rc != 1) break;
          flushset[cyc] = 1'b1;
        end
        $fclose(fd);
      end
    end

    for (int m = 0; m < NM; m++) begin nreq[m] = 0; i_m[m] = 0; ready_at[m] = 0; end
    fd = $fopen(stim_f, "r");
    if (fd == 0) $fatal(1, "cannot open stim file");
    while (!$feof(fd)) begin
      rc = $fscanf(fd, "%d", op);
      if (rc != 1) break;
      if (op == 0) begin
        rc = $fscanf(fd, "%d %d\n", mi, nre);
        nreq[mi] = nre;
      end else begin
        rc = $fscanf(fd, "%d %d %h %h %h %d %d\n", mi, wev, addr_v, wd_v, ws_v, errv, dly);
        key = (longint'(mi) << 24) + i_m[mi];
        script[key] = '{we: wev[0], err: errv[0], addr: addr_v, wdata: wd_v, wstrb: ws_v, delay: dly};
        i_m[mi] = i_m[mi] + 1;
      end
    end
    $fclose(fd);
    if (rdy_f != "") begin
      fd = $fopen(rdy_f, "r");
      if (fd != 0) begin
        while (!$feof(fd)) begin
          rc = $fscanf(fd, "%d %h\n", cyc, mk);
          if (rc != 2) break;
          rdymask[cyc] = mk;
        end
        $fclose(fd);
      end
    end
    for (int m = 0; m < NM; m++) begin
      i_m[m] = 0;
      ready_at[m] = (nreq[m] > 0) ? script[longint'(m) << 24].delay : 64'h7fff_ffff_ffff;
    end

    tfd = $fopen(trace_f, "w");
    $display("CFG uniform=%0d bank_out=%0d max_lat=%0d min_lat=%0d", dut.UNIFORM_EFF, dut.BANK_OUT_EFF, dut.MAX_LAT, dut.MIN_LAT);
    // reset: asserted asynchronously, released synchronously (while clk is low)
    rst_n = 1'b0;
    repeat (5) tick();
    rst_n = 1'b1;

    for (cyc = 0; cyc < ncyc; cyc++) begin
      // ---- drive this cycle's inputs
      for (int m = 0; m < NM; m++) begin
        req_t r;
        if (i_m[m] < nreq[m] && cyc >= ready_at[m]) begin
          r = script[(longint'(m) << 24) + i_m[m]];
          m_req_valid[m] = 1'b1;
          m_req_we[m]    = r.we;
          m_req_err[m]   = r.err;
          m_req_addr[m*32 +: 32]       = r.addr;
          m_req_wdata[m*DW +: DW]      = r.wdata[DW-1:0];
          m_req_wstrb[m*NBYTE +: NBYTE] = r.wstrb[NBYTE-1:0];
          m_req_id[m*IDW +: IDW]       = IDW'(i_m[m]);
        end else begin
          m_req_valid[m] = 1'b0;
          m_req_we[m] = 1'b0; m_req_err[m] = 1'b0;
          m_req_addr[m*32 +: 32] = '0; m_req_wdata[m*DW +: DW] = '0;
          m_req_wstrb[m*NBYTE +: NBYTE] = '0; m_req_id[m*IDW +: IDW] = '0;
        end
      end
      flush_r = flushset.exists(cyc);
      mk = rdymask.exists(cyc) ? rdymask[cyc] : 16'hFFFF;
      for (int m = 0; m < NM; m++) m_rsp_ready[m] = mk[m];
      #1;   // combinational settle (m_req_ready depends on this cycle's inputs)

      // ---- sample (pre-edge values) and trace
      reqv_n = m_req_valid; reqr_n = m_req_ready; rspv_n = m_rsp_valid; rspr_n = m_rsp_ready;
      line = $sformatf("T %0d %0h %0h %0h %0h %0h %0d", cyc, reqv_n, reqr_n, rspv_n, rspr_n,
                       dut.bk_req_valid, idle);
      for (int m = 0; m < NM; m++) begin
        if (m_rsp_valid[m])
          line = {line, $sformatf(" %0d:%0d:%0d:%0d:%0h", m, m_rsp_id[m*IDW +: IDW], m_rsp_we[m],
                                  m_rsp_status[m*4 +: 4], m_rsp_rdata[m*DW +: DW])};
      end
      $fdisplay(tfd, "%s", line);

      // ---- driver state update (acceptance)
      for (int m = 0; m < NM; m++) begin
        if (m_req_valid[m] && m_req_ready[m]) begin
          i_m[m] = i_m[m] + 1;
          if (i_m[m] < nreq[m])
            ready_at[m] = cyc + 1 + script[(longint'(m) << 24) + i_m[m]].delay;
        end
      end
      tick();
    end

    // ---- read every performance counter (no further clocking: counters are frozen)
    for (rd_i = 0; rd_i < NPERF; rd_i++) begin
      perf_sel = PSW'(rd_i);
      #1;
      $fdisplay(tfd, "P %0d %0d", rd_i, perf_val);
    end
    $fdisplay(tfd, "S %0d %0d", ovf, proto);
    $fclose(tfd);
    $display("SRAMLAB_DONE cycles=%0d", ncyc);
    $finish;
  end
endmodule
`default_nettype wire
