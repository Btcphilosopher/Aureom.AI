// =============================================================================
// SRAMLab :: tb_sramlab_ecc_codec
// Vector-driven harness around the REAL MemoryCore SECDED wrappers sf_ecc_enc / sf_ecc_dec (K data bits).
// The Python side (sramlab/studies/ecc.py) writes the vectors and compares every output with its own
// independent reference codec; this testbench decides nothing, it only reports what the RTL produced.
//
// Plusargs:  +vec=<file>
//   vector line : "<kind> <data_hex> <mask_hex>"
//       kind 0 : stored word = enc(data) ^ mask          (mask = error pattern over the N stored bits)
//       kind 1 : stored word = mask                      (raw word, e.g. all-zero / all-ones stored word)
// Output line per vector (all hex except the small integers):
//   V <enc_cw> <stored_word> <data_o> <cw_corr_o> <ce> <ue> <class> <err_idx>
// and one header line:  CFG K=<K> R=<R> N=<N>   (R, N read from the elaborated RTL ports)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_sramlab_ecc_codec;
  parameter int K = 32;
  localparam int R_EXP = $clog2(K + $clog2(K + 1) + 1);      // only used to size the harness buses
  localparam int N_EXP = K + R_EXP + 1;
  localparam int IW    = $clog2(N_EXP);

  logic [K-1:0]     data = '0;
  logic [N_EXP-1:0] mask = '0;
  logic             raw  = 1'b0;
  wire  [N_EXP-1:0] cw;
  wire  [N_EXP-1:0] stored = raw ? mask : (cw ^ mask);
  wire  [K-1:0]     data_o;
  wire  [N_EXP-1:0] cw_corr;
  wire              ce, ue;
  wire  [2:0]       cls;
  wire  [IW-1:0]    idx;

  sf_ecc_enc #(.K(K)) u_enc (.data_i(data), .cw_o(cw));
  sf_ecc_dec #(.K(K)) u_dec (.cw_i(stored), .data_o(data_o), .cw_corr_o(cw_corr), .ce_o(ce), .ue_o(ue),
                             .class_o(cls), .err_idx_o(idx));

  integer fd, rc, kind, nvec;
  string  fname;
  // $fscanf targets are temporaries, copied into the DUT-driving variables by ordinary assignments:
  // (Verilator release 5.020 does not re-trigger combinational logic that depends on a variable written as a
  // $fscanf output argument; minimal reproducer in docs/03_verification.md, "Harness portability").
  logic [K-1:0]     data_t;
  logic [N_EXP-1:0] mask_t;
  initial begin
    // the widths the RTL actually elaborated (ports of the real modules), not an assumption of this harness
    $display("CFG K=%0d R=%0d N=%0d", K, $bits(u_enc.cw_o) - K - 1, $bits(u_enc.cw_o));
    if ($bits(u_enc.cw_o) != N_EXP || $bits(u_dec.cw_i) != N_EXP) begin
      $display("ERROR harness width %0d != RTL width %0d", N_EXP, $bits(u_enc.cw_o));
      $finish;
    end
    if (!$value$plusargs("vec=%s", fname)) begin $display("ERROR no +vec=<file>"); $finish; end
    fd = $fopen(fname, "r");
    if (fd == 0) begin $display("ERROR cannot open %s", fname); $finish; end
    nvec = 0;
    while (!$feof(fd)) begin
      rc = $fscanf(fd, "%d %h %h\n", kind, data_t, mask_t);
      if (rc == 3) begin
        data = data_t;
        mask = mask_t;
        raw = (kind == 1);
        #1;
        $display("V %h %h %h %h %0d %0d %0d %0d", cw, stored, data_o, cw_corr, ce, ue, cls, idx);
        nvec = nvec + 1;
      end
    end
    $fclose(fd);
    $display("DONE vectors=%0d", nvec);
    $finish;
  end
endmodule
`default_nettype wire
