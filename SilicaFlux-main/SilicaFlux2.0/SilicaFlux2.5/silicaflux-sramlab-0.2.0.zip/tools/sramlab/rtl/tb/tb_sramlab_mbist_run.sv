// =============================================================================
// SRAMLab :: tb_sramlab_mbist_run
// Script-driven measurement / fault-campaign harness around the REAL P78 MBIST controller (sf_sram_mbist) and the
// P78 verification-only memory group (sf_mbist_sram_sys: NBANK fault-model banks, the sf_sram_controller quiesce /
// idle / init contract, and a functional master with a scoreboard).  It decides nothing; sramlab/studies/mbist.py
// writes the scripts and does every comparison.
//
// Plusarg  +script=<file>  : one command per line, all fields decimal integers:
//   0                                         clear every injected fault
//   1 bank slot type row bit row2 bit2 v v2   inject a fault (types = SF_FT_*: 1 SAF 2 TF 3 AF_NA 4 AF_ALI 5 AF_MUL
//                                             6 CFIN 7 CFID 8 CFST; same fields as sf_mbist_sram_sys.set_fault)
//   2 tag algo pat sweep sel bank bmask lo hi traffic stop reinit kstripe colsel
//                                             run ONE MBIST test with these pin settings (clear -> start -> done)
//   3 n                                       idle n cycles
//   5 n                                       functional traffic only, n cycles: TRAF cycles accepted blocked
//   4 tag rows                                coverage mode: a whole fault list follows in +faults=<file> (see below)
// Timing convention: `cyc` counts rising edges; a signal "in cycle t" is its value just before edge t (clocked monitor).
//   cycles       = cyc(done first seen) - cyc(start seen)            (start pulse -> done flag)
//   phase counts = number of cycles spent in each {arbiter, engine} state between start and done
// Output (one line per run, tagged):
//   RUN  tag algo ... result cycles fail_count fbank frow fbit fbit_v felem fop fpol fpass fcls fexp fobs tested bfm errflags
//   PH   tag f<0..9>=<cycles in engine state>  a<0..8>=<cycles in arbiter state>
//   TL   tag t_start t_qrise t_qack t_tact_rise t_tact_fall t_init_start t_ibusy_rise t_ibusy_fall t_qfall t_done t_rdy_fall t_rdy_rise
//   FUNC tag blocked acc chk err acc_in_test (functional master: counts during the run + 100 cycles after)
//
// Plusarg +cov=<file>  : coverage mode.  Lines "bank type row bit row2 bit2 v v2" define one fault each; for each fault
//   every configuration listed on the first line of the file ("n algo pat sweep ... per run", see below) is run and the
//   result is reported per fault:  CF idx cfg det row bit bit_v elem count
//   first line of the file: "<nruns> then nruns x (algo pat sweep)": a configuration is the UNION of its runs.
// =============================================================================
`timescale 1ns/1ps
`include "sf_mbist_defs.svh"
module tb_sramlab_mbist_run;
  parameter int NBANK = 4;
  parameter int ROWS  = 64;
  parameter int W     = 32;
  parameter int RL    = 1;
  parameter int NF    = 2;
  parameter int FIFO  = 4;

  localparam int AW    = (ROWS > 1) ? $clog2(ROWS) : 1;
  localparam int BW    = (NBANK > 1) ? $clog2(NBANK) : 1;
  localparam int BITW  = (W > 1) ? $clog2(W) : 1;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- pins
  logic start = 0, clr = 0;
  logic [3:0] p_algo = 0; logic [2:0] p_pat = 0; logic [3:0] p_k = 0; logic p_sweep = 0; logic [1:0] p_col = 0;
  logic p_stop = 0, p_reinit = 1; logic [2:0] p_sel = `MB_SEL_ALL; logic [7:0] p_bank = 0; logic [NBANK-1:0] p_bmask = '1;
  logic [AW-1:0] p_lo = 0, p_hi = AW'(ROWS - 1);
  logic traffic = 0;

  wire busy, done, pass_o, fail_o, error_o; wire [2:0] result; wire [NBANK-1:0] tested, bfm; wire [`MB_NERR-1:0] errflags;
  wire [7:0] state; wire fail_valid; wire [BW-1:0] fail_bank; wire [AW-1:0] fail_row; wire [BITW-1:0] fail_bit; wire fail_bit_v;
  wire [2:0] fail_elem; wire fail_op, fail_pol; wire [3:0] fail_pass, fail_cls; wire [W-1:0] fexp, fobs; wire [31:0] fail_count;
  wire quiesce, q_ack, idle, init_start, init_busy, func_req, tst_active; wire [NBANK-1:0] tst_sel; wire tst_ce, tst_we;
  wire [AW-1:0] tst_addr; wire [W-1:0] tst_wdata; wire [NBANK*W-1:0] tst_rdata;
  wire [7:0] inflight; wire func_acc; wire [31:0] f_acc, f_chk, f_err, f_blk, f_intest;

  sf_mbist_sram_sys #(.NBANK(NBANK), .ROWS(ROWS), .W(W), .READ_LATENCY(RL), .NF(NF)) sys (
    .clk(clk), .rst_n(rst_n), .quiesce_i(quiesce), .quiesce_ack_o(q_ack), .idle_o(idle), .init_start_i(init_start),
    .init_busy_o(init_busy), .func_req_o(func_req), .tst_active_i(tst_active), .tst_sel_i(tst_sel), .tst_ce_i(tst_ce),
    .tst_we_i(tst_we), .tst_addr_i(tst_addr), .tst_wdata_i(tst_wdata), .tst_rdata_o(tst_rdata), .traffic_en_i(traffic),
    .rogue_i(1'b0), .ctl_no_ack_i(1'b0), .ctl_no_idle_i(1'b0), .ctl_no_init_i(1'b0), .init_on_reset_i(1'b0),
    .ack_delay_i(8'd0), .drain_extra_i(8'd0), .init_extra_i(8'd0), .func_acc_o(func_acc), .inflight_o(inflight),
    .func_acc_cnt_o(f_acc), .func_chk_cnt_o(f_chk), .func_chk_err_o(f_err), .func_blocked_cnt_o(f_blk),
    .func_acc_in_test_o(f_intest));

  sf_sram_mbist #(.NBANK(NBANK), .ROWS(ROWS), .DATA_W(W), .STORE_W(W), .READ_LATENCY(RL), .FIFO_DEPTH(FIFO),
                  .OWN_TIMEOUT(4000), .INIT_TIMEOUT(ROWS + 256)) dut (
    .clk(clk), .rst_n(rst_n), .start_i(start), .start_clr_i(1'b0), .abort_i(1'b0), .clear_i(clr), .fail_pop_i(1'b0),
    .clr_fault_i(1'b0), .cfg_from_pins_i(1'b1), .cfg_algo_i(p_algo), .cfg_pattern_i(p_pat), .cfg_stripe_k_i(p_k),
    .cfg_sweep_i(p_sweep), .cfg_colsel_i(p_col), .cfg_stop_i(p_stop), .cfg_reinit_i(p_reinit), .cfg_sel_i(p_sel),
    .cfg_bank_i(p_bank), .cfg_bmask_i(p_bmask), .cfg_row_lo_i(p_lo), .cfg_row_hi_i(p_hi), .cfg_wdog_i(32'd0),
    .test_mode_i(1'b1), .test_permit_i(1'b1), .mem_inhibit_i(1'b0), .cpu_halted_i(1'b0), .protect_i('0),
    .busy_o(busy), .done_o(done), .pass_o(pass_o), .fail_o(fail_o), .error_o(error_o), .result_o(result),
    .bank_tested_o(tested), .bank_fail_mask_o(bfm), .err_flags_o(errflags), .state_o(state), .fail_valid_o(fail_valid),
    .fail_bank_o(fail_bank), .fail_row_o(fail_row), .fail_bit_o(fail_bit), .fail_bit_v_o(fail_bit_v), .fail_in_check_o(),
    .fail_elem_o(fail_elem), .fail_op_o(fail_op), .fail_pol_o(fail_pol), .fail_pass_o(fail_pass), .fail_cls_o(fail_cls),
    .fail_alias_o(), .fail_exp_o(fexp), .fail_obs_o(fobs), .fail_count_o(fail_count),
    .quiesce_o(quiesce), .quiesce_ack_i(q_ack), .idle_i(idle), .init_start_o(init_start), .init_busy_i(init_busy),
    .func_req_i(func_req), .clk_req_o(), .tst_active_o(tst_active), .tst_sel_o(tst_sel), .tst_ce_o(tst_ce),
    .tst_we_o(tst_we), .tst_addr_o(tst_addr), .tst_wdata_o(tst_wdata), .tst_rdata_i(tst_rdata),
    .rb_req(1'b0), .rb_we(1'b0), .rb_addr(12'd0), .rb_wdata(32'd0), .rb_gnt(), .rb_rdata(), .rb_err(),
    .ras_valid_o(), .ras_type_o(), .ras_addr_o(), .ras_addr_v_o(), .ras_info_o(), .ras_corr_o(),
    .rep_row_v_o(), .rep_row_o(), .rep_col_v_o(), .rep_col_o(), .rep_ok_o(), .rep_unrep_o(), .rep_phys_o());

  // ---------------------------------------------------------------- race-free monitor (clocked; pre-edge samples)
  longint unsigned cyc = 0;
  longint unsigned h_f [10];
  longint unsigned h_a [9];
  longint unsigned t_start, t_qrise, t_qack, t_ta_r, t_ta_f, t_is, t_ib_r, t_ib_f, t_qf, t_done, t_rf, t_rr;
  logic            armed = 0, ended = 0, p_q = 0, p_ack = 0, p_ta = 0, p_ib = 0, p_rdy = 1, started_seen = 0;
  int              max_sel_w = 0, ord_n = 0;
  logic [63:0]     ord_v = '0;
  logic [NBANK-1:0] prev_sel = '0;
  wire             rdy = !quiesce && !tst_active && !init_busy;     // what a functional master sees (sys.ready minus pend flags)
  wire             sys_ready = sys.ready;

  task automatic mon_reset();
    for (int i = 0; i < 10; i++) h_f[i] = 0;
    for (int i = 0; i < 9; i++) h_a[i] = 0;
    t_start = 0; t_qrise = 0; t_qack = 0; t_ta_r = 0; t_ta_f = 0; t_is = 0; t_ib_r = 0; t_ib_f = 0; t_qf = 0; t_done = 0; t_rf = 0; t_rr = 0;
    started_seen = 0; ended = 0; max_sel_w = 0; ord_n = 0; ord_v = '0;
  endtask

  always @(posedge clk) begin
    cyc <= cyc + 1;
    p_q <= quiesce; p_ack <= q_ack; p_ta <= tst_active; p_ib <= init_busy; p_rdy <= sys_ready; prev_sel <= tst_sel;
    if (armed) begin
      if (start && !started_seen) begin t_start <= cyc; started_seen <= 1'b1; end
      if (started_seen) begin
        if (!ended) begin                                    // phase histogram: samples start+1 .. done (cycles = t_done - t_start)
          h_f[state[3:0]] <= h_f[state[3:0]] + 1;
          h_a[state[7:4]] <= h_a[state[7:4]] + 1;
        end
        if (|tst_sel) begin                                  // which banks does the engine drive, and in which order?
          if ($countones(tst_sel) > max_sel_w) max_sel_w <= $countones(tst_sel);
          if (tst_sel != prev_sel && ord_n < 16) begin
            for (int b = 0; b < NBANK; b++) if (tst_sel[b]) ord_v[ord_n*4 +: 4] <= 4'(b);
            ord_n <= ord_n + 1;
          end
        end
        if (quiesce && !p_q && t_qrise == 0) t_qrise <= cyc;
        if (q_ack && !p_ack && t_qack == 0) t_qack <= cyc;
        if (tst_active && !p_ta && t_ta_r == 0) t_ta_r <= cyc;
        if (!tst_active && p_ta && t_ta_f == 0) t_ta_f <= cyc;
        if (init_start && t_is == 0) t_is <= cyc;
        if (init_busy && !p_ib && t_ib_r == 0) t_ib_r <= cyc;
        if (!init_busy && p_ib && t_ib_f == 0) t_ib_f <= cyc;
        if (!quiesce && p_q && t_qf == 0) t_qf <= cyc;
        if (!sys_ready && p_rdy && t_rf == 0) t_rf <= cyc;
        if (sys_ready && !p_rdy && t_rf != 0 && t_rr == 0) t_rr <= cyc;
        if (done && t_done == 0) begin t_done <= cyc; ended <= 1'b1; end
      end
    end
  end

  // ---------------------------------------------------------------- helpers
  task automatic wcyc(input int n);
    repeat (n) @(posedge clk);
    #1;
  endtask

  task automatic apply_cfg(input int algo, input int pat, input int sweep, input int sel, input int bank, input int bmask,
                           input int lo, input int hi, input int stop, input int reinit, input int kk, input int colsel);
    p_algo = 4'(algo); p_pat = 3'(pat); p_sweep = sweep[0]; p_sel = 3'(sel); p_bank = 8'(bank); p_bmask = NBANK'(bmask);
    p_lo = AW'(lo); p_hi = AW'(hi); p_stop = stop[0]; p_reinit = reinit[0]; p_k = 4'(kk); p_col = 2'(colsel);
  endtask

  // one test: clear -> (optional traffic warm-up) -> start -> done.  Returns through the monitor / DUT outputs.
  task automatic run_one(input int tg, input int tr);
    longint unsigned blk0, acc0, chk0, err0, int0;
    int g;
    clr = 1'b1; wcyc(1); clr = 1'b0; wcyc(1);
    traffic = tr[0];
    if (tr != 0) wcyc(64);                                   // let functional traffic be in flight when the test starts
    blk0 = f_blk; acc0 = f_acc; chk0 = f_chk; err0 = f_err; int0 = f_intest;
    mon_reset(); armed = 1'b1;
    start = 1'b1; wcyc(1); start = 1'b0;
    g = 0;
    while (!ended && g < 2000000) begin wcyc(1); g++; end
    wcyc(4);
    // 100 more cycles of traffic: the scoreboard must see valid (re-initialised) memory after the test
    if (tr != 0) wcyc(100);
    armed = 1'b0;
    traffic = 1'b0;
    wcyc(4);
    $display("RUN tag=%0d algo=%0d pat=%0d sweep=%0d sel=%0d bmask=%0d lo=%0d hi=%0d result=%0d cycles=%0d fail_count=%0d fail_valid=%0d fbank=%0d frow=%0d fbit=%0d fbit_v=%0d felem=%0d fop=%0d fpol=%0d fpass=%0d fcls=%0d fexp=%h fobs=%h tested=%h bfm=%h errflags=%h",
             tg, p_algo, p_pat, p_sweep, p_sel, p_bmask, p_lo, p_hi, result, t_done - t_start, fail_count, fail_valid, fail_bank, fail_row,
             fail_bit, fail_bit_v, fail_elem, fail_op, fail_pol, fail_pass, fail_cls, fexp, fobs, tested, bfm, errflags);
    $display("PH tag=%0d f0=%0d f1=%0d f2=%0d f3=%0d f4=%0d f5=%0d f6=%0d f7=%0d f8=%0d f9=%0d a0=%0d a1=%0d a2=%0d a3=%0d a4=%0d a5=%0d a6=%0d a7=%0d a8=%0d",
             tg, h_f[0], h_f[1], h_f[2], h_f[3], h_f[4], h_f[5], h_f[6], h_f[7], h_f[8], h_f[9],
             h_a[0], h_a[1], h_a[2], h_a[3], h_a[4], h_a[5], h_a[6], h_a[7], h_a[8]);
    $display("TL tag=%0d t_start=%0d t_qrise=%0d t_qack=%0d t_tact_rise=%0d t_tact_fall=%0d t_init_start=%0d t_ibusy_rise=%0d t_ibusy_fall=%0d t_qfall=%0d t_done=%0d t_rdy_fall=%0d t_rdy_rise=%0d max_sel_w=%0d order_n=%0d order=%h",
             tg, t_start, t_qrise, t_qack, t_ta_r, t_ta_f, t_is, t_ib_r, t_ib_f, t_qf, t_done, t_rf, t_rr, max_sel_w, ord_n, ord_v);
    $display("FUNC tag=%0d traffic=%0d blocked=%0d acc=%0d chk=%0d err=%0d acc_in_test=%0d", tg, tr, f_blk - blk0, f_acc - acc0, f_chk - chk0,
             f_err - err0, f_intest - int0);
  endtask

  // ---------------------------------------------------------------- coverage mode
  logic            det_any;
  logic [AW-1:0]   a_row; logic [BITW-1:0] a_bit; logic a_bitv; logic [2:0] a_elem; logic [31:0] a_cnt;
  task automatic run_cov_cfg(input int algo, input int pat, input int sweep);
    int g;
    p_algo = 4'(algo); p_pat = 3'(pat); p_sweep = sweep[0];
    clr = 1'b1; wcyc(1); clr = 1'b0; wcyc(1);
    mon_reset(); armed = 1'b1;
    start = 1'b1; wcyc(1); start = 1'b0;
    g = 0;
    while (!ended && g < 2000000) begin wcyc(1); g++; end
    wcyc(1);
    armed = 1'b0;
  endtask

  // ---------------------------------------------------------------- main
  string s_script, s_cov;
  int fd, rc, op, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14;
  int ncfg, cfg_algo [8], cfg_pat [8], cfg_sweep [8], cfg_nruns, fidx;
  int fb, ft, fr, fbit, fr2, fbit2, fv, fv2;
  longint unsigned blk0_, acc0_;
  initial begin
    mon_reset();
    repeat (4) @(posedge clk);
    #1 rst_n = 1'b1;
    wcyc(3);
    $display("CFG NBANK=%0d ROWS=%0d W=%0d RL=%0d NF=%0d", NBANK, ROWS, W, RL, NF);
    // establish a defined (all-zero) array before anything: one fault-free pass, exactly as the P78 campaign does
    apply_cfg(0, `MB_PAT_ALL0, 0, `MB_SEL_ALL, 0, (1 << NBANK) - 1, 0, ROWS - 1, 0, 1, 0, 0);
    sys.clear_faults();
    run_cov_cfg(0, `MB_PAT_ALL0, 0);
    if ($value$plusargs("script=%s", s_script)) begin
      fd = $fopen(s_script, "r");
      if (fd == 0) begin $display("ERROR cannot open %s", s_script); $finish; end
      while (!$feof(fd)) begin
        rc = $fscanf(fd, "%d", op);
        if (rc == 1) begin                                  // (no `continue`: Icarus 12 does not support it)
          case (op)
            0: begin sys.clear_faults(); end
            1: begin rc = $fscanf(fd, "%d %d %d %d %d %d %d %d %d", a1, a2, a3, a4, a5, a6, a7, a8, a9);
                     sys.set_fault(a1, a2, a3, a4, a5, a6, a7, a8, a9); end
            2: begin rc = $fscanf(fd, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d", a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14);
                     apply_cfg(a2, a3, a4, a5, a6, a7, a8, a9, a11, a12, a13, a14);
                     run_one(a1, a10); end
            3: begin rc = $fscanf(fd, "%d", a1); wcyc(a1); end
            5: begin rc = $fscanf(fd, "%d", a1);                 // functional traffic alone for a1 cycles: offered / accepted rate
                     blk0_ = f_blk; acc0_ = f_acc; traffic = 1'b1; wcyc(a1); traffic = 1'b0; wcyc(4);
                     $display("TRAF cycles=%0d accepted=%0d blocked=%0d", a1, f_acc - acc0_, f_blk - blk0_); end
            default: begin $display("ERROR bad opcode %0d", op); end
          endcase
        end
      end
      $fclose(fd);
    end
    if ($value$plusargs("cov=%s", s_cov)) begin
      fd = $fopen(s_cov, "r");
      if (fd == 0) begin $display("ERROR cannot open %s", s_cov); $finish; end
      // header: ncfg, then per cfg: nruns, (algo pat sweep) x nruns  -- stored flattened as cfg_nruns runs per cfg
      rc = $fscanf(fd, "%d", ncfg);
      apply_cfg(0, `MB_PAT_ALL0, 0, `MB_SEL_ALL, 0, (1 << NBANK) - 1, 0, ROWS - 1, 0, 1, 0, 0);
      fidx = 0;
      // configurations: read them into small arrays (at most 2 runs per configuration, 8 configurations)
      begin : cfgs
        int nr [8]; int ca [8][2]; int cp [8][2]; int cs [8][2];
        for (int c = 0; c < ncfg; c++) begin
          // scan into scalars, then assign (Icarus 12 cannot $fscanf into variable-indexed array elements)
          rc = $fscanf(fd, "%d", a1); nr[c] = a1;
          for (int r = 0; r < nr[c]; r++) begin
            rc = $fscanf(fd, "%d %d %d", a1, a2, a3); ca[c][r] = a1; cp[c][r] = a2; cs[c][r] = a3;
          end
        end
        while (!$feof(fd)) begin
          rc = $fscanf(fd, "%d %d %d %d %d %d %d %d", fb, ft, fr, fbit, fr2, fbit2, fv, fv2);
          if (rc == 8) begin                                // (no `continue`: Icarus 12 does not support it)
            for (int c = 0; c < ncfg; c++) begin
              det_any = 1'b0; a_row = '0; a_bit = '0; a_bitv = 1'b0; a_elem = '0; a_cnt = 0;
              for (int r = 0; r < nr[c]; r++) begin
                sys.clear_faults();
                sys.set_fault(fb, 0, ft, fr, fbit, fr2, fbit2, fv, fv2);
                run_cov_cfg(ca[c][r], cp[c][r], cs[c][r]);
                if (result == `MB_RES_FAIL && fail_count != 0 && !det_any) begin
                  det_any = 1'b1; a_row = fail_row; a_bit = fail_bit; a_bitv = fail_bit_v; a_elem = fail_elem; a_cnt = fail_count;
                end
                if (result != `MB_RES_FAIL && result != `MB_RES_PASS) $display("ANOMALY idx=%0d cfg=%0d result=%0d", fidx, c, result);
              end
              $display("CF idx=%0d cfg=%0d det=%0d row=%0d bit=%0d bit_v=%0d elem=%0d count=%0d", fidx, c, det_any, a_row, a_bit, a_bitv, a_elem, a_cnt);
            end
            fidx++;
          end
        end
      end
      $fclose(fd);
      sys.clear_faults();
    end
    $display("DONE cycles=%0d", cyc);
    $finish;
  end
  initial begin #(64'd60_000_000_000); $display("ERROR watchdog"); $finish; end
endmodule
