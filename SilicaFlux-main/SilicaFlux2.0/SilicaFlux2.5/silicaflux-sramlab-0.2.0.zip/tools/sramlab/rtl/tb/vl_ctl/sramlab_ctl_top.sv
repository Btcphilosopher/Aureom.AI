// =============================================================================
// SRAMLab :: sramlab_ctl_top  -- Verilator top for the C++-driven controller harness
//
// A pass-through wrapper around the REAL sf_sram_subsystem (SRAMController P73 +
// SRAMCore P71 banks, vendored byte-identical).  It contains no initial blocks, no
// delays and no testbench logic: every input is driven, and every output sampled,
// by sim_ctl.cpp through Verilator's eval() loop.  This is the canonical Verilator
// flow and does not depend on the --timing scheduler, which in Verilator 5.020
// (Ubuntu 24.04) failed to re-evaluate the controller's always_comb decode for
// inputs written by a timed initial block (see docs/03_verification.md, "Harness
// portability").
//
// The parameter names are those of the original SV testbench (tb_sramlab_ctl.sv)
// so sramlab/rtlrun.py passes the same -G generics to either harness.
// =============================================================================
`default_nettype none
module sramlab_ctl_top #(
  parameter int          NM        = 4,
  parameter int          NB        = 4,
  parameter int          DW        = 32,
  parameter int          BD        = 1024,
  parameter int          MAXOUT    = 1,
  parameter int          BANKOUT   = 0,
  parameter int          IDW       = 4,
  parameter int          ILV       = 0,
  parameter int          MASKMODE  = 0,
  parameter int          IDCHK     = 1,
  parameter int          SRCCHK    = 1,
  parameter int          PRIO      = 0,
  parameter logic [15:0] HPM       = 16'h0001,
  parameter int          HPL       = 4,
  parameter logic [63:0] LATS      = 64'h1111_1111_1111_1111,
  parameter int          UNI       = -1,
  localparam int NBYTE = DW / 8,
  localparam int SRCW  = (NM > 1) ? $clog2(NM) : 1,
  localparam int NPERF = 16 + 16 * NM + 8 * NB,
  localparam int PSW   = $clog2(NPERF)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic [NM-1:0]        m_req_valid,
  output logic      [NM-1:0]        m_req_ready,
  input  wire logic [NM-1:0]        m_req_we,
  input  wire logic [NM*32-1:0]     m_req_addr,
  input  wire logic [NM*DW-1:0]     m_req_wdata,
  input  wire logic [NM*NBYTE-1:0]  m_req_wstrb,
  input  wire logic [NM*IDW-1:0]    m_req_id,
  input  wire logic [NM-1:0]        m_req_err,
  output logic      [NM-1:0]        m_rsp_valid,
  input  wire logic [NM-1:0]        m_rsp_ready,
  output logic      [NM*DW-1:0]     m_rsp_rdata,
  output logic      [NM*IDW-1:0]    m_rsp_id,
  output logic      [NM-1:0]        m_rsp_we,
  output logic      [NM-1:0]        m_rsp_err,
  output logic      [NM*4-1:0]      m_rsp_status,
  input  wire logic                 flush,
  output logic                      idle,
  output logic                      sts_rsp_overflow,
  output logic                      sts_bank_proto,
  input  wire logic                 perf_clr,
  input  wire logic [PSW-1:0]       perf_sel,
  output logic      [31:0]          perf_val,
  // observability (read by the harness; not part of the subsystem interface)
  output logic      [NB-1:0]        obs_bk_req_valid,
  output logic      [31:0]          cfg_uniform,
  output logic      [31:0]          cfg_bank_out,
  output logic      [31:0]          cfg_max_lat,
  output logic      [31:0]          cfg_min_lat,
  output logic      [31:0]          cfg_nperf
);
  logic [NM*SRCW-1:0] m_req_src, m_rsp_src_unused;
  for (genvar m = 0; m < NM; m++) begin : g_src
    assign m_req_src[m*SRCW +: SRCW] = SRCW'(m);       // the master model always sends src = port index
  end

  sf_sram_subsystem #(
    .NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .BANK_DEPTH(BD), .ADDR_WIDTH(32), .ID_WIDTH(IDW),
    .MAX_OUT(MAXOUT), .BANK_OUT(BANKOUT), .INTERLEAVE(ILV), .ID_CHECK(IDCHK), .SRC_CHECK(SRCCHK),
    .MASK_MODE(MASKMODE), .PRIO_EN(PRIO), .HP_MASK(HPM), .HP_LIMIT(HPL), .PERF_EN(1), .CNT_W(32),
    .INIT_MODE(1), .BANK_LATS(LATS), .UNIFORM_LAT(UNI)
  ) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_we, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_req_id, .m_req_src, .m_req_err, .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_id,
    .m_rsp_src(m_rsp_src_unused), .m_rsp_we, .m_rsp_err, .m_rsp_status, .src_en({NM{1'b1}}),
    .flush, .idle, .sts_rsp_overflow, .sts_bank_proto, .perf_clr, .perf_sel, .perf_val
  );

  assign obs_bk_req_valid = dut.bk_req_valid;
  assign cfg_uniform      = 32'(dut.UNIFORM_EFF);
  assign cfg_bank_out     = 32'(dut.BANK_OUT_EFF);
  assign cfg_max_lat      = 32'(dut.MAX_LAT);
  assign cfg_min_lat      = 32'(dut.MIN_LAT);
  assign cfg_nperf        = 32'(NPERF);
endmodule
`default_nettype wire
