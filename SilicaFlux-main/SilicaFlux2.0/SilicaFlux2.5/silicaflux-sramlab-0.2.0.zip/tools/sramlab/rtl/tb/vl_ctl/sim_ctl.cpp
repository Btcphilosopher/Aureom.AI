// =============================================================================
// SRAMLab :: sim_ctl.cpp  -- C++-driven Verilator harness for sf_sram_subsystem
//
// Replays per-master request scripts against the real RTL (via sramlab_ctl_top) and
// writes the same cycle trace as the SV testbench tb_sramlab_ctl.sv, so
// sramlab/rtlrun.py compares it with the Python model unchanged.
//
// Why C++: the SV testbench drives the DUT from a timed `initial` block and needs
// Verilator's --timing scheduler.  Under Verilator 5.020 that scheduler did not
// re-evaluate the controller's always_comb decode after the testbench changed
// m_req_addr, so the RTL accessed stale rows (and with -O0 issued nothing at all).
// Driving inputs and calling eval() from C++ is the canonical Verilator flow and
// does not depend on the timing scheduler.
//
// Master model (IDENTICAL to sramlab/sim/driver.py):
//   * request i may be presented from ready_at; ready_at(0) = delay(0);
//     after acceptance in cycle t: ready_at(i+1) = t + 1 + delay(i+1)
//   * once presented, valid and payload hold until accepted (SFB2 R2)
//   * ID = i mod 2**IDW, src = port index (tied in the wrapper)
//   * m_rsp_ready from a per-cycle mask file (all ones beyond the file)
//
// Arguments: +stim=<file> +cycles=<N> +trace=<file> [+rdy=<file>] [+flush=<file>]
//   stim  : "0 m count" lines, then "1 m we addr wdata wstrb err delay" (hex addr/wdata/wstrb)
//   rdy   : "<cycle> <hex mask>"
//   flush : one cycle number per line
// Trace  : "T t reqv reqr rspv rspr bk idle [m:id:we:st:rdata ...]" per cycle (pre-edge
//          values), then "P <i> <v>" for every performance counter, then "S ovf proto".
// stdout : "CFG uniform=.. bank_out=.. max_lat=.. min_lat=..", "SRAMLAB_DONE cycles=N".
// Exit   : 0 ok, 2 usage/file error, 3 an RTL $error (embedded SFC_ASSERT checker) fired.
// =============================================================================
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <type_traits>
#include <vector>

#include "Vsramlab_ctl_top.h"
#include "verilated.h"

#ifndef NM
#error "NM (number of masters) must be defined by the build"
#endif
#ifndef NB
#error "NB (number of banks) must be defined by the build"
#endif
#ifndef DW
#error "DW (data width) must be defined by the build"
#endif
#ifndef IDW
#error "IDW (ID width) must be defined by the build"
#endif
static const int NBYTE = DW / 8;
static const int DWORDS = (DW + 31) / 32;

// ------------------------------------------------------------ generic bit access on Verilator port types
template <typename T>
static inline typename std::enable_if<std::is_integral<T>::value>::type setb(T& s, int i, uint32_t v) {
    if (v) s = (T)(s | ((T)1 << i));
    else   s = (T)(s & ~((T)1 << i));
}
template <std::size_t N>
static inline void setb(VlWide<N>& s, int i, uint32_t v) {
    if (v) s[i >> 5] |= (1u << (i & 31));
    else   s[i >> 5] &= ~(1u << (i & 31));
}
template <typename T>
static inline typename std::enable_if<std::is_integral<T>::value, uint32_t>::type getb(const T& s, int i) {
    return (uint32_t)((s >> i) & 1);
}
template <std::size_t N>
static inline uint32_t getb(const VlWide<N>& s, int i) {
    return (s[i >> 5] >> (i & 31)) & 1u;
}
template <typename S>
static void setf(S& s, int lsb, int w, const uint32_t* words) {
    for (int k = 0; k < w; k++) setb(s, lsb + k, (words[k >> 5] >> (k & 31)) & 1u);
}
template <typename S>
static void setf_u64(S& s, int lsb, int w, uint64_t v) {
    for (int k = 0; k < w; k++) setb(s, lsb + k, (uint32_t)((v >> k) & 1u));
}
template <typename S>
static uint64_t getf_u64(const S& s, int lsb, int w) {
    uint64_t v = 0;
    for (int k = 0; k < w; k++) v |= (uint64_t)getb(s, lsb + k) << k;
    return v;
}
template <typename S>
static void getf(const S& s, int lsb, int w, uint32_t* words) {
    for (int k = 0; k < (w + 31) / 32; k++) words[k] = 0;
    for (int k = 0; k < w; k++) words[k >> 5] |= getb(s, lsb + k) << (k & 31);
}

// minimal lowercase hex of a multi-word value (like SystemVerilog %0h)
static std::string hexs(const uint32_t* w, int nwords) {
    int top = nwords - 1;
    while (top > 0 && w[top] == 0) top--;
    char buf[16];
    std::snprintf(buf, sizeof buf, "%x", w[top]);
    std::string s = buf;
    for (int k = top - 1; k >= 0; k--) {
        std::snprintf(buf, sizeof buf, "%08x", w[k]);
        s += buf;
    }
    return s;
}

// parse a hex string into 32-bit words (little-endian word order)
static void parse_hex(const char* h, uint32_t* words, int nwords) {
    for (int k = 0; k < nwords; k++) words[k] = 0;
    int len = (int)std::strlen(h);
    int bit = 0;
    for (int i = len - 1; i >= 0 && bit < nwords * 32; i--, bit += 4) {
        char c = h[i];
        uint32_t d = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : (c >= 'A' && c <= 'F') ? c - 'A' + 10 : 0;
        words[bit >> 5] |= d << (bit & 31);
    }
}

struct ReqT {
    uint32_t we, err, addr, wstrb;
    uint32_t wdata[4];
    int64_t delay;
};

static const char* arg(int argc, char** argv, const char* key) {
    size_t n = std::strlen(key);
    for (int i = 1; i < argc; i++)
        if (std::strncmp(argv[i], key, n) == 0) return argv[i] + n;
    return nullptr;
}

int main(int argc, char** argv) {
    const std::unique_ptr<VerilatedContext> ctx{new VerilatedContext};
    ctx->commandArgs(argc, argv);
    ctx->fatalOnError(false);      // keep simulating after an embedded-checker $error: the full trace is the diagnostic
    const std::unique_ptr<Vsramlab_ctl_top> top{new Vsramlab_ctl_top{ctx.get(), "TOP"}};

    const char* stim_f = arg(argc, argv, "+stim=");
    const char* cyc_s = arg(argc, argv, "+cycles=");
    const char* trace_f = arg(argc, argv, "+trace=");
    const char* rdy_f = arg(argc, argv, "+rdy=");
    const char* flush_f = arg(argc, argv, "+flush=");
    if (!stim_f || !cyc_s || !trace_f) {
        std::fprintf(stderr, "usage: simv +stim=<f> +cycles=<N> +trace=<f> [+rdy=<f>] [+flush=<f>]\n");
        return 2;
    }
    const long ncyc = std::atol(cyc_s);

    // ---- stimulus
    std::vector<std::vector<ReqT>> script(NM);
    {
        FILE* fd = std::fopen(stim_f, "r");
        if (!fd) { std::fprintf(stderr, "cannot open stim file %s\n", stim_f); return 2; }
        int op;
        while (std::fscanf(fd, "%d", &op) == 1) {
            if (op == 0) {
                int m, n;
                if (std::fscanf(fd, "%d %d", &m, &n) != 2) break;
                if (m >= 0 && m < NM) script[m].reserve(n);
            } else {
                int m, we, err;
                long long dly;
                char a[64], wd[64], ws[64];
                if (std::fscanf(fd, "%d %d %63s %63s %63s %d %lld", &m, &we, a, wd, ws, &err, &dly) != 7) break;
                if (m < 0 || m >= NM) { std::fprintf(stderr, "bad master index %d\n", m); return 2; }
                ReqT r{};
                r.we = (uint32_t)we; r.err = (uint32_t)err; r.delay = dly;
                r.addr = (uint32_t)std::strtoul(a, nullptr, 16);
                r.wstrb = (uint32_t)std::strtoul(ws, nullptr, 16);
                parse_hex(wd, r.wdata, 4);
                script[m].push_back(r);
            }
        }
        std::fclose(fd);
    }
    std::map<long, uint32_t> rdymask;
    if (rdy_f) {
        FILE* fd = std::fopen(rdy_f, "r");
        if (fd) {
            long c; char mk[32];
            while (std::fscanf(fd, "%ld %31s", &c, mk) == 2) rdymask[c] = (uint32_t)std::strtoul(mk, nullptr, 16);
            std::fclose(fd);
        }
    }
    std::set<long> flushset;
    if (flush_f) {
        FILE* fd = std::fopen(flush_f, "r");
        if (fd) {
            long c;
            while (std::fscanf(fd, "%ld", &c) == 1) flushset.insert(c);
            std::fclose(fd);
        }
    }

    FILE* tfd = std::fopen(trace_f, "w");
    if (!tfd) { std::fprintf(stderr, "cannot open trace file %s\n", trace_f); return 2; }

    // ---- reset: asserted for 5 clocks, released synchronously while clk is low
    top->clk = 0; top->rst_n = 0; top->flush = 0; top->perf_clr = 0; top->perf_sel = 0;
    top->m_req_valid = 0; top->m_req_we = 0; top->m_req_err = 0;
    for (int m = 0; m < NM; m++) setb(top->m_rsp_ready, m, 1u);
    top->eval();
    for (int k = 0; k < 5; k++) {
        ctx->timeInc(1); top->clk = 1; top->eval();
        ctx->timeInc(1); top->clk = 0; top->eval();
    }
    top->rst_n = 1;
    std::printf("CFG uniform=%u bank_out=%u max_lat=%u min_lat=%u\n", (unsigned)top->cfg_uniform,
                (unsigned)top->cfg_bank_out, (unsigned)top->cfg_max_lat, (unsigned)top->cfg_min_lat);

    std::vector<long> i_m(NM, 0);
    std::vector<int64_t> ready_at(NM);
    for (int m = 0; m < NM; m++) ready_at[m] = script[m].empty() ? INT64_MAX : script[m][0].delay;
    const uint32_t zero4[4] = {0, 0, 0, 0};
    std::string line;
    line.reserve(64 + NM * (DW / 4 + 16));

    for (long cyc = 0; cyc < ncyc; cyc++) {
        // ---- drive this cycle's inputs
        for (int m = 0; m < NM; m++) {
            const bool pres = i_m[m] < (long)script[m].size() && cyc >= ready_at[m];
            const ReqT* r = pres ? &script[m][i_m[m]] : nullptr;
            setb(top->m_req_valid, m, pres ? 1u : 0u);
            setb(top->m_req_we, m, r ? r->we & 1u : 0u);
            setb(top->m_req_err, m, r ? r->err & 1u : 0u);
            setf_u64(top->m_req_addr, m * 32, 32, r ? r->addr : 0u);
            setf(top->m_req_wdata, m * DW, DW, r ? r->wdata : zero4);
            setf_u64(top->m_req_wstrb, m * NBYTE, NBYTE, r ? r->wstrb : 0u);
            setf_u64(top->m_req_id, m * IDW, IDW, r ? (uint64_t)i_m[m] : 0u);
        }
        top->flush = flushset.count(cyc) ? 1 : 0;
        auto it = rdymask.find(cyc);
        const uint32_t mk = it != rdymask.end() ? it->second : 0xFFFFu;
        for (int m = 0; m < NM; m++) setb(top->m_rsp_ready, m, (mk >> m) & 1u);
        top->eval();                                   // combinational settle

        // ---- sample (pre-edge values) and trace
        const uint64_t reqv = getf_u64(top->m_req_valid, 0, NM), reqr = getf_u64(top->m_req_ready, 0, NM);
        const uint64_t rspv = getf_u64(top->m_rsp_valid, 0, NM), rspr = getf_u64(top->m_rsp_ready, 0, NM);
        char head[160];
        std::snprintf(head, sizeof head, "T %ld %llx %llx %llx %llx %llx %u", cyc, (unsigned long long)reqv,
                      (unsigned long long)reqr, (unsigned long long)rspv, (unsigned long long)rspr,
                      (unsigned long long)getf_u64(top->obs_bk_req_valid, 0, NB),
                      (unsigned)top->idle);
        line = head;
        for (int m = 0; m < NM; m++) {
            if ((rspv >> m) & 1u) {
                uint32_t rd[4];
                getf(top->m_rsp_rdata, m * DW, DW, rd);
                char ent[64];
                std::snprintf(ent, sizeof ent, " %d:%llu:%u:%llu:", m,
                              (unsigned long long)getf_u64(top->m_rsp_id, m * IDW, IDW), getb(top->m_rsp_we, m),
                              (unsigned long long)getf_u64(top->m_rsp_status, m * 4, 4));
                line += ent;
                line += hexs(rd, DWORDS);
            }
        }
        std::fputs(line.c_str(), tfd);
        std::fputc('\n', tfd);

        // ---- driver state update (acceptance)
        for (int m = 0; m < NM; m++) {
            if (((reqv >> m) & 1u) && ((reqr >> m) & 1u)) {
                i_m[m]++;
                if (i_m[m] < (long)script[m].size()) ready_at[m] = cyc + 1 + script[m][i_m[m]].delay;
            }
        }
        // ---- clock edge
        ctx->timeInc(1); top->clk = 1; top->eval();
        ctx->timeInc(1); top->clk = 0; top->eval();
    }

    // ---- read every performance counter (no further clocking: counters are frozen)
    const unsigned nperf = top->cfg_nperf;
    for (unsigned i = 0; i < nperf; i++) {
        setf_u64(top->perf_sel, 0, 16, i);   // PSW <= 9 bits; upper bits of the C type are ignored
        top->eval();
        std::fprintf(tfd, "P %u %u\n", i, (unsigned)top->perf_val);
    }
    std::fprintf(tfd, "S %u %u\n", (unsigned)top->sts_rsp_overflow, (unsigned)top->sts_bank_proto);
    std::fclose(tfd);
    top->final();
    std::printf("SRAMLAB_DONE cycles=%ld\n", ncyc);
    std::fflush(stdout);
    return ctx->gotError() ? 3 : 0;
}
