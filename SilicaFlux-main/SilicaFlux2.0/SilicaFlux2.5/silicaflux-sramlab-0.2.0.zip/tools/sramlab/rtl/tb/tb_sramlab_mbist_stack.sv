// =============================================================================
// SRAMLab :: tb_sramlab_mbist_stack
// Timeline of ONE MBIST run (March C-, all banks, sequential) on the REAL MemoryCore stack: sf_sram_controller ->
// sf_sram_bank -> sf_sram_macro_wrapper -> sf_sram_core (SECDED optional), driven by the P78 MBIST controller through the
// controller's own quiesce / idle / init / raw-test-bus contract, with a HUNGRY functional master (a read request is
// presented every cycle while +traffic=1; it never backs off, so `m_req_ready` low == the cycles a master is stalled).
// Wiring follows P78's own tb_mbist_memorycore.sv (accepted-request strobe as the intrusion probe, quiesce_ack tied 1).
// Prints one line:  STACK ecc rl nb rows total_cycles t_* ...  (times are absolute edge indices, see tb_sramlab_mbist_run.sv)
// Plusargs: +traffic=<0|1>
// =============================================================================
`timescale 1ns/1ps
`include "sf_mbist_defs.svh"
`include "sf_sram_defs.svh"
module tb_sramlab_mbist_stack;
  parameter int ECC_EN = 1;
  parameter int READ_LATENCY = 1;
  parameter int NB = 4;
  parameter int DEPTH = 64;
  localparam int DW = 32, AWB = 16, IDW = 4, NM = 1;
  localparam int LB = $clog2(DW / 8);
  localparam int ROW_W = $clog2(DEPTH);
  localparam int BW = (NB > 1) ? $clog2(NB) : 1;
  localparam int R = $clog2(DW + $clog2(DW + 1) + 1);
  localparam int STORE_W = (ECC_EN != 0) ? DW + R + 1 : DW;
  localparam int BITW = $clog2(STORE_W);
  localparam int NLINES = NB * DEPTH;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic m_valid = 0;
  logic [AWB-1:0] m_addr = '0;
  wire m_ready, m_rsp_valid, m_rsp_we, m_rsp_ce; wire [DW-1:0] m_rsp_rdata; wire [IDW-1:0] m_rsp_id; wire [2:0] m_rsp_status;
  wire quiesce, c_idle, init_start, init_busy, tst_active, tst_ce, tst_we; wire [NB-1:0] tst_sel;
  wire [ROW_W-1:0] tst_addr; wire [STORE_W-1:0] tst_wdata; wire [NB*STORE_W-1:0] tst_rdata;
  wire [NB-1:0] ev_ce, ev_ue; wire [NB*16-1:0] ce_cnt, ue_cnt;
  logic start = 0, clr = 0;

  sf_sram_controller #(
    .NM(NM), .NB(NB), .DEPTH(DEPTH), .DW(DW), .AW(AWB), .IDW(IDW), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN), .NSLOT(8),
    .FAULT_INJECT(0)
  ) ctl (
    .clk(clk), .rst_n(rst_n), .m_req_valid(m_valid), .m_req_ready(m_ready), .m_req_we(1'b0), .m_req_addr(m_addr),
    .m_req_wdata('0), .m_req_be('1), .m_req_id('0), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(1'b1), .m_rsp_rdata(m_rsp_rdata),
    .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(quiesce), .idle_o(c_idle), .init_start_i(init_start),
    .init_busy_o(init_busy), .scrub_en_i(1'b0), .ecc_clr_i(1'b0), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue),
    .ce_cnt_o(ce_cnt), .ue_cnt_o(ue_cnt), .perf_acc_o(), .perf_conf_o(), .perf_busy_o(), .perf_stall_o(), .bank_acc_o(),
    .tst_active_i(tst_active), .tst_sel_i(tst_sel), .tst_ce_i(tst_ce), .tst_we_i(tst_we), .tst_addr_i(tst_addr),
    .tst_wdata_i(tst_wdata), .tst_rdata_o(tst_rdata),
    .fi_bank('0), .fi_type('0), .fi_row('0), .fi_row2('0), .fi_bit('0), .fi_bit2('0), .fi_val(1'b0), .fi_val2(1'b0),
    .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  wire busy, done, pass_o, fail_o, error_o; wire [2:0] result; wire [NB-1:0] tested, bfm; wire [`MB_NERR-1:0] errflags;
  wire [7:0] state; wire [31:0] fail_count;
  wire func_acc = m_valid & m_ready;

  sf_sram_mbist #(
    .NBANK(NB), .ROWS(DEPTH), .DATA_W(DW), .STORE_W(STORE_W), .READ_LATENCY(READ_LATENCY), .FIFO_DEPTH(4),
    .OWN_TIMEOUT(2000), .INIT_TIMEOUT(DEPTH + 200)
  ) dut (
    .clk(clk), .rst_n(rst_n), .start_i(start), .start_clr_i(1'b0), .abort_i(1'b0), .clear_i(clr), .fail_pop_i(1'b0),
    .clr_fault_i(1'b0), .cfg_from_pins_i(1'b1), .cfg_algo_i(4'd0), .cfg_pattern_i(3'd0), .cfg_stripe_k_i(4'd0),
    .cfg_sweep_i(1'b0), .cfg_colsel_i(2'd0), .cfg_stop_i(1'b0), .cfg_reinit_i(1'b1), .cfg_sel_i(3'd1), .cfg_bank_i(8'd0),
    .cfg_bmask_i({NB{1'b1}}), .cfg_row_lo_i('0), .cfg_row_hi_i(ROW_W'(DEPTH - 1)), .cfg_wdog_i(32'd0),
    .test_mode_i(1'b1), .test_permit_i(1'b1), .mem_inhibit_i(1'b0), .cpu_halted_i(1'b0), .protect_i('0),
    .busy_o(busy), .done_o(done), .pass_o(pass_o), .fail_o(fail_o), .error_o(error_o), .result_o(result),
    .bank_tested_o(tested), .bank_fail_mask_o(bfm), .err_flags_o(errflags), .state_o(state),
    .fail_valid_o(), .fail_bank_o(), .fail_row_o(), .fail_bit_o(), .fail_bit_v_o(), .fail_in_check_o(), .fail_elem_o(),
    .fail_op_o(), .fail_pol_o(), .fail_pass_o(), .fail_cls_o(), .fail_alias_o(), .fail_exp_o(), .fail_obs_o(),
    .fail_count_o(fail_count),
    .quiesce_o(quiesce), .quiesce_ack_i(1'b1), .idle_i(c_idle), .init_start_o(init_start), .init_busy_i(init_busy),
    .func_req_i(func_acc), .clk_req_o(), .tst_active_o(tst_active), .tst_sel_o(tst_sel), .tst_ce_o(tst_ce),
    .tst_we_o(tst_we), .tst_addr_o(tst_addr), .tst_wdata_o(tst_wdata), .tst_rdata_i(tst_rdata),
    .rb_req(1'b0), .rb_we(1'b0), .rb_addr(12'd0), .rb_wdata(32'd0), .rb_gnt(), .rb_rdata(), .rb_err(),
    .ras_valid_o(), .ras_type_o(), .ras_addr_o(), .ras_addr_v_o(), .ras_info_o(), .ras_corr_o(),
    .rep_row_v_o(), .rep_row_o(), .rep_col_v_o(), .rep_col_o(), .rep_ok_o(), .rep_unrep_o(), .rep_phys_o());

  // ---------------------------------------------------------------- hungry master: next line after each accepted request
  int line = 0;
  always @(posedge clk) if (m_valid && m_ready) begin
    line <= (line + 1) % NLINES;
    m_addr <= AWB'(((line + 1) % NLINES) << LB);
  end

  // ---------------------------------------------------------------- race-free monitor
  longint unsigned cyc = 0, acc_cnt = 0, blk_cnt = 0, t_start = 0, t_qrise = 0, t_ta_r = 0, t_ta_f = 0, t_is = 0, t_ib_r = 0, t_ib_f = 0, t_qf = 0, t_done = 0;
  longint unsigned t_rf = 0, t_rr = 0, h_run = 0, h_acq = 0, h_rel = 0, h_check = 0, h_bsel = 0, h_pinit = 0, h_drain = 0, h_bend = 0, h_fin = 0, h_idle = 0;
  logic armed = 0, started = 0, ended = 0, p_q = 0, p_ta = 0, p_ib = 0, p_rdy = 1;
  int max_sel_w = 0;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    p_q <= quiesce; p_ta <= tst_active; p_ib <= init_busy; p_rdy <= m_ready;
    if (m_valid && m_ready) acc_cnt <= acc_cnt + 1;
    if (m_valid && !m_ready) blk_cnt <= blk_cnt + 1;
    if (armed) begin
      if (start && !started) begin t_start <= cyc; started <= 1'b1; end
      if (started) begin
        if (!ended) begin
          case (state[3:0])
            4'd0: h_idle <= h_idle + 1;   4'd1: h_check <= h_check + 1; 4'd2: h_acq <= h_acq + 1;   4'd3: h_bsel <= h_bsel + 1;
            4'd4: h_pinit <= h_pinit + 1; 4'd5: h_run <= h_run + 1;     4'd6: h_drain <= h_drain + 1; 4'd7: h_bend <= h_bend + 1;
            4'd8: h_rel <= h_rel + 1;     4'd9: h_fin <= h_fin + 1;     default: ;
          endcase
        end
        if ($countones(tst_sel) > max_sel_w) max_sel_w <= $countones(tst_sel);
        if (quiesce && !p_q && t_qrise == 0) t_qrise <= cyc;
        if (tst_active && !p_ta && t_ta_r == 0) t_ta_r <= cyc;
        if (!tst_active && p_ta && t_ta_f == 0) t_ta_f <= cyc;
        if (init_start && t_is == 0) t_is <= cyc;
        if (init_busy && !p_ib && t_ib_r == 0) t_ib_r <= cyc;
        if (!init_busy && p_ib && t_ib_f == 0) t_ib_f <= cyc;
        if (!quiesce && p_q && t_qf == 0) t_qf <= cyc;
        if (m_valid && !m_ready && p_rdy && t_rf == 0) t_rf <= cyc;
        if (m_valid && m_ready && !p_rdy && t_rf != 0 && t_rr == 0) t_rr <= cyc;
        if (done && t_done == 0) begin t_done <= cyc; ended <= 1'b1; end
      end
    end
  end

  task automatic wcyc(input int n);
    repeat (n) @(posedge clk);
    #1;
  endtask

  int v_traffic, g;
  longint unsigned acc0, blk0;
  initial begin
    if (!$value$plusargs("traffic=%d", v_traffic)) v_traffic = 0;
    repeat (6) @(posedge clk);
    #1 rst_n = 1'b1;
    g = 0;
    while (!c_idle && g < 100000) begin wcyc(1); g++; end    // INIT_ON_RESET (ECC) : the init engine zeroes every row
    wcyc(20);
    // one warm-up MBIST pass is not needed: the controller leaves a valid (initialised) array; ECC off: SIM_INIT poison is overwritten by March w0
    clr = 1'b1; wcyc(1); clr = 1'b0; wcyc(1);
    m_valid = v_traffic[0];
    wcyc(64);
    acc0 = acc_cnt; blk0 = blk_cnt;
    armed = 1'b1; start = 1'b1; wcyc(1); start = 1'b0;
    g = 0;
    while (!ended && g < 2000000) begin wcyc(1); g++; end
    wcyc(4);
    if (v_traffic != 0) wcyc(100);
    armed = 1'b0;
    $display("STACK ecc=%0d rl=%0d nb=%0d rows=%0d traffic=%0d result=%0d fail_count=%0d cycles=%0d t_start=%0d t_qrise=%0d t_tact_rise=%0d t_tact_fall=%0d t_init_start=%0d t_ibusy_rise=%0d t_ibusy_fall=%0d t_qfall=%0d t_done=%0d t_rdy_fall=%0d t_rdy_rise=%0d max_sel_w=%0d",
             ECC_EN, READ_LATENCY, NB, DEPTH, v_traffic, result, fail_count, t_done - t_start, t_start, t_qrise, t_ta_r, t_ta_f, t_is, t_ib_r, t_ib_f, t_qf,
             t_done, t_rf, t_rr, max_sel_w);
    $display("STACKPH f0=%0d f1=%0d f2=%0d f3=%0d f4=%0d f5=%0d f6=%0d f7=%0d f8=%0d f9=%0d", h_idle, h_check, h_acq, h_bsel, h_pinit, h_run, h_drain, h_bend, h_rel, h_fin);
    $display("STACKF accepted=%0d blocked=%0d", acc_cnt - acc0, blk_cnt - blk0);
    $display("DONE cycles=%0d", cyc);
    $finish;
  end
  initial begin #(64'd2_000_000_000); $display("ERROR watchdog"); $finish; end
endmodule
