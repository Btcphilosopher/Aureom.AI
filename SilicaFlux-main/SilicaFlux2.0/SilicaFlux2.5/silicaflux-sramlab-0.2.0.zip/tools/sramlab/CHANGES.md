# Changes — SRAMLab 0.2.0 versus Project 80 (0.1.0)

## Why

Project 80 was run, unchanged, on Verilator 5.020 / Yosys 0.33 / Icarus 12.0 (the Ubuntu 24.04 packages): **16 failed / 275 passed / 10 skipped**
of its own tests. Its committed results had been produced on Verilator 5.49. Every failure traced to a Verilator 5.020 simulation defect
triggered by a testbench (details and minimal reproducers: `docs/03_verification.md`, *Harness portability*).

## RTL harnesses

* `rtl/tb/vl_ctl/sramlab_ctl_top.sv` + `sim_ctl.cpp` — new **C++-driven Verilator harness** for `sf_sram_subsystem` (pass-through top, `eval()`
  loop, no `--timing`, no `initial`). Same stimulus files and trace format as before, so the comparator is unchanged. Keeps simulating after an
  embedded-checker `$error` (full trace as diagnostic) and exits 3 if one fired. Build: `--cc --exe --build`, `--unroll-count 1024
  --unroll-stmts 1000000` (16×16 fairness checker, `BLKLOOPINIT` on 5.020). `rtlrun.BUILD_SCHEME` 2 → 3.
* `rtl/tb/ivl_ctl/tb_sramlab_ctl_ivl.sv` — new **Icarus testbench**, written independently for Icarus 12 (dynamic arrays, no `break`, `$fwrite`
  trace). `rtlrun.compare(..., simulator="icarus")`; `sramlab rtlcheck --icarus`.
* `tb_sramlab_ecc_codec.sv` — `$fscanf` into temporaries (defect A).
* ECC/MBIST study testbenches built with `-fno-life-post -fno-localize` (defect B), as `studies.ecc.VL_TIMING_WORKAROUND`, part of the build-cache key;
  study `BUILD_SCHEME` 1 → 3.
* `tb_sramlab_ecc_bank.sv`, `tb_sramlab_mbist_run.sv` — made Icarus-compatible without behavioural change (no `continue`, no task `return`, no
  array-literal initialiser, no `$fscanf` into indexed array elements).
* The pip-wheel `CFG_CXXFLAGS_PCH_I` override is applied only when `verilated.mk` actually has the empty setting (`tools.verilator()["pip_wheel"]`).

## Verification

* `sramlab/xsim.py`, `sramlab xsim` — ECC codec / ECC bank / MBIST testbenches run with identical inputs on Verilator and Icarus; every tagged
  result line compared; **negative control** rebuilds the MBIST testbench without the defect-B workaround and shows the cross-check detecting it
  on 5.020. `xsim --controller` adds the controller three-way check.
* `verify.WORKLOADS` — new `tensor` case: the TENSORCORE 08 chunked command stream (scaled to M = N = 8, K = 16) in the model-vs-RTL matrix
  (skipped for parameter sets whose memory is smaller than 512 B).
* `sramlab/rstats.py`, `scripts/r/sramlab_stats.R`, `sramlab rstats` — statistics recomputed in base R (no packages) from raw per-transaction data;
  every value compared; R-only analyses (Kruskal–Wallis between workloads, log-log elasticity of throughput on bank count with 95 % CI). Reports
  *unavailable* without `Rscript`.
* `stats.t_crit` — the 3-decimal t table and the df > 30 approximation (0.087 % error at df = 40) replaced by R-exact quantiles (12 digits) and a
  4-term Cornish–Fisher expansion (≤ 1.1e-7 relative error), found by the R cross-check.
* `studies/mbist.caveat_section` — the observation about P78's Verilator warning is computed from the runs (it was hard-coded as "not reproduced";
  on 5.020 it is reproduced) and names the installed Verilator version.

## Synthesis

* `studies/ecc.abc_available()` — functional ABC probe (requires ABC's own `ABC RESULTS:` log line; a wasm build that accepts `abc` and ends
  silently is detected). When ABC runs, the ECC study adds MemoryCore's flow (`abc -fast`) next to SRAMLab's no-ABC flow: 315 / 1392 cells vs
  MemoryCore's committed 314 / 1389 at K = 128; MemoryCore's own script reproduces 314 / 1389 exactly on Yosys 0.33, and the residual is
  explained (ABC depends on netlist ordering). The hard-coded "this environment's Yosys (yowasp wasm) cannot run ABC" text is gone.
* `scripts/generate_data.py --only synth_extra` regenerates the masters × `MAX_OUT` sweep, the integrated subsystem and the NoC interface
  (Project 80 committed them without a reproduction command).
* Golden-number regression pins for Yosys 0.33 next to 0.71 (they skipped on every non-0.71 Yosys before), plus a test that flip-flop counts
  agree across Yosys versions.

## Dashboard

* Header "RTL verification" block shows the three-way, second-simulator and R cross-check results (`xsim_verification.json`, `r_crosscheck.json`
  are embedded). Experiment history maps every CLI command to its provenance class (records of `ecc`, `mbist`, `xsim`, `rstats`, `optimise`,
  `power`, `floorplan` were shown as UNCLASSIFIED). Icarus and R versions are reported as clean version numbers.

## Records, data, docs

* `record.simulation_version()` in every experiment record: SRAMLab version, harness schemes, controller-RTL hash, Verilator workaround flags and
  a SHA-256 of the SRAMLab source tree.
* All datasets in `data/` regenerated on Verilator 5.020 / Icarus 12.0 / Yosys 0.33 / R 4.3.3; new `data/xsim_verification.json`,
  `data/r_crosscheck.json`; Project 80 run records archived in `data/archive/p80_runs/`.
* Report §1 now includes the three-way, second-simulator and R evidence; §2 the R sensitivity analysis; §3 states (from the dataset) that the
  TC08 stream is replayed on the RTL.
* Result tables in `docs/ecc.md`, `docs/synthesis.md`, `docs/physical.md` regenerated from the 0.2.0 datasets; `docs/06_brief_traceability.md` added.
* README (commands table now enforced in both directions by `tests/test_cli.py`), `docs/00_audit.md`, `docs/03_verification.md`,
  `docs/05_limitations.md`; packaging prefix `tools/sramlab/`.

## Tests added

`tests/test_harness_portability.py` (C++ harness has no timing dependency; the two cases that diverged now match; three-way on five cases;
Icarus comparator can fail; unknown simulator rejected), `tests/test_xsim_rstats.py` (cross-simulator check, negative control, R agreement,
R comparator can fail, t table vs exact quantiles, R unavailable), CLI tests for `xsim` and `rstats`, the P78 caveat test rewritten to check
consistency with the installed Verilator rather than a fixed outcome.
