#!/usr/bin/env python3
"""Regenerate the committed datasets in data/ (everything is deterministic given the seeds).
Usage: python3 scripts/generate_data.py [--only bank_sweep,timeline,vector,tensor,rtl,synth_extra]
Study datasets with their own commands: sramlab ecc | mbist | synth (+ --liberty nangate45 --fetch) | floorplan --dataset | power --dataset | optimise
| xsim --dataset | rstats --dataset.  ``synth_extra`` regenerates the synthesis datasets that have no CLI command of their own
(masters x MAX_OUT sweep, integrated subsystem, NoC interface); run it after ``sramlab synth --liberty nangate45 --fetch``
so the mapped variants are produced as well."""
import argparse, json, os, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from sramlab import experiments as E, record
from sramlab.config import load_config
from sramlab.studies import vector as V, tensor_study as T

D = os.path.join(ROOT, "data")

def dump(name, obj):
    with open(os.path.join(D, name), "w") as f:
        json.dump(obj, f, indent=1, default=record._json_default)
    print("wrote", name, flush=True)

def bank_sweep():
    out = {}
    for mo in (1, 4):
        base = load_config({"name": f"bank_sweep_mo{mo}", "memory": {"banks": 4, "bank_depth_words": 4096},
                            "controller": {"masters": 4, "max_outstanding": mo},
                            "workload": {"kind": "rand_read", "requests_per_master": 2000, "seed": 100,
                                         "write_fraction": 0.3, "hotspot_words": 8}})
        out[f"max_out_{mo}"] = E.sweep_banks(base, (2, 4, 8, 16), ("rand_read", "mixed", "seq_read", "hotspot", "contention"), replications=10)
    dump("bank_sweep.json", out)

def timeline():
    cfg = load_config({"name": "timeline_4b4m", "memory": {"banks": 4, "bank_depth_words": 4096},
                       "controller": {"masters": 4, "max_outstanding": 2},
                       "workload": {"kind": "mixed", "requests_per_master": 400, "seed": 21, "write_fraction": 0.3,
                                    "response_ready_rate": 0.9}})
    dump("timeline_trace.json", E.timeline_trace(cfg, 160))

def vector():
    s = V.run_vector_study(word_bits=(32, 128), vector_bits=(128, 256), banks=(4, 8, 16), replications=3, requests=1500)
    dump("vector_study.json", {"study": s, "p76_crosscheck": V.p76_crosscheck()})

def tensor():
    dump("tensor_study.json", T.run_tensor_study(banks=(1, 2, 4, 8, 16), max_out=(1, 2, 4), word_bits=(32, 128), dma_duty=(0.0, 0.25, 0.5)))

def synth_extra():
    """masters x MAX_OUT controller sweep (4 banks, counters off), the integrated sf_sram_subsystem (4 masters, 4 banks x 16 words,
    counters on; arrays become flip-flops - proof of integration only) and the P74 NoC interface, generic and Nangate45-mapped."""
    from sramlab import phys, synth, tech
    out = os.path.join(D, "synth")
    nl = tech.nangate45_liberty()
    variants = [(None, "generic")] + ([(nl["path"], "nangate45")] if nl.get("available") else [])
    if not nl.get("available"):
        print("  Nangate45 liberty not present (sramlab synth --liberty nangate45 --fetch): mapped variants skipped", flush=True)
    sub = {"NUM_MASTERS": 4, "NUM_BANKS": 4, "DATA_WIDTH": 32, "BANK_DEPTH": 16, "MAX_OUT": 1, "BANK_OUT": 0, "UNIFORM_LAT": -1,
           "PRIO_EN": 0, "PERF_EN": 1, "CNT_W": 32}
    for lib, sfx in variants:
        synth.synth_sweep(banks=(4,), masters=(2, 4, 8), max_out=(1, 4), perf=(0,), outdir=out, liberty=lib,
                          name=f"masters_maxout_sweep_{sfx}", jobs=2)
        print(f"wrote synth/masters_maxout_sweep_{sfx}.*", flush=True)
        r = synth.synth_subsystem(sub, out, lib)
        with open(os.path.join(out, f"subsystem_{sfx}.json"), "w") as f:
            json.dump(synth.portable(r), f, indent=1, default=str)
        print(f"wrote synth/subsystem_{sfx}.json ({r['status']})", flush=True)
        n = phys.noc_interface_synth(out, lib, result_name="noc_interface" if lib is None else "noc_interface_nangate45")
        print(f"wrote synth/noc_interface{'' if lib is None else '_nangate45'}.json", flush=True)


def rtl():
    """Full model-vs-RTL matrix (~2 min); same code as `sramlab rtlcheck`."""
    from sramlab import verify
    res = verify.run_matrix(quick=False, n_req=300, seed=11)
    res["mutation_check"] = verify.mutation_check()
    dump("rtl_verification.json", res)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--only", default="bank_sweep,timeline,vector,tensor,rtl,synth_extra")
    a = ap.parse_args()
    os.makedirs(D, exist_ok=True)
    for name in a.only.split(","):
        t0 = time.time(); globals()[name](); print(f"  {name}: {time.time()-t0:.0f}s", flush=True)
