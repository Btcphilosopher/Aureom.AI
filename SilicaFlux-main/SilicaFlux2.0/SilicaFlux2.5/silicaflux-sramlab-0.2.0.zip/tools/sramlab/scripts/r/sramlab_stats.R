#!/usr/bin/env Rscript
# =============================================================================
# SRAMLab :: sramlab_stats.R  -- independent statistical computation in R
#
# Called by sramlab/rstats.py (`sramlab rstats`).  Reads RAW simulation output
# written by Python (per-transaction rows and per-replication rows) and
# recomputes, with base R only (no packages):
#   * per-replication read end-to-end latency: mean, median, P95, P99
#       (quantile type 7 = the linear interpolation NumPy uses by default),
#       arbitration delay mean, request throughput
#   * across replications: mean, sd, Student-t 95 % CI half-width (exact qt())
#   * Spearman rank correlation of throughput with bank count (per workload)
#   * R-only analyses (reported, not compared): Kruskal-Wallis test of the
#     between-workload variation of throughput and a log-log linear model of
#     throughput on bank count (elasticity) per workload
# Output: a flat CSV "key,value" so no JSON package is required.
#
# Usage: Rscript sramlab_stats.R <tx.csv> <reps.csv> <sweep.csv> <out.csv>
# =============================================================================
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 4) stop("usage: sramlab_stats.R tx.csv reps.csv sweep.csv out.csv")
tx    <- read.csv(args[1], stringsAsFactors = FALSE)
reps  <- read.csv(args[2], stringsAsFactors = FALSE)
sweep <- read.csv(args[3], stringsAsFactors = FALSE)

out_k <- character(0); out_v <- character(0)
put <- function(k, v) {
  out_k <<- c(out_k, k)
  out_v <<- c(out_v, if (is.numeric(v)) formatC(v, digits = 17, format = "g") else as.character(v))
}

q7 <- function(x, p) as.numeric(quantile(x, p, type = 7, names = FALSE))
tci <- function(x) {
  n <- length(x); m <- mean(x); s <- sd(x)
  hw <- if (n > 1) qt(0.975, n - 1) * s / sqrt(n) else NaN
  c(n = n, mean = m, sd = s, half_width = hw)
}

# ---- per replication, from the raw transactions (definitions of sramlab/metrics.py)
ok  <- tx[tx$status == 0 & tx$xfer >= 0, ]
rd  <- ok[ok$we == 0, ]
rd$lat_e2e <- (rd$push + 1) - rd$present
tx$arb <- tx$accept - tx$present
per_rep <- list()
for (w in sort(unique(reps$workload))) {
  vals <- list(lat_mean = c(), lat_median = c(), lat_p95 = c(), lat_p99 = c(), arb_mean = c(), thr = c())
  for (r in sort(unique(reps$rep[reps$workload == w]))) {
    pre <- sprintf("rep.%s.%d.", w, r)
    l <- rd$lat_e2e[rd$workload == w & rd$rep == r]
    a <- tx$arb[tx$workload == w & tx$rep == r]
    cyc <- reps$cycles[reps$workload == w & reps$rep == r]
    acc <- reps$accepted[reps$workload == w & reps$rep == r]
    put(paste0(pre, "read_lat_mean"), mean(l))
    put(paste0(pre, "read_lat_median"), median(l))
    put(paste0(pre, "read_lat_p95"), q7(l, 0.95))
    put(paste0(pre, "read_lat_p99"), q7(l, 0.99))
    put(paste0(pre, "arb_mean"), mean(a))
    put(paste0(pre, "throughput"), acc / cyc)
    vals$lat_mean <- c(vals$lat_mean, mean(l)); vals$lat_p99 <- c(vals$lat_p99, q7(l, 0.99))
    vals$thr <- c(vals$thr, acc / cyc)
  }
  for (nm in c("lat_mean", "lat_p99", "thr")) {
    s <- tci(vals[[nm]])
    for (f in names(s)) put(sprintf("ci.%s.%s.%s", w, nm, f), s[[f]])
  }
  per_rep[[w]] <- vals$thr
}

# ---- R-only: between-workload variation of throughput (Kruskal-Wallis, non-parametric)
g <- factor(rep(names(per_rep), times = sapply(per_rep, length)))
kw <- kruskal.test(unlist(per_rep), g)
put("analysis.kruskal_throughput_by_workload.statistic", unname(kw$statistic))
put("analysis.kruskal_throughput_by_workload.df", unname(kw$parameter))
put("analysis.kruskal_throughput_by_workload.p_value", kw$p.value)

# ---- bank-count sensitivity per workload (sweep rows are per replication)
for (w in sort(unique(sweep$workload))) {
  s <- sweep[sweep$workload == w, ]
  rho <- suppressWarnings(cor(s$banks, s$throughput, method = "spearman"))
  put(sprintf("spearman.%s.banks_throughput", w), rho)
  if (all(s$throughput > 0) && length(unique(s$banks)) > 1 && sd(log(s$throughput)) == 0) {
    put(sprintf("analysis.elasticity.%s.slope", w), 0)
    put(sprintf("analysis.elasticity.%s.note", w), "throughput is identical at every bank count (no regression fitted)")
  } else if (all(s$throughput > 0) && length(unique(s$banks)) > 1) {
    fit <- lm(log(throughput) ~ log(banks), data = s)
    ci <- confint(fit)["log(banks)", ]
    put(sprintf("analysis.elasticity.%s.slope", w), unname(coef(fit)["log(banks)"]))
    put(sprintf("analysis.elasticity.%s.ci_lo", w), unname(ci[1]))
    put(sprintf("analysis.elasticity.%s.ci_hi", w), unname(ci[2]))
    put(sprintf("analysis.elasticity.%s.r_squared", w), summary(fit)$r.squared)
  }
}
put("R.version", R.version.string)
write.csv(data.frame(key = out_k, value = out_v), args[4], row.names = FALSE, quote = TRUE)
