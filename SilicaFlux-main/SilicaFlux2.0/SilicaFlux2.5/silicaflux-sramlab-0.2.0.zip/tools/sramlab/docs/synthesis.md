# Synthesis (`sramlab/synth.py`)

What this answers: *how much logic does the SRAM controller need, and how does it grow with the bank count?*  It does **not** answer how big, how fast or how
power-hungry the real chip is.

## Scope - read this first

* **Controller logic only.**  `synth_controller` synthesizes `sf_sram_controller` (per-bank arbiters, response FIFOs, trackers, performance counters).  The bank SRAM
  arrays are **not** synthesized to gates; the bits they would hold (`NUM_BANKS * BANK_DEPTH * DATA_WIDTH`) are reported separately as an `analytical` count.
* `synth_subsystem` synthesizes the integrated `sf_sram_subsystem` (controller + banks of `sf_sram_core`) **once, with a small depth**, only to prove that the integrated top
  elaborates and synthesizes.  There the tiny arrays become flip-flops through `memory_map` - that is not an SRAM macro and its area is not representative of anything.
* **Gate counts are not area.**  Without a technology library the area is `unavailable("no technology library")`.
* **No timing.**  Yosys gives no signoff timing and OpenSTA / OpenROAD are not installed here (`tools.opensta()` / `tools.openroad()` are `None`); every result carries
  `signoff_timing = unavailable(...)`.  The only depth figure is Yosys `ltp -noff` and is labelled *"pre-mapping logic depth (gate levels), not a frequency"*.

## Method

Yosys 0.33 (Ubuntu package) in 0.2.0; Project 80 used Yosys 0.71 (`yowasp-yosys`, WebAssembly). Each run stages the RTL and Liberty into its own directory and uses relative paths, because
the wasm build cannot read absolute `/tmp` paths; the same scripts run on both builds and every record carries the Yosys version that produced it.

```
read_verilog -sv -Irtl <fifo, arb, perf, controller>
hierarchy -check -top sf_sram_controller -chparam NUM_BANKS .. -chparam PERF_EN ..
synth -top sf_sram_controller -flatten
check -assert                      # structural check; the verdict is recorded
tee -o stat_generic.txt stat ; tee -o stat_generic.json stat -json ; tee -o ltp.txt ltp -noff
# only with a Liberty:
dfflibmap -liberty L ; abc -liberty L ; opt_clean -purge ; stat -liberty L   (text + json)
```

* Latch check: any `$_DLATCH*` cell is counted; every run below is latch-free.  `$scopeinfo` metadata cells are excluded from the cell counts.
* The stat reports are parsed by the pure function `parse_yosys_stat()` (text) **and** `stat -json`; the two must agree, and a report whose per-type counts do not add up to the
  printed total, that is truncated, or has no cell count is rejected (`YosysParseError`, unit-tested on captured samples and on corrupted ones).
* Parameters default to what `sf_sram_subsystem` derives for the sramlab default (`BANK_OUT=2`, `UNIFORM_LAT=1`, `DATA_WIDTH=32`, `BANK_DEPTH=1024`, `CNT_W=32`); the RTL's own defaults for
  `BANK_OUT`/`UNIFORM_LAT` are 4/0.  Every result records its full parameter set.
* Results are cached in `sramlab/.cache/synth/`, keyed on (RTL + include hash, parameters, Yosys version, flow version, Liberty sha256); failures are never cached.

## Liberty (technology library)

`sramlab/tech.py::fetch_nangate45()` downloads the one permitted file, `NangateOpenCellLibrary_typical.lib`
(`https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/master/flow/platforms/nangate45/lib/`), into a NEW EMPTY directory under `sramlab/.cache/tech/nangate45/`
(never bundled; `.cache` is excluded from releases).

| | |
|---|---|
| bytes | 6,692,032 |
| sha256 (pinned in `configs/tech/nangate45.json`) | `8d540a4d4cf6d09d27c87ad067857a9c0c2eeb023ab7a56e058cd3113db4e9b1` |
| downloaded | 2026-11-14T21:51:09Z (recorded in `.cache/tech/nangate45/FETCH.json`) |
| conditions (library header) | typical process, 1.10 V, 25 C; units 1 ns, 1 nW, 1 V, 1 fF; area in um^2 |

A later download or cached file whose sha256 differs from the pin is **refused** (`TechError`), and a non-empty destination is refused.  Every mapped area is bound to the string
*"NangateOpenCellLibrary 45 nm typical (open educational library; NOT the SilicaFlux target process; area is not transferable to another node)"*.

## Results (Yosys 0.33; generic gates / Nangate45-mapped; controller logic only)

`data/synth/controller_sweep_generic.{csv,json}` and `controller_sweep_nangate45.{csv,json}` (`NUM_MASTERS=4`, `MAX_OUT=1`, 32-bit words, 1024 words per bank).  All 16 runs: `check -assert` clean, 0 latches.
(Project 80's numbers were from Yosys 0.71; gate counts and depths move with the Yosys version — flip-flop counts are identical — so compare within one version only.)

| banks | perf counters | generic cells | flip-flops | pre-mapping depth (levels) | mapped cells | **mapped area (um^2, Nangate45)** | array bits (analytical, not synthesized) |
|---:|---|---:|---:|---:|---:|---:|---:|
| 2 | off | 1,862 | 242 | 31 | 1,795 | 2,875.726 | 65,536 |
| 4 | off | 3,271 | 286 | 32 | 3,102 | 4,458.692 | 131,072 |
| 8 | off | 6,098 | 374 | 36 | 4,250 | 6,598.662 | 262,144 |
| 16 | off | 11,740 | 550 | 43 | 8,291 | 11,897.382 | 524,288 |
| 2 | on | 18,201 | 2,393 | 87 | 15,594 | 27,814.822 | 65,536 |
| 4 | on | 22,725 | 2,821 | 103 | 19,153 | 33,784.394 | 131,072 |
| 8 | on | 31,828 | 3,677 | 133 | 25,272 | 45,083.542 | 262,144 |
| 16 | on | 49,923 | 5,389 | 197 | 39,425 | 68,618.424 | 524,288 |

Reading it: the controller grows roughly linearly with the bank count (per-bank arbiter + tracker + response path; 16 banks cost 6.3x the logic of 2 banks without counters).  The performance counters
(`PERF_EN=1`: `16 + 16*NM + 8*NB` 32-bit counters and their read-out mux) are the largest single block: +16,339 cells at 2 banks, +38,183 at 16.  The pre-mapping depth jump with counters
is the counter read-out network (`perf_sel` → `perf_val`); without counters the longest path runs from the response handshake through the grant logic to the bank request.
Mapped area is of **this library only** (a 45 nm educational library); it is not the area of any SilicaFlux target process.

Masters / `MAX_OUT` at 4 banks, counters off (`masters_maxout_sweep_*`):

| masters | MAX_OUT | generic cells | mapped area (um^2, Nangate45) |
|---:|---:|---:|---:|
| 2 | 1 | 1,726 | 2,305.422 |
| 4 | 1 | 3,271 | 4,458.692 |
| 8 | 1 | 6,480 | 8,141.994 |
| 2 | 4 | 2,609 | 4,917.542 |
| 4 | 4 | 5,060 | 9,215.836 |
| 8 | 4 | 10,007 | 17,591.910 |

Integrated subsystem (`data/synth/subsystem_*.json`; 4 masters, 4 banks x 16 words x 32 bit, counters on): **synthesizes**, `check -assert` clean, 27,525 generic cells, 5,001 flip-flops, 0 latches
(the 2,048 array bits are inside those flip-flops); Nangate45-mapped 50,119.72 um^2 of arrays-as-flops + controller - shown only as a proof of integration.
The masters × `MAX_OUT` sweep, the subsystem and the NoC interface are regenerated by `python3 scripts/generate_data.py --only synth_extra` (in Project 80 they had no
reproduction command).

NoC interface (`data/synth/noc_interface*.json`, vendored P74 RTL in `rtl/third_party/p74_sramfabric`): see `docs/physical.md`.

Run times (0.2.0, Yosys 0.33, cold cache, two jobs in parallel on a 4-core container): 2.8 s (2 banks, no counters) to 60.5 s (16 banks with counters) generic; 3.8 s to 71.8 s with Liberty mapping.  Cached reruns take milliseconds.

## Limits

* One RTL revision (P73) and one tool version.  Gate counts move with the Yosys version; the golden-number tests carry pins for Yosys 0.71 and 0.33 and skip on any other version (flip-flop counts must agree across versions).
* Yosys `abc` is not a physical-design flow: no placement, buffering, clock tree, scan, or timing-driven sizing.  Mapped area is cell area only (no utilisation, no routing).
* The pinned library is a 2011 characterisation of a 45 nm educational process.  Do not compare its area with the SKY130/IHP/GF180 macros of `docs/physical.md`.
* `ltp` depth counts gate levels of the generic netlist before mapping; it is not a delay and not a frequency.

## Rerun

```python
from sramlab import synth, tech
lib = tech.fetch_nangate45()["path"]                      # once; verified against the pin afterwards (tech.nangate45_liberty())
synth.synth_sweep(outdir="data/synth", liberty=None)       # generic
synth.synth_sweep(outdir="data/synth", liberty=lib)        # Nangate45-mapped
python3 -m pytest tests/test_synth.py                      # ~25 s cold cache, ~12 s warm
```
