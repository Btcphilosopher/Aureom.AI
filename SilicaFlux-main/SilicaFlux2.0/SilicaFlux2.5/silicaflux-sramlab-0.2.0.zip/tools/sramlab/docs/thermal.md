# Thermal hand-off (`sramlab/thermal.py`)

> **Every file written here is an *uncalibrated model input - not a die temperature*.**  SilicaFlux ThermalLab is **not executed**: this is a
> format-level hand-off.  No temperature is produced by `thermal_handoff`.

## What `thermal_handoff(floorplan, power_by_block, outdir, run_metrics=None, neighbours=None)` writes

| file | when | content |
|---|---|---|
| `block_geometry_activity.csv/.json` | **always** | one rectangle per SRAM bank (and the controller reserve if it has a rectangle) from the *generated* floorplan, plus per-bank access activity from `run_metrics["bank_accesses"]`: `accesses`, `access_share`, `utilisation_accesses_per_cycle`, `access_density_per_mm2`.  No power column. |
| `thermallab_blocks.csv/.json` | **only when power exists** | the ThermalLab block schema `name, zone, x0_um, y0_um, x1_um, y1_um, power_w` + `kind, layer, provenance, source` (the documented `power_mapping.load_blocks_csv/json` input), plus caller-supplied neighbouring heat sources |

Without power (`power_by_block` is `None`/empty, i.e. no validated energy profile) the ThermalLab file is **omitted** and the result carries
`thermallab_blocks = unavailable("no validated energy profile => no power")`.  Power for only *some* banks is refused as well (a partial file would
silently treat the other banks as cold).  The controller has no energy model, so it is never given a power; if it has a rectangle it is listed in
`_omitted_blocks`.  Neighbour heat sources alone are not written either (they would hide the missing SRAM heat).

Every JSON has `_label` = "uncalibrated model input - not a die temperature" and every CSV row repeats it in its `source` column (a leading comment line
would break ThermalLab's `csv.DictReader`).  Coordinates are micrometres, origin at the lower-left of the placed objects, x right, y up (ThermalLab's die
convention).  Bank rectangles are **generated geometry from vendor macro dimensions, not a routed layout**.

### Where power comes from

* `power_by_block_from_energy(energy_report, floorplan, run_metrics)` turns the *activity-based* energy of `sramlab.power.energy_report` into per-bank
  average power: dynamic read/write energy by each bank's access share, idle energy by its idle-cycle share, leakage evenly, divided by `cycles / assumed clock`.
  It returns `None` unless the profile covered every term and a clock exists (so: no profile, no power).  Energy is conserved (`sum(P_bank) * t = total energy`, tested).
* Or the caller passes `{block_name: watts}` or tagged values `{"value", "provenance", "source"}`.  The label maps to ThermalLab's `provenance` column
  (`assumed -> assumed_engineering_parameter`, `simulated -> user_supplied_data`, `synthesized -> eda_derived_data`, `measured -> laboratory_measurement`);
  a bare float is treated as an assumption.  SRAMLab never invents a watt.

`validate_blocks` re-implements the documented required-field rules (this tool's own check, not ThermalLab).

## Hotspot map (`hotspot_map_2d`) - analytical, uncalibrated

A tiny pure-numpy steady-state finite-volume model of a heat-spreading sheet:

```
k t (T_xx + T_yy) - h (T - T_amb) + q''(x, y) = 0        adiabatic borders, uniform sheet
```

`k` (W/mK), `t` (um), `h` (W/m^2K, vertical coupling to ambient) and `T_amb` are **required arguments** - there are no defaults and they are echoed back as
"assumed (caller-supplied)".  Block powers are deposited by exact area overlap (total power conserved to round-off).  The result is a *rise* map relative to
the caller's assumed ambient (`label: analytical`, `calibration: uncalibrated`), solved by Jacobi-preconditioned CG.

Validation (all in `tests/test_thermal.py`):

* uniform heating over the whole sheet equals the closed form `rise = q''/h` everywhere (2 W on 1 mm x 0.5 mm, h = 1e4: 400 K; spread < 1e-8 K) - the large number only reflects the
  unrealistic test inputs;
* exact discrete power balance `sum(h A rise) = P_total` for non-uniform maps (residual < 1e-9 W);
* linearity (3x power -> 3x rise), mirror symmetry, maximum principle (no negative rise), thicker sheet -> lower peak.

## Limits

* One lumped sheet: no layer stack, package, heat sink, lateral variation of `h`, temperature-dependent leakage feedback or transient behaviour.  ThermalLab (3-D, package and
  cooling models, steady and transient) is the intended consumer; this module only feeds it.
* Power is uniform over each bank rectangle.  The access-activity distribution is per bank, not per macro.
* The geometry is generated (macros abutted unless `spacing` is given); real placement, halos and neighbours change the thermal picture.
* No temperature, junction limit or reliability statement is made anywhere.

## Rerun

```
python3 -m pytest tests/test_thermal.py          # < 1 s
```
