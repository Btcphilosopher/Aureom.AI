# Dashboard

`sramlab/dashboard.py` builds **one self-contained HTML file** (inline CSS, JavaScript and SVG; no CDN, no external fonts or scripts; it works offline from `file://`). Every dataset found in `data/` is embedded as JSON in `<script type="application/json" id="sramlab-data">`, and the page draws itself from that JSON only.

```
python3 -m sramlab.dashboard [--data DIR] [--out FILE] [--max-bytes N] [--no-probe]
```

Python: `sramlab.dashboard.build(data_dir=None, out_path=None) -> str` returns the output path (default `dashboard/sramlab_dashboard.html`); `render()` returns the HTML text. `SOURCE_DATE_EPOCH` makes the output byte-reproducible. The file must stay under 6 MB (`DashboardTooLarge` otherwise); the real data builds to about 0.55 MB.

## Layout of the source

| path | role |
|---|---|
| `dashboard/template.html` | page skeleton with `@@CSS@@`, `@@JS@@`, `@@DATA@@` placeholders (substituted in a single pass) |
| `dashboard/dashboard.css` | SilicaFlux look: midnight navy, metallic gold gradient headings, electric cyan primary data, tensor violet secondary, silicon silver text/axes |
| `dashboard/js/00_core.js` | DOM helpers (`textContent` only for data), provenance chips, formatting, tooltip, cards, tables, UNAVAILABLE panels |
| `dashboard/js/10_charts.js` | hand-written SVG: line, grouped bar with CI whiskers, stacked bar, histogram, scatter, heatmap; hover and keyboard (arrow keys) layer |
| `dashboard/js/21..25_views_*.js` | the 15 views |
| `dashboard/js/90_main.js` | header strip, navigation, hash routing (`#v1`..`#v15`), footer |
| `tests/test_dashboard.py`, `tests/dashboard_smoke.mjs` | Python tests and the Chromium smoke test |

## The 15 views

1 Memory architecture (structural block diagram, masters/banks selectors) · 2 SRAM bank map (low/high interleave, stride stream, locate a word; computed in the browser) · 3 Live transaction timeline (**replay** of `timeline_trace.json`: play, pause, step, scrub, speed) · 4 Read/write bandwidth (`bank_sweep`, analytical peak dashed) · 5 Latency distribution (histogram, mean and p99 markers) · 6 Bank conflict heatmap (per workload x bank; first replication only, so no CI) · 7 Tensor memory utilisation (MAC utilisation, starvation, operand B/cycle vs requirement, memory-limited verdict, buffers, DMA overlap, chunked roof) · 8 Vector memory utilisation (useful vs fetched, alignment overhead, P76 RTL cross-check) · 9 ECC overhead (closed-form SECDED storage always; RTL latency, partial-write cost, scrub, fault reporting and gate counts from `ecc_study.json`) · 10 MBIST results (test cycles, sequential vs analytical parallel model, test-mode overhead, fault-model coverage, failure registers from `mbist_study.json`) · 11 Area (Yosys controller gate counts and Nangate45-mapped logic area; subsystem/NoC results; `phys.json` when present) · 12 Power estimates (parameter-free activity proxy; energy is UNAVAILABLE unless a validated profile produced `power.json`) · 13 Configuration comparison (two configs side by side with 95% CI bars and an "intervals overlap" verdict; table of all rows) · 14 Pareto frontier (`optimise.json`: scatter, Pareto points ringed, colour by area or energy proxy, statement and caveats verbatim) · 15 Experiment history (`data/runs/experiments.jsonl` plus `EXP-*.json`).

## Provenance rules the page enforces

Every card carries a chip and a `source:` line. Mapping: `analytical`, `assumed` -> **ANALYTICAL** (dashed lines, hatched bars); `simulated` -> **SIMULATED**; `rtl_simulated` -> SIMULATED with an `RTL` annotation; `synthesized` -> **SYNTHESIZED**; `unavailable` -> **UNAVAILABLE**. A panel that mixes classes shows one chip per class. A label that is not one of these (including a data file claiming `measured`) is shown as **UNCLASSIFIED**; the legend states that **MEASURED: none exists** (no silicon or FPGA data) and no chart is ever coloured or labelled as measured.

Nangate45-mapped areas are labelled as an open educational 45 nm library, controller logic only, never as SilicaFlux silicon area. Die area, energy, power and thermal data stay UNAVAILABLE (with the reason and what would unlock them) unless the corresponding dataset provides tagged values.

## Robustness and honesty

* Any dataset may be absent, malformed, or contain `unavailable` values: the panel then shows an explicit UNAVAILABLE explanation, never a blank chart. Malformed files are listed in the footer.
* NaN/Infinity (which `JSON.parse` rejects) become `null` at build time. Numbers are rounded to 9 significant digits; nothing is smoothed, extrapolated or re-labelled.
* Only bulky raw data is dropped, and every drop is recorded in `trim_notes` (shown under "Embedded-data notes" in the footer): per-replication arrays, per-case RTL config echoes, per-run Yosys cell-type breakdowns, machine paths (`run_dir`, `exe`). If the file is over the cap the builder trims in a fixed order (RTL per-case rows, experiment history, generic study lists, latency histograms) before failing.
* Strings from datasets are inserted with `textContent`; the embedded JSON escapes `<`, `>` and `&`, so a dataset cannot close the script element.
* Studies with unknown layout (ECC, MBIST, physical, power, thermal) are also shown by a generic tagged-tree renderer under "Full study record", so every tagged value stays visible with its class, source or reason.

## Accessibility and responsiveness

Dark theme, 16 px side gutter on phones, navigation collapses to a menu button below 900 px, no horizontal page scroll (wide tables scroll inside their own region), visible focus outlines, `prefers-reduced-motion` respected (the replay never autoplays), charts use marker shape and dash pattern in addition to hue, every chart has a table view, and each chart is one tab stop (arrow keys step through values and show the tooltip).

## Testing

```
python3 -m pytest tests/test_dashboard.py            # Python side + (if node and playwright exist) the browser smoke tests
node tests/dashboard_smoke.mjs dashboard/sramlab_dashboard.html --shots DIR   # 1440x900 and 390x844, screenshots to DIR
```

The smoke test fails on any console message or page error, any external request, a view without a chip or without a non-empty chart / UNAVAILABLE panel, a card without a source line, placeholder text (`NaN`, `undefined`) in a panel, horizontal page scroll, a first render over 1 s, and checks tooltips, keyboard stepping, control re-rendering with focus kept, the replay, the bank map and the phone navigation.
