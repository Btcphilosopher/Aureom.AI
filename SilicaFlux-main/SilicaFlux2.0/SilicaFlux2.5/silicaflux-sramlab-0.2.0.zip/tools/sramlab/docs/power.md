# Power and energy provenance (`sramlab/power.py`)

**Status: no SRAM energy-per-access number exists in this tree.**  A source audit of every SilicaFlux package found macro dimensions
and clock->DOUT timing only; the earlier MemoryCore energy model runs on explicitly *assumed* parameters.  SRAMLab therefore ships
**no numeric energy defaults**: energy appears only when the user supplies a validated, condition-stamped profile.

## What you always get: activity (parameter-free, `simulated`)

`energy_report(run_metrics, profile=None, cfg=...)["activity"]` is derived from the run metrics (cycle model, verified against the RTL)
and needs no assumption: array accesses, reads/writes, array bit-activations (`accesses x stored word bits`, 39/72/137 with SECDED),
bank busy cycles, bank idle cycles (`banks x cycles - accesses`), data-bus toggles, per-bank access counts, and the ECC
read-modify-write amplification when the run carries a partial-write count (the cycle model has none, so it is `unavailable`, with the
reason).  These are proxies for the energy axis, **not energies**.

## Five separate sections (never summed together)

| section | content | label |
|---|---|---|
| `analytical_energy` | closed-form relations only (bit-activation ratio vs no ECC, the energy equation); absolute energy `unavailable` | `analytical` |
| `activity_based_estimate` | simulated counts x profile coefficients; terms `read/write/idle/leakage`; `dynamic_energy_J` and `total_energy_J` only when **every** term and a clock exist | `simulated`, or `assumed` if any coefficient has provenance `assumption` |
| `fpga_vendor_estimate` | `unavailable` unless a vendor report file is given; a Vivado `report_power` summary is parsed only if internally consistent (dynamic + static = total) | `synthesized` (vendor estimator, stated "NOT a measurement") |
| `asic_library_estimate` | `unavailable` unless a macro/cell Liberty is supplied; then leakage (library units, nominal conditions) and raw internal-power table counts; **no per-access energy is inferred** | `analytical`, `data_provenance: library` |
| `hardware_measurement` | `unavailable` unless a user-supplied measurement file declares `"provenance": "measured"` | `measured` (only then) |

Counts x datasheet/library/SPICE/measurement coefficients stay `simulated` (the activity is simulated); they never become `measured`.

## Energy profile schema (`load_energy_profile`)

JSON (or YAML if PyYAML is importable).  A profile may cover only some entries; the report says which terms are missing.  Placeholders in
angle brackets are things *you* must fill in from your source - there is no default and the loader rejects anything incomplete.

```json
{
  "id": "<your profile name>",
  "entries": {
    "read":    {"value": <number>, "unit": "fJ|pJ|nJ|uJ|mJ|J", "per": "macro_access|bank_access|bit_activation",
                "source": "<file / table / page / report>", "provenance": "library|spice|datasheet|measurement|assumption",
                "conditions": {"voltage_v": <V>, "temperature_c": <C>, "corner": "<corner>", "macro": "<macro name>"}},
    "write":   { ...same fields... },
    "idle":    { ... "unit": energy, "per": "macro_cycle|bank_cycle" ... },
    "leakage": { ... "unit": "pW|nW|uW|mW|W", "per": "macro|bank|bit" ... }
  }
}
```

Every entry **must** carry `value, unit, source, provenance, per` and all four `conditions`; a defect is reported precisely
(`entries.read.conditions.corner: missing`) and *all* defects are listed at once.  `per` states what one unit of the value refers to, so a
per-macro energy is multiplied by the number of macro columns of the tiling (`tile_memory`), a per-bit energy by the stored word width, etc.;
a per-macro value without a macro tiling is `unavailable`, never guessed.

**Operating conditions.**  A profile is valid at the conditions it states.  `energy_report(..., operating_conditions={...})` (and the
configured macro name) are compared with the entry conditions; a difference makes the energy `unavailable` with both condition sets quoted.
`allow_condition_mismatch=True` applies it anyway and puts a warning on the result.

**Clock.**  Leakage energy needs `time = cycles / f`; `physical.clock_mhz` is an *assumption* and is reported as `assumed_clock_mhz`.  Without it
leakage power is still reported, the total energy is not.

## Worked arithmetic (synthetic, from the test-suite; NOT physical)

`tests/test_power.py` uses a fixture named `TEST_FIXTURE_NOT_PHYSICAL` (read 2 pJ, write 3 pJ per bank access, idle 0.5 pJ per bank-cycle,
leakage 10 uW per bank) on 600 reads + 300 writes in 1000 cycles of a 4-bank memory at an assumed 100 MHz:
`E = 600*2 pJ + 300*3 pJ + 3100*0.5 pJ + 4*10 uW*10 us = 3.65 nJ + 0.40 nJ = 4.05 nJ` (3100 = 4*1000 - 900 idle bank-cycles).  The numbers are
chosen for easy arithmetic and exist only in the test file.

## The Liberty reader (`liberty_cell_power`)

A deliberately small reader for ONE named cell: `area`, `cell_leakage_power`, state-dependent `leakage_power` groups, and `internal_power`
tables (rise/fall, 2-D, 1-D and scalar).  It was **validated on the real Nangate45 library** (sha256 pinned in `configs/tech/nangate45.json`):

* AND2_X1: area 1.064 um^2, `cell_leakage_power` 25.066064 nW (= 2.5066064e-08 W, library unit `1nW`);
* for **all 126** of the 135 cells that have state-dependent leakage, `cell_leakage_power` equals the mean of the state values (relative error < 1e-5);
* every `internal_power` table has the shape its indices say (7x7, 1x7 or scalar for the DFF cells).

Limits: leakage is converted with the library's `leakage_power_unit`; **`internal_power` values are returned raw** - their energy unit is derived by the
consuming tool from the library's voltage/current/time units and is not converted here; and a Nangate45 cell is a standard cell, not an SRAM macro, so
`asic_library_estimate` never turns it into a per-access SRAM energy.  The vendored macro manifests list Liberty views but those `.lib` files are not part of
this tree, so for the SKY130/IHP/GF180 macros the section is `unavailable` until you supply the file.

## Limits

* No energy for the controller logic, clock tree, interconnect or I/O exists in this tool (no per-cell activity, no SAIF).
* Leakage is temperature/voltage dependent; a profile is valid only at its stated conditions.
* The FPGA parser is validated for internal consistency on a synthetic fixture only; no real vendor report was available.
* The hardware-measurement path accepts a user file as given; SRAMLab cannot vouch for the measurement.

## Rerun

```
python3 -m pytest tests/test_power.py          # ~6 s (the Nangate45 Liberty test needs sramlab/.cache/tech/nangate45; skipped if absent)
```
