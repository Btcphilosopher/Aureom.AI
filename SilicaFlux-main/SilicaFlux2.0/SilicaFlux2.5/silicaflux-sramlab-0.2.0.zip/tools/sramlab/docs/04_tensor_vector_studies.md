# 04 — Tensor and vector memory studies

## Tensor (`sramlab tensor`, `sramlab/sim/tensor.py`, `studies/tensor_study.py`)

**Workload source.** The SilicaFlux TensorCore array is 4×4 INT8, output-stationary (PE(i,j) owns C[i][j]), II = 1: one k-slice per cycle = 16 MAC/cycle
(TENSORCORE 02/08 docs, audited). Per k-step it consumes 4 A bytes (A[m0..m0+3][k]) + 4 B bytes (B[k][n0..n0+3]) = **8 B/cycle** at peak.

**Two views of the access stream**
* *Direct feed* (the TensorScratch P75 architecture), closed loop on the verified controller model: an A port (4 lanes × one 32-bit word per 4 k-steps ⇒ 1 word/cycle),
  a B port (one word per k-step), a C port (4×4 INT32 write-back, 16 words per tile) and a DMA master writing/reading at a configured duty. The array fires only when the A
  words of all four lanes of the k-group **and** the B word have arrived. Look-ahead runs continuously across tiles (a prefetching ping-pong buffer). Bank conflicts come from the real
  arbitration, so **matrix pitches** (`lda`, `ldb` that alias onto one bank) and **DMA contention** matter.
* *Chunked DMA stream* (TENSORCORE 08): per (4×4 tile, K-chunk of 64) LOAD_A = 4 rows × 64 B, LOAD_B = 64 rows × 4 B, then STORE. The stream is generated open-loop (`workload.kind: tensor_stream`),
  so it can be replayed on the RTL. Its traffic is **0.500 bytes/MAC (512 B per 1024 MAC)**, matching the TC08 definition.

**Reported:** A/B operand delivery (words/cycle), accumulator traffic, operand starvation (array idle cycles), buffer occupancy (words fetched ahead), DMA overlap (share of DMA-active
cycles during which the array also fired), useful MAC utilisation (`MAC / (cycles × 16)`), conflicts.

**"Is memory the limit?"** A configuration is *memory limited* when its utilisation is < 95 % of the *ideal-resource reference* of the same model (16 banks, MAX_OUT 8, padded pitches, deep look-ahead, no DMA).
The verdict is relative to that reference, not to an external claim. The accumulator write-back and tile boundaries mean the reference is below 1.0.

**Not modelled (stated):** TC03 operand-buffer RTL internals, array fill/drain beyond a `tile_overhead` parameter (default 0), clock frequency, power. The TC10 benchmark numbers (24 %/40 % MAC utilisation of the *DMA-chunked*
architecture over one 4 B/cycle port) are quoted as `imported_reference` only; they describe a different system.

## Vector (`sramlab vector`, `studies/vector.py`)

Vector accesses (128/256-bit) are decomposed into word-aligned controller transactions; the controller has no byte-granular read, so an unaligned vector fetches extra words:
`alignment overhead = fetched bytes / useful bytes`. Cases: aligned, word-misaligned, byte-misaligned, cross-bank, aligned and partial stores (an all-masked word is not accessed), strided (64 B and 256 B —
bank-aliasing strides).

**Independent check against RTL-measured data.** `studies/vector.py::p76_crosscheck` evaluates, for every deterministic sequential load/store row of the imported VectorScratch bench
(`data/imported/p76_bench.csv`, RTL simulation by that package): words per vector (arithmetic) and `cycles = max(vectors, max-bank slots) + READ_LATENCY + 2`. All comparable rows match exactly
(76/76 cycles and word counts). This validates the alignment and bank-slot reasoning the study relies on; it does *not* validate the controller model (that is `docs/03_verification.md`).

## Optimisation (`sramlab optimise`, `optimise.py`)

Goals: A lowest read latency, B highest useful bandwidth, C lowest area, D lowest energy per useful byte, E balanced PPA. Candidates vary banks, interleave, word width, MAX_OUT, read latency,
arbitration (and ECC/macro organisation when those data sets exist), each evaluated on a 5-workload suite with replications.

Rules enforced in code: ties are reported as ties (never broken arbitrarily); an axis with no data is reported `unavailable` and a loud caveat is attached to the Pareto set (without an area axis
"more banks" trivially wins — that is stated, not a recommendation); the energy axis is the parameter-free *activity proxy* (array bits activated per useful byte) unless a validated energy
profile exists, and the proxy cannot discriminate bank organisations (it says so); balanced-PPA winners are re-evaluated under 200 random weightings and the stability is published. The output states how many
distinct configurations win each goal and workload — it never names a universally optimal configuration.
