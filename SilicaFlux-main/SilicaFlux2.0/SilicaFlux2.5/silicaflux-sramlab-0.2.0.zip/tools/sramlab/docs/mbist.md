# MBIST evaluation (brief section 11)

`sramlab.studies.mbist.run_mbist_study(banks=(2, 4, 8, 16), bank_depth=256, word_bits=32, outdir=None, quick=False)` evaluates the **P78 MemoryTest MBIST controller**
(`rtl/third_party/p78_memorytest`, `sf_sram_mbist` + fsm / arbiter / failure registers, vendored byte-identical) in Verilator.  Faults come from P78's verification-only
fault-injection memory (`sf_mbist_fault_mem`, `sf_mbist_sram_sys`); the real MemoryCore controller is used for the overhead cross-check and the Verilator caveat.  Outputs:
`<outdir>/mbist_study.json` / `.csv`.  Labels: `rtl_simulated`, `simulated` (own Python March simulator), `analytical`, `unavailable`; nothing is `measured`.

> **Every coverage number below is: coverage of the injected fault model in simulation; this is NOT manufacturing/physical defect coverage.**
> It says how well the March algorithm detects an enumerated list of behavioural fault models on tiny instances.  Nothing is claimed about retention, read-disturb,
> bit-line / sense-amp, neighbourhood, resistive or at-speed faults (not modelled) or about silicon.

## What the RTL does with several banks

The selected banks are tested **one after another in ascending index** (`tst_sel` one-hot; checked: max popcount 1 and ascending order in every run).  Per bank: `BSEL, PINIT, RUN (K*N ops), DRAIN (LT), BEND`;
one ownership acquisition and one re-initialisation per run.  **There is no parallel-bank mode in the RTL.**  The parallel numbers below are an `analytical` model and are not RTL-verified.

## Test time (rtl_simulated; 256 words/bank, 32 b, READ_LATENCY 1; cycles = start pulse -> `done` flag)

`cycles = B*(1 + P*(K*N + LT + 2)) + ACQ + (ROWS + REL_FIXED) + 3` with K = 10 (March C-) / 5 (MATS+), N = words tested, P = background passes (1; the sweep option runs 1 + ceil(log2 W) = 6 at 32 b), `ACQ = 6`,
`REL_FIXED = 6` (constants measured on the smallest run, then **validated with 0 cycles of error on every other run**: 1-16 banks, windows 32-256, both algorithms, the 6-pass background sweep, ROWS 64/128/256, LT 1/2).
Per bank = 1 (BSEL) + P x (1 PINIT + K N + LT DRAIN + 1 BEND), i.e. K N + 4 for P = 1, and each extra pass costs K N + 3 cycles.  The engine's RUN state is exactly 10 N B / 5 N B cycles in every run
(the textbook operation counts hold); the "10N model" under-predicts by the overhead:

| banks | March C- cycles | 10 N B | model error | MATS+ cycles | 5 N B | model error |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 2835 | 2560 | 9.70 % | 1555 | 1280 | 17.7 % |
| 2 | 5399 | 5120 | 5.17 % | 2839 | 2560 | 9.83 % |
| 4 | 10527 | 10240 | 2.73 % | 5407 | 5120 | 5.31 % |
| 8 | 20783 | 20480 | 1.46 % | 10543 | 10240 | 2.87 % |
| 16 | 41295 | 40960 | 0.81 % | 20815 | 20480 | 1.61 % |

Time per added bank = **10 N + 4** (March C-) / 5 N + 4 (MATS+): 2564 / 1284 cycles at N = 256; fixed cost 271 = ROWS (re-init) + 15.  Analytical parallel model (identical banks, shared overhead paid once):
sequential / parallel = 1.90, 3.71, 7.33, 14.57 for 2, 4, 8, 16 banks (March C-); peak test power is not modelled (the RTL runs banks one at a time to bound it).
P78 docs/01 quotes 194 cycles for one 16-row bank: reproduced as 194 busy cycles (195 start-to-done, one extra IDLE sample).  P78's "~42,000 cycles for 4 banks x 1024 rows (arithmetic, not measured)" is measured here as 42,015 (model 42,015).

## Test-mode access overhead (quiesce -> drain -> confirm -> test -> release -> re-init)

16 banks x 256 rows, March C-, with / without the P78 functional master (LFSR traffic, scoreboard): request -> quiesce 3, quiesce -> acknowledge 0, **acknowledge -> ownership 3 cycles (4 with a request in flight)**,
test, release -> re-init start 3, **re-initialisation = ROWS = 256 cycles** (init engine rewrites one row per cycle), re-init done -> quiesce release 1.
Functional masters are refused from quiesce to the end of re-init: 2830 cycles for 1 bank, 41290 for 16 banks; of the 275 / 335 cycles that are not March operations, 256 are the re-init.
Traffic acceptance rate before the test is 0.54 requests/cycle, so ~1535 / ~22400 offered requests are delayed (analytical estimate from the measured rate).  **No request was accepted while the memory was owned and the
scoreboard saw 0 errors** (memory returned valid and re-initialised).  On the **real MemoryCore controller** (4 banks x 64 rows, hungry master that never backs off): 2656 cycles (ECC on or off, RL 1) vs 2655 for the P78 model;
refused window 2652 cycles.  Difference to the P78 model: +1 cycle (RL 1) / +2 (RL 2) in the release step, one more cycle with a request in flight; ECC on and off give the same count.

## Failure reporting (RTL registers vs independent Python prediction: 11/11 scenarios identical)

SAF1 in bank 5 row 37 bit 5: `FAIL`, count 3 (the three `r0` reads), first failure bank 5 / row 37 / bit 5 / element 1 `U(r0,w1)`, expected `0x00000000`, observed `0x00000020`, class `0TO1_BIT`.
SAF0 bank 0 MSB: element 2, expected `0xffffffff`, observed `0x7fffffff`.  Address faults give `ALL_BITS`; two faulty banks (2 and 11): first record from bank 2, `bank_fail_mask = 0x804`.
A same-word CFid fault **escapes** the solid-background March C- (`PASS`) and is caught by the background sweep.  `fail_count` counts failing reads; the class is symptom based (SA0 and up-transition look alike).

## Coverage of the injected fault model (rtl_simulated, independent Python simulator agrees fault by fault)

Population (P78 docs/04): SAF0/1, TF up/down per cell; address faults (none, alias, multi-OR, multi-AND); CFin(2), CFid(4), CFst(4) over every ordered cell pair, inter-word and same-word.
Exhaustive: 4x8 = 10,088 faults, 4x32 = 163,112 faults, 7 configurations (P78's five C0-C4 plus MATS+ checkerboard and MATS+ solid U checkerboard); RTL vs Python: 70,616 / 1,141,784 fault-x-configuration records, **0 mismatches** (detected?, first row/bit/element, failing-read count).
vs P78's committed `coverage.json`: all 140 (class, scope, configuration) cells equal for both instances (counts, not only percentages).  vs **MemoryCore's own committed 4x32 campaign**
(`reports/mbist_coverage.json`, its own engine and fault models): March C- and MATS+, solid / checkerboard / union, 27 classes x 3 columns x 2 algorithms: **160 of 162 counts equal** (two more configurations, MATS+
checkerboard and MATS+ solid U checkerboard, are run for this comparison; MemoryCore's MATS+ figures 72.50 % inter-word / 65.48 % same-word are for the union and are reproduced exactly).  **Two disagree**: MATS+ TF-down with the
checkerboard background and in the union - MemoryCore 128/128, here 64/128 (RTL and Python agree with each other).  Likely reason, demonstrated in the Python model: MemoryCore runs the checkerboard after the solid run and its re-initialisation
writes zero lines through the faulty array (a TF-down cell that held 1 stays 1), so the second run starts from a non-zero state (replayed: 128/128); the P78 model zeroes the array without fault effects before every run (64/128).
This is a harness difference, not a different algorithm.

| (4x32, exhaustive) | March C- solid | March C- checkerboard | solid U checker | March C- sweep | MATS+ solid |
|---|---:|---:|---:|---:|---:|
| SAF / TF (cells) | 100 % | 100 % | 100 % | 100 % | 75 % (TF-down 0 %) |
| address-decoder | 100 % | 100 % | 100 % | 100 % | 100 % |
| inter-word coupling | 100 % | 100 % | 100 % | 100 % | 50 % |
| same-word coupling (all 10 variants) | 60.00 % | 60.00 % | **80.65 %** | 100 % | 40.00 % |
| four weak same-word classes | 0 % | 51.61 % | 51.61 % | 100 % | 0 % |

4x8: same-word 60.00 / 60.00 / 82.86 / 100 / 40.00 %.  80.65 % is MemoryCore's own committed figure for the same engine and population.  The sweep's 100 % holds for the enumerated population at 8 and 32 columns only.

## Verilator caveat (P78 docs/06 section 5)

P78 reports that Verilator 5.020's default (optimised) build mis-simulates MemoryCore's vendored CFST fault model in the integrated 39-bit real-stack testbench and builds it at `-O0`.  SRAMLab re-runs
P78's own `tb_mbist_memorycore` (4 variants ECC on/off x RL 1/2, each with the default build, `-O0` and `-O3`) and reports **what the installed Verilator does** (`caveat_section`, computed, never a fixed text):

* Project 80, on Verilator 5.48/5.49 (pip): all 12 builds passed and detected CFST — the warning was not reproduced there.
* 0.2.0, on **Verilator 5.020**: the warning **is reproduced** — the default and `-O3` builds fail one check and miss CFST (fault type 8); `-O0` passes all 290 checks and detects it, exactly as P78 documents.

SRAMLab's own MBIST runs use P78's fault-model memory (not MemoryCore's CFST model), are built with the defect-B workaround (`docs/03_verification.md`) and are cross-checked line for line against Icarus (`sramlab xsim`),
so they do not depend on the optimisation level that breaks P78's real-stack testbench.

## Limitations

* Coverage is of the enumerated model on 4x8 / 4x32 instances; it does not scale automatically to other widths or classes and is not defect coverage (see the box above).  MATS+ appears only as the weaker reference.
* The memory-group model (`sf_mbist_sram_sys`) is verification-only; the real controller was checked on one shape.  No physical repair exists (analysis only), no non-destructive test, no retention test, no parallel mode.
* Times are cycles (no clock exists).  The functional-loss estimate multiplies the window by a measured traffic rate: it is an estimate.

## Rerun

```
python3 -c "from sramlab.studies.mbist import run_mbist_study as r; r(outdir='out/mbist')"                 # ~4.5 min cold, ~2.7 min warm (4x32 exhaustive coverage, 7 configurations, dominates)
python3 -c "from sramlab.studies.mbist import run_mbist_study as r; r(outdir='out/mbist', quick=True)"      # 4x8 only, 1 real-stack / caveat variant: ~50 s cold
python3 -m pytest tests/test_mbist.py                                                                       # ~30 s warm, ~70 s with cold Verilator builds
```
