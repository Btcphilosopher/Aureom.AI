# 02 — Metrics, ceilings and statistics

**Cycle convention** (as the RTL docs): a signal "in cycle t" is its value just before the edge ending cycle t. A request is *accepted* in the
cycle where `valid & ready` (= the bank access issue); an error-free response is visible in cycle `t + L + 1` for bank latency `L`.

| metric | definition | label |
|---|---|---|
| response latency | (cycle the response enters the response FIFO + 1) − accept cycle. Uncontended = `L+1` | simulated |
| **end-to-end latency** | response available − first cycle the request was presented (= arbitration delay + response latency). *This is what a master experiences*; the RTL-defined response latency excludes waiting to be accepted and therefore stays at `L+1` under contention | simulated |
| arbitration delay | accept cycle − first presented cycle (includes credit wait and bank-lock stalls) | simulated |
| sustained bandwidth | useful bytes / simulated cycles | simulated |
| useful bytes | requester-useful bytes: whole word per read, `popcount(wstrb)` per write; vector studies exclude padding fetched with a word | simulated |
| peak (theoretical) | `min(banks, masters · min(1, MAX_OUT/(L+1)))` txn/cycle × word bytes — a bound, tight only when latencies are uniform (bank-lock otherwise lowers the real ceiling) | **analytical** |
| random-access estimate | `B(1−(1−1/B)^m)` busy banks; an approximation, can be over/undershot | **analytical** |
| bank utilisation | accesses to the bank / cycles; busy fraction = cycles with an access in flight / cycles | simulated (RTL counters `PB_*`) |
| conflict rate | losers per accepted request (`PG_CONFLICT / PG_ACCEPTED`); per-bank conflict-cycle fraction | simulated (RTL counters) |
| queue occupancy | per-cycle sampled: total outstanding, per-bank tracker depth, response-FIFO depth; waiting masters = `PG_WAIT / cycles` | simulated |

The efficiency figure (`efficiency_vs_peak`) always divides a *simulated* value by an *analytical* ceiling; both appear in the output under their own keys.

## Statistics

* Latency samples inside one run are autocorrelated, so intervals come from **independent replications** (different seeds), not from transactions of one run.
* Mean ± Student-t 95 % half-width (exact table to 30 d.o.f.); percentile intervals by seeded bootstrap; `required_replications` states the number of replications a target
  relative half-width needs and every benchmark reports whether its sample met a 2 % throughput half-width.
* Sensitivity: arc elasticity `d ln y / d ln x`, Spearman rank correlation; workload variation as coefficient of variation.

## What "simulated" means here

The Python model is a transcription of the RTL and is verified against it (`docs/03_verification.md`); "simulated" results are therefore results of the *implemented
protocol*. They are not silicon measurements; no SilicaFlux hardware measurement exists and nothing is labelled `measured`.
