# 00 — Repository audit (SilicaFlux SRAM stack)

## Revision 0.2.0 (this delivery): audit of the existing SRAMLab (Project 80)

The repository already contained an SRAMLab (`silicaflux-sramlab-p80.zip`, v0.1.0) that implements this brief. Following the brief's rule
*reuse functioning analysis infrastructure*, it was **audited by running it**, not by reading its claims, on the toolchain that Ubuntu 24.04
installs: Verilator 5.020, Yosys 0.33, Icarus 12.0 (and R 4.3.3, which p80 did not have).

| p80 claim | what running it showed | action in 0.2.0 |
|---|---|---|
| "297 tests pass" | **16 failed / 275 passed / 10 skipped** | all fixed; new tests added (below) |
| "253/253 model-vs-RTL cases identical" | 0/2 on the quick subset: wrong read data, an RTL assertion | root cause = Verilator 5.020 `--timing` defect C, not the RTL or the model; C++-driven Verilator harness + independent Icarus testbench; **253/253 reproduced**, then extended to 275/275 (TensorCore command stream); 112/112 model = Verilator = Icarus |
| ECC codec RTL = independent reference | every vector mismatched | defect A (`$fscanf` writes do not trigger logic); testbench fixed; codec matches the reference again |
| MBIST exact cycle model (error 0 cycles) | errors of 2,668–13,329 cycles | defect B (optimiser, multi-process variable); `-fno-life-post -fno-localize`; exact again and identical on Icarus |
| P78 "5.020 symptom is NOT reproduced" | hard-coded text; on 5.020 it **is** reproduced | observation now computed from the runs |
| statistics "checked by hand-computed tests" | t-quantile approximation 0.087 % off at df = 40, table 3 decimals | exact (R `qt`) table + Cornish–Fisher; every statistic recomputed in R (`sramlab rstats`) |
| vendored RTL byte-identical to the source packages | **confirmed** (`cmp` against the P71/P73 zips) | — |
| cycle model is a transcription of the RTL | confirmed by reading `sf_sram_controller.sv`/`sf_sramc_arb.sv` against `sim/controller.py` (decode precedence, bank-lock, credits, tracker-full, arbiter pointer/streak) and by the regenerated matrix | — |

Everything else in p80 (configuration layer, model, workloads, metrics, studies, optimiser, records, dashboard, reports) was kept and re-run; all
datasets in `data/` were **regenerated** on this toolchain (the p80 run records produced on Verilator 5.49 are archived in `data/archive/p80_runs/`).
The remainder of this document is the Project 80 audit of the sibling packages, which still applies.

## Project 80 audit of the SilicaFlux packages

Scope: the packages named in the SRAMLab brief, inspected in the repository at `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`
(each module is delivered as a zip). Extracted read-only; **RTL/Python that SRAMLab depends on was run, not just read**.

## What exists and how SRAMLab uses it

| Module (package) | What it is | Used by SRAMLab as | Verified here |
|---|---|---|---|
| **SRAMCore** (P71 `silicaflux-sramcore-p71`) | `sf_sram_core`: single-port synchronous SRAM, always-accept, byte lanes, fixed read latency, bounds policy | **vendored** (`rtl/third_party/p71_sramcore`, SHA-256 manifest) — the bank | RTL compiled and simulated in Verilator on every comparison |
| **SRAMBank** (P72) | `sf_sram_bank` multi-bank wrapper, SEQ/BLOCK/XOR address maps, bank counters; same-bank conflict = lowest lane wins (not fair) | address-map semantics reflected in the interleave option (`low`/`high`); fairness is the controller's job | documentation only (not simulated) |
| **SRAMController** (P73 `silicaflux-sramcontroller-p73`) | `sf_sram_controller` + `sf_sram_subsystem`: SFB2 request/response, per-bank round-robin (+optional 2-class priority), credits (`MAX_OUT`), bank-lock/`UNIFORM_LAT`, trackers, response FIFOs, flush, 112 hardware counters | **vendored; this is the RTL the simulator is a model of** (`rtl/third_party/p73_sramcontroller`) | **253/253 cases cycle-identical** model vs RTL, see `docs/03_verification.md` |
| **SRAMFabric** (P74) | SFB3 target adapter / NoC bridge around the memory | read for the NoC-interface question (area/phys); not simulated | read only |
| **TensorScratch** (P75) | A/B operand buffers + accumulator + DMA fill on single-port banks; 8 operands/cycle conflict-free | architecture reproduced as the *direct-feed* tensor model; its committed claims used as context | not re-run (its own regression is 503/503 per its report) |
| **VectorScratch** (P76) | wide vector scratchpad (alignment split/merge, bank scheduler); committed `reports/bench.csv` (613 RTL-simulation rows) | **imported** `bench.csv` as RTL-measured reference; SRAMLab's alignment/bank-slot arithmetic is checked against it: **76/76 rows cycle-exact** | `studies/vector.py::p76_crosscheck`, test `test_p76_rtl_crosscheck_exact` |
| **ECCMemory** (MemoryCore `sf_ecc_*`, `sf_sram_bank` SECDED + RMW + scrub) | SECDED(39/72/137), atomic partial-write RMW, scrubber, counters | ECC study RTL (see `docs/ecc.md`) | see ECC study |
| **MemoryTest** (P78) + MemoryCore `sf_sram_mbist_ctl` | March C-/MATS+ BIST FSM, fault-injection models, coverage campaign | MBIST study RTL (see `docs/mbist.md`) | see MBIST study |
| **SRAMMacroBridge** (MemoryCore `sf_sram_macro_wrapper`, SRAMLib backends) | macro wrapper; SRAM Wrapper Library with **real open-PDK macro manifests** (SKY130 OpenRAM, IHP SG13G2, GF180MCU) | manifests vendored under `data/macros/` (real W×H, area, timing) | see physical analysis |
| **BandwidthLab** | Python event simulator of SilicaFlux-V (crossbar, banks, DMA, tensor/vector engines); `ANALYTICAL_CEILING / EVENT_SIMULATED / RTL_OBSERVED` classes | design reference for the three-layer separation; not imported (different system) | not executed |
| **PowerGrid** (`powerfabric-p36`) | UPF/PDN + static IR/EM analysis | context only: its SRAM load model uses access×energy and notes **the SRAM Liberty gives 0 W** | not executed |
| **TimingFlow** | STA framework (Yosys/OpenSTA/OpenROAD); real vendor-Liberty IHP SRAM clk→DOUT/setup/hold | macro timing numbers (labelled *targets from Liberty, not measured silicon*) | OpenSTA/OpenROAD not installable here |
| **FloorplanLab** | ORFS-driven floorplans; parsed LEF macro sizes | cross-check of macro dimensions (IHP 2048×64 = 784.48×626.70 µm matches the manifests) | not executed |
| **ThermalLab** | 3-D finite-volume thermal solver; block-power CSV/JSON input schema | hand-off file format only; **all of its inputs are demonstration/assumed** | not executed |
| **MemoryCore `tools/sramlab`** (earlier) | cycle model of the *MemoryCore* controller (16 B lines, ECC in bank) + energy model with **assumed** parameters + dashboard | functioning, 67 tests pass here; **models a different controller** than P73, so SRAMLab does not import it. Its `params_assumed.json` energies are **not** used as results | `python3 -m unittest discover` → 67 tests OK (1 skipped) |

## Findings that shaped the design

1. **No package contains SRAM energy-per-access.** BandwidthLab (PowerLink pJ: "source: assumption"), PowerGrid ("SRAM Liberty gives 0 W"), MemoryCore (`params_assumed.json`: every value labelled "ASSUMPTION") — nothing is a characterised number. SRAMLab therefore ships **no default pJ values**; energy is `unavailable` until a validated profile with provenance and operating conditions is supplied. Parameter-free *activity* figures (accesses, bit activations, toggles) are always produced.
2. **Real technology data that does exist:** macro dimensions/area (IHP/SKY130/GF180 manifests, LEF-derived), clock→DOUT / setup / hold for IHP macros (Liberty-derived, TimingFlow). No Liberty/LEF for the *SilicaFlux target process*; no silicon, FPGA or board measurement anywhere.
3. **Timing frequencies in the repository are targets or derived estimates** (SDC 20 ns; derived Fmax figures), none measured. SRAMLab reports cycles and only shows MB/s under an explicit `assumed` clock.
4. **Overstatements found in sibling READMEs** (reported, not repeated): FloorplanLab "14 runs pass all 15 gates" while 13 of 14 have global-routing overflow; PowerGrid "TensorCore corner has the largest drop" holds in only one of two variants; BandwidthLab "within 1 cycle" for tensor/vector vs its own open-issues file (up to 50 % on short vectors); TimingFlow manifest claims a `runs/` tree that is absent from the archive; the TENSORCORE-10 package has no TC09/TC10 RTL (TC08 is the unit).
5. **Tooling:** Verilator and Yosys are not preinstalled. SRAMLab uses `pip install verilator yowasp-yosys`. The pip Verilator wheel ships with an empty `CFG_CXXFLAGS_PCH_I`, which breaks the C++ build with gcc (precompiled header passed as a bare input); SRAMLab passes `-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include` (harmless on a normal install). OpenROAD/OpenSTA are **not** available (`pip openroad` is a 0.0.1 placeholder), so no STA or P&R result is claimed.

## What was reused vs built

* Reused unmodified: SRAMCore + SRAMController RTL (vendored with checksums), macro manifests, VectorScratch benchmark CSV, ECC/MBIST RTL (vendored by the study modules).
* Built new: configuration/validation layer, cycle-accurate controller model, Verilator comparison harness and verification matrix, workload generators, metrics/statistics, tensor/vector studies, optimiser, reproducibility records, CLI, dashboard, reports.
* Deliberately **not** reused: the earlier MemoryCore `sramlab` (different controller) and every assumed-energy parameter.
