# 05 — Limitations and what is not claimed

* **No hardware measurements.** No SilicaFlux silicon, FPGA or board data exists. Nothing is labelled `measured`.
* **Cycles, not seconds.** The model is exact for the *implemented protocol*; no clock is claimed. MB/s figures appear only under an explicit `physical.clock_mhz` (labelled *assumed*).
* **Model scope.** The simulator reproduces `sf_sram_subsystem` (P73 controller + P71 banks). It does not model the P75 TensorScratch / P76 VectorScratch RTL internals; the tensor
  study is a closed-loop *architecture-level* model on the verified controller, the vector study decomposes accesses into controller transactions and is cross-checked (not co-simulated) against the P76 RTL-simulation results.
* **Not exercised in the RTL comparison:** `src_en`/source-ID mismatch statuses, bank-reported errors (unreachable with `sf_sram_core`), counter wrap at 2^32.
* **Energy / power.** No SRAM energy-per-access exists anywhere in the repository. SRAMLab ships no default energies; without a validated profile only parameter-free activity figures are produced. The activity proxy
  (array bits activated per useful byte) is independent of bank size and cannot rank bank organisations.
* **Area.** Die area is reported only from real macro manifests (and mapped logic only with a real library). Yosys *generic* gate counts are not area. The only library fetched is Nangate45 (open educational 45 nm):
  its numbers are not transferable to the SilicaFlux target process. Without data the value is `unavailable`.
* **Timing.** OpenSTA/OpenROAD are not installable in this environment; no STA, placement or routing result is produced. Macro clock→DOUT numbers (Liberty-derived by TimingFlow) are targets, not measurements.
* **Thermal.** Hand-off files in ThermalLab's input schema only; ThermalLab was not run and every thermal figure would be uncalibrated. No die temperature is claimed.
* **MBIST.** Coverage figures are coverage of an *injected simulation fault model*; they are not manufacturing/physical defect coverage. Parallel-bank testing is an analytical model unless the RTL implements it.
* **R.** Statistics are computed in Python; `sramlab rstats` recomputes them in base R (4.3.3 here) from the raw simulation output and also runs two
  R-only analyses (Kruskal–Wallis, log-log elasticity). Without `Rscript` the check reports *unavailable*; it never substitutes Python numbers.
* **Simulators.** Every `rtl_simulated` number depends on a simulator. Verilator 5.020 mis-simulates three testbench patterns (`docs/03_verification.md`,
  *Harness portability*); SRAMLab works around them and cross-checks against Icarus 12 (`sramlab xsim`, `rtlcheck --icarus`). Agreement of two
  simulators is evidence against simulator defects, not a proof that the RTL is correct. The P78 real-stack testbench (`tb_mbist_memorycore`) is
  reported as-is: on 5.020 its default and `-O3` builds miss the CFST fault, `-O0` detects it.
* **TensorCore stream on the RTL.** The TC08 chunked command stream is in the RTL matrix only at a scaled size (M = N = 8, K = 16; 512 B) that fits the
  small RTL-matrix memories; the full-size study runs on the verified model. The direct-feed (P75 TensorScratch) architecture is modelled, not co-simulated.
* **Verilator packaging.** The pip Verilator wheel needs `-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include`; it is applied only when `verilated.mk` has the empty setting.
