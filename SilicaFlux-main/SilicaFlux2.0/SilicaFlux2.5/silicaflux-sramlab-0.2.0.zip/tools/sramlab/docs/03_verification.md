# 03 — Verification

All results in this document were re-produced on **Verilator 5.020 (Debian 5.020-1), Icarus Verilog 12.0, Yosys 0.33 and R 4.3.3**
(Ubuntu 24.04 packages). The Project 80 datasets had been produced on Verilator 5.49; on 5.020 that code failed 16 of its own tests
(see *Harness portability* below). Every committed dataset in `data/` was regenerated on the toolchain above.

| check | method | result |
|---|---|---|
| **Simulator vs RTL consistency** | `sramlab rtlcheck`: identical per-master scripts and response back-pressure replayed in the Python model and in Verilator on `sf_sram_subsystem` (with the RTL's embedded `SFC_ASSERT` checkers enabled). Compared: per-cycle `req_ready`, `rsp_valid/ready`, bank issue mask, `idle`, every response (id, type, status, read data) and **all hardware performance counters**, plus the RTL's derived configuration (`UNIFORM_EFF`, `BANK_OUT_EFF`, latency extremes) | **275/275 cases identical** over 198,824 cycles, 340,788 transactions and 34,568 counter values — 23 parameter sets × 12 workloads (2–16 banks, 1–16 masters, 8–128-bit words, latencies 1–4 incl. non-uniform, low/high interleave, non-power-of-two depth, priority arbitration, MASK_MODE aligned, tiny ID space, forced bank-lock). The 253 Project 80 cases reproduce; the 22 new ones replay the TensorCore TC08 command stream (scaled to 512 B; skipped where the memory is smaller) |
| **Second RTL simulator (controller)** | `sramlab rtlcheck --icarus`: the same scripts on an independently written Icarus testbench (`rtl/tb/ivl_ctl/`) driving the same pass-through top | **112/112 cases: Python model = Verilator = Icarus**, cycle-for-cycle and counter-for-counter |
| **Second RTL simulator (ECC / MBIST testbenches)** | `sramlab xsim`: ECC codec, ECC bank (latency, throughput, RMW, scrub, fault injection) and MBIST (cycle counts, injected faults, traffic, coverage mode) testbenches run with byte-identical inputs under Verilator and Icarus; every tagged result line compared | **9/9 cases identical, 87,411 tagged result lines** (`data/xsim_verification.json`), incl. the exhaustive 4×8 MBIST coverage campaign (10,088 faults × 7 configurations) |
| error / flush paths | seeded injection of misaligned, out-of-range, zero-strobe and poisoned requests; `flush` pulses | identical, incl. `ALIGN/RANGE/MASK/POISON/ID/CANCEL` statuses |
| **Negative controls** | (1) the model comparison is re-run against 4 deliberately broken models (fixed-priority arbiter, bank-lock dropped, latency+1, mis-counted conflicts); (2) the Icarus path against a fixed-priority arbiter; (3) `xsim` rebuilds the MBIST testbench *without* the Verilator workaround (defect B) | (1) **4/4 detected**; (2) detected; (3) on 5.020 the outputs then **differ** (Verilator 567 cycles vs Icarus 195 for one March C- bank) — the cross-check can fail and the workaround is necessary |
| Counter accuracy | RTL counters = model counters in every case above; documented RTL figures (0.50 / 1.00 / 2.00 / ~3.99 txn/cycle, `L+1` latency, `MAX_OUT/(L+1)` credit limit, `1/(HP_LIMIT+1)` LOW-class floor, bank-lock cost) reproduced by `tests/test_controller.py` independently of the RTL runs | pass |
| Data integrity | a *flat* byte-addressed oracle replays accepted requests in accept order and checks every read (knows nothing about banks, so mapping/aliasing bugs show) | 0 errors; the oracle is itself shown able to fail |
| Workload generation | determinism by seed, legality (aligned, in-range, non-zero strobes), master-stream independence, pattern semantics (stride, single-bank contention), alignment arithmetic | `tests/test_workloads_stats.py` |
| Configuration validity | 15 illegal configurations rejected with the RTL-matching reason; all problems reported at once | `tests/test_config.py` |
| **Statistical calculations** | Python unit tests (hand-computed CIs, CI coverage ≈ nominal over 400 trials, percentile/Spearman/elasticity/Pareto) **and** `sramlab rstats`: raw per-transaction output re-analysed in base R (quantile type 7, exact `qt()`, `cor(method="spearman")`) | **305/305 quantities agree** (per-replication values exactly; CI half-widths to 1.2e-12 relative). The check found that Project 80's t table (3 decimals; 0.087 % error at df = 40) was coarser than documented (CI half-widths then differed from R by up to 1.6e-4): replaced by R-exact values and a Cornish–Fisher expansion (≤ 1.1e-7) |
| Vector arithmetic vs RTL | alignment word counts and bank-slot cycle model vs the imported VectorScratch RTL bench | **76/76 rows cycle-exact**, 76/76 word counts; corrupted input is detected |
| Reproducibility | identical result hashes on re-run; different seed → different hash | `sramlab verify-repro`, `tests/test_studies_cli.py` |

Problems found *by* this verification and fixed (kept as regression tests):

* Project 80: the 64-bit `BANK_LATS` parameter was truncated to 32 bits by Verilator's `-G` parser (fixed by a sized hex literal; the harness
  reports the RTL's *effective* configuration, which the comparator requires to match the model); a build-cache key that ignored the exact `-G` strings.
* This revision: the three Verilator 5.020 simulation defects below; the t-quantile accuracy above; a P78-caveat observation that was hard-coded
  ("5.020 is not installed here") instead of computed — on 5.020 P78's warning *is* reproduced (default and `-O3` builds of P78's real-stack testbench
  miss the CFST fault; `-O0` detects it), and the report now states what the installed Verilator does.

**Not covered by the RTL comparison** (stated, not hidden): `src_en` / source-ID mismatch (`SFC_ST_SRC`) and bank-reported errors (`SFC_ST_BANK`, unreachable with `sf_sram_core`); multi-cycle masters that withdraw requests
(forbidden by SFB2 R2); `PERF` counter wrap at 2³².

## Harness portability

Running Project 80 unchanged on the Ubuntu 24.04 toolchain gave **16 failed / 275 passed / 10 skipped** tests (it reports all passing on
Verilator 5.49): RTL-vs-model 0/2 on the quick subset, every ECC codec vector wrong, MBIST start-to-done cycle counts growing across runs. None
of these were RTL bugs; all were **simulator defects in Verilator 5.020's `--timing` mode** triggered by the testbenches. Each was isolated to a
minimal reproducer, worked around, and the workaround is now *checked* by running the same stimulus on Icarus.

| | symptom | minimal reproducer (Verilator 5.020 `--binary --timing`) | handling |
|---|---|---|---|
| **defect A** | ECC codec testbench: decoder output inconsistent with its input for every vector | a variable written as a **`$fscanf` output argument** in a timed `initial` block does not re-trigger the combinational logic that reads it: `rc = $fscanf(fd, "%d %d", a, m); #1` → `y = a + 1` keeps its previous value (second read gives `y=6`, expected `10`); an ordinary assignment works | `$fscanf` targets are temporaries copied by ordinary assignments (`tb_sramlab_ecc_codec.sv`, `tb_sramlab_mbist_run.sv`) |
| **defect B** | MBIST: `t_start` stays 0, so start-to-done cycles = absolute simulation time (2,911 instead of 195 for the first run) | a variable written **both** by a task of the timed `initial` process and by a clocked `always` block is mis-optimised: `t_done <= cyc` in `always @(posedge clk)` is lost after `rst()` sets `t_done = 0` (Icarus and Verilator `-O0` correct; blocking assignments do not help) | the **post-life / localisation passes** are disabled for the `--timing` study testbenches: `-fno-life-post -fno-localize` (each alone fixes the reproducer); `sramlab.studies.ecc.VL_TIMING_WORKAROUND`, part of the build-cache key |
| **defect C** | controller testbench: master 1 reads row 7 but the bank receives row 0 (`d_row[1]` = 0 while `m_req_addr` = 0x70); with `-O0` no access is issued at all | the controller's `always_comb` decode (per-master unpacked arrays computed from slices of a wide packed input) is not re-evaluated after the timed `initial` block changes the inputs; not fixed by `-fno-life-post`/`-fno-localize`/`-O0`; variable part-select writes alone do not reproduce it | the controller harness is now **C++-driven** (`rtl/tb/vl_ctl/`: pass-through top + `sim_ctl.cpp` calling `eval()`), the canonical Verilator flow with no `--timing` dependency; plus an independently written **Icarus testbench** (`rtl/tb/ivl_ctl/`) for the three-way check |

Other portability fixes: the Verilator controller build needs `--unroll-count 1024 --unroll-stmts 1000000` on 5.020 for the 16×16 configuration
(the RTL's embedded fairness checker loops over `NUM_BANKS*NUM_MASTERS` array NBAs, `BLKLOOPINIT` otherwise); the pip-wheel `-MAKEFLAGS
CFG_CXXFLAGS_PCH_I=-include` override is applied only when `verilated.mk` actually has the empty setting; Verilator parses any comment that
begins with `// Verilator` as a pragma (a comment in the codec testbench broke the build); the study testbenches were made Icarus-12 compatible
(no `continue`, no task `return`, no array-literal initialiser, no `$fscanf` into indexed array elements) without changing their behaviour.

**Why a second simulator, not just the fix.** Each defect produced plausible-looking numbers with no error message. A `rtl_simulated` value is
only as trustworthy as the simulator that produced it, so SRAMLab now requires agreement between two independent simulators (and the model, for
the controller), and the negative control shows that the comparison detects a defect when one is present.
