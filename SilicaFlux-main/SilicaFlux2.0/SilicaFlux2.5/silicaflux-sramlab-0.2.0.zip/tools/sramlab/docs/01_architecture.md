# 01 — Software architecture

```
                         configs/*.yaml|json ──► config.py  (schema, defaults, validation: every problem at once)
                                                     │
        ┌────────────────────────────────────────────┼─────────────────────────────────────────────┐
        │ MODEL layer (analytical)                   │ SIMULATION layer                            │ MEASURED-RESULT layer
        │ metrics.analytical_ceilings                │ sim/controller.py  cycle-accurate model of  │ rtlrun.py / verify.py  Verilator runs of the
        │ closed-form array / credit / random-access │   sf_sram_subsystem (arb, credits, bank-lock,│   real RTL (tb_sramlab_ctl.sv), trace + 112
        │ ceilings, ECC/MBIST op-count models        │   trackers, FIFOs, flush, 112 HW counters)  │   counters compared cycle by cycle
        │                                            │ sim/driver.py  masters, SFB2 hold semantics, │ data/imported/*  committed RTL-simulation
        │                                            │   transaction log, flat-memory data oracle   │   reports of sibling packages (VectorScratch)
        │                                            │ sim/workloads.py + streams.py + tensor.py    │ synth/*, data/macros/*  Yosys + real macro
        │                                            │ studies/*  vector, tensor, ECC, MBIST        │   manifests (synthesized / vendor data)
        └────────────────────────────────────────────┴──────────────┬──────────────────────────────┘
                                                                     ▼
              experiments.py (run, replicate, sweep, compare) ─► stats.py (t-CI, bootstrap, sample size, sensitivity)
                                                                     ▼
                      optimise.py (goals A–E, Pareto)      record.py (reproducibility record + raw export)
                                                                     ▼
                          report.py ─► reports/*.md, data/*.json|csv ─► dashboard/ (self-contained HTML)
                          cli.py    ─► `sramlab <command>`
```

**Layer separation is enforced in the data, not just in the code.** Every value that reaches a report or the dashboard carries a
provenance label (`analytical | simulated | rtl_simulated | synthesized | measured | assumed | unavailable`, `provenance.py`). Analytical
ceilings live under their own `analytical` key next to simulated results and are never averaged with them.

## Components

| path | role |
|---|---|
| `sramlab/config.py` | YAML/JSON experiment schema, defaults, validation (limits mirror the RTL elaboration checks), JSON-Schema export |
| `sramlab/sim/controller.py` | register-transfer transcription of `sf_sram_controller` + `sf_sramc_bank` + `sf_sram_core` timing; `step()` = one clock cycle |
| `sramlab/sim/driver.py` | master driver (request holding, ID/src rules, seeded response back-pressure), `TxLog`, flat-memory integrity oracle |
| `sramlab/sim/workloads.py`, `streams.py` | deterministic generators (11 kinds); DMA bursts, vector word-splitting with alignment/partial strobes |
| `sramlab/sim/tensor.py` | closed-loop TensorCore (4×4 INT8, output-stationary) fed from banked SRAM + DMA + accumulator write-back |
| `sramlab/rtlrun.py`, `rtl/tb/tb_sramlab_ctl.sv` | Verilator build (cached), closed-loop RTL testbench, trace/counter comparison |
| `sramlab/verify.py` | 23 parameter sets × 11 workloads (illegal-request injection, flush) matrix + negative-control mutations |
| `sramlab/metrics.py`, `stats.py` | metrics with provenance, ceilings, replication statistics |
| `sramlab/studies/` | vector (+ P76 RTL cross-check), tensor, ECC, MBIST |
| `sramlab/synth.py`, `tech.py`, `phys.py`, `power.py`, `thermal.py` | Yosys flows + report parsing, technology/macro data, area, power provenance, ThermalLab hand-off |
| `sramlab/optimise.py` | goals A–E, ties made explicit, Pareto front |
| `sramlab/record.py` | experiment records (ID, git revision, tool versions, host, seed, workload, clock/tech assumptions, counters, hashes) |
| `rtl/third_party/` | vendored reference RTL, byte-identical, `SHA256SUMS`, `PROVENANCE.md` |

## Experiment ID and reproducibility

`EXP-<UTC time>-<config hash[:8]>`; each record stores `config_hash` and `result_hash` (SHA-256 of the deterministic result payload). Workload
randomness uses a frozen SplitMix64 generator (not numpy streams), so a seed reproduces the exact requests on any machine;
`sramlab verify-repro CONFIG` demands identical result hashes on re-run.
