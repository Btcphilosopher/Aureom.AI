"""Yosys synthesis of the controller: pure parser tests on captured reports + live runs (small configurations, cached).

The captured samples below are verbatim ``stat`` outputs of Yosys 0.71 (Project 80's environment) for
``sf_sram_controller`` NUM_BANKS=2 NUM_MASTERS=2 PERF_EN=0 (generic, and mapped to the pinned Nangate45 Liberty).
Hand-written fixtures are marked FIXTURE.  Live tests use sramlab/.cache so reruns are fast.
"""
import csv
import json
import os

import pytest

from sramlab import synth, tech, tools
from sramlab.synth import YosysParseError, parse_check, parse_ltp, parse_yosys_stat, parse_yosys_stat_json

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(tools.ROOT, "data", "synth")

SAMPLE_GENERIC = '\n9. Printing statistics.\n\n=== sf_sram_controller ===\n\n        +----------Local Count, excluding submodules.\n        | \n      563 wires\n     1841 wire bits\n      177 public wires\n     1359 public wire bits\n       36 ports\n      457 port bits\n      927 cells\n       28   $_ANDNOT_\n      236   $_AND_\n       24   $_DFFE_PN0P_\n       48   $_DFFE_PP_\n      136   $_MUX_\n      261   $_NAND_\n       30   $_NOR_\n       23   $_NOT_\n        5   $_ORNOT_\n       40   $_OR_\n       66   $_SDFFCE_PP0P_\n       12   $_XNOR_\n       12   $_XOR_\n        6   $scopeinfo\n\n'

SAMPLE_MAPPED = "\n14. Printing statistics.\n\n=== sf_sram_controller ===\n\n        +----------Local Count, excluding submodules.\n        |        +-Local Area, excluding submodules.\n        |        | \n      885        - wires\n     1340        - wire bits\n       60        - public wires\n      511        - public wire bits\n       36        - ports\n      457        - port bits\n      928 1.55E+03 cells\n       73   77.672   AND2_X1\n        5     6.65   AND3_X1\n        8    10.64   AOI211_X1\n       13   13.832   AOI21_X1\n      173   230.09   AOI22_X1\n       24   127.68   DFFR_X1\n      114  515.508   DFF_X1\n      128   68.096   INV_X1\n      123  229.026   MUX2_X1\n       50     39.9   NAND2_X1\n       17   18.088   NAND3_X1\n        6     7.98   NAND4_X1\n       87   69.426   NOR2_X1\n       11   11.704   NOR3_X1\n       13    17.29   NOR4_X1\n        8    10.64   OAI211_X1\n       44   46.816   OAI21_X1\n        1     1.33   OAI22_X1\n        1    1.862   OAI33_X1\n        9    9.576   OR2_X1\n        2     2.66   OR3_X1\n        4    6.384   OR4_X1\n        9   14.364   XNOR2_X1\n        5     7.98   XOR2_X1\n\n   Chip area for module '\\sf_sram_controller': 1545.194000\n     of which used for sequential elements: 643.188000 (41.63%)\n\n"

# FIXTURE: older Yosys layout ("Number of cells:"), with a latch
SAMPLE_OLD = """
=== top ===

   Number of wires:                 10
   Number of wire bits:             20
   Number of public wires:           3
   Number of public wire bits:       8
   Number of memories:               0
   Number of memory bits:            0
   Number of processes:              0
   Number of cells:                  7
     $_AND_                          2
     $_DFF_P_                        3
     $_DFFE_PN0P_                    1
     $_DLATCH_P_                     1

"""


def _need_yosys():
    if tools.yosys() is None:
        pytest.skip("yosys not installed")


def _nangate():
    r = tech.nangate45_liberty()
    if not r["available"]:
        pytest.skip("Nangate45 liberty not fetched")
    return r["path"]


# ----------------------------------------------------------------------------------------------- parser
def test_parse_generic_sample_exact_numbers():
    r = parse_yosys_stat(SAMPLE_GENERIC)
    d = r["design"]
    assert r["top"] == "sf_sram_controller"
    assert d["cells_total"] == 927 and d["scopeinfo_cells"] == 6 and d["cells"] == 921
    assert d["flip_flops"] == 24 + 48 + 66 == 138
    assert d["latches"] == 0
    assert d["cells_by_type"]["$_MUX_"] == 136 and d["area_um2"] is None


def test_parse_mapped_sample_area_and_cells():
    d = parse_yosys_stat(SAMPLE_MAPPED)["design"]
    assert d["cells_total"] == 928 and d["area_um2"] == pytest.approx(1545.194)
    assert d["sequential_area_um2"] == pytest.approx(643.188)
    assert d["cells_by_type"]["DFF_X1"] == 114 and d["cells_by_type"]["DFFR_X1"] == 24
    assert sum(d["cells_by_type"].values()) == 928
    assert d["flip_flops"] == 0          # library flop names are not generic $_DFF cells: counted from the generic report


def test_parse_old_layout_and_latch_counting():
    d = parse_yosys_stat(SAMPLE_OLD)["design"]
    assert d["cells_total"] == 7 and d["cells"] == 7
    assert d["flip_flops"] == 4 and d["latches"] == 1            # the latch is not a flip-flop


def test_corrupted_report_is_rejected_counts_do_not_add_up():
    bad = SAMPLE_GENERIC.replace("      927 cells", "      930 cells")
    with pytest.raises(YosysParseError, match="sum to 921|sum to 927"):
        parse_yosys_stat(bad)
    bad2 = SAMPLE_GENERIC.replace("      136   $_MUX_", "      999   $_MUX_")
    with pytest.raises(YosysParseError, match="corrupted"):
        parse_yosys_stat(bad2)


def test_truncated_and_malformed_reports_are_rejected():
    # truncated: the cell-type table is cut off after the count
    cut = SAMPLE_GENERIC[: SAMPLE_GENERIC.index("      927 cells") + len("      927 cells\n")]
    with pytest.raises(YosysParseError, match="no per-type table"):
        parse_yosys_stat(cut)
    # header of the block but no cell count at all
    with pytest.raises(YosysParseError, match="no cell count"):
        parse_yosys_stat("=== top ===\n\n   563 wires\n   36 ports\n")
    for junk in ("", "   \n", "garbage with no blocks", "ERROR: something failed\n"):
        with pytest.raises(YosysParseError):
            parse_yosys_stat(junk)
    with pytest.raises(YosysParseError):
        parse_yosys_stat(None)


def test_two_modules_without_design_block_is_ambiguous():
    two = SAMPLE_OLD + SAMPLE_OLD.replace("=== top ===", "=== other ===")
    with pytest.raises(YosysParseError, match="ambiguous"):
        parse_yosys_stat(two)


def test_json_report_parser_and_rejection():
    good = json.dumps({"design": {"num_cells": 5, "num_cells_by_type": {"$_AND_": 3, "$scopeinfo": 2}, "area": 12.5,
                                  "sequential_area": 4.0}})
    r = parse_yosys_stat_json(good)
    assert r["cells"] == 3 and r["cells_total"] == 5 and r["area_um2"] == 12.5
    for bad in ('{"design": {"num_cells": 9, "num_cells_by_type": {"$_AND_": 3}}}', "{not json", "{}",
                '{"design": {"num_cells": 3}}'):
        with pytest.raises(YosysParseError):
            parse_yosys_stat_json(bad)


def test_ltp_and_check_parsers():
    assert parse_ltp("Longest topological path in x (length=21):\n 0: a")["levels"] == 21
    assert "not a frequency" in parse_ltp("Longest topological path in x (length=3):")["label"]
    assert parse_ltp("nothing")["provenance"] == "unavailable"
    ok = parse_check("7.3. Executing CHECK pass\nFound and reported 0 problems.\nFound and reported 0 problems.\n")
    assert ok == {"problems": 0, "ok": True, "errors": []}
    assert parse_check("Found and reported 2 problems.")["ok"] is False
    assert parse_check("no check ran")["ok"] is False and parse_check("no check ran")["problems"] is None
    assert parse_check("Found and reported 0 problems.\nERROR: boom")["ok"] is False


# ----------------------------------------------------------------------------------------------- argument handling
def test_unknown_or_illegal_parameters_rejected(tmp_path):
    with pytest.raises(ValueError, match="unknown sf_sram_controller parameter"):
        synth.synth_controller({"NUM_BANKZ": 4}, tmp_path)
    with pytest.raises(ValueError, match="power of two"):
        synth.synth_controller({"NUM_BANKS": 3}, tmp_path)
    with pytest.raises(ValueError, match="DATA_WIDTH"):
        synth.synth_controller({"DATA_WIDTH": 24}, tmp_path)
    with pytest.raises(ValueError, match="only integer"):
        synth.synth_controller({"NUM_BANKS": "4"}, tmp_path)
    with pytest.raises(FileNotFoundError):
        synth.synth_controller({"NUM_BANKS": 2}, tmp_path, liberty=str(tmp_path / "missing.lib"))


def test_missing_yosys_is_reported_unavailable_not_faked(tmp_path, monkeypatch):
    monkeypatch.setattr(tools, "yosys", lambda: None)
    r = synth.synth_controller({"NUM_BANKS": 2}, tmp_path)
    assert r["status"] == "unavailable" and r["mapped_area_um2"]["provenance"] == "unavailable"
    assert r["generic"]["provenance"] == "unavailable"


def test_rtl_file_sets_match_rtlrun():
    try:
        from sramlab import rtlrun
    except Exception:
        pytest.skip("rtlrun not importable")
    assert [os.path.basename(f) for f in synth.SUBSYSTEM_FILES] == [os.path.basename(f) for f in rtlrun.RTL_FILES]
    for f in synth.CONTROLLER_FILES + synth.SUBSYSTEM_FILES:
        assert os.path.isfile(f)


# ----------------------------------------------------------------------------------------------- live runs
SMALL = {"NUM_BANKS": 2, "NUM_MASTERS": 2, "PERF_EN": 0}


def test_live_generic_controller_synthesis(tmp_path):
    _need_yosys()
    r = synth.synth_controller(SMALL, tmp_path)
    assert r["status"] == "ok", r.get("error")
    g = r["generic"]
    assert g["label"] == "synthesized" and g["latch_free"] and g["latches"] == 0 and g["check_assert"]["ok"]
    assert g["flip_flops"] > 0 and g["total_cells"] > g["flip_flops"]
    assert sum(g["cells_by_type"].values()) == g["total_cells"]          # scopeinfo metadata cells excluded from both
    assert "$scopeinfo" not in g["cells_by_type"]
    assert "not a frequency" in g["logic_depth"]["label"] and g["logic_depth"]["levels"] > 3
    # no library => the area is unavailable, never a number; memory bits are a separate analytical count
    assert r["mapped_area_um2"]["provenance"] == "unavailable" and r["mapped_area_um2"]["reason"] == "no technology library"
    assert r["memory_bits_analytical"] == {"value": 2 * 1024 * 32, "provenance": "analytical",
                                           "source": r["memory_bits_analytical"]["source"], "unit": "bits"}
    assert "NOT synthesized" in r["scope"] or "NOT synthesized to gates" in r["scope"]
    # no timing is ever claimed: no STA ran (and the tools are reported as found / not found, never faked)
    st = r["signoff_timing"]
    assert st["provenance"] == "unavailable" and st["value"] is None and "no static timing analysis" in st["reason"]
    assert st["opensta"] == (tools.opensta() is not None) and st["openroad"] == (tools.openroad() is not None)
    pr = synth.portable(r)                                       # what is persisted: nothing machine-specific
    assert pr["run_dir"].startswith("runs/") and "exe" not in pr["yosys"]
    for a in ("script.ys", "stat_generic.txt", "stat_generic.json", "ltp.txt", "result.json", "yosys.log.gz"):
        assert os.path.isfile(os.path.join(r["run_dir"], a)), a


# Regression pins per Yosys version (gate counts move with the Yosys version; flip-flops and latches must not).
# 0.71 = yowasp wasm build used by Project 80; 0.33 = Ubuntu 24.04 package used by 0.2.0.
GOLDEN_GENERIC = {"0.71": (921, 138, 0, 21), "0.33": (976, 138, 0, 25)}
GOLDEN_MAPPED = {"0.71": (1545.194, 928), "0.33": (1566.74, 939)}
_YV = (tools.yosys() or {}).get("version")


@pytest.mark.skipif(_YV not in GOLDEN_GENERIC, reason=f"no golden numbers for Yosys {_YV}")
def test_golden_numbers_per_yosys_version(tmp_path):
    r = synth.synth_controller(SMALL, tmp_path)
    g = r["generic"]
    assert (g["total_cells"], g["flip_flops"], g["latches"], g["logic_depth"]["levels"]) == GOLDEN_GENERIC[_YV]


def test_flip_flop_count_is_yosys_version_independent():
    # the register count is a property of the RTL, not of the optimiser: every pinned version must agree
    assert len({v[1] for v in GOLDEN_GENERIC.values()}) == 1 and len({v[2] for v in GOLDEN_GENERIC.values()}) == 1


def test_second_call_hits_the_cache_with_identical_numbers(tmp_path):
    _need_yosys()
    a = synth.synth_controller(SMALL, tmp_path)
    b = synth.synth_controller(dict(SMALL), tmp_path / "other")
    assert b["cached"] is True and a["cache_key"] == b["cache_key"]
    assert a["generic"]["total_cells"] == b["generic"]["total_cells"]
    assert os.path.isfile(os.path.join(b["run_dir"], "result.json"))          # cached runs are re-materialised in the outdir
    c = synth.synth_controller({**SMALL, "NUM_BANKS": 4}, tmp_path)
    assert c["cache_key"] != a["cache_key"]


def test_more_banks_means_more_logic_and_perf_counters_dominate(tmp_path):
    _need_yosys()
    b2 = synth.synth_controller({"NUM_BANKS": 2, "NUM_MASTERS": 2, "PERF_EN": 0}, tmp_path)["generic"]["total_cells"]
    b4 = synth.synth_controller({"NUM_BANKS": 4, "NUM_MASTERS": 2, "PERF_EN": 0}, tmp_path)["generic"]["total_cells"]
    p4 = synth.synth_controller({"NUM_BANKS": 4, "NUM_MASTERS": 2, "PERF_EN": 1}, tmp_path)["generic"]["total_cells"]
    assert b2 < b4 < p4


def test_live_liberty_mapped_area_nangate45(tmp_path):
    _need_yosys()
    lib = _nangate()
    r = synth.synth_controller(SMALL, tmp_path, liberty=lib)
    assert r["status"] == "ok", r.get("error")
    a = r["mapped_area_um2"]
    assert a["provenance"] == "synthesized" and a["unit"] == "um^2" and a["value"] > 0
    assert a["technology"] == tech.NANGATE45_TECH_LABEL and "NOT the SilicaFlux target process" in a["technology"]
    assert a["scope"] == "controller logic only"
    m = r["mapped"]
    assert m["unmapped_cells"] == {} and m["liberty_sha256"] == tech.nangate45_liberty()["sha256"]
    assert 0 < m["sequential_area_um2"] < a["value"]
    assert all(not k.startswith("$") for k in m["cells_by_type"])
    # the mapped design has the same number of flip-flops as the generic one (every $_DFF* was mapped to a library flop)
    ffs = sum(n for k, n in m["cells_by_type"].items() if k.startswith(("DFF", "SDFF")))
    assert ffs == r["generic"]["flip_flops"]
    # gate counts of the generic result are still present next to it (both result sets)
    assert r["generic"]["total_cells"] > 0


@pytest.mark.skipif(_YV not in GOLDEN_MAPPED, reason=f"no golden numbers for Yosys {_YV}")
def test_golden_mapped_area_per_yosys_version(tmp_path):
    lib = _nangate()
    r = synth.synth_controller(SMALL, tmp_path, liberty=lib)
    area, cells = GOLDEN_MAPPED[_YV]
    assert r["mapped_area_um2"]["value"] == pytest.approx(area, abs=1e-6)
    assert r["mapped"]["cells"] == cells


def test_integrated_subsystem_top_synthesizes_with_small_depth(tmp_path):
    _need_yosys()
    r = synth.synth_subsystem({"NUM_BANKS": 2, "NUM_MASTERS": 2, "BANK_DEPTH": 8, "PERF_EN": 0}, tmp_path)
    assert r["status"] == "ok", r.get("error")
    assert r["top"] == "sf_sram_subsystem" and "NOT an SRAM macro" in r["scope"]
    assert r["generic"]["latches"] == 0 and r["generic"]["check_assert"]["ok"]
    # the 2 x 8 x 32 = 512 array bits became flip-flops on top of the controller's own
    ctl = synth.synth_controller({"NUM_BANKS": 2, "NUM_MASTERS": 2, "PERF_EN": 0, "BANK_DEPTH": 8, "BANK_OUT": 2,
                                  "UNIFORM_LAT": 1}, tmp_path)["generic"]["flip_flops"]
    assert r["generic"]["flip_flops"] >= ctl + 512


def test_failed_yosys_run_reports_the_error_and_is_not_cached(tmp_path):
    _need_yosys()
    # NUM_BANKS=1 is legal for the controller; DATA_WIDTH not a multiple of the lane width fails elaboration in sf_sram_core
    # so use a deliberately illegal subsystem parameter: BANK_DEPTH=1 (RTL requires >= 2)
    r = synth.synth_subsystem({"NUM_BANKS": 2, "NUM_MASTERS": 2, "BANK_DEPTH": 1, "PERF_EN": 0}, tmp_path)
    assert r["status"] == "failed" and r["error"]
    assert r["generic"]["provenance"] == "unavailable" and r["mapped_area_um2"]["provenance"] == "unavailable"
    again = synth.synth_subsystem({"NUM_BANKS": 2, "NUM_MASTERS": 2, "BANK_DEPTH": 1, "PERF_EN": 0}, tmp_path)
    assert again["cached"] is False


def test_sweep_writes_csv_and_json_both_modes(tmp_path):
    _need_yosys()
    res = synth.synth_sweep(banks=(2,), masters=(2,), max_out=(1,), perf=(0,), outdir=tmp_path, jobs=1)
    assert len(res) == 1 and res[0]["status"] == "ok"
    rows = list(csv.DictReader(open(tmp_path / "controller_sweep_generic.csv")))
    assert rows[0]["banks"] == "2" and rows[0]["mapped_area_um2"] == "" and int(rows[0]["cells"]) > 0
    doc = json.load(open(tmp_path / "controller_sweep_generic.json"))
    assert doc["label"] == "synthesized" and "NOT synthesized" in doc["scope"] and doc["technology"] is None
    assert "no technology library" in doc["area_note"] and "not a frequency" in doc["depth_note"]
    assert doc["signoff_timing"]["provenance"] == "unavailable"
    assert doc["results"][0]["run_dir"].startswith("runs/")
    lib = _nangate()
    synth.synth_sweep(banks=(2,), masters=(2,), max_out=(1,), perf=(0,), outdir=tmp_path, liberty=lib, jobs=1)
    rows2 = list(csv.DictReader(open(tmp_path / "controller_sweep_nangate45.csv")))
    assert float(rows2[0]["mapped_area_um2"]) > 0 and rows2[0]["cells"] == rows[0]["cells"]
    doc2 = json.load(open(tmp_path / "controller_sweep_nangate45.json"))
    assert doc2["technology"] == tech.NANGATE45_TECH_LABEL


# ----------------------------------------------------------------------------------------------- committed result sets
@pytest.mark.skipif(not os.path.isfile(os.path.join(DATA, "controller_sweep_nangate45.csv")), reason="sweep not generated")
def test_committed_sweeps_are_consistent_and_complete():
    gen = list(csv.DictReader(open(os.path.join(DATA, "controller_sweep_generic.csv"))))
    nan = list(csv.DictReader(open(os.path.join(DATA, "controller_sweep_nangate45.csv"))))
    assert len(gen) == len(nan) == 8
    for g, n in zip(gen, nan):
        assert g["status"] == n["status"] == "ok"
        assert (g["banks"], g["perf"], g["cells"], g["flip_flops"]) == (n["banks"], n["perf"], n["cells"], n["flip_flops"])
        assert g["mapped_area_um2"] == "" and float(n["mapped_area_um2"]) > 0       # both modes kept: no liberty => no area
        assert g["latches"] == "0" and g["check_ok"] == "True"
    by = {(int(r["banks"]), int(r["perf"])): int(r["cells"]) for r in gen}
    for p in (0, 1):
        assert by[(2, p)] < by[(4, p)] < by[(8, p)] < by[(16, p)]
    for b in (2, 4, 8, 16):
        assert by[(b, 0)] < by[(b, 1)]                                              # performance counters cost logic


def test_liberty_cell_parser_and_sequential_area_fallback(tmp_path):
    lib = _nangate()
    info = synth.liberty_cells(lib)
    assert info["DFF_X1"]["sequential"] and not info["NAND2_X1"]["sequential"]
    assert info["DFF_X1"]["area"] > info["NAND2_X1"]["area"] > 0
    # fallback only accepted when the Liberty-summed total equals the Yosys chip area
    res = {"mapped": {"cells_by_type": {"DFF_X1": 2, "NAND2_X1": 3}, "sequential_area_um2": None},
           "mapped_area_um2": {"value": 2 * info["DFF_X1"]["area"] + 3 * info["NAND2_X1"]["area"]}}
    synth._fill_sequential_area(res, lib)
    assert res["mapped"]["sequential_area_um2"] == pytest.approx(2 * info["DFF_X1"]["area"])
    bad = {"mapped": {"cells_by_type": {"DFF_X1": 2}, "sequential_area_um2": None}, "mapped_area_um2": {"value": 999.0}}
    synth._fill_sequential_area(bad, lib)
    assert bad["mapped"]["sequential_area_um2"] is None and "!=" in bad["mapped"]["sequential_area_source"]
