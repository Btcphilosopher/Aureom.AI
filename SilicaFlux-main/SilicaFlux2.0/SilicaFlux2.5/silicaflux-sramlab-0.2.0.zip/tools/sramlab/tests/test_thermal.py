"""Thermal hand-off (ThermalLab block schema) and the tiny analytical hotspot map.

TEST_FIXTURE_* power numbers are arbitrary and exist only in this file.
"""
import csv
import json
import os

import numpy as np
import pytest

from sramlab import phys, power, thermal
from sramlab.config import load_config

SKY = "sky130_sram_2kbyte_1rw1r_32x512_8"
LABEL = "uncalibrated model input - not a die temperature"
METRICS = {"cycles": 1000, "reads": 600, "writes": 300, "useful_bytes": 3600, "bank_accesses": [100, 200, 300, 300],
           "activity": {"array_accesses": 900, "array_bit_activations": 900 * 128, "bank_busy_cycles": 900, "data_bus_toggles": 7}}


def _cfg(banks=4):
    return load_config({"memory": {"banks": banks, "bank_depth_words": 1024, "word_width_bits": 128},
                        "physical": {"backend": "asic_macro", "macro": SKY, "clock_mhz": 100}})


@pytest.fixture(scope="module")
def fp():
    return phys.floorplan(_cfg())


def rows(path):
    with open(path, newline="") as fh:
        return list(csv.DictReader(fh))


# ----------------------------------------------------------------------------------------------- hand-off without power
def test_no_power_omits_thermallab_file_but_emits_geometry_and_activity(fp, tmp_path):
    r = thermal.thermal_handoff(fp, None, tmp_path, run_metrics=METRICS)
    assert r["thermallab_blocks"]["provenance"] == "unavailable"
    assert r["thermallab_blocks"]["reason"] == "no validated energy profile => no power"
    assert r["power"]["reason"] == "no validated energy profile => no power"
    assert sorted(os.listdir(tmp_path)) == ["block_geometry_activity.csv", "block_geometry_activity.json"]
    rs = rows(tmp_path / "block_geometry_activity.csv")
    assert [x["name"] for x in rs] == [f"SRAM_bank{i}" for i in range(4)]
    assert "power_w" not in rs[0]                                          # no power column at all when there is no power
    shares = [float(x["access_share"]) for x in rs]
    assert shares == pytest.approx([100 / 900, 200 / 900, 300 / 900, 300 / 900]) and sum(shares) == pytest.approx(1.0)
    assert [float(x["utilisation_accesses_per_cycle"]) for x in rs] == pytest.approx([0.1, 0.2, 0.3, 0.3])
    d = json.load(open(tmp_path / "block_geometry_activity.json"))
    assert d["_label"] == LABEL and "not a routed layout" in d["_geometry"]
    assert all(LABEL in x["source"] for x in rs)                           # every CSV row repeats the statement


def test_empty_power_mapping_is_also_no_power(fp, tmp_path):
    r = thermal.thermal_handoff(fp, {}, tmp_path)
    assert r["thermallab_blocks"]["provenance"] == "unavailable"
    assert not os.path.exists(tmp_path / "thermallab_blocks.csv")
    rs = rows(tmp_path / "block_geometry_activity.csv")
    assert rs[0]["accesses"] == ""                                         # no run metrics => no activity columns filled


def test_geometry_rectangles_are_the_generated_bank_regions(fp, tmp_path):
    thermal.thermal_handoff(fp, None, tmp_path)
    rs = rows(tmp_path / "block_geometry_activity.csv")
    for r, reg in zip(rs, fp["bank_regions"]):
        assert (float(r["x0_um"]), float(r["y0_um"]), float(r["x1_um"]), float(r["y1_um"])) == pytest.approx(
            (reg["x0"], reg["y0"], reg["x1"], reg["y1"]))
        assert r["zone"] == "SRAM" and r["kind"] == "cell" and r["layer"] == "active"


def test_no_geometry_no_handoff(tmp_path):
    bad = phys.floorplan(load_config({"physical": {"backend": "generic"}}))
    with pytest.raises(ValueError, match="no generated geometry"):
        thermal.thermal_handoff(bad, None, tmp_path)


# ----------------------------------------------------------------------------------------------- hand-off with power
def test_power_file_in_thermallab_schema(fp, tmp_path):
    pw = {f"SRAM_bank{i}": 0.001 * (i + 1) for i in range(4)}
    r = thermal.thermal_handoff(fp, pw, tmp_path, run_metrics=METRICS)
    assert r["power"]["total_w"] == pytest.approx(0.010)
    rs = rows(tmp_path / "thermallab_blocks.csv")
    assert list(rs[0].keys()) == ["name", "zone", "x0_um", "y0_um", "x1_um", "y1_um", "power_w", "kind", "layer", "provenance", "source"]
    assert [float(x["power_w"]) for x in rs] == pytest.approx([0.001, 0.002, 0.003, 0.004])
    assert all(x["provenance"] == "assumed_engineering_parameter" for x in rs)     # bare floats are treated as assumptions
    assert all(LABEL in x["source"] for x in rs)
    j = json.load(open(tmp_path / "thermallab_blocks.json"))
    assert j["_label"] == LABEL and len(j["blocks"]) == 4 and "NOT run" in j["_not_executed"]
    assert thermal.validate_blocks(j["blocks"]) == []                               # satisfies the documented required fields
    # the controller has no energy model: it appears in the geometry file only (when it has a rectangle at all)
    assert all(b["name"].startswith("SRAM_bank") for b in j["blocks"])


def test_power_provenance_labels_map_to_thermallab_values(fp, tmp_path):
    pw = {"SRAM_bank0": {"value": 0.001, "provenance": "simulated", "source": "counts x datasheet"},
          "SRAM_bank1": {"value": 0.001, "provenance": "assumed", "source": "assumption"},
          "SRAM_bank2": {"value": 0.001, "provenance": "synthesized", "source": "vendor estimate"},
          "SRAM_bank3": 0.001}
    thermal.thermal_handoff(fp, pw, tmp_path)
    rs = {x["name"]: x for x in rows(tmp_path / "thermallab_blocks.csv")}
    assert rs["SRAM_bank0"]["provenance"] == "user_supplied_data" and "counts x datasheet" in rs["SRAM_bank0"]["source"]
    assert rs["SRAM_bank1"]["provenance"] == "assumed_engineering_parameter"
    assert rs["SRAM_bank2"]["provenance"] == "eda_derived_data"
    assert "laboratory_measurement" not in {x["provenance"] for x in rs.values()}   # never claimed without a measured label


def test_partial_power_is_refused_not_silently_cold(fp, tmp_path):
    r = thermal.thermal_handoff(fp, {"SRAM_bank0": 0.001, "SRAM_bank1": 0.002}, tmp_path)
    assert r["thermallab_blocks"]["provenance"] == "unavailable" and "SRAM_bank2" in r["thermallab_blocks"]["reason"]
    assert not os.path.exists(tmp_path / "thermallab_blocks.csv")
    assert os.path.exists(tmp_path / "block_geometry_activity.csv")


def test_invalid_inputs_are_rejected(fp, tmp_path):
    with pytest.raises(ValueError, match="unknown blocks"):
        thermal.thermal_handoff(fp, {"SRAM_bankX": 1.0}, tmp_path)
    with pytest.raises(ValueError, match="power_w must be >= 0"):
        thermal.thermal_handoff(fp, {f"SRAM_bank{i}": -0.001 for i in range(4)}, tmp_path,
                                neighbours=[{"name": "x", "x0_um": 0, "y0_um": 0, "x1_um": 1, "y1_um": 1, "power_w": -1}])
    with pytest.raises(ValueError, match="empty or inverted"):
        thermal.thermal_handoff(fp, {f"SRAM_bank{i}": 0.001 for i in range(4)}, tmp_path,
                                neighbours=[{"name": "x", "x0_um": 5, "y0_um": 0, "x1_um": 1, "y1_um": 1, "power_w": 1}])
    with pytest.raises(ValueError, match="missing"):
        thermal.thermal_handoff(fp, {f"SRAM_bank{i}": 0.001 for i in range(4)}, tmp_path, neighbours=[{"name": "x"}])


def test_neighbouring_heat_sources_are_included(fp, tmp_path):
    W = fp["placed_bbox_um"]["width"]
    nb = [{"name": "TensorCore", "zone": "COMPUTE", "x0_um": W + 10, "y0_um": 0, "x1_um": W + 1010, "y1_um": 1000,
           "power_w": 1.5, "provenance": "assumed_engineering_parameter", "source": "caller"}]
    thermal.thermal_handoff(fp, {f"SRAM_bank{i}": 0.001 for i in range(4)}, tmp_path, neighbours=nb)
    rs = rows(tmp_path / "thermallab_blocks.csv")
    assert rs[-1]["name"] == "TensorCore" and rs[-1]["zone"] == "COMPUTE" and float(rs[-1]["power_w"]) == 1.5
    assert LABEL in rs[-1]["source"]
    # neighbours alone (no SRAM power) are NOT written: that would hide the missing SRAM heat
    r = thermal.thermal_handoff(fp, None, tmp_path / "b", neighbours=nb)
    assert r["thermallab_blocks"]["provenance"] == "unavailable" and r["neighbours_not_emitted"]
    assert not os.path.exists(tmp_path / "b" / "thermallab_blocks.csv")


def test_controller_rectangle_appears_in_geometry_when_it_exists(tmp_path):
    s = {"params": {}, "mapped_area_um2": {"value": 100000.0, "provenance": "synthesized", "source": "TEST_FIXTURE"}}
    prof = {"id": "TEST_FIXTURE", "node": "f", "source": "f", "provenance": "assumption", "process_family": "sky130",
            "conditions": {"corner": "x", "voltage_v": 1, "temperature_c": 1}, "units": {"area": "um^2", "time": "ns"}, "notes": "f"}
    f = phys.floorplan(_cfg(), synth=s, tech_profile=prof)
    thermal.thermal_handoff(f, None, tmp_path)
    names = [x["name"] for x in rows(tmp_path / "block_geometry_activity.csv")]
    assert names[-1] == "controller" and len(names) == 5
    r = thermal.thermal_handoff(f, {f"SRAM_bank{i}": 0.001 for i in range(4)}, tmp_path / "p")
    om = json.load(open(tmp_path / "p" / "thermallab_blocks.json"))["_omitted_blocks"]
    assert om == [{"name": "controller", "reason": "no power supplied for this block (not guessed)"}]


def test_power_by_block_from_a_complete_energy_report(fp, tmp_path):
    entry = lambda v, u, per: {"value": v, "unit": u, "per": per, "provenance": "datasheet", "source": "TEST_FIXTURE_NOT_PHYSICAL",
                               "conditions": {"voltage_v": 1.8, "temperature_c": 25, "corner": "t", "macro": SKY}}
    prof = {"entries": {"read": entry(2.0, "pJ", "bank_access"), "write": entry(3.0, "pJ", "bank_access"),
                        "idle": entry(0.5, "pJ", "bank_cycle"), "leakage": entry(10.0, "uW", "bank")}}
    rep = power.energy_report(METRICS, power.load_energy_profile(prof), cfg=_cfg())
    pb = thermal.power_by_block_from_energy(rep, fp, METRICS)
    assert set(pb) == {f"SRAM_bank{i}" for i in range(4)}
    t = rep["activity_based_estimate"]["terms"]["leakage_energy_J"]["time_s"]
    total_w = sum(v["value"] for v in pb.values())
    assert total_w * t == pytest.approx(rep["activity_based_estimate"]["total_energy_J"]["value"], rel=1e-12)   # energy conserved
    p = [pb[f"SRAM_bank{i}"]["value"] for i in range(4)]
    assert p[0] < p[1] < p[2] and p[2] == pytest.approx(p[3])                  # busier banks are hotter
    assert pb["SRAM_bank0"]["provenance"] == "simulated"
    # without a complete profile there is no power
    assert thermal.power_by_block_from_energy(power.energy_report(METRICS, None, cfg=_cfg()), fp, METRICS) is None
    r = thermal.thermal_handoff(fp, pb, tmp_path, run_metrics=METRICS)
    assert r["power"]["total_w"] == pytest.approx(total_w) and r["power"]["provenance_labels"] == ["simulated"]


# ----------------------------------------------------------------------------------------------- hotspot map
PARAMS = dict(k_w_per_mk=100.0, thickness_um=50.0, h_w_per_m2k=1e4, t_ambient_c=25.0)


def block(x0, y0, x1, y1, p, name="b"):
    return {"name": name, "x0_um": x0, "y0_um": y0, "x1_um": x1, "y1_um": y1, "power_w": p}


def test_uniform_heating_matches_closed_form():
    W, H, P = 1000.0, 500.0, 2.0
    r = thermal.hotspot_map_2d([block(0, 0, W, H, P)], W, H, nx=40, ny=20, **PARAMS)
    q = P / (W * 1e-6 * H * 1e-6)                                  # W/m^2
    expected = q / PARAMS["h_w_per_m2k"]                           # rise = q'' / h  (adiabatic borders, no lateral gradient)
    assert expected == pytest.approx(400.0)
    assert np.allclose(r["rise_k"], expected, rtol=1e-9)
    assert r["max_rise_k"] == pytest.approx(expected, rel=1e-9) and np.ptp(r["rise_k"]) < 1e-8
    assert r["label"] == "analytical" and r["calibration"] == "uncalibrated" and "not a die temperature" in r["statement"]
    assert r["assumed_parameters"]["t_ambient_c"] == 25.0 and r["assumed_parameters"]["provenance"].startswith("assumed")


def test_power_balance_is_exact_for_a_nonuniform_map():
    blocks = [block(100, 100, 400, 300, 1.0, "a"), block(600, 50, 900, 450, 0.25, "b")]
    r = thermal.hotspot_map_2d(blocks, 1000.0, 500.0, nx=50, ny=25, **PARAMS)
    assert r["total_power_w"] == pytest.approx(1.25, rel=1e-12)
    assert r["power_balance_residual_w"] < 1e-9                    # sum(h A rise) == total power
    dx, dy = r["grid"]["dx_um"] * 1e-6, r["grid"]["dy_um"] * 1e-6
    assert (PARAMS["h_w_per_m2k"] * dx * dy * r["rise_k"]).sum() == pytest.approx(1.25, rel=1e-8)
    assert r["rise_k"].min() > 0                                   # heat only raises temperature (maximum principle)
    i, j = r["hotspot_cell"]
    assert 100 <= (i + 0.5) * r["grid"]["dx_um"] <= 400 and 100 <= (j + 0.5) * r["grid"]["dy_um"] <= 300   # hotspot in block a


def test_linearity_and_zero_power():
    b = [block(200, 100, 500, 300, 1.0)]
    a = thermal.hotspot_map_2d(b, 1000.0, 500.0, nx=30, ny=15, **PARAMS)["rise_k"]
    b2 = [block(200, 100, 500, 300, 3.0)]
    c = thermal.hotspot_map_2d(b2, 1000.0, 500.0, nx=30, ny=15, **PARAMS)["rise_k"]
    assert np.allclose(c, 3 * a, rtol=1e-9)
    z = thermal.hotspot_map_2d([block(200, 100, 500, 300, 0.0)], 1000.0, 500.0, nx=10, ny=5, **PARAMS)
    assert z["max_rise_k"] == 0.0


def test_mirror_symmetry():
    W = 1000.0
    left = thermal.hotspot_map_2d([block(100, 100, 300, 400, 1.0)], W, 500.0, nx=40, ny=20, **PARAMS)["rise_k"]
    right = thermal.hotspot_map_2d([block(700, 100, 900, 400, 1.0)], W, 500.0, nx=40, ny=20, **PARAMS)["rise_k"]
    assert np.allclose(left, right[::-1, :], rtol=1e-9, atol=1e-12)


def test_better_spreading_lowers_the_peak():
    b = [block(450, 200, 550, 300, 1.0)]
    thin = thermal.hotspot_map_2d(b, 1000.0, 500.0, nx=40, ny=20, **{**PARAMS, "thickness_um": 10.0})["max_rise_k"]
    thick = thermal.hotspot_map_2d(b, 1000.0, 500.0, nx=40, ny=20, **{**PARAMS, "thickness_um": 500.0})["max_rise_k"]
    assert thick < thin


def test_no_default_parameters_and_input_validation():
    b = [block(0, 0, 100, 100, 1.0)]
    with pytest.raises(TypeError):
        thermal.hotspot_map_2d(b, 1000.0, 500.0, nx=10, ny=5)                      # conductivity etc. are mandatory arguments
    for bad in ({"k_w_per_mk": 0}, {"thickness_um": -1}, {"h_w_per_m2k": float("nan")}, {"k_w_per_mk": True}):
        with pytest.raises(ValueError, match="positive finite"):
            thermal.hotspot_map_2d(b, 1000.0, 500.0, nx=10, ny=5, **{**PARAMS, **bad})
    with pytest.raises(ValueError, match="t_ambient_c"):
        thermal.hotspot_map_2d(b, 1000.0, 500.0, nx=10, ny=5, **{**PARAMS, "t_ambient_c": None})
    with pytest.raises(ValueError, match="outside"):
        thermal.hotspot_map_2d([block(0, 0, 2000, 100, 1.0)], 1000.0, 500.0, nx=10, ny=5, **PARAMS)
    with pytest.raises(ValueError):
        thermal.hotspot_map_2d(b, 1000.0, 500.0, nx=1, ny=5, **PARAMS)
    with pytest.raises(ValueError, match="power_w"):
        thermal.hotspot_map_2d([block(0, 0, 100, 100, -1.0)], 1000.0, 500.0, nx=10, ny=5, **PARAMS)


def test_rasterisation_conserves_power_exactly():
    P = thermal.rasterise_power([block(13.7, 21.1, 333.3, 411.9, 2.5)], 1000.0, 500.0, 37, 19)
    assert P.sum() == pytest.approx(2.5, rel=1e-12) and (P >= 0).all()
