"""The RTL harnesses must give the same answer on any supported simulator / version.

History: the SV testbench inherited from Project 80 drove sf_sram_subsystem from a timed initial block
(Verilator --timing).  Under Verilator 5.020 that mis-simulated: the controller's always_comb decode was not
re-evaluated (stale row addresses, wrong read data; with -O0 nothing was issued).  The Verilator harness is
now C++-driven and a second, independently written testbench runs the same stimulus on Icarus.
"""
import json
import os
import subprocess

import pytest
from conftest import needs_icarus, needs_verilator
from sramlab import rtlrun, tools, verify


@needs_verilator
def test_verilator_harness_is_cpp_driven_without_timing():
    # the controller harness must not depend on the --timing scheduler
    import re
    code = "\n".join(ln.split("//")[0] for ln in open(rtlrun.VL_TOP).read().splitlines())   # strip comments
    assert not re.search(r"\binitial\b", code)                     # no initial process
    assert not re.search(r"#\s*\d", code)                          # no delays
    assert "--timing" not in open(rtlrun.__file__).read().split("def _build_locked", 1)[1].split("def build_icarus", 1)[0]
    p = verify.param_sets()["base_4m4b"]
    exe = rtlrun.build(p)
    assert os.path.exists(exe)


@needs_verilator
@pytest.mark.parametrize("pname,wname", [("4m4b_prio", "contention"), ("base_4m4b", "mixed_bp")])
def test_cases_that_failed_under_the_timing_testbench_now_match(pname, wname):
    # exactly the two cases that diverged with the --timing SV testbench on Verilator 5.020
    p, sc, rd, fl = verify.build_case(pname, wname, 80, 11)
    v = rtlrun.compare(p, sc, rd, flush_cycles=fl)
    assert v["ok"], v


@needs_verilator
@needs_icarus
@pytest.mark.parametrize("pname,wname", [("base_4m4b", "mixed_bp"), ("4m4b_mo4_lat1234", "illegal_mix"),
                                         ("3m4b_dw128_mo2", "vector"), ("4m4b_mo4_lat2", "flush_mix"),
                                         ("6m4b_prio_mo2", "contention")])
def test_three_way_model_verilator_icarus(pname, wname):
    p, sc, rd, fl = verify.build_case(pname, wname, 100, 5)
    for sim in ("verilator", "icarus"):
        v = rtlrun.compare(p, sc, rd, flush_cycles=fl, simulator=sim)
        assert v["ok"] and v["simulator"] == sim, (sim, v)


@needs_verilator
@needs_icarus
def test_three_way_comparator_can_fail():
    # the Icarus path must detect a broken model as well (a comparator that cannot fail proves nothing)
    from sramlab.sim import controller as C
    p, sc, rd, _ = verify.build_case("base_4m4b", "contention", 60, 2)
    orig = C._Arb.pick

    def fixed_priority(self, req_mask):
        for i in range(self.n):
            if req_mask >> i & 1:
                return i, False, req_mask
        return -1, False, req_mask
    C._Arb.pick = fixed_priority
    try:
        v = rtlrun.compare(p, sc, rd, simulator="icarus")
    finally:
        C._Arb.pick = orig
    assert not v["ok"] and v["first_trace_divergence"] is not None


def test_unknown_simulator_rejected():
    p = verify.param_sets()["base_4m4b"]
    with pytest.raises(ValueError):
        rtlrun.run_rtl(p, [[] for _ in range(4)], verify.ReadyMasks(4, 1.0, 1), 1, simulator="modelsim")


@needs_verilator
def test_pip_wheel_pch_detection_is_precise():
    v = tools.verilator()
    assert isinstance(v.get("pip_wheel"), bool)


@needs_verilator
def test_fscanf_defect_reproducer_documented():
    # the docs must carry the minimal reproducers that justify each workaround
    doc = open(os.path.join(tools.ROOT, "docs", "03_verification.md")).read()
    for marker in ("Harness portability", "defect A", "defect B", "defect C", "-fno-life-post"):
        assert marker in doc, marker
