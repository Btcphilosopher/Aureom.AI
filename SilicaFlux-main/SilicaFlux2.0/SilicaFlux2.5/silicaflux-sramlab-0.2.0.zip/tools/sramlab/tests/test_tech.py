"""Technology profiles, vendored macro catalogue, tiling arithmetic, Nangate45 pinning.

Hand-computed tiling cases are checked against the independently generated
silicaflux-memorycore-sram ``physical/floorplan_C1_sky130.json`` / ``area_report.md`` numbers (quoted in comments).
Offline: the Nangate45 download is replaced by a fake ``_download`` unless the real, pinned file is already cached.
"""
import copy
import json
import os
import shutil

import pytest

from sramlab import tech

HERE = os.path.dirname(os.path.abspath(__file__))
MACROS = tech.MACRO_DIR


def _manifest(name):
    with open(os.path.join(MACROS, name + ".json")) as fh:
        return json.load(fh)


# ----------------------------------------------------------------------------------------------- profiles
GOOD = {"id": "t", "node": "n", "source": "s", "provenance": "library", "process_family": "x",
        "conditions": {"corner": "typ", "voltage_v": 1.0, "temperature_c": 25.0},
        "units": {"area": "um^2", "time": "ns"}, "notes": "n"}


def test_shipped_profiles_all_valid():
    ps = tech.list_profiles()
    assert {p["id"] for p in ps} >= {"none", "nangate45", "sky130_open_pdk", "ihp_sg13g2", "gf180mcu"}
    bad = [p for p in ps if not p["valid"]]
    assert not bad, bad


def test_profile_none_means_no_library():
    p = tech.load_profile("none")
    assert p["id"] == "none" and p["liberty"] is None
    assert tech.load_profile(None)["id"] == "none"
    r = tech.profile_liberty(p)
    assert r["available"] is False and "no technology library" in r["reason"]


def test_nangate_profile_conditions_come_from_the_library_header():
    p = tech.load_profile("nangate45")
    assert p["conditions"]["voltage_v"] == 1.1 and p["conditions"]["temperature_c"] == 25.0
    assert p["provenance"] == "library" and "NOT the SilicaFlux target process" in p["disclaimer"]
    assert len(p["liberty"]["pinned_sha256"]) == 64


@pytest.mark.parametrize("missing", ["provenance", "units", "conditions", "source", "node", "notes", "id"])
def test_profile_missing_required_field_rejected(missing):
    d = copy.deepcopy(GOOD)
    del d[missing]
    with pytest.raises(tech.TechError) as e:
        tech.load_profile(d)
    assert any(missing in p for p in e.value.problems)


def test_profile_missing_units_members_and_condition_members_rejected():
    d = copy.deepcopy(GOOD)
    d["units"] = {"area": "um^2"}
    d["conditions"] = {"corner": "typ", "voltage_v": 1.0}
    with pytest.raises(tech.TechError) as e:
        tech.load_profile(d)
    msg = " | ".join(e.value.problems)
    assert "units.time" in msg and "conditions.temperature_c" in msg      # ALL problems reported, not just the first


def test_profile_bad_provenance_and_unpinned_library_path_rejected():
    d = copy.deepcopy(GOOD)
    d["provenance"] = "vibes"
    d["liberty"] = {"path": "x.lib"}
    with pytest.raises(tech.TechError) as e:
        tech.load_profile(d)
    msg = " | ".join(e.value.problems)
    assert "provenance" in msg and "liberty.path requires liberty.sha256" in msg


def test_good_profile_loads_and_yaml_if_available(tmp_path):
    assert tech.load_profile(copy.deepcopy(GOOD))["id"] == "t"
    pytest.importorskip("yaml")
    import yaml
    f = tmp_path / "p.yaml"
    f.write_text(yaml.safe_dump(GOOD))
    assert tech.load_profile(str(f))["id"] == "t"


def test_broken_profile_file_is_listed_not_hidden(tmp_path, monkeypatch):
    (tmp_path / "bad.json").write_text(json.dumps({"id": "bad", "node": "n"}))
    (tmp_path / "worse.json").write_text("{nope")
    monkeypatch.setattr(tech, "CONFIG_TECH_DIR", str(tmp_path))
    ps = {p["id"]: p for p in tech.list_profiles()}
    assert not ps["bad"]["valid"] and any("provenance" in m for m in ps["bad"]["problems"])
    assert not ps["worse"]["valid"] and any("not valid JSON" in m for m in ps["worse"]["problems"])
    with pytest.raises(tech.TechError, match="not found"):
        tech.load_profile("does_not_exist")


# ----------------------------------------------------------------------------------------------- vendored data
def test_vendored_macro_data_verifies_and_pending_are_not_vendored():
    v = tech.verify_macro_data()
    assert v["ok"], v
    assert v["checked"] == 35                      # 34 manifests + the TimingFlow transcription
    names = os.listdir(MACROS)
    assert not any("pending" in n for n in names)
    assert {p["id"] for p in tech.PENDING_MACROS} == {"commercial_130nm", "commercial_65nm", "commercial_28nm"}


def test_catalog_contents():
    cat = tech.macro_catalog()
    assert len(cat) == 34
    fams = {}
    for m in cat:
        fams.setdefault(m["family"], []).append(m)
        assert m["status"] == "OPEN_SOURCE_AVAILABLE" and m["source_commit"] and m["source_repo"]
        assert m["capacity_bits"] == m["data_width"] * m["words"]
        # the vendor's area is width x height (LEF): consistency of the real numbers (rounding in the manifests)
        assert m["area_um2"] == pytest.approx(m["width_um"] * m["height_um"], rel=2e-5), m["macro_name"]
        assert m["silicon_status"] and "not established" in m["silicon_status"]
    assert set(fams) == {"IHP_1P", "IHP_2P", "SKY130_1RW1R", "GF180_1RW"}
    assert (len(fams["IHP_1P"]), len(fams["IHP_2P"]), len(fams["SKY130_1RW1R"]), len(fams["GF180_1RW"])) == (18, 9, 3, 4)


def test_catalog_exposes_timing_numbers_only_where_the_manifest_has_them():
    sky = tech.get_macro("sky130_sram_2kbyte_1rw1r_32x512_8")
    assert sky["timing"]["rows"] == [] and "not extracted" in sky["timing"]["notes"]
    ihp = tech.get_macro("RM_IHPSG13_1P_2048x64_c2_bm_bist")
    rows = {r["corner"]: r["value"] for r in ihp["timing"]["rows"]}
    assert rows == {"wc_1d08V_125C": 9.05, "bc_1d32V_m55C": 3.35, "tc_1d20V_25C": 5.43}
    gf = tech.get_macro("gf180mcu_fd_ip_sram__sram64x8m8wm1")
    assert {r["name"]: r["value"] for r in gf["timing"]["rows"]} == {"min_clock_period": 8.2602, "clock_to_q_rise": 6.1696}


def test_datasheet_clock_to_dout_lies_inside_liberty_min_max_range():
    """Cross-check of two independent sources: manifest (datasheet) vs TimingFlow (vendor Liberty tables)."""
    corner = {"typ": "tc_1d20V_25C", "slow": "wc_1d08V_125C", "fast": "bc_1d32V_m55C"}
    n = 0
    for name in ("RM_IHPSG13_1P_2048x64_c2_bm_bist", "RM_IHPSG13_1P_512x64_c2_bm_bist", "RM_IHPSG13_1P_256x64_c2_bm_bist"):
        ds = {r["corner"]: r["value"] for r in tech.get_macro(name)["timing"]["rows"]}
        rows = tech.macro_timing_liberty(name)
        assert len(rows) == 3
        for r in rows:
            c = r["clock_to_dout_ns"]
            assert c["min"] <= ds[corner[r["corner"]]] <= c["max"], (name, r["corner"], c, ds)
            n += 1
    assert n == 9


def test_tampered_manifest_is_detected(tmp_path):
    d = tmp_path / "macros"
    shutil.copytree(MACROS, d)
    f = d / "sky130_sram_2kbyte_1rw1r_32x512_8.json"
    f.write_text(f.read_text().replace("284538.47", "1.0"))
    v = tech.verify_macro_data(str(d))
    assert not v["ok"] and any("sha256 mismatch" in p for p in v["problems"])
    with pytest.raises(tech.TechError, match="failed verification"):
        tech.macro_catalog(str(d))
    # an extra, unlisted manifest is also flagged
    shutil.copy(d / "gf180mcu_fd_ip_sram__sram64x8m8wm1.json", d / "extra.json")
    assert any("not listed" in p for p in tech.verify_macro_data(str(d))["problems"])


def test_unknown_and_pending_macro_names_rejected():
    with pytest.raises(tech.TechError, match="pending, no data"):
        tech.get_macro("commercial_28nm")


# ----------------------------------------------------------------------------------------------- tiling
def test_tile_sky130_c1_matches_independent_floorplan():
    # silicaflux-memorycore-sram physical/floorplan_C1_sky130.json: NC=4 NR=2, 8 per bank, 32 total,
    # macro area 32 x 284538.47 = 9,105,231.04 um2, bit utilisation 1.0
    t = tech.tile_memory(1024 * 128, 128, "sky130_sram_2kbyte_1rw1r_32x512_8")
    assert (t["cols"], t["rows"], t["instances"]) == (4, 2, 8)
    assert t["total_macro_area_um2"] == pytest.approx(8 * 284538.47)
    assert 4 * t["total_macro_area_um2"] == pytest.approx(9105231.04, abs=1e-6)
    assert t["bit_utilisation"] == 1.0 and t["wasted_bits"] == 0 and t["label"] == "analytical"
    assert t["grid_width_um"] == pytest.approx(4 * 683.1) and t["grid_height_um"] == pytest.approx(2 * 416.54)
    assert "1RW1R macro used as 1RW" in t["note"]


def test_tile_ihp_and_gf180_match_independent_floorplan():
    ihp = tech.tile_memory(1024 * 128, 128, "RM_IHPSG13_1P_1024x64_c2_bm_bist")   # C1_ihp: 2 x 1, 8 total, 2.1116 mm2
    assert (ihp["cols"], ihp["rows"]) == (2, 1) and 4 * ihp["total_macro_area_um2"] == pytest.approx(2111569.12, abs=1e-6)
    gf = tech.tile_memory(1024 * 128, 128, "gf180mcu_fd_ip_sram__sram512x8m8wm1")  # C1_gf180: 16 x 2, 128 total, 26.8032 mm2
    assert (gf["cols"], gf["rows"], gf["instances"]) == (16, 2, 32)
    assert 4 * gf["total_macro_area_um2"] == pytest.approx(128 * 209400.2768, abs=1e-4)


def test_tile_with_ecc_width_wastes_bits_as_in_independent_report():
    # C2_sky130: 137-bit stored word -> NC = ceil(137/32) = 5, NR = 2, 10 per bank, 40 total, util 85.62 %
    t = tech.tile_memory(1024 * 137, 137, "sky130_sram_2kbyte_1rw1r_32x512_8")
    assert (t["cols"], t["rows"], t["instances"]) == (5, 2, 10)
    assert t["provisioned_bits"] == 5 * 32 * 2 * 512 == 163840
    assert t["wasted_bits"] == 163840 - 1024 * 137 == 23552
    assert t["unused_bits_per_row"] == 23 and t["unused_rows"] == 0
    assert t["bit_utilisation"] == pytest.approx(0.85625)
    assert 4 * t["total_macro_area_um2"] == pytest.approx(11381538.8, abs=1e-3)


def test_tile_depth_rounding_and_gap():
    # depth 300 rows of 16 bits on 256x16: NR = ceil(300/256) = 2, provisioned 2*256*16 = 8192, wasted (512-300)*16
    t = tech.tile_memory(300 * 16, 16, "RM_IHPSG13_1P_256x16_c2_bm_bist", gap_um=10.0)
    assert (t["cols"], t["rows"]) == (1, 2) and t["unused_rows"] == 212
    assert t["wasted_bits"] == 212 * 16
    assert t["grid_height_um"] == pytest.approx(2 * 118.78 + 10.0) and t["gap_basis"] == "caller-supplied assumption"
    assert tech.tile_memory(300 * 16, 16, "RM_IHPSG13_1P_256x16_c2_bm_bist")["gap_basis"].startswith("abutted")


def test_tile_rejects_bad_inputs():
    with pytest.raises(tech.TechError, match="whole rows"):
        tech.tile_memory(1000, 128, "sky130_sram_2kbyte_1rw1r_32x512_8")
    with pytest.raises(tech.TechError):
        tech.tile_memory(0, 32, "sky130_sram_2kbyte_1rw1r_32x512_8")
    with pytest.raises(tech.TechError, match="no data_width"):
        tech.tile_memory(1024, 32, {"macro_name": "placeholder", "data_width": None, "words": None})


def test_rank_macros_reproduces_independent_ranking():
    r = tech.rank_macros(1024 * 128, 128, family="SKY130_1RW1R")
    assert [x["macro_name"] for x in r] == ["sky130_sram_2kbyte_1rw1r_32x512_8", "sky130_sram_1kbyte_1rw1r_32x256_8",
                                            "sky130_sram_1kbyte_1rw1r_8x1024_8"]
    # area_report.md: 9.1052 / 12.2056 / 13.0095 mm2 for the 4-bank memory
    assert [round(4 * x["total_macro_area_um2"] / 1e6, 4) for x in r] == [9.1052, 12.2056, 13.0095]
    # true dual-port macros are excluded by default
    assert all("2P" not in x["macro_name"] for x in tech.rank_macros(1024 * 32, 32))


def test_secded_stored_bits():
    assert [tech.secded_stored_bits(k) for k in (32, 64, 128)] == [39, 72, 137]
    with pytest.raises(tech.TechError):
        tech.secded_stored_bits(0)


# ----------------------------------------------------------------------------------------------- nangate45 pinning
@pytest.fixture
def fake_cache(tmp_path, monkeypatch):
    monkeypatch.setenv("SRAMLAB_CACHE", str(tmp_path / "cache"))
    prof = tmp_path / "nangate45.json"
    prof.write_text(json.dumps({"id": "nangate45", "liberty": {"cache_path": "tech/nangate45/NangateOpenCellLibrary_typical.lib",
                                                               "pinned_sha256": None}}))
    return tmp_path, prof


def _fake_download(content):
    def dl(url, dest, timeout=300):
        with open(dest, "wb") as fh:
            fh.write(content)
    return dl


LIB_A = b"library (FAKE) {\n" + b"/* padding */\n" * 200 + b"}\n"
LIB_B = b"library (FAKE) {\n" + b"/* other */\n" * 200 + b"}\n"


def test_first_fetch_records_and_pins_sha256(fake_cache, monkeypatch):
    tmp, prof = fake_cache
    monkeypatch.setattr(tech, "_download", _fake_download(LIB_A))
    meta = tech.fetch_nangate45(profile_path=str(prof))
    assert meta["sha256"] == tech.sha256_bytes(LIB_A) and meta["bytes"] == len(LIB_A) and meta["downloaded_utc"].endswith("Z")
    assert json.load(open(prof))["liberty"]["pinned_sha256"] == meta["sha256"]
    rec = json.load(open(os.path.join(os.path.dirname(meta["path"]), "FETCH.json")))
    assert rec["sha256"] == meta["sha256"] and rec["url"] == tech.NANGATE45_URL


def test_mismatching_download_is_refused_and_deleted(fake_cache, monkeypatch):
    tmp, prof = fake_cache
    monkeypatch.setattr(tech, "_download", _fake_download(LIB_A))
    tech.fetch_nangate45(profile_path=str(prof))                       # pins LIB_A
    other = str(tmp / "cache2" / "empty")
    monkeypatch.setattr(tech, "_download", _fake_download(LIB_B))      # upstream "changed"
    with pytest.raises(tech.TechError, match="sha256 mismatch"):
        tech.fetch_nangate45(other, profile_path=str(prof))
    assert not os.path.exists(os.path.join(other, tech.NANGATE45_FILE))          # the different file is not kept
    assert not os.path.exists(os.path.join(other, tech.NANGATE45_FILE + ".part"))


def test_non_empty_destination_is_refused(fake_cache, monkeypatch):
    tmp, prof = fake_cache
    d = tmp / "dirty"
    d.mkdir()
    (d / "something.txt").write_text("x")
    monkeypatch.setattr(tech, "_download", _fake_download(LIB_A))
    with pytest.raises(tech.TechError, match="NEW EMPTY directory"):
        tech.fetch_nangate45(str(d), profile_path=str(prof))


def test_refetch_into_populated_default_reuses_verified_copy_without_download(fake_cache, monkeypatch):
    tmp, prof = fake_cache
    monkeypatch.setattr(tech, "_download", _fake_download(LIB_A))
    first = tech.fetch_nangate45(profile_path=str(prof))
    monkeypatch.setattr(tech, "_download", lambda *a, **k: pytest.fail("must not download again"))
    again = tech.fetch_nangate45(profile_path=str(prof))
    assert again["reused_existing_download"] is True and again["sha256"] == first["sha256"]


def test_cached_file_that_no_longer_matches_pin_is_refused(fake_cache, monkeypatch):
    tmp, prof = fake_cache
    monkeypatch.setattr(tech, "_download", _fake_download(LIB_A))
    meta = tech.fetch_nangate45(profile_path=str(prof))
    with open(meta["path"], "ab") as fh:
        fh.write(b"/* tampered */")
    with pytest.raises(tech.TechError, match="REFUSING"):
        tech.fetch_nangate45(profile_path=str(prof))
    p = json.load(open(prof))
    p.update({"provenance": "library", "node": "n", "source": "s", "notes": "n", "process_family": "nangate45",
              "conditions": {"corner": "t", "voltage_v": 1.1, "temperature_c": 25.0}, "units": {"area": "um^2", "time": "ns"}})
    with pytest.raises(tech.TechError, match="REFUSING to use it"):
        tech.profile_liberty(tech.load_profile(p))


def test_not_a_liberty_and_tiny_downloads_refused(fake_cache, monkeypatch):
    tmp, prof = fake_cache
    monkeypatch.setattr(tech, "_download", _fake_download(b"<html>proxy error</html>" * 100))
    with pytest.raises(tech.TechError, match="does not start like a Liberty"):
        tech.fetch_nangate45(str(tmp / "a"), profile_path=str(prof))
    monkeypatch.setattr(tech, "_download", _fake_download(b"x"))
    with pytest.raises(tech.TechError, match="only 1 bytes"):
        tech.fetch_nangate45(str(tmp / "b"), profile_path=str(prof))
    assert json.load(open(prof))["liberty"]["pinned_sha256"] is None      # nothing pinned from a rejected file


def test_unpinned_library_is_refused(fake_cache):
    tmp, prof = fake_cache
    d = tmp / "cache" / "tech" / "nangate45"
    d.mkdir(parents=True)
    (d / tech.NANGATE45_FILE).write_bytes(LIB_A)
    p = dict(GOOD)
    p["liberty"] = {"cache_path": "tech/nangate45/" + tech.NANGATE45_FILE}          # no pinned_sha256
    with pytest.raises(tech.TechError, match="unpinned"):
        tech.profile_liberty(tech.load_profile(p))
    p["liberty"]["pinned_sha256"] = tech.sha256_bytes(LIB_A)
    assert tech.profile_liberty(tech.load_profile(p))["available"] is True
    p["liberty"]["cache_path"] = "tech/nangate45/missing.lib"
    r = tech.profile_liberty(tech.load_profile(p))
    assert r["available"] is False and "not present" in r["reason"]


@pytest.mark.skipif(not os.path.isfile(os.path.join(tech.cache_root(), "tech", "nangate45", tech.NANGATE45_FILE)),
                    reason="Nangate45 liberty not fetched")
def test_real_nangate_download_matches_pin_and_record():
    r = tech.nangate45_liberty()
    assert r["available"] and r["sha256"] == tech.load_profile("nangate45")["liberty"]["pinned_sha256"]
    meta = json.load(open(os.path.join(os.path.dirname(r["path"]), "FETCH.json")))
    assert meta["sha256"] == r["sha256"] and meta["bytes"] == os.path.getsize(r["path"])
    assert tech.sha256_file(r["path"]) == r["sha256"]
