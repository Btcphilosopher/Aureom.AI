import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
import pytest
from sramlab import tools

needs_verilator = pytest.mark.skipif(tools.verilator() is None, reason="Verilator not installed")
needs_yosys = pytest.mark.skipif(tools.yosys() is None, reason="Yosys not installed")
needs_icarus = pytest.mark.skipif(tools.iverilog() is None, reason="Icarus Verilog not installed")
needs_rscript = pytest.mark.skipif(tools.rscript() is None, reason="Rscript not installed")
