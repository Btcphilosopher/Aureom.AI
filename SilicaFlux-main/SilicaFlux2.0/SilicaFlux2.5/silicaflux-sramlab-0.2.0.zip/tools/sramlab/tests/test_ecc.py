"""ECC study tests (sramlab.studies.ecc): independent Python SECDED reference vs the real MemoryCore RTL, decoder latency,
partial-write read-modify-write cost, scrubbing, fault reporting, generic-gate synthesis, provenance rules.

Verilator builds are cached under ``sramlab.rtlrun.BUILD_ROOT`` (cold: ~2 minutes, about 1 minute of it Yosys; warm: ~3 s).
Tests that need a cold Yosys run (slow, especially on a wasm build) are marked ``slow``.  Run:  python3 -m pytest tests/test_ecc.py
"""
from __future__ import annotations

import itertools
import json
import os

import warnings

import pytest

warnings.filterwarnings("ignore", category=pytest.PytestUnknownMarkWarning)   # `slow` is documented in the module docstring

from sramlab import tools
from sramlab.prng import SplitMix64
from sramlab.provenance import LABELS
from sramlab.studies import ecc

needs_verilator = pytest.mark.skipif(tools.verilator() is None, reason="Verilator not installed")
needs_yosys = pytest.mark.skipif(tools.yosys() is None, reason="Yosys not installed")


# ------------------------------------------------------------------------------------------------ the reference itself
@pytest.mark.parametrize("k", [32, 64, 128])
def test_reference_code_parameters(k):
    r = ecc.SecdedRef(k)
    assert (r.k, r.r, r.n) == {32: (32, 6, 39), 64: (64, 7, 72), 128: (128, 8, 137)}[k]
    assert len(set(r.col)) == k and all(c & (c - 1) for c in r.col)          # distinct, none a power of two
    assert r.decode(0)[4] == 1 and r.decode((1 << r.n) - 1)[4] == 1          # all-zero and all-ones stored words are uncorrectable


def test_reference_corrects_every_single_error_and_detects_every_double_error():
    r = ecc.SecdedRef(32)
    rng = SplitMix64(1)
    for _ in range(3):
        d = ecc.rand_bits(rng, 32)
        cw = r.encode(d)
        assert r.decode(cw) == (ecc.C_NONE, d, cw, 0, 0, 0)
        for b in range(r.n):
            cls, dout, corr, ce, ue, idx = r.decode(cw ^ (1 << b))
            assert (dout, corr, ce, ue, idx) == (d, cw, 1, 0, b)
        for a, b in itertools.combinations(range(r.n), 2):
            cls, dout, corr, ce, ue, idx = r.decode(cw ^ (1 << a) ^ (1 << b))
            assert ue == 1 and ce == 0 and cls == ecc.C_UE_DOUBLE


@pytest.mark.parametrize("k", [32, 64, 128])
def test_reference_agrees_with_memorycore_python_reference(k):
    a = ecc.upstream_ref_agreement(k, nvec=200)
    assert a["mismatches"] == 0 and a["checks"] > 1000 and a["inv_this"] == a["inv_upstream"]


def test_secded_does_not_guarantee_triple_error_detection():
    """3-bit errors: a large share is silently miscorrected (exhaustive, reference decoder); MemoryCore's ECC.md reports 243/300."""
    r = ecc.SecdedRef(128)
    s = ecc.exact_weight_stats(r, 3)
    assert s["total"] == 419220 and s["detected_ue"] + s["miscorrected"] + s["benign"] == s["total"]
    rate = s["miscorrected"] / s["total"]
    assert 0.80 < rate < 0.87                                                # 243/300 = 0.81 +- sampling error
    assert s["benign"] == 0


# ------------------------------------------------------------------------------------------------ RTL codec vs reference
@needs_verilator
@pytest.mark.parametrize("k", [32, 64, 128])
def test_rtl_codec_equals_independent_reference(k):
    res = ecc.crosscheck_codec(k, quick=True)
    assert res["vectors"] > 3500
    assert res["mismatches"] == 0, res["first_mismatches"]
    assert (res["r_rtl"], res["n_rtl"]) == (res["r_ref"], res["n_ref"])      # widths read from the elaborated RTL
    # RTL outcomes: every single error corrected, every double detected (the guarantee), triples mostly NOT detected
    o = res["rtl_outcomes_by_weight"]
    assert o["w1"]["corrected_ok"] == o["w1"]["total"]
    assert o["w2"]["detected_ue"] == o["w2"]["total"]
    assert o["w3"]["miscorrected"] > 0.5 * o["w3"]["total"]
    # inversion makes the all-zero stored word uncorrectable in the RTL too
    assert res["raw_words_rtl"]["raw_zero"]["ue"] == 1


@needs_verilator
def test_negative_control_wrong_reference_is_detected():
    """A deliberately wrong reference (different inversion mask / a swapped syndrome column) must be flagged by the RTL comparison."""
    good = ecc.SecdedRef(32)
    wrong_inv = good.with_mutation(inv=good.inv ^ 0b100)
    r1 = ecc.crosscheck_codec(32, quick=True, ref=wrong_inv)
    assert r1["mismatches"] > 1000 and r1["encoder_mismatches"] > 0
    wrong_cols = good.with_mutation(swap_cols=(3, 17))
    r2 = ecc.crosscheck_codec(32, quick=True, ref=wrong_cols)
    assert r2["mismatches"] > 0
    # and the real reference stays clean on the very same vectors
    assert ecc.crosscheck_codec(32, quick=True, ref=good)["mismatches"] == 0


# ------------------------------------------------------------------------------------------------ latency / RMW
@needs_verilator
def test_decoder_adds_exactly_one_cycle_and_matches_documented_bank_latency():
    sec = ecc.latency_section((32,), rls=(1, 2), quick=True, n_ops=120)
    for rl in (1, 2):
        L = sec["latency"][f"DW32_RL{rl}"]
        for op in ("read", "write_full", "write_partial"):
            assert L[op]["ecc_off_cycles"]["value"] == rl
            assert L[op]["ecc_on_cycles"]["value"] == rl + 1
            assert L[op]["added_by_ecc_cycles"]["value"] == 1                 # a wrong expectation (e.g. +2) would fail here
            assert L[op]["ecc_off_cycles"]["provenance"] == "rtl_simulated"
        assert L["matches_documented"] is True


@needs_verilator
def test_partial_write_read_modify_write_throughput():
    sec = ecc.latency_section((32,), rls=(1, 2), quick=True, n_ops=240)
    for rl in (1, 2):
        T = sec["partial_write"][f"DW32_RL{rl}"]
        # ECC off: byte enables are native, a partial write is as fast as a full write
        assert T["wr_part"]["ecc_off"]["relative_to_full_write"]["value"] == pytest.approx(1.0)
        # ECC on: the bank is busy READ_LATENCY + 1 cycles per partial write -> 1/(RL+1) of the full-write rate
        assert T["wr_part"]["ecc_on"]["accept_interval_cycles"]["value"] == pytest.approx(rl + 1, abs=1e-3)
        assert T["wr_part"]["ecc_on"]["relative_to_full_write"]["value"] == pytest.approx(1.0 / (rl + 1), abs=1e-3)
        # full-line writes and reads keep one access per cycle
        assert T["wr_full"]["ecc_on"]["steady_ops_per_cycle"]["value"] == pytest.approx(1.0)
        assert T["rd"]["ecc_on"]["steady_ops_per_cycle"]["value"] == pytest.approx(1.0)
        # byte-accurate reference model agrees with every row after every stream
        for kind in T.values():
            for mode in kind.values():
                assert mode["readback_mismatches"] == 0
        # MemoryCore's own number: 0.501 (RL=1) / 0.335 (RL=2) for its partial-write benchmark
        assert abs(T["wr_part"]["ecc_on"]["ops_per_cycle"]["value"] - {1: 0.501, 2: 0.335}[rl]) < 0.01


@needs_verilator
def test_fault_hook_does_not_change_timing():
    assert ecc.fi_timing_check(32, 120)["value"] is True


# ------------------------------------------------------------------------------------------------ scrub
@needs_verilator
def test_scrub_cost_and_repair():
    s = ecc.scrub_section(32, quick=True)["RL1_SCRUB_WAIT64"]
    assert s["array_cycles_per_scrub_step"]["value"] == 2.0                    # go cycle + READ_LATENCY
    assert s["bank_blocked_cycles_per_scrub_step"]["value"] == 1.0
    assert s["cycles_per_scrubbed_word_period"]["value"] == pytest.approx(64 + 1 + 1)
    assert s["bank_bandwidth_fraction_consumed"]["value"] == pytest.approx(2 / 66, abs=1e-4)
    fix = s["repair_test"]["scrub_fix"]
    assert fix["ce_cnt"] == fix["seeded_single"] and fix["ue_cnt"] >= 1       # every seeded single-bit error found once, the double reported
    assert s["repair_test"]["readback"]["residual_bad_rows"] == 0
    full = [r for r in s["under_load"] if r["offered_requests_per_256_cycles"] == 256][0]
    assert full["scrub_steps"]["value"] == 0                                   # saturated bank: a scrub step is never started


# ------------------------------------------------------------------------------------------------ fault reporting
@needs_verilator
@pytest.mark.parametrize("k", [32, 128])
def test_fault_injection_single_double_triple(k):
    r = ecc.fault_section(k, quick=True)
    assert r["reference_mismatches"] == 0, r["first_mismatches"]
    bw = r["by_weight"]
    w1, w2, w3 = bw["weight_1"], bw["weight_2"], bw["weight_3"]
    assert w1["corrected_data_ok"]["value"] == w1["injected"]["value"] == k + ecc.SecdedRef(k).r + 1
    assert w1["ce_counter_increments"]["value"] == w1["injected"]["value"] and w1["ue_counter_increments"]["value"] == 0
    assert w2["flagged_uncorrectable"]["value"] == w2["injected"]["value"] and w2["ue_counter_increments"]["value"] == w2["injected"]["value"]
    assert w2["silently_miscorrected"]["value"] == 0
    exact = ecc.exact_weight_stats(ecc.SecdedRef(k), 3)
    exp = exact["miscorrected"] / exact["total"]
    rate = w3["silent_miscorrection_rate"]["value"]
    assert abs(rate - exp) < 0.07                                              # sampled (n=400) vs exhaustive reference
    assert rate > 0.5                                                          # SECDED does NOT guarantee detection of 3-bit errors
    # a miscorrected triple is counted as a CORRECTED error (the counters cannot tell)
    assert w3["ce_counter_increments"]["value"] == w3["silently_miscorrected"]["value"]
    rmw = r["rmw_on_errors"]
    assert all(v for v in rmw["partial_write_on_single_bit_error_line"].values() if isinstance(v, bool))
    assert all(v for v in rmw["partial_write_on_double_bit_error_line"].values() if isinstance(v, bool))


# ------------------------------------------------------------------------------------------------ storage + synthesis + provenance
@needs_verilator
def test_storage_overhead_matches_elaborated_rtl_widths():
    cc = {k: ecc.crosscheck_codec(k, quick=True) for k in (32, 64, 128)}
    bank = {k: ecc._by(ecc.run_bank(k, 1, 1, []), "CFG")[0] for k in (32, 64, 128)}
    s = ecc.storage_section((32, 64, 128), cc, bank)
    assert [s[f"DW{k}"]["ecc_on_stored_bits_per_word"]["value"] for k in (32, 64, 128)] == [39, 72, 137]
    assert [s[f"DW{k}"]["storage_overhead_pct"]["value"] for k in (32, 64, 128)] == [21.875, 12.5, 7.031]
    for k in (32, 64, 128):
        t = s[f"DW{k}"]["ecc_on_stored_bits_per_word"]
        assert t["provenance"] == "analytical" and t["agrees_with_rtl"] is True
        assert t["rtl_elaborated_bank_store_w"] == t["value"]


@needs_yosys
@pytest.mark.slow
def test_generic_gate_synthesis_is_labelled_and_sane():
    enc = ecc.yosys_generic("sf_ecc_enc", {"K": 32}, ecc.CODEC_RTL)
    dec = ecc.yosys_generic("sf_ecc_dec", {"K": 32}, ecc.CODEC_RTL)
    for r in (enc, dec):
        assert r["provenance"] == "synthesized" and "NOT area" in r["note"]
        assert r["value"]["flip_flops"] == 0 and r["value"]["latches"] == 0       # purely combinational
    assert 0 < enc["value"]["total_cells"] < dec["value"]["total_cells"]
    assert set(enc["value"]["cells_by_type"]) <= {"$_XOR_", "$_NOT_", "$_AND_", "$_OR_", "$_MUX_"}
    # XOR trees: at least one XOR per data bit that feeds a check bit
    assert enc["value"]["cells_by_type"]["$_XOR_"] >= 32


@needs_verilator
@needs_yosys
@pytest.mark.slow
def test_quick_study_end_to_end_provenance_and_files(tmp_path):
    res = ecc.run_ecc_study(word_bits=(32,), outdir=str(tmp_path), quick=True)
    assert os.path.exists(res["files"]["json"]) and os.path.exists(res["files"]["csv"])
    on_disk = json.load(open(res["files"]["json"]))
    assert on_disk["study"] == "ecc" and on_disk["unavailable_items"] == []

    labels = set()

    def walk(o):
        if isinstance(o, dict):
            if "provenance" in o and "value" in o:
                labels.add(o["provenance"])
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(on_disk)
    assert labels <= set(LABELS) and "measured" not in labels
    assert {"analytical", "synthesized", "rtl_simulated"} <= labels
    csv_text = open(res["files"]["csv"]).read()
    assert "rtl_simulated" in csv_text and "synthesized" in csv_text and ",measured," not in csv_text
    # headline checks
    lat = on_disk["latency"]["by_config"]["DW32_RL1"]
    assert lat["read"]["added_by_ecc_cycles"]["value"] == 1
    assert on_disk["logic_cost"]["deltas"]["DW=32"]["added_total_cells"]["value"] > 0


# ------------------------------------------------------------------------------------------------ ABC / MemoryCore flow
def test_abc_probe_is_functional_not_presence_based(monkeypatch):
    from sramlab import tools
    ecc.abc_available.cache_clear()
    monkeypatch.setattr(tools, "yosys", lambda: None)
    assert ecc.abc_available() is False                       # no Yosys => no ABC, never assumed
    ecc.abc_available.cache_clear()


@pytest.mark.slow
def test_memorycore_flow_comparison_is_computed_not_asserted():
    from sramlab import tools
    if tools.yosys() is None:
        pytest.skip("no yosys")
    ecc.abc_available.cache_clear()
    r = ecc.synth_section((128,), quick=True)
    for nm, committed in ecc.MC_COMMITTED_SYNTH.items():
        e = r["memorycore_committed_for_comparison"][nm]
        assert e["memorycore_report_cells"]["value"] == committed
        if ecc.abc_available():
            ab = e["this_run_cells_abc_fast"]
            assert ab["provenance"] == "synthesized" and "abc -fast" in ab["source"]
            d = e["abc_fast_minus_memorycore_cells"]["value"]
            assert d == ab["value"] - committed and abs(d) <= 0.01 * committed      # same flow, same RTL: within 1 %
            assert (d == 0) == ("gives the same count" in e["why_different"])
        else:
            assert e["this_run_cells_abc_fast"]["provenance"] == "unavailable"
            assert "does not execute ABC" in e["why_different"]
