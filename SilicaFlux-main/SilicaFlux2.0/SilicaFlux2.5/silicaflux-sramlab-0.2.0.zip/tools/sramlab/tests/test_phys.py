"""Physical-area analysis: footprint, logic area, overheads, generated geometry, "die area unknown without libraries".

Fixtures named TEST_FIXTURE_* are synthetic stand-ins used only to exercise arithmetic paths that need a library of the
macros' own process (none exists in this tree); they are never shipped as data.
"""
import json
import math
import os

import pytest

from sramlab import phys, tech
from sramlab.config import load_config
from sramlab.provenance import tag, unavailable

SKY = "sky130_sram_2kbyte_1rw1r_32x512_8"


def cfg(backend="asic_macro", macro=SKY, banks=4, depth=1024, word=128, ecc="none", masters=4, technology="none", **extra):
    d = {"memory": {"banks": banks, "bank_depth_words": depth, "word_width_bits": word, "ecc": ecc},
         "controller": {"masters": masters},
         "physical": {"backend": backend, "macro": macro if backend == "asic_macro" else None, "technology": technology}}
    return load_config(d)


def TEST_FIXTURE_NOT_PHYSICAL_synth(area=100000.0, banks=4, masters=4, cells=5000):
    """A synth-result-shaped dict with a mapped area; the number is arbitrary (TEST ONLY)."""
    return {"params": {"NUM_BANKS": banks, "NUM_MASTERS": masters, "DATA_WIDTH": 128, "MAX_OUT": 1},
            "generic": {"total_cells": cells, "flip_flops": 700, "latches": 0, "logic_depth": {"levels": 20}},
            "mapped_area_um2": tag(area, "synthesized", "TEST_FIXTURE_NOT_PHYSICAL", unit="um^2"),
            "mapped": {"technology": "TEST_FIXTURE_NOT_PHYSICAL", "liberty_sha256": "0" * 64}}


FIX_PROFILE = {"id": "TEST_FIXTURE_sky130_logic", "node": "fixture", "source": "TEST_FIXTURE_NOT_PHYSICAL",
               "provenance": "assumption", "process_family": "sky130", "conditions": {"corner": "x", "voltage_v": 1.8, "temperature_c": 25},
               "units": {"area": "um^2", "time": "ns"}, "notes": "TEST FIXTURE"}


# ----------------------------------------------------------------------------------------------- required: unknown without libraries
def test_die_area_unavailable_when_libraries_are_missing():
    r = phys.area_report(cfg(), None, None)
    assert r["die_area"]["provenance"] == "unavailable" and r["die_area"]["value"] is None
    assert "logic area unknown" in r["die_area"]["reason"]
    assert r["logic"]["area_um2"]["provenance"] == "unavailable"
    assert r["logic"]["gate_counts"]["provenance"] == "unavailable"
    # while the macro footprint (real vendor data) IS available and exact
    fp = r["memory_footprint"]
    assert fp["total_macro_area_um2"]["value"] == pytest.approx(9105231.04, abs=1e-6)
    assert fp["total_macro_area_um2"]["provenance"] == "analytical"
    assert fp["total_macro_area_mm2"]["value"] == pytest.approx(9.10523104)
    assert fp["instances_total"]["value"] == 32 and fp["bit_utilisation"]["value"] == 1.0


def test_die_area_unavailable_for_generic_and_fpga_backends():
    for b in ("generic", "fpga_bram"):
        r = phys.area_report(cfg(backend=b), None, None)
        assert r["die_area"]["provenance"] == "unavailable"
        assert r["routing_estimate"]["provenance"] == "unavailable"
    g = phys.area_report(cfg(backend="generic"), None, None)["memory_footprint"]
    assert g["kind"] == "generic" and g["area_um2"]["provenance"] == "unavailable"


def test_fpga_reports_bits_not_mm2():
    r = phys.area_report(cfg(backend="fpga_bram", banks=4, depth=1024, word=32), None, None)
    fp = r["memory_footprint"]
    assert fp["bram_bits_total"]["value"] == 4 * 1024 * 32 and fp["bram_bits_per_bank"]["value"] == 1024 * 32
    assert fp["area_mm2"]["provenance"] == "unavailable"
    assert fp["bram_tiles_lower_bound"]["provenance"] == "unavailable"          # device geometry not supplied
    prof = dict(FIX_PROFILE, id="TEST_FIXTURE_fpga", process_family="fpga", fpga={"bram_bits": 36864, "source": "TEST_FIXTURE"})
    r2 = phys.area_report(cfg(backend="fpga_bram", banks=4, depth=1024, word=32), None, prof)
    t = r2["memory_footprint"]["bram_tiles_lower_bound"]
    assert t["value"] == 4 * math.ceil(1024 * 32 / 36864) == 4 and t["provenance"] == "analytical"


def test_memory_bits_always_available_and_ecc_stored_bits():
    r = phys.area_report(cfg(backend="generic", banks=4, depth=1024, word=32, ecc="secded"), None, None)
    mb = r["memory_bits"]
    assert mb["user_bits"]["value"] == 4 * 1024 * 32 and mb["stored_bits"]["value"] == 4 * 1024 * 39
    assert mb["stored_word_bits"] == 39


def test_unknown_or_pending_macro_is_unavailable_not_estimated():
    c = cfg(macro="commercial_28nm")
    r = phys.area_report(c, None, None)
    assert r["memory_footprint"]["total_macro_area_um2"]["provenance"] == "unavailable"
    assert "pending, no data" in r["memory_footprint"]["total_macro_area_um2"]["reason"]
    assert r["die_area"]["provenance"] == "unavailable"
    fp = phys.floorplan(c)
    assert fp["status"] == "unavailable" and fp["macros"] == [] and fp["die"]["provenance"] == "unavailable"


# ----------------------------------------------------------------------------------------------- logic area
def test_logic_area_passes_through_only_when_liberty_mapped():
    s = TEST_FIXTURE_NOT_PHYSICAL_synth(12345.5)
    r = phys.area_report(cfg(), s, None)
    assert r["logic"]["area_um2"]["value"] == 12345.5 and r["logic"]["area_um2"]["provenance"] == "synthesized"
    assert r["logic"]["gate_counts"]["total_cells"]["value"] == 5000
    assert any("technology profile is 'none'" in w for w in r["warnings"])
    generic = {"params": s["params"], "generic": s["generic"], "mapped_area_um2": unavailable("no technology library")}
    r2 = phys.area_report(cfg(), generic, None)
    assert r2["logic"]["area_um2"]["provenance"] == "unavailable" and r2["logic"]["area_um2"]["reason"] == "no technology library"
    assert r2["logic"]["gate_counts"]["flip_flops"]["value"] == 700            # gate counts survive, area does not


def test_synth_result_for_another_design_is_flagged():
    s = TEST_FIXTURE_NOT_PHYSICAL_synth(banks=8)
    r = phys.area_report(cfg(banks=4), s, None)
    assert any("NUM_BANKS=8" in w and "different design" in w for w in r["warnings"])


def test_logic_from_nangate_is_not_added_to_sky130_macros():
    """A 45 nm library area must not be combined with 130 nm macros: die area stays unavailable with the reason."""
    s = TEST_FIXTURE_NOT_PHYSICAL_synth(50000.0)
    r = phys.area_report(cfg(technology="nangate45"), s, "nangate45", spacing={"margin_um": 40})
    assert r["die_area"]["provenance"] == "unavailable"
    assert "'nangate45' differs from the macro's 'sky130'" in r["die_area"]["reason"]
    fp = phys.floorplan(cfg(), synth=s, tech_profile="nangate45", spacing={"margin_um": 40})
    assert fp["controller"]["rect"] is None and fp["controller"]["area_um2"]["provenance"] == "unavailable"


def test_die_area_computed_only_with_same_process_logic_and_margin():
    s = TEST_FIXTURE_NOT_PHYSICAL_synth(100000.0)
    # same process family but no margin => still unavailable (a die needs a margin, which is a placement parameter)
    fp0 = phys.floorplan(cfg(), synth=s, tech_profile=FIX_PROFILE)
    assert fp0["die"]["provenance"] == "unavailable" and "margin_um" in fp0["die"]["reason"]
    fp = phys.floorplan(cfg(), synth=s, tech_profile=FIX_PROFILE, spacing={"margin_um": 40.0})
    array_h = 4 * 2 * 416.54                                    # 4 banks stacked, 2 macro rows each, abutted
    ctrl_w = 100000.0 / array_h
    bbox_w, bbox_h = ctrl_w + 4 * 683.1, array_h
    assert fp["controller"]["rect"]["x1"] == pytest.approx(ctrl_w)
    assert fp["placed_bbox_um"]["width"] == pytest.approx(bbox_w) and fp["placed_bbox_um"]["height"] == pytest.approx(bbox_h)
    d = fp["die"]
    assert d["value"] == pytest.approx((bbox_w + 80) * (bbox_h + 80)) and d["provenance"] == "analytical"
    assert d["label2"] == "generated-geometry"


# ----------------------------------------------------------------------------------------------- ecc
def test_ecc_overhead_ratio_and_extra_macros():
    # 512 x 32 per bank on the 32x512 macro: 1 macro per bank; SECDED stores 39 bits -> 2 columns -> 2 macros per bank
    c = cfg(banks=4, depth=512, word=32, ecc="secded")
    r = phys.area_report(c, None, None)
    e = r["ecc_overhead"]
    assert e["stored_bit_ratio"]["value"] == pytest.approx(39 / 32)
    assert e["extra_macros"]["value"] == 4
    assert e["extra_macro_area_um2"]["value"] == pytest.approx(4 * 284538.47)
    assert {k: round(v["value"], 6) for k, v in e["reference_ratios"].items()} == {
        "32": round(39 / 32, 6), "64": round(72 / 64, 6), "128": round(137 / 128, 6)}
    assert r["memory_footprint"]["instances_total"]["value"] == 8


def test_ecc_logic_is_marked_todo_until_the_ecc_study_exists(tmp_path):
    c = cfg(banks=2, depth=512, word=32, ecc="secded")
    r = phys.area_report(c, None, None, ecc_study_path=str(tmp_path / "ecc_study.json"))
    el = r["ecc_overhead"]["ecc_logic"]
    assert el["provenance"] == "unavailable" and el["TODO"] is True and "run `sramlab ecc` first" in el["reason"]
    # present but unusable file -> still unavailable, with the reason
    f = tmp_path / "ecc_study.json"
    f.write_text(json.dumps({"something": [1, 2, 3]}))
    el = phys.area_report(c, None, None, ecc_study_path=str(f))["ecc_overhead"]["ecc_logic"]
    assert el["provenance"] == "unavailable" and "no synthesized-gate rows for 32-bit" in el["reason"]
    f.write_text("{not json")
    assert phys.area_report(c, None, None, ecc_study_path=str(f))["ecc_overhead"]["ecc_logic"]["provenance"] == "unavailable"


def test_ecc_logic_rows_are_taken_from_the_study_when_present(tmp_path):
    f = tmp_path / "ecc_study.json"
    f.write_text(json.dumps({"synth": [{"name": "TEST_FIXTURE", "data_bits": 32, "total_cells": 111, "stored_bits": 39},
                                       {"name": "other", "data_bits": 64, "total_cells": 222}]}))
    el = phys.area_report(cfg(banks=2, depth=512, word=32, ecc="secded"), None, None,
                          ecc_study_path=str(f))["ecc_overhead"]["ecc_logic"]
    assert el["provenance"] == "synthesized" and len(el["rows"]) == 1 and el["rows"][0]["total_cells"] == 111
    # ecc disabled: no codec at all
    assert phys.area_report(cfg(), None, None)["ecc_overhead"]["ecc_logic"]["value"] == 0


# ----------------------------------------------------------------------------------------------- arbitration / noc / constraints
def test_arbitration_overhead_from_sweep_and_synth():
    sweep = {"_path": "x.json", "_sha256": "a" * 64,
             "rows": [{"banks": b, "masters": 4, "max_out": 1, "perf": 0, "cells": c, "flip_flops": f, "status": "ok", "mapped_area_um2": None}
                      for b, c, f in ((2, 1850, 242), (4, 3202, 286))]}
    r = phys.area_report(cfg(banks=4), TEST_FIXTURE_NOT_PHYSICAL_synth(cells=4000), None, sweep=sweep)
    a = r["arbitration_overhead"]
    assert a["controller_cells"]["value"] == 4000 and a["cells_per_bank"]["value"] == 1000
    assert [x["banks"] for x in a["controller_cells_vs_banks"]["rows"]] == [2, 4]
    none = phys.area_report(cfg(), None, None, sweep={"_path": "x", "_sha256": "b" * 64, "rows": []})["arbitration_overhead"]
    assert none["controller_cells"]["provenance"] == "unavailable"
    assert none["controller_cells_vs_banks"]["provenance"] == "unavailable"


def test_noc_interface_reports_success_and_failure_honestly():
    ok = {"parts": {"sf_sram_datafabric": {"status": "ok", "generic": {"total_cells": 11654, "flip_flops": 2487, "latches": 0},
                                           "params": {"NM": 4}, "scope": "bridge"},
                    "sf_sram_fabric_top": {"status": "failed", "error": "ERROR: boom", "scope": "top"}}}
    n = phys.area_report(cfg(), None, None, noc=ok)["noc_interface"]
    assert n["parts"]["sf_sram_datafabric"]["total_cells"] == 11654 and n["parts"]["sf_sram_datafabric"]["label"] == "synthesized"
    assert n["parts"]["sf_sram_datafabric"]["area_um2"]["provenance"] == "unavailable"
    assert n["parts"]["sf_sram_fabric_top"]["label"] == "unavailable" and n["parts"]["sf_sram_fabric_top"]["reason"] == "ERROR: boom"


def test_placement_constraints_halo_unavailable_manifest_constraints_listed():
    p = phys.area_report(cfg(), None, None, spacing={"halo_um": 20})["placement_constraints"]
    assert p["halo_keepout"]["provenance"] == "unavailable"
    assert p["caller_spacing"]["halo_um"]["provenance"] == "assumed" and p["caller_spacing"]["gap_um"]["provenance"] == "unavailable"
    assert any("same-address write" in c for c in p["manifest_constraints"])
    with pytest.raises(ValueError):
        phys.area_report(cfg(), None, None, spacing={"gap_um": -1})


# ----------------------------------------------------------------------------------------------- geometry
def _rects(fp):
    return [(m["x"], m["y"], m["x"] + m["w"], m["y"] + m["h"]) for m in fp["macros"]]


def test_floorplan_geometry_invariants(tmp_path):
    fp = phys.floorplan(cfg(), outdir=tmp_path)
    assert fp["label"] == "generated-geometry" and "NOT A ROUTED" in fp["disclaimer"]
    assert len(fp["macros"]) == 32 and len(fp["bank_regions"]) == 4
    r = _rects(fp)
    for i, a in enumerate(r):
        for b in r[i + 1:]:
            assert min(a[2], b[2]) - max(a[0], b[0]) <= 1e-9 or min(a[3], b[3]) - max(a[1], b[1]) <= 1e-9     # no overlap
    W, H = fp["placed_bbox_um"]["width"], fp["placed_bbox_um"]["height"]
    assert all(a[0] >= -1e-9 and a[1] >= -1e-9 and a[2] <= W + 1e-9 and a[3] <= H + 1e-9 for a in r)
    assert sum((a[2] - a[0]) * (a[3] - a[1]) for a in r) == pytest.approx(9105231.04, rel=1e-6)
    assert fp["macro_array_bbox_um2"]["value"] == pytest.approx(W * H)      # abutted: bbox == macro area (up to rounding)
    assert "NOT a die area" in fp["macro_array_bbox_um2"]["source"]
    assert fp["die"]["provenance"] == "unavailable"
    on_disk = json.load(open(tmp_path / "floorplan.json"))
    assert on_disk["label"] == "generated-geometry" and len(on_disk["macros"]) == 32
    # ECC columns: 137 stored bits => the last column's data_bit_hi is clipped to bit 136
    fe = phys.floorplan(cfg(ecc="secded"))
    assert max(m["data_bit_hi"] for m in fe["macros"]) == 136 and len(fe["macros"]) == 40


def test_floorplan_spacing_is_applied_and_labelled_assumed():
    fp = phys.floorplan(cfg(banks=2), spacing={"gap_um": 20.0, "channel_um": 40.0})
    m = {x["inst"]: x for x in fp["macros"]}
    assert m["u_bank0_r0_c1"]["x"] - m["u_bank0_r0_c0"]["x"] == pytest.approx(683.1 + 20.0)
    assert m["u_bank0_r1_c0"]["y"] - m["u_bank0_r0_c0"]["y"] == pytest.approx(416.54 + 20.0)
    assert fp["parameters"]["gap_um"]["provenance"] == "assumed" and fp["parameters"]["margin_um"]["provenance"] == "unavailable"
    r0, r1 = fp["bank_regions"]
    assert abs(r1["y0"] - r0["y1"]) == pytest.approx(40.0)


def test_bank_arrangement_chooses_aspect_closest_to_one():
    assert phys._bank_grid(4, 100.0, 100.0, 0.0) == (2, 2)
    assert phys._bank_grid(4, 100.0, 25.0, 0.0) == (1, 4)
    assert phys._bank_grid(16, 100.0, 100.0, 0.0) == (4, 4)
    assert phys._bank_grid(1, 5.0, 7.0, 0.0) == (1, 1)


def test_routing_estimate_hand_computed_two_banks():
    c = cfg(banks=2)
    fp = phys.floorplan(c)
    re_ = fp["routing_estimate"]
    # 2 banks stacked (1 column): bank = 2732.4 x 833.08; controller anchor = (0, 833.08)
    d = 1366.2 + 416.54
    sig = 2 * 128 + 16 + 10 + 4                      # wdata + wstrb + row addr + 2 + rdata + 2
    assert re_["signals_per_bank_bus"] == sig == 286
    assert [round(p["manhattan_centre_um"], 6) for p in re_["per_bank"]] == [round(d, 6)] * 2
    assert re_["total_signal_um_centre"] == pytest.approx(2 * d * sig)
    assert re_["label"] == "analytical" and "NOT routed" in re_["kind"]
    # nearest-edge distance is never longer than centre-to-anchor
    assert all(p["manhattan_nearest_edge_um"] <= p["manhattan_centre_um"] + 1e-9 for p in re_["per_bank"])


def test_routing_grows_with_bank_count():
    a = phys.floorplan(cfg(banks=2))["routing_estimate"]["total_signal_um_centre"]
    b = phys.floorplan(cfg(banks=4))["routing_estimate"]["total_signal_um_centre"]
    assert b > 2 * a                                 # more banks and farther banks


# ----------------------------------------------------------------------------------------------- optimiser hook
def test_candidate_area_matches_brute_force_over_the_manifests():
    here = tech.MACRO_DIR
    best = None
    for f in os.listdir(here):
        if not f.endswith(".json") or f.startswith("timingflow"):
            continue
        m = json.load(open(os.path.join(here, f)))
        if m.get("family") != "IHP_1P":
            continue
        nc, nr = -(-32 // m["data_width"]), -(-4096 // m["words"])
        a = nc * nr * m["physical"]["area_um2"]
        best = a if best is None else min(best, a)
    c = phys.candidate_area({"banks": 4, "word_bits": 32}, 65536)
    assert c["value"] == pytest.approx(4 * best) and c["label"] == "analytical" and c["unit"] == "um^2"
    assert "not a die area" in c["note"]
    bad = phys.candidate_area({"banks": 4, "word_bits": 32}, 65536 + 1)
    assert bad["label"] == "unavailable"
    assert phys.candidate_area({"banks": 4, "word_bits": 32}, 65536, macro_family="NOPE")["label"] == "unavailable"
    # ECC widens the stored word: area can only grow
    assert phys.candidate_area({"banks": 4, "word_bits": 32, "ecc": "secded"}, 65536)["value"] >= c["value"]


# ----------------------------------------------------------------------------------------------- vendored P74 RTL / NoC synthesis
def test_vendored_p74_rtl_verifies_and_tampering_is_detected(tmp_path):
    import shutil
    v = phys.verify_vendored_rtl()
    assert v["ok"] and v["checked"] == 46, v
    d = tmp_path / "p74"
    shutil.copytree(phys.P74, d)
    f = d / "rtl" / "sf_sram_datafabric.sv"
    f.write_text(f.read_text() + "\n// tampered\n")
    bad = phys.verify_vendored_rtl(str(d))
    assert not bad["ok"] and any("sf_sram_datafabric.sv: sha256 mismatch" in p for p in bad["problems"])
    (d / "rtl" / "extra.sv").write_text("module x; endmodule\n")
    assert any("extra.sv: present but not listed" in p for p in phys.verify_vendored_rtl(str(d))["problems"])


def test_noc_bridge_synthesizes_in_yosys(tmp_path):
    from sramlab import tools
    if tools.yosys() is None:
        pytest.skip("yosys not installed")
    r = phys.noc_interface_synth(tmp_path, None, fabric_top=False)
    p = r["parts"]["sf_sram_datafabric"]
    assert p["status"] == "ok", p.get("error")
    g = p["generic"]
    assert g["latches"] == 0 and g["check_assert"]["ok"] and g["total_cells"] > 1000 and g["flip_flops"] > 100
    assert p["mapped_area_um2"]["reason"] == "no technology library"
    assert os.path.isfile(tmp_path / "noc_interface.json")
    # and the area report consumes it
    n = phys.area_report(cfg(), None, None, noc=r)["noc_interface"]["parts"]["sf_sram_datafabric"]
    assert n["total_cells"] == g["total_cells"] and n["label"] == "synthesized"


def test_noc_synthesis_refuses_tampered_rtl(tmp_path, monkeypatch):
    import shutil
    d = tmp_path / "p74"
    shutil.copytree(phys.P74, d)
    (d / "rtl" / "sf_sdf_skid.sv").write_text("// changed\n")
    monkeypatch.setattr(phys, "P74", str(d))
    with pytest.raises(tech.TechError, match="failed verification"):
        phys.noc_interface_synth(tmp_path / "out", None, fabric_top=False)
