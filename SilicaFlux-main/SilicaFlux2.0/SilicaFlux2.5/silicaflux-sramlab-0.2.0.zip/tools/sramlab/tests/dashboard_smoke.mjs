// Smoke test for the self-contained SRAMLab dashboard (file:// , headless Chromium via Playwright).
//
//   node tests/dashboard_smoke.mjs <dashboard.html> [--shots DIR] [--sizes 1440x900,390x844] [--quick]
//
// For each viewport it opens the page, collects every console message and page error (any of them fails the run),
// visits all 15 views and asserts: the view is shown, has a provenance chip, and holds either a non-empty SVG chart /
// table or an explicit UNAVAILABLE panel (never a blank area); the page does not scroll horizontally; MEASURED is
// never used as a data class; the first render is fast.  Optional interaction checks run on the desktop viewport.
// Prints a JSON report on the last line; exit code 1 on any failure.
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const require = createRequire(import.meta.url);
let chromium;
try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = await import('playwright')); }

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith('--') && !/^\d+x\d+(,|$)/.test(a));
if (!file) { console.error('usage: dashboard_smoke.mjs <dashboard.html> [--shots DIR] [--sizes WxH,WxH] [--quick]'); process.exit(2); }
const opt = (name, dflt) => { const i = args.indexOf(name); return i >= 0 && args[i + 1] ? args[i + 1] : dflt; };
const shotsDir = opt('--shots', null);
const quick = args.includes('--quick');
const sizes = opt('--sizes', quick ? '1440x900' : '1440x900,390x844').split(',').map((s) => s.split('x').map(Number));
const strictFirstRenderMs = Number(opt('--max-first-render-ms', 1000));
const url = pathToFileURL(path.resolve(file)).href;

const failures = [];
const report = { file: path.resolve(file), sizes: [], views: {}, console: [], interactions: [] };
const fail = (m) => { failures.push(m); };

const ALLOWED_PROV = new Set(['analytical', 'simulated', 'synthesized', 'unavailable', 'measured-none', 'unverified']);

async function checkView(page, n, tag) {
  await page.evaluate((v) => window.__sramlab.go(v), n);
  await page.waitForSelector(`section.panel[data-view="${n}"]:not([hidden])`, { timeout: 5000 });
  const info = await page.evaluate((v) => {
    const p = document.querySelector(`section.panel[data-view="${v}"]`);
    const svgs = [...p.querySelectorAll('svg')].filter((s) => !s.closest('.chip') && !s.closest('.legend') && !s.closest('.tip'));
    const bigSvg = svgs.filter((s) => s.querySelectorAll('path,rect,circle,line,text').length >= 6);
    const rect = p.getBoundingClientRect();
    return {
      title: (p.querySelector('h2') || {}).textContent || '',
      chips: p.querySelectorAll('.chip').length,
      provs: [...new Set([...p.querySelectorAll('.chip')].map((c) => c.getAttribute('data-prov')))],
      chipText: [...p.querySelectorAll('.chip')].map((c) => c.textContent.trim()).slice(0, 12),
      svgs: svgs.length, bigSvgs: bigSvg.length,
      tables: p.querySelectorAll('table').length,
      unavail: p.querySelectorAll('.unavail').length,
      renderError: p.querySelectorAll('.render-error').length,
      cards: [...p.querySelectorAll('.card')].filter((c) => !c.parentElement.closest('.card')).length,
      sources: [...p.querySelectorAll('.card')].filter((c) => !c.parentElement.closest('.card') && c.querySelector(':scope > .src')).length,
      height: Math.round(rect.height),
      hscroll: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      bodyHscroll: document.body.scrollWidth - window.innerWidth,
      panelMs: window.__sramlab.panelMs()[v],
      badText: (p.innerText.match(/\b(NaN|undefined|Infinity|\[object)\b/g) || []).slice(0, 3),
    };
  }, n);
  const where = `view ${n} [${tag}]`;
  if (!info.title) fail(`${where}: no heading`);
  if (info.chips < 1) fail(`${where}: no provenance chip`);
  if (info.renderError) fail(`${where}: render error panel shown`);
  const hasChart = info.bigSvgs > 0;
  const tableOnly = n === 15 && info.tables > 0;
  if (!hasChart && !info.unavail && !tableOnly) fail(`${where}: neither a non-empty SVG chart nor an UNAVAILABLE panel`);
  if (info.cards > 0 && info.sources < Math.ceil(info.cards * 0.5)) fail(`${where}: cards without a source line (${info.sources}/${info.cards})`);
  for (const pv of info.provs) if (!ALLOWED_PROV.has(pv)) fail(`${where}: unexpected provenance class ${pv}`);
  if (info.badText.length) fail(`${where}: placeholder text leaked into the panel: ${info.badText.join(', ')}`);
  if (info.hscroll > 1) fail(`${where}: horizontal page scroll (${info.hscroll}px)`);
  if (info.bodyHscroll > 1) fail(`${where}: body wider than the viewport (${info.bodyHscroll}px)`);
  if (info.panelMs > 800) fail(`${where}: panel took ${Math.round(info.panelMs)} ms to render`);
  return info;
}

const browser = await chromium.launch();
try {
  for (const [w, hgt] of sizes) {
    const tag = `${w}x${hgt}`;
    const ctx = await browser.newContext({ viewport: { width: w, height: hgt }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const msgs = [];
    page.on('console', (m) => msgs.push(`${m.type()}: ${m.text()}`));
    page.on('pageerror', (e) => msgs.push(`pageerror: ${e.message}`));
    page.on('requestfailed', (r) => msgs.push(`requestfailed: ${r.url()}`));
    page.on('request', (r) => { const u = r.url(); if (!u.startsWith('file:') && !u.startsWith('data:') && !u.startsWith('about:')) msgs.push(`external request: ${u}`); });
    await page.goto(url, { waitUntil: 'load' });
    await page.waitForFunction(() => window.__sramlab && window.__sramlab.views.length === 15, null, { timeout: 5000 }).catch(() => fail(`[${tag}] dashboard did not register 15 views`));
    const boot = await page.evaluate(() => ({ ms: window.__sramlab.firstRenderMs, views: window.__sramlab.views, jsonOk: !!document.getElementById('sramlab-data'), nav: document.querySelectorAll('.nav button.navitem').length,
      headline: (document.querySelector('.rtl .headline .big') || {}).textContent, tools: document.querySelectorAll('.toolrow .tool').length,
      legend: document.querySelector('.legend-strip') ? document.querySelector('.legend-strip').textContent : '' }));
    if (boot.ms > strictFirstRenderMs) fail(`[${tag}] first render ${Math.round(boot.ms)} ms (> ${strictFirstRenderMs})`);
    if (boot.nav !== 15) fail(`[${tag}] navigation has ${boot.nav} entries, expected 15`);
    if (!/MEASURED/.test(boot.legend) || !/none exists/i.test(boot.legend)) fail(`[${tag}] legend does not state that MEASURED data does not exist`);
    report.sizes.push({ size: tag, firstRenderMs: Math.round(boot.ms), headline: boot.headline, tools: boot.tools });
    const results = {};
    for (let n = 1; n <= 15; n++) {
      const info = await checkView(page, n, tag);
      results[n] = info;
      if (shotsDir) {
        fs.mkdirSync(shotsDir, { recursive: true });
        await page.screenshot({ path: path.join(shotsDir, `v${String(n).padStart(2, '0')}_${tag}.png`), fullPage: true });
      }
    }
    report.views[tag] = Object.fromEntries(Object.entries(results).map(([n, i]) => [n, { title: i.title, chips: i.chipText, svgs: i.bigSvgs, tables: i.tables, unavail: i.unavail, h: i.height, ms: Math.round(i.panelMs || 0) }]));

    // header shot
    if (shotsDir) { await page.evaluate(() => window.__sramlab.go(1)); await page.screenshot({ path: path.join(shotsDir, `top_${tag}.png`) }); }

    if (w >= 1000 && !quick) {
      // ---- interactions (desktop only) ----
      const ok = (name, cond, detail) => { report.interactions.push({ name, ok: !!cond, detail }); if (!cond) fail(`interaction: ${name} ${detail || ''}`); };
      // 1. hover tooltip on a chart (view 4 if data present, else skip)
      await page.evaluate(() => window.__sramlab.go(4));
      const svg4 = page.locator('section.panel[data-view="4"] .chart svg.focusable').first();
      if (await svg4.count()) {
        const box = await svg4.boundingBox();
        await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5);
        await page.waitForTimeout(60);
        const vis = await page.evaluate(() => { const t = document.getElementById('tip'); return !t.hidden && t.textContent.length > 4; });
        ok('hover tooltip on view 4 chart', vis);
        await page.mouse.move(2, 2);
        // keyboard
        await svg4.focus();
        await page.keyboard.press('ArrowRight');
        const kv = await page.evaluate(() => { const t = document.getElementById('tip'); return !t.hidden && t.textContent.length > 4; });
        ok('keyboard arrow shows tooltip on view 4 chart', kv);
        await page.keyboard.press('Escape');
      }
      // 2. changing a control re-renders (view 5 workload)
      await page.evaluate(() => window.__sramlab.go(5));
      const sel = page.locator('section.panel[data-view="5"] select[data-ctl="sw-wl"]');
      if (await sel.count()) {
        const before = await page.evaluate(() => document.querySelector('section.panel[data-view="5"] .card h3').textContent);
        const opts = await sel.locator('option').allTextContents();
        await sel.focus();
        await sel.selectOption({ index: Math.min(2, opts.length - 1) });
        await page.waitForTimeout(80);
        const after = await page.evaluate(() => document.querySelector('section.panel[data-view="5"] .card h3').textContent);
        ok('view 5 workload control re-renders the histogram', before !== after, `${before} -> ${after}`);
        const focused = await page.evaluate(() => document.activeElement && document.activeElement.getAttribute('data-ctl'));
        ok('view 5 keeps focus on the changed control', focused === 'sw-wl', String(focused));
      }
      // 3. timeline replay plays
      await page.evaluate(() => window.__sramlab.go(3));
      const playBtn = page.locator('section.panel[data-view="3"] button', { hasText: /^Play$/ }).first();
      if (await playBtn.count()) {
        const c0 = await page.evaluate(() => document.querySelector('section.panel[data-view="3"] .tlread').textContent);
        await playBtn.click();
        await page.waitForTimeout(700);
        const c1 = await page.evaluate(() => document.querySelector('section.panel[data-view="3"] .tlread').textContent);
        ok('timeline replay advances while playing', c0 !== c1);
        await page.locator('section.panel[data-view="3"] button', { hasText: /^Pause$/ }).first().click();
        const lbl = await page.evaluate(() => document.querySelector('section.panel[data-view="3"] .card .replay') && document.querySelector('section.panel[data-view="3"]').textContent.toLowerCase().includes('replay of a recorded simulation'));
        ok('timeline labelled as a replay of a recorded simulation', lbl);
      }
      // 4. keyboard navigation of the left nav
      await page.evaluate(() => { window.__sramlab.go(1); });
      await page.locator('.nav button.navitem').nth(6).click();
      const cur = await page.evaluate(() => document.querySelector('.nav button.navitem[aria-current="page"]').getAttribute('data-view'));
      ok('nav click opens view 7', cur === '7', cur);
      // 5. bank map responds
      await page.evaluate(() => window.__sramlab.go(2));
      const inter = page.locator('section.panel[data-view="2"] button[data-ctl="map-i:high"]');
      if (await inter.count()) {
        await inter.click();
        const txt = await page.evaluate(() => document.querySelector('section.panel[data-view="2"] .card .note').textContent);
        ok('bank map switches to high interleave', /High interleave/.test(txt), txt.slice(0, 40));
      }
    }
    if (w < 700) {
      // phone: nav toggle opens a list
      await page.evaluate(() => window.__sramlab.go(1));
      const tg = page.locator('.nav .navtoggle');
      if (await tg.isVisible()) {
        await tg.click();
        const open = await page.evaluate(() => getComputedStyle(document.querySelector('#navlist')).display !== 'none');
        report.interactions.push({ name: 'phone nav toggle opens list', ok: open });
        if (!open) fail('phone nav toggle did not open the list');
        if (shotsDir) await page.screenshot({ path: path.join(shotsDir, `navopen_${tag}.png`) });
      } else fail('phone nav toggle not visible');
    }
    for (const m of msgs) report.console.push(`[${tag}] ${m}`);
    await ctx.close();
  }
} finally {
  await browser.close();
}
if (report.console.length) for (const m of report.console) fail(`console/page message: ${m}`);
report.failures = failures;
console.log(JSON.stringify(report));
if (failures.length) { console.error('FAILURES:\n - ' + failures.join('\n - ')); process.exit(1); }
