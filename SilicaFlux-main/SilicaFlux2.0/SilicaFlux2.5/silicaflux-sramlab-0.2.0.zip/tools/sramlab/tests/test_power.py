"""Power provenance: activity always, energy only from a validated profile, never defaulted, never 'measured' by itself.

TEST_FIXTURE_NOT_PHYSICAL profiles below are synthetic numbers chosen for easy arithmetic.  They exist only in this file;
nothing in sramlab ships numeric energy defaults.
"""
import copy
import json
import os

import pytest

from sramlab import power, tech
from sramlab.config import load_config

SKY = "sky130_sram_2kbyte_1rw1r_32x512_8"
COND = {"voltage_v": 1.8, "temperature_c": 25, "corner": "TEST_FIXTURE", "macro": "TEST_FIXTURE_MACRO"}


def entry(value, unit, per, provenance="datasheet", macro="TEST_FIXTURE_MACRO"):
    return {"value": value, "unit": unit, "per": per, "provenance": provenance, "source": "TEST_FIXTURE_NOT_PHYSICAL",
            "conditions": {**COND, "macro": macro}}


def TEST_FIXTURE_NOT_PHYSICAL(provenance="datasheet", macro="TEST_FIXTURE_MACRO"):
    return {"id": "TEST_FIXTURE_NOT_PHYSICAL", "entries": {
        "read": entry(2.0, "pJ", "bank_access", provenance, macro),
        "write": entry(3.0, "pJ", "bank_access", provenance, macro),
        "idle": entry(0.5, "pJ", "bank_cycle", provenance, macro),
        "leakage": entry(10.0, "uW", "bank", provenance, macro)}}


METRICS = {"cycles": 1000, "reads": 600, "writes": 300, "useful_bytes": 3600, "bank_accesses": [225, 225, 225, 225],
           "activity": {"label": "simulated", "array_accesses": 900, "array_bit_activations": 900 * 32, "bank_busy_cycles": 900,
                        "data_bus_toggles": 1234, "array_bit_activations_per_useful_byte": 8.0}}


def cfg(**mem):
    d = {"memory": {"banks": 4, "bank_depth_words": 1024, "word_width_bits": 32, **mem}, "physical": {"backend": "generic"}}
    return load_config(d)


# ----------------------------------------------------------------------------------------------- no profile
def test_no_profile_energy_unavailable_activity_present():
    r = power.energy_report(METRICS, None, cfg=cfg())
    a = r["activity"]
    assert a["label"] == "simulated"
    assert a["array_accesses"]["value"] == 900 and a["reads"]["value"] == 600 and a["writes"]["value"] == 300
    assert a["array_bit_activations"]["value"] == 900 * 32
    assert a["bank_busy_cycles"]["value"] == 900 and a["data_bus_toggles"]["value"] == 1234
    assert a["bank_idle_cycles"]["value"] == 4 * 1000 - 900 == 3100
    assert all(a[k]["provenance"] == "simulated" for k in ("array_accesses", "array_bit_activations", "bank_idle_cycles"))
    ab = r["activity_based_estimate"]
    assert ab["provenance"] == "unavailable" and "no validated energy profile" in ab["reason"]
    for sec in ("fpga_vendor_estimate", "asic_library_estimate", "hardware_measurement"):
        assert r[sec]["provenance"] == "unavailable", sec
    assert r["analytical_energy"]["absolute_energy"]["provenance"] == "unavailable"
    assert r["analytical_energy"]["bit_activation_ratio_vs_no_ecc"]["value"] == 1.0
    assert r["assumed_clock_mhz"]["provenance"] == "unavailable"
    # five separate sections exist
    assert {"analytical_energy", "activity_based_estimate", "fpga_vendor_estimate", "asic_library_estimate",
            "hardware_measurement"} <= set(r)


def test_activity_needs_no_config_and_degrades_to_unavailable_fields():
    r = power.energy_report({"cycles": 10, "reads": 3, "writes": 1, "bank_accesses": [2, 2], "activity": {"array_accesses": 4}})
    a = r["activity"]
    assert a["array_accesses"]["value"] == 4 and a["bank_idle_cycles"]["value"] == 2 * 10 - 4
    assert a["data_bus_toggles"]["provenance"] == "unavailable" and a["ecc_rmw_amplification"]["provenance"] == "unavailable"


def test_activity_ecc_stored_width_and_rmw_amplification():
    c = cfg(ecc="secded")
    r = power.energy_report(METRICS, None, cfg=c)["activity"]
    assert r["array_bit_activations"]["value"] == 900 * 39                       # stored word is 39 bits
    assert r["ecc_rmw_amplification"]["provenance"] == "unavailable"            # the cycle model has no partial-write count
    m2 = copy.deepcopy(METRICS)
    m2["partial_writes"] = 100
    r2 = power.energy_report(m2, None, cfg=c)["activity"]
    assert r2["ecc_rmw_amplification"]["value"] == pytest.approx(1000 / 900)
    assert power.energy_report(METRICS, None, cfg=cfg())["activity"]["ecc_rmw_amplification"]["value"] == 1.0


# ----------------------------------------------------------------------------------------------- profile validation
def test_profile_missing_conditions_is_rejected_with_precise_message():
    p = TEST_FIXTURE_NOT_PHYSICAL()
    del p["entries"]["read"]["conditions"]
    with pytest.raises(power.EnergyProfileError) as e:
        power.load_energy_profile(p)
    assert any("entries.read.conditions: missing" in m for m in e.value.problems)
    p2 = TEST_FIXTURE_NOT_PHYSICAL()
    del p2["entries"]["write"]["conditions"]["corner"]
    del p2["entries"]["write"]["conditions"]["macro"]
    with pytest.raises(power.EnergyProfileError) as e2:
        power.load_energy_profile(p2)
    msg = " | ".join(e2.value.problems)
    assert "entries.write.conditions.corner: missing" in msg and "entries.write.conditions.macro: missing" in msg


@pytest.mark.parametrize("field,value,needle", [
    ("value", None, "entries.read.value"), ("value", -1.0, "entries.read.value"), ("value", float("nan"), "entries.read.value"),
    ("value", True, "entries.read.value"), ("unit", "furlongs", "entries.read.unit"), ("unit", None, "entries.read.unit"),
    ("source", "", "entries.read.source"), ("provenance", "vibes", "entries.read.provenance"),
    ("per", "universe", "entries.read.per")])
def test_profile_entry_defects_rejected(field, value, needle):
    p = TEST_FIXTURE_NOT_PHYSICAL()
    p["entries"]["read"][field] = value
    with pytest.raises(power.EnergyProfileError) as e:
        power.load_energy_profile(p)
    assert any(needle in m for m in e.value.problems)


def test_all_defects_reported_at_once_and_unknown_entries_rejected():
    p = {"entries": {"read": {"value": "x"}, "bogus": entry(1, "pJ", "bank_access")}}
    with pytest.raises(power.EnergyProfileError) as e:
        power.load_energy_profile(p)
    msg = " | ".join(e.value.problems)
    for needle in ("entries.read.value", "entries.read.unit", "entries.read.source", "entries.read.provenance",
                   "entries.read.per", "entries.read.conditions", "entries.bogus: unknown entry"):
        assert needle in msg
    for bad in ({}, {"entries": {}}, [1], {"entries": []}):
        with pytest.raises(power.EnergyProfileError):
            power.load_energy_profile(bad)


def test_unit_conversion_and_json_file_roundtrip(tmp_path):
    p = power.load_energy_profile(TEST_FIXTURE_NOT_PHYSICAL())
    assert p["entries"]["read"]["value_si"] == pytest.approx(2e-12) and p["entries"]["leakage"]["value_si"] == pytest.approx(1e-5)
    f = tmp_path / "p.json"
    f.write_text(json.dumps(TEST_FIXTURE_NOT_PHYSICAL()))
    assert power.load_energy_profile(str(f))["entries"]["idle"]["value_si"] == pytest.approx(5e-13)
    f.write_text("{broken")
    with pytest.raises(power.EnergyProfileError, match="not valid JSON"):
        power.load_energy_profile(str(f))


def test_package_ships_no_numeric_energy_defaults():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for sub in ("configs", "data"):
        for dp, _, fs in os.walk(os.path.join(root, sub)):
            for f in fs:
                assert "energy_profile" not in f.lower() or not f.endswith(".json"), os.path.join(dp, f)
    # the entries mapping is the only way in: a profile object without it is refused
    with pytest.raises(power.EnergyProfileError):
        power.energy_report(METRICS, {"read": 1.0})


# ----------------------------------------------------------------------------------------------- arithmetic
def test_expected_arithmetic_with_test_fixture_profile():
    prof = power.load_energy_profile(TEST_FIXTURE_NOT_PHYSICAL(provenance="datasheet"))
    r = power.energy_report(METRICS, prof, cfg=cfg(), clock_mhz=100.0)
    ab = r["activity_based_estimate"]
    t = ab["terms"]
    assert t["read_energy_J"]["value"] == pytest.approx(600 * 2e-12)
    assert t["write_energy_J"]["value"] == pytest.approx(300 * 3e-12)
    assert t["idle_energy_J"]["value"] == pytest.approx(3100 * 0.5e-12)           # banks*cycles - accesses idle bank-cycles
    assert t["leakage_power_W"]["value"] == pytest.approx(4 * 10e-6)
    assert t["leakage_energy_J"]["value"] == pytest.approx(4 * 10e-6 * 1000 / 100e6)
    dyn = 600 * 2e-12 + 300 * 3e-12 + 3100 * 0.5e-12
    assert ab["dynamic_energy_J"]["value"] == pytest.approx(dyn)
    assert ab["total_energy_J"]["value"] == pytest.approx(dyn + 4e-10)
    assert ab["energy_per_useful_byte_J"]["value"] == pytest.approx((dyn + 4e-10) / 3600)
    # counts are simulated; datasheet coefficients do not turn the result into a measurement
    assert ab["label"] == "simulated" and ab["total_energy_J"]["provenance"] == "simulated"
    assert ab["coefficient_provenance"] == ["datasheet"] and "never 'measured'" in ab["basis"]
    assert r["assumed_clock_mhz"] == {"value": 100.0, "provenance": "assumed", "source": "physical.clock_mhz is an assumption",
                                      "unit": "MHz"}


def test_assumption_provenance_makes_the_result_an_assumed_illustration():
    prof = power.load_energy_profile(TEST_FIXTURE_NOT_PHYSICAL(provenance="assumption"))
    ab = power.energy_report(METRICS, prof, cfg=cfg(), clock_mhz=100.0)["activity_based_estimate"]
    assert ab["label"] == "assumed" and ab["total_energy_J"]["provenance"] == "assumed" and "not a result" in ab["warning_assumed"]


def test_measurement_provenance_coefficients_never_label_measured():
    prof = power.load_energy_profile(TEST_FIXTURE_NOT_PHYSICAL(provenance="measurement"))
    ab = power.energy_report(METRICS, prof, cfg=cfg(), clock_mhz=100.0)["activity_based_estimate"]
    assert ab["label"] == "simulated" and "measured" not in {ab["total_energy_J"]["provenance"], ab["dynamic_energy_J"]["provenance"]}


def test_total_unavailable_unless_every_term_and_a_clock_exist():
    p = TEST_FIXTURE_NOT_PHYSICAL()
    del p["entries"]["idle"]
    prof = power.load_energy_profile(p)
    ab = power.energy_report(METRICS, prof, cfg=cfg(), clock_mhz=100.0)["activity_based_estimate"]
    assert ab["terms"]["read_energy_J"]["value"] > 0                              # covered terms are still reported
    assert ab["terms"]["idle_energy_J"]["provenance"] == "unavailable"
    assert ab["dynamic_energy_J"]["provenance"] == "unavailable" and "idle" in ab["dynamic_energy_J"]["reason"]
    assert ab["total_energy_J"]["provenance"] == "unavailable" and "idle" in ab["total_energy_J"]["reason"]
    full = power.load_energy_profile(TEST_FIXTURE_NOT_PHYSICAL())
    no_clock = power.energy_report(METRICS, full, cfg=cfg())["activity_based_estimate"]
    assert no_clock["dynamic_energy_J"]["value"] > 0 and no_clock["terms"]["leakage_power_W"]["value"] > 0
    assert no_clock["total_energy_J"]["provenance"] == "unavailable" and "clock" in no_clock["total_energy_J"]["reason"]
    # the clock may come from the config (an assumption that is labelled as such)
    c = load_config({"memory": {"banks": 4, "bank_depth_words": 1024, "word_width_bits": 32},
                     "physical": {"backend": "generic", "clock_mhz": 50}})
    r = power.energy_report(METRICS, full, cfg=c)
    assert r["activity_based_estimate"]["total_energy_J"]["value"] > 0 and r["assumed_clock_mhz"]["value"] == 50


def test_missing_run_counts_make_that_term_and_the_total_unavailable():
    m = {k: v for k, v in METRICS.items() if k != "reads"}
    ab = power.energy_report(m, power.load_energy_profile(TEST_FIXTURE_NOT_PHYSICAL()), cfg=cfg(),
                             clock_mhz=100.0)["activity_based_estimate"]
    assert ab["terms"]["read_energy_J"]["provenance"] == "unavailable" and "no reads" in ab["terms"]["read_energy_J"]["reason"]
    assert ab["total_energy_J"]["provenance"] == "unavailable"


def test_per_multipliers_macro_and_bit_activation():
    c = load_config({"memory": {"banks": 4, "bank_depth_words": 1024, "word_width_bits": 128},
                     "physical": {"backend": "asic_macro", "macro": SKY}})
    m = copy.deepcopy(METRICS)
    p = TEST_FIXTURE_NOT_PHYSICAL(macro=SKY)
    p["entries"]["read"] = entry(2.0, "pJ", "macro_access", macro=SKY)             # 4 macro columns per 128-bit access
    p["entries"]["write"] = entry(1.0, "fJ", "bit_activation", macro=SKY)           # per stored bit (128)
    p["entries"]["idle"] = entry(0.5, "pJ", "macro_cycle", macro=SKY)               # 8 macros per bank
    p["entries"]["leakage"] = entry(1.0, "uW", "macro", macro=SKY)                  # 32 macros
    ab = power.energy_report(m, power.load_energy_profile(p), cfg=c, clock_mhz=100.0)["activity_based_estimate"]
    t = ab["terms"]
    assert t["read_energy_J"]["value"] == pytest.approx(600 * 2e-12 * 4)
    assert t["write_energy_J"]["value"] == pytest.approx(300 * 1e-15 * 128)
    assert t["idle_energy_J"]["value"] == pytest.approx(3100 * 0.5e-12 * 8)
    assert t["leakage_power_W"]["value"] == pytest.approx(32 * 1e-6)


def test_per_macro_needs_a_macro_tiling_otherwise_unavailable():
    p = TEST_FIXTURE_NOT_PHYSICAL()
    p["entries"]["read"] = entry(2.0, "pJ", "macro_access")
    ab = power.energy_report(METRICS, power.load_energy_profile(p), cfg=cfg(), clock_mhz=100.0)["activity_based_estimate"]
    assert ab["terms"]["read_energy_J"]["provenance"] == "unavailable" and "macro tiling" in ab["terms"]["read_energy_J"]["reason"]
    assert ab["total_energy_J"]["provenance"] == "unavailable"


# ----------------------------------------------------------------------------------------------- conditions
def test_profile_refused_at_different_conditions_unless_explicitly_allowed():
    prof = power.load_energy_profile(TEST_FIXTURE_NOT_PHYSICAL())
    same = power.energy_report(METRICS, prof, cfg=cfg(), clock_mhz=100.0,
                               operating_conditions={"voltage_v": 1.8, "temperature_c": 25.0, "corner": "test_fixture"})
    assert same["activity_based_estimate"]["total_energy_J"]["value"] > 0 and same["activity_based_estimate"]["warnings"] == []
    diff = power.energy_report(METRICS, prof, cfg=cfg(), clock_mhz=100.0, operating_conditions={"voltage_v": 1.2})
    ab = diff["activity_based_estimate"]
    assert ab["provenance"] == "unavailable" and "voltage_v: profile 1.8 vs requested 1.2" in ab["reason"]
    forced = power.energy_report(METRICS, prof, cfg=cfg(), clock_mhz=100.0, operating_conditions={"temperature_c": 85},
                                 allow_condition_mismatch=True)["activity_based_estimate"]
    assert forced["total_energy_J"]["value"] > 0
    assert any("different conditions" in w and "temperature_c" in w for w in forced["warnings"])


def test_profile_for_another_macro_is_refused():
    c = load_config({"memory": {"banks": 4, "bank_depth_words": 1024, "word_width_bits": 128},
                     "physical": {"backend": "asic_macro", "macro": SKY}})
    prof = power.load_energy_profile(TEST_FIXTURE_NOT_PHYSICAL(macro="some_other_macro"))
    ab = power.energy_report(METRICS, prof, cfg=c, clock_mhz=100.0)["activity_based_estimate"]
    assert ab["provenance"] == "unavailable" and "macro" in ab["reason"] and SKY in ab["reason"]


def test_unvalidated_profile_dict_is_validated_not_trusted():
    with pytest.raises(power.EnergyProfileError):
        power.energy_report(METRICS, {"entries": {"read": {"value": 1}}}, cfg=cfg())
    # a well-formed raw dict is validated on the way in
    r = power.energy_report(METRICS, TEST_FIXTURE_NOT_PHYSICAL(), cfg=cfg(), clock_mhz=100.0)
    assert r["activity_based_estimate"]["total_energy_J"]["value"] > 0


# ----------------------------------------------------------------------------------------------- measurement / vendor
def test_hardware_measurement_only_from_a_file_that_says_measured(tmp_path):
    f = tmp_path / "m.json"
    doc = {"provenance": "measured", "quantity": "power", "value": 0.012, "unit": "W", "instrument": "TEST_FIXTURE_meter",
           "conditions": {"voltage_v": 1.8}, "date": "2026-01-01"}
    f.write_text(json.dumps(doc))
    r = power.energy_report(METRICS, None, measurement=str(f))["hardware_measurement"]
    assert r["provenance"] == "measured" and r["value"] == 0.012 and r["unit"] == "W" and "user-supplied" in r["source"]
    doc["provenance"] = "simulated"
    f.write_text(json.dumps(doc))
    r2 = power.energy_report(METRICS, None, measurement=str(f))["hardware_measurement"]
    assert r2["provenance"] == "unavailable" and "measured" in r2["reason"]
    del doc["instrument"]
    doc["provenance"] = "measured"
    f.write_text(json.dumps(doc))
    assert power.energy_report(METRICS, None, measurement=str(f))["hardware_measurement"]["provenance"] == "unavailable"
    assert power.hardware_measurement(str(tmp_path / "nope.json"))["provenance"] == "unavailable"


VIVADO = """Copyright 1986-2023 Xilinx, Inc.  (FIXTURE: synthetic text, not a real report)
| Tool Version : Vivado v.2023.1
Power Report
| Total On-Chip Power (W)  | 0.215 |
| Dynamic (W)              | 0.100 |
| Device Static (W)        | 0.115 |
| Confidence Level         | Low   |
"""


def test_fpga_vendor_estimate_requires_a_file_and_validates_it(tmp_path):
    assert power.fpga_vendor_estimate(None)["provenance"] == "unavailable"
    f = tmp_path / "r.rpt"
    f.write_text(VIVADO)
    r = power.fpga_vendor_estimate(str(f))
    assert r["total_on_chip_power_W"]["value"] == 0.215 and r["confidence_level"] == "Low"
    assert "NOT a measurement" in r["tool"] and r["total_on_chip_power_W"]["provenance"] == "synthesized"
    f.write_text(VIVADO.replace("0.100", "0.500"))                                 # inconsistent: dynamic + static != total
    bad = power.fpga_vendor_estimate(str(f))
    assert bad["provenance"] == "unavailable" and "inconsistent" in bad["reason"] and len(bad["sha256"]) == 64
    f.write_text("some unrelated text")
    assert "nothing parsed" in power.fpga_vendor_estimate(str(f))["reason"]
    assert power.fpga_vendor_estimate(str(tmp_path / "missing"))["provenance"] == "unavailable"


# ----------------------------------------------------------------------------------------------- liberty reader
# TEST_FIXTURE_NOT_PHYSICAL: a tiny hand-written Liberty with known numbers (offline test of the reader mechanics)
MINI_LIB = '''/* header comment with a brace { that must be ignored */
library (MINI) {
  time_unit : "1ns";
  leakage_power_unit : "1nW";
  voltage_unit : "1V";
  current_unit : "1mA";
  capacitive_load_unit (1,ff);
  nom_process : 1.00;
  nom_temperature : 25.00;
  nom_voltage : 1.10;
  cell (INV_T) {
    area : 2.0;
    cell_leakage_power : 15.0;
    leakage_power () { when : "!A"; value : 10.0; }
    leakage_power () { when : "A"; value : 20.0; }
    pin (A) { direction : input; capacitance : 1.0; }
    pin (ZN) {
      direction : output;
      internal_power () {
        related_pin : "A";
        rise_power (Power_2_2) {
          index_1 ("0.1,0.2");
          index_2 ("1.0,2.0");
          values ("1.0,2.0", \\
                  "3.0,4.0");
        }
        fall_power (Power_2_2) {
          index_1 ("0.1,0.2");
          index_2 ("1.0,2.0");
          values ("5.0,6.0", \\
                  "7.0,8.0");
        }
      }
    }
  }
  cell (BUF_T) { area : 3.0; cell_leakage_power : 7.0; }
}
'''


def test_liberty_reader_on_hand_written_library(tmp_path):
    f = tmp_path / "mini.lib"
    f.write_text(MINI_LIB)
    r = power.liberty_cell_power(str(f), "INV_T")
    assert r["area"] == 2.0 and r["cell_leakage_power_raw"] == 15.0 and r["cell_leakage_power_W"] == pytest.approx(15e-9)
    assert [s["value"] for s in r["leakage_states"]] == [10.0, 20.0] and r["leakage_state_mean_raw"] == 15.0
    assert r["header"]["nom_voltage"] == 1.1 and r["header"]["leakage_power_unit"] == "1nW"
    ip = r["internal_power"][0]
    assert ip["pin"] == "ZN" and ip["related_pin"] == "A"
    assert ip["tables"]["rise_power"]["values"] == [[1.0, 2.0], [3.0, 4.0]] and ip["tables"]["fall_power"]["index_1"] == [0.1, 0.2]
    assert "NOT converted" in r["internal_power_unit"]
    b = power.liberty_cell_power(str(f), "BUF_T")
    assert b["leakage_states"] == [] and b["internal_power"] == [] and b["cell_leakage_power_raw"] == 7.0
    with pytest.raises(KeyError):
        power.liberty_cell_power(str(f), "NOPE")


def test_asic_library_estimate_section(tmp_path):
    assert power.asic_library_estimate(None)["provenance"] == "unavailable"
    f = tmp_path / "mini.lib"
    f.write_text(MINI_LIB)
    r = power.energy_report(METRICS, None, liberty={"path": str(f), "cell": "INV_T"})["asic_library_estimate"]
    assert r["leakage_power_W"]["value"] == pytest.approx(15e-9) and r["data_provenance"] == "library"
    assert r["conditions"] == {"voltage_v": 1.1, "temperature_c": 25.0, "process": 1.0}
    assert r["energy_per_access"]["provenance"] == "unavailable" and "not inferred" in r["energy_per_access"]["reason"]
    bad = power.asic_library_estimate({"path": str(f), "cell": "NOPE"})
    assert bad["provenance"] == "unavailable"


NANGATE = tech.nangate45_liberty() if os.path.isdir(os.path.join(tech.cache_root(), "tech", "nangate45")) else {"available": False}


@pytest.mark.skipif(not NANGATE["available"], reason="Nangate45 liberty not fetched")
class TestLibertyReaderOnNangate45:
    """Validation of the reader against the real, pinned library."""

    def test_known_cell_values(self):
        r = power.liberty_cell_power(NANGATE["path"], "AND2_X1")
        assert r["area"] == 1.064 and r["cell_leakage_power_raw"] == 25.066064
        assert r["cell_leakage_power_W"] == pytest.approx(25.066064e-9)
        assert len(r["leakage_states"]) == 4 and r["header"]["nom_voltage"] == 1.1 and r["header"]["time_unit"] == "1ns"
        assert r["library_sha256"] == NANGATE["sha256"]

    def test_cell_leakage_equals_mean_of_states_for_every_cell_that_has_states(self):
        import re
        with open(NANGATE["path"], encoding="latin-1") as fh:
            names = re.findall(r"^\s*cell\s*\(\s*\"?([\w$.]+)\"?\s*\)\s*\{", fh.read(), flags=re.M)
        assert len(names) == 135
        checked = 0
        for n in names:
            r = power.liberty_cell_power(NANGATE["path"], n)
            if r["leakage_states"]:
                checked += 1
                assert r["leakage_state_mean_raw"] == pytest.approx(r["cell_leakage_power_raw"], rel=1e-5), n
        assert checked == 126

    def test_internal_power_tables_are_rectangular_and_match_their_indices(self):
        for cell, minimum_arcs in (("AND2_X1", 2), ("DFF_X1", 5), ("INV_X1", 1)):
            r = power.liberty_cell_power(NANGATE["path"], cell)
            assert len(r["internal_power"]) >= minimum_arcs, cell
            for arc in r["internal_power"]:
                for name, t in arc["tables"].items():
                    assert name in ("rise_power", "fall_power", "power")
                    n1, n2 = len(t["index_1"]), len(t["index_2"])
                    if n1 and n2:                                        # 2-D table (slew x load)
                        assert len(t["values"]) == n1 and all(len(row) == n2 for row in t["values"])
                    elif n1:                                             # 1-D table: one row along index_1
                        assert len(t["values"]) == 1 and len(t["values"][0]) == n1
                    else:                                                # scalar
                        assert len(t["values"]) == 1 and len(t["values"][0]) == 1
                    assert t["index_1"] == sorted(t["index_1"]) and all(v >= -1e3 for row in t["values"] for v in row)

    def test_dff_has_clock_pin_arcs(self):
        r = power.liberty_cell_power(NANGATE["path"], "DFF_X1")
        assert {"CK", "D"} <= {a["related_pin"] for a in r["internal_power"] if a["related_pin"]} | {a["pin"] for a in r["internal_power"]}
        assert r["area"] == pytest.approx(4.522)

    def test_asic_section_on_a_library_cell_reports_leakage_with_conditions(self):
        s = power.asic_library_estimate({"path": NANGATE["path"], "cell": "NAND2_X1"})
        assert s["leakage_power_W"]["value"] > 0 and s["conditions"]["voltage_v"] == 1.1
        assert s["energy_per_access"]["provenance"] == "unavailable"
