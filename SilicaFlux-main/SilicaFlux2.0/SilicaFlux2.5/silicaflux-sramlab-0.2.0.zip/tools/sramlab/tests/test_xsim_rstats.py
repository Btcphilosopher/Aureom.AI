"""Second-simulator differential check of the study testbenches, and the independent R statistics check."""
import math

import pytest
from conftest import needs_icarus, needs_rscript, needs_verilator
from sramlab import rstats, stats, xsim


def test_tagged_line_filter_ignores_simulator_chatter():
    out = ("CFG K=32 R=6 N=39\nV 1 2 3\n- t.sv:10: Verilog $finish\n/x/t.sv:10: $finish called at 5 (1ps)\n"
           "%Error: boom\nRUN tag=1 cycles=195\n")
    assert xsim.tagged_lines(out) == ["CFG K=32 R=6 N=39", "V 1 2 3", "RUN tag=1 cycles=195"]


@needs_verilator
@needs_icarus
@pytest.mark.slow
def test_study_testbenches_identical_on_verilator_and_icarus():
    r = xsim.study_tb_check(quick=True)
    assert r["cases"] >= 6 and r["identical"] == r["cases"], [x for x in r["results"] if not x["identical"]]
    assert r["lines_compared"] > 20000


@needs_verilator
@needs_icarus
@pytest.mark.slow
def test_workaround_negative_control_reports_consistently():
    from sramlab import tools
    nc = xsim.workaround_negative_control()
    assert nc["verilator"] == tools.verilator()["version"]
    if nc["verilator"] == "5.020":
        # defect B is present on 5.020: without the workaround Verilator and Icarus must disagree
        assert nc["outputs_differ_without_workaround"], nc
        assert "cycles=" in nc["first_difference"]["verilator"]


@needs_rscript
def test_r_crosscheck_agrees_with_python():
    r = rstats.crosscheck(quick=True)
    assert r["status"] == "agree", r.get("comparison") or r.get("error")
    assert r["comparison"]["compared"] >= 150
    kinds = r["comparison"]["by_kind"]
    assert kinds["rep"]["max_rel_diff"] <= rstats.TOL_EXACT and kinds["ci.half_width"]["max_rel_diff"] <= rstats.TOL_TCI
    assert "kruskal_throughput_by_workload.p_value" in r["analysis_r"]["values"]


@needs_rscript
def test_r_comparator_can_fail():
    data = rstats.collect(replications=3, requests=60, sweep_banks=(2, 4), sweep_reps=2)
    k = next(k for k in data["python"] if k.endswith(".read_lat_p95"))
    data["python"][k] += 0.5                       # a wrong Python value must be caught
    rv = rstats.run_r(data)
    c = rstats.compare(data["python"], rv["values"])
    assert any(d["quantity"] == k for d in c["disagreements"])


def test_t_table_vs_exact_quantiles_documented_tolerance():
    # spot values of the exact Student-t 0.975 quantile (R qt): Python's table must be within the stated tolerance
    exact = {1: 12.7062047361747, 5: 2.57058183563631, 9: 2.26215716279820, 29: 2.04522964213270, 40: 2.02107539030627,
             100: 1.98397151852355}
    for df, q in exact.items():
        assert abs(stats.t_crit(df) - q) / q <= rstats.TOL_TCI, df


def test_r_unavailable_is_reported_not_substituted(monkeypatch):
    from sramlab import tools
    monkeypatch.setattr(tools, "rscript", lambda: None)
    r = rstats.run_r({"tx": [], "reps": [], "sweep": []})
    assert r["available"] is False and "not installed" in r["reason"]
