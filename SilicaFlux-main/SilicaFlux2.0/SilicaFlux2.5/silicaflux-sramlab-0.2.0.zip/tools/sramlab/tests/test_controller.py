"""Model behaviour against the figures the SRAMController RTL package MEASURED itself
(SRAMController P73 docs/02 'Measured throughput and latency', RTL counters)."""
import pytest
from sramlab.sim.controller import CtlParams
from sramlab.sim.driver import ReqSpec, ReadyMasks, run_scripts

def P(nm=4, nb=4, mo=1, lats=None, **kw):
    return CtlParams(num_masters=nm, num_banks=nb, data_width=32, bank_depth=64, max_out=mo, bank_lats=lats or [1]*nb, **kw)

def stream(p, m, n, bank_of):
    return [ReqSpec(0, (bank_of(m, k) + (k % p.bank_depth) * p.num_banks) * 4) for k in range(n)]

def run(p, scripts):
    return run_scripts(p, scripts, ReadyMasks(p.num_masters, 1.0, 1))

def thr(r):
    return r.perf_dict["global"]["ACCEPTED"] / r.cycles

def test_one_master_one_bank_half_rate():
    p = P(); sc = [stream(p, 0, 400, lambda m, k: 0)] + [[] for _ in range(3)]
    r = run(p, sc)
    assert thr(r) == pytest.approx(0.5, abs=0.01)          # RTL doc: 0.50 txn/cycle
    assert r.perf_dict["master"][0]["LAT_SUM"] / r.perf_dict["master"][0]["CMP"] == pytest.approx(2.0, abs=0.02)

def test_four_masters_one_bank_saturates_at_one():
    p = P(); r = run(p, [stream(p, m, 300, lambda m, k: 0) for m in range(4)])
    assert thr(r) == pytest.approx(1.0, abs=0.01)          # RTL doc: 1.00, bank saturated
    shares = [d["ACC"] for d in r.perf_dict["master"]]
    assert max(shares) - min(shares) <= 1                  # round robin: equal within one transaction

def test_private_banks_scale_linearly():
    p = P(); r = run(p, [stream(p, m, 300, lambda m, k: m) for m in range(4)])
    assert thr(r) == pytest.approx(2.0, abs=0.02)          # RTL doc: 2.00 (= 4 x 0.5)

def test_max_out_4_reaches_array_peak():
    p = P(mo=4); r = run(p, [stream(p, m, 400, lambda m, k: m) for m in range(4)])
    assert thr(r) == pytest.approx(3.99, abs=0.03)         # RTL doc: ~3.99 (peak 4)

@pytest.mark.parametrize("lat", [1, 2, 4])
def test_uncontended_latency_is_L_plus_1(lat):
    p = P(lats=[lat]*4); r = run(p, [[ReqSpec(0, 0)], [], [], []])
    t = r.tx
    assert t.push[0] + 1 - t.accept[0] == lat + 1

def test_credit_limit_matches_formula():
    # RTL doc: L=4, MAX_OUT=4, one master streaming across banks with UNIFORM_LAT -> 0.799 = MAX_OUT/(L+1)
    p = P(nm=1, mo=4, lats=[4]*4); r = run(p, [stream(p, 0, 500, lambda m, k: k % 4)])
    assert thr(r) == pytest.approx(0.8, abs=0.01)

def test_bank_lock_costs_throughput_when_latencies_differ():
    fast = run(P(nm=1, mo=4, lats=[2]*4), [stream(P(nm=1, nb=4), 0, 400, lambda m, k: k % 4)])
    lock = run(P(nm=1, mo=4, lats=[2]*4, uniform_lat=0), [stream(P(nm=1, nb=4), 0, 400, lambda m, k: k % 4)])
    assert thr(lock) < 0.7 * thr(fast)                     # RTL doc: 0.333 vs 0.998 at L=2

@pytest.mark.parametrize("hpl", [1, 4, 8])
def test_priority_floor_for_low_class(hpl):
    # RTL doc: the LOW class keeps at least 1/(HP_LIMIT+1) of a saturated bank (measured 20.1% at HP_LIMIT=4).
    # Needs MAX_OUT>=2 so the HIGH master can actually saturate the bank (with MAX_OUT=1 it offers only 0.5/cycle
    # and is fully served at 50%, so the guard never intervenes).  Window: 500 cycles, all masters contending.
    p = P(mo=2, prio_en=1, hp_mask=1, hp_limit=hpl)
    sc = [stream(p, m, 900, lambda m, k: 0) for m in range(4)]
    r = run_scripts(p, sc, ReadyMasks(4, 1.0, 1), fixed_cycles=500)
    acc = [d["ACC"] for d in r.perf_dict["master"]]
    assert sum(acc[1:]) / sum(acc) == pytest.approx(1 / (hpl + 1), abs=0.012)
    assert all(a > 0 for a in acc[1:])                       # no LOW master starves

def test_round_robin_without_priority_is_even():
    p = P(); r = run_scripts(p, [stream(p, m, 700, lambda m, k: 0) for m in range(4)], ReadyMasks(4, 1.0, 1), fixed_cycles=500)
    acc = [d["ACC"] for d in r.perf_dict["master"]]
    assert max(acc) - min(acc) <= 1

def test_data_integrity_with_mixed_traffic():
    from sramlab.sim.workloads import generate_scripts, make_ready
    from sramlab.config import load_config, controller_params
    cfg = load_config({"workload": {"kind": "mixed", "requests_per_master": 600, "seed": 4, "response_ready_rate": 0.6}})
    p = controller_params(cfg)
    r = run_scripts(p, generate_scripts(p, cfg["workload"]), make_ready(p, cfg["workload"]))
    assert r.integrity_errors == [] and r.drained and not r.sts_ovf and not r.sts_proto

def test_integrity_oracle_can_fail():
    from sramlab.sim.driver import check_integrity
    p = P(); r = run(p, [[ReqSpec(1, 0, 0xAA, 0xF), ReqSpec(0, 0)], [], [], []])
    assert check_integrity(p, r.tx) == []
    r.tx.rdata[1] ^= 1                                       # corrupt one read value
    assert len(check_integrity(p, r.tx)) == 1

def test_errors_have_no_side_effect():
    p = P(); sc = [[ReqSpec(1, 0, 0x11, 0xF), ReqSpec(1, 2, 0x99, 0xF), ReqSpec(1, 10**6, 0x77, 0xF), ReqSpec(1, 0, 0x55, 0), ReqSpec(0, 0)], [], [], []]
    r = run(p, sc)
    assert [s for s in r.tx.status] == [0, 2, 1, 3, 0]       # OK, ALIGN, RANGE, MASK, OK
    assert r.tx.rdata[4] == 0x11                             # erroneous writes did not touch memory
