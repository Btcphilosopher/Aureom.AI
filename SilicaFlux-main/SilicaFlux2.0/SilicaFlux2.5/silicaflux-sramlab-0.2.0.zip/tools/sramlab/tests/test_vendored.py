import hashlib, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def test_vendored_rtl_unmodified():
    n = 0
    for pkg in ("p71_sramcore", "p73_sramcontroller"):
        d = os.path.join(ROOT, "rtl", "third_party", pkg)
        for line in open(os.path.join(d, "SHA256SUMS")):
            h, f = line.split()
            assert hashlib.sha256(open(os.path.join(d, f), "rb").read()).hexdigest() == h, f
            n += 1
    assert n >= 10
