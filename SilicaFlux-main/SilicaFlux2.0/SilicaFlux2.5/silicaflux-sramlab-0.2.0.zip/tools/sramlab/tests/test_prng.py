from sramlab.prng import SplitMix64

def test_splitmix64_reference_sequence():
    # published SplitMix64 reference outputs for seed 0
    r = SplitMix64(0)
    assert [r.next_u64() for _ in range(3)] == [0xE220A8397B1DCDAF, 0x6E789E6AA1B965F4, 0x06C45D188009454F]

def test_deterministic_and_fork_independent():
    a, b = SplitMix64(5), SplitMix64(5)
    assert [a.randbelow(1000) for _ in range(50)] == [b.randbelow(1000) for _ in range(50)]
    f0, f1 = SplitMix64(5).fork(0), SplitMix64(5).fork(1)
    assert [f0.next_u64() for _ in range(4)] != [f1.next_u64() for _ in range(4)]

def test_randbelow_unbiased_range():
    r = SplitMix64(1)
    xs = [r.randbelow(7) for _ in range(7000)]
    assert set(xs) == set(range(7))
    assert all(800 < xs.count(v) < 1200 for v in range(7))
