"""Regressions for failures found by running the suite from an UNZIPPED copy placed under /tmp (cold caches)."""
import os, shutil, pytest
from conftest import needs_yosys
from sramlab.studies import ecc


@needs_yosys
def test_ecc_yosys_works_when_rtl_lives_outside_home(tmp_path, monkeypatch):
    # yowasp-yosys (WASI) cannot open absolute paths under /tmp; the ECC study used to pass them and every
    # logic-cost number silently became 'unavailable' for a package unzipped there.
    src = os.path.dirname(ecc.CODEC_RTL[0])
    for d in {os.path.dirname(f) for f in ecc.CODEC_RTL} | set(ecc.INCS):
        shutil.copytree(d, tmp_path / os.path.basename(d), dirs_exist_ok=True)
    files = [str(tmp_path / os.path.basename(os.path.dirname(f)) / os.path.basename(f)) for f in ecc.CODEC_RTL]
    incs = [str(tmp_path / os.path.basename(d)) for d in ecc.INCS]
    monkeypatch.setattr(ecc, "INCS", incs)
    r = ecc.yosys_generic("sf_ecc_enc", {"K": 32}, files)
    assert r["provenance"] == "synthesized", r
    assert r["value"]["total_cells"] > 50


def test_datasets_are_written_only_on_request(tmp_path):
    from sramlab import cli
    before = {f: os.path.getmtime(os.path.join(cli.__file__.rsplit("sramlab", 1)[0], "data", f))
              for f in ("rtl_verification.json", "optimise.json") if os.path.exists(os.path.join(cli.__file__.rsplit("sramlab", 1)[0], "data", f))}
    # a subset rtlcheck without --dataset must not touch the committed dataset
    from sramlab import verify
    import types
    orig = verify.case_list
    verify.case_list = lambda quick=False: [("base_4m4b", "mixed_bp")]
    try:
        from sramlab import tools
        if tools.verilator() is not None:
            assert cli.main(["--out", str(tmp_path), "--quiet", "rtlcheck", "--requests", "60"]) == 0
    finally:
        verify.case_list = orig
    after = {f: os.path.getmtime(os.path.join(cli.__file__.rsplit("sramlab", 1)[0], "data", f)) for f in before}
    assert before == after


# ------------------------------------------------------------------ cold-cache build races (found by the unzipped-copy run)
import threading
from conftest import needs_verilator


def _race(fn, n=4):
    out = []
    def go():
        try:
            out.append(fn())
        except Exception as e:                     # noqa: BLE001
            out.append("ERR " + str(e)[:300])
    ts = [threading.Thread(target=go) for _ in range(n)]
    [t.start() for t in ts]; [t.join() for t in ts]
    return out


@needs_verilator
def test_concurrent_cold_builds_of_the_controller_testbench_do_not_race(tmp_path, monkeypatch):
    from sramlab import rtlrun, verify
    monkeypatch.setattr(rtlrun, "BUILD_ROOT", str(tmp_path / "b1"))
    p = verify.param_sets()["2m2b"]
    res = _race(lambda: rtlrun.build(p))
    assert not any(str(r).startswith("ERR") for r in res), res
    assert len(set(res)) == 1 and os.path.exists(res[0])


@needs_verilator
def test_concurrent_cold_builds_of_the_ecc_testbench_do_not_race(tmp_path, monkeypatch):
    monkeypatch.setattr(ecc, "BUILD_ROOT", str(tmp_path / "b2"))
    res = _race(lambda: ecc.codec_exe(32, jobs=1))
    assert not any(str(r).startswith("ERR") for r in res), res
    assert len(set(res)) == 1 and os.path.exists(res[0])
