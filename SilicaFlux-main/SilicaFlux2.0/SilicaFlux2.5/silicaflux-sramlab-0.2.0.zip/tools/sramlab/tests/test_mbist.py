"""MBIST evaluation tests (sramlab.studies.mbist): independent Python March simulator vs the P78 RTL and vs P78's committed
coverage numbers, exact cycle model, sequential-bank behaviour, failure registers, test-mode overhead, analytical parallel model.

Every coverage assertion is about "coverage of the injected fault model in simulation; this is NOT manufacturing/physical defect
coverage".  Verilator builds are cached under ``sramlab.rtlrun.BUILD_ROOT`` (first run ~1 minute, later runs seconds).
Run:  python3 -m pytest tests/test_mbist.py
"""
from __future__ import annotations

import copy
import json

import warnings

import pytest

warnings.filterwarnings("ignore", category=pytest.PytestUnknownMarkWarning)   # `slow` is documented in the module docstring

from sramlab import tools
from sramlab.provenance import LABELS
from sramlab.studies import mbist as M

needs_verilator = pytest.mark.skipif(tools.verilator() is None, reason="Verilator not installed")


@pytest.fixture(scope="module")
def inst48():
    """Exhaustive 4 rows x 8 bits population through the independent Python simulator (about a second)."""
    pop = M.fault_population(4, 8, 1)
    sim = M.simulate_population(4, 8, pop)
    return pop, sim, M.tally(pop, sim)


# ------------------------------------------------------------------------------------------------ algorithm definitions
def test_operation_counts_are_10n_and_5n():
    assert M.ops_per_word(M.ALG_MARCH_CM) == 10 and M.ops_per_word(M.ALG_MATS_P) == 5
    for rows in (4, 16, 37):
        assert M.run_march(rows, 8, M.ALG_MARCH_CM, M.PAT_ALL0, False, None)["ops"] == 10 * rows
        assert M.run_march(rows, 8, M.ALG_MATS_P, M.PAT_ALL0, False, None)["ops"] == 5 * rows
        assert M.run_march(rows, 8, M.ALG_MARCH_CM, M.PAT_ALL0, False, None)["det"] is False      # fault-free: no false alarm
    assert M.run_march(16, 32, M.ALG_MARCH_CM, M.PAT_ALL0, True, None)["ops"] == 16 * 10 * M.stripe_passes(32) == 16 * 10 * 6


def test_python_march_locates_single_cell_faults_exactly():
    r = M.run_march(16, 8, M.ALG_MARCH_CM, M.PAT_ALL0, False, M.Fault(M.SAF, 5, 3, 0, 0, 1, 0))
    assert r["det"] and r["first"]["row"] == 5 and r["first"]["bit"] == 3 and r["first"]["bit_v"] and r["first"]["elem"] == 1 and r["count"] == 3
    r = M.run_march(16, 8, M.ALG_MARCH_CM, M.PAT_ALL0, False, M.Fault(M.SAF, 5, 3, 0, 0, 0, 0))
    assert r["first"]["elem"] == 2 and r["count"] == 2                                              # SA0 shows first in U(r1,w0)


# ------------------------------------------------------------------------------------------------ coverage numbers
def test_python_simulator_reproduces_p78_committed_counts_4x8(inst48):
    pop, sim, tal = inst48
    ref = [c for c in M.p78_committed() if (c["rows"], c["width"]) == (4, 8)][0]
    assert len(pop) == 10088
    for r in ref["data"]:
        e = tal[(r["cls"], r["scope"])]
        assert e["total"] == r["total"], r
        assert e["detected"][r["cfg"]] == r["detected"], r
        if r["scope"] == "cell":
            assert e["located"][r["cfg"]] == r["located"], r


def test_coverage_numbers_in_documented_ranges(inst48):
    pop, sim, tal = inst48

    def pct(cls, scope, cfg):
        e = tal[(cls, scope)]
        return 100.0 * e["detected"][cfg] / e["total"]
    # March C- (C0..C3): SAF, TF, address-decoder and every inter-word coupling fault 100 %  (van de Goor; P78 reports/coverage.md)
    for cfg in range(4):
        for cls, sc in tal:
            if sc in ("cell", "row", "row pair", "inter-word pair"):
                assert pct(cls, sc, cfg) == 100.0, (cfg, cls, sc)
    # MATS+ is weaker by construction: misses TF-down and half of the inter-word coupling variants
    assert pct("TF_down", "cell", 4) == 0.0 and pct("TF_up", "cell", 4) == 100.0
    assert pct("CFin_down", "inter-word pair", 4) == 50.0
    # same-word coupling: the weak spot of solid / checkerboard backgrounds (all 10 variants combined)
    def intra(cfg):
        d = sum(e["detected"][cfg] for (c, s), e in tal.items() if s == "intra-word pair")
        t = sum(e["total"] for (c, s), e in tal.items() if s == "intra-word pair")
        return 100.0 * d / t
    assert intra(0) == pytest.approx(60.0) and intra(1) == pytest.approx(60.0)
    assert 80.0 <= intra(2) <= 83.0                        # solid U checkerboard (MemoryCore measured 80.65 % at 4x32)
    assert intra(3) == pytest.approx(100.0)                # background sweep
    assert intra(4) == pytest.approx(40.0)
    weak = ("CFid_up_f1", "CFid_down_f0", "CFst_a0_v0", "CFst_a1_v1")
    assert all(tal[(c, "intra-word pair")]["detected"][0] == 0 for c in weak)                      # solid cannot excite them at all


def test_negative_control_mutated_algorithm_is_detected(inst48, monkeypatch):
    """A deliberately wrong March (the final B(r0) element dropped, and a flipped polarity) must disagree with P78's committed numbers."""
    pop, _, good = inst48
    ref = [c for c in M.p78_committed() if (c["rows"], c["width"]) == (4, 8)][0]
    wrong = copy.deepcopy(M.MARCH_ELEMENTS)
    wrong[M.ALG_MARCH_CM] = wrong[M.ALG_MARCH_CM][:-1]
    monkeypatch.setattr(M, "MARCH_ELEMENTS", wrong)
    sim = M.simulate_population(4, 8, pop, configs=[M.CONFIGS[0]])
    tal = M.tally(pop, sim, ncfg=1)
    diffs = [r for r in ref["data"] if r["cfg"] == 0 and tal[(r["cls"], r["scope"])]["detected"][0] != r["detected"]]
    assert diffs, "a March C- without its last read element must lose some committed detections"


def test_march_c_minus_reproduces_memorycore_committed_4x32_campaign_and_the_matsplus_difference_is_explained():
    """MemoryCore's own exhaustive 4x32 campaign (its engine + its fault models): March C- solid / checkerboard / union per class."""
    pop = M.fault_population(4, 32, 1)
    sim = M.simulate_population(4, 32, pop, configs=M.CONFIGS[:3])
    cmp_ = M.memorycore_committed_comparison(M.tally(pop, sim, ncfg=3), labels=("march_c-_4x32_exhaustive",))
    assert cmp_["march_c-_4x32_exhaustive"]["compared_cells"] == 81 and cmp_["march_c-_4x32_exhaustive"]["differences"] == 0
    # the one place the two committed campaigns differ (MATS+ checkerboard TF-down) follows from the pre-state of the second run
    d = M.tf_down_prestate_demonstration(4, 8)["value"]
    assert d["cells"] == 32 and d["solid_only_detected"] == 0
    assert d["checkerboard_from_all_zero_state_detected"] == 16                  # P78 harness: only the cells with B = 1 see a failing 1 -> 0 write
    assert d["checkerboard_after_re_init_through_faulty_array_detected"] == 32    # MemoryCore flow: stale 1 makes every cell detectable


@needs_verilator
def test_rtl_agrees_with_python_simulator_fault_by_fault():
    pop = M.fault_population(4, 8, 5)                      # every cell/AF fault, every 5th coupling pair (about 2k faults)
    sim = M.simulate_population(4, 8, pop)
    rtl = M.rtl_population(4, 8, pop)
    cmp_ = M.compare_sim_rtl(sim, rtl)
    assert cmp_["compared"] == len(pop) * len(M.CONFIGS) and cmp_["mismatches"] == 0, cmp_["first_mismatches"]
    # and the comparison can fail: corrupt one python record
    bad = copy.deepcopy(sim)
    i = next(i for i, per in enumerate(bad) if per[0] is not None)
    bad[i][0]["count"] += 1
    assert M.compare_sim_rtl(bad, rtl)["mismatches"] == 1


@needs_verilator
def test_coverage_instance_matches_p78_committed_and_carries_the_mandatory_wording():
    r = M.coverage_instance(4, 8, 1, run_rtl=True)
    assert r["rtl_vs_python_per_fault"]["value"]["mismatches"] == 0
    assert r["p78_committed_comparison"]["value"]["differences"] == 0 and r["p78_committed_comparison"]["value"]["compared_cells"] == 140
    assert M.COVERAGE_STATEMENT == "coverage of the injected fault model in simulation; this is NOT manufacturing/physical defect coverage"
    assert r["coverage_statement"] == M.COVERAGE_STATEMENT
    for row in r["table"]:
        for cell in row["configs"].values():
            assert cell["provenance"] == "rtl_simulated" and cell["note"] == M.COVERAGE_STATEMENT
    for grp in r["by_algorithm_and_group"].values():
        for cell in grp.values():
            assert cell["note"] == M.COVERAGE_STATEMENT
    for cell in r["same_word_coupling_summary"].values():
        assert cell["note"] == M.COVERAGE_STATEMENT


# ------------------------------------------------------------------------------------------------ cycles
@needs_verilator
def test_cycle_counts_exact_model_and_sequential_banks():
    r = M.cycle_section((2, 4), 64, 32, quick=True)
    assert r["calibration"]["acq_cycles"] > 0
    assert len(r["runs"]) >= 8 and any(x["sweep"] and x["passes"] == 6 for x in r["runs"])     # the background sweep (6 passes at 32 b) is in the validated set
    for x in r["runs"]:
        k = M.ALGO_OPS_PER_WORD[x["algo"]]
        assert x["run_cycles"] == k * x["window"] * x["banks"] * x["passes"]        # RUN state: exactly 10 N B / 5 N B operations (x passes for the sweep)
        assert x["refined_model_error_cycles"] == 0                                  # exact overhead model, calibrated on ANOTHER run
        assert x["cycles"] == x["phase_sum"]                                         # every cycle attributed to a state
        assert x["ops_only_model_error_pct"] > 0 and x["cycles"] > x["ops_only_model"]     # the plain 10N model underestimates
        assert x["max_sel_w"] == 1                                                   # one bank at a time
        assert M.order_list(x["order"], x["order_n"]) == list(range(x["banks"]))      # ascending bank order
        assert x["result"] == 1 and x["tested"] == (1 << x["banks"]) - 1             # PASS, every selected bank tested
        assert x["bsel"] == x["banks"] and x["pinit"] == x["banks"] * x["passes"] and x["bend"] == x["banks"] * x["passes"]
    p78 = r["p78_cross_check"]
    assert p78["p78_documented_cycles"] == 194 and p78["busy_cycles_p78_convention"] == 194 and p78["cycles_start_to_done_flag"] == 195
    slopes = r["per_bank_slopes"]
    assert slopes["March C-_N64"]["cycles_per_added_bank"] == 10 * 64 + 4           # 10 N + LT + 3
    assert slopes["MATS+_N64"]["cycles_per_added_bank"] == 5 * 64 + 4
    # a wrong expectation is detected: the textbook 10N model is off by more than 1 % for a small bank
    small = [x for x in r["runs"] if x["window"] == 16 and x["banks"] == 1 and x["algo"] == M.ALG_MARCH_CM]
    if small:
        assert small[0]["ops_only_model_error_pct"] > 1.0


def test_refined_cycle_model_formula_values():
    # P78 docs/01 section 6 quotes 194 cycles for one 16-row bank (March C-, READ_LATENCY 1) = 160 operations + 34 overhead
    # 160 operations + 4 (BSEL, PINIT, DRAIN, BEND) + 6 (ACQ) + 22 (REL = ROWS + 6) + 3 = 195 by the start-pulse -> done-flag convention used here;
    # P78's own busy-cycle counter (which excludes the cycle in which `done` is first seen) gives 194 = 160 + 34 (docs/01 section 6)
    assert M.refined_cycle_model(1, 16, 16, 1, M.ALG_MARCH_CM, 6, 6) == 195
    assert M.refined_cycle_model(1, 16, 16, 1, M.ALG_MARCH_CM, 6, 6) - 1 == 160 + 34
    # per-pass overhead of the background sweep: each extra pass adds K*N + LT + 2 cycles (PINIT, RUN, DRAIN, BEND)
    one = M.refined_cycle_model(2, 32, 64, 1, M.ALG_MARCH_CM, 6, 6, passes=1)
    six = M.refined_cycle_model(2, 32, 64, 1, M.ALG_MARCH_CM, 6, 6, passes=6)
    assert six - one == 2 * 5 * (10 * 32 + 1 + 2)


def test_parallel_model_is_analytical_and_not_the_rtl():
    pm = M.parallel_model((2, 4, 8, 16), 256, 256, 1, M.ALG_MARCH_CM, 6, 6)
    for b in (2, 4, 8, 16):
        e = pm["by_banks"][f"B{b}"]
        assert e["sequential_cycles"]["provenance"] == "analytical" and e["parallel_cycles"]["provenance"] == "analytical"
        assert e["speedup"]["value"] > 1.0 and e["parallel_cycles"]["value"] < e["sequential_cycles"]["value"]
    # parallel time does not grow with the number of identical banks; sequential does
    assert pm["by_banks"]["B2"]["parallel_cycles"]["value"] == pm["by_banks"]["B16"]["parallel_cycles"]["value"]
    assert pm["by_banks"]["B16"]["sequential_cycles"]["value"] > 7 * pm["by_banks"]["B2"]["sequential_cycles"]["value"] * 0.9
    assert "NOT implemented in the RTL" in pm["by_banks"]["B2"]["parallel_cycles"]["source"]


# ------------------------------------------------------------------------------------------------ failure registers / overhead
@needs_verilator
def test_failure_registers_report_first_failure_and_match_python():
    r = M.failure_section((2, 4, 8, 16), 64, 32)
    assert r["all_match"], [s["scenario"] for s in r["scenarios"] if not s["rtl_matches_python"]]
    by = {s["scenario"]: s["rtl"]["value"] for s in r["scenarios"]}
    assert by["fault-free memory"]["result"] == "PASS" and by["fault-free memory"]["failure_count"] == 0
    f = by["SAF1 bank 5 (row 37, bit 5)"]
    assert f["result"] == "FAIL" and f["failure_count"] == 3
    ff = f["first_failure"]
    assert (ff["bank"], ff["row"], ff["bit"], ff["elem"]) == (5, 37, 5, 1)
    assert ff["expected"] == "0x00000000" and ff["observed"] == "0x00000020"
    two = by["two faulty banks (2 and 11): first record must come from bank 2"]
    assert two["first_failure"]["bank"] == 2 and two["banks_with_failures_mask"] == hex((1 << 2) | (1 << 11))   # sequential: lower bank first
    esc = by["same-word CFid_up_f1 bank 1, solid background (expected ESCAPE)"]
    assert esc["result"] == "PASS"                                         # an injected fault the solid-background March C- does not detect
    assert by["same-word CFid_up_f1 bank 1, background sweep (detected)"]["result"] == "FAIL"


@needs_verilator
def test_test_mode_overhead_with_functional_traffic():
    r = M.overhead_section((2, 4), 64, 32, quick=True)
    assert r["rows"]
    for row in r["rows"]:
        fm = row["functional_master"]
        assert fm["scoreboard_errors"]["value"] == 0                      # memory returned valid (re-initialised) to the functional master
        assert fm["requests_accepted_while_test_owned"]["value"] == 0      # no functional access during ownership
        ph = row["phase_cycles"]
        assert ph["reinitialisation"]["value"] == 64                       # the init engine rewrites ROWS rows, one per cycle
        assert row["access_protocol_overhead_cycles"]["value"] > ph["reinitialisation"]["value"]
        assert row["functional_unavailable_window_cycles"]["value"] > row["engine_run_cycles_test_operations"]["value"]
        assert sum(v["value"] for v in ph.values()) <= row["total_test_cycles"]["value"]
    tr = [x for x in r["rows"] if x["functional_traffic"]]
    assert tr and all(x["offered_functional_requests_lost_estimate"]["provenance"] == "analytical" for x in tr)
    assert r["quiesce_to_ownership_cycles"]["with_traffic_max"]["value"] >= r["quiesce_to_ownership_cycles"]["no_traffic"]["value"]


@needs_verilator
def test_real_controller_overhead_matches_the_memory_group_model_within_a_few_cycles():
    r = M.stack_overhead_section(64, 4, quick=True)
    by = {x["hungry_functional_master"]: x for x in r["rows"]}
    for x in by.values():
        assert x["result"] == "PASS" and x["one_bank_at_a_time"] and x["engine_run_cycles_test_operations"]["value"] == 10 * 64 * 4
        assert x["phase_cycles"]["reinitialisation"]["value"] == 64
        assert 0 <= x["difference_vs_p78_model_cycles"] <= 3             # the real controller adds only a cycle or two to the P78 model's count
    win = by[True]["functional_master_stalled_window_cycles"]["value"]
    assert win > by[True]["engine_run_cycles_test_operations"]["value"] and by[True]["functional_cycles_blocked"] >= win - 2   # hungry master: refused the whole window


@needs_verilator
def test_verilator_caveat_is_rerun_and_reported():
    r = M.caveat_section(quick=True)
    opts = {x["verilator_opt"] for x in r["runs"]}
    assert opts == {"default", "O0", "O3"}
    assert all(x["checks"] == 290 and x["stored_word_bits"] == 39 for x in r["runs"])     # P78 committed: 290 checks (ECC, 39-bit)
    o0 = next(x for x in r["runs"] if x["verilator_opt"] == "O0")
    assert o0["errors"] == 0 and o0["verdict"] == "PASS" and o0["cfst_type8_detected"]     # P78's own reference build always passes
    # the observation must state what THIS Verilator did -- never a conclusion carried over from another installation
    assert r["verilator_version"] and r["verilator_version"] in r["observation"]
    if r["all_pass_and_cfst_detected_in_every_build"]:
        assert "NOT reproduced" in r["observation"] and r["failing_builds"] == []
    else:
        assert "IS reproduced" in r["observation"] and r["failing_builds"] and "O0" not in r["failing_builds"]


# ------------------------------------------------------------------------------------------------ provenance
@needs_verilator
@pytest.mark.slow
def test_quick_study_end_to_end_labels_and_wording(tmp_path):
    res = M.run_mbist_study(banks=(2, 4), bank_depth=64, word_bits=32, outdir=str(tmp_path), quick=True)
    assert res["unavailable_items"] == []
    d = json.load(open(res["files"]["json"]))
    labels = set()

    def walk(o):
        if isinstance(o, dict):
            if "provenance" in o and "value" in o:
                labels.add(o["provenance"])
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(d)
    assert labels <= set(LABELS) and "measured" not in labels and {"rtl_simulated", "analytical"} <= labels
    assert d["test_cycles"]["cycle_model"]["max_abs_error_cycles"] == 0
    assert d["test_cycles"]["verified_one_bank_at_a_time"]["value"] is True
    assert d["failure_reporting"]["all_match"]
    # every row of the CSV that reports coverage carries the mandatory sentence
    import csv
    rows = list(csv.DictReader(open(res["files"]["csv"])))
    cov = [r for r in rows if r["metric"].startswith("coverage.")]
    assert len(cov) > 100 and all(M.COVERAGE_STATEMENT in r["note"] for r in cov)
    assert "NOT manufacturing/physical defect coverage" in json.dumps(d["coverage"])
