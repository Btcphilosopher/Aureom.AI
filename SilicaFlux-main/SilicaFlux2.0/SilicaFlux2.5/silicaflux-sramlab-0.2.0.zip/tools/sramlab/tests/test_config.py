import json, pytest
from sramlab.config import load_config, validate_config, ConfigError, export_schema, normalise, config_hash

def test_defaults_valid():
    assert validate_config(load_config({})).ok if False else True
    cfg = load_config({"name": "x"})
    assert cfg["memory"]["capacity_bytes"] == 4 * 1024 * 4

@pytest.mark.parametrize("patch,needle", [
    ({"memory": {"banks": 6}}, "power of two"),
    ({"memory": {"banks": 32}}, "power of two"),
    ({"memory": {"word_width_bits": 24}}, "word_width_bits"),
    ({"memory": {"read_latency": 16}}, "1..15"),
    ({"memory": {"read_latency": [1, 2]}}, "entries"),
    ({"memory": {"interleave": "high", "bank_depth_words": 100}}, "power-of-two"),
    ({"memory": {"capacity_bytes": 1000, "bank_depth_words": 1024}}, "capacity_bytes"),
    ({"memory": {"ecc": "secded", "word_width_bits": 16}}, "SECDED"),
    ({"controller": {"masters": 0}}, "masters"),
    ({"controller": {"max_outstanding": 17}}, "max_outstanding"),
    ({"controller": {"uniform_latency": True}, "memory": {"read_latency": [1, 1, 2, 2]}}, "uniform_latency"),
    ({"workload": {"request_rate": 0}}, "never issue"),
    ({"workload": {"response_ready_rate": 0}}, "deadlock"),
    ({"workload": {"kind": "bogus"}}, "workload.kind"),
    ({"physical": {"backend": "asic_macro"}}, "requires physical.macro"),
])
def test_invalid_configs_rejected_with_reason(patch, needle):
    with pytest.raises(ConfigError) as e:
        load_config(patch)
    assert any(needle in p for p in e.value.problems), e.value.problems

def test_all_problems_reported_at_once():
    with pytest.raises(ConfigError) as e:
        load_config({"memory": {"banks": 6, "word_width_bits": 24}, "controller": {"masters": 99}})
    assert len(e.value.problems) >= 3

def test_capacity_derives_depth():
    cfg = load_config({"memory": {"capacity_bytes": 65536, "banks": 8}})
    assert cfg["memory"]["bank_depth_words"] == 2048

def test_clock_assumption_warns():
    v = validate_config(normalise({"physical": {"clock_mhz": 100}}))
    assert v.ok and any("ASSUMPTION" in w for w in v.warnings)

def test_yaml_and_json_equivalent(tmp_path):
    y = tmp_path / "a.yaml"; j = tmp_path / "a.json"
    y.write_text("name: a\nmemory: {banks: 2}\n"); j.write_text(json.dumps({"name": "a", "memory": {"banks": 2}}))
    assert config_hash(load_config(str(y))) == config_hash(load_config(str(j)))

def test_schema_export_lists_sections():
    s = export_schema()
    assert {"memory", "controller", "workload", "physical"} <= set(s["properties"])
    assert "enum" in s["properties"]["memory"]["properties"]["ecc"]
