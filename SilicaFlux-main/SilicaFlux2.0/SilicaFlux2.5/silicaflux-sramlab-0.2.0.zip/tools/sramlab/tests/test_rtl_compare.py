import pytest
from conftest import needs_verilator
from sramlab import verify, rtlrun

pytestmark = needs_verilator

CASES = [("base_4m4b", "mixed_bp"), ("4m4b_prio", "contention"), ("4m4b_mo4_lat1234", "illegal_mix"),
         ("4m4b_mo4_lat2", "flush_mix"), ("4m16b_mo4", "rand_read"), ("4m4b_high", "vector")]

@pytest.mark.parametrize("pname,wname", CASES)
def test_model_equals_rtl_cycle_by_cycle(pname, wname):
    v = verify._run_case((pname, wname, 150, 3))
    assert v["ok"], v
    assert v["cycles_compared"] > 50 and v["counters_compared"] >= 112 and not v["config_mismatch"]

def test_comparator_detects_broken_models():
    res = verify.mutation_check(n_req=120)
    assert len(res) == 4
    assert all(r["detected"] for r in res), res

def test_rtl_effective_config_reported_and_checked():
    p, sc, rd, _ = verify.build_case("16m16b", "rand_read", 40, 1)
    v = rtlrun.compare(p, sc, rd)
    assert v["rtl_effective_config"]["uniform"] == "1" and v["config_mismatch"] == []

def test_64bit_latency_vector_passed_intact():
    # regression test for the -G truncation bug found by the 16-bank comparison
    assert rtlrun._gval("LATS", 0x1111111111111111) == "64'h1111111111111111"
