import json, os, pytest
from sramlab import cli, record
from sramlab.studies import vector as V, tensor_study as T
from sramlab.sim.tensor import TensorSystem, TensorCfg
from sramlab.sim.controller import CtlParams
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def test_p76_rtl_crosscheck_exact():
    x = V.p76_crosscheck()
    v = x["value"]
    assert x["provenance"] == "rtl_simulated"
    assert v["rows_checked"] >= 50 and v["cycles_exact_match"] == v["rows_checked"] and v["max_abs_cycle_error"] == 0
    assert v["word_access_count_match"].split("/")[0] == v["word_access_count_match"].split("/")[1]

def test_p76_crosscheck_detects_corruption(tmp_path):
    src = open(os.path.join(V.IMPORTED, "p76_bench.csv")).read().splitlines()
    hdr = src[0].split(","); ci = hdr.index("cycles")
    out = [src[0]]
    for ln in src[1:]:
        f = ln.split(",")
        if f[hdr.index("workload")] == "seq_load_aligned": f[ci] = str(int(f[ci]) + 1)
        out.append(",".join(f))
    p = tmp_path / "bad.csv"; p.write_text("\n".join(out))
    v = V.p76_crosscheck(str(p))["value"]
    assert v["cycles_exact_match"] < v["rows_checked"] and v["mismatches"]

def _tp(nb, mo, cap=65536): return CtlParams(num_masters=4, num_banks=nb, data_width=32, bank_depth=cap // (4 * nb), max_out=mo, bank_lats=[1] * nb)

def test_tensor_mac_accounting_and_limits():
    r = TensorSystem(_tp(16, 8), TensorCfg(M=8, N=8, K=32, lda=36, ldb=12, a_stage=16, b_stage=16)).run()
    assert r.macs == 8 * 8 * 32 and r.slices == (8 // 4) * (8 // 4) * 32
    assert 0.5 < r.mac_utilisation <= 1.0 and not r.notes
    assert r.required_operand_bytes_per_cycle == 8.0

def test_tensor_single_bank_is_memory_limited_and_credits_matter():
    one = TensorSystem(_tp(1, 4), TensorCfg(M=8, N=8, K=32)).run()
    many = TensorSystem(_tp(8, 4), TensorCfg(M=8, N=8, K=32, lda=36, ldb=12)).run()
    mo1 = TensorSystem(_tp(8, 1), TensorCfg(M=8, N=8, K=32, lda=36, ldb=12)).run()
    assert one.mac_utilisation < 0.6 * many.mac_utilisation
    assert mo1.mac_utilisation < 0.65 * many.mac_utilisation     # MAX_OUT=1 starves regardless of banks

def test_tensor_chunked_stream_matches_tc08_traffic_definition():
    s = T.run_chunked_stream(banks=(2,))
    assert s["bytes_per_mac"] == pytest.approx(0.5, abs=0.001)    # 512 B per 1024 MAC (TC08 LOAD_A+LOAD_B per chunk)

def test_optimiser_reports_ties_and_never_one_universal_winner():
    from sramlab import optimise as O
    sp = {"banks": [2, 8], "interleave": ["low"], "max_out": [1, 4], "read_latency": [1], "word_bits": [32], "arbitration": ["round_robin"]}
    r = O.evaluate(sp, n_req=150, replications=2)
    d = r["goals"]["D_lowest_energy_per_useful_byte_ACTIVITY_PROXY"]
    assert d["n_tied"] == len(r["candidates"]) and d["discriminates"] is False   # proxy cannot rank organisations
    assert r["goals"]["C_lowest_area"].startswith("unavailable")
    assert any("AREA IS NOT PART" in c for c in r["caveats"])

def test_cli_end_to_end(tmp_path, capsys):
    out = str(tmp_path)
    cfg = os.path.join(ROOT, "configs", "four_bank_baseline.yaml")
    assert cli.main(["--out", out, "validate", cfg]) == 0
    assert cli.main(["--out", out, "simulate", cfg, "--export"]) == 0
    assert cli.main(["--out", out, "benchmark", cfg, "--replications", "3"]) == 0
    assert cli.main(["--out", out, "verify-repro", cfg]) == 0
    hist = record.load_history(out)
    assert [h["command"] for h in hist] == ["simulate", "benchmark"]
    rec = json.load(open(os.path.join(out, hist[0]["experiment_id"] + ".json")))
    for k in ("experiment_id", "git", "environment", "seed", "workload", "clock_assumptions", "technology",
              "performance_counters", "timing_results", "power_provenance", "result_hash", "config_hash"):
        assert k in rec, k
    assert rec["clock_assumptions"]["provenance"] == "unavailable" and rec["timing_results"]["status"] == "unavailable"
    assert os.path.exists(os.path.join(out, "four_bank_baseline_transactions.csv"))

def test_cli_rejects_invalid_config(tmp_path):
    bad = tmp_path / "bad.yaml"; bad.write_text("memory: {banks: 3}\n")
    assert cli.main(["validate", str(bad)]) == 1
    assert cli.main(["--out", str(tmp_path), "simulate", str(bad)]) == 2

def test_results_reproducible_across_runs():
    from sramlab import experiments as E
    from sramlab.config import load_config
    cfg = load_config({"workload": {"kind": "mixed", "seed": 5, "requests_per_master": 300, "response_ready_rate": 0.7}})
    h = [record.result_hash(E.run_once(cfg)[1]) for _ in range(2)]
    assert h[0] == h[1]
    cfg2 = load_config({"workload": {"kind": "mixed", "seed": 6, "requests_per_master": 300, "response_ready_rate": 0.7}})
    assert record.result_hash(E.run_once(cfg2)[1]) != h[0]
