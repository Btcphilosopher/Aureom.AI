#!/usr/bin/env python3
"""
compare_cluster.py - a hand-assembled SilicaFlux PROGRAM runs in the full (patched) cluster:
  imem -> fetch -> decoder (D-format) -> control core -> scheduler -> sfgx_gfx_tile (tile slot 3) -> framebuffer
and the resulting framebuffer must equal the reference model's framebuffer for the equivalent token stream.
"""
import os, subprocess, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.abspath(os.path.join(HERE, '..'))
sys.path.insert(0, os.path.join(ROOT, 'ref')); sys.path.insert(0, HERE)
import sfgx_ref as R

def main(W=32, H=32):
    out = os.path.join(ROOT, 'results', 'cluster'); os.makedirs(out, exist_ok=True)
    info = subprocess.check_output([sys.executable, os.path.join(ROOT, 'tools', 'mk_cluster_prog.py'), out]).decode().strip()
    exe = os.path.join(ROOT, 'sim', f'cluster_obj_{W}x{H}', 'sfgx_cluster')
    subprocess.check_call([os.path.join(ROOT, 'sim', 'build_cluster.sh'), str(W), str(H)], stdout=subprocess.DEVNULL)
    r = subprocess.run([exe, os.path.join(out, 'cluster_triangle.hex'), out], capture_output=True, text=True, timeout=900)
    if r.returncode: raise RuntimeError(r.stdout + r.stderr)
    got = np.fromfile(os.path.join(out, 'final.col'), dtype='<u4').reshape(H, W)
    ref = R.run_cmd(os.path.join(out, 'cluster_triangle.cmd'), W, H)
    exp = ref['captures']['final'][0]
    m = ref['model']
    nonbg = int((exp != 0x002030).sum())
    ok = np.array_equal(got, exp) and nonbg > 100
    print(f"[{'PASS' if ok else 'FAIL'}] full cluster, hand-assembled SilicaFlux program ({info}): "
          f"{r.stdout.strip().split(',')[-1].strip()}; framebuffer == reference ({int((got == exp).sum())}/{got.size} px, "
          f"{nonbg} px drawn, {m.cnt['pix_written']} written)")
    if not ok:
        d = np.nonzero(got != exp)
        print("      first differing pixel:", (int(d[1][0]), int(d[0][0])) if len(d[0]) else None, "| got non-clear px:", int((got != 0x002030).sum()),
              "| unique colours got:", sorted({hex(int(v)) for v in got.ravel()})[:6])
    return ok

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
