#!/usr/bin/env python3
"""
compare_rtl.py - replay one scene through BOTH the bit-accurate software reference
and the Verilator RTL model, and require bit-exact agreement on:
   * every token result and error flag       (incl. GFXSTAT counters, GFXRD pixels)
   * the sequence of post-clip screen-space triangles entering setup
   * colour buffer, depth buffer and per-pixel coverage counts at every CAPTURE
usage: compare_rtl.py <scene> <W> <H> [--keep]
"""
import os, subprocess, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, '..')
sys.path.insert(0, os.path.join(ROOT, 'ref')); sys.path.insert(0, HERE)
from sfgx_ref import SfgxModel, parse_cmd
import mktok


def stale(exe, extra=()):
    """True if the simulator binary is missing or older than any RTL / testbench / baseline source."""
    if not os.path.exists(exe): return True
    t = os.path.getmtime(exe)
    srcs = [os.path.join(dp, f) for d in ('rtl', 'tb', 'third_party') for dp, _, fs in os.walk(os.path.join(ROOT, d)) for f in fs
            if f.endswith(('.sv', '.cpp', '.vlt'))]
    rtl_dir = os.environ.get('SFGX_RTL_DIR')
    if rtl_dir: srcs += [os.path.join(rtl_dir, f) for f in os.listdir(rtl_dir)]
    return any(os.path.getmtime(f) > t for f in srcs)


def run_reference(cmd, W, H):
    m = SfgxModel(W, H)
    caps, results, i = {}, [], 0
    for it in parse_cmd(cmd):
        if it[0] == 'CAPTURE':
            caps[it[1]] = (m.color.copy(), m.depth.copy(), m.cov_count.astype(np.int64).copy())
            m.cov_count[:] = 0
        else:
            _, op, addr, scalar, vec, length = it
            res, err = m.token(op, addr, scalar, vec, length)
            results.append((op, res, int(err)))
    return m, caps, results


def run_rtl(scene, W, H, outdir):
    cmd = os.path.join(ROOT, 'scenes', scene + '.cmd'); tok = os.path.join(outdir, scene + '.tok')
    os.makedirs(outdir, exist_ok=True)
    mktok.convert(cmd, tok)
    exe = os.path.join(os.environ.get('SFGX_OBJ_ROOT', os.path.join(ROOT, 'sim')), f'obj_{W}x{H}', f'sfgx_sim_{W}x{H}')
    if stale(exe):
        subprocess.check_call([os.path.join(ROOT, 'sim', 'build.sh'), str(W), str(H)], stdout=subprocess.DEVNULL)
    out = subprocess.run([exe, tok, outdir], capture_output=True, text=True, timeout=int(os.environ.get('SFGX_TIMEOUT', '900')))
    if out.returncode: raise RuntimeError(f"harness failed: {out.stdout}{out.stderr}")
    return out.stdout.strip()


def compare(scene, W, H, outdir=None, verbose=True):
    outdir = outdir or os.path.join(os.environ.get('SFGX_OUT_ROOT', os.path.join(ROOT, 'results', 'rtl_runs')), f'{scene}_{W}x{H}')
    cmd = os.path.join(ROOT, 'scenes', scene + '.cmd')
    m, caps, ref_results = run_reference(cmd, W, H)
    info = run_rtl(scene, W, H, outdir)
    problems = []
    # ---- token results -------------------------------------------------------------
    rtl_tok = [tuple(int(x, 16) if i < 2 else int(x) for i, x in enumerate(l.split()[:3])) for l in open(os.path.join(outdir, 'tokens.txt'))]
    if len(rtl_tok) != len(ref_results): problems.append(f"token count rtl={len(rtl_tok)} ref={len(ref_results)}")
    bad_tok = [(i, r, t) for i, (r, t) in enumerate(zip(ref_results, rtl_tok)) if (r[0], r[1] & 0xFFFFFFFF, r[2]) != t]
    if bad_tok: problems.append(f"{len(bad_tok)} token result mismatches, first: token#{bad_tok[0][0]} ref(op,res,err)={bad_tok[0][1]} rtl={bad_tok[0][2]}")
    # ---- triangle trace -----------------------------------------------------------------
    rtl_tris = [tuple(int(x) for x in l.split()) for l in open(os.path.join(outdir, 'tris.txt'))]
    ref_tris = [tuple(v for vert in t for v in vert) for t in m.trace]
    if rtl_tris != ref_tris:
        n = next((i for i, (a, b) in enumerate(zip(rtl_tris, ref_tris)) if a != b), min(len(rtl_tris), len(ref_tris)))
        problems.append(f"triangle trace differs (rtl {len(rtl_tris)} vs ref {len(ref_tris)} tris), first diff at #{n}: "
                        f"rtl={rtl_tris[n] if n < len(rtl_tris) else None} ref={ref_tris[n] if n < len(ref_tris) else None}")
    # ---- captures ----------------------------------------------------------------------
    n_px = n_cap = 0
    for name, (rc, rz, rcov) in caps.items():
        col = np.fromfile(os.path.join(outdir, name + '.col'), dtype='<u4')
        z = np.fromfile(os.path.join(outdir, name + '.z'), dtype='<u2')
        cv = np.fromfile(os.path.join(outdir, name + '.cov'), dtype='<u2').astype(np.int64)
        n_cap += 1; n_px += W * H
        for label, a, b in (("colour", col, rc), ("depth", z, rz), ("coverage", cv, rcov)):
            d = np.nonzero(a.astype(np.int64) != b.astype(np.int64))[0]
            if len(d):
                p = int(d[0])
                problems.append(f"capture '{name}' {label}: {len(d)} px differ, first at ({p % W},{p // W}) rtl={int(a[p]):#x} ref={int(b[p]):#x}")
    ok = not problems
    if verbose:
        print(f"[{'PASS' if ok else 'FAIL'}] {scene:16s} {W}x{H}: {len(ref_results)} tokens, {len(ref_tris)} setup triangles, "
              f"{n_cap} captures ({n_px} px x colour/depth/coverage) | {info}")
        for p in problems[:8]: print("      -", p)
    return ok, problems


if __name__ == '__main__':
    scene, W, H = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    sys.exit(0 if compare(scene, W, H)[0] else 1)
