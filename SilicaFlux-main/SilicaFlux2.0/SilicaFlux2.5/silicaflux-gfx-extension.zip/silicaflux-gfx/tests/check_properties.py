#!/usr/bin/env python3
"""
check_properties.py - shared-edge / exactly-once coverage property test.

Oracle (independent of the rasteriser's edge-function / top-left code):
  for every pixel centre p and every triangle T of a mesh, classify p as
  strictly-inside / on-boundary / outside T using exact rational arithmetic
  (fractions.Fraction) on the Q8 window vertices.  Then, per mesh group:
     * p strictly inside exactly one triangle      -> coverage count must be 1
     * p strictly outside every triangle (and off every boundary) -> 0
     * p on a boundary that is INTERIOR to the union of the mesh  -> exactly 1
       (a shared edge or shared vertex: no gap, no double hit)
     * p on the OUTER boundary of the union        -> 0 or 1
  "interior to the union" is decided by probing 32 directions (offset by 0.0137 rad so none is parallel to a
  grid-aligned edge) at a distance of 2^-20 px with exact arithmetic.
Works on any coverage-count array: the Python model's (default) or the RTL's
(tests/check_properties.py --rtl-cov file.txt, produced by the Verilator harness).
"""
import math, os, sys
from fractions import Fraction as Fr
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'ref'))
import scenes
from sfgx_ref import SfgxModel, parse_cmd


def side(a, b, p):          # exact cross product (>0: p is to one side of a->b)
    return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])


def classify(tri, p):
    """'in' (strict), 'on' (boundary incl. vertices), 'out'  -- exact."""
    a, b, c = tri
    s = [side(a, b, p), side(b, c, p), side(c, a, p)]
    if all(v > 0 for v in s) or all(v < 0 for v in s): return 'in'
    if all(v >= 0 for v in s) or all(v <= 0 for v in s):
        # degenerate (zero-area) triangles have all s == 0 collinear: treat as boundary only if on the segment
        return 'on'
    return 'out'


EPS = Fr(1, 1 << 20)
DIRS = [(Fr(round(math.cos(2 * math.pi * k / 32 + 0.0137) * (1 << 20)), 1 << 20), Fr(round(math.sin(2 * math.pi * k / 32 + 0.0137) * (1 << 20)), 1 << 20)) for k in range(32)]


def run(cmd_path, W, H, groups, cov_from=None):
    m = SfgxModel(W, H)
    results = []
    for it in parse_cmd(cmd_path):
        if it[0] == 'CAPTURE':
            name = it[1]
            cov = (cov_from[name] if cov_from else m.cov_count.copy()).reshape(H, W)
            m.cov_count[:] = 0
            if name in groups: results.append((name, cov))
        else:
            _, op, addr, scalar, vec, length = it
            m.token(op, addr, scalar, vec, length)
    return results


def check(cov_by_group, groups, W, H, verbose=True):
    total_bad = 0
    for name, cov in cov_by_group:
        tris = []
        for tag, ts in groups[name]:
            for t in ts:
                tris.append(tuple((Fr(p[0], 256), Fr(p[1], 256)) for p in t))
        n_int = n_out = n_edge_int = n_edge_outer = bad = 0
        for y in range(H):
            for x in range(W):
                p = (Fr(2 * x + 1, 2), Fr(2 * y + 1, 2))
                cls = [classify(t, p) for t in tris]
                n_in = cls.count('in'); n_on = cls.count('on')
                c = int(cov[y, x])
                if n_in == 1:
                    n_int += 1; ok = (c == 1)
                elif n_in > 1:
                    ok = True            # overlapping meshes: not part of this test
                elif n_on == 0:
                    n_out += 1; ok = (c == 0)
                else:
                    inside_union = all(any(classify(t, (p[0] + EPS * dx, p[1] + EPS * dy)) == 'in' for t in tris) for dx, dy in DIRS)
                    if inside_union: n_edge_int += 1; ok = (c == 1)
                    else:            n_edge_outer += 1; ok = (c in (0, 1))
                if not ok:
                    bad += 1
                    if verbose and bad <= 5: print(f"  VIOLATION {name} pixel ({x},{y}) cov={c} in={n_in} on={n_on}")
        total_bad += bad
        print(f"{name:14s} interior-pixels={n_int:4d} outside={n_out:4d} shared-edge/vertex-pixels={n_edge_int:3d} "
              f"outer-boundary={n_edge_outer:3d} violations={bad}")
    return total_bad


if __name__ == '__main__':
    path = os.path.join(os.path.dirname(__file__), '..', 'scenes', 'shared_edges.cmd')
    groups, (W, H) = scenes.gen_shared_edges(path)
    bad = check(run(path, W, H, groups), groups, W, H)
    print("PROPERTY CHECK:", "PASS" if bad == 0 else f"FAIL ({bad} violations)")
    sys.exit(1 if bad else 0)
