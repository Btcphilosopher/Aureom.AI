#!/usr/bin/env python3
"""
check_float.py - cross-check the fixed-point specification (sfgx_ref.py) against
the ideal float64 rasteriser (sfgx_float_ref.py) on every scene.

PASS criterion per capture: 'unexplained' == 0, i.e. every differing pixel is
either within 0.02 px of a triangle edge (vertex quantisation) or differs by
<= 1 LSB (rounding).  Scenes that deliberately exercise saturation are listed
in EXPECTED_DIFFERENT and are only reported.
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'ref'))
from sfgx_ref import run_cmd
from sfgx_float_ref import run_float, compare

SCENES = None            # taken from scenes/manifest.json (every scene except the 640x480 stress scene)
EXPECTED_DIFFERENT = {"xform_saturation"}      # int model saturates; ideal model cannot

def main(only=None):
    import json
    bad = 0
    scenes = [(n, w, h) for n, w, h in json.load(open(os.path.join(HERE, '..', 'scenes', 'manifest.json'))) if (w, h) != (640, 480) and n != 'errors']
    for name, W, H in scenes:
        if only and name not in only: continue
        path = os.path.join(HERE, '..', 'scenes', name + '.cmd')
        r = run_cmd(path, W, H); f = run_float(path, W, H)
        agg = dict(differing=0, near_edge=0, lsb1_only=0, z_tie=0, tex_boundary=0, unexplained=0, pixels=0, maxc=0.0, maxd=0.0)
        worst = None
        for cap, (ic, idp) in r['captures'].items():
            fc, fd, ft, tie, tbnd = f[cap]
            s = compare(ic, idp, fc, fd, ft, W, H, tiemin=tie, texbnd=tbnd)
            if cap in EXPECTED_DIFFERENT:
                print(f"   (expected-different capture {cap}: differing={s['differing']})"); continue
            for k in ('differing', 'near_edge', 'lsb1_only', 'z_tie', 'tex_boundary', 'unexplained', 'pixels'): agg[k] += s[k]
            agg['maxc'] = max(agg['maxc'], s['max_colour_diff_away_from_edges'])
            agg['maxd'] = max(agg['maxd'], s['max_depth_diff_away_from_edges'])
            if s['unexplained'] and worst is None: worst = (cap, s)
        ok = agg['unexplained'] == 0
        bad += 0 if ok else 1
        print(f"{name:14s} captures={len(r['captures']):3d} pixels={agg['pixels']:8d} differing={agg['differing']:5d} "
              f"(near-edge {agg['near_edge']}, <=1LSB {agg['lsb1_only']}, z-tie {agg['z_tie']}, texel-boundary {agg['tex_boundary']}) unexplained={agg['unexplained']} "
              f"max|dColour| away from edges={agg['maxc']:.0f} max|dDepth|={agg['maxd']:.0f}  {'PASS' if ok else 'FAIL'}")
        if worst: print("    first failing capture:", worst)
    print("FLOAT CROSS-CHECK:", "PASS" if bad == 0 else f"FAIL ({bad} scenes)")
    return bad

if __name__ == '__main__':
    sys.exit(1 if main(sys.argv[1:] or None) else 0)
