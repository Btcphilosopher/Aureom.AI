#!/usr/bin/env python3
"""stimulus_coverage.py - which corner cases do the test scenes actually reach?
Instruments the reference model (no RTL involved) and counts clipper / setup events."""
import os, sys, collections
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'ref'))
import sfgx_ref as R

C = collections.Counter()
orig_clip, orig_setup = R.SfgxModel.clip_polygon, R.SfgxModel.setup_and_raster

def clip_polygon(self, poly):
    n_in = len(poly)
    for p in range(6):
        n = len(poly)
        if n == 0: C['poly_emptied_at_plane%d' % p] += 1; break
        out = []
        for i in range(n):
            P, Q = poly[(i - 1) % n], poly[i]
            dP, dQ = self.plane_dist(P, p), self.plane_dist(Q, p)
            pin, qin = dP >= 0, dQ >= 0
            if dP == 0: C['dP==0 (vertex exactly on plane)'] += 1
            if dQ == 0: C['dQ==0 (vertex exactly on plane)'] += 1
            if pin and not qin and dP == 0: C['in(d=0),out : intersection suppressed'] += 1
            if (not pin) and qin and dQ == 0: C['out,in(d=0): intersection suppressed'] += 1
            if pin and not qin and dP > 0: C['in,out intersection plane%d' % p] += 1
            if (not pin) and qin and dQ > 0: C['out,in intersection plane%d' % p] += 1
            def isect():
                s = abs(dP - dQ); t = (abs(dP) << 32) // s
                return tuple(P[k] + (((Q[k] - P[k]) * t + (1 << 31)) >> 32) for k in range(9))
            if pin and qin: out.append(Q)
            elif pin and not qin:
                if dP > 0: out.append(isect())
            elif (not pin) and qin:
                if dQ > 0: out.append(isect())
                out.append(Q)
        poly = out
        if len(poly) == 2: C['2-vertex degenerate polygon after plane %d' % p] += 1
    C['final polygon vertices = %d' % len(poly)] += 1
    # reuse the real implementation for the return value (and to be sure we mirror it)
    return orig_clip(self, [v for v in self._last_in])

def wrapped_clip(self, poly):
    self._last_in = list(poly)
    return clip_polygon(self, poly)
R.SfgxModel.clip_polygon = wrapped_clip

def setup(self, a, b, c):
    area2 = (b[0]-a[0])*(c[1]-a[1]) - (c[0]-a[0])*(b[1]-a[1])
    C['setup: area2==0 (degenerate)'] += area2 == 0
    C['setup: area2<0 (CCW as seen, swapped)'] += area2 < 0
    C['setup: area2>0 (CW as seen)'] += area2 > 0
    if area2:
        V = [a, b, c] if area2 > 0 else [a, c, b]
        for i in range(3):
            dx = V[(i+1)%3][0]-V[i][0]; dy = V[(i+1)%3][1]-V[i][1]
            if dy == 0: C['setup: horizontal edge (dy==0)'] += 1
            if dy == 0 and dx > 0: C['setup: top edge (dy==0,dx>0)'] += 1
            if dy < 0: C['setup: left edge (dy<0)'] += 1
    return orig_setup(self, a, b, c)
R.SfgxModel.setup_and_raster = setup

import json
SC = [(n, w, h) for n, w, h in json.load(open(os.path.join(HERE, '..', 'scenes', 'manifest.json'))) if (w, h) != (640, 480)]
agg = {}
for name, W, H in SC:
    C.clear()
    r = R.run_cmd(os.path.join(HERE, '..', 'scenes', name + '.cmd'), W, H)
    m = r['model']
    agg[name] = (dict(C), dict(m.cnt), m.flags)
tot = collections.Counter()
for name, (c, cnt, fl) in agg.items():
    for k, v in c.items(): tot[k] += v
    for k, v in cnt.items(): tot['counter:' + k] += v
for k in sorted(tot): print(f"{tot[k]:8d}  {k}")
print("sticky flags seen:", {n: hex(a[2]) for n, a in agg.items()})
