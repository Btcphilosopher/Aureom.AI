#!/bin/bash
# One-command verification of the SFGX extension (everything except the slow mutation campaign and the synthesis flow).
#   tests/run_all.sh            -> prints one PASS/FAIL line per stage, exit status 0 only if all pass
set -u
cd "$(dirname "$0")/.."
mkdir -p results
LOG=results/run_all.log; : > $LOG
fail=0
stage() { # name, command...
  local name="$1"; shift
  if "$@" >> $LOG 2>&1; then printf "[PASS] %s\n" "$name"; else printf "[FAIL] %s   (see %s)\n" "$name" "$LOG"; fail=1; fi
}
python3 ref/scenes.py scenes >/dev/null
stage "verilator lint -Wall (SFGX RTL + unmodified baseline modules)"       bash -c './sim/lint.sh 2>&1 | tee -a '"$LOG"' | grep -E "^%(Warning|Error)" && exit 1 || exit 0'
stage "constants: RTL package == reference (opcodes, registers, counters, formats)"   python3 tests/check_consts.py
stage "spec: shared edges covered exactly once (exact rational oracle)"     python3 tests/check_properties.py
stage "spec: fixed-point model vs float64 reference (all scenes)"           python3 tests/check_float.py
stage "spec: width claims enforced on all scenes + 2048^2 corner cases"     python3 tests/check_bounds.py
stage "spec: output clamps never active (adversarial slivers, 2048^2)"      python3 tests/clamp_stress.py 150
stage "RTL == reference, bit-exact, all scenes (Verilator)"                 python3 tests/run_regression.py
for s in "shared_edges 32 32" "clip_cases 32 32" "cull_depth 32 32" "errors 32 32" "texture 64 64"; do
  set -- $s; stage "scheduler-level: $1 via UNMODIFIED scheduler (plain)"        python3 tests/compare_sched.py $1 $2 $3
done
stage "scheduler-level: cull_depth, VADD on compute tile during draw + DFSYNC"    python3 tests/compare_sched.py cull_depth 32 32 interleave
stage "scheduler-level: texture, VADD on compute tile during draw + DFSYNC"       python3 tests/compare_sched.py texture 64 64 interleave
stage "display: token ROM -> engine -> scan-out -> captured VIDEO frame == reference, 640x480@60 timing" python3 tests/compare_display.py
stage "full cluster: hand-assembled SilicaFlux program draws a triangle (patched cluster)"          python3 tests/compare_cluster.py
[ $fail -eq 0 ] && echo "ALL STAGES PASSED" || echo "SOME STAGES FAILED"
exit $fail
