#!/usr/bin/env python3
"""check_bounds.py - the width claims of the numeric spec, enforced (not just argued).
 1. every scene of the regression runs through the reference with _chk() assertions armed;
 2. worst-case corner triangles on 2048x2048 (the maximum supported framebuffer) are drawn."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')
sys.path.insert(0, os.path.join(ROOT, 'ref'))
import numpy as np
import sfgx_ref as R

def main():
    man = json.load(open(os.path.join(ROOT, 'scenes', 'manifest.json')))
    for name, W, H in man:
        if (W, H) == (640, 480) and False: continue
        R.run_cmd(os.path.join(ROOT, 'scenes', name + '.cmd'), W, H)
    # ---- worst-case geometry at the maximum framebuffer size ---------------------------
    W = H = 2048
    m = R.SfgxModel(W, H)
    far = R.DEPTH_MAX * 256
    X, Y = W * 256, H * 256
    corners = [(0, 0), (X, 0), (0, Y), (X, Y)]
    cols = [(255 << 8, 0, 0), (0, 255 << 8, 0), (0, 0, 255 << 8)]
    for z0, z1 in ((0, far), (far, 0)):
        for (a, b, c) in ((0, 1, 2), (1, 3, 2), (0, 3, 1), (3, 0, 2), (2, 1, 0)):
            v = [(corners[i][0], corners[i][1], (z0, z1, (z0 + z1) // 2)[k], *cols[k]) for k, i in enumerate((a, b, c))]
            m.setup_and_raster(*v) if False else None
            # only the setup arithmetic is exercised (not the 4M-pixel scan): run with an empty bbox clamp
            area2 = (v[1][0]-v[0][0])*(v[2][1]-v[0][1]) - (v[2][0]-v[0][0])*(v[1][1]-v[0][1])
            if area2 == 0: continue
            if area2 < 0: v[1], v[2] = v[2], v[1]
            Vv = v
            dx = [Vv[(i+1)%3][0]-Vv[i][0] for i in range(3)]; dy = [Vv[(i+1)%3][1]-Vv[i][1] for i in range(3)]
            R._chk('area2 (corner triangles, 2048^2)', abs(area2), 39)
            for k in (2, 3, 4, 5):
                v0, v1, v2 = Vv[0][k], Vv[1][k], Vv[2][k]
                R._chk('gradient numerator (corner triangles)', max(abs(-(dy[1]*v0+dy[2]*v1+dy[0]*v2)), abs(dx[1]*v0+dx[2]*v1+dx[0]*v2)), 47)
            e0 = [dx[i]*(128 - Vv[i][1]) - dy[i]*(128 - Vv[i][0]) for i in range(3)]
            R._chk('edge start (corner triangles)', max(abs(e) for e in e0), 47)
    # transform accumulator at the extremes of Q16.16 operands
    mn, mx = -(1 << 31), (1 << 31) - 1
    for a in (mn, mx):
        for b in (mn, mx):
            R._chk('xform accumulator (extreme operands)', a*b + a*b + a*b + a*(1 << 16), 67)
    print("output-clamp activations over all regression scenes (covered pixels needing clamping):", R.CLAMP_HITS)
    print("WIDTH CLAIMS HOLD.  Largest bit-length observed per quantity:")
    for k, v in sorted(R.BOUNDS.items()): print(f"   {v:3d}  {k}")

if __name__ == '__main__':
    main()
