#!/usr/bin/env python3
"""
compare_display.py - end-to-end check of the display path (token ROM -> engine -> scan-out -> VIDEO STREAM).
The video frame captured from the pixel stream (de/r/g/b) must equal the reference model's framebuffer
replicated 4x4, and the timing must be the specified 640x480@60 raster (800x525 total, 96-clock hsync,
2-line vsync, 307200 DE pixels, 480 active lines).
usage: compare_display.py [scene] [W H]
"""
import os, subprocess, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.abspath(os.path.join(HERE, '..'))
sys.path.insert(0, os.path.join(ROOT, 'ref')); sys.path.insert(0, HERE)
import compare_rtl

def main(scene='demo_triangle', W=160, H=120):
    out = os.path.join(ROOT, 'results', 'display_run'); os.makedirs(out, exist_ok=True)
    rom = os.path.join(out, scene + '.rom')
    n = int(subprocess.check_output([sys.executable, os.path.join(ROOT, 'tools', 'mkrom.py'), scene, rom]).decode().strip())
    subprocess.check_call([os.path.join(ROOT, 'sim', 'build_display.sh'), rom, str(n)], stdout=subprocess.DEVNULL)
    r = subprocess.run([os.path.join(ROOT, 'sim', 'display_obj', 'sfgx_display'), out], capture_output=True, text=True, timeout=1800)
    if r.returncode: raise RuntimeError(r.stdout + r.stderr)
    # reference framebuffer after the same tokens (first capture of the scene)
    m, caps, _ = compare_rtl.run_reference(os.path.join(ROOT, 'scenes', scene + '.cmd'), W, H)
    first = next(iter(caps.values()))[0].reshape(H, W)
    expect = np.kron(first, np.ones((4, 4), dtype=np.uint32)).astype(np.uint32)
    ppm = open(os.path.join(out, 'frame.ppm'), 'rb').read().split(b'\n', 3)
    px = np.frombuffer(ppm[3], dtype=np.uint8).reshape(480, 640, 3).astype(np.uint32)
    got = (px[..., 0] << 16) | (px[..., 1] << 8) | px[..., 2]
    t = {l.split()[0]: l.split()[1:] for l in open(os.path.join(out, 'timing.txt'))}
    problems = []
    if not np.array_equal(got, expect): problems.append(f"video frame differs from the replicated reference framebuffer: {int((got != expect).sum())} px")
    if int(t['frame_cycles'][0]) != 800 * 525: problems.append(f"frame period {t['frame_cycles'][0]} != 420000 clocks")
    if int(t['de_pixels'][0]) != 640 * 480: problems.append(f"DE pixels {t['de_pixels'][0]} != 307200")
    if int(t['lines_with_de'][0]) != 480: problems.append(f"active lines {t['lines_with_de'][0]} != 480")
    if t['hsync_low_cycles'] != ['96', '96']: problems.append(f"hsync low width {t['hsync_low_cycles']} != 96")
    if int(t['vsync_low_cycles'][0]) != 2 * 800: problems.append(f"vsync low {t['vsync_low_cycles'][0]} != 1600 clocks (2 lines)")
    ok = not problems
    print(f"[{'PASS' if ok else 'FAIL'}] display path ({scene}, {W}x{H} -> 640x480): {n} ROM tokens, render {t['render_cycles'][0]} clocks; "
          f"video frame == reference framebuffer x4 ({int((got == expect).sum())}/{got.size} px); frame {t['frame_cycles'][0]} clocks, "
          f"{t['de_pixels'][0]} DE px, {t['lines_with_de'][0]} lines, hsync {t['hsync_low_cycles'][0]} clk, vsync {t['vsync_low_cycles'][0]} clk")
    for p in problems: print("      -", p)
    return ok

if __name__ == '__main__':
    a = sys.argv[1:]
    sys.exit(0 if main(*(a[:1] + [int(x) for x in a[1:3]])) else 1)
