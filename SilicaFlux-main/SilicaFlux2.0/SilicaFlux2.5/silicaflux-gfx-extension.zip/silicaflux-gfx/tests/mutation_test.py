#!/usr/bin/env python3
"""
mutation_test.py - does the regression actually catch wrong RTL?

Each mutant is a one-line fault injected into a COPY of the RTL (wrong edge rule,
missing rounding, swapped plane, dropped clamp, off-by-one address check, ...).
It is built with Verilator and run against a subset of the regression scenes;
a mutant is KILLED when any scene mismatches the bit-accurate reference (or the
simulation hangs / asserts).  SURVIVORS are printed - each one is either a gap in
the tests or an equivalent mutant (no observable behaviour change) and is
discussed in docs/04_VERIFICATION.md.
usage: mutation_test.py [--only id,id] [--jobs N]
"""
import concurrent.futures as cf, json, os, shutil, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.abspath(os.path.join(HERE, '..'))

SIZES = [(32, 32), (40, 30), (48, 36), (64, 64)]
SCENES = [("shared_edges", 32, 32), ("clip_cases", 32, 32), ("cull_depth", 32, 32), ("errors", 32, 32),
          ("random_screen_s1", 40, 30), ("random_persp_s1", 48, 36), ("texture", 64, 64), ("random_tex_s1", 48, 36)]

# id, file, old, new, description
M = [
 # ---- rasteriser: edge inclusion / orientation / interpolation ---------------
 ("R1", "sfgx_raster.sv", "bias[i] = ~((dy[i][25]) || ((dy[i] == 26'sd0) && (dx[i] > 26'sd0)));", "bias[i] = 1'b0;", "edges inclusive everywhere (double coverage on shared edges)"),
 ("R2", "sfgx_raster.sv", "bias[i] = ~((dy[i][25]) || ((dy[i] == 26'sd0) && (dx[i] > 26'sd0)));", "bias[i] = 1'b1;", "edges exclusive everywhere (gaps on shared edges)"),
 ("R3", "sfgx_raster.sv", "(dx[i] > 26'sd0)));", "(dx[i] < 26'sd0)));", "top edge test inverted (still watertight, differs from spec)"),
 ("R4", "sfgx_raster.sv", "(dy[i][25]) ||", "1'b0 ||", "left-edge ownership dropped"),
 ("R5", "sfgx_raster.sv", "rnd_r = a_pix[1] + (64'sd1 <<< (F_GRAD + 7));", "rnd_r = a_pix[1] + (64'sd1 <<< (F_GRAD + 6));", "red channel rounding constant wrong"),
 ("R6", "sfgx_raster.sv", "ZF_LESS:     z_pass = (zq <  fb_zrdata);", "ZF_LESS:     z_pass = (zq <= fb_zrdata);", "depth LESS behaves like LEQUAL"),
 ("R7", "sfgx_raster.sv", "(cull_mode == 2'd1 && !is_front)", "(cull_mode == 2'd1 && is_front)", "back/front culling swapped"),
 ("R8", "sfgx_raster.sv", "bx0 = xmin[23:8];", "bx0 = xmin[23:8] + 16'd1;", "bounding box skips first column"),
 ("R9", "sfgx_raster.sv", "assign gq     = div_quo + {79'b0, ground};", "assign gq     = div_quo;", "gradient rounding removed (truncation)"),
 ("R10", "sfgx_raster.sv", "e_row[i] <= e_row[i] + 48'($signed(dx[i])) * 48'sd256;", "e_row[i] <= e_row[i] + 48'($signed(dx[i])) * 48'sd255;", "row step of the edge function wrong"),
 ("R11", "sfgx_raster.sv", "assign fb_wr_z    = wr_now && ctrl[CTRL_ZWRITE];", "assign fb_wr_z    = wr_now;", "depth-write enable ignored"),
 ("R12", "sfgx_raster.sv", "if (area2[52]) begin                 // swap V1 <-> V2, make area positive", "if (!area2[52]) begin", "orientation normalisation inverted"),
 ("R13", "sfgx_raster.sv", "assign is_front  = ccw_front ? area2[52] : (~area2[52] && (area2 != 53'sd0));", "assign is_front  = ccw_front ? ~area2[52] : area2[52];", "front-face winding inverted"),
 ("R14", "sfgx_raster.sv", "acc0_v = (64'(att[ei*3]) <<< efs) + gx[ei] * 64'(ox) + gy[ei] * 64'(oy);", "acc0_v = (64'(att[ei*3]) <<< efs) + gx[ei] * 64'(ox);", "gY term dropped from plane equation start value"),
 ("R15", "sfgx_raster.sv", "zq    = sh_z[31] ? 16'h0000 : (|sh_z[30:16]) ? 16'hFFFF : sh_z[15:0];", "zq    = sh_z[15:0];", "depth clamp removed"),
 ("R16", "sfgx_raster.sv", "rq    = sh_r[31] ? 8'h00 : (|sh_r[30:8]) ? 8'hFF : sh_r[7:0];", "rq    = sh_r[7:0];", "colour clamp removed"),
 # ---- clipper -----------------------------------------------------------------
 ("C1", "sfgx_clip.sv", "assign dP_pos = pin && (dP != 34'sd0);", "assign dP_pos = pin;", "duplicate vertex when d_P == 0"),
 ("C2", "sfgx_clip.sv", "assign dQ_pos = qin && (dQ != 34'sd0);", "assign dQ_pos = qin;", "duplicate vertex when d_Q == 0"),
 ("C3", "sfgx_clip.sv", "68'sh0_0000_0000_8000_0000", "68'sh0", "intersection rounding removed"),
 ("C4", "sfgx_clip.sv", "default: pdist = w - z;", "default: pdist = w + z;", "far plane tested like the near plane"),
 ("C5", "sfgx_clip.sv", "assign vp_round = ({div_rem, 1'b0} >= {1'b0, div_den});", "assign vp_round = 1'b0;", "viewport divide truncates"),
 ("C6", "sfgx_clip.sv", "else if ($signed(chk_v[CV_W +: 32]) <= 32'sd0) st <= C_REJECT;", "else if ($signed(chk_v[CV_W +: 32]) < 32'sd0) st <= C_REJECT;", "w == 0 vertex accepted"),
 ("C7", "sfgx_clip.sv", "3'd1:    a_sel = vw - vy;", "3'd1:    a_sel = vw + vy;", "window Y not flipped"),
 ("C8", "sfgx_clip.sv", "if (a_sel[33])                nn = '0;", "if (1'b0)                nn = '0;", "negative lower clamp removed"),
 ("C9", "sfgx_clip.sv", "div_num   <= {1'b0, absdP, 32'b0};", "div_num   <= {2'b0, absdP, 31'b0};", "intersection parameter t halved"),
 ("C10", "sfgx_clip.sv", "assign tri_data  = {svb[ek + 4'd1], svb[ek], svb[0]};", "assign tri_data  = {svb[ek], svb[ek + 4'd1], svb[0]};", "fan winding reversed"),
 ("C11", "sfgx_clip.sv", "ev_clipped <= had_isect;", "ev_clipped <= 1'b0;", "clipped statistic never counted"),
 ("C12", "sfgx_clip.sv", "if (n < 4'd3) st <= C_REJECT;", "if (n < 4'd2) st <= C_REJECT;", "2-vertex polygon accepted"),
 ("C13", "sfgx_clip.sv", "st  <= (on == 4'd0) ? C_REJECT : C_PLANE;", "st  <= C_PLANE;", "empty polygon not rejected early"),
 ("C14", "sfgx_clip.sv", "3'd2:    pdist = w + y;", "3'd2:    pdist = w - y;", "plane 2 distance sign wrong"),
 # ---- vertex input + transform ---------------------------------------------------
 ("V1", "sfgx_vertex.sv", "else        sh_sat = sh[31:0];", "else        sh_sat = sh[31:0];\n    if (sh_ovf) sh_sat = sh[31:0];", "saturation replaced by wrap"),
 ("V2", "sfgx_vertex.sv", "sh     = (acc + 68'sd32768) >>> 16;", "sh     = acc >>> 16;", "transform rounding removed"),
 ("V3", "sfgx_vertex.sv", "(vk == 2'd1) ? tword[19:10]", "(vk == 2'd1) ? tword[18:9]", "second index field misaligned"),
 ("V4", "sfgx_vertex.sv", "prim[vk*CVW + CV_R +: 16] <= {vw[3][23:16], 8'h00};", "prim[vk*CVW + CV_R +: 16] <= {vw[3][15:8], 8'h00};", "red/green colour mapping wrong"),
 ("V5", "sfgx_vertex.sv", "((vaddr_c + {10'b0, vtx_stride}) > 18'(SRAM_DEPTH))", "((vaddr_c + {10'b0, vtx_stride}) >= 18'(SRAM_DEPTH))", "vertex address check off by one"),
 ("V6", "sfgx_vertex.sv", "(tri_addr >= SRAM_DEPTH[15:0])", "(tri_addr > SRAM_DEPTH[15:0])", "triangle-word address check off by one"),
 # ---- texture path ------------------------------------------------------------
 ("X1", "sfgx_raster.sv", "for (int a = 0; a < 7; a++) a_pix[a] <= a_pix[a] + (gx[a] <<< 8);", "for (int a = 0; a < 4; a++) a_pix[a] <= a_pix[a] + (gx[a] <<< 8);", "texture accumulators not advanced along x (a bug made during development)"),
 ("X2", "sfgx_raster.sv", "tex_addr <= (TEX_AW'(ty) << wlog) | TEX_AW'(tx);", "tex_addr <= (TEX_AW'(ty) << hlog) | TEX_AW'(tx);", "texel row stride uses height instead of width"),
 ("X3", "sfgx_raster.sv", "m_r = tex_rdata[23:16] * rq  + 16'd127;", "m_r = tex_rdata[23:16] * rq  + 16'd0;", "modulate rounding term removed (red)"),
 ("X4", "sfgx_raster.sv", "if (ctrl[CTRL_TEX_CLAMP]) begin", "if (!ctrl[CTRL_TEX_CLAMP]) begin", "REPEAT and CLAMP swapped"),
 ("X5", "sfgx_raster.sv", "tx_f  = ts_neg ? -(qu_s + ((tdu_rem != 40'd0) ? 50'sd1 : 50'sd0)) : qu_s;", "tx_f  = ts_neg ? -qu_s : qu_s;", "floor of negative quotients becomes truncation"),
 ("X6", "sfgx_raster.sv", "if (gk == (tex_en ? 4'd13 : 4'd7))", "if (gk == (tex_en ? 4'd11 : 4'd7))", "q gradient never computed"),
 ("X7", "sfgx_raster.sv", "tqd    = (tq_v <= 64'sd0) ? 64'sd1 : tq_v;", "tqd    = (tq_v <= 64'sd0) ? 64'sd2 : tq_v;", "non-positive q guard changed (only matters for q<=0)"),
 ("X8", "sfgx_raster.sv", "ts_v   = (a_pix[4] + (64'sd1 <<< (F_GRAD_T - 1))) >>> F_GRAD_T;", "ts_v   = a_pix[4] >>> F_GRAD_T;", "s rounding removed"),
 ("X9", "sfgx_clip.sv", "st_sh_s   = (st_prod_s + 72'sd32768) >>> 16;", "st_sh_s   = st_prod_s >>> 16;", "s = u*q rounding removed"),
 ("X10", "sfgx_clip.sv", "if (ik == 4'd8) begin had_isect <= 1'b1; st <= C_PUSH; end", "if (ik == 4'd6) begin had_isect <= 1'b1; st <= C_PUSH; end", "u,v not interpolated on clipped edges"),
 ("X11", "sfgx_clip.sv", "assign q_sat  = (q_full > QMAX) ? 40'sh7F_FFFF_FFFF : q_full[39:0];", "assign q_sat  = q_full[39:0];", "q saturation removed (matters only for w < 2^-15)"),
 ("X12", "sfgx_vertex.sv", "assign nlast = (tex_en && (vtx_stride >= 8'd6)) ? 3'd5 : 3'd3;", "assign nlast = 3'd3;", "u,v never fetched"),
 ("X13", "sfgx_vertex.sv", "18'(cur_idx) * 18'(vtx_stride);", "18'(cur_idx) * 18'd4;", "vertex stride register ignored in address computation"),
 ("X14", "sfgx_gfx_tile.sv", "if (tok_mem_addr >= 14'(1 << TEX_AW)) begin", "if (tok_mem_addr > 14'(1 << TEX_AW)) begin", "GFXTEX bound off by one"),
 ("X15", "sfgx_gfx_tile.sv", "if (scalar_data_in[3:0] <= 4'd6 && scalar_data_in[7:4] <= 4'd6) tex_log2", "if (scalar_data_in[3:0] <= 4'd7 && scalar_data_in[7:4] <= 4'd6) tex_log2", "TEX_CTRL accepts log2 width 7"),
 ("X16", "sfgx_gfx_tile.sv", "if (scalar_data_in >= 32'd4 && scalar_data_in <= 32'd64) vtx_stride", "if (scalar_data_in >= 32'd3 && scalar_data_in <= 32'd64) vtx_stride", "VTX_STRIDE accepts 3"),
 # ---- tile / framebuffer ------------------------------------------------------------
 ("T1", "sfgx_gfx_tile.sv", "if (ev_cull)        c_tri_cull   <= c_tri_cull + 32'd1;", "if (1'b0)           c_tri_cull   <= c_tri_cull + 32'd1;", "cull counter never counts"),
 ("T2", "sfgx_gfx_tile.sv", "clr_z_en  <= tok_length[1];", "clr_z_en  <= tok_length[0];", "GFXCLEAR depth flag mis-decoded"),
 ("T3", "sfgx_gfx_tile.sv", "(scalar_r[31:16] < 16'(FB_H))", "(scalar_r[31:16] <= 16'(FB_H))", "pixel read-back y bound off by one"),
 ("T4", "sfgx_gfx_tile.sv", "if (tok_mem_addr >= 14'(SRAM_DEPTH)) begin", "if (tok_mem_addr > 14'(SRAM_DEPTH)) begin", "scalar scratchpad bound off by one"),
 ("T5", "sfgx_gfx_tile.sv", "if (vtx_ovf)        flags[FLAG_XFORM_OVF] <= 1'b1;", "if (1'b0)           flags[FLAG_XFORM_OVF] <= 1'b1;", "overflow flag never set"),
 ("F1", "sfgx_fb.sv", "clr_dep_r <= clr_depth;", "clr_dep_r <= 16'hFFFF;", "depth clear value ignored"),
]

def run_mutant(mid, fname, old, new, desc, workdir):
    d = os.path.join(workdir, mid); shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, 'rtl'), os.path.join(d, 'rtl'))
    p = os.path.join(d, 'rtl', fname); s = open(p).read()
    if s.count(old) != 1: return mid, "NOT-APPLIED", f"pattern found {s.count(old)}x in {fname}"
    open(p, 'w').write(s.replace(old, new))
    env = dict(os.environ, SFGX_RTL_DIR=os.path.join(d, 'rtl'), SFGX_OBJ_ROOT=os.path.join(d, 'sim'), SFGX_OUT_ROOT=os.path.join(d, 'out'), SFGX_TIMEOUT='120')
    for (W, H) in SIZES:
        r = subprocess.run([os.path.join(ROOT, 'sim', 'build.sh'), str(W), str(H)], env=env, capture_output=True, text=True)
        if r.returncode: return mid, "KILLED", "does not compile/elaborate"
    code = ("import sys; sys.path.insert(0, %r); import compare_rtl as c\n"
            "for n,W,H in %r:\n"
            "    try:\n"
            "        ok,p = c.compare(n,W,H,verbose=False)\n"
            "    except Exception as e:\n"
            "        print('KILLED-BY', n, 'exception', str(e)[:80]); sys.exit(0)\n"
            "    if not ok: print('KILLED-BY', n, p[0][:110]); sys.exit(0)\n"
            "print('SURVIVED')\n") % (HERE, SCENES)
    r = subprocess.run([sys.executable, '-c', code], env=env, capture_output=True, text=True, timeout=1500)
    out = (r.stdout.strip().splitlines() or ["(no output) " + r.stderr[-200:]])[-1]
    return mid, ("SURVIVED" if out.startswith("SURVIVED") else "KILLED"), out

if __name__ == '__main__':
    only = None; jobs = 2
    a = sys.argv[1:]
    if '--only' in a: only = a[a.index('--only') + 1].split(',')
    if '--jobs' in a: jobs = int(a[a.index('--jobs') + 1])
    out_json = a[a.index('--out') + 1] if '--out' in a else os.path.join(ROOT, 'results', 'mutation_results.json')
    work = os.environ.get('SFGX_MUT_DIR', os.path.join(ROOT, 'results', 'mutation_work'))
    os.makedirs(work, exist_ok=True)
    todo = [m for m in M if not only or m[0] in only]
    res = {}; t0 = time.time()
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(run_mutant, *m, work): m for m in todo}
        for f in cf.as_completed(futs):
            m = futs[f]
            try: mid, status, detail = f.result()
            except Exception as e: mid, status, detail = m[0], "KILLED", f"harness exception {e}"
            res[mid] = (status, detail, m[4])
            print(f"{mid:4s} {status:10s} {m[4]:62s} {detail[:90]}", flush=True)
    k = sum(1 for v in res.values() if v[0] == "KILLED"); n = len(res)
    print(f"\nMUTATION SCORE: {k}/{n} killed   survivors: {[i for i, v in res.items() if v[0] != 'KILLED']}   ({time.time() - t0:.0f} s)")
    json.dump(res, open(out_json, 'w'), indent=1)
