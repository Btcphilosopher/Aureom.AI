#!/usr/bin/env python3
"""mktok.py - convert a .cmd file into the flat .tok token list replayed by the RTL harness.
One line per item:  T op addr scalar v0 v1 v2 v3 len   |   C name     (all numbers hex)."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'ref'))
from sfgx_ref import parse_cmd

def convert(src, dst):
    with open(dst, 'w') as f:
        for it in parse_cmd(src):
            if it[0] == 'CAPTURE': f.write(f"C {it[1]}\n")
            else:
                _, op, addr, scalar, vec, length = it
                f.write("T %x %x %x %x %x %x %x %x\n" % (op, addr, scalar & 0xFFFFFFFF, *[v & 0xFFFFFFFF for v in vec], length))

if __name__ == '__main__':
    convert(sys.argv[1], sys.argv[2])
