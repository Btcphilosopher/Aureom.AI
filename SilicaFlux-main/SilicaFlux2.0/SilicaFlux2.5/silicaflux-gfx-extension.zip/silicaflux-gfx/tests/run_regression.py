#!/usr/bin/env python3
"""run_regression.py - RTL == reference on every scene of scenes/manifest.json.
Builds each framebuffer size once (Verilator), replays, compares bit-exactly."""
import json, os, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')
sys.path.insert(0, HERE)
import compare_rtl

def main(only=None):
    subprocess.check_call([sys.executable, os.path.join(ROOT, 'ref', 'scenes.py'), os.path.join(ROOT, 'scenes')], stdout=subprocess.DEVNULL)
    man = json.load(open(os.path.join(ROOT, 'scenes', 'manifest.json')))
    built, fails, t0 = set(), [], time.time()
    for name, W, H in man:
        if only and not any(o in name for o in only): continue
        if (W, H) not in built:
            subprocess.check_call([os.path.join(ROOT, 'sim', 'build.sh'), str(W), str(H)], stdout=subprocess.DEVNULL); built.add((W, H))
        ok, _ = compare_rtl.compare(name, W, H)
        if not ok: fails.append(name)
    print(f"\nREGRESSION: {'PASS' if not fails else 'FAIL ' + str(fails)}  ({time.time() - t0:.0f} s)")
    return 1 if fails else 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:] or None))
