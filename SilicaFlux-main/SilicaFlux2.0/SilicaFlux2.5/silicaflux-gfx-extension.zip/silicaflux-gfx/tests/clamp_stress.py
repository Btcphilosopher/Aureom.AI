#!/usr/bin/env python3
"""clamp_stress.py - adversarial search for covered pixels whose interpolated colour/depth would
need the output clamp.  Thin slivers, extreme attribute values (0 / 255 / 0 / 65535), maximum
framebuffer (2048x2048).  Reports the number of clamp activations (expected 0: the clamp is
defence-in-depth that the covered-pixel invariant makes unreachable)."""
import os, random, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, '..', 'ref'))
import numpy as np
import sfgx_ref as R

def main(n=300, seed=1):
    rnd = random.Random(seed); W = H = 2048
    m = R.SfgxModel(W, H)
    far = R.DEPTH_MAX * 256
    t0 = time.time(); n_run = 0
    for _ in range(n):
        kind = rnd.choice(["sliver_h", "sliver_v", "sliver_d", "tiny", "wide"])
        X, Y = rnd.randrange(0, W * 256), rnd.randrange(0, H * 256)
        L = rnd.randrange(300 * 256, 2000 * 256)
        if kind == "sliver_h":   pts = [(X, Y), (min(X + L, W * 256), Y + rnd.randrange(1, 300)), (X + L // 2, Y + rnd.randrange(1, 4))]
        elif kind == "sliver_v": pts = [(X, Y), (X + rnd.randrange(1, 300), min(Y + L, H * 256)), (X + rnd.randrange(1, 4), Y + L // 2)]
        elif kind == "sliver_d": pts = [(X, Y), (min(X + L, W * 256), min(Y + L, H * 256)), (X + L // 2 + rnd.randrange(1, 6), Y + L // 2)]
        elif kind == "tiny":     pts = [(X, Y), (X + rnd.randrange(1, 700), Y + rnd.randrange(0, 700)), (X + rnd.randrange(0, 700), Y + rnd.randrange(1, 700))]
        else:                    pts = [(rnd.randrange(0, W * 256), rnd.randrange(0, H * 256)) for _ in range(3)]
        pts = [(min(max(x, 0), W * 256), min(max(y, 0), H * 256)) for x, y in pts]
        ext = lambda: rnd.choice([0, 255 << 8])
        V = [(x, y, rnd.choice([0, far]), ext(), ext(), ext()) for x, y in pts]
        m.ctrl = R.CTRL_DEFAULT & ~R.CTRL_ZTEST        # always write: no depth interference
        m.setup_and_raster(*V); n_run += 1
    print(f"{n_run} adversarial triangles on {W}x{H} in {time.time() - t0:.0f}s: "
          f"covered pixels={m.cnt['pix_cov']}  CLAMP ACTIVATIONS = {R.CLAMP_HITS}")
    return sum(R.CLAMP_HITS.values())

if __name__ == '__main__':
    sys.exit(1 if main(int(sys.argv[1]) if len(sys.argv) > 1 else 300) else 0)
