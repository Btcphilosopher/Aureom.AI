#!/usr/bin/env python3
"""check_consts.py - every constant that exists in BOTH rtl/sfgx_pkg.sv and ref/sfgx_ref.py must be equal.
Keeps the executable spec (reference) and the RTL package from drifting apart."""
import os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')
sys.path.insert(0, os.path.join(ROOT, 'ref'))
import sfgx_ref as R

src = open(os.path.join(ROOT, 'rtl', 'sfgx_pkg.sv')).read()
src = re.sub(r'//.*', '', src)
sv = {}
for m in re.finditer(r"localparam\s+(?:int|logic\s*\[[^\]]*\])\s+([^;]+);", src):
    for item in m.group(1).split(','):
        mm = re.match(r"\s*(\w+)\s*=\s*(.+?)\s*$", item)
        if not mm: continue
        name, val = mm.group(1), mm.group(2)
        val = re.sub(r"\d+'h([0-9a-fA-F_]+)", lambda x: "0x" + x.group(1).replace('_', ''), val)
        val = re.sub(r"'h([0-9a-fA-F]+)", r"0x\1", val)
        val = re.sub(r"\d+'d(\d+)", r"\1", val)
        try: sv[name] = eval(val, {}, {})
        except Exception: pass
# mapping: (SV name) -> (reference expression)
pairs = {
 'OP_GFXREG': R.OP_GFXREG, 'OP_GFXDRAW': R.OP_GFXDRAW, 'OP_GFXCLEAR': R.OP_GFXCLEAR, 'OP_GFXRD': R.OP_GFXRD,
 'OP_GFXSTAT': R.OP_GFXSTAT, 'OP_GFXMEM': R.OP_GFXMEM, 'OP_GFXTEX': R.OP_GFXTEX,
 'R_MAT0': R.R_MAT0, 'R_CTRL': R.R_CTRL, 'R_VTX_BASE': R.R_VTX_BASE, 'R_TRI_BASE': R.R_TRI_BASE, 'R_NUM_TRI': R.R_NUM_TRI,
 'R_CLEAR_DEPTH': R.R_CLEAR_DEPTH, 'R_VTX_STRIDE': R.R_VTX_STRIDE, 'R_TEX_CTRL': R.R_TEX_CTRL, 'R_STATS_CLR': R.R_STATS_CLR,
 'CTRL_ZTEST': 0, 'CTRL_ZWRITE': 1, 'CTRL_ZFUNC_LO': R.CTRL_ZFUNC_SH, 'CTRL_CULL_LO': R.CTRL_CULL_SH,
 'CTRL_FRONT_CW': R.CTRL_FRONT_CW.bit_length() - 1, 'CTRL_TEX_EN': R.CTRL_TEX_EN.bit_length() - 1,
 'CTRL_TEX_MOD': R.CTRL_TEX_MOD.bit_length() - 1, 'CTRL_TEX_CLAMP': R.CTRL_TEX_CLAMP.bit_length() - 1,
 'ST_FLAGS': R.ST_FLAGS, 'ST_TRI_IN': R.ST_TRI_IN, 'ST_TRI_ADDR_ERR': R.ST_TRI_ADDR_ERR, 'ST_TRI_CLIP_REJ': R.ST_TRI_CLIP_REJ,
 'ST_TRI_CLIPPED': R.ST_TRI_CLIPPED, 'ST_TRI_SETUP': R.ST_TRI_SETUP, 'ST_TRI_DEGEN': R.ST_TRI_DEGEN, 'ST_TRI_CULL': R.ST_TRI_CULL,
 'ST_TRI_RASTER': R.ST_TRI_RASTER, 'ST_PIX_COV': R.ST_PIX_COV, 'ST_PIX_WRITTEN': R.ST_PIX_WRITTEN, 'ST_PIX_ZFAIL': R.ST_PIX_ZFAIL,
 'ST_FBSIZE': R.ST_FBSIZE, 'ST_ID': R.ST_ID, 'ST_PIX_TEX': R.ST_PIX_TEX, 'SFGX_ID': R.SFGX_ID,
 'FLAG_XFORM_OVF': R.FLAG_XFORM_OVF.bit_length() - 1, 'FLAG_ADDR_ERR': R.FLAG_ADDR_ERR.bit_length() - 1, 'FLAG_BAD_TOKEN': R.FLAG_BAD_TOKEN.bit_length() - 1,
 'F_GRAD': R.F_GRAD, 'F_GRAD_T': R.F_GRAD_T, 'DEPTH_MAX': R.DEPTH_MAX, 'VTX_STRIDE_DEF': R.VTX_STRIDE,
 'ZF_NEVER': 0, 'ZF_LESS': 1, 'ZF_EQUAL': 2, 'ZF_LEQUAL': 3, 'ZF_GREATER': 4, 'ZF_NOTEQUAL': 5, 'ZF_GEQUAL': 6, 'ZF_ALWAYS': 7,
}
bad = 0
for k, v in pairs.items():
    if k not in sv: print(f"MISSING in sfgx_pkg.sv: {k}"); bad += 1
    elif sv[k] != v: print(f"MISMATCH {k}: rtl={sv[k]!r} ref={v!r}"); bad += 1
# texture memory size
if sv.get('TEX_AW') is not None and (1 << sv['TEX_AW']) != R.TEX_TEXELS: print("MISMATCH TEX_AW vs TEX_TEXELS"); bad += 1
# vertex layout widths are self-consistent
assert sv['CVW'] == 240 and sv['SVW'] == 240, "vertex layout widths changed; update harness extraction (tb/sfgx_harness.cpp uses 240-bit SV)"
print(f"{len(pairs)} shared constants checked: {'ALL EQUAL' if not bad else str(bad) + ' PROBLEMS'}")
sys.exit(1 if bad else 0)
