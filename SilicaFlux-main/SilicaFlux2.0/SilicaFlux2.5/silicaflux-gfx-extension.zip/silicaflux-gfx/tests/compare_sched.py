#!/usr/bin/env python3
"""
compare_sched.py - scheduler-level integration check.
Replays a scene through sfgx_sched_top (UNMODIFIED scheduler + 3 compute tiles + graphics
tile in slot 3) and requires bit-exact agreement with the software reference on every
token result/error flag (except GFXDRAW results in 'interleave' mode) and on the colour
and depth buffer at every capture.  In 'interleave' mode it also requires that every
VADD on a compute tile returned the right sum WHILE the graphics tile was still drawing,
and that the scheduler's DFSYNC barrier asserted sync_stall.
usage: compare_sched.py <scene> <W> <H> [interleave]
"""
import os, subprocess, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')
sys.path.insert(0, os.path.join(ROOT, 'ref')); sys.path.insert(0, HERE)
import compare_rtl, mktok


def compare(scene, W, H, interleave=False, verbose=True):
    outdir = os.path.join(ROOT, 'results', 'sched_runs', f"{scene}_{W}x{H}{'_il' if interleave else ''}")
    os.makedirs(outdir, exist_ok=True)
    cmd = os.path.join(ROOT, 'scenes', scene + '.cmd'); tok = os.path.join(outdir, scene + '.tok')
    mktok.convert(cmd, tok)
    exe = os.path.join(ROOT, 'sim', f'sched_obj_{W}x{H}', f'sfgx_sched_{W}x{H}')
    if compare_rtl.stale(exe): subprocess.check_call([os.path.join(ROOT, 'sim', 'build_sched.sh'), str(W), str(H)], stdout=subprocess.DEVNULL)
    args = [exe, tok, outdir] + (['interleave'] if interleave else [])
    r = subprocess.run(args, capture_output=True, text=True, timeout=1800)
    if r.returncode: raise RuntimeError(r.stdout + r.stderr)
    m, caps, ref_results = compare_rtl.run_reference(cmd, W, H)
    problems = []
    rtl_tok = [tuple(int(x, 16) if i < 2 else int(x) for i, x in enumerate(l.split()[:3])) for l in open(os.path.join(outdir, 'tokens.txt'))]
    if len(rtl_tok) != len(ref_results): problems.append(f"token count rtl={len(rtl_tok)} ref={len(ref_results)}")
    for i, (a, b) in enumerate(zip(ref_results, rtl_tok)):
        if interleave and a[0] == 0x19: b = (b[0], a[1] & 0xFFFFFFFF, b[2]) if b[1] == 0xFFFFFFFF else b
        if (a[0], a[1] & 0xFFFFFFFF, a[2]) != b:
            problems.append(f"token#{i} ref={a} rtl={b}"); break
    for name, (rc, rz, _) in caps.items():
        col = np.fromfile(os.path.join(outdir, name + '.col'), dtype='<u4'); z = np.fromfile(os.path.join(outdir, name + '.z'), dtype='<u2')
        for label, a, b in (("colour", col, rc), ("depth", z, rz)):
            d = np.nonzero(a.astype(np.int64) != b.astype(np.int64))[0]
            if len(d): problems.append(f"capture '{name}' {label}: {len(d)} px differ")
    extra = ""
    if interleave:
        st = open(os.path.join(outdir, 'selftest.txt')).read().splitlines()[-1]
        kv = dict(p.split('=') for p in st.split()[1:])
        nd = sum(1 for t in ref_results if t[0] == 0x19)
        if int(kv['vadd']) != nd or int(kv['vadd_ok']) != nd: problems.append(f"VADD results wrong: {st}")
        if int(kv['overlapped']) < 1: problems.append(f"no VADD overlapped a draw: {st}")
        if int(kv['dfsync_barrier_held']) < int(kv['overlapped']): problems.append(f"DFSYNC barrier did not assert sync_stall while a draw was running: {st}")
        extra = f" | VADD on compute tile 0 correct {kv['vadd_ok']}/{kv['vadd']}, overlapped with a running draw {kv['overlapped']} times (short/culled draws finish first), barrier held {kv['dfsync_barrier_held']}/{nd}"
    ok = not problems
    if verbose:
        print(f"[{'PASS' if ok else 'FAIL'}] scheduler-level {scene:14s} {W}x{H} {'interleaved' if interleave else 'plain'}: "
              f"{len(ref_results)} tokens, {len(caps)} captures{extra}")
        for p in problems[:6]: print("      -", p)
    return ok, problems

if __name__ == '__main__':
    scene, W, H = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    sys.exit(0 if compare(scene, W, H, len(sys.argv) > 4)[0] else 1)
