// display_harness.cpp - runs sfgx_display_demo_top (token ROM -> engine -> scan-out) and captures
// one complete VIDEO FRAME from the pixel stream (de/r/g/b), plus timing measurements.
//   display_harness <outdir>      writes frame.ppm and timing.txt
#include <cstdio>
#include <cstdint>
#include <string>
#include <vector>
#include <sys/stat.h>
#include "verilated.h"
#include "Vsfgx_display_demo_top.h"
#ifndef VID_W
#define VID_W 640
#endif
#ifndef VID_H
#define VID_H 480
#endif
static Vsfgx_display_demo_top* top; static uint64_t cycles = 0;
static void tick() { top->clk = 0; top->eval(); top->clk = 1; top->eval(); cycles++; }
int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  std::string out = argc > 1 ? argv[1] : "."; mkdir(out.c_str(), 0755);
  top = new Vsfgx_display_demo_top;
  top->rst_n = 0; top->pix_ce = 1;
  for (int i = 0; i < 8; i++) tick();
  top->rst_n = 1;
  // 1. let the ROM finish and the engine go idle
  uint64_t guard = 0;
  while (!(top->rom_finished && !top->gfx_busy)) { tick(); if (++guard > 400000000ull) { fprintf(stderr, "TIMEOUT waiting for render\n"); return 3; } }
  uint64_t render_cycles = cycles;
  // 2. align to a frame start, then capture exactly one frame
  guard = 0; while (!top->vid_frame_start) { tick(); if (++guard > 5000000) { fprintf(stderr, "no frame_start\n"); return 4; } }
  std::vector<uint32_t> img(VID_W * VID_H, 0xDEADBEEF);
  // measurement state
  unsigned x = 0, y = 0, de_count = 0, line_pixels = 0, lines_with_de = 0;
  unsigned hs_low_run = 0, hs_low_max = 0, hs_low_min = 1u << 30, vs_low_lines = 0; bool prev_hs = true, prev_vs = true, prev_de = false;
  unsigned clk_in_line = 0, line_len_min = 1u << 30, line_len_max = 0; uint64_t f0 = cycles; unsigned vs_low_run_cycles = 0, vs_low_max = 0;
  bool vs_in = false;
  guard = 0;
  // capture until the next frame_start
  bool first = true;
  while (true) {
    // sample current outputs (valid after eval of the previous edge)
    bool de = top->vid_de, hs = top->vid_hsync, vs = top->vid_vsync;
    if (!first && top->vid_frame_start) break;
    first = false;
    if (de) { if (x < VID_W && y < VID_H) img[y * VID_W + x] = (top->vid_r << 16) | (top->vid_g << 8) | top->vid_b; x++; de_count++; line_pixels++; }
    if (prev_de && !de) { lines_with_de++; if (y < VID_H) y++; x = 0; line_pixels = 0; }
    // hsync low pulse width
    if (!hs) hs_low_run++; if (hs && !prev_hs) { if (hs_low_run > hs_low_max) hs_low_max = hs_low_run; if (hs_low_run < hs_low_min) hs_low_min = hs_low_run; hs_low_run = 0; }
    if (!vs) vs_low_run_cycles++; if (vs && !prev_vs) { if (vs_low_run_cycles > vs_low_max) vs_low_max = vs_low_run_cycles; vs_low_run_cycles = 0; }
    (void)vs_in; (void)vs_low_lines; (void)clk_in_line; (void)line_len_min; (void)line_len_max;
    prev_hs = hs; prev_vs = vs; prev_de = de;
    tick(); if (++guard > 5000000) { fprintf(stderr, "frame did not end\n"); return 5; }
  }
  uint64_t frame_cycles = cycles - f0;
  FILE* f = fopen((out + "/frame.ppm").c_str(), "wb"); fprintf(f, "P6\n%d %d\n255\n", VID_W, VID_H);
  for (auto p : img) { unsigned char c[3] = {(unsigned char)(p >> 16), (unsigned char)(p >> 8), (unsigned char)p}; fwrite(c, 1, 3, f); } fclose(f);
  f = fopen((out + "/timing.txt").c_str(), "w");
  fprintf(f, "render_cycles %llu\nframe_cycles %llu\nde_pixels %u\nlines_with_de %u\nhsync_low_cycles %u %u\nvsync_low_cycles %u\n",
          (unsigned long long)render_cycles, (unsigned long long)frame_cycles, de_count, lines_with_de, hs_low_min, hs_low_max, vs_low_max);
  fclose(f);
  printf("display_harness: render %llu cycles, video frame %llu cycles, %u DE pixels\n", (unsigned long long)render_cycles, (unsigned long long)frame_cycles, de_count);
  top->final(); delete top; return 0;
}
