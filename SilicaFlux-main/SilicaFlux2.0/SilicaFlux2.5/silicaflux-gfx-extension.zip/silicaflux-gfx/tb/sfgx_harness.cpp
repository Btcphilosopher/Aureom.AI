// =============================================================================
// sfgx_harness.cpp - Verilator replay harness for sfgx_gfx_tile
//
// Drives the compute_tile-compatible token interface exactly like the SilicaFlux
// scheduler does (token_valid held until token_ready, then wait for tile_done),
// and records, per run:
//   <out>/tokens.txt   one line per token: op result error cycles
//   <out>/tris.txt     every screen-space triangle that entered setup (18 ints)
//   <out>/<cap>.col    framebuffer (uint32 LE, W*H), read through the display port fb_scan_*
//   <out>/<cap>.z      depth buffer (uint16 LE, W*H)
//   <out>/<cap>.cov    per-pixel coverage-event counts since the previous capture (uint16)
//   <out>/<cap>.ppm    the captured colour buffer as a PPM image
// usage: sfgx_harness <file.tok> <outdir> [max_cycles_per_token]
// =============================================================================
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <string>
#include <vector>
#include <sys/stat.h>
#include "verilated.h"
#include "Vsfgx_gfx_tile.h"
#include "Vsfgx_gfx_tile___024root.h"

#ifndef FB_W
#define FB_W 160
#endif
#ifndef FB_H
#define FB_H 120
#endif

static Vsfgx_gfx_tile* top;
static uint64_t cycles = 0;
static std::vector<uint16_t> cov(FB_W * FB_H, 0);
static FILE* ftris = nullptr;

template <typename W> static uint64_t bits(const W& w, int lo, int n) {   // extract n<=64 bits at lo from a wide signal
  uint64_t v = 0;
  for (int i = 0; i < n; i++) { int b = lo + i; if ((w[b >> 5] >> (b & 31)) & 1u) v |= (1ull << i); }
  return v;
}

static void sample_taps() {
  if (top->dbg_cov_valid) {
    unsigned x = top->dbg_cov_x, y = top->dbg_cov_y;
    if (x < FB_W && y < FB_H && cov[y * FB_W + x] < 65535) cov[y * FB_W + x]++;
  }
  if (top->dbg_tri_valid && ftris) {
    for (int v = 0; v < 3; v++) {
      int o = v * 240;                                // SVW = 240: X Y Z (24) | R G B (16) | S T Q (signed 40)
      auto sx40 = [&](int lo) { return (long long)((int64_t)(bits(top->dbg_tri_data, lo, 40) << 24) >> 24); };
      fprintf(ftris, "%llu %llu %llu %llu %llu %llu %lld %lld %lld%s",
              (unsigned long long)bits(top->dbg_tri_data, o + 0, 24), (unsigned long long)bits(top->dbg_tri_data, o + 24, 24),
              (unsigned long long)bits(top->dbg_tri_data, o + 48, 24), (unsigned long long)bits(top->dbg_tri_data, o + 72, 16),
              (unsigned long long)bits(top->dbg_tri_data, o + 88, 16), (unsigned long long)bits(top->dbg_tri_data, o + 104, 16),
              sx40(o + 120), sx40(o + 160), sx40(o + 200), v == 2 ? "\n" : " ");
    }
  }
}

static void tick() {
  top->clk = 0; top->eval();
  top->clk = 1; top->eval();
  cycles++;
  sample_taps();
}

static bool run_token(unsigned op, unsigned addr, uint32_t scalar, uint32_t v[4], unsigned len,
                      uint32_t* res, bool* err, uint64_t max_cycles) {
  uint64_t t0 = cycles;
  while (!top->token_ready) { tick(); if (cycles - t0 > max_cycles) return false; }
  top->tok_opcode = op; top->tok_mem_addr = addr; top->tok_length = len; top->tok_func = len;
  top->scalar_data_in = scalar;
  for (int i = 0; i < 4; i++) top->vector_data_in[i] = v[i];
  top->token_valid = 1;
  tick();                                           // edge with valid && ready = acceptance
  top->token_valid = 0;
  while (true) {
    if (top->tile_done) { *res = top->tile_result_scalar; *err = top->tile_error; break; }
    tick();
    if (cycles - t0 > max_cycles) return false;
  }
  tick();
  return true;
}

static void capture(const std::string& dir, const std::string& name) {
  std::vector<uint32_t> col(FB_W * FB_H);
  for (int i = 0; i < FB_W * FB_H; i++) {          // framebuffer capture through the display read port
    top->fb_scan_addr = i; tick();
    col[i] = top->fb_scan_data;
  }
  auto& zmem = top->rootp->sfgx_gfx_tile__DOT__u_fb__DOT__zmem;
  std::vector<uint16_t> z(FB_W * FB_H);
  for (int i = 0; i < FB_W * FB_H; i++) z[i] = zmem[i];
  FILE* f;
  f = fopen((dir + "/" + name + ".col").c_str(), "wb"); fwrite(col.data(), 4, col.size(), f); fclose(f);
  f = fopen((dir + "/" + name + ".z").c_str(), "wb");   fwrite(z.data(), 2, z.size(), f);   fclose(f);
  f = fopen((dir + "/" + name + ".cov").c_str(), "wb"); fwrite(cov.data(), 2, cov.size(), f); fclose(f);
  f = fopen((dir + "/" + name + ".ppm").c_str(), "wb");
  fprintf(f, "P6\n%d %d\n255\n", FB_W, FB_H);
  for (int i = 0; i < FB_W * FB_H; i++) { unsigned char p[3] = {(unsigned char)(col[i] >> 16), (unsigned char)(col[i] >> 8), (unsigned char)col[i]}; fwrite(p, 1, 3, f); }
  fclose(f);
  std::fill(cov.begin(), cov.end(), 0);
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  if (argc < 3) { fprintf(stderr, "usage: %s file.tok outdir [max_cycles]\n", argv[0]); return 2; }
  std::string tokfile = argv[1], outdir = argv[2];
  uint64_t max_cycles = argc > 3 ? strtoull(argv[3], nullptr, 10) : 200000000ull;
  mkdir(outdir.c_str(), 0755);
  top = new Vsfgx_gfx_tile;
  top->rst_n = 0; top->token_valid = 0; top->noc_flit_ready = 1; top->noc_flit_in_valid = 0; top->fb_scan_addr = 0;
  for (int i = 0; i < 8; i++) tick();
  top->rst_n = 1;
  for (int i = 0; i < 4; i++) tick();
  std::fill(cov.begin(), cov.end(), 0);
  ftris = fopen((outdir + "/tris.txt").c_str(), "w");
  FILE* ftok = fopen((outdir + "/tokens.txt").c_str(), "w");
  FILE* in = fopen(tokfile.c_str(), "r");
  if (!in) { fprintf(stderr, "cannot open %s\n", tokfile.c_str()); return 2; }
  char line[512]; unsigned ntok = 0, ncap = 0;
  while (fgets(line, sizeof line, in)) {
    if (line[0] == 'C') {
      char name[256]; sscanf(line + 2, "%255s", name);
      capture(outdir, name); ncap++;
    } else if (line[0] == 'T') {
      unsigned op, addr, len; uint32_t scalar, v[4];
      sscanf(line + 2, "%x %x %x %x %x %x %x %x", &op, &addr, &scalar, &v[0], &v[1], &v[2], &v[3], &len);
      uint32_t res = 0; bool err = false; uint64_t c0 = cycles;
      if (!run_token(op, addr, scalar, v, len, &res, &err, max_cycles)) {
        fprintf(stderr, "TIMEOUT on token %u (op %#x) after %llu cycles\n", ntok, op, (unsigned long long)(cycles - c0));
        return 3;
      }
      fprintf(ftok, "%x %x %d %llu\n", op, res, err ? 1 : 0, (unsigned long long)(cycles - c0));
      ntok++;
    }
  }
  fclose(in); fclose(ftok); fclose(ftris);
  printf("sfgx_harness: %u tokens, %u captures, %llu cycles\n", ntok, ncap, (unsigned long long)cycles);
  top->final(); delete top;
  return 0;
}
