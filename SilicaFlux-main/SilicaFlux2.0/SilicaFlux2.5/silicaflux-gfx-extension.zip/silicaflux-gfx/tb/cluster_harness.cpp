// cluster_harness.cpp - runs a hand-assembled SilicaFlux program in the FULL patched cluster
// (fetch -> decoder -> control core -> scheduler -> sfgx_gfx_tile in tile slot 3) and dumps the framebuffer.
//   cluster_harness <program.hex> <outdir>      -> <outdir>/final.col, final.z, halt/cycle report
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <string>
#include <vector>
#include <sys/stat.h>
#include "verilated.h"
#include "Vsilicaflux_top.h"
#include "Vsilicaflux_top___024root.h"
#ifndef FB_W
#define FB_W 32
#endif
#ifndef FB_H
#define FB_H 32
#endif
static Vsilicaflux_top* top; static uint64_t cycles = 0;
static unsigned last_op = 0xFFFF; static unsigned n_tok = 0;
static void tick() {
  top->clk = 0; top->eval(); top->clk = 1; top->eval(); cycles++;
#ifdef CLUSTER_DEBUG
  auto& r = *top->rootp;
  if ((cycles >= 1380 && cycles <= 1470) || (cycles >= 2290 && cycles <= 2300))
    printf("  cyc %5llu pc=%u flush=%d br=%d brtgt=%u stall=%d sched_v=%d sched_r=%d sync_stall=%d halt=%d\n", (unsigned long long)cycles,
      (unsigned)r.silicaflux_top__DOT__u_fetch__DOT__pc_reg, (int)r.silicaflux_top__DOT__flush, (int)r.silicaflux_top__DOT__branch_taken,
      (unsigned)r.silicaflux_top__DOT__branch_target, (int)r.silicaflux_top__DOT__stall, (int)r.silicaflux_top__DOT__sched_valid,
      (int)r.silicaflux_top__DOT__sched_ready, (int)r.silicaflux_top__DOT__sync_stall, (int)r.silicaflux_top__DOT__halt);
  if (r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__tile_done) {
    printf("  cyc %6llu tile3 DONE tk_op=%#x tk_addr=%u\n", (unsigned long long)cycles,
      (unsigned)r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__tk_op,
      (unsigned)r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__tk_addr);
    n_tok++;
  }
#endif
}
int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  if (argc < 3) { fprintf(stderr, "usage: %s prog.hex outdir\n", argv[0]); return 2; }
  std::string out = argv[2]; mkdir(out.c_str(), 0755);
  std::vector<uint32_t> prog; { FILE* f = fopen(argv[1], "r"); if (!f) return 2; unsigned w; while (fscanf(f, "%x", &w) == 1) prog.push_back(w); fclose(f); }
  top = new Vsilicaflux_top;
  top->rst_n = 0; top->imem_wr_en = 0; top->tile_phy_tx_credit = 1; top->tile_phy_rx_valid = 0; top->tile_phy_rx_data = 0; top->fb_scan_addr = 0;
  for (int i = 0; i < 4; i++) tick();
  for (size_t i = 0; i < prog.size(); i++) { top->imem_wr_en = 1; top->imem_wr_addr = i; top->imem_wr_data = prog[i]; tick(); }
  top->imem_wr_en = 0; tick();
  top->rst_n = 1;
  uint64_t guard = 0; while (!top->halt) { tick(); if (++guard > 50000000ull) { fprintf(stderr, "TIMEOUT: no halt\n"); return 3; } }
  uint64_t halt_cycle = cycles;
  for (int i = 0; i < 5000; i++) tick();
  std::vector<uint32_t> col(FB_W * FB_H);
  for (int i = 0; i < FB_W * FB_H; i++) { top->fb_scan_addr = i; tick(); col[i] = top->fb_scan_data; }
  FILE* f = fopen((out + "/final.col").c_str(), "wb"); fwrite(col.data(), 4, col.size(), f); fclose(f);
  printf("cluster_harness: %zu instruction words, halt after %llu cycles\n", prog.size(), (unsigned long long)halt_cycle);
#ifdef CLUSTER_DEBUG
  { auto& r = *top->rootp;
    printf("DEBUG tile3: tri_in=%u setup=%u raster=%u pix_cov=%u written=%u addr_err=%u num_tri=%u vtx_base=%u tri_base=%u ctrl=%#x\n",
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__c_tri_in,
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__c_tri_setup,
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__c_tri_raster,
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__c_pix_cov,
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__c_pix_written,
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__c_tri_addr_err,
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__num_tri,
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__vtx_base,
      r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__tri_base,
      (unsigned)r.silicaflux_top__DOT__g_tiles__BRA__3__KET____DOT__g_gfx__DOT__u_tile__DOT__ctrl);
  }
#endif
  top->final(); delete top; return 0;
}
