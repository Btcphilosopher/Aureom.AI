// =============================================================================
// sfgx_sched_top - integration test fixture
//
// The UNMODIFIED SilicaFlux v1.0 dataflow scheduler drives four tiles wired
// exactly as silicaflux_top.sv wires them (flat token fields, per-tile
// valid/ready, flat status vectors):
//     tile 0,1,2 : unmodified compute_tile  (vector engine / tensor unit / scratchpad)
//     tile 3     : sfgx_gfx_tile            (this extension)
// The control core / decoder / fetch are NOT part of this fixture: the testbench
// presents decoded_instr_t exactly as the (patched) decoder would for a D-format
// instruction.  What this verifies is the documented scheduler<->tile contract.
// =============================================================================
module sfgx_sched_top
  import silicaflux_pkg::*;
#(
  parameter int FB_W = 32,
  parameter int FB_H = 32,
  parameter int AW   = $clog2(FB_W * FB_H)
) (
  input  logic            clk,
  input  logic            rst_n,

  input  decoded_instr_t  instr_in,
  input  logic            instr_valid,
  output logic            instr_ready,
  input  logic [XLEN-1:0] scalar_a,
  input  logic [VLEN-1:0] vector_a,
  input  logic [VLEN-1:0] vector_b,

  output logic            sync_stall,
  output logic            wb_valid,
  output logic [4:0]      wb_reg,
  output logic [XLEN-1:0] wb_data,

  output logic [NUM_TILES-1:0]       tile_done_o,
  output logic [NUM_TILES-1:0]       tile_error_o,
  output logic [NUM_TILES*XLEN-1:0]  tile_scalar_o,
  output logic [NUM_TILES*VLEN-1:0]  tile_vector_o,
  output logic [NUM_TILES-1:0]       dispatch_o,        // token_valid && token_ready per tile

  input  logic [AW-1:0]   fb_scan_addr,
  output logic [31:0]     fb_scan_data
);
  logic [NUM_TILES-1:0] tok_valid, tok_ready;
  logic [XLEN-1:0]      s_scalar;
  logic [VLEN-1:0]      s_va, s_vb;
  logic [4:0]  tok_opcode; logic [2:0] tok_tile_id; logic [4:0] tok_src_reg, tok_dst_reg;
  logic [3:0]  tok_vsrc_reg, tok_vdst_reg; logic [13:0] tok_mem_addr; logic [4:0] tok_length; logic [7:0] tok_func;

  scheduler u_sched (
    .clk(clk), .rst_n(rst_n),
    .instr_in(instr_in), .instr_valid(instr_valid), .instr_ready(instr_ready),
    .scalar_a(scalar_a), .scalar_b('0), .vector_a(vector_a), .vector_b(vector_b),
    .tile_tok_valid_0(tok_valid[0]), .tile_tok_valid_1(tok_valid[1]),
    .tile_tok_valid_2(tok_valid[2]), .tile_tok_valid_3(tok_valid[3]),
    .tile_tok_ready_0(tok_ready[0]), .tile_tok_ready_1(tok_ready[1]),
    .tile_tok_ready_2(tok_ready[2]), .tile_tok_ready_3(tok_ready[3]),
    .sched_scalar_out(s_scalar), .sched_vector_a_out(s_va), .sched_vector_b_out(s_vb),
    .tok_opcode(tok_opcode), .tok_tile_id(tok_tile_id), .tok_src_reg(tok_src_reg), .tok_dst_reg(tok_dst_reg),
    .tok_vsrc_reg(tok_vsrc_reg), .tok_vdst_reg(tok_vdst_reg), .tok_mem_addr(tok_mem_addr),
    .tok_length(tok_length), .tok_func(tok_func),
    .tile_status_done(tile_done_o), .tile_status_scalar(tile_scalar_o),
    .wb_valid(wb_valid), .wb_reg(wb_reg), .wb_data(wb_data), .sync_stall(sync_stall)
  );

  assign dispatch_o = tok_valid & tok_ready;

  // ---- tiles 0..2: unmodified compute_tile ---------------------------------------------
  noc_flit_t tnoc_out [0:2];
  logic      tnoc_v   [0:2];
  generate
    for (genvar t = 0; t < 3; t++) begin : g_ct
      compute_tile #(.TILE_ID(t), .LANES(LANES_DEFAULT)) u_tile (
        .clk(clk), .rst_n(rst_n),
        .tok_opcode(tok_opcode), .tok_tile_id(tok_tile_id), .tok_src_reg(tok_src_reg), .tok_dst_reg(tok_dst_reg),
        .tok_vsrc_reg(tok_vsrc_reg), .tok_vdst_reg(tok_vdst_reg), .tok_mem_addr(tok_mem_addr),
        .tok_length(tok_length), .tok_func(tok_func),
        .token_valid(tok_valid[t]), .token_ready(tok_ready[t]),
        .scalar_data_in(s_scalar), .vector_data_in(s_va), .vector_data_in_b(s_vb),
        .tile_done(tile_done_o[t]), .tile_error(tile_error_o[t]),
        .tile_result_scalar(tile_scalar_o[t*XLEN +: XLEN]), .tile_result_vector(tile_vector_o[t*VLEN +: VLEN]),
        .noc_flit_out(tnoc_out[t]), .noc_flit_valid(tnoc_v[t]), .noc_flit_ready(1'b1),
        .noc_flit_in('0), .noc_flit_in_valid(1'b0), .noc_flit_in_ready()
      );
    end
  endgenerate

  // ---- tile 3: graphics tile in the compute_tile slot ---------------------------------------
  noc_flit_t g_noc_out;
  logic      g_noc_v;
  sfgx_gfx_tile #(.TILE_ID(3), .FB_W(FB_W), .FB_H(FB_H)) u_gfx (
    .clk(clk), .rst_n(rst_n),
    .tok_opcode(tok_opcode), .tok_tile_id(tok_tile_id), .tok_src_reg(tok_src_reg), .tok_dst_reg(tok_dst_reg),
    .tok_vsrc_reg(tok_vsrc_reg), .tok_vdst_reg(tok_vdst_reg), .tok_mem_addr(tok_mem_addr),
    .tok_length(tok_length), .tok_func(tok_func),
    .token_valid(tok_valid[3]), .token_ready(tok_ready[3]),
    .scalar_data_in(s_scalar), .vector_data_in(s_va), .vector_data_in_b(s_vb),
    .tile_done(tile_done_o[3]), .tile_error(tile_error_o[3]),
    .tile_result_scalar(tile_scalar_o[3*XLEN +: XLEN]), .tile_result_vector(tile_vector_o[3*VLEN +: VLEN]),
    .noc_flit_out(g_noc_out), .noc_flit_valid(g_noc_v), .noc_flit_ready(1'b1),
    .noc_flit_in('0), .noc_flit_in_valid(1'b0), .noc_flit_in_ready(),
    .fb_scan_addr(fb_scan_addr), .fb_scan_data(fb_scan_data), .gfx_busy(),
    .dbg_tri_valid(), .dbg_tri_data(), .dbg_cov_valid(), .dbg_cov_x(), .dbg_cov_y()
  );
endmodule
