// =============================================================================
// sched_harness.cpp - drives sfgx_sched_top: the UNMODIFIED SilicaFlux scheduler,
// three UNMODIFIED compute_tiles (slots 0-2) and sfgx_gfx_tile (slot 3).
//
//   sched_harness <file.tok> <outdir> [interleave]
//
// Every token of the scene becomes a decoded_instr_t for tile 3, dispatched by the
// real scheduler (token fields broadcast, per-tile valid/ready, done scoreboard).
// With `interleave`, every GFXDRAW is dispatched asynchronously and, while tile 3 is
// busy, the harness (a) runs a VADD on compute tile 0 and checks its result, then
// (b) issues a DFSYNC whose barrier must hold the scalar side until the draw is done.
// Frames are captured through the display read port exactly as in sfgx_harness.
// Outputs: tokens.txt, <cap>.col/.z/.ppm (+ empty tris.txt / zero .cov : no taps here),
//          selftest.txt (interleave checks).
// =============================================================================
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <sys/stat.h>
#include "verilated.h"
#include "Vsfgx_sched_top.h"
#include "Vsfgx_sched_top___024root.h"

#ifndef FB_W
#define FB_W 32
#endif
#ifndef FB_H
#define FB_H 32
#endif
static Vsfgx_sched_top* top;
static uint64_t cycles = 0;
static bool     done_seen[4]; static uint32_t done_scalar[4]; static uint32_t done_vec[4][4]; static bool done_err[4];
static uint64_t sync_stall_cycles = 0;

static void tick() {
  top->clk = 0; top->eval(); top->clk = 1; top->eval(); cycles++;
  if (top->sync_stall) sync_stall_cycles++;
  for (int t = 0; t < 4; t++) if ((top->tile_done_o >> t) & 1) {
    done_seen[t] = true; done_scalar[t] = top->tile_scalar_o[t];
    for (int i = 0; i < 4; i++) done_vec[t][i] = top->tile_vector_o[t * 4 + i];
    done_err[t] = (top->tile_error_o >> t) & 1;
  }
}

// decoded_instr_t packed layout (silicaflux_pkg.sv), LSB first:
// valid[0] fmt[2:1] func[10:3] tile_id[13:11] imm[30:14] vrs2[34:31] vrs1[38:35] vrd[42:39] rs2[47:43] rs1[52:48] rd[57:53] opcode[62:58]
static uint64_t mk_instr(unsigned op, unsigned tile, unsigned addr14, unsigned len5, unsigned fmt) {
  uint64_t v = 1;
  v |= (uint64_t)(fmt & 3) << 1;
  v |= (uint64_t)(len5 & 0xFF) << 3;          // D-format: func = {3'b0, len[4:0]}
  v |= (uint64_t)(tile & 7) << 11;
  v |= (uint64_t)(addr14 & 0x1FFFF) << 14;    // D-format: imm = {3'b0, addr14}
  v |= (uint64_t)1 << 48;                     // rs1 = r1 (the scalar operand is delivered on scalar_a)
  v |= (uint64_t)(op & 31) << 58;
  return v;
}
// silicaflux_pkg::get_format, extended with 0x18-0x1E as D-format (what the integration patch does)
static unsigned fmt_of(unsigned op) {
  if (op >= 1 && op <= 3) return 0;
  if (op >= 4 && op <= 9) return 1;
  if ((op >= 0x0A && op <= 0x0E) || (op >= 0x18 && op <= 0x1E)) return 2;
  if (op >= 0x0F && op <= 0x17) return 3;
  return 0;
}

static bool dispatch(unsigned op, unsigned tile, unsigned addr, uint32_t scalar, const uint32_t va[4],
                     const uint32_t vb[4], unsigned len, uint64_t max_cycles = 200000000ull) {
  uint64_t t0 = cycles;
  done_seen[tile] = false;
  top->instr_in = mk_instr(op, tile, addr, len, fmt_of(op));
  top->scalar_a = scalar;
  for (int i = 0; i < 4; i++) { top->vector_a[i] = va[i]; top->vector_b[i] = vb[i]; }
  top->instr_valid = 1;
  top->eval();
  while (!((top->dispatch_o >> tile) & 1)) { tick(); top->eval(); if (cycles - t0 > max_cycles) return false; }
  tick();                                       // the edge on which valid && ready is sampled
  top->instr_valid = 0; top->instr_in = 0; top->eval();
  return true;
}
static bool wait_done(unsigned tile, uint64_t max_cycles = 200000000ull) {
  uint64_t t0 = cycles;
  while (!done_seen[tile]) { tick(); if (cycles - t0 > max_cycles) return false; }
  return true;
}

static std::vector<uint16_t> zero_cov(FB_W * FB_H, 0);
static void capture(const std::string& dir, const std::string& name) {
  std::vector<uint32_t> col(FB_W * FB_H);
  for (int i = 0; i < FB_W * FB_H; i++) { top->fb_scan_addr = i; tick(); col[i] = top->fb_scan_data; }
  auto& zmem = top->rootp->sfgx_sched_top__DOT__u_gfx__DOT__u_fb__DOT__zmem;
  std::vector<uint16_t> z(FB_W * FB_H);
  for (int i = 0; i < FB_W * FB_H; i++) z[i] = zmem[i];
  FILE* f;
  f = fopen((dir + "/" + name + ".col").c_str(), "wb"); fwrite(col.data(), 4, col.size(), f); fclose(f);
  f = fopen((dir + "/" + name + ".z").c_str(), "wb");   fwrite(z.data(), 2, z.size(), f);   fclose(f);
  f = fopen((dir + "/" + name + ".cov").c_str(), "wb"); fwrite(zero_cov.data(), 2, zero_cov.size(), f); fclose(f);
  f = fopen((dir + "/" + name + ".ppm").c_str(), "wb");
  fprintf(f, "P6\n%d %d\n255\n", FB_W, FB_H);
  for (int i = 0; i < FB_W * FB_H; i++) { unsigned char p[3] = {(unsigned char)(col[i] >> 16), (unsigned char)(col[i] >> 8), (unsigned char)col[i]}; fwrite(p, 1, 3, f); }
  fclose(f);
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  if (argc < 3) { fprintf(stderr, "usage: %s file.tok outdir [interleave]\n", argv[0]); return 2; }
  std::string tokfile = argv[1], outdir = argv[2];
  bool interleave = argc > 3 && !strcmp(argv[3], "interleave");
  mkdir(outdir.c_str(), 0755);
  top = new Vsfgx_sched_top;
  top->rst_n = 0; top->instr_valid = 0; top->instr_in = 0; top->scalar_a = 0; top->fb_scan_addr = 0;
  for (int i = 0; i < 4; i++) { top->vector_a[i] = 0; top->vector_b[i] = 0; }
  for (int i = 0; i < 8; i++) tick();
  top->rst_n = 1;
  for (int i = 0; i < 4; i++) tick();

  FILE* ftok = fopen((outdir + "/tokens.txt").c_str(), "w");
  FILE* ftri = fopen((outdir + "/tris.txt").c_str(), "w"); fclose(ftri);
  FILE* fst  = fopen((outdir + "/selftest.txt").c_str(), "w");
  FILE* in = fopen(tokfile.c_str(), "r");
  if (!in) { fprintf(stderr, "cannot open %s\n", tokfile.c_str()); return 2; }
  char line[512]; unsigned ntok = 0, ncap = 0, n_vadd = 0, n_vadd_ok = 0, n_overlap = 0, n_sync = 0;
  const uint32_t zero4[4] = {0, 0, 0, 0};
  while (fgets(line, sizeof line, in)) {
    if (line[0] == 'C') { char name[256]; sscanf(line + 2, "%255s", name); capture(outdir, name); ncap++; continue; }
    if (line[0] != 'T') continue;
    unsigned op, addr, len; uint32_t scalar, v[4];
    sscanf(line + 2, "%x %x %x %x %x %x %x %x", &op, &addr, &scalar, &v[0], &v[1], &v[2], &v[3], &len);
    uint64_t c0 = cycles;
    if (!dispatch(op, 3, addr, scalar, v, zero4, len)) { fprintf(stderr, "TIMEOUT dispatching token %u\n", ntok); return 3; }

    if (interleave && op == 0x19) {            // GFXDRAW: tile 3 is now busy for a long time
      // (a) VADD on compute tile 0 while the draw runs: must complete, and the draw must still be running
      const uint32_t va[4] = {1, 2, 3, 4}, vb[4] = {10, 20, 30, 40};
      if (!dispatch(0x0F, 0, 0, 0, va, vb, 0)) { fprintf(stderr, "TIMEOUT VADD\n"); return 3; }
      if (!wait_done(0)) { fprintf(stderr, "TIMEOUT VADD done\n"); return 3; }
      n_vadd++;
      bool ok = !done_err[0] && done_vec[0][0] == 11 && done_vec[0][1] == 22 && done_vec[0][2] == 33 && done_vec[0][3] == 44;
      if (ok) n_vadd_ok++;
      if (!done_seen[3]) n_overlap++;           // draw still running => genuinely concurrent
      fprintf(fst, "VADD tile0 -> {%u,%u,%u,%u} err=%d overlapped_with_draw=%d\n", done_vec[0][0], done_vec[0][1], done_vec[0][2], done_vec[0][3], done_err[0], !done_seen[3]);
      // (b) DFSYNC barrier: cannot dispatch until tile 3 is idle; the scheduler must assert sync_stall meanwhile
      uint64_t s0 = sync_stall_cycles;
      if (!dispatch(0x0E, 3, 0, 0, zero4, zero4, 0)) { fprintf(stderr, "TIMEOUT DFSYNC\n"); return 3; }
      if (!wait_done(3)) { fprintf(stderr, "TIMEOUT DFSYNC done\n"); return 3; }
      n_sync += (sync_stall_cycles > s0);
      // the DFSYNC consumed the draw's own done pulse; its result was captured by tick() in done_scalar before being overwritten
    } else if (!wait_done(3)) {
      fprintf(stderr, "TIMEOUT waiting tile_done for token %u (op %#x)\n", ntok, op); return 3;
    }
    uint32_t res = done_scalar[3];
    // when interleaved, GFXDRAW's own result was overwritten by DFSYNC's (0): report the draw result via GFXSTAT-free path
    if (interleave && op == 0x19) res = 0xFFFFFFFFu;     // marker: not comparable (compare_rtl skips it)
    fprintf(ftok, "%x %x %d %llu\n", op, res, done_err[3] ? 1 : 0, (unsigned long long)(cycles - c0));
    ntok++;
  }
  fprintf(fst, "SUMMARY vadd=%u vadd_ok=%u overlapped=%u dfsync_barrier_held=%u sync_stall_cycles=%llu\n",
          n_vadd, n_vadd_ok, n_overlap, n_sync, (unsigned long long)sync_stall_cycles);
  fclose(fst); fclose(in); fclose(ftok);
  printf("sched_harness: %u tokens, %u captures, %llu cycles | vadd %u/%u ok, overlapped %u, barrier held %u\n",
         ntok, ncap, (unsigned long long)cycles, n_vadd_ok, n_vadd, n_overlap, n_sync);
  top->final(); delete top;
  return 0;
}
