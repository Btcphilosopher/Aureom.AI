# SilicaFlux Graphics Extension (SFGX)

A synthesizable SystemVerilog **triangle renderer packaged as a SilicaFlux tile**: vertex input → restricted vertex transform → homogeneous clipping → triangle setup
→ rasterisation (top-left rule) → depth test → colour interpolation → framebuffer, with **perspective-correct texture sampling** added on top once the untextured
pipeline was verified. It keeps the SilicaFlux v1.0 compute architecture's documented interfaces (token interface, scheduler, scratchpad `memory_controller`, the
README's reserved opcodes `0x18`–`0x1E`), is checked bit-for-bit against a software reference rasteriser, and ships a rotating-triangle and a 3D-scene demonstration.

> **This is not an OpenGL / Vulkan / Direct3D implementation and makes no conformance claim.** It is a fixed-function renderer for simple scenes. Vulkan/OpenGL
> integration is a separate future project (`docs/06_LIMITATIONS_AND_FUTURE.md`). Display output is *integration*, kept apart from the engine (`docs/05_DISPLAY_INTEGRATION.md`).
> **Nothing here has run on physical hardware.**

## What is in the box

```
rtl/                      the engine: sfgx_pkg, sfgx_divu, sfgx_vertex, sfgx_clip, sfgx_raster, sfgx_tex, sfgx_fb, sfgx_gfx_tile (+ lint waivers)
integration/display/      display-side scan-out + token-ROM demo top (NOT part of the engine)
integration/*.patch       the 3 small edits to the baseline needed to use the new opcodes from a real instruction stream
third_party/              the UNMODIFIED SilicaFlux v1.0 RTL (+ SHA-256 sums) used by the integration tests
ref/                      sfgx_ref.py (bit-accurate reference = executable spec), sfgx_float_ref.py (independent float64), scenes.py (test/demo generator)
tb/                       Verilator harnesses (tile, scheduler-level, display, full cluster) and the scheduler fixture
tests/                    regression, property, float, bounds, mutation, scheduler-/display-/cluster-level checks, run_all.sh
sim/                      build/lint/synthesis scripts
scenes/                   generated command streams (.cmd) replayed identically by the reference and the RTL
demo/                     animations and contact sheets rendered BY THE RTL SIMULATION (rotating triangle, 3D scene, textured 3D scene, texture tests)
results/                  logs and evidence from the final run (verification summary, synthesis, mutation results, display/cluster runs)
docs/                     01 architecture · 02 numeric specification · 03 SilicaFlux integration · 04 verification · 05 display · 06 limitations
```

## Quick start

Requirements: Verilator ≥ 5.0, Python 3 with `numpy` and `Pillow`, `g++`/`make`. For the synthesis check: a Yosys with the `read_slang` front-end (`pip install yowasp-yosys`).

```bash
tests/run_all.sh                    # lint + spec checks + RTL==reference on every scene + scheduler-level integration (≈ 4 min)
python3 tests/compare_display.py    # token ROM -> engine -> scan-out -> captured VIDEO frame == reference
python3 tests/compare_cluster.py    # a hand-assembled SilicaFlux program in the full patched cluster draws a triangle
python3 tests/mutation_test.py      # 58 injected RTL faults must all be killed (≈ 1 h)
YOSYS=yowasp-yosys sim/synth_check.sh xilinx 160 120    # Yosys/Xilinx-7 mapping + check -assert
python3 tools/bench.py              # measured cycles per triangle / pixel
```

## Demonstrations (frames captured from the RTL simulation through the framebuffer read port)

| | |
|---|---|
| `demo/demo_triangle.gif`  | rotating colour-interpolated triangle, 160×120, perspective, 24 frames |
| `demo/demo_scene.gif`     | two spinning/orbiting cubes over a ground plane, depth test + back-face culling, 36 frames |
| `demo/demo_textured.gif`  | the same scene with a brick texture on perspective-correct cubes (modulated by vertex colour), 36 frames |
| `demo/display_video_frame_640x480.png` | one frame captured from the **scan-out's video pixel stream** (display-integration test), 4× replication |
| `demo/texture_tests_sheet.png` | the 17 directed texture cases (repeat/clamp, non-square, 1×1, 64×64, perspective ground, near-plane clip, depth interaction, …) |

## Headline results (details and caveats in `docs/04_VERIFICATION.md`)

* **RTL = reference, bit for bit** (colour buffer, depth buffer, per-pixel coverage counts, every token result and error flag, every counter, and the post-clip triangle trace) on 18 scene sets from 21×17 to 640×480,
  including shared-edge meshes, clip-plane boundary cases (vertex on / just inside / just outside each of the six planes, edges lying in a plane, `w ≤ 0`, negative post-rounding distance), culling, all depth functions,
  error paths, over 4 000 random triangles and the textured scenes.
* **Shared edges are covered exactly once**, checked independently with exact rational arithmetic (and the check is shown to reject three broken edge rules while accepting an equally watertight bottom-right rule).
* **Fixed-point spec vs an independent float64 renderer:** every difference is accounted for (edge vicinity, depth near-tie, ≤ 1 LSB, texel boundary scaled by local magnification).
* **Mutation testing:** see `docs/04_VERIFICATION.md` for the final score and the classified survivors.
* **Integration:** the *unmodified* scheduler drives the graphics tile while a real `VADD` runs on a compute tile; a real instruction program in the patched cluster draws a triangle that matches the reference pixel for pixel;
  a captured video frame from the scan-out matches the reference ×4 with exact 640×480@60 timing.
* **Synthesizable:** Verilator `-Wall` clean; Yosys `check -assert` clean; Xilinx-7 mapping ≈ 23.8 k LUT / 14.5 k FF / 76 DSP48E1 / 28 RAMB36 (timing **not** closed).
* **Found in the baseline (not changed):** a scheduler hazard that silently drops an instruction waiting for a tile that completes that cycle, and several other defects (`docs/03_SILICAFLUX_INTEGRATION.md` §4).

## Specification highlights (full text: `docs/02_NUMERIC_SPEC.md`)

Right-handed, camera down −Z · clip volume `−w…w` (near `z=−w`) · window origin top-left, +Y down, sample at pixel centre · Q16.16 vertex math with saturation ·
exact 34-bit clip-plane distances, Q0.32 intersection parameter · **1/256-pixel** subpixel precision · **top-left** fill rule (a pixel centre on a shared edge belongs to exactly one triangle) ·
**Z16 depth, 0 = near**, linear in NDC z · colour interpolated affinely in screen space, texture perspective-correctly · 64-bit wrapping plane accumulators · every address/coordinate checked, never aliased.

## Honest limits (full list: `docs/06_LIMITATIONS_AND_FUTURE.md`)

Slow (≈ 1.6 k clocks per triangle, ≈ 2 per pixel, ≈ 55 per textured pixel) · 16-bit depth · nearest-only, ≤ 64×64 textures · no blending/stencil/scissor · single tile, NoC unused ·
no hardware run, no timing closure · reference and RTL share an author (common-mode risk mitigated, not eliminated).
