# Provenance and licensing notice

* `third_party/silicaflux_v1_0/` is the **unmodified** SilicaFlux v1.0 RTL (`rtl/*.sv`) and `docs/ISA_REFERENCE.md`, extracted from `SilicaFlux-main/silicaflux.zip` in the
  repository this extension was built for. SHA-256 sums of every file are in `third_party/silicaflux_v1_0/SHA256SUMS`, and of the source zip in `SOURCE_ZIP_SHA256`.
  The source bundle states no licence; it remains under whatever terms its owner applies.
* Everything else in this package (`rtl/`, `integration/`, `ref/`, `tb/`, `tests/`, `tools/`, `sim/`, `docs/`, `scenes/`, `demo/`) was written for this extension. No licence is granted by this package;
  the repository owner decides how it is licensed.
* `integration/silicaflux_cluster_*.patch` are diffs against the vendored baseline files above; they are not applied to `third_party/`.
* This package was **not committed to any repository**. It makes no claim of conformance to OpenGL, Vulkan, Direct3D or any other API.
