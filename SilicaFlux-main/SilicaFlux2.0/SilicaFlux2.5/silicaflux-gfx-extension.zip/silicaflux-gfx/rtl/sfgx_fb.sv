// =============================================================================
// SFGX - framebuffer + depth buffer + clear engine
// sfgx_fb.sv
//
// Colour buffer : FB_W*FB_H words of 32 bit, {8'h00, R8, G8, B8}
// Depth buffer  : FB_W*FB_H words of 16 bit (Z16, 0 = near, 0xFFFF = far)
// Address       : y*FB_W + x  (row-major, row 0 = TOP of the image)
//
// Port A (read-first, synchronous, one master at a time - rasteriser, pixel
//         read-back, or the clear engine) : read data appears one clock later.
// Port B (read only, synchronous)         : colour read for scan-out / capture.
// This maps onto a true-dual-port block RAM: A = read/write, B = read.
//
// Memories have no reset (BRAM-inferrable); a CLEAR is required before the
// first frame.  Simulation initialises them to zero.
// =============================================================================
module sfgx_fb #(
  parameter int FB_W = 160,
  parameter int FB_H = 120,
  parameter int AW   = $clog2(FB_W * FB_H)
) (
  input  logic          clk,
  input  logic          rst_n,

  // clear engine (rasteriser/read-back must be idle while busy)
  input  logic          clr_start,
  input  logic          clr_color_en,
  input  logic          clr_depth_en,
  input  logic [23:0]   clr_color,
  input  logic [15:0]   clr_depth,
  output logic          clr_busy,

  // port A
  input  logic [AW-1:0] a_addr,
  input  logic          a_wr_c,
  input  logic          a_wr_z,
  input  logic [23:0]   a_wdata_c,
  input  logic [15:0]   a_wdata_z,
  output logic [31:0]   a_rdata_c,
  output logic [15:0]   a_rdata_z,

  // port B (colour only)
  input  logic [AW-1:0] b_addr,
  output logic [31:0]   b_rdata
);
  localparam int N = FB_W * FB_H;

  logic [31:0] cmem [0:N-1];
  logic [15:0] zmem [0:N-1];

  // ---- clear engine ----------------------------------------------------------
  logic [AW-1:0] clr_ptr;
  logic          clr_c_r, clr_z_r;
  logic [23:0]   clr_col_r;
  logic [15:0]   clr_dep_r;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      clr_busy <= 1'b0; clr_ptr <= '0; clr_c_r <= 1'b0; clr_z_r <= 1'b0;
      clr_col_r <= '0; clr_dep_r <= '0;
    end else if (clr_start && !clr_busy) begin
      clr_busy  <= 1'b1;
      clr_ptr   <= '0;
      clr_c_r   <= clr_color_en;
      clr_z_r   <= clr_depth_en;
      clr_col_r <= clr_color;
      clr_dep_r <= clr_depth;
    end else if (clr_busy) begin
      if (clr_ptr == AW'(N - 1)) clr_busy <= 1'b0;
      else                       clr_ptr  <= clr_ptr + AW'(1);
    end
  end

  // ---- port A multiplexing (clear engine has priority while busy) ---------
  logic [AW-1:0] m_addr;
  logic          m_wc, m_wz;
  logic [23:0]   m_cdata;
  logic [15:0]   m_zdata;
  always_comb begin
    if (clr_busy) begin
      m_addr = clr_ptr; m_wc = clr_c_r; m_wz = clr_z_r; m_cdata = clr_col_r; m_zdata = clr_dep_r;
    end else begin
      m_addr = a_addr;  m_wc = a_wr_c;  m_wz = a_wr_z;  m_cdata = a_wdata_c;  m_zdata = a_wdata_z;
    end
  end

  always_ff @(posedge clk) begin
    if (m_wc) cmem[m_addr] <= {8'h00, m_cdata};
    a_rdata_c <= cmem[m_addr];
    if (m_wz) zmem[m_addr] <= m_zdata;
    a_rdata_z <= zmem[m_addr];
    b_rdata   <= cmem[b_addr];
  end

`ifndef SYNTHESIS
  // simulation-only: deterministic power-up contents
  initial begin
    for (int i = 0; i < N; i++) begin cmem[i] = 32'h0; zmem[i] = 16'hFFFF; end
  end
`endif
endmodule
