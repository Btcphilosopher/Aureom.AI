// =============================================================================
// SFGX - triangle setup + rasteriser + depth test + framebuffer write
// sfgx_raster.sv
//
// Input : one screen-space triangle (3 x SV; X,Y in 1/256 px, Z in Q16.8,
//         colour in Q8.8) per valid/ready handshake.
//
// SETUP  area2 = (X1-X0)(Y2-Y0) - (X2-X0)(Y1-Y0)           (exact, 1/65536 px^2)
//        area2 == 0            -> degenerate, dropped
//        area2 <  0            -> counter-clockwise AS SEEN (window Y is down)
//        front = CCW unless CTRL.FRONT_CW; CTRL.CULL drops back/front faces
//        area2 <  0            -> swap V1,V2 so that area2 > 0 (clockwise as seen)
//        edges e0:V0->V1  e1:V1->V2  e2:V2->V0,  E(p) = dx*(py-ay) - dy*(px-ax)
//        TOP-LEFT RULE: an edge is "top-left" iff dy < 0, or dy == 0 and dx > 0.
//        A pixel centre p is covered iff, for all i,  E_i(p) > 0, or E_i(p) == 0
//        and edge i is top-left  (i.e. E_i(p) - bias_i >= 0, bias = 0 / 1).
//        Window origin is the top-left; pixel (i,j) has its sample at (i+.5, j+.5).
//
// INTERPOLATION  for attribute v in {Z, R, G, B} (Q?.8 integers):
//        v(p) = v0 + gX*(pX-X0) + gY*(pY-Y0)     (exact integer plane equation)
//        gX = round_away( ((-(dy1 v0 + dy2 v1 + dy0 v2)) << 24) / area2 )
//        gY = round_away( (( (dx1 v0 + dx2 v1 + dx0 v2)) << 24) / area2 )
//        (gradients are per 1/256 px with 24 fractional bits; all accumulators are
//        64-bit two's complement and wrap; the shipped value is
//        (acc + 2^31) >>> 32  clamped to [0,255] (colour) / [0,65535] (depth).)
//
// RASTER  bbox scan (rows top->bottom, pixels left->right), 1 cycle per
//        uncovered pixel, 2 per covered pixel (depth read, then test+write).
//        Depth: Z16, 0 = near; CTRL.ZTEST / ZWRITE / ZFUNC (OpenGL numbering).
//
// TEXTURE (CTRL.TEX_EN) - only pixels that PASS the depth test are sampled:
//        s,t,q (= u/w, v/w, 1/w, 40-bit, 24 fractional bits) are interpolated like Z/R/G/B but with
//        12 gradient fractional bits (so the 64-bit accumulators cannot overflow);
//        per pixel   S = (acc_s + 2^11) >>> 12  (T, Q alike),  Q' = max(Q, 1)
//                    tx_f = floor( (S << log2W) / Q' ),  ty_f = floor( (T << log2H) / Q' )
//        REPEAT: tx = tx_f mod W (two's-complement low bits) | CLAMP: tx = clamp(tx_f, 0, W-1)
//        texel = tex[(ty << log2W) | tx];   REPLACE: colour = texel
//        MODULATE: c = (y + 1 + (y >> 8)) >> 8  with  y = texel_c * vertex_c + 127   (= round(texel*vertex/255))
//
// Overflow: all window coordinates are clamped to the framebuffer rectangle by
// the clipper, so areas/edge values are < 2^40 and the 48-bit edge registers
// cannot overflow (FB_W, FB_H <= 2048).  Plane accumulators wrap (64-bit) by
// design; covered pixels are inside the triangle, hence within range.
// =============================================================================
module sfgx_raster
  import sfgx_pkg::*;
#(
  parameter int FB_W = 160,
  parameter int FB_H = 120,
  parameter int AW   = $clog2(FB_W * FB_H)
) (
  input  logic                 clk,
  input  logic                 rst_n,

  input  logic [CTRL_W-1:0]    ctrl,
  input  logic [7:0]           tex_log2,         // [3:0] log2 width, [7:4] log2 height

  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic [3*SVW-1:0]     in_data,
  output logic                 busy,

  // framebuffer port A
  output logic [AW-1:0]        fb_addr,
  output logic                 fb_wr_c,
  output logic                 fb_wr_z,
  output logic [23:0]          fb_wdata_c,
  output logic [15:0]          fb_wdata_z,
  input  logic [15:0]          fb_zrdata,

  // texture memory read port (data one clock after address)
  output logic [TEX_AW-1:0]    tex_addr,
  input  logic [23:0]          tex_rdata,

  // event pulses (one clock)
  output logic                 ev_degen,
  output logic                 ev_cull,
  output logic                 ev_raster,
  output logic                 ev_cov,
  output logic                 ev_wr,
  output logic                 ev_zfail,
  output logic                 ev_tex,           // a pixel passed the depth test and is being sampled

  // debug tap: coverage event
  output logic                 dbg_cov_valid,
  output logic [11:0]          dbg_cov_x,
  output logic [11:0]          dbg_cov_y
);

  // ---------------------------------------------------------------------------
  // storage
  // ---------------------------------------------------------------------------
  logic [23:0] vX [0:2];
  logic [23:0] vY [0:2];
  logic signed [39:0] att [0:20];            // att[a*3+v]: a=0 Z, 1 R, 2 G, 3 B (non-negative), 4 s, 5 t, 6 q
  logic signed [52:0] area2;
  logic signed [47:0] e_row [0:2];
  logic signed [47:0] e_pix [0:2];
  logic signed [63:0] gx [0:6];
  logic signed [63:0] gy [0:6];
  logic signed [63:0] a_row [0:6];
  logic signed [63:0] a_pix [0:6];
  logic [11:0] x0, x1, y0, y1, px, py;
  logic [AW-1:0] row_addr;                   // address of pixel (x0, y)
  logic [2:0]  ei;                           // edge / attribute loop counter
  logic [3:0]  gk;                           // gradient loop: attr*2+dir (0..13)
  logic        tex_en;
  assign tex_en = ctrl[CTRL_TEX_EN];

  // ---------------------------------------------------------------------------
  // divider for gradients
  // ---------------------------------------------------------------------------
  logic        div_start, div_busy, div_done;
  logic [79:0] div_num, div_quo;
  logic [39:0] div_den, div_rem;
  sfgx_divu #(.NW(80), .DW(40)) u_div (
    .clk(clk), .rst_n(rst_n), .start(div_start), .num(div_num), .den(div_den),
    .busy(div_busy), .done(div_done), .quo(div_quo), .rem(div_rem)
  );
  logic unused_div_busy;
  assign unused_div_busy = div_busy;

  // ---------------------------------------------------------------------------
  // geometry helpers (combinational from vertex registers)
  // ---------------------------------------------------------------------------
  function automatic logic signed [25:0] sx(input logic [23:0] a);
    sx = {2'b00, a};
  endfunction

  logic signed [25:0] dx [0:2];
  logic signed [25:0] dy [0:2];
  logic               bias [0:2];
  always_comb begin
    dx[0] = sx(vX[1]) - sx(vX[0]);  dy[0] = sx(vY[1]) - sx(vY[0]);
    dx[1] = sx(vX[2]) - sx(vX[1]);  dy[1] = sx(vY[2]) - sx(vY[1]);
    dx[2] = sx(vX[0]) - sx(vX[2]);  dy[2] = sx(vY[0]) - sx(vY[2]);
    for (int i = 0; i < 3; i++)
      bias[i] = ~((dy[i][25]) || ((dy[i] == 26'sd0) && (dx[i] > 26'sd0)));   // 0 if top-left else 1
  end

  // area before orientation fix (uses the unswapped vertex order); every difference
  // is an explicit 26-bit signed value, every product an explicit 52-bit signed value
  logic signed [25:0] a_dx1, a_dy2, a_dx2, a_dy1;
  logic signed [51:0] pa1, pa2;
  logic signed [52:0] area_c;
  always_comb begin
    a_dx1  = sx(vX[1]) - sx(vX[0]);
    a_dy2  = sx(vY[2]) - sx(vY[0]);
    a_dx2  = sx(vX[2]) - sx(vX[0]);
    a_dy1  = sx(vY[1]) - sx(vY[0]);
    pa1    = a_dx1 * a_dy2;
    pa2    = a_dx2 * a_dy1;
    area_c = 53'(pa1) - 53'(pa2);
  end

  // bounding box (conservative, clamped to framebuffer)
  logic [23:0] xmin, xmax, ymin, ymax;
  always_comb begin
    xmin = vX[0]; if (vX[1] < xmin) xmin = vX[1]; if (vX[2] < xmin) xmin = vX[2];
    xmax = vX[0]; if (vX[1] > xmax) xmax = vX[1]; if (vX[2] > xmax) xmax = vX[2];
    ymin = vY[0]; if (vY[1] < ymin) ymin = vY[1]; if (vY[2] < ymin) ymin = vY[2];
    ymax = vY[0]; if (vY[1] > ymax) ymax = vY[1]; if (vY[2] > ymax) ymax = vY[2];
  end
  logic [15:0] bx0, bx1, by0, by1;
  always_comb begin
    bx0 = xmin[23:8];
    bx1 = (xmax[23:8] > 16'(FB_W - 1)) ? 16'(FB_W - 1) : xmax[23:8];
    by0 = ymin[23:8];
    by1 = (ymax[23:8] > 16'(FB_H - 1)) ? 16'(FB_H - 1) : ymax[23:8];
  end

  // pixel-centre coordinates of the start pixel
  logic signed [25:0] pcx0, pcy0;
  assign pcx0 = {6'b0, x0, 8'h80};
  assign pcy0 = {6'b0, y0, 8'h80};

  // E_i at the start pixel for edge ei
  logic signed [25:0] ey_d, ex_d;
  logic signed [51:0] e_a, e_b;
  logic signed [47:0] e_start;
  always_comb begin
    ey_d    = pcy0 - sx(vY[ei[1:0]]);
    ex_d    = pcx0 - sx(vX[ei[1:0]]);
    e_a     = dx[ei[1:0]] * ey_d;
    e_b     = dy[ei[1:0]] * ex_d;
    e_start = 48'(e_a - e_b);
  end

  // gradient numerator for (attribute a = gk[3:1], direction gk[0]); F = 24 (Z,R,G,B) or 12 (s,t,q) fraction bits
  logic [2:0]          ga;
  logic [4:0]          gfs;
  logic signed [39:0]  gv0, gv1, gv2;
  logic signed [71:0]  gnum;
  logic        [71:0]  gabs;
  always_comb begin
    ga  = gk[3:1];
    gfs = (ga >= 3'd4) ? 5'(F_GRAD_T) : 5'(F_GRAD);
    gv0 = att[ga*3 + 0];
    gv1 = att[ga*3 + 1];
    gv2 = att[ga*3 + 2];
    if (!gk[0]) gnum = -(72'(dy[1] * gv0) + 72'(dy[2] * gv1) + 72'(dy[0] * gv2));
    else        gnum =   72'(dx[1] * gv0) + 72'(dx[2] * gv1) + 72'(dx[0] * gv2);
    gabs = gnum[71] ? 72'(-gnum) : 72'(gnum);
  end

  logic [79:0] gq;                           // rounded magnitude of the quotient
  logic        ground;
  logic signed [63:0] gres;
  assign ground = ({div_rem, 1'b0} >= {1'b0, div_den});
  assign gq     = div_quo + {79'b0, ground};
  assign gres   = gnum[71] ? 64'(-gq[63:0]) : 64'(gq[63:0]);

  // initial accumulator for attribute ei:  v0<<F + gx*(pcx0-X0) + gy*(pcy0-Y0)   (wrapping 64 bit)
  logic signed [63:0] acc0_v;
  logic signed [25:0] ox, oy;
  logic [4:0]         efs;
  always_comb begin
    ox     = pcx0 - sx(vX[0]);
    oy     = pcy0 - sx(vY[0]);
    efs    = (ei >= 3'd4) ? 5'(F_GRAD_T) : 5'(F_GRAD);
    acc0_v = (64'(att[ei*3]) <<< efs) + gx[ei] * 64'(ox) + gy[ei] * 64'(oy);
  end

  // pixel coverage: E_i - bias_i >= 0 for all i.  Evaluated through the sign bit of
  // an explicitly signed difference so no signed/unsigned operand mixing can occur.
  logic signed [47:0] eb [0:2];
  logic               px_cov;
  always_comb begin
    for (int i = 0; i < 3; i++) eb[i] = e_pix[i] - $signed({47'b0, bias[i]});
    px_cov = ~eb[0][47] & ~eb[1][47] & ~eb[2][47];
  end

  logic signed [63:0] rnd_z, rnd_r, rnd_g, rnd_b;
  logic signed [63:0] sh_z, sh_r, sh_g, sh_b;
  logic [15:0] zq;
  logic [7:0]  rq, gq8, bq;
  always_comb begin
    rnd_z = a_pix[0] + (64'sd1 <<< (F_GRAD + 7));
    rnd_r = a_pix[1] + (64'sd1 <<< (F_GRAD + 7));
    rnd_g = a_pix[2] + (64'sd1 <<< (F_GRAD + 7));
    rnd_b = a_pix[3] + (64'sd1 <<< (F_GRAD + 7));
    sh_z  = rnd_z >>> (F_GRAD + 8);
    sh_r  = rnd_r >>> (F_GRAD + 8);
    sh_g  = rnd_g >>> (F_GRAD + 8);
    sh_b  = rnd_b >>> (F_GRAD + 8);
    zq    = sh_z[31] ? 16'h0000 : (|sh_z[30:16]) ? 16'hFFFF : sh_z[15:0];
    rq    = sh_r[31] ? 8'h00 : (|sh_r[30:8]) ? 8'hFF : sh_r[7:0];
    gq8   = sh_g[31] ? 8'h00 : (|sh_g[30:8]) ? 8'hFF : sh_g[7:0];
    bq    = sh_b[31] ? 8'h00 : (|sh_b[30:8]) ? 8'hFF : sh_b[7:0];
  end

  // ---- texture: S,T,Q at the pixel, division operands, floor + wrap/clamp ---------------------------
  logic signed [63:0] ts_v, tt_v, tq_v, tqd;
  logic               ts_neg, tt_neg;
  logic [3:0]         wlog, hlog;
  logic [47:0]        tu_num, tv_num;
  logic [41:0]        ts_abs, tt_abs;
  always_comb begin
    ts_v   = (a_pix[4] + (64'sd1 <<< (F_GRAD_T - 1))) >>> F_GRAD_T;
    tt_v   = (a_pix[5] + (64'sd1 <<< (F_GRAD_T - 1))) >>> F_GRAD_T;
    tq_v   = (a_pix[6] + (64'sd1 <<< (F_GRAD_T - 1))) >>> F_GRAD_T;
    tqd    = (tq_v <= 64'sd0) ? 64'sd1 : tq_v;
    ts_neg = ts_v[63];
    tt_neg = tt_v[63];
    ts_abs = ts_neg ? 42'(-ts_v) : 42'(ts_v);
    tt_abs = tt_neg ? 42'(-tt_v) : 42'(tt_v);
    wlog   = tex_log2[3:0];
    hlog   = tex_log2[7:4];
    tu_num = 48'(ts_abs) << wlog;
    tv_num = 48'(tt_abs) << hlog;
  end

  logic        tdu_start, tdu_busy, tdu_done, tdv_busy, tdv_done;
  logic [47:0] tdu_quo, tdv_quo;
  logic [39:0] tdu_rem, tdv_rem;
  logic [39:0] tq_den;
  assign tq_den = tqd[39:0];
  sfgx_divu #(.NW(48), .DW(40)) u_tdu (.clk(clk), .rst_n(rst_n), .start(tdu_start), .num(tu_num), .den(tq_den),
                                       .busy(tdu_busy), .done(tdu_done), .quo(tdu_quo), .rem(tdu_rem));
  sfgx_divu #(.NW(48), .DW(40)) u_tdv (.clk(clk), .rst_n(rst_n), .start(tdu_start), .num(tv_num), .den(tq_den),
                                       .busy(tdv_busy), .done(tdv_done), .quo(tdv_quo), .rem(tdv_rem));
  logic unused_tdiv;
  assign unused_tdiv = tdu_busy ^ tdv_busy;

  // floor of the signed quotient, then REPEAT or CLAMP.
  // numerator >= 0: floor = quotient;  numerator < 0: floor(-a/b) = -(floor(a/b) + (remainder != 0))
  logic signed [49:0] qu_s, qv_s, tx_f, ty_f;
  logic signed [49:0] wmask_s, hmask_s;
  logic [5:0]         tx, ty;
  logic [5:0]         wmask, hmask;
  always_comb begin
    qu_s  = $signed({2'b00, tdu_quo});
    qv_s  = $signed({2'b00, tdv_quo});
    tx_f  = ts_neg ? -(qu_s + ((tdu_rem != 40'd0) ? 50'sd1 : 50'sd0)) : qu_s;
    ty_f  = tt_neg ? -(qv_s + ((tdv_rem != 40'd0) ? 50'sd1 : 50'sd0)) : qv_s;
    wmask = 6'((7'd1 << wlog) - 7'd1);
    hmask = 6'((7'd1 << hlog) - 7'd1);
    wmask_s = $signed({44'b0, wmask});
    hmask_s = $signed({44'b0, hmask});
    if (ctrl[CTRL_TEX_CLAMP]) begin
      tx = tx_f[49] ? 6'd0 : (tx_f > wmask_s) ? wmask : tx_f[5:0];
      ty = ty_f[49] ? 6'd0 : (ty_f > hmask_s) ? hmask : ty_f[5:0];
    end else begin
      tx = tx_f[5:0] & wmask;
      ty = ty_f[5:0] & hmask;
    end
  end

  // combine texel with the interpolated vertex colour
  logic [15:0] m_r, m_g, m_b;
  logic [7:0]  tc_r, tc_g, tc_b;
  always_comb begin
    m_r = tex_rdata[23:16] * rq  + 16'd127;
    m_g = tex_rdata[15:8]  * gq8 + 16'd127;
    m_b = tex_rdata[7:0]   * bq  + 16'd127;
    if (ctrl[CTRL_TEX_MOD]) begin
      tc_r = 8'((m_r + 16'd1 + {8'b0, m_r[15:8]}) >> 8);
      tc_g = 8'((m_g + 16'd1 + {8'b0, m_g[15:8]}) >> 8);
      tc_b = 8'((m_b + 16'd1 + {8'b0, m_b[15:8]}) >> 8);
    end else begin
      tc_r = tex_rdata[23:16]; tc_g = tex_rdata[15:8]; tc_b = tex_rdata[7:0];
    end
  end

  logic z_pass;
  always_comb begin
    if (ctrl[CTRL_ZTEST]) begin
      case (ctrl[CTRL_ZFUNC_LO +: 3])
        ZF_NEVER:    z_pass = 1'b0;
        ZF_LESS:     z_pass = (zq <  fb_zrdata);
        ZF_EQUAL:    z_pass = (zq == fb_zrdata);
        ZF_LEQUAL:   z_pass = (zq <= fb_zrdata);
        ZF_GREATER:  z_pass = (zq >  fb_zrdata);
        ZF_NOTEQUAL: z_pass = (zq != fb_zrdata);
        ZF_GEQUAL:   z_pass = (zq >= fb_zrdata);
        default:     z_pass = 1'b1;
      endcase
    end else begin
      z_pass = 1'b1;
    end
  end

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [4:0] {
    R_IDLE, R_AREA, R_DECIDE, R_PREP, R_E0, R_GNUM, R_GWAIT, R_ACC0, R_SCAN, R_TEST,
    R_TDIV, R_TWAIT, R_TRD, R_TWR
  } rstate_t;
  rstate_t st;

  assign in_ready = (st == R_IDLE);
  assign busy     = (st != R_IDLE);

  // framebuffer write strobes are combinational: R_TEST (untextured) or R_TWR (textured)
  logic wr_now;
  assign wr_now     = ((st == R_TEST) && z_pass && !tex_en) || (st == R_TWR);
  assign fb_wr_c    = wr_now;
  assign fb_wr_z    = wr_now && ctrl[CTRL_ZWRITE];
  assign fb_wdata_c = (st == R_TWR) ? {tc_r, tc_g, tc_b} : {rq, gq8, bq};
  assign fb_wdata_z = zq;

  logic is_front, ccw_front;
  logic [1:0] cull_mode;
  assign ccw_front = ~ctrl[CTRL_FRONT_CW];
  assign cull_mode = ctrl[CTRL_CULL_LO +: 2];
  assign is_front  = ccw_front ? area2[52] : (~area2[52] && (area2 != 53'sd0));

  logic adv;                                 // advance to the next pixel this cycle
  logic tu_ok, tv_ok;                        // texture divisions finished
  assign adv = ((st == R_SCAN) && !px_cov) || ((st == R_TEST) && !(z_pass && tex_en)) || (st == R_TWR);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= R_IDLE; area2 <= '0; x0 <= '0; x1 <= '0; y0 <= '0; y1 <= '0; px <= '0; py <= '0;
      row_addr <= '0; fb_addr <= '0; ei <= '0; gk <= '0; tex_addr <= '0; tdu_start <= 1'b0; tu_ok <= 1'b0; tv_ok <= 1'b0;
      div_start <= 1'b0; div_num <= '0; div_den <= '0;
      ev_degen <= 1'b0; ev_cull <= 1'b0; ev_raster <= 1'b0; ev_cov <= 1'b0; ev_wr <= 1'b0; ev_zfail <= 1'b0; ev_tex <= 1'b0;
      dbg_cov_valid <= 1'b0; dbg_cov_x <= '0; dbg_cov_y <= '0;
      for (int i = 0; i < 3; i++) begin vX[i] <= '0; vY[i] <= '0; e_row[i] <= '0; e_pix[i] <= '0; end
      for (int i = 0; i < 21; i++) att[i] <= '0;
      for (int a = 0; a < 7; a++) begin gx[a] <= '0; gy[a] <= '0; a_row[a] <= '0; a_pix[a] <= '0; end
    end else begin
      div_start     <= 1'b0;
      ev_degen      <= 1'b0;
      ev_cull       <= 1'b0;
      ev_raster     <= 1'b0;
      ev_cov        <= 1'b0;
      ev_wr         <= 1'b0;
      ev_zfail      <= 1'b0;
      ev_tex        <= 1'b0;
      tdu_start     <= 1'b0;
      dbg_cov_valid <= 1'b0;

      case (st)
        R_IDLE: if (in_valid) begin
          for (int v = 0; v < 3; v++) begin
            vX[v]       <= in_data[v*SVW + SV_X +: 24];
            vY[v]       <= in_data[v*SVW + SV_Y +: 24];
            att[0*3+v]  <= {16'b0, in_data[v*SVW + SV_Z +: 24]};
            att[1*3+v]  <= {24'b0, in_data[v*SVW + SV_R +: 16]};
            att[2*3+v]  <= {24'b0, in_data[v*SVW + SV_G +: 16]};
            att[3*3+v]  <= {24'b0, in_data[v*SVW + SV_B +: 16]};
            att[4*3+v]  <= in_data[v*SVW + SV_S +: 40];
            att[5*3+v]  <= in_data[v*SVW + SV_T +: 40];
            att[6*3+v]  <= in_data[v*SVW + SV_Q +: 40];
          end
          st <= R_AREA;
        end

        R_AREA: begin
          area2 <= area_c;
          st    <= R_DECIDE;
        end

        R_DECIDE: begin
          if (area2 == 53'sd0) begin
            ev_degen <= 1'b1; st <= R_IDLE;
          end else if ((cull_mode == 2'd1 && !is_front) || (cull_mode == 2'd2 && is_front)) begin
            ev_cull <= 1'b1; st <= R_IDLE;
          end else begin
            ev_raster <= 1'b1;
            if (area2[52]) begin                 // swap V1 <-> V2, make area positive
              vX[1] <= vX[2]; vX[2] <= vX[1];
              vY[1] <= vY[2]; vY[2] <= vY[1];
              for (int a = 0; a < 7; a++) begin
                att[a*3+1] <= att[a*3+2]; att[a*3+2] <= att[a*3+1];
              end
              area2 <= -area2;
            end
            st <= R_PREP;
          end
        end

        R_PREP: begin                            // vertex registers now final: bbox
          x0 <= bx0[11:0]; x1 <= bx1[11:0]; y0 <= by0[11:0]; y1 <= by1[11:0];
          px <= bx0[11:0]; py <= by0[11:0];
          if ((bx0 > bx1) || (by0 > by1)) st <= R_IDLE;     // no pixel can be covered
          else begin ei <= 3'd0; st <= R_E0; end
        end

        R_E0: begin                              // E_i at the start pixel
          e_row[ei[1:0]] <= e_start;
          e_pix[ei[1:0]] <= e_start;
          if (ei == 3'd2) begin gk <= 4'd0; st <= R_GNUM; end
          else ei <= ei + 3'd1;
        end

        R_GNUM: begin                            // start division for gradient gk
          div_num   <= 80'({8'b0, gabs}) << gfs;
          div_den   <= area2[39:0];
          div_start <= 1'b1;
          st        <= R_GWAIT;
        end
        R_GWAIT: if (div_done) begin
          if (!gk[0]) gx[gk[3:1]] <= gres; else gy[gk[3:1]] <= gres;
          if (gk == (tex_en ? 4'd13 : 4'd7)) begin ei <= 3'd0; st <= R_ACC0; end
          else begin gk <= gk + 4'd1; st <= R_GNUM; end
        end

        R_ACC0: begin
          a_row[ei] <= acc0_v;
          a_pix[ei] <= acc0_v;
          if (ei == (tex_en ? 3'd6 : 3'd3)) begin
            row_addr <= AW'(y0) * AW'(FB_W);
            fb_addr  <= AW'(y0) * AW'(FB_W) + AW'(x0);
            st       <= R_SCAN;
          end else ei <= ei + 3'd1;
        end

        R_SCAN: begin
          if (px_cov) begin
            ev_cov        <= 1'b1;
            dbg_cov_valid <= 1'b1;
            dbg_cov_x     <= px;
            dbg_cov_y     <= py;
            st            <= R_TEST;
          end
        end

        R_TEST: begin
          if (!z_pass)      ev_zfail <= 1'b1;
          else if (!tex_en) ev_wr    <= 1'b1;
          else begin ev_tex <= 1'b1; tdu_start <= 1'b1; tu_ok <= 1'b0; tv_ok <= 1'b0; st <= R_TDIV; end
        end

        // ---- textured pixel: two parallel divisions, texel fetch, combine, write ------------------------------
        R_TDIV:  st <= R_TWAIT;                      // dividers were started by R_TEST (operands are stable)
        R_TWAIT: begin
          if (tdu_done) tu_ok <= 1'b1;
          if (tdv_done) tv_ok <= 1'b1;
          if ((tu_ok || tdu_done) && (tv_ok || tdv_done)) begin
            tex_addr <= (TEX_AW'(ty) << wlog) | TEX_AW'(tx);
            st       <= R_TRD;
          end
        end
        R_TRD: st <= R_TWR;                          // texel data is registered at the end of this cycle
        R_TWR: ev_wr <= 1'b1;                        // write strobes are combinational; adv moves on

        default: st <= R_IDLE;
      endcase

      // ---- advance to the next pixel (from R_SCAN uncovered, or R_TEST) --------
      if (adv) begin
        if (px == x1) begin
          if (py == y1) begin
            st <= R_IDLE;
          end else begin
            py       <= py + 12'd1;
            px       <= x0;
            row_addr <= row_addr + AW'(FB_W);
            fb_addr  <= row_addr + AW'(FB_W) + AW'(x0);
            for (int i = 0; i < 3; i++) begin
              e_row[i] <= e_row[i] + 48'($signed(dx[i])) * 48'sd256;
              e_pix[i] <= e_row[i] + 48'($signed(dx[i])) * 48'sd256;
            end
            for (int a = 0; a < 7; a++) begin
              a_row[a] <= a_row[a] + (gy[a] <<< 8);
              a_pix[a] <= a_row[a] + (gy[a] <<< 8);
            end
            st <= R_SCAN;
          end
        end else begin
          px      <= px + 12'd1;
          fb_addr <= fb_addr + AW'(1);
          for (int i = 0; i < 3; i++) e_pix[i] <= e_pix[i] - 48'($signed(dy[i])) * 48'sd256;
          for (int a = 0; a < 7; a++) a_pix[a] <= a_pix[a] + (gx[a] <<< 8);
          st <= R_SCAN;
        end
      end
    end
  end

endmodule
