// =============================================================================
// SFGX - texture memory
// sfgx_tex.sv
//
// 2^AW texels of RGB888 (word = {R8,G8,B8}), row-major: index = (y << log2W) | x.
// One write port (OP_GFXTEX token path) and one synchronous read port (sampler,
// read data one clock after the address, read-first).  Block-RAM inferrable.
// =============================================================================
module sfgx_tex #(
  parameter int AW = 12
) (
  input  logic          clk,
  input  logic          wr_en,
  input  logic [AW-1:0] wr_addr,
  input  logic [23:0]   wr_data,
  input  logic [AW-1:0] rd_addr,
  output logic [23:0]   rd_data
);
  logic [23:0] mem [0:(1 << AW) - 1];
  always_ff @(posedge clk) begin
    if (wr_en) mem[wr_addr] <= wr_data;
    rd_data <= mem[rd_addr];
  end
`ifndef SYNTHESIS
  initial for (int i = 0; i < (1 << AW); i++) mem[i] = 24'h0;
`endif
endmodule
