// =============================================================================
// SFGX - sequential unsigned restoring divider
// sfgx_divu.sv
//
// quo = floor(num / den), rem = num mod den.  One quotient bit per clock;
// result valid when `done` pulses (and held until the next start).
// den must be non-zero (callers guarantee it; den==0 yields quo = all ones).
// Latency: NW + 1 cycles after `start`.
// =============================================================================
module sfgx_divu #(
  parameter int NW = 72,
  parameter int DW = 40
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          start,
  input  logic [NW-1:0] num,
  input  logic [DW-1:0] den,
  output logic          busy,
  output logic          done,
  output logic [NW-1:0] quo,
  output logic [DW-1:0] rem
);
  logic [NW-1:0]           nsh;
  logic [DW-1:0]           dreg;
  logic [$clog2(NW+1)-1:0] cnt;
  logic [DW:0]             t;
  logic [DW-1:0]           t_sub;

  assign t     = {rem, nsh[NW-1]};
  // t >= dreg whenever t_sub is used, so the DW low bits of the difference are exact
  assign t_sub = t[DW-1:0] - dreg;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= 1'b0;
      done <= 1'b0;
      nsh  <= '0;
      dreg <= '0;
      cnt  <= '0;
      quo  <= '0;
      rem  <= '0;
    end else begin
      done <= 1'b0;
      if (start && !busy) begin
        busy <= 1'b1;
        nsh  <= num;
        dreg <= den;
        quo  <= '0;
        rem  <= '0;
        cnt  <= NW[$clog2(NW+1)-1:0];
      end else if (busy) begin
        if (t >= {1'b0, dreg}) begin
          rem <= t_sub;
          quo <= {quo[NW-2:0], 1'b1};
        end else begin
          rem <= t[DW-1:0];
          quo <= {quo[NW-2:0], 1'b0};
        end
        nsh <= nsh << 1;
        cnt <= cnt - 1'b1;
        if (cnt == 1) begin
          busy <= 1'b0;
          done <= 1'b1;
        end
      end
    end
  end
endmodule
