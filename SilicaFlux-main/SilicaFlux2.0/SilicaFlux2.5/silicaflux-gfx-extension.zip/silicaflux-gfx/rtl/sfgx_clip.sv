// =============================================================================
// SFGX - homogeneous clipper + viewport transform + fan triangulation
// sfgx_clip.sv
//
// Input : one triangle in clip space (3 x CV).
// Output: 0..7 screen-space triangles (3 x SV each) on a valid/ready handshake.
//
// Clipping is Sutherland-Hodgman in homogeneous clip space against the six
// planes of the view volume, in the fixed order
//     0: w+x>=0   1: w-x>=0   2: w+y>=0   3: w-y>=0   4: w+z>=0   5: w-z>=0
// A vertex is INSIDE a plane when its distance d >= 0.  Plane distances are
// exact 34-bit signed values (no overflow possible for int32 inputs).
// For an edge P->Q (P = previous vertex, Q = current vertex, cyclic):
//     in,in          : emit Q
//     in,out         : emit I   only if dP > 0           (dP == 0 => I == P)
//     out,in         : emit I   only if dQ > 0, then emit Q
//     out,out        : nothing
// I = P + (Q-P)*t with t = floor(|dP| * 2^32 / |dP - dQ|)  (Q0.32), applied to
// x y z w (Q16.16), r g b (Q8.8) and u v (Q16.16) alike:
//     attr_I = attr_P + (((attr_Q - attr_P) * t + 2^31) >>> 32)
// so colour is interpolated perspective-correctly across clipped edges.
//
// A pass producing zero vertices rejects the primitive at once.  After the six
// planes: fewer than 3 vertices, or any w <= 0  => rejected.  (A 2-vertex
// polygon can arise when an edge lies exactly in a plane; it is processed like
// any other and may regrow to 3 collinear vertices - identical to the model.)
// Surviving vertices get the viewport transform (unsigned arithmetic after
// clamping, so results can never leave the framebuffer rectangle):
//     X = round( clamp(x+w, 0, 2w) * (FB_W*128)    / w )   1/256 px, origin left
//     Y = round( clamp(w-y, 0, 2w) * (FB_H*128)    / w )   1/256 px, origin TOP
//     Z = round( clamp(z+w, 0, 2w) * (65535*128)   / w )   Q16.8, 0 = near
// With tex_en the perspective-correct texture attributes are produced as well:
//     q = sat39( round(2^40 / w) )              1/w  in Q8.24 (40-bit signed, never negative)
//     s = sat40( (u*q + 2^15) >>> 16 )          u/w  (u in Q16.16, 24 fractional bits)
//     t = sat40( (v*q + 2^15) >>> 16 )          v/w
// (without tex_en s = t = q = 0).
// round() = round-half-up of the exact quotient.
// The polygon is emitted as the fan (V0, Vk, Vk+1), k = 1 .. n-2.
// =============================================================================
module sfgx_clip
  import sfgx_pkg::*;
#(
  parameter int FB_W = 160,
  parameter int FB_H = 120
) (
  input  logic                 clk,
  input  logic                 rst_n,

  input  logic                 start,
  input  logic                 tex_en,
  input  logic [3*CVW-1:0]     prim,

  output logic                 busy,
  output logic                 done,         // pulse
  output logic                 ev_reject,    // with done: polygon discarded
  output logic                 ev_clipped,   // with done: >=1 intersection vertex created (and not rejected)

  output logic                 tri_valid,
  input  logic                 tri_ready,
  output logic [3*SVW-1:0]     tri_data      // {V2, V1, V0}
);

  // ---------------------------------------------------------------------------
  // storage
  // ---------------------------------------------------------------------------
  logic [CVW-1:0] bufa [0:8];
  logic [CVW-1:0] bufb [0:8];
  logic [SVW-1:0] svb  [0:8];
  logic           cur;                    // buffer being read (0: bufa, 1: bufb)
  logic [3:0]     n, on, ei, ci, vi, ek;
  logic [2:0]     pl;
  logic [2:0]     vk;                     // viewport step: 0 X, 1 Y, 2 Z, 3 Q
  logic           had_isect;
  logic           pend_q;                 // after pushing I, push Q as well
  logic [CVW-1:0] p_r, q_r, push_v;
  logic [3:0]     ik;
  logic [31:0]    t_r;
  logic signed [39:0] qv;                 // 1/w of the vertex being converted

  // ---------------------------------------------------------------------------
  // divider (shared by the intersection parameter and the viewport divides)
  // ---------------------------------------------------------------------------
  logic        div_start, div_busy, div_done;
  logic [65:0] div_num, div_quo;
  logic [34:0] div_den, div_rem;
  sfgx_divu #(.NW(66), .DW(35)) u_div (
    .clk(clk), .rst_n(rst_n), .start(div_start), .num(div_num), .den(div_den),
    .busy(div_busy), .done(div_done), .quo(div_quo), .rem(div_rem)
  );
  logic unused_div_busy;
  assign unused_div_busy = div_busy;

  // ---------------------------------------------------------------------------
  // combinational helpers
  // ---------------------------------------------------------------------------
  function automatic logic signed [33:0] pdist(input logic [CVW-1:0] v, input logic [2:0] p);
    logic signed [33:0] x, y, z, w;
    x = 34'($signed(v[CV_X +: 32]));
    y = 34'($signed(v[CV_Y +: 32]));
    z = 34'($signed(v[CV_Z +: 32]));
    w = 34'($signed(v[CV_W +: 32]));
    case (p)
      3'd0:    pdist = w + x;
      3'd1:    pdist = w - x;
      3'd2:    pdist = w + y;
      3'd3:    pdist = w - y;
      3'd4:    pdist = w + z;
      default: pdist = w - z;
    endcase
  endfunction

  function automatic logic signed [33:0] attr(input logic [CVW-1:0] v, input logic [3:0] k);
    case (k)
      4'd0:    attr = 34'($signed(v[CV_X +: 32]));
      4'd1:    attr = 34'($signed(v[CV_Y +: 32]));
      4'd2:    attr = 34'($signed(v[CV_Z +: 32]));
      4'd3:    attr = 34'($signed(v[CV_W +: 32]));
      4'd4:    attr = {18'b0, v[CV_R +: 16]};
      4'd5:    attr = {18'b0, v[CV_G +: 16]};
      4'd6:    attr = {18'b0, v[CV_B +: 16]};
      4'd7:    attr = 34'($signed(v[CV_U +: 32]));
      default: attr = 34'($signed(v[CV_V +: 32]));
    endcase
  endfunction

  // current edge P->Q read from the active polygon buffer
  logic [3:0]      pidx;
  logic [CVW-1:0]  rd_p, rd_q;
  assign pidx = (ei == 4'd0) ? (n - 4'd1) : (ei - 4'd1);
  always_comb begin
    rd_p = cur ? bufb[pidx] : bufa[pidx];
    rd_q = cur ? bufb[ei]   : bufa[ei];
  end

  logic signed [33:0] dP, dQ;
  logic               pin, qin, dP_pos, dQ_pos;
  assign dP     = pdist(p_r, pl);
  assign dQ     = pdist(q_r, pl);
  assign pin    = ~dP[33];
  assign qin    = ~dQ[33];
  assign dP_pos = pin && (dP != 34'sd0);
  assign dQ_pos = qin && (dQ != 34'sd0);

  // |dP| and |dP - dQ| (the two have opposite signs whenever a division is started)
  logic signed [34:0] ds;
  logic        [32:0] absdP;
  logic        [33:0] absds;
  assign ds    = 35'(dP) - 35'(dQ);
  assign absdP = dP[33] ? 33'(-dP) : 33'(dP);
  assign absds = ds[34] ? 34'(-ds) : 34'(ds);

  // intersection attribute ik:  P + (((Q-P)*t + 2^31) >>> 32)
  logic signed [33:0] pa, qa, dif;
  logic signed [67:0] prod_i, res_i;
  always_comb begin
    pa     = attr(p_r, ik);
    qa     = attr(q_r, ik);
    dif    = qa - pa;
    prod_i = 68'(dif) * 68'($signed({36'b0, t_r}));
    res_i  = 68'(pa) + ((prod_i + 68'sh0_0000_0000_8000_0000) >>> 32);
  end

  // w <= 0 check operand
  logic [CVW-1:0] chk_v;
  assign chk_v = cur ? bufb[ci] : bufa[ci];

  // viewport divide operands for vertex vi, coordinate vk
  logic [CVW-1:0]     vp_v;
  logic signed [33:0] vx, vy, vz, vw, a_sel;
  logic        [32:0] two_w, nn;
  logic        [22:0] scale;
  logic        [55:0] vp_num;
  assign vp_v  = cur ? bufb[vi] : bufa[vi];
  assign vx    = 34'($signed(vp_v[CV_X +: 32]));
  assign vy    = 34'($signed(vp_v[CV_Y +: 32]));
  assign vz    = 34'($signed(vp_v[CV_Z +: 32]));
  assign vw    = 34'($signed(vp_v[CV_W +: 32]));
  assign two_w = {vw[31:0], 1'b0};           // w > 0 here, so 2w < 2^32
  always_comb begin
    case (vk)
      3'd0:    a_sel = vw + vx;
      3'd1:    a_sel = vw - vy;
      default: a_sel = vw + vz;
    endcase
    if (a_sel[33])                nn = '0;
    else if (a_sel[32:0] > two_w) nn = two_w;
    else                          nn = a_sel[32:0];
    case (vk)
      3'd0:    scale = 23'(FB_W * 128);
      3'd1:    scale = 23'(FB_H * 128);
      default: scale = 23'(65535 * 128);
    endcase
  end
  assign vp_num = nn * scale;

  logic [23:0] vp_res;                       // valid when div_done
  logic        vp_round;
  assign vp_round = ({div_rem, 1'b0} >= {1'b0, div_den});
  assign vp_res   = div_quo[23:0] + {23'b0, vp_round};

  // q = 1/w (Q8.24) saturated to 2^39-1, and s,t = u/w, v/w
  localparam logic [41:0] QMAX = 42'h7F_FFFF_FFFF;                 // 2^39 - 1
  logic [41:0] q_full;
  logic signed [39:0] q_sat;
  assign q_full = div_quo[41:0] + {41'b0, vp_round};
  assign q_sat  = (q_full > QMAX) ? 40'sh7F_FFFF_FFFF : q_full[39:0];
  logic signed [71:0] st_prod_s, st_prod_t, st_sh_s, st_sh_t;
  logic signed [39:0] s_sat, t_sat;
  always_comb begin
    st_prod_s = 72'($signed(vp_v[CV_U +: 32])) * 72'(qv);
    st_prod_t = 72'($signed(vp_v[CV_V +: 32])) * 72'(qv);
    st_sh_s   = (st_prod_s + 72'sd32768) >>> 16;
    st_sh_t   = (st_prod_t + 72'sd32768) >>> 16;
    s_sat = (st_sh_s >  72'sh7F_FFFF_FFFF) ? 40'sh7F_FFFF_FFFF : (st_sh_s < -72'sh80_0000_0000) ? 40'sh80_0000_0000 : st_sh_s[39:0];
    t_sat = (st_sh_t >  72'sh7F_FFFF_FFFF) ? 40'sh7F_FFFF_FFFF : (st_sh_t < -72'sh80_0000_0000) ? 40'sh80_0000_0000 : st_sh_t[39:0];
  end

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [4:0] {
    C_IDLE, C_PLANE, C_EDGE_RD, C_EDGE_EVAL, C_DIV_START, C_DIV_WAIT, C_ISECT,
    C_PUSH, C_NEXT_EDGE, C_PLANE_END, C_CHECK, C_VP_START, C_VP_WAIT, C_VP_ST, C_VP_FIN, C_EMIT,
    C_DONE, C_REJECT
  } cstate_t;
  cstate_t st;

  assign busy      = (st != C_IDLE);
  assign tri_valid = (st == C_EMIT);
  assign tri_data  = {svb[ek + 4'd1], svb[ek], svb[0]};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= C_IDLE; cur <= 1'b0; n <= '0; on <= '0; ei <= '0; ci <= '0; vi <= '0; ek <= '0;
      pl <= '0; vk <= '0; had_isect <= 1'b0; pend_q <= 1'b0;
      p_r <= '0; q_r <= '0; push_v <= '0; ik <= '0; t_r <= '0; qv <= '0;
      div_start <= 1'b0; div_num <= '0; div_den <= '0;
      done <= 1'b0; ev_reject <= 1'b0; ev_clipped <= 1'b0;
      for (int i = 0; i < 9; i++) begin bufa[i] <= '0; bufb[i] <= '0; svb[i] <= '0; end
    end else begin
      div_start  <= 1'b0;
      done       <= 1'b0;
      ev_reject  <= 1'b0;
      ev_clipped <= 1'b0;

      case (st)
        C_IDLE: if (start) begin
          bufa[0] <= prim[0*CVW +: CVW];
          bufa[1] <= prim[1*CVW +: CVW];
          bufa[2] <= prim[2*CVW +: CVW];
          cur <= 1'b0; n <= 4'd3; pl <= '0; ci <= '0; had_isect <= 1'b0;
          st  <= C_PLANE;
        end

        // ---- one plane pass ------------------------------------------------
        C_PLANE: begin
          on <= '0; ei <= '0;
          st <= (pl == 3'd6) ? C_CHECK : C_EDGE_RD;
        end
        C_EDGE_RD: begin
          p_r <= rd_p; q_r <= rd_q;
          st  <= C_EDGE_EVAL;
        end
        C_EDGE_EVAL: begin
          if (pin && qin) begin                                  // in,in
            push_v <= q_r; pend_q <= 1'b0; st <= C_PUSH;
          end else if (pin && !qin) begin                        // in,out
            if (dP_pos) begin pend_q <= 1'b0; st <= C_DIV_START; end
            else        st <= C_NEXT_EDGE;
          end else if (!pin && qin) begin                        // out,in
            if (dQ_pos) begin pend_q <= 1'b1; st <= C_DIV_START; end
            else begin push_v <= q_r; pend_q <= 1'b0; st <= C_PUSH; end
          end else begin                                         // out,out
            st <= C_NEXT_EDGE;
          end
        end

        // ---- intersection ----------------------------------------------------
        C_DIV_START: begin
          div_num   <= {1'b0, absdP, 32'b0};
          div_den   <= {1'b0, absds};
          div_start <= 1'b1;
          st        <= C_DIV_WAIT;
        end
        C_DIV_WAIT: if (div_done) begin
          t_r <= div_quo[31:0];
          ik  <= '0;
          st  <= C_ISECT;
        end
        C_ISECT: begin                           // one attribute per cycle, result built in push_v
          case (ik)
            4'd0: push_v[CV_X +: 32] <= res_i[31:0];
            4'd1: push_v[CV_Y +: 32] <= res_i[31:0];
            4'd2: push_v[CV_Z +: 32] <= res_i[31:0];
            4'd3: push_v[CV_W +: 32] <= res_i[31:0];
            4'd4: push_v[CV_R +: 16] <= res_i[15:0];
            4'd5: push_v[CV_G +: 16] <= res_i[15:0];
            4'd6: push_v[CV_B +: 16] <= res_i[15:0];
            4'd7: push_v[CV_U +: 32] <= res_i[31:0];
            default: push_v[CV_V +: 32] <= res_i[31:0];
          endcase
          if (ik == 4'd8) begin had_isect <= 1'b1; st <= C_PUSH; end
          else ik <= ik + 4'd1;
        end

        // ---- append to the output polygon ----------------------------------
        C_PUSH: begin
`ifndef SYNTHESIS
          // a convex polygon gains at most one vertex per plane: 3 + 6 = 9 entries suffice
          if (on > 4'd8) begin $display("SFGX ASSERT: clip polygon buffer overflow"); $fatal(1); end
`endif
          if (cur) bufa[on] <= push_v; else bufb[on] <= push_v;
          on <= on + 4'd1;
          if (pend_q) begin push_v <= q_r; pend_q <= 1'b0; end   // push Q on the next cycle
          else st <= C_NEXT_EDGE;
        end
        C_NEXT_EDGE: begin
          if (ei == n - 4'd1) st <= C_PLANE_END;
          else begin ei <= ei + 4'd1; st <= C_EDGE_RD; end
        end
        C_PLANE_END: begin
          cur <= ~cur; n <= on; pl <= pl + 3'd1;
          st  <= (on == 4'd0) ? C_REJECT : C_PLANE;
        end

        // ---- accept / reject ---------------------------------------------------
        C_CHECK: begin
          if (n < 4'd3) st <= C_REJECT;
          else if ($signed(chk_v[CV_W +: 32]) <= 32'sd0) st <= C_REJECT;
          else if (ci == n - 4'd1) begin vi <= '0; vk <= '0; st <= C_VP_START; end
          else ci <= ci + 4'd1;
        end

        // ---- viewport transform ----------------------------------------------------------------
        C_VP_START: begin
          div_num   <= (vk == 3'd3) ? (66'd1 << 40) : {10'b0, vp_num};
          div_den   <= {4'b0, vw[30:0]};
          div_start <= 1'b1;
          st        <= C_VP_WAIT;
        end
        C_VP_WAIT: if (div_done) begin
          case (vk)
            3'd0:    svb[vi][SV_X +: 24] <= vp_res;
            3'd1:    svb[vi][SV_Y +: 24] <= vp_res;
            3'd2:    svb[vi][SV_Z +: 24] <= vp_res;
            default: qv <= q_sat;
          endcase
          if (vk == 3'd2) begin
            if (tex_en) begin vk <= 3'd3; st <= C_VP_START; end
            else st <= C_VP_FIN;
          end else if (vk == 3'd3) begin
            st <= C_VP_ST;
          end else begin
            vk <= vk + 3'd1; st <= C_VP_START;
          end
        end
        C_VP_ST: begin                             // s = u/w, t = v/w, q = 1/w
          svb[vi][SV_S +: 40] <= s_sat;
          svb[vi][SV_T +: 40] <= t_sat;
          svb[vi][SV_Q +: 40] <= qv;
          st <= C_VP_FIN;
        end
        C_VP_FIN: begin                            // colour passthrough; next vertex or fan emission
          svb[vi][SV_R +: 16] <= vp_v[CV_R +: 16];
          svb[vi][SV_G +: 16] <= vp_v[CV_G +: 16];
          svb[vi][SV_B +: 16] <= vp_v[CV_B +: 16];
          if (!tex_en) svb[vi][SV_S +: 120] <= '0;
          if (vi == n - 4'd1) begin ek <= 4'd1; st <= C_EMIT; end
          else begin vi <= vi + 4'd1; vk <= '0; st <= C_VP_START; end
        end

        // ---- fan emission ------------------------------------------------------------
        C_EMIT: if (tri_ready) begin
          if (ek == n - 4'd2) st <= C_DONE;
          else ek <= ek + 4'd1;
        end

        C_DONE:   begin done <= 1'b1; ev_clipped <= had_isect; st <= C_IDLE; end
        C_REJECT: begin done <= 1'b1; ev_reject  <= 1'b1;      st <= C_IDLE; end
        default:  st <= C_IDLE;
      endcase
    end
  end
endmodule
