// =============================================================================
// SFGX - vertex input + restricted vertex transformation stage
// sfgx_vertex.sv
//
// For one triangle:
//   1. reads the packed triangle word  {2'b0, i2[9:0], i1[9:0], i0[9:0]}
//      at scratchpad word address `tri_addr`;
//   2. for each index reads the 4-word vertex record at vtx_base + 4*idx
//         word0 = x (Q16.16)  word1 = y  word2 = z  word3 = 0x00RRGGBB
//         word4 = u  word5 = v (Q16.16)   -- fetched only when tex_en and vtx_stride >= 6, else 0
//      (the record length is the register `vtx_stride`, default 4 words)
//   3. transforms (x,y,z,1) by the 4x4 MVP matrix (Q16.16, row-major):
//         clip_r = sat32( round16( sum_c M[r][c]*v[c] ) ),   v[3] = 1.0
//      round16(a) = (a + 2^15) >>> 16.  Saturation sets `xform_ovf`.
//
// "Restricted": positions only, one matrix per draw, colour passthrough (Q8.8),
// no normals / lighting / programmable shading.  A single 32x32 multiplier is
// time-shared (2 cycles per product, 32 cycles per vertex).
//
// Scratchpad access uses ONLY the documented memory_controller scalar-LOAD
// handshake: pulse req_valid when req_ready, hold req_addr until resp_valid.
// Any address that would not fit the 256-word scratchpad is rejected (the base
// controller would silently alias it) and reported through `err`.
// =============================================================================
module sfgx_vertex
  import silicaflux_pkg::*;
  import sfgx_pkg::*;
(
  input  logic                 clk,
  input  logic                 rst_n,

  input  logic                 start,
  input  logic [15:0]          tri_addr,
  input  logic [15:0]          vtx_base,
  input  logic [7:0]           vtx_stride,     // words per vertex record, 4..64
  input  logic                 tex_en,         // fetch u,v (words 4,5) as well
  input  logic [16*32-1:0]     mat_flat,       // M[r][c] at [(4r+c)*32 +: 32]

  // memory_controller scalar LOAD port
  output logic                 mem_req_valid,
  input  logic                 mem_req_ready,
  output logic [XLEN-1:0]      mem_req_addr,   // byte address
  input  logic                 mem_resp_valid,
  input  logic [XLEN-1:0]      mem_resp_rdata,

  output logic                 busy,
  output logic                 done,           // pulse (also on error)
  output logic                 err,            // with done: scratchpad address rejected
  output logic                 xform_ovf,      // pulse per saturated coordinate
  output logic [3*CVW-1:0]     prim            // 3 clip-space vertices, valid with done && !err
);

  typedef enum logic [4:0] {
    V_IDLE, V_TRI_REQ, V_TRI_WAIT, V_VCHK, V_VREQ, V_VWAIT,
    V_XF_INIT, V_XF_MUL, V_XF_ACC, V_XF_ROW, V_XF_STORE, V_DONE, V_ERR
  } vstate_t;

  vstate_t               st;
  logic [15:0]           tri_addr_r;
  logic [29:0]           tword;         // 3 x 10-bit indices
  logic [1:0]            vk;            // vertex 0..2
  logic [2:0]            wcnt;          // word 0..5 within vertex
  logic [17:0]           vaddr;         // word address of current vertex
  logic [XLEN-1:0]       vw [0:5];
  logic [2:0]            nlast;          // index of the last word to fetch (3 or 5)
  logic [1:0]            row, col;
  logic signed [67:0]    acc;
  logic signed [63:0]    prod;
  logic signed [31:0]    cv [0:3];

  // ---- combinational helpers ----------------------------------------------
  logic [9:0]  cur_idx;
  assign nlast = (tex_en && (vtx_stride >= 8'd6)) ? 3'd5 : 3'd3;
  assign cur_idx = (vk == 2'd0) ? tword[9:0] : (vk == 2'd1) ? tword[19:10] : tword[29:20];

  logic [17:0] vaddr_c;                 // vtx_base + idx*stride  (10-bit * 8-bit = 18 bit)
  assign vaddr_c = {2'b00, vtx_base} + 18'(cur_idx) * 18'(vtx_stride);

  logic signed [31:0] m_sel;
  logic signed [31:0] v_sel;
  always_comb begin
    m_sel = $signed(mat_flat[({row, col}) * 32 +: 32]);
    case (col)
      2'd0:    v_sel = $signed(vw[0]);
      2'd1:    v_sel = $signed(vw[1]);
      2'd2:    v_sel = $signed(vw[2]);
      default: v_sel = 32'sd65536;      // w = 1.0
    endcase
  end

  logic signed [67:0] sh;               // (acc + 2^15) >>> 16
  logic               sh_ovf;
  logic signed [31:0] sh_sat;
  always_comb begin
    sh     = (acc + 68'sd32768) >>> 16;
    sh_ovf = (sh > 68'sd2147483647) || (sh < -68'sd2147483648);
    if (sh_ovf) sh_sat = sh[67] ? 32'sh80000000 : 32'sh7FFFFFFF;
    else        sh_sat = sh[31:0];
  end

  assign busy = (st != V_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st            <= V_IDLE;
      tri_addr_r    <= '0;
      tword         <= '0;
      vk            <= '0;
      wcnt          <= '0;
      vaddr         <= '0;
      row           <= '0;
      col           <= '0;
      acc           <= '0;
      prod          <= '0;
      mem_req_valid <= 1'b0;
      mem_req_addr  <= '0;
      done          <= 1'b0;
      err           <= 1'b0;
      xform_ovf     <= 1'b0;
      prim          <= '0;
      for (int i = 0; i < 6; i++) vw[i] <= '0;
      for (int i = 0; i < 4; i++) cv[i] <= '0;
    end else begin
      mem_req_valid <= 1'b0;
      done          <= 1'b0;
      err           <= 1'b0;
      xform_ovf     <= 1'b0;

      case (st)
        V_IDLE: begin
          if (start) begin
            tri_addr_r <= tri_addr;
            vk         <= '0;
            st         <= (tri_addr >= SRAM_DEPTH[15:0]) ? V_ERR : V_TRI_REQ;
          end
        end

        // ---- triangle word -------------------------------------------------
        V_TRI_REQ: if (mem_req_ready) begin
          mem_req_valid <= 1'b1;
          mem_req_addr  <= {14'b0, tri_addr_r, 2'b00};
          st            <= V_TRI_WAIT;
        end
        V_TRI_WAIT: if (mem_resp_valid) begin
          tword <= mem_resp_rdata[29:0];
          st    <= V_VCHK;
        end

        // ---- vertex fetch ----------------------------------------------------
        V_VCHK: begin
          vaddr <= vaddr_c;
          wcnt  <= '0;
          vw[4] <= '0;                         // u,v read as 0 unless fetched
          vw[5] <= '0;
          st    <= ((vaddr_c + {10'b0, vtx_stride}) > 18'(SRAM_DEPTH)) ? V_ERR : V_VREQ;
        end
        V_VREQ: if (mem_req_ready) begin
          mem_req_valid <= 1'b1;
          mem_req_addr  <= {12'b0, vaddr + {15'b0, wcnt}, 2'b00};
          st            <= V_VWAIT;
        end
        V_VWAIT: if (mem_resp_valid) begin
          vw[wcnt] <= mem_resp_rdata;
          if (wcnt == nlast) st <= V_XF_INIT;
          else begin wcnt <= wcnt + 3'd1; st <= V_VREQ; end
        end

        // ---- MVP transform ---------------------------------------------------
        V_XF_INIT: begin row <= '0; col <= '0; acc <= '0; st <= V_XF_MUL; end
        V_XF_MUL:  begin prod <= m_sel * v_sel; st <= V_XF_ACC; end
        V_XF_ACC: begin
          acc <= acc + 68'(prod);
          if (col == 2'd3) st <= V_XF_ROW;
          else begin col <= col + 2'd1; st <= V_XF_MUL; end
        end
        V_XF_ROW: begin
          cv[row]   <= sh_sat;
          xform_ovf <= sh_ovf;
          acc       <= '0;
          col       <= '0;
          if (row == 2'd3) st <= V_XF_STORE;
          else begin row <= row + 2'd1; st <= V_XF_MUL; end
        end
        V_XF_STORE: begin
          prim[vk*CVW + CV_X +: 32] <= cv[0];
          prim[vk*CVW + CV_Y +: 32] <= cv[1];
          prim[vk*CVW + CV_Z +: 32] <= cv[2];
          prim[vk*CVW + CV_W +: 32] <= cv[3];
          prim[vk*CVW + CV_R +: 16] <= {vw[3][23:16], 8'h00};
          prim[vk*CVW + CV_G +: 16] <= {vw[3][15:8],  8'h00};
          prim[vk*CVW + CV_B +: 16] <= {vw[3][7:0],   8'h00};
          prim[vk*CVW + CV_U +: 32] <= vw[4];
          prim[vk*CVW + CV_V +: 32] <= vw[5];
          if (vk == 2'd2) st <= V_DONE;
          else begin vk <= vk + 2'd1; st <= V_VCHK; end
        end

        V_DONE: begin done <= 1'b1; st <= V_IDLE; end
        V_ERR:  begin done <= 1'b1; err <= 1'b1; st <= V_IDLE; end
        default: st <= V_IDLE;
      endcase
    end
  end
endmodule
