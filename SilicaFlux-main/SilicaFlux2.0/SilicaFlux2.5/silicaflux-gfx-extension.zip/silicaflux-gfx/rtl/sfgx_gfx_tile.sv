// =============================================================================
// SilicaFlux Graphics Tile  (SFGX)
// sfgx_gfx_tile.sv
//
// Drop-in alternative to `compute_tile`: the FIRST 25 PORTS (clk .. NoC) ARE
// IDENTICAL IN NAME, WIDTH AND DIRECTION to compute_tile.sv v1.0, so the
// unmodified dataflow scheduler drives it exactly like any other tile:
//
//    scheduler --(tok_*, token_valid/ready, scalar_data_in, vector_data_in)--> tile
//    tile      --(tile_done, tile_error, tile_result_scalar/vector)---------> scheduler
//
// Token set handled (everything else completes with tile_error):
//   inherited, on the tile-local 256-word scratchpad (the unmodified
//   memory_controller):   OP_LOAD OP_STORE OP_VLOAD OP_VSTORE OP_DFLOAD
//                         OP_DFSTORE  (+ OP_DFSYNC: completes immediately)
//   graphics extension, opcodes 0x18..0x1E = the whole 0x18-0x1E range the README
//   reserves for application-specific kernels (all D-format):
//                         OP_GFXREG OP_GFXDRAW OP_GFXCLEAR OP_GFXRD OP_GFXSTAT OP_GFXMEM OP_GFXTEX
//   Vector/tensor kernels (VADD, DOT, MATMUL, ...) are NOT implemented by this
//   tile; they complete with tile_error.  NoC input is accepted and dropped,
//   NoC output is never driven (documented limitation of this milestone).
//
// Extension ports (after the compute_tile-compatible block):
//   fb_scan_addr / fb_scan_data : colour read port for a display controller
//   gfx_busy                    : a draw/clear is running
//   dbg_*                       : simulation/verification taps (optional)
// =============================================================================
module sfgx_gfx_tile
  import silicaflux_pkg::*;
  import sfgx_pkg::*;
#(
  parameter int TILE_ID = 0,
  parameter int FB_W    = 160,
  parameter int FB_H    = 120,
  parameter int AW      = $clog2(FB_W * FB_H)
)
(
  // ===== compute_tile-compatible interface (names/widths/directions as v1.0) =====
  input  logic          clk,
  input  logic          rst_n,

  input  logic [4:0]    tok_opcode,
  input  logic [2:0]    tok_tile_id,
  input  logic [4:0]    tok_src_reg,
  input  logic [4:0]    tok_dst_reg,
  input  logic [3:0]    tok_vsrc_reg,
  input  logic [3:0]    tok_vdst_reg,
  input  logic [13:0]   tok_mem_addr,
  input  logic [4:0]    tok_length,
  input  logic [7:0]    tok_func,
  input  logic          token_valid,
  output logic          token_ready,

  input  logic [XLEN-1:0]  scalar_data_in,
  input  logic [VLEN-1:0]  vector_data_in,
  input  logic [VLEN-1:0]  vector_data_in_b,

  output logic            tile_done,
  output logic            tile_error,
  output logic [XLEN-1:0] tile_result_scalar,
  output logic [VLEN-1:0] tile_result_vector,

  output noc_flit_t     noc_flit_out,
  output logic          noc_flit_valid,
  input  logic          noc_flit_ready,

  input  noc_flit_t     noc_flit_in,
  input  logic          noc_flit_in_valid,
  output logic          noc_flit_in_ready,

  // ===== graphics extension ports =====
  input  logic [AW-1:0] fb_scan_addr,
  output logic [31:0]   fb_scan_data,      // registered: valid 1 clock after fb_scan_addr
  output logic          gfx_busy,

  output logic                dbg_tri_valid,   // a screen-space triangle enters setup
  output logic [3*SVW-1:0]    dbg_tri_data,
  output logic                dbg_cov_valid,   // a pixel centre was found covered
  output logic [11:0]         dbg_cov_x,
  output logic [11:0]         dbg_cov_y
);

  // ---------------------------------------------------------------------------
  // graphics register file
  // ---------------------------------------------------------------------------
  logic signed [31:0] mat [0:15];
  logic [CTRL_W-1:0]  ctrl;
  logic [7:0]         vtx_stride, tex_log2;
  logic [15:0]        vtx_base, tri_base, num_tri, clear_depth;
  logic [16*32-1:0]   mat_flat;
  always_comb for (int i = 0; i < 16; i++) mat_flat[i*32 +: 32] = mat[i];

  // latched token
  logic [4:0]       tk_op, tk_len;
  logic [13:0]      tk_addr;
  logic [XLEN-1:0]  scalar_r;
  logic [VLEN-1:0]  vec_r;
  logic             tk_err;
  logic             clip_fin;
  logic [31:0]      pix_at_start;

  // statistics
  logic [2:0]  flags;
  logic [31:0] c_tri_in, c_tri_addr_err, c_tri_clip_rej, c_tri_clipped, c_tri_setup, c_tri_degen,
               c_tri_cull, c_tri_raster, c_pix_cov, c_pix_written, c_pix_zfail, c_pix_tex;

  // ---------------------------------------------------------------------------
  // scratchpad (UNMODIFIED SilicaFlux memory_controller)
  // ---------------------------------------------------------------------------
  logic            mem_req_valid, mem_req_ready, mem_resp_valid;
  logic [4:0]      mem_req_opcode, mem_req_length;
  logic [XLEN-1:0] mem_req_addr, mem_req_wdata, mem_resp_rdata;
  logic [VLEN-1:0] mem_req_vwdata, mem_resp_vrdata;
  logic            mem_align_err;

  memory_controller u_mem (
    .clk           (clk),
    .rst_n         (rst_n),
    .req_valid     (mem_req_valid),
    .req_ready     (mem_req_ready),
    .req_opcode    (mem_req_opcode),
    .req_addr      (mem_req_addr),
    .req_wdata     (mem_req_wdata),
    .req_vwdata    (mem_req_vwdata),
    .req_length    (mem_req_length),
    .resp_valid    (mem_resp_valid),
    .resp_rdata    (mem_resp_rdata),
    .resp_vrdata   (mem_resp_vrdata),
    .alignment_err (mem_align_err),
    .wb_valid      (1'b0),
    .wb_addr       ('0),
    .wb_data       ('0)
  );

  // ---------------------------------------------------------------------------
  // pipeline stages
  // ---------------------------------------------------------------------------
  // vertex input + transform
  logic                 vtx_start, vtx_busy, vtx_done, vtx_err, vtx_ovf, vtx_req_valid;
  logic [XLEN-1:0]      vtx_req_addr;
  logic [3*CVW-1:0]     vtx_prim;
  logic [15:0]          tri_idx;
  sfgx_vertex u_vtx (
    .clk(clk), .rst_n(rst_n),
    .start(vtx_start), .tri_addr(tri_base + tri_idx), .vtx_base(vtx_base), .vtx_stride(vtx_stride),
    .tex_en(ctrl[CTRL_TEX_EN]), .mat_flat(mat_flat),
    .mem_req_valid(vtx_req_valid), .mem_req_ready(mem_req_ready), .mem_req_addr(vtx_req_addr),
    .mem_resp_valid(mem_resp_valid), .mem_resp_rdata(mem_resp_rdata),
    .busy(vtx_busy), .done(vtx_done), .err(vtx_err), .xform_ovf(vtx_ovf), .prim(vtx_prim)
  );

  // clip + viewport
  logic                clip_start, clip_busy, clip_done, clip_rej, clip_clipped;
  logic                clip_tri_valid, rast_in_ready;
  logic [3*SVW-1:0]    clip_tri_data;
  sfgx_clip #(.FB_W(FB_W), .FB_H(FB_H)) u_clip (
    .clk(clk), .rst_n(rst_n), .start(clip_start), .tex_en(ctrl[CTRL_TEX_EN]), .prim(vtx_prim),
    .busy(clip_busy), .done(clip_done), .ev_reject(clip_rej), .ev_clipped(clip_clipped),
    .tri_valid(clip_tri_valid), .tri_ready(rast_in_ready), .tri_data(clip_tri_data)
  );

  // setup + raster
  logic [AW-1:0] r_fb_addr;
  logic          r_wr_c, r_wr_z, rast_busy;
  logic [23:0]   r_wdata_c;
  logic [15:0]   r_wdata_z, fb_zrdata;
  logic          ev_degen, ev_cull, ev_raster, ev_cov, ev_wr, ev_zfail, ev_tex;
  logic [TEX_AW-1:0] tex_raddr;
  logic [23:0]   tex_rdata;
  sfgx_raster #(.FB_W(FB_W), .FB_H(FB_H)) u_rast (
    .clk(clk), .rst_n(rst_n), .ctrl(ctrl), .tex_log2(tex_log2),
    .in_valid(clip_tri_valid), .in_ready(rast_in_ready), .in_data(clip_tri_data), .busy(rast_busy),
    .fb_addr(r_fb_addr), .fb_wr_c(r_wr_c), .fb_wr_z(r_wr_z), .fb_wdata_c(r_wdata_c),
    .fb_wdata_z(r_wdata_z), .fb_zrdata(fb_zrdata),
    .tex_addr(tex_raddr), .tex_rdata(tex_rdata),
    .ev_degen(ev_degen), .ev_cull(ev_cull), .ev_raster(ev_raster), .ev_cov(ev_cov),
    .ev_wr(ev_wr), .ev_zfail(ev_zfail), .ev_tex(ev_tex),
    .dbg_cov_valid(dbg_cov_valid), .dbg_cov_x(dbg_cov_x), .dbg_cov_y(dbg_cov_y)
  );
  // texture memory: written by OP_GFXTEX tokens, read by the sampler
  logic                tex_we;
  logic [TEX_AW-1:0]   tex_waddr;
  logic [23:0]         tex_wdata;
  sfgx_tex #(.AW(TEX_AW)) u_tex (
    .clk(clk), .wr_en(tex_we), .wr_addr(tex_waddr), .wr_data(tex_wdata), .rd_addr(tex_raddr), .rd_data(tex_rdata)
  );

  assign dbg_tri_valid = clip_tri_valid && rast_in_ready;
  assign dbg_tri_data  = clip_tri_data;

  // framebuffer
  logic          clr_start, clr_busy, clr_c_en, clr_z_en;
  logic [AW-1:0] fa_addr;
  logic [31:0]   fa_rdata_c;
  logic [15:0]   fa_rdata_z;
  logic [AW-1:0] rd_addr;
  logic          draw_active;
  assign fa_addr   = draw_active ? r_fb_addr : rd_addr;
  assign fb_zrdata = fa_rdata_z;
  sfgx_fb #(.FB_W(FB_W), .FB_H(FB_H)) u_fb (
    .clk(clk), .rst_n(rst_n),
    .clr_start(clr_start), .clr_color_en(clr_c_en), .clr_depth_en(clr_z_en),
    .clr_color(scalar_r[23:0]), .clr_depth(clear_depth), .clr_busy(clr_busy),
    .a_addr(fa_addr), .a_wr_c(r_wr_c), .a_wr_z(r_wr_z), .a_wdata_c(r_wdata_c), .a_wdata_z(r_wdata_z),
    .a_rdata_c(fa_rdata_c), .a_rdata_z(fa_rdata_z),
    .b_addr(fb_scan_addr), .b_rdata(fb_scan_data)
  );

  // ---------------------------------------------------------------------------
  // token FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [3:0] {
    T_IDLE, T_MEMWAIT, T_CLEAR, T_DRAW, T_RD0, T_RD1, T_FINISH
  } tstate_t;
  tstate_t tstate;

  typedef enum logic [2:0] { D_VSTART, D_VWAIT, D_CSTART, D_CWAIT, D_NEXT } dstate_t;
  dstate_t dstate;


  assign draw_active = (tstate == T_DRAW);
  assign gfx_busy    = (tstate != T_IDLE);

  // ---- memory-controller request mux: draw engine or token path ------------------
  logic            tk_req_valid;
  logic [XLEN-1:0] tk_req_addr;
  logic [4:0]      tk_req_opcode;
  always_comb begin
    mem_req_valid  = draw_active ? vtx_req_valid : tk_req_valid;
    mem_req_addr   = draw_active ? vtx_req_addr  : tk_req_addr;
    mem_req_opcode = draw_active ? OP_LOAD       : tk_req_opcode;
    mem_req_wdata  = scalar_r;
    mem_req_vwdata = vec_r;
    mem_req_length = tk_len;
  end

  // ---- statistics read-out ------------------------------------------------------------
  logic [31:0] stat_val;
  always_comb begin
    case (tk_addr)
      14'(ST_FLAGS):        stat_val = {29'b0, flags};
      14'(ST_TRI_IN):       stat_val = c_tri_in;
      14'(ST_TRI_ADDR_ERR): stat_val = c_tri_addr_err;
      14'(ST_TRI_CLIP_REJ): stat_val = c_tri_clip_rej;
      14'(ST_TRI_CLIPPED):  stat_val = c_tri_clipped;
      14'(ST_TRI_SETUP):    stat_val = c_tri_setup;
      14'(ST_TRI_DEGEN):    stat_val = c_tri_degen;
      14'(ST_TRI_CULL):     stat_val = c_tri_cull;
      14'(ST_TRI_RASTER):   stat_val = c_tri_raster;
      14'(ST_PIX_COV):      stat_val = c_pix_cov;
      14'(ST_PIX_WRITTEN):  stat_val = c_pix_written;
      14'(ST_PIX_ZFAIL):    stat_val = c_pix_zfail;
      14'(ST_FBSIZE):       stat_val = {16'(FB_H), 16'(FB_W)};
      14'(ST_ID):           stat_val = SFGX_ID;
      14'(ST_PIX_TEX):      stat_val = c_pix_tex;
      default:              stat_val = 32'h0;
    endcase
  end

  // ---- pixel read-back address ------------------------------------------------------------
  logic rd_ok;
  assign rd_ok   = (scalar_r[15:0] < 16'(FB_W)) && (scalar_r[31:16] < 16'(FB_H)) && (tk_addr[13:1] == 13'd0);
  assign rd_addr = AW'(scalar_r[31:16]) * AW'(FB_W) + AW'(scalar_r[15:0]);

  // ---- NoC: accepted and dropped / never driven ---------------------------------------------
  assign noc_flit_out      = '0;
  assign noc_flit_valid    = 1'b0;
  assign noc_flit_in_ready = 1'b1;

  // ---------------------------------------------------------------------------
  // sequential logic
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tstate <= T_IDLE; dstate <= D_VSTART;
      token_ready <= 1'b1; tile_done <= 1'b0; tile_error <= 1'b0;
      tile_result_scalar <= '0; tile_result_vector <= '0;
      tk_op <= '0; tk_len <= '0; tk_addr <= '0; scalar_r <= '0; vec_r <= '0; tk_err <= 1'b0;
      tk_req_valid <= 1'b0; tk_req_addr <= '0; tk_req_opcode <= '0;
      clr_start <= 1'b0; clr_c_en <= 1'b0; clr_z_en <= 1'b0;
      vtx_start <= 1'b0; clip_start <= 1'b0; clip_fin <= 1'b0; tri_idx <= '0; pix_at_start <= '0;
      for (int i = 0; i < 16; i++) mat[i] <= (i % 5 == 0) ? 32'sd65536 : 32'sd0;
      ctrl <= CTRL_W'(7);                  // ZTEST | ZWRITE | ZFUNC=LESS(1) at [4:2] -> 0b111
      vtx_stride <= 8'd4; tex_log2 <= 8'h55;
      tex_we <= 1'b0; tex_waddr <= '0; tex_wdata <= '0;
      vtx_base <= '0; tri_base <= '0; num_tri <= '0; clear_depth <= DEPTH_MAX;
      flags <= '0;
      c_tri_in <= '0; c_tri_addr_err <= '0; c_tri_clip_rej <= '0; c_tri_clipped <= '0; c_tri_setup <= '0;
      c_tri_degen <= '0; c_tri_cull <= '0; c_tri_raster <= '0; c_pix_cov <= '0; c_pix_written <= '0;
      c_pix_zfail <= '0; c_pix_tex <= '0;
    end else begin
      tk_req_valid <= 1'b0;
      clr_start    <= 1'b0;
      vtx_start    <= 1'b0;
      clip_start   <= 1'b0;
      tile_done    <= 1'b0;
      tile_error   <= 1'b0;
      tex_we       <= 1'b0;

      // ---- always-on statistics -------------------------------------------------------
      if (vtx_ovf)        flags[FLAG_XFORM_OVF] <= 1'b1;
      if (dbg_tri_valid)  c_tri_setup  <= c_tri_setup + 32'd1;
      if (ev_degen)       c_tri_degen  <= c_tri_degen + 32'd1;
      if (ev_cull)        c_tri_cull   <= c_tri_cull + 32'd1;
      if (ev_raster)      c_tri_raster <= c_tri_raster + 32'd1;
      if (ev_cov)         c_pix_cov    <= c_pix_cov + 32'd1;
      if (ev_wr)          c_pix_written <= c_pix_written + 32'd1;
      if (ev_zfail)       c_pix_zfail  <= c_pix_zfail + 32'd1;
      if (ev_tex)         c_pix_tex    <= c_pix_tex + 32'd1;
      if (clip_done && clip_rej)     c_tri_clip_rej <= c_tri_clip_rej + 32'd1;
      if (clip_done && clip_clipped) c_tri_clipped  <= c_tri_clipped + 32'd1;

      case (tstate)
        // ==================================================================
        T_IDLE: begin
          token_ready <= 1'b1;
          if (token_valid) begin
            token_ready <= 1'b0;
            tk_op    <= tok_opcode;
            tk_len   <= tok_length;
            tk_addr  <= tok_mem_addr;
            scalar_r <= scalar_data_in;
            vec_r    <= vector_data_in;
            tk_err   <= 1'b0;
            tile_result_scalar <= '0;
            tile_result_vector <= '0;

            case (tok_opcode)
              // ---- inherited scratchpad tokens (same field use as compute_tile) ----
              OP_LOAD, OP_STORE, OP_GFXMEM: begin
                if (tok_mem_addr >= 14'(SRAM_DEPTH)) begin
                  tk_err <= 1'b1; flags[FLAG_ADDR_ERR] <= 1'b1; tstate <= T_FINISH;
                end else begin
                  tk_req_valid  <= 1'b1;
                  tk_req_opcode <= (tok_opcode == OP_GFXMEM) ? OP_STORE : tok_opcode;
                  tk_req_addr   <= {22'b0, tok_mem_addr[7:0], 2'b00};
                  tstate        <= T_MEMWAIT;
                end
              end
              OP_VLOAD, OP_VSTORE, OP_DFLOAD, OP_DFSTORE: begin
                if (tok_mem_addr > 14'(SRAM_DEPTH - 4)) begin
                  tk_err <= 1'b1; flags[FLAG_ADDR_ERR] <= 1'b1; tstate <= T_FINISH;
                end else begin
                  tk_req_valid  <= 1'b1; tk_req_opcode <= tok_opcode;
                  tk_req_addr   <= {22'b0, tok_mem_addr[7:0], 2'b00};
                  tstate        <= T_MEMWAIT;
                end
              end
              OP_DFSYNC: tstate <= T_FINISH;

              // ---- graphics extension ----------------------------------------------
              OP_GFXREG: begin
                if (tok_mem_addr < 14'd16) begin
                  mat[tok_mem_addr[3:0]] <= $signed(scalar_data_in);
                end else begin
                  case (tok_mem_addr)
                    14'(R_CTRL):        ctrl        <= scalar_data_in[CTRL_W-1:0];
                    14'(R_VTX_STRIDE): begin
                      if (scalar_data_in >= 32'd4 && scalar_data_in <= 32'd64) vtx_stride <= scalar_data_in[7:0];
                      else begin tk_err <= 1'b1; flags[FLAG_BAD_TOKEN] <= 1'b1; end
                    end
                    14'(R_TEX_CTRL): begin
                      if (scalar_data_in[3:0] <= 4'd6 && scalar_data_in[7:4] <= 4'd6) tex_log2 <= scalar_data_in[7:0];
                      else begin tk_err <= 1'b1; flags[FLAG_BAD_TOKEN] <= 1'b1; end
                    end
                    14'(R_VTX_BASE):    vtx_base    <= scalar_data_in[15:0];
                    14'(R_TRI_BASE):    tri_base    <= scalar_data_in[15:0];
                    14'(R_NUM_TRI):     num_tri     <= scalar_data_in[15:0];
                    14'(R_CLEAR_DEPTH): clear_depth <= scalar_data_in[15:0];
                    14'(R_STATS_CLR): begin
                      flags <= '0;
                      c_tri_in <= '0; c_tri_addr_err <= '0; c_tri_clip_rej <= '0; c_tri_clipped <= '0;
                      c_tri_setup <= '0; c_tri_degen <= '0; c_tri_cull <= '0; c_tri_raster <= '0;
                      c_pix_cov <= '0; c_pix_written <= '0; c_pix_zfail <= '0; c_pix_tex <= '0;
                    end
                    default: begin tk_err <= 1'b1; flags[FLAG_BAD_TOKEN] <= 1'b1; end
                  endcase
                end
                tstate <= T_FINISH;
              end

              OP_GFXCLEAR: begin
                clr_start <= 1'b1;
                clr_c_en  <= tok_length[0];
                clr_z_en  <= tok_length[1];
                tstate    <= T_CLEAR;
              end

              OP_GFXDRAW: begin
                pix_at_start <= c_pix_written;
                tri_idx      <= '0;
                clip_fin     <= 1'b0;
                if (num_tri == 16'd0) tstate <= T_FINISH;
                else begin dstate <= D_VSTART; tstate <= T_DRAW; end
              end

              OP_GFXTEX: begin                        // texel write: addr14 = texel index, scalar = {8'b0,R,G,B}
                if (tok_mem_addr >= 14'(1 << TEX_AW)) begin
                  tk_err <= 1'b1; flags[FLAG_ADDR_ERR] <= 1'b1;
                end else begin
                  tex_we <= 1'b1; tex_waddr <= tok_mem_addr[TEX_AW-1:0]; tex_wdata <= scalar_data_in[23:0];
                end
                tstate <= T_FINISH;
              end

              OP_GFXRD:   tstate <= T_RD0;

              OP_GFXSTAT: tstate <= T_RD0;            // uses T_RD0/T_RD1 timing for a uniform path

              default: begin                          // vector/tensor kernels, reserved GFX opcodes
                tk_err <= 1'b1; flags[FLAG_BAD_TOKEN] <= 1'b1; tstate <= T_FINISH;
              end
            endcase
          end
        end

        // ==================================================================
        T_MEMWAIT: if (mem_resp_valid) begin
          // Loads return data; stores return 0 (the base compute_tile would leak the stale
          // resp_rdata of the previous read here - not meaningful, so it is defined as 0).
          if (tk_op == OP_LOAD) begin
            tile_result_scalar <= mem_resp_rdata;
          end else if (tk_op == OP_VLOAD || tk_op == OP_DFLOAD) begin
            tile_result_scalar <= mem_resp_vrdata[XLEN-1:0];   // word 0 (base leaves resp_rdata stale here)
            tile_result_vector <= mem_resp_vrdata;
          end
          tstate             <= T_FINISH;
        end

        // ==================================================================
        T_CLEAR: if (!clr_busy && !clr_start) tstate <= T_FINISH;

        // ==================================================================
        T_DRAW: begin
          case (dstate)
            D_VSTART: begin
              vtx_start <= 1'b1;
              c_tri_in  <= c_tri_in + 32'd1;
              clip_fin  <= 1'b0;
              dstate    <= D_VWAIT;
            end
            D_VWAIT: if (vtx_done) begin
              if (vtx_err) begin
                c_tri_addr_err <= c_tri_addr_err + 32'd1;
                flags[FLAG_ADDR_ERR] <= 1'b1;
                dstate <= D_NEXT;
              end else dstate <= D_CSTART;
            end
            D_CSTART: begin clip_start <= 1'b1; dstate <= D_CWAIT; end
            D_CWAIT: begin                 // clip finished AND the last triangle fully rasterised
              if (clip_done) clip_fin <= 1'b1;
              if ((clip_fin || clip_done) && !rast_busy) dstate <= D_NEXT;
            end
            D_NEXT: begin
              tri_idx <= tri_idx + 16'd1;
              if (tri_idx + 16'd1 == num_tri) begin
                tile_result_scalar <= c_pix_written - pix_at_start;
                tstate <= T_FINISH;
              end else dstate <= D_VSTART;
            end
            default: dstate <= D_VSTART;
          endcase
        end

        // ==================================================================
        T_RD0: tstate <= T_RD1;                      // address presented, data registered at the edge
        T_RD1: begin
          if (tk_op == OP_GFXSTAT) begin
            tile_result_scalar <= stat_val;
          end else if (rd_ok) begin
            tile_result_scalar <= tk_addr[0] ? {16'b0, fa_rdata_z} : fa_rdata_c;
          end else begin
            tk_err <= 1'b1; flags[FLAG_ADDR_ERR] <= 1'b1;
          end
          tstate <= T_FINISH;
        end

        // ==================================================================
        T_FINISH: begin
          tile_done   <= 1'b1;
          tile_error  <= tk_err;
          token_ready <= 1'b1;
          tstate      <= T_IDLE;
        end

        default: tstate <= T_IDLE;
      endcase
    end
  end

`ifndef SYNTHESIS
  // The numeric spec (docs/02_NUMERIC_SPEC.md, "Limits") proves all register widths for 1 <= FB_W,FB_H <= 2048.
  initial begin
    if (FB_W < 1 || FB_W > 2048 || FB_H < 1 || FB_H > 2048) begin
      $display("SFGX ERROR: FB_W/FB_H must be in 1..2048 (got %0d x %0d)", FB_W, FB_H);
      $fatal(1);
    end
  end
`endif

  // inputs that this tile does not use (documented in the port list above)
  logic unused_ok;
  assign unused_ok = &{1'b0, tok_tile_id[0], tok_src_reg[0], tok_dst_reg[0], tok_vsrc_reg[0],
                       tok_vdst_reg[0], tok_func[0], vector_data_in_b[0], noc_flit_ready,
                       noc_flit_in.valid, noc_flit_in_valid, mem_align_err, vtx_busy, clip_busy,
                       fa_rdata_c[31:24], TILE_ID[0]};
endmodule
