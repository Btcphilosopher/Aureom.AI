// =============================================================================
// SilicaFlux Graphics Extension (SFGX) - package
// sfgx_pkg.sv
//
// Opcode allocation, register map, fixed-point constants and the flat vertex
// layouts shared by all SFGX modules.  Every constant here has a twin in
// ref/sfgx_ref.py (checked by tests/check_consts.py).
//
// The base architecture's silicaflux_pkg is imported, not modified.
// =============================================================================
`ifndef SFGX_PKG_SV
`define SFGX_PKG_SV

`include "silicaflux_pkg.sv"

package sfgx_pkg;

  // ---------------------------------------------------------------------------
  // Opcodes: SilicaFlux README reserves 0x18-0x1E for application-specific
  // dataflow kernels.  SFGX uses D-format for all of them (tile / rs1 / len /
  // addr14), exactly as decoder.sv maps FMT_D onto the scheduler token:
  //   scalar operand (rs1)  -> scalar_data_in
  //   addr14                -> tok_mem_addr
  //   len[4:0]              -> tok_length (= tok_func[4:0])
  // ---------------------------------------------------------------------------
  localparam logic [4:0] OP_GFXREG   = 5'h18; // write graphics register: idx=addr14, data=scalar
  localparam logic [4:0] OP_GFXDRAW  = 5'h19; // draw NUM_TRI indexed triangles from the scratchpad
  localparam logic [4:0] OP_GFXCLEAR = 5'h1A; // clear: len[0]=colour (scalar), len[1]=depth (CLEAR_DEPTH)
  localparam logic [4:0] OP_GFXRD    = 5'h1B; // read pixel: scalar={y[15:0],x[15:0]}, addr14: 0=colour 1=depth
  localparam logic [4:0] OP_GFXSTAT  = 5'h1C; // read status/counter idx=addr14 -> tile_result_scalar
  localparam logic [4:0] OP_GFXMEM   = 5'h1D; // scratchpad word write: addr14 = word address, scalar = data
  localparam logic [4:0] OP_GFXTEX   = 5'h1E; // texture memory / sampler access (milestone 2)

  // ---------------------------------------------------------------------------
  // GFXREG register map
  // ---------------------------------------------------------------------------
  localparam int R_MAT0        = 'h00;  // 0x00..0x0F  MVP matrix, row-major, Q16.16
  localparam int R_CTRL        = 'h10;
  localparam int R_VTX_BASE    = 'h11;  // scratchpad word address of vertex array
  localparam int R_TRI_BASE    = 'h12;  // scratchpad word address of triangle words
  localparam int R_NUM_TRI     = 'h13;
  localparam int R_CLEAR_DEPTH = 'h14;
  localparam int R_VTX_STRIDE  = 'h15;  // words per vertex record (4..64); words 4,5 = u,v when texturing
  localparam int R_TEX_CTRL    = 'h16;  // [3:0] log2(texture width) [7:4] log2(texture height), each 0..6
  localparam int R_STATS_CLR   = 'h1F;

  // CTRL bits
  localparam int CTRL_ZTEST    = 0;
  localparam int CTRL_ZWRITE   = 1;
  localparam int CTRL_ZFUNC_LO = 2;     // [4:2]
  localparam int CTRL_CULL_LO  = 5;     // [6:5] 0 none, 1 back, 2 front
  localparam int CTRL_FRONT_CW = 7;     // 0: counter-clockwise (as seen) is front-facing
  localparam int CTRL_TEX_EN   = 8;     // sample the texture (perspective-correct, nearest)
  localparam int CTRL_TEX_MOD  = 9;     // 1: modulate texel by interpolated vertex colour, 0: replace
  localparam int CTRL_TEX_CLAMP = 10;   // 1: clamp-to-edge, 0: repeat
  localparam int CTRL_W        = 11;

  // depth functions (OpenGL numbering)
  localparam logic [2:0] ZF_NEVER = 3'd0, ZF_LESS = 3'd1, ZF_EQUAL = 3'd2, ZF_LEQUAL = 3'd3,
                         ZF_GREATER = 3'd4, ZF_NOTEQUAL = 3'd5, ZF_GEQUAL = 3'd6, ZF_ALWAYS = 3'd7;

  // GFXSTAT indices
  localparam int ST_FLAGS = 0, ST_TRI_IN = 1, ST_TRI_ADDR_ERR = 2, ST_TRI_CLIP_REJ = 3,
                 ST_TRI_CLIPPED = 4, ST_TRI_SETUP = 5, ST_TRI_DEGEN = 6, ST_TRI_CULL = 7,
                 ST_TRI_RASTER = 8, ST_PIX_COV = 9, ST_PIX_WRITTEN = 10, ST_PIX_ZFAIL = 11,
                 ST_FBSIZE = 12, ST_ID = 13, ST_PIX_TEX = 14;
  localparam logic [31:0] SFGX_ID = 32'h53464758;          // "SFGX"

  localparam int FLAG_XFORM_OVF = 0;   // sticky: transformed coordinate saturated
  localparam int FLAG_ADDR_ERR  = 1;   // sticky: scratchpad / framebuffer address rejected
  localparam int FLAG_BAD_TOKEN = 2;   // sticky: unsupported register / selector

  // ---------------------------------------------------------------------------
  // Fixed-point constants
  // ---------------------------------------------------------------------------
  localparam int F_GRAD   = 24;        // fractional bits of plane gradients / accumulators (Z, R, G, B)
  localparam int F_GRAD_T = 12;        // ... of the texture attributes s, t, q
  localparam int TEX_AW   = 12;        // texture memory: 4096 texels (64 x 64 max), RGB888
  localparam int VTX_STRIDE_DEF = 4;   // default scratchpad words per vertex: x y z colour
  localparam logic [15:0] DEPTH_MAX = 16'hFFFF;

  // ---------------------------------------------------------------------------
  // Flat vertex layouts
  //   clip-space vertex (CV): x y z w signed Q16.16 ; r g b unsigned Q8.8 ; u v signed Q16.16
  //   screen vertex     (SV): X Y unsigned (1/256 px) ; Z unsigned Q16.8 ; r g b Q8.8 ;
  //                           s t q signed 40 bit, 24 fractional bits  (s=u/w, t=v/w, q=1/w)
  // ---------------------------------------------------------------------------
  localparam int CV_X = 0, CV_Y = 32, CV_Z = 64, CV_W = 96, CV_R = 128, CV_G = 144, CV_B = 160,
                 CV_U = 176, CV_V = 208;
  localparam int CVW  = 240;
  localparam int SV_X = 0, SV_Y = 24, SV_Z = 48, SV_R = 72, SV_G = 88, SV_B = 104,
                 SV_S = 120, SV_T = 160, SV_Q = 200;
  localparam int SVW  = 240;

endpackage

`endif // SFGX_PKG_SV
