#!/usr/bin/env python3
"""mkrom.py - turn the first N tokens of a scene (up to its first CAPTURE) into a token ROM for
integration/display/sfgx_cmd_rom.sv.   usage: mkrom.py <scene> <out.rom>   (prints NTOK)"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')
sys.path.insert(0, os.path.join(ROOT, 'ref'))
from sfgx_ref import parse_cmd

def main(scene, out):
    toks = []
    for it in parse_cmd(os.path.join(ROOT, 'scenes', scene + '.cmd')):
        if it[0] == 'CAPTURE': break
        _, op, addr, scalar, vec, length = it
        v = [x & 0xFFFFFFFF for x in vec]
        words = [op, addr, length, scalar & 0xFFFFFFFF, v[3], v[2], v[1], v[0]]
        toks.append(''.join('%08x' % w for w in words))
    open(out, 'w').write('\n'.join(toks) + '\n')
    print(len(toks))

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
