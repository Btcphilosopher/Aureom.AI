#!/usr/bin/env python3
"""
mk_cluster_prog.py - hand-assembler + program generator for the full-cluster test.

One description produces BOTH the SilicaFlux instruction words (loaded into the fetch unit's instruction
memory) and the equivalent token stream (.cmd) for the software reference, so the two cannot drift apart.

Instruction formats (docs/ISA_REFERENCE.md of the baseline):
  R  op|rd|rs1|rs2|func12      I  op|rd|rs1|imm17       D  op|tile3|reg5|len5|addr14
The graphics instructions are D-format with opcodes 0x18..0x1E; the scalar operand is register `reg`.
The baseline ISA can only load a 17-bit signed immediate (MOV), so wider constants are built with MUL/ADD.
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')
OP = dict(NOP=0, ADD=1, MUL=3, MOV=6, DFSYNC=0x0E, GFXREG=0x18, GFXDRAW=0x19, GFXCLEAR=0x1A, GFXMEM=0x1D, HALT=0x1F)
TILE = 3
NOPS = 4          # spacing after each instruction: keeps the 6-stage baseline pipeline hazard-free

def sext17(x): x &= 0x1FFFF; return x - 0x20000 if x & 0x10000 else x
def q16(f): return int(round(f * 65536)) & 0xFFFFFFFF

class Prog:
    def __init__(self):
        self.words, self.cmd, self.reg = [], [], {i: 0 for i in range(32)}
    def _emit(self, w): self.words.append(w & 0xFFFFFFFF); self.words += [0] * NOPS
    def mov(self, rd, imm):
        self._emit((OP['MOV'] << 27) | (rd << 22) | (0 << 17) | (imm & 0x1FFFF)); self.reg[rd] = sext17(imm) & 0xFFFFFFFF
    def mul(self, rd, a, b):
        self._emit((OP['MUL'] << 27) | (rd << 22) | (a << 17) | (b << 12)); self.reg[rd] = (self.reg[a] * self.reg[b]) & 0xFFFFFFFF
    def add(self, rd, a, b):
        self._emit((OP['ADD'] << 27) | (rd << 22) | (a << 17) | (b << 12)); self.reg[rd] = (self.reg[a] + self.reg[b]) & 0xFFFFFFFF
    def _d(self, op, reg, length, addr):
        self._emit((op << 27) | (TILE << 24) | (reg << 19) | (length << 14) | (addr & 0x3FFF))
    # Every graphics instruction is followed by DFSYNC.  This is not optional: the UNMODIFIED scheduler can silently drop an
    # instruction that is already waiting for the same tile when that tile completes (instr_ready is asserted while
    # tile_busy is still set, so no token is dispatched).  DFSYNC is the baseline's documented way to order work on a tile.
    def gfxreg(self, idx, reg): self._d(OP['GFXREG'], reg, 0, idx); self.cmd.append(f"GFXREG {idx:#x} {self.reg[reg]:#x}"); self.dfsync()
    def gfxmem(self, addr, reg): self._d(OP['GFXMEM'], reg, 0, addr); self.cmd.append(f"GFXMEM {addr} {self.reg[reg]:#x}"); self.dfsync()
    def gfxclear(self, reg, flags): self._d(OP['GFXCLEAR'], reg, flags, 0); self.cmd.append(f"GFXCLEAR {flags} {self.reg[reg]:#x}"); self.dfsync()
    def gfxdraw(self): self._d(OP['GFXDRAW'], 0, 0, 0); self.cmd.append("GFXDRAW"); self.dfsync()
    def dfsync(self): self._emit((OP['DFSYNC'] << 27)); self.cmd.append("DFSYNC")
    def halt(self): self.words.append(OP['HALT'] << 27); self.words += [0] * 2

def triangle_program():
    p = Prog()
    p.mov(2, 256); p.mul(2, 2, 2)                  # r2 = 65536 (1.0 in Q16.16; does not fit imm17)
    p.mov(3, 255); p.mul(4, 3, 2)                  # r4 = 0x00FF0000 (red)
    p.mov(5, 0xFF00)                               # r5 = 0x0000FF00 (green)
    p.mov(6, 0x00FF)                               # r6 = 0x000000FF (blue)
    verts = [(-0.5, -0.5, 4), (0.5, -0.5, 5), (0.0, 0.5, 6)]      # NDC x,y ; colour register
    for i, (x, y, creg) in enumerate(verts):
        for k, val in enumerate((q16(x), q16(y), 0)):
            p.mov(1, sext17(val)); p.gfxmem(4 * i + k, 1)         # x/y fit imm17 (|v| < 1.0 in Q16.16)
        p.gfxmem(4 * i + 3, creg)
    p.mov(7, 0x400); p.mov(8, 32); p.mul(8, 8, 2); p.add(7, 7, 8)  # triangle word {idx2=2, idx1=1, idx0=0} = 0x200400
    p.gfxmem(12, 7)
    p.gfxreg(0x11, 0)                              # VTX_BASE = 0   (r0 is hardwired zero)
    p.mov(1, 12); p.gfxreg(0x12, 1)                # TRI_BASE = 12
    p.mov(1, 1);  p.gfxreg(0x13, 1)                # NUM_TRI  = 1
    p.mov(1, 0x2030); p.gfxclear(1, 3)             # clear colour 0x002030, depth 0xFFFF
    p.gfxdraw(); p.halt()
    return p

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    p = triangle_program()
    open(os.path.join(out, 'cluster_triangle.hex'), 'w').write('\n'.join('%08x' % w for w in p.words) + '\n')
    with open(os.path.join(out, 'cluster_triangle.cmd'), 'w') as f:
        f.write('\n'.join(p.cmd) + '\nCAPTURE final\n')
    print(len(p.words), "instruction words,", len(p.cmd), "graphics tokens")
