#!/usr/bin/env python3
"""bench.py - measured cycle counts of single-triangle draws in the RTL (Verilator, 160x120), to characterise performance.
Each case is one GFXDRAW of one triangle; the cycle count is the harness's token-to-tile_done latency."""
import os, subprocess, sys, math
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.abspath(os.path.join(HERE, '..'))
sys.path.insert(0, os.path.join(ROOT, 'ref')); sys.path.insert(0, os.path.join(ROOT, 'tests'))
import scenes, sfgx_ref as R, mktok

W, H = 160, 120
def case(name, tri_px, textured=False, clipped=False):
    path = os.path.join(ROOT, 'results', 'bench', name + '.cmd'); os.makedirs(os.path.dirname(path), exist_ok=True)
    c = scenes.Cmd(path); c.matrix(scenes.m_identity()); c.ctrl(ztest=1, zwrite=1, zfunc=1, tex=int(textured), mod=1)
    if textured: c.texture(scenes.tex_indexed(16, 16), 4, 4)
    c.clear(0x101010)
    (x0, y0), (x1, y1), (x2, y2) = tri_px
    f = lambda X, Y: (scenes.ndc(X, W), scenes.ndcy(Y, H))
    if textured:
        ids = [c.vert_uv(*f(X, Y), 0.0, 0xFFFFFF, u, v) for (X, Y), (u, v) in zip(((x0, y0), (x1, y1), (x2, y2)), ((0, 0), (1, 0), (0, 1)))]
    else:
        ids = [c.vert(*f(X, Y), 0.0, col) for (X, Y), col in zip(((x0, y0), (x1, y1), (x2, y2)), (0xFF0000, 0x00FF00, 0x0000FF))]
    c.tri(*ids); c.flush(); c.close()
    return path

cases = [("tiny_empty_bbox", ((80.2, 60.2), (80.4, 60.2), (80.2, 60.4)), False),
         ("small_10px", ((20, 20), (30, 20), (20, 30)), False), ("medium_40px", ((20, 20), (60, 20), (20, 60)), False),
         ("large_100px", ((10, 10), (110, 10), (10, 110)), False),
         ("tex_small_10px", ((20, 20), (30, 20), (20, 30)), True), ("tex_medium_40px", ((20, 20), (60, 20), (20, 60)), True),
         ("tex_large_100px", ((10, 10), (110, 10), (10, 110)), True)]
exe = os.path.join(ROOT, 'sim', f'obj_{W}x{H}', f'sfgx_sim_{W}x{H}')
if not os.path.exists(exe): subprocess.check_call([os.path.join(ROOT, 'sim', 'build.sh'), str(W), str(H)], stdout=subprocess.DEVNULL)
print(f"{'case':18s} {'bbox px':>8s} {'covered':>8s} {'draw cycles':>12s}  (clear of {W}x{H} = {W*H} cycles)")
rows = []
for name, tri, tex in cases:
    p = case(name, tri, tex)
    tok = p.replace('.cmd', '.tok'); mktok.convert(p, tok); out = p.replace('.cmd', '_out')
    subprocess.check_call([exe, tok, out], stdout=subprocess.DEVNULL)
    toks = [l.split() for l in open(os.path.join(out, 'tokens.txt'))]
    draw_cycles = int([t for t in toks if t[0] == '19'][0][3])
    m = R.run_cmd(p, W, H)['model']
    xs = [t[0] for t in tri]; ys = [t[1] for t in tri]
    bbox = (math.floor(max(xs)) - math.floor(min(xs)) + 1) * (math.floor(max(ys)) - math.floor(min(ys)) + 1)
    rows.append((name, bbox, m.cnt['pix_cov'], draw_cycles))
    print(f"{name:18s} {bbox:8d} {m.cnt['pix_cov']:8d} {draw_cycles:12d}")
a = rows[0][3]
print(f"\nfixed per-triangle cost (vertex fetch + MVP + clip + viewport + setup + 8 gradient divides) ~ {a} cycles (empty bbox)")
u = [r for r in rows if not r[0].startswith('tex')]; t = [r for r in rows if r[0].startswith('tex')]
for grp, nm in ((u, 'untextured'), (t, 'textured')):
    lo, hi = grp[1], grp[-1]
    print(f"{nm:11s}: incremental cost between '{lo[0]}' and '{hi[0]}' = {(hi[3]-lo[3])/(hi[2]-lo[2]):.2f} cycles per covered pixel (incl. ~1 per bbox pixel)")
