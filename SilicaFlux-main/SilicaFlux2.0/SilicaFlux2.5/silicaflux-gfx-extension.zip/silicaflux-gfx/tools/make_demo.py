#!/usr/bin/env python3
"""make_demo.py - build the demo animations / contact sheets from the framebuffer captures that the
RTL simulation wrote (results/rtl_runs/<scene>_WxH/*.ppm).  Nothing here renders anything: it only
re-encodes frames that came out of the Verilator simulation of sfgx_gfx_tile through its display port.
usage: make_demo.py <scene> <W> <H> <prefix> [scale]"""
import glob, os, sys
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')

def main(scene, W, H, prefix, scale=4):
    d = os.path.join(ROOT, 'results', 'rtl_runs', f'{scene}_{W}x{H}')
    frames = sorted(glob.glob(os.path.join(d, f'{prefix}_*.ppm')))
    if not frames: raise SystemExit(f"no frames {prefix}_*.ppm in {d}")
    imgs = [Image.open(f).convert('RGB').resize((W * scale, H * scale), Image.NEAREST) for f in frames]
    out = os.path.join(ROOT, 'demo')
    os.makedirs(out, exist_ok=True)
    imgs[0].save(os.path.join(out, f'{scene}.gif'), save_all=True, append_images=imgs[1:], duration=80, loop=0, optimize=False)
    cols = 6 if len(imgs) > 12 else 4
    sel = imgs[::max(1, len(imgs) // (cols * 2))][:cols * 2]
    rows = (len(sel) + cols - 1) // cols
    sheet = Image.new('RGB', (cols * W * 2, rows * H * 2), (20, 20, 20))
    for i, im in enumerate(sel):
        sheet.paste(im.resize((W * 2, H * 2), Image.NEAREST), ((i % cols) * W * 2, (i // cols) * H * 2))
    sheet.save(os.path.join(out, f'{scene}_sheet.png'))
    imgs[len(imgs) // 3].save(os.path.join(out, f'{scene}_frame.png'))
    print(f"{scene}: {len(frames)} RTL frames -> demo/{scene}.gif, {scene}_sheet.png, {scene}_frame.png")

if __name__ == '__main__':
    main(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4], int(sys.argv[5]) if len(sys.argv) > 5 else 4)
