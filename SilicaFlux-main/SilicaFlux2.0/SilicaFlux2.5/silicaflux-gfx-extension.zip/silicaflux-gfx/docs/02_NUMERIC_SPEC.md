# SFGX numeric specification

*Coordinate conventions, fixed-point precision, edge inclusion, depth representation and overflow handling.*

This document is the contract that **both** `rtl/` (SystemVerilog) and `ref/sfgx_ref.py` (the bit-accurate software
reference) implement. Where this text and the reference disagree, the reference is the executable truth and the text
is a bug. Every width claim below is *enforced* by assertions in the reference (`_chk()` in `ref/sfgx_ref.py`,
exercised by `tests/check_bounds.py`), not merely argued.

> **Scope.** SFGX is a fixed-function triangle renderer. It is **not** an implementation of OpenGL, Vulkan, Direct3D
> or any other graphics API, and nothing here should be read as a conformance claim (see `06_LIMITATIONS_AND_FUTURE.md`).
> Where a convention resembles OpenGL (e.g. the `[-w, w]` clip volume) it is chosen for familiarity, not conformance.

---

## 1. Spaces and coordinate conventions

```
 object space ──(MVP, Q16.16)──▶ clip space (x,y,z,w) ──(clip, ÷w)──▶ NDC ──(viewport)──▶ window space ──▶ pixels
```

| Item | Convention |
|---|---|
| Handedness | Right-handed object/clip space. The camera looks down **−Z** in view space (as in OpenGL-style matrices). |
| Clip volume | `−w ≤ x ≤ w`, `−w ≤ y ≤ w`, `−w ≤ z ≤ w` (six planes). **Near plane is `z = −w`, far plane is `z = +w`.** |
| NDC | `x_ndc, y_ndc, z_ndc ∈ [−1, 1]`; **+Y is up**, +X is right. |
| Window origin | **Top-left** of the image. **+X right, +Y down.** Row 0 is the top row. |
| Pixel sample point | The **centre** of the pixel: pixel `(i, j)` is sampled at window position `(i + ½, j + ½)`. Pixel `(i,j)` covers `[i,i+1) × [j,j+1)`. |
| Viewport | The whole framebuffer: `x_win = (x_ndc+1)/2 · FB_W`, `y_win = (1 − y_ndc)/2 · FB_H`. No separate viewport/scissor registers. |
| Framebuffer order | Row-major, `addr = y·FB_W + x`, row 0 = top. |
| Facing | A triangle is **front-facing if it appears counter-clockwise on screen** (default). `CTRL.FRONT_CW = 1` inverts that. Because window Y points down, "counter-clockwise on screen" ⇔ `area2 < 0` in the formula of §8. |
| Matrix layout | 16 words `M[r][c]`, **row-major**, `clip = M · (x, y, z, 1)ᵀ`. Registers `0x00 … 0x0F` = `M00, M01, M02, M03, M10, …`. |

A camera pitched *down* onto a scene needs `Rx(+θ)`; the demo originally had the sign wrong and the ground quad was (correctly)
back-face culled — a reminder that bit-exact agreement does not prove a scene looks right. Frames were inspected visually.

## 2. Number formats

| Quantity | Format | Notes |
|---|---|---|
| Object coordinates `x y z`, matrix elements, clip coordinates `x y z w` | **signed Q16.16**, 32-bit | resolution 2⁻¹⁶, range ±32768 |
| Vertex colour | `0x00RRGGBB`, 8 bits per channel | bits 31:24 ignored |
| Colour inside the pipeline | **unsigned Q8.8** (16-bit) per channel | `c << 8`; interpolated through the clipper with 8 fractional bits |
| Texture coordinates `u v` | signed Q16.16 | 1.0 = the whole texture once |
| Window X, Y | **unsigned, units of 1/256 pixel** (8 subpixel bits) | `0 … FB_W·256` |
| Window Z | **unsigned Q16.8** | `0 … 65535·256`; 24 bits |
| Stored depth | **unsigned 16-bit (Z16)** | see §10 |
| Stored colour | `{8'h00, R8, G8, B8}` in a 32-bit word | |
| Texture attributes `s t q` | **signed 40-bit, 24 fractional bits** | `s = u/w`, `t = v/w`, `q = 1/w` |
| Plane gradients | 64-bit two's-complement integers, 24 (Z,R,G,B) or 12 (s,t,q) fractional bits | per **1/256-pixel** step |

## 3. Vertex input

Vertices and triangles are read from the tile's **256-word scratchpad** (the unmodified SilicaFlux `memory_controller`).

* Vertex record, `R_VTX_STRIDE` words (default **4**, allowed 4…64): `word0 = x`, `word1 = y`, `word2 = z`, `word3 = colour`,
  and, when texturing is enabled and the stride is ≥ 6, `word4 = u`, `word5 = v` (otherwise `u = v = 0`).
* Triangle word: `{2'b0, i2[9:0], i1[9:0], i0[9:0]}` — three 10-bit vertex indices.
* A draw processes `R_NUM_TRI` triangle words starting at `R_TRI_BASE`; vertex `k` is at `R_VTX_BASE + idx_k · stride`.
* **Range checks (the base controller would silently alias):** a triangle word at `≥ 256`, or a vertex record whose last word would
  be at `≥ 256`, drops that triangle, increments `tri_addr_err` and sets the sticky `ADDR_ERR` flag.

## 4. Vertex transformation (restricted)

```
acc_r  = M[r][0]·x + M[r][1]·y + M[r][2]·z + M[r][3]·65536          (exact, 68-bit signed)
clip_r = sat32( (acc_r + 2¹⁵) >>> 16 )                              (round-half-up, arithmetic shift)
```

* **Restricted** means: position only, one 4×4 matrix per draw (the host supplies the concatenated MVP), `w_in = 1`, colour and
  UV pass through, **no** normals, lighting, skinning or programmable shading.
* **Overflow:** products and the 4-term sum are exact (the largest possible magnitude needs 64 of the 67 available bits; checked at the
  extremes of Q16.16 operands). Only the final narrowing saturates to `[−2³¹, 2³¹−1]` and raises the sticky `XFORM_OVF` flag.

## 5. Clipping

Sutherland–Hodgman in **homogeneous clip space**, in this fixed plane order (order matters because intersection rounding is sequential):

| # | plane distance `d` | boundary |
|---|---|---|
| 0 | `w + x` | left |
| 1 | `w − x` | right |
| 2 | `w + y` | bottom |
| 3 | `w − y` | top |
| 4 | `w + z` | **near** |
| 5 | `w − z` | **far** |

* `d` is an **exact 34-bit signed** value (no overflow is possible for 32-bit inputs). A vertex is **inside** when `d ≥ 0`
  (a vertex exactly on the plane is inside). Edges are `P → Q` with `P` the previous and `Q` the current vertex (cyclic):

  | P | Q | emit |
  |---|---|---|
  | in | in | `Q` |
  | in | out | intersection `I` **only if `d_P > 0`** (if `d_P = 0`, `I = P`, already emitted) |
  | out | in | intersection `I` **only if `d_Q > 0`**, then `Q` |
  | out | out | nothing |

* Intersection parameter `t = ⌊ |d_P| · 2³² / |d_P − d_Q| ⌋` (**Q0.32**, always `< 2³²`), applied identically to every attribute `a`
  (`x y z w`, `r g b`, `u v`): `a_I = a_P + (((a_Q − a_P)·t + 2³¹) >>> 32)`. The interpolated value is a convex combination, so it
  can never leave `[min, max]` of its endpoints — **no overflow is possible in the clipper.**
  Because interpolation is linear in clip space, colour and UV are **perspective-correct** across clipped edges.
* **Rejection:** a plane pass that produces **zero** vertices rejects the triangle immediately. After six planes, `< 3` vertices or **any vertex with
  `w ≤ 0`** rejects it (`w ≤ 0` can only survive for the degenerate clip-space point `(0,0,0,0)`). An edge lying exactly in a plane can
  leave a 2-vertex polygon that *regrows* to three collinear vertices at a later plane — handled like any other polygon.
* A convex polygon gains at most one vertex per plane, so ≤ 9 entries suffice (a simulation assertion guards the buffer).
  In practice the largest polygons seen were 7 vertices.
* Output is fan-triangulated `(V0, Vk, Vk+1)`. The statistics `tri_clip_rej` and `tri_clipped` count rejected triangles and triangles that
  gained an intersection vertex.

## 6. Viewport transform and perspective divide

For each surviving vertex (`w > 0`), with `FB_W`, `FB_H` the framebuffer size and rounding `round(n/d) = ⌊n/d⌋ + [2·(n mod d) ≥ d]` (round-half-up):

```
X = round( clamp(x + w, 0, 2w) · (FB_W·128)   / w )     units of 1/256 px,  0 … FB_W·256
Y = round( clamp(w − y, 0, 2w) · (FB_H·128)   / w )     units of 1/256 px,  0 … FB_H·256   (Y is flipped: top = 0)
Z = round( clamp(z + w, 0, 2w) · (65535·128)  / w )     Q16.8,              0 … 65535·256
```

* The `clamp` makes every result lie **inside the framebuffer rectangle by construction** (a clipped vertex can land 1 LSB outside `[−w, w]`
  through rounding; clamping snaps it back). All arithmetic after the clamp is unsigned, so this stage cannot overflow.
* **Subpixel precision: 8 bits (1/256 px).** Vertex positions are snapped to this grid; this is the only geometric quantisation.
* With texturing: `q = min(round(2⁴⁰ / w), 2³⁹−1)` (1/w in Q8.24, saturating for `w < 2⁻¹⁵`), `s = sat40((u·q + 2¹⁵) >>> 16)`, `t` likewise.

## 7. Colour interpolation

Colour is interpolated **linearly in screen space** (Gouraud / affine), per channel, using the plane-equation machinery of §9.
It is **not perspective-corrected**. (Texture coordinates *are*; see §12.) After the clipper the three channels are Q8.8.

## 8. Triangle setup

With the three window vertices `V0, V1, V2` (X, Y in 1/256 px):

```
area2 = (X1−X0)(Y2−Y0) − (X2−X0)(Y1−Y0)         exact, units 1/65536 px², |area2| < 2³⁹
area2 == 0                    → degenerate, dropped            (tri_degen)
front = (area2 < 0)  XOR  CTRL.FRONT_CW                          (area2 < 0 ⇔ counter-clockwise on screen, Y down)
CTRL.CULL = 1 (back) drops !front,  = 2 (front) drops front      (tri_cull)
area2 < 0                     → swap V1,V2 so that area2 > 0     (clockwise on screen; coverage is orientation-independent)
```

Edge functions for edges `e0: V0→V1`, `e1: V1→V2`, `e2: V2→V0` with `dx = bx−ax`, `dy = by−ay`:
`E(p) = dx·(py − ay) − dy·(px − ax)`, evaluated at the pixel centre `p = (256·i + 128, 256·j + 128)`. Values are exact integers; the registers are
48-bit signed while the worst case needs 38 bits (§13).

## 9. Edge inclusion rule — **top-left**

A pixel is covered iff **for all three edges** `E_i(p) > 0`, **or** `E_i(p) == 0` and edge *i* is a **top-left edge**:

```
edge i is top-left   ⇔   dy_i < 0   ||   (dy_i == 0 && dx_i > 0)
```

(after the orientation normalisation of §8, i.e. for a triangle that is *clockwise on screen with Y pointing down*; this is the usual
"top edge = horizontal edge with the interior below it, left edge = edge with the interior to its right").
The test is implemented as `E_i − bias_i ≥ 0` with `bias_i = 0` for top-left edges and `1` otherwise.

**Shared edges.** Two triangles that share an edge with identical integer endpoints see exactly opposite `E` values on it
(integer arithmetic, no rounding), and — after normalisation — traverse it in opposite directions, so **exactly one** of them classifies it as
top-left. A pixel centre exactly on a shared edge or shared vertex is therefore covered **exactly once**: no cracks, no double hits.
This is verified (a) bit-exactly RTL = reference, and (b) independently by `tests/check_properties.py`, which classifies every pixel centre with
`fractions.Fraction` arithmetic and demands coverage count 1 on shared edges/vertices and 0 outside, on quads (both diagonals, both windings,
pixel-aligned and half-pixel-aligned), fans around pixel-corner and pixel-centre hubs, strips with horizontal/vertical shared edges, and an irregular
1/256-px mesh. The test *has teeth*: mutants with an inclusive rule, an exclusive rule, or a missing horizontal-edge clause are all rejected,
while an equally watertight bottom-right rule correctly passes (the property cannot pin the convention; the exact-match reference does).

Bounding box: `x ∈ [max(0, ⌊Xmin/256⌋), min(FB_W−1, ⌊Xmax/256⌋)]` (likewise Y); it is conservative, coverage is decided only by the edge test.
Rows are scanned top→bottom, pixels left→right.

## 10. Depth representation

* **Z16, unsigned. `0` = near plane (`z_ndc = −1`), `65535` = far plane (`z_ndc = +1`).**
* The stored value is a **linear function of `z_ndc`** (i.e. *hyperbolic* in eye-space distance, like a conventional post-projective depth buffer):
  precision is concentrated near the camera and degrades far away. 16 bits are deliberately small (area/BRAM); coplanar or nearly coplanar surfaces z-fight.
* Window Z carries 8 extra fractional bits (Q16.8) through setup; the per-pixel value is `clamp((acc + 2³¹) >>> 32, 0, 65535)` of the 64-bit plane accumulator,
  i.e. round-half-up to the integer depth.
* Depth is interpolated **linearly in screen space**, which is exact for `z_ndc` (it is affine in screen coordinates).
* `CTRL.ZTEST` enables the test; `CTRL.ZFUNC` (OpenGL numbering) is `0 NEVER, 1 LESS, 2 EQUAL, 3 LEQUAL, 4 GREATER, 5 NOTEQUAL, 6 GEQUAL, 7 ALWAYS`
  with `new OP old`; `CTRL.ZWRITE` enables depth writes. With the test disabled every covered pixel is written. `GFXCLEAR` fills depth with `R_CLEAR_DEPTH` (default `0xFFFF`).

## 11. Plane-equation interpolation (Z, R, G, B)

For an attribute `v` with vertex values `v0, v1, v2` (Q?.8) and edge deltas `dx_i, dy_i`:

```
NX = −(dy1·v0 + dy2·v1 + dy0·v2)         NY = dx1·v0 + dx2·v1 + dx0·v2
gX = round_away( (NX · 2²⁴) / area2 )    gY = round_away( (NY · 2²⁴) / area2 )     (per 1/256-px step; reduced modulo 2⁶⁴)
acc(px,py) = (v0 << 24) + gX·(px − X0) + gY·(py − Y0)                               (64-bit two's complement, wraps)
value = (acc + 2³¹) >>> 32                                                          (then clamp: 0…255 colour, 0…65535 depth)
```

`round_away` rounds half away from zero on the magnitude. Because accumulation is integer addition, the incremental scan (add `gX·256` per pixel, `gY·256` per row)
equals the closed form exactly. **Wrap is by design:** for a covered pixel the true value is inside the triangle's attribute range, so a wrapped-but-modular sum still yields the right value.

## 12. Texture sampling (milestone 2)

Enabled by `CTRL.TEX_EN`. **Only pixels that pass the depth test are sampled.** Nearest-neighbour, **perspective-correct**.

```
S = (acc_s + 2¹¹) >>> 12      T = (acc_t + 2¹¹) >>> 12      Q' = max((acc_q + 2¹¹) >>> 12, 1)
tx_f = ⌊ (S << log2W) / Q' ⌋            ty_f = ⌊ (T << log2H) / Q' ⌋          floor division (floor for negatives too)
REPEAT (default):  tx = tx_f mod W (two's-complement low bits)        CLAMP:  tx = clamp(tx_f, 0, W−1)         likewise ty
texel = tex[(ty << log2W) | tx]
REPLACE:   colour = texel
MODULATE:  c' = (y + 1 + (y >> 8)) >> 8  with y = texel_c · vertex_c + 127        (= round(texel·vertex/255), exact for 0 ≤ y ≤ 65280)
```

* Texture: RGB888, power-of-two size, `log2W, log2H ∈ 0…6` (≤ 64×64 = 4096 texels), row-major, loaded one texel per `GFXTEX` token.
* The two divisions per sample are why a textured pixel costs ≈ 55 clocks (§ performance in `01_ARCHITECTURE.md`).
* No mipmapping, no bilinear filtering: minification aliases (visible on the smaller demo cube).
* `s,t` saturate at ±2³⁹ and `q` at 2³⁹−1; sane content (|u| ≲ 2⁸, w ≥ 2⁻⁷) is far from these limits. Interpolated `S,T` are bounded by `2⁴²` and `Q' < 2⁴⁰` (asserted).

## 13. Overflow and range handling — summary

| Stage | Quantity | Width / bound (checked) | Mechanism |
|---|---|---|---|
| Vertex fetch | scratchpad address | `< 256` words | **rejected** (triangle dropped, `ADDR_ERR`); never aliased |
| Transform | 4-term MAC | exact, ≤ 64 bits used of 68 | exact |
| Transform | clip coordinate | int32 | **saturate** + sticky `XFORM_OVF` |
| Clip | plane distance | exact 34-bit | none needed |
| Clip | `t`, interpolated attributes | `t < 2³²`; convex combination | none needed (cannot overflow) |
| Viewport | numerators `n·(FB·128)` | ≤ 56 bits (45 observed) | clamp before divide ⇒ results in-rectangle |
| Setup | `area2` | **< 2³⁹** (tight: a full-screen corner triangle at 2048² needs exactly 39 bits) | 40-bit divider denominator |
| Setup | edge function | < 2³⁸ (48-bit registers) | none needed for `FB ≤ 2048` |
| Setup | gradient numerator `|N|` | ≤ 2⁴⁷ (Z,R,G,B), ≤ 2⁶¹ (s,t,q) | 80-bit divider numerator |
| Raster | plane accumulators | 64-bit, **wrap by design** | covered pixels are in range |
| Raster | final colour / depth | clamp 0…255 / 0…65535 | **unreachable** under the covered-pixel invariant (0 activations in all scenes and in 11.5 M adversarial sliver pixels (23 M in a larger run)) — kept as defence in depth |
| Raster | framebuffer address | bbox clamped to `[0,FB_W−1]×[0,FB_H−1]` | by construction |
| Tokens | pixel read-back `(x,y)`, texel index, register index/value | bounds-checked | **rejected** with `tile_error` + sticky flag |

## 14. Status, counters and errors

`GFXSTAT idx` returns: `0` sticky flags (`bit0 XFORM_OVF`, `bit1 ADDR_ERR`, `bit2 BAD_TOKEN`), `1 tri_in`, `2 tri_addr_err`, `3 tri_clip_rej`, `4 tri_clipped`,
`5 tri_setup`, `6 tri_degen`, `7 tri_cull`, `8 tri_raster`, `9 pix_cov`, `10 pix_written`, `11 pix_zfail`, `12 FB_W | FB_H<<16`, `13 0x53464758 ("SFGX")`, `14 pix_tex`.
`GFXREG 0x1F` clears counters and flags. The reference model produces the same counters; they are compared exactly in every test.

## 15. Limits

`1 ≤ FB_W, FB_H ≤ 2048` (enforced at elaboration in simulation; all widths above are proven for this range) · scratchpad 256 words (the base architecture's `SRAM_DEPTH`) ·
vertex index 10 bits · `R_NUM_TRI`/`R_TRI_BASE`/`R_VTX_BASE` 16 bits · texture ≤ 64×64 · vertex stride 4…64.
