# Integration with the SilicaFlux compute architecture

The brief was to **retain the compute architecture's documented interfaces**. This document states exactly which interfaces those are, what was kept
byte-for-byte, what (little) had to be added, and which pre-existing defects in the baseline were found along the way.

**Baseline used:** `SilicaFlux-main/silicaflux.zip` (RTL v1.0, the version the repository README and `docs/ISA_REFERENCE.md` describe),
vendored **unmodified** in `third_party/silicaflux_v1_0/` (SHA-256 sums in `SHA256SUMS`; the source zip's hash is in `SOURCE_ZIP_SHA256`).
The repository also contains a differently-structured `silicaflux_pkg.sf` (a RISC-V-style "Silica Flux-2017" package) and a draft SF-G1 PCIe/driver contract;
neither is the documented v1.0 tile interface and neither is used (the SF-G1 driver document states of itself that it is an unratified proposal).

## 1. What was retained, unmodified

| Interface (source) | How SFGX uses it |
|---|---|
| **Tile token interface** (`compute_tile.sv` ports): `tok_opcode, tok_tile_id, tok_src_reg, tok_dst_reg, tok_vsrc_reg, tok_vdst_reg, tok_mem_addr, tok_length, tok_func, token_valid, token_ready, scalar_data_in, vector_data_in, vector_data_in_b` | `sfgx_gfx_tile` has the **same first 25 ports** (names, widths, directions, `noc_flit_t` types). |
| **Completion path**: `tile_done` (1-clock pulse), `tile_error`, `tile_result_scalar`, `tile_result_vector` | same semantics; `tile_done` and `token_ready` rise together as in `compute_tile`. |
| **Scheduler** (`scheduler.sv`) and its busy-scoreboard / `DFSYNC` barrier | **unmodified**; verified driving the graphics tile (`tb/sfgx_sched_top.sv`). |
| **Scratchpad** (`memory_controller.sv`): request/response handshake, 256 × 32-bit words, `OP_LOAD/STORE/VLOAD/VSTORE/DFLOAD/DFSTORE` | the **unmodified module** is instantiated inside the tile; vertex fetch uses only its scalar-LOAD handshake (pulse `req_valid` when `req_ready`, hold `req_addr` until `resp_valid`). |
| **Extension mechanism**: README — *"Reserve opcodes `0x18`–`0x1E` … for application-specific kernels. Wire them through the scheduler's opcode dispatch and add the corresponding functional unit to `compute_tile`."* | The seven reserved opcodes are all used (`0x18 GFXREG … 0x1E GFXTEX`), D-format, exactly as the decoder maps D-format onto a token (`tile` → `tok_tile_id`, `rs1` → scalar operand, `len` → `tok_length`/`func[4:0]`, `addr14` → `tok_mem_addr`). |
| **D-format** encoding `[31:27] op, [26:24] tile, [23:19] reg, [18:14] len, [13:0] addr` | unchanged. |
| Package (`silicaflux_pkg`) | imported as-is for `XLEN`, `VLEN`, `SRAM_DEPTH`, `noc_flit_t`, `OP_*`. SFGX adds its own `sfgx_pkg`; no name clashes (`OP_GFX*` do not exist in the baseline package). |

**Not used:** the NoC (graphics-tile input flits are accepted and dropped; the output is never driven), the vector engine and the tensor unit (those token types complete with `tile_error`
on a graphics tile — put graphics in one slot and keep compute tiles in the others), and the chiplet `tile_interface`.

## 2. What had to be added — and the (small) cost to the baseline

* **Nothing in the baseline needs to change for the scheduler-level contract.** That is what the verified fixture (`sfgx_sched_top`) shows: unmodified `scheduler.sv`, three unmodified `compute_tile`s
  and the graphics tile in slot 3, a real `VADD` on a compute tile running *while* the graphics tile draws, and `DFSYNC` holding behind it.
* **To drive the new opcodes from a real instruction stream** three small edits to the baseline are required (`integration/silicaflux_cluster_*.patch`, 80 lines of diff in total):
  1. `silicaflux_pkg.sv` — `get_format` must return `FMT_D` for `0x18…0x1E` (otherwise the decoder treats them as R-format and the tile/addr fields are lost);
  2. `control_core.sv` — `is_sched_op` must include `0x18…0x1E` so they are dispatched to the scheduler;
  3. `silicaflux_top.sv` — a `GFX_TILE` parameter selects which slot holds `sfgx_gfx_tile` instead of `compute_tile`, plus the `fb_scan_*` display port.

  The patch applies cleanly to the vendored baseline and the patched cluster elaborates in Verilator. **It is exercised end to end by a program-level test:**
  a hand-assembled SilicaFlux program (`tools/mk_cluster_prog.py`: 293 instruction words — `MOV/MUL/ADD` to build constants, `GFXMEM` ×13, `GFXREG` ×3, `GFXCLEAR`, `GFXDRAW`, `DFSYNC`, `HALT`)
  runs through fetch → decoder → control core → scheduler → graphics tile, and the resulting framebuffer equals the reference model's **pixel for pixel (1024 / 1024)**
  (`tests/compare_cluster.py`). Only that one program was run in the full cluster; the rest of the verification is at the tile and scheduler boundary.

## 3. Why `GFXMEM` exists

In the baseline there is **no instruction that can fill a tile's scratchpad from a program**: scalar `LOAD/STORE` go to the control core's *own* memory controller, and `DFSTORE` carries its data on
`vector_data_in`, but a D-format instruction cannot name a vector register (the decoder leaves `vrs1 = 0`, so it always carries whatever `v0` holds), while V-format instructions get `imm = 0`
(no address). So a graphics program could not upload vertices with the existing instructions. `GFXMEM`
(`0x1D`, D-format: `addr14` = word, `rs1` = data) is a scratchpad *word write* that works with the baseline's own D-format decode. The 17-bit `MOV` immediate means 32-bit
constants must be built with `MUL`/`ADD` (the cluster test does this).

## 4. Defects and limitations found in the baseline (reported, not worked around silently)

These are properties of the *unmodified* v1.0 RTL, observed while integrating. None was changed.

1. **Scheduler can silently drop an instruction (`scheduler.sv`).** `instr_ready = !sync_stall && (tile_tok_ready || !tile_busy)` but `dispatch_ok` requires `!tile_busy && tile_tok_ready`.
   In the clock where a tile raises `tile_done`/`token_ready`, `tile_busy` is still set: `instr_ready` is 1 (the control core thinks the waiting instruction was accepted) while no token is dispatched.
   Reproduced: `GFXDRAW` issued right behind a long `GFXCLEAR` was lost, the program ran on to `HALT`, then looped. **Rule:** order work on one tile with `DFSYNC` (the baseline's documented idiom); the cluster test does.
2. **Scheduler write-back always targets `r0`.** `wb_reg <= '0`, so tile scalar results never reach a usable register; results are only visible on `tile_result_scalar`/`tile_done`.
   (`wb_*` also forwards only results that are non-zero and tile 0 wins.)
3. **`memory_controller` silently aliases addresses ≥ 256** (it uses `req_addr[9:2]`). SFGX range-checks before every access and reports `ADDR_ERR` instead.
4. **`memory_controller` burst reads/writes repeat the first four words** for `length > 4` (the word index is `burst_idx[1:0]`). SFGX relies only on single-word accesses.
5. **`compute_tile` returns stale data for stores** (`tile_result_scalar <= resp_rdata` unconditionally). The graphics tile defines store results as `0`.
6. **`halt` is asserted when `HALT` is *fetched*,** not retired, and fetch continues afterwards (the program counter runs on and wraps).
7. **Tool portability:** Yosys 0.33's built-in front-end cannot parse `import pkg::*;` in a module header (the baseline uses it); the synthesis check therefore uses the `slang` front-end.
   `memory_controller.sv` also leaves `burst_len_reg` without an asynchronous reset value (a Yosys-slang warning).

## 5. Memory map used by a draw (per tile scratchpad, 256 words)

```
 words [VTX_BASE … ]              vertex records, VTX_STRIDE words each (4: x y z colour | 6: + u v)
 words [TRI_BASE … TRI_BASE+N-1]  triangle words {2'b0, i2[9:0], i1[9:0], i0[9:0]}
```
A scene larger than the scratchpad is drawn in batches (rewrite the scratchpad, `GFXDRAW` again); the framebuffer and depth buffer persist between draws.
