# SFGX architecture

SFGX ("SilicaFlux Graphics eXtension") is a small, synthesizable, fixed-function triangle renderer packaged as a **SilicaFlux tile**.
It renders simple scenes (colour-interpolated and textured, depth-tested triangles) into a framebuffer held in the tile.
It is a rendering engine and nothing more: display output is a separate integration layer (`05_DISPLAY_INTEGRATION.md`), and it is
**not** a graphics-API implementation (`06_LIMITATIONS_AND_FUTURE.md`).

## 1. Where it sits in SilicaFlux

```
 control core ──(D-format instr.)──▶ dataflow scheduler ──(flat token fields, valid/ready)──▶ ┌────────────┐
                                           ▲                                                 │ sfgx_gfx_  │──▶ fb_scan_* (display read port)
                                           └────────(tile_done / tile_error / tile_result_*)─│ tile       │
                                                                                             └────────────┘
 tile slots 0..2 may stay unmodified compute_tile; the graphics tile occupies any one slot (default 3)
```

`sfgx_gfx_tile`'s **first 25 ports are identical in name, width and direction to `compute_tile` v1.0**, so the *unmodified* scheduler drives it
exactly like any other tile (`03_SILICAFLUX_INTEGRATION.md`). Its scratchpad is the *unmodified* `memory_controller`.

## 2. Pipeline

```
 GFXDRAW token
     │  for each triangle word (NUM_TRI of them)
     ▼
 ┌──────────────┐  3 × (index → 4/6 words)   ┌────────────┐
 │ VERTEX INPUT │ ◀── memory_controller ───▶ │ scratchpad │   256 × 32 bit, the base architecture's own
 │ sfgx_vertex  │   scalar-LOAD handshake    └────────────┘
 │ + MVP xform  │   16 MACs / vertex on one shared 32×32 multiplier, saturating Q16.16
 └──────┬───────┘
        ▼   3 clip-space vertices (x y z w | r g b | u v)
 ┌──────────────┐  Sutherland–Hodgman, 6 planes, exact 34-bit distances, Q0.32 parameter,
 │ CLIP         │  attrs interpolated in clip space (perspective-correct), then ÷w viewport
 │ sfgx_clip    │  (one sequential divider), fan triangulation → 0…7 screen-space triangles
 └──────┬───────┘
        ▼   screen-space triangle (X,Y 1/256 px | Z Q16.8 | rgb Q8.8 | s t q)
 ┌──────────────┐  area, cull, orientation, top-left edge rule, 8 (or 14) plane gradients by exact
 │ SETUP+RASTER │  division, bbox scan, depth test, [texture: 2 parallel dividers + texel fetch], write
 │ sfgx_raster  │
 └──────┬───────┘
        ▼   pixel write (colour 32 b + depth 16 b)
 ┌──────────────┐  colour/depth RAM, clear engine; port A = raster/clear/read-back,
 │ FRAMEBUFFER  │  port B = display read port (registered, 1 clock latency)
 │ sfgx_fb      │  + sfgx_tex (4096 × RGB888 texture RAM)
 └──────────────┘
```

The stages run **one primitive at a time** (vertex → clip → raster of every fan triangle → next primitive). There is no inter-triangle
pipelining, no vertex cache and no parallel pixels. That keeps every FSM small and every hazard trivially absent; it is also why
throughput is modest (below).

### Modules

| File | Role | Notes |
|---|---|---|
| `sfgx_pkg.sv` | opcodes, register map, widths, flat vertex layouts | imports the *unmodified* `silicaflux_pkg` |
| `sfgx_divu.sv` | sequential restoring divider, 1 bit/clock | parameterised `NW`/`DW`; used by clip (66/35), setup (80/40) and the sampler (2 × 48/40) |
| `sfgx_vertex.sv` | vertex input + restricted MVP transform | scratchpad access only through the documented LOAD handshake |
| `sfgx_clip.sv` | clipper + viewport + fan emission | two 9-entry polygon buffers (ping-pong) |
| `sfgx_raster.sv` | setup + rasteriser + depth test + texture sampler | 1 clock per uncovered pixel, 2 per covered |
| `sfgx_tex.sv` | texture RAM | write port = `GFXTEX`, read port = sampler |
| `sfgx_fb.sv` | colour + depth RAM, clear engine | read-first synchronous ports, BRAM-inferrable |
| `sfgx_gfx_tile.sv` | token FSM, register file, statistics, `memory_controller` instance | drop-in for `compute_tile` |

## 3. Token set and registers

The graphics tile accepts, through the standard token interface:

* **inherited, on the scratchpad:** `OP_LOAD`, `OP_STORE`, `OP_VLOAD`, `OP_VSTORE`, `OP_DFLOAD`, `OP_DFSTORE`, `OP_DFSYNC` (completes immediately).
  Loads return data (`VLOAD`/`DFLOAD` return word 0 in `tile_result_scalar`); **stores return 0** (the base `compute_tile` leaks the previous read's stale data here).
* **graphics, in the opcode range the README reserves for application-specific kernels (`0x18`–`0x1E`), all D-format:**

| opcode | mnemonic | fields | effect |
|---|---|---|---|
| `0x18` | `GFXREG` | `addr14` = register, scalar = value | write a register (below) |
| `0x19` | `GFXDRAW` | – | draw `NUM_TRI` triangles; result = pixels written |
| `0x1A` | `GFXCLEAR` | `len[0]` colour, `len[1]` depth; scalar = colour | fill colour and/or depth (`CLEAR_DEPTH`) |
| `0x1B` | `GFXRD` | scalar = `{y[15:0], x[15:0]}`, `addr14` 0 = colour / 1 = depth | read one pixel into `tile_result_scalar` |
| `0x1C` | `GFXSTAT` | `addr14` = counter index | read a counter / flag |
| `0x1D` | `GFXMEM` | `addr14` = word, scalar = data | scratchpad word write (reachable from a real instruction stream, see `03_…`) |
| `0x1E` | `GFXTEX` | `addr14` = texel, scalar = `0x00RRGGBB` | texture memory write |

Everything else (vector/tensor kernels, reserved opcodes) completes with `tile_error` and the sticky `BAD_TOKEN` flag; NoC input is accepted and dropped, NoC output is never driven.

Registers (`GFXREG`): `0x00…0x0F` MVP matrix (Q16.16, row-major) · `0x10` `CTRL` · `0x11` `VTX_BASE` · `0x12` `TRI_BASE` · `0x13` `NUM_TRI` · `0x14` `CLEAR_DEPTH` ·
`0x15` `VTX_STRIDE` (4…64) · `0x16` `TEX_CTRL` (`[3:0]` log2 W, `[7:4]` log2 H, each ≤ 6) · `0x1F` clear statistics.
`CTRL`: bit0 `ZTEST`, bit1 `ZWRITE`, `[4:2]` `ZFUNC`, `[6:5]` `CULL`, bit7 `FRONT_CW`, bit8 `TEX_EN`, bit9 `TEX_MOD`(ulate), bit10 `TEX_CLAMP`. Reset: identity matrix, `ZTEST|ZWRITE|LESS`, no culling.

## 4. Performance (measured in simulation; `tools/bench.py`)

| item | measured |
|---|---|
| fixed cost per untextured triangle (vertex fetch, MVP, clip, viewport, setup, 8 gradient divides) | **≈ 1 570 clocks** |
| per covered pixel / per uncovered bounding-box pixel | **2 / 1 clock** |
| fixed cost per textured triangle (adds 6 more gradient divides) | ≈ 2 300 clocks |
| per **textured** covered pixel (two parallel 48-bit divisions + texel fetch) | **≈ 55 clocks** |
| `GFXCLEAR` of 160×120 | 19 200 clocks (1 word/clock) |

At 100 MHz that is about 60 k triangles/s and ~30 M untextured pixels/s but only ~1.8 M textured pixels/s. A 160×120 frame of the two-cube-plus-ground demo takes ≈ 103 k clocks untextured and ≈ 289 k clocks textured
(measured: total simulated clocks minus the 19 200-clock capture read per frame, divided by 36 frames). This is a *simple-scene* engine, sized for clarity and verification rather than speed.

## 5. Implementation results (Yosys 0.71 + `read_slang`, Xilinx 7-series mapping, 160×120)

`check -assert`: **0 problems**. Mapped: **≈ 23.8 k LUTs, ≈ 14.5 k flip-flops, 76 DSP48E1, 28 RAMB36E1, 88 RAM64M, 1 413 CARRY4**
(`results/synth/xilinx_160x120.log`; 32×32 generic synthesis also passes). The big register count comes from the two 9-entry polygon buffers, the 7×64-bit
plane accumulators/gradients and the 64-bit multipliers.

**Timing is not closed and was not analysed**: several wide products (64×26-bit plane start values, 68-bit intersection products, the 32×32 transform multiplier)
are single-cycle behavioural multiplies; reaching 100 MHz on an Artix-7 would require pipelining them or declaring multicycle paths. Treat the Fmax of the base
architecture's README (80–110 MHz) as *not* applying to this tile. No place-and-route or hardware run was performed.
