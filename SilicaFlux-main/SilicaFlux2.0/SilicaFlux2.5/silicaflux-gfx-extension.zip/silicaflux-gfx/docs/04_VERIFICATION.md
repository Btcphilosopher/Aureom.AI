# Verification report

Everything below was produced by the scripts in this package and is reproducible with `tests/run_all.sh` (and the separately listed long-running or tool-dependent runs).
Raw logs are in `results/`. **Read §9 (what is not verified) before relying on any of this.**

## 1. Strategy: four independent layers

| layer | question it answers | tool |
|---|---|---|
| **A. RTL ≡ bit-accurate reference** | does the SystemVerilog implement the specification exactly? | Verilator replay of the *same command file* as the Python reference; exact comparison |
| **B. the specification itself** | is the specification right (maths, edge rule, interpolation, texturing)? | exact-rational shared-edge oracle; independent float64 renderer; width-claim enforcement |
| **C. the test suite** | would A and B notice a wrong RTL? | mutation testing (58 injected faults), stimulus-coverage counters, negative controls |
| **D. integration** | does it work *inside SilicaFlux* and through to a display stream? | unmodified scheduler + compute tiles; patched full cluster; captured video frame |

The reference (`ref/sfgx_ref.py`) is plain Python integers, written from `02_NUMERIC_SPEC.md`, and shares no code with the RTL. The same `.cmd` file is replayed by both.

## 2. Layer A — RTL = reference, bit for bit

For every scene the following must be **identical**: each token's result and error flag (including all `GFXSTAT` counters and `GFXRD` reads); the **sequence of screen-space triangles entering setup**
(X, Y, Z, colour, s, t, q — i.e. the output of vertex transform + clip + viewport, which localises any fault to a stage); and, at every capture, the **colour buffer, the depth buffer and the per-pixel coverage counts**
(coverage is observed through a debug tap so that double hits are visible even when the depth test hides them). Result: **18 / 18 scenes pass.**

| scene | framebuffer | tokens | triangles into setup | captures | pixels compared (×colour, depth, coverage) |
|---|---|---|---|---|---|
| shared_edges | 32x32 | 136 | 38 | 3 | 3072 |
| clip_cases | 32x32 | 2158 | 100 | 77 | 78848 |
| cull_depth | 32x32 | 413 | 38 | 15 | 15360 |
| errors | 32x32 | 86 | 6 | 5 | 5120 |
| demo_triangle | 160x120 | 696 | 24 | 24 | 460800 |
| demo_scene | 160x120 | 4140 | 1052 | 36 | 691200 |
| random_screen_s1 | 40x30 | 2423 | 834 | 4 | 4800 |
| random_screen_s2 | 37x23 | 2390 | 815 | 4 | 3404 |
| random_screen_s3 | 64x48 | 2385 | 828 | 4 | 12288 |
| random_screen_s4 | 21x17 | 2410 | 763 | 4 | 1428 |
| random_persp_s1 | 48x36 | 2366 | 424 | 1 | 1728 |
| random_persp_s2 | 33x45 | 2366 | 505 | 1 | 1485 |
| random_persp_s3 | 100x75 | 2366 | 499 | 1 | 7500 |
| big_fb | 640x480 | 338 | 96 | 1 | 307200 |
| texture | 64x64 | 5364 | 38 | 17 | 69632 |
| random_tex_s1 | 48x36 | 17160 | 476 | 9 | 15552 |
| random_tex_s2 | 31x29 | 13128 | 489 | 9 | 8091 |
| demo_textured | 160x120 | 9809 | 1053 | 36 | 691200 |

Scene content: `shared_edges` (quads on both diagonals and both windings with edges exactly through pixel centres, half-pixel-aligned quads, fans around corner/centre hubs, strips, an irregular 1/256-px mesh) ·
`clip_cases` (every plane with a vertex *on / just inside / just outside / straddling / fully outside*, an edge lying in a plane, a vertex on a plane with the other two outside, a screen-covering triangle, near/far/behind-the-eye perspective cases, `w = 0`, transform saturation,
six cases whose rounded post-clip plane distance is −1 LSB) · `cull_depth` (all cull × winding combinations, all 8 depth functions, depth-write off) · `errors` (every range check and bad token, `GFXCLEAR` flag variants, `LOAD/VLOAD` round trips) ·
`random_screen_*` / `random_persp_*` / `random_tex_*` (random triangles, matrices, state; 4 + 3 + 2 seeds at odd sizes) · `big_fb` (640×480: address and coordinate widths) · `texture` (17 directed cases) · the three demos.

**Stimulus coverage** (`tests/stimulus_coverage.py`, `results/stimulus_coverage.txt`; counted on the reference over all scenes except `big_fb`): clipper intersections in both directions on all six planes (e.g. 1339 on plane 0 … 300 on plane 5);
80 vertices exactly on a plane; 19 + 19 suppressed-intersection cases; final polygon sizes
0:879  1:6  2:8  3:3528  4:1218  5:543  6:86  7:8  8:1 (9 is unreachable — a plane section of a cube has ≤ 6 corners — so a simulation assertion guards the buffer);
25 degenerate triangles; both windings, top edges (878), horizontal edges (1931) and left edges (10974).

## 3. Layer B — checking the specification

**B1. Shared edges are covered exactly once** (`tests/check_properties.py`). Oracle independent of the rasteriser's edge functions: every pixel centre is classified strictly-inside / on-boundary / outside *each triangle* with `fractions.Fraction`,
and whether a boundary pixel is *interior to the union* is decided by 32 exact probe points at 2⁻²⁰ px. Required: strictly inside one triangle → covered once; outside → 0; on a shared edge/vertex interior to the mesh → **exactly once**; outer boundary → at most once.

```
shared_quads   interior-pixels= 224 outside= 768 shared-edge/vertex-pixels= 32 outer-boundary=  0 violations=0
shared_fans    interior-pixels= 212 outside= 687 shared-edge/vertex-pixels= 65 outer-boundary= 60 violations=0
shared_misc    interior-pixels= 192 outside= 775 shared-edge/vertex-pixels=  9 outer-boundary= 48 violations=0
```
The test has teeth: rasteriser mutants *inclusive everywhere* (double coverage; 116 violations), *exclusive everywhere* (gaps; 106 violations) and *horizontal-edge clause dropped* (11 violations) are rejected. A *bottom-right* rule (also watertight) correctly **passes**:
the property cannot select the convention — that is pinned by the exact-match reference and by the float model below. (A first version of this test could not see its own target because its probe directions were parallel to the diagonals; found and fixed.)

**B2. Fixed-point specification vs an independent float64 renderer** (`ref/sfgx_float_ref.py`, `tests/check_float.py`). The float model re-implements transform, clipping, viewport, coverage, interpolation and perspective-correct texturing in real arithmetic, sharing only the command parser.
It is *not* expected to match bit for bit; every differing pixel must be explained by one of: within 0.02 px of a triangle edge (quantisation); ≤ 1 LSB (rounding); a depth near-tie ≤ 6 LSB (a legitimately flipping winner along a surface intersection);
or within the texel-boundary window **scaled by the local texture magnification** (one 1/256-px grid step moves a sample by gradient/256 texels). Float vertices are snapped to the *specified* 1/256-px grid so the comparison isolates the arithmetic, not the grid.

| scene | captures | pixels | differing | near an edge | ≤ 1 LSB | depth near-tie | texel boundary | **unexplained** |
|---|---|---|---|---|---|---|---|---|
| shared_edges | 3 | 3072 | 10 | 4 | 6 | 0 | 0 | **0** |
| clip_cases | 77 | 77824 | 47 | 3 | 44 | 0 | 0 | **0** |
| cull_depth | 15 | 15360 | 0 | 0 | 0 | 0 | 0 | **0** |
| demo_triangle | 24 | 460800 | 2 | 0 | 2 | 0 | 0 | **0** |
| demo_scene | 36 | 691200 | 428 | 32 | 396 | 0 | 0 | **0** |
| random_screen_s1 | 4 | 4800 | 6 | 2 | 4 | 0 | 0 | **0** |
| random_screen_s2 | 4 | 3404 | 10 | 2 | 8 | 0 | 0 | **0** |
| random_screen_s3 | 4 | 12288 | 75 | 13 | 62 | 0 | 0 | **0** |
| random_screen_s4 | 4 | 1428 | 2 | 2 | 0 | 0 | 0 | **0** |
| random_persp_s1 | 1 | 1728 | 7 | 1 | 6 | 0 | 0 | **0** |
| random_persp_s2 | 1 | 1485 | 5 | 1 | 4 | 0 | 0 | **0** |
| random_persp_s3 | 1 | 7500 | 33 | 9 | 24 | 0 | 0 | **0** |
| texture | 17 | 69632 | 497 | 9 | 48 | 0 | 440 | **0** |
| random_tex_s1 | 9 | 15552 | 41 | 5 | 36 | 0 | 0 | **0** |
| random_tex_s2 | 9 | 8091 | 10 | 0 | 2 | 0 | 8 | **0** |
| demo_textured | 36 | 691200 | 254 | 12 | 237 | 0 | 5 | **0** |

The check is able to fail on texture maths: mutating the *reference's* sampler to **affine** interpolation, **round-to-nearest instead of floor**, or the **wrong axis shift** is rejected on three scenes each. Mutating only the `+127` rounding term of `MODULATE` is *not*
rejected (the ≤ 1 LSB tolerance cannot see rounding modes) — those are pinned by the specification and layer A, not independently.

**B3. Every width in the spec is enforced, not argued** (`tests/check_bounds.py`). `_chk()` assertions in the reference raise if any claimed width is exceeded; all scenes plus 2048×2048 worst-case corner triangles and extreme Q16.16 operands pass.
Largest bit-lengths observed (limit): area2 **39** (39 — tight: a full-screen corner triangle at 2048²), edge-function start value 38 (47), clip plane distance 31 (33), `t` 32 (32, i.e. `< 2³²`), gradient numerator 43 / 53 (47 / 61), shifted numerator 65 (72),
viewport numerator 46 (56), transform accumulator 64 at extreme operands (67), texture `S,T` 39 (42), `Q` 39 (40).

**B4. The output clamps are unreachable**, as the spec claims: 0 activations over all scenes and over adversarial slivers and extreme attribute values on a 2048×2048 framebuffer (11.5 M covered pixels in the shipped run; a 250-triangle run covered 23 M). They are kept as defence in depth.

## 4. Layer C — does the suite catch wrong RTL? Mutation testing

58 one-line faults were injected into copies of the RTL (`tests/mutation_test.py`; each is built with Verilator and run against 8 scenes). A mutant is *killed* if any scene differs from the reference (or the model fails to build/hangs).
**55 of 58 killed.** The final full campaign killed 54; the remaining survivors were analysed, one real test gap (X11) was closed with a directed test and re-run (killed), leaving three **equivalent** survivors:

* **R15, R16** — the colour and depth output clamps: unreachable for a covered pixel (§B4), so removing them changes nothing observable.
* **X7** — the `q ≤ 0 → 1` divisor guard in the sampler: unreachable because every vertex `q = 2⁴⁰/w ≥ 512` and an interpolated value is a convex combination of vertex values.

| id | injected fault | outcome | first scene that caught it |
|---|---|---|---|
| C1 | duplicate vertex when d_P == 0 | KILLED | clip_cases |
| C2 | duplicate vertex when d_Q == 0 | KILLED | clip_cases |
| C3 | intersection rounding removed | KILLED | clip_cases |
| C4 | far plane tested like the near plane | KILLED | clip_cases |
| C5 | viewport divide truncates | KILLED | clip_cases |
| C6 | w == 0 vertex accepted | KILLED | clip_cases |
| C7 | window Y not flipped | KILLED | shared_edges |
| C8 | negative lower clamp removed | KILLED | clip_cases |
| C9 | intersection parameter t halved | KILLED | clip_cases |
| C10 | fan winding reversed | KILLED | shared_edges |
| C11 | clipped statistic never counted | KILLED | errors |
| C12 | 2-vertex polygon accepted | KILLED | clip_cases |
| C13 | empty polygon not rejected early | KILLED | [0] |
| C14 | plane 2 distance sign wrong | KILLED | clip_cases |
| F1 | depth clear value ignored | KILLED | errors |
| R1 | edges inclusive everywhere (double coverage on shared edges) | KILLED | shared_edges |
| R2 | edges exclusive everywhere (gaps on shared edges) | KILLED | shared_edges |
| R3 | top edge test inverted (still watertight, differs from spec) | KILLED | shared_edges |
| R4 | left-edge ownership dropped | KILLED | shared_edges |
| R5 | red channel rounding constant wrong | KILLED | shared_edges |
| R6 | depth LESS behaves like LEQUAL | KILLED | cull_depth |
| R7 | back/front culling swapped | KILLED | cull_depth |
| R8 | bounding box skips first column | KILLED | shared_edges |
| R9 | gradient rounding removed (truncation) | KILLED | shared_edges |
| R10 | row step of the edge function wrong | KILLED | shared_edges |
| R11 | depth-write enable ignored | KILLED | shared_edges |
| R12 | orientation normalisation inverted | KILLED | shared_edges |
| R13 | front-face winding inverted | KILLED | cull_depth |
| R14 | gY term dropped from plane equation start value | KILLED | shared_edges |
| R15 | depth clamp removed | survived | — |
| R16 | colour clamp removed | survived | — |
| T1 | cull counter never counts | KILLED | random_screen_s1 |
| T2 | GFXCLEAR depth flag mis-decoded | KILLED | errors |
| T3 | pixel read-back y bound off by one | KILLED | errors |
| T4 | scalar scratchpad bound off by one | KILLED | errors |
| T5 | overflow flag never set | KILLED | clip_cases |
| V1 | saturation replaced by wrap | KILLED | clip_cases |
| V2 | transform rounding removed | KILLED | clip_cases |
| V3 | second index field misaligned | KILLED | shared_edges |
| V4 | red/green colour mapping wrong | KILLED | shared_edges |
| V5 | vertex address check off by one | KILLED | errors |
| V6 | triangle-word address check off by one | KILLED | errors |
| X1 | texture accumulators not advanced along x (a bug made during development) | KILLED | texture |
| X2 | texel row stride uses height instead of width | KILLED | texture |
| X3 | modulate rounding term removed (red) | KILLED | texture |
| X4 | REPEAT and CLAMP swapped | KILLED | texture |
| X5 | floor of negative quotients becomes truncation | KILLED | texture |
| X6 | q gradient never computed | KILLED | texture |
| X7 | non-positive q guard changed (only matters for q<=0) | survived | — |
| X8 | s rounding removed | KILLED | texture |
| X9 | s = u*q rounding removed | KILLED | texture |
| X10 | u,v not interpolated on clipped edges | KILLED | texture |
| X11 | q saturation removed (matters only for w < 2^-15) | KILLED (after adding a directed test) | texture |
| X12 | u,v never fetched | KILLED | texture |
| X13 | vertex stride register ignored in address computation | KILLED | texture |
| X14 | GFXTEX bound off by one | KILLED | texture |
| X15 | TEX_CTRL accepts log2 width 7 | KILLED | texture |
| X16 | VTX_STRIDE accepts 3 | KILLED | texture |

Earlier rounds of the same campaign exposed *real* test gaps that were then closed: a clip-viewport lower clamp (C8) that no input ever exercised (six inputs producing a rounded post-clip distance of −1 LSB were found by random search and added), a triangle-word bound
off by one (V6) hidden because the aliased word happened to fail anyway (the error scene was restructured so aliasing would draw visible triangles), and the `q` saturation (X11, a vertex with `w = 1 LSB`).

## 5. Layer D — integration

| test | what it shows | result |
|---|---|---|
| `tests/compare_sched.py` — **unmodified `scheduler.sv`** + 3 unmodified `compute_tile` + graphics tile in slot 3 | the documented token/completion/`DFSYNC` contract; frames bit-exact vs reference | 5 scenes pass (plain) |
| same, `interleave` | a real **`VADD` on a compute tile runs correctly while the graphics tile draws**, and `DFSYNC` asserts `sync_stall` behind it; frames still bit-exact | `cull_depth`: VADD correct 32/32, overlapped a running draw 15×, barrier held 32/32; `texture`: 18/18, overlapped 17×, barrier held 18/18 |
| `tests/compare_cluster.py` — **patched full cluster**, hand-assembled program | `imem → fetch → decoder → control core → scheduler → graphics tile → framebuffer` | 293 instruction words, halt after 3 608 clocks, **framebuffer == reference, 1024/1024 px** |
| `tests/compare_display.py` — token ROM → engine → scan-out → **captured video frame** | the display path, separate from the engine | **307 200/307 200 px** == reference ×4; frame 420 000 clocks (800×525), 96-clock hsync, 1 600-clock vsync, 307 200 DE px, 480 lines. Negative control (latency mis-set) rejected (13 444 px differ) |

## 6. Static checks and synthesis

* **Verilator 5.020 `--lint-only -Wall`: 0 warnings** on the SFGX RTL together with the unmodified `memory_controller` (`sim/lint.sh`). Waivers (`rtl/sfgx_lint.vlt`) are per named signal, each with a reason (intentionally truncated wide intermediates; unused bits of the `compute_tile`-compatible input ports); nothing is waived file-wide for SFGX code.
* **Yosys 0.71 + `read_slang`** elaborates the whole design *including the unmodified baseline package and header imports*; `check -assert`: **0 problems** (generic 32×32 and Xilinx-7 mapping at 160×120).
  Xilinx-7 mapping: ≈ 23.8 k LUTs, ≈ 14.5 k FFs, 76 DSP48E1, 28 RAMB36E1, 88 RAM64M, 1 413 CARRY4 (`results/synth/`). Yosys 0.33's built-in front-end could not parse the baseline's `import pkg::*;` headers (not an SFGX issue).
* A simulation-only `initial` block in memories and two `ifndef SYNTHESIS` assertions are the only simulation-only constructs.

## 7. Defects found *by* the verification (and what they teach)

| found by | defect | fix |
|---|---|---|
| code review before lint | `E_i ≥ bias` mixed a signed register with an *unsigned* cast ⇒ Verilog would have compared unsigned (every negative edge value "covered") | compare through the sign bit of an explicitly signed difference |
| Verilator | `cover` is a reserved word | renamed |
| property test self-check | probe directions parallel to pixel-aligned diagonals ⇒ the test could not see shared-edge pixels | generic probe angles |
| float cross-check | colour scaled as Q8.8 in a float model that used 0…255 | fixed in the *checker* |
| RTL-vs-reference | vertex address still `base + 4·index` after adding a stride register | `base + index·stride` |
| RTL-vs-reference | texture accumulators not advanced along the scanline (loop bound left at 4 when attributes grew to 7) | loop bound 7; also now a mutant (X1) |
| visual inspection | **3-D demo: ground plane missing** — camera pitch sign wrong, so the plane was (correctly) back-face culled; RTL and reference *agreed* | scene fixed. Bit-exact agreement does not prove a scene looks right |
| scheduler-level run | stale Verilator binary silently testing old RTL | scripts rebuild when any source is newer than the binary |
| full-cluster run | **baseline scheduler drops an instruction** that waits on a tile finishing that cycle | documented (`03_…` §4); program uses `DFSYNC` as the baseline idiom |

## 8. Reproduce

```bash
tests/run_all.sh                                   # lint, B1–B4, A, scheduler-level, display, cluster   (≈ 3 min)
python3 tests/mutation_test.py --jobs 2            # layer C                                              (≈ 15–60 min)
YOSYS=yowasp-yosys sim/synth_check.sh xilinx 160 120   # synthesis (needs a Yosys with read_slang)         (≈ 3 min)
python3 tools/bench.py                             # performance numbers
```

## 9. What is **not** verified

* No physical hardware: no bitstream, no place-and-route, **no timing closure**, no real display.
* No formal proof; simulation, mutation, exact-arithmetic and cross-model evidence only.
* **Common-mode risk:** the reference and the RTL were written by the same author from the same specification. A specification mistake would be shared. Mitigations (B1, B2, visual review, mutation) reduce but do not remove this; B2 cannot see rounding *modes*.
* One program was run in the full cluster; everything else is verified at the tile / scheduler boundary.
* The mutation set is 58 hand-chosen faults, not an exhaustive fault model; the three survivors are argued, not proven, equivalent (their reachability argument rests on the invariants above, and B4's measurements).
* Scenes are small (≤ 640×480, ≤ 17 captures each for directed tests); performance on large workloads was not studied.
