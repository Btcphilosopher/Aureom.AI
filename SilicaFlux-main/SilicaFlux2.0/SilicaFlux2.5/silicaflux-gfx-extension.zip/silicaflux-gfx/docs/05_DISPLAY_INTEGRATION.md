# Display integration (separate from the rendering engine)

The rendering engine ends at a **framebuffer read port**. Turning that into photons is *integration*, it is board-specific, and it is deliberately kept out of `rtl/`.

```
           ENGINE  (rtl/, verified bit-exact)                │        DISPLAY INTEGRATION  (integration/display/, simulated)
 tokens ─▶ sfgx_gfx_tile ──▶ colour RAM ── port B ─────────────┼─▶ sfgx_scanout ──▶ hsync, vsync, de, r[7:0] g[7:0] b[7:0]
           (draws into the frame buffer)    fb_scan_addr / _data│   (timing + 4× pixel replication)        │
                                                                │                                         ▼
                                                                │                         board-specific:  resistor DAC / VGA Pmod,
                                                                │                         TMDS serializer IP, HDMI transmitter chip …
```

## 1. The boundary: the engine's framebuffer interface

| Signal | Direction | Meaning |
|---|---|---|
| `fb_scan_addr[AW-1:0]` | in | pixel address `y·FB_W + x` (row 0 = top) |
| `fb_scan_data[31:0]` | out | `{8'h00, R8, G8, B8}`, **registered: valid one clock after the address** |
| `gfx_busy` | out | a token is executing (draw / clear / …) |

That is all the display side may rely on. Colour format is fixed 24-bit RGB; there is no alpha and no packed/565 mode.

## 2. What was built and verified here

`integration/display/` contains three modules; none of them is part of the engine:

* **`sfgx_scanout.sv`** — a video timing generator and framebuffer reader. Integer pixel replication (`SCALE`) of `FB_W×FB_H` into the active area, programmable VGA-style timing
  (default **640×480@60: 800×525 total, 96-clock hsync, 2-line vsync, both active-low**, 25.175 MHz nominal), `pix_ce` clock enable, `de`, one-clock `frame_start`/`line_start`.
* **`sfgx_cmd_rom.sv`** — replays a ROM of graphics tokens (stand-in for the SilicaFlux control core, so the display demo needs no CPU program).
* **`sfgx_display_demo_top.sv`** — `cmd_rom → sfgx_gfx_tile → scanout`.

**End-to-end simulated test** (`tests/compare_display.py`, Verilator): the rotating-triangle scene's first frame is rendered through the token ROM and the engine, and **one complete video frame is
captured from the pixel stream** (`de`, `r`, `g`, `b`). It must equal the software reference's framebuffer replicated 4×4 **and** meet the timing:

```
[PASS] display path (demo_triangle, 160x120 -> 640x480): 29 ROM tokens, render 30876 clocks; video frame == reference framebuffer x4 (307200/307200 px);
       frame 420000 clocks, 307200 DE px, 480 lines, hsync 96 clk, vsync 1600 clk
```

The frame is not trivial (52 544 non-background pixels, 3 285 distinct colours), and a negative control (scan-out latency mis-set by one pixel) is detected (13 444 pixels differ).

### What this does *not* show
* **Nothing here has driven a physical display.** There are no pin constraints, no PLL, no serializer and no encoder; no board was used.
* The scan-out is **single-clock**: `pix_ce` is a clock *enable*. A real pixel clock is normally a separate PLL output (see §4).
* The engine renders into the **same buffer it scans out**, so a draw during active video shows tearing unless the whole clear + draw happens to fit in the vertical blank (45 lines = 36 000 clocks at one pixel per clock: the simple triangle frame needs 30 876, the cube scene ≈ 103 000, a textured one ≈ 289 000). The simulated test compares a static, finished frame.

## 3. Using a documented board interface or established controller IP

Choose by what the board provides; none of the following was run, so treat the names as pointers to vendor documentation, not as verified recipes:

| Target | Documented path | What you supply |
|---|---|---|
| Board with a **VGA connector** (resistor-ladder DAC, e.g. the Digilent Nexys family) | drive the board's `VGA_R/G/B[3:0]`, `VGA_HS`, `VGA_VS` pins from `r,g,b[7:4]`, `hsync`, `vsync` | pin locations **from the board's master XDC** (none are invented here) |
| Digilent Arty A7-100T (the SilicaFlux README's Vivado target, **no video connector**) | a **Digilent Pmod VGA** (12-bit) on two Pmod ports, same signals as above | Pmod pin assignment from the Arty master XDC |
| Boards with **DVI/HDMI** and a TMDS-capable FPGA | Digilent's open-source `rgb2dvi` IP (encodes RGB + syncs + pixel clock to TMDS) | a pixel clock from an MMCM/PLL (and its 5× serial clock) |
| Intel **DE10-Nano** (the README's Quartus target) | its HDMI transmitter is an external **ADV7513** that takes a 24-bit parallel RGB + `HS/VS/DE` + pixel clock bus and must be configured over I²C | the vendor's reference design for the I²C register setup (not reproduced here) |
| Anything with external DDR | AMD/Xilinx **AXI VDMA** + **Video Timing Controller** + **AXI4-Stream to Video Out**, or Intel **Frame Buffer II** + **Clocked Video Output** | a frame-copy path from the engine's framebuffer into DDR (see §4) |

## 4. Crossing from the engine clock to a pixel clock

`fb_scan_*` is clocked by the engine clock, a pixel clock is usually different. Two sound options:

1. **True-dual-port BRAM with independent clocks.** `sfgx_fb` is written so port B (colour read) maps to a read-only BRAM port; to give it its own clock add a `fb_scan_clk` input to `sfgx_fb`
   (a mechanical change — not made here, to keep the verified engine untouched) and run `sfgx_scanout` with `pix_ce = 1` on the pixel clock (`LAT = 2`).
2. **Copy the finished frame into external memory** (DMA / VDMA) and let a standard video-output IP scan it out. This is also the way to **double-buffer** and remove tearing: render into buffer *A* while buffer *B* is displayed, swap on `frame_start`.

Either way the engine's contract is unchanged; only the integration layer differs.
