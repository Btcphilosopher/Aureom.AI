# Limitations, non-goals and future work

## 1. This is not a graphics API implementation

**SFGX is a fixed-function triangle renderer. It is not an OpenGL, OpenGL ES, Vulkan, Direct3D or Metal implementation, it does not claim conformance
to any of them, and it must not be labelled as one.** Several conventions deliberately resemble OpenGL's (clip volume `−w…w`, top-left fill rule, OpenGL depth-function numbering)
because they are familiar and well understood, not because the behaviour is conformant. A conformant implementation would need, at the very least:

| Required by a real API | SFGX |
|---|---|
| programmable vertex / fragment stages (shaders), a shader ISA and compiler (SPIR-V / GLSL) | none — one 4×4 matrix, colour passthrough, fixed texture modulate |
| floating-point (IEEE-754) vertex and attribute math, defined precision rules | fixed-point Q16.16 with saturation; no NaN/Inf, no float formats |
| full attribute set, interpolation qualifiers (flat / noperspective), varyings | colour is screen-space-affine only; UV perspective-correct; no flat shading, no extra varyings |
| blending, logic ops, stencil, alpha test, multisampling, scissor, multiple viewports, user clip planes | none; depth test only |
| index/instance/primitive types (strips, fans, lines, points, adjacency), primitive restart | triangle list from a 10-bit-indexed scratchpad batch only |
| texture formats, mipmaps, bilinear/trilinear/anisotropic filtering, cube/3D/array textures, LOD, border colours | one 2D RGB888 texture ≤ 64×64, nearest, REPEAT/CLAMP |
| render targets of many formats, depth ≥ 24 bit, framebuffer objects, readback of arbitrary formats | RGB888 + Z16, one buffer |
| a driver / memory model / synchronisation (fences, barriers, queues, descriptors) | token interface + `DFSYNC` |
| conformance tests (OpenGL CTS, Vulkan CTS) | none run, none applicable |

## 2. Vulkan / OpenGL integration is a separate future project

If pursued, it is **its own project** that sits *above* an engine such as this one, not an extension of it:

1. a hardware/driver contract (the draft `silicaflux-sfg1-driver` document is an unratified starting point, not a spec);
2. a shader model and compiler, or an explicit decision to expose only a fixed-function subset (e.g. a very restricted OpenGL ES 1.x-class or a software-assisted layer);
3. the engine features in the table above that the chosen API subset requires (at minimum: float attributes, blending, ≥ 24-bit depth, mipmapped bilinear textures, scissor/viewport state);
4. a driver stack (Mesa-style) and the relevant conformance suite as the acceptance criterion.

None of that is started here, and no part of this repository should be cited as evidence of API support.

## 3. Engine limitations (deliberate or inherited)

* **Throughput:** one primitive at a time, no pipelining between stages, one pixel per ~2 clocks (≈ 55 when textured); see `01_ARCHITECTURE.md`.
* **Depth is 16-bit**, hyperbolic in eye space: expect z-fighting on coplanar or distant geometry.
* **Colour is not perspective-corrected** (texture coordinates are). Gouraud-shaded large triangles viewed obliquely will show the usual affine artefact.
* **Texturing:** nearest sampling only, no mipmaps ⇒ visible aliasing under minification; one texture at a time; ≤ 64×64.
* **Scratchpad-bound scenes:** 256 words per tile; larger scenes are drawn in batches by the host.
* **No transparency, no blending, no scissor, no stencil, no wireframe/points/lines.**
* **Single tile, no NoC use:** NoC input is dropped and output is never driven; multi-tile rendering (tile-per-region) is future work.
* **The framebuffer is single-buffered** (tearing if scanned out while drawn; see `05_DISPLAY_INTEGRATION.md`).
* **Vertex positions snap to 1/256 pixel;** that is the engine's only geometric quantisation, and with extreme texture magnification (> ~100 texels/pixel) it is visible in sampled texel coordinates.

## 4. What has *not* been verified

* **No physical hardware.** No FPGA bitstream, no place-and-route, no timing closure (several wide single-cycle multiplies would need pipelining), no display.
* **No formal proof.** Evidence is simulation (bit-exact against a reference), mutation testing, exact-arithmetic property tests, a float cross-check and Yosys synthesis checks.
* **Common-mode risk.** The software reference and the RTL were written by the same author from the same specification, so a *specification* mistake would be shared by both.
  This is mitigated — not eliminated — by (a) the independent float64 reference, (b) the exact rational shared-edge oracle, (c) visual inspection of the rendered scenes (which found one real mistake in a *scene*, not in the pipeline), and
  (d) the mutation campaign. Rounding *modes* (e.g. the `+127` in `MODULATE`) are pinned by the specification and by RTL = reference, **not** independently by the float check, whose ≤ 1-LSB tolerance cannot see them.
* **Full-cluster coverage is one program.** A hand-assembled program was run through fetch → decode → control core → scheduler → graphics tile; the rest is verified at the tile and scheduler boundary.
* **Baseline defects** listed in `03_SILICAFLUX_INTEGRATION.md` §4 (notably the scheduler's dropped-instruction hazard) are inherited by any user of the unmodified scheduler.
