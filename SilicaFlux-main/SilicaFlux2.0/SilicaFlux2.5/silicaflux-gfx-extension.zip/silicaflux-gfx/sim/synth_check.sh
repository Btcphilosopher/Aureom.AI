#!/bin/bash
# Yosys synthesizability check of the whole graphics tile (SFGX + the UNMODIFIED scratchpad memory_controller
# and the UNMODIFIED silicaflux_pkg).
#   sim/synth_check.sh generic|xilinx  [FB_W FB_H]
#
# Needs a Yosys with the `read_slang` SystemVerilog front-end:  pip install yowasp-yosys   (Yosys >= 0.50)
# or Yosys + the yosys-slang plugin.  Yosys 0.33's built-in read_verilog cannot parse `import pkg::*;` in a
# module header, which the baseline SilicaFlux RTL itself uses - so the check uses slang instead of rewriting
# anything.  Override the binary with YOSYS=/path/to/yosys.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
MODE=${1:-generic}; W=${2:-160}; H=${3:-120}
YOSYS=${YOSYS:-yowasp-yosys}
mkdir -p results/synth
FILES="rtl/sfgx_pkg.sv rtl/sfgx_divu.sv rtl/sfgx_vertex.sv rtl/sfgx_clip.sv rtl/sfgx_raster.sv rtl/sfgx_tex.sv rtl/sfgx_fb.sv third_party/silicaflux_v1_0/memory_controller.sv rtl/sfgx_gfx_tile.sv"
READ="read_slang -j 1 --single-unit -I third_party/silicaflux_v1_0 -I rtl $FILES --top sfgx_gfx_tile -G FB_W=$W -G FB_H=$H -D SYNTHESIS"
case "$MODE" in
  generic) FLOW="hierarchy -check -top sfgx_gfx_tile; proc; flatten; opt_clean; check -assert; stat" ;;
  xilinx)  FLOW="hierarchy -check -top sfgx_gfx_tile; synth_xilinx -family xc7 -top sfgx_gfx_tile -flatten; check -assert; stat" ;;
  *) echo "mode must be generic|xilinx"; exit 2 ;;
esac
$YOSYS -l results/synth/${MODE}_${W}x${H}.log -p "$READ; $FLOW" > /dev/null
echo "== $MODE synthesis ${W}x${H}: OK (check -assert passed)"
awk '/Printing statistics/{f=1} f' results/synth/${MODE}_${W}x${H}.log | grep -vE "^$" | tail -${TAIL:-45}
