#!/bin/bash
# Build the Verilator model + harness for one framebuffer size:   sim/build.sh W H
# Environment (used by the mutation test): SFGX_RTL_DIR (default rtl), SFGX_OBJ_ROOT (default sim)
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
W=${1:-160}; H=${2:-120}
RTL=${SFGX_RTL_DIR:-$ROOT/rtl}
OBJROOT=${SFGX_OBJ_ROOT:-$ROOT/sim}
SV=$ROOT/third_party/silicaflux_v1_0
OBJ=$OBJROOT/obj_${W}x${H}
mkdir -p "$OBJROOT"
verilator --cc --exe --build -j 4 -O2 --no-timing --public-flat-rw -Wno-fatal -Wno-DECLFILENAME \
  -I"$RTL" -I"$SV" "$RTL/sfgx_lint.vlt" \
  "$RTL/sfgx_pkg.sv" "$RTL/sfgx_divu.sv" "$RTL/sfgx_vertex.sv" "$RTL/sfgx_clip.sv" "$RTL/sfgx_raster.sv" "$RTL/sfgx_tex.sv" "$RTL/sfgx_fb.sv" \
  "$SV/memory_controller.sv" "$RTL/sfgx_gfx_tile.sv" --top-module sfgx_gfx_tile \
  -GFB_W=$W -GFB_H=$H -CFLAGS "-DFB_W=$W -DFB_H=$H" \
  "$ROOT/tb/sfgx_harness.cpp" -Mdir "$OBJ" -o sfgx_sim_${W}x${H} > "$OBJ.build.log" 2>&1 || { tail -30 "$OBJ.build.log"; exit 1; }
echo "built $OBJ/sfgx_sim_${W}x${H}"
