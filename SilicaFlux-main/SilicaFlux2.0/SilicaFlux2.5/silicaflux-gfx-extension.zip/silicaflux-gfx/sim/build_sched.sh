#!/bin/bash
# Build the scheduler-level integration model:  sim/build_sched.sh W H
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
W=${1:-32}; H=${2:-32}
RTL=${SFGX_RTL_DIR:-$ROOT/rtl}; SV=$ROOT/third_party/silicaflux_v1_0
OBJ=$ROOT/sim/sched_obj_${W}x${H}
verilator --cc --exe --build -j 4 -O2 --no-timing --public-flat-rw -Wno-fatal -Wno-DECLFILENAME \
  -I"$RTL" -I"$SV" "$RTL/sfgx_lint.vlt" \
  "$RTL/sfgx_pkg.sv" "$RTL/sfgx_divu.sv" "$RTL/sfgx_vertex.sv" "$RTL/sfgx_clip.sv" "$RTL/sfgx_raster.sv" "$RTL/sfgx_tex.sv" "$RTL/sfgx_fb.sv" \
  "$SV/memory_controller.sv" "$SV/vector_engine.sv" "$SV/tensor_unit.sv" "$SV/compute_tile.sv" "$SV/scheduler.sv" \
  "$RTL/sfgx_gfx_tile.sv" "$ROOT/tb/sfgx_sched_top.sv" --top-module sfgx_sched_top \
  -GFB_W=$W -GFB_H=$H -CFLAGS "-DFB_W=$W -DFB_H=$H" \
  "$ROOT/tb/sched_harness.cpp" -Mdir "$OBJ" -o sfgx_sched_${W}x${H} > "$OBJ.build.log" 2>&1 || { tail -40 "$OBJ.build.log"; exit 1; }
echo "built $OBJ/sfgx_sched_${W}x${H}"
