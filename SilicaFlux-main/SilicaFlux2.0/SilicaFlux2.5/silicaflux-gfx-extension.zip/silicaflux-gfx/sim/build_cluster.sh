#!/bin/bash
# Build the FULL SilicaFlux cluster with the graphics tile in slot 3:  sim/build_cluster.sh [W H]
# = vendored baseline v1.0 + integration/silicaflux_cluster_*.patch + SFGX RTL.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
W=${1:-32}; H=${2:-32}
B=$ROOT/sim/cluster_baseline; rm -rf "$B"; mkdir -p "$B/rtl"
cp third_party/silicaflux_v1_0/*.sv "$B/rtl/"
for p in integration/silicaflux_cluster_*.patch; do (cd "$B" && patch -p1 -s < "$ROOT/$p"); done
BASE="alu compute_tile control_core decoder fetch_unit forwarding_unit memory_controller noc_interconnect noc_router register_bank scheduler silicaflux_top tensor_unit tile_interface vector_engine"
OBJ=$ROOT/sim/cluster_obj_${W}x${H}
verilator --cc --exe --build -j 4 -O2 --no-timing --public-flat-rw -Wno-fatal -Wno-lint -Wno-style -I"$B/rtl" -I"$ROOT/rtl" \
  rtl/sfgx_pkg.sv rtl/sfgx_divu.sv rtl/sfgx_vertex.sv rtl/sfgx_clip.sv rtl/sfgx_raster.sv rtl/sfgx_tex.sv rtl/sfgx_fb.sv rtl/sfgx_gfx_tile.sv \
  $(for f in $BASE; do echo "$B/rtl/$f.sv"; done) --top-module silicaflux_top -GGFX_TILE=3 -GFB_W=$W -GFB_H=$H \
  -CFLAGS "-DFB_W=$W -DFB_H=$H ${CLUSTER_DEBUG:+-DCLUSTER_DEBUG}" "$ROOT/tb/cluster_harness.cpp" -Mdir "$OBJ" -o sfgx_cluster > "$OBJ.build.log" 2>&1 || { tail -30 "$OBJ.build.log"; exit 1; }
echo "built $OBJ/sfgx_cluster"
