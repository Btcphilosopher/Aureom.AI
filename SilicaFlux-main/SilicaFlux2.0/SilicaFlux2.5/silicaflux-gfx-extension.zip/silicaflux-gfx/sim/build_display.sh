#!/bin/bash
# Build the display-integration model (token ROM -> engine -> scan-out):  sim/build_display.sh <rom-file> <NTOK>
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
ROM=${1:?rom file}; NTOK=${2:?number of tokens}
RTL=$ROOT/rtl; SV=$ROOT/third_party/silicaflux_v1_0; DSP=$ROOT/integration/display
OBJ=$ROOT/sim/display_obj
verilator --cc --exe --build -j 4 -O2 --no-timing -Wno-fatal -Wno-DECLFILENAME -I"$RTL" -I"$SV" -I"$DSP" "$RTL/sfgx_lint.vlt" \
  "$RTL/sfgx_pkg.sv" "$RTL/sfgx_divu.sv" "$RTL/sfgx_vertex.sv" "$RTL/sfgx_clip.sv" "$RTL/sfgx_raster.sv" "$RTL/sfgx_tex.sv" "$RTL/sfgx_fb.sv" \
  "$SV/memory_controller.sv" "$RTL/sfgx_gfx_tile.sv" "$DSP/sfgx_scanout.sv" "$DSP/sfgx_cmd_rom.sv" "$DSP/sfgx_display_demo_top.sv" \
  --top-module sfgx_display_demo_top -GROM_FILE="\"$ROM\"" -GNTOK=$NTOK \
  -CFLAGS "-DVID_W=640 -DVID_H=480" "$ROOT/tb/display_harness.cpp" -Mdir "$OBJ" -o sfgx_display > "$OBJ.build.log" 2>&1 || { tail -30 "$OBJ.build.log"; exit 1; }
echo "built $OBJ/sfgx_display"
