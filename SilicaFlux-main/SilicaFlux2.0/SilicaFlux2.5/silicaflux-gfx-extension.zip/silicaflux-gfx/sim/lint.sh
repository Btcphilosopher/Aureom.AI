#!/bin/bash
# Verilator lint of the whole SFGX design (-Wall, warnings are errors).
cd "$(dirname "$0")/.."
SV=third_party/silicaflux_v1_0
verilator --lint-only -Wall -Wno-DECLFILENAME -Irtl -I$SV rtl/sfgx_lint.vlt \
  rtl/sfgx_pkg.sv rtl/sfgx_divu.sv rtl/sfgx_vertex.sv rtl/sfgx_clip.sv rtl/sfgx_raster.sv rtl/sfgx_tex.sv \
  rtl/sfgx_fb.sv $SV/memory_controller.sv rtl/sfgx_gfx_tile.sv --top-module sfgx_gfx_tile
