// =============================================================================
// sfgx_display_demo_top - engine + token ROM + scan-out: a CPU-less display demo
//
//   sfgx_cmd_rom --tokens--> sfgx_gfx_tile (UNCHANGED engine) --fb_scan_*--> sfgx_scanout --> video
//
// Everything except sfgx_gfx_tile is display/board integration.  Port mapping to a
// physical connector (pins, DAC / TMDS / HDMI-transmitter) is board specific and is
// described in docs/05_DISPLAY_INTEGRATION.md; no pin constraints are supplied because
// they must come from the board's own master constraints file.
// =============================================================================
module sfgx_display_demo_top
  import silicaflux_pkg::*;
#(
  parameter string ROM_FILE = "demo.rom",
  parameter int    NTOK     = 1,
  parameter int    FB_W     = 160,
  parameter int    FB_H     = 120,
  parameter int    SCALE    = 4,
  parameter int    LAT      = 2
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        pix_ce,

  output logic        vid_hsync,
  output logic        vid_vsync,
  output logic        vid_de,
  output logic [7:0]  vid_r,
  output logic [7:0]  vid_g,
  output logic [7:0]  vid_b,
  output logic        vid_frame_start,
  output logic        gfx_busy,
  output logic        rom_finished
);
  localparam int AW = $clog2(FB_W * FB_H);

  logic [4:0] tok_opcode; logic [13:0] tok_mem_addr; logic [4:0] tok_length;
  logic [31:0] scalar; logic [127:0] vec; logic token_valid, token_ready, tile_done, tile_error;
  logic [31:0] res_s; logic [127:0] res_v;
  noc_flit_t noc_out; logic noc_v, noc_in_ready;
  logic [AW-1:0] scan_addr; logic [31:0] scan_data; logic frame_start_i;

  sfgx_cmd_rom #(.INIT_FILE(ROM_FILE), .NTOK(NTOK)) u_rom (
    .clk(clk), .rst_n(rst_n), .tok_opcode(tok_opcode), .tok_mem_addr(tok_mem_addr), .tok_length(tok_length),
    .scalar_data_in(scalar), .vector_data_in(vec), .token_valid(token_valid), .token_ready(token_ready),
    .tile_done(tile_done), .finished(rom_finished)
  );

  sfgx_gfx_tile #(.TILE_ID(0), .FB_W(FB_W), .FB_H(FB_H)) u_gfx (
    .clk(clk), .rst_n(rst_n),
    .tok_opcode(tok_opcode), .tok_tile_id(3'd0), .tok_src_reg(5'd0), .tok_dst_reg(5'd0), .tok_vsrc_reg(4'd0),
    .tok_vdst_reg(4'd0), .tok_mem_addr(tok_mem_addr), .tok_length(tok_length), .tok_func({3'b0, tok_length}),
    .token_valid(token_valid), .token_ready(token_ready),
    .scalar_data_in(scalar), .vector_data_in(vec), .vector_data_in_b('0),
    .tile_done(tile_done), .tile_error(tile_error), .tile_result_scalar(res_s), .tile_result_vector(res_v),
    .noc_flit_out(noc_out), .noc_flit_valid(noc_v), .noc_flit_ready(1'b1),
    .noc_flit_in('0), .noc_flit_in_valid(1'b0), .noc_flit_in_ready(noc_in_ready),
    .fb_scan_addr(scan_addr), .fb_scan_data(scan_data), .gfx_busy(gfx_busy),
    .dbg_tri_valid(), .dbg_tri_data(), .dbg_cov_valid(), .dbg_cov_x(), .dbg_cov_y()
  );

  sfgx_scanout #(.FB_W(FB_W), .FB_H(FB_H), .SCALE(SCALE), .LAT(LAT)) u_scan (
    .clk(clk), .rst_n(rst_n), .pix_ce(pix_ce), .fb_addr(scan_addr), .fb_data(scan_data),
    .hsync(vid_hsync), .vsync(vid_vsync), .de(vid_de), .r(vid_r), .g(vid_g), .b(vid_b),
    .frame_start(frame_start_i), .line_start()
  );
  assign vid_frame_start = frame_start_i;

  logic unused_ok;
  assign unused_ok = &{1'b0, tile_error, res_s[0], res_v[0], noc_out.valid, noc_v, noc_in_ready};
endmodule
