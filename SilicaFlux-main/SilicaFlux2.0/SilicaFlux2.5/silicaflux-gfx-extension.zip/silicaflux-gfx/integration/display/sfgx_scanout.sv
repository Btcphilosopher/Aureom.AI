// =============================================================================
// sfgx_scanout - display-side framebuffer reader + video timing generator
//
// THIS IS DISPLAY INTEGRATION, NOT PART OF THE RENDERING ENGINE.  It talks to the
// engine only through its documented framebuffer read port (fb_scan_addr /
// fb_scan_data of sfgx_gfx_tile: registered read, data one clock after the address).
//
//   * integer pixel replication (SCALE): FB_W x FB_H  ->  FB_W*SCALE x FB_H*SCALE,
//     placed at the top-left of the active area, the rest is black
//   * programmable VGA-style timing (default: 640x480@60, 800x525 total, both
//     syncs active-low; pixel clock 25.175 MHz nominal -> 25 MHz is within monitor tolerance)
//   * `pix_ce` is a clock ENABLE: the module is single-clock.  For a real display the
//     pixel clock normally comes from a PLL; see docs/05_DISPLAY_INTEGRATION.md for the two
//     ways to cross from the engine clock (dual-clock BRAM port, or a DMA'd frame buffer).
//   * LAT = number of pixel periods between presenting an address and its data being
//     sampled: 2 when pix_ce is high every clock (the BRAM output register adds one
//     period), 1 when pix_ce is slower than every second clock.
// Outputs: hsync/vsync (polarity per HS_POL/VS_POL, 0 = active-low), de, r/g/b, and
// one-clock `frame_start` / `line_start` strobes aligned with the first active pixel period.
// =============================================================================
module sfgx_scanout #(
  parameter int FB_W     = 160,
  parameter int FB_H     = 120,
  parameter int SCALE    = 4,
  parameter int H_ACTIVE = 640, parameter int H_FP = 16, parameter int H_SYNC = 96, parameter int H_BP = 48,
  parameter int V_ACTIVE = 480, parameter int V_FP = 10, parameter int V_SYNC = 2,  parameter int V_BP = 33,
  parameter bit HS_POL   = 1'b0,
  parameter bit VS_POL   = 1'b0,
  parameter int LAT      = 2,
  parameter int AW       = $clog2(FB_W * FB_H)
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          pix_ce,

  output logic [AW-1:0] fb_addr,
  input  logic [31:0]   fb_data,

  output logic          hsync,
  output logic          vsync,
  output logic          de,
  output logic [7:0]    r,
  output logic [7:0]    g,
  output logic [7:0]    b,
  output logic          frame_start,
  output logic          line_start
);
  localparam int H_TOTAL = H_ACTIVE + H_FP + H_SYNC + H_BP;
  localparam int V_TOTAL = V_ACTIVE + V_FP + V_SYNC + V_BP;

  // ---- raster counters (address stage) --------------------------------------------------
  logic [$clog2(H_TOTAL)-1:0] hc;
  logic [$clog2(V_TOTAL)-1:0] vc;
  logic [$clog2(SCALE+1)-1:0] sx, sy;           // sub-pixel replication counters
  logic [$clog2(FB_W+1)-1:0]  fx;
  logic [$clog2(FB_H+1)-1:0]  fy;
  logic [AW-1:0]              row_base;

  logic in_img_x, in_img_y, in_active;
  assign in_img_x  = (hc < (H_ACTIVE < FB_W * SCALE ? H_ACTIVE : FB_W * SCALE));
  assign in_img_y  = (vc < (V_ACTIVE < FB_H * SCALE ? V_ACTIVE : FB_H * SCALE));
  assign in_active = (hc < H_ACTIVE) && (vc < V_ACTIVE);

  // syncs / de / strobes for the CURRENT counter position, then delayed by LAT pixel periods
  logic hs_c, vs_c, de_c, img_c, fs_c, ls_c;
  assign hs_c  = (hc >= H_ACTIVE + H_FP) && (hc < H_ACTIVE + H_FP + H_SYNC);
  assign vs_c  = (vc >= V_ACTIVE + V_FP) && (vc < V_ACTIVE + V_FP + V_SYNC);
  assign de_c  = in_active;
  assign img_c = in_img_x && in_img_y;
  assign fs_c  = (hc == 0) && (vc == 0);
  assign ls_c  = (hc == 0);

  logic [LAT-1:0] hs_p, vs_p, de_p, img_p, fs_p, ls_p;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      hc <= '0; vc <= '0; sx <= '0; sy <= '0; fx <= '0; fy <= '0; row_base <= '0; fb_addr <= '0;
      hs_p <= '0; vs_p <= '0; de_p <= '0; img_p <= '0; fs_p <= '0; ls_p <= '0;
      hsync <= ~HS_POL; vsync <= ~VS_POL; de <= 1'b0; r <= '0; g <= '0; b <= '0;
      frame_start <= 1'b0; line_start <= 1'b0;
    end else begin
      frame_start <= 1'b0;
      line_start  <= 1'b0;
      if (pix_ce) begin
        // ---- address stage: present the address of the pixel at (hc,vc) ----------------------
        fb_addr <= row_base + AW'(fx);
        // ---- delay the control signals by LAT pixel periods ------------------------------------
        hs_p  <= {hs_p[LAT-2:0],  hs_c};   vs_p  <= {vs_p[LAT-2:0],  vs_c};
        de_p  <= {de_p[LAT-2:0],  de_c};   img_p <= {img_p[LAT-2:0], img_c};
        fs_p  <= {fs_p[LAT-2:0],  fs_c};   ls_p  <= {ls_p[LAT-2:0],  ls_c};
        // ---- output stage ------------------------------------------------------------------------
        hsync <= hs_p[LAT-1] ? HS_POL : ~HS_POL;
        vsync <= vs_p[LAT-1] ? VS_POL : ~VS_POL;
        de    <= de_p[LAT-1];
        if (de_p[LAT-1] && img_p[LAT-1]) begin r <= fb_data[23:16]; g <= fb_data[15:8]; b <= fb_data[7:0]; end
        else begin r <= '0; g <= '0; b <= '0; end
        frame_start <= fs_p[LAT-1];
        line_start  <= ls_p[LAT-1];
        // ---- advance counters ----------------------------------------------------------------------
        if (hc == H_TOTAL - 1) begin
          hc <= '0; sx <= '0; fx <= '0;
          if (vc == V_TOTAL - 1) begin vc <= '0; sy <= '0; fy <= '0; row_base <= '0; end
          else begin
            vc <= vc + 1'b1;
            if (vc < V_ACTIVE && in_img_y) begin
              if (sy == SCALE - 1) begin sy <= '0; fy <= fy + 1'b1; row_base <= row_base + AW'(FB_W); end
              else sy <= sy + 1'b1;
            end
          end
        end else begin
          hc <= hc + 1'b1;
          if (in_img_x && hc < H_ACTIVE) begin
            if (sx == SCALE - 1) begin sx <= '0; fx <= fx + 1'b1; end
            else sx <= sx + 1'b1;
          end
        end
      end
    end
  end
endmodule
