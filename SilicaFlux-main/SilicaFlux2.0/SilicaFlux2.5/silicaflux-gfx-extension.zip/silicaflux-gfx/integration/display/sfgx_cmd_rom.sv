// =============================================================================
// sfgx_cmd_rom - replays a fixed list of graphics tokens into the tile's token port
//
// Stand-in for the SilicaFlux control core on a board that has no CPU program yet:
// it presents one token at a time (token_valid held until token_ready, exactly like
// the scheduler) and waits for tile_done before the next.  One ROM line per token,
// 256 bits per line (hex), eight 32-bit words, most significant first:
//        op | addr14 | len5 | scalar | v3 | v2 | v1 | v0       (see tools/mkrom.py)
// =============================================================================
module sfgx_cmd_rom #(
  parameter string INIT_FILE = "demo.rom",
  parameter int    NTOK      = 1
) (
  input  logic         clk,
  input  logic         rst_n,

  output logic [4:0]   tok_opcode,
  output logic [13:0]  tok_mem_addr,
  output logic [4:0]   tok_length,
  output logic [31:0]  scalar_data_in,
  output logic [127:0] vector_data_in,
  output logic         token_valid,
  input  logic         token_ready,
  input  logic         tile_done,

  output logic         finished
);
  logic [255:0] rom [0:NTOK-1];
  initial $readmemh(INIT_FILE, rom);

  typedef enum logic [1:0] { S_PRESENT, S_WAIT_DONE, S_FINISHED } st_t;
  st_t st;
  logic [$clog2(NTOK+1)-1:0] idx;
  logic [255:0] cur;

  assign cur            = rom[idx];
  assign tok_opcode     = cur[228:224];
  assign tok_mem_addr   = cur[205:192];
  assign tok_length     = cur[164:160];
  assign scalar_data_in = cur[159:128];
  assign vector_data_in = cur[127:0];
  assign token_valid    = (st == S_PRESENT);
  assign finished       = (st == S_FINISHED);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin st <= S_PRESENT; idx <= '0; end
    else case (st)
      S_PRESENT:     if (token_ready) st <= S_WAIT_DONE;         // valid && ready: accepted at this edge
      S_WAIT_DONE:   if (tile_done) begin
                       if (idx == NTOK - 1) st <= S_FINISHED; else begin idx <= idx + 1'b1; st <= S_PRESENT; end
                     end
      default: ;
    endcase
  end
endmodule
