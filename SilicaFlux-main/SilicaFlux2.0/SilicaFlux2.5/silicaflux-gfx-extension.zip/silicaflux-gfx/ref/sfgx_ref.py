#!/usr/bin/env python3
"""
sfgx_ref.py - bit-accurate software reference rasteriser for the SilicaFlux
Graphics Extension (SFGX).

This file is the *executable form of docs/02_NUMERIC_SPEC.md*.  It uses only
Python integers (arbitrary precision) so every rounding, saturation and wrap
rule is explicit.  The RTL in ../rtl must match it bit-for-bit (framebuffer,
depth buffer, statistics counters and the post-clip triangle trace).

Pipeline (same order as the RTL):

    vertex fetch -> MVP transform (Q16.16, saturating)
      -> homogeneous clip, 6 planes, Sutherland-Hodgman (exact 34-bit plane
         distances, Q0.32 intersection parameter)
      -> viewport transform (clamped, round-half-up division)
      -> fan triangulation -> setup (area, cull, top-left rule, gradients)
      -> raster (bbox scan, edge functions, plane-equation interpolation)
      -> depth test -> [texture: perspective-correct nearest sample] -> framebuffer write

Nothing here depends on the RTL; it was written from the spec.
"""
from __future__ import annotations
import sys
import numpy as np

# --------------------------------------------------------------------------
# Constants shared with rtl/sfgx_pkg.sv (kept in sync by tests/check_consts.py)
# --------------------------------------------------------------------------
SRAM_DEPTH = 256            # SilicaFlux scratchpad words per tile (silicaflux_pkg)
F_GRAD = 24                 # fractional bits of plane gradients / accumulators (Z, R, G, B)
F_GRAD_T = 12               # ... for the texture attributes s, t, q
TEX_TEXELS = 4096           # texture memory: 64 x 64 max, RGB888
DEPTH_MAX = 0xFFFF          # Z16
VTX_STRIDE = 4              # words: x y z colour

# opcodes (README: 0x18-0x1E reserved for application-specific kernels)
OP_LOAD, OP_STORE, OP_VLOAD, OP_VSTORE, OP_DFSYNC = 0x04, 0x05, 0x16, 0x17, 0x0E
OP_VADD = 0x0F                # a vector kernel: NOT implemented by the graphics tile (error probe)
OP_GFXREG, OP_GFXDRAW, OP_GFXCLEAR, OP_GFXRD, OP_GFXSTAT, OP_GFXMEM, OP_GFXTEX = 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E

# GFXREG register indices
R_MAT0 = 0x00               # 0x00..0x0F : M[row][col] row-major, Q16.16
R_CTRL = 0x10
R_VTX_BASE = 0x11
R_TRI_BASE = 0x12
R_NUM_TRI = 0x13
R_CLEAR_DEPTH = 0x14
R_VTX_STRIDE = 0x15
R_TEX_CTRL = 0x16
R_STATS_CLR = 0x1F

# CTRL bits
CTRL_ZTEST = 1 << 0
CTRL_ZWRITE = 1 << 1
CTRL_ZFUNC_SH = 2           # [4:2]
CTRL_CULL_SH = 5            # [6:5] 0 none, 1 back, 2 front
CTRL_FRONT_CW = 1 << 7      # 0 = CCW is front-facing
CTRL_TEX_EN = 1 << 8
CTRL_TEX_MOD = 1 << 9       # 1 = modulate texel by vertex colour, 0 = replace
CTRL_TEX_CLAMP = 1 << 10    # 1 = clamp-to-edge, 0 = repeat
CTRL_DEFAULT = CTRL_ZTEST | CTRL_ZWRITE | (1 << CTRL_ZFUNC_SH)   # LESS

# GFXSTAT indices
(ST_FLAGS, ST_TRI_IN, ST_TRI_ADDR_ERR, ST_TRI_CLIP_REJ, ST_TRI_CLIPPED,
 ST_TRI_SETUP, ST_TRI_DEGEN, ST_TRI_CULL, ST_TRI_RASTER, ST_PIX_COV,
 ST_PIX_WRITTEN, ST_PIX_ZFAIL, ST_FBSIZE, ST_ID, ST_PIX_TEX) = range(15)
SFGX_ID = 0x53464758        # "SFGX"
FLAG_XFORM_OVF = 1 << 0     # sticky: a transformed coordinate saturated
FLAG_ADDR_ERR = 1 << 1      # sticky: scratchpad / framebuffer address rejected
FLAG_BAD_TOKEN = 1 << 2     # sticky: unsupported register / selector


# Largest bit-length ever observed for each quantity whose RTL register width is a
# claim of the numeric spec.  _chk() also ENFORCES the claimed width (AssertionError).
BOUNDS = {}
FX_LOG = None   # debug: set to a dict to record the exact texel coordinate of every textured write
CLAMP_HITS = {'depth': 0, 'colour': 0}   # covered pixels whose interpolated value needed clamping
def _chk(name, value, max_bits):
    n = abs(int(value)).bit_length()
    if n > max_bits:
        raise AssertionError(f"width claim violated: {name} needs {n} bits > {max_bits}")
    if n > BOUNDS.get(name, 0): BOUNDS[name] = n


def s32(x):  return ((x + (1 << 31)) & 0xFFFFFFFF) - (1 << 31)
def s64(x):  return ((x + (1 << 63)) & 0xFFFFFFFFFFFFFFFF) - (1 << 63)
def sat32(x):
    return (-(1 << 31), True) if x < -(1 << 31) else ((1 << 31) - 1, True) if x > (1 << 31) - 1 else (x, False)
def clamp(x, lo, hi): return lo if x < lo else hi if x > hi else x


def rdiv_u(n, d):
    """round-half-up unsigned division, d>0 (n>=0)."""
    q, r = divmod(n, d)
    return q + (1 if 2 * r >= d else 0)


def rdiv_s(n, d):
    """round-half-away-from-zero signed numerator, d>0."""
    m = -n if n < 0 else n
    q = rdiv_u(m, d)
    return -q if n < 0 else q


# --------------------------------------------------------------------------
class SfgxModel:
    def __init__(self, W=160, H=120):
        assert 1 <= W <= 2048 and 1 <= H <= 2048
        self.W, self.H = W, H
        self.mem = [0] * SRAM_DEPTH
        self.color = np.zeros(W * H, dtype=np.uint32)
        self.depth = np.zeros(W * H, dtype=np.uint16)
        self.cov_count = np.zeros(W * H, dtype=np.int64)   # model-only debug
        self.tex = np.zeros(TEX_TEXELS, dtype=np.uint32)
        self.reset_regs()
        self.clear_stats()
        self.trace = []                                    # post-clip tris

    # ---- state -----------------------------------------------------------
    def reset_regs(self):
        self.mat = [0] * 16
        for i in range(4):
            self.mat[i * 5] = 1 << 16                       # identity
        self.ctrl = CTRL_DEFAULT
        self.vtx_base = 0
        self.tri_base = 0
        self.num_tri = 0
        self.clear_depth = DEPTH_MAX
        self.vtx_stride = 4
        self.tex_log2 = 0x55

    def clear_stats(self):
        self.flags = 0
        self.cnt = dict(tri_in=0, tri_addr_err=0, tri_clip_rej=0, tri_clipped=0,
                        tri_setup=0, tri_degen=0, tri_cull=0, tri_raster=0,
                        pix_cov=0, pix_written=0, pix_zfail=0, pix_tex=0)

    # ---- token interface ---------------------------------------------------
    def token(self, op, addr=0, scalar=0, vec=(0, 0, 0, 0), length=0):
        """Execute one SilicaFlux token.  Returns (result_scalar, error)."""
        err = False
        res = 0
        if op in (OP_STORE, OP_GFXMEM):
            if addr < SRAM_DEPTH: self.mem[addr] = scalar & 0xFFFFFFFF
            else: err = True; self.flags |= FLAG_ADDR_ERR
        elif op == OP_LOAD:
            if addr < SRAM_DEPTH: res = self.mem[addr]
            else: err = True; self.flags |= FLAG_ADDR_ERR
        elif op == OP_VLOAD:                       # scalar result = first word of the 4-word vector
            if addr + 3 < SRAM_DEPTH: res = self.mem[addr]
            else: err = True; self.flags |= FLAG_ADDR_ERR
        elif op == OP_VSTORE:
            if addr + 3 < SRAM_DEPTH:
                for i in range(4): self.mem[addr + i] = vec[i] & 0xFFFFFFFF
            else: err = True; self.flags |= FLAG_ADDR_ERR
        elif op == OP_DFSYNC:
            pass
        elif op == OP_GFXREG:
            err = not self._write_reg(addr, scalar & 0xFFFFFFFF)
        elif op == OP_GFXCLEAR:
            if length & 1: self.color[:] = scalar & 0x00FFFFFF
            if length & 2: self.depth[:] = self.clear_depth
        elif op == OP_GFXDRAW:
            before = self.cnt['pix_written']
            self.draw()
            res = (self.cnt['pix_written'] - before) & 0xFFFFFFFF
        elif op == OP_GFXTEX:
            if addr < TEX_TEXELS: self.tex[addr] = scalar & 0xFFFFFF
            else: err = True; self.flags |= FLAG_ADDR_ERR
        elif op == OP_GFXRD:
            x, y = scalar & 0xFFFF, (scalar >> 16) & 0xFFFF
            if x < self.W and y < self.H and addr in (0, 1):
                res = int(self.color[y * self.W + x]) if addr == 0 else int(self.depth[y * self.W + x])
            else:
                err = True; self.flags |= FLAG_ADDR_ERR
        elif op == OP_GFXSTAT:
            res = self.stat(addr)
        else:                                      # vector/tensor kernels and reserved GFX opcodes
            err = True; self.flags |= FLAG_BAD_TOKEN
        return res, err

    def _write_reg(self, idx, val):
        if idx < 16: self.mat[idx] = s32(val)
        elif idx == R_CTRL: self.ctrl = val & 0x7FF
        elif idx == R_VTX_STRIDE:
            if 4 <= val <= 64: self.vtx_stride = val
            else: self.flags |= FLAG_BAD_TOKEN; return False
        elif idx == R_TEX_CTRL:
            if (val & 15) <= 6 and ((val >> 4) & 15) <= 6: self.tex_log2 = val & 0xFF
            else: self.flags |= FLAG_BAD_TOKEN; return False
        elif idx == R_VTX_BASE: self.vtx_base = val & 0xFFFF
        elif idx == R_TRI_BASE: self.tri_base = val & 0xFFFF
        elif idx == R_NUM_TRI: self.num_tri = val & 0xFFFF
        elif idx == R_CLEAR_DEPTH: self.clear_depth = val & 0xFFFF
        elif idx == R_STATS_CLR: self.clear_stats()
        else:
            self.flags |= FLAG_BAD_TOKEN
            return False
        return True

    def stat(self, idx):
        c = self.cnt
        tbl = [self.flags, c['tri_in'], c['tri_addr_err'], c['tri_clip_rej'], c['tri_clipped'],
               c['tri_setup'], c['tri_degen'], c['tri_cull'], c['tri_raster'], c['pix_cov'],
               c['pix_written'], c['pix_zfail'], self.W | (self.H << 16), SFGX_ID, c['pix_tex']]
        return tbl[idx] & 0xFFFFFFFF if idx < len(tbl) else 0

    # ---- draw --------------------------------------------------------------
    def draw(self):
        for t in range(self.num_tri):
            self.cnt['tri_in'] += 1
            taddr = self.tri_base + t
            if taddr >= SRAM_DEPTH:
                self.cnt['tri_addr_err'] += 1; self.flags |= FLAG_ADDR_ERR; continue
            tw = self.mem[taddr]
            idx = [(tw >> (10 * k)) & 0x3FF for k in range(3)]
            verts, bad = [], False
            nfetch = 6 if ((self.ctrl & CTRL_TEX_EN) and self.vtx_stride >= 6) else 4
            for i in idx:
                va = self.vtx_base + i * self.vtx_stride
                if va + self.vtx_stride - 1 >= SRAM_DEPTH:
                    bad = True; break
                w = self.mem[va:va + nfetch]
                verts.append(w + [0] * (6 - nfetch))        # u,v read as 0 unless fetched
            if bad:
                self.cnt['tri_addr_err'] += 1; self.flags |= FLAG_ADDR_ERR; continue
            clipv = [self.transform(v) for v in verts]
            self.process_clip_triangle(clipv)

    def transform(self, vw):
        x, y, z = s32(vw[0]), s32(vw[1]), s32(vw[2])
        col = vw[3]
        out = []
        for r in range(4):
            m = self.mat[r * 4:(r + 1) * 4]
            acc = m[0] * x + m[1] * y + m[2] * z + m[3] * (1 << 16)
            _chk('xform accumulator (68b signed => <=67 magnitude bits)', acc, 67)
            v = (acc + (1 << 15)) >> 16
            v, o = sat32(v)
            if o: self.flags |= FLAG_XFORM_OVF
            out.append(v)
        r8, g8, b8 = (col >> 16) & 255, (col >> 8) & 255, col & 255
        return tuple(out) + (r8 << 8, g8 << 8, b8 << 8, s32(vw[4]), s32(vw[5]))   # x y z w r g b u v

    # ---- clip --------------------------------------------------------------
    @staticmethod
    def plane_dist(v, p):
        x, y, z, w = v[0], v[1], v[2], v[3]
        return [w + x, w - x, w + y, w - y, w + z, w - z][p]

    def clip_polygon(self, poly):
        """Sutherland-Hodgman over the 6 planes; returns (polygon, n_intersections)."""
        nint = 0
        for p in range(6):
            n = len(poly)
            if n == 0: break
            out = []
            for i in range(n):
                P, Q = poly[(i - 1) % n], poly[i]
                dP, dQ = self.plane_dist(P, p), self.plane_dist(Q, p)
                pin, qin = dP >= 0, dQ >= 0
                def isect():
                    s = abs(dP - dQ)
                    t = (abs(dP) << 32) // s
                    _chk('clip plane distance |d| (34b signed => <=33)', dP, 33)
                    _chk('clip |dP-dQ| (34b unsigned)', s, 34)
                    _chk('clip t (Q0.32, must be < 2^32)', t, 32)
                    return tuple(P[k] + (((Q[k] - P[k]) * t + (1 << 31)) >> 32) for k in range(9))
                if pin and qin:
                    out.append(Q)
                elif pin and not qin:
                    if dP > 0: out.append(isect()); nint += 1
                elif (not pin) and qin:
                    if dQ > 0: out.append(isect()); nint += 1
                    out.append(Q)
            poly = out
        return poly, nint

    def viewport(self, v):
        x, y, z, w = v[0], v[1], v[2], v[3]
        nx = clamp(x + w, 0, 2 * w)
        ny = clamp(w - y, 0, 2 * w)
        nz = clamp(z + w, 0, 2 * w)
        X = rdiv_u(nx * (self.W * 128), w)
        Y = rdiv_u(ny * (self.H * 128), w)
        Z = rdiv_u(nz * (DEPTH_MAX * 128), w)
        _chk('viewport numerator nx*(W*128) (56b)', max(nx * (self.W * 128), ny * (self.H * 128), nz * (DEPTH_MAX * 128)), 56)
        _chk('viewport X,Y (<=2^19) / Z (<2^24)', max(X, Y, Z), 24)
        if self.ctrl & CTRL_TEX_EN:
            QMAX, SMAX = (1 << 39) - 1, (1 << 39) - 1
            q = min(rdiv_u(1 << 40, w), QMAX)
            s_ = clamp((v[7] * q + (1 << 15)) >> 16, -(1 << 39), SMAX)
            t_ = clamp((v[8] * q + (1 << 15)) >> 16, -(1 << 39), SMAX)
        else:
            s_ = t_ = q = 0
        return (X, Y, Z, v[4], v[5], v[6], s_, t_, q)

    def process_clip_triangle(self, tri):
        poly, nint = self.clip_polygon(list(tri))
        if len(poly) < 3 or any(v[3] <= 0 for v in poly):
            self.cnt['tri_clip_rej'] += 1
            return
        if nint: self.cnt['tri_clipped'] += 1
        sv = [self.viewport(v) for v in poly]
        for k in range(1, len(sv) - 1):
            self.cnt['tri_setup'] += 1
            self.trace.append((sv[0], sv[k], sv[k + 1]))
            self.setup_and_raster(sv[0], sv[k], sv[k + 1])

    # ---- setup + raster -------------------------------------------------------
    def setup_and_raster(self, a, b, c):
        area2 = (b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])
        if area2 == 0:
            self.cnt['tri_degen'] += 1; return
        front_ccw = not (self.ctrl & CTRL_FRONT_CW)
        front = (area2 < 0) if front_ccw else (area2 > 0)
        cull = (self.ctrl >> CTRL_CULL_SH) & 3
        if (cull == 1 and not front) or (cull == 2 and front):
            self.cnt['tri_cull'] += 1; return
        if area2 < 0:
            b, c = c, b
            area2 = -area2
        _chk('area2 (DW=40 divider denominator => <=39 bits)', area2, 39)
        V = [a, b, c]
        # edges e0: V0->V1, e1: V1->V2, e2: V2->V0 ; E(p)=dx*(py-ay)-dy*(px-ax)
        dx = [V[(i + 1) % 3][0] - V[i][0] for i in range(3)]
        dy = [V[(i + 1) % 3][1] - V[i][1] for i in range(3)]
        tl = [(dy[i] < 0) or (dy[i] == 0 and dx[i] > 0) for i in range(3)]
        bias = [0 if tl[i] else 1 for i in range(3)]
        # attribute plane gradients (per Q8 unit), attr order: Z, R, G, B
        grads = []
        tex_on = bool(self.ctrl & CTRL_TEX_EN)
        for k in ((2, 3, 4, 5, 6, 7, 8) if tex_on else (2, 3, 4, 5)):
            F = F_GRAD if k < 6 else F_GRAD_T
            v0, v1, v2 = V[0][k], V[1][k], V[2][k]
            nx = -(dy[1] * v0 + dy[2] * v1 + dy[0] * v2)
            ny = dx[1] * v0 + dx[2] * v1 + dx[0] * v2
            _chk('gradient numerator |N| (<=2^47 for Z/RGB, <=2^61 for s,t,q => gabs 72b)', max(abs(nx), abs(ny)), 47 if k < 6 else 61)
            _chk('gradient numerator shifted (<=2^72 => 80-bit divider)', max(abs(nx), abs(ny)) << F, 72)
            gx = s64(rdiv_s(nx << F, area2))
            gy = s64(rdiv_s(ny << F, area2))
            grads.append((v0, gx, gy, F))
        # bbox (conservative, clamped)
        xs = [v[0] for v in V]; ys = [v[1] for v in V]
        x0 = max(0, min(xs) >> 8); x1 = min(self.W - 1, max(xs) >> 8)
        y0 = max(0, min(ys) >> 8); y1 = min(self.H - 1, max(ys) >> 8)
        self.cnt['tri_raster'] += 1
        if x0 > x1 or y0 > y1: return
        px0, py0 = x0 * 256 + 128, y0 * 256 + 128
        e0 = [dx[i] * (py0 - V[i][1]) - dy[i] * (px0 - V[i][0]) for i in range(3)]
        A = [-dy[i] * 256 for i in range(3)]        # per +1 pixel in x
        B = [dx[i] * 256 for i in range(3)]         # per +1 pixel in y
        _chk('edge function start value (48b signed => <=47)', max(abs(v) for v in e0), 47)
        nxp, nyp = x1 - x0 + 1, y1 - y0 + 1
        _chk('edge function worst case E_start+span*step', max(abs(e0[i]) + (nxp * abs(A[i])) + (nyp * abs(B[i])) for i in range(3)), 47)
        gxi = np.arange(nxp, dtype=np.int64)[None, :]
        gyi = np.arange(nyp, dtype=np.int64)[:, None]
        cover = np.ones((nyp, nxp), dtype=bool)
        for i in range(3):
            Ei = np.int64(e0[i]) + gxi * np.int64(A[i]) + gyi * np.int64(B[i])
            cover &= (Ei - bias[i]) >= 0
        ncov = int(cover.sum())
        if ncov == 0: return
        # attribute values at pixel centres (64-bit wrapping arithmetic)
        vals = []
        with np.errstate(over='ignore'):
            for ai, (v0, gx, gy, F) in enumerate(grads):
                acc0 = s64((v0 << F) + gx * (px0 - V[0][0]) + gy * (py0 - V[0][1]))
                accg = (np.int64(acc0) + gxi * np.int64(s64(gx * 256)) + gyi * np.int64(s64(gy * 256)))
                if ai < 4:                                   # Z, R, G, B: Q?.8 -> integer
                    vals.append((accg + np.int64(1 << (F + 7))) >> (F + 8))
                else:                                        # s, t, q: keep 24 fractional bits
                    vals.append((accg + np.int64(1 << (F - 1))) >> F)
        CLAMP_HITS['depth'] += int((((vals[0] < 0) | (vals[0] > DEPTH_MAX)) & cover).sum())
        CLAMP_HITS['colour'] += int((((vals[1] < 0) | (vals[1] > 255) | (vals[2] < 0) | (vals[2] > 255) | (vals[3] < 0) | (vals[3] > 255)) & cover).sum())
        z16 = np.clip(vals[0], 0, DEPTH_MAX)
        r8, g8, b8 = (np.clip(vals[i], 0, 255) for i in (1, 2, 3))
        ys_, xs_ = np.nonzero(cover)                # raster order: y asc, x asc
        # statistics are order independent; write order matters only for ties
        # inside one triangle, which cannot occur (each pixel covered once)
        fb = (ys_ + y0) * self.W + (xs_ + x0)
        self.cov_count[fb] += 1
        self.cnt['pix_cov'] += ncov
        zn = z16[ys_, xs_].astype(np.int64)
        zo = self.depth[fb].astype(np.int64)
        if self.ctrl & CTRL_ZTEST:
            f = (self.ctrl >> CTRL_ZFUNC_SH) & 7
            ok = [np.zeros_like(zn, bool), zn < zo, zn == zo, zn <= zo,
                  zn > zo, zn != zo, zn >= zo, np.ones_like(zn, bool)][f]
        else:
            ok = np.ones_like(zn, bool)
        self.cnt['pix_zfail'] += int((~ok).sum())
        self.cnt['pix_written'] += int(ok.sum())
        rr, gg, bb = (a[ys_, xs_].astype(np.int64) for a in (r8, g8, b8))
        if tex_on:
            wlog, hlog = self.tex_log2 & 15, (self.tex_log2 >> 4) & 15
            sv, tv, qv = (vals[i][ys_, xs_].astype(np.int64) for i in (4, 5, 6))
            _chk('texture |S|,|T| (<2^42 => 42-bit magnitude)', max(int(np.abs(sv).max()), int(np.abs(tv).max())), 42)
            _chk('texture Q (<2^40 => 40-bit divisor)', int(np.abs(qv).max()), 40)
            qd = np.where(qv <= 0, 1, qv)
            if FX_LOG is not None:
                fxe = (sv << wlog) / qd; fye = (tv << hlog) / qd
                for i_ in np.nonzero(ok)[0]:
                    p_ = int(fb[i_]); FX_LOG[(p_ % self.W, p_ // self.W)] = (float(fxe[i_]), float(fye[i_]))
            txf = np.floor_divide(sv << wlog, qd)                # floor division, exactly as the RTL
            tyf = np.floor_divide(tv << hlog, qd)
            if self.ctrl & CTRL_TEX_CLAMP:
                tx = np.clip(txf, 0, (1 << wlog) - 1); ty = np.clip(tyf, 0, (1 << hlog) - 1)
            else:
                tx = txf & ((1 << wlog) - 1); ty = tyf & ((1 << hlog) - 1)
            texel = self.tex[(ty << wlog) | tx].astype(np.int64)
            tr, tg, tb = (texel >> 16) & 255, (texel >> 8) & 255, texel & 255
            if self.ctrl & CTRL_TEX_MOD:
                def mod(t, c):
                    y = t * c + 127
                    return (y + 1 + (y >> 8)) >> 8
                tr, tg, tb = mod(tr, rr), mod(tg, gg), mod(tb, bb)
            rr, gg, bb = tr, tg, tb
            self.cnt['pix_tex'] += int(ok.sum())
        col = ((rr.astype(np.uint32) << 16) | (gg.astype(np.uint32) << 8) | bb.astype(np.uint32))
        self.color[fb[ok]] = col[ok]
        if self.ctrl & CTRL_ZWRITE:
            self.depth[fb[ok]] = zn[ok].astype(np.uint16)


# --------------------------------------------------------------------------
# command-file replay (same file is replayed by the RTL harness)
# --------------------------------------------------------------------------
OPNAMES = {'GFXTEX': OP_GFXTEX, 'GFXMEM': OP_GFXMEM, 'LOAD': OP_LOAD, 'VLOAD': OP_VLOAD, 'VADD': OP_VADD, 'STORE': OP_STORE, 'VSTORE': OP_VSTORE, 'DFSYNC': OP_DFSYNC, 'GFXREG': OP_GFXREG,
           'GFXDRAW': OP_GFXDRAW, 'GFXCLEAR': OP_GFXCLEAR, 'GFXRD': OP_GFXRD, 'GFXSTAT': OP_GFXSTAT}


def parse_cmd(path):
    """-> list of ('TOKEN', op, addr, scalar, vec, length) | ('CAPTURE', name)."""
    out = []
    for ln in open(path):
        ln = ln.split('#')[0].strip()
        if not ln: continue
        t = ln.split()
        k = t[0].upper()
        if k == 'CAPTURE':
            out.append(('CAPTURE', t[1])); continue
        a = [int(x, 0) for x in t[1:]]
        if k == 'STORE':
            out.append(('TOKEN', OP_STORE, a[0], a[1], (0, 0, 0, 0), 0))
        elif k == 'GFXMEM':
            out.append(('TOKEN', OP_GFXMEM, a[0], a[1], (0, 0, 0, 0), 0))
        elif k == 'GFXTEX':
            out.append(('TOKEN', OP_GFXTEX, a[0], a[1], (0, 0, 0, 0), 0))
        elif k == 'VSTORE':
            out.append(('TOKEN', OP_VSTORE, a[0], 0, tuple(a[1:5]), 0))
        elif k == 'LOAD':
            out.append(('TOKEN', OP_LOAD, a[0], 0, (0, 0, 0, 0), 0))
        elif k == 'VLOAD':
            out.append(('TOKEN', OP_VLOAD, a[0], 0, (0, 0, 0, 0), 0))
        elif k == 'VADD':                          # unsupported-token probe
            out.append(('TOKEN', OP_VADD, 0, 0, (0, 0, 0, 0), 0))
        elif k == 'GFXREG':
            out.append(('TOKEN', OP_GFXREG, a[0], a[1], (0, 0, 0, 0), 0))
        elif k == 'GFXCLEAR':
            out.append(('TOKEN', OP_GFXCLEAR, 0, a[1] if len(a) > 1 else 0, (0, 0, 0, 0), a[0]))
        elif k == 'GFXDRAW':
            out.append(('TOKEN', OP_GFXDRAW, 0, 0, (0, 0, 0, 0), 0))
        elif k == 'GFXRD':     # x y sel
            out.append(('TOKEN', OP_GFXRD, a[2] if len(a) > 2 else 0, (a[1] << 16) | a[0], (0, 0, 0, 0), 0))
        elif k == 'GFXSTAT':
            out.append(('TOKEN', OP_GFXSTAT, a[0], 0, (0, 0, 0, 0), 0))
        elif k == 'DFSYNC':
            out.append(('TOKEN', OP_DFSYNC, 0, 0, (0, 0, 0, 0), 0))
        else:
            raise ValueError(f"bad command: {ln}")
    return out


def run_cmd(path, W, H):
    """Replay a command file.  Returns dict(captures, results, model)."""
    m = SfgxModel(W, H)
    caps, results = {}, []
    for item in parse_cmd(path):
        if item[0] == 'CAPTURE':
            caps[item[1]] = (m.color.copy().reshape(H, W), m.depth.copy().reshape(H, W))
        else:
            _, op, addr, scalar, vec, length = item
            res, err = m.token(op, addr, scalar, vec, length)
            results.append((op, res, err))
    return dict(captures=caps, results=results, model=m)


def write_ppm(path, color2d):
    H, W = color2d.shape
    rgb = np.stack([(color2d >> 16) & 255, (color2d >> 8) & 255, color2d & 255], -1).astype(np.uint8)
    with open(path, 'wb') as f:
        f.write(b"P6\n%d %d\n255\n" % (W, H)); f.write(rgb.tobytes())


if __name__ == '__main__':
    if len(sys.argv) < 4:
        print("usage: sfgx_ref.py cmdfile W H [outdir]"); sys.exit(1)
    r = run_cmd(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]))
    out = sys.argv[4] if len(sys.argv) > 4 else '.'
    for n, (c, d) in r['captures'].items():
        write_ppm(f"{out}/{n}.ref.ppm", c)
    print({k: v for k, v in r['model'].cnt.items()}, "flags", r['model'].flags)
