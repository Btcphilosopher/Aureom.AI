#!/usr/bin/env python3
"""
sfgx_float_ref.py - *ideal* (float64) rasteriser used to cross-check the
fixed-point specification.  It shares only the command-file parser with
sfgx_ref.py; transform, clipping, viewport, coverage and interpolation are
re-implemented here with real arithmetic.

It is NOT expected to match bit-for-bit.  compare() classifies every
difference:
   * coverage / winner differences must lie within TOL_EDGE_PX of a triangle
     edge (quantisation of vertices to 1/256 px moves an edge < 0.01 px);
   * colour / depth differences on commonly-covered pixels must be small.
Anything else is reported as 'unexplained' and fails the check.
"""
from __future__ import annotations
import numpy as np
from sfgx_ref import (parse_cmd, OP_STORE, OP_VSTORE, OP_GFXMEM, OP_GFXTEX, OP_GFXREG, OP_GFXCLEAR, OP_GFXDRAW,
                      R_VTX_STRIDE, R_TEX_CTRL, CTRL_TEX_EN, CTRL_TEX_MOD, CTRL_TEX_CLAMP,
                      R_CTRL, R_VTX_BASE, R_TRI_BASE, R_NUM_TRI, R_CLEAR_DEPTH, CTRL_DEFAULT,
                      CTRL_ZTEST, CTRL_ZWRITE, CTRL_ZFUNC_SH, CTRL_CULL_SH, CTRL_FRONT_CW,
                      s32, DEPTH_MAX, SRAM_DEPTH)

TOL_EDGE_PX = 0.02
SNAP = True          # snap window vertex positions to the specified 1/256 px grid (see docs/02_NUMERIC_SPEC.md)


class FloatModel:
    def __init__(self, W, H):
        self.W, self.H = W, H
        self.mem = [0] * SRAM_DEPTH
        self.M = np.eye(4)
        self.ctrl, self.vb, self.tb, self.nt, self.cd = CTRL_DEFAULT, 0, 0, 0, DEPTH_MAX
        self.color = np.zeros((H, W, 3))
        self.depth = np.zeros((H, W))
        self.tiemin = np.full((H, W), 1e9)   # min |z_new - z_old| vs previously written geometry
        self.texbnd = np.full((H, W), 1e9)   # distance (texels) of the winning sample from a texel boundary
        self.stride, self.tex_log2 = 4, 0x55
        self.tex = np.zeros(4096, dtype=np.int64)
        self.written = np.zeros((H, W), bool)
        self.tris = []               # screen-space triangles of last draw (for edge distance)

    def token(self, op, addr, scalar, vec, length):
        if op in (OP_STORE, OP_GFXMEM):
            if addr < SRAM_DEPTH: self.mem[addr] = scalar & 0xFFFFFFFF      # out-of-range: error path, verified RTL==ref only
        elif op == OP_GFXTEX:
            if addr < 4096: self.tex[addr] = scalar & 0xFFFFFF
        elif op == OP_VSTORE:
            if addr + 3 < SRAM_DEPTH:
                for i in range(4): self.mem[addr + i] = vec[i] & 0xFFFFFFFF
        elif op == OP_GFXREG:
            if addr < 16: self.M.flat[addr] = s32(scalar) / 65536.0
            elif addr == R_CTRL: self.ctrl = scalar & 0x7FF
            elif addr == R_VTX_STRIDE:
                if 4 <= scalar <= 64: self.stride = scalar
            elif addr == R_TEX_CTRL:
                if (scalar & 15) <= 6 and ((scalar >> 4) & 15) <= 6: self.tex_log2 = scalar & 0xFF
            elif addr == R_VTX_BASE: self.vb = scalar
            elif addr == R_TRI_BASE: self.tb = scalar
            elif addr == R_NUM_TRI: self.nt = scalar
            elif addr == R_CLEAR_DEPTH: self.cd = scalar & 0xFFFF
        elif op == OP_GFXCLEAR:
            if length & 1:
                c = scalar & 0xFFFFFF
                self.color[:] = [(c >> 16) & 255, (c >> 8) & 255, c & 255]
            if length & 2: self.depth[:] = self.cd
        elif op == OP_GFXDRAW:
            self.draw()

    # ---------------------------------------------------------------
    def draw(self):
        for t in range(self.nt):
            tw = self.mem[self.tb + t]
            vs = []
            for k in range(3):
                i = (tw >> (10 * k)) & 0x3FF
                a = self.vb + i * self.stride
                x, y, z = (s32(self.mem[a + j]) / 65536.0 for j in range(3))
                col = self.mem[a + 3]
                c = np.array([(col >> 16) & 255, (col >> 8) & 255, col & 255], float)
                uv = np.array([s32(self.mem[a + 4]) / 65536.0, s32(self.mem[a + 5]) / 65536.0]) \
                    if ((self.ctrl & CTRL_TEX_EN) and self.stride >= 6) else np.zeros(2)
                clip = self.M @ np.array([x, y, z, 1.0])
                vs.append(np.concatenate([clip, c, uv]))
            poly = vs
            for p in range(6):
                out = []
                n = len(poly)
                for i in range(n):
                    P, Q = poly[(i - 1) % n], poly[i]
                    d = lambda v: [v[3] + v[0], v[3] - v[0], v[3] + v[1], v[3] - v[1], v[3] + v[2], v[3] - v[2]][p]
                    dP, dQ = d(P), d(Q)
                    if dP >= 0 and dQ >= 0: out.append(Q)
                    elif dP >= 0 > dQ:
                        if dP > 0: out.append(P + (Q - P) * dP / (dP - dQ))
                    elif dP < 0 <= dQ:
                        if dQ > 0: out.append(P + (Q - P) * dP / (dP - dQ))
                        out.append(Q)
                poly = out
                if not poly: break
            if len(poly) < 3 or any(v[3] <= 0 for v in poly): continue
            sv = []
            for v in poly:
                w = v[3]
                X = np.clip((v[0] / w + 1) / 2, 0, 1) * self.W
                Y = np.clip((1 - v[1] / w) / 2, 0, 1) * self.H
                Z = np.clip((v[2] / w + 1) / 2, 0, 1) * DEPTH_MAX
                if SNAP:        # the spec fixes window X,Y to 1/256 px and Z to Q16.8: snap, then stay in float
                    X = np.floor(X * 256 + 0.5) / 256; Y = np.floor(Y * 256 + 0.5) / 256; Z = np.floor(Z * 256 + 0.5) / 256
                sv.append((X, Y, Z, v[4], v[5], v[6], v[7], v[8], w))
            for k in range(1, len(sv) - 1):
                self.raster(sv[0], sv[k], sv[k + 1])

    def raster(self, a, b, c):
        A2 = (b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])
        if A2 == 0: return
        front = (A2 < 0) if not (self.ctrl & CTRL_FRONT_CW) else (A2 > 0)
        cull = (self.ctrl >> CTRL_CULL_SH) & 3
        if (cull == 1 and not front) or (cull == 2 and front): return
        if A2 < 0: b, c, A2 = c, b, -A2
        V = [a, b, c]
        self.tris.append(V)
        ys, xs = np.mgrid[0:self.H, 0:self.W]
        px, py = xs + 0.5, ys + 0.5
        E = []; tl = []; dxs = []; dys = []
        for i in range(3):
            p, q = V[i], V[(i + 1) % 3]
            dx, dy = q[0] - p[0], q[1] - p[1]
            dxs.append(dx); dys.append(dy)
            E.append(dx * (py - p[1]) - dy * (px - p[0]))
            tl.append(dy < 0 or (dy == 0 and dx > 0))
        cov = np.ones((self.H, self.W), bool)
        for i in range(3):
            cov &= (E[i] > 0) | ((E[i] == 0) & tl[i])
        l0, l1, l2 = E[1] / A2, E[2] / A2, E[0] / A2
        z = l0 * V[0][2] + l1 * V[1][2] + l2 * V[2][2]
        zq = np.clip(np.floor(z + 0.5), 0, DEPTH_MAX)
        col = np.stack([np.clip(np.floor((l0 * V[0][3 + k] + l1 * V[1][3 + k] + l2 * V[2][3 + k]) + 0.5), 0, 255)
                        for k in range(3)], -1)
        cmp = cov & self.written
        self.tiemin[cmp] = np.minimum(self.tiemin[cmp], np.abs(zq - self.depth)[cmp])
        if self.ctrl & CTRL_ZTEST:
            f = (self.ctrl >> CTRL_ZFUNC_SH) & 7
            ok = [np.zeros_like(cov), zq < self.depth, zq == self.depth, zq <= self.depth,
                  zq > self.depth, zq != self.depth, zq >= self.depth, np.ones_like(cov)][f]
        else:
            ok = np.ones_like(cov)
        w = cov & ok
        if self.ctrl & CTRL_TEX_EN:
            # perspective-correct: interpolate u/w, v/w, 1/w with the screen-space weights, then divide
            iw = [1.0 / V[i][8] for i in range(3)]
            q = l0 * iw[0] + l1 * iw[1] + l2 * iw[2]
            su = l0 * V[0][6] * iw[0] + l1 * V[1][6] * iw[1] + l2 * V[2][6] * iw[2]
            sv_ = l0 * V[0][7] * iw[0] + l1 * V[1][7] * iw[1] + l2 * V[2][7] * iw[2]
            with np.errstate(divide='ignore', invalid='ignore'):
                u, v = su / q, sv_ / q
            wl, hl = self.tex_log2 & 15, (self.tex_log2 >> 4) & 15
            fx, fy = u * (1 << wl), v * (1 << hl)
            fx = np.nan_to_num(fx); fy = np.nan_to_num(fy)
            tx_f, ty_f = np.floor(fx).astype(np.int64), np.floor(fy).astype(np.int64)
            if self.ctrl & CTRL_TEX_CLAMP: tx = np.clip(tx_f, 0, (1 << wl) - 1); ty = np.clip(ty_f, 0, (1 << hl) - 1)
            else: tx = tx_f & ((1 << wl) - 1); ty = ty_f & ((1 << hl) - 1)
            texel = self.tex[(ty << wl) | tx]
            tr, tg, tb = (texel >> 16) & 255, (texel >> 8) & 255, texel & 255
            if self.ctrl & CTRL_TEX_MOD:
                tr, tg, tb = ((tr * col[..., 0] + 127) // 255, (tg * col[..., 1] + 127) // 255, (tb * col[..., 2] + 127) // 255)
            col = np.stack([tr, tg, tb], -1).astype(float)
            fr = lambda a: np.minimum(a - np.floor(a), np.ceil(a) - a)
            bnd = np.minimum(fr(fx), fr(fy))
            # texel-coordinate gradient (texels / pixel), analytic: u = su/q  =>  du = (dsu - u dq) / q
            dlx = np.array([-dys[1], -dys[2], -dys[0]]) / A2
            dly = np.array([dxs[1], dxs[2], dxs[0]]) / A2
            uw = [V[i][6] * iw[i] for i in range(3)]; vw_ = [V[i][7] * iw[i] for i in range(3)]
            def grad(dl):
                dq = sum(dl[i] * iw[i] for i in range(3)); dsu = sum(dl[i] * uw[i] for i in range(3)); dsv = sum(dl[i] * vw_[i] for i in range(3))
                return np.abs((dsu - u * dq) / q) * (1 << wl) + np.abs((dsv - v * dq) / q) * (1 << hl)
            with np.errstate(divide='ignore', invalid='ignore'):
                mag = np.nan_to_num(grad(dlx) + grad(dly))
            # one step of the specified 1/256 px vertex grid moves the sample by about mag/256 texels
            self.texbnd[w] = (bnd - mag / 256.0)[w]
        else:
            self.texbnd[w] = 1e9
        self.color[w] = col[w]
        if self.ctrl & CTRL_ZWRITE:
            self.depth[w] = zq[w]; self.written[w] = True


def run_float(path, W, H):
    m = FloatModel(W, H)
    caps = {}
    for it in parse_cmd(path):
        if it[0] == 'CAPTURE':
            caps[it[1]] = (m.color.copy(), m.depth.copy(), list(m.tris), m.tiemin.copy(), m.texbnd.copy())
        else:
            _, op, addr, scalar, vec, length = it
            m.token(op, addr, scalar, vec, length)
    return caps


def edge_dist_map(tris, W, H):
    """distance (px) from every pixel centre to the nearest triangle edge segment."""
    ys, xs = np.mgrid[0:H, 0:W]
    px, py = xs + 0.5, ys + 0.5
    best = np.full((H, W), 1e9)
    for V in tris:
        for i in range(3):
            p, q = np.array(V[i][:2]), np.array(V[(i + 1) % 3][:2])
            d = q - p; L2 = d @ d
            t = np.zeros_like(px) if L2 == 0 else np.clip(((px - p[0]) * d[0] + (py - p[1]) * d[1]) / L2, 0, 1)
            cx, cy = p[0] + t * d[0], p[1] + t * d[1]
            best = np.minimum(best, np.hypot(px - cx, py - cy))
    return best


ZTIE_LSB = 6      # near-tie window (Z16 LSBs) in which the winner of a depth test may legitimately flip


TEX_BND = 0.06    # texels: a sample this close to a texel boundary may legitimately fall in the neighbouring texel


def compare(int_color, int_depth, fcolor, fdepth, ftris, W, H, tol_edge=TOL_EDGE_PX, tiemin=None, texbnd=None):
    """Return a dict of statistics; 'unexplained' must be 0 for a pass."""
    icol = np.stack([(int_color >> 16) & 255, (int_color >> 8) & 255, int_color & 255], -1).astype(float)
    diff_pix = np.any(icol != fcolor, axis=-1)
    dist = edge_dist_map(ftris, W, H)
    big = np.abs(icol - fcolor).max(-1)
    # a pixel difference is explained if it is near an edge, or tiny (<=1 LSB rounding)
    ztie = (tiemin <= ZTIE_LSB) if tiemin is not None else np.zeros_like(diff_pix)
    tbnd = (texbnd <= TEX_BND) if texbnd is not None else np.zeros_like(diff_pix)
    explained = (dist <= tol_edge) | (big <= 1) | ztie | tbnd
    unexplained = diff_pix & ~explained
    return dict(pixels=W * H, differing=int(diff_pix.sum()),
                near_edge=int((diff_pix & (dist <= tol_edge)).sum()),
                lsb1_only=int((diff_pix & (big <= 1) & ~(dist <= tol_edge)).sum()),
                z_tie=int((diff_pix & ztie & ~(dist <= tol_edge) & ~(big <= 1)).sum()),
                tex_boundary=int((diff_pix & tbnd & ~ztie & ~(dist <= tol_edge) & ~(big <= 1)).sum()),
                max_colour_diff_away_from_edges=float(np.where(dist > tol_edge, big, 0).max()),
                max_depth_diff_away_from_edges=float(np.where(dist > tol_edge, np.abs(int_depth.astype(float) - fdepth), 0).max()),
                unexplained=int(unexplained.sum()))
