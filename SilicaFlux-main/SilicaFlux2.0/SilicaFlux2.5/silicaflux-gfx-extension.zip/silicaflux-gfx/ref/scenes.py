#!/usr/bin/env python3
"""
scenes.py - command-stream generator for SFGX tests and demos.

Produces .cmd files (see sfgx_ref.parse_cmd) that are replayed identically by
  * ref/sfgx_ref.py       (bit-accurate software reference)
  * tb/sfgx_harness.cpp   (Verilator replay of the RTL)

Directed tests (shared edges, clip boundaries, culling, depth) use a power-of-
two framebuffer so that any Q8 screen coordinate is exactly representable in
Q16.16 NDC; that makes "edge passes exactly through a pixel centre" cases
reproducible rather than accidental.
"""
from __future__ import annotations
import math, os, random, sys
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from sfgx_ref import (R_MAT0, R_CTRL, R_VTX_BASE, R_TRI_BASE, R_NUM_TRI, R_CLEAR_DEPTH, R_STATS_CLR, R_VTX_STRIDE, R_TEX_CTRL,
                      CTRL_ZTEST, CTRL_ZWRITE, CTRL_ZFUNC_SH, CTRL_CULL_SH, CTRL_FRONT_CW, SRAM_DEPTH)

Q = 65536


def q16(f):  return int(round(f * Q)) & 0xFFFFFFFF
def pack_rgb(r, g, b): return ((r & 255) << 16) | ((g & 255) << 8) | (b & 255)
def ctrl(ztest=1, zwrite=1, zfunc=1, cull=0, cw=0, tex=0, mod=0, clamp=0):
    return ((ztest << 0) | (zwrite << 1) | (zfunc << CTRL_ZFUNC_SH) | (cull << CTRL_CULL_SH) | (cw << 7)
            | (tex << 8) | (mod << 9) | (clamp << 10))


# ---- matrices (row-major, float -> Q16.16 words) ----------------------------
def m_identity(): return np.eye(4)
def m_translate(x, y, z):
    m = np.eye(4); m[:3, 3] = (x, y, z); return m
def m_scale(x, y, z): return np.diag([x, y, z, 1.0])
def m_rot_y(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1.0]])
def m_rot_x(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1.0]])
def m_rot_z(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0, 0], [s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1.0]])
def m_perspective(fovy_deg, aspect, near, far):
    f = 1.0 / math.tan(math.radians(fovy_deg) / 2)
    return np.array([[f / aspect, 0, 0, 0], [0, f, 0, 0],
                     [0, 0, (far + near) / (near - far), 2 * far * near / (near - far)],
                     [0, 0, -1, 0]])


# Found by random search against the reference model (seed 5): an intersection vertex whose rounded plane
# distance is -1 LSB.  Each entry = (16 matrix words Q16.16 row-major, 3 object-space vertices (x,y,z) Q16.16).
NEG_DIST_CASES = [
    ([-666334, 959369, 676944, 969092, -561136, 215260, -786106, -710525, 695764, -993944, 834395, 122456, 679546, 318826, -981647, -212591], [(-209563, 243505, -141373), (215973, 70231, -194899), (-154624, -201837, 164443)]),   # plane 2, d=-1
    ([299377, 335177, 775739, 125846, -627529, -305706, 329461, -639992, -410170, -484795, 830779, 164902, -756643, -392178, -152865, 920273], [(176403, -183007, 156898), (-147452, 163338, -139413), (128212, -163492, -103501)]),   # plane 2, d=-1
    ([-42796, 541783, -246995, 370886, -61664, 196677, 683347, -171094, -969936, 564833, 218201, -644882, -4937, -747104, -874963, 801719], [(-57313, -116532, 152247), (-127263, 260058, 82884), (-117247, -250285, -90127)]),   # plane 5, d=-1
    ([-194301, -530680, -686837, 908523, -86386, 727625, -933503, -538104, 320760, -114776, -583732, 270713, -696120, 809324, -465116, 300996], [(-147951, 252073, 244611), (163593, 105835, -230412), (102396, -233915, -211478)]),   # plane 1, d=-1
    ([-911223, 752392, -831194, 937792, 49841, -86714, -81385, 15963, -237249, -210040, -449815, 598105, -373004, -816124, 1008247, -396954], [(-195359, 101389, -16071), (-157784, -116826, 81578), (228703, 97606, 232056)]),   # plane 1, d=-1
    ([363328, -872915, 842250, 57699, -126637, 262640, 504858, 130033, -890480, 879088, -949771, -728746, -351286, -950034, 529362, -1005579], [(220618, 18103, 242181), (48527, -126211, -222891), (-126472, -200933, -10091)]),   # plane 4, d=-1
]


class Cmd:
    """Accumulates tokens; mesh batches respect the 256-word scratchpad."""
    def __init__(self, path):
        self.f = open(path, 'w')
        self.nv = 0
        self.verts, self.tris = [], []

    def w(self, s): self.f.write(s + "\n")
    def comment(self, s): self.w("# " + s)
    def reg(self, idx, val): self.w(f"GFXREG {idx:#x} {val & 0xFFFFFFFF:#x}")
    def matrix(self, M):
        for i, v in enumerate(np.asarray(M).reshape(16)): self.reg(R_MAT0 + i, q16(v))
    def matrix_raw(self, words):
        for i, v in enumerate(words): self.reg(R_MAT0 + i, v)
    def ctrl(self, **kw): self.reg(R_CTRL, ctrl(**kw))
    def clear(self, rgb=0, depth=0xFFFF):
        self.reg(R_CLEAR_DEPTH, depth); self.w(f"GFXCLEAR 3 {rgb:#x}")
    def capture(self, name): self.w(f"CAPTURE {name}")
    def stat(self, idx): self.w(f"GFXSTAT {idx}")
    def rd(self, x, y, sel=0): self.w(f"GFXRD {x} {y} {sel}")
    def stats_clear(self): self.reg(R_STATS_CLR, 0)

    # geometry -------------------------------------------------------------
    def vert(self, x, y, z, rgb):
        """add vertex (floats, object space); returns index"""
        self.verts.append((q16(x), q16(y), q16(z), rgb)); return len(self.verts) - 1
    def vert_q(self, xq, yq, zq, rgb):
        self.verts.append((xq & 0xFFFFFFFF, yq & 0xFFFFFFFF, zq & 0xFFFFFFFF, rgb)); return len(self.verts) - 1
    def vert_uv(self, x, y, z, rgb, u, v):
        """textured vertex (6-word record): position/colour as vert(), plus u,v (floats, Q16.16)"""
        self.verts.append((q16(x), q16(y), q16(z), rgb, q16(u), q16(v))); return len(self.verts) - 1
    def vert_uv_q(self, x, y, z, rgb, uq, vq):
        self.verts.append((x & 0xFFFFFFFF, y & 0xFFFFFFFF, z & 0xFFFFFFFF, rgb, uq & 0xFFFFFFFF, vq & 0xFFFFFFFF)); return len(self.verts) - 1
    def tri(self, a, b, c): self.tris.append((a, b, c))
    def stride(self):
        return max((len(v) for v in self.verts), default=4)
    def capacity_ok(self, extra_v=0, extra_t=0):
        return self.stride() * (len(self.verts) + extra_v) + len(self.tris) + extra_t <= SRAM_DEPTH
    def texture(self, texels, log2w, log2h):
        """upload an RGB888 texture (row-major list of 24-bit values) and set TEX_CTRL"""
        assert len(texels) == (1 << (log2w + log2h)) <= 4096
        for i, t in enumerate(texels): self.w(f"GFXTEX {i} {t & 0xFFFFFF:#x}")
        self.reg(R_TEX_CTRL, log2w | (log2h << 4))

    def flush(self):
        """upload pending mesh to the scratchpad and DRAW it"""
        if not self.tris: self.verts = []; return
        assert self.capacity_ok(), "batch exceeds scratchpad"
        st = self.stride()
        assert all(len(v) == st for v in self.verts), "mixed vertex strides in one batch"
        for i, rec in enumerate(self.verts):
            self.w(f"VSTORE {st * i} {rec[0]:#x} {rec[1]:#x} {rec[2]:#x} {rec[3]:#x}")
            for k in range(4, st): self.w(f"STORE {st * i + k} {rec[k]:#x}")
        self.reg(R_VTX_STRIDE, st)
        tb = st * len(self.verts)
        for i, (a, b, c) in enumerate(self.tris):
            self.w(f"STORE {tb + i} {(a | (b << 10) | (c << 20)):#x}")
        self.reg(R_VTX_BASE, 0); self.reg(R_TRI_BASE, tb); self.reg(R_NUM_TRI, len(self.tris))
        self.w("GFXDRAW"); self.w("DFSYNC")
        self.verts, self.tris = [], []

    def close(self): self.flush(); self.f.close()


def ndc(Xpx, W):  return 2.0 * Xpx / W - 1.0          # window X (px) -> NDC x
def ndcy(Ypx, H): return 1.0 - 2.0 * Ypx / H          # window Y (px, down) -> NDC y
def ndcz(Zn):     return 2.0 * Zn - 1.0               # depth 0..1 -> NDC z


# ---- procedural textures (every texel distinguishable, so any mis-addressing shows) -----------------
def tex_indexed(w, h):
    """texel (x,y) = (R: x scaled, G: y scaled, B: checker) - unique per texel for sizes <= 64"""
    return [pack_rgb(min(255, x * 255 // max(1, w - 1)), min(255, y * 255 // max(1, h - 1)), 255 if (x ^ y) & 1 else 40)
            for y in range(h) for x in range(w)]

def tex_bricks(w=32, h=32):
    out = []
    for y in range(h):
        for x in range(w):
            row = y // 8; xo = (x + (4 if row % 2 else 0)) % 16
            mortar = (y % 8 == 0) or (xo % 16 == 0)
            base = [(190, 70, 50), (170, 60, 45), (205, 85, 60)][((x + (4 if row % 2 else 0)) // 16 + row * 3) % 3]
            out.append(pack_rgb(200, 200, 190) if mortar else pack_rgb(*base))
    return out


# ===========================================================================
# Directed tests
# ===========================================================================
def gen_shared_edges(path, W=32, H=32):
    """Meshes of triangles sharing edges; used by the exactly-once-coverage
    property check (tests/check_properties.py) in addition to RTL==ref."""
    c = Cmd(path); c.comment(f"shared-edge meshes, {W}x{H}; identity matrix")
    c.matrix(m_identity()); c.ctrl(ztest=0, zwrite=0)       # depth test off: every coverage visible
    c.clear(0x000000)
    rnd = random.Random(1)
    meshes = {}

    def P(xq, yq): return (xq, yq)
    def mesh_quad(x0, y0, x1, y1, diag, cw):
        # quad (x0,y0)-(x1,y1) in Q8 window coords split along a diagonal
        a, b, cc, d = P(x0, y0), P(x1, y0), P(x1, y1), P(x0, y1)
        if diag == 0: tris = [(a, b, cc), (a, cc, d)]
        else:         tris = [(a, b, d), (b, cc, d)]
        if cw: tris = [(t[0], t[2], t[1]) for t in tris]
        return tris

    vcache = {}

    def vindex(p):
        # shared vertices: one record per distinct screen position per batch
        if p not in vcache:
            vcache[p] = c.vert(ndc(p[0] / 256.0, W), ndcy(p[1] / 256.0, H), 0.0, rnd.randrange(1 << 24))
        return vcache[p]

    cur = []

    def emit(tris, tag):
        cur.append((tag, tris))
        for t in tris:
            c.tri(*[vindex(p) for p in t])

    def end_group(name):
        c.flush(); vcache.clear(); c.capture(name)
        meshes[name] = list(cur); cur.clear()

    # 1) pixel-aligned quads, both diagonals, both windings: diagonals pass exactly through pixel centres
    emit(mesh_quad(2 * 256, 2 * 256, 10 * 256, 10 * 256, 0, 0), "quad_diag0_ccw")
    emit(mesh_quad(12 * 256, 2 * 256, 20 * 256, 10 * 256, 1, 0), "quad_diag1_ccw")
    emit(mesh_quad(2 * 256, 12 * 256, 10 * 256, 20 * 256, 0, 1), "quad_diag0_cw")
    emit(mesh_quad(12 * 256, 12 * 256, 20 * 256, 20 * 256, 1, 1), "quad_diag1_cw")
    end_group("shared_quads")
    c.clear(0x000000)
    # 2) half-pixel aligned quads (edges through pixel centres on both axes)
    emit(mesh_quad(2 * 256 + 128, 2 * 256 + 128, 9 * 256 + 128, 9 * 256 + 128, 0, 0), "quad_half_diag0")
    emit(mesh_quad(12 * 256 + 128, 2 * 256 + 128, 19 * 256 + 128, 9 * 256 + 128, 1, 0), "quad_half_diag1")
    # 3) fan of 8 triangles around a pixel-corner hub, and a fan around a pixel-centre hub
    for (hx, hy, tag) in ((8 * 256, 24 * 256, "fan_corner_hub"), (22 * 256 + 128, 24 * 256 + 128, "fan_centre_hub")):
        r = 6 * 256
        ring = [(hx + int(round(r * math.cos(2 * math.pi * k / 8))), hy + int(round(r * math.sin(2 * math.pi * k / 8)))) for k in range(8)]
        emit([((hx, hy), ring[k], ring[(k + 1) % 8]) for k in range(8)], tag)
    end_group("shared_fans")
    c.clear(0x000000)
    # 4) strips: horizontal and vertical shared edges at integer and half-integer boundaries
    emit([((2 * 256, 2 * 256), (14 * 256, 2 * 256), (2 * 256, 6 * 256)),
          ((14 * 256, 2 * 256), (14 * 256, 6 * 256), (2 * 256, 6 * 256)),
          ((2 * 256, 6 * 256), (14 * 256, 6 * 256), (8 * 256, 12 * 256))], "strip_horizontal_edges")
    emit([((18 * 256 + 128, 2 * 256 + 128), (18 * 256 + 128, 14 * 256 + 128), (24 * 256 + 128, 8 * 256 + 128)),
          ((18 * 256 + 128, 2 * 256 + 128), (24 * 256 + 128, 8 * 256 + 128), (30 * 256 + 128, 2 * 256 + 128))], "strip_vertical_halfpix")
    # 5) irregular shared-vertex mesh with sub-pixel (1/256) coordinates
    pts = [(rnd.randrange(2 * 256, 30 * 256), rnd.randrange(16 * 256, 30 * 256)) for _ in range(5)]
    hub = (16 * 256 + 37, 22 * 256 + 91)
    ordered = sorted(pts, key=lambda p: math.atan2(p[1] - hub[1], p[0] - hub[0]))
    emit([(hub, ordered[k], ordered[(k + 1) % 5]) for k in range(5)], "irregular_fan_subpixel")
    end_group("shared_misc")
    c.close()
    return meshes, (W, H)


def gen_clip(path, W=32, H=32):
    """Triangles straddling / touching / outside each clip plane."""
    c = Cmd(path); c.comment(f"clipping boundary cases, {W}x{H}")
    c.ctrl(ztest=0, zwrite=0)
    col = lambda i: pack_rgb(255 if i % 3 == 0 else 40, 255 if i % 3 == 1 else 40, 255 if i % 3 == 2 else 40)

    def vtx(x, y, z, i): return c.vert(x, y, z, col(i))
    cases = []

    def case(name, M, verts):
        c.flush(); c.clear(0x202020); c.matrix(M)
        idx = [vtx(*v, i) for i, v in enumerate(verts)]
        c.tri(*idx); c.flush(); c.capture(name); cases.append(name)

    I = m_identity()
    # identity matrix => clip coords = (x,y,z,1); planes are |x|,|y|,|z| <= 1
    case("inside", I, [(-0.5, -0.5, 0), (0.5, -0.5, 0), (0, 0.5, 0)])
    for ax, nm in ((0, "x"), (1, "y"), (2, "z")):
        for sgn, sn in ((1, "pos"), (-1, "neg")):
            def mk(off):
                p = [[-0.4, -0.4, 0.0], [0.4, -0.4, 0.0], [0.0, 0.4, 0.0]]
                # move vertex 0 along the axis by `off` (so it sits at sgn*off)
                p[0][ax] = sgn * off
                return [tuple(v) for v in p]
            case(f"{nm}_{sn}_vertex_on_plane", I, mk(1.0))               # exactly on plane: d == 0 -> inside
            case(f"{nm}_{sn}_vertex_just_inside", I, mk(1.0 - 1 / 65536))
            case(f"{nm}_{sn}_vertex_just_outside", I, mk(1.0 + 1 / 65536))
            case(f"{nm}_{sn}_straddle", I, mk(2.5))
    # fully outside each plane (all three vertices beyond)
    for ax, nm in ((0, "x"), (1, "y"), (2, "z")):
        for sgn, sn in ((1, "pos"), (-1, "neg")):
            p = [[-0.2, -0.2, 0.0], [0.2, -0.2, 0.0], [0.0, 0.2, 0.0]]
            for v in p: v[ax] = sgn * 1.5
            case(f"{nm}_{sn}_fully_outside", I, [tuple(v) for v in p])
    # edge exactly on the plane: two vertices at x = +1 (edge lies in the plane)
    case("edge_in_plane_xpos", I, [(1.0, -0.8, 0.0), (1.0, 0.8, 0.0), (0.2, 0.0, 0.0)])
    # triangle covering the whole viewport and far beyond (needs 4-plane clipping)
    case("covers_screen", I, [(-6.0, -6.0, 0.0), (6.0, -6.0, 0.0), (0.0, 7.0, 0.0)])
    # clipped by many planes -> polygon with many vertices
    case("corner_cut_many", I, [(-1.8, -0.3, -0.4), (1.7, -1.9, 0.5), (0.2, 1.8, 1.6)])
    case("big_cross_zfar", I, [(-3.0, -3.0, 2.0), (3.0, -3.0, -2.0), (0.0, 3.0, 0.0)])

    # edge lying exactly IN a plane (two vertices d == 0), third vertex outside: the polygon
    # degenerates to 2 vertices; with the long edge poking out of a second plane it regrows to 3
    for ax, nm in ((0, "x"), (1, "y"), (2, "z")):
        o = (ax + 1) % 3
        for sgn, sn in ((1, "pos"), (-1, "neg")):
            def pt(along, off):
                v = [0.0, 0.0, 0.0]; v[ax] = sgn * off; v[o] = along; return tuple(v)
            case(f"edge_in_plane_{nm}_{sn}_third_out", I, [pt(-0.8, 1.0), pt(0.8, 1.0), pt(0.0, 1.8)])
            case(f"edge_in_plane_{nm}_{sn}_regrow", I, [pt(-2.0, 1.0), pt(2.0, 1.0), pt(0.0, 1.8)])
            # a single vertex exactly on the plane, the other two outside: both intersections suppressed
            case(f"one_vertex_on_plane_{nm}_{sn}", I, [pt(0.0, 1.0), pt(0.5, 1.6), pt(-0.5, 1.6)])
            # two vertices on the plane and the third INSIDE: nothing to clip (d >= 0 everywhere)
            case(f"edge_in_plane_{nm}_{sn}_third_in", I, [pt(-0.8, 1.0), pt(0.8, 1.0), pt(0.0, 0.2)])
    # vertex at clip-space (0,0,0,0): inside every plane, but w == 0 -> rejected after clipping
    Mw0 = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, -1, 0.0]])
    case("origin_w_zero_rejected", Mw0, [(0, 0, 0), (0.2, 0.1, -0.5), (-0.2, 0.1, -0.5)])

    # intersection vertices whose rounded plane distance is -1 LSB (exercises the viewport lower clamp)
    for k, (Mw, vs) in enumerate(NEG_DIST_CASES):
        c.flush(); c.clear(0x202020); c.matrix_raw(Mw)
        idx = [c.vert_q(x, y, z, col(i)) for i, (x, y, z) in enumerate(vs)]
        c.tri(*idx); c.flush(); c.capture(f"neg_dist_after_clip_{k}"); cases.append(f"neg_dist_after_clip_{k}")

    # perspective cases: w = -z_eye.  camera at origin looking down -z
    Pm = m_perspective(60.0, W / H, 1.0, 10.0)
    case("persp_inside", Pm, [(-1, -1, -4), (1, -1, -4), (0, 1, -4)])
    case("persp_near_plane_straddle", Pm, [(-1, -1, -0.5), (1, -1, -3), (0, 1, -3)])
    case("persp_behind_eye_vertex", Pm, [(-1, -1, -3), (1, -1, -3), (0, 1, 2.0)])
    case("persp_two_behind_eye", Pm, [(-1, -1, 2.0), (1, -1, 2.0), (0, 1, -3.0)])
    case("persp_all_behind_eye", Pm, [(-1, -1, 2), (1, -1, 2), (0, 1, 2)])
    case("persp_on_near_plane", Pm, [(-1, -1, -1.0), (1, -1, -1.0), (0, 1, -1.0)])
    case("persp_on_far_plane", Pm, [(-1, -1, -10.0), (1, -1, -10.0), (0, 1, -10.0)])
    case("persp_beyond_far", Pm, [(-1, -1, -12.0), (1, -1, -12.0), (0, 1, -12.0)])
    case("persp_floor_to_horizon", Pm, [(-6, -1, -0.8), (6, -1, -0.8), (0, -1, -30.0)])
    case("persp_w_zero_vertex", Pm, [(-1, -1, -3), (1, -1, -3), (0, 1, 0.0)])     # w == 0 exactly
    # coordinate overflow in the transform stage (saturation)
    c.flush(); c.clear(0x202020); c.matrix(m_scale(30000.0, 30000.0, 1.0))
    idx = [vtx(*v, i) for i, v in enumerate([(-2.0, -2.0, 0), (2.0, -2.0, 0), (0, 2.0, 0)])]   # 2*30000 > 32767
    c.tri(*idx); c.flush(); c.capture("xform_saturation"); cases.append("xform_saturation")
    c.stat(0)
    c.close()
    return cases, (W, H)


def gen_cull_depth(path, W=32, H=32):
    c = Cmd(path); c.comment("culling, winding, depth functions"); c.matrix(m_identity())
    tri_ccw = lambda z, rgb, dx=0.0: [c.vert(-0.6 + dx, -0.6, z, rgb), c.vert(0.6 + dx, -0.6, z, rgb), c.vert(0.0 + dx, 0.6, z, rgb)]
    tri_cw = lambda z, rgb, dx=0.0: [c.vert(-0.6 + dx, -0.6, z, rgb), c.vert(0.0 + dx, 0.6, z, rgb), c.vert(0.6 + dx, -0.6, z, rgb)]
    names = []
    for cull in (0, 1, 2):
        for cw in (0, 1):
            c.ctrl(ztest=0, zwrite=0, cull=cull, cw=cw); c.clear(0)
            a = tri_ccw(0, 0xFF0000, -0.3); c.tri(*a)
            b = tri_cw(0, 0x0000FF, 0.3); c.tri(*b)
            c.flush(); n = f"cull{cull}_cw{cw}"; c.capture(n); names.append(n)
    # depth functions: draw a far green triangle then a near red one overlapping, then equal-depth blue
    for zf in range(8):
        c.ctrl(ztest=1, zwrite=1, zfunc=zf); c.clear(0)
        a = [c.vert(-0.8, -0.8, 0.5, 0x00FF00), c.vert(0.8, -0.8, 0.5, 0x00FF00), c.vert(0.0, 0.8, 0.5, 0x00FF00)]
        c.tri(*a); c.flush()
        b = [c.vert(-0.6, -0.6, -0.2, 0xFF0000), c.vert(0.9, -0.5, 0.2, 0xFF0000), c.vert(0.0, 0.9, 0.8, 0xFF0000)]
        c.tri(*b); c.flush()
        d = [c.vert(-0.9, -0.2, 0.5, 0x0000FF), c.vert(0.9, -0.2, 0.5, 0x0000FF), c.vert(0.0, -0.9, 0.5, 0x0000FF)]
        c.tri(*d); c.flush()
        n = f"zfunc{zf}"; c.capture(n); names.append(n)
    # depth write disabled / depth test disabled
    c.ctrl(ztest=1, zwrite=0, zfunc=1); c.clear(0)
    a = [c.vert(-0.8, -0.8, 0.5, 0x00FF00), c.vert(0.8, -0.8, 0.5, 0x00FF00), c.vert(0.0, 0.8, 0.5, 0x00FF00)]
    c.tri(*a); c.flush()
    b = [c.vert(-0.7, -0.7, 0.9, 0xFF0000), c.vert(0.7, -0.7, 0.9, 0xFF0000), c.vert(0.0, 0.7, 0.9, 0xFF0000)]
    c.tri(*b); c.flush(); c.capture("zwrite_off"); names.append("zwrite_off")
    c.stat(0); c.stat(1); c.stat(8); c.stat(9); c.stat(10); c.stat(11)
    c.rd(16, 16, 0); c.rd(16, 16, 1)
    c.close()
    return names, (W, H)


def gen_errors(path, W=32, H=32):
    """address-range protection, bad tokens, GFXCLEAR flag variants, LOAD/VLOAD round trips."""
    c = Cmd(path); c.comment("error paths / token-level behaviour")
    w = c.w
    w("GFXMEM 5 0xCAFE0005"); w("GFXMEM 300 0x1"); w("LOAD 5"); w("GFXMEM 255 0x7F7F7F7F"); w("LOAD 255")
    w("STORE 255 0xA5A5A5A5"); w("STORE 256 0x11111111"); w("STORE 16383 0x22222222"); w("STORE 0 0x600DF00D")
    w("LOAD 255"); w("LOAD 256"); w("LOAD 0")
    w("VSTORE 252 0x1 0x2 0x3 0x4"); w("VSTORE 253 0x5 0x6 0x7 0x8"); w("VSTORE 255 0x9 0xA 0xB 0xC")
    w("VLOAD 252"); w("VLOAD 253"); w("LOAD 252"); w("LOAD 255")
    w("VADD"); w("GFXREG 0x30 5"); w("GFXREG 0x17 5"); w("GFXRD 0 0 2"); w("GFXRD 32 0 0"); w("GFXRD 0 32 1"); w("GFXRD 31 31 0")
    w("GFXSTAT 0"); w("GFXSTAT 99"); w("GFXSTAT 13"); w("GFXSTAT 12")
    c.stats_clear(); w("GFXSTAT 0")
    # a draw whose triangle words / vertex indices fall outside the scratchpad.
    # Vertices live at words 4.. (VTX_BASE = 4); words 0 and 1 hold VALID triangle words, so that an
    # out-of-range triangle-word fetch (256, 257) which the base memory_controller would silently alias to
    # words 0/1 would draw visible extra triangles if the bounds check were wrong.
    c.matrix(m_identity()); c.ctrl(ztest=0, zwrite=0); c.clear(0x102030)
    for i in range(3):
        w(f"VSTORE {4 + 4 * i} {q16(-0.5 + 0.5 * i):#x} {q16(-0.5 + 0.7 * (i % 2)):#x} 0x0 {0xFF0000 >> (8 * (i % 3)):#x}")
    good = 0 | (1 << 10) | (2 << 20)
    w(f"STORE 0 {good:#x}"); w(f"STORE 1 {good:#x}")
    w(f"STORE 250 {good:#x}")                              # good triangle word at 250
    w(f"STORE 251 {0 | (1 << 10) | (62 << 20):#x}")       # vertex index 62 -> word 4+248 = 252: last valid vertex slot
    w(f"STORE 252 {0 | (1 << 10) | (63 << 20):#x}")       # vertex index 63 -> word 256: rejected
    w(f"STORE 253 {5 | (6 << 10) | (700 << 20):#x}")      # far outside
    c.reg(R_VTX_BASE, 4); c.reg(R_TRI_BASE, 250); c.reg(R_NUM_TRI, 8)   # words 250..257: 256 and 257 out of range
    w("GFXDRAW"); w("DFSYNC"); c.capture("err_draw")
    for i in (0, 1, 2, 3, 4, 8): w(f"GFXSTAT {i}")
    # GFXCLEAR flag variants (colour only / depth only / nothing)
    c.stats_clear(); c.ctrl(ztest=1, zwrite=1, zfunc=1); c.reg(R_VTX_BASE, 4); c.reg(R_TRI_BASE, 250); c.reg(R_NUM_TRI, 1)
    c.clear(0x405060); w("GFXDRAW"); c.capture("clear_both_drawn")
    c.reg(R_CLEAR_DEPTH, 0x1234); w("GFXCLEAR 1 0x00FF00"); c.capture("clear_colour_only")
    w("GFXCLEAR 2 0xFFFFFF"); c.capture("clear_depth_only")
    w("GFXCLEAR 0 0xFFFFFF"); c.capture("clear_nothing")
    w("GFXRD 16 16 0"); w("GFXRD 16 16 1"); w("GFXRD 1 1 1")
    c.close()
    return (W, H)


# ===========================================================================
# test manifest: (scene file stem, generator, W, H)
# ===========================================================================
def manifest():
    m = [("shared_edges", 32, 32), ("clip_cases", 32, 32), ("cull_depth", 32, 32), ("errors", 32, 32),
         ("demo_triangle", 160, 120), ("demo_scene", 160, 120)]
    for i, (w, h) in enumerate([(40, 30), (37, 23), (64, 48), (21, 17)]): m.append((f"random_screen_s{i + 1}", w, h))
    for i, (w, h) in enumerate([(48, 36), (33, 45), (100, 75)]): m.append((f"random_persp_s{i + 1}", w, h))
    m.append(("big_fb", 640, 480))
    m += [("texture", 64, 64), ("random_tex_s1", 48, 36), ("random_tex_s2", 31, 29), ("demo_textured", 160, 120)]
    return m


# ===========================================================================
# Texture scenes (milestone 2)
# ===========================================================================
def quad_uv(c, x0, y0, x1, y1, z, u0, v0, u1, v1, rgb=0xFFFFFF, rgb2=None):
    """screen-aligned quad in NDC, two triangles, CCW; uv given for the corners (y up in NDC)."""
    rgb2 = rgb if rgb2 is None else rgb2
    a = c.vert_uv(x0, y0, z, rgb, u0, v1); b = c.vert_uv(x1, y0, z, rgb2, u1, v1)
    d = c.vert_uv(x1, y1, z, rgb, u1, v0); e = c.vert_uv(x0, y1, z, rgb2, u0, v0)
    c.tri(a, b, d); c.tri(a, d, e)


def gen_texture(path, W=64, H=64):
    c = Cmd(path); c.comment(f"texture sampling directed tests {W}x{H}")
    I = m_identity(); names = []

    def shot(name):
        c.flush(); c.capture(name); names.append(name)

    c.matrix(I)
    tex16 = tex_indexed(16, 16)
    c.texture(tex16, 4, 4)
    # 1. head-on quad, 1:1 mapping, REPLACE / REPEAT
    c.ctrl(ztest=0, zwrite=0, tex=1, mod=0, clamp=0); c.clear(0x101820)
    quad_uv(c, -0.875, -0.875, 0.875, 0.875, 0.0, 0, 0, 1, 1); shot("tex_replace_16")
    # 2. MODULATE with a colour gradient across the quad
    c.ctrl(ztest=0, zwrite=0, tex=1, mod=1, clamp=0); c.clear(0x101820)
    quad_uv(c, -0.875, -0.875, 0.875, 0.875, 0.0, 0, 0, 1, 1, rgb=0xFF8040, rgb2=0x40C0FF); shot("tex_modulate")
    # 3. REPEAT (uv 0..3) and negative / over-range uv, REPEAT vs CLAMP
    c.ctrl(ztest=0, zwrite=0, tex=1, mod=0, clamp=0); c.clear(0x101820)
    quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.0, 0, 0, 3, 3); shot("tex_repeat_3x")
    c.clear(0x101820); quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.0, -0.5, -0.5, 1.5, 1.5); shot("tex_repeat_negative")
    c.ctrl(ztest=0, zwrite=0, tex=1, mod=0, clamp=1); c.clear(0x101820)
    quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.0, -0.5, -0.5, 1.5, 1.5); shot("tex_clamp_edges")
    # 4. non-square texture 8 x 32 (log2 3 x 5), then 1x1 and 64x64
    c.texture(tex_indexed(8, 32), 3, 5)
    c.ctrl(ztest=0, zwrite=0, tex=1, mod=0, clamp=0); c.clear(0x101820)
    quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.0, 0, 0, 2, 1); shot("tex_nonsquare_8x32")
    c.texture([0x336699], 0, 0); c.clear(0x101820)
    quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.0, 0, 0, 1, 1); shot("tex_1x1")
    c.texture(tex_indexed(64, 64), 6, 6); c.clear(0x101820)
    quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.0, 0, 0, 1, 1); shot("tex_64x64")
    # 5. exact texel boundaries: 2 texels per pixel (64-wide texture over a 32 px wide quad): every pixel
    #    centre sits exactly on a texel boundary -> exercises the floor(exact integer) path
    c.clear(0x101820)
    quad_uv(c, -0.5, -0.5, 0.5, 0.5, 0.0, 0, 0, 1, 1); shot("tex_exact_boundaries")
    # 6. perspective: ground plane to the horizon, checker, repeat; perspective-correct vs affine would differ visibly
    c.texture(tex_indexed(16, 16), 4, 4)
    Pm = m_perspective(60.0, W / H, 0.5, 40.0)
    c.matrix(Pm @ m_translate(0, -1.0, -2.0) @ m_rot_x(math.radians(8)))
    c.ctrl(ztest=1, zwrite=1, zfunc=1, tex=1, mod=1, clamp=0); c.clear(0x203050)
    a = c.vert_uv(-6, 0, 2, 0xFFFFFF, 0, 0); b = c.vert_uv(6, 0, 2, 0xFFFFFF, 6, 0)
    d = c.vert_uv(6, 0, -30, 0xC0C0C0, 6, 30); e = c.vert_uv(-6, 0, -30, 0xC0C0C0, 0, 30)
    c.tri(a, b, d); c.tri(a, d, e); shot("tex_perspective_ground")
    # 7. textured triangle crossing the near plane (uv interpolated through the clipper)
    c.matrix(Pm); c.ctrl(ztest=0, zwrite=0, tex=1, mod=0, clamp=0); c.clear(0x203050)
    a = c.vert_uv(-2, -1, -0.3, 0xFFFFFF, 0, 0); b = c.vert_uv(2, -1, -0.3, 0xFFFFFF, 4, 0); d = c.vert_uv(0, 1.5, -8, 0xFFFFFF, 2, 4)
    c.tri(a, b, d); shot("tex_near_plane_clip")
    # 8. depth interaction: textured quad behind a plain triangle and in front of it (only passing pixels are sampled)
    c.matrix(I); c.reg(R_VTX_STRIDE, 4)
    c.ctrl(ztest=1, zwrite=1, zfunc=1, tex=0); c.clear(0x101820)
    t0 = c.vert(-0.7, -0.7, 0.0, 0xFF0000); t1 = c.vert(0.7, -0.7, 0.0, 0x00FF00); t2 = c.vert(0.0, 0.8, 0.0, 0x0000FF)
    c.tri(t0, t1, t2); c.flush()
    c.ctrl(ztest=1, zwrite=1, zfunc=1, tex=1, mod=0)
    quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.3, 0, 0, 2, 2); shot("tex_behind_triangle")
    c.ctrl(ztest=1, zwrite=1, zfunc=1, tex=1, mod=0)
    quad_uv(c, -0.4, -0.4, 0.4, 0.4, -0.5, 0, 0, 1, 1); shot("tex_in_front")
    # 9. huge uv (+-100) and fractional boundaries, repeat then clamp
    c.ctrl(ztest=0, zwrite=0, tex=1, mod=1, clamp=0); c.clear(0x101820)
    quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.0, -100.5, -100.5, 100.5, 100.5, rgb=0xFFFFFF, rgb2=0x8080FF); shot("tex_huge_uv_repeat")
    c.ctrl(ztest=0, zwrite=0, tex=1, mod=1, clamp=1); c.clear(0x101820)
    quad_uv(c, -0.9, -0.9, 0.9, 0.9, 0.0, -100.5, -100.5, 100.5, 100.5, rgb=0xFFFFFF, rgb2=0x8080FF); shot("tex_huge_uv_clamp")
    # 10. mixed: texture enabled but only 4-word vertices (stride 4) -> u,v read as 0 (every pixel samples texel 0)
    c.reg(R_TEX_CTRL, 4 | (4 << 4))
    c.ctrl(ztest=0, zwrite=0, tex=1, mod=0); c.clear(0x101820)
    t0 = c.vert(-0.7, -0.7, 0.0, 0xFF0000); t1 = c.vert(0.7, -0.7, 0.0, 0x00FF00); t2 = c.vert(0.0, 0.8, 0.0, 0x0000FF)
    c.tri(t0, t1, t2); shot("tex_stride4_uv_zero")
    # 10b. clip-space w = 1 LSB (a matrix of raw LSB entries): q = 2^40/w exceeds 2^39 and must SATURATE (q and s alike,
    #      so u = s/q stays 1.0); the quad then samples the right/top edge texels
    c.matrix_raw([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1])
    c.reg(R_TEX_CTRL, 4 | (4 << 4)); c.ctrl(ztest=0, zwrite=0, tex=1, mod=0, clamp=0); c.clear(0x101820)
    quad_uv(c, -1.0, -1.0, 1.0, 1.0, 0.0, 0, 0, 1, 1); shot("tex_w_one_lsb_q_saturates")
    c.matrix(I)
    # 11. error paths and statistics
    w = c.w
    w(f"GFXREG {R_TEX_CTRL:#x} 0x47"); w(f"GFXREG {R_TEX_CTRL:#x} 0x74")        # log2 7: rejected
    w(f"GFXREG {R_VTX_STRIDE:#x} 3"); w(f"GFXREG {R_VTX_STRIDE:#x} 65"); w(f"GFXREG {R_VTX_STRIDE:#x} 4")
    w("GFXTEX 4095 0xABCDEF"); w("GFXTEX 4096 0x1"); w("GFXTEX 16383 0x2")
    for i in (0, 9, 11, 14): w(f"GFXSTAT {i}")
    w("GFXRD 32 32 0")
    c.close()
    return names, (W, H)


def gen_random_tex(path, W=48, H=36, n=400, seed=21):
    rnd = random.Random(seed)
    c = Cmd(path); c.comment(f"random textured triangles n={n} seed={seed} {W}x{H}")
    c.clear(0x000000)
    k = 0; batch = 0
    sizes = [(0, 0), (3, 3), (4, 4), (5, 3), (2, 6), (6, 2), (3, 5), (5, 5)]
    while k < n:
        c.flush(); batch += 1
        lw, lh = rnd.choice(sizes)
        texels = [rnd.randrange(1 << 24) for _ in range(1 << (lw + lh))]
        c.texture(texels, lw, lh)
        P = m_perspective(rnd.uniform(40, 95), W / H, rnd.choice([0.3, 0.5, 1.0]), rnd.choice([20.0, 60.0]))
        V = m_translate(rnd.uniform(-1, 1), rnd.uniform(-1, 1), rnd.uniform(-8, -1.5)) @ m_rot_y(rnd.uniform(0, 6.28)) @ m_rot_x(rnd.uniform(-1, 1))
        c.matrix(P @ V)
        c.ctrl(ztest=rnd.random() < 0.8, zwrite=1, zfunc=rnd.choice([1, 1, 3]), cull=rnd.choice([0, 0, 1]), cw=0,
               tex=1, mod=rnd.randrange(2), clamp=rnd.randrange(2))
        urange = rnd.choice([1.0, 3.0, 8.0, 60.0])
        for _ in range(24):
            if k >= n: break
            if not c.capacity_ok(3, 1): break
            sc = rnd.choice([0.6, 1.5, 3.0, 7.0]); cx, cy, cz = (rnd.uniform(-3, 3) for _ in range(3))
            idx = [c.vert_uv(cx + rnd.uniform(-sc, sc), cy + rnd.uniform(-sc, sc), cz + rnd.uniform(-sc, sc), rnd.randrange(1 << 24),
                             rnd.uniform(-urange, urange), rnd.uniform(-urange, urange)) for _ in range(3)]
            c.tri(*idx); k += 1
        c.flush()
        if batch % 4 == 0: c.capture(f"rand_tex_{batch}")
    c.capture("rand_tex_final"); c.stat(0); c.stat(10); c.stat(11); c.stat(14)
    c.close()
    return (W, H)


def gen_demo_textured(path, W=160, H=120, frames=36):
    """brick-textured cubes (perspective-correct, modulated by vertex colour) over a plain ground."""
    c = Cmd(path); c.comment(f"textured 3D scene demo {W}x{H}")
    P = m_perspective(55.0, W / H, 0.5, 30.0)
    c.texture(tex_bricks(32, 32), 5, 5)
    shade = [0xFFFFFF, 0xE0E0E0, 0xC8C8D8, 0xFFE8D0, 0xD0E8FF, 0xB0B0B0]
    faces = [((-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)), ((1, -1, -1), (-1, -1, -1), (-1, 1, -1), (1, 1, -1)),
             ((-1, -1, -1), (-1, -1, 1), (-1, 1, 1), (-1, 1, -1)), ((1, -1, 1), (1, -1, -1), (1, 1, -1), (1, 1, 1)),
             ((-1, 1, 1), (1, 1, 1), (1, 1, -1), (-1, 1, -1)), ((-1, -1, -1), (1, -1, -1), (1, -1, 1), (-1, -1, 1))]
    uv = [(0, 1), (1, 1), (1, 0), (0, 0)]

    def textured_cube(s, k=1.0):
        for fi, f in enumerate(faces):
            ids = [c.vert_uv(s * p[0], s * p[1], s * p[2], shade[fi], uv[j][0] * k, uv[j][1] * k) for j, p in enumerate(f)]
            c.tri(ids[0], ids[1], ids[2]); c.tri(ids[0], ids[2], ids[3])

    for f in range(frames):
        a = 2 * math.pi * f / frames
        V = m_translate(0, -0.4, -6.5) @ m_rot_x(math.radians(22)) @ m_rot_y(0.3 * a)
        c.clear(0x0B1020)
        c.ctrl(ztest=1, zwrite=1, zfunc=1, cull=1, tex=0)
        c.matrix(P @ V)
        g = [c.vert(-5, -1.6, -5, 0x303848), c.vert(5, -1.6, -5, 0x303848), c.vert(5, -1.6, 5, 0x607080), c.vert(-5, -1.6, 5, 0x607080)]
        c.tri(g[0], g[2], g[1]); c.tri(g[0], g[3], g[2]); c.flush()
        c.ctrl(ztest=1, zwrite=1, zfunc=1, cull=1, tex=1, mod=1, clamp=0)
        c.matrix(P @ V @ m_translate(-1.5, 0.0, 0) @ m_rot_y(a * 2) @ m_rot_x(a))
        textured_cube(0.9, 1.0); c.flush()
        c.matrix(P @ V @ m_rot_y(-a) @ m_translate(2.3, 0.2, 0) @ m_rot_z(a * 1.5) @ m_rot_y(a))
        textured_cube(0.6, 2.0); c.flush()
        c.capture(f"texscene_{f:03d}")
    c.close()
    return (W, H, frames)


# ===========================================================================
# Randomised tests
# ===========================================================================
def gen_random_screen(path, W=40, H=30, n=600, seed=7):
    """random triangles with identity matrix; coordinates range beyond the
    viewport so that clipping engages; random colours / depths / state."""
    rnd = random.Random(seed)
    c = Cmd(path); c.comment(f"random screen-space triangles n={n} seed={seed} {W}x{H}")
    c.matrix(m_identity()); c.clear(0x000000)
    k = 0
    while k < n:
        if rnd.random() < 0.08:
            c.flush(); c.ctrl(ztest=rnd.random() < 0.8, zwrite=rnd.random() < 0.8, zfunc=rnd.randrange(8),
                              cull=rnd.randrange(3), cw=rnd.randrange(2))
        sc = rnd.choice([0.4, 1.0, 1.0, 1.6, 3.0])
        cx, cy = rnd.uniform(-1.2, 1.2), rnd.uniform(-1.2, 1.2)
        pts = []
        for _ in range(3):
            pts.append((cx + rnd.uniform(-sc, sc), cy + rnd.uniform(-sc, sc), rnd.uniform(-1.2, 1.2)))
        if not c.capacity_ok(3, 1): c.flush()
        idx = [c.vert(*p, rnd.randrange(1 << 24)) for p in pts]
        c.tri(*idx); k += 1
        if k % 150 == 0: c.flush(); c.capture(f"rand_screen_{k}")
    c.flush(); c.capture("rand_screen_final"); c.stat(0)
    for i in range(1, 12): c.stat(i)
    c.close()
    return (W, H)


def gen_random_persp(path, W=48, H=36, n=600, seed=11):
    """random object-space triangles under random rotation + perspective."""
    rnd = random.Random(seed)
    c = Cmd(path); c.comment(f"random perspective triangles n={n} seed={seed} {W}x{H}")
    c.clear(0x000000)
    k = 0
    while k < n:
        # new random view every batch
        c.flush()
        P = m_perspective(rnd.uniform(35, 100), W / H, rnd.choice([0.5, 1.0, 2.0]), rnd.choice([8.0, 20.0, 60.0]))
        V = m_translate(rnd.uniform(-1, 1), rnd.uniform(-1, 1), rnd.uniform(-9, -1)) @ m_rot_y(rnd.uniform(0, 6.28)) @ m_rot_x(rnd.uniform(-1, 1))
        c.matrix(P @ V)
        c.ctrl(ztest=1, zwrite=1, zfunc=rnd.choice([1, 1, 3]), cull=rnd.choice([0, 0, 1]), cw=0)
        for _ in range(30):
            if k >= n: break
            if not c.capacity_ok(3, 1): break
            sc = rnd.choice([0.5, 1.5, 3.0, 8.0])
            cx, cy, cz = (rnd.uniform(-3, 3) for _ in range(3))
            idx = [c.vert(cx + rnd.uniform(-sc, sc), cy + rnd.uniform(-sc, sc), cz + rnd.uniform(-sc, sc), rnd.randrange(1 << 24)) for _ in range(3)]
            c.tri(*idx); k += 1
        c.flush()
        if k % 120 == 0: c.capture(f"rand_persp_{k}")
    c.capture("rand_persp_final"); c.stat(0)
    for i in range(1, 12): c.stat(i)
    c.close()
    return (W, H)


# ===========================================================================
# Demos
# ===========================================================================
def gen_demo_triangle(path, W=160, H=120, frames=24):
    c = Cmd(path); c.comment(f"rotating triangle demo {W}x{H}")
    P = m_perspective(50.0, W / H, 1.0, 20.0)
    for f in range(frames):
        a = 2 * math.pi * f / frames
        M = P @ m_translate(0, 0, -3.0) @ m_rot_y(a)
        c.matrix(M); c.ctrl(ztest=1, zwrite=1, zfunc=1, cull=0)
        c.clear(0x14182A)
        i0 = c.vert(-1.0, -0.8, 0.0, 0xFF3030); i1 = c.vert(1.0, -0.8, 0.0, 0x30FF30); i2 = c.vert(0.0, 1.0, 0.0, 0x3060FF)
        c.tri(i0, i1, i2); c.flush(); c.capture(f"tri_{f:03d}")
    c.close()
    return (W, H, frames)


def cube_mesh(c, cx, cy, cz, s, face_cols):
    """8 shared vertices (per-corner colours), 12 triangles, CCW outward."""
    corners = [(-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1), (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)]
    idx = [c.vert(cx + s * x, cy + s * y, cz + s * z, face_cols[i % len(face_cols)]) for i, (x, y, z) in enumerate(corners)]
    faces = [(4, 5, 6, 7), (1, 0, 3, 2), (0, 4, 7, 3), (5, 1, 2, 6), (3, 7, 6, 2), (0, 1, 5, 4)]   # +z -z -x +x +y -y
    for (a, b, d, e) in faces:
        c.tri(idx[a], idx[b], idx[d]); c.tri(idx[a], idx[d], idx[e])


def gen_demo_scene(path, W=160, H=120, frames=36):
    """two cubes orbiting + a ground quad, perspective, depth test, back-face culling."""
    c = Cmd(path); c.comment(f"3D scene demo {W}x{H}")
    P = m_perspective(55.0, W / H, 0.5, 30.0)
    cols_a = [0xFF4040, 0x40FF40, 0x4040FF, 0xFFFF40, 0x40FFFF, 0xFF40FF, 0xFFFFFF, 0x808080]
    cols_b = [0xFFA030, 0x30A0FF, 0xA0FF30, 0xFF30A0, 0x30FFA0, 0xA030FF, 0xFFFFFF, 0x404040]
    for f in range(frames):
        a = 2 * math.pi * f / frames
        V = m_translate(0, -0.4, -6.5) @ m_rot_x(math.radians(22)) @ m_rot_y(0.3 * a)   # camera pitched DOWN onto the scene
        c.clear(0x0B1020)
        c.ctrl(ztest=1, zwrite=1, zfunc=1, cull=1)
        # ground
        c.matrix(P @ V)
        g = [c.vert(-5, -1.6, -5, 0x303848), c.vert(5, -1.6, -5, 0x303848), c.vert(5, -1.6, 5, 0x607080), c.vert(-5, -1.6, 5, 0x607080)]
        c.tri(g[0], g[2], g[1]); c.tri(g[0], g[3], g[2])
        c.flush()
        # cube A: spins in place on its own axes
        c.matrix(P @ V @ m_translate(-1.5, 0.0, 0) @ m_rot_y(a * 2) @ m_rot_x(a))
        cube_mesh(c, 0, 0, 0, 0.9, cols_a); c.flush()
        # cube B: orbiting, smaller
        c.matrix(P @ V @ m_rot_y(-a) @ m_translate(2.3, 0.2, 0) @ m_rot_z(a * 1.5) @ m_rot_y(a))
        cube_mesh(c, 0, 0, 0, 0.6, cols_b); c.flush()
        c.capture(f"scene_{f:03d}")
    c.close()
    return (W, H, frames)


if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else '../scenes'
    os.makedirs(out, exist_ok=True)
    gen_shared_edges(f"{out}/shared_edges.cmd")
    gen_clip(f"{out}/clip_cases.cmd")
    gen_cull_depth(f"{out}/cull_depth.cmd")
    gen_errors(f"{out}/errors.cmd")
    gen_demo_triangle(f"{out}/demo_triangle.cmd")
    gen_demo_scene(f"{out}/demo_scene.cmd")
    gen_texture(f"{out}/texture.cmd")
    gen_demo_textured(f"{out}/demo_textured.cmd")
    for name, W, H in manifest():
        if name.startswith("random_screen"):
            gen_random_screen(f"{out}/{name}.cmd", W, H, n=500, seed=100 + int(name[-1]))
        elif name.startswith("random_persp"):
            gen_random_persp(f"{out}/{name}.cmd", W, H, n=450, seed=200 + int(name[-1]))
        elif name.startswith("random_tex"):
            gen_random_tex(f"{out}/{name}.cmd", W, H, n=420, seed=300 + int(name[-1]))
        elif name == "big_fb":
            gen_random_screen(f"{out}/big_fb.cmd", W, H, n=60, seed=31337)
    import json
    json.dump(manifest(), open(f"{out}/manifest.json", "w"))
    print("generated in", out)
