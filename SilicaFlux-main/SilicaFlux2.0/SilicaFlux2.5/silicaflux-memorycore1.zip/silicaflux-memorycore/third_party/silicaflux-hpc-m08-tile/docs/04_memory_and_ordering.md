# 04 — Memory arbitration, hazards and ordering

## 1. Requesters and physical port limits

| Scratchpad port | Requester | Requests |
|---|---|---|
| 0 .. P−1 | LSU (`hpc_tile_lsu`), P = min(words per beat, LSU_MAX_PORTS) | operand loads, result stores, reduction store |
| P | DMA adapter (`hpc_dma_adapter` → `hpc_dma_spm_port`) | DMA reads / writes of the scratchpad window |
| P + 1 | host window (`hpc_dma_spm_port`, SFB2 slave `hs_*`) | host reads / writes |

* Each bank is a **1RW** SRAM (Module 04 `PORT_MODE = 1RW`), so each bank performs at most **one access per
  cycle**. The bank arbiter never grants more (an assertion in Module 04 checks this every cycle).
* Requests to different banks are served in the same cycle.
* The map is word-interleaved (`MAP = LOW`: bank = word mod NUM_BANKS). With NUM_BANKS ≥ NUM_LANES, the lanes
  of one beat therefore hit different banks.
* Write acknowledgements (`WRITE_ACK = 1`) are only produced after the bank has been written.

## 2. Arbitration and fairness

* **Per bank:** Module 04 round robin. The pointer moves past the first winner. A requester that stays
  eligible waits at most NUM_PORTS − 1 cycles for its bank (the bound is proved by Module 04's tests).
  The LSU, DMA and host ports therefore compete **fairly**: neither the vector unit nor the DMA can starve
  the other or the host.
* **Inside the LSU, per port:** a pending result store has priority over a load. Stores free operand FIFOs,
  so this keeps the pipeline moving. A request that has been presented is held until accepted (Module 04
  H2): the choice is never withdrawn.
* **Response channel:** the LSU accepts every response at once (`rsp_ready = 1`).
  * A load is only issued when its operand FIFO slot is reserved.
  * A store acknowledgement needs no space.
  * The DMA adapter likewise never back-pressures responses.
  * So scratchpad response credits can never form a dependency cycle. The tile has no deadlock through the
    scratchpad.
* **Measured:**
  * `contention` test: DMA, vector and host traffic in parallel, results exact, SPM_CONFLICTS > 0.
  * `perf` test: SPM_CONFLICTS equal to the per-port arbitration-loss events.

## 3. Hazards inside a vector command

* The load of element e precedes the store of element e (data dependence through the array).
* The scheduler accepts a destination D that is either **exactly** equal to a source base (in place) or
  disjoint from every source range (rule OVERLAP).
* Therefore no load of a command can observe a store of the same command, and results are independent of
  timing.
* A reduction stores one word, after the array's completion, that is after every load: no rule applies.

## 4. Hazards between commands: the dispatch rule

The scheduler dispatches strictly in queue order. One DMA command and one VEC command can be in flight at the
same time, **only if they are independent**. The candidate is compared against the command in flight on the
other unit, using exact byte ranges:

| Candidate | Compared with the in-flight | Blocks on |
|---|---|---|
| DMA (reads [SRC, SRC+LEN), writes [DST, DST+LEN)) | VEC (reads A/B/C ranges, writes the D range) | DMA writes ∩ VEC reads (WAR), DMA writes ∩ VEC writes (WAW), DMA reads ∩ VEC writes (RAW) |
| VEC | DMA | VEC writes ∩ DMA reads (WAR), VEC writes ∩ DMA writes (WAW), VEC reads ∩ DMA writes (RAW) |

* Two DMAs never overlap (single DMA path), and neither do two VECs (single vector unit).
* A KERNEL waits until nothing is in flight and owns both units until it retires.
* A blocked command waits; counter HAZARD_STALL counts the cycles.
* Consequence: **every interleaving produces the memory state of sequential execution**. This is the
  property the reference model uses (it executes commands one at a time).
* The `ordering` test checks it with random RAW / WAR / WAW chains and independent pairs over a few shared
  buffers. Mutants S1 / S2 (hazard check removed) are detected (`reports/mutation.md`).

## 5. Required ordering between DMA and compute commands (software rules)

1. **No fence is needed for data dependences.** A VEC that reads a DMA's destination, or a DMA that reads a
   VEC's result, waits automatically (rule §4). Double buffering is expressed simply by using different
   buffers: an independent DMA-in overlaps the compute (measured speed-up: `reports/perf.md` E3).
2. **Completion order = submission order.** A record in the completion queue means the command and every
   older command are complete. For DMA writes and vector stores, completion means every write was
   acknowledged by its target, so the data is in memory.
3. **Host accesses are not ordered with tile commands.**
   * The host scratchpad window and the tile's DMA master are separate paths.
   * The host must not touch a scratchpad or host-memory range used by a command until that command's
     record has been read.
   * The tile's hazard check covers tile commands only.
4. **Commands that can fail at run time** (a DMA bus error, a scratchpad parity error) halt the scheduler
   when CFG.HALT_ON_ERROR = 1. Rules:
   * a younger command that **depends** on the failing one never starts (it was waiting for it);
   * a younger **independent** command already executing completes with its own status;
   * when software needs "nothing after a failure runs", it uses FENCE on the next command, or waits for
     the record before submitting.

   The test generator follows this rule (it drains after such commands) so that the model and the hardware
   halt at the same point.
5. **FENCE** makes a command wait until every older command has retired, for example before reusing a
   buffer the host will read, or for timing measurements.

## 6. Host-visible memory

* The DMA master is an SFB2 master of the DataFabric crossbar: one transaction outstanding per port (rev 2.0).
* The crossbar's access matrix denies it the peripheral window and its own scratchpad window. The adapter
  routes scratchpad addresses internally.
* Unmapped host addresses answer a decode error, reported as DMA_ERR / READ_BUS or WRITE_BUS with the failing
  address.
