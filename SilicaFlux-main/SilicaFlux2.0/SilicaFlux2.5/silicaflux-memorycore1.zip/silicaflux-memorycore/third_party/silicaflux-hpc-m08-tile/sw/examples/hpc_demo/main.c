/* =============================================================================
 * SilicaFlux-HPC Module 08 -- compute-tile host control example / acceptance firmware
 * Runs on the SilicaFlux-V CPU (RV32I) in soc/rtl/sfv_soc_hpc.sv, loaded into SRAM
 * bank 0 (boot mode 3).  Drives the tile ONLY through its registers (0x4000_8000)
 * and its host scratchpad window (0x3000_0000) with the driver in
 * sw/drivers/silicaflux_hpc.c.  Expected values come from the independent
 * reference model (scripts/gen_fw_data.py -> hpc_demo_data.h); the CPU has no
 * FPU and compares bit patterns.
 *
 *   H1 probe: ID, VERSION, configuration; soft reset; counters cleared
 *   H2 three KERNEL commands (host memory -> scratchpad -> FADD / FMUL / FMADD ->
 *      scratchpad -> host memory), one completion each, results compared
 *   H3 explicit DMA -> VEC (dot product = reduction, AXPY = FMADD with a broadcast
 *      scalar) -> DMA, completion order and results
 *   H4 host scratchpad window: CPU writes operands, VEC with broadcast, CPU reads
 *   H5 errors: unsupported opcode (BAD_OP, nothing executed, tile halts, RESUME),
 *      DMA from an unmapped address (DMA_ERR / READ_BUS / err_addr)
 *   H6 performance counters against the model's deterministic values; cycles
 *   H7 soft reset during idle + recovery kernel
 * Output: UART log, TEST_STATUS (PASS / FAIL + number of failures).
 * ===========================================================================*/
#include "sfv_lib.h"
#include "sfv_df_map.h"
#include "silicaflux_hpc.h"
#include "hpc_demo_data.h"

#define HPC     SFV_DF_HPC_BASE
#define WIN     SFV_DF_HPC_SPM_BASE
#define R_ADD   0x10013000u            /* results in SRAM bank 2 */
#define R_MUL   0x10014000u
#define R_FMA   0x10015000u
#define R_AXPY  0x10016000u
#define R_ADD2  0x10017000u
#define W32(a)  ((volatile uint32_t *)(uintptr_t)(a))
#define TMO     2000000u

static uint32_t fails, checks;
volatile uint32_t n_exc, last_cause;

/* no interrupt is enabled and no exception is expected: count any trap (checked at the end) */
__attribute__((interrupt("machine"))) void trap_entry(void) {
  uint32_t cause = csr_read(mcause);
  if (cause & 0x80000000u) return;
  n_exc++;
  last_cause = cause;
  csr_write(mepc, csr_read(mepc) + 4u);
}

static void check(int ok, uint32_t id, uint32_t got, uint32_t exp) {
  checks++;
  if (!ok) {
    fails++;
    if (fails <= 20) {
      uart_puts("  FAIL id="); uart_puthex(id); uart_puts(" got="); uart_puthex(got);
      uart_puts(" exp="); uart_puthex(exp); uart_puts("\n");
    }
  }
}
#define CHECK_EQ(id, got, exp) do { uint32_t _g = (uint32_t)(got), _e = (uint32_t)(exp); check(_g == _e, (id), _g, _e); } while (0)

static void section(const char *name) {
  uart_puts("["); uart_puts(name); uart_puts("] checks="); uart_putdec(checks);
  uart_puts(" fails="); uart_putdec(fails); uart_puts("\n");
}

static void submit(const hpc_cmd_t *c, uint32_t id) {
  uint32_t t = TMO;
  while (hpc_submit(HPC, c) != 0 && --t) { }
  check(t != 0, id, 0, 1);
}

/* wait for the next completion and check its tag / status / count; returns the record */
static hpc_cpl_t expect(uint32_t id, uint8_t tag, uint8_t status, uint32_t count) {
  hpc_cpl_t c = {0};
  int got = hpc_wait(HPC, &c, TMO);
  check(got, id, 0, 1);
  CHECK_EQ(id + 1, c.tag, tag);
  CHECK_EQ(id + 2, c.status, status);
  CHECK_EQ(id + 3, c.count, count);
  return c;
}

static void cmp_mem(uint32_t id, uint32_t addr, const uint32_t *exp, uint32_t n) {
  uint32_t bad = 0, first = 0;
  for (uint32_t i = 0; i < n; i++)
    if (W32(addr)[i] != exp[i]) { if (!bad) first = i; bad++; }
  check(bad == 0, id, bad ? W32(addr)[first] : 0, bad ? exp[first] : 0);
}

int main(void) {
  hpc_info_t info;
  hpc_cpl_t c;
  uart_puts("\nSilicaFlux-HPC compute tile demo (Module 08)\n");

  /* ------------------------------------------------------------ H1 */
  CHECK_EQ(0x100, hpc_probe(HPC, &info), 0);
  print_kv("lanes", info.lanes); print_kv("spm_bytes", 1u << info.spm_log2); print_kv("banks", info.banks);
  print_kv("spm_base", info.spm_base); print_kv("vl_max", info.vl_max); print_kv("perf_counters", info.num_perf);
  uint32_t ln = info.lanes, dot = 0, dotf = 0xFFu;
  check(ln == 1 || ln == 2 || ln == 4 || ln == 8 || ln == 16, 0x101, ln, 4);
  for (unsigned i = 0; i < 5; i++) if (exp_dot[i][0] == ln) { dot = exp_dot[i][1]; dotf = exp_dot[i][2]; }
  CHECK_EQ(0x102, info.spm_base, WIN);
  CHECK_EQ(0x103, info.data_bytes, 4);
  CHECK_EQ(0x104, hpc_soft_reset(HPC, TMO), 0);
  CHECK_EQ(0x105, hpc_status(HPC) & 0x3Fu, 0);                 /* idle, not halted, queues empty */
  hpc_configure(HPC, 1, 0);
  hpc_perf_clear(HPC);
  section("H1 probe");

  /* ------------------------------------------------------------ H2 kernels */
  hpc_cmd_t k;
  k = hpc_cmd_kernel(HPC_OP_FADD, HPC_RNE, DEMO_VL, (uint32_t)in_a, (uint32_t)in_b, 0, R_ADD, WIN, 0, 1, 0);
  submit(&k, 0x200);
  k = hpc_cmd_kernel(HPC_OP_FMUL, HPC_RNE, DEMO_VL, (uint32_t)in_a, (uint32_t)in_b, 0, R_MUL, WIN, 0, 2, 0);
  submit(&k, 0x201);
  k = hpc_cmd_kernel(HPC_OP_FMADD, HPC_RNE, DEMO_VL, (uint32_t)in_a, (uint32_t)in_b, (uint32_t)in_c, R_FMA, WIN, 0, 3, 0);
  submit(&k, 0x202);
  c = expect(0x210, 1, HPC_ST_OK, DEMO_VL); CHECK_EQ(0x214, c.fflags, EXP_FLAGS_ADD);
  uart_puts("  FADD kernel cycles="); uart_putdec(c.cycles); uart_puts("\n");
  c = expect(0x220, 2, HPC_ST_OK, DEMO_VL); CHECK_EQ(0x224, c.fflags, EXP_FLAGS_MUL);
  c = expect(0x230, 3, HPC_ST_OK, DEMO_VL); CHECK_EQ(0x234, c.fflags, EXP_FLAGS_FMA);
  uart_puts("  FMADD kernel cycles="); uart_putdec(c.cycles); uart_puts("\n");
  cmp_mem(0x240, R_ADD, exp_add, DEMO_VL);
  cmp_mem(0x241, R_MUL, exp_mul, DEMO_VL);
  cmp_mem(0x242, R_FMA, exp_fma, DEMO_VL);
  section("H2 kernels");

  /* ------------------------------------------------------------ H3 explicit pipeline */
  k = hpc_cmd_dma((uint32_t)in_a, WIN + 0x2000, 4 * DEMO_VL, 4, 0); submit(&k, 0x300);
  k = hpc_cmd_dma((uint32_t)in_b, WIN + 0x3000, 4 * DEMO_VL, 5, 0); submit(&k, 0x301);
  k = hpc_cmd_vec(HPC_OP_FMUL, HPC_RNE, DEMO_VL, WIN + 0x2000, WIN + 0x3000, 0, WIN + 0x4000, 0, 6, HPC_RED);
  submit(&k, 0x302);
  k = hpc_cmd_vec(HPC_OP_FMADD, HPC_RNE, DEMO_VL, WIN + 0x2000, WIN + 0x3000, 0, WIN + 0x5000, DEMO_AXPY_SCALAR, 7, HPC_BC_C);
  submit(&k, 0x303);
  k = hpc_cmd_dma(WIN + 0x5000, R_AXPY, 4 * DEMO_VL, 8, 0); submit(&k, 0x304);
  expect(0x310, 4, HPC_ST_OK, 4 * DEMO_VL);
  expect(0x320, 5, HPC_ST_OK, 4 * DEMO_VL);
  c = expect(0x330, 6, HPC_ST_OK, DEMO_VL);
  CHECK_EQ(0x334, c.result, dot); CHECK_EQ(0x335, c.fflags, dotf);   /* defined order for this lane count */
  CHECK_EQ(0x336, W32(WIN + 0x4000)[0], dot);                       /* also stored in the scratchpad */
  c = expect(0x340, 7, HPC_ST_OK, DEMO_VL); CHECK_EQ(0x344, c.fflags, EXP_FLAGS_AXPY);
  expect(0x350, 8, HPC_ST_OK, 4 * DEMO_VL);
  cmp_mem(0x360, R_AXPY, exp_axpy, DEMO_VL);
  uart_puts("  dot product = "); uart_puthex(dot); uart_puts("\n");
  section("H3 DMA -> VEC -> DMA");

  /* ------------------------------------------------------------ H4 host scratchpad window */
  for (uint32_t i = 0; i < DEMO_NH; i++) W32(WIN + 0x6000)[i] = in_h[i];
  k = hpc_cmd_vec(HPC_OP_FADD, HPC_RNE, DEMO_NH, WIN + 0x6000, 0, 0, WIN + 0x7000, DEMO_ONE, 9, HPC_BC_B);
  submit(&k, 0x400);
  c = expect(0x410, 9, HPC_ST_OK, DEMO_NH); CHECK_EQ(0x414, c.fflags, EXP_FLAGS_HOST);
  cmp_mem(0x420, WIN + 0x7000, exp_host, DEMO_NH);
  section("H4 host window");

  /* ------------------------------------------------------------ H5 errors */
  W32(WIN + 0x9000)[0] = 0xA5A5A5A5u;                                /* must stay untouched */
  k = hpc_cmd_vec(0x1Fu, HPC_RNE, DEMO_VL, WIN + 0x2000, WIN + 0x3000, 0, WIN + 0x9000, 0, 0xE0, 0);
  submit(&k, 0x500);
  expect(0x510, 0xE0, HPC_ST_BAD_OP, 0);
  CHECK_EQ(0x514, (hpc_status(HPC) >> 1) & 1u, 1);                   /* HALTED */
  CHECK_EQ(0x515, W32(WIN + 0x9000)[0], 0xA5A5A5A5u);               /* unsupported opcode did not execute */
  hpc_resume(HPC);
  k = hpc_cmd_dma(DEMO_UNMAPPED, WIN + 0x8000, 64, 0xE1, 0); submit(&k, 0x520);
  c = expect(0x530, 0xE1, HPC_ST_DMA_ERR, 0);
  CHECK_EQ(0x534, c.detail, 8);                                       /* READ_BUS */
  CHECK_EQ(0x535, c.err_addr, DEMO_UNMAPPED);
  CHECK_EQ(0x536, (hpc_status(HPC) >> 1) & 1u, 1);
  hpc_resume(HPC);
  CHECK_EQ(0x537, (hpc_status(HPC) >> 1) & 1u, 0);
  section("H5 errors");

  /* ------------------------------------------------------------ H6 counters */
  hpc_configure(HPC, 1, 1);                                           /* freeze */
  CHECK_EQ(0x600, hpc_perf_read(HPC, HPC_PC_SUBMITTED), EXP_PC_SUBMITTED);
  CHECK_EQ(0x601, hpc_perf_read(HPC, HPC_PC_COMPLETED), EXP_PC_COMPLETED);
  CHECK_EQ(0x602, hpc_perf_read(HPC, HPC_PC_ERRORS), EXP_PC_ERRORS);
  CHECK_EQ(0x603, hpc_perf_read(HPC, HPC_PC_DMA_BYTES_RD), EXP_PC_DMA_BYTES_RD);
  CHECK_EQ(0x604, hpc_perf_read(HPC, HPC_PC_DMA_BYTES_WR), EXP_PC_DMA_BYTES_WR);
  CHECK_EQ(0x605, hpc_perf_read(HPC, HPC_PC_VEC_ELEMS), EXP_PC_VEC_ELEMS);
  CHECK_EQ(0x606, hpc_perf_read(HPC, HPC_PC_VEC_FLOPS), EXP_PC_VEC_FLOPS);
  CHECK_EQ(0x607, hpc_perf_read(HPC, HPC_PC_LSU_LOADS), EXP_PC_LSU_LOADS);
  CHECK_EQ(0x608, hpc_perf_read(HPC, HPC_PC_LSU_STORES), EXP_PC_LSU_STORES);
  CHECK_EQ(0x609, hpc_perf_read(HPC, HPC_PC_DMA_CMDS), EXP_PC_DMA_CMDS);
  CHECK_EQ(0x60A, hpc_perf_read(HPC, HPC_PC_VEC_CMDS), EXP_PC_VEC_CMDS);
  CHECK_EQ(0x60B, hpc_perf_read(HPC, HPC_PC_KERNEL_CMDS), EXP_PC_KERNEL_CMDS);
  CHECK_EQ(0x60C, hpc_perf_read(HPC, HPC_PC_HOST_SPM), EXP_PC_HOST_SPM);
  uint32_t cyc = hpc_perf_read(HPC, HPC_PC_CYCLES), busy = hpc_perf_read(HPC, HPC_PC_BUSY);
  check(busy > 0 && busy <= cyc, 0x60D, busy, cyc);
  print_kv("perf_cycles", cyc); print_kv("perf_busy", busy);
  print_kv("perf_vec_flops", hpc_perf_read(HPC, HPC_PC_VEC_FLOPS));
  print_kv("perf_spm_conflicts", hpc_perf_read(HPC, HPC_PC_SPM_CONFLICTS));
  print_kv("perf_overlap", hpc_perf_read(HPC, HPC_PC_OVERLAP));
  hpc_configure(HPC, 1, 0);
  section("H6 counters");

  /* ------------------------------------------------------------ H7 soft reset + recovery */
  CHECK_EQ(0x700, hpc_soft_reset(HPC, TMO), 0);
  CHECK_EQ(0x701, hpc_status(HPC) & 0x3Fu, 0);
  CHECK_EQ(0x702, HPC_REG(HPC, HPC_REG_ID), HPC_TILE_ID);
  k = hpc_cmd_kernel(HPC_OP_FADD, HPC_RNE, DEMO_VL, (uint32_t)in_a, (uint32_t)in_b, 0, R_ADD2, WIN, 0, 0x10, 0);
  submit(&k, 0x703);
  expect(0x710, 0x10, HPC_ST_OK, DEMO_VL);
  cmp_mem(0x720, R_ADD2, exp_add, DEMO_VL);
  section("H7 soft reset");

  CHECK_EQ(0x800, n_exc, 0);                                         /* no unexpected trap (e.g. bus error) */
  uart_puts("RESULT checks="); uart_putdec(checks); uart_puts(" fails="); uart_putdec(fails);
  uart_puts(fails ? " FAIL\n" : " PASS\n");
  uart_flush();
  test_status(fails ? TEST_FAIL : TEST_PASS, fails);
  for (;;) { }
}
