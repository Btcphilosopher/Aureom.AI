/* =============================================================================
 * SilicaFlux-HPC Module 08 :: silicaflux_hpc.h -- host driver for the compute tile
 *
 * Bare-metal, polling driver (no interrupts required, no allocation, no libc).
 * Register map and encodings: hpc_tile_regs.h, GENERATED from
 * rtl/hpc_tile_defs.svh (single source of truth).  Documented in
 * docs/03_register_map.md and docs/06_host_software.md.
 *
 *   hpc_probe        check ID / VERSION, read the configuration
 *   hpc_soft_reset   CTRL.SOFT_RESET and wait until the sequence has finished
 *   hpc_configure    halt-on-error, counter freeze
 *   hpc_submit       write CMD0..7 and ring DOORBELL -- only if CMDQ_FREE > 0, so a
 *                    refused DOORBELL (bus error) can never happen from this driver
 *   hpc_poll / hpc_wait   completion read-back (CPL_* registers, CPL_POP)
 *   hpc_resume / hpc_flush, hpc_perf_*   control and counters
 *   hpc_cmd_*        descriptor builders
 * The tile is single-host: these functions are not re-entrant.
 * ===========================================================================*/
#ifndef SILICAFLUX_HPC_H
#define SILICAFLUX_HPC_H

#include <stdint.h>
#include "hpc_tile_regs.h"

typedef struct { uint32_t w[8]; } hpc_cmd_t;

typedef struct {
  uint8_t  tag, status, type, detail, fflags, step;
  uint16_t seq;
  uint32_t count, result, err_addr, cycles;
} hpc_cpl_t;

typedef struct {
  uint32_t lanes, data_bytes, spm_log2, banks, perf, dma_buffered, host_spm, lsu_ports;
  uint32_t cmdq_depth, cplq_depth, dma_buffer_log2, num_perf, spm_base, vl_max;
} hpc_info_t;

/* element operations (Module 02 encoding) */
enum { HPC_OP_FMV = 0x00, HPC_OP_FADD = 0x01, HPC_OP_FSUB = 0x02, HPC_OP_FMUL = 0x03, HPC_OP_FMADD = 0x04,
       HPC_OP_FMSUB = 0x05, HPC_OP_FNMSUB = 0x06, HPC_OP_FNMADD = 0x07, HPC_OP_FMIN = 0x08, HPC_OP_FMAX = 0x09,
       HPC_OP_FEQ = 0x0A, HPC_OP_FLT = 0x0B, HPC_OP_FLE = 0x0C, HPC_OP_IADD = 0x10, HPC_OP_IMUL = 0x11 };
/* rounding modes */
enum { HPC_RNE = 0, HPC_RTZ = 1, HPC_RDN = 2, HPC_RUP = 3, HPC_RMM = 4 };
/* descriptor option bits for the builders */
#define HPC_BC_A   (1u << 0)            /* broadcast SCALAR as operand a */
#define HPC_BC_B   (1u << 1)
#define HPC_BC_C   (1u << 2)
#define HPC_RED    (1u << 3)            /* sum-reduce the element results */
#define HPC_FENCE  (1u << 4)            /* wait for every older command */

#define HPC_REG(base, off) (*(volatile uint32_t *)((uintptr_t)(base) + (uintptr_t)(off)))

int      hpc_probe(uintptr_t base, hpc_info_t *info);
int      hpc_soft_reset(uintptr_t base, uint32_t timeout);
void     hpc_configure(uintptr_t base, int halt_on_error, int perf_freeze);
int      hpc_submit(uintptr_t base, const hpc_cmd_t *c);
int      hpc_poll(uintptr_t base, hpc_cpl_t *cpl);
int      hpc_wait(uintptr_t base, hpc_cpl_t *cpl, uint32_t timeout);
uint32_t hpc_status(uintptr_t base);
void     hpc_resume(uintptr_t base);
int      hpc_flush(uintptr_t base, uint32_t timeout);
uint32_t hpc_perf_read(uintptr_t base, unsigned idx);
void     hpc_perf_clear(uintptr_t base);

hpc_cmd_t hpc_cmd_nop(uint8_t tag, uint32_t opt);
hpc_cmd_t hpc_cmd_dma(uint32_t src, uint32_t dst, uint32_t len, uint8_t tag, uint32_t opt);
hpc_cmd_t hpc_cmd_vec(unsigned op, unsigned rm, uint32_t vl, uint32_t a, uint32_t b, uint32_t c, uint32_t d,
                      uint32_t scalar, uint8_t tag, uint32_t opt);
hpc_cmd_t hpc_cmd_kernel(unsigned op, unsigned rm, uint32_t vl, uint32_t a, uint32_t b, uint32_t c, uint32_t d,
                         uint32_t stage, uint32_t scalar, uint8_t tag, uint32_t opt);

#endif /* SILICAFLUX_HPC_H */
