/* =============================================================================
 * SilicaFlux-HPC Module 08 :: silicaflux_hpc.c -- host driver (see silicaflux_hpc.h)
 * ===========================================================================*/
#include "silicaflux_hpc.h"

#define R(off) HPC_REG(base, off)

int hpc_probe(uintptr_t base, hpc_info_t *info) {
  if (R(HPC_REG_ID) != HPC_TILE_ID) return -1;
  if ((R(HPC_REG_VERSION) >> 16) != (HPC_TILE_VERSION >> 16)) return -2;
  uint32_t c0 = R(HPC_REG_CONFIG0), c1 = R(HPC_REG_CONFIG1);
  info->lanes = c0 & 0xFFu;
  info->data_bytes = (c0 >> 8) & 0xFFu;
  info->spm_log2 = (c0 >> 16) & 0x1Fu;
  info->banks = (c0 >> 21) & 0x1Fu;
  info->perf = (c0 >> 26) & 1u;
  info->dma_buffered = (c0 >> 27) & 1u;
  info->host_spm = (c0 >> 28) & 1u;
  info->lsu_ports = ((c0 >> 29) & 7u) + 1u;
  info->cmdq_depth = c1 & 0xFFu;
  info->cplq_depth = (c1 >> 8) & 0xFFu;
  info->dma_buffer_log2 = (c1 >> 16) & 0xFFu;
  info->num_perf = (c1 >> 24) & 0xFFu;
  info->spm_base = R(HPC_REG_SPM_BASE);
  info->vl_max = R(HPC_REG_VL_MAX);
  return 0;
}

uint32_t hpc_status(uintptr_t base) { return R(HPC_REG_STATUS); }

int hpc_soft_reset(uintptr_t base, uint32_t timeout) {
  R(HPC_REG_CTRL) = 1u << HPC_CTRL_SOFT_RESET;
  while (timeout--)
    if (!(R(HPC_REG_STATUS) & (1u << 3))) return 0;      /* STATUS.SOFT_RESET */
  return -1;
}

void hpc_configure(uintptr_t base, int halt_on_error, int perf_freeze) {
  R(HPC_REG_CFG) = (halt_on_error ? (1u << HPC_CFG_HALT_ON_ERROR) : 0u) |
                   (perf_freeze ? (1u << HPC_CFG_PERF_FREEZE) : 0u);
}

int hpc_submit(uintptr_t base, const hpc_cmd_t *c) {
  if (R(HPC_REG_CMDQ_FREE) == 0u) return -1;              /* never ring a full queue (no bus error) */
  for (unsigned i = 0; i < 8; i++) R(HPC_REG_CMD0 + 4u * i) = c->w[i];
  R(HPC_REG_DOORBELL) = 0u;
  return 0;
}

int hpc_poll(uintptr_t base, hpc_cpl_t *cpl) {
  uint32_t info = R(HPC_REG_CPL_INFO);
  if (!(info >> 31)) return 0;
  cpl->tag = (uint8_t)(info & 0xFFu);
  cpl->status = (uint8_t)((info >> 8) & 0xFu);
  cpl->type = (uint8_t)((info >> 12) & 0xFu);
  cpl->detail = (uint8_t)((info >> 16) & 0xFu);
  cpl->fflags = (uint8_t)((info >> 20) & 0x1Fu);
  cpl->step = (uint8_t)((info >> 25) & 0x7u);
  cpl->seq = (uint16_t)R(HPC_REG_CPL_SEQ);
  cpl->count = R(HPC_REG_CPL_COUNT);
  cpl->result = R(HPC_REG_CPL_RESULT);
  cpl->err_addr = R(HPC_REG_CPL_ERR_ADDR);
  cpl->cycles = R(HPC_REG_CPL_CYCLES);
  R(HPC_REG_CPL_POP) = 0u;
  return 1;
}

int hpc_wait(uintptr_t base, hpc_cpl_t *cpl, uint32_t timeout) {
  while (timeout--)
    if (hpc_poll(base, cpl)) return 1;
  return 0;
}

void hpc_resume(uintptr_t base) { R(HPC_REG_CTRL) = 1u << HPC_CTRL_RESUME; }

int hpc_flush(uintptr_t base, uint32_t timeout) {
  R(HPC_REG_CTRL) = 1u << HPC_CTRL_FLUSH;
  while (timeout--)
    if (!(R(HPC_REG_STATUS) & (1u << 2))) return 0;      /* STATUS.FLUSHING */
  return -1;
}

uint32_t hpc_perf_read(uintptr_t base, unsigned idx) { return R(HPC_REG_PERF0 + 4u * idx); }
void hpc_perf_clear(uintptr_t base) { R(HPC_REG_CTRL) = 1u << HPC_CTRL_PERF_CLEAR; }

static uint32_t w0(unsigned type, unsigned op, unsigned rm, uint8_t tag, uint32_t opt) {
  return (type & 0xFu) | ((op & 0x1Fu) << 4) | ((rm & 7u) << 9) | ((opt & 7u) << 12) |
         (((opt >> 3) & 1u) << 15) | ((uint32_t)tag << 16) | (((opt >> 4) & 1u) << 24);
}

hpc_cmd_t hpc_cmd_nop(uint8_t tag, uint32_t opt) {
  hpc_cmd_t c = {{w0(HPC_CT_NOP, 0, 0, tag, opt), 0, 0, 0, 0, 0, 0, 0}};
  return c;
}

hpc_cmd_t hpc_cmd_dma(uint32_t src, uint32_t dst, uint32_t len, uint8_t tag, uint32_t opt) {
  hpc_cmd_t c = {{w0(HPC_CT_DMA, 0, 0, tag, opt), len, 0, src, dst, 0, 0, 0}};
  return c;
}

hpc_cmd_t hpc_cmd_vec(unsigned op, unsigned rm, uint32_t vl, uint32_t a, uint32_t b, uint32_t c, uint32_t d,
                      uint32_t scalar, uint8_t tag, uint32_t opt) {
  hpc_cmd_t k = {{w0(HPC_CT_VEC, op, rm, tag, opt), vl, scalar, a, b, c, d, 0}};
  return k;
}

hpc_cmd_t hpc_cmd_kernel(unsigned op, unsigned rm, uint32_t vl, uint32_t a, uint32_t b, uint32_t c, uint32_t d,
                         uint32_t stage, uint32_t scalar, uint8_t tag, uint32_t opt) {
  hpc_cmd_t k = {{w0(HPC_CT_KERNEL, op, rm, tag, opt), vl, scalar, a, b, c, d, stage}};
  return k;
}
