# Provenance of third_party/

Every file below `third_party/` is an **unmodified, byte-identical** copy of a file in the source repository `btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (verified by `scripts/check_vendor.py --repo ...`; hashes in `SHA256SUMS`). MemoryCore's own code never edits these files.

| Directory | Source archive (in SilicaFlux-main/) | Files | Used for |
|---|---|---|---|
| `silicaflux-sramlib/` | `SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` | 19 | bank controller, 1RW backends, MBIST march controller (Project 01) |
| `silicaflux-datafabric/` | `SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric.zip` | 17 | SFB2 protocol, protocol checker, DMA, v1 slave adapter; SilicaFlux-V `sfv_cpu`, `sfv_pkg`, `sfv_periph_bridge` (Project 03 vendored copies) |
| `silicaflux-tensorcore08/` | `silicaflux-tensorcore08.zip` | 134 | tensor unit + its vendored HPC tile, scratchpad, TC02-07, SRAM library, DataFabric pieces; C driver (system test) |
| `silicaflux-hpc-m08-tile/` | `SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m08-tile.zip` | 11 | HPC tile C driver, SoC memory map (legacy-address check), docs |
| `silicaflux-bandwidthlab/` | `SilicaFlux2.0/SilicaFlux2.5/silicaflux-bandwidthlab.zip` | 35 | MemoryLab Python package (Project 02 inside Project 10) for bwlab_compare |

No license file exists in the source repository; the owner must add one before external distribution (same note as Projects 01-10).
