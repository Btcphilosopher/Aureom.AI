# 06 — Integration with SilicaFlux-HPC

`integration/sfx_hpc_tensor_system.sv` is the worked, synthesizable integration: the **unmodified HPC Module 08
compute tile** (Module 02 FP32 lanes, Module 03 vector array, Module 04 scratchpad, Module 05 DMA, its command
queue, counters and register page) and `silicaflux_tensor_unit`, on the **unmodified DataFabric `sfb_crossbar`**,
with a host CPU data port and one shared SRAM.

```
                 register bus (16 pages)            page 8 ─► silicaflux_hpc_tile        page 9 ─► silicaflux_tensor_unit
                                                                     │ fab_* (DMA)                    │ m_* (DMA)
 host CPU port ──► m0 ┐                                              ▼                                ▼
                      ├──── sfb_crossbar (round robin per slave, one transaction per port, R6) ◄── m1        m2
                      └──► s0 shared SRAM window          └──► s1 tile scratchpad window (hs_*)
```

## 1. Interfaces the tensor unit presents

| Interface | Contract | Shared with |
|---|---|---|
| register page | SilicaFlux-V `rb_*`, 4 KiB, proposed page 9 (`0x4000_9000`) | identical to the tile's page 8 |
| SFB2 master | 32-bit, `MAX_OUT` (default 4) transactions; behind the crossbar R6 limits it to 1 at a time | a crossbar master port, like the tile's DMA |
| `irq` | level, `OR(INT_STATUS & INT_ENABLE)` | proposed interrupt index next to the tile's |
| `perf_ev` | 20 × 32-bit increments per cycle (`TSU_PC_*`) | input for an HPC Module 07-style telemetry unit (`hpc_perf_counters` accepts multi-event increments) |
| `busy`, `halted` | status | |

## 2. Resource ownership

| Resource | Owner | Who else can reach it | Enforced by |
|---|---|---|---|
| Shared SRAM (s0) | software (partitioned per job) | host, tile DMA, tensor DMA | crossbar access matrix; the tensor unit's own window `[MEM_LO, MEM_HI)` = the SRAM, checked by validation (RANGE) and again by TC07 |
| Tile scratchpad (s1) | the HPC tile | the host only (through the tile's host window) | crossbar access matrix: `MST_SLV_EN` excludes the tensor unit; a stray address would get a fabric decode error, never an alias. A tensor command naming it is rejected before any bus access (`system` test) |
| Tensor operand / output buffers | the tensor unit (TC03 / output-buffer ownership states) | nobody: not mapped on any bus | structure |
| Tile register page / tensor register page | their unit | the host (CPU) | page decoder; an unmapped page answers `rb_err` |

## 3. Arbitration

* One DataFabric `sfb_arbiter` per slave, `ARB_MODE = 1` (round robin): the pointer moves past the winner only on
  acceptance; a waiting master is served after at most NM − 1 = 2 other acceptances (DataFabric's ABC proof).
* One transaction per crossbar port (R6): each master has at most one transaction outstanding at the fabric; the
  tensor unit's adapter presents the next request while the previous response is pending (TC07 recommends
  `MAX_OUT ≥ 2` behind the crossbar), so it loses no cycle to its own turnaround.
* No master can starve another: measured in `reports/system.md` (arbitration losses per master under full load from
  all three masters), and in the contention tests of the main regression (a competing master at 60 % request rate).

## 4. Coherence and ordering — not claimed beyond this

There are **no caches** in this system and **no coherent interface** on the tensor unit. Correctness between
producers and consumers rests on the completion semantics alone: both units report a command complete only after
every one of its writes has been acknowledged by the target (SFB2 R7), so software that starts a consumer after
reading the producer's completion record sees the data. A CPU with a data cache would have to clean A / B before
the doorbell and invalidate C before reading it (the driver documents this; the SilicaFlux-V SoC has no data cache).

## 5. Verified

`scripts/run_system.py` (`reports/system.md`): 9 runs (3 seeds × {1-cycle SRAM, 1-cycle SRAM + 40 % host CPU traffic,
4-cycle SRAM + 25 % host traffic}). Each run interleaves 9 FP32 KERNEL commands (FADD / FMUL, 64–700 elements,
bit-exact vs binary64-then-binary32 reference) with 9 tensor GEMMs (INT32 and INT8, PREFETCH and SEQUENTIAL) and one
tensor command aimed at the tile scratchpad (rejected, RANGE). Checked: every record of both units, the whole SRAM,
the host's own reads (shadow), and an SFB2 protocol checker on each of the three master ports.
