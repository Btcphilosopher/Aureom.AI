/*
 * SilicaFlux TENSORCORE 08 -- host-side access to device memory for the examples.
 * On the simulation backend (cosim/cosim_main.cpp) these touch the memory model directly; on a bare-metal
 * SoC they are ordinary CPU loads / stores to the shared SRAM (memcpy to the device address).
 */
#ifndef TSU_HOST_H
#define TSU_HOST_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
void     tsu_host_write(uint32_t addr, const void *src, uint32_t len);
void     tsu_host_read(uint32_t addr, void *dst, uint32_t len);
uint64_t tsu_host_cycles(void);
int      host_main(void);                    /* the example program (called by the harness / crt0) */
#ifdef __cplusplus
}
#endif
#endif
