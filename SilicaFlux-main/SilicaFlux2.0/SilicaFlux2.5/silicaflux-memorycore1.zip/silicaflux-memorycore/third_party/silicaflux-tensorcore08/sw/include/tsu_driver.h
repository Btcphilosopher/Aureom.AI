/*
 * SilicaFlux TENSORCORE 08 -- host driver for silicaflux_tensor_unit.  Aureom.AI | SilicaFlux-HPC
 *
 * Bare-metal C (no libc beyond <stdint.h> / <stddef.h>).  Register access goes through two hooks:
 *
 *   default            volatile 32-bit MMIO at TSU_BASE (the unit's register page on the SilicaFlux-V register
 *                      bus).  NOT exercised on hardware: no board or SoC with the unit exists (see README).
 *   -DTSU_COSIM        SIMULATION BACKEND: tsu_cosim_wr32 / tsu_cosim_rd32 are provided by cosim/cosim_main.cpp,
 *                      which turns each call into one register-bus cycle on the Verilated RTL.
 *
 * There is no PCIe or OS driver.  Matrices live in device-visible memory; the API takes their DEVICE byte addresses.
 * Software owns coherence: the unit has no cache-coherent port, so data written by a CPU through a cache must be
 * cleaned before submission and C invalidated before it is read (no-ops on the SilicaFlux-V SoC, which has none).
 *
 * Return convention (HPC Module 06 driver style):  0 = OK,  > 0 = hardware ERR_CODE (TSU_E_*),  < 0 = driver error.
 */
#ifndef TSU_DRIVER_H
#define TSU_DRIVER_H

#include <stddef.h>
#include <stdint.h>
#include "tsu_abi.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef TSU_BASE
#define TSU_BASE 0x40009000u        /* proposed page (docs/06): next to the HPC tile page at 0x4000_8000 */
#endif

/* driver errors (negative) */
#define TSU_EINVAL     (-1)         /* host-side validation failed; nothing was submitted */
#define TSU_EBUSY      (-2)         /* command queue full */
#define TSU_ETIMEDOUT  (-3)         /* no completion record within the poll budget */
#define TSU_EABI       (-4)         /* ID / ABI version mismatch */
#define TSU_EPROTO     (-5)         /* a record arrived for a different TID / SEQ than expected */
#define TSU_EHALTED    (-6)         /* the unit halted (quiesce timeout): only a hard reset recovers */

typedef struct {
    uint32_t info, caps, opbuf, mem_lo, mem_last, k_max;   /* capability registers read by tsu_init */
    uint32_t submitted;                             /* commands submitted through this handle */
    uint32_t next_seq;                              /* SEQ expected in the next record */
    uint8_t  next_tid;
} tsu_dev_t;

typedef struct {
    uint32_t lda, ldb, ldc;         /* 0 = dense default (K, N, element size * N) */
    uint32_t kc;                    /* K chunk, 0 = TILE_K */
    int      out_int8;              /* 1: requantised INT8 output (needs ENABLE_QUANTIZATION) */
    int      rm;                    /* INT8: rounding mode TSU_RM_* */
    int      relu;                  /* INT8: ReLU at the output zero-point */
    int32_t  qmult;                 /* INT8: multiplier M */
    uint8_t  qshift;                /* INT8: shift S (0..63) */
    int8_t   qzp;                   /* INT8: output zero-point */
    int      prefetch;              /* double-buffered overlap (needs ENABLE_DOUBLE_BUFFERING) */
    int      nmajor;                /* N-major tile order */
    int      irq;                   /* set FLAGS.IRQ */
    int      skip_host_check;       /* 1: submit even if tsu_check predicts a rejection (tests the hardware) */
    uint32_t poll_budget;           /* status polls before TSU_ETIMEDOUT (0 = 50 000 000) */
} tsu_opts_t;

typedef struct {                    /* decoded completion record */
    uint8_t  tid, opcode, err, status, irq, sat, detail;
    uint32_t count, err_addr, seq, cycles, tiles;
    uint32_t raw[TSU_CPL_WORDS];
} tsu_record_t;

/* -------------------------------------------------------------------- register access hooks */
#ifdef TSU_COSIM
void     tsu_cosim_wr32(uint32_t off, uint32_t v);
uint32_t tsu_cosim_rd32(uint32_t off);
int      tsu_cosim_last_err(void);                  /* rb_err of the last access */
#define TSU_WR32(off, v)  tsu_cosim_wr32((off), (v))
#define TSU_RD32(off)     tsu_cosim_rd32((off))
#define TSU_LAST_ERR()    tsu_cosim_last_err()
#else
#define TSU_WR32(off, v)  (*(volatile uint32_t *)(uintptr_t)(TSU_BASE + (off)) = (v))
#define TSU_RD32(off)     (*(volatile uint32_t *)(uintptr_t)(TSU_BASE + (off)))
#define TSU_LAST_ERR()    0          /* a refused access raises a bus fault on the CPU instead */
#endif

/* -------------------------------------------------------------------- API */
int  tsu_init(tsu_dev_t *dev);
void tsu_build_gemm(uint32_t desc[TSU_DESC_WORDS], uint8_t tid, uint32_t a, uint32_t b, uint32_t c,
                    uint32_t m, uint32_t n, uint32_t k, const tsu_opts_t *o);
void tsu_build_nop(uint32_t desc[TSU_DESC_WORDS], uint8_t tid, int irq);
int  tsu_check(const tsu_dev_t *dev, const uint32_t desc[TSU_DESC_WORDS]);    /* predicted ERR_CODE, 0 = valid */
int  tsu_submit(tsu_dev_t *dev, const uint32_t desc[TSU_DESC_WORDS]);         /* 0 or TSU_EBUSY */
int  tsu_poll(tsu_dev_t *dev, tsu_record_t *rec);                             /* 1 = record taken, 0 = none */
int  tsu_wait(tsu_dev_t *dev, tsu_record_t *rec, uint32_t poll_budget);       /* 0 or TSU_ETIMEDOUT / EHALTED */
void tsu_set_continue_on_error(int on);
void tsu_clear_error(void);
void tsu_clear_counters(void);
void tsu_abort(void);
uint32_t tsu_counter(int i);
uint32_t tsu_status(void);

/* The brief's one-call API: validate, build, submit, wait, read the status, check errors.
 * Returns 0 when C is in memory (every write acknowledged), > 0 hardware error, < 0 driver error. */
int tensor_gemm(tsu_dev_t *dev, uint32_t A, uint32_t B, uint32_t C, uint32_t M, uint32_t N, uint32_t K,
                const tsu_opts_t *opts, tsu_record_t *rec_out);

const char *tsu_err_name(int code);

#ifdef __cplusplus
}
#endif
#endif /* TSU_DRIVER_H */
