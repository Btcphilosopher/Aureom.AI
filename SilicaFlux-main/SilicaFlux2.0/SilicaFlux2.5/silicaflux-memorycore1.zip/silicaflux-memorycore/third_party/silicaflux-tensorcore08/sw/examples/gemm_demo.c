/*
 * SilicaFlux TENSORCORE 08 -- host example: dense INT8 GEMMs through tensor_gemm().
 *
 * Places A and B in device memory, calls tensor_gemm() (validate -> build -> submit -> wait -> status -> errors),
 * reads C back and compares every element with a plain C reference (exact INT32, and the TENSORCORE 05
 * requantisation contract for INT8 output).  Then shows the error path (host check, hardware rejection,
 * stop-on-error skip, ERR_CLEAR) and back-to-back submission with in-order records.
 *
 * Built against the simulation backend (cosim/cosim_main.cpp) by `make cosim`; tsu_host_write / tsu_host_read
 * stand for the CPU's ordinary loads and stores to shared SRAM.
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "tsu_driver.h"
#include "tsu_host.h"

static uint32_t heap = 0x10001000u;
static uint32_t rng = 0xC0FFEEu;
static int failures = 0;

static uint32_t rnd(void) { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng; }
static uint32_t alloc(uint32_t bytes, uint32_t align)
{
    uint32_t a = (heap + align - 1u) & ~(align - 1u);
    heap = a + bytes + 4u + (rnd() & 0x1Fu);
    return a;
}

typedef struct { uint32_t a, b, c, m, n, k, lda, ldb, ldc; int8_t *A, *B; } prob_t;
static int8_t bufA[64 * 1024], bufB[64 * 1024];

static void make(prob_t *p, uint32_t m, uint32_t n, uint32_t k, uint32_t lda, uint32_t ldb, uint32_t ldc_elems,
                 uint32_t esz)
{
    uint32_t i;
    p->m = m; p->n = n; p->k = k;
    p->lda = lda ? lda : k;
    p->ldb = ldb ? ldb : n;
    p->ldc = (ldc_elems ? ldc_elems : n) * esz;
    p->A = bufA; p->B = bufB;
    for (i = 0; i < (m - 1) * p->lda + k; i++) bufA[i] = (int8_t)rnd();
    for (i = 0; i < (k - 1) * p->ldb + n; i++) bufB[i] = (int8_t)rnd();
    p->a = alloc((m - 1) * p->lda + k, 1);
    p->b = alloc((k - 1) * p->ldb + n, 1);
    p->c = alloc((m - 1) * p->ldc + n * esz, 4);
    tsu_host_write(p->a, bufA, (m - 1) * p->lda + k);
    tsu_host_write(p->b, bufB, (k - 1) * p->ldb + n);
}

static int64_t acc_ref(const prob_t *p, uint32_t i, uint32_t j)
{
    int64_t s = 0;
    uint32_t t;
    for (t = 0; t < p->k; t++) s += (int64_t)p->A[i * p->lda + t] * (int64_t)p->B[t * p->ldb + j];
    return s;
}

/* q = clamp(R_rm(acc * M / 2^S) + zp, -128, 127), then max(q, zp) with ReLU (TENSORCORE 05 NUMERIC_FORMAT) */
static int32_t requant(int64_t acc, int32_t mult, unsigned shift, int zp, int rm, int relu)
{
    int64_t p = acc * (int64_t)mult, q = shift ? (p >> shift) : p, y;
    uint64_t r = shift ? ((uint64_t)p & ((((uint64_t)1) << shift) - 1u)) : 0u;
    uint64_t half = shift ? (((uint64_t)1) << (shift - 1u)) : 0u;
    if (shift) {
        switch (rm) {
        case TSU_RM_RNE: if (r > half || (r == half && (q & 1))) q++; break;
        case TSU_RM_RTZ: if (p < 0 && r) q++; break;
        case TSU_RM_RDN: break;
        case TSU_RM_RUP: if (r) q++; break;
        default:         if (r > half || (r == half && p > 0)) q++; break;  /* RMM */
        }
    }
    y = q + zp;
    if (y < -128) y = -128;
    if (y > 127) y = 127;
    if (relu && y < zp) y = zp;
    return (int32_t)y;
}

static void verify(const char *what, const prob_t *p, const tsu_opts_t *o, int rc, const tsu_record_t *r)
{
    uint32_t i, j, bad = 0;
    int int8 = o && o->out_int8;
    for (i = 0; i < p->m && rc == 0; i++)
        for (j = 0; j < p->n; j++) {
            int64_t a = acc_ref(p, i, j);
            int32_t want = int8 ? requant(a, o->qmult, o->qshift, o->qzp, o->rm, o->relu) : (int32_t)a, got;
            if (int8) { int8_t v; tsu_host_read(p->c + i * p->ldc + j, &v, 1); got = v; }
            else tsu_host_read(p->c + i * p->ldc + 4 * j, &got, 4);
            if (got != want) { if (bad < 3) printf("    C[%u][%u] = %d, expected %d\n", i, j, got, want); bad++; }
        }
    printf("  %-34s M=%-3u N=%-3u K=%-4u %s  rc=%d (%s) tiles=%u bytes=%u cycles=%u sat=%u  %s\n", what, p->m, p->n,
           p->k, int8 ? "INT8 " : "INT32", rc, tsu_err_name(rc), r->tiles, r->count, r->cycles, r->sat,
           (rc == 0 && bad == 0) ? "PASS" : "FAIL");
    if (rc != 0 || bad) failures++;
}

int host_main(void)
{
    tsu_dev_t dev;
    tsu_opts_t o;
    tsu_record_t r;
    prob_t p;
    int rc, quant, dbuf;
    uint32_t d[TSU_DESC_WORDS];

    rc = tsu_init(&dev);
    quant = (dev.info >> 24) & 1;
    dbuf = (dev.info >> 25) & 1;
    printf("SilicaFlux tensor unit: INFO %08x (array %ux%u, TILE_K %u, quantisation %d, double buffering %d), "
           "window %08x..%08x, K_MAX %u, init rc %d\n", dev.info, (dev.info >> 8) & 0xFF, (dev.info >> 16) & 0xFF,
           dev.caps & 0xFFFF, quant, dbuf, dev.mem_lo, dev.mem_last, dev.k_max, rc);
    if (rc) return 1;

    printf("tensor_gemm, checked element by element against the C reference:\n");
    memset(&o, 0, sizeof o);
    make(&p, 4, 4, 4, 0, 0, 0, 4);
    rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);           verify("4x4 baseline", &p, &o, rc, &r);
    make(&p, 8, 8, 8, 0, 0, 0, 4);
    rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);           verify("8x8 (4 output tiles)", &p, &o, rc, &r);
    make(&p, 17, 13, 29, 31, 17, 15, 4);
    o.lda = p.lda; o.ldb = p.ldb; o.ldc = p.ldc;
    rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);           verify("17x13x29, padded strides", &p, &o, rc, &r);
    memset(&o, 0, sizeof o);
    make(&p, 32, 32, 256, 0, 0, 0, 4);
    rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);           verify("32x32x256 (4 K chunks)", &p, &o, rc, &r);
    if (dbuf) {
        o.prefetch = 1;
        make(&p, 32, 32, 256, 0, 0, 0, 4);
        rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);       verify("32x32x256, PREFETCH", &p, &o, rc, &r);
        o.prefetch = 0;
    }
    if (quant) {
        memset(&o, 0, sizeof o);
        o.out_int8 = 1; o.rm = TSU_RM_RNE; o.qmult = 1518500250; o.qshift = 41; o.qzp = -3;
        make(&p, 9, 11, 40, 0, 0, 0, 1);
        rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);       verify("INT8 requantised, RNE", &p, &o, rc, &r);
        o.rm = TSU_RM_RTZ; o.relu = 1; o.qmult = -987654321; o.qshift = 38; o.qzp = 5;
        make(&p, 6, 5, 70, 0, 0, 0, 1);
        rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);       verify("INT8 RTZ + ReLU, negative M", &p, &o, rc, &r);
        o.rm = TSU_RM_RNE; o.relu = 0; o.qmult = 0x7FFFFFFF; o.qshift = 16; o.qzp = 0;
        make(&p, 4, 4, 64, 0, 0, 0, 1);
        rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);       verify("INT8 saturating", &p, &o, rc, &r);
        if (!r.sat) { printf("    expected SAT = 1\n"); failures++; }
    }

    printf("error handling:\n");
    memset(&o, 0, sizeof o);
    rc = tensor_gemm(&dev, p.a, p.b, p.c, 0, 4, 4, &o, &r);
    printf("  M = 0, host check                 -> %d (%s), nothing submitted\n", rc, tsu_err_name(rc));
    if (rc != TSU_EINVAL) failures++;
    o.skip_host_check = 1;
    rc = tensor_gemm(&dev, p.a, p.b, p.c, 0, 4, 4, &o, &r);
    printf("  M = 0, submitted anyway            -> %d (%s) status %u\n", rc, tsu_err_name(rc), r.status);
    if (rc != (int)TSU_E_DIM_ZERO) failures++;
    o.skip_host_check = 0;
    make(&p, 4, 4, 4, 0, 0, 0, 4);
    rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);
    printf("  next GEMM, stop-on-error           -> %d (%s) status %u (SKIPPED, nothing executed)\n", rc,
           tsu_err_name(rc), r.status);
    if (rc != (int)TSU_E_PRIOR || r.status != TSU_ST_SKIPPED) failures++;
    tsu_clear_error();
    rc = tensor_gemm(&dev, p.a, p.b, p.c, p.m, p.n, p.k, &o, &r);           verify("after ERR_CLEAR", &p, &o, rc, &r);
    rc = tensor_gemm(&dev, p.a, 0x0FFFFF00u, p.c, p.m, p.n, p.k, &o, &r);
    printf("  B outside the memory window        -> %d (%s), host check\n", rc, tsu_err_name(rc));
    if (rc != TSU_EINVAL) failures++;

    printf("back-to-back submission (no waiting), records in order:\n");
    {
        prob_t q[3];
        uint32_t i, seq0 = dev.next_seq;
        uint8_t ms[3] = {5, 12, 3};
        for (i = 0; i < 3; i++) {
            make(&q[i], ms[i], 7, 33, 0, 0, 0, 4);
            memcpy(bufA + 32768 + i * 4096, bufA, 4096); memcpy(bufB + 32768 + i * 4096, bufB, 4096);
            tsu_build_gemm(d, (uint8_t)(0x80 + i), q[i].a, q[i].b, q[i].c, q[i].m, q[i].n, q[i].k, &o);
            while (tsu_submit(&dev, d) == TSU_EBUSY) { }
        }
        for (i = 0; i < 3; i++) {
            rc = tsu_wait(&dev, &r, 0);
            q[i].A = bufA + 32768 + i * 4096; q[i].B = bufB + 32768 + i * 4096;
            if (rc == 0 && (r.tid != 0x80 + i || r.seq != seq0 + i)) { printf("    order error\n"); failures++; }
            verify(i == 0 ? "queued command 1" : i == 1 ? "queued command 2" : "queued command 3", &q[i], &o,
                   rc ? rc : (r.status ? r.err : 0), &r);
        }
    }

    printf("counters: GEMMs %u, tiles %u, chunks %u, MACs %u, SFB2 reads %u, writes %u, busy %u / %u cycles\n",
           tsu_counter(TSU_PC_GEMM_OK), tsu_counter(TSU_PC_TILES), tsu_counter(TSU_PC_CHUNKS),
           tsu_counter(TSU_PC_MACS), tsu_counter(TSU_PC_RD_WORDS), tsu_counter(TSU_PC_WR_WORDS),
           tsu_counter(TSU_PC_BUSY), tsu_counter(TSU_PC_CYCLES));
    printf("DEMO %s (%d failures)\n", failures ? "FAIL" : "PASS", failures);
    return failures ? 1 : 0;
}
