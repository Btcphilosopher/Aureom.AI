/*
 * SilicaFlux TENSORCORE 08 -- host driver for silicaflux_tensor_unit (see include/tsu_driver.h).
 * tsu_check() implements the hardware's validation rules in the same order (rtl/tsu_validate.sv,
 * docs/02_COMMAND_ABI.md) so software can predict a rejection before it rings the doorbell.
 */
#include "tsu_driver.h"

#define FIELD(w, lo, n) (((w) >> (lo)) & ((1u << (n)) - 1u))

static uint32_t dev_tile_k(const tsu_dev_t *d) { return d->caps & 0xFFFFu; }
static int dev_quant(const tsu_dev_t *d) { return (int)((d->info >> 24) & 1u); }
static int dev_dbuf(const tsu_dev_t *d) { return (int)((d->info >> 25) & 1u); }

int tsu_init(tsu_dev_t *dev)
{
    dev->info = TSU_RD32(TSU_R_INFO);
    dev->caps = TSU_RD32(TSU_R_CAPS);
    dev->opbuf = TSU_RD32(TSU_R_OPBUF);
    dev->mem_lo = TSU_RD32(TSU_R_MEM_LO);
    dev->mem_last = TSU_RD32(TSU_R_MEM_LAST);
    dev->k_max = TSU_RD32(TSU_R_KMAX);
    dev->submitted = 0;
    dev->next_seq = 0;
    dev->next_tid = 0;
    if (TSU_RD32(TSU_R_ID) != TSU_ID_VALUE || (dev->info & 0xFu) != TSU_ABI_VERSION)
        return TSU_EABI;
    TSU_WR32(TSU_R_INT_ENABLE, 0u);
    TSU_WR32(TSU_R_INT_STATUS, 7u);
    TSU_WR32(TSU_R_CTRL, 0u);                          /* stop on error */
    /* the record stream continues after earlier users: drain anything pending, learn the next SEQ */
    while (TSU_RD32(TSU_R_STATUS) & (1u << TSU_SB_CPL_VALID)) {
        dev->next_seq = TSU_RD32(TSU_R_CPL0 + 12u) + 1u;
        TSU_WR32(TSU_R_CPL_POP, 1u);
    }
    if (TSU_RD32(TSU_R_SUBMITTED) != 0u && dev->next_seq == 0u)
        dev->next_seq = TSU_RD32(TSU_R_SUBMITTED);
    return 0;
}

void tsu_build_nop(uint32_t d[TSU_DESC_WORDS], uint8_t tid, int irq)
{
    unsigned i;
    for (i = 0; i < TSU_DESC_WORDS; i++) d[i] = 0;
    d[0] = TSU_OP_NOP | (TSU_ABI_VERSION << 8) | ((irq ? 1u : 0u) << (16 + TSU_FL_IRQ)) | ((uint32_t)tid << 24);
}

void tsu_build_gemm(uint32_t d[TSU_DESC_WORDS], uint8_t tid, uint32_t a, uint32_t b, uint32_t c,
                    uint32_t m, uint32_t n, uint32_t k, const tsu_opts_t *o)
{
    uint32_t esz = (o && o->out_int8) ? 1u : 4u, flags = 0, rm = 0;
    unsigned i;
    for (i = 0; i < TSU_DESC_WORDS; i++) d[i] = 0;
    if (o) {
        if (o->irq) flags |= 1u << TSU_FL_IRQ;
        if (o->prefetch) flags |= 1u << TSU_FL_PREFETCH;
        if (o->nmajor) flags |= 1u << TSU_FL_NMAJOR;
        if (o->out_int8) rm = (uint32_t)o->rm & 7u;
    }
    d[0] = TSU_OP_GEMM | (TSU_ABI_VERSION << 8) | (rm << 12) | (flags << 16) | ((uint32_t)tid << 24);
    d[1] = a;
    d[2] = b;
    d[3] = c;
    d[4] = (m & 0xFFFFu) | ((n & 0xFFFFu) << 16);
    d[5] = (k & 0x1FFFFu) | (((o ? o->kc : 0u) & 0x7FFFu) << 17);
    d[6] = (o && o->lda) ? o->lda : k;
    d[7] = (o && o->ldb) ? o->ldb : n;
    d[8] = (o && o->ldc) ? o->ldc : esz * n;
    if (o && o->out_int8) {
        d[9] = (TSU_OFMT_INT8 << 4) | ((o->relu ? 1u : 0u) << 14);
        d[10] = (uint32_t)o->qmult;
        d[11] = ((uint32_t)o->qshift & 0x3Fu) | ((uint32_t)(uint8_t)o->qzp << 8);
    }
}

/* The hardware rule order: VERSION OPCODE FLAGS RSVD RM LAYOUT PRECISION DIM_ZERO DIM_RANGE CHUNK LD ALIGN
 * ADDR_OVF RANGE ALIAS.  64-bit arithmetic, as in the RTL: nothing wraps. */
int tsu_check(const tsu_dev_t *dev, const uint32_t w[TSU_DESC_WORDS])
{
    uint32_t op = FIELD(w[0], 0, 8), ver = FIELD(w[0], 8, 4), rm = FIELD(w[0], 12, 3), h15 = FIELD(w[0], 15, 1);
    uint32_t flags = FIELD(w[0], 16, 8), ofmt = FIELD(w[9], 4, 2), relu = FIELD(w[9], 14, 1);
    uint32_t m = w[4] & 0xFFFFu, n = w[4] >> 16, k = w[5] & 0x1FFFFu, kc = w[5] >> 17, kce, esz;
    uint64_t al, bl, cl, chunks, lo = dev->mem_lo, hi = (uint64_t)dev->mem_last + 1u;
    int int8 = (ofmt == TSU_OFMT_INT8);
    unsigned i;

    if (ver != TSU_ABI_VERSION) return TSU_E_VERSION;
    if (op != TSU_OP_NOP && op != TSU_OP_GEMM) return TSU_E_OPCODE;
    if (op == TSU_OP_NOP) {
        if (flags & ~((1u << TSU_FL_IRQ) | (1u << TSU_FL_BARRIER)) & 0xFFu) return TSU_E_FLAGS;
        if (h15 || rm) return TSU_E_RSVD;
        for (i = 1; i < TSU_DESC_WORDS; i++) if (w[i]) return TSU_E_RSVD;
        return TSU_E_NONE;
    }
    if ((flags & ~TSU_FL_MASK & 0xFFu) || (((flags >> TSU_FL_PREFETCH) & 1u) && !dev_dbuf(dev))) return TSU_E_FLAGS;
    if (h15 || (w[9] & TSU_W9_RSVD_MASK) || (w[11] & TSU_W11_RSVD_MASK)) return TSU_E_RSVD;
    if (ofmt == TSU_OFMT_INT32 && (rm || relu || w[10] || w[11])) return TSU_E_RSVD;
    if (int8 && rm > TSU_RM_RMM) return TSU_E_RM;
    if (FIELD(w[9], 8, 2) || FIELD(w[9], 10, 2) || FIELD(w[9], 12, 2)) return TSU_E_LAYOUT;
    if (FIELD(w[9], 0, 2) || FIELD(w[9], 2, 2) || !(ofmt == TSU_OFMT_INT32 || (int8 && dev_quant(dev))))
        return TSU_E_PRECISION;
    if (m == 0 || n == 0 || k == 0) return TSU_E_DIM_ZERO;
    if (k > dev->k_max) return TSU_E_DIM_RANGE;
    kce = kc ? kc : dev_tile_k(dev);
    chunks = ((uint64_t)k + kce - 1u) / kce;
    if (kc > dev_tile_k(dev) || chunks > 65535u) return TSU_E_CHUNK;
    esz = int8 ? 1u : 4u;
    if (w[6] < k || w[7] < n || (uint64_t)w[8] < (uint64_t)esz * n) return TSU_E_LD;
    if (!int8 && ((w[3] & 3u) || (w[8] & 3u))) return TSU_E_ALIGN;
    al = (uint64_t)w[1] + (uint64_t)(m - 1u) * w[6] + k - 1u;
    bl = (uint64_t)w[2] + (uint64_t)(k - 1u) * w[7] + n - 1u;
    cl = (uint64_t)w[3] + (uint64_t)(m - 1u) * w[8] + (uint64_t)esz * n - 1u;
    if ((al >> 32) || (bl >> 32) || (cl >> 32)) return TSU_E_ADDR_OVF;
    if (w[1] < lo || al >= hi || w[2] < lo || bl >= hi || w[3] < lo || cl >= hi) return TSU_E_RANGE;
    if (((uint64_t)w[3] <= al && (uint64_t)w[1] <= cl) || ((uint64_t)w[3] <= bl && (uint64_t)w[2] <= cl))
        return TSU_E_ALIAS;
    return TSU_E_NONE;
}

int tsu_submit(tsu_dev_t *dev, const uint32_t d[TSU_DESC_WORDS])
{
    unsigned i;
    if (((TSU_RD32(TSU_R_STATUS) >> TSU_SB_QFREE_LO) & 0xFFu) == 0u) return TSU_EBUSY;  /* never ring a full queue */
    for (i = 0; i < TSU_DESC_WORDS; i++) TSU_WR32(TSU_R_DESC0 + 4u * i, d[i]);
    TSU_WR32(TSU_R_DOORBELL, 1u);
    if (TSU_LAST_ERR()) return TSU_EBUSY;              /* refused: exactly nothing happened, safe to retry */
    dev->submitted++;
    return 0;
}

int tsu_poll(tsu_dev_t *dev, tsu_record_t *r)
{
    unsigned i;
    uint32_t w0;
    if (!(TSU_RD32(TSU_R_STATUS) & (1u << TSU_SB_CPL_VALID))) return 0;
    for (i = 0; i < TSU_CPL_WORDS; i++) r->raw[i] = TSU_RD32(TSU_R_CPL0 + 4u * i);
    TSU_WR32(TSU_R_CPL_POP, 1u);
    w0 = r->raw[0];
    r->tid = (uint8_t)FIELD(w0, 0, 8);
    r->opcode = (uint8_t)FIELD(w0, 8, 8);
    r->err = (uint8_t)FIELD(w0, 16, 8);
    r->status = (uint8_t)FIELD(w0, 24, 2);
    r->irq = (uint8_t)FIELD(w0, 26, 1);
    r->sat = (uint8_t)FIELD(w0, 27, 1);
    r->detail = (uint8_t)FIELD(w0, 28, 4);
    r->count = r->raw[1];
    r->err_addr = r->raw[2];
    r->seq = r->raw[3];
    r->cycles = r->raw[4];
    r->tiles = r->raw[5];
    dev->next_seq = r->seq + 1u;
    return 1;
}

int tsu_wait(tsu_dev_t *dev, tsu_record_t *r, uint32_t budget)
{
    uint32_t i;
    if (budget == 0) budget = 50000000u;
    for (i = 0; i < budget; i++) {
        if (tsu_poll(dev, r)) return 0;
        if (TSU_RD32(TSU_R_STATUS) & (1u << TSU_SB_HALTED)) {
            if (tsu_poll(dev, r)) return 0;            /* the halting command's record comes first */
            return TSU_EHALTED;
        }
    }
    return TSU_ETIMEDOUT;
}

void tsu_set_continue_on_error(int on) { TSU_WR32(TSU_R_CTRL, on ? 1u : 0u); }
void tsu_clear_error(void) { TSU_WR32(TSU_R_CTRL, (TSU_RD32(TSU_R_CTRL) & 1u) | (1u << TSU_CTRL_ERR_CLEAR)); }
void tsu_clear_counters(void) { TSU_WR32(TSU_R_CTRL, (TSU_RD32(TSU_R_CTRL) & 1u) | (1u << TSU_CTRL_PERF_CLEAR)); }
void tsu_abort(void) { TSU_WR32(TSU_R_CTRL, (TSU_RD32(TSU_R_CTRL) & 1u) | (1u << TSU_CTRL_ABORT)); }
uint32_t tsu_counter(int i) { return TSU_RD32(TSU_R_PERF0 + 4u * (uint32_t)i); }
uint32_t tsu_status(void) { return TSU_RD32(TSU_R_STATUS); }

int tensor_gemm(tsu_dev_t *dev, uint32_t A, uint32_t B, uint32_t C, uint32_t M, uint32_t N, uint32_t K,
                const tsu_opts_t *opts, tsu_record_t *rec_out)
{
    uint32_t d[TSU_DESC_WORDS];
    tsu_record_t rec;
    uint8_t tid = dev->next_tid++;
    uint32_t seq;
    int rc;

    tsu_build_gemm(d, tid, A, B, C, M, N, K, opts);                       /* prepare */
    rc = tsu_check(dev, d);                                               /* validate */
    if (rc != 0 && !(opts && opts->skip_host_check)) return TSU_EINVAL;
    /* every older record must have been collected, so this command's record is the next one */
    while (tsu_poll(dev, &rec)) { }
    seq = dev->next_seq;
    do { rc = tsu_submit(dev, d); } while (rc == TSU_EBUSY);              /* submit */
    rc = tsu_wait(dev, &rec, opts ? opts->poll_budget : 0u);              /* wait for completion */
    if (rc != 0) return rc;
    if (rec_out) *rec_out = rec;                                          /* read the status */
    if (rec.tid != tid || rec.seq != seq) return TSU_EPROTO;
    if (rec.status != TSU_ST_OK) return rec.err ? (int)rec.err : TSU_EPROTO;   /* check errors */
    return 0;
}

const char *tsu_err_name(int code)
{
    switch (code) {
    case 0x00: return "NONE";      case 0x01: return "VERSION";   case 0x02: return "OPCODE";
    case 0x03: return "FLAGS";     case 0x04: return "RSVD";      case 0x05: return "RM";
    case 0x06: return "LAYOUT";    case 0x07: return "PRECISION"; case 0x08: return "DIM_ZERO";
    case 0x09: return "DIM_RANGE"; case 0x0A: return "CHUNK";     case 0x0B: return "LD";
    case 0x0C: return "ALIGN";     case 0x0D: return "ADDR_OVF";  case 0x0E: return "RANGE";
    case 0x0F: return "ALIAS";     case 0x18: return "DMA_READ";  case 0x19: return "DMA_WRITE";
    case 0x1A: return "DMA_REJECT"; case 0x1B: return "DMA_PROTO"; case 0x20: return "BUF_ACCESS";
    case 0x21: return "COMPUTE";   case 0x22: return "OUTBUF";    case 0x28: return "ACC_OVF";
    case 0x29: return "QUANT";     case 0x30: return "TIMEOUT";   case 0x38: return "ABORTED";
    case 0x40: return "PRIOR";
    case TSU_EINVAL: return "EINVAL (host check)"; case TSU_EBUSY: return "EBUSY";
    case TSU_ETIMEDOUT: return "ETIMEDOUT"; case TSU_EABI: return "EABI"; case TSU_EPROTO: return "EPROTO";
    case TSU_EHALTED: return "EHALTED";
    default: return "?";
    }
}
