// =============================================================================
// SilicaFlux TENSORCORE 08 :: sfx_hpc_tensor_system
// The tensor unit next to the existing SilicaFlux-HPC compute tile, on the real
// DataFabric crossbar.  Every block is reused unmodified except this wiring.
//
//   host register bus (page 8 / page 9) ──► HPC Module 08 silicaflux_hpc_tile (FP32 vector array, scratchpad, DMA)
//                                       └─► silicaflux_tensor_unit (INT8 GEMM)
//
//   SFB2 masters                                  DataFabric sfb_crossbar (round robin, R6)      SFB2 slaves
//     m0  host CPU data port (testbench / SoC) ─┐                                              ┌─► s0 shared SRAM window
//     m1  HPC tile DMA (fab_*)                 ─┼──────────────────────────────────────────────┤
//     m2  tensor unit DMA (m_*)                ─┘                                              └─► s1 tile scratchpad window (hs_*)
//
// RESOURCE OWNERSHIP (docs/06):
//   * shared SRAM (s0): reachable by all three masters; software partitions it.  The tensor unit's legal window
//     (MEM_LO / MEM_HI) is exactly this SRAM, and its validation rejects commands outside it (RANGE).
//   * tile scratchpad (s1): owned by the tile; only the host may reach it through the fabric (access matrix).
//     The tensor unit can neither read nor write it (decode error, never a silent alias).
//   * tensor operand / output buffers: private to the tensor unit, not mapped on the fabric at all.
//   * arbitration: one round-robin arbiter per slave (DataFabric sfb_arbiter: a waiting master is served after
//     at most NM-1 other acceptances; proven in DataFabric).  One transaction per port (R6).
//   * no coherence: there are no caches in this system; whoever produces data must have it acknowledged (both
//     units report completion only after every write was acknowledged, SFB2 R7) before the consumer is started.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tsu_defs.svh"
`default_nettype none

module sfx_hpc_tensor_system #(
  parameter logic [31:0] SRAM_BASE  = 32'h1000_0000,
  parameter int          SRAM_BYTES = 1 << 20,
  parameter logic [31:0] SPM_BASE   = 32'h2000_0000,
  parameter int          SPM_BYTES  = 65536,
  // tensor unit
  parameter int          TSU_QUANT  = 1,
  parameter int          TSU_DBUF   = 1,
  parameter int          TSU_MAXOUT = 4
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // ---------------------------------------------------------- host register bus (SilicaFlux-V rb, 16 pages of 4 KiB)
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [15:0] rb_addr,          // [15:12] page: 8 = HPC tile, 9 = tensor unit
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // ---------------------------------------------------------- host CPU data port (SFB2 master m0)
  input  wire logic        h_req_valid,
  output logic             h_req_ready,
  input  wire logic        h_req_write,
  input  wire logic [31:0] h_req_addr,
  input  wire logic [31:0] h_req_wdata,
  input  wire logic [3:0]  h_req_wstrb,
  output logic             h_rsp_valid,
  input  wire logic        h_rsp_ready,
  output logic [31:0]      h_rsp_rdata,
  output logic             h_rsp_error,
  // ---------------------------------------------------------- shared SRAM (SFB2 slave s0)
  output logic             s_req_valid,
  input  wire logic        s_req_ready,
  output logic             s_req_write,
  output logic [31:0]      s_req_addr,
  output logic [31:0]      s_req_wdata,
  output logic [3:0]       s_req_wstrb,
  input  wire logic        s_rsp_valid,
  output logic             s_rsp_ready,
  input  wire logic [31:0] s_rsp_rdata,
  input  wire logic        s_rsp_error,
  // ---------------------------------------------------------- interrupts / status
  output logic             tile_irq,
  output logic             tsu_irq,
  output logic             tile_busy,
  output logic             tsu_busy,
  output logic             tsu_halted,
  // ---------------------------------------------------------- monitor taps (verification / telemetry)
  output logic [2:0]       mon_req_stall,     // per master: request presented and not accepted
  output logic [2:0]       mon_req_accept,    // per master: request accepted
  output logic [2:0]       mon_arb_loss       // per master: eligible but another master won the slave
);
  // ============================================================ register pages
  wire        p_tile = rb_addr[15:12] == 4'd8;
  wire        p_tsu  = rb_addr[15:12] == 4'd9;
  logic [31:0] t_rdata, u_rdata;
  logic        t_err, u_err;
  assign rb_rdata = p_tile ? t_rdata : p_tsu ? u_rdata : 32'd0;
  assign rb_err   = rb_sel && (p_tile ? t_err : p_tsu ? u_err : 1'b1);   // unmapped page: refused

  // ============================================================ fabric signals
  localparam int NM = 3, NS = 2;
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb;
  logic [NS-1:0]    x_req_valid, x_req_ready, x_req_write, x_rsp_valid, x_rsp_ready, x_rsp_error;
  logic [NS*32-1:0] x_req_addr, x_req_wdata, x_rsp_rdata;
  logic [NS*4-1:0]  x_req_wstrb;

  // m0: host
  assign m_req_valid[0] = h_req_valid;  assign h_req_ready = m_req_ready[0];  assign m_req_write[0] = h_req_write;
  assign m_req_addr[31:0] = h_req_addr; assign m_req_wdata[31:0] = h_req_wdata; assign m_req_wstrb[3:0] = h_req_wstrb;
  assign h_rsp_valid = m_rsp_valid[0];  assign m_rsp_ready[0] = h_rsp_ready;  assign h_rsp_rdata = m_rsp_rdata[31:0];
  assign h_rsp_error = m_rsp_error[0];

  // ============================================================ HPC Module 08 compute tile (unmodified)
  logic        hs_req_valid, hs_req_ready, hs_req_write, hs_rsp_valid, hs_rsp_ready, hs_rsp_error;
  logic [31:0] hs_req_addr, hs_req_wdata, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        tile_halted_u;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_hpc_tile #(.SPM_BASE(SPM_BASE), .SCRATCHPAD_BYTES(SPM_BYTES)) u_tile (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel && p_tile), .rb_we(rb_we), .rb_addr(rb_addr[11:0]), .rb_wdata(rb_wdata), .rb_rdata(t_rdata),
    .rb_err(t_err),
    .hs_req_valid(hs_req_valid), .hs_req_ready(hs_req_ready), .hs_req_write(hs_req_write), .hs_req_addr(hs_req_addr),
    .hs_req_wdata(hs_req_wdata), .hs_req_wstrb(hs_req_wstrb), .hs_rsp_valid(hs_rsp_valid),
    .hs_rsp_ready(hs_rsp_ready), .hs_rsp_rdata(hs_rsp_rdata), .hs_rsp_error(hs_rsp_error),
    .fab_req_valid(m_req_valid[1]), .fab_req_ready(m_req_ready[1]), .fab_req_write(m_req_write[1]),
    .fab_req_addr(m_req_addr[63:32]), .fab_req_wdata(m_req_wdata[63:32]), .fab_req_wstrb(m_req_wstrb[7:4]),
    .fab_rsp_valid(m_rsp_valid[1]), .fab_rsp_ready(m_rsp_ready[1]), .fab_rsp_rdata(m_rsp_rdata[63:32]),
    .fab_rsp_error(m_rsp_error[1]),
    .irq(tile_irq), .busy(tile_busy), .halted(tile_halted_u));

  // ============================================================ tensor unit
  /* verilator lint_off UNUSEDSIGNAL */
  logic [`TSU_NUM_PC*32-1:0] tsu_ev;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_tensor_unit #(
    .ENABLE_QUANTIZATION(TSU_QUANT), .ENABLE_DOUBLE_BUFFERING(TSU_DBUF), .MAX_OUT(TSU_MAXOUT),
    .MEM_LO(33'(SRAM_BASE)), .MEM_HI(33'(SRAM_BASE) + 33'(SRAM_BYTES))
  ) u_tsu (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel && p_tsu), .rb_we(rb_we), .rb_addr(rb_addr[11:0]), .rb_wdata(rb_wdata), .rb_rdata(u_rdata),
    .rb_err(u_err),
    .m_req_valid(m_req_valid[2]), .m_req_ready(m_req_ready[2]), .m_req_write(m_req_write[2]),
    .m_req_addr(m_req_addr[95:64]), .m_req_wdata(m_req_wdata[95:64]), .m_req_wstrb(m_req_wstrb[11:8]),
    .m_rsp_valid(m_rsp_valid[2]), .m_rsp_ready(m_rsp_ready[2]), .m_rsp_rdata(m_rsp_rdata[95:64]),
    .m_rsp_error(m_rsp_error[2]),
    .irq(tsu_irq), .busy(tsu_busy), .halted(tsu_halted), .perf_ev(tsu_ev), .fi_mode(2'd0));

  // ============================================================ DataFabric crossbar (unmodified)
  // access matrix, bit m*NS+s:  host -> SRAM, SPM;  tile DMA -> SRAM;  tensor unit -> SRAM only
  localparam logic [NM*NS-1:0] EN = 6'b01_01_11;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        x_err_evt;
  logic [31:0] x_err_addr;
  logic [1:0]  x_err_master;
  logic        x_err_write;
  logic [NM-1:0] x_rsp_stall;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_crossbar #(
    .NM(NM), .NS(NS), .AW(32), .DW(32), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE({SPM_BASE, SRAM_BASE}), .SLV_MASK({32'(~(SPM_BYTES - 1)), 32'(~(SRAM_BYTES - 1))}), .MST_SLV_EN(EN)
  ) u_xbar (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .s_req_valid(x_req_valid), .s_req_ready(x_req_ready), .s_req_write(x_req_write), .s_req_addr(x_req_addr),
    .s_req_wdata(x_req_wdata), .s_req_wstrb(x_req_wstrb), .s_rsp_valid(x_rsp_valid), .s_rsp_ready(x_rsp_ready),
    .s_rsp_rdata(x_rsp_rdata), .s_rsp_error(x_rsp_error),
    .err_evt(x_err_evt), .err_addr(x_err_addr), .err_master(x_err_master), .err_write(x_err_write),
    .ev_req_accept(mon_req_accept), .ev_req_stall(mon_req_stall), .ev_arb_loss(mon_arb_loss), .ev_rsp_stall(x_rsp_stall));

  // s0: shared SRAM (external port)
  assign s_req_valid = x_req_valid[0];  assign x_req_ready[0] = s_req_ready;  assign s_req_write = x_req_write[0];
  assign s_req_addr = x_req_addr[31:0]; assign s_req_wdata = x_req_wdata[31:0]; assign s_req_wstrb = x_req_wstrb[3:0];
  assign x_rsp_valid[0] = s_rsp_valid;  assign s_rsp_ready = x_rsp_ready[0];  assign x_rsp_rdata[31:0] = s_rsp_rdata;
  assign x_rsp_error[0] = s_rsp_error;
  // s1: the tile's host scratchpad window
  assign hs_req_valid = x_req_valid[1];  assign x_req_ready[1] = hs_req_ready;  assign hs_req_write = x_req_write[1];
  assign hs_req_addr = x_req_addr[63:32]; assign hs_req_wdata = x_req_wdata[63:32]; assign hs_req_wstrb = x_req_wstrb[7:4];
  assign x_rsp_valid[1] = hs_rsp_valid;  assign hs_rsp_ready = x_rsp_ready[1];  assign x_rsp_rdata[63:32] = hs_rsp_rdata;
  assign x_rsp_error[1] = hs_rsp_error;
endmodule

`default_nettype wire
