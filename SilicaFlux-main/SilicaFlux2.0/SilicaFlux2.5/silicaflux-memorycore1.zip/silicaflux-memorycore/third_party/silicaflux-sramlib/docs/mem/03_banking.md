# 03 — Banking (`sram_bank_controller`)

```
 master 0 ─┐                 ┌─ bank 0 (sram_backend_1rw) ─┐
 master 1 ─┼─ decode ─ per-bank RR arbiters ─┤  …                          ├─ owner pipelines ─ per-master
   …       │  (bank,row,err)  (1 grant/bank/cycle)                         │  (route read data)   rsp FIFO + credits
 master N ─┘                 └─ bank B-1 ──────────────────┘                  (sram_rsp_path, in order, ID)
```

| Feature | Implementation |
|---|---|
| Bank count | `NUM_BANKS` = 1, 2, 4, 8 (any power of two); non-powers rejected |
| Interleave | `SRAM_ILV_LOW` (default): bank = word % B, row = word / B — sequential and unit-stride streams rotate across banks.  `SRAM_ILV_HIGH`: bank = word / BANK_DEPTH (contiguous regions; `BANK_DEPTH` power of two) |
| Addressing | word or byte (`ADDR_MODE`), any `ADDR_WIDTH` ≥ needed (system addresses allowed); out-of-range and misaligned requests are answered with `rsp_err` in order |
| Arbitration | per-bank round robin (`SRAM_ARB_RR`, default; a master holding a request is granted within `NUM_MASTERS` grants — formally bounded-proven for 2×2) or fixed priority (`SRAM_ARB_FIXED`, master 0 highest; lower masters can starve under sustained contention — documented, not hidden) |
| Acceptance | `m_req_ready` = granted this cycle (or error request with a free credit); acceptance == issue |
| Backpressure | per-master response credits (`RSP_FIFO_DEPTH`); a stalled master never blocks another master's banks |
| Transaction identity | `m_req_id` → `m_rsp_id`; per-master responses strictly in acceptance order (all accesses take exactly `READ_LATENCY`, one issue per master per cycle) |
| Routing | per-bank owner pipeline (`READ_LATENCY` deep) selects which master receives each bank's read data |
| Error detection | out-of-range, misaligned (byte mode) |
| Perf hooks | `m_stall_conflict[m]`: master was ready to issue but lost bank arbitration |
| Coherence | none (not required: the only coherence-related RTL in the repository is the 2.5 controller's write-notify output, which has no consumer) |
| MBIST | `tst_sel[b]` selects banks; identical banks may be tested in parallel |

Assertions (RTL, `SRAMLIB_ASSERT`): one grant per bank, grant ⊆ request, read-data owner == master response stage
(misrouted or dropped read), no master receives data from two banks in one cycle (duplicate), no functional access
in test mode; plus the response-path checks of `sram_rsp_path` per master.

## Access patterns (measured, `reports/mem/analysis.md`)

The banking testbench doubles as a workload generator (`+wl=`): CPU sequential, vector unit-stride streaming,
tensor tile loads (8×8 tiles of a 64-word-wide matrix), DMA 64-word bursts, mixed (one of each per master) and a
pathological stride-by-`NUM_BANKS` pattern.  Every run is self-checking.  Typical results with 4 masters on
32-bit words (seed and cycles in the report): unit-stride streams reach `min(masters, banks)` words/cycle; random
traffic is limited by bank conflicts; stride-by-B collapses to one bank (1 word/cycle) — the classic argument for
low-order interleave plus software-visible stride awareness (or XOR interleave, a listed next action).
