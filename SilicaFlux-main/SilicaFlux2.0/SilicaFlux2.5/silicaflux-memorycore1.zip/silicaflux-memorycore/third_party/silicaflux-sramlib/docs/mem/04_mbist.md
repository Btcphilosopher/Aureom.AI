# 04 — MBIST integration

## Contract (the stable part)

Every library memory exposes a raw **test port** (`tst_active, tst_ce, tst_we, tst_addr, tst_wdata →
tst_rdata`; the bank controller adds `tst_sel`).  Semantics (also `01_interface_spec.md` §8):

| Signal | Meaning |
|---|---|
| `tst_active` | normal/test access selection.  While high the array belongs to the test bus and functional `req_ready` is 0 (functional requests already accepted still complete) |
| `tst_sel` | bank selection (bank controller) / memory selection (bus level, via `sram_mbist_adapter`) |
| `tst_ce`, `tst_we` | one operation per cycle; 1R1W memories route writes to the write port and reads to the read port, never both in one cycle |
| `tst_addr`, `tst_wdata` | all lanes written; addresses ≥ DEPTH are ignored |
| `tst_rdata` | raw array data exactly `READ_LATENCY` cycles after a test read (compare at that cycle; never held) |

This is the same bus as the repository's TestCore (`silicaflux-testcore.zip::rtl/tc_mbist.sv` →
`tc_mbist_collar.sv`): `bist_active`, `bist_sel`, `bist_ce`, `bist_we`, `bist_addr`, `bist_wdata`, `bist_rdata`
with registry latency = memory latency + pipeline stages.  `sram_mbist_adapter` connects one library memory to that
bus (width truncation/extension and optional `IN_PIPE` / `OUT_PIPE` test-path registers for timing closure), so
either TestCore's `tc_mbist` or this library's demonstration controller can drive the memories.  The library's
wrappers already provide what the TestCore collar adds around a bare macro (functional block, test mux), so no
collar is needed in front of them.

## Demonstration controller `sram_mbist_march`

* Control/status handshake: `start` pulse → `busy` → `done` (held until the next start) with `pass` / `fail`.
* Algorithms: March C- (10N) and MATS+ (5N); solid or checkerboard background.
* Serial testing of the selected targets (`target_mask`), per-target depth and width (`TARGET_MAXADDR`,
  `TARGET_DW`), one operation per cycle, compare at exactly `READ_LATENCY`.
* Results: per-target fail mask, saturating fail count, **first failure: target, March element, address and
  syndrome (expected XOR actual)**; `stop_on_fail`; an empty selection reports FAIL (never a false PASS).

## Verified (tb_sram_mbist; `reports/mem/regression.md`)

Six targets of three kinds on one bus — `sram_sp` 32×100 (non-power-of-two), `sram_1r1w` 16×64, four banks of a
`sram_bank_controller` — at latency 1 and at latency 2 with one input and one output pipeline stage per adapter
(controller latency 4):

| Injected fault (GENERIC backend hook) | Expected first failure (derived by hand from March C-) | Observed |
|---|---|---|
| SA0 target 0, word 37, bit 5 | element 2 (⇑ r1,w0), word 37 | element 2, word 37, syndrome `0x20` |
| SA1 target 0, word 99, bit 31 | element 1, word 99 | element 1, word 99, syndrome `0x80000000` |
| transition 0→1 target 1, word 10, bit 15 | element 2, word 10 | as expected |
| transition 1→0 target 1, word 0, bit 0 | element 3 (⇓ r0,w1), word 0 | as expected |
| idempotent coupling 3.1 → 20.7, target 2 | element 1, victim word 20 | as expected |
| address-decoder fault 5 → 9, target 4 | element 1, word 9 | as expected |
| SA0 target 5, word 31, bit 0 | element 2, word 31 | as expected |

Also: fault-free March C- (solid, checkerboard) and MATS+ pass; MATS+ detects SA1; stop-on-fail; empty-selection
FAIL; functional traffic after MBIST sees the March background.  A mutant with a wrong March element is detected by
the same testbench (mutation suite).

## Limits (not claimed)

No production fault coverage is claimed: no formal fault-model coverage analysis, no retention/pause elements, no
macro-specific (column-mux / bit-line) algorithms, no ATPG interaction ("RAM sequential" models or scan bypass), no
repair.  Hard macros with built-in test pins (IHP `*_BIST_*`) are currently driven through their functional pins;
using the macro's own BIST mux is a per-family leaf change (respecting the datasheet's one-idle-cycle rule around
`*_BIST_EN`) and is listed as a next action.
