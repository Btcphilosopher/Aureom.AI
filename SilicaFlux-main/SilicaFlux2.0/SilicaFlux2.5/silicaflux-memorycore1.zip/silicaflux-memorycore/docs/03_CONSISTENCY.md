# 03 — The memory-consistency contract

This is the precise contract under which the ControlCore, the system DMA, the vector engine (HPC tile), the
TensorCore and the debug / host port share data through MemoryCore. Every rule names the test that checks it
(docs/09). **A unified address map is not hardware coherence**: the only caches belong to the ControlCore, they are
noncoherent, and visibility between the ControlCore and everybody else is established by software with the
operations below.

## 1. Agents, paths and observation points

| Requester (port) | Path through MemoryCore | Caches |
|---|---|---|
| DBG (m0) — debug / external host | `sfmem_port` → target | none |
| CPUI (m1) — ControlCore fetch | [I-cache, optional] → `sfmem_port` → target | I-cache (ICACHE_EN, default absent) |
| CPUD (m2) — ControlCore data | [D-cache] → `sfmem_port` → target | D-cache (DCACHE_EN, default present, **disabled at reset**) |
| SDMA (m3), VDMA (m4), TDMA (m5) | `sfmem_port` → target | none |

Targets: LMEM and SRAM (banked memories, one port per requester), EXT, VSPM, MMIO (narrow targets, one shared
downstream port each), MEMCTL (internal register page). Engine-internal memories (vector scratchpad engine ports,
TensorCore operand / accumulator / output buffers) are outside MemoryCore and are reached only by their engine.

## 2. Definitions

* **Accepted**: the cycle in which `req_valid && req_ready` at the requester port (for the ControlCore: at the
  cache's upstream port).
* **Performed**: a write is performed when the target array or register holds it; a read is performed when the
  target samples the data it returns.
* **Completed**: the requester has taken the response (`rsp_valid && rsp_ready`). SFB2 R7: the response to a write
  is issued only after the write is performed.
* **Serialization point**: for SRAM and LMEM, the acceptance cycle — MemoryCore adds no cycle and no buffer between
  the requester port and `sram_bank_controller`, which performs an access at its acceptance edge
  (`bwlab_compare`: 49/49 runs cycle-identical to the validated controller model). For EXT, VSPM and MMIO, the
  acceptance by the downstream target (MemoryCore forwards in its own acceptance order).

## 3. Rules for uncached accesses (every requester, and the ControlCore with caches off / non-cacheable addresses)

| # | Rule | Checked by |
|---|---|---|
| C1 | **Single-copy atomicity.** An aligned 32-bit access is performed as one indivisible access; a write's enabled bytes are written together. Misaligned addresses are refused (MISALIGNED), never split. | `bytes`, `partial`, `bounds`; scoreboard |
| C2 | **Per-location total order.** All accesses to one SRAM / LMEM word are totally ordered by their serialization points (one grant per bank per cycle). A read returns, byte for byte, the value of the latest write to that byte serialized **before** it (writes of the same cycle are to other banks). | serialization scoreboard on every SRAM / LMEM read of every run (docs/09 §3) |
| C3 | **Per-requester order.** Each requester's responses return in its acceptance order (ordering FIFO in `sfmem_port`). Accesses of one requester to the same target are performed in that order. Accesses of one requester to **different** targets may be performed in either order. | protocol checkers; `hazard` (RAW / WAW / WAR with 4 in flight); mutants P5, T2 |
| C4 | **Completion implies visibility.** When a write has completed, every access serialized at that target afterwards — by any requester — observes it. | `multi`, `hazard`, `visibility` |
| C5 | **Message passing.** Producer: data writes; then the flag write. Consumer: read the flag until set; then read the data. Correct if data and flag are in the **same banked memory** (C2 + C3: the flag write is serialized after the data writes). If they are on **different targets**, the producer must wait for the data writes to complete before writing the flag (a local fence; `sfmem_fence()` on the ControlCore). | `multi` (both forms, data reads forced-checked) |
| C6 | **Refused accesses have no side effect.** UNMAPPED, DENIED, MISALIGNED, OWNERSHIP and REG errors are answered in order with `rsp_error = 1`, `rdata = 0`, and change nothing. | `bounds`, `ownership`, `semaphore` |

## 4. The ControlCore caches (noncoherent)

| # | Rule | Checked by |
|---|---|---|
| K1 | An address is cached only if: the cache is enabled (CACHE_CTRL), the region is cacheable in the map **and** enabled in CACHE_REGIONS (reset: EXT only), the address is word aligned, and it lies outside both non-cacheable windows. Everything else bypasses with zero added cycles and the uncached rules. | `cache`, `visibility`, `random`; mutants C7, C8, R4 |
| K2 | **No snooping.** A cached line is not updated or invalidated by any other requester's write; another requester never sees data held only in the cache. | `visibility` negative controls (model-predicted stale values); system T1, T2 |
| K3 | **Write-back (default).** A store to a cached line completes in the cache; memory sees it only after CLEAN (or an eviction). Store miss = write-allocate (refill, merge). **Write-through** (DCACHE_WB = 0): a store completes only after memory acknowledged it (C4 applies); no allocation on a store miss. | `cache` (both builds), `cmo` |
| K4 | **Maintenance**: CLEAN writes back every dirty line in scope and keeps it valid; INVAL drops every line in scope **including dirty data** (reported as DIRTY_DISCARD); CLEAN_INVAL writes back then drops. Scope: ALL, or every line that intersects [ADDR, ADDR+SIZE). | `cmo`; mutants C3, C4, C10 |
| K5 | **Implicit fence (D-cache).** A D-cache command issued by the ControlCore is executed after all of its earlier data accesses have completed and before any later one is accepted; when the next data access returns, the command is done and its write-backs have completed (C4). | `cmo`; mutant C6 |
| K6 | **I-cache commands are asynchronous** to the data port: poll CMO_STATUS.BUSY (the API does). FENCE.I only flushes the CPU's 2-entry prefetch buffer. | `cmo` (found by the regression: docs/09 §6) |
| K7 | Changing CACHE_CTRL, CACHE_REGIONS or a non-cacheable window does not touch cache contents: CLEAN_INVAL the affected range first (the API does). | `cache` (disable / re-enable hits stale lines by design) |
| K8 | Write-back errors are imprecise: the line's data is lost, WRITEBACK + TARGET are logged, IRQ_STATUS.WB_ERR and CMO_STATUS.WB_ERR are set. Refill errors are precise: the access fails, the line is not installed. | `wberr`, `parity`; mutant C9 |

## 5. DMA / engine visibility protocol (software)

Buffers have exactly one **owner** at a time: the CPU or a device (DMA, vector engine, TensorCore).

| Transition | ControlCore must | API |
|---|---|---|
| CPU wrote a buffer → a device reads it | CLEAN the range (write-through: nothing to do; the call is cheap) | `sfmem_dma_to_device(buf, len)` |
| device will write a buffer → the CPU reads it afterwards | **before** starting the device: CLEAN_INVAL the range (no dirty line may be evicted over device data later); **after** the completion record: INVAL the range (drop lines allocated in between) | `sfmem_dma_from_device_begin / _end` |
| device reads and writes a buffer | begin: CLEAN_INVAL; end: INVAL | `sfmem_dma_bidir_begin`, `_end` |
| fine-grained sharing (descriptors, mailboxes, flags) | put it in a non-cacheable window — no maintenance | `sfmem_set_noncacheable` |

Rules: (a) while a device owns a buffer the CPU neither reads nor writes it; (b) receive / bidirectional buffers are
cache-line aligned and a whole number of lines (`SFMEM_DMA_ALIGN`; the API refuses others with SFMEM_EALIGN) —
otherwise a neighbouring CPU variable shares a line and either the CPU's write-back destroys device data or the
invalidate destroys CPU data; (c) a device is started by an MMIO write, which is ordered after a completed CLEAN
(K5); (d) a device's completion record is read by an uncached MMIO read; all device writes were acknowledged
before the record was posted (HPC tile and TENSORCORE 08 both guarantee this, SFB2 R7) — so after INVAL the CPU
sees them.

**Demonstrated** on the real ControlCore RTL (`reports/system.md`): T1 the DMA copies a buffer the CPU did not clean
and receives the stale pre-CLEAN data, exactly as predicted; T2 the CPU reads stale GEMM output until it
invalidates; the correct protocol gives bit-exact results in T1–T6. At the subsystem level `visibility` also shows
the destructive case (a dirty line written back over DMA data when the buffer was not handed over with CLEAN_INVAL).

Engine to engine (no CPU data access in between): the consumer is submitted after the producer's completion record
has been read; nothing else is needed (T3: TensorCore → vector engine). Two engines never own one buffer at once.

## 6. Deadlock freedom of the routing

Responses return in order per requester (C3) while targets serve several requesters. A cycle of waits would need a
requester A waiting at the head of its FIFO for target X, whose oldest response belongs to B, which waits for target
Y, whose oldest response belongs to A. Each narrow target accepts at most one request per cycle and keeps its owner
FIFO in acceptance order; each requester issues at most one request per cycle. The globally oldest outstanding
request R (minimum acceptance cycle; same-cycle acceptances are by different requesters at different targets) is at
the head of its requester's FIFO (all older ones of that requester have completed) and at the head of its target's
owner FIFO (all older ones there have completed) — so R completes once its target answers, and by induction every
request completes. Banked memories keep a separate response FIFO per requester and never block one requester on
another. A requester that stops taking responses blocks only itself and any narrow target whose head it owns.

## 7. Scratchpads, semaphores, errors, reset

| # | Rule | Checked by |
|---|---|---|
| S1 | VSPM partitions owned by the engine (VSPM_OWN bit = 1) refuse host-window accesses (OWNERSHIP, no side effect). Host accesses are **not ordered** with engine commands: hand partitions over only between commands (give after the host's writes completed; take back after the completion record). | `ownership`, `visibility`, system T4 (precise load-access fault) |
| S2 | TensorCore operand / accumulator / output buffers are not addressable by anybody but the TensorCore. | structural (not in the map); docs/05 |
| A1 | A SEMn read is an atomic test-and-set within the MEMCTL page (single serializing slave port): two requesters can never both obtain 0. Release = write 0 by the holder; anything else is refused. Atomicity domain: MEMCTL; it orders no data — release after `sfmem_fence()`. | `semaphore` (mutual-exclusion race checked under stalls); mutant R1 |
| E1 | The first error of any kind is captured (address, cause, requester, write); later ones set OVERFLOW and count. | `bounds`, `wberr`, `parity`; mutant R2 |
| R1 | **Reset** (asynchronous assert): every transaction in flight is cancelled (no response); caches are emptied (dirty data is lost); SRAM / LMEM / EXT contents are kept (arrays are never reset); MEMCTL returns to its reset values. | `reset` (random traffic, reset mid-flight, programs re-run and pass) |
| R2 | **Integration rule — shared reset**: MemoryCore and its requesters share one reset (SFB2 R11). A requester with its own reset (the ControlCore held while the debug port loads LMEM) must have its request valid gated while in reset — the unmodified `sfv_cpu` drives `i_req` in reset; ungated, a fetch accepted then would be answered after reset release and taken as the answer to a different fetch (found by the system test; `integration/sfmem_hpc_system.sv`). | system test |
| I1 | **Initialization (ECC_MODE = PARITY)**: every word must be written once before **any** read — a read returns and checks the whole word, so byte loads, DMA bursts and line refills of never-written words fail with PARITY. Boot code writes all memory it will use (`sfmem_scrub`, the loader zero-fills LMEM). After MBIST the background has non-odd parity: scrub before use. | system test (found), `tb_sfmem_mbist` |

## 8. What is deliberately NOT provided

* No hardware cache coherence (no snooping, no directory, no MESI/MOESI); no coherent port on any engine.
* No multiprocessor memory model: there is one ControlCore hart. The rules above are what the hardware guarantees;
  no claim of sequential consistency across targets is made.
* No ordering between different engines except through completion records read by the ControlCore.
* No atomic read-modify-write on memory (docs/06); atomicity is a single aligned word access (C1) plus the MEMCTL
  semaphores.
* No address translation or protection beyond the per-region access matrix and VSPM ownership.
