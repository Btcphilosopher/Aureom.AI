# 07 — Integrity: byte parity implemented, SECDED hooks for Project 26

## 1. One encode / decode layer

Integrity is applied in exactly **one** place: `sfmem_banked.sv`, between the requester ports and the SRAM library's
bank controller, for the shared SRAM and LMEM. Nothing below it (the library, the macros) and nothing above it (the
router, the caches, the engines) encodes, checks or regenerates check bits. The cache data arrays and the engines'
internal memories are outside this layer (the vector scratchpad has its own Module 04 parity option; the TensorCore
buffers have none) — so no word is ever encoded twice, and nothing re-encodes data it did not check.

## 2. ECC_MODE = PARITY (1, default) — implemented

The HPC Module 04 / MCU-I convention, unchanged:
* stored word = 4 lanes of 9 bits `{p, byte}`, `p = ~^byte` (odd parity: an all-zero lane is detected);
* byte writes stay single-cycle (each lane's check bit depends only on that byte) — no read-modify-write;
* a read whose lane XOR is 0 on any lane answers `rsp_error = 1`, `rdata = 0`; the event logs the address, the lane
  syndrome and the requester (ECC_ERR_ADDR / ECC_ERR_INFO / ECC_ERR_COUNT, ERR_* with cause PARITY, IRQ bit 1);
* `ECC_CTRL.CHECK_DIS` returns data despite bad parity (diagnostics). It is sampled **when the read is accepted** and
  travels with it (a fix found by the regression, docs/09 §6);
* fault injection: `ECC_CTRL.INJECT` + `INJ_LANES` + `INJ_LMEM` inverts the parity of the selected lanes of the next
  write accepted by the selected memory (reads never consume it — mutant B3);
* detects any odd number of flips per lane; does not detect even flips in one lane; corrects nothing.

**Initialization rule.** A read returns and checks all four lanes, so a word must be written once before *any* read:
power-up content (and an MBIST background) has random / non-odd parity. Boot code scrubs memory it will use
(`sfmem_scrub`), the debug loader zero-fills LMEM. Found by the system test (docs/09 §6).

## 3. ECC_MODE = SECDED (2) — reserved, rejected at elaboration

`sfmem_banked` stops elaboration with *"ECC_MODE = SECDED is reserved for Project 26 and NOT implemented"*. No SECDED
protection is claimed.

## 4. Hooks and coordination points for Project 26

| Hook | Where | For |
|---|---|---|
| `ECC_MODE` value 2 | `silicaflux_memory_subsystem`, `sfmem_banked` | selection |
| stored-word width `SW` (32 / 36) | `sfmem_banked` → library `DATA_WIDTH` | (39,32) needs 39 bits, (72,64) needs 72 |
| encode point `c_wdata` / decode point `syn`, `perr` | `sfmem_banked` | one place for encoder / decoder |
| request ID carrying `{check-disable, word offset}` | `sfmem_banked` (library `ID_WIDTH`) | exact error address; sideband for "corrected" flag |
| `par_evt / par_syn / par_addr / par_port` → MEMCTL | `sfmem_regs` | syndrome width becomes the check-bit count; add a corrected-error counter |
| `rsp_error` + cause PARITY | router / requesters | uncorrectable error; a correctable one would answer data with `rsp_error = 0` |
| `INJECT / INJ_LANES` | MEMCTL | single- and double-bit injection |
| MBIST test port, raw stored words | `*_tst_*` | MBIST already sees the stored word (incl. check bits) |

Design constraints Project 26 must resolve (they are why SECDED is not here):
* **Byte writes**: a word-wide SECDED code needs read-merge-encode-write for every partial write — two bank accesses,
  a bank lock against the other five ports, and a read-after-write forwarding hazard. Options: SECDED only for
  word-writing requesters, byte-granular codes, or RMW with bank-busy back-pressure through the existing arbiter.
* **No double encoding**: the encoder replaces the parity encoder in `sfmem_banked`; caches, engines and the bus stay
  unaware. The engines' internal memories keep their own (separate) protection.
* **Scrubbing**: a corrected error must be written back (by hardware or software) or it accumulates.
* Acceptance before any SECDED claim: exhaustive single- and double-bit injection through the backdoor and
  `INJECT`, syndrome and address logging, the initialization rule for the new code.
