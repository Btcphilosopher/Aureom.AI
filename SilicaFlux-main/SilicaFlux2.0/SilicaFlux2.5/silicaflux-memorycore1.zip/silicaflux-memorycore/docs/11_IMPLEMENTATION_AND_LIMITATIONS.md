# 11 — Implementation status and known limitations

## 1. What was run

| Step | Tool | Result |
|---|---|---|
| lint, 10 legal configurations | Verilator 5.020 `-Wall` | 0 warnings in every configuration (`reports/lint.md`) |
| elaboration | Icarus 12, Yosys 0.33 front end (`read -defer`, `hierarchy`, `proc`, `check -assert`) | clean; no latch inferred |
| illegal configurations | Verilator, Icarus | 10 / 10 rejected by the modules' own checks (incl. SECDED reserved) |
| RTL simulation | Icarus 12, Verilator 5.020 | `reports/regression.md`, `reports/system.md` |
| generic logic synthesis (`syn/run_synth.sh`): `synth -flatten`, `check -assert`, arrays as black boxes (`syn/sram_generic_1rw_blackbox.sv` = macros) | Yosys 0.33 | see §1a; 0 latches, `check -assert` clean in every configuration |
| technology mapping / place and route / timing / power | — | **not run**: no FPGA or ASIC area, frequency or power figure is claimed |

### 1a. Generic synthesis (Yosys internal cell library, not a technology; `reports/synth.md`, raw logs `reports/synth/`)

| Configuration | Generic cells | Flip-flops (approx.) | Array macros (black boxes) |
|---|---|---|---|
| no caches, no counters | 25 081 | ~2 050 | 10 (8 SRAM banks, 2 LMEM banks) |
| default without counters (`PERF_EN = 0`) | 62 755 | — | 12 (+ 2 D-cache ways) |
| **default** (D-cache, 43 counters) | **72 324** | ~6 900 | 12 |
| + I-cache | 94 125 | ~10 200 | 14 |

Reading: routing, the six-port bank controllers, the narrow-target muxes and MEMCTL cost about 25 k generic cells;
the 43 performance counters about 9.6 k; the D-cache about 37.7 k — dominated by its tag / valid / dirty arrays in
flip-flops with several independent read ports (lookup, victim selection, maintenance). Moving the tags into a 1RW
array read in the acceptance cycle (as the data arrays already are) is the first area optimisation to make; it is
not done here because it changes the maintenance engine's timing and would need the full regression again.

## 2. Implementation notes

* Every array is an SRAM-library wrapper: changing `BACKEND` / `*_MACRO` maps the shared SRAM, LMEM and the cache data
  arrays to FPGA block RAM or to the library's ASIC macro leaves without touching MemoryCore.
* Critical-path candidates (not measured): the zero-cycle routing chain requester → `sfmem_port` decode → bank
  arbiter → macro address, and the ready chain back. Cut with DataFabric `sfb_reg_slice` on the requester side (adds
  one cycle; legal because ports track their own outstanding count) or raise `SRAM_RD_LAT` for registered macro
  outputs. The cache's hit path is tag compare (flops) + way mux after a 1-cycle array read.
* Storage cost (default): shared SRAM 8 x 8192 x 36 bit, LMEM 2 x 4096 x 36 bit, D-cache 2 x 256 x 32 bit data +
  128 x 22-bit tags in flops, MEMCTL 43 x 32-bit counters (removable with `PERF_EN = 0`).

## 3. Known limitations

| Area | Limitation |
|---|---|
| Evidence | RTL simulation only. No FPGA board, no silicon, no timing closure, no power figure. |
| Coherence | none in hardware (by design): one noncoherent ControlCore cache; correctness rests on the software protocol |
| Harts / atomics | one ControlCore hart; no AMO / LR-SC; semaphores in MEMCTL only (docs/06) |
| ECC | byte parity (detect only); SECDED reserved for Project 26 (docs/07) |
| Cache | write hit not pipelined (2 cycles per store); one maintenance command at a time; range commands iterate one line per cycle (a 1 MiB range takes 64 k cycles — use ALL for large CLEAN / CLEAN_INVAL); I-cache commands asynchronous to the data port (poll BUSY) |
| Ordering | a requester's accesses to different targets complete in order but may be performed out of order; use a fence (wait for responses) between targets |
| Narrow targets | a requester that stops taking responses blocks any narrow target whose oldest response it owns (head-of-line); banked memories are not affected |
| Error log | first error captured, later ones counted; a write-back error loses the line's data (imprecise) |
| Scratchpad | VSPM ownership granule fixed at 8 partitions; engine-side accesses are policed by the tile, not by MemoryCore; no address translation |
| Integration | requesters with their own reset must gate their requests while in reset (docs/03 R2); memory must be initialized before reads with parity on (docs/07) |
| External memory | the testbench's EXT model has fixed latency (+ jitter, back-pressure); DRAM timing is not modelled at RTL level |
| Perf counters | 32-bit, wrapping; bank counters only for banks 0–7 |
| Test harnesses | the performance and BandwidthLab harnesses run on Verilator only; the Icarus system run is slow (minutes) |
