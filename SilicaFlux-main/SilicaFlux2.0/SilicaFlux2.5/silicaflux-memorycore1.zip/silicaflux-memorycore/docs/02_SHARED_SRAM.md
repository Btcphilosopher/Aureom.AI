# 02 — Shared SRAM (banked, one port per requester)

`rtl/sfmem_banked.sv` around the SRAM Wrapper Library's **unmodified** `sram_bank_controller` (Project 01).
The same wrapper builds LMEM (3 ports, 2 banks).

## 1. Ports, banks, macros

* **No macro has more than one port.** Each bank is a single-port (1RW) array (`sram_backend_1rw`: GENERIC inferred,
  FPGA block RAM, or ASIC macro leaves from the library's catalogue). Concurrency comes only from banking: up to
  `min(requesters, banks)` accesses per cycle — 6 at the default 8 banks.
* Every requester has its **own port** into the bank controller, so the SFB2 one-transaction-per-slave rule of the
  DataFabric crossbar (R6) does not apply: a DMA streaming bank 3 and the ControlCore reading bank 5 proceed in the
  same cycle, and each requester may have `RSP_DEPTH` (= read latency + 1) accesses in flight.
* Shape of the default SRAM: 8 banks x 8192 words x 36 bits (32 data + 4 parity), 256 KiB of data.

## 2. Bank mapping

Word interleave (`interleave: low` in the map): `bank = (addr >> 2) mod BANKS`, `row = (addr >> 2) / BANKS` (offset
inside the region). Unit-stride streams rotate through all banks; a stride of `BANKS` words hits one bank
(pathological, measured in docs/10 E2: 1 word / cycle for everyone). High (block) interleave is a map option
(`SRAM_ILV_HIGH`) for software that partitions memory per requester.

## 3. Read / write interface

| Item | Behaviour |
|---|---|
| request | SFB2, byte address (`SRAM_BASE + offset`), word aligned (misaligned → MISALIGNED at the router) |
| byte enables | `wstrb[3:0]` → library lane mask; any pattern including 0 (a no-op write that is still acknowledged) |
| write | performed at the acceptance edge; acknowledged `SRAM_RD_LAT` cycles later (`rsp_rdata = 0`) |
| read | data `SRAM_RD_LAT` cycles after acceptance unless the requester back-pressures (response FIFO, credits) |
| acceptance | in the cycle the bank grants the request (`req_ready` = grant); a request waits while its bank is busy or its requester has no response credit |
| ordering | per requester: strictly in acceptance order (library guarantee; every access takes exactly `RD_LAT`) |

## 4. Arbitration

Per bank, round robin (pointer moves past the winner on every grant): a requester holding a request is granted
within `requesters − 1` grants of that bank (library property, formally bounded-proven for 2x2 in Project 01;
measured here: E7 all four requesters on one bank receive exactly 1/4 of it, maximum wait 4 cycles). Fixed priority
(`SRAM_ARB = FIXED`, requester 0 highest) is available and starves under sustained contention (E7: the lowest
requester waited 4 501 cycles).

## 5. Errors and bounds

The router (`sfmem_port`) decodes the full 32-bit address against the map: only `[SRAM_BASE, SRAM_BASE + 256 KiB)`
reaches the SRAM, so the library's own out-of-range check never fires in a legal build (it is kept). The access
matrix lets every requester reach the SRAM. Parity failures on reads answer `rsp_error = 1`, `rdata = 0` (docs/07).

## 6. Configurable read latency

`SRAM_RD_LAT` = macro latency plus optional output registers (1 = macro registered once). Throughput per requester
stays at one access per cycle when `MAX_OUT ≥ SRAM_RD_LAT + 1` (default 4 covers latency ≤ 3; E3). The regression
runs latency 1, 2 and 3; the read-latency ≥ 2 configurations found a real ordering bug in the integrity path
(docs/09 §6).

## 7. Equivalence with the validated model

`scripts/bwlab_compare.py` runs MemoryLab's `bankbench` stimulus (6 requesters x 400 requests, workloads random /
cpu / vector / tensor / dma / mixed / stride) on MemoryLab's RTL-validated `BankController` model and on
`silicaflux_memory_subsystem`: identical acceptance cycle, response cycle, read data, error flag and bank-conflict
count for every transaction in all runs (`reports/bwlab_compare.md`). MemoryCore's routing adds no cycle and no
reordering, so MemoryLab / BandwidthLab bandwidth studies of this controller apply to MemoryCore unchanged.

## 8. MBIST

`sram_tst_*` / `lmem_tst_*` expose the library's test port (TestCore collar bus): `tst_active` hands all banks to the
test bus (functional `req_ready = 0`; accepted requests complete), banks tested in parallel with `tst_sel`, raw
36-bit words including the parity bits, read data at exactly `READ_LATENCY`. `tb/tb_sfmem_mbist.sv` drives the
library's `sram_mbist_march` (March C-, solid and checkerboard) through these ports: fault-free PASS on all 8 SRAM
and 2 LMEM banks, a functional request held off for the 655 k test cycles and performed after, injected SA0 (bank 3,
row 100, bit 5), transition fault on a parity bit (bank 6, last row) and an LMEM address-decoder fault each found at
the right bank and row. MBIST writes raw words, so the parity lanes it leaves are not odd: memory is scrubbed after
MBIST (initialization rule, docs/07).
