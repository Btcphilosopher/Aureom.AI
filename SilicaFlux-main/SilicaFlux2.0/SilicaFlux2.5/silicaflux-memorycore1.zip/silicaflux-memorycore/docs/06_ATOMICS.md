# 06 — Atomics: only where a concurrent software requirement exists

## 1. Requirement analysis

| Concurrent software pattern in this system | Needs an atomic RMW? |
|---|---|
| ControlCore ↔ engines (commands, completion records) | no — each engine's command / completion queues are single-producer / single-consumer register FIFOs |
| ControlCore ↔ DMA buffers | no — ownership hand-over with completion (docs/03 §5) |
| ControlCore main code ↔ its own interrupt handlers | no — one hart; mask interrupts around the critical section |
| **external host / debug agent (DBG port) ↔ ControlCore**, sharing buffers or a mailbox in the shared SRAM | **yes** — two independent instruction streams that must agree on who owns a resource (mutual exclusion); SPSC rings would suffice for streaming, but claiming a shared buffer pool does not |

Only the last pattern is genuine. It is served by **hardware semaphores**, not by memory atomics.

## 2. What is implemented: MEMCTL semaphores SEM0..SEM7

| Item | Definition |
|---|---|
| Operation | read of SEMn = atomic test-and-set: returns 0 and records the reader as holder if free; otherwise returns holder + 1 (requester index + 1) and changes nothing |
| Release | write 0 by the holder; a write by anyone else, a non-zero write or a sub-word write is refused (REG error, no effect) |
| Atomicity domain | the MEMCTL register page: all accesses to it pass through one slave port that accepts one access at a time, so test-and-sets are totally ordered |
| Alignment | 32-bit word access at `MEMCTL + 0x080 + 4n` |
| Ordering | a semaphore orders nothing by itself. Acquire, then access the protected data; complete the protected writes (`sfmem_fence()`) before the release. `sfmem_sem_lock / _unlock` do this |
| Requesters | DBG and CPUD (the only requesters that reach MMIO) |
| Verified | `semaphore`: per-step semantics, and a race where DBG and the ControlCore port each acquire SEM1 24 times, write their ID to a shared word, wait 1–5 cycles, read it back — the read must be their own ID (checked for every interleaving, with random stalls); mutant R1 (read does not acquire) is killed |

## 3. What is not implemented, and why

* **No atomic memory operations (AMO add / swap / CAS) on SRAM or EXT.** No requester issues them: the ControlCore
  is RV32I without the A extension, and the engines' DMA engines have no atomic transaction type. Implementing them
  would need a new SFB2 transaction type, a read-modify-write in the bank (two accesses, a lock on the bank, a hazard
  against the other five ports) and a new memory-model clause — with no consumer.
* **No LR/SC reservation** — same reason (no A extension).
* **No multi-word atomicity.** Single-copy atomicity is one aligned 32-bit word (docs/03 C1).

If a second hart or an A-extension ControlCore is added: implement AMOs in `sfmem_banked` as a bank-locking
read-modify-write (the bank controller's arbiter already serialises per bank, which is the atomicity domain such an
AMO needs), add the `amo` field to SFB2 per its additive-extension rule, and extend docs/03 with a per-location AMO
clause and litmus tests.
