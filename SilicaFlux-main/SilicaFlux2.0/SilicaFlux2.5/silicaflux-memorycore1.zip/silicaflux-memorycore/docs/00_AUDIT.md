# 00 — Repository audit

Source: `btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (and `SilicaFlux2.0/SilicaFlux2.5/`), the project
archives listed below, unpacked and inspected file by file. Every reused file is copied **byte-identical** into
`third_party/` (`third_party/SHA256SUMS`, `third_party/PROVENANCE.md`).

## 1. Which memories actually exist

No SilicaFlux silicon exists, and no physical memory has been fabricated or placed. "Physical" below means a
foundry / open-PDK macro that a wrapper can instantiate; "inferred" means an RTL array that a simulator or a
synthesis tool turns into flip-flops or FPGA block RAM.

| Memory | Where | Kind | Status |
|---|---|---|---|
| SRAM Wrapper Library cores `sram_sp`, `sram_1r1w`, `sram_tdp`, `sram_bank_controller`, raw `sram_backend_{1rw,1r1w,2rw}` | Project 01 `silicaflux-sramlib.zip` | **inferred** (GENERIC: `logic mem[]`), FPGA block RAM (inferred), **physical** only through the ASIC leaves | verified (simulation, formal on the bank controller, MemoryLab cross-check) |
| ASIC macro leaves: SKY130 OpenRAM (`sky130_sram_1kbyte_1rw1r_32x256_8`, ...), GF180MCU (`gf180mcu_fd_ip_sram__sram64x8m8wm1` ... `512x8`), IHP SG13G2 (`RM_IHPSG13_1P_*`, `RM_IHPSG13_2P_*`) | Project 01 `manifests/`, `backends/asic/` | **physical** open-PDK macros (behavioural models / black boxes) | 31 manifests; 3 commercial entries are placeholders and are rejected at elaboration |
| HPC Module 04 banked scratchpad (64 KiB default, 4 banks, 1RW/1R1W/2RW, byte parity) | `silicaflux-hpc-m04-scratchpad.zip` | inferred via the SRAM library | verified; inside the HPC tile (Module 08) |
| TensorCore operand buffers TC03 (A/B ping-pong, 2 KiB default), accumulator TC04, output buffer TC07 | `silicaflux-tensorcore0{3,4,7}.zip`, integrated in TC08 | inferred (generic storage; TC08 maps them to ECP5 DP16KD on FPGA) | verified inside `silicaflux_tensor_unit` |
| SilicaFlux-V SoC memories: 4 x 32 KiB SRAM banks (`sfv_sram_sp`), 4 KiB boot ROM, tile scratchpad TSPM 16 KiB | `silicaflux-v-release1.zip` | inferred; `asic/tech/*/sfv_sram_macro_bank.sv` maps to SKY130 / IHP macros | verified (release 1) |
| MCU-I SRAM (64 / 128 KiB, byte parity in the industrial build) | `silicaflux-mcu-i.zip` | inferred via the SRAM library | verified |
| DataFabric SFB2 SRAM slaves `sfb_sram_slave`, `sfb_sram_1r1w_slave`; DMA FIFOs (`dma_fifo`, flops) | `silicaflux-datafabric.zip` | inferred | verified |
| Generic caches `direct_mapped_cache`, `set_assoc_cache`, `memory_controller` (DRAM-style FSM) | `memory_cache_repo.zip` | inferred | **not usable** — see §3 |
| SilicaFlux 2.5 `memory_controller.sf`, `register_bank.sf` | `SilicaFlux2.5/*.sf` | inferred | earlier generation; superseded by the SRAM library (its integration patch lives in Project 01) |

## 2. Reuse matrix

| Needed by MemoryCore | Existing block | Decision |
|---|---|---|
| shared-SRAM banking, arbitration, byte lanes, read latency, credits, MBIST port | SRAM Wrapper Library `sram_bank_controller` | **reused unmodified** (also for LMEM) |
| cache data arrays | `sram_backend_1rw` | **reused unmodified** (one 1RW array per way) |
| bus protocol | DataFabric SFB2 (`docs/datafabric/PROTOCOL.md`) | adopted: every MemoryCore port is SFB2 |
| protocol checking in tests | DataFabric `sfb_protocol_checker` | reused unmodified (testbenches) |
| integrity layout | HPC Module 04 / MCU-I odd byte parity, 9-bit lanes, SECDED reserved | adopted unchanged (docs/07) |
| ControlCore | no "ControlCore" project exists in the repository; SilicaFlux-V `sfv_cpu` (RV32I, 2-stage, blocking loads / stores, FENCE = NOP, no caches) is the control processor of every SilicaFlux SoC | used as the ControlCore, unmodified |
| system DMA | DataFabric `silicaflux_dma` | reused unmodified (system test) |
| vector engine + scratchpad + its DMA | HPC Module 08 `silicaflux_hpc_tile` (via TC08's vendored tree) | reused unmodified (system test) |
| TensorCore | TENSORCORE 08 `silicaflux_tensor_unit` | reused unmodified (system test) |
| register bus | SilicaFlux-V `sfv_periph_bridge` + DataFabric `sfb_v1_slave_adapter` | reused unmodified (system test) |
| MBIST | SRAM library `sram_mbist_march` (TestCore collar bus) | reused unmodified (`tb_sfmem_mbist`) |
| memory / bandwidth simulators | MemoryLab (Project 02, inside BandwidthLab Project 10) | reused unmodified (`bwlab_compare`) |
| device drivers | TC08 `tsu_driver.c`, HPC Module 08 `silicaflux_hpc.c` | reused unmodified (firmware) |
| address-map generator | DataFabric `memmap_gen.py` (YAML → SV/C/Py/MD) | pattern adopted; new generator for the new map (`scripts/memmap_gen.py`) |

## 3. Why the existing cache library is not used

`memory_cache_repo/rtl/set_assoc_cache.sv` (write-back, LRU / PLRU) and `direct_mapped_cache.sv`:
* fail to compile: Icarus 12 `set_assoc_cache.sv:358: syntax error` (concurrent assertions); Verilator 5.020
  `%Error-BLKLOOPINIT` (delayed assignments to arrays in loops);
* no byte enables on stores (`cpu_we` writes whole words) — the ControlCore issues byte and half-word stores;
* no clean / invalidate / flush interface — the entire noncoherent visibility protocol depends on it;
* a req / ack interface that is not SFB2, no error responses, no cacheability control.
A new cache (`rtl/sfmem_cache.sv`) was therefore justified; its data arrays reuse the SRAM library.

## 4. What the repository did NOT have (and MemoryCore adds)

* a unified address map covering ControlCore local memory, shared SRAM, scratchpad window, external memory and MMIO
  (the DataFabric / HPC maps had 4 x 32 KiB SRAM slaves on one crossbar port each, one transaction at a time);
* a multi-ported (banked) shared SRAM reachable by every requester in parallel (the DataFabric crossbar serialises
  each slave port to one transaction);
* any cache, any cache-maintenance operation, any non-cacheable window, any statement of a DMA visibility protocol
  (TC08 `docs/06` states the need: "a CPU with a data cache would have to clean A / B before the doorbell and
  invalidate C" — the SilicaFlux-V SoC had none);
* hardware enforcement of scratchpad ownership on the host window (HPC Module 08 `docs/04` §5.3 states the rule as
  software-only);
* a memory reference model of the address space with caches, and a consistency test bench.

## 5. Tools

Ubuntu 24.04 packages: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, GNU RISC-V GCC 13.2 (rv32i / ilp32 multilib),
Python 3.13 with PyYAML and numpy — the same tool versions as Projects 01–10 and TENSORCORE 08–10.
