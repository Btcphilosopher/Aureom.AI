# 04 — ControlCore cache: design, maintenance, and the measured case

## 1. Decision (from measurements, docs/10)

The brief: start with shared SRAM and software-managed scratchpads; add caching only when the correctness and
performance case is established. The measurements decided **where** caching pays:

| Case | Uncached | Cached | Decision |
|---|---|---|---|
| ControlCore loads from **external memory** (latency 20), 1 KiB working set | 20.0 cycles / load | 1.42 (98.4 % hits) | **cache** (14x) |
| same, latency 40 | 40.0 | 1.74 | **cache** (23x) |
| same, 8 KiB sequential working set (4x the cache) | 20.0 / 40.0 | 7.5 / 12.5 (75 % hits: spatial locality) | **cache** (2.7x / 3.2x) |
| ControlCore loads from the **shared SRAM**, random, 0–4 DMA streams | 1.00 – 1.21 | 1.15 – 1.17 (1 KiB WS) | marginal at best (1.21 → 1.17 only with 4 DMA streams; slower without load): banking already gives ~1 cycle |
| same, 8 KiB random working set | 1.00 – 1.21 | **6.2 – 6.8** (26 % hits) | caching SRAM is **harmful** here |
| instruction fetch from EXT (execute in place) | 20.0 | 1.42 | cache **if** code lives in EXT |
| instruction fetch from LMEM (where ControlCore code lives) | 1.0 | — (LMEM is never cached) | no I-cache needed |

Resulting defaults:
* D-cache **present** (`DCACHE_EN = 1`), **disabled at reset**, write-back; when enabled it caches only the regions
  in `CACHE_REGIONS`, which resets to **EXT only**. Caching the shared SRAM is an explicit software opt-in (the
  system demo opts in to exercise the protocol; random-access firmware should not).
* I-cache **absent** (`ICACHE_EN = 0`): the ControlCore executes from LMEM; enable the parameter only for
  execute-in-place from EXT. It is verified anyway (regression configurations, E5).
* No coherence protocol: there is one cached agent, and a snooping MESI/MOESI controller for one hart and
  noncoherent DMA engines would add verification risk without a measured benefit.

## 2. Geometry and policies

| Item | Default | Options |
|---|---|---|
| line | 16 B (4 words) | 8 – 64 B, power of two |
| sets / ways | 64 / 2 (2 KiB) | sets ≥ 2 pow2; ways 1, 2, 4, 8 |
| replacement | first invalid way, else tree pseudo-LRU (`WAYS − 1` bits per set; updated on every hit and fill) | — |
| write policy | write-back, write-allocate | write-through, no-write-allocate (`DCACHE_WB = 0`) |
| storage | tags, valid, dirty, PLRU in flops (valid / dirty / PLRU reset); data in one `sram_backend_1rw` per way | any SRAM-library backend |
| hit latency | 1 cycle; read hits pipelined 1 / cycle | — |
| miss | write back the dirty victim (read `LINE/4` words, then `LINE/4` acknowledged writes), refill `LINE/4` words pipelined (`MAX_OUT` in flight), install, respond | refill error → precise error, line not installed |
| uncached | combinational pass-through, up to `MAX_OUT` in flight, 0 added cycles | LMEM, MMIO, VSPM, misaligned, NC windows, regions off |

## 3. Cacheability regions

Cached iff all of: CACHE_CTRL enable for this cache; region marked `cacheable` in the map (SRAM, EXT); its bit set
in **CACHE_REGIONS** (reset = the map's `cache_default` regions = EXT); requester may reach the region; address word
aligned; not inside an enabled **non-cacheable window** (NCW0 / NCW1: `[BASE, LIMIT)`, for mailboxes and descriptors).
Only cacheable regions' bits are writable in CACHE_REGIONS (mutant R4 proves the test).

## 4. Maintenance engine

| Command (CMO_CMD) | Effect per line in scope |
|---|---|
| CLEAN (1) | if dirty: write back (counts DC_WB), keep valid and clean |
| INVAL (2) | drop; a dirty line's data is discarded and CMO_STATUS.DIRTY_DISCARD is set |
| CLEAN_INVAL (3) | write back if dirty, then drop |

Scope: `ALL` (every set and way) or RANGE `[CMO_ADDR, CMO_ADDR + CMO_SIZE)` — every line touched, any alignment,
size 0 = nothing, a range wrapping past 2^32 is clamped. Iteration: one candidate per cycle, write-backs through the
eviction path. The engine starts only when nothing is in flight, and while a command is pending the D-cache accepts
no new access: the command is ordered after all earlier and before all later ControlCore data accesses (docs/03 K5).
CMO_STATUS: BUSY, DONE, WB_ERR, DIRTY_DISCARD, number of lines operated on (both caches). A command naming an absent
cache completes at once; a command written while BUSY, with OP = 0, no cache selected or reserved bits set is refused.

## 5. Interaction with DMA — summary

Noncoherent; see docs/03 §5 for the protocol and the API. The hazards, all demonstrated in the tests:
stale CPU line after a device write (needs INVAL), device reads stale memory while the CPU holds dirty data (needs
CLEAN), a dirty line evicted over device data (needs CLEAN_INVAL before hand-over), a shared line between a CPU
variable and a receive buffer (needs line-aligned buffers).

## 6. Verification

`cache`, `cmo`, `visibility`, `wberr`, `parity`, `random`, `reset` scenarios on eight cache geometries / policies
(direct-mapped 32 B lines, 2-way 16 B, 4-way 8 B, 8-way 64 B, write-back and write-through); exact prediction of
every read value, hit / miss / write-back counter and maintenance line count by the reference model; ten cache
mutants killed (docs/09).
