# 01 — Architecture and memory hierarchy

## 1. Hierarchy plan

All capacities and address ranges come from `memmap/memorycore.yaml` (generated: `docs/MEMORY_MAP.md`,
`generated/sfmem_map_{pkg.sv,.h,.py}`); bank counts and latencies are RTL parameters checked against it.

| Level | Storage | Capacity (default) | Address range | Reached by | Managed by |
|---|---|---|---|---|---|
| ControlCore local memory **LMEM** | 2 x 1RW banks, word-interleaved, byte parity | 32 KiB | `0x0800_0000`–`0x0800_7FFF` | DBG, CPUI, CPUD only (DMA engines denied) | ControlCore (code, stack, private data); never cached (1-cycle already) |
| ControlCore **D-cache** (optional, present) | 2-way, 64 sets, 16 B lines, write-back + write-allocate (or write-through), tree PLRU; tags in flops, data in 1RW arrays | 2 KiB | caches EXT (default) and optionally SRAM | CPUD | hardware fills; **software** maintenance (docs/03 §4) |
| ControlCore **I-cache** (optional, absent by default) | same module, read-only use | 2 KiB | EXT / SRAM code | CPUI | software invalidation |
| **Shared SRAM** | 8 x 1RW banks, word-interleaved, one port per requester, byte parity | 256 KiB | `0x1000_0000`–`0x1003_FFFF` | all six requesters | software partitions buffers; ownership protocol |
| **Vector scratchpad** (HPC Module 04, inside the tile) | 4 banks, engine-private ports + host window | 64 KiB | host window `0x6000_0000`–`0x6000_FFFF` | engine (LSU, tile DMA) internally; DBG, CPUD, SDMA through the window | explicitly managed; VSPM_OWN ownership in 8 x 8 KiB partitions |
| **Tensor operand / accumulator / output buffers** (TC03 / TC04 / TC07) | inside the TensorCore | 2 x 2 KiB A/B + C tile | **not host-addressable** | TensorCore DMA / array only | TensorCore command sequencer |
| **External memory** window | off-chip DRAM / HBM controller on `ext_*` | 256 MiB window | `0x8000_0000`–`0x8FFF_FFFF` | all six requesters | cached by the ControlCore (default region) |
| **MMIO** | register pages (32 x 4 KiB); MEMCTL (page 10) inside MemoryCore | 128 KiB | `0x4000_0000`–`0x4001_FFFF` | DBG, CPUD only | never cached, never executable |

Everything else is unmapped (bus error, cause UNMAPPED). Legacy SilicaFlux addresses are kept: SRAM base
`0x1000_0000`, PERIPH `0x4000_0000` with DMA page 6 / HPC page 8 / TSU page 9, HPC scratchpad window
`0x6000_0000` (checked by `memmap_gen.py --check-legacy` against the HPC SoC map).

## 2. Block diagram

```
 requesters (SFB2)              per-requester router              targets
                                (sfmem_port: decode, access
 m0 DBG  ─────────────────────► matrix, alignment, VSPM      ┌──► sfmem_banked LMEM  (sram_bank_controller 3 x 2)
 m1 CPUI ──► [sfmem_cache I] ─► ownership, MAX_OUT ordering ├──► sfmem_banked SRAM  (sram_bank_controller 6 x 8)
 m2 CPUD ──► [sfmem_cache D] ─► FIFO, local error responder) ├──► sfmem_tgt_mux EXT  ──► ext_*  (external memory)
 m3 SDMA ─────────────────────►                              ├──► sfmem_tgt_mux VSPM ──► vs_*   (tile host window)
 m4 VDMA ─────────────────────►    one port per requester    ├──► sfmem_tgt_mux MMIO ──► io_*   (register pages)
 m5 TDMA ─────────────────────►    into each banked memory   └──► sfmem_tgt_mux REGS ──► sfmem_regs (MEMCTL page 10)
                                                                    │ cache control / CMO, CACHE_REGIONS, NC windows,
                                                                    │ error log, parity control, VSPM_OWN, semaphores,
                                                                    │ 43 performance counters, irq
```

| File | Lines of responsibility |
|---|---|
| `rtl/silicaflux_memory_subsystem.sv` | top level: instances, wiring, error-event and counter collection, INFO values |
| `rtl/sfmem_port.sv` | decode (priority MISALIGNED > UNMAPPED > DENIED > OWNERSHIP), routing, in-order responses |
| `rtl/sfmem_banked.sv` | SFB2 view of `sram_bank_controller`; parity encode / decode / injection; events |
| `rtl/sfmem_tgt_mux.sv` | round-robin with grant lock, owner FIFO (DEPTH outstanding), target-error events |
| `rtl/sfmem_cache.sv` | I / D cache, maintenance engine |
| `rtl/sfmem_regs.sv` | MEMCTL register page |
| `rtl/sfmem_defs.svh`, `generated/sfmem_map_pkg.sv` | macros; map constants (`sfmem_map_pkg::NAME`, no imports) |

## 3. Parameters (`silicaflux_memory_subsystem`)

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `SRAM_BANKS` | 8 (map) | power of two | shared-SRAM banks |
| `SRAM_RD_LAT` | 1 | ≥ 1 | SRAM read latency (macro + optional output registers) |
| `SRAM_RSP_DEPTH` | `SRAM_RD_LAT + 1` | ≥ 1 | response credits per requester (sustains 1 access / cycle) |
| `SRAM_ARB` | round robin | RR / FIXED | per-bank arbitration |
| `SRAM_ILV_HIGH` | 0 (map: low) | 0 / 1 | word or block interleave |
| `LMEM_BANKS`, `LMEM_RD_LAT` | 2 (map), 1 | | ControlCore local memory |
| `ECC_MODE` | 1 (byte parity) | 0 none, 1 parity; 2 SECDED **rejected** (reserved, Project 26) | integrity of SRAM and LMEM |
| `DCACHE_EN`, `ICACHE_EN` | 1, 0 | 0 / 1 | caches present (both disabled at reset) |
| `DCACHE_WB` | 1 | 0 / 1 | write-back + write-allocate, or write-through + no-write-allocate |
| `CACHE_LINE`, `CACHE_SETS`, `CACHE_WAYS` | 16, 64, 2 | ≥ 8 pow2, ≥ 2 pow2, 1/2/4/8 | cache geometry (I and D) |
| `MAX_OUT` | 4 | ≥ 1 | outstanding transactions per requester port (and per cache downstream) |
| `EXT_DEPTH`, `VSPM_DEPTH`, `MMIO_DEPTH` | 4, 2, 1 | ≥ 1 | outstanding transactions per narrow target |
| `BACKEND`, `*_MACRO` | GENERIC | SRAM library | technology mapping of every array |
| `PERF_EN` | 1 | 0 / 1 | performance counters |

Illegal combinations fail elaboration in Verilator, Icarus and Yosys (`reports/lint.md`: 10 / 10 rejected).

## 4. Interfaces

* `m_*` — six SFB2 requester ports (flattened, requester m at slice m): `req_valid/ready/write/addr/wdata/wstrb`,
  `rsp_valid/ready/rdata/error`. 32-bit data, byte addresses, word aligned (SFB2 R9).
* `ext_*`, `vs_*`, `io_*` — SFB2 master ports to external memory, the tile's host scratchpad window and the
  register bus (full byte addresses; responses in order; any latency ≥ 1).
* `sram_tst_*`, `lmem_tst_*` — the SRAM library's MBIST test ports (TestCore collar bus): 36-bit stored words with
  parity, bank select, raw read data at `READ_LATENCY`.
* `irq` — `|(IRQ_STATUS & IRQ_ENABLE)` (error, parity, CMO done, write-back error).
* `busy` — something in flight (for clock gating / quiesce).

## 5. Timing (cycles, from acceptance)

| Access | Latency | Throughput per requester |
|---|---|---|
| SRAM / LMEM read or write, no conflict | `SRAM_RD_LAT` (1) | 1 / cycle with `MAX_OUT ≥ RD_LAT + 1` (E3) |
| bank conflict | + 1 per losing round (≤ requesters − 1 rounds, round robin) | — |
| uncached through a cache (bypass) | + 0 | as above |
| D-cache read hit | 1 | 1 / cycle (accept-while-retiring) |
| D-cache write hit (write-back) | 1 | 1 per 2 cycles |
| D-cache miss, clean victim | lookup + `LINE/4`-word pipelined refill + install: 8 cycles measured for a 16 B line from idle SRAM (docs/10 E4) | — |
| EXT / VSPM / MMIO | target latency + 0 | `DEPTH` in flight per target |
| decode error | 1 | 1 / cycle |

Combinational paths: requester `req_*` → target `req_*`, target `ready` → requester `ready` (zero-cycle routing); no
path from `rsp_ready` to `req_ready`. Insert DataFabric `sfb_reg_slice` on long wires to macros (docs/11).
