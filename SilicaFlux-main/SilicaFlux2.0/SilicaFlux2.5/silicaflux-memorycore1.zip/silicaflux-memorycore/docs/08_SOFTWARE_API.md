# 08 — Cache-maintenance and synchronisation API (firmware)

`sw/include/sfmem.h`, `sw/sfmem.c` — bare-metal C for the ControlCore (RV32I, no libc). Addresses and register
offsets come from `generated/sfmem_map.h` (from the YAML map). Built warning-free with `-Wall -Wextra -Werror`
(GCC 13.2, `rv32i_zicsr_zifencei`, ilp32) and executed on the RTL by the system test.

## Functions

| Function | Does | Notes |
|---|---|---|
| `sfmem_init(&info)` | checks MEMCTL ID and map version, reads geometry (line, sets, ways, write policy, parity) | `SFMEM_EABI` on mismatch |
| `sfmem_scrub(base, len)` | full-word zero writes + fence | parity initialization rule; call before enabling the D-cache on the range |
| `sfmem_cache_regions(mask)` | select cached regions (`SFMEM_REGION_EXT`, `SFMEM_REGION_SRAM`) | cleans + invalidates first when a region is removed; returns the effective mask (only cacheable regions stick) |
| `sfmem_cache_enable(d, i)` | enable / disable D / I caches | invalidates on enable (no lines from an earlier epoch), CLEAN_INVAL on disable |
| `sfmem_fence()` | `fence rw,rw` + an uncached MEMCTL read | every earlier uncached / write-through store has completed; does **not** flush a write-back cache |
| `sfmem_cmo_range(op, sel, addr, len)`, `sfmem_cmo_all(op, sel)` | issue a maintenance command and wait for !BUSY | returns `SFMEM_EIO` (write-back refused), `SFMEM_EDISCARD` (INVAL dropped dirty data) |
| `sfmem_dcache_clean / _inval / _clean_inval(addr, len)`, `sfmem_icache_inval` | wrappers | |
| `sfmem_sync_icache(code, len)` | D CLEAN + I INVAL + `fence.i` | code written by the CPU or a DMA becomes executable |
| `sfmem_dma_to_device(buf, len)` | CLEAN | before a device reads `buf` |
| `sfmem_dma_from_device_begin(buf, len)` | CLEAN_INVAL; requires line-aligned `buf` and `len` (`SFMEM_EALIGN`) | before a device writes `buf` |
| `sfmem_dma_from_device_end(buf, len)` | INVAL; line-aligned | after the device's completion record |
| `sfmem_dma_bidir_begin` | = `_from_device_begin` | |
| `sfmem_set_noncacheable(w, base, limit)` | CLEAN_INVAL the range, program NCW w | `limit = 0` disables the window |
| `sfmem_vspm_give(parts)`, `sfmem_vspm_take(parts)`, `sfmem_vspm_owner_mask()` | VSPM partition ownership | `give` fences first |
| `sfmem_sem_try / _lock / _unlock(i)` | hardware semaphores | `unlock` fences first |
| `sfmem_err_read / _clear`, `sfmem_perf(i)`, `sfmem_perf_clear()`, `sfmem_perf_freeze(on)` | diagnostics | |

`SFMEM_DMA_ALIGN` (64) is a static alignment that satisfies every legal line size.

## Typical sequences (from `integration/firmware/main.c`, executed on the RTL)

```c
sfmem_init(&inf);
sfmem_scrub((void *)SFMEM_SRAM_BASE, 0x8000);                   /* boot: parity initialization */
sfmem_cache_regions(SFMEM_REGION_SRAM | SFMEM_REGION_EXT);      /* opt in to SRAM caching (default: EXT only) */
sfmem_cache_enable(1, 1);

/* CPU -> TensorCore -> CPU */
fill(A); fill(B);                                                /* cached stores */
sfmem_dma_to_device(A, 64);  sfmem_dma_to_device(B, 64);
sfmem_dma_from_device_begin(C, 256);                             /* C line-aligned */
tensor_gemm(&dev, A, B, C, 8, 8, 8, &opts, &rec);                /* TC08 driver: submit + wait for the record */
sfmem_dma_from_device_end(C, 256);
check(C);

/* vector scratchpad through the host window */
fill_window(X, Y);                                               /* uncached window writes */
sfmem_vspm_give(1u << 1);                                        /* host accesses to partition 1 now fault */
hpc_submit(HPC, &vec_imul);  hpc_wait(HPC, &cpl, budget);
sfmem_vspm_take(1u << 1);
check_window(Z);
```

## Cost (measured on the RTL, default build)

A RANGE command issues at most four MMIO accesses (ADDR, SIZE, CMD, STATUS) and the engine visits one line per cycle
plus `2 x LINE/4 + few` cycles per dirty line written back. The system demo prints the CMO_LINES, DC_WB and hit /
miss counters of its run (`reports/system.md`); the complete T1–T6 sequence, console output included, takes about
0.3 M cycles.
