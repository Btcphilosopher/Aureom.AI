# 05 — Scratchpads: explicitly managed storage

Scratchpads stay private to their engines and are managed by software and the engines' command streams — never by
a cache. MemoryCore's role is the address map, the host window and its isolation.

| Property | Vector scratchpad (HPC Module 04 in the tile) | Tensor operand / accumulator / output buffers (TC03 / TC04 / TC07) |
|---|---|---|
| Capacity | 64 KiB, 4 banks | 2 x 2 KiB A/B ping-pong + accumulator tile + output tile (TC08 defaults) |
| Host-addressable | **yes**, through the VSPM window `0x6000_0000` (MemoryCore `vs_*` → tile `hs_*`), word access, any byte enables | **no** — not in the map; a TensorCore command naming any other address than the shared SRAM is rejected by the unit (RANGE) |
| Who may use the host window | DBG, CPUD, SDMA (access matrix); CPUI denied (execute-never), VDMA denied (it reaches the scratchpad internally), TDMA denied (isolation) | — |
| DMA loading | tile DMA (Module 05) between the scratchpad and any external address (shared SRAM, EXT), or the system DMA through the host window | TensorCore DMA (TC07) from the shared SRAM, block by block |
| Compute ownership | the tile's command stream; KERNEL = DMA in, compute, DMA out | the TensorCore command sequencer (TC03 ownership states) |
| Result write-back | tile DMA to external memory, completion after all writes acknowledged | TC07 DMA to the shared SRAM, completion after all writes acknowledged |
| Address translation | none: the tile is instantiated with `SPM_BASE = VSPM_BASE`, so engine and host use identical addresses | none: the TensorCore takes physical shared-SRAM addresses |
| Isolation | **VSPM_OWN** (MEMCTL): 8 partitions of 8 KiB; an engine-owned partition refuses every host-window access (OWNERSHIP error, no side effect); plus the access matrix | structural |

## Ownership protocol (vector scratchpad)

1. Host phase: the CPU (or a DMA) fills a partition through the window; `sfmem_vspm_give(parts)` fences (all window
   writes acknowledged), then sets the VSPM_OWN bits.
2. Engine phase: commands operate on the partition (VEC, KERNEL staging); host accesses to it fail immediately — on
   the ControlCore as a precise load / store access fault (system test T4: `mcause = 5`, `mtval` = the address,
   MEMCTL ERR_INFO = OWNERSHIP).
3. After the completion record: `sfmem_vspm_take(parts)`; the host reads results through the window.

The window is never cached (map: `kind: window`), so no maintenance applies. Host accesses are not ordered with
engine commands by hardware (HPC Module 08 docs/04 §5.3); VSPM_OWN turns a violation from silent corruption into a
precise error. The tile's own command checks (OVERLAP, SPM_RANGE) remain the engine-side protection.

## Why no translation

Engines and host share one physical address space with no aliasing; buffers are allocated by firmware at known
addresses. Translation (an IOMMU-like unit) would only be needed for virtualised or untrusted command sources, which
the ControlCore-driven system does not have. Recorded as a limitation, not a gap in the contract.
