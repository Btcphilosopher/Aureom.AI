# MemoryCore unified address map

Generated from `memmap/memorycore.yaml` by `scripts/memmap_gen.py` -- edit the YAML, not this file. Map version 1. Little-endian, 32-bit byte addresses, 32-bit data. Addresses in no region are **unmapped** and answer a bus error (cause UNMAPPED); nothing is aliased.

## Regions

| # | Region | Base | Size | End | Kind | Banks / interleave | Cacheable (ControlCore) | Note |
|---|---|---|---|---|---|---|---|---|
| 0 | LMEM | `0x08000000` | 32 KiB | `0x08007FFF` | memory | 2 / low | no | ControlCore local memory (code + data, TCM-like).  2 x 1RW banks, word-interleaved; ports: DBG, CPUI, CPUD. |
| 1 | SRAM | `0x10000000` | 256 KiB | `0x1003FFFF` | memory | 8 / low | opt-in (CACHE_REGIONS) | Shared on-chip SRAM.  8 x 1RW banks, word-interleaved; one port per requester (6), per-bank round robin. |
| 2 | MMIO | `0x40000000` | 128 KiB | `0x4001FFFF` | window | - | no | Register pages.  Page MEMCTL is served inside MemoryCore, every other page leaves on the io_* port. |
| 3 | VSPM | `0x60000000` | 64 KiB | `0x6000FFFF` | window | 8 ownership partitions | no | Vector-engine scratchpad host window (HPC Module 04 via the tile's hs_* port).  Explicitly managed, never cached. |
| 4 | EXT | `0x80000000` | 256 MiB | `0x8FFFFFFF` | memory | - | yes (cached after reset) | External-memory window (DRAM / HBM controller on the ext_* port; not part of MemoryCore). |

## Access matrix (requester x region)

| Requester | Index | LMEM | SRAM | MMIO | VSPM | EXT | Note |
|---|---|---|---|---|---|---|---|
| DBG | 0 | rw | rw | rw | rw | rw | debug / external-host loader (JTAG system-bus style).  Never cached. |
| CPUI | 1 | x (fetch) | x (fetch) | DENIED | DENIED | x (fetch) | ControlCore instruction port (SilicaFlux-V sfv_cpu i_*).  Execute-never device windows. |
| CPUD | 2 | rw | rw | rw | rw | rw | ControlCore data port (sfv_cpu d_*). |
| SDMA | 3 | DENIED | rw | DENIED | rw | rw | system DMA (DataFabric silicaflux_dma).  ControlCore-private LMEM and MMIO side effects are out of reach. |
| VDMA | 4 | DENIED | rw | DENIED | DENIED | rw | vector engine DMA (HPC Module 08 tile fab_*).  Reaches its own scratchpad internally, never through MemoryCore. |
| TDMA | 5 | DENIED | rw | DENIED | DENIED | rw | TensorCore DMA (TENSORCORE 08 m_*).  Isolated from the vector scratchpad. |

## Register pages inside MMIO

| Page | Index | Base | Served by | Owner |
|---|---|---|---|---|
| DMA | 6 | `0x40006000` | io_* port | DataFabric silicaflux_dma (system DMA) |
| HPC | 8 | `0x40008000` | io_* port | HPC Module 08 silicaflux_hpc_tile (vector engine) |
| TSU | 9 | `0x40009000` | io_* port | TENSORCORE 08 silicaflux_tensor_unit |
| MEMCTL | 10 | `0x4000A000` | MemoryCore (internal) | MemoryCore (this design) |

Pages not listed are forwarded to the `io_*` port, whose register bus answers unmapped pages with an error.

## Memories that are not host-addressable

| Memory | Owner | Size | Reachable by |
|---|---|---|---|
| TOB | TENSORCORE 03 tensor_operand_buffer (inside TSU) | 2 x 2 KiB A/B ping-pong (TC08 default OPERAND_BUFFER_BYTES) | TSU DMA fill port and systolic-array read port only |
| TACC | TENSORCORE 04 accumulator (inside TSU) | ARRAY_ROWS x ARRAY_COLS x INT32 per tile | array output and TC05/TC07 drain only |
| TOUT | TENSORCORE 07 tensor_output_buffer (inside TSU) | one C tile | TSU DMA drain only |
| VSPM_ENGINE_PORTS | HPC Module 04 scratchpad LSU / DMA ports (inside the tile) | same array as VSPM | vector LSU and tile DMA; MemoryCore sees only the host window |

## Error causes (`ERR_INFO.CAUSE`)

| Code | Name | Meaning |
|---|---|---|
| 0 | NONE |  |
| 1 | UNMAPPED | address in no region (or a reserved MMIO page) |
| 2 | DENIED | access matrix: this master may not reach this region |
| 3 | MISALIGNED | address not 4-byte aligned (SFB2 R9) |
| 4 | OWNERSHIP | host access to a VSPM partition owned by the engine |
| 5 | PARITY | byte-parity error on an SRAM / LMEM read |
| 6 | TARGET | a downstream port (EXT / VSPM / MMIO) answered with an error |
| 7 | WRITEBACK | a cache line write-back was refused (imprecise; data of that line lost) |
| 8 | REG | MEMCTL refused the access (sub-word, read-only, busy, not owner) |

## MEMCTL register block (page 10, `0x4000A000`)

All registers are 32-bit, word access only (a sub-word write answers a REG error and has no effect).

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | ID | ro | `0x53464D43` | Identification 'SFMC'. |
| `0x004` | INFO | ro | - | [7:0] MAP_VERSION; [11:8] log2 SRAM banks; [15:12] SRAM read latency; [16] ICACHE present; [17] DCACHE present; [18] DCACHE write-back; [20:19] ECC_MODE (0 none, 1 byte parity); [23:21] log2 LMEM banks; [31:24] number of requesters |
| `0x008` | CACHE_INFO | ro | - | [3:0] log2 LINE_BYTES; [11:4] log2 SETS; [15:12] WAYS; [16] write-back; [17] write-allocate |
| `0x00C` | SRAM_SIZE | ro | - | Shared SRAM bytes. |
| `0x010` | CACHE_CTRL | rw | `0x0` | [0] DEN: D-cache enable; [1] IEN: I-cache enable.  Disabled at reset: every access bypasses.  Disable only after CLEAN_INVAL ALL. |
| `0x014` | CMO_ADDR | rw | `0x0` | Start byte address of a RANGE maintenance operation. |
| `0x034` | CACHE_REGIONS | rw | `0x10` | [r] = 1: region r (map index) is cached by the ControlCore caches when they are enabled.  Only bits of regions marked cacheable in the map are writable (others read 0).  Reset: the map's cache_default regions (EXT).  Change it only after CLEAN_INVAL of the region. |
| `0x018` | CMO_SIZE | rw | `0x0` | Length in bytes of a RANGE operation (every line touched by [ADDR, ADDR+SIZE) is operated on). |
| `0x01C` | CMO_CMD | wo | - | [1:0] OP: 1 CLEAN, 2 INVAL, 3 CLEAN_INVAL; [2] ALL (whole cache, ADDR/SIZE ignored); [3] D-cache; [4] I-cache (INVAL only).  Starts the operation; refused (REG error) while BUSY.  The cache executes it before accepting its next CPU access (implicit fence). |
| `0x020` | CMO_STATUS | ro | - | [0] BUSY; [1] DONE; [2] WB_ERR: a write-back failed; [3] DIRTY_DISCARD: INVAL dropped dirty data (software bug indicator); [31:16] lines operated on by the last command |
| `0x024` | NCW0_BASE | rw | `0x0` | Non-cacheable window 0: [31:2] base (word aligned), [0] enable.  Accesses in [BASE, LIMIT) bypass both caches. |
| `0x028` | NCW0_LIMIT | rw | `0x0` | Non-cacheable window 0: exclusive end address. |
| `0x02C` | NCW1_BASE | rw | `0x0` | Non-cacheable window 1 base / enable. |
| `0x030` | NCW1_LIMIT | rw | `0x0` | Non-cacheable window 1 exclusive end. |
| `0x040` | ERR_STATUS | rw | `0x0` | [0] VALID (w1c): first error captured; [1] OVERFLOW (w1c): further errors after the first |
| `0x044` | ERR_ADDR | ro | - | Address of the first captured error. |
| `0x048` | ERR_INFO | ro | - | [3:0] CAUSE (error_causes); [6:4] MASTER; [7] WRITE |
| `0x04C` | ERR_COUNT | ro | - | Errors since reset (saturating). |
| `0x050` | IRQ_ENABLE | rw | `0x0` | [0] ERR; [1] PARITY; [2] CMO_DONE; [3] WB_ERR |
| `0x054` | IRQ_STATUS | rw | `0x0` | Same bits, w1c.  irq = |(IRQ_STATUS & IRQ_ENABLE) |
| `0x058` | ECC_CTRL | rw | `0x0` | [3:0] INJ_LANES: byte lanes whose parity is inverted; [8] INJECT (w1s, cleared when consumed): applied to the next write accepted by the selected memory; [9] INJ_LMEM: 1 = LMEM, 0 = SRAM; [16] CHECK_DIS: ignore parity on reads (diagnostics).  No effect when ECC_MODE = NONE. |
| `0x05C` | ECC_ERR_ADDR | ro | - | Address of the last parity error. |
| `0x060` | ECC_ERR_INFO | ro | - | [3:0] syndrome (failing lanes) of the last parity error; [6:4] MASTER; [8] 1 = LMEM, 0 = SRAM |
| `0x064` | ECC_ERR_COUNT | ro | - | Parity errors since reset (saturating). |
| `0x070` | VSPM_OWN | rw | `0x0` | [n] = 1: VSPM partition n owned by the ENGINE; host-window accesses to it fail (OWNERSHIP, no side effect). |
| `0x080` | SEM0 | rw | - | Hardware semaphores SEM0..SEM7 at 0x080 + 4n.  Read = atomic test-and-set: returns 0 if acquired by the reader, else (holder master + 1).  Write 0 = release (holder only, else REG error). |
| `0x100` | PERF_CTRL | rw | `0x0` | [0] FREEZE; [1] CLEAR (w1s, self-clearing) |
| `0x104` | PERF_BASE | ro | - | First of NUM_PERF counters (see perf_counters). |

## Performance counters (`PERF_BASE + 4 * index`)

| Index | Name | Description |
|---|---|---|
| 0 | CYCLES | cycles since clear |
| 1 | SRAM_ACC_M0 | SRAM accesses accepted from master 0..5 (indices 1..6) |
| 2 | SRAM_ACC_M1 | SRAM accesses accepted from master 0..5 (indices 1..6) |
| 3 | SRAM_ACC_M2 | SRAM accesses accepted from master 0..5 (indices 1..6) |
| 4 | SRAM_ACC_M3 | SRAM accesses accepted from master 0..5 (indices 1..6) |
| 5 | SRAM_ACC_M4 | SRAM accesses accepted from master 0..5 (indices 1..6) |
| 6 | SRAM_ACC_M5 | SRAM accesses accepted from master 0..5 (indices 1..6) |
| 7 | SRAM_CONF_M0 | SRAM bank-conflict stall cycles of master 0..5 (indices 7..12) |
| 8 | SRAM_CONF_M1 | SRAM bank-conflict stall cycles of master 0..5 (indices 7..12) |
| 9 | SRAM_CONF_M2 | SRAM bank-conflict stall cycles of master 0..5 (indices 7..12) |
| 10 | SRAM_CONF_M3 | SRAM bank-conflict stall cycles of master 0..5 (indices 7..12) |
| 11 | SRAM_CONF_M4 | SRAM bank-conflict stall cycles of master 0..5 (indices 7..12) |
| 12 | SRAM_CONF_M5 | SRAM bank-conflict stall cycles of master 0..5 (indices 7..12) |
| 13 | SRAM_BANK0 | SRAM accesses per bank 0..7 (indices 13..20) |
| 14 | SRAM_BANK1 | SRAM accesses per bank 0..7 (indices 13..20) |
| 15 | SRAM_BANK2 | SRAM accesses per bank 0..7 (indices 13..20) |
| 16 | SRAM_BANK3 | SRAM accesses per bank 0..7 (indices 13..20) |
| 17 | SRAM_BANK4 | SRAM accesses per bank 0..7 (indices 13..20) |
| 18 | SRAM_BANK5 | SRAM accesses per bank 0..7 (indices 13..20) |
| 19 | SRAM_BANK6 | SRAM accesses per bank 0..7 (indices 13..20) |
| 20 | SRAM_BANK7 | SRAM accesses per bank 0..7 (indices 13..20) |
| 21 | SRAM_RD_BYTES | useful bytes read from SRAM (enabled byte lanes; reads count 4) |
| 22 | SRAM_WR_BYTES | useful bytes written to SRAM (enabled byte lanes) |
| 23 | LMEM_ACC | LMEM accesses |
| 24 | LMEM_CONF | LMEM bank-conflict stall cycles (all ports) |
| 25 | DC_HIT | D-cache hits |
| 26 | DC_MISS | D-cache misses (cacheable, line absent) |
| 27 | DC_WB | D-cache dirty line write-backs (evictions + CLEAN) |
| 28 | DC_BYPASS | D-cache uncached accesses |
| 29 | IC_HIT | I-cache hits |
| 30 | IC_MISS | I-cache misses |
| 31 | CMO_LINES | lines operated on by maintenance commands |
| 32 | EXT_TXN | transactions on the ext_* port |
| 33 | EXT_STALL | cycles a request to EXT waited (arbitration or port not ready) |
| 34 | VSPM_TXN | transactions on the vs_* port |
| 35 | MMIO_TXN | transactions on the io_* port + MEMCTL |
| 36 | REQ_STALL_M0 | cycles master 0..5 presented a request that was not accepted (indices 36..41) |
| 37 | REQ_STALL_M1 | cycles master 0..5 presented a request that was not accepted (indices 36..41) |
| 38 | REQ_STALL_M2 | cycles master 0..5 presented a request that was not accepted (indices 36..41) |
| 39 | REQ_STALL_M3 | cycles master 0..5 presented a request that was not accepted (indices 36..41) |
| 40 | REQ_STALL_M4 | cycles master 0..5 presented a request that was not accepted (indices 36..41) |
| 41 | REQ_STALL_M5 | cycles master 0..5 presented a request that was not accepted (indices 36..41) |
| 42 | ERRORS | bus errors generated or relayed by MemoryCore |
