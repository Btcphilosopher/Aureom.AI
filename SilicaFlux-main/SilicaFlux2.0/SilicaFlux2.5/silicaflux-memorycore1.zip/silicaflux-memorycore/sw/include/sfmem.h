/*
 * SilicaFlux-HPC MemoryCore -- cache-maintenance and memory-ordering API for the ControlCore.
 * Aureom.AI | SilicaFlux-HPC
 *
 * Bare metal C (stdint / stddef only).  Addresses and register offsets come from the generated map
 * (generated/sfmem_map.h, from memmap/memorycore.yaml).  The contract these functions implement is
 * docs/03_CONSISTENCY.md; the short version:
 *
 *   The ControlCore caches are NOT coherent with the DMA engines, the vector engine, the TensorCore or the debug
 *   port.  Buffers change OWNER explicitly:
 *
 *     CPU -> device (device reads):      CPU writes;  sfmem_dma_to_device(buf, len);        start the device
 *     device -> CPU (device writes):     sfmem_dma_from_device_begin(buf, len);  start;  wait for completion;
 *                                        sfmem_dma_from_device_end(buf, len);              CPU reads
 *     bidirectional (device reads and writes):   begin = sfmem_dma_bidir_begin, end = sfmem_dma_from_device_end
 *
 *   While a device owns a buffer the CPU must neither read nor write it.  Receive buffers must be cache-line
 *   aligned and a whole number of lines (SFMEM_DMA_ALIGN) -- otherwise a neighbouring CPU variable shares a line
 *   and either the CPU's write-back destroys device data or the invalidate destroys CPU data; the receive calls
 *   refuse misaligned buffers (SFMEM_EALIGN).  A device's completion means all its writes were acknowledged by
 *   memory (SFB2 R7), so data is visible to everybody once the CPU has seen the completion record.
 *
 *   Memory that the CPU and devices share at fine grain (descriptors, mailboxes, flags) should be placed in a
 *   non-cacheable window (sfmem_set_noncacheable) -- then no maintenance is needed for it at all.
 *
 * All functions are safe without caches (DCACHE_EN / ICACHE_EN = 0 or disabled): maintenance then completes at
 * once.  Not thread-safe against interrupt handlers that issue maintenance themselves (one CMO at a time).
 */
#ifndef SFMEM_H
#define SFMEM_H

#include <stddef.h>
#include <stdint.h>
#include "sfmem_map.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Alignment for DMA receive buffers: >= every legal CACHE_LINE of this design family (8..64 B).  The run-time
 * requirement is sfmem_line_bytes(); allocating with SFMEM_DMA_ALIGN satisfies it for any build. */
#define SFMEM_DMA_ALIGN 64u

#define SFMEM_EINVAL   (-1)       /* bad argument */
#define SFMEM_EALIGN   (-2)       /* receive buffer not cache-line aligned / sized */
#define SFMEM_EIO      (-3)       /* a write-back was refused by memory (data of that line lost) */
#define SFMEM_EABI     (-4)       /* MEMCTL ID / map version mismatch */
#define SFMEM_EDISCARD (-5)       /* an INVAL dropped dirty data (ownership rule broken somewhere) */

#ifndef SFMEM_MEMCTL
#define SFMEM_MEMCTL SFMEM_PAGE_MEMCTL
#endif
#define SFMEM_REG(off) (*(volatile uint32_t *)(uintptr_t)(SFMEM_MEMCTL + (off)))

typedef struct {
    uint32_t info, cache_info, sram_size;
    uint32_t line_bytes, sets, ways;
    int      dcache, icache, write_back, ecc_parity;
} sfmem_info_t;

typedef struct {
    uint32_t status, addr, info, count;
} sfmem_err_t;

/* ---------------------------------------------------------------------------------------------- ordering */
/* Compiler barrier + RISC-V FENCE + an uncached read of MEMCTL.ID.  On the in-order SilicaFlux-V data port every
 * earlier uncached or write-through store has been acknowledged by its target when this returns; stores held in
 * a WRITE-BACK D-cache are NOT made visible by a fence -- use CLEAN (sfmem_dma_to_device). */
static inline void sfmem_fence(void)
{
    __asm__ volatile("fence rw, rw" ::: "memory");
    (void)SFMEM_REG(SFMEM_MC_ID);
    __asm__ volatile("" ::: "memory");
}

/* ---------------------------------------------------------------------------------------------- setup */
/* Initialise memory: with ECC_MODE = PARITY a word must be written once before ANY read of it -- a read always
 * returns (and checks) the whole word, so a byte load, a DMA burst or a cache-line refill touching a never-written
 * word fails with PARITY (the macros power up with random content).  Writes zero words; call it for every SRAM /
 * LMEM range in use BEFORE enabling the D-cache on it (a write-allocate refill would read the old content). */
void     sfmem_scrub(void *base, size_t len);
int      sfmem_init(sfmem_info_t *info);                    /* probe; caches stay as they are */
void     sfmem_cache_enable(int dcache, int icache);        /* enable (1) / disable (0); disabling the D-cache
                                                               first cleans + invalidates it */
uint32_t sfmem_line_bytes(void);
/* Select the regions the ControlCore caches hold (SFMEM_REGION_EXT | SFMEM_REGION_SRAM ...; only regions marked
 * cacheable in the map can be selected).  Reset: EXT only -- the measured case (docs/10_PERFORMANCE.md E4/E5): the
 * banked shared SRAM answers in ~1 cycle even under DMA load, so caching it rarely pays and costs maintenance.
 * Regions being removed are cleaned and invalidated first.  Returns the mask actually in effect. */
uint32_t sfmem_cache_regions(uint32_t mask);

/* ---------------------------------------------------------------------------------------------- maintenance */
/* op: SFMEM_CMO_CLEAN / _INVAL / _CLEAN_INVAL; sel: SFMEM_CMO_DCACHE and/or SFMEM_CMO_ICACHE.  Returns 0,
 * SFMEM_EIO (write-back refused) or SFMEM_EDISCARD (INVAL dropped dirty data); waits for completion. */
int      sfmem_cmo_range(unsigned op, unsigned sel, uintptr_t addr, size_t len);
int      sfmem_cmo_all(unsigned op, unsigned sel);
static inline int sfmem_dcache_clean(const void *a, size_t n)      { return sfmem_cmo_range(SFMEM_CMO_CLEAN, SFMEM_CMO_DCACHE, (uintptr_t)a, n); }
static inline int sfmem_dcache_inval(void *a, size_t n)            { return sfmem_cmo_range(SFMEM_CMO_INVAL, SFMEM_CMO_DCACHE, (uintptr_t)a, n); }
static inline int sfmem_dcache_clean_inval(void *a, size_t n)      { return sfmem_cmo_range(SFMEM_CMO_CLEAN_INVAL, SFMEM_CMO_DCACHE, (uintptr_t)a, n); }
static inline int sfmem_icache_inval(const void *a, size_t n)      { return sfmem_cmo_range(SFMEM_CMO_INVAL, SFMEM_CMO_ICACHE, (uintptr_t)a, n); }
/* new code written through the D-port (or by a DMA) becomes executable */
int      sfmem_sync_icache(const void *code, size_t len);

/* ---------------------------------------------------------------------------------------------- DMA ownership */
int      sfmem_dma_to_device(const void *buf, size_t len);          /* CLEAN: device may read */
int      sfmem_dma_from_device_begin(void *buf, size_t len);        /* CLEAN_INVAL; line-aligned only */
int      sfmem_dma_bidir_begin(void *buf, size_t len);              /* CLEAN_INVAL; line-aligned only */
int      sfmem_dma_from_device_end(void *buf, size_t len);          /* INVAL; CPU may read */

/* ---------------------------------------------------------------------------------------------- attributes */
/* Window w (0/1) of [base, limit) bypasses both caches.  Cleans + invalidates the range first. limit = 0 disables. */
int      sfmem_set_noncacheable(unsigned w, uintptr_t base, uintptr_t limit);

/* ---------------------------------------------------------------------------------------------- scratchpad */
/* Hand VSPM partitions (bit n = partition n, SFMEM_VSPM_PART_BYTES each) to the vector engine / take them back.
 * While engine-owned, host-window accesses fail (bus error, no side effect). */
void     sfmem_vspm_give(uint32_t parts);
void     sfmem_vspm_take(uint32_t parts);
uint32_t sfmem_vspm_owner_mask(void);

/* ---------------------------------------------------------------------------------------------- semaphores */
int      sfmem_sem_try(unsigned i);       /* 1 = acquired */
void     sfmem_sem_lock(unsigned i);
int      sfmem_sem_unlock(unsigned i);    /* 0; a release by a non-holder is refused by MEMCTL (REG error,
                                             i.e. a store access fault on the ControlCore) */

/* ---------------------------------------------------------------------------------------------- diagnostics */
void     sfmem_err_read(sfmem_err_t *e);
void     sfmem_err_clear(void);
uint32_t sfmem_perf(unsigned idx);
void     sfmem_perf_clear(void);
void     sfmem_perf_freeze(int on);

#ifdef __cplusplus
}
#endif
#endif /* SFMEM_H */
