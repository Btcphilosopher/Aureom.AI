/*
 * SilicaFlux-HPC MemoryCore -- cache-maintenance and memory-ordering API (implementation).
 * Aureom.AI | SilicaFlux-HPC.  See sfmem.h and docs/03_CONSISTENCY.md.
 */
#include "sfmem.h"

static uint32_t g_line = 16;          /* updated by sfmem_init from CACHE_INFO */
static int      g_dcache, g_icache;

int sfmem_init(sfmem_info_t *info)
{
    uint32_t id = SFMEM_REG(SFMEM_MC_ID);
    uint32_t inf = SFMEM_REG(SFMEM_MC_INFO);
    uint32_t ci = SFMEM_REG(SFMEM_MC_CACHE_INFO);
    if (id != SFMEM_MEMCTL_ID_VALUE || (inf & 0xFFu) != SFMEM_MAP_VERSION)
        return SFMEM_EABI;
    g_line = 1u << (ci & 0xFu);
    g_dcache = (inf >> 17) & 1u;
    g_icache = (inf >> 16) & 1u;
    if (info) {
        info->info = inf;
        info->cache_info = ci;
        info->sram_size = SFMEM_REG(SFMEM_MC_SRAM_SIZE);
        info->line_bytes = g_line;
        info->sets = 1u << ((ci >> 4) & 0xFFu);
        info->ways = (ci >> 12) & 0xFu;
        info->dcache = g_dcache;
        info->icache = g_icache;
        info->write_back = (int)((inf >> 18) & 1u);
        info->ecc_parity = ((inf >> 19) & 3u) == 1u;
    }
    return 0;
}

uint32_t sfmem_line_bytes(void) { return g_line; }

void sfmem_scrub(void *base, size_t len)
{
    volatile uint32_t *p = (volatile uint32_t *)base;
    for (size_t i = 0; i < len / 4u; i++)
        p[i] = 0u;                                /* full-word stores: every lane gets valid parity */
    sfmem_fence();
}

static int cmo_issue(uint32_t cmd)
{
    uint32_t st;
    SFMEM_REG(SFMEM_MC_CMO_CMD) = cmd;
    /* A D-cache command is executed before this CPU's next data access is accepted (implicit fence), so the first
     * status read already returns !BUSY for it.  An I-cache command runs alongside the data port: poll. */
    do {
        st = SFMEM_REG(SFMEM_MC_CMO_STATUS);
    } while (st & SFMEM_CMO_ST_BUSY);
    if (st & SFMEM_CMO_ST_WB_ERR)
        return SFMEM_EIO;
    if (st & SFMEM_CMO_ST_DISCARD)
        return SFMEM_EDISCARD;
    return 0;
}

int sfmem_cmo_range(unsigned op, unsigned sel, uintptr_t addr, size_t len)
{
    if (op == 0u || op > 3u || (sel & ~(SFMEM_CMO_DCACHE | SFMEM_CMO_ICACHE)) || !sel)
        return SFMEM_EINVAL;
    if (len == 0u)
        return 0;
    __asm__ volatile("" ::: "memory");
    SFMEM_REG(SFMEM_MC_CMO_ADDR) = (uint32_t)addr;
    SFMEM_REG(SFMEM_MC_CMO_SIZE) = (uint32_t)len;
    int r = cmo_issue(op | sel);
    __asm__ volatile("" ::: "memory");
    return r;
}

int sfmem_cmo_all(unsigned op, unsigned sel)
{
    if (op == 0u || op > 3u || !sel)
        return SFMEM_EINVAL;
    __asm__ volatile("" ::: "memory");
    int r = cmo_issue(op | sel | SFMEM_CMO_ALL);
    __asm__ volatile("" ::: "memory");
    return r;
}

uint32_t sfmem_cache_regions(uint32_t mask)
{
    uint32_t cur = SFMEM_REG(SFMEM_MC_CACHE_REGIONS);
    if (cur & ~mask) {                            /* a region leaves the caches: no line of it may stay behind */
        (void)sfmem_cmo_all(SFMEM_CMO_CLEAN_INVAL, SFMEM_CMO_DCACHE);
        (void)sfmem_cmo_all(SFMEM_CMO_INVAL, SFMEM_CMO_ICACHE);
    }
    SFMEM_REG(SFMEM_MC_CACHE_REGIONS) = mask;
    sfmem_fence();
    return SFMEM_REG(SFMEM_MC_CACHE_REGIONS);
}

void sfmem_cache_enable(int dcache, int icache)
{
    uint32_t cur = SFMEM_REG(SFMEM_MC_CACHE_CTRL);
    if ((cur & 1u) && !dcache)
        (void)sfmem_cmo_all(SFMEM_CMO_CLEAN_INVAL, SFMEM_CMO_DCACHE);   /* never strand dirty lines */
    if ((cur & 2u) && !icache)
        (void)sfmem_cmo_all(SFMEM_CMO_INVAL, SFMEM_CMO_ICACHE);
    if (!(cur & 2u) && icache)
        (void)sfmem_cmo_all(SFMEM_CMO_INVAL, SFMEM_CMO_ICACHE);         /* drop lines from an earlier epoch */
    if (!(cur & 1u) && dcache)
        (void)sfmem_cmo_all(SFMEM_CMO_INVAL, SFMEM_CMO_DCACHE);
    SFMEM_REG(SFMEM_MC_CACHE_CTRL) = (dcache ? 1u : 0u) | (icache ? 2u : 0u);
    sfmem_fence();
}

int sfmem_sync_icache(const void *code, size_t len)
{
    int r = sfmem_dcache_clean(code, len);
    if (r)
        return r;
    r = sfmem_icache_inval(code, len);
    __asm__ volatile("fence.i" ::: "memory");     /* SilicaFlux-V: discards the 2-entry prefetch buffer */
    return r;
}

static int line_ok(const void *buf, size_t len)
{
    return (((uintptr_t)buf | len) & (g_line - 1u)) == 0u;
}

int sfmem_dma_to_device(const void *buf, size_t len)
{
    return sfmem_dcache_clean(buf, len);          /* write-through: nothing dirty, completes at once */
}

int sfmem_dma_from_device_begin(void *buf, size_t len)
{
    if (!line_ok(buf, len))
        return SFMEM_EALIGN;
    return sfmem_dcache_clean_inval(buf, len);   /* no dirty line can later be written over device data */
}

int sfmem_dma_bidir_begin(void *buf, size_t len)
{
    return sfmem_dma_from_device_begin(buf, len);
}

int sfmem_dma_from_device_end(void *buf, size_t len)
{
    if (!line_ok(buf, len))
        return SFMEM_EALIGN;
    int r = sfmem_dcache_inval(buf, len);         /* drop anything allocated while the device owned it */
    return r == SFMEM_EDISCARD ? SFMEM_EDISCARD : r;
}

int sfmem_set_noncacheable(unsigned w, uintptr_t base, uintptr_t limit)
{
    if (w > 1u || (base & 3u) || (limit && limit <= base))
        return SFMEM_EINVAL;
    if (limit) {
        int r = sfmem_cmo_range(SFMEM_CMO_CLEAN_INVAL, SFMEM_CMO_DCACHE | SFMEM_CMO_ICACHE, base, limit - base);
        if (r)
            return r;
    }
    uint32_t b = w ? SFMEM_MC_NCW1_BASE : SFMEM_MC_NCW0_BASE;
    uint32_t l = w ? SFMEM_MC_NCW1_LIMIT : SFMEM_MC_NCW0_LIMIT;
    SFMEM_REG(b) = 0u;                            /* disable while changing */
    SFMEM_REG(l) = (uint32_t)limit;
    SFMEM_REG(b) = limit ? ((uint32_t)base | 1u) : 0u;
    sfmem_fence();
    return 0;
}

void sfmem_vspm_give(uint32_t parts)
{
    sfmem_fence();                                /* host-window writes acknowledged before the hand-over */
    SFMEM_REG(SFMEM_MC_VSPM_OWN) = SFMEM_REG(SFMEM_MC_VSPM_OWN) | parts;
    sfmem_fence();
}

void sfmem_vspm_take(uint32_t parts)
{
    SFMEM_REG(SFMEM_MC_VSPM_OWN) = SFMEM_REG(SFMEM_MC_VSPM_OWN) & ~parts;
    sfmem_fence();
}

uint32_t sfmem_vspm_owner_mask(void) { return SFMEM_REG(SFMEM_MC_VSPM_OWN); }

int sfmem_sem_try(unsigned i)
{
    if (i >= 8u)
        return 0;
    return SFMEM_REG(SFMEM_MC_SEM0 + 4u * i) == 0u;
}

void sfmem_sem_lock(unsigned i)
{
    while (!sfmem_sem_try(i)) {
    }
    __asm__ volatile("" ::: "memory");
}

int sfmem_sem_unlock(unsigned i)
{
    if (i >= 8u)
        return SFMEM_EINVAL;
    sfmem_fence();                                /* critical-section stores acknowledged before the release */
    SFMEM_REG(SFMEM_MC_SEM0 + 4u * i) = 0u;
    return 0;
}

void sfmem_err_read(sfmem_err_t *e)
{
    e->status = SFMEM_REG(SFMEM_MC_ERR_STATUS);
    e->addr = SFMEM_REG(SFMEM_MC_ERR_ADDR);
    e->info = SFMEM_REG(SFMEM_MC_ERR_INFO);
    e->count = SFMEM_REG(SFMEM_MC_ERR_COUNT);
}

void sfmem_err_clear(void) { SFMEM_REG(SFMEM_MC_ERR_STATUS) = 3u; }

uint32_t sfmem_perf(unsigned idx)
{
    return idx < SFMEM_NUM_PERF ? SFMEM_REG(SFMEM_MC_PERF_BASE + 4u * idx) : 0u;
}

void sfmem_perf_clear(void) { SFMEM_REG(SFMEM_MC_PERF_CTRL) = 2u; }

void sfmem_perf_freeze(int on) { SFMEM_REG(SFMEM_MC_PERF_CTRL) = on ? 1u : 0u; }
