// =============================================================================
// SilicaFlux-HPC MemoryCore :: tb_sfmem_perf -- performance measurement harness (verification only)
//
// One traffic generator per requester, configured by plusargs (m = 0..5):
//   +m<m>_mode=  0 idle | 1 sequential words | 2 random words | 3 stride = SRAM_BANKS words (one bank)
//                4 CPU loop: sequential over a working set, repeated (reuse) | 5 CPU random over a working set
//   +m<m>_base=HEX +m<m>_size=HEX (bytes)  +m<m>_n=N (operations; 0 = background, runs until the measured
//   generators finish)  +m<m>_out=N (max in flight; 1 = blocking CPU)  +m<m>_wr=% (writes)  +m<m>_strb=HEX
// Setup (before traffic, through the debug port): +dcache=1 / +icache=1 enable the ControlCore caches; +ncw=HEX
// sets non-cacheable window 0 to [HEX, HEX+0x1000).
// Measured per generator: operations, bytes, cycles from its first request to its last response, latency from
// first presentation to response (avg, max, histogram), cycles stalled with a request presented.
// Printed: "PERF m ops bytes cycles lat_sum lat_max stall" and the MEMCTL counters (white-box read) for the
// cross-check in scripts/run_perf.py.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`ifndef SRAM_BANKS
  `define SRAM_BANKS 8
`endif
`ifndef SRAM_RD_LAT
  `define SRAM_RD_LAT 1
`endif
`ifndef SRAM_ARB
  `define SRAM_ARB 0
`endif
`ifndef EXT_LAT
  `define EXT_LAT 20
`endif
`ifndef EXT_DEPTH
  `define EXT_DEPTH 4
`endif
`ifndef MAX_OUT
  `define MAX_OUT 4
`endif
`ifndef CACHE_SETS
  `define CACHE_SETS 64
`endif
`ifndef CACHE_WAYS
  `define CACHE_WAYS 2
`endif
`ifndef CACHE_LINE
  `define CACHE_LINE 16
`endif

module tb_sfmem_perf;
  localparam int NM = 6;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb;
  logic        ext_req_valid, ext_req_ready, ext_req_write, ext_rsp_valid, ext_rsp_ready, ext_rsp_error;
  logic [31:0] ext_req_addr, ext_req_wdata, ext_rsp_rdata;
  logic [3:0]  ext_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        vv, vw, iv, iw, irq, busy, vr_r, ir_r;
  logic [31:0] va, vd, ia, id;
  logic [3:0]  vs, is_;
  logic [`SRAM_BANKS*36-1:0] str;
  logic [2*36-1:0] ltr;
  int          ext_n;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_memory_subsystem #(
    .SRAM_BANKS(`SRAM_BANKS), .SRAM_RD_LAT(`SRAM_RD_LAT), .SRAM_ARB(`SRAM_ARB), .ECC_MODE(1), .DCACHE_EN(1),
    .ICACHE_EN(1), .DCACHE_WB(1), .CACHE_SETS(`CACHE_SETS), .CACHE_WAYS(`CACHE_WAYS), .CACHE_LINE(`CACHE_LINE),
    .MAX_OUT(`MAX_OUT), .EXT_DEPTH(`EXT_DEPTH)
  ) u_dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .ext_req_valid(ext_req_valid), .ext_req_ready(ext_req_ready), .ext_req_write(ext_req_write),
    .ext_req_addr(ext_req_addr), .ext_req_wdata(ext_req_wdata), .ext_req_wstrb(ext_req_wstrb),
    .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(ext_rsp_ready), .ext_rsp_rdata(ext_rsp_rdata),
    .ext_rsp_error(ext_rsp_error),
    .vs_req_valid(vv), .vs_req_ready(1'b1), .vs_req_write(vw), .vs_req_addr(va), .vs_req_wdata(vd),
    .vs_req_wstrb(vs), .vs_rsp_valid(1'b0), .vs_rsp_ready(vr_r), .vs_rsp_rdata(32'd0), .vs_rsp_error(1'b0),
    .io_req_valid(iv), .io_req_ready(1'b1), .io_req_write(iw), .io_req_addr(ia), .io_req_wdata(id),
    .io_req_wstrb(is_), .io_rsp_valid(1'b0), .io_rsp_ready(ir_r), .io_rsp_rdata(32'd0), .io_rsp_error(1'b0),
    .irq(irq),
    .sram_tst_active(1'b0), .sram_tst_sel('0), .sram_tst_ce(1'b0), .sram_tst_we(1'b0), .sram_tst_addr('0),
    .sram_tst_wdata('0), .sram_tst_rdata(str),
    .lmem_tst_active(1'b0), .lmem_tst_sel('0), .lmem_tst_ce(1'b0), .lmem_tst_we(1'b0), .lmem_tst_addr('0),
    .lmem_tst_wdata('0), .lmem_tst_rdata(ltr), .busy(busy)
  );
  sfmem_tb_slave #(.LAT(`EXT_LAT), .QD(16), .BASE(32'h8000_0000), .WORDS(262144), .NAME("ext")) u_ext (
    .clk(clk), .rst_n(rst_n), .stall_pct(32'd0), .jitter(32'd0), .dyn_lo(32'd0), .dyn_hi(32'd0),
    .req_valid(ext_req_valid), .req_ready(ext_req_ready), .req_write(ext_req_write), .req_addr(ext_req_addr),
    .req_wdata(ext_req_wdata), .req_wstrb(ext_req_wstrb), .rsp_valid(ext_rsp_valid), .rsp_ready(ext_rsp_ready),
    .rsp_rdata(ext_rsp_rdata), .rsp_error(ext_rsp_error), .n_acc(ext_n));

  // memory initialised with valid parity (the initialisation rule; see docs/07)
  localparam int SRAW = $clog2(sfmem_map_pkg::SRAM_BYTES / 4 / `SRAM_BANKS);
  for (genvar b = 0; b < `SRAM_BANKS; b++) begin : g_init
    initial for (int r = 0; r < (1 << SRAW); r++)
      u_dut.u_sram.u_bc.g_bank[b].u_bank.g_generic.u_mem.mem[r] = {4{1'b1, 8'h00}};
  end

  // ------------------------------------------------------------ generators
  int          mode [NM], n [NM], out [NM], wrp [NM];
  logic [31:0] base [NM], size [NM];
  logic [3:0]  strb [NM];
  logic        go, stop;
  logic        su_v = 1'b0;
  logic [31:0] su_a = 32'd0, su_d = 32'd0;
  int          cyc;
  // per-generator state / statistics
  int     issued [NM], done_n [NM], infl [NM], lat_max [NM], stall [NM], hist [NM*8];
  longint lat_sum [NM], bytes [NM];
  int     first_c [NM], last_c [NM];
  int     pt [NM*64], pw [NM], pr [NM];      // presentation cycle of each in-flight op
  int     pres_c [NM];
  logic [31:0] lfsr [NM];

  function automatic logic [31:0] gen_addr(input int m, input int i, input logic [31:0] rnd);
    logic [31:0] w, words;
    words = size[m] >> 2;
    case (mode[m])
      1, 4:    w = 32'(i) % words;
      2, 5:    w = rnd % words;
      3:       w = (32'(i) * `SRAM_BANKS) % words;
      default: w = 0;
    endcase
    gen_addr = base[m] + (w << 2);
  endfunction

  always_comb begin
    for (int m = 0; m < NM; m++) begin
      logic act;
      act = go && !stop && mode[m] != 0 && (n[m] == 0 || issued[m] < n[m]) && infl[m] < out[m];
      m_req_valid[m] = act;
      m_req_write[m] = ((32'(issued[m]) * 32'd2654435761 + 32'(m) * 32'd97) % 100) < 32'(wrp[m]);
      m_req_addr[m*32 +: 32] = gen_addr(m, issued[m], lfsr[m]);
      m_req_wdata[m*32 +: 32] = 32'(issued[m]) ^ 32'hA5A5_0000;
      m_req_wstrb[m*4 +: 4] = m_req_write[m] ? strb[m] : 4'h0;
      m_rsp_ready[m] = 1'b1;
    end
    if (su_v) begin                       // setup write through the debug port (before traffic)
      m_req_valid[0] = 1'b1; m_req_write[0] = 1'b1; m_req_addr[31:0] = su_a; m_req_wdata[31:0] = su_d;
      m_req_wstrb[3:0] = 4'hF;
    end
  end

  always @(posedge clk) begin
    if (!rst_n || !go) begin
      cyc <= 0;
      for (int m = 0; m < NM; m++) begin
        issued[m] <= 0; done_n[m] <= 0; infl[m] <= 0; lat_max[m] <= 0; stall[m] <= 0; lat_sum[m] <= 0;
        bytes[m] <= 0; first_c[m] <= -1; last_c[m] <= 0; pw[m] <= 0; pr[m] <= 0; pres_c[m] <= -1;
        lfsr[m] <= 32'h1234_5678 ^ (32'(m) << 20);
        for (int k = 0; k < 8; k++) hist[m*8 + k] <= 0;
      end
    end else begin
      cyc <= cyc + 1;
      for (int m = 0; m < NM; m++) begin
        int d_infl;
        d_infl = 0;
        if (m_req_valid[m]) begin
          if (pres_c[m] < 0) pres_c[m] <= cyc;
          if (first_c[m] < 0) first_c[m] <= cyc;
          if (!m_req_ready[m]) stall[m] <= stall[m] + 1;
        end
        if (m_req_valid[m] && m_req_ready[m]) begin
          pt[m*64 + (pw[m] % 64)] = (pres_c[m] < 0) ? cyc : pres_c[m];
          pw[m] <= pw[m] + 1;
          pres_c[m] <= -1;
          issued[m] <= issued[m] + 1;
          lfsr[m] <= {lfsr[m][30:0], lfsr[m][31] ^ lfsr[m][21] ^ lfsr[m][1] ^ lfsr[m][0]};
          bytes[m] <= bytes[m] + (m_req_write[m] ? ((m_req_wstrb[m*4] ? 1 : 0) + (m_req_wstrb[m*4+1] ? 1 : 0) +
                                                    (m_req_wstrb[m*4+2] ? 1 : 0) + (m_req_wstrb[m*4+3] ? 1 : 0)) : 4);
          d_infl = d_infl + 1;
        end
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          int l;
          l = cyc - pt[m*64 + (pr[m] % 64)];
          pr[m] <= pr[m] + 1;
          lat_sum[m] <= lat_sum[m] + l;
          if (l > lat_max[m]) lat_max[m] <= l;
          hist[m*8 + ((l <= 1) ? 0 : (l <= 2) ? 1 : (l <= 4) ? 2 : (l <= 8) ? 3 : (l <= 16) ? 4 : (l <= 32) ? 5 :
                      (l <= 64) ? 6 : 7)] <= hist[m*8 + ((l <= 1) ? 0 : (l <= 2) ? 1 : (l <= 4) ? 2 : (l <= 8) ? 3 :
                      (l <= 16) ? 4 : (l <= 32) ? 5 : (l <= 64) ? 6 : 7)] + 1;
          done_n[m] <= done_n[m] + 1;
          last_c[m] <= cyc;
          d_infl = d_infl - 1;
        end
        infl[m] <= infl[m] + d_infl;
      end
    end
  end

  // ------------------------------------------------------------ setup through the debug port, then run
  task automatic setup_wr(input logic [31:0] a, input logic [31:0] d);
    @(negedge clk);
    su_a = a; su_d = d; su_v = 1'b1;
    do @(posedge clk); while (!m_req_ready[0]);
    @(negedge clk);
    su_v = 1'b0;
    repeat (4) @(posedge clk);
  endtask

  initial begin
    int dc, ic, finished;
    logic [31:0] ncw, creg;
    go = 1'b0; stop = 1'b0;
    // literal format strings (Verilator 5.020 needs constant $value$plusargs formats)
    if (!$value$plusargs("m0_mode=%d", mode[0])) mode[0] = 0;
    if (!$value$plusargs("m0_base=%h", base[0])) base[0] = 32'h1000_0000 + 32'(0) * 32'h8000;
    if (!$value$plusargs("m0_size=%h", size[0])) size[0] = 32'h1000;
    if (!$value$plusargs("m0_n=%d", n[0])) n[0] = 0;
    if (!$value$plusargs("m0_out=%d", out[0])) out[0] = 4;
    if (!$value$plusargs("m0_wr=%d", wrp[0])) wrp[0] = 0;
    if (!$value$plusargs("m0_strb=%h", strb[0])) strb[0] = 4'hF;
    if (!$value$plusargs("m1_mode=%d", mode[1])) mode[1] = 0;
    if (!$value$plusargs("m1_base=%h", base[1])) base[1] = 32'h1000_0000 + 32'(1) * 32'h8000;
    if (!$value$plusargs("m1_size=%h", size[1])) size[1] = 32'h1000;
    if (!$value$plusargs("m1_n=%d", n[1])) n[1] = 0;
    if (!$value$plusargs("m1_out=%d", out[1])) out[1] = 4;
    if (!$value$plusargs("m1_wr=%d", wrp[1])) wrp[1] = 0;
    if (!$value$plusargs("m1_strb=%h", strb[1])) strb[1] = 4'hF;
    if (!$value$plusargs("m2_mode=%d", mode[2])) mode[2] = 0;
    if (!$value$plusargs("m2_base=%h", base[2])) base[2] = 32'h1000_0000 + 32'(2) * 32'h8000;
    if (!$value$plusargs("m2_size=%h", size[2])) size[2] = 32'h1000;
    if (!$value$plusargs("m2_n=%d", n[2])) n[2] = 0;
    if (!$value$plusargs("m2_out=%d", out[2])) out[2] = 4;
    if (!$value$plusargs("m2_wr=%d", wrp[2])) wrp[2] = 0;
    if (!$value$plusargs("m2_strb=%h", strb[2])) strb[2] = 4'hF;
    if (!$value$plusargs("m3_mode=%d", mode[3])) mode[3] = 0;
    if (!$value$plusargs("m3_base=%h", base[3])) base[3] = 32'h1000_0000 + 32'(3) * 32'h8000;
    if (!$value$plusargs("m3_size=%h", size[3])) size[3] = 32'h1000;
    if (!$value$plusargs("m3_n=%d", n[3])) n[3] = 0;
    if (!$value$plusargs("m3_out=%d", out[3])) out[3] = 4;
    if (!$value$plusargs("m3_wr=%d", wrp[3])) wrp[3] = 0;
    if (!$value$plusargs("m3_strb=%h", strb[3])) strb[3] = 4'hF;
    if (!$value$plusargs("m4_mode=%d", mode[4])) mode[4] = 0;
    if (!$value$plusargs("m4_base=%h", base[4])) base[4] = 32'h1000_0000 + 32'(4) * 32'h8000;
    if (!$value$plusargs("m4_size=%h", size[4])) size[4] = 32'h1000;
    if (!$value$plusargs("m4_n=%d", n[4])) n[4] = 0;
    if (!$value$plusargs("m4_out=%d", out[4])) out[4] = 4;
    if (!$value$plusargs("m4_wr=%d", wrp[4])) wrp[4] = 0;
    if (!$value$plusargs("m4_strb=%h", strb[4])) strb[4] = 4'hF;
    if (!$value$plusargs("m5_mode=%d", mode[5])) mode[5] = 0;
    if (!$value$plusargs("m5_base=%h", base[5])) base[5] = 32'h1000_0000 + 32'(5) * 32'h8000;
    if (!$value$plusargs("m5_size=%h", size[5])) size[5] = 32'h1000;
    if (!$value$plusargs("m5_n=%d", n[5])) n[5] = 0;
    if (!$value$plusargs("m5_out=%d", out[5])) out[5] = 4;
    if (!$value$plusargs("m5_wr=%d", wrp[5])) wrp[5] = 0;
    if (!$value$plusargs("m5_strb=%h", strb[5])) strb[5] = 4'hF;
    if (!$value$plusargs("dcache=%d", dc)) dc = 0;
    if (!$value$plusargs("icache=%d", ic)) ic = 0;
    if (!$value$plusargs("ncw=%h", ncw)) ncw = 0;
    if (!$value$plusargs("cregions=%h", creg)) creg = 32'h10;     // CACHE_REGIONS (reset value: EXT only)
    repeat (4) @(posedge clk);
    rst_n = 1'b1;
    repeat (4) @(posedge clk);
    if (ncw != 0) begin
      setup_wr(sfmem_map_pkg::MEMCTL_PAGE_BASE + 32'(sfmem_map_pkg::MC_NCW0_LIMIT), ncw + 32'h1000);
      setup_wr(sfmem_map_pkg::MEMCTL_PAGE_BASE + 32'(sfmem_map_pkg::MC_NCW0_BASE), ncw | 32'd1);
    end
    setup_wr(sfmem_map_pkg::MEMCTL_PAGE_BASE + 32'(sfmem_map_pkg::MC_CACHE_REGIONS), creg);
    setup_wr(sfmem_map_pkg::MEMCTL_PAGE_BASE + 32'(sfmem_map_pkg::MC_CACHE_CTRL), 32'(dc != 0) | (32'(ic != 0) << 1));
    setup_wr(sfmem_map_pkg::MEMCTL_PAGE_BASE + 32'(sfmem_map_pkg::MC_PERF_CTRL), 32'd2);   // clear counters
    @(negedge clk) go = 1'b1;
    do begin
      @(posedge clk);
      finished = 1;
      for (int m = 0; m < NM; m++) if (mode[m] != 0 && n[m] != 0 && done_n[m] < n[m]) finished = 0;
    end while (!finished && cyc < 5000000);
    @(negedge clk) stop = 1'b1;
    repeat (200) @(posedge clk);
    for (int m = 0; m < NM; m++) begin
      $display("PERF %0d %0d %0d %0d %0d %0d %0d", m, done_n[m], bytes[m], (first_c[m] < 0) ? 0 : last_c[m] - first_c[m] + 1,
               lat_sum[m], lat_max[m], stall[m]);
      $display("HIST %0d %0d %0d %0d %0d %0d %0d %0d %0d", m, hist[m*8], hist[m*8+1], hist[m*8+2], hist[m*8+3],
               hist[m*8+4], hist[m*8+5], hist[m*8+6], hist[m*8+7]);
    end
    for (int i = 0; i < sfmem_map_pkg::NUM_PERF; i++) $display("PC %0d %0d", i, u_dut.u_regs.pc_q[i]);
    $display("RESULT: DONE (%0d cycles)", cyc);
    $finish;
  end
endmodule

`default_nettype wire
