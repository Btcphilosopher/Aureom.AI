// =============================================================================
// SilicaFlux-HPC MemoryCore :: sfmem_tb_slave -- SFB2 memory model (verification only)
//
// Models the external memory (ext_*), the vector-scratchpad host window (vs_*)
// and the MMIO register pages (io_*).  Storage: WORDS words at BASE (Icarus 12 has
// no associative arrays), initial content f(addr) (same function as the reference
// model); an access outside [BASE, BASE + 4*WORDS) that is not in the error
// window is answered with an error (the tests never rely on unmodelled storage).  Accepts up to QD
// requests (random req_ready low: STALL %), performs a write at acceptance and
// answers every request in order LAT (+ random JITTER) cycles later; rdata is 0
// for writes and errors (SFB2 R8).  Errors (no side effect): addresses in
// [ERR_LO, ERR_HI), and sub-word writes when WORD_ONLY = 1 (register bus rule).
// =============================================================================
`default_nettype none

module sfmem_tb_slave #(
  parameter int          LAT       = 1,
  parameter int          QD        = 8,
  parameter logic [31:0] ERR_LO    = 32'hFFFF_FFFF,
  parameter logic [31:0] ERR_HI    = 32'hFFFF_FFFF,
  parameter int          WORD_ONLY = 0,
  parameter logic [31:0] BASE      = 32'h8000_0000,
  parameter int          WORDS     = 262144,
  parameter              NAME      = "slave"
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic [31:0] stall_pct,
  input  wire logic [31:0] jitter,
  input  wire logic [31:0] dyn_lo,          // run-time error window [dyn_lo, dyn_hi) (testbench control page)
  input  wire logic [31:0] dyn_hi,
  input  wire logic        req_valid,
  output logic             req_ready,
  input  wire logic        req_write,
  input  wire logic [31:0] req_addr,
  input  wire logic [31:0] req_wdata,
  input  wire logic [3:0]  req_wstrb,
  output logic             rsp_valid,
  input  wire logic        rsp_ready,
  output logic [31:0]      rsp_rdata,
  output logic             rsp_error,
  output int               n_acc
);
  logic [31:0] mem [WORDS];
  localparam logic [31:0] LIMIT = BASE + 32'(WORDS * 4);
  initial for (int i = 0; i < WORDS; i++) mem[i] = init_word(BASE + 32'(i * 4));

  function automatic logic [31:0] init_word(input logic [31:0] a);
    init_word = ({a[31:2], 2'b00} * 32'h9E37_79B1) ^ 32'hA5A5_A5A5;
  endfunction

  function automatic logic [31:0] rd(input logic [31:0] a);
    rd = mem[(a - BASE) >> 2];
  endfunction

  logic [31:0] q_data [QD];
  logic        q_err  [QD];
  logic [63:0] q_t    [QD];
  int          q_rd, q_wr, q_n;
  logic [63:0] now, last_t;
  logic        rdy_q;

  assign req_ready = rdy_q && (q_n < QD);
  assign rsp_valid = (q_n > 0) && (q_t[q_rd] <= now);
  assign rsp_rdata = rsp_valid ? q_data[q_rd] : 32'd0;
  assign rsp_error = rsp_valid ? q_err[q_rd] : 1'b0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_rd   <= 0;
      q_wr   <= 0;
      q_n    <= 0;
      now    <= 0;
      last_t <= 0;
      rdy_q  <= 1'b0;
      n_acc  <= 0;
    end else begin
      int     n;
      logic [63:0] t;
      n     = q_n;
      now   <= now + 1;
      rdy_q <= ($urandom % 100) >= stall_pct;
      if (rsp_valid && rsp_ready) begin
        q_rd <= (q_rd + 1) % QD;
        n    = n - 1;
      end
      if (req_valid && req_ready) begin
        logic e;
        logic [31:0] w;
        e = (req_addr >= ERR_LO && req_addr < ERR_HI) || (WORD_ONLY != 0 && req_write && req_wstrb != 4'hF) ||
            (req_addr < BASE) || (req_addr >= LIMIT) || (req_addr >= dyn_lo && req_addr < dyn_hi);
        t = now + 64'(LAT) + ((jitter != 0) ? 64'($urandom % (jitter + 1)) : 64'd0);
        if (t <= last_t) t = last_t + 1;                // in order
        last_t <= t;
        q_t[q_wr]    <= t;
        q_err[q_wr]  <= e;
        q_data[q_wr] <= (e || req_write) ? 32'd0 : rd(req_addr);
        if (req_write && !e) begin
          w = rd(req_addr);
          for (int b = 0; b < 4; b++) if (req_wstrb[b]) w[b*8 +: 8] = req_wdata[b*8 +: 8];
          mem[(req_addr - BASE) >> 2] = w;
        end
        q_wr  <= (q_wr + 1) % QD;
        n     = n + 1;
        n_acc <= n_acc + 1;
      end
      q_n <= n;
    end
  end
endmodule

`default_nettype wire
