// =============================================================================
// SilicaFlux-HPC MemoryCore :: tb_sfmem_trace -- MemoryLab / BandwidthLab stimulus harness
//
// Executes a MemoryLab bankbench stimulus file (memorylab.bankbench.write_stimulus) on the shared SRAM through
// all six requester ports of silicaflux_memory_subsystem, with exactly the bankbench driving rule:
//   master m presents request i in the first cycle c >= not_before(i) strictly after the acceptance cycle of
//   request i-1 (valid held until accepted);  rsp_ready(m, c) = backpressure_ready(seed, pct, m, c)
// (the same 32-bit hash as memorylab/bankbench.py).  Word address w -> byte address SRAM_BASE + 4 w.
// Logs (+log=FILE):  A <cycle> <m> <rid>  and  R <cycle> <m> <rid> <rdata> <err> <we>  and  C <cycle> <m>
// (bank-conflict stall), for scripts/bwlab_compare.py.  Cycle 0 = first cycle a request may be presented.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`ifndef SRAM_BANKS
  `define SRAM_BANKS 8
`endif
`ifndef SRAM_RD_LAT
  `define SRAM_RD_LAT 1
`endif
`ifndef SRAM_ARB
  `define SRAM_ARB 0
`endif

module tb_sfmem_trace;
  localparam int NM = 6, MAXR = 20000;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic             ev, ew, vv, vw, iv, iw, irq, busy;
  logic [31:0]      ea, ed, va, vd, ia, id;
  logic [3:0]       es, vs, is_;
  logic             er_r, vr_r, ir_r;
  logic [8*36-1:0]  str;
  logic [2*36-1:0]  ltr;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_memory_subsystem #(.SRAM_BANKS(`SRAM_BANKS), .SRAM_RD_LAT(`SRAM_RD_LAT), .SRAM_ARB(`SRAM_ARB),
                                .ECC_MODE(1)) u_dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .ext_req_valid(ev), .ext_req_ready(1'b1), .ext_req_write(ew), .ext_req_addr(ea), .ext_req_wdata(ed),
    .ext_req_wstrb(es), .ext_rsp_valid(1'b0), .ext_rsp_ready(er_r), .ext_rsp_rdata(32'd0), .ext_rsp_error(1'b0),
    .vs_req_valid(vv), .vs_req_ready(1'b1), .vs_req_write(vw), .vs_req_addr(va), .vs_req_wdata(vd),
    .vs_req_wstrb(vs), .vs_rsp_valid(1'b0), .vs_rsp_ready(vr_r), .vs_rsp_rdata(32'd0), .vs_rsp_error(1'b0),
    .io_req_valid(iv), .io_req_ready(1'b1), .io_req_write(iw), .io_req_addr(ia), .io_req_wdata(id),
    .io_req_wstrb(is_), .io_rsp_valid(1'b0), .io_rsp_ready(ir_r), .io_rsp_rdata(32'd0), .io_rsp_error(1'b0),
    .irq(irq),
    .sram_tst_active(1'b0), .sram_tst_sel('0), .sram_tst_ce(1'b0), .sram_tst_we(1'b0), .sram_tst_addr('0),
    .sram_tst_wdata('0), .sram_tst_rdata(str),
    .lmem_tst_active(1'b0), .lmem_tst_sel('0), .lmem_tst_ce(1'b0), .lmem_tst_we(1'b0), .lmem_tst_addr('0),
    .lmem_tst_wdata('0), .lmem_tst_rdata(ltr), .busy(busy)
  );

  // zero-initialised arrays with valid parity (MemoryLab's model starts from zero)
  localparam int SRAW = $clog2(sfmem_map_pkg::SRAM_BYTES / 4 / `SRAM_BANKS);
  for (genvar b = 0; b < `SRAM_BANKS; b++) begin : g_init
    initial for (int r = 0; r < (1 << SRAW); r++)
      u_dut.u_sram.u_bc.g_bank[b].u_bank.g_generic.u_mem.mem[r] = {4{1'b1, 8'h00}};
  end

  // ------------------------------------------------------------ stimulus
  int          n [NM];
  int          nb [NM*MAXR];
  logic        we [NM*MAXR];
  logic [31:0] wa [NM*MAXR];
  logic [31:0] wd [NM*MAXR];
  logic [3:0]  wm [NM*MAXR];
  logic [15:0] rid [NM*MAXR];
  int          bp_pct, seed, lf;

  function automatic logic bp_ready(input int m, input int c);
    logic [31:0] h;
    if (bp_pct <= 0) bp_ready = 1'b1;
    else begin
      h = 32'(c) * 32'd2654435761 + 32'(m) * 32'd40503 + 32'(seed) * 32'd97 + 32'd12345;
      h = h ^ (h >> 15);
      h = h * 32'd2246822519;
      h = h ^ (h >> 13);
      bp_ready = (h % 100) >= 32'(bp_pct);
    end
  endfunction

  initial begin
    string fn, lfn;
    int f, r, nm_, mx, m, cnt;
    int a, b, d, e, g, hh;
    if (!$value$plusargs("stim=%s", fn)) $fatal(1, "+stim=FILE required");
    if (!$value$plusargs("log=%s", lfn)) lfn = "trace.log";
    if (!$value$plusargs("bp=%d", bp_pct)) bp_pct = 0;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    for (int k = 0; k < NM; k++) n[k] = 0;
    f = $fopen(fn, "r");
    r = $fscanf(f, "%d %d\n", nm_, mx);
    if (nm_ != NM || mx > MAXR) $fatal(1, "stimulus has %0d masters / %0d requests", nm_, mx);
    for (int k = 0; k < NM; k++) begin
      r = $fscanf(f, "M %d %d\n", m, cnt);
      n[m] = cnt;
      for (int i = 0; i < cnt; i++) begin
        r = $fscanf(f, "%d %d %h %h %h %h\n", a, b, d, e, g, hh);
        nb[m*MAXR + i] = a; we[m*MAXR + i] = b[0]; wa[m*MAXR + i] = sfmem_map_pkg::SRAM_BASE + 32'(d) * 4;
        wd[m*MAXR + i] = 32'(e); wm[m*MAXR + i] = 4'(g); rid[m*MAXR + i] = 16'(hh);
      end
    end
    $fclose(f);
    lf = $fopen(lfn, "w");
  end

  // ------------------------------------------------------------ drivers (cycle 0 = first eligible cycle)
  int cyc, idx [NM], q_rid [NM*64], q_w [NM], q_r [NM];
  logic [NM-1:0] dn;
  logic run;
  always_comb begin
    for (int m = 0; m < NM; m++) begin
      int i;
      i = idx[m];
      m_req_valid[m] = run && (i < n[m]) && (cyc >= nb[m*MAXR + i]);
      m_req_write[m] = (i < n[m]) ? we[m*MAXR + i] : 1'b0;
      m_req_addr[m*32 +: 32]  = (i < n[m]) ? wa[m*MAXR + i] : 32'd0;
      m_req_wdata[m*32 +: 32] = (i < n[m]) ? wd[m*MAXR + i] : 32'd0;
      m_req_wstrb[m*4 +: 4]   = (i < n[m] && we[m*MAXR + i]) ? wm[m*MAXR + i] : 4'd0;
      m_rsp_ready[m] = bp_ready(m, cyc);
      dn[m] = (i >= n[m]) && (q_w[m] == q_r[m]);
    end
  end
  always @(posedge clk) begin
    if (!run) begin
      cyc <= 0;
      for (int m = 0; m < NM; m++) begin idx[m] <= 0; q_w[m] <= 0; q_r[m] <= 0; end
    end else begin
      cyc <= cyc + 1;
      for (int m = 0; m < NM; m++) begin
        if (u_dut.u_sram.ev_conf[m]) $fdisplay(lf, "C %0d %0d", cyc, m);
        if (m_req_valid[m] && m_req_ready[m]) begin
          $fdisplay(lf, "A %0d %0d %0d", cyc, m, rid[m*MAXR + idx[m]]);
          q_rid[m*64 + (q_w[m] % 64)] = rid[m*MAXR + idx[m]];
          q_w[m] <= q_w[m] + 1;
          idx[m] <= idx[m] + 1;
        end
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          $fdisplay(lf, "R %0d %0d %0d %0h %0d", cyc, m, q_rid[m*64 + (q_r[m] % 64)], m_rsp_rdata[m*32 +: 32],
                    m_rsp_error[m]);
          q_r[m] <= q_r[m] + 1;
        end
      end
    end
  end
  initial begin
    run = 1'b0;
    repeat (4) @(posedge clk);
    rst_n = 1'b1;
    repeat (3) @(posedge clk);
    @(negedge clk) run = 1'b1;
    while (!(&dn) && cyc < 2000000) @(posedge clk);
    repeat (2) @(posedge clk);
    $fdisplay(lf, "END %0d", cyc);
    $fclose(lf);
    $display("RESULT: DONE (%0d cycles)", cyc);
    $finish;
  end
endmodule

`default_nettype wire
