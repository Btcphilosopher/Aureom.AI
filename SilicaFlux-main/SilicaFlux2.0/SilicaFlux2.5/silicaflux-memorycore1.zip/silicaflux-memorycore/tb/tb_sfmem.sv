// =============================================================================
// SilicaFlux-HPC MemoryCore :: tb_sfmem -- subsystem testbench (Icarus 12 / Verilator 5.020)
//
//   six sfmem_tb_master requesters (programs from model/gen_tests.py, expected
//   values computed by the Python reference model model/sfmem_ref.py)
//        |  SFB2 protocol checker on every requester and downstream port
//   silicaflux_memory_subsystem (parameters from `defines, see scripts/run_tests.py)
//        |
//   sfmem_tb_slave models: EXT (latency / jitter / stalls / error window),
//   VSPM (host window), MMIO (word-only register pages, page 31 unmapped)
//
// Independent checks besides the program expectations:
//   * serialization scoreboard: every SRAM / LMEM read answered OK by a requester
//     port must return, byte for byte, the memory state after every write accepted
//     in an EARLIER cycle (shadow updated at acceptance, reads sampled before the
//     writes of their own cycle).  This is the per-location ordering contract of
//     docs/03_CONSISTENCY.md §2, checked on all traffic incl. cache refills;
//   * responses in order per port, no unsolicited / dropped responses (checkers);
//   * a watchdog.
// Plusargs: +prog=DIR +seed=N +gap=% +stall=% +slv_stall=% +ext_lat=N +jitter=N
//           +timeout=N +reset_at=CYCLE (pulse reset once; programs restart)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

`ifndef SRAM_BANKS
  `define SRAM_BANKS 8
`endif
`ifndef SRAM_RD_LAT
  `define SRAM_RD_LAT 1
`endif
`ifndef ECC_MODE
  `define ECC_MODE 1
`endif
`ifndef DCACHE_EN
  `define DCACHE_EN 1
`endif
`ifndef ICACHE_EN
  `define ICACHE_EN 1
`endif
`ifndef DCACHE_WB
  `define DCACHE_WB 1
`endif
`ifndef CACHE_LINE
  `define CACHE_LINE 16
`endif
`ifndef CACHE_SETS
  `define CACHE_SETS 64
`endif
`ifndef CACHE_WAYS
  `define CACHE_WAYS 2
`endif
`ifndef EXT_LAT
  `define EXT_LAT 8
`endif
`ifndef MAX_OUT
  `define MAX_OUT 4
`endif
`ifndef SRAM_ARB
  `define SRAM_ARB 0
`endif

module tb_sfmem;
  localparam int NM = 6;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------ configuration
  logic [31:0] gap, stall, slv_stall, jitter, ext_lat_cfg;
  longint      timeout, reset_at;
  int          seed;
  initial begin
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("gap=%d", gap)) gap = 0;
    if (!$value$plusargs("stall=%d", stall)) stall = 0;
    if (!$value$plusargs("slv_stall=%d", slv_stall)) slv_stall = 0;
    if (!$value$plusargs("jitter=%d", jitter)) jitter = 0;
    if (!$value$plusargs("timeout=%d", timeout)) timeout = 2000000;
    if (!$value$plusargs("reset_at=%d", reset_at)) reset_at = 0;
    void'($urandom(seed));
  end

  // ------------------------------------------------------------ requesters
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb;
  logic [31:0]      bar_at [NM];
  logic [NM-1:0]    done;
  int               n_err [NM], n_ops [NM], n_rd [NM], n_wr [NM];
  logic [31:0]      bar_all;
  always_comb begin
    bar_all = 32'h7FFF_FFFF;
    for (int m = 0; m < NM; m++) if (bar_at[m] < bar_all) bar_all = bar_at[m];
  end

  for (genvar m = 0; m < NM; m++) begin : g_m
    sfmem_tb_master #(.IDX(m), .OUT(4)) u_m (
      .clk(clk), .rst_n(rst_n),
      .req_valid(m_req_valid[m]), .req_ready(m_req_ready[m]), .req_write(m_req_write[m]),
      .req_addr(m_req_addr[m*32 +: 32]), .req_wdata(m_req_wdata[m*32 +: 32]), .req_wstrb(m_req_wstrb[m*4 +: 4]),
      .rsp_valid(m_rsp_valid[m]), .rsp_ready(m_rsp_ready[m]), .rsp_rdata(m_rsp_rdata[m*32 +: 32]),
      .rsp_error(m_rsp_error[m]),
      .gap_pct(gap), .stall_pct(stall), .barrier_all(bar_all), .barrier_at(bar_at[m]), .done(done[m]),
      .n_err(n_err[m]), .n_ops(n_ops[m]), .n_rd(n_rd[m]), .n_wr(n_wr[m])
    );
  end

  // ------------------------------------------------------------ downstream models
  logic        ext_req_valid, ext_req_ready, ext_req_write, ext_rsp_valid, ext_rsp_ready, ext_rsp_error;
  logic [31:0] ext_req_addr, ext_req_wdata, ext_rsp_rdata;
  logic [3:0]  ext_req_wstrb;
  logic        vs_req_valid, vs_req_ready, vs_req_write, vs_rsp_valid, vs_rsp_ready, vs_rsp_error;
  logic [31:0] vs_req_addr, vs_req_wdata, vs_rsp_rdata;
  logic [3:0]  vs_req_wstrb;
  logic        io_req_valid, io_req_ready, io_req_write, io_rsp_valid, io_rsp_ready, io_rsp_error;
  logic [31:0] io_req_addr, io_req_wdata, io_rsp_rdata;
  logic [3:0]  io_req_wstrb;
  int          ext_n, vs_n, io_n;
  // testbench control page (MMIO page 30): +0 / +4 = run-time EXT error window [lo, hi) for write-back tests
  logic [31:0] ext_dyn_lo, ext_dyn_hi;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ext_dyn_lo <= 32'd0;
      ext_dyn_hi <= 32'd0;
    end else if (io_req_valid && io_req_ready && io_req_write && io_req_wstrb == 4'hF) begin
      if (io_req_addr == 32'h4001_E000) ext_dyn_lo <= io_req_wdata;
      if (io_req_addr == 32'h4001_E004) ext_dyn_hi <= io_req_wdata;
    end
  end
  logic        irq, busy;

  sfmem_tb_slave #(.LAT(`EXT_LAT), .QD(8), .ERR_LO(32'h8F00_0000), .ERR_HI(32'h8F00_1000), .BASE(32'h8000_0000),
                   .WORDS(262144), .NAME("ext")) u_ext (
    .clk(clk), .rst_n(rst_n), .stall_pct(slv_stall), .jitter(jitter), .dyn_lo(ext_dyn_lo), .dyn_hi(ext_dyn_hi),
    .req_valid(ext_req_valid), .req_ready(ext_req_ready), .req_write(ext_req_write), .req_addr(ext_req_addr),
    .req_wdata(ext_req_wdata), .req_wstrb(ext_req_wstrb), .rsp_valid(ext_rsp_valid), .rsp_ready(ext_rsp_ready),
    .rsp_rdata(ext_rsp_rdata), .rsp_error(ext_rsp_error), .n_acc(ext_n));
  sfmem_tb_slave #(.LAT(2), .QD(4), .BASE(32'h6000_0000), .WORDS(16384), .NAME("vspm")) u_vs (
    .clk(clk), .rst_n(rst_n), .stall_pct(slv_stall), .jitter(32'd0), .dyn_lo(32'd0), .dyn_hi(32'd0),
    .req_valid(vs_req_valid), .req_ready(vs_req_ready), .req_write(vs_req_write), .req_addr(vs_req_addr),
    .req_wdata(vs_req_wdata), .req_wstrb(vs_req_wstrb), .rsp_valid(vs_rsp_valid), .rsp_ready(vs_rsp_ready),
    .rsp_rdata(vs_rsp_rdata), .rsp_error(vs_rsp_error), .n_acc(vs_n));
  sfmem_tb_slave #(.LAT(1), .QD(2), .ERR_LO(32'h4001_F000), .ERR_HI(32'h4002_0000), .WORD_ONLY(1), .BASE(32'h4000_0000),
                   .WORDS(32768), .NAME("mmio")) u_io (
    .clk(clk), .rst_n(rst_n), .stall_pct(slv_stall), .jitter(32'd0), .dyn_lo(32'd0), .dyn_hi(32'd0),
    .req_valid(io_req_valid), .req_ready(io_req_ready), .req_write(io_req_write), .req_addr(io_req_addr),
    .req_wdata(io_req_wdata), .req_wstrb(io_req_wstrb), .rsp_valid(io_rsp_valid), .rsp_ready(io_rsp_ready),
    .rsp_rdata(io_rsp_rdata), .rsp_error(io_rsp_error), .n_acc(io_n));

  // ------------------------------------------------------------ DUT
  localparam int SW = (`ECC_MODE == 1) ? 36 : 32;
  localparam int SRAW = $clog2(sfmem_map_pkg::SRAM_BYTES / 4 / `SRAM_BANKS);
  localparam int LRAW = $clog2(sfmem_map_pkg::LMEM_BYTES / 4 / sfmem_map_pkg::LMEM_BANKS);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [`SRAM_BANKS*SW-1:0] s_tst_rdata;
  logic [sfmem_map_pkg::LMEM_BANKS*SW-1:0] l_tst_rdata;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_memory_subsystem #(
    .SRAM_BANKS(`SRAM_BANKS), .SRAM_RD_LAT(`SRAM_RD_LAT), .SRAM_ARB(`SRAM_ARB), .ECC_MODE(`ECC_MODE),
    .DCACHE_EN(`DCACHE_EN), .ICACHE_EN(`ICACHE_EN), .DCACHE_WB(`DCACHE_WB),
    .CACHE_LINE(`CACHE_LINE), .CACHE_SETS(`CACHE_SETS), .CACHE_WAYS(`CACHE_WAYS), .MAX_OUT(`MAX_OUT)
  ) u_dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .ext_req_valid(ext_req_valid), .ext_req_ready(ext_req_ready), .ext_req_write(ext_req_write),
    .ext_req_addr(ext_req_addr), .ext_req_wdata(ext_req_wdata), .ext_req_wstrb(ext_req_wstrb),
    .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(ext_rsp_ready), .ext_rsp_rdata(ext_rsp_rdata),
    .ext_rsp_error(ext_rsp_error),
    .vs_req_valid(vs_req_valid), .vs_req_ready(vs_req_ready), .vs_req_write(vs_req_write), .vs_req_addr(vs_req_addr),
    .vs_req_wdata(vs_req_wdata), .vs_req_wstrb(vs_req_wstrb), .vs_rsp_valid(vs_rsp_valid), .vs_rsp_ready(vs_rsp_ready),
    .vs_rsp_rdata(vs_rsp_rdata), .vs_rsp_error(vs_rsp_error),
    .io_req_valid(io_req_valid), .io_req_ready(io_req_ready), .io_req_write(io_req_write), .io_req_addr(io_req_addr),
    .io_req_wdata(io_req_wdata), .io_req_wstrb(io_req_wstrb), .io_rsp_valid(io_rsp_valid), .io_rsp_ready(io_rsp_ready),
    .io_rsp_rdata(io_rsp_rdata), .io_rsp_error(io_rsp_error),
    .irq(irq),
    .sram_tst_active(1'b0), .sram_tst_sel('0), .sram_tst_ce(1'b0), .sram_tst_we(1'b0), .sram_tst_addr('0),
    .sram_tst_wdata('0), .sram_tst_rdata(s_tst_rdata),
    .lmem_tst_active(1'b0), .lmem_tst_sel('0), .lmem_tst_ce(1'b0), .lmem_tst_we(1'b0), .lmem_tst_addr('0),
    .lmem_tst_wdata('0), .lmem_tst_rdata(l_tst_rdata), .busy(busy)
  );

  // ------------------------------------------------------------ backdoor initialisation (content = f(addr))
  function automatic logic [31:0] init_word(input logic [31:0] a);
    init_word = ({a[31:2], 2'b00} * 32'h9E37_79B1) ^ 32'hA5A5_A5A5;
  endfunction
  function automatic logic [SW-1:0] enc(input logic [31:0] d);
    logic [35:0] r;
    for (int l = 0; l < 4; l++) r[l*9 +: 9] = {~^d[l*8 +: 8], d[l*8 +: 8]};
    enc = (SW == 36) ? SW'(r) : SW'(d);
  endfunction
  for (genvar b = 0; b < `SRAM_BANKS; b++) begin : g_si
    initial begin
      for (int r = 0; r < (1 << SRAW); r++)
        u_dut.u_sram.u_bc.g_bank[b].u_bank.g_generic.u_mem.mem[r] =
          enc(init_word(sfmem_map_pkg::SRAM_BASE + 32'((r * `SRAM_BANKS + b) * 4)));
    end
  end
  for (genvar b = 0; b < sfmem_map_pkg::LMEM_BANKS; b++) begin : g_li
    initial begin
      for (int r = 0; r < (1 << LRAW); r++)
        u_dut.u_lmem.u_bc.g_bank[b].u_bank.g_generic.u_mem.mem[r] =
          enc(init_word(sfmem_map_pkg::LMEM_BASE + 32'((r * sfmem_map_pkg::LMEM_BANKS + b) * 4)));
    end
  end

  // ------------------------------------------------------------ SFB2 protocol checkers
  logic [31:0] viol [NM+3];
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] c_nreq [NM+3], c_nrsp [NM+3], c_out [NM+3];
  /* verilator lint_on UNUSEDSIGNAL */
  for (genvar m = 0; m < NM; m++) begin : g_chk
    sfb_protocol_checker #(.MAX_OUT(4), .NAME("requester")) u_chk (
      .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid[m]), .req_ready(m_req_ready[m]), .req_write(m_req_write[m]),
      .req_addr(m_req_addr[m*32 +: 32]), .req_wdata(m_req_wdata[m*32 +: 32]), .req_wstrb(m_req_wstrb[m*4 +: 4]),
      .rsp_valid(m_rsp_valid[m]), .rsp_ready(m_rsp_ready[m]), .rsp_rdata(m_rsp_rdata[m*32 +: 32]),
      .rsp_error(m_rsp_error[m]), .violations(viol[m]), .n_req(c_nreq[m]), .n_rsp(c_nrsp[m]), .outstanding(c_out[m]));
  end
  sfb_protocol_checker #(.MAX_OUT(8), .NAME("ext")) u_chk_ext (
    .clk(clk), .rst_n(rst_n), .req_valid(ext_req_valid), .req_ready(ext_req_ready), .req_write(ext_req_write),
    .req_addr(ext_req_addr), .req_wdata(ext_req_wdata), .req_wstrb(ext_req_wstrb), .rsp_valid(ext_rsp_valid),
    .rsp_ready(ext_rsp_ready), .rsp_rdata(ext_rsp_rdata), .rsp_error(ext_rsp_error), .violations(viol[NM]),
    .n_req(c_nreq[NM]), .n_rsp(c_nrsp[NM]), .outstanding(c_out[NM]));
  sfb_protocol_checker #(.MAX_OUT(4), .NAME("vspm")) u_chk_vs (
    .clk(clk), .rst_n(rst_n), .req_valid(vs_req_valid), .req_ready(vs_req_ready), .req_write(vs_req_write),
    .req_addr(vs_req_addr), .req_wdata(vs_req_wdata), .req_wstrb(vs_req_wstrb), .rsp_valid(vs_rsp_valid),
    .rsp_ready(vs_rsp_ready), .rsp_rdata(vs_rsp_rdata), .rsp_error(vs_rsp_error), .violations(viol[NM+1]),
    .n_req(c_nreq[NM+1]), .n_rsp(c_nrsp[NM+1]), .outstanding(c_out[NM+1]));
  sfb_protocol_checker #(.MAX_OUT(2), .NAME("mmio")) u_chk_io (
    .clk(clk), .rst_n(rst_n), .req_valid(io_req_valid), .req_ready(io_req_ready), .req_write(io_req_write),
    .req_addr(io_req_addr), .req_wdata(io_req_wdata), .req_wstrb(io_req_wstrb), .rsp_valid(io_rsp_valid),
    .rsp_ready(io_rsp_ready), .rsp_rdata(io_rsp_rdata), .rsp_error(io_rsp_error), .violations(viol[NM+2]),
    .n_req(c_nreq[NM+2]), .n_rsp(c_nrsp[NM+2]), .outstanding(c_out[NM+2]));

  // ------------------------------------------------------------ serialization scoreboard (port level)
  logic [NM-1:0]    pv, pr, pw, rv, rr, re;
  logic [NM*32-1:0] pa, pd, rd;
  logic [NM*4-1:0]  ps;
  for (genvar m = 0; m < NM; m++) begin : g_tap
    assign pv[m] = u_dut.g_port[m].u_port.s_req_valid;
    assign pr[m] = u_dut.g_port[m].u_port.s_req_ready;
    assign pw[m] = u_dut.g_port[m].u_port.s_req_write;
    assign pa[m*32 +: 32] = u_dut.g_port[m].u_port.s_req_addr;
    assign pd[m*32 +: 32] = u_dut.g_port[m].u_port.s_req_wdata;
    assign ps[m*4 +: 4]   = u_dut.g_port[m].u_port.s_req_wstrb;
    assign rv[m] = u_dut.g_port[m].u_port.s_rsp_valid;
    assign rr[m] = u_dut.g_port[m].u_port.s_rsp_ready;
    assign re[m] = u_dut.g_port[m].u_port.s_rsp_error;
    assign rd[m*32 +: 32] = u_dut.g_port[m].u_port.s_rsp_rdata;
  end

  localparam int SWORDS = sfmem_map_pkg::SRAM_BYTES / 4;
  localparam int LWORDS = sfmem_map_pkg::LMEM_BYTES / 4;
  localparam int EQ     = 64;                          // > max outstanding per port
  logic [31:0] sh_s [SWORDS];
  logic [31:0] sh_l [LWORDS];
  logic [32:0] expq [NM*EQ];
  int          eq_rd [NM], eq_wr [NM], eq_n [NM];
  longint      sb_checked, sb_err;
  initial begin
    for (int i = 0; i < SWORDS; i++) sh_s[i] = init_word(sfmem_map_pkg::SRAM_BASE + 32'(i * 4));
    for (int i = 0; i < LWORDS; i++) sh_l[i] = init_word(sfmem_map_pkg::LMEM_BASE + 32'(i * 4));
    for (int m = 0; m < NM; m++) begin eq_rd[m] = 0; eq_wr[m] = 0; eq_n[m] = 0; end
  end

  function automatic logic banked_ok(input int m, input logic [31:0] a);
    logic in_s, in_l;
    in_s = (a & sfmem_map_pkg::SRAM_MASK) == sfmem_map_pkg::SRAM_BASE;
    in_l = (a & sfmem_map_pkg::LMEM_MASK) == sfmem_map_pkg::LMEM_BASE;
    banked_ok = (a[1:0] == 2'b00) &&
                ((in_s && sfmem_map_pkg::ACCESS_EN[m*sfmem_map_pkg::NUM_REGIONS + sfmem_map_pkg::R_SRAM]) ||
                 (in_l && sfmem_map_pkg::ACCESS_EN[m*sfmem_map_pkg::NUM_REGIONS + sfmem_map_pkg::R_LMEM]));
  endfunction
  function automatic logic [31:0] sh_rd(input logic [31:0] a);
    if ((a & sfmem_map_pkg::SRAM_MASK) == sfmem_map_pkg::SRAM_BASE) sh_rd = sh_s[(a - sfmem_map_pkg::SRAM_BASE) >> 2];
    else                                                             sh_rd = sh_l[(a - sfmem_map_pkg::LMEM_BASE) >> 2];
  endfunction
  function automatic void sh_wr(input logic [31:0] a, input logic [31:0] d);
    if ((a & sfmem_map_pkg::SRAM_MASK) == sfmem_map_pkg::SRAM_BASE) sh_s[(a - sfmem_map_pkg::SRAM_BASE) >> 2] = d;
    else                                                             sh_l[(a - sfmem_map_pkg::LMEM_BASE) >> 2] = d;
  endfunction

  always @(posedge clk) begin
    if (!rst_n) begin
      for (int m = 0; m < NM; m++) begin eq_rd[m] = 0; eq_wr[m] = 0; eq_n[m] = 0; end
    end else begin
      // responses
      for (int m = 0; m < NM; m++) begin
        if (rv[m] && rr[m]) begin
          logic [32:0] e;
          if (eq_n[m] == 0) begin
            $display("SCOREBOARD FAIL: port %0d response without request", m);
            sb_err++;
          end else begin
            e = expq[m*EQ + eq_rd[m]];
            eq_rd[m] = (eq_rd[m] + 1) % EQ;
            eq_n[m]  = eq_n[m] - 1;
            if (e[32] && !re[m]) begin
              sb_checked++;
              if (rd[m*32 +: 32] !== e[31:0]) begin
                sb_err++;
                $display("SCOREBOARD FAIL: port %0d read returned %08h, serialization order requires %08h (t=%0t)",
                         m, rd[m*32 +: 32], e[31:0], $time);
              end
            end
          end
        end
      end
      // acceptances: reads see the state before this cycle's writes
      for (int m = 0; m < NM; m++) begin
        if (pv[m] && pr[m]) begin
          expq[m*EQ + eq_wr[m]] = (!pw[m] && banked_ok(m, pa[m*32 +: 32])) ? {1'b1, sh_rd(pa[m*32 +: 32])} : 33'd0;
          eq_wr[m] = (eq_wr[m] + 1) % EQ;
          eq_n[m]  = eq_n[m] + 1;
        end
      end
      for (int m = 0; m < NM; m++) begin
        if (pv[m] && pr[m] && pw[m] && banked_ok(m, pa[m*32 +: 32])) begin
          logic [31:0] w;
          w = sh_rd(pa[m*32 +: 32]);
          for (int b = 0; b < 4; b++) if (ps[m*4 + b]) w[b*8 +: 8] = pd[m*32 + b*8 +: 8];
          sh_wr(pa[m*32 +: 32], w);
        end
      end
    end
  end

  // ------------------------------------------------------------ run control
  longint cyc;
  logic   reset_done;
  initial begin
    sb_checked = 0;
    sb_err     = 0;
    cyc        = 0;
    reset_done = 1'b0;
    rst_n      = 1'b0;
    repeat (5) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
  end
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (reset_at != 0 && !reset_done && cyc == reset_at) begin
      reset_done <= 1'b1;
      $display("[tb] asynchronous reset pulse at cycle %0d (traffic in flight: %0d requests outstanding at the ports)",
               cyc, c_out[0] + c_out[1] + c_out[2] + c_out[3] + c_out[4] + c_out[5]);
      #1 rst_n = 1'b0;
      #23 rst_n = 1'b1;
    end
  end

  always @(posedge clk) begin
    if (rst_n && ((&done) || cyc > timeout)) begin
      int errs, ops, v;
      errs = 0; ops = 0; v = 0;
      repeat (3) @(posedge clk);
      for (int m = 0; m < NM; m++) begin
        errs += n_err[m];
        ops  += n_ops[m];
        $display("[tb] m%0d: %0d ops (%0d R, %0d W), %0d failures, done=%b", m, n_ops[m], n_rd[m], n_wr[m], n_err[m], done[m]);
      end
      for (int k = 0; k < NM + 3; k++) v += viol[k];
      $display("[tb] downstream transactions: ext %0d, vspm %0d, mmio %0d", ext_n, vs_n, io_n);
      $display("[tb] scoreboard: %0d SRAM/LMEM reads checked against the serialization order, %0d failures", sb_checked, sb_err);
      $display("[tb] protocol violations: %0d", v);
      $display("[tb] cycles: %0d", cyc);
      if (cyc > timeout) $display("RESULT: FAIL (timeout after %0d cycles)", cyc);
      else if (errs == 0 && sb_err == 0 && v == 0) $display("RESULT: PASS (%0d ops)", ops);
      else $display("RESULT: FAIL (%0d program failures, %0d scoreboard failures, %0d protocol violations)", errs, sb_err, v);
      $finish;
    end
  end
endmodule

`default_nettype wire
