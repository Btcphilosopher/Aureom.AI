// =============================================================================
// SilicaFlux-HPC MemoryCore :: tb_sfmem_mbist -- MBIST / TestCore integration through the subsystem test ports
//
// The SRAM Wrapper Library's demonstration controller sram_mbist_march (unmodified; same bus as the TestCore
// tc_mbist collar) drives MemoryCore's sram_tst_* port (8 banks in parallel, 36-bit stored words incl. parity)
// and lmem_tst_* port.  Checked:
//   1. March C- passes on every SRAM bank and both LMEM banks (fault-free);
//   2. while tst_active is high no functional request is accepted (a debug-port request waits; it completes after);
//   3. injected stuck-at, transition and address-decoder faults (generic backend hooks) are found in the right bank,
//      at the right row;
//   4. initialisation rule: March leaves a background whose parity lanes are not odd -> a functional read reports
//      PARITY until software scrubs the word (sfmem_scrub) -- MBIST and ECC share one stored-word layout, nothing
//      re-encodes behind the controller's back.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sfmem_mbist;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  localparam int NB = 8, LB = 2, SW = 36;
  localparam int SRAW = $clog2(sfmem_map_pkg::SRAM_BYTES / 4 / NB);
  localparam int LRAW = $clog2(sfmem_map_pkg::LMEM_BYTES / 4 / LB);
  localparam int NM = 6;

  logic [NM-1:0]    m_req_valid = '0, m_req_ready, m_req_write = '0, m_rsp_valid, m_rsp_error;
  logic [NM-1:0]    m_rsp_ready = '1;
  logic [NM*32-1:0] m_req_addr = '0, m_req_wdata = '0, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb = '0;
  /* verilator lint_off UNUSEDSIGNAL */
  logic             ext_req_valid, ext_req_write, vs_req_valid, vs_req_write, io_req_valid, io_req_write, irq, busy;
  logic [31:0]      ext_req_addr, ext_req_wdata, vs_req_addr, vs_req_wdata, io_req_addr, io_req_wdata;
  logic [3:0]       ext_req_wstrb, vs_req_wstrb, io_req_wstrb;
  logic             ext_rsp_ready, vs_rsp_ready, io_rsp_ready;
  /* verilator lint_on UNUSEDSIGNAL */

  // MBIST controllers (unmodified SRAM library)
  logic s_start = 1'b0, l_start = 1'b0;
  logic s_busy, s_done, s_pass, s_fail, l_busy, l_done, l_pass, l_fail;
  logic [NB-1:0] s_fmask;
  logic [LB-1:0] l_fmask;
  logic [2:0] s_ftgt;
  logic [0:0] l_ftgt;
  logic [SRAW-1:0] s_faddr;
  logic [LRAW-1:0] l_faddr;
  logic [2:0] s_felem, l_felem;
  logic [SW-1:0] s_fsyn, l_fsyn;
  logic [15:0] s_fcnt, l_fcnt;
  logic s_ta, s_ce, s_we, l_ta, l_ce, l_we;
  logic [NB-1:0] s_sel;
  logic [LB-1:0] l_sel;
  logic [SRAW-1:0] s_addr;
  logic [LRAW-1:0] l_addr;
  logic [SW-1:0] s_wd, l_wd;
  logic [NB*SW-1:0] s_rd;
  logic [LB*SW-1:0] l_rd;

  sram_mbist_march #(.NUM_TARGETS(NB), .DW(SW), .AW(SRAW), .READ_LATENCY(1),
                     .TARGET_MAXADDR({NB{32'((1 << SRAW) - 1)}}), .TARGET_DW({NB{16'(SW)}})) u_ms (
    .clk(clk), .rst_n(rst_n), .start(s_start), .target_mask({NB{1'b1}}), .bg_checker(1'b0), .stop_on_fail(1'b0),
    .busy(s_busy), .done(s_done), .pass(s_pass), .fail(s_fail), .fail_mask(s_fmask), .fail_target(s_ftgt),
    .fail_addr(s_faddr), .fail_elem(s_felem), .fail_syndrome(s_fsyn), .fail_count(s_fcnt),
    .tst_active(s_ta), .tst_sel(s_sel), .tst_ce(s_ce), .tst_we(s_we), .tst_addr(s_addr), .tst_wdata(s_wd),
    .tst_rdata(s_rd));
  sram_mbist_march #(.NUM_TARGETS(LB), .DW(SW), .AW(LRAW), .READ_LATENCY(1),
                     .TARGET_MAXADDR({LB{32'((1 << LRAW) - 1)}}), .TARGET_DW({LB{16'(SW)}})) u_ml (
    .clk(clk), .rst_n(rst_n), .start(l_start), .target_mask({LB{1'b1}}), .bg_checker(1'b1), .stop_on_fail(1'b0),
    .busy(l_busy), .done(l_done), .pass(l_pass), .fail(l_fail), .fail_mask(l_fmask), .fail_target(l_ftgt),
    .fail_addr(l_faddr), .fail_elem(l_felem), .fail_syndrome(l_fsyn), .fail_count(l_fcnt),
    .tst_active(l_ta), .tst_sel(l_sel), .tst_ce(l_ce), .tst_we(l_we), .tst_addr(l_addr), .tst_wdata(l_wd),
    .tst_rdata(l_rd));

  silicaflux_memory_subsystem #(.ECC_MODE(1), .SRAM_BANKS(NB)) u_dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .ext_req_valid(ext_req_valid), .ext_req_ready(1'b1), .ext_req_write(ext_req_write), .ext_req_addr(ext_req_addr),
    .ext_req_wdata(ext_req_wdata), .ext_req_wstrb(ext_req_wstrb), .ext_rsp_valid(1'b0), .ext_rsp_ready(ext_rsp_ready),
    .ext_rsp_rdata(32'd0), .ext_rsp_error(1'b0),
    .vs_req_valid(vs_req_valid), .vs_req_ready(1'b1), .vs_req_write(vs_req_write), .vs_req_addr(vs_req_addr),
    .vs_req_wdata(vs_req_wdata), .vs_req_wstrb(vs_req_wstrb), .vs_rsp_valid(1'b0), .vs_rsp_ready(vs_rsp_ready),
    .vs_rsp_rdata(32'd0), .vs_rsp_error(1'b0),
    .io_req_valid(io_req_valid), .io_req_ready(1'b1), .io_req_write(io_req_write), .io_req_addr(io_req_addr),
    .io_req_wdata(io_req_wdata), .io_req_wstrb(io_req_wstrb), .io_rsp_valid(1'b0), .io_rsp_ready(io_rsp_ready),
    .io_rsp_rdata(32'd0), .io_rsp_error(1'b0),
    .irq(irq),
    .sram_tst_active(s_ta), .sram_tst_sel(s_sel), .sram_tst_ce(s_ce), .sram_tst_we(s_we), .sram_tst_addr(s_addr),
    .sram_tst_wdata(s_wd), .sram_tst_rdata(s_rd),
    .lmem_tst_active(l_ta), .lmem_tst_sel(l_sel), .lmem_tst_ce(l_ce), .lmem_tst_we(l_we), .lmem_tst_addr(l_addr),
    .lmem_tst_wdata(l_wd), .lmem_tst_rdata(l_rd), .busy(busy)
  );

  int fails = 0, checks = 0;
  task automatic chk(input string what, input logic ok);
    checks++;
    if (!ok) begin fails++; $display("FAIL %s", what); end
    else $display("  ok  %s", what);
  endtask

  // debug-port (m0) single access
  task automatic dbg(input logic wr, input logic [31:0] a, input logic [31:0] wd, output logic [31:0] rd,
                     output logic er, output longint wait_cycles);
    longint t0;
    @(negedge clk);
    m_req_valid[0] = 1'b1; m_req_write[0] = wr; m_req_addr[31:0] = a; m_req_wdata[31:0] = wd;
    m_req_wstrb[3:0] = wr ? 4'hF : 4'h0;
    t0 = $time;
    do @(posedge clk); while (!m_req_ready[0]);
    wait_cycles = ($time - t0) / 10;
    @(negedge clk);
    m_req_valid[0] = 1'b0;
    while (!m_rsp_valid[0]) @(negedge clk);
    rd = m_rsp_rdata[31:0];
    er = m_rsp_error[0];
  endtask

  task automatic run_sram(output logic pass_o);
    @(negedge clk) s_start = 1'b1;
    @(negedge clk) s_start = 1'b0;
    while (!s_done) @(posedge clk);
    pass_o = s_pass;
  endtask

  initial begin
    logic [31:0] rd;
    logic er, p;
    longint w;
    repeat (4) @(posedge clk);
    rst_n = 1'b1;
    repeat (4) @(posedge clk);
    // ------------------------------------------------------------ 1/2: fault-free March C-, functional lock-out
    dbg(1'b1, 32'h1000_0040, 32'hCAFE_0001, rd, er, w);
    fork
      run_sram(p);
      begin
        repeat (50) @(posedge clk);
        dbg(1'b1, 32'h1000_0080, 32'h1234_5678, rd, er, w);     // presented while the test owns the arrays
      end
    join
    chk("SRAM March C- on 8 banks x 8192 x 36 bit: PASS", p && !s_fail);
    chk($sformatf("functional request held off during MBIST (%0d cycles) and completed after", w), w > 1000 && !er);
    // ------------------------------------------------------------ 4: initialisation rule
    dbg(1'b0, 32'h1000_0100, 32'd0, rd, er, w);
    chk("read after MBIST (background word, parity lanes not odd): PARITY error until scrubbed", er);
    dbg(1'b1, 32'h1000_0100, 32'h0000_0000, rd, er, w);
    dbg(1'b0, 32'h1000_0100, 32'd0, rd, er, w);
    chk("after a full-word write (scrub) the word reads back clean", !er && rd == 32'd0);
    dbg(1'b0, 32'h1000_0080, 32'd0, rd, er, w);
    chk("the request held off during MBIST was performed after it", !er && rd == 32'h1234_5678);
    // ------------------------------------------------------------ 3: injected faults
    u_dut.u_sram.u_bc.g_bank[3].u_bank.g_generic.u_mem.flt_kind = 1;      // SA0
    u_dut.u_sram.u_bc.g_bank[3].u_bank.g_generic.u_mem.flt_addr = 100;
    u_dut.u_sram.u_bc.g_bank[3].u_bank.g_generic.u_mem.flt_bit  = 5;
    run_sram(p);
    chk($sformatf("SA0 bank 3 row 100 bit 5 detected: target %0d row %0d syndrome %h", s_ftgt, s_faddr, s_fsyn),
        s_fail && s_fmask == 8'b0000_1000 && s_ftgt == 3'd3 && s_faddr == SRAW'(100) && s_fsyn == 36'h20);
    u_dut.u_sram.u_bc.g_bank[3].u_bank.g_generic.u_mem.flt_kind = 0;
    u_dut.u_sram.u_bc.g_bank[6].u_bank.g_generic.u_mem.flt_kind = 3;      // transition fault 0->1 on a parity bit
    u_dut.u_sram.u_bc.g_bank[6].u_bank.g_generic.u_mem.flt_addr = 8191;
    u_dut.u_sram.u_bc.g_bank[6].u_bank.g_generic.u_mem.flt_bit  = 35;
    run_sram(p);
    chk($sformatf("TF on parity bit 35, bank 6, last row: target %0d row %0d", s_ftgt, s_faddr),
        s_fail && s_ftgt == 3'd6 && s_faddr == SRAW'(8191) && s_fsyn[35]);
    u_dut.u_sram.u_bc.g_bank[6].u_bank.g_generic.u_mem.flt_kind = 0;
    // LMEM: checkerboard background, address-decoder fault
    u_dut.u_lmem.u_bc.g_bank[1].u_bank.g_generic.u_mem.flt_kind  = 6;
    u_dut.u_lmem.u_bc.g_bank[1].u_bank.g_generic.u_mem.flt_addr  = 7;
    u_dut.u_lmem.u_bc.g_bank[1].u_bank.g_generic.u_mem.flt_addr2 = 9;
    @(negedge clk) l_start = 1'b1;
    @(negedge clk) l_start = 1'b0;
    while (!l_done) @(posedge clk);
    chk($sformatf("LMEM address-decoder fault bank 1 row 7->9 detected: target %0d", l_ftgt), l_fail && l_ftgt == 1'b1);
    u_dut.u_lmem.u_bc.g_bank[1].u_bank.g_generic.u_mem.flt_kind = 0;
    @(negedge clk) l_start = 1'b1;
    @(negedge clk) l_start = 1'b0;
    while (!l_done) @(posedge clk);
    chk("LMEM March C- (checkerboard) fault-free: PASS", l_pass);
    $display("[tb] %0d checks, %0d failures", checks, fails);
    if (fails == 0) $display("RESULT: PASS (mbist)");
    else            $display("RESULT: FAIL (mbist)");
    $finish;
  end
endmodule

`default_nettype wire
