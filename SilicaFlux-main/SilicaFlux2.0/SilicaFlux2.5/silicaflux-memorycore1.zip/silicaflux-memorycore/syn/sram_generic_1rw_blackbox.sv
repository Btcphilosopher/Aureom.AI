// Synthesis-only stand-in: the SRAM library's GENERIC 1RW array as a black box (a macro), so logic synthesis of
// MemoryCore counts its logic, not 2.4 Mbit of arrays turned into flip-flops.  Same parameters and ports as
// third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv.
(* blackbox *)
module sram_generic_1rw #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  ce,
  input  wire logic                  we,
  input  wire logic [MASK_WIDTH-1:0] wmask,
  input  wire logic [AW-1:0]         addr,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  output logic      [DATA_WIDTH-1:0] rdata
);
endmodule
