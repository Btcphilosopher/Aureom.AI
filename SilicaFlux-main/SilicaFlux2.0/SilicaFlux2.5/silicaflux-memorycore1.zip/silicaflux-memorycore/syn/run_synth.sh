#!/bin/sh
# Yosys 0.33 generic logic synthesis of silicaflux_memory_subsystem (arrays as black boxes) -> reports/synth/synth_<cfg>.log (summary: reports/synth.md)
set -e
mkdir -p reports/synth
cd "$(dirname "$0")/.."
FILES=$(grep -v '^+' rtl/files.f | grep -v sram_generic_1rw.sv | tr '\n' ' ')
INC="-Irtl -Ithird_party/silicaflux-sramlib/rtl/mem -Ithird_party/silicaflux-sramlib/rtl/mem/backends/asic"
for cfg in "default:" "noperf:chparam -set PERF_EN 0 silicaflux_memory_subsystem;" "icache:chparam -set ICACHE_EN 1 silicaflux_memory_subsystem;" "nocache_noperf:chparam -set DCACHE_EN 0 -set PERF_EN 0 silicaflux_memory_subsystem;"; do
  name=${cfg%%:*}; cp=${cfg#*:}
  yosys -q -l reports/synth/synth_$name.log -p "read_verilog -defer -sv -DSYNTHESIS $INC syn/sram_generic_1rw_blackbox.sv $FILES; $cp hierarchy -check -top silicaflux_memory_subsystem; synth -top silicaflux_memory_subsystem -flatten; check -assert; stat" >/dev/null
  echo "$name: $(grep -m1 'Number of cells' reports/synth/synth_$name.log | tail -1)"
done
python3 syn/summarize.py
