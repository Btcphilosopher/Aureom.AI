#!/usr/bin/env python3
"""reports/synth/synth_<cfg>.log -> reports/synth.md (final `stat` block, latch count, check -assert result)."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CFGS = [("nocache_noperf", "DCACHE_EN = 0, PERF_EN = 0"), ("noperf", "default, PERF_EN = 0"),
        ("default", "default (D-cache, counters)"), ("icache", "default + ICACHE_EN = 1")]
L = ["# MemoryCore generic logic synthesis (Yosys 0.33)", "",
     "`syn/run_synth.sh`: `read_verilog -defer -sv -DSYNTHESIS` of `rtl/files.f` with the SRAM library's GENERIC 1RW "
     "array replaced by a black box (`syn/sram_generic_1rw_blackbox.sv`, i.e. every array is a macro), "
     "`hierarchy -check`, `synth -top silicaflux_memory_subsystem -flatten`, `check -assert`, `stat`. Yosys internal "
     "gate library — no technology mapping, no timing, no area in um^2. Raw logs: `reports/synth/`.", ""]
for n, desc in CFGS:
    p = ROOT / "reports" / "synth" / f"synth_{n}.log"
    if not p.exists():
        continue
    t = p.read_text()
    blk = t[t.rfind("Printing statistics"):]
    blk = blk[blk.find("=== silicaflux_memory_subsystem ==="):]
    lines = [ln.rstrip() for ln in blk.splitlines() if ln.strip()][:40]
    lat = len(re.findall(r"^Latch inferred", t, re.M))
    chk = "Found and reported 0 problems" in t
    L += [f"## {n} ({desc})", "", f"Latches inferred: {lat}; `check -assert`: {'clean' if chk else 'FAILED'}.", "",
          "```"] + lines + ["```", ""]
(ROOT / "reports" / "synth.md").write_text("\n".join(L) + "\n")
print("wrote reports/synth.md")
