// =============================================================================
// SilicaFlux-HPC MemoryCore :: sfmem_hpc_system -- the definition-of-done system
//
// Every block except silicaflux_memory_subsystem is reused UNMODIFIED:
//   ControlCore   SilicaFlux-V sfv_cpu (RV32I_Zicsr), boots from LMEM          -> m1 (i_*), m2 (d_*)
//   system DMA    DataFabric silicaflux_dma (buffered burst engine), page 6     -> m3
//   vector engine HPC Module 08 silicaflux_hpc_tile (FP32/INT32 lanes, Module 04
//                 scratchpad, Module 05 DMA), page 8, scratchpad host window    -> m4 (fab_*), vs_* -> hs_*
//   TensorCore    TENSORCORE 08 silicaflux_tensor_unit (INT8 GEMM), page 9      -> m5
//   register bus  SilicaFlux-V sfv_periph_bridge behind DataFabric sfb_v1_slave_adapter on io_*
//   debug / host  m0 (testbench: firmware loader, host accesses)
//   ext_*         external-memory window (testbench model)
//
//   The tile's scratchpad is placed at the VSPM host window (SPM_BASE = 0x6000_0000), so its internal addresses
//   and the host's addresses are identical (no translation).  The tensor unit's legal window is the shared SRAM
//   plus nothing else (MEM_LO / MEM_HI); MemoryCore's access matrix additionally keeps it out of LMEM, MMIO and
//   the vector scratchpad.
// Classification: SYNTHESIZABLE (integration wiring)
// =============================================================================
`include "sram_defs.svh"
`include "sfmem_defs.svh"
`include "tsu_defs.svh"
`default_nettype none

module sfmem_hpc_system #(
  parameter int DCACHE_EN  = 1,
  parameter int ICACHE_EN  = 0,
  parameter int DCACHE_WB  = 1,
  parameter int ECC_MODE   = `SFMEM_ECC_PARITY,
  parameter int SRAM_BANKS = 8,
  parameter int SRAM_RD_LAT = 1
) (
  input  wire logic        clk,
  input  wire logic        rst_n,          // memory system, engines
  input  wire logic        cpu_rst_n,      // ControlCore (held while the debug port loads LMEM)
  // ---------------------------------------------------------- debug / host port (m0)
  input  wire logic        dbg_req_valid,
  output logic             dbg_req_ready,
  input  wire logic        dbg_req_write,
  input  wire logic [31:0] dbg_req_addr,
  input  wire logic [31:0] dbg_req_wdata,
  input  wire logic [3:0]  dbg_req_wstrb,
  output logic             dbg_rsp_valid,
  input  wire logic        dbg_rsp_ready,
  output logic [31:0]      dbg_rsp_rdata,
  output logic             dbg_rsp_error,
  // ---------------------------------------------------------- external memory
  output logic             ext_req_valid,
  input  wire logic        ext_req_ready,
  output logic             ext_req_write,
  output logic [31:0]      ext_req_addr,
  output logic [31:0]      ext_req_wdata,
  output logic [3:0]       ext_req_wstrb,
  input  wire logic        ext_rsp_valid,
  output logic             ext_rsp_ready,
  input  wire logic [31:0] ext_rsp_rdata,
  input  wire logic        ext_rsp_error,
  // ---------------------------------------------------------- extra register page 15 (testbench console)
  output logic             tbp_sel,
  output logic             tbp_we,
  output logic [11:0]      tbp_addr,
  output logic [31:0]      tbp_wdata,
  input  wire logic [31:0] tbp_rdata,
  input  wire logic        tbp_err,
  // ---------------------------------------------------------- status
  output logic [3:0]       irqs,           // {memctl, tensor, tile, dma}
  output logic             cpu_sleeping
);
  localparam int NM = 6;
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb;

  // ============================================================ m0: debug / host
  assign m_req_valid[0] = dbg_req_valid;   assign dbg_req_ready = m_req_ready[0];
  assign m_req_write[0] = dbg_req_write;   assign m_req_addr[31:0] = dbg_req_addr;
  assign m_req_wdata[31:0] = dbg_req_wdata; assign m_req_wstrb[3:0] = dbg_req_wstrb;
  assign dbg_rsp_valid = m_rsp_valid[0];   assign m_rsp_ready[0] = dbg_rsp_ready;
  assign dbg_rsp_rdata = m_rsp_rdata[31:0]; assign dbg_rsp_error = m_rsp_error[0];

  // ============================================================ ControlCore: SilicaFlux-V sfv_cpu (SFB v1 -> SFB2:
  // req = valid, gnt = ready, rvalid = rsp_valid, response always accepted)
  logic        irq_ext;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        rt_valid, rt_trap, rt_rd_we;
  logic [31:0] rt_pc, rt_insn, rt_cause, rt_rd_wdata;
  logic [4:0]  rt_rd;
  /* verilator lint_on UNUSEDSIGNAL */
  // RESET ISOLATION (integration rule, docs/03 §7 R2): sfv_cpu drives i_req while it is held in reset.  MemoryCore keeps
  // running during that time (the debug port loads LMEM), so an ungated request would be accepted and its response
  // would arrive after the CPU leaves reset -- consumed as the answer to a different fetch.  SFB2 R11 assumes one
  // reset for requesters and fabric; a requester with its own reset must not present requests while in it.
  logic cpu_run_q, i_req_raw, d_req_raw;
  always_ff @(posedge clk or negedge cpu_rst_n) begin
    if (!cpu_rst_n) cpu_run_q <= 1'b0;
    else            cpu_run_q <= 1'b1;
  end
  assign m_req_valid[1] = i_req_raw && cpu_run_q;
  assign m_req_valid[2] = d_req_raw && cpu_run_q;
  sfv_cpu #(.BOOT_ADDR(sfmem_map_pkg::LMEM_BASE)) u_cpu (
    .clk(clk), .rst_n(cpu_rst_n),
    .i_req(i_req_raw), .i_gnt(m_req_ready[1] && cpu_run_q), .i_addr(m_req_addr[63:32]), .i_rvalid(m_rsp_valid[1]),
    .i_rdata(m_rsp_rdata[63:32]), .i_err(m_rsp_error[1]),
    .d_req(d_req_raw), .d_gnt(m_req_ready[2] && cpu_run_q), .d_addr(m_req_addr[95:64]), .d_we(m_req_write[2]),
    .d_be(m_req_wstrb[11:8]), .d_wdata(m_req_wdata[95:64]), .d_rvalid(m_rsp_valid[2]), .d_rdata(m_rsp_rdata[95:64]),
    .d_err(m_rsp_error[2]),
    .irq_ext(irq_ext), .irq_timer(1'b0), .irq_soft(1'b0), .sleeping(cpu_sleeping),
    .rt_valid(rt_valid), .rt_pc(rt_pc), .rt_insn(rt_insn), .rt_trap(rt_trap), .rt_cause(rt_cause), .rt_rd(rt_rd),
    .rt_rd_wdata(rt_rd_wdata), .rt_rd_we(rt_rd_we)
  );
  assign m_req_write[1] = 1'b0;
  assign m_req_wdata[63:32] = 32'd0;
  assign m_req_wstrb[7:4] = 4'd0;
  assign m_rsp_ready[2:1] = 2'b11;

  // ============================================================ register bus (io_* -> SFB v1 -> sfv_periph_bridge)
  logic        io_req_valid, io_req_ready, io_req_write, io_rsp_valid, io_rsp_ready, io_rsp_error;
  logic [31:0] io_req_addr, io_req_wdata, io_rsp_rdata;
  logic [3:0]  io_req_wstrb;
  logic        v1_req, v1_gnt, v1_we, v1_rvalid, v1_err;
  logic [31:0] v1_addr, v1_wdata, v1_rdata;
  logic [3:0]  v1_be;
  sfb_v1_slave_adapter u_io_adapter (
    .clk(clk), .rst_n(rst_n),
    .req_valid(io_req_valid), .req_ready(io_req_ready), .req_write(io_req_write), .req_addr(io_req_addr),
    .req_wdata(io_req_wdata), .req_wstrb(io_req_wstrb), .rsp_valid(io_rsp_valid), .rsp_ready(io_rsp_ready),
    .rsp_rdata(io_rsp_rdata), .rsp_error(io_rsp_error),
    .v1_req(v1_req), .v1_gnt(v1_gnt), .v1_addr(v1_addr), .v1_we(v1_we), .v1_be(v1_be), .v1_wdata(v1_wdata),
    .v1_rvalid(v1_rvalid), .v1_rdata(v1_rdata), .v1_err(v1_err)
  );
  localparam int NPG = 32;
  // pages: 6 DMA, 8 HPC tile, 9 tensor unit, 15 testbench console (MEMCTL, page 10, never leaves MemoryCore)
  localparam logic [31:0] PAGE_EN = (32'd1 << 6) | (32'd1 << 8) | (32'd1 << 9) | (32'd1 << 15);
  logic [NPG-1:0]    rb_sel;
  logic              rb_we;
  logic [11:0]       rb_addr;
  logic [31:0]       rb_wdata;
  logic [NPG*32-1:0] rb_rdata;
  logic [NPG-1:0]    rb_err;
  logic [3*32-1:0]   pg_rdata;           // pages 6, 8, 9 (one driver each)
  logic [2:0]        pg_err;
  sfv_periph_bridge #(.NP(NPG), .PAGE_EN(PAGE_EN)) u_bridge (
    .clk(clk), .rst_n(rst_n), .req(v1_req), .gnt(v1_gnt), .addr(v1_addr), .we(v1_we), .be(v1_be), .wdata(v1_wdata),
    .rvalid(v1_rvalid), .rdata(v1_rdata), .err(v1_err),
    .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata), .rb_err(rb_err)
  );

  // ============================================================ system DMA (DataFabric, unmodified)
  logic        dma_irq;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        dma_busy, dma_done_ev;
  logic [31:0] dma_bytes;
  logic [7:0]  dma_fifo;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_dma #(.DW(32), .ENGINE(1), .FIFO_DEPTH(8), .BURST(8), .MAX_OUT(2), .MAX_LEN_LOG2(20), .PERF(1)) u_dma (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel[6]), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(pg_rdata[0*32 +: 32]),
    .rb_err(pg_err[0]), .irq(dma_irq),
    .m_req_valid(m_req_valid[3]), .m_req_ready(m_req_ready[3]), .m_req_write(m_req_write[3]),
    .m_req_addr(m_req_addr[127:96]), .m_req_wdata(m_req_wdata[127:96]), .m_req_wstrb(m_req_wstrb[15:12]),
    .m_rsp_valid(m_rsp_valid[3]), .m_rsp_ready(m_rsp_ready[3]), .m_rsp_rdata(m_rsp_rdata[127:96]),
    .m_rsp_error(m_rsp_error[3]),
    .busy(dma_busy), .ev_done(dma_done_ev), .bytes_done(dma_bytes), .fifo_level(dma_fifo)
  );

  // ============================================================ vector engine (HPC Module 08 tile, unmodified)
  logic        vs_req_valid, vs_req_ready, vs_req_write, vs_rsp_valid, vs_rsp_ready, vs_rsp_error;
  logic [31:0] vs_req_addr, vs_req_wdata, vs_rsp_rdata;
  logic [3:0]  vs_req_wstrb;
  logic        tile_irq;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        tile_busy, tile_halted;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_hpc_tile #(.SPM_BASE(sfmem_map_pkg::VSPM_BASE), .SCRATCHPAD_BYTES(sfmem_map_pkg::VSPM_BYTES)) u_tile (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel[8]), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(pg_rdata[1*32 +: 32]),
    .rb_err(pg_err[1]),
    .hs_req_valid(vs_req_valid), .hs_req_ready(vs_req_ready), .hs_req_write(vs_req_write), .hs_req_addr(vs_req_addr),
    .hs_req_wdata(vs_req_wdata), .hs_req_wstrb(vs_req_wstrb), .hs_rsp_valid(vs_rsp_valid),
    .hs_rsp_ready(vs_rsp_ready), .hs_rsp_rdata(vs_rsp_rdata), .hs_rsp_error(vs_rsp_error),
    .fab_req_valid(m_req_valid[4]), .fab_req_ready(m_req_ready[4]), .fab_req_write(m_req_write[4]),
    .fab_req_addr(m_req_addr[159:128]), .fab_req_wdata(m_req_wdata[159:128]), .fab_req_wstrb(m_req_wstrb[19:16]),
    .fab_rsp_valid(m_rsp_valid[4]), .fab_rsp_ready(m_rsp_ready[4]), .fab_rsp_rdata(m_rsp_rdata[159:128]),
    .fab_rsp_error(m_rsp_error[4]),
    .irq(tile_irq), .busy(tile_busy), .halted(tile_halted)
  );

  // ============================================================ TensorCore (TENSORCORE 08, unmodified)
  logic        tsu_irq;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        tsu_busy, tsu_halted;
  logic [`TSU_NUM_PC*32-1:0] tsu_ev;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_tensor_unit #(
    .ENABLE_QUANTIZATION(0), .ENABLE_DOUBLE_BUFFERING(1), .MAX_OUT(4),
    .MEM_LO(33'(sfmem_map_pkg::SRAM_BASE)), .MEM_HI(33'(sfmem_map_pkg::SRAM_BASE) + 33'(sfmem_map_pkg::SRAM_BYTES))
  ) u_tsu (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel[9]), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(pg_rdata[2*32 +: 32]),
    .rb_err(pg_err[2]),
    .m_req_valid(m_req_valid[5]), .m_req_ready(m_req_ready[5]), .m_req_write(m_req_write[5]),
    .m_req_addr(m_req_addr[191:160]), .m_req_wdata(m_req_wdata[191:160]), .m_req_wstrb(m_req_wstrb[23:20]),
    .m_rsp_valid(m_rsp_valid[5]), .m_rsp_ready(m_rsp_ready[5]), .m_rsp_rdata(m_rsp_rdata[191:160]),
    .m_rsp_error(m_rsp_error[5]),
    .irq(tsu_irq), .busy(tsu_busy), .halted(tsu_halted), .perf_ev(tsu_ev), .fi_mode(2'd0)
  );

  // testbench console page
  assign tbp_sel   = rb_sel[15];
  assign tbp_we    = rb_we;
  assign tbp_addr  = rb_addr;
  assign tbp_wdata = rb_wdata;
  always_comb begin
    rb_rdata = '0;
    rb_err   = '1;                         // pages not in PAGE_EN are refused by the bridge anyway
    rb_rdata[6*32 +: 32]  = pg_rdata[0*32 +: 32];  rb_err[6]  = pg_err[0];
    rb_rdata[8*32 +: 32]  = pg_rdata[1*32 +: 32];  rb_err[8]  = pg_err[1];
    rb_rdata[9*32 +: 32]  = pg_rdata[2*32 +: 32];  rb_err[9]  = pg_err[2];
    rb_rdata[15*32 +: 32] = tbp_rdata;             rb_err[15] = tbp_err;
  end

  // ============================================================ MemoryCore
  logic memctl_irq;
  /* verilator lint_off UNUSEDSIGNAL */
  logic mem_busy;
  /* verilator lint_on UNUSEDSIGNAL */
  localparam int SW = (ECC_MODE == `SFMEM_ECC_PARITY) ? 36 : 32;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [SRAM_BANKS*SW-1:0] s_tst_rdata;
  logic [sfmem_map_pkg::LMEM_BANKS*SW-1:0] l_tst_rdata;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_memory_subsystem #(
    .DCACHE_EN(DCACHE_EN), .ICACHE_EN(ICACHE_EN), .DCACHE_WB(DCACHE_WB), .ECC_MODE(ECC_MODE),
    .SRAM_BANKS(SRAM_BANKS), .SRAM_RD_LAT(SRAM_RD_LAT)
  ) u_mem (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .ext_req_valid(ext_req_valid), .ext_req_ready(ext_req_ready), .ext_req_write(ext_req_write),
    .ext_req_addr(ext_req_addr), .ext_req_wdata(ext_req_wdata), .ext_req_wstrb(ext_req_wstrb),
    .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(ext_rsp_ready), .ext_rsp_rdata(ext_rsp_rdata),
    .ext_rsp_error(ext_rsp_error),
    .vs_req_valid(vs_req_valid), .vs_req_ready(vs_req_ready), .vs_req_write(vs_req_write), .vs_req_addr(vs_req_addr),
    .vs_req_wdata(vs_req_wdata), .vs_req_wstrb(vs_req_wstrb), .vs_rsp_valid(vs_rsp_valid), .vs_rsp_ready(vs_rsp_ready),
    .vs_rsp_rdata(vs_rsp_rdata), .vs_rsp_error(vs_rsp_error),
    .io_req_valid(io_req_valid), .io_req_ready(io_req_ready), .io_req_write(io_req_write), .io_req_addr(io_req_addr),
    .io_req_wdata(io_req_wdata), .io_req_wstrb(io_req_wstrb), .io_rsp_valid(io_rsp_valid), .io_rsp_ready(io_rsp_ready),
    .io_rsp_rdata(io_rsp_rdata), .io_rsp_error(io_rsp_error),
    .irq(memctl_irq),
    .sram_tst_active(1'b0), .sram_tst_sel('0), .sram_tst_ce(1'b0), .sram_tst_we(1'b0), .sram_tst_addr('0),
    .sram_tst_wdata('0), .sram_tst_rdata(s_tst_rdata),
    .lmem_tst_active(1'b0), .lmem_tst_sel('0), .lmem_tst_ce(1'b0), .lmem_tst_we(1'b0), .lmem_tst_addr('0),
    .lmem_tst_wdata('0), .lmem_tst_rdata(l_tst_rdata), .busy(mem_busy)
  );

  assign irqs    = {memctl_irq, tsu_irq, tile_irq, dma_irq};
  assign irq_ext = |irqs;

endmodule

`default_nettype wire
