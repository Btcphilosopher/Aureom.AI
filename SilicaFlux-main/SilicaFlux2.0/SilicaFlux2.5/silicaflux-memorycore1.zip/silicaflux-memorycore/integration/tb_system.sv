// =============================================================================
// SilicaFlux-HPC MemoryCore :: tb_system -- definition-of-done system testbench
//
// 1. memory system and engines out of reset, ControlCore held in reset;
// 2. the debug / host port (m0) loads the firmware image into LMEM word by word through MemoryCore and reads every
//    word back;
// 3. the ControlCore boots from LMEM and runs integration/firmware/main.c; console page 15 prints its output
//    (+0 PUTC, +4 EXIT, +8 cycle counter);
// 4. SFB2 protocol checkers watch all six requester ports (the CPU instruction port with the documented
//    ISS-017 request-change waiver) and the EXT port.
// Plusargs: +fw=FILE (word hex) +timeout=N +ext_stall=% +ext_lat via `EXT_LAT
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`ifndef DCACHE_WB
  `define DCACHE_WB 1
`endif
`ifndef DCACHE_EN
  `define DCACHE_EN 1
`endif
`ifndef ICACHE_EN
  `define ICACHE_EN 0
`endif
`ifndef EXT_LAT
  `define EXT_LAT 12
`endif

module tb_system;
  logic clk = 1'b0, rst_n = 1'b0, cpu_rst_n = 1'b0;
  always #5 clk = ~clk;

  logic        d_req_valid = 1'b0, d_req_ready, d_req_write = 1'b0, d_rsp_valid, d_rsp_error;
  logic        d_rsp_ready = 1'b1;
  logic [31:0] d_req_addr = 32'd0, d_req_wdata = 32'd0, d_rsp_rdata;
  logic [3:0]  d_req_wstrb = 4'h0;
  logic        ext_req_valid, ext_req_ready, ext_req_write, ext_rsp_valid, ext_rsp_ready, ext_rsp_error;
  logic [31:0] ext_req_addr, ext_req_wdata, ext_rsp_rdata;
  logic [3:0]  ext_req_wstrb;
  logic        tbp_sel, tbp_we, tbp_err;
  logic [11:0] tbp_addr;
  logic [31:0] tbp_wdata, tbp_rdata;
  logic [3:0]  irqs;
  logic        sleeping;
  longint      cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  sfmem_hpc_system #(.DCACHE_EN(`DCACHE_EN), .DCACHE_WB(`DCACHE_WB), .ICACHE_EN(`ICACHE_EN)) u_sys (
    .clk(clk), .rst_n(rst_n), .cpu_rst_n(cpu_rst_n),
    .dbg_req_valid(d_req_valid), .dbg_req_ready(d_req_ready), .dbg_req_write(d_req_write), .dbg_req_addr(d_req_addr),
    .dbg_req_wdata(d_req_wdata), .dbg_req_wstrb(d_req_wstrb), .dbg_rsp_valid(d_rsp_valid), .dbg_rsp_ready(d_rsp_ready),
    .dbg_rsp_rdata(d_rsp_rdata), .dbg_rsp_error(d_rsp_error),
    .ext_req_valid(ext_req_valid), .ext_req_ready(ext_req_ready), .ext_req_write(ext_req_write),
    .ext_req_addr(ext_req_addr), .ext_req_wdata(ext_req_wdata), .ext_req_wstrb(ext_req_wstrb),
    .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(ext_rsp_ready), .ext_rsp_rdata(ext_rsp_rdata),
    .ext_rsp_error(ext_rsp_error),
    .tbp_sel(tbp_sel), .tbp_we(tbp_we), .tbp_addr(tbp_addr), .tbp_wdata(tbp_wdata), .tbp_rdata(tbp_rdata),
    .tbp_err(tbp_err), .irqs(irqs), .cpu_sleeping(sleeping)
  );

  logic [31:0] ext_stall;
  int          ext_n;
  initial if (!$value$plusargs("ext_stall=%d", ext_stall)) ext_stall = 0;
  sfmem_tb_slave #(.LAT(`EXT_LAT), .QD(8), .BASE(32'h8000_0000), .WORDS(262144), .NAME("ext")) u_ext (
    .clk(clk), .rst_n(rst_n), .stall_pct(ext_stall), .jitter(32'd2), .dyn_lo(32'd0), .dyn_hi(32'd0),
    .req_valid(ext_req_valid), .req_ready(ext_req_ready), .req_write(ext_req_write), .req_addr(ext_req_addr),
    .req_wdata(ext_req_wdata), .req_wstrb(ext_req_wstrb), .rsp_valid(ext_rsp_valid), .rsp_ready(ext_rsp_ready),
    .rsp_rdata(ext_rsp_rdata), .rsp_error(ext_rsp_error), .n_acc(ext_n));

  // ------------------------------------------------------------ console page 15 (combinational register bus)
  assign tbp_rdata = (tbp_addr == 12'h008) ? 32'(cyc) : 32'd0;
  assign tbp_err   = 1'b0;
  int exit_code = -1;
  always @(posedge clk) begin
    if (tbp_sel && tbp_we && tbp_addr == 12'h000) $write("%c", tbp_wdata[7:0]);
    if (tbp_sel && tbp_we && tbp_addr == 12'h004) exit_code <= int'(tbp_wdata);
  end

  // ------------------------------------------------------------ protocol checkers on every requester port
  logic [31:0] viol [7];
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] cnr [7], cns [7], cno [7];
  /* verilator lint_on UNUSEDSIGNAL */
  for (genvar m = 0; m < 6; m++) begin : g_chk
    sfb_protocol_checker #(.MAX_OUT(4), .ALLOW_REQ_CHANGE(m == 1 ? 1 : 0), .NAME("requester")) u_chk (
      .clk(clk), .rst_n(m == 1 || m == 2 ? cpu_rst_n : rst_n),
      .req_valid(u_sys.m_req_valid[m]), .req_ready(u_sys.m_req_ready[m]), .req_write(u_sys.m_req_write[m]),
      .req_addr(u_sys.m_req_addr[m*32 +: 32]), .req_wdata(u_sys.m_req_wdata[m*32 +: 32]),
      .req_wstrb(u_sys.m_req_wstrb[m*4 +: 4]), .rsp_valid(u_sys.m_rsp_valid[m]), .rsp_ready(u_sys.m_rsp_ready[m]),
      .rsp_rdata(u_sys.m_rsp_rdata[m*32 +: 32]), .rsp_error(u_sys.m_rsp_error[m]),
      .violations(viol[m]), .n_req(cnr[m]), .n_rsp(cns[m]), .outstanding(cno[m]));
  end
  sfb_protocol_checker #(.MAX_OUT(8), .NAME("ext")) u_chk_ext (
    .clk(clk), .rst_n(rst_n), .req_valid(ext_req_valid), .req_ready(ext_req_ready), .req_write(ext_req_write),
    .req_addr(ext_req_addr), .req_wdata(ext_req_wdata), .req_wstrb(ext_req_wstrb), .rsp_valid(ext_rsp_valid),
    .rsp_ready(ext_rsp_ready), .rsp_rdata(ext_rsp_rdata), .rsp_error(ext_rsp_error), .violations(viol[6]),
    .n_req(cnr[6]), .n_rsp(cns[6]), .outstanding(cno[6]));

`ifdef TRACE_IP
  always @(posedge clk) if (cyc > 13815 && cyc < 13832)
    $display("c%0d ireq=%b gnt=%b addr=%h | rv=%b err=%b | st=%0d byp=%0d dv=%b dr=%b  cpu_rst=%b",
      cyc, u_sys.m_req_valid[1], u_sys.m_req_ready[1], u_sys.m_req_addr[63:32], u_sys.m_rsp_valid[1],
      u_sys.m_rsp_error[1], u_sys.u_mem.g_req[1].g_icache.u_cache.st, u_sys.u_mem.g_req[1].g_icache.u_cache.byp_cnt,
      u_sys.u_mem.g_req[1].g_icache.u_cache.d_rsp_valid, u_sys.u_mem.g_req[1].g_icache.u_cache.d_rsp_ready, cpu_rst_n);
`endif
  // ------------------------------------------------------------ debug-port loader
  localparam int FWMAX = 8192;
  logic [31:0] fw [FWMAX];
  int          fw_n, load_err;
  task automatic dbg_access(input logic wr, input logic [31:0] a, input logic [31:0] wd, output logic [31:0] rd,
                            output logic er);
    @(negedge clk);
    d_req_valid = 1'b1; d_req_write = wr; d_req_addr = a; d_req_wdata = wd; d_req_wstrb = wr ? 4'hF : 4'h0;
    do @(posedge clk); while (!d_req_ready);
    @(negedge clk);
    d_req_valid = 1'b0;
    while (!d_rsp_valid) @(negedge clk);
    rd = d_rsp_rdata;
    er = d_rsp_error;
  endtask

  initial begin
    string fn;
    longint timeout;
    logic [31:0] rd;
    logic        er;
    int          v;
    if (!$value$plusargs("fw=%s", fn)) fn = "build/fw/demo.hex";
    if (!$value$plusargs("timeout=%d", timeout)) timeout = 3000000;
    begin                                     // count words by reading the file (2-state simulators have no X)
      int f, r;
      logic [31:0] w;
      fw_n = 0;
      f = $fopen(fn, "r");
      if (f == 0) $fatal(1, "cannot open firmware image %s", fn);
      while (!$feof(f) && fw_n < FWMAX) begin
        r = $fscanf(f, "%h\n", w);
        if (r == 1) begin fw[fw_n] = w; fw_n++; end
      end
      $fclose(f);
    end
    load_err = 0;
    repeat (5) @(posedge clk);
    rst_n = 1'b1;
    repeat (5) @(posedge clk);
    // the loader initialises ALL of LMEM (image, then zeros): with byte parity every word must be written before
    // it is read (stack bytes, .bss) -- the ControlCore's boot ROM would do the same on silicon
    for (int i = 0; i < sfmem_map_pkg::LMEM_BYTES / 4; i++) begin
      dbg_access(1'b1, sfmem_map_pkg::LMEM_BASE + 32'(4 * i), (i < fw_n) ? fw[i] : 32'd0, rd, er);
      if (er) load_err++;
    end
    for (int i = 0; i < fw_n; i++) begin
      dbg_access(1'b0, sfmem_map_pkg::LMEM_BASE + 32'(4 * i), 32'd0, rd, er);
      if (er || rd !== fw[i]) load_err++;
    end
    $display("[tb] debug port loaded %0d words into LMEM and read them back: %0d errors (cycle %0d)", fw_n, load_err, cyc);
    @(negedge clk) cpu_rst_n = 1'b1;
    while (exit_code < 0 && cyc < timeout) @(posedge clk);
    repeat (5) @(posedge clk);
    v = 0;
    for (int k = 0; k < 7; k++) v += viol[k];
    $display("[tb] firmware exit code %0d at cycle %0d; EXT transactions %0d; SFB2 protocol violations %0d",
             exit_code, cyc, ext_n, v);
    if (exit_code == 0 && load_err == 0 && v == 0) $display("RESULT: PASS (system demo)");
    else $display("RESULT: FAIL (exit %0d, load errors %0d, protocol violations %0d%s)", exit_code, load_err, v,
                  cyc >= timeout ? ", TIMEOUT" : "");
    $finish;
  end
endmodule

`default_nettype wire
