#!/usr/bin/env python3
"""Raw binary -> one 32-bit little-endian word per line (for $readmemh); argv: in.bin out.hex"""
import sys
b = open(sys.argv[1], "rb").read()
b += b"\0" * (-len(b) % 4)
with open(sys.argv[2], "w") as f:
    for i in range(0, len(b), 4):
        f.write(f"{int.from_bytes(b[i:i + 4], 'little'):08x}\n")
print(f"{sys.argv[2]}: {len(b) // 4} words")
