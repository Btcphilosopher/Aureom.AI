/*
 * SilicaFlux-HPC MemoryCore -- definition-of-done firmware (runs on the ControlCore, SilicaFlux-V sfv_cpu).
 * Aureom.AI | SilicaFlux-HPC
 *
 * Demonstrates the memory-consistency contract of docs/03_CONSISTENCY.md on the real RTL of every agent:
 *   T1  CPU -> system DMA -> CPU   (DataFabric DMA, shared SRAM; negative control without CLEAN)
 *   T2  CPU -> TensorCore -> CPU   (INT8 GEMM on the TENSORCORE 08 unit; negative control without INVAL)
 *   T3  TensorCore -> vector engine -> CPU (the tile's KERNEL IADD consumes the GEMM result in place: no CPU
 *       involvement between producer and consumer except the completion record)
 *   T4  explicitly managed vector scratchpad through the host window: VSPM ownership hand-over, a precise bus
 *       error on a host access while the engine owns the partition, VEC IMUL inside the scratchpad
 *   T5  external-memory window: CPU (cached) -> DMA EXT->SRAM -> DMA SRAM->EXT -> CPU
 *   T6  non-cacheable window: the same CPU <-> DMA exchange with no maintenance at all
 * Each step is checked word by word against a reference computed by the CPU; each negative control checks that
 * the hardware really is noncoherent (the stale value is predicted exactly in write-back mode).
 * Exit code (console EXIT) = number of failed checks.
 */
#include <stddef.h>
#include <stdint.h>
#include "sfmem.h"
#include "silicaflux_hpc.h"
#include "tsu_driver.h"

/* ------------------------------------------------------------------------------------------- console */
#define CON_PUTC  (*(volatile uint32_t *)0x4000F000u)
#define CON_CYCLE (*(volatile uint32_t *)0x4000F008u)
#define HPC       0x40008000u
#define DMA_BASE  0x40006000u
#define DMA_REG(o) (*(volatile uint32_t *)(DMA_BASE + (o)))

volatile uint32_t trap_count, trap_last_cause, trap_last_tval;
static int fails, checks;

void *memset(void *d, int c, size_t n) { uint8_t *p = d; while (n--) *p++ = (uint8_t)c; return d; }
void *memcpy(void *d, const void *s, size_t n) { uint8_t *p = d; const uint8_t *q = s; while (n--) *p++ = *q++; return d; }

static void puts_(const char *s) { while (*s) CON_PUTC = (uint32_t)(uint8_t)*s++; }
static void puthex(uint32_t v) { for (int i = 7; i >= 0; i--) CON_PUTC = "0123456789abcdef"[(v >> (4 * i)) & 15u]; }
static void putdec(uint32_t v) { char b[11]; int n = 0; do { b[n++] = (char)('0' + v % 10u); v /= 10u; } while (v); while (n) CON_PUTC = (uint32_t)b[--n]; }
static void check(const char *what, uint32_t got, uint32_t exp)
{
    checks++;
    if (got != exp) {
        fails++;
        puts_("  FAIL "); puts_(what); puts_(": got 0x"); puthex(got); puts_(" expected 0x"); puthex(exp); puts_("\n");
    }
}
static void check_buf(const char *what, const volatile uint32_t *p, const uint32_t *exp, unsigned n)
{
    unsigned bad = 0;
    for (unsigned i = 0; i < n; i++) {
        checks++;
        if (p[i] != exp[i]) {
            if (bad < 3) { puts_("  FAIL "); puts_(what); puts_("["); putdec(i); puts_("]: got 0x"); puthex(p[i]);
                           puts_(" expected 0x"); puthex(exp[i]); puts_("\n"); }
            bad++;
            fails++;
        }
    }
    puts_("  "); puts_(what); puts_(bad ? ": MISMATCH (" : ": ok ("); putdec(n); puts_(" words)\n");
}
static void step(const char *s) { puts_("["); putdec(CON_CYCLE); puts_("] "); puts_(s); puts_("\n"); }

/* ------------------------------------------------------------------------------------------- buffers */
#define SRAM(o)  ((volatile uint32_t *)(SFMEM_SRAM_BASE + (o)))
#define EXTM(o)  ((volatile uint32_t *)(SFMEM_EXT_BASE + (o)))
#define VSPM(o)  ((volatile uint32_t *)(SFMEM_VSPM_BASE + (o)))
#define NW 64u                                   /* words per buffer (256 B, line aligned) */

static uint32_t ref[NW], ref2[NW];

static int dma_copy(uint32_t src, uint32_t dst, uint32_t len)
{
    DMA_REG(0x08) = src;
    DMA_REG(0x0C) = dst;
    DMA_REG(0x10) = len;
    DMA_REG(0x00) = 1u;                          /* START */
    uint32_t st;
    do { st = DMA_REG(0x04); } while (st & 1u);  /* BUSY */
    return (st & 4u) ? -1 : 0;                   /* ERROR */
}

int main(void)
{
    sfmem_info_t inf;
    puts_("MemoryCore system demo: ControlCore + system DMA + vector engine + TensorCore\n");
    check("sfmem_init", (uint32_t)sfmem_init(&inf), 0u);
    const int wb = inf.dcache && inf.write_back;
    sfmem_scrub((void *)SFMEM_SRAM_BASE, 0x8000);                       /* boot-time init (parity), caches off */
    puts_("  D-cache "); puts_(inf.dcache ? (wb ? "write-back" : "write-through") : "absent");
    puts_(", line "); putdec(inf.line_bytes); puts_(" B, "); putdec(inf.sets); puts_(" sets x "); putdec(inf.ways);
    puts_(" ways\n");
    /* EXT is cached after reset (the measured case); the shared SRAM is opt-in.  The demo opts in so that T1-T3
       exercise the maintenance protocol on SRAM buffers as well. */
    check("cache regions", sfmem_cache_regions(SFMEM_REGION_SRAM | SFMEM_REGION_EXT),
          SFMEM_REGION_SRAM | SFMEM_REGION_EXT);
    sfmem_cache_enable(1, 1);
    sfmem_perf_clear();

    /* ===================================================================== T1: CPU -> system DMA -> CPU */
    step("T1 CPU -> system DMA (shared SRAM)");
    volatile uint32_t *src = SRAM(0x1000), *dst = SRAM(0x2000);
    for (unsigned i = 0; i < NW; i++) src[i] = 0x01D00000u | i;          /* "old" content, made visible */
    check("T1 clean(old)", (uint32_t)sfmem_dma_to_device((void *)src, 4 * NW), 0u);
    for (unsigned i = 0; i < NW; i++) { src[i] = 0x5A000000u | i; ref[i] = 0x5A000000u | i; ref2[i] = 0x01D00000u | i; }
    /* negative control: hand the buffer over WITHOUT cleaning it */
    check("T1 begin(dst)", (uint32_t)sfmem_dma_from_device_begin((void *)dst, 4 * NW), 0u);
    check("T1 dma (no clean)", (uint32_t)dma_copy((uint32_t)src, (uint32_t)dst, 4 * NW), 0u);
    check("T1 end(dst)", (uint32_t)sfmem_dma_from_device_end((void *)dst, 4 * NW), 0u);
    check_buf(wb ? "T1 negative control: DMA saw the stale pre-CLEAN data" : "T1 write-through: visible without CLEAN",
              dst, wb ? ref2 : ref, NW);
    /* correct protocol */
    check("T1 to_device(src)", (uint32_t)sfmem_dma_to_device((void *)src, 4 * NW), 0u);
    check("T1 begin(dst)", (uint32_t)sfmem_dma_from_device_begin((void *)dst, 4 * NW), 0u);
    check("T1 dma", (uint32_t)dma_copy((uint32_t)src, (uint32_t)dst, 4 * NW), 0u);
    check("T1 end(dst)", (uint32_t)sfmem_dma_from_device_end((void *)dst, 4 * NW), 0u);
    check_buf("T1 DMA copy after CLEAN", dst, ref, NW);

    /* ===================================================================== T2: CPU -> TensorCore -> CPU */
    step("T2 CPU -> TensorCore INT8 GEMM 8x8x8 -> CPU");
    volatile int8_t *A = (volatile int8_t *)SRAM(0x4000), *B = (volatile int8_t *)SRAM(0x4100);
    volatile uint32_t *C = SRAM(0x4200);
    for (int i = 0; i < 64; i++) { A[i] = (int8_t)(i * 7 - 100); B[i] = (int8_t)(53 - i * 3); }
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++) {
            int32_t s = 0;
            for (int k = 0; k < 8; k++) s += (int32_t)A[i * 8 + k] * (int32_t)B[k * 8 + j];
            ref[i * 8 + j] = (uint32_t)s;
        }
    for (unsigned i = 0; i < NW; i++) C[i] = 0xCCCC0000u | i;           /* old C, cleaned below */
    check("T2 to_device(A)", (uint32_t)sfmem_dma_to_device((void *)A, 64), 0u);
    check("T2 to_device(B)", (uint32_t)sfmem_dma_to_device((void *)B, 64), 0u);
    check("T2 begin(C)", (uint32_t)sfmem_dma_from_device_begin((void *)C, 4 * NW), 0u);
    for (unsigned i = 0; i < NW; i++) ref2[i] = C[i];                   /* CPU touches C while the TSU will own
                                                                          it: lines allocated with the old data */
    tsu_dev_t dev;
    tsu_opts_t o;
    tsu_record_t rec;
    memset(&o, 0, sizeof o);
    check("T2 tsu_init", (uint32_t)tsu_init(&dev), 0u);
    check("T2 tensor_gemm", (uint32_t)tensor_gemm(&dev, (uint32_t)A, (uint32_t)B, (uint32_t)C, 8, 8, 8, &o, &rec), 0u);
    {
        uint32_t stale[NW];
        for (unsigned i = 0; i < NW; i++) stale[i] = C[i];
        unsigned same = 0;
        for (unsigned i = 0; i < NW; i++) same += stale[i] == ref2[i];
        check(wb || inf.dcache ? "T2 negative control: CPU read stale C without INVAL (words)" :
                                 "T2 no cache: fresh C", same, inf.dcache ? NW : 0u);
    }
    check("T2 end(C)", (uint32_t)sfmem_dma_from_device_end((void *)C, 4 * NW), 0u);
    check_buf("T2 GEMM result after INVAL", C, ref, NW);

    /* ===================================================================== T3: TensorCore -> vector engine -> CPU */
    step("T3 TensorCore result -> vector engine KERNEL IADD (bias) -> CPU");
    volatile uint32_t *BIAS = SRAM(0x4400), *D = SRAM(0x4600);
    for (unsigned i = 0; i < NW; i++) { BIAS[i] = 1000u * i; ref2[i] = ref[i] + 1000u * i; }
    check("T3 to_device(bias)", (uint32_t)sfmem_dma_to_device((void *)BIAS, 4 * NW), 0u);
    check("T3 begin(D)", (uint32_t)sfmem_dma_from_device_begin((void *)D, 4 * NW), 0u);
    hpc_info_t hi;
    hpc_cpl_t cpl;
    check("T3 hpc_probe", (uint32_t)hpc_probe(HPC, &hi), 0u);
    check("T3 hpc_soft_reset", (uint32_t)hpc_soft_reset(HPC, 100000), 0u);
    sfmem_vspm_give(1u << 0);                                            /* staging partition 0 -> engine */
    hpc_cmd_t k = hpc_cmd_kernel(HPC_OP_IADD, HPC_RNE, NW, (uint32_t)C, (uint32_t)BIAS, 0, (uint32_t)D,
                                 hi.spm_base, 0, 3, 0);
    check("T3 submit", (uint32_t)hpc_submit(HPC, &k), 0u);
    check("T3 wait", (uint32_t)hpc_wait(HPC, &cpl, 2000000), 1u);
    check("T3 status", cpl.status, HPC_ST_OK);
    sfmem_vspm_take(1u << 0);
    check("T3 end(D)", (uint32_t)sfmem_dma_from_device_end((void *)D, 4 * NW), 0u);
    check_buf("T3 vector-engine result (GEMM + bias)", D, ref2, NW);

    /* ===================================================================== T4: scratchpad ownership */
    step("T4 vector scratchpad: host window, ownership, VEC IMUL in place");
    const uint32_t P1 = SFMEM_VSPM_PART_BYTES * 1u;                    /* partition 1 */
    volatile uint32_t *X = VSPM(P1), *Y = VSPM(P1 + 0x100), *Z = VSPM(P1 + 0x200);
    for (unsigned i = 0; i < 32; i++) { X[i] = i + 3u; Y[i] = 2u * i + 1u; ref[i] = (i + 3u) * (2u * i + 1u); }
    sfmem_vspm_give(1u << 1);
    sfmem_err_clear();
    uint32_t t0 = trap_count;
    uint32_t v = X[5];                                                   /* engine-owned: bus error -> trap */
    (void)v;
    check("T4 host load while engine-owned faulted", trap_count - t0, 1u);
    check("T4 fault cause = load access fault", trap_last_cause, 5u);
    check("T4 fault address", trap_last_tval, (uint32_t)&X[5]);
    sfmem_err_t e;
    sfmem_err_read(&e);
    check("T4 MEMCTL error cause OWNERSHIP", e.info & 0xFu, SFMEM_ERR_OWNERSHIP);
    sfmem_err_clear();
    hpc_cmd_t vc = hpc_cmd_vec(HPC_OP_IMUL, HPC_RNE, 32, (uint32_t)X, (uint32_t)Y, 0, (uint32_t)Z, 0, 4, 0);
    check("T4 submit", (uint32_t)hpc_submit(HPC, &vc), 0u);
    check("T4 wait", (uint32_t)hpc_wait(HPC, &cpl, 2000000), 1u);
    check("T4 status", cpl.status, HPC_ST_OK);
    sfmem_vspm_take(1u << 1);
    check_buf("T4 VEC IMUL in the scratchpad", Z, ref, 32);

    /* ===================================================================== T5: external memory */
    step("T5 CPU (cached EXT) -> DMA EXT->SRAM -> DMA SRAM->EXT -> CPU");
    volatile uint32_t *xs = EXTM(0x1000), *xd = EXTM(0x2000), *mid = SRAM(0x5000);
    for (unsigned i = 0; i < NW; i++) { xs[i] = 0xE0000000u ^ (i * 0x01010101u); ref[i] = xs[i]; }
    check("T5 to_device(xs)", (uint32_t)sfmem_dma_to_device((void *)xs, 4 * NW), 0u);
    check("T5 begin(xd)", (uint32_t)sfmem_dma_from_device_begin((void *)xd, 4 * NW), 0u);
    check("T5 dma EXT->SRAM", (uint32_t)dma_copy((uint32_t)xs, (uint32_t)mid, 4 * NW), 0u);
    check("T5 dma SRAM->EXT", (uint32_t)dma_copy((uint32_t)mid, (uint32_t)xd, 4 * NW), 0u);
    check("T5 end(xd)", (uint32_t)sfmem_dma_from_device_end((void *)xd, 4 * NW), 0u);
    check_buf("T5 round trip through EXT and SRAM", xd, ref, NW);

    /* ===================================================================== T6: non-cacheable window */
    step("T6 non-cacheable window: no maintenance");
    volatile uint32_t *nc = SRAM(0x6000);
    check("T6 set_noncacheable", (uint32_t)sfmem_set_noncacheable(0, (uintptr_t)nc, (uintptr_t)nc + 0x400), 0u);
    for (unsigned i = 0; i < NW; i++) { nc[i] = 0x7C000000u | i; ref[i] = 0x7C000000u | i; }
    check("T6 dma", (uint32_t)dma_copy((uint32_t)nc, (uint32_t)(nc + 0x40), 4 * NW), 0u);
    check_buf("T6 DMA copy, no CLEAN / INVAL", nc + 0x40, ref, NW);
    check("T6 clear window", (uint32_t)sfmem_set_noncacheable(0, 0, 0), 0u);

    /* ===================================================================== counters */
    step("counters");
    static const struct { const char *n; unsigned i; } pc[] = {
        {"DC_HIT", SFMEM_PC_DC_HIT}, {"DC_MISS", SFMEM_PC_DC_MISS}, {"DC_WB", SFMEM_PC_DC_WB},
        {"DC_BYPASS", SFMEM_PC_DC_BYPASS}, {"IC_HIT", SFMEM_PC_IC_HIT}, {"IC_MISS", SFMEM_PC_IC_MISS},
        {"CMO_LINES", SFMEM_PC_CMO_LINES}, {"SRAM_ACC_CPUD", SFMEM_PC_SRAM_ACC_M2},
        {"SRAM_ACC_SDMA", SFMEM_PC_SRAM_ACC_M3}, {"SRAM_ACC_VDMA", SFMEM_PC_SRAM_ACC_M4},
        {"SRAM_ACC_TDMA", SFMEM_PC_SRAM_ACC_M5}, {"SRAM_CONF_SDMA", SFMEM_PC_SRAM_CONF_M3},
        {"SRAM_CONF_TDMA", SFMEM_PC_SRAM_CONF_M5}, {"EXT_TXN", SFMEM_PC_EXT_TXN}, {"VSPM_TXN", SFMEM_PC_VSPM_TXN},
        {"ERRORS", SFMEM_PC_ERRORS}, {"CYCLES", SFMEM_PC_CYCLES}};
    for (unsigned i = 0; i < sizeof pc / sizeof pc[0]; i++) {
        puts_("  "); puts_(pc[i].n); puts_(" = "); putdec(sfmem_perf(pc[i].i)); puts_("\n");
    }
    puts_(fails ? "DEMO FAIL: " : "DEMO PASS: "); putdec((uint32_t)checks); puts_(" checks, ");
    putdec((uint32_t)fails); puts_(" failures\n");
    return fails;
}
