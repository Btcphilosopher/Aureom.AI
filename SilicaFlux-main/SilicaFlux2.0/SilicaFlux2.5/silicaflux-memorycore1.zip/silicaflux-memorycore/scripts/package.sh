#!/bin/sh
# Package the MemoryCore deliverable as a zip (sources, docs, reports; build/ excluded).
set -e
cd "$(dirname "$0")/.."
NAME=silicaflux-memorycore
OUT=${1:-../$NAME.zip}
find . -name __pycache__ -type d -prune -exec rm -rf {} +
( find . -type f ! -path './build/*' ! -path './MANIFEST.sha256' | LC_ALL=C sort | sed 's|^\./||' \
  | xargs sha256sum ) > MANIFEST.sha256
cd ..
rm -f "$OUT"
zip -qr "$OUT" "$NAME" -x "$NAME/build/*"
echo "wrote $OUT ($(du -h "$OUT" | cut -f1))"
