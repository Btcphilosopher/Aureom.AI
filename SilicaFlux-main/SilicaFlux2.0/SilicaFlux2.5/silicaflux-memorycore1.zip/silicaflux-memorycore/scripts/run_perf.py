#!/usr/bin/env python3
"""MemoryCore performance measurements (RTL simulation, Verilator 5.020, tb/tb_sfmem_perf.sv).

Every number is a measured RTL-simulation result in clock cycles: bank conflicts, access latency (from the cycle a
request is first presented to the cycle its response is taken), sustained bandwidth, cache hit / miss rates, DMA
contention, stall cycles and useful bytes.  Each run also cross-checks the hardware counters (MEMCTL perf block)
against the testbench's own counts.  No clock frequency is assumed; bytes / cycle x f gives bytes / second at any
frequency the implementation closes.

Results: reports/perf.{md,json}.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "generated"))
import sfmem_map as MAP  # noqa: E402

BUILD = ROOT / "build" / "perf"
REPORTS = ROOT / "reports"
PC = MAP.PERF
SRAM, EXT = 0x1000_0000, 0x8000_0000
NAMES = ["DBG", "CPUI", "CPUD", "SDMA", "VDMA", "TDMA"]


def build(banks=8, lat=1, arb=0, ext_lat=20, ext_depth=4, max_out=4) -> Path:
    tag = f"b{banks}l{lat}a{arb}e{ext_lat}d{ext_depth}o{max_out}"
    d = BUILD / tag
    exe = d / "vsim"
    if exe.exists():
        return exe
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "-j", "2", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
           "-Wno-UNOPTFLAT", f"-DSRAM_BANKS={banks}", f"-DSRAM_RD_LAT={lat}", f"-DSRAM_ARB={arb}", f"-DEXT_LAT={ext_lat}",
           f"-DEXT_DEPTH={ext_depth}", f"-DMAX_OUT={max_out}", "--top-module", "tb_sfmem_perf", "-f", "rtl/files.f",
           "tb/sfmem_tb_slave.sv", "tb/tb_sfmem_perf.sv", "-Mdir", str(d / "obj"), "-o", "../vsim"]
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    if r.returncode or not exe.exists():
        raise RuntimeError(r.stdout[-2000:] + r.stderr[-2000:])
    return exe


def gen(m, mode, n=0, base=None, size=0x1000, out=4, wr=0, strb=0xF):
    a = [f"+m{m}_mode={mode}", f"+m{m}_n={n}", f"+m{m}_size={size:x}", f"+m{m}_out={out}", f"+m{m}_wr={wr}",
         f"+m{m}_strb={strb:x}"]
    if base is not None:
        a.append(f"+m{m}_base={base:x}")
    return a


def run(build_kw: dict, args: list[str]) -> dict:
    exe = build(**build_kw)
    r = subprocess.run([str(exe), *args], capture_output=True, text=True, timeout=3600)
    out = r.stdout
    if "RESULT: DONE" not in out:
        raise RuntimeError(out[-1500:])
    res = {"masters": {}, "pc": {}, "hist": {}}
    for m in re.finditer(r"PERF (\d+) (\d+) (\d+) (\d+) (\d+) (\d+) (\d+)", out):
        i, ops, by, cyc, ls, lm, st = map(int, m.groups())
        res["masters"][i] = dict(ops=ops, bytes=by, cycles=cyc, lat_avg=round(ls / ops, 3) if ops else 0, lat_max=lm,
                                 stall=st, bpc=round(by / cyc, 3) if cyc else 0)
    for m in re.finditer(r"HIST (\d+) ([\d ]+)", out):
        res["hist"][int(m.group(1))] = list(map(int, m.group(2).split()))
    for m in re.finditer(r"PC (\d+) (\d+)", out):
        res["pc"][int(m.group(1))] = int(m.group(2))
    act = [v for v in res["masters"].values() if v["ops"]]
    span = max((v["cycles"] for v in act), default=0)
    res["aggregate_bpc"] = round(sum(v["bytes"] for v in act) / span, 3) if span else 0
    res["cycles"] = int(re.search(r"RESULT: DONE \((\d+) cycles", out).group(1))
    return res


def pc(res, name):
    return res["pc"].get(PC[name], 0)


def crosscheck(res, uncached_sram_masters):
    """Hardware counters vs testbench counts (only where the testbench count is exact)."""
    bad = []
    for m in uncached_sram_masters:
        if m in res["masters"] and pc(res, f"SRAM_ACC_M{m}") != res["masters"][m]["ops"]:
            bad.append(f"SRAM_ACC_M{m} {pc(res, f'SRAM_ACC_M{m}')} != {res['masters'][m]['ops']}")
    return bad


# ============================================================================= experiments
def e1_bank_scaling():
    rows = []
    for banks in (1, 2, 4, 8, 16):
        for pat, mode in (("sequential", 1), ("random", 2)):
            args = []
            for j, m in enumerate((0, 3, 4, 5, 1, 2)):
                args += gen(m, mode, n=2000, base=SRAM + j * 0x8000, size=0x8000, out=4)
            r = run(dict(banks=banks), args)
            conf = sum(pc(r, f"SRAM_CONF_M{m}") for m in range(6))
            rows.append(dict(banks=banks, pattern=pat, requesters=6, aggregate_bpc=r["aggregate_bpc"],
                             words_per_cycle=round(r["aggregate_bpc"] / 4, 3),
                             avg_latency=round(sum(v["lat_avg"] for v in r["masters"].values()) / 6, 2),
                             conflict_cycles=conf, check=crosscheck(r, [0, 3, 4, 5, 1, 2])))
    return rows


def e2_patterns():
    rows = []
    pats = [("sequential", 1, 0), ("random", 2, 0), ("stride = banks (one bank)", 3, 0), ("sequential, 50 % writes", 1, 50),
            ("random, 50 % writes", 2, 50)]
    for name, mode, wr in pats:
        args = []
        for j, m in enumerate((0, 3, 4, 5)):
            args += gen(m, mode, n=2000, base=SRAM + j * 0x8000, size=0x8000, out=4, wr=wr)
        r = run(dict(banks=8), args)
        rows.append(dict(pattern=name, requesters=4, aggregate_bpc=r["aggregate_bpc"],
                         avg_latency=round(sum(r["masters"][m]["lat_avg"] for m in (0, 3, 4, 5)) / 4, 2),
                         max_latency=max(r["masters"][m]["lat_max"] for m in (0, 3, 4, 5)),
                         conflict_cycles=sum(pc(r, f"SRAM_CONF_M{m}") for m in (0, 3, 4, 5)),
                         bank_accesses=[pc(r, f"SRAM_BANK{b}") for b in range(8)], check=crosscheck(r, [0, 3, 4, 5])))
    return rows


def e3_latency():
    rows = []
    for lat in (1, 2, 3):
        for out in (1, 2, 4):
            r = run(dict(lat=lat), gen(3, 1, n=2000, base=SRAM, size=0x8000, out=out))
            v = r["masters"][3]
            rows.append(dict(read_latency=lat, outstanding=out, bpc=v["bpc"], words_per_cycle=round(v["bpc"] / 4, 3),
                             lat_avg=v["lat_avg"], lat_max=v["lat_max"], check=crosscheck(r, [3])))
    return rows


def e4_contention():
    """ControlCore loads (blocking, random over a working set in SRAM) against 0..4 DMA streams on the same SRAM."""
    rows = []
    for ws in (0x400, 0x2000):
        for k in range(5):
            for cached in (0, 1):
                args = gen(2, 5, n=3000, base=SRAM + 0x30000, size=ws, out=1)
                for j, m in enumerate((3, 4, 5, 0)[:k]):
                    args += gen(m, 2, n=0, base=SRAM + j * 0x8000, size=0x8000, out=4)
                r = run(dict(), args + [f"+dcache={cached}", "+cregions=12"])   # SRAM | EXT cached
                v = r["masters"][2]
                hits, miss = pc(r, "DC_HIT"), pc(r, "DC_MISS")
                rows.append(dict(working_set=ws, dma_streams=k, dcache=bool(cached), cpu_lat_avg=v["lat_avg"],
                                 cpu_lat_max=v["lat_max"], cpu_hist=r["hist"][2],
                                 hit_rate=round(hits / (hits + miss), 4) if hits + miss else None,
                                 dma_bpc=round(sum(r["masters"][m]["bytes"] for m in (3, 4, 5, 0)[:k]) /
                                               max(1, v["cycles"]), 3),
                                 cpu_conflicts=pc(r, "SRAM_CONF_M2")))
    return rows


def e5_ext_cache():
    rows = []
    for ext_lat in (20, 40):
        for who, m in (("ControlCore data (CPUD)", 2), ("ControlCore fetch (CPUI)", 1)):
            for ws in (0x400, 0x2000):
                for cached in (0, 1):
                    args = gen(m, 4, n=4000, base=EXT + 0x10000, size=ws, out=1)
                    flag = f"+dcache={cached}" if m == 2 else f"+icache={cached}"
                    r = run(dict(ext_lat=ext_lat), args + [flag])
                    v = r["masters"][m]
                    h = pc(r, "DC_HIT" if m == 2 else "IC_HIT")
                    s = pc(r, "DC_MISS" if m == 2 else "IC_MISS")
                    rows.append(dict(ext_latency=ext_lat, requester=who, working_set=ws, cached=bool(cached),
                                     lat_avg=v["lat_avg"], cycles=v["cycles"], hit_rate=round(h / (h + s), 4) if h + s else None,
                                     ext_txn=pc(r, "EXT_TXN")))
    return rows


def e6_ext_stream():
    rows = []
    for depth in (1, 2, 4):
        for out in (1, 4):
            r = run(dict(ext_lat=20, ext_depth=depth), gen(3, 1, n=2000, base=EXT, size=0x8000, out=out))
            v = r["masters"][3]
            rows.append(dict(ext_latency=20, ext_depth=depth, requester_outstanding=out, bpc=v["bpc"],
                             lat_avg=v["lat_avg"], ext_txn=pc(r, "EXT_TXN"), ext_wait=pc(r, "EXT_STALL")))
    return rows


def e7_fairness():
    rows = []
    for arb, name in ((0, "round robin"), (1, "fixed priority")):
        args = []
        for j, m in enumerate((0, 3, 4, 5)):
            args += gen(m, 3, n=1500, base=SRAM + j * 0x8000 + 0, size=0x8000, out=4)   # every requester, bank 0
        r = run(dict(arb=arb), args)
        rows.append(dict(arbitration=name, per_requester={NAMES[m]: dict(cycles=r["masters"][m]["cycles"],
                                                                         lat_avg=r["masters"][m]["lat_avg"],
                                                                         lat_max=r["masters"][m]["lat_max"])
                                                          for m in (0, 3, 4, 5)},
                         aggregate_bpc=r["aggregate_bpc"]))
    return rows


def e8_useful_bytes():
    rows = []
    for strb, name in ((0xF, "word writes"), (0x3, "half-word writes"), (0x1, "byte writes")):
        r = run(dict(), gen(3, 1, n=2000, base=SRAM, size=0x8000, out=4, wr=100, strb=strb))
        v = r["masters"][3]
        rows.append(dict(kind=name, transactions=v["ops"], bus_bytes=4 * v["ops"], useful_bytes=pc(r, "SRAM_WR_BYTES"),
                         efficiency=round(pc(r, "SRAM_WR_BYTES") / (4 * v["ops"]), 3), tb_useful_bytes=v["bytes"]))
    return rows


EXPERIMENTS = [("E1", "Bank scaling (6 requesters)", e1_bank_scaling), ("E2", "Access patterns (8 banks)", e2_patterns),
               ("E3", "Read latency and outstanding requests", e3_latency),
               ("E4", "DMA contention vs ControlCore load latency (shared SRAM)", e4_contention),
               ("E5", "Caching case: external memory", e5_ext_cache), ("E6", "External-memory streaming", e6_ext_stream),
               ("E7", "Arbitration fairness (all requesters on one bank)", e7_fairness),
               ("E8", "Useful bytes (partial writes)", e8_useful_bytes)]


def main() -> int:
    t0 = time.time()
    # builds first (parallel), then experiments (parallel by experiment)
    cfgs = [dict(banks=b) for b in (1, 2, 4, 8, 16)] + [dict(lat=2), dict(lat=3), dict(arb=1), dict(ext_lat=40)] + \
           [dict(ext_lat=20, ext_depth=d) for d in (1, 2)]
    with cf.ThreadPoolExecutor(4) as ex:
        list(ex.map(lambda k: build(**k), cfgs))
    out = {}
    with cf.ThreadPoolExecutor(4) as ex:
        futs = {ex.submit(f): (k, t) for k, t, f in EXPERIMENTS}
        for fu in cf.as_completed(futs):
            k, t = futs[fu]
            out[k] = dict(title=t, rows=fu.result())
            print("done", k)
    REPORTS.mkdir(exist_ok=True)
    js = dict(generated=time.strftime("%Y-%m-%d %H:%M:%S"), time_base="RTL simulation clock cycles (Verilator 5.020)",
              wall_s=round(time.time() - t0, 1), experiments=out)
    (REPORTS / "perf.json").write_text(json.dumps(js, indent=1))
    print(f"perf done in {js['wall_s']} s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
