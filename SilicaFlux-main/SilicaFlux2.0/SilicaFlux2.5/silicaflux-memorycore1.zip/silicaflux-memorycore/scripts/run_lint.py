#!/usr/bin/env python3
"""Lint / elaboration of the MemoryCore RTL, illegal-configuration rejection, memory-map generator rules.

  * Verilator 5.020 --lint-only -Wall on silicaflux_memory_subsystem for every legal configuration below: 0 warnings
    required (third-party files are byte-identical copies and are linted as part of the hierarchy);
  * Icarus 12 elaboration of the same configurations;
  * Yosys 0.33 front end (read -defer, hierarchy, proc, check -assert) on three configurations;
  * illegal parameter sets must FAIL elaboration in both simulators (the modules' own checks);
  * the memory-map generator must refuse illegal maps, and its outputs must be up to date (--check).
Results: reports/lint.{md,json}.
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
REPORTS = ROOT / "reports"
TOP = "silicaflux_memory_subsystem"

LEGAL = {
    "default": {},
    "I-cache + D-cache": {"ICACHE_EN": 1},
    "write-through": {"DCACHE_WB": 0},
    "no caches": {"DCACHE_EN": 0, "ICACHE_EN": 0},
    "no ECC": {"ECC_MODE": 0},
    "16 banks, latency 3": {"SRAM_BANKS": 16, "SRAM_RD_LAT": 3},
    "1 bank, fixed priority": {"SRAM_BANKS": 1, "SRAM_ARB": 1},
    "direct-mapped 32 B lines": {"CACHE_WAYS": 1, "CACHE_SETS": 32, "CACHE_LINE": 32},
    "8-way 64 B lines": {"CACHE_WAYS": 8, "CACHE_SETS": 8, "CACHE_LINE": 64},
    "max_out 1, no perf": {"MAX_OUT": 1, "EXT_DEPTH": 1, "VSPM_DEPTH": 1, "PERF_EN": 0},
}
ILLEGAL = {
    "ECC_MODE = SECDED (reserved, Project 26)": {"ECC_MODE": 2},
    "ECC_MODE = 3": {"ECC_MODE": 3},
    "CACHE_WAYS = 3": {"CACHE_WAYS": 3},
    "CACHE_LINE = 4": {"CACHE_LINE": 4},
    "CACHE_SETS = 48": {"CACHE_SETS": 48},
    "SRAM_BANKS = 3": {"SRAM_BANKS": 3},
    "SRAM_RD_LAT = 0": {"SRAM_RD_LAT": 0},
    "MAX_OUT = 0": {"MAX_OUT": 0},
    "DCACHE_WB = 2": {"DCACHE_WB": 2},
    "EXT_DEPTH = 0": {"EXT_DEPTH": 0},
}


def sh(cmd, timeout=900):
    return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)


def gflags(p: dict, tool: str):
    if tool == "verilator":
        return [f"-G{k}={v}" for k, v in p.items()]
    return [f"-P{TOP}.{k}={v}" for k, v in p.items()]


def verilator(p: dict, wall=True):
    r = sh(["verilator", "--lint-only", *(["-Wall", "-Wno-DECLFILENAME"] if wall else ["-Wno-fatal"]),
            "-f", "rtl/files.f", "--top-module", TOP, *gflags(p, "verilator")])
    warns = [l for l in (r.stdout + r.stderr).splitlines() if l.startswith("%Warning")]
    # Verilator reports an elaboration-time $fatal of a generate-scope check as %Warning-USERFATAL
    errs = [l for l in (r.stdout + r.stderr).splitlines() if l.startswith("%Error") or "USERFATAL" in l]
    return r.returncode, warns, errs


def icarus(p: dict):
    with tempfile.TemporaryDirectory() as d:
        r = sh(["iverilog", "-g2012", "-o", f"{d}/x.vvp", "-f", "rtl/files.f", "-s", TOP, *gflags(p, "icarus")])
        msg = r.stdout + r.stderr
        if r.returncode == 0:                      # Icarus reports $fatal of generate-scope checks at run time
            r2 = sh(["vvp", "-n", f"{d}/x.vvp"], timeout=120)
            if "FATAL" in (r2.stdout + r2.stderr) or r2.returncode:
                return 1, (r2.stdout + r2.stderr)[-300:]
        return r.returncode, msg[-300:]


def yosys(p: dict):
    files = [l.strip() for l in open(ROOT / "rtl/files.f") if l.strip() and not l.startswith("+")]
    inc = "-Irtl -Ithird_party/silicaflux-sramlib/rtl/mem -Ithird_party/silicaflux-sramlib/rtl/mem/backends/asic"
    chp = " ".join(f"-set {k} {v}" for k, v in p.items())
    script = (f"read_verilog -defer -sv -DSYNTHESIS {inc} {' '.join(files)}; "
              f"chparam {chp} {TOP}; " if p else f"read_verilog -defer -sv -DSYNTHESIS {inc} {' '.join(files)}; ")
    script += f"hierarchy -check -top {TOP}; proc; opt_clean; check -assert"
    r = sh(["yosys", "-q", "-p", script], timeout=1800)
    out = r.stdout + r.stderr
    latches = out.count("Latch inferred")
    return r.returncode, latches, out[-300:]


def map_rules():
    base = yaml.safe_load(open(ROOT / "memmap/memorycore.yaml"))
    cases = {}

    def mut(name, fn):
        m = yaml.safe_load(yaml.safe_dump(base))
        fn(m)
        cases[name] = m
    mut("overlapping regions", lambda m: m["regions"][1].__setitem__("base", 0x0800_0000))
    mut("base not aligned to size", lambda m: m["regions"][1].__setitem__("base", 0x1002_0000))
    mut("size not a power of two", lambda m: m["regions"][0].__setitem__("size", 0x6000))
    mut("cacheable MMIO window", lambda m: m["regions"][2].__setitem__("cacheable", True))
    mut("banks not a power of two", lambda m: m["regions"][1].__setitem__("banks", 6))
    mut("deny of an unknown region", lambda m: m["masters"][3]["deny"].append("NOPE"))
    mut("LMEM reachable by a DMA", lambda m: m["masters"][3].__setitem__("deny", ["MMIO"]))
    mut("page outside MMIO", lambda m: m["pages"][0].__setitem__("index", 40))
    mut("duplicate register offset", lambda m: m["register_blocks"]["memctl"]["registers"][1].__setitem__("offset", 0))
    res = []
    with tempfile.TemporaryDirectory() as d:
        for name, m in cases.items():
            y = Path(d) / "m.yaml"
            y.write_text(yaml.safe_dump(m))
            r = sh([sys.executable, "scripts/memmap_gen.py", "--yaml", str(y), "--out", d])
            res.append(dict(case=name, rejected=r.returncode == 2, message=(r.stderr.strip().splitlines() or [""])[-1]))
    chk = sh([sys.executable, "scripts/memmap_gen.py", "--check"])
    leg = sh([sys.executable, "scripts/memmap_gen.py", "--check-legacy",
              "third_party/silicaflux-hpc-m08-tile/soc/memmap/silicaflux_v_hpc.yaml"])
    return res, chk.returncode == 0, leg.returncode == 0, leg.stdout


def main() -> int:
    t0 = time.time()
    legal, illegal, ys = [], [], []
    for name, p in LEGAL.items():
        rc, w, e = verilator(p)
        irc, _ = icarus(p)
        legal.append(dict(config=name, params=p, verilator_ok=rc == 0 and not w and not e, warnings=len(w),
                          first=(w + e)[:3], icarus_ok=irc == 0))
    for name, p in ILLEGAL.items():
        rc, w, e = verilator(p, wall=False)
        irc, imsg = icarus(p)
        illegal.append(dict(config=name, params=p, verilator_rejected=rc != 0 or bool(e), icarus_rejected=irc != 0,
                            verilator_message=(e[:1] or [""])[0][:160]))
    for name in ("default", "write-through", "16 banks, latency 3"):
        rc, latches, tail = yosys(LEGAL[name])
        ys.append(dict(config=name, ok=rc == 0, latches=latches, tail=tail if rc else ""))
    mr, gen_ok, legacy_ok, legacy_txt = map_rules()
    js = dict(generated=time.strftime("%Y-%m-%d %H:%M:%S"), legal=legal, illegal=illegal, yosys=ys, map_rules=mr,
              generated_up_to_date=gen_ok, legacy_map_consistent=legacy_ok, legacy=legacy_txt,
              wall_s=round(time.time() - t0, 1))
    REPORTS.mkdir(exist_ok=True)
    (REPORTS / "lint.json").write_text(json.dumps(js, indent=1))
    n_legal = sum(x["verilator_ok"] and x["icarus_ok"] for x in legal)
    n_ill = sum(x["verilator_rejected"] and x["icarus_rejected"] for x in illegal)
    L = ["# MemoryCore lint, elaboration and configuration checks", "",
         f"Generated by `scripts/run_lint.py` ({js['generated']}).", "",
         f"* Legal configurations clean (Verilator `-Wall`: 0 warnings, and Icarus elaboration): **{n_legal} / {len(legal)}**",
         f"* Illegal configurations rejected by both Verilator and Icarus: **{n_ill} / {len(illegal)}**",
         f"* Yosys 0.33 front end + `check -assert`, no latches: **{sum(y['ok'] and y['latches'] == 0 for y in ys)} / {len(ys)}**",
         f"* Memory-map generator: illegal maps refused **{sum(m['rejected'] for m in mr)} / {len(mr)}**; generated files up "
         f"to date: **{gen_ok}**; addresses shared with the HPC SoC map consistent: **{legacy_ok}**", "",
         "## Legal", "", "| Configuration | Parameters | Verilator -Wall | Icarus |", "|---|---|---|---|"]
    for x in legal:
        L.append(f"| {x['config']} | `{x['params']}` | {'0 warnings' if x['verilator_ok'] else x['first']} | "
                 f"{'ok' if x['icarus_ok'] else 'FAIL'} |")
    L += ["", "## Illegal (must be rejected)", "", "| Configuration | Verilator | Icarus | Message |", "|---|---|---|---|"]
    for x in illegal:
        L.append(f"| {x['config']} | {'rejected' if x['verilator_rejected'] else 'ACCEPTED'} | "
                 f"{'rejected' if x['icarus_rejected'] else 'ACCEPTED'} | `{x['verilator_message']}` |")
    L += ["", "## Yosys", "", "| Configuration | check -assert | Latches |", "|---|---|---|"]
    L += [f"| {y['config']} | {'ok' if y['ok'] else 'FAIL'} | {y['latches']} |" for y in ys]
    L += ["", "## Memory-map generator rules", "", "| Illegal map | Refused | Message |", "|---|---|---|"]
    L += [f"| {m['case']} | {'yes' if m['rejected'] else 'NO'} | `{m['message']}` |" for m in mr]
    L += ["", "```", legacy_txt.strip(), "```", ""]
    (REPORTS / "lint.md").write_text("\n".join(L) + "\n")
    print(f"legal {n_legal}/{len(legal)}  illegal rejected {n_ill}/{len(illegal)}  yosys {len(ys)}  "
          f"map rules {sum(m['rejected'] for m in mr)}/{len(mr)}  gen up to date {gen_ok}  ({js['wall_s']} s)")
    ok = n_legal == len(legal) and n_ill == len(illegal) and all(y["ok"] and not y["latches"] for y in ys) and \
        all(m["rejected"] for m in mr) and gen_ok and legacy_ok
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
