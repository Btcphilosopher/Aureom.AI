#!/usr/bin/env python3
"""Verify that every file under third_party/ is a byte-identical copy of a file in the source repository archives,
and (re)write third_party/SHA256SUMS and third_party/PROVENANCE.md.

    python3 scripts/check_vendor.py --repo /path/to/Aureom.AI/SilicaFlux-main            # verify + write
    python3 scripts/check_vendor.py --sums-only                                          # SHA256SUMS check only
"""
from __future__ import annotations

import argparse
import hashlib
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TP = ROOT / "third_party"
# third_party/<dir>  ->  (archive path relative to SilicaFlux-main, top directory inside the archive)
SOURCES = {
    "silicaflux-sramlib": ("SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip", "silicaflux-sramlib"),
    "silicaflux-datafabric": ("SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric.zip", "silicaflux-datafabric"),
    "silicaflux-tensorcore08": ("silicaflux-tensorcore08.zip", "silicaflux-tensorcore08"),
    "silicaflux-hpc-m08-tile": ("SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m08-tile.zip", "silicaflux-hpc-m08-tile"),
    "silicaflux-bandwidthlab": ("SilicaFlux2.0/SilicaFlux2.5/silicaflux-bandwidthlab.zip", "silicaflux-bandwidthlab"),
}
SKIP = {"SHA256SUMS", "PROVENANCE.md"}


def files():
    return sorted(p for p in TP.rglob("*") if p.is_file() and p.name not in SKIP and "__pycache__" not in p.parts)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", help="path of SilicaFlux-main in btcphilosopher/Aureom.AI")
    ap.add_argument("--sums-only", action="store_true")
    a = ap.parse_args()
    fs = files()
    if a.sums_only:
        bad = 0
        for ln in (TP / "SHA256SUMS").read_text().splitlines():
            h, p = ln.split(None, 1)
            if hashlib.sha256((TP / p).read_bytes()).hexdigest() != h:
                print("CHANGED", p)
                bad += 1
        print(f"{len(fs)} vendored files, {bad} changed")
        return 1 if bad else 0
    if not a.repo:
        ap.error("--repo is required to verify against the source archives")
    repo = Path(a.repo)
    zips, ok, bad, per = {}, 0, [], {}
    for p in fs:
        rel = p.relative_to(TP)
        top = rel.parts[0]
        arc, inner = SOURCES[top]
        if arc not in zips:
            zips[arc] = zipfile.ZipFile(repo / arc)
        member = f"{inner}/" + "/".join(rel.parts[1:])
        try:
            same = zips[arc].read(member) == p.read_bytes()
        except KeyError:
            same = False
        if same:
            ok += 1
            per[top] = per.get(top, 0) + 1
        else:
            bad.append(str(rel))
    (TP / "SHA256SUMS").write_text("".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(TP)}\n"
                                           for p in fs))
    L = ["# Provenance of third_party/", "",
         "Every file below `third_party/` is an **unmodified, byte-identical** copy of a file in the source repository "
         "`btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (verified by `scripts/check_vendor.py --repo ...`; "
         "hashes in `SHA256SUMS`). MemoryCore's own code never edits these files.", "",
         "| Directory | Source archive (in SilicaFlux-main/) | Files | Used for |", "|---|---|---|---|"]
    use = {"silicaflux-sramlib": "bank controller, 1RW backends, MBIST march controller (Project 01)",
           "silicaflux-datafabric": "SFB2 protocol, protocol checker, DMA, v1 slave adapter; SilicaFlux-V `sfv_cpu`, "
                                    "`sfv_pkg`, `sfv_periph_bridge` (Project 03 vendored copies)",
           "silicaflux-tensorcore08": "tensor unit + its vendored HPC tile, scratchpad, TC02-07, SRAM library, "
                                      "DataFabric pieces; C driver (system test)",
           "silicaflux-hpc-m08-tile": "HPC tile C driver, SoC memory map (legacy-address check), docs",
           "silicaflux-bandwidthlab": "MemoryLab Python package (Project 02 inside Project 10) for bwlab_compare"}
    for top, (arc, _) in SOURCES.items():
        L.append(f"| `{top}/` | `{arc}` | {per.get(top, 0)} | {use[top]} |")
    L += ["", "No license file exists in the source repository; the owner must add one before external distribution "
          "(same note as Projects 01-10).", ""]
    (TP / "PROVENANCE.md").write_text("\n".join(L))
    print(f"{ok} identical, {len(bad)} not found / different")
    for b in bad[:20]:
        print("  ", b)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
