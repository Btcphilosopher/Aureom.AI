#!/usr/bin/env python3
"""Transaction-by-transaction comparison of MemoryCore's shared SRAM path (RTL) with MemoryLab / BandwidthLab.

MemoryLab (Project 02; vendored unmodified inside BandwidthLab, Project 10: third_party/silicaflux-bandwidthlab/
python/memorylab) contains `BankController`, a cycle-level model of the SRAM Wrapper Library's sram_bank_controller
that MemoryLab validated against that RTL, and `bankbench`, a deterministic stimulus generator (workloads random /
cpu / vector / tensor / dma / mixed / stride) with a fixed driving rule and response back-pressure hash.

Here the SAME stimulus runs (a) on the model and (b) on silicaflux_memory_subsystem through its six requester ports
(tb/tb_sfmem_trace.sv: requester -> [cache bypass] -> sfmem_port -> sfmem_banked -> sram_bank_controller).
Compared per transaction: acceptance cycle, response cycle, read data, error flag, and per-cycle bank-conflict
stalls.  Identity means MemoryCore's routing adds no cycle and no reordering to the verified bank controller, so
every MemoryLab / BandwidthLab bandwidth result for that controller applies to MemoryCore's shared SRAM unchanged.

Results: reports/bwlab_compare.{md,json}.
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "third_party" / "silicaflux-bandwidthlab" / "python"))
from memorylab import bankbench  # noqa: E402
from memorylab.sram import BankCtrlConfig  # noqa: E402

BUILD = ROOT / "build" / "bwlab"
REPORTS = ROOT / "reports"
NM, SRAM_WORDS = 6, 65536
WORKLOADS = ["random", "cpu", "vector", "tensor", "dma", "mixed", "stride"]
# name, banks, read latency, arbitration, back-pressure %
CASES = [("B8L1", 8, 1, "rr", 0), ("B8L2bp20", 8, 2, "rr", 20), ("B4L1bp10", 4, 1, "rr", 10),
         ("B16L3bp30", 16, 3, "rr", 30), ("B1L1", 1, 1, "rr", 0), ("B8L1fix", 8, 1, "fixed", 20),
         ("B2L2", 2, 2, "rr", 0)]
N_PER = 400


def build(banks: int, lat: int, arb: str) -> Path:
    d = BUILD / f"b{banks}l{lat}{arb}"
    exe = d / "vsim"
    if exe.exists():
        return exe
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
           "-Wno-UNOPTFLAT", f"-DSRAM_BANKS={banks}", f"-DSRAM_RD_LAT={lat}", f"-DSRAM_ARB={1 if arb == 'fixed' else 0}",
           "--top-module", "tb_sfmem_trace", "-f", "rtl/files.f", "tb/tb_sfmem_trace.sv", "-Mdir", str(d / "obj"),
           "-o", "../vsim"]
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    if r.returncode or not exe.exists():
        raise RuntimeError(r.stdout[-2000:] + r.stderr[-2000:])
    return exe


def parse_log(p: Path):
    acc, rsp, conf = defaultdict(list), defaultdict(list), defaultdict(int)
    for ln in p.read_text().splitlines():
        f = ln.split()
        if f[0] == "A":
            acc[int(f[2])].append((int(f[1]), int(f[3])))
        elif f[0] == "R":
            rsp[int(f[2])].append((int(f[1]), int(f[3]), int(f[4], 16), int(f[5])))
        elif f[0] == "C":
            conf[int(f[2])] += 1
    return acc, rsp, conf


def compare(case, wl):
    name, banks, lat, arb, bp = case
    cfg = BankCtrlConfig(num_masters=NM, num_banks=banks, bank_depth=SRAM_WORDS // banks, read_latency=lat,
                         arbitration=arb, data_width=32, mask_width=4)
    stim = bankbench.generate(wl, cfg, N_PER, seed=7)
    model = bankbench.run(cfg, stim, bp_pct=bp, seed=7)
    d = BUILD / "runs" / f"{name}-{wl}"
    d.mkdir(parents=True, exist_ok=True)
    bankbench.write_stimulus(d / "stim.txt", cfg, stim)
    exe = build(banks, lat, arb)
    r = subprocess.run([str(exe), f"+stim={d / 'stim.txt'}", f"+log={d / 'rtl.log'}", f"+bp={bp}", "+seed=7"],
                       capture_output=True, text=True, timeout=1800)
    if "RESULT: DONE" not in r.stdout:
        return dict(case=name, workload=wl, ok=False, note="RTL run failed: " + r.stdout[-300:])
    acc, rsp, conf = parse_log(d / "rtl.log")
    m_acc, m_rsp, m_conf = defaultdict(list), defaultdict(list), defaultdict(int)
    for c, m, rid in model["accepts"]:
        m_acc[m].append((c, rid))
    for c, m, rid, data, err, _we in model["responses"]:
        m_rsp[m].append((c, rid, data & 0xFFFFFFFF, err))
    for c, m in model["conflicts"]:
        m_conf[m] += 1
    n, mism, first = 0, 0, None
    for m in range(NM):
        a_r, a_m = sorted(acc[m]), sorted(m_acc[m])
        r_r, r_m = sorted(rsp[m]), sorted(m_rsp[m])
        if len(a_r) != len(a_m) or len(r_r) != len(r_m):
            mism += 1
            first = first or f"m{m}: count RTL {len(a_r)}/{len(r_r)} model {len(a_m)}/{len(r_m)}"
            continue
        for x, y in zip(a_r, a_m):
            n += 1
            if x != y:
                mism += 1
                first = first or f"m{m} accept RTL {x} model {y}"
        for x, y in zip(r_r, r_m):
            n += 1
            if x != y:
                mism += 1
                first = first or f"m{m} response RTL {x} model {y}"
    conf_eq = all(conf[m] == m_conf[m] for m in range(NM))
    met = bankbench.metrics(model, cfg)
    end = max([c for m in rsp for c, *_ in rsp[m]] or [0]) + 1
    words = sum(len(acc[m]) for m in range(NM))
    return dict(case=name, workload=wl, banks=banks, lat=lat, arb=arb, bp=bp, compared=n, mismatches=mism,
                first_mismatch=first, conflicts_rtl=sum(conf.values()), conflicts_model=sum(m_conf.values()),
                conflicts_equal=conf_eq, ok=mism == 0 and conf_eq,
                model_words_per_cycle=round(met["words_per_cycle"], 4), rtl_words_per_cycle=round(words / end, 4),
                model_avg_latency=round(met["avg_latency_cycles"], 3), conflict_rate=round(met["conflict_rate"], 4))


def main() -> int:
    t0 = time.time()
    res = []
    for case in CASES:
        for wl in WORKLOADS:
            r = compare(case, wl)
            res.append(r)
            print(f"{r['case']:<10} {r['workload']:<7} {'MATCH' if r['ok'] else 'DIFF '} "
                  f"{r.get('compared', 0):6d} items  {r.get('rtl_words_per_cycle', 0):.3f} w/cyc  "
                  f"{r.get('first_mismatch') or ''}")
    REPORTS.mkdir(exist_ok=True)
    ok = sum(r["ok"] for r in res)
    js = dict(generated=time.strftime("%Y-%m-%d %H:%M:%S"), requests_per_master=N_PER, masters=NM, runs=len(res),
              identical=ok, items=sum(r.get("compared", 0) for r in res), wall_s=round(time.time() - t0, 1), results=res)
    (REPORTS / "bwlab_compare.json").write_text(json.dumps(js, indent=1))
    L = ["# MemoryCore shared SRAM vs MemoryLab / BandwidthLab", "",
         f"Generated by `scripts/bwlab_compare.py` ({js['generated']}). Same MemoryLab `bankbench` stimulus "
         f"({NM} requesters x {N_PER} requests, seed 7) on the model and on `silicaflux_memory_subsystem` (Verilator).",
         "", f"**{ok} / {len(res)} runs identical** -- {js['items']:,} compared items (every acceptance cycle and "
         "every response cycle / data / error flag), plus equal bank-conflict stall counts per requester.", "",
         "| Case | Banks | Read lat. | Arb. | Back-pressure % | Workload | Compared | Mismatches | Conflicts RTL / model | "
         "Words / cycle | Avg latency (model) | Result |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in res:
        L.append(f"| {r['case']} | {r.get('banks')} | {r.get('lat')} | {r.get('arb')} | {r.get('bp')} | {r['workload']} | "
                 f"{r.get('compared')} | {r.get('mismatches')} | {r.get('conflicts_rtl')} / {r.get('conflicts_model')} | "
                 f"{r.get('rtl_words_per_cycle')} | {r.get('model_avg_latency')} | {'MATCH' if r['ok'] else 'DIFF'} |")
    (REPORTS / "bwlab_compare.md").write_text("\n".join(L) + "\n")
    print(f"{ok}/{len(res)} identical")
    return 0 if ok == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
