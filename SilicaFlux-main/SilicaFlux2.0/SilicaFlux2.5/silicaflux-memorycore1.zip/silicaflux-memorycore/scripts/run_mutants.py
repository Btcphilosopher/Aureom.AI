#!/usr/bin/env python3
"""Mutation testing of the new MemoryCore RTL: each mutant is one deliberate bug; it is KILLED when at least one run
of the mutation suite (every directed scenario + random traffic, with and without stalls, Icarus) fails.
A surviving mutant is either a test gap or an equivalent mutant -- both are listed with an explanation.
Results: reports/mutation.{md,json}.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "model"))
sys.path.insert(0, str(ROOT / "scripts"))
from sfmem_ref import Config  # noqa: E402
import gen_tests  # noqa: E402

BUILD = ROOT / "build" / "mut"
REPORTS = ROOT / "reports"

# id, file, original text, mutated text, description, config ("base" or "lat2")
MUTANTS = [
    ("P1", "sfmem_port.sv", "den     = any_hit && !ACC[rsel];", "den     = 1'b0;", "access matrix ignored", "base"),
    ("P2", "sfmem_port.sv", "mis     = s_req_addr[1:0] != 2'b00;", "mis     = 1'b0;", "misalignment not detected", "base"),
    ("P3", "sfmem_port.sv", "own_err = (rsel == 3'(sfmem_map_pkg::R_VSPM)) && vspm_own[part];", "own_err = 1'b0;",
     "VSPM ownership not enforced", "base"),
    ("P4", "sfmem_port.sv", "page == PGW'(sfmem_map_pkg::PG_MEMCTL)", "page == PGW'(sfmem_map_pkg::PG_MEMCTL + 1)",
     "MEMCTL page decoded at the wrong page", "base"),
    ("P5", "sfmem_port.sv", "assign pop = !empty && s_rsp_valid && s_rsp_ready;", "assign pop = !empty && s_rsp_valid;",
     "ordering FIFO pops without the response handshake", "base"),
    ("P6", "sfmem_port.sv", "if (!empty) begin\n      if (head == `SFMEM_TG_ERR)", "if (1'b1) begin\n      if (head == `SFMEM_TG_ERR)",
     "error responder answers with no request outstanding", "base"),
    ("T1", "sfmem_tgt_mux.sv", "        lock_q <= 1'b1;               // presented, not accepted: keep this requester",
     "        lock_q <= 1'b0;", "grant lock removed (target payload may change before acceptance)", "base"),
    ("T2", "sfmem_tgt_mux.sv", "assign head  = own_q[rd_p];", "assign head  = own_q[wr_p];", "response routed to the wrong owner",
     "base"),
    ("B1", "sfmem_banked.sv", "LW'({~^p_req_wdata[p*32 + l*8 +: 8] ^", "LW'({^p_req_wdata[p*32 + l*8 +: 8] ^",
     "even parity encoded (all-zero lane undetectable, every read fails)", "base"),
    ("B2", "sfmem_banked.sv", "!c_rid[p*(AWW+1) + AWW] && !c_rwe[p]", "!chk_dis && !c_rwe[p]",
     "CHECK_DIS applied at response time instead of acceptance (the bug found by the regression)", "lat2"),
    ("B3", "sfmem_banked.sv", "if (ECC_MODE == `SFMEM_ECC_PARITY && inj_req && !taken && c_acc[p] && p_req_write[p]) begin",
     "if (ECC_MODE == `SFMEM_ECC_PARITY && inj_req && c_acc[p]) begin", "injection applied to reads and to several ports",
     "base"),
    ("C1", "sfmem_cache.sv", "              if (r_write) dirty_q[lix(r_set, hit_way)] <= 1'b1;", "              ;",
     "write hit does not set the dirty bit (write-back lost)", "base"),
    ("C2", "sfmem_cache.sv", "            plru_q[r_set*PB +: PB] <= plru_touch(plru_q[r_set*PB +: PB], hit_way);", "            ;",
     "PLRU not updated on hits", "base"),
    ("C3", "sfmem_cache.sv", "                valid_q[lix(m_set, m_way)] <= 1'b0;\n                dirty_q[lix(m_set, m_way)] <= 1'b0;",
     "                dirty_q[lix(m_set, m_way)] <= 1'b0;", "INVAL keeps the line valid", "base"),
    ("C4", "sfmem_cache.sv", "            if (c_op[0] && m_d && WRITE_BACK != 0) begin              // CLEAN part: write back first",
     "            if (1'b0) begin", "CLEAN does not write dirty lines back", "base"),
    ("C5", "sfmem_cache.sv", "        S_FILLDONE: if (!beat_err && r_write) begin", "        S_FILLDONE: if (1'b0) begin",
     "write-allocate does not merge the store into the refilled line", "base"),
    ("C6", "sfmem_cache.sv", "wire idle_ok  = (st == S_IDLE) && !cmo_valid;", "wire idle_ok  = (st == S_IDLE);",
     "no implicit fence: accesses accepted while a maintenance command is pending", "base"),
    ("C7", "sfmem_cache.sv", "      if (nen[n] && a >= {nb[n*32+2 +: 30], 2'b00} && a < nl[n*32 +: 32]) c = 1'b0;", "      ;",
     "non-cacheable windows ignored", "base"),
    ("C8", "sfmem_cache.sv", "if (CACH[r] && ren[r] &&", "if (CACH[r] &&", "CACHE_REGIONS ignored", "base"),
    ("C9", "sfmem_cache.sv", "          if (!beat_err) begin\n            tag_q[lix(r_set, r_way)]   <= r_tag;",
     "          if (1'b1) begin\n            tag_q[lix(r_set, r_way)]   <= r_tag;", "a failed refill installs the line", "base"),
    ("C10", "sfmem_cache.sv", "                if (m_d && !c_op[0]) c_disc <= 1'b1;", "                ;",
     "DIRTY_DISCARD never reported", "base"),
    ("R1", "sfmem_regs.sv", "if (acc && !req_write && is_sem && sem_q[sem_i] == 3'd0) sem_q[sem_i] <= req_master + 3'd1;",
     ";", "semaphore read does not acquire (no mutual exclusion)", "base"),
    ("R2", "sfmem_regs.sv", "        if (!err_st[0]) begin\n          err_st[0]  <= 1'b1;", "        if (1'b1) begin\n          err_st[0]  <= 1'b1;",
     "error log overwritten by later errors (first error lost)", "base"),
    ("R3", "sfmem_regs.sv", "    if (req_write && !full) bad = 1'b1;", "    ;", "sub-word register writes not refused", "base"),
    ("R4", "sfmem_regs.sv", "            sfmem_map_pkg::MC_CACHE_REGIONS: creg_q <= req_wdata[NRG-1:0] & sfmem_map_pkg::CACHEABLE;",
     "            sfmem_map_pkg::MC_CACHE_REGIONS: creg_q <= req_wdata[NRG-1:0];",
     "non-cacheable regions can be enabled in CACHE_REGIONS", "base"),
]
CFG = {"base": Config(), "lat2": Config(sram_rd_lat=2, sram_banks=4)}
SUITE = gen_tests.SCENARIOS.keys() - {"reset", "stream", "smoke"}
STALLS = {"none": "+gap=0 +stall=0 +slv_stall=0 +jitter=0", "mid": "+gap=20 +stall=25 +slv_stall=25 +jitter=3"}


def prepare():
    for c, cfg in CFG.items():
        for sc in SUITE:
            p = BUILD / "progs" / f"{c}-{sc}"
            if not (p / "meta.json").exists():
                gen_tests.generate(sc, p, cfg, 1)


def run_mutant(mt):
    mid, fn, orig, mut, desc, cfgname = mt
    d = BUILD / mid
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(ROOT / "rtl", d / "rtl")
    src = (d / "rtl" / fn).read_text()
    if src.count(orig) != 1:
        return dict(id=mid, desc=desc, status="NOT APPLIED", note=f"pattern found {src.count(orig)} times")
    (d / "rtl" / fn).write_text(src.replace(orig, mut))
    files = (ROOT / "rtl/files.f").read_text().replace("rtl/sfmem", f"{d}/rtl/sfmem").replace(
        "+incdir+rtl", f"+incdir+{d}/rtl").replace("rtl/silicaflux_memory", f"{d}/rtl/silicaflux_memory")
    (d / "files.f").write_text(files)
    defs = [f"-D{k}={v}" for k, v in CFG[cfgname].defines().items()]
    r = subprocess.run(["iverilog", "-g2012", *defs, "-o", str(d / "sim.vvp"), "-f", str(d / "files.f"), "-f",
                        "tb/files_tb.f", "-s", "tb_sfmem"], cwd=ROOT, capture_output=True, text=True)
    if r.returncode:
        return dict(id=mid, desc=desc, status="KILLED (compile)", killed_by=["compile"], note=r.stderr[-200:])
    killers = []
    for sc in sorted(SUITE):
        for st, args in STALLS.items():
            o = subprocess.run(["vvp", "-n", str(d / "sim.vvp"), f"+prog={BUILD / 'progs' / f'{cfgname}-{sc}'}",
                                "+timeout=400000", *args.split()], cwd=ROOT, capture_output=True, text=True,
                               timeout=900).stdout
            if "RESULT: PASS" not in o:
                killers.append(f"{sc}/{st}")
        if len(killers) >= 3:
            break
    return dict(id=mid, file=fn, desc=desc, config=cfgname, status="KILLED" if killers else "SURVIVED",
                killed_by=killers)


def main() -> int:
    t0 = time.time()
    prepare()
    with cf.ThreadPoolExecutor(4) as ex:
        res = list(ex.map(run_mutant, MUTANTS))
    for r in res:
        print(f"{r['id']:<4} {r['status']:<18} {r['desc']}  {','.join(r.get('killed_by', [])[:3])}")
    killed = sum(r["status"].startswith("KILLED") for r in res)
    REPORTS.mkdir(exist_ok=True)
    js = dict(generated=time.strftime("%Y-%m-%d %H:%M:%S"), mutants=len(res), killed=killed, suite=sorted(SUITE),
              stalls=list(STALLS), wall_s=round(time.time() - t0, 1), results=res)
    (REPORTS / "mutation.json").write_text(json.dumps(js, indent=1))
    L = ["# MemoryCore mutation testing", "", f"Generated by `scripts/run_mutants.py` ({js['generated']}).", "",
         f"**{killed} / {len(res)} mutants killed** by the suite: {', '.join(sorted(SUITE))} -- each without and with "
         "random stalls (Icarus 12); a mutant is killed by the first failing run (up to 3 listed).", "",
         "| Id | File | Deliberate bug | Config | Result | First failing runs |", "|---|---|---|---|---|---|"]
    for r in res:
        L.append(f"| {r['id']} | {r.get('file', '')} | {r['desc']} | {r.get('config', '')} | {r['status']} | "
                 f"{', '.join(r.get('killed_by', [])[:3])} |")
    (REPORTS / "mutation.md").write_text("\n".join(L) + "\n")
    print(f"{killed}/{len(res)} killed in {js['wall_s']} s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
