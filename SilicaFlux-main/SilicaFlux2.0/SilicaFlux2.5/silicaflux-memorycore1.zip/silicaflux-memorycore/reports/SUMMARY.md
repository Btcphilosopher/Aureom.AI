# MemoryCore results summary

Collected by `scripts/make_report.py` on 2026-11-10 15:03:22 from the JSON / log files in `reports/`. RTL simulation only: no FPGA board, no silicon, no timing closure.

| Check | Result | Report |
|---|---|---|
| Regression: 14 directed scenarios + random + reset, 12 RTL configurations, 3 stall profiles, Icarus 12 + Verilator 5.020 | **588 / 588** runs pass; 60 / 60 Icarus/Verilator pairs cycle-identical | `reports/regression.md` |
| Operations / checked reads (model) / scoreboard-checked SRAM+LMEM reads | 1,114,870 / 350,380 / 634,954; protocol violations 0 | `reports/regression.md` |
| Definition of done: ControlCore + system DMA + vector engine + TensorCore on the RTL (5 variants Verilator + Icarus) | **6 / 6** PASS; 456 checks per run, 0 failures | `reports/system.md` |
| Shared SRAM vs MemoryLab / BandwidthLab model, transaction by transaction | **49 / 49** identical (235,200 events) | `reports/bwlab_compare.md` |
| MBIST through the subsystem test ports (March C-, injected faults) | 9 checks, 0 failures | `reports/mbist.log` |
| Mutation testing (deliberate RTL bugs) | **25 / 25** killed | `reports/mutation.md` |
| Lint / elaboration | 10 / 10 legal configurations clean (Verilator -Wall 0 warnings, Icarus); 10 / 10 illegal rejected; Yosys check -assert 3 / 3, 0 latches; map rules 9 / 9 | `reports/lint.md` |
| Yosys generic synthesis (arrays as black boxes; no technology / timing) | nocache_noperf: 25,081 cells, noperf: 62,755 cells, default: 72,324 cells, icache: 94,125 cells; latches 0 | `reports/synth.md` |
| Measured bandwidth (8 banks, 6 requesters) | 23.928 B / cycle sustained (5.982 words / cycle); EXT caching 20.0 → 1.416 cycles per load | `docs/10_PERFORMANCE.md` |
