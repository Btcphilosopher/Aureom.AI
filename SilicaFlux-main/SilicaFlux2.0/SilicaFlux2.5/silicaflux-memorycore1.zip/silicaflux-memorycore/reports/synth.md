# MemoryCore generic logic synthesis (Yosys 0.33)

`syn/run_synth.sh`: `read_verilog -defer -sv -DSYNTHESIS` of `rtl/files.f` with the SRAM library's GENERIC 1RW array replaced by a black box (`syn/sram_generic_1rw_blackbox.sv`, i.e. every array is a macro), `hierarchy -check`, `synth -top silicaflux_memory_subsystem -flatten`, `check -assert`, `stat`. Yosys internal gate library — no technology mapping, no timing, no area in um^2. Raw logs: `reports/synth/`.

## nocache_noperf (DCACHE_EN = 0, PERF_EN = 0)

Latches inferred: 0; `check -assert`: clean.

```
=== silicaflux_memory_subsystem ===
   Number of wires:              22734
   Number of wire bits:          44077
   Number of public wires:        1293
   Number of public wire bits:   22472
   Number of memories:               0
   Number of memory bits:            0
   Number of processes:              0
   Number of cells:              25081
     $_ANDNOT_                    5027
     $_AND_                        309
     $_DFFE_PN0P_                  479
     $_DFFE_PN1P_                    1
     $_DFFE_PP_                   1299
     $_DFF_PN0_                    132
     $_DFF_P_                      137
     $_MUX_                       9431
     $_NAND_                       255
     $_NOR_                        797
     $_NOT_                       1698
     $_ORNOT_                      743
     $_OR_                        3580
     $_XNOR_                       384
     $_XOR_                        799
     $paramod$283da6172b1a3daa69a5bdb692d0a9f7c140d1f7\sram_generic_1rw      2
     $paramod$311572fdebc71106076c220bbb177050e55ffda0\sram_generic_1rw      8
Warnings: 13 unique messages, 22 total
End of script. Logfile hash: 04008bff8c, CPU: user 29.95s system 0.39s, MEM: 608.42 MB peak
Yosys 0.33 (git sha1 2584903a060)
Time spent: 30% 76x opt_expr (9 sec), 16% 31x opt_clean (5 sec), ...
```

## noperf (default, PERF_EN = 0)

Latches inferred: 0; `check -assert`: clean.

```
=== silicaflux_memory_subsystem ===
   Number of wires:              56723
   Number of wire bits:          82726
   Number of public wires:        1540
   Number of public wire bits:   27040
   Number of memories:               0
   Number of memory bits:            0
   Number of processes:              0
   Number of cells:              62755
     $_ANDNOT_                   20530
     $_AND_                        381
     $_DFFE_PN0P_                  842
     $_DFFE_PN1P_                    1
     $_DFFE_PP_                   4434
     $_DFF_PN0_                    166
     $_DFF_P_                      137
     $_MUX_                      11037
     $_NAND_                       741
     $_NOR_                       1061
     $_NOT_                       2181
     $_ORNOT_                     1154
     $_OR_                       18455
     $_SDFFCE_PP0P_                  4
     $_XNOR_                       476
     $_XOR_                       1143
     $paramod$283da6172b1a3daa69a5bdb692d0a9f7c140d1f7\sram_generic_1rw      2
     $paramod$311572fdebc71106076c220bbb177050e55ffda0\sram_generic_1rw      8
     $paramod$806d5da867856d23fa51ea58489647805bb143f1\sram_generic_1rw      2
Warnings: 14 unique messages, 23 total
End of script. Logfile hash: cde7049ba5, CPU: user 63.76s system 0.64s, MEM: 890.04 MB peak
Yosys 0.33 (git sha1 2584903a060)
Time spent: 31% 101x opt_expr (21 sec), 15% 35x opt_clean (10 sec), ...
```

## default (default (D-cache, counters))

Latches inferred: 0; `check -assert`: clean.

```
=== silicaflux_memory_subsystem ===
   Number of wires:              64993
   Number of wire bits:          91076
   Number of public wires:        1552
   Number of public wire bits:   27132
   Number of memories:               0
   Number of memory bits:            0
   Number of processes:              0
   Number of cells:              72324
     $_ANDNOT_                   24139
     $_AND_                        407
     $_DFFE_PN0N_                 1310
     $_DFFE_PN0P_                  842
     $_DFFE_PN1P_                    1
     $_DFFE_PP_                   4434
     $_DFF_PN0_                    167
     $_DFF_P_                      137
     $_MUX_                      11191
     $_NAND_                      1948
     $_NOR_                       1095
     $_NOT_                       2331
     $_ORNOT_                     1222
     $_OR_                       20036
     $_SDFFCE_PP0P_                  4
     $_XNOR_                      1069
     $_XOR_                       1979
     $paramod$283da6172b1a3daa69a5bdb692d0a9f7c140d1f7\sram_generic_1rw      2
     $paramod$311572fdebc71106076c220bbb177050e55ffda0\sram_generic_1rw      8
     $paramod$806d5da867856d23fa51ea58489647805bb143f1\sram_generic_1rw      2
Warnings: 14 unique messages, 23 total
End of script. Logfile hash: bc3ea00e31, CPU: user 73.19s system 0.63s, MEM: 982.97 MB peak
Yosys 0.33 (git sha1 2584903a060)
Time spent: 32% 105x opt_expr (24 sec), 16% 37x opt_clean (12 sec), ...
```

## icache (default + ICACHE_EN = 1)

Latches inferred: 0; `check -assert`: clean.

```
=== silicaflux_memory_subsystem ===
   Number of wires:              83493
   Number of wire bits:         113798
   Number of public wires:        1773
   Number of public wire bits:   31423
   Number of memories:               0
   Number of memory bits:            0
   Number of processes:              0
   Number of cells:              94125
     $_ANDNOT_                   32677
     $_AND_                        481
     $_DFFE_PN0N_                 1374
     $_DFFE_PN0P_                 1072
     $_DFFE_PN1P_                    1
     $_DFFE_PP_                   7420
     $_DFF_PN0_                    177
     $_DFF_P_                      137
     $_MUX_                      12018
     $_NAND_                      2220
     $_NOR_                       1279
     $_NOT_                       2686
     $_ORNOT_                     1638
     $_OR_                       27413
     $_XNOR_                      1206
     $_XOR_                       2312
     $paramod$283da6172b1a3daa69a5bdb692d0a9f7c140d1f7\sram_generic_1rw      2
     $paramod$311572fdebc71106076c220bbb177050e55ffda0\sram_generic_1rw      8
     $paramod$806d5da867856d23fa51ea58489647805bb143f1\sram_generic_1rw      4
Warnings: 14 unique messages, 24 total
End of script. Logfile hash: a1b68e1640, CPU: user 97.85s system 0.93s, MEM: 1116.40 MB peak
Yosys 0.33 (git sha1 2584903a060)
Time spent: 31% 106x opt_expr (32 sec), 17% 38x opt_clean (18 sec), ...
```

