#!/usr/bin/env python3
"""MemoryCore memory reference model (transaction level, independent of the RTL).

Executes requester accesses in an order the caller chooses and returns, for each, (error, read_data) exactly as
silicaflux_memory_subsystem must answer them, plus the architecturally visible side effects:

  * the generated address map (generated/sfmem_map.py): decode priority MISALIGNED > UNMAPPED > DENIED > OWNERSHIP,
    access matrix, MEMCTL page, VSPM partition ownership;
  * byte-addressed little-endian memories (SRAM, LMEM, EXT window, VSPM window, MMIO echo pages of the testbench)
    with the testbench's initial content f(addr);
  * odd byte parity with injection and check disable (ECC_MODE = 1);
  * the ControlCore caches: geometry, first-invalid-then-tree-PLRU replacement, write-back + write-allocate or
    write-through + no-write-allocate, cacheability (map, enable, non-cacheable windows), refill / write-back
    order and errors, CLEAN / INVAL / CLEAN_INVAL on ALL or a range;
  * MEMCTL: every register's read value and refusal rule, error log (first capture, overflow, count), IRQ status,
    semaphores (test-and-set), and every timing-independent performance counter.

The model knows nothing about cycles: a test that wants exact expectations must keep concurrent requesters on
disjoint data (gen_tests.py does), or mark the read unchecked -- the testbench's serialization scoreboard then
checks it against the bank order.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "generated"))
import sfmem_map as MAP  # noqa: E402

M_DBG, M_CPUI, M_CPUD, M_SDMA, M_VDMA, M_TDMA = range(6)
REG = {r["name"]: r for r in MAP.REGIONS}
RIDX = {r["name"]: i for i, r in enumerate(MAP.REGIONS)}
NR = len(MAP.REGIONS)
MC = MAP.MEMCTL
PC = MAP.PERF
ERR = MAP.ERR
MEMCTL_BASE = MAP.PAGES["MEMCTL"]["base"]
NSEM = 8

# testbench device behaviour (tb/tb_sfmem.sv) -- part of the test environment, not of MemoryCore
TB_EXT_LO, TB_EXT_HI = 0x8000_0000, 0x8010_0000          # modelled external storage (1 MiB)
TB_EXT_ERR = (0x8F00_0000, 0x8F00_1000)                  # static error window of the EXT model
TB_IO_ERR = (0x4001_F000, 0x4002_0000)                   # MMIO page 31: unmapped register page
TB_CTRL_PAGE = 0x4001_E000                               # page 30: +0 dynamic EXT error base, +4 limit


def init_word(a: int) -> int:
    return (((a & ~3) * 0x9E3779B1) ^ 0xA5A5A5A5) & 0xFFFFFFFF


def in_region(a: int, name: str) -> bool:
    r = REG[name]
    return r["base"] <= a < r["base"] + r["size"]


@dataclass
class Config:
    sram_banks: int = 8
    sram_rd_lat: int = 1
    ecc_mode: int = 1
    dcache_en: int = 1
    icache_en: int = 1
    dcache_wb: int = 1
    cache_line: int = 16
    cache_sets: int = 64
    cache_ways: int = 2
    ext_lat: int = 8
    max_out: int = 4
    sram_arb: int = 0

    def defines(self) -> dict:
        return {"SRAM_BANKS": self.sram_banks, "SRAM_RD_LAT": self.sram_rd_lat, "ECC_MODE": self.ecc_mode,
                "DCACHE_EN": self.dcache_en, "ICACHE_EN": self.icache_en, "DCACHE_WB": self.dcache_wb,
                "CACHE_LINE": self.cache_line, "CACHE_SETS": self.cache_sets, "CACHE_WAYS": self.cache_ways,
                "EXT_LAT": self.ext_lat, "MAX_OUT": self.max_out, "SRAM_ARB": self.sram_arb}


# ============================================================================= cache
@dataclass
class Line:
    valid: bool = False
    dirty: bool = False
    tag: int = 0
    data: list = field(default_factory=list)


class Cache:
    """Exact architectural model of rtl/sfmem_cache.sv."""

    def __init__(self, sys_: "RefModel", midx: int, line: int, sets: int, ways: int, wb: bool):
        self.sys, self.midx, self.lb, self.sets, self.ways, self.wb = sys_, midx, line, sets, ways, wb
        self.wpl = line // 4
        self.offw = line.bit_length() - 1
        self.setw = sets.bit_length() - 1
        self.wl = max(1, (ways - 1).bit_length()) if ways > 1 else 1
        self.reset()

    def reset(self):
        self.l = [[Line(data=[0] * self.wpl) for _ in range(self.ways)] for _ in range(self.sets)]
        self.plru = [0] * self.sets
        self.enable = False

    # ---------------------------------------------------------------- tree PLRU (same encoding as the RTL)
    def victim_plru(self, t: int) -> int:
        if self.ways == 1:
            return 0
        node = 0
        for _ in range(self.wl):
            node = 2 * node + 2 if (t >> node) & 1 else 2 * node + 1
        return node - (self.ways - 1)

    def touch(self, s: int, w: int):
        if self.ways == 1:
            return
        t = self.plru[s]
        for n in range(self.ways - 1):
            lvl = (n + 1).bit_length() - 1
            pos = n - ((1 << lvl) - 1)
            if (w >> (self.wl - lvl)) == pos:
                bit = 0 if (w >> (self.wl - 1 - lvl)) & 1 else 1
                t = (t & ~(1 << n)) | (bit << n)
        self.plru[s] = t

    # ---------------------------------------------------------------- helpers
    def split(self, a: int):
        return (a >> self.offw) & (self.sets - 1), a >> (self.offw + self.setw), (a >> 2) & (self.wpl - 1)

    def line_addr(self, s: int, tag: int) -> int:
        return ((tag << (self.offw + self.setw)) | (s << self.offw)) & 0xFFFFFFFF

    def cacheable(self, a: int) -> bool:
        if not self.enable or a & 3:
            return False
        ok = False
        for i, r in enumerate(MAP.REGIONS):
            if r["cacheable"] and self.sys.creg >> i & 1 and self.sys.allowed(self.midx, i) and \
                    r["base"] <= a < r["base"] + r["size"]:
                ok = True
        for n in range(2):
            b, lim = self.sys.ncw_base[n], self.sys.ncw_limit[n]
            if b & 1 and (b & ~3) <= a < lim:
                ok = False
        return ok

    def lookup(self, s: int, tag: int):
        for w in range(self.ways):
            ln = self.l[s][w]
            if ln.valid and ln.tag == tag:
                return w
        return None

    def evict(self, s: int, w: int, in_cmo: bool) -> bool:
        """Write the dirty line back (WPL word writes, all issued even after an error).  Returns the error flag."""
        ln = self.l[s][w]
        base = self.line_addr(s, ln.tag)
        err = False
        for k in range(self.wpl):
            e, _ = self.sys.port_access(self.midx, True, base + 4 * k, ln.data[k], 0xF)
            err |= e
        ln.dirty = False
        self.sys.count(PC["DC_WB"])
        if err:
            self.sys.error_event(ERR["WRITEBACK"], self.midx, base, True, wb=True)
        return err

    # ---------------------------------------------------------------- an access from the requester
    def access(self, write: bool, a: int, wdata: int, strb: int):
        if not self.cacheable(a):
            e, d = self.sys.port_access(self.midx, write, a, wdata, strb)
            if self.midx == M_CPUD:
                self.sys.count(PC["DC_BYPASS"])
            return e, d
        s, tag, word = self.split(a)
        w = self.lookup(s, tag)
        is_d = self.midx == M_CPUD
        if w is not None:
            self.sys.count(PC["DC_HIT"] if is_d else PC["IC_HIT"])
            self.touch(s, w)
            ln = self.l[s][w]
            if not write:
                return False, ln.data[word]
            if self.wb:
                ln.data[word] = merge(ln.data[word], wdata, strb)
                ln.dirty = True
                return False, 0
            e, _ = self.sys.port_access(self.midx, True, a, wdata, strb)       # write-through hit
            if not e:
                ln.data[word] = merge(ln.data[word], wdata, strb)
            return e, 0
        self.sys.count(PC["DC_MISS"] if is_d else PC["IC_MISS"])
        if write and not self.wb:                                            # write-through, no allocation
            e, _ = self.sys.port_access(self.midx, True, a, wdata, strb)
            return e, 0
        inv = [x for x in range(self.ways) if not self.l[s][x].valid]
        v = inv[0] if inv else self.victim_plru(self.plru[s])
        ln = self.l[s][v]
        if self.wb and ln.valid and ln.dirty:
            self.evict(s, v, False)
        ln.valid = False
        base = a & ~(self.lb - 1)
        ferr, data = False, []
        for k in range(self.wpl):
            e, d = self.sys.port_access(self.midx, False, base + 4 * k, 0, 0)
            ferr |= e
            data.append(d)
        ln.data = data
        if ferr:
            return True, 0
        ln.tag, ln.valid, ln.dirty = tag, True, bool(write)
        self.touch(s, v)
        if write:
            ln.data[word] = merge(ln.data[word], wdata, strb)
            return False, 0
        return False, ln.data[word]

    # ---------------------------------------------------------------- maintenance
    def cmo(self, op: int, all_: bool, addr: int, size: int):
        """Returns (lines, wb_err, discard)."""
        lines, wberr, disc = 0, False, False
        cands = []
        if all_:
            cands = [(s, w) for s in range(self.sets) for w in range(self.ways)]
        elif size:
            first = addr & ~(self.lb - 1)
            end = addr + size
            last = 0xFFFFFFFF & ~(self.lb - 1) if end > 1 << 32 else ((end - 1) & 0xFFFFFFFF) & ~(self.lb - 1)
            la = first
            while True:
                s, tag, _ = self.split(la)
                w = self.lookup(s, tag)
                cands.append((s, w))
                if la == last:
                    break
                la = (la + self.lb) & 0xFFFFFFFF
        for s, w in cands:
            if w is None or not self.l[s][w].valid:
                continue
            ln = self.l[s][w]
            lines += 1
            self.sys.count(PC["CMO_LINES"])
            if op & 1 and ln.dirty and self.wb:
                wberr |= self.evict(s, w, True)
            if op & 2:
                if ln.dirty and not op & 1:
                    disc = True
                ln.valid = ln.dirty = False
        return lines, wberr, disc


def merge(old: int, new: int, strb: int) -> int:
    for b in range(4):
        if strb >> b & 1:
            old = (old & ~(0xFF << 8 * b)) | (new & (0xFF << 8 * b))
    return old & 0xFFFFFFFF


# ============================================================================= system
class RefModel:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.mem: dict[int, int] = {}            # word address -> value (all regions + TB MMIO echo)
        self.badpar: dict[int, int] = {}         # word address -> lanes stored with inverted parity
        self.dc = Cache(self, M_CPUD, cfg.cache_line, cfg.cache_sets, cfg.cache_ways, bool(cfg.dcache_wb)) \
            if cfg.dcache_en else None
        self.ic = Cache(self, M_CPUI, cfg.cache_line, cfg.cache_sets, cfg.cache_ways, False) if cfg.icache_en else None
        self.ext_dyn = [0, 0]                    # TB control page: dynamic EXT error window
        self.reset_regs()

    def reset_regs(self):
        self.ctrl = 0
        self.creg = sum(1 << i for i, r in enumerate(MAP.REGIONS) if r["cache_default"])
        self.cmo_addr = self.cmo_size = 0
        self.cmo_done = self.cmo_wberr = self.cmo_disc = False
        self.cmo_lines = 0
        self.ncw_base, self.ncw_limit = [0, 0], [0, 0]
        self.err_st, self.err_addr, self.err_info, self.err_cnt = 0, 0, 0, 0
        self.irq_en = self.irq_st = 0
        self.inj_lanes, self.inj, self.inj_lmem, self.chk_dis = 0, False, False, False
        self.par_addr = self.par_info = self.par_cnt = 0
        self.own = 0
        self.sem = [0] * NSEM
        self.frozen = False
        self._frozen_at_start = False
        self.pc = [0] * len(PC)
        self._pending_clear = False
        if self.dc:
            self.dc.reset()
        if self.ic:
            self.ic.reset()

    def reset(self):
        """Asynchronous reset: control state and caches; memory contents are kept (arrays are never reset)."""
        self.reset_regs()
        self.ext_dyn = [0, 0]                    # the testbench control page is reset too

    # ---------------------------------------------------------------- helpers
    def allowed(self, m: int, r: int) -> bool:
        return bool(MAP.ACCESS_EN >> (m * NR + r) & 1)

    def count(self, idx: int, n: int = 1):
        if not self._frozen_at_start:
            self.pc[idx] = (self.pc[idx] + n) & 0xFFFFFFFF

    def rdw(self, a: int) -> int:
        return self.mem.get(a >> 2, init_word(a))

    def error_event(self, cause: int, m: int, addr: int, write: bool, wb: bool = False):
        if not self.err_st & 1:
            self.err_st |= 1
            self.err_addr = addr & 0xFFFFFFFF
            self.err_info = (int(write) << 7) | (m << 4) | cause
        else:
            self.err_st |= 2
        self.err_cnt = min(self.err_cnt + 1, 0xFFFFFFFF)
        self.irq_st |= 1
        if wb:
            self.irq_st |= 8
        self.count(PC["ERRORS"])

    def decode(self, m: int, a: int):
        """Returns (target, cause): target in LMEM/SRAM/MMIO/VSPM/EXT/REGS, or None with an error cause."""
        if a & 3:
            return None, ERR["MISALIGNED"]
        hit = [i for i, r in enumerate(MAP.REGIONS) if r["base"] <= a < r["base"] + r["size"]]
        if not hit:
            return None, ERR["UNMAPPED"]
        r = hit[0]
        name = MAP.REGIONS[r]["name"]
        if not self.allowed(m, r):
            return None, ERR["DENIED"]
        if name == "VSPM":
            psz = REG["VSPM"]["size"] // REG["VSPM"]["partitions"]
            if self.own >> ((a - REG["VSPM"]["base"]) // psz) & 1:
                return None, ERR["OWNERSHIP"]
        if name == "MMIO" and (a - REG["MMIO"]["base"]) // MAP.PAGE_SIZE == MAP.PAGES["MEMCTL"]["index"]:
            return "REGS", 0
        return name, 0

    # ---------------------------------------------------------------- top-level access
    def access(self, m: int, write: bool, a: int, wdata: int = 0, strb: int = 0xF):
        a &= 0xFFFFFFFF
        self._frozen_at_start = self.frozen
        if m == M_CPUD and self.dc:
            res = self.dc.access(write, a, wdata, strb)
        elif m == M_CPUI and self.ic:
            res = self.ic.access(write, a, wdata, strb)
        else:
            res = self.port_access(m, write, a, wdata, strb)
        if self._pending_clear:
            self.pc = [0] * len(PC)
            self._pending_clear = False
        return res

    def port_access(self, m: int, write: bool, a: int, wdata: int, strb: int):
        tgt, cause = self.decode(m, a)
        if tgt is None:
            self.error_event(cause, m, a, write)
            return True, 0
        if tgt in ("SRAM", "LMEM"):
            return self.banked(m, tgt, write, a, wdata, strb)
        if tgt == "REGS":
            res = self.regs(m, write, a, wdata, strb)
            self.count(PC["MMIO_TXN"])
            return res
        # narrow downstream targets of the testbench
        err = False
        if tgt == "EXT":
            self.count(PC["EXT_TXN"])
            err = not (TB_EXT_LO <= a < TB_EXT_HI) or TB_EXT_ERR[0] <= a < TB_EXT_ERR[1] or \
                self.ext_dyn[0] <= a < self.ext_dyn[1]
        elif tgt == "VSPM":
            self.count(PC["VSPM_TXN"])
        elif tgt == "MMIO":
            self.count(PC["MMIO_TXN"])
            err = TB_IO_ERR[0] <= a < TB_IO_ERR[1] or (write and strb != 0xF)
            if write and not err and (a & ~0xFFF) == TB_CTRL_PAGE and (a & 0xFFF) < 8:
                self.ext_dyn[(a & 0xFFF) >> 2] = wdata
        if err:
            self.error_event(ERR["TARGET"], m, a, write)
            return True, 0
        if write:
            self.mem[a >> 2] = merge(self.rdw(a), wdata, strb)
            return False, 0
        return False, self.rdw(a)

    def banked(self, m: int, tgt: str, write: bool, a: int, wdata: int, strb: int):
        if tgt == "SRAM":
            self.count(PC[f"SRAM_ACC_M{m}"])
            bank = (a >> 2) & (self.cfg.sram_banks - 1)
            if bank < 8:
                self.count(PC[f"SRAM_BANK{bank}"])
            if write:
                self.count(PC["SRAM_WR_BYTES"], bin(strb).count("1"))
            else:
                self.count(PC["SRAM_RD_BYTES"], 4)
        else:
            self.count(PC["LMEM_ACC"])
        if write:
            self.mem[a >> 2] = merge(self.rdw(a), wdata, strb)
            if self.cfg.ecc_mode == 1:
                bad = self.badpar.get(a >> 2, 0) & ~strb
                if self.inj and self.inj_lmem == (tgt == "LMEM"):
                    bad |= self.inj_lanes & strb
                    self.inj = False
                self.badpar[a >> 2] = bad
            return False, 0
        syn = self.badpar.get(a >> 2, 0) if self.cfg.ecc_mode == 1 else 0
        if syn and not self.chk_dis:
            self.error_event(ERR["PARITY"], m, a, False)
            self.par_addr = a
            self.par_info = (int(tgt == "LMEM") << 8) | (m << 4) | syn
            self.par_cnt = min(self.par_cnt + 1, 0xFFFFFFFF)
            self.irq_st |= 2
            return True, 0
        return False, self.rdw(a)

    # ---------------------------------------------------------------- MEMCTL
    def info_value(self) -> int:
        c = self.cfg
        return (6 << 24) | ((MAP.REGIONS[RIDX["LMEM"]]["banks"].bit_length() - 1) << 21) | (c.ecc_mode << 19) | \
            (int(bool(c.dcache_en and c.dcache_wb)) << 18) | (int(bool(c.dcache_en)) << 17) | \
            (int(bool(c.icache_en)) << 16) | (c.sram_rd_lat << 12) | ((c.sram_banks.bit_length() - 1) << 8) | \
            MAP.MAP_VERSION

    def cache_info_value(self) -> int:
        c = self.cfg
        return (int(bool(c.dcache_wb)) << 17) | (int(bool(c.dcache_wb)) << 16) | (c.cache_ways << 12) | \
            ((c.cache_sets.bit_length() - 1) << 4) | (c.cache_line.bit_length() - 1)

    def regs(self, m: int, write: bool, a: int, wd: int, strb: int):
        off = a & 0xFFF
        full = strb == 0xF
        ro = {MC["ID"]: MAP.MEMCTL_ID_VALUE, MC["INFO"]: self.info_value(), MC["CACHE_INFO"]: self.cache_info_value(),
              MC["SRAM_SIZE"]: REG["SRAM"]["size"], MC["ERR_ADDR"]: self.err_addr, MC["ERR_INFO"]: self.err_info,
              MC["ERR_COUNT"]: self.err_cnt, MC["ECC_ERR_ADDR"]: self.par_addr, MC["ECC_ERR_INFO"]: self.par_info,
              MC["ECC_ERR_COUNT"]: self.par_cnt,
              MC["CMO_STATUS"]: (self.cmo_lines << 16) | (int(self.cmo_disc) << 3) | (int(self.cmo_wberr) << 2) |
              (int(self.cmo_done) << 1)}
        rw = {MC["CACHE_CTRL"]: self.ctrl, MC["CMO_ADDR"]: self.cmo_addr, MC["CMO_SIZE"]: self.cmo_size,
              MC["CACHE_REGIONS"]: self.creg,
              MC["NCW0_BASE"]: self.ncw_base[0], MC["NCW0_LIMIT"]: self.ncw_limit[0],
              MC["NCW1_BASE"]: self.ncw_base[1], MC["NCW1_LIMIT"]: self.ncw_limit[1],
              MC["ERR_STATUS"]: self.err_st, MC["IRQ_ENABLE"]: self.irq_en, MC["IRQ_STATUS"]: self.irq_st,
              MC["ECC_CTRL"]: (int(self.chk_dis) << 16) | (int(self.inj_lmem) << 9) | (int(self.inj) << 8) |
              self.inj_lanes,
              MC["VSPM_OWN"]: self.own, MC["PERF_CTRL"]: int(self.frozen), MC["CMO_CMD"]: 0}
        sem0, pcb = MC["SEM0"], MC["PERF_BASE"]
        bad, rdata = False, 0
        if sem0 <= off < sem0 + 4 * NSEM:
            i = (off - sem0) >> 2
            rdata = self.sem[i]
            if write:
                bad = not full or wd != 0 or self.sem[i] != m + 1
            elif self.sem[i] == 0:
                self.sem[i] = m + 1
        elif pcb <= off < pcb + 4 * len(PC):
            rdata = self.pc[(off - pcb) >> 2]
            bad = write
        elif off in ro:
            rdata, bad = ro[off], write
        elif off in rw:
            rdata = rw[off]
            if write and off == MC["CMO_CMD"]:
                bad = (wd & 3) == 0 or not (wd >> 3 & 3) or (wd >> 5) != 0
        else:
            bad = True
        if write and not full:
            bad = True
        if bad:
            self.error_event(ERR["REG"], m, MEMCTL_BASE | off, write)
            return True, 0
        if not write:
            return False, rdata
        # ------------------------------------------------ register write side effects
        if sem0 <= off < sem0 + 4 * NSEM:
            self.sem[(off - sem0) >> 2] = 0
        elif off == MC["CACHE_CTRL"]:
            self.ctrl = wd & 3
            if self.dc:
                self.dc.enable = bool(wd & 1)
            if self.ic:
                self.ic.enable = bool(wd & 2)
        elif off == MC["CMO_ADDR"]:
            self.cmo_addr = wd
        elif off == MC["CACHE_REGIONS"]:
            self.creg = wd & sum(1 << i for i, r in enumerate(MAP.REGIONS) if r["cacheable"])
        elif off == MC["CMO_SIZE"]:
            self.cmo_size = wd
        elif off == MC["CMO_CMD"]:
            self.cmo_lines, self.cmo_wberr, self.cmo_disc = 0, False, False
            op, all_ = wd & 3, bool(wd & 4)
            for sel, c in ((wd >> 3 & 1, self.dc), (wd >> 4 & 1, self.ic)):
                if sel and c:
                    ln, we, dd = c.cmo(op, all_, self.cmo_addr, self.cmo_size)
                    self.cmo_lines = (self.cmo_lines + ln) & 0xFFFF
                    self.cmo_wberr |= we
                    self.cmo_disc |= dd
            self.cmo_done = True
            self.irq_st |= 4
        elif off in (MC["NCW0_BASE"], MC["NCW1_BASE"]):
            self.ncw_base[off == MC["NCW1_BASE"]] = wd & 0xFFFFFFFD
        elif off in (MC["NCW0_LIMIT"], MC["NCW1_LIMIT"]):
            self.ncw_limit[off == MC["NCW1_LIMIT"]] = wd
        elif off == MC["ERR_STATUS"]:
            self.err_st &= ~wd & 3
        elif off == MC["IRQ_ENABLE"]:
            self.irq_en = wd & 0xF
        elif off == MC["IRQ_STATUS"]:
            self.irq_st &= ~wd & 0xF
        elif off == MC["ECC_CTRL"]:
            self.inj_lanes, self.inj_lmem, self.chk_dis = wd & 0xF, bool(wd >> 9 & 1), bool(wd >> 16 & 1)
            if wd >> 8 & 1:
                self.inj = True
        elif off == MC["VSPM_OWN"]:
            self.own = wd & ((1 << REG["VSPM"]["partitions"]) - 1)
        elif off == MC["PERF_CTRL"]:
            # RTL: this access's own events are counted under the FREEZE value it found (count() uses the
            # snapshot taken when the access started); CLEAR zeroes everything one cycle later
            self.frozen = bool(wd & 1)
            if wd & 2:
                self._pending_clear = True
        return False, 0

    # perf counters whose value depends on cycle timing (never compared exactly)
    TIMING_COUNTERS = {"CYCLES", "EXT_STALL"} | {f"SRAM_CONF_M{i}" for i in range(6)} | \
        {f"REQ_STALL_M{i}" for i in range(6)} | {"LMEM_CONF"}
