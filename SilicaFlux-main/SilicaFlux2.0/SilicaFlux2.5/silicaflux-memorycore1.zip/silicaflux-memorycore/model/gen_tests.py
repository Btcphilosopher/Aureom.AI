#!/usr/bin/env python3
"""MemoryCore test-program generator.

Every scenario drives the six requester BFMs of tb/tb_sfmem.sv.  Each operation is executed on the reference model
(model/sfmem_ref.py) as it is generated, so every expected value, error flag, register value and deterministic
performance-counter value in a program comes from the model, never from the RTL.

Concurrency rule (enforced here, not trusted to the scenario author): operations between two barriers run
concurrently on the RTL, in an order the model does not know.  At each barrier the phase is analysed:
  * a read of a word that another requester wrote in the same phase is made UNCHECKED (expected flag 2) -- the
    testbench's serialization scoreboard still checks it against the bank order;
  * a word written by two requesters in one phase is TAINTED: later reads stay unchecked until a single requester
    rewrites it in full.
Scenarios may force a check (mutual-exclusion test) when the property holds for every interleaving.

Usage:  python3 model/gen_tests.py SCENARIO OUTDIR [--seed N] [--cfg k=v ...]
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sfmem_ref import (MC, PC, REG, Config, RefModel, M_CPUD, M_CPUI, M_DBG, M_SDMA, M_TDMA,  # noqa: E402
                       M_VDMA, MEMCTL_BASE, TB_CTRL_PAGE, init_word)

SRAM, LMEM, EXT, VSPM, MMIO = (REG[n]["base"] for n in ("SRAM", "LMEM", "EXT", "VSPM", "MMIO"))
NAMES = ["DBG", "CPUI", "CPUD", "SDMA", "VDMA", "TDMA"]
CMO_CLEAN, CMO_INVAL, CMO_CI = 1, 2, 3
ALL, DC, IC = 1 << 2, 1 << 3, 1 << 4


def mc(off: str) -> int:
    return MEMCTL_BASE + MC[off]


class Gen:
    def __init__(self, cfg: Config, seed: int = 1):
        self.cfg = cfg
        self.m = RefModel(cfg)
        self.p: list[list] = [[] for _ in range(6)]
        self.bar = 0
        self.rng = random.Random(seed)
        self.phase: list = []          # (master, kind, word, prog index)
        self.tainted: set[int] = set()
        self.stats = {"checked_reads": 0, "unchecked_reads": 0, "writes": 0, "expected_errors": 0}

    # ------------------------------------------------------------------ primitive operations
    def w(self, mi: int, a: int, d: int, strb: int = 0xF) -> bool:
        e, _ = self.m.access(mi, True, a, d & 0xFFFFFFFF, strb)
        self.p[mi].append(["W", a & 0xFFFFFFFF, d & 0xFFFFFFFF, strb, int(e)])
        self.phase.append((mi, "W", a >> 2, len(self.p[mi]) - 1, strb))
        self.stats["writes"] += 1
        self.stats["expected_errors"] += int(e)
        return e

    def r(self, mi: int, a: int, check: bool = True, force: bool = False, mask: int = 0xFFFFFFFF):
        e, d = self.m.access(mi, False, a)
        exp = (1 if e else 0) if check else 2
        if check and not force and (a >> 2) in self.tainted and not e:
            exp = 2
        self.p[mi].append(["R", a & 0xFFFFFFFF, d, mask, exp])
        self.phase.append((mi, "R", a >> 2, len(self.p[mi]) - 1, 0 if force else 1))
        return e, d

    def poll(self, mi: int, a: int, value: int, mask: int = 0xFFFFFFFF, maxp: int = 100000):
        """Read until (rdata & mask) == value.  The model performs one read (the satisfying one)."""
        self.m.access(mi, False, a)
        self.p[mi].append(["P", a, value, mask, maxp])
        self.phase.append((mi, "P", a >> 2, len(self.p[mi]) - 1, 0))

    def fence(self, mi: int):
        self.p[mi].append(["F", 0, 0, 0, 0])

    def delay(self, mi: int, n: int):
        self.p[mi].append(["D", n, 0, 0, 0])

    def barrier(self):
        self._analyse_phase()
        self.bar += 1
        for mi in range(6):
            self.p[mi].append(["B", self.bar, 0, 0, 0])

    def _analyse_phase(self):
        writers: dict[int, set] = {}
        for mi, k, wd, _, strb in self.phase:
            if k == "W":
                writers.setdefault(wd, set()).add(mi)
        for mi, k, wd, idx, chk in self.phase:
            if k == "R" and chk and wd in writers and (writers[wd] - {mi}):
                if self.p[mi][idx][4] == 0:
                    self.p[mi][idx][4] = 2
        for wd, ws in writers.items():
            if len(ws) > 1:
                self.tainted.add(wd)
            else:
                full = any(k == "W" and w_ == wd and s == 0xF for _, k, w_, _, s in self.phase)
                if full:
                    self.tainted.discard(wd)
        self.phase = []

    # ------------------------------------------------------------------ helpers
    def mcw(self, mi: int, reg: str, v: int) -> bool:
        return self.w(mi, mc(reg), v)

    def cache_on(self, mi: int, ctrl: int, regions: int = 0x12):
        """Select the cached regions (default SRAM | EXT: the tests exercise SRAM caching, which software must
        enable explicitly -- CACHE_REGIONS resets to EXT only), then enable the caches."""
        self.mcw(mi, "CACHE_REGIONS", regions)
        self.mcw(mi, "CACHE_CTRL", ctrl)

    def mcr(self, mi: int, reg: str, check: bool = True):
        return self.r(mi, mc(reg), check)

    def cmo(self, mi: int, op: int, a: int = 0, size: int = 0, sel: int = DC, all_: bool = False):
        """Firmware sequence of sfmem_cmo(): ADDR, SIZE, CMD, then wait until not BUSY and read the status."""
        if not all_:
            self.mcw(mi, "CMO_ADDR", a)
            self.mcw(mi, "CMO_SIZE", size)
        self.mcw(mi, "CMO_CMD", op | sel | (ALL if all_ else 0))
        if mi == M_CPUD and sel == DC:
            self.mcr(mi, "CMO_STATUS")             # a D-port access waits for a D-cache command (implicit fence)
        else:                                      # I-cache commands and other issuers: poll BUSY
            self.poll(mi, mc("CMO_STATUS"), 0, 1)
            self.mcr(mi, "CMO_STATUS")

    def save(self, out: Path, meta: dict):
        self._analyse_phase()
        out.mkdir(parents=True, exist_ok=True)
        for mi in range(6):
            with open(out / f"m{mi}.txt", "w") as f:
                for op in self.p[mi]:
                    f.write(f"{op[0]} {op[1]:x} {op[2] & 0xFFFFFFFF:x} {op[3]:x} {op[4]:x}\n")
                    if op[0] == "R":
                        self.stats["checked_reads" if op[4] != 2 else "unchecked_reads"] += 1
        meta = dict(meta, stats=self.stats, ops=sum(len(x) for x in self.p), cfg=self.cfg.__dict__)
        (out / "meta.json").write_text(json.dumps(meta, indent=1))


# ============================================================================= scenarios
def sc_smoke(g: Gen):
    g.w(M_DBG, SRAM, 0x11223344)
    g.r(M_DBG, SRAM)
    g.r(M_SDMA, LMEM)
    g.barrier()
    g.r(M_TDMA, SRAM)


def accessible(mi: int):
    out = []
    for name, base in (("SRAM", SRAM), ("LMEM", LMEM), ("EXT", EXT), ("VSPM", VSPM)):
        if g_allowed(mi, name):
            out.append((name, base))
    return out


def g_allowed(mi: int, name: str) -> bool:
    from sfmem_ref import RIDX, MAP
    return bool(MAP.ACCESS_EN >> (mi * len(MAP.REGIONS) + RIDX[name]) & 1)


def sc_bytes(g: Gen):
    """Byte-address correctness: bytes, half-words, words, little-endian, every requester and memory."""
    for mi in range(6):
        if mi == M_CPUI:
            continue
        for name, base in accessible(mi):
            a = base + 0x400 + mi * 0x40
            for k in range(4):                                      # single bytes
                g.w(mi, a + 0, (0xA0 + k) << (8 * k), 1 << k)
            g.w(mi, a + 4, 0x0000BEEF, 0x3)                          # low half
            g.w(mi, a + 4, 0xDEAD0000, 0xC)                          # high half
            g.w(mi, a + 8, 0x01020304)
            for off in (0, 4, 8):
                g.r(mi, a + off)
    g.barrier()
    for mi in range(6):                                              # cross-requester read-back
        nx = (mi + 1) % 6
        for name, base in accessible(mi):
            if name == "LMEM" and nx >= 3:
                nx = M_DBG
            for off in (0, 4, 8):
                g.r(nx, base + 0x400 + mi * 0x40 + off)              # DENIED where the matrix says so
    g.barrier()
    for off in range(4):                                             # misaligned byte addresses are refused
        g.w(M_DBG, SRAM + 0x800 + off, 0xFF, 1 << off) if off else None
    g.r(M_DBG, SRAM + 0x800)


def sc_banks(g: Gen):
    """Every bank (first, second, middle, last row) of the shared SRAM and of LMEM, written and read by different
    requesters."""
    nb = g.cfg.sram_banks
    rows = REG["SRAM"]["size"] // 4 // nb
    writers = [M_DBG, M_CPUD, M_SDMA, M_VDMA, M_TDMA]
    addrs = []
    for b in range(nb):
        for row in (0, 1, rows // 2, rows - 1):
            addrs.append(SRAM + (row * nb + b) * 4)
    for i, a in enumerate(addrs):
        g.w(writers[i % len(writers)], a, 0x5A000000 | (i << 8) | (a & 0xFF))
    g.barrier()
    for i, a in enumerate(addrs):
        g.r(writers[(i + 2) % len(writers)], a)
    lb = REG["LMEM"]["banks"]
    lrows = REG["LMEM"]["size"] // 4 // lb
    la = [LMEM + (row * lb + b) * 4 for b in range(lb) for row in (0, 1, lrows // 2, lrows - 1)]
    g.barrier()
    for i, a in enumerate(la):
        g.w((M_DBG, M_CPUD)[i % 2], a, 0x1B000000 | i)
    g.barrier()
    for i, a in enumerate(la):
        g.r((M_CPUD, M_DBG, M_CPUI)[i % 3], a)


def sc_partial(g: Gen):
    """All 16 byte-enable patterns on every memory (MMIO: only full words are legal)."""
    for name, base, mi in (("SRAM", SRAM, M_SDMA), ("LMEM", LMEM, M_CPUD), ("EXT", EXT, M_TDMA),
                           ("VSPM", VSPM, M_DBG), ("MMIO", MMIO + 0x6000, M_DBG)):
        for strb in range(16):
            a = base + 0x200 + strb * 4
            g.w(mi, a, 0x11111111 * (strb + 1))
            g.w(mi, a, 0xA1B2C3D4 ^ (strb * 0x01010101), strb)       # MMIO: error unless strb == 0xF
            g.r(mi, a)
        g.barrier()


def sc_bounds(g: Gen):
    """Region boundaries, unmapped gaps, misalignment, the access matrix, MEMCTL refusal rules, the error log."""
    g.mcw(M_DBG, "ERR_STATUS", 3)
    g.mcr(M_DBG, "ERR_COUNT")
    for name in ("LMEM", "SRAM", "VSPM", "EXT"):
        r = REG[name]
        first, last = r["base"], r["base"] + r["size"] - 4
        top = 0x8010_0000 - 4 if name == "EXT" else last                # EXT: modelled storage ends at 1 MiB
        for a in (first, top):
            g.w(M_DBG, a, a ^ 0x5555AAAA)
            g.r(M_DBG, a)
        g.r(M_DBG, r["base"] + r["size"])                             # one past the end
        g.r(M_DBG, r["base"] - 4)                                     # one before the start
        for off in (1, 2, 3):
            g.r(M_DBG, first + off)
            g.w(M_DBG, first + off, 0, 1)
    for a in (0x0000_0000, 0x0400_0000, 0x2000_0000, 0x3000_0000, 0x5000_0000, 0x7000_0000, 0x9000_0000,
              0xC000_0000, 0xFFFF_FFFC):
        g.r(M_DBG, a)
        g.w(M_DBG, a, 1)
    g.barrier()
    # access matrix: every requester x every region (reads; writes for the data-capable requesters)
    for mi in range(6):
        for name in ("LMEM", "SRAM", "MMIO", "VSPM", "EXT"):
            a = REG[name]["base"] + (0x6000 if name == "MMIO" else 0x100) + mi * 4
            g.r(mi, a)
            if mi != M_CPUI:
                g.w(mi, a, 0xC0DE0000 | mi)
        g.barrier()
    # downstream errors: EXT error window, MMIO unmapped page, sub-word MMIO write
    g.r(M_DBG, 0x8F00_0000)
    g.w(M_DBG, 0x8F00_0010, 7)
    g.r(M_DBG, 0x4001_F000)
    g.w(M_DBG, MMIO + 0x8000, 0x1234, 0x3)
    # MEMCTL rules
    for reg in ("ID", "INFO", "CACHE_INFO", "SRAM_SIZE", "CMO_CMD", "CACHE_CTRL", "CACHE_REGIONS", "VSPM_OWN",
                "PERF_CTRL"):
        g.mcr(M_DBG, reg)
    g.w(M_DBG, mc("ID"), 0)                                           # read-only
    g.w(M_DBG, mc("CACHE_CTRL"), 1, 0x1)                              # sub-word
    g.r(M_DBG, MEMCTL_BASE + 0x300)                                   # unknown offset
    g.w(M_DBG, mc("CMO_CMD"), CMO_CLEAN)                              # no cache selected
    g.w(M_DBG, mc("CMO_CMD"), DC)                                     # OP = 0
    g.w(M_DBG, mc("CMO_CMD"), 1 << 7 | CMO_CLEAN | DC)                # reserved bits
    for reg in ("ERR_STATUS", "ERR_ADDR", "ERR_INFO", "ERR_COUNT", "IRQ_STATUS"):
        g.mcr(M_DBG, reg)
    g.mcw(M_DBG, "ERR_STATUS", 3)
    g.mcw(M_DBG, "IRQ_STATUS", 0xF)
    g.r(M_DBG, 0x0000_0002)                                           # misaligned and unmapped: MISALIGNED wins
    for reg in ("ERR_STATUS", "ERR_ADDR", "ERR_INFO"):
        g.mcr(M_DBG, reg)
    g.mcw(M_DBG, "ERR_STATUS", 1)
    g.mcr(M_DBG, "ERR_STATUS")
    g.mcr(M_DBG, "PERF_BASE")                                         # CYCLES (unchecked below)
    g.p[M_DBG][-1][4] = 2
    g.r(M_DBG, MEMCTL_BASE + MC["PERF_BASE"] + 4 * PC["ERRORS"])


def sc_multi(g: Gen):
    """Simultaneous requesters: same bank every cycle (maximum conflicts), then cross read-back; message passing
    through a flag with and without a local fence."""
    nb = g.cfg.sram_banks
    act = [M_DBG, M_CPUD, M_SDMA, M_VDMA, M_TDMA]
    for k in range(48):
        for j, mi in enumerate(act):
            a = SRAM + 0x8000 + ((j * 64 + k) * nb + (k % nb)) * 4
            g.w(mi, a, (mi << 24) | (k << 8) | j)
    g.barrier()
    for k in range(48):
        for j, mi in enumerate(act):
            a = SRAM + 0x8000 + ((j * 64 + k) * nb + (k % nb)) * 4
            g.r(act[(j + 1) % len(act)], a)
    g.barrier()
    # message passing on the same memory: data then flag, consumer polls the flag (no barrier in between)
    data, flag = SRAM + 0xC000, SRAM + 0xC100
    g.w(M_DBG, flag, 0)
    g.barrier()
    for i in range(16):
        g.w(M_DBG, data + 4 * i, 0xD0D00000 + i)
    g.w(M_DBG, flag, 1)
    g.poll(M_SDMA, flag, 1)
    for i in range(16):
        g.r(M_SDMA, data + 4 * i, force=True)          # ordered by the flag: holds for every interleaving
    g.barrier()
    # producer data in EXT (slow path), flag in SRAM: a local fence (wait for every response) before the flag
    edata, eflag = EXT + 0x4000, SRAM + 0xC200
    g.w(M_TDMA, eflag, 0)
    g.barrier()
    for i in range(16):
        g.w(M_TDMA, edata + 4 * i, 0xE0E00000 + i)
    g.fence(M_TDMA)
    g.w(M_TDMA, eflag, 1)
    g.poll(M_VDMA, eflag, 1)
    for i in range(16):
        g.r(M_VDMA, edata + 4 * i, force=True)


def sc_hazard(g: Gen):
    """RAW / WAW / WAR inside one pipelined requester (up to 4 in flight) and across requesters."""
    for mi, base in ((M_DBG, SRAM + 0x10000), (M_SDMA, EXT + 0x8000), (M_CPUD, LMEM + 0x1000), (M_TDMA, SRAM + 0x11000)):
        for i in range(32):
            a = base + 4 * (i % 4)
            g.w(mi, a, 0x1000 * mi + i)
            g.r(mi, a)                                      # RAW, back to back
            g.w(mi, a, 0xFF000000 | i, 0x8)                 # WAW partial
            g.r(mi, a)
            g.r(mi, a + 4)                                  # WAR on the next word
            g.w(mi, a + 4, i)
    g.barrier()
    x = SRAM + 0x12000
    g.w(M_DBG, x, 1)
    g.barrier()
    g.w(M_SDMA, x, 2)
    g.barrier()
    g.r(M_TDMA, x)
    g.barrier()
    # true races: checked only by the serialization scoreboard
    for i in range(64):
        g.w(M_DBG, x + 4 * (i % 4), i)
        g.w(M_SDMA, x + 4 * (i % 4), 0x100 + i)
        g.r(M_TDMA, x + 4 * (i % 4))
        g.r(M_VDMA, x + 4 * (i % 4))
    g.barrier()
    for i in range(4):
        g.r(M_DBG, x + 4 * i)                               # tainted: unchecked, scoreboard-checked


def set_size_stride(cfg: Config) -> int:
    return cfg.cache_line * cfg.cache_sets


def sc_cache(g: Gen):
    """Hits, misses, PLRU replacement, dirty evictions, write-allocate / write-through, enable / disable, counters."""
    c = g.cfg
    st = set_size_stride(c)
    base = SRAM + 0x20000
    for k in range(c.cache_line // 4 * 3):              # pre-fill memory through DBG (known values)
        g.w(M_DBG, base + 4 * k, 0x0C000000 | k)
    for w in range(c.cache_ways + 2):
        for k in range(4):
            g.w(M_DBG, base + w * st + 4 * k, 0x0D000000 | (w << 8) | k)
    g.mcw(M_DBG, "PERF_CTRL", 2)
    g.barrier()
    g.cache_on(M_CPUD, 1)
    for k in range(c.cache_line // 4 * 2):              # sequential: one miss per line, hits after
        g.r(M_CPUD, base + 4 * k)
    for k in range(c.cache_line // 4 * 2):
        g.r(M_CPUD, base + 4 * k)
    g.w(M_CPUD, base, 0x11110000)                       # write hit (WB: dirty; WT: through)
    g.w(M_CPUD, base + 5, 0x22, 0x2)                    # misaligned through the cache: bypass -> MISALIGNED
    g.w(M_CPUD, base + 4, 0x00330000, 0x4)              # byte write hit
    g.r(M_CPUD, base + 4)
    g.barrier()
    g.r(M_DBG, base)                                    # WB: stale in memory; WT: new
    g.r(M_DBG, base + 4)
    g.barrier()
    # replacement: WAYS + 2 lines in one set (conflict misses, PLRU order, dirty eviction write-backs)
    for rnd in range(3):
        for w in range(c.cache_ways + 2):
            g.r(M_CPUD, base + w * st + 4 * (rnd % 4))
            if rnd == 1:
                g.w(M_CPUD, base + w * st + 4 * (rnd % 4), 0xE0000000 | (w << 4) | rnd)
        g.r(M_CPUD, base)                               # keep line 0 recent
    g.barrier()
    for w in range(c.cache_ways + 2):
        g.r(M_DBG, base + w * st + 4)                   # which write-backs have happened is model-predicted
    g.barrier()
    # write miss: WB allocates (then hits), WT does not (next read misses)
    wm = SRAM + 0x24000
    g.w(M_CPUD, wm, 0x77777777)
    g.r(M_CPUD, wm)
    g.r(M_CPUD, wm + 4)
    # EXT window cached
    for k in range(8):
        g.r(M_CPUD, EXT + 0x10000 + 4 * k)
    g.w(M_CPUD, EXT + 0x10000, 0x5E5E5E5E)
    # disable with dirty lines: accesses bypass (memory view), re-enable: the old lines hit again
    g.mcw(M_CPUD, "CACHE_CTRL", 0)
    g.r(M_CPUD, base)
    g.r(M_CPUD, EXT + 0x10000)
    g.cache_on(M_CPUD, 1)
    g.r(M_CPUD, base)
    g.r(M_CPUD, EXT + 0x10000)
    for n in ("DC_HIT", "DC_MISS", "DC_WB", "DC_BYPASS", "SRAM_ACC_M2", "EXT_TXN", "SRAM_RD_BYTES", "SRAM_WR_BYTES",
              "MMIO_TXN", "SRAM_ACC_M0", "ERRORS"):
        g.r(M_CPUD, MEMCTL_BASE + MC["PERF_BASE"] + 4 * PC[n])
    g.cmo(M_CPUD, CMO_CI, all_=True)
    g.barrier()
    for k in range(4):
        g.r(M_DBG, base + 4 * k)
        g.r(M_DBG, EXT + 0x10000 + 4 * k)
        g.r(M_DBG, wm + 4 * k)
    g.barrier()
    # CACHE_REGIONS: only cacheable regions' bits stick; a region switched off is bypassed (no line allocated)
    g.mcw(M_CPUD, "CACHE_REGIONS", 0xFFFFFFFF)
    g.mcr(M_CPUD, "CACHE_REGIONS")
    g.mcw(M_CPUD, "CACHE_REGIONS", 0x10)                   # EXT only (the reset default)
    g.r(M_CPUD, base + 0x40)                               # SRAM: bypass
    g.r(M_CPUD, base + 0x40)
    g.r(M_CPUD, EXT + 0x12000)                             # EXT: miss then hit
    g.r(M_CPUD, EXT + 0x12000)
    for n in ("DC_HIT", "DC_MISS", "DC_BYPASS"):
        g.r(M_CPUD, MEMCTL_BASE + MC["PERF_BASE"] + 4 * PC[n])
    # replacement order: fill every way of one set, re-touch the lines in a scrambled order, then miss repeatedly;
    # which lines survive (hit / miss counts) is decided by tree-PLRU and predicted exactly by the model
    g.cache_on(M_CPUD, 1)
    g.cmo(M_CPUD, CMO_CI, all_=True)
    pl = SRAM + 0x26000
    w = c.cache_ways
    for k in (0, 1, 0, 2, 0):                              # A, B, A (hit: A becomes MRU), C (evicts B), A (hit)
        g.r(M_CPUD, pl + 0x800 + k * st)
    g.cmo(M_CPUD, CMO_CI, all_=True)
    for k in range(w):
        g.r(M_CPUD, pl + k * st)
    for k in [0] + list(range(w - 1, 0, -2)):
        g.r(M_CPUD, pl + k * st)                           # hits: update the tree
    for j in range(3):
        g.r(M_CPUD, pl + (w + j) * st)                     # misses: victims chosen by the tree
        for k in range(w):
            g.r(M_CPUD, pl + k * st)
    for n in ("DC_HIT", "DC_MISS"):
        g.r(M_CPUD, MEMCTL_BASE + MC["PERF_BASE"] + 4 * PC[n])


def sc_cmo(g: Gen):
    """Every maintenance operation: CLEAN / INVAL / CLEAN_INVAL, RANGE (aligned, unaligned, crossing, size 0) and
    ALL, status (lines, DIRTY_DISCARD, DONE), I-cache invalidation, a command issued by the debug port."""
    c = g.cfg
    lb = c.cache_line
    buf = SRAM + 0x28000
    g.cache_on(M_CPUD, 3)
    for k in range(16 * lb // 4):
        g.w(M_CPUD, buf + 4 * k, 0x3C000000 | k)          # WB: dirty lines; WT: through
    g.barrier()
    g.r(M_DBG, buf)
    g.r(M_DBG, buf + 2 * lb)
    g.barrier()
    g.cmo(M_CPUD, CMO_CLEAN, buf, 2 * lb)                 # lines 0, 1
    g.barrier()
    g.r(M_DBG, buf)
    g.r(M_DBG, buf + lb)
    g.r(M_DBG, buf + 2 * lb)                              # not cleaned (WB): stale
    g.barrier()
    g.cmo(M_CPUD, CMO_CLEAN, buf + 2 * lb + 4, lb)        # unaligned: touches lines 2 and 3
    g.cmo(M_CPUD, CMO_CLEAN, buf, 0)                      # size 0: no line
    g.w(M_CPUD, buf + 4 * lb, 0xBAD0BAD0)                 # line 4 dirty again
    g.cmo(M_CPUD, CMO_INVAL, buf + 4 * lb, lb)            # dirty data dropped (WB): DIRTY_DISCARD
    g.r(M_CPUD, buf + 4 * lb)                             # miss: memory value
    g.cmo(M_CPUD, CMO_CI, buf + 5 * lb, 3 * lb)           # lines 5..7
    g.barrier()
    for k in range(0, 8 * lb, 4):
        g.r(M_DBG, buf + k)
    g.barrier()
    g.r(M_CPUD, buf + 9 * lb)                             # hits remain for lines never operated on
    g.cmo(M_CPUD, CMO_CLEAN, all_=True)
    g.cmo(M_CPUD, CMO_INVAL, all_=True)
    g.r(M_CPUD, buf + 9 * lb)                             # miss after INVAL ALL
    # I-cache: fetch, modify behind it, stale fetch until invalidated
    code = SRAM + 0x2C000
    for k in range(8):
        g.w(M_DBG, code + 4 * k, 0x13000000 | k)
    g.barrier()
    for k in range(8):
        g.r(M_CPUI, code + 4 * k)
    g.barrier()
    g.w(M_DBG, code + 4, 0x6F000001)
    g.barrier()
    g.r(M_CPUI, code + 4)                                 # stale (I-cache on)
    g.barrier()
    g.cmo(M_CPUD, CMO_INVAL, code, 32, sel=IC)
    g.barrier()
    g.r(M_CPUI, code + 4)                                 # fresh
    g.barrier()
    # both caches in one command, issued by the debug port (polls BUSY)
    g.r(M_CPUD, buf)
    g.barrier()
    g.cmo(M_DBG, CMO_CI, all_=True, sel=DC | IC)
    g.barrier()
    g.r(M_CPUD, buf)
    g.cmo(M_CPUD, CMO_CI, all_=True, sel=DC | IC)
    g.barrier()
    for n in ("CMO_LINES", "DC_WB"):
        g.r(M_DBG, MEMCTL_BASE + MC["PERF_BASE"] + 4 * PC[n])


def sc_visibility(g: Gen):
    """The software contract end to end at the subsystem boundary (docs/03): CPU -> DMA -> accelerator -> CPU, with
    negative controls that show the cache is really noncoherent and that each maintenance step is necessary."""
    lb = g.cfg.cache_line
    A, C, B, D = SRAM + 0x30000, SRAM + 0x31000, SRAM + 0x32000, SRAM + 0x33000
    XA, XC = EXT + 0x20000, EXT + 0x21000
    n = 4 * lb // 4                                         # 4 lines
    g.cache_on(M_CPUD, 1)
    # ---- 1. CPU produces A (cached); DMA reads before / after CLEAN
    for i in range(n):
        g.w(M_CPUD, A + 4 * i, 0xA0000000 | i)
    g.barrier()
    for i in range(n):
        g.r(M_SDMA, A + 4 * i)                              # WB: stale (negative control); WT: already visible
    g.barrier()
    g.cmo(M_CPUD, CMO_CLEAN, A, 4 * n)
    g.barrier()
    # ---- 2. "accelerator" (tensor DMA) consumes A, produces C; system DMA stages A into the vector scratchpad
    for i in range(n):
        g.r(M_TDMA, A + 4 * i)
        g.w(M_TDMA, C + 4 * i, 0xC0000000 | i)
        g.r(M_SDMA, A + 4 * i)
        g.w(M_SDMA, VSPM + 4 * i, 0xA0000000 | i)
    g.barrier()
    # ---- 3. CPU had a stale copy of C: reads stale until INVAL, then fresh
    g.mcw(M_CPUD, "VSPM_OWN", 1)                            # partition 0 handed to the engine
    g.r(M_CPUD, VSPM)                                       # OWNERSHIP error: host may not touch it now
    g.mcw(M_CPUD, "VSPM_OWN", 0)
    g.r(M_CPUD, VSPM + 4)
    g.barrier()
    for i in range(n):
        g.r(M_CPUD, C + 4 * i)                              # first touch: misses, fresh
    g.barrier()
    for i in range(n):
        g.w(M_VDMA, C + 4 * i, 0xC1000000 | i)              # the engine rewrites C
    g.barrier()
    for i in range(n):
        g.r(M_CPUD, C + 4 * i)                              # stale (cached): negative control
    g.cmo(M_CPUD, CMO_INVAL, C, 4 * n)
    for i in range(n):
        g.r(M_CPUD, C + 4 * i)                              # fresh
    g.barrier()
    # ---- 4. receive buffer B with dirty CPU lines: wrong protocol loses DMA data, right protocol keeps it
    for i in range(n):
        g.w(M_CPUD, B + 4 * i, 0xB0000000 | i)              # CPU leaves B dirty (WB)
    g.barrier()
    for i in range(n):
        g.w(M_SDMA, B + 4 * i, 0xB1000000 | i)              # DMA writes B without the CPU giving it up
    g.barrier()
    g.cmo(M_CPUD, CMO_CLEAN, B, 4 * n)                      # a later write-back overwrites the DMA data (WB)
    g.barrier()
    for i in range(n):
        g.r(M_DBG, B + 4 * i)                               # model predicts the lost DMA data
    g.barrier()
    for i in range(n):
        g.w(M_CPUD, B + 4 * i, 0xB2000000 | i)
    g.cmo(M_CPUD, CMO_CI, B, 4 * n)                         # correct: CLEAN_INVAL before the hand-over
    g.barrier()
    for i in range(n):
        g.w(M_SDMA, B + 4 * i, 0xB3000000 | i)
    g.barrier()
    g.cmo(M_CPUD, CMO_INVAL, B, 4 * n)                      # and INVAL after completion
    for i in range(n):
        g.r(M_CPUD, B + 4 * i)
    g.barrier()
    # ---- 5. non-cacheable window: no maintenance at all
    g.mcw(M_CPUD, "NCW0_BASE", D | 1)
    g.mcw(M_CPUD, "NCW0_LIMIT", D + 0x100)
    for i in range(n):
        g.w(M_CPUD, D + 4 * i, 0xD0000000 | i)
    g.barrier()
    for i in range(n):
        g.r(M_SDMA, D + 4 * i)
        g.w(M_SDMA, D + 0x80 + 4 * i, 0xD1000000 | i)
    g.barrier()
    for i in range(n):
        g.r(M_CPUD, D + 0x80 + 4 * i)
    g.barrier()
    # ---- 6. external-memory buffers: CPU -> EXT (cached), CLEAN, DMA EXT -> SRAM, tensor writes EXT, CPU INVAL
    for i in range(n):
        g.w(M_CPUD, XA + 4 * i, 0xEA000000 | i)
    g.cmo(M_CPUD, CMO_CLEAN, XA, 4 * n)
    g.barrier()
    for i in range(n):
        g.r(M_SDMA, XA + 4 * i)
        g.w(M_SDMA, A + 0x800 + 4 * i, 0xEA000000 | i)
    g.barrier()
    for i in range(n):
        g.r(M_TDMA, A + 0x800 + 4 * i)
        g.w(M_TDMA, XC + 4 * i, 0xEC000000 | i)
    g.barrier()
    g.cmo(M_CPUD, CMO_INVAL, XC, 4 * n)
    for i in range(n):
        g.r(M_CPUD, XC + 4 * i)


def sc_ownership(g: Gen):
    """VSPM partition ownership: host-window accesses to engine-owned partitions fail with no side effect."""
    psz = REG["VSPM"]["size"] // REG["VSPM"]["partitions"]
    for p in range(REG["VSPM"]["partitions"]):
        g.w(M_DBG, VSPM + p * psz, 0x50000000 | p)
    g.barrier()
    for mask in (0x01, 0xA5, 0xFF, 0x00, 0x80):
        g.mcw(M_DBG, "VSPM_OWN", mask)
        g.mcr(M_DBG, "VSPM_OWN")
        g.barrier()
        for p in range(REG["VSPM"]["partitions"]):
            for mi in (M_DBG, M_CPUD, M_SDMA):
                a = VSPM + p * psz + 4 * mi
                g.w(mi, a, 0x5F000000 | (mask << 8) | p)
                g.r(mi, a)
            g.r(M_TDMA, VSPM + p * psz)                     # never allowed (access matrix)
        g.barrier()
    for p in range(REG["VSPM"]["partitions"]):
        g.r(M_DBG, VSPM + p * psz + 4 * M_SDMA)
    g.mcr(M_DBG, "ERR_COUNT")


def sc_semaphore(g: Gen):
    """Hardware semaphores: sequential semantics, then a mutual-exclusion race between DBG and the ControlCore."""
    steps = [(M_DBG, "r"), (M_CPUD, "r"), (M_CPUD, "w0"), (M_DBG, "w5"), (M_DBG, "w0"), (M_CPUD, "r"),
             (M_DBG, "r"), (M_CPUD, "w0"), (M_CPUD, "w0")]
    # read: test-and-set (0 = acquired, else holder + 1); w0: release (REG error unless the holder); w5: refused
    for mi, k in steps:                   # one step per phase: the order between requesters is defined
        for i in range(8):
            s = mc("SEM0") + 4 * i
            if k == "r":
                g.r(mi, s)
            else:
                g.w(mi, s, 0 if k == "w0" else 5)
        g.barrier()
    owner = SRAM + 0x38000
    sem = mc("SEM0") + 4
    for it in range(24):
        for mi in (M_DBG, M_CPUD):
            g.poll(mi, sem, 0)
            g.w(mi, owner, 0xAB00 | mi)
            g.delay(mi, 1 + (it * 7 + mi * 3) % 5)
            g.r(mi, owner, force=True)    # mutual exclusion: nobody else wrote it in between
            g.w(mi, sem, 0)


def sc_parity(g: Gen):
    """Byte-parity hooks: injection on SRAM and LMEM, detection, logging, clearing by rewrite, check disable."""
    a = SRAM + 0x3A000
    g.mcw(M_DBG, "IRQ_ENABLE", 0xF)
    g.w(M_DBG, a, 0x01020304)
    g.mcw(M_DBG, "ECC_CTRL", (1 << 8) | 0x1)                # inject lane 0 on the next SRAM write
    g.mcr(M_DBG, "ECC_CTRL")
    g.barrier()
    g.r(M_SDMA, a + 4)                                      # reads never consume the pending injection
    g.r(M_SDMA, a)
    g.barrier()
    g.w(M_SDMA, a, 0x0A0B0C0D)                              # this write (another requester) carries the bad parity
    g.barrier()
    g.mcr(M_DBG, "ECC_CTRL")                                # INJECT consumed (parity mode) / still pending (none)
    g.barrier()
    g.r(M_SDMA, a)                                          # PARITY error
    g.barrier()
    for reg in ("ECC_ERR_ADDR", "ECC_ERR_INFO", "ECC_ERR_COUNT", "IRQ_STATUS", "ERR_INFO", "ERR_ADDR"):
        g.mcr(M_DBG, reg)
    g.w(M_DBG, a, 0xFF00, 0x2)                              # partial write not covering lane 0
    g.r(M_DBG, a)                                           # still failing
    g.mcw(M_DBG, "ECC_CTRL", 1 << 16)                       # CHECK_DIS
    g.r(M_DBG, a)                                           # data returned
    g.mcw(M_DBG, "ECC_CTRL", 0)
    g.w(M_DBG, a, 0xEE, 0x1)                                # rewrite of lane 0 clears it
    g.r(M_DBG, a)
    g.mcw(M_DBG, "ECC_CTRL", (1 << 9) | (1 << 8) | 0xA)     # LMEM, lanes 1 and 3
    g.barrier()
    g.w(M_CPUD, LMEM + 0x40, 0x11223344)
    g.barrier()
    g.r(M_DBG, LMEM + 0x40)
    g.barrier()
    g.r(M_CPUD, LMEM + 0x40)
    g.barrier()
    for reg in ("ECC_ERR_ADDR", "ECC_ERR_INFO", "ECC_ERR_COUNT"):
        g.mcr(M_DBG, reg)
    g.w(M_DBG, LMEM + 0x40, 0)
    g.barrier()
    g.r(M_CPUI, LMEM + 0x40)
    g.barrier()
    # a parity failure during a D-cache refill: the access fails, the line is not installed
    if g.cfg.dcache_en:
        b = SRAM + 0x3B000
        g.mcw(M_DBG, "ECC_CTRL", 0)
        g.mcw(M_DBG, "ECC_CTRL", (1 << 8) | 0x4)
        g.w(M_DBG, b + 8, 0x99)
        g.barrier()
        g.cache_on(M_CPUD, 1)
        g.r(M_CPUD, b)                                      # word 0 is fine but word 2 of the line is not
        g.r(M_CPUD, b + 8)
        g.barrier()
        g.w(M_DBG, b + 8, 0x98)
        g.barrier()
        g.r(M_CPUD, b)
        g.r(M_CPUD, b + 8)
        g.mcr(M_CPUD, "ECC_ERR_COUNT")
        g.barrier()
    g.mcr(M_DBG, "IRQ_STATUS")
    g.mcw(M_DBG, "IRQ_STATUS", 0xF)
    g.mcr(M_DBG, "IRQ_STATUS")


def sc_wberr(g: Gen):
    """Write-back and refill errors: the testbench's EXT model is told (MMIO page 30) to refuse a window."""
    if not (g.cfg.dcache_en and g.cfg.dcache_wb):
        return sc_smoke(g)
    st = set_size_stride(g.cfg)
    x = EXT + 0x40000
    g.mcw(M_DBG, "ERR_STATUS", 3)
    g.mcw(M_DBG, "IRQ_ENABLE", 0xF)
    g.barrier()
    g.cache_on(M_CPUD, 1)
    g.r(M_CPUD, x)
    g.w(M_CPUD, x + 4, 0x0BAD0001)                          # dirty line in EXT
    g.barrier()
    g.w(M_DBG, TB_CTRL_PAGE, x)                             # EXT now refuses [x, x + 64)
    g.w(M_DBG, TB_CTRL_PAGE + 4, x + 64)
    g.barrier()
    g.cmo(M_CPUD, CMO_CLEAN, x, 4)                          # write-back refused: WB_ERR, WRITEBACK, TARGET x4
    for reg in ("CMO_STATUS", "ERR_INFO", "ERR_ADDR", "ERR_COUNT", "IRQ_STATUS"):
        g.mcr(M_CPUD, reg)
    g.r(M_CPUD, x + 16)                                     # refill refused: precise error, no line
    g.r(M_CPUD, x + 16)
    g.barrier()
    # eviction-triggered write-back error (not a maintenance command)
    g.w(M_DBG, TB_CTRL_PAGE, 0)
    g.w(M_DBG, TB_CTRL_PAGE + 4, 0)
    g.barrier()
    y = EXT + 0x50000
    g.w(M_CPUD, y, 0x0BAD0002)                              # write-allocate: dirty
    g.barrier()
    g.w(M_DBG, TB_CTRL_PAGE, y)
    g.w(M_DBG, TB_CTRL_PAGE + 4, y + 16)
    g.barrier()
    for w in range(1, g.cfg.cache_ways + 1):
        g.r(M_CPUD, y + w * st)                             # evicts the dirty line eventually
    for reg in ("CMO_STATUS", "ERR_COUNT", "IRQ_STATUS"):
        g.mcr(M_CPUD, reg)
    g.mcr(M_CPUD, "PERF_BASE", check=False)
    g.r(M_CPUD, MEMCTL_BASE + MC["PERF_BASE"] + 4 * PC["DC_WB"])
    g.barrier()
    g.w(M_DBG, TB_CTRL_PAGE, 0)
    g.w(M_DBG, TB_CTRL_PAGE + 4, 0)
    g.r(M_DBG, y)                                           # the refused write-back never reached memory


def random_traffic(g: Gen, nops: int, phases: int, wbr: bool):
    """Concurrent random traffic on shared and private pools, legal and illegal addresses, MEMCTL accesses.
    wbr = write-before-read discipline for checked reads (needed when a reset restarts the programs)."""
    rng = g.rng
    shared = (SRAM, 0x1000)                                 # every requester, races
    priv = {mi: (SRAM + 0x1000 + mi * 0x1000, 0x1000) for mi in range(6)}
    epriv = {mi: (EXT + mi * 0x1000, 0x1000) for mi in range(6)}
    lshared = (LMEM, 0x800)
    vpriv = {M_DBG: VSPM, M_CPUD: VSPM + 0x2000, M_SDMA: VSPM + 0x4000}
    illegal = [0x0, 0x2000_0000, 0x7FFF_FFFC, 0x1004_0000, 0x0800_8000, MMIO + 0x1F000, 0x8F00_0000]
    written = {mi: set() for mi in range(6)}
    g.mcw(M_DBG, "NCW0_BASE", shared[0] | 1)                # the shared pool is never cached
    g.mcw(M_DBG, "NCW0_LIMIT", shared[0] + shared[1])
    g.barrier()
    g.cache_on(M_CPUD, 3 if g.cfg.dcache_en else 0)
    for ph in range(phases):
        for mi in range(6):
            for _ in range(nops // phases):
                kind = rng.random()
                if mi == M_CPUI:
                    pool = rng.choice([priv[mi], shared, lshared])
                    a = pool[0] + rng.randrange(pool[1] // 4) * 4
                    g.r(mi, a, check=pool is priv[mi])
                    continue
                pools = [shared, priv[mi], epriv[mi]]
                if mi in (M_DBG, M_CPUD):
                    pools.append(lshared)
                if mi in vpriv:
                    pools.append((vpriv[mi], 0x800))
                if kind < 0.04:
                    a = rng.choice(illegal) + rng.choice([0, 0, 1, 2])
                    if rng.random() < 0.5:
                        g.w(mi, a, rng.getrandbits(32), rng.randrange(16))
                    else:
                        g.r(mi, a, check=True)
                    continue
                if kind < 0.07 and mi in (M_DBG, M_CPUD):
                    g.r(mi, mc(rng.choice(["ID", "INFO", "VSPM_OWN", "CACHE_INFO"])))
                    continue
                if kind < 0.08 and mi in (M_DBG, M_CPUD):
                    g.w(mi, MMIO + 0x6000 + 4 * rng.randrange(64), rng.getrandbits(32))
                    continue
                pool = rng.choice(pools)
                a = pool[0] + rng.randrange(pool[1] // 4) * 4
                private = pool is not shared and pool is not lshared
                if rng.random() < 0.5:
                    strb = 0xF if rng.random() < 0.6 else rng.randrange(1, 16)
                    g.w(mi, a, rng.getrandbits(32), strb)
                    if strb == 0xF:
                        written[mi].add(a)
                else:
                    chk = private and (not wbr or a in written[mi])
                    g.r(mi, a, check=chk)
        if g.cfg.dcache_en and ph % 2 == 1:
            g.cmo(M_CPUD, CMO_CI, all_=True)
        g.barrier()
    g.mcw(M_CPUD, "CACHE_CTRL", 0)


def sc_random(g: Gen):
    random_traffic(g, nops=1200, phases=4, wbr=False)


def sc_reset(g: Gen):
    g.mcr(M_DBG, "CACHE_CTRL")                              # reset values after the pulse
    g.mcr(M_DBG, "ERR_COUNT")
    g.mcr(M_DBG, "VSPM_OWN")
    random_traffic(g, nops=900, phases=3, wbr=True)


def sc_stream(g: Gen):
    """Bandwidth stream: every DMA-class requester streams its own unit-stride buffer (reads then writes)."""
    for mi, base in ((M_SDMA, SRAM + 0x0000), (M_VDMA, SRAM + 0x8000), (M_TDMA, SRAM + 0x10000),
                     (M_DBG, SRAM + 0x18000), (M_CPUD, SRAM + 0x20000)):
        for i in range(512):
            g.r(mi, base + 4 * i, check=False)
        for i in range(512):
            g.w(mi, base + 4 * i, i)


SCENARIOS = {
    "smoke": sc_smoke, "bytes": sc_bytes, "banks": sc_banks, "partial": sc_partial, "bounds": sc_bounds,
    "multi": sc_multi, "hazard": sc_hazard, "cache": sc_cache, "cmo": sc_cmo, "visibility": sc_visibility,
    "ownership": sc_ownership, "semaphore": sc_semaphore, "parity": sc_parity, "wberr": sc_wberr,
    "random": sc_random, "reset": sc_reset, "stream": sc_stream,
}


def generate(name: str, out: Path, cfg: Config, seed: int) -> dict:
    g = Gen(cfg, seed)
    SCENARIOS[name](g)
    g.save(out, {"scenario": name, "seed": seed})
    return g.stats


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("scenario", choices=sorted(SCENARIOS))
    ap.add_argument("out")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--cfg", nargs="*", default=[])
    a = ap.parse_args()
    cfg = Config()
    for kv in a.cfg:
        k, v = kv.split("=")
        setattr(cfg, k, int(v))
    st = generate(a.scenario, Path(a.out), cfg, a.seed)
    print(json.dumps(st))
    return 0


if __name__ == "__main__":
    sys.exit(main())
