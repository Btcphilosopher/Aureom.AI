// =============================================================================
// SilicaFlux-HPC MemoryCore :: sfmem_tgt_mux -- NM requester ports -> one SFB2 target
//
// Used for the narrow targets: EXT window, VSPM host window, MMIO (io_*) and
// the internal MEMCTL register page.
//
// * Arbitration: round robin; the pointer moves past the winner only on
//   acceptance.  Grant lock: a request presented downstream but not accepted
//   keeps the grant while its requester still requests, so the downstream
//   payload is stable (SFB2 R2 at the target).  A requester waiting with a
//   valid request is served after at most NM-1 other acceptances.
// * Outstanding: up to DEPTH transactions in flight; the owner FIFO records the
//   requester of each, responses (in order, SFB2 R5) go to the FIFO head.
//   DEPTH = 1 reproduces the DataFabric crossbar's one-transaction rule (R6).
// * The downstream request valid never depends on the downstream ready (R3);
//   the downstream rsp_ready depends only on the head requester's ready (R4).
// * err_evt reports a response with rsp_error = 1 (cause TARGET in MEMCTL),
//   with the requester and the request address (address FIFO).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfmem_defs.svh"
`default_nettype none

module sfmem_tgt_mux #(
  parameter int NM    = 6,
  parameter int DEPTH = 2,
  localparam int MW   = (NM > 1) ? $clog2(NM) : 1,
  localparam int PW   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int CW   = $clog2(DEPTH + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- requester side
  input  wire logic [NM-1:0]    m_req_valid,
  output logic [NM-1:0]         m_req_ready,
  input  wire logic [NM-1:0]    m_req_write,
  input  wire logic [NM*32-1:0] m_req_addr,
  input  wire logic [NM*32-1:0] m_req_wdata,
  input  wire logic [NM*4-1:0]  m_req_wstrb,
  output logic [NM-1:0]         m_rsp_valid,
  input  wire logic [NM-1:0]    m_rsp_ready,
  output logic [31:0]           m_rsp_rdata,      // broadcast; qualified by m_rsp_valid
  output logic                  m_rsp_error,
  // ---------------------------------------------------------- target side (SFB2 master)
  output logic                  d_req_valid,
  input  wire logic             d_req_ready,
  output logic                  d_req_write,
  output logic [31:0]           d_req_addr,
  output logic [31:0]           d_req_wdata,
  output logic [3:0]            d_req_wstrb,
  output logic [2:0]            d_req_master,     // sideband: requester index (MEMCTL semaphores)
  input  wire logic             d_rsp_valid,
  output logic                  d_rsp_ready,
  input  wire logic [31:0]      d_rsp_rdata,
  input  wire logic             d_rsp_error,
  // ---------------------------------------------------------- events
  output logic                  ev_txn,           // transaction accepted downstream
  output logic                  ev_wait,          // some request waiting (arbitration or target not ready)
  output logic                  err_evt,          // response with error delivered
  output logic [2:0]            err_master,
  output logic [31:0]           err_addr,
  output logic                  err_write
);

  if (NM < 1 || NM > 8) begin : g_err_nm
    `SFMEM_CFG_FATAL("sfmem_tgt_mux: NM must be 1..8")
  end
  if (DEPTH < 1) begin : g_err_depth
    `SFMEM_CFG_FATAL("sfmem_tgt_mux: DEPTH must be >= 1")
  end

  // ============================================================ owner FIFO
  logic [MW-1:0] own_q  [DEPTH];
  logic [31:0]   addr_q [DEPTH];
  logic          wr_q   [DEPTH];
  logic [PW-1:0] rd_p, wr_p;
  logic [CW-1:0] cnt;
  logic          full, empty, acc, pop;
  logic [MW-1:0] head;

  assign full  = cnt == CW'(DEPTH);
  assign empty = cnt == '0;
  assign head  = own_q[rd_p];

  // ============================================================ arbitration
  logic [MW-1:0] ptr_q, win, lock_m;
  logic          lock_q, any;

  always_comb begin
    win = '0;
    any = 1'b0;
    // round robin starting at ptr_q
    for (int k = 0; k < NM; k++) begin
      int idx;
      idx = k + 32'(ptr_q);           // no int'() casts (Yosys 0.33)
      if (idx >= NM) idx = idx - NM;
      if (!any && m_req_valid[idx]) begin
        any = 1'b1;
        win = MW'(idx);
      end
    end
    if (lock_q && m_req_valid[lock_m]) begin
      win = lock_m;
      any = 1'b1;
    end
  end

  assign d_req_valid  = any && !full;
  assign d_req_write  = m_req_write[win];
  assign d_req_addr   = m_req_addr[win*32 +: 32];
  assign d_req_wdata  = m_req_wdata[win*32 +: 32];
  assign d_req_wstrb  = m_req_wstrb[win*4 +: 4];
  assign d_req_master = 3'(win);
  assign acc          = d_req_valid && d_req_ready;

  always_comb begin
    m_req_ready = '0;
    if (acc) m_req_ready[win] = 1'b1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ptr_q  <= '0;
      lock_q <= 1'b0;
      lock_m <= '0;
    end else begin
      if (acc) begin
        ptr_q  <= (win == MW'(NM - 1)) ? '0 : win + MW'(1);
        lock_q <= 1'b0;
      end else if (d_req_valid) begin
        lock_q <= 1'b1;               // presented, not accepted: keep this requester
        lock_m <= win;
      end else begin
        lock_q <= 1'b0;
      end
    end
  end

  // ============================================================ responses
  always_comb begin
    m_rsp_valid = '0;
    if (!empty) m_rsp_valid[head] = d_rsp_valid;
  end
  assign m_rsp_rdata = d_rsp_rdata;
  assign m_rsp_error = d_rsp_error;
  assign d_rsp_ready = !empty && m_rsp_ready[head];
  assign pop         = d_rsp_valid && d_rsp_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_p <= '0;
      wr_p <= '0;
      cnt  <= '0;
    end else begin
      if (acc) wr_p <= (wr_p == PW'(DEPTH - 1)) ? '0 : wr_p + PW'(1);
      if (pop) rd_p <= (rd_p == PW'(DEPTH - 1)) ? '0 : rd_p + PW'(1);
      cnt <= cnt + CW'(acc) - CW'(pop);
    end
  end
  always_ff @(posedge clk) begin
    if (acc) begin
      own_q[wr_p]  <= win;
      addr_q[wr_p] <= d_req_addr;
      wr_q[wr_p]   <= d_req_write;
    end
  end

  // ============================================================ events
  assign ev_txn     = acc;
  assign ev_wait    = (|m_req_valid) && !acc;
  assign err_evt    = pop && d_rsp_error;
  assign err_master = 3'(head);
  assign err_addr   = addr_q[rd_p];
  assign err_write  = wr_q[rd_p];

`ifndef SYNTHESIS
`ifdef SFMEM_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    if (d_rsp_valid && empty) $error("%m: unsolicited response from the target");
  end
`endif
`endif

endmodule

`default_nettype wire
