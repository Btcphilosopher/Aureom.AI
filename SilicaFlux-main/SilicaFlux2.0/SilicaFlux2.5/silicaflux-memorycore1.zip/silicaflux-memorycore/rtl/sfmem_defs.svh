// =============================================================================
// SilicaFlux-HPC MemoryCore :: shared definitions (macros only; no package import in RTL).
// Address-map constants come from generated/sfmem_map_pkg.sv (referenced as sfmem_map_pkg::NAME).
// =============================================================================
`ifndef SFMEM_DEFS_SVH
`define SFMEM_DEFS_SVH

// ------------------------------------------------------------- internal target numbering (per requester port)
// Region targets use the region index of the map (LMEM 0, SRAM 1, MMIO 2, VSPM 3, EXT 4); MEMCTL is the
// MMIO page served inside MemoryCore; ERR is the port's local error responder.
`define SFMEM_NT        6       // targets with a request channel (ERR has none)
`define SFMEM_TG_LMEM   3'd0
`define SFMEM_TG_SRAM   3'd1
`define SFMEM_TG_MMIO   3'd2
`define SFMEM_TG_VSPM   3'd3
`define SFMEM_TG_EXT    3'd4
`define SFMEM_TG_REGS   3'd5
`define SFMEM_TG_ERR    3'd6

// ------------------------------------------------------------- ECC / integrity modes (coordinated with Project 26)
`define SFMEM_ECC_NONE    0     // no check bits
`define SFMEM_ECC_PARITY  1     // odd parity per byte lane, 9-bit lanes (HPC Module 04 / MCU-I convention)
`define SFMEM_ECC_SECDED  2     // RESERVED for Project 26 -- rejected at elaboration

// ------------------------------------------------------------- cache maintenance opcodes (CMO_CMD.OP)
`define SFMEM_CMO_CLEAN        2'd1
`define SFMEM_CMO_INVAL        2'd2
`define SFMEM_CMO_CLEAN_INVAL  2'd3

`ifdef __ICARUS__
  `define SFMEM_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SFMEM_CFG_FATAL(msg) $fatal(1, msg);
`endif

`endif // SFMEM_DEFS_SVH
