// =============================================================================
// SilicaFlux-HPC MemoryCore :: silicaflux_memory_subsystem  (primary source)
// Aureom.AI | SilicaFlux-HPC
//
// Unified memory subsystem: one documented 32-bit address space
// (memmap/memorycore.yaml -> generated/sfmem_map_pkg.sv) shared by the
// ControlCore, the system DMA, the vector engine and the TensorCore, with
// private, explicitly managed scratchpads kept inside the engines.
// A unified address map is NOT hardware coherence: the only cache (ControlCore)
// is noncoherent and software-managed (docs/03_CONSISTENCY.md).
//
//   requesters (SFB2)            routing (sfmem_port: decode, access matrix,   targets
//                                alignment, VSPM ownership, in-order responses)
//   m0 DBG  ──────────────────► port0 ─┐                                     ┌► LMEM   sfmem_banked (3 ports x 2 banks)
//   m1 CPUI ─► [I-cache] ─────► port1 ─┤                                     ├► SRAM   sfmem_banked (6 ports x 8 banks)
//   m2 CPUD ─► [D-cache] ─────► port2 ─┤  one port per requester into each   ├► EXT    sfmem_tgt_mux ─► ext_*  (external memory)
//   m3 SDMA ──────────────────► port3 ─┤  banked memory; narrow targets      ├► VSPM   sfmem_tgt_mux ─► vs_*   (vector scratchpad window)
//   m4 VDMA ──────────────────► port4 ─┤  arbitrated round robin             ├► MMIO   sfmem_tgt_mux ─► io_*   (register pages)
//   m5 TDMA ──────────────────► port5 ─┘                                     └► MEMCTL sfmem_tgt_mux ─► sfmem_regs (page 10)
//
// Shared SRAM: SRAM_BANKS single-port banks, word interleave, one port per
// requester, per-bank round robin -- up to min(6, banks) accesses per cycle.
// No macro is assumed to have more than one port.  Read latency SRAM_RD_LAT.
// Every write is acknowledged after it is performed (SFB2 R7).
//
// Coding rules: SilicaFlux-V RTL_CODING_RULES (flat ports, no interfaces /
// structs / package imports in RTL; map constants as sfmem_map_pkg::NAME).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfmem_defs.svh"
`default_nettype none

module silicaflux_memory_subsystem #(
  // ---------------------------------------------------------- shared SRAM
  parameter int SRAM_BANKS     = sfmem_map_pkg::SRAM_BANKS,
  parameter int SRAM_RD_LAT    = 1,
  parameter int SRAM_RSP_DEPTH = SRAM_RD_LAT + 1,
  parameter int SRAM_ARB       = `SRAM_ARB_RR,
  parameter int SRAM_ILV_HIGH  = sfmem_map_pkg::SRAM_INTERLEAVE_HIGH,
  // ---------------------------------------------------------- ControlCore local memory
  parameter int LMEM_BANKS     = sfmem_map_pkg::LMEM_BANKS,
  parameter int LMEM_RD_LAT    = 1,
  // ---------------------------------------------------------- integrity (single encode / decode layer)
  parameter int ECC_MODE       = `SFMEM_ECC_PARITY,
  // ---------------------------------------------------------- ControlCore caches (noncoherent, optional)
  parameter int DCACHE_EN      = 1,             // present (disabled at reset); case: EXT data (docs/10 E5)
  parameter int ICACHE_EN      = 0,             // absent by default: no case while ControlCore code is in LMEM
  parameter int DCACHE_WB      = 1,             // 1 write-back + write-allocate, 0 write-through
  parameter int CACHE_LINE     = 16,
  parameter int CACHE_SETS     = 64,
  parameter int CACHE_WAYS     = 2,
  // ---------------------------------------------------------- routing
  parameter int MAX_OUT        = 4,             // per requester port
  parameter int EXT_DEPTH      = 4,             // outstanding on ext_*
  parameter int VSPM_DEPTH     = 2,
  parameter int MMIO_DEPTH     = 1,
  // ---------------------------------------------------------- implementation
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int SRAM_MACRO     = 0,
  parameter int LMEM_MACRO     = 0,
  parameter int CACHE_MACRO    = 0,
  parameter int PERF_EN        = 1,
  localparam int NM            = sfmem_map_pkg::NUM_MASTERS,
  localparam int SW            = (ECC_MODE == `SFMEM_ECC_PARITY) ? 36 : 32,
  localparam int SRAM_RAW      = $clog2(sfmem_map_pkg::SRAM_BYTES / 4 / SRAM_BANKS),
  localparam int LMEM_RAW      = $clog2(sfmem_map_pkg::LMEM_BYTES / 4 / LMEM_BANKS)
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------- requesters (SFB2 slave side), m at slice m
  input  wire logic [NM-1:0]          m_req_valid,
  output logic [NM-1:0]               m_req_ready,
  input  wire logic [NM-1:0]          m_req_write,
  input  wire logic [NM*32-1:0]       m_req_addr,
  input  wire logic [NM*32-1:0]       m_req_wdata,
  input  wire logic [NM*4-1:0]        m_req_wstrb,
  output logic [NM-1:0]               m_rsp_valid,
  input  wire logic [NM-1:0]          m_rsp_ready,
  output logic [NM*32-1:0]            m_rsp_rdata,
  output logic [NM-1:0]               m_rsp_error,
  // ---------------------------------------------------------- external-memory window (SFB2 master)
  output logic                        ext_req_valid,
  input  wire logic                   ext_req_ready,
  output logic                        ext_req_write,
  output logic [31:0]                 ext_req_addr,
  output logic [31:0]                 ext_req_wdata,
  output logic [3:0]                  ext_req_wstrb,
  input  wire logic                   ext_rsp_valid,
  output logic                        ext_rsp_ready,
  input  wire logic [31:0]            ext_rsp_rdata,
  input  wire logic                   ext_rsp_error,
  // ---------------------------------------------------------- vector-scratchpad host window (SFB2 master -> tile hs_*)
  output logic                        vs_req_valid,
  input  wire logic                   vs_req_ready,
  output logic                        vs_req_write,
  output logic [31:0]                 vs_req_addr,
  output logic [31:0]                 vs_req_wdata,
  output logic [3:0]                  vs_req_wstrb,
  input  wire logic                   vs_rsp_valid,
  output logic                        vs_rsp_ready,
  input  wire logic [31:0]            vs_rsp_rdata,
  input  wire logic                   vs_rsp_error,
  // ---------------------------------------------------------- MMIO register pages except MEMCTL (SFB2 master)
  output logic                        io_req_valid,
  input  wire logic                   io_req_ready,
  output logic                        io_req_write,
  output logic [31:0]                 io_req_addr,
  output logic [31:0]                 io_req_wdata,
  output logic [3:0]                  io_req_wstrb,
  input  wire logic                   io_rsp_valid,
  output logic                        io_rsp_ready,
  input  wire logic [31:0]            io_rsp_rdata,
  input  wire logic                   io_rsp_error,
  // ---------------------------------------------------------- interrupt (MEMCTL IRQ_STATUS & IRQ_ENABLE)
  output logic                        irq,
  // ---------------------------------------------------------- MBIST test ports (SRAM library / TestCore contract)
  input  wire logic                   sram_tst_active,
  input  wire logic [SRAM_BANKS-1:0]  sram_tst_sel,
  input  wire logic                   sram_tst_ce,
  input  wire logic                   sram_tst_we,
  input  wire logic [SRAM_RAW-1:0]    sram_tst_addr,
  input  wire logic [SW-1:0]          sram_tst_wdata,
  output logic [SRAM_BANKS*SW-1:0]    sram_tst_rdata,
  input  wire logic                   lmem_tst_active,
  input  wire logic [LMEM_BANKS-1:0]  lmem_tst_sel,
  input  wire logic                   lmem_tst_ce,
  input  wire logic                   lmem_tst_we,
  input  wire logic [LMEM_RAW-1:0]    lmem_tst_addr,
  input  wire logic [SW-1:0]          lmem_tst_wdata,
  output logic [LMEM_BANKS*SW-1:0]    lmem_tst_rdata,
  output logic                        busy
);

  localparam int NT    = `SFMEM_NT;
  localparam int NPART = sfmem_map_pkg::VSPM_PARTITIONS;
  localparam int NE    = 13;
  localparam int NPERF = sfmem_map_pkg::NUM_PERF;
  localparam int TG_LMEM = 0, TG_SRAM = 1, TG_MMIO = 2, TG_VSPM = 3, TG_EXT = 4, TG_REGS = 5;
  localparam int MI = sfmem_map_pkg::M_CPUI;
  localparam int MD = sfmem_map_pkg::M_CPUD;

  // ------------------------------------------------------------ configuration checks
  if (NM != 6) begin : g_err_nm
    `SFMEM_CFG_FATAL("silicaflux_memory_subsystem: the rev-1 map has exactly 6 requesters")
  end
  if (sfmem_map_pkg::M_DBG != 0 || MI != 1 || MD != 2) begin : g_err_order
    `SFMEM_CFG_FATAL("silicaflux_memory_subsystem: LMEM ports assume DBG=0, CPUI=1, CPUD=2")
  end
  if (((sfmem_map_pkg::ACCESS_EN >> (3 * sfmem_map_pkg::NUM_REGIONS)) & 30'h0000_0421) != 30'd0) begin : g_err_lmem_private
    `SFMEM_CFG_FATAL("silicaflux_memory_subsystem: LMEM must be denied to requesters 3..5")
  end

  // ============================================================ register-block signals
  logic        dc_en, ic_en;
  logic [sfmem_map_pkg::NUM_REGIONS-1:0] cache_regions;
  logic [1:0]  ncw_en;
  logic [63:0] ncw_base, ncw_limit;
  logic        dc_cmo_valid, dc_cmo_ready, ic_cmo_valid, ic_cmo_ready;
  logic [1:0]  cmo_op;
  logic        cmo_all;
  logic [31:0] cmo_addr, cmo_size;
  logic        dc_cmo_done, ic_cmo_done, dc_cmo_wb_err, dc_cmo_discard;
  logic [15:0] dc_cmo_lines, ic_cmo_lines;
  logic        chk_dis, inj_sram_req, inj_lmem_req, inj_sram_ack, inj_lmem_ack;
  logic [3:0]  inj_lanes;
  logic [NPART-1:0] vspm_own;

  // ============================================================ requester -> (cache) -> port
  logic [NM-1:0]    p_req_valid, p_req_ready, p_req_write, p_rsp_valid, p_rsp_ready, p_rsp_error;
  logic [NM*32-1:0] p_req_addr, p_req_wdata, p_rsp_rdata;
  logic [NM*4-1:0]  p_req_wstrb;

  // cache events
  logic dc_hit, dc_miss, dc_wb, dc_byp, dc_line, dc_wb_err;
  logic ic_hit, ic_miss, ic_wb_u, ic_byp_u, ic_line, ic_wb_err_u;
  logic [31:0] dc_wb_err_addr, ic_wb_err_addr_u;
  logic        ic_cmo_wb_err_u, ic_cmo_disc_u;     // an I-cache is never dirty

  for (genvar m = 0; m < NM; m++) begin : g_req
    if (m == MD && DCACHE_EN != 0) begin : g_dcache
      sfmem_cache #(
        .MIDX(MD), .LINE_BYTES(CACHE_LINE), .SETS(CACHE_SETS), .WAYS(CACHE_WAYS), .WRITE_BACK(DCACHE_WB),
        .MAX_OUT(MAX_OUT), .BACKEND(BACKEND), .MACRO(CACHE_MACRO)
      ) u_cache (
        .clk(clk), .rst_n(rst_n), .enable(dc_en), .reg_en(cache_regions), .ncw_en(ncw_en), .ncw_base(ncw_base), .ncw_limit(ncw_limit),
        .u_req_valid(m_req_valid[m]), .u_req_ready(m_req_ready[m]), .u_req_write(m_req_write[m]),
        .u_req_addr(m_req_addr[m*32 +: 32]), .u_req_wdata(m_req_wdata[m*32 +: 32]), .u_req_wstrb(m_req_wstrb[m*4 +: 4]),
        .u_rsp_valid(m_rsp_valid[m]), .u_rsp_ready(m_rsp_ready[m]), .u_rsp_rdata(m_rsp_rdata[m*32 +: 32]),
        .u_rsp_error(m_rsp_error[m]),
        .d_req_valid(p_req_valid[m]), .d_req_ready(p_req_ready[m]), .d_req_write(p_req_write[m]),
        .d_req_addr(p_req_addr[m*32 +: 32]), .d_req_wdata(p_req_wdata[m*32 +: 32]), .d_req_wstrb(p_req_wstrb[m*4 +: 4]),
        .d_rsp_valid(p_rsp_valid[m]), .d_rsp_ready(p_rsp_ready[m]), .d_rsp_rdata(p_rsp_rdata[m*32 +: 32]),
        .d_rsp_error(p_rsp_error[m]),
        .cmo_valid(dc_cmo_valid), .cmo_ready(dc_cmo_ready), .cmo_op(cmo_op), .cmo_all(cmo_all), .cmo_addr(cmo_addr),
        .cmo_size(cmo_size), .cmo_done(dc_cmo_done), .cmo_lines(dc_cmo_lines), .cmo_wb_err(dc_cmo_wb_err),
        .cmo_discard(dc_cmo_discard),
        .ev_hit(dc_hit), .ev_miss(dc_miss), .ev_wb(dc_wb), .ev_bypass(dc_byp), .ev_cmo_line(dc_line),
        .ev_wb_err(dc_wb_err), .wb_err_addr(dc_wb_err_addr)
      );
    end else if (m == MI && ICACHE_EN != 0) begin : g_icache
      sfmem_cache #(
        .MIDX(MI), .LINE_BYTES(CACHE_LINE), .SETS(CACHE_SETS), .WAYS(CACHE_WAYS), .WRITE_BACK(0),
        .MAX_OUT(MAX_OUT), .BACKEND(BACKEND), .MACRO(CACHE_MACRO)
      ) u_cache (
        .clk(clk), .rst_n(rst_n), .enable(ic_en), .reg_en(cache_regions), .ncw_en(ncw_en), .ncw_base(ncw_base), .ncw_limit(ncw_limit),
        .u_req_valid(m_req_valid[m]), .u_req_ready(m_req_ready[m]), .u_req_write(m_req_write[m]),
        .u_req_addr(m_req_addr[m*32 +: 32]), .u_req_wdata(m_req_wdata[m*32 +: 32]), .u_req_wstrb(m_req_wstrb[m*4 +: 4]),
        .u_rsp_valid(m_rsp_valid[m]), .u_rsp_ready(m_rsp_ready[m]), .u_rsp_rdata(m_rsp_rdata[m*32 +: 32]),
        .u_rsp_error(m_rsp_error[m]),
        .d_req_valid(p_req_valid[m]), .d_req_ready(p_req_ready[m]), .d_req_write(p_req_write[m]),
        .d_req_addr(p_req_addr[m*32 +: 32]), .d_req_wdata(p_req_wdata[m*32 +: 32]), .d_req_wstrb(p_req_wstrb[m*4 +: 4]),
        .d_rsp_valid(p_rsp_valid[m]), .d_rsp_ready(p_rsp_ready[m]), .d_rsp_rdata(p_rsp_rdata[m*32 +: 32]),
        .d_rsp_error(p_rsp_error[m]),
        .cmo_valid(ic_cmo_valid), .cmo_ready(ic_cmo_ready), .cmo_op(cmo_op), .cmo_all(cmo_all), .cmo_addr(cmo_addr),
        .cmo_size(cmo_size), .cmo_done(ic_cmo_done), .cmo_lines(ic_cmo_lines), .cmo_wb_err(ic_cmo_wb_err_u),
        .cmo_discard(ic_cmo_disc_u),
        .ev_hit(ic_hit), .ev_miss(ic_miss), .ev_wb(ic_wb_u), .ev_bypass(ic_byp_u), .ev_cmo_line(ic_line),
        .ev_wb_err(ic_wb_err_u), .wb_err_addr(ic_wb_err_addr_u)
      );
    end else begin : g_direct
      assign p_req_valid[m]           = m_req_valid[m];
      assign m_req_ready[m]           = p_req_ready[m];
      assign p_req_write[m]           = m_req_write[m];
      assign p_req_addr[m*32 +: 32]   = m_req_addr[m*32 +: 32];
      assign p_req_wdata[m*32 +: 32]  = m_req_wdata[m*32 +: 32];
      assign p_req_wstrb[m*4 +: 4]    = m_req_wstrb[m*4 +: 4];
      assign m_rsp_valid[m]           = p_rsp_valid[m];
      assign p_rsp_ready[m]           = m_rsp_ready[m];
      assign m_rsp_rdata[m*32 +: 32]  = p_rsp_rdata[m*32 +: 32];
      assign m_rsp_error[m]           = p_rsp_error[m];
    end
  end
  if (DCACHE_EN == 0) begin : g_no_dcache
    assign dc_cmo_ready = 1'b0; assign dc_cmo_done = 1'b0; assign dc_cmo_lines = 16'd0;
    assign dc_cmo_wb_err = 1'b0; assign dc_cmo_discard = 1'b0;
    assign dc_hit = 1'b0; assign dc_miss = 1'b0; assign dc_wb = 1'b0; assign dc_byp = 1'b0; assign dc_line = 1'b0;
    assign dc_wb_err = 1'b0; assign dc_wb_err_addr = 32'd0;
  end
  if (ICACHE_EN == 0) begin : g_no_icache
    assign ic_cmo_ready = 1'b0; assign ic_cmo_done = 1'b0; assign ic_cmo_lines = 16'd0;
    assign ic_hit = 1'b0; assign ic_miss = 1'b0; assign ic_line = 1'b0;
    assign ic_wb_u = 1'b0; assign ic_byp_u = 1'b0; assign ic_wb_err_u = 1'b0; assign ic_wb_err_addr_u = 32'd0;
    assign ic_cmo_wb_err_u = 1'b0; assign ic_cmo_disc_u = 1'b0;
  end

  // ============================================================ ports
  logic [NM*NT-1:0]    t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready, t_rsp_error;
  logic [NM-1:0]       t_req_write;
  logic [NM*32-1:0]    t_req_addr, t_req_wdata;
  logic [NM*4-1:0]     t_req_wstrb;
  logic [NM*NT*32-1:0] t_rsp_rdata;
  logic [NM-1:0]       pe_evt, pe_write, p_stall_u, p_acc_u;
  logic [NM*4-1:0]     pe_cause;
  logic [NM*32-1:0]    pe_addr;

  for (genvar m = 0; m < NM; m++) begin : g_port
    sfmem_port #(.MIDX(m), .MAX_OUT(MAX_OUT)) u_port (
      .clk(clk), .rst_n(rst_n),
      .s_req_valid(p_req_valid[m]), .s_req_ready(p_req_ready[m]), .s_req_write(p_req_write[m]),
      .s_req_addr(p_req_addr[m*32 +: 32]), .s_req_wdata(p_req_wdata[m*32 +: 32]), .s_req_wstrb(p_req_wstrb[m*4 +: 4]),
      .s_rsp_valid(p_rsp_valid[m]), .s_rsp_ready(p_rsp_ready[m]), .s_rsp_rdata(p_rsp_rdata[m*32 +: 32]),
      .s_rsp_error(p_rsp_error[m]),
      .vspm_own(vspm_own),
      .t_req_valid(t_req_valid[m*NT +: NT]), .t_req_ready(t_req_ready[m*NT +: NT]), .t_req_write(t_req_write[m]),
      .t_req_addr(t_req_addr[m*32 +: 32]), .t_req_wdata(t_req_wdata[m*32 +: 32]), .t_req_wstrb(t_req_wstrb[m*4 +: 4]),
      .t_rsp_valid(t_rsp_valid[m*NT +: NT]), .t_rsp_ready(t_rsp_ready[m*NT +: NT]),
      .t_rsp_rdata(t_rsp_rdata[m*NT*32 +: NT*32]), .t_rsp_error(t_rsp_error[m*NT +: NT]),
      .err_evt(pe_evt[m]), .err_cause(pe_cause[m*4 +: 4]), .err_addr(pe_addr[m*32 +: 32]), .err_write(pe_write[m]),
      .ev_req_stall(p_stall_u[m]), .ev_req_accept(p_acc_u[m])
    );
  end

  // per-target views of the port channels
  function automatic logic [NM-1:0] col(input logic [NM*NT-1:0] v, input int t);
    for (int m = 0; m < NM; m++) col[m] = v[m*NT + t];
  endfunction

  // ============================================================ shared SRAM (6 ports)
  logic [NM-1:0]      s_ready, s_rvalid, s_rerr, s_acc, s_conf;
  logic [NM*32-1:0]   s_rdata;
  logic [SRAM_BANKS-1:0] s_bank;
  logic [5:0]         s_rdb, s_wrb;
  logic               s_par, l_par, s_busy, l_busy;
  logic [3:0]         s_syn, l_syn;
  logic [31:0]        s_paddr, l_paddr;
  logic [2:0]         s_pport, l_pport;

  sfmem_banked #(
    .NP(NM), .BYTES(sfmem_map_pkg::SRAM_BYTES), .BANKS(SRAM_BANKS), .RD_LAT(SRAM_RD_LAT), .ILV_HIGH(SRAM_ILV_HIGH),
    .ECC_MODE(ECC_MODE), .RSP_DEPTH(SRAM_RSP_DEPTH), .ARB(SRAM_ARB), .BACKEND(BACKEND), .MACRO(SRAM_MACRO),
    .BASE(sfmem_map_pkg::SRAM_BASE)
  ) u_sram (
    .clk(clk), .rst_n(rst_n),
    .p_req_valid(col(t_req_valid, TG_SRAM)), .p_req_ready(s_ready), .p_req_write(t_req_write),
    .p_req_addr(t_req_addr), .p_req_wdata(t_req_wdata), .p_req_wstrb(t_req_wstrb),
    .p_rsp_valid(s_rvalid), .p_rsp_ready(col(t_rsp_ready, TG_SRAM)), .p_rsp_rdata(s_rdata), .p_rsp_error(s_rerr),
    .chk_dis(chk_dis), .inj_req(inj_sram_req), .inj_lanes(inj_lanes), .inj_ack(inj_sram_ack),
    .par_evt(s_par), .par_syn(s_syn), .par_addr(s_paddr), .par_port(s_pport),
    .ev_acc(s_acc), .ev_conf(s_conf), .ev_bank(s_bank), .ev_rd_bytes(s_rdb), .ev_wr_bytes(s_wrb),
    .tst_active(sram_tst_active), .tst_sel(sram_tst_sel), .tst_ce(sram_tst_ce), .tst_we(sram_tst_we),
    .tst_addr(sram_tst_addr), .tst_wdata(sram_tst_wdata), .tst_rdata(sram_tst_rdata), .busy(s_busy)
  );

  // ============================================================ LMEM (ports for DBG, CPUI, CPUD)
  localparam int NL = 3;
  logic [NL-1:0]    l_ready, l_rvalid, l_rerr, l_acc, l_conf;
  logic [NL*32-1:0] l_rdata;
  logic [LMEM_BANKS-1:0] l_bank_u;
  logic [5:0]       l_rdb_u, l_wrb_u;
  logic [NM-1:0]    lv, lrr;
  assign lv  = col(t_req_valid, TG_LMEM);
  assign lrr = col(t_rsp_ready, TG_LMEM);

  sfmem_banked #(
    .NP(NL), .BYTES(sfmem_map_pkg::LMEM_BYTES), .BANKS(LMEM_BANKS), .RD_LAT(LMEM_RD_LAT),
    .ILV_HIGH(sfmem_map_pkg::LMEM_INTERLEAVE_HIGH), .ECC_MODE(ECC_MODE), .RSP_DEPTH(LMEM_RD_LAT + 1),
    .ARB(`SRAM_ARB_RR), .BACKEND(BACKEND), .MACRO(LMEM_MACRO), .BASE(sfmem_map_pkg::LMEM_BASE)
  ) u_lmem (
    .clk(clk), .rst_n(rst_n),
    .p_req_valid(lv[NL-1:0]), .p_req_ready(l_ready), .p_req_write(t_req_write[NL-1:0]),
    .p_req_addr(t_req_addr[NL*32-1:0]), .p_req_wdata(t_req_wdata[NL*32-1:0]), .p_req_wstrb(t_req_wstrb[NL*4-1:0]),
    .p_rsp_valid(l_rvalid), .p_rsp_ready(lrr[NL-1:0]), .p_rsp_rdata(l_rdata), .p_rsp_error(l_rerr),
    .chk_dis(chk_dis), .inj_req(inj_lmem_req), .inj_lanes(inj_lanes), .inj_ack(inj_lmem_ack),
    .par_evt(l_par), .par_syn(l_syn), .par_addr(l_paddr), .par_port(l_pport),
    .ev_acc(l_acc), .ev_conf(l_conf), .ev_bank(l_bank_u), .ev_rd_bytes(l_rdb_u), .ev_wr_bytes(l_wrb_u),
    .tst_active(lmem_tst_active), .tst_sel(lmem_tst_sel), .tst_ce(lmem_tst_ce), .tst_we(lmem_tst_we),
    .tst_addr(lmem_tst_addr), .tst_wdata(lmem_tst_wdata), .tst_rdata(lmem_tst_rdata), .busy(l_busy)
  );

  // ============================================================ narrow targets
  // flat vectors on instance ports (Yosys 0.33 cannot take unpacked-array elements there); narrow target x at slice x
  logic [4*NM-1:0] x_ready, x_rvalid;
  logic [4*32-1:0] x_rdata, x_erra;
  logic [3:0]      x_rerr, x_txn, x_wait, x_err, x_errw;
  logic [4*3-1:0]  x_errm;

  // downstream ends: 0 EXT, 1 VSPM, 2 MMIO (io_*), 3 MEMCTL
  logic          r_req_valid, r_req_ready, r_req_write, r_rsp_valid, r_rsp_ready, r_rsp_error;
  logic [31:0]   r_req_addr, r_req_wdata, r_rsp_rdata;
  logic [3:0]    r_req_wstrb;
  logic [2:0]    r_req_master;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2:0]    ext_m_u, vs_m_u, io_m_u;
  /* verilator lint_on UNUSEDSIGNAL */

  sfmem_tgt_mux #(.NM(NM), .DEPTH(EXT_DEPTH)) u_ext (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(col(t_req_valid, TG_EXT)), .m_req_ready(x_ready[0*NM +: NM]), .m_req_write(t_req_write), .m_req_addr(t_req_addr),
    .m_req_wdata(t_req_wdata), .m_req_wstrb(t_req_wstrb), .m_rsp_valid(x_rvalid[0*NM +: NM]), .m_rsp_ready(col(t_rsp_ready, TG_EXT)),
    .m_rsp_rdata(x_rdata[0*32 +: 32]), .m_rsp_error(x_rerr[0]),
    .d_req_valid(ext_req_valid), .d_req_ready(ext_req_ready), .d_req_write(ext_req_write), .d_req_addr(ext_req_addr),
    .d_req_wdata(ext_req_wdata), .d_req_wstrb(ext_req_wstrb), .d_req_master(ext_m_u),
    .d_rsp_valid(ext_rsp_valid), .d_rsp_ready(ext_rsp_ready), .d_rsp_rdata(ext_rsp_rdata), .d_rsp_error(ext_rsp_error),
    .ev_txn(x_txn[0]), .ev_wait(x_wait[0]), .err_evt(x_err[0]), .err_master(x_errm[0*3 +: 3]), .err_addr(x_erra[0*32 +: 32]),
    .err_write(x_errw[0])
  );
  sfmem_tgt_mux #(.NM(NM), .DEPTH(VSPM_DEPTH)) u_vspm (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(col(t_req_valid, TG_VSPM)), .m_req_ready(x_ready[1*NM +: NM]), .m_req_write(t_req_write), .m_req_addr(t_req_addr),
    .m_req_wdata(t_req_wdata), .m_req_wstrb(t_req_wstrb), .m_rsp_valid(x_rvalid[1*NM +: NM]), .m_rsp_ready(col(t_rsp_ready, TG_VSPM)),
    .m_rsp_rdata(x_rdata[1*32 +: 32]), .m_rsp_error(x_rerr[1]),
    .d_req_valid(vs_req_valid), .d_req_ready(vs_req_ready), .d_req_write(vs_req_write), .d_req_addr(vs_req_addr),
    .d_req_wdata(vs_req_wdata), .d_req_wstrb(vs_req_wstrb), .d_req_master(vs_m_u),
    .d_rsp_valid(vs_rsp_valid), .d_rsp_ready(vs_rsp_ready), .d_rsp_rdata(vs_rsp_rdata), .d_rsp_error(vs_rsp_error),
    .ev_txn(x_txn[1]), .ev_wait(x_wait[1]), .err_evt(x_err[1]), .err_master(x_errm[1*3 +: 3]), .err_addr(x_erra[1*32 +: 32]),
    .err_write(x_errw[1])
  );
  sfmem_tgt_mux #(.NM(NM), .DEPTH(MMIO_DEPTH)) u_mmio (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(col(t_req_valid, TG_MMIO)), .m_req_ready(x_ready[2*NM +: NM]), .m_req_write(t_req_write), .m_req_addr(t_req_addr),
    .m_req_wdata(t_req_wdata), .m_req_wstrb(t_req_wstrb), .m_rsp_valid(x_rvalid[2*NM +: NM]), .m_rsp_ready(col(t_rsp_ready, TG_MMIO)),
    .m_rsp_rdata(x_rdata[2*32 +: 32]), .m_rsp_error(x_rerr[2]),
    .d_req_valid(io_req_valid), .d_req_ready(io_req_ready), .d_req_write(io_req_write), .d_req_addr(io_req_addr),
    .d_req_wdata(io_req_wdata), .d_req_wstrb(io_req_wstrb), .d_req_master(io_m_u),
    .d_rsp_valid(io_rsp_valid), .d_rsp_ready(io_rsp_ready), .d_rsp_rdata(io_rsp_rdata), .d_rsp_error(io_rsp_error),
    .ev_txn(x_txn[2]), .ev_wait(x_wait[2]), .err_evt(x_err[2]), .err_master(x_errm[2*3 +: 3]), .err_addr(x_erra[2*32 +: 32]),
    .err_write(x_errw[2])
  );
  sfmem_tgt_mux #(.NM(NM), .DEPTH(1)) u_regs_mux (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(col(t_req_valid, TG_REGS)), .m_req_ready(x_ready[3*NM +: NM]), .m_req_write(t_req_write), .m_req_addr(t_req_addr),
    .m_req_wdata(t_req_wdata), .m_req_wstrb(t_req_wstrb), .m_rsp_valid(x_rvalid[3*NM +: NM]), .m_rsp_ready(col(t_rsp_ready, TG_REGS)),
    .m_rsp_rdata(x_rdata[3*32 +: 32]), .m_rsp_error(x_rerr[3]),
    .d_req_valid(r_req_valid), .d_req_ready(r_req_ready), .d_req_write(r_req_write), .d_req_addr(r_req_addr),
    .d_req_wdata(r_req_wdata), .d_req_wstrb(r_req_wstrb), .d_req_master(r_req_master),
    .d_rsp_valid(r_rsp_valid), .d_rsp_ready(r_rsp_ready), .d_rsp_rdata(r_rsp_rdata), .d_rsp_error(r_rsp_error),
    .ev_txn(x_txn[3]), .ev_wait(x_wait[3]), .err_evt(x_err[3]), .err_master(x_errm[9 +: 3]), .err_addr(x_erra[96 +: 32]),
    .err_write(x_errw[3])   // REG errors are reported by sfmem_regs itself
  );

  // ============================================================ target -> port return channels
  always_comb begin
    for (int m = 0; m < NM; m++) begin
      for (int t = 0; t < NT; t++) begin
        t_req_ready[m*NT + t]         = 1'b0;
        t_rsp_valid[m*NT + t]         = 1'b0;
        t_rsp_error[m*NT + t]         = 1'b0;
        t_rsp_rdata[(m*NT + t)*32 +: 32] = 32'd0;
      end
      // SRAM
      t_req_ready[m*NT + TG_SRAM]            = s_ready[m];
      t_rsp_valid[m*NT + TG_SRAM]            = s_rvalid[m];
      t_rsp_error[m*NT + TG_SRAM]            = s_rerr[m];
      t_rsp_rdata[(m*NT + TG_SRAM)*32 +: 32] = s_rdata[m*32 +: 32];
      // LMEM (requesters 0..2 only)
      if (m < NL) begin
        t_req_ready[m*NT + TG_LMEM]            = l_ready[m];
        t_rsp_valid[m*NT + TG_LMEM]            = l_rvalid[m];
        t_rsp_error[m*NT + TG_LMEM]            = l_rerr[m];
        t_rsp_rdata[(m*NT + TG_LMEM)*32 +: 32] = l_rdata[m*32 +: 32];
      end
      // narrow targets
      t_req_ready[m*NT + TG_EXT]  = x_ready[0*NM + m];  t_rsp_valid[m*NT + TG_EXT]  = x_rvalid[0*NM + m];
      t_rsp_error[m*NT + TG_EXT]  = x_rerr[0];      t_rsp_rdata[(m*NT + TG_EXT)*32 +: 32]  = x_rdata[0*32 +: 32];
      t_req_ready[m*NT + TG_VSPM] = x_ready[1*NM + m];  t_rsp_valid[m*NT + TG_VSPM] = x_rvalid[1*NM + m];
      t_rsp_error[m*NT + TG_VSPM] = x_rerr[1];      t_rsp_rdata[(m*NT + TG_VSPM)*32 +: 32] = x_rdata[1*32 +: 32];
      t_req_ready[m*NT + TG_MMIO] = x_ready[2*NM + m];  t_rsp_valid[m*NT + TG_MMIO] = x_rvalid[2*NM + m];
      t_rsp_error[m*NT + TG_MMIO] = x_rerr[2];      t_rsp_rdata[(m*NT + TG_MMIO)*32 +: 32] = x_rdata[2*32 +: 32];
      t_req_ready[m*NT + TG_REGS] = x_ready[3*NM + m];  t_rsp_valid[m*NT + TG_REGS] = x_rvalid[3*NM + m];
      t_rsp_error[m*NT + TG_REGS] = x_rerr[3];      t_rsp_rdata[(m*NT + TG_REGS)*32 +: 32] = x_rdata[3*32 +: 32];
    end
  end

  // ============================================================ MEMCTL
  logic [NE-1:0]    e_evt, e_write;
  logic [NE*4-1:0]  e_cause;
  logic [NE*3-1:0]  e_master;
  logic [NE*32-1:0] e_addr;
  logic             rg_evt, rg_write;
  logic [31:0]      rg_addr;
  logic [2:0]       rg_master;
  logic [NPERF*8-1:0] pc_inc;

  always_comb begin
    // 0..5: requester-port decode errors
    for (int m = 0; m < NM; m++) begin
      e_evt[m]            = pe_evt[m];
      e_cause[m*4 +: 4]   = pe_cause[m*4 +: 4];
      e_master[m*3 +: 3]  = 3'(m);
      e_addr[m*32 +: 32]  = pe_addr[m*32 +: 32];
      e_write[m]          = pe_write[m];
    end
    // 6..8: downstream EXT / VSPM / MMIO answered with an error
    for (int x = 0; x < 3; x++) begin
      e_evt[6 + x]               = x_err[x];
      e_cause[(6 + x)*4 +: 4]    = sfmem_map_pkg::ERR_TARGET;
      e_master[(6 + x)*3 +: 3]   = x_errm[x*3 +: 3];
      e_addr[(6 + x)*32 +: 32]   = x_erra[x*32 +: 32];
      e_write[6 + x]             = x_errw[x];
    end
    // 9, 10: parity (SRAM, LMEM) -- the requester index equals the port index for both memories
    e_evt[9]  = s_par;  e_cause[36 +: 4] = sfmem_map_pkg::ERR_PARITY; e_master[27 +: 3] = s_pport;
    e_addr[9*32 +: 32]  = s_paddr; e_write[9] = 1'b0;
    e_evt[10] = l_par;  e_cause[40 +: 4] = sfmem_map_pkg::ERR_PARITY; e_master[30 +: 3] = l_pport;
    e_addr[10*32 +: 32] = l_paddr; e_write[10] = 1'b0;
    // 11: D-cache write-back refused (imprecise)
    e_evt[11] = dc_wb_err; e_cause[44 +: 4] = sfmem_map_pkg::ERR_WRITEBACK; e_master[33 +: 3] = 3'(MD);
    e_addr[11*32 +: 32] = dc_wb_err_addr; e_write[11] = 1'b1;
    // 12: MEMCTL refused an access
    e_evt[12] = rg_evt; e_cause[48 +: 4] = sfmem_map_pkg::ERR_REG; e_master[36 +: 3] = rg_master;
    e_addr[12*32 +: 32] = rg_addr; e_write[12] = rg_write;
  end

  // performance increments (8 bits per counter)
  always_comb begin
    pc_inc = '0;
    for (int m = 0; m < NM; m++) begin
      pc_inc[(sfmem_map_pkg::PC_SRAM_ACC_M0 + m)*8 +: 8]  = 8'(s_acc[m]);
      pc_inc[(sfmem_map_pkg::PC_SRAM_CONF_M0 + m)*8 +: 8] = 8'(s_conf[m]);
      pc_inc[(sfmem_map_pkg::PC_REQ_STALL_M0 + m)*8 +: 8] = 8'(m_req_valid[m] && !m_req_ready[m]);
    end
    for (int b = 0; b < SRAM_BANKS && b < 8; b++)
      pc_inc[(sfmem_map_pkg::PC_SRAM_BANK0 + b)*8 +: 8] = 8'(s_bank[b]);
    pc_inc[sfmem_map_pkg::PC_SRAM_RD_BYTES*8 +: 8] = 8'(s_rdb);
    pc_inc[sfmem_map_pkg::PC_SRAM_WR_BYTES*8 +: 8] = 8'(s_wrb);
    pc_inc[sfmem_map_pkg::PC_LMEM_ACC*8 +: 8]      = 8'(l_acc[0]) + 8'(l_acc[1]) + 8'(l_acc[2]);
    pc_inc[sfmem_map_pkg::PC_LMEM_CONF*8 +: 8]     = 8'(l_conf[0]) + 8'(l_conf[1]) + 8'(l_conf[2]);
    pc_inc[sfmem_map_pkg::PC_DC_HIT*8 +: 8]        = 8'(dc_hit);
    pc_inc[sfmem_map_pkg::PC_DC_MISS*8 +: 8]       = 8'(dc_miss);
    pc_inc[sfmem_map_pkg::PC_DC_WB*8 +: 8]         = 8'(dc_wb);
    pc_inc[sfmem_map_pkg::PC_DC_BYPASS*8 +: 8]     = 8'(dc_byp);
    pc_inc[sfmem_map_pkg::PC_IC_HIT*8 +: 8]        = 8'(ic_hit);
    pc_inc[sfmem_map_pkg::PC_IC_MISS*8 +: 8]       = 8'(ic_miss);
    pc_inc[sfmem_map_pkg::PC_CMO_LINES*8 +: 8]     = 8'(dc_line) + 8'(ic_line);
    pc_inc[sfmem_map_pkg::PC_EXT_TXN*8 +: 8]       = 8'(x_txn[0]);
    pc_inc[sfmem_map_pkg::PC_EXT_STALL*8 +: 8]     = 8'(x_wait[0]);
    pc_inc[sfmem_map_pkg::PC_VSPM_TXN*8 +: 8]      = 8'(x_txn[1]);
    pc_inc[sfmem_map_pkg::PC_MMIO_TXN*8 +: 8]      = 8'(x_txn[2]) + 8'(x_txn[3]);
    for (int e = 0; e < NE; e++)
      pc_inc[sfmem_map_pkg::PC_ERRORS*8 +: 8] = pc_inc[sfmem_map_pkg::PC_ERRORS*8 +: 8] + 8'(e_evt[e]);
  end

  localparam logic [31:0] INFO_VALUE = {8'(NM), 3'($clog2(LMEM_BANKS)), 2'(ECC_MODE), 1'(DCACHE_EN != 0 && DCACHE_WB != 0),
                                        1'(DCACHE_EN != 0), 1'(ICACHE_EN != 0), 4'(SRAM_RD_LAT), 4'($clog2(SRAM_BANKS)),
                                        8'(sfmem_map_pkg::MAP_VERSION)};
  localparam logic [31:0] CACHE_INFO_VALUE = {14'd0, 1'(DCACHE_WB != 0), 1'(DCACHE_WB != 0), 4'(CACHE_WAYS),
                                              8'($clog2(CACHE_SETS)), 4'($clog2(CACHE_LINE))};

  sfmem_regs #(
    .NE(NE), .INFO_VALUE(INFO_VALUE), .CACHE_INFO_VALUE(CACHE_INFO_VALUE), .HAS_DCACHE(DCACHE_EN),
    .HAS_ICACHE(ICACHE_EN), .PERF_EN(PERF_EN)
  ) u_regs (
    .clk(clk), .rst_n(rst_n),
    .req_valid(r_req_valid), .req_ready(r_req_ready), .req_write(r_req_write), .req_addr(r_req_addr),
    .req_wdata(r_req_wdata), .req_wstrb(r_req_wstrb), .req_master(r_req_master),
    .rsp_valid(r_rsp_valid), .rsp_ready(r_rsp_ready), .rsp_rdata(r_rsp_rdata), .rsp_error(r_rsp_error),
    .dc_enable(dc_en), .ic_enable(ic_en), .cache_regions(cache_regions), .ncw_en(ncw_en), .ncw_base(ncw_base), .ncw_limit(ncw_limit),
    .dc_cmo_valid(dc_cmo_valid), .dc_cmo_ready(dc_cmo_ready), .ic_cmo_valid(ic_cmo_valid), .ic_cmo_ready(ic_cmo_ready),
    .cmo_op(cmo_op), .cmo_all(cmo_all), .cmo_addr(cmo_addr), .cmo_size(cmo_size),
    .dc_cmo_done(dc_cmo_done), .dc_cmo_lines(dc_cmo_lines), .dc_cmo_wb_err(dc_cmo_wb_err),
    .dc_cmo_discard(dc_cmo_discard), .ic_cmo_done(ic_cmo_done), .ic_cmo_lines(ic_cmo_lines),
    .ecc_chk_dis(chk_dis), .inj_sram_req(inj_sram_req), .inj_lmem_req(inj_lmem_req), .inj_lanes(inj_lanes),
    .inj_sram_ack(inj_sram_ack), .inj_lmem_ack(inj_lmem_ack),
    .par_evt(s_par || l_par), .par_syn(s_par ? s_syn : l_syn), .par_addr(s_par ? s_paddr : l_paddr),
    .par_master(s_par ? s_pport : l_pport), .par_lmem(!s_par),
    .vspm_own(vspm_own),
    .e_evt(e_evt), .e_cause(e_cause), .e_master(e_master), .e_addr(e_addr), .e_write(e_write), .e_wb(dc_wb_err),
    .pc_inc(pc_inc),
    .reg_err_evt(rg_evt), .reg_err_addr(rg_addr), .reg_err_master(rg_master), .reg_err_write(rg_write),
    .irq(irq)
  );

  assign busy = s_busy || l_busy || (|p_rsp_valid) || dc_cmo_valid || ic_cmo_valid;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, x_err[3], p_stall_u, p_acc_u, l_bank_u, l_rdb_u, l_wrb_u, ic_wb_u, ic_byp_u, ic_wb_err_u,
                     ic_wb_err_addr_u, lv[NM-1:NL], lrr[NM-1:NL], x_errw[3], x_errm[9 +: 3], x_erra[96 +: 32],
                     x_wait[3:1], ic_cmo_wb_err_u, ic_cmo_disc_u};
  // used only by the caches that are present (DCACHE_EN / ICACHE_EN = 0 leaves them unloaded)
  wire unused_cfg = &{1'b0, dc_en, ic_en, cache_regions, ncw_en, ncw_base, ncw_limit, cmo_op, cmo_all, cmo_addr, cmo_size,
                      dc_cmo_valid, ic_cmo_valid};
  /* verilator lint_on UNUSEDSIGNAL */

endmodule

`default_nettype wire
