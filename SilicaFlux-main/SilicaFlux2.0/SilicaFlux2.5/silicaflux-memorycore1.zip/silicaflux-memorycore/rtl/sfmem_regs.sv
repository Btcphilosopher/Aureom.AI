// =============================================================================
// SilicaFlux-HPC MemoryCore :: sfmem_regs -- MEMCTL register page (MMIO page 10)
//
// Offsets, reset values and field layouts come from memmap/memorycore.yaml via
// generated/sfmem_map_pkg.sv (MC_* constants); docs/MEMORY_MAP.md is the table.
//
// Access rules: 32-bit registers, word access only.  Refused accesses answer
// rsp_error = 1 with no side effect and raise a REG error event: a write with
// wstrb != 4'hF, a write to a read-only register, an unknown offset, CMO_CMD
// while BUSY or with OP = 0 / no cache selected, and a semaphore write other
// than a release by its holder.
//
// Slave timing: one transaction at a time; the response is registered (one
// cycle after acceptance) and held under back-pressure.  Side effects (CMO
// start, w1c, test-and-set) take place at the acceptance edge.
//
// Semaphores (the only atomic operation in MemoryCore, see docs/06): SEMn read =
// test-and-set in one register access, serialized by this single slave port,
// so two agents (e.g. the debug / host port and the ControlCore) can never both
// observe 0.  Atomicity domain: the MEMCTL page.  They order nothing else: use
// them with completed (acknowledged) data accesses, see docs/03 §7 (A1).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfmem_defs.svh"
`default_nettype none

module sfmem_regs #(
  parameter int NE          = 12,      // error-event sources
  parameter int NPERF       = sfmem_map_pkg::NUM_PERF,
  parameter int NPART       = sfmem_map_pkg::VSPM_PARTITIONS,
  parameter int NSEM        = 8,
  parameter logic [31:0] INFO_VALUE       = 32'd0,
  parameter logic [31:0] CACHE_INFO_VALUE = 32'd0,
  parameter int HAS_DCACHE  = 1,
  parameter int HAS_ICACHE  = 1,
  parameter int PERF_EN     = 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ---------------------------------------------------------- register slave (from sfmem_tgt_mux)
  input  wire logic              req_valid,
  output logic                   req_ready,
  input  wire logic              req_write,
  input  wire logic [31:0]       req_addr,
  input  wire logic [31:0]       req_wdata,
  input  wire logic [3:0]        req_wstrb,
  input  wire logic [2:0]        req_master,
  output logic                   rsp_valid,
  input  wire logic              rsp_ready,
  output logic [31:0]            rsp_rdata,
  output logic                   rsp_error,
  // ---------------------------------------------------------- cache configuration / maintenance
  output logic                   dc_enable,
  output logic                   ic_enable,
  output logic [sfmem_map_pkg::NUM_REGIONS-1:0] cache_regions,   // regions the caches may hold (CACHE_REGIONS)
  output logic [1:0]             ncw_en,
  output logic [63:0]            ncw_base,
  output logic [63:0]            ncw_limit,
  output logic                   dc_cmo_valid,
  input  wire logic              dc_cmo_ready,
  output logic                   ic_cmo_valid,
  input  wire logic              ic_cmo_ready,
  output logic [1:0]             cmo_op,
  output logic                   cmo_all,
  output logic [31:0]            cmo_addr,
  output logic [31:0]            cmo_size,
  input  wire logic              dc_cmo_done,
  input  wire logic [15:0]       dc_cmo_lines,
  input  wire logic              dc_cmo_wb_err,
  input  wire logic              dc_cmo_discard,
  input  wire logic              ic_cmo_done,
  input  wire logic [15:0]       ic_cmo_lines,
  // ---------------------------------------------------------- integrity control
  output logic                   ecc_chk_dis,
  output logic                   inj_sram_req,
  output logic                   inj_lmem_req,
  output logic [3:0]             inj_lanes,
  input  wire logic              inj_sram_ack,
  input  wire logic              inj_lmem_ack,
  input  wire logic              par_evt,          // one parity failure this cycle (SRAM has priority)
  input  wire logic [3:0]        par_syn,
  input  wire logic [31:0]       par_addr,
  input  wire logic [2:0]        par_master,
  input  wire logic              par_lmem,
  // ---------------------------------------------------------- VSPM ownership
  output logic [NPART-1:0]       vspm_own,
  // ---------------------------------------------------------- error events (source e at slice e)
  input  wire logic [NE-1:0]     e_evt,
  input  wire logic [NE*4-1:0]   e_cause,
  input  wire logic [NE*3-1:0]   e_master,
  input  wire logic [NE*32-1:0]  e_addr,
  input  wire logic [NE-1:0]     e_write,
  input  wire logic              e_wb,             // a write-back error is among this cycle's events
  // ---------------------------------------------------------- performance counter increments
  input  wire logic [NPERF*8-1:0] pc_inc,          // counter i adds pc_inc[i*8 +: 8] (CYCLES is internal)
  // ---------------------------------------------------------- outputs
  output logic                   reg_err_evt,      // this slave refused an access (fed back as an error source)
  output logic [31:0]            reg_err_addr,
  output logic [2:0]             reg_err_master,
  output logic                   reg_err_write,
  output logic                   irq
);

  localparam logic [31:0] PG = sfmem_map_pkg::MEMCTL_PAGE_BASE;

  // ------------------------------------------------------------ state
  logic [1:0]       ctrl_q;
  localparam int    NRG = sfmem_map_pkg::NUM_REGIONS;
  logic [NRG-1:0]   creg_q;
  logic [31:0]      cmo_addr_q, cmo_size_q;
  logic [1:0]       cmo_op_q;
  logic             cmo_all_q;
  logic             dc_pend, dc_run, ic_pend, ic_run, cmo_done_q, cmo_wberr_q, cmo_disc_q;
  logic [15:0]      cmo_lines_q;
  logic [31:0]      ncw_b [2];
  logic [31:0]      ncw_l [2];
  logic [1:0]       err_st;
  logic [31:0]      err_addr_q, err_cnt;
  logic [7:0]       err_info_q;
  logic [3:0]       irq_en, irq_st;
  logic [3:0]       inj_lanes_q;
  logic             inj_q, inj_lmem_q, chk_dis_q;
  logic [31:0]      par_addr_q, par_cnt;
  logic [8:0]       par_info_q;
  logic [NPART-1:0] own_q;
  logic [2:0]       sem_q [NSEM];          // 0 = free, else holder + 1
  logic [1:0]       perf_ctrl_q;
  logic [31:0]      pc_q [NPERF];
  logic             rv_q, re_q;
  logic [31:0]      rd_q;

  wire cmo_busy = dc_pend || dc_run || ic_pend || ic_run;

  // ------------------------------------------------------------ access decode
  wire        acc  = req_valid && req_ready;
  /* verilator lint_off UNUSEDSIGNAL */
  wire [19:0] unused_hi = req_addr[31:12];      // the page is decoded upstream
  wire [25:0] unused_pc = pc_i[31:6];
  wire        unused_inc = (PERF_EN == 0) && (|pc_inc);     // increments are dropped when PERF_EN = 0
  /* verilator lint_on UNUSEDSIGNAL */
  wire [11:0] off  = req_addr[11:0];
  wire        full = req_wstrb == 4'hF;
  logic [31:0] rdata;
  logic        bad;
  logic        is_sem, is_pc;
  logic [2:0]  sem_i;
  logic [31:0] pc_i;

  always_comb begin
    rdata  = 32'd0;
    bad    = 1'b0;
    is_sem = (off >= sfmem_map_pkg::MC_SEM0) && (off < sfmem_map_pkg::MC_SEM0 + 12'(4 * NSEM));
    sem_i  = 3'((32'(off) - 32'(sfmem_map_pkg::MC_SEM0)) >> 2);
    is_pc  = (off >= sfmem_map_pkg::MC_PERF_BASE) && (off < sfmem_map_pkg::MC_PERF_BASE + 12'(4 * NPERF));
    pc_i   = (32'(off) - 32'(sfmem_map_pkg::MC_PERF_BASE)) >> 2;
    if (is_sem) begin
      rdata = {29'd0, sem_q[sem_i]};
      if (req_write) bad = !full || (req_wdata != 32'd0) || (sem_q[sem_i] != req_master + 3'd1);
    end else if (is_pc) begin
      rdata = (PERF_EN != 0) ? pc_q[pc_i[5:0]] : 32'd0;
      bad   = req_write;
    end else begin
      case (off)
        sfmem_map_pkg::MC_ID:            begin rdata = sfmem_map_pkg::MEMCTL_ID_VALUE; bad = req_write; end
        sfmem_map_pkg::MC_INFO:          begin rdata = INFO_VALUE;                     bad = req_write; end
        sfmem_map_pkg::MC_CACHE_INFO:    begin rdata = CACHE_INFO_VALUE;               bad = req_write; end
        sfmem_map_pkg::MC_SRAM_SIZE:     begin rdata = 32'(sfmem_map_pkg::SRAM_BYTES); bad = req_write; end
        sfmem_map_pkg::MC_CACHE_CTRL:    rdata = {30'd0, ctrl_q};
        sfmem_map_pkg::MC_CMO_ADDR:      rdata = cmo_addr_q;
        sfmem_map_pkg::MC_CACHE_REGIONS: rdata = 32'(creg_q);
        sfmem_map_pkg::MC_CMO_SIZE:      rdata = cmo_size_q;
        sfmem_map_pkg::MC_CMO_CMD: begin
          rdata = 32'd0;                                   // write-only, reads 0
          if (req_write) bad = cmo_busy || (req_wdata[1:0] == 2'd0) || !(req_wdata[3] || req_wdata[4]) ||
                               (req_wdata[31:5] != 27'd0);
        end
        sfmem_map_pkg::MC_CMO_STATUS: begin
          rdata = {cmo_lines_q, 12'd0, cmo_disc_q, cmo_wberr_q, cmo_done_q, cmo_busy};
          bad   = req_write;
        end
        sfmem_map_pkg::MC_NCW0_BASE:     rdata = ncw_b[0];
        sfmem_map_pkg::MC_NCW0_LIMIT:    rdata = ncw_l[0];
        sfmem_map_pkg::MC_NCW1_BASE:     rdata = ncw_b[1];
        sfmem_map_pkg::MC_NCW1_LIMIT:    rdata = ncw_l[1];
        sfmem_map_pkg::MC_ERR_STATUS:    rdata = {30'd0, err_st};
        sfmem_map_pkg::MC_ERR_ADDR:      begin rdata = err_addr_q;        bad = req_write; end
        sfmem_map_pkg::MC_ERR_INFO:      begin rdata = {24'd0, err_info_q}; bad = req_write; end
        sfmem_map_pkg::MC_ERR_COUNT:     begin rdata = err_cnt;           bad = req_write; end
        sfmem_map_pkg::MC_IRQ_ENABLE:    rdata = {28'd0, irq_en};
        sfmem_map_pkg::MC_IRQ_STATUS:    rdata = {28'd0, irq_st};
        sfmem_map_pkg::MC_ECC_CTRL:      rdata = {15'd0, chk_dis_q, 6'd0, inj_lmem_q, inj_q, 4'd0, inj_lanes_q};
        sfmem_map_pkg::MC_ECC_ERR_ADDR:  begin rdata = par_addr_q;           bad = req_write; end
        sfmem_map_pkg::MC_ECC_ERR_INFO:  begin rdata = {23'd0, par_info_q};  bad = req_write; end
        sfmem_map_pkg::MC_ECC_ERR_COUNT: begin rdata = par_cnt;              bad = req_write; end
        sfmem_map_pkg::MC_VSPM_OWN:      rdata = 32'(own_q);
        sfmem_map_pkg::MC_PERF_CTRL:     rdata = {31'd0, perf_ctrl_q[0]};
        default:                         bad = 1'b1;
      endcase
    end
    if (req_write && !full) bad = 1'b1;
  end
  wire wr_ok = acc && req_write && !bad;

  assign req_ready = !rv_q;

  // ------------------------------------------------------------ response
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rv_q <= 1'b0;
      re_q <= 1'b0;
      rd_q <= 32'd0;
    end else if (acc) begin
      rv_q <= 1'b1;
      re_q <= bad;
      rd_q <= (bad || req_write) ? 32'd0 : rdata;
    end else if (rsp_ready) begin
      rv_q <= 1'b0;
    end
  end
  assign rsp_valid = rv_q;
  assign rsp_rdata = rd_q;
  assign rsp_error = re_q;

  assign reg_err_evt    = acc && bad;
  assign reg_err_addr   = PG | {20'd0, off};
  assign reg_err_master = req_master;
  assign reg_err_write  = req_write;

  // ------------------------------------------------------------ error capture
  logic       e_any, e_par_any;
  logic [4:0] e_n;
  logic [3:0] e_c;
  logic [2:0] e_m;
  logic [31:0] e_a;
  logic        e_w;
  always_comb begin
    e_any = 1'b0;
    e_n   = 5'd0;
    e_c   = 4'd0;
    e_m   = 3'd0;
    e_a   = 32'd0;
    e_w   = 1'b0;
    for (int e = NE - 1; e >= 0; e--) begin
      if (e_evt[e]) begin
        e_any = 1'b1;
        e_c   = e_cause[e*4 +: 4];
        e_m   = e_master[e*3 +: 3];
        e_a   = e_addr[e*32 +: 32];
        e_w   = e_write[e];
      end
    end
    for (int e = 0; e < NE; e++) e_n = e_n + 5'(e_evt[e]);
    e_par_any = par_evt;
  end

  // ------------------------------------------------------------ sequential state
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctrl_q      <= 2'd0;
      creg_q      <= sfmem_map_pkg::CACHE_DEFAULT;
      cmo_addr_q  <= 32'd0;
      cmo_size_q  <= 32'd0;
      cmo_op_q    <= 2'd0;
      cmo_all_q   <= 1'b0;
      dc_pend     <= 1'b0;
      dc_run      <= 1'b0;
      ic_pend     <= 1'b0;
      ic_run      <= 1'b0;
      cmo_done_q  <= 1'b0;
      cmo_wberr_q <= 1'b0;
      cmo_disc_q  <= 1'b0;
      cmo_lines_q <= 16'd0;
      for (int n = 0; n < 2; n++) begin
        ncw_b[n] <= 32'd0;
        ncw_l[n] <= 32'd0;
      end
      err_st      <= 2'd0;
      err_addr_q  <= 32'd0;
      err_info_q  <= 8'd0;
      err_cnt     <= 32'd0;
      irq_en      <= 4'd0;
      irq_st      <= 4'd0;
      inj_lanes_q <= 4'd0;
      inj_q       <= 1'b0;
      inj_lmem_q  <= 1'b0;
      chk_dis_q   <= 1'b0;
      par_addr_q  <= 32'd0;
      par_info_q  <= 9'd0;
      par_cnt     <= 32'd0;
      own_q       <= '0;
      for (int n = 0; n < NSEM; n++) sem_q[n] <= 3'd0;
      perf_ctrl_q <= 2'd0;
    end else begin
      // ---------------------------------------------------- maintenance sequencing
      if (dc_cmo_ready) begin dc_pend <= 1'b0; dc_run <= 1'b1; end
      if (ic_cmo_ready) begin ic_pend <= 1'b0; ic_run <= 1'b1; end
      if (dc_cmo_done) begin
        dc_run      <= 1'b0;
        cmo_lines_q <= cmo_lines_q + dc_cmo_lines;
        cmo_wberr_q <= cmo_wberr_q | dc_cmo_wb_err;
        cmo_disc_q  <= cmo_disc_q | dc_cmo_discard;
      end
      if (ic_cmo_done) begin
        ic_run <= 1'b0;
      end
      if (ic_cmo_done && !dc_cmo_done) cmo_lines_q <= cmo_lines_q + ic_cmo_lines;
      if (ic_cmo_done && dc_cmo_done)  cmo_lines_q <= cmo_lines_q + dc_cmo_lines + ic_cmo_lines;
      if (cmo_busy && !((dc_pend || dc_run) && !dc_cmo_done) && !((ic_pend || ic_run) && !ic_cmo_done)) begin
        cmo_done_q <= 1'b1;                              // last running part finishes this cycle
        irq_st[2]  <= 1'b1;
      end
      // ---------------------------------------------------- error capture
      if (e_any) begin
        if (!err_st[0]) begin
          err_st[0]  <= 1'b1;
          err_addr_q <= e_a;
          err_info_q <= {e_w, e_m, e_c};
        end else begin
          err_st[1] <= 1'b1;
        end
        if (e_n > 5'd1 && !err_st[0]) err_st[1] <= 1'b1;
        err_cnt   <= (err_cnt > 32'hFFFF_FFFF - 32'(e_n)) ? 32'hFFFF_FFFF : err_cnt + 32'(e_n);
        irq_st[0] <= 1'b1;
      end
      if (e_wb) irq_st[3] <= 1'b1;
      if (e_par_any) begin
        par_addr_q <= par_addr;
        par_info_q <= {par_lmem, 1'b0, par_master, par_syn};
        par_cnt    <= (par_cnt == 32'hFFFF_FFFF) ? par_cnt : par_cnt + 32'd1;
        irq_st[1]  <= 1'b1;
      end
      // ---------------------------------------------------- parity injection consumed
      if ((inj_sram_ack && !inj_lmem_q) || (inj_lmem_ack && inj_lmem_q)) inj_q <= 1'b0;
      if (perf_ctrl_q[1]) perf_ctrl_q[1] <= 1'b0;
      // ---------------------------------------------------- semaphores: test-and-set on read
      if (acc && !req_write && is_sem && sem_q[sem_i] == 3'd0) sem_q[sem_i] <= req_master + 3'd1;
      // ---------------------------------------------------- register writes
      if (wr_ok) begin
        if (is_sem) sem_q[sem_i] <= 3'd0;                // release by the holder (checked in decode)
        else begin
          case (off)
            sfmem_map_pkg::MC_CACHE_CTRL: ctrl_q     <= req_wdata[1:0];
            sfmem_map_pkg::MC_CMO_ADDR:   cmo_addr_q <= req_wdata;
            sfmem_map_pkg::MC_CACHE_REGIONS: creg_q <= req_wdata[NRG-1:0] & sfmem_map_pkg::CACHEABLE;
            sfmem_map_pkg::MC_CMO_SIZE:   cmo_size_q <= req_wdata;
            sfmem_map_pkg::MC_CMO_CMD: begin
              cmo_op_q    <= req_wdata[1:0];
              cmo_all_q   <= req_wdata[2];
              dc_pend     <= req_wdata[3] && (HAS_DCACHE != 0);
              ic_pend     <= req_wdata[4] && (HAS_ICACHE != 0);
              cmo_done_q  <= 1'b0;
              cmo_wberr_q <= 1'b0;
              cmo_disc_q  <= 1'b0;
              cmo_lines_q <= 16'd0;
              if (!((req_wdata[3] && HAS_DCACHE != 0) || (req_wdata[4] && HAS_ICACHE != 0))) begin
                cmo_done_q <= 1'b1;                      // no selected cache present: nothing to do
                irq_st[2]  <= 1'b1;
              end
            end
            sfmem_map_pkg::MC_NCW0_BASE:  ncw_b[0] <= {req_wdata[31:2], 1'b0, req_wdata[0]};
            sfmem_map_pkg::MC_NCW0_LIMIT: ncw_l[0] <= req_wdata;
            sfmem_map_pkg::MC_NCW1_BASE:  ncw_b[1] <= {req_wdata[31:2], 1'b0, req_wdata[0]};
            sfmem_map_pkg::MC_NCW1_LIMIT: ncw_l[1] <= req_wdata;
            sfmem_map_pkg::MC_ERR_STATUS: err_st <= err_st & ~req_wdata[1:0];
            sfmem_map_pkg::MC_IRQ_ENABLE: irq_en <= req_wdata[3:0];
            sfmem_map_pkg::MC_IRQ_STATUS: irq_st <= irq_st & ~req_wdata[3:0];
            sfmem_map_pkg::MC_ECC_CTRL: begin
              inj_lanes_q <= req_wdata[3:0];
              inj_lmem_q  <= req_wdata[9];
              chk_dis_q   <= req_wdata[16];
              if (req_wdata[8]) inj_q <= 1'b1;
            end
            sfmem_map_pkg::MC_VSPM_OWN:   own_q <= req_wdata[NPART-1:0];
            sfmem_map_pkg::MC_PERF_CTRL:  perf_ctrl_q <= req_wdata[1:0];
            default: ;
          endcase
        end
      end
    end
  end

  // ------------------------------------------------------------ performance counters
  for (genvar i = 0; i < NPERF; i++) begin : g_pc
    if (PERF_EN != 0) begin : g_on
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)                pc_q[i] <= 32'd0;
        else if (perf_ctrl_q[1])   pc_q[i] <= 32'd0;
        else if (!perf_ctrl_q[0])  pc_q[i] <= pc_q[i] + ((i == sfmem_map_pkg::PC_CYCLES) ? 32'd1 : 32'(pc_inc[i*8 +: 8]));
      end
    end else begin : g_off
      assign pc_q[i] = 32'd0;
    end
  end

  // ------------------------------------------------------------ outputs
  assign dc_enable    = ctrl_q[0];
  assign ic_enable    = ctrl_q[1];
  assign cache_regions = creg_q;
  assign ncw_en       = {ncw_b[1][0], ncw_b[0][0]};
  assign ncw_base     = {ncw_b[1], ncw_b[0]};
  assign ncw_limit    = {ncw_l[1], ncw_l[0]};
  assign dc_cmo_valid = dc_pend;
  assign ic_cmo_valid = ic_pend;
  assign cmo_op       = cmo_op_q;
  assign cmo_all      = cmo_all_q;
  assign cmo_addr     = cmo_addr_q;
  assign cmo_size     = cmo_size_q;
  assign ecc_chk_dis  = chk_dis_q;
  assign inj_sram_req = inj_q && !inj_lmem_q;
  assign inj_lmem_req = inj_q && inj_lmem_q;
  assign inj_lanes    = inj_lanes_q;
  assign vspm_own     = own_q;
  assign irq          = |(irq_st & irq_en);

endmodule

`default_nettype wire
