// =============================================================================
// SilicaFlux-HPC MemoryCore :: sfmem_port -- one requester's router
//
// Upstream: one SFB2 master (a requester, or a cache's downstream side).
// Function: decode the byte address against the generated map, enforce the
// access matrix, alignment and VSPM partition ownership, route the request to
// one target, and return the responses in this requester's acceptance order.
//
// Decode priority (first match wins; the reference model uses the same order):
//   1. MISALIGNED  addr[1:0] != 0                              (SFB2 R9)
//   2. UNMAPPED    no region contains addr
//   3. DENIED      access matrix bit (master, region) = 0
//   4. OWNERSHIP   VSPM partition owned by the engine (vspm_own)
//   otherwise      LMEM / SRAM / VSPM / EXT, or MMIO -> REGS (MEMCTL page) / MMIO (any other page)
// An error request is accepted and answered with rsp_error = 1, rdata = 0,
// one cycle or more later, in order, with no side effect anywhere.
//
// Ordering: a FIFO of MAX_OUT target numbers records every accepted request;
// the response channel is taken only from the target at its head, so
// responses return in acceptance order even when consecutive requests go to
// different targets with different latencies.  A target holds a response for
// this port until the port's head reaches it (bank controllers keep it in this
// port's own response FIFO; narrow targets in their owner FIFO).  Deadlock
// freedom: docs/03_CONSISTENCY.md §6 (the globally oldest outstanding request
// is at the head of both its port FIFO and its target's owner FIFO).
//
// Timing: zero added cycles in both directions (req_ready = target ready,
// response mux is combinational).  req_ready never depends on rsp_ready.
// Request stability: payload sampled only on acceptance, so the SilicaFlux-V
// instruction port's documented address change before grant (ISS-017) is
// harmless.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfmem_defs.svh"
`default_nettype none

module sfmem_port #(
  parameter int MIDX    = 0,        // requester index (row of the access matrix)
  parameter int MAX_OUT = 4,        // outstanding transactions tracked (>= 1)
  localparam int NT     = `SFMEM_NT,
  localparam int NPART  = sfmem_map_pkg::VSPM_PARTITIONS,
  localparam int CW     = $clog2(MAX_OUT + 1),
  localparam int PW     = (MAX_OUT > 1) ? $clog2(MAX_OUT) : 1
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- upstream SFB2 (this module is the slave)
  input  wire logic             s_req_valid,
  output logic                  s_req_ready,
  input  wire logic             s_req_write,
  input  wire logic [31:0]      s_req_addr,
  input  wire logic [31:0]      s_req_wdata,
  input  wire logic [3:0]       s_req_wstrb,
  output logic                  s_rsp_valid,
  input  wire logic             s_rsp_ready,
  output logic [31:0]           s_rsp_rdata,
  output logic                  s_rsp_error,
  // ---------------------------------------------------------- VSPM partition ownership (1 = engine-owned)
  input  wire logic [NPART-1:0] vspm_own,
  // ---------------------------------------------------------- targets (payload shared, valid/ready per target)
  output logic [NT-1:0]         t_req_valid,
  input  wire logic [NT-1:0]    t_req_ready,
  output logic                  t_req_write,
  output logic [31:0]           t_req_addr,
  output logic [31:0]           t_req_wdata,
  output logic [3:0]            t_req_wstrb,
  input  wire logic [NT-1:0]    t_rsp_valid,
  output logic [NT-1:0]         t_rsp_ready,
  input  wire logic [NT*32-1:0] t_rsp_rdata,
  input  wire logic [NT-1:0]    t_rsp_error,
  // ---------------------------------------------------------- decode-error event (one per accepted error request)
  output logic                  err_evt,
  output logic [3:0]            err_cause,
  output logic [31:0]           err_addr,
  output logic                  err_write,
  // ---------------------------------------------------------- performance events
  output logic                  ev_req_stall,     // request presented and not accepted
  output logic                  ev_req_accept
);

  if (MAX_OUT < 1) begin : g_err_max_out
    `SFMEM_CFG_FATAL("sfmem_port: MAX_OUT must be >= 1")
  end

  localparam int NR = sfmem_map_pkg::NUM_REGIONS;
  localparam logic [NR*32-1:0] RBASE = sfmem_map_pkg::REGION_BASE;
  localparam logic [NR*32-1:0] RMASK = sfmem_map_pkg::REGION_MASK;
  localparam logic [NR-1:0]    ACC   = NR'(sfmem_map_pkg::ACCESS_EN >> (MIDX * NR));
  localparam int               PLOG  = $clog2(sfmem_map_pkg::VSPM_BYTES / NPART);   // partition size log2
  localparam int               PIW   = (NPART > 1) ? $clog2(NPART) : 1;
  localparam int               PGL   = $clog2(sfmem_map_pkg::PAGE_BYTES);
  localparam int               PGW   = $clog2(sfmem_map_pkg::MMIO_BYTES / sfmem_map_pkg::PAGE_BYTES);

  // ============================================================ decode
  logic [NR-1:0] hit;
  logic [2:0]    rsel;          // region index of the hit
  logic          any_hit, mis, den, own_err, is_err;
  logic [3:0]    cause;
  logic [2:0]    tgt;           // target of the presented request
  logic [PGW-1:0] page;
  logic [PIW-1:0] part;

  always_comb begin
    hit  = '0;
    rsel = 3'd0;
    for (int r = 0; r < NR; r++) begin
      hit[r] = (s_req_addr & RMASK[r*32 +: 32]) == RBASE[r*32 +: 32];
    end
    for (int r = NR - 1; r >= 0; r--) begin
      if (hit[r]) rsel = 3'(r);
    end
    any_hit = |hit;
    mis     = s_req_addr[1:0] != 2'b00;
    den     = any_hit && !ACC[rsel];
    page    = s_req_addr[PGL +: PGW];
    part    = (NPART > 1) ? PIW'(s_req_addr[PLOG +: PIW]) : '0;
    own_err = (rsel == 3'(sfmem_map_pkg::R_VSPM)) && vspm_own[part];
    is_err  = mis || !any_hit || den || own_err;
    cause   = mis      ? sfmem_map_pkg::ERR_MISALIGNED :
              !any_hit ? sfmem_map_pkg::ERR_UNMAPPED :
              den      ? sfmem_map_pkg::ERR_DENIED :
              own_err  ? sfmem_map_pkg::ERR_OWNERSHIP : sfmem_map_pkg::ERR_NONE;
    if (is_err)                                                           tgt = `SFMEM_TG_ERR;
    else if (rsel == 3'(sfmem_map_pkg::R_MMIO) && page == PGW'(sfmem_map_pkg::PG_MEMCTL)) tgt = `SFMEM_TG_REGS;
    else                                                                  tgt = rsel;   // region index == target
  end

  // ============================================================ ordering FIFO (target of each accepted request)
  logic [2:0]    q_tgt [MAX_OUT];
  logic [PW-1:0] q_rd, q_wr;
  logic [CW-1:0] q_cnt;
  logic          full, empty, acc, pop;
  logic [2:0]    head;

  assign full  = q_cnt == CW'(MAX_OUT);
  assign empty = q_cnt == '0;
  assign head  = q_tgt[q_rd];

  // request side: zero-cycle routing, accepted when tracked and the target is ready
  always_comb begin
    t_req_valid = '0;
    if (s_req_valid && !full && !is_err) t_req_valid[tgt] = 1'b1;
  end
  assign s_req_ready  = !full && (is_err || t_req_ready[tgt]);
  assign acc          = s_req_valid && s_req_ready;
  assign t_req_write  = s_req_write;
  assign t_req_addr   = s_req_addr;
  assign t_req_wdata  = s_req_wdata;
  assign t_req_wstrb  = s_req_wstrb;

  // response side: only the head target may respond
  always_comb begin
    t_rsp_ready = '0;
    s_rsp_valid = 1'b0;
    s_rsp_rdata = 32'd0;
    s_rsp_error = 1'b0;
    if (!empty) begin
      if (head == `SFMEM_TG_ERR) begin
        s_rsp_valid = 1'b1;           // entry exists only from the cycle after acceptance (SFB2 R5)
        s_rsp_error = 1'b1;
      end else begin
        s_rsp_valid = t_rsp_valid[head];
        s_rsp_rdata = t_rsp_rdata[head*32 +: 32];
        s_rsp_error = t_rsp_error[head];
        t_rsp_ready[head] = s_rsp_ready;
      end
    end
  end
  assign pop = !empty && s_rsp_valid && s_rsp_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_rd  <= '0;
      q_wr  <= '0;
      q_cnt <= '0;
    end else begin
      if (acc) q_wr <= (q_wr == PW'(MAX_OUT - 1)) ? '0 : q_wr + PW'(1);
      if (pop) q_rd <= (q_rd == PW'(MAX_OUT - 1)) ? '0 : q_rd + PW'(1);
      q_cnt <= q_cnt + CW'(acc) - CW'(pop);
    end
  end
  // payload storage: written only on acceptance, read only while valid (no reset needed)
  always_ff @(posedge clk) begin
    if (acc) q_tgt[q_wr] <= tgt;
  end

  // ============================================================ events
  assign err_evt       = acc && is_err;
  assign err_cause     = cause;
  assign err_addr      = s_req_addr;
  assign err_write     = s_req_write;
  assign ev_req_stall  = s_req_valid && !s_req_ready;
  assign ev_req_accept = acc;

`ifndef SYNTHESIS
`ifdef SFMEM_ASSERT
  // a target answers only when this port has selected it
  always_ff @(posedge clk) if (rst_n) begin
    for (int t = 0; t < NT; t++)
      if (t_rsp_ready[t] && (empty || head != 3'(t))) $error("%m: response ready to a non-head target %0d", t);
  end
`endif
`endif

endmodule

`default_nettype wire
