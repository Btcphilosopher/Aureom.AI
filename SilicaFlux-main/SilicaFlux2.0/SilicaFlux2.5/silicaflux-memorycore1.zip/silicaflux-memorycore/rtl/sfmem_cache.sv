// =============================================================================
// SilicaFlux-HPC MemoryCore :: sfmem_cache -- small NONCOHERENT ControlCore cache
//
// One module, two uses: D-cache on the ControlCore data port, I-cache on its
// instruction port (the I-port never writes).  It is NOT coherent with any other
// requester: DMA engines, the vector and tensor engines and the debug port do not
// snoop it and are not snooped.  Visibility is restored only by the maintenance
// operations below, issued by software (sw/include/sfmem.h) -- see
// docs/03_CONSISTENCY.md for the contract and docs/04_CACHE.md for the design.
//
// Geometry  : LINE_BYTES (>= 8, power of 2), SETS (>= 2, power of 2), WAYS 1/2/4/8.
// Storage   : tags / valid / dirty / PLRU in flops (valid, dirty, PLRU reset);
//             data in one SRAM-library 1RW macro per way (sram_backend_1rw,
//             SETS*LINE_BYTES/4 x 32 bit, byte mask, read latency 1).
// Policy    : WRITE_BACK = 1: write-back, write-allocate (store miss refills the line).
//             WRITE_BACK = 0: write-through, no-write-allocate; a store completes
//             (response) only after the downstream write response, so a completed
//             store is in memory (SFB2 R7) and needs no CLEAN.
// Replacement: first invalid way, else tree pseudo-LRU (WAYS-1 bits per set).
// Cacheable : enable && word-aligned && inside a region marked cacheable in the
//             map && enabled in CACHE_REGIONS (reset: the map's cache_default regions
//             -- EXT only, the measured case) && reachable by this requester &&
//             outside both non-cacheable windows.  Everything else is forwarded unchanged with ZERO added
//             cycles (combinational pass-through), up to MAX_OUT in flight, so
//             LMEM code / data and MMIO keep their full speed.
// Hit       : 1 cycle (response in the cycle after acceptance); back-to-back read
//             hits at one per cycle (accept-while-retiring).  Write hit: 1 cycle
//             (write-back) or downstream latency (write-through).
// Miss      : [write back the dirty victim: read WPL words, then WPL writes, all
//             acknowledged] -> refill WPL words (pipelined, MAX_OUT outstanding) ->
//             install -> respond.  A refill error leaves the line invalid and
//             answers the access with an error (precise).  A write-back error is
//             imprecise: reported on ev_wb_err (MEMCTL cause WRITEBACK).
// Maintenance (cmo_*): CLEAN / INVAL / CLEAN_INVAL on ALL lines or on every line
//             touched by [addr, addr+size).  Accepted only when nothing is in flight;
//             while cmo_valid is pending no new access is accepted, so a command is
//             ordered after every earlier access and before every later one
//             (implicit fence).  INVAL drops dirty data and reports it (discard).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfmem_defs.svh"
`default_nettype none

module sfmem_cache #(
  parameter int MIDX       = 2,          // requester index (access-matrix row) behind this cache
  parameter int LINE_BYTES = 16,
  parameter int SETS       = 64,
  parameter int WAYS       = 2,
  parameter int WRITE_BACK = 1,
  parameter int MAX_OUT    = 4,
  parameter int BACKEND    = `SRAM_BACKEND_GENERIC,
  parameter int MACRO      = 0,
  localparam int WPL       = LINE_BYTES / 4,
  localparam int OFFW      = $clog2(LINE_BYTES),
  localparam int SETW      = $clog2(SETS),
  localparam int TAGW      = 32 - OFFW - SETW,
  localparam int WDW       = $clog2(WPL),
  localparam int DEPTH     = SETS * WPL,
  localparam int DAW       = $clog2(DEPTH),
  localparam int WL        = (WAYS > 1) ? $clog2(WAYS) : 1,
  localparam int PB        = (WAYS > 1) ? WAYS - 1 : 1,
  localparam int CW        = $clog2(MAX_OUT + 1),
  localparam int KW        = $clog2(WPL + 1)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // ---------------------------------------------------------- configuration (MEMCTL)
  input  wire logic        enable,
  input  wire logic [sfmem_map_pkg::NUM_REGIONS-1:0] reg_en,   // MEMCTL CACHE_REGIONS
  input  wire logic [1:0]  ncw_en,
  input  wire logic [63:0] ncw_base,        // window n at [n*32 +: 32]
  input  wire logic [63:0] ncw_limit,
  // ---------------------------------------------------------- upstream SFB2 (requester side)
  input  wire logic        u_req_valid,
  output logic             u_req_ready,
  input  wire logic        u_req_write,
  input  wire logic [31:0] u_req_addr,
  input  wire logic [31:0] u_req_wdata,
  input  wire logic [3:0]  u_req_wstrb,
  output logic             u_rsp_valid,
  input  wire logic        u_rsp_ready,
  output logic [31:0]      u_rsp_rdata,
  output logic             u_rsp_error,
  // ---------------------------------------------------------- downstream SFB2 (to sfmem_port)
  output logic             d_req_valid,
  input  wire logic        d_req_ready,
  output logic             d_req_write,
  output logic [31:0]      d_req_addr,
  output logic [31:0]      d_req_wdata,
  output logic [3:0]       d_req_wstrb,
  input  wire logic        d_rsp_valid,
  output logic             d_rsp_ready,
  input  wire logic [31:0] d_rsp_rdata,
  input  wire logic        d_rsp_error,
  // ---------------------------------------------------------- maintenance
  input  wire logic        cmo_valid,
  output logic             cmo_ready,       // pulse: command accepted
  input  wire logic [1:0]  cmo_op,
  input  wire logic        cmo_all,
  input  wire logic [31:0] cmo_addr,
  input  wire logic [31:0] cmo_size,
  output logic             cmo_done,        // pulse: command finished; stats below valid from then on
  output logic [15:0]      cmo_lines,
  output logic             cmo_wb_err,
  output logic             cmo_discard,
  // ---------------------------------------------------------- events
  output logic             ev_hit,
  output logic             ev_miss,
  output logic             ev_wb,           // one dirty line written back
  output logic             ev_bypass,
  output logic             ev_cmo_line,
  output logic             ev_wb_err,
  output logic [31:0]      wb_err_addr
);

  // ------------------------------------------------------------ configuration checks
  if (LINE_BYTES < 8 || (LINE_BYTES & (LINE_BYTES - 1)) != 0) begin : g_err_line
    `SFMEM_CFG_FATAL("sfmem_cache: LINE_BYTES must be a power of two >= 8")
  end
  if (SETS < 2 || (SETS & (SETS - 1)) != 0) begin : g_err_sets
    `SFMEM_CFG_FATAL("sfmem_cache: SETS must be a power of two >= 2")
  end
  if (WAYS != 1 && WAYS != 2 && WAYS != 4 && WAYS != 8) begin : g_err_ways
    `SFMEM_CFG_FATAL("sfmem_cache: WAYS must be 1, 2, 4 or 8")
  end
  if (MAX_OUT < 1 || MAX_OUT > 15) begin : g_err_max_out
    `SFMEM_CFG_FATAL("sfmem_cache: MAX_OUT must be 1..15")
  end
  if (WRITE_BACK != 0 && WRITE_BACK != 1) begin : g_err_wb
    `SFMEM_CFG_FATAL("sfmem_cache: WRITE_BACK must be 0 or 1")
  end

  localparam int NR = sfmem_map_pkg::NUM_REGIONS;
  localparam logic [NR-1:0] CACH = sfmem_map_pkg::CACHEABLE & NR'(sfmem_map_pkg::ACCESS_EN >> (MIDX * NR));

  // ------------------------------------------------------------ helpers
  function automatic logic [31:0] lix(input logic [SETW-1:0] s, input logic [WL-1:0] w);
    lix = 32'(s) * 32'(WAYS) + 32'(w);
  endfunction
  function automatic logic is_cacheable(input logic [31:0] a, input logic en, input logic [1:0] nen,
                                        input logic [63:0] nb, input logic [63:0] nl, input logic [NR-1:0] ren);
    logic c;
    c = 1'b0;
    for (int r = 0; r < NR; r++)
      if (CACH[r] && ren[r] && ((a & sfmem_map_pkg::REGION_MASK[r*32 +: 32]) == sfmem_map_pkg::REGION_BASE[r*32 +: 32]))
        c = 1'b1;
    for (int n = 0; n < 2; n++)
      if (nen[n] && a >= {nb[n*32+2 +: 30], 2'b00} && a < nl[n*32 +: 32]) c = 1'b0;
    is_cacheable = en && c && (a[1:0] == 2'b00);
  endfunction

  function automatic logic [WL-1:0] plru_victim(input logic [PB-1:0] t);
    int node;
    node = 0;
    for (int l = 0; l < WL; l++) begin
      if (WAYS > 1) node = t[node] ? 2 * node + 2 : 2 * node + 1;
    end
    plru_victim = (WAYS > 1) ? WL'(node - (WAYS - 1)) : '0;
  endfunction

  // every node on the path to w points away from w
  function automatic logic [PB-1:0] plru_touch(input logic [PB-1:0] t, input logic [WL-1:0] w);
    logic [PB-1:0] r;
    int lvl, pos;
    r = t;
    if (WAYS > 1) begin
      for (int n = 0; n < PB; n++) begin
        lvl = 0;
        for (int k = 1; k < WL; k++) if (n + 1 >= (1 << k)) lvl = k;
        pos = n - ((1 << lvl) - 1);
        if ((32'(w) >> (WL - lvl)) == 32'(pos)) r[n] = !w[WL - 1 - lvl];
      end
    end
    plru_touch = r;
  endfunction

  // ------------------------------------------------------------ state
  localparam logic [3:0] S_IDLE = 4'd0, S_LOOKUP = 4'd1, S_HOLD = 4'd2, S_WT = 4'd3, S_EVRD = 4'd4, S_EVWR = 4'd5,
                         S_REFILL = 4'd6, S_FILLDONE = 4'd7, S_CMO = 4'd8, S_CMO_POST = 4'd9, S_CMO_END = 4'd10;
  logic [3:0] st, ret_st;

  logic [SETS*WAYS-1:0] valid_q, dirty_q;
  logic [SETS*PB-1:0]   plru_q;
  logic [TAGW-1:0]      tag_q [SETS*WAYS];

  logic [31:0]     r_addr, r_wdata, r_rdata, h_rdata;
  logic            r_write, h_error;
  logic [3:0]      r_wstrb;
  logic [WL-1:0]   r_way;                 // hit way (LOOKUP) or victim way (miss)
  logic            r_hit;
  logic [SETW-1:0] ev_set;
  logic [WL-1:0]   ev_way;
  logic [31:0]     ev_addr;               // line address being written back
  logic [31:0]     lbuf [WPL];
  logic [KW-1:0]   k_iss, k_rsp, k_rd;    // issued / answered downstream beats, eviction reads
  logic            beat_err;
  logic [CW-1:0]   byp_cnt;
  // maintenance
  logic [1:0]      c_op;
  logic            c_all;
  logic [31:0]     c_la, c_last;
  logic [SETW-1:0] c_set;
  logic [WL-1:0]   c_way;
  logic            c_none;
  logic [15:0]     c_lines;
  logic            c_wberr, c_disc;

  wire [SETW-1:0] r_set  = r_addr[OFFW +: SETW];
  wire [TAGW-1:0] r_tag  = r_addr[31 -: TAGW];
  wire [WDW-1:0]  r_word = r_addr[2 +: WDW];
  wire [31:0]     r_line = {r_addr[31:OFFW], {OFFW{1'b0}}};

  // ------------------------------------------------------------ data arrays
  logic [WAYS-1:0]    a_ce, a_we;
  logic [DAW-1:0]     a_addr;
  logic [31:0]        a_wdata;
  logic [3:0]         a_wmask;
  logic [WAYS*32-1:0] a_rdata;

  for (genvar w = 0; w < WAYS; w++) begin : g_way
    sram_backend_1rw #(
      .DATA_WIDTH(32), .DEPTH(DEPTH), .MASK_WIDTH(4), .READ_LATENCY(1), .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_data (
      .clk(clk), .ce(a_ce[w]), .we(a_we[w]), .wmask(a_wmask), .addr(a_addr), .wdata(a_wdata),
      .rdata(a_rdata[w*32 +: 32])
    );
  end

  // ------------------------------------------------------------ lookup (registered address, flop tags)
  logic [WAYS-1:0] hitv;
  logic [WL-1:0]   hit_way, inv_way, vic_way;
  logic            any_inv;
  always_comb begin
    hitv    = '0;
    hit_way = '0;
    inv_way = '0;
    any_inv = 1'b0;
    for (int w = 0; w < WAYS; w++) begin
      hitv[w] = valid_q[lix(r_set, WL'(w))] && (tag_q[lix(r_set, WL'(w))] == r_tag);
      if (hitv[w]) hit_way = WL'(w);
    end
    for (int w = WAYS - 1; w >= 0; w--) begin
      if (!valid_q[lix(r_set, WL'(w))]) begin
        any_inv = 1'b1;
        inv_way = WL'(w);
      end
    end
    vic_way = any_inv ? inv_way : plru_victim(plru_q[r_set*PB +: PB]);
  end
  wire hit = |hitv;
  wire [31:0] hit_data = a_rdata[hit_way*32 +: 32];

  // maintenance candidate (ALL: one way per cycle; RANGE: one line per cycle, all ways compared)
  logic [SETW-1:0] m_set;
  logic [WL-1:0]   m_way;
  logic            m_v, m_d;
  logic [31:0]     m_line;
  always_comb begin
    m_set = c_all ? c_set : c_la[OFFW +: SETW];
    m_way = c_way;
    m_v   = 1'b0;
    if (c_all) begin
      m_v = valid_q[lix(m_set, c_way)];
    end else begin
      for (int w = 0; w < WAYS; w++) begin
        if (valid_q[lix(m_set, WL'(w))] && tag_q[lix(m_set, WL'(w))] == c_la[31 -: TAGW]) begin
          m_v   = 1'b1;
          m_way = WL'(w);
        end
      end
    end
    m_d    = dirty_q[lix(m_set, m_way)];
    m_line = {tag_q[lix(m_set, m_way)], m_set, {OFFW{1'b0}}};
  end
  wire c_last_step = c_none || (c_all ? (c_set == SETW'(SETS - 1) && c_way == WL'(WAYS - 1)) : (c_la == c_last));
  wire c_wb_now    = (st == S_CMO) && !c_none && m_v && c_op[0] && m_d && (WRITE_BACK != 0);
  wire c_adv       = (((st == S_CMO) && !c_wb_now) || (st == S_CMO_POST)) && !c_last_step;

  // ------------------------------------------------------------ upstream acceptance
  wire u_cach   = is_cacheable(u_req_addr, enable, ncw_en, ncw_base, ncw_limit, reg_en);
  wire idle_ok  = (st == S_IDLE) && !cmo_valid;
  wire byp_acc  = idle_ok && u_req_valid && !u_cach && (byp_cnt != CW'(MAX_OUT)) && d_req_ready;
  wire look_rhit = (st == S_LOOKUP) && hit && !r_write;
  wire pipe_ok  = look_rhit && u_rsp_ready && !cmo_valid && u_cach;   // accept-while-retiring a read hit
  wire c_acc    = u_req_valid && u_cach && ((idle_ok && byp_cnt == '0) || pipe_ok);
  assign u_req_ready = byp_acc || (u_cach && ((idle_ok && byp_cnt == '0) || pipe_ok));
  assign cmo_ready   = (st == S_IDLE) && cmo_valid && byp_cnt == '0;

  // ------------------------------------------------------------ downstream request
  wire [CW-1:0] infl = CW'(k_iss) - CW'(k_rsp);
  always_comb begin
    d_req_valid = 1'b0;
    d_req_write = 1'b0;
    d_req_addr  = 32'd0;
    d_req_wdata = 32'd0;
    d_req_wstrb = 4'd0;
    case (st)
      S_IDLE: begin                      // uncached pass-through
        d_req_valid = idle_ok && u_req_valid && !u_cach && (byp_cnt != CW'(MAX_OUT));
        d_req_write = u_req_write;
        d_req_addr  = u_req_addr;
        d_req_wdata = u_req_wdata;
        d_req_wstrb = u_req_wstrb;
      end
      S_WT: begin                        // write-through store (single beat)
        d_req_valid = k_iss == '0;
        d_req_write = 1'b1;
        d_req_addr  = r_addr;
        d_req_wdata = r_wdata;
        d_req_wstrb = r_wstrb;
      end
      S_EVWR: begin
        d_req_valid = (k_iss != KW'(WPL)) && (infl != CW'(MAX_OUT));
        d_req_write = 1'b1;
        d_req_addr  = ev_addr | {{(32-WDW-2){1'b0}}, k_iss[WDW-1:0], 2'b00};
        d_req_wdata = lbuf[k_iss[WDW-1:0]];
        d_req_wstrb = 4'hF;
      end
      S_REFILL: begin
        d_req_valid = (k_iss != KW'(WPL)) && (infl != CW'(MAX_OUT));
        d_req_addr  = r_line | {{(32-WDW-2){1'b0}}, k_iss[WDW-1:0], 2'b00};
      end
      default: ;
    endcase
  end
  wire d_acc = d_req_valid && d_req_ready;

  // ------------------------------------------------------------ responses
  always_comb begin
    u_rsp_valid = 1'b0;
    u_rsp_rdata = 32'd0;
    u_rsp_error = 1'b0;
    d_rsp_ready = 1'b1;                  // own beats (eviction, refill) are always accepted
    case (st)
      S_IDLE: begin
        u_rsp_valid = (byp_cnt != '0) && d_rsp_valid;
        u_rsp_rdata = d_rsp_rdata;
        u_rsp_error = d_rsp_error;
        d_rsp_ready = u_rsp_ready;
      end
      S_LOOKUP: begin
        u_rsp_valid = hit && (!r_write || WRITE_BACK != 0);
        u_rsp_rdata = r_write ? 32'd0 : hit_data;
      end
      S_HOLD: begin
        u_rsp_valid = 1'b1;
        u_rsp_rdata = h_rdata;
        u_rsp_error = h_error;
      end
      S_WT: begin
        u_rsp_valid = d_rsp_valid;
        u_rsp_rdata = 32'd0;
        u_rsp_error = d_rsp_error;
        d_rsp_ready = u_rsp_ready;
      end
      default: ;
    endcase
  end
  wire d_rsp_fire = d_rsp_valid && d_rsp_ready;

  // ------------------------------------------------------------ data-array port
  always_comb begin
    a_ce    = '0;
    a_we    = '0;
    a_addr  = '0;
    a_wdata = 32'd0;
    a_wmask = 4'd0;
    if (c_acc) begin                                 // lookup read of the accepted access, all ways
      a_ce   = '1;
      a_addr = {u_req_addr[OFFW +: SETW], u_req_addr[2 +: WDW]};
    end else begin
      case (st)
        S_LOOKUP: if (hit && r_write && WRITE_BACK != 0) begin
          a_ce[hit_way] = 1'b1; a_we[hit_way] = 1'b1;
          a_addr = {r_set, r_word}; a_wdata = r_wdata; a_wmask = r_wstrb;
        end
        S_WT: if (d_rsp_fire && !d_rsp_error && r_hit) begin
          a_ce[r_way] = 1'b1; a_we[r_way] = 1'b1;
          a_addr = {r_set, r_word}; a_wdata = r_wdata; a_wmask = r_wstrb;
        end
        S_EVRD: if (k_rd != KW'(WPL)) begin
          a_ce[ev_way] = 1'b1;
          a_addr = {ev_set, k_rd[WDW-1:0]};
        end
        S_REFILL: if (d_rsp_fire) begin
          a_ce[r_way] = 1'b1; a_we[r_way] = 1'b1;
          a_addr = {r_set, k_rsp[WDW-1:0]}; a_wdata = d_rsp_rdata; a_wmask = 4'hF;
        end
        S_FILLDONE: if (!beat_err && r_write) begin  // write-allocate: merge the store into the new line
          a_ce[r_way] = 1'b1; a_we[r_way] = 1'b1;
          a_addr = {r_set, r_word}; a_wdata = r_wdata; a_wmask = r_wstrb;
        end
        default: ;
      endcase
    end
  end

  // ------------------------------------------------------------ control FSM
  // eviction-read capture: word k_rd-1 arrives one cycle after its read
  logic ev_cap;
  logic [WDW-1:0] ev_cap_k;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ev_cap   <= 1'b0;
      ev_cap_k <= '0;
    end else begin
      ev_cap   <= (st == S_EVRD) && (k_rd != KW'(WPL));
      ev_cap_k <= k_rd[WDW-1:0];
    end
  end
  always_ff @(posedge clk) begin
    if (ev_cap) lbuf[ev_cap_k] <= a_rdata[ev_way*32 +: 32];
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st       <= S_IDLE;
      ret_st   <= S_IDLE;
      valid_q  <= '0;
      dirty_q  <= '0;
      plru_q   <= '0;
      byp_cnt  <= '0;
      k_iss    <= '0;
      k_rsp    <= '0;
      k_rd     <= '0;
      beat_err <= 1'b0;
      r_hit    <= 1'b0;
      r_way    <= '0;
      h_error  <= 1'b0;
      c_op     <= 2'd0;
      c_all    <= 1'b0;
      c_none   <= 1'b0;
      c_lines  <= 16'd0;
      c_wberr  <= 1'b0;
      c_disc   <= 1'b0;
      c_set    <= '0;
      c_way    <= '0;
    end else begin
      // uncached transactions in flight
      byp_cnt <= byp_cnt + CW'(byp_acc) - CW'((st == S_IDLE) && (byp_cnt != '0) && d_rsp_fire);

      case (st)
        // ------------------------------------------------------------------------------------------
        S_IDLE: begin
          if (cmo_ready) begin
            c_op    <= cmo_op;
            c_all   <= cmo_all;
            c_set   <= '0;
            c_way   <= '0;
            c_lines <= 16'd0;
            c_wberr <= 1'b0;
            c_disc  <= 1'b0;
            c_none  <= !cmo_all && (cmo_size == 32'd0);
            st      <= S_CMO;
          end else if (c_acc) begin
            st <= S_LOOKUP;
          end
        end
        // ------------------------------------------------------------------------------------------
        S_LOOKUP: begin
          r_hit <= hit;
          if (hit) begin
            r_way <= hit_way;
            plru_q[r_set*PB +: PB] <= plru_touch(plru_q[r_set*PB +: PB], hit_way);
            if (r_write && WRITE_BACK == 0) begin
              st    <= S_WT;                         // write-through hit: memory first, then the line
              k_iss <= '0;
            end else begin
              if (r_write) dirty_q[lix(r_set, hit_way)] <= 1'b1;
              if (u_rsp_ready) st <= c_acc ? S_LOOKUP : S_IDLE;
              else begin
                st      <= S_HOLD;
                h_rdata <= r_write ? 32'd0 : hit_data;
                h_error <= 1'b0;
              end
            end
          end else if (r_write && WRITE_BACK == 0) begin
            st    <= S_WT;                           // write-through miss: no allocation
            k_iss <= '0;
          end else begin
            r_way    <= vic_way;
            k_iss    <= '0;
            k_rsp    <= '0;
            k_rd     <= '0;
            beat_err <= 1'b0;
            if (WRITE_BACK != 0 && valid_q[lix(r_set, vic_way)] && dirty_q[lix(r_set, vic_way)]) begin
              ev_set  <= r_set;
              ev_way  <= vic_way;
              ev_addr <= {tag_q[lix(r_set, vic_way)], r_set, {OFFW{1'b0}}};
              ret_st  <= S_REFILL;
              st      <= S_EVRD;
            end else begin
              st <= S_REFILL;
            end
            valid_q[lix(r_set, vic_way)] <= 1'b0;   // the victim's data is about to be overwritten
          end
        end
        // ------------------------------------------------------------------------------------------
        S_HOLD: if (u_rsp_ready) st <= S_IDLE;
        // ------------------------------------------------------------------------------------------
        S_WT: begin
          if (d_acc) k_iss <= KW'(1);
          if (d_rsp_fire) st <= S_IDLE;              // response passed through to the requester
        end
        // ------------------------------------------------------------------------------------------
        S_EVRD: begin
          if (k_rd != KW'(WPL)) k_rd <= k_rd + KW'(1);
          else begin                                 // the last word is captured at this edge
            st       <= S_EVWR;
            k_iss    <= '0;
            k_rsp    <= '0;
            beat_err <= 1'b0;
          end
        end
        S_EVWR: begin
          if (d_acc) k_iss <= k_iss + KW'(1);
          if (d_rsp_fire) begin
            k_rsp <= k_rsp + KW'(1);
            if (d_rsp_error) beat_err <= 1'b1;
            if (k_rsp == KW'(WPL - 1)) begin
              dirty_q[lix(ev_set, ev_way)] <= 1'b0;
              if ((beat_err || d_rsp_error) && ret_st == S_CMO_POST) c_wberr <= 1'b1;
              st       <= ret_st;
              k_iss    <= '0;
              k_rsp    <= '0;
              beat_err <= 1'b0;
            end
          end
        end
        // ------------------------------------------------------------------------------------------
        S_REFILL: begin
          if (d_acc) k_iss <= k_iss + KW'(1);
          if (d_rsp_fire) begin
            k_rsp <= k_rsp + KW'(1);
            if (d_rsp_error) beat_err <= 1'b1;
            if (k_rsp[WDW-1:0] == r_word) r_rdata <= d_rsp_rdata;
            if (k_rsp == KW'(WPL - 1)) st <= S_FILLDONE;
          end
        end
        S_FILLDONE: begin
          if (!beat_err) begin
            tag_q[lix(r_set, r_way)]   <= r_tag;
            valid_q[lix(r_set, r_way)] <= 1'b1;
            dirty_q[lix(r_set, r_way)] <= r_write;  // write-allocate leaves the line dirty
            plru_q[r_set*PB +: PB]      <= plru_touch(plru_q[r_set*PB +: PB], r_way);
          end
          h_rdata <= (beat_err || r_write) ? 32'd0 : r_rdata;
          h_error <= beat_err;
          st      <= S_HOLD;
        end
        // ------------------------------------------------------------------------------------------
        S_CMO: begin
          if (!c_none && m_v) begin
            c_lines <= c_lines + 16'd1;
            if (c_op[0] && m_d && WRITE_BACK != 0) begin              // CLEAN part: write back first
              ev_set   <= m_set;
              ev_way   <= m_way;
              ev_addr  <= m_line;
              k_rd     <= '0;
              ret_st   <= S_CMO_POST;
              st       <= S_EVRD;
            end else begin
              if (c_op[1]) begin                                      // INVAL part
                valid_q[lix(m_set, m_way)] <= 1'b0;
                dirty_q[lix(m_set, m_way)] <= 1'b0;
                if (m_d && !c_op[0]) c_disc <= 1'b1;
              end
              st <= c_last_step ? S_CMO_END : S_CMO;
            end
          end else begin
            st <= c_last_step ? S_CMO_END : S_CMO;
          end
        end
        S_CMO_POST: begin                                             // after a CMO write-back
          if (c_op[1]) begin
            valid_q[lix(ev_set, ev_way)] <= 1'b0;
            dirty_q[lix(ev_set, ev_way)] <= 1'b0;
          end
          st <= c_last_step ? S_CMO_END : S_CMO;
        end
        S_CMO_END: st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
      // ALL: next (set, way) once the current candidate is finished (after its write-back, if any)
      if (c_adv && c_all) begin
        c_way <= (c_way == WL'(WAYS - 1)) ? '0 : c_way + WL'(1);
        if (c_way == WL'(WAYS - 1)) c_set <= c_set + SETW'(1);
      end
    end
  end

  // latched request (no reset: qualified by the FSM state)
  always_ff @(posedge clk) begin
    if (c_acc) begin
      r_addr  <= u_req_addr;
      r_write <= u_req_write;
      r_wdata <= u_req_wdata;
      r_wstrb <= u_req_wstrb;
    end
  end

  // range iteration: c_la advances in the cycle the candidate is consumed
  always_ff @(posedge clk) begin
    if (cmo_ready) begin
      c_la   <= {cmo_addr[31:OFFW], {OFFW{1'b0}}};
      c_last <= ({1'b0, cmo_addr} + {1'b0, cmo_size} > 33'h1_0000_0000) ?
                {{(32-OFFW){1'b1}}, {OFFW{1'b0}}} :
                (((cmo_addr + cmo_size) - 32'd1) & ~32'(LINE_BYTES - 1));
    end else if (c_adv && !c_all) begin
      c_la <= c_la + 32'(LINE_BYTES);
    end
  end

  // ------------------------------------------------------------ outputs
  assign cmo_done    = st == S_CMO_END;
  assign cmo_lines   = c_lines;
  assign cmo_wb_err  = c_wberr;
  assign cmo_discard = c_disc;
  assign ev_hit      = (st == S_LOOKUP) && hit;
  assign ev_miss     = (st == S_LOOKUP) && !hit;
  assign ev_wb       = (st == S_EVWR) && d_rsp_fire && (k_rsp == KW'(WPL - 1));
  assign ev_wb_err   = ev_wb && (beat_err || d_rsp_error);
  assign wb_err_addr = ev_addr;
  assign ev_bypass   = byp_acc;
  assign ev_cmo_line = (st == S_CMO) && !c_none && m_v;

endmodule

`default_nettype wire
