// =============================================================================
// SilicaFlux-HPC MemoryCore :: sfmem_banked -- banked memory with one port per requester
//
// Used twice in silicaflux_memory_subsystem: the shared SRAM (6 ports, 8 banks)
// and the ControlCore local memory LMEM (3 ports, 2 banks).
//
// Core: the SRAM Wrapper Library's sram_bank_controller (Project 01), reused
// UNMODIFIED: NP ports x BANKS single-port (1RW) banks, per-bank round robin,
// low (word) or high (block) interleave, byte addressing, READ_LATENCY >= 1,
// per-port response credits, MBIST test port.  No macro is assumed to have more
// than one port: concurrency comes only from banking.
//
// This wrapper adds
//   * the SFB2 view: byte address -> word offset inside the region (library
//     ADDR_MODE = WORD: the library's byte mode needs DATA_WIDTH/8 to be a power of
//     two, which 36-bit parity words are not), wstrb -> lane mask,
//     every write acknowledged after it is performed (SFB2 R7: the library
//     performs a write at its acceptance edge and acknowledges it in order);
//   * integrity hooks (single layer -- nothing else in MemoryCore encodes data):
//       ECC_MODE = NONE   (0): 32-bit words;
//       ECC_MODE = PARITY (1): odd parity per byte, stored as 4 x 9-bit lanes
//                              (36-bit words, library MASK_WIDTH = 4, lane width 9) --
//                              the convention of HPC Module 04 and MCU-I.  Byte writes
//                              stay single-cycle (no read-modify-write).  A read with a
//                              failing lane answers rsp_error = 1, rdata = 0, and raises
//                              par_evt with the lane syndrome and the word address;
//       ECC_MODE = SECDED (2): RESERVED for Project 26, rejected at elaboration;
//     fault injection: inj_req inverts the parity of inj_lanes on the next accepted
//     write (lowest port index first); inj_ack pulses when it was consumed;
//   * the word offset travels as the library request ID, so the error log gets the
//     exact address of a parity failure without extra state; the ID also carries
//     CHECK_DIS as it was when the read was ACCEPTED (its serialization point) -- a later
//     ECC_CTRL write must not change the outcome of an earlier read still in the
//     pipeline (READ_LATENCY >= 2; found by the regression, see docs/09 §6);
//   * performance events: accepts and bank-conflict stalls per port, accesses per
//     bank, useful bytes read / written.
//
// Serialization: a request is performed at its acceptance edge (library
// contract §4/§10) and this wrapper adds no cycle, so the acceptance cycle at the
// requester port is the access's position in the bank's total order.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfmem_defs.svh"
`default_nettype none

module sfmem_banked #(
  parameter int          NP          = 6,
  parameter int          BYTES       = 262144,
  parameter int          BANKS       = 8,
  parameter int          RD_LAT      = 1,
  parameter int          ILV_HIGH    = 0,
  parameter int          ECC_MODE    = `SFMEM_ECC_NONE,
  parameter int          RSP_DEPTH   = RD_LAT + 1,
  parameter int          ARB         = `SRAM_ARB_RR,
  parameter int          BACKEND     = `SRAM_BACKEND_GENERIC,
  parameter int          MACRO       = 0,
  parameter logic [31:0] BASE        = 32'h1000_0000,   // only for error-log addresses
  localparam int         AWB         = $clog2(BYTES),
  localparam int         AWW         = AWB - 2,                     // word-address width (library ADDR_MODE = WORD)
  localparam int         SW          = (ECC_MODE == `SFMEM_ECC_PARITY) ? 36 : 32,
  localparam int         BANK_DEPTH  = BYTES / 4 / BANKS,
  localparam int         RAW         = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  localparam int         BW          = (BANKS > 1) ? $clog2(BANKS) : 1,
  localparam int         LW          = SW / 4                       // stored lane width (8 or 9)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- requester ports (SFB2, full byte addresses)
  input  wire logic [NP-1:0]    p_req_valid,
  output logic [NP-1:0]         p_req_ready,
  input  wire logic [NP-1:0]    p_req_write,
  input  wire logic [NP*32-1:0] p_req_addr,
  input  wire logic [NP*32-1:0] p_req_wdata,
  input  wire logic [NP*4-1:0]  p_req_wstrb,
  output logic [NP-1:0]         p_rsp_valid,
  input  wire logic [NP-1:0]    p_rsp_ready,
  output logic [NP*32-1:0]      p_rsp_rdata,
  output logic [NP-1:0]         p_rsp_error,
  // ---------------------------------------------------------- integrity control / report
  input  wire logic             chk_dis,        // ignore parity on reads (diagnostics)
  input  wire logic             inj_req,        // invert parity of inj_lanes on the next write
  input  wire logic [3:0]       inj_lanes,
  output logic                  inj_ack,
  output logic                  par_evt,        // a read failed the parity check (response carries the error)
  output logic [3:0]            par_syn,
  output logic [31:0]           par_addr,
  output logic [2:0]            par_port,
  // ---------------------------------------------------------- performance events (per cycle)
  output logic [NP-1:0]         ev_acc,
  output logic [NP-1:0]         ev_conf,
  output logic [BANKS-1:0]      ev_bank,
  output logic [5:0]            ev_rd_bytes,
  output logic [5:0]            ev_wr_bytes,
  // ---------------------------------------------------------- MBIST test port (library / TestCore contract)
  input  wire logic             tst_active,
  input  wire logic [BANKS-1:0] tst_sel,
  input  wire logic             tst_ce,
  input  wire logic             tst_we,
  input  wire logic [RAW-1:0]   tst_addr,
  input  wire logic [SW-1:0]    tst_wdata,
  output logic [BANKS*SW-1:0]   tst_rdata,
  output logic                  busy
);

  // ------------------------------------------------------------ configuration checks
  if (ECC_MODE == `SFMEM_ECC_SECDED) begin : g_err_secded_reserved
    `SFMEM_CFG_FATAL("sfmem_banked: ECC_MODE = SECDED is reserved for Project 26 and NOT implemented")
  end
  if (ECC_MODE != `SFMEM_ECC_NONE && ECC_MODE != `SFMEM_ECC_PARITY && ECC_MODE != `SFMEM_ECC_SECDED) begin : g_err_ecc
    `SFMEM_CFG_FATAL("sfmem_banked: unknown ECC_MODE")
  end
  if (NP < 1 || NP > 8) begin : g_err_np
    `SFMEM_CFG_FATAL("sfmem_banked: NP must be 1..8")
  end
  if ((BYTES & (BYTES - 1)) != 0 || BYTES < 8 * BANKS) begin : g_err_bytes
    `SFMEM_CFG_FATAL("sfmem_banked: BYTES must be a power of two >= 8 * BANKS")
  end
  if (RD_LAT < 1) begin : g_err_lat
    `SFMEM_CFG_FATAL("sfmem_banked: RD_LAT must be >= 1")
  end
  if (RSP_DEPTH < 1) begin : g_err_rsp_depth
    `SFMEM_CFG_FATAL("sfmem_banked: RSP_DEPTH must be >= 1 (requesters may back-pressure responses)")
  end

  // ------------------------------------------------------------ request mapping + encode
  logic [NP*AWW-1:0] c_addr;
  logic [NP*SW-1:0]  c_wdata;
  logic [NP*4-1:0]   c_wmask;
  logic [NP-1:0]     c_acc, inj_here;
  logic [NP-1:0]     c_ready;

  // injection goes to the lowest-index port that writes in this cycle
  always_comb begin
    logic taken;
    taken    = 1'b0;
    inj_here = '0;
    for (int p = 0; p < NP; p++) begin
      c_acc[p] = p_req_valid[p] && c_ready[p];
      if (ECC_MODE == `SFMEM_ECC_PARITY && inj_req && !taken && c_acc[p] && p_req_write[p]) begin
        inj_here[p] = 1'b1;
        taken       = 1'b1;
      end
    end
  end
  assign inj_ack = |inj_here;

  always_comb begin
    for (int p = 0; p < NP; p++) begin
      c_addr[p*AWW +: AWW] = p_req_addr[p*32 + 2 +: AWW];   // word offset inside the region
      c_id[p*(AWW+1) +: (AWW+1)] = {chk_dis, p_req_addr[p*32 + 2 +: AWW]};
      c_wmask[p*4 +: 4]    = p_req_wstrb[p*4 +: 4];
      for (int l = 0; l < 4; l++) begin
        if (ECC_MODE == `SFMEM_ECC_PARITY)
          c_wdata[p*SW + l*LW +: LW] = LW'({~^p_req_wdata[p*32 + l*8 +: 8] ^ (inj_here[p] && inj_lanes[l]),
                                            p_req_wdata[p*32 + l*8 +: 8]});
        else
          c_wdata[p*SW + l*LW +: LW] = LW'(p_req_wdata[p*32 + l*8 +: 8]);
      end
    end
  end

  // ------------------------------------------------------------ the verified bank controller (unmodified)
  logic [NP*SW-1:0]  c_rdata;
  logic [NP-1:0]     c_err;
  logic [NP*(AWW+1)-1:0] c_id, c_rid;            // {check-disable at acceptance, word offset}
  logic [NP-1:0]     c_rwe;

  sram_bank_controller #(
    .NUM_MASTERS(NP), .NUM_BANKS(BANKS), .DATA_WIDTH(SW), .MASK_WIDTH(4), .BANK_DEPTH(BANK_DEPTH),
    .READ_LATENCY(RD_LAT), .BACKEND(BACKEND), .MACRO(MACRO), .ARB(ARB),
    .INTERLEAVE(ILV_HIGH != 0 ? `SRAM_ILV_HIGH : `SRAM_ILV_LOW), .ADDR_MODE(`SRAM_ADDR_WORD),
    .ID_WIDTH(AWW + 1), .RSP_FIFO_DEPTH(RSP_DEPTH), .WRITE_ACK(1), .TEST_EN(1), .ADDR_WIDTH(AWW)
  ) u_bc (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(p_req_valid), .m_req_ready(c_ready), .m_req_we(p_req_write), .m_req_addr(c_addr),
    .m_req_wdata(c_wdata), .m_req_wmask(c_wmask), .m_req_id(c_id),
    .m_rsp_valid(p_rsp_valid), .m_rsp_ready(p_rsp_ready), .m_rsp_rdata(c_rdata), .m_rsp_err(c_err),
    .m_rsp_we(c_rwe), .m_rsp_id(c_rid), .m_stall_conflict(ev_conf),
    .tst_active(tst_active), .tst_sel(tst_sel), .tst_ce(tst_ce), .tst_we(tst_we), .tst_addr(tst_addr),
    .tst_wdata(tst_wdata), .tst_rdata(tst_rdata), .busy(busy)
  );
  assign p_req_ready = c_ready;

  // ------------------------------------------------------------ response decode
  logic [NP*4-1:0] syn;
  logic [NP-1:0]   perr;
  always_comb begin
    for (int p = 0; p < NP; p++) begin
      for (int l = 0; l < 4; l++) begin
        if (ECC_MODE == `SFMEM_ECC_PARITY)
          syn[p*4 + l] = ~^c_rdata[p*SW + l*LW +: LW];             // odd parity: a good lane XORs to 1
        else
          syn[p*4 + l] = 1'b0;
        p_rsp_rdata[p*32 + l*8 +: 8] = c_rdata[p*SW + l*LW +: 8];
      end
      // write acknowledgements carry zero data (library) -> zero syndrome check is skipped for them
      perr[p] = (ECC_MODE == `SFMEM_ECC_PARITY) && !c_rid[p*(AWW+1) + AWW] && !c_rwe[p] && !c_err[p] &&
                (|syn[p*4 +: 4]);
      if (perr[p]) p_rsp_rdata[p*32 +: 32] = 32'd0;
      p_rsp_error[p] = c_err[p] || perr[p];
    end
  end

  // parity event: reported once, at the cycle the failing response is delivered
  always_comb begin
    par_evt  = 1'b0;
    par_syn  = 4'd0;
    par_addr = 32'd0;
    par_port = 3'd0;
    for (int p = NP - 1; p >= 0; p--) begin
      if (p_rsp_valid[p] && p_rsp_ready[p] && perr[p]) begin
        par_evt  = 1'b1;
        par_syn  = syn[p*4 +: 4];
        par_addr = BASE | {30'(c_rid[p*(AWW+1) +: AWW]), 2'b00};
        par_port = 3'(p);
      end
    end
  end

  // ------------------------------------------------------------ performance events
  always_comb begin
    ev_bank     = '0;
    ev_rd_bytes = '0;
    ev_wr_bytes = '0;
    for (int p = 0; p < NP; p++) begin
      ev_acc[p] = c_acc[p];
      if (c_acc[p]) begin
        if (BANKS > 1) begin
          if (ILV_HIGH != 0) ev_bank[BW'(p_req_addr[p*32 + 2 + RAW +: BW])] = 1'b1;
          else               ev_bank[BW'(p_req_addr[p*32 + 2 +: BW])]       = 1'b1;
        end else begin
          ev_bank[0] = 1'b1;
        end
        if (p_req_write[p]) ev_wr_bytes = ev_wr_bytes + 6'(p_req_wstrb[p*4]) + 6'(p_req_wstrb[p*4+1])
                                                    + 6'(p_req_wstrb[p*4+2]) + 6'(p_req_wstrb[p*4+3]);
        else                ev_rd_bytes = ev_rd_bytes + 6'd4;
      end
    end
  end

endmodule

`default_nettype wire
