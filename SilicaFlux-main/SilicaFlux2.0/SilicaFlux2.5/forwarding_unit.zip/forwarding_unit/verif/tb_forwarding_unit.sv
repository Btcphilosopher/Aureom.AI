module tb_forwarding_unit;
  import silicaflux_pkg::*;
  localparam int unsigned IW = SF_ISSUE_WIDTH, NE = SF_NUM_EX_BYP, NM = SF_NUM_MEM_BYP, NW = SF_NUM_WB_PORTS;
  localparam int NITER = 200000;

  logic flush; br_mask_t kill; epoch_t ep;
  ex_pkt_t [IW-1:0] iss; word_t [IW-1:0] rfa, rfb; logic [IW-1:0] sba, sbb;
  byp_pkt_t [NE-1:0] ex; byp_pkt_t [NM-1:0] mem; wb_pkt_t [NW-1:0] wb;
  fwd_src_e [IW-1:0] sela, selb; fwd_port_t [IW-1:0] ida, idb; logic [IW-1:0] bea, beb, rha, rhb, stl, amb;
  word_t [IW-1:0] oa, ob; sb_hook_t [IW-1:0] hook;

  forwarding_unit dut (.flush_i(flush), .br_kill_i(kill), .cur_epoch_i(ep), .issue_i(iss),
    .rf_rdata_a_i(rfa), .rf_rdata_b_i(rfb), .sb_busy_a_i(sba), .sb_busy_b_i(sbb),
    .ex_byp_i(ex), .mem_byp_i(mem), .wb_i(wb),
    .operand_a_select_o(sela), .operand_b_select_o(selb), .operand_a_src_id_o(ida), .operand_b_src_id_o(idb),
    .operand_a_bypass_en_o(bea), .operand_b_bypass_en_o(beb), .operand_a_o(oa), .operand_b_o(ob),
    .raw_hazard_a_o(rha), .raw_hazard_b_o(rhb), .issue_stall_o(stl), .sb_hook_o(hook), .fwd_ambiguity_o(amb));

  function automatic logic sq(br_mask_t m, epoch_t e);
    return flush | (|(m & kill)) | (e != ep);
  endfunction

  int errors = 0; int hist[4]; int chist[4];

  task automatic check_op(int c, src_tag_t t, word_t rf, logic sb, fwd_src_e sel, fwd_port_t id, logic be, word_t d, logic rh, dep_wait_t dw);
    fwd_src_e es = FWD_RF; fwd_port_t eid = '0; logic ebe = 0, erh = 0, est = 0; stall_cause_e ec = STALL_NONE; word_t ed = rf;
    logic live = iss[c].valid & ~sq(iss[c].br_mask, iss[c].epoch) & t.valid & (t.preg != 0);
    logic found = 0;
    if (live) begin
      for (int p = 0; p < NE && !found; p++)
        if (ex[p].valid && ex[p].rd_we && !sq(ex[p].br_mask, ex[p].epoch) && ex[p].rd_preg == t.preg) begin
          found = 1; erh = 1;
          if (ex[p].data_vld) begin es = FWD_EX; eid = p[2:0]; ebe = 1; ed = ex[p].data; end
          else begin est = 1; ec = ex[p].is_load ? STALL_LOAD_USE : STALL_EX_PENDING; end
        end
      for (int p = 0; p < NM && !found; p++)
        if (mem[p].valid && mem[p].rd_we && !sq(mem[p].br_mask, mem[p].epoch) && mem[p].rd_preg == t.preg) begin
          found = 1; erh = 1;
          if (mem[p].data_vld) begin es = FWD_MEM; eid = p[2:0]; ebe = 1; ed = mem[p].data; end
          else begin est = 1; ec = mem[p].is_load ? STALL_LOAD_USE : STALL_EX_PENDING; end
        end
      for (int p = 0; p < NW && !found; p++)
        if (wb[p].valid && wb[p].rd_we && !sq(wb[p].br_mask, wb[p].epoch) && wb[p].rd_preg == t.preg) begin
          found = 1; erh = 1; es = FWD_WB; eid = p[2:0]; ebe = 1; ed = wb[p].data;
        end
      if (!found && sb) begin erh = 1; est = 1; ec = STALL_SB_BUSY; end
    end
    if (sel !== es || be !== ebe || rh !== erh || dw.wait_dep !== est || dw.cause !== ec || (ebe && id !== eid) || (!est && d !== ed)) begin
      errors++;
      if (errors < 10) $display("MISMATCH c=%0d sel=%0d/%0d id=%0d/%0d be=%b/%b rh=%b/%b st=%b/%b cause=%0d/%0d d=%h/%h",
        c, sel, es, id, eid, be, ebe, rh, erh, dw.wait_dep, est, dw.cause, ec, d, ed);
    end
    hist[sel]++; chist[ec]++;
  endtask

  initial begin
    preg_t pool [$];
    word_t [IW-1:0] ta, tb; logic [IW-1:0] tsa, tsb;
    for (int it = 0; it < NITER; it++) begin
      // unique destinations across all producers (renaming invariant)
      pool.delete();
      for (int i = 1; i < 32; i++) pool.push_back(preg_t'(i));
      pool.shuffle();
      flush = ($urandom_range(0, 49) == 0);
      kill  = ($urandom_range(0, 7) == 0) ? br_mask_t'(1 << $urandom_range(0, 15)) : '0;
      ep    = epoch_t'($urandom_range(0, 3));
      foreach (ex[p]) begin
        ex[p] = '{valid: $urandom_range(0,3)!=0, rd_we: $urandom_range(0,7)!=0, rd_preg: pool.pop_front(),
                  data_vld: $urandom_range(0,3)!=0, is_load: $urandom_range(0,3)==0, data: {$urandom,$urandom},
                  rob_idx: rob_idx_t'($urandom), br_mask: br_mask_t'(1 << $urandom_range(0,15)),
                  epoch: ($urandom_range(0,9)==0) ? ep + 1'b1 : ep};
      end
      foreach (mem[p]) begin
        mem[p] = '{valid: $urandom_range(0,3)!=0, rd_we: $urandom_range(0,7)!=0, rd_preg: pool.pop_front(),
                  data_vld: $urandom_range(0,3)!=0, is_load: $urandom_range(0,1)==0, data: {$urandom,$urandom},
                  rob_idx: rob_idx_t'($urandom), br_mask: br_mask_t'(1 << $urandom_range(0,15)),
                  epoch: ($urandom_range(0,9)==0) ? ep + 1'b1 : ep};
      end
      foreach (wb[p]) begin
        wb[p] = '{valid: $urandom_range(0,3)!=0, rd_we: $urandom_range(0,7)!=0, rd_preg: pool.pop_front(),
                  data: {$urandom,$urandom}, rob_idx: rob_idx_t'($urandom),
                  br_mask: br_mask_t'(1 << $urandom_range(0,15)), epoch: ($urandom_range(0,9)==0) ? ep + 1'b1 : ep};
      end
      foreach (iss[c]) begin
        iss[c] = '{valid: $urandom_range(0,7)!=0, rob_idx: rob_idx_t'($urandom), br_mask: br_mask_t'(1 << $urandom_range(0,15)),
                   epoch: ($urandom_range(0,15)==0) ? ep + 1'b1 : ep,
                   src_a: '{valid: $urandom_range(0,7)!=0, preg: preg_t'($urandom_range(0,33))},
                   src_b: '{valid: $urandom_range(0,7)!=0, preg: preg_t'($urandom_range(0,33))}};
        ta[c] = {$urandom,$urandom}; tb[c] = {$urandom,$urandom};
        tsa[c] = $urandom_range(0,3)==0; tsb[c] = $urandom_range(0,3)==0;
      end
      rfa = ta; rfb = tb; sba = tsa; sbb = tsb;
      #1;
      foreach (iss[c]) begin
        check_op(c, iss[c].src_a, rfa[c], sba[c], sela[c], ida[c], bea[c], oa[c], rha[c], hook[c].dep_a);
        check_op(c, iss[c].src_b, rfb[c], sbb[c], selb[c], idb[c], beb[c], ob[c], rhb[c], hook[c].dep_b);
        if (stl[c] !== (hook[c].dep_a.wait_dep | hook[c].dep_b.wait_dep) || amb[c] !== 1'b0) begin
          errors++; if (errors < 10) $display("STALL/AMB mismatch c=%0d", c);
        end
      end
    end
    $display("sel histogram RF/EX/MEM/WB = %0d/%0d/%0d/%0d", hist[0], hist[1], hist[2], hist[3]);
    $display("stall histogram NONE/EXP/LDU/SB = %0d/%0d/%0d/%0d", chist[0], chist[1], chist[2], chist[3]);
    $display("RESULT: %0d iterations, %0d errors", NITER, errors);
    $finish;
  end
endmodule
