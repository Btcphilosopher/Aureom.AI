# Mutation campaign — coherence path

One defect at a time in `sf_atomic_coh_agent.sv` / the engine's coherent write-back, run against the REAL CoherenceDirectory (P107) with two real CPU cache agents (`tb/tb_sf_atomic_coh.sv`: directed, negative control, random, stress).

**7 / 7 non-equivalent mutants killed** (1 defensive-check mutant(s) that a correct directory can never exercise, listed as EQUIVALENT: C08 removes the `gn_line == p_line` check of a grant; the verified directory only ever grants the line that was requested, so only a fault-injecting directory model could expose it).

| id | file | planted defect | result | first failing test | first error |
|---|---|---|---|---|---|
| C01 | `sf_atomic_coh_agent.sv` | ALU result never merged into the line (lost update) | KILLED | coh_directed | [815000] ERROR: COHERENCE: a CPU agent found a line that differs from the golden line |
| C02 | `sf_atomic_coh_agent.sv` | PUTM writes back the UNMODIFIED line (memory loses the update) | KILLED | coh_directed | [815000] ERROR: COHERENCE: a CPU agent found a line that differs from the golden line |
| C03 | `sf_atomic_coh_agent.sv` | intervention from the eviction buffer returns zeros | KILLED | coh_random | [12485000] ERROR: COHERENCE: a CPU agent found a line that differs from the golden line |
| C04 | `sf_atomic_coh_agent.sv` | 32-bit result written to the wrong half of the 8-byte word | KILLED | coh_directed | [2695000] ERROR: COHERENCE: a CPU agent found a line that differs from the golden line |
| C05 | `sf_atomic_coh_agent.sv` | commit event reports the new value as the old value | KILLED | coh_directed | [375000] ERROR: ead a value that differs from the golden line (stale copy / lost update) |
| C06 | `sf_atomic_coh_agent.sv` | COMPLETE never sent (the directory keeps the line blocked) | KILLED | coh_directed | [200235000] ERROR: DEADLOCK / timeout while draining |
| C07 | `sf_atomic_engine.sv` | coherent completion returns old = 0 | KILLED | coh_directed | [505000] ERROR: completion old value differs from the value at the linearisation point |
| C08 | `sf_atomic_coh_agent.sv` | grant for a different line accepted as the awaited one | EQUIVALENT |  |  |
