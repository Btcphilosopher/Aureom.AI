# Reports (generated; every number in `docs/` is copied from these files)

| File | Produced by | Content |
|---|---|---|
| `regression.md`, `regression.json` | `scripts/regress.py --seeds 3` | 8 configurations × 19 tests × seeds, Verilator 5.020, in-RTL assertions on |
| `coherence.md` | `scripts/coh_regress.py` | engine as agent 2 next to P107's real directory and two real CPU caches |
| `mutation.md`, `mutation.json` | `scripts/mutate.py` | 41 planted defects (4-context configuration) |
| `mutation_coh.md`, `mutation_coh.json` | `scripts/mutate.py --coh` | 8 planted defects in the coherence path, real P107 directory |
| `formal.md`, `formal.json` | `formal/run_formal.py` | ALU (all inputs), lock table / queue structure (unbounded), queue / ordering / whole engine (bounded) |
| `synthesis.md`, `synthesis.json` | `scripts/synth.py` | Yosys 0.33 generic-gate structure counts (no library, no timing) |
| `bench.md` | `scripts/bench.py` | operations per cycle, latency, queue wait, lock wait, contention |
