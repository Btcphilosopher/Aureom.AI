# Mutation campaign

One deliberate RTL defect at a time (`scripts/mutate.py`); the quick test list is run on the 4-context configuration (`-GNCTX=4`) until one test fails (see the file header for the list).

**40 / 40 non-equivalent mutants killed** (1 provably equivalent control mutant(s) listed separately).

| id | file | planted defect | result | first failing test | first error |
|---|---|---|---|---|---|
| A01 | `sf_atomic_alu.sv` | 32-bit fetch-add does not wrap at 32 bits | KILLED | overflow | [245000] ERROR: new value differs from the sequential reference |
| A02 | `sf_atomic_alu.sv` | signed min/max compare as unsigned | KILLED | minmax | [585000] ERROR: new value differs from the sequential reference |
| A03 | `sf_atomic_alu.sv` | MIN returns the maximum | KILLED | minmax | [465000] ERROR: new value differs from the sequential reference |
| A04 | `sf_atomic_alu.sv` | failed CAS still writes | KILLED | smoke | [345000] ERROR: wrote / did-not-write differs from the sequential reference |
| A05 | `sf_atomic_alu.sv` | CAS always reports success | KILLED | smoke | [335000] ERROR: success flag differs from the sequential reference |
| A06 | `sf_atomic_alu.sv` | 32-bit CAS compares 64 bits | KILLED | smoke | [275000] ERROR: success flag differs from the sequential reference |
| A07 | `sf_atomic_alu.sv` | swap does not store the operand | KILLED | minmax | [645000] ERROR: new value differs from the sequential reference |
| A08 | `sf_atomic_alu.sv` | 32-bit signed compare without sign inversion | KILLED | minmax | [2145000] ERROR: new value differs from the sequential reference |
| A09 | `sf_atomic_alu.sv` | MAXU returns the minimum | KILLED | minmax | [1785000] ERROR: new value differs from the sequential reference |
| E01 | `sf_atomic_engine.sv` | atomics on the same granule overlap (lost updates) | KILLED | smoke | [165000] ERROR: two contexts hold the same lock granule |
| E02 | `sf_atomic_engine.sv` | aq / rl ordering bits ignored | KILLED | order | [8115000] ERROR: ng violated: a younger command committed before an older acquire |
| E03 | `sf_atomic_engine.sv` | write permission not checked | KILLED | perm | [205000] ERROR: command predicted to be rejected reached its linearisation point |
| E04 | `sf_atomic_engine.sv` | domain binding not checked | KILLED | perm | [425000] ERROR: command predicted to be rejected reached its linearisation point |
| E05 | `sf_atomic_engine.sv` | 64-bit operations accepted at 4-byte alignment | KILLED | perm | [355000] ERROR: command predicted to be rejected reached its linearisation point |
| E06 | `sf_atomic_engine.sv` | off-by-one at the window limit | KILLED | perm | [265000] ERROR: completion status differs from the independent prediction |
| E07 | `sf_atomic_engine.sv` | write issued after a failed read | KILLED | errors | [175000] ERROR:  without an open atomic window (no read seen at the memory port) |
| E08 | `sf_atomic_engine.sv` | lock never released at completion | KILLED | smoke | [2000115000] ERROR: ADLOCK / timeout: commands or ordinary requests did not complete |
| E09 | `sf_atomic_engine.sv` | write data is the old value | KILLED | smoke | [165000] ERROR: memory write data differs from the sequential reference result |
| E10 | `sf_atomic_engine.sv` | completion destination not checked | KILLED | perm | [505000] ERROR: command predicted to be rejected reached its linearisation point |
| E11 | `sf_atomic_engine.sv` | completion always reports success | KILLED | smoke | [355000] ERROR: completion success flag differs from the reference |
| E12 | `sf_atomic_engine.sv` | completion returns the NEW value instead of the original | KILLED | smoke | [165000] ERROR: value differs from the memory content at the linearisation point |
| E13 | `sf_atomic_engine.sv` | linearisation event of writing operations missing | KILLED | smoke | [165000] ERROR: cepted without a (writing) linearisation event in the same cycle |
| E14 | `sf_atomic_engine.sv` | completion destination ignored (always the issuer) | KILLED | reset | [735000] ERROR: completion delivered to the wrong destination port |
| L01 | `sf_atomic_lock_table.sv` | second atomic on a locked granule is granted | KILLED | smoke | [165000] ERROR: two contexts hold the same lock granule |
| L02 | `sf_atomic_lock_table.sv` | ordinary writes are not held off by a lock | KILLED | contend | [1315000] ERROR: te was accepted inside another atomic's read-modify-write window |
| L03 | `sf_atomic_lock_table.sv` | locks are never released | KILLED | smoke | [2000115000] ERROR: ADLOCK / timeout: commands or ordinary requests did not complete |
| L04 | `sf_atomic_lock_table.sv` | no hold-off of atomics behind an ordinary write | KILLED | starve | [2011275000] ERROR: ADLOCK / timeout: commands or ordinary requests did not complete |
| L05 | `sf_atomic_lock_table.sv` | locks survive a reset | KILLED | reset | [385000] ERROR: two contexts hold the same lock granule |
| L06 | `sf_atomic_lock_table.sv` | reservation never blocks ordinary writes (ordinary stream starves atomics) | KILLED | starve | [600115000] ERROR:  writer hammered the same word (ordinary stream starves atomics) |
| O01 | `sf_atomic_ordering.sv` | ordinary writes interleave with atomics | KILLED | contend | [1315000] ERROR: te was accepted inside another atomic's read-modify-write window |
| O02 | `sf_atomic_ordering.sv` | every context takes every atomic response | KILLED | smoke | [155000] ERROR: success flag differs from the sequential reference |
| O03 | `sf_atomic_ordering.sv` | no grant lock: a stalled memory request can be withdrawn / switched | KILLED | order | [885000] ERROR: memory request payload changed while stalled (SFB2 R2) |
| O04 | `sf_atomic_ordering.sv` | ordinary response valid during reset | KILLED | reset | [1375000] ERROR: ordinary response valid during reset |
| O05 | `sf_atomic_ordering.sv` | (equivalent: space reserved) -- control mutant | EQUIVALENT |  |  |
| O06 | `sf_atomic_ordering.sv` | ordinary read data lost | KILLED | contend | [995000] ERROR: nary read data differs from the memory content at its acceptance |
| Q01 | `sf_atomic_queue.sv` | queue accepts one command too many (overwrites a pending entry) | KILLED | ticket | [255000] ERROR: OK completion without a commit event (no linearisation point) |
| Q02 | `sf_atomic_queue.sv` | quiesce does not stop ingress | KILLED | quiesce | [195000] ERROR: quiesce: cmd_ready must be 0 |
| Q03 | `sf_atomic_queue.sv` | scheduler is fixed priority (client 0 first) | KILLED | fair | [24205000] ERROR: r: a client was served noticeably less than another (starvation) |
| Q04 | `sf_atomic_queue.sv` | success flag lost in the queue | KILLED | smoke | [195000] ERROR: completion success flag differs from the reference |
| Q05 | `sf_atomic_queue.sv` | destination lost in the queue | KILLED | reset | [735000] ERROR: completion delivered to the wrong destination port |
| Q06 | `sf_atomic_queue.sv` | tag corrupted for one slot | KILLED | smoke | [335000] ERROR: commit event for a command that is not outstanding |
