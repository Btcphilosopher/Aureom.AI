# Synthesis statistics (Yosys 0.33, generic gates)

> **No library, no timing, no power, no placement.** The counts are structure counts after `synth -flatten` and `abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX`. `NAND2-eq` is an **estimate** (AND/OR-type = 1, XOR/XNOR = 2.5, MUX = 2.5, NOT = 0.5; flops not included). `depth` is the unweighted longest topological path in gates (`ltp -noff`), not a delay.

## Whole engine

| configuration | cells | flip-flops | combinational | NAND2-eq (est.) | depth (gates) |
|---|---|---|---|---|---|
| phase1  (NCTX=1, FADD+CAS, 32-bit) | 49,830 | 4,867 | 44,963 | 62,834 | 112 |
| phase2  (NCTX=1, all ops, 64-bit) | 49,400 | 4,867 | 44,533 | 63,206 | 110 |
| default (NC=4 QD=4 NCTX=2) | 51,411 | 5,184 | 46,227 | 64,988 | 116 |
| ctx4    (NCTX=4) | 55,576 | 5,816 | 49,760 | 69,238 | 127 |
| ctx4+coh (NCTX=4, COHERENT=1, 16 lines) | 76,236 | 7,175 | 69,061 | 95,388 | 135 |
| ctx4 PERF=0 | 50,017 | 4,728 | 45,289 | 62,458 | 121 |

## Modules (stand-alone, representative parameters)

| module | cells | flip-flops | combinational | NAND2-eq (est.) | depth (gates) |
|---|---|---|---|---|---|
| `sf_atomic_alu` | 2,172 | 0 | 2,172 | 2,416 | 114 |
| `sf_atomic_lock_table` | 2,712 | 150 | 2,562 | 2,946 | 9 |
| `sf_atomic_queue` | 31,134 | 3,090 | 28,044 | 42,904 | 34 |
| `sf_atomic_ordering` | 3,077 | 310 | 2,767 | 2,843 | 26 |
| `sf_atomic_perf` | 6,571 | 1,120 | 5,451 | 7,806 | 83 |
| `sf_atomic_coh_agent` | 11,654 | 1,320 | 10,334 | 14,956 | 135 |
