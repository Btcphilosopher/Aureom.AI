# Formal results (Yosys 0.33 internal SAT: `sat -tempinduct` / `sat -seq`)

Properties live in `formal/*.svh` (included into the RTL under `SF_ATOMIC_PROPS` / `SF_ATOMIC_FORMAL`); their headers define each property and the environment assumptions. **UNBOUNDED** = temporal induction closed, valid for all depths under the environment; **BOUNDED** = no counterexample in any execution of the stated length from reset, nothing beyond. Instances are deliberately small (see each row's parameters in `formal/run_formal.py`).

| module / harness | verdict | check | depth | result | seconds | note |
|---|---|---|---|---|---|---|
| alu | UNBOUNDED | all-input proof |  | PASS | 1.9 | no counterexample for any input |
| alu |  | sensitivity (planted signed-compare defect) |  | PASS | 0.5 | counterexample found: the harness can fail |
| lock | UNBOUNDED | induction | k=2 | PASS | 0.2 | induction step proven (all depths) |
| lock | BOUNDED | bmc | 30 | PASS | 2.4 | no counterexample within the depth |
| lock |  | non-vacuity (cover points) | 12 | PASS | 0 | 5 of 5 cover points reachable under the environment |
| queue_struct | UNBOUNDED | induction | k=2 | PASS | 4.5 | induction step proven (all depths) |
| queue | BOUNDED | bmc | 20 | PASS | 1406.8 | no counterexample within the depth |
| ordering | BOUNDED | induction | k=6 | **no result / FAIL** | 3.9 | base case proven to length 6; induction step did not close |
| ordering | BOUNDED | bmc | 16 | PASS | 10.7 | no counterexample within the depth |
| engine_d10 | BOUNDED | bmc | 10 | PASS | 976.9 | no counterexample within the depth |
| engine_d10 |  | non-vacuity (cover points) | 14 | PASS | 0 | 8 of 8 cover points reachable under the environment |
| engine | BOUNDED | bmc | 14 | **no result / FAIL** | 3000.0 | NO RESULT: the solver did not finish within 3000 s (timeout, not a counterexample); the depth-10 run (engine_d |
| engine_rst | BOUNDED | bmc | 8 | PASS | 203.1 | no counterexample within the depth |
