# Benchmark (RTL simulation cycles; ideal memory; 32-bit FETCH-ADD, 100 operations per client, back to back)

`ops/cycle` = committed operations / cycles from the first command to the last completion. Latencies are accept -> completion delivered, in cycles. `lock wait` = cycles the queue head was blocked by a lock before it was granted; `contended` = operations that waited at least one cycle for a lock. Hard ceiling: one memory master port, two requests per writing atomic => 0.5 operations per cycle.

| workload | NC | NCTX | mem latency | lock granule | ops | cycles | **ops / cycle** | avg latency | max latency | avg queue wait | max queue wait | avg lock wait | max lock wait | contended ops | ingress stall cycles | ctx utilisation |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| same-word | 4 | 1 | 1 | 8 B | 400 | 2403 | **0.166** | 93.1 | 95 | 87.1 | 89 | 19.8 | 20 | 399 | 8396 | 83 % |
| own-word | 4 | 1 | 1 | 8 B | 400 | 2403 | **0.166** | 93.1 | 95 | 87.1 | 89 | 4.9 | 5 | 396 | 8396 | 83 % |
| random-32 | 4 | 1 | 1 | 8 B | 400 | 2403 | **0.166** | 93.1 | 95 | 87.1 | 89 | 0.6 | 10 | 50 | 8396 | 83 % |
| same-word | 4 | 2 | 1 | 8 B | 400 | 2403 | **0.166** | 93.1 | 95 | 87.1 | 89 | 19.8 | 20 | 399 | 8396 | 41 % |
| own-word | 4 | 2 | 1 | 8 B | 400 | 1204 | **0.332** | 46.1 | 47 | 40.1 | 41 | 4.9 | 5 | 396 | 3814 | 83 % |
| random-32 | 4 | 2 | 1 | 8 B | 400 | 1204 | **0.332** | 45.8 | 65 | 39.8 | 59 | 0.7 | 10 | 55 | 3819 | 83 % |
| same-word | 4 | 4 | 1 | 8 B | 400 | 2403 | **0.166** | 93.1 | 95 | 87.1 | 89 | 19.8 | 20 | 399 | 8396 | 20 % |
| own-word | 4 | 4 | 1 | 8 B | 400 | 806 | **0.496** | 30.5 | 31 | 22.5 | 23 | 6.9 | 7 | 396 | 2294 | 86 % |
| random-32 | 4 | 4 | 1 | 8 B | 400 | 806 | **0.496** | 30.4 | 47 | 22.4 | 39 | 1.0 | 13 | 64 | 2301 | 86 % |
| same-word | 4 | 8 | 1 | 8 B | 400 | 2403 | **0.166** | 93.1 | 95 | 87.1 | 89 | 19.8 | 20 | 399 | 8396 | 10 % |
| own-word | 4 | 8 | 1 | 8 B | 400 | 806 | **0.496** | 30.5 | 31 | 22.5 | 23 | 6.9 | 7 | 396 | 2294 | 43 % |
| random-32 | 4 | 8 | 1 | 8 B | 400 | 812 | **0.492** | 29.6 | 92 | 14.4 | 76 | 2.7 | 43 | 95 | 2264 | 87 % |
| same-word | 4 | 4 | 3 | 8 B | 400 | 4003 | **0.099** | 155.9 | 159 | 145.9 | 149 | 35.7 | 36 | 399 | 14516 | 22 % |
| own-word | 4 | 4 | 3 | 8 B | 400 | 1006 | **0.397** | 38.4 | 39 | 28.4 | 29 | 8.9 | 9 | 396 | 3062 | 89 % |
| random-32 | 4 | 4 | 3 | 8 B | 400 | 1013 | **0.394** | 37.9 | 60 | 27.9 | 50 | 1.7 | 17 | 85 | 3035 | 88 % |
| same-word | 8 | 4 | 1 | 8 B | 800 | 4803 | **0.166** | 94.1 | 95 | 88.1 | 89 | 39.7 | 40 | 799 | 35896 | 20 % |
| own-word | 8 | 4 | 1 | 8 B | 800 | 1606 | **0.498** | 30.8 | 34 | 22.8 | 26 | 6.9 | 7 | 792 | 10956 | 87 % |
| random-32 | 8 | 4 | 1 | 8 B | 800 | 1606 | **0.498** | 30.3 | 71 | 22.3 | 63 | 1.9 | 28 | 203 | 10826 | 87 % |
