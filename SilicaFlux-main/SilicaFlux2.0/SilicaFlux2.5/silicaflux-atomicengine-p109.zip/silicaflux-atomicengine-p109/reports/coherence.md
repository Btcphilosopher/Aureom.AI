# Coherence system regression

Real CoherenceDirectory (P107, vendored unmodified) with N_AGENTS = 3: agents 0 and 1 are P107's own CPU cache adapters, agent 2 is the AtomicEngine's coherent path. Golden cache-line image checked on every performed operation of every agent; after each test every agent FLUSHes and the shared memory must equal the golden image.

**24 / 24 runs pass; 81,882 self-checks; 6,167 coherent atomic operations and 1,536 CPU cache operations checked.**

| geometry | test | seed | result | engine commands | of which coherent | CPU cache operations | self-checks |
|---|---|---|---|---|---|---|---|
| nctx2 | coh_directed | 1 | PASS | 8 | 6 | 8 | 183 |
| nctx2 | coh_naive | 1 | PASS | 1 | 1 | 3 | 94 |
| nctx2 | coh_random | 1 | PASS | 240 | 207 | 62 | 2,764 |
| nctx2 | coh_random | 2 | PASS | 240 | 206 | 62 | 2,764 |
| nctx2 | coh_random | 3 | PASS | 240 | 212 | 56 | 2,754 |
| nctx2 | coh_random | 4 | PASS | 240 | 202 | 58 | 2,759 |
| nctx2 | coh_random | 5 | PASS | 240 | 208 | 59 | 2,764 |
| nctx2 | coh_stress | 1 | PASS | 480 | 421 | 95 | 5,409 |
| nctx2 | coh_stress | 2 | PASS | 480 | 412 | 95 | 5,382 |
| nctx2 | coh_stress | 3 | PASS | 480 | 392 | 102 | 5,364 |
| nctx2 | coh_stress | 4 | PASS | 480 | 406 | 88 | 5,365 |
| nctx2 | coh_stress | 5 | PASS | 480 | 414 | 98 | 5,405 |
| nctx4_nc2_memready60 | coh_directed | 1 | PASS | 8 | 6 | 8 | 183 |
| nctx4_nc2_memready60 | coh_naive | 1 | PASS | 1 | 1 | 3 | 94 |
| nctx4_nc2_memready60 | coh_random | 1 | PASS | 240 | 202 | 66 | 2,759 |
| nctx4_nc2_memready60 | coh_random | 2 | PASS | 240 | 197 | 55 | 2,731 |
| nctx4_nc2_memready60 | coh_random | 3 | PASS | 240 | 203 | 60 | 2,749 |
| nctx4_nc2_memready60 | coh_random | 4 | PASS | 240 | 202 | 66 | 2,764 |
| nctx4_nc2_memready60 | coh_random | 5 | PASS | 240 | 214 | 62 | 2,784 |
| nctx4_nc2_memready60 | coh_stress | 1 | PASS | 480 | 406 | 97 | 5,380 |
| nctx4_nc2_memready60 | coh_stress | 2 | PASS | 480 | 411 | 86 | 5,364 |
| nctx4_nc2_memready60 | coh_stress | 3 | PASS | 480 | 414 | 90 | 5,370 |
| nctx4_nc2_memready60 | coh_stress | 4 | PASS | 480 | 416 | 83 | 5,363 |
| nctx4_nc2_memready60 | coh_stress | 5 | PASS | 480 | 408 | 74 | 5,334 |
