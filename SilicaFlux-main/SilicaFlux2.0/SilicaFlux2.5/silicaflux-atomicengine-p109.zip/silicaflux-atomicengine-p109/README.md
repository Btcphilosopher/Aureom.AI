# SilicaFlux Project 109 — AtomicEngine

**Hardware atomic memory-operation engine** · Aureom.AI | SilicaFlux Cloud Semiconductor Systems · primary RTL: [`rtl/sf_atomic_engine.sv`](rtl/sf_atomic_engine.sv)

Delivered as this archive. **Nothing was committed to GitHub.**

> ## Read this first — scope of every claim
>
> * **RTL + simulation + formal + generic synthesis only.** No FPGA, no PDK, no timing / area / power in a real library, no silicon. The synthesis
>   report is a structure count (`reports/synthesis.md`) and says so.
> * **Atomicity is real but conditional.** The engine makes read-modify-write atomic *against every access that passes through it*. The memories in this
>   repository have no locks and give atomicity only for one word (MemoryMatrix M4/M5), so **integration rule R1 is mandatory**: the engine's memory
>   port must be the only path to the atomic window (enforce it with MemoryGuard / MemoryMatrix region permissions). See `docs/04_INTEGRATION.md`.
> * **No RISC-V memory-model (RVWMO) compliance is claimed.** Only the ordering that is implemented and tested is documented (`docs/ARCHITECTURE_SPEC.md` §10).
> * **Coherence is integrated with the real CoherenceDirectory (P107)** in simulation (3 agents: two P107 CPU caches + the engine). It is *not* formally
>   proved; the directory itself is proved only for its minimal 2-agent instance by P107. Throughput of the coherent window is one operation at a time.
> * **Formal results are mixed**: some proofs are unbounded, the engine-level exclusivity proof is a bounded model check. `reports/formal.md` states which is which.
> * Two items of the brief's list do not exist in the repository and were **not invented**: an `AtomicEngine` (this project creates it) and CPU-side atomics
>   (the ControlCore is RV32I with no A extension). `docs/00_AUDIT.md` lists what was found.

## What it does

NC clients submit atomic commands (swap, fetch-add / and / or / xor, signed and unsigned min / max, compare-and-swap; 32- and 64-bit) on a **command
interface** that carries opcode, address, operand, compare value, width, requester id, tag, protection domain and completion destination. The engine validates
each command (opcode, width, alignment, window, domain binding, destination, MemoryGuard **read and write** permission), queues it in a bounded per-client queue,
schedules clients round-robin, **locks the 8-byte word (or 64-byte line)**, reads the word, applies the ALU, writes the result, unlocks, and returns the
**original value**, a success flag, an error status and the tag. Ordinary loads / stores that must meet the same memory go through the engine's **ordinary port**;
an ordinary write to a locked word is held back until the lock is released, so no ordinary access can interleave with a read-modify-write.
With `COHERENT = 1`, addresses of the coherent window are executed as GETM → perform-on-grant → PUTM through a one-line agent of the CoherenceDirectory.

```
 clients 0..NC-1 ──cmd──► validate ─► per-client queues ─► RR start ─► NCTX contexts ─┐  lock table (word / line)
        ▲                  (guard R+W hook)                                         │  ALU
        └───────── completion (old, succ, status, tag, dest) ◄───────────────────────┘
 ordinary port (CPU / DMA) ─► ordering unit ─► ONE memory master port (MemoryMatrix contract)
 coherent window ─► sf_atomic_coh_agent ─► CoherenceDirectory (REQ / RSP / SNP / GNT)
```

## Deliverables (the brief's list → where it is)

| Deliverable | File |
|---|---|
| `sf_atomic_engine.sv` | `rtl/sf_atomic_engine.sv` |
| `sf_atomic_alu.sv` | `rtl/sf_atomic_alu.sv` |
| `sf_atomic_lock_table.sv` | `rtl/sf_atomic_lock_table.sv` |
| `sf_atomic_queue.sv` | `rtl/sf_atomic_queue.sv` |
| `sf_atomic_ordering.sv` | `rtl/sf_atomic_ordering.sv` |
| `sf_atomic_perf.sv` | `rtl/sf_atomic_perf.sv` |
| (supporting) package, coherence agent | `rtl/sf_atomic_pkg.sv`, `rtl/sf_atomic_coh_agent.sv`, file list `rtl/files.f` |
| Self-checking testbench | `tb/tb_sf_atomic_engine.sv` (system, uncached) · `tb/tb_sf_atomic_coh.sv` (real P107 directory) · `tb/tb_sf_atomic_alu.sv` (Python-vector replay) · `tb/sf_atomic_mem_model.sv` |
| Independent sequential reference model | `model/sf_atomic_ref.py` (Python) and the scoreboard's own reference task in the testbenches |
| Formal properties | `formal/*.svh`, `formal/fv_alu.sv`, runner `formal/run_formal.py`, results `reports/formal.md` |
| Synthesis reports | `reports/synthesis.md` (+ `.json`), runner `scripts/synth.py` |
| Architectural specification | `docs/ARCHITECTURE_SPEC.md` (+ `docs/00_AUDIT.md`, `04_INTEGRATION.md`, `VERIFICATION.md`, `LIMITATIONS.md`) |

## Quick start

```bash
# tools used: Verilator 5.020, Yosys 0.33 (+ yosys-smtbmc, yosys-abc), z3 4.8, Icarus 12 (RTL elaboration only), Python 3
scripts/vrun.sh default "" smoke 1          # one test, default configuration (NC=4 QD=4 NCTX=2)
scripts/regress.py --seeds 3                # 8 configurations x 18 tests x seeds     -> reports/regression.md
scripts/crun.sh coh_random 1                # one coherence system test (real P107 directory)
scripts/coh_regress.py                      # coherence regression (2 geometries x 12 runs)   -> reports/coherence.md
scripts/mutate.py                           # 41 planted RTL defects                  -> reports/mutation.md
scripts/mutate.py --coh                     # 8 planted coherence-path defects        -> reports/mutation_coh.md
python3 -I model/sf_atomic_ref.py vectors build/alu_vectors.hex && scripts/alu_check.sh   # ALU replay of the Python vectors
formal/run_formal.py                        # formal jobs                              -> reports/formal.md
scripts/synth.py                            # generic-gate statistics                  -> reports/synthesis.md
scripts/bench.py                            # throughput / latency / contention        -> reports/bench.md
scripts/make_docs.py                        # copies the numbers of reports/ into docs/VERIFICATION.md
scripts/make_zip.py                         # builds silicaflux-atomicengine-p109.zip
```

## Phases (as requested: start small, then extend)

| Phase | Configuration of the same RTL | Verified by |
|---|---|---|
| 1 uncached 32-bit FETCH-ADD + CAS | `NCTX=1 OP_EN=FADD+CAS W64_EN=0` (config `phase1`) | whole test list |
| 2 + 64-bit and every opcode | `NCTX=1` (`phase2`) | whole test list |
| 3 + parallel address locks | `NCTX=2..4`, word or line granule (`default`, `ctx4`, `nc3`, `line`, `lat3`) | whole test list, mutation campaign |
| 4 + coherence integration | `COHERENT=1` | `tb_sf_atomic_coh.sv` with the real CoherenceDirectory |

Layout: `rtl/` · `tb/` · `model/` · `formal/` · `scripts/` · `docs/` · `reports/` · `third_party/coherence_p107/` (vendored unmodified, `SHA256SUMS`).
