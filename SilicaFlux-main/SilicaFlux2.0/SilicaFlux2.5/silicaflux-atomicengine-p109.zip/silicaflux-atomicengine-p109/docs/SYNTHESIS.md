# Synthesis (generic gates only)

`scripts/synth.py` → `reports/synthesis.md`, `reports/synthesis.json`. Yosys 0.33, `synth -flatten` followed by `abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX`.

> **No technology library, no timing, no power, no placement, no clock frequency.** The numbers are structure counts. `NAND2-eq` is an *estimate* from fixed weights;
> `depth` is the unweighted longest topological path in gates (`ltp -noff`), **not a delay**. Nothing here says the design meets any frequency in any process.

## What the report shows (copied from `reports/synthesis.md`)

| configuration | cells | flip-flops | NAND2-eq (est.) | depth (gates) |
|---|---|---|---|---|
| phase 1 (`NCTX=1`, FADD + CAS, 32-bit) | 49,830 | 4,867 | 62,834 | 112 |
| phase 2 (`NCTX=1`, all opcodes, 64-bit) | 49,400 | 4,867 | 63,206 | 110 |
| default (`NC=4 QD=4 NCTX=2`) | 51,411 | 5,184 | 64,988 | 116 |
| `NCTX=4` | 55,576 | 5,816 | 69,238 | 127 |
| `NCTX=4`, `COHERENT=1`, 16 directory lines | 76,236 | 7,175 | 95,388 | 135 |
| `NCTX=4`, `PERF=0` | 50,017 | 4,728 | 62,458 | 121 |

| module (stand-alone) | cells | flip-flops | depth |
|---|---|---|---|
| `sf_atomic_queue` (NC=4, QD=4, payload 102 bits) | 31,134 | 3,090 | 34 |
| `sf_atomic_coh_agent` (16 lines) | 11,654 | 1,320 | 135 |
| `sf_atomic_perf` | 6,571 | 1,120 | 83 |
| `sf_atomic_ordering` (NCTX=4) | 3,077 | 310 | 26 |
| `sf_atomic_lock_table` (N=4) | 2,712 | 150 | 9 |
| `sf_atomic_alu` | 2,172 | 0 | 114 |

## Reading it

* **The queue dominates the area** (31 k of the 51 k cells of the default configuration, 3.1 k of its 5.2 k flip-flops): 16 entries × ≈ 190 bits (64-bit operand, address, compare / old value, tag, requester id, destination, flags, status).
  Halving `QD` or `NC` halves it. A leaner variant would keep only {op, width, address} per entry and fetch the operands later — not done.
* **Phase 1 and phase 2 are essentially the same size** in this count (49.8 k vs 49.4 k cells): the opcode / width enables fold into a few gates and the 64-bit data path is shared. Disabling opcodes buys verification scope, not area.
* **Parallel locks are cheap**: going from 1 to 4 contexts adds ≈ 6 k cells (3 more context register sets and lock entries, wider arbitration); the shared ALU and the single memory port are unchanged.
* **Coherence costs ≈ 20 k cells** (`NCTX=4`: 55.6 k → 76.2 k): the one-line agent (11.7 k cells stand-alone, ≈ 1.3 k flip-flops) plus the 512-bit line data path and the extra context mux.
* **Counters** (`PERF = 1`) cost ≈ 5.5 k cells / 1.1 k flops (per-entry timestamps dominate).
* **Longest path**: ≈ 110 – 135 unweighted gate levels. For the default configuration `ltp` reports 116 levels from the input `m_rsp_valid` (through the response-to-context select, the shared 64-bit ALU — adder and signed / unsigned comparators — and the write-data mux) to bit 63 of the `cx_new` register: the engine closes *memory response → ALU → context register* in one cycle. A register stage between
  the response and the ALU would cut it at the price of one more lock-hold cycle; **it is not implemented** and no frequency is claimed.
* The default configuration elaborates with Yosys `check` reporting 0 problems, and Verilator `-Wall` is clean (with and without the property files) for the configurations listed in `reports/regression.md`, for `PERF = 0` and for `COHERENT = 1`.

## Not measured

Area in a library, timing, power, SRAM macros for the queue (it is flops here), clock-gating, reset-tree cost, scan insertion, physical design.
