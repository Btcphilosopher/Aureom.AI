# 04 — Integration rules, the uncached/coherent regions, and what connects to what

Everything the engine guarantees rests on rules that **only the integrator can establish** (the engine cannot see what is wired around it). They are
listed first; the table of interfaces follows.

## 1. Integration rules

| # | Rule | Why | How to enforce / check |
|---|---|---|---|
| **R1** | **Every access to the atomic window reaches memory through the engine** (atomic commands, or the **ordinary port**). No second master, no debug / MBIST / DMA path on the same memory without its own protection. | The memories have no locks and no atomicity beyond one word (MemoryMatrix M4/M5). A master that bypasses the engine can write a word between the engine's read and write: **a lost update the engine cannot see.** | MemoryGuard (P104) inline ports or MemoryMatrix `NUM_REGIONS` permissions: deny every port except the engine's own for the window. Disable test / debug access in production lifecycle states (P104 R7). |
| **R2** | The engine's memory port obeys the **MemoryMatrix contract**: acceptance-order visibility, in-order responses with the request id echoed, relative byte lanes, `req_ready` independent of `req_valid`. | Ordering of ordinary accesses against atomics, response routing. | `tb/sf_atomic_mem_model.sv` implements exactly this contract; MemoryMatrix (P101) M1–M3 and SRAMController (P73) state it. A memory with absolute lanes (SFB2 native) needs a thin adapter. |
| **R3** | `win_base`, `win_limit` are 8-byte aligned (`coh_*` 64-byte aligned); the windows do not overlap; `coh_limit − coh_base ≤ DIR_LINES × 64`. | A natural-aligned ≤ 8-byte access then never straddles the window edge or a word. | `cfg_err_o` flags a violation; the engine then treats that window as empty (`AST_RANGE`). |
| **R4** | `port_dom_mask` (domain binding), `dest_allow`, the window registers and `atom_prot_i` are driven **only from the management plane** (ControlCore behind the secure-boot gate), constant while commands are in flight. | They are the trusted part of the check; a client must not be able to change them. | Same rule as MemoryGuard R3. |
| **R5** | **Policy changes follow the drain rule**: assert `quiesce_i`, wait `idle_o`, reprogram the guard / registers, release. | A command accepted under the old policy would otherwise execute under the new one (time-of-check / time-of-use). `quiesce_i` blocks new commands **and** new ordinary requests, lets queued work finish; `idle_o` = nothing queued, running or in flight. | MemoryGuard's own in-flight policy is drain-then-commit; the engine's `idle_o` provides the matching condition. |
| **R6** | **Uncached region only (before / without coherence).** The atomic window must lie in memory that no cache holds: a non-cacheable window (CacheForge `cfg_nc_*` / `attr.mem_type` ≠ NORMAL_WB), or a region no cache is configured to map. | An atomic that writes memory behind a cache leaves a stale copy (CacheForge is not coherent, P106 docs/05 §2). | CLEAN_INVAL the range before it becomes atomic (P106 maintenance), then never cache it. With `COHERENT = 1` use the coherent window instead (§3). |
| **R7** | The engine's reset is the system reset of the memory behind it (one reset, synchronous release). | After reset nothing in flight survives on either side (SFB2 R11). | One reset tree. |
| **R8** | The clients of the command interface are **trusted by port, not by claim**: the port index is the identity; `cmd_dom` is only a claim checked against `port_dom_mask` and the MemoryGuard verdict. | Same anchor as MemoryGuard (the claim is attacker-controlled; the physical port is not). | One physical master per port, or masters that may act for the same domains. |

## 2. Interfaces and the neighbouring blocks

| Neighbour | Interface | Connection | Status here |
|---|---|---|---|
| **MemoryMatrix** (P101) | its master port (`m_req_*`: valid/ready, `we`, byte `addr`, `size` = log2 bytes, `wdata`, `be`, `id`, `prot`; response with `rdata`, `id`, `we`, `status`) | engine `m_*` → one matrix master port (the class map of the matrix decides which port number) | **contract modelled and tested** (`tb/sf_atomic_mem_model.sv`); the real matrix was **not instantiated** in a system test |
| **SRAMController** (P73) | SFB2 master port | needs `id`/`size` extensions that the P73 doc states as additive | contract (acceptance-order visibility, errors without side effect) matches; **not instantiated** |
| **Meridian / DataFabric** | SFB2 / Albion single-beat READ / WRITE | clients reach the engine through the command interface (not through Meridian: there is no atomic opcode). The engine's *memory side* may sit behind a Meridian target port. | wiring only; **not instantiated** |
| **MemoryGuard** (P104) | combinational verdict per port: `{op READ \| WRITE, addr, len, dom}` → `permit` | engine outputs `grd_addr_o / grd_len_o / grd_dom_o` per client; inputs `grd_ok_r`, `grd_ok_w` = two `sf_memory_guard_checker` verdicts (op = READ and op = WRITE) of that port's guard | hook **tested with a behavioural region model** (whole transfer inside one region, R/W per region); the real checker was **not instantiated** — mapping only |
| **CoherenceDirectory** (P107) | REQ / RSP / SNP / GNT, line index messages | engine `rq_* / rs_* / sn_* / gn_*` ↔ directory slice of agent id `AGENT_ID` | **real directory simulated** (`tb/tb_sf_atomic_coh.sv`) |
| **CacheForge** (P106) | ALP v1 | no direct connection; rule R6 (NC window) | not instantiated |
| **StreamDMA** (P103) / CPU data port | ordinary loads and stores | engine **ordinary port** `o_*` (single beat ≤ 8 bytes; a wider master is split upstream) | modelled by the testbench's random ordinary master |
| **ControlCore** (P21) | SFB2 master (`ext_*`) | an MMIO wrapper that turns register writes into a command and register reads into the completion is **integration work, not built** | not built |
| **Clockworks** (P105) | quiescence contract | `quiesce_i` / `idle_o` map to its stop-new-work / confirm-idle steps | mapping only |

## 3. The two address regions

| | **Uncached window** `[win_base, win_limit)` | **Coherent window** `[coh_base, coh_limit)` (`COHERENT = 1`) |
|---|---|---|
| Executed by | contexts through the engine's single memory port (read, ALU, write under a lock) | `sf_atomic_coh_agent`: GETM → perform on grant → COMPLETE → PUTM → PUTACK |
| Cached copies | **must not exist** (R6) | allowed: the directory invalidates sharers / takes the dirty line from the owner before the ALU runs; after the operation the engine keeps **no** copy |
| Ordinary port access | allowed (loads and stores, lock-checked) | **refused** (`OST_COHWIN`): the window is reachable only by coherent agents and the engine's coherent path |
| Concurrency | up to `NCTX` operations on different granules in parallel | one operation at a time (single agent); documented limit |
| Linearisation point | acceptance of the write at the memory port (read response for a failed CAS) | the edge at which the line arrives (perform-on-grant), exactly as P107's own AMO |
| Typical use | locks, queue pointers, doorbells, counters shared with accelerators and DMA | counters shared with CPU caches |

A command whose address lies in neither window is rejected (`AST_RANGE`). With `COHERENT = 0` the coherent window does not exist, which is the
"before coherence integration: documented uncached region only" requirement of the mission.

## 4. Enforcing R1 with the existing blocks

1. Give the engine its own master port on the memory (MemoryMatrix class map) and mark the atomic window as accessible **only** by that port
   (`NUM_REGIONS`, `DEFAULT_ALLOW = 0` + one region with the engine's `prot`), or put an inline MemoryGuard port in front of every other master.
2. Route every other master's accesses to the window to the engine's **ordinary port** (the fabric decoder does this) instead of to the memory.
3. Keep debug / MBIST access to the window off in production (P104 R7). MemoryMatrix also has an optional ECC scrubber (P101 README: "scrubbing
   interface"); **this project did not verify how a scrub cycle interacts with the engine's read ... write window.** Until that is checked, disable the
   scrubber for the banks that hold the atomic window or confirm that a scrub write cannot land between the engine's read and write of a word.

## 5. Software contract (what a client must do)

* Wait for the completion before relying on the result; the completion of a **writing** atomic is delivered after the memory acknowledged the write.
* Handle the status codes of `docs/ARCHITECTURE_SPEC.md` §7: resubmit only per the retry class (never blindly after `AST_WRITE` / `AST_COH`).
* Use `aq` / `rl` (or wait for completions) when later commands must not overtake earlier ones on **different** words; commands on the **same** word of one client
  are always executed and completed in submission order.
* A producer that hands data to an atomic flag (data stored by DMA / CPU, then an atomic on the flag) must wait for the **write acknowledgements** of the data
  first (SFB2 R7 / Meridian T2): the engine orders what reaches it, it cannot order what has not been acknowledged yet.
