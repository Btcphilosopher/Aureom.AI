# Limitations and honest status

Everything below is something this package **does not do or does not prove**. It is deliberately not softened.

## What exists

RTL (SystemVerilog, flat-port Yosys-0.33 style), a self-checking simulation environment (Verilator), an in-RTL assertion set that runs in every simulation, a mutation campaign,
formal checks (Yosys + yosys-smtbmc + z3, ABC PDR), generic-gate synthesis statistics, and documentation. **No FPGA, no technology library, no static timing, no place-and-route,
no power analysis, no silicon.** No frequency, critical path, area in a real library, or power is claimed; `reports/synthesis.md` contains structure counts and an unweighted gate depth only.

## Architectural limits

* **Atomicity is conditional on integration rule R1** (`04_INTEGRATION.md`): a master that reaches the atomic window without passing through the engine can write between the engine's
  read and write. The engine cannot detect this. The memories in the repository offer no lock to close the gap (MemoryMatrix M4/M5).
* **One memory master port**: ≤ 1 request per cycle; a writing atomic needs two ⇒ ≤ 0.5 atomic operations per cycle at best, for any `NCTX`. Operations on the **same** granule serialise
  (a hot counter runs at one operation per lock-hold time). `NCTX = 1` is a single-lock configuration.
* **In-order start per client** (head-of-line): a head command waiting for a lock delays that client's later commands.
* **Coherent window: one operation at a time**, each costing a GETM and a PUTM round trip (the engine keeps no copy). Retaining ownership would be faster and is not implemented.
* **No RISC-V memory-model compliance** is claimed (`ARCHITECTURE_SPEC.md` §10). There are no `lr` / `sc`, no AMO instructions: the ControlCore (RV32I) has no A extension, and the MMIO wrapper
  that would let a CPU drive the command interface is **not built**.
* **Atomics are naturally aligned, ≤ 8 bytes, one word.** No 128-bit operations, no misaligned or word-spanning atomics (they would not be single-copy atomic), no atomic over a burst.
* **Unsigned wrap only for FADD**; there is no overflow flag and no saturating add.
* The **ordinary port** is single-beat (≤ 8 bytes) and in-order: an ordinary write to a locked word blocks the port behind it (head-of-line across words); reads are never blocked.
* Completion timestamps for statistics are 16 bits (an operation older than 65 535 cycles wraps its own sample).
* **No timeout** on the memory port: an engine waiting for a memory response that never comes keeps its lock. The memory is trusted to answer every accepted request (MemoryMatrix, SRAMController do).

## Error semantics that are deliberately weak

* `AST_WRITE` (memory write failed) and `AST_COH` leave the location **indeterminate**: MemoryMatrix's ECC read-modify-write path means a failed write cannot be proved side-effect free.
  The engine reports it and never retries by itself; software must read the location back.
* After a **reset**, an operation whose completion was lost may or may not have executed (a write accepted before the reset persists). Idempotent protocols or read-back are required.

## Verification scope — what is and is not proved

* **Simulation** is evidence, not proof: `reports/regression.md` lists every configuration, test and seed. The sequential reference model, the memory-port exclusivity monitor, the ticket test and the
  in-RTL assertions are independent of the RTL's own control logic, but all share the testbench's single memory model; the engine was run against the **real** MemoryMatrix, SRAMController, Meridian or
  MemoryGuard **in no test** — only against a model of the MemoryMatrix contract (`04_INTEGRATION.md` §2).
* **Formal**: see `reports/formal.md` for the exact verdict per job. The ALU equivalence and the lock-table invariants are all-depth proofs; the whole-engine exclusivity properties are a **bounded** model
  check of a reduced instance (NC = 2, QD = 2, NCTX = 2, AW = 16) — they say nothing about deeper pipelines or larger geometries; those are covered by simulation only. Fairness (bounded waiting) is proved
  for the arbiter *pointer rule* (Q8 / Q10), not as a liveness property of the whole engine.
* **Coherence**: the engine was simulated against the real P107 directory and two real P107 cache agents (N = 3), 5 seeds of random and stress traffic plus directed scenarios. P107's own formal proof covers its
  minimal 2-agent / 2-line instance only; **the 3-agent system including this engine has no formal proof.**
* **MemoryGuard**: the hook was tested with a behavioural region model that implements the same rule (whole transfer inside one region, per-region R / W). The real `sf_memory_guard_checker` was **not**
  instantiated with the engine.
* The mutation campaign (41 mutants, 40 non-equivalent killed) measures the testbench's sensitivity to the defects it plants, not the absence of other defects.
* Tools: Verilator 5.020, Yosys 0.33, z3 4.8.12, Icarus 12 (RTL elaboration only — the testbenches use Verilator's `--timing`). Other tool versions were not tried.

## Not done (candidate next steps)

1. System test with the real MemoryMatrix (4 banks, ECC on) behind the engine and a real MemoryGuard port in front of the ordinary master; check the scrubber interaction.
2. MMIO command wrapper for the ControlCore and a DMA-side doorbell example.
3. Retained-ownership coherent mode (keep the line in M across consecutive atomics to the same line).
4. Pipelining of the ALU stage (the memory response currently feeds the ALU and the context registers in one cycle — see the synthesis depth) and registered guard verdicts.
5. Per-granule queues (remove head-of-line) and multiple ordinary ports.
6. Liveness proof of the whole engine under fairness assumptions.
