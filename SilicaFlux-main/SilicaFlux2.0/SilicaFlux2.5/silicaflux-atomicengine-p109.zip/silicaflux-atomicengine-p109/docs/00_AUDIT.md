# 00 — Repository audit: what the existing blocks actually guarantee

Mission item 1 asked for the **actual** transaction-ordering guarantees of Meridian / DataFabric, MemoryMatrix, SRAMController, CacheForge,
CoherenceDirectory, ControlCore, MemoryGuard and the shared transaction definitions. This audit was made from the archives in this
repository (`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/*.zip`). Every statement cites the document or RTL it comes
from. Nothing was assumed from the block's name.

## 1. Where the named blocks are (and what is *not* there)

| Name in the brief | What exists | Source |
|---|---|---|
| Meridian | P83 `silicaflux-meridian-p83` (QoS / access-control fabric, Albion transaction format) and P102 `silicaflux-meridianqos-p102` (**located by archive name only; its documents were not read** — every Meridian finding below is from P83) | `…/silicaflux-meridian-p83/docs/meridian/02_PROTOCOL.md`, `08_LIMITATIONS.md` |
| DataFabric | P03 `silicaflux-datafabric` — SFB2 bus, crossbar, DMA | `docs/datafabric/PROTOCOL.md` (rules R1–R12) |
| MemoryMatrix | P101 `silicaflux-memorymatrix` — banked SRAM subsystem | `docs/memory_matrix/ARCHITECTURE.md` (contract M1–M8) |
| SRAMController | P73 `silicaflux-sramcontroller` | `docs/01_interface_and_semantics.md` (rules T1–T7) |
| CacheForge | P106 `silicaflux-cacheforge` — last-level cache, Albion Link Protocol v1 | `docs/05_integration.md`, `docs/08_limitations.md` |
| CoherenceDirectory | P107 `silicaflux-coherencedirectory` — MSI directory, 64-byte lines | `docs/01_PROTOCOL_SPEC.md`, `docs/05_NONCOHERENT_AND_INTEGRATION.md` |
| ControlCore | P21 `silicaflux-controlcore` (vendored under the cloud-runtime archive) with the MCU-I CPU | `…/silicaflux-mcu-i/docs/CPU.md` |
| MemoryGuard | P104 `silicaflux-memoryguard` — inline region-based protection | `docs/memory_guard/03_ENFORCEMENT_AND_BYPASS.md`, `rtl/memory_guard/sf_memory_guard_checker.sv` |
| Shared transaction definitions | SFB2 (`PROTOCOL.md`), Albion (`02_PROTOCOL.md` of P83), `sf_sram_defs.svh`, `sf_coherence_pkg.sv`, `sf_memory_guard_pkg.sv` | as listed |
| **AtomicEngine** | **does not exist** — P107's README states it explicitly ("an AtomicEngine … do[es] not exist in this repository"). This project creates it. | `silicaflux-coherencedirectory-p107/README.md` |

## 2. The guarantees that decide the design

### 2.1 No existing path gives an atomic read-modify-write

| Block | Finding (verbatim rule) | Consequence for the engine |
|---|---|---|
| **Meridian P83** | "Single-beat transactions: a burst is a sequence of transactions; there are no posted writes, fences or atomic operations." Opcodes `2`, `3` are reserved (`op` = 2 bits: READ, WRITE). | The fabric cannot carry an atomic. The engine therefore needs its **own command interface** (mission §3) and must be a *memory-side* agent. |
| **Meridian P83 ordering table** | "requests of one master to one target reach the target in issue order; to different targets no relative order; **across masters none; no coherence; use acknowledged writes**." Responses per master in acceptance order (`OOO = 0`). | Ordering across requesters has to be created by the engine itself (lock table + single memory port). |
| **SFB2 / DataFabric** | R5 one response per accepted request, in order. R7 "a write response is issued only after the write was performed". R6 **one outstanding transaction per crossbar port**. R10 **no bursts**. R11 reset cancels in-flight transactions, "an accepted write may or may not have been performed". | Two separate bus transactions (read, then write) are never atomic; the engine must not rely on them to be. Reset ambiguity of an accepted write is inherited and documented (docs/05). |
| **MemoryMatrix P101** | **M3** per-bank serialisation: a read accepted at edge *t* sees every write accepted at an earlier edge, across all masters. **M4 "Atomicity is one word (one bank access). A request spanning several words is a set of independent word accesses; another master can observe it half performed."** **M5 "No coherence, no locks."** M7 `flush`: "accepted words stay written (torn writes possible)". M8: reset clears control state only. | One 8-byte word access is single-copy atomic — the engine's 32/64-bit naturally-aligned accesses use exactly one word access. Everything larger needs the engine's lock. There is no lock to borrow: the engine supplies it. |
| **SRAMController P73** | "acceptance **is** issue": a request accepted at an edge observes every write accepted earlier to the same bank (T-rules, `bank ordering`); at most `MAX_OUT` (default 1) outstanding per master; a failed request has no side effect (T5). | Confirms (a) acceptance-order visibility as the memory-side contract the engine may rely on, (b) error = no side effect. |
| **CacheForge P106** | "**Not hardware-coherent** … ALP v1 carries one 16-byte beat per request … there are **no bursts, atomics**, QoS arbitration or per-domain enforcement." DMA visibility is software-managed (CLEAN / INVAL / CLEAN_INVAL) and a **non-cacheable window** exists (`cfg_nc_*`). | Before coherence integration, atomics are limited to an **uncached / shared-memory window** — which is exactly what CacheForge's NC window provides (integration rule R6, docs/04). |
| **CoherenceDirectory P107** | "AtomicEngine does not exist." The agent adapter's `OP_AMO` is a **32-bit fetch-add only**, "one indivisible read-modify-write on an M line" (perform-on-grant). Non-coherent masters reach the coherent window only through `sf_coherence_nc_gateway`, which **refuses window accesses by default** (N1–N8). One open transaction per line, explicit COMPLETE, no NACK. | The engine's coherent path must be a real *agent* of this protocol, not a gateway client: it acquires M with GETM, performs on grant, writes back with PUTM (docs/04). |
| **ControlCore / MCU-I** | RV32I + Zicsr + Zifencei, optional M; **no A extension** (`CPU.md` ISA table). The CPU data port is an SFB2 master. | The CPU cannot issue atomics natively; it reaches the engine through the command interface (an MMIO wrapper is integration work). |
| **StreamDMA P103** | AXI4 bursts via `sf_stream_dma_mm_bridge` into MemoryMatrix. | DMA traffic is ordinary loads / stores: it uses the engine's **ordinary port** when it touches the atomic window. |
| **MemoryGuard P104** | Inline, per-port enforcement: **authority = the physical port binding**; the request's domain field is a *claim* that must lie inside the binding. The **whole** transfer must lie in **one** region; ops are `READ` / `WRITE` only (`op` 2, 3 → `FT_BADOP`); denial leaves "no trace on the memory side"; drain-then-commit for policy changes (R5, R9). | The engine checks **read AND write** permission for one command (two verdicts), keeps the port as identity, and offers `quiesce_i` / `idle_o` so policy changes can follow the drain rule (docs/04 §5). |

### 2.2 Ordering facts used by the design (each is relied on in exactly one place)

1. **Acceptance-order visibility** at the memory port (MemoryMatrix M3, SRAMController): the engine needs it only to order *ordinary* accesses
   against atomics; the lock is released after the write **response** (not merely the acceptance) so that even a memory whose visibility point
   were its completion would still be safe for later accesses.
2. **Ids are echoed in order** (MemoryMatrix: "transaction ids preserved", responses in acceptance order): used to route responses to contexts and
   to the ordinary-response FIFO.
3. **One word access is atomic** (M4): used so that a naturally aligned 32/64-bit access is one indivisible read and one indivisible write. The
   engine rejects misaligned atomics (`AST_ALIGN`) instead of splitting them.
4. **Errors have no side effect** (SFB2 R8, MemoryMatrix, SRAMController T5): a failed *read* proves nothing was changed (`AST_READ`, retry-safe);
   for a failed *write* the ECC read-modify-write path of MemoryMatrix means the engine cannot prove the same, so `AST_WRITE` is "indeterminate".
5. **Reset** cancels in-flight work and an accepted write may or may not have been performed (SFB2 R11); memory contents are not reset (M8). The
   engine's reset rule is the same (docs/05).

### 2.3 What the audit rules out

* "Read then write over the fabric" as an atomic: false on every block above (this is demonstrated, not argued, by the negative control
  `+test=naive`: 200 naive increments from two masters on the testbench memory leave 100).
* An atomic that is **only** a memory-side lock: it protects only against accessors that pass through the engine. The memories have no lock of their
  own (M5), so integration rule **R1** is mandatory: *every* access to the atomic window must go through the engine (ordinary port) — enforce it
  with MemoryGuard / MemoryMatrix region permissions (docs/04 §4).
* Claiming RISC-V memory-model compliance: Meridian and the memories give no cross-master ordering, the ControlCore has no A extension, and the
  engine implements only the hooks listed in docs/03 §6. **No RVWMO compliance is claimed.**
