# AtomicEngine — Architectural Specification (SilicaFlux Project 109)

Primary RTL: `rtl/sf_atomic_engine.sv` · companion documents: `00_AUDIT.md` (what the neighbouring blocks guarantee), `04_INTEGRATION.md` (rules R1–R8),
`VERIFICATION.md` (evidence), `LIMITATIONS.md` (what is not done). Section numbers `§n` below refer to this document.

> **Definition of done of the mission** — *multiple supported clients can concurrently request atomic updates to shared memory, and every committed
> result matches a valid serial execution without lost updates.* Evidence: the sequential reference model replays every linearisation point of every
> regression run on the memory's real content (`VERIFICATION.md` §2); the ticket test returns every value 0 … N−1 exactly once; the memory-port monitor sees
> no write inside any read-modify-write window; the formal exclusivity properties (lock uniqueness unbounded, whole-engine bounded).
> This holds **under integration rule R1** (§15): atomicity is against accesses that pass through the engine.

## 1. Structure

```
                     per client c = 0 .. NC-1                                          NCTX contexts          lock table
 cmd_*  ──► ingress validation ──► in-order bounded queue (QD) ──► RR start ──► ctx 0 .. NCTX-1 ──► ALU      entry i = ctx i
 (struct §3) op | width | align | window | domain | dest | guard R+W   │                 │ read / write requests
                       └─ rejected ⇒ stored DONE, never starts        │                 ▼
 rsp_*  ◄── in-order completion per client ◄── write-back {old, succ, status} ◄────  sf_atomic_ordering ──► m_*  (one memory master port)
 (dest port)                                                                              ▲
 o_*  ordinary port (CPU / DMA loads & stores) ───────────────────────────────────────────┘  holds ordinary WRITES to locked words
 rq/rs/sn/gn  ◄──► sf_atomic_coh_agent  (COHERENT = 1: GETM → perform-on-grant → PUTM)
```

| File | Role |
|---|---|
| `sf_atomic_pkg.sv` | opcodes, width codes, status codes, context states, counter indices; packed `sf_atomic_cmd_t` / `sf_atomic_rsp_t` (documentation / testbench use; no synthesizable module consumes a struct) |
| `sf_atomic_alu.sv` | combinational read-modify-write function (§6) |
| `sf_atomic_queue.sv` | per-client bounded queues, round-robin start scheduling, in-order completion delivery |
| `sf_atomic_lock_table.sv` | one lock entry per context, key = address granule; hold-off / reservation fairness |
| `sf_atomic_ordering.sv` | owner of the memory master port, ordinary port, response routing (§8, §10) |
| `sf_atomic_coh_agent.sv` | one-line coherent agent of the CoherenceDirectory (§11) |
| `sf_atomic_perf.sv` | counters (§13) |
| `sf_atomic_engine.sv` | ingress validation, contexts, scheduling eligibility, write-back, events, diagnostics |

## 2. Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `NC` | 4 | clients = completion ports (≤ 15) |
| `QD` | 4 | queue entries per client (power of two ≥ 2) |
| `NCTX` | 2 | execution contexts = **address locks held in parallel** (1 … 15). `NCTX = 1` is the "single lock" configuration (§9) |
| `AW`, `TAGW`, `RIDW`, `DOMW`, `OIDW` | 32, 8, 4, 2, 4 | address, tag, requester-id, domain (2**DOMW domains), ordinary-id widths |
| `OMAX` | 4 | ordinary requests in flight (response FIFO depth, power of two) |
| `LOCK_GRAN` | 3 | lock granule = 2**LOCK_GRAN bytes: **3 = 8-byte memory word** (default), **6 = 64-byte cache line** (3 … 12) |
| `OP_EN` | `16'h07FE` | bit *i* enables opcode *i* (1 … 10); a disabled opcode is rejected `AST_OP` (phase 1 = FADD + CAS = `16'h0404`) |
| `W64_EN` | 1 | 64-bit operations (0 = 32-bit only, `AST_WIDTH` otherwise) |
| `COHERENT`, `AGENT_ID`, `N_AGENTS`, `DIR_LINES`, `LINE_BYTES` | 0, 2, 3, 16, 64 | coherent window through the CoherenceDirectory |
| `PERF` | 1 | instantiate the counters (removing them changes no other output) |

## 3. The command structure (mission §3)

One command port per client (flat vectors; client `c` = slice `c`). Valid / ready: a command is accepted at the edge where `cmd_valid && cmd_ready`;
`cmd_ready` never depends on `cmd_valid` (it is `entries < QD`, qualified by the `quiesce_i` and reset inputs). A presented command must be held unchanged until accepted (SFB2 R2).

| Field (port) | Width | Meaning |
|---|---|---|
| **Opcode** `cmd_op` | 4 | `1` SWAP · `2` FADD · `3` FAND · `4` FOR · `5` FXOR · `6` MIN (signed) · `7` MAX (signed) · `8` MINU · `9` MAXU · `10` CAS. `0` and `11 … 15` are rejected |
| **Address** `cmd_addr` | AW | byte address, **naturally aligned** to the width, inside a window |
| **Operand** `cmd_opd` | 64 | addend / mask / replacement value / new value for CAS. A 32-bit operation uses bits [31:0]; **bits [63:32] are ignored** (proved for the ALU) |
| **Compare value** `cmd_cmp` | 64 | CAS only (width-masked); ignored by every other opcode |
| **Data width** `cmd_width` | 2 | `0` = 32-bit, `1` = 64-bit; `2`, `3` rejected (`AST_WIDTH`) |
| **Requester identifier** `cmd_rid` | RIDW | opaque id of the agent behind the port; echoed (`rsp_rid`); the **port index** is the trusted identity (`rsp_src`) |
| **Transaction tag** `cmd_tag` | TAGW | chosen by the client, echoed; must be unique among the client's outstanding commands |
| **Protection domain** `cmd_dom` | DOMW | **claim**; checked against `port_dom_mask` (trusted binding) and by the MemoryGuard verdict |
| **Completion destination** `cmd_dest` | clog2(NC) | client port that receives the completion; allowed only if `dest_allow[c][dest]` (else the completion returns to the issuer with `AST_DEST`) |
| **Ordering hints** `cmd_aq`, `cmd_rl` | 1 + 1 | `rl`: starts only after every older command of this client has committed; `aq`: no younger command of this client starts before this one commits (§10) |

Completion (one channel per destination port, valid / ready, held unchanged until accepted — SFB2 R4):

| Field | Meaning |
|---|---|
| `rsp_old` (64) | the **original** value of the location, zero-extended from the operand width (software sign-extends a 32-bit signed value). `0` on every error except `AST_WRITE` (§7) |
| `rsp_succ` | CAS: compare succeeded. Every other opcode: `1` when `rsp_status == AST_OK`. Always `0` on error |
| `rsp_status` (4) | `AST_*` (§7) |
| `rsp_tag`, `rsp_rid`, `rsp_src` | echoed tag and requester id; issuing client port |

The same fields as packed structs: `sf_atomic_cmd_t`, `sf_atomic_rsp_t` in `sf_atomic_pkg.sv`.

## 4. Static configuration and management

`win_base / win_limit` (uncached window, 8-byte aligned), `coh_base / coh_limit` (coherent window, 64-byte aligned, ≤ `DIR_LINES × 64`),
`port_dom_mask[c][d]` (port *c* may act for domain *d*), `dest_allow[c][d]`, `atom_prot_i` (MemoryMatrix `prot` of the engine's own requests),
`quiesce_i` / `idle_o`, `cfg_err_o`, `diag_*` (latest rejected command: client, status, address; `diag_clr_i`), `perf_*`. All are management-plane signals (R4).

## 5. Validation (mission §8) — precedence and effect

Performed when the command is accepted; the result is stored with the entry. First failing check wins:

| # | Check | Status | Notes |
|---|---|---|---|
| 1 | opcode in 1 … 10 and enabled in `OP_EN` | `AST_OP` | |
| 2 | width 0, or 1 with `W64_EN` | `AST_WIDTH` | operand width |
| 3 | natural alignment (4 / 8 bytes) | `AST_ALIGN` | the engine never splits an atomic (a split would not be single-copy atomic: MemoryMatrix M4) |
| 4 | address inside the uncached window or (COHERENT) the coherent window | `AST_RANGE` | address bounds / "invalid address" |
| 5 | domain claim bound to this port | `AST_DOMAIN` | domain ownership |
| 6 | destination allowed | `AST_DEST` | completion goes to the issuer |
| 7 | **read AND write** permission: `grd_ok_r && grd_ok_w` for `{addr, len, dom}` | `AST_PERM` | read permission and write permission, whole range in one region |

**A rejected command is stored already DONE**: it never reaches the scheduler, takes no lock, makes no memory or coherence request, and still completes
**in order** with its status. *Denied operations cause no memory modification* is therefore structural (queue property Q3, engine properties X2 / X4) and also
checked at the memory port by every regression run.

## 6. Operations (mission §2) — exact semantics

All operations work on the operand **width** (32 or 64 bits); the unused upper operand bits of a 32-bit operation are ignored; a 32-bit result is zero-extended.

| Op | Memory ← | Returns | Notes |
|---|---|---|---|
| SWAP | `opd` | old | always writes |
| FADD | `old + opd` mod 2**w | old | **wraps** (32 / 64 bit); no trap, no overflow flag |
| FAND / FOR / FXOR | `old & / \| / ^ opd` | old | always write |
| MIN / MAX | smaller / larger of `old`, `opd` | old | **signed** two's complement **at the operand width** |
| MINU / MAXU | smaller / larger | old | **unsigned** |
| CAS | `opd` **iff** `old == cmp` (width-masked), else **no write** | old, `succ` | a failed CAS makes no write and is not an error |

Every operation except a failed CAS writes its result even when it equals the old value (uniform ECC / coherence behaviour). Proved: `sf_atomic_alu` equals this
specification for **all inputs** (`formal/fv_alu.sv`, unbounded), and equals the Python model on 34 896 edge / random vectors (`tb/tb_sf_atomic_alu.sv`).

## 7. Completion status and retry rule (mission §10)

| Code | Name | Cause | Effect on memory | May be retried? |
|---|---|---|---|---|
| 0 | `AST_OK` | executed (CAS failure is still OK, `succ = 0`) | as defined | n/a |
| 1 | `AST_OP` | reserved / disabled opcode | none | only after fixing the command |
| 2 | `AST_WIDTH` | unsupported width | none | after fixing |
| 3 | `AST_ALIGN` | misaligned | none | after fixing |
| 4 | `AST_RANGE` | address outside the atomic window(s) | none | after fixing |
| 5 | `AST_DOMAIN` | claim not bound to the port | none | after fixing |
| 6 | `AST_DEST` | destination not allowed | none | after fixing (the completion came to the issuer) |
| 7 | `AST_PERM` | MemoryGuard denied read or write | none | only after the policy changes |
| 8 | `AST_READ` | memory read failed (error response) | **none** (nothing was written) | **yes** — safe |
| 9 | `AST_WRITE` | memory write failed | **indeterminate** | **no, not blindly**: read the location back first (`rsp_old` is the value read, valid but not proof of the final state) |
| 10 | `AST_COH` | coherence agent failed (unexpected grant / outside the directory) | **indeterminate** | no, not blindly |
| — | queue saturation | `cmd_ready = 0` (flow control; nothing dropped) | none | n/a — present again |
| — | reset | no completion for unfinished commands | a write accepted before the reset **persists** | see §14 |

**The engine never re-executes an operation by itself**: there is no internal retry path. *Never silently execute a failed atomic operation twice* holds structurally;
the testbenches additionally check that no (client, tag) commits twice.

## 8. Atomicity mechanism (mission §4) and the linearisation point

An accepted, valid command is executed by a context:

```
 grant ──► lock the granule ──► READ (memory port) ──► response ──► ALU ──► WRITE (memory port) ──► write response ──► write-back ──► unlock
 (key free, no ordinary write waiting, context free)    old value      new, succ, wr      commit = write accepted
```

* **Acquire exclusive access.** The lock-table entry of the context is written at the same clock edge as the grant; the read request is made at the earliest one cycle later.
  The grant condition is evaluated in the grant cycle on the registered lock table and on the ordinary request of that cycle: *no entry holds the key, no ordinary write that is waiting for it or already presented to memory*.
* **Read old value / compute / commit / release.** The context holds its request stable (SFB2 R2), waits for the response, applies the shared ALU
  in the response cycle, requests the write, waits for its response, then releases the lock **after** the write response (so that even a memory whose visibility point
  were its completion cannot expose a later access to a half-done update).
* **Linearisation point (LP).** *For an operation that writes:* the edge at which the **memory accepts the write request** (`ev_c_valid && ev_c_wrote`). *For a failed CAS:*
  the edge at which the read response is consumed (`ev_c_wrote = 0`; the lock guarantees nothing could change the word in between). *For the coherent window:* the edge at which the
  line is granted in M and the ALU is applied (§11). The value returned is the value read under the lock, which is the value of the location at the LP.
* **Exclusivity argument.** Between a context's read acceptance and its LP no write to its granule can be accepted by the memory, because
  (a) every memory request of a context is made while that context's lock holds the granule of its address [X2: whole-engine bounded check + in-RTL assertion in every regression run];
  (b) no two valid lock entries ever hold the same key [L1, **unbounded** proof under the engine's acquire discipline];
  (c) an ordinary write is accepted by the memory only when no lock holds its granule [X1: whole-engine bounded check + in-RTL assertion in every regression run];
  (d) a context writes only in its write state and only after its own read response succeeded [X4: same evidence as X2];
  (e) every other master is excluded by integration rule R1.
  Hence the old value equals the memory content at the LP and the new value is committed without an intervening write: the committed operations, ordered by LP, are a valid
  serial execution. The testbench checks (a)–(d) independently at the memory port and by replaying every LP through the sequential reference model.
* **Do not treat two bus transactions as atomic.** Nothing in the design relies on the read and the write being adjacent on the bus; the testbench's negative control
  (`+test=naive`) shows the naive read-then-write sequence losing 100 of 200 increments on the very memory model the engine runs on.

## 9. Lock granularity and throughput (mission §5)

* **Granule**: `LOCK_GRAN = 3` → one lock per **8-byte memory word** (the unit of single-copy atomicity in MemoryMatrix); `LOCK_GRAN = 6` → one lock per **64-byte cache line**
  (use with the coherent window or when ordinary stores of the whole line must be excluded). An ordinary write of 1 … 8 aligned bytes blocks if its word's (line's) granule is locked.
  The engine never locks the memory subsystem: other words stay fully accessible to ordinary traffic and to the other contexts.
* **Parallelism**: `NCTX` locks are held at once (one per context). Two operations on the **same** granule are serialised; on different granules they overlap in the
  memory pipeline. With `NCTX = 1` this degenerates to **one operation at a time (a single lock)**: throughput ≤ 1 / (lock hold time) operations per cycle,
  documented in `reports/bench.md`.
* **Hard limit**: the engine owns **one** memory master port: ≤ 1 request per cycle, 2 requests per writing atomic ⇒ **≤ 0.5 atomic operations per cycle** regardless of `NCTX`.
* **Head-of-line**: each client starts its commands in order, so a head command waiting for a lock delays its client's later commands (other clients are not delayed).
* **Contention**: same-granule operations are serialised in round-robin order of clients; a saturated single counter runs at one operation per lock-hold time.

## 10. Memory ordering (mission §6)

**Ordering scope, stated exactly:**

| Pair of accesses | Guarantee |
|---|---|
| atomic ↔ atomic, same granule (any clients) | totally ordered by their LPs; each sees the previous one's result |
| atomic ↔ atomic, different granules | no relative order **unless** the same client uses `aq` / `rl` |
| atomic ↔ **ordinary write**, same granule | serialised: the write is accepted before the lock is taken or after it is released, never inside the window; alternation rule guarantees neither side starves (§13) |
| atomic ↔ **ordinary read**, same granule | the read returns the value before the LP or the value after it (never a partial result: one word access is single-copy atomic). Reads are **not held** by locks |
| atomic ↔ ordinary access, different granule | no interaction except arbitration of the single memory port (round robin) |
| **DMA** requests | ordinary accesses: through the ordinary port, same rules as a CPU store; a DMA must wait for its write acknowledgements (SFB2 R7) before signalling an atomic flag |
| commands of one client | start **in order**; complete (are delivered) **in order**; same-granule commands are also committed in order; different granules may commit out of order |
| `rl` | the command starts only after every older command of the client has **completed its write-back** (committed) — release semantics for the client's earlier atomics |
| `aq` | no younger command of the client starts before this one has completed its write-back — acquire semantics |
| `quiesce_i` → `idle_o` | **full fence** between the engine and everything around it: new commands and new ordinary requests are blocked, everything queued or in flight drains |
| coherent window | an atomic cannot bypass coherence: the directory removes every other copy before the ALU runs (§11) |

**What is *not* claimed.** Not a RISC-V memory model: there are no `fence` instructions to implement (the ControlCore has no A extension and its CPU data port is a plain
SFB2 master), no `lr` / `sc`, no total store order across clients, no ordering between a client's atomics and its own ordinary stores unless software waits for the
acknowledgements. `aq` / `rl` are *ordering hooks among the engine's own commands*, not a claim of RVWMO `.aq` / `.rl` compliance.

## 11. Cache coherence (mission §7)

* **Before / without coherence** (`COHERENT = 0`): atomics are limited to the documented uncached window (rule R6); `cmd` addresses outside it are `AST_RANGE`.
* **With coherence** (`COHERENT = 1`): addresses of the coherent window are executed by `sf_atomic_coh_agent`, an agent of the CoherenceDirectory protocol:
  `RQ_GETM` → (directory invalidates sharers, or takes the dirty line from the owner through FWD_M) → `GN_DATA_M` with the line → **ALU applied in the grant cycle**
  (perform-on-grant: no snoop can intervene) → `RS_COMPLETE` → `RQ_PUTM` (write-back of the modified line, ownership dropped) → `GN_PUTACK` → completion.
  After the operation the engine holds **no** copy, so no stale copy can exist anywhere; memory holds the new value; completion is reported only after `PUTACK`.
  Races follow P107 §6: while the PUTM is outstanding the line sits in an eviction buffer that still answers `FWD_S / FWD_M` (`keep = 0`, the directory then treats the PUTM
  as stale); `INV` for a line the agent does not hold is acknowledged.
* **Ordinary port** access to the coherent window is refused (`OST_COHWIN`); non-coherent masters must follow P107's hand-over rules (docs/05 N1–N8) for the window.
* **Limits**: one coherent operation at a time; one GETM + one PUTM round trip per operation (an agent that retained ownership would be faster — not implemented);
  the coherent path was simulated against the real directory with two real P107 cache agents (`VERIFICATION.md` §5), not formally proved; N_AGENTS = 3 is a simulated, not a formally checked, configuration of P107.

## 12. Protection (mission §8)

Layers, outermost first: **(1)** physical port = identity (R8); **(2)** domain claim ∈ `port_dom_mask[port]`; **(3)** MemoryGuard verdict for READ **and** WRITE of the whole
operand; **(4)** window and alignment checks inside the engine; **(5)** the memory's own checks (status → `AST_READ` / `AST_WRITE`). A rejected command has no side effect (§5).
Policy updates use the drain rule (R5). `cfg_err_o` flags illegal window registers (the window is then treated as empty).
The hook is a **combinational verdict per port**, like MemoryGuard's checker; MemoryGuard's inline port, which holds requests until its decision, can be used equally if a registered
verdict is preferred (the verdict is sampled in the acceptance cycle).

## 13. Fairness and measurement (mission §9)

* **Bounded request queue**: `QD` entries per client; exact back-pressure (`cmd_ready = entries < QD`); no drop, no duplicate (queue properties Q1, Q2 proved).
* **Round-robin scheduling**: the start grant goes to the first eligible head at or after the pointer; the pointer moves past every winner ⇒ a head that stays eligible
  is passed over at most `NC − 1` times (Q8 / Q10 proved; measured max-min spread between saturating clients: `VERIFICATION.md` §6). The memory port is also round robin
  (context requests and the ordinary request), with a **grant lock** (a presented request is never withdrawn).
* **Ordinary writes vs atomics** (no starvation either way): an ordinary write that waits for a lock, or is already presented, blocks the next atomic grant on its granule
  (hold-off); an atomic that was held off by a *presented* ordinary write registers a reservation that blocks the next ordinary write to that granule until the atomic is granted.
  A reservation is never made for a write that merely waits (that combination deadlocks — found by the testbench, `VERIFICATION.md` §7). Measured: longest ordinary wait 6 cycles under
  a saturating atomic stream; 25 atomics complete in 178 cycles under a saturating ordinary writer.
* **Counters** (`perf_o`, 32-bit saturating, `sf_atomic_pkg::PF_*`): queue wait (sum, max), lock-acquisition time (sum, max, contended count), operation latency (sum, max),
  contention (operations that waited for a lock; ordinary-write stall cycles), operations per cycle (`PF_COMMITTED / PF_CYCLES`), stall cycles (ingress, memory port),
  context utilisation, lock occupancy, memory reads / writes by origin. Per-operation timestamps are 16 bits (an operation older than 65 535 cycles wraps its own sample).

## 14. Errors, reset (mission §10)

* **Invalid address / misalignment / unsupported operation / permission**: rejected at ingress (§5); no lock, no memory traffic.
* **Read failure**: `AST_READ`, nothing written, lock released, later operations on the word work. **Write failure**: `AST_WRITE`, location indeterminate.
* **Queue saturation**: flow control only.
* **Reset during operation** (synchronous, `rst_n`): queues, contexts, lock table, ordinary-response FIFO and perf timestamps are cleared in one edge; `cmd_ready`, every `rsp_valid`, `o_rsp_valid` and
  `m_req_valid` are 0 during reset; **no completion is produced for work cancelled by the reset**. A write that the memory accepted before the reset stays written (memory is not reset — M8) and
  the operation's completion is lost: after a reset a client cannot tell whether such an operation executed, **so it must not resubmit it blindly** (read the location, or use idempotent operations).
  An operation whose write had not been accepted never writes: **a reset can never complete a half-executed atomic**. Coherent agent: a line modified but not yet written back by PUTM is lost (as for every P107 agent).

## 15. Phases

| Phase | Configuration | Scope |
|---|---|---|
| 1 | `NCTX=1`, `OP_EN=16'h0404`, `W64_EN=0` | uncached 32-bit FETCH-ADD and COMPARE-AND-SWAP, single lock |
| 2 | `NCTX=1` | + every opcode, 64-bit |
| 3 | `NCTX=2…4` | + parallel address locks; word or line granule |
| 4 | `COHERENT=1` | + CoherenceDirectory integration |

The four phases are one RTL source; each is a parameter set of it, verified with the same test list (`reports/regression.md`).
