#!/usr/bin/env python3
"""Independent sequential reference model of the AtomicEngine operations (executable specification).

Written from docs/03_ATOMICITY.md / sf_atomic_alu.sv's header contract only, with Python integers and explicit two's-complement
conversion -- no shared code or construction with the RTL (which uses an offset-binary signed compare) or with the SystemVerilog
testbench (which uses sign-extension and $signed).  Used for:
  * `gen_vectors`  : an exhaustive edge-value cross product plus random vectors for tb/tb_sf_atomic_alu.sv (ALU replay),
  * `serial_check` : a pure-software linearisation checker for a trace of committed operations (used by the self test).

Semantics (the whole contract)
  width 32 or 64; operands reduced to the width; FADD wraps; MIN/MAX signed, MINU/MAXU unsigned; SWAP stores opd;
  FAND/FOR/FXOR bitwise; CAS stores opd iff old == cmp and writes NOTHING otherwise; returned value is always the ORIGINAL value;
  succ = (old == cmp) for CAS, 1 for every other valid op.
"""
import random, sys

SWAP, FADD, FAND, FOR, FXOR, MIN, MAX, MINU, MAXU, CAS = range(1, 11)
NAMES = {SWAP: "SWAP", FADD: "FADD", FAND: "FAND", FOR: "FOR", FXOR: "FXOR", MIN: "MIN", MAX: "MAX", MINU: "MINU", MAXU: "MAXU", CAS: "CAS"}

def signed(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v

def apply(op, wide, old, opd, cmp_):
    """-> (new, succ, wrote, opok)   all values already reduced to the operand width"""
    bits = 64 if wide else 32
    m = (1 << bits) - 1
    o, a, c = old & m, opd & m, cmp_ & m
    if op == SWAP: return a, 1, 1, 1
    if op == FADD: return (o + a) & m, 1, 1, 1
    if op == FAND: return o & a, 1, 1, 1
    if op == FOR:  return o | a, 1, 1, 1
    if op == FXOR: return o ^ a, 1, 1, 1
    if op == MIN:  return (o if signed(o, bits) < signed(a, bits) else a), 1, 1, 1
    if op == MAX:  return (o if signed(o, bits) > signed(a, bits) else a), 1, 1, 1
    if op == MINU: return (o if o < a else a), 1, 1, 1
    if op == MAXU: return (o if o > a else a), 1, 1, 1
    if op == CAS:
        if o == c: return a, 1, 1, 1
        return o, 0, 0, 1
    return o, 0, 0, 0

EDGES32 = [0, 1, 2, 0x7FFFFFFE, 0x7FFFFFFF, 0x80000000, 0x80000001, 0xFFFFFFFE, 0xFFFFFFFF, 0x0000FFFF, 0x00010000, 0x55555555, 0xAAAAAAAA]
EDGES64 = EDGES32 + [0x100000000, 0x7FFFFFFFFFFFFFFE, 0x7FFFFFFFFFFFFFFF, 0x8000000000000000, 0x8000000000000001,
                     0xFFFFFFFF00000000, 0xFFFFFFFFFFFFFFFE, 0xFFFFFFFFFFFFFFFF, 0x5555555555555555, 0xAAAAAAAAAAAAAAAA, 0x00000000FFFFFFFF]

def gen_vectors(n_random=20000, seed=7):
    rnd = random.Random(seed)
    vecs = []
    for op in range(0, 16):
        for wide in (0, 1):
            edges = EDGES64 if wide else EDGES32
            if op == CAS:
                trip = [(o, a, c) for o in edges for a in edges[::2] for c in edges]
            elif 1 <= op <= 9:
                trip = [(o, a, 0) for o in edges for a in edges]
            else:
                trip = [(edges[i % len(edges)], edges[(i * 3) % len(edges)], 0) for i in range(8)]
            for (o, a, c) in trip:
                # upper garbage in 32-bit operands must be ignored: fill the unused upper half with noise
                noise = lambda: rnd.getrandbits(32) << 32
                oo = o | (0 if wide else noise()); aa = a | (0 if wide else noise()); cc = c | (0 if wide else noise())
                vecs.append((op, wide, oo, aa, cc))
    for _ in range(n_random):
        op = rnd.choice(list(range(1, 11)) * 4 + [0, 11, 12, 13, 14, 15]); wide = rnd.getrandbits(1)
        o, a = rnd.getrandbits(64), rnd.getrandbits(64)
        c = o if (op == CAS and rnd.random() < 0.5) else rnd.getrandbits(64)
        vecs.append((op, wide, o, a, c))
    return vecs

def write_vectors(path):
    """8 x 64-bit hex words per vector: op, wide, old, opd, cmp, new, succ, wr   (opok folded into wr/succ = 0 and op field)"""
    vecs = gen_vectors()
    with open(path, "w") as f:
        for (op, wide, o, a, c) in vecs:
            new, succ, wr, ok = apply(op, wide, o, a, c)
            for w in (op, wide, o, a, c, new, succ | (ok << 1), wr):
                f.write(f"{w:016x}\n")
        for _ in range(8):                       # end-of-file sentinel vector (all ones)
            f.write("f" * 16 + "\n")
    return len(vecs)

def serial_check(trace):
    """trace: list of dict(addr, op, wide, opd, cmp, old, new, succ, wrote) in commit order; initial memory 0 (or 'init' dict).
    Returns (ok, message).  A trace is linearisable iff replaying it sequentially reproduces every old / new / succ / wrote."""
    mem = {}
    for i, t in enumerate(trace):
        w = t["addr"] >> 3; sh = 32 if (not t["wide"] and (t["addr"] & 4)) else 0
        cur = mem.get(w, 0)
        o = (cur >> sh) & ((1 << (64 if t["wide"] else 32)) - 1)
        new, succ, wr, ok = apply(t["op"], t["wide"], o, t["opd"], t["cmp"])
        if o != t["old"]: return False, f"op {i}: old {t['old']:#x} but memory holds {o:#x}"
        if succ != t["succ"] or wr != t["wrote"]: return False, f"op {i}: succ/wrote mismatch"
        if wr:
            if new != t["new"]: return False, f"op {i}: new {t['new']:#x} != {new:#x}"
            mask = ((1 << (64 if t["wide"] else 32)) - 1) << sh
            mem[w] = (cur & ~mask) | ((new << sh) & mask)
    return True, "linearisable"

def self_test():
    # tickets: N increments of one counter in ANY commit order are linearisable only if the olds are 0..N-1 in order
    tr = [dict(addr=0x1000, op=FADD, wide=0, opd=1, cmp=0, old=i, new=i + 1, succ=1, wrote=1) for i in range(50)]
    assert serial_check(tr)[0]
    tr[10]["old"] = 11                      # a lost update
    assert not serial_check(tr)[0]
    # 32-bit halves are independent
    tr = [dict(addr=0x1000, op=FADD, wide=0, opd=0xFFFFFFFF, cmp=0, old=0, new=0xFFFFFFFF, succ=1, wrote=1),
          dict(addr=0x1004, op=FADD, wide=0, opd=5, cmp=0, old=0, new=5, succ=1, wrote=1),
          dict(addr=0x1000, op=FADD, wide=0, opd=1, cmp=0, old=0xFFFFFFFF, new=0, succ=1, wrote=1),
          dict(addr=0x1000, op=FADD, wide=1, opd=0, cmp=0, old=0x500000000, new=0x500000000, succ=1, wrote=1)]
    ok, msg = serial_check(tr); assert ok, msg
    # CAS failure writes nothing
    tr = [dict(addr=8, op=CAS, wide=1, opd=9, cmp=1, old=0, new=0, succ=0, wrote=0)]
    assert serial_check(tr)[0]
    # signed vs unsigned
    assert apply(MIN, 0, 0x80000000, 1, 0)[0] == 0x80000000 and apply(MINU, 0, 0x80000000, 1, 0)[0] == 1
    assert apply(MAX, 1, 0xFFFFFFFFFFFFFFFF, 0, 0)[0] == 0 and apply(MAXU, 1, 0xFFFFFFFFFFFFFFFF, 0, 0)[0] == 0xFFFFFFFFFFFFFFFF
    assert apply(FADD, 0, 0xFFFFFFFF, 1, 0)[0] == 0 and apply(FADD, 1, 0xFFFFFFFFFFFFFFFF, 1, 0)[0] == 0
    print("sf_atomic_ref self test: OK")

if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "vectors":
        print(f"{write_vectors(sys.argv[2])} vectors -> {sys.argv[2]}")
    else:
        self_test()
