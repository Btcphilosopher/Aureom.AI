// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine testbench :: sf_atomic_mem_model
//
// Behavioural memory that implements the MemoryMatrix (P101) master-port CONTRACT the engine relies on:
//   * one request accepted per cycle at most, req_ready independent of req_valid (random back-pressure, registered);
//   * a request accepted at edge t observes every write accepted at an earlier edge (acceptance-order visibility): the array
//     is read / written AT the acceptance edge;
//   * RELATIVE byte lanes: byte j < 2**size of the request is the byte at addr + j, lanes above are 0 on reads;
//   * one response per accepted request, in acceptance order, ids echoed, latency LAT + random extra cycles, responses held
//     until accepted; errors: address outside the array -> status 1 (RANGE), no side effect; injected read / write errors
//     -> status 3 (ECC_UE), no side effect for the injected write error (the TB can select "side effect" too);
//   * rdata = 0 on errors and on writes.
//
// The model is deliberately NOT atomic across requests: two separate requests can interleave freely.  A negative-control test
// (tb: +test=naive) shows that a read-then-write pair from two masters loses updates on this very model.
// =============================================================================
`default_nettype none

module sf_atomic_mem_model #(
  parameter int AW    = 32,
  parameter int MIDW  = 4,
  parameter int WORDS = 2048,                 // 8-byte words
  parameter int LAT   = 1,                    // minimum response latency (cycles after acceptance), >= 1
  parameter int DEPTH = 16                    // outstanding responses the model can hold
) (
  input  wire              clk,
  input  wire              rst_n,
  input  wire              req_valid,
  output wire              req_ready,
  input  wire              req_we,
  input  wire [AW-1:0]     req_addr,
  input  wire [2:0]        req_size,
  input  wire [63:0]       req_wdata,
  input  wire [7:0]        req_be,
  input  wire [MIDW-1:0]   req_id,
  input  wire [1:0]        req_prot,
  output wire              rsp_valid,
  input  wire              rsp_ready,
  output wire [63:0]       rsp_rdata,
  output wire [MIDW-1:0]   rsp_id,
  output wire              rsp_we,
  output wire [3:0]        rsp_status,
  // knobs (static during a test)
  input  wire [7:0]        rdy_pct,           // probability (percent, 0..100) that req_ready is 1 in a cycle
  input  wire [7:0]        lat_extra_pct,     // probability that a response gets extra latency cycles
  input  wire [3:0]        lat_extra_max,
  input  wire              inj_rd_en,         // read of word inj_rd_word fails (status 3)
  input  wire [31:0]       inj_rd_word,
  input  wire              inj_wr_en,         // write to word inj_wr_word fails (status 3, no side effect)
  input  wire [31:0]       inj_wr_word
);
  localparam int WIDX = $clog2(WORDS);

  reg [63:0] mem [0:WORDS-1];

  // ---------------------------------------------------------------- pseudo random (xorshift32), cycle accurate and deterministic
  reg [31:0] rs;
  function automatic [31:0] xs(input [31:0] x);
    reg [31:0] y;
    begin
      y = x;
      y = y ^ (y << 13);
      y = y ^ (y >> 17);
      y = y ^ (y << 5);
      xs = y;
    end
  endfunction

  // ---------------------------------------------------------------- response queue
  reg [63:0]       q_data [0:DEPTH-1];
  reg [MIDW-1:0]   q_id   [0:DEPTH-1];
  reg              q_we   [0:DEPTH-1];
  reg [3:0]        q_st   [0:DEPTH-1];
  integer          q_due  [0:DEPTH-1];
  integer          q_h, q_t, q_n;
  integer          cyc;

  reg rdy_r;
  assign req_ready = rdy_r && rst_n && (q_n < DEPTH);

  wire acc = req_valid && req_ready;

  wire [WIDX-1:0] widx = req_addr[WIDX+2:3];
  wire [2:0]      boff = req_addr[2:0];
  wire            in_range = (req_addr[AW-1:3] < WORDS);

  // read / write functions on a word with relative lanes
  function automatic [63:0] do_read(input [63:0] w, input [2:0] off, input [2:0] size);
    reg [63:0] r;
    reg [63:0] sh;
    begin
      sh = w >> (8 * off);
      case (size)
        3'd0: r = {56'd0, sh[7:0]};
        3'd1: r = {48'd0, sh[15:0]};
        3'd2: r = {32'd0, sh[31:0]};
        default: r = sh;
      endcase
      do_read = r;
    end
  endfunction

  function automatic [63:0] do_write(input [63:0] w, input [2:0] off, input [2:0] size, input [63:0] d, input [7:0] be);
    reg [63:0] r;
    begin
      r = w;
      for (int j = 0; j < 8; j++)
        if ((j < (1 << size)) && be[j] && ((off + j) < 8)) r[8*(off+j) +: 8] = d[8*j +: 8];
      do_write = r;
    end
  endfunction

  reg [3:0]  st_n;
  reg [63:0] rd_n;
  integer    due_n;
  always @(posedge clk) begin
    if (!rst_n) begin
      q_h <= 0; q_t <= 0; q_n <= 0;
      rs  <= 32'h1234_5678 ^ 32'(WORDS);
      rdy_r <= 1'b0;
      cyc <= 0;
    end else begin
      cyc <= cyc + 1;
      rs  <= xs(rs);
      rdy_r <= (rs[7:0] % 100) < rdy_pct;

      // ---- accept: array access at the acceptance edge
      if (acc) begin
        st_n = 4'd0;
        rd_n = 64'd0;
        if (!in_range) st_n = 4'd1;
        else if (!req_we && inj_rd_en && (32'(widx) == inj_rd_word)) st_n = 4'd3;
        else if (req_we && inj_wr_en && (32'(widx) == inj_wr_word)) st_n = 4'd3;
        if (st_n == 4'd0) begin
          if (req_we) mem[widx] <= do_write(mem[widx], boff, req_size, req_wdata, req_be);
          else rd_n = do_read(mem[widx], boff, req_size);
        end
        due_n = cyc + LAT + (((rs[15:8] % 100) < lat_extra_pct) ? (1 + (rs[19:16] % (lat_extra_max + 1))) : 0);
        // in-order: a response is never due before the one ahead of it
        if (q_n > 0 && due_n < q_due[(q_t + DEPTH - 1) % DEPTH]) due_n = q_due[(q_t + DEPTH - 1) % DEPTH];
        q_data[q_t] <= (st_n == 4'd0 && !req_we) ? rd_n : 64'd0;
        q_id  [q_t] <= req_id;
        q_we  [q_t] <= req_we;
        q_st  [q_t] <= st_n;
        q_due [q_t] <= due_n;
        q_t <= (q_t + 1) % DEPTH;
      end

      // ---- response handshake
      if (rsp_valid && rsp_ready) q_h <= (q_h + 1) % DEPTH;
      q_n <= q_n + (acc ? 1 : 0) - ((rsp_valid && rsp_ready) ? 1 : 0);
    end
  end

  // a response is never visible in its acceptance cycle: q_n counts only entries committed at an earlier edge
  assign rsp_valid  = rst_n && (q_n > 0) && (cyc >= q_due[q_h]);
  assign rsp_rdata  = q_data[q_h];
  assign rsp_id     = q_id[q_h];
  assign rsp_we     = q_we[q_h];
  assign rsp_status = q_st[q_h];

  wire _unused = &{1'b0, req_prot};

  // image access for the testbench
  task automatic poke(input integer w, input [63:0] v);
    mem[w] = v;
  endtask
  function automatic [63:0] peek(input integer w);
    peek = mem[w];
  endfunction
endmodule

`default_nettype wire
