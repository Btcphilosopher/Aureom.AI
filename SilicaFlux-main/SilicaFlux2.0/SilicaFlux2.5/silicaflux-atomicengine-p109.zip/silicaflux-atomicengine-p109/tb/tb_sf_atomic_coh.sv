// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: coherence system testbench  (Verilator --binary --timing)
//
// REAL CoherenceDirectory (Project 107, vendored unmodified in third_party/coherence_p107) with N_AGENTS = 3 caching agents:
//     agent 0, agent 1 : P107's own sf_coherence_agent_adapter (a small MSI cache each; CPU ops LOAD / STORE / AMO / FLUSH / FENCE)
//     agent 2          : the AtomicEngine's coherent path (sf_atomic_coh_agent inside sf_atomic_engine, COHERENT = 1)
//   behind a shared memory model (P107 sf_coh_mem_model).  The engine's uncached window sits on its own memory (sf_atomic_mem_model).
//
// CHECKED
//   * a GOLDEN cache-line image: every operation PERFORMED by any agent (the adapters' ev_perf_* events at their perform edge; the
//     engine's commit events at its perform-on-grant edge) must find the line exactly as the golden image holds it, and the golden image
//     takes the operation's result.  A stale copy, a lost update, a missed invalidation or a bypassed coherence action makes an old value
//     differ.  Engine operations are recomputed with the independent reference function (same construction as tb_sf_atomic_engine).
//   * completions: status OK, old value equals the commit event's, one per command, in order.
//   * at the end: every agent FLUSHes every line (dirty data written back), then the shared memory equals the golden image.
//   * no protocol error flag of the directory or of the adapters; the engine's coherence path reports no error.
//   * negative control: coh_naive uses the UNCACHED window path on a coherent line to show that bypassing coherence leaves a stale copy.
// Tests (+test=): coh_directed coh_random coh_stress coh_naive
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_atomic_coh;
  parameter int NC         = 2;
  parameter int QD         = 4;
  parameter int NCTX       = 2;
  parameter int DIR_LINES  = 16;
  parameter int CACHE_SETS = 4;
  parameter int MEMREADY   = 100;
  parameter int NA         = 3;            // agents: 0, 1 = CPU caches, 2 = engine
  localparam int AW   = 32;
  localparam int TAGW = 8;
  localparam int RIDW = 4;
  localparam int DOMW = 2;
  localparam int ND   = 4;
  localparam int OIDW = 4;
  localparam int OMAX = 4;
  localparam int LOCK_GRAN = 6;
  localparam int CLW  = (NC > 1) ? $clog2(NC) : 1;
  localparam int CXW  = (NCTX > 1) ? $clog2(NCTX) : 1;
  localparam int OW   = $clog2(OMAX);
  localparam int IDW  = (CXW > OW) ? CXW : OW;
  localparam int MIDW = IDW + 1;
  localparam int LIW  = $clog2(DIR_LINES);
  localparam int LB   = 512;
  localparam int KEYW = AW - LOCK_GRAN;
  localparam int PF_N = sf_atomic_pkg::PF_N;
  localparam [31:0] CBASE = 32'h8000_0000;
  localparam [31:0] CLIM  = 32'h8000_0000 + DIR_LINES * 64;
  localparam [31:0] UBASE = 32'h0000_1000;
  localparam [31:0] ULIM  = 32'h0000_1100;
  localparam int WORDS_U = 1024;

  reg clk = 1'b0;
  reg rst_n = 1'b0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------------ engine ports
  reg  [NC-1:0]       cmd_valid;  wire [NC-1:0] cmd_ready;
  reg  [NC*4-1:0]     cmd_op;     reg [NC*AW-1:0] cmd_addr; reg [NC*64-1:0] cmd_opd, cmd_cmp; reg [NC*2-1:0] cmd_width;
  reg  [NC*RIDW-1:0]  cmd_rid;    reg [NC*TAGW-1:0] cmd_tag; reg [NC*DOMW-1:0] cmd_dom; reg [NC*CLW-1:0] cmd_dest;
  reg  [NC-1:0]       cmd_aq, cmd_rl;
  wire [NC-1:0]       rsp_valid;  reg  [NC-1:0] rsp_ready;
  wire [NC*TAGW-1:0]  rsp_tag;    wire [NC*RIDW-1:0] rsp_rid; wire [NC*CLW-1:0] rsp_src; wire [NC*64-1:0] rsp_old;
  wire [NC-1:0]       rsp_succ;   wire [NC*4-1:0] rsp_status;
  reg                 o_req_valid; wire o_req_ready; reg o_req_we; reg [AW-1:0] o_req_addr; reg [2:0] o_req_size;
  reg  [63:0]         o_req_wdata; reg [7:0] o_req_be; reg [OIDW-1:0] o_req_id; reg [1:0] o_req_prot;
  wire                o_rsp_valid; reg o_rsp_ready; wire [63:0] o_rsp_rdata; wire [OIDW-1:0] o_rsp_id; wire o_rsp_we; wire [3:0] o_rsp_status;
  wire                m_req_valid, m_req_ready, m_req_we; wire [AW-1:0] m_req_addr; wire [2:0] m_req_size; wire [63:0] m_req_wdata;
  wire [7:0]          m_req_be;  wire [MIDW-1:0] m_req_id; wire [1:0] m_req_prot;
  wire                m_rsp_valid, m_rsp_ready, m_rsp_we; wire [63:0] m_rsp_rdata; wire [MIDW-1:0] m_rsp_id; wire [3:0] m_rsp_status;
  wire [NCTX-1:0]      ev_c_valid; wire [NCTX*CLW-1:0] ev_c_client; wire [NCTX*TAGW-1:0] ev_c_tag; wire [NCTX*AW-1:0] ev_c_addr;
  wire [NCTX*4-1:0]    ev_c_op; wire [NCTX-1:0] ev_c_wide; wire [NCTX*64-1:0] ev_c_old, ev_c_new; wire [NCTX-1:0] ev_c_succ, ev_c_wrote, ev_c_coh;
  wire [NCTX-1:0]      lk_valid_o; wire [NCTX*KEYW-1:0] lk_key_o;
  wire [PF_N*32-1:0]   perf_o;
  wire                 idle_w, cfg_err_w, diag_valid_o; wire [CLW-1:0] diag_client_o; wire [3:0] diag_status_o; wire [AW-1:0] diag_addr_o;
  reg                  quiesce_r;

  // coherence channels of the engine (agent 2) and of the directory
  wire [NA-1:0]        d_req_valid, d_req_ready, d_rsp_valid, d_rsp_ready, d_snp_valid, d_snp_ready, d_gnt_valid, d_gnt_ready, d_rsp_keep;
  wire [NA*3-1:0]      d_req_type, d_gnt_type;
  wire [NA*LIW-1:0]    d_req_line, d_rsp_line, d_snp_line, d_gnt_line;
  wire [NA*LB-1:0]     d_req_data, d_rsp_data, d_gnt_data;
  wire [NA*2-1:0]      d_rsp_type, d_snp_type;
  wire                 dm_req_valid, dm_req_ready, dm_req_wr, dm_rsp_valid, dm_rsp_ready;
  wire [LIW-1:0]       dm_req_line; wire [LB-1:0] dm_req_wdata, dm_rsp_rdata;
  wire [DIR_LINES*LB-1:0] mem_flat;
  wire [sf_coherence_pkg::DE_W-1:0] dir_err;
  wire [NA*LB-1:0]     dbg_slot_data_w;

  // ------------------------------------------------------------------ the engine (agent 2)
  sf_atomic_engine #(.NC(NC), .QD(QD), .NCTX(NCTX), .AW(AW), .TAGW(TAGW), .RIDW(RIDW), .DOMW(DOMW), .OIDW(OIDW), .OMAX(OMAX),
                     .LOCK_GRAN(LOCK_GRAN), .OP_EN(16'h07FE), .W64_EN(1), .COHERENT(1), .AGENT_ID(2), .N_AGENTS(NA),
                     .DIR_LINES(DIR_LINES), .LINE_BYTES(64), .PERF(1)) dut (
    .clk(clk), .rst_n(rst_n), .win_base(UBASE), .win_limit(ULIM), .coh_base(CBASE), .coh_limit(CLIM),
    .port_dom_mask({NC*ND{1'b1}}), .dest_allow({NC*NC{1'b1}}), .atom_prot_i(2'b11), .quiesce_i(quiesce_r), .idle_o(idle_w), .cfg_err_o(cfg_err_w),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_op(cmd_op), .cmd_addr(cmd_addr), .cmd_opd(cmd_opd), .cmd_cmp(cmd_cmp), .cmd_width(cmd_width),
    .cmd_rid(cmd_rid), .cmd_tag(cmd_tag), .cmd_dom(cmd_dom), .cmd_dest(cmd_dest), .cmd_aq(cmd_aq), .cmd_rl(cmd_rl),
    .grd_addr_o(), .grd_len_o(), .grd_dom_o(), .grd_ok_r({NC{1'b1}}), .grd_ok_w({NC{1'b1}}),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_tag(rsp_tag), .rsp_rid(rsp_rid), .rsp_src(rsp_src), .rsp_old(rsp_old), .rsp_succ(rsp_succ), .rsp_status(rsp_status),
    .o_req_valid(o_req_valid), .o_req_ready(o_req_ready), .o_req_we(o_req_we), .o_req_addr(o_req_addr), .o_req_size(o_req_size), .o_req_wdata(o_req_wdata),
    .o_req_be(o_req_be), .o_req_id(o_req_id), .o_req_prot(o_req_prot),
    .o_rsp_valid(o_rsp_valid), .o_rsp_ready(o_rsp_ready), .o_rsp_rdata(o_rsp_rdata), .o_rsp_id(o_rsp_id), .o_rsp_we(o_rsp_we), .o_rsp_status(o_rsp_status),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_size(m_req_size), .m_req_wdata(m_req_wdata),
    .m_req_be(m_req_be), .m_req_id(m_req_id), .m_req_prot(m_req_prot),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status),
    .rq_valid(d_req_valid[2]), .rq_ready(d_req_ready[2]), .rq_type(d_req_type[2*3 +: 3]), .rq_line(d_req_line[2*LIW +: LIW]), .rq_data(d_req_data[2*LB +: LB]),
    .rs_valid(d_rsp_valid[2]), .rs_ready(d_rsp_ready[2]), .rs_type(d_rsp_type[2*2 +: 2]), .rs_line(d_rsp_line[2*LIW +: LIW]), .rs_data(d_rsp_data[2*LB +: LB]), .rs_keep(d_rsp_keep[2]),
    .sn_valid(d_snp_valid[2]), .sn_ready(d_snp_ready[2]), .sn_type(d_snp_type[2*2 +: 2]), .sn_line(d_snp_line[2*LIW +: LIW]),
    .gn_valid(d_gnt_valid[2]), .gn_ready(d_gnt_ready[2]), .gn_type(d_gnt_type[2*3 +: 3]), .gn_line(d_gnt_line[2*LIW +: LIW]), .gn_data(d_gnt_data[2*LB +: LB]),
    .ev_c_valid(ev_c_valid), .ev_c_client(ev_c_client), .ev_c_tag(ev_c_tag), .ev_c_addr(ev_c_addr), .ev_c_op(ev_c_op), .ev_c_wide(ev_c_wide),
    .ev_c_old(ev_c_old), .ev_c_new(ev_c_new), .ev_c_succ(ev_c_succ), .ev_c_wrote(ev_c_wrote), .ev_c_coh(ev_c_coh),
    .lk_valid_o(lk_valid_o), .lk_key_o(lk_key_o),
    .diag_clr_i(1'b0), .diag_valid_o(diag_valid_o), .diag_client_o(diag_client_o), .diag_status_o(diag_status_o), .diag_addr_o(diag_addr_o),
    .perf_clr_i(1'b0), .perf_o(perf_o)
  );

  // uncached window memory of the engine
  sf_atomic_mem_model #(.AW(AW), .MIDW(MIDW), .WORDS(WORDS_U), .LAT(1)) umem (
    .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid), .req_ready(m_req_ready), .req_we(m_req_we), .req_addr(m_req_addr), .req_size(m_req_size),
    .req_wdata(m_req_wdata), .req_be(m_req_be), .req_id(m_req_id), .req_prot(m_req_prot),
    .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready), .rsp_rdata(m_rsp_rdata), .rsp_id(m_rsp_id), .rsp_we(m_rsp_we), .rsp_status(m_rsp_status),
    .rdy_pct(8'd100), .lat_extra_pct(8'd0), .lat_extra_max(4'd0), .inj_rd_en(1'b0), .inj_rd_word(32'd0), .inj_wr_en(1'b0), .inj_wr_word(32'd0));

  // ------------------------------------------------------------------ directory, two CPU caches, shared memory
  sf_coherence_directory #(.N_AGENTS(NA), .DIR_LINES(DIR_LINES), .LINE_BYTES(64)) dir (
    .clk(clk), .rst_n(rst_n),
    .req_valid(d_req_valid), .req_ready(d_req_ready), .req_type(d_req_type), .req_line(d_req_line), .req_data(d_req_data),
    .rsp_valid(d_rsp_valid), .rsp_ready(d_rsp_ready), .rsp_type(d_rsp_type), .rsp_line(d_rsp_line), .rsp_data(d_rsp_data), .rsp_keep(d_rsp_keep),
    .snp_valid(d_snp_valid), .snp_ready(d_snp_ready), .snp_type(d_snp_type), .snp_line(d_snp_line),
    .gnt_valid(d_gnt_valid), .gnt_ready(d_gnt_ready), .gnt_type(d_gnt_type), .gnt_line(d_gnt_line), .gnt_data(d_gnt_data),
    .mem_req_valid(dm_req_valid), .mem_req_ready(dm_req_ready), .mem_req_wr(dm_req_wr), .mem_req_line(dm_req_line), .mem_req_wdata(dm_req_wdata),
    .mem_rsp_valid(dm_rsp_valid), .mem_rsp_ready(dm_rsp_ready), .mem_rsp_rdata(dm_rsp_rdata),
    .dbg_dir(), .dbg_slot_state(), .dbg_slot_line(), .dbg_slot_type(), .dbg_slot_busy(), .dbg_slot_waiting(), .dbg_slot_gtype(), .dbg_slot_gk(),
    .dbg_slot_data(dbg_slot_data_w), .dbg_slot_wait(), .dbg_mem_wr_perf(), .dbg_err(dir_err), .perf());

  sf_coh_mem_model #(.DIR_LINES(DIR_LINES), .LINE_BYTES(64), .RD_LAT_MIN(1), .RD_LAT_MAX(3), .WR_LAT_MIN(1), .WR_LAT_MAX(3), .READY_PCT(MEMREADY), .SEED(11), .COH_BASE(CBASE)) cmem (
    .clk(clk), .rst_n(rst_n),
    .l_req_valid(dm_req_valid), .l_req_ready(dm_req_ready), .l_req_wr(dm_req_wr), .l_req_line(dm_req_line), .l_req_wdata(dm_req_wdata),
    .l_rsp_valid(dm_rsp_valid), .l_rsp_ready(dm_rsp_ready), .l_rsp_rdata(dm_rsp_rdata),
    .w_req_valid(1'b0), .w_req_ready(), .w_req_write(1'b0), .w_req_addr(32'd0), .w_req_wdata(32'd0), .w_req_wstrb(4'd0),
    .w_rsp_valid(), .w_rsp_ready(1'b1), .w_rsp_rdata(), .w_rsp_error(), .mem_flat(mem_flat), .st_line_rd(), .st_line_wr());

  // CPU agents 0 and 1
  reg  [1:0]        cpu_req_valid;  wire [1:0] cpu_req_ready;
  reg  [2*3-1:0]    cpu_op;         reg [2*AW-1:0] cpu_addr; reg [2*32-1:0] cpu_wdata; reg [2*4-1:0] cpu_wstrb;
  wire [1:0]        cpu_rsp_valid;  reg  [1:0] cpu_rsp_ready;  wire [2*32-1:0] cpu_rdata; wire [1:0] cpu_rsp_err;
  wire [1:0]        ev_pv, ev_pw;  wire [2*LIW-1:0] ev_pl;  wire [2*32-1:0] ev_pr;  wire [2*LB-1:0] ev_pn, ev_po;
  wire [1:0]        ag_err_unused;
  wire [3-1:0]      ag_err0, ag_err1;
  generate
    for (genvar a = 0; a < 2; a++) begin : g_ag
      wire [CACHE_SETS*2-1:0] dcs; wire [CACHE_SETS*LIW-1:0] dtag; wire [CACHE_SETS*LB-1:0] ddata; wire [2:0] dps; wire [LIW-1:0] dpl; wire dpx; wire [LB-1:0] dpd; wire [1:0] das;
      wire [3-1:0] derr; wire [sf_coherence_pkg::PA_N*32-1:0] dperf; wire [$clog2(LB/32)-1:0] evword;
      sf_coherence_agent_adapter #(.AGENT_ID(a), .N_AGENTS(NA), .DIR_LINES(DIR_LINES), .CACHE_SETS(CACHE_SETS), .LINE_BYTES(64), .ADDR_W(AW), .COH_BASE(CBASE)) ag (
        .clk(clk), .rst_n(rst_n),
        .cpu_req_valid(cpu_req_valid[a]), .cpu_req_ready(cpu_req_ready[a]), .cpu_op(cpu_op[a*3 +: 3]), .cpu_addr(cpu_addr[a*AW +: AW]),
        .cpu_wdata(cpu_wdata[a*32 +: 32]), .cpu_wstrb(cpu_wstrb[a*4 +: 4]),
        .cpu_rsp_valid(cpu_rsp_valid[a]), .cpu_rsp_ready(cpu_rsp_ready[a]), .cpu_rdata(cpu_rdata[a*32 +: 32]), .cpu_rsp_err(cpu_rsp_err[a]),
        .rq_valid(d_req_valid[a]), .rq_ready(d_req_ready[a]), .rq_type(d_req_type[a*3 +: 3]), .rq_line(d_req_line[a*LIW +: LIW]), .rq_data(d_req_data[a*LB +: LB]),
        .rs_valid(d_rsp_valid[a]), .rs_ready(d_rsp_ready[a]), .rs_type(d_rsp_type[a*2 +: 2]), .rs_line(d_rsp_line[a*LIW +: LIW]), .rs_data(d_rsp_data[a*LB +: LB]), .rs_keep(d_rsp_keep[a]),
        .sn_valid(d_snp_valid[a]), .sn_ready(d_snp_ready[a]), .sn_type(d_snp_type[a*2 +: 2]), .sn_line(d_snp_line[a*LIW +: LIW]),
        .gn_valid(d_gnt_valid[a]), .gn_ready(d_gnt_ready[a]), .gn_type(d_gnt_type[a*3 +: 3]), .gn_line(d_gnt_line[a*LIW +: LIW]), .gn_data(d_gnt_data[a*LB +: LB]),
        .dbg_cs(dcs), .dbg_tag(dtag), .dbg_data(ddata), .dbg_p_st(dps), .dbg_p_line(dpl), .dbg_p_lost(dpx), .dbg_p_data(dpd), .dbg_a_st(das),
        .ev_perf_v(ev_pv[a]), .ev_perf_wr(ev_pw[a]), .ev_perf_line(ev_pl[a*LIW +: LIW]), .ev_perf_word(evword), .ev_perf_rdata(ev_pr[a*32 +: 32]),
        .ev_perf_newline(ev_pn[a*LB +: LB]), .ev_perf_oldline(ev_po[a*LB +: LB]), .dbg_err(derr), .perf(dperf));
      if (a == 0) assign ag_err0 = derr; else assign ag_err1 = derr;
    end
  endgenerate
  assign ag_err_unused = 2'b00;

  // ------------------------------------------------------------------ golden line image and reference model
  reg [LB-1:0] gl [0:DIR_LINES-1];
  function automatic [31:0] init_word(input integer idx);
    init_word = 32'hC0DE_0000 ^ (idx * 32'h0101_0101) ^ 32'h0000_00A5;
  endfunction
  integer n_errors, n_checks, n_events_cpu, n_events_eng, n_pushed, n_completed;
  task automatic fail(input [8*72-1:0] msg);
    begin n_errors = n_errors + 1; if (n_errors <= 20) $display("[%0t] ERROR: %0s", $time, msg); end
  endtask
  task automatic chk(input bit c, input [8*72-1:0] msg);
    begin n_checks = n_checks + 1; if (!c) fail(msg); end
  endtask

  localparam [3:0] OP_SWAP=1, OP_FADD=2, OP_FAND=3, OP_FOR=4, OP_FXOR=5, OP_MIN=6, OP_MAX=7, OP_MINU=8, OP_MAXU=9, OP_CAS=10;
  task automatic ref_atomic(input [3:0] op, input bit wide, input [63:0] old_v, input [63:0] opd_v, input [63:0] cmp_v,
                            output [63:0] new_v, output bit succ, output bit wr);
    reg [63:0] m, o, a, c; reg signed [63:0] so, sa;
    begin
      m = wide ? 64'hFFFF_FFFF_FFFF_FFFF : 64'h0000_0000_FFFF_FFFF;
      o = old_v & m; a = opd_v & m; c = cmp_v & m;
      so = wide ? $signed(o) : $signed({{32{o[31]}}, o[31:0]}); sa = wide ? $signed(a) : $signed({{32{a[31]}}, a[31:0]});
      new_v = o; succ = 1'b1; wr = 1'b1;
      case (op)
        OP_SWAP: new_v = a;  OP_FADD: new_v = (o + a) & m;  OP_FAND: new_v = o & a;  OP_FOR: new_v = o | a;  OP_FXOR: new_v = o ^ a;
        OP_MIN: new_v = (so < sa) ? o : a;  OP_MAX: new_v = (so > sa) ? o : a;  OP_MINU: new_v = (o < a) ? o : a;  OP_MAXU: new_v = (o > a) ? o : a;
        OP_CAS: begin succ = (o == c); wr = succ; new_v = succ ? a : o; end
        default: begin succ = 1'b0; wr = 1'b0; end
      endcase
    end
  endtask

  // per-(client, tag) commands
  reg        rc_v [0:NC-1][0:255];
  reg [3:0]  rc_op [0:NC-1][0:255];
  reg [31:0] rc_addr [0:NC-1][0:255];
  reg [63:0] rc_opd [0:NC-1][0:255];
  reg [63:0] rc_cmp [0:NC-1][0:255];
  reg        rc_wide [0:NC-1][0:255];
  reg        rc_com [0:NC-1][0:255];
  reg [63:0] rc_old [0:NC-1][0:255];
  reg        rc_succ [0:NC-1][0:255];
  reg        rc_coh [0:NC-1][0:255];
  integer    seq_next [0:NC-1];
  integer    n_coh_commits, n_unc_commits;

  // client command FIFOs and drivers
  localparam int CQ = 2048;
  reg [3:0]  q_op [0:NC-1][0:CQ-1]; reg [31:0] q_addr [0:NC-1][0:CQ-1]; reg [63:0] q_opd [0:NC-1][0:CQ-1]; reg [63:0] q_cmp [0:NC-1][0:CQ-1];
  reg        q_wide [0:NC-1][0:CQ-1]; reg [7:0] q_tag [0:NC-1][0:CQ-1];
  integer    q_hd [0:NC-1]; integer q_tl [0:NC-1]; integer cur [0:NC-1]; reg cv [0:NC-1]; integer gap [0:NC-1];
  integer    gap_pct;

  reg [63:0] rng;
  function automatic [63:0] rnd64(input integer d);
    reg [63:0] x;
    begin x = rng; x = x ^ (x >> 12); x = x ^ (x << 25); x = x ^ (x >> 27); rng = x; rnd64 = x * 64'h2545F4914F6CDD1D; end
  endfunction
  function automatic integer rnd(input integer bound);
    reg [63:0] r;
    begin r = rnd64(0); rnd = (bound <= 1) ? 0 : integer'((r >> 11) % bound); end
  endfunction
  function automatic bit pct(input integer p); pct = (rnd(100) < p); endfunction

  always_comb begin
    for (int c = 0; c < NC; c++) begin
      cmd_valid[c] = cv[c];
      cmd_op[c*4 +: 4] = cv[c] ? q_op[c][cur[c]] : 4'd0;
      cmd_addr[c*AW +: AW] = cv[c] ? q_addr[c][cur[c]] : 32'd0;
      cmd_opd[c*64 +: 64] = cv[c] ? q_opd[c][cur[c]] : 64'd0;
      cmd_cmp[c*64 +: 64] = cv[c] ? q_cmp[c][cur[c]] : 64'd0;
      cmd_width[c*2 +: 2] = cv[c] ? (q_wide[c][cur[c]] ? 2'd1 : 2'd0) : 2'd0;
      cmd_rid[c*RIDW +: RIDW] = RIDW'(c);
      cmd_tag[c*TAGW +: TAGW] = cv[c] ? q_tag[c][cur[c]] : 8'd0;
      cmd_dom[c*DOMW +: DOMW] = DOMW'(c);
      cmd_dest[c*CLW +: CLW] = CLW'(c);
      cmd_aq[c] = 1'b0; cmd_rl[c] = 1'b0;
    end
  end

  task automatic push(input integer c, input [3:0] op, input [31:0] addr, input [63:0] opd, input [63:0] cmp, input bit wide);
    reg [7:0] tg; integer idx;
    begin
      tg = seq_next[c][7:0];
      while (rc_v[c][tg] || ((q_tl[c] - q_hd[c]) >= CQ - 2)) @(posedge clk);
      if (!wide) begin opd = opd | (rnd64(0) << 32); cmp = cmp | (rnd64(0) << 32); end
      idx = q_tl[c] % CQ;
      q_op[c][idx] = op; q_addr[c][idx] = addr; q_opd[c][idx] = opd; q_cmp[c][idx] = cmp; q_wide[c][idx] = wide; q_tag[c][idx] = tg;
      rc_v[c][tg] = 1'b1; rc_op[c][tg] = op; rc_addr[c][tg] = addr; rc_opd[c][tg] = opd; rc_cmp[c][tg] = cmp; rc_wide[c][tg] = wide;
      rc_com[c][tg] = 1'b0; rc_coh[c][tg] = (addr >= CBASE) && (addr < CLIM);
      seq_next[c] = seq_next[c] + 1; q_tl[c] = q_tl[c] + 1; n_pushed = n_pushed + 1;
    end
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin for (int c = 0; c < NC; c++) begin cv[c] <= 1'b0; gap[c] <= 0; end end
    else for (int c = 0; c < NC; c++) begin
      if (cv[c] && cmd_ready[c]) begin cv[c] <= 1'b0; gap[c] <= pct(gap_pct) ? (1 + rnd(5)) : 0; end
      else if (!cv[c]) begin
        if (gap[c] > 0) gap[c] <= gap[c] - 1;
        else if (q_hd[c] != q_tl[c]) begin cur[c] <= q_hd[c] % CQ; q_hd[c] = q_hd[c] + 1; cv[c] <= 1'b1; end
      end
    end
  end

  // completion sink and check
  always @(posedge clk) begin
    if (!rst_n) rsp_ready <= {NC{1'b0}}; else for (int d = 0; d < NC; d++) rsp_ready[d] <= pct(70);
  end
  always @(posedge clk) if (rst_n) begin
    for (int d = 0; d < NC; d++) if (rsp_valid[d] && rsp_ready[d]) begin : cb
      reg [7:0] tg; integer s;
      tg = rsp_tag[d*TAGW +: TAGW]; s = 32'(rsp_src[d*CLW +: CLW]);
      chk(rc_v[s][tg], "completion for a command that is not outstanding");
      if (rc_v[s][tg]) begin
        chk(rsp_status[d*4 +: 4] == 4'd0, "coherent / uncached atomic completed with an error status");
        chk(rc_com[s][tg], "completion without a linearisation event");
        chk(rsp_old[d*64 +: 64] == rc_old[s][tg], "completion old value differs from the value at the linearisation point");
        chk(rsp_succ[d] == rc_succ[s][tg], "completion success flag differs");
        rc_v[s][tg] = 1'b0; n_completed = n_completed + 1;
      end
    end
  end

  // ---- uncached-window golden words (the engine's own memory)
  reg [63:0] gu [0:WORDS_U-1];

  // ---- engine commit events against the golden image
  always @(posedge clk) if (rst_n) begin
    for (int i = 0; i < NCTX; i++) if (ev_c_valid[i]) begin : eb
      integer s; reg [7:0] tg; reg [31:0] a; integer ln, off; reg [63:0] gold, nv; reg sc, wr; reg [63:0] wmask;
      s = 32'(ev_c_client[i*CLW +: CLW]); tg = ev_c_tag[i*TAGW +: TAGW]; a = ev_c_addr[i*AW +: AW];
      chk(rc_v[s][tg], "engine commit event for a command that is not outstanding");
      if (rc_v[s][tg]) begin
        chk(!rc_com[s][tg], "operation committed twice");
        chk(ev_c_coh[i] == rc_coh[s][tg], "commit event flags the wrong path (coherent / uncached)");
        if (rc_coh[s][tg]) begin
          ln = (a - CBASE) >> 6; off = (a - CBASE) & 63;
          gold = rc_wide[s][tg] ? gl[ln][off*8 +: 64] : {32'd0, gl[ln][off*8 +: 32]};
          ref_atomic(rc_op[s][tg], rc_wide[s][tg], gold, rc_opd[s][tg], rc_cmp[s][tg], nv, sc, wr);
          chk(ev_c_old[i*64 +: 64] == gold, "COHERENCE: engine read a value that differs from the golden line (stale copy / lost update)");
          chk(ev_c_succ[i] == sc && ev_c_wrote[i] == wr, "engine success / wrote differs from the reference");
          if (wr) begin
            chk(ev_c_new[i*64 +: 64] == nv, "engine new value differs from the reference");
            if (rc_wide[s][tg]) gl[ln][off*8 +: 64] = nv; else gl[ln][off*8 +: 32] = nv[31:0];
          end
          n_coh_commits = n_coh_commits + 1;
        end else begin
          ln = (a >> 3) % WORDS_U;
          gold = gu[ln];
          if (!rc_wide[s][tg]) gold = {32'd0, gu[ln] >> (8 * (a & 4))};
          if (!rc_wide[s][tg]) gold = gold & 64'hFFFF_FFFF;
          ref_atomic(rc_op[s][tg], rc_wide[s][tg], gold, rc_opd[s][tg], rc_cmp[s][tg], nv, sc, wr);
          chk(ev_c_old[i*64 +: 64] == gold, "uncached old value differs from the golden word");
          if (wr) begin
            if (rc_wide[s][tg]) gu[ln] = nv;
            else begin wmask = 64'h0000_0000_FFFF_FFFF << (8 * (a & 4)); gu[ln] = (gu[ln] & ~wmask) | ((nv << (8 * (a & 4))) & wmask); end
          end
          n_unc_commits = n_unc_commits + 1;
        end
        rc_com[s][tg] = 1'b1; rc_old[s][tg] = ev_c_old[i*64 +: 64]; rc_succ[s][tg] = ev_c_succ[i];
        n_events_eng = n_events_eng + 1;
      end
    end
    // ---- CPU agent perform events
    for (int a = 0; a < 2; a++) if (ev_pv[a]) begin
      chk(ev_po[a*LB +: LB] == gl[ev_pl[a*LIW +: LIW]], "COHERENCE: a CPU agent found a line that differs from the golden line");
      gl[ev_pl[a*LIW +: LIW]] = ev_pn[a*LB +: LB];
      n_events_cpu = n_events_cpu + 1;
    end
  end

  // ------------------------------------------------------------------ CPU drivers
  reg        m_go [0:1];
  reg [2:0]  m_op [0:1];
  reg [31:0] m_addr [0:1];
  reg [31:0] m_wdata [0:1];
  reg [3:0]  m_wstrb [0:1];
  reg dbg = 1'b0;
  initial if ($test$plusargs("dbg")) dbg = 1'b1;
  reg [63:0] r64t;
  integer cpu_pending [0:1];
  reg     cpu_en;
  integer cpu_pct;
  integer cpu_ops_done [0:1];
  integer cpu_lines;                 // lines the CPUs touch (hot set)
  integer cpu_bias_hot;
  always @(posedge clk) begin
    if (!rst_n) begin
      cpu_req_valid <= 2'b00; cpu_rsp_ready <= 2'b11; cpu_pending[0] = 0; cpu_pending[1] = 0; m_go[0] = 1'b0; m_go[1] = 1'b0;
    end else for (int a = 0; a < 2; a++) begin
      cpu_rsp_ready[a] <= pct(80);
      if (cpu_req_valid[a] && cpu_req_ready[a]) cpu_req_valid[a] <= 1'b0;
      if (cpu_rsp_valid[a] && cpu_rsp_ready[a]) begin
        chk(!cpu_rsp_err[a], "CPU agent reported an error response");
        cpu_pending[a] = cpu_pending[a] - 1; cpu_ops_done[a] = cpu_ops_done[a] + 1;
      end
      if (m_go[a] && !cpu_req_valid[a]) begin
        cpu_req_valid[a] <= 1'b1; cpu_op[a*3 +: 3] <= m_op[a]; cpu_addr[a*AW +: AW] <= m_addr[a]; cpu_wdata[a*32 +: 32] <= m_wdata[a]; cpu_wstrb[a*4 +: 4] <= m_wstrb[a];
        m_go[a] = 1'b0;
      end else if (!cpu_req_valid[a] && cpu_pending[a] == 0 && cpu_en && pct(cpu_pct)) begin : gen
        integer k, ln, wd; reg [2:0] op;
        k = rnd(100);
        op = (k < 35) ? 3'd0 : (k < 65) ? 3'd1 : (k < 85) ? 3'd2 : (k < 93) ? 3'd3 : 3'd4;     // LOAD STORE AMO FLUSH FENCE
        ln = pct(cpu_bias_hot) ? rnd(2) : rnd(cpu_lines);
        wd = pct(60) ? rnd(4) : rnd(16);
        cpu_req_valid[a] <= 1'b1; cpu_op[a*3 +: 3] <= op;
        cpu_addr[a*AW +: AW] <= CBASE + ln * 64 + wd * 4;
        r64t = rnd64(0); cpu_wdata[a*32 +: 32] <= r64t[31:0]; cpu_wstrb[a*4 +: 4] <= (rnd(3) == 0) ? 4'(rnd(16)) : 4'hF;
        cpu_pending[a] = 1;
      end
    end
  end

  // ------------------------------------------------------------------ helpers
  task automatic wait_cycles(input integer n); integer k; begin for (k = 0; k < n; k++) @(posedge clk); end endtask

  function automatic bit engine_done(input integer d);
    bit r;
    begin
      r = 1'b1;
      for (int c = 0; c < NC; c++) if (q_hd[c] != q_tl[c] || cv[c]) r = 1'b0;
      if (n_completed != n_pushed) r = 1'b0;
      engine_done = r;
    end
  endfunction

  task automatic drain_all(input integer maxc);
    integer k;
    begin
      k = 0; cpu_en = 1'b0;
      while (!(engine_done(0) && cpu_pending[0] == 0 && cpu_pending[1] == 0 && !cpu_req_valid[0] && !cpu_req_valid[1]) && k < maxc) begin @(posedge clk); k++; end
      if (k >= maxc) begin
        fail("DEADLOCK / timeout while draining");
        $display("  engine: ctx_st=%h idle=%b q_empty=%b completed=%0d pushed=%0d  cpu_pending=%0d/%0d  dir_err=%b", dut.cx_st, idle_w, dut.q_empty, n_completed, n_pushed, cpu_pending[0], cpu_pending[1], dir_err);
        $display("  agent: a_st=%0d p_st=%0d rq_v=%b rs_v=%b  dir req_valid=%b req_ready=%b snp_valid=%b gnt_valid=%b", dut.g_coh.u_ca.a_st, dut.g_coh.u_ca.p_st, d_req_valid[2], d_rsp_valid[2], d_req_valid, d_req_ready, d_snp_valid, d_gnt_valid);
      end
      wait_cycles(20);
    end
  endtask

  // issue one blocking CPU op and wait for it (directed tests; the random CPU generator is off)
  task automatic cpu_op_do(input integer a, input [2:0] op, input [31:0] addr, input [31:0] wdata, input [3:0] wstrb, output [31:0] rdata);
    integer k;
    begin
      m_op[a] = op; m_addr[a] = addr; m_wdata[a] = wdata; m_wstrb[a] = wstrb;
      cpu_pending[a] = 1;
      m_go[a] = 1'b1;
      @(posedge clk);
      k = 0;
      while (cpu_pending[a] != 0 && k < 5000) begin @(posedge clk); k++; end
      rdata = cpu_rdata[a*32 +: 32];
      if (dbg) $display("[%0t] cpu%0d op=%0d addr=%h done after %0d cycles rdata=%h (pending=%0d)", $time, a, op, addr, k, rdata, cpu_pending[a]);
      chk(k < 5000, "CPU operation never completed");
      wait_cycles(2);
    end
  endtask

  task automatic flush_all;
    reg [31:0] dummy;
    begin
      for (int a = 0; a < 2; a++)
        for (int ln = 0; ln < DIR_LINES; ln++) cpu_op_do(a, 3'd3, CBASE + ln * 64, 32'd0, 4'h0, dummy);
      wait_cycles(30);
    end
  endtask

  task automatic final_checks(input [8*24-1:0] name);
    integer bad;
    begin
      drain_all(300000);
      flush_all();
      drain_all(100000);
      bad = 0;
      for (int ln = 0; ln < DIR_LINES; ln++) if (mem_flat[ln*LB +: LB] !== gl[ln]) bad = bad + 1;
      chk(bad == 0, "shared memory differs from the golden image after every agent flushed (stale / lost data)");
      bad = 0;
      for (int w = 0; w < WORDS_U; w++) if (umem.mem[w] !== gu[w]) bad = bad + 1;
      chk(bad == 0, "uncached memory differs from the golden words");
      chk(dir_err == '0, "directory reported a protocol error");
      chk(ag_err0 == '0 && ag_err1 == '0, "a CPU agent reported a protocol error");
      chk(idle_w, "engine not idle");
      chk(lk_valid_o == '0, "locks held after drain");
      chk(n_completed == n_pushed, "commands pushed != completed");
      $display("[%0t] %0s: engine commands=%0d (coherent %0d, uncached %0d)  CPU perform events=%0d  checks=%0d errors=%0d", $time, name, n_pushed, n_coh_commits, n_unc_commits,
               n_events_cpu, n_checks, n_errors);
    end
  endtask

  task automatic init_state;
    begin
      for (int c = 0; c < NC; c++) begin q_hd[c] = 0; q_tl[c] = 0; seq_next[c] = 0; cur[c] = 0; for (int t = 0; t < 256; t++) begin rc_v[c][t] = 1'b0; rc_com[c][t] = 1'b0; end end
      for (int ln = 0; ln < DIR_LINES; ln++) for (int w = 0; w < 16; w++) gl[ln][w*32 +: 32] = init_word(ln * 16 + w);
      for (int w = 0; w < WORDS_U; w++) begin gu[w] = 64'd0; umem.mem[w] = 64'd0; end
      n_errors = 0; n_checks = 0; n_events_cpu = 0; n_events_eng = 0; n_pushed = 0; n_completed = 0; n_coh_commits = 0; n_unc_commits = 0;
      cpu_ops_done[0] = 0; cpu_ops_done[1] = 0; cpu_en = 1'b0; cpu_pct = 40; cpu_lines = 4; cpu_bias_hot = 60; gap_pct = 20; quiesce_r = 1'b0;
      o_req_valid = 1'b0; o_rsp_ready = 1'b1; o_req_we = 1'b0; o_req_addr = 32'd0; o_req_size = 3'd2; o_req_wdata = 64'd0; o_req_be = 8'hFF; o_req_id = 4'd0; o_req_prot = 2'b11;
    end
  endtask

  function automatic [31:0] caddr(input integer ln, input integer byte_off); caddr = CBASE + ln * 64 + byte_off; endfunction

  // ------------------------------------------------------------------ tests
  task automatic test_directed;
    reg [31:0] r;
    begin
      // 1. dirty line in CPU 0's cache: the engine must observe the CPU's value (dirty intervention), CPU 0's copy must die
      cpu_op_do(0, 3'd1, caddr(1, 8), 32'd100, 4'hF, r);                 // cpu0 STORE word -> line M in cpu0
      push(0, OP_FADD, caddr(1, 8), 64'd5, 64'd0, 1'b0);                 // engine fetch-add must see 100
      drain_all(20000);
      cpu_op_do(0, 3'd0, caddr(1, 8), 32'd0, 4'h0, r);                   // cpu0 LOAD: must see 105, not its stale 100
      chk(r == 32'd105, "directed 1: CPU 0 reads a stale value after the engine's atomic update");
      // 2. two sharers, engine CAS succeeds, both caches invalidated
      cpu_op_do(0, 3'd0, caddr(2, 0), 32'd0, 4'h0, r);
      cpu_op_do(1, 3'd0, caddr(2, 0), 32'd0, 4'h0, r);                   // both agents share line 2
      push(1, OP_CAS, caddr(2, 0), 64'd7, {32'd0, init_word(2*16)}, 1'b0);   // compare with the initial word: success
      drain_all(20000);
      cpu_op_do(0, 3'd0, caddr(2, 0), 32'd0, 4'h0, r); chk(r == 32'd7, "directed 2: CPU 0 stale after CAS");
      cpu_op_do(1, 3'd0, caddr(2, 0), 32'd0, 4'h0, r); chk(r == 32'd7, "directed 2: CPU 1 stale after CAS");
      // 3. CPU atomic then engine atomic then CPU atomic: a chain of ownership transfers
      cpu_op_do(1, 3'd2, caddr(3, 4), 32'd1, 4'hF, r);                   // cpu1 AMO +1
      push(0, OP_FADD, caddr(3, 4), 64'd10, 64'd0, 1'b0);
      drain_all(20000);
      cpu_op_do(0, 3'd2, caddr(3, 4), 32'd100, 4'hF, r);                 // cpu0 AMO +100 returns (init+11)
      chk(r == init_word(3*16 + 1) + 32'd11, "directed 3: AMO after engine update returns the wrong old value");
      // 4. 64-bit atomics straddling two words of one line
      push(0, OP_SWAP, caddr(4, 16), 64'h1122_3344_5566_7788, 64'd0, 1'b1);
      push(0, OP_FADD, caddr(4, 16), 64'h0000_0001_0000_0001, 64'd0, 1'b1);
      push(1, OP_MAXU, caddr(4, 16), 64'h9999_9999_9999_9999, 64'd0, 1'b1);
      // 5. uncached window still works next to the coherent one
      push(1, OP_FADD, UBASE + 8, 64'd3, 64'd0, 1'b0);
      push(1, OP_FADD, UBASE + 8, 64'd4, 64'd0, 1'b0);
      final_checks("coh_directed");
    end
  endtask

  task automatic test_random(input integer n, input bit stress);
    integer k;
    begin
      for (int round = 0; round < 4; round++) begin
        cpu_en = 1'b1; cpu_pct = stress ? 80 : 40; cpu_lines = stress ? 2 : 6; cpu_bias_hot = stress ? 85 : 60; gap_pct = stress ? 0 : 30;
        for (k = 0; k < n / 4; k++) begin : gen
          integer c; reg [3:0] op; reg wide; integer ln, off; reg [31:0] a;
          c = rnd(NC);
          op = 4'(1 + rnd(10));
          wide = pct(40);
          ln = pct(70) ? rnd(2) : rnd(cpu_lines);
          off = wide ? 8 * rnd(8) : 4 * rnd(16);
          if (pct(15)) a = UBASE + 8 * rnd(8) + (wide ? 0 : 4 * rnd(2)); else a = caddr(ln, off);
          push(c, op, a, (rnd(4) == 0) ? 64'd1 : rnd64(0), (op == OP_CAS && pct(40)) ? gl[ln] >> (off*8) : rnd64(0), wide);
          if (rnd(6) == 0) wait_cycles(rnd(8));
        end
        wait_cycles(100);
        cpu_en = 1'b0;
        drain_all(400000);
      end
      final_checks(stress ? "coh_stress" : "coh_random");
    end
  endtask

  // NEGATIVE CONTROL.  An atomic update that bypassed coherence (here: memory is written directly behind the directory's back, which is what an
  // uncached engine would do to a CACHED address) leaves a stale copy in the CPU cache.  The golden-line checker must DETECT it (that is the
  // proof that the coherent-path checks have teeth); the expected error is then cleared.  The same update made by the engine's coherent path
  // (GETM / perform-on-grant / PUTM) is seen by the CPU.
  task automatic test_naive;
    reg [31:0] r;
    integer e0;
    begin
      cpu_op_do(0, 3'd0, caddr(5, 0), 32'd0, 4'h0, r);                    // cpu0 caches line 5 (Shared)
      e0 = n_errors;
      cmem.m[5*16 + 0] = 32'hDEAD_BEEF;                                   // the bypassing update ...
      gl[5][31:0] = 32'hDEAD_BEEF;                                        // ... is the newest value of the location
      cpu_op_do(0, 3'd0, caddr(5, 0), 32'd0, 4'h0, r);                    // the CPU hits its stale Shared copy
      $display("          negative control: after an update that bypassed coherence the CPU reads %h although the newest value is DEADBEEF (stale copy)", r);
      chk(r != 32'hDEAD_BEEF, "naive: the bypass must leave a stale copy in the CPU cache");
      chk(n_errors > e0, "naive: the golden-line checker must flag the stale copy (negative control)");
      n_errors = e0;                                                      // the detection was the expected outcome
      gl[5][31:0] = 32'hDEAD_BEEF;                                        // the checker copied the stale line into the golden image: resynchronise
      // the same kind of update through the engine's coherent path is visible
      push(0, OP_SWAP, caddr(6, 0), 64'hCAFE_F00D, 64'd0, 1'b0);
      drain_all(20000);
      cpu_op_do(0, 3'd0, caddr(6, 0), 32'd0, 4'h0, r);
      chk(r == 32'hCAFE_F00D, "naive: the engine's coherent update must be visible to the CPU");
      final_checks("coh_naive");
    end
  endtask

  integer seed;
  string  tname;
  initial begin
    rng = 64'h9E3779B97F4A7C15; seed = 1;
    if ($value$plusargs("seed=%d", seed)) rng = rng ^ (64'(seed) * 64'hD1B54A32D192ED03);
    rnd64(0); rnd64(0);
    tname = "coh_directed";
    void'($value$plusargs("test=%s", tname));
    init_state();
    rst_n = 1'b0; wait_cycles(6); rst_n = 1'b1; wait_cycles(4);
    case (tname)
      "coh_directed": test_directed();
      "coh_random":   test_random(240, 1'b0);
      "coh_stress":   test_random(480, 1'b1);
      "coh_naive":    test_naive();
      default: begin $display("unknown test"); n_errors = n_errors + 1; end
    endcase
    if (n_errors == 0) $display("RESULT: PASS  test=%0s seed=%0d  checks=%0d", tname, seed, n_checks);
    else               $display("RESULT: FAIL  test=%0s seed=%0d  errors=%0d checks=%0d", tname, seed, n_errors, n_checks);
    $finish;
  end
  initial begin #300000000; $display("RESULT: FAIL  (global timeout)"); $finish; end
endmodule

`default_nettype wire
