// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: self-checking system testbench   (Verilator --binary --timing, Icarus -g2012)
//
// Select a test with +test=NAME, a seed with +seed=N.  Tests: smoke single cas ticket overflow minmax w64 random contend
// perm errors reset queue order quiesce fair naive.  Every test ends with the same final checks.
//
// WHAT IS CHECKED (all of it independent of the RTL under test):
//   1. SEQUENTIAL REFERENCE MODEL.  For every linearisation-point event of the engine the scoreboard recomputes the operation with
//      its OWN reference function (sign-extension based, written separately from the RTL's offset-binary ALU; also cross-checked
//      against model/sf_atomic_ref.py by tb_sf_atomic_alu) on the value the memory REALLY holds at that instant, and compares the
//      old value, the new value, the success flag and "wrote / did not write".  That is exactly "every committed result matches a
//      valid serial execution": the commit events, ordered by the clock, are the serial order.
//   2. EXCLUSIVITY AT THE MEMORY PORT.  Independently of any engine-internal signal a monitor watches the memory master port:
//      a write accepted between the read and the commit of an atomic to the same 8-byte word (by an ordinary master or by another
//      context) is a LOST-UPDATE VIOLATION.  Every write must belong to either an issued ordinary request or an open atomic.
//   3. COMPLETIONS: status equals the TB's independent prediction (op / width / alignment / window / domain / destination / guard),
//      destination port, tag, rid, in-order per client, exactly once, old value equals the value of the commit event.
//   4. MEMORY IMAGE: after every test the memory array equals the golden image built from observed accepted writes; a denied or
//      failed operation that wrote would show up as a write without an open atomic or as an image difference.
//   5. PROTOCOL: stability of every valid/ready channel while stalled, nothing valid during reset, bounded queues never overflow.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_atomic_engine;
  // ------------------------------------------------------------------ geometry (override with -G on the simulator command line)
  parameter int NC        = 4;
  parameter int QD        = 4;
  parameter int NCTX      = 2;
  parameter int AW        = 32;
  parameter int TAGW      = 8;
  parameter int RIDW      = 4;
  parameter int DOMW      = 2;
  parameter int OIDW      = 4;
  parameter int OMAX      = 4;
  parameter int LOCK_GRAN = 3;
  parameter logic [15:0] OP_EN = 16'h07FE;
  parameter int W64_EN    = 1;
  parameter int MEM_LAT   = 1;
  parameter int WORDS     = 2048;
  parameter int PERF      = 1;

  localparam int ND   = (1 << DOMW);
  localparam int CLW  = (NC > 1) ? $clog2(NC) : 1;
  localparam int CXW  = (NCTX > 1) ? $clog2(NCTX) : 1;
  localparam int OW   = (OMAX > 1) ? $clog2(OMAX) : 1;
  localparam int IDW  = (CXW > OW) ? CXW : OW;
  localparam int MIDW = IDW + 1;
  localparam int KEYW = AW - LOCK_GRAN;
  localparam int PF_N = sf_atomic_pkg::PF_N;

  localparam int WIN_BASE  = 32'h1000;
  localparam int WIN_LIMIT = 32'h1100;           // 256 bytes = 32 words = 32 lock granules (default granule)

  // ------------------------------------------------------------------ clock / reset
  reg clk = 1'b0;
  reg rst_n = 1'b0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------------ DUT signals
  reg  [AW-1:0]       win_base_r, win_limit_r;
  reg  [NC*ND-1:0]    port_dom_mask_r;
  reg  [NC*NC-1:0]    dest_allow_r;
  reg  [1:0]          atom_prot_r;
  reg                 quiesce_r;
  wire                idle_w, cfg_err_w;

  reg  [NC-1:0]       cmd_valid;
  wire [NC-1:0]       cmd_ready;
  reg  [NC*4-1:0]     cmd_op;
  reg  [NC*AW-1:0]    cmd_addr;
  reg  [NC*64-1:0]    cmd_opd, cmd_cmp;
  reg  [NC*2-1:0]     cmd_width;
  reg  [NC*RIDW-1:0]  cmd_rid;
  reg  [NC*TAGW-1:0]  cmd_tag;
  reg  [NC*DOMW-1:0]  cmd_dom;
  reg  [NC*CLW-1:0]   cmd_dest;
  reg  [NC-1:0]       cmd_aq, cmd_rl;

  wire [NC*AW-1:0]    grd_addr_o;
  wire [NC*4-1:0]     grd_len_o;
  wire [NC*DOMW-1:0]  grd_dom_o;
  reg  [NC-1:0]       grd_ok_r, grd_ok_w;

  wire [NC-1:0]       rsp_valid;
  reg  [NC-1:0]       rsp_ready;
  wire [NC*TAGW-1:0]  rsp_tag;
  wire [NC*RIDW-1:0]  rsp_rid;
  wire [NC*CLW-1:0]   rsp_src;
  wire [NC*64-1:0]    rsp_old;
  wire [NC-1:0]       rsp_succ;
  wire [NC*4-1:0]     rsp_status;

  reg                 o_req_valid;
  wire                o_req_ready;
  reg                 o_req_we;
  reg  [AW-1:0]       o_req_addr;
  reg  [2:0]          o_req_size;
  reg  [63:0]         o_req_wdata;
  reg  [7:0]          o_req_be;
  reg  [OIDW-1:0]     o_req_id;
  reg  [1:0]          o_req_prot;
  wire                o_rsp_valid;
  reg                 o_rsp_ready;
  wire [63:0]         o_rsp_rdata;
  wire [OIDW-1:0]     o_rsp_id;
  wire                o_rsp_we;
  wire [3:0]          o_rsp_status;

  wire                m_req_valid, m_req_ready, m_req_we;
  wire [AW-1:0]       m_req_addr;
  wire [2:0]          m_req_size;
  wire [63:0]         m_req_wdata;
  wire [7:0]          m_req_be;
  wire [MIDW-1:0]     m_req_id;
  wire [1:0]          m_req_prot;
  wire                m_rsp_valid, m_rsp_ready, m_rsp_we;
  wire [63:0]         m_rsp_rdata;
  wire [MIDW-1:0]     m_rsp_id;
  wire [3:0]          m_rsp_status;

  wire [NCTX-1:0]      ev_c_valid;
  wire [NCTX*CLW-1:0]  ev_c_client;
  wire [NCTX*TAGW-1:0] ev_c_tag;
  wire [NCTX*AW-1:0]   ev_c_addr;
  wire [NCTX*4-1:0]    ev_c_op;
  wire [NCTX-1:0]      ev_c_wide;
  wire [NCTX*64-1:0]   ev_c_old, ev_c_new;
  wire [NCTX-1:0]      ev_c_succ, ev_c_wrote, ev_c_coh;
  wire [NCTX-1:0]      lk_valid_o;
  wire [NCTX*KEYW-1:0] lk_key_o;
  reg                  diag_clr_r, perf_clr_r;
  wire                 diag_valid_o;
  wire [CLW-1:0]       diag_client_o;
  wire [3:0]           diag_status_o;
  wire [AW-1:0]        diag_addr_o;
  wire [PF_N*32-1:0]   perf_o;

  // memory knobs
  reg [7:0]  mem_rdy_pct, mem_lat_pct;
  reg [3:0]  mem_lat_max;
  reg        inj_rd_en, inj_wr_en;
  reg [31:0] inj_rd_word, inj_wr_word;

  // ------------------------------------------------------------------ DUT and memory
  sf_atomic_engine #(.NC(NC), .QD(QD), .NCTX(NCTX), .AW(AW), .TAGW(TAGW), .RIDW(RIDW), .DOMW(DOMW), .OIDW(OIDW), .OMAX(OMAX),
                     .LOCK_GRAN(LOCK_GRAN), .OP_EN(OP_EN), .W64_EN(W64_EN), .COHERENT(0), .PERF(PERF)) dut (
    .clk(clk), .rst_n(rst_n),
    .win_base(win_base_r), .win_limit(win_limit_r), .coh_base({AW{1'b0}}), .coh_limit({AW{1'b0}}),
    .port_dom_mask(port_dom_mask_r), .dest_allow(dest_allow_r), .atom_prot_i(atom_prot_r), .quiesce_i(quiesce_r),
    .idle_o(idle_w), .cfg_err_o(cfg_err_w),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_op(cmd_op), .cmd_addr(cmd_addr), .cmd_opd(cmd_opd), .cmd_cmp(cmd_cmp),
    .cmd_width(cmd_width), .cmd_rid(cmd_rid), .cmd_tag(cmd_tag), .cmd_dom(cmd_dom), .cmd_dest(cmd_dest), .cmd_aq(cmd_aq), .cmd_rl(cmd_rl),
    .grd_addr_o(grd_addr_o), .grd_len_o(grd_len_o), .grd_dom_o(grd_dom_o), .grd_ok_r(grd_ok_r), .grd_ok_w(grd_ok_w),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_tag(rsp_tag), .rsp_rid(rsp_rid), .rsp_src(rsp_src), .rsp_old(rsp_old),
    .rsp_succ(rsp_succ), .rsp_status(rsp_status),
    .o_req_valid(o_req_valid), .o_req_ready(o_req_ready), .o_req_we(o_req_we), .o_req_addr(o_req_addr), .o_req_size(o_req_size),
    .o_req_wdata(o_req_wdata), .o_req_be(o_req_be), .o_req_id(o_req_id), .o_req_prot(o_req_prot),
    .o_rsp_valid(o_rsp_valid), .o_rsp_ready(o_rsp_ready), .o_rsp_rdata(o_rsp_rdata), .o_rsp_id(o_rsp_id), .o_rsp_we(o_rsp_we),
    .o_rsp_status(o_rsp_status),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_size(m_req_size),
    .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id), .m_req_prot(m_req_prot),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we),
    .m_rsp_status(m_rsp_status),
    .rq_valid(), .rq_ready(1'b0), .rq_type(), .rq_line(), .rq_data(), .rs_valid(), .rs_ready(1'b0), .rs_type(), .rs_line(),
    .rs_data(), .rs_keep(), .sn_valid(1'b0), .sn_ready(), .sn_type(2'd0), .sn_line({16{1'b0}}), .gn_valid(1'b0), .gn_ready(),
    .gn_type(3'd0), .gn_line({16{1'b0}}), .gn_data({512{1'b0}}),
    .ev_c_valid(ev_c_valid), .ev_c_client(ev_c_client), .ev_c_tag(ev_c_tag), .ev_c_addr(ev_c_addr), .ev_c_op(ev_c_op),
    .ev_c_wide(ev_c_wide), .ev_c_old(ev_c_old), .ev_c_new(ev_c_new), .ev_c_succ(ev_c_succ), .ev_c_wrote(ev_c_wrote), .ev_c_coh(ev_c_coh),
    .lk_valid_o(lk_valid_o), .lk_key_o(lk_key_o),
    .diag_clr_i(diag_clr_r), .diag_valid_o(diag_valid_o), .diag_client_o(diag_client_o), .diag_status_o(diag_status_o),
    .diag_addr_o(diag_addr_o), .perf_clr_i(perf_clr_r), .perf_o(perf_o)
  );

  sf_atomic_mem_model #(.AW(AW), .MIDW(MIDW), .WORDS(WORDS), .LAT(MEM_LAT)) mem (
    .clk(clk), .rst_n(rst_n),
    .req_valid(m_req_valid), .req_ready(m_req_ready), .req_we(m_req_we), .req_addr(m_req_addr), .req_size(m_req_size),
    .req_wdata(m_req_wdata), .req_be(m_req_be), .req_id(m_req_id), .req_prot(m_req_prot),
    .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready), .rsp_rdata(m_rsp_rdata), .rsp_id(m_rsp_id), .rsp_we(m_rsp_we),
    .rsp_status(m_rsp_status),
    .rdy_pct(mem_rdy_pct), .lat_extra_pct(mem_lat_pct), .lat_extra_max(mem_lat_max),
    .inj_rd_en(inj_rd_en), .inj_rd_word(inj_rd_word), .inj_wr_en(inj_wr_en), .inj_wr_word(inj_wr_word)
  );

  // ------------------------------------------------------------------ opcode / status constants (TB's own copies of the specification)
  localparam [3:0] OP_SWAP=1, OP_FADD=2, OP_FAND=3, OP_FOR=4, OP_FXOR=5, OP_MIN=6, OP_MAX=7, OP_MINU=8, OP_MAXU=9, OP_CAS=10;
  localparam [3:0] ST_OK=0, ST_OP=1, ST_WIDTH=2, ST_ALIGN=3, ST_RANGE=4, ST_DOMAIN=5, ST_DEST=6, ST_PERM=7, ST_READ=8, ST_WRITE=9;

  // ------------------------------------------------------------------ random numbers (deterministic, simulator independent)
  reg [63:0] rng;
  function automatic [63:0] rnd64(input integer dummy);
    reg [63:0] x;
    begin
      x = rng;
      x = x ^ (x >> 12);
      x = x ^ (x << 25);
      x = x ^ (x >> 27);
      rng = x;
      rnd64 = x * 64'h2545F4914F6CDD1D;
    end
  endfunction
  function automatic integer rnd(input integer bound);       // 0 .. bound-1
    reg [63:0] r;
    begin
      r = rnd64(0);
      rnd = (bound <= 1) ? 0 : integer'((r >> 11) % bound);
    end
  endfunction
  function automatic bit pct(input integer p);
    pct = (rnd(100) < p);
  endfunction

  // ------------------------------------------------------------------ independent reference model of one atomic operation
  // Written with sign-extension and ordinary SV arithmetic; deliberately a different construction from sf_atomic_alu.
  task automatic ref_atomic(input [3:0] op, input bit wide, input [63:0] old_v, input [63:0] opd_v, input [63:0] cmp_v,
                            output [63:0] new_v, output bit succ, output bit wr, output bit opok);
    reg [63:0] m, o, a, c;
    reg signed [63:0] so, sa;
    begin
      m = wide ? 64'hFFFF_FFFF_FFFF_FFFF : 64'h0000_0000_FFFF_FFFF;
      o = old_v & m; a = opd_v & m; c = cmp_v & m;
      so = wide ? $signed(o) : $signed({{32{o[31]}}, o[31:0]});
      sa = wide ? $signed(a) : $signed({{32{a[31]}}, a[31:0]});
      new_v = o; succ = 1'b1; wr = 1'b1; opok = 1'b1;
      case (op)
        OP_SWAP: new_v = a;
        OP_FADD: new_v = (o + a) & m;
        OP_FAND: new_v = o & a;
        OP_FOR : new_v = o | a;
        OP_FXOR: new_v = o ^ a;
        OP_MIN : new_v = (so < sa) ? o : a;
        OP_MAX : new_v = (so > sa) ? o : a;
        OP_MINU: new_v = (o < a) ? o : a;
        OP_MAXU: new_v = (o > a) ? o : a;
        OP_CAS : begin succ = (o == c); wr = succ; new_v = succ ? a : o; end
        default: begin opok = 1'b0; succ = 1'b0; wr = 1'b0; end
      endcase
    end
  endtask

  // ------------------------------------------------------------------ MemoryGuard-style region model (whole transfer inside ONE region)
  reg        gr_v  [0:ND-1][0:3];
  reg [31:0] gr_b  [0:ND-1][0:3];
  reg [31:0] gr_l  [0:ND-1][0:3];
  reg        gr_r  [0:ND-1][0:3];
  reg        gr_w  [0:ND-1][0:3];

  function automatic bit guard_ok(input integer dom, input [31:0] addr, input integer len, input bit wr);
    bit res;
    begin
      res = 1'b0;
      for (int k = 0; k < 4; k++)
        if (gr_v[dom][k] && (addr >= gr_b[dom][k]) && ((addr + len) <= gr_l[dom][k]))
          res = wr ? gr_w[dom][k] : gr_r[dom][k];
      guard_ok = res;
    end
  endfunction

  always_comb begin
    for (int c = 0; c < NC; c++) begin
      grd_ok_r[c] = guard_ok(32'(grd_dom_o[c*DOMW +: DOMW]), grd_addr_o[c*AW +: AW], 32'(grd_len_o[c*4 +: 4]), 1'b0);
      grd_ok_w[c] = guard_ok(32'(grd_dom_o[c*DOMW +: DOMW]), grd_addr_o[c*AW +: AW], 32'(grd_len_o[c*4 +: 4]), 1'b1);
    end
  end

  // ------------------------------------------------------------------ expected status predictor (the specification, again, independently)
  function automatic [3:0] predict(input integer c, input [3:0] op, input [1:0] wd, input [31:0] addr, input integer dom, input integer dest);
    bit opok, wdok, alok, rgok, dmok, deok, pmok, wide;
    begin
      opok = (op >= 1) && (op <= 10) && OP_EN[op];
      wide = (wd == 2'd1);
      wdok = (wd == 2'd0) || (wd == 2'd1 && W64_EN != 0);
      alok = wide ? ((addr & 32'h7) == 0) : ((addr & 32'h3) == 0);
      rgok = (addr >= win_base_r) && (addr < win_limit_r);
      dmok = port_dom_mask_r[c*ND + dom];
      deok = (dest < NC) && dest_allow_r[c*NC + dest];
      pmok = guard_ok(dom, addr, wide ? 8 : 4, 1'b0) && guard_ok(dom, addr, wide ? 8 : 4, 1'b1);
      predict = !opok ? ST_OP : !wdok ? ST_WIDTH : !alok ? ST_ALIGN : !rgok ? ST_RANGE : !dmok ? ST_DOMAIN : !deok ? ST_DEST : !pmok ? ST_PERM : ST_OK;
    end
  endfunction

  // ------------------------------------------------------------------ per-client command FIFOs (stimulus)
  localparam int CQ = 4096;
  reg [3:0]    q_op   [0:NC-1][0:CQ-1];
  reg [31:0]   q_addr [0:NC-1][0:CQ-1];
  reg [63:0]   q_opd  [0:NC-1][0:CQ-1];
  reg [63:0]   q_cmp  [0:NC-1][0:CQ-1];
  reg [1:0]    q_wd   [0:NC-1][0:CQ-1];
  reg [3:0]    q_rid  [0:NC-1][0:CQ-1];
  reg [7:0]    q_tag  [0:NC-1][0:CQ-1];
  reg [3:0]    q_dom  [0:NC-1][0:CQ-1];
  reg [3:0]    q_dest [0:NC-1][0:CQ-1];
  reg          q_aq   [0:NC-1][0:CQ-1];
  reg          q_rl   [0:NC-1][0:CQ-1];
  integer      q_hd [0:NC-1];
  integer      q_tl [0:NC-1];
  integer      seq_next [0:NC-1];                     // next sequence number per client
  integer      gap_cnt [0:NC-1];
  integer      cmd_gap_pct, cmd_gap_max;              // issue pacing knobs
  integer      rsp_rdy_pct;                           // completion back-pressure knob

  // per-(client, tag) record of an outstanding command: the scoreboard's memory of what was asked
  reg          rc_v    [0:NC-1][0:255];               // outstanding
  reg          rc_acc  [0:NC-1][0:255];               // accepted by the engine
  reg [3:0]    rc_op   [0:NC-1][0:255];
  reg [31:0]   rc_addr [0:NC-1][0:255];
  reg [63:0]   rc_opd  [0:NC-1][0:255];
  reg [63:0]   rc_cmp  [0:NC-1][0:255];
  reg [1:0]    rc_wd   [0:NC-1][0:255];
  reg [3:0]    rc_rid  [0:NC-1][0:255];
  reg          rc_aq   [0:NC-1][0:255];
  reg          rc_rl   [0:NC-1][0:255];
  reg [3:0]    rc_est  [0:NC-1][0:255];               // expected status
  integer      rc_edst [0:NC-1][0:255];               // expected destination
  integer      rc_seq  [0:NC-1][0:255];
  reg          rc_com  [0:NC-1][0:255];               // commit event seen
  reg [63:0]   rc_old  [0:NC-1][0:255];
  reg          rc_succ [0:NC-1][0:255];
  reg          rc_wrote[0:NC-1][0:255];
  integer      rc_cyc  [0:NC-1][0:255];
  integer      last_dlv_seq [0:NC-1];
  integer      n_pushed, n_completed, n_cancelled, n_commits, n_errors, n_checks;
  integer      n_status [0:15];

  // flat bus drive
  reg          cv [0:NC-1];
  integer      cur [0:NC-1];                          // FIFO index being presented
  always_comb begin
    for (int c = 0; c < NC; c++) begin
      cmd_valid[c] = cv[c];
      cmd_op   [c*4 +: 4]     = cv[c] ? q_op  [c][cur[c]] : 4'd0;
      cmd_addr [c*AW +: AW]   = cv[c] ? AW'(q_addr[c][cur[c]]) : {AW{1'b0}};
      cmd_opd  [c*64 +: 64]   = cv[c] ? q_opd [c][cur[c]] : 64'd0;
      cmd_cmp  [c*64 +: 64]   = cv[c] ? q_cmp [c][cur[c]] : 64'd0;
      cmd_width[c*2 +: 2]     = cv[c] ? q_wd  [c][cur[c]] : 2'd0;
      cmd_rid  [c*RIDW +: RIDW] = cv[c] ? RIDW'(q_rid[c][cur[c]]) : {RIDW{1'b0}};
      cmd_tag  [c*TAGW +: TAGW] = cv[c] ? TAGW'(q_tag[c][cur[c]]) : {TAGW{1'b0}};
      cmd_dom  [c*DOMW +: DOMW] = cv[c] ? DOMW'(q_dom[c][cur[c]]) : {DOMW{1'b0}};
      cmd_dest [c*CLW +: CLW]   = cv[c] ? CLW'(q_dest[c][cur[c]]) : {CLW{1'b0}};
      cmd_aq   [c]            = cv[c] ? q_aq[c][cur[c]] : 1'b0;
      cmd_rl   [c]            = cv[c] ? q_rl[c][cur[c]] : 1'b0;
    end
  end

  // push a command (blocks while the tag slot is still in use)
  task automatic push(input integer c, input [3:0] op, input [31:0] addr, input [63:0] opd, input [63:0] cmp, input [1:0] wd,
                      input integer dom, input integer dest, input bit aq, input bit rl);
    reg [7:0] tg;
    integer   idx;
    integer   dom_m, dest_m;
    begin
      dom_m  = dom  & ((1 << DOMW) - 1);          // the port carries DOMW / CLW bits: what the DUT sees is what the prediction uses
      dest_m = dest & ((1 << CLW) - 1);
      dom = dom_m; dest = dest_m;
      if (wd == 2'd0) begin                      // 32-bit operation: the upper operand bits are don't-care, fill them with noise
        opd = opd | (rnd64(0) << 32);
        cmp = cmp | (rnd64(0) << 32);
      end
      tg = seq_next[c][7:0];
      while (rc_v[c][tg] || ((q_tl[c] - q_hd[c]) >= CQ - 2)) @(posedge clk);
      idx = q_tl[c] % CQ;
      q_op[c][idx] = op; q_addr[c][idx] = addr; q_opd[c][idx] = opd; q_cmp[c][idx] = cmp; q_wd[c][idx] = wd;
      q_rid[c][idx] = 4'(c); q_tag[c][idx] = tg; q_dom[c][idx] = 4'(dom); q_dest[c][idx] = 4'(dest); q_aq[c][idx] = aq; q_rl[c][idx] = rl;
      rc_v[c][tg] = 1'b1; rc_acc[c][tg] = 1'b0; rc_op[c][tg] = op; rc_addr[c][tg] = addr; rc_opd[c][tg] = opd; rc_cmp[c][tg] = cmp;
      rc_wd[c][tg] = wd; rc_rid[c][tg] = 4'(c); rc_aq[c][tg] = aq; rc_rl[c][tg] = rl;
      rc_est[c][tg] = predict(c, op, wd, addr, dom, dest);
      rc_edst[c][tg] = ((dest < NC) && dest_allow_r[c*NC + dest]) ? dest : c;
      rc_seq[c][tg] = seq_next[c]; rc_com[c][tg] = 1'b0; rc_wrote[c][tg] = 1'b0; rc_succ[c][tg] = 1'b0; rc_old[c][tg] = 64'd0;
      seq_next[c] = seq_next[c] + 1;
      q_tl[c] = q_tl[c] + 1;
      n_pushed = n_pushed + 1;
    end
  endtask

  task automatic set_est(input integer c, input [3:0] st);
    rc_est[c][(seq_next[c] - 1) & 255] = st;
  endtask

  // simple push helper: domain = client's own, destination = self
  task automatic atom(input integer c, input [3:0] op, input [31:0] addr, input [63:0] opd, input [63:0] cmp, input bit wide);
    push(c, op, addr, opd, cmp, wide ? 2'd1 : 2'd0, c % ND, c, 1'b0, 1'b0);
  endtask

  // ------------------------------------------------------------------ per-client drivers
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int c = 0; c < NC; c++) begin cv[c] <= 1'b0; gap_cnt[c] <= 0; end
    end else begin
      for (int c = 0; c < NC; c++) begin
        if (cv[c] && cmd_ready[c]) begin
          rc_acc[c][q_tag[c][cur[c]]] = 1'b1;
          cv[c] <= 1'b0;
          gap_cnt[c] <= pct(cmd_gap_pct) ? (1 + rnd(cmd_gap_max)) : 0;
        end else if (!cv[c]) begin
          if (gap_cnt[c] > 0) gap_cnt[c] <= gap_cnt[c] - 1;
          else if (q_hd[c] != q_tl[c]) begin
            cur[c] <= q_hd[c] % CQ;
            q_hd[c] = q_hd[c] + 1;
            cv[c] <= 1'b1;
          end
        end
      end
    end
  end

  // ------------------------------------------------------------------ scoreboard state
  reg [63:0] gm [0:WORDS-1];                          // golden memory image (from observed accepted writes)
  reg        win_open [0:NCTX-1];                     // an atomic read was accepted and the atomic has not committed
  integer    win_word [0:NCTX-1];
  reg [63:0] exp_wdata [0:NCTX-1];
  reg        exp_wr    [0:NCTX-1];
  reg        exp_wr_v  [0:NCTX-1];
  integer    viol_cnt;
  integer    wr_atomic_cnt, wr_ord_cnt, rd_atomic_cnt, rd_ord_cnt;
  integer    ticket_en, ticket_word;
  reg        ticket_seen [0:65535];
  integer    ticket_dups;
  integer    ord_en_cnt;
  integer    inv_cnt;
  integer    comp_cnt [0:NC-1];
  integer    skew_max;
  reg        skew_en;

  task automatic fail(input [8*64-1:0] msg);
    begin
      n_errors = n_errors + 1;
      if (n_errors <= 20) $display("[%0t] ERROR: %0s", $time, msg);
    end
  endtask
  task automatic chk(input bit cond, input [8*64-1:0] msg);
    begin
      n_checks = n_checks + 1;
      if (!cond) fail(msg);
    end
  endtask

  // ------------------------------------------------------------------ completion monitor (back-pressure random)
  always @(posedge clk) begin
    if (!rst_n) rsp_ready <= {NC{1'b0}};
    else for (int d = 0; d < NC; d++) rsp_ready[d] <= pct(rsp_rdy_pct);
  end

  always @(posedge clk) begin
    if (rst_n) begin
      for (int d = 0; d < NC; d++) begin
        if (rsp_valid[d] && rsp_ready[d]) begin : cmp_blk
          reg [7:0] tg;
          integer   s;
          reg [3:0] st;
          tg = rsp_tag[d*TAGW +: TAGW];
          s  = 32'(rsp_src[d*CLW +: CLW]);
          st = rsp_status[d*4 +: 4];
          n_status[st] = n_status[st] + 1;
          chk(s < NC, "completion src out of range");
          if (s < NC) begin
            chk(rc_v[s][tg], "completion for a command that is not outstanding (duplicate / phantom)");
            if (rc_v[s][tg]) begin
              chk(rc_acc[s][tg], "completion before the command was accepted");
              chk(d == rc_edst[s][tg], "completion delivered to the wrong destination port");
              chk(rsp_rid[d*RIDW +: RIDW] == rc_rid[s][tg][RIDW-1:0], "completion rid mismatch");
              chk(st == rc_est[s][tg], "completion status differs from the independent prediction");
              chk(rc_seq[s][tg] > last_dlv_seq[s], "completions of one client out of order");
              last_dlv_seq[s] = rc_seq[s][tg];
              if (rc_est[s][tg] == ST_OK && st == ST_OK) begin
                chk(rc_com[s][tg], "OK completion without a commit event (no linearisation point)");
                chk(rsp_old[d*64 +: 64] == rc_old[s][tg], "completion old value differs from the value at the linearisation point");
                chk(rsp_succ[d] == rc_succ[s][tg], "completion success flag differs from the reference");
                if (ticket_en != 0 && rc_op[s][tg] == OP_FADD && rc_addr[s][tg] == ticket_word && rc_wd[s][tg] == 2'd0 && rc_opd[s][tg][31:0] == 32'd1) begin
                  if (rsp_old[d*64 +: 64] < 65536) begin
                    if (ticket_seen[rsp_old[d*64 +: 16]]) ticket_dups = ticket_dups + 1;
                    ticket_seen[rsp_old[d*64 +: 16]] = 1'b1;
                  end
                end
              end else begin
                chk(!rc_com[s][tg] || rc_est[s][tg] == ST_WRITE, "rejected command shows a linearisation point");
                chk(rsp_old[d*64 +: 64] == 64'd0 || st == ST_WRITE, "error completion returns a non-zero old value");
                chk(!rsp_succ[d], "error completion reports success");
              end
              rc_v[s][tg] = 1'b0;
              n_completed = n_completed + 1;
              comp_cnt[s] = comp_cnt[s] + 1;
            end
          end
        end
      end
    end
  end

  // ------------------------------------------------------------------ memory-port monitor, commit events, exclusivity
  reg [63:0] r_new;
  reg        r_succ, r_wr, r_opok;
  reg [63:0] r_old_g;
  integer    mw;
  integer    ctx_i;
  reg [63:0] gm_before;
  reg        any_viol;
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int i = 0; i < NCTX; i++) begin win_open[i] = 1'b0; exp_wr_v[i] = 1'b0; end
    end else begin
      // ---- (1) commit events: reference model on the golden memory, BEFORE this edge's write is applied
      for (int i = 0; i < NCTX; i++) begin
        if (ev_c_valid[i]) begin : ev_blk
          integer s;
          reg [7:0] tg;
          reg [63:0] wmask;
          s  = 32'(ev_c_client[i*CLW +: CLW]);
          tg = ev_c_tag[i*TAGW +: TAGW];
          mw = (32'(ev_c_addr[i*AW +: AW]) >> 3) % WORDS;
          n_commits = n_commits + 1;
          chk(rc_v[s][tg], "commit event for a command that is not outstanding");
          chk(win_open[i], "commit event without an open atomic window (no read seen at the memory port)");
          if (rc_v[s][tg]) begin
            chk(!rc_com[s][tg], "operation committed TWICE (executed more than once)");
            chk(rc_est[s][tg] == ST_OK || rc_est[s][tg] == ST_WRITE, "a command predicted to be rejected reached its linearisation point");
            chk(rc_op[s][tg] == ev_c_op[i*4 +: 4], "commit event opcode differs from the command");
            chk(rc_addr[s][tg] == 32'(ev_c_addr[i*AW +: AW]), "commit event address differs from the command");
            chk((rc_wd[s][tg] == 2'd1) == ev_c_wide[i], "commit event width differs from the command");
            // value the memory really holds for this operand
            gm_before = gm[mw];
            if (rc_wd[s][tg] == 2'd1) r_old_g = gm_before;
            else r_old_g = {32'd0, (gm_before >> (8 * (32'(ev_c_addr[i*AW +: AW]) & 4)))};
            if (rc_wd[s][tg] != 2'd1) r_old_g = r_old_g & 64'h0000_0000_FFFF_FFFF;
            ref_atomic(rc_op[s][tg], rc_wd[s][tg] == 2'd1, r_old_g, rc_opd[s][tg], rc_cmp[s][tg], r_new, r_succ, r_wr, r_opok);
            chk(ev_c_old[i*64 +: 64] == r_old_g, "LOST UPDATE / stale read: old value differs from the memory content at the linearisation point");
            chk(ev_c_succ[i] == r_succ, "success flag differs from the sequential reference");
            chk(ev_c_wrote[i] == r_wr, "wrote / did-not-write differs from the sequential reference");
            if (r_wr) chk(ev_c_new[i*64 +: 64] == r_new, "new value differs from the sequential reference");
            for (int t = 0; t < 256; t++)
              if (rc_v[s][t] && (t != tg) && !rc_com[s][t] && (rc_est[s][t] == ST_OK || rc_est[s][t] == ST_WRITE) && rc_seq[s][t] < rc_seq[s][tg]) begin inv_cnt = inv_cnt + 1; t = 256; end
            // ordering bits: rl = every older command of the client committed before this one; aq = nothing younger commits before this one
            for (int t = 0; t < 256; t++) begin
              if (rc_v[s][t] && (t != tg) && !rc_com[s][t] && (rc_est[s][t] == ST_OK || rc_est[s][t] == ST_WRITE)) begin
                if (rc_rl[s][tg] && rc_seq[s][t] < rc_seq[s][tg]) fail("RL ordering violated: an older command of the client had not committed");
                if (rc_aq[s][t] && rc_seq[s][t] < rc_seq[s][tg]) fail("AQ ordering violated: a younger command committed before an older acquire");
              end
            end
            rc_com[s][tg] = 1'b1; rc_old[s][tg] = ev_c_old[i*64 +: 64]; rc_succ[s][tg] = ev_c_succ[i]; rc_wrote[s][tg] = ev_c_wrote[i];
            exp_wr_v[i] = r_wr;
            // expected image of the written word (merge into the 64-bit word)
            if (rc_wd[s][tg] == 2'd1) exp_wdata[i] = r_new;
            else begin
              wmask = 64'h0000_0000_FFFF_FFFF << (8 * (32'(ev_c_addr[i*AW +: AW]) & 4));
              exp_wdata[i] = (gm_before & ~wmask) | ((r_new << (8 * (32'(ev_c_addr[i*AW +: AW]) & 4))) & wmask);
            end
          end
        end else exp_wr_v[i] = 1'b0;
      end

      // ---- (2) memory-port accept monitor
      if (m_req_valid && m_req_ready) begin : acc_blk
        integer wix;
        reg [63:0] nw;
        wix = (32'(m_req_addr) >> 3) % WORDS;
        if (m_req_id[MIDW-1]) begin
          // ordinary access
          if (m_req_we) wr_ord_cnt = wr_ord_cnt + 1; else rd_ord_cnt = rd_ord_cnt + 1;
        end else begin
          ctx_i = 32'(m_req_id[IDW-1:0]);
          if (m_req_we) wr_atomic_cnt = wr_atomic_cnt + 1; else rd_atomic_cnt = rd_atomic_cnt + 1;
          if (!m_req_we) begin
            chk(!win_open[ctx_i], "context issued a read while its previous atomic window is still open");
            win_open[ctx_i] = 1'b1; win_word[ctx_i] = wix;
          end else begin
            chk(win_open[ctx_i], "atomic write without a preceding atomic read");
            chk(win_open[ctx_i] && win_word[ctx_i] == wix, "atomic write to a different word than its read");
            chk(ev_c_valid[ctx_i] && exp_wr_v[ctx_i], "atomic write accepted without a (writing) linearisation event in the same cycle");
            if (exp_wr_v[ctx_i]) begin
              // observed data vs reference (merge lanes into the word)
              nw = do_write_tb(gm[wix], m_req_addr[2:0], m_req_size, m_req_wdata, m_req_be);
              chk(nw == exp_wdata[ctx_i], "memory write data differs from the sequential reference result");
            end
          end
        end
        if (m_req_we) begin
          // exclusivity: nobody else may write a word while an atomic window on it is open
          for (int j = 0; j < NCTX; j++) begin
            any_viol = win_open[j] && (win_word[j] == wix) && (m_req_id[MIDW-1] || (32'(m_req_id[IDW-1:0]) != j));
            if (any_viol) begin
              viol_cnt = viol_cnt + 1;
              fail("EXCLUSIVITY VIOLATION: a write was accepted inside another atomic's read-modify-write window");
            end
          end
          if (!(inj_wr_en && (32'(wix) == inj_wr_word)) && (wix < WORDS) && (m_req_addr[AW-1:3] < WORDS))
            gm[wix] = do_write_tb(gm[wix], m_req_addr[2:0], m_req_size, m_req_wdata, m_req_be);
        end
      end

      // an atomic read answered with an error ends its window without a linearisation point (nothing was written)
      if (m_rsp_valid && m_rsp_ready && !m_rsp_id[MIDW-1] && !m_rsp_we && (m_rsp_status != 4'd0)) win_open[32'(m_rsp_id[IDW-1:0])] = 1'b0;
      // ---- (3) close the windows of the atomics that committed this cycle
      for (int i = 0; i < NCTX; i++) if (ev_c_valid[i]) win_open[i] = 1'b0;
    end
  end

  function automatic [63:0] do_write_tb(input [63:0] w, input [2:0] off, input [2:0] size, input [63:0] d, input [7:0] be);
    reg [63:0] r;
    begin
      r = w;
      for (int j = 0; j < 8; j++)
        if ((j < (1 << size)) && be[j] && ((off + j) < 8)) r[8*(off+j) +: 8] = d[8*j +: 8];
      do_write_tb = r;
    end
  endfunction

  // fairness: while every client still has work queued the completed counts of any two clients may differ by a bounded amount only
  always @(posedge clk) begin
    if (rst_n && skew_en) begin : skew_blk
      integer mx, mn;
      reg active;
      mx = 0; mn = 1 << 30; active = 1'b1;
      for (int c = 0; c < NC; c++) begin
        if (comp_cnt[c] > mx) mx = comp_cnt[c];
        if (comp_cnt[c] < mn) mn = comp_cnt[c];
        if (q_hd[c] == q_tl[c]) active = 1'b0;
      end
      if (active && (mx - mn) > skew_max) skew_max = mx - mn;
    end
  end

  // ------------------------------------------------------------------ protocol monitors (SFB2 R2 / R4 / R11)
  reg                 p_m_v, p_o_v;
  reg [AW+3+64+8+MIDW+2:0] p_m_pl;
  reg [NC-1:0]        p_rsp_v;
  reg [NC*(TAGW+RIDW+CLW+64+1+4)-1:0] p_rsp_pl;
  reg [NC*(TAGW+RIDW+CLW+64+1+4)-1:0] cur_rsp_pl;
  always_comb begin
    for (int d = 0; d < NC; d++)
      cur_rsp_pl[d*(TAGW+RIDW+CLW+64+1+4) +: (TAGW+RIDW+CLW+64+1+4)] =
        {rsp_tag[d*TAGW +: TAGW], rsp_rid[d*RIDW +: RIDW], rsp_src[d*CLW +: CLW], rsp_old[d*64 +: 64], rsp_succ[d], rsp_status[d*4 +: 4]};
  end
  wire [AW+3+64+8+MIDW+2:0] m_pl = {m_req_we, m_req_addr, m_req_size, m_req_wdata, m_req_be, m_req_id, m_req_prot};
  always @(posedge clk) begin
    if (!rst_n) begin
      chk(!m_req_valid, "memory request valid during reset");
      chk(rsp_valid == {NC{1'b0}}, "completion valid during reset");
      chk(!o_rsp_valid, "ordinary response valid during reset");
      chk(cmd_ready == {NC{1'b0}}, "cmd_ready during reset");
      chk(!o_req_ready, "ordinary request ready during reset");
      p_m_v <= 1'b0; p_rsp_v <= {NC{1'b0}};
    end else begin
      if (p_m_v) begin chk(m_req_valid, "memory request withdrawn while stalled (SFB2 R2)"); chk(m_pl == p_m_pl, "memory request payload changed while stalled (SFB2 R2)"); end
      p_m_v  <= m_req_valid && !m_req_ready;
      p_m_pl <= m_pl;
      for (int d = 0; d < NC; d++) begin
        if (p_rsp_v[d]) begin
          chk(rsp_valid[d], "completion withdrawn while stalled (SFB2 R4)");
          chk(cur_rsp_pl[d*(TAGW+RIDW+CLW+64+1+4) +: (TAGW+RIDW+CLW+64+1+4)] == p_rsp_pl[d*(TAGW+RIDW+CLW+64+1+4) +: (TAGW+RIDW+CLW+64+1+4)],
              "completion payload changed while stalled (SFB2 R4)");
        end
        p_rsp_v[d] <= rsp_valid[d] && !rsp_ready[d];
      end
      p_rsp_pl <= cur_rsp_pl;
      // locks: no two contexts ever hold the same granule
      for (int i = 0; i < NCTX; i++)
        for (int j = i + 1; j < NCTX; j++)
          if (lk_valid_o[i] && lk_valid_o[j]) chk(lk_key_o[i*KEYW +: KEYW] != lk_key_o[j*KEYW +: KEYW], "two contexts hold the same lock granule");
    end
  end

  // ------------------------------------------------------------------ ordinary master (loads / stores / DMA-like traffic)
  integer    ord_pct;                                   // probability of issuing per cycle
  integer    ord_hot_pct;                               // probability that the address is inside the atomic window
  integer    ord_wr_pct;
  reg        ord_en;
  integer    ord_n_req, ord_n_rsp, ord_n_cancel;
  reg [31:0] of_addr [0:255];
  reg        of_we   [0:255];
  reg [2:0]  of_size [0:255];
  reg        of_legal[0:255];
  reg [63:0] of_exp  [0:255];
  reg        of_has_exp [0:255];
  integer    of_h, of_t, of_acc_h;                      // request order, accepted-at-memory order for the expected data
  reg        ord_illegal_en;
  reg        o_rsp_ready_pct_en;
  integer    o_rsp_pct;

  always @(posedge clk) begin
    if (!rst_n) begin
      o_req_valid <= 1'b0;
      o_rsp_ready <= 1'b0;
      of_h = 0; of_t = 0; of_acc_h = 0;
    end else begin
      o_rsp_ready <= pct(o_rsp_pct);
      // expected data for ordinary reads: captured when the memory accepts the request (gm is the memory content at that instant)
      if (m_req_valid && m_req_ready && m_req_id[MIDW-1] && !m_req_we) begin : cap_blk
        integer wix;
        reg [63:0] v;
        wix = (32'(m_req_addr) >> 3) % WORDS;
        v = gm[wix] >> (8 * m_req_addr[2:0]);
        case (m_req_size)
          3'd0: v = v & 64'hFF;
          3'd1: v = v & 64'hFFFF;
          3'd2: v = v & 64'hFFFF_FFFF;
          default: v = v;
        endcase
        // find the oldest legal request without expected data
        while (of_acc_h < of_t && !of_legal[of_acc_h % 256]) of_acc_h = of_acc_h + 1;
        if (of_acc_h < of_t) begin of_exp[of_acc_h % 256] = v; of_has_exp[of_acc_h % 256] = 1'b1; of_acc_h = of_acc_h + 1; end
        else fail("ordinary read accepted at memory that the master never issued");
      end else if (m_req_valid && m_req_ready && m_req_id[MIDW-1] && m_req_we) begin
        while (of_acc_h < of_t && !of_legal[of_acc_h % 256]) of_acc_h = of_acc_h + 1;
        if (of_acc_h < of_t) begin of_has_exp[of_acc_h % 256] = 1'b1; of_exp[of_acc_h % 256] = 64'd0; of_acc_h = of_acc_h + 1; end
        else fail("ordinary write accepted at memory that the master never issued");
      end
      // request handshake
      if (o_req_valid && o_req_ready) begin
        o_req_valid <= 1'b0;
      end
      if ((!o_req_valid || o_req_ready) && ord_en && pct(ord_pct) && (of_t - of_h) < 200) begin : gen_blk
        reg [31:0] a;
        reg [2:0]  sz;
        reg        we, legal;
        sz = 3'(rnd(4));
        we = pct(ord_wr_pct);
        if (pct(ord_hot_pct)) a = WIN_BASE + rnd(32) * 8 + rnd(8);
        else a = rnd(WORDS * 8);
        if (ord_fixed) begin a = ord_fixed_addr; sz = 3'd3; end
        legal = 1'b1;
        if (ord_illegal_en && pct(20)) begin
          if (pct(50)) begin sz = 3'(4 + rnd(4)); legal = 1'b0; end
          else begin a = a | 32'd1; sz = 3'd3; legal = 1'b0; end
        end else begin
          a = a & ~((32'd1 << sz) - 1);          // naturally aligned
        end
        o_req_valid <= 1'b1; o_req_we <= we; o_req_addr <= a; o_req_size <= sz; o_req_id <= OIDW'(of_t);
        o_req_wdata <= rnd64(0); o_req_be <= (we && pct(30)) ? 8'(rnd(256)) : 8'hFF; o_req_prot <= 2'b11;
        of_addr[of_t % 256] = a; of_we[of_t % 256] = we; of_size[of_t % 256] = sz; of_legal[of_t % 256] = legal; of_has_exp[of_t % 256] = 1'b0;
        of_t = of_t + 1;
        ord_n_req = ord_n_req + 1;
      end
      // response check (in request order)
      if (o_rsp_valid && o_rsp_ready) begin : ordrsp
        chk(of_h < of_t, "ordinary response with no request outstanding");
        if (of_h < of_t) begin
          chk(o_rsp_id == OIDW'(of_h), "ordinary response out of order / wrong id");
          chk(o_rsp_we == of_we[of_h % 256], "ordinary response type differs");
          if (of_legal[of_h % 256]) begin
            chk(o_rsp_status == 4'd0, "legal ordinary request answered with an error");
            if (!of_we[of_h % 256] && of_has_exp[of_h % 256])
              chk(o_rsp_rdata == of_exp[of_h % 256], "ordinary read data differs from the memory content at its acceptance");
          end else begin
            chk(o_rsp_status != 4'd0, "illegal ordinary request answered without an error");
            chk(o_rsp_rdata == 64'd0, "failed ordinary request returned data");
          end
          of_h = of_h + 1;
          ord_n_rsp = ord_n_rsp + 1;
        end
      end
    end
  end

  // ------------------------------------------------------------------ helpers for tests
  task automatic wait_cycles(input integer n);
    integer k;
    begin for (k = 0; k < n; k++) @(posedge clk); end
  endtask

  function automatic bit all_done(input integer dummy);
    bit r;
    begin
      r = 1'b1;
      for (int c = 0; c < NC; c++) begin
        if (q_hd[c] != q_tl[c] || cv[c]) r = 1'b0;
      end
      if (n_completed != n_pushed - n_cancelled) r = 1'b0;
      all_done = r;
    end
  endfunction

  task automatic dump_state;
    begin
      $display("  --- state dump at %0t", $time);
      $display("  ctx_st=%h lk_valid=%b lk_key0=%h  m_req v/r/we=%b/%b/%b id=%h addr=%h  m_rsp_v=%b", dut.cx_st, lk_valid_o, lk_key_o[KEYW-1:0],
               m_req_valid, m_req_ready, m_req_we, m_req_id, m_req_addr, m_rsp_valid);
      $display("  o_req v/r/we=%b/%b/%b addr=%h size=%0d  o_rsp_v=%b o_wait=%b hold=%b of_h=%0d of_t=%0d (dut %0d..%0d) ord lk_v=%b lk_i=%0d",
               o_req_valid, o_req_ready, o_req_we, o_req_addr, o_req_size, o_rsp_valid, dut.u_ord.o_wait_q, dut.hold_valid,
               of_h, of_t, dut.u_ord.of_h, dut.u_ord.of_t, dut.u_ord.lk_v, dut.u_ord.lk_i);
      $display("  resv_v=%b hd_valid=%b elig=%b h_lock=%b h_hold=%b  free_any=%b", dut.resv_v, dut.hd_valid, dut.elig, dut.h_lock, dut.h_hold, dut.free_any);
      $display("  q empty=%b rsp_valid=%b", dut.q_empty, rsp_valid);
    end
  endtask

  task automatic drain(input integer max_cycles);
    integer k;
    begin
      k = 0;
      ord_en = 1'b0;
      while (!(all_done(0) && (of_h == of_t) && !o_req_valid) && k < max_cycles) begin @(posedge clk); k++; end
      if (k >= max_cycles) begin fail("DEADLOCK / timeout: commands or ordinary requests did not complete"); dump_state(); end
      wait_cycles(6);
    end
  endtask

  task automatic final_checks(input [8*32-1:0] name);
    integer bad;
    begin
      drain(200000);
      chk(idle_w, "engine not idle after drain");
      chk(lk_valid_o == {NCTX{1'b0}}, "lock table not empty after drain");
      chk(n_completed + n_cancelled == n_pushed, "commands pushed != completed + cancelled");
      bad = 0;
      for (int w = 0; w < WORDS; w++) if (mem.mem[w] !== gm[w]) bad = bad + 1;
      chk(bad == 0, "memory image differs from the golden image (extraneous or missing write)");
      chk(viol_cnt == 0, "exclusivity violations were recorded");
      for (int c = 0; c < NC; c++) for (int t = 0; t < 256; t++) if (rc_v[c][t] && rc_acc[c][t] && !(rc_com[c][t] || rc_est[c][t] != ST_OK)) begin
        // outstanding but never completed
      end
      $display("[%0t] %0s: pushed=%0d completed=%0d commits=%0d  mem rd/wr atomic=%0d/%0d ordinary=%0d/%0d  checks=%0d errors=%0d",
               $time, name, n_pushed, n_completed, n_commits, rd_atomic_cnt, wr_atomic_cnt, rd_ord_cnt, wr_ord_cnt, n_checks, n_errors);
    end
  endtask

  task automatic init_state;
    begin
      for (int c = 0; c < NC; c++) begin
        q_hd[c] = 0; q_tl[c] = 0; seq_next[c] = 0; cur[c] = 0; last_dlv_seq[c] = -1;
        for (int t = 0; t < 256; t++) begin rc_v[c][t] = 1'b0; rc_acc[c][t] = 1'b0; rc_com[c][t] = 1'b0; end
      end
      for (int i = 0; i < 16; i++) n_status[i] = 0;
      for (int c = 0; c < NC; c++) comp_cnt[c] = 0;
      skew_max = 0; skew_en = 1'b0; inv_cnt = 0;
      n_pushed = 0; n_completed = 0; n_cancelled = 0; n_commits = 0; n_errors = 0; n_checks = 0; viol_cnt = 0;
      wr_atomic_cnt = 0; wr_ord_cnt = 0; rd_atomic_cnt = 0; rd_ord_cnt = 0; ticket_en = 0; ticket_dups = 0; ord_n_req = 0; ord_n_rsp = 0;
      for (int w = 0; w < WORDS; w++) begin gm[w] = 64'd0; mem.mem[w] = 64'd0; end
      for (int i = 0; i < 65536; i++) ticket_seen[i] = 1'b0;
    end
  endtask

  task automatic default_config;
    begin
      win_base_r = WIN_BASE; win_limit_r = WIN_LIMIT;
      // client c is bound to domain c (mod ND) and to the shared domain ND-1
      for (int c = 0; c < NC; c++) begin
        port_dom_mask_r[c*ND +: ND] = ({ND{1'b0}} | (1 << (c % ND)) | (1 << (ND - 1)));
        dest_allow_r[c*NC +: NC] = {NC{1'b1}};
      end
      atom_prot_r = 2'b11; quiesce_r = 1'b0; diag_clr_r = 1'b0; perf_clr_r = 1'b0;
      for (int d = 0; d < ND; d++) begin
        for (int k = 0; k < 4; k++) begin gr_v[d][k] = 1'b0; gr_b[d][k] = 0; gr_l[d][k] = 0; gr_r[d][k] = 1'b0; gr_w[d][k] = 1'b0; end
        gr_v[d][0] = 1'b1; gr_b[d][0] = WIN_BASE; gr_l[d][0] = WIN_LIMIT; gr_r[d][0] = 1'b1; gr_w[d][0] = 1'b1;   // whole window RW
      end
      mem_rdy_pct = 8'd100; mem_lat_pct = 8'd0; mem_lat_max = 4'd0;
      inj_rd_en = 1'b0; inj_wr_en = 1'b0; inj_rd_word = 0; inj_wr_word = 0;
      cmd_gap_pct = 0; cmd_gap_max = 1; rsp_rdy_pct = 100;
      ord_en = 1'b0; ord_pct = 30; ord_hot_pct = 70; ord_wr_pct = 50; ord_illegal_en = 1'b0; o_rsp_pct = 100; ord_fixed = 1'b0; ord_fixed_addr = WIN_BASE; ord_wait_max = 0; ord_acc_in_phase = 0;
    end
  endtask

  task automatic do_reset(input integer cycles);
    begin
      rst_n = 1'b0;
      wait_cycles(cycles);
      rst_n = 1'b1;
      wait_cycles(2);
    end
  endtask

  task automatic randomize_knobs;
    integer r;
    begin
      r = rnd(4);
      mem_rdy_pct = (r == 0) ? 8'd100 : (r == 1) ? 8'd75 : (r == 2) ? 8'd40 : 8'd90;
      mem_lat_pct = (rnd(2) == 0) ? 8'd0 : 8'd30;
      mem_lat_max = 4'(1 + rnd(5));
      cmd_gap_pct = (rnd(3) == 0) ? 0 : 30; cmd_gap_max = 1 + rnd(6);
      rsp_rdy_pct = (rnd(3) == 0) ? 100 : 50 + rnd(50);
      o_rsp_pct = (rnd(2) == 0) ? 100 : 60;
    end
  endtask

  // hot addresses used by the contention tests
  function automatic [31:0] hot(input integer k);
    hot = WIN_BASE + 8 * k;
  endfunction

  // ------------------------------------------------------------------ random operation generator
  function automatic [63:0] rnd_val(input bit wide);
    integer r;
    reg [63:0] v;
    begin
      r = rnd(10);
      case (r)
        0: v = 64'd0;
        1: v = 64'd1;
        2: v = 64'hFFFF_FFFF_FFFF_FFFF;
        3: v = 64'h8000_0000_0000_0000;
        4: v = 64'h7FFF_FFFF_FFFF_FFFF;
        5: v = 64'h0000_0000_8000_0000;
        6: v = 64'h0000_0000_7FFF_FFFF;
        7: v = 64'h0000_0000_FFFF_FFFF;
        default: v = rnd64(0);
      endcase
      rnd_val = wide ? v : (v & 64'hFFFF_FFFF);
    end
  endfunction

  task automatic push_random(input integer c, input integer p_bad);
    reg [3:0]  op;
    reg [31:0] a;
    reg        wide;
    reg [63:0] opd, cmp;
    integer    dom, dest;
    reg [1:0]  wd;
    reg        aq, rl;
    begin
      // opcode among the enabled ones
      op = 4'(1 + rnd(10));
      while (!OP_EN[op]) op = 4'(1 + rnd(10));
      wide = (W64_EN != 0) && pct(50);
      wd = wide ? 2'd1 : 2'd0;
      if (pct(75)) a = hot(rnd(4)) + (wide ? 0 : 4 * rnd(2)); else a = WIN_BASE + 8 * rnd(32) + (wide ? 0 : 4 * rnd(2));
      opd = rnd_val(wide);
      cmp = (op == OP_CAS && pct(50)) ? gm[(a >> 3) % WORDS] >> (wide ? 0 : 8 * (a & 4)) : rnd_val(wide);   // CAS often matches the current value
      if (!wide) cmp = cmp & 64'hFFFF_FFFF;
      dom = (c % ND == ND - 1 || pct(30)) ? ND - 1 : c % ND;
      dest = pct(85) ? c : rnd(NC);
      aq = pct(5); rl = pct(5);
      if (pct(p_bad)) begin
        case (rnd(7))
          0: op = pct(50) ? 4'd0 : 4'(11 + rnd(5));
          1: wd = 2'(2 + rnd(2));
          2: a = a | (wide ? 32'd4 : 32'd2);
          3: a = pct(50) ? 32'(WIN_BASE - 8) : 32'(WIN_LIMIT);
          4: dom = (c % ND == 0) ? 1 : 0;
          5: dest = NC + rnd(3);
          default: begin op = 4'd0; end
        endcase
      end
      push(c, op, a, opd, cmp, wd, dom, dest, aq, rl);
    end
  endtask

  // ------------------------------------------------------------------ tests
  integer t_n, t_i;
  task automatic test_smoke;
    begin
      atom(0, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);
      atom(0, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);
      atom(0, OP_CAS,  hot(0), 64'd77, 64'd2, 1'b0);
      atom(0, OP_CAS,  hot(0), 64'd99, 64'd5, 1'b0);
      final_checks("smoke");
      chk(mem.mem[(hot(0) >> 3)][31:0] == 32'd77, "smoke: final value");
    end
  endtask

  task automatic test_single;
    begin
      atom(0, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);
      final_checks("single");
      chk(mem.mem[(hot(0) >> 3)] == 64'd1, "single increment: memory value is 1");
    end
  endtask

  task automatic test_cas;
    begin
      // success, failure, success-after-failure, in different clients; 32-bit and 64-bit
      atom(0, OP_FADD, hot(1), 64'd10, 64'd0, 1'b0);
      atom(0, OP_CAS, hot(1), 64'd11, 64'd10, 1'b0);          // success  10 -> 11
      atom(0, OP_CAS, hot(1), 64'd12, 64'd10, 1'b0);          // failure  mem is 11
      atom(0, OP_CAS, hot(1), 64'd12, 64'd11, 1'b0);          // success  11 -> 12
      if (W64_EN != 0) begin
        atom(1, OP_FADD, hot(2), 64'h1234_5678_9ABC_DEF0, 64'd0, 1'b1);
        atom(1, OP_CAS, hot(2), 64'hAAAA_BBBB_CCCC_DDDD, 64'h1234_5678_9ABC_DEF0, 1'b1);   // success
        atom(1, OP_CAS, hot(2), 64'h0, 64'h1234_5678_9ABC_DEF0, 1'b1);                       // failure
        atom(1, OP_CAS, hot(2), 64'h0, 64'h0000_0000_9ABC_DEF0, 1'b0);                       // 32-bit compare of the low half only: fails (low half differs now)
      end
      final_checks("cas");
    end
  endtask

  // all clients increment the same counter: unique tickets, no lost update
  task automatic test_ticket;
    integer per;
    begin
      per = 40;
      ticket_en = 1; ticket_word = hot(0);
      for (int k = 0; k < per; k++)
        for (int c = 0; c < NC; c++) atom(c, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);
      final_checks("ticket");
      chk(mem.mem[(hot(0) >> 3)][31:0] == 32'(per * NC), "ticket: final counter equals the number of increments (no lost update)");
      chk(ticket_dups == 0, "ticket: duplicate old value returned to two increments");
      for (int k = 0; k < per * NC; k++) chk(ticket_seen[k], "ticket: some old value 0..N-1 was never returned");
    end
  endtask

  task automatic test_overflow;
    begin
      atom(0, OP_FADD, hot(0), 64'hFFFF_FFFF, 64'd0, 1'b0);
      atom(0, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);                  // wraps to 0 (32-bit)
      atom(0, OP_FADD, hot(1), 64'h7FFF_FFFF, 64'd0, 1'b0);
      atom(0, OP_FADD, hot(1), 64'd1, 64'd0, 1'b0);                  // signed overflow -> 0x80000000, no trap
      atom(0, OP_FADD, hot(2), 64'h8000_0000, 64'd0, 1'b0);
      atom(0, OP_FADD, hot(2), 64'h8000_0000, 64'd0, 1'b0);          // wraps to 0
      // a 32-bit operation on the upper half must not disturb the lower half and vice versa
      atom(0, OP_FADD, hot(3),     64'h1111_1111, 64'd0, 1'b0);
      atom(0, OP_FADD, hot(3) + 4, 64'hFFFF_FFFF, 64'd0, 1'b0);
      atom(0, OP_FADD, hot(3) + 4, 64'd1, 64'd0, 1'b0);              // upper half wraps to 0, carry must NOT reach anything
      if (W64_EN != 0) begin
        atom(1, OP_FADD, hot(4), 64'hFFFF_FFFF_FFFF_FFFF, 64'd0, 1'b1);
        atom(1, OP_FADD, hot(4), 64'd1, 64'd0, 1'b1);                // 64-bit wrap
        atom(1, OP_FADD, hot(5), 64'h0000_0000_FFFF_FFFF, 64'd0, 1'b1);
        atom(1, OP_FADD, hot(5), 64'd1, 64'd0, 1'b1);                // carry crosses bit 32 in a 64-bit op
        atom(1, OP_FADD, hot(6), 64'h7FFF_FFFF_FFFF_FFFF, 64'd0, 1'b1);
        atom(1, OP_FADD, hot(6), 64'd1, 64'd0, 1'b1);
      end
      final_checks("overflow");
      chk(mem.mem[hot(0) >> 3][31:0] == 32'd0, "overflow: 32-bit wrap");
      chk(mem.mem[hot(1) >> 3][31:0] == 32'h8000_0000, "overflow: signed overflow wraps");
      chk(mem.mem[hot(3) >> 3] == 64'h0000_0000_1111_1111, "overflow: upper-half wrap leaves the lower half intact");
    end
  endtask

  task automatic test_minmax;
    reg [63:0] vals32 [0:5];
    reg [63:0] vals64 [0:5];
    integer a, b, ops;
    reg [3:0] mm [0:3];
    begin
      if (!(OP_EN[OP_MIN] && OP_EN[OP_MAX] && OP_EN[OP_MINU] && OP_EN[OP_MAXU] && OP_EN[OP_SWAP])) begin
        $display("          minmax skipped: opcodes not enabled in this configuration");
        final_checks("minmax(skipped)");
        return;
      end
      vals32[0] = 64'h0000_0000; vals32[1] = 64'h0000_0001; vals32[2] = 64'h7FFF_FFFF; vals32[3] = 64'h8000_0000; vals32[4] = 64'hFFFF_FFFF; vals32[5] = 64'hFFFF_FFFE;
      vals64[0] = 64'h0; vals64[1] = 64'h1; vals64[2] = 64'h7FFF_FFFF_FFFF_FFFF; vals64[3] = 64'h8000_0000_0000_0000; vals64[4] = 64'hFFFF_FFFF_FFFF_FFFF; vals64[5] = 64'h0000_0000_8000_0000;
      mm[0] = OP_MIN; mm[1] = OP_MAX; mm[2] = OP_MINU; mm[3] = OP_MAXU;
      for (a = 0; a < 6; a++)
        for (b = 0; b < 6; b++)
          for (ops = 0; ops < 4; ops++) begin
            atom((a + b) % NC, OP_SWAP, hot(0), vals32[a], 64'd0, 1'b0);
            atom((a + b) % NC, mm[ops], hot(0), vals32[b], 64'd0, 1'b0);
            if (W64_EN != 0) begin
              atom((a + b) % NC, OP_SWAP, hot(1), vals64[a], 64'd0, 1'b1);
              atom((a + b) % NC, mm[ops], hot(1), vals64[b], 64'd0, 1'b1);
            end
          end
      final_checks("minmax");
    end
  endtask

  task automatic test_w64;
    begin
      for (int k = 0; k < 150; k++) begin
        integer c;
        c = rnd(NC);
        push_random(c, 0);
      end
      final_checks("w64");
    end
  endtask

  task automatic test_random(input integer n, input integer p_bad, input bit with_ord);
    integer k;
    begin
      for (int round = 0; round < 6; round++) begin
        randomize_knobs();
        ord_en = with_ord; ord_pct = 20 + rnd(60); ord_hot_pct = 60 + rnd(40); ord_wr_pct = 30 + rnd(50);
        for (k = 0; k < n / 6; k++) begin
          push_random(rnd(NC), p_bad);
          if (rnd(8) == 0) wait_cycles(rnd(6));
        end
        // let the ordinary master run concurrently with the drain of this round, then quiet it
        wait_cycles(40);
        ord_en = 1'b0;
      end
      final_checks("random");
    end
  endtask

  // ordinary writers against atomic incrementers on the SAME words: the serial order must remain consistent
  task automatic test_contend;
    begin
      ticket_en = 0;
      ord_en = 1'b1; ord_pct = 90; ord_hot_pct = 100; ord_wr_pct = 70; o_rsp_pct = 100;
      for (int k = 0; k < 60; k++)
        for (int c = 0; c < NC; c++) begin
          atom(c, OP_FADD, hot(rnd(2)), 64'd1, 64'd0, 1'b0);
          if (rnd(4) == 0) atom(c, OP_CAS, hot(rnd(2)), rnd64(0) & 64'hFFFF, gm[(hot(0)>>3)] & 64'hFFFF, 1'b0);
        end
      wait_cycles(200);
      final_checks("contend");
    end
  endtask

  task automatic test_perm;
    begin
      // the domain of every client gets a split window: RW / read-only / write-only
      for (int c = 0; c < NC; c++) begin : split
        integer d;
        d = c % ND;
        for (int k = 0; k < 4; k++) gr_v[d][k] = 1'b0;
        gr_v[d][0] = 1'b1; gr_b[d][0] = WIN_BASE;         gr_l[d][0] = WIN_BASE + 32'h80;  gr_r[d][0] = 1'b1; gr_w[d][0] = 1'b1;
        gr_v[d][1] = 1'b1; gr_b[d][1] = WIN_BASE + 32'h80; gr_l[d][1] = WIN_BASE + 32'hC0;  gr_r[d][1] = 1'b1; gr_w[d][1] = 1'b0;
        gr_v[d][2] = 1'b1; gr_b[d][2] = WIN_BASE + 32'hC0; gr_l[d][2] = WIN_BASE + 32'h100; gr_r[d][2] = 1'b0; gr_w[d][2] = 1'b1;
      end
      wait_cycles(2);
      for (int c = 0; c < NC; c++) begin
        integer dm;
        dm = (c % ND);
        // allowed
        push(c, OP_FADD, WIN_BASE + 8,        64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        // read-only region, write-only region (only meaningful for domain 2)
        push(c, OP_FADD, WIN_BASE + 32'h88,    64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        push(c, OP_SWAP, WIN_BASE + 32'hC8,    64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        // domain not bound to the port
        push(c, OP_FADD, WIN_BASE + 8,        64'd1, 64'd0, 2'd0, (c + 1) % ND == ND - 1 ? (c + 2) % ND : (c + 1) % ND, c, 1'b0, 1'b0);
        // outside the window (below, at the limit, far away)
        push(c, OP_FADD, WIN_BASE - 8,        64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        push(c, OP_FADD, WIN_LIMIT,           64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        push(c, OP_FADD, 32'h0000_0000,       64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        // misaligned, bad width, bad opcode, bad destination
        push(c, OP_FADD, WIN_BASE + 2,        64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        push(c, OP_FADD, WIN_BASE + 4,        64'd1, 64'd0, 2'd1, dm, c, 1'b0, 1'b0);
        push(c, OP_FADD, WIN_BASE + 8,        64'd1, 64'd0, 2'd2, dm, c, 1'b0, 1'b0);
        push(c, 4'd0,    WIN_BASE + 8,        64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        push(c, 4'd11,   WIN_BASE + 8,        64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
        // and a legal one afterwards: rejected commands must not disturb the queue
        push(c, OP_FADD, WIN_BASE + 16,       64'd1, 64'd0, 2'd0, dm, c, 1'b0, 1'b0);
      end
      // destination restriction: client 0 may only name itself
      dest_allow_r[0*NC +: NC] = {{(NC-1){1'b0}}, 1'b1};
      wait_cycles(2);
      push(0, OP_FADD, WIN_BASE + 24, 64'd1, 64'd0, 2'd0, 0, 0, 1'b0, 1'b0);
      push(0, OP_FADD, WIN_BASE + 24, 64'd1, 64'd0, 2'd0, 0, NC - 1, 1'b0, 1'b0);        // denied -> completion returns to port 0
      final_checks("perm");
      chk(diag_valid_o, "perm: diagnostic record not set after rejected commands");
      for (int st = 1; st <= 7; st++) chk(n_status[st] > 0, "perm: a status code was never produced");
    end
  endtask

  task automatic test_errors;
    begin
      // memory read error on word hot(0), write error on word hot(2)
      inj_rd_en = 1'b1; inj_rd_word = hot(0) >> 3;
      inj_wr_en = 1'b1; inj_wr_word = hot(2) >> 3;
      mem.poke(hot(1) >> 3, 64'd5); gm[hot(1) >> 3] = 64'd5;
      atom(0, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0); set_est(0, ST_READ);     // read fails: AST_READ, nothing written
      atom(0, OP_FADD, hot(2), 64'd1, 64'd0, 1'b0); set_est(0, ST_WRITE);    // read ok, write fails: AST_WRITE (location indeterminate)
      atom(1, OP_FADD, hot(1), 64'd1, 64'd0, 1'b0);                          // unaffected
      atom(1, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0); set_est(1, ST_READ);     // again: the engine does NOT retry on its own
      wait_cycles(100);
      // we must adapt the golden image/predictions: errors are reported via status, so use a custom check
      drain(100000);
      chk(n_status[ST_READ] == 2, "errors: expected two AST_READ completions");
      chk(n_status[ST_WRITE] == 1, "errors: expected one AST_WRITE completion");
      chk(mem.mem[hot(0) >> 3] == 64'd0, "errors: a failed read must leave the word untouched");
      chk(mem.mem[hot(1) >> 3] == 64'd6, "errors: a healthy word was updated exactly once");
      inj_rd_en = 1'b0; inj_wr_en = 1'b0;
      atom(0, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);            // lock was released: a later operation on the word works
      final_checks("errors");
      chk(mem.mem[hot(0) >> 3] == 64'd1, "errors: later operation on the previously failed word");
    end
  endtask

  task automatic test_queue;
    begin
      // saturate: completions stalled hard, memory slow, many commands per client; nothing may be lost or duplicated
      rsp_rdy_pct = 5; mem_rdy_pct = 8'd30;
      for (int k = 0; k < 80; k++) for (int c = 0; c < NC; c++) atom(c, OP_FADD, hot(c), 64'd1, 64'd0, 1'b0);
      wait_cycles(300);
      chk(perf_o[sf_atomic_pkg::PF_CMD_STALL*32 +: 32] > 0 || PERF == 0, "queue: no ingress stall observed under saturation");
      rsp_rdy_pct = 100;
      final_checks("queue");
      for (int c = 0; c < NC; c++) if (c < 8) chk(mem.mem[hot(c) >> 3][31:0] == 32'd80, "queue: every increment applied exactly once");
    end
  endtask

  // ordering bits: a release command waits for every older command of its client; acquire holds back younger ones
  task automatic test_order;
    integer r;
    begin
      if (!OP_EN[OP_SWAP]) begin $display("          order skipped: SWAP not enabled"); final_checks("order(skipped)"); return; end
      for (r = 0; r < 5; r++) begin
        randomize_knobs();
        if (r >= 1) begin mem_rdy_pct = (r == 1) ? 8'd35 : (r == 2) ? 8'd60 : 8'd45; mem_lat_pct = 8'd40; mem_lat_max = 4'd4; end
        ord_en = (r >= 2); ord_pct = 50; ord_hot_pct = 100; ord_wr_pct = 60;
        for (int k = 0; k < 24; k++) begin
          // older commands on different granules can run in parallel; the rl / aq bits must still order them
          push(0, OP_FADD, hot(k % 8), 64'd1, 64'd0, 2'd0, 0, 0, 1'b0, 1'b0);
          push(0, OP_FADD, hot((k + 3) % 8), 64'd1, 64'd0, 2'd0, 0, 0, 1'b0, 1'b0);
          push(0, OP_SWAP, hot(8), 64'(k), 64'd0, 2'd0, 0, 0, 1'b0, 1'b1);        // rl: after all older commands of the client
          push(0, OP_FADD, hot(9), 64'd1, 64'd0, 2'd0, 0, 0, 1'b1, 1'b0);         // aq: nothing younger commits before it
          push(0, OP_FADD, hot(10), 64'd1, 64'd0, 2'd0, 0, 0, 1'b0, 1'b0);
          push(0, OP_FADD, hot(11), 64'd1, 64'd0, 2'd0, 0, 0, 1'b0, 1'b0);
          if (NC > 1) push(1, OP_FADD, hot(k % 3), 64'd1, 64'd0, 2'd0, 1, 1, 1'b0, 1'b0);   // background traffic of another client
        end
        wait_cycles(30);
        drain(200000);
      end
      final_checks("order");
      $display("          order: %0d commits happened out of per-client program order (permitted without aq/rl; none may violate an aq/rl bit)", inv_cnt);
      chk(mem.mem[hot(8) >> 3][31:0] == 32'd23, "order: the last release store wins");
    end
  endtask

  // order stress: client 0 issues pairs  A(aq) B  and  X Y(rl)  while the other clients and an ordinary master keep the memory port busy.
  // Arbitration of the single memory port can let a YOUNGER command of the same client reach its write first; the aq / rl bits must
  // make that impossible, and the scoreboard flags any commit that violates a bit.
  task automatic test_orderx;
    integer k;
    begin
      mem_rdy_pct = 8'd50; mem_lat_pct = 8'd30; mem_lat_max = 4'd3; cmd_gap_pct = 0; rsp_rdy_pct = 100;
      ord_en = 1'b1; ord_pct = 60; ord_hot_pct = 100; ord_wr_pct = 60;
      for (k = 0; k < 400; k++) begin
        push(0, OP_FADD, hot(k % 6),       64'd1, 64'd0, 2'd0, 0, 0, 1'b1, 1'b0);          // A: acquire
        push(0, OP_FADD, hot(6 + (k % 6)), 64'd1, 64'd0, 2'd0, 0, 0, 1'b0, 1'b0);          // B: must not commit before A
        push(0, OP_FADD, hot(12 + (k % 5)), 64'd1, 64'd0, 2'd0, 0, 0, 1'b0, 1'b0);         // X
        push(0, OP_FADD, hot(17 + (k % 5)), 64'd1, 64'd0, 2'd0, 0, 0, 1'b0, 1'b1);         // Y: release, after X and everything older
        for (int c = 1; c < NC; c++) begin
          push(c, OP_FADD, hot(22 + c),  64'd1, 64'd0, 2'd0, c % ND, c, 1'b0, 1'b0);
          push(c, OP_FADD, hot(26 + c),  64'd1, 64'd0, 2'd0, c % ND, c, 1'b0, 1'b0);
        end
      end
      wait_cycles(50);
      drain(400000);
      final_checks("orderx");
      $display("          orderx: %0d commits out of per-client program order (none of them may violate an aq/rl bit)", inv_cnt);
    end
  endtask

  // starvation, both ways: ordinary writes vs atomics on the SAME word.  (liveness of the hold-off / reservation alternation)
  integer ord_wait_cnt, ord_wait_max, ord_acc_in_phase;
  reg        ord_fixed;
  reg [31:0] ord_fixed_addr;
  always @(posedge clk) begin
    if (!rst_n) begin ord_wait_cnt <= 0; end
    else begin
      if (o_req_valid && !o_req_ready) ord_wait_cnt <= ord_wait_cnt + 1;
      if (o_req_valid && o_req_ready) begin
        if (ord_wait_cnt > ord_wait_max) ord_wait_max <= ord_wait_cnt;
        ord_wait_cnt <= 0;
        ord_acc_in_phase <= ord_acc_in_phase + 1;
      end
    end
  end

  task automatic test_starve;
    integer k, t0;
    begin
      ord_fixed = 1'b1; ord_fixed_addr = hot(0);
      ord_wait_max = 0; ord_acc_in_phase = 0;
      // phase A: atomics saturate the word, an ordinary writer must still get through promptly
      ord_en = 1'b1; ord_pct = 100; ord_wr_pct = 100; ord_hot_pct = 100; o_rsp_pct = 100;
      for (k = 0; k < 40; k++) for (int c = 0; c < NC; c++) atom(c, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);
      t0 = 0;
      while (!all_done(0) && t0 < 60000) begin @(posedge clk); t0++; end
      chk(all_done(0), "starve A: the atomics did not finish while an ordinary writer hammered the same word (ordinary stream starves atomics)");
      $display("          starve A: %0d ordinary writes accepted during the atomic phase, longest ordinary wait %0d cycles, atomics took %0d cycles", ord_acc_in_phase, ord_wait_max, t0);
      chk(ord_acc_in_phase >= 20, "starve A: the ordinary writer made almost no progress (atomics starve the ordinary stream)");
      chk(ord_wait_max <= 24 + 6 * NC * (NCTX + 1), "starve A: an ordinary write waited unreasonably long for a locked word");
      // phase B: the ordinary writer saturates, a single atomic client needs a bounded time per operation
      ord_wait_max = 0; ord_acc_in_phase = 0;
      for (k = 0; k < 25; k++) atom(0, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);
      t0 = 0;
      while (!all_done(0) && t0 < 60000) begin @(posedge clk); t0++; end
      chk(all_done(0), "starve B: an atomic client could not complete while an ordinary stream hammered its word");
      $display("          starve B: 25 atomics completed in %0d cycles under a saturating ordinary writer (%0d ordinary accepted)", t0, ord_acc_in_phase);
      ord_fixed = 1'b0;
      final_checks("starve");
    end
  endtask

  task automatic test_quiesce;
    begin
      for (int k = 0; k < 20; k++) for (int c = 0; c < NC; c++) atom(c, OP_FADD, hot(c), 64'd1, 64'd0, 1'b0);
      wait_cycles(5);
      quiesce_r = 1'b1;
      wait_cycles(3);
      chk(cmd_ready == {NC{1'b0}}, "quiesce: cmd_ready must be 0");
      chk(!o_req_ready, "quiesce: ordinary ready must be 0");
      begin : q_wait
        integer k;
        k = 0;
        while (!idle_w && k < 20000) begin @(posedge clk); k++; end
        chk(idle_w, "quiesce: engine never became idle");
      end
      quiesce_r = 1'b0;
      final_checks("quiesce");
    end
  endtask

  // fairness: all clients saturate one word; every client must make progress, bounded relative difference
  task automatic test_fair;
    integer mx, mn;
    begin
      skew_en = 1'b1;
      for (int k = 0; k < 100; k++) for (int c = 0; c < NC; c++) atom(c, OP_FADD, hot(0), 64'd1, 64'd0, 1'b0);
      final_checks("fair");
      skew_en = 1'b0;
      $display("          fairness: max difference of completed operations between any two saturating clients = %0d (bound %0d)", skew_max, QD + NCTX + 2);
      chk(skew_max <= QD + NCTX + 2, "fair: a client was served noticeably less than another (starvation)");
      chk(mem.mem[hot(0) >> 3][31:0] == 32'(100 * NC), "fair: every client's increments were applied");
      if (PERF != 0) begin
        $display("          perf: committed=%0d cycles=%0d  qwait sum/max=%0d/%0d  lockwait sum/max=%0d/%0d  lat sum/max=%0d/%0d  contended=%0d",
                 perf_o[sf_atomic_pkg::PF_COMMITTED*32 +: 32], perf_o[sf_atomic_pkg::PF_CYCLES*32 +: 32],
                 perf_o[sf_atomic_pkg::PF_QWAIT_SUM*32 +: 32], perf_o[sf_atomic_pkg::PF_QWAIT_MAX*32 +: 32],
                 perf_o[sf_atomic_pkg::PF_LOCKWAIT_SUM*32 +: 32], perf_o[sf_atomic_pkg::PF_LOCKWAIT_MAX*32 +: 32],
                 perf_o[sf_atomic_pkg::PF_LAT_SUM*32 +: 32], perf_o[sf_atomic_pkg::PF_LAT_MAX*32 +: 32],
                 perf_o[sf_atomic_pkg::PF_CONTENDED*32 +: 32]);
      end
      mx = 0; mn = 1 << 30;
    end
  endtask

  // reset in the middle of activity, several times; the engine must come back clean, never double-execute, never answer for cancelled work
  task automatic test_reset;
    integer rr;
    integer k;
    begin
      for (rr = 0; rr < 8; rr++) begin
        randomize_knobs();
        ord_en = 1'b1; ord_pct = 40; ord_hot_pct = 80; ord_wr_pct = 50;
        for (k = 0; k < 60; k++) push_random(rnd(NC), 5);
        wait_cycles(10 + rnd(60));
        // ---- reset: abandon everything unfinished
        ord_en = 1'b0;
        rst_n = 1'b0;
        wait_cycles(1 + rnd(3));
        // every outstanding command is cancelled (its effect, if its write was accepted, persists in the golden image already)
        for (int c = 0; c < NC; c++) begin
          for (int t = 0; t < 256; t++) if (rc_v[c][t]) begin rc_v[c][t] = 1'b0; n_cancelled = n_cancelled + 1; end
          q_hd[c] = q_tl[c]; cv[c] = 1'b0;
          last_dlv_seq[c] = rc_seq_hi(c);
        end
        of_h = of_t; of_acc_h = of_t; o_req_valid = 1'b0;
        wait_cycles(1);
        rst_n = 1'b1;
        wait_cycles(3);
        chk(idle_w, "reset: engine not idle after reset");
        chk(lk_valid_o == {NCTX{1'b0}}, "reset: locks still held after reset");
        chk(cmd_ready == {NC{1'b1}}, "reset: queues not empty after reset");
        // sanity batch after the reset
        for (k = 0; k < 12; k++) push_random(rnd(NC), 0);
        drain(100000);
      end
      final_checks("reset");
    end
  endtask

  function automatic integer rc_seq_hi(input integer c);
    rc_seq_hi = seq_next[c] - 1;
  endfunction

  // negative control: two masters doing a NAIVE read-then-write increment through the same memory lose updates.  The testbench's
  // own memory model is not atomic across requests (and neither is MemoryMatrix: M4 / M5) -- this shows why the engine exists.
  task automatic test_naive;
    integer lost;
    reg [63:0] v;
    begin
      // two naive "software" incrementers against the model's array, interleaved cycle by cycle (no engine involved)
      mem.poke(hot(0) >> 3, 64'd0);
      lost = 0;
      for (int k = 0; k < 100; k++) begin
        v = mem.peek(hot(0) >> 3);          // master A reads
        // master B reads the same value before A writes: classic interleaving
        begin : nb
          reg [63:0] vb;
          vb = mem.peek(hot(0) >> 3);
          mem.poke(hot(0) >> 3, v + 1);     // A writes
          mem.poke(hot(0) >> 3, vb + 1);    // B writes: A's update is lost
        end
      end
      lost = 200 - mem.peek(hot(0) >> 3);
      $display("          naive read+write increments: 200 requested, memory holds %0d => %0d lost updates (negative control)", mem.peek(hot(0) >> 3), lost);
      chk(lost > 0, "naive: the negative control must lose updates on a non-atomic memory");
      for (int w = 0; w < WORDS; w++) gm[w] = mem.mem[w];
      // now the same through the engine: no loss
      for (int k = 0; k < 50; k++) begin atom(0, OP_FADD, hot(4), 64'd1, 64'd0, 1'b0); atom(1 % NC, OP_FADD, hot(4), 64'd1, 64'd0, 1'b0); end
      final_checks("naive");
      chk(mem.mem[hot(4) >> 3][31:0] == 32'd100, "naive: the engine does not lose updates");
    end
  endtask

  // ------------------------------------------------------------------ benchmark: throughput / latency / contention (machine readable "BENCH" lines)
  integer bench_t0, bench_cyc;
  task automatic bench_phase(input [8*10-1:0] name, input integer mode, input integer n_per);
    integer k, t;
    reg [31:0] a;
    reg [31:0] pcm, pcc, pqs, pqm, pls, plm, pts, ptm, pcn, pcs, pms, pcb, plo;
    begin
      perf_clr_r = 1'b1; wait_cycles(2); perf_clr_r = 1'b0; wait_cycles(1);
      bench_t0 = 0;
      for (k = 0; k < n_per; k++)
        for (int c = 0; c < NC; c++) begin
          case (mode)
            0: a = hot(0);                                  // every client on ONE word  (fully serialised)
            1: a = hot(c);                                  // every client on its OWN word (no lock conflict)
            default: a = WIN_BASE + 8 * rnd(32);            // random word of 32
          endcase
          atom(c, OP_FADD, a, 64'd1, 64'd0, 1'b0);
        end
      t = 0;
      while (!all_done(0) && t < 400000) begin @(posedge clk); t++; end
      bench_cyc = t;
      wait_cycles(4);
      pcm = perf_o[sf_atomic_pkg::PF_COMMITTED*32 +: 32];    pcc = perf_o[sf_atomic_pkg::PF_CYCLES*32 +: 32];
      pqs = perf_o[sf_atomic_pkg::PF_QWAIT_SUM*32 +: 32];    pqm = perf_o[sf_atomic_pkg::PF_QWAIT_MAX*32 +: 32];
      pls = perf_o[sf_atomic_pkg::PF_LOCKWAIT_SUM*32 +: 32]; plm = perf_o[sf_atomic_pkg::PF_LOCKWAIT_MAX*32 +: 32];
      pts = perf_o[sf_atomic_pkg::PF_LAT_SUM*32 +: 32];      ptm = perf_o[sf_atomic_pkg::PF_LAT_MAX*32 +: 32];
      pcn = perf_o[sf_atomic_pkg::PF_CONTENDED*32 +: 32];    pcs = perf_o[sf_atomic_pkg::PF_CMD_STALL*32 +: 32];
      pms = perf_o[sf_atomic_pkg::PF_MEM_STALL*32 +: 32];    pcb = perf_o[sf_atomic_pkg::PF_CTX_BUSY*32 +: 32];
      plo = perf_o[sf_atomic_pkg::PF_LOCK_OCC*32 +: 32];
      $display("BENCH mode=%0s NC=%0d NCTX=%0d MEM_LAT=%0d GRAN=%0d ops=%0d cycles=%0d opc_x1000=%0d lat_avg_x10=%0d lat_max=%0d qwait_avg_x10=%0d qwait_max=%0d lockwait_avg_x10=%0d lockwait_max=%0d contended=%0d cmd_stall=%0d mem_stall=%0d ctx_util_pct=%0d",
               name, NC, NCTX, MEM_LAT, LOCK_GRAN, pcm, bench_cyc, (pcm * 1000) / ((bench_cyc == 0) ? 1 : bench_cyc),
               (pts * 10) / ((pcm == 0) ? 1 : pcm), ptm, (pqs * 10) / ((pcm == 0) ? 1 : pcm), pqm, (pls * 10) / ((pcm == 0) ? 1 : pcm), plm, pcn, pcs, pms,
               (pcb * 100) / ((bench_cyc == 0 ? 1 : bench_cyc) * NCTX));
      final_checks("bench-phase");
    end
  endtask

  task automatic test_bench;
    begin
      bench_phase("same-word",  0, 100);
      bench_phase("own-word",   1, 100);
      bench_phase("random-32",  2, 100);
    end
  endtask

  // ------------------------------------------------------------------ main
  string tname;
  integer seed;
  initial begin
    rng = 64'h9E3779B97F4A7C15;
    seed = 1;
    if ($value$plusargs("seed=%d", seed)) rng = rng ^ (64'(seed) * 64'hD1B54A32D192ED03);
    rnd64(0); rnd64(0);
    tname = "smoke";
    void'($value$plusargs("test=%s", tname));
    default_config();
    init_state();
    do_reset(5);
    wait_cycles(5);
    case (tname)
      "smoke":    test_smoke();
      "single":   test_single();
      "cas":      test_cas();
      "ticket":   test_ticket();
      "overflow": test_overflow();
      "minmax":   test_minmax();
      "w64":      test_w64();
      "random":   test_random(300, 6, 1'b1);
      "randomx":  test_random(1200, 8, 1'b1);
      "contend":  test_contend();
      "perm":     test_perm();
      "errors":   test_errors();
      "queue":    test_queue();
      "order":    test_order();
      "quiesce":  test_quiesce();
      "fair":     test_fair();
      "reset":    test_reset();
      "naive":    test_naive();
      "starve":   test_starve();
      "orderx":   test_orderx();
      "bench":    test_bench();
      default: begin $display("unknown test %0s", tname); n_errors = n_errors + 1; end
    endcase
    if (n_errors == 0) $display("RESULT: PASS  test=%0s seed=%0d  checks=%0d", tname, seed, n_checks);
    else               $display("RESULT: FAIL  test=%0s seed=%0d  errors=%0d checks=%0d", tname, seed, n_errors, n_checks);
    $finish;
  end

  // global timeout
  initial begin
    #200000000;
    $display("RESULT: FAIL  (global timeout)");
    $finish;
  end
endmodule

`default_nettype wire
