// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: sf_atomic_perf
//
// Performance instrumentation.  Pure observer: it has inputs only from event strobes of the engine and cannot influence
// any functional signal (removing it, PERF = 0 in the engine, changes no output other than perf_o).
//
// Measures (indices in sf_atomic_pkg::PF_*), all 32-bit saturating, cleared by perf_clr_i:
//   queue wait        cycles from acceptance of a command to the grant that starts it          (sum, max)
//   lock acquisition  cycles the queue head was blocked by a lock / hold-off before it was granted (sum, max, contended count)
//   operation latency cycles from acceptance to delivery of the completion                      (sum, max)
//   contention        operations that waited at least one cycle for a lock; cycles ordinary writes were held by a lock
//   operations / cycle PF_COMMITTED / PF_CYCLES (and PF_DELIVERED / PF_CYCLES) -- the ratio is computed by software
//   stall cycles      ingress stalls (cmd_valid && !cmd_ready), memory-request stalls, ordinary-write stalls
//   utilisation       context-busy cycles, lock-occupancy cycles
// Per-operation timestamps are 16 bits (cycle counter modulo 2**16): a single operation older than 65 535 cycles wraps its
// own wait / latency sample (a saturation guard is not implemented; sums of the wrapped value are therefore a lower bound).
//
// Classification: SYNTHESIZABLE (observer).
// =============================================================================
`default_nettype none

module sf_atomic_perf #(
  parameter int NC    = 4,
  parameter int QD    = 4,
  localparam int CLW  = (NC > 1) ? $clog2(NC) : 1,
  localparam int PQW  = (QD > 1) ? $clog2(QD) : 1,
  localparam int NPOP = 4                      // width of the small population-count inputs
) (
  input  wire                  clk,
  input  wire                  rst_n,
  input  wire                  perf_clr_i,
  // queue events
  input  wire [NC-1:0]         ev_in,
  input  wire [NC*PQW-1:0]     ev_in_slot,
  input  wire [NC-1:0]         ev_rej,                // accepted already rejected
  input  wire                  ev_gnt,
  input  wire [CLW-1:0]        ev_gnt_client,
  input  wire [PQW-1:0]        ev_gnt_slot,
  input  wire [NC-1:0]         hd_lock_blk,           // head blocked by a lock / hold-off this cycle
  input  wire [NC-1:0]         ev_dlv,
  input  wire [NC*PQW-1:0]     ev_dlv_slot,
  // engine events
  input  wire [NPOP-1:0]       n_commit,
  input  wire [NPOP-1:0]       n_cas_fail,
  input  wire [NPOP-1:0]       n_memerr,
  input  wire                  ev_atm_rd,
  input  wire                  ev_atm_wr,
  input  wire                  ev_ord_rd,
  input  wire                  ev_ord_wr,
  input  wire                  ev_ord_err,
  input  wire                  ev_ord_blk,
  input  wire                  ev_coh_op,
  input  wire                  ev_resv,
  input  wire [NPOP-1:0]       n_mem_stall,
  input  wire [NPOP-1:0]       n_cmd_stall,
  input  wire [NPOP-1:0]       n_ctx_busy,
  input  wire [NPOP-1:0]       n_locks,
  output wire [sf_atomic_pkg::PF_N*32-1:0] perf_o
);
  localparam int PF_N = sf_atomic_pkg::PF_N;
  localparam int TSW  = 16;

  reg [PF_N*32-1:0] c_q;
  reg [TSW-1:0]     cyc_q;
  reg [NC*QD*TSW-1:0] tacc_q;
  reg [NC*TSW-1:0]  lw_q;                          // per-client running lock-wait cycles of the current head

  assign perf_o = c_q;

  function automatic [31:0] sat_add(input [31:0] a, input [31:0] b);
    reg [32:0] s;
    begin
      s = {1'b0, a} + {1'b0, b};
      sat_add = s[32] ? 32'hFFFF_FFFF : s[31:0];
    end
  endfunction

  // ------------------------------------------------------------------ per-cycle sample values
  reg [31:0] gnt_wait;
  reg [31:0] gnt_lw;
  reg [31:0] n_acc, n_rej, n_dlv;
  always_comb begin
    n_acc = 32'd0; n_rej = 32'd0; n_dlv = 32'd0;
    gnt_wait = 32'd0; gnt_lw = 32'd0;
    for (int c = 0; c < NC; c++) begin
      if (ev_in[c])  n_acc = n_acc + 32'd1;
      if (ev_rej[c]) n_rej = n_rej + 32'd1;
    end
    if (ev_gnt) begin
      gnt_wait = {16'd0, cyc_q - tacc_q[(32'(ev_gnt_client)*QD + 32'(ev_gnt_slot))*TSW +: TSW]};
      gnt_lw   = {16'd0, lw_q[32'(ev_gnt_client)*TSW +: TSW]};
    end
    // up to NC deliveries per cycle: accumulate the sum, the maximum and the count
    for (int c = 0; c < NC; c++) begin
      if (ev_dlv[c]) begin
        n_dlv = n_dlv + 32'd1;
      end
    end
  end

  // latency sum / max over the deliveries of this cycle
  reg [31:0] lat_sum_cyc, lat_max_cyc, l_tmp;
  always_comb begin
    lat_sum_cyc = 32'd0;
    lat_max_cyc = 32'd0;
    l_tmp       = 32'd0;
    for (int c = 0; c < NC; c++) begin
      if (ev_dlv[c]) begin
        l_tmp = {16'd0, cyc_q - tacc_q[(c*QD + 32'(ev_dlv_slot[c*PQW +: PQW]))*TSW +: TSW]};
        lat_sum_cyc = lat_sum_cyc + l_tmp;
        if (l_tmp > lat_max_cyc) lat_max_cyc = l_tmp;
      end
    end
  end

  // ------------------------------------------------------------------ state
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      c_q    <= '0;
      cyc_q  <= '0;
      tacc_q <= '0;
      lw_q   <= '0;
    end else begin
      cyc_q <= cyc_q + TSW'(1);

      // accept timestamps
      for (int c = 0; c < NC; c++)
        if (ev_in[c]) tacc_q[(c*QD + 32'(ev_in_slot[c*PQW +: PQW]))*TSW +: TSW] <= cyc_q;

      // lock-wait running counters: count while blocked, clear at grant
      for (int c = 0; c < NC; c++) begin
        if (ev_gnt && (32'(ev_gnt_client) == c)) lw_q[c*TSW +: TSW] <= '0;
        else if (hd_lock_blk[c] && (lw_q[c*TSW +: TSW] != {TSW{1'b1}})) lw_q[c*TSW +: TSW] <= lw_q[c*TSW +: TSW] + TSW'(1);
      end

      if (perf_clr_i) begin
        c_q <= '0;
      end else begin
        c_q[sf_atomic_pkg::PF_CYCLES*32 +: 32]    <= sat_add(c_q[sf_atomic_pkg::PF_CYCLES*32 +: 32], 32'd1);
        c_q[sf_atomic_pkg::PF_ACCEPTED*32 +: 32]  <= sat_add(c_q[sf_atomic_pkg::PF_ACCEPTED*32 +: 32], n_acc);
        c_q[sf_atomic_pkg::PF_DELIVERED*32 +: 32] <= sat_add(c_q[sf_atomic_pkg::PF_DELIVERED*32 +: 32], n_dlv);
        c_q[sf_atomic_pkg::PF_COMMITTED*32 +: 32] <= sat_add(c_q[sf_atomic_pkg::PF_COMMITTED*32 +: 32], {28'd0, n_commit});
        c_q[sf_atomic_pkg::PF_REJECTED*32 +: 32]  <= sat_add(c_q[sf_atomic_pkg::PF_REJECTED*32 +: 32], n_rej);
        c_q[sf_atomic_pkg::PF_MEMERR*32 +: 32]    <= sat_add(c_q[sf_atomic_pkg::PF_MEMERR*32 +: 32], {28'd0, n_memerr});
        c_q[sf_atomic_pkg::PF_CAS_FAIL*32 +: 32]  <= sat_add(c_q[sf_atomic_pkg::PF_CAS_FAIL*32 +: 32], {28'd0, n_cas_fail});
        c_q[sf_atomic_pkg::PF_QWAIT_SUM*32 +: 32] <= sat_add(c_q[sf_atomic_pkg::PF_QWAIT_SUM*32 +: 32], gnt_wait);
        if (gnt_wait > c_q[sf_atomic_pkg::PF_QWAIT_MAX*32 +: 32])
          c_q[sf_atomic_pkg::PF_QWAIT_MAX*32 +: 32] <= gnt_wait;
        c_q[sf_atomic_pkg::PF_LOCKWAIT_SUM*32 +: 32] <= sat_add(c_q[sf_atomic_pkg::PF_LOCKWAIT_SUM*32 +: 32], gnt_lw);
        if (gnt_lw > c_q[sf_atomic_pkg::PF_LOCKWAIT_MAX*32 +: 32])
          c_q[sf_atomic_pkg::PF_LOCKWAIT_MAX*32 +: 32] <= gnt_lw;
        c_q[sf_atomic_pkg::PF_LAT_SUM*32 +: 32]   <= sat_add(c_q[sf_atomic_pkg::PF_LAT_SUM*32 +: 32], lat_sum_cyc);
        if (lat_max_cyc > c_q[sf_atomic_pkg::PF_LAT_MAX*32 +: 32])
          c_q[sf_atomic_pkg::PF_LAT_MAX*32 +: 32] <= lat_max_cyc;
        c_q[sf_atomic_pkg::PF_CONTENDED*32 +: 32] <= sat_add(c_q[sf_atomic_pkg::PF_CONTENDED*32 +: 32], {31'd0, (gnt_lw != 32'd0)});
        c_q[sf_atomic_pkg::PF_ORD_STALL*32 +: 32] <= sat_add(c_q[sf_atomic_pkg::PF_ORD_STALL*32 +: 32], {31'd0, ev_ord_blk});
        c_q[sf_atomic_pkg::PF_MEM_STALL*32 +: 32] <= sat_add(c_q[sf_atomic_pkg::PF_MEM_STALL*32 +: 32], {28'd0, n_mem_stall});
        c_q[sf_atomic_pkg::PF_CMD_STALL*32 +: 32] <= sat_add(c_q[sf_atomic_pkg::PF_CMD_STALL*32 +: 32], {28'd0, n_cmd_stall});
        c_q[sf_atomic_pkg::PF_CTX_BUSY*32 +: 32]  <= sat_add(c_q[sf_atomic_pkg::PF_CTX_BUSY*32 +: 32], {28'd0, n_ctx_busy});
        c_q[sf_atomic_pkg::PF_LOCK_OCC*32 +: 32]  <= sat_add(c_q[sf_atomic_pkg::PF_LOCK_OCC*32 +: 32], {28'd0, n_locks});
        c_q[sf_atomic_pkg::PF_ATM_RD*32 +: 32]    <= sat_add(c_q[sf_atomic_pkg::PF_ATM_RD*32 +: 32], {31'd0, ev_atm_rd});
        c_q[sf_atomic_pkg::PF_ATM_WR*32 +: 32]    <= sat_add(c_q[sf_atomic_pkg::PF_ATM_WR*32 +: 32], {31'd0, ev_atm_wr});
        c_q[sf_atomic_pkg::PF_ORD_RD*32 +: 32]    <= sat_add(c_q[sf_atomic_pkg::PF_ORD_RD*32 +: 32], {31'd0, ev_ord_rd});
        c_q[sf_atomic_pkg::PF_ORD_WR*32 +: 32]    <= sat_add(c_q[sf_atomic_pkg::PF_ORD_WR*32 +: 32], {31'd0, ev_ord_wr});
        c_q[sf_atomic_pkg::PF_ORD_ERR*32 +: 32]   <= sat_add(c_q[sf_atomic_pkg::PF_ORD_ERR*32 +: 32], {31'd0, ev_ord_err});
        c_q[sf_atomic_pkg::PF_COH_OPS*32 +: 32]   <= sat_add(c_q[sf_atomic_pkg::PF_COH_OPS*32 +: 32], {31'd0, ev_coh_op});
        c_q[sf_atomic_pkg::PF_RESV*32 +: 32]      <= sat_add(c_q[sf_atomic_pkg::PF_RESV*32 +: 32], {31'd0, ev_resv});
      end
    end
  end

endmodule

`default_nettype wire
