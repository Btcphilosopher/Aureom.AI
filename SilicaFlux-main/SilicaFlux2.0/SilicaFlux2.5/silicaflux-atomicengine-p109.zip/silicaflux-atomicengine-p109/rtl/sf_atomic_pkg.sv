// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: sf_atomic_pkg -- protocol constants
//
// SINGLE SOURCE OF TRUTH for every encoding that crosses a module, testbench or formal boundary: opcodes,
// width codes, completion status codes, queue/context state codes, performance-counter indices.
//
// Coding rule inherited from the SilicaFlux Yosys-0.33 flow (same as Projects 22 / 83 / 104 / 107):
//   * synthesizable RTL uses ONLY localparams of this package, fully qualified (sf_atomic_pkg::NAME), inside module
//     bodies, on flat bit vectors.  No struct, no enum, no `import`, no package function, no interface in a module.
//   * a package constant is NOT used in a module parameter list or a port width: geometry (clients, queue depth,
//     contexts, address width) is module parameters with local derived widths.
//
// The COMMAND STRUCTURE of the brief is the set of per-client flat ports of sf_atomic_engine (cmd_*), whose bit layout
// is also given as the packed struct sf_atomic_cmd_t / sf_atomic_rsp_t below.  The structs exist for testbenches,
// firmware headers and documentation; no synthesizable module consumes them (see docs/02_INTERFACES.md).
//
// Classification: SYNTHESIZABLE (constants).
// =============================================================================
`default_nettype none

package sf_atomic_pkg;
  /* verilator lint_off UNUSEDPARAM */

  // ---------------------------------------------------------------- opcodes (cmd_op).  0 and 11..15 are rejected.
  localparam logic [3:0] AOP_NONE = 4'd0;    // reserved: an all-zero command is never executed
  localparam logic [3:0] AOP_SWAP = 4'd1;    // old <- mem;  mem <- opd
  localparam logic [3:0] AOP_FADD = 4'd2;    // fetch-add, modulo 2**width (wraps, no trap, no flag)
  localparam logic [3:0] AOP_FAND = 4'd3;    // fetch-and
  localparam logic [3:0] AOP_FOR  = 4'd4;    // fetch-or
  localparam logic [3:0] AOP_FXOR = 4'd5;    // fetch-xor
  localparam logic [3:0] AOP_MIN  = 4'd6;    // mem <- min(mem, opd), SIGNED two's complement at the operand width
  localparam logic [3:0] AOP_MAX  = 4'd7;    // mem <- max(mem, opd), SIGNED
  localparam logic [3:0] AOP_MINU = 4'd8;    // mem <- min(mem, opd), UNSIGNED
  localparam logic [3:0] AOP_MAXU = 4'd9;    // mem <- max(mem, opd), UNSIGNED
  localparam logic [3:0] AOP_CAS  = 4'd10;   // if (mem == cmp) mem <- opd;  success flag = (mem == cmp)
  localparam int         AOP_N    = 11;      // bit i of the OP_EN parameter enables opcode i

  // ---------------------------------------------------------------- width codes (cmd_width)
  localparam logic [1:0] AWD_32   = 2'd0;    // 32-bit operand, 4-byte aligned address
  localparam logic [1:0] AWD_64   = 2'd1;    // 64-bit operand, 8-byte aligned address   (2 and 3 are rejected)

  // ---------------------------------------------------------------- completion status (rsp_status)
  localparam logic [3:0] AST_OK      = 4'd0;   // executed; CAS failure is still OK (rsp_succ = 0)
  localparam logic [3:0] AST_OP      = 4'd1;   // unsupported / reserved opcode               rejected, no effect, retry-safe after fixing
  localparam logic [3:0] AST_WIDTH   = 4'd2;   // unsupported operand width                   rejected, no effect
  localparam logic [3:0] AST_ALIGN   = 4'd3;   // address not naturally aligned to the width  rejected, no effect
  localparam logic [3:0] AST_RANGE   = 4'd4;   // invalid address: outside the atomic window  rejected, no effect
  localparam logic [3:0] AST_DOMAIN  = 4'd5;   // domain claim not bound to this port         rejected, no effect
  localparam logic [3:0] AST_DEST    = 4'd6;   // completion destination not allowed          rejected, no effect, completion to issuer
  localparam logic [3:0] AST_PERM    = 4'd7;   // MemoryGuard denied read or write permission rejected, no effect
  localparam logic [3:0] AST_READ    = 4'd8;   // memory read failed: NOTHING was written     no effect, retry-safe
  localparam logic [3:0] AST_WRITE   = 4'd9;   // memory write failed: location INDETERMINATE do NOT retry blindly (read back first)
  localparam logic [3:0] AST_COH     = 4'd10;  // coherence protocol failure: INDETERMINATE   do NOT retry blindly
  localparam int         AST_N       = 11;

  // ---------------------------------------------------------------- ordinary-port status (o_rsp_status), MemoryMatrix style
  localparam logic [3:0] OST_OK      = 4'd0;
  localparam logic [3:0] OST_ALIGN   = 4'd2;   // same numbers as MemoryMatrix SF_ST_*: ALIGN 2, BADOP 5, PERM 6
  localparam logic [3:0] OST_BADOP   = 4'd5;   // size > 3 (more than 8 bytes) is not supported on the ordinary port
  localparam logic [3:0] OST_COHWIN  = 4'd7;   // ordinary access to the coherent window is refused (use a coherent agent)

  // ---------------------------------------------------------------- memory-port response status (m_rsp_status)
  // MemoryMatrix: OK 0, RANGE 1, ALIGN 2, ECC_UE 3, OWNER 4, BADOP 5, PERM 6.  The engine treats every non-zero value
  // as a failure of that access (AST_READ / AST_WRITE).

  // ---------------------------------------------------------------- execution-context FSM
  localparam logic [2:0] CX_IDLE = 3'd0;
  localparam logic [2:0] CX_RD   = 3'd1;   // presenting the read request (lock already held)
  localparam logic [2:0] CX_RW   = 3'd2;   // waiting for the read response
  localparam logic [2:0] CX_WR   = 3'd3;   // presenting the write request
  localparam logic [2:0] CX_WW   = 3'd4;   // waiting for the write response (lock released after it when REL_ON_ACK = 1)
  localparam logic [2:0] CX_COH  = 3'd5;   // executing in the coherence agent
  localparam logic [2:0] CX_FIN  = 3'd6;   // result to the queue, lock released

  // ---------------------------------------------------------------- performance counters (32-bit, saturating)
  localparam int PF_CYCLES      = 0;    // cycles since clear
  localparam int PF_ACCEPTED    = 1;    // commands accepted at an ingress port (valid commands and pre-rejected ones)
  localparam int PF_DELIVERED   = 2;    // completions delivered to a destination port
  localparam int PF_COMMITTED   = 3;    // atomic operations that reached their linearisation point (memory or coherence)
  localparam int PF_REJECTED    = 4;    // commands completed with a validation error (no lock, no memory access)
  localparam int PF_MEMERR      = 5;    // commands completed with AST_READ / AST_WRITE / AST_COH
  localparam int PF_CAS_FAIL    = 6;    // CAS operations whose compare failed
  localparam int PF_QWAIT_SUM   = 7;    // sum over operations of (cycles from accept to start of execution)
  localparam int PF_QWAIT_MAX   = 8;    // maximum of the same
  localparam int PF_LOCKWAIT_SUM = 9;   // sum over operations of cycles the queue head was blocked by a lock / hold-off
  localparam int PF_LOCKWAIT_MAX = 10;  // maximum of the same ("lock acquisition time")
  localparam int PF_LAT_SUM     = 11;   // sum over operations of (cycles from accept to completion delivered)
  localparam int PF_LAT_MAX     = 12;   // maximum of the same ("atomic operation latency")
  localparam int PF_CONTENDED   = 13;   // operations that waited at least one cycle for a lock ("contention events")
  localparam int PF_ORD_STALL   = 14;   // cycles an ordinary write was held off by an atomic lock
  localparam int PF_MEM_STALL   = 15;   // context-cycles a memory request was presented but not accepted
  localparam int PF_CMD_STALL   = 16;   // port-cycles cmd_valid && !cmd_ready ("stall cycles" at the ingress)
  localparam int PF_CTX_BUSY    = 17;   // sum over cycles of busy contexts (utilisation = this / (cycles * NCTX))
  localparam int PF_LOCK_OCC    = 18;   // sum over cycles of held locks
  localparam int PF_ATM_RD      = 19;   // memory reads issued by atomic contexts
  localparam int PF_ATM_WR      = 20;   // memory writes issued by atomic contexts
  localparam int PF_ORD_RD      = 21;   // ordinary reads forwarded
  localparam int PF_ORD_WR      = 22;   // ordinary writes forwarded
  localparam int PF_ORD_ERR     = 23;   // ordinary requests answered locally with an error
  localparam int PF_COH_OPS     = 24;   // operations executed through the coherence agent
  localparam int PF_RESV        = 25;   // times the ordinary-write / atomic alternation rule gave the atomic its turn
  localparam int PF_N           = 26;

  // ---------------------------------------------------------------- command / response structures (documentation and testbench use)
  // Field widths of the DEFAULT geometry: AW = 32, TAGW = 8, RIDW = 4, DOMW = 2, DESTW = 2.  Other geometries change
  // only the widths of addr / tag / rid / dom / dest.
  typedef struct packed {
    logic        rl;       // release-like ordering: starts only after every older command of this client has committed
    logic        aq;       // acquire-like ordering: no younger command of this client starts before this one commits
    logic [1:0]  dest;     // completion destination = client port index (must be allowed for the issuing port)
    logic [1:0]  dom;      // protection-domain claim, checked against the port's trusted binding and by MemoryGuard
    logic [7:0]  tag;      // transaction tag, echoed in the completion
    logic [3:0]  rid;      // requester identifier (agent behind the port), echoed
    logic [1:0]  width;    // AWD_32 / AWD_64
    logic [63:0] cmp;      // compare value (CAS only)
    logic [63:0] opd;      // operand: addend / mask / new value
    logic [31:0] addr;     // byte address, naturally aligned to the width
    logic [3:0]  op;       // AOP_*
  } sf_atomic_cmd_t;

  typedef struct packed {
    logic [3:0]  status;   // AST_*
    logic        succ;     // CAS: compare succeeded; every other opcode: 1 when status == AST_OK
    logic [63:0] old;      // original value of the location, zero-extended from the operand width (0 on error)
    logic [1:0]  src;      // issuing client port
    logic [3:0]  rid;
    logic [7:0]  tag;
  } sf_atomic_rsp_t;

  /* verilator lint_on UNUSEDPARAM */
endpackage

`default_nettype wire
