// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: sf_atomic_queue
//
// Bounded per-client command queues, round-robin start scheduling and in-order completion delivery.
//
//   ingress      one command per client per cycle into a ring of QD entries.  in_ready[c] = (entries < QD), a registered
//                function only (never of in_valid): the queue is a bounded buffer with EXACT back-pressure; nothing is dropped.
//                A command that failed validation (in_pre_err != 0) is stored already DONE with its error status: it never
//                reaches the scheduler, takes no lock and no memory cycle, but is still completed IN ORDER.
//   scheduling   every client queue offers its oldest not-yet-started entry (the "head candidate": in-order START per client).
//                The engine decides eligibility (free context, lock, ordering bits); this module picks ONE eligible client per
//                cycle by round robin (pointer moves past the winner on every grant: waiting <= NC-1 grants).
//   completion   a context writes {old, succ, status} back into its entry (res_*).  The old value reuses the storage of the
//                compare operand (it is dead after the read).
//   delivery     the oldest entry of a client is delivered when DONE, to the destination port named in the entry: completions
//                of one client are IN ORDER, completions of different clients are independent.  One completion per destination
//                port per cycle, chosen by round robin; once presented, a completion is held (same client, same data) until
//                accepted (valid / ready rules of SFB2 R4).
//
// Entry life cycle:  free -> pending (start not yet granted) -> running (granted, result not yet written) -> done -> delivered.
// Pointers (PW+1 bits, wrap bit): head <= iss <= tail.   head..iss = started, iss..tail = pending.
//
// Counters kept for the ordering bits of the engine:
//   q_run[c]    entries started and not yet completed (rl: "all older commands have committed" <=> q_run == 0)
//   q_aqrun[c]  the same restricted to entries issued with aq
//
// Classification: SYNTHESIZABLE.  QD must be a power of two >= 2 (checked in simulation).
// =============================================================================
`default_nettype none

module sf_atomic_queue #(
  parameter int NC    = 4,                 // clients = destination ports
  parameter int QD    = 4,                 // entries per client (power of two)
  parameter int PW    = 102,               // stored launch payload bits  {op, width, addr, opd}
  parameter int TAGW  = 8,
  parameter int RIDW  = 4,
  localparam int CLW   = (NC > 1) ? $clog2(NC) : 1,
  localparam int PQW   = (QD > 1) ? $clog2(QD) : 1,
  localparam int PTW   = PQW + 1,
  localparam int CNTW  = PTW
) (
  input  wire                    clk,
  input  wire                    rst_n,
  input  wire                    block_in,                // quiesce: no new entries
  // ---------------------------------------------------------------- ingress
  input  wire [NC-1:0]           in_valid,
  output wire [NC-1:0]           in_ready,
  input  wire [NC*PW-1:0]        in_pay,
  input  wire [NC*64-1:0]        in_cmp,
  input  wire [NC*TAGW-1:0]      in_tag,
  input  wire [NC*RIDW-1:0]      in_rid,
  input  wire [NC*CLW-1:0]       in_dest,
  input  wire [NC-1:0]           in_aq,
  input  wire [NC-1:0]           in_rl,
  input  wire [NC*4-1:0]         in_pre_err,
  // ---------------------------------------------------------------- scheduling
  output wire [NC-1:0]           hd_valid,
  output wire [NC*PW-1:0]        hd_pay,
  output wire [NC-1:0]           hd_aq,
  output wire [NC-1:0]           hd_rl,
  output wire [NC*CNTW-1:0]      q_run,
  output wire [NC*CNTW-1:0]      q_aqrun,
  input  wire [NC-1:0]           elig,
  output wire                    gnt_valid,
  output wire [CLW-1:0]          gnt_client,
  output wire [PQW-1:0]          gnt_slot,
  output wire [PW-1:0]           gnt_pay,
  output wire [63:0]             gnt_cmp,
  output wire [TAGW-1:0]         gnt_tag,
  output wire [RIDW-1:0]         gnt_rid,
  // ---------------------------------------------------------------- completion write-back from a context
  input  wire                    res_valid,
  input  wire [CLW-1:0]          res_client,
  input  wire [PQW-1:0]          res_slot,
  input  wire [63:0]             res_old,
  input  wire                    res_succ,
  input  wire [3:0]              res_status,
  // ---------------------------------------------------------------- delivery (one channel per destination port)
  output wire [NC-1:0]           rsp_valid,
  input  wire [NC-1:0]           rsp_ready,
  output wire [NC*TAGW-1:0]      rsp_tag,
  output wire [NC*RIDW-1:0]      rsp_rid,
  output wire [NC*CLW-1:0]       rsp_src,
  output wire [NC*64-1:0]        rsp_old,
  output wire [NC-1:0]           rsp_succ,
  output wire [NC*4-1:0]         rsp_status,
  // ---------------------------------------------------------------- status / events
  output wire                    empty_o,                 // no entry anywhere
  output wire [NC-1:0]           full_o,
  output wire [NC-1:0]           ev_in,                   // entry written this cycle
  output wire [NC*PQW-1:0]       ev_in_slot,
  output wire [NC-1:0]           ev_dlv,                  // entry delivered this cycle
  output wire [NC*PQW-1:0]       ev_dlv_slot,
  output wire [NC-1:0]           ev_dlv_err
);

`ifndef SYNTHESIS
  initial begin
    if (QD < 2 || (QD & (QD - 1)) != 0) begin
      $display("sf_atomic_queue: QD must be a power of two >= 2 (got %0d)", QD);
      $finish;
    end
  end
`endif

  // ------------------------------------------------------------------ storage (flat vectors, entry e = c*QD + s)
  reg [NC*QD*PW-1:0]   pay_q;
  reg [NC*QD*64-1:0]   co_q;           // compare operand, replaced by the old value on completion
  reg [NC*QD*TAGW-1:0] tag_q;
  reg [NC*QD*RIDW-1:0] rid_q;
  reg [NC*QD*CLW-1:0]  dst_q;
  reg [NC*QD-1:0]      aq_q, rl_q, done_q, succ_q;
  reg [NC*QD*4-1:0]    st_q;

  reg [NC*PTW-1:0]     hd_p, is_p, tl_p;       // head (oldest), issue (next to start), tail (next free)
  reg [NC*CNTW-1:0]    run_q, aqrun_q;
  reg [CLW-1:0]        sch_rr;                  // scheduler round-robin pointer
  reg [NC*CLW-1:0]     dl_rr;                   // delivery round-robin pointer per destination
  reg [NC-1:0]         dl_lk_v;                 // delivery winner locked (presented, not yet accepted)
  reg [NC*CLW-1:0]     dl_lk_c;

  // ------------------------------------------------------------------ per-client derived signals
  reg [NC-1:0]         full_r, in_fire, hd_valid_r, hd_done_r, skip_r, hd_aq_r, hd_rl_r;
  reg [NC*PQW-1:0]     tl_s, is_s, hd_s;
  reg [NC*PW-1:0]      hd_pay_r;
  always_comb begin
    for (int c = 0; c < NC; c++) begin
      reg [PTW-1:0] h, i, t;
      reg [PQW-1:0] ts, is_, hs;
      h  = hd_p[c*PTW +: PTW];
      i  = is_p[c*PTW +: PTW];
      t  = tl_p[c*PTW +: PTW];
      ts = t[PQW-1:0];
      is_ = i[PQW-1:0];
      hs = h[PQW-1:0];
      tl_s[c*PQW +: PQW] = ts;
      is_s[c*PQW +: PQW] = is_;
      hd_s[c*PQW +: PQW] = hs;
      full_r[c]  = ((t - h) == PTW'(QD));
      in_fire[c] = in_valid[c] && !full_r[c] && !block_in && rst_n;
      // head candidate: oldest not-yet-started entry that is not already done
      hd_valid_r[c] = (i != t) && !done_q[c*QD + 32'(is_)];
      skip_r[c]     = (i != t) &&  done_q[c*QD + 32'(is_)];
      hd_pay_r[c*PW +: PW] = pay_q[(c*QD + 32'(is_))*PW +: PW];
      hd_aq_r[c]    = aq_q[c*QD + 32'(is_)];
      hd_rl_r[c]    = rl_q[c*QD + 32'(is_)];
      // head (oldest) entry delivered when done
      hd_done_r[c]  = (h != t) && done_q[c*QD + 32'(hs)];
    end
  end

  assign in_ready   = ~full_r & {NC{~block_in & rst_n}};
  assign full_o     = full_r;
  assign hd_valid   = hd_valid_r & {NC{rst_n}};
  assign hd_pay     = hd_pay_r;
  assign hd_aq      = hd_aq_r;
  assign hd_rl      = hd_rl_r;
  assign q_run      = run_q;
  assign q_aqrun    = aqrun_q;
  assign ev_in      = in_fire;
  assign ev_in_slot = tl_s;

  reg empty_r;
  always_comb begin
    empty_r = 1'b1;
    for (int c = 0; c < NC; c++) if (hd_p[c*PTW +: PTW] != tl_p[c*PTW +: PTW]) empty_r = 1'b0;
  end
  assign empty_o = empty_r;

  // ------------------------------------------------------------------ start scheduling: round robin over eligible heads
  reg             gv;
  reg [CLW-1:0]   gc;
  integer         g_idx;
  always_comb begin
    gv = 1'b0;
    gc = '0;
    g_idx = 0;
    for (int k = 0; k < NC; k++) begin
      g_idx = 32'(sch_rr) + k;
      if (g_idx >= NC) g_idx = g_idx - NC;
      if (!gv && hd_valid_r[g_idx] && elig[g_idx]) begin
        gv = 1'b1;
        gc = CLW'(g_idx);
      end
    end
  end
  assign gnt_valid  = gv && rst_n;
  assign gnt_client = gc;
  assign gnt_slot   = is_s[32'(gc)*PQW +: PQW];
  assign gnt_pay    = hd_pay_r[32'(gc)*PW +: PW];
  assign gnt_cmp    = co_q[(32'(gc)*QD + 32'(is_s[32'(gc)*PQW +: PQW]))*64 +: 64];
  assign gnt_tag    = tag_q[(32'(gc)*QD + 32'(is_s[32'(gc)*PQW +: PQW]))*TAGW +: TAGW];
  assign gnt_rid    = rid_q[(32'(gc)*QD + 32'(is_s[32'(gc)*PQW +: PQW]))*RIDW +: RIDW];

  // ------------------------------------------------------------------ delivery: winner per destination port
  reg [NC-1:0]         dv;
  reg [NC*CLW-1:0]     dw;
  reg                  dl_f;
  reg [CLW-1:0]        dl_w;
  integer              dl_idx;
  always_comb begin
    dv = '0;
    dw = '0;
    dl_f = 1'b0; dl_w = '0; dl_idx = 0;
    for (int d = 0; d < NC; d++) begin
      dl_f = 1'b0;
      dl_w = '0;
      if (dl_lk_v[d]) begin
        dl_f = 1'b1;
        dl_w = dl_lk_c[d*CLW +: CLW];
      end else begin
        for (int k = 0; k < NC; k++) begin
          dl_idx = 32'(dl_rr[d*CLW +: CLW]) + k;
          if (dl_idx >= NC) dl_idx = dl_idx - NC;
          if (!dl_f && hd_done_r[dl_idx] && (32'(dst_q[(dl_idx*QD + 32'(hd_s[dl_idx*PQW +: PQW]))*CLW +: CLW]) == d)) begin
            dl_f = 1'b1;
            dl_w = CLW'(dl_idx);
          end
        end
      end
      dv[d]            = dl_f && rst_n;
      dw[d*CLW +: CLW] = dl_w;
    end
  end

  reg [NC*TAGW-1:0] rsp_tag_r;
  reg [NC*RIDW-1:0] rsp_rid_r;
  reg [NC*CLW-1:0]  rsp_src_r;
  reg [NC*64-1:0]   rsp_old_r;
  reg [NC-1:0]      rsp_succ_r;
  reg [NC*4-1:0]    rsp_st_r;
  reg [NC-1:0]      pop_r;                       // client popped this cycle
  reg [NC*PQW-1:0]  pop_slot_r;
  reg [NC-1:0]      pop_err_r;
  always_comb begin
    pop_r      = '0;
    pop_slot_r = '0;
    pop_err_r  = '0;
    for (int d = 0; d < NC; d++) begin
      int w, e;
      w = 32'(dw[d*CLW +: CLW]);
      e = w*QD + 32'(hd_s[w*PQW +: PQW]);
      rsp_tag_r[d*TAGW +: TAGW] = tag_q[e*TAGW +: TAGW];
      rsp_rid_r[d*RIDW +: RIDW] = rid_q[e*RIDW +: RIDW];
      rsp_src_r[d*CLW +: CLW]   = CLW'(w);
      rsp_old_r[d*64 +: 64]     = co_q[e*64 +: 64];
      rsp_succ_r[d]             = succ_q[e];
      rsp_st_r[d*4 +: 4]        = st_q[e*4 +: 4];
      if (dv[d] && rsp_ready[d]) begin
        pop_r[w]                  = 1'b1;
        pop_slot_r[w*PQW +: PQW]  = hd_s[w*PQW +: PQW];
        pop_err_r[w]              = (st_q[e*4 +: 4] != 4'd0);
      end
    end
  end
  assign rsp_valid  = dv;
  assign rsp_tag    = rsp_tag_r;
  assign rsp_rid    = rsp_rid_r;
  assign rsp_src    = rsp_src_r;
  assign rsp_old    = rsp_old_r;
  assign rsp_succ   = rsp_succ_r;
  assign rsp_status = rsp_st_r;
  assign ev_dlv      = pop_r;
  assign ev_dlv_slot = pop_slot_r;
  assign ev_dlv_err  = pop_err_r;

  // ------------------------------------------------------------------ state update
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      pay_q   <= '0;
      co_q    <= '0;
      tag_q   <= '0;
      rid_q   <= '0;
      dst_q   <= '0;
      aq_q    <= '0;
      rl_q    <= '0;
      done_q  <= '0;
      succ_q  <= '0;
      st_q    <= '0;
      hd_p    <= '0;
      is_p    <= '0;
      tl_p    <= '0;
      run_q   <= '0;
      aqrun_q <= '0;
      sch_rr  <= '0;
      dl_rr   <= '0;
      dl_lk_v <= '0;
      dl_lk_c <= '0;
    end else begin
      // ---- ingress: write the entry at the tail
      for (int c = 0; c < NC; c++) begin
        if (in_fire[c]) begin
          int e;
          e = c*QD + 32'(tl_s[c*PQW +: PQW]);
          pay_q [e*PW   +: PW  ] <= in_pay [c*PW   +: PW  ];
          co_q  [e*64   +: 64  ] <= (in_pre_err[c*4 +: 4] != 4'd0) ? 64'd0 : in_cmp[c*64 +: 64];
          tag_q [e*TAGW +: TAGW] <= in_tag [c*TAGW +: TAGW];
          rid_q [e*RIDW +: RIDW] <= in_rid [c*RIDW +: RIDW];
          dst_q [e*CLW  +: CLW ] <= in_dest[c*CLW  +: CLW ];
          aq_q  [e]              <= in_aq[c];
          rl_q  [e]              <= in_rl[c];
          done_q[e]              <= (in_pre_err[c*4 +: 4] != 4'd0);
          succ_q[e]              <= 1'b0;
          st_q  [e*4    +: 4   ] <= in_pre_err[c*4 +: 4];
          tl_p[c*PTW +: PTW]     <= tl_p[c*PTW +: PTW] + PTW'(1);
        end
      end

      // ---- start grant: advance the issue pointer, count the entry as running
      // ---- skip of a pre-rejected (already done) entry: advance the issue pointer without a grant
      for (int c = 0; c < NC; c++) begin
        if (gnt_valid && (32'(gnt_client) == c)) begin
          is_p[c*PTW +: PTW] <= is_p[c*PTW +: PTW] + PTW'(1);
        end else if (skip_r[c]) begin
          is_p[c*PTW +: PTW] <= is_p[c*PTW +: PTW] + PTW'(1);
        end
      end
      if (gnt_valid) begin
        sch_rr <= (32'(gnt_client) == NC - 1) ? '0 : (gnt_client + CLW'(1));
      end

      // ---- run counters: +1 on grant, -1 on completion write-back
      for (int c = 0; c < NC; c++) begin
        reg inc, dec, inc_aq, dec_aq;
        inc    = gnt_valid && (32'(gnt_client) == c);
        inc_aq = inc && hd_aq_r[c];
        dec    = res_valid && (32'(res_client) == c);
        dec_aq = dec && aq_q[c*QD + 32'(res_slot)];
        run_q  [c*CNTW +: CNTW] <= run_q  [c*CNTW +: CNTW] + CNTW'(inc)    - CNTW'(dec);
        aqrun_q[c*CNTW +: CNTW] <= aqrun_q[c*CNTW +: CNTW] + CNTW'(inc_aq) - CNTW'(dec_aq);
      end

      // ---- completion write-back
      if (res_valid) begin
        int e;
        e = 32'(res_client)*QD + 32'(res_slot);
        co_q  [e*64 +: 64] <= res_old;
        succ_q[e]          <= res_succ;
        st_q  [e*4  +: 4 ] <= res_status;
        done_q[e]          <= 1'b1;
      end

      // ---- delivery: pop on handshake, round robin and winner lock per destination
      for (int c = 0; c < NC; c++) begin
        if (pop_r[c]) begin
          hd_p[c*PTW +: PTW] <= hd_p[c*PTW +: PTW] + PTW'(1);
          done_q[c*QD + 32'(hd_s[c*PQW +: PQW])] <= 1'b0;
        end
      end
      for (int d = 0; d < NC; d++) begin
        if (dv[d] && rsp_ready[d]) begin
          dl_lk_v[d] <= 1'b0;
          dl_rr[d*CLW +: CLW] <= (32'(dw[d*CLW +: CLW]) == NC - 1) ? '0 : (dw[d*CLW +: CLW] + CLW'(1));
        end else if (dv[d]) begin
          dl_lk_v[d] <= 1'b1;
          dl_lk_c[d*CLW +: CLW] <= dw[d*CLW +: CLW];
        end
      end
    end
  end
  // ------------------------------------------------------------------ formal / simulation properties (formal/fv_queue_props.svh)
`ifdef SF_ATOMIC_PROPS
`include "fv_queue_props.svh"
`endif
endmodule

`default_nettype wire
