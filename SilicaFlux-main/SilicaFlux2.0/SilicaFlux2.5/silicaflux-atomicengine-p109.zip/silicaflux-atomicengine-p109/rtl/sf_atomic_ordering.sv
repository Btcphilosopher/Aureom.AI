// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: sf_atomic_ordering
//
// The ORDERING UNIT.  It owns the engine's single memory master port and decides, every cycle, who may use it:
//   * the atomic execution contexts (read request, write request),
//   * the ORDINARY port (loads / stores of CPUs, DMA ... that must meet the same memory),
// and it makes sure no ordinary WRITE can interleave with an atomic read-modify-write of the same lock granule.
//
// WHY THE ENGINE OWNS THE MEMORY PORT (docs/03_ATOMICITY.md): the repository's memories give no atomicity beyond ONE word
// access (MemoryMatrix M4) and no locks (M5); Meridian carries no atomic or exclusive transaction.  Two separately issued
// bus transactions are therefore never atomic.  The engine makes them atomic by being the only path to the window:
// every access to a locked granule goes through this module, which holds ordinary writes back while the lock is held.
//
// MEMORY-PORT CONTRACT (what the engine requires of the memory, all stated by MemoryMatrix M1-M3 / SRAMController T1-T4):
//   (a) requests are accepted one per cycle at most; a request accepted at edge t observes every write accepted at an
//       earlier edge to the same word, and is observed by every later one (acceptance order = visibility order);
//   (b) responses are returned with the request's id (ids are echoed); one response per accepted request;
//   (c) req_ready depends on registered state only; a presented request is held until accepted (SFB2 R2) -- the engine
//       guarantees the same on its side with a GRANT LOCK: once a request is presented and not accepted, the same requester
//       keeps the port with unchanged fields until it is accepted.
//   Byte lanes follow MemoryMatrix: RELATIVE lanes, lane j = address + j, access size given as log2(bytes).
//
// ORDINARY PORT RULES
//   * single beat, size 1/2/4/8 bytes, naturally aligned (so one access touches one 8-byte memory word and one lock granule);
//     anything else is answered locally with an error and never reaches memory;
//   * READS are never held: a read ordered before the atomic's linearisation point returns the old value, after it the new
//     value, both valid serial orders;
//   * WRITES to a granule locked by a context (or reserved by an atomic, see sf_atomic_lock_table) are held back and presented
//     only after the lock is released; a write that is waiting or presented blocks the NEXT atomic grant on its granule (hold-off),
//     so neither side can starve the other;
//   * responses return in request order; they are stored in a FIFO of OMAX entries reserved at acceptance, so the memory response
//     path can never be blocked by a slow ordinary requester (no deadlock through the response channel);
//   * when COHERENT = 1 an ordinary access to the coherent window is refused (status OST_COHWIN): that window is reachable only
//     through coherent agents and the engine's coherence path.
//
// Classification: SYNTHESIZABLE.  OMAX must be a power of two >= 2.
// =============================================================================
`default_nettype none

module sf_atomic_ordering #(
  parameter int NCTX     = 2,
  parameter int AW       = 32,
  parameter int GRAN     = 3,              // lock granule = 2**GRAN bytes
  parameter int OMAX     = 4,              // ordinary requests in flight (response FIFO depth), power of two
  parameter int OIDW     = 4,              // ordinary requester id width
  parameter int COHERENT = 0,
  localparam int KEYW = AW - GRAN,
  localparam int CXW  = (NCTX > 1) ? $clog2(NCTX) : 1,
  localparam int OW   = (OMAX > 1) ? $clog2(OMAX) : 1,
  localparam int IDW  = (CXW > OW) ? CXW : OW,
  localparam int MIDW = IDW + 1,
  localparam int NR   = NCTX + 1,
  localparam int RRW  = $clog2(NR)
) (
  input  wire                  clk,
  input  wire                  rst_n,
  input  wire                  quiesce_i,
  input  wire [AW-1:0]         coh_base,
  input  wire [AW-1:0]         coh_limit,
  input  wire [1:0]            atom_prot_i,
  // ---------------------------------------------------------------- atomic contexts
  input  wire [NCTX-1:0]       a_req_valid,
  output wire [NCTX-1:0]       a_req_ready,           // accepted by memory this cycle
  input  wire [NCTX-1:0]       a_req_we,
  input  wire [NCTX*AW-1:0]    a_req_addr,
  input  wire [NCTX-1:0]       a_req_wide,
  input  wire [NCTX*64-1:0]    a_req_wdata,
  output wire [NCTX-1:0]       a_rsp_valid,
  output wire [63:0]           a_rsp_rdata,
  output wire                  a_rsp_err,
  // ---------------------------------------------------------------- ordinary port
  input  wire                  o_req_valid,
  output wire                  o_req_ready,
  input  wire                  o_req_we,
  input  wire [AW-1:0]         o_req_addr,
  input  wire [2:0]            o_req_size,
  input  wire [63:0]           o_req_wdata,
  input  wire [7:0]            o_req_be,
  input  wire [OIDW-1:0]       o_req_id,
  input  wire [1:0]            o_req_prot,
  output wire                  o_rsp_valid,
  input  wire                  o_rsp_ready,
  output wire [63:0]           o_rsp_rdata,
  output wire [OIDW-1:0]       o_rsp_id,
  output wire                  o_rsp_we,
  output wire [3:0]            o_rsp_status,
  // ---------------------------------------------------------------- memory master port (MemoryMatrix contract)
  output wire                  m_req_valid,
  input  wire                  m_req_ready,
  output wire                  m_req_we,
  output wire [AW-1:0]         m_req_addr,
  output wire [2:0]            m_req_size,
  output wire [63:0]           m_req_wdata,
  output wire [7:0]            m_req_be,
  output wire [MIDW-1:0]       m_req_id,
  output wire [1:0]            m_req_prot,
  input  wire                  m_rsp_valid,
  output wire                  m_rsp_ready,
  input  wire [63:0]           m_rsp_rdata,
  input  wire [MIDW-1:0]       m_rsp_id,
  input  wire                  m_rsp_we,
  input  wire [3:0]            m_rsp_status,
  // ---------------------------------------------------------------- lock table interface
  output wire [KEYW-1:0]       lk_o_key,
  input  wire                  lk_o_lock,
  input  wire                  lk_o_resv,
  output wire                  hold_valid,
  output wire                  hold_pres,
  output wire [KEYW-1:0]       hold_key,
  // ---------------------------------------------------------------- status / events
  output wire                  ord_idle_o,
  output wire                  ev_ord_rd,
  output wire                  ev_ord_wr,
  output wire                  ev_ord_err,
  output wire                  ev_ord_blk,
  output wire                  ev_acc_atomic             // an atomic request was accepted by memory this cycle
);
  localparam logic [3:0] OST_ALIGN  = sf_atomic_pkg::OST_ALIGN;
  localparam logic [3:0] OST_BADOP  = sf_atomic_pkg::OST_BADOP;
  localparam logic [3:0] OST_COHWIN = sf_atomic_pkg::OST_COHWIN;

`ifndef SYNTHESIS
  initial begin
    if (OMAX < 2 || (OMAX & (OMAX - 1)) != 0) begin
      $display("sf_atomic_ordering: OMAX must be a power of two >= 2 (got %0d)", OMAX);
      $finish;
    end
  end
`endif

  // ------------------------------------------------------------------ ordinary request classification
  wire        o_size_bad = (o_req_size > 3'd3);
  wire [2:0]  o_mask     = (o_req_size[1:0] == 2'd0) ? 3'd0 : (o_req_size[1:0] == 2'd1) ? 3'd1 : (o_req_size[1:0] == 2'd2) ? 3'd3 : 3'd7;
  wire        o_misal    = |(o_req_addr[2:0] & o_mask);
  wire        o_in_coh   = (COHERENT != 0) && (o_req_addr >= coh_base) && (o_req_addr < coh_limit);
  wire        o_local    = o_req_valid && (o_size_bad || o_misal || o_in_coh);
  wire [3:0]  o_local_st = o_size_bad ? OST_BADOP : (o_misal ? OST_ALIGN : OST_COHWIN);

  // ordinary response FIFO (OMAX entries, reserved at acceptance)
  reg [OW:0]            of_h, of_t;
  reg [OMAX-1:0]        of_fill, of_we;
  reg [OMAX*OIDW-1:0]   of_id;
  reg [OMAX*4-1:0]      of_st;
  reg [OMAX*64-1:0]     of_dat;
  wire [OW:0]           of_cnt   = of_t - of_h;
  wire                  o_space  = (of_cnt != (OW+1)'(OMAX));

  assign lk_o_key = o_req_addr[AW-1:GRAN];
  wire o_blocked  = o_req_we && (lk_o_lock || lk_o_resv);

  // ------------------------------------------------------------------ memory-port arbitration (round robin + grant lock)
  reg                lk_v;            // a request was presented and not accepted: keep the same requester
  reg [RRW-1:0]      lk_i;
  reg [RRW-1:0]      rr_q;
  wire               o_lk_sel = lk_v && (lk_i == RRW'(NCTX));
  wire               o_fresh  = o_req_valid && !o_local && o_space && !quiesce_i && !o_blocked;
  wire               o_present = o_lk_sel ? o_req_valid : o_fresh;

  reg [NR-1:0]       req_raw;
  always_comb begin
    req_raw = {o_present, a_req_valid};
  end

  reg                sel_v;
  reg [RRW-1:0]      sel_i;
  integer            rr_idx;
  always_comb begin
    sel_v  = 1'b0;
    sel_i  = '0;
    rr_idx = 0;
    if (lk_v) begin
      sel_i = lk_i;
      sel_v = req_raw[lk_i];
    end else begin
      for (int k = 0; k < NR; k++) begin
        rr_idx = 32'(rr_q) + k;
        if (rr_idx >= NR) rr_idx = rr_idx - NR;
        if (!sel_v && req_raw[rr_idx]) begin
          sel_v = 1'b1;
          sel_i = RRW'(rr_idx);
        end
      end
    end
  end

  wire sel_is_ord = (sel_i == RRW'(NCTX));
  wire acc        = sel_v && m_req_ready && rst_n;

  // request field mux
  reg               f_we;
  reg [AW-1:0]      f_addr;
  reg [2:0]         f_size;
  reg [63:0]        f_wdata;
  reg [7:0]         f_be;
  reg [MIDW-1:0]    f_id;
  reg [1:0]         f_prot;
  always_comb begin
    f_we    = 1'b0;
    f_addr  = '0;
    f_size  = 3'd2;
    f_wdata = '0;
    f_be    = '0;
    f_id    = '0;
    f_prot  = atom_prot_i;
    if (sel_is_ord) begin
      f_we    = o_req_we;
      f_addr  = o_req_addr;
      f_size  = o_req_size;
      f_wdata = o_req_wdata;
      f_be    = o_req_be;
      f_id    = {1'b1, IDW'(of_t[OW-1:0])};
      f_prot  = o_req_prot;
    end else begin
      for (int i = 0; i < NCTX; i++) begin
        if (sel_i == RRW'(i)) begin
          f_we    = a_req_we[i];
          f_addr  = a_req_addr[i*AW +: AW];
          f_size  = a_req_wide[i] ? 3'd3 : 3'd2;
          f_wdata = a_req_wdata[i*64 +: 64];
          f_be    = a_req_wide[i] ? 8'hFF : 8'h0F;
          f_id    = {1'b0, IDW'(i)};
        end
      end
    end
  end

  assign m_req_valid = sel_v && rst_n;
  assign m_req_we    = f_we;
  assign m_req_addr  = f_addr;
  assign m_req_size  = f_size;
  assign m_req_wdata = f_wdata;
  assign m_req_be    = f_be;
  assign m_req_id    = f_id;
  assign m_req_prot  = f_prot;

  reg [NCTX-1:0] a_ready_r;
  always_comb begin
    for (int i = 0; i < NCTX; i++) a_ready_r[i] = acc && (sel_i == RRW'(i));
  end
  assign a_req_ready = a_ready_r;
  assign ev_acc_atomic = acc && !sel_is_ord;
  wire _unused = &{1'b0, m_rsp_we};

  // ordinary request acceptance: through memory, or locally answered
  wire o_acc_mem   = acc && sel_is_ord;
  wire o_acc_local = o_local && o_space && !quiesce_i && rst_n;
  assign o_req_ready = o_acc_mem || o_acc_local;
  wire o_acc = o_req_valid && o_req_ready;

  // ------------------------------------------------------------------ hold-off of the next atomic grant on the ordinary write's granule
  reg o_wait_q;      // an ordinary write has been blocked by a LOCK and is still waiting
  wire presented_ord = sel_v && sel_is_ord;
  assign hold_valid = o_req_valid && o_req_we && !o_local && (o_wait_q || presented_ord);
  // hold_pres: the hold-off is caused by a request that is PRESENTED to memory (it can no longer be withdrawn and is never
  // blocked by a reservation).  Only this kind of hold-off may create a reservation: if a reservation were also created while the
  // ordinary write merely WAITS for a lock, the waiting write (blocked by the reservation) and the atomics (blocked by the hold-off)
  // would wait for each other forever.  (Found by the testbench: +test=contend.)
  assign hold_pres  = o_req_valid && o_req_we && !o_local && presented_ord;
  assign hold_key   = o_req_addr[AW-1:GRAN];

  // ------------------------------------------------------------------ responses
  wire rsp_ord = m_rsp_valid && m_rsp_id[MIDW-1];
  wire rsp_atm = m_rsp_valid && !m_rsp_id[MIDW-1];
  reg [NCTX-1:0] a_rsp_r;
  always_comb begin
    for (int i = 0; i < NCTX; i++) a_rsp_r[i] = rsp_atm && (m_rsp_id[IDW-1:0] == IDW'(i));
  end
  assign a_rsp_valid = a_rsp_r;
  assign a_rsp_rdata = m_rsp_rdata;
  assign a_rsp_err   = (m_rsp_status != 4'd0);
  assign m_rsp_ready = 1'b1;               // every response slot was reserved at acceptance

  wire [OW-1:0] of_hs = of_h[OW-1:0];
  assign o_rsp_valid  = rst_n && (of_cnt != '0) && of_fill[of_hs];
  assign o_rsp_rdata  = of_dat[of_hs*64 +: 64];
  assign o_rsp_id     = of_id[of_hs*OIDW +: OIDW];
  assign o_rsp_we     = of_we[of_hs];
  assign o_rsp_status = of_st[of_hs*4 +: 4];

  // ------------------------------------------------------------------ events
  assign ev_ord_rd  = o_acc_mem && !o_req_we;
  assign ev_ord_wr  = o_acc_mem &&  o_req_we;
  assign ev_ord_err = o_acc_local;
  assign ev_ord_blk = o_req_valid && o_blocked && !o_lk_sel && !o_local;
  assign ord_idle_o = (of_cnt == '0);

  // ------------------------------------------------------------------ state
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      lk_v     <= 1'b0;
      lk_i     <= '0;
      rr_q     <= '0;
      o_wait_q <= 1'b0;
      of_h     <= '0;
      of_t     <= '0;
      of_fill  <= '0;
      of_we    <= '0;
      of_id    <= '0;
      of_st    <= '0;
      of_dat   <= '0;
    end else begin
      // grant lock
      if (sel_v && !m_req_ready) begin
        lk_v <= 1'b1;
        lk_i <= sel_i;
      end else begin
        lk_v <= 1'b0;
      end
      if (acc) rr_q <= (sel_i == RRW'(NR - 1)) ? '0 : (sel_i + RRW'(1));

      // waiting-write flag
      o_wait_q <= o_req_valid && o_req_we && !o_acc && (lk_o_lock || o_wait_q);

      // ordinary response FIFO: allocate at acceptance
      if (o_acc) begin
        of_id  [of_t[OW-1:0]*OIDW +: OIDW] <= o_req_id;
        of_we  [of_t[OW-1:0]]              <= o_req_we;
        of_fill[of_t[OW-1:0]]              <= o_acc_local;
        of_st  [of_t[OW-1:0]*4 +: 4]       <= o_acc_local ? o_local_st : 4'd0;
        of_dat [of_t[OW-1:0]*64 +: 64]     <= 64'd0;
        of_t <= of_t + (OW+1)'(1);
      end
      // fill from the memory response
      if (rsp_ord) begin
        of_dat [m_rsp_id[OW-1:0]*64 +: 64] <= (m_rsp_status == 4'd0) ? m_rsp_rdata : 64'd0;
        of_st  [m_rsp_id[OW-1:0]*4 +: 4]   <= m_rsp_status;
        of_fill[m_rsp_id[OW-1:0]]          <= 1'b1;
      end
      // pop
      if (o_rsp_valid && o_rsp_ready) begin
        of_fill[of_hs] <= 1'b0;
        of_h <= of_h + (OW+1)'(1);
      end
    end
  end
  // ------------------------------------------------------------------ formal / simulation properties (formal/fv_ordering_props.svh)
`ifdef SF_ATOMIC_PROPS
`include "fv_ordering_props.svh"
`endif
endmodule

`default_nettype wire
