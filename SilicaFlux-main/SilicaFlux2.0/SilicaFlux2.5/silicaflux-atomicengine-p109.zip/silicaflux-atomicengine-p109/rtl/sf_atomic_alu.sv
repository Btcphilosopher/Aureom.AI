// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: sf_atomic_alu
//
// The read-modify-write function of every atomic operation: purely combinational, no state.
//
//   old_i  value read from memory (only the low 32 bits are used when wide = 0)
//   opd_i  operand: addend / mask / replacement value / new value for CAS
//   cmp_i  compare value (CAS only)
//   -> new_o  value to be written back (zero-extended to 64 bits for a 32-bit operation)
//      wr_o   1 when memory must be written (0 only for a failed CAS)
//      succ_o CAS: compare succeeded.  Every other valid opcode: 1.  Invalid opcode: 0.
//
// SEMANTICS (the whole contract; the independent model/sf_atomic_ref.py and the testbench's own sequential model implement
// exactly this and nothing else):
//   * every operation works on the operand WIDTH (32 or 64 bits); upper operand bits of a 32-bit operation are ignored;
//   * FADD wraps modulo 2**width.  There is no overflow trap and no overflow flag;
//   * MIN / MAX interpret both values as SIGNED two's complement of the operand width; MINU / MAXU as UNSIGNED;
//   * SWAP always writes `opd`; FAND / FOR / FXOR / FADD / MIN / MAX / MINU / MAXU always write their result
//     (even when it equals the old value: the location is written, which keeps ECC / coherence behaviour uniform);
//   * CAS writes `opd` only when old == cmp (width-masked compare), and writes NOTHING otherwise;
//   * the value returned to the requester is always the ORIGINAL memory value (handled by the engine, not here).
//
// Signed compare = unsigned compare with the sign bit of the operand width inverted (offset binary).
// Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_atomic_alu (
  input  wire [3:0]  op_i,
  input  wire        wide_i,
  input  wire [63:0] old_i,
  input  wire [63:0] opd_i,
  input  wire [63:0] cmp_i,
  output reg  [63:0] new_o,
  output reg         wr_o,
  output reg         succ_o,
  output reg         op_ok_o
);
  localparam logic [3:0] AOP_SWAP = sf_atomic_pkg::AOP_SWAP;
  localparam logic [3:0] AOP_FADD = sf_atomic_pkg::AOP_FADD;
  localparam logic [3:0] AOP_FAND = sf_atomic_pkg::AOP_FAND;
  localparam logic [3:0] AOP_FOR  = sf_atomic_pkg::AOP_FOR;
  localparam logic [3:0] AOP_FXOR = sf_atomic_pkg::AOP_FXOR;
  localparam logic [3:0] AOP_MIN  = sf_atomic_pkg::AOP_MIN;
  localparam logic [3:0] AOP_MAX  = sf_atomic_pkg::AOP_MAX;
  localparam logic [3:0] AOP_MINU = sf_atomic_pkg::AOP_MINU;
  localparam logic [3:0] AOP_MAXU = sf_atomic_pkg::AOP_MAXU;
  localparam logic [3:0] AOP_CAS  = sf_atomic_pkg::AOP_CAS;

  // operands reduced to the operand width, zero-extended
  wire [63:0] o = wide_i ? old_i : {32'b0, old_i[31:0]};
  wire [63:0] a = wide_i ? opd_i : {32'b0, opd_i[31:0]};
  wire [63:0] c = wide_i ? cmp_i : {32'b0, cmp_i[31:0]};

  wire [63:0] sum   = o + a;
  wire [63:0] sum_w = wide_i ? sum : {32'b0, sum[31:0]};

  // unsigned order of the zero-extended values == unsigned order at the operand width
  wire lt_u = (o < a);
  // signed order: invert the sign bit of the operand width, then compare unsigned
  wire [63:0] o_s = wide_i ? {~o[63], o[62:0]} : {32'b0, ~o[31], o[30:0]};
  wire [63:0] a_s = wide_i ? {~a[63], a[62:0]} : {32'b0, ~a[31], a[30:0]};
  wire lt_s = (o_s < a_s);

  wire eq = (o == c);

  always_comb begin
    new_o   = o;
    wr_o    = 1'b0;
    succ_o  = 1'b0;
    op_ok_o = 1'b1;
    case (op_i)
      AOP_SWAP: begin new_o = a;          wr_o = 1'b1; succ_o = 1'b1; end
      AOP_FADD: begin new_o = sum_w;      wr_o = 1'b1; succ_o = 1'b1; end
      AOP_FAND: begin new_o = o & a;      wr_o = 1'b1; succ_o = 1'b1; end
      AOP_FOR : begin new_o = o | a;      wr_o = 1'b1; succ_o = 1'b1; end
      AOP_FXOR: begin new_o = o ^ a;      wr_o = 1'b1; succ_o = 1'b1; end
      AOP_MIN : begin new_o = lt_s ? o : a; wr_o = 1'b1; succ_o = 1'b1; end
      AOP_MAX : begin new_o = lt_s ? a : o; wr_o = 1'b1; succ_o = 1'b1; end
      AOP_MINU: begin new_o = lt_u ? o : a; wr_o = 1'b1; succ_o = 1'b1; end
      AOP_MAXU: begin new_o = lt_u ? a : o; wr_o = 1'b1; succ_o = 1'b1; end
      AOP_CAS : begin
        succ_o = eq;
        wr_o   = eq;
        new_o  = eq ? a : o;
      end
      default: begin op_ok_o = 1'b0; end
    endcase
  end
endmodule

`default_nettype wire
