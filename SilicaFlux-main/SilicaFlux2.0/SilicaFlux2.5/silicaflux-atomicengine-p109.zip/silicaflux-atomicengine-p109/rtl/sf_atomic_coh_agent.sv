// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: sf_atomic_coh_agent
//
// The engine's coherent-window path: a ONE-LINE coherent agent of the CoherenceDirectory (Project 107, MSI directory protocol,
// 64-byte lines, four channels REQ / RSP / SNP / GNT, encodings of sf_coherence_pkg).  It exists so that an atomic read-modify-write on a
// CACHED address is performed under exclusive ownership and therefore cannot bypass coherence or leave a stale copy.
//
// ONE OPERATION  (identical in structure to what P107's sf_coherence_agent_adapter does for its own AMO):
//   1. REQ   GETM(line)                       the directory invalidates every sharer / takes the dirty line from the owner
//   2. GNT   DATA_M(line data)                PERFORM-ON-GRANT: in the very cycle the line arrives the ALU is applied to the target
//                                             word of the line.  No snoop can intervene between install and use.  This edge is the
//                                             LINEARISATION POINT (res_commit), exactly as in the uncached path.
//   3. RSP   COMPLETE                         unblocks the line at the directory
//   4. REQ   PUTM(modified line)              the line is written back and ownership dropped: the engine keeps no copy, so no stale
//                                             copy can exist anywhere after the operation; memory holds the new value
//   5. GNT   PUTACK                           the result is reported only now: "completion" implies memory is current
// RACES (same rules as P107 section 6):  between 3 and 5 the line sits in the EVICTION BUFFER (p_data) and still answers
//   SNP FWD_S / FWD_M with RSP DATA (keep = 0); the directory then treats the PUTM as stale and answers a bare PUTACK.
//   SNP INV for a line the agent does not hold is acknowledged (cannot hang) and flagged.
// One operation at a time; throughput of the coherent window = one operation per (GETM + PUTM) round trip -- documented limit.
// Reset: synchronous; an operation in progress is abandoned.  If the GETM grant had been received and the line modified but the
// PUTM not yet acknowledged, the modification is LOST (dirty data is dropped, as for every P107 agent) -- see docs/05_ERRORS_RESET.md.
// Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_atomic_coh_agent #(
  /* verilator lint_off UNUSEDPARAM */
  parameter int AGENT_ID   = 2,                // documentation only: the agent drives its own slice of the directory channels
  parameter int N_AGENTS   = 3,                // documentation only
  /* verilator lint_on UNUSEDPARAM */
  parameter int DIR_LINES  = 16,
  parameter int LINE_BYTES = 64,
  parameter int AW         = 32,
  localparam int LIW = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1,
  localparam int LB  = LINE_BYTES * 8,
  localparam int OFW = $clog2(LINE_BYTES)
) (
  input  wire                clk,
  input  wire                rst_n,
  input  wire [AW-1:0]       coh_base,
  // ---- operation from the engine
  input  wire                op_valid,
  output wire                op_ready,
  input  wire [3:0]          op_code,
  input  wire [AW-1:0]       op_addr,
  input  wire                op_wide,
  input  wire [63:0]         op_opd,
  input  wire [63:0]         op_cmp,
  output wire                res_valid,
  output wire [63:0]         res_old,
  output wire [63:0]         res_new,
  output wire                res_succ,
  output wire                res_wrote,
  output wire                res_err,
  output wire                res_commit,
  // ---- CoherenceDirectory channels (flat, ready/valid)
  output wire                rq_valid,
  input  wire                rq_ready,
  output wire [2:0]          rq_type,
  output wire [LIW-1:0]      rq_line,
  output wire [LB-1:0]       rq_data,
  output wire                rs_valid,
  input  wire                rs_ready,
  output wire [1:0]          rs_type,
  output wire [LIW-1:0]      rs_line,
  output wire [LB-1:0]       rs_data,
  output wire                rs_keep,
  input  wire                sn_valid,
  output wire                sn_ready,
  input  wire [1:0]          sn_type,
  input  wire [LIW-1:0]      sn_line,
  input  wire                gn_valid,
  output wire                gn_ready,
  input  wire [2:0]          gn_type,
  input  wire [LIW-1:0]      gn_line,
  input  wire [LB-1:0]       gn_data
);
  // protocol encodings (Project 107, sf_coherence_pkg) -- the values are part of the CoherenceDirectory ABI
  localparam logic [2:0] RQ_GETM = 3'd2, RQ_PUTM = 3'd5;
  localparam logic [1:0] RS_INVACK = 2'd1, RS_DATA = 2'd2, RS_COMPLETE = 2'd3;
  localparam logic [1:0] SN_INV = 2'd1, SN_FWD_S = 2'd2, SN_FWD_M = 2'd3;
  localparam logic [2:0] GN_DATA_M = 3'd2, GN_PUTACK = 3'd4;
  localparam logic [2:0] PS_NONE = 3'd0, PS_IM = 3'd2, PS_MI = 3'd4;
  localparam logic [1:0] AG_IDLE = 2'd0, AG_REQ = 2'd1, AG_EVICT = 2'd2, AG_RES = 2'd3;

  reg [1:0]   a_st;
  reg [2:0]   p_st;
  reg         p_lost;
  reg [LIW-1:0] p_line;
  reg [LB-1:0]  p_data;
  reg [3:0]   o_code;
  reg [AW-1:0] o_addr;
  reg         o_wide;
  reg [63:0]  o_opd, o_cmp;
  reg [63:0]  r_old, r_new;
  reg         r_succ, r_wrote, r_err;
  reg         rq_v;  reg [2:0] rq_t;  reg [LIW-1:0] rq_l;  reg [LB-1:0] rq_d;
  reg         rs_v;  reg [1:0] rs_t;  reg [LIW-1:0] rs_l;  reg [LB-1:0] rs_d;  reg rs_k;

  assign rq_valid = rq_v;  assign rq_type = rq_t;  assign rq_line = rq_l;  assign rq_data = rq_d;
  assign rs_valid = rs_v;  assign rs_type = rs_t;  assign rs_line = rs_l;  assign rs_data = rs_d;  assign rs_keep = rs_k;
  assign op_ready = (a_st == AG_IDLE) && rst_n;

  // ---- address decode of the latched operation and of the incoming one
  wire [AW-1:0]  off_i    = op_addr - coh_base;
  wire           in_dir_i = (op_addr >= coh_base) && (off_i < DIR_LINES * LINE_BYTES);
  wire [LIW-1:0] line_i   = off_i[OFW +: LIW];
  wire [AW-1:0]  off_o    = o_addr - coh_base;
  wire [OFW-1:0] boff     = off_o[OFW-1:0];

  // ---- snoop / grant arbitration (same rules as the P107 adapter): snoop > grant, both only when the RSP register is free
  assign sn_ready = !rs_v && rst_n;
  assign gn_ready = !rs_v && !sn_valid && rst_n;
  wire snp_take = sn_valid && !rs_v;
  wire gnt_take = gn_valid && !rs_v && !sn_valid;
  wire gnt_perf = gnt_take && (a_st == AG_REQ) && (p_st == PS_IM) && (gn_line == p_line) && (gn_type == GN_DATA_M);

  // ---- the read-modify-write on the target word of the granted line (combinational, perform-on-grant)
  reg  [63:0] old_w;
  reg  [LB-1:0] new_line;
  wire [63:0] alu_new;
  wire        alu_wr, alu_succ, alu_opok;
  always_comb begin
    old_w = o_wide ? gn_data[boff*8 +: 64] : {32'd0, gn_data[boff*8 +: 32]};
  end
  sf_atomic_alu u_alu (.op_i(o_code), .wide_i(o_wide), .old_i(old_w), .opd_i(o_opd), .cmp_i(o_cmp),
                       .new_o(alu_new), .wr_o(alu_wr), .succ_o(alu_succ), .op_ok_o(alu_opok));
  always_comb begin
    new_line = gn_data;
    if (alu_wr) begin
      if (o_wide) new_line[boff*8 +: 64] = alu_new;
      else        new_line[boff*8 +: 32] = alu_new[31:0];
    end
  end

  assign res_commit = gnt_perf;
  assign res_old    = gnt_perf ? old_w : r_old;
  assign res_new    = gnt_perf ? alu_new : r_new;
  assign res_succ   = gnt_perf ? alu_succ : r_succ;
  assign res_wrote  = gnt_perf ? alu_wr : r_wrote;
  assign res_valid  = (a_st == AG_RES);
  assign res_err    = r_err;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      a_st <= AG_IDLE; p_st <= PS_NONE; p_lost <= 1'b0; rq_v <= 1'b0; rs_v <= 1'b0; r_err <= 1'b0;
      r_old <= 64'd0; r_new <= 64'd0; r_succ <= 1'b0; r_wrote <= 1'b0;
    end else begin
      rq_v <= rq_v && !rq_ready;
      rs_v <= rs_v && !rs_ready;

      // ---------------- 1. snoop (highest priority)
      if (snp_take) begin
        if ((p_st == PS_MI) && !p_lost && (p_line == sn_line) && (sn_type == SN_FWD_S || sn_type == SN_FWD_M)) begin
          // the line is in the eviction buffer: intervene from it, then remember that it was lost
          rs_v <= 1'b1; rs_t <= RS_DATA; rs_l <= sn_line; rs_d <= p_data; rs_k <= 1'b0;
          p_lost <= 1'b1;
        end else if (sn_type == SN_INV) begin
          // an invalidation for a line this agent does not hold (it holds none outside the eviction window): acknowledge, never hang
          rs_v <= 1'b1; rs_t <= RS_INVACK; rs_l <= sn_line; rs_k <= 1'b0;
        end
      end

      // ---------------- 2. grant
      if (gnt_perf) begin
        // PERFORM-ON-GRANT: result registered, COMPLETE queued, the modified line goes straight into the eviction buffer and PUTM
        r_old <= old_w; r_new <= alu_new; r_succ <= alu_succ; r_wrote <= alu_wr; r_err <= 1'b0;
        rs_v <= 1'b1; rs_t <= RS_COMPLETE; rs_l <= gn_line; rs_k <= 1'b0;
        p_data <= new_line; p_st <= PS_MI; p_lost <= 1'b0;
        rq_v <= 1'b1; rq_t <= RQ_PUTM; rq_l <= p_line; rq_d <= new_line;
        a_st <= AG_EVICT;
      end else if (gnt_take && (gn_type == GN_PUTACK) && (a_st == AG_EVICT) && (p_st == PS_MI) && (gn_line == p_line)) begin
        p_st <= PS_NONE;
        a_st <= AG_RES;
      end else if (gnt_take && (a_st == AG_REQ || a_st == AG_EVICT)) begin
        // a grant that does not match the pending request: protocol failure -> abandon with an error
        // (cannot be produced by the verified directory; reported as AST_COH, location INDETERMINATE)
        r_err <= 1'b1; r_old <= 64'd0; r_new <= 64'd0; r_succ <= 1'b0; r_wrote <= 1'b0;
        p_st <= PS_NONE;
        a_st <= AG_RES;
      end

      // ---------------- 3. operation side
      case (a_st)
        AG_IDLE: begin
          if (op_valid) begin
            o_code <= op_code; o_addr <= op_addr; o_wide <= op_wide; o_opd <= op_opd; o_cmp <= op_cmp;
            if (!in_dir_i) begin
              r_err <= 1'b1; r_old <= 64'd0; r_new <= 64'd0; r_succ <= 1'b0; r_wrote <= 1'b0;
              a_st <= AG_RES;                                           // outside the directory range: no coherence traffic
            end else begin
              rq_v <= 1'b1; rq_t <= RQ_GETM; rq_l <= line_i; p_line <= line_i; p_st <= PS_IM; p_lost <= 1'b0;
              r_err <= 1'b0;
              a_st <= AG_REQ;
            end
          end
        end
        AG_RES: a_st <= AG_IDLE;                                         // the engine consumes the result in this cycle
        default: ;
      endcase
    end
  end

  wire _unused = &{1'b0, alu_opok, off_o[AW-1:OFW]};
endmodule

`default_nettype wire
