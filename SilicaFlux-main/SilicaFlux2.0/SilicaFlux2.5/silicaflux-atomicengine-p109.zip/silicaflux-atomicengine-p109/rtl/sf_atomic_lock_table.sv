// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: sf_atomic_lock_table
//
// The address-lock table.  N entries, entry i belongs to execution context i.  An entry is {valid, key}; the KEY is the
// lock granule number (address >> LOCK_GRAN_LOG2), so the granularity (memory word or cache line) is decided by the
// instantiating engine and not here.
//
// A lock is HELD from the edge that writes the entry (the context's grant) until the edge that releases it.  While held:
//   * no other command whose key is equal can be granted (query h_*: `h_lock`),
//   * no ORDINARY WRITE to the granule is forwarded to memory (query o_*: `o_lock`).
// Ordinary READS are never blocked (docs/03_ATOMICITY.md section 4: a read before the linearisation point returns the old
// value, one after it the new value; both are valid serial orders).
//
// TWO-SIDED FAIRNESS between ordinary writes and atomics on the same granule (no side can starve the other):
//   * hold-off  (hold_valid / hold_key, from sf_atomic_ordering): an ordinary write that is waiting for a lock or is already
//     presented to memory blocks new atomic grants on its granule (`h_hold`): the lock cannot be re-taken in front of it, and
//     a presented request is never withdrawn (the memory port obeys SFB2 R2);
//   * reservation (resv_set / resv_key_i): an atomic that was held off by a PRESENTED ordinary write registers its granule; ordinary
//     writes to it are then blocked (`o_resv`) until an atomic grant for that granule clears the reservation.  A reservation is
//     never created for a write that merely waits for a lock (that would let the two mechanisms block each other forever).
//   Together: after at most one ordinary write the atomic goes, after at most one atomic the ordinary write goes.
//
// Invariant (proved in formal/fv_lock_table.sv): no two valid entries hold the same key.  The engine only acquires a key
// for which h_lock = 0 and h_hold = 0 in the same cycle (checked by the engine's own assertions and by the proof).
//
// Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_atomic_lock_table #(
  parameter int N    = 2,                 // lock entries = execution contexts
  parameter int KEYW = 29,                // key width
  parameter int NH   = 4,                 // head query ports (one per client queue)
  localparam int IDXW = (N > 1) ? $clog2(N) : 1,
  localparam int CNTW = $clog2(N + 1)
) (
  input  wire                  clk,
  input  wire                  rst_n,
  // acquire (one per cycle): entry acq_idx must be free; written at the clock edge
  input  wire                  acq_valid,
  input  wire [IDXW-1:0]       acq_idx,
  input  wire [KEYW-1:0]       acq_key,
  // release (one per cycle)
  input  wire                  rel_valid,
  input  wire [IDXW-1:0]       rel_idx,
  // ordinary-write hold-off and atomic reservation
  input  wire                  hold_valid,
  input  wire                  hold_pres,
  input  wire [KEYW-1:0]       hold_key,
  input  wire                  resv_set,
  input  wire [KEYW-1:0]       resv_key_i,
  // queries for the queue heads: key -> held? / held off?
  input  wire [NH*KEYW-1:0]    h_key,
  output wire [NH-1:0]         h_lock,
  output wire [NH-1:0]         h_hold,
  output wire [NH-1:0]         h_hpres,               // the hold-off comes from a presented ordinary write
  // query for an ordinary write: key -> locked? / reserved?
  input  wire [KEYW-1:0]       o_key,
  output wire                  o_lock,
  output wire                  o_resv,
  // observability
  output wire [N-1:0]          lk_valid,
  output wire [N*KEYW-1:0]     lk_key,
  output wire [CNTW-1:0]       lk_cnt,
  output wire                  resv_v_o
);
  reg [N-1:0]      v_q;
  reg [N*KEYW-1:0] k_q;
  reg              resv_v_q;
  reg [KEYW-1:0]   resv_k_q;

  assign lk_valid = v_q;
  assign lk_key   = k_q;
  assign resv_v_o = resv_v_q;

  // ------------------------------------------------------------------ queries (registered state only)
  reg [NH-1:0] h_lock_r, h_hold_r, h_hpres_r;
  reg          o_lock_r;
  always_comb begin
    for (int h = 0; h < NH; h++) begin
      h_lock_r[h] = 1'b0;
      for (int i = 0; i < N; i++)
        if (v_q[i] && (k_q[i*KEYW +: KEYW] == h_key[h*KEYW +: KEYW])) h_lock_r[h] = 1'b1;
      h_hold_r[h]  = hold_valid && (hold_key == h_key[h*KEYW +: KEYW]);
      h_hpres_r[h] = hold_pres  && (hold_key == h_key[h*KEYW +: KEYW]);
    end
    o_lock_r = 1'b0;
    for (int i = 0; i < N; i++)
      if (v_q[i] && (k_q[i*KEYW +: KEYW] == o_key)) o_lock_r = 1'b1;
  end
  assign h_lock = h_lock_r;
  assign h_hold = h_hold_r;
  assign h_hpres = h_hpres_r;
  assign o_lock = o_lock_r;
  assign o_resv = resv_v_q && (resv_k_q == o_key);

  // ------------------------------------------------------------------ occupancy
  reg [CNTW-1:0] cnt_r;
  always_comb begin
    cnt_r = '0;
    for (int i = 0; i < N; i++) cnt_r = cnt_r + CNTW'(v_q[i]);
  end
  assign lk_cnt = cnt_r;

  // ------------------------------------------------------------------ state
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      v_q      <= '0;
      k_q      <= '0;
      resv_v_q <= 1'b0;
      resv_k_q <= '0;
    end else begin
      for (int i = 0; i < N; i++) begin
        if (rel_valid && (rel_idx == IDXW'(i))) v_q[i] <= 1'b0;
        if (acq_valid && (acq_idx == IDXW'(i))) begin
          v_q[i]                <= 1'b1;
          k_q[i*KEYW +: KEYW]   <= acq_key;
        end
      end
      // reservation: set by the engine, cleared by the atomic grant it was made for
      if (acq_valid && resv_v_q && (acq_key == resv_k_q)) begin
        resv_v_q <= 1'b0;
      end else if (resv_set && !resv_v_q) begin
        resv_v_q <= 1'b1;
        resv_k_q <= resv_key_i;
      end
    end
  end
  // ------------------------------------------------------------------ formal / simulation properties (formal/fv_lock_table_props.svh)
`ifdef SF_ATOMIC_PROPS
`include "fv_lock_table_props.svh"
`endif
endmodule

`default_nettype wire
