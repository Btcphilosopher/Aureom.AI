// =============================================================================
// SilicaFlux Project 109 -- AtomicEngine :: sf_atomic_engine   (primary RTL)
//
// Hardware atomic memory-operation engine: safe read-modify-write (swap, fetch-add/and/or/xor, signed / unsigned min / max,
// compare-and-swap; 32- and 64-bit) on a shared-memory window, for counters, queues, locks and accelerator coordination.
//
//   NC clients ---cmd--->  validate  --->  sf_atomic_queue (bounded, round robin)  --->  NCTX execution contexts
//                           (op, width, alignment, window, domain binding, destination, MemoryGuard R+W)
//      ^                                                                |  acquire lock, read, ALU, write, release
//      +-------- completion (old value, success, status, tag) <---------+  sf_atomic_lock_table / sf_atomic_alu
//   ordinary port (CPU / DMA loads and stores) ---> sf_atomic_ordering ---> single MEMORY master port (MemoryMatrix contract)
//   coherent window (COHERENT = 1) ---> sf_atomic_coh_agent ---> CoherenceDirectory (MSI, 64-byte lines)
//
// ATOMICITY (docs/03_ATOMICITY.md).  An atomic operation is the sequence  lock granule -> read -> ALU -> write -> unlock.
// While the lock is held no other atomic and no ordinary write can touch the granule, because EVERY access to the window passes
// through this engine's ordering unit (integration rule R1: the engine's memory port is the only path to the window).
// LINEARISATION POINT:
//   * operation that writes     : the edge at which the memory accepts the write request   (ev_c_wrote = 1);
//   * operation that does not   : failed CAS -- the edge at which the read response is consumed (no memory change; the lock
//                                 guarantees the value read is the value at every instant of the window) (ev_c_wrote = 0).
// The value returned is the original memory value read under the lock.
//
// RETRY RULE (docs/05_ERRORS_RESET.md): the engine never re-executes an operation by itself.  AST_OP .. AST_PERM and AST_READ left
// the memory untouched (safe to resubmit once the cause is fixed); AST_WRITE and AST_COH leave the location INDETERMINATE (read it
// back before resubmitting); reset drops every unfinished operation without a completion (an operation whose write was accepted
// before the reset stays written).
//
// Geometry: NC clients, QD queue entries per client, NCTX contexts (= address locks held in parallel), OMAX ordinary requests
// in flight.  Phase 1 of the project = NCTX 1, OP_EN {FADD, CAS}, W64_EN 0 (a configuration of THIS file, see docs/06).
//
// Classification: SYNTHESIZABLE (Yosys 0.33 flat-port style).
// =============================================================================
`default_nettype none

module sf_atomic_engine #(
  parameter int NC         = 4,                 // atomic clients (also the number of completion ports)
  parameter int QD         = 4,                 // queue entries per client (power of two)
  parameter int NCTX       = 2,                 // execution contexts = parallel address locks (1 .. 15)
  parameter int AW         = 32,
  parameter int TAGW       = 8,
  parameter int RIDW       = 4,
  parameter int DOMW       = 2,                 // 2**DOMW protection domains
  parameter int OIDW       = 4,                 // ordinary-port requester id width
  parameter int OMAX       = 4,                 // ordinary requests in flight (power of two)
  parameter int LOCK_GRAN  = 3,                 // lock granule = 2**LOCK_GRAN bytes: 3 = 8-byte word (default), 6 = 64-byte line
  parameter logic [15:0] OP_EN = 16'h07FE,      // bit i enables opcode i (1 .. 10)
  parameter int W64_EN     = 1,                 // 1: 64-bit operations supported
  parameter int COHERENT   = 0,                 // 1: coherent window through the CoherenceDirectory agent
  parameter int AGENT_ID   = 2,                 // coherence agent id of the engine
  parameter int N_AGENTS   = 3,                 // coherence agents in the system
  parameter int DIR_LINES  = 16,                // directory lines of the coherent window
  parameter int LINE_BYTES = 64,
  parameter int PERF       = 1,
  localparam int ND    = (1 << DOMW),
  localparam int CLW   = (NC > 1) ? $clog2(NC) : 1,
  localparam int PQW   = (QD > 1) ? $clog2(QD) : 1,
  localparam int CNTW  = PQW + 1,
  localparam int KEYW  = AW - LOCK_GRAN,
  localparam int PW    = 6 + AW + 64,           // stored payload {opd, addr, width, op}
  localparam int CXW   = (NCTX > 1) ? $clog2(NCTX) : 1,
  localparam int OW    = (OMAX > 1) ? $clog2(OMAX) : 1,
  localparam int IDW   = (CXW > OW) ? CXW : OW,
  localparam int MIDW  = IDW + 1,
  localparam int LIW   = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1,
  localparam int LB    = LINE_BYTES * 8,
  localparam int LCW   = $clog2(NCTX + 1)
) (
  input  wire                    clk,
  input  wire                    rst_n,
  // ---------------------------------------------------------------- static configuration (management plane)
  input  wire [AW-1:0]           win_base,            // uncached atomic window [win_base, win_limit), 8-byte aligned
  input  wire [AW-1:0]           win_limit,
  input  wire [AW-1:0]           coh_base,            // coherent atomic window (COHERENT = 1), line aligned
  input  wire [AW-1:0]           coh_limit,
  input  wire [NC*ND-1:0]        port_dom_mask,       // trusted binding: bit [c*ND+d] = port c may act for domain d
  input  wire [NC*NC-1:0]        dest_allow,          // bit [c*NC+d] = port c may name completion destination d
  input  wire [1:0]              atom_prot_i,         // MemoryMatrix prot {secure, priv} of the engine's own memory requests
  input  wire                    quiesce_i,           // stop accepting new commands / ordinary requests, let everything drain
  output wire                    idle_o,              // nothing queued, running or in flight
  output wire                    cfg_err_o,           // window configuration illegal (misaligned / empty / overlapping)
  // ---------------------------------------------------------------- command ingress (per client)
  input  wire [NC-1:0]           cmd_valid,
  output wire [NC-1:0]           cmd_ready,
  input  wire [NC*4-1:0]         cmd_op,
  input  wire [NC*AW-1:0]        cmd_addr,
  input  wire [NC*64-1:0]        cmd_opd,
  input  wire [NC*64-1:0]        cmd_cmp,
  input  wire [NC*2-1:0]         cmd_width,
  input  wire [NC*RIDW-1:0]      cmd_rid,
  input  wire [NC*TAGW-1:0]      cmd_tag,
  input  wire [NC*DOMW-1:0]      cmd_dom,
  input  wire [NC*CLW-1:0]       cmd_dest,
  input  wire [NC-1:0]           cmd_aq,
  input  wire [NC-1:0]           cmd_rl,
  // ---------------------------------------------------------------- MemoryGuard permission hook (combinational, per port)
  output wire [NC*AW-1:0]        grd_addr_o,
  output wire [NC*4-1:0]         grd_len_o,
  output wire [NC*DOMW-1:0]      grd_dom_o,
  input  wire [NC-1:0]           grd_ok_r,            // READ of {addr, len} permitted for this port and domain claim
  input  wire [NC-1:0]           grd_ok_w,            // WRITE permitted
  // ---------------------------------------------------------------- completion (per destination port)
  output wire [NC-1:0]           rsp_valid,
  input  wire [NC-1:0]           rsp_ready,
  output wire [NC*TAGW-1:0]      rsp_tag,
  output wire [NC*RIDW-1:0]      rsp_rid,
  output wire [NC*CLW-1:0]       rsp_src,
  output wire [NC*64-1:0]        rsp_old,
  output wire [NC-1:0]           rsp_succ,
  output wire [NC*4-1:0]         rsp_status,
  // ---------------------------------------------------------------- ordinary port (loads / stores that must meet the same memory)
  input  wire                    o_req_valid,
  output wire                    o_req_ready,
  input  wire                    o_req_we,
  input  wire [AW-1:0]           o_req_addr,
  input  wire [2:0]              o_req_size,          // log2(bytes): 0..3
  input  wire [63:0]             o_req_wdata,
  input  wire [7:0]              o_req_be,
  input  wire [OIDW-1:0]         o_req_id,
  input  wire [1:0]              o_req_prot,
  output wire                    o_rsp_valid,
  input  wire                    o_rsp_ready,
  output wire [63:0]             o_rsp_rdata,
  output wire [OIDW-1:0]         o_rsp_id,
  output wire                    o_rsp_we,
  output wire [3:0]              o_rsp_status,
  // ---------------------------------------------------------------- memory master port (MemoryMatrix contract, relative byte lanes)
  output wire                    m_req_valid,
  input  wire                    m_req_ready,
  output wire                    m_req_we,
  output wire [AW-1:0]           m_req_addr,
  output wire [2:0]              m_req_size,
  output wire [63:0]             m_req_wdata,
  output wire [7:0]              m_req_be,
  output wire [MIDW-1:0]         m_req_id,
  output wire [1:0]              m_req_prot,
  input  wire                    m_rsp_valid,
  output wire                    m_rsp_ready,
  input  wire [63:0]             m_rsp_rdata,
  input  wire [MIDW-1:0]         m_rsp_id,
  input  wire                    m_rsp_we,
  input  wire [3:0]              m_rsp_status,
  // ---------------------------------------------------------------- CoherenceDirectory agent channels (tie off when COHERENT = 0)
  output wire                    rq_valid,
  input  wire                    rq_ready,
  output wire [2:0]              rq_type,
  output wire [LIW-1:0]          rq_line,
  output wire [LB-1:0]           rq_data,
  output wire                    rs_valid,
  input  wire                    rs_ready,
  output wire [1:0]              rs_type,
  output wire [LIW-1:0]          rs_line,
  output wire [LB-1:0]           rs_data,
  output wire                    rs_keep,
  input  wire                    sn_valid,
  output wire                    sn_ready,
  input  wire [1:0]              sn_type,
  input  wire [LIW-1:0]          sn_line,
  input  wire                    gn_valid,
  output wire                    gn_ready,
  input  wire [2:0]              gn_type,
  input  wire [LIW-1:0]          gn_line,
  input  wire [LB-1:0]           gn_data,
  // ---------------------------------------------------------------- events for scoreboards / traces (one slot per context)
  output wire [NCTX-1:0]         ev_c_valid,          // linearisation point reached this cycle
  output wire [NCTX*CLW-1:0]     ev_c_client,
  output wire [NCTX*TAGW-1:0]    ev_c_tag,
  output wire [NCTX*AW-1:0]      ev_c_addr,
  output wire [NCTX*4-1:0]       ev_c_op,
  output wire [NCTX-1:0]         ev_c_wide,
  output wire [NCTX*64-1:0]      ev_c_old,
  output wire [NCTX*64-1:0]      ev_c_new,
  output wire [NCTX-1:0]         ev_c_succ,
  output wire [NCTX-1:0]         ev_c_wrote,
  output wire [NCTX-1:0]         ev_c_coh,
  // ---------------------------------------------------------------- lock observability (assertions / formal)
  output wire [NCTX-1:0]         lk_valid_o,
  output wire [NCTX*KEYW-1:0]    lk_key_o,
  // ---------------------------------------------------------------- diagnostics and performance
  input  wire                    diag_clr_i,
  output wire                    diag_valid_o,        // a command was rejected since the last clear
  output wire [CLW-1:0]          diag_client_o,
  output wire [3:0]              diag_status_o,
  output wire [AW-1:0]           diag_addr_o,
  input  wire                    perf_clr_i,
  output wire [sf_atomic_pkg::PF_N*32-1:0] perf_o
);
  // ------------------------------------------------------------------ package aliases
  localparam logic [3:0] AOP_NONE = sf_atomic_pkg::AOP_NONE;
  localparam logic [3:0] AOP_CAS  = sf_atomic_pkg::AOP_CAS;
  localparam logic [3:0] AST_OK     = sf_atomic_pkg::AST_OK;
  localparam logic [3:0] AST_OP     = sf_atomic_pkg::AST_OP;
  localparam logic [3:0] AST_WIDTH  = sf_atomic_pkg::AST_WIDTH;
  localparam logic [3:0] AST_ALIGN  = sf_atomic_pkg::AST_ALIGN;
  localparam logic [3:0] AST_RANGE  = sf_atomic_pkg::AST_RANGE;
  localparam logic [3:0] AST_DOMAIN = sf_atomic_pkg::AST_DOMAIN;
  localparam logic [3:0] AST_DEST   = sf_atomic_pkg::AST_DEST;
  localparam logic [3:0] AST_PERM   = sf_atomic_pkg::AST_PERM;
  localparam logic [3:0] AST_READ   = sf_atomic_pkg::AST_READ;
  localparam logic [3:0] AST_WRITE  = sf_atomic_pkg::AST_WRITE;
  localparam logic [3:0] AST_COH    = sf_atomic_pkg::AST_COH;
  localparam logic [2:0] CX_IDLE = sf_atomic_pkg::CX_IDLE;
  localparam logic [2:0] CX_RD   = sf_atomic_pkg::CX_RD;
  localparam logic [2:0] CX_RW   = sf_atomic_pkg::CX_RW;
  localparam logic [2:0] CX_WR   = sf_atomic_pkg::CX_WR;
  localparam logic [2:0] CX_WW   = sf_atomic_pkg::CX_WW;
  localparam logic [2:0] CX_COH  = sf_atomic_pkg::CX_COH;
  localparam logic [2:0] CX_FIN  = sf_atomic_pkg::CX_FIN;

`ifndef SYNTHESIS
  initial begin
    if (NCTX < 1 || NCTX > 15) begin $display("sf_atomic_engine: NCTX must be 1..15"); $finish; end
    if (LOCK_GRAN < 3 || LOCK_GRAN > 12) begin $display("sf_atomic_engine: LOCK_GRAN must be 3..12"); $finish; end
    if (NC > 15) begin $display("sf_atomic_engine: NC must be <= 15"); $finish; end
    if (AW < 16) begin $display("sf_atomic_engine: AW must be >= 16"); $finish; end
  end
`endif

  // ------------------------------------------------------------------ window configuration
  wire uc_cfg_ok  = (win_base[2:0] == 3'd0) && (win_limit[2:0] == 3'd0) && (win_limit > win_base);
  wire ch_cfg_ok  = (COHERENT != 0) && (coh_base[5:0] == 6'd0) && (coh_limit[5:0] == 6'd0) && (coh_limit > coh_base) &&
                    ((coh_limit - coh_base) <= (DIR_LINES * LINE_BYTES));     // the window must fit the directory
  wire overlap    = uc_cfg_ok && ch_cfg_ok && (win_base < coh_limit) && (coh_base < win_limit);
  assign cfg_err_o = (!uc_cfg_ok && (win_base != win_limit)) ||
                     ((COHERENT != 0) && !ch_cfg_ok && (coh_base != coh_limit)) || overlap;

  // ------------------------------------------------------------------ ingress validation
  reg [NC*4-1:0]    pre_err;
  reg [NC*CLW-1:0]  dest_eff;
  reg [NC*PW-1:0]   in_pay;
  reg [NC-1:0]      c_coh_in;
  always_comb begin
    for (int c = 0; c < NC; c++) begin : g_val
      reg [3:0]      op_c;
      reg [1:0]      wd_c;
      reg [AW-1:0]   ad_c;
      reg            op_ok, wd_ok, wide_c, al_ok, in_uc, in_ch, rg_ok, dm_ok, de_ok, pm_ok;
      reg [CLW-1:0]  ds_c;
      reg [DOMW-1:0] dm_c;
      op_c   = cmd_op[c*4 +: 4];
      wd_c   = cmd_width[c*2 +: 2];
      ad_c   = cmd_addr[c*AW +: AW];
      ds_c   = cmd_dest[c*CLW +: CLW];
      dm_c   = cmd_dom[c*DOMW +: DOMW];
      op_ok  = (op_c != AOP_NONE) && (op_c < 4'd11) && OP_EN[op_c];
      wide_c = (wd_c == 2'd1);
      wd_ok  = (wd_c == 2'd0) || ((wd_c == 2'd1) && (W64_EN != 0));
      al_ok  = wide_c ? (ad_c[2:0] == 3'd0) : (ad_c[1:0] == 2'd0);
      in_uc  = uc_cfg_ok && (ad_c >= win_base) && (ad_c < win_limit);
      in_ch  = ch_cfg_ok && (ad_c >= coh_base) && (ad_c < coh_limit);
      rg_ok  = in_uc || in_ch;
      dm_ok  = port_dom_mask[c*ND + 32'(dm_c)];
      de_ok  = (32'(ds_c) < NC) && dest_allow[c*NC + 32'(ds_c)];
      pm_ok  = grd_ok_r[c] && grd_ok_w[c];
      pre_err[c*4 +: 4] = !op_ok ? AST_OP :
                          !wd_ok ? AST_WIDTH :
                          !al_ok ? AST_ALIGN :
                          !rg_ok ? AST_RANGE :
                          !dm_ok ? AST_DOMAIN :
                          !de_ok ? AST_DEST :
                          !pm_ok ? AST_PERM : AST_OK;
      dest_eff[c*CLW +: CLW] = de_ok ? ds_c : CLW'(c);
      in_pay[c*PW +: PW]     = {cmd_opd[c*64 +: 64], ad_c, wd_c, op_c};
      c_coh_in[c]            = in_ch;
    end
  end
  generate
    for (genvar c = 0; c < NC; c++) begin : g_grd
      assign grd_addr_o[c*AW +: AW]     = cmd_addr[c*AW +: AW];
      assign grd_len_o[c*4 +: 4]        = (cmd_width[c*2 +: 2] == 2'd1) ? 4'd8 : 4'd4;
      assign grd_dom_o[c*DOMW +: DOMW]  = cmd_dom[c*DOMW +: DOMW];
    end
  endgenerate

  // ------------------------------------------------------------------ queue
  wire [NC-1:0]       q_in_ready, hd_valid, hd_aq, hd_rl;
  wire [NC*PW-1:0]    hd_pay;
  wire [NC*CNTW-1:0]  q_run, q_aqrun;
  wire [NC-1:0]       elig;
  wire                gnt_valid;
  wire [CLW-1:0]      gnt_client;
  wire [PQW-1:0]      gnt_slot;
  wire [PW-1:0]       gnt_pay;
  wire [63:0]         gnt_cmp;
  wire [TAGW-1:0]     gnt_tag;
  wire [RIDW-1:0]     gnt_rid;
  wire                res_valid;
  wire [CLW-1:0]      res_client;
  wire [PQW-1:0]      res_slot;
  wire [63:0]         res_old;
  wire                res_succ;
  wire [3:0]          res_status;
  wire                q_empty;
  wire [NC-1:0]       q_full;
  wire [NC-1:0]       ev_in, ev_dlv, ev_dlv_err;
  wire [NC*PQW-1:0]   ev_in_slot, ev_dlv_slot;

  sf_atomic_queue #(.NC(NC), .QD(QD), .PW(PW), .TAGW(TAGW), .RIDW(RIDW)) u_q (
    .clk(clk), .rst_n(rst_n), .block_in(quiesce_i),
    .in_valid(cmd_valid), .in_ready(q_in_ready), .in_pay(in_pay), .in_cmp(cmd_cmp),
    .in_tag(cmd_tag), .in_rid(cmd_rid), .in_dest(dest_eff), .in_aq(cmd_aq), .in_rl(cmd_rl), .in_pre_err(pre_err),
    .hd_valid(hd_valid), .hd_pay(hd_pay), .hd_aq(hd_aq), .hd_rl(hd_rl), .q_run(q_run), .q_aqrun(q_aqrun),
    .elig(elig), .gnt_valid(gnt_valid), .gnt_client(gnt_client), .gnt_slot(gnt_slot), .gnt_pay(gnt_pay),
    .gnt_cmp(gnt_cmp), .gnt_tag(gnt_tag), .gnt_rid(gnt_rid),
    .res_valid(res_valid), .res_client(res_client), .res_slot(res_slot), .res_old(res_old),
    .res_succ(res_succ), .res_status(res_status),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_tag(rsp_tag), .rsp_rid(rsp_rid), .rsp_src(rsp_src),
    .rsp_old(rsp_old), .rsp_succ(rsp_succ), .rsp_status(rsp_status),
    .empty_o(q_empty), .full_o(q_full), .ev_in(ev_in), .ev_in_slot(ev_in_slot),
    .ev_dlv(ev_dlv), .ev_dlv_slot(ev_dlv_slot), .ev_dlv_err(ev_dlv_err)
  );
  assign cmd_ready = q_in_ready;

  // ------------------------------------------------------------------ head decode and eligibility
  reg  [NC*KEYW-1:0]  h_key;
  reg  [NC-1:0]       h_is_coh;
  always_comb begin
    for (int c = 0; c < NC; c++) begin
      reg [AW-1:0] a;
      a = hd_pay[c*PW + 6 +: AW];
      h_key[c*KEYW +: KEYW] = a[AW-1:LOCK_GRAN];
      h_is_coh[c] = ch_cfg_ok && (a >= coh_base) && (a < coh_limit);
    end
  end

  // execution-context state (flat vectors, context i = slice i)
  reg [NCTX*3-1:0]    cx_st;
  reg [NCTX*CLW-1:0]  cx_cl;
  reg [NCTX*PQW-1:0]  cx_slot;
  reg [NCTX*TAGW-1:0] cx_tag;
  reg [NCTX*4-1:0]    cx_op;
  reg [NCTX-1:0]      cx_wide;
  reg [NCTX*AW-1:0]   cx_addr;
  reg [NCTX*64-1:0]   cx_opd, cx_cmp, cx_old, cx_new;
  reg [NCTX-1:0]      cx_succ, cx_lkheld, cx_coh, cx_wrote, cx_sent;
  reg [NCTX*4-1:0]    cx_stat;

  // free context (lowest index) and coherence agent availability
  reg              free_any;
  reg [CXW-1:0]    free_idx;
  reg              coh_busy;
  always_comb begin
    free_any = 1'b0;
    free_idx = '0;
    coh_busy = 1'b0;
    for (int i = NCTX - 1; i >= 0; i--) begin
      if (cx_st[i*3 +: 3] == CX_IDLE) begin
        free_any = 1'b1;
        free_idx = CXW'(i);
      end
      if (cx_coh[i] && (cx_st[i*3 +: 3] != CX_IDLE)) coh_busy = 1'b1;
    end
  end

  // lock-table queries
  wire [NC-1:0]    h_lock, h_hold, h_hpres;
  wire             lk_o_lock, lk_o_resv;
  wire [KEYW-1:0]  lk_o_key;
  wire             hold_valid, hold_pres;
  wire [KEYW-1:0]  hold_key;
  wire [NCTX-1:0]  lk_valid;
  wire [NCTX*KEYW-1:0] lk_key;
  wire [LCW-1:0]   lk_cnt_w;
  wire             resv_v;

  // a head whose address is in the coherent window needs the (single) coherence agent
  wire [NC-1:0] coh_blk = coh_busy ? h_is_coh : {NC{1'b0}};

  reg [NC-1:0] ord_ok;
  always_comb begin
    for (int c = 0; c < NC; c++)
      ord_ok[c] = (!hd_rl[c] || (q_run[c*CNTW +: CNTW] == '0)) && (q_aqrun[c*CNTW +: CNTW] == '0);
  end

  wire [NC-1:0] elig_nolock = hd_valid & {NC{free_any}} & ~coh_blk & ord_ok;
  assign elig = elig_nolock & ~h_lock & ~h_hold;

  // reservation: a head that is held off ONLY by a PRESENTED ordinary write registers its granule (ordinary writes then wait)
  reg              resv_set;
  reg [KEYW-1:0]   resv_key;
  always_comb begin
    resv_set = 1'b0;
    resv_key = '0;
    for (int c = NC - 1; c >= 0; c--) begin
      if (elig_nolock[c] && h_hpres[c] && !h_lock[c]) begin
        resv_set = 1'b1;
        resv_key = h_key[c*KEYW +: KEYW];
      end
    end
  end

  // grant decode
  wire [3:0]      g_op   = gnt_pay[3:0];
  wire [1:0]      g_wd   = gnt_pay[5:4];
  wire [AW-1:0]   g_addr = gnt_pay[6 +: AW];
  wire [63:0]     g_opd  = gnt_pay[6+AW +: 64];
  wire            g_is_coh = ch_cfg_ok && (g_addr >= coh_base) && (g_addr < coh_limit);

  // ------------------------------------------------------------------ ordering unit and memory port
  wire [NCTX-1:0]    a_req_valid, a_req_ready, a_req_we, a_req_wide, a_rsp_valid;
  wire [NCTX*AW-1:0] a_req_addr;
  wire [NCTX*64-1:0] a_req_wdata;
  wire [63:0]        a_rsp_rdata;
  wire               a_rsp_err;
  wire               ord_idle, ev_ord_rd, ev_ord_wr, ev_ord_err, ev_ord_blk, ev_acc_atomic;

  sf_atomic_ordering #(.NCTX(NCTX), .AW(AW), .GRAN(LOCK_GRAN), .OMAX(OMAX), .OIDW(OIDW), .COHERENT(COHERENT)) u_ord (
    .clk(clk), .rst_n(rst_n), .quiesce_i(quiesce_i), .coh_base(coh_base), .coh_limit(coh_limit), .atom_prot_i(atom_prot_i),
    .a_req_valid(a_req_valid), .a_req_ready(a_req_ready), .a_req_we(a_req_we), .a_req_addr(a_req_addr),
    .a_req_wide(a_req_wide), .a_req_wdata(a_req_wdata), .a_rsp_valid(a_rsp_valid), .a_rsp_rdata(a_rsp_rdata),
    .a_rsp_err(a_rsp_err),
    .o_req_valid(o_req_valid), .o_req_ready(o_req_ready), .o_req_we(o_req_we), .o_req_addr(o_req_addr),
    .o_req_size(o_req_size), .o_req_wdata(o_req_wdata), .o_req_be(o_req_be), .o_req_id(o_req_id), .o_req_prot(o_req_prot),
    .o_rsp_valid(o_rsp_valid), .o_rsp_ready(o_rsp_ready), .o_rsp_rdata(o_rsp_rdata), .o_rsp_id(o_rsp_id),
    .o_rsp_we(o_rsp_we), .o_rsp_status(o_rsp_status),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr),
    .m_req_size(m_req_size), .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id), .m_req_prot(m_req_prot),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id),
    .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status),
    .lk_o_key(lk_o_key), .lk_o_lock(lk_o_lock), .lk_o_resv(lk_o_resv), .hold_valid(hold_valid), .hold_pres(hold_pres), .hold_key(hold_key),
    .ord_idle_o(ord_idle), .ev_ord_rd(ev_ord_rd), .ev_ord_wr(ev_ord_wr), .ev_ord_err(ev_ord_err),
    .ev_ord_blk(ev_ord_blk), .ev_acc_atomic(ev_acc_atomic)
  );

  // ------------------------------------------------------------------ lock table
  wire rel_valid;
  wire [CXW-1:0] rel_idx;
  sf_atomic_lock_table #(.N(NCTX), .KEYW(KEYW), .NH(NC)) u_lk (
    .clk(clk), .rst_n(rst_n),
    .acq_valid(gnt_valid), .acq_idx(free_idx), .acq_key(g_addr[AW-1:LOCK_GRAN]),
    .rel_valid(rel_valid), .rel_idx(rel_idx),
    .hold_valid(hold_valid), .hold_pres(hold_pres), .hold_key(hold_key), .resv_set(resv_set), .resv_key_i(resv_key),
    .h_key(h_key), .h_lock(h_lock), .h_hold(h_hold), .h_hpres(h_hpres),
    .o_key(lk_o_key), .o_lock(lk_o_lock), .o_resv(lk_o_resv),
    .lk_valid(lk_valid), .lk_key(lk_key), .lk_cnt(lk_cnt_w), .resv_v_o(resv_v)
  );
  assign lk_valid_o = lk_valid;
  assign lk_key_o   = lk_key;

  // ------------------------------------------------------------------ shared ALU (one response per cycle)
  reg [3:0]   alu_op;
  reg         alu_wide;
  reg [63:0]  alu_opd, alu_cmp;
  always_comb begin
    alu_op = AOP_NONE; alu_wide = 1'b0; alu_opd = 64'd0; alu_cmp = 64'd0;
    for (int i = 0; i < NCTX; i++) begin
      if (a_rsp_valid[i]) begin
        alu_op   = cx_op[i*4 +: 4];
        alu_wide = cx_wide[i];
        alu_opd  = cx_opd[i*64 +: 64];
        alu_cmp  = cx_cmp[i*64 +: 64];
      end
    end
  end
  wire [63:0] alu_new;
  wire        alu_wr, alu_succ, alu_opok;
  sf_atomic_alu u_alu (.op_i(alu_op), .wide_i(alu_wide), .old_i(a_rsp_rdata), .opd_i(alu_opd), .cmp_i(alu_cmp),
                       .new_o(alu_new), .wr_o(alu_wr), .succ_o(alu_succ), .op_ok_o(alu_opok));
  wire [63:0] alu_old = alu_wide ? a_rsp_rdata : {32'd0, a_rsp_rdata[31:0]};

  // ------------------------------------------------------------------ memory-request outputs of the contexts
  reg [NCTX-1:0]    rq_v, rq_w;
  always_comb begin
    for (int i = 0; i < NCTX; i++) begin
      rq_v[i] = (cx_st[i*3 +: 3] == CX_RD) || (cx_st[i*3 +: 3] == CX_WR);
      rq_w[i] = (cx_st[i*3 +: 3] == CX_WR);
    end
  end
  assign a_req_valid = rq_v;
  assign a_req_we    = rq_w;
  assign a_req_wide  = cx_wide;
  assign a_req_addr  = cx_addr;
  assign a_req_wdata = cx_new;

  // ------------------------------------------------------------------ coherence agent (phase 4)
  wire             ca_op_valid, ca_op_ready, ca_res_valid, ca_res_err, ca_res_succ, ca_res_wrote, ca_commit;
  wire [63:0]      ca_res_old, ca_res_new;
  reg  [CXW-1:0]   ca_owner;
  reg              ca_sel;
  always_comb begin
    ca_sel   = 1'b0;
    ca_owner = '0;
    for (int i = NCTX - 1; i >= 0; i--) begin
      if (cx_coh[i] && (cx_st[i*3 +: 3] == CX_COH)) begin ca_sel = 1'b1; ca_owner = CXW'(i); end
    end
  end
  assign ca_op_valid = ca_sel && !cx_sent[ca_owner];

  generate
    if (COHERENT != 0) begin : g_coh
      sf_atomic_coh_agent #(.AGENT_ID(AGENT_ID), .N_AGENTS(N_AGENTS), .DIR_LINES(DIR_LINES), .LINE_BYTES(LINE_BYTES), .AW(AW)) u_ca (
        .clk(clk), .rst_n(rst_n), .coh_base(coh_base),
        .op_valid(ca_op_valid), .op_ready(ca_op_ready), .op_code(cx_op[ca_owner*4 +: 4]), .op_addr(cx_addr[ca_owner*AW +: AW]),
        .op_wide(cx_wide[ca_owner]), .op_opd(cx_opd[ca_owner*64 +: 64]), .op_cmp(cx_cmp[ca_owner*64 +: 64]),
        .res_valid(ca_res_valid), .res_old(ca_res_old), .res_new(ca_res_new), .res_succ(ca_res_succ),
        .res_wrote(ca_res_wrote), .res_err(ca_res_err), .res_commit(ca_commit),
        .rq_valid(rq_valid), .rq_ready(rq_ready), .rq_type(rq_type), .rq_line(rq_line), .rq_data(rq_data),
        .rs_valid(rs_valid), .rs_ready(rs_ready), .rs_type(rs_type), .rs_line(rs_line), .rs_data(rs_data), .rs_keep(rs_keep),
        .sn_valid(sn_valid), .sn_ready(sn_ready), .sn_type(sn_type), .sn_line(sn_line),
        .gn_valid(gn_valid), .gn_ready(gn_ready), .gn_type(gn_type), .gn_line(gn_line), .gn_data(gn_data)
      );
    end else begin : g_nocoh
      assign ca_op_ready  = 1'b0;
      assign ca_res_valid = 1'b0;
      assign ca_res_old   = 64'd0;
      assign ca_res_new   = 64'd0;
      assign ca_res_succ  = 1'b0;
      assign ca_res_wrote = 1'b0;
      assign ca_res_err   = 1'b0;
      assign ca_commit    = 1'b0;
      assign rq_valid = 1'b0;  assign rq_type = 3'd0;  assign rq_line = '0;  assign rq_data = '0;
      assign rs_valid = 1'b0;  assign rs_type = 2'd0;  assign rs_line = '0;  assign rs_data = '0;  assign rs_keep = 1'b0;
      assign sn_ready = 1'b0;
      assign gn_ready = 1'b0;
      wire _unused_coh = &{1'b0, rq_ready, rs_ready, sn_valid, sn_type, sn_line, gn_valid, gn_type, gn_line, gn_data};
    end
  endgenerate

  // ------------------------------------------------------------------ completion write-back (one context per cycle)
  reg              fin_any;
  reg [CXW-1:0]    fin_idx;
  always_comb begin
    fin_any = 1'b0;
    fin_idx = '0;
    for (int i = NCTX - 1; i >= 0; i--) begin
      if (cx_st[i*3 +: 3] == CX_FIN) begin fin_any = 1'b1; fin_idx = CXW'(i); end
    end
  end
  assign res_valid  = fin_any;
  assign res_client = cx_cl[fin_idx*CLW +: CLW];
  assign res_slot   = cx_slot[fin_idx*PQW +: PQW];
  assign res_old    = cx_old[fin_idx*64 +: 64];
  assign res_succ   = cx_succ[fin_idx] && (cx_stat[fin_idx*4 +: 4] == AST_OK);
  assign res_status = cx_stat[fin_idx*4 +: 4];
  assign rel_valid  = fin_any && cx_lkheld[fin_idx];
  assign rel_idx    = fin_idx;

  // ------------------------------------------------------------------ events (per context)
  reg [NCTX-1:0]      ev_v, ev_wd, ev_sc, ev_wr, ev_ch;
  reg [NCTX*64-1:0]   ev_o, ev_n;
  reg [NCTX-1:0]      memerr_v, casfail_v;
  always_comb begin
    for (int i = 0; i < NCTX; i++) begin
      reg [2:0] s;
      s = cx_st[i*3 +: 3];
      ev_v[i]  = 1'b0; ev_wr[i] = 1'b0; ev_sc[i] = cx_succ[i]; ev_o[i*64 +: 64] = cx_old[i*64 +: 64];
      ev_n[i*64 +: 64] = cx_new[i*64 +: 64]; ev_wd[i] = cx_wide[i]; ev_ch[i] = 1'b0;
      memerr_v[i] = 1'b0; casfail_v[i] = 1'b0;
      if ((s == CX_RW) && a_rsp_valid[i] && !a_rsp_err && !alu_wr) begin
        // linearisation point of an operation that does not write (failed CAS)
        ev_v[i] = 1'b1; ev_wr[i] = 1'b0; ev_sc[i] = alu_succ; ev_o[i*64 +: 64] = alu_old; ev_n[i*64 +: 64] = alu_old;
        casfail_v[i] = (cx_op[i*4 +: 4] == AOP_CAS) && !alu_succ;
      end
      if ((s == CX_WR) && a_req_ready[i]) begin
        ev_v[i] = 1'b1; ev_wr[i] = 1'b1;
      end
      if ((s == CX_COH) && ca_commit && (ca_owner == CXW'(i)) && ca_sel) begin
        ev_v[i] = 1'b1; ev_wr[i] = ca_res_wrote; ev_ch[i] = 1'b1; ev_sc[i] = ca_res_succ;
        ev_o[i*64 +: 64] = ca_res_old; ev_n[i*64 +: 64] = ca_res_new;
        casfail_v[i] = (cx_op[i*4 +: 4] == AOP_CAS) && !ca_res_succ;
      end
      if (((s == CX_RW) && a_rsp_valid[i] && a_rsp_err) || ((s == CX_WW) && a_rsp_valid[i] && a_rsp_err) ||
          ((s == CX_COH) && ca_res_valid && ca_res_err && (ca_owner == CXW'(i)) && ca_sel))
        memerr_v[i] = 1'b1;
    end
  end
  assign ev_c_valid  = ev_v;
  assign ev_c_client = cx_cl;
  assign ev_c_tag    = cx_tag;
  assign ev_c_addr   = cx_addr;
  assign ev_c_op     = cx_op;
  assign ev_c_wide   = ev_wd;
  assign ev_c_old    = ev_o;
  assign ev_c_new    = ev_n;
  assign ev_c_succ   = ev_sc;
  assign ev_c_wrote  = ev_wr;
  assign ev_c_coh    = ev_ch;

  // ------------------------------------------------------------------ context state machines
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      cx_st     <= '0;
      cx_cl     <= '0;
      cx_slot   <= '0;
      cx_tag    <= '0;
      cx_op     <= '0;
      cx_wide   <= '0;
      cx_addr   <= '0;
      cx_opd    <= '0;
      cx_cmp    <= '0;
      cx_old    <= '0;
      cx_new    <= '0;
      cx_succ   <= '0;
      cx_lkheld <= '0;
      cx_coh    <= '0;
      cx_wrote  <= '0;
      cx_sent   <= '0;
      cx_stat   <= '0;
    end else begin
      // ---- grant: load the context, take the lock (the lock table writes its entry at the same edge)
      if (gnt_valid) begin
        for (int i = 0; i < NCTX; i++) begin
          if (free_idx == CXW'(i)) begin
            cx_st    [i*3 +: 3]     <= g_is_coh ? CX_COH : CX_RD;
            cx_cl    [i*CLW +: CLW] <= gnt_client;
            cx_slot  [i*PQW +: PQW] <= gnt_slot;
            cx_tag   [i*TAGW +: TAGW] <= gnt_tag;
            cx_op    [i*4 +: 4]     <= g_op;
            cx_wide  [i]            <= (g_wd == 2'd1);
            cx_addr  [i*AW +: AW]   <= g_addr;
            cx_opd   [i*64 +: 64]   <= g_opd;
            cx_cmp   [i*64 +: 64]   <= gnt_cmp;
            cx_old   [i*64 +: 64]   <= 64'd0;
            cx_new   [i*64 +: 64]   <= 64'd0;
            cx_succ  [i]            <= 1'b0;
            cx_lkheld[i]            <= 1'b1;
            cx_coh   [i]            <= g_is_coh;
            cx_wrote [i]            <= 1'b0;
            cx_sent  [i]            <= 1'b0;
            cx_stat  [i*4 +: 4]     <= AST_OK;
          end
        end
      end

      for (int i = 0; i < NCTX; i++) begin
        case (cx_st[i*3 +: 3])
          CX_RD: begin
            if (a_req_ready[i]) cx_st[i*3 +: 3] <= CX_RW;
          end
          CX_RW: begin
            if (a_rsp_valid[i]) begin
              if (a_rsp_err) begin
                cx_stat[i*4 +: 4] <= AST_READ;
                cx_old [i*64 +: 64] <= 64'd0;
                cx_succ[i]        <= 1'b0;
                cx_st  [i*3 +: 3] <= CX_FIN;
              end else begin
                cx_old [i*64 +: 64] <= alu_old;
                cx_new [i*64 +: 64] <= alu_new;
                cx_succ[i]        <= alu_succ;
                cx_st  [i*3 +: 3] <= alu_wr ? CX_WR : CX_FIN;
              end
            end
          end
          CX_WR: begin
            if (a_req_ready[i]) begin
              cx_wrote[i]       <= 1'b1;
              cx_st  [i*3 +: 3] <= CX_WW;
            end
          end
          CX_WW: begin
            if (a_rsp_valid[i]) begin
              if (a_rsp_err) begin
                cx_stat[i*4 +: 4] <= AST_WRITE;
                cx_succ[i]        <= 1'b0;
              end
              cx_st[i*3 +: 3] <= CX_FIN;
            end
          end
          CX_COH: begin
            if (ca_op_valid && ca_op_ready && (ca_owner == CXW'(i))) cx_sent[i] <= 1'b1;
            if (ca_res_valid && (ca_owner == CXW'(i))) begin
              cx_old [i*64 +: 64] <= ca_res_err ? 64'd0 : ca_res_old;
              cx_new [i*64 +: 64] <= ca_res_new;
              cx_succ[i]          <= ca_res_succ && !ca_res_err;
              cx_stat[i*4 +: 4]   <= ca_res_err ? AST_COH : AST_OK;
              cx_st  [i*3 +: 3]   <= CX_FIN;
            end
          end
          CX_FIN: begin
            if (fin_any && (fin_idx == CXW'(i))) begin
              cx_st    [i*3 +: 3] <= CX_IDLE;
              cx_lkheld[i]        <= 1'b0;
            end
          end
          default: ;
        endcase
      end
    end
  end

  // ------------------------------------------------------------------ status
  reg ctx_all_idle;
  always_comb begin
    ctx_all_idle = 1'b1;
    for (int i = 0; i < NCTX; i++) if (cx_st[i*3 +: 3] != CX_IDLE) ctx_all_idle = 1'b0;
  end
  assign idle_o = q_empty && ctx_all_idle && ord_idle;

  // ------------------------------------------------------------------ diagnostics: latest rejected command
  reg              dg_v;
  reg [CLW-1:0]    dg_c;
  reg [3:0]        dg_s;
  reg [AW-1:0]     dg_a;
  always_ff @(posedge clk) begin
    if (!rst_n || diag_clr_i) begin
      dg_v <= 1'b0; dg_c <= '0; dg_s <= 4'd0; dg_a <= '0;
    end else begin
      for (int c = 0; c < NC; c++) begin
        if (ev_in[c] && (pre_err[c*4 +: 4] != AST_OK)) begin
          dg_v <= 1'b1; dg_c <= CLW'(c); dg_s <= pre_err[c*4 +: 4]; dg_a <= cmd_addr[c*AW +: AW];
        end
      end
    end
  end
  assign diag_valid_o  = dg_v;
  assign diag_client_o = dg_c;
  assign diag_status_o = dg_s;
  assign diag_addr_o   = dg_a;

  // ------------------------------------------------------------------ performance
  generate
    if (PERF != 0) begin : g_perf
      reg [3:0] n_mem_stall, n_cmd_stall, n_ctx_busy, n_commit, n_casf, n_merr;
      reg [NC-1:0] ev_rej, hd_lock_blk;
      reg [3:0] n_locks_w;
      always_comb begin
        n_locks_w = 4'(lk_cnt_w);
        n_mem_stall = 4'd0; n_cmd_stall = 4'd0; n_ctx_busy = 4'd0; n_commit = 4'd0; n_casf = 4'd0; n_merr = 4'd0;
        for (int i = 0; i < NCTX; i++) begin
          if (a_req_valid[i] && !a_req_ready[i]) n_mem_stall = n_mem_stall + 4'd1;
          if (cx_st[i*3 +: 3] != CX_IDLE)        n_ctx_busy  = n_ctx_busy + 4'd1;
          if (ev_v[i])                           n_commit    = n_commit + 4'd1;
          if (casfail_v[i])                      n_casf      = n_casf + 4'd1;
          if (memerr_v[i])                       n_merr      = n_merr + 4'd1;
        end
        for (int c = 0; c < NC; c++) begin
          if (cmd_valid[c] && !q_in_ready[c]) n_cmd_stall = n_cmd_stall + 4'd1;
          ev_rej[c]      = ev_in[c] && (pre_err[c*4 +: 4] != AST_OK);
          hd_lock_blk[c] = hd_valid[c] && (h_lock[c] || h_hold[c]);
        end
      end
      sf_atomic_perf #(.NC(NC), .QD(QD)) u_perf (
        .clk(clk), .rst_n(rst_n), .perf_clr_i(perf_clr_i),
        .ev_in(ev_in), .ev_in_slot(ev_in_slot), .ev_rej(ev_rej),
        .ev_gnt(gnt_valid), .ev_gnt_client(gnt_client), .ev_gnt_slot(gnt_slot), .hd_lock_blk(hd_lock_blk),
        .ev_dlv(ev_dlv), .ev_dlv_slot(ev_dlv_slot),
        .n_commit(n_commit), .n_cas_fail(n_casf), .n_memerr(n_merr),
        .ev_atm_rd(ev_acc_atomic && !m_req_we), .ev_atm_wr(ev_acc_atomic && m_req_we),
        .ev_ord_rd(ev_ord_rd), .ev_ord_wr(ev_ord_wr), .ev_ord_err(ev_ord_err), .ev_ord_blk(ev_ord_blk),
        .ev_coh_op(ca_commit), .ev_resv(resv_set && !resv_v),
        .n_mem_stall(n_mem_stall), .n_cmd_stall(n_cmd_stall), .n_ctx_busy(n_ctx_busy), .n_locks(n_locks_w), .perf_o(perf_o)
      );
    end else begin : g_noperf
      assign perf_o = '0;
      wire _unused_perf = &{1'b0, perf_clr_i, ev_dlv, ev_in_slot, ev_dlv_slot, lk_cnt_w, ev_acc_atomic, ev_ord_rd, ev_ord_wr, ev_ord_err, ev_ord_blk, resv_set, resv_v, memerr_v, casfail_v};
    end
  endgenerate

  wire _unused = &{1'b0, ev_dlv_err, q_full, alu_opok, cx_wrote, m_rsp_we, hd_aq, gnt_rid, c_coh_in};
  // ------------------------------------------------------------------ formal / simulation properties (formal/fv_engine_props.svh)
`ifdef SF_ATOMIC_PROPS
`include "fv_engine_props.svh"
`endif
endmodule

`default_nettype wire
