# Provenance of the vendored CoherenceDirectory files (Project 107)

Source: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-coherencedirectory-p107.zip` of this repository (btcphilosopher/Aureom.AI),
`rtl/coherence/*.sv` and `tb/sf_coh_mem_model.sv`.  **Copied byte for byte, not modified** (`SHA256SUMS`; byte-compared with the archive when
this package was built).  Used only by the coherence system testbench `tb/tb_sf_atomic_coh.sv` (they are NOT part of the engine's RTL; the
engine speaks the protocol with its own `rtl/sf_atomic_coh_agent.sv`).  The package, the directory, the sharer-vector and transient-FSM
modules and the CPU-side agent adapter are the real implementation; `sf_coh_mem_model.sv` is P107's verification-only shared-memory model.
