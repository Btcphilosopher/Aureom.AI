#!/usr/bin/env python3
"""Regression driver: configurations x tests x seeds, Verilator.  Writes reports/regression.md and reports/regression.json.

usage: scripts/regress.py [--quick] [--configs a,b] [--tests t1,t2] [--seeds N] [--jobs J]
"""
import argparse, concurrent.futures as cf, json, os, re, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

P = lambda **kw: [f"-G{k}={v}" for k, v in kw.items()]
# name -> (parameters, description)
CONFIGS = {
    # phase 1 of the project: ONE context, only FETCH-ADD and CAS, 32-bit only
    "phase1":  (P(NCTX=1, OP_EN="16'h0404", W64_EN=0),                         "phase 1: 1 context, FADD+CAS, 32-bit"),
    # phase 2: 64-bit and every opcode, still ONE lock
    "phase2":  (P(NCTX=1),                                                     "phase 2: 1 context, all opcodes, 32/64-bit"),
    # phase 3: parallel address locks
    "default": (P(),                                                           "NC=4 QD=4 NCTX=2"),
    "ctx4":    (P(NCTX=4),                                                     "NC=4 QD=4 NCTX=4 (4 parallel locks)"),
    "nc3":     (P(NC=3, NCTX=3, QD=2),                                         "NC=3 (not a power of two) QD=2 NCTX=3"),
    "nc2":     (P(NC=2, NCTX=1, QD=8),                                         "NC=2 QD=8 NCTX=1"),
    "line":    (P(NCTX=4, LOCK_GRAN=6),                                        "64-byte lock granule, 4 contexts"),
    "lat3":    (P(NCTX=3, MEM_LAT=3, OMAX=8),                                  "memory latency 3, OMAX 8"),
}
TESTS_ALL = ["smoke", "single", "cas", "ticket", "overflow", "minmax", "w64", "random", "contend", "perm", "errors",
             "queue", "order", "quiesce", "fair", "reset", "naive", "starve", "orderx"]
SEEDED = {"random", "contend", "reset", "w64", "randomx", "order", "starve", "orderx"}

def build(name):
    params, _ = CONFIGS[name]
    obj = f"build/obj_{name}"
    exe = f"{obj}/tb_{name}"
    cmd = (["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH", "-Wno-UNOPTFLAT",
            "-Wno-TIMESCALEMOD", "-Wno-IGNOREDRETURN", "--assert", "-DSF_ATOMIC_PROPS", "-Iformal", "--top-module", "tb_sf_atomic_engine", "-Mdir", obj] + params +
           ["-f", "rtl/files.f", "tb/sf_atomic_mem_model.sv", "tb/tb_sf_atomic_engine.sv", "-o", f"tb_{name}"])
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        return name, False, r.stdout[-2000:] + r.stderr[-2000:]
    return name, True, ""

def run(name, test, seed):
    exe = f"build/obj_{name}/tb_{name}"
    t0 = time.time()
    r = subprocess.run([exe, f"+test={test}", f"+seed={seed}"], capture_output=True, text=True, timeout=1800)
    out = r.stdout + r.stderr
    m = re.search(r"RESULT: (PASS|FAIL).*?checks=(\d+)", out)
    ok = bool(m and m.group(1) == "PASS")
    checks = int(m.group(2)) if m else 0
    errs = [l for l in out.splitlines() if "ERROR" in l][:4]
    return dict(config=name, test=test, seed=seed, ok=ok, checks=checks, secs=round(time.time() - t0, 1), errors=errs,
                tail="\n".join(out.splitlines()[-3:]))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--configs", default="")
    ap.add_argument("--tests", default="")
    ap.add_argument("--seeds", type=int, default=0)
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    a = ap.parse_args()
    cfgs = a.configs.split(",") if a.configs else list(CONFIGS)
    tests = a.tests.split(",") if a.tests else TESTS_ALL
    nseeds = a.seeds or (2 if a.quick else 6)
    os.makedirs("build", exist_ok=True); os.makedirs("reports", exist_ok=True)

    print(f"building {len(cfgs)} configurations ...", flush=True)
    with cf.ThreadPoolExecutor(max_workers=max(1, a.jobs // 2)) as ex:
        for name, ok, log in ex.map(build, cfgs):
            print(f"  build {name}: {'ok' if ok else 'FAILED'}", flush=True)
            if not ok:
                print(log); sys.exit(2)

    jobs = []
    for c in cfgs:
        for t in tests:
            for s in (range(1, nseeds + 1) if t in SEEDED else [1]):
                jobs.append((c, t, s))
    print(f"running {len(jobs)} simulations on {a.jobs} workers ...", flush=True)
    results = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = {ex.submit(run, *j): j for j in jobs}
        for f in cf.as_completed(futs):
            r = f.result(); results.append(r)
            if not r["ok"]:
                print(f"  FAIL {r['config']}/{r['test']}/seed{r['seed']}: {r['errors']}", flush=True)
    results.sort(key=lambda r: (r["config"], r["test"], r["seed"]))
    npass = sum(r["ok"] for r in results); checks = sum(r["checks"] for r in results)
    with open("reports/regression.json", "w") as f: json.dump(results, f, indent=1)
    with open("reports/regression.md", "w") as f:
        f.write("# Regression (Verilator 5.020, `scripts/regress.py`)\n\n")
        f.write(f"**{npass} / {len(results)} simulations pass; {checks:,} self-checks executed.**\n\n")
        f.write("| configuration | parameters | tests run | pass | self-checks |\n|---|---|---|---|---|\n")
        for c in cfgs:
            rs = [r for r in results if r["config"] == c]
            f.write(f"| `{c}` | {CONFIGS[c][1]} (`{' '.join(CONFIGS[c][0]) or 'defaults'}`) | {len(rs)} | {sum(r['ok'] for r in rs)} | {sum(r['checks'] for r in rs):,} |\n")
        f.write("\n| configuration | test | seeds | result | self-checks |\n|---|---|---|---|---|\n")
        for c in cfgs:
            for t in tests:
                rs = [r for r in results if r["config"] == c and r["test"] == t]
                if rs:
                    f.write(f"| `{c}` | `{t}` | {len(rs)} | {'PASS' if all(r['ok'] for r in rs) else '**FAIL**'} | {sum(r['checks'] for r in rs):,} |\n")
        bad = [r for r in results if not r["ok"]]
        if bad:
            f.write("\n## Failures\n\n")
            for r in bad:
                f.write(f"* `{r['config']}` / `{r['test']}` / seed {r['seed']}: {r['errors']}\n")
    print(f"{npass}/{len(results)} pass, {checks:,} checks -> reports/regression.md")
    sys.exit(0 if npass == len(results) else 1)

main()
