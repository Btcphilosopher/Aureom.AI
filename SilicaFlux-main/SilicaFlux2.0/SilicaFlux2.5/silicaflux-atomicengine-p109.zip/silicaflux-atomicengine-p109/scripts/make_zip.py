#!/usr/bin/env python3
"""Packages the project into silicaflux-atomicengine-p109.zip (root folder silicaflux-atomicengine-p109/) with MANIFEST.sha256.
Excludes build/, caches and any previous archive.  Nothing is committed to git: this only reads the working tree and writes the archive."""
import hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
NAME = "silicaflux-atomicengine-p109"
SKIP_DIRS = {"build", "__pycache__", ".git"}
files = []
for d, ds, fs in os.walk("."):
    ds[:] = sorted(x for x in ds if x not in SKIP_DIRS)
    for f in sorted(fs):
        p = os.path.join(d, f)[2:]
        if p.endswith(".zip") or f == "MANIFEST.sha256" or f.endswith(".pyc"): continue
        files.append(p)
man = "".join(f"{hashlib.sha256(open(p, 'rb').read()).hexdigest()}  {p}\n" for p in files)
open("MANIFEST.sha256", "w").write(man)
out = f"{NAME}.zip"
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files + ["MANIFEST.sha256"]:
        z.write(p, f"{NAME}/{p}")
print(f"{out}: {len(files) + 1} files, {os.path.getsize(out)/1024:.0f} KiB")
