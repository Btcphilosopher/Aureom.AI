#!/usr/bin/env python3
"""Technology-independent Yosys synthesis statistics (NO library, NO timing, NO power: structure counts only).

For each configuration and each module: `synth -flatten` + `abc -g` generic gates; reports cells, flip-flops, an estimated NAND2-equivalent
count (weights below, an ESTIMATE) and the longest topological path in gates (`ltp`, an unweighted depth, NOT a timing number).
Writes reports/synthesis.md and reports/synthesis.json.
"""
import json, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
FILES = [l.strip() for l in open("rtl/files.f") if l.strip()]
W = {"$_AND_": 1.0, "$_NAND_": 1.0, "$_OR_": 1.0, "$_NOR_": 1.0, "$_XOR_": 2.5, "$_XNOR_": 2.5, "$_ANDNOT_": 1.0, "$_ORNOT_": 1.0,
     "$_NOT_": 0.5, "$_MUX_": 2.5, "$_AOI3_": 1.5, "$_OAI3_": 1.5, "$_AOI4_": 2.0, "$_OAI4_": 2.0}
CFG = {
    "phase1  (NCTX=1, FADD+CAS, 32-bit)":      dict(top="sf_atomic_engine", par="-set NCTX 1 -set OP_EN 16'h0404 -set W64_EN 0"),
    "phase2  (NCTX=1, all ops, 64-bit)":       dict(top="sf_atomic_engine", par="-set NCTX 1"),
    "default (NC=4 QD=4 NCTX=2)":              dict(top="sf_atomic_engine", par=""),
    "ctx4    (NCTX=4)":                        dict(top="sf_atomic_engine", par="-set NCTX 4"),
    "ctx4+coh (NCTX=4, COHERENT=1, 16 lines)": dict(top="sf_atomic_engine", par="-set NCTX 4 -set COHERENT 1"),
    "ctx4 PERF=0":                             dict(top="sf_atomic_engine", par="-set NCTX 4 -set PERF 0"),
}
MODS = {"sf_atomic_alu": "", "sf_atomic_lock_table": "-set N 4 -set KEYW 29 -set NH 4", "sf_atomic_queue": "-set NC 4 -set QD 4 -set PW 102",
        "sf_atomic_ordering": "-set NCTX 4 -set AW 32 -set GRAN 3 -set OMAX 4", "sf_atomic_perf": "-set NC 4 -set QD 4",
        "sf_atomic_coh_agent": ""}

def run(top, par, tag):
    script = f"read_verilog -sv -defer {' '.join(FILES)}; "
    if par: script += f"chparam {par} {top}; "
    script += (f"hierarchy -check -top {top}; synth -flatten -top {top}; abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX; opt_clean; "
               f"tee -o build/stat_{tag}.txt stat; ltp -noff")
    r = subprocess.run(["yosys", "-p", script], capture_output=True, text=True)
    out = r.stdout + r.stderr
    if r.returncode != 0: return dict(error=out[-600:])
    stat = open(f"build/stat_{tag}.txt").read()
    cells = {m.group(1): int(m.group(2)) for m in re.finditer(r"^\s+(\$_\w+_)\s+(\d+)\s*$", stat, re.M)}
    tot = sum(cells.values()); ffs = sum(v for k, v in cells.items() if "DFF" in k or "SDFF" in k)
    comb = tot - ffs; nand2 = sum(W.get(k, 1.0) * v for k, v in cells.items() if "DFF" not in k)
    m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", out)
    return dict(cells=tot, ffs=ffs, comb=comb, nand2eq=round(nand2), depth=int(m.group(1)) if m else None, hist=cells)

only = sys.argv[1:]                      # optional name filters: only (re)run entries whose name contains one of them; results are merged into the json
res = {"configs": {}, "modules": {}}
if only and os.path.exists("reports/synthesis.json"): res = json.load(open("reports/synthesis.json"))
os.makedirs("build", exist_ok=True)
for i, (name, c) in enumerate(CFG.items()):
    if only and not any(o in name for o in only): continue
    print("synth", name, flush=True)
    r = run(c["top"], c["par"], f"cfg{i}")
    if "error" in r: r = run(c["top"], c["par"], f"cfg{i}")      # one retry (a transient tool failure under memory pressure was seen once)
    res["configs"][name] = r
for i, (m, p) in enumerate(MODS.items()):
    if only and not any(o in m for o in only): continue
    print("synth", m, flush=True); res["modules"][m] = run(m, p, f"mod{i}")
json.dump(res, open("reports/synthesis.json", "w"), indent=1)
with open("reports/synthesis.md", "w") as f:
    f.write("# Synthesis statistics (Yosys 0.33, generic gates)\n\n> **No library, no timing, no power, no placement.** The counts are structure counts "
            "after `synth -flatten` and `abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX`. `NAND2-eq` is an **estimate** (AND/OR-type = 1, XOR/XNOR = 2.5, "
            "MUX = 2.5, NOT = 0.5; flops not included). `depth` is the unweighted longest topological path in gates (`ltp -noff`), not a delay.\n\n")
    f.write("## Whole engine\n\n| configuration | cells | flip-flops | combinational | NAND2-eq (est.) | depth (gates) |\n|---|---|---|---|---|---|\n")
    for n, r in res["configs"].items():
        f.write(f"| {n} | " + (f"{r['cells']:,} | {r['ffs']:,} | {r['comb']:,} | {r['nand2eq']:,} | {r['depth']} |\n" if "cells" in r else f"ERROR {r['error'][:80]} |||||\n"))
    f.write("\n## Modules (stand-alone, representative parameters)\n\n| module | cells | flip-flops | combinational | NAND2-eq (est.) | depth (gates) |\n|---|---|---|---|---|---|\n")
    for n, r in res["modules"].items():
        f.write(f"| `{n}` | " + (f"{r['cells']:,} | {r['ffs']:,} | {r['comb']:,} | {r['nand2eq']:,} | {r['depth']} |\n" if "cells" in r else f"ERROR {r['error'][:80]} |||||\n"))
print("wrote reports/synthesis.md")
