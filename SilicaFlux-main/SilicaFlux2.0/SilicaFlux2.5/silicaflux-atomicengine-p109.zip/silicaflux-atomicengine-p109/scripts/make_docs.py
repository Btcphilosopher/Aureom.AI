#!/usr/bin/env python3
"""Fills the generated sections of docs/VERIFICATION.md from the files in reports/ (so that every number in the document is copied, not typed).
Idempotent: the sections are delimited by <!-- BEGIN name --> / <!-- END name --> markers (created on first run from the @@NAME@@ placeholders)."""
import json, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
P = "docs/VERIFICATION.md"
doc = open(P).read()
for n in ("REGRESSION", "MUTATION", "COHERENCE", "BENCH", "FORMAL"):
    doc = doc.replace(f"@@{n}@@", f"<!-- BEGIN {n} -->\n<!-- END {n} -->")
def put(name, text):
    global doc
    doc = re.sub(rf"<!-- BEGIN {name} -->.*?<!-- END {name} -->", lambda m: f"<!-- BEGIN {name} -->\n{text.strip()}\n<!-- END {name} -->", doc, flags=re.S)

# ---------------------------------------------------------------- regression
rg = json.load(open("reports/regression.json"))
npass = sum(r["ok"] for r in rg); chk = sum(r["checks"] for r in rg)
cfgs = {}
for r in rg: cfgs.setdefault(r["config"], []).append(r)
desc = {"phase1": "phase 1: 1 context, FADD + CAS only, 32-bit", "phase2": "phase 2: 1 context, all opcodes, 32/64-bit", "default": "NC=4 QD=4 NCTX=2",
        "ctx4": "NC=4 QD=4 NCTX=4 (4 parallel locks)", "nc3": "NC=3 (not a power of two) QD=2 NCTX=3", "nc2": "NC=2 QD=8 NCTX=1", "line": "64-byte lock granule, NCTX=4",
        "lat3": "memory latency 3, OMAX=8, NCTX=3"}
t = (f"`scripts/regress.py --seeds 3`: **{npass} / {len(rg)} simulations pass, {chk:,} self-checks**, Verilator 5.020, with the in-RTL assertions enabled (`--assert -DSF_ATOMIC_PROPS`). "
     "Seeded tests (`random`, `contend`, `reset`, `w64`, `order`, `starve`, `orderx`) run with 3 seeds, the others once. Full per-test table: `reports/regression.md`.\n\n"
     "| configuration | what it covers | simulations | pass | self-checks |\n|---|---|---|---|---|\n")
for c, rs in cfgs.items(): t += f"| `{c}` | {desc.get(c, '')} | {len(rs)} | {sum(r['ok'] for r in rs)} | {sum(r['checks'] for r in rs):,} |\n"
t += ("\nThe **phase 1** configuration (`NCTX = 1`, only FETCH-ADD and CAS enabled, 32-bit only) runs the same test list as every other configuration; tests that need a disabled opcode "
      "(`minmax`, `order`) report themselves skipped there, and every disabled opcode is rejected `AST_OP` (checked by the prediction).\n\n"
      "Also: `scripts/alu_check.sh` replays 34 896 Python-generated vectors against the ALU (output: `RESULT: PASS  alu vectors=34896 checks=139584`); the same bench **fails** (2 260 mismatches) on an ALU with a planted signed-compare defect.")
put("REGRESSION", t)

# ---------------------------------------------------------------- mutation
mu = json.load(open("reports/mutation.json")); mc = json.load(open("reports/mutation_coh.json"))
def tally(rs, eq):
    for r in rs:
        if r["id"] in eq and r["status"] != "KILLED": r["status"] = "EQUIVALENT"
    return sum(r["status"] == "KILLED" for r in rs), sum(r["status"] == "EQUIVALENT" for r in rs), len(rs)
k1, e1, n1 = tally(mu, {"O05"}); k2, e2, n2 = tally(mc, {"C08"})
by = {}
for r in mu: by.setdefault(r["file"], []).append(r)
t = (f"`scripts/mutate.py` plants one RTL defect at a time and runs the test list on the 4-context configuration until a test fails: **{k1} / {n1 - e1} non-equivalent mutants killed** "
     f"({e1} provably equivalent control mutant, O05: it replaces the constant `m_rsp_ready = 1` by an expression that is always 1 because response space is reserved at acceptance). "
     "The defects span the ALU, the lock table, the ordering unit, the engine and the queue:\n\n| file | mutants | killed |\n|---|---|---|\n")
for f, rs in by.items():
    eq = sum(r['status'] == 'EQUIVALENT' for r in rs)
    t += f"| `{f}` | {len(rs)} | {sum(r['status'] == 'KILLED' for r in rs)}" + (f" (+ {eq} equivalent control)" if eq else "") + " |\n"
t += (f"\n`scripts/mutate.py --coh` does the same for the coherence path against the real P107 directory: **{k2} / {n2 - e2} non-equivalent mutants killed** "
      f"({e2} defensive-check mutant — removing the `gn_line == p_line` check of a grant — is unreachable with a correct directory). Full tables: `reports/mutation.md`, `reports/mutation_coh.md`.\n\n"
      "The first campaign had 5 survivors; four exposed holes in the stimulus (unused upper operand bits, ordering bits under arbitration inversions, fairness / liveness) and were closed by new "
      "tests (§7); the fifth is the equivalent control. The mutation score measures the testbench's sensitivity to the defects planted, not the absence of other defects.")
put("MUTATION", t)

# ---------------------------------------------------------------- coherence
cm = open("reports/coherence.md").read()
m = re.search(r"\*\*(\d+) / (\d+) runs pass; ([\d,]+) self-checks; ([\d,]+) coherent atomic operations and ([\d,]+) CPU cache operations checked\.\*\*", cm)
t = (f"`scripts/coh_regress.py` (`tb/tb_sf_atomic_coh.sv`): the engine with `COHERENT = 1` as agent 2 next to P107's own two CPU cache adapters and the **real** P107 directory, behind P107's memory model. "
     f"**{m.group(1)} / {m.group(2)} runs pass; {m.group(3)} self-checks; {m.group(4)} coherent atomic operations and {m.group(5)} CPU cache operations checked against the golden cache-line image.** Tests:\n\n"
     "* `coh_directed` — a line held **Modified** in a CPU cache is updated by the engine (the engine observes the CPU's value through the directory's intervention, the CPU's copy is invalidated and reads the new value); "
     "two sharers invalidated by an engine CAS; CPU AMO ↔ engine fetch-add ownership chains; 64-bit operations inside a line; the uncached window next to the coherent one.\n"
     "* `coh_random`, `coh_stress` — random 32/64-bit operations of all ten opcodes from two clients, concurrently with random LOAD / STORE / AMO / FLUSH traffic of both CPU caches on the same few lines, memory back-pressure and latency, 5 seeds.\n"
     "* `coh_naive` — **negative control**: an update that bypasses coherence (memory written behind the directory's back) leaves a stale copy in a CPU cache and the golden-line checker flags it; "
     "the same update through the engine's coherent path is seen by the CPU.\n\n"
     "After every test each agent FLUSHes every line and the shared memory must equal the golden image; the directory's and the agents' protocol-error flags must be clear; the engine's coherent path must report no error. "
     "Two geometries (2 and 4 contexts, memory ready 100 % / 60 %). Per-run table: `reports/coherence.md`.")
put("COHERENCE", t)

# ---------------------------------------------------------------- bench
bn = open("reports/bench.md").read().split("\n")
rows = [l for l in bn if l.startswith("|")]
t = ("Throughput, latency and contention (`scripts/bench.py`, RTL-simulation cycles, ideal memory, 32-bit FETCH-ADD, 100 operations per client back to back; `reports/bench.md` has every column):\n\n" + "\n".join(rows[:2]) + "\n" +
     "\n".join(l for l in rows[2:] if re.match(r"\| (same-word|own-word|random-32) \| 4 \| (1|2|4|8) \| 1 \|", l)) + "\n\n"
     "* **One hot word**: 0.166 operations per cycle for every `NCTX` — one lock hold is 6 cycles at memory latency 1 (10 cycles at latency 3: 0.099); extra contexts cannot help a serialised counter.\n"
     "* **Independent words**: throughput scales with the number of locks held in parallel (0.166 → 0.332 → 0.496 for 1, 2, 4 contexts) and saturates at the hard ceiling of **0.5** (one memory port, two requests per writing atomic).\n"
     "* **Fairness**: with every client saturating one word the completed-operation counts of any two clients never differ by more than 1 (bound checked by `+test=fair`: `QD + NCTX + 2`); the round-robin rule itself is proved (§8).\n"
     "* **Reading the contention columns**: in `own-word` every client uses a different word, but a client's next command still waits for its own previous operation on that word (in-order start), so \"contended\" counts self-contention there; `ingress stall cycles` are cycles in which a client was held back by its full bounded queue (the clients here offer far more work than the engine can start).\n"
     "* **No starvation either way** (`+test=starve`, default configuration, seed 1): under a saturating atomic stream an ordinary writer to the same word got 162 writes through with a longest wait of 6 cycles; under a saturating ordinary writer 25 atomics completed in 178 cycles.\n"
     "* Counters: queue wait, lock-acquisition time, operation latency, contention, operations/cycle, stall cycles — all exposed by `sf_atomic_perf` and printed by the bench.")
put("BENCH", t)

# ---------------------------------------------------------------- formal
fm = json.load(open("reports/formal.json"))
t = ("`formal/run_formal.py` (Yosys 0.33 internal SAT engine; SymbiYosys is not installed here and z3-based `yosys-smtbmc` stalled on the queue's wide variable shifts; ABC PDR could not be driven). "
     "Properties are in `formal/*.svh`; **their headers define every property and every environment assumption**. Instances are small (parameters in the runner).\n\n"
     "| harness | verdict | what was run | result |\n|---|---|---|---|\n")
for n, r in fm.items():
    for x in r["jobs"]:
        verdict = r["kind"] if x["mode"] in ("induction", "all-input proof") else ("BOUNDED" if x["mode"] == "bmc" else "—")
        t += f"| {n} | {verdict} | {x['mode']}{(' ' + str(x['depth'])) if x.get('depth') not in ('', None) else ''} | {'PASS' if x['ok'] else '**no result / FAIL**'} — {x['tail']} ({x['secs']} s) |\n"
t += ("\n**Reading the table.** *UNBOUNDED* rows are closed by temporal induction (valid for every depth under the stated environment); *BOUNDED* rows say only that no execution of that length from reset violates a property. "
      "Engine-level exclusivity (X1 … X5) is **bounded**; the lock-table uniqueness (L1), the queue's structural properties and round-robin rule (Q1, Q2, Q3, Q5, Q7, Q8, Q10) and the ALU are unbounded. "
      "In the whole-engine run the sub-modules' own environment assumptions are *not* active — every sub-module property is an assertion in situ (this was a soundness fix, §7 item 7). "
      "The unbounded lock-table proof assumes the engine's acquire discipline (EN1 – EN3 in `formal/fv_lock_table_props.svh`); at engine level that discipline is checked only to depth 10 (the in-situ assertion of L1) and by the simulation assertions, not proved for all depths. "
      "The one induction row marked *no result* (ordering) means the induction step did not close without further strengthening invariants; the same properties hold for every execution of 16 cycles (BMC). "
      "The depth-14 whole-engine run timed out; it is listed so that nothing is hidden. Non-vacuity: every cover point of the environment (an ordinary write reaching memory, an ordinary write held by a lock, an atomic write, a linearisation point with and without a write, a delivered completion, hold-off while locked, a registered reservation) is reachable, so the assumptions do not rule out the interesting behaviour.")
put("FORMAL", t)
open(P, "w").write(doc)
print("docs/VERIFICATION.md updated")
