#!/usr/bin/env python3
"""Throughput / latency / contention benchmark: builds a few configurations and runs `+test=bench` (tb_sf_atomic_engine).
Every operation is a 32-bit FETCH-ADD; clients issue back to back; the memory model is ideal (ready 100 %, fixed latency).
Writes reports/bench.md.  All numbers are RTL-simulation cycle counts, not silicon."""
import concurrent.futures as cf, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
CFGS = {"nctx1": ["-GNCTX=1"], "nctx2": ["-GNCTX=2"], "nctx4": ["-GNCTX=4"], "nctx8": ["-GNCTX=8"], "nctx4_lat3": ["-GNCTX=4", "-GMEM_LAT=3"], "nctx4_nc8": ["-GNCTX=4", "-GNC=8", "-GQD=2"]}
def build(n):
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH", "-Wno-UNOPTFLAT", "-Wno-TIMESCALEMOD", "-Wno-IGNOREDRETURN",
           "--top-module", "tb_sf_atomic_engine", "-Mdir", f"build/obj_bench_{n}"] + CFGS[n] + ["-f", "rtl/files.f", "tb/sf_atomic_mem_model.sv", "tb/tb_sf_atomic_engine.sv", "-o", f"tb_{n}"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return n, r.returncode == 0
def run(n):
    out = subprocess.run([f"build/obj_bench_{n}/tb_{n}", "+test=bench", "+seed=1"], capture_output=True, text=True).stdout
    return n, [dict(re.findall(r"(\w+)=(\S+)", l)) for l in out.splitlines() if l.startswith("BENCH")], "RESULT: PASS" in out
if __name__ == "__main__":
    os.makedirs("build", exist_ok=True)
    with cf.ThreadPoolExecutor(max_workers=3) as ex: 
        for n, ok in ex.map(build, CFGS): print("build", n, ok, flush=True)
    rows = []
    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        for n, rs, ok in ex.map(run, CFGS): rows += rs; print("run", n, ok, flush=True)
    with open("reports/bench.md", "w") as f:
        f.write("# Benchmark (RTL simulation cycles; ideal memory; 32-bit FETCH-ADD, 100 operations per client, back to back)\n\n"
                "`ops/cycle` = committed operations / cycles from the first command to the last completion. Latencies are accept -> completion delivered, in cycles. "
                "`lock wait` = cycles the queue head was blocked by a lock before it was granted; `contended` = operations that waited at least one cycle for a lock. "
                "Hard ceiling: one memory master port, two requests per writing atomic => 0.5 operations per cycle.\n\n"
                "| workload | NC | NCTX | mem latency | lock granule | ops | cycles | **ops / cycle** | avg latency | max latency | avg queue wait | max queue wait | avg lock wait | max lock wait | contended ops | ingress stall cycles | ctx utilisation |\n"
                "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
        for r in rows:
            f.write(f"| {r['mode']} | {r['NC']} | {r['NCTX']} | {r['MEM_LAT']} | {2**int(r['GRAN'])} B | {r['ops']} | {r['cycles']} | **{int(r['opc_x1000'])/1000:.3f}** | "
                    f"{int(r['lat_avg_x10'])/10:.1f} | {r['lat_max']} | {int(r['qwait_avg_x10'])/10:.1f} | {r['qwait_max']} | {int(r['lockwait_avg_x10'])/10:.1f} | {r['lockwait_max']} | {r['contended']} | {r['cmd_stall']} | {r['ctx_util_pct']} % |\n")
    print("wrote reports/bench.md")
