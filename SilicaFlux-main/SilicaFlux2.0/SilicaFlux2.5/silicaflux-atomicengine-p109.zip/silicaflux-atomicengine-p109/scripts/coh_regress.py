#!/usr/bin/env python3
"""Coherence system regression: tb_sf_atomic_coh.sv (real P107 directory + 2 CPU cache agents + the engine) x tests x seeds, for two geometries.
Writes reports/coherence.md."""
import concurrent.futures as cf, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
C = "third_party/coherence_p107"
GEOM = {"nctx2": [], "nctx4_nc2_memready60": ["-GNCTX=4", "-GMEMREADY=60"]}
TESTS = [("coh_directed", [1]), ("coh_naive", [1]), ("coh_random", [1, 2, 3, 4, 5]), ("coh_stress", [1, 2, 3, 4, 5])]
def build(g):
    obj = f"build/obj_cohr_{g}"
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH", "-Wno-UNOPTFLAT", "-Wno-TIMESCALEMOD", "-Wno-IGNOREDRETURN", "-Wno-PINMISSING",
           "--assert", "-DSF_ATOMIC_PROPS", "-Iformal", "--top-module", "tb_sf_atomic_coh", "-Mdir", obj] + GEOM[g] + \
          [f"{C}/sf_coherence_pkg.sv", f"{C}/sf_coherence_sharers.sv", f"{C}/sf_coherence_transient_fsm.sv", f"{C}/sf_coherence_directory.sv",
           f"{C}/sf_coherence_agent_adapter.sv", f"{C}/sf_coh_mem_model.sv", "-f", "rtl/files.f", "tb/sf_atomic_mem_model.sv", "tb/tb_sf_atomic_coh.sv", "-o", "tb"]
    r = subprocess.run(cmd, capture_output=True, text=True); return g, r.returncode == 0, obj
def run(args):
    g, obj, t, s = args
    out = subprocess.run([f"{obj}/tb", f"+test={t}", f"+seed={s}"], capture_output=True, text=True, timeout=1800).stdout
    m = re.search(r"RESULT: (PASS|FAIL).*checks=(\d+)", out); st = re.search(r"engine commands=(\d+) \(coherent (\d+), uncached (\d+)\)\s+CPU perform events=(\d+)", out)
    return dict(geom=g, test=t, seed=s, ok=bool(m and m.group(1) == "PASS"), checks=int(m.group(2)) if m else 0,
                cmds=int(st.group(1)) if st else 0, coh=int(st.group(2)) if st else 0, cpu=int(st.group(4)) if st else 0)
if __name__ == "__main__":
    with cf.ThreadPoolExecutor(max_workers=2) as ex: built = {g: obj for g, ok, obj in ex.map(build, GEOM) if ok}
    jobs = [(g, obj, t, s) for g, obj in built.items() for t, ss in TESTS for s in ss]
    with cf.ThreadPoolExecutor(max_workers=2) as ex: rs = list(ex.map(run, jobs))
    ok = sum(r["ok"] for r in rs)
    with open("reports/coherence.md", "w") as f:
        f.write("# Coherence system regression\n\nReal CoherenceDirectory (P107, vendored unmodified) with N_AGENTS = 3: agents 0 and 1 are P107's own CPU cache adapters, agent 2 is the AtomicEngine's coherent path. "
                "Golden cache-line image checked on every performed operation of every agent; after each test every agent FLUSHes and the shared memory must equal the golden image.\n\n"
                f"**{ok} / {len(rs)} runs pass; {sum(r['checks'] for r in rs):,} self-checks; {sum(r['coh'] for r in rs):,} coherent atomic operations and {sum(r['cpu'] for r in rs):,} CPU cache operations checked.**\n\n"
                "| geometry | test | seed | result | engine commands | of which coherent | CPU cache operations | self-checks |\n|---|---|---|---|---|---|---|---|\n")
        for r in rs: f.write(f"| {r['geom']} | {r['test']} | {r['seed']} | {'PASS' if r['ok'] else '**FAIL**'} | {r['cmds']} | {r['coh']} | {r['cpu']} | {r['checks']:,} |\n")
    print(f"{ok}/{len(rs)} pass -> reports/coherence.md")
    sys.exit(0 if ok == len(rs) else 1)
