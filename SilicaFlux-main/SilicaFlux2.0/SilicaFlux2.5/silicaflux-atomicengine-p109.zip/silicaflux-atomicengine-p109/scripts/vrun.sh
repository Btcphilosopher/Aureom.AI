#!/usr/bin/env bash
# usage: scripts/vrun.sh <config-name> "<-G params>" <test> [seed]
# Builds (cached per config) the Verilator testbench and runs one test.  Output: last lines of the simulation only.
set -u
cd "$(dirname "$0")/.."
mkdir -p build
CFG="$1"; GPARAMS="$2"; TEST="$3"; SEED="${4:-1}"
OBJ="build/obj_$CFG"
if [ ! -x "$OBJ/tb_$CFG" ] || [ -n "$(find rtl tb -newer "$OBJ/tb_$CFG" -name '*.sv' 2>/dev/null | head -1)" ]; then
  verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-UNOPTFLAT -Wno-TIMESCALEMOD -Wno-IGNOREDRETURN \
    --assert -DSF_ATOMIC_PROPS -Iformal --top-module tb_sf_atomic_engine -Mdir "$OBJ" $GPARAMS -f rtl/files.f tb/sf_atomic_mem_model.sv tb/tb_sf_atomic_engine.sv \
    -o "tb_$CFG" > "build/build_$CFG.log" 2>&1 || { echo "BUILD FAILED ($CFG)"; grep -E "%Error" "build/build_$CFG.log" | head -20; exit 2; }
fi
"$OBJ/tb_$CFG" +test="$TEST" +seed="$SEED" 2>&1 | tail -${TAIL:-25}
