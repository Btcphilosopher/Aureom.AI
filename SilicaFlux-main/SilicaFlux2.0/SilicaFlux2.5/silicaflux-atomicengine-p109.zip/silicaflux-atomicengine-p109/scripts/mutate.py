#!/usr/bin/env python3
"""Mutation campaign: plant one deliberate defect at a time in the RTL and require the testbench to catch it.

usage: scripts/mutate.py [--jobs J] [--only id1,id2]
Each mutant = (id, file, old text, new text, what it breaks).  `old` must occur exactly once.  A mutant is KILLED when some test of
the quick list FAILs, times out or crashes.  Output: reports/mutation.md / .json.
"""
import argparse, concurrent.futures as cf, json, os, re, shutil, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

TESTS = ["smoke", "ticket", "cas", "overflow", "minmax", "contend", "perm", "errors", "order", "orderx", "starve", "reset", "queue", "quiesce", "fair", "random"]
GPARAMS = ["-GNCTX=4"]      # the campaign runs with 4 contexts so that memory-port arbitration inversions are reachable
M = []
EQUIV = {"O05"}      # provably equivalent control mutants: reported separately, not counted as survivors
def mut(id, f, old, new, why): M.append((id, f, old, new, why))

# ------------------------------------------------------------------ ALU
mut("A01", "sf_atomic_alu.sv", "AOP_FADD: begin new_o = sum_w;", "AOP_FADD: begin new_o = sum;", "32-bit fetch-add does not wrap at 32 bits")
mut("A02", "sf_atomic_alu.sv", "wire lt_s = (o_s < a_s);", "wire lt_s = (o < a);", "signed min/max compare as unsigned")
mut("A03", "sf_atomic_alu.sv", "AOP_MIN : begin new_o = lt_s ? o : a;", "AOP_MIN : begin new_o = lt_s ? a : o;", "MIN returns the maximum")
mut("A04", "sf_atomic_alu.sv", "        wr_o   = eq;\n", "        wr_o   = 1'b1;\n", "failed CAS still writes")
mut("A05", "sf_atomic_alu.sv", "        succ_o = eq;\n", "        succ_o = 1'b1;\n", "CAS always reports success")
mut("A06", "sf_atomic_alu.sv", "wire [63:0] c = wide_i ? cmp_i : {32'b0, cmp_i[31:0]};", "wire [63:0] c = cmp_i;", "32-bit CAS compares 64 bits")
mut("A07", "sf_atomic_alu.sv", "AOP_SWAP: begin new_o = a;", "AOP_SWAP: begin new_o = o;", "swap does not store the operand")
mut("A08", "sf_atomic_alu.sv", "{32'b0, ~o[31], o[30:0]}", "{32'b0, o[31], o[30:0]}", "32-bit signed compare without sign inversion")
mut("A09", "sf_atomic_alu.sv", "AOP_MAXU: begin new_o = lt_u ? a : o;", "AOP_MAXU: begin new_o = lt_u ? o : a;", "MAXU returns the minimum")
# ------------------------------------------------------------------ lock table
mut("L01", "sf_atomic_lock_table.sv", "if (v_q[i] && (k_q[i*KEYW +: KEYW] == h_key[h*KEYW +: KEYW])) h_lock_r[h] = 1'b1;", "if (v_q[i] && (k_q[i*KEYW +: KEYW] == h_key[h*KEYW +: KEYW])) h_lock_r[h] = 1'b0;", "second atomic on a locked granule is granted")
mut("L02", "sf_atomic_lock_table.sv", "if (v_q[i] && (k_q[i*KEYW +: KEYW] == o_key)) o_lock_r = 1'b1;", "if (v_q[i] && (k_q[i*KEYW +: KEYW] == o_key)) o_lock_r = 1'b0;", "ordinary writes are not held off by a lock")
mut("L03", "sf_atomic_lock_table.sv", "        if (rel_valid && (rel_idx == IDXW'(i))) v_q[i] <= 1'b0;\n", "", "locks are never released")
mut("L04", "sf_atomic_lock_table.sv", "      h_hold_r[h]  = hold_valid && (hold_key == h_key[h*KEYW +: KEYW]);", "      h_hold_r[h]  = 1'b0;", "no hold-off of atomics behind an ordinary write")
mut("L05", "sf_atomic_lock_table.sv", "      v_q      <= '0;\n      k_q      <= '0;\n      resv_v_q <= 1'b0;", "      k_q      <= '0;\n      resv_v_q <= 1'b0;", "locks survive a reset")
mut("L06", "sf_atomic_lock_table.sv", "assign o_resv = resv_v_q && (resv_k_q == o_key);", "assign o_resv = 1'b0;", "reservation never blocks ordinary writes (ordinary stream starves atomics)")
# ------------------------------------------------------------------ ordering
mut("O01", "sf_atomic_ordering.sv", "wire o_blocked  = o_req_we && (lk_o_lock || lk_o_resv);", "wire o_blocked  = 1'b0;", "ordinary writes interleave with atomics")
mut("O02", "sf_atomic_ordering.sv", "a_rsp_r[i] = rsp_atm && (m_rsp_id[IDW-1:0] == IDW'(i));", "a_rsp_r[i] = rsp_atm;", "every context takes every atomic response")
mut("O03", "sf_atomic_ordering.sv", "      if (sel_v && !m_req_ready) begin\n        lk_v <= 1'b1;", "      if (1'b0) begin\n        lk_v <= 1'b1;", "no grant lock: a stalled memory request can be withdrawn / switched")
mut("O04", "sf_atomic_ordering.sv", "  assign o_rsp_valid  = rst_n && (of_cnt != '0) && of_fill[of_hs];", "  assign o_rsp_valid  = (of_cnt != '0) && of_fill[of_hs];", "ordinary response valid during reset")
mut("O05", "sf_atomic_ordering.sv", "  assign m_rsp_ready = 1'b1;               // every response slot was reserved at acceptance", "  assign m_rsp_ready = !rsp_ord || o_rsp_ready || o_space;", "(equivalent: space reserved) -- control mutant")
mut("O06", "sf_atomic_ordering.sv", "of_dat [m_rsp_id[OW-1:0]*64 +: 64] <= (m_rsp_status == 4'd0) ? m_rsp_rdata : 64'd0;", "of_dat [m_rsp_id[OW-1:0]*64 +: 64] <= 64'd0;", "ordinary read data lost")
# ------------------------------------------------------------------ engine
mut("E01", "sf_atomic_engine.sv", "assign elig = elig_nolock & ~h_lock & ~h_hold;", "assign elig = elig_nolock & ~h_hold;", "atomics on the same granule overlap (lost updates)")
mut("E02", "sf_atomic_engine.sv", "ord_ok[c] = (!hd_rl[c] || (q_run[c*CNTW +: CNTW] == '0)) && (q_aqrun[c*CNTW +: CNTW] == '0);", "ord_ok[c] = 1'b1;", "aq / rl ordering bits ignored")
mut("E03", "sf_atomic_engine.sv", "pm_ok  = grd_ok_r[c] && grd_ok_w[c];", "pm_ok  = grd_ok_r[c];", "write permission not checked")
mut("E04", "sf_atomic_engine.sv", "dm_ok  = port_dom_mask[c*ND + 32'(dm_c)];", "dm_ok  = 1'b1;", "domain binding not checked")
mut("E05", "sf_atomic_engine.sv", "al_ok  = wide_c ? (ad_c[2:0] == 3'd0) : (ad_c[1:0] == 2'd0);", "al_ok  = (ad_c[1:0] == 2'd0);", "64-bit operations accepted at 4-byte alignment")
mut("E06", "sf_atomic_engine.sv", "in_uc  = uc_cfg_ok && (ad_c >= win_base) && (ad_c < win_limit);", "in_uc  = uc_cfg_ok && (ad_c >= win_base) && (ad_c <= win_limit);", "off-by-one at the window limit")
mut("E07", "sf_atomic_engine.sv", "                cx_stat[i*4 +: 4] <= AST_READ;\n                cx_old [i*64 +: 64] <= 64'd0;\n                cx_succ[i]        <= 1'b0;\n                cx_st  [i*3 +: 3] <= CX_FIN;", "                cx_stat[i*4 +: 4] <= AST_READ;\n                cx_old [i*64 +: 64] <= 64'd0;\n                cx_succ[i]        <= 1'b0;\n                cx_st  [i*3 +: 3] <= CX_WR;", "write issued after a failed read")
mut("E08", "sf_atomic_engine.sv", "assign rel_valid  = fin_any && cx_lkheld[fin_idx];", "assign rel_valid  = 1'b0;", "lock never released at completion")
mut("E09", "sf_atomic_engine.sv", "assign a_req_wdata = cx_new;", "assign a_req_wdata = cx_old;", "write data is the old value")
mut("E10", "sf_atomic_engine.sv", "de_ok  = (32'(ds_c) < NC) && dest_allow[c*NC + 32'(ds_c)];", "de_ok  = 1'b1;", "completion destination not checked")
mut("E11", "sf_atomic_engine.sv", "assign res_succ   = cx_succ[fin_idx] && (cx_stat[fin_idx*4 +: 4] == AST_OK);", "assign res_succ   = 1'b1;", "completion always reports success")
mut("E12", "sf_atomic_engine.sv", "                cx_old [i*64 +: 64] <= alu_old;\n                cx_new [i*64 +: 64] <= alu_new;", "                cx_old [i*64 +: 64] <= alu_new;\n                cx_new [i*64 +: 64] <= alu_new;", "completion returns the NEW value instead of the original")
mut("E13", "sf_atomic_engine.sv", "      if ((s == CX_WR) && a_req_ready[i]) begin\n        ev_v[i] = 1'b1; ev_wr[i] = 1'b1;", "      if ((s == CX_WR) && a_req_ready[i]) begin\n        ev_v[i] = 1'b0; ev_wr[i] = 1'b1;", "linearisation event of writing operations missing")
mut("E14", "sf_atomic_engine.sv", "dest_eff[c*CLW +: CLW] = de_ok ? ds_c : CLW'(c);", "dest_eff[c*CLW +: CLW] = CLW'(c);", "completion destination ignored (always the issuer)")
# ------------------------------------------------------------------ queue
mut("Q01", "sf_atomic_queue.sv", "full_r[c]  = ((t - h) == PTW'(QD));", "full_r[c]  = ((t - h) == PTW'(QD + 1));", "queue accepts one command too many (overwrites a pending entry)")
mut("Q02", "sf_atomic_queue.sv", "assign in_ready   = ~full_r & {NC{~block_in & rst_n}};", "assign in_ready   = ~full_r & {NC{rst_n}};", "quiesce does not stop ingress")
mut("Q03", "sf_atomic_queue.sv", "        sch_rr <= (32'(gnt_client) == NC - 1) ? '0 : (gnt_client + CLW'(1));", "        sch_rr <= '0;", "scheduler is fixed priority (client 0 first)")
mut("Q04", "sf_atomic_queue.sv", "        co_q  [e*64 +: 64] <= res_old;\n        succ_q[e]          <= res_succ;", "        co_q  [e*64 +: 64] <= res_old;\n        succ_q[e]          <= 1'b0;", "success flag lost in the queue")
mut("Q05", "sf_atomic_queue.sv", "          dst_q [e*CLW  +: CLW ] <= in_dest[c*CLW  +: CLW ];", "          dst_q [e*CLW  +: CLW ] <= CLW'(c);", "destination lost in the queue")
mut("Q06", "sf_atomic_queue.sv", "          tag_q [e*TAGW +: TAGW] <= in_tag [c*TAGW +: TAGW];", "          tag_q [e*TAGW +: TAGW] <= in_tag [c*TAGW +: TAGW] ^ TAGW'(e == 3);", "tag corrupted for one slot")


# ------------------------------------------------------------------ coherence-path mutants (run with --coh against tb/tb_sf_atomic_coh.sv and the REAL P107 directory)
CM = []
def cmut(id, f, old, new, why): CM.append((id, f, old, new, why))
cmut("C01", "sf_atomic_coh_agent.sv", "    if (alu_wr) begin\n      if (o_wide) new_line[boff*8 +: 64] = alu_new;", "    if (1'b0) begin\n      if (o_wide) new_line[boff*8 +: 64] = alu_new;", "ALU result never merged into the line (lost update)")
cmut("C02", "sf_atomic_coh_agent.sv", "rq_v <= 1'b1; rq_t <= RQ_PUTM; rq_l <= p_line; rq_d <= new_line;", "rq_v <= 1'b1; rq_t <= RQ_PUTM; rq_l <= p_line; rq_d <= gn_data;", "PUTM writes back the UNMODIFIED line (memory loses the update)")
cmut("C03", "sf_atomic_coh_agent.sv", "rs_v <= 1'b1; rs_t <= RS_DATA; rs_l <= sn_line; rs_d <= p_data; rs_k <= 1'b0;", "rs_v <= 1'b1; rs_t <= RS_DATA; rs_l <= sn_line; rs_d <= {LB{1'b0}}; rs_k <= 1'b0;", "intervention from the eviction buffer returns zeros")
cmut("C04", "sf_atomic_coh_agent.sv", "      else        new_line[boff*8 +: 32] = alu_new[31:0];", "      else        new_line[(boff & 6'h38)*8 +: 32] = alu_new[31:0];", "32-bit result written to the wrong half of the 8-byte word")
cmut("C05", "sf_atomic_coh_agent.sv", "assign res_old    = gnt_perf ? old_w : r_old;", "assign res_old    = gnt_perf ? alu_new : r_old;", "commit event reports the new value as the old value")
cmut("C06", "sf_atomic_coh_agent.sv", "rs_v <= 1'b1; rs_t <= RS_COMPLETE; rs_l <= gn_line; rs_k <= 1'b0;", "rs_v <= 1'b0; rs_t <= RS_COMPLETE; rs_l <= gn_line; rs_k <= 1'b0;", "COMPLETE never sent (the directory keeps the line blocked)")
cmut("C07", "sf_atomic_engine.sv", "              cx_old [i*64 +: 64] <= ca_res_err ? 64'd0 : ca_res_old;", "              cx_old [i*64 +: 64] <= 64'd0;", "coherent completion returns old = 0")
cmut("C08", "sf_atomic_coh_agent.sv", "  wire gnt_perf = gnt_take && (a_st == AG_REQ) && (p_st == PS_IM) && (gn_line == p_line) && (gn_type == GN_DATA_M);", "  wire gnt_perf = gnt_take && (a_st == AG_REQ) && (p_st == PS_IM) && (gn_type == GN_DATA_M);", "grant for a different line accepted as the awaited one")
CEQUIV = {"C08"}
CTESTS = [("coh_directed", 1), ("coh_naive", 1), ("coh_random", 1), ("coh_stress", 1)]

def build_and_run_coh(m):
    id, f, old, new, why = m
    d = f"build/mut/{id}"
    shutil.rmtree(d, ignore_errors=True); os.makedirs(d + "/rtl")
    for fn in os.listdir("rtl"): shutil.copy(f"rtl/{fn}", f"{d}/rtl/{fn}")
    src = open(f"{d}/rtl/{f}").read()
    if src.count(old) != 1: return dict(id=id, file=f, why=why, status="BAD-MUTANT", detail=f"pattern occurs {src.count(old)} times")
    open(f"{d}/rtl/{f}", "w").write(src.replace(old, new))
    files = [x.replace("rtl/", f"{d}/rtl/") for x in [l.strip() for l in open("rtl/files.f") if l.strip()]]
    C = "third_party/coherence_p107"
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH", "-Wno-UNOPTFLAT", "-Wno-TIMESCALEMOD", "-Wno-IGNOREDRETURN", "-Wno-PINMISSING",
           "--top-module", "tb_sf_atomic_coh", "-Mdir", f"{d}/obj", f"{C}/sf_coherence_pkg.sv", f"{C}/sf_coherence_sharers.sv", f"{C}/sf_coherence_transient_fsm.sv",
           f"{C}/sf_coherence_directory.sv", f"{C}/sf_coherence_agent_adapter.sv", f"{C}/sf_coh_mem_model.sv"] + files + ["tb/sf_atomic_mem_model.sv", "tb/tb_sf_atomic_coh.sv", "-o", "tbm"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0: return dict(id=id, file=f, why=why, status="BUILD-FAIL", detail=(r.stderr + r.stdout)[-300:])
    killed_by = None; detail = ""
    for t, sd in CTESTS:
        try:
            p = subprocess.run([f"{d}/obj/tbm", f"+test={t}", f"+seed={sd}"], capture_output=True, text=True, timeout=300)
            out = p.stdout + p.stderr
            if "RESULT: PASS" not in out:
                killed_by = t; errs = [l for l in out.splitlines() if "ERROR" in l]
                detail = errs[0][:150] if errs else "no PASS"; break
        except subprocess.TimeoutExpired:
            killed_by = t; detail = "timeout"; break
    shutil.rmtree(d, ignore_errors=True)
    return dict(id=id, file=f, why=why, status="KILLED" if killed_by else "SURVIVED", killed_by=killed_by, detail=detail)

def build_and_run(m):
    id, f, old, new, why = m
    d = f"build/mut/{id}"
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d + "/rtl")
    for fn in os.listdir("rtl"):
        shutil.copy(f"rtl/{fn}", f"{d}/rtl/{fn}")
    src = open(f"{d}/rtl/{f}").read()
    if src.count(old) != 1:
        return dict(id=id, file=f, why=why, status="BAD-MUTANT", detail=f"pattern occurs {src.count(old)} times")
    open(f"{d}/rtl/{f}", "w").write(src.replace(old, new))
    files = [l.strip() for l in open("rtl/files.f") if l.strip()]
    files = [x.replace("rtl/", f"{d}/rtl/") for x in files]
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH", "-Wno-UNOPTFLAT", "-Wno-TIMESCALEMOD",
           "-Wno-IGNOREDRETURN", "--top-module", "tb_sf_atomic_engine", "-Mdir", f"{d}/obj"] + GPARAMS + files + \
          ["tb/sf_atomic_mem_model.sv", "tb/tb_sf_atomic_engine.sv", "-o", "tbm"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        return dict(id=id, file=f, why=why, status="BUILD-FAIL", detail=(r.stderr + r.stdout)[-400:])
    killed_by = None; detail = ""
    for t in TESTS:
        try:
            p = subprocess.run([f"{d}/obj/tbm", f"+test={t}", "+seed=1"], capture_output=True, text=True, timeout=240)
            out = p.stdout + p.stderr
            if "RESULT: PASS" not in out:
                killed_by = t
                errs = [l for l in out.splitlines() if "ERROR" in l]
                detail = errs[0][:150] if errs else out.strip().splitlines()[-1][:150] if out.strip() else "no output"
                break
        except subprocess.TimeoutExpired:
            killed_by = t; detail = "timeout"
            break
    shutil.rmtree(d, ignore_errors=True)
    return dict(id=id, file=f, why=why, status="KILLED" if killed_by else "SURVIVED", killed_by=killed_by, detail=detail)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", default="")
    ap.add_argument("--report-only", action="store_true")
    ap.add_argument("--coh", action="store_true", help="run the coherence-path mutants against the real P107 directory")
    a = ap.parse_args()
    if a.coh:
        res = []
        if a.report_only:
            res = json.load(open("reports/mutation_coh.json"))
        else:
            with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
                for r in ex.map(build_and_run_coh, CM):
                    res.append(r); print(f"{r['id']} {r['status']:9s} {r.get('killed_by') or '':12s} {r['why']}  {r.get('detail','')[:90]}", flush=True)
            json.dump(res, open("reports/mutation_coh.json", "w"), indent=1)
        for r in res:
            if r["id"] in CEQUIV and r["status"] != "KILLED": r["status"] = "EQUIVALENT"
        n_eq = sum(r["status"] == "EQUIVALENT" for r in res)
        kill = sum(r["status"] == "KILLED" for r in res)
        with open("reports/mutation_coh.md", "w") as f:
            f.write("# Mutation campaign — coherence path\n\nOne defect at a time in `sf_atomic_coh_agent.sv` / the engine's coherent write-back, run against the REAL CoherenceDirectory "
                    "(P107) with two real CPU cache agents (`tb/tb_sf_atomic_coh.sv`: directed, negative control, random, stress).\n\n"
                    f"**{kill} / {len(res) - n_eq} non-equivalent mutants killed** ({n_eq} defensive-check mutant(s) that a correct directory can never exercise, listed as EQUIVALENT: "
                    "C08 removes the `gn_line == p_line` check of a grant; the verified directory only ever grants the line that was requested, so only a fault-injecting directory model could expose it).\n\n"
                    "| id | file | planted defect | result | first failing test | first error |\n|---|---|---|---|---|---|\n")
            for r in res:
                f.write(f"| {r['id']} | `{r['file']}` | {r['why']} | {r['status']} | {r.get('killed_by') or ''} | {r.get('detail','').replace('|','/')[:110]} |\n")
        print(f"{kill}/{len(res) - n_eq} non-equivalent killed -> reports/mutation_coh.md"); return
    muts = [m for m in M if not a.only or m[0] in a.only.split(",")]
    os.makedirs("reports", exist_ok=True)
    res = []
    if a.report_only:
        res = json.load(open("reports/mutation.json"))
    else:
        with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
            for r in ex.map(build_and_run, muts):
                res.append(r); print(f"{r['id']} {r['status']:9s} {r.get('killed_by') or '':9s} {r['why']}  {r.get('detail','')[:90]}", flush=True)
        res.sort(key=lambda r: r["id"])
        json.dump(res, open("reports/mutation.json", "w"), indent=1)
    for r in res:
        if r["id"] in EQUIV and r["status"] != "KILLED": r["status"] = "EQUIVALENT"
    kill = sum(r["status"] == "KILLED" for r in res)
    n_equiv = sum(r["status"] == "EQUIVALENT" for r in res)
    with open("reports/mutation.md", "w") as f:
        f.write("# Mutation campaign\n\nOne deliberate RTL defect at a time (`scripts/mutate.py`); the quick test list is run on the 4-context "
                "configuration (`-GNCTX=4`) until one test fails (see the file header for the list).\n\n")
        f.write(f"**{kill} / {len(res) - n_equiv} non-equivalent mutants killed** ({n_equiv} provably equivalent control mutant(s) listed separately).\n\n| id | file | planted defect | result | first failing test | first error |\n|---|---|---|---|---|---|\n")
        for r in res:
            f.write(f"| {r['id']} | `{r['file']}` | {r['why']} | {r['status']} | {r.get('killed_by') or ''} | {r.get('detail','').replace('|','/')[:110]} |\n")
        surv = [r for r in res if r["status"] not in ("KILLED", "EQUIVALENT")]
        if surv:
            f.write("\n## Not killed\n\n")
            for r in surv: f.write(f"* **{r['id']}** ({r['file']}): {r['why']} -- {r['status']} {r.get('detail','')}\n")
    print(f"{kill}/{len(res) - n_equiv} non-equivalent killed -> reports/mutation.md")

main()
