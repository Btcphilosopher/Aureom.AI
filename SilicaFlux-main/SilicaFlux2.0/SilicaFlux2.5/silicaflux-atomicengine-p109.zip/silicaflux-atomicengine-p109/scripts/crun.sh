#!/usr/bin/env bash
# usage: scripts/crun.sh <test> [seed] [extra verilator -G params]     coherence system testbench (real P107 directory + 2 CPU agents + engine agent)
set -u
cd "$(dirname "$0")/.."
mkdir -p build
TEST="$1"; SEED="${2:-1}"; GP="${3:-}"
OBJ="build/obj_coh${GP//[^A-Za-z0-9]/_}"
C=third_party/coherence_p107
if [ ! -x "$OBJ/tb_coh" ] || [ -n "$(find rtl tb formal $C -newer "$OBJ/tb_coh" \( -name '*.sv' -o -name '*.svh' \) 2>/dev/null | head -1)" ]; then
  verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-UNOPTFLAT -Wno-TIMESCALEMOD -Wno-IGNOREDRETURN -Wno-PINMISSING \
    --assert -DSF_ATOMIC_PROPS -Iformal --top-module tb_sf_atomic_coh -Mdir "$OBJ" $GP \
    $C/sf_coherence_pkg.sv $C/sf_coherence_sharers.sv $C/sf_coherence_transient_fsm.sv $C/sf_coherence_directory.sv $C/sf_coherence_agent_adapter.sv $C/sf_coh_mem_model.sv \
    -f rtl/files.f tb/sf_atomic_mem_model.sv tb/tb_sf_atomic_coh.sv -o tb_coh > "$OBJ.log" 2>&1 || { echo "BUILD FAILED"; grep -E "%Error" "$OBJ.log" | head -20; exit 2; }
fi
"$OBJ/tb_coh" +test="$TEST" +seed="$SEED" 2>&1 | tail -${TAIL:-25}
