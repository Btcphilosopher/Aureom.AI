#!/usr/bin/env bash
# Replays the Python reference vectors (model/sf_atomic_ref.py) against sf_atomic_alu.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build
python3 -I model/sf_atomic_ref.py
python3 -I model/sf_atomic_ref.py vectors build/alu_vectors.hex
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-TIMESCALEMOD -Wno-IGNOREDRETURN --top-module tb_sf_atomic_alu \
  -Mdir build/obj_alu rtl/sf_atomic_pkg.sv rtl/sf_atomic_alu.sv tb/tb_sf_atomic_alu.sv -o tb_alu > build/obj_alu.log 2>&1 || { tail -20 build/obj_alu.log; exit 2; }
build/obj_alu/tb_alu +vec=build/alu_vectors.hex 2>&1 | grep -E "RESULT|vec "
