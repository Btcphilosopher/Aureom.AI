// =============================================================================
// Formal properties of sf_atomic_ordering
//
// ENVIRONMENT
//   EO1  a context request that was not accepted is presented again unchanged (SFB2 R2 on the context side: the FSM holds it)
//   EO2  an ordinary request that was not accepted is presented again unchanged (SFB2 R2 on the ordinary side)
//   EO3  a lock on the key of a PENDING ordinary write never appears while the write is held off (the engine's lock table obeys
//        hold_valid: acquisitions for a held-off key are refused).  This is the contract proved on the lock table (L1/EN1) and
//        re-proved on the integrated engine (fv_engine_props.svh X1 without this assumption).
//   EO4  atom_prot_i and the coherent-window registers are static configuration (integration rule R4)
// PROPERTIES
//   O1  the memory master port obeys R2: a request that was not accepted is presented again with unchanged payload
//   O2  an ordinary WRITE is accepted by memory only when its granule is not locked
//   O3  at most one requester is accepted per cycle; a context is accepted only while it requests
//   O4  nothing is presented to memory during reset
//   O5  the ordinary response FIFO never holds more than OMAX entries
// =============================================================================
`ifdef SF_ATOMIC_FORMAL_UNIT
  reg f_first = 1'b1;
  always @(posedge clk) f_first <= 1'b0;
  always @* begin
    if (f_first) assume(!rst_n); else assume(rst_n);
  end
  reg [NCTX-1:0]      f_as_q;
  reg [NCTX-1:0]      f_aw_q, f_awd_q;
  reg [NCTX*AW-1:0]   f_aa_q;
  reg [NCTX*64-1:0]   f_ad_q;
  reg                 f_os_q, f_ow_q;
  reg [AW+3+64+8+OIDW+2:0] f_opl_q;
  reg                 f_lk_q, f_hv_q;
  reg [1:0]           f_ap_q;
  reg [AW-1:0]        f_cb_q, f_cl_q;
  wire [AW+3+64+8+OIDW+2:0] f_opl = {o_req_we, o_req_addr, o_req_size, o_req_wdata, o_req_be, o_req_id, o_req_prot};
  always @(posedge clk) begin
    f_as_q  <= rst_n ? (a_req_valid & ~a_req_ready) : '0;
    f_aw_q  <= a_req_we; f_awd_q <= a_req_wide; f_aa_q <= a_req_addr; f_ad_q <= a_req_wdata;
    f_os_q  <= rst_n && o_req_valid && !o_req_ready;
    f_ow_q  <= rst_n && o_req_valid && o_req_we && !o_req_ready;
    f_opl_q <= f_opl;
    f_lk_q  <= lk_o_lock;
    f_hv_q  <= hold_valid;
    f_ap_q  <= atom_prot_i; f_cb_q <= coh_base; f_cl_q <= coh_limit;
  end
  always @* if (!f_first) begin
    for (int i = 0; i < NCTX; i++) if (f_as_q[i]) begin
      assume(a_req_valid[i]);
      assume(a_req_we[i] == f_aw_q[i]);
      assume(a_req_wide[i] == f_awd_q[i]);
      assume(a_req_addr[i*AW +: AW] == f_aa_q[i*AW +: AW]);
      assume(!f_aw_q[i] || (a_req_wdata[i*64 +: 64] == f_ad_q[i*64 +: 64]));
    end
    if (f_os_q) begin assume(o_req_valid); assume(f_opl == f_opl_q); end
    // EO3
    if (f_ow_q && lk_o_lock && !f_lk_q) assume(!f_hv_q);
    // EO4: the configuration inputs are static (integration rule R4)
    assume(atom_prot_i == f_ap_q);
    assume(coh_base == f_cb_q);
    assume(coh_limit == f_cl_q);
  end
`endif
`ifdef SF_ATOMIC_PROPS
  reg f_pv, f_ms_q;
  reg [AW+3+64+8+MIDW+2:0] f_mpl, f_mpl_q;
  // SFB2 R2: wdata is part of the held payload for WRITES only (a read's data bus is a don't-care)
  always @* f_mpl = {m_req_we, m_req_addr, m_req_size, (m_req_we ? m_req_wdata : 64'd0), m_req_be, m_req_id, m_req_prot};
  always @(posedge clk) begin f_pv <= rst_n; f_ms_q <= rst_n && m_req_valid && !m_req_ready; f_mpl_q <= f_mpl; end
  always @(posedge clk) if (f_pv && rst_n && f_ms_q) begin assert(m_req_valid); assert(f_mpl == f_mpl_q); end     // O1
  always @* if (rst_n) begin
    if (ev_ord_wr) assert(!lk_o_lock);                                                                              // O2
    assert(((a_req_ready & (a_req_ready - 1'b1)) == '0) && !(|a_req_ready && o_acc_mem));                           // O3
    assert((a_req_ready & ~a_req_valid) == '0);
    assert(of_cnt <= (OW+1)'(OMAX));                                                                                // O5
  end
  always @* if (!rst_n) assert(!m_req_valid);                                                                       // O4
`endif
