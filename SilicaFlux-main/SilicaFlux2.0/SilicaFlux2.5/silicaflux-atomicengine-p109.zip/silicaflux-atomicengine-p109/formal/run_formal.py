#!/usr/bin/env python3
"""Formal runner: Yosys 0.33 internal SAT engine (`sat -tempinduct` / `sat -seq`).  Writes reports/formal.md and reports/formal.json.

Why not SymbiYosys: it is not installed in this environment; z3-based yosys-smtbmc was tried first and stalls on the queue (variable shifts of wide vectors),
whereas Yosys's own SAT back end closes the same models in seconds.  ABC PDR could not be driven (this Yosys 0.33 flow cannot export these models to AIGER).

Verdicts
  UNBOUNDED  temporal induction closed ("Induction step proven: SUCCESS!") -- the property holds for ALL depths under the stated environment
  BOUNDED    "no model found" for every execution of the stated length from reset -- a bounded model check, nothing is said beyond that depth
  NON-VACUITY  each cover point is turned into assert(!cover); a counterexample is the proof that the point is reachable under the environment
Jobs
  alu         all-input combinational proof (UNBOUNDED, no state)                  + sensitivity: the same proof FAILS on a planted ALU defect
  lock        lock table L1..L5                                                    induction + BMC + 5 cover points
  queue_struct queue structural properties Q1 Q2 Q3 Q5 Q7 Q8 Q10 (-DSF_Q_STRUCT_ONLY) induction
  queue       all queue properties Q1..Q10 (NC=2, QD=2)                            BMC
  ordering    ordering unit O1..O5 (NCTX=2)                                        induction attempt + BMC
  engine      whole engine X1..X5 (NC=2, QD=2, NCTX=2, AW=16)                      BMC + 8 cover points
  engine_rst  whole engine with a FREE reset X7                                    BMC
"""
import json, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
os.makedirs("build/formal", exist_ok=True); os.makedirs("reports", exist_ok=True)
PKG = "rtl/sf_atomic_pkg.sv"
UNIT = "-DSF_ATOMIC_FORMAL_UNIT -DSF_ATOMIC_PROPS -Iformal"      # unit proofs: the module's own environment assumptions + its assertions
WHOLE = "-DSF_ATOMIC_FORMAL -DSF_ATOMIC_PROPS -Iformal"          # whole engine: ONLY the engine's environment on its top-level ports; every sub-module property is an assertion in situ

def sh(cmd, timeout):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout + p.stderr, time.time() - t0
    except subprocess.TimeoutExpired:
        return 124, "timeout", time.time() - t0

def front(files, top, chparam, defs, base=None):
    ch = f"chparam {chparam} {top}; " if chparam else ""
    return (f"read_verilog -formal -sv -defer {base or UNIT} {defs} {files}; {ch}hierarchy -top {top}; prep -top {top}; chformal -cover -remove; "
            f"flatten; memory_map; opt -fast; async2sync; dffunmap; opt_clean; ")

def sat_ind(files, top, chparam, k, defs="", timeout=3000, base=None):
    rc, out, t = sh(f"yosys -p \"{front(files, top, chparam, defs, base)} sat -tempinduct -prove-asserts -set-assumes -maxsteps {k} -verify\"", timeout)
    ok = "Induction step proven: SUCCESS" in out
    base = re.findall(r"Base case for induction length (\d+) proven", out)
    return dict(mode="induction", ok=ok, secs=round(t, 1), depth=(f"k={base[-1]}" if base else ""),
                tail="induction step proven (all depths)" if ok else ("base case proven to length " + (base[-1] if base else "?") + "; induction step did not close"
                                                                   if "timeout" not in out and "model found for base" not in out else
                                                                   ("COUNTEREXAMPLE in the base case" if "model found for base" in out else "timeout")))

def sat_bmc(files, top, chparam, n, defs="", timeout=3000, base=None):
    rc, out, t = sh(f"yosys -p \"{front(files, top, chparam, defs, base)} sat -seq {n} -prove-asserts -set-assumes -verify\"", timeout)
    ok = "no model found: SUCCESS" in out
    return dict(mode="bmc", ok=ok, secs=round(t, 1), depth=n, tail="no counterexample within the depth" if ok else ("timeout" if "timeout" in out else "COUNTEREXAMPLE / error: " + out[-120:]))

def sat_cover(files, top, chparam, n, sel, steps, timeout=1500, base=None):
    rc, out, t = sh(f"yosys -p \"{front(files, top, chparam, f'-DSF_COVER_SEL={sel}', base)} sat -seq {steps} -prove-asserts -set-assumes\"", timeout)
    if "model found: FAIL" in out: return True, round(t, 1)         # the assert(!cover) FAILED  =>  the cover point is reachable
    if "no model found: SUCCESS" in out: return False, round(t, 1)  # proven unreachable within the depth
    return None, round(t, 1)                                         # no verdict (timeout / killed): inconclusive, never counted as unreachable

JOBS = {
  "lock": dict(files=f"{PKG} rtl/sf_atomic_lock_table.sv", top="sf_atomic_lock_table", ch="-set N 3 -set KEYW 3 -set NH 2", ind=10, bmc=30, covers=5, cov_steps=12),
  "queue_struct": dict(files=f"{PKG} rtl/sf_atomic_queue.sv", top="sf_atomic_queue", ch="-set NC 2 -set QD 2 -set PW 8 -set TAGW 2 -set RIDW 1", defs="-DSF_Q_STRUCT_ONLY", ind=6),
  "queue": dict(files=f"{PKG} rtl/sf_atomic_queue.sv", top="sf_atomic_queue", ch="-set NC 2 -set QD 2 -set PW 8 -set TAGW 2 -set RIDW 1", bmc=20),
  "ordering": dict(files=f"{PKG} rtl/sf_atomic_ordering.sv", top="sf_atomic_ordering", ch="-set NCTX 2 -set AW 16 -set GRAN 3 -set OMAX 2 -set OIDW 2", ind=6, bmc=16),
  "engine": dict(files=f"{PKG} rtl/sf_atomic_alu.sv rtl/sf_atomic_lock_table.sv rtl/sf_atomic_queue.sv rtl/sf_atomic_ordering.sv rtl/sf_atomic_perf.sv rtl/sf_atomic_coh_agent.sv rtl/sf_atomic_engine.sv",
                 top="sf_atomic_engine", ch="-set NC 2 -set QD 2 -set NCTX 2 -set AW 16 -set TAGW 2 -set RIDW 1 -set DOMW 1 -set OIDW 2 -set OMAX 2 -set PERF 0", bmc=14, covers=8, cov_steps=16, whole=True),
}

# a shallower whole-engine run (finishes much sooner than depth 14; both are reported)
JOBS["engine_d10"] = dict(JOBS["engine"], bmc=10, covers=8, cov_steps=14)

def main():
    only = sys.argv[1:]
    res = {}
    if not only or "alu" in only:
        rc, out, t = sh(f"yosys -p \"read_verilog -formal -sv {PKG} rtl/sf_atomic_alu.sv formal/fv_alu.sv; prep -top fv_alu; flatten; sat -verify -prove-asserts -timeout 900\"", 1000)
        ok = "no model found: SUCCESS" in out
        mut = open("rtl/sf_atomic_alu.sv").read().replace("wire lt_s = (o_s < a_s);", "wire lt_s = (o < a);")
        open("build/formal/alu_mut.sv", "w").write(mut)
        rc2, out2, t2 = sh(f"yosys -p \"read_verilog -formal -sv {PKG} build/formal/alu_mut.sv formal/fv_alu.sv; prep -top fv_alu; flatten; sat -verify -prove-asserts -timeout 900\"", 1000)
        caught = rc2 != 0 and "no model found: SUCCESS" not in out2
        res["alu"] = dict(kind="UNBOUNDED", ok=ok and caught, jobs=[dict(mode="all-input proof", depth="", ok=ok, secs=round(t, 1), tail="no counterexample for any input"),
                                                                dict(mode="sensitivity (planted signed-compare defect)", depth="", ok=caught, secs=round(t2, 1), tail="counterexample found: the harness can fail")])
        print("alu", res["alu"]["ok"], flush=True)
    for name, j in JOBS.items():
        if only and name not in only: continue
        jobs = []
        if j.get("ind"):
            r = sat_ind(j["files"], j["top"], j["ch"], j["ind"], j.get("defs", "")); jobs.append(r); print(name, "induction", r["ok"], r["secs"], r["tail"], flush=True)
        if os.environ.get("COVERS_ONLY"): j = dict(j, bmc=None)
        if j.get("bmc"):
            r = sat_bmc(j["files"], j["top"], j["ch"], j["bmc"], j.get("defs", ""), base=(WHOLE if j.get("whole") else None)); jobs.append(r); print(name, "bmc", r["ok"], r["secs"], flush=True)
        if j.get("covers"):
            reached = []
            for n in range(1, j["covers"] + 1):
                ok_c, t = sat_cover(j["files"], j["top"], j["ch"], j["covers"], n, j["cov_steps"], base=(WHOLE if j.get("whole") else None))
                if ok_c is None: ok_c, t = sat_cover(j["files"], j["top"], j["ch"], j["covers"], n, j["cov_steps"], base=(WHOLE if j.get("whole") else None))   # one retry
                reached.append(ok_c)
            jobs.append(dict(mode="non-vacuity (cover points)", depth=j["cov_steps"], ok=all(x is True for x in reached), secs=0,
                             tail=f"{sum(x is True for x in reached)} of {len(reached)} cover points reachable under the environment" + (" (inconclusive: %d)" % sum(x is None for x in reached) if any(x is None for x in reached) else "")))
            print(name, "covers", reached, flush=True)
        if os.environ.get("COVERS_ONLY") and os.path.exists("reports/formal.json"):
            old = json.load(open("reports/formal.json")).get(name, {}).get("jobs", [])
            jobs = [x for x in old if x["mode"] != "non-vacuity (cover points)"] + jobs
        unb = any(x["mode"] == "induction" and x["ok"] for x in jobs)
        res[name] = dict(kind="UNBOUNDED" if unb else "BOUNDED", ok=all(x["ok"] for x in jobs if x["mode"] in ("bmc", "non-vacuity (cover points)")), jobs=jobs)
    if not only or "engine_rst" in only:
        j = JOBS["engine"]
        r = sat_bmc(j["files"], j["top"], j["ch"], 8, "-DSF_FORMAL_RESET", base=WHOLE)
        res["engine_rst"] = dict(kind="BOUNDED", ok=r["ok"], jobs=[r]); print("engine_rst", r["ok"], flush=True)
    prev = {}
    if os.path.exists("reports/formal.json"):
        try: prev = json.load(open("reports/formal.json"))
        except Exception: prev = {}
    prev.update(res)
    json.dump(prev, open("reports/formal.json", "w"), indent=1)
    with open("reports/formal.md", "w") as f:
        f.write("# Formal results (Yosys 0.33 internal SAT: `sat -tempinduct` / `sat -seq`)\n\nProperties live in `formal/*.svh` (included into the RTL under `SF_ATOMIC_PROPS` / `SF_ATOMIC_FORMAL`); their headers define each "
                "property and the environment assumptions. **UNBOUNDED** = temporal induction closed, valid for all depths under the environment; **BOUNDED** = no counterexample in any execution "
                "of the stated length from reset, nothing beyond. Instances are deliberately small (see each row's parameters in `formal/run_formal.py`).\n\n"
                "| module / harness | verdict | check | depth | result | seconds | note |\n|---|---|---|---|---|---|---|\n")
        for n, r in prev.items():
            for x in r["jobs"]:
                f.write(f"| {n} | {r['kind'] if x['mode'] in ('induction', 'all-input proof') else 'BOUNDED' if x['mode'] == 'bmc' else ''} | {x['mode']} | {x.get('depth', '')} | {'PASS' if x['ok'] else '**no result / FAIL**'} | {x['secs']} | {x['tail'][:110]} |\n")
    print("wrote reports/formal.md")
main()
