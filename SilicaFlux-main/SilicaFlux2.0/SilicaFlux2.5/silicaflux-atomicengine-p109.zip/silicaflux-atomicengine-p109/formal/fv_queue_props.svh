// =============================================================================
// Formal properties of sf_atomic_queue
//
// ENVIRONMENT  EQ1  a completion write-back (res_*) addresses an entry that was started and is not yet done
// STRUCTURAL-ONLY MODE (-DSF_Q_STRUCT_ONLY): drops the environment assumption and the two groups that need a shadow of the running entries
//   (Q4, Q6) so that the remaining properties (Q1, Q2, Q3, Q5, Q7, Q8, Q10) are closed by temporal induction for ALL depths.
// PROPERTIES
//   Q1  a ring never holds more than QD entries; issued entries never exceed allocated entries     (bounded queues, no overwrite)
//   Q2  an entry is accepted only when the ring is not full
//   Q3  a start grant goes only to an eligible head that is not rejected/done                      (rejected commands never reach a context)
//   Q4  run counters equal the number of started-and-not-done entries                              (ordering bits are exact)
//   Q5  a delivered entry is the oldest entry of its client and is done                            (in-order completion per client)
//   Q6  a presented completion is held with unchanged payload until accepted                       (SFB2 R4)
//   Q7  at most one grant per cycle, always to one client
//   H3  helper invariant: a locked delivery winner is a done head addressed to its port (makes Q5 inductive)
//   Q8  round robin: the granted client is the FIRST eligible head at or after the pointer (cyclically); Q10 the pointer moves past it
//       => a head that stays eligible is passed over by at most NC-1 grants
// =============================================================================
`ifdef SF_ATOMIC_PROPS
  // shadow of "started and not done" (shared by the formal environment and the assertions)
  reg [NC*QD-1:0] f_run;
  always @(posedge clk) begin
    if (!rst_n) f_run <= '0;
    else begin
      if (gnt_valid) f_run[32'(gnt_client)*QD + 32'(gnt_slot)] <= 1'b1;
      if (res_valid) f_run[32'(res_client)*QD + 32'(res_slot)] <= 1'b0;
    end
  end
`endif
`ifdef SF_ATOMIC_FORMAL_UNIT
  reg f_first = 1'b1;
  always @(posedge clk) f_first <= 1'b0;
  always @* begin
    if (f_first) assume(!rst_n); else assume(rst_n);
  end
`ifndef SF_Q_STRUCT_ONLY
  always @* if (!f_first) begin
    if (res_valid) assume(f_run[32'(res_client)*QD + 32'(res_slot)]);
    assume(32'(res_client) < NC);
  end
`endif
`endif
`ifdef SF_ATOMIC_PROPS
  reg f_pv;
  reg [CNTW-1:0] f_n;
  reg f_gq;
  reg [CLW-1:0] f_gc_q;
  integer f_j;
  reg f_seen;
  always @(posedge clk) begin f_pv <= rst_n; f_gq <= rst_n && gnt_valid; f_gc_q <= gnt_client; end
  always @* if (rst_n) begin
    for (int c = 0; c < NC; c++) begin
      // Q1
      assert((tl_p[c*PTW +: PTW] - hd_p[c*PTW +: PTW]) <= PTW'(QD));
      assert((is_p[c*PTW +: PTW] - hd_p[c*PTW +: PTW]) <= (tl_p[c*PTW +: PTW] - hd_p[c*PTW +: PTW]));
      assert((tl_p[c*PTW +: PTW] - is_p[c*PTW +: PTW]) <= PTW'(QD));
      // Q2
      if (in_fire[c]) assert(!full_r[c]);
    end
    // Q3 / Q7
    if (gnt_valid) begin
      assert(hd_valid_r[gnt_client] && elig[gnt_client]);
      assert(!done_q[32'(gnt_client)*QD + 32'(gnt_slot)]);
    end
  end
`ifndef SF_Q_STRUCT_ONLY
  // Q4: run counters = started-and-not-done (shadow count)
  always @* begin
    f_n = '0;
    if (rst_n && f_pv) begin
      for (int c = 0; c < NC; c++) begin
        f_n = '0;
        for (int s = 0; s < QD; s++) f_n = f_n + CNTW'(f_run[c*QD + s]);
        assert(run_q[c*CNTW +: CNTW] == f_n);
      end
    end
  end
`endif
  // Q8: no eligible head lies cyclically between the pointer (inclusive) and the granted client (exclusive)
  always @* begin
    f_j = 0;
    f_seen = 1'b0;
    if (rst_n && gnt_valid) begin
      for (int k = 0; k < NC; k++) begin
        f_j = 32'(sch_rr) + k;
        if (f_j >= NC) f_j = f_j - NC;
        if (f_j == 32'(gnt_client)) f_seen = 1'b1;                 // clients visited AFTER the winner are not constrained
        else if (!f_seen) assert(!(hd_valid_r[f_j] && elig[f_j]));  // every client visited BEFORE the winner is not an eligible head
      end
    end
  end
  // H3 (helper invariant, also asserted in simulation): a LOCKED delivery winner is a client whose head entry is done and addressed to that very port
  always @* if (rst_n) begin
    for (int d = 0; d < NC; d++) begin
      if (dl_lk_v[d]) begin
        assert(hd_done_r[32'(dl_lk_c[d*CLW +: CLW])]);
        assert(32'(dst_q[(32'(dl_lk_c[d*CLW +: CLW])*QD + 32'(hd_s[32'(dl_lk_c[d*CLW +: CLW])*PQW +: PQW]))*CLW +: CLW]) == d);
      end
    end
  end
  // Q10: the pointer moves past the winner
  always @(posedge clk) if (f_pv && rst_n && f_gq) assert(32'(sch_rr) == ((32'(f_gc_q) + 1) % NC));
  // Q5: the delivered entry is the oldest allocated entry of the client and is done
  always @* if (rst_n) for (int c = 0; c < NC; c++) if (pop_r[c]) begin
    assert(hd_p[c*PTW +: PTW] != tl_p[c*PTW +: PTW]);
    assert(done_q[c*QD + 32'(hd_s[c*PQW +: PQW])]);
  end
`ifndef SF_Q_STRUCT_ONLY
  // Q6: stability of a stalled completion
  reg [NC-1:0] f_stall_q;
  reg [NC*(TAGW+RIDW+CLW+64+1+4)-1:0] f_pl_q, f_pl;
  always @* for (int d = 0; d < NC; d++)
    f_pl[d*(TAGW+RIDW+CLW+64+1+4) +: (TAGW+RIDW+CLW+64+1+4)] = {rsp_tag[d*TAGW +: TAGW], rsp_rid[d*RIDW +: RIDW], rsp_src[d*CLW +: CLW], rsp_old[d*64 +: 64], rsp_succ[d], rsp_status[d*4 +: 4]};
  always @(posedge clk) begin f_stall_q <= rst_n ? (rsp_valid & ~rsp_ready) : '0; f_pl_q <= f_pl; end
  always @(posedge clk) if (f_pv && rst_n) for (int d = 0; d < NC; d++) if (f_stall_q[d]) begin
    assert(rsp_valid[d]);
    assert(f_pl[d*(TAGW+RIDW+CLW+64+1+4) +: (TAGW+RIDW+CLW+64+1+4)] == f_pl_q[d*(TAGW+RIDW+CLW+64+1+4) +: (TAGW+RIDW+CLW+64+1+4)]);
  end
`endif
`endif
