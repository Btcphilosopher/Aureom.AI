`ifndef F_COV
`ifndef SF_COVER_SEL
`define SF_COVER_SEL 0
`endif
// non-vacuity: with -DSF_COVER_SEL=n cover point n becomes assert(!cond); a counterexample then PROVES that the point is reachable
// under the environment assumptions.  Without the define nothing is asserted (SF_COVER_SEL = 0).
`define F_COV(n, c) if (`SF_COVER_SEL == n) assert(!(c));
`endif
// =============================================================================
// Formal properties of sf_atomic_lock_table   (`include d at the end of the module under SF_ATOMIC_FORMAL / SF_ATOMIC_SIMASSERT)
//
// ENVIRONMENT (the contract the engine keeps; each line is also asserted at engine level by fv_engine_props.svh or by the testbench):
//   EN1  an acquire targets a FREE entry and a key that is not held, and not held off by an ordinary write
//   EN2  a release targets a held entry; acquire and release never address the same entry in one cycle
//   EN3  a reservation is only registered for a key that no entry holds and that is held off by a PRESENTED ordinary write
// PROPERTIES
//   L1  no two valid entries hold the same key                                       (exclusive ownership of a granule)
//   L2  the entry written by an acquire is valid with that key one cycle later; a released entry is free one cycle later
//   L3  query results are exactly "some valid entry holds the key"
//   L4  a registered reservation implies that no entry holds the reserved key        (the reason the alternation cannot deadlock)
//   L5  an acquire for the reserved key clears the reservation
// =============================================================================
`ifdef SF_ATOMIC_FORMAL_UNIT
  reg f_first = 1'b1;
  always @(posedge clk) f_first <= 1'b0;
  always @* begin
    if (f_first) assume(!rst_n); else assume(rst_n);
  end
  // ---- environment
  always @* if (!f_first) begin
    assume(32'(acq_idx) < N);                       // indices address existing entries (an out-of-range index would be an unconstrained read)
    assume(32'(rel_idx) < N);
    if (acq_valid) begin
      assume(!v_q[acq_idx]);
      assume(!(hold_valid && (hold_key == acq_key)));
      for (int j = 0; j < N; j++) assume(!(v_q[j] && (k_q[j*KEYW +: KEYW] == acq_key)));
    end
    if (rel_valid) assume(v_q[rel_idx]);
    if (acq_valid && rel_valid) assume(acq_idx != rel_idx);
    if (resv_set) begin
      assume(hold_pres && (hold_key == resv_key_i));
      for (int j = 0; j < N; j++) assume(!(v_q[j] && (k_q[j*KEYW +: KEYW] == resv_key_i)));
    end
    if (hold_pres) assume(hold_valid);
  end
`endif
`ifdef SF_ATOMIC_FORMAL_UNIT
  always @* if (!f_first) begin
    `F_COV(1, |v_q)
    `F_COV(2, &v_q)
    `F_COV(3, resv_v_q)
    `F_COV(4, resv_set)
    `F_COV(5, |h_lock && hold_valid)
  end
`endif
`ifdef SF_ATOMIC_PROPS
  reg f_acq_q, f_rel_q, f_clr_q, f_pv;
  reg [IDXW-1:0] f_acq_i_q, f_rel_i_q;
  reg [KEYW-1:0] f_acq_k_q;
  reg            f_any;
  always @(posedge clk) begin
    f_acq_q <= acq_valid && rst_n; f_rel_q <= rel_valid && rst_n;
    f_acq_i_q <= acq_idx; f_rel_i_q <= rel_idx; f_acq_k_q <= acq_key;
    f_clr_q <= rst_n && acq_valid && resv_v_q && (acq_key == resv_k_q);
    f_pv <= rst_n;
  end
  // L2, L5
  always @(posedge clk) if (f_pv && rst_n) begin
    if (f_acq_q) assert(v_q[f_acq_i_q] && (k_q[f_acq_i_q*KEYW +: KEYW] == f_acq_k_q));
    if (f_rel_q && !(f_acq_q && f_acq_i_q == f_rel_i_q)) assert(!v_q[f_rel_i_q]);
    if (f_clr_q) assert(!resv_v_q);
  end
  // L1, L3, L4
  always @* begin
    f_any = 1'b0;
    if (rst_n) begin
      for (int a = 0; a < N; a++)
        for (int b = a + 1; b < N; b++)
          assert(!(v_q[a] && v_q[b] && (k_q[a*KEYW +: KEYW] == k_q[b*KEYW +: KEYW])));
      for (int h = 0; h < NH; h++) begin
        f_any = 1'b0;
        for (int j = 0; j < N; j++) if (v_q[j] && (k_q[j*KEYW +: KEYW] == h_key[h*KEYW +: KEYW])) f_any = 1'b1;
        assert(h_lock[h] == f_any);
      end
      if (resv_v_q) for (int j = 0; j < N; j++) assert(!(v_q[j] && (k_q[j*KEYW +: KEYW] == resv_k_q)));
    end
  end
`endif
