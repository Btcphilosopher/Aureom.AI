// =============================================================================
// Formal proof (ALL inputs, combinational): sf_atomic_alu == its specification, written here a third way (65-bit sums,
// sign-extended signed compare) and independent of the RTL's offset-binary construction.  Also proves that the unused upper half of a
// 32-bit operation never influences any output (noise instance), that 32-bit results have a zero upper half, and CAS invariants.
//   yosys: read_verilog -formal -sv ...; prep -top fv_alu; flatten; sat -verify -prove-asserts
// =============================================================================
`default_nettype none
module fv_alu (
  input wire [3:0]  op,
  input wire        wide,
  input wire [63:0] old_i, opd_i, cmp_i,
  input wire [31:0] n_old, n_opd, n_cmp
);
  wire [63:0] new1, new2;  wire wr1, wr2, su1, su2, ok1, ok2;
  sf_atomic_alu a1 (.op_i(op), .wide_i(wide), .old_i(old_i), .opd_i(opd_i), .cmp_i(cmp_i), .new_o(new1), .wr_o(wr1), .succ_o(su1), .op_ok_o(ok1));
  // same operation with arbitrary noise in the upper halves of every operand
  sf_atomic_alu a2 (.op_i(op), .wide_i(wide), .old_i({wide ? old_i[63:32] : n_old, old_i[31:0]}), .opd_i({wide ? opd_i[63:32] : n_opd, opd_i[31:0]}),
                    .cmp_i({wide ? cmp_i[63:32] : n_cmp, cmp_i[31:0]}), .new_o(new2), .wr_o(wr2), .succ_o(su2), .op_ok_o(ok2));

  reg [63:0] m, o, a, c, exp_new;
  reg signed [63:0] so, sa;
  reg [64:0] sum65;
  reg exp_wr, exp_su;
  always @* begin
    m = wide ? 64'hFFFF_FFFF_FFFF_FFFF : 64'h0000_0000_FFFF_FFFF;
    o = old_i & m;  a = opd_i & m;  c = cmp_i & m;
    so = wide ? $signed(old_i) : $signed({{32{old_i[31]}}, old_i[31:0]});
    sa = wide ? $signed(opd_i) : $signed({{32{opd_i[31]}}, opd_i[31:0]});
    sum65 = {1'b0, o} + {1'b0, a};
    exp_new = o; exp_wr = 1'b1; exp_su = 1'b1;
    case (op)
      4'd1: exp_new = a;
      4'd2: exp_new = sum65[63:0] & m;
      4'd3: exp_new = o & a;
      4'd4: exp_new = o | a;
      4'd5: exp_new = o ^ a;
      4'd6: exp_new = (so < sa)  ? o : a;
      4'd7: exp_new = (so >= sa) ? o : a;            // ties: both candidates equal
      4'd8: exp_new = (o < a)  ? o : a;
      4'd9: exp_new = (o >= a) ? o : a;
      4'd10: begin exp_su = (o == c); exp_wr = exp_su; exp_new = exp_su ? a : o; end
      default: begin exp_su = 1'b0; exp_wr = 1'b0; end
    endcase
    assert(ok1 == (op >= 4'd1 && op <= 4'd10));
    if (ok1) begin
      assert(new1 == exp_new);
      assert(wr1 == exp_wr);
      assert(su1 == exp_su);
      assert(wide || (new1[63:32] == 32'd0));
      if (op == 4'd10) assert(wr1 == su1);
      if (op != 4'd10) assert(wr1 && su1);
      // the unused upper half of a 32-bit operation is ignored
      assert(new2 == new1 && wr2 == wr1 && su2 == su1 && ok2 == ok1);
    end else begin
      assert(!wr1 && !su1);
    end
  end
endmodule
