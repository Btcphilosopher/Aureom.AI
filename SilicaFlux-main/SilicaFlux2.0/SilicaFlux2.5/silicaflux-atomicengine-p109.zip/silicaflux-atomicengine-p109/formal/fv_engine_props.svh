`ifndef F_COV
`ifndef SF_COVER_SEL
`define SF_COVER_SEL 0
`endif
// non-vacuity: with -DSF_COVER_SEL=n cover point n becomes assert(!cond); a counterexample then PROVES that the point is reachable
// under the environment assumptions.  Without the define nothing is asserted (SF_COVER_SEL = 0).
`define F_COV(n, c) if (`SF_COVER_SEL == n) assert(!(c));
`endif
// =============================================================================
// Formal / simulation properties of sf_atomic_engine -- ATOMICITY, EXCLUSIVE UPDATE AND LINEARISATION POINT
//
// ENVIRONMENT (formal only)   cmd and ordinary requests obey R2; configuration is constant; the memory answers every accepted
//   request exactly once, in order, with the id and type of the request (data and status are FREE: errors are covered);
//   rsp_ready / o_rsp_ready / quiesce / guard verdicts are free.
// PROPERTIES
//   X1  EXCLUSIVE UPDATE   an ordinary write is never accepted by the memory while a context holds the lock of its granule
//   X2  every memory request of a context is made under THAT context's lock, on the granule of its own address
//   X3  lock bookkeeping   a context holds a lock exactly when its flag says so; busy contexts hold their lock; no two share a key
//   X4  READ-BEFORE-WRITE  a context's write request exists only after its read response was consumed without error, and only in
//       the write state; a context never writes after a failed read                         (no write of a failed / denied operation)
//   X5  LINEARISATION      the commit event of a writing operation coincides with the acceptance of its write request and happens at
//       most once per operation; the event of a non-writing operation (failed CAS) coincides with its read response
//   X6  (queue Q3) no operation is started from a rejected entry: a rejected command is stored DONE, never granted, takes no lock and makes no
//       memory request -- proved on the queue (fv_queue_props.svh Q3) and visible here as X2/X4 (every memory request belongs to a granted context)
//   X7  after a reset every context is idle, no lock is held, the queues are empty                    (SF_FORMAL_RESET harness)
// =============================================================================
`ifdef SF_ATOMIC_FORMAL
  reg f_first = 1'b1;
  always @(posedge clk) f_first <= 1'b0;
  always @* begin
`ifdef SF_FORMAL_RESET
    if (f_first) assume(!rst_n);
`else
    if (f_first) assume(!rst_n); else assume(rst_n);
`endif
  end
  // constant configuration
  reg [AW-1:0] f_wb_q, f_wl_q, f_cb_q, f_cl_q;
  reg [NC*ND-1:0] f_dm_q; reg [NC*NC-1:0] f_da_q; reg [1:0] f_ap_q;
  always @(posedge clk) begin f_wb_q <= win_base; f_wl_q <= win_limit; f_cb_q <= coh_base; f_cl_q <= coh_limit; f_dm_q <= port_dom_mask; f_da_q <= dest_allow; f_ap_q <= atom_prot_i; end
  always @* if (!f_first) begin
    assume(win_base == f_wb_q); assume(win_limit == f_wl_q); assume(coh_base == f_cb_q); assume(coh_limit == f_cl_q);
    assume(port_dom_mask == f_dm_q); assume(dest_allow == f_da_q); assume(atom_prot_i == f_ap_q);
    assume(win_base[2:0] == 3'd0); assume(win_limit[2:0] == 3'd0);
  end
  // R2 on the command ports
  reg [NC-1:0] f_cs_q;
  reg [NC*(4+AW+64+64+2+RIDW+TAGW+DOMW+CLW+2)-1:0] f_cpl_q, f_cpl;
  localparam int CPL = 4+AW+64+64+2+RIDW+TAGW+DOMW+CLW+2;
  always @* for (int c = 0; c < NC; c++)
    f_cpl[c*CPL +: CPL] = {cmd_op[c*4 +: 4], cmd_addr[c*AW +: AW], cmd_opd[c*64 +: 64], cmd_cmp[c*64 +: 64], cmd_width[c*2 +: 2], cmd_rid[c*RIDW +: RIDW],
                           cmd_tag[c*TAGW +: TAGW], cmd_dom[c*DOMW +: DOMW], cmd_dest[c*CLW +: CLW], cmd_aq[c], cmd_rl[c]};
  always @(posedge clk) begin f_cs_q <= rst_n ? (cmd_valid & ~cmd_ready) : '0; f_cpl_q <= f_cpl; end
  always @* if (!f_first) for (int c = 0; c < NC; c++) if (f_cs_q[c]) begin assume(cmd_valid[c]); assume(f_cpl[c*CPL +: CPL] == f_cpl_q[c*CPL +: CPL]); end
  // R2 on the ordinary port
  reg f_os_q; reg [AW+3+64+8+OIDW+2:0] f_opl_q;
  wire [AW+3+64+8+OIDW+2:0] f_opl = {o_req_we, o_req_addr, o_req_size, o_req_wdata, o_req_be, o_req_id, o_req_prot};
  always @(posedge clk) begin f_os_q <= rst_n && o_req_valid && !o_req_ready; f_opl_q <= f_opl; end
  always @* if (!f_first && f_os_q) begin assume(o_req_valid); assume(f_opl == f_opl_q); end
  // memory behaviour: in-order, one response per accepted request, ids and types echoed; the response never appears in the acceptance cycle
  reg [3:0] f_mh, f_mt;
  reg [MIDW-1:0] f_mid [0:7];
  reg            f_mwe [0:7];
  wire f_macc = m_req_valid && m_req_ready;
  wire f_mrsp = m_rsp_valid && m_rsp_ready;
  always @(posedge clk) begin
    if (f_first || !rst_n) begin f_mh <= 4'd0; f_mt <= 4'd0; end
    else begin
      if (f_macc) begin f_mid[f_mt[2:0]] <= m_req_id; f_mwe[f_mt[2:0]] <= m_req_we; f_mt <= f_mt + 4'd1; end
      if (f_mrsp) f_mh <= f_mh + 4'd1;
    end
  end
  always @* if (!f_first) begin
    if (m_rsp_valid) begin assume(f_mt != f_mh); assume(m_rsp_id == f_mid[f_mh[2:0]]); assume(m_rsp_we == f_mwe[f_mh[2:0]]); end
    assume((f_mt - f_mh) <= 4'd6);
  end
  // a response, once valid, stays valid with unchanged payload until accepted (SFB2 R4)
  reg f_rs_q; reg [63:0] f_rd_q; reg [MIDW-1:0] f_ri_q; reg [3:0] f_rst_q;
  always @(posedge clk) begin f_rs_q <= rst_n && m_rsp_valid && !m_rsp_ready; f_rd_q <= m_rsp_rdata; f_ri_q <= m_rsp_id; f_rst_q <= m_rsp_status; end
  always @* if (!f_first && f_rs_q) begin assume(m_rsp_valid); assume(m_rsp_rdata == f_rd_q); assume(m_rsp_id == f_ri_q); assume(m_rsp_status == f_rst_q); end
`endif
`ifdef SF_ATOMIC_FORMAL
  // non-vacuity: the environment assumptions must still allow real activity
  always @* if (!f_first) begin
    `F_COV(1, ev_ord_wr)                                              // an ordinary write reaches the memory
    `F_COV(2, ev_ord_blk)                                             // an ordinary write is held back by a lock
    `F_COV(3, ev_acc_atomic && m_req_we)                              // an atomic write is accepted
    `F_COV(4, |ev_c_valid && |ev_c_wrote)                             // a linearisation point with a write
    `F_COV(5, |ev_c_valid && ~|ev_c_wrote)                            // a linearisation point without a write (failed CAS)
    `F_COV(6, |(rsp_valid & rsp_ready))                               // a completion is delivered
    `F_COV(7, hold_valid && |h_lock)                                  // hold-off while a lock is held
    `F_COV(8, resv_v)                                                 // a reservation is registered
  end
`endif
`ifdef SF_ATOMIC_PROPS
  reg [NCTX-1:0] f_rdok;
  always @(posedge clk) begin
    if (!rst_n) begin f_rdok <= '0; end
    else for (int i = 0; i < NCTX; i++) begin
      if (gnt_valid && free_idx == CXW'(i)) f_rdok[i] <= 1'b0;
      if (cx_st[i*3 +: 3] == CX_RW && a_rsp_valid[i] && !a_rsp_err) f_rdok[i] <= 1'b1;
    end
  end
  always @* if (rst_n) begin
    // X1
    if (ev_ord_wr) assert(!lk_o_lock);
    for (int i = 0; i < NCTX; i++) begin
      // X2
      if (a_req_valid[i]) assert(lk_valid[i] && (lk_key[i*KEYW +: KEYW] == cx_addr[i*AW + LOCK_GRAN +: KEYW]));
      // X3
      assert(cx_lkheld[i] == lk_valid[i]);
      if (cx_st[i*3 +: 3] != CX_IDLE) assert(lk_valid[i]);
      for (int j = i + 1; j < NCTX; j++) assert(!(lk_valid[i] && lk_valid[j] && (lk_key[i*KEYW +: KEYW] == lk_key[j*KEYW +: KEYW])));
      // X4
      if (a_req_valid[i] && a_req_we[i]) begin assert(cx_st[i*3 +: 3] == CX_WR); assert(f_rdok[i]); end
      if (cx_st[i*3 +: 3] == CX_WR || cx_st[i*3 +: 3] == CX_WW) assert(f_rdok[i]);
      // X5
      if (ev_c_valid[i] && ev_c_wrote[i] && !ev_c_coh[i]) assert(a_req_ready[i] && cx_st[i*3 +: 3] == CX_WR);
      if (ev_c_valid[i] && !ev_c_wrote[i] && !ev_c_coh[i]) assert(a_rsp_valid[i] && cx_st[i*3 +: 3] == CX_RW);
    end
  end
`endif
`ifdef SF_ATOMIC_PROPS
`ifdef SF_FORMAL_RESET
  // X7: one reset edge empties everything
  reg f_rq;
  always @(posedge clk) f_rq <= !rst_n;
  always @* if (!f_first && f_rq) begin                // (f_rq is unconstrained in the very first cycle, before any reset edge has been applied)
    assert(ctx_all_idle);
    assert(lk_valid == {NCTX{1'b0}});
    assert(q_empty);
  end
`endif
`endif
