# Third-party provenance

Every file in `third_party/` is a byte-identical copy of a file inside a project archive of the Aureom.AI
repository. Archive paths are relative to `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. **No vendored file
is modified.**

`SHA256SUMS` lists all 404 files. When they were vendored, each hash was checked against the same file extracted
from its origin archive: 0 differences. `scripts/regress.py` (step `hashes`) re-verifies the list.

| Directory | Origin archive | Used for |
|---|---|---|
| `silicaflux-testcore/rtl/testcore` | `silicaflux-testcore-p07.zip` (`rtl/testcore`) | TAP, JTAG CDC bridge, register page, test-mode controller, MBIST engine, bank mux, ownership controller (Project 07 TestCore r2) |
| `silicaflux-testcore/pdk` | `silicaflux-testcore-p07.zip` (`third_party/pdk`) | sky130hd liberty and LEF: open SkyWater PDK views (Apache-2.0) that P07 copied from the OpenROAD test data |
| `silicaflux-sramgrid/rtl`, `gen` | `silicaflux-sramgrid-p33.zip` | P33 SRAM grid (group 0 of the system testbench), configurations `sg_min4` / `sg_hier` |
| `silicaflux-sramgrid/physical` | `silicaflux-sramgrid-p33.zip` | macro abstracts parsed from the vendor LEF, macro placements (physical report) |
| `silicaflux-sramgrid/reports` | `silicaflux-sramgrid-p33.zip` | macro connectivity of the synthesized netlists (macro test pins) |
| `silicaflux-sramlib/rtl` | `silicaflux-sramgrid-p33.zip` (`third_party/silicaflux-sramlib`) | SRAM Wrapper Library: generic models with fault hooks, bank controller |
| `silicaflux-memorycore/rtl` | `silicaflux-dietop-p31.zip` (`third_party/silicaflux-memorycore`) | MemoryCore `sfmem_banked` (groups 1 and 2) |
| `silicaflux-ras/rtl` | `silicaflux-ras-project26.zip` | RAS Project 26 event engine (testbench), SECDED codec (grid) |
| `silicaflux-clocktree/rtl` | `silicaflux-clocktree-p35.zip` | Project 35 clock / reset tree (clock-reset integration test) |
| `silicaflux-dietop` | `silicaflux-dietop-p31.zip` | Project 31 die RTL subset listed by `rtl/files_die.f` (scan-planning register counts) |

The SRAM library copies in P31 and P33 are identical for every file they share. So are the RAS SECDED files
vendored by P33 and those in P26. One copy of each is kept.
