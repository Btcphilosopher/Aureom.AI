`include "sftc_defs.svh"
// =============================================================================
// Formal harness: sfta_seq (2 groups), every group status free.
// =============================================================================
`default_nettype none
module fv_seq (
  input wire logic        clk,
  input wire logic        start, abort, clear, parallel, stop_on_fail, mbist_enable, mode_exit,
  input wire logic [1:0]  groups,
  input wire logic [3:0]  wdog_limit_in,
  input wire logic [1:0]  g_busy, g_owned_all, g_acq_blocked, g_released, g_owner_fault, g_refused,
  input wire logic [5:0]  g_last
);
  logic rst_n = 1'b0;
  always @(posedge clk) rst_n <= 1'b1;
  wire [31:0] wdog_limit = {28'd0, wdog_limit_in};
  logic [1:0] seq_sel, seq_acq, seq_start, seq_abort, seq_clear, fin, ev_tmo, ev_ref;
  logic [7:0] result;
  logic [5:0] ev_ph;
  logic [31:0] cycles;
  logic busy, done, pass, fail, err, ev_sr, ev_done;
  logic [2:0] cg, cp;
  sfta_seq #(.NG(2)) dut (
    .clk, .rst_n, .start, .abort, .clear, .parallel, .stop_on_fail, .groups, .wdog_limit, .mbist_enable, .mode_exit,
    .g_busy, .g_last, .g_owned_all, .g_acq_blocked, .g_released, .g_owner_fault, .g_refused,
    .seq_sel, .seq_acq, .seq_start, .seq_abort, .seq_clear, .busy, .done, .pass, .fail, .err,
    .cur_group(cg), .cur_phase(cp), .result, .fin_mask(fin), .cycles, .ev_timeout(ev_tmo),
    .ev_timeout_phase(ev_ph), .ev_refused(ev_ref), .ev_seq_refused(ev_sr), .ev_seq_done(ev_done)
  );
  // properties S1..S6 are embedded in sfta_seq (SFTC_ASSERT, compiled with -DFORMAL);
  // S7: START is issued only after the group was owned by test
  logic p_v;
  always @(posedge clk) p_v <= rst_n;
  always @(posedge clk) begin
    if (rst_n && p_v) begin
      if (seq_start[0]) assert ($past(g_owned_all[0], 2));
      if (seq_start[1]) assert ($past(g_owned_all[1], 2));
      if (done) assert (!busy);
    end
  end
  always @(posedge clk) if (rst_n) begin
    `SFTC_REACH(0, done && pass && fin == 2'b11)
    `SFTC_REACH(1, |ev_tmo)
    `SFTC_REACH(2, seq_acq == 2'b11)
    `SFTC_REACH(3, done && result[3:0] == 4'd8)
  end
endmodule
`default_nettype wire
