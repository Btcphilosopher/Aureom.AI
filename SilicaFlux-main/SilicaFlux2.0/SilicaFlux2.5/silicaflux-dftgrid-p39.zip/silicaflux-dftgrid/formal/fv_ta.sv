`include "sftc_defs.svh"
// =============================================================================
// Formal harness: silicaflux_test_access, small 2-group configuration, every
// input free (JTAG pins, system bus incl. privilege, lifecycle, tester pins,
// functional side, memory read data); clk and tck independent (multiclock).
// Proves the lifecycle access gate at the chip boundary together with every
// assertion embedded in the test-access RTL and in the reused TestCore blocks
// (compiled in with -DFORMAL), i.e. the composition respects their contracts.
// =============================================================================
`default_nettype none
module fv_ta (
  input wire logic        clk, tck,
  input wire logic        tms, tdi, trst_pin,
  input wire logic        lc_valid,
  input wire logic [3:0]  lc_state,
  input wire logic        sb_debug_en, sb_test_mode_en, otp_ift_en,
  input wire logic        scan_mode_pin, scan_en_pin, test_rst_n_pin, cpu_halted,
  input wire logic        s_req, s_we, s_priv,
  input wire logic [11:0] s_addr,
  input wire logic [31:0] s_wdata,
  input wire logic [1:0]  quiesce_ack, f_busy, f_req, mem_init_busy,
  input wire logic [15:0] tst_rdata
);
  logic rst_n = 1'b0, trst_n = 1'b0;
  always @(posedge clk) rst_n <= 1'b1;
  always @(posedge tck) trst_n <= trst_pin | trst_n;
  logic tdo, tdo_oe, s_gnt, s_err, dft_test_mode, dft_icg_te, dft_scan_en, dft_test_rst_n, dft_mem_inhibit;
  logic dbg_allow, jtag_mode, diag_mode, ras_ev_valid, ras_ev_addr_v, ras_ev_corr, irq, test_done, test_pass, test_fail;
  logic [31:0] s_rdata, ras_ev_addr, ras_ev_info;
  logic [3:0] ras_ev_type;
  logic [2:0] mode;
  logic [1:0] quiesce_req, f_block, mem_ready, tst_active, tst_ce, tst_we, mbist_clk_req;
  logic [3:0] tst_sel;
  logic [3:0] tst_addr;
  logic [7:0] tst_wdata;
  silicaflux_test_access #(
    .NG(2), .MAXNB(2), .MAXSW(4), .MAXRAW(2),
    .G_NB({8'd1, 8'd2}), .G_SW({16'd3, 16'd4}), .G_DEPTH({24'd4, 24'd4}), .G_LAT({4'd2, 4'd1}),
    .G_INIT({4'd1, 4'd2}), .G_INIT_ON_RESET(2'b10), .G_INIT_WORD({4'b0101, 4'b0000}), .G_KIND({4'd1, 4'd0}),
    .G_PIPE_REQ(2'b10), .G_PIPE_RSP(2'b00), .LOG_DEPTH(1), .CNT_W(4), .ENG_TIMEOUT(8), .OWN_TIMEOUT(4)
  ) dut (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .clk, .rst_n,
    .lc_valid, .lc_state, .sb_debug_en, .sb_test_mode_en, .otp_ift_en,
    .scan_mode_pin, .scan_en_pin, .test_rst_n_pin, .cpu_halted,
    .s_req, .s_we, .s_priv, .s_addr, .s_wdata, .s_gnt, .s_rdata, .s_err,
    .quiesce_req, .quiesce_ack, .f_busy, .f_req, .f_block, .mem_init_busy, .mem_ready,
    .tst_active, .tst_sel, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata,
    .dft_test_mode, .dft_icg_te, .dft_scan_en, .dft_test_rst_n, .dft_mem_inhibit, .mbist_clk_req,
    .dbg_allow, .jtag_mode, .diag_mode,
    .ras_ev_valid, .ras_ev_type, .ras_ev_addr, .ras_ev_addr_v, .ras_ev_info, .ras_ev_corr,
    .irq, .mode, .test_done, .test_pass, .test_fail
  );
  wire dev_ok   = lc_valid && lc_state == 4'd0 && sb_debug_en && sb_test_mode_en;
  wire field_ok = lc_valid && (lc_state == 4'd1 || lc_state == 4'd2 || lc_state == 4'd3) && !sb_debug_en &&
                  !sb_test_mode_en && otp_ift_en;
  logic p_v = 1'b0;
  always @(posedge clk) p_v <= rst_n;
  always @(posedge clk) begin
    if (rst_n) begin
      assert (!dft_test_mode || dev_ok);                                // G1 scan mode only in a consistent DEV lifecycle
      assert (!dft_scan_en || dft_test_mode);                           // G2 scan enable only inside scan mode
      assert (!dbg_allow || dev_ok);                                    // G3 debug only in DEV
      assert (!(jtag_mode || diag_mode) || dev_ok);                     // G4 JTAG_ACCESS / DIAGNOSTIC only in DEV
      // G5 MBIST mode only with lifecycle permission (the registered mode status lags a permission
      //    loss by one cycle; the MBIST hard enable itself is gated combinationally)
      if (p_v && mode == 3'd2) assert ($past(dev_ok || field_ok));
      assert (!(|tst_ce) || (|tst_active));                             // G6 raw memory access only in test ownership
      assert (!tst_ce[0] || tst_active[0]);
      assert (!tst_ce[1] || tst_active[1]);
      // G7 an unprivileged write outside DEV completes with an error (never forwarded)
      if (s_req && s_we && !s_priv && !dev_ok && s_gnt) assert (s_err);
      // G8 an unprivileged read of a group page outside DEV completes with an error
      if (s_req && !s_we && !s_priv && !dev_ok && s_gnt && s_addr[11:9] != 3'd0) assert (s_err);
    end
  end
  always @(posedge clk) if (rst_n) begin
    `SFTC_REACH(0, mode == 3'd2)
    `SFTC_REACH(1, |tst_ce)
    `SFTC_REACH(2, dft_test_mode)
  end
endmodule
`default_nettype wire
