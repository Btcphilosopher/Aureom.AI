`include "sftc_defs.svh"
// =============================================================================
// Formal harness: sfta_group_collar, every input free (engine, ownership,
// functional side, memory read data).  INIT_MODE selected by define:
//   default : collar sweep (INIT_MODE 1) with INIT_ON_RESET
//   SELF    : memory self-initialisation (INIT_MODE 2)
// =============================================================================
`default_nettype none
module fv_collar (
  input wire logic       clk,
  input wire logic [1:0] b_req,
  input wire logic       b_we,
  input wire logic [1:0] b_addr,
  input wire logic [2:0] b_wdata,
  input wire logic [1:0] acq_req,
  input wire logic       fault_clear, mbist_busy, quiesce_ack, f_busy, f_req, mem_init_busy,
  input wire logic [5:0] tst_rdata
);
`ifdef SELF
  localparam int MODE = 2, IOR = 0;
`else
  localparam int MODE = 1, IOR = 1;
`endif
  logic rst_n = 1'b0;
  always @(posedge clk) rst_n <= 1'b1;
  always @(*) assume ($onehot0(b_req));               // the TestCore bank mux selects one bank at a time

  logic [1:0] b_gnt, b_rvalid, b_rerr, owned, owner_dirty;
  logic [5:0] b_rdata, owner_state;
  logic ev_fault, ev_intrusion, ev_reinit, quiesce_req, f_block, mem_ready, tst_active, tst_ce, tst_we;
  logic [1:0] tst_sel, tst_addr;
  logic [2:0] tst_wdata, grp_state;
  logic grp_dirty, sweeping, released, clk_req;
  sfta_group_collar #(.NB(2), .SW(3), .DEPTH(4), .LAT(2), .INIT_MODE(MODE), .INIT_WORD(3'b101),
                      .INIT_ON_RESET(IOR), .OWN_TIMEOUT(12), .MAX_W(3)) dut (
    .clk, .rst_n, .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr,
    .acq_req, .fault_clear, .mbist_busy, .owner_state, .owned, .owner_dirty, .ev_fault, .ev_intrusion,
    .ev_reinit, .quiesce_req, .quiesce_ack, .f_busy, .f_req, .f_block, .mem_init_busy, .mem_ready,
    .tst_active, .tst_sel, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata,
    .grp_state, .grp_dirty, .sweeping, .released, .clk_req
  );
  wire eng = tst_ce && !sweeping;
  logic [2:0] p_st; logic p_v, p_eng_rd0, p_eng_rd1, pp_eng_rd0, pp_eng_rd1;
  always @(posedge clk) begin
    p_st <= grp_state; p_v <= rst_n;
    p_eng_rd0 <= eng && !tst_we && tst_sel[0]; p_eng_rd1 <= eng && !tst_we && tst_sel[1];
    pp_eng_rd0 <= p_eng_rd0; pp_eng_rd1 <= p_eng_rd1;
  end
  always @(posedge clk) begin
    if (rst_n) begin
      assert (!tst_ce || tst_active);                                   // C1 raw access only with tst_active
      assert (!eng || grp_state == 3'd4);                               // C2 engine access only in TEST_ACTIVE
      assert (!(grp_state == 3'd3 || grp_state == 3'd4 || grp_state == 3'd5) || f_block);  // C3 test owns => functional blocked
      assert (!(sweeping && |b_gnt && |b_req));                         // C4 sweep and engine never together
      assert (!eng || $onehot(tst_sel));                                // C5 engine access selects exactly one bank
      if (p_v) begin
        assert (!(b_rvalid[0]) || pp_eng_rd0);                          // C6 response only for a read LAT cycles ago
        assert (!(b_rvalid[1]) || pp_eng_rd1);
        if (grp_state == 3'd0 && p_st == 3'd6) assert (!$past(grp_dirty)); // C7 release never with undefined content
      end
      assert (!ev_reinit);                                              // C8 REINIT_REQUIRED cannot occur
      assert (!(grp_state == 3'd0) || !tst_ce || sweeping);             // C9 NORMAL: only an initialisation sweep uses the bus
`ifndef SELF
      assert (mem_ready || tst_active);                                 // C10 reset initialisation keeps the memory in test
`endif
      assert (!(tst_active) || clk_req || (grp_state == 3'd0 && !sweeping));  // C11 clock requested while the bus is owned
    end
  end
  always @(posedge clk) if (rst_n) begin
    `SFTC_REACH(0, grp_state == 3'd4 && eng && !tst_we)
    `SFTC_REACH(1, p_v && grp_state == 3'd0 && p_st == 3'd6)
    `SFTC_REACH(2, ev_fault)
    `SFTC_REACH(3, ev_intrusion)
  end
endmodule
`default_nettype wire
