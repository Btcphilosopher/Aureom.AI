# 00 — Repository audit: test infrastructure, implemented vs planned

Scope: every SilicaFlux project archive in the repository that touches test, memory, clocking, power, RAS or
security. The archives were extracted and read. Where a claim mattered, the project's own regression was
re-run (`reports/independent/`).

## 1. What exists

| Area | Where (archive in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`) | Implemented | Verified by its project | Status for Project 39 |
|---|---|---|---|---|
| **TestCore r2 (P07)** | `silicaflux-testcore-p07.zip` | TAP (16 states, IR 5 bit, IDCODE/BYPASS/TC_REG/TC_STATUS), TCK→clk register bridge, register file, test-mode controller, 6-algorithm March MBIST engine, fail log, bank mux, per-bank ownership controller, SRAM-library wrappers | simulation (TAP 51 776 checks), MBIST campaign of 15 320 RTL cases against a golden model, 6 SymbiYosys proofs, OpenROAD scan insertion on the TestCore block, an in-house ATPG experiment | **Reused, unmodified** (15 files). Re-run here: TAP **51 776 checks PASS**, quick MBIST campaign **9 627 cases, 0 mismatches** |
| TestCore r1 (`tc_top`) | `silicaflux-testcore.zip` | TAP + boundary-scan register (`tc_bsr`), LBIST demo, clock-root mux and reset control, MBIST collar | its own TBs | **Not used.** Its clock-root mux (`assign clk_o = sel ? clk1 : clk0`) is glitch-free only by protocol (P35 finding F-03). That is the reason P31 refuses `TESTCORE_EN = 1`. r2 has no clock mux, so the blocker is gone |
| MBIST controllers | P07 `silicaflux_mbist`; SRAM library `sram_mbist_march` (demonstration March C−) | P07: 6 algorithms, timeouts, fail log, scrub | P07 campaign | P07 engine used per memory group |
| SRAM wrappers / test ports | SRAM Wrapper Library (`sram_bank_controller`, `sram_sp`, generic / FPGA / ASIC back-ends); P33 `silicaflux_sram_macro_wrapper` | raw test bus `tst_active / tst_sel / tst_ce / tst_we / tst_addr / tst_wdata → tst_rdata` (fixed latency); generic models with fault hooks (SA0/1, TF↑/↓, CFid, address alias) | P33 wrapper vs vendor models 13/13 | **Used as the MBIST attachment point** (one contract for both families) |
| SRAM grid (P33) | `silicaflux-sramgrid-p33.zip` | distributed banks, SECDED, MBIST bus on raw stored words, init after test, real IHP macro placements | 232/232 runs | Group 0 of the verified configuration |
| Shared SRAM (P31 die) | `silicaflux-dietop-p31.zip` → MemoryCore `sfmem_banked` | parity slices; P31 drives the test port with a **post-reset initialisation sweep** | P31 regressions | Groups 1–2; the collar's after-reset sweep replaces P31's (same port) |
| JTAG pins at the die | P31 `silicaflux_die_top` | `tck_i/tms_i/tdi_i/trst_ni/tdo_o/tdo_oe_o` reserved, tied inactive | — | Driven by this block on integration |
| Boundary scan | r1 `tc_bsr` only | BSR model | r1 TB | **Not present in the die.** No pad ring or I/O library exists. EXTEST/SAMPLE are reserved (→ BYPASS) |
| DFT / ATPG scripts | P07 `asic/dft/run_scan.tcl`, `check_chains.py`, in-house ATPG (Python) | OpenROAD scan insertion on the TestCore block (8 chains, sky130hd) | gate-level continuity | Reused approach for this block (17 chains). P07's ATPG is a research experiment on TestCore only |
| Clock / reset (P35) | `silicaflux-clocktree-p35.zip` | DFT inputs `test_mode_i`, `test_rst_ni`, `test_en_i`; branch clock requests `br_clk_req_i`; library ICG with SE pin | P35 TBs, CDC checks | Driven by this block; integration verified (`tb_ta_clktree`) |
| Power states (P36) | `silicaflux-powerfabric-p36.zip` | `test_mode_i` reset bypass; `mbist_req_o / mbist_allow_o / mbist_done_i / mbist_fail_i` for **power-up MBIST**, but only in the FUTURE power-gating configuration (needs switch / retention cells; refused at elaboration for IHP) | P36 TBs | Planned interface: a power-up MBIST request maps to a sequencer START of the region's group (docs/07) |
| RAS (P26) | `silicaflux-ras-project26.zip` | event engine with severity, log, counters; **no MBIST event type** (types are a firmware contract, append-only) | P26 regressions | Test access uses existing types on its own source port (MEM_UE / TIMEOUT / ILLEGAL_OP / RECOVERY) |
| Secure boot (P28) | `silicaflux-secureboot-p28.zip` | lifecycle DEV / PROV / PROD / RECOVERY / INVALID from a fuse model; `debug_en = test_mode_en = DEV`. Its docs state: "no scan-chain or BIST access control: a real tape-out must tie scan enable/mode to the lifecycle in the DFT flow" | P28 TBs | **Gap closed here**: lifecycle policy for JTAG, debug, scan and MBIST |
| Vector / tensor / DMA / DataFabric / ControlCore | P31 die and vendored blocks | logic + SPMs / buffers; no scan, no test port on most memories | their projects | Scan **planned** from Yosys register counts (docs/06). Memories without a raw test bus are not connected (docs/05) |

## 2. Implemented vs planned (before Project 39)

| Function | Implemented | Planned / missing |
|---|---|---|
| JTAG TAP | yes (P07 r2, verified; not IEEE 1149.1 conformance-tested) | boundary-scan register, BSDL, conformance |
| MBIST engine | yes (P07) | none at chip level (no die integration) |
| MBIST ↔ SRAM grid / shared SRAM | test ports exist; P33 TB uses the library's demonstration controller | **chip-level controller: missing**. Added here |
| Test-mode control | P07 controller (single TestCore) | **chip-level, lifecycle-gated: missing**. Added here |
| Security of test / debug | P28 gates its own debug port | scan / MBIST lifecycle gating: **missing**. Added here |
| Scan | P07 TestCore block only | chip partitions: none. Planned here (Yosys counts); this block inserted |
| ATPG | P07 in-house experiment | production ATPG: none (tools not available) |
| Test status to RAS / host | — | added here |

## 3. Defects and findings recorded during this project

| # | Finding | Where | Consequence / action |
|---|---|---|---|
| F1 | P31 refuses `TESTCORE_EN = 1` because TestCore **r1** owns the clock root | P31 `ras_test_subsystem.sv` | r2 (P07) has no clock mux and runs on the memory clock: used instead |
| F2 | The MBIST bus of the P33 grid and of `sram_bank_controller` is **group-wide** (`tst_active` stops all functional issue of the memory) | P33 / SRAM library | Ownership is per group, not per bank (one owner per collar). Documented in docs/03 |
| F3 | P31 uses the shared-SRAM test port for its post-reset initialisation sweep | P31 `memory_subsystem.sv` | The collar provides the same sweep (`G_INIT_ON_RESET`) so the port has one driver |
| F4 | A raw-zero scrub leaves **invalid parity / ECC** (MemoryCore parity: zero data needs parity 1). TestCore's scrub writes all-zero raw words | P07 engine vs MemoryCore | Collar re-initialises with a **valid** stored word (`G_INIT_WORD`); the grid self-initialises. Verified: no parity / ECC error after any session |
| F5 | TestCore `TEST_BANK_ID` read after a run returns the bank-loop counter (0 when the last selected bank was the highest-numbered), not "last tested" | P07 `silicaflux_mbist` / `sftc_regs` | Use `BANKS_TESTED` / `BANKS_FAILED`; recorded in the register map |
| F6 | OpenROAD 26Q3 numbers `scan_in_k` / `scan_out_k` in **lexicographic** order of chain names (chain_10 → port 2). With ≤ 10 chains (P07) this is invisible | OpenROAD DFT | First gate-level run of this block failed for 4 chains; the checker now maps chains to ports structurally. Reported in docs/06 |
| F7 | P26 has no MBIST / test event type and types are append-only | P26 | Test access reports on its own source port with existing types; info word carries the class |
| F8 | P28 lifecycle state lives in scannable flops (`lc_eff_q`). If they are scanned, scan entry could change the permission while shifting | P28 | Test-access permission decode is combinational. Readiness item S-3: exclude the P28 lifecycle flops from scan |
| F9 | IHP SRAM macros have 79 to 156 macro-BIST pins each; all are tied off in the P33 netlists (`A_BIST_EN = 0`, `A_DLY = 1`) | P33 connectivity | MBIST uses the wrapper test port. Macro BIST is not used (docs/10) |
| F10 | First testbench version: TB-side reset initialised low, no edge → TAP stayed X | this project's TB | Fixed in the TB (resets start high; TRST* modelled as TRST*·POR) |
| F11 | Formal: the sequencer watchdog limit could be re-programmed mid-sequence | `sfta_seq` (this project) | Limit latched at START, like the other sequence configuration; proven (S7) |

## 4. Independent re-runs (reports/independent/)

| Run | Result |
|---|---|
| P07 `tb_jtag_tap` (Icarus 12) | `TB_JTAG_RESULT PASS checks=51776 errors=0` |
| P07 MBIST campaign `--quick` (Icarus 12, golden model) | 3 configurations, 9 627 cases, 0 mismatches, 0 assertions: **PASS** |
