# 07 — Clock and reset test modes

## 1. Controls

| Output | Value | Destination (P35 contract) | Purpose |
|---|---|---|---|
| `dft_test_mode` | scan mode | P35 `test_mode_i`, P36 `test_mode_i` | every reset synchroniser's input **and** output switch to `test_rst_ni` through DFT mux cells |
| `dft_icg_te` | scan mode | P35 `test_en_i` | every ICG (root, branches) opened through its SE pin for the whole scan session (P35 test SDC: `test_mode_i = test_en_i = 1`) |
| `dft_scan_en` | scan mode AND `SCAN_EN` | scan-enable network | shift / capture |
| `dft_test_rst_n` | `TEST_RST_N` pin in scan mode, else 1 | P35 `test_rst_ni` | reset controlled by the tester during scan |
| `dft_mem_inhibit` | scan mode | memory wrappers (CE gating at integration) | random scan states never write macros |
| `mbist_clk_req[g]` | group g acquired / tested / re-initialising | P35 `br_clk_req_i[b]` of the group's branch | MBIST works even when software gated the branch |

Scan mode = `TEST_MODE` pin AND DEV lifecycle (combinational). Every output is low outside DEV whatever the
pins do.

## 2. Clock selection and clock domains

* **No clock multiplexer** in the test-access RTL. The earlier TestCore r1 had a root clock mux that is
  glitch-free only by protocol (P35 finding F-03); it is not used.
* MBIST runs on the functional clock of each memory group (P35 `clk_core_o` or one of its gated branches:
  the same clock, not a crossing), at functional speed.
* JTAG runs on TCK. The only TCK↔clk crossing is TestCore's verified toggle-handshake bridge.
* Scan shifts and captures with the functional clock pin. The tester clock reaches `clk_core_i` through
  the PLL bypass of the clock root, which is part of the PLL IP. No PLL exists in the repository (P31
  boundary `clk_i`).
* ICG behaviour in scan follows P35: transparent for the whole session, so capture clocks reach every
  domain. The functional ICG enable logic is therefore not tested by capture. A `TE = SCAN_EN` alternative
  is a one-line change (`dft_icg_te`) if ATPG needs it.

## 3. Verified against the real P35 tree (`tb/tb_ta_clktree.sv`, both simulators)

| Check | Result |
|---|---|
| A: software gates both accelerator branches (`R_CLK_EN = 0`) | 0 branch edges in 100 core cycles |
| B: MBIST on a group whose memory sits on gated branch 0 | `mbist_clk_req` opens branch 0 only; March C− PASS; branch 1 gets 0 edges; branch 0 gates again after release |
| C: DEV + `TEST_MODE`: ICGs open, resets follow `TEST_RST_N` | both branches toggle with software enables 0; fabric, ControlCore and branch resets follow `TEST_RST_N` 0 → 1 |
| D: PROD + `TEST_MODE` + `TEST_RST_N = 0` | no ICG opens, no domain reset; `dft_*` outputs inactive |

## 4. Reset handling in test

* Test-access reset `rst_n`: P35 fabric reset (asynchronous assert, synchronous release). In scan it follows
  `TEST_RST_N` through P35, so the block's own flops are controllable.
* `trst_n` = TRST* AND POR, so the TAP resets at power-up even without a TRST* pin.
* A reset during MBIST leaves no memory with undefined content (docs/03 §3, `reset_in_test`).
* Leaving scan requires a reset (TestCore rule): after shifting, state is undefined.
