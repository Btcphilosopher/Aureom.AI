# 11 — DFT readiness checklist

Status: **DONE** (implemented and verified with the evidence named), **PARTIAL**, **PLANNED** (designed /
documented, not implemented), **BLOCKED** (needs something unavailable here), **N/A**.

## Test access and JTAG

| # | Item | Status | Evidence / gap |
|---|---|---|---|
| J-1 | TAP state machine, TCK/TMS/TDI/TDO, TRST* | DONE | 16/16 states, 32/32 arcs against the reference; TRST* async reset; 5 x TMS=1 → TLR (`jtag_tap`); TestCore formal `fv_tap`; P07 TB re-run 51 776 checks |
| J-2 | IR (5 bit), capture value 01, BYPASS, IDCODE | DONE | DR lengths 32 / 1 / 46 / 8 measured; EXTEST / SAMPLE / unassigned → BYPASS |
| J-3 | Register access over JTAG (CDC), BUSY / ERROR reporting | DONE | `jtag_tap`, `reset_in_test` (BUSY during system reset, CLEAR) |
| J-4 | IEEE 1149.1 compliance | **NOT CLAIMED** | no boundary-scan register, EXTEST / SAMPLE reserved, no BSDL, no conformance suite |
| J-5 | JEDEC manufacturer ID / part number | BLOCKED | IDCODE `0x15F07001` is TestCore's placeholder |
| J-6 | Boundary scan / pad ring | BLOCKED | no I/O library or pad ring in the repository |

## Test modes and security

| # | Item | Status | Evidence / gap |
|---|---|---|---|
| S-1 | Lifecycle-gated JTAG, debug, scan, MBIST | DONE | `lc_policy` (12 lifecycle cases), `secure_debug`, formal G1–G8 |
| S-2 | Fail closed on invalid / inconsistent lifecycle | DONE | `lc_policy`, mutant M02 |
| S-3 | P28 lifecycle flops excluded from scan | PLANNED | requirement on the chip scan flow (docs/04) |
| S-4 | Authenticated debug unlock / RMA | BLOCKED | not in P28 |
| S-5 | Write-protected regions excluded from in-field MBIST groups | PLANNED | integration rule (docs/04) |
| S-6 | Violations logged and sent to RAS | DONE | `lc_policy`, `error_prop` |

## MBIST

| # | Item | Status | Evidence / gap |
|---|---|---|---|
| M-1 | Shared SRAM (MemoryCore) under MBIST | DONE (RTL + simulation) | groups 1–2, real `sfmem_banked` |
| M-2 | P33 SRAM grid under MBIST | DONE (RTL + simulation) | group 0, real `silicaflux_sram_grid` (`sg_min4`) |
| M-3 | ControlCore IMEM / DMEM | PLANNED | test ports exist but are tied off inside the ControlCore |
| M-4 | Vector SPM, tensor buffers | PLANNED | no test port in those wrappers |
| M-5 | Selection, start / complete, pass / fail, address, syndrome, timeout, abort, reset | DONE | docs/05 §2 |
| M-6 | Functional-master arbitration | DONE | ownership FSM, formal C1–C11, `func_switch`, `error_prop` |
| M-7 | Content valid after every session (ECC / parity) | DONE | scoreboards: 0 error responses after any session, formal C7 / C8 |
| M-8 | Multi-group ordering (sequential / parallel) | DONE | `ordering`, formal S3 |
| M-9 | Memory-compiler specific algorithms, scrambling, retention, repair | BLOCKED | no compiler data; no redundancy |
| M-10 | At-speed MBIST timing of the macros | BLOCKED | no macro timing used (no STA with macro libs) |
| M-11 | Power-up MBIST hooks of P36 | PLANNED | P36 power gating is a FUTURE configuration |

## Scan / ATPG

| # | Item | Status | Evidence / gap |
|---|---|---|---|
| D-1 | Scan insertion with compatible cells and a real tool | DONE for this block | OpenROAD + sky130hd, 17 chains, 0 non-scan flops, continuity PASS |
| D-2 | Scan of ControlCore, vector, tensor, DataFabric, DMA, glue | PLANNED | register counts and chain proposals (docs/06) |
| D-3 | Scan compression, OCC, at-speed | BLOCKED | commercial DFT tools |
| D-4 | ATPG fault coverage | BLOCKED, **not claimed** | no ATPG tool run in this project |
| D-5 | Scan-mode timing closure (post-CTS hold) | BLOCKED | no CTS / routing; ideal-clock experiment only |
| D-6 | No clock mux in test logic; ICGs transparent in scan; resets controllable | DONE | RTL, `tb_ta_clktree` C |

## Clock / reset / power

| # | Item | Status | Evidence / gap |
|---|---|---|---|
| C-1 | DFT controls to P35 (test_mode, test_en, test_rst) | DONE | `tb_ta_clktree` (real P35) |
| C-2 | Branch clock request during MBIST | DONE | `tb_ta_clktree` B, `dft_clkrst` |
| C-3 | PLL bypass for the scan clock | BLOCKED | no PLL IP |
| C-4 | Test power (shift / capture IR drop) | BLOCKED | no power grid / analysis |

## Observability and production test

| # | Item | Status | Evidence / gap |
|---|---|---|---|
| O-1 | Test status, controller state, memory failures, scan status, timeouts, RAS, severity; host-readable | DONE | register map; `error_prop` |
| O-2 | Wafer-probe status pins TEST_DONE / PASS / FAIL | DONE (RTL) | `ordering`, `faults`, JTAG flow in `secure_debug` |
| O-3 | ATE program, probe card, binning | BLOCKED | no tester |
| O-4 | Silicon / FPGA validation | BLOCKED | none exists |
