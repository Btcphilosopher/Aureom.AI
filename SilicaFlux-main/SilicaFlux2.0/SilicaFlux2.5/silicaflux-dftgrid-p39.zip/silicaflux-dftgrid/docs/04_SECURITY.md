# 04 — Security: test / debug access and the lifecycle

Test access is coordinated with SecureBoot (P28, "SecureSilicon"). P28 latches the effective lifecycle from
its fuse model at reset and publishes `debug_en = test_mode_en = (lifecycle == DEV)`. P28 explicitly leaves
scan and BIST gating to the DFT flow. This block closes that gap.

## 1. Lifecycle states

| State (P28) | Meaning for test | How the part gets there |
|---|---|---|
| **DEV** (blank fuses) | **development and manufacturing test**: wafer probe, final test, bring-up. Everything open | as fabricated |
| **PROV** | provisioning (keys programmed): no external test or debug; firmware in-field self-test if fused | `LC_ADVANCE` DEV → PROV |
| **PROD** | production: same as PROV | `LC_ADVANCE` PROV → PROD |
| RECOVERY | PROV/PROD booting from the host only: same as PROD | strap or 3 failed boots |
| INVALID / not sensed / inconsistent | everything closed (fail closed) | corrupted fuse word, glitch, integration error |

Manufacturing test therefore happens while the part is DEV. A PROD part cannot be reopened. There is no
authenticated unlock or RMA state (P28 limitation, unchanged).

## 2. Permission matrix (`sfta_lc_policy`, combinational)

| | JTAG `TC_REG` | JTAG_ACCESS / DIAG | `TEST_MODE` (scan) | unprivileged write / group read | MBIST by ControlCore firmware | MBIST over JTAG | IDCODE / BYPASS |
|---|---|---|---|---|---|---|---|
| DEV | yes | yes | yes | yes | yes | yes | yes |
| PROV / PROD / RECOVERY, fuse `otp_ift_en` = 1 | — | — | — | — | **yes** | — | yes |
| PROV / PROD / RECOVERY, fuse = 0 | — | — | — | — | — | — | yes |
| INVALID, not sensed, inconsistent | — | — | — | — | — | — | yes |

"Inconsistent" means the lifecycle enum disagrees with P28's own `debug_en` / `test_mode_en`, or the enum is
unknown. It raises `LC_INCONS` (RAS ILLEGAL_OP). All 12 combinations are tested (`lc_policy`), and properties
G1–G8 are model-checked at block level.

## 3. What a refused access does

* JTAG `TC_REG` request outside DEV: the bridge returns `STATUS = ERROR` with data 0. Nothing reaches a
  register (embedded assertion, formal G-set).
* Unprivileged (`s_priv = 0`: host, DMA) write outside DEV, or read of a group page: `err`, data 0. Page-0
  reads stay allowed: the host can read summary status (`SEQ_STATUS`, results, errors), but not failure
  details.
* Every refusal: `VIOL_INFO` (source, address), `VIOL_COUNT`, `ERR_STATUS.SEC_VIOL`, RAS `ILLEGAL_OP`
  (WARN; firmware may raise the minimum severity in RAS `SEV_CFG`).
* `TEST_MODE` pin outside DEV: ignored. `dft_test_mode`, `dft_icg_te`, `dft_scan_en` stay 0 and the P35
  resets ignore `TEST_RST_N` (checked against the real P35 tree, `tb_ta_clktree` part D). Logged as
  `SCAN_PIN`.

## 4. Why test mode cannot bypass the production restrictions by accident

| Path | Protection | Evidence |
|---|---|---|
| Scan entry | `scan_mode = TEST_MODE pin AND DEV`. Purely combinational: shifting the chains of this block cannot change it | formal G1, simulation `lc_policy`, `secure_debug`, `tb_ta_clktree` D |
| Reset / clock bypass through P35 | only via `dft_test_mode` / `dft_icg_te` (scan mode) | as above |
| JTAG reading memory or registers | `TC_REG` gated to DEV; there is no system-bus master on JTAG in this block | G-set + `secure_debug` |
| MBIST used to read memory contents | every algorithm **writes before it reads** each address (March elements start with w0; walking writes then reads the same word). Failure logs therefore hold test-pattern data, never previous content | algorithm tables (TestCore `sftc_consts.svh`) |
| MBIST used to write a protected memory | test writes only test patterns, and every session ends with a re-initialisation to zero. A bank holding live CPU state can be `PROTECT`ed (acquired only while the CPU is halted). A write-protected region (P33 boot RAM, `wp_lock`) must not be in a group the firmware tests after the lock (readiness item S-5) | `abort_protect` |
| Permission withdrawn mid-test | mode forced NORMAL, engines hard-stopped, groups re-initialised before release | `secure_debug` (c) |
| Debug via the ControlCore debug port | `dbg_allow` = debug permission for the SoC debug module | `lc_policy` |

## 5. Not provided / requirements on integration

* **S-3** P28 keeps `lc_eff_q` in ordinary flops. They must be excluded from scan (or rebuilt from OTP sense
  outputs). Otherwise shifting could change the lifecycle the policy sees.
* No authenticated debug unlock, no RMA state (P28).
* No protection against physical attacks (probing, fault injection on the lifecycle wires) beyond fail-closed
  decoding.
* The TestCore unlock key is an interlock against accidental destructive tests, not a secret.
* The JTAG IDCODE is TestCore's placeholder `0x15F07001` (manufacturer field 0). A JEDEC ID and a die part
  number must be assigned.
