# 03 — Test modes and test-mode arbitration

## 1. Test modes (TestCore mode controller, global)

| Mode | Entered by | Permission | Effect |
|---|---|---|---|
| NORMAL | reset, request, permission loss | — | functional operation |
| JTAG_ACCESS | `MODE_CTRL` request | debug (DEV) | `jtag_mode` output for SoC debug muxing |
| DIAGNOSTIC | `MODE_CTRL` request | debug (DEV) | `diag_mode` output |
| MBIST | `UNLOCK` key, then `MODE_CTRL` request | MBIST (DEV, or PROV/PROD/RECOVERY with the in-field fuse) | engines may acquire memory groups |
| SCAN_SHIFT / SCAN_CAPTURE | `TEST_MODE` pin (+ `SCAN_EN`) | scan (DEV) | DFT controls (docs/07); overrides everything combinationally |

The transition table is TestCore's (formally proven there): MBIST is left through an exit sequence (abort,
wait until every engine is idle and every group released). An illegal request is refused and logged
(`REFUSED`). A request without permission is denied and logged as a security violation (`MODE`). Losing
the permission forces NORMAL immediately and hard-stops the engines (`PERM_LOSS` violation). Leaving scan
requires a reset, a TestCore rule: state is undefined after shifting.

## 2. Functional-to-test switching (per memory group)

```
NORMAL --acq--> QUIESCE_REQUEST --quiesce_ack--> WAIT_FOR_IDLE --memory idle--> TEST_ACQUIRE
   ^                                                                                 |
   |                                                                            TEST_ACTIVE (engine)
   |                                                                                 |
   +--- TEST_RELEASE <--test reads drained, re-initialised-- TEST_COMPLETE <--engine idle, acq withdrawn
   any wait > timeout -> FAULT (port back to functional, test access denied, sticky until CLEAR)
```

* `acq` = MBIST mode, not exiting, bank selected (page `BANK_MASK` or the sequencer), and the bank not
  `PROTECT`ed unless `cpu_halted`. A protected bank holds live CPU state.
* `quiesce_req` asks the group's masters to stop issuing. The port stays open in QUIESCE_REQUEST so a
  request already presented can complete its handshake (TestCore deadlock fix). From the acknowledge on,
  `f_block` gates **every** functional request of the group. A request presented anyway is blocked and
  reported **once per episode** (`INTRUSION`).
* The memory's raw test bus is driven only in TEST_ACTIVE (engine) or during a collar sweep. This is proven
  (C1, C2, C9).
* While test owns the group, `f_block` is high (C3, proven), so **a functional master cannot corrupt a
  memory test**. Simulation (`error_prop`): a master that ignores the protocol presents requests throughout
  a test; the test passes, one INTRUSION event is logged, and the requests complete after release.
* Release only after re-initialisation: collar sweep (MemoryCore) or the memory's own init (grid,
  `released` waits for `init_busy` low). A group is never returned with undefined content (C7, C8 proven).
  Functional reads after every test session return zero with no parity or ECC error (checked by every
  master scoreboard).
* Groups are independent. Testing one group never stalls the masters of another (`func_switch`: 36k–56k
  requests accepted by the other groups during each session).

## 3. Arbitration rules

| Situation | Behaviour |
|---|---|
| JTAG and system port request in the same cycle | JTAG first (single-cycle bus, the system request retries) |
| Page START while the sequencer owns the group | ignored, `ERROR_FLAGS.ILLEGAL_START`; the running algorithm is unchanged (`abort_protect`) |
| Page ABORT while the sequencer owns the group | honoured: an abort is never blocked. The sequencer records ABORTED for that group, releases it and goes on with the next group, or stops if STOP_ON_FAIL is set (by design; not exercised by a bench, docs/09) |
| Two groups test in parallel | independent engines and collars; RAS events are queued per (class, group) and none is lost when two groups fail in the same cycle |
| Sequential sequence | one group acquired at a time, ascending index (proven S3; simulated windows strictly ordered) |
| Functional master never acknowledges quiesce | owner timeout → FAULT → group back to functional, result `OWNER_FAULT`, RAS TIMEOUT; or the sequencer watchdog fires first → `TIMEOUT` |
| Engine does not finish | sequencer watchdog → ABORT → release → `TIMEOUT` |
| Test-access reset during a test | owners reset → the grid re-initialises (tst_active fell); MemoryCore collars run the after-reset sweep (memory held in test from reset assertion). Results are lost, memories valid (`reset_in_test`) |
| Full reset during a test | memories re-initialise on reset; scoreboards clean afterwards |
| ABORT (sequence or page) | engine stops at its next transaction boundary, group released and re-initialised; result ABORTED / NOT_RUN |

## 4. Sequencer

| Field | Meaning |
|---|---|
| `SEQ_GROUPS` | groups to test (all banks of each) |
| `SEQ_CTRL` | START / ABORT / CLEAR, PARALLEL, STOP_ON_FAIL, engine stop-on-fail, checkerboard background, scrub, algorithm |
| `WDOG_LIMIT` | per-phase watchdog (ACQ, RUN, STOP, REL), latched at START |
| `SEQ_RESULT` | 4 bits per group: NOT_RUN, PASS, FAIL, ABORTED, ERROR, TIMEOUT, REFUSED, RUNNING, OWNER_FAULT |
| `SEQ_CYCLES` | test time of the last sequence |
| pins | `TEST_DONE`, `TEST_PASS`, `TEST_FAIL` |

Measured in simulation (3 groups, March C−, traffic running): see `reports/REGRESSION.md` (`ordering`).
Parallel is faster than sequential by roughly the sum of the shorter groups.

## 5. Timeouts

| Timeout | Default | Result |
|---|---|---|
| Engine request / response (`ENG_TIMEOUT`) | 1024 cycles | engine ERROR (inconclusive), `MBIST_ERROR` |
| Ownership quiesce / drain (`OWN_TIMEOUT` + sweep length) | 4096 + depth + latency + 8 | FAULT, `OWNER_FAULT` |
| Sequencer phase watchdog (`WDOG_LIMIT`) | off (0) | `TIMEOUT`, engine aborted, group released |
