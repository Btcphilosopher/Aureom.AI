# 05 — MBIST integration

## 1. Memory inventory of the die and MBIST status

Memory-array bits come from Yosys elaboration of the P31 die (`reports/scan_plan/scan_plan.json`, MIN
configuration; the HPC configuration has 4 vector tiles, 2 tensor units and 4 shared slices).

| Memory | Size (MIN) | Raw test bus available? | Status in this delivery |
|---|---|---|---|
| Shared SRAM, MemoryCore `sfmem_banked` slices | 4 banks x 65 536 x 36 b (parity) per slice | **yes** (P31 uses it for its init sweep) | **connected**: collar group (verified with 16 KiB / 8 KiB slices; depth is a parameter up to 2^24) |
| P33 SRAM grid (distributed regions) | `sg_min4`: 4 x 1024 x 72 b; `sg_hier`: 23 banks | **yes** | **connected**: group 0 of the verified configuration (`sg_min4`) |
| ControlCore IMEM / DMEM (`mcu_sram_bank`) | 36 x 16 384 + 36 x 8 192 | port exists in `mcu_sram_bank`, **tied off** inside `silicaflux_control_core` (`.tst_active(1'b0)` …) | not connected: needs the ControlCore to export the two ports (a change to P29/P31 RTL). Then one collar group with `G_INIT = 1` and `PROTECT` on the bank holding the boot stack |
| Vector-tile scratchpads (`hpc_scratchpad`) | 4 x 32 x 4096 per tile | **no** (generic memories, no test mux) | not connected: needs a test port in `hpc_spm_bank` (sramlib `sram_bank_controller` with `TEST_EN = 1` provides it) |
| Tensor operand / accumulator buffers | 32 x 128, 32 x 64, … per unit | **no** | not connected (as above), or covered by scan if they are mapped to flip-flops |
| Boot ROM (`sfv_bootrom_image`) | 32 x 1024 | no (ROM) | functional read-back / signature by firmware. MBIST does not apply |
| Small queues / mailbox (`hpc_command_queue`, `tdma_queue`, `cc_mailbox`, …) | ≤ 2 Kib each | no | flip-flop arrays in synthesis: **scan** covers them |

## 2. Per-group features (brief §4)

| Feature | Where | Verified by |
|---|---|---|
| Memory selection | page `BANK_MASK` (any subset of banks), or the sequencer (all banks of the selected groups) | `mbist_select` (single bank, bank pairs, bank sequence checked on the bus) |
| Test start / complete | `TEST_CONTROL.START`, `TEST_STATUS.done/busy`; `SEQ_CTRL.START`, `SEQ_STATUS` | all MBIST tests |
| Pass / fail | `TEST_STATUS.pass/fail`, `LAST_RESULT`, `BANKS_FAILED`; `SEQ_RESULT`, `TEST_PASS/FAIL` pins | `faults`, `ordering` |
| Failure address | `FIRST_FAIL_ADDRESS` (row), `FF_INFO` (bank, March element, op index, walk bit), fail-log FIFO | `faults`: exact row in 10/10 single-cell cases |
| Failure syndrome / pattern | `FF_EXP`, `FF_OBS`, `FF_SYND` (expected XOR observed, full stored word incl. ECC / parity bits) | `faults`: single-bit syndrome at the injected bit in 10/10 cases |
| Timeout | engine request / response timeout; ownership timeout; sequencer watchdog | `timeout` |
| Abort / reset | `TEST_CONTROL.ABORT`, `SEQ_CTRL.ABORT`, mode exit, permission loss, test-access reset, system reset | `abort_protect`, `recovery`, `reset_in_test`, `secure_debug` |
| Arbitration against functional masters | ownership FSM, quiesce, `f_block`, intrusion detection | `func_switch`, `error_prop`, formal C1–C11 |

## 3. Algorithms and test time

TestCore algorithms: March C− (10N), MATS+ (5N), checkerboard, inverse checkerboard (2N each), walking one,
walking zero ((2W+1)N); checkerboard-background option for March. The engine runs one transaction at a time,
independent of latency: a read costs 1 + L_eff, a write costs 1 + request stages.

Measured (Icarus and Verilator identical), 1024 rows:

| Group | Read / write cost | March C− (scrub on) | MATS+ (scrub on) | Fixed overhead |
|---|---|---|---|---|
| 0 grid, 72 b, L 1 | 2 / 1 | 16 398 | 8 203 | 14 / 11 |
| 1 MemoryCore, 36 b, L 1 | 2 / 1 | 16 398 | 8 203 | 14 / 11 |
| 2 MemoryCore, 36 b, L 2 + 2 stages | 5 / 2 | 37 894 | 18 437 | 6 / 5 |

The per-operation model holds exactly: an error in any coefficient would show up as a multiple of 1024
cycles. One MIN shared-SRAM slice (4 x 65 536 rows, L 1) therefore needs about 4 x 16 x 65 536 ≈ 4.2 M cycles
for March C− (plus 65 536 cycles of re-initialisation): 42 ms at 100 MHz. This is a model figure, not a
silicon measurement.

## 4. Fault model and memory-test coverage

**Implemented fault model** (TestCore golden model, single fault): cell stuck-at 0/1, transition ↑/↓,
address-decoder (alias, multi-access, no-access), coupling CFin / CFid / CFst (inter- and intra-word),
read-path inversion, data-line stuck-at, intermittent read, memory error flag, protocol faults.

**Coverage over the enumerated synthetic population** (TestCore P07 campaign, 8 b x 16 words; re-run here in
quick mode: 9 627 cases, 0 mismatches against the golden model):

| Algorithm | Detected | Coverage |
|---|---|---|
| March C− | 2216 / 2376 | 93.3 % (100 % for stuck-at, transition, address decoder, CFin, read path, data line; 83.3 % for CFid / CFst: the escapes are intra-word pairs) |
| MATS+ | 1824 / 2376 | 76.8 % |
| Checkerboard / inverse | 868 / 836 of 2376 | 36.5 % / 35.2 % |
| Walking one / zero | 1115 / 1132 of 2376 | 46.9 % / 47.6 % |

This is coverage of an **enumerated synthetic fault list**, not silicon defect coverage. No production
memory-defect statistics exist.

**System-level injection in this project** (real P33 grid and MemoryCore RTL; generic-model fault hooks;
fault in data, ECC check or parity bits):

| Group / bank / row / bit | Fault | Detected | Element | Location | Syndrome |
|---|---|---|---|---|---|
| 1 / 2 / 517 / 13 | SA0 | FAIL | 2 | exact | single bit 13 |
| 1 / 0 / 3 / 35 (parity) | SA1 | FAIL | 1 | exact | bit 35 |
| 1 / 3 / 1000 / 7 | TF↑ | FAIL | 2 | exact | bit 7 |
| 1 / 1 / 64 / 20 | TF↓ | FAIL | 3 | exact | bit 20 |
| 1 / 2 / 100 → 200 / 4 → 9 | CFid | FAIL | 1 | victim row 200 | bit 9 |
| 1 / 0 / 10 → 20 | address alias | FAIL | 1 | row 20 | whole word |
| 0 / 1 / 700 / 13 (grid data) | SA0 | FAIL | 2 | exact | bit 13 |
| 0 / 3 / 5 / 70 (SECDED check bit) | SA1 | FAIL | 1 | exact | bit 70 |
| 0 / 0 / 1023 / 71 | TF↓ | FAIL | 3 | exact | bit 71 |
| 2 / 1 / 333 / 5 (L 2, pipelined) | SA0 | FAIL | 2 | exact | bit 5 |
| 2 / 0 / 1023 / 35 | SA1 | FAIL | 1 | exact | bit 35 |
| 0 / 1 / 12 / 40 via sequencer | SA1 | FAIL (sequence result FAIL, `TEST_FAIL` pin; STOP_ON_FAIL leaves groups 1–2 NOT_RUN) | — | — | — |

Every case passes again once the fault is removed. Each failure reaches RAS as one `MEM_UE` event
(severity ERROR) with group, bank, row and element.

## 5. Repair

None. No supported macro has spare rows or columns, and there is no fuse or repair logic. MBIST reports
the failing group, bank, row and bits; mapping a bank out is a software decision.
