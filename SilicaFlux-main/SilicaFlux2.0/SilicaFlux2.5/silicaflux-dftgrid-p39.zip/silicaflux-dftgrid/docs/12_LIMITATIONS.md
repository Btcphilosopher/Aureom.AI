# 12 — Limitations: what is not claimed

* **No silicon, FPGA, wafer-probe or packaged-part result exists.** All results come from RTL simulation, formal
  tools, open-source synthesis, scan insertion and a placement experiment.
* **IEEE 1149.1 compliance is not claimed.** The TAP is the verified TestCore P07 TAP. There is no
  boundary-scan register, EXTEST / SAMPLE are reserved, there is no BSDL, and no conformance suite was run.
  The IDCODE is a placeholder.
* **No ATPG fault coverage is claimed.** No ATPG tool was run in this project. The inserted chains are verified
  for continuity only.
* **Scan of the chip partitions is planning only**: real register counts, proposed chains, no scan cells.
* **Scan in this block is an open-flow experiment**, not production scan: no compression, no OCC, no
  placement-aware ordering, no post-CTS hold closure. Timing figures use ideal clocks and estimated parasitics.
* **Memory-test coverage figures apply to an enumerated synthetic fault model** (TestCore golden model and
  injected cases), not to silicon defect populations.
* The ControlCore memories, vector scratchpads and tensor buffers are **not under MBIST** in this delivery
  (docs/05 §1).
* The P31 die is **not modified**. Integration steps are specified (docs/01 §5) and exercised with the real
  memory RTL in a system testbench, not in the die top.
* Formal proofs cover small parameterisations of the collar and the sequencer (unbounded). The whole block is
  checked by bounded model checking only (depth recorded in `reports/formal/summary.md`); an unbounded `abc pdr`
  attempt on the whole block did not complete and is not reported as a result. Synchronisers are modelled as
  ideal flops; liveness is shown by simulation only.
* Functional-coverage holes are listed with their reasons in docs/09 §2 (two ownership arcs and one RAS
  bookkeeping class are not exercised by the benches).
* Distances in the physical report are geometric, from P33's planning floorplans. They are not extracted wire
  delays.
* No memory repair (no redundancy in any supported macro). No retention test. No non-destructive (save /
  restore) memory test: a tested group's content is re-initialised (zero data with valid ECC / parity).
* Security: no authenticated debug, no RMA state, no protection against physical attacks. The unlock key is an
  interlock, not a secret. The P28 lifecycle flops must be excluded from scan (requirement S-3).
* Delivered as an archive; nothing was committed to GitHub.
