# 01 — Test-access architecture

![test-access diagram](test_access_diagram.svg)

## 1. Hierarchy

```
silicaflux_test_access                 rtl/silicaflux_test_access.sv   (primary RTL, new)
├── sfta_lc_policy                     lifecycle -> permissions (combinational, new)
├── sftc_jtag_tap                      TestCore P07, unmodified
├── sftc_jtag_reg_bridge               TestCore P07, unmodified (TCK -> clk)
├── access gate + arbiter              in the top (new)
├── silicaflux_test_mode_controller    TestCore P07, unmodified (one, global)
├── sftc_sync                          TEST_MODE pin synchroniser (status / violation log only)
├── sfta_seq                           MBIST sequencer (new)
├── sfta_regs                          page-0 registers, errors, RAS port (new)
└── g_grp[g]  (one per memory group)
    ├── sfta_group_ctrl                new composition of TestCore blocks:
    │   ├── sftc_regs                  register page g+1 (unmodified)
    │   ├── silicaflux_mbist           March engine (unmodified)
    │   └── sftc_mbist_bank_mux        bank selector, optional pipeline (unmodified)
    └── sfta_group_collar              collar at the memory (new)
        └── sftc_mem_owner             ownership FSM (unmodified)
```

All RTL is SystemVerilog accepted by Verilator 5.020 (`-Wall`, clean in the synthesis view and the simulation
view), Icarus 12, Yosys 0.33 and Yosys 0.70.

## 2. Memory groups

A **memory group** is one memory with the SRAM-library raw test bus:
`tst_active, tst_sel[b], tst_ce, tst_we, tst_addr, tst_wdata -> tst_rdata[b]`, fixed read latency.
Both memory families of the chip already have this bus:

| Family | Instance | Test bus semantics | Initialisation after a test |
|---|---|---|---|
| P33 `silicaflux_sram_grid` | distributed SRAM regions | raw stored word (data + SECDED / parity bits), `TEST_LAT`; `tst_active` stops functional issue of the whole grid | the grid itself (`INIT_AFTER_TEST = 1`): `G_INIT = 2` |
| MemoryCore `sfmem_banked` / `sram_bank_controller` | P31 shared-SRAM slices | raw stored word, `RD_LAT`; `tst_active` blocks all masters of the slice | the collar writes `G_INIT_WORD` (zero data, valid parity) to every row: `G_INIT = 1`, also after reset |

Parameters per group: `G_NB` banks, `G_SW` stored width, `G_DEPTH` rows, per-bank widths / depths
(`G_BW`, `G_BD`), `G_LAT`, `G_INIT`, `G_INIT_ON_RESET`, `G_INIT_WORD`, `G_KIND`, `G_PIPE_REQ/RSP`.
Up to 7 groups (the 12-bit address leaves 7 pages); TestCore register fields show up to 8 banks per group
(`OWNER_STATUS`), and the engine itself takes up to 32.

Verified configuration (`tb/tb_ta_sys.sv`, `asic/synth/sfta_synth_top.sv`):

| Group | Memory | Banks x rows x bits | Latency | Init | Link |
|---|---|---|---|---|---|
| 0 | P33 grid `sg_min4` (12 IHP macros in ASIC builds) | 4 x 1024 x 72 (SECDED) | 1 | self | direct |
| 1 | MemoryCore slice, 16 KiB | 4 x 1024 x 36 (parity) | 1 | collar + after reset | direct |
| 2 | MemoryCore slice, 8 KiB | 2 x 1024 x 36 (parity) | 2 | collar + after reset | 1 request + 1 response pipeline stage |

## 3. Data and control paths

* **Register access.** JTAG (`TC_REG` DR, 46 bits, via the CDC bridge) and the system register port share
  one single-cycle register bus. JTAG has priority. The access gate applies the lifecycle policy before
  anything is decoded (docs/04).
* **Test mode.** One global TestCore mode controller. `MBIST` needs the hardware permission (lifecycle)
  **and** the unlock key; scan is pin-forced (`TEST_MODE`) in DEV only. Permission loss forces NORMAL and
  hard-stops every engine.
* **MBIST.** Per group: engine → bank mux → (optional stages) → collar → memory raw bus. One transaction at a
  time per engine, banks in ascending order. Groups are independent and can run concurrently.
* **Sequencer.** One START tests every bank of the selected groups, either sequentially (ascending group
  index) or in parallel, with a per-phase watchdog. It is used for wafer probe (`TEST_DONE/PASS/FAIL` pins)
  and boot POST.
* **Status.** `GRP_STATUS`, `SEQ_*`, `GRP_LIVE` and the TestCore pages hold the details. Error classes,
  severities, the first error, counters and the violation log are in page 0. RAS events go out on the P26
  external event port. `irq` goes to the ControlCore.

## 4. Clocks and resets

| Domain | Clock | Reset | Contents |
|---|---|---|---|
| TCK | `tck` | `trst_n` = TRST* AND POR | TAP, TCK side of the bridge (rising + 7 falling-edge flops) |
| system | `clk` = memory clock (P35 `clk_core_o`, or a branch: same clock, gated) | `rst_n` (asynchronous assert, synchronous release by P35) | everything else |

There is **no clock multiplexer** in the block. MBIST runs on the functional clock at functional speed.
Scan uses the functional clock pin (PLL bypass belongs to the PLL / clock root). `mbist_clk_req[g]` keeps the
group's clock branch running while it is acquired, tested or re-initialised (P35 `br_clk_req_i`).

## 5. Integration into the P31 die (not done in this delivery: P31 is vendored unmodified)

1. Instantiate `silicaflux_test_access` in `silicaflux_die_top` in place of the reserved JTAG tie-offs
   (`tdo_o`, `tdo_oe_o`), on `clk` with the fabric reset.
2. `memory_subsystem`: route each slice's `tst_*` port to group g and delete the local initialisation sweep.
   The collar sweep with `G_INIT_ON_RESET = 1` replaces it, and `mem_ready` comes from the collar.
3. Per group, connect `quiesce_req` and `quiesce_ack` to the masters of that memory. These are the ControlCore,
   DMA, vector and tensor ports through the NoC target, or a NoC-target-side hold. `f_busy` is the slice's
   `busy`, `f_req` is the OR of the slice's request valids, and `f_block` gates every request valid / ready
   of the slice.
4. The system register port is a fabric target window. `s_priv` is set when the fabric master ID is the
   ControlCore CPU (the P28 access policy already classifies masters).
5. Connect SecureBoot `lc_*` / `debug_en` / `test_mode_en` and the OTP in-field-test bit; the P26 external
   event port; the P35 DFT inputs and branch clock requests; `irq` to the ControlCore INTC.
6. Replace `ras_test_subsystem`'s `TESTCORE_EN` refusal with a reference to this block. Its `TEST_STATUS`
   register can mirror `SEQ_STATUS`.

`tb_ta_sys` exercises steps 2–5 with the real memory RTL. `tb_ta_clktree` exercises the P35 connection.
