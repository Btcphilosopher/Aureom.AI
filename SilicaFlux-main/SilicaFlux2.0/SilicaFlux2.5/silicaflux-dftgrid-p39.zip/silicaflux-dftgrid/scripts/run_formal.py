#!/usr/bin/env python3
"""Run the Project 39 formal harnesses (SymbiYosys).

    python3 scripts/run_formal.py [--skip-bmc]

  * fv_collar, fv_collar_self, fv_seq : unbounded safety proofs (abc pdr), then each
    non-vacuity reach point (expected FAIL = reachable, the property is not vacuous);
  * fv_ta_bmc : bounded model check (smtbmc z3) of the whole test-access block in a
    small configuration -- every embedded TA and TestCore assertion plus the
    lifecycle-gate properties, reported as BOUNDED to the stated depth.
Writes reports/formal/summary.{json,md}.  Requires sby + yosys on PATH.
"""
import json, re, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FDIR = ROOT / "formal"
OUT = ROOT / "reports" / "formal"
HARNESSES = {
    "fv_collar": ("Group collar, collar re-initialisation sweep + init after reset (2 banks x 4 rows, LAT 2)", 4, [
        "C1 raw memory access only with tst_active", "C2 engine access only in TEST_ACTIVE",
        "C3 test owns the group => every functional request blocked", "C4 sweep and engine never in the same cycle",
        "C5 engine access selects exactly one bank", "C6 read response only for a read issued LAT cycles earlier",
        "C7 the group is never released with undefined content", "C8 REINIT_REQUIRED cannot occur",
        "C9 in NORMAL only an initialisation sweep uses the test bus",
        "C10 reset initialisation keeps the memory in test (functional traffic held)",
        "C11 clock requested whenever the test bus is owned",
        "embedded: collar assertions, TestCore sftc_mem_owner assertions"]),
    "fv_collar_self": ("Group collar, memory self-initialisation mode (P33 grid style)", 4, [
        "C1-C9, C11 as above with INIT_MODE = self"]),
    "fv_seq": ("MBIST sequencer, 2 groups, every group status free", 4, [
        "S1 groups acquired only inside a sequence", "S2 acquisition only of a group owned by the sequencer",
        "S3 sequential mode: at most one group acquired", "S4 START only while the group is acquired",
        "S5 done and busy exclusive", "S6 sequence PASS => every selected group PASS",
        "S7 the watchdog bounds every timed phase", "S8 START only after the group was owned by test"]),
}


def tool(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True).stdout.strip().splitlines()[0]
    except Exception:
        return "unavailable"


def run(name, extra_def="", timeout=3600):
    src = (FDIR / f"{name}.sby").read_text()
    if extra_def:
        src = re.sub(r"^read -formal ", f"read -formal {extra_def} ", src, flags=re.M)
    work = OUT / "runs"
    work.mkdir(parents=True, exist_ok=True)
    lines, in_files = [], False
    for ln in src.splitlines():
        if ln.startswith("["):
            in_files = ln.strip() == "[files]"
        elif in_files and ln.strip():
            ln = str((FDIR / ln.strip()).resolve())
        lines.append(ln)
    tag = name + (("_" + re.sub(r"\W+", "", extra_def)) if extra_def else "")
    sby = work / f"{tag}.sby"
    sby.write_text("\n".join(lines) + "\n")
    shutil.rmtree(work / tag, ignore_errors=True)
    t0 = time.time()
    try:
        p = subprocess.run(["sby", "-f", str(sby)], cwd=work, capture_output=True, text=True, timeout=timeout)
        out = p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        out = (e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or "")) + "\nTIMEOUT"
    (work / f"{tag}.log").write_text(out)
    shutil.rmtree(work / tag, ignore_errors=True)
    m = re.search(r"DONE \((\w+), rc=", out)
    frame = re.search(r"(?:asserted in frame|step) (\d+)", out)
    return (m.group(1) if m else ("TIMEOUT" if "TIMEOUT" in out else "ERROR")), round(time.time() - t0, 1), out


def main():
    if not shutil.which("sby"):
        OUT.mkdir(parents=True, exist_ok=True)
        (OUT / "summary.json").write_text(json.dumps({"status": "BLOCKED", "reason": "sby not on PATH"}))
        print("[formal] BLOCKED: sby not on PATH")
        return 2
    sbyv = tool(["sby", "--version"])
    if "unknown" in sbyv:                     # nixpkgs build reports no version; take it from the store path
        m = re.search(r"-sby-([\d.]+)/", str(Path(shutil.which("sby")).resolve()))
        sbyv = f"SBY {m.group(1)} (nixpkgs)" if m else sbyv
    res = {"tools": {"yosys": tool(["yosys", "-V"]), "sby": sbyv}, "harnesses": {}}
    bad = 0
    for h, (desc, nreach, props) in HARNESSES.items():
        st, sec, _ = run(h)
        reach = []
        for k in range(nreach):
            rst, rsec, out = run(h, f"-DREACH -DREACH_IDX={k}")
            fr = re.search(r"failed assertion .* step (\d+)", out)
            reach.append({"point": k, "result": "REACHED" if rst == "FAIL" else f"NOT REACHED ({rst})",
                          "depth": int(fr.group(1)) if fr else None, "seconds": rsec})
            bad += rst != "FAIL"
        bad += st != "PASS"
        res["harnesses"][h] = {"description": desc, "properties": props, "engine": "abc pdr (unbounded)",
                               "result": st, "seconds": sec, "reach": reach}
        print(f"[formal] {h:15s} {st:5s} ({sec}s) reach={[r['result'] for r in reach]}", flush=True)
    prev = json.loads((OUT / "summary.json").read_text()) if (OUT / "summary.json").exists() else {}
    if "--skip-bmc" in sys.argv and "fv_ta_bmc" in prev.get("harnesses", {}):
        res["harnesses"]["fv_ta_bmc"] = prev["harnesses"]["fv_ta_bmc"]          # keep the recorded bounded run
        bad += not res["harnesses"]["fv_ta_bmc"]["result"].startswith("PASS")
    if "--skip-bmc" not in sys.argv:
        depth = int(re.search(r"^depth (\d+)", (FDIR / "fv_ta_bmc.sby").read_text(), re.M).group(1))
        st, sec, out = run("fv_ta_bmc", timeout=7200)
        res["harnesses"]["fv_ta_bmc"] = {
            "description": "whole silicaflux_test_access (2 groups, free JTAG / bus / lifecycle / pins, independent "
                           "clk and tck): lifecycle gate G1-G8 + every embedded TA and TestCore assertion",
            "properties": ["G1 scan mode only in a consistent DEV lifecycle", "G2 scan enable only in scan mode",
                           "G3 debug permission only in DEV", "G4 JTAG_ACCESS / DIAGNOSTIC only in DEV",
                           "G5 MBIST mode only with lifecycle permission (previous cycle)",
                           "G6 raw memory access only in test ownership",
                           "G7 unprivileged write outside DEV -> error", "G8 unprivileged group-page read outside DEV -> error",
                           "embedded: access gate (no JTAG forward outside DEV), collar, sequencer, register, mode "
                           "controller, MBIST engine, bank mux, ownership assertions"],
            "engine": f"smtbmc z3, BOUNDED: no counterexample in steps 0..{depth - 1} (not a proof)", "result": st,
            "bounded_depth": depth - 1, "seconds": sec}
        bad += st != "PASS"
        res["harnesses"]["fv_ta_bmc"]["result"] = "PASS (bounded)" if st == "PASS" else st
        print(f"[formal] fv_ta_bmc       {st:5s} ({sec}s, steps 0..{depth - 1})", flush=True)
    res["status"] = "PASS" if bad == 0 else "FAIL"
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "summary.json").write_text(json.dumps(res, indent=1))
    md = ["# Formal verification", "", f"Tools: {res['tools']['yosys']}; {res['tools']['sby']}", "",
          "| Harness | Engine | Result | Time (s) | Non-vacuity reach points |", "|---|---|---|---|---|"]
    for h, r in res["harnesses"].items():
        rp = ", ".join(f"#{x['point']} {x['result']}@{x['depth']}" for x in r.get("reach", [])) or "-"
        r.setdefault("seconds", None)
        md.append(f"| `{h}`: {r['description']} | {r['engine']} | **{r['result']}** | {r['seconds']} | {rp} |")
    md += ["", "Properties:", ""] + [f"* `{h}`: " + "; ".join(r["properties"]) for h, r in res["harnesses"].items()]
    md += ["", "Limits: proofs hold for the harness parameterisation (small banks / depths); synchronisers are ideal "
           "flops (no metastability); liveness is covered by simulation, not proven; the whole-block check is "
           "bounded.", "", f"Overall: **{res['status']}**"]
    (OUT / "summary.md").write_text("\n".join(md) + "\n")
    print(f"[formal] overall {res['status']}")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
