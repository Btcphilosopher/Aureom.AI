#!/usr/bin/env python3
"""Scan PLANNING for the SilicaFlux die partitions (no scan insertion).

    python3 scripts/scan_plan.py            (env: SFTA_YOSYS)

Elaborates the Project 31 die (vendored, unmodified: third_party/silicaflux-dietop)
in the MIN and HPC configurations with Yosys (`proc; memory -nomap`, hierarchy
kept) and counts, per module and with instance multiplicity per partition:
  * flip-flop bits   ($dff/$adff/$sdff/$dffe/... WIDTH)  -> scan cells
  * latch bits       ($dlatch/$adlatch/...)              -> scan-unfriendly, listed
  * memory-array bits ($mem_v2 WIDTH x SIZE)             -> MBIST / macro or RF
From the flip-flop bits it proposes chains (ceil(bits / max_length)) and scan
ports per partition.  Evidence class: PLANNING derived from RTL elaboration
(register counts are real Yosys counts of the RTL; chain counts are a proposal;
nothing is inserted, no scan cell exists for these partitions).
"""
import json, math, os, re, shutil, subprocess, sys, time
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIE = ROOT / "third_party" / "silicaflux-dietop"
OUT = ROOT / "reports" / "scan_plan"
YOSYS = os.environ.get("SFTA_YOSYS", shutil.which("yosys") or "yosys")
TOPS = {"MIN": "silicaflux_die_min", "HPC": "silicaflux_die_hpc"}
FF = {"$dff", "$dffe", "$adff", "$adffe", "$sdff", "$sdffe", "$sdffce", "$aldff", "$aldffe", "$dffsr", "$dffsre",
      "$ff"}
LATCH = {"$dlatch", "$adlatch", "$dlatchsr", "$sr"}
MEM = {"$mem", "$mem_v2"}
# brief section 5 targets -> die partitions (module names of the P31 hierarchy)
TARGETS = [
    ("ControlCore", ["control_subsystem"], "clk (ControlCore); acc_clk gate inside", "BLOCK"),
    ("Vector clusters", ["vector_cluster"], "acc_clk (ICG-gated copy of clk)", "BLOCK x N"),
    ("Tensor clusters", ["tensor_cluster"], "acc_clk (ICG-gated copy of clk)", "BLOCK x N"),
    ("DataFabric", ["datafabric"], "clk", "BLOCK"),
    ("DMA", ["dma_subsystem"], "clk", "BLOCK"),
    ("Control / status logic", ["die_sysctrl", "ras_test_subsystem", "die_regs_window", "clock_reset_subsystem",
                                "host_io_subsystem"], "clk (+ reset sequencer on clk)", "GLUE"),
    ("Shared memory subsystem (logic only)", ["memory_subsystem"], "clk (+ mc_clk if EXTMEM_ASYNC)", "BLOCK"),
]
MAXLEN = [200, 1000]


def filelist():
    incs, srcs = [], []
    for l in open(DIE / "rtl" / "files_die.f"):
        l = l.strip()
        if not l or l.startswith("//"):
            continue
        if l.startswith("+incdir+"):
            incs.append("-I" + str(DIE / l[8:]))
        else:
            srcs.append(str(DIE / l))
    return incs, srcs


def run(cfg, top):
    incs, srcs = filelist()
    OUT.mkdir(parents=True, exist_ok=True)
    js = OUT / f"{cfg}.json"
    script = (f"read_verilog -defer -sv -DSYNTHESIS {' '.join(incs)} {' '.join(srcs)}; "
              f"hierarchy -check -top {top}; proc; opt_clean; memory -nomap; opt_clean; write_json {js}")
    t0 = time.time()
    p = subprocess.run([YOSYS, "-q", "-l", str(OUT / f"{cfg}_yosys.log"), "-p", script], cwd=DIE,
                       capture_output=True, text=True)
    return p.returncode, round(time.time() - t0, 1), js


def base(name):
    m = re.search(r"\\([A-Za-z_][A-Za-z0-9_]*)", name)
    return m.group(1) if (name.startswith("$paramod") and m) else name.lstrip("\\")


def analyse(js, top):
    mods = json.load(open(js))["modules"]
    own = {}
    for mn, m in mods.items():
        ff = lat = mem = 0
        memlist, subs = [], []
        for cn, c in m.get("cells", {}).items():
            t = c["type"]
            prm = {k: int(v, 2) if isinstance(v, str) and set(v) <= {"0", "1"} else v
                   for k, v in c.get("parameters", {}).items()}
            if t in FF:
                ff += int(prm.get("WIDTH", 1))
            elif t in LATCH:
                lat += int(prm.get("WIDTH", 1))
            elif t in MEM:
                bits = int(prm.get("WIDTH", 0)) * int(prm.get("SIZE", 0))
                mem += bits
                memlist.append((cn, int(prm.get("WIDTH", 0)), int(prm.get("SIZE", 0))))
            elif t in mods:
                subs.append(t)
        own[mn] = {"ff": ff, "lat": lat, "mem": mem, "memlist": memlist, "subs": subs}
    memo = {}

    def tot(mn):
        if mn in memo:
            return memo[mn]
        o = own[mn]
        r = {"ff": o["ff"], "lat": o["lat"], "mem": o["mem"], "mems": [(base(mn), w, s) for _, w, s in o["memlist"]]}
        for s in o["subs"]:
            t = tot(s)
            r["ff"] += t["ff"]; r["lat"] += t["lat"]; r["mem"] += t["mem"]; r["mems"] = r["mems"] + t["mems"]
        memo[mn] = r
        return r

    # instances per partition module name (with multiplicity)
    inst = defaultdict(list)

    def walk(mn):
        for s in own[mn]["subs"]:
            inst[base(s)].append(s)
            walk(s)
    walk(top)
    return tot(top), {k: [tot(m) for m in v] for k, v in inst.items()}


def main():
    res = {"evidence_class": "SCAN PLANNING from RTL elaboration (Yosys); no scan insertion on these partitions",
           "yosys": subprocess.run([YOSYS, "-V"], capture_output=True, text=True).stdout.strip(),
           "max_chain_lengths": MAXLEN, "configs": {}}
    for cfg, top in TOPS.items():
        rc, sec, js = run(cfg, top)
        if rc:
            res["configs"][cfg] = {"status": "ERROR", "log": str(OUT / f"{cfg}_yosys.log")}
            print(f"[scan_plan] {cfg}: Yosys failed")
            continue
        total, inst = analyse(js, top)
        rows = []
        for name, parts, clk, kind in TARGETS:
            n_inst = sum(len(inst.get(p, [])) for p in parts)
            ff = sum(t["ff"] for p in parts for t in inst.get(p, []))
            lat = sum(t["lat"] for p in parts for t in inst.get(p, []))
            mem = sum(t["mem"] for p in parts for t in inst.get(p, []))
            arrays = defaultdict(lambda: [0, 0])
            for p in parts:
                for t in inst.get(p, []):
                    for mname, w, s in t["mems"]:
                        a = arrays[f"{mname} {w}x{s}"]
                        a[0] += 1; a[1] += w * s
            rows.append({"target": name, "partitions": parts, "instances": n_inst, "clock": clk, "kind": kind,
                         "ff_bits": ff, "latch_bits": lat, "mem_bits": mem,
                         "chains": {str(L): math.ceil(ff / L) if ff else 0 for L in MAXLEN},
                         "arrays": {k: {"count": v[0], "bits": v[1]} for k, v in sorted(arrays.items())}})
        res["configs"][cfg] = {"status": "OK", "top": top, "yosys_seconds": sec, "die_ff_bits": total["ff"],
                               "die_latch_bits": total["lat"], "die_mem_bits": total["mem"], "targets": rows}
        print(f"[scan_plan] {cfg}: die flip-flop bits {total['ff']}, latch bits {total['lat']}, "
              f"memory-array bits {total['mem']} ({sec}s)")
    (OUT / "scan_plan.json").write_text(json.dumps(res, indent=1))
    for cfg in TOPS:
        p = OUT / f"{cfg}.json"
        if p.exists():
            p.unlink()                                       # large intermediate; regenerated on demand
    return 0 if all(c.get("status") == "OK" for c in res["configs"].values()) else 1


if __name__ == "__main__":
    sys.exit(main())
