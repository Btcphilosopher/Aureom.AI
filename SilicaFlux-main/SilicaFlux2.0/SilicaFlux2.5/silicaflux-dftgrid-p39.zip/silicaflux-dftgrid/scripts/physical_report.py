#!/usr/bin/env python3
"""DFT physical-connectivity report.

    python3 scripts/physical_report.py

Sources (all generated or vendored data -- nothing is estimated unless marked):
  * reports/dft/scan_netlist.v, openroad_scan.log, scan_summary.json  (OpenROAD scan insertion)
  * reports/floorplan/ta_placed.def, place_ta.log                      (OpenROAD placement experiment)
  * third_party/silicaflux-sramgrid/physical/placement/<cfg>/<strategy>/placement.json  (P33, real IHP LEF outlines)
  * third_party/silicaflux-sramgrid/physical/abstracts/*.json          (P33, parsed vendor LEF)
  * third_party/silicaflux-sramgrid/reports/connectivity_<cfg>.json    (P33, synthesized-netlist pin resolution)
  * third_party/silicaflux-clocktree/rtl/silicaflux_clock_reset_tree.sv (P35 DFT control destinations)
  * reports/scan_plan/scan_plan.json                                   (this project, Yosys register counts)
Writes reports/physical/physical_connectivity.{json,md}.
Distances are Manhattan distances between placed coordinates, NOT extracted wire delay.
"""
import gzip, json, re, statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reports" / "physical"
SG = ROOT / "third_party" / "silicaflux-sramgrid"


def ta_block():
    net = (ROOT / "reports/dft/scan_netlist.v").read_text()
    log = (ROOT / "reports/dft/openroad_scan.log").read_text()
    summ = json.loads((ROOT / "reports/dft/scan_summary.json").read_text())
    place = (ROOT / "reports/floorplan/place_ta.log").read_text()
    dp = ROOT / "reports/floorplan/ta_placed.def"           # the archive ships only the .gz copy
    deff = dp.read_text() if dp.exists() else gzip.decompress((dp.parent / (dp.name + ".gz")).read_bytes()).decode()
    units = int(re.search(r"UNITS DISTANCE MICRONS (\d+)", deff).group(1))
    die = [int(x) / units for x in re.search(r"DIEAREA \( (\d+) (\d+) \) \( (\d+) (\d+) \)", deff).groups()]
    comp = {}
    for m in re.finditer(r"^\s+- (\S+) (\S+) \+ (?:PLACED|FIXED) \( (-?\d+) (-?\d+) \) (\S+)", deff, re.M):
        comp[m.group(1).replace("\\", "")] = (int(m.group(3)) / units, int(m.group(4)) / units, m.group(2))
    pins = {}
    for m in re.finditer(r"^\s+- (\S+) \+ NET \S+.*?\+ (?:PLACED|FIXED) \( (-?\d+) (-?\d+) \)", deff, re.M | re.S):
        pins[m.group(1)] = (int(m.group(2)) / units, int(m.group(3)) / units)
    fan = {
        "scan_enable_0 (SCE pins)": len(re.findall(r"\.SCE\(scan_enable_0\)", net)),
        "clk (CLK pins)": len(re.findall(r"\.CLK\(clk\)", net)),
        "tck (CLK pins, rising)": len(re.findall(r"\.CLK\(tck\)", net)),
        "tck (CLK_N pins, falling)": len(re.findall(r"\.CLK_N\(tck\)", net)),
        "rst_n (RESET_B / SET_B)": len(re.findall(r"\.(?:RESET_B|SET_B)\(rst_n\)", net)),
        "trst_n (RESET_B / SET_B)": len(re.findall(r"\.(?:RESET_B|SET_B)\(trst_n\)", net)),
    }
    chains = []
    for m in re.finditer(r"Scan chain '(chain_\d+)' has (\d+) cells[^\n]*\n\n((?:  \S+[^\n]*\n)+)", log):
        cells = [l.split()[0] for l in m.group(3).strip("\n").split("\n")]
        info = next(c for c in summ["chains"] if c["name"] == m.group(1))
        xy = [comp.get(c) for c in cells]
        wl = sum(abs(a[0] - b[0]) + abs(a[1] - b[1]) for a, b in zip(xy, xy[1:]) if a and b)
        si, so = f"scan_in_{info['port']}", info.get("scan_out", f"scan_out_{info['port']}")
        chains.append({"chain": m.group(1), "scan_in": si, "scan_out": so, "length": int(m.group(2)),
                       "clock": f"{info['clock']}/{info['edge']}", "first_cell": cells[0], "last_cell": cells[-1],
                       "first_xy_um": xy[0][:2] if xy[0] else None, "last_xy_um": xy[-1][:2] if xy[-1] else None,
                       "scan_in_pin_xy_um": pins.get(si), "scan_out_pin_xy_um": pins.get(so),
                       "shared_functional_scan_out": bool(info.get("shared_functional_scan_out")),
                       "stitch_manhattan_um": round(wl, 1)})
    chains.sort(key=lambda c: int(c["scan_in"].split("_")[-1]))
    g = lambda k: re.search(k, place)
    timing = {"functional_100MHz_setup_ns": float(re.search(r"SFTA_TIMING_FUNCTIONAL\nworst slack max (-?[\d.]+)", place).group(1)),
              "functional_hold_ns": float(re.search(r"SFTA_TIMING_FUNCTIONAL\nworst slack max -?[\d.]+\nworst slack min (-?[\d.]+)", place).group(1)),
              "shift_50MHz_setup_ns": float(re.search(r"SFTA_TIMING_SHIFT\nworst slack max (-?[\d.]+)", place).group(1)),
              "shift_hold_ns": float(re.search(r"SFTA_TIMING_SHIFT\nworst slack max -?[\d.]+\nworst slack min (-?[\d.]+)", place).group(1))}
    area = [float(x) for x in re.findall(r"Design area (\d+) um\^2", place)]
    hpwl = g(r"legalized HPWL\s+([\d.]+) u")
    return {"die_um": die[2:], "cells_placed": len(comp), "std_cell_area_um2_pre_repair": area[0] if area else None,
            "std_cell_area_um2_post_repair": area[-1] if area else None,
            "legalized_hpwl_um": float(hpwl.group(1)) if hpwl else None, "timing": timing,
            "fanout": fan, "chains": chains, "scan_summary": {k: summ[k] for k in
            ("chain_count", "total_scan_cells", "scan_flop_cells", "non_scan_flop_cells", "continuity")}}


def l1median(pts):
    return (statistics.median(p[0] for p in pts), statistics.median(p[1] for p in pts))


def memory_mbist():
    res = {}
    for cfg in ("sg_min4", "sg_hier"):
        conn = json.loads((SG / f"reports/connectivity_{cfg}.json").read_text())
        res[cfg] = {"strategies": {}, "connectivity_ok": conn.get("ok"), "anomalies": len(conn.get("anomalies", []))}
        bist = {}
        for strat_dir in sorted((SG / "physical/placement" / cfg).iterdir()):
            if not strat_dir.is_dir():
                continue
            pl = json.loads((strat_dir / "placement.json").read_text())
            macros = pl["macros"]
            pts = [tuple(m["pin_point"]) for m in macros]
            c = l1median(pts)
            dist = [abs(p[0] - c[0]) + abs(p[1] - c[1]) for p in pts]
            per_bank = {}
            for m, d in zip(macros, dist):
                b = per_bank.setdefault(m["bank"], {"macros": 0, "max_um": 0.0, "region": m.get("region")})
                b["macros"] += 1; b["max_um"] = round(max(b["max_um"], d), 1)
            # alternative: one controller per region (P33 regions)
            regions = {}
            for m in macros:
                regions.setdefault(m.get("region"), []).append(tuple(m["pin_point"]))
            per_region = {}
            for r, rp in regions.items():
                rc = l1median(rp)
                rd = [abs(p[0] - rc[0]) + abs(p[1] - rc[1]) for p in rp]
                per_region[r] = {"macros": len(rp), "candidate_xy_um": [round(rc[0], 1), round(rc[1], 1)],
                                 "max_um": round(max(rd), 1), "mean_um": round(sum(rd) / len(rd), 1)}
            res[cfg]["strategies"][strat_dir.name] = {
                "die_um": pl["die"][2:], "macros": len(macros), "banks": len(per_bank),
                "candidate_xy_um": [round(c[0], 1), round(c[1], 1)],
                "max_um": round(max(dist), 1), "mean_um": round(sum(dist) / len(dist), 1),
                "per_bank": {str(k): v for k, v in sorted(per_bank.items())}, "per_region": per_region}
            if not bist:
                for m in macros:
                    bist[m["master"]] = bist.get(m["master"], 0) + 1
        abst = {}
        for master, n in bist.items():
            a = json.loads((SG / "physical/abstracts" / f"{master}.json").read_text())
            bp = sorted({re.sub(r"\[\d+\]", "", p) for p in a["pins"] if "BIST" in p})
            abst[master] = {"instances": n, "bist_pins_per_macro": sum(1 for p in a["pins"] if "BIST" in p),
                            "bist_pin_groups": bp, "signal_pin_edge": a.get("signal_pin_edge"),
                            "signal_pin_layers": a.get("signal_pin_layers"), "size_um": [a["width_um"], a["height_um"]]}
        res[cfg]["macro_test_pins"] = abst
        # pin-level resolution of the synthesized netlist (P33): every BIST pin bit tied, A_DLY tied 1
        ties = {}
        for inst in conn.get("instances", []):
            for pn, pv in inst.get("pins", {}).items():
                if "BIST" in pn or pn == "A_DLY":
                    t = ties.setdefault(pn, {"instances": 0, "bits": 0, "const0": 0, "const1": 0, "nets": 0})
                    t["instances"] += 1
                    for k in ("const0", "const1", "nets"):
                        t[k] += pv.get(k, 0)
                    t["bits"] += pv.get("width", 0)
        ties = {k: (f"{k}: {v['bits']} bits over {v['instances']} macros, {v['const0']} tied 0, {v['const1']} tied 1, "
                    f"{v['nets']} driven by logic") for k, v in sorted(ties.items())}
        res[cfg]["macro_tieoffs_in_netlist"] = list(ties.values())
    return res


def clock_tree_destinations():
    src = (ROOT / "third_party/silicaflux-clocktree/rtl/silicaflux_clock_reset_tree.sv").read_text()
    body = src.split("module silicaflux_clock_reset_tree", 1)[1]
    return {"reset_synchronisers_with_test_bypass": len(re.findall(r"sf_crt_rst_sync\s*#?", body)),
            "dft_reset_muxes": len(re.findall(r"sf_crt_dft_mux\s", body)),
            "icg_instances (root + branch generate)": len(re.findall(r"sf_crt_clk_gate\s|sf_crt_branch_gate\s", body)),
            "note": "instance statements in the P35 RTL; the branch ones are inside generate loops (x NB). "
                    "test_mode_i drives every reset synchroniser's DFT mux, test_en_i every ICG SE pin."}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    plan = json.loads((ROOT / "reports/scan_plan/scan_plan.json").read_text())
    r = {"evidence_classes": {
            "test_access_block": "OpenROAD scan insertion + placement experiment (sky130hd, estimated parasitics)",
            "memory_to_mbist": "geometry of the P33 macro placements (real IHP LEF outlines, planning die/blocks)",
            "chip_scan_endpoints": "PLANNING (Yosys register counts, no insertion)"},
         "test_access_block": ta_block(), "memory_mbist": memory_mbist(),
         "clock_tree_test_controls": clock_tree_destinations(), "scan_plan": plan}
    (OUT / "physical_connectivity.json").write_text(json.dumps(r, indent=1))
    t = r["test_access_block"]
    md = ["# DFT physical-connectivity report", "",
          "Generated by `scripts/physical_report.py` from tool output and vendored placement data. "
          "Distances are Manhattan distances between placed coordinates, **not extracted wire delay**. "
          "Nothing here is a silicon, timing-closure or area sign-off claim.", "",
          "## 1. Test-access block (`silicaflux_test_access`, verified 3-group configuration)", "",
          f"Evidence: OpenROAD 26Q3 scan insertion on the Yosys sky130hd netlist, then a placement experiment "
          f"(floorplan 40 % utilisation, global + detailed placement, `repair_design`, parasitics estimated from placement; "
          f"no CTS, no routing).", "",
          "| Item | Value |", "|---|---|",
          f"| Placed block (die) | {t['die_um'][0]:.0f} x {t['die_um'][1]:.0f} µm |",
          f"| Standard-cell area before / after buffering | {t['std_cell_area_um2_pre_repair']:.0f} / {t['std_cell_area_um2_post_repair']:.0f} µm² |",
          f"| Legalised HPWL | {t['legalized_hpwl_um']:.0f} µm |",
          f"| Functional mode, 10 ns clk: setup / hold worst slack | {t['timing']['functional_100MHz_setup_ns']:+.3f} / {t['timing']['functional_hold_ns']:+.3f} ns |",
          f"| Scan shift, 20 ns clk and tck: setup / hold worst slack | {t['timing']['shift_50MHz_setup_ns']:+.3f} / {t['timing']['shift_hold_ns']:+.3f} ns |",
          f"| Scan cells / non-scan flops | {t['scan_summary']['scan_flop_cells']} / {t['scan_summary']['non_scan_flop_cells']} |",
          f"| Chains (gate-level continuity) | {t['scan_summary']['chain_count']} ({t['scan_summary']['continuity']}) |",
          "", "Timing uses ideal clocks (no CTS) and placement-estimated parasitics: hold slack in particular is "
          "not sign-off (clock skew is not modelled).", "",
          "### Test-control fanout (logical, scan netlist)", "", "| Net | Loads |", "|---|---|"]
    md += [f"| `{k.split(' ')[0]}` {k[len(k.split(' ')[0]):]} | {v} |" for k, v in t["fanout"].items()]
    md += ["", "`scan_enable_0` is a single net to every scan cell: `repair_design` buffered it in the placement "
           "experiment; in a chip it must be a balanced, timed tree (shift and capture SDC).", "",
           "### Scan-chain endpoints", "",
           "| Chain | scan_in / scan_out | Length | Clock | First cell (x, y µm) | Last cell (x, y µm) | Stitch length (µm, Manhattan) |",
           "|---|---|---|---|---|---|---|"]
    for c in t["chains"]:
        fx = f"{c['first_xy_um'][0]:.0f}, {c['first_xy_um'][1]:.0f}" if c["first_xy_um"] else "-"
        lx = f"{c['last_xy_um'][0]:.0f}, {c['last_xy_um'][1]:.0f}" if c["last_xy_um"] else "-"
        md.append(f"| {c['chain']} | `{c['scan_in']}` / `{c['scan_out']}` | {c['length']} | {c['clock']} | "
                  f"{fx} | {lx} | {c['stitch_manhattan_um']:.0f} |")
    md += ["", "OpenROAD numbers the scan ports in lexicographic order of the chain names (chain_10 -> port 2), and "
           "reuses a functional output as the scan-out when a chain's last flop already drives a primary output "
           "(shared scan-out, e.g. `ras_ev_info[6]`); "
           "the table maps them structurally (SCD pin of the first cell). Chains were stitched without "
           "placement-aware ordering, which is why stitch lengths are long; reordering after placement is a "
           "production-flow step.", ""]
    mm = r["memory_mbist"]
    md += ["## 2. MBIST controller placement candidates and memory-to-MBIST distance (P33 SRAM grid)", "",
           "Candidate = L1 median of the macros' signal-pin edge midpoints (minimises total Manhattan distance). "
           "Macro outlines and pin edges come from the vendor LEF (via P33); die size and logic outlines of the "
           "P33 floorplans are planning assumptions.", ""]
    for cfg, v in mm.items():
        md += [f"### `{cfg}` (connectivity of {sum(a['instances'] for a in v['macro_test_pins'].values())} macros: "
               f"{'OK' if v['connectivity_ok'] else 'NOT OK'}, {v['anomalies']} anomalies)", "",
               "| Placement strategy | Macros | Banks | One controller at (x, y µm) | Max / mean distance (µm) | Per-region controllers: worst max distance (µm) |",
               "|---|---|---|---|---|---|"]
        for s, d in v["strategies"].items():
            wr = max(x["max_um"] for x in d["per_region"].values())
            md.append(f"| {s} | {d['macros']} | {d['banks']} | {d['candidate_xy_um'][0]:.0f}, {d['candidate_xy_um'][1]:.0f} | "
                      f"{d['max_um']:.0f} / {d['mean_um']:.0f} | {wr:.0f} ({len(d['per_region'])} regions) |")
        md += [""]
        for m, a in v["macro_test_pins"].items():
            md.append(f"* Macro test signals, `{m}` x {a['instances']}: {a['bist_pins_per_macro']} BIST pins per macro "
                      f"({', '.join(a['bist_pin_groups'])}); signal pins on the {a['signal_pin_edge']} edge "
                      f"({', '.join(a['signal_pin_layers'])}).")
        md += ["", "Macro test-pin resolution in the P33 synthesized netlist:", ""]
        md += [f"* {t}" for t in v["macro_tieoffs_in_netlist"]]
        md += ["", "The macro-internal BIST multiplexer is not used (every BIST pin tied off): MBIST reaches the "
               "macros through the wrapper's test port on the raw stored word (data + check bits)."]
        md += [""]
    md += ["The MBIST engine reaches its collar through the TestCore bank bus; `G_PIPE_REQ` / `G_PIPE_RSP` add a "
           "register stage each way (verified in simulation for group 2: read cost 1 + L + 2, write cost 2). "
           "The number of stages for a given distance must come from post-placement STA, not from this table.", "",
           "MemoryCore slices of the P31 die have **no floorplan data** in the repository; their controller "
           "placement is planning only (adjacent to each slice).", "",
           "## 3. Test clock paths and test-control destinations", "",
           "| Path | Source | Destination | Notes |", "|---|---|---|---|",
           "| JTAG | TCK pin | TAP + TCK side of the CDC bridge (`tck` rising and falling flops) | asynchronous to clk; "
           "own chains (rising, falling); no clock mux |",
           "| MBIST / functional | clk (P35 `clk_core_o` or branch) | engines, collars, registers, memories | same clock as the "
           "memories; MBIST at functional speed; `mbist_clk_req[g]` keeps the branch running |",
           "| Scan shift / capture | functional clock pin (PLL bypass in the clock-root / PLL IP) | every scan cell | "
           "`dft_icg_te` = scan_mode opens every ICG (P35 `test_en_i`) |",
           f"| Reset in scan | TEST_RST_N pin -> `dft_test_rst_n` | P35 reset synchronisers via DFT muxes | "
           f"{r['clock_tree_test_controls']['reset_synchronisers_with_test_bypass']} synchroniser and "
           f"{r['clock_tree_test_controls']['dft_reset_muxes']} DFT-mux instance statements in P35 (x NB in generate) |",
           "| ICG transparency | `dft_icg_te` | P35 root + branch ICG SE pins | "
           f"{r['clock_tree_test_controls']['icg_instances (root + branch generate)']} ICG instance statements in P35 |",
           "| Memory protection in scan | `dft_mem_inhibit` | memory wrappers' CE gating (integration) | keeps scan "
           "toggling from writing macros |", "",
           "No clock multiplexer exists in the test-access RTL (`grep` of `rtl/`; Yosys mapped no MUX on a clock net).",
           "", "## 4. Required test pins", "",
           "| Pin | Direction | Purpose | Required |", "|---|---|---|---|",
           "| TCK, TMS, TDI | in | JTAG | yes |", "| TDO | out (tri-state via TDO_OE) | JTAG | yes |",
           "| TRST_N | in | JTAG reset (else POR-only TAP reset) | recommended |",
           "| TEST_MODE | in | scan mode (honoured in DEV only) | yes |", "| SCAN_EN | in | shift / capture | yes |",
           "| TEST_RST_N | in | reset control during scan | yes |",
           "| SCAN_IN[k] / SCAN_OUT[k] | in / out | scan data; muxed on GPIO in TEST_MODE | yes (count below) |",
           "| TEST_DONE / TEST_PASS / TEST_FAIL | out | MBIST sequence status for wafer probe | recommended |",
           "| CLK, RST_N | in | existing functional pins (scan clock through PLL bypass) | existing |", ""]
    md += ["## 5. Scan-chain endpoints at chip level (PLANNING)", "",
           "Register counts are Yosys counts of the P31 die RTL; chain counts are proposals at the chain length shown. "
           "No scan cell exists for these partitions.", ""]
    for cfg, v in plan["configs"].items():
        if v.get("status") != "OK":
            continue
        md += [f"### {cfg} (`{v['top']}`): {v['die_ff_bits']} flip-flop bits, {v['die_latch_bits']} latch bit(s), "
               f"{v['die_mem_bits']} memory-array bits", "",
               "| Target | Instances | Clock | Flip-flop bits | Chains @200 | Chains @1000 | Memory-array bits (MBIST / RF) |",
               "|---|---|---|---|---|---|---|"]
        for t2 in v["targets"]:
            md.append(f"| {t2['target']} | {t2['instances']} | {t2['clock']} | {t2['ff_bits']} | {t2['chains']['200']} | "
                      f"{t2['chains']['1000']} | {t2['mem_bits']} |")
        md += [""]
    (OUT / "physical_connectivity.md").write_text("\n".join(md) + "\n")
    print(f"[physical] chains {t['scan_summary']['chain_count']}, block {t['die_um'][0]:.0f}x{t['die_um'][1]:.0f} um, "
          f"sg_min4 central max distance {mm['sg_min4']['strategies']['central_shared']['max_um']} um")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
