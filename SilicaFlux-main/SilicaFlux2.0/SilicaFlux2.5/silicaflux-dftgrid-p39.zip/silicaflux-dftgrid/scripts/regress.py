#!/usr/bin/env python3
"""Project 39 DFTGRID regression.

    python3 scripts/regress.py [--only step,step] [--skip step,step] [-j N]

Steps (evidence class in brackets):
  tools        tool versions                                     [environment]
  hashes       vendored sources byte-identical to SHA256SUMS      [provenance]
  regmap       generated register map / C header up to date       [consistency]
  lint         Verilator -Wall (synthesis + simulation view), Icarus, Yosys 0.33 + 0.70 elaboration [static]
  illegal      illegal parameter sets refused at elaboration      [static]
  sim_icarus   tb_ta_sys (14 tests) + tb_ta_clktree, Icarus 12    [functional simulation]
  sim_verilator same, Verilator 5.020 --timing                    [functional simulation]
  xsim         identical check counts / cycle results in both simulators [cross-simulation]
  coverage     functional coverage merged over the Verilator runs [coverage]
  synth        Yosys 0.70 -> sky130hd + OpenSTA                   [logic synthesis, pre-placement STA]
  scan         OpenROAD scan insertion + gate-level chain continuity [DFT]
  place        OpenROAD placement experiment                      [physical experiment]
  scanplan     Yosys register counts of the P31 die partitions    [planning]
  physical     DFT physical-connectivity report                   [report]
  formal       SymbiYosys (collects reports/formal/summary.json; run scripts/run_formal.py) [formal]
  mutation     collects reports/mutation/mutation.json (run scripts/mutate.py)              [mutation]
  codecov      collects reports/coverage/code_coverage.json (run scripts/code_coverage.py)  [coverage]
Steps whose tools are missing report BLOCKED, never PASS.  Results: reports/REGRESSION.md, reports/regression.json.
"""
import argparse, concurrent.futures as cf, hashlib, json, os, re, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REP = ROOT / "reports"
LOG = REP / "logs"
BUILD = ROOT / "build"
TESTS = ["jtag_tap", "lc_policy", "mbist_select", "algorithms", "func_switch", "faults", "ordering", "timeout",
         "reset_in_test", "secure_debug", "error_prop", "recovery", "abort_protect", "dft_clkrst"]
NIX = {"yosys70": os.environ.get("SFTA_YOSYS", "/nix/store/cfry5mn7l5qk6cy730gspaa51fahc108-yosys-0.70/bin/yosys"),
       "openroad": os.environ.get("SFTA_OPENROAD", "/nix/store/6qbn5zjnnnyna6md4rsmiqw4y26y8556-openroad-26Q3/bin/openroad"),
       "sta": os.environ.get("SFTA_STA", "/nix/store/6qbn5zjnnnyna6md4rsmiqw4y26y8556-openroad-26Q3/bin/sta")}
IV = ["iverilog", "-g2012", "-Wno-timescale", "-Wno-portbind", "-DSFTC_FATAL_ASSERT"]
VLF = ["verilator", "--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-UNOPTFLAT",
       "-Wno-MULTIDRIVEN", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-DSFTC_FATAL_ASSERT"]


def sh(cmd, log, cwd=ROOT, timeout=7200, env=None):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env,
                           shell=isinstance(cmd, str))
        out, rc = p.stdout + p.stderr, p.returncode
    except subprocess.TimeoutExpired:
        out, rc = "TIMEOUT", 124
    (LOG / log).write_text((cmd if isinstance(cmd, str) else " ".join(cmd)) + "\n" + out)
    return rc, out, round(time.time() - t0, 1)


def have(x):
    return shutil.which(x) or (os.path.exists(x) and x)


def ver(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True).stdout.strip().splitlines()[0]
    except Exception:
        return "unavailable"


def st_tools():
    v = {"iverilog": ver(["iverilog", "-V"]), "verilator": ver(["verilator", "--version"]),
         "yosys_0.33": ver(["yosys", "-V"]), "yosys_0.70": ver([NIX["yosys70"], "-V"]),
         "openroad": ver([NIX["openroad"], "-version"]), "sby": ver(["sby", "--version"]),
         "python": sys.version.split()[0]}
    if "unknown" in v["sby"] and shutil.which("sby"):      # nixpkgs sby reports no version: use the store path
        m = re.search(r"-sby-([\d.]+)/", str(Path(shutil.which("sby")).resolve()))
        v["sby"] = f"SBY {m.group(1)} (nixpkgs)" if m else v["sby"]
    return "PASS", v


def st_hashes():
    f = ROOT / "third_party" / "SHA256SUMS"
    if not f.exists():
        return "FAIL", {"reason": "third_party/SHA256SUMS missing"}
    bad, n = [], 0
    for l in f.read_text().splitlines():
        if not l.strip():
            continue
        h, p = l.split(None, 1)
        n += 1
        q = ROOT / "third_party" / p.strip()
        if not q.exists() or hashlib.sha256(q.read_bytes()).hexdigest() != h:
            bad.append(p)
    return ("PASS" if not bad else "FAIL"), {"files": n, "mismatch": bad[:20]}


def st_regmap():
    rc, out, s = sh([sys.executable, "scripts/gen_regmap.py", "--check"], "regmap.log")
    return ("PASS" if rc == 0 else "FAIL"), {"output": out.strip().splitlines()[-1], "seconds": s}


def st_lint():
    r = {}
    files = [l.strip() for l in (ROOT / "rtl/files_ta.f").read_text().splitlines()
             if l.strip() and not l.startswith(("//", "+"))]
    for view, d in (("verilator_synthesis_view", ["-DSYNTHESIS"]), ("verilator_simulation_view", [])):
        rc, out, s = sh(["verilator", "--lint-only", "-Wall", "-Wno-UNUSEDPARAM", *d, "--top-module",
                         "silicaflux_test_access", "rtl/lint.vlt", "-f", "rtl/files_ta.f"], f"lint_{view}.log")
        r[view] = {"warnings": len(re.findall(r"^%Warning", out, re.M)), "errors": len(re.findall(r"^%Error", out, re.M))}
    rc, out, s = sh(IV + ["-Wall", "-o", str(BUILD / "lint_ta.vvp"), "-s", "silicaflux_test_access", "-c", "rtl/files_ta.f"],
                    "lint_icarus.log")
    own = [l for l in out.splitlines() if "warning" in l.lower() and "third_party" not in l]
    r["icarus"] = {"exit": rc, "warnings_in_new_rtl": len(own)}
    for tag, y in (("yosys_0.33", "yosys"), ("yosys_0.70", NIX["yosys70"])):
        rc, out, s = sh([y, "-q", "-p", f"read_verilog -sv -DSYNTHESIS -Irtl -Ithird_party/silicaflux-testcore/rtl/testcore "
                         f"{' '.join(files)}; hierarchy -check -top silicaflux_test_access; proc"], f"lint_{tag}.log")
        r[tag] = {"exit": rc}
    ok = all(v.get("warnings", 0) == 0 and v.get("errors", 0) == 0 for k, v in r.items() if k.startswith("verilator")) \
        and r["icarus"]["exit"] == 0 and r["icarus"]["warnings_in_new_rtl"] == 0 and \
        r["yosys_0.33"]["exit"] == 0 and r["yosys_0.70"]["exit"] == 0
    return ("PASS" if ok else "FAIL"), r


ILLEGAL = [
    ("collar LAT=0", "sfta_group_collar", ["-GLAT=0"]),
    ("collar INIT_MODE=3", "sfta_group_collar", ["-GINIT_MODE=3"]),
    ("collar self-init with INIT_ON_RESET", "sfta_group_collar", ["-GINIT_MODE=2", "-GINIT_ON_RESET=1"]),
    ("collar OWN_TIMEOUT below the sweep length", "sfta_group_collar", ["-GOWN_TIMEOUT=100"]),
    ("collar MAX_W < SW", "sfta_group_collar", ["-GMAX_W=8"]),
    ("collar NB=0", "sfta_group_collar", ["-GNB=0"]),
    ("sequencer NG=8", "sfta_seq", ["-GNG=8"]),
    ("test access NG=8", "silicaflux_test_access", ["-GNG=8"]),
    ("test access group wider than MAXSW", "silicaflux_test_access", ["-GMAXSW=64"]),
    ("test access deeper than MAXRAW", "silicaflux_test_access", ["-GMAXRAW=8"]),
]


def st_illegal():
    """Legal configuration: lint-clean.  Each illegal set: elaboration must report the RTL's own $error."""
    rows, ok = [], True
    lint = ["verilator", "--lint-only", "-Wall", "-Wno-UNUSEDPARAM"]
    rc, out, s = sh(lint + ["--top-module", "silicaflux_test_access", "rtl/lint.vlt", "-f", "rtl/files_ta.f"],
                    "illegal_baseline.log")
    base_ok = rc == 0 and "USERERROR" not in out
    for name, top, g in ILLEGAL:
        rc, out, s = sh(lint + ["--top-module", top, *g, "rtl/lint.vlt", "-f", "rtl/files_ta.f"],
                        f"illegal_{re.sub(r'\W+', '_', name)}.log")
        msg = re.search(r"%(?:Warning-USERERROR|Error)[^\n]*?: ((?:sfta_|silicaflux_)\w+: [^\n]*)", out)
        refused = rc != 0 and msg is not None
        rows.append({"case": name, "params": g, "refused": refused, "message": msg.group(1) if msg else None})
        ok &= refused
    return ("PASS" if ok and base_ok else "FAIL"), {"legal_baseline_lint_clean": base_ok, "cases": rows,
                                                     "refused": sum(r["refused"] for r in rows), "total": len(rows)}


def parse_test(out):
    m = re.search(r"TEST (\w+) RESULT (PASS|FAIL) checks=(\d+) errors=(\d+)", out)
    mm = re.search(r"master_checks=(\d+) master_errors=(\d+)", out)
    keys = sorted(set(l for l in out.splitlines() if l.startswith(("MBIST_CYCLES", "ALG_CYCLES", "ORDER", "FAULT ",
                                                                   "LC_MATRIX", "COVERAGE", "FUNC_SWITCH"))))
    cov = [l for l in out.splitlines() if l.startswith("COV ")]
    return {"result": m.group(2) if m else "FAIL", "checks": int(m.group(3)) if m else 0,
            "errors": int(m.group(4)) if m else -1, "assertion": "SFTC_ASSERTION_FAILED" in out, "key_lines": keys,
            "master_checks": int(mm.group(1)) if mm else None, "master_errors": int(mm.group(2)) if mm else None,
            "cov": cov}


def st_sim(sim, jobs):
    BUILD.mkdir(exist_ok=True)
    res = {}
    if sim == "icarus":
        rc, out, s = sh(IV + ["-o", str(BUILD / "tb_ta_sys.vvp"), "-s", "tb_ta_sys", "-c", "rtl/files_ta.f", "-c",
                              "tb/files_tb.f"], "build_icarus_sys.log")
        rc2, out2, s2 = sh(IV + ["-o", str(BUILD / "tb_ta_clktree.vvp"), "-s", "tb_ta_clktree", "-c", "rtl/files_ta.f",
                                 "-c", "tb/files_clktree.f", "tb/tb_ta_clktree.sv"], "build_icarus_clktree.log")
        run = lambda t: ["vvp", "-n", str(BUILD / "tb_ta_sys.vvp"), f"+TEST={t}"]
        runct = ["vvp", "-n", str(BUILD / "tb_ta_clktree.vvp")]
    else:
        rc, out, s = sh(VLF + ["--top-module", "tb_ta_sys", "-Mdir", str(BUILD / "vl_sys"), "-o", "vl_tb", "rtl/lint.vlt",
                               "-f", "rtl/files_ta.f", "-f", "tb/files_tb.f"], "build_verilator_sys.log")
        rc2, out2, s2 = sh(VLF + ["--top-module", "tb_ta_clktree", "-Mdir", str(BUILD / "vl_ct"), "-o", "vl_ct",
                                  "rtl/lint.vlt", "-f", "rtl/files_ta.f", "-f", "tb/files_clktree.f", "tb/tb_ta_clktree.sv"],
                            "build_verilator_clktree.log")
        run = lambda t: [str(BUILD / "vl_sys" / "vl_tb"), f"+TEST={t}"]
        runct = [str(BUILD / "vl_ct" / "vl_ct")]
    if rc or rc2:
        return "FAIL", {"build": "FAILED", "seconds": s + s2}
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        fut = {t: ex.submit(sh, run(t), f"{sim}_{t}.log") for t in TESTS}
        fut["ta_clktree"] = ex.submit(sh, runct, f"{sim}_ta_clktree.log")
        for t, f in fut.items():
            rc, out, s = f.result()
            r = parse_test(out)
            r["seconds"] = s
            res[t] = r
    ok = all(r["result"] == "PASS" and not r["assertion"] for r in res.values())
    return ("PASS" if ok else "FAIL"), {"build_seconds": s, "tests": res,
                                        "passed": sum(r["result"] == "PASS" for r in res.values()), "total": len(res),
                                        "checks": sum(r["checks"] for r in res.values())}


def st_xsim(results):
    a, b = results.get("sim_icarus", {}).get("data", {}).get("tests"), results.get("sim_verilator", {}).get("data", {}).get("tests")
    if not a or not b:
        return "BLOCKED", {"reason": "needs both simulators"}
    rows, ok = [], True
    for t in a:
        same = a[t]["checks"] == b[t]["checks"] and a[t]["key_lines"] == b[t]["key_lines"]
        rows.append({"test": t, "icarus_checks": a[t]["checks"], "verilator_checks": b[t]["checks"], "identical": same})
        ok &= same
    return ("PASS" if ok else "FAIL"), {"tests": rows, "identical": sum(r["identical"] for r in rows), "total": len(rows)}


def st_coverage(results):
    tests = results.get("sim_verilator", {}).get("data", {}).get("tests") or \
        results.get("sim_icarus", {}).get("data", {}).get("tests")
    if not tests:
        return "BLOCKED", {}
    acc = {}
    for t, r in tests.items():
        for l in r["cov"]:
            for k, g, v in re.findall(r"(\w+)(?: g=(\d))? ([0-9a-f]+)", l[4:]):
                key = f"{k}{'_g' + g if g else ''}"
                acc[key] = acc.get(key, 0) | int(v, 16)
    # legal universe of each item
    own_states = {0, 1, 2, 3, 4, 5, 6, 7}
    own_arcs = {(0, 1), (1, 0), (1, 2), (1, 7), (2, 0), (2, 3), (2, 7), (3, 4), (4, 5), (5, 6), (5, 7), (6, 0), (7, 0)}
    phases = {0, 1, 2, 3, 4, 5, 6}
    universe = {"own_state": own_states, "seq_phase": phases, "seq_result": set(range(9)),
                "error_class": set(range(11)) - {6}, "viol_src": {1, 2, 3, 4, 5, 6}, "mode": {0, 1, 2, 3, 4, 5},
                "algorithm": set(range(6)), "engine_result": {1, 2, 3}}
    rep = {}
    for key, val in sorted(acc.items()):
        base = re.sub(r"_g\d$", "", key)
        if base == "own_arc":
            hit = {(i >> 3, i & 7) for i in range(64) if val >> i & 1}
            rep[key] = {"hit": len(hit & own_arcs), "of": len(own_arcs), "missing": sorted(own_arcs - hit),
                        "unexpected": sorted(hit - own_arcs)}
        elif base in universe:
            hit = {i for i in range(64) if val >> i & 1}
            u = universe[base]
            rep[key] = {"hit": len(hit & u), "of": len(u), "missing": sorted(u - hit), "unexpected": sorted(hit - u)}
    taps = [l for t in tests.values() for l in t["key_lines"] if l.startswith("COVERAGE tap")]
    return "PASS", {"items": rep, "tap": taps[:1],
                    "note": "REINIT_REQUIRED (class 6) is unreachable by construction with INIT modes 1/2 (formal C8)"}


def st_synth():
    if not have(NIX["yosys70"]):
        return "BLOCKED", {"reason": "Yosys 0.70 not available"}
    env = dict(os.environ, SFTA_YOSYS=NIX["yosys70"], SFTA_STA=NIX["sta"])
    rc, out, s = sh(["bash", "asic/synth/run_synth.sh"], "synth.log", env=env)
    stat = (REP / "synth/stat.txt").read_text() if (REP / "synth/stat.txt").exists() else ""
    area = re.search(r"Chip area for module '\\sfta_synth_top': ([\d.]+)", stat)
    cells = re.search(r"^\s+(\d+)\s+[\d.E+-]+\s+cells$", stat, re.M)
    ffs = sum(int(n) for n, c in re.findall(r"^\s+(\d+)\s+[\d.E+-]+\s+sky130_fd_sc_hd__(s?e?df\w+)", stat, re.M))
    sta = (REP / "synth/sta.rpt").read_text() if (REP / "synth/sta.rpt").exists() else ""
    w = re.search(r"worst slack max (-?[\d.]+)", sta)
    hd = re.search(r"worst slack min (-?[\d.]+)", sta)
    undriven = len(re.findall(r"no driver", (REP / "synth/yosys.log").read_text())) if (REP / "synth/yosys.log").exists() else -1
    return ("PASS" if rc == 0 and area and undriven == 0 else "FAIL"), {
        "area_um2": float(area.group(1)) if area else None, "cells": int(cells.group(1)) if cells else None,
        "flops": ffs, "undriven_warnings": undriven,
        "pre_placement_sta_10ns": {"setup_wns_ns": float(w.group(1)) if w else None,
                                   "hold_ns": float(hd.group(1)) if hd else None,
                                   "note": "no buffering / wire model: high-fanout enables dominate; see place step"},
        "seconds": s}


def st_scan():
    if not have(NIX["openroad"]):
        return "BLOCKED", {"reason": "OpenROAD not available"}
    env = dict(os.environ, SFTA_PDK="third_party/silicaflux-testcore/pdk", SFTA_NET="reports/synth/netlist.v",
               SFTA_TOP="sfta_synth_top", SFTA_OUT="reports/dft", SFTA_MAXLEN="200", SFTA_YOSYS=NIX["yosys70"])
    (REP / "dft").mkdir(parents=True, exist_ok=True)
    rc, out, s = sh(f"{NIX['openroad']} -no_init -exit asic/dft/run_scan.tcl > reports/dft/openroad_scan.log 2>&1", "scan_openroad.log", env=env)
    rc2, out2, s2 = sh([sys.executable, "asic/dft/check_chains.py"], "scan_chain_check.log", env=env)
    summ = json.loads((REP / "dft/scan_summary.json").read_text()) if (REP / "dft/scan_summary.json").exists() else {}
    ok = rc == 0 and rc2 == 0 and summ.get("continuity") == "PASS" and summ.get("non_scan_flop_cells") == 0
    return ("PASS" if ok else "FAIL"), {k: summ.get(k) for k in ("chain_count", "total_scan_cells", "scan_flop_cells",
                                                               "non_scan_flop_cells", "continuity")}


def st_place():
    if not have(NIX["openroad"]):
        return "BLOCKED", {"reason": "OpenROAD not available"}
    env = dict(os.environ, SFTA_PDK="third_party/silicaflux-testcore/pdk", SFTA_NET="reports/dft/scan_netlist.v",
               SFTA_TOP="sfta_synth_top", SFTA_OUT="reports/floorplan", SFTA_UTIL="40")
    (REP / "floorplan").mkdir(parents=True, exist_ok=True)
    rc, out, s = sh(f"{NIX['openroad']} -no_init -exit asic/floorplan/place_ta.tcl > reports/floorplan/place_ta.log 2>&1",
                    "place.log", env=env)
    lg = (REP / "floorplan/place_ta.log").read_text()
    ok = rc == 0 and "SFTA_PLACE_DONE" in lg
    d = (REP / "floorplan/ta_placed.def")
    if d.exists():
        subprocess.run(["gzip", "-kf", str(d)])
    return ("PASS" if ok else "FAIL"), {"log": "reports/floorplan/place_ta.log", "seconds": s}


def st_scanplan():
    env = dict(os.environ, SFTA_YOSYS=NIX["yosys70"])
    rc, out, s = sh([sys.executable, "scripts/scan_plan.py"], "scan_plan.log", env=env)
    return ("PASS" if rc == 0 else "FAIL"), {"output": out.strip().splitlines()[-2:], "seconds": s}


def st_physical():
    rc, out, s = sh([sys.executable, "scripts/physical_report.py"], "physical.log")
    return ("PASS" if rc == 0 else "FAIL"), {"output": out.strip().splitlines()[-1:]}


def collect(path, key="status"):
    p = REP / path
    if not p.exists():
        return "BLOCKED", {"reason": f"{path} not produced (run the script)"}
    d = json.loads(p.read_text())
    return d.get(key, "UNKNOWN"), d


def st_formal():
    return collect("formal/summary.json")


def st_mutation():
    p = REP / "mutation/mutation.json"
    if not p.exists():
        return "BLOCKED", {"reason": "run scripts/mutate.py"}
    d = json.loads(p.read_text())
    k = sum(1 for r in d.values() if r["status"] == "KILLED")
    v = sum(1 for r in d.values() if r["status"] in ("KILLED", "SURVIVED"))
    return ("PASS" if k == v and v > 0 else "FAIL"), {"killed": k, "valid": v,
                                                      "survived": [m for m, r in d.items() if r["status"] == "SURVIVED"]}


def st_codecov():
    return collect("coverage/code_coverage.json")


STEPS = ["tools", "hashes", "regmap", "lint", "illegal", "sim_icarus", "sim_verilator", "xsim", "coverage", "synth",
         "scan", "place", "scanplan", "physical", "formal", "mutation", "codecov"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--skip", default="")
    ap.add_argument("-j", type=int, default=4)
    a = ap.parse_args()
    LOG.mkdir(parents=True, exist_ok=True)
    prev = json.loads((REP / "regression.json").read_text())["steps"] if (REP / "regression.json").exists() else {}
    only = set(a.only.split(",")) if a.only else set(STEPS)
    skip = set(a.skip.split(",")) if a.skip else set()
    results = dict(prev)
    fn = {"tools": st_tools, "hashes": st_hashes, "regmap": st_regmap, "lint": st_lint, "illegal": st_illegal,
          "sim_icarus": lambda: st_sim("icarus", a.j), "sim_verilator": lambda: st_sim("verilator", a.j),
          "xsim": lambda: st_xsim(results), "coverage": lambda: st_coverage(results), "synth": st_synth,
          "scan": st_scan, "place": st_place, "scanplan": st_scanplan, "physical": st_physical, "formal": st_formal,
          "mutation": st_mutation, "codecov": st_codecov}
    for s in STEPS:
        if s not in only or s in skip:
            continue
        t0 = time.time()
        st, data = fn[s]()
        results[s] = {"status": st, "data": data, "seconds": round(time.time() - t0, 1),
                      "time": time.strftime("%Y-%m-%d %H:%M:%S")}
        print(f"[regress] {s:14s} {st:8s} ({results[s]['seconds']} s)", flush=True)
    overall = "PASS" if all(r["status"] == "PASS" for r in results.values()) else "FAIL"
    (REP / "regression.json").write_text(json.dumps({"overall": overall, "steps": results}, indent=1))
    md = ["# Regression", "", f"Overall: **{overall}** ({sum(r['status'] == 'PASS' for r in results.values())}/"
          f"{len(results)} steps PASS)", "", "| Step | Result | Time (s) | Summary |", "|---|---|---|---|"]
    for s in STEPS:
        if s not in results:
            continue
        r = results[s]
        d = r["data"]
        summ = ""
        if s.startswith("sim_"):
            summ = f"{d.get('passed')}/{d.get('total')} tests, {d.get('checks')} checks"
        elif s == "xsim":
            summ = f"{d.get('identical')}/{d.get('total')} tests identical"
        elif s == "lint":
            summ = "; ".join(f"{k}: {v}" for k, v in d.items())
        elif s == "illegal":
            summ = f"{d.get('refused')}/{d.get('total')} illegal sets refused"
        elif s == "synth":
            summ = f"{d.get('cells')} cells, {d.get('area_um2')} µm², {d.get('flops')} flops"
        elif s == "scan":
            summ = f"{d.get('chain_count')} chains, {d.get('total_scan_cells')} cells, continuity {d.get('continuity')}"
        elif s == "mutation":
            summ = f"{d.get('killed')}/{d.get('valid')} killed"
        elif s == "formal":
            summ = ", ".join(f"{h}: {v['result']}" for h, v in d.get("harnesses", {}).items())
        elif s == "hashes":
            summ = f"{d.get('files')} files, {len(d.get('mismatch', []))} mismatches"
        elif s == "codecov":
            summ = d.get("summary", "")
        elif s == "tools":
            summ = "; ".join(f"{k} {v}" for k, v in d.items())
        md.append(f"| {s} | **{r['status']}** | {r['seconds']} | {summ} |")
    (REP / "REGRESSION.md").write_text("\n".join(md) + "\n")
    subprocess.run([sys.executable, str(ROOT / "scripts" / "gen_docs.py")])     # README / docs figures from reports
    print(f"[regress] overall {overall}")
    return 0 if overall == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
