#!/usr/bin/env python3
"""Fill README.md, docs/06_SCAN.md, docs/09_COVERAGE.md and docs/10_PHYSICAL.md from the evidence.

    python3 scripts/gen_docs.py [--check]

Every number in the two documents comes from reports/*.json or the per-test
logs in reports/logs/, so the headline figures cannot drift from the
evidence.  Templates: docs/templates/*.in.  A missing report is written as
"not run", never as a figure.  --check exits 1 if the files are out of date.
"""
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REP = ROOT / "reports"
TPL = ROOT / "docs" / "templates"


def load(p):
    p = REP / p
    return json.loads(p.read_text()) if p.exists() else {}


def n(x):
    """Thousands separated by a thin space, as in the hand-written docs."""
    return f"{x:,}".replace(",", " ") if isinstance(x, int) else str(x)


def sec(lst):
    return ", ".join(str(x) for x in lst)


OWN = ["NORMAL", "QUIESCE_REQUEST", "WAIT_FOR_IDLE", "TEST_ACQUIRE", "TEST_ACTIVE", "TEST_COMPLETE", "TEST_RELEASE",
       "FAULT"]
EC = ["MBIST_FAIL", "MBIST_ERROR", "SEQ_TIMEOUT", "OWNER_FAULT", "INTRUSION", "SEC_VIOL", "REINIT", "LC_INCONS",
      "REFUSED", "RAS_LOST", "BUS_ERR"]
RES = ["NOT_RUN", "PASS", "FAIL", "ABORTED", "ERROR", "TIMEOUT", "REFUSED", "RUNNING", "OWNER_FAULT"]
# why an item is open: only reasons established by reading the RTL, never "probably fine"
OPEN_REASON = {
    ("own_arc", (5, 7)): "not reachable in this integration: in TEST_COMPLETE the owner waits only for the collar's "
                         "own sweep / read pipeline (bounded by DEPTH + LAT + 2 cycles) and elaboration refuses "
                         "OWN_TIMEOUT <= DEPTH + LAT + 4",
    ("own_arc", (2, 7)): "open: needs a memory that never goes idle after the quiesce acknowledge (functional "
                         "requests are already blocked in this state); not scripted",
    ("own_arc", (2, 0)): "open: needs the request withdrawn inside the drain window (1-2 cycles in the benches); "
                         "not scripted",
    ("error_class", 9): "open: needs two different RAS-reported events pending while one of them recurs before it "
                        "is drained (one event drained per cycle); not scripted",
    ("error_class", 6): "excluded from the universe: unreachable by construction with INIT modes 1 / 2 (formal C8)",
}


def cov_table(cov):
    items = cov.get("items", {})
    if not items:
        return "*Coverage step not run.*"
    rows = ["| Item | Hit / legal | Open | Note |", "|---|---|---|---|"]

    def name(base, v):
        if base == "own_arc":
            return f"{OWN[v[0]]}→{OWN[v[1]]}"
        if base == "own_state":
            return OWN[v]
        if base == "error_class":
            return f"{v} {EC[v]}"
        if base == "seq_result":
            return f"{v} {RES[v]}"
        return str(v)

    union = {}
    for key, r in sorted(items.items()):
        base = re.sub(r"_g\d$", "", key)
        if base in ("own_arc", "own_state"):
            u = union.setdefault(base, {"hit": set(), "of": r["of"], "unexpected": set()})
            miss = {tuple(m) if isinstance(m, list) else m for m in r["missing"]}
            u.setdefault("all", None)
            u["missing_sets"] = u.get("missing_sets", []) + [miss]
            u["unexpected"] |= {tuple(m) if isinstance(m, list) else m for m in r["unexpected"]}
        miss = [tuple(m) if isinstance(m, list) else m for m in r["missing"]]
        unexp = [tuple(m) if isinstance(m, list) else m for m in r["unexpected"]]
        # per-group ownership rows: reasons are given once, in the union row below
        note = "" if base in ("own_arc", "own_state") else \
            "; ".join(f"{name(base, m)}: {OPEN_REASON[(base, m)]}" for m in miss if (base, m) in OPEN_REASON)
        if unexp:
            note = (note + "; " if note else "") + "**unexpected: " + sec(name(base, m) for m in unexp) + "**"
        if base == "error_class":
            note = (note + "; " if note else "") + "6 REINIT " + OPEN_REASON[("error_class", 6)]
        rows.append(f"| `{key}` | {r['hit']} / {r['of']} | {sec(name(base, m) for m in miss) or '—'} | {note} |")
    for base, u in union.items():
        common = set.intersection(*u["missing_sets"]) if u["missing_sets"] else set()
        of = u["of"]
        notes = "; ".join(f"{name(base, m)}: {OPEN_REASON[(base, m)]}" for m in sorted(common) if (base, m) in OPEN_REASON)
        rows.append(f"| **{base}, union of groups** | **{of - len(common)} / {of}** | "
                    f"{sec(name(base, m) for m in sorted(common)) or '—'} | {notes} |")
    for t in cov.get("tap", []):
        rows.append(f"| JTAG TAP (`jtag_tap`, random walk vs reference) | {t.split(' ', 1)[1]} | — | |")
    return "\n".join(rows)


def main():
    reg = load("regression.json").get("steps", {})
    form = load("formal/summary.json")
    mut = load("mutation/mutation.json")
    cc = load("coverage/code_coverage.json")
    scan = load("dft/scan_summary.json")
    phys = load("physical/physical_connectivity.json")
    plan = load("scan_plan/scan_plan.json")
    d = lambda s: reg.get(s, {}).get("data", {})
    st = lambda s: reg.get(s, {}).get("status", "not run")

    v = {}
    v["HASH_FILES"] = n(d("hashes").get("files", "?"))
    fl = [l for l in d("sim_icarus").get("tests", {}).get("faults", {}).get("key_lines", []) if l.startswith("FAULT ")]
    v["FAULTS"] = n(len(fl))
    v["FAULTS_DET"] = n(sum(1 for l in fl if "-> FAIL" in l))
    tests = d("sim_icarus").get("tests", {})
    mc = sum(t.get("master_checks") or 0 for t in tests.values())
    me = sum(t.get("master_errors") or 0 for t in tests.values())
    v["MASTER_CHECKS"] = n(mc)
    v["MASTER_ERRORS"] = n(me)
    for k, s in (("IV", "sim_icarus"), ("VL", "sim_verilator")):
        dd = d(s)
        v[f"{k}_PASS"] = f"{dd.get('passed', 0)} / {dd.get('total', 0)} {st(s)}" if dd else "not run"
        v[f"{k}_CHECKS"] = n(dd.get("checks", 0))
    v["XSIM"] = f"{d('xsim').get('identical', 0)} / {d('xsim').get('total', 0)} identical ({st('xsim')})"
    h = form.get("harnesses", {})
    unb = [k for k in h if k != "fv_ta_bmc"]
    reach = [r for k in unb for r in h[k].get("reach", [])]
    v["FORMAL_UNB"] = (f"{sum(h[k]['result'] == 'PASS' for k in unb)} / {len(unb)} PASS; reach points "
                       f"{sum(r['result'] == 'REACHED' for r in reach)} / {len(reach)} reached") if unb else "not run"
    bmc = h.get("fv_ta_bmc", {})
    dep = bmc.get("bounded_depth")
    if dep is None:
        m = re.search(r"depth (\d+)", bmc.get("engine", ""))
        dep = m.group(1) if m else "?"
    v["FORMAL_BMC"] = (f"{bmc['result']}: no counterexample in steps 0..{dep} (not a proof)" if bmc else "not run")
    k = sum(r["status"] == "KILLED" for r in mut.values())
    val = sum(r["status"] in ("KILLED", "SURVIVED") for r in mut.values())
    surv = [m for m, r in mut.items() if r["status"] == "SURVIVED"]
    v["MUT"] = f"{k} / {val} killed" + (f" (survived: {', '.join(surv)})" if surv else "") if val else "not run"
    rt_ = cc.get("new_rtl_runtime")
    rts = (f" (run-time points {rt_['covered']} / {rt_['total']} = {rt_['percent']} %; compile-time constant "
           "functions excluded)") if rt_ else ""
    v["CODECOV"] = (f"new RTL **{cc['new_rtl']['covered']} / {cc['new_rtl']['total']} ({cc['new_rtl']['percent']} %)**{rts}, "
                    f"reused TestCore {cc['reused_testcore']['covered']} / {cc['reused_testcore']['total']} "
                    f"({cc['reused_testcore']['percent']} %)") if cc.get("new_rtl") else "not run"
    items = d("coverage").get("items", {})
    label = {"algorithm": "algorithms", "engine_result": "engine results", "error_class": "error classes",
             "mode": "modes", "seq_result": "sequencer results", "viol_src": "violation sources",
             "seq_phase": "sequencer phases (every group)", "own_state": "ownership states (union of groups)",
             "own_arc": "ownership arcs (union of groups)"}
    agg = {}
    for kk, r in items.items():
        base = re.sub(r"_g\d$", "", kk)
        miss = {tuple(m) if isinstance(m, list) else m for m in r["missing"]}
        a = agg.setdefault(base, {"of": r["of"], "miss": None, "pergroup": base != kk})
        if a["pergroup"] and base == "seq_phase":
            a["miss"] = (a["miss"] or set()) | miss               # every group must see every phase
        else:
            a["miss"] = miss if a["miss"] is None else (a["miss"] & miss)
    done = [f"{label.get(b, b)} {a['of'] - len(a['miss'])}/{a['of']}" for b, a in agg.items() if not a["miss"]]
    open_ = [f"{label.get(b, b)} {a['of'] - len(a['miss'])}/{a['of']}" for b, a in agg.items() if a["miss"]]
    tap = d("coverage").get("tap", [])
    if tap:
        done.append("TAP " + tap[0].split(" ", 1)[1].replace("tap_states=", "states ").replace(" tap_arcs=", ", arcs "))
    v["FCOV"] = ("complete: " + "; ".join(done) + (". Open (reasons in docs/09): " + "; ".join(open_) if open_ else "")
                 if items else "not run")
    lint = d("lint")
    lw = sum(x.get("warnings", 0) + x.get("errors", 0) + x.get("warnings_in_new_rtl", 0) for x in lint.values()
             if isinstance(x, dict))
    v["LINT"] = f"{lw} warnings ({st('lint')})" if lint else "not run"
    v["ILLEGAL"] = f"{d('illegal').get('refused', 0)} / {d('illegal').get('total', 0)}"
    sy = d("synth")
    v["SYN_CELLS"], v["SYN_AREA"], v["SYN_FF"] = n(sy.get("cells")), n(round(sy.get("area_um2") or 0)), n(sy.get("flops"))
    v["SCAN_CHAINS"] = n(scan.get("chain_count", "not run"))
    v["SCAN_CELLS"] = n(scan.get("total_scan_cells", "?"))
    v["SCAN_NONSCAN"] = n(scan.get("non_scan_flop_cells", "?"))
    v["SCAN_CONT"] = scan.get("continuity", "?")
    ch = scan.get("chains", [])
    clk = sum(c["clock"] == "clk" for c in ch)
    tr = sum(c["clock"] == "tck" and c["edge"] == "rising" for c in ch)
    tf = sum(c["clock"] == "tck" and c["edge"] == "falling" for c in ch)
    v["SCAN_SPLIT"] = f"{clk} on clk, {tr} on TCK rising, {tf} on TCK falling"
    lens = lambda cs: " + ".join(f"{cnt} x {ln}" if cnt > 1 else str(ln) for ln, cnt in
                                 sorted({c["len"]: sum(x["len"] == c["len"] for x in cs) for c in cs}.items(),
                                        key=lambda t: -t[1]))
    grp = [("clk", "rising", "on `clk`"), ("tck", "rising", "on TCK rising"), ("tck", "falling", "on TCK falling")]
    v["SCAN_BYCLK"] = ", ".join(f"{len(cs)} {lbl} ({lens(cs)})" for c0, e0, lbl in grp
                                for cs in [[c for c in ch if c["clock"] == c0 and c["edge"] == e0]] if cs)
    shared = [f"{c['name']} → `{c['scan_out']}`" for c in ch if not c["scan_out"].startswith("scan_out_")]
    v["SCAN_SHARED"] = ("scan-out shared with a functional output: " + ", ".join(shared)) if shared else \
        "every scan-out a dedicated port"
    v["SCAN_SHARED_NOTE"] = (
        "**Finding (tool behaviour):** OpenROAD 26Q3 did not create a dedicated scan-out port for "
        + ", ".join(f"`{c['name']}`" for c in ch if not c["scan_out"].startswith("scan_out_"))
        + "; it used a functional output that the chain's last flop already drives directly ("
        + ", ".join(f"`{c['scan_out']}`" for c in ch if not c["scan_out"].startswith("scan_out_"))
        + "). The chain checker finds scan-outs structurally, and the continuity simulation observes the chain "
          "at that port. At chip level this output must reach a pin in scan mode (or the flow must be "
          "constrained to dedicated scan-out ports) before the chain can be used on a tester."
    ) if shared else "Every chain has a dedicated scan-out port."
    tab = phys.get("test_access_block", {})
    st_um = [c.get("stitch_manhattan_um") for c in tab.get("chains", []) if c.get("stitch_manhattan_um") is not None]
    v["STITCH"] = f"{n(round(min(st_um)))}–{n(round(max(st_um)))}" if st_um else "?"
    fo = tab.get("fanout", {})
    fget = lambda pre: next((val for kk, val in fo.items() if kk.startswith(pre)), "?")
    v["FO_SE"], v["FO_CLK"], v["FO_RST"], v["FO_TRST"] = (n(fget("scan_enable")), n(fget("clk ")), n(fget("rst_n")),
                                                          n(fget("trst_n")))
    v["FO_TCK_R"], v["FO_TCK_F"] = n(fget("tck (CLK pins")), n(fget("tck (CLK_N"))
    v["FO_TCK"] = n(fget("tck (CLK pins") + fget("tck (CLK_N")) if fo else "?"
    v["AREA_POST"] = n(round(tab.get("std_cell_area_um2_post_repair", 0)))
    v["DIE"] = " x ".join(n(round(x)) for x in tab.get("die_um", [])) or "?"
    tm = tab.get("timing", {})
    v["T_FUN"] = f"{tm.get('functional_100MHz_setup_ns', '?'):+}" if tm else "?"
    v["T_HOLD"] = f"{tm.get('functional_hold_ns', '?'):+}" if tm else "?"
    v["T_SHIFT"] = f"{tm.get('shift_50MHz_setup_ns', '?'):+}" if tm else "?"
    cf = plan.get("configs", {})
    v["PLAN_MIN"] = n(cf.get("MIN", {}).get("die_ff_bits", "?"))
    v["PLAN_HPC"] = n(cf.get("HPC", {}).get("die_ff_bits", "?"))

    v["COV_TABLE"] = cov_table(d("coverage"))
    v["CODECOV_BLOCK"] = (v["CODECOV"] + ". Per-file table and the uncovered lines of the new RTL: "
                          "`reports/coverage/code_coverage.md`.") if cc else "*Not run.*"
    if val:
        rows = ["| Mutant | Defect | Result | Detected by |", "|---|---|---|---|"]
        rows += [f"| {m} | {r['description']} | {r['status']} | {r.get('by', '').replace('|', '/')[:110]} |"
                 for m, r in mut.items()]
        v["MUT_BLOCK"] = (f"**Mutation testing: {v['MUT']}** (`reports/mutation/mutation.md`). Each mutant is one "
                          "deliberate defect in the new RTL; the full suite runs with fatal assertions.\n\n" + "\n".join(rows))
    else:
        v["MUT_BLOCK"] = "Mutation testing: not run."
    v["FORMAL_BLOCK"] = (f"Formal (`reports/formal/summary.md`): unbounded {v['FORMAL_UNB']}; whole block "
                         f"{v['FORMAL_BMC']}.")

    out = {}
    readme = (TPL / "README.md.in").read_text()
    covdoc = (TPL / "09_COVERAGE.md.in").read_text()
    covdoc = (covdoc.replace("COVERAGE_TABLE_PLACEHOLDER", "{{COV_TABLE}}").replace("CODECOV_PLACEHOLDER", "{{CODECOV_BLOCK}}")
              .replace("MUTATION_PLACEHOLDER", "{{MUT_BLOCK}}").replace("FORMAL_PLACEHOLDER", "{{FORMAL_BLOCK}}")
              .replace("11 single-fault cases plus 1", "{{FAULTS}} single-fault cases plus 1"))
    hdr = "<!-- generated by scripts/gen_docs.py from docs/templates/{} and reports/; do not edit -->\n"
    jobs = [("README.md.in", readme, ROOT / "README.md"), ("09_COVERAGE.md.in", covdoc, ROOT / "docs" / "09_COVERAGE.md")]
    jobs += [(f"{d}.md.in", (TPL / f"{d}.md.in").read_text(), ROOT / "docs" / f"{d}.md") for d in ("06_SCAN", "10_PHYSICAL")]
    for name, tpl, dst in jobs:
        txt = re.sub(r"\{\{(\w+)\}\}", lambda m: str(v.get(m.group(1), "{{" + m.group(1) + "}}")), tpl)
        left = re.findall(r"\{\{\w+\}\}", txt)
        if left:
            print(f"[gen_docs] unfilled in {dst.name}: {left}")
            return 1
        out[dst] = hdr.format(name) + txt
    if "--check" in sys.argv:
        stale = [p.name for p, t in out.items() if not p.exists() or p.read_text() != t]
        print(f"[gen_docs] {'stale: ' + ', '.join(stale) if stale else 'up to date'}")
        return 1 if stale else 0
    for p, t in out.items():
        p.write_text(t)
    print(f"[gen_docs] wrote README.md, docs/06, 09, 10 (sim {v['IV_PASS']}, mutation {v['MUT']}, "
          f"scan {v['SCAN_CHAINS']} chains / {v['SCAN_CELLS']} cells)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
