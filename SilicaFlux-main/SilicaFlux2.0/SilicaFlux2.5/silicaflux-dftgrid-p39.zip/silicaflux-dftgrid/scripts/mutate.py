#!/usr/bin/env python3
"""Mutation testing of the NEW Project 39 RTL against the full system testbench.

    python3 scripts/mutate.py [--only M01,M02]

Each mutant is one deliberate defect (a textual replacement that must match
exactly once).  The mutant RTL is built with Verilator (-O0, assertions fatal)
and the complete tb_ta_sys suite runs; the mutant is KILLED if any test
fails, an RTL assertion fires or the simulation times out.  A surviving
mutant is a verification gap.  Results: reports/mutation/mutation.{json,md}.
"""
import argparse, fcntl, json, os, re, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reports" / "mutation"
WORK = ROOT / "build" / "mut"

MUTANTS = [
    ("M01", "rtl/sfta_lc_policy.sv", "assign perm_scan    = ok && is_dev;", "assign perm_scan    = ok;",
     "scan pin honoured in every consistent lifecycle"),
    ("M02", "rtl/sfta_lc_policy.sv",
     "assign inconsistent = lc_valid && (!known || (sb_debug_en != is_dev) || (sb_test_mode_en != is_dev));",
     "assign inconsistent = 1'b0;", "lifecycle consistency check removed"),
    ("M03", "rtl/sfta_lc_policy.sv", "assign perm_ift     = ok && is_field && otp_ift_en;",
     "assign perm_ift     = ok && is_field;", "in-field MBIST without the fuse"),
    ("M04", "rtl/silicaflux_test_access.sv", "wire r_allowed = j_sel ? perm_jtag", "wire r_allowed = j_sel ? 1'b1",
     "JTAG register access in every lifecycle"),
    ("M05", "rtl/silicaflux_test_access.sv", ": (s_priv || perm_host_wr || (!s_we && r_page == 3'd0));",
     ": (s_priv || perm_host_wr || (r_page == 3'd0));", "unprivileged writes to page 0 outside DEV"),
    ("M06", "rtl/silicaflux_test_access.sv", "wire r_grp_restricted = (r_page != 3'd0) && r_we &&",
     "wire r_grp_restricted = 1'b0 && r_we &&", "group-page MODE_CTRL / UNLOCK accepted"),
    ("M07", "rtl/silicaflux_test_access.sv", ".scan_mode_pin(scan_mode_pin && perm_scan)", ".scan_mode_pin(scan_mode_pin)",
     "scan pin not gated by the scan permission (MBIST permission only)"),
    ("M08", "rtl/sfta_group_collar.sv", "assign f_block     = own_fblock;", "assign f_block     = 1'b0;",
     "functional path open while the group is under test"),
    ("M09", "rtl/sfta_group_collar.sv", "wire post_req = COLLAR && own_dirty", "wire post_req = 1'b0 && own_dirty",
     "no re-initialisation sweep after a test"),
    ("M10", "rtl/sfta_group_collar.sv", "assign tst_wdata  = sw_act ? INIT_WORD : b_wdata[SW-1:0];",
     "assign tst_wdata  = sw_act ? '0 : b_wdata[SW-1:0];", "sweep writes zero instead of the valid init word"),
    ("M11", "rtl/sfta_group_collar.sv", "wire [NB-1:0] rp_out = rp_b[(LAT-1)*NB +: NB];",
     "wire [NB-1:0] rp_out = rp_b[0 +: NB];", "read response taken from the wrong pipeline stage"),
    ("M12", "rtl/sfta_group_collar.sv", "      b_rvalid[k]               = rp_v[LAT-1] && rp_out[k];",
     "      b_rvalid[k]               = rp_v[0] && rp_out[k];", "read response one cycle early for LAT > 1"),
    ("M13", "rtl/sfta_group_collar.sv",
     "assign clk_req      = (own_st != OWN_NORMAL && own_st != OWN_FAULT) || sw_act || post_req;",
     "assign clk_req      = 1'b0;", "branch clock never requested"),
    ("M14", "rtl/sfta_group_collar.sv", "                        !(!COLLAR && mem_init_busy);", "                        1'b1;",
     "group reported released while the memory still initialises"),
    ("M15", "rtl/sfta_group_collar.sv", "wire own_acq    = (|acq_req) && !rst_sweep;", "wire own_acq    = (|acq_req);",
     "acquisition allowed during the reset initialisation sweep"),
    ("M16", "rtl/sfta_seq.sv", "end else if (par_l || first_open[g]) begin", "end else if (1'b1) begin",
     "sequential mode starts every group at once"),
    ("M17", "rtl/sfta_seq.sv", "for (int g = 0; g < NG; g++) tmo_v[g] = wd_on && (tmr[g*32 +: 32] >= wd_q);",
     "for (int g = 0; g < NG; g++) tmo_v[g] = 1'b0;", "watchdog never expires"),
    ("M18", "rtl/sfta_seq.sv", "      RES_FAIL:    map_res = TA_RES_FAIL;", "      RES_FAIL:    map_res = TA_RES_PASS;",
     "engine FAIL reported as PASS by the sequencer"),
    ("M19", "rtl/sfta_seq.sv",
     "if (stop_on_fail && !(res[g*4 +: 4] == TA_RES_PASS && !g_owner_fault[g])) stop_l <= 1'b1;",
     "if (1'b0) stop_l <= 1'b1;", "STOP_ON_FAIL ignored"),
    ("M20", "rtl/sfta_consts.svh", "      TA_EC_MBIST_FAIL:  ta_ras_type = TA_RAS_MEM_UE;",
     "      TA_EC_MBIST_FAIL:  ta_ras_type = TA_RAS_ILLEGAL_OP;", "MBIST failure sent to RAS with the wrong type"),
    ("M21", "rtl/sfta_regs.sv", "      if (e_viol) begin\n        r_viol_info <=", "      if (1'b0) begin\n        r_viol_info <=",
     "security violations not logged"),
    ("M22", "rtl/sfta_regs.sv", "TA_R_UNLOCK:     unlocked <= (wdata == TC_UNLOCK_KEY);",
     "TA_R_UNLOCK:     unlocked <= 1'b1;", "any value unlocks the destructive mode"),
    ("M23", "rtl/sfta_group_ctrl.sv", "acq_req[k] = mbist_enable && !mode_busy && e_mask[k] && (!protect[k] || cpu_halted);",
     "acq_req[k] = mbist_enable && !mode_busy && e_mask[k];", "PROTECT ignored"),
    ("M24", "rtl/sfta_group_ctrl.sv", "wire          e_start = (c_start && !seq_sel) || seq_start;",
     "wire          e_start = c_start || seq_start;", "page START not blocked while the sequencer owns the group"),
    ("M25", "rtl/silicaflux_test_access.sv", "assign dft_icg_te      = scan_mode;", "assign dft_icg_te      = scan_en;",
     "ICG test enable only during shift"),
    ("M26", "rtl/silicaflux_test_access.sv", ".e_intr(g_ev_intr & ~g_intr_q)", ".e_intr(g_ev_intr)",
     "intrusion counted every cycle instead of once per episode"),
]

VL = ["verilator", "--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-UNOPTFLAT",
      "-Wno-MULTIDRIVEN", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-DSFTC_FATAL_ASSERT", "--top-module", "tb_ta_sys",
      "-CFLAGS", "-O0", "-MAKEFLAGS", "OPT_FAST=-O0"]


def run_mutant(mid, path, old, new):
    d = WORK / mid
    shutil.rmtree(d, ignore_errors=True)
    d.mkdir(parents=True)
    for x in ("third_party", "tb"):
        (d / x).symlink_to(ROOT / x)
    shutil.copytree(ROOT / "rtl", d / "rtl")
    src = (d / path).read_text()
    if src.count(old) != 1:
        return {"status": "INVALID", "reason": f"pattern found {src.count(old)} times"}
    (d / path).write_text(src.replace(old, new))
    t0 = time.time()
    b = subprocess.run(VL + ["-Mdir", "obj", "-o", "vl_tb", "rtl/lint.vlt", "-f", "rtl/files_ta.f", "-f", "tb/files_tb.f"],
                       cwd=d, capture_output=True, text=True)
    if b.returncode:
        (d / "build.log").write_text(b.stdout + b.stderr)
        return {"status": "KILLED", "by": "build / elaboration error", "seconds": round(time.time() - t0)}
    try:
        r = subprocess.run([str(d / "obj" / "vl_tb"), "+TEST=all", "+MAXCYC=40000000"], cwd=d, capture_output=True,
                           text=True, timeout=1800)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        out += "\nWALLCLOCK TIMEOUT"
    (d / "sim.log").write_text(out)
    failed = re.findall(r"TEST (\w+) RESULT FAIL", out)
    m = re.search(r"TB_TA_SYS SUMMARY tests=(\d+) failed=(\d+)", out)
    assertion = re.search(r"SFTC_ASSERTION_FAILED[^\n]*", out)
    shutil.rmtree(d / "obj", ignore_errors=True)
    if assertion:
        return {"status": "KILLED", "by": "RTL assertion: " + assertion.group(0)[:160], "failed_tests": failed,
                "seconds": round(time.time() - t0)}
    if failed or not m or int(m.group(2)) > 0:
        return {"status": "KILLED", "by": "tests: " + (", ".join(failed) if failed else "incomplete run (timeout / crash)"),
                "failed_tests": failed, "seconds": round(time.time() - t0)}
    return {"status": "SURVIVED", "seconds": round(time.time() - t0)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    sel = set(a.only.split(",")) if a.only else None
    OUT.mkdir(parents=True, exist_ok=True)
    resf = OUT / "mutation.json"
    res = json.loads(resf.read_text()) if (resf.exists() and sel) else {}
    for mid, path, old, new, desc in MUTANTS:
        if sel and mid not in sel:
            continue
        r = run_mutant(mid, path, old, new)
        r.update({"file": path, "description": desc})
        print(f"[mutate] {mid} {r['status']:8s} {desc} :: {r.get('by', '')}", flush=True)
        # merge under a lock: several --only instances may run in parallel on disjoint mutant sets
        with open(OUT / ".lock", "w") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX)
            cur = json.loads(resf.read_text()) if (resf.exists() and (sel or res)) else {}
            cur[mid] = r
            resf.write_text(json.dumps(cur, indent=1))
            res = cur
    if resf.exists():
        res = json.loads(resf.read_text())
    killed = sum(1 for r in res.values() if r["status"] == "KILLED")
    valid = sum(1 for r in res.values() if r["status"] in ("KILLED", "SURVIVED"))
    md = ["# Mutation testing (new Project 39 RTL)", "",
          "Each mutant is one deliberate defect; the full `tb_ta_sys` suite runs on a Verilator build with fatal "
          "assertions. KILLED = a test failed, an assertion fired or the run did not complete.", "",
          f"**{killed} / {valid} killed**", "", "| Mutant | File | Defect | Result | Killed by |", "|---|---|---|---|---|"]
    for mid in sorted(res):
        r = res[mid]
        md.append(f"| {mid} | `{r['file']}` | {r['description']} | **{r['status']}** | {r.get('by', '')} |")
    (OUT / "mutation.md").write_text("\n".join(md) + "\n")
    print(f"[mutate] {killed}/{valid} killed")
    return 0 if killed == valid else 1


if __name__ == "__main__":
    sys.exit(main())
