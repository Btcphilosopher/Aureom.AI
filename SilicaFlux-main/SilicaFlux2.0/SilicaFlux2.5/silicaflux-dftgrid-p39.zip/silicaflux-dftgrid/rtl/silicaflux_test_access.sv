// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: silicaflux_test_access
// Top-level test access of the SilicaFlux die.   Aureom.AI | SilicaFlux-HPC
//
//  TCK/TMS/TDI/TDO/TRST* ─► sftc_jtag_tap ─► sftc_jtag_reg_bridge (TCK→clk CDC)  [TestCore P07, unmodified]
//                                                    │ JTAG master (priority)
//  ControlCore / host (s_*, s_priv) ─────────────────┤ system master
//                                                    ▼
//                     ┌──── access gate: lifecycle policy (sfta_lc_policy ◄── SecureBoot P28) ────┐
//                     │  page 0  sfta_regs   global mode / unlock / sequencer / errors / RAS port │
//                     │  page g+1 sfta_group_ctrl[g]  (TestCore regs + MBIST engine + bank mux)   │
//                     └────────────────────────────────────────────────────────────────────────────┘
//  silicaflux_test_mode_controller (TestCore P07, unmodified): NORMAL / JTAG_ACCESS / MBIST /
//      DIAGNOSTIC (register-requested) and SCAN_SHIFT / SCAN_CAPTURE (TEST_MODE pin, DEV only)
//  sfta_seq: one-command test of every bank of the selected groups (sequential / parallel)
//  per memory group g:  sfta_group_ctrl[g] ──bank bus (opt. pipelined)──► sfta_group_collar[g]
//      ─► memory raw test bus (tst_*) of the group (P33 SRAM grid, MemoryCore slice, ...)
//      ◄─► quiesce_req/ack, f_busy, f_req, f_block with the group's functional masters
//
// Clocks: tck (JTAG) and clk (the memory clock of every group: the P35
//   clk_core_o or one of its gated branches -- same clock, no crossing).
//   There is NO clock multiplexer in this block.  Scan clocks enter through
//   the functional clock pin (PLL bypass is the clock-root's / PLL IP's job);
//   dft_icg_te opens every ICG during scan (P35 contract test_en_i = 1).
// Resets: trst_n = TRST* AND power-on reset (TCK domain), rst_n = test-access
//   reset (asynchronous assert, synchronous release by the reset tree).
//
// Security (docs/04_SECURITY.md): JTAG register access, debug modes, the scan
//   pin and unprivileged writes are honoured only in the DEV lifecycle;
//   outside DEV the authenticated ControlCore firmware (s_priv) may run
//   in-field MBIST when the fuse enables it; IDCODE / BYPASS always work.
//   Refused accesses complete with an error, are logged (VIOL_INFO) and sent
//   to RAS as ILLEGAL_OP.  Permission decode is combinational from the
//   SecureBoot outputs, so scan shifting of this block cannot open it.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module silicaflux_test_access #(
  parameter int NG       = 2,                       // memory groups, 1..7
  parameter int MAXNB    = 4,                       // max banks per group (port sizing)
  parameter int MAXSW    = 72,                      // max stored-word width (port sizing)
  parameter int MAXRAW   = 10,                      // max row-address width (port sizing)
  parameter logic [NG*8-1:0]  G_NB    = {NG{8'd4}},       // banks per group
  parameter logic [NG*16-1:0] G_SW    = {NG{16'd72}},     // stored word width per group
  parameter logic [NG*24-1:0] G_DEPTH = {NG{24'd1024}},   // rows of the deepest bank per group
  parameter logic [NG*MAXNB*8-1:0]  G_BW = '0,            // per-bank width  (0 = group width)
  parameter logic [NG*MAXNB*24-1:0] G_BD = '0,            // per-bank depth  (0 = group depth)
  parameter logic [NG*4-1:0]  G_LAT   = {NG{4'd1}},       // raw test read latency
  parameter logic [NG*4-1:0]  G_INIT  = {NG{4'd1}},       // 1 collar sweep, 2 memory self-init
  parameter logic [NG-1:0]    G_INIT_ON_RESET = '0,
  parameter logic [NG*MAXSW-1:0] G_INIT_WORD = '0,
  parameter logic [NG*4-1:0]  G_KIND  = '0,               // TA_KIND_*
  parameter logic [NG-1:0]    G_PIPE_REQ = '0,            // pipeline stage engine -> collar
  parameter logic [NG-1:0]    G_PIPE_RSP = '0,            // pipeline stage collar -> engine
  parameter logic [15:0] ALG_MASK   = 16'h003F,
  parameter int LOG_DEPTH  = 4,
  parameter int CNT_W      = 16,
  parameter int ENG_TIMEOUT = 1024,                // engine request / response timeout (cycles)
  parameter int OWN_TIMEOUT = 4096,                // ownership quiesce / drain timeout (+ sweep length)
  parameter int SCAN_CHAINS = 0                    // reported in CAPS / SCAN_STATUS (0 = planning only)
) (
  // ---- JTAG
  input  wire logic                       tck,
  input  wire logic                       trst_n,
  input  wire logic                       tms,
  input  wire logic                       tdi,
  output logic                            tdo,
  output logic                            tdo_oe,
  // ---- system clock / reset
  input  wire logic                       clk,
  /* verilator lint_off SYNCASYNCNET */
  input  wire logic                       rst_n,
  /* verilator lint_on SYNCASYNCNET */
  // ---- SecureBoot (P28) lifecycle outputs and fuse configuration
  input  wire logic                       lc_valid,
  input  wire logic [3:0]                 lc_state,
  input  wire logic                       sb_debug_en,
  input  wire logic                       sb_test_mode_en,
  input  wire logic                       otp_ift_en,
  // ---- tester pins / CPU status
  input  wire logic                       scan_mode_pin,     // TEST_MODE (static during a scan session)
  input  wire logic                       scan_en_pin,       // SCAN_EN
  input  wire logic                       test_rst_n_pin,    // TEST_RST_N (reset during scan)
  input  wire logic                       cpu_halted,
  // ---- system register port (ControlCore / host through the fabric)
  input  wire logic                       s_req,
  input  wire logic                       s_we,
  input  wire logic                       s_priv,            // requester is the ControlCore CPU (trusted)
  input  wire logic [11:0]                s_addr,
  input  wire logic [31:0]                s_wdata,
  output logic                            s_gnt,
  output logic [31:0]                     s_rdata,
  output logic                            s_err,
  // ---- functional side of each group
  output logic [NG-1:0]                   quiesce_req,
  input  wire logic [NG-1:0]              quiesce_ack,
  input  wire logic [NG-1:0]              f_busy,
  input  wire logic [NG-1:0]              f_req,
  output logic [NG-1:0]                   f_block,
  input  wire logic [NG-1:0]              mem_init_busy,
  output logic [NG-1:0]                   mem_ready,
  // ---- memory raw test buses (group g uses the low bits of its slice)
  output logic [NG-1:0]                   tst_active,
  output logic [NG*MAXNB-1:0]             tst_sel,
  output logic [NG-1:0]                   tst_ce,
  output logic [NG-1:0]                   tst_we,
  output logic [NG*MAXRAW-1:0]            tst_addr,
  output logic [NG*MAXSW-1:0]             tst_wdata,
  input  wire logic [NG*MAXNB*MAXSW-1:0]  tst_rdata,
  // ---- clock / reset test controls (to the clock-reset tree P35, power domains P36, memories)
  output logic                            dft_test_mode,     // reset-synchroniser bypass (P35/P36 test_mode_i)
  output logic                            dft_icg_te,        // ICG scan enable (P35 test_en_i)
  output logic                            dft_scan_en,       // scan-enable network
  output logic                            dft_test_rst_n,    // P35 test_rst_ni
  output logic                            dft_mem_inhibit,   // memory CE inhibit while scan logic toggles
  output logic [NG-1:0]                   mbist_clk_req,     // keep the group's clock branch running (P35 br_clk_req_i)
  // ---- debug gating
  output logic                            dbg_allow,         // ControlCore debug module may be used
  output logic                            jtag_mode,
  output logic                            diag_mode,
  // ---- RAS (Project 26) external event port
  output logic                            ras_ev_valid,
  output logic [3:0]                      ras_ev_type,
  output logic [31:0]                     ras_ev_addr,
  output logic                            ras_ev_addr_v,
  output logic [31:0]                     ras_ev_info,
  output logic                            ras_ev_corr,
  // ---- status
  output logic                            irq,
  output logic [2:0]                      mode,
  output logic                            test_done,         // wafer-probe status pins (sequence)
  output logic                            test_pass,
  output logic                            test_fail
);
  `include "sftc_consts.svh"
  `include "sfta_consts.svh"

  if (NG < 1 || NG > TA_MAX_GROUPS) begin : g_err_ng $error("silicaflux_test_access: NG must be 1..7"); end

  function automatic integer f_nbt(input integer unused);
    f_nbt = 0;
    for (int g = 0; g < NG; g++) f_nbt = f_nbt + {24'd0, G_NB[g*8 +: 8]};
  endfunction
  // per-bank width / depth of group g (0 in G_BW / G_BD = the group value)
  function automatic logic [MAXNB*8-1:0] f_bw(input integer g);
    f_bw = '0;
    for (int b = 0; b < MAXNB; b++)
      f_bw[b*8 +: 8] = (G_BW[(g*MAXNB + b)*8 +: 8] == 8'd0) ? G_SW[g*16 +: 8] : G_BW[(g*MAXNB + b)*8 +: 8];
  endfunction
  function automatic logic [MAXNB*24-1:0] f_bd(input integer g);
    f_bd = '0;
    for (int b = 0; b < MAXNB; b++)
      f_bd[b*24 +: 24] = (G_BD[(g*MAXNB + b)*24 +: 24] == 24'd0) ? G_DEPTH[g*24 +: 24] : G_BD[(g*MAXNB + b)*24 +: 24];
  endfunction
  function automatic logic [NG*32-1:0] f_grp_info(input integer unused);
    logic [4:0] rw;
    f_grp_info = '0;
    for (int g = 0; g < NG; g++) begin
      rw = 5'd1;
      for (int i = 2; i < 24; i++) if (G_DEPTH[g*24 +: 24] > (24'd1 << (i - 1))) rw = 5'(i);
      f_grp_info[g*32 +: 32] = {G_PIPE_REQ[g] | G_PIPE_RSP[g], G_INIT_ON_RESET[g], G_INIT[g*4 +: 2],
                                G_KIND[g*4 +: 4], 3'(G_LAT[g*4 +: 4] - 4'd1), rw,
                                (G_SW[g*16 +: 16] > 16'd255) ? 8'hFF : G_SW[g*16 +: 8], G_NB[g*8 +: 8]};
    end
  endfunction
  localparam int NBT = f_nbt(0);

  // ===================================================================== lifecycle policy
  logic perm_jtag, perm_dbg, perm_mbist, perm_scan, perm_host_wr, perm_ift, lc_incons;
  sfta_lc_policy u_lc (
    .lc_valid, .lc_state, .sb_debug_en, .sb_test_mode_en, .otp_ift_en,
    .perm_jtag, .perm_dbg, .perm_mbist, .perm_scan, .perm_host_wr, .perm_ift, .inconsistent(lc_incons)
  );

  // ===================================================================== JTAG (TestCore P07, unmodified)
  logic [3:0] tap_state;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [4:0] ir;
  logic launch_tck, exec_sys;
  /* verilator lint_on UNUSEDSIGNAL */
  logic sel_reg, sel_status, tdo_reg, tdo_status;
  sftc_jtag_tap u_tap (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .state_o(tap_state), .ir_o(ir),
    .sel_reg, .sel_status, .tdo_reg_i(tdo_reg), .tdo_status_i(tdo_status)
  );
  logic j_req, j_we, j_gnt, j_err;
  logic [11:0] j_addr;
  logic [31:0] j_wdata, j_rdata;
  sftc_jtag_reg_bridge u_bridge (
    .tck, .trst_n, .tap_state, .sel_reg, .sel_status, .tdi, .tdo_reg, .tdo_status,
    .clk, .rst_n, .m_req(j_req), .m_we(j_we), .m_addr(j_addr), .m_wdata(j_wdata),
    .m_gnt(j_gnt), .m_rdata(j_rdata), .m_err(j_err), .launch_tck, .exec_sys
  );

  // ===================================================================== register access gate + arbiter
  wire         j_sel   = j_req;                       // JTAG has priority (as TestCore)
  wire         r_req   = j_req || s_req;
  wire         r_we    = j_sel ? j_we    : s_we;
  wire  [11:0] r_addr  = j_sel ? j_addr  : s_addr;
  wire  [31:0] r_wdata = j_sel ? j_wdata : s_wdata;
  wire  [2:0]  r_page  = r_addr[11:9];
  wire  [8:0]  r_off   = r_addr[8:0];

  wire r_allowed = j_sel ? perm_jtag
                         : (s_priv || perm_host_wr || (!s_we && r_page == 3'd0));
  wire r_page_ok = (32'(r_page) <= NG);
  // global controls live in page 0: a group page's MODE_CTRL / UNLOCK are refused
  wire r_grp_restricted = (r_page != 3'd0) && r_we &&
                          (r_off == R_MODE_CTRL[8:0] || r_off == R_UNLOCK[8:0]);
  wire r_fwd = r_req && r_allowed && r_page_ok && !r_grp_restricted;

  logic        ta_gnt, ta_err;
  logic [31:0] ta_rdata;
  logic [NG-1:0]    pg_gnt_v, pg_err_v;
  logic [NG*32-1:0] pg_rdata_v;
  logic [31:0] grp_rdata;
  always_comb begin
    grp_rdata = '0;
    for (int g = 0; g < NG; g++) grp_rdata |= pg_rdata_v[g*32 +: 32];
  end
  wire r_gate_err = r_req && (!r_allowed || !r_page_ok || r_grp_restricted);
  wire [31:0] r_rdata = ta_rdata | grp_rdata;
  wire        r_err   = r_gate_err || ta_err || (|pg_err_v);

  assign j_gnt   = j_sel;
  assign j_rdata = r_rdata;
  assign j_err   = r_err;
  assign s_gnt   = !j_sel && s_req;
  assign s_rdata = j_sel ? 32'd0 : r_rdata;
  assign s_err   = !j_sel && s_req && r_err;

  // security violations and gate bus errors
  logic       e_viol;
  logic [3:0] e_viol_src;
  always_comb begin
    e_viol = 1'b0; e_viol_src = '0;
    if (r_req && !r_allowed) begin
      e_viol = 1'b1;
      e_viol_src = j_sel ? TA_VS_JTAG : (r_we ? TA_VS_HOST_WR : TA_VS_HOST_RD);
    end
  end
  wire e_gate_bus_err = r_req && r_allowed && (!r_page_ok || r_grp_restricted);

  // ===================================================================== global mode controller (TestCore P07, unmodified)
  logic       mreq_v, unlocked, mode_busy, mbist_enable, mbist_abort, scan_mode, scan_en, ev_illegal, ev_denied;
  logic [2:0] mreq, mode_pend;
  logic [NG-1:0] g_busy, g_released;
  silicaflux_test_mode_controller u_mode (
    .clk, .rst_n, .hw_dbg_en(perm_dbg), .hw_test_en(perm_mbist), .unlocked,
    .scan_mode_pin(scan_mode_pin && perm_scan), .scan_en_pin,
    .req_valid(mreq_v), .req_mode(mreq), .mbist_busy(|g_busy), .banks_released(&g_released),
    .mode, .mode_busy, .pending(mode_pend), .mbist_enable, .mbist_abort, .jtag_mode, .diag_mode,
    .scan_mode, .scan_en, .ev_illegal, .ev_denied
  );

  // TEST_MODE pin synchronised for status / violation logging only (the scan
  // path itself uses the pin combinationally, it is static during scan)
  logic scan_pin_s, scan_viol_q, incons_q, perm_mbist_q, perm_dbg_q;
  logic [2:0] mode_q;
  sftc_sync #(.W(1)) u_scan_sync (.clk, .rst_n, .d(scan_mode_pin), .q(scan_pin_s));
  wire scan_viol = scan_pin_s && !perm_scan;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      scan_viol_q <= 1'b0; incons_q <= 1'b0; perm_mbist_q <= 1'b0; perm_dbg_q <= 1'b0; mode_q <= MODE_NORMAL;
    end else begin
      scan_viol_q <= scan_viol; incons_q <= lc_incons; perm_mbist_q <= perm_mbist; perm_dbg_q <= perm_dbg;
      mode_q <= mode;
    end
  end
  wire ev_scan_viol = scan_viol && !scan_viol_q;
  wire ev_lc_incons = lc_incons && !incons_q;
  wire ev_perm_loss = (perm_mbist_q && !perm_mbist && mode_q == MODE_MBIST) ||
                      (perm_dbg_q && !perm_dbg && (mode_q == MODE_JTAG_ACCESS || mode_q == MODE_DIAGNOSTIC));

  logic       ev_v;
  logic [3:0] ev_v_src;
  logic [11:0] ev_v_addr;
  always_comb begin
    ev_v = 1'b1; ev_v_src = e_viol_src; ev_v_addr = r_addr;
    if (e_viol)            begin ev_v_src = e_viol_src;     ev_v_addr = r_addr; end
    else if (ev_denied)    begin ev_v_src = TA_VS_MODE;     ev_v_addr = {3'd0, TA_R_MODE_CTRL}; end
    else if (ev_scan_viol) begin ev_v_src = TA_VS_SCAN_PIN; ev_v_addr = '0; end
    else if (ev_perm_loss) begin ev_v_src = TA_VS_PERM_LOSS; ev_v_addr = '0; end
    else                   ev_v = 1'b0;
  end

  // ===================================================================== sequencer
  logic          sq_start, sq_abort, sq_clear, sq_par, sq_sof, sq_esof, sq_bg, sq_scrub;
  logic [3:0]    sq_algo;
  logic [NG-1:0] sq_groups;
  logic [31:0]   sq_wdog, sq_cycles;
  logic          sq_busy, sq_done, sq_pass, sq_fail, sq_errs, sq_ev_seq_refused, sq_ev_done;
  logic [2:0]    sq_cur_group, sq_cur_phase;
  logic [NG*4-1:0] sq_result;
  logic [NG-1:0] sq_fin, sq_sel, sq_acq, sq_gstart, sq_gabort, sq_gclear, sq_ev_tmo, sq_ev_ref;
  logic [NG*3-1:0] sq_ev_tmo_phase;
  logic [NG*3-1:0] g_last;
  logic [NG-1:0] g_owned_all, g_acq_blocked, g_owner_fault, g_refused;

  sfta_seq #(.NG(NG)) u_seq (
    .clk, .rst_n, .start(sq_start), .abort(sq_abort), .clear(sq_clear), .parallel(sq_par),
    .stop_on_fail(sq_sof), .groups(sq_groups), .wdog_limit(sq_wdog), .mbist_enable, .mode_exit(mode_busy),
    .g_busy, .g_last, .g_owned_all, .g_acq_blocked, .g_released, .g_owner_fault, .g_refused,
    .seq_sel(sq_sel), .seq_acq(sq_acq), .seq_start(sq_gstart), .seq_abort(sq_gabort), .seq_clear(sq_gclear),
    .busy(sq_busy), .done(sq_done), .pass(sq_pass), .fail(sq_fail), .err(sq_errs),
    .cur_group(sq_cur_group), .cur_phase(sq_cur_phase), .result(sq_result), .fin_mask(sq_fin),
    .cycles(sq_cycles), .ev_timeout(sq_ev_tmo), .ev_timeout_phase(sq_ev_tmo_phase), .ev_refused(sq_ev_ref),
    .ev_seq_refused(sq_ev_seq_refused), .ev_seq_done(sq_ev_done)
  );

  // ===================================================================== memory groups
  logic [NG-1:0] g_done, g_pass, g_fail, g_ev_done, g_ev_refused, g_ev_eng_err, g_irq;
  logic [NG-1:0] g_ev_ofault, g_ev_intr, g_ev_reinit, g_intr_q;
  logic [NG*24-1:0] g_ff_info;
  logic [NG*MAXRAW-1:0] g_ff_addr;
  logic [NG*32-1:0] g_live;

  for (genvar g = 0; g < NG; g++) begin : g_grp
    localparam int NBg   = {24'd0, G_NB[g*8 +: 8]};
    localparam int SWg   = {16'd0, G_SW[g*16 +: 16]};
    localparam int DPg   = {8'd0, G_DEPTH[g*24 +: 24]};
    localparam int LATg  = {28'd0, G_LAT[g*4 +: 4]};
    localparam int INITg = {28'd0, G_INIT[g*4 +: 4]};
    localparam int RAWg  = (DPg > 2) ? $clog2(DPg) : 1;
    localparam logic [SWg-1:0] IWg = G_INIT_WORD[g*MAXSW +: SWg];

    localparam logic [MAXNB*8-1:0]  BWfull = f_bw(g);
    localparam logic [MAXNB*24-1:0] BDfull = f_bd(g);
    localparam logic [NBg*8-1:0]  BWg = BWfull[NBg*8-1:0];
    localparam logic [NBg*24-1:0] BDg = BDfull[NBg*24-1:0];

    if (NBg < 1 || NBg > MAXNB)   begin : g_err_nb  $error("silicaflux_test_access: group bank count outside 1..MAXNB"); end
    if (SWg < 1 || SWg > MAXSW)   begin : g_err_sw  $error("silicaflux_test_access: group width outside 1..MAXSW"); end
    if (SWg > 255)                begin : g_err_sw2 $error("silicaflux_test_access: TestCore bank width field is 8 bits"); end
    if (RAWg > MAXRAW)            begin : g_err_raw $error("silicaflux_test_access: group depth needs more than MAXRAW row bits"); end

    // ---- register page g+1
    wire pg_req = r_fwd && (r_page == 3'(g + 1));
    logic [31:0] pg_rdata;

    // ---- controller <-> collar
    logic [NBg-1:0]       acq_req, owned, owner_dirty, b_req, b_gnt, b_rvalid, b_rerr;
    logic [NBg*3-1:0]     owner_state;
    logic                 fault_clear, acq_blocked, ev_ofault, ev_intr, ev_reinit, m_busy;
    logic                 b_we;
    logic [RAWg-1:0]      b_addr;
    logic [SWg-1:0]       b_wdata;
    logic [NBg*SWg-1:0]   b_rdata;
    logic [2:0]           m_last, grp_state;
    logic                 ff_valid, grp_dirty, sweeping, released, clk_req_g;
    logic [23:0]          ff_info;
    logic [RAWg-1:0]      ff_addr;
    logic [RAWg-1:0]      tst_addr_g;
    logic [SWg-1:0]       tst_wdata_g;
    logic [NBg-1:0]       tst_sel_g;
    logic [NBg*SWg-1:0]   tst_rdata_g;
    always_comb begin
      for (int b = 0; b < NBg; b++) tst_rdata_g[b*SWg +: SWg] = tst_rdata[(g*MAXNB + b)*MAXSW +: SWg];
    end

    sfta_group_ctrl #(
      .NB(NBg), .MAX_W(SWg), .DEPTH(DPg), .BANK_WIDTHS(BWg), .BANK_DEPTHS(BDg), .BANK_FLAGS('0),
      .ALG_MASK(ALG_MASK), .LOG_DEPTH(LOG_DEPTH), .CNT_W(CNT_W), .TIMEOUT(ENG_TIMEOUT),
      .PIPE_REQ(G_PIPE_REQ[g]), .PIPE_RSP(G_PIPE_RSP[g])
    ) u_ctrl (
      .clk, .rst_n,
      .pg_req, .pg_we(r_we), .pg_off(r_off), .pg_wdata(r_wdata), .pg_gnt(pg_gnt_v[g]), .pg_rdata,
      .pg_err(pg_err_v[g]),
      .mode, .mode_busy, .mode_pend, .hw_test_en(perm_mbist), .hw_dbg_en(perm_dbg),
      .scan_pin(scan_pin_s), .mbist_enable, .mbist_abort, .cpu_halted,
      .seq_sel(sq_sel[g]), .seq_mask({NBg{sq_acq[g]}}), .seq_start(sq_gstart[g]), .seq_abort(sq_gabort[g]),
      .seq_clear(sq_gclear[g]), .seq_algo(sq_algo), .seq_bg(sq_bg), .seq_sof(sq_esof), .seq_scrub(sq_scrub),
      .acq_req, .acq_blocked, .fault_clear, .owner_state, .owned, .owner_dirty,
      .ev_owner_fault(ev_ofault), .ev_intrusion(ev_intr), .ev_reinit,
      .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr,
      .m_busy, .m_done(g_done[g]), .m_pass(g_pass[g]), .m_fail(g_fail[g]), .m_last,
      .ff_valid, .ff_info, .ff_addr, .ev_done(g_ev_done[g]), .ev_refused(g_ev_refused[g]),
      .ev_eng_err(g_ev_eng_err[g]), .irq(g_irq[g])
    );
    assign pg_rdata_v[g*32 +: 32] = pg_req ? pg_rdata : 32'd0;

    sfta_group_collar #(
      .NB(NBg), .SW(SWg), .DEPTH(DPg), .LAT(LATg), .INIT_MODE(INITg), .INIT_WORD(IWg),
      .INIT_ON_RESET({31'd0, G_INIT_ON_RESET[g]}), .OWN_TIMEOUT(OWN_TIMEOUT + DPg + LATg + 8), .MAX_W(SWg)
    ) u_collar (
      .clk, .rst_n,
      .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr,
      .acq_req, .fault_clear(fault_clear || sq_gclear[g]), .mbist_busy(m_busy),
      .owner_state, .owned, .owner_dirty, .ev_fault(ev_ofault), .ev_intrusion(ev_intr), .ev_reinit,
      .quiesce_req(quiesce_req[g]), .quiesce_ack(quiesce_ack[g]), .f_busy(f_busy[g]), .f_req(f_req[g]),
      .f_block(f_block[g]), .mem_init_busy(mem_init_busy[g]), .mem_ready(mem_ready[g]),
      .tst_active(tst_active[g]), .tst_sel(tst_sel_g), .tst_ce(tst_ce[g]), .tst_we(tst_we[g]),
      .tst_addr(tst_addr_g), .tst_wdata(tst_wdata_g), .tst_rdata(tst_rdata_g),
      .grp_state, .grp_dirty, .sweeping, .released, .clk_req(clk_req_g)
    );

    assign tst_sel  [g*MAXNB  +: MAXNB]  = MAXNB'(tst_sel_g);
    assign tst_addr [g*MAXRAW +: MAXRAW] = MAXRAW'(tst_addr_g);
    assign tst_wdata[g*MAXSW  +: MAXSW]  = MAXSW'(tst_wdata_g);

    assign g_busy[g]        = m_busy;
    assign g_released[g]    = released;
    assign g_last[g*3 +: 3] = m_last;
    assign g_owned_all[g]   = &owned;
    assign g_acq_blocked[g] = acq_blocked;
    assign g_owner_fault[g] = (grp_state == OWN_FAULT);
    assign g_refused[g]     = g_ev_refused[g];
    assign g_ev_ofault[g]   = ev_ofault;
    assign g_ev_intr[g]     = ev_intr;
    assign g_ev_reinit[g]   = ev_reinit;
    assign g_ff_info[g*24 +: 24]      = ff_info;
    assign g_ff_addr[g*MAXRAW +: MAXRAW] = MAXRAW'(ff_addr);
    assign mbist_clk_req[g] = clk_req_g;
    assign g_live[g*32 +: 32] = {12'd0, ff_valid, m_last, m_busy, sq_sel[g], acq_blocked, mem_ready[g], released,
                                 clk_req_g, tst_active[g], f_block[g], quiesce_ack[g], quiesce_req[g],
                                 mem_init_busy[g], sweeping, grp_dirty, grp_state};
  end

  // intrusion: one event per episode (the owner flags every cycle a request is presented)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) g_intr_q <= '0;
    else        g_intr_q <= g_ev_intr;
  end

  // ===================================================================== page 0
  localparam logic [NG*32-1:0] GRP_INFO_P = f_grp_info(0);
  logic ta_irq;

  sfta_regs #(
    .NG(NG), .NBT(NBT), .SCAN_CHAINS(SCAN_CHAINS), .GRP_INFO(GRP_INFO_P), .AWMAX(MAXRAW)
  ) u_regs (
    .clk, .rst_n,
    .req(r_fwd && r_page == 3'd0), .we(r_we), .off(r_off), .wdata(r_wdata), .gnt(ta_gnt),
    .rdata(ta_rdata), .err(ta_err),
    .mode_req_valid(mreq_v), .mode_req(mreq), .unlocked,
    .mode, .mode_busy, .mode_pend, .mbist_enable, .jtag_mode, .diag_mode, .scan_mode, .scan_en,
    .scan_pin_raw(scan_pin_s), .scan_pin_gated(scan_pin_s && perm_scan),
    .lc_valid, .lc_state, .sb_debug_en, .sb_test_mode_en, .otp_ift_en, .lc_incons,
    .perm({perm_ift, perm_host_wr, perm_scan, perm_mbist, perm_dbg, perm_jtag}),
    .seq_start(sq_start), .seq_abort(sq_abort), .seq_clear(sq_clear), .seq_parallel(sq_par),
    .seq_sof(sq_sof), .seq_eng_sof(sq_esof), .seq_bg(sq_bg), .seq_scrub(sq_scrub), .seq_algo(sq_algo),
    .seq_groups(sq_groups), .wdog_limit(sq_wdog),
    .sq_busy, .sq_done, .sq_pass, .sq_fail, .sq_err(sq_errs), .sq_cur_group, .sq_cur_phase,
    .sq_result, .sq_fin, .sq_cycles, .sq_ev_done,
    .g_busy, .g_done, .g_pass, .g_fail, .g_live, .g_ff_info, .g_ff_addr, .g_last,
    .clk_req(mbist_clk_req), .dft_test_mode, .dft_scan_en, .dft_test_rst_n, .dft_mem_inhibit, .cpu_halted,
    .e_fail(g_ev_done & g_fail), .e_err(g_ev_eng_err), .e_tmo(sq_ev_tmo), .e_tmo_phase(sq_ev_tmo_phase),
    .e_ofault(g_ev_ofault), .e_intr(g_ev_intr & ~g_intr_q), .e_reinit(g_ev_reinit),
    .e_refused(g_ev_refused | sq_ev_ref), .e_seq_refused(sq_ev_seq_refused || ev_illegal),
    .e_bus_err(e_gate_bus_err),
    .e_viol(ev_v), .e_viol_src(ev_v_src), .e_viol_addr(ev_v_addr), .e_lc_incons(ev_lc_incons),
    .ras_valid(ras_ev_valid), .ras_type(ras_ev_type), .ras_addr(ras_ev_addr), .ras_addr_v(ras_ev_addr_v),
    .ras_info(ras_ev_info), .ras_corr(ras_ev_corr), .irq(ta_irq)
  );

  // ===================================================================== DFT clock / reset controls
  assign dft_test_mode   = scan_mode;
  assign dft_icg_te      = scan_mode;                  // P35: test_en_i = 1 for the whole scan session
  assign dft_scan_en     = scan_en;
  assign dft_test_rst_n  = scan_mode ? test_rst_n_pin : 1'b1;
  assign dft_mem_inhibit = scan_mode;

  assign dbg_allow = perm_dbg;
  assign irq       = ta_irq || (|g_irq);
  assign test_done = sq_done;
  assign test_pass = sq_pass;
  assign test_fail = sq_done && !sq_pass;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = ^{ta_gnt, pg_gnt_v, perm_ift};
  /* verilator lint_on UNUSEDSIGNAL */

`ifdef SFTC_CHECKS
  always @(posedge clk) begin
    if (rst_n) begin
      `SFTC_ASSERT(!scan_mode || perm_scan, "scan mode without DEV lifecycle")
      `SFTC_ASSERT(!mbist_enable || perm_mbist, "MBIST enabled without lifecycle permission")
      `SFTC_ASSERT(!(j_req && !perm_jtag && (r_fwd)), "JTAG register access forwarded outside DEV")
      `SFTC_ASSERT(!jtag_mode || perm_dbg, "JTAG_ACCESS mode outside DEV")
      `SFTC_ASSERT(!(|tst_ce) || (|tst_active), "raw test access without tst_active")
    end
  end
`endif
endmodule

`default_nettype wire
