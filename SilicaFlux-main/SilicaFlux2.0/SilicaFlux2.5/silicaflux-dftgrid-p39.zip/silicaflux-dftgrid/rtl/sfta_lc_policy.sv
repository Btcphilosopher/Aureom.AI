// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: sfta_lc_policy
// Lifecycle -> test/debug permission decode.  PURELY COMBINATIONAL on purpose:
// no flop of the test-access block lies on the scan-mode path, so shifting the
// test-access scan chains can never change the scan permission.  (The
// lifecycle source itself -- SecureBoot P28 lc_eff_q -- must be excluded from
// scan by the DFT flow; see docs/04_SECURITY.md, readiness item S-3.)
//
// Inputs come from SecureBoot (P28 silicaflux_secure_boot):
//   lc_valid        lifecycle sensed and latched (P28 init_q)
//   lc_state        effective lifecycle (P28 lc_eff_q: DEV/PROV/PROD/RECOVERY/INVALID)
//   sb_debug_en     P28 debug_en      (= DEV)
//   sb_test_mode_en P28 test_mode_en  (= DEV)
//   otp_ift_en      fuse configuration: in-field memory self-test by the
//                   authenticated ControlCore firmware outside DEV
//
//   state            JTAG   debug  scan  host  MBIST (CPU)      MBIST (JTAG)
//                    TC_REG modes  pin   write
//   not sensed       -      -      -     -     -                -
//   DEV              yes    yes    yes   yes   yes              yes
//   PROV/PROD/REC    -      -      -     -     if otp_ift_en    -  (JTAG refused)
//   INVALID          -      -      -     -     -                -
//   inconsistent     -      -      -     -     -                -   (+ LC_INCONS event)
// IDCODE / BYPASS stay available in every state (identification only, as P28).
// "inconsistent": the lifecycle enum and SecureBoot's own debug/test enables
// disagree (glitch, tamper, integration error) -> everything closed.
// Classification: SYNTHESIZABLE (combinational)
// =============================================================================
`default_nettype none

module sfta_lc_policy (
  input  wire logic       lc_valid,
  input  wire logic [3:0] lc_state,
  input  wire logic       sb_debug_en,
  input  wire logic       sb_test_mode_en,
  input  wire logic       otp_ift_en,
  output logic            perm_jtag,      // JTAG TC_REG register access
  output logic            perm_dbg,       // JTAG_ACCESS / DIAGNOSTIC modes (TestCore hw_dbg_en)
  output logic            perm_mbist,     // MBIST hardware permission (TestCore hw_test_en)
  output logic            perm_scan,      // scan_mode pin honoured
  output logic            perm_host_wr,   // unprivileged requesters may write / read group pages
  output logic            perm_ift,       // in-field (firmware) MBIST outside DEV
  output logic            inconsistent
);
  `include "sfta_consts.svh"

  wire is_dev   = (lc_state == TA_LC_DEV);
  wire is_field = (lc_state == TA_LC_PROV) || (lc_state == TA_LC_PROD) || (lc_state == TA_LC_RECOVERY);
  wire known    = is_dev || is_field || (lc_state == TA_LC_INVALID);

  assign inconsistent = lc_valid && (!known || (sb_debug_en != is_dev) || (sb_test_mode_en != is_dev));
  wire ok = lc_valid && !inconsistent;

  assign perm_jtag    = ok && is_dev;
  assign perm_dbg     = ok && is_dev;
  assign perm_scan    = ok && is_dev;
  assign perm_host_wr = ok && is_dev;
  assign perm_ift     = ok && is_field && otp_ift_en;
  assign perm_mbist   = (ok && is_dev) || perm_ift;
endmodule

`default_nettype wire
