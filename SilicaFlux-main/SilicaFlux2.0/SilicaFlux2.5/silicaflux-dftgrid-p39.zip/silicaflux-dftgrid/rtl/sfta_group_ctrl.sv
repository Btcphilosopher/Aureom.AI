// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: sfta_group_ctrl
// Distributed MBIST controller of one memory group = the unmodified TestCore
// P07 blocks
//   sftc_regs            register page (page g+1 of the test-access space)
//   silicaflux_mbist     March engine (6 algorithms, fail log, timeouts)
//   sftc_mbist_bank_mux  bank selector (+ optional request / response
//                        pipeline stages for the distance to the collar)
// plus the composition logic that TestCore's sftc_testcore_top provides for a
// single-controller system, adapted to a multi-group chip:
//   * the test mode, unlock and permissions are GLOBAL (one mode controller
//     in silicaflux_test_access); this page's MODE_CTRL / UNLOCK registers are
//     refused by the page decoder, its MODE_STATUS mirrors the global mode;
//   * the global MBIST sequencer can take the group over (seq_sel): its
//     START / configuration / bank mask then replace the page's; a page START
//     while the sequencer owns the group is ignored and flagged
//     (ERROR_FLAGS.ILLEGAL_START);
//   * acquisition: acq_req[b] = MBIST mode && not exiting && selected &&
//     (not PROTECTed || cpu_halted)   (as TestCore);
//   * ERROR_FLAGS sources: engine, ownership (fault / intrusion / reinit).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sfta_group_ctrl #(
  parameter int NB          = 4,
  parameter int MAX_W       = 72,
  parameter int DEPTH       = 1024,                 // deepest bank (rows)
  parameter logic [NB*8-1:0]  BANK_WIDTHS = {NB{8'd72}},
  parameter logic [NB*24-1:0] BANK_DEPTHS = {NB{24'd1024}},
  parameter logic [NB*8-1:0]  BANK_FLAGS  = {NB{8'd0}},
  parameter logic [15:0] ALG_MASK = 16'h003F,
  parameter int LOG_DEPTH   = 4,
  parameter int CNT_W       = 16,
  parameter int TIMEOUT     = 1024,                 // engine request / response timeout
  parameter bit PIPE_REQ    = 1'b0,
  parameter bit PIPE_RSP    = 1'b0,
  localparam int AW         = (DEPTH > 2) ? $clog2(DEPTH) : 1,
  localparam int BW         = (NB > 1) ? $clog2(NB) : 1
) (
  input  wire logic                clk,
  /* verilator lint_off SYNCASYNCNET */
  input  wire logic                rst_n,          // also sampled by the simulation-only assertion blocks
  /* verilator lint_on SYNCASYNCNET */
  // ---- register page (already decoded to this group)
  input  wire logic                pg_req,
  input  wire logic                pg_we,
  input  wire logic [8:0]          pg_off,
  input  wire logic [31:0]         pg_wdata,
  output logic                     pg_gnt,
  output logic [31:0]              pg_rdata,
  output logic                     pg_err,
  // ---- global mode / permissions
  input  wire logic [2:0]          mode,
  input  wire logic                mode_busy,
  input  wire logic [2:0]          mode_pend,
  input  wire logic                hw_test_en,
  input  wire logic                hw_dbg_en,
  input  wire logic                scan_pin,
  input  wire logic                mbist_enable,
  input  wire logic                mbist_abort,
  input  wire logic                cpu_halted,
  // ---- sequencer override
  input  wire logic                seq_sel,
  input  wire logic [NB-1:0]       seq_mask,
  input  wire logic                seq_start,
  input  wire logic                seq_abort,
  input  wire logic                seq_clear,
  input  wire logic [3:0]          seq_algo,
  input  wire logic                seq_bg,
  input  wire logic                seq_sof,
  input  wire logic                seq_scrub,
  // ---- collar coupling
  output logic [NB-1:0]            acq_req,
  output logic                     acq_blocked,     // a selected bank cannot be acquired (PROTECT, CPU running)
  output logic                     fault_clear,
  input  wire logic [NB*3-1:0]     owner_state,
  input  wire logic [NB-1:0]       owned,
  input  wire logic [NB-1:0]       owner_dirty,
  input  wire logic                ev_owner_fault,
  input  wire logic                ev_intrusion,
  input  wire logic                ev_reinit,
  // ---- bank bus (to the collar)
  output logic [NB-1:0]            b_req,
  output logic                     b_we,
  output logic [AW-1:0]            b_addr,
  output logic [MAX_W-1:0]         b_wdata,
  input  wire logic [NB-1:0]       b_gnt,
  input  wire logic [NB-1:0]       b_rvalid,
  input  wire logic [NB*MAX_W-1:0] b_rdata,
  input  wire logic [NB-1:0]       b_rerr,
  // ---- status for the test-access block
  output logic                     m_busy,
  output logic                     m_done,
  output logic                     m_pass,
  output logic                     m_fail,
  output logic [2:0]               m_last,
  output logic                     ff_valid,
  output logic [23:0]              ff_info,
  output logic [AW-1:0]            ff_addr,
  output logic                     ev_done,
  output logic                     ev_refused,
  output logic                     ev_eng_err,      // engine timeout / spurious response
  output logic                     irq
);
  `include "sftc_consts.svh"

  // ------------------------------------------------------------------ register page (TestCore, unmodified)
  logic c_start, c_abort, c_clear, c_bg, c_sof, c_scrub, c_pop, mreq_v_u, unlocked_u;
  logic [3:0] c_algo;
  logic [2:0] mreq_u;
  logic [NB-1:0] c_mask, protect;

  logic m_aborted, m_error, m_stopped, m_scrub;
  logic [3:0] m_state, m_algo;
  logic [BW-1:0] m_bank;
  logic [2:0] m_elem, m_prev;
  logic [AW-1:0] m_addr;
  logic [NB-1:0] m_tested, m_failed, m_scrubbed_u;
  logic [31:0] m_cycles;
  logic ev_tmo, ev_spur, ev_merr, cnt_ovf, log_ovf, cnt_ovf_q, log_ovf_q;
  logic [MAX_W-1:0] ff_exp, ff_obs, log_synd;
  logic [CNT_W-1:0] fail_count;
  logic [7:0] log_level;
  logic [23:0] log_info;
  logic [AW-1:0] log_addr;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin cnt_ovf_q <= 1'b0; log_ovf_q <= 1'b0; end
    else        begin cnt_ovf_q <= cnt_ovf; log_ovf_q <= log_ovf; end
  end

  wire page_start_ignored = c_start && seq_sel;
  logic [NUM_EF-1:0] ev_flags;
  always_comb begin
    ev_flags = '0;
    ev_flags[EF_TIMEOUT]       = ev_tmo;
    ev_flags[EF_SPURIOUS]      = ev_spur;
    ev_flags[EF_ILLEGAL_START] = ev_refused || page_start_ignored;
    ev_flags[EF_CNT_OVF]       = cnt_ovf && !cnt_ovf_q;
    ev_flags[EF_LOG_OVF]       = log_ovf && !log_ovf_q;
    ev_flags[EF_MEM_ERR]       = ev_merr;
    ev_flags[EF_OWNER_FAULT]   = ev_owner_fault;
    ev_flags[EF_INTRUSION]     = ev_intrusion;
    ev_flags[EF_REINIT_REQ]    = ev_reinit;
  end

  sftc_regs #(
    .BANK_COUNT(NB), .MAX_W(MAX_W), .AW(AW), .CNT_W(CNT_W), .BANK_WIDTHS(BANK_WIDTHS),
    .BANK_DEPTHS(BANK_DEPTHS), .BANK_FLAGS(BANK_FLAGS), .ALG_MASK(ALG_MASK), .LOG_DEPTH(LOG_DEPTH)
  ) u_regs (
    .clk, .rst_n, .req(pg_req), .we(pg_we), .addr({3'b000, pg_off}), .wdata(pg_wdata), .gnt(pg_gnt),
    .rdata(pg_rdata), .err(pg_err),
    .c_start, .c_abort, .c_clear, .c_algo, .c_bg_chk(c_bg), .c_sof, .c_scrub, .c_mask,
    .c_log_pop(c_pop), .mode_req_valid(mreq_v_u), .mode_req(mreq_u), .unlocked(unlocked_u), .protect,
    .owner_fault_clear(fault_clear), .irq,
    .mode, .mode_busy, .mode_pending(mode_pend), .hw_test_en, .hw_dbg_en, .scan_pin,
    .owner_state, .owner_dirty,
    .m_busy, .m_done, .m_pass, .m_fail, .m_aborted, .m_error, .m_stopped, .m_scrubbing(m_scrub),
    .m_state, .m_bank, .m_elem, .m_addr, .m_algo, .m_last, .m_prev, .m_tested, .m_failed,
    .m_cycles, .m_ff_valid(ff_valid), .m_ff_info(ff_info), .m_ff_addr(ff_addr), .m_ff_exp(ff_exp),
    .m_ff_obs(ff_obs), .m_fail_count(fail_count), .m_log_level(log_level), .m_log_ovf(log_ovf),
    .m_log_info(log_info), .m_log_addr(log_addr), .m_log_synd(log_synd),
    .ev_flags, .ev_done
  );

  // ------------------------------------------------------------------ engine control (page or sequencer)
  wire          e_start = (c_start && !seq_sel) || seq_start;
  wire          e_abort = c_abort || mbist_abort || seq_abort;
  wire          e_clear = c_clear || seq_clear;
  wire [3:0]    e_algo  = seq_sel ? seq_algo  : c_algo;
  wire          e_bg    = seq_sel ? seq_bg    : c_bg;
  wire          e_sof   = seq_sel ? seq_sof   : c_sof;
  wire          e_scrub = seq_sel ? seq_scrub : c_scrub;
  wire [NB-1:0] e_mask  = seq_sel ? seq_mask  : c_mask;

  always_comb begin
    for (int k = 0; k < NB; k++)
      acq_req[k] = mbist_enable && !mode_busy && e_mask[k] && (!protect[k] || cpu_halted);
  end
  assign acq_blocked = mbist_enable && !mode_busy && |(e_mask & ~acq_req);

  // ------------------------------------------------------------------ engine + bank selector (TestCore, unmodified)
  logic t_req, t_we, t_gnt, t_rvalid, t_rerr, t_stray;
  logic [AW-1:0] t_addr;
  logic [MAX_W-1:0] t_wdata, t_rdata;
  logic [BW-1:0] t_bank;

  silicaflux_mbist #(
    .BANK_COUNT(NB), .MAX_W(MAX_W), .MAX_DEPTH(DEPTH), .BANK_WIDTHS(BANK_WIDTHS),
    .BANK_DEPTHS(BANK_DEPTHS), .BANK_FLAGS(BANK_FLAGS), .ALG_MASK(ALG_MASK), .LOG_DEPTH(LOG_DEPTH),
    .CNT_W(CNT_W), .TIMEOUT(TIMEOUT)
  ) u_mbist (
    .clk, .rst_n, .test_enable(mbist_enable), .start(e_start), .abort(e_abort),
    .clear(e_clear), .cfg_algo(e_algo), .cfg_bg_chk(e_bg), .cfg_sof(e_sof), .cfg_scrub(e_scrub),
    .cfg_bank_mask(e_mask), .bank_owned(owned),
    .t_req, .t_we, .t_addr, .t_wdata, .t_bank, .t_gnt, .t_rvalid, .t_rdata, .t_rerr,
    .t_stray_rvalid(t_stray),
    .busy(m_busy), .done(m_done), .pass(m_pass), .fail(m_fail), .aborted(m_aborted),
    .error_st(m_error), .stopped(m_stopped), .scrubbing(m_scrub), .state(m_state), .cur_bank(m_bank),
    .cur_elem(m_elem), .cur_addr(m_addr), .run_algo(m_algo), .last_result(m_last),
    .prev_result(m_prev), .banks_tested(m_tested), .banks_failed(m_failed),
    .banks_scrubbed(m_scrubbed_u), .cycles(m_cycles),
    .ev_start_refused(ev_refused), .ev_timeout(ev_tmo), .ev_spurious(ev_spur), .ev_mem_err(ev_merr),
    .ev_done, .log_pop(c_pop), .ff_valid, .ff_info, .ff_addr, .ff_exp, .ff_obs, .fail_count,
    .cnt_ovf, .log_level, .log_ovf, .log_info, .log_addr, .log_synd
  );

  sftc_mbist_bank_mux #(.BANK_COUNT(NB), .MAX_W(MAX_W), .AW(AW), .PIPE_REQ(PIPE_REQ),
                        .PIPE_RSP(PIPE_RSP)) u_mux (
    .clk, .rst_n, .t_req, .t_we, .t_addr, .t_wdata, .t_bank, .t_gnt, .t_rvalid, .t_rdata, .t_rerr,
    .stray_rvalid(t_stray), .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr
  );

  assign ev_eng_err = ev_tmo || ev_spur;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = ^{mreq_v_u, mreq_u, unlocked_u, m_scrubbed_u};
  /* verilator lint_on UNUSEDSIGNAL */

`ifdef SFTC_CHECKS
  always @(posedge clk) begin
    if (rst_n) begin
      `SFTC_ASSERT(!(|b_req) || mbist_enable || m_busy, "bank request outside MBIST mode")
    end
  end
`endif
endmodule

`default_nettype wire
