// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: sfta_consts.svh
// Single authoritative definition of the test-access (TA) encodings:
//   * register map of page 0 (TA page) and the page layout
//   * lifecycle encodings (SecureBoot P28 effective-lifecycle enum)
//   * sequencer result codes, error classes, RAS event mapping, severities
// scripts/gen_regmap.py parses THIS file to generate docs/02_REGISTER_MAP.md and
// sw/include/silicaflux_test_access.h (single source of truth).
// Like the TestCore constants this file has no include guard: it is included
// INSIDE module bodies (localparams / automatic functions only).  Every name
// carries the TA_ prefix so it can be included next to sftc_consts.svh.
// Classification: SYNTHESIZABLE (constants and pure functions only)
// =============================================================================

  // ------------------------------------------------------------------ identity
  localparam logic [31:0] TA_ID_VALUE  = 32'h5346_5441;   // "SFTA"
  localparam logic [31:0] TA_REVISION  = 32'h0039_0100;   // Project 39, r1.0

  // ------------------------------------------------------------------ pages
  // 12-bit register address (the width of the TestCore JTAG TC_REG DR address
  // field): [11:9] page, [8:0] byte offset.  Page 0 = TA, page g+1 = memory
  // group g (an unmodified TestCore sftc_regs instance).  Max 7 groups.
  localparam int TA_PAGE_BITS = 3;
  localparam int TA_MAX_GROUPS = 7;

  // ------------------------------------------------------------------ lifecycle
  // Effective lifecycle as published by SecureBoot (P28 CC_SB_LC_*).
  localparam logic [3:0] TA_LC_DEV      = 4'd0;
  localparam logic [3:0] TA_LC_PROV     = 4'd1;
  localparam logic [3:0] TA_LC_PROD     = 4'd2;
  localparam logic [3:0] TA_LC_RECOVERY = 4'd3;
  localparam logic [3:0] TA_LC_INVALID  = 4'hF;

  // ------------------------------------------------------------------ page-0 registers
  localparam logic [8:0] TA_R_ID           = 9'h000;  // RO  "SFTA"
  localparam logic [8:0] TA_R_REVISION     = 9'h004;  // RO  [31:16] project (0x0039) [15:0] release
  localparam logic [8:0] TA_R_CAPS         = 9'h008;  // RO  [3:0] groups [11:4] total banks [12] seq [13] ras port [23:16] scan chains (0 = planning only)
  localparam logic [8:0] TA_R_IDCODE       = 9'h00C;  // RO  JTAG IDCODE value
  localparam logic [8:0] TA_R_SCRATCH      = 9'h010;  // RW  scratch (bus / JTAG loop-back)
  localparam logic [8:0] TA_R_LC_STATUS    = 9'h014;  // RO  lifecycle and derived permissions
  localparam logic [8:0] TA_R_MODE_CTRL    = 9'h018;  // RW  [2:0] requested test mode (write = request)
  localparam logic [8:0] TA_R_MODE_STATUS  = 9'h01C;  // RO  global test mode, permissions, unlock (fields below)
  localparam logic [8:0] TA_R_UNLOCK       = 9'h020;  // WO  TestCore unlock key (interlock, not security)
  localparam logic [8:0] TA_R_SEQ_CTRL     = 9'h024;  // RW  sequencer control (bits [2:0] self-clearing pulses)
  localparam logic [8:0] TA_R_SEQ_GROUPS   = 9'h028;  // RW  [NG-1:0] groups of the sequence
  localparam logic [8:0] TA_R_SEQ_STATUS   = 9'h02C;  // RO  sequencer status (fields below)
  localparam logic [8:0] TA_R_SEQ_RESULT   = 9'h030;  // RO  4 bits per group (TA_RES_*)
  localparam logic [8:0] TA_R_WDOG_LIMIT   = 9'h034;  // RW  per-phase watchdog (cycles, 0 = off)
  localparam logic [8:0] TA_R_SEQ_CYCLES   = 9'h038;  // RO  cycles of the last / running sequence
  localparam logic [8:0] TA_R_GRP_STATUS   = 9'h03C;  // RO  4 bits per group {fail, pass, done, busy} (engine)
  localparam logic [8:0] TA_R_ERR_STATUS   = 9'h040;  // W1C sticky error classes
  localparam logic [8:0] TA_R_ERR_IRQ_EN   = 9'h044;  // RW  error classes that raise irq
  localparam logic [8:0] TA_R_ERR_FIRST    = 9'h048;  // RW  [31] valid [29:28] sev [27:24] class [23:16] group [15:8] bank [7:0] aux; any write clears (re-arms)
  localparam logic [8:0] TA_R_ERR_FIRST_ADDR = 9'h04C; // RO  address of the first error (failing row / register address)
  localparam logic [8:0] TA_R_SEV_STATUS   = 9'h050;  // W1C [3:0] severities seen (INFO..FATAL)  RO [5:4] max severity seen
  localparam logic [8:0] TA_R_VIOL_INFO    = 9'h054;  // RO  last security violation [31] valid [27:24] source [11:0] address
  localparam logic [8:0] TA_R_VIOL_COUNT   = 9'h058;  // RO  saturating
  localparam logic [8:0] TA_R_SCAN_STATUS  = 9'h05C;  // RO  [0] scan_mode [1] scan_en [2] TEST_MODE pin (sync) [3] scan permission [4] pin refused [15:8] scan chains
  localparam logic [8:0] TA_R_CLKRST_STATUS= 9'h060;  // RO  [7:0] branch clock requests [8] test_mode [9] scan_en [10] test_rst_n [11] mem_inhibit [12] cpu_halted
  localparam logic [8:0] TA_R_RAS_STATUS   = 9'h064;  // RO  [15:0] events sent [31:16] events coalesced (lost)
  localparam logic [8:0] TA_R_IRQ_STATUS   = 9'h068;  // W1C [0] sequence done [1] sequence fail [2] error class
  localparam logic [8:0] TA_R_IRQ_EN       = 9'h06C;  // RW  enables for IRQ_STATUS[2:0]
  localparam logic [8:0] TA_R_ERR_CNT0     = 9'h080;  // RO  16-bit saturating count per class, 0x080 + 4*class
  localparam logic [8:0] TA_R_GRP_INFO0    = 9'h100;  // RO  0x100 + 8*g : static group description
  localparam logic [8:0] TA_R_GRP_LIVE0    = 9'h104;  // RO  0x104 + 8*g : live collar status

  // SEQ_CTRL fields
  localparam int TA_SEQ_START = 0, TA_SEQ_ABORT = 1, TA_SEQ_CLEAR = 2, TA_SEQ_PARALLEL = 3,
                 TA_SEQ_STOP_ON_FAIL = 4, TA_SEQ_ENG_SOF = 5, TA_SEQ_BG_CHK = 6, TA_SEQ_SCRUB = 7;
  // [11:8] algorithm (TestCore ALG_*)

  // ------------------------------------------------------------------ sequencer
  localparam logic [3:0] TA_RES_NOT_RUN     = 4'd0;
  localparam logic [3:0] TA_RES_PASS        = 4'd1;
  localparam logic [3:0] TA_RES_FAIL        = 4'd2;
  localparam logic [3:0] TA_RES_ABORTED     = 4'd3;
  localparam logic [3:0] TA_RES_ERROR       = 4'd4;   // engine inconclusive (protocol error / timeout)
  localparam logic [3:0] TA_RES_TIMEOUT     = 4'd5;   // sequencer watchdog expired
  localparam logic [3:0] TA_RES_REFUSED     = 4'd6;   // START refused / not permitted
  localparam logic [3:0] TA_RES_RUNNING     = 4'd7;
  localparam logic [3:0] TA_RES_OWNER_FAULT = 4'd8;   // ownership controller FAULT (quiesce / drain timeout)

  // per-group sequencer phase
  localparam logic [2:0] TA_GS_IDLE = 3'd0, TA_GS_ACQ = 3'd1, TA_GS_START = 3'd2, TA_GS_RUN = 3'd3,
                         TA_GS_STOP = 3'd4, TA_GS_REL = 3'd5, TA_GS_FIN = 3'd6;

  // ------------------------------------------------------------------ error classes
  localparam int TA_EC_MBIST_FAIL   = 0;   // a group test completed with a memory failure
  localparam int TA_EC_MBIST_ERROR  = 1;   // engine result ERROR (inconclusive: protocol / response timeout)
  localparam int TA_EC_SEQ_TIMEOUT  = 2;   // sequencer watchdog expired
  localparam int TA_EC_OWNER_FAULT  = 3;   // ownership FAULT: masters did not quiesce / drain in time
  localparam int TA_EC_INTRUSION    = 4;   // functional request presented to a group under test
  localparam int TA_EC_SEC_VIOL     = 5;   // access or mode refused by the lifecycle policy
  localparam int TA_EC_REINIT       = 6;   // group released with undefined content (REINIT_REQUIRED)
  localparam int TA_EC_LC_INCONS    = 7;   // lifecycle inputs inconsistent (fail closed)
  localparam int TA_EC_REFUSED      = 8;   // sequencer / engine START refused
  localparam int TA_EC_RAS_LOST     = 9;   // RAS event coalesced (same class+group still pending)
  localparam int TA_EC_BUS_ERR      = 10;  // TA register access to an unmapped / read-only location
  localparam int TA_NUM_EC          = 11;

  // RAS (Project 26) event types (sfras_defs.svh: SFRAS_EV_*; firmware contract, never renumbered)
  localparam logic [3:0] TA_RAS_MEM_UE     = 4'd2;
  localparam logic [3:0] TA_RAS_ILLEGAL_OP = 4'd8;
  localparam logic [3:0] TA_RAS_RECOVERY   = 4'd10;
  localparam logic [3:0] TA_RAS_TIMEOUT    = 4'd11;
  localparam logic [3:0] TA_RAS_NONE       = 4'd0;

  // severities (SFRAS_SEV_*): INFO 0, WARN 1, ERROR 2, FATAL 3
  localparam logic [1:0] TA_SEV_INFO = 2'd0, TA_SEV_WARN = 2'd1, TA_SEV_ERROR = 2'd2, TA_SEV_FATAL = 2'd3;

  function automatic logic [3:0] ta_ras_type(input int ec);
    case (ec)
      TA_EC_MBIST_FAIL:  ta_ras_type = TA_RAS_MEM_UE;
      TA_EC_MBIST_ERROR: ta_ras_type = TA_RAS_TIMEOUT;
      TA_EC_SEQ_TIMEOUT: ta_ras_type = TA_RAS_TIMEOUT;
      TA_EC_OWNER_FAULT: ta_ras_type = TA_RAS_TIMEOUT;
      TA_EC_INTRUSION:   ta_ras_type = TA_RAS_ILLEGAL_OP;
      TA_EC_SEC_VIOL:    ta_ras_type = TA_RAS_ILLEGAL_OP;
      TA_EC_REINIT:      ta_ras_type = TA_RAS_RECOVERY;
      TA_EC_LC_INCONS:   ta_ras_type = TA_RAS_ILLEGAL_OP;
      TA_EC_REFUSED:     ta_ras_type = TA_RAS_ILLEGAL_OP;
      default:           ta_ras_type = TA_RAS_NONE;      // RAS_LOST, BUS_ERR: local only
    endcase
  endfunction

  // TA-local severity = the RAS hardware minimum severity of the mapped type
  // (sfras_event_ctrl hw_min_sev), so both logs agree.
  function automatic logic [1:0] ta_sev(input int ec);
    case (ta_ras_type(ec))
      TA_RAS_MEM_UE, TA_RAS_TIMEOUT:      ta_sev = TA_SEV_ERROR;
      TA_RAS_ILLEGAL_OP, TA_RAS_RECOVERY: ta_sev = TA_SEV_WARN;
      default:                            ta_sev = TA_SEV_INFO;
    endcase
  endfunction

  // violation sources (VIOL_INFO[27:24])
  localparam logic [3:0] TA_VS_JTAG      = 4'd1;   // JTAG TC_REG access outside DEV
  localparam logic [3:0] TA_VS_HOST_WR   = 4'd2;   // unprivileged write outside DEV
  localparam logic [3:0] TA_VS_HOST_RD   = 4'd3;   // unprivileged read of a group page outside DEV
  localparam logic [3:0] TA_VS_SCAN_PIN  = 4'd4;   // TEST_MODE (scan) pin asserted outside DEV
  localparam logic [3:0] TA_VS_MODE      = 4'd5;   // mode request denied by the hardware permission
  localparam logic [3:0] TA_VS_PERM_LOSS = 4'd6;   // permission withdrawn while a test mode was active

  // group kinds (GRP_INFO[27:24]) and post-test initialisation modes
  localparam logic [3:0] TA_KIND_GRID    = 4'd0;   // Project 33 silicaflux_sram_grid
  localparam logic [3:0] TA_KIND_MEMCORE = 4'd1;   // MemoryCore sfmem_banked / sram_bank_controller
  localparam logic [3:0] TA_KIND_OTHER   = 4'd2;
  localparam int TA_INIT_COLLAR = 1;               // collar writes INIT_WORD to every row before release
  localparam int TA_INIT_SELF   = 2;               // memory re-initialises itself when tst_active falls
