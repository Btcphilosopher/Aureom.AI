// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: sfta_regs
// Page 0 of the test-access register space: identity, lifecycle and
// permission status, global test mode / unlock, MBIST sequencer, aggregated
// group status, error classes with severity, security-violation log, scan and
// clock/reset test status, and the RAS (Project 26) event port.
// Register map: sfta_consts.svh (TA_R_*), docs/02_REGISTER_MAP.md.
// Single-cycle register bus like TestCore sftc_regs (gnt = req).
//
// Error events.  Each event is (class c, column j): j = group index, or
// j = NG for test-access-level events (security violation, lifecycle,
// sequence-level refusal).  Per event: ERR_STATUS[c] (sticky, W1C), ERR_CNT[c]
// (+1 per event, saturating), ERR_FIRST / ERR_FIRST_ADDR (first event since
// cleared, lowest (c, j) wins within a cycle), SEV_STATUS (severity seen).
// RAS port: one pending bit per (c, j); one event per cycle is sent to the
// RAS external event port (lowest (c, j) first) with
//   type = ta_ras_type(c)            (MEM_UE / TIMEOUT / ILLEGAL_OP / RECOVERY)
//   info = {class, group (FF = TA), bank, aux}
//   addr = failing row (MBIST_FAIL) / register address (SEC_VIOL)
// The group's first-fail registers are stable after the engine finished, so
// MBIST_FAIL details are read at send time.  An event whose (c, j) is still
// pending is coalesced: RAS_STATUS lost count + ERR_STATUS[RAS_LOST].
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sfta_regs #(
  parameter int NG          = 2,
  parameter int NBT         = 8,                 // total banks (CAPS)
  parameter int SCAN_CHAINS = 0,                 // chains in the scan-inserted netlist (0 = planning only)
  parameter logic [NG*32-1:0] GRP_INFO = '0,     // static description word per group
  parameter int AWMAX       = 16,                // width of the group first-fail address inputs
  localparam int NC         = NG + 1,            // event columns
  localparam int NEV        = 11 * NC            // TA_NUM_EC * NC
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---- register bus (page 0)
  input  wire logic                req,
  input  wire logic                we,
  input  wire logic [8:0]          off,
  input  wire logic [31:0]         wdata,
  output logic                     gnt,
  output logic [31:0]              rdata,
  output logic                     err,
  // ---- to the global mode controller
  output logic                     mode_req_valid,
  output logic [2:0]               mode_req,
  output logic                     unlocked,
  // ---- mode status
  input  wire logic [2:0]          mode,
  input  wire logic                mode_busy,
  input  wire logic [2:0]          mode_pend,
  input  wire logic                mbist_enable,
  input  wire logic                jtag_mode,
  input  wire logic                diag_mode,
  input  wire logic                scan_mode,
  input  wire logic                scan_en,
  input  wire logic                scan_pin_raw,     // synchronised TEST_MODE pin (status only)
  input  wire logic                scan_pin_gated,
  // ---- lifecycle / permissions
  input  wire logic                lc_valid,
  input  wire logic [3:0]          lc_state,
  input  wire logic                sb_debug_en,
  input  wire logic                sb_test_mode_en,
  input  wire logic                otp_ift_en,
  input  wire logic                lc_incons,
  input  wire logic [5:0]          perm,             // {ift, host_wr, scan, mbist, dbg, jtag}
  // ---- sequencer
  output logic                     seq_start,
  output logic                     seq_abort,
  output logic                     seq_clear,
  output logic                     seq_parallel,
  output logic                     seq_sof,
  output logic                     seq_eng_sof,
  output logic                     seq_bg,
  output logic                     seq_scrub,
  output logic [3:0]               seq_algo,
  output logic [NG-1:0]            seq_groups,
  output logic [31:0]              wdog_limit,
  input  wire logic                sq_busy,
  input  wire logic                sq_done,
  input  wire logic                sq_pass,
  input  wire logic                sq_fail,
  input  wire logic                sq_err,
  input  wire logic [2:0]          sq_cur_group,
  input  wire logic [2:0]          sq_cur_phase,
  input  wire logic [NG*4-1:0]     sq_result,
  input  wire logic [NG-1:0]       sq_fin,
  input  wire logic [31:0]         sq_cycles,
  input  wire logic                sq_ev_done,
  // ---- groups
  input  wire logic [NG-1:0]       g_busy,
  input  wire logic [NG-1:0]       g_done,
  input  wire logic [NG-1:0]       g_pass,
  input  wire logic [NG-1:0]       g_fail,
  input  wire logic [NG*32-1:0]    g_live,
  input  wire logic [NG*24-1:0]    g_ff_info,
  input  wire logic [NG*AWMAX-1:0] g_ff_addr,
  input  wire logic [NG*3-1:0]     g_last,
  // ---- clock / reset test status
  input  wire logic [NG-1:0]       clk_req,
  input  wire logic                dft_test_mode,
  input  wire logic                dft_scan_en,
  input  wire logic                dft_test_rst_n,
  input  wire logic                dft_mem_inhibit,
  input  wire logic                cpu_halted,
  // ---- events (pulses)
  input  wire logic [NG-1:0]       e_fail,
  input  wire logic [NG-1:0]       e_err,
  input  wire logic [NG-1:0]       e_tmo,
  input  wire logic [NG*3-1:0]     e_tmo_phase,
  input  wire logic [NG-1:0]       e_ofault,
  input  wire logic [NG-1:0]       e_intr,
  input  wire logic [NG-1:0]       e_reinit,
  input  wire logic [NG-1:0]       e_refused,
  input  wire logic                e_seq_refused,
  input  wire logic                e_bus_err,        // access-gate bus error (bad page, restricted register)
  input  wire logic                e_viol,
  input  wire logic [3:0]          e_viol_src,
  input  wire logic [11:0]         e_viol_addr,
  input  wire logic                e_lc_incons,
  // ---- RAS external event port (Project 26 silicaflux_ras ext_ev_*)
  output logic                     ras_valid,
  output logic [3:0]               ras_type,
  output logic [31:0]              ras_addr,
  output logic                     ras_addr_v,
  output logic [31:0]              ras_info,
  output logic                     ras_corr,
  output logic                     irq
);
  `include "sftc_consts.svh"
  `include "sfta_consts.svh"

  // ================================================================== event matrix
  // ev[c*NC + j]
  logic [NEV-1:0] ev;
  always_comb begin
    ev = '0;
    for (int g = 0; g < NG; g++) begin
      ev[TA_EC_MBIST_FAIL  * NC + g] = e_fail[g];
      ev[TA_EC_MBIST_ERROR * NC + g] = e_err[g];
      ev[TA_EC_SEQ_TIMEOUT * NC + g] = e_tmo[g];
      ev[TA_EC_OWNER_FAULT * NC + g] = e_ofault[g];
      ev[TA_EC_INTRUSION   * NC + g] = e_intr[g];
      ev[TA_EC_REINIT      * NC + g] = e_reinit[g];
      ev[TA_EC_REFUSED     * NC + g] = e_refused[g];
    end
    ev[TA_EC_SEC_VIOL  * NC + NG] = e_viol;
    ev[TA_EC_LC_INCONS * NC + NG] = e_lc_incons;
    ev[TA_EC_REFUSED   * NC + NG] = e_seq_refused;
  end
  // RAS-mapped events only (RAS_LOST and BUS_ERR are local)
  localparam logic [NEV-1:0] RAS_MASK = {{(2*NC){1'b0}}, {(9*NC){1'b1}}};

  // ================================================================== registers
  logic [31:0] r_scratch, r_wdog, r_cnt_sent, r_viol_info, r_viol_cnt, r_first, r_first_addr;
  logic [15:0] r_lost;
  logic [2:0]  r_mode_req, r_irq, r_irq_en;
  logic        r_par, r_sof, r_esof, r_bg, r_scrub;
  logic [3:0]  r_algo;
  logic [NG-1:0] r_groups;
  logic [TA_NUM_EC-1:0] r_err, r_err_irq_en;
  logic [3:0]  r_sev;
  logic [16*TA_NUM_EC-1:0] r_cnt;
  logic [NEV-1:0] pend;
  logic [NG*3-1:0] tmo_phase_q;

  // ---------------------------------------------------------------- read mux
  logic        mapped, ro;
  logic [31:0] rv;
  logic [1:0]  sev_max;
  always_comb begin
    sev_max = r_sev[3] ? 2'd3 : r_sev[2] ? 2'd2 : r_sev[1] ? 2'd1 : 2'd0;
  end

  always_comb begin
    mapped = 1'b1; ro = 1'b1; rv = 32'd0;
    case (off)
      TA_R_ID:            rv = TA_ID_VALUE;
      TA_R_REVISION:      rv = TA_REVISION;
      TA_R_CAPS:          rv = {8'd0, 8'(SCAN_CHAINS), 2'b00, 1'b1, 1'b1, 8'(NBT), 4'(NG)};
      TA_R_IDCODE:        rv = IDCODE_VALUE;
      TA_R_SCRATCH:       begin rv = r_scratch; ro = 1'b0; end
      TA_R_LC_STATUS:     rv = {10'd0, perm, 7'd0, lc_incons, otp_ift_en, sb_test_mode_en, sb_debug_en,
                                lc_valid, lc_state};
      TA_R_MODE_CTRL:     begin rv = {29'd0, r_mode_req}; ro = 1'b0; end
      TA_R_MODE_STATUS:   rv = {perm[1], 15'd0, scan_en, scan_mode, mbist_enable, diag_mode, jtag_mode,
                                mode_pend, scan_pin_raw, scan_pin_gated, unlocked, perm[2], mode_busy, mode};
      TA_R_UNLOCK:        begin rv = 32'd0; ro = 1'b0; end
      TA_R_SEQ_CTRL:      begin rv = {20'd0, r_algo, r_scrub, r_bg, r_esof, r_sof, r_par, 3'd0}; ro = 1'b0; end
      TA_R_SEQ_GROUPS:    begin rv = 32'(r_groups); ro = 1'b0; end
      TA_R_SEQ_STATUS:    rv = {9'd0, 7'(sq_fin), 5'd0, sq_cur_phase, sq_cur_group, sq_err, sq_fail, sq_pass,
                                sq_done, sq_busy};
      TA_R_SEQ_RESULT:    rv = 32'(sq_result);
      TA_R_WDOG_LIMIT:    begin rv = r_wdog; ro = 1'b0; end
      TA_R_SEQ_CYCLES:    rv = sq_cycles;
      TA_R_GRP_STATUS:    for (int g = 0; g < NG; g++) rv[g*4 +: 4] = {g_fail[g], g_pass[g], g_done[g], g_busy[g]};
      TA_R_ERR_STATUS:    begin rv = 32'(r_err); ro = 1'b0; end
      TA_R_ERR_IRQ_EN:    begin rv = 32'(r_err_irq_en); ro = 1'b0; end
      TA_R_ERR_FIRST:     begin rv = r_first; ro = 1'b0; end          // write: clear
      TA_R_ERR_FIRST_ADDR:rv = r_first_addr;
      TA_R_SEV_STATUS:    begin rv = {26'd0, sev_max, r_sev}; ro = 1'b0; end
      TA_R_VIOL_INFO:     rv = r_viol_info;
      TA_R_VIOL_COUNT:    rv = r_viol_cnt;
      TA_R_SCAN_STATUS:   rv = {15'd0, 1'b0, 8'(SCAN_CHAINS), 3'd0, scan_pin_raw && !perm[3], perm[3],
                                scan_pin_raw, scan_en, scan_mode};
      TA_R_CLKRST_STATUS: rv = {19'd0, cpu_halted, dft_mem_inhibit, dft_test_rst_n, dft_scan_en, dft_test_mode,
                                8'(clk_req)};
      TA_R_RAS_STATUS:    rv = {r_lost, r_cnt_sent[15:0]};
      TA_R_IRQ_STATUS:    begin rv = {29'd0, r_irq}; ro = 1'b0; end
      TA_R_IRQ_EN:        begin rv = {29'd0, r_irq_en}; ro = 1'b0; end
      default: begin
        mapped = 1'b0;
        for (int c = 0; c < TA_NUM_EC; c++)
          if (off == TA_R_ERR_CNT0 + 9'(4 * c)) begin mapped = 1'b1; rv = {16'd0, r_cnt[c*16 +: 16]}; end
        for (int g = 0; g < NG; g++) begin
          if (off == TA_R_GRP_INFO0 + 9'(8 * g)) begin mapped = 1'b1; rv = GRP_INFO[g*32 +: 32]; end
          if (off == TA_R_GRP_LIVE0 + 9'(8 * g)) begin mapped = 1'b1; rv = g_live[g*32 +: 32]; end
        end
      end
    endcase
  end

  assign gnt   = req;
  assign rdata = (req && !we) ? rv : 32'd0;
  assign err   = req && (!mapped || (we && ro));
  wire w_ok    = req && we && mapped && !ro;

  // ---------------------------------------------------------------- event bookkeeping
  logic [NEV-1:0] ev_all;
  always_comb begin
    ev_all = ev;
    ev_all[TA_EC_BUS_ERR * NC + NG] = err || e_bus_err;     // local only
  end

  // first event of this cycle (lowest index) and RAS drain candidate (lowest pending)
  logic           f_hit, d_hit;
  logic [3:0]     f_cls, d_cls;
  logic [7:0]     f_col, d_col;
  logic [NEV-1:0] d_sel;
  always_comb begin
    f_hit = 1'b0; f_cls = '0; f_col = '0;
    d_hit = 1'b0; d_cls = '0; d_col = '0; d_sel = '0;
    for (int i = 0; i < NEV; i++) begin
      if (!f_hit && ev_all[i]) begin f_hit = 1'b1; f_cls = 4'(i / NC); f_col = 8'(i % NC); end
      if (!d_hit && pend[i] && RAS_MASK[i]) begin
        d_hit = 1'b1; d_sel[i] = 1'b1; d_cls = 4'(i / NC); d_col = 8'(i % NC);
      end
    end
  end
  wire [NEV-1:0] lost_hit = ev & pend & ~d_sel & RAS_MASK;
  wire           lost_any = |lost_hit;

  // per-class hits / counts and severities of this cycle
  logic [TA_NUM_EC-1:0] cls_hit;
  logic [4*TA_NUM_EC-1:0] cls_n;
  logic [3:0]           sev_set;
  always_comb begin
    cls_hit = '0; cls_n = '0; sev_set = '0;
    for (int c = 0; c < TA_NUM_EC; c++) begin
      for (int j = 0; j < NC; j++) begin
        if (ev_all[c*NC + j]) begin
          cls_hit[c] = 1'b1;
          cls_n[c*4 +: 4] = cls_n[c*4 +: 4] + 4'd1;
          sev_set[ta_sev(c)] = 1'b1;
        end
      end
    end
    if (lost_any) begin
      cls_hit[TA_EC_RAS_LOST] = 1'b1; cls_n[TA_EC_RAS_LOST*4 +: 4] = 4'd1; sev_set[0] = 1'b1;
    end
  end

  // event details: column j -> group information
  logic [7:0]  f_bank, f_aux, d_bank, d_aux;
  logic [31:0] f_addr, d_addr;
  logic        f_addr_v, d_addr_v;
  logic [3:0]  d_type;
  logic [1:0]  f_sev;
  always_comb begin
    f_bank = '0; f_aux = '0; f_addr = '0; f_addr_v = 1'b0;
    d_bank = '0; d_aux = '0; d_addr = '0; d_addr_v = 1'b0;
    d_type = '0; f_sev = '0;
    for (int c = 0; c < TA_NUM_EC; c++) begin
      if (f_cls == 4'(c)) f_sev  = ta_sev(c);
      if (d_cls == 4'(c)) d_type = ta_ras_type(c);
    end
    for (int g = 0; g < NG; g++) begin
      if (f_col == 8'(g)) begin
        if (f_cls == 4'(TA_EC_MBIST_FAIL)) begin
          f_bank = g_ff_info[g*24 +: 8]; f_aux = g_ff_info[g*24 + 8 +: 8];
          f_addr = 32'(g_ff_addr[g*AWMAX +: AWMAX]); f_addr_v = 1'b1;
        end
        if (f_cls == 4'(TA_EC_MBIST_ERROR)) f_aux = {5'd0, g_last[g*3 +: 3]};
        if (f_cls == 4'(TA_EC_SEQ_TIMEOUT)) f_aux = {5'd0, e_tmo_phase[g*3 +: 3]};
      end
      if (d_col == 8'(g)) begin
        if (d_cls == 4'(TA_EC_MBIST_FAIL)) begin
          d_bank = g_ff_info[g*24 +: 8]; d_aux = g_ff_info[g*24 + 8 +: 8];
          d_addr = 32'(g_ff_addr[g*AWMAX +: AWMAX]); d_addr_v = 1'b1;
        end
        if (d_cls == 4'(TA_EC_MBIST_ERROR)) d_aux = {5'd0, g_last[g*3 +: 3]};
        if (d_cls == 4'(TA_EC_SEQ_TIMEOUT)) d_aux = {5'd0, tmo_phase_q[g*3 +: 3]};
      end
    end
    if (f_col == 8'(NG)) begin
      if (f_cls == 4'(TA_EC_SEC_VIOL))  begin f_aux = {e_viol_src, 4'd0}; f_addr = {20'd0, e_viol_addr}; f_addr_v = 1'b1; end
      if (f_cls == 4'(TA_EC_LC_INCONS)) f_aux = {4'd0, lc_state};
    end
    if (d_col == 8'(NG)) begin
      if (d_cls == 4'(TA_EC_SEC_VIOL))  begin d_aux = {r_viol_info[27:24], 4'd0}; d_addr = {20'd0, r_viol_info[11:0]}; d_addr_v = 1'b1; end
      if (d_cls == 4'(TA_EC_LC_INCONS)) d_aux = {4'd0, lc_state};
    end
  end
  wire [7:0]  f_grp  = (f_col == 8'(NG)) ? 8'hFF : f_col;
  wire [7:0]  d_grp  = (d_col == 8'(NG)) ? 8'hFF : d_col;
  wire [31:0] d_info = {4'd0, d_cls, d_grp, d_bank, d_aux};

  wire [2:0] irq_set = {|(cls_hit & r_err_irq_en), sq_ev_done && sq_fail, sq_ev_done};

  // ---------------------------------------------------------------- sequential
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_scratch <= '0; r_wdog <= '0; r_mode_req <= MODE_NORMAL; unlocked <= 1'b0;
      r_par <= 1'b0; r_sof <= 1'b0; r_esof <= 1'b0; r_bg <= 1'b0; r_scrub <= 1'b0; r_algo <= ALG_MARCH_C_MINUS;
      r_groups <= '0; r_err <= '0; r_err_irq_en <= '0; r_sev <= '0; r_cnt <= '0; pend <= '0;
      r_first <= '0; r_first_addr <= '0; r_viol_info <= '0; r_viol_cnt <= '0; r_cnt_sent <= '0; r_lost <= '0;
      r_irq <= '0; r_irq_en <= '0; tmo_phase_q <= '0;
      mode_req_valid <= 1'b0; seq_start <= 1'b0; seq_abort <= 1'b0; seq_clear <= 1'b0;
      ras_valid <= 1'b0; ras_type <= '0; ras_addr <= '0; ras_addr_v <= 1'b0; ras_info <= '0;
    end else begin
      mode_req_valid <= 1'b0; seq_start <= 1'b0; seq_abort <= 1'b0; seq_clear <= 1'b0;

      for (int g = 0; g < NG; g++) if (e_tmo[g]) tmo_phase_q[g*3 +: 3] <= e_tmo_phase[g*3 +: 3];
      if (e_viol) begin
        r_viol_info <= {1'b1, 3'd0, e_viol_src, 12'd0, e_viol_addr};
        if (r_viol_cnt != 32'hFFFF_FFFF) r_viol_cnt <= r_viol_cnt + 32'd1;
      end

      // ---- error classes, counters, severities, first error
      for (int c = 0; c < TA_NUM_EC; c++) begin
        if (cls_n[c*4 +: 4] != 4'd0)
          r_cnt[c*16 +: 16] <= (17'(r_cnt[c*16 +: 16]) + 17'(cls_n[c*4 +: 4]) > 17'hFFFF) ? 16'hFFFF
                               : r_cnt[c*16 +: 16] + 16'(cls_n[c*4 +: 4]);
      end
      r_err <= ((w_ok && off == TA_R_ERR_STATUS) ? (r_err & ~wdata[TA_NUM_EC-1:0]) : r_err) | cls_hit;
      r_sev <= ((w_ok && off == TA_R_SEV_STATUS) ? (r_sev & ~wdata[3:0]) : r_sev) | sev_set;
      if (w_ok && off == TA_R_ERR_FIRST) begin
        r_first <= '0; r_first_addr <= '0;
      end else if (f_hit && !r_first[31]) begin
        r_first      <= {1'b1, 1'b0, f_sev, f_cls, f_grp, f_bank, f_aux};
        r_first_addr <= f_addr_v ? f_addr : 32'd0;
      end

      // ---- RAS port
      pend <= ((pend & ~d_sel) | ev) & RAS_MASK;
      if (lost_any && r_lost != 16'hFFFF) r_lost <= r_lost + 16'd1;
      ras_valid  <= d_hit;
      ras_type   <= d_hit ? d_type : 4'd0;
      ras_info   <= d_hit ? d_info : 32'd0;
      ras_addr   <= (d_hit && d_addr_v) ? d_addr : 32'd0;
      ras_addr_v <= d_hit && d_addr_v;
      if (d_hit && r_cnt_sent != 32'hFFFF_FFFF) r_cnt_sent <= r_cnt_sent + 32'd1;

      // ---- interrupts
      r_irq <= ((w_ok && off == TA_R_IRQ_STATUS) ? (r_irq & ~wdata[2:0]) : r_irq) | irq_set;

      // ---- writes
      if (w_ok) begin
        case (off)
          TA_R_SCRATCH:    r_scratch <= wdata;
          TA_R_MODE_CTRL:  begin r_mode_req <= wdata[2:0]; mode_req_valid <= 1'b1; end
          TA_R_UNLOCK:     unlocked <= (wdata == TC_UNLOCK_KEY);
          TA_R_SEQ_CTRL: begin
            if (!sq_busy) begin
              r_par <= wdata[TA_SEQ_PARALLEL]; r_sof <= wdata[TA_SEQ_STOP_ON_FAIL];
              r_esof <= wdata[TA_SEQ_ENG_SOF]; r_bg <= wdata[TA_SEQ_BG_CHK]; r_scrub <= wdata[TA_SEQ_SCRUB];
              r_algo <= wdata[11:8];
            end
            seq_start <= wdata[TA_SEQ_START];
            seq_abort <= wdata[TA_SEQ_ABORT];
            seq_clear <= wdata[TA_SEQ_CLEAR];
          end
          TA_R_SEQ_GROUPS: if (!sq_busy) r_groups <= wdata[NG-1:0];
          TA_R_WDOG_LIMIT: r_wdog <= wdata;
          TA_R_ERR_IRQ_EN: r_err_irq_en <= wdata[TA_NUM_EC-1:0];
          TA_R_IRQ_EN:     r_irq_en <= wdata[2:0];
          default: ;
        endcase
      end
    end
  end

  assign mode_req     = r_mode_req;
  assign seq_parallel = r_par;
  assign seq_sof      = r_sof;
  assign seq_eng_sof  = r_esof;
  assign seq_bg       = r_bg;
  assign seq_scrub    = r_scrub;
  assign seq_algo     = r_algo;
  assign seq_groups   = r_groups;
  assign wdog_limit   = r_wdog;
  assign ras_corr     = 1'b0;
  assign irq          = |(r_irq & r_irq_en);
endmodule

`default_nettype wire
