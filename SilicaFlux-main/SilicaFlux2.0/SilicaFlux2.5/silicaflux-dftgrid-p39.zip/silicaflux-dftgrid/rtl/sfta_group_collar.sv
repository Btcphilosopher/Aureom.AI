// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: sfta_group_collar
// MBIST collar of one MEMORY GROUP: a memory with the SRAM-library raw test
// bus (tst_active / tst_sel[b] / tst_ce / tst_we / tst_addr / tst_wdata ->
// tst_rdata[b], fixed read latency LAT), i.e.
//   * Project 33 silicaflux_sram_grid   (TEST_LAT, INIT_AFTER_TEST = 1)
//   * MemoryCore sfmem_banked / SRAM-library sram_bank_controller (RD_LAT)
// Placed next to the memory group; the group's MBIST engine (sfta_group_ctrl)
// reaches it through the TestCore bank bus (optionally pipelined).
//
// Functional isolation.  The memory's tst_active is GROUP-wide (it stops all
// functional issue of the group), so the group -- not the bank -- is the unit
// of ownership: ONE unmodified TestCore sftc_mem_owner per group:
//   NORMAL -> QUIESCE_REQUEST (quiesce_req to the group's masters)
//          -> WAIT_FOR_IDLE   (quiesce_ack; f_block gates every request; wait
//                              until the memory is idle: f_busy = 0)
//          -> TEST_ACQUIRE -> TEST_ACTIVE (engine requests granted)
//          -> TEST_COMPLETE  (engine idle; drain test reads; re-initialise)
//          -> TEST_RELEASE -> NORMAL
// A functional request presented from WAIT_FOR_IDLE to TEST_RELEASE is
// blocked and reported (ev_intrusion).  Owner timeouts -> FAULT (ev_fault).
//
// Re-initialisation (the memory content is destroyed by the test):
//   INIT_MODE = TA_INIT_COLLAR : in TEST_COMPLETE (and on entry to FAULT with
//     a dirty bank) the collar writes INIT_WORD to every row of every bank
//     (all banks in parallel, one row per cycle, exactly DEPTH cycles) before
//     releasing.  INIT_WORD is a VALID stored word (e.g. zero data with
//     correct parity), so functional reads after release never see a parity
//     or ECC error.  With INIT_ON_RESET the same sweep runs after reset
//     (this replaces the Project 31 memory_subsystem initialisation sweep,
//     which used the same test port).
//   INIT_MODE = TA_INIT_SELF   : the memory re-initialises itself when
//     tst_active falls (P33 INIT_AFTER_TEST = 1) and blocks functional issue
//     meanwhile (init_busy); `released` waits for mem_init_busy = 0.
// Either way the owner's DIRTY flag is cleared by hardware, so a normal
// release never raises REINIT_REQUIRED.
//
// Raw-bus mapping (TestCore handshake -> fixed-latency raw port, as P07
// sftc_tst_port_adapter):  b_gnt = test_en (one operation per cycle),
// writes posted, each read returns b_rvalid exactly LAT cycles later with
// tst_rdata sampled then.  The raw bus is driven only while the group is in
// TEST_ACTIVE or the collar is sweeping -- never in functional ownership.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sfta_group_collar #(
  parameter int NB          = 4,                 // banks in the group
  parameter int SW          = 72,                // raw stored word (test-bus) width
  parameter int DEPTH       = 1024,              // rows (of the deepest bank)
  parameter int LAT         = 1,                 // raw test read latency, >= 1
  parameter int INIT_MODE   = 1,                 // 1 = TA_INIT_COLLAR, 2 = TA_INIT_SELF
  parameter logic [SW-1:0] INIT_WORD = '0,       // valid stored word written by the collar sweep
  parameter int INIT_ON_RESET = 0,               // collar sweep after reset (INIT_MODE 1 only)
  parameter int OWN_TIMEOUT = 4096,              // > DEPTH + LAT (collar sweep inside TEST_COMPLETE)
  parameter int MAX_W       = SW,                // engine data width (>= SW)
  localparam int RAW        = (DEPTH > 2) ? $clog2(DEPTH) : 1
) (
  input  wire logic                clk,
  /* verilator lint_off SYNCASYNCNET */
  input  wire logic                rst_n,          // also sampled by the simulation-only assertion blocks
  /* verilator lint_on SYNCASYNCNET */
  // ---- TestCore bank bus (from the group's sftc_mbist_bank_mux)
  input  wire logic [NB-1:0]       b_req,
  input  wire logic                b_we,
  input  wire logic [RAW-1:0]      b_addr,
  input  wire logic [MAX_W-1:0]    b_wdata,
  output logic      [NB-1:0]       b_gnt,
  output logic      [NB-1:0]       b_rvalid,
  output logic      [NB*MAX_W-1:0] b_rdata,
  output logic      [NB-1:0]       b_rerr,
  // ---- ownership coupling (group controller)
  input  wire logic [NB-1:0]       acq_req,
  input  wire logic                fault_clear,
  input  wire logic                mbist_busy,
  output logic      [NB*3-1:0]     owner_state,
  output logic      [NB-1:0]       owned,
  output logic      [NB-1:0]       owner_dirty,
  output logic                     ev_fault,
  output logic                     ev_intrusion,
  output logic                     ev_reinit,
  // ---- functional side of the group
  output logic                     quiesce_req,
  input  wire logic                quiesce_ack,
  input  wire logic                f_busy,          // memory has accepted work / responses in flight
  input  wire logic                f_req,           // a functional request is presented (raw, before f_block)
  output logic                     f_block,         // integration gates every functional request with this
  input  wire logic                mem_init_busy,   // INIT_SELF: memory's own init sweep running
  output logic                     mem_ready,       // reset initialisation complete
  // ---- memory raw test bus
  output logic                     tst_active,
  output logic      [NB-1:0]       tst_sel,
  output logic                     tst_ce,
  output logic                     tst_we,
  output logic      [RAW-1:0]      tst_addr,
  output logic      [SW-1:0]       tst_wdata,
  input  wire logic [NB*SW-1:0]    tst_rdata,
  // ---- status
  output logic [2:0]               grp_state,
  output logic                     grp_dirty,
  output logic                     sweeping,
  output logic                     released,        // owner NORMAL/FAULT and no initialisation running
  output logic                     clk_req          // keep the group's clock branch running
);
  `include "sftc_consts.svh"
  `include "sfta_consts.svh"

  // ------------------------------------------------------------------ elaboration checks
  if (NB < 1 || NB > 32)               begin : g_err_nb    $error("sfta_group_collar: NB must be 1..32"); end
  if (LAT < 1 || LAT > 8)              begin : g_err_lat   $error("sfta_group_collar: LAT must be 1..8"); end
  if (MAX_W < SW)                      begin : g_err_w     $error("sfta_group_collar: MAX_W < SW"); end
  if (INIT_MODE != TA_INIT_COLLAR && INIT_MODE != TA_INIT_SELF)
                                       begin : g_err_mode  $error("sfta_group_collar: INIT_MODE must be 1 (collar) or 2 (self)"); end
  if (INIT_ON_RESET != 0 && INIT_MODE != TA_INIT_COLLAR)
                                       begin : g_err_ror   $error("sfta_group_collar: INIT_ON_RESET needs INIT_MODE = 1"); end
  if (OWN_TIMEOUT <= DEPTH + LAT + 4)  begin : g_err_tmo   $error("sfta_group_collar: OWN_TIMEOUT must exceed DEPTH + LAT + 4"); end

  localparam bit COLLAR = (INIT_MODE == TA_INIT_COLLAR);

  // ------------------------------------------------------------------ state
  logic           sw_act, sw_post;            // sweep running / it is a post-test (not reset) sweep
  logic [RAW-1:0] sw_row;
  logic [LAT-1:0] rp_v;                       // read pipeline: valid
  logic [LAT*NB-1:0] rp_b;                    // read pipeline: one-hot bank
  logic [2:0]     own_st, own_st_q;
  logic           sel_test, test_en, own_owned, own_dirty, own_fblock;
  logic           scrub_pulse;

  wire rd_busy  = |rp_v;
  wire eng_acc  = test_en && (|b_req);
  wire eng_rd   = eng_acc && !b_we;
  wire t_wr     = eng_acc && b_we;
  wire rst_sweep = sw_act && !sw_post;

  // a sweep restores valid content of a dirty group, once the test port is
  // quiet: after the engine finished (TEST_COMPLETE) or after an owner FAULT
  wire post_req = COLLAR && own_dirty && !sw_act && !rd_busy &&
                  (own_st == OWN_TEST_COMPLETE || own_st == OWN_FAULT);

  // ------------------------------------------------------------------ ownership (TestCore P07, unmodified)
  wire own_acq    = (|acq_req) && !rst_sweep;
  wire own_tbusy  = rd_busy || sw_act || post_req;
  logic own_qreq, own_ev_fault, own_ev_intr, own_ev_reinit;
  sftc_mem_owner #(.TIMEOUT(OWN_TIMEOUT)) u_owner (
    .clk, .rst_n, .acq_req(own_acq), .fault_clear, .quiesce_ack, .f_busy, .f_req, .mbist_busy,
    .t_busy(own_tbusy), .t_wr, .scrub_done(scrub_pulse), .quiesce_req(own_qreq), .f_block(own_fblock),
    .sel_test, .test_en, .owned(own_owned), .state(own_st), .dirty(own_dirty),
    .ev_fault(own_ev_fault), .ev_intrusion(own_ev_intr), .ev_reinit_req(own_ev_reinit)
  );

  // ------------------------------------------------------------------ sweeps
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sw_act   <= COLLAR && (INIT_ON_RESET != 0);
      sw_post  <= 1'b0;
      sw_row   <= '0;
      own_st_q <= OWN_NORMAL;
    end else begin
      own_st_q <= own_st;
      if (sw_act) begin
        if (sw_row == RAW'(DEPTH - 1)) begin
          sw_act <= 1'b0; sw_post <= 1'b0;
        end
        sw_row <= sw_row + 1'b1;
      end else if (post_req) begin
        sw_act <= 1'b1; sw_post <= 1'b1; sw_row <= '0;
      end
    end
  end
  wire sw_last = sw_act && (sw_row == RAW'(DEPTH - 1));
  // DIRTY is cleared by hardware: collar mode at the last row of a post-test
  // sweep; self mode on entry to TEST_COMPLETE (the memory re-initialises
  // when tst_active falls, before any functional access is issued).
  assign scrub_pulse = COLLAR ? (sw_last && sw_post)
                              : (own_st == OWN_TEST_COMPLETE && own_st_q != OWN_TEST_COMPLETE);

  // ------------------------------------------------------------------ read pipeline
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rp_v <= '0; rp_b <= '0;
    end else if (LAT == 1) begin
      rp_v <= LAT'(eng_rd);
      rp_b <= (LAT*NB)'(b_req);
    end else begin
      rp_v <= LAT'({rp_v, eng_rd});
      rp_b <= (LAT*NB)'({rp_b, b_req});
    end
  end
  wire [NB-1:0] rp_out = rp_b[(LAT-1)*NB +: NB];
  always_comb begin
    for (int k = 0; k < NB; k++) begin
      b_rvalid[k]               = rp_v[LAT-1] && rp_out[k];
      b_rdata[k*MAX_W +: MAX_W] = MAX_W'(tst_rdata[k*SW +: SW]);
    end
  end
  assign b_gnt  = {NB{test_en}};
  assign b_rerr = '0;

  // ------------------------------------------------------------------ raw test bus
  assign tst_active = sel_test || sw_act;
  assign tst_ce     = sw_act || eng_acc;
  assign tst_sel    = sw_act ? {NB{1'b1}} : (test_en ? b_req : '0);
  assign tst_we     = sw_act ? 1'b1 : b_we;
  assign tst_addr   = sw_act ? sw_row : b_addr;
  assign tst_wdata  = sw_act ? INIT_WORD : b_wdata[SW-1:0];

  // ------------------------------------------------------------------ outputs
  assign quiesce_req = own_qreq;
  assign f_block     = own_fblock;
  assign mem_ready   = !rst_sweep;
  for (genvar k = 0; k < NB; k++) begin : g_rep
    assign owner_state[k*3 +: 3] = own_st;
    assign owned[k]              = own_owned;
    assign owner_dirty[k]        = own_dirty;
  end
  assign ev_fault     = own_ev_fault;
  assign ev_intrusion = own_ev_intr;
  assign ev_reinit    = own_ev_reinit;
  assign grp_state    = own_st;
  assign grp_dirty    = own_dirty;
  assign sweeping     = sw_act;
  assign released     = (own_st == OWN_NORMAL || own_st == OWN_FAULT) && !sw_act && !post_req &&
                        !(!COLLAR && mem_init_busy);
  assign clk_req      = (own_st != OWN_NORMAL && own_st != OWN_FAULT) || sw_act || post_req;

`ifdef SFTC_CHECKS
  always @(posedge clk) begin
    if (rst_n) begin
      `SFTC_ASSERT(!(sw_act && eng_acc), "collar sweep and engine access in the same cycle")
      `SFTC_ASSERT(!tst_ce || tst_active, "raw test access outside test ownership")
      `SFTC_ASSERT(!eng_acc || (own_st == OWN_TEST_ACTIVE), "engine access outside TEST_ACTIVE")
      `SFTC_ASSERT(!(sel_test && !f_block), "test owns the group while its functional path is open")
      `SFTC_ASSERT($onehot0(b_req), "more than one bank requested at once")
    end
  end
`endif
endmodule

`default_nettype wire
