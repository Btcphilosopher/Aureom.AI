// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: sfta_seq
// Global MBIST sequencer: runs a complete memory test of the selected groups
// (every bank of each group) with one command, for wafer probe / boot POST.
//
// Per group g a phase machine:
//   IDLE --turn--> ACQ (all banks requested; wait until the collar owns them)
//        --> START (one-cycle engine START) --> RUN (wait engine busy, then idle)
//        --> REL (request withdrawn; wait until released: drained, re-initialised)
//        --> FIN (result recorded)
//   RUN --abort / watchdog / mode exit--> STOP (engine ABORT; wait engine idle) --> REL
// Order: SEQUENTIAL (PARALLEL = 0): one group at a time in ascending group
//   index (bounded test power, one group's masters quiesced at a time);
//   PARALLEL = 1: every selected group at once (shortest test time).
//   Inside a group the TestCore engine tests the banks in ascending index.
// Results per group (TA_RES_*): PASS / FAIL / ABORTED / ERROR (engine
//   inconclusive) / TIMEOUT (watchdog) / REFUSED (cannot acquire: PROTECT,
//   not in MBIST mode, engine refused START) / OWNER_FAULT / NOT_RUN.
// Watchdog: WDOG_LIMIT cycles per phase (ACQ, RUN, STOP, REL); 0 = off.
// STOP_ON_FAIL: groups not yet started are left NOT_RUN after the first
//   group that did not PASS.
// ABORT: running groups are stopped and released (ABORTED); waiting groups
//   stay NOT_RUN.  START while running, or with no group / not in MBIST mode,
//   is refused (event).  CLEAR (when idle) clears results and every group's
//   engine / owner FAULT.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sfta_seq #(
  parameter int NG = 2,
  localparam int GW = 3
) (
  input  wire logic             clk,
  /* verilator lint_off SYNCASYNCNET */
  input  wire logic             rst_n,          // also sampled by the simulation-only assertion blocks
  /* verilator lint_on SYNCASYNCNET */
  // ---- control (pulses from SEQ_CTRL) and configuration
  input  wire logic             start,
  input  wire logic             abort,
  input  wire logic             clear,
  input  wire logic             parallel,
  input  wire logic             stop_on_fail,
  input  wire logic [NG-1:0]    groups,
  input  wire logic [31:0]      wdog_limit,
  input  wire logic             mbist_enable,
  input  wire logic             mode_exit,       // MBIST-mode exit sequence in progress
  // ---- per-group status
  input  wire logic [NG-1:0]    g_busy,          // engine busy
  input  wire logic [NG*3-1:0]  g_last,          // engine LAST_TEST_RESULT (TestCore RES_*)
  input  wire logic [NG-1:0]    g_owned_all,
  input  wire logic [NG-1:0]    g_acq_blocked,
  input  wire logic [NG-1:0]    g_released,
  input  wire logic [NG-1:0]    g_owner_fault,   // owner in FAULT (level)
  input  wire logic [NG-1:0]    g_refused,       // engine START refused (pulse)
  // ---- group control
  output logic [NG-1:0]         seq_sel,
  output logic [NG-1:0]         seq_acq,
  output logic [NG-1:0]         seq_start,
  output logic [NG-1:0]         seq_abort,
  output logic [NG-1:0]         seq_clear,
  // ---- status
  output logic                  busy,
  output logic                  done,
  output logic                  pass,
  output logic                  fail,
  output logic                  err,
  output logic [GW-1:0]         cur_group,
  output logic [2:0]            cur_phase,
  output logic [NG*4-1:0]       result,
  output logic [NG-1:0]         fin_mask,
  output logic [31:0]           cycles,
  // ---- events (pulses)
  output logic [NG-1:0]         ev_timeout,
  output logic [NG*3-1:0]       ev_timeout_phase,
  output logic [NG-1:0]         ev_refused,
  output logic                  ev_seq_refused,  // START refused at sequence level (busy / no group)
  output logic                  ev_seq_done
);
  `include "sftc_consts.svh"
  `include "sfta_consts.svh"

  if (NG < 1 || NG > TA_MAX_GROUPS) begin : g_err_ng $error("sfta_seq: NG must be 1..7"); end

  logic          running, abort_l, stop_l, par_l;
  logic [31:0]   wd_q;      // watchdog limit latched at START (configuration of the running sequence)
  logic [NG-1:0] sel, started, tmo_v;
  logic [NG*3-1:0]  gs;     // phase per group
  logic [NG*4-1:0]  res;    // result per group
  logic [NG*32-1:0] tmr;    // phase timer per group

  wire wd_on = (wd_q != 32'd0);
  always_comb begin
    for (int g = 0; g < NG; g++) tmo_v[g] = wd_on && (tmr[g*32 +: 32] >= wd_q);
  end

  // token: the lowest selected group that has not finished
  logic [NG-1:0] first_open;
  logic          fo_found;
  always_comb begin
    fo_found = 1'b0; first_open = '0;
    for (int g = 0; g < NG; g++)
      if (!fo_found && sel[g] && gs[g*3 +: 3] != TA_GS_FIN) begin first_open[g] = 1'b1; fo_found = 1'b1; end
  end

  function automatic logic [3:0] map_res(input logic [2:0] r);
    case (r)
      RES_PASS:    map_res = TA_RES_PASS;
      RES_FAIL:    map_res = TA_RES_FAIL;
      RES_ABORTED: map_res = TA_RES_ABORTED;
      default:     map_res = TA_RES_ERROR;      // ERROR / NOT_RUN / RUNNING at the end of RUN: inconclusive
    endcase
  endfunction

  logic all_fin;
  always_comb begin
    all_fin = 1'b1;
    for (int g = 0; g < NG; g++) if (sel[g] && gs[g*3 +: 3] != TA_GS_FIN) all_fin = 1'b0;
  end

  wire stop_any = abort_l || abort;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      running <= 1'b0; abort_l <= 1'b0; stop_l <= 1'b0; par_l <= 1'b0; sel <= '0; wd_q <= '0;
      done <= 1'b0; cycles <= '0; started <= '0;
      seq_start <= '0; seq_abort <= '0; seq_clear <= '0;
      ev_timeout <= '0; ev_timeout_phase <= '0; ev_refused <= '0; ev_seq_refused <= 1'b0; ev_seq_done <= 1'b0;
      gs <= '0; res <= '0; tmr <= '0;
    end else begin
      seq_start <= '0; seq_abort <= '0; seq_clear <= '0;
      ev_timeout <= '0; ev_refused <= '0; ev_seq_refused <= 1'b0; ev_seq_done <= 1'b0;

      if (!running) begin
        // ------------------------------------------------ idle: START / CLEAR
        if (start) begin
          if (groups == '0) begin
            ev_seq_refused <= 1'b1;
          end else if (!mbist_enable || mode_exit) begin
            ev_seq_refused <= 1'b1;
            done <= 1'b1; sel <= groups; ev_refused <= groups;
            for (int g = 0; g < NG; g++) begin
              res[g*4 +: 4] <= groups[g] ? TA_RES_REFUSED : TA_RES_NOT_RUN;
              gs[g*3 +: 3]  <= groups[g] ? TA_GS_FIN : TA_GS_IDLE;
            end
          end else begin
            running <= 1'b1; done <= 1'b0; abort_l <= 1'b0; stop_l <= 1'b0; par_l <= parallel; wd_q <= wdog_limit;
            sel <= groups; cycles <= '0; started <= '0; tmr <= '0;
            for (int g = 0; g < NG; g++) begin
              gs[g*3 +: 3]  <= TA_GS_IDLE;
              res[g*4 +: 4] <= groups[g] ? TA_RES_RUNNING : TA_RES_NOT_RUN;
            end
          end
        end else if (clear) begin
          done <= 1'b0; cycles <= '0; sel <= '0; gs <= '0; res <= '0;
          seq_clear <= {NG{1'b1}};
        end
      end else begin
        // ------------------------------------------------ running
        if (cycles != 32'hFFFF_FFFF) cycles <= cycles + 32'd1;
        if (abort) abort_l <= 1'b1;
        if (start) ev_seq_refused <= 1'b1;                 // START while running: refused

        for (int g = 0; g < NG; g++) begin
          if (sel[g]) begin
            if (tmr[g*32 +: 32] != 32'hFFFF_FFFF) tmr[g*32 +: 32] <= tmr[g*32 +: 32] + 32'd1;
            case (gs[g*3 +: 3])
              TA_GS_IDLE: begin
                tmr[g*32 +: 32] <= '0;
                if (stop_any || stop_l) begin
                  gs[g*3 +: 3] <= TA_GS_FIN; res[g*4 +: 4] <= TA_RES_NOT_RUN;
                end else if (par_l || first_open[g]) begin
                  gs[g*3 +: 3] <= TA_GS_ACQ;
                end
              end
              TA_GS_ACQ: begin
                if (stop_any || mode_exit) begin
                  gs[g*3 +: 3] <= TA_GS_REL; res[g*4 +: 4] <= TA_RES_ABORTED; tmr[g*32 +: 32] <= '0;
                end else if (!mbist_enable || g_acq_blocked[g]) begin
                  gs[g*3 +: 3] <= TA_GS_REL; res[g*4 +: 4] <= TA_RES_REFUSED; tmr[g*32 +: 32] <= '0;
                  ev_refused[g] <= 1'b1;
                end else if (g_owner_fault[g]) begin
                  gs[g*3 +: 3] <= TA_GS_REL; res[g*4 +: 4] <= TA_RES_OWNER_FAULT; tmr[g*32 +: 32] <= '0;
                end else if (tmo_v[g]) begin
                  gs[g*3 +: 3] <= TA_GS_REL; res[g*4 +: 4] <= TA_RES_TIMEOUT; tmr[g*32 +: 32] <= '0;
                  ev_timeout[g] <= 1'b1; ev_timeout_phase[g*3 +: 3] <= TA_GS_ACQ;
                end else if (g_owned_all[g]) begin
                  gs[g*3 +: 3] <= TA_GS_START; tmr[g*32 +: 32] <= '0;
                end
              end
              TA_GS_START: begin
                seq_start[g] <= 1'b1; started[g] <= 1'b0;
                gs[g*3 +: 3] <= TA_GS_RUN; tmr[g*32 +: 32] <= '0;
              end
              TA_GS_RUN: begin
                if (g_busy[g]) started[g] <= 1'b1;
                if (g_refused[g]) begin           // the engine's own refusal event is reported by the group
                  gs[g*3 +: 3] <= TA_GS_REL; res[g*4 +: 4] <= TA_RES_REFUSED; tmr[g*32 +: 32] <= '0;
                end else if (started[g] && !g_busy[g]) begin
                  gs[g*3 +: 3] <= TA_GS_REL; res[g*4 +: 4] <= map_res(g_last[g*3 +: 3]); tmr[g*32 +: 32] <= '0;
                end else if (stop_any || mode_exit || !mbist_enable) begin
                  gs[g*3 +: 3] <= TA_GS_STOP; res[g*4 +: 4] <= TA_RES_ABORTED; seq_abort[g] <= 1'b1;
                  tmr[g*32 +: 32] <= '0;
                end else if (tmo_v[g]) begin
                  gs[g*3 +: 3] <= TA_GS_STOP; res[g*4 +: 4] <= TA_RES_TIMEOUT; seq_abort[g] <= 1'b1;
                  tmr[g*32 +: 32] <= '0;
                  ev_timeout[g] <= 1'b1; ev_timeout_phase[g*3 +: 3] <= TA_GS_RUN;
                end
              end
              TA_GS_STOP: begin
                // the engine honours ABORT at its next transaction boundary (its own
                // request / response timeout bounds this); ownership is kept until idle
                if (!g_busy[g]) begin
                  gs[g*3 +: 3] <= TA_GS_REL; tmr[g*32 +: 32] <= '0;
                end else if (tmo_v[g]) begin
                  gs[g*3 +: 3] <= TA_GS_REL; tmr[g*32 +: 32] <= '0;
                  ev_timeout[g] <= 1'b1; ev_timeout_phase[g*3 +: 3] <= TA_GS_STOP;
                end
              end
              TA_GS_REL: begin
                if (g_released[g]) begin
                  gs[g*3 +: 3] <= TA_GS_FIN;
                  if (g_owner_fault[g]) res[g*4 +: 4] <= TA_RES_OWNER_FAULT;
                  if (stop_on_fail && !(res[g*4 +: 4] == TA_RES_PASS && !g_owner_fault[g])) stop_l <= 1'b1;
                end else if (tmo_v[g]) begin
                  gs[g*3 +: 3] <= TA_GS_FIN; res[g*4 +: 4] <= TA_RES_TIMEOUT;
                  ev_timeout[g] <= 1'b1; ev_timeout_phase[g*3 +: 3] <= TA_GS_REL;
                  if (stop_on_fail) stop_l <= 1'b1;
                end
              end
              default: ;   // FIN: hold
            endcase
          end
        end

        if (all_fin) begin
          running <= 1'b0; done <= 1'b1; ev_seq_done <= 1'b1;
        end
      end
    end
  end

  // ------------------------------------------------------------------ outputs
  logic cg_found;
  always_comb begin
    pass = done; fail = 1'b0; err = 1'b0; cg_found = 1'b0; cur_group = '0; cur_phase = TA_GS_IDLE;
    for (int g = 0; g < NG; g++) begin
      result[g*4 +: 4] = res[g*4 +: 4];
      fin_mask[g]      = sel[g] && (gs[g*3 +: 3] == TA_GS_FIN);
      seq_sel[g]       = running && sel[g] && (gs[g*3 +: 3] != TA_GS_FIN);
      seq_acq[g]       = (gs[g*3 +: 3] == TA_GS_ACQ) || (gs[g*3 +: 3] == TA_GS_START) ||
                         (gs[g*3 +: 3] == TA_GS_RUN) || (gs[g*3 +: 3] == TA_GS_STOP);
      if (sel[g] && res[g*4 +: 4] != TA_RES_PASS) pass = 1'b0;
      if (sel[g] && res[g*4 +: 4] == TA_RES_FAIL) fail = 1'b1;
      if (sel[g] && res[g*4 +: 4] != TA_RES_PASS && res[g*4 +: 4] != TA_RES_FAIL &&
          res[g*4 +: 4] != TA_RES_RUNNING) err = 1'b1;
      if (!cg_found && running && sel[g] && gs[g*3 +: 3] != TA_GS_IDLE && gs[g*3 +: 3] != TA_GS_FIN) begin
        cg_found = 1'b1; cur_group = GW'(g); cur_phase = gs[g*3 +: 3];
      end
    end
    if (sel == '0) pass = 1'b0;
    fail = fail && done;
    err  = err && done;
  end
  assign busy = running;

`ifdef SFTC_CHECKS
  always @(posedge clk) begin
    if (rst_n) begin
      if (!par_l && running) begin
        `SFTC_ASSERT($onehot0(seq_acq), "sequential mode: more than one group acquired")
      end
      `SFTC_ASSERT(!(|seq_acq) || running, "group acquired outside a sequence")
      `SFTC_ASSERT(!(done && running), "done while running")
      for (int g = 0; g < NG; g++) begin
        `SFTC_ASSERT(!seq_acq[g] || seq_sel[g], "acquisition of a group the sequencer does not own")
        `SFTC_ASSERT(!seq_start[g] || seq_acq[g], "START of a group that is not acquired")
        `SFTC_ASSERT(!(pass && sel[g]) || res[g*4 +: 4] == TA_RES_PASS, "sequence PASS with a group not PASS")
        // the watchdog bounds every timed phase (ACQ, RUN, STOP, REL)
        if (running && wd_on && (gs[g*3 +: 3] == TA_GS_ACQ || gs[g*3 +: 3] == TA_GS_RUN ||
                                 gs[g*3 +: 3] == TA_GS_STOP || gs[g*3 +: 3] == TA_GS_REL)) begin
          `SFTC_ASSERT(tmr[g*32 +: 32] <= wd_q, "phase timer beyond the watchdog limit")
        end
      end
    end
  end
`endif
endmodule

`default_nettype wire
