# Code coverage (Verilator line / branch points)

Merged over the 14 `tb_ta_sys` tests and `tb_ta_clktree`. A point is one statement block or branch (if / elsif / else / case item) instrumented by `verilator --coverage-line`, merged over instances; it is not toggle, FSM or functional coverage.

* New Project 39 RTL, all instrumented points: **291 / 314 (92.7 %)**
* New Project 39 RTL, run-time points: **291 / 303 (96.0 %)**; excluded: 11 points in compile-time constant functions (f_nbt, f_bw, f_bd, f_grp_info), used only in localparam initialisers (evaluated at elaboration), so their points can never count
* Reused TestCore blocks (as used here): 373 / 418 (89.2 %)

| File | Kind | Covered / points | % |
|---|---|---|---|
| `rtl/sfta_consts.svh` | new (P39) | 14 / 15 | 93.3 |
| `rtl/sfta_group_collar.sv` | new (P39) | 22 / 22 | 100.0 |
| `rtl/sfta_group_ctrl.sv` | new (P39) | 10 / 10 | 100.0 |
| `rtl/sfta_regs.sv` | new (P39) | 123 / 126 | 97.6 |
| `rtl/sfta_seq.sv` | new (P39) | 95 / 103 | 92.2 |
| `rtl/silicaflux_test_access.sv` | new (P39) | 27 / 38 | 71.1 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_consts.svh` | reused (TestCore P07) | 46 / 47 | 97.9 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_jtag_reg_bridge.sv` | reused (TestCore P07) | 31 / 32 | 96.9 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_jtag_tap.sv` | reused (TestCore P07) | 31 / 31 | 100.0 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_mbist_addr_gen.sv` | reused (TestCore P07) | 10 / 10 | 100.0 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_mbist_bank_mux.sv` | reused (TestCore P07) | 18 / 19 | 94.7 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_mbist_fail_log.sv` | reused (TestCore P07) | 28 / 32 | 87.5 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_mbist_pattern.sv` | reused (TestCore P07) | 10 / 10 | 100.0 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_mem_owner.sv` | reused (TestCore P07) | 37 / 41 | 90.2 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_regs.sv` | reused (TestCore P07) | 61 / 79 | 77.2 |
| `third_party/silicaflux-testcore/rtl/testcore/sftc_sync.sv` | reused (TestCore P07) | 3 / 3 | 100.0 |
| `third_party/silicaflux-testcore/rtl/testcore/silicaflux_mbist.sv` | reused (TestCore P07) | 65 / 71 | 91.5 |
| `third_party/silicaflux-testcore/rtl/testcore/silicaflux_test_mode_controller.sv` | reused (TestCore P07) | 33 / 43 | 76.7 |

## Uncovered run-time points in the new RTL (line numbers)

* `rtl/sfta_consts.svh`: 119 `TA_EC_REINIT:      ta_ras_type = TA_RAS_RECOVERY;`
* `rtl/sfta_group_collar.sv`: none
* `rtl/sfta_group_ctrl.sv`: none
* `rtl/sfta_regs.sv`: 271 `if (lost_any) begin`, 339 `if (r_viol_cnt != 32'hFFFF_FFFF) r_viol_cnt <= r_viol_cnt + 32'd1;`, 359 `if (lost_any && r_lost != 16'hFFFF) r_lost <= r_lost + 16'd1;`
* `rtl/sfta_seq.sv`: 111 `RES_ABORTED: map_res = TA_RES_ABORTED;`, 161 `if (cycles != 32'hFFFF_FFFF) cycles <= cycles + 32'd1;`, 167 `if (tmr[g*32 +: 32] != 32'hFFFF_FFFF) tmr[g*32 +: 32] <= tmr[g*32 +: 3`, 198 `if (g_refused[g]) begin           // the engine's own refusal event is`, 216 `end else if (tmo_v[g]) begin`, 226 `end else if (tmo_v[g]) begin`, 229 `if (stop_on_fail) stop_l <= 1'b1;`
* `rtl/silicaflux_test_access.sv`: none
