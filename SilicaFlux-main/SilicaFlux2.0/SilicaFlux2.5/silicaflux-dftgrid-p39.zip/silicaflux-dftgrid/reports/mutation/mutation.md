# Mutation testing (new Project 39 RTL)

Each mutant is one deliberate defect; the full `tb_ta_sys` suite runs on a Verilator build with fatal assertions. KILLED = a test failed, an assertion fired or the run did not complete.

**26 / 26 killed**

| Mutant | File | Defect | Result | Killed by |
|---|---|---|---|---|
| M01 | `rtl/sfta_lc_policy.sv` | scan pin honoured in every consistent lifecycle | **KILLED** | tests: lc_policy, secure_debug |
| M02 | `rtl/sfta_lc_policy.sv` | lifecycle consistency check removed | **KILLED** | tests: lc_policy |
| M03 | `rtl/sfta_lc_policy.sv` | in-field MBIST without the fuse | **KILLED** | tests: lc_policy, secure_debug |
| M04 | `rtl/silicaflux_test_access.sv` | JTAG register access in every lifecycle | **KILLED** | RTL assertion: SFTC_ASSERTION_FAILED TOP.tb_ta_sys.u_ta t=333495000: JTAG register access forwarded outside DEV |
| M05 | `rtl/silicaflux_test_access.sv` | unprivileged writes to page 0 outside DEV | **KILLED** | tests: lc_policy, secure_debug |
| M06 | `rtl/silicaflux_test_access.sv` | group-page MODE_CTRL / UNLOCK accepted | **KILLED** | tests: abort_protect |
| M07 | `rtl/silicaflux_test_access.sv` | scan pin not gated by the scan permission (MBIST permission only) | **KILLED** | RTL assertion: SFTC_ASSERTION_FAILED TOP.tb_ta_sys.u_ta t=368555000: scan mode without DEV lifecycle |
| M08 | `rtl/sfta_group_collar.sv` | functional path open while the group is under test | **KILLED** | RTL assertion: SFTC_ASSERTION_FAILED TOP.tb_ta_sys.u_ta.g_grp[1].u_collar t=601175000: test owns the group while its functional path is open |
| M09 | `rtl/sfta_group_collar.sv` | no re-initialisation sweep after a test | **KILLED** | tests: mbist_select, algorithms, func_switch, faults, ordering, timeout, reset_in_test, error_prop, recovery, abort_protect |
| M10 | `rtl/sfta_group_collar.sv` | sweep writes zero instead of the valid init word | **KILLED** | tests: mbist_select, algorithms, func_switch, faults, ordering, timeout, reset_in_test, error_prop, recovery, abort_protect |
| M11 | `rtl/sfta_group_collar.sv` | read response taken from the wrong pipeline stage | **KILLED** | tests: mbist_select, algorithms, func_switch, faults, ordering, timeout, reset_in_test, secure_debug, error_prop, recovery |
| M12 | `rtl/sfta_group_collar.sv` | read response one cycle early for LAT > 1 | **KILLED** | tests: mbist_select, algorithms, func_switch, faults, ordering, timeout, reset_in_test, secure_debug, error_prop, recovery |
| M13 | `rtl/sfta_group_collar.sv` | branch clock never requested | **KILLED** | tests: mbist_select, dft_clkrst |
| M14 | `rtl/sfta_group_collar.sv` | group reported released while the memory still initialises | **KILLED** | tests: jtag_tap, lc_policy, mbist_select, algorithms, func_switch, faults, ordering, timeout, reset_in_test, secure_debug, error_prop, recovery, abort_protect, dft_clkrst |
| M15 | `rtl/sfta_group_collar.sv` | acquisition allowed during the reset initialisation sweep | **KILLED** | tests: reset_in_test |
| M16 | `rtl/sfta_seq.sv` | sequential mode starts every group at once | **KILLED** | RTL assertion: SFTC_ASSERTION_FAILED TOP.tb_ta_sys.u_ta.u_seq t=12198185000: sequential mode: more than one group acquired |
| M17 | `rtl/sfta_seq.sv` | watchdog never expires | **KILLED** | RTL assertion: SFTC_ASSERTION_FAILED TOP.tb_ta_sys.u_ta.u_seq.unnamedblk8 t=17160475000: phase timer beyond the watchdog limit |
| M18 | `rtl/sfta_seq.sv` | engine FAIL reported as PASS by the sequencer | **KILLED** | tests: faults |
| M19 | `rtl/sfta_seq.sv` | STOP_ON_FAIL ignored | **KILLED** | tests: faults |
| M20 | `rtl/sfta_consts.svh` | MBIST failure sent to RAS with the wrong type | **KILLED** | tests: faults, error_prop |
| M21 | `rtl/sfta_regs.sv` | security violations not logged | **KILLED** | tests: lc_policy, secure_debug |
| M22 | `rtl/sfta_regs.sv` | any value unlocks the destructive mode | **KILLED** | tests: abort_protect |
| M23 | `rtl/sfta_group_ctrl.sv` | PROTECT ignored | **KILLED** | tests: abort_protect |
| M24 | `rtl/sfta_group_ctrl.sv` | page START not blocked while the sequencer owns the group | **KILLED** | tests: abort_protect |
| M25 | `rtl/silicaflux_test_access.sv` | ICG test enable only during shift | **KILLED** | tests: lc_policy, dft_clkrst |
| M26 | `rtl/silicaflux_test_access.sv` | intrusion counted every cycle instead of once per episode | **KILLED** | tests: error_prop |
