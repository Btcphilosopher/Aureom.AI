# Formal verification

Tools: Yosys 0.70+post (git sha1 v0.70, Release, GNU /nix/store/r5ri78axx1qggkjq3vawywlzglg70b5w-gcc-wrapper-16.2.0/bin/g++ 16.2.0); SBY 0.70 (nixpkgs)

| Harness | Engine | Result | Time (s) | Non-vacuity reach points |
|---|---|---|---|---|
| `fv_collar`: Group collar, collar re-initialisation sweep + init after reset (2 banks x 4 rows, LAT 2) | abc pdr (unbounded) | **PASS** | 0.5 | #0 REACHED@10, #1 REACHED@13, #2 REACHED@20, #3 REACHED@8 |
| `fv_collar_self`: Group collar, memory self-initialisation mode (P33 grid style) | abc pdr (unbounded) | **PASS** | 0.5 | #0 REACHED@6, #1 REACHED@9, #2 REACHED@17, #3 REACHED@4 |
| `fv_seq`: MBIST sequencer, 2 groups, every group status free | abc pdr (unbounded) | **PASS** | 18.8 | #0 REACHED@12, #1 REACHED@6, #2 REACHED@4, #3 REACHED@7 |
| `fv_ta_bmc`: whole silicaflux_test_access (2 groups, free JTAG / bus / lifecycle / pins, independent clk and tck): lifecycle gate G1-G8 + every embedded TA and TestCore assertion | smtbmc z3, BOUNDED: no counterexample in steps 0..15 (not a proof) | **PASS (bounded)** | 1063.8 | - |

Properties:

* `fv_collar`: C1 raw memory access only with tst_active; C2 engine access only in TEST_ACTIVE; C3 test owns the group => every functional request blocked; C4 sweep and engine never in the same cycle; C5 engine access selects exactly one bank; C6 read response only for a read issued LAT cycles earlier; C7 the group is never released with undefined content; C8 REINIT_REQUIRED cannot occur; C9 in NORMAL only an initialisation sweep uses the test bus; C10 reset initialisation keeps the memory in test (functional traffic held); C11 clock requested whenever the test bus is owned; embedded: collar assertions, TestCore sftc_mem_owner assertions
* `fv_collar_self`: C1-C9, C11 as above with INIT_MODE = self
* `fv_seq`: S1 groups acquired only inside a sequence; S2 acquisition only of a group owned by the sequencer; S3 sequential mode: at most one group acquired; S4 START only while the group is acquired; S5 done and busy exclusive; S6 sequence PASS => every selected group PASS; S7 the watchdog bounds every timed phase; S8 START only after the group was owned by test
* `fv_ta_bmc`: G1 scan mode only in a consistent DEV lifecycle; G2 scan enable only in scan mode; G3 debug permission only in DEV; G4 JTAG_ACCESS / DIAGNOSTIC only in DEV; G5 MBIST mode only with lifecycle permission (previous cycle); G6 raw memory access only in test ownership; G7 unprivileged write outside DEV -> error; G8 unprivileged group-page read outside DEV -> error; embedded: access gate (no JTAG forward outside DEV), collar, sequencer, register, mode controller, MBIST engine, bank mux, ownership assertions

Limits: proofs hold for the harness parameterisation (small banks / depths); synchronisers are ideal flops (no metastability); liveness is covered by simulation, not proven; the whole-block check is bounded.

Overall: **PASS**
