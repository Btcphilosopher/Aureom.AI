# Regression

Overall: **PASS** (17/17 steps PASS)

| Step | Result | Time (s) | Summary |
|---|---|---|---|
| tools | **PASS** | 0.3 | iverilog Icarus Verilog version 12.0 (stable) (); verilator Verilator 5.020 2024-01-01 rev (Debian 5.020-1); yosys_0.33 Yosys 0.33 (git sha1 2584903a060); yosys_0.70 Yosys 0.70+post (git sha1 v0.70, Release, GNU /nix/store/r5ri78axx1qggkjq3vawywlzglg70b5w-gcc-wrapper-16.2.0/bin/g++ 16.2.0); openroad 26Q3; sby SBY 0.70 (nixpkgs); python 3.13.18 |
| hashes | **PASS** | 0.0 | 404 files, 0 mismatches |
| regmap | **PASS** | 0.0 |  |
| lint | **PASS** | 3.6 | verilator_synthesis_view: {'warnings': 0, 'errors': 0}; verilator_simulation_view: {'warnings': 0, 'errors': 0}; icarus: {'exit': 0, 'warnings_in_new_rtl': 0}; yosys_0.33: {'exit': 0}; yosys_0.70: {'exit': 0} |
| illegal | **PASS** | 9.1 | 10/10 illegal sets refused |
| sim_icarus | **PASS** | 1011.4 | 15/15 tests, 1725464 checks |
| sim_verilator | **PASS** | 505.5 | 15/15 tests, 1725464 checks |
| xsim | **PASS** | 0.0 | 15/15 tests identical |
| coverage | **PASS** | 0.0 |  |
| synth | **PASS** | 20.9 | 13291 cells, 146309.072 µm², 3039 flops |
| scan | **PASS** | 10.6 | 17 chains, 3039 cells, continuity PASS |
| place | **PASS** | 15.0 |  |
| scanplan | **PASS** | 41.0 |  |
| physical | **PASS** | 0.1 |  |
| formal | **PASS** | 0.0 | fv_collar: PASS, fv_collar_self: PASS, fv_seq: PASS, fv_ta_bmc: PASS (bounded) |
| mutation | **PASS** | 0.0 | 26/26 killed |
| codecov | **PASS** | 0.0 | new RTL 291/314 line points (92.7 %; run-time points 291/303 = 96.0 %), reused TestCore 373/418 (89.2 %) |
