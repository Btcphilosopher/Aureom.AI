read_liberty third_party/silicaflux-testcore/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog reports/synth/netlist.v
link_design sfta_synth_top
create_clock -name clk -period 10 [get_ports clk]
create_clock -name tck -period 50 [get_ports tck]
set_clock_groups -asynchronous -group clk -group tck
set_clock_uncertainty 0.25 [all_clocks]
set_case_analysis 0 [get_ports scan_mode_pin]
set_case_analysis 0 [get_ports scan_en_pin]
set_input_delay 2.0 -clock clk [delete_from_list [all_inputs] [get_ports {clk tck trst_n rst_n tms tdi}]]
set_input_delay 10 -clock tck [get_ports {tms tdi}]
set_output_delay 2.0 -clock clk [delete_from_list [all_outputs] [get_ports {tdo tdo_oe}]]
set_output_delay 10 -clock tck [get_ports {tdo tdo_oe}]
set_false_path -from [get_ports {rst_n trst_n}]
set_load 0.01 [all_outputs]
puts "SFTA_STA_FUNCTIONAL"
report_checks -path_delay max -group_path_count 3 -format full -digits 3
report_checks -path_delay min -group_path_count 1 -format full -digits 3
report_wns -digits 3
report_tns -digits 3
report_worst_slack -max -digits 3
report_worst_slack -min -digits 3
report_power -digits 6
