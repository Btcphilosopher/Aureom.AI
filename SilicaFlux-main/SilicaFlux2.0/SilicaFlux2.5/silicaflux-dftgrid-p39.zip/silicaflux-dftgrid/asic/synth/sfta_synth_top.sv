// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: sfta_synth_top
// Synthesis / scan-insertion top: silicaflux_test_access in the verified
// three-group configuration of tb_ta_sys (P33 grid sg_min4 + two MemoryCore
// slices).  The memories themselves are NOT part of this netlist: they are
// macros / separate blocks reached through the tst_* ports.
// Classification: SYNTHESIZABLE (wrapper)
// =============================================================================
`default_nettype none
module sfta_synth_top #(
  parameter int NG = 3, MAXNB = 4, MAXSW = 72, MAXRAW = 10
) (
  input  wire logic tck, trst_n, tms, tdi,
  output logic      tdo, tdo_oe,
  input  wire logic clk, rst_n,
  input  wire logic lc_valid,
  input  wire logic [3:0] lc_state,
  input  wire logic sb_debug_en, sb_test_mode_en, otp_ift_en,
  input  wire logic scan_mode_pin, scan_en_pin, test_rst_n_pin, cpu_halted,
  input  wire logic s_req, s_we, s_priv,
  input  wire logic [11:0] s_addr,
  input  wire logic [31:0] s_wdata,
  output logic s_gnt,
  output logic [31:0] s_rdata,
  output logic s_err,
  output logic [NG-1:0] quiesce_req,
  input  wire logic [NG-1:0] quiesce_ack, f_busy, f_req,
  output logic [NG-1:0] f_block,
  input  wire logic [NG-1:0] mem_init_busy,
  output logic [NG-1:0] mem_ready, tst_active,
  output logic [NG*MAXNB-1:0] tst_sel,
  output logic [NG-1:0] tst_ce, tst_we,
  output logic [NG*MAXRAW-1:0] tst_addr,
  output logic [NG*MAXSW-1:0] tst_wdata,
  input  wire logic [NG*MAXNB*MAXSW-1:0] tst_rdata,
  output logic dft_test_mode, dft_icg_te, dft_scan_en, dft_test_rst_n, dft_mem_inhibit,
  output logic [NG-1:0] mbist_clk_req,
  output logic dbg_allow, jtag_mode, diag_mode,
  output logic ras_ev_valid,
  output logic [3:0] ras_ev_type,
  output logic [31:0] ras_ev_addr,
  output logic ras_ev_addr_v,
  output logic [31:0] ras_ev_info,
  output logic ras_ev_corr, irq,
  output logic [2:0] mode,
  output logic test_done, test_pass, test_fail
);
  localparam logic [35:0] IW36 = {4{9'h100}};
  silicaflux_test_access #(
    .NG(NG), .MAXNB(MAXNB), .MAXSW(MAXSW), .MAXRAW(MAXRAW),
    .G_NB({8'd2, 8'd4, 8'd4}), .G_SW({16'd36, 16'd36, 16'd72}), .G_DEPTH({24'd1024, 24'd1024, 24'd1024}),
    .G_LAT({4'd2, 4'd1, 4'd1}), .G_INIT({4'd1, 4'd1, 4'd2}), .G_INIT_ON_RESET(3'b110),
    .G_INIT_WORD({72'(IW36), 72'(IW36), 72'd0}), .G_KIND({4'd1, 4'd1, 4'd0}),
    .G_PIPE_REQ(3'b100), .G_PIPE_RSP(3'b100), .ENG_TIMEOUT(1024), .OWN_TIMEOUT(4096), .SCAN_CHAINS(0)
  ) u_ta (
    .tck(tck), .trst_n(trst_n), .tms(tms), .tdi(tdi), .tdo(tdo), .tdo_oe(tdo_oe),
    .clk(clk), .rst_n(rst_n), .lc_valid(lc_valid), .lc_state(lc_state), .sb_debug_en(sb_debug_en), .sb_test_mode_en(sb_test_mode_en),
    .otp_ift_en(otp_ift_en), .scan_mode_pin(scan_mode_pin), .scan_en_pin(scan_en_pin), .test_rst_n_pin(test_rst_n_pin), .cpu_halted(cpu_halted), .s_req(s_req),
    .s_we(s_we), .s_priv(s_priv), .s_addr(s_addr), .s_wdata(s_wdata), .s_gnt(s_gnt), .s_rdata(s_rdata),
    .s_err(s_err), .quiesce_req(quiesce_req), .quiesce_ack(quiesce_ack), .f_busy(f_busy), .f_req(f_req), .f_block(f_block),
    .mem_init_busy(mem_init_busy), .mem_ready(mem_ready), .tst_active(tst_active), .tst_sel(tst_sel), .tst_ce(tst_ce), .tst_we(tst_we),
    .tst_addr(tst_addr), .tst_wdata(tst_wdata), .tst_rdata(tst_rdata), .dft_test_mode(dft_test_mode), .dft_icg_te(dft_icg_te), .dft_scan_en(dft_scan_en),
    .dft_test_rst_n(dft_test_rst_n), .dft_mem_inhibit(dft_mem_inhibit), .mbist_clk_req(mbist_clk_req), .dbg_allow(dbg_allow), .jtag_mode(jtag_mode), .diag_mode(diag_mode),
    .ras_ev_valid(ras_ev_valid), .ras_ev_type(ras_ev_type), .ras_ev_addr(ras_ev_addr), .ras_ev_addr_v(ras_ev_addr_v), .ras_ev_info(ras_ev_info), .ras_ev_corr(ras_ev_corr),
    .irq(irq), .mode(mode), .test_done(test_done), .test_pass(test_pass), .test_fail(test_fail)
  );
endmodule
`default_nettype wire
