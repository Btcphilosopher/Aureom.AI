#!/usr/bin/env bash
# Yosys -> sky130hd synthesis of sfta_synth_top (flattened, for OpenROAD DFT) + OpenSTA (pre-placement).
#   asic/synth/run_synth.sh            (env: SFTA_YOSYS, SFTA_STA, SFTA_PDK)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
Y=${SFTA_YOSYS:-yosys}; STA=${SFTA_STA:-sta}
PDK=${SFTA_PDK:-third_party/silicaflux-testcore/pdk}
LIB=$PDK/sky130_fd_sc_hd__tt_025C_1v80.lib
OUT=reports/synth; mkdir -p $OUT
FILES=$(grep -v '^//' rtl/files_ta.f | grep -v '^+' | tr '\n' ' ')
cat > $OUT/synth.ys <<YS
read_liberty -lib $LIB
read_verilog -sv -DSYNTHESIS -Irtl -Ithird_party/silicaflux-testcore/rtl/testcore $FILES asic/synth/sfta_synth_top.sv
hierarchy -check -top sfta_synth_top
synth -top sfta_synth_top -flatten
dfflibmap -liberty $LIB -dont_use *lpflow* -dont_use *probe*
abc -liberty $LIB -D 10000 -dont_use *lpflow* -dont_use *probe*
opt_clean -purge
hilomap -hicell sky130_fd_sc_hd__conb_1 HI -locell sky130_fd_sc_hd__conb_1 LO
setundef -zero
splitnets
opt_clean -purge
check
tee -o $OUT/stat.txt stat -liberty $LIB
write_verilog -noattr -noexpr $OUT/netlist.v
YS
$Y -l $OUT/yosys.log -q -s $OUT/synth.ys
cat > $OUT/sta.tcl <<TCL
read_liberty $LIB
read_verilog $OUT/netlist.v
link_design sfta_synth_top
create_clock -name clk -period 10 [get_ports clk]
create_clock -name tck -period 50 [get_ports tck]
set_clock_groups -asynchronous -group clk -group tck
set_clock_uncertainty 0.25 [all_clocks]
set_case_analysis 0 [get_ports scan_mode_pin]
set_case_analysis 0 [get_ports scan_en_pin]
set_input_delay 2.0 -clock clk [delete_from_list [all_inputs] [get_ports {clk tck trst_n rst_n tms tdi}]]
set_input_delay 10 -clock tck [get_ports {tms tdi}]
set_output_delay 2.0 -clock clk [delete_from_list [all_outputs] [get_ports {tdo tdo_oe}]]
set_output_delay 10 -clock tck [get_ports {tdo tdo_oe}]
set_false_path -from [get_ports {rst_n trst_n}]
set_load 0.01 [all_outputs]
puts "SFTA_STA_FUNCTIONAL"
report_checks -path_delay max -group_path_count 3 -format full -digits 3
report_checks -path_delay min -group_path_count 1 -format full -digits 3
report_wns -digits 3
report_tns -digits 3
report_worst_slack -max -digits 3
report_worst_slack -min -digits 3
report_power -digits 6
TCL
$STA -no_init -exit $OUT/sta.tcl > $OUT/sta.rpt 2>&1 || true
grep -E "Chip area|Number of cells|cells$" $OUT/stat.txt | head -5
grep -E "^(wns|tns|worst slack)" $OUT/sta.rpt
