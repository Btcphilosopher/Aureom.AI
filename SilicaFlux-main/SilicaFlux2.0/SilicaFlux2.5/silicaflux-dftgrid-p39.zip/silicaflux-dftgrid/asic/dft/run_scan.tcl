# =============================================================================
# SilicaFlux DFTGRID (Project 39) -- OpenROAD DFT scan insertion (open flow)
#   openroad -no_init -exit asic/dft/run_scan.tcl
#   env: SFTA_PDK (sky130hd views), SFTA_NET (Yosys netlist), SFTA_TOP, SFTA_OUT, SFTA_MAXLEN
# Clock-domain-pure chains (no clock mixing), scan cells from the sky130hd
# liberty (scan_replace), stitched by execute_dft_plan.
# =============================================================================
set pdk    $::env(SFTA_PDK)
set net    $::env(SFTA_NET)
set top    $::env(SFTA_TOP)
set out    $::env(SFTA_OUT)
set maxlen $::env(SFTA_MAXLEN)
read_lef     $pdk/sky130hd.tlef
read_lef     $pdk/sky130_fd_sc_hd_merged.lef
read_liberty $pdk/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog $net
link_design  $top
create_clock -name clk -period 10 [get_ports clk]
create_clock -name tck -period 50 [get_ports tck]
set_dft_config -max_length $maxlen -clock_mixing no_mix \
    -scan_enable_name_pattern "scan_enable_{}" -scan_in_name_pattern "scan_in_{}" -scan_out_name_pattern "scan_out_{}"
report_dft_config
scan_replace
report_dft_plan -verbose
execute_dft_plan
write_verilog $out/scan_netlist.v
puts "SFTA_SCAN_DONE"
