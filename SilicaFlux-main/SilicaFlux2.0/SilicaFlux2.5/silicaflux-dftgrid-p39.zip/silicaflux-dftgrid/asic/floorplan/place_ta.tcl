# =============================================================================
# SilicaFlux DFTGRID (Project 39) -- placement experiment of the scan-inserted
# test-access block (OpenROAD, sky130hd).  NOT a sign-off flow: no CTS, no
# routing; parasitics estimated from placement.
#   env: SFTA_PDK SFTA_NET SFTA_TOP SFTA_OUT SFTA_UTIL
# Reports: area, HPWL, high-fanout test-control nets, chain endpoint locations,
# functional / scan-shift timing after repair_design (estimated parasitics).
# =============================================================================
set pdk  $::env(SFTA_PDK)
set net  $::env(SFTA_NET)
set top  $::env(SFTA_TOP)
set out  $::env(SFTA_OUT)
set util $::env(SFTA_UTIL)
read_lef     $pdk/sky130hd.tlef
read_lef     $pdk/sky130_fd_sc_hd_merged.lef
read_liberty $pdk/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog $net
link_design  $top
create_clock -name clk -period 10 [get_ports clk]
create_clock -name tck -period 50 [get_ports tck]
set_clock_groups -asynchronous -group clk -group tck
set_clock_uncertainty 0.25 [all_clocks]
initialize_floorplan -utilization $util -aspect_ratio 1.0 -core_space 10 -site unithd
make_tracks
place_pins -hor_layers met3 -ver_layers met2
global_placement -density 0.6
set_wire_rc -signal -layer met2
set_wire_rc -clock  -layer met5
estimate_parasitics -placement
puts "SFTA_PRE_REPAIR"
report_design_area
repair_design
detailed_placement
check_placement -verbose
estimate_parasitics -placement
puts "SFTA_POST_REPAIR"
report_design_area
# ---- functional mode
set_case_analysis 0 [get_ports scan_mode_pin]
set_case_analysis 0 [get_ports scan_en_pin]
set_case_analysis 0 [get_ports scan_enable_0]
puts "SFTA_TIMING_FUNCTIONAL"
report_worst_slack -max -digits 3
report_worst_slack -min -digits 3
report_tns -digits 3
report_checks -path_delay max -format end -group_path_count 5 -digits 3
# ---- scan shift mode (scan enable high, tester clocks)
unset_case_analysis [get_ports scan_mode_pin]
unset_case_analysis [get_ports scan_en_pin]
unset_case_analysis [get_ports scan_enable_0]
set_case_analysis 1 [get_ports scan_mode_pin]
set_case_analysis 1 [get_ports scan_en_pin]
set_case_analysis 1 [get_ports scan_enable_0]
create_clock -name clk -period 20 [get_ports clk]
create_clock -name tck -period 20 [get_ports tck]
puts "SFTA_TIMING_SHIFT"
report_worst_slack -max -digits 3
report_worst_slack -min -digits 3
report_checks -path_delay min -format end -group_path_count 5 -digits 3
puts "SFTA_DEF"
write_def $out/ta_placed.def
puts "SFTA_PLACE_DONE"
