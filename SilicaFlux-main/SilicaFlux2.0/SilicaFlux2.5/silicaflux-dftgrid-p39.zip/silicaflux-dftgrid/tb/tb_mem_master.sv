// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: tb_mem_master        (SIMULATION ONLY)
// Functional-master model with scoreboard for one memory port
// (valid/ready request, in-order valid/ready response):
//   * random reads / writes inside its own word window [BASE, BASE + SPAN*WB)
//   * up to MAXOUT outstanding requests; responses checked in order against a
//     shadow memory (expected value captured at acceptance)
//   * ANY error response is a check failure (a parity / ECC error after a
//     test session means the memory was not re-initialised correctly)
//   * quiesce protocol: on quiesce_req stop issuing (a presented request is
//     kept until accepted), drain, then raise quiesce_ack; resume when the
//     request drops.  Misbehaviour knobs for negative tests:
//       rogue  : acknowledge but keep presenting requests (intrusion)
//       no_ack : never acknowledge (ownership timeout)
//   * zero_shadow (pulse) : the memory was re-initialised -> every word of
//     the window is known to read zero
// =============================================================================
`default_nettype none

module tb_mem_master #(
  parameter int          DW     = 64,
  parameter logic [31:0] BASE   = 32'h2000_0000,
  parameter int          SPAN   = 256,            // words in the window
  parameter int          MAXOUT = 2,
  parameter bit          FULLSTRB = 1'b1,         // SECDED granule: always write whole words
  parameter int          SEED   = 1
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            en,
  input  wire logic            rogue,
  input  wire logic            no_ack,
  input  wire logic            zero_shadow,
  input  wire logic            quiesce_req,
  output logic                 quiesce_ack,
  // request
  output logic                 req_valid,
  input  wire logic            req_ready,
  output logic                 req_we,
  output logic [31:0]          req_addr,
  output logic [DW-1:0]        req_wdata,
  output logic [DW/8-1:0]      req_wstrb,
  // response
  input  wire logic            rsp_valid,
  output logic                 rsp_ready,
  input  wire logic [DW-1:0]   rsp_rdata,
  input  wire logic            rsp_err
);
  localparam int WB = DW / 8;

  logic [DW-1:0] sh [SPAN];
  bit            kn [SPAN];
  // outstanding queue (in order)
  logic          q_rd  [MAXOUT];
  logic [DW-1:0] q_exp [MAXOUT];
  bit            q_kn  [MAXOUT];
  int            q_idx [MAXOUT];
  int            q_n;
  int unsigned   rng;

  int checks, errors, n_rd, n_wr, n_rsp, stall_cyc, accepted_total;
  int wa, wi;

  function automatic int unsigned nxt();
    rng = rng * 1664525 + 1013904223;
    return rng;
  endfunction

  task automatic fail(input string what);
    errors++;
    $display("MASTER %m CHECK FAILED t=%0t: %s", $time, what);
  endtask

  initial begin
    rng = SEED;
    for (int i = 0; i < SPAN; i++) begin sh[i] = '0; kn[i] = 1'b0; end
  end

  wire draining = quiesce_req && !rogue;
  assign rsp_ready = 1'b1;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      req_valid <= 1'b0; req_we <= 1'b0; req_addr <= '0; req_wdata <= '0; req_wstrb <= '0;
      quiesce_ack <= 1'b0; q_n = 0;
    end else begin
      // ---- response (in order)
      if (rsp_valid && rsp_ready) begin
        n_rsp++;
        checks++;
        if (q_n == 0) fail("response with nothing outstanding");
        else begin
          if (rsp_err) fail($sformatf("error response (word %0d, rd=%0d)", q_idx[0], q_rd[0]));
          else if (q_rd[0] && q_kn[0] && rsp_rdata !== q_exp[0])
            fail($sformatf("read word %0d: got %h expected %h", q_idx[0], rsp_rdata, q_exp[0]));
          for (int i = 0; i + 1 < MAXOUT; i++) begin
            q_rd[i] = q_rd[i+1]; q_exp[i] = q_exp[i+1]; q_kn[i] = q_kn[i+1]; q_idx[i] = q_idx[i+1];
          end
          q_n = q_n - 1;
        end
      end
      // ---- request accepted
      if (req_valid && req_ready) begin
        accepted_total++;
        wa = (req_addr - BASE) / WB;
        if (q_n >= MAXOUT) fail("queue overflow");
        q_rd[q_n] = !req_we; q_idx[q_n] = wa; q_exp[q_n] = sh[wa]; q_kn[q_n] = kn[wa];
        q_n = q_n + 1;
        if (req_we) begin
          for (int b = 0; b < WB; b++) if (req_wstrb[b]) sh[wa][b*8 +: 8] = req_wdata[b*8 +: 8];
          if (&req_wstrb) kn[wa] = 1'b1;
          n_wr++;
        end else n_rd++;
        req_valid <= 1'b0;
      end else if (req_valid) stall_cyc++;
      // ---- issue
      if ((!req_valid || req_ready) && en && (!draining || rogue) && (q_n + ((req_valid && !req_ready) ? 1 : 0)) < MAXOUT
          && (nxt() % 4) != 0) begin
        wi = int'(nxt() % SPAN);
        req_valid <= 1'b1;
        req_addr  <= BASE + 32'(wi * WB);
        req_we    <= (nxt() % 2) == 0;
        req_wdata <= {(DW/32){nxt()}} ^ DW'(wi);
        req_wstrb <= FULLSTRB ? '1 : ((nxt() % 3 == 0) ? WB'(nxt()) | WB'(1) : '1);
      end
      // ---- quiesce acknowledge: nothing presented, nothing outstanding
      quiesce_ack <= quiesce_req && !no_ack && (rogue || (!req_valid && q_n == 0)) &&
                     !(req_valid && req_ready);
    end
  end

  // re-initialisation: every word reads zero from now on
  always @(posedge zero_shadow) begin
    for (int i = 0; i < SPAN; i++) begin sh[i] = '0; kn[i] = 1'b1; end
  end
  // reset: outstanding requests are dropped by the memory
  always @(negedge rst_n) q_n = 0;

  task automatic clear_stats();
    checks = 0; errors = 0; n_rd = 0; n_wr = 0; n_rsp = 0; stall_cyc = 0; accepted_total = 0;
  endtask
  task automatic set_unknown();
    for (int i = 0; i < SPAN; i++) kn[i] = 1'b0;
  endtask
endmodule

`default_nettype wire
