// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: tb_ta_sys          (SIMULATION ONLY)
// System testbench: silicaflux_test_access with REAL memory RTL and REAL RAS.
//
//   group 0 : Project 33 silicaflux_sram_grid, configuration sg_min4
//             (4 banks x 1024 x 72 b SECDED, TEST_LAT 1, INIT_AFTER_TEST 1)
//             -> INIT_MODE self; two functional masters (ports 0 and 1)
//   group 1 : MemoryCore sfmem_banked, 16 KiB, 4 banks x 1024 x 36 b parity, RD_LAT 1
//             -> INIT_MODE collar (+ after reset); one master
//   group 2 : MemoryCore sfmem_banked, 8 KiB, 2 banks x 1024 x 36 b parity, RD_LAT 2,
//             MBIST link pipelined both ways (distance) -> collar init; one master
//   RAS     : Project 26 silicaflux_ras, external event port 0 = test access
//   JTAG    : bit-level TAP driver (TCK asynchronous to clk)
//   SecureBoot lifecycle outputs are driven by the testbench (P28 encodings).
// Every functional master checks every response against a shadow memory;
// any error response (parity / ECC) is a failure.  RTL assertions are fatal.
// Tests (+TEST=name, or all): see the list in the main initial block.
// Output: "TEST <name> RESULT PASS|FAIL checks=<n> errors=<n>" per test.
// =============================================================================
`timescale 1ns/1ps
`include "sfras_defs.svh"
`include "sfras_regs.svh"
`include "sfmem_defs.svh"
`include "sg_cfg.svh"
`default_nettype none

module tb_ta_sys;
  `include "sftc_consts.svh"
  `include "sfta_consts.svh"

  // ======================================================================= configuration
  localparam int NG = 3, MAXNB = 4, MAXSW = 72, MAXRAW = 10;
  localparam logic [35:0] IW36 = {4{9'h100}};                 // zero data, odd parity per byte
  localparam int OWN_TMO = 2000;

  // ======================================================================= clocks / resets
  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n = 1'b1;         // test-access reset (first edge in sys_reset)
  logic mem_rst_n = 1'b1;     // memories + functional masters
  logic tck = 1'b0, trst_n = 1'b1, tms = 1'b1, tdi = 1'b0;
  wire  tdo, tdo_oe;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // lifecycle (SecureBoot outputs) and pins
  logic       lc_valid = 1'b1, sb_debug_en = 1'b1, sb_test_mode_en = 1'b1, otp_ift_en = 1'b1;
  logic [3:0] lc_state = TA_LC_DEV;
  logic scan_mode_pin = 1'b0, scan_en_pin = 1'b0, test_rst_n_pin = 1'b1, cpu_halted = 1'b0;

  // system register port
  logic        s_req = 1'b0, s_we = 1'b0, s_priv = 1'b1;
  logic [11:0] s_addr = '0;
  logic [31:0] s_wdata = '0;
  wire         s_gnt, s_err;
  wire  [31:0] s_rdata;

  // ======================================================================= DUT
  wire [NG-1:0] quiesce_req, f_block, mem_ready, tst_active, tst_ce, tst_we, mbist_clk_req;
  logic [NG-1:0] quiesce_ack, f_busy, f_req, mem_init_busy;
  wire [NG*MAXNB-1:0] tst_sel;
  wire [NG*MAXRAW-1:0] tst_addr;
  wire [NG*MAXSW-1:0] tst_wdata;
  logic [NG*MAXNB*MAXSW-1:0] tst_rdata;
  wire dft_test_mode, dft_icg_te, dft_scan_en, dft_test_rst_n, dft_mem_inhibit, dbg_allow, jtag_mode, diag_mode;
  wire ras_ev_valid, ras_ev_addr_v, ras_ev_corr, irq, test_done, test_pass, test_fail;
  wire [3:0] ras_ev_type;
  wire [31:0] ras_ev_addr, ras_ev_info;
  wire [2:0] mode;

  silicaflux_test_access #(
    .NG(NG), .MAXNB(MAXNB), .MAXSW(MAXSW), .MAXRAW(MAXRAW),
    .G_NB({8'd2, 8'd4, 8'd4}), .G_SW({16'd36, 16'd36, 16'd72}), .G_DEPTH({24'd1024, 24'd1024, 24'd1024}),
    .G_LAT({4'd2, 4'd1, 4'd1}), .G_INIT({4'd1, 4'd1, 4'd2}), .G_INIT_ON_RESET(3'b110),
    .G_INIT_WORD({72'(IW36), 72'(IW36), 72'd0}), .G_KIND({4'd1, 4'd1, 4'd0}),
    .G_PIPE_REQ(3'b100), .G_PIPE_RSP(3'b100),
    .ENG_TIMEOUT(1024), .OWN_TIMEOUT(OWN_TMO), .SCAN_CHAINS(0)
  ) u_ta (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .clk, .rst_n,
    .lc_valid, .lc_state, .sb_debug_en, .sb_test_mode_en, .otp_ift_en,
    .scan_mode_pin, .scan_en_pin, .test_rst_n_pin, .cpu_halted,
    .s_req, .s_we, .s_priv, .s_addr, .s_wdata, .s_gnt, .s_rdata, .s_err,
    .quiesce_req, .quiesce_ack, .f_busy, .f_req, .f_block, .mem_init_busy, .mem_ready,
    .tst_active, .tst_sel, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata,
    .dft_test_mode, .dft_icg_te, .dft_scan_en, .dft_test_rst_n, .dft_mem_inhibit, .mbist_clk_req,
    .dbg_allow, .jtag_mode, .diag_mode,
    .ras_ev_valid, .ras_ev_type, .ras_ev_addr, .ras_ev_addr_v, .ras_ev_info, .ras_ev_corr,
    .irq, .mode, .test_done, .test_pass, .test_fail
  );

  // ======================================================================= functional masters
  logic m_en = 1'b0;
  logic [3:0] m_rogue = '0, m_noack = '0;
  logic [3:0] zero_sh = '0;
  wire  [3:0] m_qack;
  // master 0/1 -> grid ports 0/1 (64 b), master 2 -> group 1, master 3 -> group 2 (32 b)
  wire        m0_v, m0_we, m1_v, m1_we, m2_v, m2_we, m3_v, m3_we;
  wire [31:0] m0_a, m1_a, m2_a, m3_a, m2_d, m3_d;
  wire [63:0] m0_d, m1_d;
  wire [7:0]  m0_s, m1_s;
  wire [3:0]  m2_s, m3_s;
  logic       m0_r, m1_r, m2_r, m3_r;
  logic       m0_rv, m1_rv, m2_rv, m3_rv, m0_re, m1_re, m2_re, m3_re;
  logic [63:0] m0_rd, m1_rd;
  logic [31:0] m2_rd, m3_rd;
  wire        m0_rr, m1_rr, m2_rr, m3_rr;

  tb_mem_master #(.DW(64), .BASE(32'h2000_0000), .SPAN(256), .MAXOUT(3), .FULLSTRB(1), .SEED(11)) u_m0 (
    .clk, .rst_n(mem_rst_n), .en(m_en), .rogue(m_rogue[0]), .no_ack(m_noack[0]), .zero_shadow(zero_sh[0]),
    .quiesce_req(quiesce_req[0]), .quiesce_ack(m_qack[0]),
    .req_valid(m0_v), .req_ready(m0_r), .req_we(m0_we), .req_addr(m0_a), .req_wdata(m0_d), .req_wstrb(m0_s),
    .rsp_valid(m0_rv), .rsp_ready(m0_rr), .rsp_rdata(m0_rd), .rsp_err(m0_re));
  tb_mem_master #(.DW(64), .BASE(32'h2000_4000), .SPAN(256), .MAXOUT(2), .FULLSTRB(1), .SEED(23)) u_m1 (
    .clk, .rst_n(mem_rst_n), .en(m_en), .rogue(m_rogue[1]), .no_ack(m_noack[1]), .zero_shadow(zero_sh[1]),
    .quiesce_req(quiesce_req[0]), .quiesce_ack(m_qack[1]),
    .req_valid(m1_v), .req_ready(m1_r), .req_we(m1_we), .req_addr(m1_a), .req_wdata(m1_d), .req_wstrb(m1_s),
    .rsp_valid(m1_rv), .rsp_ready(m1_rr), .rsp_rdata(m1_rd), .rsp_err(m1_re));
  tb_mem_master #(.DW(32), .BASE(32'h3000_0000), .SPAN(512), .MAXOUT(2), .FULLSTRB(0), .SEED(37)) u_m2 (
    .clk, .rst_n(mem_rst_n), .en(m_en), .rogue(m_rogue[2]), .no_ack(m_noack[2]), .zero_shadow(zero_sh[2]),
    .quiesce_req(quiesce_req[1]), .quiesce_ack(m_qack[2]),
    .req_valid(m2_v), .req_ready(m2_r), .req_we(m2_we), .req_addr(m2_a), .req_wdata(m2_d), .req_wstrb(m2_s),
    .rsp_valid(m2_rv), .rsp_ready(m2_rr), .rsp_rdata(m2_rd), .rsp_err(m2_re));
  tb_mem_master #(.DW(32), .BASE(32'h3100_0000), .SPAN(512), .MAXOUT(2), .FULLSTRB(0), .SEED(41)) u_m3 (
    .clk, .rst_n(mem_rst_n), .en(m_en), .rogue(m_rogue[3]), .no_ack(m_noack[3]), .zero_shadow(zero_sh[3]),
    .quiesce_req(quiesce_req[2]), .quiesce_ack(m_qack[3]),
    .req_valid(m3_v), .req_ready(m3_r), .req_we(m3_we), .req_addr(m3_a), .req_wdata(m3_d), .req_wstrb(m3_s),
    .rsp_valid(m3_rv), .rsp_ready(m3_rr), .rsp_rdata(m3_rd), .rsp_err(m3_re));

  assign quiesce_ack = {m_qack[3], m_qack[2], m_qack[1] & m_qack[0]};
  assign f_req       = {m3_v, m2_v, m1_v | m0_v};

  // ======================================================================= group 0: P33 SRAM grid (sg_min4)
  localparam int NP = `SGC_NP, DW = `SGC_DW, TAG = `SGC_TAG_W, NR = `SGC_NR, NBT = `SGC_NBT;
  logic [NP-1:0]      g_req_valid, g_rsp_ready;
  wire  [NP-1:0]      g_req_ready, g_rsp_valid, g_rsp_err, g_rsp_we, g_rsp_ce;
  logic [NP-1:0]      g_req_we;
  logic [NP*32-1:0]   g_req_addr;
  logic [NP*DW-1:0]   g_req_wdata;
  logic [NP*DW/8-1:0] g_req_wstrb;
  wire  [NP*DW-1:0]   g_rsp_rdata;
  wire  [NP*3-1:0]    g_rsp_err_code;
  wire  [NP*TAG-1:0]  g_rsp_tag;
  wire  [NBT*`SGC_TSW-1:0] g_tst_rdata;
  wire  g_init_busy, g_init_done, g_busy;
  /* verilator lint_off UNUSEDSIGNAL */
  wire [NR-1:0] g_ras_v, g_ras_ce, g_ras_ue, g_ras_p, g_ras_lost;
  wire [NR*3-1:0] g_ras_org; wire [NR*32-1:0] g_ras_addr; wire [NR*9-1:0] g_ras_syn; wire [NR*8-1:0] g_ras_idx;
  wire [NP-1:0] g_e1, g_e2, g_e3, g_e4, g_e5, g_e6, g_e7;
  wire [NBT*2-1:0] g_e8; wire [NBT-1:0] g_e9, g_e10;
  wire [31:0] g_p0, g_p7, g_p8; wire [NP*32-1:0] g_p1, g_p2, g_p3, g_p4; wire [NBT*32-1:0] g_p5, g_p6;
  /* verilator lint_on UNUSEDSIGNAL */

  always_comb begin
    g_req_valid = '0; g_req_we = '0; g_req_addr = '0; g_req_wdata = '0; g_req_wstrb = '0; g_rsp_ready = '1;
    g_req_valid[0] = m0_v && !f_block[0]; g_req_we[0] = m0_we; g_req_addr[31:0] = m0_a;
    g_req_wdata[63:0] = m0_d; g_req_wstrb[7:0] = m0_s; g_rsp_ready[0] = m0_rr;
    g_req_valid[1] = m1_v && !f_block[0]; g_req_we[1] = m1_we; g_req_addr[63:32] = m1_a;
    g_req_wdata[127:64] = m1_d; g_req_wstrb[15:8] = m1_s; g_rsp_ready[1] = m1_rr;
  end
  assign m0_r = g_req_ready[0] && !f_block[0];
  assign m1_r = g_req_ready[1] && !f_block[0];
  assign m0_rv = g_rsp_valid[0]; assign m0_rd = g_rsp_rdata[63:0];   assign m0_re = g_rsp_err[0] || g_rsp_ce[0];
  assign m1_rv = g_rsp_valid[1]; assign m1_rd = g_rsp_rdata[127:64]; assign m1_re = g_rsp_err[1] || g_rsp_ce[1];

  silicaflux_sram_grid `SGC_PARAMS u_grid (
    .clk, .rst_n(mem_rst_n),
    .req_valid(g_req_valid), .req_ready(g_req_ready), .req_we(g_req_we), .req_addr(g_req_addr),
    .req_wdata(g_req_wdata), .req_wstrb(g_req_wstrb), .req_tag('0),
    .rsp_valid(g_rsp_valid), .rsp_ready(g_rsp_ready), .rsp_rdata(g_rsp_rdata), .rsp_err(g_rsp_err),
    .rsp_err_code(g_rsp_err_code), .rsp_we(g_rsp_we), .rsp_ce(g_rsp_ce), .rsp_tag(g_rsp_tag),
    .wp_lock(1'b0), .init_req(1'b0), .init_busy(g_init_busy), .init_done(g_init_done),
    .tst_active(tst_active[0]), .tst_sel(tst_sel[0*MAXNB +: NBT]), .tst_ce(tst_ce[0]), .tst_we(tst_we[0]),
    .tst_addr(tst_addr[0*MAXRAW +: `SGC_RWX]), .tst_wdata(tst_wdata[0*MAXSW +: `SGC_TSW]), .tst_rdata(g_tst_rdata),
    .ras_ev_valid(g_ras_v), .ras_ev_ce(g_ras_ce), .ras_ev_ue(g_ras_ue), .ras_ev_poison(g_ras_p),
    .ras_ev_org(g_ras_org), .ras_ev_addr(g_ras_addr), .ras_ev_syn(g_ras_syn), .ras_ev_idx(g_ras_idx),
    .ras_ev_lost(g_ras_lost),
    .ev_accept(g_e1), .ev_issue(g_e2), .ev_conflict(g_e3), .ev_credit_stall(g_e4), .ev_block_stall(g_e5),
    .ev_error(g_e6), .ev_complete(g_e7), .ev_bank_ops(g_e8), .ev_bank_conflict(g_e9), .ev_rdw_split(g_e10),
    .perf_clear(1'b0), .perf_cycles(g_p0), .perf_issue(g_p1), .perf_conflict(g_p2), .perf_credit_stall(g_p3),
    .perf_complete(g_p4), .perf_bank_ops(g_p5), .perf_bank_conflict(g_p6), .perf_ecc_ce(g_p7), .perf_ecc_ue(g_p8),
    .busy(g_busy)
  );

  // ======================================================================= groups 1 and 2: MemoryCore slices
  wire mc1_busy, mc2_busy;
  wire [4*36-1:0] mc1_tst_rdata;
  wire [2*36-1:0] mc2_tst_rdata;
  /* verilator lint_off UNUSEDSIGNAL */
  wire mc1_ia, mc1_pe, mc2_ia, mc2_pe; wire [3:0] mc1_ps, mc2_ps; wire [31:0] mc1_pa, mc2_pa; wire [2:0] mc1_pp, mc2_pp;
  wire mc1_ea, mc1_ec, mc2_ea, mc2_ec; wire [3:0] mc1_eb; wire [1:0] mc2_eb; wire [5:0] mc1_r, mc1_w, mc2_r, mc2_w;
  /* verilator lint_on UNUSEDSIGNAL */
  logic mc1_v, mc2_v;
  assign mc1_v = m2_v && !f_block[1];
  assign mc2_v = m3_v && !f_block[2];
  wire mc1_ready, mc2_ready;
  assign m2_r = mc1_ready && !f_block[1];
  assign m3_r = mc2_ready && !f_block[2];

  sfmem_banked #(.NP(1), .BYTES(16384), .BANKS(4), .RD_LAT(1), .ECC_MODE(`SFMEM_ECC_PARITY),
                 .BASE(32'h3000_0000)) u_mc1 (
    .clk, .rst_n(mem_rst_n),
    .p_req_valid(mc1_v), .p_req_ready(mc1_ready), .p_req_write(m2_we), .p_req_addr(m2_a), .p_req_wdata(m2_d),
    .p_req_wstrb(m2_s), .p_rsp_valid(m2_rv), .p_rsp_ready(m2_rr), .p_rsp_rdata(m2_rd), .p_rsp_error(m2_re),
    .chk_dis(1'b0), .inj_req(1'b0), .inj_lanes(4'd0), .inj_ack(mc1_ia),
    .par_evt(mc1_pe), .par_syn(mc1_ps), .par_addr(mc1_pa), .par_port(mc1_pp),
    .ev_acc(mc1_ea), .ev_conf(mc1_ec), .ev_bank(mc1_eb), .ev_rd_bytes(mc1_r), .ev_wr_bytes(mc1_w),
    .tst_active(tst_active[1]), .tst_sel(tst_sel[1*MAXNB +: 4]), .tst_ce(tst_ce[1]), .tst_we(tst_we[1]),
    .tst_addr(tst_addr[1*MAXRAW +: 10]), .tst_wdata(tst_wdata[1*MAXSW +: 36]), .tst_rdata(mc1_tst_rdata),
    .busy(mc1_busy));
  sfmem_banked #(.NP(1), .BYTES(8192), .BANKS(2), .RD_LAT(2), .ECC_MODE(`SFMEM_ECC_PARITY),
                 .BASE(32'h3100_0000)) u_mc2 (
    .clk, .rst_n(mem_rst_n),
    .p_req_valid(mc2_v), .p_req_ready(mc2_ready), .p_req_write(m3_we), .p_req_addr(m3_a), .p_req_wdata(m3_d),
    .p_req_wstrb(m3_s), .p_rsp_valid(m3_rv), .p_rsp_ready(m3_rr), .p_rsp_rdata(m3_rd), .p_rsp_error(m3_re),
    .chk_dis(1'b0), .inj_req(1'b0), .inj_lanes(4'd0), .inj_ack(mc2_ia),
    .par_evt(mc2_pe), .par_syn(mc2_ps), .par_addr(mc2_pa), .par_port(mc2_pp),
    .ev_acc(mc2_ea), .ev_conf(mc2_ec), .ev_bank(mc2_eb), .ev_rd_bytes(mc2_r), .ev_wr_bytes(mc2_w),
    .tst_active(tst_active[2]), .tst_sel(tst_sel[2*MAXNB +: 2]), .tst_ce(tst_ce[2]), .tst_we(tst_we[2]),
    .tst_addr(tst_addr[2*MAXRAW +: 10]), .tst_wdata(tst_wdata[2*MAXSW +: 36]), .tst_rdata(mc2_tst_rdata),
    .busy(mc2_busy));

  assign f_busy        = {mc2_busy, mc1_busy, g_busy};
  assign mem_init_busy = {1'b0, 1'b0, g_init_busy};
  always_comb begin
    tst_rdata = '0;
    for (int b = 0; b < 4; b++) tst_rdata[(0*MAXNB + b)*MAXSW +: 72] = g_tst_rdata[b*72 +: 72];
    for (int b = 0; b < 4; b++) tst_rdata[(1*MAXNB + b)*MAXSW +: 36] = mc1_tst_rdata[b*36 +: 36];
    for (int b = 0; b < 2; b++) tst_rdata[(2*MAXNB + b)*MAXSW +: 36] = mc2_tst_rdata[b*36 +: 36];
  end

  // shadow re-initialisation events: end of a test / init session of the group, grid reset
  logic [NG-1:0] ta_q = '0;
  always @(posedge clk) ta_q <= tst_active;
  always @(posedge clk) begin
    zero_sh <= '0;
    if (ta_q[0] && !tst_active[0]) zero_sh[1:0] <= 2'b11;
    if (ta_q[1] && !tst_active[1]) zero_sh[2]   <= 1'b1;
    if (ta_q[2] && !tst_active[2]) zero_sh[3]   <= 1'b1;
  end
  always @(posedge mem_rst_n) begin zero_sh[1:0] = 2'b11; #1 zero_sh[1:0] = 2'b00; end

  // ======================================================================= RAS (Project 26)
  logic        rb_sel = 1'b0, rb_we = 1'b0;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0;
  wire  [31:0] rb_rdata;
  wire         rb_err;
  /* verilator lint_off UNUSEDSIGNAL */
  wire ras_irq_ctrl, ras_irq_host, ras_fatal, ras_contain, ras_cc_warn, ras_cc_fatal, ras_th, ras_wd, ras_fia;
  wire [0:0] r_sq_v, r_init_req, r_fi_arm; wire [1:0] r_sq_op, r_fi_mode; wire [15:0] r_sq_a, r_fi_addr;
  wire [79:0] r_fi_mask; wire r_fi_aen; wire [0:0] r_bfi_arm; wire [1:0] r_bfi_mode; wire [63:0] r_bfi_mask;
  wire [15:0] r_bfi_delay;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_ras #(.NEXT(1), .NMEM(1), .NBUS(1), .MEM_AW(16), .MEM_NW(80), .MEM_DEPTHS(32'd1024),
                   .LOG_DEPTH(16), .CNT_W(32), .TS_W(48), .FI_EN(0), .THERM_W(12)) u_ras (
    .clk, .rst_n(mem_rst_n), .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .rb_priv(1'b1),
    .ext_ev_valid(ras_ev_valid), .ext_ev_type(ras_ev_type), .ext_ev_addr(ras_ev_addr),
    .ext_ev_addr_v(ras_ev_addr_v), .ext_ev_info(ras_ev_info), .ext_ev_corr(ras_ev_corr),
    .mem_ev_valid(1'b0), .mem_ev_ce(1'b0), .mem_ev_ue(1'b0), .mem_ev_poison(1'b0), .mem_ev_org(3'd0),
    .mem_ev_addr(16'd0), .mem_ev_syn(9'd0), .mem_ev_idx(8'd0),
    .mem_scr_req_valid(r_sq_v), .mem_scr_req_ready(1'b1), .mem_scr_req_op(r_sq_op), .mem_scr_req_addr(r_sq_a),
    .mem_scr_rsp_valid(1'b0), .mem_scr_rsp_op(2'd0), .mem_scr_rsp_addr(16'd0), .mem_scr_rsp_ce(1'b0),
    .mem_scr_rsp_ue(1'b0), .mem_scr_rsp_poison(1'b0), .mem_scr_rsp_wb(1'b0),
    .mem_init_req(r_init_req), .mem_init_busy(1'b0), .mem_init_done(1'b1),
    .mem_fi_arm(r_fi_arm), .mem_fi_mode(r_fi_mode), .mem_fi_mask(r_fi_mask), .mem_fi_addr_en(r_fi_aen),
    .mem_fi_addr(r_fi_addr), .mem_fi_armed(1'b0), .mem_fi_fired(1'b0), .mem_fi_fired_addr(16'd0),
    .bfi_arm(r_bfi_arm), .bfi_mode(r_bfi_mode), .bfi_mask(r_bfi_mask), .bfi_delay(r_bfi_delay), .bfi_busy(1'b0),
    .therm_valid_i(1'b0), .therm_code_i(12'd0), .fi_allow_i(1'b0),
    .irq_ctrl_o(ras_irq_ctrl), .irq_host_o(ras_irq_host), .fatal_o(ras_fatal), .contain_o(ras_contain),
    .cc_warn_o(ras_cc_warn), .cc_fatal_o(ras_cc_fatal), .therm_shutdown_o(ras_th), .wdog_reset_req_o(ras_wd),
    .fi_active_o(ras_fia)
  );

  // ======================================================================= check bookkeeping
  int checks = 0, errors = 0;
  string cur_test = "";
  task automatic chk(input bit cond, input string what);
    checks++;
    if (!cond) begin errors++; $display("CHECK FAILED [%s] t=%0t cyc=%0d: %s", cur_test, $time, cyc, what); end
  endtask
  function automatic int m_errors();
    return u_m0.errors + u_m1.errors + u_m2.errors + u_m3.errors;
  endfunction
  function automatic int m_checks();
    return u_m0.checks + u_m1.checks + u_m2.checks + u_m3.checks;
  endfunction

  // ======================================================================= monitors
  // (a) no functional request is accepted by a memory while its group is under test
  int viol_func_under_test = 0;
  always @(posedge clk) if (mem_rst_n) begin
    if (tst_active[0] && |(g_req_valid & g_req_ready)) viol_func_under_test++;
    if (tst_active[1] && mc1_v && mc1_ready)           viol_func_under_test++;
    if (tst_active[2] && mc2_v && mc2_ready)           viol_func_under_test++;
  end
  // (b) raw test-bus activity only while the group is in test ownership / sweeping
  int viol_tst_outside = 0;
  always @(posedge clk) if (rst_n) begin
    for (int g = 0; g < NG; g++) if (tst_ce[g] && !tst_active[g]) viol_tst_outside++;
  end
  // (d) a group is never reported released (sequencer FIN / mode exit) while its memory still
  //     initialises itself after the test (P33 grid: INIT_AFTER_TEST)
  int viol_released_init = 0;
  always @(posedge clk) if (rst_n) begin
    for (int g = 0; g < NG; g++) if (u_ta.g_released[g] && mem_init_busy[g]) viol_released_init++;
  end
  // (c) timeline: per group first / last tst_active cycle, bank order of engine accesses,
  //     quiesce acknowledge -> test-bus ownership ordering
  longint t_first [NG], t_last [NG], t_qack [NG], t_act [NG];
  int     bank_seq [NG][16];
  int     bank_n [NG];
  int     last_bank [NG];
  int     overlap_cycles;
  int     mon_nact, mon_b, mon_cnt;
  task automatic tl_clear();
    for (int g = 0; g < NG; g++) begin
      t_first[g] = -1; t_last[g] = -1; t_qack[g] = -1; t_act[g] = -1; bank_n[g] = 0; last_bank[g] = -1;
    end
    overlap_cycles = 0;
  endtask
  function automatic bit collar_sweeping(input int g);
    if (g == 1) return u_ta.g_grp[1].u_collar.sweeping;
    if (g == 2) return u_ta.g_grp[2].u_collar.sweeping;
    return 1'b0;
  endfunction
  always @(posedge clk) if (rst_n) begin
    mon_nact = 0;
    for (int g = 0; g < NG; g++) begin
      if (quiesce_ack[g] && t_qack[g] < 0) t_qack[g] = cyc;
      if (tst_active[g]) begin
        mon_nact = mon_nact + 1;
        if (t_first[g] < 0) t_first[g] = cyc;
        if (t_act[g] < 0) t_act[g] = cyc;
        t_last[g] = cyc;
      end
      // engine accesses select exactly one bank (a collar sweep selects every bank)
      mon_cnt = 0; mon_b = 0;
      for (int k = 0; k < MAXNB; k++) if (tst_sel[g*MAXNB + k]) begin mon_cnt = mon_cnt + 1; mon_b = k; end
      if (tst_ce[g] && mon_cnt == 1 && !collar_sweeping(g) && mon_b != last_bank[g]) begin
        if (bank_n[g] < 16) bank_seq[g][bank_n[g]] = mon_b;
        bank_n[g] = bank_n[g] + 1;
        last_bank[g] = mon_b;
      end
    end
    if (mon_nact > 1) overlap_cycles = overlap_cycles + 1;
  end

  // (d) functional coverage of the test controller (merged across tests by scripts/regress.py)
  logic [7:0]  cov_own_st  [NG];          // ownership states visited per group
  logic [63:0] cov_own_arc [NG];          // ownership transitions {from, to} per group
  logic [7:0]  cov_seq_ph  [NG];          // sequencer phases visited per group
  logic [15:0] cov_res;                   // sequencer result codes produced
  logic [15:0] cov_ecls;                  // error classes raised
  logic [15:0] cov_vsrc;                  // violation sources logged
  logic [7:0]  cov_mode;                  // test modes entered
  logic [15:0] cov_alg;                   // algorithms started by an engine
  logic [7:0]  cov_eres;                  // engine LAST_TEST_RESULT values produced
  logic [2:0]  cov_prev_st [NG];
  initial begin
    for (int g = 0; g < NG; g++) begin cov_own_st[g] = '0; cov_own_arc[g] = '0; cov_seq_ph[g] = '0; cov_prev_st[g] = '0; end
    cov_res = '0; cov_ecls = '0; cov_vsrc = '0; cov_mode = '0; cov_alg = '0; cov_eres = '0;
  end
  // a reset is not an FSM transition: restart the arc tracking at NORMAL
  always @(negedge rst_n) for (int g = 0; g < NG; g++) cov_prev_st[g] = OWN_NORMAL;
  always @(posedge clk) if (rst_n) begin
    for (int g = 0; g < NG; g++) begin
      logic [2:0] st;
      st = (g == 0) ? u_ta.g_grp[0].u_collar.grp_state : (g == 1) ? u_ta.g_grp[1].u_collar.grp_state
                                                        : u_ta.g_grp[2].u_collar.grp_state;
      cov_own_st[g][st] = 1'b1;
      if (st != cov_prev_st[g]) cov_own_arc[g][{cov_prev_st[g], st}] = 1'b1;
      cov_prev_st[g] = st;
      cov_seq_ph[g][u_ta.u_seq.gs[g*3 +: 3]] = 1'b1;
      if (u_ta.u_seq.res[g*4 +: 4] < 16) cov_res[u_ta.u_seq.res[g*4 +: 4]] = 1'b1;
      if (u_ta.g_ev_done[g]) cov_eres[u_ta.g_last[g*3 +: 3]] = 1'b1;
    end
    if (u_ta.g_grp[0].u_ctrl.e_start && u_ta.mbist_enable) cov_alg[u_ta.g_grp[0].u_ctrl.e_algo] = 1'b1;
    if (u_ta.g_grp[1].u_ctrl.e_start && u_ta.mbist_enable) cov_alg[u_ta.g_grp[1].u_ctrl.e_algo] = 1'b1;
    if (u_ta.g_grp[2].u_ctrl.e_start && u_ta.mbist_enable) cov_alg[u_ta.g_grp[2].u_ctrl.e_algo] = 1'b1;
    cov_ecls = cov_ecls | 16'(u_ta.u_regs.cls_hit);
    if (u_ta.ev_v) cov_vsrc[u_ta.ev_v_src] = 1'b1;
    cov_mode[mode] = 1'b1;
  end
  task automatic cov_report();
    for (int g = 0; g < NG; g++)
      $display("COV own_state g=%0d %02h own_arc g=%0d %016h seq_phase g=%0d %02h", g, cov_own_st[g], g, cov_own_arc[g],
               g, cov_seq_ph[g]);
    $display("COV seq_result %04h error_class %04h viol_src %04h mode %02h algorithm %04h engine_result %02h",
             cov_res, cov_ecls, cov_vsrc, cov_mode, cov_alg, cov_eres);
  endtask

  // ======================================================================= register access helpers
  task automatic bus(input bit we, input bit priv, input logic [11:0] a, input logic [31:0] d,
                     output logic [31:0] rd, output logic err);
    @(negedge clk);
    s_req = 1'b1; s_we = we; s_priv = priv; s_addr = a; s_wdata = d;
    #1;
    while (!s_gnt) begin @(negedge clk); #1; end
    rd = s_rdata; err = s_err;
    @(posedge clk); #1;
    s_req = 1'b0; s_we = 1'b0;
  endtask
  task automatic cpu_wr(input logic [11:0] a, input logic [31:0] d);
    logic [31:0] rd; logic e;
    bus(1'b1, 1'b1, a, d, rd, e);
    chk(!e, $sformatf("CPU write %03h = %08h returned an error", a, d));
  endtask
  task automatic cpu_rd(input logic [11:0] a, output logic [31:0] rd);
    logic e;
    bus(1'b0, 1'b1, a, 32'd0, rd, e);
    chk(!e, $sformatf("CPU read %03h returned an error", a));
  endtask
  function automatic logic [11:0] ta(input logic [8:0] off);  return {3'd0, off}; endfunction
  function automatic logic [11:0] pg(input int g, input logic [11:0] off); return 12'((g + 1) << 9) | off; endfunction

  task automatic wait_reg(input logic [11:0] a, input logic [31:0] mask, input logic [31:0] val,
                          input int max_cyc, input string what, output logic [31:0] rd);
    int n;
    n = 0;
    cpu_rd(a, rd);
    while ((rd & mask) != val && n < max_cyc) begin
      repeat (16) @(posedge clk);
      n += 17;
      cpu_rd(a, rd);
    end
    chk((rd & mask) == val, $sformatf("timeout waiting for %s (reg %03h = %08h)", what, a, rd));
  endtask

  // ---------------------------------------------------------------- RAS helpers
  task automatic ras_rd(input logic [11:0] a, output logic [31:0] rd);
    @(negedge clk); rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a; #1; rd = rb_rdata;
    @(posedge clk); #1 rb_sel = 1'b0;
  endtask
  task automatic ras_wr(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk); rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d;
    @(posedge clk); #1 rb_sel = 1'b0; rb_we = 1'b0;
  endtask
  logic [3:0]  rl_typ  [64];
  logic [1:0]  rl_sev  [64];
  logic        rl_av   [64];
  logic [31:0] rl_addr [64];
  logic [31:0] rl_info [64];
  int          rl_n = 0;
  task automatic ras_clear(); rl_n = 0; endtask
  task automatic ras_drain();
    logic [31:0] st, src, a, inf;
    repeat (20) @(posedge clk);
    ras_rd(`SFRAS_R_LOG_STAT, st);
    for (int i = 0; i < int'(st[15:0]); i++) begin
      ras_rd(`SFRAS_R_LOG_SRC, src); ras_rd(`SFRAS_R_LOG_ADDR, a); ras_rd(`SFRAS_R_LOG_INFO, inf);
      chk(src[7:0] == 8'd0, "RAS record source is not external port 0 (test access)");
      if (rl_n < 64) begin
        rl_typ[rl_n] = src[11:8]; rl_sev[rl_n] = src[13:12]; rl_av[rl_n] = src[15]; rl_addr[rl_n] = a; rl_info[rl_n] = inf;
      end
      rl_n = rl_n + 1;
      ras_wr(`SFRAS_R_LOG_POP, 32'd1);
    end
  endtask
  function automatic int ras_count(input logic [3:0] typ, input int cls, input int grp);
    int n;
    n = 0;
    for (int i = 0; i < rl_n && i < 64; i++)
      if (rl_typ[i] == typ && (cls < 0 || rl_info[i][27:24] == 4'(cls)) && (grp < 0 || rl_info[i][23:16] == 8'(grp))) n++;
    return n;
  endfunction

  // ---------------------------------------------------------------- JTAG driver
  real tck_half = 23.0;
  task automatic clk_tck(input bit t, input bit d, output bit o);
    tms = t; tdi = d;
    #(tck_half);
    o = tdo;
    tck = 1'b1;
    #(tck_half);
    tck = 1'b0;
    #1;
  endtask
  task automatic j_tlr();  bit o; repeat (5) clk_tck(1, 0, o); endtask
  task automatic j_rti();  bit o; clk_tck(0, 0, o); endtask
  task automatic j_idle(input int n); bit o; repeat (n) clk_tck(0, 0, o); endtask
  task automatic j_ir(input logic [4:0] v, output logic [4:0] cap);
    bit o;
    clk_tck(1, 0, o); clk_tck(1, 0, o); clk_tck(0, 0, o); clk_tck(0, 0, o);
    for (int i = 0; i < 5; i++) begin clk_tck(i == 4, v[i], o); cap[i] = o; end
    clk_tck(1, 0, o); clk_tck(0, 0, o);
  endtask
  task automatic j_dr(input int n, input logic [63:0] v, output logic [63:0] cap);
    bit o;
    cap = '0;
    clk_tck(1, 0, o); clk_tck(0, 0, o); clk_tck(0, 0, o);
    for (int i = 0; i < n; i++) begin clk_tck(i == n - 1, v[i], o); cap[i] = o; end
    clk_tck(1, 0, o); clk_tck(0, 0, o);
  endtask
  task automatic j_reg_read(input logic [11:0] a, output logic [1:0] st, output logic [31:0] rd);
    logic [63:0] cap;
    j_ir(IR_TC_REG, cap[4:0]);
    j_dr(REG_DR_LEN, {18'd0, REGOP_READ, a, 32'd0}, cap);
    j_idle(12);
    j_dr(REG_DR_LEN, {18'd0, REGOP_NOP, 12'd0, 32'd0}, cap);
    st = cap[45:44]; rd = cap[31:0];
  endtask
  task automatic j_reg_write(input logic [11:0] a, input logic [31:0] d, output logic [1:0] st);
    logic [63:0] cap;
    j_ir(IR_TC_REG, cap[4:0]);
    j_dr(REG_DR_LEN, {18'd0, REGOP_WRITE, a, d}, cap);
    j_idle(12);
    j_dr(REG_DR_LEN, {18'd0, REGOP_NOP, 12'd0, 32'd0}, cap);
    st = cap[45:44];
  endtask
  task automatic j_idcode(output logic [31:0] id);
    logic [63:0] cap; logic [4:0] c;
    j_ir(IR_IDCODE, c);
    j_dr(32, 64'd0, cap);
    id = cap[31:0];
  endtask

  // ---------------------------------------------------------------- fault injection (generic SRAM hooks)
  event fl_ev;
  int fl_g, fl_b, fl_kind, fl_addr, fl_bit, fl_addr2, fl_bit2;
  for (genvar b = 0; b < 4; b++) begin : g_flt0
    always @(fl_ev) if (fl_g == 0 && fl_b == b) begin
      u_grid.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.flt_kind  = fl_kind;
      u_grid.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.flt_addr  = fl_addr;
      u_grid.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.flt_bit   = fl_bit;
      u_grid.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.flt_addr2 = fl_addr2;
      u_grid.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.flt_bit2  = fl_bit2;
    end
  end
  for (genvar b = 0; b < 4; b++) begin : g_flt1
    always @(fl_ev) if (fl_g == 1 && fl_b == b) begin
      u_mc1.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_kind  = fl_kind;
      u_mc1.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_addr  = fl_addr;
      u_mc1.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_bit   = fl_bit;
      u_mc1.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_addr2 = fl_addr2;
      u_mc1.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_bit2  = fl_bit2;
    end
  end
  for (genvar b = 0; b < 2; b++) begin : g_flt2
    always @(fl_ev) if (fl_g == 2 && fl_b == b) begin
      u_mc2.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_kind  = fl_kind;
      u_mc2.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_addr  = fl_addr;
      u_mc2.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_bit   = fl_bit;
      u_mc2.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_addr2 = fl_addr2;
      u_mc2.u_bc.g_bank[b].u_bank.g_generic.u_mem.flt_bit2  = fl_bit2;
    end
  end
  task automatic inject(input int g, input int b, input int kind, input int a, input int bt,
                        input int a2, input int bt2);
    fl_g = g; fl_b = b; fl_kind = kind; fl_addr = a; fl_bit = bt; fl_addr2 = a2; fl_bit2 = bt2;
    -> fl_ev;
    #1;
  endtask
  task automatic clear_faults();
    for (int g = 0; g < NG; g++) for (int b = 0; b < 4; b++) inject(g, b, 0, 0, 0, 0, 0);
  endtask

  // ======================================================================= scenario helpers
  task automatic set_lc(input logic v, input logic [3:0] s, input logic dbg, input logic tm, input logic ift);
    lc_valid = v; lc_state = s; sb_debug_en = dbg; sb_test_mode_en = tm; otp_ift_en = ift;
  endtask
  task automatic set_lc_std(input logic [3:0] s, input logic ift);
    set_lc(1'b1, s, s == TA_LC_DEV, s == TA_LC_DEV, ift);
  endtask

  // full reset of test access, memories and JTAG; waits for initialisation
  task automatic sys_reset();
    m_en = 1'b0; m_rogue = '0; m_noack = '0; cpu_halted = 1'b0;
    scan_mode_pin = 1'b0; scan_en_pin = 1'b0; test_rst_n_pin = 1'b1;
    s_req = 1'b0; rb_sel = 1'b0;
    clear_faults();
    #3; rst_n = 1'b0; mem_rst_n = 1'b0; trst_n = 1'b0;
    repeat (5) @(posedge clk);
    #2; rst_n = 1'b1; mem_rst_n = 1'b1; trst_n = 1'b1;
    wait_init();
    u_m0.clear_stats(); u_m1.clear_stats(); u_m2.clear_stats(); u_m3.clear_stats();
    ras_clear();
  endtask
  task automatic wait_init();
    int n;
    n = 0;
    while ((mem_ready !== 3'b111 || g_init_busy !== 1'b0 || |tst_active) && n < 20000) begin @(posedge clk); n++; end
    chk(mem_ready === 3'b111 && !g_init_busy, "memories did not finish initialisation");
    repeat (4) @(posedge clk);
  endtask

  task automatic enter_mode(input logic [2:0] m, input bit expect_ok);
    logic [31:0] rd;
    if (m == MODE_MBIST) cpu_wr(ta(TA_R_UNLOCK), TC_UNLOCK_KEY);
    cpu_wr(ta(TA_R_MODE_CTRL), 32'(m));
    repeat (4) @(posedge clk);
    cpu_rd(ta(TA_R_MODE_STATUS), rd);
    if (expect_ok) chk(rd[2:0] == m, $sformatf("mode %0d not entered (MODE_STATUS %08h)", m, rd));
    else           chk(rd[2:0] != m, $sformatf("mode %0d entered although not permitted", m));
  endtask
  task automatic leave_mbist();
    logic [31:0] rd;
    cpu_wr(ta(TA_R_MODE_CTRL), 32'(MODE_NORMAL));
    wait_reg(ta(TA_R_MODE_STATUS), 32'h0000_000F, 32'(MODE_NORMAL), 200000, "MBIST exit", rd);
  endtask

  // run one group test through its page; returns TEST_STATUS
  task automatic page_test(input int g, input logic [3:0] mask, input logic [3:0] alg, input bit scrub,
                           output logic [31:0] st);
    logic [31:0] rd;
    cpu_wr(pg(g, R_BANK_MASK), 32'(mask));
    wait_reg(pg(g, R_OWNER_STATUS), 32'h0000_0007, 32'(OWN_TEST_ACTIVE), 20000, "group acquisition", rd);
    cpu_wr(pg(g, R_TEST_CONTROL), (32'(scrub) << 10) | (32'(alg) << 4) | 32'h1);
    repeat (4) @(posedge clk);
    wait_reg(pg(g, R_TEST_STATUS), 32'h0000_0003, 32'h0000_0002, 2000000, "group test done", st);
    cpu_wr(pg(g, R_BANK_MASK), 32'd0);                         // release
    wait_reg(pg(g, R_OWNER_STATUS), 32'h0000_0007, 32'(OWN_NORMAL), 20000, "group release", rd);
    wait_released(g);
  endtask
  task automatic wait_released(input int g);
    int n;
    n = 0;
    while (!u_ta.g_released[g] && n < 50000) begin @(posedge clk); n++; end
    chk(u_ta.g_released[g], $sformatf("group %0d not released", g));
  endtask

  // run the sequencer; returns SEQ_STATUS and SEQ_RESULT
  task automatic seq_run(input logic [2:0] groups, input bit par, input logic [3:0] alg, input logic [31:0] wdog,
                         output logic [31:0] st, output logic [31:0] res);
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'(groups));
    cpu_wr(ta(TA_R_WDOG_LIMIT), wdog);
    cpu_wr(ta(TA_R_SEQ_CTRL), (32'(alg) << 8) | (32'(par) << TA_SEQ_PARALLEL) | 32'h1);
    repeat (4) @(posedge clk);
    wait_reg(ta(TA_R_SEQ_STATUS), 32'h0000_0003, 32'h0000_0002, 4000000, "sequence done", st);
    // black-box contract: DONE means every memory can serve functional traffic again
    chk(mem_ready === 3'b111 && !g_init_busy, "sequence done while a memory is still initialising");
    cpu_rd(ta(TA_R_SEQ_RESULT), res);
  endtask

  // functional traffic for n cycles, then drain
  task automatic traffic(input int n);
    m_en = 1'b1;
    repeat (n) @(posedge clk);
    m_en = 1'b0;
    repeat (40) @(posedge clk);
  endtask

  // closed-form March C- cycle count (TestCore model: read = 1 + L, write = 1; +scrub N; +11 overhead)
  function automatic int march_cycles(input int n, input int l, input bit scrub);
    return 5 * n * (2 + l) + (scrub ? n : 0) + 11;
  endfunction

  task automatic finish_test();
    int me, mc;
    me = m_errors(); mc = m_checks();
    chk(viol_func_under_test == 0, $sformatf("%0d functional acceptances while a group was under test", viol_func_under_test));
    chk(viol_tst_outside == 0, $sformatf("%0d raw test accesses outside tst_active", viol_tst_outside));
    chk(viol_released_init == 0, $sformatf("%0d cycles with a group released while its memory initialises",
                                           viol_released_init));
    $display("TEST %s RESULT %s checks=%0d errors=%0d master_checks=%0d master_errors=%0d",
             cur_test, (errors + me == 0) ? "PASS" : "FAIL", checks + mc, errors + me, mc, me);
    total_fail += (errors + me != 0);
    total_tests++;
    checks = 0; errors = 0; viol_func_under_test = 0; viol_tst_outside = 0; viol_released_init = 0;
  endtask
  int total_fail = 0, total_tests = 0;

  // ======================================================================= tests
  `include "tb_ta_tests.svh"

  initial begin
    string sel;
    if (!$value$plusargs("TEST=%s", sel)) sel = "all";
    $display("tb_ta_sys: TEST=%s", sel);
    tl_clear();
    if (sel == "all" || sel == "jtag_tap")        begin cur_test = "jtag_tap";        t_jtag_tap();        finish_test(); end
    if (sel == "all" || sel == "lc_policy")       begin cur_test = "lc_policy";       t_lc_policy();       finish_test(); end
    if (sel == "all" || sel == "mbist_select")    begin cur_test = "mbist_select";    t_mbist_select();    finish_test(); end
    if (sel == "all" || sel == "algorithms")      begin cur_test = "algorithms";      t_algorithms();      finish_test(); end
    if (sel == "all" || sel == "func_switch")     begin cur_test = "func_switch";     t_func_switch();     finish_test(); end
    if (sel == "all" || sel == "faults")          begin cur_test = "faults";          t_faults();          finish_test(); end
    if (sel == "all" || sel == "ordering")        begin cur_test = "ordering";        t_ordering();        finish_test(); end
    if (sel == "all" || sel == "timeout")         begin cur_test = "timeout";         t_timeout();         finish_test(); end
    if (sel == "all" || sel == "reset_in_test")   begin cur_test = "reset_in_test";   t_reset_in_test();   finish_test(); end
    if (sel == "all" || sel == "secure_debug")    begin cur_test = "secure_debug";    t_secure_debug();    finish_test(); end
    if (sel == "all" || sel == "error_prop")      begin cur_test = "error_prop";      t_error_prop();      finish_test(); end
    if (sel == "all" || sel == "recovery")        begin cur_test = "recovery";        t_recovery();        finish_test(); end
    if (sel == "all" || sel == "abort_protect")   begin cur_test = "abort_protect";   t_abort_protect();   finish_test(); end
    if (sel == "all" || sel == "dft_clkrst")      begin cur_test = "dft_clkrst";      t_dft_clkrst();      finish_test(); end
    cov_report();
    $display("TB_TA_SYS SUMMARY tests=%0d failed=%0d", total_tests, total_fail);
    $finish;
  end

  initial begin
    longint lim;
    if (!$value$plusargs("MAXCYC=%d", lim)) lim = 64'd60_000_000;
    wait (cyc > lim);
    $display("TB_TA_SYS TIMEOUT at cycle %0d (test %s)", cyc, cur_test);
    $display("TEST %s RESULT FAIL checks=%0d errors=%0d (simulation timeout)", cur_test, checks, errors + 1);
    $finish;
  end
endmodule

`default_nettype wire
