// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: tb_ta_clktree      (SIMULATION ONLY)
// Clock / reset test-mode integration: silicaflux_test_access + the REAL
// Project 35 silicaflux_clock_reset_tree (simulation technology cells).
//   TA clock = clk_core_o (root-gated core clock), TA reset = fab_rst_no;
//   one memory group whose memory model runs on gated branch 0 (clk_br_o[0]);
//   TA dft_test_mode / dft_icg_te / dft_test_rst_n -> P35 test_mode_i /
//   test_en_i / test_rst_ni;  TA mbist_clk_req[0] -> P35 br_clk_req_i[0].
// Checks: (A) software gates both branches; (B) an MBIST session on the
// group re-enables only its branch, passes, and the branch gates again after
// release; (C) DEV + TEST_MODE: every ICG opens and every domain reset follows
// TEST_RST_N; (D) PROD + TEST_MODE: nothing changes (no bypass).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_ta_clktree;
  `include "sftc_consts.svh"
  `include "sfta_consts.svh"

  logic clk_ref = 1'b0, clk_core = 1'b0;
  always #20 clk_ref = ~clk_ref;
  always #5  clk_core = ~clk_core;
  logic por_n = 1'b1, pll_lock = 1'b1;          // first edge in boot()
  logic trst_n = 1'b1;                           // TRST* AND POR (TAP reset)

  // ---------------------------------------------------------------- P35 clock / reset tree
  localparam int NB = 2;
  wire clk_core_o, fab_rst_n, cc_rst_n, mc_rst_n, sys_ready, mc_ready, wdog_irq, fab_q;
  wire [NB-1:0] clk_br, br_ce, br_rst_n, br_q;
  wire [3:0] seq_state;
  logic rb_sel = 1'b0, rb_we = 1'b0;
  logic [7:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0;
  wire [31:0] rb_rdata;
  wire rb_err;
  wire dft_test_mode, dft_icg_te, dft_scan_en, dft_test_rst_n, dft_mem_inhibit;
  wire [0:0] mbist_clk_req;
  silicaflux_clock_reset_tree #(.NB(NB), .NW(2)) u_crt (
    .clk_ref_i(clk_ref), .clk_core_i(clk_core), .clk_mc_i(1'b0), .por_ni(por_n), .ext_rst_ni(1'b1),
    .pll_lock_i(pll_lock), .test_mode_i(dft_test_mode), .test_rst_ni(dft_test_rst_n), .test_en_i(dft_icg_te),
    .clk_core_o, .clk_br_o(clk_br), .clk_br_ce_o(br_ce), .fab_rst_no(fab_rst_n), .cc_rst_no(cc_rst_n),
    .br_rst_no(br_rst_n), .mc_rst_no(mc_rst_n), .fab_quiesce_o(fab_q), .fab_idle_i(1'b1), .br_quiesce_o(br_q),
    .br_idle_i({NB{1'b1}}), .br_clk_req_i({1'b0, mbist_clk_req[0]}), .br_wake_i('0), .wdog_req_i(2'b00),
    .wdog_irq_o(wdog_irq), .sys_ready_o(sys_ready), .mc_ready_o(mc_ready),
    .rb_sel_i(rb_sel), .rb_we_i(rb_we), .rb_addr_i(rb_addr), .rb_wdata_i(rb_wdata), .rb_rdata_o(rb_rdata),
    .rb_err_o(rb_err), .seq_state_o(seq_state)
  );

  // ---------------------------------------------------------------- test access (1 group, 2 banks x 16 x 8)
  logic lc_valid = 1'b1, dbg = 1'b1;
  logic [3:0] lc_state = TA_LC_DEV;
  logic scan_pin = 1'b0, scan_en_pin = 1'b0, test_rst_pin = 1'b1;
  logic s_req = 1'b0, s_we = 1'b0;
  logic [11:0] s_addr = '0;
  logic [31:0] s_wdata = '0;
  wire s_gnt, s_err;
  wire [31:0] s_rdata;
  wire [0:0] quiesce_req, f_block, mem_ready, tst_active, tst_ce, tst_we;
  wire [1:0] tst_sel;
  wire [3:0] tst_addr;
  wire [7:0] tst_wdata;
  logic [15:0] tst_rdata;
  wire tdo, tdo_oe, dbg_allow, jtag_mode, diag_mode, ras_v, ras_av, ras_c, irq, t_done, t_pass, t_fail;
  wire [3:0] ras_t; wire [31:0] ras_a, ras_i; wire [2:0] mode;
  silicaflux_test_access #(
    .NG(1), .MAXNB(2), .MAXSW(8), .MAXRAW(4), .G_NB(8'd2), .G_SW(16'd8), .G_DEPTH(24'd16), .G_LAT(4'd1),
    .G_INIT(4'd1), .G_INIT_ON_RESET(1'b0), .G_INIT_WORD(8'h00), .G_KIND(4'd1), .OWN_TIMEOUT(64)
  ) u_ta (
    .tck(1'b0), .trst_n(trst_n), .tms(1'b1), .tdi(1'b0), .tdo, .tdo_oe, .clk(clk_core_o), .rst_n(fab_rst_n),
    .lc_valid, .lc_state, .sb_debug_en(dbg), .sb_test_mode_en(dbg), .otp_ift_en(1'b0),
    .scan_mode_pin(scan_pin), .scan_en_pin, .test_rst_n_pin(test_rst_pin), .cpu_halted(1'b0),
    .s_req, .s_we, .s_priv(1'b1), .s_addr, .s_wdata, .s_gnt, .s_rdata, .s_err,
    .quiesce_req, .quiesce_ack(quiesce_req), .f_busy(1'b0), .f_req(1'b0), .f_block, .mem_init_busy(1'b0), .mem_ready,
    .tst_active, .tst_sel, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata,
    .dft_test_mode, .dft_icg_te, .dft_scan_en, .dft_test_rst_n, .dft_mem_inhibit, .mbist_clk_req,
    .dbg_allow, .jtag_mode, .diag_mode, .ras_ev_valid(ras_v), .ras_ev_type(ras_t), .ras_ev_addr(ras_a),
    .ras_ev_addr_v(ras_av), .ras_ev_info(ras_i), .ras_ev_corr(ras_c), .irq, .mode, .test_done(t_done),
    .test_pass(t_pass), .test_fail(t_fail)
  );

  // ---------------------------------------------------------------- memory model on gated branch 0 (raw test port, latency 1)
  logic [7:0] mem [2][16];
  always @(posedge clk_br[0]) begin
    for (int b = 0; b < 2; b++) begin
      if (tst_ce[0] && tst_sel[b]) begin
        if (tst_we[0]) mem[b][tst_addr] <= tst_wdata;
        else           tst_rdata[b*8 +: 8] <= mem[b][tst_addr];
      end
    end
  end

  // ---------------------------------------------------------------- helpers
  int checks = 0, errors = 0;
  task automatic chk(input bit c, input string w);
    checks++;
    if (!c) begin errors++; $display("CHECK FAILED t=%0t: %s", $time, w); end
  endtask
  int edges0 = 0, edges1 = 0;
  always @(posedge clk_br[0]) edges0++;
  always @(posedge clk_br[1]) edges1++;
  task automatic crt_wr(input logic [7:0] a, input logic [31:0] d);
    @(negedge clk_core_o); rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d;
    @(posedge clk_core_o); #1 rb_sel = 1'b0; rb_we = 1'b0;
  endtask
  task automatic ta_bus(input bit we, input logic [11:0] a, input logic [31:0] d, output logic [31:0] rd);
    @(negedge clk_core_o); s_req = 1'b1; s_we = we; s_addr = a; s_wdata = d; #1; rd = s_rdata;
    @(posedge clk_core_o); #1 s_req = 1'b0; s_we = 1'b0;
  endtask
  task automatic count_edges(input int ncore, output int e0, output int e1);
    int a0, a1;
    a0 = edges0; a1 = edges1;
    repeat (ncore) @(posedge clk_core);
    e0 = edges0 - a0; e1 = edges1 - a1;
  endtask
  task automatic boot();
    #3 por_n = 1'b0; trst_n = 1'b0;
    repeat (10) @(posedge clk_ref);
    por_n = 1'b1; trst_n = 1'b1;
    wait (sys_ready);
    repeat (20) @(posedge clk_core);
  endtask

  initial begin
    int e0, e1, n;
    logic [31:0] rd;
    // ---------------------------------------------------------------- (A) software gates both branches
    boot();
    count_edges(50, e0, e1);
    chk(e0 > 40 && e1 > 40, $sformatf("branches not running after boot (%0d, %0d)", e0, e1));
    crt_wr(sf_crt_pkg::R_CLK_EN, 32'h0);
    repeat (10) @(posedge clk_core);
    count_edges(100, e0, e1);
    chk(e0 == 0 && e1 == 0, $sformatf("branches not gated by software (%0d, %0d edges)", e0, e1));
    // ---------------------------------------------------------------- (B) MBIST session re-enables branch 0 only
    ta_bus(1, {3'd0, TA_R_UNLOCK}, TC_UNLOCK_KEY, rd);
    ta_bus(1, {3'd0, TA_R_MODE_CTRL}, MODE_MBIST, rd);
    ta_bus(1, 12'h200 | R_BANK_MASK, 32'h3, rd);
    n = 0;
    do begin repeat (4) @(posedge clk_core); ta_bus(0, 12'h200 | R_OWNER_STATUS, 0, rd); n++; end
    while (rd[2:0] != OWN_TEST_ACTIVE && n < 200);
    chk(rd[2:0] == OWN_TEST_ACTIVE, "group not acquired");
    chk(mbist_clk_req[0], "no clock request while the group is owned");
    ta_bus(1, 12'h200 | R_TEST_CONTROL, 32'h1, rd);
    e1 = edges1;
    n = 0;
    do begin repeat (16) @(posedge clk_core); ta_bus(0, 12'h200 | R_TEST_STATUS, 0, rd); n++; end
    while (!rd[1] && n < 2000);
    chk(rd[1] && rd[2] && !rd[3], $sformatf("MBIST on the gated branch did not pass (TEST_STATUS %08h)", rd));
    chk(edges1 == e1, "branch 1 clock ran during the group-0 session");
    ta_bus(1, 12'h200 | R_BANK_MASK, 32'h0, rd);
    n = 0;
    while (mbist_clk_req[0] && n < 500) begin @(posedge clk_core); n++; end
    chk(!mbist_clk_req[0], "clock request not withdrawn after release");
    repeat (10) @(posedge clk_core);
    count_edges(100, e0, e1);
    chk(e0 == 0 && e1 == 0, $sformatf("branches not gated again after the session (%0d, %0d)", e0, e1));
    ta_bus(1, {3'd0, TA_R_MODE_CTRL}, MODE_NORMAL, rd);
    repeat (20) @(posedge clk_core);
    // ---------------------------------------------------------------- (C) DEV + TEST_MODE: ICGs open, resets from TEST_RST_N
    @(negedge clk_core); scan_pin = 1'b1; scan_en_pin = 1'b1; test_rst_pin = 1'b1;
    #1;
    chk(dft_test_mode && dft_icg_te, "DEV: TEST_MODE pin not honoured");
    count_edges(50, e0, e1);
    chk(e0 > 40 && e1 > 40, $sformatf("DEV scan: ICGs not transparent (%0d, %0d edges)", e0, e1));
    @(negedge clk_core); test_rst_pin = 1'b0; #2;
    chk(!fab_rst_n && !cc_rst_n && br_rst_n == '0, "DEV scan: domain resets do not follow TEST_RST_N = 0");
    @(negedge clk_core); test_rst_pin = 1'b1; #2;
    chk(fab_rst_n && cc_rst_n && br_rst_n == '1, "DEV scan: domain resets do not follow TEST_RST_N = 1");
    @(negedge clk_core); scan_pin = 1'b0; scan_en_pin = 1'b0;
    // ---------------------------------------------------------------- (D) PROD + TEST_MODE: no bypass
    lc_state = TA_LC_PROD; dbg = 1'b0;
    boot();
    crt_wr(sf_crt_pkg::R_CLK_EN, 32'h0);
    repeat (10) @(posedge clk_core);
    @(negedge clk_core); scan_pin = 1'b1; scan_en_pin = 1'b1; test_rst_pin = 1'b0;
    #2;
    chk(!dft_test_mode && !dft_icg_te && dft_test_rst_n, "PROD: TEST_MODE pin reached the clock / reset tree");
    count_edges(100, e0, e1);
    chk(e0 == 0 && e1 == 0, $sformatf("PROD scan pin opened gated branches (%0d, %0d)", e0, e1));
    chk(fab_rst_n && cc_rst_n, "PROD: TEST_RST_N pin reset the domains");
    @(negedge clk_core); scan_pin = 1'b0; scan_en_pin = 1'b0; test_rst_pin = 1'b1;
    $display("TEST ta_clktree RESULT %s checks=%0d errors=%0d", errors == 0 ? "PASS" : "FAIL", checks, errors);
    $finish;
  end
  initial begin #20ms; $display("TEST ta_clktree RESULT FAIL (timeout)"); $finish; end
endmodule
`default_nettype wire
