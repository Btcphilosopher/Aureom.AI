// =============================================================================
// SilicaFlux DFTGRID (Project 39) :: tb_ta_tests.svh   (included by tb_ta_sys)
// Scenario tasks.  Each starts from sys_reset() and leaves the DUT idle.
// =============================================================================

  // ---------------------------------------------------------------- helpers
  task automatic j_drlen(output int len);
    bit o;
    clk_tck(1, 0, o); clk_tck(0, 0, o); clk_tck(0, 0, o);
    for (int i = 0; i < 80; i++) clk_tck(0, 0, o);
    clk_tck(0, 1, o);
    len = -1;
    for (int i = 1; i <= 80 && len < 0; i++) begin clk_tck(0, 0, o); if (o) len = i; end
    clk_tck(1, 0, o); clk_tck(1, 0, o); clk_tck(0, 0, o);
  endtask
  function automatic int nib(input logic [31:0] v, input int g); return int'(v[g*4 +: 4]); endfunction
  function automatic longint t_act_q(input int g); return t_act[g]; endfunction
  task automatic chk_bankseq(input int g, input int n, input int b0, input int b1, input int b2, input int b3);
    int e [4];
    e[0] = b0; e[1] = b1; e[2] = b2; e[3] = b3;
    chk(bank_n[g] == n, $sformatf("group %0d: %0d bank switches, expected %0d", g, bank_n[g], n));
    for (int i = 0; i < n && i < bank_n[g]; i++)
      chk(bank_seq[g][i] == e[i], $sformatf("group %0d bank order[%0d] = %0d, expected %0d", g, i, bank_seq[g][i], e[i]));
  endtask

  // ================================================================ 1. JTAG TAP
  task automatic t_jtag_tap();
    logic [4:0] c;
    logic [63:0] cap;
    logic [31:0] id, rd;
    logic [1:0] st;
    int len, ref_st, n_states, n_arcs;
    bit o;
    bit vis [16];
    bit arc [32];
    set_lc_std(TA_LC_DEV, 1'b1); sys_reset();
    chk(u_ta.tap_state == TAP_TLR, "TAP not in Test-Logic-Reset after TRST*");
    chk(u_ta.ir == IR_IDCODE, "IR not IDCODE after reset");
    // random walk against the reference next-state function until every state / arc is covered
    for (int i = 0; i < 16; i++) vis[i] = 0;
    for (int i = 0; i < 32; i++) arc[i] = 0;
    ref_st = TAP_TLR; vis[TAP_TLR] = 1;
    for (int i = 0; i < 4000; i++) begin
      bit t;
      t = ($urandom % 3) == 0;
      arc[ref_st * 2 + int'(t)] = 1;
      clk_tck(t, 1'b0, o);
      ref_st = int'(tap_next(4'(ref_st), t));
      vis[ref_st] = 1;
      chk(int'(u_ta.tap_state) == ref_st, $sformatf("TAP state %0d != reference %0d", u_ta.tap_state, ref_st));
      chk(tdo_oe == (ref_st == TAP_SH_DR || ref_st == TAP_SH_IR), "TDO enable does not match the shift states");
    end
    n_states = 0; n_arcs = 0;
    for (int i = 0; i < 16; i++) n_states += vis[i];
    for (int i = 0; i < 32; i++) n_arcs += arc[i];
    chk(n_states == 16, $sformatf("TAP state coverage %0d/16", n_states));
    chk(n_arcs == 32, $sformatf("TAP arc coverage %0d/32", n_arcs));
    $display("COVERAGE tap_states=%0d/16 tap_arcs=%0d/32", n_states, n_arcs);
    // TLR from any state with 5 x TMS = 1, then IDCODE selected by default
    j_tlr();
    chk(u_ta.tap_state == TAP_TLR, "5 x TMS=1 did not reach TLR");
    j_rti();
    j_dr(32, 64'd0, cap);
    chk(cap[31:0] == IDCODE_VALUE, $sformatf("default DR after TLR: %08h, expected IDCODE %08h", cap[31:0], IDCODE_VALUE));
    // IR capture value (1149.1: LSBs 01)
    j_ir(IR_BYPASS, c);
    chk(c == IR_CAPTURE, $sformatf("IR capture %b, expected %b", c, IR_CAPTURE));
    // BYPASS: one-bit delay
    j_dr(16, 64'h0000_0000_0000_B5A3, cap);
    chk(cap[15:0] == 16'(64'hB5A3 << 1), $sformatf("BYPASS shift %h", cap[15:0]));
    // DR lengths
    j_ir(IR_IDCODE, c);     j_drlen(len); chk(len == 32, $sformatf("IDCODE DR length %0d", len));
    j_ir(IR_BYPASS, c);     j_drlen(len); chk(len == 1,  $sformatf("BYPASS DR length %0d", len));
    j_ir(IR_TC_REG, c);     j_drlen(len); chk(len == REG_DR_LEN, $sformatf("TC_REG DR length %0d", len));
    j_ir(IR_TC_STATUS, c);  j_drlen(len); chk(len == 8,  $sformatf("TC_STATUS DR length %0d", len));
    j_ir(IR_EXTEST, c);     j_drlen(len); chk(len == 1,  $sformatf("EXTEST (reserved -> BYPASS) DR length %0d", len));
    j_ir(IR_SAMPLE, c);     j_drlen(len); chk(len == 1,  $sformatf("SAMPLE (reserved -> BYPASS) DR length %0d", len));
    j_ir(5'h07, c);         j_drlen(len); chk(len == 1,  $sformatf("unassigned opcode DR length %0d", len));
    // IDCODE instruction
    j_idcode(id);
    chk(id == IDCODE_VALUE, $sformatf("IDCODE %08h", id));
    // TC_STATUS signature
    j_ir(IR_TC_STATUS, c); j_dr(8, 64'd0, cap); j_dr(8, 64'd0, cap);
    chk(cap[7:4] == 4'h7 && cap[3] == 1'b0 && cap[2] == 1'b1, $sformatf("TC_STATUS %02h", cap[7:0]));
    // register access through the CDC bridge (DEV)
    j_reg_read(ta(TA_R_ID), st, rd);
    chk(st == REGST_OK && rd == TA_ID_VALUE, $sformatf("JTAG read TA_ID: st %0d data %08h", st, rd));
    j_reg_write(ta(TA_R_SCRATCH), 32'hC0DE_1234, st);
    chk(st == REGST_OK, "JTAG write SCRATCH status");
    cpu_rd(ta(TA_R_SCRATCH), rd);
    chk(rd == 32'hC0DE_1234, $sformatf("SCRATCH written by JTAG reads %08h by CPU", rd));
    j_reg_read(pg(1, R_REVISION), st, rd);
    chk(st == REGST_OK && rd == TC_REVISION, $sformatf("JTAG read group-1 TestCore REVISION %08h", rd));
    j_reg_read(12'hE00, st, rd);
    chk(st == REGST_ERR, "JTAG read of an unmapped page did not return ERROR");
    // TRST* asynchronously resets the TAP from any state
    j_ir(IR_TC_REG, c); clk_tck(1, 0, o); clk_tck(0, 0, o); clk_tck(0, 0, o);   // Shift-DR
    #7 trst_n = 1'b0; #11;
    chk(u_ta.tap_state == TAP_TLR && u_ta.ir == IR_IDCODE, "TRST* did not reset TAP / IR");
    #5 trst_n = 1'b1;
    j_rti();
  endtask

  // ================================================================ 2. lifecycle policy matrix
  task automatic lc_case(input string nm, input logic v, input logic [3:0] s, input logic dbg, input logic tm,
                         input logic ift, input logic [5:0] exp_perm, input bit exp_incons);
    logic [31:0] rd, id;
    logic [1:0] st;
    logic e;
    bit p_jtag, p_dbg, p_mbist, p_scan, p_host;
    {p_host, p_scan, p_mbist, p_dbg, p_jtag} = exp_perm[4:0];
    set_lc(v, s, dbg, tm, ift);
    sys_reset();
    cpu_rd(ta(TA_R_LC_STATUS), rd);
    chk(rd[21:16] == exp_perm, $sformatf("%s: permissions %06b, expected %06b", nm, rd[21:16], exp_perm));
    chk(rd[8] == exp_incons, $sformatf("%s: inconsistent flag %0d", nm, rd[8]));
    chk(dbg_allow == p_dbg, $sformatf("%s: dbg_allow %0d", nm, dbg_allow));
    // JTAG identification always works
    j_tlr(); j_rti();
    j_idcode(id);
    chk(id == IDCODE_VALUE, $sformatf("%s: IDCODE not readable (%08h)", nm, id));
    // JTAG register access
    j_reg_read(ta(TA_R_ID), st, rd);
    if (p_jtag) chk(st == REGST_OK && rd == TA_ID_VALUE, $sformatf("%s: JTAG register read refused", nm));
    else        chk(st == REGST_ERR && rd == 32'd0, $sformatf("%s: JTAG register read NOT refused (st %0d, %08h)", nm, st, rd));
    j_reg_write(ta(TA_R_SCRATCH), 32'h1111_2222, st);
    cpu_rd(ta(TA_R_SCRATCH), rd);
    chk(p_jtag ? (rd == 32'h1111_2222) : (rd == 32'd0), $sformatf("%s: JTAG write effect %08h", nm, rd));
    // host (unprivileged) access
    bus(1'b0, 1'b0, ta(TA_R_SEQ_STATUS), 32'd0, rd, e);
    chk(!e, $sformatf("%s: host-readable status refused", nm));
    bus(1'b0, 1'b0, pg(0, R_REVISION), 32'd0, rd, e);
    chk(e == !p_host, $sformatf("%s: host read of a group page err=%0d", nm, e));
    bus(1'b1, 1'b0, ta(TA_R_SCRATCH), 32'h3333_4444, rd, e);
    chk(e == !p_host, $sformatf("%s: host write err=%0d", nm, e));
    cpu_wr(ta(TA_R_SCRATCH), 32'h5555_6666);                     // the ControlCore may always write
    // debug mode
    enter_mode(MODE_JTAG_ACCESS, p_dbg);
    chk(jtag_mode == p_dbg, $sformatf("%s: jtag_mode output %0d", nm, jtag_mode));
    cpu_wr(ta(TA_R_MODE_CTRL), MODE_NORMAL); repeat (3) @(posedge clk);
    enter_mode(MODE_DIAGNOSTIC, p_dbg);
    chk(diag_mode == p_dbg, $sformatf("%s: diag_mode output %0d", nm, diag_mode));
    cpu_wr(ta(TA_R_MODE_CTRL), MODE_NORMAL); repeat (3) @(posedge clk);
    // MBIST mode
    enter_mode(MODE_MBIST, p_mbist);
    leave_mbist();
    // scan pin
    @(negedge clk); scan_mode_pin = 1'b1; scan_en_pin = 1'b0; #1;
    chk(dft_test_mode == p_scan && dft_icg_te == p_scan && dft_mem_inhibit == p_scan,
        $sformatf("%s: scan pin -> test_mode %0d", nm, dft_test_mode));
    chk((mode == MODE_SCAN_CAPTURE) == p_scan, $sformatf("%s: scan mode %0d", nm, mode));
    repeat (8) @(posedge clk);
    @(negedge clk); scan_mode_pin = 1'b0;
    repeat (8) @(posedge clk);
    // violation bookkeeping
    cpu_rd(ta(TA_R_VIOL_COUNT), rd);
    if (p_jtag && p_host && p_scan && p_dbg && p_mbist) chk(rd == 0, $sformatf("%s: %0d violations in DEV", nm, rd));
    else chk(rd != 0, $sformatf("%s: no security violation logged", nm));
    cpu_rd(ta(TA_R_ERR_STATUS), rd);
    chk(rd[TA_EC_SEC_VIOL] == !(p_jtag && p_host && p_scan), $sformatf("%s: ERR_STATUS.SEC_VIOL %0d", nm, rd[TA_EC_SEC_VIOL]));
    chk(rd[TA_EC_LC_INCONS] == exp_incons, $sformatf("%s: ERR_STATUS.LC_INCONS %0d", nm, rd[TA_EC_LC_INCONS]));
    ras_drain();
    if (!(p_jtag && p_host && p_scan))
      chk(ras_count(TA_RAS_ILLEGAL_OP, TA_EC_SEC_VIOL, 255) > 0, $sformatf("%s: no ILLEGAL_OP security event in RAS", nm));
    else
      chk(ras_count(TA_RAS_ILLEGAL_OP, -1, -1) == 0, $sformatf("%s: unexpected ILLEGAL_OP in RAS", nm));
    if (exp_incons) chk(ras_count(TA_RAS_ILLEGAL_OP, TA_EC_LC_INCONS, 255) == 1, $sformatf("%s: LC_INCONS not in RAS", nm));
    // bit by bit: simulators differ in the zero padding of a vector printed with %b
    $display("LC_MATRIX %-14s perm{ift,host,scan,mbist,dbg,jtag}=%b%b%b%b%b%b incons=%0d viol_events=%0d", nm,
             exp_perm[5], exp_perm[4], exp_perm[3], exp_perm[2], exp_perm[1], exp_perm[0], exp_incons,
             ras_count(TA_RAS_ILLEGAL_OP, TA_EC_SEC_VIOL, 255));
  endtask

  task automatic t_lc_policy();
    //                         valid state         dbg tm  ift  {ift,host,scan,mbist,dbg,jtag} incons
    lc_case("DEV",           1, TA_LC_DEV,      1,  1,  0,  6'b011111, 0);
    lc_case("DEV_ift",       1, TA_LC_DEV,      1,  1,  1,  6'b011111, 0);
    lc_case("PROV",          1, TA_LC_PROV,     0,  0,  0,  6'b000000, 0);
    lc_case("PROV_ift",      1, TA_LC_PROV,     0,  0,  1,  6'b100100, 0);
    lc_case("PROD",          1, TA_LC_PROD,     0,  0,  0,  6'b000000, 0);
    lc_case("PROD_ift",      1, TA_LC_PROD,     0,  0,  1,  6'b100100, 0);
    lc_case("RECOVERY_ift",  1, TA_LC_RECOVERY, 0,  0,  1,  6'b100100, 0);
    lc_case("INVALID",       1, TA_LC_INVALID,  0,  0,  1,  6'b000000, 0);
    lc_case("NOT_SENSED",    0, TA_LC_DEV,      0,  0,  1,  6'b000000, 0);
    lc_case("PROD_dbg_on",   1, TA_LC_PROD,     1,  1,  1,  6'b000000, 1);
    lc_case("DEV_dbg_off",   1, TA_LC_DEV,      0,  1,  1,  6'b000000, 1);
    lc_case("UNKNOWN_enum",  1, 4'd7,           0,  0,  1,  6'b000000, 1);
  endtask

  // ================================================================ 3. MBIST selection (page interface)
  task automatic t_mbist_select();
    logic [31:0] st, rd, c_mc, c_mp;
    int lat [3], preq [3];
    // effective read latency seen by the engine and request pipeline stages
    lat[0] = 1; lat[1] = 1; lat[2] = 4;      // group 2: RD_LAT 2 + request and response pipeline stages
    preq[0] = 0; preq[1] = 0; preq[2] = 1;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    traffic(1500);
    // identification and static group description (host-readable). Expected GRP_INFO from the bench
    // parameters: {pipe, init_on_reset, init_mode[1:0], kind[3:0], lat-1[2:0], row_bits[4:0], width[7:0], banks[7:0]}
    begin
      logic [31:0] exp_info [3];
      exp_info[0] = {1'b0, 1'b0, 2'd2, 4'd0, 3'd0, 5'd10, 8'd72, 8'd4};   // P33 grid: self init, 4 x 1024 x 72
      exp_info[1] = {1'b0, 1'b1, 2'd1, 4'd1, 3'd0, 5'd10, 8'd36, 8'd4};   // MemoryCore 16 KiB: collar init, reset sweep
      exp_info[2] = {1'b1, 1'b1, 2'd1, 4'd1, 3'd1, 5'd10, 8'd36, 8'd2};   // MemoryCore 8 KiB: RD_LAT 2, pipelined
      cpu_rd(ta(TA_R_ID), rd);       chk(rd == TA_ID_VALUE, $sformatf("ID %08h", rd));
      cpu_rd(ta(TA_R_REVISION), rd); chk(rd[31:16] == 16'h0039, $sformatf("REVISION %08h", rd));
      cpu_rd(ta(TA_R_CAPS), rd);
      chk(rd == {8'd0, 8'd0, 2'b00, 1'b1, 1'b1, 8'd10, 4'd3}, $sformatf("CAPS %08h (3 groups, 10 banks, seq, RAS, 0 chains)", rd));
      cpu_rd(ta(TA_R_IDCODE), rd);   chk(rd == IDCODE_VALUE, $sformatf("IDCODE register %08h", rd));
      for (int g = 0; g < NG; g++) begin
        cpu_rd(ta(TA_R_GRP_INFO0 + 9'(8 * g)), rd);
        chk(rd == exp_info[g], $sformatf("GRP_INFO%0d %08h, expected %08h", g, rd, exp_info[g]));
        cpu_rd(ta(TA_R_GRP_LIVE0 + 9'(8 * g)), rd);   // idle: NORMAL, released, ready, functional path open
        chk(rd[2:0] == OWN_NORMAL && rd[11] && rd[12] && !rd[9] && !rd[8] && !rd[15],
            $sformatf("GRP_LIVE%0d idle %08h", g, rd));
      end
    end
    enter_mode(MODE_MBIST, 1);
    // live status of a group under test, then after its release
    cpu_wr(pg(1, R_BANK_MASK), 32'h1);
    wait_reg(pg(1, R_OWNER_STATUS), 32'h7, 32'(OWN_TEST_ACTIVE), 20000, "group acquisition", rd);
    cpu_wr(pg(1, R_TEST_CONTROL), (32'(ALG_MARCH_C_MINUS) << 4) | 32'h1);
    repeat (200) @(posedge clk);
    cpu_rd(ta(TA_R_GRP_LIVE0 + 9'd8), rd);
    chk(rd[2:0] == OWN_TEST_ACTIVE && rd[15] && rd[9] && rd[8] && rd[10] && rd[7] && !rd[11],
        $sformatf("GRP_LIVE1 under test %08h", rd));
    wait_reg(pg(1, R_TEST_STATUS), 32'h3, 32'h2, 2000000, "group test done", st);
    cpu_wr(pg(1, R_BANK_MASK), 32'd0);
    wait_reg(pg(1, R_OWNER_STATUS), 32'h7, 32'(OWN_NORMAL), 20000, "group release", rd);
    wait_released(1);
    cpu_rd(ta(TA_R_GRP_LIVE0 + 9'd8), rd);
    chk(rd[2:0] == OWN_NORMAL && !rd[15] && !rd[9] && !rd[8] && rd[11] && rd[18:16] == RES_PASS,
        $sformatf("GRP_LIVE1 after the test %08h", rd));
    for (int g = 0; g < NG; g++) begin
      int b, n, model_mc, delta;
      b = (g == 0) ? 2 : 1;
      n = 1024;
      tl_clear();
      page_test(g, 4'(1 << b), ALG_MARCH_C_MINUS, 1'b1, st);
      chk(st[2] && !st[3] && !st[5], $sformatf("group %0d bank %0d: March C- did not pass (TEST_STATUS %08h)", g, b, st));
      cpu_rd(pg(g, R_BANKS_TESTED), rd); chk(rd == 32'(1 << b), $sformatf("group %0d BANKS_TESTED %0h", g, rd));
      cpu_rd(pg(g, R_BANKS_FAILED), rd); chk(rd == 32'd0, $sformatf("group %0d BANKS_FAILED %0h", g, rd));
      cpu_rd(pg(g, R_LAST_RESULT), rd);  chk(rd[2:0] == RES_PASS, $sformatf("group %0d LAST_RESULT %0d", g, rd[2:0]));
      cpu_rd(pg(g, R_CYCLES), c_mc);
      chk_bankseq(g, 1, b, 0, 0, 0);
      for (int o = 0; o < NG; o++) if (o != g) chk(t_first[o] < 0, $sformatf("group %0d touched while testing %0d", o, g));
      page_test(g, 4'(1 << b), ALG_MATS_PLUS, 1'b1, st);
      chk(st[2], $sformatf("group %0d bank %0d: MATS+ did not pass", g, b));
      cpu_rd(pg(g, R_CYCLES), c_mp);
      // March C- = 5N reads + 6N writes (incl. scrub), MATS+ = 2N reads + 4N writes.  Per-operation
      // model: read = 1 + L_eff, write = 1 + request stages.  A wrong coefficient would be off by a
      // multiple of N (1024); the remainder is a small fixed per-run / per-element overhead.
      delta = 3 * n * (1 + lat[g]) + 2 * n * (1 + preq[g]);
      model_mc = 5 * n * (1 + lat[g]) + 6 * n * (1 + preq[g]);
      chk(int'(c_mc) - model_mc >= 0 && int'(c_mc) - model_mc <= 16,
          $sformatf("group %0d: March C- %0d cycles vs per-operation model %0d", g, c_mc, model_mc));
      chk(int'(c_mp) - (model_mc - delta) >= 0 && int'(c_mp) - (model_mc - delta) <= 16,
          $sformatf("group %0d: MATS+ %0d cycles vs per-operation model %0d", g, c_mp, model_mc - delta));
      $display("MBIST_CYCLES group=%0d bank=%0d depth=%0d read_cost=%0d write_cost=%0d marchc=%0d (model %0d + %0d) mats=%0d (model %0d + %0d)",
               g, b, n, 1 + lat[g], 1 + preq[g], c_mc, model_mc, int'(c_mc) - model_mc,
               c_mp, model_mc - delta, int'(c_mp) - (model_mc - delta));
    end
    // two banks of one group: ascending order
    tl_clear();
    page_test(1, 4'b1010, ALG_MARCH_C_MINUS, 1'b0, st);
    chk(st[2], "group 1 banks {1,3}: no PASS");
    cpu_rd(pg(1, R_BANKS_TESTED), rd); chk(rd == 32'hA, $sformatf("group 1 BANKS_TESTED %0h", rd));
    chk_bankseq(1, 2, 1, 3, 0, 0);
    // TestCore observation: TEST_BANK_ID after completion holds the bank-loop counter, not the last bank
    cpu_rd(pg(1, R_TEST_BANK_ID), rd);
    $display("OBSERVATION TestCore TEST_BANK_ID after a run of banks {1,3} reads %0d", rd);
    leave_mbist();
    traffic(2000);
  endtask

  // ================================================================ 4. algorithms
  task automatic t_algorithms();
    logic [31:0] st, rd;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    enter_mode(MODE_MBIST, 1);
    for (int a = 0; a < 6; a++) begin
      page_test(1, 4'b0001, 4'(a), 1'b0, st);
      cpu_rd(pg(1, R_CYCLES), rd);
      chk(st[2] && !st[3], $sformatf("group 1 algorithm %0d: no PASS (%08h)", a, st));
      $display("ALG_CYCLES group=1 width=36 depth=1024 alg=%0d cycles=%0d", a, rd);
    end
    for (int a = 0; a < 4; a++) begin
      page_test(0, 4'b0010, 4'(a), 1'b0, st);
      cpu_rd(pg(0, R_CYCLES), rd);
      chk(st[2] && !st[3], $sformatf("group 0 algorithm %0d: no PASS (%08h)", a, st));
      $display("ALG_CYCLES group=0 width=72 depth=1024 alg=%0d cycles=%0d", a, rd);
    end
    // March C- with the checkerboard background option (TEST_CONTROL[8])
    cpu_wr(pg(2, R_BANK_MASK), 32'h1);
    wait_reg(pg(2, R_OWNER_STATUS), 32'h7, 32'(OWN_TEST_ACTIVE), 20000, "acquire g2", rd);
    cpu_wr(pg(2, R_TEST_CONTROL), (32'h1 << 8) | 32'h1);
    repeat (4) @(posedge clk);
    wait_reg(pg(2, R_TEST_STATUS), 32'h3, 32'h2, 2000000, "g2 done", st);
    chk(st[2], "group 2 March C- checkerboard background: no PASS");
    cpu_wr(pg(2, R_BANK_MASK), 32'h0);
    wait_released(2);
    leave_mbist();
    traffic(1500);
  endtask

  // ================================================================ 5. functional -> test -> functional under live traffic
  task automatic t_func_switch();
    logic [31:0] st, rd;
    int acc_before [4], acc_during [4];
    longint t_ack, t_act;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    m_en = 1'b1;
    repeat (2000) @(posedge clk);
    enter_mode(MODE_MBIST, 1);
    for (int g = 0; g < NG; g++) begin
      acc_before[0] = u_m0.accepted_total; acc_before[1] = u_m1.accepted_total;
      acc_before[2] = u_m2.accepted_total; acc_before[3] = u_m3.accepted_total;
      tl_clear();
      page_test(g, (g == 2) ? 4'b0011 : 4'b1111, ALG_MARCH_C_MINUS, 1'b0, st);
      t_ack = t_qack[g]; t_act = t_act_q(g);
      chk(st[2], $sformatf("group %0d: test under traffic did not pass (%08h)", g, st));
      chk(t_ack >= 0 && t_act > t_ack, $sformatf("group %0d: test bus taken before quiesce acknowledge (ack %0d act %0d)",
          g, t_ack, t_act));
      acc_during[0] = u_m0.accepted_total - acc_before[0]; acc_during[1] = u_m1.accepted_total - acc_before[1];
      acc_during[2] = u_m2.accepted_total - acc_before[2]; acc_during[3] = u_m3.accepted_total - acc_before[3];
      // the other groups kept working while group g was under test
      if (g != 0) chk(acc_during[0] > 100 && acc_during[1] > 100, $sformatf("grid traffic stalled while group %0d tested", g));
      if (g != 1) chk(acc_during[2] > 100, $sformatf("group-1 traffic stalled while group %0d tested", g));
      if (g != 2) chk(acc_during[3] > 100, $sformatf("group-2 traffic stalled while group %0d tested", g));
      $display("FUNC_SWITCH group=%0d quiesce_ack->tst_active=%0d cycles accepted_during={%0d,%0d,%0d,%0d}",
               g, t_act - t_ack, acc_during[0], acc_during[1], acc_during[2], acc_during[3]);
      repeat (1500) @(posedge clk);
    end
    leave_mbist();
    repeat (3000) @(posedge clk);
    m_en = 1'b0;
    repeat (50) @(posedge clk);
    chk(u_m0.n_rsp > 1000 && u_m2.n_rsp > 1000 && u_m3.n_rsp > 1000, "too little functional traffic checked");
  endtask

  // ================================================================ 6. injected memory faults
  task automatic fault_case(input int g, input int b, input int kind, input int a, input int bt,
                            input int a2, input int bt2, input int exp_elem, input int exp_addr, input int exp_bit);
    logic [31:0] st, rd, info, fa, s0, s1, s2;
    logic [95:0] synd;
    string nm;
    nm = $sformatf("g%0d b%0d kind%0d row%0d bit%0d", g, b, kind, a, bt);
    inject(g, b, kind, a, bt, a2, bt2);
    page_test(g, 4'(1 << b), ALG_MARCH_C_MINUS, 1'b1, st);
    chk(st[1] && st[3] && !st[2], $sformatf("%s: not reported as FAIL (TEST_STATUS %08h)", nm, st));
    cpu_rd(pg(g, R_FF_INFO), info);
    cpu_rd(pg(g, R_FF_ADDR), fa);
    cpu_rd(pg(g, R_FF_SYND0), s0); cpu_rd(pg(g, R_FF_SYND0 + 12'h4), s1); cpu_rd(pg(g, R_FF_SYND0 + 12'h8), s2);
    synd = {s2, s1, s0};
    chk(info[31], $sformatf("%s: FIRST_FAIL not valid", nm));
    chk(info[7:0] == 8'(b), $sformatf("%s: FIRST_FAIL bank %0d", nm, info[7:0]));
    if (exp_elem >= 0) chk(info[11:8] == 4'(exp_elem), $sformatf("%s: FIRST_FAIL element %0d, expected %0d", nm, info[11:8], exp_elem));
    if (exp_addr >= 0) chk(fa == 32'(exp_addr), $sformatf("%s: FIRST_FAIL address %0d, expected %0d", nm, fa, exp_addr));
    if (exp_bit >= 0)  chk(synd == (96'd1 << exp_bit), $sformatf("%s: syndrome %h, expected bit %0d", nm, synd, exp_bit));
    cpu_rd(pg(g, R_BANKS_FAILED), rd); chk(rd == 32'(1 << b), $sformatf("%s: BANKS_FAILED %0h", nm, rd));
    cpu_rd(ta(TA_R_GRP_STATUS), rd);   chk(rd[g*4 + 3], $sformatf("%s: TA GRP_STATUS fail bit", nm));
    cpu_rd(pg(g, R_FAIL_COUNT), rd);   chk(rd != 0, $sformatf("%s: FAIL_COUNT 0", nm));
    $display("FAULT %s -> FAIL elem=%0d op_index=%0d addr=%0d synd=%h fail_count=%0d", nm, info[11:8], info[15:12], fa, synd, rd);
    inject(g, b, 0, 0, 0, 0, 0);
    page_test(g, 4'(1 << b), ALG_MARCH_C_MINUS, 1'b0, st);
    chk(st[2] && !st[3], $sformatf("%s: fault removed but test still fails", nm));
  endtask

  task automatic t_faults();
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    enter_mode(MODE_MBIST, 1);
    // generic SRAM fault hooks: 1 SA0, 2 SA1, 3 TF-up, 4 TF-down, 5 CFid (aggr -> victim), 6 address alias
    //          g  b kind  row  bit  row2 bit2  elem  addr  bit
    fault_case(1, 2, 1,   517, 13,    0,   0,    2,   517,  13);   // MemoryCore data bit
    fault_case(1, 0, 2,     3, 35,    0,   0,    1,     3,  35);   // MemoryCore parity bit (lane 3)
    fault_case(1, 3, 3,  1000,  7,    0,   0,    2,  1000,   7);
    fault_case(1, 1, 4,    64, 20,    0,   0,    3,    64,  20);
    fault_case(1, 2, 5,   100,  4,  200,   9,    1,   200,   9);   // coupling: victim reported
    fault_case(1, 0, 6,    10,  0,   20,   0,   -1,    -1,  -1);   // address-decoder alias
    fault_case(0, 1, 1,   700, 13,    0,   0,    2,   700,  13);   // grid data bit
    fault_case(0, 3, 2,     5, 70,    0,   0,    1,     5,  70);   // grid SECDED check bit
    fault_case(0, 0, 4,  1023, 71,    0,   0,    3,  1023,  71);   // grid, last row, top bit
    fault_case(2, 1, 1,   333,  5,    0,   0,    2,   333,   5);   // RD_LAT 2 + pipelined link
    fault_case(2, 0, 2,  1023, 35,    0,   0,    1,  1023,  35);
    // sequencer over a faulty group: FAIL result and probe pins; then STOP_ON_FAIL leaves later groups NOT_RUN
    begin
      logic [31:0] st, res;
      inject(0, 1, 1, 12, 40, 0, 0);
      seq_run(3'b111, 1'b0, ALG_MATS_PLUS, 32'd0, st, res);
      chk(res[11:0] == 12'h112 && st[3] && test_done && test_fail && !test_pass,
          $sformatf("sequence with a faulty group 0: SEQ_STATUS %08h RESULT %03h", st, res[11:0]));
      cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h7);
      cpu_wr(ta(TA_R_SEQ_CTRL), (32'(ALG_MATS_PLUS) << 8) | (32'h1 << TA_SEQ_STOP_ON_FAIL) | 32'h1);
      repeat (4) @(posedge clk);
      wait_reg(ta(TA_R_SEQ_STATUS), 32'h3, 32'h2, 2000000, "stop-on-fail sequence", st);
      cpu_rd(ta(TA_R_SEQ_RESULT), res);
      chk(res[11:0] == 12'h002, $sformatf("STOP_ON_FAIL: SEQ_RESULT %03h (expected g0 FAIL, others NOT_RUN)", res[11:0]));
      inject(0, 1, 0, 0, 0, 0, 0);
      seq_run(3'b001, 1'b0, ALG_MATS_PLUS, 32'd0, st, res);    // clean re-initialisation without the defect
      chk(res[3:0] == 4'h1, "group 0 does not pass after the fault was removed");
    end
    ras_drain();
    chk(ras_count(TA_RAS_MEM_UE, TA_EC_MBIST_FAIL, -1) == 13, $sformatf("RAS MEM_UE MBIST_FAIL events %0d, expected 13",
        ras_count(TA_RAS_MEM_UE, TA_EC_MBIST_FAIL, -1)));
    leave_mbist();
    traffic(2000);
  endtask

  // ================================================================ 7. multi-group / multi-bank ordering
  task automatic t_ordering();
    logic [31:0] st, res, cyc_seq, cyc_par;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    m_en = 1'b1;
    enter_mode(MODE_MBIST, 1);
    // sequential: groups 0, 1, 2 one after another, banks ascending
    tl_clear();
    seq_run(3'b111, 1'b0, ALG_MARCH_C_MINUS, 32'd0, st, res);
    cpu_rd(ta(TA_R_SEQ_CYCLES), cyc_seq);
    chk(st[2] && !st[3] && !st[4], $sformatf("sequential: SEQ_STATUS %08h", st));
    chk(res[11:0] == 12'h111, $sformatf("sequential: SEQ_RESULT %03h", res[11:0]));
    chk(test_done && test_pass && !test_fail, "sequential: wafer-probe status pins");
    chk(overlap_cycles == 0, $sformatf("sequential: %0d cycles with two groups under test", overlap_cycles));
    chk(t_first[0] >= 0 && t_last[0] < t_first[1] && t_last[1] < t_first[2],
        $sformatf("sequential: group windows [%0d,%0d] [%0d,%0d] [%0d,%0d] not ascending",
                  t_first[0], t_last[0], t_first[1], t_last[1], t_first[2], t_last[2]));
    chk_bankseq(0, 4, 0, 1, 2, 3); chk_bankseq(1, 4, 0, 1, 2, 3); chk_bankseq(2, 2, 0, 1, 0, 0);
    $display("ORDER sequential windows g0=[%0d,%0d] g1=[%0d,%0d] g2=[%0d,%0d] cycles=%0d",
             t_first[0], t_last[0], t_first[1], t_last[1], t_first[2], t_last[2], cyc_seq);
    // parallel: all groups at once
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h4);                                  // CLEAR
    tl_clear();
    seq_run(3'b111, 1'b1, ALG_MARCH_C_MINUS, 32'd0, st, res);
    cpu_rd(ta(TA_R_SEQ_CYCLES), cyc_par);
    chk(st[2] && res[11:0] == 12'h111, $sformatf("parallel: SEQ_STATUS %08h SEQ_RESULT %03h", st, res[11:0]));
    chk(overlap_cycles > 0, "parallel: groups never tested concurrently");
    chk(cyc_par < cyc_seq, $sformatf("parallel (%0d cycles) not faster than sequential (%0d)", cyc_par, cyc_seq));
    chk_bankseq(0, 4, 0, 1, 2, 3); chk_bankseq(1, 4, 0, 1, 2, 3); chk_bankseq(2, 2, 0, 1, 0, 0);
    $display("ORDER parallel overlap_cycles=%0d cycles=%0d (sequential %0d)", overlap_cycles, cyc_par, cyc_seq);
    // subset {0, 2}
    tl_clear();
    seq_run(3'b101, 1'b0, ALG_MATS_PLUS, 32'd0, st, res);
    chk(res[11:0] == 12'h101, $sformatf("subset: SEQ_RESULT %03h", res[11:0]));
    chk(t_first[1] < 0, "subset: group 1 touched");
    chk(t_last[0] < t_first[2], "subset: order");
    leave_mbist();
    repeat (2000) @(posedge clk);
    m_en = 1'b0; repeat (50) @(posedge clk);
  endtask

  // ================================================================ 8. timeouts
  task automatic t_timeout();
    logic [31:0] st, res, rd;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    enter_mode(MODE_MBIST, 1);
    // (a) sequencer watchdog expires in RUN
    seq_run(3'b010, 1'b0, ALG_MARCH_C_MINUS, 32'd3000, st, res);
    chk(nib(res, 1) == TA_RES_TIMEOUT, $sformatf("watchdog RUN: result %0d", nib(res, 1)));
    chk(st[4] && !st[2], $sformatf("watchdog RUN: SEQ_STATUS %08h", st));
    cpu_rd(pg(1, R_LAST_RESULT), rd); chk(rd[2:0] == RES_ABORTED, $sformatf("watchdog RUN: engine result %0d", rd[2:0]));
    cpu_rd(ta(TA_R_ERR_STATUS), rd);  chk(rd[TA_EC_SEQ_TIMEOUT], "watchdog RUN: ERR_STATUS.SEQ_TIMEOUT");
    chk(u_ta.g_released[1], "watchdog RUN: group not released");
    traffic(1500);
    // (b) watchdog expires in ACQ (master never acknowledges; watchdog < owner timeout)
    m_noack[2] = 1'b1; m_en = 1'b1;
    seq_run(3'b010, 1'b0, ALG_MARCH_C_MINUS, 32'd500, st, res);
    chk(nib(res, 1) == TA_RES_TIMEOUT, $sformatf("watchdog ACQ: result %0d", nib(res, 1)));
    cpu_rd(pg(1, R_OWNER_STATUS), rd); chk(rd[2:0] == OWN_NORMAL, $sformatf("watchdog ACQ: owner state %0d", rd[2:0]));
    // (b2) sequence ABORT while the group still waits for acquisition: ABORTED, never owned by test
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h2);
    cpu_wr(ta(TA_R_WDOG_LIMIT), 32'd0);
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1);
    wait (u_ta.sq_cur_phase == TA_GS_ACQ);
    repeat (50) @(posedge clk);
    chk(!tst_active[1], "ACQ abort: group owned before the master acknowledged");
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1 << TA_SEQ_ABORT);
    wait_reg(ta(TA_R_SEQ_STATUS), 32'h3, 32'h2, 200000, "sequence abort in ACQ", st);
    cpu_rd(ta(TA_R_SEQ_RESULT), res);
    chk(nib(res, 1) == TA_RES_ABORTED, $sformatf("ACQ abort: result %0d", nib(res, 1)));
    cpu_rd(pg(1, R_OWNER_STATUS), rd); chk(rd[2:0] == OWN_NORMAL, $sformatf("ACQ abort: owner state %0d", rd[2:0]));
    chk(!tst_active[1], "ACQ abort: group owned by test");
    // (c) ownership timeout (no watchdog): owner FAULT
    m_noack[2] = 1'b0; m_noack[3] = 1'b1;
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h4);
    seq_run(3'b100, 1'b0, ALG_MARCH_C_MINUS, 32'd0, st, res);
    chk(nib(res, 2) == TA_RES_OWNER_FAULT, $sformatf("owner timeout: result %0d", nib(res, 2)));
    cpu_rd(pg(2, R_OWNER_STATUS), rd); chk(rd[2:0] == OWN_FAULT, $sformatf("owner timeout: owner state %0d", rd[2:0]));
    cpu_rd(pg(2, R_ERROR_FLAGS), rd);  chk(rd[EF_OWNER_FAULT], "owner timeout: ERROR_FLAGS.OWNER_FAULT");
    cpu_rd(ta(TA_R_ERR_STATUS), rd);   chk(rd[TA_EC_OWNER_FAULT], "owner timeout: ERR_STATUS.OWNER_FAULT");
    m_noack[3] = 1'b0;
    repeat (200) @(posedge clk);                                     // FAULT returns the port to functional use
    chk(u_m3.n_rsp > 0, "owner FAULT: functional traffic did not resume");
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h4);                                // CLEAR: engine + owner FAULT
    repeat (4) @(posedge clk);
    cpu_rd(pg(2, R_OWNER_STATUS), rd); chk(rd[2:0] == OWN_NORMAL, "CLEAR did not clear the owner FAULT");
    seq_run(3'b100, 1'b0, ALG_MARCH_C_MINUS, 32'd0, st, res);
    chk(nib(res, 2) == TA_RES_PASS, $sformatf("after CLEAR: result %0d", nib(res, 2)));
    // (d) engine response timeout: the memory stops answering reads -> inconclusive (ERROR), never PASS / FAIL
    -> ev_withhold_rsp;
    seq_run(3'b010, 1'b0, ALG_MARCH_C_MINUS, 32'd0, st, res);
    release u_ta.g_grp[1].u_collar.b_rvalid;
    chk(nib(res, 1) == TA_RES_ERROR, $sformatf("engine timeout: sequence result %0d (expected ERROR)", nib(res, 1)));
    cpu_rd(pg(1, R_LAST_RESULT), rd); chk(rd[2:0] == RES_ERROR, $sformatf("engine timeout: LAST_RESULT %0d", rd[2:0]));
    cpu_rd(pg(1, R_ERROR_FLAGS), rd); chk(rd[EF_TIMEOUT], "engine timeout: ERROR_FLAGS.TIMEOUT");
    cpu_rd(ta(TA_R_ERR_STATUS), rd);  chk(rd[TA_EC_MBIST_ERROR], "engine timeout: ERR_STATUS.MBIST_ERROR");
    chk(u_ta.g_released[1], "engine timeout: group not released");
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h4);                                // CLEAR leaves the engine ERROR state
    seq_run(3'b010, 1'b0, ALG_MATS_PLUS, 32'd0, st, res);
    chk(nib(res, 1) == TA_RES_PASS, $sformatf("after engine timeout + CLEAR: result %0d", nib(res, 1)));
    m_en = 1'b0;
    ras_drain();
    chk(ras_count(TA_RAS_TIMEOUT, TA_EC_MBIST_ERROR, 1) >= 1, "RAS MBIST_ERROR (TIMEOUT) event for group 1");
    chk(ras_count(TA_RAS_TIMEOUT, TA_EC_SEQ_TIMEOUT, 1) == 2, $sformatf("RAS SEQ_TIMEOUT events for group 1: %0d",
        ras_count(TA_RAS_TIMEOUT, TA_EC_SEQ_TIMEOUT, 1)));
    chk(ras_count(TA_RAS_TIMEOUT, TA_EC_OWNER_FAULT, 2) == 1, "RAS OWNER_FAULT event for group 2");
    leave_mbist();
    traffic(1500);
  endtask

  // module-level helper for (d): withhold group 1's read responses once its engine runs
  event ev_withhold_rsp;
  always @(ev_withhold_rsp) begin
    wait (tst_active[1] && u_ta.g_grp[1].u_collar.grp_state == OWN_TEST_ACTIVE);
    repeat (200) @(posedge clk);
    force u_ta.g_grp[1].u_collar.b_rvalid = '0;
  end

  // ================================================================ 9. reset during test
  task automatic t_reset_in_test();
    logic [31:0] st, res, rd;
    logic [1:0] jst;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    m_en = 1'b1;
    // (a) test-access reset only, all groups mid-test (parallel)
    enter_mode(MODE_MBIST, 1);
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h7);
    cpu_wr(ta(TA_R_SEQ_CTRL), (32'h1 << TA_SEQ_PARALLEL) | 32'h1);
    wait (&tst_active);
    repeat (3000) @(posedge clk);
    chk(u_ta.sq_busy, "sequence not running before the reset");
    #3 rst_n = 1'b0;
    #1;
    chk(!tst_active[0], "grid still owned by test during reset");
    chk(tst_active[1] && tst_active[2], "MemoryCore groups not held in test (initialisation) during reset");
    repeat (6) @(posedge clk);
    #2 rst_n = 1'b1;
    wait_init();
    cpu_rd(ta(TA_R_SEQ_STATUS), rd); chk(rd[1:0] == 2'b00, $sformatf("after reset: SEQ_STATUS %08h", rd));
    cpu_rd(ta(TA_R_MODE_STATUS), rd); chk(rd[2:0] == MODE_NORMAL, "after reset: mode not NORMAL");
    repeat (3000) @(posedge clk);                                    // traffic: re-initialised content, no parity / ECC error
    j_tlr(); j_rti();
    j_reg_read(ta(TA_R_ID), jst, rd);
    chk(jst == REGST_OK && rd == TA_ID_VALUE, "JTAG access after the test-access reset");
    // (b) full system reset mid-test (sequential)
    enter_mode(MODE_MBIST, 1);
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h7);
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1);
    wait (tst_active[1]);
    repeat (5000) @(posedge clk);
    #3 rst_n = 1'b0; mem_rst_n = 1'b0;
    repeat (6) @(posedge clk);
    #2 rst_n = 1'b1; mem_rst_n = 1'b1;
    wait_init();
    repeat (3000) @(posedge clk);
    // (c) JTAG register request while the system domain is in reset: BUSY, never a stale OK
    #3 rst_n = 1'b0;
    j_reg_read(ta(TA_R_ID), jst, rd);
    chk(jst == REGST_BUSY, $sformatf("JTAG request during system reset: status %0d (expected BUSY)", jst));
    #2 rst_n = 1'b1;
    repeat (20) @(posedge clk);
    begin
      logic [63:0] cap;
      j_dr(REG_DR_LEN, {18'd0, REGOP_CLEAR, 12'd0, 32'd0}, cap);
      j_idle(12);
    end
    j_reg_read(ta(TA_R_ID), jst, rd);
    chk(jst == REGST_OK && rd == TA_ID_VALUE, "JTAG access after CLEAR");
    wait_init();
    // (d) test requested while the reset initialisation sweep of the MemoryCore groups is still running:
    //     acquisition waits for the sweep (no test ownership before the memory is initialised), then passes
    begin
      int early;
      #3 rst_n = 1'b0;
      repeat (6) @(posedge clk);
      #2 rst_n = 1'b1;
      repeat (2) @(posedge clk);
      chk(mem_ready[2:1] == 2'b00, "reset initialisation sweep not running after the test-access reset");
      enter_mode(MODE_MBIST, 1);
      cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h6);
      cpu_wr(ta(TA_R_WDOG_LIMIT), 32'd0);
      cpu_wr(ta(TA_R_SEQ_CTRL), (32'h1 << TA_SEQ_PARALLEL) | 32'h1);
      chk(mem_ready[2:1] == 2'b00, "sequence requested after the initialisation sweeps (scenario too slow)");
      early = 0;
      while (mem_ready[2:1] != 2'b11) begin
        @(posedge clk);
        if (!mem_ready[1] && u_ta.g_grp[1].u_collar.grp_state != OWN_NORMAL) early++;
        if (!mem_ready[2] && u_ta.g_grp[2].u_collar.grp_state != OWN_NORMAL) early++;
      end
      chk(early == 0, $sformatf("group left NORMAL during the reset initialisation sweep (%0d cycles)", early));
      wait_reg(ta(TA_R_SEQ_STATUS), 32'h0000_0003, 32'h0000_0002, 4000000, "sequence done", st);
      chk(mem_ready === 3'b111 && !g_init_busy, "sequence done while a memory is still initialising");
      cpu_rd(ta(TA_R_SEQ_RESULT), res);
      chk(st[2] && res[11:4] == 8'h11, $sformatf("test requested during the reset sweep: SEQ_STATUS %08h RESULT %03h",
                                                  st, res[11:0]));
      leave_mbist();
      repeat (2000) @(posedge clk);                                  // traffic on the re-initialised groups
    end
    m_en = 1'b0;
    repeat (50) @(posedge clk);
  endtask

  // ================================================================ 10. secure debug restrictions
  task automatic t_secure_debug();
    logic [31:0] st, res, rd;
    logic [1:0] jst;
    logic e;
    // (a) PROD with in-field test fuse: firmware may test, JTAG / host may not
    set_lc_std(TA_LC_PROD, 1'b1); sys_reset();
    traffic(1000);
    enter_mode(MODE_MBIST, 1);
    seq_run(3'b111, 1'b1, ALG_MARCH_C_MINUS, 32'd0, st, res);
    chk(st[2] && res[11:0] == 12'h111, $sformatf("PROD in-field MBIST: SEQ_STATUS %08h RESULT %03h", st, res));
    j_tlr(); j_rti();
    j_reg_read(ta(TA_R_SEQ_RESULT), jst, rd);
    chk(jst == REGST_ERR && rd == 0, "PROD: JTAG could read the test results");
    j_reg_write(ta(TA_R_MODE_CTRL), MODE_NORMAL, jst);
    cpu_rd(ta(TA_R_MODE_STATUS), rd);
    chk(jst == REGST_ERR && rd[2:0] == MODE_MBIST, "PROD: JTAG could change the test mode");
    bus(1'b1, 1'b0, ta(TA_R_SEQ_CTRL), 32'h1, rd, e);
    chk(e, "PROD: host could start a sequence");
    repeat (4) @(posedge clk);
    cpu_rd(ta(TA_R_SEQ_STATUS), rd); chk(!rd[0], "PROD: host START was executed");
    bus(1'b0, 1'b0, ta(TA_R_SEQ_STATUS), 32'd0, rd, e);
    chk(!e && rd[2], "PROD: host cannot read the summary status");
    bus(1'b0, 1'b0, pg(1, R_FF_ADDR), 32'd0, rd, e);
    chk(e, "PROD: host could read group failure details");
    leave_mbist();
    @(negedge clk); scan_mode_pin = 1'b1; scan_en_pin = 1'b1; #1;
    chk(!dft_test_mode && !dft_scan_en && !dft_icg_te && mode == MODE_NORMAL, "PROD: scan pin honoured");
    repeat (10) @(posedge clk); @(negedge clk); scan_mode_pin = 1'b0; scan_en_pin = 1'b0;
    enter_mode(MODE_JTAG_ACCESS, 0);
    enter_mode(MODE_DIAGNOSTIC, 0);
    cpu_rd(ta(TA_R_VIOL_COUNT), rd); chk(rd >= 6, $sformatf("PROD: %0d violations logged", rd));
    cpu_rd(ta(TA_R_VIOL_INFO), rd);  chk(rd[31] && rd[27:24] == TA_VS_MODE, $sformatf("PROD: last violation %08h", rd));
    traffic(1500);
    // (b) PROD without the in-field fuse: no MBIST at all, memory content untouched
    set_lc_std(TA_LC_PROD, 1'b0); sys_reset();
    traffic(2000);
    tl_clear();
    enter_mode(MODE_MBIST, 0);
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h7);
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1);
    repeat (10) @(posedge clk);
    cpu_rd(ta(TA_R_SEQ_RESULT), res);
    chk(res[11:0] == 12'h666, $sformatf("PROD no fuse: SEQ_RESULT %03h (expected REFUSED)", res[11:0]));
    m_en = 1'b1; repeat (2000) @(posedge clk); m_en = 1'b0; repeat (40) @(posedge clk);
    chk(t_first[0] < 0 && t_first[1] < 0 && t_first[2] < 0, "PROD no fuse: a memory group entered test");
    // (c) permission withdrawn in the middle of a test (DEV, lifecycle becomes invalid)
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    m_en = 1'b1;
    enter_mode(MODE_MBIST, 1);
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h7);
    cpu_wr(ta(TA_R_SEQ_CTRL), (32'h1 << TA_SEQ_PARALLEL) | 32'h1);
    wait (&tst_active);
    repeat (2000) @(posedge clk);
    @(negedge clk); lc_valid = 1'b0;
    repeat (2) @(posedge clk);
    chk(mode == MODE_NORMAL && !u_ta.mbist_enable, "permission loss: mode not forced to NORMAL");
    wait_reg(ta(TA_R_SEQ_STATUS), 32'h3, 32'h2, 200000, "sequence end after permission loss", st);
    cpu_rd(ta(TA_R_SEQ_RESULT), res);
    chk(res[11:0] == 12'h333, $sformatf("permission loss: SEQ_RESULT %03h (expected ABORTED)", res[11:0]));
    wait_init();
    cpu_rd(ta(TA_R_VIOL_INFO), rd); chk(rd[27:24] == TA_VS_PERM_LOSS, $sformatf("permission loss: VIOL_INFO %08h", rd));
    repeat (2000) @(posedge clk);
    m_en = 1'b0; repeat (40) @(posedge clk);
    // (d) DEV: manufacturing test entirely over JTAG (wafer-probe flow)
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    j_tlr(); j_rti();
    j_reg_write(ta(TA_R_UNLOCK), TC_UNLOCK_KEY, jst);       chk(jst == REGST_OK, "JTAG UNLOCK");
    j_reg_write(ta(TA_R_MODE_CTRL), MODE_MBIST, jst);       chk(jst == REGST_OK, "JTAG MODE_CTRL");
    j_reg_write(ta(TA_R_SEQ_GROUPS), 32'h7, jst);
    j_reg_write(ta(TA_R_SEQ_CTRL), (32'h1 << TA_SEQ_PARALLEL) | 32'h1, jst);
    jst = REGST_OK; rd = '0;
    while (jst == REGST_OK && !rd[1]) begin
      j_idle(400);
      j_reg_read(ta(TA_R_SEQ_STATUS), jst, rd);
    end
    j_reg_read(ta(TA_R_SEQ_RESULT), jst, res);
    chk(jst == REGST_OK && res[11:0] == 12'h111, $sformatf("JTAG-driven MBIST: SEQ_RESULT %03h", res[11:0]));
    chk(test_done && test_pass, "JTAG-driven MBIST: probe status pins");
    j_reg_write(ta(TA_R_MODE_CTRL), MODE_NORMAL, jst);
    j_idle(200);
  endtask

  // ================================================================ 11. error propagation to RAS
  task automatic t_error_prop();
    logic [31:0] st, res, rd, first, fa;
    logic e;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    cpu_wr(ta(TA_R_ERR_IRQ_EN), 32'(1 << TA_EC_MBIST_FAIL));
    cpu_wr(ta(TA_R_IRQ_EN), 32'h4);
    enter_mode(MODE_MBIST, 1);
    // memory failure
    inject(1, 2, 2, 77, 3, 0, 0);
    page_test(1, 4'b0100, ALG_MARCH_C_MINUS, 1'b1, st);
    chk(st[3], "error_prop: injected fault not detected");
    chk(irq, "error_prop: irq not raised for MBIST_FAIL");
    // the re-initialisation sweep ran with the stuck-at cell present, so that word holds bad
    // parity; once the (simulated) defect is gone, a passing session re-initialises it
    inject(1, 2, 0, 0, 0, 0, 0);
    page_test(1, 4'b0100, ALG_MARCH_C_MINUS, 1'b0, st);
    chk(st[2], "error_prop: bank does not pass after the fault was removed");
    // functional master ignores the quiesce protocol: blocked, flagged once, test unaffected
    m_rogue[3] = 1'b1; m_en = 1'b1;
    page_test(2, 4'b0011, ALG_MARCH_C_MINUS, 1'b0, st);
    chk(st[2], "error_prop: intrusion corrupted the memory test");
    cpu_rd(pg(2, R_ERROR_FLAGS), rd); chk(rd[EF_INTRUSION], "error_prop: ERROR_FLAGS.INTRUSION not set");
    m_rogue[3] = 1'b0;
    repeat (500) @(posedge clk);
    // ownership timeout
    m_noack[3] = 1'b1;
    seq_run(3'b100, 1'b0, ALG_MARCH_C_MINUS, 32'd0, st, res);
    m_noack[3] = 1'b0; m_en = 1'b0;
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h4);
    // sequence-level refusal (no group) and a bus error (unmapped page)
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h0);
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1);
    bus(1'b0, 1'b1, 12'hC00, 32'd0, rd, e);
    chk(e, "error_prop: unmapped page did not return an error");
    repeat (20) @(posedge clk);
    // ---- TA bookkeeping
    cpu_rd(ta(TA_R_ERR_FIRST), first); cpu_rd(ta(TA_R_ERR_FIRST_ADDR), fa);
    chk(first[31] && first[27:24] == TA_EC_MBIST_FAIL && first[29:28] == TA_SEV_ERROR && first[23:16] == 8'd1 &&
        first[15:8] == 8'd2 && fa == 32'd77, $sformatf("ERR_FIRST %08h / %08h", first, fa));
    cpu_rd(ta(TA_R_ERR_STATUS), rd);
    chk(rd[TA_EC_MBIST_FAIL] && rd[TA_EC_INTRUSION] && rd[TA_EC_OWNER_FAULT] && rd[TA_EC_REFUSED] && rd[TA_EC_BUS_ERR] &&
        !rd[TA_EC_RAS_LOST], $sformatf("ERR_STATUS %03h", rd));
    cpu_rd(ta(TA_R_ERR_CNT0 + 9'(4 * TA_EC_MBIST_FAIL)), rd); chk(rd == 1, $sformatf("ERR_CNT[MBIST_FAIL] %0d", rd));
    cpu_rd(ta(TA_R_ERR_CNT0 + 9'(4 * TA_EC_INTRUSION)), rd);  chk(rd == 1, $sformatf("ERR_CNT[INTRUSION] %0d (one per episode)", rd));
    cpu_rd(ta(TA_R_SEV_STATUS), rd); chk(rd[2] && rd[1] && rd[5:4] == TA_SEV_ERROR, $sformatf("SEV_STATUS %08h", rd));
    // ---- RAS log content
    ras_drain();
    for (int i = 0; i < rl_n; i++)
      $display("RAS_LOG[%0d] type=%0d sev=%0d addr_v=%0d addr=%08h info=%08h", i, rl_typ[i], rl_sev[i],
               rl_av[i], rl_addr[i], rl_info[i]);
    chk(ras_count(TA_RAS_MEM_UE, TA_EC_MBIST_FAIL, 1) == 1, "RAS: MBIST_FAIL (MEM_UE) for group 1");
    chk(ras_count(TA_RAS_ILLEGAL_OP, TA_EC_INTRUSION, 2) == 1, "RAS: INTRUSION (ILLEGAL_OP) for group 2");
    chk(ras_count(TA_RAS_TIMEOUT, TA_EC_OWNER_FAULT, 2) == 1, "RAS: OWNER_FAULT (TIMEOUT) for group 2");
    chk(ras_count(TA_RAS_ILLEGAL_OP, TA_EC_REFUSED, 255) >= 1, "RAS: sequence REFUSED (ILLEGAL_OP)");
    for (int i = 0; i < rl_n; i++) begin
      if (rl_typ[i] == TA_RAS_MEM_UE)
        chk(rl_sev[i] == TA_SEV_ERROR && rl_av[i] && rl_addr[i] == 77 && rl_info[i][15:8] == 8'd2,
            $sformatf("RAS MEM_UE record: sev %0d addr %0d bank %0d", rl_sev[i], rl_addr[i], rl_info[i][15:8]));
      if (rl_typ[i] == TA_RAS_ILLEGAL_OP) chk(rl_sev[i] == TA_SEV_WARN, "RAS ILLEGAL_OP severity");
      if (rl_typ[i] == TA_RAS_TIMEOUT)    chk(rl_sev[i] == TA_SEV_ERROR, "RAS TIMEOUT severity");
    end
    cpu_rd(ta(TA_R_RAS_STATUS), rd);
    chk(rd[15:0] == 16'(rl_n) && rd[31:16] == 0, $sformatf("RAS_STATUS %08h, %0d records", rd, rl_n));
    ras_rd(`SFRAS_R_STATUS, rd);
    chk(rd[`SFRAS_STATUS_SEEN_WARN_LSB] && rd[`SFRAS_STATUS_SEEN_ERROR_LSB], $sformatf("RAS STATUS %08h", rd));
    chk(ras_irq_ctrl, "RAS did not interrupt the ControlCore");
    // interrupt clear
    cpu_wr(ta(TA_R_IRQ_STATUS), 32'h7);
    for (int g = 0; g < NG; g++) cpu_wr(pg(g, R_IRQ_STATUS), 32'h7);
    repeat (2) @(posedge clk);
    chk(!irq, "irq still asserted after W1C");
    leave_mbist();
    traffic(1000);
  endtask

  // ================================================================ 12. recovery after abort / complete sessions
  task automatic t_recovery();
    logic [31:0] st, res, rd;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    m_en = 1'b1;
    repeat (2000) @(posedge clk);
    enter_mode(MODE_MBIST, 1);
    // abort the sequence while group 1 runs
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h7);
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1);
    wait (u_ta.sq_cur_group == 3'd1 && u_ta.sq_cur_phase == TA_GS_RUN);
    repeat (3000) @(posedge clk);
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h2);
    wait_reg(ta(TA_R_SEQ_STATUS), 32'h3, 32'h2, 200000, "aborted sequence end", st);
    cpu_rd(ta(TA_R_SEQ_RESULT), res);
    chk(res[11:0] == 12'h031, $sformatf("abort: SEQ_RESULT %03h (expected g0 PASS, g1 ABORTED, g2 NOT_RUN)", res[11:0]));
    repeat (3000) @(posedge clk);
    // complete sequence again with traffic, then leave test mode
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h4);
    seq_run(3'b111, 1'b0, ALG_MATS_PLUS, 32'd0, st, res);
    chk(res[11:0] == 12'h111, $sformatf("recovery: SEQ_RESULT %03h", res[11:0]));
    leave_mbist();
    repeat (4000) @(posedge clk);
    m_en = 1'b0; repeat (50) @(posedge clk);
    chk(u_m0.n_rsp > 1000 && u_m1.n_rsp > 1000 && u_m2.n_rsp > 1000 && u_m3.n_rsp > 1000, "recovery: too little traffic");
  endtask

  // ================================================================ 13. abort, PROTECT, refused starts, register guards
  task automatic t_abort_protect();
    logic [31:0] st, res, rd;
    logic e;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    // START outside MBIST mode
    cpu_wr(pg(1, R_BANK_MASK), 32'h1);
    cpu_wr(pg(1, R_TEST_CONTROL), 32'h1);
    repeat (4) @(posedge clk);
    cpu_rd(pg(1, R_ERROR_FLAGS), rd); chk(rd[EF_ILLEGAL_START], "START outside MBIST mode not refused");
    cpu_wr(pg(1, R_BANK_MASK), 32'h0);
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h7); cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1);
    repeat (4) @(posedge clk);
    cpu_rd(ta(TA_R_SEQ_RESULT), res); chk(res[11:0] == 12'h666, $sformatf("sequence outside MBIST mode: %03h", res[11:0]));
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h4);
    // group-page global registers are refused
    bus(1'b1, 1'b1, pg(0, R_MODE_CTRL), 32'(MODE_MBIST), rd, e); chk(e, "group-page MODE_CTRL write accepted");
    bus(1'b1, 1'b1, pg(0, R_UNLOCK), TC_UNLOCK_KEY, rd, e);       chk(e, "group-page UNLOCK write accepted");
    cpu_rd(ta(TA_R_MODE_STATUS), rd); chk(rd[2:0] == MODE_NORMAL && !rd[5], "group-page write changed the mode");
    bus(1'b0, 1'b1, 12'h800, 32'd0, rd, e); chk(e, "page beyond the last group accepted");
    // a wrong unlock key never enables the destructive mode
    cpu_wr(ta(TA_R_UNLOCK), TC_UNLOCK_KEY ^ 32'h1);
    cpu_wr(ta(TA_R_MODE_CTRL), 32'(MODE_MBIST));
    repeat (4) @(posedge clk);
    cpu_rd(ta(TA_R_MODE_STATUS), rd); chk(rd[2:0] == MODE_NORMAL && !rd[5], "MBIST entered with a wrong unlock key");
    enter_mode(MODE_MBIST, 1);
    // PROTECT: bank 0 of group 1 holds live CPU state
    cpu_wr(pg(1, R_PROTECT), 32'h1);
    seq_run(3'b010, 1'b0, ALG_MATS_PLUS, 32'd0, st, res);
    chk(nib(res, 1) == TA_RES_REFUSED, $sformatf("PROTECT, CPU running: result %0d", nib(res, 1)));
    cpu_halted = 1'b1;
    seq_run(3'b010, 1'b0, ALG_MATS_PLUS, 32'd0, st, res);
    chk(nib(res, 1) == TA_RES_PASS, $sformatf("PROTECT, CPU halted: result %0d", nib(res, 1)));
    cpu_halted = 1'b0;
    // page START ignored while the sequencer owns the group
    cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h1);
    cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1);
    wait (u_ta.sq_cur_phase == TA_GS_RUN);
    cpu_wr(pg(0, R_ERROR_FLAGS), 32'h7FF);
    cpu_wr(pg(0, R_TEST_CONTROL), (32'(ALG_WALK_ONE) << 4) | 32'h1);
    repeat (4) @(posedge clk);
    cpu_rd(pg(0, R_ERROR_FLAGS), rd); chk(rd[EF_ILLEGAL_START], "page START while sequenced not flagged");
    cpu_rd(pg(0, R_TEST_ALGO), rd);   chk(rd[3:0] == ALG_MARCH_C_MINUS, "page START changed the running algorithm");
    // sequence-level protection while running: group set frozen, a second START refused and counted
    begin
      logic [31:0] c0, c1;
      cpu_rd(ta(TA_R_ERR_CNT0 + 9'(4 * TA_EC_REFUSED)), c0);
      cpu_wr(ta(TA_R_SEQ_GROUPS), 32'h6);
      cpu_rd(ta(TA_R_SEQ_GROUPS), rd); chk(rd == 32'h1, $sformatf("SEQ_GROUPS changed under a running sequence: %0h", rd));
      cpu_wr(ta(TA_R_SEQ_CTRL), 32'h1);
      repeat (4) @(posedge clk);
      cpu_rd(ta(TA_R_ERR_CNT0 + 9'(4 * TA_EC_REFUSED)), c1);
      chk(c1 == c0 + 1, $sformatf("START while running: REFUSED count %0d -> %0d", c0, c1));
      chk(u_ta.sq_busy, "START while running disturbed the sequence");
    end
    wait_reg(ta(TA_R_SEQ_STATUS), 32'h3, 32'h2, 2000000, "sequence", st);
    cpu_rd(ta(TA_R_SEQ_RESULT), res); chk(nib(res, 0) == TA_RES_PASS, "sequenced group disturbed by page START");
    // ERR_FIRST holds the first event until software re-arms it with a write
    cpu_rd(ta(TA_R_ERR_FIRST), rd); chk(rd[31], $sformatf("ERR_FIRST not valid after events: %08h", rd));
    cpu_wr(ta(TA_R_ERR_FIRST), 32'd0);
    cpu_rd(ta(TA_R_ERR_FIRST), rd); chk(!rd[31], $sformatf("ERR_FIRST not cleared by a write: %08h", rd));
    cpu_rd(ta(TA_R_ERR_FIRST_ADDR), rd); chk(rd == 32'd0, "ERR_FIRST_ADDR not cleared with ERR_FIRST");
    // page ABORT
    m_en = 1'b1;
    cpu_wr(pg(0, R_BANK_MASK), 32'hF);
    wait_reg(pg(0, R_OWNER_STATUS), 32'h7, 32'(OWN_TEST_ACTIVE), 20000, "acquire", rd);
    cpu_wr(pg(0, R_TEST_CONTROL), 32'h1);
    repeat (5000) @(posedge clk);
    cpu_wr(pg(0, R_TEST_CONTROL), 32'h2);
    wait_reg(pg(0, R_TEST_STATUS), 32'h3, 32'h2, 200000, "abort", st);
    chk(st[4], $sformatf("page ABORT: TEST_STATUS %08h", st));
    cpu_rd(pg(0, R_LAST_RESULT), rd); chk(rd[2:0] == RES_ABORTED, "page ABORT: LAST_RESULT");
    cpu_wr(pg(0, R_BANK_MASK), 32'h0);
    wait_released(0);
    leave_mbist();
    repeat (2000) @(posedge clk);
    m_en = 1'b0; repeat (50) @(posedge clk);
  endtask

  // ================================================================ 14. DFT clock / reset controls
  int clkreq_miss = 0;
  always @(posedge clk) if (rst_n) begin
    for (int g = 0; g < NG; g++) if (tst_active[g] && !mbist_clk_req[g]) clkreq_miss = clkreq_miss + 1;
  end
  task automatic t_dft_clkrst();
    logic [31:0] st, rd;
    set_lc_std(TA_LC_DEV, 1'b0); sys_reset();
    chk(!dft_test_mode && !dft_icg_te && !dft_scan_en && dft_test_rst_n && !dft_mem_inhibit && mbist_clk_req == 0,
        "functional mode: DFT controls not inactive");
    @(negedge clk); scan_mode_pin = 1'b1; scan_en_pin = 1'b1; test_rst_n_pin = 1'b0; #1;
    chk(dft_test_mode && dft_icg_te && dft_scan_en && dft_mem_inhibit && !dft_test_rst_n && mode == MODE_SCAN_SHIFT,
        "scan shift: DFT controls");
    @(negedge clk); test_rst_n_pin = 1'b1; scan_en_pin = 1'b0; #1;
    chk(dft_test_mode && dft_icg_te && !dft_scan_en && dft_test_rst_n && mode == MODE_SCAN_CAPTURE, "scan capture: DFT controls");
    repeat (6) @(posedge clk);
    cpu_rd(ta(TA_R_CLKRST_STATUS), rd); chk(rd[8] && rd[11], $sformatf("CLKRST_STATUS %08h", rd));
    cpu_rd(ta(TA_R_SCAN_STATUS), rd);   chk(rd[0] && rd[2] && rd[3], $sformatf("SCAN_STATUS %08h", rd));
    cpu_wr(ta(TA_R_UNLOCK), TC_UNLOCK_KEY);
    cpu_wr(ta(TA_R_MODE_CTRL), MODE_MBIST);
    repeat (3) @(posedge clk);
    chk(mode == MODE_SCAN_CAPTURE && !u_ta.mbist_enable, "register mode request honoured during scan");
    @(negedge clk); scan_mode_pin = 1'b0;
    sys_reset();                                                     // leaving scan requires a reset (TestCore rule)
    // the clock request covers exactly the test session of each group
    clkreq_miss = 0;
    enter_mode(MODE_MBIST, 1);
    seq_run(3'b111, 1'b0, ALG_MATS_PLUS, 32'd0, st, rd);
    chk(clkreq_miss == 0, $sformatf("%0d cycles with a group under test but no clock request", clkreq_miss));
    repeat (10) @(posedge clk);
    chk(mbist_clk_req == 0, "clock request left asserted after the sequence");
    leave_mbist();
  endtask
