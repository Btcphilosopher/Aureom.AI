// =============================================================================
// SilicaFlux -- Project 108 -- PageWalker :: sf_iommu_perf
//
// Hardware performance counters (32 bit, SATURATING -- they never wrap), read through CNT_SEL / CNT_DATA.
// Derived metrics are computed by software from these raw counts:
//   TLB hit rate        = TLB_HIT / (TLB_HIT + TLB_MISS)
//   page-walk cycles    = WALK_CYC / WALKS             (and WALK_MAX)
//   memory refs / walk  = WALK_REFS / WALKS
//   translation latency = LAT_SUM / LAT_N              (and LAT_MAX)    handshake -> first response valid
//   DMA stalls          = REQ_STALL (request waiting for the translator) and RSP_STALL (response waiting for the DMA)
// The counter map is rtl/iommu/sf_iommu_defs.svh (SFIO_CN_*).
// =============================================================================
`default_nettype none
`include "sf_iommu_defs.svh"
module sf_iommu_perf (
  input  wire        clk,
  input  wire        rst_n,
  // one-cycle event pulses
  input  wire        ev_req, ev_seg, ev_hit, ev_miss, ev_walk, ev_walk_fault, ev_fill, ev_evict, ev_torn, ev_fab_tmo, ev_stray,
  input  wire        ev_cfg_rej, ev_ctx_commit, ev_inv_done, ev_inv_tmo, ev_fault,
  input  wire [3:0]  ev_fault_cause,
  input  wire        ev_req_stall, ev_rsp_stall, ev_inv_block,
  // valued events
  input  wire        walk_done_evt,
  input  wire [15:0] walk_cycles,
  input  wire [7:0]  walk_refs,
  input  wire        lat_evt,
  input  wire [15:0] lat_cycles,
  // CSR slice
  input  wire        csr_wr,
  input  wire [4:0]  csr_idx,
  input  wire [31:0] csr_wdata,
  output reg  [31:0] csr_rdata,
  output reg         csr_hit
);
  localparam integer NC = `SFIO_NCNT;
  reg [NC*32-1:0] cnt;
  reg [NC*32-1:0] incv;
  reg [31:0]      sel_q;
  integer         ia, ib, ic;

  always @* begin
    incv = {(NC*32){1'b0}};
    incv[`SFIO_CN_REQS*32      +: 32] = {31'd0, ev_req};
    incv[`SFIO_CN_SEGS*32      +: 32] = {31'd0, ev_seg};
    incv[`SFIO_CN_TLB_HIT*32   +: 32] = {31'd0, ev_hit};
    incv[`SFIO_CN_TLB_MISS*32  +: 32] = {31'd0, ev_miss};
    incv[`SFIO_CN_WALKS*32     +: 32] = {31'd0, ev_walk};
    incv[`SFIO_CN_WALK_CYC*32  +: 32] = walk_done_evt ? {16'd0, walk_cycles} : 32'd0;
    incv[`SFIO_CN_WALK_REFS*32 +: 32] = walk_done_evt ? {24'd0, walk_refs}   : 32'd0;
    incv[`SFIO_CN_WALK_FAULT*32 +: 32] = {31'd0, ev_walk_fault};
    incv[`SFIO_CN_LAT_SUM*32   +: 32] = lat_evt ? {16'd0, lat_cycles} : 32'd0;
    incv[`SFIO_CN_LAT_N*32     +: 32] = {31'd0, lat_evt};
    incv[`SFIO_CN_INV_DONE*32  +: 32] = {31'd0, ev_inv_done};
    incv[`SFIO_CN_INV_TMO*32   +: 32] = {31'd0, ev_inv_tmo};
    incv[`SFIO_CN_FAULTS*32    +: 32] = {31'd0, ev_fault};
    incv[`SFIO_CN_REQ_STALL*32 +: 32] = {31'd0, ev_req_stall};
    incv[`SFIO_CN_RSP_STALL*32 +: 32] = {31'd0, ev_rsp_stall};
    incv[`SFIO_CN_FILLS*32     +: 32] = {31'd0, ev_fill};
    incv[`SFIO_CN_EVICTS*32    +: 32] = {31'd0, ev_evict};
    incv[`SFIO_CN_TORN*32      +: 32] = {31'd0, ev_torn};
    incv[`SFIO_CN_FAB_TMO*32   +: 32] = {31'd0, ev_fab_tmo};
    incv[`SFIO_CN_STRAY*32     +: 32] = {31'd0, ev_stray};
    incv[`SFIO_CN_CFG_REJ*32   +: 32] = {31'd0, ev_cfg_rej};
    incv[`SFIO_CN_CTX_COMMIT*32 +: 32] = {31'd0, ev_ctx_commit};
    incv[`SFIO_CN_INV_BLOCK*32 +: 32] = {31'd0, ev_inv_block};
    for (ia = 0; ia < 16; ia = ia + 1) begin
      incv[(`SFIO_CN_RSP_FAULT0 + ia)*32 +: 32] = {31'd0, (ev_fault && (ev_fault_cause == ia[3:0]))};
    end
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cnt   <= {(NC*32){1'b0}};
      sel_q <= 32'd0;
    end else begin
      if (csr_wr && csr_idx == `SFIO_R_CNT_SEL) sel_q <= csr_wdata;
      for (ib = 0; ib < NC; ib = ib + 1) begin
        if (ib == `SFIO_CN_WALK_MAX) begin
          if (walk_done_evt && ({16'd0, walk_cycles} > cnt[ib*32 +: 32])) cnt[ib*32 +: 32] <= {16'd0, walk_cycles};
        end else if (ib == `SFIO_CN_LAT_MAX) begin
          if (lat_evt && ({16'd0, lat_cycles} > cnt[ib*32 +: 32])) cnt[ib*32 +: 32] <= {16'd0, lat_cycles};
        end else begin
          cnt[ib*32 +: 32] <= ((32'hFFFF_FFFF - cnt[ib*32 +: 32]) < incv[ib*32 +: 32]) ? 32'hFFFF_FFFF
                                                                                            : (cnt[ib*32 +: 32] + incv[ib*32 +: 32]);   // saturate, never wrap
        end
      end
    end
  end

  always @* begin
    ic        = 0;
    csr_hit   = 1'b1;
    csr_rdata = 32'd0;
    case (csr_idx)
      `SFIO_R_CNT_SEL:  csr_rdata = sel_q;
      `SFIO_R_CNT_DATA: begin
        csr_rdata = 32'd0;
        ic = 0;
        for (ic = 0; ic < NC; ic = ic + 1) if (sel_q == ic) csr_rdata = cnt[ic*32 +: 32];
      end
      `SFIO_R_NCNT:     csr_rdata = NC;
      default:          begin csr_hit = 1'b0; csr_rdata = 32'd0; end
    endcase
  end

`ifdef FORMAL
  // Formal (formal/iommu/fv_perf.sv): every counter is monotone non-decreasing between resets -- it SATURATES and never wraps.
  reg f_init;
  initial f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  reg [NC*32-1:0] f_cnt_q;
  reg             f_rstn_q;
  always @(posedge clk) begin f_cnt_q <= cnt; f_rstn_q <= rst_n; end
  integer fz;
  always @* begin
    if (!f_init && f_rstn_q && rst_n) begin
      for (fz = 0; fz < NC; fz = fz + 1) assert (cnt[fz*32 +: 32] >= f_cnt_q[fz*32 +: 32]);
    end
  end
`endif
endmodule
`default_nettype wire
