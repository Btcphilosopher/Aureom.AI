// =============================================================================
// SilicaFlux -- Project 108 -- PageWalker :: sf_iommu_walk_fsm
//
// ONE Sv39 page-table walk at a time, over DataFabric SFB2 read transactions.  The algorithm is docs/01 section 5, step for step.
//
//   W_IDLE --walk_start--> W_REQ (present the read; held until accepted)  -> W_RSP (wait for the response)
//          -> [more beats of this PTE: W_REQ] -> W_DECODE -> {descend: W_REQ | leaf / fault: W_DONE} -> W_IDLE
//
// BOUNDED BY CONSTRUCTION (no undefined loops):  at most 3 levels (the level counter only decrements); at most 3 beats per PTE attempt;
// at most RETRY_MAX + 1 attempts per PTE; each beat waits at most WALK_TMO cycles.  => the walk ends within
// 3 * 3 * (RETRY_MAX + 1) * WALK_TMO + small cycles under ANY fabric behaviour.  Every path ends in W_DONE with exactly one result.
//
// THE WALKER NEVER WRITES: m_req_write is not driven by any state (it is a constant 0 at the top); no A/D update (Svade).
//
// FABRIC PORT DISCIPLINE (SFB2 R2 / R5 / R6):
//   * a presented read is held, address unchanged, until accepted -- even after the walk gave up on it (timeout);
//   * one transaction outstanding; if a walk times out the transaction stays "owed" (orph_req / orph_rsp = the port is WEDGED):
//     a late response is DISCARDED (never mistaken for the next walk's), and a new walk is refused immediately with F_PHYS_READ
//     until the port is free again (or reset).  A response with nothing owed is counted as STRAY and discarded.
//
// TORN-READ SAFETY (DW = 32, PTE_DOUBLE_READ = 1): a PTE is read low, high, low; a changed low word re-reads the PTE (<= RETRY_MAX times),
// then F_INVALID_PTE.  With the update protocol of docs/01 section 9 every accepted PTE is a consistent snapshot.
// =============================================================================
`default_nettype none
`include "sf_iommu_defs.svh"
/* verilator lint_off UNSIGNED */   // RETRY_MAX = 0 makes `retry_q < RETRY_MAX` constant: a legal 'never retry' configuration
module sf_iommu_walk_fsm #(
  parameter integer PPN_W           = 20,     // PA_W - 12: leaf PPN limit
  parameter integer FAB_AW          = 32,
  parameter integer FAB_PPN_W       = 20,     // FAB_AW - 12: next-table limit
  parameter integer DW              = 32,     // 32 or 64
  parameter integer VPN_W           = 27,
  parameter integer SUPERPAGE_EN    = 0,
  parameter integer PTE_DOUBLE_READ = 1,
  parameter integer RETRY_MAX       = 2,
  parameter integer WALK_TMO        = 64      // cycles per beat (request presented -> response), >= 4
) (
  input  wire                 clk,
  input  wire                 rst_n,
  // walk request (one-cycle pulse; ignored unless idle)
  input  wire                 walk_start,
  input  wire [FAB_PPN_W-1:0] walk_root,                  // validated at programming time to lie below 2**FAB_PPN_W
  input  wire [VPN_W-1:0]     walk_vpn,
  output wire                 walk_busy,
  // result: walk_done is a one-cycle pulse; the fields are held until the next walk_start
  output wire                 walk_done,
  output wire [3:0]           walk_fault,        // F_NONE (leaf found) or the cause
  output wire [1:0]           walk_level,        // level of the leaf / of the fault
  output wire [PPN_W-1:0]     walk_ppn,
  output wire [1:0]           walk_psize,
  output wire                 walk_r_ok,
  output wire                 walk_w_ok,
  output wire [15:0]          walk_cycles,       // walk_start cycle .. cycle before walk_done
  output wire [7:0]           walk_refs,         // fabric reads accepted by this walk
  // SFB2 read master
  output wire                 m_req_valid,
  input  wire                 m_req_ready,
  output wire [FAB_AW-1:0]    m_req_addr,
  input  wire                 m_rsp_valid,
  output wire                 m_rsp_ready,
  input  wire [DW-1:0]        m_rsp_rdata,
  input  wire                 m_rsp_error,
  // status / events
  output wire                 fab_wedged,
  output wire                 ev_torn,
  output wire                 ev_fab_tmo,
  output wire                 ev_fab_err,
  output wire                 ev_stray
);
  localparam [2:0] W_IDLE = 3'd0, W_REQ = 3'd1, W_RSP = 3'd2, W_DECODE = 3'd3, W_DONE = 3'd4;
  localparam integer PTE_BEATS = (DW == 64) ? 1 : 2;
  localparam integer NB        = (PTE_BEATS == 2 && PTE_DOUBLE_READ != 0) ? 3 : PTE_BEATS;
  localparam integer TMO_LAST_I = WALK_TMO - 1;
  localparam integer NB_LAST_I  = NB - 1;
  localparam [15:0]  TMO_LAST   = TMO_LAST_I[15:0];
  localparam [1:0]   NB_LAST    = NB_LAST_I[1:0];
  localparam [3:0]   RETRY_MAXV = RETRY_MAX[3:0];

  reg [2:0]            wst;
  reg [FAB_PPN_W-1:0]  tbl_q;                 // current page-table page
  reg [VPN_W-1:0]      vpn_q;
  reg [1:0]            lvl_q;                 // 2, 1, 0
  reg [1:0]            b_q;                   // beat of the current PTE attempt
  reg [3:0]            retry_q;
  reg [31:0]           pte_lo, pte_hi;
  reg [15:0]           tmo_q;
  reg [15:0]           cyc_q;
  reg [7:0]            refs_q;
  reg                  orph_req, orph_rsp;    // the fabric still owes us (or still waits for) a transaction of an abandoned read

  // result registers
  reg [3:0]            res_fault;
  reg [1:0]            res_level, res_psize;
  reg [PPN_W-1:0]      res_ppn;
  reg                  res_r, res_w;

  assign walk_busy  = (wst != W_IDLE);
  assign walk_done  = (wst == W_DONE);
  assign walk_fault = res_fault;
  assign walk_level = res_level;
  assign walk_ppn   = res_ppn;
  assign walk_psize = res_psize;
  assign walk_r_ok  = res_r;
  assign walk_w_ok  = res_w;
  assign walk_cycles = cyc_q + 16'd1;
  assign walk_refs   = refs_q;
  assign fab_wedged  = orph_req | orph_rsp;

  // ---------------------------------------------------------------- the read being presented (combinational from registers: stable while presented)
  wire [8:0]  vpn_idx = (lvl_q == 2'd2) ? vpn_q[26:18] : ((lvl_q == 2'd1) ? vpn_q[17:9] : vpn_q[8:0]);
  wire [FAB_AW-1:0] pte_base = {tbl_q, 12'd0} + {{(FAB_AW-12){1'b0}}, vpn_idx, 3'd0};
  wire [FAB_AW-1:0] boff     = (DW == 32 && b_q == 2'd1) ? {{(FAB_AW-3){1'b0}}, 3'd4} : {FAB_AW{1'b0}};
  assign m_req_addr  = pte_base + boff;
  assign m_req_valid = (wst == W_REQ) | orph_req;
  assign m_rsp_ready = 1'b1;                                   // every response is consumed in the cycle it is presented

  // ---------------------------------------------------------------- PTE decode (docs/01 section 5, steps 1-7)
  /* verilator lint_off UNUSEDSIGNAL */
  wire [63:0] pte_w = {pte_hi, pte_lo};                        // the assembled PTE (RSW and G are ignored by design)
  /* verilator lint_on UNUSEDSIGNAL */
  wire        p_v = pte_w[`SFIO_PTE_V], p_r = pte_w[`SFIO_PTE_R], p_w = pte_w[`SFIO_PTE_W], p_x = pte_w[`SFIO_PTE_X];
  wire        p_u = pte_w[`SFIO_PTE_U], p_a = pte_w[`SFIO_PTE_A], p_d = pte_w[`SFIO_PTE_D];
  wire [43:0] p_ppn = pte_w[`SFIO_PTE_PPN_HI:`SFIO_PTE_PPN_LO];
  wire        p_rsv = (pte_w[63:54] != 10'd0);
  wire        p_big_leaf = ((p_ppn >> PPN_W) != 44'd0);
  wire        p_big_ptr  = ((p_ppn >> FAB_PPN_W) != 44'd0);
  wire        misal1     = (p_ppn[8:0]  != 9'd0);
  wire        misal2     = (p_ppn[17:0] != 18'd0);

  reg [3:0] d_fault;
  reg       d_leaf;
  always @* begin
    d_fault = `SFIO_F_NONE; d_leaf = 1'b0;
    if (!p_v)                                       d_fault = `SFIO_F_NOT_PRESENT;                  // 1
    else if (p_rsv)                                 d_fault = `SFIO_F_INVALID_PTE;                  // 2
    else if (p_w && !p_r)                           d_fault = `SFIO_F_INVALID_PTE;                  // 3
    else if (p_r || p_x) begin                                                                      // 4: leaf
      if (lvl_q != 2'd0 && SUPERPAGE_EN == 0)       d_fault = `SFIO_F_PAGE_SIZE;                    // 5
      else if (lvl_q == 2'd2 && misal2)             d_fault = `SFIO_F_MALFORMED;
      else if (lvl_q == 2'd1 && misal1)             d_fault = `SFIO_F_MALFORMED;
      else if (p_big_leaf)                          d_fault = `SFIO_F_ADDR_OVERFLOW;                // 6
      else                                          d_leaf  = 1'b1;
    end else begin                                                                                  // 7: pointer
      if (p_a || p_d || p_u)                        d_fault = `SFIO_F_INVALID_PTE;
      else if (lvl_q == 2'd0)                       d_fault = `SFIO_F_MALFORMED;
      else if (p_big_ptr)                           d_fault = `SFIO_F_MALFORMED;
      else                                          d_leaf  = 1'b0;                                  // descend
    end
  end

  // ---------------------------------------------------------------- events
  wire rsp_for_walk = m_rsp_valid && (wst == W_RSP);
  wire rsp_orphan   = m_rsp_valid && orph_rsp && (wst != W_RSP);
  wire timed_out    = ((wst == W_REQ) || (wst == W_RSP)) && !rsp_for_walk && (tmo_q >= TMO_LAST);
  wire last_beat    = (b_q == NB_LAST);
  wire torn         = rsp_for_walk && !m_rsp_error && (DW == 32) && (PTE_DOUBLE_READ != 0) && (b_q == 2'd2) && (m_rsp_rdata[31:0] != pte_lo);
  assign ev_torn    = torn && (retry_q < RETRY_MAXV);
  assign ev_fab_tmo = timed_out;
  assign ev_fab_err = rsp_for_walk && m_rsp_error;
  assign ev_stray   = m_rsp_valid && (wst != W_RSP) && !orph_rsp;

  // ---------------------------------------------------------------- sequencer
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wst <= W_IDLE; tbl_q <= {FAB_PPN_W{1'b0}}; vpn_q <= {VPN_W{1'b0}}; lvl_q <= 2'd0; b_q <= 2'd0; retry_q <= 4'd0;
      pte_lo <= 32'd0; pte_hi <= 32'd0; tmo_q <= 16'd0; cyc_q <= 16'd0; refs_q <= 8'd0; orph_req <= 1'b0; orph_rsp <= 1'b0;
      res_fault <= `SFIO_F_NONE; res_level <= 2'd0; res_psize <= 2'd0; res_ppn <= {PPN_W{1'b0}}; res_r <= 1'b0; res_w <= 1'b0;
    end else begin
      // ---- orphan resolution (an abandoned read): accepted -> awaiting response -> response discarded
      if (orph_req && m_req_ready) begin orph_req <= 1'b0; orph_rsp <= 1'b1; end
      if (rsp_orphan)              orph_rsp <= 1'b0;

      if (wst != W_IDLE && wst != W_DONE && cyc_q != 16'hFFFF) cyc_q <= cyc_q + 16'd1;
      if (((wst == W_REQ) || (wst == W_RSP))) tmo_q <= tmo_q + 16'd1;

      case (wst)
        W_IDLE: begin
          if (walk_start) begin
            if (orph_req || orph_rsp) begin               // the port still owes a response of an abandoned read: refuse (nothing latched)
              res_fault <= `SFIO_F_PHYS_READ; res_level <= 2'd2; res_psize <= 2'd0; res_ppn <= {PPN_W{1'b0}}; res_r <= 1'b0; res_w <= 1'b0;
              cyc_q <= 16'd0; refs_q <= 8'd0;
              wst <= W_DONE;
            end else begin
              tbl_q <= walk_root; vpn_q <= walk_vpn; lvl_q <= 2'd2; b_q <= 2'd0; retry_q <= 4'd0;
              tmo_q <= 16'd0; cyc_q <= 16'd0; refs_q <= 8'd0;
              res_fault <= `SFIO_F_NONE; res_level <= 2'd2; res_psize <= 2'd0; res_ppn <= {PPN_W{1'b0}}; res_r <= 1'b0; res_w <= 1'b0;
              wst <= W_REQ;
            end
          end
        end

        W_REQ: begin
          if (m_req_ready) begin
            wst <= W_RSP;
            if (refs_q != 8'hFF) refs_q <= refs_q + 8'd1;
          end
          if (timed_out) begin                              // give up, but the read stays presented / owed
            orph_req <= !m_req_ready;
            orph_rsp <= m_req_ready;
            res_fault <= `SFIO_F_PHYS_READ; res_level <= lvl_q;
            wst <= W_DONE;
          end
        end

        W_RSP: begin
          if (m_rsp_valid) begin
            if (m_rsp_error) begin
              res_fault <= `SFIO_F_PHYS_READ; res_level <= lvl_q; wst <= W_DONE;
            end else if (DW == 64) begin
              pte_lo <= m_rsp_rdata[31:0]; pte_hi <= m_rsp_rdata[DW-1 -: 32];
              wst <= W_DECODE;
            end else begin
              case (b_q)
                2'd0: begin pte_lo <= m_rsp_rdata[31:0]; b_q <= 2'd1; tmo_q <= 16'd0; wst <= W_REQ; end
                2'd1: begin
                  pte_hi <= m_rsp_rdata[31:0];
                  if (last_beat) wst <= W_DECODE;
                  else begin b_q <= 2'd2; tmo_q <= 16'd0; wst <= W_REQ; end
                end
                default: begin                                  // beat 2: the validating re-read of the low word
                  if (m_rsp_rdata[31:0] != pte_lo) begin
                    if (retry_q < RETRY_MAXV) begin retry_q <= retry_q + 4'd1; b_q <= 2'd0; tmo_q <= 16'd0; wst <= W_REQ; end
                    else begin res_fault <= `SFIO_F_INVALID_PTE; res_level <= lvl_q; wst <= W_DONE; end   // unstable PTE
                  end else wst <= W_DECODE;
                end
              endcase
            end
          end else if (timed_out) begin
            orph_rsp <= 1'b1;
            res_fault <= `SFIO_F_PHYS_READ; res_level <= lvl_q;
            wst <= W_DONE;
          end
        end

        W_DECODE: begin
          if (d_fault != `SFIO_F_NONE) begin
            res_fault <= d_fault; res_level <= lvl_q; wst <= W_DONE;
          end else if (d_leaf) begin
            res_fault <= `SFIO_F_NONE; res_level <= lvl_q; res_psize <= lvl_q;
            res_ppn   <= p_ppn[PPN_W-1:0];
            res_r     <= p_r & p_a & p_u;                    // docs/01 section 5: r_ok = R & A & U
            res_w     <= p_w & p_a & p_d & p_u;              //                    w_ok = W & A & D & U
            wst <= W_DONE;
          end else begin                                     // descend
            tbl_q <= p_ppn[FAB_PPN_W-1:0]; lvl_q <= lvl_q - 2'd1; b_q <= 2'd0; retry_q <= 4'd0; tmo_q <= 16'd0;
            wst <= W_REQ;
          end
        end

        W_DONE: wst <= W_IDLE;
        default: wst <= W_IDLE;
      endcase
    end
  end

`ifdef FORMAL
  // ===========================================================================================================================
  // Formal (formal/iommu/fv_walk.sv; docs/05 section 5)
  //   W1  decode equivalence: for EVERY 64-bit PTE and level, the RTL decode equals an independent statement of docs/01 section 5 steps 1-7
  //       (W1a: the fault class and the leaf / pointer decision, combinational;  W1b: what the decode LATCHES into the result registers --
  //        the fault and its level, the leaf's PPN, size and the permissions R&A&U / W&A&D&U, or the next table and level on a descent -- one
  //        cycle later, through shadow registers that hold the independent expectation)
  //   W5  address generation: a presented walk read is at  table*4096 + 8*(9-bit index of the IOVA for this level) + (4 on the high word of a 32-bit fabric)
  //   W2  legality of the state: level, beat, retry, timeout counters stay in range (=> the walk is bounded by construction)
  //   W3  fabric discipline: never a new read over an abandoned one; never present a read while one is awaiting its response
  //   W6  SFB2 discipline stated on the PORTS (not on the walker's own orphan flags): a presented read is never withdrawn or changed before it is
  //       accepted (R2), and no read is presented while an accepted read still awaits its response (R6)
  //   W7  a bus error on the response to a walk read ends the walk with PHYS_READ; a mismatching validating re-read never goes on to decode
  //   W4  a faulting walk reports NO permission; a leaf result is consistent with SUPERPAGE_EN
  // ===========================================================================================================================
  reg f_init;
  initial f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  reg [3:0] s_f;
  reg       s_leaf;
  reg [43:0] s_ppn;
  always @* begin
    s_ppn  = pte_w[53:10];
    s_f    = `SFIO_F_NONE;
    s_leaf = 1'b0;
    if (pte_w[0] == 1'b0)                                          s_f = `SFIO_F_NOT_PRESENT;
    else if (pte_w[63:54] != 10'd0)                                s_f = `SFIO_F_INVALID_PTE;
    else if (pte_w[2] == 1'b1 && pte_w[1] == 1'b0)                 s_f = `SFIO_F_INVALID_PTE;
    else if (pte_w[1] == 1'b1 || pte_w[3] == 1'b1) begin            // a leaf
      if (lvl_q != 2'd0 && SUPERPAGE_EN == 0)                      s_f = `SFIO_F_PAGE_SIZE;
      else if (lvl_q == 2'd1 && (s_ppn & 44'h1FF) != 44'd0)        s_f = `SFIO_F_MALFORMED;
      else if (lvl_q == 2'd2 && (s_ppn & 44'h3FFFF) != 44'd0)      s_f = `SFIO_F_MALFORMED;
      else if (s_ppn >= (44'd1 << PPN_W))                          s_f = `SFIO_F_ADDR_OVERFLOW;
      else                                                         s_leaf = 1'b1;
    end else begin                                                  // a pointer
      if (pte_w[6] == 1'b1 || pte_w[7] == 1'b1 || pte_w[4] == 1'b1) s_f = `SFIO_F_INVALID_PTE;
      else if (lvl_q == 2'd0)                                      s_f = `SFIO_F_MALFORMED;
      else if (s_ppn >= (44'd1 << FAB_PPN_W))                      s_f = `SFIO_F_MALFORMED;
    end
  end
  // W1b shadow: the expectation computed from the independent statement in the DECODE cycle, checked in the cycle after (rst_n guards both ends:
  // under async2sync a reset asserted in the current cycle already shows the reset values)
  reg        f_leaf_q, f_desc_q, f_flt_q;
  wire [43:0] f_res_ppn = res_ppn;                                   // zero-extended to 44 bits (no zero-width replication at PA_W = 56)
  wire [43:0] f_tbl_ext = tbl_q;
  reg  [3:0] f_fault_q;
  reg  [1:0] f_lvl_q;
  reg        f_r_q, f_w_q;
  reg [43:0] f_ppn_q;
  always @(posedge clk) begin
    f_leaf_q  <= rst_n && (wst == W_DECODE) && s_leaf;
    f_desc_q  <= rst_n && (wst == W_DECODE) && !s_leaf && (s_f == `SFIO_F_NONE);
    f_flt_q   <= rst_n && (wst == W_DECODE) && (s_f != `SFIO_F_NONE);
    f_fault_q <= s_f;
    f_lvl_q   <= lvl_q;
    f_r_q     <= pte_w[1] & pte_w[6] & pte_w[4];                     // R & A & U
    f_w_q     <= pte_w[2] & pte_w[6] & pte_w[7] & pte_w[4];          // W & A & D & U
    f_ppn_q   <= pte_w[53:10];
  end
  always @* begin
    if (!f_init && rst_n) begin
      if (f_leaf_q) begin                                           // W1b: a leaf latches exactly the independent expectation
        assert (wst == W_DONE);
        assert (res_fault == `SFIO_F_NONE);
        assert (res_level == f_lvl_q);
        assert (res_psize == f_lvl_q);
        assert (f_res_ppn == (f_ppn_q & ((44'd1 << PPN_W) - 44'd1)));
        assert (res_r == f_r_q);
        assert (res_w == f_w_q);
      end
      if (f_flt_q) begin                                            // W1b: a fault latches exactly the independent class and level
        assert (wst == W_DONE);
        assert (res_fault == f_fault_q);
        assert (res_level == f_lvl_q);
      end
      if (f_desc_q) begin                                           // W1b: a descent goes one level down, to the pointed table, from beat 0 with a fresh retry budget
        assert (wst == W_REQ);
        assert (lvl_q == f_lvl_q - 2'd1);
        assert (f_tbl_ext == (f_ppn_q & ((44'd1 << FAB_PPN_W) - 44'd1)));
        assert (b_q == 2'd0);
        assert (retry_q == 4'd0);
      end
    end
  end
  // W5: the independent address (a shift of the stored IOVA page number, not the RTL's mux)
  wire [VPN_W-1:0]  s_vsh   = vpn_q >> (9 * lvl_q);
  wire [FAB_AW-1:0] s_addr  = {tbl_q, 12'd0} + ({{(FAB_AW-9){1'b0}}, s_vsh[8:0]} << 3) + ((DW == 32 && b_q == 2'd1) ? {{(FAB_AW-3){1'b0}}, 3'd4} : {FAB_AW{1'b0}});
  // W6 / W7 shadows (port-level)
  reg                f_mreq_q, f_mrdy_q, f_out_q, f_err_q, f_torn_q;
  reg [FAB_AW-1:0]   f_maddr_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin f_mreq_q <= 1'b0; f_mrdy_q <= 1'b0; f_out_q <= 1'b0; f_err_q <= 1'b0; f_torn_q <= 1'b0; f_maddr_q <= {FAB_AW{1'b0}}; end
    else begin
      f_mreq_q  <= m_req_valid; f_mrdy_q <= m_req_ready; f_maddr_q <= m_req_addr;
      f_out_q   <= (f_out_q || (m_req_valid && m_req_ready)) && !m_rsp_valid;
      f_err_q   <= (wst == W_RSP) && m_rsp_valid && m_rsp_error;
      f_torn_q  <= (wst == W_RSP) && m_rsp_valid && !m_rsp_error && (DW == 32) && (PTE_DOUBLE_READ != 0) && (b_q == 2'd2) && (m_rsp_rdata[31:0] != pte_lo);
    end
  end
  always @* begin
    if (!f_init && rst_n) begin
      if (f_mreq_q && !f_mrdy_q) assert (m_req_valid && (m_req_addr == f_maddr_q));       // W6 / R2
      if (f_out_q) assert (!m_req_valid);                                                  // W6 / R6
      if (f_out_q) assert ((wst == W_RSP) || orph_rsp);                                    // strengthening: a read accepted and unanswered is either this walk's or an abandoned one
      if (f_err_q) assert ((wst == W_DONE) && (res_fault == `SFIO_F_PHYS_READ));           // W7: a bus error ends the walk
      if (f_torn_q) assert (((wst == W_REQ) && (b_q == 2'd0) && (retry_q != 4'd0)) ||
                            ((wst == W_DONE) && (res_fault == `SFIO_F_INVALID_PTE)));       // W7: a torn PTE is re-read or refused, never decoded
    end
  end
  always @* begin
    if (!f_init) begin
      if (wst == W_REQ) assert (m_req_addr == s_addr);                // W5
      assert (wst <= W_DONE);                                       // W2
      assert (lvl_q <= 2'd2);
      assert (b_q <= NB_LAST);
      assert (retry_q <= RETRY_MAXV);
      if (wst == W_REQ || wst == W_RSP) assert (tmo_q <= TMO_LAST);
      assert (!(orph_req && orph_rsp));                             // W3
      if (wst == W_REQ || wst == W_RSP) assert (!(orph_req || orph_rsp));
      assert (!(m_req_valid && (wst == W_RSP || orph_rsp)));
      if (wst == W_DECODE) begin                                    // W1
        assert (d_fault == s_f);
        assert (d_leaf  == s_leaf);
      end
      if (wst == W_REQ || wst == W_RSP || wst == W_DECODE) assert (!res_r && !res_w);            // strengthening: a walk in flight holds no result (cleared at start)
      if (walk_done && res_fault != `SFIO_F_NONE) assert (!res_r && !res_w);                    // W4
      if (walk_done && res_fault == `SFIO_F_NONE) begin
        assert (res_psize == res_level);
        assert (SUPERPAGE_EN != 0 || res_psize == 2'd0);
      end
    end
  end
`endif
endmodule
/* verilator lint_on UNSIGNED */
`default_nettype wire
