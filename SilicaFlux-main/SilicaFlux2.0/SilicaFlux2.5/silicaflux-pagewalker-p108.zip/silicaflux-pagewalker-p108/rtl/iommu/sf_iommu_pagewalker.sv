// =============================================================================
// SilicaFlux -- Project 108 -- PageWalker :: sf_iommu_pagewalker                                         (PRIMARY MODULE)
//
// Hardware IOMMU address translation for cloud DMA / accelerator access.  ONE translation stage (first-stage semantics), 4 KiB pages,
// a defined Sv39-compatible subset (docs/01_SPEC_SUBSET.md is normative), configurable TLB (baseline 4 entries), ONE request and ONE
// page walk at a time.  It is NOT a RISC-V IOMMU and does not claim to be.
//
//   Trusted device context -> request -> static checks -> TLB lookup -> page-table walk on a miss -> permission check -> physical address
//
//      req_*  (DMA, untrusted payload / trusted req_dev)  ------>  [ context | checks | split | TLB | walker ]  ------>  rsp_* (PA segments)
//      m_*    (SFB2 master: page-table READS only)  <----------------------------------------------^
//      cfg_*  (privileged SFB2-slave CSR port: contexts, invalidation, fault log, counters)
//
//   A request is answered by ONE response if it stays inside a 4 KiB page, by TWO (segment 0, segment 1) if it crosses one boundary, or
//   by ONE fault response.  Both pages are validated BEFORE the first segment is released: a refused second page releases nothing.
//   A refusal carries rsp_pa = 0 and issues no memory request other than the walk's own page-table reads.
//
// Request sequencer:  IDLE -> CHECK -> LOOKUP -> [WALK] -> (LOOKUP for page 1) -> RESP -> IDLE
//   req_ready = IDLE && !inv_busy        (a pending invalidation blocks the port from the cycle after the command: docs/01 section 8)
// =============================================================================
`default_nettype none
`include "sf_iommu_defs.svh"
module sf_iommu_pagewalker #(
  parameter integer TLB_ENTRIES       = 4,
  parameter integer NUM_CTX           = 4,
  parameter integer DEV_W             = 4,
  parameter integer ID_W              = 4,
  parameter integer LEN_W             = 13,
  parameter integer MAX_BYTES         = 4096,
  parameter integer PA_W              = 32,
  parameter integer FAB_AW            = 32,
  parameter integer DW                = 32,
  parameter integer FQ_DEPTH          = 4,
  parameter integer WALK_TMO          = 64,
  parameter integer RETRY_MAX         = 2,
  parameter integer PTE_DOUBLE_READ   = 1,
  parameter integer SUPERPAGE_EN      = 0,
  parameter integer DRAIN_TMO_DEFAULT = 256,
  parameter integer WAIT_DMA_QUIET    = 1
) (
  input  wire                 clk,
  input  wire                 rst_n,

  // ------------------------------------------------ translation request (DMA side)
  input  wire                 req_valid,
  output wire                 req_ready,
  input  wire [DEV_W-1:0]     req_dev,              // TRUSTED sideband: selects the device context
  input  wire                 req_claim_valid,      // UNTRUSTED descriptor claim (can only be refused, never obeyed)
  input  wire [DEV_W-1:0]     req_claim_dev,
  input  wire                 req_write,
  input  wire [63:0]          req_iova,
  input  wire [LEN_W-1:0]     req_bytes,
  input  wire [ID_W-1:0]      req_id,
  // ------------------------------------------------ translation response
  output wire                 rsp_valid,
  input  wire                 rsp_ready,
  output wire [ID_W-1:0]      rsp_id,
  output wire                 rsp_ok,
  output wire [3:0]           rsp_fault,
  output wire [PA_W-1:0]      rsp_pa,
  output wire [LEN_W-1:0]     rsp_bytes,
  output wire                 rsp_last,
  input  wire                 dma_quiet,            // no granted-but-unfinished transfer (tie 1 if the platform quiesces by software)

  // ------------------------------------------------ SFB2 master: page-table reads
  output wire                 m_req_valid,
  input  wire                 m_req_ready,
  output wire                 m_req_write,          // constant 0: the walker never writes
  output wire [FAB_AW-1:0]    m_req_addr,
  output wire [DW-1:0]        m_req_wdata,          // 0
  output wire [DW/8-1:0]      m_req_wstrb,          // 0
  input  wire                 m_rsp_valid,
  output wire                 m_rsp_ready,
  input  wire [DW-1:0]        m_rsp_rdata,
  input  wire                 m_rsp_error,

  // ------------------------------------------------ privileged configuration (SFB2 slave style)
  input  wire                 cfg_req_valid,
  output wire                 cfg_req_ready,
  input  wire                 cfg_req_write,
  input  wire [7:0]           cfg_req_addr,
  input  wire [31:0]          cfg_req_wdata,
  input  wire                 cfg_priv,
  output wire                 cfg_rsp_valid,
  input  wire                 cfg_rsp_ready,
  output wire [31:0]          cfg_rsp_rdata,
  output wire                 cfg_rsp_error,

  // ------------------------------------------------ events
  output wire                 inv_done_evt,         // one cycle: an invalidation / context command finished
  output wire [1:0]           inv_done_status,      // SFIO_IS_OK / SFIO_IS_TMO
  output wire                 irq
);
  // ---------------------------------------------------------------- elaboration-time configuration checks
  if (TLB_ENTRIES < 2 || TLB_ENTRIES > 64)    begin : g_chk_tlb   $error("TLB_ENTRIES must be 2..64"); end
  if (NUM_CTX < 1 || NUM_CTX > 255)           begin : g_chk_ctx   $error("NUM_CTX must be 1..255");   end
  if (DEV_W < 1 || DEV_W > 8)                 begin : g_chk_devw  $error("DEV_W must be 1..8");       end
  if ((1 << DEV_W) < NUM_CTX)                 begin : g_chk_devn  $error("DEV_W too small for NUM_CTX"); end
  if (ID_W < 1 || ID_W > 16)                  begin : g_chk_idw   $error("ID_W must be 1..16");       end
  if (MAX_BYTES < 1 || MAX_BYTES > 4096)      begin : g_chk_maxb  $error("MAX_BYTES must be 1..4096 (a request may cross at most ONE page boundary)"); end
  if (LEN_W < 13 || LEN_W > 16 || (1 << LEN_W) <= MAX_BYTES)
                                              begin : g_chk_lenw  $error("LEN_W must be 13..16 and hold MAX_BYTES"); end
  if (PA_W < 13 || PA_W > 56)                 begin : g_chk_paw   $error("PA_W must be 13..56");      end
  if (FAB_AW < 13 || FAB_AW > 32 || FAB_AW > PA_W) begin : g_chk_fab $error("FAB_AW must be 13..32 and <= PA_W"); end
  if (DW != 32 && DW != 64)                   begin : g_chk_dw    $error("DW must be 32 or 64");      end
  if (WALK_TMO < 4 || WALK_TMO > 65000)       begin : g_chk_tmo   $error("WALK_TMO must be 4..65000"); end
  if (RETRY_MAX < 0 || RETRY_MAX > 15)        begin : g_chk_retry $error("RETRY_MAX must be 0..15");  end
  if (FQ_DEPTH < 1 || FQ_DEPTH > 64)          begin : g_chk_fq    $error("FQ_DEPTH must be 1..64");   end

  localparam integer CTX_W     = (NUM_CTX > 1) ? $clog2(NUM_CTX) : 1;
  localparam integer VPN_W     = 27;
  localparam integer PPN_W     = PA_W - 12;
  localparam integer FAB_PPN_W = FAB_AW - 12;

  // ---------------------------------------------------------------- sequencer state
  localparam [2:0] S_IDLE = 3'd0, S_CHECK = 3'd1, S_LOOKUP = 3'd2, S_WALK = 3'd3, S_RESP = 3'd4;
  reg [2:0]            st;

  reg [DEV_W-1:0]      q_dev, q_cd;
  reg                  q_cv, q_write;
  reg [ID_W-1:0]       q_id;
  reg [63:0]           q_iova;
  reg [LEN_W-1:0]      q_bytes;
  reg [CTX_W-1:0]      q_ctx;
  reg [FAB_PPN_W-1:0]  q_root;
  reg                  q_cross;
  reg [VPN_W-1:0]      q_vpn0, q_vpn1;
  reg [LEN_W-1:0]      q_len0, q_len1;
  reg                  seg_q;                       // segment being looked up
  reg [PA_W-1:0]       r_pa0, r_pa1;
  reg [LEN_W-1:0]      r_len0, r_len1;
  reg                  r_ok, r_two, r_idx;
  reg [3:0]            r_fault;
  reg [15:0]           lat_q;

  // ---------------------------------------------------------------- sub-block wiring
  wire        inv_busy;
  wire        locked;
  // context table
  wire        ctx_ok, ctx_ar, ctx_aw;
  wire [CTX_W-1:0] ctx_idx;
  wire [FAB_PPN_W-1:0] ctx_root;
  // TLB
  wire        tlb_hit, tlb_multi, tlb_r, tlb_w;
  wire [PPN_W-1:0] tlb_ppn;
  wire [1:0]  tlb_ps;
  wire        tlb_inv_valid;
  wire [1:0]  tlb_inv_kind;
  wire [CTX_W-1:0] tlb_inv_ctx;
  wire [VPN_W-1:0] tlb_inv_vpn;
  wire        ev_fill, ev_evict;
  // walker
  wire        walk_busy, walk_done, walk_r_ok, walk_w_ok;
  wire [3:0]  walk_fault;
  wire [1:0]  walk_level, walk_psize;
  wire [PPN_W-1:0] walk_ppn;
  wire [15:0] walk_cycles;
  wire [7:0]  walk_refs;
  wire        fab_wedged, ev_torn, ev_fab_tmo, ev_fab_err, ev_stray;

  // ---------------------------------------------------------------- request handshake
  assign req_ready = (st == S_IDLE) && !inv_busy;
  wire   req_hs    = req_valid && req_ready;
  wire   rsp_hs    = rsp_valid && rsp_ready;

  // ---------------------------------------------------------------- S_CHECK: static checks (docs/01 section 5, "fault attribution")
  wire [64:0] last65   = {1'b0, q_iova} + {{(65-LEN_W){1'b0}}, (q_bytes - {{(LEN_W-1){1'b0}}, 1'b1})};
  /* verilator lint_off UNUSEDSIGNAL */
  wire [63:0] last64   = last65[63:0];                       // [11:0] is not needed: only the page of the last byte and canonicality are
  /* verilator lint_on UNUSEDSIGNAL */
  wire        c_ovf    = last65[64];
  wire        c_canon_s = (q_iova[63:38] == {26{q_iova[38]}});
  wire        c_canon_e = (last64[63:38] == {26{last64[38]}});
  wire        c_len    = (q_bytes == {LEN_W{1'b0}}) || ({{(32-LEN_W){1'b0}}, q_bytes} > MAX_BYTES);
  wire        c_claim  = q_cv && (q_cd != q_dev);
  wire        c_dir    = q_write ? !ctx_aw : !ctx_ar;
  reg         chk_bad;
  reg [3:0]   chk_fault;
  always @* begin
    chk_bad = 1'b1; chk_fault = `SFIO_F_NONE;
    if (!ctx_ok || c_claim)                   chk_fault = `SFIO_F_BAD_CONTEXT;
    else if (c_len)                           chk_fault = `SFIO_F_BAD_REQUEST;
    else if (c_ovf)                           chk_fault = `SFIO_F_ADDR_OVERFLOW;
    else if (!c_canon_s || !c_canon_e)        chk_fault = `SFIO_F_NONCANONICAL;
    else if (c_dir)                           chk_fault = `SFIO_F_PERM;
    else                                      chk_bad   = 1'b0;
  end
  // page split (valid only when chk_bad = 0, so 1 <= bytes <= MAX_BYTES <= 4096)
  wire [16:0] off_sum  = {5'd0, q_iova[11:0]} + {{(17-LEN_W){1'b0}}, q_bytes};
  wire        pg_cross = (off_sum > 17'd4096);
  wire [16:0] len0_w   = pg_cross ? (17'd4096 - {5'd0, q_iova[11:0]}) : {{(17-LEN_W){1'b0}}, q_bytes};
  /* verilator lint_off UNUSEDSIGNAL */
  wire [16:0] len1_w   = {{(17-LEN_W){1'b0}}, q_bytes} - len0_w;     // <= 4095: bits above LEN_W are 0
  /* verilator lint_on UNUSEDSIGNAL */

  // ---------------------------------------------------------------- S_LOOKUP / S_WALK
  wire [VPN_W-1:0] cur_vpn  = seg_q ? q_vpn1 : q_vpn0;
  wire [11:0]      cur_off  = seg_q ? 12'd0  : q_iova[11:0];
  wire             lookup_c = (st == S_LOOKUP);
  wire             use_hit  = lookup_c && tlb_hit;
  wire             do_walk  = lookup_c && !tlb_hit;                 // also on a (never expected) multi-match: treat as a miss
  wire             walk_c   = (st == S_WALK) && walk_done;

  /* verilator lint_off UNUSEDSIGNAL */
  // physical page of a superpage: the leaf's PPN with its low (9 * level) bits replaced by the offset bits of the VPN (width-independent: 44-bit arithmetic)
  function automatic [PPN_W-1:0] eff_ppn(input [PPN_W-1:0] ppn, input [1:0] ps, input [VPN_W-1:0] vpn);
    reg [43:0] p44, m44, v44;
    begin
      p44 = {{(44-PPN_W){1'b0}}, ppn};
      v44 = {{(44-VPN_W){1'b0}}, vpn};
      case (ps)
        2'd1:    m44 = 44'h1FF;
        2'd2:    m44 = 44'h3FFFF;
        default: m44 = 44'h0;
      endcase
      p44      = (p44 & ~m44) | (v44 & m44);
      eff_ppn  = p44[PPN_W-1:0];
    end
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */

  // segment decision (combinational): either the segment is granted (seg_ok, with ppn) or refused (seg_bad, cause, level)
  reg              seg_ok, seg_bad;
  reg [3:0]        seg_cause;
  reg [1:0]        seg_level;
  reg [PPN_W-1:0]  seg_ppn;
  always @* begin
    seg_ok = 1'b0; seg_bad = 1'b0; seg_cause = `SFIO_F_NONE; seg_level = 2'd3; seg_ppn = {PPN_W{1'b0}};
    if (use_hit) begin
      if (q_write ? tlb_w : tlb_r) begin seg_ok = 1'b1; seg_ppn = eff_ppn(tlb_ppn, tlb_ps, cur_vpn); end
      else begin seg_bad = 1'b1; seg_cause = `SFIO_F_PERM; end
    end else if (walk_c) begin
      seg_level = walk_level;
      if (walk_fault != `SFIO_F_NONE) begin seg_bad = 1'b1; seg_cause = walk_fault; end
      else if (q_write ? walk_w_ok : walk_r_ok) begin seg_ok = 1'b1; seg_ppn = eff_ppn(walk_ppn, walk_psize, cur_vpn); end
      else begin seg_bad = 1'b1; seg_cause = `SFIO_F_PERM; end
    end
  end

  // a request is refused: one fault record, one fault response
  wire        chk_c    = (st == S_CHECK);
  wire        flt_push = (chk_c && chk_bad) || seg_bad;
  wire [3:0]  flt_cause = chk_c ? chk_fault : seg_cause;
  wire [1:0]  flt_level = chk_c ? 2'd3 : seg_level;

  // TLB fill: a walk found a leaf that grants something (the TLB itself drops a fill that grants nothing)
  wire        fill_v   = walk_c && (walk_fault == `SFIO_F_NONE);
  wire        pipe_idle = (st == S_IDLE);

  // ---------------------------------------------------------------- response
  assign rsp_valid = (st == S_RESP);
  assign rsp_id    = q_id;
  assign rsp_ok    = r_ok;
  assign rsp_fault = r_fault;
  assign rsp_pa    = r_ok ? (r_idx ? r_pa1  : r_pa0)  : {PA_W{1'b0}};
  assign rsp_bytes = r_ok ? (r_idx ? r_len1 : r_len0) : {LEN_W{1'b0}};
  assign rsp_last  = r_ok ? (r_idx == r_two)           : 1'b1;

  // latency sample: handshake -> first response valid
  wire lat_evt = (chk_c && chk_bad) || seg_bad || (seg_ok && !(!seg_q && q_cross));

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE;
      q_dev <= {DEV_W{1'b0}}; q_cd <= {DEV_W{1'b0}}; q_cv <= 1'b0; q_write <= 1'b0; q_id <= {ID_W{1'b0}}; q_iova <= 64'd0;
      q_bytes <= {LEN_W{1'b0}}; q_ctx <= {CTX_W{1'b0}}; q_root <= {FAB_PPN_W{1'b0}}; q_cross <= 1'b0;
      q_vpn0 <= {VPN_W{1'b0}}; q_vpn1 <= {VPN_W{1'b0}}; q_len0 <= {LEN_W{1'b0}}; q_len1 <= {LEN_W{1'b0}};
      seg_q <= 1'b0; r_pa0 <= {PA_W{1'b0}}; r_pa1 <= {PA_W{1'b0}}; r_len0 <= {LEN_W{1'b0}}; r_len1 <= {LEN_W{1'b0}};
      r_ok <= 1'b0; r_two <= 1'b0; r_idx <= 1'b0; r_fault <= `SFIO_F_NONE; lat_q <= 16'd0;
    end else begin
      if (st != S_IDLE && st != S_RESP && lat_q != 16'hFFFF) lat_q <= lat_q + 16'd1;
      case (st)
        S_IDLE: begin
          if (req_hs) begin
            q_dev <= req_dev; q_cd <= req_claim_dev; q_cv <= req_claim_valid; q_write <= req_write; q_id <= req_id;
            q_iova <= req_iova; q_bytes <= req_bytes;
            lat_q <= 16'd1;
            st <= S_CHECK;
          end
        end
        S_CHECK: begin
          if (chk_bad) begin
            r_ok <= 1'b0; r_fault <= chk_fault; r_two <= 1'b0; r_idx <= 1'b0;
            st <= S_RESP;
          end else begin
            q_ctx <= ctx_idx; q_root <= ctx_root;
            q_cross <= pg_cross;
            q_vpn0 <= q_iova[38:12]; q_vpn1 <= last64[38:12];
            q_len0 <= len0_w[LEN_W-1:0]; q_len1 <= len1_w[LEN_W-1:0];
            seg_q <= 1'b0;
            st <= S_LOOKUP;
          end
        end
        S_LOOKUP: begin
          if (use_hit) begin
            if (seg_ok) begin
              if (!seg_q) begin r_pa0 <= {seg_ppn, cur_off}; r_len0 <= q_len0; end
              else        begin r_pa1 <= {seg_ppn, cur_off}; r_len1 <= q_len1; end
              if (!seg_q && q_cross) begin seg_q <= 1'b1; st <= S_LOOKUP; end
              else begin r_ok <= 1'b1; r_fault <= `SFIO_F_NONE; r_two <= q_cross; r_idx <= 1'b0; st <= S_RESP; end
            end else begin
              r_ok <= 1'b0; r_fault <= seg_cause; r_two <= 1'b0; r_idx <= 1'b0; st <= S_RESP;
            end
          end else begin
            st <= S_WALK;                                              // miss: walk_start pulses in this cycle (do_walk)
          end
        end
        S_WALK: begin
          if (walk_done) begin
            if (seg_ok) begin
              if (!seg_q) begin r_pa0 <= {seg_ppn, cur_off}; r_len0 <= q_len0; end
              else        begin r_pa1 <= {seg_ppn, cur_off}; r_len1 <= q_len1; end
              if (!seg_q && q_cross) begin seg_q <= 1'b1; st <= S_LOOKUP; end
              else begin r_ok <= 1'b1; r_fault <= `SFIO_F_NONE; r_two <= q_cross; r_idx <= 1'b0; st <= S_RESP; end
            end else begin
              r_ok <= 1'b0; r_fault <= seg_cause; r_two <= 1'b0; r_idx <= 1'b0; st <= S_RESP;
            end
          end
        end
        S_RESP: begin
          if (rsp_hs) begin
            if (r_ok && r_two && !r_idx) r_idx <= 1'b1;
            else                          st <= S_IDLE;
          end
        end
        default: st <= S_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------- TLB
  sf_iommu_tlb #(.N(TLB_ENTRIES), .CTX_W(CTX_W), .VPN_W(VPN_W), .PPN_W(PPN_W)) u_tlb (
    .clk(clk), .rst_n(rst_n),
    .lk_ctx(q_ctx), .lk_vpn(cur_vpn), .lk_hit(tlb_hit), .lk_multi(tlb_multi), .lk_ppn(tlb_ppn), .lk_r(tlb_r), .lk_w(tlb_w),
    .lk_psize(tlb_ps), .lk_touch(use_hit),
    .fill_valid(fill_v), .fill_ctx(q_ctx), .fill_vpn(cur_vpn), .fill_ppn(walk_ppn), .fill_r(walk_r_ok), .fill_w(walk_w_ok),
    .fill_psize(walk_psize),
    .inv_valid(tlb_inv_valid), .inv_kind(tlb_inv_kind), .inv_ctx(tlb_inv_ctx), .inv_vpn(tlb_inv_vpn),
    .ev_fill(ev_fill), .ev_evict(ev_evict));

  // ---------------------------------------------------------------- walker
  sf_iommu_walk_fsm #(.PPN_W(PPN_W), .FAB_AW(FAB_AW), .FAB_PPN_W(FAB_PPN_W), .DW(DW), .VPN_W(VPN_W), .SUPERPAGE_EN(SUPERPAGE_EN),
                      .PTE_DOUBLE_READ(PTE_DOUBLE_READ), .RETRY_MAX(RETRY_MAX), .WALK_TMO(WALK_TMO)) u_walk (
    .clk(clk), .rst_n(rst_n),
    .walk_start(do_walk), .walk_root(q_root), .walk_vpn(cur_vpn), .walk_busy(walk_busy),
    .walk_done(walk_done), .walk_fault(walk_fault), .walk_level(walk_level), .walk_ppn(walk_ppn), .walk_psize(walk_psize),
    .walk_r_ok(walk_r_ok), .walk_w_ok(walk_w_ok), .walk_cycles(walk_cycles), .walk_refs(walk_refs),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_addr(m_req_addr),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .fab_wedged(fab_wedged), .ev_torn(ev_torn), .ev_fab_tmo(ev_fab_tmo), .ev_fab_err(ev_fab_err), .ev_stray(ev_stray));
  assign m_req_write = 1'b0;                       // THE WALKER NEVER WRITES
  assign m_req_wdata = {DW{1'b0}};
  assign m_req_wstrb = {(DW/8){1'b0}};

  // ---------------------------------------------------------------- privileged CSR port
  reg          cfg_rsp_valid_q, cfg_err_q;
  reg  [31:0]  cfg_rdata_q;
  assign cfg_req_ready = !cfg_rsp_valid_q || cfg_rsp_ready;
  wire         cfg_hs  = cfg_req_valid && cfg_req_ready;
  wire [4:0]   c_idx   = cfg_req_addr[6:2];
  wire         a_ok    = (cfg_req_addr[1:0] == 2'b00) && !cfg_req_addr[7] && (c_idx < `SFIO_NREG);
  reg          is_ro;
  always @* begin
    case (c_idx)
      `SFIO_R_ID, `SFIO_R_VERSION, `SFIO_R_STATE, `SFIO_R_INV_STAT, `SFIO_R_CTX_RD_LO, `SFIO_R_CTX_RD_HI, `SFIO_R_CTX_RD_ATTR,
      `SFIO_R_FLOG_CNT, `SFIO_R_FLOG_W0, `SFIO_R_FLOG_W1, `SFIO_R_FLOG_W2, `SFIO_R_FLOG_W3, `SFIO_R_FLOG_SEQ,
      `SFIO_R_CNT_DATA, `SFIO_R_NCNT, `SFIO_R_CAPS, `SFIO_R_CAPS2:  is_ro = 1'b1;
      default:                                                       is_ro = 1'b0;
    endcase
  end
  wire         cfg_ok_wr = cfg_hs && cfg_req_write && cfg_priv && a_ok && !is_ro;   // a write that takes effect
  wire         cfg_ok_rd = cfg_hs && !cfg_req_write && cfg_priv && a_ok;
  wire         ev_priv   = cfg_hs && !cfg_priv;
  wire         ev_badad  = cfg_hs && cfg_priv && !a_ok;
  wire         ev_rowr   = cfg_hs && cfg_priv && a_ok && cfg_req_write && is_ro;
  wire         cfg_err   = cfg_hs && (!cfg_priv || !a_ok || (cfg_req_write && is_ro));

  // slices
  wire [31:0] ctx_rd, inv_rd, flt_rd, prf_rd;
  wire        ctx_hit, inv_hit, flt_hit, prf_hit;
  wire        ctx_ce_evt, inv_ce_evt;
  wire [3:0]  ctx_ce_code, inv_ce_code;
  wire        cu_req, cu_clear, cu_commit, cu_commit_clear;
  wire [CTX_W-1:0] cu_idx, cu_commit_idx;
  wire        inv_done_ok_evt, inv_done_tmo_evt;
  wire        fq_nonempty, fq_drop;

  sf_iommu_context #(.NUM_CTX(NUM_CTX), .DEV_W(DEV_W), .CTX_W(CTX_W), .PPN_W(FAB_PPN_W), .FAB_PPN_W(FAB_PPN_W)) u_ctx (   // a root PPN is stored in FAB_PPN_W bits: it is validated to fit the fabric
    .clk(clk), .rst_n(rst_n),
    .lk_dev(q_dev), .lk_ok(ctx_ok), .lk_idx(ctx_idx), .lk_root(ctx_root), .lk_allow_r(ctx_ar), .lk_allow_w(ctx_aw),
    .csr_wr(cfg_ok_wr), .csr_idx(c_idx), .csr_wdata(cfg_req_wdata), .csr_rdata(ctx_rd), .csr_hit(ctx_hit),
    .locked(locked), .cmd_busy(inv_busy), .ce_evt(ctx_ce_evt), .ce_code(ctx_ce_code),
    .cu_req(cu_req), .cu_clear(cu_clear), .cu_idx(cu_idx),
    .cu_commit(cu_commit), .cu_commit_clear(cu_commit_clear), .cu_commit_idx(cu_commit_idx));

  sf_iommu_invalidation #(.NUM_CTX(NUM_CTX), .CTX_W(CTX_W), .VPN_W(VPN_W), .DRAIN_TMO_DEFAULT(DRAIN_TMO_DEFAULT),
                          .WAIT_DMA_QUIET(WAIT_DMA_QUIET)) u_inv (
    .clk(clk), .rst_n(rst_n),
    .csr_wr(cfg_ok_wr), .csr_idx(c_idx), .csr_wdata(cfg_req_wdata), .csr_rdata(inv_rd), .csr_hit(inv_hit),
    .locked(locked), .ce_evt(inv_ce_evt), .ce_code(inv_ce_code),
    .cu_req(cu_req), .cu_clear(cu_clear), .cu_idx(cu_idx),
    .cu_commit(cu_commit), .cu_commit_clear(cu_commit_clear), .cu_commit_idx(cu_commit_idx),
    .pipe_idle(pipe_idle), .dma_quiet(dma_quiet), .busy(inv_busy),
    .tlb_inv_valid(tlb_inv_valid), .tlb_inv_kind(tlb_inv_kind), .tlb_inv_ctx(tlb_inv_ctx), .tlb_inv_vpn(tlb_inv_vpn),
    .done_evt(inv_done_evt), .done_ok_evt(inv_done_ok_evt), .done_tmo_evt(inv_done_tmo_evt), .done_status(inv_done_status));

  sf_iommu_faults #(.FQ_DEPTH(FQ_DEPTH), .DEV_W(DEV_W), .ID_W(ID_W), .LEN_W(LEN_W)) u_flt (
    .clk(clk), .rst_n(rst_n),
    .push(flt_push), .push_cause(flt_cause), .push_level(flt_level), .push_write(q_write), .push_dev(q_dev), .push_id(q_id),
    .push_iova(q_iova), .push_bytes(q_bytes),
    .csr_wr(cfg_ok_wr), .csr_idx(c_idx), .csr_wdata(cfg_req_wdata), .csr_rdata(flt_rd), .csr_hit(flt_hit),
    .nonempty(fq_nonempty), .drop_evt(fq_drop));

  wire ev_rsp_stall = rsp_valid && !rsp_ready;
  wire ev_req_stall = req_valid && !req_ready;
  sf_iommu_perf u_perf (
    .clk(clk), .rst_n(rst_n),
    .ev_req(req_hs), .ev_seg(lookup_c), .ev_hit(lookup_c && tlb_hit), .ev_miss(lookup_c && !tlb_hit), .ev_walk(do_walk),
    .ev_walk_fault(walk_c && (walk_fault != `SFIO_F_NONE)), .ev_fill(ev_fill), .ev_evict(ev_evict), .ev_torn(ev_torn),
    .ev_fab_tmo(ev_fab_tmo), .ev_stray(ev_stray), .ev_cfg_rej(cfg_err), .ev_ctx_commit(cu_commit),
    .ev_inv_done(inv_done_ok_evt), .ev_inv_tmo(inv_done_tmo_evt), .ev_fault(flt_push), .ev_fault_cause(flt_cause),
    .ev_req_stall(ev_req_stall), .ev_rsp_stall(ev_rsp_stall), .ev_inv_block(req_valid && (st == S_IDLE) && inv_busy),
    .walk_done_evt(walk_done), .walk_cycles(walk_cycles), .walk_refs(walk_refs),
    .lat_evt(lat_evt), .lat_cycles(lat_q + 16'd1),
    .csr_wr(cfg_ok_wr), .csr_idx(c_idx), .csr_wdata(cfg_req_wdata), .csr_rdata(prf_rd), .csr_hit(prf_hit));

  // ---------------------------------------------------------------- top-level registers: CTRL, STATUS, STATE, ID, CAPS
  reg         irq_en, lock_q;
  reg  [9:1]  sticky;                    // STATUS bits 1..9
  reg  [3:0]  last_ce;
  assign locked = lock_q;

  wire        ce_any    = ctx_ce_evt | inv_ce_evt | ev_priv | ev_badad | ev_rowr;
  reg  [3:0]  ce_now;
  always @* begin
    ce_now = `SFIO_CE_OK;
    if (ev_priv)             ce_now = `SFIO_CE_PRIV;
    else if (ev_badad)       ce_now = `SFIO_CE_CMD;
    else if (ev_rowr)        ce_now = `SFIO_CE_CMD;
    else if (ctx_ce_evt)     ce_now = ctx_ce_code;
    else if (inv_ce_evt)     ce_now = inv_ce_code;
  end
  wire        tmo_ce    = (ce_now == `SFIO_CE_TMO);

  wire [9:1] sticky_set = {ev_stray,                                                  // 9 STRAY
                           (ev_fab_err | ev_fab_tmo),                                 // 8 FAB_ERR
                           fq_drop,                                                   // 7 FQ_DROP
                           ev_badad,                                                  // 6 BADADDR
                           (ce_any && ce_now == `SFIO_CE_LOCKED),                     // 5 LOCKED_REJ
                           ev_priv,                                                   // 4 PRIV
                           (ce_any && !tmo_ce),                                       // 3 CMD_ERR
                           inv_done_tmo_evt,                                          // 2 INV_TMO
                           inv_done_ok_evt};                                          // 1 INV_DONE
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      irq_en <= 1'b0; lock_q <= 1'b0; sticky <= 9'd0; last_ce <= `SFIO_CE_OK;
    end else begin
      if (cfg_ok_wr && c_idx == `SFIO_R_CTRL) begin
        irq_en <= cfg_req_wdata[0];
        if (cfg_req_wdata[31]) lock_q <= 1'b1;                 // set-only: cleared by reset only
      end
      sticky <= (sticky & ~((cfg_ok_wr && c_idx == `SFIO_R_STATUS) ? cfg_req_wdata[9:1] : 9'd0)) | sticky_set;
      if (ce_any) last_ce <= ce_now;
    end
  end
  assign irq = irq_en && (fq_nonempty || sticky[`SFIO_ST_INV_DONE] || sticky[`SFIO_ST_INV_TMO]);

  wire [31:0] st_word = {21'd0, fab_wedged, sticky, fq_nonempty};      // [10] wedged (live) [9:1] sticky [0] fault pending
  wire [31:0] state_w = {20'd0, last_ce, 2'd0, fab_wedged, walk_busy, (st != S_IDLE), lock_q, !req_ready, inv_busy};
  reg  [31:0] rd_mux;
  always @* begin
    rd_mux = 32'd0;
    case (c_idx)
      `SFIO_R_ID:      rd_mux = {16'h5057, TLB_ENTRIES[7:0], NUM_CTX[7:0]};
      `SFIO_R_VERSION: rd_mux = 32'h0001_0000;
      `SFIO_R_CTRL:    rd_mux = {lock_q, 30'd0, irq_en};
      `SFIO_R_STATUS:  rd_mux = st_word;
      `SFIO_R_STATE:   rd_mux = state_w;
      `SFIO_R_CAPS:    rd_mux = {MAX_BYTES[15:0], DW[7:0], PA_W[7:0]};
      `SFIO_R_CAPS2:   rd_mux = {29'd0, (PTE_DOUBLE_READ != 0), (WAIT_DMA_QUIET != 0), (SUPERPAGE_EN != 0)};
      default:         rd_mux = ctx_rd | inv_rd | flt_rd | prf_rd;      // each slice returns 0 for registers that are not its own
    endcase
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cfg_rsp_valid_q <= 1'b0; cfg_err_q <= 1'b0; cfg_rdata_q <= 32'd0;
    end else begin
      if (cfg_hs) begin
        cfg_rsp_valid_q <= 1'b1;
        cfg_err_q       <= cfg_err;
        cfg_rdata_q     <= cfg_ok_rd ? rd_mux : 32'd0;
      end else if (cfg_rsp_ready) begin
        cfg_rsp_valid_q <= 1'b0;
      end
    end
  end
  assign cfg_rsp_valid = cfg_rsp_valid_q;
  assign cfg_rsp_rdata = cfg_rdata_q;
  assign cfg_rsp_error = cfg_err_q;

  // ---------------------------------------------------------------- unused-signal sinks (lint)
  wire unused_ok = &{1'b0, ctx_hit, inv_hit, flt_hit, prf_hit, tlb_multi, walk_busy, cfg_req_wdata[31:10], 1'b0};

`ifdef SF_CHECKS
  // ---- port-level safety properties: checked in every simulation build, and proved / bounded by formal/iommu/fv_top.sv (docs/05 sections 4 and 5)
  always @* begin
    if (rst_n) begin
      assert (m_req_write == 1'b0);                                                 // the walker never writes
      assert (!(rsp_valid && rsp_ok && (rsp_fault != `SFIO_F_NONE)));               // ok and fault are exclusive
      assert (!(rsp_valid && !rsp_ok && rsp_fault == `SFIO_F_NONE));
      assert (!(rsp_valid && !rsp_ok && (rsp_pa != {PA_W{1'b0}})));                 // no address leaves on a refusal
      assert (!(tlb_inv_valid && st != S_IDLE));                                    // a TLB invalidation only with the translator idle
      assert (!(req_ready && inv_busy));                                            // blocking
    end
  end
`endif

`ifdef FORMAL
  // ===========================================================================================================================
  // Formal (formal/iommu/fv_top.sv; docs/05 section 5): the composed design, BOUNDED (BMC) unless the proof says otherwise.
  //   F1  a fabric read is made only inside a walk or as the still-presented remainder of an abandoned read: a request refused by a
  //       static check (or hitting the TLB) makes NO fabric access
  //   F2  an OK response implies every static check passed and the direction is within the context's caps
  //   F3  response structure: offset kept, never crosses a 4 KiB boundary, segment lengths add up to the request, `last` is exact
  //   F4  a refusal carries no address and no length
  //   F5  one response (group) per accepted request; request port blocked while a response is pending
  // ===========================================================================================================================
  reg f_init;
  initial f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  reg f_out;                                       // a request has been accepted and its last response has not been accepted
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) f_out <= 1'b0;
    else begin
      if (req_hs) f_out <= 1'b1;
      if (rsp_hs && rsp_last) f_out <= 1'b0;
    end
  end
  wire [13:0] f_end0 = {2'b00, rsp_pa[11:0]} + {1'b0, rsp_bytes};
  always @* begin
    if (!f_init) begin
      assert (st <= S_RESP);
      assert (!(m_req_valid && st != S_WALK && !fab_wedged));                                   // F1
      if (walk_busy) assert (st == S_WALK);
      if (st == S_RESP && r_ok) begin                                                           // F2, F3
        assert (ctx_ok && !c_claim && !c_len && !c_ovf && c_canon_s && c_canon_e);
        assert (q_write ? ctx_aw : ctx_ar);
        assert (rsp_bytes != {LEN_W{1'b0}});
        assert (f_end0 <= 14'd4096);
        if (!r_idx) assert (rsp_pa[11:0] == q_iova[11:0]);
        else        assert (rsp_pa[11:0] == 12'd0);
        assert (rsp_last == (!r_two || r_idx));
        if (r_two) assert ({1'b0, r_len0} + {1'b0, r_len1} == {1'b0, q_bytes});
        else       assert (r_len0 == q_bytes);
        assert (r_fault == `SFIO_F_NONE);
      end
      if (st == S_RESP && !r_ok) begin                                                          // F4
        assert (r_fault != `SFIO_F_NONE);
        assert (rsp_pa == {PA_W{1'b0}});
        assert (rsp_bytes == {LEN_W{1'b0}});
        assert (rsp_last);
      end
      assert (f_out == (st != S_IDLE));                                                         // F5
      if (inv_busy) assert (!req_ready);
    end
  end
`endif
endmodule
`default_nettype wire
