// =============================================================================
// SilicaFlux -- Project 108 -- PageWalker :: sf_iommu_faults
//
// Privileged fault log: which request failed, and why.  One record per refused request:
//   {cause, walk level (3 = not a walk fault), write, device, request id, IOVA, length, sequence number}
// Bounded FIFO (FQ_DEPTH).  When it is full the NEW record is dropped (the oldest evidence is kept), the drop is counted (saturating)
// and flagged -- but the SEQUENCE NUMBER still advances, so software sees the gap.  The requester sees only rsp_fault / rsp_id;
// the full record is for the privileged port only.
// =============================================================================
`default_nettype none
`include "sf_iommu_defs.svh"
module sf_iommu_faults #(
  parameter integer FQ_DEPTH = 4,
  parameter integer DEV_W    = 4,
  parameter integer ID_W     = 4,
  parameter integer LEN_W    = 13
) (
  input  wire                 clk,
  input  wire                 rst_n,
  input  wire                 push,
  input  wire [3:0]           push_cause,
  input  wire [1:0]           push_level,
  input  wire                 push_write,
  input  wire [DEV_W-1:0]     push_dev,
  input  wire [ID_W-1:0]      push_id,
  input  wire [63:0]          push_iova,
  input  wire [LEN_W-1:0]     push_bytes,
  // CSR slice
  input  wire                 csr_wr,
  input  wire [4:0]           csr_idx,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire [31:0]          csr_wdata,                    // only bit 0 (POP) is used
  /* verilator lint_on UNUSEDSIGNAL */
  output reg  [31:0]          csr_rdata,
  output reg                  csr_hit,
  output wire                 nonempty,
  output wire                 drop_evt
);
  localparam integer PW = (FQ_DEPTH > 1) ? $clog2(FQ_DEPTH) : 1;
  localparam integer CW = $clog2(FQ_DEPTH + 1);
  localparam integer LAST_I   = FQ_DEPTH - 1;
  localparam [CW-1:0] DEPTH_C = FQ_DEPTH[CW-1:0];
  localparam [PW-1:0] LAST_P  = LAST_I[PW-1:0];

  reg [FQ_DEPTH*4-1:0]      q_cause;
  reg [FQ_DEPTH*2-1:0]      q_level;
  reg [FQ_DEPTH-1:0]        q_write;
  reg [FQ_DEPTH*DEV_W-1:0]  q_dev;
  reg [FQ_DEPTH*ID_W-1:0]   q_id;
  reg [FQ_DEPTH*64-1:0]     q_iova;
  reg [FQ_DEPTH*LEN_W-1:0]  q_bytes;
  reg [FQ_DEPTH*32-1:0]     q_seq;
  reg [PW-1:0]              rd_ptr, wr_ptr;
  reg [CW-1:0]              cnt;
  reg [31:0]                seq_cnt;
  reg [15:0]                dropped;

  assign nonempty = (cnt != {CW{1'b0}});
  wire   full     = (cnt == DEPTH_C);
  wire   pop      = csr_wr && (csr_idx == `SFIO_R_FLOG_POP) && csr_wdata[0] && nonempty;
  wire   can_push = push && (!full || pop);
  assign drop_evt = push && full && !pop;

  function automatic [PW-1:0] inc(input [PW-1:0] p);
    begin
      inc = (p == LAST_P) ? {PW{1'b0}} : p + {{(PW-1){1'b0}}, 1'b1};
    end
  endfunction

  // ---------------------------------------------------------------- CSR read (head record)
  wire [3:0]          h_cause = q_cause[rd_ptr*4 +: 4];
  wire [1:0]          h_level = q_level[rd_ptr*2 +: 2];
  wire                h_write = q_write[rd_ptr];
  wire [DEV_W-1:0]    h_dev   = q_dev[rd_ptr*DEV_W +: DEV_W];
  wire [ID_W-1:0]     h_id    = q_id[rd_ptr*ID_W +: ID_W];
  wire [63:0]         h_iova  = q_iova[rd_ptr*64 +: 64];
  wire [LEN_W-1:0]    h_bytes = q_bytes[rd_ptr*LEN_W +: LEN_W];
  wire [31:0]         h_seq   = q_seq[rd_ptr*32 +: 32];
  always @* begin
    csr_hit   = 1'b1;
    csr_rdata = 32'd0;
    case (csr_idx)
      `SFIO_R_FLOG_CNT: csr_rdata = {dropped, FQ_DEPTH[7:0], {(8-CW){1'b0}}, cnt};
      `SFIO_R_FLOG_W0:  csr_rdata = nonempty ? {{(16-ID_W){1'b0}}, h_id, {(8-DEV_W){1'b0}}, h_dev, 1'b0, h_write, h_level, h_cause} : 32'd0;
      `SFIO_R_FLOG_W1:  csr_rdata = nonempty ? h_iova[31:0]  : 32'd0;
      `SFIO_R_FLOG_W2:  csr_rdata = nonempty ? h_iova[63:32] : 32'd0;
      `SFIO_R_FLOG_W3:  csr_rdata = nonempty ? {{(32-LEN_W){1'b0}}, h_bytes} : 32'd0;
      `SFIO_R_FLOG_SEQ: csr_rdata = nonempty ? h_seq : 32'd0;
      `SFIO_R_FLOG_POP: csr_rdata = 32'd0;                                   // write-only
      default:          begin csr_hit = 1'b0; csr_rdata = 32'd0; end
    endcase
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_cause <= {(FQ_DEPTH*4){1'b0}};   q_level <= {(FQ_DEPTH*2){1'b0}};  q_write <= {FQ_DEPTH{1'b0}};
      q_dev   <= {(FQ_DEPTH*DEV_W){1'b0}}; q_id <= {(FQ_DEPTH*ID_W){1'b0}}; q_iova <= {(FQ_DEPTH*64){1'b0}};
      q_bytes <= {(FQ_DEPTH*LEN_W){1'b0}}; q_seq <= {(FQ_DEPTH*32){1'b0}};
      rd_ptr <= {PW{1'b0}}; wr_ptr <= {PW{1'b0}}; cnt <= {CW{1'b0}}; seq_cnt <= 32'd0; dropped <= 16'd0;
    end else begin
      if (push) seq_cnt <= seq_cnt + 32'd1;                                   // a dropped record still consumes a sequence number
      if (drop_evt && dropped != 16'hFFFF) dropped <= dropped + 16'd1;
      if (can_push) begin
        q_cause[wr_ptr*4 +: 4]          <= push_cause;
        q_level[wr_ptr*2 +: 2]          <= push_level;
        q_write[wr_ptr]                 <= push_write;
        q_dev[wr_ptr*DEV_W +: DEV_W]    <= push_dev;
        q_id[wr_ptr*ID_W +: ID_W]       <= push_id;
        q_iova[wr_ptr*64 +: 64]         <= push_iova;
        q_bytes[wr_ptr*LEN_W +: LEN_W]  <= push_bytes;
        q_seq[wr_ptr*32 +: 32]          <= seq_cnt;
        wr_ptr                          <= inc(wr_ptr);
      end
      if (pop) rd_ptr <= inc(rd_ptr);
      if (can_push && !pop)      cnt <= cnt + {{(CW-1){1'b0}}, 1'b1};
      else if (!can_push && pop) cnt <= cnt - {{(CW-1){1'b0}}, 1'b1};
    end
  end

`ifdef FORMAL
  // Formal (formal/iommu/fv_flt.sv): the ring and its count agree; POP on an empty log changes nothing; the drop counter saturates.
  reg f_init;
  initial f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  reg [CW-1:0] f_cnt_q;
  reg [PW-1:0] f_rd_q, f_wr_q;
  reg [15:0]   f_drop_q;
  reg          f_pop_empty_q, f_rstn_q;
  always @(posedge clk) begin
    f_cnt_q <= cnt; f_rd_q <= rd_ptr; f_wr_q <= wr_ptr; f_drop_q <= dropped; f_rstn_q <= rst_n;
    f_pop_empty_q <= csr_wr && (csr_idx == `SFIO_R_FLOG_POP) && csr_wdata[0] && !nonempty && !push;
  end
  wire [31:0] f_diff = (wr_ptr >= rd_ptr) ? ({{(32-PW){1'b0}}, wr_ptr} - {{(32-PW){1'b0}}, rd_ptr})
                                          : ({{(32-PW){1'b0}}, wr_ptr} + FQ_DEPTH - {{(32-PW){1'b0}}, rd_ptr});
  always @* begin
    if (!f_init) begin
      assert (cnt <= DEPTH_C);
      if (cnt == {CW{1'b0}})  assert (wr_ptr == rd_ptr);
      if (cnt == DEPTH_C)     assert (wr_ptr == rd_ptr);
      if (cnt != {CW{1'b0}} && cnt != DEPTH_C) assert ({{(32-CW){1'b0}}, cnt} == f_diff);
      assert (rd_ptr < FQ_DEPTH);
      assert (wr_ptr < FQ_DEPTH);
      if (f_rstn_q && rst_n) begin                                   // a reset asserted in THIS cycle already shows reset values (async2sync)
        assert (dropped >= f_drop_q);
        if (f_pop_empty_q) begin assert (cnt == f_cnt_q); assert (rd_ptr == f_rd_q); end    // POP on an empty log is a no-op
      end
    end
  end
`endif
endmodule
`default_nettype wire
