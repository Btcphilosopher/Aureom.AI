// =============================================================================
// SilicaFlux -- Project 108 -- PageWalker :: sf_iommu_tlb
//
// Fully associative translation cache, N entries (baseline N = 4), true LRU.
//
//   entry  {valid, context tag, vpn, ppn, r_ok, w_ok, psize, age}
//   match  valid && tag == ctx && ((vpn ^ entry.vpn) & size_mask(entry.psize)) == 0      (docs/01 section 7)
//
// Safety properties (formal/iommu/fv_tlb.sv proves them for all inputs and all reachable states):
//   T1  uniqueness      at most one valid entry matches any lookup (a fill first removes every overlapping entry of its context)
//   T2  no stale hit    after an invalidation that covers (ctx, vpn) in cycle t, no lookup of (ctx, vpn) hits in any cycle > t
//                       until a fill of that (ctx, vpn) happens
//   T3  inv beats fill  a fill presented in the cycle of an invalidation is DROPPED (never lands)
//   T4  LRU invariant   the ages of the N entries are always a permutation of 0..N-1
//   T5  data integrity  a hit returns exactly the {ppn, r_ok, w_ok, psize} of the last fill of that tag
//
// Defence in depth: should two entries ever match (T1 says never), the lookup reports a MISS and lk_multi, never an OR of two PPNs.
// Tool rules (as P103/P104): flat ports, no structs / packages / return / int casts.
// =============================================================================
`default_nettype none
`include "sf_iommu_defs.svh"
module sf_iommu_tlb #(
  parameter integer N     = 4,     // entries, >= 2
  parameter integer CTX_W = 2,
  parameter integer VPN_W = 27,    // Sv39
  parameter integer PPN_W = 20
) (
  input  wire                  clk,
  input  wire                  rst_n,
  // lookup: combinational
  input  wire [CTX_W-1:0]      lk_ctx,
  input  wire [VPN_W-1:0]      lk_vpn,
  output reg                   lk_hit,
  output reg                   lk_multi,
  output reg  [PPN_W-1:0]      lk_ppn,
  output reg                   lk_r,
  output reg                   lk_w,
  output reg  [1:0]            lk_psize,
  input  wire                  lk_touch,      // the lookup result is being used: make the hit entry most recently used
  // fill
  input  wire                  fill_valid,
  input  wire [CTX_W-1:0]      fill_ctx,
  input  wire [VPN_W-1:0]      fill_vpn,
  input  wire [PPN_W-1:0]      fill_ppn,
  input  wire                  fill_r,
  input  wire                  fill_w,
  input  wire [1:0]            fill_psize,
  // invalidate (single cycle, takes effect at the clock edge ending the cycle in which inv_valid is high)
  input  wire                  inv_valid,
  input  wire [1:0]            inv_kind,
  input  wire [CTX_W-1:0]      inv_ctx,
  input  wire [VPN_W-1:0]      inv_vpn,
  // events (one-cycle pulses in the cycle the operation is applied)
  output wire                  ev_fill,
  output wire                  ev_evict
);
  localparam integer IW = (N > 1) ? $clog2(N) : 1;
  localparam integer AGE_OLD_I = N - 1;
  localparam [IW-1:0] AGE_OLD = AGE_OLD_I[IW-1:0];

  function automatic [VPN_W-1:0] smask(input [1:0] ps);
    begin
      case (ps)
        2'd1:    smask = {{(VPN_W-9){1'b1}},  9'd0};     // 2 MiB: vpn[8:0] is offset
        2'd2:    smask = {{(VPN_W-18){1'b1}}, 18'd0};    // 1 GiB: vpn[17:0] is offset
        default: smask = {VPN_W{1'b1}};                  // 4 KiB (and the never-filled code 3: strictest)
      endcase
    end
  endfunction

  reg [N-1:0]        e_valid;
  reg [N*CTX_W-1:0]  e_ctx;
  reg [N*VPN_W-1:0]  e_vpn;
  reg [N*PPN_W-1:0]  e_ppn;
  reg [N-1:0]        e_r, e_w;
  reg [N*2-1:0]      e_ps;
  reg [N*IW-1:0]     e_age;

  integer i_lk, i_fs, i_iv, i_ag;

  // --------------------------------------------------------------- lookup
  reg [N-1:0] match;
  always @* begin
    match    = {N{1'b0}};
    lk_ppn   = {PPN_W{1'b0}};
    lk_r     = 1'b0;
    lk_w     = 1'b0;
    lk_psize = 2'd0;
    for (i_lk = 0; i_lk < N; i_lk = i_lk + 1) begin
      match[i_lk] = e_valid[i_lk] && (e_ctx[i_lk*CTX_W +: CTX_W] == lk_ctx) &&
                 (((e_vpn[i_lk*VPN_W +: VPN_W] ^ lk_vpn) & smask(e_ps[i_lk*2 +: 2])) == {VPN_W{1'b0}});
    end
    lk_multi = |(match & (match - {{(N-1){1'b0}}, 1'b1}));     // more than one bit set
    lk_hit   = (|match) && !lk_multi;
    if (lk_hit) begin
      for (i_lk = 0; i_lk < N; i_lk = i_lk + 1) begin
        if (match[i_lk]) begin
          lk_ppn   = e_ppn[i_lk*PPN_W +: PPN_W];
          lk_r     = e_r[i_lk];
          lk_w     = e_w[i_lk];
          lk_psize = e_ps[i_lk*2 +: 2];
        end
      end
    end
  end

  // --------------------------------------------------------------- fill slot selection
  reg [N-1:0]  conflict;       // valid entries of the fill's context whose range overlaps the fill's
  reg          have_conf, have_inv;
  reg [IW-1:0] slot_conf, slot_inv, slot_lru, slot;
  always @* begin
    conflict  = {N{1'b0}};
    have_conf = 1'b0; have_inv = 1'b0;
    slot_conf = {IW{1'b0}}; slot_inv = {IW{1'b0}}; slot_lru = {IW{1'b0}};
    for (i_fs = 0; i_fs < N; i_fs = i_fs + 1) begin
      conflict[i_fs] = e_valid[i_fs] && (e_ctx[i_fs*CTX_W +: CTX_W] == fill_ctx) &&
                    (((e_vpn[i_fs*VPN_W +: VPN_W] ^ fill_vpn) & smask(e_ps[i_fs*2 +: 2]) & smask(fill_psize)) == {VPN_W{1'b0}});
    end
    for (i_fs = N-1; i_fs >= 0; i_fs = i_fs - 1) begin       // descending loop: the lowest index wins
      if (conflict[i_fs])  begin have_conf = 1'b1; slot_conf = i_fs[IW-1:0]; end
      if (!e_valid[i_fs])  begin have_inv  = 1'b1; slot_inv  = i_fs[IW-1:0]; end
      if (e_age[i_fs*IW +: IW] == AGE_OLD) slot_lru = i_fs[IW-1:0];
    end
    slot = have_conf ? slot_conf : (have_inv ? slot_inv : slot_lru);
  end

  // --------------------------------------------------------------- invalidation match
  reg [N-1:0] inv_hit;
  always @* begin
    inv_hit = {N{1'b0}};
    for (i_iv = 0; i_iv < N; i_iv = i_iv + 1) begin
      case (inv_kind)
        `SFIO_INV_ALL:  inv_hit[i_iv] = e_valid[i_iv];
        `SFIO_INV_CTX:  inv_hit[i_iv] = e_valid[i_iv] && (e_ctx[i_iv*CTX_W +: CTX_W] == inv_ctx);
        `SFIO_INV_PAGE: inv_hit[i_iv] = e_valid[i_iv] && (e_ctx[i_iv*CTX_W +: CTX_W] == inv_ctx) &&
                                     (((e_vpn[i_iv*VPN_W +: VPN_W] ^ inv_vpn) & smask(e_ps[i_iv*2 +: 2])) == {VPN_W{1'b0}});
        default:        inv_hit[i_iv] = 1'b0;
      endcase
    end
  end

  wire do_inv  = inv_valid;
  wire do_fill = fill_valid && !inv_valid && (fill_psize != 2'd3) && (fill_r || fill_w);   // T3: the invalidation wins
  wire hit_touch = lk_touch && lk_hit && !do_fill && !do_inv;

  assign ev_fill  = do_fill;
  assign ev_evict = do_fill && !have_conf && !have_inv;   // a valid, non-overlapping entry is replaced

  // LRU touch of entry j: entries younger than j age by one, j becomes 0
  reg [IW-1:0] touch_idx;
  reg          touch_en;
  reg [IW-1:0] touch_age;
  reg [N*IW-1:0] age_n;
  always @* begin
    i_ag      = 0;
    touch_en  = do_fill || hit_touch;
    touch_idx = do_fill ? slot : {IW{1'b0}};
    if (!do_fill) begin
      for (i_ag = 0; i_ag < N; i_ag = i_ag + 1) if (match[i_ag]) touch_idx = i_ag[IW-1:0];
    end
    touch_age = e_age[touch_idx*IW +: IW];
    age_n     = e_age;
    if (touch_en) begin
      for (i_ag = 0; i_ag < N; i_ag = i_ag + 1) begin
        if (i_ag[IW-1:0] == touch_idx)                    age_n[i_ag*IW +: IW] = {IW{1'b0}};
        else if (e_age[i_ag*IW +: IW] < touch_age)        age_n[i_ag*IW +: IW] = e_age[i_ag*IW +: IW] + {{(IW-1){1'b0}}, 1'b1};
      end
    end
  end

  // --------------------------------------------------------------- state update
  integer k;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      e_valid <= {N{1'b0}};
      e_ctx   <= {(N*CTX_W){1'b0}};
      e_vpn   <= {(N*VPN_W){1'b0}};
      e_ppn   <= {(N*PPN_W){1'b0}};
      e_r     <= {N{1'b0}};
      e_w     <= {N{1'b0}};
      e_ps    <= {(N*2){1'b0}};
      for (k = 0; k < N; k = k + 1) e_age[k*IW +: IW] <= k[IW-1:0];      // a permutation from the first cycle
    end else begin
      e_age <= age_n;
      if (do_inv) begin
        e_valid <= e_valid & ~inv_hit;
      end else if (do_fill) begin
        for (k = 0; k < N; k = k + 1) begin
          if (conflict[k]) e_valid[k] <= 1'b0;                          // remove every overlapping entry ...
        end
        e_valid[slot]                    <= 1'b1;                      // ... then install the new one (last assignment wins)
        e_ctx[slot*CTX_W +: CTX_W]       <= fill_ctx;
        e_vpn[slot*VPN_W +: VPN_W]       <= fill_vpn;
        e_ppn[slot*PPN_W +: PPN_W]       <= fill_ppn;
        e_r[slot]                        <= fill_r;
        e_w[slot]                        <= fill_w;
        e_ps[slot*2 +: 2]                <= fill_psize;
      end
    end
  end

`ifdef FORMAL
  // ===========================================================================================================================
  // Formal invariants (formal/iommu/fv_tlb.sv; docs/05_VERIFICATION.md section 5).  Everything below is excluded from synthesis and simulation.
  // A free, constant TAG (f_ctx, f_vpn) is shadowed: sh_valid = "some entry may cover the tag".  Because the tag is arbitrary, a property of
  // the tag is a property of EVERY (context, page).
  // ===========================================================================================================================
  reg f_init;
  initial f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  // the tag is FREE in the first cycle and HELD afterwards (explicit, so that it means the same under SMT and AIG engines)
  (* anyseq *) wire [CTX_W-1:0] f_ctx_in;
  (* anyseq *) wire [VPN_W-1:0] f_vpn_in;
  reg [CTX_W-1:0] f_ctx_r;
  reg [VPN_W-1:0] f_vpn_r;
  wire [CTX_W-1:0] f_ctx = f_init ? f_ctx_in : f_ctx_r;
  wire [VPN_W-1:0] f_vpn = f_init ? f_vpn_in : f_vpn_r;
  always @(posedge clk) begin f_ctx_r <= f_ctx; f_vpn_r <= f_vpn; end
  reg              sh_valid, sh_r, sh_w;
  reg [PPN_W-1:0]  sh_ppn;
  reg [1:0]        sh_ps;
  wire f_fill_cov = do_fill && (fill_ctx == f_ctx) && (((fill_vpn ^ f_vpn) & smask(fill_psize)) == {VPN_W{1'b0}});
  wire f_inv_cov  = inv_valid && ((inv_kind == `SFIO_INV_ALL) ||
                                  (((inv_kind == `SFIO_INV_CTX) || (inv_kind == `SFIO_INV_PAGE)) && (inv_ctx == f_ctx) &&
                                   ((inv_kind == `SFIO_INV_CTX) || (inv_vpn == f_vpn))));
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sh_valid <= 1'b0; sh_r <= 1'b0; sh_w <= 1'b0; sh_ppn <= {PPN_W{1'b0}}; sh_ps <= 2'd0;
    end else if (f_inv_cov) begin
      sh_valid <= 1'b0;
    end else if (f_fill_cov) begin
      sh_valid <= 1'b1; sh_r <= fill_r; sh_w <= fill_w; sh_ppn <= fill_ppn; sh_ps <= fill_psize;
    end
  end
  integer fa, fb;
  reg f_cov;
  always @* begin
    f_cov = 1'b0;
    if (!f_init) begin
      for (fa = 0; fa < N; fa = fa + 1) begin
        // T4: the LRU ages are a permutation of 0..N-1
        assert (e_age[fa*IW +: IW] < N);
        // legal sizes
        assert (!e_valid[fa] || (e_ps[fa*2 +: 2] != 2'd3));
        // T6: negative caching never -- a valid entry always grants at least one right (a leaf that grants nothing, or a fault, is never cached)
        assert (!e_valid[fa] || e_r[fa] || e_w[fa]);
        for (fb = fa + 1; fb < N; fb = fb + 1) begin
          assert (e_age[fa*IW +: IW] != e_age[fb*IW +: IW]);
          // T1: no two valid entries of one context overlap  (=> a lookup matches at most one entry)
          assert (!(e_valid[fa] && e_valid[fb] && (e_ctx[fa*CTX_W +: CTX_W] == e_ctx[fb*CTX_W +: CTX_W]) &&
                    (((e_vpn[fa*VPN_W +: VPN_W] ^ e_vpn[fb*VPN_W +: VPN_W]) & smask(e_ps[fa*2 +: 2]) & smask(e_ps[fb*2 +: 2])) == {VPN_W{1'b0}})));
        end
        // the shadow relation: an entry covering the tag exists only if sh_valid, and then carries exactly the last covering fill's data
        f_cov = e_valid[fa] && (e_ctx[fa*CTX_W +: CTX_W] == f_ctx) && (((e_vpn[fa*VPN_W +: VPN_W] ^ f_vpn) & smask(e_ps[fa*2 +: 2])) == {VPN_W{1'b0}});
        if (f_cov) begin
          assert (sh_valid);
          assert (e_ppn[fa*PPN_W +: PPN_W] == sh_ppn);
          assert (e_r[fa] == sh_r);
          assert (e_w[fa] == sh_w);
          assert (e_ps[fa*2 +: 2] == sh_ps);
        end
      end
      assert (!lk_multi);                                              // T1: a multi-match never happens
      assert (!(inv_valid && ev_fill));                                // T3: an invalidation beats a fill in the same cycle
      if (lk_hit && (lk_ctx == f_ctx) && (lk_vpn == f_vpn)) begin     // T2: no stale hit; T5: data integrity
        assert (sh_valid);
        assert (lk_ppn == sh_ppn);
        assert (lk_r == sh_r);
        assert (lk_w == sh_w);
        assert (lk_psize == sh_ps);
      end
    end
  end
`endif
endmodule
`default_nettype wire
