// =============================================================================
// SilicaFlux -- Project 108 -- PageWalker :: sf_iommu_invalidation
//
// Explicit invalidation: ALL / CTX c / PAGE c,va, and the context-programming commit (a CTX invalidation fused with the table write).
// ONE command slot.  DRAIN-THEN-COMMIT (docs/01 section 8):
//
//   IDLE   --command accepted (the cycle of the CSR write)-->   DRAIN
//   DRAIN  blocking = 1 from the NEXT cycle: no new translation request is accepted.
//          wait until the translator is idle (the last response has been ACCEPTED) and dma_quiet = 1
//          timeout (DRAIN_TMO != 0): the command is NOT applied -> DONE with status TMO
//   COMMIT one cycle: tlb_inv_* (and cu_commit for a context command).  The translator is idle, so no walk is in flight and
//          nothing can re-install a stale entry after this cycle.
//   DONE   one cycle: done_evt with the status; then IDLE.
//
// Formal (formal/iommu/fv_inv.sv): tlb_inv_valid / cu_commit only in COMMIT, only after pipe_idle (and dma_quiet) was seen in the DRAIN cycle
// that led to it; a timeout never commits; the FSM always returns to IDLE (bounded); only one command at a time.
// =============================================================================
`default_nettype none
`include "sf_iommu_defs.svh"
module sf_iommu_invalidation #(
  parameter integer NUM_CTX           = 4,
  parameter integer CTX_W             = 2,
  parameter integer VPN_W             = 27,
  parameter integer DRAIN_TMO_DEFAULT = 256,
  parameter integer WAIT_DMA_QUIET    = 1
) (
  input  wire                 clk,
  input  wire                 rst_n,
  // CSR slice
  input  wire                 csr_wr,
  input  wire [4:0]           csr_idx,
  input  wire [31:0]          csr_wdata,
  output reg  [31:0]          csr_rdata,
  output reg                  csr_hit,
  input  wire                 locked,
  output reg                  ce_evt,
  output reg  [3:0]           ce_code,
  // context-programming command from sf_iommu_context
  input  wire                 cu_req,
  input  wire                 cu_clear,
  input  wire [CTX_W-1:0]     cu_idx,
  output reg                  cu_commit,
  output reg                  cu_commit_clear,
  output reg  [CTX_W-1:0]     cu_commit_idx,
  // translator
  input  wire                 pipe_idle,
  input  wire                 dma_quiet,
  output wire                 busy,            // blocking: req_ready must be 0
  // TLB
  output reg                  tlb_inv_valid,
  output reg  [1:0]           tlb_inv_kind,
  output reg  [CTX_W-1:0]     tlb_inv_ctx,
  output reg  [VPN_W-1:0]     tlb_inv_vpn,
  // completion
  output reg                  done_evt,        // one cycle, in the DONE state
  output reg                  done_ok_evt,     // ... and the command was applied
  output reg                  done_tmo_evt,    // ... and the command was NOT applied (drain timeout)
  output reg  [1:0]           done_status
);
  localparam [1:0] S_IDLE = 2'd0, S_DRAIN = 2'd1, S_COMMIT = 2'd2, S_DONE = 2'd3;
  reg [1:0]   st;
  assign busy = (st != S_IDLE);

  // staged operands
  reg [31:0]  drain_tmo;
  reg [31:0]  s_ctx, s_va_lo, s_va_hi;
  // the active command
  reg [1:0]         a_kind;
  reg [CTX_W-1:0]   a_ctx;
  reg [VPN_W-1:0]   a_vpn;
  reg               a_from_ctx, a_clear;
  reg [31:0]        tmo_cnt;
  reg [15:0]        done_cnt;
  reg [1:0]         last_status;

  // ---------------------------------------------------------------- CSR read
  always @* begin
    csr_hit   = 1'b1;
    csr_rdata = 32'd0;
    case (csr_idx)
      `SFIO_R_DRAIN_TMO: csr_rdata = drain_tmo;
      `SFIO_R_INV_CTX:   csr_rdata = s_ctx;
      `SFIO_R_INV_VA_LO: csr_rdata = s_va_lo;
      `SFIO_R_INV_VA_HI: csr_rdata = s_va_hi;
      `SFIO_R_INV_CMD:   csr_rdata = 32'd0;
      `SFIO_R_INV_STAT:  csr_rdata = {done_cnt, 12'd0, last_status, 1'b0, busy};
      default:           begin csr_hit = 1'b0; csr_rdata = 32'd0; end
    endcase
  end

  // ---------------------------------------------------------------- command validation (write cycle)
  wire        wr_cmd    = csr_wr && (csr_idx == `SFIO_R_INV_CMD);
  wire [1:0]  k_in      = csr_wdata[1:0];
  wire        k_known   = (csr_wdata == 32'd1) || (csr_wdata == 32'd2) || (csr_wdata == 32'd3);
  wire        k_needctx = (k_in == `SFIO_INV_CTX) || (k_in == `SFIO_INV_PAGE);
  wire        ctx_ok    = (s_ctx < NUM_CTX);
  wire        va_canon  = ({s_va_hi[31:6]} == {26{s_va_hi[6]}});         // iova[63:38] all equal (bit 38 = hi[6])
  reg         cmd_ok;
  reg [3:0]   cmd_code;
  always @* begin
    cmd_ok = 1'b0; cmd_code = `SFIO_CE_OK;
    if (busy)                                              cmd_code = `SFIO_CE_BUSY;
    else if (!k_known)                                     cmd_code = `SFIO_CE_CMD;
    else if (k_needctx && !ctx_ok)                         cmd_code = `SFIO_CE_INDEX;
    else if (k_in == `SFIO_INV_PAGE && !va_canon)          cmd_code = `SFIO_CE_RANGE;
    else                                                   cmd_ok   = 1'b1;
  end
  wire wr_stage = csr_wr && ((csr_idx == `SFIO_R_INV_CTX) || (csr_idx == `SFIO_R_INV_VA_LO) || (csr_idx == `SFIO_R_INV_VA_HI));
  wire wr_tmo   = csr_wr && (csr_idx == `SFIO_R_DRAIN_TMO);

  always @* begin
    ce_evt = 1'b0; ce_code = `SFIO_CE_OK;
    if (wr_cmd && !cmd_ok)       begin ce_evt = 1'b1; ce_code = cmd_code;          end
    else if (wr_stage && busy)   begin ce_evt = 1'b1; ce_code = `SFIO_CE_BUSY;     end
    else if (wr_tmo && locked)   begin ce_evt = 1'b1; ce_code = `SFIO_CE_LOCKED;   end
    else if (wr_tmo && busy)     begin ce_evt = 1'b1; ce_code = `SFIO_CE_BUSY;     end
    else if (st == S_DONE && done_status == `SFIO_IS_TMO) begin ce_evt = 1'b1; ce_code = `SFIO_CE_TMO; end
  end

  // ---------------------------------------------------------------- DRAIN decision (combinational)
  wire wait_ok  = pipe_idle && ((WAIT_DMA_QUIET == 0) || dma_quiet);
  wire tmo_hit  = (drain_tmo != 32'd0) && (tmo_cnt >= (drain_tmo - 32'd1));

  // ---------------------------------------------------------------- outputs of the active command
  always @* begin
    tlb_inv_valid   = (st == S_COMMIT);
    tlb_inv_kind    = a_kind;
    tlb_inv_ctx     = a_ctx;
    tlb_inv_vpn     = a_vpn;
    cu_commit       = (st == S_COMMIT) && a_from_ctx;
    cu_commit_clear = a_clear;
    cu_commit_idx   = a_ctx;
    done_evt        = (st == S_DONE);
    done_ok_evt     = (st == S_DONE) && (done_status == `SFIO_IS_OK);
    done_tmo_evt    = (st == S_DONE) && (done_status == `SFIO_IS_TMO);
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; drain_tmo <= DRAIN_TMO_DEFAULT; s_ctx <= 32'd0; s_va_lo <= 32'd0; s_va_hi <= 32'd0;
      a_kind <= `SFIO_INV_NONE; a_ctx <= {CTX_W{1'b0}}; a_vpn <= {VPN_W{1'b0}}; a_from_ctx <= 1'b0; a_clear <= 1'b0;
      tmo_cnt <= 32'd0; done_cnt <= 16'd0; last_status <= `SFIO_IS_OK; done_status <= `SFIO_IS_OK;
    end else begin
      if (wr_stage && !busy) begin
        if (csr_idx == `SFIO_R_INV_CTX)   s_ctx   <= csr_wdata;
        if (csr_idx == `SFIO_R_INV_VA_LO) s_va_lo <= csr_wdata;
        if (csr_idx == `SFIO_R_INV_VA_HI) s_va_hi <= csr_wdata;
      end
      if (wr_tmo && !locked && !busy) drain_tmo <= csr_wdata;
      case (st)
        S_IDLE: begin
          if (wr_cmd && cmd_ok) begin                      // command accepted in this cycle
            a_kind     <= k_in;
            a_ctx      <= s_ctx[CTX_W-1:0];
            a_vpn      <= {s_va_hi[6:0], s_va_lo[31:12]};  // iova[38:12]
            a_from_ctx <= 1'b0;
            a_clear    <= 1'b0;
            tmo_cnt    <= 32'd0;
            st         <= S_DRAIN;
          end else if (cu_req) begin                       // context-programming command accepted in this cycle
            a_kind     <= `SFIO_INV_CTX;
            a_ctx      <= cu_idx;
            a_vpn      <= {VPN_W{1'b0}};
            a_from_ctx <= 1'b1;
            a_clear    <= cu_clear;
            tmo_cnt    <= 32'd0;
            st         <= S_DRAIN;
          end
        end
        S_DRAIN: begin
          if (wait_ok) begin
            st <= S_COMMIT;
          end else if (tmo_hit) begin
            done_status <= `SFIO_IS_TMO;                   // NOT applied
            st          <= S_DONE;
          end else begin
            tmo_cnt <= tmo_cnt + 32'd1;
          end
        end
        S_COMMIT: begin
          done_status <= `SFIO_IS_OK;
          st          <= S_DONE;
        end
        S_DONE: begin
          last_status <= done_status;
          if (done_status == `SFIO_IS_OK) done_cnt <= done_cnt + 16'd1;
          st <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase
    end
  end

`ifdef FORMAL
  // ===========================================================================================================================
  // Formal (formal/iommu/fv_inv.sv; docs/05 section 5): drain-then-commit.
  //   V1  a commit (tlb_inv_valid / cu_commit) happens only in COMMIT, which is entered only from a DRAIN cycle that saw wait_ok
  //   V2  a timed-out command never commits: COMMIT is never visited between acceptance and a TMO completion
  //   V3  bounded: with DRAIN_TMO != 0 the DRAIN state lasts at most DRAIN_TMO cycles
  //   V4  exactly one completion per accepted command; DONE only after DRAIN/COMMIT
  //   V5  one command at a time: the active command registers are stable while busy
  // ===========================================================================================================================
  reg f_init;
  initial f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  reg [1:0] f_st_q;
  reg       f_waitok_q;
  reg       f_idle_q, f_quiet_q;                                   // the PORT values of the previous cycle (independent of the wait_ok wire)
  reg       f_commit_seen;
  reg [1:0] f_kind_q;
  reg       f_busy_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin f_st_q <= S_IDLE; f_waitok_q <= 1'b0; f_commit_seen <= 1'b0; f_kind_q <= 2'd0; f_busy_q <= 1'b0; f_idle_q <= 1'b0; f_quiet_q <= 1'b0; end
    else begin
      f_st_q <= st; f_waitok_q <= wait_ok; f_kind_q <= a_kind; f_busy_q <= busy; f_idle_q <= pipe_idle; f_quiet_q <= dma_quiet;
      if (st == S_COMMIT)    f_commit_seen <= 1'b1;
      else if (st == S_DONE) f_commit_seen <= 1'b0;                 // visible exactly in the DONE cycle of a command that committed
    end
  end
  always @* begin
    if (!f_init) begin
      assert (tlb_inv_valid == (st == S_COMMIT));
      assert (cu_commit == ((st == S_COMMIT) && a_from_ctx));
      assert (!(cu_commit && !tlb_inv_valid));
      if (st == S_COMMIT) begin                                        // V1
        assert (f_st_q == S_DRAIN);
        assert (f_waitok_q);
        assert (f_idle_q);                                             // the translator (pipeline) was idle in the cycle that sent the FSM to COMMIT
        assert (WAIT_DMA_QUIET == 0 || f_quiet_q);                     // and, when waiting for the platform, dma_quiet was high
      end
      if (st == S_DONE && done_status == `SFIO_IS_TMO) assert (!f_commit_seen);   // V2
      if (st == S_DONE && done_status == `SFIO_IS_OK)  assert (f_commit_seen);
      if (st == S_DRAIN && drain_tmo != 32'd0) assert (tmo_cnt <= drain_tmo - 32'd1);   // V3
      if (st == S_IDLE) assert (!f_commit_seen);
      if (f_commit_seen) begin assert (st == S_DONE); assert (done_status == `SFIO_IS_OK); end      // strengthening: the commit flag lives only in DONE
      assert (done_evt == (st == S_DONE));                            // V4
      assert (!(done_ok_evt && done_tmo_evt));
      if (f_busy_q && busy) assert (a_kind == f_kind_q);              // V5
      assert (st <= S_DONE);
    end
  end
`endif
endmodule
`default_nettype wire
