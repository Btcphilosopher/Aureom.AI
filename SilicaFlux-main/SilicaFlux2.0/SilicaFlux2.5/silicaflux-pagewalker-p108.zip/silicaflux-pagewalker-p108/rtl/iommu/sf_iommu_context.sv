// =============================================================================
// SilicaFlux -- Project 108 -- PageWalker :: sf_iommu_context
//
// TRUSTED DEVICE CONTEXT TABLE.   req_dev (a hardware sideband, never a descriptor field) selects one entry:
//   {valid, root PPN, allow_r, allow_w}            mode is always Sv39 when valid; there is NO pass-through (BARE) mode
// An entry can be written only through the privileged configuration port, validated at programming time, and changed
// only inside an invalidation commit (the table write and the TLB flush of that context happen in the SAME cycle):
// no request ever sees a new root with the TLB entries of the old one, and no walk straddles a change.
//
//   CTX_SEL, CTX_ROOT_LO/HI, CTX_ATTR   staging registers (writable while neither locked nor busy)
//   CTX_CMD  1 = SET (install staged entry at CTX_SEL)   2 = CLEAR (invalidate it)
//   CTX_RD_*  read back the INSTALLED entry of CTX_SEL
//
// Validation (CE_* codes as MemoryGuard P104):  locked -> CE_LOCKED   busy -> CE_BUSY   CTX_SEL >= NUM_CTX -> CE_INDEX
//   SET: mode field must be SV39 (BARE / reserved modes refused), no reserved attribute / root bits, root PPN < 2**FAB_PPN_W -> else CE_RANGE
//   an unknown command value -> CE_CMD
// =============================================================================
`default_nettype none
`include "sf_iommu_defs.svh"
module sf_iommu_context #(
  parameter integer NUM_CTX   = 4,
  parameter integer DEV_W     = 4,
  parameter integer CTX_W     = 2,      // = clog2(NUM_CTX)
  parameter integer PPN_W     = 20,     // root PPN bits stored (PA_W - 12)
  parameter integer FAB_PPN_W = 20      // FAB_AW - 12: a page table must lie below 2**FAB_AW
) (
  input  wire                 clk,
  input  wire                 rst_n,
  // combinational lookup, selected by the trusted device id
  input  wire [DEV_W-1:0]     lk_dev,
  output wire                 lk_ok,        // dev in range and the entry is valid
  output wire [CTX_W-1:0]     lk_idx,
  output wire [PPN_W-1:0]     lk_root,
  output wire                 lk_allow_r,
  output wire                 lk_allow_w,
  // CSR slice
  input  wire                 csr_wr,       // a privileged write handshake this cycle
  input  wire [4:0]           csr_idx,
  input  wire [31:0]          csr_wdata,
  output reg  [31:0]          csr_rdata,
  output reg                  csr_hit,      // csr_idx belongs to this slice
  input  wire                 locked,       // CTRL.LOCK
  input  wire                 cmd_busy,     // an invalidation / context commit is in progress
  output reg                  ce_evt,       // a configuration command was refused ...
  output reg  [3:0]           ce_code,      // ... with this CE_* code
  // command to the invalidation engine (same-cycle pulse together with the accepted CTX_CMD write)
  output reg                  cu_req,
  output reg                  cu_clear,     // 0 = SET, 1 = CLEAR
  output reg  [CTX_W-1:0]     cu_idx,
  // commit from the invalidation engine (one cycle, together with the TLB flush)
  input  wire                 cu_commit,
  input  wire                 cu_commit_clear,
  input  wire [CTX_W-1:0]     cu_commit_idx
);
  reg [NUM_CTX-1:0]       c_valid;
  reg [NUM_CTX*PPN_W-1:0] c_root;
  reg [NUM_CTX-1:0]       c_ar, c_aw;

  // staging
  reg [31:0]        sel_q;
  reg [31:0]        st_root_lo, st_root_hi, st_attr;

  // ---------------------------------------------------------------- lookup
  wire [31:0] dev32   = {{(32-DEV_W){1'b0}}, lk_dev};
  wire        in_rng  = (dev32 < NUM_CTX);
  assign lk_idx       = lk_dev[CTX_W-1:0];
  assign lk_ok        = in_rng && c_valid[lk_idx];
  assign lk_root      = c_root[lk_idx*PPN_W +: PPN_W];
  assign lk_allow_r   = c_ar[lk_idx];
  assign lk_allow_w   = c_aw[lk_idx];

  // ---------------------------------------------------------------- CSR read
  wire        sel_ok  = (sel_q < NUM_CTX);
  wire [CTX_W-1:0] sel_i = sel_q[CTX_W-1:0];
  wire        rd_v    = sel_ok && c_valid[sel_i];
  wire [PPN_W-1:0] rd_root = rd_v ? c_root[sel_i*PPN_W +: PPN_W] : {PPN_W{1'b0}};
  wire [63:0]      rd_root64 = {{(64-PPN_W){1'b0}}, rd_root};
  always @* begin
    csr_hit   = 1'b1;
    csr_rdata = 32'd0;
    case (csr_idx)
      `SFIO_R_CTX_SEL:      csr_rdata = sel_q;
      `SFIO_R_CTX_ROOT_LO:  csr_rdata = st_root_lo;
      `SFIO_R_CTX_ROOT_HI:  csr_rdata = st_root_hi;
      `SFIO_R_CTX_ATTR:     csr_rdata = st_attr;
      `SFIO_R_CTX_CMD:      csr_rdata = 32'd0;                           // write-only
      `SFIO_R_CTX_RD_LO:    csr_rdata = rd_root64[31:0];
      `SFIO_R_CTX_RD_HI:    csr_rdata = rd_root64[63:32];
      `SFIO_R_CTX_RD_ATTR:  csr_rdata = {rd_v, 27'd0, (rd_v ? `SFIO_MODE_SV39 : `SFIO_MODE_OFF),
                                         (rd_v ? c_aw[sel_i] : 1'b0), (rd_v ? c_ar[sel_i] : 1'b0)};
      default:              begin csr_hit = 1'b0; csr_rdata = 32'd0; end
    endcase
  end

  // ---------------------------------------------------------------- command validation (combinational, evaluated in the write cycle)
  wire        wr_cmd     = csr_wr && (csr_idx == `SFIO_R_CTX_CMD);
  wire        op_set     = (csr_wdata == 32'd1);
  wire        op_clr     = (csr_wdata == 32'd2);
  wire        mode_ok    = (st_attr[3:2] == `SFIO_MODE_SV39);
  wire        attr_rsv   = (st_attr[31:4] != 28'd0);
  // staged root PPN as a 44-bit value; must fit PPN_W bits and the fabric; hi register carries bits [43:32] only
  wire [43:0] st_root44  = {st_root_hi[11:0], st_root_lo};
  wire        root_rsv   = (st_root_hi[31:12] != 20'd0);
  wire        root_big   = (st_root44 >> FAB_PPN_W) != 44'd0;
  reg         v_ok;
  reg [3:0]   v_code;
  always @* begin
    v_ok = 1'b0; v_code = `SFIO_CE_OK;
    if (locked)                         v_code = `SFIO_CE_LOCKED;
    else if (cmd_busy)                  v_code = `SFIO_CE_BUSY;
    else if (!(op_set || op_clr))       v_code = `SFIO_CE_CMD;
    else if (!sel_ok)                   v_code = `SFIO_CE_INDEX;
    else if (op_set && (!mode_ok || attr_rsv || root_rsv || root_big)) v_code = `SFIO_CE_RANGE;
    else                                v_ok = 1'b1;
  end
  // a write to a staging register while locked / busy is refused too
  wire wr_stage = csr_wr && ((csr_idx == `SFIO_R_CTX_ROOT_LO) || (csr_idx == `SFIO_R_CTX_ROOT_HI) || (csr_idx == `SFIO_R_CTX_ATTR));

  always @* begin
    cu_req   = wr_cmd && v_ok;
    cu_clear = op_clr;
    cu_idx   = sel_q[CTX_W-1:0];
    ce_evt   = 1'b0;
    ce_code  = `SFIO_CE_OK;
    if (wr_cmd && !v_ok) begin ce_evt = 1'b1; ce_code = v_code; end
    else if (wr_stage && locked)   begin ce_evt = 1'b1; ce_code = `SFIO_CE_LOCKED; end
    else if (wr_stage && cmd_busy) begin ce_evt = 1'b1; ce_code = `SFIO_CE_BUSY; end
  end

  // ---------------------------------------------------------------- state
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      c_valid    <= {NUM_CTX{1'b0}};
      c_root     <= {(NUM_CTX*PPN_W){1'b0}};
      c_ar       <= {NUM_CTX{1'b0}};
      c_aw       <= {NUM_CTX{1'b0}};
      sel_q      <= 32'd0;
      st_root_lo <= 32'd0;
      st_root_hi <= 32'd0;
      st_attr    <= 32'd0;
    end else begin
      if (csr_wr && csr_idx == `SFIO_R_CTX_SEL) sel_q <= csr_wdata;
      if (wr_stage && !locked && !cmd_busy) begin
        if (csr_idx == `SFIO_R_CTX_ROOT_LO) st_root_lo <= csr_wdata;
        if (csr_idx == `SFIO_R_CTX_ROOT_HI) st_root_hi <= csr_wdata;
        if (csr_idx == `SFIO_R_CTX_ATTR)    st_attr    <= csr_wdata;
      end
      if (cu_commit) begin
        if (cu_commit_clear) begin
          c_valid[cu_commit_idx]                        <= 1'b0;
          c_root[cu_commit_idx*PPN_W +: PPN_W]          <= {PPN_W{1'b0}};
          c_ar[cu_commit_idx]                           <= 1'b0;
          c_aw[cu_commit_idx]                           <= 1'b0;
        end else begin
          c_valid[cu_commit_idx]                        <= 1'b1;
          c_root[cu_commit_idx*PPN_W +: PPN_W]          <= st_root44[PPN_W-1:0];
          c_ar[cu_commit_idx]                           <= st_attr[0];
          c_aw[cu_commit_idx]                           <= st_attr[1];
        end
      end
    end
  end

`ifdef FORMAL
  // Formal (formal/iommu/fv_ctx.sv; docs/05 section 5):
  //   C1  a command is issued only when every validation rule holds (an independent statement of docs/02 section 4)
  //   C2  the table changes only at a commit
  //   C3  an installed context always has a root PPN inside the fabric (root PPN < 2**FAB_PPN_W)
  //   C4  an unprogrammed / cleared / out-of-range device id is never reported valid
  //   C5  the cycle after a commit the entry is exactly the command's: SET = the staged root and caps, valid; CLEAR = invalid with no caps
  // ENVIRONMENT CONTRACT (the invalidation FSM guarantees it; proved there, formal/iommu/fv_inv.sv): from a command until the engine goes idle,
  // cmd_busy is high (so the staging area is frozen: writes are refused while busy), and a commit follows only a still-pending command and
  // carries that command's context index and operation.
  reg f_init;
  initial f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  reg                f_pend, f_clear, f_busy_q, f_commit_q, f_rstn_q;
  reg [CTX_W-1:0]    f_idx;
  reg [NUM_CTX-1:0]  f_valid_q;
  wire               f_act = f_pend && cmd_busy;                 // a command is pending and the engine has not finished it
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin f_pend <= 1'b0; f_clear <= 1'b0; f_idx <= {CTX_W{1'b0}}; end
    else begin
      if (cu_req) begin f_pend <= 1'b1; f_clear <= cu_clear; f_idx <= cu_idx; end
      else if (!cmd_busy || cu_commit) f_pend <= 1'b0;
    end
  end
  always @(posedge clk) begin f_valid_q <= c_valid; f_commit_q <= cu_commit; f_rstn_q <= rst_n; f_busy_q <= cmd_busy; end
  wire [43:0] f_root44 = {st_root_hi[11:0], st_root_lo};
  always @* begin
    if (!f_init) begin
      assume (!cu_commit || f_act);
      assume (!cu_commit || (cu_commit_idx == f_idx && cu_commit_clear == f_clear));
    end
  end
  integer fc;
  always @* begin
    if (!f_init) begin
      if (cu_req) begin                                                           // C1
        assert (!locked && !cmd_busy);
        assert (csr_wdata == 32'd1 || csr_wdata == 32'd2);
        assert (sel_q < NUM_CTX);
        if (csr_wdata == 32'd1) begin
          assert (st_attr[3:2] == 2'd1);
          assert (st_attr[31:4] == 28'd0);
          assert (st_root_hi[31:12] == 20'd0);
          assert (f_root44 < (44'd1 << FAB_PPN_W));
        end
      end
      if (f_act && !f_clear) begin                                                // the frozen staging area of a pending SET is a validated one
        assert (st_attr[3:2] == 2'd1);
        assert (st_attr[31:4] == 28'd0);
        assert (st_root_hi[31:12] == 20'd0);
        assert (f_root44 < (44'd1 << FAB_PPN_W));
      end
      for (fc = 0; fc < NUM_CTX; fc = fc + 1) begin
        if (c_valid[fc]) assert (({{(44-PPN_W){1'b0}}, c_root[fc*PPN_W +: PPN_W]}) < (44'd1 << FAB_PPN_W));    // C3
      end
      if (f_rstn_q && rst_n && !f_commit_q) assert (c_valid == f_valid_q);       // C2 (the valid bits; roots / caps change with them)
      if (lk_ok) begin assert ({{(32-DEV_W){1'b0}}, lk_dev} < NUM_CTX); assert (c_valid[lk_idx]); end    // C4
      assert ({{(32-CTX_W){1'b0}}, f_idx} < NUM_CTX);                              // strengthening for C5: the remembered command index is a real context
      if (f_commit_q && f_rstn_q && rst_n) begin                                  // C5: the cycle after a commit, the entry is exactly what the command asked for
        if (f_clear) begin
          assert (!c_valid[f_idx]);
          assert (!c_ar[f_idx] && !c_aw[f_idx]);
        end else begin
          assert (c_valid[f_idx]);
          assert ({{(44-PPN_W){1'b0}}, c_root[f_idx*PPN_W +: PPN_W]} == (f_root44 & ((44'd1 << PPN_W) - 44'd1)));
          assert (c_ar[f_idx] == st_attr[0]);
          assert (c_aw[f_idx] == st_attr[1]);
        end
      end
    end
  end
`endif
endmodule
`default_nettype wire
