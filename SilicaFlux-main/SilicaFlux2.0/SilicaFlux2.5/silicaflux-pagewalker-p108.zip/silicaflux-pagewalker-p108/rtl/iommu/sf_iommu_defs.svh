// =============================================================================
// SilicaFlux -- Project 108 -- PageWalker :: sf_iommu_defs.svh
//
// Constants of the translation engine.  A header of `define macros (not a package) because the repository's baseline flow
// (Yosys 0.33 front end) accepts neither package imports nor structs in synthesizable RTL -- the same rule as P103/P104.
// docs/01_SPEC_SUBSET.md is the normative text; this file is its machine-readable form.  The independent Python reference
// model (tests/iommu/ref_model.py) is written from the document, NOT from this file.
// =============================================================================
`ifndef SF_IOMMU_DEFS_SVH
`define SF_IOMMU_DEFS_SVH

// ----------------------------------------------------------------------------- fault causes (4 bit)
// 1..8 are the eight causes of the brief, in the brief's order; 9 and 10 are additions (docs/01 section 6).
`define SFIO_F_NONE         4'd0   // permitted
`define SFIO_F_BAD_CONTEXT  4'd1   // invalid / disabled / out-of-range device context, or descriptor claim != bound context
`define SFIO_F_NOT_PRESENT  4'd2   // a PTE on the walk has V = 0
`define SFIO_F_PERM         4'd3   // permission denied: R / W / U / A / D of the leaf, or the context's direction cap
`define SFIO_F_MALFORMED    4'd4   // structurally invalid table: pointer at level 0, pointer PPN outside the fabric, misaligned superpage
`define SFIO_F_PAGE_SIZE    4'd5   // a leaf at level 1 or 2 (2 MiB / 1 GiB) while SUPERPAGE_EN = 0
`define SFIO_F_PHYS_READ    4'd6   // a PTE read failed: bus error, timeout, or the fabric port is wedged by an earlier timeout
`define SFIO_F_INVALID_PTE  4'd7   // reserved bits set, reserved R/W encoding, reserved non-leaf A/D/U, or unstable (torn) PTE
`define SFIO_F_ADDR_OVERFLOW 4'd8  // IOVA + length wraps 2**64, or a leaf PPN beyond the implemented physical address width
`define SFIO_F_NONCANONICAL 4'd9   // IOVA (first or last byte) is not a canonical Sv39 address
`define SFIO_F_BAD_REQUEST  4'd10  // zero length, or length > MAX_BYTES
`define SFIO_NFAULT         11     // codes 0..10 defined

// ----------------------------------------------------------------------------- Sv39 PTE (64 bit)
`define SFIO_PTE_V   0
`define SFIO_PTE_R   1
`define SFIO_PTE_W   2
`define SFIO_PTE_X   3
`define SFIO_PTE_U   4
`define SFIO_PTE_G   5
`define SFIO_PTE_A   6
`define SFIO_PTE_D   7
// [9:8] RSW (ignored), [53:10] PPN, [63:54] reserved (must be zero: no Svpbmt / Svnapot / Svadu)
`define SFIO_PTE_PPN_LO 10
`define SFIO_PTE_PPN_HI 53

// ----------------------------------------------------------------------------- invalidation kinds
`define SFIO_INV_NONE 2'd0
`define SFIO_INV_ALL  2'd1    // every entry of every context
`define SFIO_INV_CTX  2'd2    // every entry of one context
`define SFIO_INV_PAGE 2'd3    // the entry (entries) of one context that cover one IOVA page

`define SFIO_IS_OK    2'd0    // invalidation completed
`define SFIO_IS_TMO   2'd1    // drain timeout: NOT applied
`define SFIO_IS_BAD   2'd2    // command refused (index / address / busy / lock); never reaches the engine

// ----------------------------------------------------------------------------- configuration errors (numbers as MemoryGuard P104)
`define SFIO_CE_OK      4'd0
`define SFIO_CE_RANGE   4'd1   // root PPN outside the fabric, reserved attribute bits / mode, non-canonical invalidation address
`define SFIO_CE_INDEX   4'd3   // context / counter index out of range
`define SFIO_CE_PRIV    4'd4   // not privileged
`define SFIO_CE_LOCKED  4'd5   // CTRL.LOCK is set
`define SFIO_CE_BUSY    4'd6   // an invalidation / context commit is in progress
`define SFIO_CE_TMO     4'd7   // drain timeout: the command was NOT applied
`define SFIO_CE_CMD     4'd8   // unknown command / bad register address / write to a read-only register

// ----------------------------------------------------------------------------- context modes
`define SFIO_MODE_OFF   2'd0
`define SFIO_MODE_SV39  2'd1   // the only supported translation mode; BARE (pass-through) is deliberately NOT supported
// 2 and 3 are reserved: a context command naming them is refused (CE_RANGE)

// ----------------------------------------------------------------------------- CSR map (32-bit words; byte address = 4 * index)
`define SFIO_R_ID           5'd0    // RO   [31:16] 0x5057 "PW"   [15:8] TLB_ENTRIES   [7:0] NUM_CTX
`define SFIO_R_VERSION      5'd1    // RO
`define SFIO_R_CTRL         5'd2    // RW   [0] IRQ_EN   [31] LOCK (set-only, cleared by reset only)
`define SFIO_R_STATUS       5'd3    // RW1C sticky flags (SFIO_ST_*)
`define SFIO_R_STATE        5'd4    // RO   [0] inv busy [1] request blocking [2] locked [3] translator busy [4] walker busy [5] fabric wedged [11:8] last CE_*
`define SFIO_R_DRAIN_TMO    5'd5    // RW   drain timeout in cycles, 0 = wait forever (writable until locked)
`define SFIO_R_INV_CTX      5'd6    // RW   staged context for INV_CTX / INV_PAGE
`define SFIO_R_INV_VA_LO    5'd7    // RW   staged IOVA for INV_PAGE
`define SFIO_R_INV_VA_HI    5'd8
`define SFIO_R_INV_CMD      5'd9    // WO   [1:0] SFIO_INV_*
`define SFIO_R_INV_STAT     5'd10   // RO   [0] busy [3:2] last status (SFIO_IS_*) [31:16] completed-invalidation count (low 16)
`define SFIO_R_CTX_SEL      5'd11   // RW   context index being programmed / read back
`define SFIO_R_CTX_ROOT_LO  5'd12   // RW   staged root PPN [31:0]
`define SFIO_R_CTX_ROOT_HI  5'd13   // RW   staged root PPN [43:32]
`define SFIO_R_CTX_ATTR     5'd14   // RW   [0] allow R  [1] allow W  [3:2] MODE
`define SFIO_R_CTX_CMD      5'd15   // WO   [3:0] 1 = SET (install staged), 2 = CLEAR
`define SFIO_R_CTX_RD_LO    5'd16   // RO   installed entry of CTX_SEL: root PPN [31:0]
`define SFIO_R_CTX_RD_HI    5'd17   // RO   root PPN [43:32]
`define SFIO_R_CTX_RD_ATTR  5'd18   // RO   [31] VALID  [1:0] allow R/W  [3:2] MODE
`define SFIO_R_FLOG_CNT     5'd19   // RO   [7:0] records held [15:8] depth [31:16] dropped (saturating)
`define SFIO_R_FLOG_W0      5'd20   // RO   head: [3:0] cause [5:4] level (3 = n/a) [6] write [15:8] device [31:16] request id
`define SFIO_R_FLOG_W1      5'd21   // RO   head: IOVA [31:0]
`define SFIO_R_FLOG_W2      5'd22   // RO   head: IOVA [63:32]
`define SFIO_R_FLOG_W3      5'd23   // RO   head: [15:0] length in bytes
`define SFIO_R_FLOG_SEQ     5'd24   // RO   head: fault sequence number
`define SFIO_R_FLOG_POP     5'd25   // WO   [0] drop the head record
`define SFIO_R_CNT_SEL      5'd26   // RW   counter index
`define SFIO_R_CNT_DATA     5'd27   // RO   selected counter (saturating, never wraps)
`define SFIO_R_NCNT         5'd28   // RO   number of counters
`define SFIO_R_CAPS         5'd29   // RO   [7:0] PA_W  [15:8] DW  [31:16] MAX_BYTES
`define SFIO_R_CAPS2        5'd30   // RO   [3:0] flags: [0] SUPERPAGE_EN [1] WAIT_DMA_QUIET [2] PTE_DOUBLE_READ
`define SFIO_NREG           31

// STATUS bits (sticky unless noted; write 1 to clear)
`define SFIO_ST_FAULT_PEND  0    // RO mirror: the fault log holds a record
`define SFIO_ST_INV_DONE    1
`define SFIO_ST_INV_TMO     2
`define SFIO_ST_CMD_ERR     3
`define SFIO_ST_PRIV        4    // an unprivileged configuration access was rejected
`define SFIO_ST_LOCKED_REJ  5
`define SFIO_ST_BADADDR     6
`define SFIO_ST_FQ_DROP     7
`define SFIO_ST_FAB_ERR     8    // a page-table read failed (error response or timeout)
`define SFIO_ST_STRAY       9    // a fabric response arrived with nothing outstanding and was discarded
`define SFIO_ST_WEDGED      10   // RO live: the fabric port still owes a response to an abandoned (timed-out) read

// ----------------------------------------------------------------------------- performance counters (CSR CNT_SEL index)
`define SFIO_CN_REQS        0    // requests accepted
`define SFIO_CN_SEGS        1    // page segments looked up (a request crossing one page boundary has two)
`define SFIO_CN_TLB_HIT     2
`define SFIO_CN_TLB_MISS    3
`define SFIO_CN_WALKS       4
`define SFIO_CN_WALK_CYC    5    // sum over walks of (cycles from start to done)
`define SFIO_CN_WALK_REFS   6    // sum over walks of fabric read transactions accepted
`define SFIO_CN_WALK_FAULT  7    // walks that ended in a fault
`define SFIO_CN_WALK_MAX    8    // longest walk in cycles
`define SFIO_CN_LAT_SUM     9    // sum over requests of (handshake -> first response valid) cycles
`define SFIO_CN_LAT_N       10   // requests with a latency sample
`define SFIO_CN_LAT_MAX     11
`define SFIO_CN_INV_DONE    12   // completed (applied) invalidations / context commits
`define SFIO_CN_INV_TMO     13   // drain timeouts (not applied)
`define SFIO_CN_FAULTS      14   // requests answered with a fault
`define SFIO_CN_REQ_STALL   15   // cycles req_valid && !req_ready  (DMA waiting for the translator)
`define SFIO_CN_RSP_STALL   16   // cycles rsp_valid && !rsp_ready  (translator waiting for the DMA)
`define SFIO_CN_FILLS       17
`define SFIO_CN_EVICTS      18   // a fill replaced a valid entry
`define SFIO_CN_TORN        19   // PTE re-reads after a torn-read detection
`define SFIO_CN_FAB_TMO     20   // fabric timeouts
`define SFIO_CN_STRAY       21
`define SFIO_CN_CFG_REJ     22   // rejected configuration accesses
`define SFIO_CN_CTX_COMMIT  23
`define SFIO_CN_INV_BLOCK   24   // cycles the request port was held off by a pending invalidation
`define SFIO_CN_RSP_FAULT0  25   // + cause: faults per cause (16 entries)
`define SFIO_CN_G           25
`define SFIO_NCNT           41

`endif
