#!/usr/bin/env python3
"""
regress.py -- build, run and judge the P108 simulation regression.

    scripts/regress.py [--configs base dw64 ...] [--seeds 3] [--jobs N] [--only SUBSTR] [--report reports/regression.md]

For every configuration: build the Verilator bench (-G parameter overrides), generate the scenarios for that parameterisation, run every
scenario under several seeds (seed = memory latency / ready jitter / junk-input randomness), and judge every trace with the independent
checker (tests/iommu/check_trace.py + ref_model.py).  Aggregates the feature coverage the checker observed, so that "pass" cannot hide
"never exercised".  Exit status 0 = every run passed (negative controls are run separately and are EXPECTED to fail: scripts/mutate.py).
"""
import argparse, json, os, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tests", "iommu"))
import ref_model as RM
import check_trace as CT
import gen_scenarios as GS

# name -> (verilator -G overrides, ref_model parameters, meta overrides)
CONFIGS = {
    "base":  ({}, {}),
    "dw64":  ({"DW": 64}, {"DW": 64}),
    "wide":  ({"PA_W": 44}, {"PA_W": 44}),
    "tmo":   ({"WALK_TMO": 24}, {"WALK_TMO": 24}),
    "nodbl": ({"PTE_DOUBLE_READ": 0}, {"PTE_DOUBLE_READ": 0}),
    "nodbl_wide": ({"PTE_DOUBLE_READ": 0, "PA_W": 44}, {"PTE_DOUBLE_READ": 0, "PA_W": 44}),    # NEGATIVE CONTROL: expected to FAIL d_race_bbm (a mixed PTE is returned)
    "tlb8":  ({"TLB_ENTRIES": 8}, {"TLB_ENTRIES": 8}),
    "tlb16": ({"TLB_ENTRIES": 16}, {"TLB_ENTRIES": 16}),
    "ctx1":  ({"NUM_CTX": 1, "DEV_W": 1}, {"NUM_CTX": 1, "DEV_W": 1}),
    "ctx7":  ({"NUM_CTX": 7, "DEV_W": 3}, {"NUM_CTX": 7, "DEV_W": 3}),
    "small": ({"MAX_BYTES": 256}, {"MAX_BYTES": 256}),
    "retry0": ({"RETRY_MAX": 0}, {"RETRY_MAX": 0}),
    "sp":    ({"SUPERPAGE_EN": 1}, {"SUPERPAGE_EN": 1}),
    "fab24": ({"FAB_AW": 24, "PA_W": 32}, {"FAB_AW": 24, "PA_W": 32}),
}
DEFAULT_CONFIGS = ["base", "dw64", "wide", "tmo", "tlb8", "tlb16", "ctx1", "ctx7", "small", "retry0", "fab24"]


def build(name, G):
    exe = os.path.join(ROOT, "out", "tb_%s" % name, "tb_%s" % name)
    if os.path.exists(exe) and os.environ.get("P108_REBUILD") != "1":
        newest = max(os.path.getmtime(os.path.join(ROOT, "rtl", "iommu", f)) for f in os.listdir(os.path.join(ROOT, "rtl", "iommu")))
        newest = max(newest, os.path.getmtime(os.path.join(ROOT, "tests", "iommu", "tb_pagewalker.cpp")))
        if os.path.getmtime(exe) > newest:
            return exe
    args = [os.path.join(ROOT, "scripts", "build_tb.sh"), name] + ["-G%s=%s" % (k, v) for k, v in G.items()]
    r = subprocess.run(args, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("build failed for %s:\n%s" % (name, r.stdout + r.stderr))
    return exe


def scenarios_for(P, nrandom=0):
    GS.set_params(P)
    fns = list(GS.DIRECTED) + [lambda P: GS.d_race(P, "bbm"), lambda P: GS.d_race(P, "lo_hi"), lambda P: GS.d_race(P, "hi_lo"), GS.d_timeout]
    out = []
    for f in fns:
        out.append(f(P))
    for s in range(1, nrandom + 1):
        out.append(GS.random_scenario(1000 + s, P, 500))
    return out


def run_one(exe, scn_path, trace_path, seed, timeout=600):
    r = subprocess.run([exe, scn_path, trace_path, str(seed)], capture_output=True, text=True, timeout=timeout)
    return r.returncode, (r.stdout + r.stderr).strip()


def judge(trace_path, P, meta):
    ck = CT.run(trace_path, P, meta)
    return ck


def one_job(args):
    cfg, exe, sc_name, scn_path, seed, pkw, meta = args
    trace = scn_path[:-4] + ".s%d.trace" % seed
    t0 = time.time()
    try:
        rc, out = run_one(exe, scn_path, trace, seed)
    except subprocess.TimeoutExpired:
        return dict(cfg=cfg, scn=sc_name, seed=seed, ok=False, detail="TIMEOUT", cov={}, secs=time.time() - t0)
    if rc != 0:
        return dict(cfg=cfg, scn=sc_name, seed=seed, ok=False, detail="bench rc=%d %s" % (rc, out[-400:]), cov={}, secs=time.time() - t0)
    P = RM.Params(**pkw)
    ck = judge(trace, P, meta)
    ok = not ck.errors
    if ok and os.environ.get("P108_KEEP") != "1":
        os.remove(trace)
    return dict(cfg=cfg, scn=sc_name, seed=seed, ok=ok, detail="; ".join(ck.errors[:3]), cov=ck.cov, secs=time.time() - t0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", nargs="*", default=DEFAULT_CONFIGS)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--only", default=None)
    ap.add_argument("--report", default=os.path.join(ROOT, "reports", "regression.md"))
    ap.add_argument("--json", default=None)
    ap.add_argument("--random", type=int, default=0, help="number of random scenarios per configuration")
    a = ap.parse_args()
    results = []
    jobs = []
    for cfg in a.configs:
        G, pkw = CONFIGS[cfg]
        exe = build(cfg, G)
        P = RM.Params(**pkw)
        sdir = os.path.join(ROOT, "out", "scn_%s" % cfg)
        os.makedirs(sdir, exist_ok=True)
        for sc in scenarios_for(P, a.random):
            if a.only and a.only not in sc.name:
                continue
            path = GS.write(sc, sdir)
            meta = json.loads(open(path).readline()[len("#meta "):])
            for seed in range(1, a.seeds + 1):
                jobs.append((cfg, exe, sc.name, path, seed, pkw, meta))
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(one_job, jobs):
            results.append(r)
            if not r["ok"]:
                print("FAIL %-6s %-24s seed %d: %s" % (r["cfg"], r["scn"], r["seed"], r["detail"][:300]))
    npass = sum(1 for r in results if r["ok"])
    cov = {}
    for r in results:
        for k, v in r["cov"].items():
            cov[k] = cov.get(k, 0) + v
    print("%d / %d runs pass (%.0fs)" % (npass, len(results), time.time() - t0))
    os.makedirs(os.path.dirname(a.report), exist_ok=True)
    lines = ["# Simulation regression", "", "%d / %d runs pass.  Every trace judged by the independent reference model (tests/iommu/ref_model.py)." % (npass, len(results)), "",
             "| configuration | scenarios x seeds | pass |", "|---|---|---|"]
    for cfg in a.configs:
        rs = [r for r in results if r["cfg"] == cfg]
        lines.append("| %s | %d | %d |" % (cfg, len(rs), sum(1 for r in rs if r["ok"])))
    lines += ["", "## Feature coverage observed by the checker (all runs)", "", "| feature | count |", "|---|---|"]
    for k in sorted(cov):
        lines.append("| %s | %d |" % (k, cov[k]))
    fails = [r for r in results if not r["ok"]]
    if fails:
        lines += ["", "## Failures", ""]
        for r in fails:
            lines.append("* `%s / %s / seed %d`: %s" % (r["cfg"], r["scn"], r["seed"], r["detail"][:300]))
    open(a.report, "w").write("\n".join(lines) + "\n")
    if a.json:
        json.dump(dict(results=results, coverage=cov), open(a.json, "w"), indent=1)
    return 0 if npass == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
