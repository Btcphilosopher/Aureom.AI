#!/usr/bin/env python3
"""make_zip.py [--manifest-only] [--out PATH] -- build the delivery archive.  Writes MANIFEST.sha256 (SHA-256 of every shipped file) first.
Excludes generated work (out/, __pycache__, *.trace, built binaries).  Nothing is committed to git: the archive is the deliverable."""
import hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "silicaflux-pagewalker-p108"
SKIP_DIRS = {"out", "__pycache__", ".git"}
SKIP_EXT = (".trace", ".pyc", ".o", ".a")


def files():
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = sorted(d for d in dn if d not in SKIP_DIRS)
        for f in sorted(fn):
            if f.endswith(SKIP_EXT) or f == "MANIFEST.sha256":
                continue
            yield os.path.join(dp, f)


def main():
    out = None
    if "--out" in sys.argv:
        out = sys.argv[sys.argv.index("--out") + 1]
    man = []
    for p in files():
        rel = os.path.relpath(p, ROOT)
        man.append("%s  %s" % (hashlib.sha256(open(p, "rb").read()).hexdigest(), rel))
    open(os.path.join(ROOT, "MANIFEST.sha256"), "w").write("\n".join(man) + "\n")
    if "--manifest-only" in sys.argv:
        print("%d files in MANIFEST.sha256" % len(man))
        return 0
    out = out or os.path.join(os.path.dirname(ROOT), NAME + ".zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in list(files()) + [os.path.join(ROOT, "MANIFEST.sha256")]:
            z.write(p, os.path.join(NAME, os.path.relpath(p, ROOT)))
    print("%s: %d files, %d bytes" % (out, len(man) + 1, os.path.getsize(out)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
