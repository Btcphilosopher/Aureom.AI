#!/usr/bin/env python3
"""
mutation_union.py -- combine the simulation mutation campaign (reports/mutation.json) with the formal mutation checks
(reports/formal_mutants_modules.json, reports/formal_mutants_top.json) into reports/mutation_union.md.

A mutant is "caught" if EITHER the simulation suite OR a formal job produced a counterexample / failure.  A formal "PROOF BREAKS" (the proof of the
unmutated design no longer goes through, no counterexample) is listed separately and is NOT counted as caught.
"""
import json, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, "reports")


def load(name):
    p = os.path.join(R, name)
    return {r["id"]: r for r in json.load(open(p))} if os.path.exists(p) else {}


def main():
    sim = load("mutation.json")
    fm = {}
    for n in ("formal_mutants_modules.json", "formal_mutants_top.json"):
        fm.update(load(n))
    rows = []
    for mid, r in sim.items():
        f = fm.get(mid)
        s_ok = r["status"] == "KILLED"
        f_ok = bool(f) and f["status"] == "KILLED"
        rows.append((mid, r["cls"], r["desc"], s_ok, (f["status"] if f else "not run"), f_ok))
    n = len(rows)
    both = sum(1 for x in rows if x[3] and x[5])
    only_s = sum(1 for x in rows if x[3] and not x[5])
    only_f = sum(1 for x in rows if not x[3] and x[5])
    neither = [x for x in rows if not x[3] and not x[5]]
    L = ["# Mutation: simulation and formal combined", "",
         "%d planted defects.  Simulation kills %d; formal kills %d (counterexample from reset); **either: %d**.  Killed by both: %d; by simulation only: %d; by formal only: %d; **by neither: %d**." %
         (n, sum(1 for x in rows if x[3]), sum(1 for x in rows if x[5]), both + only_s + only_f, both, only_s, only_f, len(neither)), "",
         "Formal checks only the module's own harness (the top level by a bounded BMC under a short budget), so many mutants are simulation-only by construction.", ""]
    L += ["## By neither", "", "| mutant | class | what was planted | formal verdict |", "|---|---|---|---|"]
    for x in sorted(neither):
        L.append("| `%s` | %s | %s | %s |" % (x[0], x[1], x[2], x[4]))
    L += ["", "## Simulation survivors and what formal said", "", "| mutant | class | simulation | formal |", "|---|---|---|---|"]
    for x in sorted(rows):
        if not x[3]:
            L.append("| `%s` | %s | SURVIVED | %s |" % (x[0], x[1], x[4]))
    L += ["", "## Formal-only kills (simulation missed them)", ""]
    L += ["* `%s` (%s): %s" % (x[0], x[1], x[2]) for x in sorted(rows) if (not x[3] and x[5])] or ["(none)"]
    L += ["", "## Simulation-only kills by class", ""]
    cls = {}
    for x in rows:
        if x[3] and not x[5]:
            cls.setdefault(x[1], 0)
            cls[x[1]] += 1
    L += ["* %s: %d" % (k, v) for k, v in sorted(cls.items())]
    pbs = sorted(x[0] for x in rows if x[4] == "PROOF BREAKS")
    L += ["", "## Formal 'PROOF BREAKS' (no counterexample; not counted above)", ""] + (["* `%s`" % m for m in pbs] or ["(none)"])
    open(os.path.join(R, "mutation_union.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L[:3]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
