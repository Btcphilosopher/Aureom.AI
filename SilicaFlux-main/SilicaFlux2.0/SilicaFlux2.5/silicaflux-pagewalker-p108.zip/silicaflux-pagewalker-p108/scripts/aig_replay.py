#!/usr/bin/env python3
"""
aig_replay.py DESIGN.aig DESIGN.cex [--show REGEX] -- replay an ABC counterexample on the AIGER model and print the named inputs and latches of every frame.
(`write_cex` file from `bmc3`, names from the .aim map written next to the .aig by Yosys.)  A maintainer tool for failed formal jobs.
"""
import re, sys

def load(path):
    d = open(path, "rb").read()
    nl = d.index(b"\n")
    h = d[:nl].split()
    assert h[0] == b"aig"
    M, I, L, O, A = [int(x) for x in h[1:6]]
    B = int(h[6]) if len(h) > 6 else 0
    C = int(h[7]) if len(h) > 7 else 0
    pos = nl + 1
    lat = []
    for _ in range(L):
        e = d.index(b"\n", pos); lat.append([int(x) for x in d[pos:e].split()]); pos = e + 1
    outs = []
    for _ in range(O + B + C):
        e = d.index(b"\n", pos); outs.append(int(d[pos:e])); pos = e + 1
    ands = []
    for k in range(A):
        lhs = 2 * (I + L + 1 + k)
        vals = []
        for _ in range(2):
            x = 0; sh = 0
            while True:
                b = d[pos]; pos += 1
                x |= (b & 0x7F) << sh; sh += 7
                if not b & 0x80: break
            vals.append(x)
        r0 = lhs - vals[0]; r1 = r0 - vals[1]
        ands.append((lhs, r0, r1))
    return dict(I=I, L=L, O=O, A=A, B=B, C=C, lat=lat, outs=outs, ands=ands)

def names(aim):
    ins, lats, inv = {}, {}, set()
    for ln in open(aim):
        p = ln.split()
        if p[0] == "input": ins[int(p[1])] = (p[3], int(p[2]))
        elif p[0] in ("latch", "invlatch"):
            lats[int(p[1])] = (p[3], int(p[2]))
            if p[0] == "invlatch": inv.add(int(p[1]))
    return ins, lats, inv

def main():
    aig, cex = sys.argv[1], sys.argv[2]
    rx = re.compile(sys.argv[sys.argv.index("--show") + 1]) if "--show" in sys.argv else re.compile(".")
    g = load(aig)
    ins, lats, inv = names(aig[:-4] + ".aim")
    bits = open(cex).read().strip().split()[0]
    I, L = g["I"], g["L"]
    nframes = (len(bits) - L) // I
    state = [int(bits[i]) for i in range(L)]
    # latch init in the AIG is 0 (-zinit); a cex starts from the initial state, i.e. all zeros
    badidx = g["O"]
    for f in range(nframes):
        inp = [int(bits[L + f * I + i]) for i in range(I)]
        val = {0: 0}
        for i in range(I): val[1 + i] = inp[i]
        for i in range(L): val[1 + I + i] = state[i]
        def lit(x):
            v = val[x >> 1]
            return v ^ (x & 1)
        for (lhs, r0, r1) in g["ands"]:
            val[lhs >> 1] = lit(r0) & lit(r1)
        outs = [lit(o) for o in g["outs"]]
        # decode named values
        groups = {}
        for i in range(I):
            if i in ins: groups.setdefault(("in", ins[i][0]), {})[ins[i][1]] = inp[i]
        for i in range(L):
            if i in lats:
                v = state[i] ^ (1 if i in inv else 0)
                groups.setdefault(("st", lats[i][0]), {})[lats[i][1]] = v
        print("=== frame %d   bad outputs asserted: %s" % (f, [k for k in range(g["O"], len(outs)) if outs[k]] or "-"))
        for (kind, name), bs in sorted(groups.items()):
            if not rx.search(name): continue
            n = max(bs) + 1
            v = sum(bs.get(b, 0) << b for b in range(n))
            print("   %s %-28s = %d (0x%x)" % (kind, name, v, v))
        state = [lit(g["lat"][i][0]) for i in range(L)]

main()
