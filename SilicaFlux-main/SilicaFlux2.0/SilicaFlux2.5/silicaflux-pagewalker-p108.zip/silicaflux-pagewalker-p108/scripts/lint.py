#!/usr/bin/env python3
"""
lint.py -- Verilator -Wall (many parameterisations), Yosys elaboration + latch check, and NEGATIVE elaboration tests: every illegal parameter set must be
rejected by its intended `$error` check (a check that never fires is not a check).   Writes reports/lint.md.
"""
import os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = os.path.join(ROOT, "rtl", "iommu")
FILES = [l.strip() for l in open(os.path.join(RTL, "filelist.f")) if l.strip()]
TOP = "sf_iommu_pagewalker"

GOOD = [
    {}, {"DW": 64}, {"PA_W": 44}, {"PA_W": 56, "DW": 64}, {"TLB_ENTRIES": 2}, {"TLB_ENTRIES": 8}, {"TLB_ENTRIES": 16}, {"TLB_ENTRIES": 64},
    {"NUM_CTX": 1, "DEV_W": 1}, {"NUM_CTX": 7, "DEV_W": 3}, {"NUM_CTX": 255, "DEV_W": 8}, {"FAB_AW": 24}, {"FAB_AW": 13, "PA_W": 13},
    {"SUPERPAGE_EN": 1}, {"PTE_DOUBLE_READ": 0}, {"WAIT_DMA_QUIET": 0}, {"ID_W": 16}, {"ID_W": 1}, {"LEN_W": 16}, {"MAX_BYTES": 1}, {"MAX_BYTES": 256},
    {"FQ_DEPTH": 1}, {"FQ_DEPTH": 3}, {"FQ_DEPTH": 64}, {"WALK_TMO": 4}, {"RETRY_MAX": 0}, {"RETRY_MAX": 15}, {"DRAIN_TMO_DEFAULT": 0},
    {"DW": 64, "SUPERPAGE_EN": 1, "TLB_ENTRIES": 16, "PA_W": 48},
]
BAD = [  # (override, the check that must reject it)
    ({"TLB_ENTRIES": 1}, "g_chk_tlb"), ({"TLB_ENTRIES": 65}, "g_chk_tlb"), ({"NUM_CTX": 0}, "g_chk_ctx"), ({"NUM_CTX": 256}, "g_chk_ctx"),
    ({"DEV_W": 0}, "g_chk_devw"), ({"DEV_W": 9}, "g_chk_devw"), ({"NUM_CTX": 8, "DEV_W": 2}, "g_chk_devn"), ({"ID_W": 0}, "g_chk_idw"), ({"ID_W": 17}, "g_chk_idw"),
    ({"MAX_BYTES": 0}, "g_chk_maxb"), ({"MAX_BYTES": 4097}, "g_chk_maxb"), ({"LEN_W": 12}, "g_chk_lenw"), ({"LEN_W": 17}, "g_chk_lenw"),
    ({"PA_W": 12}, "g_chk_paw"), ({"PA_W": 57}, "g_chk_paw"), ({"FAB_AW": 12}, "g_chk_fab"), ({"FAB_AW": 33, "PA_W": 40}, "g_chk_fab"), ({"FAB_AW": 32, "PA_W": 24}, "g_chk_fab"),
    ({"DW": 16}, "g_chk_dw"), ({"DW": 128}, "g_chk_dw"), ({"WALK_TMO": 3}, "g_chk_tmo"), ({"RETRY_MAX": 16}, "g_chk_retry"), ({"FQ_DEPTH": 0}, "g_chk_fq"), ({"FQ_DEPTH": 65}, "g_chk_fq"),
]


def verilator(g):
    cmd = ["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-Wno-UNUSEDPARAM", "--top-module", TOP, "-I" + RTL] + ["-G%s=%s" % kv for kv in g.items()] + [os.path.join(RTL, f) for f in FILES]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def main():
    lines = ["# Lint, elaboration and parameter-check report", "", "Verilator 5.020 `--lint-only -Wall` (the only waivers are three local `UNUSEDSIGNAL` pragmas in the RTL for deliberately unused bits) "
             "and Yosys 0.33 elaboration.", "", "## Verilator -Wall, legal parameter sets", "", "| parameters | result |", "|---|---|"]
    bad = 0
    for g in GOOD:
        rc, out = verilator(g)
        ok = rc == 0 and "%Warning" not in out
        bad += 0 if ok else 1
        lines.append("| `%s` | %s |" % (g or "defaults", "clean" if ok else "**FAIL**: " + out.strip().splitlines()[0][:100]))
    lines += ["", "## Negative elaboration tests: every illegal parameter set must be rejected by its intended check", "", "| parameters | intended check | result |", "|---|---|---|"]
    for g, chk in BAD:
        rc, out = verilator(g)
        hit = rc != 0 and chk in out
        early = rc != 0 and not hit and "Internal Error" in out and ("width" in out or "SEL" in out)
        bad += 0 if (hit or early) else 1
        lines.append("| `%s` | `%s` | %s |" % (g, chk, "rejected by it" if hit else ("rejected, but by Verilator's zero-width error on a port declaration BEFORE the check is reached" if early else "**NOT REJECTED** (rc=%d)" % rc)))
    # ---- Yosys: elaboration, check, latches (default and two variants)
    lines += ["", "## Yosys elaboration, `check -assert`, latch count", "", "| parameters | result |", "|---|---|"]
    for g in ({}, {"DW": 64, "SUPERPAGE_EN": 1}, {"TLB_ENTRIES": 16, "PA_W": 44}):
        chp = " ".join("-chparam %s %d" % kv for kv in g.items())
        ys = "read_verilog -sv -I%s %s; hierarchy -check -top %s %s; proc; check -assert; select -count t:$dlatch" % (RTL, " ".join(os.path.join(RTL, f) for f in FILES), TOP, chp)
        r = subprocess.run(["yosys", "-p", ys], capture_output=True, text=True)
        out = r.stdout + r.stderr
        m = re.findall(r"(\d+) objects\.", out)
        latches = int(m[-1]) if m else -1
        ok = r.returncode == 0 and latches == 0 and "Found and reported 0 problems" in out
        bad += 0 if ok else 1
        lines.append("| `%s` | %s |" % (g or "defaults", "0 problems, 0 latches" if ok else "**FAIL** (rc=%d, latches=%d)" % (r.returncode, latches)))
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "lint.md"), "w").write("\n".join(lines) + "\n")
    print("lint: %d problem(s)" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
