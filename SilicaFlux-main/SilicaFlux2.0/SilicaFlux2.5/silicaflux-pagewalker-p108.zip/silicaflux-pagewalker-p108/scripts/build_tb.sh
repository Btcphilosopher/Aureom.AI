#!/usr/bin/env bash
# build_tb.sh NAME [verilator -G... parameter overrides]   ->  out/tb_NAME/tb_NAME
# Builds the Verilator system bench for one parameterisation.  -DSF_CHECKS is on so the in-RTL port-level assertions also run in simulation.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
name="$1"; shift
out="${P108_OUT:-$ROOT/out}/tb_$name"
rtl="${P108_RTL:-$ROOT/rtl/iommu}"
dw=32; idw=4; devw=4; lenw=13
for a in "$@"; do case "$a" in -GDW=*) dw="${a#-GDW=}";; -GID_W=*) idw="${a#-GID_W=}";; -GDEV_W=*) devw="${a#-GDEV_W=}";; -GLEN_W=*) lenw="${a#-GLEN_W=}";; esac; done
files=$(sed "s#^#$rtl/#" "$rtl/filelist.f" | tr '\n' ' ')
rm -rf "$out"; mkdir -p "$out"
verilator --cc --exe --build -O2 -Wno-fatal -DSF_CHECKS --prefix VTOP --top-module sf_iommu_pagewalker \
  -I"$rtl" -Mdir "$out" -CFLAGS "-DBENCH_DW=$dw -DBENCH_ID_W=$idw -DBENCH_DEV_W=$devw -DBENCH_LEN_W=$lenw -std=c++17 -O2" "$@" $files "$ROOT/tests/iommu/tb_pagewalker.cpp" -o "tb_$name" \
  > "$out/build.log" 2>&1 || { tail -40 "$out/build.log"; exit 1; }
echo "built $out/tb_$name"
