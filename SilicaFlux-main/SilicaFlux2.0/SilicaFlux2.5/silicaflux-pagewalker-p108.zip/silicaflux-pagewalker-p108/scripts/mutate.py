#!/usr/bin/env python3
"""
mutate.py -- simulation mutation campaign.   scripts/mutate.py [--jobs N] [--only SUBSTR] [--random N] [--report reports/mutation.md]

For every mutant of scripts/mutants.py: apply it to a private copy of rtl/iommu, build the bench, run the regression scenarios, and ask the
independent checker.  A mutant is KILLED when the bench monitors, the checker, or the hard cycle limit reports a failure.  Survivors are
re-tried on further configurations (64-bit fabric, 8-entry TLB) before being declared survived.  The UNMUTATED baseline must pass the very
same suite first (a harness that kills mutants because it fails on the baseline proves nothing -- P103 learned that the hard way).
"""
import argparse, json, os, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.join(ROOT, "tests", "iommu"))
import mutants as MU
import regress as RG
import ref_model as RM
import gen_scenarios as GS
import check_trace as CT

OUT = os.path.join(ROOT, "out", "mut")
STAGES = [("base", {}, {}), ("dw64", {"DW": 64}, {"DW": 64}), ("tlb8", {"TLB_ENTRIES": 8}, {"TLB_ENTRIES": 8}), ("tmo", {"WALK_TMO": 24}, {"WALK_TMO": 24})]


def apply(m, dst):
    mid, f, old, new = m[0], m[1], m[2], m[3]
    shutil.rmtree(dst, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, "rtl", "iommu"), dst)
    p = os.path.join(dst, f)
    s = open(p).read()
    if s.count(old) != 1:
        raise RuntimeError("mutant %s: anchor occurs %d times in %s" % (mid, s.count(old), f))
    open(p, "w").write(s.replace(old, new))


def build(tag, rtl_dir, G):
    env = dict(os.environ, P108_RTL=rtl_dir, P108_OUT=os.path.dirname(rtl_dir))
    name = "m_" + tag
    r = subprocess.run([os.path.join(ROOT, "scripts", "build_tb.sh"), name] + ["-G%s=%s" % (k, v) for k, v in G.items()], capture_output=True, text=True, env=env)
    if r.returncode != 0:
        raise RuntimeError("build failed: " + (r.stdout + r.stderr)[-500:])
    return os.path.join(os.path.dirname(rtl_dir), "tb_" + name, "tb_" + name)


def run_suite(exe, scen, pkw, seeds=(1,), stop_on_fail=True, tag=""):
    """-> (None | (scenario, detail))"""
    for (name, path, meta) in scen:
        for sd in seeds:
            trace = path[:-4] + ".%s.s%d.trace" % (tag or "x", sd)
            try:
                rc, out = RG.run_one(exe, path, trace, sd, timeout=300)
            except subprocess.TimeoutExpired:
                return (name, "TIMEOUT")
            if rc != 0:
                return (name, "bench: " + out.replace("\n", " ")[:160])
            ck = CT.run(trace, RM.Params(**pkw), meta)
            if os.path.exists(trace):
                os.remove(trace)
            if ck.errors:
                return (name, ck.errors[0][:200])
    return None


def scenarios(cfg, pkw, nrand):
    P = RM.Params(**pkw)
    sdir = os.path.join(ROOT, "out", "scn_%s" % cfg)
    os.makedirs(sdir, exist_ok=True)
    out = []
    for sc in RG.scenarios_for(P, nrand):
        path = GS.write(sc, sdir)
        out.append((sc.name, path, json.loads(open(path).readline()[len("#meta "):])))
    return out


def one(args):
    m, scen_by_stage, tag = args
    mid = m[0]
    rtl = os.path.join(OUT, mid, "rtl")
    try:
        apply(m, rtl)
    except Exception as e:
        return dict(id=mid, cls=m[4], desc=m[5], status="ERROR", detail=str(e))
    for (cfg, G, pkw) in STAGES:
        try:
            exe = build("%s_%s" % (mid, cfg), rtl, G) if cfg != "base" else build(mid, rtl, G)
        except Exception as e:
            return dict(id=mid, cls=m[4], desc=m[5], status="BUILD-ERROR", detail=str(e)[-200:])
        r = run_suite(exe, scen_by_stage[cfg], pkw, seeds=(1,), tag=mid)
        shutil.rmtree(os.path.dirname(exe), ignore_errors=True)
        if r:
            return dict(id=mid, cls=m[4], desc=m[5], status="KILLED", stage=cfg, by=r[0], detail=r[1])
    return dict(id=mid, cls=m[4], desc=m[5], status="SURVIVED", detail="")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--only", default=None)
    ap.add_argument("--ids", nargs="*", default=None, help="run exactly these mutant ids")
    ap.add_argument("--random", type=int, default=8)
    ap.add_argument("--report", default=os.path.join(ROOT, "reports", "mutation.md"))
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    scen_by_stage = {cfg: scenarios(cfg, pkw, a.random if cfg == "base" else max(2, a.random // 4)) for (cfg, G, pkw) in STAGES}
    # ---- baseline gate
    print("baseline gate ...")
    for (cfg, G, pkw) in STAGES:
        exe = RG.build(cfg, G)
        r = run_suite(exe, scen_by_stage[cfg], pkw, seeds=(1, 2), tag="base_" + cfg)
        if r:
            print("BASELINE FAILS on %s / %s: %s -- the campaign is meaningless until the baseline passes" % (cfg, r[0], r[1]))
            return 2
    print("baseline passes on every stage; running %d mutants" % len(MU.M))
    ms = [m for m in MU.M if (not a.only or a.only in m[0]) and (a.ids is None or m[0] in a.ids)]
    t0 = time.time()
    res = []
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(one, [(m, scen_by_stage, "") for m in ms]):
            res.append(r)
            print("%-9s %-38s %s" % (r["status"], r["id"], ("(%s: %s)" % (r.get("stage"), r.get("by"))) if r["status"] == "KILLED" else r["detail"][:100]))
            shutil.rmtree(os.path.join(OUT, r["id"]), ignore_errors=True)
    killed = [r for r in res if r["status"] == "KILLED"]
    surv = [r for r in res if r["status"] == "SURVIVED"]
    bad = [r for r in res if r["status"] not in ("KILLED", "SURVIVED")]
    print("%d / %d killed, %d survived, %d errors (%.0fs)" % (len(killed), len(res), len(surv), len(bad), time.time() - t0))
    lines = ["# Simulation mutation campaign", "", "Baseline (unmutated RTL) passes the same suite on every stage first.  **%d / %d planted defects killed**, %d survived, %d did not build/apply." %
             (len(killed), len(res), len(surv), len(bad)), "", "| mutant | class | result | caught by | what was planted |", "|---|---|---|---|---|"]
    for r in sorted(res, key=lambda r: (r["status"] != "SURVIVED", r["cls"], r["id"])):
        lines.append("| `%s` | %s | %s | %s | %s |" % (r["id"], r["cls"], r["status"], ("%s: %s" % (r.get("stage"), r.get("by"))) if r["status"] == "KILLED" else "-", r["desc"]))
    if surv:
        lines += ["", "## Survivors (see docs/05_VERIFICATION.md for the analysis of each)", ""] + ["* `%s` (%s): %s" % (r["id"], r["cls"], r["desc"]) for r in surv]
    open(a.report, "w").write("\n".join(lines) + "\n")
    json.dump(res, open(a.report.replace(".md", ".json"), "w"), indent=1)
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
