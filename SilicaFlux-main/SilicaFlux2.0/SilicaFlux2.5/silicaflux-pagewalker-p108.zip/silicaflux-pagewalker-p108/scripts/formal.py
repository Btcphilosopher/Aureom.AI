#!/usr/bin/env python3
"""
formal.py -- P108 formal driver: Yosys -> AIGER -> ABC (bmc3 + k-induction).     scripts/formal.py [--only SUBSTR ...] [--jobs N] [--mutants] [--list]

Job kinds
   prove  k-induction ("PROVED" = UNBOUNDED proof: base case from reset + induction step; every input free, every reachable state)
   bmc    bounded model check from reset ("BOUNDED" = no violation within DEPTH cycles; NOT an unbounded proof)
   vac    a reachability witness: the assertion MUST fail ("WITNESSED" = the situation is reachable, so the proofs are not vacuous)
   mut    the same harness on an RTL copy with one planted defect: it MUST fail ("KILLED")
Results: reports/formal.md, reports/formal.json.   Tools: Yosys 0.33, yosys-abc.  (z3 / yosys-smtbmc were tried first and abandoned: see docs/05 section 5.)
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = os.path.join(ROOT, "rtl", "iommu")
FV = os.path.join(ROOT, "formal", "iommu")
OUT = os.path.join(ROOT, "out", "formal")
sys.path.insert(0, os.path.join(ROOT, "scripts"))

GROUPS = {   # harness -> (top, rtl files, harness file)
    "tlb":  ("fv_tlb",  ["sf_iommu_tlb.sv"], "fv_tlb.sv"),
    "inv":  ("fv_inv",  ["sf_iommu_invalidation.sv"], "fv_inv.sv"),
    "walk": ("fv_walk", ["sf_iommu_walk_fsm.sv"], "fv_walk.sv"),
    "ctx":  ("fv_ctx",  ["sf_iommu_context.sv"], "fv_ctx.sv"),
    "perf": ("fv_perf", ["sf_iommu_perf.sv"], "fv_perf.sv"),
    "flt":  ("fv_flt",  ["sf_iommu_faults.sv"], "fv_flt.sv"),
    "top":  ("fv_top",  ["sf_iommu_tlb.sv", "sf_iommu_context.sv", "sf_iommu_invalidation.sv", "sf_iommu_faults.sv", "sf_iommu_perf.sv",
                         "sf_iommu_walk_fsm.sv", "sf_iommu_pagewalker.sv"], "fv_top.sv"),
}
J = []   # (name, kind, group, params, depth, claim)
def job(name, kind, group, params, depth, claim): J.append((name, kind, group, params, depth, claim))

# ---- TLB: unbounded proofs for the baseline (4 entries) and variants
job("tlb_n4",   "prove", "tlb", dict(N=4, CTX_W=1, VPN_W=20, PPN_W=3), 4, "T1 uniqueness, T2 no stale hit after a covering invalidation, T3 invalidation beats fill, T4 LRU ages are a permutation, T5 a hit returns the last fill, T6 every valid entry grants a right (no negative caching) -- N = 4 (the baseline), all inputs, all reachable states")
job("tlb_n3",   "prove", "tlb", dict(N=3, CTX_W=1, VPN_W=20, PPN_W=3), 4, "the same with 3 entries (a non-power-of-two: ages must stay < N)")
job("tlb_n2",   "prove", "tlb", dict(N=2, CTX_W=2, VPN_W=20, PPN_W=2), 4, "the same with 2 entries and 4 contexts")
job("tlb_n8",   "prove", "tlb", dict(N=8, CTX_W=1, VPN_W=20, PPN_W=2), 4, "the same with 8 entries (the capacity expansion)")
job("tlb_n16",  "prove", "tlb", dict(N=16, CTX_W=1, VPN_W=18, PPN_W=2), 3, "the same with 16 entries")
for v, w in [(1, "a hit on a given page"), (2, "an LRU eviction"), (3, "a fill and an invalidation in the same cycle"), (4, "a 1 GiB fill"), (5, "a 2 MiB hit"), (6, "a hit after an eviction")]:
    job("vac_tlb_%d" % v, "vac", "tlb", dict(N=4, CTX_W=1, VPN_W=20, PPN_W=3, VAC=v), 14, "witness: " + w)
# ---- invalidation FSM
job("inv_q1",   "prove", "inv", dict(DRAIN_TMO_DEFAULT=5, WAIT_DMA_QUIET=1), 6, "V1..V5: a commit only after a DRAIN cycle in which the ports pipe_idle and dma_quiet were high; a timeout never commits; DRAIN is bounded by DRAIN_TMO; exactly one completion per command")
job("inv_q0",   "prove", "inv", dict(DRAIN_TMO_DEFAULT=5, WAIT_DMA_QUIET=0), 6, "the same without the dma_quiet wait")
job("inv_t1",   "prove", "inv", dict(DRAIN_TMO_DEFAULT=1, WAIT_DMA_QUIET=1), 6, "the same with a drain timeout of one cycle")
job("inv_t0",   "prove", "inv", dict(DRAIN_TMO_DEFAULT=0, WAIT_DMA_QUIET=1), 6, "the same with the timeout disabled (wait forever)")
for v, w in [(1, "a command completes"), (2, "a drain times out"), (3, "a page invalidation commits"), (4, "a context CLEAR commits"), (5, "both outcomes reachable")]:
    job("vac_inv_%d" % v, "vac", "inv", dict(DRAIN_TMO_DEFAULT=3, WAIT_DMA_QUIET=1, VAC=v), 16, "witness: " + w)
# ---- walker
W0 = dict(PPN_W=4, FAB_AW=16, FAB_PPN_W=4)
job("walk_dw64",  "prove", "walk", dict(W0, DW=64, SUPERPAGE_EN=0, RETRY_MAX=0, PTE_DOUBLE_READ=0, WALK_TMO=4), 8, "W1a fault class / leaf decision and W1b latched PPN, size, permissions (R&A&U, W&A&D&U) or next table == independent spec for EVERY PTE and level; W5 read addresses; W2 counters in range; W3 + W6 never a read over an abandoned read (own flags / SFB2 R2, R6 on the ports); W7 bus error -> PHYS_READ, torn re-read never decoded; W4 a fault reports no permission -- 64-bit fabric")
job("walk_dw32",  "prove", "walk", dict(W0, DW=32, SUPERPAGE_EN=0, RETRY_MAX=1, PTE_DOUBLE_READ=1, WALK_TMO=4), 8, "the same, 32-bit fabric with the lo-hi-lo validated read")
job("walk_dw32n", "prove", "walk", dict(W0, DW=32, SUPERPAGE_EN=0, RETRY_MAX=0, PTE_DOUBLE_READ=0, WALK_TMO=4), 8, "the same, 32-bit fabric, no validating re-read")
job("walk_sp",    "prove", "walk", dict(W0, DW=64, SUPERPAGE_EN=1, RETRY_MAX=0, PTE_DOUBLE_READ=0, WALK_TMO=4), 8, "the same with superpages enabled (alignment rule)")
job("walk_b64",   "bmc",   "walk", dict(W0, DW=64, SUPERPAGE_EN=0, RETRY_MAX=0, PTE_DOUBLE_READ=0, WALK_TMO=4, BOUND=24, BMCCHK=1), 30, "B: a walk ends within 24 cycles under ANY fabric behaviour (3 levels x (WALK_TMO + 2) + 6) -- 64-bit fabric")
job("walk_b32n",  "bmc",   "walk", dict(W0, DW=32, SUPERPAGE_EN=0, RETRY_MAX=0, PTE_DOUBLE_READ=0, WALK_TMO=4, BOUND=42, BMCCHK=1), 48, "B: bounded, 32-bit fabric, two beats per PTE (3 x 2 x (4 + 2) + 6 = 42)")
job("walk_b32",   "bmc",   "walk", dict(W0, DW=32, SUPERPAGE_EN=0, RETRY_MAX=1, PTE_DOUBLE_READ=1, WALK_TMO=4, BOUND=114, BMCCHK=1), 120, "B: bounded with the retry budget (3 x 3 x 2 x (4 + 2) + 6 = 114): no undefined retry loop")
for v, w in [(1, "a leaf is found"), (2, "a fabric timeout"), (3, "a torn read is detected and retried"), (4, "a bus error"), (5, "the port is wedged by an abandoned read"),
             (6, "a level-0 leaf"), (7, "a superpage leaf"), (8, "a PHYS_READ fault after a long walk"), (9, "a new walk request while wedged")]:
    p = dict(W0, DW=32, SUPERPAGE_EN=1, RETRY_MAX=1, PTE_DOUBLE_READ=1, WALK_TMO=4, VAC=v)
    job("vac_walk_%d" % v, "vac", "walk", p, 40, "witness: " + w)
# ---- context
job("ctx_n3",   "prove", "ctx", dict(NUM_CTX=3, DEV_W=2, CTX_W=2, PPN_W=6, FAB_PPN_W=4), 6, "C1 a command only when every rule holds; C2 the table changes only at a commit; C3 an installed root is inside the fabric; C4 an invalid / out-of-range id is never valid; C5 a commit installs exactly the command's entry (SET: staged root and caps; CLEAR: invalid)")
job("ctx_n4",   "prove", "ctx", dict(NUM_CTX=4, DEV_W=3, CTX_W=2, PPN_W=5, FAB_PPN_W=5), 6, "the same with 4 contexts and 3-bit device ids")
job("ctx_n1",   "prove", "ctx", dict(NUM_CTX=1, DEV_W=2, CTX_W=1, PPN_W=4, FAB_PPN_W=4), 6, "the same with one context")
for v, w in [(1, "a command is issued"), (2, "a valid device id"), (3, "a context CLEAR commits"), (4, "a range error (CE_RANGE)")]:
    job("vac_ctx_%d" % v, "vac", "ctx", dict(NUM_CTX=3, DEV_W=2, CTX_W=2, PPN_W=6, FAB_PPN_W=4, VAC=v), 18, "witness: " + w)
# ---- perf / fault log
job("perf",     "prove", "perf", dict(), 3, "every counter is monotone non-decreasing between resets: it saturates and never wraps (41 counters x 32 bits)")
job("flt_d3",   "prove", "flt", dict(FQ_DEPTH=3), 6, "the ring and its count agree; POP on an empty log is a no-op; the drop counter saturates (depth 3: not a power of two)")
job("flt_d4",   "prove", "flt", dict(FQ_DEPTH=4), 6, "the same with depth 4")
job("flt_d1",   "prove", "flt", dict(FQ_DEPTH=1), 6, "the same with depth 1")
for v, w in [(1, "a record is dropped (log full)"), (2, "a record is popped"), (3, "a record is read after a drop")]:
    job("vac_flt_%d" % v, "vac", "flt", dict(FQ_DEPTH=2, VAC=v), 14, "witness: " + w)
# ---- the composed design (bounded)
job("top_dw64", "bmc", "top", dict(DW=64, TLB_ENTRIES=2, BOUND=40), 34, "F1 a fabric read only inside a walk; F2 an OK response implies every static check and the context's caps; F3 response structure; F4 a refusal carries no address; F5 one response per request; L bounded first response; M never writes -- free CSR traffic, free hostile fabric (BMC, bounded)")
job("top_dw32", "bmc", "top", dict(DW=32, TLB_ENTRIES=2, PTE_DOUBLE_READ=1, RETRY_MAX=0, BOUND=60), 38, "the same with a 32-bit fabric and the validated PTE read")
for v, w in [(1, "an OK translation"), (2, "a two-segment response"), (3, "an invalidation completes"), (4, "a NOT_PRESENT refusal"), (5, "a page-table read"), (6, "a PHYS_READ refusal")]:
    job("vac_top_%d" % v, "vac", "top", dict(DW=64, TLB_ENTRIES=2, BOUND=40, VAC=v), 36, "witness: " + w)

job("vac_top32_1", "vac", "top", dict(DW=32, TLB_ENTRIES=2, PTE_DOUBLE_READ=1, RETRY_MAX=0, BOUND=60, VAC=1), 40, "witness: an OK translation on a 32-bit fabric (9 page-table reads) -- so top_dw32 covers a completed walk")


TMO_OVERRIDE = {"tlb_n16": 1500, "top_dw32": 900, "vac_top32_1": 900}   # seconds per ABC call for the two heaviest jobs
BASE_DEPTH = {"tlb_n16": 6}      # the 16-entry TLB base case is heavy: reset + 5 cycles are checked before the inductive step
ANSI = re.compile(r"\x1b\[[0-9;]*m")


def flow(group, params, rtl_dir, outdir, name):
    """Yosys -> AIGER (bad-state outputs = assertions, constraints = assumptions)."""
    top, rfiles, hfile = GROUPS[group]
    chp = " ".join("-chparam %s %s" % (k, v) for k, v in params.items())
    files = " ".join([os.path.join(rtl_dir, f) for f in rfiles] + [os.path.join(FV, hfile)])
    aig = os.path.join(outdir, name + ".aig")
    ys = ("read_verilog -sv -formal -DFORMAL -DSF_CHECKS -I%s %s; hierarchy -check -top %s %s; prep -flatten -nordff -top %s; memory_map; "
          "async2sync; dffunmap; chformal -assume -early; opt_clean; setundef -anyseq; opt -fast; techmap; dffunmap; abc -g AND -fast; dffunmap; "
          "opt -fast; write_aiger -I -B -zinit -map %s.aim %s" % (rtl_dir, files, top, chp, top, os.path.join(outdir, name), aig))
    r = subprocess.run(["yosys", "-q", "-p", ys], capture_output=True, text=True)
    return r, aig


def abc(aig, cmd, tmo):
    p = subprocess.run(["yosys-abc", "-c", "read_aiger %s; fold; strash; orpos; %s" % (aig, cmd)], capture_output=True, text=True, timeout=tmo + 60)
    return ANSI.sub("", p.stdout + p.stderr)


def bmc(aig, depth, tmo):
    out = abc(aig, "bmc3 -F %d -T %d" % (depth, tmo), tmo)
    m = re.search(r"asserted in frame (\d+)", out)
    if m:
        return "FAILED", "violated in frame %s" % m.group(1), out
    if "No output asserted in %d frames" % depth in out or re.search(r"No output asserted in \d+ frames", out):
        fr = re.search(r"No output asserted in (\d+) frames", out)
        if fr and int(fr.group(1)) >= depth:
            return "PASSED", "no violation in %s frames" % fr.group(1), out
        return "UNKNOWN", "only %s of %d frames completed" % (fr.group(1) if fr else "?", depth), out
    return "UNKNOWN", out.strip().splitlines()[-1][:100] if out.strip() else "no output", out


def induct(aig, kmax, tmo):
    last = ""
    for k in [x for x in (1, 2, 3, 4, 6, 8, 12) if x <= kmax]:
        out = abc(aig, "ind -F %d -T %d" % (k, tmo), tmo)
        last = out
        if "Networks are equivalent" in out:
            return "PASSED", k, out
        if "NOT equivalent" in out or "are NOT" in out:
            return "FAILED", k, out
    return "UNKNOWN", kmax, last


def run_job(j, rtl_dir=RTL, outdir=OUT, mutant=None):
    name, kind, group, params, depth, claim = j
    os.makedirs(outdir, exist_ok=True)
    tmo = TMO_OVERRIDE.get(name, int(os.environ.get("FV_TIMEOUT", "900")))
    t0 = time.time()
    r, aig = flow(group, params, rtl_dir, outdir, name)
    base = dict(name=name, kind=kind, group=group, params=params, claim=claim, depth=depth)
    if r.returncode != 0:
        return dict(base, status="ERROR", detail=(r.stdout + r.stderr)[-300:], secs=time.time() - t0)
    try:
        if kind == "prove":
            # base case from reset (bounded, depth frames) AND the inductive step (k <= depth): together an UNBOUNDED proof
            st_b, det_b, _ = bmc(aig, BASE_DEPTH.get(name, max(depth + 6, 12)), tmo)
            if st_b == "FAILED":
                status, detail = "FAILED", "base case: " + det_b
            elif st_b != "PASSED":
                status, detail = "UNKNOWN", "base case: " + det_b
            else:
                st_i, k, out = induct(aig, depth, tmo)
                status = {"PASSED": "PROVED", "FAILED": "FAILED"}.get(st_i, "UNKNOWN")
                detail = "base %s; induction k=%s" % (det_b, k) if st_i == "PASSED" else "induction %s up to k=%s" % (st_i, k)
        else:
            st, det, out = bmc(aig, depth, tmo)
            if kind == "bmc":
                status = "BOUNDED" if st == "PASSED" else ("FAILED" if st == "FAILED" else "UNKNOWN")
            elif kind == "vac":
                status = "WITNESSED" if st == "FAILED" else ("NOT-REACHABLE" if st == "PASSED" else "UNKNOWN")
            else:
                status = "KILLED" if st == "FAILED" else ("SURVIVED" if st == "PASSED" else "UNKNOWN")
            detail = det
    except subprocess.TimeoutExpired:
        status, detail = "UNKNOWN", "timeout"
    return dict(base, status=status, detail=detail, secs=time.time() - t0)


# a mutated module is checked with every job listed (the walker with BOTH fabric widths: a 32-bit walk is too deep for the base case to reach a leaf, a 64-bit one is not)
MUT_JOB = {"sf_iommu_tlb.sv": ["tlb_n4"], "sf_iommu_invalidation.sv": ["inv_q1"], "sf_iommu_walk_fsm.sv": ["walk_dw64", "walk_dw32"], "sf_iommu_context.sv": ["ctx_n4", "ctx_n3"],
           "sf_iommu_perf.sv": ["perf"], "sf_iommu_faults.sv": ["flt_d3"], "sf_iommu_pagewalker.sv": ["top_dw64"]}


def run_mutants(ids, jobs, report):
    import mutants as MU
    byname = {j[0]: j for j in J}
    work = os.path.join(ROOT, "out", "fmut")
    os.makedirs(work, exist_ok=True)

    def one(m):
        mid, f, old, new = m[0], m[1], m[2], m[3]
        d = os.path.join(work, mid)
        shutil.rmtree(d, ignore_errors=True)
        shutil.copytree(RTL, os.path.join(d, "rtl"))
        p = os.path.join(d, "rtl", f)
        src = open(p).read()
        assert src.count(old) == 1, mid
        open(p, "w").write(src.replace(old, new))
        runs = []
        for jn in MUT_JOB[f]:
            j = byname[jn]
            r = run_job(j, rtl_dir=os.path.join(d, "rtl"), outdir=os.path.join(d, "o_" + jn))
            runs.append((jn, r))
            if r["status"] == "FAILED":                                   # a counterexample: no need to run the other jobs
                break
        shutil.rmtree(d, ignore_errors=True)
        # KILLED = a counterexample from reset (the harness found the defect); SURVIVED = every job still PROVES / finds nothing (the property set does not see it);
        # PROOF BREAKS = the unmutated design is PROVED but on the mutant the induction no longer goes through and BMC finds no counterexample within its depth
        # (a defect the proof notices but cannot exhibit -- weaker evidence than a counterexample, reported separately)
        bad = [x for x in runs if x[1]["status"] == "FAILED"]
        if bad:
            jn, r = bad[0]; st = "KILLED"
        elif all(x[1]["status"] in ("PROVED", "BOUNDED") for x in runs):
            jn, r = runs[-1]; st = "SURVIVED"
        else:
            jn, r = [x for x in runs if x[1]["status"] not in ("PROVED", "BOUNDED")][0]
            st = ("PROOF BREAKS" if byname[jn][1] == "prove" else "UNDECIDED") if r["status"] == "UNKNOWN" else r["status"]
        return dict(id=mid, cls=m[4], file=f, job=jn, status=st, detail=r["detail"], desc=m[5])
    ms = [m for m in MU.M if (not ids or m[0] in ids)]
    with ThreadPoolExecutor(max_workers=jobs) as ex:
        res = list(ex.map(one, ms))
    k = sum(1 for r in res if r["status"] == "KILLED")
    pb = sum(1 for r in res if r["status"] == "PROOF BREAKS")
    ud = sum(1 for r in res if r["status"] == "UNDECIDED")
    print("%d / %d mutants killed by FORMAL (counterexample); %d more break the proof without a counterexample; %d undecided within the BMC budget; the harness of the mutated module only" % (k, len(res), pb, ud))
    lines = ["# Formal mutation check", "", "Each planted defect of `scripts/mutants.py` is applied to the RTL and the formal job(s) of the mutated module are run (the unbounded proofs and module-level "
             "invariants; `top_dw64` for the top level, BOUNDED).  **KILLED** = a counterexample from reset (%d / %d).  **PROOF BREAKS** = the unmutated design is PROVED, but on the mutant "
             "the induction no longer goes through and BMC finds no counterexample within its depth (%d): the proof notices the change but exhibits nothing -- weaker than a kill.  "
             "**SURVIVED** = every job still proves / finds nothing: the property set does not see the defect (it is a simulation-only catch, or an equivalent mutant).  "
             "**UNDECIDED** = a BMC job ran out of its time budget before its full depth (no counterexample in the frames it did complete).  Simulation kills a different, overlapping subset: the union is in docs/05." % (k, len(res), pb), "",
             "| mutant | class | module job | result | what was planted |", "|---|---|---|---|---|"]
    for r in sorted(res, key=lambda r: (r["status"], r["file"], r["id"])):
        lines.append("| `%s` | %s | %s | %s | %s |" % (r["id"], r["cls"], r["job"], r["status"], r["desc"]))
    open(report, "w").write("\n".join(lines) + "\n")
    json.dump(res, open(report.replace(".md", ".json"), "w"), indent=1)
    return res


def write_report(res, report):
    bad = [r for r in res if (r["kind"] in ("prove", "bmc") and r["status"] not in ("PROVED", "BOUNDED")) or (r["kind"] == "vac" and r["status"] != "WITNESSED")]
    lines = ["# Formal verification", "", "Yosys 0.33 + ABC (`bmc3` base case, `ind` k-induction).  **PROVED** = k-induction (unbounded: all inputs, all reachable states).  **BOUNDED** = BMC from reset, no violation within the depth (NOT unbounded).  **WITNESSED** = a reachability witness (the assertion had to fail) so the proofs are not vacuous.", "",
             "| job | kind | result | depth | seconds | claim |", "|---|---|---|---|---|---|"]
    for r in res:
        lines.append("| `%s` | %s | **%s** | %d | %.0f | %s |" % (r["name"], r["kind"], r["status"], r["depth"], r["secs"], r["claim"]))
    if bad:
        lines += ["", "## Not as expected", ""] + ["* `%s`: %s %s" % (r["name"], r["status"], r["detail"]) for r in bad]
    os.makedirs(os.path.dirname(report), exist_ok=True)
    open(report, "w").write("\n".join(lines) + "\n")
    json.dump(res, open(report.replace(".md", ".json"), "w"), indent=1)
    return bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*", default=None)
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--mutants", nargs="*", default=None, help="run the formal mutation check (optionally only the named mutant ids)")
    ap.add_argument("--report", default=os.path.join(ROOT, "reports", "formal.md"))
    ap.add_argument("--merge", action="store_true", help="with --only: fold these results into the existing reports/formal.json instead of replacing it")
    ap.add_argument("--rewrite-report", action="store_true", help="re-render the markdown report from the existing json with the current claim strings")
    ap.add_argument("--scope", choices=["modules", "top", "all"], default=None,
                    help="with --mutants: 'modules' = every mutant of a leaf module (fast), 'top' = the mutants of sf_iommu_pagewalker (BMC, slow: use a small FV_TIMEOUT), 'all'")
    a = ap.parse_args()
    if a.mutants is not None or a.scope:
        import mutants as MU
        ids = list(a.mutants or [])
        if a.scope in ("modules", "top") and not ids:
            ids = [m[0] for m in MU.M if (m[1] == "sf_iommu_pagewalker.sv") == (a.scope == "top")]
        rep = a.report
        if rep.endswith("formal.md"):
            rep = os.path.join(ROOT, "reports", {"modules": "formal_mutants_modules.md", "top": "formal_mutants_top.md"}.get(a.scope, "formal_mutants.md"))
        run_mutants(ids, a.jobs, rep)
        return 0
    js = [j for j in J if (not a.only or any(o in j[0] for o in a.only))]
    if a.list:
        for j in js: print(j[0], j[1], j[2], j[4])
        return 0
    if a.rewrite_report:                                   # re-render reports/formal.md from reports/formal.json with the current claim strings (no job is run)
        res = json.load(open(a.report.replace(".md", ".json")))
        claims = {j[0]: j[5] for j in J}
        for r in res:
            r["claim"] = claims.get(r["name"], r["claim"])
        write_report(res, a.report)
        return 0
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = []
        for r in ex.map(run_job, js):
            res.append(r)
            print("%-10s %-14s %5.0fs  %s" % (r["status"], r["name"], r["secs"], r["detail"][:120]), flush=True)
    bad = [r for r in res if (r["kind"] in ("prove", "bmc") and r["status"] not in ("PROVED", "BOUNDED")) or (r["kind"] == "vac" and r["status"] != "WITNESSED")]
    print("%d jobs, %d not as expected (%.0fs)" % (len(res), len(bad), time.time() - t0))
    if a.merge:
        prev = {r["name"]: r for r in json.load(open(a.report.replace(".md", ".json")))}
        prev.update({r["name"]: r for r in res})
        res = [prev[j[0]] for j in J if j[0] in prev]
    bad = write_report(res, a.report)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
