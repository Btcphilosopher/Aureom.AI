"""
Catalogue of planted RTL defects (mutants) for the simulation mutation campaign (scripts/mutate.py).

Each entry: (id, file, old, new, class, description).  `old` must occur EXACTLY once in `file` (checked at load: a mutant that does not apply
is an error, never a silent no-op).  Every mutant is a realistic engineering mistake -- the kind a reviewer might miss -- not a random edit.
Classes: SAFETY = would let an access through that must be refused / return a wrong address; STALE = a stale translation survives an
invalidation or reset; ORDER = invalidation / blocking / drain ordering; LIVE = hang / unbounded loop / wrong recovery; CSR = control path;
OBS = performance / fault-log observability (cannot cause a wrong translation).
"""
M = []


def mut(mid, f, old, new, cls, desc):
    M.append((mid, f, old, new, cls, desc))


T, C, I, W, P, F, PF = ("sf_iommu_tlb.sv", "sf_iommu_context.sv", "sf_iommu_invalidation.sv", "sf_iommu_walk_fsm.sv", "sf_iommu_pagewalker.sv",
                        "sf_iommu_faults.sv", "sf_iommu_perf.sv")

# ------------------------------------------------------------------------------------------------ TLB
mut("tlb-ctx-tag-ignored", T, "match[i_lk] = e_valid[i_lk] && (e_ctx[i_lk*CTX_W +: CTX_W] == lk_ctx) &&", "match[i_lk] = e_valid[i_lk] &&", "SAFETY",
    "lookup ignores the context tag: a translation of one device context is served to another")
mut("tlb-inv-all-noop", T, "`SFIO_INV_ALL:  inv_hit[i_iv] = e_valid[i_iv];", "`SFIO_INV_ALL:  inv_hit[i_iv] = 1'b0;", "STALE", "ALL invalidation clears nothing")
mut("tlb-inv-ctx-noop", T, "`SFIO_INV_CTX:  inv_hit[i_iv] = e_valid[i_iv] && (e_ctx[i_iv*CTX_W +: CTX_W] == inv_ctx);",
    "`SFIO_INV_CTX:  inv_hit[i_iv] = 1'b0;", "STALE", "context invalidation clears nothing")
mut("tlb-inv-ctx-wrong-ctx", T, "`SFIO_INV_CTX:  inv_hit[i_iv] = e_valid[i_iv] && (e_ctx[i_iv*CTX_W +: CTX_W] == inv_ctx);",
    "`SFIO_INV_CTX:  inv_hit[i_iv] = e_valid[i_iv] && (e_ctx[i_iv*CTX_W +: CTX_W] != inv_ctx);", "STALE", "context invalidation clears every OTHER context")
mut("tlb-inv-page-ignores-ctx", T, "`SFIO_INV_PAGE: inv_hit[i_iv] = e_valid[i_iv] && (e_ctx[i_iv*CTX_W +: CTX_W] == inv_ctx) &&",
    "`SFIO_INV_PAGE: inv_hit[i_iv] = e_valid[i_iv] &&", "OBS", "page invalidation also drops the same page of other contexts (over-invalidation)")
mut("tlb-inv-page-never-matches", T, "(((e_vpn[i_iv*VPN_W +: VPN_W] ^ inv_vpn) & smask(e_ps[i_iv*2 +: 2])) == {VPN_W{1'b0}});",
    "(((e_vpn[i_iv*VPN_W +: VPN_W] ^ inv_vpn) & smask(e_ps[i_iv*2 +: 2])) != {VPN_W{1'b0}});", "STALE", "page invalidation matches every page EXCEPT the named one")
mut("tlb-inv-page-low-bit", T, "(((e_vpn[i_iv*VPN_W +: VPN_W] ^ inv_vpn) & smask(e_ps[i_iv*2 +: 2])) == {VPN_W{1'b0}});",
    "((((e_vpn[i_iv*VPN_W +: VPN_W] ^ inv_vpn) >> 1) & smask(e_ps[i_iv*2 +: 2])) == {VPN_W{1'b0}});", "STALE", "page invalidation ignores vpn bit 0: the odd/even neighbour is hit instead")
mut("tlb-fill-beats-inv", T, "wire do_fill = fill_valid && !inv_valid && (fill_psize != 2'd3) && (fill_r || fill_w);",
    "wire do_fill = fill_valid && (fill_psize != 2'd3) && (fill_r || fill_w);", "STALE", "a fill in the cycle of an invalidation lands (invalidation does not win)")
mut("tlb-lru-no-touch-on-hit", T, "wire hit_touch = lk_touch && lk_hit && !do_fill && !do_inv;", "wire hit_touch = 1'b0;", "OBS", "a hit does not refresh the LRU age (FIFO replacement)")
mut("tlb-victim-lowest-index", T, "slot = have_conf ? slot_conf : (have_inv ? slot_inv : slot_lru);", "slot = have_conf ? slot_conf : (have_inv ? slot_inv : {IW{1'b0}});", "OBS",
    "replacement always evicts entry 0 instead of the least recently used")
mut("tlb-write-perm-from-read", T, "e_w[slot]                        <= fill_w;", "e_w[slot]                        <= fill_r;", "SAFETY",
    "the cached write permission is the READ permission: a write to a read-only page succeeds on a TLB hit")
mut("tlb-read-perm-from-write", T, "e_r[slot]                        <= fill_r;", "e_r[slot]                        <= fill_w;", "SAFETY", "the cached read permission is the write permission")
mut("tlb-no-fill-filter", T, "wire do_fill = fill_valid && !inv_valid && (fill_psize != 2'd3) && (fill_r || fill_w);",
    "wire do_fill = fill_valid && !inv_valid && (fill_psize != 2'd3);", "OBS", "a leaf that grants nothing is cached")
mut("tlb-ppn-truncated", T, "e_ppn[slot*PPN_W +: PPN_W]       <= fill_ppn;", "e_ppn[slot*PPN_W +: PPN_W]       <= {1'b0, fill_ppn[PPN_W-2:0]};", "SAFETY",
    "the top bit of the cached PPN is dropped: a TLB hit returns a wrong physical address")
mut("tlb-reset-keeps-valid", T, "      e_valid <= {N{1'b0}};\n      e_ctx   <= {(N*CTX_W){1'b0}};", "      e_ctx   <= {(N*CTX_W){1'b0}};", "STALE", "reset does not clear the valid bits")
mut("tlb-multi-ignored", T, "lk_hit   = (|match) && !lk_multi;", "lk_hit   = (|match);", "SAFETY", "a multi-match is not treated as a miss (OR of two PPNs possible)")

# ------------------------------------------------------------------------------------------------ context
mut("ctx-valid-ignored", C, "assign lk_ok        = in_rng && c_valid[lk_idx];", "assign lk_ok        = in_rng;", "SAFETY", "an unprogrammed / cleared context is accepted (root 0)")
mut("ctx-range-ignored", C, "assign lk_ok        = in_rng && c_valid[lk_idx];", "assign lk_ok        = c_valid[lk_idx];", "SAFETY",
    "the device id is not range-checked: ids above NUM_CTX alias a valid context")
mut("ctx-allow-w-ignored", P, "wire        c_dir    = q_write ? !ctx_aw : !ctx_ar;", "wire        c_dir    = q_write ? 1'b0 : !ctx_ar;", "SAFETY",
    "the context's write cap is not enforced")
mut("ctx-allow-r-ignored", P, "wire        c_dir    = q_write ? !ctx_aw : !ctx_ar;", "wire        c_dir    = q_write ? !ctx_aw : 1'b0;", "SAFETY", "the context's read cap is not enforced")
mut("ctx-root-range-unchecked", C, "wire        root_big   = (st_root44 >> FAB_PPN_W) != 44'd0;", "wire        root_big   = 1'b0;", "CSR",
    "a root PPN beyond the fabric is accepted at programming time")
mut("ctx-mode-unchecked", C, "wire        mode_ok    = (st_attr[3:2] == `SFIO_MODE_SV39);", "wire        mode_ok    = 1'b1;", "CSR", "BARE / reserved modes are accepted")
mut("ctx-attr-reserved-unchecked", C, "wire        attr_rsv   = (st_attr[31:4] != 28'd0);", "wire        attr_rsv   = 1'b0;", "CSR", "reserved attribute bits accepted")
mut("ctx-lock-ignored", C, "    if (locked)                         v_code = `SFIO_CE_LOCKED;\n    else if (cmd_busy)", "    if (1'b0)                           v_code = `SFIO_CE_LOCKED;\n    else if (cmd_busy)", "CSR",
    "CTRL.LOCK does not freeze context programming")
mut("ctx-clear-keeps-valid", C, "          c_valid[cu_commit_idx]                        <= 1'b0;", "          c_valid[cu_commit_idx]                        <= c_valid[cu_commit_idx];", "STALE",
    "CLEAR leaves the context valid")
mut("ctx-attr-swapped", C, "          c_ar[cu_commit_idx]                           <= st_attr[0];\n          c_aw[cu_commit_idx]                           <= st_attr[1];",
    "          c_ar[cu_commit_idx]                           <= st_attr[1];\n          c_aw[cu_commit_idx]                           <= st_attr[0];", "SAFETY", "read and write caps swapped at commit")
mut("ctx-index-unchecked", C, "    else if (!sel_ok)                   v_code = `SFIO_CE_INDEX;", "    else if (1'b0)                      v_code = `SFIO_CE_INDEX;", "CSR", "context index not range-checked on a command")
mut("ctx-busy-unchecked", C, "    else if (cmd_busy)                  v_code = `SFIO_CE_BUSY;", "    else if (1'b0)                      v_code = `SFIO_CE_BUSY;", "ORDER",
    "a context command is accepted while another command is in progress")

# ------------------------------------------------------------------------------------------------ invalidation
mut("inv-no-drain", I, "wire wait_ok  = pipe_idle && ((WAIT_DMA_QUIET == 0) || dma_quiet);", "wire wait_ok  = ((WAIT_DMA_QUIET == 0) || dma_quiet);", "ORDER",
    "the command does not wait for the translator to go idle")
mut("inv-ignores-quiet", I, "wire wait_ok  = pipe_idle && ((WAIT_DMA_QUIET == 0) || dma_quiet);", "wire wait_ok  = pipe_idle;", "ORDER", "dma_quiet is ignored")
mut("inv-timeout-applies", I, "            done_status <= `SFIO_IS_TMO;                   // NOT applied\n            st          <= S_DONE;",
    "            done_status <= `SFIO_IS_TMO;\n            st          <= S_COMMIT;", "STALE", "a drain timeout still applies the command")
mut("inv-no-blocking", I, "assign busy = (st != S_IDLE);", "assign busy = 1'b0;", "ORDER", "requests are not held off while a command is pending")
mut("inv-kind-ctx-as-all", I, "a_kind     <= k_in;", "a_kind     <= (k_in == `SFIO_INV_CTX) ? `SFIO_INV_ALL : k_in;", "OBS", "a context invalidation flushes everything")
mut("inv-kind-page-as-ctx", I, "a_kind     <= k_in;", "a_kind     <= (k_in == `SFIO_INV_PAGE) ? `SFIO_INV_CTX : k_in;", "OBS", "a page invalidation flushes the whole context")
mut("inv-page-uses-lo-only", I, "a_vpn      <= {s_va_hi[6:0], s_va_lo[31:12]};  // iova[38:12]", "a_vpn      <= {7'd0, s_va_lo[31:12]};", "STALE",
    "the page invalidation drops IOVA bits [38:32]: high pages are never invalidated")
mut("inv-ctx-from-wrong-reg", I, "a_ctx      <= s_ctx[CTX_W-1:0];", "a_ctx      <= {CTX_W{1'b0}};", "STALE", "invalidation always targets context 0")
mut("inv-commit-skipped-for-ctxcmd", I, "tlb_inv_valid   = (st == S_COMMIT);", "tlb_inv_valid   = (st == S_COMMIT) && !a_from_ctx;", "STALE",
    "a context programming command does not flush that context's TLB entries")
mut("inv-done-count-wrong", I, "          if (done_status == `SFIO_IS_OK) done_cnt <= done_cnt + 16'd1;", "          done_cnt <= done_cnt + 16'd1;", "CSR", "a timed-out command counts as completed")
mut("inv-range-check-removed", I, "    else if (k_in == `SFIO_INV_PAGE && !va_canon)          cmd_code = `SFIO_CE_RANGE;", "    else if (1'b0)          cmd_code = `SFIO_CE_RANGE;", "CSR", "a non-canonical invalidation address is accepted")
mut("inv-index-check-removed", I, "    else if (k_needctx && !ctx_ok)                         cmd_code = `SFIO_CE_INDEX;", "    else if (1'b0)                         cmd_code = `SFIO_CE_INDEX;", "CSR", "an out-of-range context index is accepted by INV_CMD")

# ------------------------------------------------------------------------------------------------ walker
mut("walk-x-only-as-pointer", W, "else if (p_r || p_x) begin                                                                      // 4: leaf",
    "else if (p_r) begin                                                                      // 4: leaf", "SAFETY", "an execute-only PTE is treated as a pointer")
mut("walk-reserved-bits-mask", W, "wire        p_rsv = (pte_w[63:54] != 10'd0);", "wire        p_rsv = (pte_w[63:61] != 3'd0);", "SAFETY", "only PTE bits 63:61 are checked as reserved")
mut("walk-w-without-r-allowed", W, "else if (p_w && !p_r)                           d_fault = `SFIO_F_INVALID_PTE;                  // 3", "else if (1'b0)                                 d_fault = `SFIO_F_INVALID_PTE;", "SAFETY",
    "the reserved W-without-R encoding is accepted")
mut("walk-pointer-adu-allowed", W, "      if (p_a || p_d || p_u)                        d_fault = `SFIO_F_INVALID_PTE;", "      if (1'b0)                                     d_fault = `SFIO_F_INVALID_PTE;", "SAFETY",
    "reserved A/D/U bits on a pointer PTE are accepted")
mut("walk-a-not-required", W, "res_r     <= p_r & p_a & p_u;", "res_r     <= p_r & p_u;", "SAFETY", "the accessed bit is not required for a read (Svade violated)")
mut("walk-d-not-required", W, "res_w     <= p_w & p_a & p_d & p_u;", "res_w     <= p_w & p_a & p_u;", "SAFETY", "the dirty bit is not required for a write")
mut("walk-u-not-required", W, "res_r     <= p_r & p_a & p_u;", "res_r     <= p_r & p_a;", "SAFETY", "the user bit is not required for a read")
mut("walk-u-not-required-w", W, "res_w     <= p_w & p_a & p_d & p_u;", "res_w     <= p_w & p_a & p_d;", "SAFETY", "the user bit is not required for a write")
mut("walk-level0-pointer-descends", W, "      else if (lvl_q == 2'd0)                       d_fault = `SFIO_F_MALFORMED;\n      else if (p_big_ptr)", "      else if (p_big_ptr)", "LIVE",
    "a pointer at the last level is followed (the level counter wraps)")
mut("walk-superpage-without-enable", W, "if (lvl_q != 2'd0 && SUPERPAGE_EN == 0)       d_fault = `SFIO_F_PAGE_SIZE;                    // 5", "if (1'b0)                                     d_fault = `SFIO_F_PAGE_SIZE;", "SAFETY",
    "a 2 MiB / 1 GiB leaf is accepted as if it were 4 KiB")
mut("walk-leaf-ppn-overflow-unchecked", W, "      else if (p_big_leaf)                          d_fault = `SFIO_F_ADDR_OVERFLOW;                // 6", "      else if (1'b0)                                d_fault = `SFIO_F_ADDR_OVERFLOW;", "SAFETY",
    "a leaf PPN beyond the physical address width is accepted (the address is truncated)")
mut("walk-pointer-ppn-unchecked", W, "      else if (p_big_ptr)                           d_fault = `SFIO_F_MALFORMED;\n      else                                          d_leaf  = 1'b0;",
    "      else                                          d_leaf  = 1'b0;", "SAFETY", "a pointer PPN beyond the fabric is followed (the address wraps)")
mut("walk-no-torn-compare", W, "if (m_rsp_rdata[31:0] != pte_lo) begin\n                    if (retry_q < RETRY_MAXV)", "if (1'b0) begin\n                    if (retry_q < RETRY_MAXV)", "SAFETY",
    "the validating re-read of the low word is not compared: a torn (mixed) PTE is accepted")
mut("walk-retry-unbounded", W, "if (retry_q < RETRY_MAXV) begin retry_q <= retry_q + 4'd1;", "if (1'b1) begin retry_q <= retry_q;", "LIVE", "the retry budget never runs out")
mut("walk-timeout-disabled", W, "wire timed_out    = ((wst == W_REQ) || (wst == W_RSP)) && !rsp_for_walk && (tmo_q >= TMO_LAST);",
    "wire timed_out    = 1'b0;", "LIVE", "the per-beat watchdog never fires: a silent fabric hangs the walker")
mut("walk-no-wedge-on-timeout", W, "            orph_req <= !m_req_ready;\n            orph_rsp <= m_req_ready;", "            orph_req <= 1'b0;\n            orph_rsp <= 1'b0;", "LIVE",
    "after a timeout the abandoned read is forgotten: a late response is mistaken for the next walk's / a new read is issued over it")
mut("walk-start-while-wedged", W, "            if (orph_req || orph_rsp) begin               // the port still owes a response of an abandoned read: refuse (nothing latched)",
    "            if (1'b0) begin", "LIVE", "a new walk starts while the port still owes a response")
mut("walk-withdraw-orphan-req", W, "assign m_req_valid = (wst == W_REQ) | orph_req;", "assign m_req_valid = (wst == W_REQ);", "LIVE",
    "an abandoned read is withdrawn from the fabric (SFB2 R2 violated)")
mut("walk-bus-error-ignored", W, "            if (m_rsp_error) begin\n              res_fault <= `SFIO_F_PHYS_READ; res_level <= lvl_q; wst <= W_DONE;\n            end else if (DW == 64) begin",
    "            if (1'b0) begin\n              res_fault <= `SFIO_F_PHYS_READ; res_level <= lvl_q; wst <= W_DONE;\n            end else if (DW == 64) begin", "SAFETY",
    "a bus error on a PTE read is ignored (the zero data is decoded)")
mut("walk-wrong-beat-offset", W, "wire [FAB_AW-1:0] boff     = (DW == 32 && b_q == 2'd1) ? {{(FAB_AW-3){1'b0}}, 3'd4} : {FAB_AW{1'b0}};",
    "wire [FAB_AW-1:0] boff     = (DW == 32 && b_q == 2'd1) ? {{(FAB_AW-4){1'b0}}, 4'd8} : {FAB_AW{1'b0}};", "SAFETY", "the high word is read from +8 instead of +4")
mut("walk-wrong-level-index", W, "wire [8:0]  vpn_idx = (lvl_q == 2'd2) ? vpn_q[26:18] : ((lvl_q == 2'd1) ? vpn_q[17:9] : vpn_q[8:0]);",
    "wire [8:0]  vpn_idx = (lvl_q == 2'd2) ? vpn_q[26:18] : ((lvl_q == 2'd1) ? vpn_q[8:0] : vpn_q[17:9]);", "SAFETY", "level 1 and level 0 index bits swapped")
mut("walk-leaf-r-or-w-fill", W, "res_ppn   <= p_ppn[PPN_W-1:0];", "res_ppn   <= p_ppn[PPN_W-1:0] ^ {{(PPN_W-1){1'b0}}, p_x};", "SAFETY", "an X bit flips the low bit of the returned PPN")
mut("walk-valid-bit-ignored", W, "    if (!p_v)                                       d_fault = `SFIO_F_NOT_PRESENT;                  // 1", "    if (1'b0)                                       d_fault = `SFIO_F_NOT_PRESENT;", "SAFETY",
    "the V bit is not checked")

# ------------------------------------------------------------------------------------------------ top level
mut("top-claim-ignored", P, "wire        c_claim  = q_cv && (q_cd != q_dev);", "wire        c_claim  = 1'b0;", "SAFETY", "a descriptor's claimed context is not compared with the trusted one")
mut("top-claim-obeyed", P, "q_dev <= req_dev; q_cd <= req_claim_dev;", "q_dev <= req_claim_valid ? req_claim_dev : req_dev; q_cd <= req_claim_dev;", "SAFETY",
    "the descriptor's claim SELECTS the context (an untrusted descriptor picks its page-table root)")
mut("top-overflow-ignored", P, "wire        c_ovf    = last65[64];", "wire        c_ovf    = 1'b0;", "SAFETY", "IOVA + length wrapping 2**64 is not detected")
mut("top-canon-end-ignored", P, "wire        c_canon_e = (last64[63:38] == {26{last64[38]}});", "wire        c_canon_e = 1'b1;", "SAFETY", "the LAST byte is not checked for canonicality")
mut("top-canon-start-ignored", P, "wire        c_canon_s = (q_iova[63:38] == {26{q_iova[38]}});", "wire        c_canon_s = 1'b1;", "SAFETY", "the first byte is not checked for canonicality")
mut("top-len-off-by-one", P, "{{(32-LEN_W){1'b0}}, q_bytes} > MAX_BYTES);", "{{(32-LEN_W){1'b0}}, q_bytes} > (MAX_BYTES + 1));", "SAFETY", "a request of MAX_BYTES + 1 bytes is accepted")
mut("top-zero-len-ok", P, "wire        c_len    = (q_bytes == {LEN_W{1'b0}}) ||", "wire        c_len    = 1'b0 ||", "SAFETY", "a zero-length request is accepted")
mut("top-cross-off-by-one", P, "wire        pg_cross = (off_sum > 17'd4096);", "wire        pg_cross = (off_sum > 17'd4097);", "SAFETY", "a request ending exactly one byte past the page is not split")
mut("top-second-page-perm-ignored-hit", P, "if (q_write ? tlb_w : tlb_r) begin seg_ok = 1'b1;", "if (seg_q || (q_write ? tlb_w : tlb_r)) begin seg_ok = 1'b1;", "SAFETY",
    "a TLB hit on the SECOND page of a request is granted without a permission check (first page released, second unchecked)")
mut("top-second-page-perm-ignored-walk", P, "else if (q_write ? walk_w_ok : walk_r_ok) begin seg_ok = 1'b1;", "else if (seg_q || (q_write ? walk_w_ok : walk_r_ok)) begin seg_ok = 1'b1;", "SAFETY",
    "a walked leaf of the SECOND page is granted without a permission check")
mut("top-seg1-offset", P, "wire [11:0]      cur_off  = seg_q ? 12'd0  : q_iova[11:0];", "wire [11:0]      cur_off  = q_iova[11:0];", "SAFETY", "the second segment keeps the first page's offset")
mut("top-len1-wrong", P, "wire [16:0] len1_w   = {{(17-LEN_W){1'b0}}, q_bytes} - len0_w;", "wire [16:0] len1_w   = {{(17-LEN_W){1'b0}}, q_bytes} - len0_w + 17'd1;", "SAFETY", "the second segment is one byte too long")
mut("top-rsp-last-wrong", P, "assign rsp_last  = r_ok ? (r_idx == r_two)           : 1'b1;", "assign rsp_last  = r_ok ? 1'b1 : 1'b1;", "SAFETY", "the first segment of a two-page request is marked last")
mut("top-pa-leak-on-refusal", P, "assign rsp_pa    = r_ok ? (r_idx ? r_pa1  : r_pa0)  : {PA_W{1'b0}};", "assign rsp_pa    = (r_idx ? r_pa1  : r_pa0);", "SAFETY", "an address leaves with a refusal")
mut("top-perm-inverted-on-hit", P, "if (q_write ? tlb_w : tlb_r) begin seg_ok = 1'b1;", "if (q_write ? tlb_r : tlb_w) begin seg_ok = 1'b1;", "SAFETY", "a TLB hit checks the opposite permission")
mut("top-perm-skipped-after-walk", P, "else if (q_write ? walk_w_ok : walk_r_ok) begin seg_ok = 1'b1;", "else if (1'b1) begin seg_ok = 1'b1;", "SAFETY", "the permission of a freshly walked leaf is not checked")
mut("top-ready-during-inv", P, "assign req_ready = (st == S_IDLE) && !inv_busy;", "assign req_ready = (st == S_IDLE);", "ORDER", "requests are accepted while a command is pending")
mut("top-idle-while-resp", P, "wire        pipe_idle = (st == S_IDLE);", "wire        pipe_idle = (st == S_IDLE) || (st == S_RESP);", "ORDER", "the translator counts as idle while a response is still held")
mut("top-fill-on-fault", P, "wire        fill_v   = walk_c && (walk_fault == `SFIO_F_NONE);", "wire        fill_v   = walk_c;", "OBS", "a faulting walk fills the TLB")
mut("top-unpriv-read", P, "wire         cfg_ok_rd = cfg_hs && !cfg_req_write && cfg_priv && a_ok;", "wire         cfg_ok_rd = cfg_hs && !cfg_req_write && a_ok;", "CSR",
    "an unprivileged CSR read returns data (a root pointer / a fault record leaks)")
mut("top-unpriv-write", P, "wire         cfg_ok_wr = cfg_hs && cfg_req_write && cfg_priv && a_ok && !is_ro;", "wire         cfg_ok_wr = cfg_hs && cfg_req_write && a_ok && !is_ro;", "SAFETY",
    "an unprivileged CSR write takes effect (a tenant programs its own context)")
mut("top-ro-write-ok", P, "wire         cfg_err   = cfg_hs && (!cfg_priv || !a_ok || (cfg_req_write && is_ro));", "wire         cfg_err   = cfg_hs && (!cfg_priv || !a_ok);", "CSR",
    "a write to a read-only register is not reported")
mut("top-status-w1c-broken", P, "sticky <= (sticky & ~((cfg_ok_wr && c_idx == `SFIO_R_STATUS) ? cfg_req_wdata[9:1] : 9'd0)) | sticky_set;", "sticky <= sticky | sticky_set;", "CSR",
    "STATUS flags cannot be cleared")
mut("top-lock-clearable", P, "if (cfg_req_wdata[31]) lock_q <= 1'b1;", "lock_q <= cfg_req_wdata[31];", "CSR", "CTRL.LOCK can be cleared by software")
mut("top-fault-level-wrong", P, "wire [1:0]  flt_level = chk_c ? 2'd3 : seg_level;", "wire [1:0]  flt_level = 2'd3;", "OBS", "the fault record never names the walk level")
mut("top-lat-sample-wrong", P, "    .lat_evt(lat_evt), .lat_cycles(lat_q + 16'd1),", "    .lat_evt(lat_evt), .lat_cycles(lat_q),", "OBS", "latency counter is one cycle short")

# ------------------------------------------------------------------------------------------------ fault log / perf
mut("flt-keeps-newest", F, "wire   can_push = push && (!full || pop);", "wire   can_push = push;", "OBS", "a full log overwrites instead of dropping the newest")
mut("flt-seq-not-advanced-on-drop", F, "if (push) seq_cnt <= seq_cnt + 32'd1;", "if (can_push) seq_cnt <= seq_cnt + 32'd1;", "OBS", "a dropped record does not consume a sequence number")
mut("flt-record-dev-id-swapped", F, "q_dev[wr_ptr*DEV_W +: DEV_W]    <= push_dev;\n        q_id[wr_ptr*ID_W +: ID_W]       <= push_id;", "q_dev[wr_ptr*DEV_W +: DEV_W]    <= push_id[DEV_W-1:0];\n        q_id[wr_ptr*ID_W +: ID_W]       <= {{(ID_W-DEV_W){1'b0}}, push_dev};", "OBS",
    "device and request id swapped in the record")
mut("flt-pop-when-empty", F, "wire   pop      = csr_wr && (csr_idx == `SFIO_R_FLOG_POP) && csr_wdata[0] && nonempty;", "wire   pop      = csr_wr && (csr_idx == `SFIO_R_FLOG_POP);", "OBS", "POP on an empty log underflows")
mut("perf-hit-miss-swapped", P, ".ev_hit(lookup_c && tlb_hit), .ev_miss(lookup_c && !tlb_hit),", ".ev_hit(lookup_c && !tlb_hit), .ev_miss(lookup_c && tlb_hit),", "OBS", "hit and miss counters swapped")
mut("perf-fault-cause-index", P, ".ev_fault(flt_push), .ev_fault_cause(flt_cause),", ".ev_fault(flt_push), .ev_fault_cause(4'd0),", "OBS", "per-cause fault counters always count cause 0")
mut("perf-refs-not-counted", W, "if (refs_q != 8'hFF) refs_q <= refs_q + 8'd1;", "refs_q <= refs_q;", "OBS", "walk reference counter does not count")
mut("perf-wrap-not-saturate", PF, "(32'hFFFF_FFFF - cnt[ib*32 +: 32]) < incv[ib*32 +: 32]) ? 32'hFFFF_FFFF", "(32'hFFFF_FFFF - cnt[ib*32 +: 32]) < incv[ib*32 +: 32]) ? 32'h0000_0000", "OBS", "counters wrap to zero instead of saturating")

