#!/usr/bin/env python3
"""
fv_bisect.py JOB [--file sf_iommu_x.sv] -- find WHICH assertion of a failing formal job is violated.
Re-runs the job once per `assert (...)` statement of the named RTL file's `ifdef FORMAL block, with every other assertion of that file removed.
Prints the assertions that fail on their own (with the frame of the first violation).  A maintainer tool: the AIGER output map does not name
properties, and a counterexample is useless without knowing which statement it violates.
"""
import argparse, os, re, shutil, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import formal as F

ap = argparse.ArgumentParser()
ap.add_argument("job")
ap.add_argument("--file", default=None)
a = ap.parse_args()
j = [x for x in F.J if x[0] == a.job][0]
files = F.GROUPS[j[2]][1]
target = a.file or files[-1]
tmp = tempfile.mkdtemp(prefix="fvb_")
shutil.copytree(F.RTL, os.path.join(tmp, "rtl"))
src = open(os.path.join(F.RTL, target)).read().split("\n")
idx = [i for i, l in enumerate(src) if re.search(r"\bassert \(", l) and "FORMAL" not in l]
start = next(i for i, l in enumerate(src) if l.strip().startswith("`ifdef FORMAL"))
idx = [i for i in idx if i > start]
print("%d assertions in %s after the FORMAL marker" % (len(idx), target))
for n, keep in enumerate(idx):
    lines = list(src)
    for i in idx:
        if i != keep:
            lines[i] = re.sub(r"\bassert \(", "if (1'b0) assert (", lines[i])
    open(os.path.join(tmp, "rtl", target), "w").write("\n".join(lines))
    r = F.run_job(j, rtl_dir=os.path.join(tmp, "rtl"), outdir=os.path.join(tmp, "o"))
    flag = "FAIL" if r["status"] in ("FAILED",) else r["status"]
    if flag == "FAIL" or flag in ("ERROR",) or os.environ.get("ALL"):
        print("  %-4s line %d: %s   [%s]" % (flag, keep + 1, src[keep].strip()[:140], r["detail"][:60]))
shutil.rmtree(tmp, ignore_errors=True)
