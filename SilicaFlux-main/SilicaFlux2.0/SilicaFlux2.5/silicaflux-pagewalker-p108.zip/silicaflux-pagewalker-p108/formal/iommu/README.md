# formal/iommu — proofs, bounded checks, witnesses

Flow: Yosys (`prep; memory_map; async2sync; dffunmap; … write_aiger -zinit`) → ABC (`bmc3` base case, `ind` k-induction, constraints `fold`ed). Runner: `scripts/formal.py` (`make formal`).

| harness | module | what is checked |
|---|---|---|
| `fv_tlb.sv` | `sf_iommu_tlb` | T1 uniqueness · T2 no stale hit after a covering invalidation · T3 invalidation beats fill · T4 LRU ages are a permutation · T5 a hit returns the last fill (free tag, shadowed) · T6 every valid entry grants a right (no negative caching) |
| `fv_inv.sv` | `sf_iommu_invalidation` | V1 commit only after a drain cycle in which the **ports** `pipe_idle` and `dma_quiet` were high · V2 a timeout never commits · V3 DRAIN bounded by `DRAIN_TMO` · V4 one completion per command · V5 stable active command |
| `fv_walk.sv` | `sf_iommu_walk_fsm` | W1a/W1b decode (fault class, leaf/pointer, and the latched PPN / permissions / next table) == independent spec for every PTE · W5 read addresses · W2 state legality · W3/W6 fabric discipline (own flags / on the ports) · W7 bus error and torn re-read · W4 a fault reports no permission · **B bounded termination under any fabric behaviour** (BMC) |
| `fv_ctx.sv` | `sf_iommu_context` | C1 a command only when every rule holds · C2 table changes only at a commit · C3 an installed root is inside the fabric · C4 an invalid id is never valid · C5 a commit installs exactly the command's entry |
| `fv_perf.sv`, `fv_flt.sv` | counters / fault log | counters saturate, never wrap · ring and count agree, POP on empty is a no-op |
| `fv_top.sv` | `sf_iommu_pagewalker` (small instance) | F1..F5 + bounded first response + never writes, with free CSR traffic and a hostile SFB2 fabric (**BMC, bounded**) |

The invariants live in the RTL (`` `ifdef FORMAL `` at the end of each module) so they can see internal state; the harnesses only add free inputs, the environment rules and reachability witnesses (`VAC` parameter: the
assertion must FAIL, proving the situation is reachable). Debug helpers: `scripts/fv_bisect.py JOB --file FILE` (which assertion fails), `scripts/aig_replay.py AIG CEX` (frame-by-frame counterexample).
