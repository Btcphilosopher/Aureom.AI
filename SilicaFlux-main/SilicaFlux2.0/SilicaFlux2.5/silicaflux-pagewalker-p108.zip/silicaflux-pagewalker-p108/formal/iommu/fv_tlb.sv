// =============================================================================
// P108 formal harness: sf_iommu_tlb.  Every input is FREE (any lookup, fill, invalidation, in any order, any cycle); the properties are the
// invariants inside the TLB (rtl/iommu/sf_iommu_tlb.sv, `ifdef FORMAL): T1 uniqueness, T2 no stale hit, T3 invalidation beats fill, T4 LRU
// permutation, T5 data integrity -- proved by k-induction, i.e. for ALL reachable states and ALL input sequences, not sampled.
//   VAC != 0: reachability witnesses (the assertion MUST fail) so that the proof cannot be vacuous.
// =============================================================================
`default_nettype none
module fv_tlb #(
  parameter N = 4, parameter CTX_W = 1, parameter VPN_W = 20, parameter PPN_W = 3, parameter VAC = 0
) (
  input wire clk,
  input wire rst_n_in,
  input wire [CTX_W-1:0] lk_ctx, input wire [VPN_W-1:0] lk_vpn, input wire lk_touch,
  input wire fill_valid, input wire [CTX_W-1:0] fill_ctx, input wire [VPN_W-1:0] fill_vpn, input wire [PPN_W-1:0] fill_ppn,
  input wire fill_r, input wire fill_w, input wire [1:0] fill_psize,
  input wire inv_valid, input wire [1:0] inv_kind, input wire [CTX_W-1:0] inv_ctx, input wire [VPN_W-1:0] inv_vpn
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = init ? 1'b0 : rst_n_in;                 // the first cycle is a reset; later resets are free
  wire lk_hit, lk_multi, lk_r, lk_w, ev_fill, ev_evict;
  wire [PPN_W-1:0] lk_ppn;
  wire [1:0] lk_psize;
  sf_iommu_tlb #(.N(N), .CTX_W(CTX_W), .VPN_W(VPN_W), .PPN_W(PPN_W)) dut (
    .clk(clk), .rst_n(rst_n), .lk_ctx(lk_ctx), .lk_vpn(lk_vpn), .lk_hit(lk_hit), .lk_multi(lk_multi), .lk_ppn(lk_ppn), .lk_r(lk_r), .lk_w(lk_w),
    .lk_psize(lk_psize), .lk_touch(lk_touch), .fill_valid(fill_valid), .fill_ctx(fill_ctx), .fill_vpn(fill_vpn), .fill_ppn(fill_ppn),
    .fill_r(fill_r), .fill_w(fill_w), .fill_psize(fill_psize), .inv_valid(inv_valid), .inv_kind(inv_kind), .inv_ctx(inv_ctx), .inv_vpn(inv_vpn),
    .ev_fill(ev_fill), .ev_evict(ev_evict));
  // ---- witnesses (reachability): each assertion below is FALSE exactly when the situation is reachable
  reg seen_hit = 1'b0, seen_evict = 1'b0, seen_invdrop = 1'b0, seen_ps2 = 1'b0;
  always @(posedge clk) begin
    if (!init) begin
      if (lk_hit) seen_hit <= 1'b1;
      if (ev_evict) seen_evict <= 1'b1;
      if (inv_valid && fill_valid) seen_invdrop <= 1'b1;
      if (ev_fill && fill_psize == 2'd2) seen_ps2 <= 1'b1;
    end
  end
  always @* begin
    if (VAC == 1) assert (!(lk_hit && lk_ctx == 0 && lk_vpn == 20'd5));
    if (VAC == 2) assert (!ev_evict);
    if (VAC == 3) assert (!(inv_valid && fill_valid && !init));
    if (VAC == 4) assert (!(ev_fill && fill_psize == 2'd2 && !init));
    if (VAC == 5) assert (!(lk_hit && lk_psize == 2'd1));
    if (VAC == 6) assert (!(seen_hit && seen_evict && lk_hit));
  end
endmodule
