// =============================================================================
// P108 formal harness: sf_iommu_context.  Free CSR traffic, free device ids, free commit strobes -- constrained only by the rules the
// composed design guarantees: a commit follows a command; the engine reports cmd_busy from the command until the commit.
// Properties C1..C4 are the invariants inside the module.
// =============================================================================
`default_nettype none
module fv_ctx #(
  parameter NUM_CTX = 3, parameter DEV_W = 2, parameter CTX_W = 2, parameter PPN_W = 6, parameter FAB_PPN_W = 4, parameter VAC = 0
) (
  input wire clk, input wire rst_n_in,
  input wire [DEV_W-1:0] lk_dev,
  input wire csr_wr, input wire [4:0] csr_idx, input wire [31:0] csr_wdata, input wire locked, input wire busy_in,
  input wire commit_in, input wire cclr_in, input wire [CTX_W-1:0] cidx_in
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = init ? 1'b0 : rst_n_in;
  wire lk_ok, lk_allow_r, lk_allow_w; wire [CTX_W-1:0] lk_idx; wire [PPN_W-1:0] lk_root;
  wire [31:0] csr_rdata; wire csr_hit, ce_evt, cu_req, cu_clear; wire [3:0] ce_code; wire [CTX_W-1:0] cu_idx;
  wire cmd_busy = busy_in;                                 // free: constrained only by the contract inside the module (a command keeps the engine busy until its commit / abort)
  sf_iommu_context #(.NUM_CTX(NUM_CTX), .DEV_W(DEV_W), .CTX_W(CTX_W), .PPN_W(PPN_W), .FAB_PPN_W(FAB_PPN_W)) dut (
    .clk(clk), .rst_n(rst_n), .lk_dev(lk_dev), .lk_ok(lk_ok), .lk_idx(lk_idx), .lk_root(lk_root), .lk_allow_r(lk_allow_r), .lk_allow_w(lk_allow_w),
    .csr_wr(csr_wr), .csr_idx(csr_idx), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata), .csr_hit(csr_hit), .locked(locked), .cmd_busy(cmd_busy),
    .ce_evt(ce_evt), .ce_code(ce_code), .cu_req(cu_req), .cu_clear(cu_clear), .cu_idx(cu_idx),
    .cu_commit(commit_in), .cu_commit_clear(cclr_in), .cu_commit_idx(cidx_in));
  always @* begin
    if (VAC == 1) assert (!(cu_req && !init));
    if (VAC == 2) assert (!(lk_ok && !init));
    if (VAC == 3) assert (!(commit_in && cclr_in && !init));
    if (VAC == 4) assert (!(ce_evt && ce_code == 4'd1 && !init));
  end
endmodule
