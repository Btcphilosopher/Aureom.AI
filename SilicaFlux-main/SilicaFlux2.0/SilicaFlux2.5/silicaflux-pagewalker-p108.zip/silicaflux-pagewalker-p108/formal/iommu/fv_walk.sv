// =============================================================================
// P108 formal harness: sf_iommu_walk_fsm.  The fabric is FREE: any latency, any data, any error, silence forever (hang), a late response.
// SFB2 is assumed only where it is a rule of the protocol (R2 / R5 / R6): a response only for an accepted read, never in the cycle of
// acceptance, one outstanding; a presented read is held by the walker (asserted, not assumed).
// Properties: W1..W4 inside the module (invariants), plus here
//   B   BOUNDED: a walk ends within BOUND cycles of its start, under ANY fabric behaviour (bmc); no undefined retry loop
//   S   never a read before a start; the result of a walk is produced exactly once (done pulse)
//   H   an accepted-but-abandoned read is never forgotten: while it is owed the walker issues nothing else
// =============================================================================
`default_nettype none
module fv_walk #(
  parameter PPN_W = 4, parameter FAB_AW = 16, parameter FAB_PPN_W = 4, parameter DW = 32, parameter SUPERPAGE_EN = 0,
  parameter PTE_DOUBLE_READ = 1, parameter RETRY_MAX = 1, parameter WALK_TMO = 4, parameter BOUND = 64, parameter BMCCHK = 0, parameter VAC = 0
) (
  input wire clk, input wire rst_n_in,
  input wire walk_start, input wire [FAB_PPN_W-1:0] walk_root, input wire [26:0] walk_vpn,
  input wire m_req_ready, input wire m_rsp_valid_in, input wire [DW-1:0] m_rsp_rdata, input wire m_rsp_error
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = init ? 1'b0 : rst_n_in;
  wire walk_busy, walk_done, walk_r_ok, walk_w_ok, m_req_valid, m_rsp_ready, fab_wedged, ev_torn, ev_fab_tmo, ev_fab_err, ev_stray;
  wire [3:0] walk_fault; wire [1:0] walk_level, walk_psize; wire [PPN_W-1:0] walk_ppn; wire [15:0] walk_cycles; wire [7:0] walk_refs;
  wire [FAB_AW-1:0] m_req_addr;
  // ---- SFB2 environment (only the protocol rules): outstanding tracking
  reg env_out = 1'b0;                                   // a read was accepted and not answered
  wire acc = m_req_valid && m_req_ready;
  wire m_rsp_valid = m_rsp_valid_in && env_out;         // a response exists only for an accepted read ...
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) env_out <= 1'b0;
    else begin
      if (acc) env_out <= 1'b1;
      if (m_rsp_valid) env_out <= 1'b0;
    end
  end
  always @* begin
    if (!init) begin
      assume (!(m_rsp_valid && acc));                    // R5: never in the acceptance cycle
      assume (!(m_req_ready && env_out));                // R6: the slave accepts only when it has nothing outstanding
    end
  end
  sf_iommu_walk_fsm #(.PPN_W(PPN_W), .FAB_AW(FAB_AW), .FAB_PPN_W(FAB_PPN_W), .DW(DW), .VPN_W(27), .SUPERPAGE_EN(SUPERPAGE_EN),
                      .PTE_DOUBLE_READ(PTE_DOUBLE_READ), .RETRY_MAX(RETRY_MAX), .WALK_TMO(WALK_TMO)) dut (
    .clk(clk), .rst_n(rst_n), .walk_start(walk_start), .walk_root(walk_root), .walk_vpn(walk_vpn), .walk_busy(walk_busy), .walk_done(walk_done),
    .walk_fault(walk_fault), .walk_level(walk_level), .walk_ppn(walk_ppn), .walk_psize(walk_psize), .walk_r_ok(walk_r_ok), .walk_w_ok(walk_w_ok),
    .walk_cycles(walk_cycles), .walk_refs(walk_refs), .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_addr(m_req_addr),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .fab_wedged(fab_wedged), .ev_torn(ev_torn), .ev_fab_tmo(ev_fab_tmo), .ev_fab_err(ev_fab_err), .ev_stray(ev_stray));
  // ---- B: bounded walk.  `run` counts cycles since a start was accepted (only meaningful from idle).
  reg [15:0] run = 16'd0;
  reg        started = 1'b0;
  reg        held = 1'b0; reg [FAB_AW-1:0] held_addr;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin run <= 16'd0; started <= 1'b0; held <= 1'b0; end
    else begin
      held <= m_req_valid && !m_req_ready; held_addr <= m_req_addr;
      if (!walk_busy && walk_start) begin started <= 1'b1; run <= 16'd0; end
      else if (walk_busy && !walk_done) run <= run + 16'd1;
      if (walk_done) started <= 1'b0;
    end
  end
  always @* begin
    if (!init) begin
      // history / ranking properties: bounded checks only (BMCCHK = 1); they are not inductive on their own
      if (BMCCHK != 0) begin
        assert (run <= BOUND);                                                 // B
        if (walk_busy) assert (started);
        if (held) begin assert (m_req_valid); assert (m_req_addr == held_addr); end   // SFB2 R2: a presented read is held, address unchanged
      end
      assert (!(walk_done && !walk_busy));                                     // S: done is reported by a busy walker
      assert (m_req_addr[1:0] == 2'b00);
      if (DW == 64) assert (m_req_addr[2:0] == 3'b000);
      assert (m_rsp_ready);                                                    // every response is consumed when presented
    end
  end
  // ---- witnesses
  reg seen_leaf = 1'b0, seen_tmo = 1'b0, seen_torn = 1'b0, seen_err = 1'b0, seen_wedge = 1'b0, seen_super = 1'b0, seen_l2 = 1'b0;
  always @(posedge clk) begin
    if (walk_done && walk_fault == 4'd0) seen_leaf <= 1'b1;
    if (ev_fab_tmo) seen_tmo <= 1'b1;
    if (ev_torn) seen_torn <= 1'b1;
    if (ev_fab_err) seen_err <= 1'b1;
    if (fab_wedged) seen_wedge <= 1'b1;
    if (walk_done && walk_psize != 2'd0) seen_super <= 1'b1;
    if (walk_done && walk_fault == 4'd0 && walk_level == 2'd0) seen_l2 <= 1'b1;
  end
  always @* begin
    if (VAC == 1) assert (!(walk_done && walk_fault == 4'd0 && !init));
    if (VAC == 2) assert (!(ev_fab_tmo && !init));
    if (VAC == 3) assert (!(ev_torn && !init));
    if (VAC == 4) assert (!(ev_fab_err && !init));
    if (VAC == 5) assert (!(fab_wedged && !init));
    if (VAC == 6) assert (!(walk_done && walk_fault == 4'd0 && walk_level == 2'd0 && !init));
    if (VAC == 7) assert (!(walk_done && walk_psize != 2'd0 && !init));
    if (VAC == 8) assert (!(walk_done && walk_fault == 4'd6 && walk_cycles > 16'd8 && !init));
    if (VAC == 9) assert (!(seen_wedge && walk_start && !walk_busy && !init));
  end
endmodule
