// =============================================================================
// P108 formal harness: sf_iommu_invalidation (drain-then-commit).  Free inputs: any CSR traffic (privileged or not is decided above this
// block), any pipe_idle / dma_quiet behaviour, context-programming requests.  The properties are the invariants V1..V5 inside the module.
// Environment assumptions (each is a property of the composed design, proved or checked there):
//   * a context-programming request (cu_req) is presented only while the engine is not busy (the context block refuses it otherwise)
//   * once the engine is busy and the translator has been seen idle, it stays idle (request port is blocked)
// =============================================================================
`default_nettype none
module fv_inv #(
  parameter NUM_CTX = 3, parameter CTX_W = 2, parameter VPN_W = 27, parameter DRAIN_TMO_DEFAULT = 5, parameter WAIT_DMA_QUIET = 1, parameter VAC = 0
) (
  input wire clk, input wire rst_n_in,
  input wire csr_wr, input wire [4:0] csr_idx, input wire [31:0] csr_wdata, input wire locked,
  input wire cu_req, input wire cu_clear, input wire [CTX_W-1:0] cu_idx,
  input wire pipe_idle, input wire dma_quiet
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = init ? 1'b0 : rst_n_in;
  wire [31:0] csr_rdata; wire csr_hit, ce_evt; wire [3:0] ce_code;
  wire cu_commit, cu_commit_clear; wire [CTX_W-1:0] cu_commit_idx;
  wire busy, tlb_inv_valid; wire [1:0] tlb_inv_kind; wire [CTX_W-1:0] tlb_inv_ctx; wire [VPN_W-1:0] tlb_inv_vpn;
  wire done_evt, done_ok_evt, done_tmo_evt; wire [1:0] done_status;
  sf_iommu_invalidation #(.NUM_CTX(NUM_CTX), .CTX_W(CTX_W), .VPN_W(VPN_W), .DRAIN_TMO_DEFAULT(DRAIN_TMO_DEFAULT), .WAIT_DMA_QUIET(WAIT_DMA_QUIET)) dut (
    .clk(clk), .rst_n(rst_n), .csr_wr(csr_wr), .csr_idx(csr_idx), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata), .csr_hit(csr_hit), .locked(locked),
    .ce_evt(ce_evt), .ce_code(ce_code), .cu_req(cu_req), .cu_clear(cu_clear), .cu_idx(cu_idx), .cu_commit(cu_commit),
    .cu_commit_clear(cu_commit_clear), .cu_commit_idx(cu_commit_idx), .pipe_idle(pipe_idle), .dma_quiet(dma_quiet), .busy(busy),
    .tlb_inv_valid(tlb_inv_valid), .tlb_inv_kind(tlb_inv_kind), .tlb_inv_ctx(tlb_inv_ctx), .tlb_inv_vpn(tlb_inv_vpn),
    .done_evt(done_evt), .done_ok_evt(done_ok_evt), .done_tmo_evt(done_tmo_evt), .done_status(done_status));
  reg busy_q = 1'b0, idle_q = 1'b0;
  always @(posedge clk) begin busy_q <= busy; idle_q <= pipe_idle; end
  always @* begin
    if (!init) assume (!(cu_req && busy));                           // the context block never presents a command while busy
    if (!init && busy_q && idle_q) assume (pipe_idle);                // blocking keeps an idle translator idle
  end
  // ---- witnesses
  reg seen_ok = 1'b0, seen_tmo = 1'b0;
  always @(posedge clk) begin if (done_ok_evt) seen_ok <= 1'b1; if (done_tmo_evt) seen_tmo <= 1'b1; end
  always @* begin
    if (VAC == 1) assert (!(done_ok_evt && !init));
    if (VAC == 2) assert (!(done_tmo_evt && !init));
    if (VAC == 3) assert (!(tlb_inv_valid && tlb_inv_kind == 2'd3 && !init));
    if (VAC == 4) assert (!(cu_commit && cu_commit_clear && !init));
    if (VAC == 5) assert (!(seen_ok && seen_tmo));
  end
endmodule
