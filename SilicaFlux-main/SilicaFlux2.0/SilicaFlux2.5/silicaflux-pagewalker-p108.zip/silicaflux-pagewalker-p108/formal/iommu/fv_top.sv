// =============================================================================
// P108 formal harness: the COMPOSED engine sf_iommu_pagewalker (small instance).  BOUNDED (BMC), not unbounded: the properties are the
// port-level checks (SF_CHECKS) and the structural invariants F1..F5 inside the top (`ifdef FORMAL), plus here:
//   * the request payload is held stable until accepted and the CSR request likewise (BY CONSTRUCTION: the DUT is driven from held copies)
//   * the fabric obeys the SFB2 rules R5 / R6 by construction (a response only for an accepted read, one outstanding); it may be slow, silent
//     forever, answer with errors, or answer with arbitrary data -- nothing else is assumed
//   * CSR traffic is FREE: any register, any value, privileged or not, at any time (so contexts are programmed by the proof itself)
//   L   an accepted request produces its first response within BOUND cycles under ANY fabric behaviour (no unbounded walk)
//   M   the engine never writes: m_req_write == 0 (also asserted in the RTL)
// =============================================================================
`default_nettype none
module fv_top #(
  parameter TLB_ENTRIES = 2, parameter NUM_CTX = 2, parameter DEV_W = 1, parameter ID_W = 1, parameter LEN_W = 13, parameter MAX_BYTES = 16,
  parameter PA_W = 16, parameter FAB_AW = 16, parameter DW = 64, parameter FQ_DEPTH = 2, parameter WALK_TMO = 4, parameter RETRY_MAX = 0,
  parameter PTE_DOUBLE_READ = 0, parameter SUPERPAGE_EN = 0, parameter DRAIN_TMO_DEFAULT = 4, parameter WAIT_DMA_QUIET = 1,
  parameter BOUND = 40, parameter VAC = 0
) (
  input wire clk, input wire rst_n_in,
  input wire req_valid_in, input wire [DEV_W-1:0] req_dev_in, input wire req_claim_valid_in, input wire [DEV_W-1:0] req_claim_dev_in,
  input wire req_write_in, input wire [63:0] req_iova_in, input wire [LEN_W-1:0] req_bytes_in, input wire [ID_W-1:0] req_id_in,
  input wire rsp_ready, input wire dma_quiet,
  input wire m_req_ready_in, input wire m_rsp_valid_in, input wire [DW-1:0] m_rsp_rdata, input wire m_rsp_error,
  input wire cfg_req_valid_in, input wire cfg_req_write_in, input wire [7:0] cfg_req_addr_in, input wire [31:0] cfg_req_wdata_in,
  input wire cfg_priv_in, input wire cfg_rsp_ready
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = init ? 1'b0 : rst_n_in;
  // ---- held request / CSR payload
  wire req_ready, cfg_req_ready;
  reg  rq_pend = 1'b0, cf_pend = 1'b0;
  reg [DEV_W-1:0] h_dev, h_cd; reg h_cv, h_wr; reg [63:0] h_iova; reg [LEN_W-1:0] h_bytes; reg [ID_W-1:0] h_id;
  reg h_cw, h_cp; reg [7:0] h_ca; reg [31:0] h_cd32;
  wire req_valid = rq_pend | req_valid_in;
  wire [DEV_W-1:0] req_dev = rq_pend ? h_dev : req_dev_in;           wire [DEV_W-1:0] req_claim_dev = rq_pend ? h_cd : req_claim_dev_in;
  wire req_claim_valid = rq_pend ? h_cv : req_claim_valid_in;        wire req_write = rq_pend ? h_wr : req_write_in;
  wire [63:0] req_iova = rq_pend ? h_iova : req_iova_in;             wire [LEN_W-1:0] req_bytes = rq_pend ? h_bytes : req_bytes_in;
  wire [ID_W-1:0] req_id = rq_pend ? h_id : req_id_in;
  wire cfg_req_valid = cf_pend | cfg_req_valid_in;
  wire cfg_req_write = cf_pend ? h_cw : cfg_req_write_in;            wire [7:0] cfg_req_addr = cf_pend ? h_ca : cfg_req_addr_in;
  wire [31:0] cfg_req_wdata = cf_pend ? h_cd32 : cfg_req_wdata_in;   wire cfg_priv = cf_pend ? h_cp : cfg_priv_in;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin rq_pend <= 1'b0; cf_pend <= 1'b0; end
    else begin
      rq_pend <= req_valid && !req_ready;
      cf_pend <= cfg_req_valid && !cfg_req_ready;
      h_dev <= req_dev; h_cd <= req_claim_dev; h_cv <= req_claim_valid; h_wr <= req_write; h_iova <= req_iova; h_bytes <= req_bytes; h_id <= req_id;
      h_cw <= cfg_req_write; h_cp <= cfg_priv; h_ca <= cfg_req_addr; h_cd32 <= cfg_req_wdata;
    end
  end
  // ---- SFB2 fabric environment (rules only)
  wire m_req_valid, m_rsp_ready, m_req_write; wire [FAB_AW-1:0] m_req_addr; wire [DW-1:0] m_req_wdata; wire [DW/8-1:0] m_req_wstrb;
  reg env_out = 1'b0;
  wire m_req_ready = m_req_ready_in && !env_out;                      // R6: one outstanding
  wire m_rsp_valid = m_rsp_valid_in && env_out;                        // R5: a response only for an accepted read, never in its acceptance cycle
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) env_out <= 1'b0;
    else begin
      if (m_req_valid && m_req_ready) env_out <= 1'b1;
      if (m_rsp_valid) env_out <= 1'b0;
    end
  end
  wire rsp_valid, rsp_ok, rsp_last, cfg_rsp_valid, cfg_rsp_error, inv_done_evt, irq; wire [ID_W-1:0] rsp_id; wire [3:0] rsp_fault;
  wire [PA_W-1:0] rsp_pa; wire [LEN_W-1:0] rsp_bytes; wire [31:0] cfg_rsp_rdata; wire [1:0] inv_done_status;
  sf_iommu_pagewalker #(.TLB_ENTRIES(TLB_ENTRIES), .NUM_CTX(NUM_CTX), .DEV_W(DEV_W), .ID_W(ID_W), .LEN_W(LEN_W), .MAX_BYTES(MAX_BYTES), .PA_W(PA_W),
    .FAB_AW(FAB_AW), .DW(DW), .FQ_DEPTH(FQ_DEPTH), .WALK_TMO(WALK_TMO), .RETRY_MAX(RETRY_MAX), .PTE_DOUBLE_READ(PTE_DOUBLE_READ),
    .SUPERPAGE_EN(SUPERPAGE_EN), .DRAIN_TMO_DEFAULT(DRAIN_TMO_DEFAULT), .WAIT_DMA_QUIET(WAIT_DMA_QUIET)) dut (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready), .req_dev(req_dev), .req_claim_valid(req_claim_valid),
    .req_claim_dev(req_claim_dev), .req_write(req_write), .req_iova(req_iova), .req_bytes(req_bytes), .req_id(req_id), .rsp_valid(rsp_valid),
    .rsp_ready(rsp_ready), .rsp_id(rsp_id), .rsp_ok(rsp_ok), .rsp_fault(rsp_fault), .rsp_pa(rsp_pa), .rsp_bytes(rsp_bytes), .rsp_last(rsp_last),
    .dma_quiet(dma_quiet), .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata),
    .m_rsp_error(m_rsp_error), .cfg_req_valid(cfg_req_valid), .cfg_req_ready(cfg_req_ready), .cfg_req_write(cfg_req_write),
    .cfg_req_addr(cfg_req_addr), .cfg_req_wdata(cfg_req_wdata), .cfg_priv(cfg_priv), .cfg_rsp_valid(cfg_rsp_valid), .cfg_rsp_ready(cfg_rsp_ready),
    .cfg_rsp_rdata(cfg_rsp_rdata), .cfg_rsp_error(cfg_rsp_error), .inv_done_evt(inv_done_evt), .inv_done_status(inv_done_status), .irq(irq));
  // ---- L: bounded first response
  reg [15:0] lat = 16'd0; reg waiting = 1'b0;
  wire req_hs = req_valid && req_ready;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin lat <= 16'd0; waiting <= 1'b0; end
    else begin
      if (req_hs) begin waiting <= 1'b1; lat <= 16'd1; end
      else if (waiting && !rsp_valid) lat <= lat + 16'd1;
      if (rsp_valid && waiting) waiting <= 1'b0;
    end
  end
  always @* begin
    if (!init) begin
      assert (!m_req_write);                                           // M
      assert (lat <= BOUND);                                           // L
      if (waiting) assert (!(rsp_valid && lat < 16'd2));
    end
  end
  // ---- witnesses
  reg seen_ok = 1'b0, seen_two = 1'b0, seen_inv = 1'b0, seen_refuse = 1'b0, seen_walk = 1'b0;
  always @(posedge clk) begin
    if (rsp_valid && rsp_ok) seen_ok <= 1'b1;
    if (rsp_valid && rsp_ok && !rsp_last) seen_two <= 1'b1;
    if (inv_done_evt) seen_inv <= 1'b1;
    if (rsp_valid && !rsp_ok) seen_refuse <= 1'b1;
    if (m_req_valid) seen_walk <= 1'b1;
  end
  always @* begin
    if (VAC == 1) assert (!(rsp_valid && rsp_ok && !init));
    if (VAC == 2) assert (!(rsp_valid && rsp_ok && !rsp_last && !init));
    if (VAC == 3) assert (!(inv_done_evt && !init));
    if (VAC == 4) assert (!(rsp_valid && !rsp_ok && rsp_fault == 4'd2 && !init));
    if (VAC == 5) assert (!(m_req_valid && !init));
    if (VAC == 6) assert (!(rsp_valid && !rsp_ok && rsp_fault == 4'd6 && !init));
    if (VAC == 7) assert (!(seen_ok && m_req_valid && !init));
  end
endmodule
