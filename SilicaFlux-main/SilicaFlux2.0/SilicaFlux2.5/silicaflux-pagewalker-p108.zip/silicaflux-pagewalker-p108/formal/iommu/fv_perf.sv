// P108 formal harness: sf_iommu_perf.  Every event input is FREE; the invariant inside the module says every counter is monotone
// non-decreasing between resets: it SATURATES and never wraps.  VAC: reachability witnesses.
`default_nettype none
module fv_perf (
  input wire clk, input wire rst_n_in,
  input wire ev_req, ev_seg, ev_hit, ev_miss, ev_walk, ev_walk_fault, ev_fill, ev_evict, ev_torn, ev_fab_tmo, ev_stray,
  input wire ev_cfg_rej, ev_ctx_commit, ev_inv_done, ev_inv_tmo, ev_fault, input wire [3:0] ev_fault_cause,
  input wire ev_req_stall, ev_rsp_stall, ev_inv_block, input wire walk_done_evt, input wire [15:0] walk_cycles, input wire [7:0] walk_refs,
  input wire lat_evt, input wire [15:0] lat_cycles, input wire csr_wr, input wire [4:0] csr_idx, input wire [31:0] csr_wdata
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = init ? 1'b0 : rst_n_in;
  wire [31:0] csr_rdata; wire csr_hit;
  sf_iommu_perf dut (.clk(clk), .rst_n(rst_n), .ev_req(ev_req), .ev_seg(ev_seg), .ev_hit(ev_hit), .ev_miss(ev_miss), .ev_walk(ev_walk),
    .ev_walk_fault(ev_walk_fault), .ev_fill(ev_fill), .ev_evict(ev_evict), .ev_torn(ev_torn), .ev_fab_tmo(ev_fab_tmo), .ev_stray(ev_stray),
    .ev_cfg_rej(ev_cfg_rej), .ev_ctx_commit(ev_ctx_commit), .ev_inv_done(ev_inv_done), .ev_inv_tmo(ev_inv_tmo), .ev_fault(ev_fault),
    .ev_fault_cause(ev_fault_cause), .ev_req_stall(ev_req_stall), .ev_rsp_stall(ev_rsp_stall), .ev_inv_block(ev_inv_block),
    .walk_done_evt(walk_done_evt), .walk_cycles(walk_cycles), .walk_refs(walk_refs), .lat_evt(lat_evt), .lat_cycles(lat_cycles),
    .csr_wr(csr_wr), .csr_idx(csr_idx), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata), .csr_hit(csr_hit));
endmodule
