// P108 formal harness: sf_iommu_faults.  Free pushes and CSR traffic.  Invariants inside the module: ring and count agree, POP on an empty
// log is a no-op, the drop counter saturates.  VAC: a record can be dropped / popped / wrapped.
`default_nettype none
module fv_flt #(parameter FQ_DEPTH = 3, parameter DEV_W = 2, parameter ID_W = 2, parameter LEN_W = 13, parameter VAC = 0) (
  input wire clk, input wire rst_n_in,
  input wire push, input wire [3:0] push_cause, input wire [1:0] push_level, input wire push_write, input wire [DEV_W-1:0] push_dev,
  input wire [ID_W-1:0] push_id, input wire [63:0] push_iova, input wire [LEN_W-1:0] push_bytes,
  input wire csr_wr, input wire [4:0] csr_idx, input wire [31:0] csr_wdata
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = init ? 1'b0 : rst_n_in;
  wire [31:0] csr_rdata; wire csr_hit, nonempty, drop_evt;
  sf_iommu_faults #(.FQ_DEPTH(FQ_DEPTH), .DEV_W(DEV_W), .ID_W(ID_W), .LEN_W(LEN_W)) dut (
    .clk(clk), .rst_n(rst_n), .push(push), .push_cause(push_cause), .push_level(push_level), .push_write(push_write), .push_dev(push_dev),
    .push_id(push_id), .push_iova(push_iova), .push_bytes(push_bytes), .csr_wr(csr_wr), .csr_idx(csr_idx), .csr_wdata(csr_wdata),
    .csr_rdata(csr_rdata), .csr_hit(csr_hit), .nonempty(nonempty), .drop_evt(drop_evt));
  reg seen_drop = 1'b0, seen_wrap = 1'b0;
  always @(posedge clk) begin if (drop_evt) seen_drop <= 1'b1; end
  always @* begin
    if (VAC == 1) assert (!(drop_evt && !init));
    if (VAC == 2) assert (!(nonempty && csr_wr && csr_idx == 5'd25 && csr_wdata[0] && !init));
    if (VAC == 3) assert (!(seen_drop && nonempty && !init));
  end
endmodule
