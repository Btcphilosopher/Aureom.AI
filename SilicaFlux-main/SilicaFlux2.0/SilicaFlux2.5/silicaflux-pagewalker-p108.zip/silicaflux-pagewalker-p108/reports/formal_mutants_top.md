# Formal mutation check

Each planted defect of `scripts/mutants.py` is applied to the RTL and the formal job(s) of the mutated module are run (the unbounded proofs and module-level invariants; `top_dw64` for the top level, BOUNDED).  **KILLED** = a counterexample from reset (7 / 30).  **PROOF BREAKS** = the unmutated design is PROVED, but on the mutant the induction no longer goes through and BMC finds no counterexample within its depth (23): the proof notices the change but exhibits nothing -- weaker than a kill.  **SURVIVED** = every job still proves / finds nothing: the property set does not see the defect (it is a simulation-only catch, or an equivalent mutant).  **UNKNOWN / timeout** = not decided within the budget.  Simulation kills a different, overlapping subset: the union is in docs/05.

| mutant | class | module job | result | what was planted |
|---|---|---|---|---|
| `ctx-allow-r-ignored` | SAFETY | top_dw64 | KILLED | the context's read cap is not enforced |
| `ctx-allow-w-ignored` | SAFETY | top_dw64 | KILLED | the context's write cap is not enforced |
| `top-cross-off-by-one` | SAFETY | top_dw64 | KILLED | a request ending exactly one byte past the page is not split |
| `top-idle-while-resp` | ORDER | top_dw64 | KILLED | the translator counts as idle while a response is still held |
| `top-pa-leak-on-refusal` | SAFETY | top_dw64 | KILLED | an address leaves with a refusal |
| `top-ready-during-inv` | ORDER | top_dw64 | KILLED | requests are accepted while a command is pending |
| `top-zero-len-ok` | SAFETY | top_dw64 | KILLED | a zero-length request is accepted |
| `perf-fault-cause-index` | OBS | top_dw64 | PROOF BREAKS | per-cause fault counters always count cause 0 |
| `perf-hit-miss-swapped` | OBS | top_dw64 | PROOF BREAKS | hit and miss counters swapped |
| `top-canon-end-ignored` | SAFETY | top_dw64 | PROOF BREAKS | the LAST byte is not checked for canonicality |
| `top-canon-start-ignored` | SAFETY | top_dw64 | PROOF BREAKS | the first byte is not checked for canonicality |
| `top-claim-ignored` | SAFETY | top_dw64 | PROOF BREAKS | a descriptor's claimed context is not compared with the trusted one |
| `top-claim-obeyed` | SAFETY | top_dw64 | PROOF BREAKS | the descriptor's claim SELECTS the context (an untrusted descriptor picks its page-table root) |
| `top-fault-level-wrong` | OBS | top_dw64 | PROOF BREAKS | the fault record never names the walk level |
| `top-fill-on-fault` | OBS | top_dw64 | PROOF BREAKS | a faulting walk fills the TLB |
| `top-lat-sample-wrong` | OBS | top_dw64 | PROOF BREAKS | latency counter is one cycle short |
| `top-len-off-by-one` | SAFETY | top_dw64 | PROOF BREAKS | a request of MAX_BYTES + 1 bytes is accepted |
| `top-len1-wrong` | SAFETY | top_dw64 | PROOF BREAKS | the second segment is one byte too long |
| `top-lock-clearable` | CSR | top_dw64 | PROOF BREAKS | CTRL.LOCK can be cleared by software |
| `top-overflow-ignored` | SAFETY | top_dw64 | PROOF BREAKS | IOVA + length wrapping 2**64 is not detected |
| `top-perm-inverted-on-hit` | SAFETY | top_dw64 | PROOF BREAKS | a TLB hit checks the opposite permission |
| `top-perm-skipped-after-walk` | SAFETY | top_dw64 | PROOF BREAKS | the permission of a freshly walked leaf is not checked |
| `top-ro-write-ok` | CSR | top_dw64 | PROOF BREAKS | a write to a read-only register is not reported |
| `top-rsp-last-wrong` | SAFETY | top_dw64 | PROOF BREAKS | the first segment of a two-page request is marked last |
| `top-second-page-perm-ignored-hit` | SAFETY | top_dw64 | PROOF BREAKS | a TLB hit on the SECOND page of a request is granted without a permission check (first page released, second unchecked) |
| `top-second-page-perm-ignored-walk` | SAFETY | top_dw64 | PROOF BREAKS | a walked leaf of the SECOND page is granted without a permission check |
| `top-seg1-offset` | SAFETY | top_dw64 | PROOF BREAKS | the second segment keeps the first page's offset |
| `top-status-w1c-broken` | CSR | top_dw64 | PROOF BREAKS | STATUS flags cannot be cleared |
| `top-unpriv-read` | CSR | top_dw64 | PROOF BREAKS | an unprivileged CSR read returns data (a root pointer / a fault record leaks) |
| `top-unpriv-write` | SAFETY | top_dw64 | PROOF BREAKS | an unprivileged CSR write takes effect (a tenant programs its own context) |
