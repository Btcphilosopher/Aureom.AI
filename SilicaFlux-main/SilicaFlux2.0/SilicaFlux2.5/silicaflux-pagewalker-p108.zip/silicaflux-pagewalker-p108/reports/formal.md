# Formal verification

Yosys 0.33 + ABC (`bmc3` base case, `ind` k-induction).  **PROVED** = k-induction (unbounded: all inputs, all reachable states).  **BOUNDED** = BMC from reset, no violation within the depth (NOT unbounded).  **WITNESSED** = a reachability witness (the assertion had to fail) so the proofs are not vacuous.

| job | kind | result | depth | seconds | claim |
|---|---|---|---|---|---|
| `tlb_n4` | prove | **PROVED** | 4 | 8 | T1 uniqueness, T2 no stale hit after a covering invalidation, T3 invalidation beats fill, T4 LRU ages are a permutation, T5 a hit returns the last fill, T6 every valid entry grants a right (no negative caching) -- N = 4 (the baseline), all inputs, all reachable states |
| `tlb_n3` | prove | **PROVED** | 4 | 4 | the same with 3 entries (a non-power-of-two: ages must stay < N) |
| `tlb_n2` | prove | **PROVED** | 4 | 2 | the same with 2 entries and 4 contexts |
| `tlb_n8` | prove | **PROVED** | 4 | 134 | the same with 8 entries (the capacity expansion) |
| `tlb_n16` | prove | **UNKNOWN** | 3 | 3053 | the same with 16 entries |
| `vac_tlb_1` | vac | **WITNESSED** | 14 | 3 | witness: a hit on a given page |
| `vac_tlb_2` | vac | **WITNESSED** | 14 | 3 | witness: an LRU eviction |
| `vac_tlb_3` | vac | **WITNESSED** | 14 | 3 | witness: a fill and an invalidation in the same cycle |
| `vac_tlb_4` | vac | **WITNESSED** | 14 | 3 | witness: a 1 GiB fill |
| `vac_tlb_5` | vac | **WITNESSED** | 14 | 3 | witness: a 2 MiB hit |
| `vac_tlb_6` | vac | **WITNESSED** | 14 | 3 | witness: a hit after an eviction |
| `inv_q1` | prove | **PROVED** | 6 | 1 | V1..V5: a commit only after a DRAIN cycle in which the ports pipe_idle and dma_quiet were high; a timeout never commits; DRAIN is bounded by DRAIN_TMO; exactly one completion per command |
| `inv_q0` | prove | **PROVED** | 6 | 1 | the same without the dma_quiet wait |
| `inv_t1` | prove | **PROVED** | 6 | 1 | the same with a drain timeout of one cycle |
| `inv_t0` | prove | **PROVED** | 6 | 1 | the same with the timeout disabled (wait forever) |
| `vac_inv_1` | vac | **WITNESSED** | 16 | 1 | witness: a command completes |
| `vac_inv_2` | vac | **WITNESSED** | 16 | 1 | witness: a drain times out |
| `vac_inv_3` | vac | **WITNESSED** | 16 | 1 | witness: a page invalidation commits |
| `vac_inv_4` | vac | **WITNESSED** | 16 | 1 | witness: a context CLEAR commits |
| `vac_inv_5` | vac | **WITNESSED** | 16 | 1 | witness: both outcomes reachable |
| `walk_dw64` | prove | **PROVED** | 8 | 2 | W1a fault class / leaf decision and W1b latched PPN, size, permissions (R&A&U, W&A&D&U) or next table == independent spec for EVERY PTE and level; W5 read addresses; W2 counters in range; W3 + W6 never a read over an abandoned read (own flags / SFB2 R2, R6 on the ports); W7 bus error -> PHYS_READ, torn re-read never decoded; W4 a fault reports no permission -- 64-bit fabric |
| `walk_dw32` | prove | **PROVED** | 8 | 2 | the same, 32-bit fabric with the lo-hi-lo validated read |
| `walk_dw32n` | prove | **PROVED** | 8 | 2 | the same, 32-bit fabric, no validating re-read |
| `walk_sp` | prove | **PROVED** | 8 | 2 | the same with superpages enabled (alignment rule) |
| `walk_b64` | bmc | **BOUNDED** | 30 | 2 | B: a walk ends within 24 cycles under ANY fabric behaviour (3 levels x (WALK_TMO + 2) + 6) -- 64-bit fabric |
| `walk_b32n` | bmc | **BOUNDED** | 48 | 4 | B: bounded, 32-bit fabric, two beats per PTE (3 x 2 x (4 + 2) + 6 = 42) |
| `walk_b32` | bmc | **BOUNDED** | 120 | 11 | B: bounded with the retry budget (3 x 3 x 2 x (4 + 2) + 6 = 114): no undefined retry loop |
| `vac_walk_1` | vac | **WITNESSED** | 40 | 2 | witness: a leaf is found |
| `vac_walk_2` | vac | **WITNESSED** | 40 | 2 | witness: a fabric timeout |
| `vac_walk_3` | vac | **WITNESSED** | 40 | 2 | witness: a torn read is detected and retried |
| `vac_walk_4` | vac | **WITNESSED** | 40 | 2 | witness: a bus error |
| `vac_walk_5` | vac | **WITNESSED** | 40 | 2 | witness: the port is wedged by an abandoned read |
| `vac_walk_6` | vac | **WITNESSED** | 40 | 2 | witness: a level-0 leaf |
| `vac_walk_7` | vac | **WITNESSED** | 40 | 2 | witness: a superpage leaf |
| `vac_walk_8` | vac | **WITNESSED** | 40 | 2 | witness: a PHYS_READ fault after a long walk |
| `vac_walk_9` | vac | **WITNESSED** | 40 | 2 | witness: a new walk request while wedged |
| `ctx_n3` | prove | **PROVED** | 6 | 1 | C1 a command only when every rule holds; C2 the table changes only at a commit; C3 an installed root is inside the fabric; C4 an invalid / out-of-range id is never valid; C5 a commit installs exactly the command's entry (SET: staged root and caps; CLEAR: invalid) |
| `ctx_n4` | prove | **PROVED** | 6 | 1 | the same with 4 contexts and 3-bit device ids |
| `ctx_n1` | prove | **PROVED** | 6 | 1 | the same with one context |
| `vac_ctx_1` | vac | **WITNESSED** | 18 | 1 | witness: a command is issued |
| `vac_ctx_2` | vac | **WITNESSED** | 18 | 1 | witness: a valid device id |
| `vac_ctx_3` | vac | **WITNESSED** | 18 | 1 | witness: a context CLEAR commits |
| `vac_ctx_4` | vac | **WITNESSED** | 18 | 1 | witness: a range error (CE_RANGE) |
| `perf` | prove | **PROVED** | 3 | 10 | every counter is monotone non-decreasing between resets: it saturates and never wraps (41 counters x 32 bits) |
| `flt_d3` | prove | **PROVED** | 6 | 0 | the ring and its count agree; POP on an empty log is a no-op; the drop counter saturates (depth 3: not a power of two) |
| `flt_d4` | prove | **PROVED** | 6 | 1 | the same with depth 4 |
| `flt_d1` | prove | **PROVED** | 6 | 0 | the same with depth 1 |
| `vac_flt_1` | vac | **WITNESSED** | 14 | 0 | witness: a record is dropped (log full) |
| `vac_flt_2` | vac | **WITNESSED** | 14 | 0 | witness: a record is popped |
| `vac_flt_3` | vac | **WITNESSED** | 14 | 0 | witness: a record is read after a drop |
| `top_dw64` | bmc | **BOUNDED** | 34 | 301 | F1 a fabric read only inside a walk; F2 an OK response implies every static check and the context's caps; F3 response structure; F4 a refusal carries no address; F5 one response per request; L bounded first response; M never writes -- free CSR traffic, free hostile fabric (BMC, bounded) |
| `top_dw32` | bmc | **BOUNDED** | 38 | 299 | the same with a 32-bit fabric and the validated PTE read |
| `vac_top_1` | vac | **WITNESSED** | 36 | 32 | witness: an OK translation |
| `vac_top_2` | vac | **WITNESSED** | 36 | 135 | witness: a two-segment response |
| `vac_top_3` | vac | **WITNESSED** | 36 | 22 | witness: an invalidation completes |
| `vac_top_4` | vac | **WITNESSED** | 36 | 23 | witness: a NOT_PRESENT refusal |
| `vac_top_5` | vac | **WITNESSED** | 36 | 22 | witness: a page-table read |
| `vac_top_6` | vac | **WITNESSED** | 36 | 23 | witness: a PHYS_READ refusal |
| `vac_top32_1` | vac | **WITNESSED** | 40 | 147 | witness: an OK translation on a 32-bit fabric (9 page-table reads) -- so top_dw32 covers a completed walk |

## Not as expected

* `tlb_n16`: UNKNOWN induction UNKNOWN up to k=3
