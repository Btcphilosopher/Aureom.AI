# Mutation: simulation and formal combined

97 planted defects.  Simulation kills 92; formal kills 58 (counterexample from reset); **either: 94**.  Killed by both: 56; by simulation only: 36; by formal only: 2; **by neither: 3**.

Formal checks only the module's own harness (the top level by a bounded BMC under a short budget), so many mutants are simulation-only by construction.

## By neither

| mutant | class | what was planted | formal verdict |
|---|---|---|---|
| `perf-wrap-not-saturate` | OBS | counters wrap to zero instead of saturating | PROOF BREAKS |
| `tlb-multi-ignored` | SAFETY | a multi-match is not treated as a miss (OR of two PPNs possible) | SURVIVED |
| `top-fill-on-fault` | OBS | a faulting walk fills the TLB | UNDECIDED |

## Simulation survivors and what formal said

| mutant | class | simulation | formal |
|---|---|---|---|
| `perf-wrap-not-saturate` | OBS | SURVIVED | PROOF BREAKS |
| `tlb-fill-beats-inv` | STALE | SURVIVED | KILLED |
| `tlb-multi-ignored` | SAFETY | SURVIVED | SURVIVED |
| `tlb-reset-keeps-valid` | STALE | SURVIVED | KILLED |
| `top-fill-on-fault` | OBS | SURVIVED | UNDECIDED |

## Formal-only kills (simulation missed them)

* `tlb-fill-beats-inv` (STALE): a fill in the cycle of an invalidation lands (invalidation does not win)
* `tlb-reset-keeps-valid` (STALE): reset does not clear the valid bits

## Simulation-only kills by class

* CSR: 7
* OBS: 12
* SAFETY: 14
* STALE: 3

## Formal 'PROOF BREAKS' (no counterexample; not counted above)

* `perf-wrap-not-saturate`
