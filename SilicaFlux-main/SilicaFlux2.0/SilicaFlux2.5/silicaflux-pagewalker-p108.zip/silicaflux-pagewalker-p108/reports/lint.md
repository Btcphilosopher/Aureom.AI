# Lint, elaboration and parameter-check report

Verilator 5.020 `--lint-only -Wall` (the only waivers are three local `UNUSEDSIGNAL` pragmas in the RTL for deliberately unused bits) and Yosys 0.33 elaboration.

## Verilator -Wall, legal parameter sets

| parameters | result |
|---|---|
| `defaults` | clean |
| `{'DW': 64}` | clean |
| `{'PA_W': 44}` | clean |
| `{'PA_W': 56, 'DW': 64}` | clean |
| `{'TLB_ENTRIES': 2}` | clean |
| `{'TLB_ENTRIES': 8}` | clean |
| `{'TLB_ENTRIES': 16}` | clean |
| `{'TLB_ENTRIES': 64}` | clean |
| `{'NUM_CTX': 1, 'DEV_W': 1}` | clean |
| `{'NUM_CTX': 7, 'DEV_W': 3}` | clean |
| `{'NUM_CTX': 255, 'DEV_W': 8}` | clean |
| `{'FAB_AW': 24}` | clean |
| `{'FAB_AW': 13, 'PA_W': 13}` | clean |
| `{'SUPERPAGE_EN': 1}` | clean |
| `{'PTE_DOUBLE_READ': 0}` | clean |
| `{'WAIT_DMA_QUIET': 0}` | clean |
| `{'ID_W': 16}` | clean |
| `{'ID_W': 1}` | clean |
| `{'LEN_W': 16}` | clean |
| `{'MAX_BYTES': 1}` | clean |
| `{'MAX_BYTES': 256}` | clean |
| `{'FQ_DEPTH': 1}` | clean |
| `{'FQ_DEPTH': 3}` | clean |
| `{'FQ_DEPTH': 64}` | clean |
| `{'WALK_TMO': 4}` | clean |
| `{'RETRY_MAX': 0}` | clean |
| `{'RETRY_MAX': 15}` | clean |
| `{'DRAIN_TMO_DEFAULT': 0}` | clean |
| `{'DW': 64, 'SUPERPAGE_EN': 1, 'TLB_ENTRIES': 16, 'PA_W': 48}` | clean |

## Negative elaboration tests: every illegal parameter set must be rejected by its intended check

| parameters | intended check | result |
|---|---|---|
| `{'TLB_ENTRIES': 1}` | `g_chk_tlb` | rejected by it |
| `{'TLB_ENTRIES': 65}` | `g_chk_tlb` | rejected by it |
| `{'NUM_CTX': 0}` | `g_chk_ctx` | rejected by it |
| `{'NUM_CTX': 256}` | `g_chk_ctx` | rejected by it |
| `{'DEV_W': 0}` | `g_chk_devw` | rejected, but by Verilator's zero-width error on a port declaration BEFORE the check is reached |
| `{'DEV_W': 9}` | `g_chk_devw` | rejected by it |
| `{'NUM_CTX': 8, 'DEV_W': 2}` | `g_chk_devn` | rejected by it |
| `{'ID_W': 0}` | `g_chk_idw` | rejected, but by Verilator's zero-width error on a port declaration BEFORE the check is reached |
| `{'ID_W': 17}` | `g_chk_idw` | rejected by it |
| `{'MAX_BYTES': 0}` | `g_chk_maxb` | rejected by it |
| `{'MAX_BYTES': 4097}` | `g_chk_maxb` | rejected by it |
| `{'LEN_W': 12}` | `g_chk_lenw` | rejected by it |
| `{'LEN_W': 17}` | `g_chk_lenw` | rejected by it |
| `{'PA_W': 12}` | `g_chk_paw` | rejected, but by Verilator's zero-width error on a port declaration BEFORE the check is reached |
| `{'PA_W': 57}` | `g_chk_paw` | rejected by it |
| `{'FAB_AW': 12}` | `g_chk_fab` | rejected, but by Verilator's zero-width error on a port declaration BEFORE the check is reached |
| `{'FAB_AW': 33, 'PA_W': 40}` | `g_chk_fab` | rejected by it |
| `{'FAB_AW': 32, 'PA_W': 24}` | `g_chk_fab` | rejected by it |
| `{'DW': 16}` | `g_chk_dw` | rejected by it |
| `{'DW': 128}` | `g_chk_dw` | rejected by it |
| `{'WALK_TMO': 3}` | `g_chk_tmo` | rejected by it |
| `{'RETRY_MAX': 16}` | `g_chk_retry` | rejected by it |
| `{'FQ_DEPTH': 0}` | `g_chk_fq` | rejected, but by Verilator's zero-width error on a port declaration BEFORE the check is reached |
| `{'FQ_DEPTH': 65}` | `g_chk_fq` | rejected by it |

## Yosys elaboration, `check -assert`, latch count

| parameters | result |
|---|---|
| `defaults` | 0 problems, 0 latches |
| `{'DW': 64, 'SUPERPAGE_EN': 1}` | 0 problems, 0 latches |
| `{'TLB_ENTRIES': 16, 'PA_W': 44}` | 0 problems, 0 latches |
