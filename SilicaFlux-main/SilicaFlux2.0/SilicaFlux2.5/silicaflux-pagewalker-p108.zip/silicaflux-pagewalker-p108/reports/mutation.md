# Simulation mutation campaign

Baseline (unmutated RTL) passes the same suite on every stage first.  **92 / 97 planted defects killed**, 5 survived, 0 did not build/apply.

| mutant | class | result | caught by | what was planted |
|---|---|---|---|---|
| `perf-wrap-not-saturate` | OBS | SURVIVED | - | counters wrap to zero instead of saturating |
| `top-fill-on-fault` | OBS | SURVIVED | - | a faulting walk fills the TLB |
| `tlb-multi-ignored` | SAFETY | SURVIVED | - | a multi-match is not treated as a miss (OR of two PPNs possible) |
| `tlb-fill-beats-inv` | STALE | SURVIVED | - | a fill in the cycle of an invalidation lands (invalidation does not win) |
| `tlb-reset-keeps-valid` | STALE | SURVIVED | - | reset does not clear the valid bits |
| `ctx-attr-reserved-unchecked` | CSR | KILLED | base: d_malicious | reserved attribute bits accepted |
| `ctx-index-unchecked` | CSR | KILLED | base: d_malicious | context index not range-checked on a command |
| `ctx-lock-ignored` | CSR | KILLED | base: d_malicious | CTRL.LOCK does not freeze context programming |
| `ctx-mode-unchecked` | CSR | KILLED | base: d_malicious | BARE / reserved modes are accepted |
| `ctx-root-range-unchecked` | CSR | KILLED | base: d_malicious | a root PPN beyond the fabric is accepted at programming time |
| `inv-done-count-wrong` | CSR | KILLED | base: d_drain | a timed-out command counts as completed |
| `inv-index-check-removed` | CSR | KILLED | base: d_inval | an out-of-range context index is accepted by INV_CMD |
| `inv-range-check-removed` | CSR | KILLED | base: d_inval | a non-canonical invalidation address is accepted |
| `top-lock-clearable` | CSR | KILLED | base: d_malicious | CTRL.LOCK can be cleared by software |
| `top-ro-write-ok` | CSR | KILLED | base: d_malicious | a write to a read-only register is not reported |
| `top-status-w1c-broken` | CSR | KILLED | base: d_status | STATUS flags cannot be cleared |
| `top-unpriv-read` | CSR | KILLED | base: d_malicious | an unprivileged CSR read returns data (a root pointer / a fault record leaks) |
| `walk-level0-pointer-descends` | LIVE | KILLED | base: d_invalid_pte | a pointer at the last level is followed (the level counter wraps) |
| `walk-no-wedge-on-timeout` | LIVE | KILLED | base: d_timeout | after a timeout the abandoned read is forgotten: a late response is mistaken for the next walk's / a new read is issued over it |
| `walk-retry-unbounded` | LIVE | KILLED | base: d_flap | the retry budget never runs out |
| `walk-start-while-wedged` | LIVE | KILLED | base: d_timeout | a new walk starts while the port still owes a response |
| `walk-timeout-disabled` | LIVE | KILLED | base: d_timeout | the per-beat watchdog never fires: a silent fabric hangs the walker |
| `walk-withdraw-orphan-req` | LIVE | KILLED | base: d_timeout | an abandoned read is withdrawn from the fabric (SFB2 R2 violated) |
| `flt-keeps-newest` | OBS | KILLED | base: d_boundary | a full log overwrites instead of dropping the newest |
| `flt-pop-when-empty` | OBS | KILLED | base: d_faultlog | POP on an empty log underflows |
| `flt-record-dev-id-swapped` | OBS | KILLED | base: d_unmapped | device and request id swapped in the record |
| `flt-seq-not-advanced-on-drop` | OBS | KILLED | base: d_faultlog | a dropped record does not consume a sequence number |
| `inv-kind-ctx-as-all` | OBS | KILLED | base: d_inval | a context invalidation flushes everything |
| `inv-kind-page-as-ctx` | OBS | KILLED | base: d_inval | a page invalidation flushes the whole context |
| `perf-fault-cause-index` | OBS | KILLED | base: d_unmapped | per-cause fault counters always count cause 0 |
| `perf-hit-miss-swapped` | OBS | KILLED | base: d_valid | hit and miss counters swapped |
| `perf-refs-not-counted` | OBS | KILLED | base: d_valid | walk reference counter does not count |
| `tlb-inv-page-ignores-ctx` | OBS | KILLED | base: d_inval_ctx | page invalidation also drops the same page of other contexts (over-invalidation) |
| `tlb-lru-no-touch-on-hit` | OBS | KILLED | base: d_concurrent | a hit does not refresh the LRU age (FIFO replacement) |
| `tlb-no-fill-filter` | OBS | KILLED | base: d_perm | a leaf that grants nothing is cached |
| `tlb-victim-lowest-index` | OBS | KILLED | base: d_tlb_repl | replacement always evicts entry 0 instead of the least recently used |
| `top-fault-level-wrong` | OBS | KILLED | base: d_unmapped | the fault record never names the walk level |
| `top-lat-sample-wrong` | OBS | KILLED | base: d_valid | latency counter is one cycle short |
| `ctx-busy-unchecked` | ORDER | KILLED | base: d_status | a context command is accepted while another command is in progress |
| `inv-ignores-quiet` | ORDER | KILLED | base: d_drain | dma_quiet is ignored |
| `inv-no-blocking` | ORDER | KILLED | base: d_concurrent | requests are not held off while a command is pending |
| `inv-no-drain` | ORDER | KILLED | base: d_concurrent | the command does not wait for the translator to go idle |
| `top-idle-while-resp` | ORDER | KILLED | base: d_concurrent | the translator counts as idle while a response is still held |
| `top-ready-during-inv` | ORDER | KILLED | base: d_concurrent | requests are accepted while a command is pending |
| `ctx-allow-r-ignored` | SAFETY | KILLED | base: d_perm | the context's read cap is not enforced |
| `ctx-allow-w-ignored` | SAFETY | KILLED | base: d_perm | the context's write cap is not enforced |
| `ctx-attr-swapped` | SAFETY | KILLED | base: d_perm | read and write caps swapped at commit |
| `ctx-range-ignored` | SAFETY | KILLED | base: d_malicious | the device id is not range-checked: ids above NUM_CTX alias a valid context |
| `ctx-valid-ignored` | SAFETY | KILLED | base: d_multictx | an unprogrammed / cleared context is accepted (root 0) |
| `tlb-ctx-tag-ignored` | SAFETY | KILLED | base: d_valid | lookup ignores the context tag: a translation of one device context is served to another |
| `tlb-ppn-truncated` | SAFETY | KILLED | base: d_invalid_pte | the top bit of the cached PPN is dropped: a TLB hit returns a wrong physical address |
| `tlb-read-perm-from-write` | SAFETY | KILLED | base: d_boundary | the cached read permission is the write permission |
| `tlb-write-perm-from-read` | SAFETY | KILLED | base: d_perm | the cached write permission is the READ permission: a write to a read-only page succeeds on a TLB hit |
| `top-canon-end-ignored` | SAFETY | KILLED | base: d_boundary | the LAST byte is not checked for canonicality |
| `top-canon-start-ignored` | SAFETY | KILLED | base: d_malicious | the first byte is not checked for canonicality |
| `top-claim-ignored` | SAFETY | KILLED | base: d_malicious | a descriptor's claimed context is not compared with the trusted one |
| `top-claim-obeyed` | SAFETY | KILLED | base: d_malicious | the descriptor's claim SELECTS the context (an untrusted descriptor picks its page-table root) |
| `top-cross-off-by-one` | SAFETY | KILLED | base: d_boundary | a request ending exactly one byte past the page is not split |
| `top-len-off-by-one` | SAFETY | KILLED | base: d_boundary | a request of MAX_BYTES + 1 bytes is accepted |
| `top-len1-wrong` | SAFETY | KILLED | base: d_boundary | the second segment is one byte too long |
| `top-overflow-ignored` | SAFETY | KILLED | base: d_boundary | IOVA + length wrapping 2**64 is not detected |
| `top-pa-leak-on-refusal` | SAFETY | KILLED | base: d_unmapped | an address leaves with a refusal |
| `top-perm-inverted-on-hit` | SAFETY | KILLED | base: d_perm | a TLB hit checks the opposite permission |
| `top-perm-skipped-after-walk` | SAFETY | KILLED | base: d_perm | the permission of a freshly walked leaf is not checked |
| `top-rsp-last-wrong` | SAFETY | KILLED | base: d_boundary | the first segment of a two-page request is marked last |
| `top-second-page-perm-ignored-hit` | SAFETY | KILLED | base: d_boundary | a TLB hit on the SECOND page of a request is granted without a permission check (first page released, second unchecked) |
| `top-second-page-perm-ignored-walk` | SAFETY | KILLED | base: d_boundary | a walked leaf of the SECOND page is granted without a permission check |
| `top-seg1-offset` | SAFETY | KILLED | base: d_boundary | the second segment keeps the first page's offset |
| `top-unpriv-write` | SAFETY | KILLED | base: d_malicious | an unprivileged CSR write takes effect (a tenant programs its own context) |
| `top-zero-len-ok` | SAFETY | KILLED | base: d_boundary | a zero-length request is accepted |
| `walk-a-not-required` | SAFETY | KILLED | base: d_perm | the accessed bit is not required for a read (Svade violated) |
| `walk-bus-error-ignored` | SAFETY | KILLED | base: d_fabric | a bus error on a PTE read is ignored (the zero data is decoded) |
| `walk-d-not-required` | SAFETY | KILLED | base: d_perm | the dirty bit is not required for a write |
| `walk-leaf-ppn-overflow-unchecked` | SAFETY | KILLED | base: d_invalid_pte | a leaf PPN beyond the physical address width is accepted (the address is truncated) |
| `walk-leaf-r-or-w-fill` | SAFETY | KILLED | base: d_perm | an X bit flips the low bit of the returned PPN |
| `walk-no-torn-compare` | SAFETY | KILLED | base: d_flap | the validating re-read of the low word is not compared: a torn (mixed) PTE is accepted |
| `walk-pointer-adu-allowed` | SAFETY | KILLED | base: d_invalid_pte | reserved A/D/U bits on a pointer PTE are accepted |
| `walk-pointer-ppn-unchecked` | SAFETY | KILLED | base: d_invalid_pte | a pointer PPN beyond the fabric is followed (the address wraps) |
| `walk-reserved-bits-mask` | SAFETY | KILLED | base: d_invalid_pte | only PTE bits 63:61 are checked as reserved |
| `walk-superpage-without-enable` | SAFETY | KILLED | base: d_invalid_pte | a 2 MiB / 1 GiB leaf is accepted as if it were 4 KiB |
| `walk-u-not-required` | SAFETY | KILLED | base: d_perm | the user bit is not required for a read |
| `walk-u-not-required-w` | SAFETY | KILLED | base: d_perm | the user bit is not required for a write |
| `walk-valid-bit-ignored` | SAFETY | KILLED | base: d_unmapped | the V bit is not checked |
| `walk-w-without-r-allowed` | SAFETY | KILLED | base: d_invalid_pte | the reserved W-without-R encoding is accepted |
| `walk-wrong-beat-offset` | SAFETY | KILLED | base: d_valid | the high word is read from +8 instead of +4 |
| `walk-wrong-level-index` | SAFETY | KILLED | base: d_valid | level 1 and level 0 index bits swapped |
| `walk-x-only-as-pointer` | SAFETY | KILLED | base: d_perm | an execute-only PTE is treated as a pointer |
| `ctx-clear-keeps-valid` | STALE | KILLED | base: d_multictx | CLEAR leaves the context valid |
| `inv-commit-skipped-for-ctxcmd` | STALE | KILLED | base: d_multictx | a context programming command does not flush that context's TLB entries |
| `inv-ctx-from-wrong-reg` | STALE | KILLED | base: d_inval | invalidation always targets context 0 |
| `inv-page-uses-lo-only` | STALE | KILLED | base: d_inval | the page invalidation drops IOVA bits [38:32]: high pages are never invalidated |
| `inv-timeout-applies` | STALE | KILLED | base: d_drain | a drain timeout still applies the command |
| `tlb-inv-all-noop` | STALE | KILLED | base: d_malicious | ALL invalidation clears nothing |
| `tlb-inv-ctx-noop` | STALE | KILLED | base: d_multictx | context invalidation clears nothing |
| `tlb-inv-ctx-wrong-ctx` | STALE | KILLED | base: d_multictx | context invalidation clears every OTHER context |
| `tlb-inv-page-low-bit` | STALE | KILLED | base: d_inval | page invalidation ignores vpn bit 0: the odd/even neighbour is hit instead |
| `tlb-inv-page-never-matches` | STALE | KILLED | base: d_inval | page invalidation matches every page EXCEPT the named one |

## Survivors (see docs/05_VERIFICATION.md for the analysis of each)

* `tlb-fill-beats-inv` (STALE): a fill in the cycle of an invalidation lands (invalidation does not win)
* `tlb-reset-keeps-valid` (STALE): reset does not clear the valid bits
* `tlb-multi-ignored` (SAFETY): a multi-match is not treated as a miss (OR of two PPNs possible)
* `top-fill-on-fault` (OBS): a faulting walk fills the TLB
* `perf-wrap-not-saturate` (OBS): counters wrap to zero instead of saturating
