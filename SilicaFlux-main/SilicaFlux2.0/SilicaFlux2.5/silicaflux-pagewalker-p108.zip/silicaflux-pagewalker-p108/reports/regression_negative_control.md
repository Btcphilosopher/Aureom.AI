# Simulation regression

279 / 282 runs pass.  Every trace judged by the independent reference model (tests/iommu/ref_model.py).

| configuration | scenarios x seeds | pass |
|---|---|---|
| nodbl | 141 | 141 |
| nodbl_wide | 141 | 138 |

## Feature coverage observed by the checker (all runs)

| feature | count |
|---|---|
| cfg | 151308 |
| cfg_refused | 732 |
| cmd_ALL | 924 |
| cmd_CTX | 5226 |
| cmd_PAGE | 3912 |
| cmd_lost_at_reset | 6 |
| cnt_checked | 10722 |
| cnt_unchecked | 846 |
| fabric_reads | 180186 |
| fault_records | 9204 |
| flog_drop | 46458 |
| flog_pop | 9204 |
| flog_pop_empty | 18 |
| flog_reg_checked | 21448 |
| hit_perm_fault | 264 |
| inv_done_ok | 9932 |
| inv_done_tmo | 130 |
| ok | 10462 |
| ok_two_segments | 96 |
| ok_write | 2577 |
| race_claim_ok | 1668 |
| race_outcome_0_of_1 | 1260 |
| race_outcome_0_of_4 | 128 |
| race_outcome_1_of_4 | 194 |
| race_outcome_2_of_4 | 86 |
| refused | 56344 |
| rej_busy | 36 |
| rej_ctxcmd_busy | 12 |
| rej_ctxcmd_cmd | 18 |
| rej_ctxcmd_index | 6 |
| rej_ctxcmd_locked | 12 |
| rej_ctxcmd_range | 48 |
| rej_invcmd_busy | 12 |
| rej_invcmd_cmd | 12 |
| rej_invcmd_index | 6 |
| rej_invcmd_range | 258 |
| rej_locked | 36 |
| requests | 66882 |
| requests_lost_at_reset | 76 |
| resets | 192 |
| static_ADDR_OVERFLOW | 324 |
| static_BAD_CONTEXT | 10802 |
| static_BAD_REQUEST | 2306 |
| static_NONCANONICAL | 11738 |
| static_PERM | 4620 |
| tlb_evict | 4862 |
| tlb_hit | 2207 |
| tlb_miss | 36447 |
| walk_ADDR_OVERFLOW | 18 |
| walk_INVALID_PTE | 5328 |
| walk_MALFORMED | 1248 |
| walk_NOT_PRESENT | 17014 |
| walk_PAGE_SIZE | 774 |
| walk_PERM | 1848 |
| walk_PHYS_READ | 36 |
| walk_timeout | 18 |
| wedge_refusal | 6 |

## Failures

* `nodbl_wide / d_race_bbm_dw32 / seed 1`: cycle 2600: request 7: result [(1, 0, 34376867856, 16, 1)] is none of the allowed outcomes ['pa:17196998672', 'pa:34376871952', 'fault:2', 'fault:7'] (a MIXED translation?); cycle 2658: request 9: result [(1, 0, 34376876048, 16, 1)] is none of the allowed outcomes ['pa:17197006864', 'pa:34376880144'
* `nodbl_wide / d_race_bbm_dw32 / seed 2`: cycle 2620: request 7: result [(1, 0, 34376867856, 16, 1)] is none of the allowed outcomes ['pa:17196998672', 'pa:34376871952', 'fault:2', 'fault:7'] (a MIXED translation?); cycle 2679: request 9: result [(1, 0, 34376876048, 16, 1)] is none of the allowed outcomes ['pa:17197006864', 'pa:34376880144'
* `nodbl_wide / d_race_bbm_dw32 / seed 3`: cycle 2605: request 7: result [(1, 0, 34376867856, 16, 1)] is none of the allowed outcomes ['pa:17196998672', 'pa:34376871952', 'fault:2', 'fault:7'] (a MIXED translation?); cycle 2667: request 9: result [(1, 0, 34376876048, 16, 1)] is none of the allowed outcomes ['pa:17197006864', 'pa:34376880144'
