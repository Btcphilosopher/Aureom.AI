# Simulation regression

1551 / 1551 runs pass.  Every trace judged by the independent reference model (tests/iommu/ref_model.py).

| configuration | scenarios x seeds | pass |
|---|---|---|
| base | 141 | 141 |
| dw64 | 141 | 141 |
| wide | 141 | 141 |
| tmo | 141 | 141 |
| tlb8 | 141 | 141 |
| tlb16 | 141 | 141 |
| ctx1 | 141 | 141 |
| ctx7 | 141 | 141 |
| small | 141 | 141 |
| retry0 | 141 | 141 |
| fab24 | 141 | 141 |

## Feature coverage observed by the checker (all runs)

| feature | count |
|---|---|
| cfg | 821405 |
| cfg_refused | 4023 |
| cmd_ALL | 5067 |
| cmd_CTX | 27696 |
| cmd_PAGE | 22887 |
| cmd_lost_at_reset | 33 |
| cnt_checked | 58971 |
| cnt_unchecked | 4653 |
| fabric_reads | 1369806 |
| fault_records | 47186 |
| flog_drop | 261411 |
| flog_pop | 47186 |
| flog_pop_empty | 99 |
| flog_reg_checked | 107778 |
| hit_perm_fault | 1365 |
| inv_done_ok | 54846 |
| inv_done_tmo | 804 |
| ok | 59720 |
| ok_two_segments | 483 |
| ok_write | 13353 |
| race_claim_ok | 12480 |
| race_outcome_0_of_1 | 9360 |
| race_outcome_0_of_4 | 531 |
| race_outcome_1_of_4 | 2397 |
| race_outcome_2_of_4 | 106 |
| race_outcome_3_of_4 | 86 |
| refused | 312586 |
| rej_busy | 195 |
| rej_ctxcmd_busy | 66 |
| rej_ctxcmd_cmd | 99 |
| rej_ctxcmd_index | 1641 |
| rej_ctxcmd_locked | 66 |
| rej_ctxcmd_range | 240 |
| rej_invcmd_busy | 63 |
| rej_invcmd_cmd | 66 |
| rej_invcmd_index | 1386 |
| rej_invcmd_range | 1332 |
| rej_locked | 198 |
| requests | 372777 |
| requests_lost_at_reset | 471 |
| resets | 1110 |
| static_ADDR_OVERFLOW | 1524 |
| static_BAD_CONTEXT | 67440 |
| static_BAD_REQUEST | 20197 |
| static_NONCANONICAL | 60617 |
| static_PERM | 23606 |
| tlb_evict | 24621 |
| tlb_hit | 11998 |
| tlb_miss | 194859 |
| torn_retries | 2760 |
| walk_ADDR_OVERFLOW | 132 |
| walk_INVALID_PTE | 27939 |
| walk_MALFORMED | 6327 |
| walk_NOT_PRESENT | 89152 |
| walk_PAGE_SIZE | 4483 |
| walk_PERM | 9480 |
| walk_PHYS_READ | 192 |
| walk_timeout | 99 |
| wedge_refusal | 33 |
