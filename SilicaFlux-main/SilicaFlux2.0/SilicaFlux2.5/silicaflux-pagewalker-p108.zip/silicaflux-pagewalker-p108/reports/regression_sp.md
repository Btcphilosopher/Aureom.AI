# Simulation regression

141 / 141 runs pass.  Every trace judged by the independent reference model (tests/iommu/ref_model.py).

| configuration | scenarios x seeds | pass |
|---|---|---|
| sp | 141 | 141 |

## Feature coverage observed by the checker (all runs)

| feature | count |
|---|---|
| cfg | 74326 |
| cfg_refused | 366 |
| cmd_ALL | 462 |
| cmd_CTX | 2613 |
| cmd_PAGE | 2226 |
| cmd_lost_at_reset | 3 |
| cnt_checked | 5361 |
| cnt_unchecked | 423 |
| fabric_reads | 140532 |
| fault_records | 4258 |
| flog_drop | 23515 |
| flog_pop | 4258 |
| flog_pop_empty | 9 |
| flog_reg_checked | 8965 |
| hit_perm_fault | 138 |
| inv_done_ok | 5218 |
| inv_done_tmo | 83 |
| ok | 5821 |
| ok_two_segments | 57 |
| ok_write | 1305 |
| race_claim_ok | 1200 |
| race_outcome_0_of_1 | 900 |
| race_outcome_0_of_4 | 50 |
| race_outcome_1_of_4 | 240 |
| race_outcome_2_of_4 | 10 |
| refused | 28117 |
| rej_busy | 18 |
| rej_ctxcmd_busy | 6 |
| rej_ctxcmd_cmd | 9 |
| rej_ctxcmd_index | 3 |
| rej_ctxcmd_locked | 6 |
| rej_ctxcmd_range | 24 |
| rej_invcmd_busy | 6 |
| rej_invcmd_cmd | 6 |
| rej_invcmd_index | 3 |
| rej_invcmd_range | 129 |
| rej_locked | 18 |
| requests | 33981 |
| requests_lost_at_reset | 43 |
| resets | 96 |
| static_ADDR_OVERFLOW | 162 |
| static_BAD_CONTEXT | 5399 |
| static_BAD_REQUEST | 1154 |
| static_NONCANONICAL | 5869 |
| static_PERM | 2322 |
| tlb_evict | 2663 |
| tlb_hit | 1162 |
| tlb_miss | 18702 |
| torn_retries | 306 |
| walk_ADDR_OVERFLOW | 18 |
| walk_INVALID_PTE | 2707 |
| walk_MALFORMED | 927 |
| walk_NOT_PRESENT | 8467 |
| walk_PERM | 924 |
| walk_PHYS_READ | 18 |
| walk_timeout | 9 |
| wedge_refusal | 3 |
