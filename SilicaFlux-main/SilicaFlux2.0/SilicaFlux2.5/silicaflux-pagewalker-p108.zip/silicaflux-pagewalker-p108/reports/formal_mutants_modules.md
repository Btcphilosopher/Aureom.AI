# Formal mutation check

Each planted defect of `scripts/mutants.py` is applied to the RTL and the formal job(s) of the mutated module are run (the unbounded proofs and module-level invariants; `top_dw64` for the top level, BOUNDED).  **KILLED** = a counterexample from reset (51 / 67).  **PROOF BREAKS** = the unmutated design is PROVED, but on the mutant the induction no longer goes through and BMC finds no counterexample within its depth (1): the proof notices the change but exhibits nothing -- weaker than a kill.  **SURVIVED** = every job still proves / finds nothing: the property set does not see the defect (it is a simulation-only catch, or an equivalent mutant).  **UNKNOWN / timeout** = not decided within the budget.  Simulation kills a different, overlapping subset: the union is in docs/05.

| mutant | class | module job | result | what was planted |
|---|---|---|---|---|
| `ctx-attr-reserved-unchecked` | CSR | ctx_n4 | KILLED | reserved attribute bits accepted |
| `ctx-attr-swapped` | SAFETY | ctx_n4 | KILLED | read and write caps swapped at commit |
| `ctx-busy-unchecked` | ORDER | ctx_n4 | KILLED | a context command is accepted while another command is in progress |
| `ctx-clear-keeps-valid` | STALE | ctx_n4 | KILLED | CLEAR leaves the context valid |
| `ctx-index-unchecked` | CSR | ctx_n4 | KILLED | context index not range-checked on a command |
| `ctx-lock-ignored` | CSR | ctx_n4 | KILLED | CTRL.LOCK does not freeze context programming |
| `ctx-mode-unchecked` | CSR | ctx_n4 | KILLED | BARE / reserved modes are accepted |
| `ctx-range-ignored` | SAFETY | ctx_n4 | KILLED | the device id is not range-checked: ids above NUM_CTX alias a valid context |
| `ctx-root-range-unchecked` | CSR | ctx_n4 | KILLED | a root PPN beyond the fabric is accepted at programming time |
| `ctx-valid-ignored` | SAFETY | ctx_n4 | KILLED | an unprogrammed / cleared context is accepted (root 0) |
| `flt-keeps-newest` | OBS | flt_d3 | KILLED | a full log overwrites instead of dropping the newest |
| `flt-pop-when-empty` | OBS | flt_d3 | KILLED | POP on an empty log underflows |
| `inv-commit-skipped-for-ctxcmd` | STALE | inv_q1 | KILLED | a context programming command does not flush that context's TLB entries |
| `inv-ignores-quiet` | ORDER | inv_q1 | KILLED | dma_quiet is ignored |
| `inv-no-blocking` | ORDER | inv_q1 | KILLED | requests are not held off while a command is pending |
| `inv-no-drain` | ORDER | inv_q1 | KILLED | the command does not wait for the translator to go idle |
| `inv-timeout-applies` | STALE | inv_q1 | KILLED | a drain timeout still applies the command |
| `tlb-ctx-tag-ignored` | SAFETY | tlb_n4 | KILLED | lookup ignores the context tag: a translation of one device context is served to another |
| `tlb-fill-beats-inv` | STALE | tlb_n4 | KILLED | a fill in the cycle of an invalidation lands (invalidation does not win) |
| `tlb-inv-all-noop` | STALE | tlb_n4 | KILLED | ALL invalidation clears nothing |
| `tlb-inv-ctx-noop` | STALE | tlb_n4 | KILLED | context invalidation clears nothing |
| `tlb-inv-ctx-wrong-ctx` | STALE | tlb_n4 | KILLED | context invalidation clears every OTHER context |
| `tlb-inv-page-never-matches` | STALE | tlb_n4 | KILLED | page invalidation matches every page EXCEPT the named one |
| `tlb-no-fill-filter` | OBS | tlb_n4 | KILLED | a leaf that grants nothing is cached |
| `tlb-ppn-truncated` | SAFETY | tlb_n4 | KILLED | the top bit of the cached PPN is dropped: a TLB hit returns a wrong physical address |
| `tlb-read-perm-from-write` | SAFETY | tlb_n4 | KILLED | the cached read permission is the write permission |
| `tlb-reset-keeps-valid` | STALE | tlb_n4 | KILLED | reset does not clear the valid bits |
| `tlb-write-perm-from-read` | SAFETY | tlb_n4 | KILLED | the cached write permission is the READ permission: a write to a read-only page succeeds on a TLB hit |
| `walk-a-not-required` | SAFETY | walk_dw64 | KILLED | the accessed bit is not required for a read (Svade violated) |
| `walk-bus-error-ignored` | SAFETY | walk_dw64 | KILLED | a bus error on a PTE read is ignored (the zero data is decoded) |
| `walk-d-not-required` | SAFETY | walk_dw64 | KILLED | the dirty bit is not required for a write |
| `walk-leaf-ppn-overflow-unchecked` | SAFETY | walk_dw64 | KILLED | a leaf PPN beyond the physical address width is accepted (the address is truncated) |
| `walk-leaf-r-or-w-fill` | SAFETY | walk_dw64 | KILLED | an X bit flips the low bit of the returned PPN |
| `walk-level0-pointer-descends` | LIVE | walk_dw64 | KILLED | a pointer at the last level is followed (the level counter wraps) |
| `walk-no-torn-compare` | SAFETY | walk_dw32 | KILLED | the validating re-read of the low word is not compared: a torn (mixed) PTE is accepted |
| `walk-no-wedge-on-timeout` | LIVE | walk_dw64 | KILLED | after a timeout the abandoned read is forgotten: a late response is mistaken for the next walk's / a new read is issued over it |
| `walk-pointer-adu-allowed` | SAFETY | walk_dw64 | KILLED | reserved A/D/U bits on a pointer PTE are accepted |
| `walk-pointer-ppn-unchecked` | SAFETY | walk_dw64 | KILLED | a pointer PPN beyond the fabric is followed (the address wraps) |
| `walk-reserved-bits-mask` | SAFETY | walk_dw64 | KILLED | only PTE bits 63:61 are checked as reserved |
| `walk-retry-unbounded` | LIVE | walk_dw32 | KILLED | the retry budget never runs out |
| `walk-start-while-wedged` | LIVE | walk_dw64 | KILLED | a new walk starts while the port still owes a response |
| `walk-superpage-without-enable` | SAFETY | walk_dw64 | KILLED | a 2 MiB / 1 GiB leaf is accepted as if it were 4 KiB |
| `walk-timeout-disabled` | LIVE | walk_dw64 | KILLED | the per-beat watchdog never fires: a silent fabric hangs the walker |
| `walk-u-not-required` | SAFETY | walk_dw64 | KILLED | the user bit is not required for a read |
| `walk-u-not-required-w` | SAFETY | walk_dw64 | KILLED | the user bit is not required for a write |
| `walk-valid-bit-ignored` | SAFETY | walk_dw64 | KILLED | the V bit is not checked |
| `walk-w-without-r-allowed` | SAFETY | walk_dw64 | KILLED | the reserved W-without-R encoding is accepted |
| `walk-withdraw-orphan-req` | LIVE | walk_dw64 | KILLED | an abandoned read is withdrawn from the fabric (SFB2 R2 violated) |
| `walk-wrong-beat-offset` | SAFETY | walk_dw32 | KILLED | the high word is read from +8 instead of +4 |
| `walk-wrong-level-index` | SAFETY | walk_dw64 | KILLED | level 1 and level 0 index bits swapped |
| `walk-x-only-as-pointer` | SAFETY | walk_dw64 | KILLED | an execute-only PTE is treated as a pointer |
| `perf-wrap-not-saturate` | OBS | perf | PROOF BREAKS | counters wrap to zero instead of saturating |
| `flt-record-dev-id-swapped` | OBS | flt_d3 | SURVIVED | device and request id swapped in the record |
| `flt-seq-not-advanced-on-drop` | OBS | flt_d3 | SURVIVED | a dropped record does not consume a sequence number |
| `inv-ctx-from-wrong-reg` | STALE | inv_q1 | SURVIVED | invalidation always targets context 0 |
| `inv-done-count-wrong` | CSR | inv_q1 | SURVIVED | a timed-out command counts as completed |
| `inv-index-check-removed` | CSR | inv_q1 | SURVIVED | an out-of-range context index is accepted by INV_CMD |
| `inv-kind-ctx-as-all` | OBS | inv_q1 | SURVIVED | a context invalidation flushes everything |
| `inv-kind-page-as-ctx` | OBS | inv_q1 | SURVIVED | a page invalidation flushes the whole context |
| `inv-page-uses-lo-only` | STALE | inv_q1 | SURVIVED | the page invalidation drops IOVA bits [38:32]: high pages are never invalidated |
| `inv-range-check-removed` | CSR | inv_q1 | SURVIVED | a non-canonical invalidation address is accepted |
| `tlb-inv-page-ignores-ctx` | OBS | tlb_n4 | SURVIVED | page invalidation also drops the same page of other contexts (over-invalidation) |
| `tlb-inv-page-low-bit` | STALE | tlb_n4 | SURVIVED | page invalidation ignores vpn bit 0: the odd/even neighbour is hit instead |
| `tlb-lru-no-touch-on-hit` | OBS | tlb_n4 | SURVIVED | a hit does not refresh the LRU age (FIFO replacement) |
| `tlb-multi-ignored` | SAFETY | tlb_n4 | SURVIVED | a multi-match is not treated as a miss (OR of two PPNs possible) |
| `tlb-victim-lowest-index` | OBS | tlb_n4 | SURVIVED | replacement always evicts entry 0 instead of the least recently used |
| `perf-refs-not-counted` | OBS | walk_dw32 | SURVIVED | walk reference counter does not count |
