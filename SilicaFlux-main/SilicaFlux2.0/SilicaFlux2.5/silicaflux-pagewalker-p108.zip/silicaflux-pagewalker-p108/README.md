# SilicaFlux Project 108 — PageWalker: hardware IOMMU address translation (Aureom.AI)

A synthesizable, single-stage address-translation engine for cloud DMA / accelerators: a 64-bit device-visible address is translated to a physical address through a **TLB** (default **four entries**) and a **page-table walker that reads real DataFabric (SFB2) memory transactions**, under a **trusted device context**, with R/W permission checks, the **full byte range** checked (a transfer that crosses a page boundary is split safely), explicit **fault classes with the failing request identified**, **invalidation** (all / context / page) with completion reporting and a defined ordering against outstanding DMA, and performance counters.

**Status:** the baseline (four-entry TLB, one request / one walk at a time) is built and verified; capacity expansion (TLB 8 / 16, superpages) was run *after* the baseline gate; **concurrency expansion was deliberately not built** (the brief orders it after the memory-safety tests pass). It implements a *defined Sv39-compatible subset*; **it is not Sv39-compliant and not a RISC-V IOMMU** (`docs/01_SPEC_SUBSET.md` §11 lists every difference).

> **Evidence level: RTL simulation, formal checks on RTL, and Yosys generic-gate counts.** No FPGA, no place-and-route, no PDK, no timing / area / power figure, and no simulation against the real DataFabric / DMA RTL. Read `docs/07_LIMITATIONS.md` before relying on anything here.

## Definition of done → evidence

| the brief | evidence | where |
|---|---|---|
| DMA is translated correctly | every response of ~373 k simulated requests (11 configurations) compared with an independent reference model, including every page-table read the engine issued | `reports/regression.md`, `docs/05` §4 |
| invalid accesses are rejected **before side effects** | a statically refused request issues **zero** fabric reads (checked on every request); a refusal returns no address; the engine never writes memory (`m_req_write = 0`, proved/asserted); a two-page request releases **neither** segment if either page is refused | `docs/03` §2–§4, formal F1–F5 |
| invalidation prevents stale mappings | drain-then-commit ordering; **no stale hit after a covering invalidation and "invalidation beats a same-cycle fill" are PROVED** (unbounded, N = 2, 3, 4, 8 entries); ordering FSM proved; checked by the oracle's exact LRU model on every request | `docs/05` §5, `docs/01` §8 |

## Deliverables

| brief | file |
|---|---|
| `sf_iommu_pagewalker.sv` (primary) | `rtl/iommu/sf_iommu_pagewalker.sv` |
| `sf_iommu_tlb.sv`, `sf_iommu_context.sv`, `sf_iommu_walk_fsm.sv`, `sf_iommu_faults.sv`, `sf_iommu_invalidation.sv` | `rtl/iommu/` (+ `sf_iommu_perf.sv` counters, `sf_iommu_defs.svh` macros, `filelist.f`) |
| formal assertions | invariants inside each RTL module under `` `ifdef FORMAL``; harnesses `formal/iommu/`; runner `scripts/formal.py`; results `reports/formal.md` |
| simulation tests | `tests/iommu/` (Verilator C++ bench, scenario generator, **independent reference model + trace checker**); `scripts/regress.py` |
| performance benchmarks | `benchmarks/iommu/` (`run_bench.py`, `report.py`, `synth.py`); results `benchmarks/iommu/results/` |
| documented supported-spec subset | `docs/01_SPEC_SUBSET.md` (normative) and `docs/02_INTERFACES.md` |

Further: `docs/00_AUDIT.md` (what the repo gave and what was assumed), `03_SECURITY.md` (threat model, enforcement points), `04_ARCHITECTURE.md`, `05_VERIFICATION.md`, `06_PERFORMANCE.md`, `07_LIMITATIONS.md`.

## Results at a glance

* **Simulation:** 1551 / 1551 scenario-seed runs pass on 11 configurations; 141 / 141 with superpages. Directed scenarios cover the brief's whole verification list (valid, unmapped, permissions, boundaries, multi-context, invalid PTEs, TLB replacement, invalidation, requests while busy, reset, malicious descriptors, page-table update races). Every trace is judged by an oracle written from `docs/01` that shares no code with the RTL.
* **Negative control:** with the validating third PTE read disabled on a wide-PA build, the same suite **fails** on the break-before-make race scenario (mixed translations) — so the torn-read test is not vacuous.
* **Mutation testing:** 97 planted RTL defects; simulation kills 92, and **94 of 97 are caught by simulation or a formal counterexample**; the other three are two equivalent mutants and one that needs 2³² events (`reports/mutation.md`, `reports/mutation_union.md`; analysed in `docs/05` §7).
* **Formal (Yosys → AIGER → ABC):** PROVED unbounded, at small parameter instances: TLB (2 / 3 / 4 / 8 entries), invalidation FSM (4 variants), walker (4 variants: decode, permissions, PPN, addresses equal an independent statement of the spec for every PTE), context table, fault log, counters never wrap. BOUNDED: walker termination, the composed engine (34 frames at DW 64, 38 at DW 32; each reaches a completed translation within its bound). **UNKNOWN:** the 16-entry TLB induction.
* **Performance (simulation cycles, not time):** TLB hit 3 cycles, statically refused request 2; a miss on a 32-bit fabric makes 9 page-table reads (36 cycles at a 2-cycle memory); hit rate ≈ 99 % inside the TLB's capacity and, for a cyclic sweep, **0 % beyond it** (true LRU). The 41 required counters are ≈ 42 % of the generic-gate count. `docs/06_PERFORMANCE.md`.

## Quick start

Tools (Ubuntu 24.04 packages): Verilator 5.020, Yosys 0.33 (with `yosys-abc`), Python 3, g++, make. (Icarus Verilog 12 is installed in the reference environment but not used.)

```bash
make tools            # print tool versions
make lint             # Verilator -Wall over 29 legal parameter sets + illegal-parameter rejection + Yosys elaboration
make regress-quick    # one configuration, one seed (~10 s)
make regress          # 11 configurations × 3 seeds, directed + random, judged by the oracle (~1 min on 4 cores)
make mutate           # 97 planted defects, baseline gate first (~6 min on 4 cores)
make formal           # proofs, bounded checks, witnesses (~50 min: the 16-entry TLB induction runs ~50 min to an UNKNOWN verdict; every other job together ~10 min)
make formal-mutants   # the defects against the formal harnesses, and the union with simulation
make bench synth      # performance benchmarks (every run verified) and generic-gate estimates
make zip              # rebuild the archive (nothing is committed to git)
```

## Layout

```
rtl/iommu/        the engine (7 modules + macros)            tests/iommu/    bench, generator, reference model, checker
formal/iommu/     formal harnesses                           scripts/        regress, mutate, formal, lint, packaging
benchmarks/iommu/ benchmarks + generic-gate estimates        reports/        generated results (lint, regression, formal, mutation)
docs/             spec subset, interfaces, security, architecture, verification, performance, limitations
```

## What is not done (the short list; the long one is `docs/07_LIMITATIONS.md`)

Concurrency (hit-under-miss, request queues, multiple walkers) · walk cache · multi-stage translation, RISC-V IOMMU device directory, in-memory queues, PASID / ATS / PCIe contexts (the brief says: only after the baseline passes verification) · any silicon / FPGA / timing / power evidence · a simulation against the real DataFabric / DMA RTL · an unbounded proof of the composed design · the 16-entry TLB proof · independent review of `docs/01` (the oracle and the RTL share an author).
