"""
Independent software reference model of the P108 translation engine.

Written from docs/01_SPEC_SUBSET.md ONLY.  It shares no code, no constant table and no module with rtl/iommu/.  It models:
  * the PTE classification and the Sv39 walk (spec section 5), including the lo-hi-lo validated read of a 64-bit PTE over a 32-bit fabric
  * the static request checks and their precedence (spec sections 3, 5, 6)
  * the page split of a request (spec section 2.1)
  * a fully associative LRU TLB (spec section 7) with the invalidation scopes of section 8
It is purely functional: time, handshakes and the CSR bus are the trace checker's business (check_trace.py).
"""

# ---- fault causes (spec section 6)
NONE, BAD_CONTEXT, NOT_PRESENT, PERM, MALFORMED, PAGE_SIZE, PHYS_READ, INVALID_PTE, ADDR_OVERFLOW, NONCANONICAL, BAD_REQUEST = range(11)
FAULT_NAMES = ["NONE", "BAD_CONTEXT", "NOT_PRESENT", "PERM", "MALFORMED", "PAGE_SIZE", "PHYS_READ", "INVALID_PTE",
               "ADDR_OVERFLOW", "NONCANONICAL", "BAD_REQUEST"]

PAGE = 4096
M64 = (1 << 64) - 1


class Params(object):
    """Build-time parameters of the design under test (spec section 1/2/3)."""
    def __init__(self, **kw):
        self.PA_W = 32
        self.FAB_AW = 32
        self.DW = 32
        self.MAX_BYTES = 4096
        self.NUM_CTX = 4
        self.DEV_W = 4
        self.TLB_ENTRIES = 4
        self.SUPERPAGE_EN = 0
        self.PTE_DOUBLE_READ = 1
        self.RETRY_MAX = 2
        self.WALK_TMO = 64
        self.FQ_DEPTH = 4
        for k, v in kw.items():
            setattr(self, k, v)

    @property
    def ppn_lim(self):          # leaf PPN must be below this (physical address width)
        return 1 << (self.PA_W - 12)

    @property
    def fab_lim(self):          # a next-level table PPN must be below this (the fabric)
        return 1 << (self.FAB_AW - 12)


# --------------------------------------------------------------------------------------- PTE (spec section 4 / 5 steps 1-7)
def pte_fields(pte):
    return dict(v=pte & 1, r=(pte >> 1) & 1, w=(pte >> 2) & 1, x=(pte >> 3) & 1, u=(pte >> 4) & 1, g=(pte >> 5) & 1,
                a=(pte >> 6) & 1, d=(pte >> 7) & 1, ppn=(pte >> 10) & ((1 << 44) - 1), rsv=(pte >> 54) & 0x3FF)


def classify(pte, level, P):
    """-> ('F', cause) | ('LEAF', ppn, r_ok, w_ok, psize) | ('PTR', ppn)"""
    f = pte_fields(pte)
    if not f["v"]:
        return ("F", NOT_PRESENT)                                   # step 1
    if f["rsv"]:
        return ("F", INVALID_PTE)                                   # step 2
    if f["w"] and not f["r"]:
        return ("F", INVALID_PTE)                                   # step 3
    if f["r"] or f["x"]:                                            # step 4: leaf
        if level != 0:                                              # step 5
            if not P.SUPERPAGE_EN:
                return ("F", PAGE_SIZE)
            if f["ppn"] & ((1 << (9 * level)) - 1):
                return ("F", MALFORMED)
        if f["ppn"] >= P.ppn_lim:                                   # step 6
            return ("F", ADDR_OVERFLOW)
        r_ok = f["r"] & f["a"] & f["u"]
        w_ok = f["w"] & f["a"] & f["d"] & f["u"]
        return ("LEAF", f["ppn"], r_ok, w_ok, level)
    # pointer
    if f["a"] or f["d"] or f["u"]:
        return ("F", INVALID_PTE)
    if level == 0:
        return ("F", MALFORMED)
    if f["ppn"] >= P.fab_lim:
        return ("F", MALFORMED)
    return ("PTR", f["ppn"])


def vpn_part(vpn, level):
    return (vpn >> (9 * level)) & 0x1FF


def beat_offsets(P):
    if P.DW == 64:
        return [0]
    return [0, 4, 0] if P.PTE_DOUBLE_READ else [0, 4]


class ReplayMismatch(Exception):
    pass


NEED_MORE = "NEED_MORE"         # the trace ran out where the walk should have read again (a timeout / wedge)


def replay_walk(events, pos, root, vpn, P):
    """Replay ONE walk against the fabric reads the DUT actually made.

    events: list of (addr, data, err, complete) in order.  Every read the walker issues must be exactly the read the algorithm of
    spec section 5 demands given the data it received.  Returns (outcome, newpos, retries) with outcome
       ('F', cause, level)  |  ('LEAF', ppn, r_ok, w_ok, psize, level)  |  (NEED_MORE, level)
    Raises ReplayMismatch when the DUT's reads deviate from the algorithm."""
    level, table, retries = 2, root, 0
    while True:
        attempts = 0
        while True:
            lo = hi = lo2 = None
            offs = beat_offsets(P)
            data = []
            for off in offs:
                want = table * PAGE + vpn_part(vpn, level) * 8 + off
                if pos >= len(events):
                    return ((NEED_MORE, level), pos, retries)
                addr, d, err, complete = events[pos]
                if addr != want:
                    raise ReplayMismatch("level %d: read 0x%x, algorithm demands 0x%x" % (level, addr, want))
                pos += 1
                if not complete:                                    # accepted, never answered: the walk must end in a timeout
                    return ((NEED_MORE, level), pos, retries)
                if err:
                    return (("F", PHYS_READ, level), pos, retries)
                data.append(d)
            if P.DW == 64:
                pte = data[0]
            else:
                lo, hi = data[0] & 0xFFFFFFFF, data[1] & 0xFFFFFFFF
                if P.PTE_DOUBLE_READ:
                    lo2 = data[2] & 0xFFFFFFFF
                    if lo2 != lo:
                        if attempts < P.RETRY_MAX:
                            attempts += 1
                            retries += 1
                            continue
                        return (("F", INVALID_PTE, level), pos, retries)
                pte = (hi << 32) | lo
            break
        c = classify(pte, level, P)
        if c[0] == "F":
            return (("F", c[1], level), pos, retries)
        if c[0] == "LEAF":
            return (("LEAF", c[1], c[2], c[3], c[4], level), pos, retries)
        table, level = c[1], level - 1


# --------------------------------------------------------------------------------------- request-level static checks (spec 3, 5, 6)
def canonical(a):
    top = a >> 38
    return top == 0 or top == (1 << 26) - 1


def static_check(P, ctx, dev, claim_valid, claim_dev, write, iova, nbytes):
    """ctx: dict idx -> (root_ppn, allow_r, allow_w) of VALID contexts.  Returns the first refusal cause or NONE."""
    if dev >= P.NUM_CTX or dev not in ctx:
        return BAD_CONTEXT
    if claim_valid and claim_dev != dev:
        return BAD_CONTEXT
    if nbytes == 0 or nbytes > P.MAX_BYTES:
        return BAD_REQUEST
    last = iova + nbytes - 1
    if last > M64:
        return ADDR_OVERFLOW
    if not canonical(iova) or not canonical(last):
        return NONCANONICAL
    root, ar, aw = ctx[dev]
    if (write and not aw) or ((not write) and not ar):
        return PERM
    return NONE


def split_pages(iova, nbytes):
    """-> list of (vpn, offset, length) -- one entry, or two if the request crosses one page boundary."""
    last = iova + nbytes - 1
    vpn0 = (iova >> 12) & ((1 << 27) - 1)
    off = iova & 0xFFF
    if off + nbytes <= PAGE:
        return [(vpn0, off, nbytes)]
    l0 = PAGE - off
    vpn1 = (last >> 12) & ((1 << 27) - 1)
    return [(vpn0, off, l0), (vpn1, 0, nbytes - l0)]


# --------------------------------------------------------------------------------------- TLB (spec section 7)
class RefTLB(object):
    """Fully associative, true LRU.  entries: MRU first.  Only the *behaviour* is modelled (what hits, what is evicted)."""
    def __init__(self, n):
        self.n = n
        self.e = []                                   # [(ctx, vpn, psize, ppn, r_ok, w_ok)]

    @staticmethod
    def _mask(ps):
        return ~((1 << (9 * ps)) - 1)

    def _match(self, ent, ctx, vpn):
        return ent[0] == ctx and ((ent[1] ^ vpn) & self._mask(ent[2])) == 0

    def lookup(self, ctx, vpn, touch=True):
        for i, ent in enumerate(self.e):
            if self._match(ent, ctx, vpn):
                if touch:
                    self.e.insert(0, self.e.pop(i))
                return ent
        return None

    def fill(self, ctx, vpn, psize, ppn, r_ok, w_ok):
        if not (r_ok or w_ok):                        # a leaf that grants nothing is never cached
            return False
        m = self._mask(psize)
        # remove every overlapping entry of this context (overlap: equal under the coarser mask)
        keep = []
        removed = 0
        for ent in self.e:
            mm = self._mask(ent[2]) & m
            if ent[0] == ctx and ((ent[1] ^ vpn) & mm) == 0:
                removed += 1
            else:
                keep.append(ent)
        self.e = keep
        evicted = False
        if len(self.e) >= self.n:
            self.e.pop()                              # least recently used
            evicted = True
        self.e.insert(0, (ctx, vpn, psize, ppn, r_ok, w_ok))
        return evicted

    def invalidate(self, kind, ctx=None, vpn=None):
        if kind == "ALL":
            self.e = []
        elif kind == "CTX":
            self.e = [x for x in self.e if x[0] != ctx]
        elif kind == "PAGE":
            self.e = [x for x in self.e if not (x[0] == ctx and ((x[1] ^ vpn) & self._mask(x[2])) == 0)]


def eff_ppn(ppn, psize, vpn):
    if psize == 0:
        return ppn
    m = (1 << (9 * psize)) - 1
    return (ppn & ~m) | (vpn & m)
