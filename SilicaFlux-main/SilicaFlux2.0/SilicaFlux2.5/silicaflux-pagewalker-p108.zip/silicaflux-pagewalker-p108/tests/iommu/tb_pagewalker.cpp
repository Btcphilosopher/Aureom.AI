// =============================================================================
// SilicaFlux P108 PageWalker -- Verilator system bench.
//
//   scenario file (written by gen_scenarios.py)  -->  this bench  -->  trace file  -->  check_trace.py (independent reference model)
//
// The bench is a STIMULUS + MEMORY MODEL + PROTOCOL MONITOR.  It contains no translation logic: whether a translation is right is decided
// ONLY by tests/iommu/ref_model.py / check_trace.py, which are written from docs/01_SPEC_SUBSET.md and share no code with the RTL.
//
// Models:   SFB2 slave memory (page tables), latency / jitter / error ranges / hang (timeout + late-response tests),
//           a DMA-side requester and response consumer (ready jitter), a privileged CSR master (incl. a fault-log drain macro),
//           timed memory pokes (page-table updates, word granular => torn windows), reset, dma_quiet.
// Monitors: SFB2 rules on the walker port (hold until accepted, write == 0, DW alignment, one outstanding), response stability, no response
//           without a request, CSR response stability.  A monitor failure is a FAIL (exit 2).
// Usage:    tb_<cfg> <scenario> <trace> [seed]
// =============================================================================
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <deque>
#include <map>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <algorithm>
#include "VTOP.h"
#include "verilated.h"

#ifndef BENCH_DW
#define BENCH_DW 32
#endif
#ifndef BENCH_ID_W
#define BENCH_ID_W 4
#endif
#ifndef BENCH_DEV_W
#define BENCH_DEV_W 4
#endif
#ifndef BENCH_LEN_W
#define BENCH_LEN_W 13
#endif
#ifndef BENCH_MEM_BYTES
#define BENCH_MEM_BYTES (64u << 20)
#endif

// Verilator does not mask C++ inputs to the port width: the bench must never drive a bit the port does not have.
#define MASKW(w) ((uint64_t)((1ull << (w)) - 1))
static uint64_t rng_s = 88172645463325252ull;
static uint32_t rnd() { rng_s ^= rng_s << 13; rng_s ^= rng_s >> 7; rng_s ^= rng_s << 17; return (uint32_t)(rng_s >> 11); }
static bool chance(int pct) { return (int)(rnd() % 100) < pct; }

// A command fires when cycle >= t AND all its gates hold: @req=n (n requests fully answered), @inv=k (k completion events seen),
// @cfg=m (m CSR accesses answered), @frs=k (k fabric responses delivered) [+ @dly=d cycles after the gate opened].
struct Gate    { long req = -1, inv = -1, cfg = -1, frs = -1, acc = -1, rfrs = -1, rst = -1, pk = -1; long dly = 0; long setinv = -1; bool open = false; uint64_t t_open = 0; };
struct ReqCmd  { uint64_t t; unsigned dev, cv, cd, wr; uint64_t iova; unsigned bytes, id; Gate g; };
struct CfgCmd  { uint64_t t; int kind; unsigned addr, val; int priv; Gate g; };   // kind 0 write, 1 read, 2 fault-log drain macro
struct Poke    { uint64_t t; uint32_t addr, val; int two = 0; uint32_t val_hi = 0; Gate g; };
struct Timed   { uint64_t t; int a, b; Gate g; };

static VTOP* top;
static uint64_t cyc = 0;
static FILE*    tr;
static int      fails = 0;
static void fail(const char* m) { fprintf(stderr, "BENCH FAIL @%llu: %s\n", (unsigned long long)cyc, m); fprintf(tr, "BENCHFAIL %llu %s\n", (unsigned long long)cyc, m); fails++; }

// ------------------------------------------------------------------ memory
static std::unordered_map<uint32_t, uint32_t> mem;
static std::vector<std::pair<uint32_t, uint32_t>> errr;
static bool mem_err(uint32_t a) {
  if (a >= BENCH_MEM_BYTES) return true;
  for (auto& r : errr) if (a >= r.first && a < r.second) return true;
  return false;
}
static uint32_t rd32(uint32_t a) { auto it = mem.find(a >> 2); return it == mem.end() ? 0u : it->second; }
static long n_req_done = 0, n_inv = 0, n_cfg_done = 0, n_frs = 0, n_acc = 0, n_rfrs = 0, n_rst = 0, n_pk = 0;   // n_rfrs: fabric responses since the last request handshake
static void parse_gate(std::istringstream& is, Gate& g) {
  std::string tok;
  while (is >> tok) {
    if (tok.size() < 4 || tok[0] != '@') continue;
    size_t eq = tok.find('='); if (eq == std::string::npos) continue;
    std::string k = tok.substr(1, eq - 1); long v = strtol(tok.c_str() + eq + 1, 0, 0);
    if (k == "req") g.req = v; else if (k == "inv") g.inv = v; else if (k == "cfg") g.cfg = v; else if (k == "frs") g.frs = v; else if (k == "dly") g.dly = v; else if (k == "setinv") g.setinv = v; else if (k == "acc") g.acc = v; else if (k == "rfrs") g.rfrs = v; else if (k == "rst") g.rst = v; else if (k == "pk") g.pk = v;
  }
}
static bool gate_ok(Gate& g) {
  if (!g.open) {
    if ((g.req >= 0 && n_req_done < g.req) || (g.inv >= 0 && n_inv < g.inv) || (g.cfg >= 0 && n_cfg_done < g.cfg) || (g.frs >= 0 && n_frs < g.frs) || (g.acc >= 0 && n_acc < g.acc) || (g.rfrs >= 0 && n_rfrs < g.rfrs) || (g.rst >= 0 && n_rst < g.rst) || (g.pk >= 0 && n_pk < g.pk)) return false;
    g.open = true; g.t_open = cyc;
  }
  return cyc >= g.t_open + (uint64_t)g.dly;
}

int main(int argc, char** argv) {
  if (argc < 3) { fprintf(stderr, "usage: %s scenario trace [seed]\n", argv[0]); return 1; }
  if (argc > 3) rng_s ^= (uint64_t)strtoull(argv[3], 0, 0) * 0x9E3779B97F4A7C15ull;
  Verilated::commandArgs(argc, argv);
  top = new VTOP;
  tr  = fopen(argv[2], "w");
  if (!tr) { fprintf(stderr, "cannot open trace\n"); return 1; }

  // ---------------------------------------------------------------- scenario
  std::vector<ReqCmd> reqs; std::vector<CfgCmd> cfgs; std::vector<Poke> pokes;
  std::vector<Timed> resets, quiets, rspmodes, lats, hangs; uint64_t end_t = 0; int req_pipe = 1;
  {
    std::ifstream f(argv[1]); std::string line;
    if (!f) { fprintf(stderr, "cannot open scenario\n"); return 1; }
    while (std::getline(f, line)) {
      if (line.empty() || line[0] == '#') continue;
      std::istringstream is(line); std::string op; is >> op;
      auto H = [&](uint64_t& v) { std::string s; is >> s; v = strtoull(s.c_str(), 0, 0); };
      if (op == "mem32") { uint64_t a, v; H(a); H(v); mem[(uint32_t)(a >> 2)] = (uint32_t)v; }
      else if (op == "memerr") { uint64_t a, b; H(a); H(b); errr.push_back({(uint32_t)a, (uint32_t)b}); }
      else if (op == "req") { ReqCmd r; uint64_t x; H(r.t); H(x); r.dev = x; H(x); r.cv = x; H(x); r.cd = x; H(x); r.wr = x; H(r.iova); H(x); r.bytes = x; H(x); r.id = x; parse_gate(is, r.g); reqs.push_back(r); }
      else if (op == "cfg") { CfgCmd c; uint64_t x; std::string k; H(c.t); is >> k; c.kind = (k[0] == 'w') ? 0 : 1; c.priv = (k.size() > 1 && k[1] == 'u') ? 0 : 1; H(x); c.addr = x; H(x); c.val = x; parse_gate(is, c.g); cfgs.push_back(c); }
      else if (op == "fdrain") { CfgCmd c; c.t = 0; H(c.t); c.kind = 2; c.addr = 0; c.val = 0; c.priv = 1; parse_gate(is, c.g); cfgs.push_back(c); }
      else if (op == "poke") { Poke p; uint64_t a, v; H(p.t); H(a); H(v); p.addr = (uint32_t)a; p.val = (uint32_t)v; parse_gate(is, p.g); pokes.push_back(p); }
      else if (op == "poke64") { Poke p; uint64_t a, v, w; H(p.t); H(a); H(v); H(w); p.addr = (uint32_t)a; p.val = (uint32_t)v; p.two = 1; p.val_hi = (uint32_t)w; parse_gate(is, p.g); pokes.push_back(p); }
      else if (op == "reset") { Timed t; uint64_t x, y; H(x); H(y); t.t = x; t.a = (int)y; t.b = 0; parse_gate(is, t.g); resets.push_back(t); }
      else if (op == "quiet") { Timed t; uint64_t x, y; H(x); H(y); t.t = x; t.a = (int)y; t.b = 0; parse_gate(is, t.g); quiets.push_back(t); }
      else if (op == "rspmode") { Timed t; uint64_t x, y; H(x); H(y); t.t = x; t.a = (int)y; t.b = 0; parse_gate(is, t.g); rspmodes.push_back(t); }
      else if (op == "memlat") { Timed t; uint64_t x, y, z; H(x); H(y); H(z); t.t = x; t.a = (int)y; t.b = (int)z; parse_gate(is, t.g); lats.push_back(t); }
      else if (op == "memhang") { Timed t; uint64_t x, y; H(x); H(y); t.t = x; t.a = (int)y; t.b = 0; parse_gate(is, t.g); hangs.push_back(t); }
      else if (op == "reqpipe") { uint64_t x; H(x); req_pipe = (int)x; }
      else if (op == "end") { H(end_t); }
      else { fprintf(stderr, "bad scenario line: %s\n", line.c_str()); return 1; }
    }
  }
  // initial memory image into the trace so the checker starts from the same state
  { std::vector<uint32_t> ks; for (auto& kv : mem) ks.push_back(kv.first); std::sort(ks.begin(), ks.end());
    for (uint32_t k : ks) fprintf(tr, "MEM %u %08x\n", k << 2, mem[k]);
    for (auto& r : errr) fprintf(tr, "MEMERR %u %u\n", r.first, r.second); }
  fprintf(tr, "DW %d\n", BENCH_DW);

  // ---------------------------------------------------------------- state
  size_t rq_i = 0, cf_i = 0, pk_i = 0, rs_i = 0, qu_i = 0, rm_i = 0, lt_i = 0, hg_i = 0;
  int rsp_mode = 0, lat_min = 1, lat_max = 2, hang = 0, quiet = 1;
  // requester
  bool rq_pres = false; ReqCmd rq_cur{}; int outstanding = 0;           // outstanding = accepted requests whose last response was not yet delivered
  // memory slave
  bool s_busy = false; uint32_t s_addr = 0; uint64_t s_due = 0; bool s_rsp_hold = false;
  uint32_t last_m_addr = 0; bool last_m_valid = false;
  // cfg master
  bool cf_act = false; bool cf_wait = false; CfgCmd cf_cur{}; uint64_t cf_t_req = 0;
  int  dr_state = 0; uint32_t dr_w[6]; uint32_t dr_cnt = 0;   // fault-log drain macro
  uint64_t reset_until = 0; bool in_reset = false;
  // monitors
  bool rsp_prev_valid = false; uint64_t rsp_prev_sig[6]; bool cfg_prev_valid = false; uint32_t cfg_prev_rd = 0; bool cfg_prev_err = false;
  const uint64_t HARD_LIMIT = 3000000;
  uint64_t idle_after = 0;
  bool rspv_seen = false; uint64_t req_stall = 0, rsp_stall = 0;

  top->rst_n = 0; top->clk = 0;
  top->req_valid = 0; top->req_dev = 0; top->req_claim_valid = 0; top->req_claim_dev = 0; top->req_write = 0; top->req_iova = 0; top->req_bytes = 0; top->req_id = 0;
  top->rsp_ready = 1; top->dma_quiet = 1; top->m_req_ready = 0; top->m_rsp_valid = 0; top->m_rsp_rdata = 0; top->m_rsp_error = 0;
  top->cfg_req_valid = 0; top->cfg_req_write = 0; top->cfg_req_addr = 0; top->cfg_req_wdata = 0; top->cfg_priv = 1; top->cfg_rsp_ready = 1;
  for (int i = 0; i < 4; i++) { top->clk = 0; top->eval(); top->clk = 1; top->eval(); }
  top->rst_n = 1; top->clk = 0; top->eval();

  while (cyc < HARD_LIMIT) {
    // ------------------------------------------------ timed environment
    while (rs_i < resets.size() && resets[rs_i].t <= cyc && gate_ok(resets[rs_i].g)) { reset_until = cyc + resets[rs_i].a; in_reset = true; fprintf(tr, "RST %llu\n", (unsigned long long)cyc); n_rst++; n_req_done = (long)rq_i; n_cfg_done = (long)cf_i; if (resets[rs_i].g.setinv >= 0) n_inv = resets[rs_i].g.setinv; req_stall = 0; rsp_stall = 0; rspv_seen = false; rs_i++;
      s_busy = false; s_rsp_hold = false; rq_pres = false; outstanding = 0; cf_act = false; cf_wait = false; dr_state = 0; last_m_valid = false; rsp_prev_valid = false; cfg_prev_valid = false; }
    if (in_reset && cyc >= reset_until) in_reset = false;
    while (pk_i < pokes.size() && pokes[pk_i].t <= cyc && gate_ok(pokes[pk_i].g)) { mem[pokes[pk_i].addr >> 2] = pokes[pk_i].val; fprintf(tr, "POKE %llu %u %08x\n", (unsigned long long)cyc, pokes[pk_i].addr, pokes[pk_i].val);
      if (pokes[pk_i].two) { mem[(pokes[pk_i].addr + 4) >> 2] = pokes[pk_i].val_hi; fprintf(tr, "POKE %llu %u %08x\n", (unsigned long long)cyc, pokes[pk_i].addr + 4, pokes[pk_i].val_hi); }
      pk_i++; n_pk++; }
    while (qu_i < quiets.size() && quiets[qu_i].t <= cyc && gate_ok(quiets[qu_i].g)) { quiet = quiets[qu_i].a; fprintf(tr, "QUIET %llu %d\n", (unsigned long long)cyc, quiet); qu_i++; }
    while (rm_i < rspmodes.size() && rspmodes[rm_i].t <= cyc && gate_ok(rspmodes[rm_i].g)) { rsp_mode = rspmodes[rm_i].a; rm_i++; }
    while (lt_i < lats.size() && lats[lt_i].t <= cyc && gate_ok(lats[lt_i].g)) { lat_min = lats[lt_i].a; lat_max = lats[lt_i].b; lt_i++; }
    while (hg_i < hangs.size() && hangs[hg_i].t <= cyc && gate_ok(hangs[hg_i].g)) { hang = hangs[hg_i].a; fprintf(tr, "HANG %llu %d\n", (unsigned long long)cyc, hang); hg_i++; }

    // ------------------------------------------------ drive inputs
    top->rst_n = in_reset ? 0 : 1;
    top->dma_quiet = quiet;
    // requester
    if (!in_reset && !rq_pres && rq_i < reqs.size() && reqs[rq_i].t <= cyc && (req_pipe || outstanding == 0) && gate_ok(reqs[rq_i].g)) { rq_cur = reqs[rq_i]; rq_pres = true; rq_i++; }
    top->req_valid = (!in_reset && rq_pres) ? 1 : 0;
    if (rq_pres) { top->req_dev = rq_cur.dev & MASKW(BENCH_DEV_W); top->req_claim_valid = rq_cur.cv & 1; top->req_claim_dev = rq_cur.cd & MASKW(BENCH_DEV_W); top->req_write = rq_cur.wr & 1;
                   top->req_iova = rq_cur.iova; top->req_bytes = rq_cur.bytes & MASKW(BENCH_LEN_W); top->req_id = rq_cur.id & MASKW(BENCH_ID_W); }
    else { top->req_dev = rnd() & MASKW(BENCH_DEV_W); top->req_claim_valid = rnd() & 1; top->req_claim_dev = rnd() & MASKW(BENCH_DEV_W); top->req_write = rnd() & 1;
           top->req_iova = ((uint64_t)rnd() << 32) | rnd(); top->req_bytes = rnd() & MASKW(BENCH_LEN_W); top->req_id = rnd() & MASKW(BENCH_ID_W); }   // junk while not valid (in range)
    // response consumer
    bool rr = (rsp_mode == 0) ? true : (rsp_mode == 1) ? chance(50) : (rsp_mode == 2) ? chance(15) : false;
    top->rsp_ready = rr ? 1 : 0;
    // memory slave
    bool deliver = s_busy && hang == 0 && cyc >= s_due && !in_reset;
    uint32_t m_ready = (!s_busy && !in_reset && hang != 2 && chance(85)) ? 1 : 0;
    top->m_req_ready = m_ready;
    top->m_rsp_valid = deliver ? 1 : 0;
    top->m_rsp_error = 0; top->m_rsp_rdata = 0;
    uint64_t rsp_data = 0; bool rsp_err = false;
    if (deliver) {
      rsp_err = mem_err(s_addr);
      if (!rsp_err) {
        rsp_data = rd32(s_addr);
        if (BENCH_DW == 64) rsp_data |= (uint64_t)rd32(s_addr + 4) << 32;
      }
      top->m_rsp_rdata = rsp_data; top->m_rsp_error = rsp_err ? 1 : 0;
    }
    // cfg master
    top->cfg_rsp_ready = chance(70) ? 1 : 0;
    bool cf_drive = false; unsigned cf_addr = 0, cf_val = 0; bool cf_wr = false;
    if (!in_reset) {
      if (!cf_act && cf_i < cfgs.size() && cfgs[cf_i].t <= cyc && gate_ok(cfgs[cf_i].g)) { cf_cur = cfgs[cf_i]; cf_act = true; cf_wait = false; dr_state = 0; cf_i++; }
      if (cf_act && !cf_wait) {
        if (cf_cur.kind == 2) {   // fault-log drain macro: read CNT; if held: read W0..W3, SEQ; write POP
          static const unsigned A[6] = { 20, 21, 22, 23, 24, 25 };
          if (dr_state == 0)      { cf_drive = true; cf_wr = false; cf_addr = 19 * 4; }
          else if (dr_state <= 5) { cf_drive = true; cf_wr = false; cf_addr = A[dr_state - 1] * 4; }
          else                    { cf_drive = true; cf_wr = true;  cf_addr = 25 * 4; cf_val = 1; }
        } else { cf_drive = true; cf_wr = (cf_cur.kind == 0); cf_addr = cf_cur.addr; cf_val = cf_cur.val; }
      }
    }
    top->cfg_req_valid = cf_drive ? 1 : 0;
    top->cfg_req_write = cf_wr ? 1 : 0; top->cfg_req_addr = cf_drive ? cf_addr : (rnd() & 0xFF); top->cfg_req_wdata = cf_drive ? cf_val : rnd();
    top->cfg_priv = cf_drive ? (cf_cur.priv ? 1 : 0) : (rnd() & 1);

    top->clk = 0; top->eval();

    // ------------------------------------------------ sample (pre-edge): handshakes of this cycle
    bool req_hs = top->req_valid && top->req_ready;
    bool rsp_hs = top->rsp_valid && top->rsp_ready;
    bool m_acc  = top->m_req_valid && top->m_req_ready;
    bool cf_hs  = top->cfg_req_valid && top->cfg_req_ready;
    bool cfr_hs = top->cfg_rsp_valid && top->cfg_rsp_ready;

    // monitors
    if (!in_reset) {
      if (top->m_req_write) fail("walker asserted m_req_write");
      if (top->m_req_valid && (top->m_req_addr % (BENCH_DW / 8)) != 0) fail("walker address not DW aligned");
      if (top->m_req_valid && (top->m_req_addr % 4) != 0) fail("walker address not word aligned");
      if (last_m_valid && !(top->m_req_valid && top->m_req_addr == last_m_addr)) fail("walker withdrew or changed a presented read (SFB2 R2)");
      last_m_valid = top->m_req_valid && !top->m_req_ready; last_m_addr = top->m_req_addr;
      if (m_acc && s_busy) fail("read accepted while one is outstanding");
      uint64_t sig[6] = { top->rsp_id, top->rsp_ok, top->rsp_fault, (uint64_t)top->rsp_pa, top->rsp_bytes, top->rsp_last };
      if (rsp_prev_valid && !(top->rsp_valid && !memcmp(sig, rsp_prev_sig, sizeof sig))) fail("response withdrawn or changed before acceptance");
      rsp_prev_valid = top->rsp_valid && !top->rsp_ready; memcpy(rsp_prev_sig, sig, sizeof sig);
      if (top->rsp_valid && outstanding == 0 && !req_hs) fail("response without an outstanding request");
      if (cfg_prev_valid && !(top->cfg_rsp_valid && top->cfg_rsp_rdata == cfg_prev_rd && top->cfg_rsp_error == cfg_prev_err)) fail("cfg response withdrawn or changed");
      cfg_prev_valid = top->cfg_rsp_valid && !top->cfg_rsp_ready; cfg_prev_rd = top->cfg_rsp_rdata; cfg_prev_err = top->cfg_rsp_error;
      if (top->rsp_valid && top->rsp_ok && top->rsp_fault) fail("rsp_ok with a fault code");
      if (top->rsp_valid && !top->rsp_ok && (top->rsp_pa != 0 || top->rsp_bytes != 0)) fail("address / length leaves with a refusal");
    }

    // trace
    if (!in_reset) {
      if (req_hs) { fprintf(tr, "REQ %llu %u %u %u %u %u %llu %u\n", (unsigned long long)cyc, (unsigned)top->req_id, (unsigned)top->req_dev, (unsigned)top->req_claim_valid,
                           (unsigned)top->req_claim_dev, (unsigned)top->req_write, (unsigned long long)top->req_iova, (unsigned)top->req_bytes); outstanding++; rq_pres = false; n_acc++; n_rfrs = 0; }
      if (top->rsp_valid && !rspv_seen) { fprintf(tr, "RSPV %llu %u\n", (unsigned long long)cyc, (unsigned)top->rsp_id); rspv_seen = true; }
      if (rsp_hs) { rspv_seen = false; fprintf(tr, "RSP %llu %u %u %u %llu %u %u\n", (unsigned long long)cyc, (unsigned)top->rsp_id, (unsigned)top->rsp_ok, (unsigned)top->rsp_fault,
                           (unsigned long long)top->rsp_pa, (unsigned)top->rsp_bytes, (unsigned)top->rsp_last); if (top->rsp_last && outstanding > 0) { outstanding--; n_req_done++; } }
      if (m_acc)  { fprintf(tr, "FRQ %llu %u\n", (unsigned long long)cyc, (unsigned)top->m_req_addr); s_busy = true; s_addr = top->m_req_addr;
                    int span = lat_max - lat_min; int lat = lat_min + (span > 0 ? (int)(rnd() % (span + 1)) : 0); if (lat < 1) lat = 1; s_due = cyc + lat; }
      if (deliver && top->m_rsp_ready) { fprintf(tr, "FRS %llu %u %llx %d\n", (unsigned long long)cyc, s_addr, (unsigned long long)rsp_data, rsp_err ? 1 : 0); s_busy = false; n_frs++; n_rfrs++; }
      if (top->inv_done_evt) { fprintf(tr, "INV %llu %u\n", (unsigned long long)cyc, (unsigned)top->inv_done_status); n_inv++; }
      if (cf_hs) { cf_t_req = cyc; cf_wait = true; fprintf(tr, "ST %llu %llu %llu\n", (unsigned long long)cyc, (unsigned long long)req_stall, (unsigned long long)rsp_stall); }
      if (top->req_valid && !top->req_ready) req_stall++;
      if (top->rsp_valid && !top->rsp_ready) rsp_stall++;
      if (cfr_hs && cf_act && cf_wait) {
        bool wr; unsigned a, v;
        if (cf_cur.kind == 2) { wr = (dr_state == 6); a = (dr_state == 0) ? 19 * 4 : (dr_state <= 5 ? (20 + dr_state - 1) * 4 : 25 * 4); v = (dr_state == 6) ? 1 : 0; }
        else { wr = (cf_cur.kind == 0); a = cf_cur.addr; v = cf_cur.val; }
        fprintf(tr, "CFG %llu %llu %c %u %u %u %u %d\n", (unsigned long long)cf_t_req, (unsigned long long)cyc, wr ? 'W' : 'R', a & 0xFF, v, (unsigned)top->cfg_rsp_error, (unsigned)top->cfg_rsp_rdata, cf_cur.priv);
        if (cf_cur.kind == 2) {
          uint32_t rd = top->cfg_rsp_rdata;
          if (dr_state == 0) { dr_cnt = rd & 0xFF; if (dr_cnt == 0) { cf_act = false; } else { dr_state = 1; cf_wait = false; } }
          else if (dr_state <= 5) { dr_w[dr_state] = rd; dr_state++; cf_wait = false; }
          else {   // POP done: dr_w[1..5] = W0 W1 W2 W3 SEQ of the record just removed
            fprintf(tr, "FLG %llu %u %u %u %u %u %u %llu %u\n", (unsigned long long)cyc, dr_w[5], dr_w[1] & 0xF, (dr_w[1] >> 4) & 3, (dr_w[1] >> 6) & 1, (dr_w[1] >> 8) & 0xFF, (dr_w[1] >> 16) & 0xFFFF,
                    ((unsigned long long)dr_w[3] << 32) | dr_w[2], dr_w[4]);
            dr_state = 0; cf_wait = false;                  // re-read the count: loop until the log is empty
          }
        } else { cf_act = false; }
        if (!cf_act) n_cfg_done++;
      }
    }

    top->clk = 1; top->eval();
    cyc++;

    // ------------------------------------------------ termination
    bool tracks_done = (rq_i >= reqs.size()) && !rq_pres && outstanding == 0 && cf_i >= cfgs.size() && !cf_act && pk_i >= pokes.size() && rs_i >= resets.size();
    if (end_t && cyc >= end_t && tracks_done) break;
    if (!end_t && tracks_done) { if (++idle_after > 200) break; } else idle_after = 0;
  }
  if (cyc >= HARD_LIMIT) {
    char m[600];
    snprintf(m, sizeof m, "HARD CYCLE LIMIT: the design or the scenario hung [rq_i=%zu/%zu pres=%d out=%d cf_i=%zu/%zu act=%d wait=%d pk_i=%zu/%zu rs_i=%zu done: req=%ld inv=%ld cfg=%ld frs=%ld acc=%ld; "
             "dut: req_ready=%d rsp_valid=%d cfg_rsp_valid=%d inv_done_evt=%d]",
             rq_i, reqs.size(), (int)rq_pres, outstanding, cf_i, cfgs.size(), (int)cf_act, (int)cf_wait, pk_i, pokes.size(), rs_i, n_req_done, n_inv, n_cfg_done, n_frs, n_acc,
             (int)top->req_ready, (int)top->rsp_valid, (int)top->cfg_rsp_valid, (int)top->inv_done_evt);
    fail(m);
  }
  fprintf(tr, "END %llu\n", (unsigned long long)cyc);
  fclose(tr);
  top->final(); delete top;
  if (fails) { fprintf(stderr, "bench monitors: %d failure(s)\n", fails); return 2; }
  return 0;
}
