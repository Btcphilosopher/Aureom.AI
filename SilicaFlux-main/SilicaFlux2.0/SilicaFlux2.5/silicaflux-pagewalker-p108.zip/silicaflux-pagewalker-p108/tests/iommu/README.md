# tests/iommu — simulation and the independent oracle

```
 gen_scenarios.py ──> scenario (.scn) ──> tb_pagewalker.cpp (Verilator bench) ──> trace ──> check_trace.py  (+ ref_model.py)
   page-table forests,       stimulus, SFB2 memory model,          every handshake,          the JUDGE: written from docs/01,
   directed + random         protocol monitors, CSR master         pokes, resets, events     shares no code with the RTL
```

| file | role |
|---|---|
| `ref_model.py` | **independent reference model** (Sv39 PTE classification, the walk, static checks, page split, an exact LRU TLB). Written from `docs/01_SPEC_SUBSET.md`. |
| `check_trace.py` | the oracle: replays every walk against the reads the DUT made, predicts hit / miss with the LRU model, checks refusals, ordering, CSR contract, fault log, counters |
| `tb_pagewalker.cpp` | the bench: no translation logic — stimulus, memory, monitors, trace |
| `gen_scenarios.py` | scenario generator: 18 directed scenarios + a random / adversarial generator |

## What the checker proves per request (strictly in order)

`S` static refusals (and **no fabric read at all**) · `T` exact TLB behaviour (a predicted hit must not read; a predicted miss must walk; a hit returns the last fill) ·
`W` every fabric read is exactly what the Sv39 algorithm demands from the data the DUT received (addresses, order, retries) · `R` response structure (ids, `rsp_pa = 0` on refusal, segments, `last`) ·
`L` bounded latency / timeout-vs-wedge timing · `C` every CSR response against the register model · `I` no request accepted while a command is pending; completion only after the drain and with `dma_quiet` ·
`F` fault-log records and registers (FIFO model, drops, sequence numbers) · `P` performance counters equal the counters derived from the trace.

## Scenario grammar (one command per line, `#` comments; the first line is `#meta {json}`)

```
mem32 ADDR VAL                    initial memory word          memerr LO HI       reads in [LO,HI) return a bus error
req   T DEV CV CD WR IOVA BYTES ID [gates]       a translation request (CV/CD = the descriptor's claim)
cfg   T w|r|wu|ru ADDR VAL [gates]               a CSR access (u = unprivileged)       fdrain T [gates]   drain the fault log
poke  T ADDR VAL [gates]          write one memory word at an exact cycle   poke64 T ADDR LO HI [gates]  atomic 64-bit store
reset T LEN [gates] @setinv=N     assert reset   quiet T V   dma_quiet   rspmode T M   memlat T MIN MAX   memhang T M (1 accept-but-silent, 2 not even accepting)
gates:  @req=n (n requests answered)  @inv=k (k completions)  @cfg=m  @frs=k (fabric responses)  @acc=n (requests accepted)  @rfrs=k (responses since the last accepted request)
        @rst=k (after the k-th reset)  @pk=n (n pokes applied)  @dly=d (+d cycles after the gates open)
```

Program order is the generator's default (a request waits for earlier CSR accesses and expected completions, etc.); overlap is requested with explicit gates.

## Trace format

`REQ cyc id dev cv cd wr iova bytes` · `RSPV cyc id` (first cycle `rsp_valid` is high) · `RSP cyc id ok fault pa bytes last` · `FRQ cyc addr` / `FRS cyc addr data err` (page-table read accepted / answered) ·
`CFG cyc_req cyc_rsp W|R addr wdata err rdata priv` · `INV cyc status` · `POKE cyc addr val` · `RST cyc` · `QUIET`, `HANG`, `ST` (stall snapshots), `FLG` (a drained fault record).

## Reading a failure

`check_trace.py TRACE --verbose` prints `cycle N: <what> ...`. Re-run the failing scenario with `P108_KEEP=1 scripts/regress.py --only NAME` to keep the trace, then look at the events around that cycle.
