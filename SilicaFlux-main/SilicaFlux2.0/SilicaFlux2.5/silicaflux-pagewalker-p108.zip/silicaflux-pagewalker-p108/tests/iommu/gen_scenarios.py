#!/usr/bin/env python3
"""
Scenario generator for the P108 system bench.   gen_scenarios.py OUTDIR [--seed N] [--random N]

Builds Sv39 page-table forests in a sparse memory image and writes scenario files (grammar: tb_pagewalker.cpp) plus a `#meta` JSON line
read by the runner.  Program order is the DEFAULT ordering: a request waits for every earlier CSR access and every expected completion; a CSR
access waits for every earlier request; a poke waits for both.  Scenarios that want overlap pass an explicit gate.
The generator decides nothing about correctness: expectations come from the independent oracle (check_trace.py / ref_model.py), except the
explicit race-set claims (`race_allowed`), which are statements of docs/01 section 9.
"""
import argparse, json, os, random, sys

M32 = 0xFFFFFFFF
PAGE = 4096
V, R_, W_, X_, U, G, A, D = 1, 2, 4, 8, 16, 32, 64, 128
RW = V | R_ | W_ | U | A | D
RO = V | R_ | U | A
TBL_BASE = 0x0010_0000
DATA_BASE = 0x0100_0000
MEM_BYTES = 64 << 20
NCTX = 4                      # contexts of the configuration under test (set_params)
DEVW = 4


def set_params(P):
    global NCTX, DEVW
    NCTX, DEVW = P.NUM_CTX, P.DEV_W

# CSR byte addresses
def CSR(i): return i * 4
(C_ID, C_VERSION, C_CTRL, C_STATUS, C_STATE, C_DRAIN_TMO, C_INV_CTX, C_INV_VA_LO, C_INV_VA_HI, C_INV_CMD, C_INV_STAT, C_CTX_SEL,
 C_CTX_ROOT_LO, C_CTX_ROOT_HI, C_CTX_ATTR, C_CTX_CMD, C_CTX_RD_LO, C_CTX_RD_HI, C_CTX_RD_ATTR, C_FLOG_CNT, C_FLOG_W0, C_FLOG_W1, C_FLOG_W2,
 C_FLOG_W3, C_FLOG_SEQ, C_FLOG_POP, C_CNT_SEL, C_CNT_DATA, C_NCNT, C_CAPS, C_CAPS2) = [i * 4 for i in range(31)]


def mkpte(ppn, flags, rsv=0, rsw=0):
    return (rsv << 54) | (ppn << 10) | (rsw << 8) | flags


class Alloc(object):
    def __init__(self, base=TBL_BASE):
        self.t = base
        self.d = DATA_BASE

    def table(self):
        a = self.t
        self.t += PAGE
        assert a < DATA_BASE
        return a

    def data(self, n=1):
        a = self.d
        self.d += PAGE * n
        assert self.d < MEM_BYTES
        return a


class Sc(object):
    def __init__(self, name, **meta):
        self.name = name
        self.meta = dict(meta)
        self.w = {}                  # 32-bit word memory image: byte addr -> value
        self.errs = []
        self.al = Alloc()
        self.lines = []              # body lines in program order
        self.n_cfg = self.n_req = self.n_inv = self.n_rst = self.n_poke = 0
        self.rid = 0
        self.races = {}

    # ------------------------------------------------------------------ memory image
    def w64(self, a, v):
        self.w[a] = v & M32
        self.w[a + 4] = (v >> 32) & M32

    def r64(self, a):
        return self.w.get(a, 0) | (self.w.get(a + 4, 0) << 32)

    def root(self):
        return self.al.table()

    def map4k(self, root, iova, pa, flags=RW, leaf_override=None):
        vpn = (iova >> 12) & ((1 << 27) - 1)
        i2, i1, i0 = vpn >> 18, (vpn >> 9) & 0x1FF, vpn & 0x1FF
        t = root
        for idx in (i2, i1):
            e = self.r64(t + idx * 8)
            if not (e & V) or (e & (R_ | W_ | X_)):
                nt = self.al.table()
                self.w64(t + idx * 8, mkpte(nt >> 12, V))
                t = nt
            else:
                t = ((e >> 10) & ((1 << 44) - 1)) << 12
        pte = mkpte(pa >> 12, flags) if leaf_override is None else leaf_override
        self.w64(t + i0 * 8, pte)
        return t + i0 * 8                                     # address of the leaf PTE

    def pte_addr(self, root, iova, level=0):
        """address of the PTE at `level` for iova (follows existing pointers)"""
        vpn = (iova >> 12) & ((1 << 27) - 1)
        idx = [vpn & 0x1FF, (vpn >> 9) & 0x1FF, vpn >> 18]
        t = root
        for lv in (2, 1, 0):
            a = t + idx[lv] * 8
            if lv == level:
                return a
            t = ((self.r64(a) >> 10) & ((1 << 44) - 1)) << 12
        return None

    # ------------------------------------------------------------------ environment
    def env(self, line):
        self.lines.append(line)

    def memerr(self, lo, hi):
        self.errs.append((lo, hi))

    # ------------------------------------------------------------------ CSR / commands
    def rg(self):
        """gate fragment: after the last reset issued so far"""
        return ((" @rst=%d" % self.n_rst) if self.n_rst else "") + ((" @pk=%d" % self.n_poke) if self.n_poke else "")

    def reset(self, length, gate):
        """a reset at the point named by `gate`; everything issued afterwards is ordered after it"""
        self.lines.append("reset 0 %d %s @setinv=%d" % (length, gate, self.n_inv))
        self.n_rst += 1

    def _cfg_gate(self, gate):
        if gate is not None:
            return gate
        return "@req=%d @inv=%d%s" % (self.n_req, self.n_inv, self.rg())

    def cfg(self, op, addr, val=0, gate=None, t=0):
        self.lines.append("cfg %d %s %d %d %s" % (t, op, addr, val, self._cfg_gate(gate)))
        self.n_cfg += 1

    def ctx_set(self, idx, root_pa, r=1, w=1, mode=1, ok=True, gate=None, hi=0, extra_attr=0):
        ok = ok and idx < NCTX                                      # an out-of-range context is refused (CE_INDEX): no completion
        self.cfg("w", C_CTX_SEL, idx, gate)
        g = "@cfg=%d" % (self.n_cfg) if gate is None else gate
        self.cfg("w", C_CTX_ROOT_LO, (root_pa >> 12) & M32, g)
        self.cfg("w", C_CTX_ROOT_HI, hi | ((root_pa >> 44) & 0xFFF), g)
        self.cfg("w", C_CTX_ATTR, (mode << 2) | (w << 1) | r | extra_attr, g)
        self.cfg("w", C_CTX_CMD, 1, g)
        if ok:
            self.n_inv += 1

    def ctx_clear(self, idx, ok=True, gate=None):
        ok = ok and idx < NCTX
        self.cfg("w", C_CTX_SEL, idx, gate)
        self.cfg("w", C_CTX_CMD, 2, "@cfg=%d" % self.n_cfg if gate is None else gate)
        if ok:
            self.n_inv += 1

    def inv(self, kind, ctx=0, iova=0, ok=True, gate=None):
        if kind in ("ctx", "page") and ctx >= NCTX:
            ok = False
        if kind == "page":
            top = (iova >> 38) & ((1 << 26) - 1)
            if top not in (0, (1 << 26) - 1):                      # a non-canonical address is refused (CE_RANGE): no completion
                ok = False
        if kind in ("ctx", "page"):
            self.cfg("w", C_INV_CTX, ctx, gate)
        if kind == "page":
            self.cfg("w", C_INV_VA_LO, iova & M32, "@cfg=%d" % self.n_cfg if gate is None else gate)
            self.cfg("w", C_INV_VA_HI, (iova >> 32) & M32, "@cfg=%d" % self.n_cfg if gate is None else gate)
        if kind == "all":
            self.cfg("w", C_INV_CMD, 1, gate)                      # no staging write precedes: default (program-order) gate
        else:
            self.cfg("w", C_INV_CMD, {"ctx": 2, "page": 3}[kind], "@cfg=%d" % self.n_cfg if gate is None else gate)
        if ok:
            self.n_inv += 1

    def fdrain(self, gate=None):
        self.lines.append("fdrain 0 %s" % self._cfg_gate(gate))
        self.n_cfg += 1

    def counters(self, idxs=range(41)):
        for i in idxs:
            self.cfg("w", C_CNT_SEL, i)
            self.cfg("r", C_CNT_DATA, 0, "@cfg=%d" % self.n_cfg)

    def csr_dump(self, gate=None):
        for a in (C_ID, C_VERSION, C_CTRL, C_STATUS, C_STATE, C_DRAIN_TMO, C_INV_STAT, C_CAPS, C_CAPS2, C_NCNT):
            self.cfg("r", a, 0, gate)

    # ------------------------------------------------------------------ requests / pokes
    def req(self, dev, iova, nbytes, wr=0, cv=0, cd=0, gate=None, t=0, rid=None):
        if rid is None:
            self.rid = (self.rid + 1) & 0xF                        # ID_W = 4: an id is an opaque tag, it repeats
            rid = self.rid
        g = gate if gate is not None else "@cfg=%d @inv=%d%s" % (self.n_cfg, self.n_inv, self.rg())
        self.lines.append("req %d %d %d %d %d 0x%x %d %d %s" % (t, dev, cv, cd, wr, iova & ((1 << 64) - 1), nbytes, rid, g))
        self.n_req += 1
        return rid

    def poke(self, addr, val, gate=None, t=0):
        self.w[addr] = val & M32
        g = gate if gate is not None else "@req=%d @cfg=%d @inv=%d%s" % (self.n_req, self.n_cfg, self.n_inv, self.rg())
        self.lines.append("poke %d 0x%x 0x%x %s" % (t, addr, val & M32, g))
        self.n_poke += 1

    def poke64_bbm(self, addr, newpte, gate=None):
        """break-before-make for a 32-bit fabric (docs/01 section 9): lo (V=0), hi, lo (new)"""
        old = self.r64(addr)
        self.lines.append("poke 0 0x%x 0x%x %s" % (addr, (old & M32) & ~1, gate if gate is not None else "@req=%d @cfg=%d @inv=%d" % (self.n_req, self.n_cfg, self.n_inv)))
        self.lines.append("poke 0 0x%x 0x%x @dly=1" % (addr + 4, (newpte >> 32) & M32))
        self.lines.append("poke 0 0x%x 0x%x @dly=1" % (addr, newpte & M32))
        self.n_poke += 3

    # ------------------------------------------------------------------ output
    def text(self):
        out = ["#meta " + json.dumps(dict(self.meta, race_allowed=self.races), sort_keys=True)]
        for a in sorted(self.w):
            if self.w[a]:
                out.append("mem32 0x%x 0x%x" % (a, self.w[a]))
        for lo, hi in self.errs:
            out.append("memerr 0x%x 0x%x" % (lo, hi))
        out += self.lines
        return "\n".join(out) + "\n"


# ====================================================================================================================== standard setups
def std_contexts(sc, nctx=4):
    """four contexts: 0 RW, 1 RW (other tables), 2 read-only cap, 3 write-only cap."""
    roots = [sc.root() for _ in range(nctx)]
    return roots


def program_contexts(sc, roots, caps=None):
    caps = caps or [(1, 1), (1, 1), (1, 0), (0, 1)]
    for i, r in enumerate(roots):
        sc.ctx_set(i, r, caps[i][0], caps[i][1])


# ====================================================================================================================== directed scenarios
def d_valid(P):
    sc = Sc("d_valid")
    roots = std_contexts(sc)
    pages = {}
    for k in range(8):
        pa = sc.al.data()
        pages[k] = pa
        sc.map4k(roots[0], 0x4000_0000 + k * PAGE, pa)
    # same IOVA in context 1 -> different PA
    pa1 = sc.al.data()
    sc.map4k(roots[1], 0x4000_0000, pa1)
    program_contexts(sc, roots)
    for off, ln in [(0, 1), (0, 4096), (1, 7), (0xFF8, 8), (0xFFF, 1), (16, 64), (0x800, 0x800), (0, 2048)]:
        sc.req(0, 0x4000_0000 + off, ln, 0)
        sc.req(0, 0x4000_0000 + PAGE + off, ln, 1)
    sc.req(1, 0x4000_0000 + 8, 16, 0)
    sc.req(0, 0x4000_0000 + 8, 16, 0)
    # high (negative) canonical addresses
    hi = 0xFFFF_FFC0_0000_0000
    sc.map4k(roots[0], hi + 0x1000, sc.al.data())
    sc.req(0, hi + 0x1010, 32, 0)
    sc.req(0, hi + 0x1010, 32, 1)
    sc.fdrain()
    sc.counters()
    return sc


def d_unmapped(P):
    sc = Sc("d_unmapped")
    roots = std_contexts(sc)
    sc.map4k(roots[0], 0x0000_2000, sc.al.data())
    # V=0 at each level
    sc.map4k(roots[0], 0x0020_0000, sc.al.data())               # makes L2[0] -> L1[0] -> L0 table for vpn1=1
    sc.w64(sc.pte_addr(roots[0], 0x0020_0000, 0), 0)           # L0 entry cleared
    sc.w64(sc.pte_addr(roots[0], 0x0020_0000, 1), 0)           # L1 entry cleared
    sc.map4k(roots[0], 0x8000_0000, sc.al.data())
    sc.w64(sc.pte_addr(roots[0], 0x8000_0000, 2), 0)           # L2 entry cleared
    program_contexts(sc, roots)
    sc.req(0, 0x2000, 16, 0)
    sc.req(0, 0x0020_0000, 16, 0)
    sc.req(0, 0x8000_0000, 16, 0)
    sc.req(0, 0x3000, 16, 0)                                   # never mapped (L0 entry zero)
    sc.req(0, 0x1_0000_0000, 16, 1)                            # L2 index 4 never mapped
    sc.req(0, 0x2000, 16, 0)                                   # still fine afterwards
    sc.fdrain()
    sc.counters()
    return sc


def d_perm(P):
    sc = Sc("d_perm")
    roots = std_contexts(sc)
    r0 = roots[0]
    b = 0x1000_0000
    cases = [("ro", RO), ("rw", RW), ("x_only", V | X_ | U | A | D), ("a0", V | R_ | W_ | U | D), ("d0", V | R_ | W_ | U | A),
             ("u0", V | R_ | W_ | A | D), ("rx", V | R_ | X_ | U | A), ("rwx", RW | X_), ("g", RW | G), ("rsw", None)]
    for i, (nm, fl) in enumerate(cases):
        iova = b + i * PAGE
        if fl is None:
            sc.map4k(r0, iova, sc.al.data(), RW, leaf_override=mkpte(sc.al.data() >> 12, RW, rsw=3))
        else:
            sc.map4k(r0, iova, sc.al.data(), fl)
    # same pages through the read-only context (2) and the write-only context (3)
    for i, (nm, fl) in enumerate(cases):
        sc.map4k(roots[2], b + i * PAGE, sc.al.data(), RW)
        sc.map4k(roots[3], b + i * PAGE, sc.al.data(), RW)
    program_contexts(sc, roots)
    for i in range(len(cases)):
        for wr in (0, 1):
            sc.req(0, b + i * PAGE + 4, 8, wr)
    for i in range(3):
        for wr in (0, 1):
            sc.req(2, b + i * PAGE + 4, 8, wr)                  # direction cap: write refused before any walk
            sc.req(3, b + i * PAGE + 4, 8, wr)
    # a hit on a read-only page, then a write: PERM from the TLB (no new walk)
    sc.req(0, b + 4, 8, 0)
    sc.req(0, b + 4, 8, 1)
    sc.fdrain()
    sc.counters()
    return sc


def d_boundary(P):
    sc = Sc("d_boundary")
    roots = std_contexts(sc)
    r0 = roots[0]
    b = 0x2000_0000
    for k in range(6):
        sc.map4k(r0, b + k * PAGE, sc.al.data(), RW)            # data pages are NOT contiguous in PA order? (allocated increasing: contiguous)
    # make page 2 -> PA discontiguous from page 1
    sc.map4k(r0, b + 2 * PAGE, sc.al.data(8) + 5 * PAGE, RW)
    sc.map4k(r0, b + 6 * PAGE, sc.al.data(), RO)               # read-only page after a writable one
    sc.map4k(r0, b + 8 * PAGE, sc.al.data(), RW)               # page 7 unmapped, page 8 mapped
    program_contexts(sc, roots)
    sc.req(0, b + 0xFF8, 16, 0)                               # crosses 0 -> 1, both mapped
    sc.req(0, b + PAGE + 0xFFF, 2, 1)                         # crosses 1 -> 2 (discontiguous PAs)
    sc.req(0, b + PAGE - 1, 4096, 0)                          # 4096 bytes starting in the last byte: crosses
    sc.req(0, b + 0x1, 4096, 1)                               # 4096 bytes unaligned: crosses
    sc.req(0, b + 0, 4096, 0)                                 # 4096 aligned: ONE page
    sc.req(0, b + 0xFFF, 1, 0)                                # last byte of a page, no crossing
    sc.req(0, b + 0xFFF, 2, 0)                                # one byte crosses
    sc.req(0, b + 5 * PAGE + 0xFF0, 0x20, 1)                  # page 5 (rw) -> page 6 (read-only): write refused, atomically
    sc.req(0, b + 5 * PAGE + 0xFF0, 0x20, 0)                  # read of the same: ok, two segments
    sc.req(0, b + 5 * PAGE + 0xFF0, 0x20, 1)                  # the same write again: now BOTH pages are TLB hits; the second (read-only) one must still be refused
    sc.req(0, b + 5 * PAGE + 0xFF0, 0x20, 1)
    sc.req(0, b + 6 * PAGE + 0xFF0, 0x20, 0)                  # page 6 (ro) -> page 7 (unmapped): second page refused, nothing released
    sc.req(0, b + 7 * PAGE - 8, 16, 0)                        # page 6 -> page 7 again (same refusal, TLB hit on page 6)
    sc.req(0, b + 7 * PAGE + 0xFF0, 0x20, 0)                  # page 7 (unmapped) -> page 8 (mapped): first page refused
    sc.req(0, b + 7 * PAGE - 1, 4097, 0)                      # BAD_REQUEST (> 4096)
    sc.req(0, b, 0, 0)                                        # zero length
    # canonical boundary: last page below the hole, crossing into the hole
    sc.map4k(r0, 0x3F_FFFF_F000, sc.al.data(), RW)
    sc.req(0, 0x3F_FFFF_F000, 16, 0)
    sc.req(0, 0x3F_FFFF_FFF8, 16, 0)                          # crosses into the non-canonical hole
    # top of the 64-bit space
    sc.map4k(r0, 0xFFFF_FFFF_FFFF_F000, sc.al.data(), RW)
    sc.req(0, 0xFFFF_FFFF_FFFF_F000, 4096, 1)                 # exactly the last page: ok
    sc.req(0, 0xFFFF_FFFF_FFFF_F001, 4096, 1)                 # wraps 2**64
    sc.req(0, 0xFFFF_FFFF_FFFF_FFFF, 1, 0)                    # last byte: ok (page mapped)
    sc.req(0, 0xFFFF_FFFF_FFFF_FFFF, 2, 0)                    # wraps
    sc.fdrain()
    sc.counters()
    return sc


def d_multictx(P):
    sc = Sc("d_multictx")
    roots = std_contexts(sc)
    iova = 0x5000_0000
    pas = []
    for i in range(4):
        pa = sc.al.data()
        pas.append(pa)
        sc.map4k(roots[i], iova, pa, RW)
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    for rep in range(2):
        for i in range(4):
            sc.req(i, iova + 8, 8, 0)
    # clear context 1: BAD_CONTEXT, others unaffected (still hit)
    sc.ctx_clear(1)
    sc.req(1, iova + 8, 8, 0)
    sc.req(0, iova + 8, 8, 0)
    sc.req(2, iova + 8, 8, 0)
    # re-program context 1 with context 3's root: no stale entry of the old root may be used
    sc.ctx_set(1, roots[3], 1, 1)
    sc.req(1, iova + 8, 8, 0)
    # change attributes of context 0 to read-only: the write is refused by the direction cap with no walk
    sc.ctx_set(0, roots[0], 1, 0)
    sc.req(0, iova + 8, 8, 1)
    sc.req(0, iova + 8, 8, 0)
    sc.fdrain()
    sc.counters()
    return sc


def d_invalid_pte(P):
    """every reserved / malformed / unsupported PTE form, each on its OWN table path (own L2 slot) so tests cannot disturb each other"""
    sc = Sc("d_invalid_pte")
    roots = std_contexts(sc)
    r0 = roots[0]
    tests = []
    n = [0]
    def path():
        n[0] += 1
        assert n[0] < 250
        return n[0] * (1 << 30) + 0x1000                           # a fresh L2 slot per test: private L1 / L0 tables
    dp = sc.al.data
    tbl = lambda: sc.al.table() >> 12
    def t_leaf(pte):
        iova = path()
        sc.map4k(r0, iova, dp(), RW, leaf_override=pte)
        tests.append(iova)
    def t_ptr(level, pte):
        iova = path()
        sc.map4k(r0, iova, dp(), RW)
        sc.w64(sc.pte_addr(r0, iova, level), pte)
        tests.append(iova)
    # ---- leaf PTE forms (level 0)
    t_leaf(mkpte(dp() >> 12, RW, rsv=1))                        # reserved bit 54
    t_leaf(mkpte(dp() >> 12, RW, rsv=0x200))                    # N bit 63 (Svnapot)
    t_leaf(mkpte(dp() >> 12, RW, rsv=0x180))                    # PBMT bits
    t_leaf(mkpte(dp() >> 12, RW, rsv=0x3FF))                    # every reserved bit
    t_leaf(mkpte(dp() >> 12, V | W_ | U | A | D))               # W without R
    t_leaf(mkpte(dp() >> 12, V | W_ | X_ | U | A | D))          # W without R, with X
    t_leaf(mkpte(1 << 20, RW))                                  # PPN = 2**20: beyond PA_W = 32 -> ADDR_OVERFLOW
    t_leaf(mkpte((1 << 44) - 1, RW))                            # all-ones PPN
    t_leaf(mkpte((1 << 20) - 1, RW))                            # the last legal PPN
    t_leaf(mkpte(0, RW))                                        # PPN 0 is legal
    t_leaf(mkpte(dp() >> 12, 0))                                # V = 0, everything else zero
    t_leaf(mkpte(dp() >> 12, RW & ~V))                          # V = 0 with other bits set: NOT_PRESENT, nothing else is looked at
    t_leaf(mkpte(dp() >> 12, RW, rsv=1) & ~V)                   # V = 0 with reserved bits set: still NOT_PRESENT
    t_leaf(mkpte(dp() >> 12, RW | G | (3 << 8)))                # G and RSW are ignored: a normal leaf
    # ---- pointer-level violations
    t_ptr(2, mkpte(tbl(), V | A))                               # pointer with A
    t_ptr(2, mkpte(tbl(), V | D))                               # pointer with D
    t_ptr(1, mkpte(tbl(), V | U))                               # pointer with U
    t_ptr(1, mkpte(tbl(), V | G))                               # G on a pointer is legal: an empty table -> NOT_PRESENT at level 0
    t_ptr(2, mkpte(tbl(), V, rsw=3))                            # RSW ignored
    t_ptr(2, mkpte(1 << 20, V))                                 # pointer PPN beyond the fabric -> MALFORMED
    t_ptr(1, mkpte((1 << 44) - 1, V))                           # pointer PPN all ones
    t_ptr(2, mkpte(tbl(), V, rsv=1))                            # reserved bit on a pointer
    t_ptr(1, mkpte(tbl(), V | W_))                              # W without R where a pointer was expected
    t_ptr(0, mkpte(tbl(), V))                                   # pointer at the last level: MALFORMED
    t_ptr(0, mkpte(tbl(), V | A))                               # A on a non-leaf: INVALID_PTE takes precedence over MALFORMED
    t_ptr(0, mkpte(tbl(), V | U | A | D))
    # ---- superpage leaves (baseline: PAGE_SIZE, before any other check of the leaf)
    t_ptr(1, mkpte(dp() >> 12, RW))                             # 2 MiB leaf, misaligned
    t_ptr(2, mkpte(dp() >> 12, RW))                             # 1 GiB leaf, misaligned
    t_ptr(1, mkpte(0x400, RW))                                  # aligned 2 MiB leaf
    t_ptr(2, mkpte(0x40000, RW))                                # aligned 1 GiB leaf
    t_ptr(1, mkpte(1 << 20, RW))                                # 2 MiB leaf with PPN beyond PA
    t_ptr(1, mkpte(0x400, V | W_))                              # reserved encoding on a superpage: INVALID_PTE before PAGE_SIZE
    t_ptr(1, mkpte(0x400, V | X_))                              # execute-only superpage
    program_contexts(sc, roots)
    for iova in tests:
        sc.req(0, iova + 8, 8, 0)
        sc.req(0, iova + 8, 8, 1)
    sc.fdrain()
    sc.counters()
    return sc


def d_tlb_repl(P):
    sc = Sc("d_tlb_repl")
    roots = std_contexts(sc)
    r0 = roots[0]
    b = 0x7000_0000
    n = 12
    for k in range(n):
        sc.map4k(r0, b + k * PAGE, sc.al.data(), RW)
        sc.map4k(roots[1], b + k * PAGE, sc.al.data(), RW)
    program_contexts(sc, roots)
    seq = list(range(n)) + list(range(n)) + [0, 1, 2, 3, 0, 1, 2, 3, 4, 0, 1, 5, 2, 6, 0, 3]
    # LRU probes: touch a, add new ones, see which was evicted
    seq += [0, 1, 2, 3, 1, 4, 1, 2, 5, 3, 0]
    for k in seq:
        sc.req(0, b + k * PAGE + 16, 8, k & 1)
    # two contexts competing for the same TLB
    for k in range(6):
        sc.req(0, b + k * PAGE, 8, 0)
        sc.req(1, b + k * PAGE, 8, 0)
    sc.counters()
    return sc


def d_inval(P):
    sc = Sc("d_inval")
    roots = std_contexts(sc)
    r0, r1 = roots[0], roots[1]
    b = 0x1_0000_0000
    pa_old = [sc.al.data() for _ in range(6)]
    pa_new = [sc.al.data() for _ in range(6)]
    leaf = []
    for k in range(6):
        leaf.append(sc.map4k(r0, b + k * PAGE, pa_old[k], RW))
        sc.map4k(r1, b + k * PAGE, sc.al.data(), RW)
    program_contexts(sc, roots)
    for k in range(4):
        sc.req(0, b + k * PAGE + 8, 8, 0)                       # fill 4 entries of context 0
    # remap page 0 and page 1 WITHOUT invalidation: the engine may still return the old translation (stale by contract)
    sc.poke64_bbm(leaf[0], mkpte(pa_new[0] >> 12, RW))
    sc.poke64_bbm(leaf[1], mkpte(pa_new[1] >> 12, RW))
    sc.req(0, b + 8, 8, 0)                                      # hit: old PA
    sc.req(0, b + PAGE + 8, 8, 0)
    # page invalidation of page 0 only: page 0 new, page 1 still old
    sc.inv("page", 0, b)
    sc.req(0, b + 8, 8, 0)
    sc.req(0, b + PAGE + 8, 8, 0)
    # an invalidation of another context does not touch context 0
    sc.inv("ctx", 1)
    sc.req(0, b + PAGE + 8, 8, 0)
    # an invalidation of a different page of the same context does not touch page 1
    sc.inv("page", 0, b + 5 * PAGE)
    sc.req(0, b + PAGE + 8, 8, 0)
    # context invalidation: page 1 now new
    sc.inv("ctx", 0)
    sc.req(0, b + PAGE + 8, 8, 0)
    # unmap page 2 + page 3, then full flush
    for k in (2, 3):
        sc.poke64_bbm(leaf[k], 0)
    sc.req(0, b + 2 * PAGE + 8, 8, 0)                           # stale hit (if still cached)
    sc.inv("all")
    sc.req(0, b + 2 * PAGE + 8, 8, 0)                           # NOT_PRESENT now
    sc.req(0, b + 3 * PAGE + 8, 8, 0)
    # a page invalidation with an address inside the page (not page aligned)
    sc.req(0, b + 4 * PAGE + 8, 8, 0)
    sc.poke64_bbm(leaf[4], mkpte(pa_new[4] >> 12, RW))
    sc.inv("page", 0, b + 4 * PAGE + 0x7FF)
    sc.req(0, b + 4 * PAGE + 8, 8, 0)
    # invalidation commands that must be refused
    sc.cfg("w", C_INV_CTX, NCTX)
    sc.cfg("w", C_INV_CMD, 2, "@cfg=%d" % sc.n_cfg)                # ctx index out of range
    sc.cfg("w", C_INV_CMD, 7, "@cfg=%d" % sc.n_cfg)                # unknown kind
    sc.cfg("w", C_INV_CMD, 0, "@cfg=%d" % sc.n_cfg)
    sc.cfg("w", C_INV_CTX, 0, "@cfg=%d" % sc.n_cfg)
    sc.cfg("w", C_INV_VA_LO, 0, "@cfg=%d" % sc.n_cfg)
    sc.cfg("w", C_INV_VA_HI, 0x0000_0040, "@cfg=%d" % sc.n_cfg)    # IOVA bit 38 set, bits 63:39 clear: non-canonical
    sc.cfg("w", C_INV_CMD, 3, "@cfg=%d" % sc.n_cfg)
    sc.csr_dump("@cfg=%d" % sc.n_cfg)
    sc.fdrain("@cfg=%d" % sc.n_cfg)
    sc.counters()
    return sc


def d_concurrent(P):
    """pipelined requests, back-pressured responses, CSR traffic and commands overlapping translation.  Requests are NOT gated on commands:
    they are presented while a command is pending and the hardware must hold them off; commands are NOT gated on requests: they arrive
    while requests are in the pipeline and must wait for them."""
    sc = Sc("d_concurrent")
    roots = std_contexts(sc)
    b = 0x1_8000_0000
    for k in range(10):
        for i in range(4):
            sc.map4k(roots[i], b + k * PAGE, sc.al.data(), RW)
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    sc.env("rspmode 0 2")                                        # slow, jittery response consumer
    sc.env("memlat 0 1 6")
    rng = random.Random(1)
    def rq(n):
        for i in range(n):
            sc.req(rng.randrange(4), b + rng.randrange(10) * PAGE + rng.randrange(0, 4096, 8), 8 * rng.randrange(1, 40), rng.randrange(2),
                   gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv0))
    sc.n_inv0 = sc.n_inv                                           # requests wait only for the programming above
    rq(24)
    sc.inv("all", gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))   # arrives while requests are in the pipeline
    rq(24)
    sc.inv("ctx", 1, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    rq(12)
    sc.inv("page", 2, b + 3 * PAGE, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    rq(12)
    # CSR reads while translating
    sc.csr_dump("@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    # back-to-back writes: the second command is refused (busy), so are staging writes and context commands issued while one is in progress
    sc.cfg("w", C_INV_CTX, 2, "@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    sc.cfg("w", C_INV_CMD, 2, "@cfg=%d" % sc.n_cfg)
    sc.n_inv += 1
    sc.cfg("w", C_INV_CMD, 1, "@cfg=%d" % sc.n_cfg)                # refused: busy
    sc.cfg("w", C_CTX_CMD, 2, "@cfg=%d" % sc.n_cfg)                # refused: busy
    sc.cfg("w", C_CTX_ROOT_LO, 5, "@cfg=%d" % sc.n_cfg)            # refused: busy
    sc.cfg("w", C_INV_VA_LO, 5, "@cfg=%d" % sc.n_cfg)              # refused: busy
    sc.cfg("w", C_DRAIN_TMO, 7, "@cfg=%d" % sc.n_cfg)              # refused: busy
    sc.n_inv0 = sc.n_inv
    rq(8)
    sc.fdrain("@req=%d @inv=%d" % (sc.n_req, sc.n_inv))
    sc.counters()
    return sc


def d_drain(P):
    """dma_quiet and the drain timeout: a command waits for the DMA; a timeout applies NOTHING"""
    sc = Sc("d_drain")
    roots = std_contexts(sc)
    b = 0x2_0000_0000
    for k in range(4):
        sc.map4k(roots[0], b + k * PAGE, sc.al.data(), RW)
    pa_new = sc.al.data()
    leaf = sc.pte_addr(roots[0], b, 0)
    program_contexts(sc, roots)
    sc.cfg("w", C_DRAIN_TMO, 40)
    sc.req(0, b + 8, 8, 0)
    sc.req(0, b + PAGE + 8, 8, 0)
    sc.poke64_bbm(leaf, mkpte(pa_new >> 12, RW))
    # quiet low for 25 cycles: the command waits (drain < timeout), then completes
    sc.env("quiet 0 0 @req=%d @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv))
    sc.inv("page", 0, b, gate="@req=%d @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv))
    sc.env("quiet 0 1 @cfg=%d @dly=25" % (sc.n_cfg))
    sc.req(0, b + 8, 8, 0)                                        # new PA: the invalidation was applied
    # quiet low for a long time: timeout, NOT applied; the page stays stale
    sc.poke64_bbm(sc.pte_addr(roots[0], b + PAGE, 0), mkpte(pa_new >> 12, RW))
    sc.env("quiet 0 0 @req=%d @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv))
    sc.inv("page", 0, b + PAGE, gate="@req=%d @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv))
    sc.env("quiet 0 1 @cfg=%d @inv=%d @dly=10" % (sc.n_cfg, sc.n_inv))
    sc.req(0, b + PAGE + 8, 8, 0)                                  # still the OLD translation: the timed-out command changed nothing
    # a timed-out CONTEXT command changes nothing either
    sc.env("quiet 0 0 @req=%d @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv))
    sc.ctx_clear(0, gate="@req=%d @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv))
    sc.env("quiet 0 1 @inv=%d @dly=10" % sc.n_inv)
    sc.req(0, b + 2 * PAGE + 8, 8, 0)                              # context 0 still valid
    # the status register and the completion record
    sc.csr_dump("@req=%d @inv=%d" % (sc.n_req, sc.n_inv))
    sc.counters()
    return sc


# ------------------------------------------------------------------------------------------------------------ malicious
def d_malicious(P):
    sc = Sc("d_malicious")
    roots = std_contexts(sc)
    r0 = roots[0]
    b = 0x4_0000_0000
    for k in range(4):
        sc.map4k(r0, b + k * PAGE, sc.al.data(), RW)
        sc.map4k(roots[1], b + k * PAGE, sc.al.data(), RW)
    # an *attacker-controlled* page of memory that looks like a page table: a descriptor can never make the walker use it as a root
    evil = sc.al.table()
    sc.map4k(evil, b, sc.al.data(), RW)
    program_contexts(sc, roots)
    sc.req(0, b + 8, 8, 0)
    # --- descriptor-borne attacks on the request port
    for dev in range(1 << DEVW):
        sc.req(dev, b + 8, 8, 0)                                    # device ids >= NUM_CTX are out of range
    for cd in range(min(8, 1 << DEVW)):
        sc.req(0, b + 8, 8, 0, cv=1, cd=cd)                         # a claim can only be refused: claim 0 matches, others do not
        sc.req(1, b + 8, 8, 0, cv=1, cd=cd)
    for iova, ln in [(0xFFFF_FFFF_FFFF_FFFF, 2), (0xFFFF_FFFF_FFFF_F000, 4097), (0x8000_0000_0000_0000, 16), (0x0000_0040_0000_0000, 8),
                     (0x0000_0080_0000_0000, 8), (0x0001_0000_0000_0000, 8), (0xFFFF_FF80_0000_0000, 8), (0xFFFF_FFBF_FFFF_FFFF, 2),
                     (0x4000_0000_0000_0000, 8), (0xFFFF_FFC0_0000_0000 - 1, 2), (0x3F_FFFF_FFFF, 1), (0x3F_FFFF_FFFF, 2),
                     (b, 4096), (b, 4097), (b, 0xFFFF), (b, 0x1FFF), (b + 1, 4096), (b, 0)]:
        sc.req(0, iova, ln, 0)
        sc.req(0, iova, ln, 1)
    # --- CSR-borne attacks: unprivileged programming must have NO effect and be reported
    sc.cfg("wu", C_CTX_SEL, 2)
    sc.cfg("wu", C_CTX_ROOT_LO, (evil >> 12) & M32, "@cfg=%d" % sc.n_cfg)
    sc.cfg("wu", C_CTX_ATTR, 7, "@cfg=%d" % sc.n_cfg)
    sc.cfg("wu", C_CTX_CMD, 1, "@cfg=%d" % sc.n_cfg)
    sc.cfg("ru", C_CTX_RD_LO, 0, "@cfg=%d" % sc.n_cfg)             # unprivileged read of a root pointer: refused, zero data
    sc.cfg("wu", C_INV_CMD, 1, "@cfg=%d" % sc.n_cfg)
    sc.cfg("wu", C_CTRL, 1 << 31, "@cfg=%d" % sc.n_cfg)
    sc.cfg("ru", C_FLOG_W1, 0, "@cfg=%d" % sc.n_cfg)
    # bad addresses and read-only registers
    for a in (3, 0x7C, 0x80, 0xFC, 0x81, C_ID, C_VERSION, C_STATE, C_CAPS, C_FLOG_W0, C_CNT_DATA):
        sc.cfg("w", a, 0xFFFFFFFF, "@cfg=%d" % sc.n_cfg)
    sc.cfg("r", 0x7C, 0, "@cfg=%d" % sc.n_cfg)
    sc.cfg("r", 0x81, 0, "@cfg=%d" % sc.n_cfg)
    # privileged but invalid context commands
    def try_ctx(sel, root_pages, attr, hi=0, cmd=1):
        sc.cfg("w", C_CTX_SEL, sel, "@cfg=%d" % sc.n_cfg)
        sc.cfg("w", C_CTX_ROOT_LO, root_pages & M32, "@cfg=%d" % sc.n_cfg)
        sc.cfg("w", C_CTX_ROOT_HI, hi, "@cfg=%d" % sc.n_cfg)
        sc.cfg("w", C_CTX_ATTR, attr, "@cfg=%d" % sc.n_cfg)
        sc.cfg("w", C_CTX_CMD, cmd, "@cfg=%d" % sc.n_cfg)
    try_ctx(2, 0x100000, 7)                                         # root PPN 2**20: beyond the fabric
    try_ctx(2, 0x10, 7, hi=1)                                       # PPN above bit 32
    try_ctx(2, 0x10, 7, hi=1 << 12)                                 # reserved HI bits
    try_ctx(2, 0x10, 0x03)                                          # mode 0 (BARE / off): refused
    try_ctx(2, 0x10, 0x0B)                                          # mode 2: reserved
    try_ctx(2, 0x10, 0x0F)                                          # mode 3: reserved
    try_ctx(2, 0x10, 0x17)                                          # reserved attribute bit 4
    try_ctx(2, 0x10, 0x8000_0007)                                   # reserved attribute bit 31
    try_ctx(NCTX + 5, 0x10, 7)                                      # context index out of range
    try_ctx(2, 0x10, 7, cmd=3)                                      # unknown command
    try_ctx(2, 0x10, 7, cmd=0)
    try_ctx(2, 0x10, 7, cmd=0x101)                                  # command word with high bits
    # context 2 must still be what it was: a request through it works, and an attacker's table was never used
    sc.req(2, b + 8, 8, 0, gate="@cfg=%d" % sc.n_cfg)
    sc.req(2, b + 8, 8, 1, gate="@cfg=%d" % sc.n_cfg)               # write refused by the cap (context 2 is read-only)
    # lock: once set, context programming and the drain timeout are frozen, invalidation still works
    sc.cfg("w", C_CTRL, 1 << 31, "@req=%d" % sc.n_req)
    sc.cfg("w", C_CTRL, 0, "@cfg=%d" % sc.n_cfg)                    # LOCK is set-only
    sc.cfg("r", C_CTRL, 0, "@cfg=%d" % sc.n_cfg)
    try_ctx(3, evil >> 12, 7)                                       # refused: locked
    sc.cfg("w", C_CTX_SEL, 0, "@cfg=%d" % sc.n_cfg)
    sc.cfg("w", C_CTX_CMD, 2, "@cfg=%d" % sc.n_cfg)                 # refused: locked (clear)
    sc.cfg("w", C_DRAIN_TMO, 5, "@cfg=%d" % sc.n_cfg)               # refused: locked
    sc.cfg("w", C_INV_CMD, 1, "@cfg=%d" % sc.n_cfg)                 # invalidation: allowed under lock
    sc.n_inv += 1
    sc.req(0, b + 8, 8, 0)
    sc.req(0, b + 8, 8, 1)
    sc.csr_dump()
    sc.fdrain()
    sc.counters()
    return sc


def d_fabric(P):
    """fabric errors at every level of a walk, errors are never cached, and a table beyond the memory"""
    sc = Sc("d_fabric")
    roots = std_contexts(sc)
    r0, r1 = roots[0], roots[1]
    b = 0x6_0000_0000
    ok_iova = b
    sc.map4k(r0, ok_iova, sc.al.data(), RW)
    l0_iova = b + (1 << 21)                                          # own L0 table, shared L1 / L2
    sc.map4k(r0, l0_iova, sc.al.data(), RW)
    l1_iova = b + (1 << 30)                                          # own L1 and L0 tables
    sc.map4k(r0, l1_iova, sc.al.data(), RW)
    sc.map4k(r1, ok_iova, sc.al.data(), RW)                          # context 1: its root page will be poisoned
    far_iova = b + (3 << 21)
    sc.map4k(r0, far_iova, sc.al.data(), RW)
    last_iova = b + (4 << 21)
    sc.map4k(r0, last_iova, sc.al.data(), RW)
    l0_tbl = sc.pte_addr(r0, l0_iova, 0) & ~0xFFF
    l1_tbl = sc.pte_addr(r0, l1_iova, 1) & ~0xFFF
    sc.memerr(l0_tbl, l0_tbl + PAGE)                                  # the L0 table page of l0_iova returns bus errors
    sc.memerr(l1_tbl, l1_tbl + PAGE)                                  # the L1 table page of l1_iova
    sc.memerr(r1, r1 + PAGE)                                          # the root page of context 1
    # an L1 entry pointing to a page beyond the end of the memory (bus error on the next read), and one to the last page (a zero table)
    sc.w64(sc.pte_addr(r0, far_iova, 1), mkpte(MEM_BYTES >> 12, V))
    sc.w64(sc.pte_addr(r0, last_iova, 1), mkpte((MEM_BYTES >> 12) - 1, V))
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    for iova, dev in [(ok_iova, 0), (l0_iova, 0), (l1_iova, 0), (ok_iova, 1), (far_iova, 0), (last_iova, 0), (l0_iova, 0), (ok_iova, 0)]:
        sc.req(dev, iova + 8, 8, 0)
    sc.req(0, l0_iova + 8, 8, 1)                                      # errors are not cached: the refusal repeats, a walk each time
    sc.fdrain()
    sc.counters()
    return sc


def d_reset(P):
    """reset in every interesting state; afterwards NOTHING may survive: contexts, TLB, fault log, lock, counters, a pending command"""
    sc = Sc("d_reset")
    roots = std_contexts(sc)
    b = 0x3_0000_0000
    for k in range(6):
        sc.map4k(roots[0], b + k * PAGE, sc.al.data(), RW)
    def reprogram():
        program_contexts(sc, roots, caps=[(1, 1)] * 4)
    reprogram()
    sc.cfg("w", C_CTRL, 1 | (1 << 31))                              # irq enable + LOCK: both must be cleared by reset
    for k in range(4):
        sc.req(0, b + k * PAGE + 8, 8, 0)
    sc.req(0, 0xDEAD_0000, 8, 0)                                    # a refusal: the fault log holds a record
    sc.cfg("w", C_CNT_SEL, 4)
    # (1) reset in the middle of a walk: the request is lost, no response may appear for it
    sc.req(0, b + 5 * PAGE + 8, 8, 0)
    sc.reset(6, "@acc=%d @rfrs=%d" % (sc.n_req, 1 if P.DW == 64 else 4))
    sc.req(0, b + 8, 8, 0)                                          # BAD_CONTEXT: every context is invalid after reset
    sc.csr_dump("@req=%d @rst=%d" % (sc.n_req, sc.n_rst))
    sc.cfg("r", C_CTRL, 0, "@cfg=%d" % sc.n_cfg)                    # LOCK and IRQ_EN cleared
    sc.cfg("w", C_CNT_SEL, 4, "@cfg=%d" % sc.n_cfg)
    sc.cfg("r", C_CNT_DATA, 0, "@cfg=%d" % sc.n_cfg)
    sc.fdrain("@cfg=%d" % sc.n_cfg)                                 # the fault log was emptied by the reset
    reprogram()
    for k in range(4):
        sc.req(0, b + k * PAGE + 8, 8, 0)                           # must WALK again: the TLB was emptied by the reset
    # (2) reset while a response is held back by the consumer
    sc.env("rspmode 0 3 @req=%d @rst=%d" % (sc.n_req, sc.n_rst))     # the DMA stops accepting responses
    sc.req(0, b + 8, 8, 0)
    sc.reset(4, "@acc=%d @dly=40" % sc.n_req)
    sc.env("rspmode 0 0 @rst=%d" % sc.n_rst)
    reprogram()
    sc.req(0, b + 8, 8, 0)
    # (3) reset while an invalidation waits for the DMA to go quiet (a pending command is lost, nothing is applied)
    sc.env("quiet 0 0 @req=%d @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv))
    sc.inv("all", ok=False, gate="@req=%d @cfg=%d @inv=%d @rst=%d" % (sc.n_req, sc.n_cfg, sc.n_inv, sc.n_rst))
    sc.reset(4, "@cfg=%d @dly=20" % sc.n_cfg)
    sc.env("quiet 0 1 @rst=%d" % sc.n_rst)
    sc.req(0, b + 8, 8, 0)                                          # BAD_CONTEXT again
    reprogram()
    sc.req(0, b + 8, 8, 0)
    sc.fdrain()
    sc.counters()
    return sc


# ------------------------------------------------------------------------------------------------------------ page-table update races
def write_pte(sc, leaf, new, P, how):
    """rewrite the leaf PTE at `leaf` to `new` while a walk may be reading it.
       how = 'bbm'      the protocol of docs/01 section 9 (a 64-bit fabric: one atomic 64-bit store)
             'lo_hi'    VIOLATING: low word first, V never cleared
             'hi_lo'    VIOLATING: high word first"""
    old = sc.r64(leaf)
    gate = "@acc=%d @rfrs=%d @dly=%d" % (sc.n_req, sc.cur_trigger, sc.cur_delay)
    if P.DW == 64:
        sc.lines.append("poke64 0 0x%x 0x%x 0x%x %s" % (leaf, new & M32, new >> 32, gate))
        sc.n_poke += 1
    elif how == "bbm":
        sc.lines.append("poke 0 0x%x 0x%x %s" % (leaf, (old & M32) & ~1, gate))
        sc.lines.append("poke 0 0x%x 0x%x @dly=%d" % (leaf + 4, new >> 32, sc.cur_gap))
        sc.lines.append("poke 0 0x%x 0x%x @dly=%d" % (leaf, new & M32, sc.cur_gap))
        sc.n_poke += 3
    elif how == "lo_hi":
        sc.lines.append("poke 0 0x%x 0x%x %s" % (leaf, new & M32, gate))
        sc.lines.append("poke 0 0x%x 0x%x @dly=%d" % (leaf + 4, new >> 32, sc.cur_gap))
        sc.n_poke += 2
    else:
        sc.lines.append("poke 0 0x%x 0x%x %s" % (leaf + 4, new >> 32, gate))
        sc.lines.append("poke 0 0x%x 0x%x @dly=%d" % (leaf, new & M32, sc.cur_gap))
        sc.n_poke += 2


def d_race(P, how="bbm"):
    """A leaf PTE is rewritten at every possible point of a walk (trigger = fabric responses after the request was accepted, plus a delay
    sweep).  docs/01 section 9: under break-before-make the result is the OLD translation, the NEW one or NOT_PRESENT -- never a mixture;
    after the invalidation completes it is exactly the NEW one."""
    sc = Sc("d_race_%s_dw%d" % (how, P.DW))
    roots = std_contexts(sc)
    r0 = roots[0]
    b = 0x1000_0000
    wide = P.PA_W >= 44                                              # PA bits >= 34 exist: old and new differ in the HIGH word of the PTE
    reads = 3 * (1 if P.DW == 64 else (3 if P.PTE_DOUBLE_READ else 2))
    plan = []
    n = 0
    for k in range(reads + 1):
        for gap in (1, 4):
            for d in range(0, 5):
                n += 1
                iova = b + n * (1 << 30)                             # separate L1 / L0 tables per race
                # PPN[43:22] = PA[55:34] lives in the HIGH word of the PTE: only PA bits >= 34 make old and new differ in the high word
                pa_old = sc.al.data() | ((1 << 34) if wide else 0)
                pa_new = sc.al.data() | ((2 << 34) if wide else 0)
                leaf = sc.map4k(r0, iova, pa_old, RW)
                plan.append((k, d, gap, iova, leaf, pa_old, pa_new))
    assert n < 250
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    for (k, d, gap, iova, leaf, pa_old, pa_new) in plan:
        sc.cur_gap = gap
        rid = sc.req(0, iova + 0x10, 16, 0, gate="@req=%d @cfg=%d @inv=%d @pk=%d" % (sc.n_req, sc.n_cfg, sc.n_inv, sc.n_poke))
        ord1 = sc.n_req - 1                                          # claims are keyed by the request's ORDINAL (ids repeat)
        sc.cur_trigger = k
        sc.cur_delay = d
        write_pte(sc, leaf, mkpte(pa_new >> 12, RW), P, how)
        if how == "bbm":
            sc.races[str(ord1)] = ["pa:%d" % (pa_old + 0x10), "pa:%d" % (pa_new + 0x10), "fault:2", "fault:7"]   # old | new | NOT_PRESENT | unstable
        # after the invalidation the NEW translation, exactly
        sc.inv("page", 0, iova, gate="@req=%d @cfg=%d @inv=%d @pk=%d" % (sc.n_req, sc.n_cfg, sc.n_inv, sc.n_poke))
        sc.req(0, iova + 0x10, 16, 0)
        sc.races[str(sc.n_req - 1)] = ["pa:%d" % (pa_new + 0x10)]
    sc.fdrain()
    sc.counters()
    return sc


def d_timeout(P):
    """small WALK_TMO build: the memory stops answering; the walker times out, wedges, refuses, and recovers"""
    sc = Sc("d_timeout", allow_timeouts=True)
    roots = std_contexts(sc)
    r0 = roots[0]
    b = 0x7_0000_0000
    for k in range(8):
        sc.map4k(r0, b + k * PAGE, sc.al.data(), RW)
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    T = P.WALK_TMO
    sc.req(0, b + 8, 8, 0)                                           # fills one TLB entry
    def seq_gate():
        return "@req=%d @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv)
    # (1) the memory ACCEPTS the first read of a walk but never answers
    sc.env("memhang 0 1 @req=%d" % sc.n_req)
    sc.req(0, b + PAGE + 8, 8, 0, gate=seq_gate())                    # times out after WALK_TMO: PHYS_READ, the port is wedged
    sc.req(0, b + 8, 8, 0, gate="@req=%d" % sc.n_req)                 # a TLB hit still works while wedged
    sc.req(0, b + 2 * PAGE + 8, 8, 0, gate="@req=%d" % sc.n_req)      # a miss is refused at once (wedged): no new read is made
    sc.env("memhang 0 0 @req=%d" % sc.n_req)                          # the memory wakes up: the late response arrives and ends the wedge
    sc.req(0, b + 2 * PAGE + 8, 8, 0, gate="@req=%d @dly=%d" % (sc.n_req, 3 * T))   # normal again
    sc.req(0, b + PAGE + 8, 8, 0)
    # (2) the memory stops ACCEPTING: the read is presented, never taken, the walk times out; the read stays presented (SFB2 R2) and is
    #     taken later, after the memory wakes up: that late transaction must not be mistaken for the next walk's
    sc.env("memhang 0 2 @req=%d" % sc.n_req)
    sc.req(0, b + 3 * PAGE + 8, 8, 0, gate=seq_gate())
    sc.env("memhang 0 0 @req=%d" % sc.n_req)
    sc.req(0, b + 4 * PAGE + 8, 8, 0, gate="@req=%d @dly=%d" % (sc.n_req, 3 * T))
    # (3) the memory stops answering after the first response of a walk (accepted, unanswered at a deeper level)
    sc.env("memhang 0 1 @req=%d" % sc.n_req)
    sc.req(0, 0x7_4000_0000 + 8, 8, 0, gate=seq_gate())
    sc.env("memhang 0 0 @req=%d" % sc.n_req)
    sc.req(0, b + 5 * PAGE + 8, 8, 0, gate="@req=%d @dly=%d" % (sc.n_req, 3 * T))
    # (4) a slow (not hung) memory: latency just below and just above the timeout
    sc.env("memlat 0 %d %d @req=%d" % (T - 8, T - 8, sc.n_req))
    sc.req(0, b + 6 * PAGE + 8, 8, 0, gate=seq_gate())               # slow but in time (beats take T-8 cycles): succeeds
    sc.env("memlat 0 1 3 @req=%d" % sc.n_req)
    sc.fdrain()
    sc.counters()
    return sc


# ====================================================================================================================== random / adversarial
def random_scenario(seed, P, nreq=400):
    """Randomised forests (with corrupted PTEs at every level), hostile descriptors, concurrent commands, PTE rewrites that race the walker,
    context reprogramming, resets.  The generator predicts NOTHING about results; the independent oracle judges every request.  The only
    thing it must get right is the gating bookkeeping (which commands will be accepted), so commands are issued in program order."""
    rng = random.Random(seed)
    sc = Sc("r_%s_%d" % (("dw%d" % P.DW), seed))
    sc.meta["allow_timeouts"] = False
    nctx = max(NCTX, 1)
    roots = [sc.root() for _ in range(max(4, nctx))]
    regions = [0x0000_1000, 0x0020_0000, 0x4000_0000, 0x1_0000_0000, 0x3F_FFFF_0000, 0xFFFF_FFC0_0000_0000, 0xFFFF_FFFF_FFFF_0000, 0x2000_0000]
    mapped = {i: [] for i in range(len(roots))}
    leaves = {}
    BAD_FLAGS = [V | R_ | U | A, V | R_ | W_ | U | D, V | R_ | W_ | A | D, V | X_ | U | A | D, V | W_ | U | A | D, V | R_ | W_ | X_ | U | A | D,
                 RW | G, V | R_ | W_ | U | A]
    def good_flags():
        r = rng.random()
        if r < 0.55: return RW
        if r < 0.75: return RO
        return rng.choice(BAD_FLAGS)
    # --- forests
    for ci in range(len(roots)):
        for _ in range(rng.randrange(10, 40)):
            base = rng.choice(regions)
            iova = base + rng.randrange(0, 64) * PAGE + (rng.randrange(0, 3) << 21 if rng.random() < 0.3 else 0)
            if (iova >> 12) in [(x >> 12) for x in mapped[ci]]:
                continue
            pa = sc.al.data()
            fl = good_flags()
            leaves[(ci, iova)] = sc.map4k(roots[ci], iova, pa, fl)
            mapped[ci].append(iova)
        # corrupt a few PTEs at random levels with random forms
        for _ in range(rng.randrange(0, 5)):
            if not mapped[ci]:
                break
            iova = rng.choice(mapped[ci])
            lvl = rng.choice([0, 0, 1, 2])
            addr = sc.pte_addr(roots[ci], iova, lvl)
            tb = sc.al.table() >> 12
            forms = [mkpte(tb, V | rng.choice([A, D, U, A | D | U])), mkpte(tb, V, rsv=rng.randrange(1, 1024)), mkpte(1 << rng.randrange(20, 44), V),
                     mkpte(sc.al.data() >> 12, rng.choice([RW, RO, V | R_ | U | A | D]) ), mkpte(sc.al.data() >> 12, V | W_ | U | A | D),
                     0, mkpte(tb, V), mkpte(sc.al.data() >> 12, RW, rsv=rng.randrange(1, 1024))]
            sc.w64(addr, rng.choice(forms))
    program_contexts(sc, roots, caps=[rng.choice([(1, 1), (1, 1), (1, 0), (0, 1)]) for _ in roots])
    sc.cfg("w", C_DRAIN_TMO, rng.choice([8, 30, 300]))
    sc.env("memlat 0 %d %d" % (1, rng.choice([1, 3, 6])))
    sc.env("rspmode 0 %d" % rng.choice([0, 1, 2]))
    ws = {ci: [rng.choice(mapped[ci]) for _ in range(6)] if mapped[ci] else [0x1000] for ci in range(len(roots))}
    def pick_request():
        r = rng.random()
        ci = rng.randrange(len(roots))
        dev = ci if rng.random() < 0.88 else rng.randrange(1 << DEVW)
        cv = 1 if rng.random() < 0.06 else 0
        cd = dev if rng.random() < 0.5 else rng.randrange(1 << DEVW)
        wr = 1 if rng.random() < 0.4 else 0
        if r < 0.50:
            base = rng.choice(ws[ci]) if rng.random() < 0.7 else rng.choice(mapped[ci] or [0x1000])
            iova = base + rng.randrange(0, PAGE)
        elif r < 0.65:
            base = rng.choice(mapped[ci] or [0x1000])
            iova = base + rng.choice([-1, 1, -2, 2, 512, -512]) * PAGE + rng.randrange(0, PAGE)
        elif r < 0.78:
            iova = rng.choice(regions) + rng.randrange(0, 256) * PAGE + rng.randrange(0, PAGE)
        elif r < 0.84:
            iova = rng.getrandbits(64)
        elif r < 0.90:
            iova = ((1 << 64) - rng.randrange(1, 9000)) & ((1 << 64) - 1)
        elif r < 0.95:
            iova = (rng.getrandbits(26) << 38) | rng.getrandbits(38)
        else:
            iova = rng.choice([0x3F_FFFF_F000, 0x3F_FFFF_FFF0, 0x4000_0000_0000, 0xFFFF_FFBF_FFFF_F000, 0xFFFF_FFC0_0000_0000 - 8])
        q = rng.random()
        if q < 0.55:   ln = rng.randrange(1, 65)
        elif q < 0.75: ln = rng.randrange(1, 600)
        elif q < 0.88: ln = rng.randrange(3000, 4097)
        elif q < 0.94: ln = 4096
        elif q < 0.97: ln = rng.randrange(4097, 8192)
        else:          ln = rng.choice([0, 1, 4095, 4097])
        return dev, iova & ((1 << 64) - 1), ln, wr, cv, cd
    last_inv_cmds = 0
    for n in range(nreq):
        r = rng.random()
        if r < 0.060:
            # an invalidation in program order
            kind = rng.choice(["all", "ctx", "page", "page", "page"])
            ci = rng.randrange(len(roots))
            iova = rng.choice(mapped[ci] or [0x1000]) + rng.randrange(PAGE) if kind == "page" else 0
            sc.inv(kind, ci, iova, gate="@req=%d @cfg=%d @inv=%d%s" % (sc.n_req if rng.random() < 0.5 else max(0, sc.n_req - rng.randrange(0, 3)), sc.n_cfg, sc.n_inv, sc.rg()))
        elif r < 0.085:
            ci = rng.randrange(len(roots))
            if rng.random() < 0.5:
                sc.ctx_set(ci, roots[rng.randrange(len(roots))], *rng.choice([(1, 1), (1, 0), (0, 1), (1, 1)]))
            else:
                sc.ctx_clear(ci)
                if rng.random() < 0.8:
                    sc.ctx_set(ci, roots[ci], 1, 1)
        elif r < 0.115:
            # rewrite a leaf PTE (page-table update), with or without the break-before-make protocol, sometimes racing the walker
            ci = rng.randrange(len(roots))
            if mapped[ci]:
                iova = rng.choice(mapped[ci])
                leaf = sc.pte_addr(roots[ci], iova, 0)
                if leaf is None:
                    continue
                new = mkpte(sc.al.data() >> 12 if rng.random() < 0.8 else rng.getrandbits(20), rng.choice([RW, RO, RW, V | R_ | W_ | U | A, 0]))
                if rng.random() < 0.2:
                    new |= rng.getrandbits(10) << 54
                how = rng.random()
                sc.cur_trigger = 0
                racing = rng.random() < 0.5
                gate = ("@acc=%d @dly=%d%s" % (sc.n_req, rng.randrange(0, 25), sc.rg())) if racing and sc.n_req else None
                if how < 0.35 and P.DW == 32:
                    old = sc.r64(leaf)
                    sc.poke(leaf, old & M32 & ~1, gate); sc.lines.append("poke 0 0x%x 0x%x @dly=%d" % (leaf + 4, new >> 32, rng.randrange(0, 6))); sc.lines.append("poke 0 0x%x 0x%x @dly=%d" % (leaf, new & M32, rng.randrange(0, 6)))
                    sc.n_poke += 2; sc.w[leaf + 4] = new >> 32; sc.w[leaf] = new & M32
                elif how < 0.7:
                    if P.DW == 64:
                        sc.lines.append("poke64 0 0x%x 0x%x 0x%x %s" % (leaf, new & M32, new >> 32, gate or "@req=%d @cfg=%d @inv=%d%s" % (sc.n_req, sc.n_cfg, sc.n_inv, sc.rg())))
                        sc.n_poke += 1
                    else:
                        first, second = (leaf, leaf + 4) if rng.random() < 0.5 else (leaf + 4, leaf)
                        v1, v2 = (new & M32, new >> 32) if first == leaf else (new >> 32, new & M32)
                        sc.poke(first, v1, gate); sc.lines.append("poke 0 0x%x 0x%x @dly=%d" % (second, v2, rng.randrange(0, 8))); sc.n_poke += 1
                    sc.w64(leaf, new)
                else:
                    sc.poke(leaf, new & M32, gate)
                    if P.DW == 32:
                        sc.poke(leaf + 4, new >> 32, "@req=%d @cfg=%d @inv=%d%s" % (sc.n_req, sc.n_cfg, sc.n_inv, sc.rg()))
        elif r < 0.135:
            sc.csr_dump("@cfg=%d%s" % (sc.n_cfg, sc.rg()))
            sc.cfg("r", C_CTX_RD_ATTR, 0, "@cfg=%d%s" % (sc.n_cfg, sc.rg()))
            sc.cfg("w", C_CTX_SEL, rng.randrange(0, 12), "@cfg=%d%s" % (sc.n_cfg, sc.rg()))
            sc.cfg("r", C_CTX_RD_LO, 0, "@cfg=%d%s" % (sc.n_cfg, sc.rg()))
            sc.cfg("r", C_CTX_RD_ATTR, 0, "@cfg=%d%s" % (sc.n_cfg, sc.rg()))
        elif r < 0.155:
            sc.fdrain("@cfg=%d%s" % (sc.n_cfg, sc.rg()))
        elif r < 0.165:
            # an unprivileged access or a bad address (never a command write): refused, no effect
            sc.cfg(rng.choice(["wu", "ru", "r"]), rng.choice([4 * i for i in range(0, 31)] + [3, 0x80, 0xFC]), rng.getrandbits(32), "@cfg=%d @inv=%d%s" % (sc.n_cfg, sc.n_inv, sc.rg()))
        elif r < 0.172:
            sc.env("quiet 0 %d @cfg=%d @inv=%d%s" % (rng.choice([0, 1]), sc.n_cfg, sc.n_inv, sc.rg()))
            sc.env("quiet 0 1 @cfg=%d @inv=%d%s @dly=%d" % (sc.n_cfg, sc.n_inv, sc.rg(), rng.randrange(5, 60)))
        elif r < 0.178:
            sc.env("rspmode 0 %d @acc=%d%s" % (rng.choice([0, 1, 2]), sc.n_req, sc.rg()))
            sc.env("memlat 0 %d %d @acc=%d%s" % (1, rng.choice([1, 2, 5, 9]), sc.n_req, sc.rg()))
        elif r < 0.181 and nreq > 100:
            sc.reset(rng.randrange(2, 8), "@cfg=%d @inv=%d @acc=%d @dly=%d%s" % (sc.n_cfg, sc.n_inv, max(sc.n_req, 1), rng.randrange(0, 30), sc.rg()))
            sc.cfg("w", C_DRAIN_TMO, 300, "@rst=%d" % sc.n_rst)
            program_contexts(sc, roots, caps=[(1, 1)] * len(roots))
            sc.env("quiet 0 1 @rst=%d" % sc.n_rst)
        else:
            dev, iova, ln, wr, cv, cd = pick_request()
            # most requests are gated only on the previous CSR traffic (they overlap commands); some wait for everything
            if rng.random() < 0.7:
                sc.req(dev, iova, ln, wr, cv, cd, gate="@cfg=%d @inv=%d%s" % (sc.n_cfg, sc.n_inv, sc.rg()))
            else:
                sc.req(dev, iova, ln, wr, cv, cd)
    sc.fdrain("@req=%d @inv=%d%s" % (sc.n_req, sc.n_inv, sc.rg()))
    sc.counters()
    return sc


def d_inval_ctx(P):
    """invalidation SELECTIVITY: the same IOVA cached in two contexts; invalidating one context's page must not touch the other's"""
    sc = Sc("d_inval_ctx")
    roots = std_contexts(sc)
    b = 0x1_4000_0000
    for k in range(3):
        for i in range(4):
            sc.map4k(roots[i], b + k * PAGE, sc.al.data(), RW)
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    for k in range(2):
        for i in range(min(2, NCTX)):
            sc.req(i, b + k * PAGE + 8, 8, 0)                       # 4 entries: (ctx0,p0) (ctx1,p0) (ctx0,p1) (ctx1,p1)
    sc.inv("page", 0, b)                                            # drops (ctx0,p0) only
    sc.req(min(1, NCTX - 1) if NCTX > 1 else 0, b + 8, 8, 0)         # (ctx1,p0) must still HIT
    sc.req(0, b + PAGE + 8, 8, 0)                                   # (ctx0,p1) must still HIT
    sc.req(0, b + 8, 8, 0)                                          # (ctx0,p0): miss, walk
    sc.inv("ctx", 0)                                                # drops every ctx0 entry, no ctx1 entry
    sc.req(min(1, NCTX - 1) if NCTX > 1 else 0, b + PAGE + 8, 8, 0)  # (ctx1,p1) must still HIT
    sc.req(0, b + PAGE + 8, 8, 0)
    sc.inv("page", 1, b + PAGE)
    sc.req(0, b + PAGE + 8, 8, 0)                                   # (ctx0,p1) was refilled just above: must still HIT after ctx1's page invalidation
    sc.counters()
    return sc


def d_status(P):
    """every refusal class sets its sticky flag; STATUS is write-1-to-clear; probed while a command is pending (held by dma_quiet)"""
    sc = Sc("d_status")
    roots = std_contexts(sc)
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    sc.cfg("w", C_DRAIN_TMO, 5000)
    sc.env("quiet 0 0 @cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    sc.inv("all", gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))   # pending until the DMA goes quiet
    clr = lambda: sc.cfg("w", C_STATUS, 0xFFFFFFFF, "@cfg=%d" % sc.n_cfg)
    rd = lambda: sc.cfg("r", C_STATUS, 0, "@cfg=%d" % sc.n_cfg)
    clr(); rd()
    sc.cfg("w", C_CTX_SEL, 0, "@cfg=%d" % sc.n_cfg); clr()
    sc.cfg("w", C_CTX_CMD, 2, "@cfg=%d" % sc.n_cfg); rd()           # refused: busy
    clr(); sc.cfg("w", C_INV_CMD, 1, "@cfg=%d" % sc.n_cfg); rd()    # refused: busy
    clr(); sc.cfg("w", C_CTX_ROOT_LO, 5, "@cfg=%d" % sc.n_cfg); rd()  # staging write refused: busy
    clr(); sc.cfg("w", C_INV_CTX, 1, "@cfg=%d" % sc.n_cfg); rd()    # staging write refused: busy
    clr(); sc.cfg("w", C_DRAIN_TMO, 5, "@cfg=%d" % sc.n_cfg); rd()  # refused: busy
    clr(); sc.cfg("wu", C_CTX_CMD, 1, "@cfg=%d" % sc.n_cfg); rd()   # unprivileged: PRIV
    clr(); sc.cfg("w", 0x80, 1, "@cfg=%d" % sc.n_cfg); rd()         # bad address: BADADDR
    clr(); sc.cfg("w", C_ID, 1, "@cfg=%d" % sc.n_cfg); rd()         # read-only register: CMD_ERR only
    clr(); rd()                                                     # cleared: nothing sticky left
    sc.env("quiet 0 1 @cfg=%d @dly=30" % sc.n_cfg)
    sc.cfg("r", C_STATUS, 0, "@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))   # the command completed: INV_DONE
    clr(); rd()
    # lock: LOCKED_REJ
    sc.cfg("w", C_CTRL, 1 << 31, "@cfg=%d" % sc.n_cfg)
    clr(); sc.cfg("w", C_CTX_ROOT_LO, 5, "@cfg=%d" % sc.n_cfg); rd()
    clr(); sc.cfg("w", C_DRAIN_TMO, 9, "@cfg=%d" % sc.n_cfg); rd()
    sc.csr_dump("@cfg=%d" % sc.n_cfg)
    sc.counters()
    return sc


def d_faultlog(P):
    """fault-log corner cases: POP on an empty log, overflow (drop newest, sequence keeps counting), drain, wrap-around of the ring"""
    sc = Sc("d_faultlog")
    roots = std_contexts(sc)
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    sc.cfg("w", C_FLOG_POP, 1, "@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))          # POP on an empty log: no effect
    sc.cfg("w", C_FLOG_POP, 1, "@cfg=%d" % sc.n_cfg)
    sc.cfg("r", C_FLOG_CNT, 0, "@cfg=%d" % sc.n_cfg)
    for rnd in range(3):
        for k in range(9):                                                         # 9 refusals into a 4-deep log: 5 are dropped
            sc.req(0, 0xDEAD_0000 + 0x1000 * k + rnd, 4 + k, k & 1)
        sc.fdrain("@req=%d" % sc.n_req)
    sc.cfg("w", C_FLOG_POP, 1, "@cfg=%d" % sc.n_cfg)
    sc.req(0, 0xBEEF_0000, 4, 0)
    sc.req(0, 0xBEEF_1000, 4, 1)
    sc.fdrain("@req=%d" % sc.n_req)
    sc.cfg("r", C_FLOG_CNT, 0, "@cfg=%d" % sc.n_cfg)
    sc.counters()
    return sc


def d_flap(P):
    """a hostile writer keeps changing the low word of a PTE the walker is reading (violating docs/01 section 9 on purpose).
    The walker must give up after RETRY_MAX re-reads (INVALID_PTE 'unstable'), never loop, never return a mixed translation it did not
    read consistently; the oracle replays every attempt exactly."""
    sc = Sc("d_flap")
    roots = std_contexts(sc)
    r0 = roots[0]
    b = 0x2_8000_0000
    pas = [sc.al.data() for _ in range(4)]
    plan = []
    n = 0
    for k in range(10):
        for per in (1, 2):
            n += 1
            iova = b + n * (1 << 30)
            leaf = sc.map4k(r0, iova, pas[0], RW)
            plan.append((iova, leaf, per, k))
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    rounds = 60
    for (iova, leaf, per, k) in plan:
        sc.req(0, iova + 0x10, 8, 0, gate="@req=%d @cfg=%d @inv=%d @pk=%d" % (sc.n_req, sc.n_cfg, sc.n_inv, sc.n_poke))
        trig = max(0, min(6, 3 + (k % 5)))                          # start flapping before the leaf's low-word read (DW=32: reads 7..9)
        first = True
        for i in range(rounds):
            val = mkpte(pas[i % 4] >> 12, RW) & M32
            g_ = ("@acc=%d @rfrs=%d @dly=%d" % (sc.n_req, trig if P.DW == 32 else 1, k % 3)) if first else "@dly=%d" % per
            sc.lines.append("poke 0 0x%x 0x%x %s" % (leaf, val, g_))
            sc.n_poke += 1
            first = False
        sc.lines.append("poke 0 0x%x 0x%x @dly=1" % (leaf, mkpte(pas[0] >> 12, RW) & M32))      # restore
        sc.n_poke += 1
    sc.fdrain()
    sc.counters()
    return sc


def map_super(sc, root, iova, pa, level, flags=RW):
    """a 2 MiB (level 1) or 1 GiB (level 2) leaf; returns the address of the leaf PTE"""
    vpn = (iova >> 12) & ((1 << 27) - 1)
    i2, i1 = vpn >> 18, (vpn >> 9) & 0x1FF
    if level == 2:
        a = root + i2 * 8
        sc.w64(a, mkpte(pa >> 12, flags))
        return a
    e = sc.r64(root + i2 * 8)
    if not (e & V) or (e & (R_ | W_ | X_)):
        nt = sc.al.table()
        sc.w64(root + i2 * 8, mkpte(nt >> 12, V))
        t = nt
    else:
        t = ((e >> 10) & ((1 << 44) - 1)) << 12
    sc.w64(t + i1 * 8, mkpte(pa >> 12, flags))
    return t + i1 * 8


def d_superpage(P):
    """2 MiB / 1 GiB leaves: one TLB entry serves every page of the superpage; offsets; the overlap rule of the TLB; invalidation scope.
    Meaningful when SUPERPAGE_EN = 1 (otherwise every request below is refused PAGE_SIZE -- also checked by the oracle)."""
    sc = Sc("d_superpage")
    roots = std_contexts(sc)
    r0 = roots[0]
    two_m, one_g = 0x4000_0000, 0x8000_0000
    map_super(sc, r0, two_m, 0x0400_0000, 1)                          # 2 MiB at IOVA 0x4000_0000 -> PA 0x0400_0000
    map_super(sc, r0, two_m + (1 << 21), 0x0420_0000, 1, RO)         # the next 2 MiB: read-only, DIFFERENT physical base (not contiguous with the previous)
    map_super(sc, r0, one_g, 0x4000_0000, 2)                          # 1 GiB at IOVA 0x8000_0000 -> PA 0x4000_0000
    sc.map4k(r0, 0x0000_1000, sc.al.data(), RW)                       # an ordinary page for contrast
    # a 2 MiB region that starts as 4 KiB pages and is later converted to a superpage (stale 4 KiB entries must not survive the fill)
    conv = 0x2000_0000
    for k in range(4):
        sc.map4k(r0, conv + k * PAGE, sc.al.data(), RW)
    conv_l1 = sc.pte_addr(r0, conv, 1)
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    # ---- one entry, many pages
    for k in (0, 1, 2, 7, 100, 511):
        sc.req(0, two_m + k * PAGE + 0x18, 8, k & 1)
    sc.req(0, two_m + 0x1FFFF8, 8, 0)                                  # the last 8 bytes of the 2 MiB page
    sc.req(0, two_m + 0x0FFC, 8, 0)                                    # crosses a 4 KiB boundary INSIDE the superpage: two segments, contiguous PAs
    sc.req(0, two_m + 0x1FFFFC, 8, 0)                                  # crosses the 2 MiB boundary into the read-only superpage (different PA base)
    sc.req(0, two_m + 0x1FFFFC, 8, 1)                                  # ... as a write: the read-only second page refuses the WHOLE request
    sc.req(0, two_m + (1 << 21) + 0x30, 8, 1)                          # write to the read-only superpage
    sc.req(0, two_m + (2 << 21) + 8, 8, 0)                             # the region after: unmapped
    # ---- 1 GiB
    for off in (0, 0x1000, 0x12345678 & ~7, 0x3FFFFFF8):
        sc.req(0, one_g + off, 8, 0)
    sc.req(0, one_g + 0x3FFFFFFC, 8, 0)                                # crosses the 1 GiB boundary (the next 1 GiB is unmapped)
    sc.req(0, one_g + 0x3FFFEFFC, 8, 1)                                # crosses a 4 KiB boundary inside the 1 GiB page
    # ---- invalidation scope
    sc.inv("page", 0, two_m + 0x1234)                                  # any address inside the superpage drops it
    sc.req(0, two_m + 0x40, 8, 0)
    sc.req(0, 0x1010, 8, 0)
    sc.inv("ctx", 0)
    sc.req(0, one_g + 8, 8, 0)
    # ---- conversion: cache two 4 KiB pages, then replace the L1 pointer by a 2 MiB leaf WITHOUT invalidating
    sc.req(0, conv + 0x10, 8, 0)
    sc.req(0, conv + PAGE + 0x10, 8, 0)
    sc.poke64_bbm(conv_l1, mkpte(0x0600_0000 >> 12, RW)) if P.DW == 32 else sc.lines.append("poke64 0 0x%x 0x%x 0x%x @req=%d @cfg=%d @inv=%d" % (conv_l1, mkpte(0x0600_0000 >> 12, RW) & M32, mkpte(0x0600_0000 >> 12, RW) >> 32, sc.n_req, sc.n_cfg, sc.n_inv))
    if P.DW == 64:
        sc.n_poke += 1
    sc.req(0, conv + 2 * PAGE + 0x10, 8, 0)                            # page 2 was never cached: walks the superpage; the fill must drop the stale 4 KiB entries
    sc.req(0, conv + 0x10, 8, 0)                                       # now served by the superpage entry (physical base changed)
    sc.req(0, conv + PAGE + 0x10, 8, 0)
    sc.counters()
    return sc


DIRECTED = [d_valid, d_unmapped, d_perm, d_boundary, d_multictx, d_invalid_pte, d_tlb_repl, d_inval, d_inval_ctx, d_concurrent, d_drain, d_malicious,
            d_fabric, d_reset, d_status, d_faultlog, d_flap, d_superpage]


def write(sc, outdir):
    path = os.path.join(outdir, sc.name + ".scn")
    open(path, "w").write(sc.text())
    return path


def main():
    import ref_model as RM
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("--config", default="base")
    ap.add_argument("--param", action="append", default=[])
    ap.add_argument("--only", action="append", default=[])
    a = ap.parse_args()
    kw = {}
    for p in a.param:
        k, v = p.split("=")
        kw[k] = int(v, 0)
    P = RM.Params(**kw)
    set_params(P)
    os.makedirs(a.outdir, exist_ok=True)
    fns = list(DIRECTED)
    fns += [lambda P: d_race(P, "bbm"), lambda P: d_race(P, "lo_hi"), lambda P: d_race(P, "hi_lo"), d_timeout]
    for f in fns:
        sc = f(P)
        if a.only and not any(o in sc.name for o in a.only):
            continue
        print(write(sc, a.outdir))


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    main()
