#!/usr/bin/env python3
"""
Trace checker for the P108 translation engine: the INDEPENDENT judge of a simulation run.

    check_trace.py TRACE [--meta JSON] [--param NAME=VALUE ...] [--json OUT] [--verbose]

Input: the trace written by tb_pagewalker.cpp -- every handshake of the DMA port, the page-table read port and the CSR port, every memory
poke, every invalidation completion.  The judge is ref_model.py (written from docs/01_SPEC_SUBSET.md) plus the CSR / command contract of
docs/02_INTERFACES.md.  This file never looks inside the RTL and shares no code with it.

Per request, strictly in order:
  S  static refusals -- cause, and NO fabric read at all
  T  an exact LRU TLB model predicts for every page whether the DUT must hit or must walk; a hit returns exactly what the last fill of
     that page returned; a predicted hit that reads, or a predicted miss that does not walk, is an error
  W  every walk is replayed: each fabric read (address, order, retries) must be exactly the read the algorithm of spec section 5 demands
     given the data the DUT had received; the outcome must equal the DUT's response; no extra and no missing reads
  R  response structure: ids, ok/fault exclusivity, pa = 0 on a refusal, segment lengths, offsets, `last`, atomicity of a two-page request
  L  bounded latency; first-valid latency accumulated for the counter cross-check; a timeout takes >= WALK_TMO, a wedge refusal is immediate
Per CSR access / command:
  C  every response (error flag, read value) against the register model; command acceptance predicted from the rules of docs/02 and
     matched against the completion events (accepted <=> exactly one completion)
  I  no request accepted between acceptance and completion; completion only after the last response of every earlier request and with
     dma_quiet high; a timed-out command changes nothing; a completed command takes effect for every later request
  F  fault log: every record equals the refusal it names (sequence number = index in the refusal stream of the epoch)
  P  performance counters read while quiescent equal the counters derived from the trace
Exit status 0 = no violation.
"""
import argparse, bisect, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ref_model as R
from ref_model import (NONE, BAD_CONTEXT, NOT_PRESENT, PERM, MALFORMED, PAGE_SIZE, PHYS_READ, INVALID_PTE, ADDR_OVERFLOW, NONCANONICAL,
                       BAD_REQUEST, FAULT_NAMES)

# ---- CSR indices (docs/02_INTERFACES.md)
(R_ID, R_VERSION, R_CTRL, R_STATUS, R_STATE, R_DRAIN_TMO, R_INV_CTX, R_INV_VA_LO, R_INV_VA_HI, R_INV_CMD, R_INV_STAT, R_CTX_SEL,
 R_CTX_ROOT_LO, R_CTX_ROOT_HI, R_CTX_ATTR, R_CTX_CMD, R_CTX_RD_LO, R_CTX_RD_HI, R_CTX_RD_ATTR, R_FLOG_CNT, R_FLOG_W0, R_FLOG_W1, R_FLOG_W2,
 R_FLOG_W3, R_FLOG_SEQ, R_FLOG_POP, R_CNT_SEL, R_CNT_DATA, R_NCNT, R_CAPS, R_CAPS2) = range(31)
NREG = 31
RO_REGS = {R_ID, R_VERSION, R_STATE, R_INV_STAT, R_CTX_RD_LO, R_CTX_RD_HI, R_CTX_RD_ATTR, R_FLOG_CNT, R_FLOG_W0, R_FLOG_W1, R_FLOG_W2,
           R_FLOG_W3, R_FLOG_SEQ, R_CNT_DATA, R_NCNT, R_CAPS, R_CAPS2}
WO_REGS = {R_INV_CMD, R_CTX_CMD, R_FLOG_POP}
# STATUS sticky bits (bit numbers of the STATUS register)
ST_INV_DONE, ST_INV_TMO, ST_CMD_ERR, ST_PRIV, ST_LOCKED_REJ, ST_BADADDR = 1, 2, 3, 4, 5, 6
STATUS_MODELLED = (1 << ST_INV_DONE) | (1 << ST_INV_TMO) | (1 << ST_CMD_ERR) | (1 << ST_PRIV) | (1 << ST_LOCKED_REJ) | (1 << ST_BADADDR)

# ---- performance counter indices
(CN_REQS, CN_SEGS, CN_TLB_HIT, CN_TLB_MISS, CN_WALKS, CN_WALK_CYC, CN_WALK_REFS, CN_WALK_FAULT, CN_WALK_MAX, CN_LAT_SUM, CN_LAT_N, CN_LAT_MAX,
 CN_INV_DONE, CN_INV_TMO, CN_FAULTS, CN_REQ_STALL, CN_RSP_STALL, CN_FILLS, CN_EVICTS, CN_TORN, CN_FAB_TMO, CN_STRAY, CN_CFG_REJ,
 CN_CTX_COMMIT, CN_INV_BLOCK) = range(25)
CN_FAULT0, NCNT = 25, 41
EXACT_CNT = [CN_REQS, CN_SEGS, CN_TLB_HIT, CN_TLB_MISS, CN_WALKS, CN_WALK_REFS, CN_WALK_FAULT, CN_LAT_SUM, CN_LAT_N, CN_LAT_MAX, CN_INV_DONE,
             CN_INV_TMO, CN_FAULTS, CN_REQ_STALL, CN_RSP_STALL, CN_FILLS, CN_EVICTS, CN_TORN, CN_FAB_TMO, CN_STRAY, CN_CFG_REJ,
             CN_CTX_COMMIT] + list(range(CN_FAULT0, CN_FAULT0 + 16))
BIG = 10 ** 18


class Epoch(object):
    """Everything the engine holds that a reset clears."""
    def __init__(self, P, meta, start):
        self.start = start
        self.ctx = {}                                  # idx -> (root_ppn, allow_r, allow_w) of VALID contexts
        self.tlb = R.RefTLB(P.TLB_ENTRIES)
        self.locked = False
        self.irq_en = 0
        self.sel = 0
        self.st_root_lo = self.st_root_hi = self.st_attr = 0
        self.drain_tmo = int(meta.get("drain_tmo_default", 256))
        self.inv_ctx = self.inv_lo = self.inv_hi = 0
        self.cnt_sel = 0
        self.pending = None                            # dict(accept, done, status, kind, ctx, vpn, from_ctx, clear)
        self.done_cnt = 0
        self.last_status = 0
        self.stream = []                               # refusals: dict(cyc, cause, level, write, dev, id, iova, bytes)
        self.log = []                                  # sequence numbers of the records the fault log holds (head first)
        self.dropped = 0
        self.pushes = []                               # (decision cycle, seq): refusals not yet applied to the log model
        self.cnt = [0] * NCNT
        self.sticky = 0
        self.wedge_end = -1                            # the fabric port is wedged until this cycle (late response of an abandoned read)
        self.flg_seqs = []


class Checker(object):
    def __init__(self, P, meta, verbose=False):
        self.P, self.meta, self.verbose = P, meta, verbose
        self.errors = []
        self.cov = {}
        self.allow_timeouts = bool(meta.get("allow_timeouts", False))

    def err(self, cyc, msg):
        self.errors.append("cycle %s: %s" % (cyc, msg))
        if self.verbose:
            print("ERROR cycle %s: %s" % (cyc, msg))

    def hit(self, key, n=1):
        self.cov[key] = self.cov.get(key, 0) + n


# ====================================================================================================================== trace
def load(path):
    T = dict(mem={}, errr=[], dw=32, end=0, benchfail=[], rows=[])
    with open(path) as f:
        for ln in f:
            p = ln.split()
            if not p:
                continue
            k = p[0]
            if k == "MEM":       T["mem"][int(p[1]) >> 2] = int(p[2], 16)
            elif k == "MEMERR":  T["errr"].append((int(p[1]), int(p[2])))
            elif k == "DW":      T["dw"] = int(p[1])
            elif k == "END":     T["end"] = int(p[1])
            elif k == "BENCHFAIL": T["benchfail"].append(ln.strip())
            else:                T["rows"].append((k, p[1:]))
    return T


ORDER = {"RST": -1, "POKE": 0, "QUIET": 0, "HANG": 0, "REQ": 1, "CFG": 2, "ST": 2, "INV": 3}


def run(path, P, meta, verbose=False):
    T = load(path)
    P.DW = T["dw"]
    ck = Checker(P, meta, verbose)
    for b in T["benchfail"]:
        ck.err(0, "bench monitor: " + b)

    rows = []
    for k, a in T["rows"]:
        cyc = int(a[0]) if a else 0
        rows.append((cyc, ORDER.get(k, 4), k, a))
    rows.sort(key=lambda r: (r[0], r[1]))

    rst = [r[0] for r in rows if r[2] == "RST"]
    def epoch_of(c):
        return bisect.bisect_right(rst, c)
    nep = len(rst) + 1

    quiet_ch = [(0, 1)] + [(r[0], int(r[3][1])) for r in rows if r[2] == "QUIET"]
    def quiet_at(c):
        q = 1
        for t, v in quiet_ch:
            if t <= c:
                q = v
        return q

    # ---- pair fabric reads (one outstanding transaction: the next FRS answers the open FRQ)
    reads = []
    open_r = None
    for cyc, _, k, a in rows:
        if k == "RST":
            open_r = None
        elif k == "FRQ":
            open_r = dict(cyc=cyc, addr=int(a[1]), data=0, err=0, frs=None, epoch=epoch_of(cyc), orphan=False)
            reads.append(open_r)
        elif k == "FRS":
            if open_r is None or open_r["addr"] != int(a[1]):
                ck.err(cyc, "fabric response for address 0x%x without a matching accepted read" % int(a[1]))
            else:
                open_r["frs"], open_r["data"], open_r["err"] = cyc, int(a[2], 16), int(a[3])
            open_r = None

    # ---- group requests, first-valid cycles and responses per epoch
    reqs = [(cyc, a) for cyc, _, k, a in rows if k == "REQ"]
    rsps = [(cyc, a) for cyc, _, k, a in rows if k == "RSP"]
    rspv = [(cyc, int(a[1])) for cyc, _, k, a in rows if k == "RSPV"]
    rspv_c = [c for c, _ in rspv]
    groups = {}
    for e in range(nep):
        rl = [x for x in reqs if epoch_of(x[0]) == e]
        rr = [x for x in rsps if epoch_of(x[0]) == e]
        j = 0
        for (c, a) in rl:
            g = []
            while j < len(rr):
                g.append(rr[j]); j += 1
                if int(rr[j - 1][1][6]) == 1:
                    break
            groups[c] = g if (g and int(g[-1][1][6]) == 1) else None
    first_rspv = {}
    for c, a in reqs:
        i = bisect.bisect_right(rspv_c, c)
        first_rspv[c] = rspv_c[i] if i < len(rspv_c) else None
    final_rsp = {c: (g[-1][0] if g else None) for c, g in groups.items()}
    req_cycles = sorted(c for c, _ in reqs)

    def last_final_rsp_upto(cyc):
        best = -1
        for c in req_cycles:
            if c > cyc:
                break
            fr = final_rsp.get(c)
            if fr is not None and fr > best:
                best = fr
        return best

    def quiescent(cyc, ep):
        for c in req_cycles:
            fr = final_rsp.get(c)
            if c <= cyc and (fr is None or cyc <= fr + 2) and epoch_of(c) == epoch_of(cyc):      # a request handshaken in the same cycle is concurrent
                return False
        if ep.pending and ep.pending["accept"] < cyc <= ep.pending["done"] + 1:
            return False
        return True

    invs_by_epoch = [[] for _ in range(nep)]
    for cyc, _, k, a in rows:
        if k == "INV":
            invs_by_epoch[epoch_of(cyc)].append((cyc, int(a[1])))
    st_snap = {cyc: (int(a[1]), int(a[2])) for cyc, _, k, a in rows if k == "ST"}
    flg = [(cyc, a) for cyc, _, k, a in rows if k == "FLG"]

    max_lat = 40 + 9 * (P.RETRY_MAX + 1) * (P.WALK_TMO + 6) * 2
    ep = Epoch(P, meta, 0)
    epochs = [ep]
    invq = list(invs_by_epoch[0])

    # ---------------------------------------------------------------------------------------------- CSR
    def valid_addr(addr):
        return (addr & 3) == 0 and not (addr & 0x80) and (addr >> 2) < NREG

    def reg_read(idx, cyc):
        if idx == R_ID:        return (0x5057 << 16) | (P.TLB_ENTRIES << 8) | P.NUM_CTX
        if idx == R_VERSION:   return 0x00010000
        if idx == R_CTRL:      return (int(ep.locked) << 31) | ep.irq_en
        if idx == R_DRAIN_TMO: return ep.drain_tmo
        if idx == R_INV_CTX:   return ep.inv_ctx
        if idx == R_INV_VA_LO: return ep.inv_lo
        if idx == R_INV_VA_HI: return ep.inv_hi
        if idx == R_CTX_SEL:   return ep.sel
        if idx == R_CTX_ROOT_LO: return ep.st_root_lo
        if idx == R_CTX_ROOT_HI: return ep.st_root_hi
        if idx == R_CTX_ATTR:  return ep.st_attr
        if idx in (R_CTX_RD_LO, R_CTX_RD_HI, R_CTX_RD_ATTR):
            e = ep.ctx.get(ep.sel) if ep.sel < P.NUM_CTX else None
            if idx == R_CTX_RD_LO: return (e[0] & 0xFFFFFFFF) if e else 0
            if idx == R_CTX_RD_HI: return (e[0] >> 32) if e else 0
            return ((1 << 31) | (1 << 2) | (e[2] << 1) | e[1]) if e else 0
        if idx == R_INV_STAT:
            busy = 1 if ep.pending and ep.pending["accept"] < cyc <= ep.pending["done"] else 0
            return ((ep.done_cnt & 0xFFFF) << 16) | (ep.last_status << 2) | busy
        if idx == R_CNT_SEL:   return ep.cnt_sel
        if idx == R_NCNT:      return NCNT
        if idx == R_CAPS:      return (P.MAX_BYTES << 16) | (P.DW << 8) | P.PA_W
        if idx == R_CAPS2:     return (int(bool(P.PTE_DOUBLE_READ)) << 2) | (int(bool(meta.get("wait_dma_quiet", 1))) << 1) | int(bool(P.SUPERPAGE_EN))
        return None

    def refuse(flags):
        ep.sticky |= (1 << ST_CMD_ERR)
        for f in flags:
            ep.sticky |= (1 << f)

    def begin_command(cyc, kind, c, vpn, from_ctx, clear):
        if not invq:
            if epoch_of(cyc) < len(rst):                            # a reset follows: the pending command is abandoned, nothing is applied
                ck.hit("cmd_lost_at_reset")
                ep.pending = dict(accept=cyc, done=rst[epoch_of(cyc)], status=-1, kind=kind, ctx=c, vpn=vpn, from_ctx=from_ctx, clear=clear)
                return
            ck.err(cyc, "a %s command was accepted by the model but the DUT never completed it" % kind)
            return
        done, status = invq.pop(0)
        if done <= cyc:
            ck.err(cyc, "completion at %d precedes the command accepted at %d" % (done, cyc))
        ep.pending = dict(accept=cyc, done=done, status=status, kind=kind, ctx=c, vpn=vpn, from_ctx=from_ctx, clear=clear)
        for rc in req_cycles:
            if cyc < rc <= done:
                ck.err(rc, "a request was accepted while an invalidation (accepted %d, done %d) was pending: blocking violated" % (cyc, done))
        ck.hit("cmd_" + kind)

    def on_cfg(cr, cs, wr, addr, val, err, rdata, priv):
        ck.hit("cfg")
        idx = (addr >> 2) & 31
        ok_addr = valid_addr(addr)
        exp_err = (not priv) or (not ok_addr) or (wr and idx in RO_REGS)
        if err != int(exp_err):
            ck.err(cr, "CSR %s 0x%02x: error flag %d, expected %d (priv=%d)" % ("write" if wr else "read", addr, err, int(exp_err), priv))
        if exp_err:
            ep.cnt[CN_CFG_REJ] += 1
            refuse([ST_PRIV] if not priv else ([ST_BADADDR] if not ok_addr else []))
            ck.hit("cfg_refused")
            if not wr and rdata != 0:
                ck.err(cr, "a refused CSR read returned data 0x%x" % rdata)
            return
        busy = bool(ep.pending and ep.pending["accept"] < cr <= ep.pending["done"])
        if not wr:
            if idx == R_STATUS:
                if (rdata & STATUS_MODELLED) != (ep.sticky & STATUS_MODELLED):
                    ck.err(cr, "STATUS reads 0x%x, expected sticky bits 0x%x" % (rdata & STATUS_MODELLED, ep.sticky & STATUS_MODELLED))
            elif idx == R_CNT_DATA:
                check_counter(cr, rdata)
            elif idx in (R_FLOG_CNT, R_FLOG_W0, R_FLOG_W1, R_FLOG_W2, R_FLOG_W3, R_FLOG_SEQ):
                flog_read(cr, idx, rdata)
            else:
                exp = reg_read(idx, cr)
                if exp is not None and rdata != exp:
                    ck.err(cr, "read of register %d returned 0x%x, expected 0x%x" % (idx, rdata, exp))
                if idx in WO_REGS and rdata != 0:
                    ck.err(cr, "write-only register %d read non-zero (0x%x)" % (idx, rdata))
            return
        if idx == R_CTRL:
            ep.irq_en = val & 1
            if val >> 31:
                ep.locked = True
        elif idx == R_STATUS:
            ep.sticky &= ~val
        elif idx == R_CNT_SEL:
            ep.cnt_sel = val
        elif idx == R_CTX_SEL:
            ep.sel = val
        elif idx in (R_CTX_ROOT_LO, R_CTX_ROOT_HI, R_CTX_ATTR):
            if ep.locked:    refuse([ST_LOCKED_REJ]); ck.hit("rej_locked")
            elif busy:       refuse([]); ck.hit("rej_busy")
            elif idx == R_CTX_ROOT_LO: ep.st_root_lo = val
            elif idx == R_CTX_ROOT_HI: ep.st_root_hi = val
            else:                      ep.st_attr = val
        elif idx in (R_INV_CTX, R_INV_VA_LO, R_INV_VA_HI):
            if busy:         refuse([]); ck.hit("rej_busy")
            elif idx == R_INV_CTX: ep.inv_ctx = val
            elif idx == R_INV_VA_LO: ep.inv_lo = val
            else:                    ep.inv_hi = val
        elif idx == R_FLOG_POP:
            if (val & 1) and ep.log:
                ep.log.pop(0)
                ck.hit("flog_pop")
            elif (val & 1):
                ck.hit("flog_pop_empty")
        elif idx == R_DRAIN_TMO:
            if ep.locked:    refuse([ST_LOCKED_REJ]); ck.hit("rej_locked")
            elif busy:       refuse([]); ck.hit("rej_busy")
            else:            ep.drain_tmo = val
        elif idx == R_CTX_CMD:
            code = None
            if ep.locked:               code = "locked"
            elif busy:                  code = "busy"
            elif val not in (1, 2):     code = "cmd"
            elif ep.sel >= P.NUM_CTX:   code = "index"
            elif val == 1:
                root44 = ((ep.st_root_hi & 0xFFF) << 32) | ep.st_root_lo
                if ((ep.st_attr >> 2) & 3) != 1 or (ep.st_attr >> 4) != 0 or (ep.st_root_hi >> 12) != 0 or root44 >= P.fab_lim:
                    code = "range"
            if code:
                refuse([ST_LOCKED_REJ] if code == "locked" else [])
                ck.hit("rej_ctxcmd_" + code)
            else:
                begin_command(cr, "CTX", ep.sel, 0, True, val == 2)
        elif idx == R_INV_CMD:
            code = None
            if busy:                    code = "busy"
            elif val not in (1, 2, 3):  code = "cmd"
            elif val in (2, 3) and ep.inv_ctx >= P.NUM_CTX: code = "index"
            elif val == 3 and (ep.inv_hi >> 6) not in (0, (1 << 26) - 1): code = "range"
            if code:
                refuse([])
                ck.hit("rej_invcmd_" + code)
            else:
                vpn = ((ep.inv_hi & 0x7F) << 20) | (ep.inv_lo >> 12)
                begin_command(cr, {1: "ALL", 2: "CTX", 3: "PAGE"}[val], ep.inv_ctx, vpn, False, False)

    def on_inv_done(cyc, status):
        p = ep.pending
        if p is None or p["done"] != cyc:
            ck.err(cyc, "completion event without an accepted command")
            return
        ck.hit("inv_done_ok" if status == 0 else "inv_done_tmo")
        ep.last_status = status
        if status == 0:
            ep.done_cnt += 1
            ep.cnt[CN_INV_DONE] += 1
            ep.sticky |= 1 << ST_INV_DONE
            lf = last_final_rsp_upto(p["accept"])
            if cyc - 3 < lf:
                ck.err(cyc, "completed at %d but the last response of an earlier request was accepted at %d: drain violated" % (cyc, lf))
            if meta.get("wait_dma_quiet", 1) and quiet_at(cyc - 2) == 0:
                ck.err(cyc, "committed while dma_quiet was low")
            if p["from_ctx"]:
                ep.cnt[CN_CTX_COMMIT] += 1
                ep.tlb.invalidate("CTX", ctx=p["ctx"])
                if p["clear"]:
                    ep.ctx.pop(p["ctx"], None)
                else:
                    root44 = ((ep.st_root_hi & 0xFFF) << 32) | ep.st_root_lo
                    ep.ctx[p["ctx"]] = (root44, ep.st_attr & 1, (ep.st_attr >> 1) & 1)
            else:
                ep.tlb.invalidate(p["kind"], ctx=p["ctx"], vpn=p["vpn"])
        elif status == 1:
            ep.cnt[CN_INV_TMO] += 1
            ep.sticky |= 1 << ST_INV_TMO
        else:
            ck.err(cyc, "unknown completion status %d" % status)
        ep.pending = None

    def check_counter(cyc, got):
        idx = ep.cnt_sel
        if idx >= NCNT:
            if got != 0:
                ck.err(cyc, "CNT_DATA for out-of-range index %d returned 0x%x" % (idx, got))
            return
        if not quiescent(cyc, ep):
            return
        snap = st_snap.get(cyc)
        if snap:
            ep.cnt[CN_REQ_STALL], ep.cnt[CN_RSP_STALL] = snap
        if idx in EXACT_CNT:
            exp = ep.cnt[idx]
            if got != exp:
                ck.err(cyc, "counter %d reads %d, derived from the trace: %d" % (idx, got, exp))
            ck.hit("cnt_checked")
        elif idx in (CN_WALK_CYC, CN_WALK_MAX, CN_INV_BLOCK):
            ck.hit("cnt_unchecked")

    # ---------------------------------------------------------------------------------------------- one request
    req_ord = [0]
    def on_request(cyc, a):
        rid, dev, cv, cd, wr, iova, nbytes = int(a[1]), int(a[2]), int(a[3]), int(a[4]), int(a[5]), int(a[6]), int(a[7])
        ordinal = req_ord[0]
        req_ord[0] += 1
        e_i = epoch_of(cyc)
        ep.cnt[CN_REQS] += 1
        ck.hit("requests")
        group = groups.get(cyc)
        if group is None:
            ck.hit("requests_lost_at_reset")
            return
        rv = first_rspv.get(cyc) or group[0][0]
        lat = rv - cyc
        ep.cnt[CN_LAT_SUM] += lat
        ep.cnt[CN_LAT_N] += 1
        ep.cnt[CN_LAT_MAX] = max(ep.cnt[CN_LAT_MAX], lat)
        if lat < 2:
            ck.err(cyc, "request %d: response valid after %d cycles (minimum is 2)" % (rid, lat))
        if lat > max_lat:
            ck.err(cyc, "request %d: first response after %d cycles exceeds the bound %d (unbounded walk?)" % (rid, lat, max_lat))
        events = []
        for r in reads:
            if r["epoch"] == e_i and cyc <= r["cyc"] <= rv and not r["orphan"]:
                events.append((r["addr"], r["data"], r["err"], r["frs"] is not None and r["frs"] <= rv))
        cause = R.static_check(P, ep.ctx, dev, cv, cd, wr, iova, nbytes)
        level = 3
        if cause != NONE:
            if events:
                ck.err(cyc, "request %d refused by the static checks (%s) but the DUT issued %d fabric read(s)" % (rid, FAULT_NAMES[cause], len(events)))
            fault, exp = (cause, 3), [(0, cause, 0, 0, 1)]
            ck.hit("static_" + FAULT_NAMES[cause])
        else:
            root = ep.ctx[dev][0]
            segs, pos, fault = [], 0, None
            for (vpn, off, length) in R.split_pages(iova, nbytes):
                ep.cnt[CN_SEGS] += 1
                ent = ep.tlb.lookup(dev, vpn)
                if ent is not None:
                    ep.cnt[CN_TLB_HIT] += 1
                    ck.hit("tlb_hit")
                    _, _, ps, ppn, r_ok, w_ok = ent
                    if not (w_ok if wr else r_ok):
                        fault = (PERM, 3)
                        ck.hit("hit_perm_fault")
                        break
                    segs.append(((R.eff_ppn(ppn, ps, vpn) << 12) | off, length))
                    continue
                ep.cnt[CN_TLB_MISS] += 1
                ep.cnt[CN_WALKS] += 1
                ck.hit("tlb_miss")
                try:
                    out, newpos, retries = R.replay_walk(events, pos, root, vpn, P)
                except R.ReplayMismatch as ex:
                    ck.err(cyc, "request %d (iova 0x%x): walk of vpn 0x%x deviates from the algorithm: %s" % (rid, iova, vpn, ex))
                    return
                ep.cnt[CN_WALK_REFS] += newpos - pos
                ep.cnt[CN_TORN] += retries
                ck.hit("fabric_reads", newpos - pos)
                if retries:
                    ck.hit("torn_retries", retries)
                pos = newpos
                if out[0] == R.NEED_MORE:
                    ep.cnt[CN_WALK_FAULT] += 1
                    fault = (PHYS_READ, out[1])
                    timeout_event(cyc, rv, e_i, events, lat, out[1])
                    break
                if out[0] == "F":
                    ep.cnt[CN_WALK_FAULT] += 1
                    fault = (out[1], out[2])
                    ck.hit("walk_" + FAULT_NAMES[out[1]])
                    break
                _, ppn, r_ok, w_ok, ps, lvl = out
                evicted = ep.tlb.fill(dev, vpn, ps, ppn, r_ok, w_ok)
                if r_ok or w_ok:
                    ep.cnt[CN_FILLS] += 1
                    if evicted:
                        ep.cnt[CN_EVICTS] += 1
                        ck.hit("tlb_evict")
                if not (w_ok if wr else r_ok):
                    fault = (PERM, lvl)
                    ck.hit("walk_PERM")
                    break
                segs.append(((R.eff_ppn(ppn, ps, vpn) << 12) | off, length))
            if pos != len(events):
                ck.err(cyc, "request %d: %d fabric read(s) beyond what the algorithm needs" % (rid, len(events) - pos))
            if fault:
                exp = [(0, fault[0], 0, 0, 1)]
            else:
                exp = [(1, 0, pa, ln, 1 if i == len(segs) - 1 else 0) for i, (pa, ln) in enumerate(segs)]
                ck.hit("ok")
                if len(segs) == 2:
                    ck.hit("ok_two_segments")
                if wr:
                    ck.hit("ok_write")
        if fault:
            cause_, level_ = fault
            ep.pushes.append((rv - 1, len(ep.stream)))
            ep.stream.append(dict(cyc=cyc, cause=cause_, level=level_, write=wr, dev=dev, id=rid, iova=iova, bytes=nbytes))
            ep.cnt[CN_FAULTS] += 1
            ep.cnt[CN_FAULT0 + cause_] += 1
            ck.hit("refused")
        got = [(int(ra[2]), int(ra[3]), int(ra[4]), int(ra[5]), int(ra[6]), int(ra[1])) for (rc, ra) in group]
        if len(got) != len(exp):
            ck.err(cyc, "request %d (iova 0x%x, %d bytes, %s): %d response(s), expected %d: DUT %s, expected %s" %
                   (rid, iova, nbytes, "W" if wr else "R", len(got), len(exp), [g[:5] for g in got], exp))
            return
        ra = meta.get("race_allowed", {}).get(str(ordinal))
        if ra:                                                    # an explicit claim of docs/01 section 9 (old / new / not present, never a mixture)
            g = got[0]
            hit_idx = None
            if len(got) == 1 and g[0] == 1 and ("pa:%d" % g[2]) in ra:
                hit_idx = ra.index("pa:%d" % g[2])
            elif len(got) == 1 and g[0] == 0 and ("fault:%d" % g[1]) in ra:
                hit_idx = ra.index("fault:%d" % g[1])
            if hit_idx is None:
                ck.err(cyc, "request %d: result %s is none of the allowed outcomes %s (a MIXED translation?)" % (rid, [x[:5] for x in got], ra))
            else:
                ck.hit("race_claim_ok")
                ck.hit("race_outcome_%d_of_%d" % (hit_idx, len(ra)))
        for i, (g, x) in enumerate(zip(got, exp)):
            if g[5] != rid:
                ck.err(cyc, "request %d: response %d carries id %d" % (rid, i, g[5]))
            if g[:5] != x:
                ck.err(cyc, "request %d (iova 0x%x, %d bytes, %s): response %d is (ok,fault,pa,bytes,last)=%s, expected %s (%s)" %
                       (rid, iova, nbytes, "W" if wr else "R", i, g[:5], x, FAULT_NAMES[x[1]]))

    def timeout_event(cyc, rv, e_i, events, lat, level):
        """The DUT gave up on a page-table read (timeout) or refused the walk (the port is wedged by an earlier timeout)."""
        if not ck.allow_timeouts:
            ck.err(cyc, "a walk stopped before reaching a leaf or a fault, and no timeout is expected in this scenario")
            return
        wedged_at_end = ep.wedge_end > rv
        wedged_before = ep.wedge_end > cyc + 2
        if wedged_at_end and wedged_before:
            ck.hit("wedge_refusal")
            if events:
                ck.err(cyc, "walk refused (port wedged) but reads were issued")
            if lat >= P.WALK_TMO:
                ck.err(cyc, "a wedge refusal must be immediate, took %d cycles" % lat)
            return
        # a genuine timeout
        ep.cnt[CN_FAB_TMO] += 1
        ck.hit("walk_timeout")
        if lat < P.WALK_TMO:
            ck.err(cyc, "a walk timed out after only %d cycles (WALK_TMO is %d)" % (lat, P.WALK_TMO))
        last = None
        for r in reads:
            if r["epoch"] == e_i and cyc <= r["cyc"] <= rv and not r["orphan"]:
                last = r
        if last is not None and (last["frs"] is None or last["frs"] > rv):
            ep.wedge_end = last["frs"] if last["frs"] is not None else BIG          # the late response ends the wedge
        else:
            for r in reads:                                                          # the unaccepted read will be accepted later: orphan
                if r["epoch"] == e_i and r["cyc"] > rv and not r["orphan"]:
                    r["orphan"] = True
                    ep.wedge_end = r["frs"] if r["frs"] is not None else BIG
                    break
            else:
                ep.wedge_end = BIG

    def flush_pushes(cyc, order):
        """apply to the fault-log model every refusal whose decision cycle precedes this event (a push and a POP in one cycle: POP first)"""
        due = [p for p in ep.pushes if (p[0], 3) < (cyc, order)]
        if not due:
            return
        ep.pushes = [p for p in ep.pushes if p not in due]
        for (cd, seq) in sorted(due):
            if len(ep.log) >= P.FQ_DEPTH:
                ep.dropped = min(0xFFFF, ep.dropped + 1)
                ck.hit("flog_drop")
            else:
                ep.log.append(seq)

    def flog_read(cr, idx, rdata):
        if not quiescent(cr, ep):
            return
        held = len(ep.log)
        if idx == R_FLOG_CNT:
            exp = (ep.dropped << 16) | (P.FQ_DEPTH << 8) | held
        elif held == 0:
            exp = 0
        else:
            x = ep.stream[ep.log[0]]
            if idx == R_FLOG_W0:    exp = ((x["id"] & 0xFFFF) << 16) | ((x["dev"] & 0xFF) << 8) | (int(x["write"]) << 6) | (x["level"] << 4) | x["cause"]
            elif idx == R_FLOG_W1:  exp = x["iova"] & 0xFFFFFFFF
            elif idx == R_FLOG_W2:  exp = x["iova"] >> 32
            elif idx == R_FLOG_W3:  exp = x["bytes"]
            else:                   exp = ep.log[0]
        ck.hit("flog_reg_checked")
        if rdata != exp:
            ck.err(cr, "fault-log register %d reads 0x%x, the model (held=%d, dropped=%d) expects 0x%x" % (idx, rdata, held, ep.dropped, exp))

    # ---------------------------------------------------------------------------------------------- drive in time order
    for cyc, order, k, a in rows:
        flush_pushes(cyc, order)
        if k == "RST":
            ep = Epoch(P, meta, cyc)
            epochs.append(ep)
            invq = list(invs_by_epoch[epoch_of(cyc)])
            ck.hit("resets")
        elif k == "CFG":
            on_cfg(int(a[0]), int(a[1]), a[2] == "W", int(a[3]), int(a[4]), int(a[5]), int(a[6]), int(a[7]))
        elif k == "INV":
            on_inv_done(cyc, int(a[1]))
        elif k == "REQ":
            on_request(cyc, a)
    for e in epochs:
        if e.pending and e.pending["status"] != -1:
            ck.err(e.pending["accept"], "command accepted but not completed before the end of the epoch")
    if invq:
        for c, s in invq:
            ck.err(c, "completion event with no accepted command")

    # ---------------------------------------------------------------------------------------------- fault log
    last_seq = {}
    for cyc, a in flg:
        e_i = epoch_of(cyc)
        e = epochs[e_i]
        seq, cause, level, wr, dev, rid, iova, nbytes = int(a[1]), int(a[2]), int(a[3]), int(a[4]), int(a[5]), int(a[6]), int(a[7]), int(a[8])
        ck.hit("fault_records")
        if seq >= len(e.stream):
            ck.err(cyc, "fault record %d but only %d refusals happened" % (seq, len(e.stream)))
            continue
        x = e.stream[seq]
        got = (cause, level, wr, dev, rid & 0xFFFF, iova, nbytes)
        want = (x["cause"], x["level"], x["write"], x["dev"], x["id"] & 0xFFFF, x["iova"], x["bytes"])
        if got != want:
            ck.err(cyc, "fault record %d (cause,level,write,dev,id,iova,bytes) = %s, the refused request is %s" % (seq, got, want))
        if cyc < x["cyc"]:
            ck.err(cyc, "fault record %d drained before the request was even accepted" % seq)
        if e_i in last_seq and seq <= last_seq[e_i]:
            ck.err(cyc, "fault log order violated: record %d after %d" % (seq, last_seq[e_i]))
        last_seq[e_i] = seq
    return ck


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("trace")
    ap.add_argument("--meta", default="{}")
    ap.add_argument("--param", action="append", default=[])
    ap.add_argument("--json", default=None)
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()
    meta = json.loads(a.meta)
    kw = {}
    for p in a.param:
        k, v = p.split("=")
        kw[k] = int(v, 0)
    P = R.Params(**kw)
    ck = run(a.trace, P, meta, a.verbose)
    c = ck.cov
    print("checked: %d requests (%d ok / %d refused), TLB %d hit / %d miss, %d fabric reads, %d CSR accesses, %d commands completed" %
          (c.get("requests", 0), c.get("ok", 0), c.get("refused", 0), c.get("tlb_hit", 0), c.get("tlb_miss", 0), c.get("fabric_reads", 0),
           c.get("cfg", 0), c.get("inv_done_ok", 0) + c.get("inv_done_tmo", 0)))
    if a.json:
        json.dump(dict(coverage=c, errors=ck.errors[:50], passed=not ck.errors), open(a.json, "w"), indent=1, sort_keys=True)
    if ck.errors:
        print("FAIL: %d violation(s)" % len(ck.errors))
        for e in ck.errors[:40]:
            print("  " + e)
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
