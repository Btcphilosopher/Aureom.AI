# Technology-independent size estimates (Yosys generic gates)

**Not area, timing or power**: no PDK exists in this project.  Counts of generic gates / flip-flops of the flattened design, comparable only with each other.

| configuration | generic cells | flip-flops | combinational cells |
|---|---|---|---|
| baseline: 4-entry TLB, 4 contexts, DW 32 | 23453 | 3075 | 20378 |
| DW 64 | 22909 | 3033 | 19876 |
| TLB 8 | 27322 | 3307 | 24015 |
| TLB 16 | 33882 | 3779 | 30103 |
| TLB 4 + superpages | 23445 | 3075 | 20370 |
| 16 contexts | 27980 | 3363 | 24617 |
| PA_W 44 | 23846 | 3159 | 20687 |
| fault log 16 deep | 35171 | 4569 | 30602 |

## Baseline, per module (hierarchy kept)

| module | generic cells | flip-flops |
|---|---|---|
| `sf_iommu_faults` | 4327 | 551 |
| `sf_iommu_invalidation` | 1224 | 213 |
| `sf_iommu_context` | 1913 | 220 |
| `sf_iommu_tlb` | 3263 | 224 |
| `sf_iommu_walk_fsm` | 1177 | 195 |
| `sf_iommu_pagewalker` | 1843 | 360 |
| `sf_iommu_perf` | 9819 | 1312 |
