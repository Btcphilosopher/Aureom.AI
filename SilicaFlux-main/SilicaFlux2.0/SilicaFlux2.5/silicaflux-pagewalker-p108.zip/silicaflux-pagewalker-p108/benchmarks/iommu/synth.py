#!/usr/bin/env python3
"""synth.py -- technology-INDEPENDENT size estimates (Yosys 0.33 generic gates).  NOT area in um^2, NOT timing, NOT power: no PDK exists in this project.
Counts generic cells and flip-flops of the flattened design for several configurations; useful only to compare configurations with each other."""
import os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RTL = os.path.join(ROOT, "rtl", "iommu")
FILES = [l.strip() for l in open(os.path.join(RTL, "filelist.f")) if l.strip()]
CONF = [("baseline: 4-entry TLB, 4 contexts, DW 32", {}), ("DW 64", {"DW": 64}), ("TLB 8", {"TLB_ENTRIES": 8}), ("TLB 16", {"TLB_ENTRIES": 16}),
        ("TLB 4 + superpages", {"SUPERPAGE_EN": 1}), ("16 contexts", {"NUM_CTX": 16, "DEV_W": 4}), ("PA_W 44", {"PA_W": 44}), ("fault log 16 deep", {"FQ_DEPTH": 16})]


def run(g, flatten=True):
    chp = " ".join("-chparam %s %d" % kv for kv in g.items())
    ys = "read_verilog -sv -I%s %s; hierarchy -check -top sf_iommu_pagewalker %s; synth -top sf_iommu_pagewalker %s; stat" % (RTL, " ".join(os.path.join(RTL, f) for f in FILES), chp, "-flatten" if flatten else "")
    return subprocess.run(["yosys", "-p", ys], capture_output=True, text=True).stdout


def parse_block(block):
    n = re.findall(r"Number of cells:\s+(\d+)", block)
    cells = {t: int(c) for t, c in re.findall(r"^\s+(\$_\w+_)\s+(\d+)\s*$", block, re.M)}
    ff = sum(v for k, v in cells.items() if k.startswith("$_DFF") or k.startswith("$_SDFF") or k.startswith("$_DLATCH"))
    return (int(n[-1]) if n else 0), ff


def main():
    rows = ["# Technology-independent size estimates (Yosys generic gates)", "",
            "**Not area, timing or power**: no PDK exists in this project.  Counts of generic gates / flip-flops of the flattened design, comparable only with each other.", "",
            "| configuration | generic cells | flip-flops | combinational cells |", "|---|---|---|---|"]
    for name, g in CONF:
        out = run(g)
        n, ff = parse_block(out[out.rindex("=== sf_iommu_pagewalker ==="):])
        rows.append("| %s | %d | %d | %d |" % (name, n, ff, n - ff))
        print(rows[-1])
    # per-module breakdown of the baseline (hierarchy kept)
    out = run({}, flatten=False)
    rows += ["", "## Baseline, per module (hierarchy kept)", "", "| module | generic cells | flip-flops |", "|---|---|---|"]
    seen = set()
    parts = re.split(r"^=== (.+?) ===$", out, flags=re.M)
    for hdr, body in zip(parts[1::2], parts[2::2]):
        mod = hdr.split("\\")[-1]
        if mod.startswith("design") or mod in seen or not mod.startswith("sf_iommu_"):
            continue
        seen.add(mod)
        n, ff = parse_block(body)
        if n:
            rows.append("| `%s` | %d | %d |" % (mod, n, ff))
    os.makedirs(os.path.join(ROOT, "benchmarks", "iommu", "results"), exist_ok=True)
    open(os.path.join(ROOT, "benchmarks", "iommu", "results", "synth.md"), "w").write("\n".join(rows) + "\n")


if __name__ == "__main__":
    main()
