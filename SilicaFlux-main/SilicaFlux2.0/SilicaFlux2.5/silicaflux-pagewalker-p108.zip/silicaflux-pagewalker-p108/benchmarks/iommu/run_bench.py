#!/usr/bin/env python3
"""
run_bench.py -- P108 performance benchmarks (simulation, cycle-accurate RTL; NO silicon, NO timing, NO frequency / power / area claim).

    benchmarks/iommu/run_bench.py [--quick] [--out benchmarks/iommu/results]

Every workload is a scenario of the SAME bench used by the regression and is judged by the SAME independent checker: a number is reported only for
a run that PASSED verification.  Metrics come from the engine's own hardware counters (read over the CSR port at the end of the run) and, where the
counters do not separate a case (hit vs miss latency, invalidation cost), from the trace.

Measured (brief section 9): TLB hit rate, TLB misses, page-walk cycles, memory references per walk, translation latency, invalidation count and
cost, fault count, DMA stalls.
"""
import argparse, csv, json, os, random, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.join(ROOT, "tests", "iommu"))
import regress as RG
import ref_model as RM
import check_trace as CT
import gen_scenarios as GS
from gen_scenarios import Sc, PAGE, RW, std_contexts, program_contexts, mkpte

CN = {n: i for i, n in enumerate(["REQS", "SEGS", "TLB_HIT", "TLB_MISS", "WALKS", "WALK_CYC", "WALK_REFS", "WALK_FAULT", "WALK_MAX", "LAT_SUM", "LAT_N",
                                  "LAT_MAX", "INV_DONE", "INV_TMO", "FAULTS", "REQ_STALL", "RSP_STALL", "FILLS", "EVICTS", "TORN", "FAB_TMO", "STRAY",
                                  "CFG_REJ", "CTX_COMMIT", "INV_BLOCK"])}

CONFIGS = {   # name -> (-G overrides, ref params)
    "tlb4_dw32": ({}, {}),
    "tlb4_dw32_nodbl": ({"PTE_DOUBLE_READ": 0}, {"PTE_DOUBLE_READ": 0}),
    "tlb4_dw64": ({"DW": 64}, {"DW": 64}),
    "tlb8_dw32": ({"TLB_ENTRIES": 8}, {"TLB_ENTRIES": 8}),
    "tlb16_dw32": ({"TLB_ENTRIES": 16}, {"TLB_ENTRIES": 16}),
}


def setup(name, P, npages=64, memlat=None, rspmode=None):
    sc = Sc(name)
    roots = std_contexts(sc)
    b = 0x4000_0000
    for k in range(npages):
        sc.map4k(roots[0], b + k * PAGE, sc.al.data(), RW)
    program_contexts(sc, roots, caps=[(1, 1)] * 4)
    if memlat is not None:
        sc.env("memlat 0 %d %d" % (memlat, memlat))
    if rspmode is not None:
        sc.env("rspmode 0 %d" % rspmode)
    return sc, roots, b


def finish(sc):
    sc.counters(range(25))
    return sc


def w_cyclic(P, npages, memlat, nreq=600):
    sc, roots, b = setup("cyclic_%d" % npages, P, max(npages, 1), memlat)
    for i in range(nreq):
        sc.req(0, b + (i % npages) * PAGE + 8, 8, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    return finish(sc)


def w_random(P, npages, memlat, nreq=1500, seed=3):
    sc, roots, b = setup("random_%d" % npages, P, max(npages, 1), memlat)
    rng = random.Random(seed)
    for i in range(nreq):
        sc.req(0, b + rng.randrange(npages) * PAGE + 8, 8, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    return finish(sc)


def w_zipf(P, npages, memlat, nreq=1500, seed=5):
    sc, roots, b = setup("zipf_%d" % npages, P, max(npages, 1), memlat)
    rng = random.Random(seed)
    w = [1.0 / (k + 1) for k in range(npages)]
    for i in range(nreq):
        k = rng.choices(range(npages), weights=w)[0]
        sc.req(0, b + k * PAGE + 8, 8, rng.randrange(2), gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    return finish(sc)


def w_hit(P, memlat, nreq=300):
    sc, roots, b = setup("hit", P, 4, memlat)
    for i in range(nreq):
        sc.req(0, b + 8, 8, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    return finish(sc)


def w_miss(P, memlat, nreq=200):
    sc, roots, b = setup("miss", P, nreq, memlat)
    for i in range(nreq):
        sc.req(0, b + i * PAGE + 8, 8, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    return finish(sc)


def w_cross(P, memlat, hit, nreq=100):
    sc, roots, b = setup("cross_%s" % ("hit" if hit else "miss"), P, 2 * nreq + 4, memlat)
    for i in range(nreq):
        base = b + ((0 if hit else 2 * i) * PAGE) + PAGE - 8
        sc.req(0, base, 16, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    return finish(sc)


def w_fault(P, memlat, kind, nreq=100):
    sc, roots, b = setup("fault_%s" % kind, P, 8, memlat)
    for i in range(nreq):
        if kind == "static":
            sc.req(0, 0xFFFF_FFFF_FFFF_FFF0 + (i & 7), 64, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))        # wraps 2**64: refused before any walk
        else:
            sc.req(0, 0x5_0000_0000 + (i % 7) * PAGE, 8, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))         # unmapped: a full walk then NOT_PRESENT
    return finish(sc)


def w_inval(P, memlat, every, nreq=400):
    sc, roots, b = setup("inval_%d" % every, P, 8, memlat)
    for i in range(nreq):
        sc.req(0, b + (i % 4) * PAGE + 8, 8, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
        if every and i % every == every - 1:
            sc.inv("page", 0, b + (i % 4) * PAGE)
    return finish(sc)


def w_inval_busy(P, memlat, nreq=60):
    """an invalidation command arrives 3 cycles after a MISS was accepted: it must wait for the walk and the response (drain), and the next request
    is held off until it completes"""
    sc, roots, b = setup("inval_busy", P, nreq + 4, memlat)
    for i in range(nreq):
        sc.req(0, b + i * PAGE + 8, 8, 0, gate="@cfg=%d" % sc.n_cfg)                    # presented while the command is pending: held off, counted as a DMA stall
        sc.inv("page", 0, b + i * PAGE, gate="@acc=%d @dly=3 @cfg=%d @inv=%d" % (sc.n_req, sc.n_cfg, sc.n_inv))
    return finish(sc)


def w_backpressure(P, memlat, mode, nreq=300):
    sc, roots, b = setup("bp_%d" % mode, P, 4, memlat, rspmode=mode)
    for i in range(nreq):
        sc.req(0, b + (i % 3) * PAGE + 8, 8, 0, gate="@cfg=%d @inv=%d" % (sc.n_cfg, sc.n_inv))
    return finish(sc)


def counters_from_trace(trace):
    """last value read for each counter index (CFG write to CNT_SEL (byte 104), then read of CNT_DATA (byte 108))"""
    sel, vals = 0, {}
    for ln in open(trace):
        p = ln.split()
        if not p or p[0] != "CFG":
            continue
        wr, addr, val, err, rd = p[3] == "W", int(p[4]), int(p[5]), int(p[6]), int(p[7])
        if wr and addr == 104:
            sel = val
        elif (not wr) and addr == 108 and not err:
            vals[sel] = rd
    return {n: vals.get(i, 0) for n, i in CN.items()}


def trace_metrics(trace):
    """per-request first-valid latency split into hit / miss (a miss issued at least one fabric read), invalidation cost, elapsed cycles"""
    req, rspv, frq, rsp_last, inv_cmds, invs = [], [], [], [], [], []
    for ln in open(trace):
        p = ln.split()
        if not p:
            continue
        if p[0] == "REQ": req.append(int(p[1]))
        elif p[0] == "RSPV": rspv.append(int(p[1]))
        elif p[0] == "FRQ": frq.append(int(p[1]))
        elif p[0] == "RSP" and p[7] == "1": rsp_last.append(int(p[1]))      # RSP cyc id ok fault pa bytes last
        elif p[0] == "INV": invs.append(int(p[1]))
        elif p[0] == "CFG" and p[3] == "W" and int(p[4]) in (36, 60): inv_cmds.append(int(p[1]))
    import bisect
    hit, miss = [], []
    for c in req:
        i = bisect.bisect_right(rspv, c)
        if i >= len(rspv):
            continue
        lat = rspv[i] - c
        j = bisect.bisect_left(frq, c)
        (miss if (j < len(frq) and frq[j] <= rspv[i]) else hit).append(lat)
    invc = [d - c for c, d in zip(inv_cmds, invs)]
    return dict(hit_lat=hit, miss_lat=miss, inv_cost=invc, elapsed=(rsp_last[-1] - req[0]) if req and rsp_last else 0, n=len(req))


def mean(x): return sum(x) / len(x) if x else 0.0


def run(cfg, sc, results, outdir, tag, extra):
    G, pkw = CONFIGS[cfg]
    exe = RG.build(cfg, G)
    path = GS.write(sc, os.path.join(outdir, "scn"))
    trace = path[:-4] + ".trace"
    rc, out = RG.run_one(exe, path, trace, 1)
    if rc != 0:
        raise RuntimeError("%s %s: bench rc=%d %s" % (cfg, sc.name, rc, out[-200:]))
    meta = json.loads(open(path).readline()[6:])
    ck = CT.run(trace, RM.Params(**pkw), meta)
    if ck.errors:
        raise RuntimeError("%s %s FAILED VERIFICATION: %s" % (cfg, sc.name, ck.errors[0]))
    c = counters_from_trace(trace)
    m = trace_metrics(trace)
    if m["n"] and m["elapsed"] <= 0:                                  # a metric that silently reads 0 is a harness bug, never a result
        raise RuntimeError("%s %s: elapsed time not measured (trace parse)" % (cfg, sc.name))
    row = dict(cfg=cfg, workload=sc.name, **extra)
    hits, misses = c["TLB_HIT"], c["TLB_MISS"]
    row.update(requests=c["REQS"], segments=c["SEGS"], hit_rate=round(hits / (hits + misses), 4) if hits + misses else 0.0, tlb_hits=hits, tlb_misses=misses,
               walks=c["WALKS"], walk_cycles=round(c["WALK_CYC"] / c["WALKS"], 2) if c["WALKS"] else 0, refs_per_walk=round(c["WALK_REFS"] / c["WALKS"], 2) if c["WALKS"] else 0,
               lat_avg=round(c["LAT_SUM"] / c["LAT_N"], 2) if c["LAT_N"] else 0, lat_max=c["LAT_MAX"], hit_lat=round(mean(m["hit_lat"]), 2), miss_lat=round(mean(m["miss_lat"]), 2),
               inv_done=c["INV_DONE"], inv_cost=round(mean(m["inv_cost"]), 2), inv_cost_max=max(m["inv_cost"]) if m["inv_cost"] else 0, faults=c["FAULTS"], req_stall=c["REQ_STALL"], rsp_stall=c["RSP_STALL"],
               evicts=c["EVICTS"], elapsed=m["elapsed"], req_per_kcycle=round(1000.0 * m["n"] / m["elapsed"], 1) if m["elapsed"] else 0)
    results.append(row)
    os.remove(trace)
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--out", default=os.path.join(ROOT, "benchmarks", "iommu", "results"))
    a = ap.parse_args()
    os.makedirs(os.path.join(a.out, "scn"), exist_ok=True)
    R = []
    lats = [1, 4, 12] if not a.quick else [2]
    sizes = [1, 2, 3, 4, 5, 6, 8, 12, 16, 24, 32] if not a.quick else [2, 4, 6]
    for cfg in (["tlb4_dw32", "tlb8_dw32", "tlb16_dw32"] if not a.quick else ["tlb4_dw32"]):
        pkw = CONFIGS[cfg][1]
        P = RM.Params(**pkw)
        GS.set_params(P)
        for n in sizes:
            run(cfg, w_cyclic(P, n, 2), R, a.out, "cyc", dict(ws=n, pattern="cyclic", memlat=2))
            run(cfg, w_random(P, n, 2), R, a.out, "rnd", dict(ws=n, pattern="random", memlat=2))
        for n in ([8, 16, 32] if not a.quick else [8]):
            run(cfg, w_zipf(P, n, 2), R, a.out, "zipf", dict(ws=n, pattern="zipf", memlat=2))
    # walk cost, latency and fault cost across fabric configurations and memory latencies
    for cfg in (["tlb4_dw32", "tlb4_dw32_nodbl", "tlb4_dw64"] if not a.quick else ["tlb4_dw32"]):
        P = RM.Params(**CONFIGS[cfg][1])
        GS.set_params(P)
        for L in lats:
            run(cfg, w_hit(P, L), R, a.out, "hit", dict(memlat=L, pattern="hit"))
            run(cfg, w_miss(P, L), R, a.out, "miss", dict(memlat=L, pattern="miss"))
            run(cfg, w_cross(P, L, True), R, a.out, "xh", dict(memlat=L, pattern="two-page hit"))
            run(cfg, w_cross(P, L, False), R, a.out, "xm", dict(memlat=L, pattern="two-page miss"))
            run(cfg, w_fault(P, L, "static"), R, a.out, "fs", dict(memlat=L, pattern="refused (static)"))
            run(cfg, w_fault(P, L, "walk"), R, a.out, "fw", dict(memlat=L, pattern="refused (walk)"))
    # invalidation cost and DMA stalls
    P = RM.Params()
    GS.set_params(P)
    for every in ([0, 1, 4, 16] if not a.quick else [4]):
        run("tlb4_dw32", w_inval(P, 2, every), R, a.out, "inv", dict(memlat=2, pattern="inval every %d" % every if every else "no inval"))
    run("tlb4_dw32", w_inval_busy(P, 2), R, a.out, "ib", dict(memlat=2, pattern="inval during a walk"))
    for mode in ([0, 1, 2] if not a.quick else [1]):
        run("tlb4_dw32", w_backpressure(P, 2, mode), R, a.out, "bp", dict(memlat=2, pattern="consumer mode %d" % mode))
    os.makedirs(a.out, exist_ok=True)
    keys = sorted({k for r in R for k in r}, key=lambda k: (k not in ("cfg", "workload", "pattern", "ws", "memlat"), k))
    with open(os.path.join(a.out, "results.csv"), "w") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in R:
            w.writerow(r)
    json.dump(R, open(os.path.join(a.out, "results.json"), "w"), indent=1)
    print("%d runs, every one verified; results.csv / results.json written to %s" % (len(R), a.out))


if __name__ == "__main__":
    main()
