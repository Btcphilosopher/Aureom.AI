# 03 — Security: threat model, enforcement points, what is and is not claimed

> A device-visible address is a *request*, not a grant. The grant is the physical address the engine returns, derived only from a trusted context and from page tables
> that a privileged agent owns.

## 1. Threat model

| actor | trusted? | what it controls |
|---|---|---|
| the **DMA / accelerator / device** | **untrusted** | `req_iova`, `req_bytes`, `req_write`, `req_id`, the `req_claim_*` fields, the *timing* of requests and of `rsp_ready` |
| the platform's **port logic** that drives `req_dev` | trusted | which device context a request belongs to (a hardware sideband: the physical port, or the PCIe requester ID — never a descriptor field) |
| **privileged software** (hypervisor / firmware) | trusted | the CSR port, the page tables in memory, the invalidation protocol of docs/01 §9 |
| the **fabric and memory** holding page tables | trusted to hold the tables; **not trusted to answer** | may be slow, silent, return errors, or violate protocol (stray response) |

Page tables are owned by the privileged agent in this single-stage design. **A guest-owned table would need a second stage (G-stage), which does not exist here** — mixing the two
is exactly what the spec (docs/01) forbids.

## 2. Properties and where each is enforced

| # | property | enforced by | evidence |
|---|---|---|---|
| S1 | a request is bound to a **trusted device context**; an untrusted descriptor cannot select a root or a domain | `req_dev` is a sideband; contexts are programmed only through the privileged port and validated there (root PPN inside the fabric, mode Sv39, no reserved bits); a descriptor *claim* can only be **refused** (`F_BAD_CONTEXT`), never obeyed | mutants `top-claim-obeyed`, `top-claim-ignored`, `ctx-*` killed; `d_malicious`; formal C1–C4 |
| S2 | **fail closed**: reset state = no context valid; no pass-through (BARE) mode | context table clears at reset; `SFIO_MODE_SV39` is the only mode that can be installed | `d_reset`, `d_malicious`; formal C3/C4; mutant `ctx-mode-unchecked` |
| S3 | the **full byte range** is checked: wrap of the 64-bit space, first **and last** byte canonical, length 1..`MAX_BYTES`, direction vs the context's caps | `CHECK` state: 65-bit `last = iova + bytes − 1`, canonical test on both ends | mutants `top-overflow-ignored`, `top-canon-*`, `top-len-*`, `top-zero-len-ok` killed; `d_boundary`, `d_malicious`; random |
| S4 | **page-boundary safety**: a request crossing one boundary is split into two page segments; **both pages are validated before the first segment is released** | segments are held in registers; a refusal of either page produces **one** fault response with `rsp_pa = 0` | mutants `top-second-page-perm-ignored-*`, `top-cross-off-by-one`, `top-seg1-offset`, `top-len1-wrong`, `top-rsp-last-wrong` killed; formal F3/F4 |
| S5 | **invalid accesses are rejected before side effects** | a statically refused request issues **zero** fabric reads; a faulting walk's reads are page-table reads only; a refusal carries `rsp_pa = 0`, `rsp_bytes = 0`; no TLB fill from a fault | checker: "static refusal ⇒ no fabric read" on every request; formal F1, F4 (`m_req_valid → st == WALK ∨ wedged`) |
| S6 | **permissions**: R/W/U/A/D of the leaf and the context caps | `r_ok = R∧A∧U`, `w_ok = W∧A∧D∧U` (Svade); a leaf that grants nothing is never cached; caps checked before any walk | mutants `walk-a/d/u-not-required*`, `tlb-write-perm-from-read`, `top-perm-*` killed |
| S7 | **no stale translation after an invalidation** | drain-then-commit; the TLB is cleared in the cycle the command commits, with no walk in flight; an invalidation beats a same-cycle fill | formal T2/T3 (**proved unbounded**), formal V1–V5; mutants `inv-*`, `tlb-inv-*` killed; checker's exact LRU model on every request |
| S8 | **no cross-context leak**: TLB entries are tagged by context | tag compare in every match; context reprogramming flushes that context in the same cycle as the table write | mutant `tlb-ctx-tag-ignored` killed; formal T1/T5; `d_multictx` |
| S9 | **bounded work**: no infinite walk, no undefined retry loop | ≤ 3 levels, ≤ `RETRY_MAX+1` attempts per PTE, ≤ `WALK_TMO` cycles per beat; a timeout wedges the port instead of withdrawing a read | formal W2 (**proved**) + bounded-walk BMC; mutants `walk-retry-unbounded`, `walk-timeout-disabled`, `walk-no-wedge-on-timeout` killed |
| S10 | the engine **never writes memory** | no write path exists in the walker; `m_req_write` is the constant 0 | formal M + in-RTL assertion in every simulation |
| S11 | **configuration is privileged and frozen when asked** | every CSR access needs `cfg_priv`; `CTRL.LOCK` is set-only | mutants `top-unpriv-*`, `ctx-lock-ignored`, `top-lock-clearable` killed |
| S12 | **malformed tables cannot produce an address**: reserved bits, W-without-R, non-leaf A/D/U, pointer at level 0, PPN beyond the fabric / PA width, misaligned superpage | decode of docs/01 §5 steps 1–7 | formal W1 (**decode equals an independent statement of the spec for every 64-bit PTE**); `d_invalid_pte`; decode mutants `walk-reserved-bits-mask`, `walk-w-without-r-allowed`, `walk-pointer-adu-allowed`, `walk-pointer-ppn-unchecked`, `walk-leaf-ppn-overflow-unchecked`, `walk-superpage-without-enable`, `walk-level0-pointer-descends`, `walk-valid-bit-ignored`, `walk-x-only-as-pointer` killed (all 24 walker mutants are) |

## 3. Why a refusal has no side effect

A refusal can originate in three places, none of which touches memory beyond what is stated:

1. **`CHECK`** (context, claim, length, overflow, canonical, direction): purely combinational on the latched request; the fabric port is idle. Formal F1.
2. **`LOOKUP` with a TLB hit that lacks the right**: no fabric access, no fill.
3. **`WALK`**: only SFB2 *reads* of page-table words. A walk that faults performs reads, never a write, never a fill.

The DMA never receives an address from a refused request: `rsp_pa` and `rsp_bytes` are forced to 0 and `rsp_last` to 1 (formal F4; every simulation checks it per cycle).

## 4. The two-page rule (the part of "check the full range" that is easy to get wrong)

A request `[iova, iova + bytes)` with `bytes ≤ 4096` touches at most two 4 KiB pages. The engine translates page 0, **holds** its result, translates page 1, and only then
releases segment 0 and segment 1. If page 1 is unmapped, read-only for a write, or malformed, the whole request is refused and **segment 0 is never released** — even though
page 0 translated correctly. Without this, a DMA could write the first half of a transfer into memory it is allowed to use and then be told the transfer failed.
(`d_boundary`; mutants `top-second-page-perm-ignored-hit/-walk`.)

## 5. Ordering of invalidation against outstanding DMA (summary of docs/01 §8)

The engine blocks new requests from the cycle after a command, drains its **own** translator, optionally waits for the platform's `dma_quiet`, then clears. It cannot revoke a
grant it already delivered; the platform must not reuse a page until the command completes **with status OK**. A drain timeout is reported and **does not apply** the command —
the engine never reports a half-done invalidation as complete.

## 6. Composition with MemoryGuard (P104) — specified, **not simulated here**

```
 device -> [ DMA ] -> (iova, bytes, dev) -> P108 translate -> (pa, bytes) -> P104 inline port (region check of the PA for the same domain) -> memory
```

P108 answers "which physical page does this IOVA mean for this context"; P104 answers "may this domain touch that physical range at all". They fail independently: a corrupt
page table that maps a tenant onto another tenant's page is still refused by P104's region table. Binding the walker's SFB2 master to a fabric port whose access matrix
reaches **only page-table memory** is the third, independent barrier (`MST_SLV_EN`).

## 7. What is not claimed (honest boundaries)

* **`cfg_priv` is a label.** Isolation is only as strong as the physical exclusivity of the configuration bus (ControlCore claims no authentication; the same boundary as P104).
* **`req_dev` is trusted.** If a platform lets a device influence it (e.g. a forged PCIe requester ID without ACS / source validation), the context binding is void.
* **No grant revocation**: an already-delivered translation cannot be cancelled; `dma_quiet` is the platform's contract (docs/01 §8).
* **Torn PTEs under a software protocol violation**: a 32-bit fabric can expose a mixed PTE to a walker if software rewrites a valid PTE without break-before-make (docs/01 §9). The
  engine stays safe (terminates, one response, reads only walk addresses) but the returned translation is then whatever memory held. Under the protocol the result is old, new or a
  transient fault — never mixed (simulation: `d_race`, 3 120 break-before-make races across the 11 default regression configurations × 3 seeds, all four outcomes observed; the *negative control* `PTE_DOUBLE_READ = 0` on a wide-PA build does return mixtures).
* **Denial of service**: a device that hammers unmapped pages makes the walker do 3–9 page-table reads per request (faults are not cached). No rate limiting exists.
* **Side channels** (hit/miss latency, TLB contention between contexts) are not addressed.
* **Page-table memory confidentiality / integrity** (ECC, encryption) is out of scope; a bus error on a PTE read becomes `F_PHYS_READ`.
* **No silicon evidence**; no timing, area or power figure exists.
