# 01 — Supported-specification subset (normative)

This is the contract of Project 108. The RTL (`rtl/iommu/`) and the independent reference model (`tests/iommu/ref_model.py`) are both written
from **this document**. Where this document and a RISC-V document differ, this document wins, and the difference is listed in §11.

> **Not a RISC-V IOMMU.** This engine implements one translation stage over a defined subset of the RISC-V privileged-architecture **Sv39**
> page-table format. It has no device directory (DDT), no process contexts (PASID), no in-memory command / fault queues, no MSI translation,
> no ATS / PRI, no second stage. It **must not be described as RISC-V IOMMU compliant**, and it is not Sv39-*compliant* either: it accepts a
> strict subset of Sv39 table contents and refuses the rest (§4–§6). Section 12 lists what it is prepared for.

## 1. Scope

| item | baseline (this release) |
|---|---|
| address spaces | 64-bit device-visible address (IOVA). Only the Sv39-canonical window is translatable (§3). |
| stages | **one**: IOVA → PA, first-stage semantics only. Nothing in the engine is a guest-physical → host-physical stage. |
| page sizes | **4 KiB** leaves only. 2 MiB / 1 GiB leaves are *recognised* and refused with `F_PAGE_SIZE` (§5, step 5). `SUPERPAGE_EN` exists as a parameter (default 0) — see §12. |
| TLB | fully associative, `TLB_ENTRIES` entries (**default 4**), true LRU. |
| walker | **one** walk at a time; one request at a time (no request queue). |
| access | read and write. Never execute. |
| memory | page-table reads only, as SFB2 read transactions (§2.3). The engine **never writes memory**. |

## 2. Interfaces (flat ports; names are the contract)

### 2.1 Translation request / response (DMA side — a strict superset of the P64 / P103 `iommu_req/rsp` contract)

| signal | dir | meaning |
|---|---|---|
| `req_valid` / `req_ready` | in / out | handshake; `req_valid` is held, payload unchanged, until accepted; `req_ready` never depends on `req_valid` |
| `req_dev[DEV_W]` | in | **trusted device identity** — driven by hardware the device cannot influence (the physical port / the PCIe requester ID), never by a descriptor. Selects the device context. |
| `req_claim_valid`, `req_claim_dev[DEV_W]` | in | the **untrusted** context the descriptor *claims*. If `req_claim_valid` and the claim differs from `req_dev` → `F_BAD_CONTEXT`. A claim can only be refused, never obeyed. |
| `req_write` | in | 1 = the DMA will write the range, 0 = read |
| `req_iova[63:0]` | in | first byte |
| `req_bytes[LEN_W]` | in | length, **1 .. MAX_BYTES** (`MAX_BYTES` ≤ 4096; default 4096) |
| `req_id[ID_W]` | in | opaque tag, echoed |
| `rsp_valid` / `rsp_ready` | out / in | handshake; `rsp_valid` held with payload unchanged until accepted |
| `rsp_id` | out | the request's tag |
| `rsp_ok`, `rsp_fault[3:0]` | out | exactly one of: `ok = 1, fault = 0` or `ok = 0, fault ≠ 0` |
| `rsp_pa[PA_W]` | out | physical address of the **segment** start; **0 when `rsp_ok = 0`** (no address leaves on a refusal) |
| `rsp_bytes[LEN_W]` | out | bytes of the segment (0 when `rsp_ok = 0`) |
| `rsp_last` | out | 1 on the last response of the request |
| `dma_quiet` | in | (§8) 1 = the platform has no granted-but-unfinished transfer; tie to 1 if the platform quiesces by software |

**One request → one response if it stays inside one 4 KiB page; two responses (segment 0, segment 1, `rsp_last` on the second) if it crosses one
page boundary; exactly one fault response (`rsp_last = 1`, no address) if any byte is refused.** Because `MAX_BYTES ≤ 4096`, a request touches
at most two pages. **Both pages are validated before the first segment is released**, so a refused second page releases nothing (§4 of
`03_SECURITY.md`). A request that does not cross a page is answered exactly as the P64 / P103 contract expects (one response).

### 2.2 Privileged configuration port (SFB2-slave style, one 32-bit word per access)

`cfg_req_valid/ready/write`, `cfg_addr[7:0]` (byte address, word aligned), `cfg_wdata[31:0]`, **`cfg_priv`** (1 = privileged initiator),
`cfg_rsp_valid/ready`, `cfg_rsp_rdata[31:0]`, `cfg_rsp_error`. An unprivileged access, an unaligned / unmapped address, or a write to a read-only
register gets `cfg_rsp_error = 1` and **no effect**. **`cfg_priv` is a label**: isolation is only as strong as the physical exclusivity of this
bus (the same honest boundary as P104). Register map: `rtl/iommu/sf_iommu_defs.svh`, `docs/02_INTERFACES.md`.

### 2.3 Page-table read port (DataFabric SFB2 master)

`m_req_valid/ready`, `m_req_write` (**constant 0**), `m_req_addr[31:0]`, `m_req_wdata` (0), `m_req_wstrb` (0), `m_rsp_valid/ready`, `m_rsp_rdata[DW]`,
`m_rsp_error`. `DW ∈ {32, 64}`. SFB2 rules R1–R12 of `docs/datafabric/PROTOCOL.md` are obeyed: a presented request is held until accepted (R2, no
cancellation); one response per accepted request, in order, ≥ 1 cycle later (R5); one outstanding transaction (R6); DW-aligned addresses (R9);
`m_rsp_error` → the read failed (R8); reset cancels everything in flight (R11). Little-endian: byte lane `b` of `m_rsp_rdata` is address `A + b`.
The port must be bound to a fabric master whose access matrix reaches **only the page-table memory** (`MST_SLV_EN`).

## 3. Address model

* `IOVA_W = 64` bits arrive. **Sv39 canonical rule:** bits `[63:39]` must equal bit `38`. The translatable window is therefore
  `[0, 2^38)` ∪ `[2^64 − 2^38, 2^64)`. **Both the first and the last byte** of a transfer must be canonical (§2.1, `F_NONCANONICAL`).
* `last = iova + bytes − 1` is computed in **65 bits**. A carry out of bit 63 is `F_ADDR_OVERFLOW` (the transfer wraps the address space).
* `vpn = iova[38:12]` (27 bits: `vpn[2] = iova[38:30]`, `vpn[1] = iova[29:21]`, `vpn[0] = iova[20:12]`); `offset = iova[11:0]`.
* Physical address width **`PA_W`** (default 32, ≤ 56; = `FAB_AW` of the fabric in the default build). `PPN_W = PA_W − 12`.
* `FAB_AW = 32`: the SFB2 address width. A page table must lie below `2^FAB_AW`.

## 4. The Sv39 PTE (64 bits, little-endian in memory)

| bits | field | handling |
|---|---|---|
| 0 | V | 0 → `F_NOT_PRESENT`. **All other bits are then ignored** (as in Sv39). |
| 1 | R | read |
| 2 | W | write. `W = 1, R = 0` is a **reserved encoding** → `F_INVALID_PTE` |
| 3 | X | accepted on a leaf, **never grants anything** to a DMA. R=W=0, X=1 is a leaf with no usable right. |
| 4 | U | leaf: **must be 1** (a device is a *user-privilege* initiator, decision D-U). Non-leaf: must be 0. |
| 5 | G | accepted everywhere, **ignored** (the TLB is tagged by context; nothing is global). |
| 6 | A | leaf: must be 1 (**Svade**: no hardware A/D update; A = 0 → `F_PERM`). Non-leaf: must be 0. |
| 7 | D | leaf: must be 1 **for a write** (D = 0 and write → `F_PERM`). Non-leaf: must be 0. |
| 9:8 | RSW | ignored |
| 53:10 | PPN | `PPN[0] = [18:10]`, `PPN[1] = [27:19]`, `PPN[2] = [53:28]` (26 bits) |
| 63:54 | reserved | **must be zero** (no Svpbmt `[62:61]`, no Svnapot `[63]`, `[60:54]` reserved) → `F_INVALID_PTE` |

Classification of a PTE with V = 1 and zero reserved bits and not (W ∧ ¬R): **leaf iff R ∨ X; pointer iff R = W = X = 0.**

PTE address at level `i`: `a_i = (table_ppn << 12) + vpn[i] * 8`. PTEs are 8 bytes, 8-byte aligned.

## 5. The walk (normative algorithm; this is what the reference model implements)

```
table = context.root_ppn          // context validated at programming time: root_ppn < 2^(FAB_AW-12)
for i = 2, 1, 0:                                    // at most three PTE fetches -- the walk is bounded by construction
    pte = read64(table*4096 + vpn[i]*8)             // a failed read: F_PHYS_READ, walk ends
    1. if V == 0:                                   F_NOT_PRESENT
    2. if pte[63:54] != 0:                          F_INVALID_PTE
    3. if W == 1 and R == 0:                        F_INVALID_PTE
    4. if (R or X):                                 // leaf
         5. if i != 0:  if SUPERPAGE_EN == 0:      F_PAGE_SIZE
                        else if PPN[i-1:0] != 0:    F_MALFORMED      // misaligned superpage
         6. if PPN >= 2^PPN_W:                      F_ADDR_OVERFLOW  // physical address beyond PA_W
         -> leaf found: r_ok = R & A & U ;  w_ok = W & A & D & U     // (W implies R by step 3)
    7. else (pointer):
         if (A or D or U):                           F_INVALID_PTE    // reserved on non-leaf
         if i == 0:                                  F_MALFORMED      // pointer at the last level
         if PPN >= 2^(FAB_AW-12):                    F_MALFORMED      // next table beyond the fabric
         table = PPN
```
After a leaf: the access is permitted iff `write ? w_ok : r_ok`; otherwise `F_PERM`. The leaf is written into the TLB iff `r_ok | w_ok`
(a leaf that grants nothing is **never cached**, so software that later sets A / D needs no invalidation to *gain* access — it needs one to *lose* it).
**Faults are never cached** (no negative caching). Result PA = `(PPN << 12) | offset` (4 KiB leaf).

**Fault attribution** for a request: `F_BAD_CONTEXT`, then `F_BAD_REQUEST`, then `F_ADDR_OVERFLOW`, then `F_NONCANONICAL`, then the context's direction cap
(`F_PERM`), then page 0 (first byte's page), then page 1 (last byte's page, if different). The **first** refusal wins.

**Page-table reads are 64-bit.** With `DW = 64` a PTE is one beat (atomic). With `DW = 32` it is two beats; to make a non-atomic read safe the engine reads
**low, high, low** and compares the two low words. A mismatch re-reads the PTE (at most `RETRY_MAX` times, default 2); still unstable →
`F_INVALID_PTE`. Under the **update protocol of §9** this makes every PTE read a consistent snapshot (argument in `docs/05_VERIFICATION.md` §6).

## 6. Faults

| code | name | when |
|---|---|---|
| 0 | `NONE` | permitted |
| 1 | `BAD_CONTEXT` | `req_dev ≥ NUM_CTX`, or the context is not valid / not `SV39`, or the claim differs |
| 2 | `NOT_PRESENT` | a PTE on the walk has `V = 0` |
| 3 | `PERM` | leaf lacks the right for this access (R / W / U / A / D), or the context's `allow_r / allow_w` forbids the direction |
| 4 | `MALFORMED` | pointer at level 0; pointer PPN beyond the fabric; misaligned superpage |
| 5 | `PAGE_SIZE` | leaf at level 1 / 2 with `SUPERPAGE_EN = 0` |
| 6 | `PHYS_READ` | a PTE read returned `m_rsp_error`, timed out (`WALK_TMO` cycles per beat), or the port is wedged by an earlier timeout |
| 7 | `INVALID_PTE` | reserved bits, `W ∧ ¬R`, reserved non-leaf A/D/U, or a PTE that stayed unstable through `RETRY_MAX` re-reads |
| 8 | `ADDR_OVERFLOW` | `iova + bytes` wraps 2^64, or a leaf PPN ≥ `2^PPN_W` |
| 9 | `NONCANONICAL` | first or last byte outside the Sv39 canonical window *(addition)* |
| 10 | `BAD_REQUEST` | `bytes = 0` or `bytes > MAX_BYTES` *(addition)* |

A TLB *miss* while the fabric port is wedged (an earlier read timed out and its late response is still owed) is refused at once as `PHYS_READ` with `level = 2` and **no new page-table read is issued** (the abandoned read, if the fabric has not yet accepted it, simply stays presented, as SFB2 R2 requires); TLB hits are unaffected. The late response (or reset) ends the wedge.

Every faulting request produces **one** record in the fault log: `{cause, level (0..2, or 3 = not a walk fault), write, device, id, iova, bytes, sequence}`,
and **one** `rsp_fault` response. A fault leaves **no trace on the fabric** unless it is a walk fault (a request refused by the static checks
issues **zero** fabric reads — checked per request by the test checker).

## 7. TLB semantics

* Entry: `{valid, context tag (CTX_W), vpn (27), ppn (PPN_W), r_ok, w_ok, psize (2), LRU age}`; fully associative; lookup is combinational.
* Match: `valid ∧ tag = context ∧ (vpn ⊕ entry.vpn) & size_mask = 0`, `size_mask` = all 27 bits (4 KiB), `vpn[26:9]` (2 MiB), `vpn[26:18]` (1 GiB).
* **Uniqueness.** At most one valid entry matches any lookup. A fill first removes every entry of the same context whose range overlaps the new one;
  a fill and an invalidation in the same cycle → the **invalidation wins and the fill is dropped**. A multi-match, if it were ever observed, is treated as a **miss**.
* **Replacement:** first an entry made invalid by a conflict, then any invalid entry (lowest index), else the **least-recently used** (true LRU: ages are a permutation of `0..N-1`).
* **No stale translation after an invalidation** — §8.

## 8. Invalidation: commands and their ordering against DMA

Commands (CSR `INV_CMD`): **`ALL`** (every entry), **`CTX c`** (every entry of context `c`), **`PAGE c, va`** (the entries of context `c` covering `va`). A context
programming command (`CTX_CMD` SET / CLEAR) is an invalidation of that context **fused with** the table write: the new entry and the flush happen in the **same cycle**.

**Drain-then-commit** (the P104 discipline):

1. The command is *accepted* in the cycle of the `INV_CMD` / `CTX_CMD` write. From the **next** cycle `req_ready = 0` (`blocking`).
   A request handshaken in the same cycle as the write is ordered **before** the command and is drained.
2. **DRAIN:** wait until the translator is idle (no request in progress, **the last response of the last request has been accepted**) *and* `dma_quiet = 1`.
   If `DRAIN_TMO ≠ 0` and the wait exceeds it: **the command is NOT applied** (`INV_STAT.status = TMO`, `STATUS.INV_TMO`, `CE_TMO`), blocking is released.
3. **COMMIT** (one cycle): the TLB entries are cleared (and a context entry is written). No walk is in flight, so no walk can re-install a stale entry afterwards.
4. **DONE:** `inv_done_evt` pulses, `STATUS.INV_DONE` is set, the completion counter advances, blocking ends.

**Ordering guarantee.** (a) Every translation response **accepted before** the command completes was computed **before** the commit; every request
**accepted after** completion is computed from fresh walks. (b) Responses are *grants*: the engine does **not** revoke a grant it already delivered — it
cannot see the data path. A platform that reclaims a physical page must therefore also wait for its own granted transfers; `dma_quiet` lets the engine wait for
them *before* it reports completion. If the platform has no such signal it must quiesce the DMA itself before issuing the command (P64 / P103 / P104 state the same rule).
(c) A request that was split into two segments is validated and delivered **atomically with respect to invalidation**: the command waits for both segments.
(d) **Software contract:** the PTE change must be globally visible in memory **before** the invalidation command is written.

## 9. Page-table update protocol (software contract)

* **Never-valid → valid** (map): write the PTE (any order), then publish. No invalidation needed (a non-present translation is never cached).
* **Valid → invalid** or **valid → different valid** (unmap / remap), *break-before-make*:
  1. write the **low word** with `V = 0`;
  2. write the **high word**;
  3. write the **low word** with the new value (`V = 1`);
  4. issue the invalidation and wait for `INV_DONE`.
  With a 64-bit fabric the three writes collapse into one atomic 64-bit store.
* **What the engine guarantees under this protocol:** a translation requested while a PTE is being rewritten is the **old** one, the **new** one, or a **transient
  fault** -- `NOT_PRESENT` (the walker read the `V = 0` window) or `INVALID_PTE` (the low word kept changing for more than `RETRY_MAX` re-reads: "unstable") -- and
  **never a mixture** of old and new fields. Software must therefore treat a `NOT_PRESENT` / `INVALID_PTE` fault on a page it is remapping as retryable.
* Violating this (e.g. rewriting a valid PTE low-word-first) can expose a *mixed* PTE to a 32-bit walker for a bounded window. The engine still terminates,
  still produces exactly one response, and still never reads outside the walk's addresses; but the translation it returns during the window is whatever the
  memory held, which is the software's responsibility.

## 10. Decisions

| id | decision | reason |
|---|---|---|
| D-U | a device is a user-privilege initiator: leaf `U = 1` is required | removes a privilege-mode input the DMA does not have; no SUM semantics to mix up |
| D-AD | Svade: A = 0 or (write ∧ D = 0) → fault; the engine never updates A / D | a read-only walker has no memory side effects (formally: `m_req_write ≡ 0`) |
| D-NEG | faults and no-right leaves are never cached | no software-visible stale *absence*; every cached entry grants something |
| D-G | G is ignored | the TLB is tagged by context |
| D-ROOT | a context's root is programmed only through the privileged port and validated there | an untrusted descriptor can never select a root |
| D-BARE | no pass-through (BARE) mode | an unconfigured / disabled context must fail closed |
| D-ATOM | a two-page request is validated completely before anything is released | "rejected before side effects" holds for the whole range |
| D-TMO | a walk timeout wedges the fabric port until the late response arrives or reset; TLB hits still work, misses fault `PHYS_READ` | a withdrawn SFB2 request is illegal (R2); a late response must not be mistaken for the next walk's |
| D-DRN | drain timeout does **not** apply the command | a half-drained invalidation must not be reported as complete |

## 11. Differences from the RISC-V documents (so nobody mistakes this for compliance)

| RISC-V | here |
|---|---|
| Sv39 allows hardware A/D update (Svadu) *or* faults | faults only (Svade) |
| non-leaf A/D/U "must be cleared by software" (hardware behaviour unspecified) | hardware **faults** (`F_INVALID_PTE`) |
| reserved PTE bits are an extension space (Svpbmt, Svnapot) | none implemented: any set → `F_INVALID_PTE` |
| superpages | recognised, refused (`F_PAGE_SIZE`) unless `SUPERPAGE_EN` |
| `satp`-selected modes (Bare, Sv39, Sv48, Sv57…) | Sv39 only; Bare deliberately absent |
| privilege modes and SUM / MXR | one fixed privilege (user); no SUM, no MXR |
| IOMMU: device directory (DDT), PASID process directory, queues, MSI, ATS, G-stage | none |
| canonical check on virtual addresses | same rule; failure is `F_NONCANONICAL` here (a page fault in RISC-V) |
| TLB may cache invalid translations (without Svvptc) | never cached |
| PTE reads atomic w.r.t. a 64-bit store | atomic when `DW = 64`; `lo-hi-lo` validation when `DW = 32` |

## 12. Prepared for (not implemented unless stated)

* **Larger pages:** TLB `psize` field, mask match, overlap-removal on fill and the walker's alignment rule are in place; `SUPERPAGE_EN = 1` is verified *only* in the
  expansion configuration reported in `reports/` (see `docs/05_VERIFICATION.md` for exactly what ran).
* **Multiple stages:** the TLB result is `ppn + perms` of *one* stage; a second stage would add a second walker and a combined entry. Nothing in §5 reads or writes a guest-physical address.
* **RISC-V IOMMU device directory:** `req_dev` → context lookup is the place a DDT walk would go; the context record already carries `{root, mode, direction caps}`.
* **Queue-based invalidation:** the invalidation block is already a command FSM with a single slot; a memory queue would feed the same `{kind, ctx, vpn}` port.
* **PCIe device contexts:** `req_dev` can be the PCIe requester ID; `DEV_W` and `NUM_CTX` are parameters.
