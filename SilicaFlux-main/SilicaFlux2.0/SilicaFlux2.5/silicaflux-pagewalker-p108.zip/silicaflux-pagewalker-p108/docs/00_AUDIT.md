# 00 — Repository audit (what exists, what this project reuses, what it does not)

Method: the repository (`btcphilosopher/Aureom.AI`, `SilicaFlux-main/`) was inspected as committed — the SilicaFlux modules are **zip archives**
(`SilicaFlux2.0/SilicaFlux2.5/*.zip`, 157 of them), so each relevant archive was extracted into a scratch directory and read there. Nothing in the
repository was modified; **nothing in this project was committed to git** — it is delivered as an archive.

## 1. Findings that shaped the design

| # | Finding | Consequence for P108 |
|---|---|---|
| A1 | **No MMU, TLB, IOMMU page walker or Sv39 RTL exists anywhere in the repository.** The only translation-like RTL is DomainGuard's `sf_albion_iommu` (P97), whose own header says: *"a simple, flat, register-based translation unit … NOT a RISC-V IOMMU (no in-memory device/process contexts, **no page walker** …)"*. | P108 is new work, not an extension. |
| A2 | **MemoryGuard exists** as Project 104 (`silicaflux-memoryguard-p104.zip`). It is region *protection* and states *"it is protection, not translation — it is not an IOMMU"*; its `sf_memory_guard_iommu_if` returns `guard_rsp_pa = guard_req_addr` (identity). StreamDMA's own docs (P103, written earlier) still say "no module named MemoryGuard exists" — that statement is out of date. | P108 is the *translation* half; P104 is the natural *second, independent check* behind it (docs/03 §6). They compose; they are not the same block. |
| A3 | **BridgeEngine is not an RTL module.** The Albion hardware-dependency table lists it as project 85, *"DMA / host bridge (inferred) — **Missing**"* (`sf_albion_dma`, `sf_albion_host_if`). It appears as a *named bus master* (DOM_BRIDGE, "BridgeEngine (DMA)") in IronMemory and ComputeWorks. | There is no BridgeEngine interface to honour. The DMA-side contract used is the real one that exists: StreamDMA (P103) / CloudDMA (P64) `iommu_req/rsp` (A4). |
| A4 | **The DMA-side translation contract is already defined**: P64 `docs/03 §3` / P103 `guard_req_* / guard_rsp_*` — request `{domain, asid, write, addr, bytes 1..4096, id}` → response, **in order, one per request, variable latency allowed**, `{id, ok, fault[4], pa}`; P64 fault codes NO_MAP / PERM / DOMAIN / RANGE / XLAT / ASID / LEN. | P108's request/response ports are a **strict superset** (§2.1 of the spec): same fields, plus a trusted `req_dev` and an untrusted claim, a `rsp_bytes` / `rsp_last` pair for a request that crosses one 4 KiB boundary, and a richer fault code. A request inside one page is answered exactly as P64 / P103 expect. |
| A5 | **DataFabric SFB2** (P03): 32-bit address, `DW ∈ {32, 64, 128}`, **single-beat** transactions, one outstanding per port, in-order responses ≥ 1 cycle later, no cancellation of a presented request (R2), `rsp_error` with `rdata = 0`, reset cancels everything (R11). | A 64-bit Sv39 PTE is **two beats** on the default `DW = 32` fabric → the walker needs a torn-read defence (low-high-low, spec §5) and a policy for an abandoned read (wedge, spec D-TMO). `PA` / table addresses are limited to 32 bits (`FAB_AW`). |
| A6 | **ControlCore** (HPC): privileged `ext_*` / SFB2 master, memory map generated from `config/cc_memmap.yaml`, "ControlCore claims no authentication". | The CSR port is SFB2-slave style with a `cfg_priv` *label* — isolation is only as strong as the physical exclusivity of that bus (same honest boundary as P104). |
| A7 | **Meridian / MeridianQoS** (P83 / P102): an arbitrated fabric with a `grd_*` check port. | Not instantiated. The walker's SFB2 master can be one more Meridian slave-side client; no code was needed. |
| A8 | **Toolchain convention** of the neighbouring projects: Verilator 5.020, Yosys 0.33, Icarus 12, z3 4.8, **no structs / packages / `return` / `int'()` casts / interfaces in synthesizable RTL**, flat ports, `.svh` macro headers, `make lint regress formal mutate synth bench zip`, a baseline gate before mutation, "honest boundaries" documents. | Followed: same tool versions (apt), same RTL subset, same evidence layout. |
| A9 | The repository's *committed* artefacts are archives of other projects. A `*.sf` file is SystemVerilog. | Deliverables are `.sv` as the brief names them. |

## 2. Reuse matrix

| Existing block | Used how | Not used because |
|---|---|---|
| DataFabric SFB2 (P03) | The page-table read port **is** an SFB2 master (rules R1–R12 obeyed and checked by the bench). The CSR port follows the SFB2-slave style. | The crossbar itself is not instantiated (no system testbench in the repo wires an IOMMU into it; see 05 §7). |
| StreamDMA / CloudDMA contract (P103 / P64) | Request / response port shape, in-order single response, `id` echo, fault-code style, ≤ 4096-byte bursts. | The RTL of those DMAs is not instantiated; compatibility is by contract, verified by a bench that *is* the contract (not by simulation against P103 RTL). |
| MemoryGuard (P104) | Documented composition: P108 translates, P104's inline port checks the physical result per domain (docs/03 §6). CE_* error numbers and the "drain-then-commit" / "drain timeout does not apply" semantics are reused. | Not instantiated in a joint simulation. |
| DomainGuard (P97) | Fault-record style (`{cause, op, device, tid, len, addr}`). | Different model (flat table, no walker). |
| ControlCore | Privileged-bus convention only. | No firmware / bus integration exists to reuse. |
| MemoryLab / TimingLab | — | Not needed; performance is measured by the engine's own counters and the bench. |

## 3. What was *not* found (so it is not claimed)

* A RISC-V IOMMU, a device directory, a process-directory, a command queue in memory, an MSI table, ATS / PRI, a G-stage — none exist; none are claimed.
* Any joint simulation of a DMA + IOMMU + MemoryGuard + memory. This project verifies the IOMMU against a **bench that models the DMA contract and an
  SFB2 memory**; the end-to-end composition is specified (docs/03 §6) but **not simulated**.
* PDK data, timing, power, silicon — none; no frequency, area (µm²) or power figure is claimed anywhere in this project.
