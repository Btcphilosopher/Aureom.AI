# 04 — Architecture walkthrough and the reasons behind the non-obvious decisions

Read `01_SPEC_SUBSET.md` for *what* is promised and `02_INTERFACES.md` for the ports. This document explains *how* the RTL keeps those promises.

## 1. The datapath in one picture

```
 req_dev ─┐                                     ┌────────── TLB hit ───────────────────────────────┐
 claim    │  ┌─────────┐  ┌───────────────┐   ┌─┴───────┐                                           │
 iova     ├─>│ CHECK   │─>│ page split    │──>│ LOOKUP  │── miss ─> walk_start ─> [ walk_fsm ] ─ m_* (SFB2 reads)
 bytes    │  │ context │  │ vpn0 / vpn1   │   │ (TLB)   │<── walk_done (leaf | fault) ─┘
 write    │  │ claim   │  │ len0 / len1   │   └────┬────┘
 id       ┘  │ len     │  └───────────────┘        │ per page: permission check (r_ok / w_ok vs request)
             │ overflow│                           ▼
             │ canon.  │                      RESP registers: pa0,len0 [pa1,len1]   ──> rsp_* (1 or 2 segments, or one fault)
             │ caps    │                           │ fill TLB with a leaf that grants something
             └─────────┘                           └──> sf_iommu_faults (on any refusal)
```

**States** (`sf_iommu_pagewalker`): `IDLE → CHECK → LOOKUP → [WALK → LOOKUP (page 1)] → RESP → IDLE`. `req_ready = IDLE ∧ ¬inv_busy`.

## 2. Why a request stays in one register set for its whole life

A request is latched at the handshake and never re-read from the port, so the DMA can change its payload the cycle after acceptance (the bench drives junk then, on purpose). Context lookup output
(`ctx_idx`, root) is latched in `CHECK`; the context table cannot change under it because a commit happens only when the translator is idle (§5).

## 3. The two-page request — why results are held in registers, not re-looked-up

An obvious design translates page 0, releases it, then translates page 1. That lets a DMA act on page 0 and *then* be told the transfer failed. Here page 0's result is
parked in `r_pa0/r_len0`, page 1 is translated, and only when **both** are valid does `RESP` begin. Parking also avoids a second walk of page 0 (a 4-entry TLB cannot be relied on
to still hold it) **and** closes a time-of-check/time-of-use window: the PAs released are exactly the ones validated, even if page tables change in between.

## 4. The walker (`sf_iommu_walk_fsm`)

```
W_IDLE ─start─> W_REQ ─accepted─> W_RSP ─response─> [next beat: W_REQ] ─> W_DECODE ─┬─ descend ─> W_REQ (level-1)
                  │                  │                                              ├─ leaf    ─> W_DONE
                  └── timeout ───────┴── gives up (orphan flags) ──────────────────>└─ fault   ─> W_DONE
```

* **Bounded by construction.** The level counter only decrements; beats per PTE ≤ 3; attempts per PTE ≤ `RETRY_MAX+1`; each beat ≤ `WALK_TMO` cycles. Formally proved (state legality, `W2`) and
  bounded-model-checked under a hostile fabric: a walk ends within 24 / 42 / 114 cycles (64-bit, 32-bit, 32-bit with retries; `WALK_TMO = 4`).
* **Why `lo-hi-lo`.** A Sv39 PTE is 64 bits; DataFabric moves 32. Reading `lo, hi` can return a mixture if software rewrites the PTE between the beats. Re-reading `lo` after `hi` and comparing detects every
  rewrite that follows the break-before-make order of docs/01 §9 (argument in `05_VERIFICATION.md` §6); `RETRY_MAX` bounds the re-reads. Disabling it (`PTE_DOUBLE_READ = 0`) is a *negative control* that
  produces mixed translations in simulation.
* **Why an abandoned read wedges the port instead of being withdrawn.** SFB2 R2 forbids cancelling a presented read, and R6 allows one outstanding transaction. If a walk times out, the read is still the fabric's
  business: it may be accepted a million cycles later and its response must not be mistaken for the next walk's. `orph_req` / `orph_rsp` record "owed"; while owed, TLB **hits still work** and a miss is refused at once
  (`F_PHYS_READ`, level 2). The late response clears it. (Reset clears it too: R11.)
* **No write path.** There is no state that issues a write; `m_req_write` is tied to 0 at the top. (There is no hardware A/D update: Svade, D-AD.)
* **Decode is a pure function** of `{pte, level}` (steps 1–7 of docs/01 §5), which is why it could be proved equivalent to an independently written statement for *every* 64-bit PTE.

## 5. Invalidation — drain-then-commit and why completion is "after"

```
 accepted ──> DRAIN (blocking=1) ── pipe_idle ∧ dma_quiet ──> COMMIT (clear TLB [+ write context]) ──> DONE (inv_done_evt)
                         └─ DRAIN_TMO expires ──────────────────────────────────────────────────────> DONE (status TMO, NOT applied)
```

* Blocking begins the cycle **after** the write that accepts the command, so ordering is crisp: a request handshaken in the same cycle is *before* the command; every later one is *after* completion.
* `pipe_idle` means the **last response has been accepted**, not merely produced — so no response computed from pre-invalidation state can be consumed after completion.
* A context command is an invalidation of that context **fused** with the table write (one `COMMIT` cycle). There is no moment at which the new root coexists with the old root's TLB entries, and no walk can straddle it.
* Timeout does **not** apply the command. A forced commit under a stuck consumer could leave a validated-but-undelivered response alive after "completion"; the engine would rather report failure.

## 6. TLB details that matter

* Tag = context index (`CTX_W` bits). Match is combinational; `lk_multi` (never reachable — proved) is treated as a miss, never as an OR of two PPNs.
* Fill order: remove every overlapping entry of the context → choose a slot (overlapped slot, else invalid slot, else LRU) → write. An invalidation in the same cycle **wins** and drops the fill.
* A leaf that grants nothing (`r_ok = w_ok = 0`) is **not cached**, and a fault is never cached: so software that *adds* a right (sets A, D, or maps a page) needs no invalidation; only software that *removes* one does.
* Page size is a first-class field (`psize`, masks): the baseline fills only 4 KiB; `SUPERPAGE_EN = 1` lets the walker fill 2 MiB / 1 GiB and the TLB's overlap rule is exercised (05 §8).

## 7. Decisions that were reversed during verification (kept here so they are not re-made)

| first idea | found by | outcome |
|---|---|---|
| "walk faults and no-right leaves may be cached to save walks" | spec review (D-NEG) | rejected: stale *absence* is a security bug; every cached entry grants something |
| drain timeout forces the commit | analysis of the stuck-DMA case | rejected: a half-drained invalidation must not be reported complete (D-DRN) |
| race claim "old, new or NOT_PRESENT" | `retry0` regression configuration | **corrected**: an unstable PTE past the retry budget is a legal transient `INVALID_PTE`; the guarantee is "never a mixture" (01 §9) |
| context root stored in `PA_W−12` bits | lint across parameterisations | changed: the root is validated to fit the **fabric** (`FAB_PPN_W` bits); smaller hardware, no dead bits |
