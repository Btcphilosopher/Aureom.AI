# 07 — Limitations: what this is **not**

Read this before relying on anything in this directory.

## Evidence level

* **Everything is RTL simulation, formal on RTL, and Yosys generic-gate estimates.** No FPGA, no place-and-route, no silicon, no PDK, no timing closure, no power. **No frequency, area (µm²) or power figure is claimed anywhere.**
* **The environment is a model written for this project.** The bench's SFB2 memory, its DMA-side requester and its CSR master were written alongside the RTL by the same author. They implement the *documented* contracts
  (DataFabric SFB2 R1–R12; the P64 / P103 `iommu_req/rsp` shape) and the bench monitors check those rules, but **no simulation of this engine against the RTL of DataFabric's crossbar, StreamDMA, CloudDMA, MemoryGuard or ControlCore exists.**
* **One simulator** (Verilator 5.020). Icarus 12 was installed but not used to simulate the bench (C++). The in-RTL assertions are compiled into every simulation build (`SF_CHECKS`); the formal invariants are `FORMAL`-only.
* **The independent oracle shares an author with the RTL.** It shares no code and was written from `docs/01`, but both come from one understanding of that document. A misreading present in both would not be caught. The formal
  decode-equivalence proof (W1) restates the spec a *third* time in different style; that reduces, not removes, this risk. Review of `docs/01` by someone else is the real fix.
* **Directed + constrained-random, not exhaustive**, for everything the proofs do not cover. Coverage is reported as feature counters observed by the checker (05 §4), not as code / toggle coverage from a tool.
* **Mutation testing samples; it does not cover.** 97 hand-written defects (05 §7) are evidence that the suite is sensitive to those faults.
* **Unbounded formal proofs are module-level** (TLB, walker, invalidation FSM, context table, fault log, counters). **The composed design is bounded (BMC: 34 cycles at `DW = 64`, 38 at `DW = 32`)**, not proved: induction on the whole design would need the
  cross-module invariants stated explicitly. Module proofs use **assumptions** about their neighbours (e.g. "a commit follows a command"); each holds by construction in the composed RTL and is exercised by simulation and the bounded top-level check, but is not proved *across* modules.
* **Small parameter instances.** Proofs are for small widths (e.g. 20-bit VPN, 3-bit PPN in the TLB proof; 4-bit PPN in the walker proof) and a 2-entry TLB in the composed check; unbounded in time, not in size. The 16-entry TLB induction did not conclude (≈ 51 minutes of ABC, 05 §5).
* **Walker termination is bounded, not proved**: "a walk ends within 24 / 42 / 114 cycles under any fabric behaviour" is a BMC result to 30 / 48 / 120 frames; the *by-construction* argument (counters only count down / are bounded) is backed by the proved state-legality invariant W2.
* **The 32-bit composed check is shallow**: its 38 frames contain one completed 9-read walk (witness at frame 31) and a few cycles after it; a two-segment response is not reachable in 40 frames on a 32-bit fabric (it is on a 64-bit one), so two-page atomicity is covered by the 64-bit bounded check and by simulation (05 §5, limit 2).

## Protection

* **`cfg_priv` and `req_dev` are labels / sidebands** whose integrity the platform must guarantee (03 §7).
* **Granted translations are not revoked**; `dma_quiet` is the platform's contract. A DMA that ignores the response of a refused request is the DMA's bug; a DMA that keeps using a stale grant after `INV_DONE(OK)` is a platform bug.
* **Page tables are trusted (single stage).** A guest-owned page table needs a second stage that does not exist. Mixing the two is the one thing the spec forbids.
* **Software must follow the update protocol of docs/01 §9.** Under a violation a 32-bit fabric can expose a mixed PTE (shown by the negative control); the engine stays safe (bounded, one response, reads only walk addresses) but the translation is then whatever memory held.
* **No rate limiting**: a device hammering unmapped pages costs 3–9 page-table reads per request. **No side-channel mitigation.** No ECC / parity on the TLB, the context table or page-table words.
* **The page-table read port must be bound to a fabric master that reaches only page-table memory.** The RTL cannot enforce that; the platform's access matrix must.

## Function

* **Baseline concurrency is one**: one request and one walk at a time. A request waits for the previous response group to be accepted. There is no hit-under-miss, no request queue, no multi-client arbitration. *Expanding concurrency was deliberately not attempted:* the brief
  requires the baseline's memory-safety tests to pass first, and this project stops there. (Capacity expansion and superpages *were* run, after the baseline gate — 05 §8.)
* **Single stage, Sv39 subset only**: no Sv48 / Sv57, no BARE mode, no PASID, no device directory, no queues in memory, no MSI, no ATS / PRI. **Not a RISC-V IOMMU and not Sv39-compliant** (docs/01 §11 lists every difference, including the strict handling of reserved bits).
* **No walk cache** (intermediate PTEs are re-read on every miss): 9 reads per miss on a 32-bit fabric. **No hardware A/D update** (Svade).
* **A request is ≤ 4096 bytes** (`MAX_BYTES`), so it touches ≤ 2 pages. Larger transfers must be split by the DMA (P64 / P103 already do).
* **Fabric address is 32 bits** (SFB2 `AW`): page tables must lie below 4 GiB. `PA_W` up to 56 is supported for the *translated output*.
* **After a walk timeout the walker is wedged until the late response arrives or reset**; a fabric that never answers blocks all TLB *misses* (hits still work) until reset.
* **Counters are 32-bit saturating and cleared only by reset**; the 41 counters are 42 % of the gates (benchmarks/iommu/results/synth.md) — a production build would narrow or remove most of them.
* **The fault log has `FQ_DEPTH` records**; a full log drops the *newest* record (counted, sequence numbers keep counting).

## Tool and process notes

* Formal runs on **ABC (`bmc3`, `ind`)**, not `yosys-smtbmc` + z3: z3 4.8.12 did not complete even trivial depth-1 queries on these models in this environment (the toy design was instant), so it was abandoned after bisecting
  (not a design issue). The proofs are therefore only as trustworthy as ABC's k-induction; each inductive claim has a base case checked with `bmc3` and each property has a reachability witness.
* The formal back-end needed the flow `prep; memory_map; async2sync; dffunmap; … write_aiger -zinit` and constraint `fold` (an `orpos` before `fold` silently merges constraints into the property and was a trap).
* **Nothing was committed to git.** The project is delivered as a zip.
