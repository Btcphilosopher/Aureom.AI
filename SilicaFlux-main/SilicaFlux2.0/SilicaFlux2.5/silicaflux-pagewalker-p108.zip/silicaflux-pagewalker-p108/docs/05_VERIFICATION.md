# 05 — Verification: what was checked, how, with what evidence, and what is not covered

Read `07_LIMITATIONS.md` first if you only read one file. This document says **which claim rests on which kind of evidence**.

## 0. Evidence levels used in this project

| level | meaning | where |
|---|---|---|
| **PROVED** | k-induction (Yosys → AIGER → ABC `ind`) of an invariant over *all* inputs and *all* reachable states of a **module** at a **small parameter instance**; base case by `bmc3` from reset | §5 |
| **BOUNDED** | BMC from reset to a stated depth: no violation within that many cycles; says nothing beyond | §5 |
| **WITNESSED** | a reachability witness: an assertion that *must fail* does fail, so the proofs are not vacuous | §5 |
| **SIMULATED** | RTL simulation (Verilator) of directed + constrained-random scenarios, every trace judged cycle-by-cycle by an independent Python reference model | §3, §4 |
| **MUTATION-TESTED** | a catalogue of 97 planted RTL defects; the suite is shown sensitive to them | §7 |
| **ARGUED** | a written argument, not mechanised | §6 |
| **MODELLED** | Yosys generic-gate counts; no timing, area or power | `06_PERFORMANCE.md` |

There is **no** silicon, FPGA, timing or power evidence, and **no** simulation against the real DataFabric / DMA RTL.

## 1. Architecture of the verification (and its one weak point)

```
 gen_scenarios.py ──> .scn ──> tb_pagewalker.cpp (Verilator bench: SFB2 memory slave, DMA requester, CSR master, protocol monitors, reset/hang injection)
                                    │ trace (every handshake, every page-table read and its answer, every CSR access, every poke into the page tables)
                                    ▼
                     check_trace.py  +  ref_model.py   ← written from docs/01, shares NO code with the RTL
        walks replayed against the data the DUT actually read · exact LRU TLB model · refusal ⇒ no fabric read · CSR / command / fault-log model · counter cross-check
```

* The **checker is the judge**, the bench only drives and records. The checker predicts, for every request, whether it must hit or miss the TLB, what every page-table read must be (address, order, retries), the exact response, the fault, every CSR reply, every fault-log record
  and every performance counter — from the trace alone.
* The RTL additionally carries **in-RTL assertions** (`SF_CHECKS`, compiled into every simulation build: response payload stable until accepted, a refusal carries no address, one response group per request, `m_req_write = 0`, …) and `FORMAL` invariant blocks.
* **The weak point is stated plainly**: the RTL, the oracle and the formal restatement of the decode were written by the same author from the same document. They share no code, but a *misreading of `docs/01`* would be reproduced in all three. Review of `docs/01` by someone else is the real fix.

## 2. Phase gating — "build a four-entry TLB and single-request page walker first"

* The RTL was built as **the baseline only**: a 4-entry TLB (default `TLB_ENTRIES = 4`), one request and one walk at a time. The directed memory-safety scenarios, the oracle, the in-RTL assertions, the formal module proofs and the mutation gate were assembled against that baseline.
* **Expansion was run only after that**, and is reported separately (§8): TLB 8 / 16 entries, 64-bit fabric, superpages (`SUPERPAGE_EN`), wider PA, other context counts. They are *parameter instances of the same RTL*; none of the baseline's claims is supported by an expansion run.
* **Concurrency was not expanded.** No hit-under-miss, no request queue, no multiple walkers, no multi-client arbitration exist. The brief orders expansion after the memory-safety tests pass; this project stops there. "Concurrent requests" in §3 therefore means *requests offered while the engine is busy / blocked*, not simultaneous translations.
* The brief's "future-prep" items (larger pages, multi-stage, RISC-V IOMMU DDT, queue invalidation, PCIe contexts) are **not implemented**; `docs/01` §11 lists the hooks and the differences.

## 3. The brief's verification list → evidence

| brief item | scenarios (`tests/iommu/gen_scenarios.py`) | proofs / checks | mutants that show sensitivity |
|---|---|---|---|
| valid translations | `d_valid`, random, benchmarks | every response compared with `ref_model` (address, size, segments) | `walk-wrong-beat-offset`, `walk-wrong-level-index`, `tlb-ppn-truncated`, `top-seg1-offset` |
| unmapped | `d_unmapped`, `d_fault*` | `NOT_PRESENT` at each level, fault level, fault log | `walk-valid-bit-ignored` |
| permissions (R / W / U / A / D, caps) | `d_perm` | W1b (formal): latched `R&A&U`, `W&A&D&U` equal the independent expression for every PTE | `walk-a/d/u-not-required*`, `top-perm-*`, `tlb-*-perm-*`, `ctx-allow-*` |
| page-boundary / full-range | `d_boundary`: page crossing, exactly one byte past, 4096 B, 4097 B, zero length, 64-bit wrap, first/last byte non-canonical, write across a read-only page | two-page atomicity (F3/F4); oracle checks no segment of a refused request is released | `top-cross-off-by-one`, `top-len*`, `top-overflow-ignored`, `top-canon-*`, `top-second-page-perm-ignored-*`, `top-rsp-last-wrong` |
| multiple contexts | `d_multictx`, `d_inval_ctx` | TLB tag compare T1/T5 (proved) | `tlb-ctx-tag-ignored`, `ctx-*`, `inv-ctx-from-wrong-reg` |
| invalid PTEs / malicious page tables | `d_invalid_pte`, `d_superpage`, `d_fabric` (bus errors), `d_flap` (unstable PTE) | W1a (fault class for every 64-bit PTE and level), W2/W3 | `walk-reserved-bits-mask`, `walk-w-without-r-allowed`, `walk-pointer-*`, `walk-superpage-without-enable`, `walk-bus-error-ignored` |
| TLB replacement | `d_tlb_repl`, random at `tlb4 / tlb8 / tlb16` | the oracle's **exact LRU model** predicts every hit and every miss; T1–T5 | `tlb-lru-no-touch-on-hit`, `tlb-victim-lowest-index` |
| invalidation (all / context / page) and its ordering against outstanding DMA | `d_inval`, `d_inval_ctx`, `d_drain` (busy translator, `dma_quiet`, timeout, back-pressure) | V1–V5, T2, T3 (proved); the oracle checks "no request accepted while a command is pending, completion only after the last response was accepted" | `inv-*`, `tlb-inv-*`, `top-ready-during-inv`, `top-idle-while-resp` |
| concurrent requests | `d_concurrent` (back-to-back requests, a request offered while a walk / a command / an unaccepted response is pending, consumer back-pressure) | one response group per request (F5), stable payload until accepted | `inv-no-blocking`, `inv-no-drain`, `top-idle-while-resp` |
| reset | `d_reset` (mid-walk, mid-response, mid-command, back-to-back), `@rst` gates | fail-closed state after reset; abandoned commands apply nothing; wedge cleared | `tlb-reset-keeps-valid`, `ctx-clear-keeps-valid` (see §7 for what reaches them) |
| malicious descriptors | `d_malicious`: forged claim / out-of-range device, bad lengths, non-canonical, unprivileged CSR access, locked configuration; adversarial random | S1–S3 (docs/03) | `top-claim-obeyed`, `top-claim-ignored`, `top-unpriv-*`, `ctx-range-ignored`, `ctx-lock-ignored` |
| page-table update races | `d_race_bbm / lo_hi / hi_lo` (a PTE rewritten at **every** point of a walk, 2 gaps × 5 delays), `d_flap`, `d_timeout` | torn-read argument (§6); the oracle's per-request **race-set** claim; negative control | `walk-no-torn-compare`, `walk-retry-unbounded` |

Only the **break-before-make** race (`d_race_bbm`) carries a translation claim ("old, new, NOT_PRESENT or unstable-INVALID_PTE — never a mixture"; after the invalidation completes, exactly the new one). The `lo_hi` / `hi_lo` variants violate the protocol on purpose: the checker still replays every read and checks termination and single response, but claims no translation (`docs/01` §9).

## 4. Simulation results (final RTL)

`python3 scripts/regress.py --seeds 3 --random 25` — every trace judged by the oracle. Source: `reports/regression.md`.

| set | configurations | scenario × seed runs | result |
|---|---|---|---|
| default | base, dw64, wide (PA_W 44), tmo, tlb8, tlb16, ctx1, ctx7, small, retry0, fab24 | 11 × 141 = 1551 | **1551 / 1551 pass** |
| superpages | sp (`SUPERPAGE_EN = 1`) | 141 | **141 / 141 pass** (`reports/regression_sp.md`) |
| **negative control** | nodbl (`PTE_DOUBLE_READ = 0`), nodbl_wide | 282 | **279 / 282 pass; the 3 failures are `d_race_bbm` on `nodbl_wide`, as designed** (`reports/regression_negative_control.md`) |

Each configuration runs 22 directed scenarios (18 named `d_*`, `d_race` in three write orders, and `d_timeout`) × 3 seeds, and 25 constrained-random / adversarial scenarios × 3 seeds (66 + 75 = 141). Selected feature counters observed by the checker over the 1551 default runs (all in `reports/regression.md`):

| feature | count | | feature | count |
|---|---|---|---|---|
| requests judged | 372 777 | | refused: statically (BAD_CONTEXT / BAD_REQUEST / NONCANONICAL / PERM / ADDR_OVERFLOW) | 173 k |
| translated OK (incl. 13 353 writes, 483 two-segment) | 59 720 | | refused in a walk (NOT_PRESENT 89 152, INVALID_PTE 27 939, PERM 9 480, MALFORMED 6 327, PAGE_SIZE 4 483, PHYS_READ 192, ADDR_OVERFLOW 132) | 137 k |
| page-table reads checked against the Sv39 algorithm | 1 369 806 | | TLB hits / misses / evictions | 11 998 / 194 859 / 24 621 |
| invalidations completed OK / timed out | 54 846 / 804 | | torn-read retries actually triggered | 2 760 |
| CSR accesses / commands refused (privilege, address, busy, index, range, locked, bad command) | 4 023 | | walk timeouts / wedge refusals | 99 / 33 |
| resets injected (requests lost at reset) | 1 110 (471) | | break-before-make races with a checked outcome | 3 120 (old 531, new 2 397, NOT_PRESENT 106, unstable 86) |
| fault records / drops checked | 47 186 / 261 411 | | counter values cross-checked | 58 971 |

Two things this table says about *coverage*, honestly: (1) the regression is dominated by walks (194 859 misses vs 11 998 hits) — the miss and fault paths are exercised far harder than the hit path, which is the right bias for memory safety but means hit-path timing variety is thinner; (2) coverage is the checker's feature counters, **not** line, branch or toggle coverage from a tool.

## 5. Formal verification (Yosys → AIGER → ABC)

`python3 scripts/formal.py` (`make formal`). Source: `reports/formal.md` / `.json`; harnesses in `formal/iommu/`; the invariants live in the RTL under `` `ifdef FORMAL``.

| job | what | result | k / frames | seconds |
|---|---|---|---|---|
| `tlb_n4` | TLB, 4 entries (baseline): T1–T6 | **PROVED** | k = 2 | 8 |
| `tlb_n3` | TLB, 3 entries (non-power-of-two) | **PROVED** | k = 2 | 4 |
| `tlb_n2` | TLB, 2 entries | **PROVED** | k = 2 | 2 |
| `tlb_n8` | TLB, 8 entries (expansion) | **PROVED** | k = 2 | 134 |
| `tlb_n16` | TLB, 16 entries (expansion) | **UNKNOWN** | induction not concluded (k ≤ 3) | 3053 |
| `inv_q1` | invalidation FSM, wait for `dma_quiet`: V1–V5 | **PROVED** | k = 2 | 1 |
| `inv_q0` | invalidation FSM, no `dma_quiet` wait | **PROVED** | k = 2 | 1 |
| `inv_t1` | invalidation FSM, drain timeout 1 cycle | **PROVED** | k = 2 | 1 |
| `inv_t0` | invalidation FSM, timeout disabled | **PROVED** | k = 2 | 1 |
| `walk_dw64` | walker, 64-bit fabric: W1a/b, W2–W7 | **PROVED** | k = 3 | 2 |
| `walk_dw32` | walker, 32-bit fabric, validated (lo-hi-lo) read | **PROVED** | k = 3 | 2 |
| `walk_dw32n` | walker, 32-bit, no validating re-read | **PROVED** | k = 3 | 2 |
| `walk_sp` | walker, superpages enabled | **PROVED** | k = 3 | 2 |
| `walk_b64` | walker termination ≤ 24 cycles, any fabric behaviour, 64-bit | BOUNDED | 30 frames | 2 |
| `walk_b32n` | termination ≤ 42 cycles, 32-bit, no re-read | BOUNDED | 48 frames | 4 |
| `walk_b32` | termination ≤ 114 cycles, 32-bit with retries | BOUNDED | 120 frames | 11 |
| `ctx_n3` | context table, 3 contexts: C1–C5 | **PROVED** | k = 2 | 1 |
| `ctx_n4` | context table, 4 contexts, 3-bit ids | **PROVED** | k = 2 | 1 |
| `ctx_n1` | context table, 1 context | **PROVED** | k = 2 | 1 |
| `perf` | 41 counters never wrap | **PROVED** | k = 2 | 10 |
| `flt_d3` | fault log, depth 3 | **PROVED** | k = 2 | 0 |
| `flt_d4` | fault log, depth 4 | **PROVED** | k = 2 | 1 |
| `flt_d1` | fault log, depth 1 | **PROVED** | k = 2 | 0 |
| `top_dw64` | **composed engine**, 64-bit fabric: F1–F5, bounded response, never writes (BMC) | BOUNDED | 34 frames | 301 |
| `top_dw32` | **composed engine**, 32-bit fabric (BMC) | BOUNDED | 38 frames | 299 |

**34 / 34 reachability witnesses WITNESSED** (e.g. composed engine: an OK translation at frame 19, a two-segment response at frame 30, an invalidation completing, NOT_PRESENT and PHYS_READ refusals — on a 64-bit fabric; an OK translation on a **32-bit** fabric at frame 31 of 38; TLB: a hit, an LRU eviction, a same-cycle fill+invalidation, a 1 GiB fill, a 2 MiB hit; walker: a leaf, a torn read detected and retried, a bus error, a wedge, a request refused while wedged). A property that cannot fail in a reachable situation would prove nothing; each of these shows the situation it guards is reachable. A two-segment response on a 32-bit fabric needs two 9-read walks and was **not** reached within 40 frames (one measured run, 405 s).

What each property statement covers — **exactly**:

* **TLB** (`T1`–`T5`): at most one entry matches a lookup; after an invalidation that covers a page, that page cannot hit; an invalidation in the same cycle as a fill wins; the LRU ages are a permutation of `0..N-1`; a hit returns the PPN and rights of the last fill of that tag (tag is a free-but-held symbolic value); `T6` every valid entry grants at least one right (**negative caching never**: a fault or a no-right leaf is never cached). *Not* covered: that replacement is *least*-recently-used (T4 says only that the ages are a permutation; the exact LRU behaviour is checked by the oracle in simulation), over-invalidation (T2 is one-sided: nothing stale; the oracle checks nothing *extra* is lost), and the interplay with the walker and sequencer (simulation + the bounded top check).
* **Invalidation FSM** (`V1`–`V5`): a command commits only in a COMMIT cycle entered from a DRAIN cycle in which the **ports** `pipe_idle` (the translator is idle) and, when waiting, `dma_quiet` were high (stated on the ports through shadow registers, **not** on the FSM's own `wait_ok` wire — see §9: the first version was circular and let two planted defects through); a timeout never commits; DRAIN is bounded by `DRAIN_TMO`; exactly one completion per command; the active command is stable. *Not* covered: that the operands (kind, context, page) reaching the TLB are the ones software staged (simulation + oracle).
* **Context table** (`C1`–`C5`), under the environment contract written in the module (a commit follows a pending, accepted command with the same index): a command is accepted only if every rule holds; the table changes only at a commit; an installed root is inside the fabric; an invalid id is never valid; the cycle after a commit the entry is exactly the command's (SET: the staged root and both caps, valid; CLEAR: invalid, no caps).
* **Walker** — `W1a` the fault class and leaf/pointer decision equal an independent statement of `docs/01` §5 steps 1–7 **for every 64-bit PTE and level**; `W1b` what the decode *latches* — the fault and its level, the leaf's PPN, size and the permissions `R&A&U` / `W&A&D&U`, or the next table and level on a descent — equals the independent expectation; `W5` every presented page-table read is at `table×4096 + 8×index(level) + (4 on the high word)`; `W2` state legality (levels, beats, retries, timeouts in range); `W3` the walker's own bookkeeping never shows a new read over an abandoned one; **`W6` the same discipline stated on the ports** (a presented read is never withdrawn or changed before it is accepted — SFB2 R2 — and no read is presented while an accepted one is unanswered — R6), which is what makes the wedge mechanism a checked property rather than the walker's own say-so; **`W7`** a bus error on a walk read ends the walk with `PHYS_READ`, and a validating re-read that differs from the first low word is retried or refused, never decoded; `W4` a fault reports no permission.
  **Not covered by a proof:** the *argument* that the lo-hi-lo read yields a consistent PTE under the update protocol (§6), the walk-timeout *timing* (simulation), and termination, which is **BOUNDED**, not proved: a walk ends within 24 / 42 / 114 cycles under any fabric behaviour (checked to 30 / 48 / 120 frames at `WALK_TMO = 4`).
* **Fault log / counters**: ring and count agree, POP on an empty log is a no-op; counters saturate and never wrap (unbounded).
* **Composed top level** (`top_dw64`, `top_dw32`): F1 a fabric read only inside a walk; F2 an OK response implies every static check and the context's caps; F3 response structure; F4 a refusal carries no address; F5 one response per request; bounded first response; the engine never writes — with **free CSR traffic** (contexts are programmed by the proof itself) and a **hostile SFB2 fabric** (slow, silent, erroring, arbitrary data). **BOUNDED only.**

Limits of the formal evidence, in the order they matter:

1. **The composed design is not proved**, only bounded (34 frames at `DW = 64`, 38 at `DW = 32`; each completes a full translation within its bound: frame 19 and frame 31). Module proofs use environment assumptions about neighbours (e.g. "a commit follows a command"); they hold by construction and are exercised by simulation and the bounded top check, but are not proved *across* modules.
2. **The 32-bit composed check is shallow relative to its walks.** A 32-bit translation needs 9 sequential reads; the witness for an OK translation is at frame 31 of the 38 checked, so the bound covers one completed walk and only a few cycles after it. A **two-segment** response (two walks) is *not* reachable within 40 frames on a 32-bit fabric (it is, at frame 30, on a 64-bit one), so the two-page atomicity is checked by `top_dw64`, by simulation and by the oracle, not by a 32-bit bounded proof. The 32-bit walker itself is proved at module level (`walk_dw32`, `walk_dw32n`) and bounded for termination to 120 frames.
3. **`tlb_n16` is UNKNOWN** (induction did not conclude: 51 minutes of ABC across two attempts, k ≤ 3). N = 2, 3, 4 and 8 are PROVED. The 16-entry TLB is covered by simulation (`tlb16`, §8) and the mutation campaign's `tlb8` stage only.
4. **Small instances**: widths such as a 20-bit VPN, a 3-bit PPN (TLB proof) and 4-bit PPN (walker proof); unbounded in time, not in size.
5. **Tooling**: `yosys-smtbmc` + z3 hung even on trivial queries in this environment, so the flow is ABC (`bmc3`, `ind`). Each inductive claim has a `bmc3` base case and each property a reachability witness; the proofs are only as trustworthy as ABC.

## 6. The torn-read argument (ARGUED, plus a simulation negative control)

A Sv39 PTE is 64 bits; the fabric moves 32. A walker that reads `lo` then `hi` can see a mixture if software rewrites the PTE in between. The engine reads **`lo`, `hi`, `lo` again** and compares the two `lo` reads; on a mismatch it re-reads (≤ `RETRY_MAX` times) and then reports `INVALID_PTE`.

Under break-before-make (`docs/01` §9: (1) write `lo` with V = 0, (2) write `hi`, (3) write `lo` with the new value, (4) invalidate) the high word changes **only while `lo` has V = 0**. Consider where the walker's three reads `L1, H, L2` fall relative to the writes:

* `L1` before (1) (old, valid): if `H` is read before (2) it is old and `L2` is old (equal → consistent **old**) or invalid/new (not equal → retry). If `H` is read after (2), then (1) happened before `H`, hence before `L2`, so `L2 ≠ L1` unless step (3) restored the *same* low word — in which case `(lo, H)` is exactly the new PTE (its low word equals the old one): consistent **new**.
* `L1` between (1) and (3): V = 0 → `NOT_PRESENT` (or a retry).
* `L1` after (3): the new PTE.

So the result is old, new, a transient fault, or a bounded retry that ends in `INVALID_PTE` — never a mixture. The argument assumes: each 32-bit word is written and read atomically, reads and writes are visible in one order (SFB2 is in-order, one outstanding), and software follows the protocol. **It is a sketch, not a mechanised proof.** Without the protocol (e.g. writing `hi` then `lo` without the V = 0 step) a mixture *is* possible and the engine stays safe (bounded, one response, reads only walk addresses) but returns whatever memory held.

**Evidence that the mechanism matters:** the same suite with `PTE_DOUBLE_READ = 0` on a wide-PA build (`nodbl_wide`, PA bits ≥ 34 so that old and new PTEs differ in the high word) **fails** `d_race_bbm` with mixed translations, in all three seeds; the same suite on the real configuration passes all 3 120 break-before-make races, and `torn_retries = 2 760` shows the validating read actually fired. (An earlier version of the scenario used PA bits 32/33, which live in the *low* word, and could not have shown tearing at all — the negative control was added precisely to catch such a vacuous test; see §9.)

## 7. Mutation testing

97 planted defects (`scripts/mutants.py`): 44 SAFETY, 12 STALE, 6 ORDER, 6 LIVE, 12 CSR, 17 OBS; by module: top 30, walker 24, TLB 16, invalidation 12, context 10, fault log 4, counters 1. Each applies a one-line realistic mistake to a private copy of the RTL; **the anchor of each must occur exactly once** (a mutant that does not apply is an error, never a silent no-op).
The **unmutated baseline must pass the same suite first** on every stage (base, dw64, tlb8, tmo): a suite that "kills" mutants because it fails on the baseline proves nothing.

### 7.1 Simulation campaign (`reports/mutation.md`)

**92 / 97 killed**, 5 survived, 0 not applicable. (The first campaign killed 86 / 97; six survivors were *test gaps* that were then closed: `ctx-busy-unchecked`, `tlb-inv-page-ignores-ctx`, `top-second-page-perm-ignored-hit`, `top-status-w1c-broken`, `walk-retry-unbounded`, and `flt-pop-when-empty`, which also exposed that the fault-log CSR registers were not modelled by the checker at all.)

### 7.2 The five survivors, analysed

| mutant | what it does | why simulation cannot see it | status |
|---|---|---|---|
| `tlb-fill-beats-inv` (STALE) | a TLB fill in the same cycle as an invalidation lands | unreachable through the engine: a command commits only when the translator is idle, so no fill can occur in a commit cycle | defence-in-depth of the TLB module; **killed by formal** (T3, proved) |
| `tlb-reset-keeps-valid` (STALE) | reset does not clear the TLB valid bits | no context is valid after reset, and installing a context flushes its TLB entries in the same cycle, so a stale entry can never be reached | defence-in-depth; **killed by formal** (the TLB proof gives a counterexample from a stale entry surviving reset) |
| `tlb-multi-ignored` (SAFETY) | a multi-match is not treated as a miss | a multi-match is unreachable: T1 (uniqueness) is **proved** | **equivalent mutant** under a proved invariant; formal also survives it, as it must |
| `top-fill-on-fault` (OBS) | a faulting walk asks the TLB to fill | the TLB drops any fill that grants no right and W4 (proved) says a fault reports none, so there is no behavioural difference | **equivalent mutant** (T6 + W4 give it no effect); the composed BMC could not decide it within its budget |
| `perf-wrap-not-saturate` (OBS) | counters wrap instead of saturating | needs 2³² events | not reachable in simulation; formal proves saturation of the real counters (`perf` PROVED) and the proof **breaks** on the mutant (induction fails) — a defect noticed, no counterexample, because a wrap is 2³² events away |

### 7.3 Formal mutation check and the union

Each mutant is run against the formal jobs of **its own module** (`scripts/formal.py --mutants`; walker: 64- and 32-bit; context: 4 and 3 contexts; invalidation, TLB, fault log, counters: one job each). Verdicts: **KILLED** = a counterexample from reset; **SURVIVED** = the property set still passes; **PROOF BREAKS** = the unmutated proof holds but on the mutant the induction no longer closes and BMC finds nothing (noticed, not exhibited); **UNDECIDED** = a BMC out of budget.

| scope | mutants | KILLED | SURVIVED | PROOF BREAKS | UNDECIDED |
|---|---|---|---|---|---|
| leaf modules (`reports/formal_mutants_modules.md`) | 67 | 51 | 15 | 1 | 0 |
| composed engine, `top_dw64` BMC at 90 s per ABC call (`reports/formal_mutants_top.md`) | 30 | 7 | 0 | 0 | 23 |

The composed-engine result is weak by design: 34 frames take ~300 s, the budget of 90 s reached only 27–29 frames, so most of those 23 mutants are simply *undecided* (the 7 killed are the shallow ones, frames 2–22). It is reported so nobody reads the table as "formal checks the top level".

**The union (`reports/mutation_union.md`): 94 of 97 defects are caught by simulation or by a formal counterexample.** Killed by both: 56; by simulation only: 36; by formal only: 2 (`tlb-fill-beats-inv`, `tlb-reset-keeps-valid` — the two defects the engine's own structure hides from simulation). Not caught by either: `tlb-multi-ignored` and `top-fill-on-fault` (equivalent mutants, §7.2) and `perf-wrap-not-saturate` (proof breaks).

The 15 leaf-module mutants that formal does **not** kill — all are killed by simulation — fall in clear groups, which is also the list of what the formal properties do *not* say:
* over-invalidation, which is conservative and which T2 ("nothing stale") does not forbid: `tlb-inv-page-ignores-ctx`, `tlb-inv-page-low-bit`, `inv-kind-ctx-as-all`, `inv-kind-page-as-ctx`;
* replacement-policy quality (T4 says only that ages are a permutation): `tlb-lru-no-touch-on-hit`, `tlb-victim-lowest-index`;
* equivalent under a proved invariant: `tlb-multi-ignored`;
* **which context / page reaches the TLB on an invalidation** (operand capture) — a real gap in the formal set, closed only by simulation and the oracle: `inv-page-uses-lo-only`, `inv-ctx-from-wrong-reg`;
* CSR refusal rules and completion counting: `inv-done-count-wrong`, `inv-range-check-removed`, `inv-index-check-removed`;
* fault-log record contents and counter semantics: `flt-seq-not-advanced-on-drop`, `flt-record-dev-id-swapped`, `perf-refs-not-counted`.


## 8. Expansion phase (after the baseline gate)

* **TLB 8 and 16 entries** (`tlb8`, `tlb16`): all 141 scenario-seeds each pass the oracle (which models the LRU exactly at the configured size); `tlb8` is also a stage of the mutation gate; the 8-entry TLB is formally PROVED (`tlb_n8`); the 16-entry one is **not** (UNKNOWN, §5). Hit-rate effect: `06_PERFORMANCE.md` §3.
* **Superpages** (`SUPERPAGE_EN = 1`, 2 MiB / 1 GiB leaves; alignment rule): 141 / 141 pass; the walker proof with superpages (`walk_sp`) is PROVED; the TLB's page-size masks and overlap-removal-on-fill are exercised (`d_superpage`, `sp` regression) and covered by the TLB proofs (the page-size field is a first-class input; witnesses `vac_tlb_4/5` show 1 GiB and 2 MiB entries are reachable). **Not** run as a mutation-gate stage.
* **Other instances**: 64-bit fabric, wide PA (44), 1 and 7 contexts, tiny parameters, `RETRY_MAX = 0`, 24-bit fabric — all 141 scenario-seeds pass.
* **Not done**: concurrency expansion (§2), walk cache, multi-stage, DDT, queues.

## 9. Defects found by the verification effort (and fixed)

| found by | what | fix |
|---|---|---|
| Yosys synthesis | shared `integer` loop variables inferred latches | one loop variable per block, initialised at the top |
| lint across parameterisations | `walk_root` had unused bits at small `FAB_AW`; `eff_ppn` sliced out of range at tiny `PA_W`; `FQ_DEPTH = 255` replicated 8 k flops; `RETRY_MAX = 0` produced a constant compare; zero-width parameters crash Verilator before `$error` fires | widths made parameter-driven; `FQ_DEPTH` capped at 64; illegal sets rejected at elaboration (zero-width ones are reported as a Verilator limitation, `reports/lint.md`) |
| mutation survivor | fault-log CSR registers were not modelled by the checker | full fault-log model added to `check_trace.py` |
| mutation survivors (×5) | test gaps listed in §7.1 | scenarios added; all now killed |
| regression config `retry0` | the spec claim "old, new or NOT_PRESENT" was too strong: an unstable PTE past the retry budget is a legal transient `INVALID_PTE` | `docs/01` §9 and the checker corrected |
| review of the race scenario | the tearing test used PA bits 32/33, which are in the *low* PTE word: it could not have exposed tearing | moved to PA bits ≥ 34; negative control `nodbl_wide` added and shown to fail |
| formal bring-up | `$anyconst` becomes free-every-cycle in an AIG (shadow tag must be explicitly held); reset-cycle guards missing (`&& rst_n`); a shadow flag cleared a cycle late; harness-internal checks not inductive (gated behind `BMCCHK`); the walker proof needed a strengthening invariant; ROM-inferred cells needed `memory_map` | each fixed and re-proved |
| writing this document | the walker's "decode equivalence" proof covered only the fault class and the leaf/pointer decision — **not** the permission bits, the PPN or the addresses (11 walker mutants survived it) | `W1b` and `W5` added; those mutants are now killed by counterexample (§7.3) |
| the formal mutation check | three formal properties were **circular**: V1 (commit only after an idle, quiet drain) was stated on the FSM's own `wait_ok` wire, and W3 (no read over an abandoned one) on the walker's own orphan flags, so planted defects in those very wires (`inv-no-drain`, `inv-ignores-quiet`, `walk-no-wedge-on-timeout`, `walk-withdraw-orphan-req`) passed the proof; `walk-bus-error-ignored` and `walk-no-torn-compare` also passed; context CLEAR / caps-swapped were not covered | V1 restated on the ports `pipe_idle` / `dma_quiet`; W6 (SFB2 R2 / R6 on the ports) and W7 added; C5 and T6 added; two strengthening invariants needed to make them inductive; those mutants are now killed by counterexample (§7.3) |
| writing `06_PERFORMANCE.md` | the benchmark's throughput / elapsed columns were all zero (wrong trace field) | fixed; the harness now refuses a run whose elapsed time is 0 |
| bench bring-up (several rounds) | gating of generated scenarios (commands without a completion wait were refused as busy; reset with queued operations; race claims keyed by repeating ids) and checker precision (commands lost at reset, a counter read concurrent with a request) | generator and checker corrected |

## 10. Reproduce

```
make lint          # Verilator -Wall over legal parameter sets + Yosys elaboration     -> reports/lint.md
make regress       # 11 configurations × (directed + random) × 3 seeds                   -> reports/regression.md
make mutate        # 97 mutants, baseline gate first                                      -> reports/mutation.md
make formal        # ~ 60 jobs, the 16-entry TLB alone is capped at 25 minutes            -> reports/formal.md
make formal-mutants  # the 97 defects against the formal harnesses, then the union          -> reports/formal_mutants_*.md, reports/mutation_union.md
python3 benchmarks/iommu/run_bench.py && python3 benchmarks/iommu/report.py
```

What would raise confidence most, in order: an independent review of `docs/01`; simulating the engine against the real DataFabric / DMA RTL; an unbounded proof of the composed design (state the cross-module invariants and induct); the 16-entry TLB induction with a stronger solver; FPGA / synthesis evidence for any frequency or area claim.
