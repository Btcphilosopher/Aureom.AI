# 02 — Interfaces, registers and command rules (normative)

`rtl/iommu/sf_iommu_defs.svh` is the machine-readable form of this document; `tests/iommu/check_trace.py` models §3–§5 independently.

## 1. Module map

```
                          cfg_*  (privileged, SFB2-slave style)
                             |
   req_* ---> [ sf_iommu_pagewalker ] --- request sequencer: IDLE CHECK LOOKUP WALK RESP
   rsp_* <---    |      |      |   \
   dma_quiet     |      |      |    +--> sf_iommu_faults        fault log (privileged)
                 |      |      +-------> sf_iommu_invalidation  drain-then-commit command FSM
                 |      +--------------> sf_iommu_context       trusted device-context table + its CSR slice
                 +---> sf_iommu_tlb     fully associative LRU cache         sf_iommu_perf   counters
                 +---> sf_iommu_walk_fsm   one Sv39 walk, SFB2 read master  --> m_*  (page-table READS only)
```

| file | role |
|---|---|
| `sf_iommu_pagewalker.sv` | **primary**: request sequencer, static checks, page split, CSR fabric, glue |
| `sf_iommu_context.sv` | `req_dev` → `{valid, root PPN, allow_r, allow_w}`; staging + validation of programming |
| `sf_iommu_tlb.sv` | N-entry fully associative TLB, true LRU, generic page-size masks, overlap removal on fill |
| `sf_iommu_walk_fsm.sv` | one walk: read FSM + SFB2 master + orphan (wedge) tracking + torn-read validation |
| `sf_iommu_invalidation.sv` | ALL / CTX / PAGE and context-commit commands; drain-then-commit |
| `sf_iommu_faults.sv` | bounded fault log, sequence numbers, drop counter |
| `sf_iommu_perf.sv` | 41 saturating counters |

## 2. Parameters (defaults are the baseline)

| parameter | default | meaning / limit |
|---|---|---|
| `TLB_ENTRIES` | **4** | 2..64 |
| `NUM_CTX` / `DEV_W` | 4 / 4 | contexts / width of `req_dev`; `2**DEV_W ≥ NUM_CTX`; `req_dev ≥ NUM_CTX` is refused |
| `ID_W`, `LEN_W`, `MAX_BYTES` | 4, 13, 4096 | request tag; length field (13..16); max request bytes (**≤ 4096**: a request touches ≤ 2 pages) |
| `PA_W`, `FAB_AW`, `DW` | 32, 32, 32 | physical address width (≤ 56); fabric address width (≤ 32, ≤ `PA_W`); fabric data width 32 or 64 |
| `WALK_TMO` | 64 | cycles per page-table beat before the walker gives up (4..65000) |
| `RETRY_MAX` | 2 | re-reads of an unstable PTE (0..15) |
| `PTE_DOUBLE_READ` | 1 | with `DW = 32`: read low-high-**low** |
| `SUPERPAGE_EN` | 0 | accept 2 MiB / 1 GiB leaves (expansion; see 05 §8) |
| `FQ_DEPTH` | 4 | fault-log records |
| `DRAIN_TMO_DEFAULT`, `WAIT_DMA_QUIET` | 256, 1 | reset value of `DRAIN_TMO`; wait for `dma_quiet` |

Illegal parameter sets are rejected at elaboration (`$error`): see `reports/lint.md`.

## 3. Privileged CSR port

`cfg_req_valid/ready/write`, `cfg_req_addr[7:0]` (byte address), `cfg_req_wdata[31:0]`, `cfg_priv`; response `cfg_rsp_valid/ready/rdata/error` one cycle after the
handshake, held until accepted. Register index = `addr[6:2]`; `addr[1:0] = 0`, `addr[7] = 0`, index < 31 else **bad address**.

**Access rule.** *Every* access (read or write) requires `cfg_priv = 1`. An access that is unprivileged, to a bad address, or a **write to a read-only register**
returns `cfg_rsp_error = 1`, **has no effect**, and a refused read returns `0`. (`cfg_priv` is a label: see 03 §7.)

| idx | name | acc | content |
|---|---|---|---|
| 0 | `ID` | RO | `[31:16] 0x5057 "PW"`, `[15:8] TLB_ENTRIES`, `[7:0] NUM_CTX` |
| 1 | `VERSION` | RO | `0x0001_0000` |
| 2 | `CTRL` | RW | `[0] IRQ_EN`, `[31] LOCK` (**set-only**: cleared by reset only) |
| 3 | `STATUS` | RW1C | sticky flags (§5) |
| 4 | `STATE` | RO | `[0]` command busy `[1]` request port blocked `[2]` locked `[3]` translator busy `[4]` walker busy `[5]` fabric wedged `[11:8]` last `CE_*` |
| 5 | `DRAIN_TMO` | RW | cycles a command may wait for the drain; 0 = wait forever |
| 6–8 | `INV_CTX`, `INV_VA_LO/HI` | RW | staged operands of an invalidation |
| 9 | `INV_CMD` | WO | `1` ALL, `2` CTX, `3` PAGE (the whole word must be exactly 1, 2 or 3) |
| 10 | `INV_STAT` | RO | `[0]` busy `[3:2]` last status (0 OK, 1 TMO) `[31:16]` completed-command count |
| 11 | `CTX_SEL` | RW | context being programmed / read back |
| 12–14 | `CTX_ROOT_LO/HI`, `CTX_ATTR` | RW | staged root PPN `[43:0]`; attr `[0]` allow R, `[1]` allow W, `[3:2]` mode (must be 1 = Sv39) |
| 15 | `CTX_CMD` | WO | `1` SET (install staged entry at `CTX_SEL`), `2` CLEAR |
| 16–18 | `CTX_RD_LO/HI/ATTR` | RO | the **installed** entry of `CTX_SEL` (`[31]` VALID) |
| 19 | `FLOG_CNT` | RO | `[7:0]` records held, `[15:8]` depth, `[31:16]` dropped (saturating) |
| 20–24 | `FLOG_W0..W3`, `FLOG_SEQ` | RO | head record: `W0 = {id[31:16], dev[15:8], write[6], level[5:4], cause[3:0]}`, `W1/W2` = IOVA lo/hi, `W3` = length, `SEQ` |
| 25 | `FLOG_POP` | WO | bit 0 drops the head (no effect on an empty log) |
| 26–28 | `CNT_SEL`, `CNT_DATA`, `NCNT` | RW / RO / RO | counter window (§6) |
| 29–30 | `CAPS`, `CAPS2` | RO | `{MAX_BYTES, DW, PA_W}`; flags `[0] SUPERPAGE_EN [1] WAIT_DMA_QUIET [2] PTE_DOUBLE_READ` |

## 4. Command rules (`CE_*`; numbers as MemoryGuard P104)

A command is **accepted** only if every rule below holds, in this order; otherwise it is **refused: no effect**, `STATUS.CMD_ERR` is set and `STATE[11:8]` records the code.

**`CTX_CMD`** — `LOCKED` (CTRL.LOCK) → `BUSY` (a command is in progress) → `CMD` (word ≠ 1, 2) → `INDEX` (`CTX_SEL ≥ NUM_CTX`) → for SET: `RANGE`
(mode ≠ Sv39, reserved `CTX_ATTR[31:4]`, reserved `CTX_ROOT_HI[31:12]`, or root PPN ≥ `2**(FAB_AW−12)`).
**`INV_CMD`** — `BUSY` → `CMD` (word ≠ 1, 2, 3) → `INDEX` (CTX / PAGE with `INV_CTX ≥ NUM_CTX`) → `RANGE` (PAGE with a non-canonical address: `INV_VA_HI[31:6]` not all equal).
Invalidation is **not** blocked by `LOCK`.
**Staging writes** (`CTX_ROOT_*`, `CTX_ATTR`, `INV_CTX`, `INV_VA_*`) are refused while `LOCK` (context ones) or a command is in progress (`BUSY`); `DRAIN_TMO` is refused when
locked or busy. `CTX_SEL`, `CNT_SEL` and `CTRL` are always writable (`CTRL.LOCK` is set-only).

A refused **command** does not raise `cfg_rsp_error` (the bus access itself succeeded); a refused **access** (§3) does.

Every accepted command produces **exactly one completion** (`inv_done_evt`, `STATUS.INV_DONE` or `INV_TMO`, `INV_STAT`): `OK` (applied) or `TMO` (the drain timed out: **not applied**).
A command pending at a reset is abandoned: no completion, nothing applied.

## 5. STATUS flags (write 1 to clear; bit `n` = STATUS bit `n`)

| bit | name | set when |
|---|---|---|
| 0 | `FAULT_PEND` | RO: the fault log holds a record |
| 1 | `INV_DONE` | a command completed OK |
| 2 | `INV_TMO` | a command timed out (not applied) |
| 3 | `CMD_ERR` | **any** refused access or command, except a drain timeout |
| 4 | `PRIV` | an unprivileged access (also sets `CMD_ERR`) |
| 5 | `LOCKED_REJ` | a refusal because of `LOCK` (also `CMD_ERR`) |
| 6 | `BADADDR` | a bad register address (also `CMD_ERR`) |
| 7 | `FQ_DROP` | a fault record was dropped |
| 8 | `FAB_ERR` | a page-table read failed (error response or timeout) |
| 9 | `STRAY` | a fabric response arrived with nothing owed and was discarded |
| 10 | `WEDGED` | RO live: the fabric port still owes a response to an abandoned read |

`irq = CTRL.IRQ_EN & (fault log non-empty | INV_DONE | INV_TMO)`.

## 6. Counters (`CNT_SEL` → `CNT_DATA`, 32 bit, **saturating**, cleared by reset only)

`REQS, SEGS, TLB_HIT, TLB_MISS, WALKS, WALK_CYC, WALK_REFS, WALK_FAULT, WALK_MAX, LAT_SUM, LAT_N, LAT_MAX, INV_DONE, INV_TMO, FAULTS, REQ_STALL, RSP_STALL, FILLS, EVICTS,
TORN, FAB_TMO, STRAY, CFG_REJ, CTX_COMMIT, INV_BLOCK` (indices 0..24), then `FAULT[cause]` for cause 0..15 (indices 25..40). Definitions: `rtl/iommu/sf_iommu_defs.svh`. `WALK_CYC` /
`WALK_MAX` are measured from the cycle `walk_start` is asserted to the cycle before `walk_done`; `LAT_*` from the request handshake to the first cycle `rsp_valid` is high.
`REQ_STALL` = cycles `req_valid ∧ ¬req_ready`; `RSP_STALL` = cycles `rsp_valid ∧ ¬rsp_ready`.

## 7. Request / response timing

* Request accepted in cycle `t` (`req_valid ∧ req_ready`, `req_ready = IDLE ∧ ¬cmd_busy`).
* Static checks in `t+1`; TLB lookup in `t+2` → **a TLB hit answers (`rsp_valid`) in `t+3`: 3 cycles**; a statically refused request answers in `t+2` (2 cycles).
* A miss starts a walk in `t+2`. Each page-table read costs the fabric's accept-to-response latency plus about one cycle of engine overhead, and each level adds a couple of
  cycles of decode: at `DW = 32` with the validating re-read (3 reads per level, 9 per walk) and a response 2 cycles after acceptance, a miss answers about **36 cycles** after
  the request handshake (33 in the walker), measured in 06_PERFORMANCE.md (which also gives the dependence on fabric latency). A request crossing a page boundary performs two lookups.
* A response group is held (`rsp_valid` with unchanged payload) until accepted; the request port stays closed until the **last** response is accepted.
* A command accepted in cycle `a`: `busy` from `a+1`; completion `inv_done_evt` ≥ `a+3` (DRAIN, COMMIT, DONE) after the drain.
