# 06 — Performance: what was measured, what it means, what it does not mean

> **Everything here is RTL-simulation cycles from a bench written for this project, plus Yosys generic-gate counts.** There is no clock frequency, no place-and-route, no PDK, no power model.
> Do not turn a cycle count into nanoseconds, a gate count into µm², or anything into watts.

Reproduce: `python3 benchmarks/iommu/run_bench.py` (≈ 1 minute; 137 runs) then `python3 benchmarks/iommu/report.py`; `python3 benchmarks/iommu/synth.py` for the gate counts.
Raw data: `benchmarks/iommu/results/results.csv` / `.json`; all tables below are regenerated into `benchmarks/iommu/results/summary.md` (that file is the authority if a number here ever disagrees).

## 1. Method

* Every workload is a scenario of the **same bench and the same independent checker** as the regression. `run_bench.py` raises an error rather than report a number for a run the checker rejected, or for a run whose elapsed time could not be measured.
* The numbers come from the engine's own hardware counters (read over the CSR port at the end of each run: `TLB_HIT`, `TLB_MISS`, `WALKS`, `WALK_CYC`, `WALK_REFS`, `LAT_SUM`, `REQ_STALL`, `RSP_STALL`, `INV_DONE`, …) and, where the counters do not
  separate a case (hit latency vs miss latency, invalidation cost, elapsed time), from the trace.
* **The bench memory is a simple model**: it accepts a presented page-table read with probability 85 % per cycle (SFB2 back-pressure) and answers a fixed number of cycles after acceptance (`memory latency` in the tables; 1, 2, 4 or 12). Pseudo-random, fixed seed.
  A real fabric has contention, arbitration and variable latency; this model has none of that beyond the acceptance jitter.
* Single seed, one run per point. Averages over hundreds of requests, but there are no confidence intervals: treat differences of a few percent as noise.
* The DMA side is the bench's requester: it presents the next request as soon as the port is ready (so `REQ_STALL` is "time the DMA waited", not "time the DMA was idle by choice").

## 2. Latency anatomy

Cycles from the request handshake to the first cycle `rsp_valid` is high (`LAT_*` counters / trace). 4-entry TLB.

| fabric | memory latency | hit | miss (walk) | walk cycles | reads / walk | static refusal | unmapped (faulting walk) | reads / faulting walk | 2-page hit | 2-page miss |
|---|---|---|---|---|---|---|---|---|---|---|
| DW 32, validated PTE read (baseline) | 1 | 3 | 26.48 | 23.48 | 9 | 2 | 11.50 | 3 | 4 | 50.92 |
| DW 32, validated PTE read (baseline) | 4 | 3 | 53.74 | 50.74 | 9 | 2 | 20.57 | 3 | 4 | 105.29 |
| DW 32, validated PTE read (baseline) | 12 | 3 | 125.57 | 122.57 | 9 | 2 | 44.40 | 3 | 4 | 249.09 |
| DW 32, no validating re-read (**negative control**, unsafe) | 1 | 3 | 20.03 | 17.03 | 6 | 2 | 9.36 | 2 | 4 | 38.06 |
| DW 32, no validating re-read (**negative control**, unsafe) | 4 | 3 | 38.03 | 35.03 | 6 | 2 | 15.39 | 2 | 4 | 74.26 |
| DW 32, no validating re-read (**negative control**, unsafe) | 12 | 3 | 86.08 | 83.08 | 6 | 2 | 31.37 | 2 | 4 | 170.09 |
| DW 64 | 1 | 3 | 13.57 | 10.57 | 3 | 2 | 7.18 | 1 | 4 | 24.99 |
| DW 64 | 4 | 3 | 22.43 | 19.43 | 3 | 2 | 10.16 | 1 | 4 | 43.07 |
| DW 64 | 12 | 3 | 46.55 | 43.55 | 3 | 2 | 18.18 | 1 | 4 | 91.03 |

What the table says:

* **A TLB hit costs 3 cycles, a statically refused request 2, a two-page hit 4** — independent of the fabric. These are exact in every run (the pipeline is IDLE → CHECK → LOOKUP → RESP, `docs/02` §7).
* **A miss costs about one memory round trip per page-table read, and a 32-bit walk makes 9 of them** (3 levels × `lo, hi, lo`). Each extra cycle of memory latency adds ≈ 9 cycles to a 32-bit miss and ≈ 3 to a 64-bit one
  (23.5 → 50.7 → 122.6 walk cycles at latency 1 → 4 → 12). A miss on a 32-bit fabric at a 12-cycle memory is ≈ 125 cycles; a hit is 3.
* **The torn-read protection is not free.** The validating third read raises reads per walk from 6 to 9 (+50 %) and the miss latency by 32 % (latency 1) to 46 % (latency 12) on a 32-bit fabric. What it buys is in `05_VERIFICATION.md` §6 (the
  negative control produces mixed translations without it). A 64-bit fabric needs none of it: 3 reads per walk, and a 64-bit miss is 1.9× (latency 1) to 2.7× (latency 12) faster than the 32-bit baseline.
* **A walk that faults at the top level still costs 3 reads on a 32-bit fabric** (the engine reads the whole PTE before it decodes it), and **faults are never cached**, so a device that repeatedly touches an unmapped page pays a walk every time
  (11–44 cycles here, vs. 2 for a statically refused request). That is a denial-of-service surface that this engine does not rate-limit (`03_SECURITY.md` §7).
* **There is no walk cache.** The two upper-level PTEs are re-read on every miss. A walk cache would cut a 9-read walk toward 3 reads; it was deliberately not built (`07_LIMITATIONS.md`).
  Where the cycles go is therefore clear: of a 36-cycle baseline miss, essentially all are the nine sequential fabric reads.

## 3. TLB capacity

Hit rate = `TLB_HIT / (TLB_HIT + TLB_MISS)` (per page lookup), memory latency 2, DW 32, 600 (cyclic) or 1500 (random) requests.

| pattern | TLB | 1 | 2 | 3 | 4 | 5 | 6 | 8 | 12 | 16 | 24 | 32 pages |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cyclic | 4 entries (baseline) | 0.998 | 0.997 | 0.995 | 0.993 | **0** | 0 | 0 | 0 | 0 | 0 | 0 |
| cyclic | 8 entries | 0.998 | 0.997 | 0.995 | 0.993 | 0.992 | 0.990 | 0.987 | **0** | 0 | 0 | 0 |
| cyclic | 16 entries | 0.998 | 0.997 | 0.995 | 0.993 | 0.992 | 0.990 | 0.987 | 0.980 | 0.973 | **0** | 0 |
| random | 4 entries (baseline) | 0.999 | 0.999 | 0.998 | 0.997 | 0.801 | 0.678 | 0.512 | 0.347 | 0.256 | 0.172 | 0.131 |
| random | 8 entries | 0.999 | 0.999 | 0.998 | 0.997 | 0.997 | 0.996 | 0.995 | 0.671 | 0.506 | 0.335 | 0.261 |
| random | 16 entries | 0.999 | 0.999 | 0.998 | 0.997 | 0.997 | 0.996 | 0.995 | 0.992 | 0.989 | 0.667 | 0.513 |

Average translation latency (cycles), random access:

| TLB | 4 pages | 8 pages | 16 pages | 32 pages |
|---|---|---|---|---|
| 4 entries | 3.09 | 18.88 | 27.28 | 31.29 |
| 8 entries | 3.09 | 3.17 | 19.13 | 27.07 |
| 16 entries | 3.09 | 3.17 | 3.34 | 18.83 |

* **Within capacity the engine hits ≈ 99–100 %** (the residual is the cold misses of the run). **Beyond capacity, true LRU on a cyclic sweep collapses to 0 %** — the classic LRU pathology, and a real risk for streaming DMA over a buffer
  one page larger than the TLB. On random access the hit rate degrades gracefully to about `entries / pages` (4/8 → 0.51, 4/16 → 0.26).
* Zipf-weighted access (a few hot pages, long tail): 4 entries 0.64 / 0.44 / 0.32 at 8 / 16 / 32 pages; 8 entries 0.995 / 0.70 / 0.52; 16 entries 0.995 / 0.99 / 0.74.
* The 8- and 16-entry results are from the expansion phase, run after the 4-entry baseline passed (`05_VERIFICATION.md` §7). Which TLB size is right depends entirely on the DMA's working set and access pattern, which this project does not know.

## 4. Sustained throughput of a one-request-at-a-time engine

Requests per 1000 cycles, back-to-back requests from one requester (the port is closed from acceptance until the last response is accepted):

| workload | DW 32, latency 1 | DW 64, latency 1 | DW 32, latency 4 | DW 64, latency 4 |
|---|---|---|---|---|
| all TLB hits | 245.3 | 248.1 | 240 | 246.3 |
| every request a miss | 36.4 | 68.7 | 18.3 | 42.7 |
| two-page request, both hit | 154.3 | 161.6 | 142.9 | 157 |
| two-page request, both miss | 18.9 | 37.1 | 9.3 | 22.2 |
| statically refused | 334.4 | 334.4 | 334.4 | 334.4 |
| unmapped (walk, then NOT_PRESENT) | 80.1 | 122.4 | 46.4 | 89.7 |

All-hit traffic runs at about one request per 4 cycles (3 cycles of latency plus the handshake turnaround); this is the price of the baseline's concurrency of one. It is a property of the sequencer, not of the TLB: hit-under-miss, a request queue
or a pipelined lookup would raise it. **None of those were built** — the brief asks for capacity and concurrency to be expanded only after the memory-safety tests pass, and this project stops at the baseline's concurrency (`07_LIMITATIONS.md`).

## 5. Invalidation

4-entry TLB, DW 32, latency 2. "Command → completion" runs from the CSR write that accepts the command to `INV_DONE`.

| workload | requests | hit rate | avg latency | command → completion (avg / max) | DMA stall cycles |
|---|---|---|---|---|---|
| no invalidation | 400 | 0.990 | 3.32 | 3 / 3 | 1325 |
| page invalidation every 16 requests | 400 | 0.930 | 5.26 | 3 / 3 | 2031 |
| every 4 requests | 400 | 0.743 | 11.34 | 3 / 3 | 996 |
| after every request | 400 | 0 | 35.59 | 3 / 3 | 0 |
| command 3 cycles after a **miss** was accepted | 60 | 0 | 35.32 | **17.14 / 21** | 985 |

* On an idle translator a command completes in **3 cycles** (DRAIN, COMMIT, DONE). If it arrives behind a walk it first waits for the walk **and for the response to be accepted** (that is the ordering guarantee, `01_SPEC_SUBSET.md` §8): 17 cycles on average, 21 at most here.
  The wait is bounded by `DRAIN_TMO` (default 256 cycles; a timeout reports failure and applies nothing).
* The cost of invalidation is not the command; it is the entries it destroys. A page invalidation drops only the named page, so the hit rate falls smoothly with the invalidation rate (0.99 → 0.93 → 0.74).
* Requests presented while a command is pending are held off (`INV_BLOCK` / `REQ_STALL`), never accepted into the old TLB state.

## 6. Response back-pressure

300 requests over 3 pages (all but the first hit), 4-entry TLB, DW 32.

| consumer | avg latency | response stall cycles | request stall cycles | requests / 1000 cycles |
|---|---|---|---|---|
| `rsp_ready` always high | 3.32 | 0 | 993 | 231.7 |
| high 50 % of cycles | 3.32 | 238 | 1230 | 195.8 |
| high 15 % of cycles | 3.32 | 1617 | 2606 | 103.1 |

The first-response latency is unchanged (the engine does not wait for `rsp_ready` to start), but a slow consumer holds the engine's single response register and therefore the request port; throughput falls with it. A response group is held until accepted (never dropped).

## 7. Cost: Yosys generic-gate estimates (not area)

`benchmarks/iommu/results/synth.md`. Yosys 0.33 `synth -flatten` to generic cells — comparable **only with each other**.

| configuration | generic cells | flip-flops |
|---|---|---|
| baseline: 4-entry TLB, 4 contexts, DW 32 | 23 453 | 3 075 |
| DW 64 | 22 909 | 3 033 |
| TLB 8 | 27 322 | 3 307 |
| TLB 16 | 33 882 | 3 779 |
| 4 entries + superpages | 23 445 | 3 075 |
| 16 contexts | 27 980 | 3 363 |
| `PA_W` 44 | 23 846 | 3 159 |
| fault log 16 deep | 35 171 | 4 569 |

| baseline module | generic cells | flip-flops |
|---|---|---|
| `sf_iommu_perf` (41 counters) | 9 819 | 1 312 |
| `sf_iommu_faults` (4-record log) | 4 327 | 551 |
| `sf_iommu_tlb` | 3 263 | 224 |
| `sf_iommu_context` | 1 913 | 220 |
| `sf_iommu_pagewalker` (sequencer, CSR, glue) | 1 843 | 360 |
| `sf_iommu_walk_fsm` | 1 177 | 195 |
| `sf_iommu_invalidation` | 1 224 | 213 |

* **The 41 saturating 32-bit counters are ≈ 42 % of the baseline's gates and 43 % of its flip-flops**, more than the TLB and walker together. The brief asked for these counters; a production build would keep only the few it needs and narrow them. This is the largest, cheapest saving available.
* Going from 4 to 8 TLB entries adds ≈ 3 900 cells (+16.5 %); to 16 adds ≈ 10 400 (+44.5 %).
* These counts say nothing about timing closure, routing, memory macros or power. A TLB of this size would normally be built from a CAM or register file the generic flow does not model.

## 8. What these numbers do not show

* No real DMA, fabric, DRAM or contention: only the bench's requester and fixed-latency memory.
* No concurrency: a throughput limit of **one** translation at a time is a design choice of the baseline, not a measured ceiling of the architecture.
* No multi-tenant workload, no TLB interference between contexts beyond the directed tests.
* No power, area, frequency; a cycle is not a time.
