// =============================================================================
// SilicaFlux TENSORCORE 07 :: tb_tdma_gemm
// End-to-end integration: tiled INT8 GEMMs on the UNMODIFIED TC02 array with
// TC03 operands and TC04 accumulation, where EVERY operand block and EVERY
// result tile moves through tensor_dma_adapter over one SFB2 port
// (tdma_tile_system).  Programs come from model/gemm_gen.py; the expected C is
// a plain-Python matmul.  Checks: every descriptor completes once with OK and
// the reference byte count; every job completes; no compute-path error flag;
// no output-buffer flag; the SFB2 protocol checker; R2 hold; and the WHOLE
// memory at the end (C exact, everything else - A, B, row padding, canaries -
// unchanged).  The memory model performs a write only when it responds.
// =============================================================================
`timescale 1ns/1ps
`include "tdma_defs.svh"

module tb_tdma_gemm;
  parameter int NS = 2, ASB = 1024, BSB = 1024, MAXOUT = 4, LOCOUT = 4, RCAP = 32, QD = 4;
  parameter int TPM = 1, OPM = 0, ONB = 2;
  parameter int MEM_BASE = 32'h1000_0000, MEM_BYTES = 1 << 16;
  localparam int WB = 4, DW = 32, NPC = `TDMA_NUM_PC, MAXJ = 4096, MAXD = 8192;

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; if (errors <= 30) begin $write("ERROR cyc=%0d: ", cyc); $display args ; end end

  int unsigned rs [0:7];
  function automatic int unsigned rnd(input int s);
    int unsigned x;
    x = rs[s]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[s] = x; return x;
  endfunction
  function automatic bit pct(input int s, input int p);
    return (p > 0) && (int'(rnd(s) % 100) < p);
  endfunction

  // ------------------------------------------------------------ DUT
  logic prefetch = 1'b0, desc_valid = 1'b0, desc_ready, cpl_valid, cpl_ready, job_valid = 1'b0, job_ready;
  logic [`TDMA_DESC_W-1:0] desc_data = '0;
  logic [7:0] cpl_id; logic [3:0] cpl_code; logic [31:0] cpl_bytes;
  logic [15:0] j_tag = '0, j_nch = '0, j_chunk = '0; logic [2:0] j_m = '0, j_n = '0; logic [16:0] j_k = '0;
  logic [39:0] j_kt = '0; logic [31:0] j_aa = '0, j_lda = '0, j_ba = '0, j_ldb = '0;
  logic req_valid, req_ready, req_write, rsp_valid, rsp_ready, rsp_error;
  logic [31:0] req_addr, req_wdata, rsp_rdata; logic [3:0] req_wstrb;
  logic dma_busy, cmp_busy, ev_compute; logic [4:0] cmp_err; logic [31:0] jobs_done;
  logic [NS*2-1:0] op_state; logic [3:0] ob_state; logic [5:0] ob_flags; logic [1:0] ob_conf;
  logic [NPC*32-1:0] perf_cnt;

  tdma_tile_system #(
    .TILE_M(4), .TILE_N(4), .WB(4), .NUM_SETS(NS), .A_SET_BYTES(ASB), .B_SET_BYTES(BSB), .A_BANKS(4), .B_BANKS(2),
    .TOB_PORT(TPM), .TOB_RL(1), .O_SETS(2), .O_SET_BYTES(256), .O_LD(16), .O_BANKS(ONB), .O_PORT(OPM), .NUM_SLOTS(2),
    .MEM_LO(33'(MEM_BASE)), .MEM_HI(33'(MEM_BASE) + 33'(MEM_BYTES)), .MAX_OUT(MAXOUT), .LOC_OUT(LOCOUT),
    .RCAP(RCAP), .QDEPTH(QD)
  ) dut (
    .clk(clk), .rst_n(rst_n), .cfg_prefetch(prefetch),
    .desc_valid(desc_valid), .desc_ready(desc_ready), .desc_data(desc_data),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_id(cpl_id), .cpl_code(cpl_code), .cpl_bytes(cpl_bytes),
    .job_valid(job_valid), .job_ready(job_ready), .job_tag(j_tag), .job_m(j_m), .job_n(j_n), .job_k(j_k),
    .job_k_total(j_kt), .job_n_chunks(j_nch), .job_chunk(j_chunk), .job_a_addr(j_aa), .job_lda(j_lda),
    .job_b_addr(j_ba), .job_ldb(j_ldb),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr),
    .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .array_stall_i(1'b0), .dma_busy(dma_busy), .cmp_busy(cmp_busy), .cmp_err(cmp_err), .jobs_done(jobs_done),
    .ev_compute(ev_compute), .op_state(op_state), .ob_state(ob_state), .ob_flags(ob_flags), .ob_conflict(ob_conf),
    .perf_clear(1'b0), .perf_cnt(perf_cnt));

  logic [31:0] pc_viol, pc_nreq, pc_nrsp, pc_out;
  sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(MAXOUT), .NAME("gemm_sfb")) u_chk (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write),
    .req_addr(req_addr), .req_wdata(req_wdata), .req_wstrb(req_wstrb), .rsp_valid(rsp_valid),
    .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .violations(pc_viol), .n_req(pc_nreq), .n_rsp(pc_nrsp), .outstanding(pc_out));

  // ------------------------------------------------------------ SFB2 memory model (write performed at response, R7)
  logic [7:0] mem  [0:MEM_BYTES-1];
  logic [8:0] mexp [0:MEM_BYTES-1];
  int lat_min = 1, lat_max = 1, bp = 0, xbar = 0, cpl_bp = 0;
  localparam int QN = 64;
  logic q_w [0:QN-1]; logic [31:0] q_a [0:QN-1], q_d [0:QN-1]; logic [3:0] q_s [0:QN-1]; longint q_t [0:QN-1];
  int q_head = 0, q_tail = 0, outst_q = 0;
  longint n_rd = 0, n_wr = 0, n_cmp = 0;
  logic rsp_v_q = 1'b0, rsp_e_q = 1'b0, rdy_q = 1'b0; logic [31:0] rsp_d_q = '0;
  assign rsp_valid = rsp_v_q; assign rsp_error = rsp_e_q; assign rsp_rdata = rsp_d_q;
  assign req_ready = rdy_q && rst_n && (outst_q < QN - 2) &&
                     (xbar == 0 || outst_q == 0 || (outst_q == 1 && rsp_v_q && rsp_ready));
  always @(posedge clk)
    if (!rst_n) outst_q <= 0;
    else        outst_q <= outst_q + ((req_valid && req_ready) ? 1 : 0) - ((rsp_v_q && rsp_ready) ? 1 : 0);
  function automatic bit inwin(input logic [31:0] a);
    return (a >= MEM_BASE) && (64'(a) < 64'(MEM_BASE) + 64'(MEM_BYTES));
  endfunction
  always @(posedge clk) begin
    if (!rst_n) begin
      q_head = 0; q_tail = 0; rsp_v_q <= 1'b0; rsp_e_q <= 1'b0; rdy_q <= 1'b0;
    end else begin
      if ((!rsp_v_q || rsp_ready) && q_head != q_tail && cyc >= q_t[q_head % QN]) begin
        int h; logic [31:0] o; logic e;
        h = q_head % QN; q_head = q_head + 1; o = q_a[h] - MEM_BASE; e = !inwin(q_a[h]);
        rsp_v_q <= 1'b1; rsp_e_q <= e;
        if (q_w[h]) begin
          rsp_d_q <= '0;
          if (!e) for (int b = 0; b < 4; b++) if (q_s[h][b]) mem[o + b] = q_d[h][8*b +: 8];
        end else rsp_d_q <= e ? 32'd0 : {mem[o+3], mem[o+2], mem[o+1], mem[o]};
      end else if (rsp_v_q && rsp_ready) rsp_v_q <= 1'b0;
      if (req_valid && req_ready) begin
        int t; t = q_tail % QN;
        q_w[t] = req_write; q_a[t] = req_addr; q_d[t] = req_wdata; q_s[t] = req_wstrb;
        q_t[t] = cyc + lat_min + ((lat_max > lat_min) ? longint'(rnd(1) % (lat_max - lat_min + 1)) : 0);
        q_tail = q_tail + 1;
        if (req_addr[1:0] != 2'b00 || !inwin(req_addr)) `ERR(("bad SFB2 address %h", req_addr))
        if (req_write) n_wr = n_wr + 1; else n_rd = n_rd + 1;
      end
      rdy_q <= !pct(2, bp);
      if (ev_compute) n_cmp = n_cmp + 1;
    end
  end
  logic pv = 1'b0, pw; logic [31:0] pa, pd; logic [3:0] ps;
  always @(posedge clk) begin
    if (!rst_n) pv <= 1'b0;
    else begin
      if (pv && !(req_valid && req_write == pw && req_addr == pa && req_wstrb == ps && (!pw || req_wdata == pd)))
        `ERR(("SFB2 R2: request changed before acceptance"))
      pv <= req_valid && !req_ready; pw <= req_write; pa <= req_addr; pd <= req_wdata; ps <= req_wstrb;
    end
  end

  // ------------------------------------------------------------ completions
  int n_cpl = 0; longint cpl_sum = 0, exp_sum = 0;
  always @(posedge clk) cpl_ready <= !pct(4, cpl_bp);
  always @(posedge clk) if (rst_n && cpl_valid && cpl_ready) begin
    n_cpl = n_cpl + 1; cpl_sum = cpl_sum + cpl_bytes;
    if (cpl_code != `TDMA_C_OK) `ERR(("descriptor id %0d completed with code %0d", cpl_id, cpl_code))
  end

  // ------------------------------------------------------------ program
  string dir; int fd, rc, n_desc = 0, n_jobs = 0;
  logic [31:0] f [0:17];
  logic [`TDMA_DESC_W-1:0] dq [0:MAXD-1];
  logic [31:0] jq [0:MAXJ-1][0:10];
  bit prog_done = 0, drain_ok = 0;
  longint maxcyc = 5_000_000, t_first = -1;
  always @(posedge clk)
    drain_ok <= prog_done && (n_cpl == n_desc) && (int'(jobs_done) == n_jobs) && !dma_busy && !cmp_busy &&
                !cpl_valid && op_state == '0 && ob_state == '0 && q_head == q_tail && !rsp_v_q;
  always @(posedge clk) if (cyc == maxcyc + 100) begin
    `ERR(("WATCHDOG: cpl %0d/%0d jobs %0d/%0d busy=%0d/%0d op=%b ob=%b", n_cpl, n_desc, jobs_done, n_jobs, dma_busy,
          cmp_busy, op_state, ob_state))
    $display("RESULT FAIL"); $finish;
  end

  // job driver (independent of the descriptor stream, as a compute scheduler would be)
  initial begin
    @(posedge rst_n);
    while (!prog_done) @(posedge clk);
    for (int j = 0; j < n_jobs; j++) begin
      @(negedge clk);
      job_valid <= 1'b1; j_tag <= jq[j][0][15:0]; j_m <= jq[j][1][2:0]; j_n <= jq[j][2][2:0]; j_k <= jq[j][3][16:0];
      j_kt <= 40'(jq[j][4]); j_nch <= jq[j][5][15:0]; j_chunk <= jq[j][6][15:0]; j_aa <= jq[j][7]; j_lda <= jq[j][8];
      j_ba <= jq[j][9]; j_ldb <= jq[j][10];
      @(posedge clk);
      while (!job_ready) @(posedge clk);
      @(negedge clk) job_valid <= 1'b0;
    end
  end

  initial begin
    int s, p;
    if (!$value$plusargs("dir=%s", dir)) dir = ".";
    if (!$value$plusargs("seed=%d", s)) s = 1;
    for (int i = 0; i < 8; i++) rs[i] = 32'h9E37_79B9 * (s + i * 7919) + 32'h1234_5 + i;
    void'($value$plusargs("lat_min=%d", lat_min)); void'($value$plusargs("lat_max=%d", lat_max));
    void'($value$plusargs("bp=%d", bp)); void'($value$plusargs("xbar=%d", xbar));
    void'($value$plusargs("cpl_bp=%d", cpl_bp)); void'($value$plusargs("maxcyc=%d", maxcyc));
    if ($value$plusargs("prefetch=%d", p)) prefetch = (p != 0);
    if (lat_max < lat_min) lat_max = lat_min;
    $readmemh({dir, "/mem_init.hex"}, mem);
    $readmemh({dir, "/mem_exp.hex"}, mexp);
    fd = $fopen({dir, "/prog.txt"}, "r"); rc = 18;
    while (!$feof(fd) && rc == 18) begin
      rc = $fscanf(fd, "%h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h\n", f[0], f[1], f[2], f[3], f[4], f[5],
                   f[6], f[7], f[8], f[9], f[10], f[11], f[12], f[13], f[14], f[15], f[16], f[17]);
      if (rc == 18 && f[0] == 32'd1) begin
        logic [`TDMA_DESC_W-1:0] v; v = '0;
        v[`TDMA_D_ID] = f[1][7:0]; v[`TDMA_D_KIND] = f[2][1:0]; v[`TDMA_D_FLAGS] = f[3][5:0]; v[`TDMA_D_SRC] = f[4];
        v[`TDMA_D_DST] = f[5]; v[`TDMA_D_SSTRIDE] = f[6]; v[`TDMA_D_DSTRIDE] = f[7]; v[`TDMA_D_ROWLEN] = f[8][15:0];
        v[`TDMA_D_ROWS] = f[9][15:0]; v[`TDMA_D_VER] = f[10][7:0]; v[`TDMA_D_RSVD] = f[11][7:0];
        if (f[12] != 32'd0) `ERR(("GEMM program contains a descriptor expected to fail"))
        exp_sum = exp_sum + f[13];
        dq[n_desc] = v; n_desc = n_desc + 1;
      end
    end
    $fclose(fd);
    fd = $fopen({dir, "/jobs.txt"}, "r"); rc = 11;
    while (!$feof(fd) && rc == 11) begin
      rc = $fscanf(fd, "%h %h %h %h %h %h %h %h %h %h %h\n", f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9], f[10]);
      if (rc == 11) begin for (int i = 0; i < 11; i++) jq[n_jobs][i] = f[i]; n_jobs = n_jobs + 1; end
    end
    $fclose(fd);
    repeat (4) @(posedge clk);
    @(negedge clk) rst_n <= 1'b1;
    repeat (2) @(posedge clk);
    prog_done = 1;
    t_first = cyc;
    for (int k = 0; k < n_desc; k++) begin
      @(negedge clk) begin desc_valid <= 1'b1; desc_data <= dq[k]; end
      @(posedge clk);
      while (!desc_ready) @(posedge clk);
      @(negedge clk) desc_valid <= 1'b0;
    end
    while (!drain_ok && cyc < maxcyc) @(posedge clk);
    begin longint t_end; t_end = cyc;
      repeat (10) @(posedge clk);
      if (cmp_err != 0) `ERR(("compute sequencer error flags %b", cmp_err))
      if (ob_flags != 0) `ERR(("output buffer tile flags %b", ob_flags))
      if (pc_viol != 0) `ERR(("sfb_protocol_checker: %0d violations", pc_viol))
      if (cpl_sum != exp_sum) `ERR(("completed bytes %0d, reference %0d", cpl_sum, exp_sum))
      begin int bad, first; bad = 0; first = -1;
        for (int i = 0; i < MEM_BYTES; i++) if (!mexp[i][8] && {1'b0, mem[i]} != mexp[i]) begin bad++; if (first < 0) first = i; end
        if (bad != 0) `ERR(("final memory: %0d bytes differ (first at %h: %h expected %h)", bad, MEM_BASE + first,
                            mem[first], mexp[first][7:0]))
      end
      for (int i = 0; i < NPC; i++) $display("PERF %0d %0d", i, perf_cnt[i*32 +: 32]);
      $display("STATS desc=%0d cpl=%0d jobs=%0d sfb_rd=%0d sfb_wr=%0d compute_cyc=%0d cycles=%0d", n_desc, n_cpl, jobs_done,
               n_rd, n_wr, n_cmp, t_end - t_first);
    end
    $display("RESULT %s", (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule
