// =============================================================================
// SilicaFlux TENSORCORE 07 :: tb_tdma_xbar
// The tensor DMA adapter (+ TC03 + tensor output buffer) as master 3 of the
// REAL DataFabric sfb_crossbar, contending with:
//   master 0  CPU traffic: random loads/stores (self-checking shadow) to private
//             regions in SRAM0 and in the tile scratchpad; also initialises and
//             finally reads back all memory through the fabric (no backdoor)
//   master 1  vector-engine stream: back-to-back writes then verifying reads (SRAM1)
//   master 2  another DMA engine: DataFabric dma_burst_engine (unmodified), a
//             4 KiB SRAM0 -> SRAM1 copy, repeated
//   slaves    SRAM0 / SRAM1 = DataFabric sfb_sram_slave (unmodified, SRAM Wrapper
//             Library), TSPM = Module 04 hpc_scratchpad (unmodified, 4 banks):
//             port 0 on the fabric, ports 1-2 driven by two vector lanes doing random
//             self-checking accesses (scratchpad bank contention)
// Arbitration is the crossbar's (ARB = 1 round robin, 0 fixed priority with the
// tensor DMA LOWEST).  Checks: tensor completions vs the reference, operand-set
// contents at compute time (TC03 shadow), every generator's own data, the copy,
// the whole memory read back through the fabric, the DataFabric protocol checker
// on all four master links, no decode error, and that every master progressed.
// Reports the tensor DMA's worst request wait (starvation bound).
// =============================================================================
`timescale 1ns/1ps
`include "tdma_defs.svh"
`include "tob_defs.svh"
`include "hpc_spm_defs.svh"
`include "sram_defs.svh"

module tb_tdma_xbar;
  parameter int ARB = 1, SRL = 1, MAXOUT = 4;
  parameter int CPU_PCT = 60, VEC_PCT = 80, LANE_PCT = 70;
  localparam int WB = 4, NS = 2, ASB = 1024, BSB = 1024, OS = 2, OSB = 256, OLD = 16, TM = 4, TN = 4;
  localparam int MEM_BASE = 32'h1000_0000, KB = 1024, MEM_BYTES = 48 * KB;
  localparam int AT = NS * ASB, BT = NS * BSB, REGION = (AT > BT) ? AT : BT, WIN = REGION + BT;
  localparam int NM = 4, NSL = 3, MAXD = 300, MAXSEAL = 96, MAXT = 128, NPC = `TDMA_NUM_PC;
  localparam logic [31:0] S0 = MEM_BASE, S1 = MEM_BASE + 16 * KB, S2 = MEM_BASE + 32 * KB;

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; if (errors <= 40) begin $write("ERROR cyc=%0d: ", cyc); $display args ; end end

  int unsigned rs [0:15];
  function automatic int unsigned rnd(input int s);
    int unsigned x;
    x = rs[s]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[s] = x; return x;
  endfunction
  function automatic bit pct(input int s, input int p);
    return (p > 0) && (int'(rnd(s) % 100) < p);
  endfunction

  // ============================================================ crossbar
  logic [NM-1:0] m_rqv, m_rqr, m_rqw, m_rsv, m_rsr, m_rse;
  logic [NM*32-1:0] m_rqa, m_rqd, m_rsd;
  logic [NM*4-1:0]  m_rqs;
  logic [NSL-1:0] s_rqv, s_rqr, s_rqw, s_rsv, s_rsr, s_rse;
  logic [NSL*32-1:0] s_rqa, s_rqd, s_rsd;
  logic [NSL*4-1:0]  s_rqs;
  logic x_err; logic [31:0] x_err_a; logic [1:0] x_err_m; logic x_err_w;
  logic [NM-1:0] ev_acc, ev_stall, ev_loss, ev_rstall;
  sfb_crossbar #(.NM(NM), .NS(NSL), .AW(32), .DW(32), .ARB_MODE(ARB), .CHECK_ALIGN(1),
                 .SLV_BASE({S2, S1, S0}), .SLV_MASK({32'hFFFF_C000, 32'hFFFF_C000, 32'hFFFF_C000}),
                 .MST_SLV_EN({(NM*NSL){1'b1}})) u_xbar (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_rqv), .m_req_ready(m_rqr), .m_req_write(m_rqw), .m_req_addr(m_rqa), .m_req_wdata(m_rqd),
    .m_req_wstrb(m_rqs), .m_rsp_valid(m_rsv), .m_rsp_ready(m_rsr), .m_rsp_rdata(m_rsd), .m_rsp_error(m_rse),
    .s_req_valid(s_rqv), .s_req_ready(s_rqr), .s_req_write(s_rqw), .s_req_addr(s_rqa), .s_req_wdata(s_rqd),
    .s_req_wstrb(s_rqs), .s_rsp_valid(s_rsv), .s_rsp_ready(s_rsr), .s_rsp_rdata(s_rsd), .s_rsp_error(s_rse),
    .err_evt(x_err), .err_addr(x_err_a), .err_master(x_err_m), .err_write(x_err_w),
    .ev_req_accept(ev_acc), .ev_req_stall(ev_stall), .ev_arb_loss(ev_loss), .ev_rsp_stall(ev_rstall));
  always @(posedge clk) if (rst_n && x_err) `ERR(("crossbar decode error: master %0d addr %h", x_err_m, x_err_a))

  // protocol checkers on every master link (DataFabric, unmodified)
  for (genvar m = 0; m < NM; m++) begin : g_chk
    logic [31:0] viol, nrq, nrs, outs;
    sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(1), .NAME("xbar_m")) u_c (
      .clk(clk), .rst_n(rst_n), .req_valid(m_rqv[m]), .req_ready(m_rqr[m]), .req_write(m_rqw[m]),
      .req_addr(m_rqa[m*32 +: 32]), .req_wdata(m_rqd[m*32 +: 32]), .req_wstrb(m_rqs[m*4 +: 4]),
      .rsp_valid(m_rsv[m]), .rsp_ready(m_rsr[m]), .rsp_rdata(m_rsd[m*32 +: 32]), .rsp_error(m_rse[m]),
      .violations(viol), .n_req(nrq), .n_rsp(nrs), .outstanding(outs));
  end

  // ============================================================ slaves: SRAM0, SRAM1 (DataFabric), TSPM (Module 04)
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] tst0, tst1;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_sram_slave #(.DW(32), .DEPTH(4096), .READ_LATENCY(SRL), .BACKEND(`SRAM_BACKEND_GENERIC)) u_sram0 (
    .clk(clk), .rst_n(rst_n), .req_valid(s_rqv[0]), .req_ready(s_rqr[0]), .req_write(s_rqw[0]), .req_addr(s_rqa[31:0]),
    .req_wdata(s_rqd[31:0]), .req_wstrb(s_rqs[3:0]), .rsp_valid(s_rsv[0]), .rsp_ready(s_rsr[0]), .rsp_rdata(s_rsd[31:0]),
    .rsp_error(s_rse[0]), .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr(12'd0), .tst_wdata(32'd0),
    .tst_rdata(tst0));
  sfb_sram_slave #(.DW(32), .DEPTH(4096), .READ_LATENCY(SRL), .BACKEND(`SRAM_BACKEND_GENERIC)) u_sram1 (
    .clk(clk), .rst_n(rst_n), .req_valid(s_rqv[1]), .req_ready(s_rqr[1]), .req_write(s_rqw[1]), .req_addr(s_rqa[63:32]),
    .req_wdata(s_rqd[63:32]), .req_wstrb(s_rqs[7:4]), .rsp_valid(s_rsv[1]), .rsp_ready(s_rsr[1]), .rsp_rdata(s_rsd[63:32]),
    .rsp_error(s_rse[1]), .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr(12'd0), .tst_wdata(32'd0),
    .tst_rdata(tst1));

  // TSPM: port 0 = fabric (direct SFB2 wiring, Module 04 doc 08 §1), ports 1-2 = vector lanes
  logic [2:0] tq_v, tq_r, tq_we, tr_v, tr_r, tr_e, tr_we;
  logic [3*32-1:0] tq_a, tq_d, tr_d;
  logic [3*4-1:0] tq_s, tr_syn;
  logic [3*8-1:0] tq_t, tr_t;
  logic [3*3-1:0] tr_c;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2:0] sp_acc, sp_iss, sp_conf, sp_cst, sp_err, sp_ecc; logic [4*2-1:0] sp_bops; logic [3:0] sp_bconf;
  logic [31:0] sp_cyc, sp_eccn; logic [3*32-1:0] sp_a, sp_i, sp_c, sp_cf, sp_w, sp_e; logic [4*32-1:0] sp_b; logic sp_busy;
  /* verilator lint_on UNUSEDSIGNAL */
  assign tq_v[0] = s_rqv[2]; assign tq_we[0] = s_rqw[2]; assign tq_a[31:0] = s_rqa[95:64];
  assign tq_d[31:0] = s_rqd[95:64]; assign tq_s[3:0] = s_rqs[11:8]; assign tq_t[7:0] = 8'd0;
  assign s_rqr[2] = tq_r[0]; assign s_rsv[2] = tr_v[0]; assign tr_r[0] = s_rsr[2];
  assign s_rsd[95:64] = tr_d[31:0]; assign s_rse[2] = tr_e[0];
  hpc_scratchpad #(.NUM_PORTS(3), .CAPACITY_BYTES(16 * KB), .NUM_BANKS(4), .DATA_WIDTH(32), .ADDR_WIDTH(32),
                   .BASE_ADDR(64'(S2)), .READ_LATENCY(1), .BYTE_WE(1), .PORT_MODE(`HPC_SPM_PORT_1RW),
                   .MAP(`HPC_SPM_MAP_LOW), .ARB(`HPC_SPM_ARB_RR), .QUEUE_DEPTH(0), .RSP_FIFO_DEPTH(2), .WRITE_ACK(1),
                   .TAG_W(8), .ECC_MODE(`HPC_SPM_ECC_NONE), .BACKEND(`SRAM_BACKEND_GENERIC), .MACRO(0), .PERF_EN(0)) u_tspm (
    .clk(clk), .rst_n(rst_n),
    .req_valid(tq_v), .req_ready(tq_r), .req_we(tq_we), .req_addr(tq_a), .req_wdata(tq_d), .req_wstrb(tq_s), .req_tag(tq_t),
    .rsp_valid(tr_v), .rsp_ready(tr_r), .rsp_rdata(tr_d), .rsp_err(tr_e), .rsp_err_code(tr_c), .rsp_we(tr_we),
    .rsp_tag(tr_t), .rsp_ecc_syn(tr_syn),
    .ev_accept(sp_acc), .ev_issue(sp_iss), .ev_conflict(sp_conf), .ev_credit_stall(sp_cst), .ev_error(sp_err),
    .ev_ecc_err(sp_ecc), .ev_bank_ops(sp_bops), .ev_bank_conflict(sp_bconf),
    .perf_clear(1'b0), .perf_cycles(sp_cyc), .perf_accept(sp_a), .perf_issue(sp_i), .perf_complete(sp_c),
    .perf_conflict(sp_cf), .perf_wait(sp_w), .perf_error(sp_e), .perf_bank_ops(sp_b), .perf_ecc_err(sp_eccn), .busy(sp_busy));

  // ============================================================ master 2: DataFabric dma_burst_engine (unmodified)
  logic d_start = 1'b0, d_busy, d_done, d_fail, d_stall;
  logic [3:0] d_code; logic [31:0] d_eaddr, d_bytes; logic [2:0] d_state; logic [7:0] d_lvl;
  dma_burst_engine #(.DW(32), .MAX_LEN_LOG2(24), .FIFO_DEPTH(8), .BURST(8), .DUAL_PORT(0), .MAX_OUT(2)) u_odma (
    .clk(clk), .rst_n(rst_n), .start(d_start), .abort(1'b0), .cfg_src(S0 + 32'(8 * KB)), .cfg_dst(S1 + 32'(4 * KB)),
    .cfg_len(32'(4 * KB)), .busy(d_busy), .done(d_done), .fail(d_fail), .err_code(d_code), .err_addr(d_eaddr),
    .bytes_done(d_bytes), .state(d_state), .ev_stall(d_stall), .fifo_level(d_lvl),
    .req_valid(m_rqv[2]), .req_ready(m_rqr[2]), .req_write(m_rqw[2]), .req_addr(m_rqa[95:64]), .req_wdata(m_rqd[95:64]),
    .req_wstrb(m_rqs[11:8]), .rsp_valid(m_rsv[2]), .rsp_ready(m_rsr[2]), .rsp_rdata(m_rsd[95:64]), .rsp_error(m_rse[2]));
  int n_copies = 0;
  always @(posedge clk) if (rst_n && d_done) begin
    n_copies = n_copies + 1;
    if (d_fail) `ERR(("other DMA failed: code %0d at %h", d_code, d_eaddr))
  end

  // ============================================================ master 3: tensor DMA + TC03 + output buffer
  logic prefetch = 1'b1, desc_valid = 1'b0, desc_ready, cpl_valid, cpl_ready;
  logic [`TDMA_DESC_W-1:0] desc_data = '0;
  logic [7:0] cpl_id; logic [1:0] cpl_kind; logic [3:0] cpl_code; logic [2:0] cpl_detail; logic [31:0] cpl_err_addr, cpl_bytes;
  logic op_rq_v, op_rq_r, op_rq_we, op_rs_v, op_rs_r, op_rs_e, op_rs_we, fb_v, fb_r, fe_v, fe_r, cb_v = 1'b0, cb_r, ce_v = 1'b0, ce_r;
  logic [31:0] op_rq_a, op_rq_d, op_rs_d; logic [3:0] op_rq_s; logic [7:0] op_rq_t, op_rs_t; logic [2:0] op_rs_c;
  logic [0:0] fill_set, cmp_set; logic [3:0] op_state;
  logic ob_rq_v, ob_rq_r, ob_rq_we, ob_rs_v, ob_rs_r, ob_rs_e, ob_rs_we, rb_v, rb_r, re_v, re_r;
  logic [31:0] ob_rq_a, ob_rq_d, ob_rs_d; logic [3:0] ob_rq_s; logic [7:0] ob_rq_t, ob_rs_t; logic [2:0] ob_rs_c;
  logic [0:0] ob_wr_set, ob_rd_set; logic [3:0] ob_state;
  logic busy, ev_cpl, ev_proto; logic [2:0] ld_state, st_state; logic [7:0] ld_id, st_id; logic [NPC*32-1:0] perf_cnt;
  logic pin_v = 1'b0, pin_r, pin_last = 1'b0; logic [1:0] pin_row = '0; logic [3:0] pin_mask = '0;
  logic [127:0] pin_data = '0; logic [15:0] pin_tag = '0;

  tensor_dma_adapter #(.WB(4), .NUM_SETS(NS), .A_SET_BYTES(ASB), .B_SET_BYTES(BSB), .O_SETS(OS), .O_SET_BYTES(OSB),
    .MEM_LO(33'(MEM_BASE)), .MEM_HI(33'(MEM_BASE) + 33'(MEM_BYTES)), .MAX_OUT(MAXOUT), .LOC_OUT(4), .RCAP(32),
    .QDEPTH(4), .CPL_DEPTH(4)) u_dma (
    .clk(clk), .rst_n(rst_n), .cfg_prefetch(prefetch),
    .desc_valid(desc_valid), .desc_ready(desc_ready), .desc_data(desc_data),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_id(cpl_id), .cpl_kind(cpl_kind), .cpl_code(cpl_code),
    .cpl_detail(cpl_detail), .cpl_err_addr(cpl_err_addr), .cpl_bytes(cpl_bytes),
    .req_valid(m_rqv[3]), .req_ready(m_rqr[3]), .req_write(m_rqw[3]), .req_addr(m_rqa[127:96]), .req_wdata(m_rqd[127:96]),
    .req_wstrb(m_rqs[15:12]), .rsp_valid(m_rsv[3]), .rsp_ready(m_rsr[3]), .rsp_rdata(m_rsd[127:96]), .rsp_error(m_rse[3]),
    .op_req_valid(op_rq_v), .op_req_ready(op_rq_r), .op_req_we(op_rq_we), .op_req_addr(op_rq_a), .op_req_wdata(op_rq_d),
    .op_req_wstrb(op_rq_s), .op_req_tag(op_rq_t), .op_rsp_valid(op_rs_v), .op_rsp_ready(op_rs_r), .op_rsp_rdata(op_rs_d),
    .op_rsp_err(op_rs_e), .op_rsp_err_code(op_rs_c), .op_rsp_we(op_rs_we), .op_rsp_tag(op_rs_t),
    .op_fill_begin_valid(fb_v), .op_fill_begin_ready(fb_r), .op_fill_end_valid(fe_v), .op_fill_end_ready(fe_r),
    .op_fill_set(fill_set), .op_set_state(op_state),
    .ob_req_valid(ob_rq_v), .ob_req_ready(ob_rq_r), .ob_req_we(ob_rq_we), .ob_req_addr(ob_rq_a), .ob_req_wdata(ob_rq_d),
    .ob_req_wstrb(ob_rq_s), .ob_req_tag(ob_rq_t), .ob_rsp_valid(ob_rs_v), .ob_rsp_ready(ob_rs_r), .ob_rsp_rdata(ob_rs_d),
    .ob_rsp_err(ob_rs_e), .ob_rsp_err_code(ob_rs_c), .ob_rsp_we(ob_rs_we), .ob_rsp_tag(ob_rs_t),
    .ob_rd_begin_valid(rb_v), .ob_rd_begin_ready(rb_r), .ob_rd_end_valid(re_v), .ob_rd_end_ready(re_r),
    .ob_rd_set(ob_rd_set), .ob_set_state(ob_state),
    .busy(busy), .ld_state(ld_state), .st_state(st_state), .ld_id(ld_id), .st_id(st_id),
    .sfb_outstanding(), .op_outstanding(), .ob_outstanding(), .ev_cpl(ev_cpl), .ev_cpl_id(), .ev_proto(ev_proto),
    .perf_clear(1'b0), .perf_cnt(perf_cnt));

  /* verilator lint_off UNUSEDSIGNAL */
  logic tile_r, trsp_v, trsp_err, s_valid, s_first, s_last, t_busy, t_eidle;
  logic [7:0] trsp_tag, s_tag; logic [3:0] trsp_code; logic [2:0] trsp_m, trsp_n; logic [16:0] trsp_k, s_k, s_kg;
  logic [31:0] s_a, s_b; logic [15:0] s_m0, s_n0; logic [3:0] s_rm, s_cm; logic [0:0] s_set;
  logic [`TOB_NUM_EV*8-1:0] t_ev; logic [3:0] t_bconf; logic [`TOB_NUM_EV*32-1:0] t_pc;
  logic [31:0] ob_tag; logic [5:0] ob_rows, ob_cols, ob_flags; logic ob_ev_wr, ob_ev_rd, ob_ev_ref, ob_ev_werr, ob_ev_wait;
  logic [1:0] ob_conf;
  /* verilator lint_on UNUSEDSIGNAL */
  tensor_operand_buffer #(.ARRAY_ROWS(TM), .ARRAY_COLS(TN), .WORD_BYTES(4), .A_SET_BYTES(ASB), .B_SET_BYTES(BSB),
    .A_BANKS(4), .B_BANKS(2), .A_REPL(1), .NUM_SETS(NS), .SET_MAP(`TOB_SET_SHARED), .PORT_MODE(`TOB_PORT_1R1W),
    .READ_LATENCY(1), .A_STAGE(2), .B_STAGE(4), .WR_STARVE_LIMIT(8), .ADDR_W(32), .DMA_BASE(64'h0), .IDX_W(16),
    .K_W(17), .TAG_W(8), .DMA_RSP_DEPTH(4), .PERF_EN(1), .CNT_W(32)) u_tob (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(op_rq_v), .dma_req_ready(op_rq_r), .dma_req_we(op_rq_we), .dma_req_addr(op_rq_a),
    .dma_req_wdata(op_rq_d), .dma_req_wstrb(op_rq_s), .dma_req_tag(op_rq_t),
    .dma_rsp_valid(op_rs_v), .dma_rsp_ready(op_rs_r), .dma_rsp_rdata(op_rs_d), .dma_rsp_err(op_rs_e),
    .dma_rsp_err_code(op_rs_c), .dma_rsp_we(op_rs_we), .dma_rsp_tag(op_rs_t),
    .fill_begin_valid(fb_v), .fill_begin_ready(fb_r), .fill_end_valid(fe_v), .fill_end_ready(fe_r),
    .cmp_begin_valid(cb_v), .cmp_begin_ready(cb_r), .cmp_end_valid(ce_v), .cmp_end_ready(ce_r),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(op_state),
    .tile_valid(1'b0), .tile_ready(tile_r), .tile_a_addr(32'd0), .tile_lda(32'd0), .tile_b_addr(32'd0),
    .tile_ldb(32'd0), .tile_m0(16'd0), .tile_n0(16'd0), .tile_k0(17'd0), .tile_mat_m(16'd0), .tile_mat_n(16'd0),
    .tile_mat_k(17'd0), .tile_k(17'd0), .tile_tag(8'd0),
    .tile_rsp_valid(trsp_v), .tile_rsp_ready(1'b1), .tile_rsp_tag(trsp_tag), .tile_rsp_err(trsp_err),
    .tile_rsp_code(trsp_code), .tile_rsp_m(trsp_m), .tile_rsp_n(trsp_n), .tile_rsp_k(trsp_k),
    .s_valid(s_valid), .s_ready(1'b1), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0),
    .s_row_mask(s_rm), .s_col_mask(s_cm), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .busy(t_busy), .engine_idle(t_eidle), .ev_inc(t_ev), .ev_bank_conflict_a(t_bconf), .perf_clear(1'b0), .perf_cnt(t_pc));
  tensor_output_buffer #(.WB(4), .O_SETS(OS), .O_SET_BYTES(OSB), .TILE_M(TM), .TILE_N(TN), .O_LD(OLD), .NUM_BANKS(2),
    .PORT_MODE(`HPC_SPM_PORT_1RW), .READ_LATENCY(1), .BACKEND(`SRAM_BACKEND_GENERIC), .TAG_W(8)) u_ob (
    .clk(clk), .rst_n(rst_n),
    .in_valid(pin_v), .in_ready(pin_r), .in_row(pin_row), .in_col_mask(pin_mask), .in_data(pin_data),
    .in_last(pin_last), .in_tag(pin_tag), .in_err(1'b0), .in_ovf(4'd0),
    .d_req_valid(ob_rq_v), .d_req_ready(ob_rq_r), .d_req_we(ob_rq_we), .d_req_addr(ob_rq_a), .d_req_wdata(ob_rq_d),
    .d_req_wstrb(ob_rq_s), .d_req_tag(ob_rq_t), .d_rsp_valid(ob_rs_v), .d_rsp_ready(ob_rs_r), .d_rsp_rdata(ob_rs_d),
    .d_rsp_err(ob_rs_e), .d_rsp_err_code(ob_rs_c), .d_rsp_we(ob_rs_we), .d_rsp_tag(ob_rs_t),
    .rd_begin_valid(rb_v), .rd_begin_ready(rb_r), .rd_end_valid(re_v), .rd_end_ready(re_r),
    .wr_set(ob_wr_set), .rd_set(ob_rd_set), .set_state(ob_state), .set_tag(ob_tag), .set_rows(ob_rows),
    .set_cols(ob_cols), .set_flags(ob_flags), .ev_wr(ob_ev_wr), .ev_rd(ob_ev_rd), .ev_conflict(ob_conf),
    .ev_refused(ob_ev_ref), .ev_wr_err(ob_ev_werr), .ev_wr_wait(ob_ev_wait));
  always @(posedge clk) if (rst_n && (ob_ev_ref || ob_ev_werr || ev_proto)) `ERR(("output buffer / protocol error event"))

  // ============================================================ program + expectations
  logic [7:0]  mem_init [0:MEM_BYTES-1];
  logic [8:0]  mexp     [0:MEM_BYTES-1];
  logic [7:0]  rb       [0:MEM_BYTES-1];
  logic [8:0]  shadow   [0:WIN-1];
  logic [8:0]  sexp     [0:MAXSEAL*(ASB+BSB)-1];
  logic [31:0] tiles    [0:65535];
  logic [`TDMA_DESC_W-1:0] dq [0:MAXD-1];
  logic [3:0]  e_code [0:MAXD-1]; logic [31:0] e_bytes [0:MAXD-1];
  int n_desc = 0, n_seal_exp = 0, n_cpl = 0;
  logic [15:0] t_tag [0:MAXT-1]; int t_rows [0:MAXT-1], t_cols [0:MAXT-1], t_off [0:MAXT-1];
  int tq_head = 0, tq_tail = 0;
  int id2idx [0:255];

  // completions
  always @(posedge clk) cpl_ready <= 1'b1;
  always @(posedge clk) if (rst_n && cpl_valid && cpl_ready) begin
    int k; k = id2idx[cpl_id]; n_cpl = n_cpl + 1;
    if (k < 0) `ERR(("completion for unknown id %0d", cpl_id))
    else begin
      if (cpl_code != e_code[k]) `ERR(("desc %0d: code %0d expected %0d", k, cpl_code, e_code[k]))
      if (cpl_bytes != e_bytes[k]) `ERR(("desc %0d: bytes %0d expected %0d", k, cpl_bytes, e_bytes[k]))
    end
  end

  // TC03 shadow (applied at TC03's OK response) and the compute consumer of operand sets
  localparam int FQ = 32;
  logic [31:0] f_a [0:FQ-1], f_d [0:FQ-1]; logic [3:0] f_s [0:FQ-1]; int f_head = 0, f_tail = 0;
  always @(posedge clk) if (rst_n) begin
    if (op_rs_v && op_rs_r) begin
      int h; h = f_head % FQ; f_head = f_head + 1;
      if (!op_rs_e) for (int b = 0; b < 4; b++) if (f_s[h][b]) shadow[f_a[h] + b] = {1'b0, f_d[h][8*b +: 8]};
    end
    if (op_rq_v && op_rq_r) begin int t; t = f_tail % FQ; f_tail = f_tail + 1; f_a[t] = op_rq_a; f_d[t] = op_rq_d; f_s[t] = op_rq_s; end
  end
  int cs = 0, c_cnt = 0, seal_idx = 0;
  always @(posedge clk) begin
    if (!rst_n) begin cs = 0; cb_v <= 1'b0; ce_v <= 1'b0; end
    else case (cs)
      0: if (op_state[cmp_set*2 +: 2] == `TDMA_BS_READY) begin c_cnt = int'(rnd(5) % 12); cs = 1; end
      1: if (c_cnt == 0) begin cb_v <= 1'b1; cs = 2; end else c_cnt = c_cnt - 1;
      2: if (cb_v && cb_r) begin
           int bad; bad = 0; cb_v <= 1'b0;
           if (seal_idx >= n_seal_exp) `ERR(("unexpected sealed set"))
           else for (int i = 0; i < ASB + BSB; i++) begin
             logic [8:0] e, g;
             e = sexp[seal_idx * (ASB + BSB) + i];
             g = (i < ASB) ? shadow[int'(cmp_set) * ASB + i] : shadow[REGION + int'(cmp_set) * BSB + (i - ASB)];
             if (!e[8] && g != e) bad++;
           end
           if (bad != 0) `ERR(("operand set (seal %0d): %0d bytes differ from the reference", seal_idx, bad))
           seal_idx = seal_idx + 1; c_cnt = int'(rnd(6) % 40); cs = 3;
         end
      3: if (c_cnt == 0) begin ce_v <= 1'b1; cs = 4; end else c_cnt = c_cnt - 1;
      4: if (ce_v && ce_r) begin ce_v <= 1'b0; cs = 0; end
      default: cs = 0;
    endcase
  end
  // compute producer of output tiles
  int ps_ = 0, p_row = 0;
  always @(posedge clk) begin
    if (!rst_n) begin ps_ = 0; pin_v <= 1'b0; end
    else case (ps_)
      0: if (tq_head != tq_tail) begin
           int h; logic [127:0] dd; h = tq_head % MAXT; dd = '0;
           for (int j = 0; j < 4; j++) if (j < t_cols[h]) dd[32*j +: 32] = tiles[t_off[h] + p_row * t_cols[h] + j];
           pin_v <= 1'b1; pin_row <= 2'(p_row); pin_mask <= 4'((1 << t_cols[h]) - 1); pin_data <= dd;
           pin_last <= (p_row == t_rows[h] - 1); pin_tag <= t_tag[h]; ps_ = 1;
         end
      1: if (pin_v && pin_r) begin
           pin_v <= 1'b0; p_row = p_row + 1;
           if (p_row == t_rows[tq_head % MAXT]) begin p_row = 0; tq_head = tq_head + 1; end
           ps_ = 0;
         end
      default: ps_ = 0;
    endcase
  end

  // ============================================================ master 0: CPU (init, random traffic, readback)
  // phase 0 idle, 1 init writes, 2 random traffic, 3 readback, 4 done
  int cpu_ph = 0, cpu_i = 0, cpu_ops = 0;
  logic c_v = 1'b0, c_w = 1'b0, c_wait = 1'b0; logic [31:0] c_a = '0, c_d = '0; logic [3:0] c_s = '0;
  logic [7:0] cpu_sh [0:8*KB-1];                     // shadow of the CPU regions (SRAM0 12K-16K, TSPM 36K-40K)
  bit traffic_stop = 0;
  assign m_rqv[0] = c_v; assign m_rqw[0] = c_w; assign m_rqa[31:0] = c_a; assign m_rqd[31:0] = c_w ? c_d : 32'd0;
  assign m_rqs[3:0] = c_w ? c_s : 4'd0; assign m_rsr[0] = 1'b1;
  function automatic int cpu_off(input int i);           // CPU region byte i (0..8K) -> memory offset
    return (i < 4 * KB) ? 12 * KB + i : 36 * KB + (i - 4 * KB);
  endfunction
  always @(posedge clk) begin
    if (!rst_n) begin c_v <= 1'b0; c_wait <= 1'b0; end
    else begin
      if (c_v && m_rqr[0]) begin c_v <= 1'b0; c_wait <= 1'b1; end
      if (c_wait && m_rsv[0]) begin
        c_wait <= 1'b0;
        if (m_rse[0]) `ERR(("CPU access %h answered with an error", c_a))
        if (!c_w && cpu_ph == 2) begin
          int o; o = int'(c_a - MEM_BASE);
          for (int b = 0; b < 4; b++) begin
            int ci; ci = (o >= 36 * KB) ? o - 36 * KB + 4 * KB + b : o - 12 * KB + b;
            if (m_rsd[8*b +: 8] != cpu_sh[ci]) `ERR(("CPU read %h byte %0d: %h, shadow %h", c_a, b, m_rsd[8*b +: 8], cpu_sh[ci]))
          end
        end
        if (!c_w && cpu_ph == 3) for (int b = 0; b < 4; b++) rb[int'(c_a - MEM_BASE) + b] = m_rsd[8*b +: 8];
      end
      if (!c_v && !c_wait && !(c_wait && m_rsv[0])) begin
        case (cpu_ph)
          1: if (cpu_i < MEM_BYTES) begin
               c_v <= 1'b1; c_w <= 1'b1; c_a <= MEM_BASE + 32'(cpu_i); c_s <= 4'hF;
               c_d <= {mem_init[cpu_i+3], mem_init[cpu_i+2], mem_init[cpu_i+1], mem_init[cpu_i]}; cpu_i = cpu_i + 4;
             end else begin cpu_ph = 2; for (int i = 0; i < 8 * KB; i++) cpu_sh[i] = mem_init[cpu_off(i)]; end
          2: if (traffic_stop) begin cpu_ph = 3; cpu_i = 0; end
             else if (pct(8, CPU_PCT)) begin
               int i; logic [31:0] d; logic [3:0] s;
               i = int'(rnd(9) % (8 * KB)) & ~3; d = rnd(10); s = 4'(rnd(11)); if (s == 0) s = 4'h1;
               c_v <= 1'b1; c_a <= MEM_BASE + 32'(cpu_off(i)); cpu_ops = cpu_ops + 1;
               if (pct(12, 50)) begin
                 c_w <= 1'b1; c_d <= d; c_s <= s;
                 for (int b = 0; b < 4; b++) if (s[b]) cpu_sh[i + b] = d[8*b +: 8];
               end else c_w <= 1'b0;
             end
          3: if (cpu_i < MEM_BYTES) begin
               c_v <= 1'b1; c_w <= 1'b0; c_a <= MEM_BASE + 32'(cpu_i); cpu_i = cpu_i + 4;
             end else cpu_ph = 4;
          default: ;
        endcase
      end
    end
  end

  // ============================================================ master 1: vector-engine stream (SRAM1 24K-32K)
  logic v_v = 1'b0, v_w = 1'b1, v_wait = 1'b0, v_ow = 1'b1; logic [31:0] v_a = '0, v_d = '0;
  int v_i = 0, v_pass = 0, vec_ops = 0, v_oi = 0, v_opass = 0;     // v_o*: the outstanding request
  assign m_rqv[1] = v_v; assign m_rqw[1] = v_ow; assign m_rqa[63:32] = v_a; assign m_rqd[63:32] = v_ow ? v_d : 32'd0;
  assign m_rqs[7:4] = v_ow ? 4'hF : 4'h0; assign m_rsr[1] = 1'b1;
  function automatic logic [31:0] vpat(input int pass, input int i);
    return 32'hA5A5_0000 ^ (32'(pass) << 24) ^ 32'(i * 2654435761);
  endfunction
  always @(posedge clk) begin
    if (!rst_n) begin v_v <= 1'b0; v_wait <= 1'b0; end
    else begin
      if (v_v && m_rqr[1]) begin v_v <= 1'b0; v_wait <= 1'b1; end
      if (v_wait && m_rsv[1]) begin
        v_wait <= 1'b0;
        if (m_rse[1]) `ERR(("vector access error"))
        if (!v_ow && m_rsd[63:32] != vpat(v_opass, v_oi))
          `ERR(("vector read %h: %h expected %h", v_a, m_rsd[63:32], vpat(v_opass, v_oi)))
      end
      if (cpu_ph == 2 && !traffic_stop && !v_v && !v_wait && pct(13, VEC_PCT)) begin
        v_v <= 1'b1; v_a <= S1 + 32'(8 * KB) + 32'(4 * v_i); vec_ops = vec_ops + 1;
        v_ow = v_w; v_oi = v_i; v_opass = v_pass;
        if (v_w) v_d <= vpat(v_pass, v_i);
        v_i = v_i + 1;
        if (v_i == 2 * KB) begin v_i = 0; if (!v_w) v_pass = v_pass + 1; v_w = !v_w; end
      end
    end
  end

  // ============================================================ TSPM vector lanes (ports 1-2), 4 KiB each
  logic [7:0] ln_sh [0:1][0:4*KB-1];
  int lane_ops [0:1];
  int lane_init = 0;
  for (genvar l = 1; l <= 2; l++) begin : g_lane
    logic lv = 1'b0, lw = 1'b0, lwait = 1'b0; logic [31:0] la = '0, ld_ = '0; logic [3:0] ls = '0;
    assign tq_v[l] = lv; assign tq_we[l] = lw; assign tq_a[32*l +: 32] = la; assign tq_d[32*l +: 32] = ld_;
    assign tq_s[4*l +: 4] = ls; assign tq_t[8*l +: 8] = 8'(l); assign tr_r[l] = 1'b1;
    always @(posedge clk) begin
      if (!rst_n) begin lv <= 1'b0; lwait <= 1'b0; lane_ops[l-1] = 0; end
      else begin
        if (lv && tq_r[l]) begin lv <= 1'b0; lwait <= 1'b1; end
        if (lwait && tr_v[l]) begin
          lwait <= 1'b0;
          if (tr_e[l]) `ERR(("lane %0d error", l))
          if (!lw) for (int b = 0; b < 4; b++)
            if (tr_d[32*l + 8*b +: 8] != ln_sh[l-1][int'(la - MEM_BASE) - (40 + 4 * (l - 1)) * KB + b]) `ERR(("lane %0d read mismatch at %h", l, la))
        end
        if (cpu_ph == 2 && !traffic_stop && !lv && !lwait && pct(14 + l, LANE_PCT)) begin
          int i; logic [31:0] d;
          i = int'(rnd(16 - l) % (4 * KB)) & ~3; d = rnd(3);
          lv <= 1'b1; la <= MEM_BASE + 32'((40 + 4 * (l - 1)) * KB + i); lane_ops[l-1] = lane_ops[l-1] + 1;
          if (pct(4, 50)) begin lw <= 1'b1; ld_ <= d; ls <= 4'hF; for (int b = 0; b < 4; b++) ln_sh[l-1][i + b] = d[8*b +: 8]; end
          else lw <= 1'b0;
        end
      end
    end
  end
  // the lane regions start as the initial memory image (written by the CPU init phase)
  always @(posedge clk) if (cpu_ph == 2 && lane_init == 0) begin
    for (int i = 0; i < 4 * KB; i++) begin ln_sh[0][i] = mem_init[40 * KB + i]; ln_sh[1][i] = mem_init[44 * KB + i]; end
    lane_init = 1;
  end

  // ============================================================ tensor DMA starvation measurement
  int t_stall = 0, t_stall_max = 0, loss3 = 0, spm_conf = 0;
  always @(posedge clk) if (rst_n) begin
    if (m_rqv[3] && !m_rqr[3]) begin t_stall = t_stall + 1; if (t_stall > t_stall_max) t_stall_max = t_stall; end
    else t_stall = 0;
  end

  // ============================================================ main
  string dir; int fd, rc; logic [31:0] f [0:17];
  longint maxcyc = 3_000_000;
  bit tensor_done = 0;
  always @(posedge clk) tensor_done <= (n_cpl == n_desc) && n_desc > 0 && !busy && cs == 0 && tq_head == tq_tail &&
                                       op_state == '0 && ob_state == '0;
  always @(posedge clk) if (cyc == maxcyc) begin
    `ERR(("WATCHDOG: cpu_ph=%0d cpl=%0d/%0d busy=%0d copies=%0d", cpu_ph, n_cpl, n_desc, busy, n_copies))
    $display("RESULT FAIL"); $finish;
  end

  initial begin
    int s;
    if (!$value$plusargs("dir=%s", dir)) dir = ".";
    if (!$value$plusargs("seed=%d", s)) s = 1;
    for (int i = 0; i < 16; i++) rs[i] = 32'h9E37_79B9 * (s + i * 7919) + 32'h1234_5 + i;
    for (int i = 0; i < 256; i++) id2idx[i] = -1;
    for (int i = 0; i < WIN; i++) shadow[i] = 9'h100;
    $readmemh({dir, "/mem_init.hex"}, mem_init);
    $readmemh({dir, "/mem_exp.hex"}, mexp);
    $readmemh({dir, "/tiles.hex"}, tiles);
    fd = $fopen({dir, "/seals.txt"}, "r"); rc = $fscanf(fd, "%d", n_seal_exp); $fclose(fd);
    if (n_seal_exp > 0) $readmemh({dir, "/seal_exp.hex"}, sexp);
    fd = $fopen({dir, "/prog.txt"}, "r"); rc = 18;
    while (!$feof(fd) && rc == 18) begin
      rc = $fscanf(fd, "%h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h\n", f[0], f[1], f[2], f[3], f[4], f[5],
                   f[6], f[7], f[8], f[9], f[10], f[11], f[12], f[13], f[14], f[15], f[16], f[17]);
      if (rc == 18 && f[0] == 32'd1) begin
        logic [`TDMA_DESC_W-1:0] v; v = '0;
        v[`TDMA_D_ID] = f[1][7:0]; v[`TDMA_D_KIND] = f[2][1:0]; v[`TDMA_D_FLAGS] = f[3][5:0]; v[`TDMA_D_SRC] = f[4];
        v[`TDMA_D_DST] = f[5]; v[`TDMA_D_SSTRIDE] = f[6]; v[`TDMA_D_DSTRIDE] = f[7]; v[`TDMA_D_ROWLEN] = f[8][15:0];
        v[`TDMA_D_ROWS] = f[9][15:0]; v[`TDMA_D_VER] = f[10][7:0]; v[`TDMA_D_RSVD] = f[11][7:0];
        e_code[n_desc] = f[12][3:0]; e_bytes[n_desc] = f[13]; id2idx[f[1][7:0]] = n_desc;
        dq[n_desc] = v; n_desc = n_desc + 1;
      end else if (rc == 18 && f[0] == 32'd2) begin
        int h; h = tq_tail % MAXT; t_tag[h] = f[1][15:0]; t_rows[h] = int'(f[2]); t_cols[h] = int'(f[3]); t_off[h] = int'(f[4]);
        tq_tail = tq_tail + 1;
      end
    end
    $fclose(fd);
    repeat (4) @(posedge clk);
    @(negedge clk) rst_n <= 1'b1;
    repeat (2) @(posedge clk);
    cpu_ph = 1;                                   // initialise memory through the fabric
    while (cpu_ph != 2) @(posedge clk);
    @(negedge clk) d_start <= 1'b1;               // other DMA engine: first copy
    @(negedge clk) d_start <= 1'b0;
    for (int k = 0; k < n_desc; k++) begin
      @(negedge clk) begin desc_valid <= 1'b1; desc_data <= dq[k]; end
      @(posedge clk);
      while (!desc_ready) @(posedge clk);
      @(negedge clk) desc_valid <= 1'b0;
      if (k == n_desc / 2) begin
        while (d_busy) @(posedge clk);            // second copy during the tensor program
        @(negedge clk) d_start <= 1'b1;
        @(negedge clk) d_start <= 1'b0;
      end
    end
    while (!tensor_done && cyc < maxcyc) @(posedge clk);
    while (d_busy && cyc < maxcyc) @(posedge clk);
    traffic_stop = 1;
    while (cpu_ph != 4 && cyc < maxcyc) @(posedge clk);
    repeat (10) @(posedge clk);
    begin int bad, first; bad = 0; first = -1;
      for (int i = 0; i < MEM_BYTES; i++) if (!mexp[i][8] && {1'b0, rb[i]} != mexp[i]) begin bad++; if (first < 0) first = i; end
      if (bad != 0) `ERR(("memory read back through the fabric: %0d bytes differ (first at %h: %h expected %h)", bad,
                          MEM_BASE + first, rb[first], mexp[first][7:0]))
    end
    if (seal_idx != n_seal_exp) `ERR(("compute took %0d sets, reference sealed %0d", seal_idx, n_seal_exp))
    if (g_chk[0].viol + g_chk[1].viol + g_chk[2].viol + g_chk[3].viol != 0) `ERR(("SFB2 protocol violations"))
    if (n_copies < 2) `ERR(("other DMA completed %0d copies", n_copies))
    if (cpu_ops == 0 || vec_ops == 0 || lane_ops[0] == 0 || lane_ops[1] == 0) `ERR(("a traffic generator made no progress"))
    for (int i = 0; i < NPC; i++) $display("PERF %0d %0d", i, perf_cnt[i*32 +: 32]);
    $display("STATS desc=%0d cpl=%0d cycles=%0d cpu_ops=%0d vec_ops=%0d lane0=%0d lane1=%0d copies=%0d tdma_req=%0d tdma_stall_max=%0d tdma_arb_loss=%0d spm_conflict=%0d",
             n_desc, n_cpl, cyc, cpu_ops, vec_ops, lane_ops[0], lane_ops[1], n_copies, g_chk[3].nrq, t_stall_max,
             loss3, spm_conf);
    $display("RESULT %s", (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  always @(posedge clk) if (rst_n) begin
    if (ev_loss[3]) loss3 = loss3 + 1;
    if (sp_conf != 3'b000) spm_conf = spm_conf + 1;
  end
endmodule
