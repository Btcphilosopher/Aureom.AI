// =============================================================================
// SilicaFlux TENSORCORE 07 :: tb_tdma
// System testbench of the tensor DMA adapter with the REAL buffers:
//   tensor_dma_adapter + TC03 tensor_operand_buffer (unmodified) +
//   tensor_output_buffer (Module 04 hpc_scratchpad + TC03 tob_dbuf_ctrl)
// against a byte-accurate SFB2 memory model, driven by programs from
// model/gen_tests.py.  Expected results come ONLY from model/tdma_ref.py; this
// testbench never computes a transfer result.  It checks:
//   * every completion record (exactly one per descriptor; code, bytes, error
//     address, detail); SEQUENTIAL mode: completions in submission order;
//   * WRITE COMPLETION: the memory model performs a write only when it sends
//     the response (SFB2 R7) after a random latency; at every OK completion each
//     destination byte of the descriptor must already have been performed BY THAT
//     descriptor (external memory and the TC03 fill window alike);
//   * operand sets: the TC03 fill window is shadowed byte by byte from the writes
//     TC03 acknowledged; when the compute model takes a READY set (cmp_begin) the
//     whole set must equal the reference snapshot (compute never sees a partial set);
//   * bus-level element maps: every SFB2 read word holds a byte of a source row of
//     the running LOAD, every strobed byte of every SFB2 / TC03 write is a byte of a
//     destination row of the running descriptor, no byte is written twice by one
//     descriptor, TC03 writes only target a FILLING set, SFB2 R2/R9 and the DataFabric
//     sfb_protocol_checker on the link;
//   * the WHOLE external memory at the end (exact, except don't-care bytes of failed
//     or reset-interrupted transfers); no gate refusal in the output buffer;
//   * reset: no request while reset is asserted, no completion of a pre-reset
//     descriptor afterwards, and the post-reset program runs exactly.
// Memory model: req_ready random (+bp), per-request latency in [+lat_min,+lat_max],
// in-order responses, +xbar=1 = DataFabric R6 (one transaction in flight),
// error injection on a word (program E lines).  Fault injectors on the TC03 and
// output-buffer response paths produce LOC_WR / LOC_RD / PROTO cases.
// =============================================================================
`timescale 1ns/1ps
`include "tdma_defs.svh"
`include "tob_defs.svh"
`include "hpc_spm_defs.svh"

module tb_tdma;
  parameter int WB = 4, NS = 2, ASB = 1024, BSB = 1024, OS = 2, OSB = 256;
  parameter int MAXOUT = 4, LOCOUT = 4, RCAP = 32, QD = 4, CPLD = 4;
  parameter int TPM = 1, TRL = 1, OPM = 0, ORL = 1, ONB = 2;
  parameter int MEM_BASE = 32'h1000_0000, MEM_BYTES = 1 << 16;
  localparam int DW = 8 * WB, TM = 4, TN = 4, OLD = 16, NPC = `TDMA_NUM_PC;
  localparam int AT = NS * ASB, BT = NS * BSB, REGION = (AT > BT) ? AT : BT, WIN = REGION + BT;
  localparam int SW = (NS > 1) ? $clog2(NS) : 1, OSW = (OS > 1) ? $clog2(OS) : 1;
  localparam int MAXD = 512, MAXSEAL = 96, MAXT = 128;

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;          // a real falling edge: the asynchronous resets act before the first clock
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; if (errors <= 40) begin $write("ERROR cyc=%0d: ", cyc); $display args ; end end

  // ============================================================ random streams (xorshift)
  int unsigned rs [0:15];
  function automatic int unsigned rnd(input int s);
    int unsigned x;
    x = rs[s]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[s] = x; return x;
  endfunction
  function automatic bit pct(input int s, input int p);
    return (p > 0) && (int'(rnd(s) % 100) < p);
  endfunction
  function automatic int rrange(input int s, input int lo, input int hi);
    return (hi > lo) ? lo + int'(rnd(s) % (hi - lo + 1)) : lo;
  endfunction

  // ============================================================ DUT signals
  logic                    prefetch = 1'b0;
  logic                    desc_valid = 1'b0, desc_ready;
  logic [`TDMA_DESC_W-1:0] desc_data = '0;
  logic                    cpl_valid, cpl_ready;
  logic [7:0]              cpl_id;
  logic [1:0]              cpl_kind;
  logic [3:0]              cpl_code;
  logic [2:0]              cpl_detail;
  logic [31:0]             cpl_err_addr, cpl_bytes;
  logic                    req_valid, req_ready, req_write, rsp_valid, rsp_ready, rsp_error;
  logic [31:0]             req_addr;
  logic [DW-1:0]           req_wdata, rsp_rdata;
  logic [WB-1:0]           req_wstrb;
  // TC03 link (adapter side / TC03 side differ only in the injected response fields)
  logic          op_rq_v, op_rq_r, op_rq_we, op_rs_v, op_rs_r, op_rs_e, op_rs_we, t_rs_e;
  logic [31:0]   op_rq_a;
  logic [DW-1:0] op_rq_d, op_rs_d;
  logic [WB-1:0] op_rq_s;
  logic [7:0]    op_rq_t, op_rs_t, t_rs_t;
  logic [2:0]    op_rs_c, t_rs_c;
  logic          fb_v, fb_r, fe_v, fe_r;
  logic          cb_v = 1'b0, cb_r, ce_v = 1'b0, ce_r;
  logic [SW-1:0] fill_set, cmp_set;
  logic [NS*2-1:0] op_state;
  // output buffer link
  logic          ob_rq_v, ob_rq_r, ob_rq_we, ob_rs_v, ob_rs_r, ob_rs_e, ob_rs_we, o_rs_e;
  logic [31:0]   ob_rq_a;
  logic [DW-1:0] ob_rq_d, ob_rs_d, o_rs_d;
  logic [WB-1:0] ob_rq_s;
  logic [7:0]    ob_rq_t, ob_rs_t;
  logic [2:0]    ob_rs_c, o_rs_c;
  logic          rb_v, rb_r, re_v, re_r;
  logic [OSW-1:0] ob_wr_set, ob_rd_set;
  logic [OS*2-1:0] ob_state;
  // producer
  logic          pin_v = 1'b0, pin_r, pin_last = 1'b0;
  logic [1:0]    pin_row = '0;
  logic [TN-1:0] pin_mask = '0;
  logic [TN*32-1:0] pin_data = '0;
  logic [15:0]   pin_tag = '0;
  // status
  logic          busy, ev_cpl, ev_proto, perf_clear = 1'b0;
  logic [7:0]    ev_cpl_id;
  logic [2:0]    ld_state, st_state;
  logic [7:0]    ld_id, st_id;
  logic [NPC*32-1:0] perf_cnt;

  // ============================================================ DUT: adapter
  tensor_dma_adapter #(
    .WB(WB), .NUM_SETS(NS), .A_SET_BYTES(ASB), .B_SET_BYTES(BSB), .OP_BASE(32'h0), .O_SETS(OS),
    .O_SET_BYTES(OSB), .OB_BASE(32'h0), .MEM_LO(33'(MEM_BASE)), .MEM_HI(33'(MEM_BASE) + 33'(MEM_BYTES)),
    .MAX_OUT(MAXOUT), .LOC_OUT(LOCOUT), .RCAP(RCAP), .QDEPTH(QD), .CPL_DEPTH(CPLD), .TAG_W(8), .CNT_W(32)
  ) u_dma (
    .clk(clk), .rst_n(rst_n), .cfg_prefetch(prefetch),
    .desc_valid(desc_valid), .desc_ready(desc_ready), .desc_data(desc_data),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_id(cpl_id), .cpl_kind(cpl_kind), .cpl_code(cpl_code),
    .cpl_detail(cpl_detail), .cpl_err_addr(cpl_err_addr), .cpl_bytes(cpl_bytes),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr),
    .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .op_req_valid(op_rq_v), .op_req_ready(op_rq_r), .op_req_we(op_rq_we), .op_req_addr(op_rq_a),
    .op_req_wdata(op_rq_d), .op_req_wstrb(op_rq_s), .op_req_tag(op_rq_t),
    .op_rsp_valid(op_rs_v), .op_rsp_ready(op_rs_r), .op_rsp_rdata(op_rs_d), .op_rsp_err(op_rs_e),
    .op_rsp_err_code(op_rs_c), .op_rsp_we(op_rs_we), .op_rsp_tag(op_rs_t),
    .op_fill_begin_valid(fb_v), .op_fill_begin_ready(fb_r), .op_fill_end_valid(fe_v), .op_fill_end_ready(fe_r),
    .op_fill_set(fill_set), .op_set_state(op_state),
    .ob_req_valid(ob_rq_v), .ob_req_ready(ob_rq_r), .ob_req_we(ob_rq_we), .ob_req_addr(ob_rq_a),
    .ob_req_wdata(ob_rq_d), .ob_req_wstrb(ob_rq_s), .ob_req_tag(ob_rq_t),
    .ob_rsp_valid(ob_rs_v), .ob_rsp_ready(ob_rs_r), .ob_rsp_rdata(ob_rs_d), .ob_rsp_err(ob_rs_e),
    .ob_rsp_err_code(ob_rs_c), .ob_rsp_we(ob_rs_we), .ob_rsp_tag(ob_rs_t),
    .ob_rd_begin_valid(rb_v), .ob_rd_begin_ready(rb_r), .ob_rd_end_valid(re_v), .ob_rd_end_ready(re_r),
    .ob_rd_set(ob_rd_set), .ob_set_state(ob_state),
    .busy(busy), .ld_state(ld_state), .st_state(st_state), .ld_id(ld_id), .st_id(st_id),
    .sfb_outstanding(), .op_outstanding(), .ob_outstanding(), .ev_cpl(ev_cpl), .ev_cpl_id(ev_cpl_id), .ev_proto(ev_proto),
    .perf_clear(perf_clear), .perf_cnt(perf_cnt));

  // ============================================================ DUT: TC03 operand buffer (unmodified)
  logic t_rs_v, t_rs_we;
  logic [DW-1:0] t_rs_d;
  /* verilator lint_off UNUSEDSIGNAL */
  logic tile_r, trsp_v, trsp_err, s_valid, s_first, s_last, t_busy, t_eidle;
  logic [7:0] trsp_tag, s_tag; logic [3:0] trsp_code; logic [2:0] trsp_m, trsp_n; logic [16:0] trsp_k, s_k, s_kg;
  logic [TM*8-1:0] s_a; logic [TN*8-1:0] s_b; logic [15:0] s_m0, s_n0; logic [TM-1:0] s_rm; logic [TN-1:0] s_cm;
  logic [SW-1:0] s_set; logic [`TOB_NUM_EV*8-1:0] t_ev; logic [3:0] t_bconf; logic [`TOB_NUM_EV*32-1:0] t_pc;
  /* verilator lint_on UNUSEDSIGNAL */

  tensor_operand_buffer #(
    .ARRAY_ROWS(TM), .ARRAY_COLS(TN), .WORD_BYTES(WB), .A_SET_BYTES(ASB), .B_SET_BYTES(BSB), .A_BANKS(4),
    .B_BANKS(2), .A_REPL(1), .NUM_SETS(NS), .SET_MAP(`TOB_SET_SHARED), .PORT_MODE(TPM), .READ_LATENCY(TRL),
    .A_STAGE(2), .B_STAGE(4), .WR_STARVE_LIMIT(8), .ADDR_W(32), .DMA_BASE(64'h0), .IDX_W(16), .K_W(17),
    .TAG_W(8), .DMA_RSP_DEPTH(4), .PERF_EN(1), .CNT_W(32)
  ) u_tob (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(op_rq_v), .dma_req_ready(op_rq_r), .dma_req_we(op_rq_we), .dma_req_addr(op_rq_a),
    .dma_req_wdata(op_rq_d), .dma_req_wstrb(op_rq_s), .dma_req_tag(op_rq_t),
    .dma_rsp_valid(t_rs_v), .dma_rsp_ready(op_rs_r), .dma_rsp_rdata(t_rs_d), .dma_rsp_err(t_rs_e),
    .dma_rsp_err_code(t_rs_c), .dma_rsp_we(t_rs_we), .dma_rsp_tag(t_rs_t),
    .fill_begin_valid(fb_v), .fill_begin_ready(fb_r), .fill_end_valid(fe_v), .fill_end_ready(fe_r),
    .cmp_begin_valid(cb_v), .cmp_begin_ready(cb_r), .cmp_end_valid(ce_v), .cmp_end_ready(ce_r),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(op_state),
    .tile_valid(1'b0), .tile_ready(tile_r), .tile_a_addr(32'd0), .tile_lda(32'd0), .tile_b_addr(32'd0),
    .tile_ldb(32'd0), .tile_m0(16'd0), .tile_n0(16'd0), .tile_k0(17'd0), .tile_mat_m(16'd0), .tile_mat_n(16'd0),
    .tile_mat_k(17'd0), .tile_k(17'd0), .tile_tag(8'd0),
    .tile_rsp_valid(trsp_v), .tile_rsp_ready(1'b1), .tile_rsp_tag(trsp_tag), .tile_rsp_err(trsp_err),
    .tile_rsp_code(trsp_code), .tile_rsp_m(trsp_m), .tile_rsp_n(trsp_n), .tile_rsp_k(trsp_k),
    .s_valid(s_valid), .s_ready(1'b1), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0),
    .s_row_mask(s_rm), .s_col_mask(s_cm), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .busy(t_busy), .engine_idle(t_eidle), .ev_inc(t_ev), .ev_bank_conflict_a(t_bconf),
    .perf_clear(1'b0), .perf_cnt(t_pc));

  // ============================================================ DUT: output buffer
  logic ob_ev_wr, ob_ev_rd, ob_ev_ref, ob_ev_wait, ob_ev_werr;
  logic [1:0] ob_ev_conf;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [OS*16-1:0] ob_tag; logic [OS*3-1:0] ob_rows; logic [OS*3-1:0] ob_cols; logic [OS*3-1:0] ob_flags;
  /* verilator lint_on UNUSEDSIGNAL */
  tensor_output_buffer #(
    .WB(WB), .O_SETS(OS), .O_SET_BYTES(OSB), .TILE_M(TM), .TILE_N(TN), .O_LD(OLD), .NUM_BANKS(ONB),
    .PORT_MODE(OPM), .READ_LATENCY(ORL), .BACKEND(`SRAM_BACKEND_GENERIC), .TAG_W(8)
  ) u_ob (
    .clk(clk), .rst_n(rst_n),
    .in_valid(pin_v), .in_ready(pin_r), .in_row(pin_row), .in_col_mask(pin_mask), .in_data(pin_data),
    .in_last(pin_last), .in_tag(pin_tag), .in_err(1'b0), .in_ovf({TN{1'b0}}),
    .d_req_valid(ob_rq_v), .d_req_ready(ob_rq_r), .d_req_we(ob_rq_we), .d_req_addr(ob_rq_a),
    .d_req_wdata(ob_rq_d), .d_req_wstrb(ob_rq_s), .d_req_tag(ob_rq_t),
    .d_rsp_valid(ob_rs_v), .d_rsp_ready(ob_rs_r), .d_rsp_rdata(o_rs_d), .d_rsp_err(o_rs_e),
    .d_rsp_err_code(o_rs_c), .d_rsp_we(ob_rs_we), .d_rsp_tag(ob_rs_t),
    .rd_begin_valid(rb_v), .rd_begin_ready(rb_r), .rd_end_valid(re_v), .rd_end_ready(re_r),
    .wr_set(ob_wr_set), .rd_set(ob_rd_set), .set_state(ob_state), .set_tag(ob_tag), .set_rows(ob_rows),
    .set_cols(ob_cols), .set_flags(ob_flags),
    .ev_wr(ob_ev_wr), .ev_rd(ob_ev_rd), .ev_conflict(ob_ev_conf), .ev_refused(ob_ev_ref), .ev_wr_err(ob_ev_werr),
    .ev_wr_wait(ob_ev_wait));

  // ============================================================ fault injectors (response paths)
  int op_rsp_n = 0, ob_rsp_n = 0;          // responses since reset
  int inj_op_n = -1, inj_op_kind = 0, inj_ob_n = -1;
  logic inj_op_now, inj_ob_now;
  assign inj_op_now = t_rs_v && (op_rsp_n == inj_op_n);
  assign inj_ob_now = ob_rs_v && (ob_rsp_n == inj_ob_n);
  assign op_rs_v  = t_rs_v;
  assign op_rs_d  = t_rs_d;
  assign op_rs_we = t_rs_we;
  assign op_rs_e  = t_rs_e || (inj_op_now && inj_op_kind == 3);
  assign op_rs_c  = (inj_op_now && inj_op_kind == 3) ? 3'd6 : t_rs_c;
  assign op_rs_t  = (inj_op_now && inj_op_kind == 5) ? (t_rs_t ^ 8'h01) : t_rs_t;
  assign ob_rs_e  = o_rs_e || inj_ob_now;
  assign ob_rs_c  = inj_ob_now ? 3'd4 : o_rs_c;
  assign ob_rs_d  = inj_ob_now ? '0 : o_rs_d;
  always @(posedge clk) begin
    if (!rst_n) begin op_rsp_n = 0; ob_rsp_n = 0; end
    else begin
      if (t_rs_v && op_rs_r) op_rsp_n = op_rsp_n + 1;
      if (ob_rs_v && ob_rs_r) ob_rsp_n = ob_rsp_n + 1;
    end
  end

  // ============================================================ SFB2 protocol checker (DataFabric, unmodified)
  logic [31:0] pc_viol, pc_nreq, pc_nrsp, pc_out;
  sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT(MAXOUT), .ALLOW_REQ_CHANGE(0), .CHECK_RDATA_ZERO(1),
                         .NAME("tdma_sfb")) u_chk (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write),
    .req_addr(req_addr), .req_wdata(req_wdata), .req_wstrb(req_wstrb), .rsp_valid(rsp_valid),
    .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .violations(pc_viol), .n_req(pc_nreq), .n_rsp(pc_nrsp), .outstanding(pc_out));

  // ============================================================ descriptor table (from the program)
  logic [7:0]  d_id   [0:MAXD-1];
  logic [1:0]  d_kind [0:MAXD-1];
  logic [5:0]  d_flags[0:MAXD-1];
  logic [31:0] d_src  [0:MAXD-1], d_dst [0:MAXD-1], d_sstr[0:MAXD-1], d_dstr[0:MAXD-1];
  logic [15:0] d_len  [0:MAXD-1], d_rows[0:MAXD-1];
  logic [7:0]  d_ver  [0:MAXD-1], d_rsvd[0:MAXD-1];
  logic [3:0]  e_code [0:MAXD-1];
  logic [31:0] e_bytes[0:MAXD-1], e_eaddr[0:MAXD-1];
  logic [3:0]  e_det  [0:MAXD-1];
  int          d_part [0:MAXD-1];
  bit          d_opt  [0:MAXD-1];
  bit          d_done [0:MAXD-1];
  bit          d_fin  [0:MAXD-1];        // completion record produced (finished), maybe not yet consumed
  int          d_set  [0:MAXD-1];        // operand set of a LOAD (sampled at RUN)
  int          id2idx [0:255];
  int          n_desc = 0;

  // per channel: descriptors in submission order, and the running one
  int ld_list [0:MAXD-1], st_list [0:MAXD-1];
  int ld_n = 0, st_n = 0, ld_p = 0, st_p = 0, ld_cur = -1, st_cur = -1;
  int part = 1;

  // ============================================================ memory model + expectations
  logic [7:0] mem  [0:MEM_BYTES-1];
  logic [8:0] mexp [0:MEM_BYTES-1];        // 0x1XX = don't care
  int         lw   [0:MEM_BYTES-1];        // descriptor whose write was performed last
  logic [8:0] shadow   [0:WIN-1];          // TC03 fill window, 0x100 = never written
  int         sh_lw    [0:WIN-1];
  logic [8:0] sexp [0:MAXSEAL*(ASB+BSB)-1];
  int         n_seal_exp = 0;

  function automatic bit inwin(input logic [31:0] a);
    return (a >= MEM_BASE) && (64'(a) < 64'(MEM_BASE) + 64'(MEM_BYTES));
  endfunction

  // byte o (local offset in the region of the descriptor) is in a destination row
  function automatic bit dst_has(input int k, input longint o);
    longint r, x;
    if (o < 0) return 0;
    if (d_rows[k] == 16'd1 || d_dstr[k] == 32'd0) return (o - longint'(d_dst[k])) >= 0 && (o - longint'(d_dst[k])) < longint'(d_len[k]);
    x = o - longint'(d_dst[k]);
    if (x < 0) return 0;
    r = x / longint'(d_dstr[k]);
    return (r < longint'(d_rows[k])) && (x - r * longint'(d_dstr[k]) < longint'(d_len[k]));
  endfunction
  // the word at byte address w (WB bytes) holds a byte of a source row
  // (no `return` inside loops: Verilator 5.020 --timing mis-schedules it in functions called from coroutines)
  function automatic bit src_word_hit(input int k, input longint w);
    longint s; bit hit;
    hit = 0;
    for (int r = 0; r < int'(d_rows[k]); r++) begin
      s = longint'(d_src[k]) + longint'(r) * longint'(d_sstr[k]);
      if (s < w + WB && s + longint'(d_len[k]) > w) hit = 1;
    end
    return hit;
  endfunction
  function automatic longint win_base(input int k);
    if (d_kind[k] == `TDMA_K_LOAD_B) return longint'(REGION) + longint'(d_set[k]) * BSB;
    return longint'(d_set[k]) * ASB;
  endfunction

  // ------------------------------------------------------------ SFB2 slave
  int lat_min = 1, lat_max = 1, bp = 0, xbar = 0, cpl_bp = 0, gap_max = 0, cons_dly = 4, cons_hold = 8;
  int prod_gap = 2, seq_check = 0, rst_delay = 30, rst_len = 4, parts = 1;
  logic [31:0] err_rd = 32'hFFFF_FFFF, err_wr = 32'hFFFF_FFFF;
  localparam int QN = 64;
  logic          q_w [0:QN-1];
  logic [31:0]   q_a [0:QN-1];
  logic [DW-1:0] q_d [0:QN-1];
  logic [WB-1:0] q_s [0:QN-1];
  longint        q_t [0:QN-1];
  int            q_k [0:QN-1];
  int q_head = 0, q_tail = 0;
  longint n_rd = 0, n_wr = 0, n_op_wr = 0, n_ob_rd = 0;
  logic rsp_v_q = 1'b0, rsp_e_q = 1'b0; logic [DW-1:0] rsp_d_q = '0;
  assign rsp_valid = rsp_v_q;
  assign rsp_error = rsp_e_q;
  assign rsp_rdata = rsp_d_q;
  logic rdy_q = 1'b0;
  int outst_q = 0;
  assign req_ready = rdy_q && rst_n && (outst_q < QN - 2) &&
                     (xbar == 0 || outst_q == 0 || (outst_q == 1 && rsp_v_q && rsp_ready));
  always @(posedge clk)
    if (!rst_n) outst_q <= 0;
    else        outst_q <= outst_q + ((req_valid && req_ready) ? 1 : 0) - ((rsp_v_q && rsp_ready) ? 1 : 0);

  always @(posedge clk) begin
    if (!rst_n) begin
      q_head = 0; q_tail = 0; rsp_v_q <= 1'b0; rsp_e_q <= 1'b0; rsp_d_q <= '0; rdy_q <= 1'b0;
      if (req_valid || op_rq_v || ob_rq_v) `ERR(("request presented during reset"))
    end else begin
      if ((!rsp_v_q || rsp_ready) && q_head != q_tail && cyc >= q_t[q_head % QN]) begin
        int h; logic [31:0] o; logic e;
        h = q_head % QN; q_head = q_head + 1;
        o = q_a[h] - MEM_BASE;
        e = !inwin(q_a[h]) || (q_w[h] ? (q_a[h] == err_wr) : (q_a[h] == err_rd));
        rsp_v_q <= 1'b1; rsp_e_q <= e;
        if (q_w[h]) begin
          rsp_d_q <= '0;
          if (!e) for (int b = 0; b < WB; b++) if (q_s[h][b]) begin            // performed now (R7)
            mem[o + b] = q_d[h][8*b +: 8];
            if (lw[o + b] == q_k[h]) `ERR(("byte %h written twice by descriptor %0d", q_a[h] + b, q_k[h]))
            lw[o + b] = q_k[h];
          end
        end else begin
          logic [DW-1:0] rd;
          for (int b = 0; b < WB; b++) rd[8*b +: 8] = mem[o + b];
          rsp_d_q <= e ? '0 : rd;
        end
      end else if (rsp_v_q && rsp_ready) begin
        rsp_v_q <= 1'b0;
      end
      if (req_valid && req_ready) begin
        int t; t = q_tail % QN;
        q_w[t] = req_write; q_a[t] = req_addr; q_d[t] = req_wdata; q_s[t] = req_wstrb; q_k[t] = st_cur;
        q_t[t] = cyc + lat_min + ((lat_max > lat_min) ? longint'(rnd(1) % (lat_max - lat_min + 1)) : 0);
        q_tail = q_tail + 1;
        sfb_check();
      end
      rdy_q <= !pct(2, bp);
    end
  end

  task automatic sfb_check();
    longint w;
    if (req_addr[$clog2(WB)-1:0] != '0) `ERR(("SFB2 R9: misaligned address %h", req_addr))
    if (!inwin(req_addr)) `ERR(("SFB2 access outside the memory window: %h", req_addr))
    w = longint'(req_addr);
    if (!req_write) begin
      n_rd = n_rd + 1;
      if (ld_cur < 0 || ld_state != `TDMA_CH_RUN) `ERR(("SFB2 read %h while no LOAD is running", req_addr))
      else if (!src_word_hit(ld_cur, w)) `ERR(("SFB2 read of %h holds no source byte of descriptor %0d", req_addr, ld_cur))
    end else begin
      n_wr = n_wr + 1;
      if (st_cur < 0 || st_state != `TDMA_CH_RUN) `ERR(("SFB2 write %h while no STORE is running", req_addr))
      else for (int b = 0; b < WB; b++)
        if (req_wstrb[b] && !dst_has(st_cur, w + b)) `ERR(("SFB2 write byte %h is outside descriptor %0d", w + b, st_cur))
      if (req_wstrb == '0) `ERR(("SFB2 write with an empty strobe at %h", req_addr))
    end
  endtask

  // SFB2 R2 monitor
  logic pv = 1'b0, pw; logic [31:0] pa; logic [DW-1:0] pd; logic [WB-1:0] ps;
  always @(posedge clk) begin
    if (!rst_n) pv <= 1'b0;
    else begin
      if (pv && !(req_valid && req_write == pw && req_addr == pa && req_wstrb == ps && (!pw || req_wdata == pd)))
        `ERR(("SFB2 R2: request withdrawn or changed before acceptance"))
      pv <= req_valid && !req_ready; pw <= req_write; pa <= req_addr; pd <= req_wdata; ps <= req_wstrb;
    end
  end

  // ------------------------------------------------------------ TC03 fill-port monitor + shadow
  localparam int FQ = 32;
  logic [31:0]   f_a [0:FQ-1];
  logic [DW-1:0] f_d [0:FQ-1];
  logic [WB-1:0] f_s [0:FQ-1];
  int            f_k [0:FQ-1];
  int f_head = 0, f_tail = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      f_head = 0; f_tail = 0;
    end else begin
      if (t_rs_v && op_rs_r) begin                      // TC03's own response (before injection)
        int h; h = f_head % FQ; f_head = f_head + 1;
        if (!t_rs_e) for (int b = 0; b < WB; b++) if (f_s[h][b]) begin
          if (sh_lw[f_a[h] + b] == f_k[h]) `ERR(("TC03 byte %h written twice by descriptor %0d", f_a[h] + b, f_k[h]))
          shadow[f_a[h] + b] = {1'b0, f_d[h][8*b +: 8]};
          sh_lw[f_a[h] + b]  = f_k[h];
        end
      end
      if (op_rq_v && op_rq_r) begin
        int t; longint base; int sset;
        t = f_tail % FQ; f_tail = f_tail + 1;
        f_a[t] = op_rq_a; f_d[t] = op_rq_d; f_s[t] = op_rq_s; f_k[t] = ld_cur;
        n_op_wr = n_op_wr + 1;
        if (!op_rq_we) `ERR(("TC03 fill port: read request"))
        if (ld_cur < 0 || ld_state != `TDMA_CH_RUN) `ERR(("TC03 write %h while no LOAD is running", op_rq_a))
        else begin
          base = win_base(ld_cur);
          sset = d_set[ld_cur];
          if (op_state[sset*2 +: 2] != `TDMA_BS_FILLING) `ERR(("TC03 write to set %0d that is not FILLING", sset))
          for (int b = 0; b < WB; b++)
            if (op_rq_s[b] && !dst_has(ld_cur, longint'(op_rq_a) + b - base))
              `ERR(("TC03 write byte %h outside descriptor %0d", op_rq_a + b, ld_cur))
          if (op_rq_s == '0) `ERR(("TC03 write with an empty strobe"))
        end
      end
      if (ob_rq_v && ob_rq_r) n_ob_rd = n_ob_rd + 1;
    end
  end

  // a FENCE descriptor (and, in SEQUENTIAL mode, every descriptor) starts only after every older one completed
  task automatic fence_check(input int k);
    int pend;
    pend = 0;
    if (seq_check != 0 || d_flags[k][`TDMA_F_FENCE]) begin
      for (int i = 0; i < k; i++) if (d_part[i] == part && !d_fin[i]) pend = pend + 1;
      if (pend != 0) `ERR(("descriptor %0d started with %0d older descriptors not completed (%s)", k, pend,
                           (seq_check != 0) ? "SEQUENTIAL" : "FENCE"))
    end
  endtask

  // ------------------------------------------------------------ channel tracking
  logic [2:0] ld_prev = `TDMA_CH_IDLE, st_prev = `TDMA_CH_IDLE;
  always @(posedge clk) begin
    if (!rst_n) begin
      ld_prev <= `TDMA_CH_IDLE; st_prev <= `TDMA_CH_IDLE;
    end else begin
      if (ld_prev == `TDMA_CH_IDLE && ld_state != `TDMA_CH_IDLE) begin
        if (ld_p >= ld_n) `ERR(("load channel started with no descriptor submitted"))
        else begin ld_cur = ld_list[ld_p]; ld_p = ld_p + 1;
          if (d_id[ld_cur] != ld_id) `ERR(("load channel runs id %0d, expected %0d", ld_id, d_id[ld_cur]))
          fence_check(ld_cur); end
      end
      if (ld_prev != `TDMA_CH_RUN && ld_state == `TDMA_CH_RUN && ld_cur >= 0) d_set[ld_cur] = int'(fill_set);
      if (st_prev == `TDMA_CH_IDLE && st_state != `TDMA_CH_IDLE) begin
        if (st_p >= st_n) `ERR(("store channel started with no descriptor submitted"))
        else begin st_cur = st_list[st_p]; st_p = st_p + 1;
          if (d_id[st_cur] != st_id) `ERR(("store channel runs id %0d, expected %0d", st_id, d_id[st_cur]))
          fence_check(st_cur); end
      end
      ld_prev <= ld_state; st_prev <= st_state;
    end
  end

  // ------------------------------------------------------------ completions
  always @(posedge clk) if (rst_n && ev_cpl && id2idx[ev_cpl_id] >= 0) d_fin[id2idx[ev_cpl_id]] = 1'b1;
  int n_cpl = 0, next_seq = 0;
  always @(posedge clk) cpl_ready <= !pct(4, cpl_bp);
  always @(posedge clk) if (rst_n && cpl_valid && cpl_ready) begin
    int k;
    k = id2idx[cpl_id];
    n_cpl = n_cpl + 1;
    if (k < 0 || k >= n_desc) `ERR(("completion for unknown id %0d", cpl_id))
    else if (d_done[k]) `ERR(("second completion for descriptor %0d (id %0d)", k, cpl_id))
    else if (d_part[k] != part) `ERR(("completion of descriptor %0d of reset part %0d", k, d_part[k]))
    else begin
      if (seq_check != 0) begin
        while (next_seq < n_desc && (d_part[next_seq] != part || d_done[next_seq])) next_seq = next_seq + 1;
        if (next_seq != k) `ERR(("SEQUENTIAL: descriptor %0d completed before %0d", k, next_seq))
      end
      d_done[k] = 1'b1;
      if (cpl_kind != d_kind[k]) `ERR(("desc %0d: completion kind %0d, expected %0d", k, cpl_kind, d_kind[k]))
      if (cpl_code != e_code[k]) `ERR(("desc %0d: code %0d, expected %0d", k, cpl_code, e_code[k]))
      if (e_bytes[k] != 32'hFFFF_FFFF && cpl_bytes != e_bytes[k]) `ERR(("desc %0d: bytes %0d, expected %0d", k, cpl_bytes, e_bytes[k]))
      if (e_eaddr[k] != 32'hFFFF_FFFF && cpl_err_addr != e_eaddr[k]) `ERR(("desc %0d: err_addr %h, expected %h", k, cpl_err_addr, e_eaddr[k]))
      if (e_det[k] != 4'hF && cpl_detail != e_det[k][2:0]) `ERR(("desc %0d: detail %0d, expected %0d", k, cpl_detail, e_det[k]))
      if (cpl_code != `TDMA_C_OK && e_bytes[k] == 32'hFFFF_FFFF &&
          cpl_bytes > 32'(d_len[k]) * 32'(d_rows[k])) `ERR(("desc %0d: bytes %0d beyond the transfer", k, cpl_bytes))
      if (cpl_code == `TDMA_C_OK && e_code[k] == `TDMA_C_OK) check_written(k);
    end
  end

  // every destination byte must already have been performed by this descriptor
  task automatic check_written(input int k);
    longint s, o, base; int bad;
    bad = 0;
    for (int r = 0; r < d_rows[k]; r++) for (int i = 0; i < d_len[k]; i++) begin
      s = longint'(d_dst[k]) + longint'(r) * longint'(d_dstr[k]) + i;
      if (d_kind[k] == `TDMA_K_STORE) begin
        o = s - MEM_BASE;
        if (lw[o] != k) bad++;
      end else begin
        base = win_base(k);
        if (sh_lw[base + s] != k) bad++;
      end
    end
    if (bad != 0) `ERR(("desc %0d completed OK but %0d destination bytes were not yet performed by it", k, bad))
  endtask

  // ------------------------------------------------------------ compute consumer of operand sets
  int cs = 0, c_cnt = 0, seal_idx = 0, seals_seen = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      cs = 0; seal_idx = 0; cb_v <= 1'b0; ce_v <= 1'b0;
    end else begin
      case (cs)
        0: if (op_state[cmp_set*2 +: 2] == `TDMA_BS_READY) begin c_cnt = rrange(5, 0, cons_dly); cs = 1; end
        1: if (c_cnt == 0) begin cb_v <= 1'b1; cs = 2; end else c_cnt = c_cnt - 1;
        2: if (cb_v && cb_r) begin
             cb_v <= 1'b0; if (part == parts) check_set(int'(cmp_set)); seal_idx = seal_idx + 1; seals_seen = seals_seen + 1;
             c_cnt = rrange(6, 0, cons_hold); cs = 3;
           end
        3: if (c_cnt == 0) begin ce_v <= 1'b1; cs = 4; end else c_cnt = c_cnt - 1;
        4: if (ce_v && ce_r) begin ce_v <= 1'b0; cs = 0; end
        default: cs = 0;
      endcase
    end
  end

  task automatic check_set(input int s);
    int bad, first; logic [8:0] e, g;
    bad = 0; first = -1;
    if (seal_idx >= n_seal_exp) `ERR(("compute took set %0d but the reference has only %0d sealed sets", s, n_seal_exp))
    else for (int i = 0; i < ASB + BSB; i++) begin
      e = sexp[seal_idx * (ASB + BSB) + i];
      g = (i < ASB) ? shadow[s * ASB + i] : shadow[REGION + s * BSB + (i - ASB)];
      if (!e[8] && g != e) begin bad++; if (first < 0) first = i; end
    end
    if (bad != 0) `ERR(("operand set %0d (seal %0d): %0d bytes differ from the reference (first at %s+%0d)", s, seal_idx,
                        bad, (first < ASB) ? "A" : "B", (first < ASB) ? first : first - ASB))
  endtask

  // ------------------------------------------------------------ compute producer of output tiles
  logic [15:0] t_tag  [0:MAXT-1];
  int          t_rows [0:MAXT-1], t_cols [0:MAXT-1], t_off [0:MAXT-1], t_dly [0:MAXT-1];
  logic [31:0] tiles  [0:65535];
  int tq_head = 0, tq_tail = 0, ps_ = 0, p_row = 0, p_cnt = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      ps_ = 0; tq_head = tq_tail; pin_v <= 1'b0;
    end else begin
      case (ps_)
        0: if (tq_head != tq_tail) begin p_row = 0; p_cnt = t_dly[tq_head % MAXT] + rrange(7, 0, prod_gap); ps_ = 1; end
        1: if (p_cnt == 0) begin
             int h; logic [TN*32-1:0] dd;
             h = tq_head % MAXT; dd = '0;
             for (int j = 0; j < TN; j++) if (j < t_cols[h]) dd[32*j +: 32] = tiles[t_off[h] + p_row * t_cols[h] + j];
             pin_v <= 1'b1; pin_row <= 2'(p_row); pin_mask <= TN'((1 << t_cols[h]) - 1); pin_data <= dd;
             pin_last <= (p_row == t_rows[h] - 1); pin_tag <= t_tag[h];
             ps_ = 2;
           end else p_cnt = p_cnt - 1;
        2: if (pin_v && pin_r) begin
             pin_v <= 1'b0; p_row = p_row + 1;
             if (p_row == t_rows[tq_head % MAXT]) begin tq_head = tq_head + 1; ps_ = 0; end
             else begin p_cnt = rrange(7, 0, prod_gap); ps_ = 1; end
           end
        default: ps_ = 0;
      endcase
    end
  end

  // ============================================================ program driver
  string dir;
  int    fd, rc;
  logic [31:0] f [0:17];
  int    n_tiles = 0, ob_refused = 0, ob_conflicts = 0;
  always @(posedge clk) if (rst_n) begin
    if (ob_ev_ref) ob_refused = ob_refused + 1;
    if (ob_ev_werr) `ERR(("output buffer: a producer write was answered with an error"))
    if (ob_ev_conf != 2'b00) ob_conflicts = ob_conflicts + 1;
  end

  task automatic do_reset(input int cycles);
    @(negedge clk) rst_n <= 1'b0;
    repeat (cycles) @(posedge clk);
    @(negedge clk) rst_n <= 1'b1;
  endtask

  task automatic send_desc(input int k);
    logic [`TDMA_DESC_W-1:0] v;
    v = '0;
    v[`TDMA_D_SRC] = d_src[k]; v[`TDMA_D_DST] = d_dst[k]; v[`TDMA_D_SSTRIDE] = d_sstr[k];
    v[`TDMA_D_DSTRIDE] = d_dstr[k]; v[`TDMA_D_ROWLEN] = d_len[k]; v[`TDMA_D_ROWS] = d_rows[k];
    v[`TDMA_D_ID] = d_id[k]; v[`TDMA_D_KIND] = d_kind[k]; v[`TDMA_D_FLAGS] = d_flags[k];
    v[`TDMA_D_RSVD] = d_rsvd[k]; v[`TDMA_D_VER] = d_ver[k];
    repeat (rrange(8, 0, gap_max)) @(posedge clk);
    @(negedge clk) begin desc_valid <= 1'b1; desc_data <= v; end
    @(posedge clk);
    while (!desc_ready) @(posedge clk);
    // accepted at this edge: record the channel order
    if (d_kind[k] == `TDMA_K_STORE) begin st_list[st_n] = k; st_n = st_n + 1; end
    else begin ld_list[ld_n] = k; ld_n = ld_n + 1; end
    @(negedge clk) desc_valid <= 1'b0;
  endtask

  function automatic bit sets_quiet();
    bit q;
    q = 1;
    for (int i = 0; i < NS; i++) if (op_state[i*2 +: 2] == `TDMA_BS_READY || op_state[i*2 +: 2] == `TDMA_BS_IN_USE) q = 0;
    return q;
  endfunction

  function automatic bit all_done();
    bit d;
    d = 1;
    for (int k = 0; k < n_desc; k++) if (!d_done[k] && d_part[k] == part && !d_opt[k]) d = 0;
    return d;
  endfunction

  longint maxcyc = 2_000_000;
  bit drain_ok = 0, prog_done = 0, cpl_reached = 0;
  int wait_n = 0;
  always @(posedge clk) cpl_reached <= (n_cpl >= wait_n);
  always @(posedge clk)
    drain_ok <= prog_done && all_done() && !busy && !cpl_valid && cs == 0 && sets_quiet() && ps_ == 0 &&
                tq_head == tq_tail && q_head == q_tail && !rsp_v_q;
  always @(posedge clk) if ($test$plusargs("hb") && cyc % 100 == 0) begin $display("HB cyc=%0d ndesc=%0d cpl=%0d busy=%0d ld=%0d st=%0d dv=%0d dr=%0d opst=%b cs=%0d", cyc, n_desc, n_cpl, busy, ld_state, st_state, desc_valid, desc_ready, op_state, cs); $fflush(); end
  // global watchdog: a hang anywhere (driver, DUT, models) ends the run with a state dump
  always @(posedge clk) if (cyc == maxcyc + 1000) begin
    `ERR(("WATCHDOG: no progress (desc %0d/%0d submitted? cpl=%0d busy=%0d ld=%0d st=%0d op_state=%b ob_state=%b cs=%0d ps=%0d fill_set=%0d tq=%0d/%0d)",
          n_desc, n_desc, n_cpl, busy, ld_state, st_state, op_state, ob_state, cs, ps_, fill_set, tq_head, tq_tail))
    $display("RESULT FAIL");
    $finish;
  end

  initial begin
    int s, op, nl; logic [31:0] pre;
    if (!$value$plusargs("dir=%s", dir)) dir = ".";
    if (!$value$plusargs("seed=%d", s)) s = 1;
    for (int i = 0; i < 16; i++) rs[i] = 32'h9E37_79B9 * (s + i * 7919) + 32'h1234_5 + i;
    void'($value$plusargs("lat_min=%d", lat_min));
    void'($value$plusargs("lat_max=%d", lat_max));
    void'($value$plusargs("bp=%d", bp));
    void'($value$plusargs("xbar=%d", xbar));
    void'($value$plusargs("cpl_bp=%d", cpl_bp));
    void'($value$plusargs("gap=%d", gap_max));
    void'($value$plusargs("cons_dly=%d", cons_dly));
    void'($value$plusargs("cons_hold=%d", cons_hold));
    void'($value$plusargs("prod_gap=%d", prod_gap));
    void'($value$plusargs("rst_delay=%d", rst_delay));
    void'($value$plusargs("rst_len=%d", rst_len));
    void'($value$plusargs("maxcyc=%d", maxcyc));
    void'($value$plusargs("parts=%d", parts));
    begin int p; if ($value$plusargs("prefetch=%d", p)) prefetch = (p != 0); end
    seq_check = prefetch ? 0 : 1;
    if (lat_max < lat_min) lat_max = lat_min;

    for (int i = 0; i < 256; i++) id2idx[i] = -1;
    for (int i = 0; i < MEM_BYTES; i++) lw[i] = -1;
    for (int i = 0; i < WIN; i++) begin shadow[i] = 9'h100; sh_lw[i] = -1; end
    $readmemh({dir, "/mem_init.hex"}, mem);
    $readmemh({dir, "/mem_exp.hex"}, mexp);
    $readmemh({dir, "/tiles.hex"}, tiles);
    fd = $fopen({dir, "/seals.txt"}, "r");
    rc = $fscanf(fd, "%d", n_seal_exp); $fclose(fd);
    if (n_seal_exp > 0) $readmemh({dir, "/seal_exp.hex"}, sexp);

    do_reset(5);
    fd = $fopen({dir, "/prog.txt"}, "r");
    if (fd == 0) begin $display("FATAL: no program in %s", dir); $finish; end
    nl = 0;
    rc = 18;
    while (!$feof(fd) && rc == 18) begin
      rc = $fscanf(fd, "%h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h\n", f[0], f[1], f[2], f[3], f[4], f[5],
                   f[6], f[7], f[8], f[9], f[10], f[11], f[12], f[13], f[14], f[15], f[16], f[17]);
      nl = nl + 1;
      op = (rc == 18) ? int'(f[0]) : 0;
      case (op)
        1: begin                                   // D: descriptor
          int k; k = n_desc; n_desc = n_desc + 1;
          d_id[k] = f[1][7:0]; d_kind[k] = f[2][1:0]; d_flags[k] = f[3][5:0]; d_src[k] = f[4]; d_dst[k] = f[5];
          d_sstr[k] = f[6]; d_dstr[k] = f[7]; d_len[k] = f[8][15:0]; d_rows[k] = f[9][15:0];
          d_ver[k] = f[10][7:0]; d_rsvd[k] = f[11][7:0]; e_code[k] = f[12][3:0]; e_bytes[k] = f[13];
          e_eaddr[k] = f[14]; e_det[k] = f[15][3:0]; d_part[k] = int'(f[16]); d_opt[k] = f[17][0];
          d_done[k] = 1'b0; d_fin[k] = 1'b0; d_set[k] = 0;
          if (id2idx[d_id[k]] >= 0 && d_part[id2idx[d_id[k]]] == part) `ERR(("program reuses id %0d", d_id[k]))
          id2idx[d_id[k]] = k;
          send_desc(k);
        end
        2: begin                                   // T: output tile for the producer
          int h; h = tq_tail % MAXT;
          t_tag[h] = f[1][15:0]; t_rows[h] = int'(f[2]); t_cols[h] = int'(f[3]); t_off[h] = int'(f[4]);
          t_dly[h] = int'(f[5]);
          tq_tail = tq_tail + 1; n_tiles = n_tiles + 1;
        end
        3: begin                                   // R: reset while part 1 is in flight
          repeat (rst_delay) @(posedge clk);
          begin int done1; done1 = 0;
            for (int i = 0; i < n_desc; i++) if (d_done[i]) done1 = done1 + 1;
            $display("RESET at cyc=%0d busy=%0d ld=%0d st=%0d sfb_out=%0d completed=%0d/%0d", cyc, busy, ld_state, st_state,
                     outst_q, done1, n_desc);
            if (!busy || (ld_state == `TDMA_CH_IDLE && st_state == `TDMA_CH_IDLE))
              `ERR(("reset test: no transfer in flight at the reset instant"))
          end
          do_reset(rst_len);
          part = part + 1;
          ld_n = 0; st_n = 0; ld_p = 0; st_p = 0; ld_cur = -1; st_cur = -1; next_seq = 0;
          for (int i = 0; i < WIN; i++) begin shadow[i] = 9'h100; sh_lw[i] = -1; end
          inj_op_n = -1; inj_ob_n = -1; err_rd = 32'hFFFF_FFFF; err_wr = 32'hFFFF_FFFF;
        end
        4: begin                                   // E: error injection
          case (int'(f[1]))
            1: err_rd = f[2];
            2: err_wr = f[2];
            3: begin inj_op_n = int'(f[2]); inj_op_kind = 3; end
            4: inj_ob_n = int'(f[2]);
            5: begin inj_op_n = int'(f[2]); inj_op_kind = 5; end
            default: ;
          endcase
        end
        5: begin                                   // W: wait for completions
          wait_n = int'(f[1]);
          while (!cpl_reached && cyc < maxcyc) @(posedge clk);
        end
        6: repeat (int'(f[1])) @(posedge clk);     // G: gap
        default: ;
      endcase
    end
    $fclose(fd);
    prog_done = 1;

    // drain (the condition is computed by a clocked process: Verilator 5.020 --timing does not yield
    // reliably on a loop whose condition calls looping functions)
    while (!drain_ok && cyc < maxcyc) @(posedge clk);
    repeat (20) @(posedge clk);
    if (cyc >= maxcyc) `ERR(("timeout: %0d of %0d descriptors completed (busy=%0d ld=%0d st=%0d)", n_cpl, n_desc,
                             busy, ld_state, st_state))
    for (int k = 0; k < n_desc; k++)
      if (!d_done[k] && d_part[k] == part && !d_opt[k]) `ERR(("descriptor %0d (id %0d) never completed", k, d_id[k]))
    if (seals_seen != n_seal_exp && part == 1) `ERR(("compute took %0d sets, reference sealed %0d", seals_seen, n_seal_exp))
    if (part > 1 && seal_idx != n_seal_exp) `ERR(("after reset compute took %0d sets, reference sealed %0d", seal_idx, n_seal_exp))
    begin int bad, first; bad = 0; first = -1;
      for (int i = 0; i < MEM_BYTES; i++) if (!mexp[i][8] && {1'b0, mem[i]} != mexp[i]) begin bad++; if (first < 0) first = i; end
      if (bad != 0) `ERR(("final memory: %0d bytes differ (first at %h: %h, expected %h)", bad, MEM_BASE + first,
                          mem[first], mexp[first][7:0]))
    end
    if (pc_viol != 0) `ERR(("sfb_protocol_checker: %0d violations", pc_viol))
    if (ob_refused != 0) `ERR(("output buffer gate refused %0d requests", ob_refused))
    if (ev_proto) `ERR(("unsolicited response"))
    for (int i = 0; i < NPC; i++) $display("PERF %0d %0d", i, perf_cnt[i*32 +: 32]);
    $display("STATS desc=%0d cpl=%0d sfb_rd=%0d sfb_wr=%0d op_wr=%0d ob_rd=%0d seals=%0d tiles=%0d ob_conflicts=%0d cycles=%0d",
             n_desc, n_cpl, n_rd, n_wr, n_op_wr, n_ob_rd, seals_seen, n_tiles, ob_conflicts, cyc);
    $display("RESULT %s", (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule
