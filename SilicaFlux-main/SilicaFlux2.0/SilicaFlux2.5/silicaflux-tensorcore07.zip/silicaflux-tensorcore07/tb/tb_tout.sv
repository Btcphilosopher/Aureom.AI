// =============================================================================
// SilicaFlux TENSORCORE 07 :: tb_tout
// Directed test of tensor_output_buffer ownership enforcement (the adapter never
// issues an illegal access, so the gates are exercised here directly):
//   1. DMA read of a FREE set               -> OWNER, no data
//   2. producer writes tile 0 -> set 0 READY with the tile record
//   3. DMA read of a READY set (no rd_begin) -> OWNER
//   4. rd_begin -> IN_USE; DMA reads return tile 0 exactly
//   5. DMA WRITE to the IN_USE set          -> UNSUP, and the set is unchanged
//   6. DMA read beyond the buffer           -> RANGE
//   7. producer tile 1 -> set 1; producer tile 2 must WAIT (set 0 still IN_USE)
//      and set 0 must still hold tile 0 (not overwritten before release)
//   8. rd_end set 0 -> FREE -> tile 2 lands in set 0; drain set 1 then set 0
// Prints RESULT PASS / FAIL.
// =============================================================================
`timescale 1ns/1ps
`include "tdma_defs.svh"
`include "hpc_spm_defs.svh"

module tb_tout;
  parameter int OPM = 0;
  localparam int OSB = 256, OLD = 16;
  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; $write("ERROR t=%0t: ", $time); $display args ; end

  logic in_v = 1'b0, in_r, in_last = 1'b0; logic [1:0] in_row = '0; logic [3:0] in_mask = '0; logic [127:0] in_data = '0;
  logic [15:0] in_tag = '0;
  logic d_v = 1'b0, d_r, d_we = 1'b0, r_v, r_e, r_we; logic [31:0] d_a = '0, d_wd = '0, r_d; logic [3:0] d_s = '0;
  logic [7:0] d_t = '0, r_t; logic [2:0] r_c;
  logic rb_v = 1'b0, rb_r, re_v = 1'b0, re_r; logic [0:0] wr_set, rd_set; logic [3:0] st;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] tag_o; logic [5:0] rows_o, cols_o, flags_o; logic e_wr, e_rd, e_ref, e_werr, e_wait; logic [1:0] e_conf;
  /* verilator lint_on UNUSEDSIGNAL */
  int waits = 0;
  always @(posedge clk) if (e_wait) waits = waits + 1;

  tensor_output_buffer #(.WB(4), .O_SETS(2), .O_SET_BYTES(OSB), .TILE_M(4), .TILE_N(4), .O_LD(OLD), .NUM_BANKS(2),
                         .PORT_MODE(OPM), .READ_LATENCY(1), .TAG_W(8)) dut (
    .clk(clk), .rst_n(rst_n), .in_valid(in_v), .in_ready(in_r), .in_row(in_row), .in_col_mask(in_mask),
    .in_data(in_data), .in_last(in_last), .in_tag(in_tag), .in_err(1'b0), .in_ovf(4'd0),
    .d_req_valid(d_v), .d_req_ready(d_r), .d_req_we(d_we), .d_req_addr(d_a), .d_req_wdata(d_wd), .d_req_wstrb(d_s),
    .d_req_tag(d_t), .d_rsp_valid(r_v), .d_rsp_ready(1'b1), .d_rsp_rdata(r_d), .d_rsp_err(r_e), .d_rsp_err_code(r_c),
    .d_rsp_we(r_we), .d_rsp_tag(r_t), .rd_begin_valid(rb_v), .rd_begin_ready(rb_r), .rd_end_valid(re_v),
    .rd_end_ready(re_r), .wr_set(wr_set), .rd_set(rd_set), .set_state(st), .set_tag(tag_o), .set_rows(rows_o),
    .set_cols(cols_o), .set_flags(flags_o), .ev_wr(e_wr), .ev_rd(e_rd), .ev_conflict(e_conf), .ev_refused(e_ref),
    .ev_wr_err(e_werr), .ev_wr_wait(e_wait));

  function automatic logic [31:0] val(input int t, input int r, input int j);
    return 32'hC0DE_0000 ^ (32'(t) << 20) ^ (32'(r) << 8) ^ 32'(j);
  endfunction

  // DMA access: returns {err, code, data} after the response
  logic [35:0] acc_res;
  task automatic dma(input logic we, input logic [31:0] a, input logic [31:0] wd);
    @(negedge clk) begin d_v <= 1'b1; d_we <= we; d_a <= a; d_wd <= wd; d_s <= we ? 4'hF : 4'h0; d_t <= d_t + 8'd1; end
    @(posedge clk); while (!d_r) @(posedge clk);
    @(negedge clk) d_v <= 1'b0;
    while (!r_v) @(posedge clk);
    acc_res = {r_e, r_c, r_d};
    if (r_t != d_t) `ERR(("response tag %0d, request %0d", r_t, d_t))
    @(posedge clk);
  endtask
  task automatic expect_err(input logic we, input logic [31:0] a, input logic [2:0] code, input string what);
    dma(we, a, 32'hDEAD_BEEF);
    if (!acc_res[35] || acc_res[34:32] != code || acc_res[31:0] != 32'd0)
      `ERR(("%s: got err=%0d code=%0d data=%h, expected code %0d", what, acc_res[35], acc_res[34:32], acc_res[31:0], code))
  endtask
  task automatic expect_tile(input int s, input int t, input string what);
    for (int r = 0; r < 4; r++) for (int j = 0; j < 4; j++) begin
      dma(1'b0, 32'(s * OSB + r * OLD + 4 * j), 32'd0);
      if (acc_res[35] || acc_res[31:0] != val(t, r, j)) `ERR(("%s: set %0d row %0d col %0d = %h (err %0d), expected %h", what,
                                                               s, r, j, acc_res[31:0], acc_res[35], val(t, r, j)))
    end
  endtask
  task automatic produce(input int t);                // 4 x 4 tile, rows presented back to back
    for (int r = 0; r < 4; r++) begin
      @(negedge clk) begin
        in_v <= 1'b1; in_row <= 2'(r); in_mask <= 4'hF; in_last <= (r == 3); in_tag <= 16'(t);
        for (int j = 0; j < 4; j++) in_data[32*j +: 32] <= val(t, r, j);
      end
      @(posedge clk); while (!in_r) @(posedge clk);
    end
    @(negedge clk) in_v <= 1'b0;
  endtask
  task automatic cmd(input bit is_begin);
    @(negedge clk) if (is_begin) rb_v <= 1'b1; else re_v <= 1'b1;
    @(posedge clk); while (!(is_begin ? rb_r : re_r)) @(posedge clk);
    @(negedge clk) begin rb_v <= 1'b0; re_v <= 1'b0; end
  endtask
  function automatic logic [1:0] sst(input int s);
    return st[s*2 +: 2];
  endfunction

  bit p2_done = 0;
  initial begin
    repeat (3) @(posedge clk);
    @(negedge clk) rst_n <= 1'b1;
    repeat (2) @(posedge clk);
    expect_err(1'b0, 32'd0, 3'd6, "1: read of a FREE set");
    produce(0);
    while (sst(0) != `TDMA_BS_READY) @(posedge clk);
    if (tag_o[15:0] != 16'd0 || rows_o[2:0] != 3'd4 || cols_o[2:0] != 3'd4) `ERR(("2: tile record wrong"))
    expect_err(1'b0, 32'd4, 3'd6, "3: read of a READY set before rd_begin");
    cmd(1'b1);
    if (sst(0) != `TDMA_BS_IN_USE) `ERR(("4: set 0 not IN_USE after rd_begin"))
    expect_tile(0, 0, "4: drain tile 0");
    expect_err(1'b1, 32'd8, 3'd7, "5: DMA write into the output buffer");
    expect_tile(0, 0, "5: set 0 unchanged after the refused write");
    expect_err(1'b0, 32'(2 * OSB), 3'd1, "6: read beyond the buffer");
    produce(1);                                      // -> set 1
    while (sst(1) != `TDMA_BS_READY) @(posedge clk);
    fork
      begin produce(2); p2_done = 1; end            // must wait for set 0
    join_none
    repeat (40) @(posedge clk);
    if (p2_done || waits == 0) `ERR(("7: tile 2 was not held back while set 0 is IN_USE"))
    expect_tile(0, 0, "7: set 0 still holds tile 0 before its release");
    cmd(1'b0);                                       // release set 0
    while (!p2_done) @(posedge clk);
    while (sst(0) != `TDMA_BS_READY) @(posedge clk);
    cmd(1'b1); expect_tile(1, 1, "8: drain tile 1 (set 1)"); cmd(1'b0);
    cmd(1'b1); expect_tile(0, 2, "8: drain tile 2 (set 0)"); cmd(1'b0);
    if (st != 4'b0000) `ERR(("8: sets not FREE at the end: %b", st))
    $display("RESULT %s", (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #2_000_000; `ERR(("timeout")); $display("RESULT FAIL"); $finish; end
endmodule
