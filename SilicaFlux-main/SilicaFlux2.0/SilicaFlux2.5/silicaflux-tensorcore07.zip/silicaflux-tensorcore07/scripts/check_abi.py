#!/usr/bin/env python3
"""Check that model/tdma_desc.py (host / test mirror) matches the RTL ABI in rtl/tdma_defs.svh exactly:
descriptor field positions, version, kinds, flags, completion codes, buffer states, counter indices."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "model"))
import tdma_desc as m  # noqa: E402


def main():
    src = (ROOT / "rtl/tdma_defs.svh").read_text()
    d = dict(re.findall(r"`define\s+(TDMA_\w+)\s+([^\s/]+)", src))
    errs = []

    def num(v):
        v = v.strip()
        if "'" in v:
            base = v.split("'")[1][0].lower()
            digits = v.split("'")[1][1:]
            return int(digits, {"d": 10, "h": 16, "b": 2}[base])
        return int(v)

    if num(d["TDMA_DESC_W"]) != m.DESC_W:
        errs.append("DESC_W")
    if num(d["TDMA_VERSION"]) != m.VERSION:
        errs.append("VERSION")
    for f, (lsb, w) in m.FIELDS.items():
        hi, lo = map(int, d[f"TDMA_D_{f}"].split(":"))
        if (lo, hi - lo + 1) != (lsb, w):
            errs.append(f"field {f}: RTL [{hi}:{lo}], Python lsb {lsb} width {w}")
    for k, v in (("LOAD_A", m.K_LOAD_A), ("LOAD_B", m.K_LOAD_B), ("STORE", m.K_STORE), ("RSVD", m.K_RSVD)):
        if num(d[f"TDMA_K_{k}"]) != v:
            errs.append(f"kind {k}")
    if 1 << int(d["TDMA_F_SEAL"]) != m.F_SEAL or 1 << int(d["TDMA_F_FENCE"]) != m.F_FENCE:
        errs.append("flags")
    if num(d["TDMA_F_RSVD_MASK"]) != m.F_RSVD_MASK:
        errs.append("reserved flag mask")
    for name, v in m.CODES.items():
        if num(d[f"TDMA_C_{name}"]) != v:
            errs.append(f"code {name}")
    for name, v in m.BS.items():
        if num(d[f"TDMA_BS_{name}"]) != v:
            errs.append(f"buffer state {name}")
    if int(d["TDMA_NUM_PC"]) != len(m.PC_NAMES):
        errs.append("number of counters")
    for i, name in enumerate(m.PC_NAMES):
        if int(d[f"TDMA_PC_{name}"]) != i:
            errs.append(f"counter {name}")
    print("ABI check:", "OK" if not errs else "MISMATCH " + "; ".join(errs))
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
