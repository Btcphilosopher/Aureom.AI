#!/usr/bin/env python3
"""Throughput sweep of single transfers (tb_tdma, self-checking) for reports/throughput.md.

One descriptor per run, so the adapter's own counters give its time: transfer cycles = channel busy cycles
minus buffer-wait cycles (LD_BUSY - BUF_WAIT for loads, ST_BUSY - BUF_WAIT for stores).
Axes: MAX_OUT (SFB2 transactions in flight) x WB (bus width) x memory latency x DataFabric R6 mode, for
aligned / misaligned 1-D and 2-D loads and stores.
"""
from __future__ import annotations

import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BASE, BUILD, REPORTS, ROOT, build, hwcfg, parse, simulate, tool_versions, write_json  # noqa: E402

sys.path.insert(0, str(ROOT / "model"))
from gen_tests import Prog  # noqa: E402
from tdma_desc import K_LOAD_A, K_STORE  # noqa: E402


def programs(cfg):
    hc = hwcfg(cfg)
    out = {}

    def mk(name, fn):
        p = Prog(hc, 5)
        fn(p)
        p.write(BUILD / "perf" / f"wb{cfg['WB']}" / name)
        out[name] = p.next_id

    mk("load1d_aligned", lambda p: p.d(K_LOAD_A, p.ea(0x1000), 0, 1024))
    mk("load1d_misaligned", lambda p: p.d(K_LOAD_A, p.ea(0x1001), 3, 1021))
    mk("load2d_32x31", lambda p: p.d(K_LOAD_A, p.ea(0x1003), 1, 31, 32, 97, 32))
    mk("load2d_256x4", lambda p: p.d(K_LOAD_A, p.ea(0x1002), 0, 4, 256, 13, 4))        # B-like: narrow rows
    def st(p, src, dst, ln):
        p.tile()
        p.d(K_STORE, src, p.ea(dst), ln)
    mk("store1d_aligned", lambda p: st(p, 0, 0x4000, 256))
    mk("store1d_misaligned", lambda p: st(p, 1, 0x4003, 255))
    return out


MAXOUTS = [1, 2, 4, 8, 16]
MEM = {"lat1": dict(), "lat4": dict(lat_min=4, lat_max=4), "lat8": dict(lat_min=8, lat_max=8),
       "lat16": dict(lat_min=16, lat_max=16), "xbar_lat1": dict(xbar=1), "xbar_lat4": dict(xbar=1, lat_min=4, lat_max=4)}


def main():
    rows = []
    jobs = []
    for wb in (4, 8):
        for mo in MAXOUTS:
            cfg = dict(BASE, WB=wb, MAXOUT=mo, LOCOUT=min(8, max(2, mo)), RCAP=64 if wb == 4 else 128, QD=4)
            progs = programs(cfg)
            exe, log = build("verilator", "tb_tdma", "tb/tb_tdma.sv", cfg)
            if exe is None:
                print(log[-2000:])
                raise SystemExit("build failed")
            for pn in progs:
                for mn, mp in MEM.items():
                    jobs.append((wb, mo, pn, mn, mp, exe))

    def one(j):
        wb, mo, pn, mn, mp, exe = j
        rc, log = simulate("verilator", exe, dict(mp, dir=str(BUILD / "perf" / f"wb{wb}" / pn), seed=1, prod_gap=0))
        r = parse(log)
        p = r["perf"]
        store = pn.startswith("store")
        busy = (p.get("ST_BUSY", 0) if store else p.get("LD_BUSY", 0)) - p.get("BUF_WAIT", 0)
        nbytes = p.get("WR_BYTES", 0)
        return dict(wb=wb, max_out=mo, program=pn, mem=mn, ok=(r["result"] == "PASS"), errors=r["errors"][:3],
                    bytes=nbytes, cycles=busy, bpc=round(nbytes / busy, 3) if busy > 0 else None,
                    words_rd=r["stats"].get("sfb_rd", 0) + r["stats"].get("ob_rd", 0),
                    words_wr=r["stats"].get("sfb_wr", 0) + r["stats"].get("op_wr", 0),
                    sfb_stall=p.get("SFB_STALL", 0), out_max=p.get("OUT_MAX", 0))

    with ThreadPoolExecutor(4) as ex:
        rows = list(ex.map(one, jobs))
    ok = sum(r["ok"] for r in rows)
    print(f"perf: {ok}/{len(rows)} runs pass")
    for r in rows:
        if not r["ok"]:
            print("  FAIL", r)
    write_json(REPORTS / "perf.json", dict(tools=tool_versions(), total=len(rows), passed=ok, runs=rows))
    sys.exit(0 if ok == len(rows) else 1)


if __name__ == "__main__":
    main()
