#!/usr/bin/env python3
"""Build reports/*.md from the JSON results (every number in the markdown comes from a JSON file)."""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS  # noqa: E402

SURVIVOR_NOTES = {
    "M23": "Equivalent. The channel limits its own in-flight writes/reads with its meta FIFOs (MAXW = MAXR = max(2, LOC_OUT)), "
           "so the port is never offered more than LOC_OUT requests; the port limit is a second, redundant interlock. "
           "An invariant assertion (in-flight <= MAX_OUT) is kept in both ports.",
    "M27": "Equivalent. The edge that delivers the failing read sets the channel's error flag, and every write issue is gated "
           "by that flag, so bytes pushed from a failed read can never be written. The `!rr_err` term is defensive redundancy.",
    "M28": "Equivalent. TC03's own fill_begin_ready is true only for an EMPTY set, so presenting fill_begin early cannot open a "
           "set that is READY or IN_USE; the coordinator condition is a redundant interlock on top of TC03's hardware rule.",
}


def load(name):
    p = REPORTS / f"{name}.json"
    return json.loads(p.read_text()) if p.exists() else None


def tools(d):
    t = d.get("tools", {})
    return ", ".join(f"{k}: {v}" for k, v in t.items())


def regression():
    d = load("regression")
    if not d:
        return
    L = ["# Unit / system regression (tb_tdma)", "",
         f"**{d['passed']} / {d['total']} runs pass**, stages {d['stages']} in order (a failing stage stops the run). "
         f"Icarus vs Verilator cross-simulation: **{d['xsim']['identical']} / {d['xsim']['runs']}** run pairs with identical "
         f"bus statistics, cycle counts and counters. Wall time {d['seconds']} s. Tools: {tools(d)}.", "",
         "## Hardware configurations", "", "| config | parameters |", "|---|---|"]
    for c, p in d["configs"].items():
        L.append(f"| `{c}` | " + ", ".join(f"{k}={v}" for k, v in p.items()) + " |")
    L += ["", "## Runs per stage and configuration", "", "| stage | config | Verilator runs | pass | Icarus runs | pass |",
          "|---|---|---|---|---|---|"]
    agg = defaultdict(lambda: [0, 0, 0, 0])
    for r in d["runs"]:
        a = agg[(r["stage"], r["config"])]
        i = 0 if r["sim"] == "verilator" else 2
        a[i] += 1
        a[i + 1] += r["ok"]
    for (st, c), a in sorted(agg.items()):
        L.append(f"| {st} | `{c}` | {a[0]} | {a[1]} | {a[2]} | {a[3]} |")
    L += ["", "## Tests", "", "| test | stage | runs | pass | max cycles |", "|---|---|---|---|---|"]
    tt = defaultdict(lambda: [0, 0, 0, 0])
    for r in d["runs"]:
        a = tt[r["test"]]
        a[0] = r["stage"]
        a[1] += 1
        a[2] += r["ok"]
        a[3] = max(a[3], r["cycles"] or 0)
    for t, a in sorted(tt.items(), key=lambda x: (x[1][0], x[0])):
        L.append(f"| `{t}` | {a[0]} | {a[1]} | {a[2]} | {a[3]} |")
    fails = [r for r in d["runs"] if not r["ok"]]
    L += ["", f"Failing runs: {len(fails)}."] + [f"* {r['sim']} {r['config']} {r['test']} seed {r['seed']}: {r['errors'][:2]}"
                                                 for r in fails[:20]]
    (REPORTS / "regression.md").write_text("\n".join(L) + "\n")


def gemm():
    d = load("gemm")
    if not d:
        return
    L = ["# End-to-end GEMM integration (tb_tdma_gemm on tdma_tile_system)", "",
         f"**{d['passed']} / {d['total']} runs pass.** Every operand block and every C tile moves through "
         "tensor_dma_adapter over one SFB2 port; TC02 / TC03 / TC04 are unmodified. Each run compares the whole "
         "memory (C exact, everything else untouched) and checks every completion. Tools: " + tools(d), "",
         "## Workloads", "", "| workload | M x N x K | tiles | K chunks | descriptors | useful MACs |", "|---|---|---|---|---|---|"]
    for k, w in d["workloads"].items():
        L.append(f"| `{k}` | {w['M']} x {w['N']} x {w['K']} | {w['tiles']} | {w['chunks']} | {w['n_desc']} | {w['macs']} |")
    L += ["", "## Cycles: SEQUENTIAL (0) vs PREFETCH (1), configuration `base`", "",
          "| workload | memory | cycles seq | cycles prefetch | speed-up | array utilisation prefetch | DMA overlap cycles |",
          "|---|---|---|---|---|---|---|"]
    idx = {(r["workload"], r["hw"], r["mem"], r["prefetch"]): r for r in d["runs"]}
    for k in d["workloads"]:
        for m in d["mems"]:
            a, b = idx.get((k, "base", m, 0)), idx.get((k, "base", m, 1))
            if not a or not b or not a["stats"] or not b["stats"]:
                continue
            ca, cb = a["stats"]["cycles"], b["stats"]["cycles"]
            util = b["macs"] / (16 * cb)
            L.append(f"| `{k}` | {m} | {ca} | {cb} | {ca / cb:.2f}x | {100 * util:.1f} % | {b['perf'].get('OVERLAP', 0)} |")
    L += ["", "## Configurations (prefetch, memory `lat1`)", "", "| workload | " + " | ".join(d["hw"]) + " |",
          "|---|" + "---|" * len(d["hw"])]
    for k in d["workloads"]:
        row = [f"`{k}`"]
        for h in d["hw"]:
            r = idx.get((k, h, "lat1", 1))
            row.append(str(r["stats"]["cycles"]) if r and r["stats"] else "-")
        L.append("| " + " | ".join(row) + " |")
    L += ["", "Hardware: " + "; ".join(f"`{h}` = " + ", ".join(f"{a}={b}" for a, b in p.items()) for h, p in d["hw"].items()),
          "", "Memory: " + "; ".join(f"`{m}` = " + (", ".join(f"{a}={b}" for a, b in p.items()) or "latency 1") for m, p in d["mems"].items()),
          "", f"Failing runs: {d['total'] - d['passed']}."]
    (REPORTS / "gemm.md").write_text("\n".join(L) + "\n")


def xbar():
    d = load("xbar")
    if not d:
        return
    L = ["# DataFabric crossbar contention (tb_tdma_xbar)", "",
         f"**{d['passed']} / {d['total']} runs pass.** Real `sfb_crossbar` (4 masters x 3 slaves), real `sfb_sram_slave` x 2, "
         "Module 04 `hpc_scratchpad` as TSPM with two vector lanes on its other ports, DataFabric `dma_burst_engine` as a "
         "second DMA master, self-checking CPU and vector-stream masters. Memory is initialised and finally read back "
         "through the fabric. Tools: " + tools(d), "",
         "| mode | arbitration | SRAM latency | MAX_OUT | runs | pass | tensor DMA worst wait (cycles) | mean arbitration losses | "
         "mean CPU ops | mean vector ops | mean lane ops | mean scratchpad conflict cycles | mean cycles |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for h, p in d["hw"].items():
        rs = [r for r in d["runs"] if r["hw"] == h and r["stats"]]
        if not rs:
            continue
        n = len(rs)
        mean = lambda k: sum(r["stats"][k] for r in rs) // n  # noqa: E731
        L.append(f"| `{h}` | {'round robin' if p['ARB'] else 'fixed (tensor DMA lowest)'} | {p['SRL']} | {p['MAXOUT']} | "
                 f"{n} | {sum(r['ok'] for r in d['runs'] if r['hw'] == h)} | {max(r['stats']['tdma_stall_max'] for r in rs)} | "
                 f"{mean('tdma_arb_loss')} | {mean('cpu_ops')} | {mean('vec_ops')} | {mean('lane0') + mean('lane1')} | "
                 f"{mean('spm_conflict')} | {mean('cycles')} |")
    L += ["", "`*_hot` modes: every generator requests on every cycle it can (100 %)."]
    (REPORTS / "xbar.md").write_text("\n".join(L) + "\n")


def mutation():
    d = load("mutation")
    if not d:
        return
    L = ["# Mutation testing", "", f"**{d['killed']} / {d['total']} mutants killed**; every survivor is analysed below.", "",
         "Each mutant is one textual change to the new RTL, built in an isolated copy and run against the directed output-buffer "
         f"test (`tb_tout`, both port modes) and the regression subset {', '.join('`' + s + '`' for s in d['subset'])} "
         f"on configurations {', '.join(d['configs'])} (`small`: a reduced subset), with every regression check active.", "",
         "| id | file | injected bug | result | first detection |", "|---|---|---|---|---|"]
    for m in d["mutants"]:
        L.append(f"| {m['id']} | `{m['file']}` | {m['what']} | {'killed' if m['killed'] else '**survived**'} | "
                 f"{(m['by'][0] if m['by'] else '').replace('|', '/').replace('result None', 'run aborted by an RTL assertion')} |")
    surv = [m for m in d["mutants"] if not m["killed"]]
    if surv:
        L += ["", "## Survivors", ""]
        for m in surv:
            L.append(f"* **{m['id']}** ({m['what']}): {SURVIVOR_NOTES.get(m['id'], 'not analysed')}")
    (REPORTS / "mutation.md").write_text("\n".join(L) + "\n")


def lint():
    d = load("lint")
    if not d:
        return
    L = ["# Lint and elaboration", "", f"**{d['passed']} / {d['total']} checks pass.** Tools: {tools(d)}", "",
         "| check | top | parameters | result |", "|---|---|---|---|"]
    for c in d["checks"]:
        ps = ", ".join(f"{k}={v}" for k, v in c["params"].items()) or "defaults"
        if c["kind"] == "lint":
            res = (f"Verilator -Wall: {c['new_rtl_warnings']} warnings in new RTL ({c['third_party_warnings']} in unmodified "
                   f"third-party files); Icarus elaboration {'OK' if c['icarus_ok'] else 'FAILED'}")
        else:
            res = (f"rejected by the module's own check: Verilator {'yes' if c['verilator_rejects'] else 'NO'}, "
                   f"Icarus {'yes' if c['icarus_rejects'] else 'NO'}")
        L.append(f"| {c['name']} | `{c['top']}` | {ps} | {'PASS' if c['ok'] else 'FAIL'}: {res} |")
    (REPORTS / "lint.md").write_text("\n".join(L) + "\n")


def synth():
    d = load("synth")
    if not d:
        return
    L = ["# Synthesis (Yosys 0.33) - resource estimates and structural checks only", "",
         "No place and route, no timing analysis: **no clock frequency is claimed.** Every run asserts no latch "
         "and `check -assert` (no combinational loop, no undriven net) on the flattened design. Tools: " + tools(d), "",
         "| run | top | flow | parameters | result | cells | flip-flops | LUTs | CARRY4 | DSP48 | BRAM | LUTRAM |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for n, r in d["runs"].items():
        ps = ", ".join(f"{k}={v}" for k, v in r["params"].items()) or "defaults"
        L.append(f"| {n} | `{r['top']}` | {r['flow']} | {ps} | {'OK' if r['ok'] else 'FAILED'} | {r['total']} | {r['ff']} | "
                 f"{r['lut'] or '-'} | {r['carry'] or '-'} | {r['dsp'] or '-'} | {r['bram'] or '-'} | {r['lutram'] or '-'} |")
    (REPORTS / "synth.md").write_text("\n".join(L) + "\n")


def perf_tables():
    d = load("perf")
    if not d:
        return ""
    rows = d["runs"]
    progs = ["load1d_aligned", "load1d_misaligned", "load2d_32x31", "load2d_256x4", "store1d_aligned", "store1d_misaligned"]
    mems = ["lat1", "lat4", "lat8", "lat16", "xbar_lat1", "xbar_lat4"]
    out = [f"Sweep: **{d['passed']} / {d['total']} runs pass** (every run self-checking). Bytes per cycle of the "
           "transfer (channel busy cycles minus buffer-wait cycles):", ""]
    for wb in (4, 8):
        out += [f"### {8 * wb}-bit port (WB = {wb}), peak {wb} B/cycle", "",
                "| transfer | memory | MAX_OUT 1 | 2 | 4 | 8 | 16 |", "|---|---|---|---|---|---|---|"]
        for p in progs:
            for m in mems:
                v = [next((r for r in rows if r["wb"] == wb and r["program"] == p and r["mem"] == m and r["max_out"] == mo), None)
                     for mo in (1, 2, 4, 8, 16)]
                out.append(f"| `{p}` | {m} | " + " | ".join(f"{x['bpc']:.2f}" if x and x["bpc"] else "-" for x in v) + " |")
        out.append("")
    return "\n".join(out)


def main():
    regression()
    gemm()
    xbar()
    mutation()
    lint()
    synth()
    pt = perf_tables()
    if pt:
        (REPORTS / "perf.md").write_text("# Single-transfer throughput sweep (scripts/run_perf.py)\n\n" + pt + "\n")
    print("reports written")


if __name__ == "__main__":
    main()
