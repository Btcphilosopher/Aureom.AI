#!/usr/bin/env python3
"""Staged regression of the tensor DMA adapter (tb/tb_tdma.sv).

Stage 1: one sequential 1-D transfer at a time (baseline first)
Stage 2: 2-D strided transfers, partial rows, misalignment, back-pressure, R6, errors, validation
Stage 3: double-buffered overlap, prefetch vs sequential, memory dependencies, fences, reset, contention
A failing stage stops the run.  Every run is self-checking (RESULT PASS); in addition, for error-free runs
the counters and bus statistics must equal the reference model exactly, and mode properties are checked
(no prefetch overlap in SEQUENTIAL mode, overlap / dependency waits / buffer contention where a test
expects them).  Icarus cross-simulation: identical STATS and counters to Verilator for the same seed.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, CONFIGS, REPORTS, ROOT, build, hwcfg, parse, simulate, tool_versions, write_json  # noqa: E402

sys.path.insert(0, str(ROOT / "model"))
from gen_tests import generate  # noqa: E402

PERF_EXACT = ["RD_BYTES", "WR_BYTES", "RD_REQ", "WR_REQ", "DESC_OK", "XFER_ERR"]


def check_run(meta: dict, cfg: dict, r: dict) -> list[str]:
    errs = []
    if r["result"] != "PASS":
        errs.append("result " + str(r["result"]))
    errs += r["errors"][:5]
    p, st = r["perf"], r["stats"]
    if not p or not st:
        return errs + ["no counters"]
    pf = int(meta["plus"].get("prefetch", 0))
    if meta["check_perf"]:
        for k in PERF_EXACT:
            if p.get(k) != meta["perf"][k]:
                errs.append(f"counter {k} = {p.get(k)}, reference {meta['perf'][k]}")
        for k, v in meta["stats"].items():
            if st.get(k) != v:
                errs.append(f"bus stat {k} = {st.get(k)}, reference {v}")
        if p["ACTIVE"] == 0 or p["ACTIVE"] > st["cycles"]:
            errs.append(f"ACTIVE {p['ACTIVE']} not in (0, cycles]")
        if p["OUT_MAX"] > cfg["MAXOUT"] + 2 * cfg["LOCOUT"]:
            errs.append(f"OUT_MAX {p['OUT_MAX']} above the configured limits")
    if pf == 0 and p["OVERLAP"] != 0:
        errs.append(f"SEQUENTIAL mode but OVERLAP = {p['OVERLAP']}")
    if meta.get("expect_dep_wait") and p["DEP_WAIT"] == 0:
        errs.append("expected a dependency wait (DEP_WAIT = 0)")
    if meta.get("expect_ob_conflict") and cfg["OS"] == 2 and cfg["OPM"] == 0 and st.get("ob_conflicts", 0) == 0:
        errs.append("expected output-buffer bank conflicts")
    if "dbuf" in meta.get("name", "") and pf == 1 and cfg["NS"] == 2 and p["OVERLAP"] == 0:
        errs.append("prefetch with two sets but OVERLAP = 0")
    return errs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", default="1,2,3")
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--sims", default="verilator,icarus")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--xsim-configs", default="seq1,base")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--out", default="regression")
    a = ap.parse_args()
    stages = [int(s) for s in a.stages.split(",")]
    cfgs = a.configs.split(",")
    sims = a.sims.split(",")
    t0 = time.time()

    # generate programs and build testbenches
    tests, exes = {}, {}
    for c in cfgs:
        tests[c] = generate(hwcfg(CONFIGS[c]), BUILD / "tests" / c, seed=1, stages=stages)
        for name, m in tests[c].items():
            m["name"] = name
    for sim in sims:
        def bld(c):
            exe, log = build(sim, "tb_tdma", "tb/tb_tdma.sv", CONFIGS[c])
            if exe is None:
                print(log[-3000:])
                raise SystemExit(f"build failed: {sim} {c}")
            return c, exe
        targets = cfgs if sim == "verilator" else [c for c in cfgs if c in a.xsim_configs.split(",")]
        with ThreadPoolExecutor(a.jobs) as ex:
            for c, exe in ex.map(bld, targets):
                exes[(sim, c)] = exe

    rows, total, passed = [], 0, 0
    stage_ok = True
    for st in stages:
        if not stage_ok:
            break
        jobs = []
        for c in cfgs:
            for name, m in tests[c].items():
                if m["stage"] != st:
                    continue
                for seed in range(1, a.seeds + 1):
                    jobs.append(("verilator", c, name, seed))
                if ("icarus", c) in exes:
                    jobs.append(("icarus", c, name, 1))

        def one(j):
            sim, c, name, seed = j
            m = tests[c][name]
            plus = dict(m["plus"], dir=str(BUILD / "tests" / c / name), seed=seed)
            t = time.time()
            rc, log = simulate(sim, exes[(sim, c)], plus)
            r = parse(log)
            errs = check_run(m, CONFIGS[c], r)
            if rc not in (0,) and not errs:
                errs.append(f"exit code {rc}")
            return dict(stage=st, sim=sim, config=c, test=name, seed=seed, ok=not errs, errors=errs,
                        cycles=r["stats"].get("cycles"), stats=r["stats"], perf=r["perf"], secs=round(time.time() - t, 2))

        with ThreadPoolExecutor(a.jobs) as ex:
            res = list(ex.map(one, jobs))
        if st == 2:      # directed ownership test of the output buffer (both port modes, both simulators)
            for sim in sims:
                for opm in (0, 1):
                    exe, log = build(sim, "tb_tout", "tb/tb_tout.sv", dict(OPM=opm))
                    rc, out = simulate(sim, exe, {}) if exe else (1, log)
                    r = parse(out)
                    errs = ([] if r["result"] == "PASS" else ["result " + str(r["result"])]) + r["errors"][:3]
                    res.append(dict(stage=st, sim=sim, config=f"tout_opm{opm}", test="tout_ownership", seed=1,
                                    ok=not errs, errors=errs, cycles=None, stats={}, perf={}, secs=0, directed=True))
        # cross-simulation: identical statistics and counters for the same seed
        for r in res:
            if r["sim"] != "icarus" or r.get("directed"):
                continue
            v = next((x for x in res if x["sim"] == "verilator" and x["config"] == r["config"] and
                      x["test"] == r["test"] and x["seed"] == r["seed"]), None)
            r["xsim_identical"] = bool(v and v["stats"] == r["stats"] and v["perf"] == r["perf"])
            if not r["xsim_identical"]:
                r["ok"] = False
                r["errors"].append("Icarus and Verilator differ")
        n_ok = sum(r["ok"] for r in res)
        print(f"stage {st}: {n_ok}/{len(res)} runs pass")
        for r in res:
            if not r["ok"]:
                print(f"  FAIL {r['sim']} {r['config']} {r['test']} seed={r['seed']}: {r['errors'][:3]}")
        rows += res
        total += len(res)
        passed += n_ok
        stage_ok = (n_ok == len(res))

    xs = [r for r in rows if r["sim"] == "icarus" and not r.get("directed")]
    summary = dict(total=total, passed=passed, stages=stages, configs={c: CONFIGS[c] for c in cfgs},
                   xsim=dict(runs=len(xs), identical=sum(r.get("xsim_identical", False) for r in xs)),
                   tools=tool_versions(), seconds=round(time.time() - t0, 1), runs=rows)
    write_json(REPORTS / f"{a.out}.json", summary)
    print(f"total: {passed}/{total} runs pass; cross-sim identical {summary['xsim']['identical']}/{summary['xsim']['runs']}"
          f" ({summary['seconds']} s)")
    sys.exit(0 if passed == total and stage_ok else 1)


if __name__ == "__main__":
    main()
