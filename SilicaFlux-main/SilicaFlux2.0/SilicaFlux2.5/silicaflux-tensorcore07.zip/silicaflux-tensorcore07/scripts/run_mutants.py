#!/usr/bin/env python3
"""Mutation testing: deliberate bugs in the NEW RTL must be detected by the regression.

Each mutant is one textual replacement (asserted to apply exactly once) in a copy of the source tree.
A mutant is KILLED when at least one run of the selected subset fails (self-check, reference counters,
mode properties, assertion, timeout).  Survivors are listed with an analysis in reports/mutation.md.
"""
from __future__ import annotations

import argparse
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, CONFIGS, REPORTS, ROOT, build, parse, simulate, write_json  # noqa: E402
from run_regress import check_run  # noqa: E402

sys.path.insert(0, str(ROOT / "model"))
from gen_tests import generate  # noqa: E402
from common import hwcfg  # noqa: E402

M = [
    ("M01", "rtl/tdma_sfb_port.sv", "assign r_rsp_valid = rsp_go && !of_head[32];", "assign r_rsp_valid = rsp_go && of_head[32];",
     "SFB2 responses routed to the wrong channel"),
    ("M02", "rtl/tdma_channel.sv", "assign finish = act && (rm_cnt == '0) && (wm_cnt == '0) &&", "assign finish = act && (rm_cnt == '0) &&",
     "completion without waiting for the write acknowledgements (premature completion)"),
    ("M03", "rtl/tdma_channel.sv", "if (wa_take && !wa_err && !wr_err_seen) bytes_ok <= bytes_ok + 32'(wm_head);",
     "if (wa_take) bytes_ok <= bytes_ok + 32'(wm_head);", "byte count includes failed / post-error writes"),
    ("M04", "rtl/tdma_agu.sv", "assign hi     = (j == nw_m1)  ? span[LWB-1:0] : LWB'(WB - 1);", "assign hi     = LWB'(WB - 1);",
     "row tail not masked (writes past the end of a row)"),
    ("M05", "rtl/tdma_agu.sv", "assign lo     = (j == 17'd0)  ? s[LWB-1:0]    : '0;", "assign lo     = '0;",
     "row start misalignment ignored"),
    ("M06", "rtl/tdma_realign.sv", "pop_data[8*l +: 8] = head[LWB'(l) - pop_lo];", "pop_data[8*l +: 8] = head[LWB'(l)];",
     "realigner does not shift bytes to the destination lanes"),
    ("M07", "rtl/tdma_buf_coord.sv", "assign policy_ok        = prefetch || !op_compute_owns;", "assign policy_ok        = 1'b1;",
     "SEQUENTIAL mode fills while compute owns a set"),
    ("M08", "rtl/tensor_dma_adapter.sv", "else                                 blocked[c] = (hd[c][E_CODE +: 4] == `TDMA_C_OK) && older_ovl[c];",
     "else                                 blocked[c] = 1'b0;", "memory dependencies ignored in PREFETCH mode"),
    ("M09", "rtl/tensor_dma_adapter.sv", "if (a_ok[1-c] && ovl(a_lo[1-c], a_hi[1-c], hd[c][E_LO +: 32], hd[c][E_HI +: 32])) older_ovl[c] = 1'b1;",
     "", "dependency check ignores the other channel's ACTIVE descriptor"),
    ("M10", "rtl/tensor_dma_adapter.sv", "if (!cfg_prefetch || hd[c][E_FENCE]) blocked[c] = older_any[c];",
     "if (hd[c][E_FENCE]) blocked[c] = older_any[c];", "SEQUENTIAL mode does not serialise the channels"),
    ("M11", "rtl/tensor_dma_adapter.sv", "if (!cfg_prefetch || hd[c][E_FENCE]) blocked[c] = older_any[c];",
     "if (!cfg_prefetch) blocked[c] = older_any[c];", "FENCE flag ignored"),
    ("M12", "rtl/tdma_validate.sv", "else if (rows > 16'd1 && dstr < 32'(len))", "else if (1'b0)",
     "overlapping destination rows accepted"),
    ("M13", "rtl/tdma_validate.sv", "33'(ext_last[31:0]) >= MEM_HI)", "33'(ext_last[31:0]) > MEM_HI)",
     "external range check off by one"),
    ("M14", "rtl/tdma_validate.sv", "else if (loc_last >= set_bytes)", "else if (loc_last > set_bytes)",
     "local range check off by one (crosses into the next set)"),
    ("M15", "rtl/tdma_loc_port.sv", "assign mism         = (rsp_tag != h_tag) || (rsp_we != h_we);", "assign mism         = 1'b0;",
     "local response tag / direction not checked"),
    ("M16", "rtl/tdma_sfb_port.sv", "assign can_load = !rq_v || acc;", "assign can_load = 1'b1;",
     "SFB2 request replaced before acceptance (R2)"),
    ("M17", "rtl/tdma_channel.sv", "(rm_cnt < (RW+1)'(MAXR)) && (used_next <= (CW+2)'(RCAP));", "(rm_cnt < (RW+1)'(MAXR));",
     "realigner credit not checked (overflow)"),
    ("M18", "rtl/tdma_buf_coord.sv", "assign st_acq_ok        = st_acq && (ost == `TDMA_BS_IN_USE);",
     "assign st_acq_ok        = st_acq && (ost == `TDMA_BS_IN_USE || ost == `TDMA_BS_FILLING);",
     "store drains an output set compute is still writing"),
    ("M19", "rtl/tensor_dma_adapter.sv", "st[c]     <= a_seal[c] ? `TDMA_CH_SEAL : `TDMA_CH_CPL;", "st[c]     <= `TDMA_CH_CPL;",
     "SEAL never hands the set over"),
    ("M20", "rtl/tensor_dma_adapter.sv", "            if (ch_err[c]) begin", "            if (1'b0) begin",
     "transfer errors reported as OK"),
    ("M21", "rtl/tdma_queue.sv", "ent_valid[i]  = (AW'(AW'(i) - rp[AW-1:0]) < count[AW-1:0]) || (count == (AW+1)'(DEPTH));",
     "ent_valid[i]  = 1'b0;", "dependency check does not see QUEUED descriptors"),
    ("M22", "rtl/tensor_dma_adapter.sv", "    older = d[7];", "    older = !d[7];",
     "age comparison reversed"),
    ("M23", "rtl/tdma_loc_port.sv", "assign u_gnt    = can_load && u_valid && (cnt < (OW+1)'(MAX_OUT));",
     "assign u_gnt    = can_load && u_valid && (cnt <= (OW+1)'(MAX_OUT));", "local outstanding limit off by one"),
    ("M24", "rtl/tensor_output_buffer.sv", "assign lane_addr = sbase + 32'(in_row) * 32'(O_LD) + (32'(lane) << 2);",
     "assign lane_addr = sbase + (32'(lane) << 2);", "output writer ignores the row"),
    ("M25", "rtl/tensor_dma_adapter.sv", "? OP_BASE + REGION + 32'(op_fill_set) * 32'(B_SET_BYTES) + a_dst[0]",
     "? OP_BASE + 32'(op_fill_set) * 32'(B_SET_BYTES) + a_dst[0]", "LOAD_B lands in the A region"),
    ("M26", "rtl/tensor_dma_adapter.sv", "assign st_loc_src = OB_BASE + 32'(ob_rd_set) * 32'(O_SET_BYTES) + a_src[1];",
     "assign st_loc_src = OB_BASE + a_src[1];", "STORE always drains output set 0"),
    ("M27", "rtl/tdma_channel.sv", "assign rl_push = rr_take && !rr_err && !errq;", "assign rl_push = rr_take && !errq;",
     "data of a failed read is used"),
    ("M28", "rtl/tdma_buf_coord.sv", "assign fill_begin_valid = ld_acq && (fst == `TDMA_BS_FREE) && policy_ok;",
     "assign fill_begin_valid = ld_acq && policy_ok;", "fill_begin requested on a set that is not FREE"),
    ("M29", "rtl/tdma_agu.sv", "s <= s + str;", "s <= s + str + 32'd1;", "row stride off by one"),
    ("M30", "rtl/tout_gate.sv", "else if (st_x != NEED)                     code = 3'd6;   // OWNER",
     "else if (1'b0)                             code = 3'd6;   // OWNER", "output-buffer OWNER check removed"),
]
SUBSET = ["s1_single", "s1_lengths_load", "s1_lengths_store", "s2_partial", "s2_src_overlap", "s2_invalid",
          "s2_err_rd", "s2_err_wr", "s2_err_loc_wr", "s2_err_loc_rd", "s2_err_proto", "s2_random_bp", "s2_writecpl",
          "s3_dbuf_pf0", "s3_dbuf_pf1", "s3_hazard_raw_pf1", "s3_hazard_war_pf1", "s3_fence_pf1", "s3_mix_pf0",
          "s3_mix_pf1", "s3_reset_pf1", "s3_contention_pf1"]
CFGS = ["base", "stress", "small"]
SMALL_SUBSET = ["s1_lengths_load", "s2_random_bp", "s3_mix_pf1"]       # LOC_OUT = 2 < target credits


def make_tree(mid: str, f: str, old: str, new: str) -> Path:
    d = BUILD / "mut" / mid
    if d.exists():
        shutil.rmtree(d)
    for sub in ("rtl", "tb", "third_party"):
        shutil.copytree(ROOT / sub, d / sub)
    p = d / f
    s = p.read_text()
    assert s.count(old) == 1, f"{mid}: pattern found {s.count(old)} times in {f}"
    p.write_text(s.replace(old, new))
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    t0 = time.time()
    tests = {c: generate(hwcfg(CONFIGS[c]), BUILD / "tests" / c, seed=1) for c in CFGS}
    for c in CFGS:
        for n, m in tests[c].items():
            m["name"] = n
    mutants = [m for m in M if not a.only or m[0] in a.only.split(",")]

    def run_mutant(mu):
        mid, f, old, new, what = mu
        root = make_tree(mid, f, old, new)
        killed_by, built = [], True
        # directed output-buffer ownership test first (cheap)
        for opm in (0, 1):
            exe, log = build("verilator", "tb_tout", "tb/tb_tout.sv", dict(OPM=opm), root=root)
            if exe is None:
                killed_by.append("tb_tout: does not build")
                break
            rc, out = simulate("verilator", exe, {}, timeout=300)
            r = parse(out)
            if r["result"] != "PASS":
                killed_by.append(f"tb_tout OPM={opm}: {(r['errors'] or ['result ' + str(r['result'])])[0][:110]}")
                break
        for c in CFGS:
            if killed_by:
                break
            exe, log = build("verilator", "tb_tdma", "tb/tb_tdma.sv", CONFIGS[c], root=root)
            if exe is None:
                built = False
                killed_by.append(f"{c}: does not build")
                break
            for name in (SUBSET if c != "small" else SMALL_SUBSET):
                m = tests[c][name]
                plus = dict(m["plus"], dir=str(BUILD / "tests" / c / name), seed=1, maxcyc=300000)
                rc, out = simulate("verilator", exe, plus, timeout=600)
                errs = check_run(m, CONFIGS[c], parse(out))
                if errs:
                    killed_by.append(f"{c}/{name}: {errs[0][:110]}")
                    break
            if killed_by:
                break
        shutil.rmtree(root, ignore_errors=True)
        return dict(id=mid, file=f, what=what, killed=bool(killed_by), built=built, by=killed_by[:1])

    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run_mutant, mutants))
    k = sum(r["killed"] for r in res)
    for r in res:
        print(f"{r['id']} {'KILLED ' if r['killed'] else 'SURVIVED'} {r['what']}  <- {r['by'][0] if r['by'] else ''}")
    print(f"mutants: {k}/{len(res)} killed ({time.time() - t0:.0f} s)")
    write_json(REPORTS / "mutation.json", dict(total=len(res), killed=k, subset=SUBSET, configs=CFGS, mutants=res))


if __name__ == "__main__":
    main()
