#!/usr/bin/env python3
"""TENSORCORE 07 synthesis (Yosys 0.33): RESOURCE ESTIMATES AND STRUCTURAL CHECKS ONLY.

  adp_generic / adp_xc7   tensor_dma_adapter (default parameters)
  adp_min_generic         tensor_dma_adapter, minimum configuration (1 set, 1 outstanding, 8-byte realigner)
  obuf_generic / obuf_xc7 tensor_output_buffer (Module 04 scratchpad + ownership + writer)
  sys_generic             tdma_tile_system (adapter + TC02 + TC03 + TC04 + output buffer + sequencer),
                          flattened: check -assert proves the integration has no combinational loop
Every run: no latch (select -assert-none), check -assert.  No place & route, no timing, no Fmax.
"""
from __future__ import annotations

import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, run, tool_versions, write_json  # noqa: E402

ADP = ["third_party/silicaflux-datafabric/rtl/dma/dma_fifo.sv"] + [f"rtl/{f}.sv" for f in (
    "tdma_agu", "tdma_realign", "tdma_channel", "tdma_sfb_port", "tdma_loc_port", "tdma_validate", "tdma_queue",
    "tdma_buf_coord", "tdma_perf", "tensor_dma_adapter")]


def flist():
    inc, files = [], []
    for line in (ROOT / "rtl/files.f").read_text().splitlines():
        line = line.strip()
        if line.startswith("+incdir+"):
            inc.append(line[len("+incdir+"):])
        elif line and "stubs" not in line:
            files.append(line)
    return inc, files


def ys(top, files, inc, flow, params):
    rd = "read_verilog -defer -sv -DSYNTHESIS " + " ".join(f"-I{i}" for i in inc) + " " + " ".join(files)
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in params.items())
    if flow == "generic":
        body = (f"{ch}hierarchy -check -top {top}; proc; flatten; opt_clean; check -assert; "
                f"synth -top {top} -flatten; select -assert-none t:$dlatch t:$_DLATCH_* t:$_DLATCH*_; "
                f"check -assert; stat")
    else:
        body = (f"{ch}hierarchy -check -top {top}; synth_xilinx -family xc7 -top {top} -flatten; "
                f"select -assert-none t:LDCE t:LDPE; check -assert; stat")
    return f"{rd}; {body}"


def parse_stat(log):
    i = log.rfind("Printing statistics")
    s = log[i:]
    cells = {m[1]: int(m[2]) for m in re.finditer(r"^\s+(\$?\w+)\s+(\d+)$", s, re.M)}
    tot = re.search(r"Number of cells:\s+(\d+)", s)
    return (int(tot[1]) if tot else None), cells


def main():
    inc, files = flist()
    minp = dict(NUM_SETS=1, O_SETS=1, MAX_OUT=1, LOC_OUT=1, RCAP=8, QDEPTH=2, CPL_DEPTH=2)
    obuf = ["third_party/silicaflux-datafabric/rtl/dma/dma_fifo.sv"] + [f for f in files if "sram" in f or "hpc_" in f] + \
           ["third_party/silicaflux-tensorcore03/rtl/tob_dbuf_ctrl.sv", "rtl/tdma_loc_port.sv", "rtl/tout_gate.sv",
            "rtl/tensor_output_buffer.sv"]
    jobs = {"adp_generic": ("tensor_dma_adapter", ADP, "generic", {}),
            "adp_xc7": ("tensor_dma_adapter", ADP, "xc7", {}),
            "adp_min_generic": ("tensor_dma_adapter", ADP, "generic", minp),
            "obuf_generic": ("tensor_output_buffer", obuf, "generic", {}),
            "obuf_xc7": ("tensor_output_buffer", obuf, "xc7", {}),
            "sys_generic": ("tdma_tile_system", files, "generic", {})}
    d = BUILD / "synth"
    d.mkdir(parents=True, exist_ok=True)

    def one(item):
        name, (top, fl, flow, p) = item
        script = d / f"{name}.ys"
        script.write_text(ys(top, fl, ["rtl"] + inc, flow, p) + "\n")
        rc, log = run(["yosys", "-q", "-l", str(d / f"{name}.log"), "-s", str(script)], timeout=7200)
        full = (d / f"{name}.log").read_text() if (d / f"{name}.log").exists() else log
        tot, cells = parse_stat(full)
        return name, dict(ok=rc == 0, top=top, flow=flow, params=p, total=tot, cells=cells, err=(log[-800:] if rc else ""))

    with ThreadPoolExecutor(3) as ex:
        res = dict(ex.map(one, jobs.items()))
    for n, r in res.items():
        c = r["cells"]
        ff = sum(v for k, v in c.items() if re.fullmatch(r"\$_(S?DFF|DFFE|SDFFE|SDFFCE|ALDFF|DFFSR|DFFSRE)\w*_", k) or k in ("FDRE", "FDSE", "FDCE", "FDPE"))
        lut = sum(v for k, v in c.items() if re.fullmatch(r"LUT\d", k))
        r.update(ff=ff, lut=lut, carry=c.get("CARRY4", 0), dsp=c.get("DSP48E1", 0), bram=c.get("RAMB36E1", 0) + c.get("RAMB18E1", 0),
                 lutram=sum(v for k, v in c.items() if k.startswith("RAM") and "RAMB" not in k))
        print(f"{n:16s} {'ok' if r['ok'] else 'FAILED'} cells={r['total']} ff={ff} lut={lut} dsp={r['dsp']}"
              + ("" if r["ok"] else "\n" + r["err"]))
    write_json(REPORTS / "synth.json", dict(tools=tool_versions(), runs=res))
    sys.exit(0 if all(r["ok"] for r in res.values()) else 1)


if __name__ == "__main__":
    main()
