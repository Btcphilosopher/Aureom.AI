#!/usr/bin/env bash
# Package the deliverable as a zip (build/ excluded). Writes SHA256SUMS of every delivered file first.
set -euo pipefail
cd "$(dirname "$0")/.."
NAME=silicaflux-tensorcore07
find . -type f ! -path './build/*' ! -name SHA256SUMS ! -path './third_party/SHA256SUMS' -print0 | sort -z \
  | xargs -0 sha256sum | sed 's|  \./|  |' > SHA256SUMS
cd ..
rm -f "$NAME.zip"
zip -q -r -X "$NAME.zip" "$NAME" -x "$NAME/build/*" -x "*/__pycache__/*"
echo "$(pwd)/$NAME.zip"
