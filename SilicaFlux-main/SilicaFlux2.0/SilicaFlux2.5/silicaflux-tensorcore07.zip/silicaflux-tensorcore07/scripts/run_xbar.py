#!/usr/bin/env python3
"""DataFabric crossbar contention integration (tb/tb_tdma_xbar.sv).

Arbitration (round robin / fixed priority with the tensor DMA lowest) x SRAM latency x traffic intensity x
programs x seeds.  Every run must PASS; the tensor DMA's worst request wait is recorded per mode.
"""
from __future__ import annotations

import argparse
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, build, parse, simulate, tool_versions, write_json  # noqa: E402

sys.path.insert(0, str(ROOT / "model"))
from gen_xbar import xbar_program  # noqa: E402

HW = {"rr_l1": dict(ARB=1, SRL=1, MAXOUT=4), "rr_l2": dict(ARB=1, SRL=2, MAXOUT=4),
      "rr_l1_mo1": dict(ARB=1, SRL=1, MAXOUT=1), "fixed_l1": dict(ARB=0, SRL=1, MAXOUT=4),
      "rr_hot": dict(ARB=1, SRL=1, MAXOUT=4, CPU_PCT=100, VEC_PCT=100, LANE_PCT=100),
      "fixed_hot": dict(ARB=0, SRL=1, MAXOUT=4, CPU_PCT=100, VEC_PCT=100, LANE_PCT=100)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--programs", type=int, default=3)
    ap.add_argument("--seeds", type=int, default=2)
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    t0 = time.time()
    progs = [f"x{i}" for i in range(1, a.programs + 1)]
    for i, pname in enumerate(progs, 1):
        xbar_program(BUILD / "xbar" / pname, seed=100 + i)
    exes = {}
    for h, p in HW.items():
        exe, log = build("verilator", "tb_tdma_xbar", "tb/tb_tdma_xbar.sv", p)
        if exe is None:
            print(log[-3000:])
            raise SystemExit("build failed " + h)
        exes[h] = exe
    jobs = [(h, pn, s) for h in HW for pn in progs for s in range(1, a.seeds + 1)]

    def one(j):
        h, pn, s = j
        rc, log = simulate("verilator", exes[h], dict(dir=str(BUILD / "xbar" / pn), seed=s), timeout=3600)
        r = parse(log)
        errs = ([] if r["result"] == "PASS" else ["result " + str(r["result"])]) + r["errors"][:4]
        return dict(hw=h, program=pn, seed=s, ok=not errs, errors=errs, stats=r["stats"], perf=r["perf"])

    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(one, jobs))
    ok = sum(r["ok"] for r in res)
    for r in res:
        if not r["ok"]:
            print(f"  FAIL {r['hw']} {r['program']} seed={r['seed']}: {r['errors'][:3]}")
    print(f"xbar: {ok}/{len(res)} runs pass ({time.time() - t0:.0f} s)")
    for h in HW:
        rs = [r for r in res if r["hw"] == h and r["stats"]]
        if rs:
            print(f"  {h:10s} tdma_stall_max={max(r['stats']['tdma_stall_max'] for r in rs):4d}  "
                  f"arb_loss={sum(r['stats']['tdma_arb_loss'] for r in rs) // len(rs):5d}  "
                  f"cycles={sum(r['stats']['cycles'] for r in rs) // len(rs)}")
    write_json(REPORTS / "xbar.json", dict(total=len(res), passed=ok, hw=HW, tools=tool_versions(), runs=res))
    sys.exit(0 if ok == len(res) else 1)


if __name__ == "__main__":
    main()
