#!/usr/bin/env python3
"""Lint and elaboration checks.

  * Verilator -Wall --lint-only on every new top in several parameter sets: 0 warnings in the new RTL
    (third-party files are reported separately and are not modified);
  * Icarus 12 elaboration of the same tops;
  * illegal parameter sets must be REJECTED at elaboration by the new modules' own checks (both tools).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, run, tool_versions, write_json  # noqa: E402

NEW = [p.name for p in (ROOT / "rtl").glob("*.sv")] + [p.name for p in (ROOT / "rtl").glob("*.svh")]
GOOD = [
    ("adapter_base", "tensor_dma_adapter", {}),
    ("adapter_min", "tensor_dma_adapter", dict(NUM_SETS=1, O_SETS=1, MAX_OUT=1, LOC_OUT=1, RCAP=8, QDEPTH=2, CPL_DEPTH=2)),
    ("adapter_wide", "tensor_dma_adapter", dict(WB=8, RCAP=32)),
    ("adapter_deep", "tensor_dma_adapter", dict(MAX_OUT=16, LOC_OUT=8, RCAP=64, QDEPTH=16, CPL_DEPTH=8)),
    ("obuf_base", "tensor_output_buffer", {}),
    ("obuf_1set_wide", "tensor_output_buffer", dict(O_SETS=1, WB=8, PORT_MODE=1)),
    ("tile_system", "tdma_tile_system", {}),
]
BAD = [
    ("wb3", "tensor_dma_adapter", dict(WB=3)),
    ("sets3", "tensor_dma_adapter", dict(NUM_SETS=3)),
    ("osets0", "tensor_dma_adapter", dict(O_SETS=0)),
    ("qdepth3", "tensor_dma_adapter", dict(QDEPTH=3)),
    ("cpl1", "tensor_dma_adapter", dict(CPL_DEPTH=1)),
    ("rcap_small", "tensor_dma_adapter", dict(RCAP=4)),
    ("max_out3", "tensor_dma_adapter", dict(MAX_OUT=3)),
    ("loc_out32", "tensor_dma_adapter", dict(LOC_OUT=32)),
    ("mem_window", "tensor_dma_adapter", dict(MEM_LO="33'h1000", MEM_HI="33'h1000")),
    ("obuf_wb2", "tensor_output_buffer", dict(WB=2)),
    ("obuf_ld", "tensor_output_buffer", dict(O_LD=10)),
    ("obuf_tile_too_big", "tensor_output_buffer", dict(O_SET_BYTES=32)),
]


def flist():
    inc, files = [], []
    for line in (ROOT / "rtl/files.f").read_text().splitlines():
        line = line.strip()
        if line.startswith("+incdir+"):
            inc.append(line[len("+incdir+"):])
        elif line:
            files.append(line)
    return inc, files


def verilator(top, params):
    cmd = ["verilator", "--lint-only", "-Wall", "-Wno-fatal", "--top-module", top, "-f", "rtl/files.f"]
    cmd += [f"-G{k}={v}" for k, v in params.items()]
    return run(cmd)


def icarus(top, params):
    cmd = ["iverilog", "-g2012", "-o", str(BUILD / "lint.vvp"), "-s", top] + [f"-P{top}.{k}={v}" for k, v in params.items()]
    cmd += ["-f", "rtl/files.f"]
    rc, log = run(cmd)
    if rc == 0 and "$fatal" not in log:          # Icarus evaluates the elaboration $fatal at time 0
        rc2, log2 = run(["vvp", "-n", str(BUILD / "lint.vvp")], timeout=60)
        if "FATAL" in log2 or "fatal" in log2.lower():
            return 1, log + log2
    return rc, log


def main():
    BUILD.mkdir(exist_ok=True)
    rows = []
    for name, top, p in GOOD:
        rc, log = verilator(top, p)
        warn = [l for l in log.splitlines() if l.startswith("%Warning") and any(f"rtl/{n}" in l.split(":")[1] for n in NEW
                                                                               if ":" in l)]
        tp = [l for l in log.splitlines() if l.startswith("%Warning") and "third_party" in l]
        errs = [l for l in log.splitlines() if l.startswith("%Error")]
        ok_v = not errs and not warn
        rc_i, log_i = icarus(top, p)
        ok_i = rc_i == 0
        rows.append(dict(kind="lint", name=name, top=top, params=p, verilator_ok=ok_v, new_rtl_warnings=len(warn),
                         third_party_warnings=len(tp), icarus_ok=ok_i, ok=ok_v and ok_i, detail=(warn + errs)[:5]))
    for name, top, p in BAD:
        rc, log = verilator(top, p)
        fat = [l for l in log.splitlines() if "USERFATAL" in l or "%Error" in l]
        rej_v = bool(fat)
        msg_v = any(re.search(rf"{top}:", l) for l in fat)     # the message comes from the module's own check
        rc_i, log_i = icarus(top, p)
        rej_i = rc_i != 0
        rows.append(dict(kind="reject", name=name, top=top, params=p, verilator_rejects=rej_v and msg_v,
                         icarus_rejects=rej_i, ok=rej_v and msg_v and rej_i))
    ok = sum(r["ok"] for r in rows)
    for r in rows:
        if not r["ok"]:
            print("  FAIL", r)
    print(f"lint: {ok}/{len(rows)} checks pass")
    write_json(REPORTS / "lint.json", dict(total=len(rows), passed=ok, tools=tool_versions(), checks=rows))
    sys.exit(0 if ok == len(rows) else 1)


if __name__ == "__main__":
    main()
