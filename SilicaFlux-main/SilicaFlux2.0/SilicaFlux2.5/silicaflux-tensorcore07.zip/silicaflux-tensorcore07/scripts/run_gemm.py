#!/usr/bin/env python3
"""End-to-end GEMM integration regression (tb/tb_tdma_gemm.sv on rtl/tdma_tile_system.sv).

Every operand block and every C tile moves through tensor_dma_adapter; TC02/TC03/TC04 are unmodified.
Workloads x hardware configurations x {SEQUENTIAL, PREFETCH} x memory behaviours.  Every run must PASS
(exact C, untouched memory elsewhere, all descriptors OK).  Cycle counts feed reports/throughput.md.
"""
from __future__ import annotations

import argparse
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, build, parse, simulate, tool_versions, write_json  # noqa: E402

sys.path.insert(0, str(ROOT / "model"))
from gemm_gen import gemm  # noqa: E402
from tdma_ref import HwCfg  # noqa: E402

WORKLOADS = {
    "g1x1x1":      dict(M=1, N=1, K=1),
    "g4x4x4":      dict(M=4, N=4, K=4),
    "g5x7x3":      dict(M=5, N=7, K=3),
    "g17x13x29":   dict(M=17, N=13, K=29, lda=29, ldb=13, ldc=13 * 4 + 8),
    "g37x1x5":     dict(M=37, N=1, K=5, lda=7, ldb=3),
    "g1x37x5":     dict(M=1, N=37, K=5, ldb=41),
    "g8x8x200":    dict(M=8, N=8, K=200, lda=203),            # 4 K chunks (64, 64, 64, 8)
    "g32x32x64":   dict(M=32, N=32, K=64),
    "g64x16x64n":  dict(M=64, N=16, K=64, order="n"),
    "g32x32x256":  dict(M=32, N=32, K=256, b_off=0x100 + 32 * 256 + 0x40),   # aligned bases (TC06 comparison)
    "g32x32x256u": dict(M=32, N=32, K=256),                                   # B base misaligned by 3
}
HW = {
    "base":   dict(NS=2, MAXOUT=4, LOCOUT=4, RCAP=32, QD=4, TPM=1, OPM=0, ONB=2),
    "single": dict(NS=1, MAXOUT=4, LOCOUT=4, RCAP=32, QD=4, TPM=1, OPM=0, ONB=2),
    "min":    dict(NS=2, MAXOUT=1, LOCOUT=1, RCAP=8, QD=2, TPM=1, OPM=0, ONB=2),
    "stress": dict(NS=2, MAXOUT=16, LOCOUT=8, RCAP=64, QD=8, TPM=0, OPM=0, ONB=1),
}
MEMS = {
    "lat1": dict(),
    "lat8": dict(lat_min=8, lat_max=8),
    "xbar": dict(xbar=1, lat_min=4, lat_max=4),
    "bp":   dict(bp=30, lat_min=1, lat_max=6, cpl_bp=20),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--out", default="gemm")
    a = ap.parse_args()
    t0 = time.time()
    wl = WORKLOADS if not a.quick else {k: WORKLOADS[k] for k in ("g4x4x4", "g17x13x29", "g8x8x200")}
    hw = HW if not a.quick else {"base": HW["base"]}
    mems = MEMS if not a.quick else {"lat1": MEMS["lat1"]}
    metas = {}
    for name, w in wl.items():
        metas[name] = gemm(HwCfg(), BUILD / "gemm" / name, seed=7, **w)
    exes = {}
    for h, p in hw.items():
        exe, log = build("verilator", "tb_tdma_gemm", "tb/tb_tdma_gemm.sv", p)
        if exe is None:
            print(log[-3000:])
            raise SystemExit("build failed " + h)
        exes[h] = exe
    jobs = []
    for name in wl:
        big = metas[name]["macs"] > 100_000
        for h in hw:
            for m in mems:
                if big and (h in ("min", "stress") and m != "lat1"):
                    continue
                for pf in (0, 1):
                    jobs.append((name, h, m, pf))

    def one(j):
        name, h, m, pf = j
        plus = dict(MEMS[m], dir=str(BUILD / "gemm" / name), prefetch=pf, seed=3)
        t = time.time()
        rc, log = simulate("verilator", exes[h], plus, timeout=3600)
        r = parse(log)
        errs = ([] if r["result"] == "PASS" else ["result " + str(r["result"])]) + r["errors"][:4]
        return dict(workload=name, hw=h, mem=m, prefetch=pf, ok=not errs, errors=errs, stats=r["stats"], perf=r["perf"],
                    macs=metas[name]["macs"], tiles=metas[name]["tiles"], chunks=metas[name]["chunks"],
                    secs=round(time.time() - t, 2))

    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(one, jobs))
    ok = sum(r["ok"] for r in res)
    for r in res:
        if not r["ok"]:
            print(f"  FAIL {r['workload']} {r['hw']} {r['mem']} pf={r['prefetch']}: {r['errors'][:3]}")
    print(f"gemm: {ok}/{len(res)} runs pass ({time.time() - t0:.0f} s)")
    write_json(REPORTS / f"{a.out}.json", dict(total=len(res), passed=ok, hw=hw, mems=mems,
                                               workloads={k: dict(wl[k], **{x: metas[k][x] for x in ("tiles", "chunks", "macs", "n_desc")}) for k in wl},
                                               tools=tool_versions(), runs=res))
    sys.exit(0 if ok == len(res) else 1)


if __name__ == "__main__":
    main()
