"""Shared helpers for the TENSORCORE 07 scripts: configurations, builds (cached), runs, log parsing."""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"
sys.path.insert(0, str(ROOT / "model"))

from tdma_desc import PC_NAMES  # noqa: E402
from tdma_ref import HwCfg  # noqa: E402

DEFINES = ["TOB_ASSERT", "SRAMLIB_ASSERT"]
VFLAGS = ["-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-Wno-MULTIDRIVEN",
          "-Wno-SYNCASYNCNET", "-Wno-BLKANDNBLK", "-Wno-UNOPTFLAT", "-Wno-CASEINCOMPLETE", "-Wno-WIDTH",
          "--x-assign", "unique", "--x-initial", "unique"]

BASE = dict(WB=4, NS=2, ASB=1024, BSB=1024, OS=2, OSB=256, MAXOUT=4, LOCOUT=4, RCAP=32, QD=4, CPLD=4,
            TPM=1, TRL=1, OPM=0, ORL=1, ONB=2)
CONFIGS = {
    # baseline: one transaction in flight per port, single operand / output set, minimum buffering
    "seq1":   dict(BASE, NS=1, OS=1, MAXOUT=1, LOCOUT=1, RCAP=8, QD=2, CPLD=2),
    "base":   dict(BASE),
    # small sets, minimum realigner, 2 outstanding
    "small":  dict(BASE, ASB=256, BSB=256, OSB=128, MAXOUT=2, LOCOUT=2, RCAP=8, QD=2, CPLD=2),
    # 64-bit fabric / buffers
    "wide":   dict(BASE, WB=8, RCAP=32),
    # deep pipelining, 1RW banks everywhere, slower SRAMs, one output bank (maximum contention)
    "stress": dict(BASE, MAXOUT=16, LOCOUT=8, RCAP=64, QD=8, CPLD=2, TPM=0, TRL=2, OPM=0, ORL=2, ONB=1),
}

_lock = threading.Lock()


def hwcfg(cfg: dict) -> HwCfg:
    return HwCfg(WB=cfg["WB"], NS=cfg["NS"], ASB=cfg["ASB"], BSB=cfg["BSB"], OS=cfg["OS"], OSB=cfg["OSB"])


def run(cmd, cwd=ROOT, timeout=3600):
    try:
        p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        return p.returncode, p.stdout
    except subprocess.TimeoutExpired as e:
        return -9, (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "") + "\nTIMEOUT"


def source_hash(root: Path = ROOT, extra: list[Path] | None = None) -> str:
    h = hashlib.sha1()
    files = sorted(list((root / "rtl").glob("*")) + list((root / "tb").glob("*")) +
                   [p for p in (root / "third_party").rglob("*") if p.is_file()]) + (extra or [])
    for p in files:
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def build(sim: str, top: str, tb: str, cfg: dict, root: Path = ROOT, files: list[str] | None = None):
    """Build a testbench for one parameter set (cached by parameters and source content)."""
    key = hashlib.sha1((top + json.dumps(cfg, sort_keys=True) + source_hash(root)).encode()).hexdigest()[:12]
    out = root / "build" / sim / key
    flist = files or ["-f", "rtl/files.f", "-f", "tb/files_tb.f"]
    with _lock:
        out.mkdir(parents=True, exist_ok=True)
    if sim == "icarus":
        exe = out / "sim.vvp"
        if exe.exists():
            return exe, ""
        cmd = ["iverilog", "-g2012", "-o", str(exe), "-s", top] + [f"-D{d}" for d in DEFINES]
        cmd += [f"-P{top}.{k}={v}" for k, v in cfg.items()] + flist + [tb]
        rc, log = run(cmd, cwd=root)
        return (exe if rc == 0 and exe.exists() else None), log
    exe = out / f"V{top}"
    if exe.exists():
        return exe, ""
    cmd = ["verilator", "--binary", "--timing", "-O2", "-j", "2", "--top-module", top, "-Mdir", str(out)] + VFLAGS
    cmd += [f"+define+{d}" for d in DEFINES] + [f"-G{k}={v}" for k, v in cfg.items()] + flist + [tb]
    rc, log = run(cmd, cwd=root)
    return (exe if rc == 0 and exe.exists() else None), log


def simulate(sim: str, exe: Path, plus: dict, timeout=1800):
    args = [f"+{k}={v}" for k, v in plus.items()]
    if sim == "icarus":
        return run(["vvp", "-n", str(exe)] + args, timeout=timeout)
    seed = int(plus.get("seed", 1))
    return run([str(exe), f"+verilator+seed+{seed}", "+verilator+rand+reset+2"] + args, timeout=timeout)


def parse(log: str) -> dict:
    d = dict(perf={}, stats={}, result=None, errors=[])
    for line in log.splitlines():
        if line.startswith("PERF "):
            _, i, v = line.split()
            d["perf"][PC_NAMES[int(i)]] = int(v)
        elif line.startswith("STATS "):
            d["stats"] = {k: int(v) for k, v in (x.split("=") for x in line.split()[1:])}
        elif line.startswith("RESULT "):
            d["result"] = line.split()[1]
        elif line.startswith("ERROR") or "%Error" in line or "Assertion" in line or "TIMEOUT" in line:
            d["errors"].append(line.strip())
    return d


def tool_versions() -> dict:
    v = {}
    for name, cmd in [("icarus", ["iverilog", "-V"]), ("verilator", ["verilator", "--version"]), ("yosys", ["yosys", "-V"])]:
        try:
            v[name] = run(cmd)[1].splitlines()[0].strip()
        except Exception:  # noqa: BLE001
            v[name] = "n/a"
    v["python"] = sys.version.split()[0]
    return v


def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1))
