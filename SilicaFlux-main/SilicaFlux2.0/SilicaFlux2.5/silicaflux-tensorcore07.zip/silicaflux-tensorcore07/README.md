# SilicaFlux TENSORCORE 07 — Tensor DMA adapter and memory-movement pipeline

**Primary source:** `rtl/tensor_dma_adapter.sv` · Aureom.AI | SilicaFlux-HPC

The data-movement subsystem between the TensorCore buffers and the existing SilicaFlux DataFabric: byte-addressed
**2-D strided** transfers from external memory into the TENSORCORE 03 operand buffer (A and B regions), and from a
new **tensor output buffer** (fed by TENSORCORE 04) back to external memory — over the **real SFB2 bus protocol**,
with explicit **FREE / FILLING / READY / IN_USE** double-buffer ownership, optional **next-tile prefetch** that
preserves memory dependencies, a **sequential fallback**, and 18 performance counters.

> **Not committed to GitHub** — delivered as a plain archive. Every number below comes from the generated reports
> in `reports/` (final run on these sources). Simulation, lint and Yosys synthesis only: no hardware run, no timing
> / Fmax claim.

## Results

| Check | Result | Report |
|---|---|---|
| Staged regression, stage 1: one sequential 1-D transfer at a time (5 HW configs incl. the one-transaction baseline) | **68 / 68 runs pass** | `regression.md` |
| Stage 2: 2-D strided, partial rows, every misalignment, long, back-pressure, DataFabric R6, every error kind, every validation rule | **242 / 242 runs pass** (incl. directed output-buffer ownership test) | `regression.md` |
| Stage 3: double-buffered overlap, prefetch vs sequential, RAW / WAR dependencies, fences, reset during transfer, scratchpad contention, random mixes | **272 / 272 runs pass** | `regression.md` |
| Icarus 12 vs Verilator 5.020, same seed: identical bus statistics, cycle counts and counters | **68 / 68 run pairs identical** | `regression.md` |
| End-to-end tiled GEMMs on the **unmodified TC02 / TC03 / TC04** with every operand block and C tile moved by the DMA (11 workloads × 4 HW × 4 memory behaviours × 2 modes) | **328 / 328 runs pass** | `gemm.md` |
| On the **real DataFabric crossbar** against CPU, vector-stream, DataFabric-DMA and scratchpad-lane traffic; memory read back through the fabric | **36 / 36 runs pass** | `xbar.md` |
| Mutation testing: deliberate bugs in the new RTL detected | **27 / 30 killed**; 3 survivors analysed as equivalent (redundant interlocks), 0 unexplained | `mutation.md` |
| Lint: Verilator -Wall, 7 parameter sets, **0 warnings in new RTL**; Icarus elaboration; 12 illegal parameter sets rejected by the modules' own checks | **19 / 19** | `lint.md` |
| Yosys 0.33: adapter (2 configs, generic + xc7), output buffer, **whole integration flattened**: no latch, `check -assert` (no combinational loop) | **6 / 6 OK** | `synth.md` |
| Single-transfer throughput sweep (self-checking) | **360 / 360** | `perf.md` |

**Definition of done — met:** tensor operands and results move through the real implemented memory interface
(SFB2 to memory / the DataFabric crossbar; Module 04 ports to TC03 and the output buffer) **without data loss,
duplication or premature completion**: every run compares the whole external memory and every operand set at the
moment compute takes it with an independent reference; a per-byte last-writer check proves each destination byte was
written once, by its descriptor, **before** that descriptor's completion record; the end-to-end GEMMs produce exact C.

## Headline measurements

| Measurement | Value | Source |
|---|---|---|
| 1 KiB load, 32-bit port, 1 / 2 / 4 transactions in flight | 0.99 / 1.97 / **3.83 B/cycle** (peak 4) | `perf.md` |
| same, source +1 and destination +3 bytes misaligned | 0.99 / 1.96 / **3.82 B/cycle** — misalignment is free (existing DataFabric engines reject it) | `perf.md` |
| 1 KiB load, 64-bit port | **7.37 B/cycle** (peak 8) | `perf.md` |
| GEMM 17 × 13 × 29 (misaligned strides), sequential → prefetch | 3 903 → 2 155 cycles (**1.81×**) | `gemm.md` |
| GEMM 32 × 32 × 256, sequential → prefetch | 63 557 → **40 069** cycles (1.59×); **84 %** of the single-port bound (33 792 transactions); TC06's embedded mover: 36 729 | `gemm.md`, doc 08 |
| Tensor DMA's worst request wait on the crossbar, round robin vs fixed priority | **3–5** vs 13 cycles | `xbar.md` |

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Audit (DataFabric DMA, DataFabric, HPC DMA adapter, scratchpad, operand buffers, bus protocol); reuse; justification for a new engine | `docs/00_AUDIT.md` (§5: why 1-D engines cannot move INT8 tiles, and why this engine is compatible, not a second subsystem) |
| 2 | ext → A, ext → B, output → ext; byte addresses; length, row stride, rows, ID, completion and error status | `rtl/tdma_defs.svh`, `docs/02_DESCRIPTOR.md` |
| 3 | 2-D strided transfers; row boundaries, partial tiles, non-contiguous rows, byte tails, alignment, capacity; no packing assumption | `rtl/tdma_agu.sv`, `rtl/tdma_realign.sv`, `rtl/tdma_validate.sv`; `docs/03` §2 |
| 4 | Request / response handshakes, back-pressure, outstanding tracking, buffering, error propagation; completion = acknowledged | `rtl/tdma_sfb_port.sv`, `rtl/tdma_loc_port.sv`, `rtl/tdma_channel.sv`; `docs/03` §3–§6 |
| 5 | Double-buffer ownership FREE / FILLING / READY / IN_USE; no overwrite before release; no compute before DMA completion | `rtl/tdma_buf_coord.sv`, TC03 + `rtl/tensor_output_buffer.sv` (both `tob_dbuf_ctrl`); `docs/04` §1–§3 |
| 6 | Optional next-tile prefetch, configurable, no dependency violation, no overwrite of live data; sequential fallback | `cfg_prefetch`; dependency check in `rtl/tensor_dma_adapter.sv`; `docs/04` §4 |
| 7 | Arbitration with CPU / vector / other DMA / scratchpad; reuse DataFabric arbitration; no starvation (documented conditions) | `docs/05_ARBITRATION_AND_FABRIC.md`; `tb/tb_tdma_xbar.sv` |
| 8 | Bytes read / written, active, stall, outstanding, buffer waiting, errors | `rtl/tdma_perf.sv`; `docs/06_PERFORMANCE_COUNTERS.md` |
| 9 | Single row, multi-row strided, partial final row, misaligned, long, back-pressure, scratchpad contention, double-buffer switching, reset during transfer, error propagation, write completion; byte-accurate memory models | `docs/07_VERIFICATION.md` §3 (item → tests); `tb/tb_tdma.sv` |
| 10 | Deliverables | table below |
| — | Start with one sequential transfer, then 2-D, then double-buffered overlap | `scripts/run_regress.py` stages 1 → 2 → 3 (a failing stage stops the run) |

## Deliverables

| Deliverable | Files |
|---|---|
| `tensor_dma_adapter.sv` | `rtl/tensor_dma_adapter.sv` (+ `tdma_channel`, `tdma_agu`, `tdma_realign`, `tdma_sfb_port`, `tdma_loc_port`, `tdma_validate`, `tdma_queue`, `tdma_perf`) |
| 2-D transfer descriptor definition | `rtl/tdma_defs.svh`, `model/tdma_desc.py` (checked equal by `scripts/check_abi.py`), `docs/02_DESCRIPTOR.md` |
| Buffer coordination logic | `rtl/tdma_buf_coord.sv`, `rtl/tensor_output_buffer.sv`, `rtl/tout_gate.sv`, `docs/04_BUFFER_COORDINATION.md` |
| Tests | `tb/tb_tdma.sv`, `tb/tb_tdma_gemm.sv`, `tb/tb_tdma_xbar.sv`, `tb/tb_tout.sv`; `model/tdma_ref.py` (reference), `model/gen_tests.py`, `model/gemm_gen.py`, `model/gen_xbar.py`; `scripts/run_*.py` |
| Throughput analysis | `docs/08_THROUGHPUT_ANALYSIS.md`, `reports/perf.md`, `reports/gemm.md` |
| Integration documentation | `docs/09_INTEGRATION.md`, `rtl/tdma_tile_system.sv` (worked integration), `docs/01_ARCHITECTURE.md` |
| Also | `docs/00` audit, `03` transfer & protocol, `05` arbitration, `06` counters, `07` verification, `10` limitations; `reports/`; `third_party/` (`SHA256SUMS`, `PROVENANCE.md`) |

## Quick start

```bash
make quick        # lint + stage 1 (one sequential transfer at a time), Verilator, about a minute
```

```bash
make regress      # stages 1 -> 2 -> 3, 5 configurations, Verilator + Icarus cross-simulation
```

```bash
make gemm xbar    # end-to-end GEMMs on TC02/TC03/TC04, and the DataFabric crossbar contention test
```

```bash
make all          # lint, regress, gemm, xbar, mutants, perf, synth, then reports/*.md
```

Tools: Icarus Verilog 12, Verilator 5.020, Yosys 0.33 (Ubuntu 24.04 packages), Python ≥ 3.10 (standard library
only). The directory is self-contained: `third_party/` holds every reused source, byte-identical to the archives in
`btcphilosopher/Aureom.AI`.

## Layout

```
rtl/          tensor_dma_adapter.sv  tdma_defs.svh  tdma_channel.sv  tdma_agu.sv  tdma_realign.sv  tdma_sfb_port.sv
              tdma_loc_port.sv  tdma_validate.sv  tdma_queue.sv  tdma_buf_coord.sv  tdma_perf.sv
              tensor_output_buffer.sv  tout_gate.sv  tdma_compute_seq.sv  tdma_tile_system.sv  files.f
tb/           tb_tdma.sv  tb_tdma_gemm.sv  tb_tdma_xbar.sv  tb_tout.sv  files_tb.f
model/        tdma_desc.py (ABI)  tdma_ref.py (reference)  gen_tests.py  gemm_gen.py  gen_xbar.py
scripts/      run_regress  run_gemm  run_xbar  run_mutants  run_lint  run_synth  run_perf  make_report  check_abi  common
docs/         00 audit · 01 architecture · 02 descriptor · 03 transfer & protocol · 04 buffer coordination & prefetch
              05 arbitration · 06 counters · 07 verification · 08 throughput analysis · 09 integration · 10 limitations
reports/      regression · gemm · xbar · mutation · lint · synth · perf (.md + .json)
third_party/  TC02/03/04, Module 04 scratchpad, DataFabric subset, SRAM Wrapper Library subset; SHA256SUMS, PROVENANCE.md
```

## Honest caveats

* Simulation only; no formal proof, gate-level simulation, FPGA or silicon. Synthesis numbers are Yosys estimates
  with no timing analysis; the validation multipliers and the one-cycle dependency scan are the likely timing paths.
* **A channel runs one descriptor at a time** (it completes every acknowledgement before starting the next): about
  12 cycles per descriptor, which is why 32 × 32 × 256 reaches 84 % of the port bound versus 92 % for TC06's
  embedded mover. Descriptor pipelining is the first next action (doc 08 §5).
* Behind the DataFabric crossbar (one transaction per port, R6) throughput is one word per slave round trip.
* The output buffer is new (no addressable output buffer existed); it is built from the unmodified Module 04
  scratchpad and TC03 ownership controller. TC06 has **not** been retrofitted to use the adapter and the Module 06
  command queue is not connected; the end-to-end integration uses a reference compute sequencer
  (`tdma_compute_seq`, test infrastructure). Details: `docs/09`, `docs/10`.
