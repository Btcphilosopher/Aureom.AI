# Unit / system regression (tb_tdma)

**582 / 582 runs pass**, stages [1, 2, 3] in order (a failing stage stops the run). Icarus vs Verilator cross-simulation: **68 / 68** run pairs with identical bus statistics, cycle counts and counters. Wall time 61.8 s. Tools: icarus: Icarus Verilog version 12.0 (stable) (), verilator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1), yosys: Yosys 0.33 (git sha1 2584903a060), python: 3.13.18.

## Hardware configurations

| config | parameters |
|---|---|
| `seq1` | WB=4, NS=1, ASB=1024, BSB=1024, OS=1, OSB=256, MAXOUT=1, LOCOUT=1, RCAP=8, QD=2, CPLD=2, TPM=1, TRL=1, OPM=0, ORL=1, ONB=2 |
| `base` | WB=4, NS=2, ASB=1024, BSB=1024, OS=2, OSB=256, MAXOUT=4, LOCOUT=4, RCAP=32, QD=4, CPLD=4, TPM=1, TRL=1, OPM=0, ORL=1, ONB=2 |
| `small` | WB=4, NS=2, ASB=256, BSB=256, OS=2, OSB=128, MAXOUT=2, LOCOUT=2, RCAP=8, QD=2, CPLD=2, TPM=1, TRL=1, OPM=0, ORL=1, ONB=2 |
| `wide` | WB=8, NS=2, ASB=1024, BSB=1024, OS=2, OSB=256, MAXOUT=4, LOCOUT=4, RCAP=32, QD=4, CPLD=4, TPM=1, TRL=1, OPM=0, ORL=1, ONB=2 |
| `stress` | WB=4, NS=2, ASB=1024, BSB=1024, OS=2, OSB=256, MAXOUT=16, LOCOUT=8, RCAP=64, QD=8, CPLD=2, TPM=0, TRL=2, OPM=0, ORL=2, ONB=1 |

## Runs per stage and configuration

| stage | config | Verilator runs | pass | Icarus runs | pass |
|---|---|---|---|---|---|
| 1 | `base` | 12 | 12 | 4 | 4 |
| 1 | `seq1` | 12 | 12 | 4 | 4 |
| 1 | `small` | 12 | 12 | 0 | 0 |
| 1 | `stress` | 12 | 12 | 0 | 0 |
| 1 | `wide` | 12 | 12 | 0 | 0 |
| 2 | `base` | 42 | 42 | 14 | 14 |
| 2 | `seq1` | 42 | 42 | 14 | 14 |
| 2 | `small` | 42 | 42 | 0 | 0 |
| 2 | `stress` | 42 | 42 | 0 | 0 |
| 2 | `tout_opm0` | 1 | 1 | 1 | 1 |
| 2 | `tout_opm1` | 1 | 1 | 1 | 1 |
| 2 | `wide` | 42 | 42 | 0 | 0 |
| 3 | `base` | 48 | 48 | 16 | 16 |
| 3 | `seq1` | 48 | 48 | 16 | 16 |
| 3 | `small` | 48 | 48 | 0 | 0 |
| 3 | `stress` | 48 | 48 | 0 | 0 |
| 3 | `wide` | 48 | 48 | 0 | 0 |

## Tests

| test | stage | runs | pass | max cycles |
|---|---|---|---|---|
| `s1_lengths_load` | 1 | 17 | 17 | 4397 |
| `s1_lengths_store` | 1 | 17 | 17 | 3249 |
| `s1_long_1d` | 1 | 17 | 17 | 5275 |
| `s1_single` | 1 | 17 | 17 | 204 |
| `s2_err_loc_rd` | 2 | 17 | 17 | 506 |
| `s2_err_loc_wr` | 2 | 17 | 17 | 603 |
| `s2_err_proto` | 2 | 17 | 17 | 603 |
| `s2_err_rd` | 2 | 17 | 17 | 808 |
| `s2_err_wr` | 2 | 17 | 17 | 801 |
| `s2_invalid` | 2 | 17 | 17 | 188 |
| `s2_long_2d` | 2 | 17 | 17 | 2582 |
| `s2_multirow` | 2 | 17 | 17 | 2593 |
| `s2_partial` | 2 | 17 | 17 | 2668 |
| `s2_random` | 2 | 17 | 17 | 8788 |
| `s2_random_bp` | 2 | 17 | 17 | 22914 |
| `s2_random_xbar` | 2 | 17 | 17 | 13980 |
| `s2_src_overlap` | 2 | 17 | 17 | 757 |
| `s2_writecpl` | 2 | 17 | 17 | 37038 |
| `tout_ownership` | 2 | 4 | 4 | 0 |
| `s3_contention_pf0` | 3 | 17 | 17 | 982 |
| `s3_contention_pf1` | 3 | 17 | 17 | 982 |
| `s3_dbuf_bp_pf0` | 3 | 17 | 17 | 10442 |
| `s3_dbuf_bp_pf1` | 3 | 17 | 17 | 10514 |
| `s3_dbuf_pf0` | 3 | 17 | 17 | 5846 |
| `s3_dbuf_pf1` | 3 | 17 | 17 | 5974 |
| `s3_fence_pf0` | 3 | 17 | 17 | 11376 |
| `s3_fence_pf1` | 3 | 17 | 17 | 8353 |
| `s3_hazard_raw_pf0` | 3 | 17 | 17 | 721 |
| `s3_hazard_raw_pf1` | 3 | 17 | 17 | 628 |
| `s3_hazard_war_pf0` | 3 | 17 | 17 | 1010 |
| `s3_hazard_war_pf1` | 3 | 17 | 17 | 898 |
| `s3_mix_pf0` | 3 | 17 | 17 | 35969 |
| `s3_mix_pf1` | 3 | 17 | 17 | 37055 |
| `s3_reset_pf0` | 3 | 17 | 17 | 6062 |
| `s3_reset_pf1` | 3 | 17 | 17 | 6158 |

Failing runs: 0.
