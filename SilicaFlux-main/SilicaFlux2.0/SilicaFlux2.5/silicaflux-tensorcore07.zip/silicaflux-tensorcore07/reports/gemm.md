# End-to-end GEMM integration (tb_tdma_gemm on tdma_tile_system)

**328 / 328 runs pass.** Every operand block and every C tile moves through tensor_dma_adapter over one SFB2 port; TC02 / TC03 / TC04 are unmodified. Each run compares the whole memory (C exact, everything else untouched) and checks every completion. Tools: icarus: Icarus Verilog version 12.0 (stable) (), verilator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1), yosys: Yosys 0.33 (git sha1 2584903a060), python: 3.13.18

## Workloads

| workload | M x N x K | tiles | K chunks | descriptors | useful MACs |
|---|---|---|---|---|---|
| `g1x1x1` | 1 x 1 x 1 | 1 | 1 | 3 | 1 |
| `g4x4x4` | 4 x 4 x 4 | 1 | 1 | 3 | 64 |
| `g5x7x3` | 5 x 7 x 3 | 4 | 1 | 12 | 105 |
| `g17x13x29` | 17 x 13 x 29 | 20 | 1 | 60 | 6409 |
| `g37x1x5` | 37 x 1 x 5 | 10 | 1 | 30 | 185 |
| `g1x37x5` | 1 x 37 x 5 | 10 | 1 | 30 | 185 |
| `g8x8x200` | 8 x 8 x 200 | 4 | 4 | 36 | 12800 |
| `g32x32x64` | 32 x 32 x 64 | 64 | 1 | 192 | 65536 |
| `g64x16x64n` | 64 x 16 x 64 | 64 | 1 | 192 | 65536 |
| `g32x32x256` | 32 x 32 x 256 | 64 | 4 | 576 | 262144 |
| `g32x32x256u` | 32 x 32 x 256 | 64 | 4 | 576 | 262144 |

## Cycles: SEQUENTIAL (0) vs PREFETCH (1), configuration `base`

| workload | memory | cycles seq | cycles prefetch | speed-up | array utilisation prefetch | DMA overlap cycles |
|---|---|---|---|---|---|---|
| `g1x1x1` | lat1 | 74 | 74 | 1.00x | 0.1 % | 0 |
| `g1x1x1` | lat8 | 95 | 95 | 1.00x | 0.1 % | 0 |
| `g1x1x1` | xbar | 83 | 83 | 1.00x | 0.1 % | 0 |
| `g1x1x1` | bp | 78 | 78 | 1.00x | 0.1 % | 0 |
| `g4x4x4` | lat1 | 126 | 126 | 1.00x | 3.2 % | 0 |
| `g4x4x4` | lat8 | 175 | 175 | 1.00x | 2.3 % | 0 |
| `g4x4x4` | xbar | 235 | 235 | 1.00x | 1.7 % | 0 |
| `g4x4x4` | bp | 159 | 159 | 1.00x | 2.5 % | 0 |
| `g5x7x3` | lat1 | 397 | 186 | 2.13x | 3.5 % | 9 |
| `g5x7x3` | lat8 | 544 | 305 | 1.78x | 2.2 % | 4 |
| `g5x7x3` | xbar | 653 | 407 | 1.60x | 1.6 % | 3 |
| `g5x7x3` | bp | 484 | 251 | 1.93x | 2.6 % | 6 |
| `g17x13x29` | lat1 | 3903 | 2155 | 1.81x | 18.6 % | 534 |
| `g17x13x29` | lat8 | 6892 | 5076 | 1.36x | 7.9 % | 197 |
| `g17x13x29` | xbar | 10483 | 8710 | 1.20x | 4.6 % | 152 |
| `g17x13x29` | bp | 5782 | 4064 | 1.42x | 9.9 % | 293 |
| `g37x1x5` | lat1 | 956 | 434 | 2.20x | 2.7 % | 68 |
| `g37x1x5` | lat8 | 1299 | 705 | 1.84x | 1.6 % | 34 |
| `g37x1x5` | xbar | 1570 | 1024 | 1.53x | 1.1 % | 18 |
| `g37x1x5` | bp | 1179 | 599 | 1.97x | 1.9 % | 38 |
| `g1x37x5` | lat1 | 893 | 389 | 2.30x | 3.0 % | 28 |
| `g1x37x5` | lat8 | 1173 | 606 | 1.94x | 1.9 % | 18 |
| `g1x37x5` | xbar | 1399 | 840 | 1.67x | 1.4 % | 18 |
| `g1x37x5` | bp | 1093 | 543 | 2.01x | 2.1 % | 18 |
| `g8x8x200` | lat1 | 4153 | 3100 | 1.34x | 25.8 % | 648 |
| `g8x8x200` | lat8 | 8577 | 7397 | 1.16x | 10.8 % | 248 |
| `g8x8x200` | xbar | 14165 | 12988 | 1.09x | 6.2 % | 157 |
| `g8x8x200` | bp | 6909 | 5740 | 1.20x | 13.9 % | 355 |
| `g32x32x64` | lat1 | 23109 | 14982 | 1.54x | 27.3 % | 4032 |
| `g32x32x64` | lat8 | 46405 | 38278 | 1.21x | 10.7 % | 1575 |
| `g32x32x64` | xbar | 76165 | 68101 | 1.12x | 6.0 % | 945 |
| `g32x32x64` | bp | 37923 | 28905 | 1.31x | 14.2 % | 2166 |
| `g64x16x64n` | lat1 | 23109 | 14982 | 1.54x | 27.3 % | 4032 |
| `g64x16x64n` | lat8 | 46405 | 38278 | 1.21x | 10.7 % | 1575 |
| `g64x16x64n` | xbar | 76165 | 68101 | 1.12x | 6.0 % | 945 |
| `g64x16x64n` | bp | 37923 | 28905 | 1.31x | 14.2 % | 2166 |
| `g32x32x256` | lat1 | 63557 | 40069 | 1.59x | 40.9 % | 16320 |
| `g32x32x256` | lat8 | 122693 | 99205 | 1.24x | 16.5 % | 6184 |
| `g32x32x256` | xbar | 198149 | 174724 | 1.13x | 9.4 % | 3634 |
| `g32x32x256` | bp | 101273 | 77159 | 1.31x | 21.2 % | 8676 |
| `g32x32x256u` | lat1 | 79941 | 56453 | 1.42x | 29.0 % | 16320 |
| `g32x32x256u` | lat8 | 167749 | 144261 | 1.16x | 11.4 % | 6184 |
| `g32x32x256u` | xbar | 280069 | 256644 | 1.09x | 6.4 % | 3634 |
| `g32x32x256u` | bp | 135444 | 111110 | 1.22x | 14.7 % | 8731 |

## Configurations (prefetch, memory `lat1`)

| workload | base | single | min | stress |
|---|---|---|---|---|
| `g1x1x1` | 74 | 74 | 74 | 74 |
| `g4x4x4` | 126 | 126 | 201 | 126 |
| `g5x7x3` | 186 | 244 | 342 | 189 |
| `g17x13x29` | 2155 | 3045 | 7154 | 2287 |
| `g37x1x5` | 434 | 631 | 892 | 443 |
| `g1x37x5` | 389 | 587 | 668 | 389 |
| `g8x8x200` | 3100 | 4009 | 10872 | 3204 |
| `g32x32x64` | 14982 | 20085 | 54531 | 15990 |
| `g64x16x64n` | 14982 | 20085 | 54531 | 15990 |
| `g32x32x256` | 40069 | 60533 | 139906 | 44149 |
| `g32x32x256u` | 56453 | 76917 | 205442 | 60533 |

Hardware: `base` = NS=2, MAXOUT=4, LOCOUT=4, RCAP=32, QD=4, TPM=1, OPM=0, ONB=2; `single` = NS=1, MAXOUT=4, LOCOUT=4, RCAP=32, QD=4, TPM=1, OPM=0, ONB=2; `min` = NS=2, MAXOUT=1, LOCOUT=1, RCAP=8, QD=2, TPM=1, OPM=0, ONB=2; `stress` = NS=2, MAXOUT=16, LOCOUT=8, RCAP=64, QD=8, TPM=0, OPM=0, ONB=1

Memory: `lat1` = latency 1; `lat8` = lat_min=8, lat_max=8; `xbar` = xbar=1, lat_min=4, lat_max=4; `bp` = bp=30, lat_min=1, lat_max=6, cpl_bp=20

Failing runs: 0.
