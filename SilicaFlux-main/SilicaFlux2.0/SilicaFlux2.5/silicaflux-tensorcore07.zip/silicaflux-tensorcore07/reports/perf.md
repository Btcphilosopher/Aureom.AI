# Single-transfer throughput sweep (scripts/run_perf.py)

Sweep: **360 / 360 runs pass** (every run self-checking). Bytes per cycle of the transfer (channel busy cycles minus buffer-wait cycles):

### 32-bit port (WB = 4), peak 4 B/cycle

| transfer | memory | MAX_OUT 1 | 2 | 4 | 8 | 16 |
|---|---|---|---|---|---|---|
| `load1d_aligned` | lat1 | 0.99 | 1.97 | 3.83 | 3.83 | 3.83 |
| `load1d_aligned` | lat4 | 0.57 | 1.13 | 2.23 | 3.79 | 3.79 |
| `load1d_aligned` | lat8 | 0.36 | 0.72 | 1.43 | 2.79 | 3.74 |
| `load1d_aligned` | lat16 | 0.21 | 0.42 | 0.83 | 1.64 | 2.99 |
| `load1d_aligned` | xbar_lat1 | 0.99 | 1.96 | 1.96 | 1.96 | 1.96 |
| `load1d_aligned` | xbar_lat4 | 0.57 | 0.79 | 0.79 | 0.79 | 0.79 |
| `load1d_misaligned` | lat1 | 0.99 | 1.96 | 3.82 | 3.82 | 3.82 |
| `load1d_misaligned` | lat4 | 0.57 | 1.13 | 2.22 | 3.78 | 3.78 |
| `load1d_misaligned` | lat8 | 0.36 | 0.72 | 1.43 | 2.78 | 3.73 |
| `load1d_misaligned` | lat16 | 0.21 | 0.42 | 0.83 | 1.64 | 2.82 |
| `load1d_misaligned` | xbar_lat1 | 0.99 | 1.96 | 1.96 | 1.96 | 1.96 |
| `load1d_misaligned` | xbar_lat4 | 0.57 | 0.79 | 0.79 | 0.79 | 0.79 |
| `load2d_32x31` | lat1 | 0.91 | 1.79 | 3.50 | 3.50 | 3.50 |
| `load2d_32x31` | lat4 | 0.52 | 1.03 | 2.04 | 3.47 | 3.47 |
| `load2d_32x31` | lat8 | 0.33 | 0.66 | 1.31 | 2.55 | 3.42 |
| `load2d_32x31` | lat16 | 0.19 | 0.38 | 0.76 | 1.50 | 2.80 |
| `load2d_32x31` | xbar_lat1 | 0.91 | 1.79 | 1.79 | 1.79 | 1.79 |
| `load2d_32x31` | xbar_lat4 | 0.52 | 0.72 | 0.72 | 0.72 | 0.72 |
| `load2d_256x4` | lat1 | 0.57 | 1.13 | 2.23 | 2.23 | 2.23 |
| `load2d_256x4` | lat4 | 0.33 | 0.65 | 1.29 | 2.22 | 2.22 |
| `load2d_256x4` | lat8 | 0.21 | 0.41 | 0.82 | 1.62 | 2.20 |
| `load2d_256x4` | lat16 | 0.12 | 0.24 | 0.48 | 0.95 | 1.84 |
| `load2d_256x4` | xbar_lat1 | 0.57 | 1.13 | 1.13 | 1.13 | 1.13 |
| `load2d_256x4` | xbar_lat4 | 0.33 | 0.46 | 0.46 | 0.46 | 0.46 |
| `store1d_aligned` | lat1 | 0.97 | 1.88 | 3.46 | 3.46 | 3.46 |
| `store1d_aligned` | lat4 | 0.56 | 1.10 | 2.10 | 3.33 | 3.33 |
| `store1d_aligned` | lat8 | 0.36 | 0.71 | 1.38 | 2.51 | 3.16 |
| `store1d_aligned` | lat16 | 0.21 | 0.42 | 0.81 | 1.54 | 2.61 |
| `store1d_aligned` | xbar_lat1 | 0.97 | 1.87 | 1.87 | 1.87 | 1.87 |
| `store1d_aligned` | xbar_lat4 | 0.56 | 0.78 | 0.78 | 0.78 | 0.78 |
| `store1d_misaligned` | lat1 | 0.95 | 1.83 | 3.40 | 3.40 | 3.40 |
| `store1d_misaligned` | lat4 | 0.55 | 1.07 | 2.02 | 3.27 | 3.27 |
| `store1d_misaligned` | lat8 | 0.35 | 0.69 | 1.31 | 2.41 | 3.11 |
| `store1d_misaligned` | lat16 | 0.20 | 0.40 | 0.77 | 1.43 | 2.50 |
| `store1d_misaligned` | xbar_lat1 | 0.95 | 1.83 | 1.83 | 1.83 | 1.83 |
| `store1d_misaligned` | xbar_lat4 | 0.55 | 0.76 | 0.76 | 0.76 | 0.76 |

### 64-bit port (WB = 8), peak 8 B/cycle

| transfer | memory | MAX_OUT 1 | 2 | 4 | 8 | 16 |
|---|---|---|---|---|---|---|
| `load1d_aligned` | lat1 | 1.97 | 3.86 | 7.37 | 7.37 | 7.37 |
| `load1d_aligned` | lat4 | 1.13 | 2.24 | 4.36 | 7.21 | 7.21 |
| `load1d_aligned` | lat8 | 0.72 | 1.44 | 2.82 | 5.36 | 7.01 |
| `load1d_aligned` | lat16 | 0.42 | 0.84 | 1.65 | 3.21 | 5.63 |
| `load1d_aligned` | xbar_lat1 | 1.97 | 3.85 | 3.85 | 3.85 | 3.85 |
| `load1d_aligned` | xbar_lat4 | 1.13 | 1.57 | 1.57 | 1.57 | 1.57 |
| `load1d_misaligned` | lat1 | 1.96 | 3.85 | 7.34 | 7.34 | 7.34 |
| `load1d_misaligned` | lat4 | 1.13 | 2.23 | 4.34 | 7.19 | 7.19 |
| `load1d_misaligned` | lat8 | 0.72 | 1.43 | 2.81 | 5.35 | 6.99 |
| `load1d_misaligned` | lat16 | 0.42 | 0.83 | 1.65 | 3.20 | 5.26 |
| `load1d_misaligned` | xbar_lat1 | 1.96 | 3.84 | 3.84 | 3.84 | 3.84 |
| `load1d_misaligned` | xbar_lat4 | 1.13 | 1.57 | 1.57 | 1.57 | 1.57 |
| `load2d_32x31` | lat1 | 1.61 | 3.17 | 6.09 | 6.09 | 6.09 |
| `load2d_32x31` | lat4 | 0.93 | 1.83 | 3.58 | 5.98 | 5.98 |
| `load2d_32x31` | lat8 | 0.59 | 1.17 | 2.31 | 4.43 | 5.83 |
| `load2d_32x31` | lat16 | 0.34 | 0.68 | 1.35 | 2.64 | 4.84 |
| `load2d_32x31` | xbar_lat1 | 1.61 | 3.16 | 3.16 | 3.16 | 3.16 |
| `load2d_32x31` | xbar_lat4 | 0.93 | 1.29 | 1.29 | 1.29 | 1.29 |
| `load2d_256x4` | lat1 | 0.72 | 1.44 | 2.82 | 2.82 | 2.82 |
| `load2d_256x4` | lat4 | 0.41 | 0.82 | 1.63 | 2.80 | 2.80 |
| `load2d_256x4` | lat8 | 0.26 | 0.53 | 1.05 | 2.05 | 2.77 |
| `load2d_256x4` | lat16 | 0.15 | 0.30 | 0.61 | 1.20 | 2.32 |
| `load2d_256x4` | xbar_lat1 | 0.72 | 1.43 | 1.43 | 1.43 | 1.43 |
| `load2d_256x4` | xbar_lat4 | 0.41 | 0.58 | 0.58 | 0.58 | 0.58 |
| `store1d_aligned` | lat1 | 1.90 | 3.56 | 6.09 | 6.09 | 6.09 |
| `store1d_aligned` | lat4 | 1.11 | 2.13 | 3.88 | 5.69 | 5.69 |
| `store1d_aligned` | lat8 | 0.71 | 1.39 | 2.61 | 4.41 | 5.22 |
| `store1d_aligned` | lat16 | 0.42 | 0.82 | 1.58 | 2.84 | 4.27 |
| `store1d_aligned` | xbar_lat1 | 1.90 | 3.51 | 3.51 | 3.51 | 3.51 |
| `store1d_aligned` | xbar_lat4 | 1.11 | 1.51 | 1.51 | 1.51 | 1.51 |
| `store1d_misaligned` | lat1 | 1.83 | 3.40 | 5.93 | 5.93 | 5.93 |
| `store1d_misaligned` | lat4 | 1.07 | 2.02 | 3.64 | 5.54 | 5.54 |
| `store1d_misaligned` | lat8 | 0.69 | 1.31 | 2.41 | 4.11 | 5.10 |
| `store1d_misaligned` | lat16 | 0.40 | 0.77 | 1.43 | 2.50 | 3.98 |
| `store1d_misaligned` | xbar_lat1 | 1.83 | 3.40 | 3.40 | 3.40 | 3.40 |
| `store1d_misaligned` | xbar_lat4 | 1.07 | 1.47 | 1.47 | 1.47 | 1.47 |

