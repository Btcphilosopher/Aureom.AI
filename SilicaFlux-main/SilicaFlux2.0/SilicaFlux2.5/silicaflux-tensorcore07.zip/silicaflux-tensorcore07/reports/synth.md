# Synthesis (Yosys 0.33) - resource estimates and structural checks only

No place and route, no timing analysis: **no clock frequency is claimed.** Every run asserts no latch and `check -assert` (no combinational loop, no undriven net) on the flattened design. Tools: icarus: Icarus Verilog version 12.0 (stable) (), verilator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1), yosys: Yosys 0.33 (git sha1 2584903a060), python: 3.13.18

| run | top | flow | parameters | result | cells | flip-flops | LUTs | CARRY4 | DSP48 | BRAM | LUTRAM |
|---|---|---|---|---|---|---|---|---|---|---|---|
| adp_generic | `tensor_dma_adapter` | generic | defaults | OK | 33132 | 5576 | - | - | - | - | - |
| adp_xc7 | `tensor_dma_adapter` | xc7 | defaults | OK | 15692 | 4772 | 5947 | 535 | 4 | - | 38 |
| adp_min_generic | `tensor_dma_adapter` | generic | NUM_SETS=1, O_SETS=1, MAX_OUT=1, LOC_OUT=1, RCAP=8, QDEPTH=2, CPL_DEPTH=2 | OK | 24497 | 3758 | - | - | - | - | - |
| obuf_generic | `tensor_output_buffer` | generic | defaults | OK | 11210 | 4682 | - | - | - | - | - |
| obuf_xc7 | `tensor_output_buffer` | xc7 | defaults | OK | 1584 | 274 | 535 | 92 | - | - | 80 |
| sys_generic | `tdma_tile_system` | generic | defaults | OK | 155844 | 48867 | - | - | - | - | - |
