# Lint and elaboration

**19 / 19 checks pass.** Tools: icarus: Icarus Verilog version 12.0 (stable) (), verilator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1), yosys: Yosys 0.33 (git sha1 2584903a060), python: 3.13.18

| check | top | parameters | result |
|---|---|---|---|
| adapter_base | `tensor_dma_adapter` | defaults | PASS: Verilator -Wall: 0 warnings in new RTL (68 in unmodified third-party files); Icarus elaboration OK |
| adapter_min | `tensor_dma_adapter` | NUM_SETS=1, O_SETS=1, MAX_OUT=1, LOC_OUT=1, RCAP=8, QDEPTH=2, CPL_DEPTH=2 | PASS: Verilator -Wall: 0 warnings in new RTL (68 in unmodified third-party files); Icarus elaboration OK |
| adapter_wide | `tensor_dma_adapter` | WB=8, RCAP=32 | PASS: Verilator -Wall: 0 warnings in new RTL (68 in unmodified third-party files); Icarus elaboration OK |
| adapter_deep | `tensor_dma_adapter` | MAX_OUT=16, LOC_OUT=8, RCAP=64, QDEPTH=16, CPL_DEPTH=8 | PASS: Verilator -Wall: 0 warnings in new RTL (68 in unmodified third-party files); Icarus elaboration OK |
| obuf_base | `tensor_output_buffer` | defaults | PASS: Verilator -Wall: 0 warnings in new RTL (70 in unmodified third-party files); Icarus elaboration OK |
| obuf_1set_wide | `tensor_output_buffer` | O_SETS=1, WB=8, PORT_MODE=1 | PASS: Verilator -Wall: 0 warnings in new RTL (70 in unmodified third-party files); Icarus elaboration OK |
| tile_system | `tdma_tile_system` | defaults | PASS: Verilator -Wall: 0 warnings in new RTL (70 in unmodified third-party files); Icarus elaboration OK |
| wb3 | `tensor_dma_adapter` | WB=3 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| sets3 | `tensor_dma_adapter` | NUM_SETS=3 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| osets0 | `tensor_dma_adapter` | O_SETS=0 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| qdepth3 | `tensor_dma_adapter` | QDEPTH=3 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| cpl1 | `tensor_dma_adapter` | CPL_DEPTH=1 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| rcap_small | `tensor_dma_adapter` | RCAP=4 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| max_out3 | `tensor_dma_adapter` | MAX_OUT=3 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| loc_out32 | `tensor_dma_adapter` | LOC_OUT=32 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| mem_window | `tensor_dma_adapter` | MEM_LO=33'h1000, MEM_HI=33'h1000 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| obuf_wb2 | `tensor_output_buffer` | WB=2 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| obuf_ld | `tensor_output_buffer` | O_LD=10 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
| obuf_tile_too_big | `tensor_output_buffer` | O_SET_BYTES=32 | PASS: rejected by the module's own check: Verilator yes, Icarus yes |
