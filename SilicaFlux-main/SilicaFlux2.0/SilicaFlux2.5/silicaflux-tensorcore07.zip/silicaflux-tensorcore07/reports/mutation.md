# Mutation testing

**27 / 30 mutants killed**; every survivor is analysed below.

Each mutant is one textual change to the new RTL, built in an isolated copy and run against the directed output-buffer test (`tb_tout`, both port modes) and the regression subset `s1_single`, `s1_lengths_load`, `s1_lengths_store`, `s2_partial`, `s2_src_overlap`, `s2_invalid`, `s2_err_rd`, `s2_err_wr`, `s2_err_loc_wr`, `s2_err_loc_rd`, `s2_err_proto`, `s2_random_bp`, `s2_writecpl`, `s3_dbuf_pf0`, `s3_dbuf_pf1`, `s3_hazard_raw_pf1`, `s3_hazard_war_pf1`, `s3_fence_pf1`, `s3_mix_pf0`, `s3_mix_pf1`, `s3_reset_pf1`, `s3_contention_pf1` on configurations base, stress, small (`small`: a reduced subset), with every regression check active.

| id | file | injected bug | result | first detection |
|---|---|---|---|---|
| M01 | `rtl/tdma_sfb_port.sv` | SFB2 responses routed to the wrong channel | killed | base/s1_single: result FAIL |
| M02 | `rtl/tdma_channel.sv` | completion without waiting for the write acknowledgements (premature completion) | killed | base/s1_single: result FAIL |
| M03 | `rtl/tdma_channel.sv` | byte count includes failed / post-error writes | killed | base/s2_err_wr: result FAIL |
| M04 | `rtl/tdma_agu.sv` | row tail not masked (writes past the end of a row) | killed | base/s1_single: counter RD_BYTES = 113, reference 108 |
| M05 | `rtl/tdma_agu.sv` | row start misalignment ignored | killed | base/s1_single: result FAIL |
| M06 | `rtl/tdma_realign.sv` | realigner does not shift bytes to the destination lanes | killed | base/s1_single: result FAIL |
| M07 | `rtl/tdma_buf_coord.sv` | SEQUENTIAL mode fills while compute owns a set | killed | base/s1_single: SEQUENTIAL mode but OVERLAP = 2 |
| M08 | `rtl/tensor_dma_adapter.sv` | memory dependencies ignored in PREFETCH mode | killed | base/s3_hazard_raw_pf1: result FAIL |
| M09 | `rtl/tensor_dma_adapter.sv` | dependency check ignores the other channel's ACTIVE descriptor | killed | base/s3_hazard_raw_pf1: result FAIL |
| M10 | `rtl/tensor_dma_adapter.sv` | SEQUENTIAL mode does not serialise the channels | killed | base/s1_single: result FAIL |
| M11 | `rtl/tensor_dma_adapter.sv` | FENCE flag ignored | killed | base/s3_fence_pf1: result FAIL |
| M12 | `rtl/tdma_validate.sv` | overlapping destination rows accepted | killed | base/s2_invalid: result FAIL |
| M13 | `rtl/tdma_validate.sv` | external range check off by one | killed | base/s2_invalid: result FAIL |
| M14 | `rtl/tdma_validate.sv` | local range check off by one (crosses into the next set) | killed | base/s2_invalid: result FAIL |
| M15 | `rtl/tdma_loc_port.sv` | local response tag / direction not checked | killed | base/s2_err_proto: result FAIL |
| M16 | `rtl/tdma_sfb_port.sv` | SFB2 request replaced before acceptance (R2) | killed | base/s2_random_bp: run aborted by an RTL assertion |
| M17 | `rtl/tdma_channel.sv` | realigner credit not checked (overflow) | killed | base/s2_err_wr: run aborted by an RTL assertion |
| M18 | `rtl/tdma_buf_coord.sv` | store drains an output set compute is still writing | killed | base/s1_lengths_store: result FAIL |
| M19 | `rtl/tensor_dma_adapter.sv` | SEAL never hands the set over | killed | base/s1_single: result FAIL |
| M20 | `rtl/tensor_dma_adapter.sv` | transfer errors reported as OK | killed | base/s2_err_rd: result FAIL |
| M21 | `rtl/tdma_queue.sv` | dependency check does not see QUEUED descriptors | killed | base/s1_single: result FAIL |
| M22 | `rtl/tensor_dma_adapter.sv` | age comparison reversed | killed | base/s1_single: result FAIL |
| M23 | `rtl/tdma_loc_port.sv` | local outstanding limit off by one | **survived** |  |
| M24 | `rtl/tensor_output_buffer.sv` | output writer ignores the row | killed | tb_tout OPM=0: ERROR t=355000: 4: drain tile 0: set 0 row 0 col 0 = c0de0300 (err 0), expected c0de0000 |
| M25 | `rtl/tensor_dma_adapter.sv` | LOAD_B lands in the A region | killed | base/s1_single: result FAIL |
| M26 | `rtl/tensor_dma_adapter.sv` | STORE always drains output set 0 | killed | base/s1_lengths_store: result FAIL |
| M27 | `rtl/tdma_channel.sv` | data of a failed read is used | **survived** |  |
| M28 | `rtl/tdma_buf_coord.sv` | fill_begin requested on a set that is not FREE | **survived** |  |
| M29 | `rtl/tdma_agu.sv` | row stride off by one | killed | base/s2_partial: result FAIL |
| M30 | `rtl/tout_gate.sv` | output-buffer OWNER check removed | killed | tb_tout OPM=0: ERROR t=65000: 1: read of a FREE set: got err=0 code=0 data=417e00b6, expected code 6 |

## Survivors

* **M23** (local outstanding limit off by one): Equivalent. The channel limits its own in-flight writes/reads with its meta FIFOs (MAXW = MAXR = max(2, LOC_OUT)), so the port is never offered more than LOC_OUT requests; the port limit is a second, redundant interlock. An invariant assertion (in-flight <= MAX_OUT) is kept in both ports.
* **M27** (data of a failed read is used): Equivalent. The edge that delivers the failing read sets the channel's error flag, and every write issue is gated by that flag, so bytes pushed from a failed read can never be written. The `!rr_err` term is defensive redundancy.
* **M28** (fill_begin requested on a set that is not FREE): Equivalent. TC03's own fill_begin_ready is true only for an EMPTY set, so presenting fill_begin early cannot open a set that is READY or IN_USE; the coordinator condition is a redundant interlock on top of TC03's hardware rule.
