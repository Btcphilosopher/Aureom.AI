# DataFabric crossbar contention (tb_tdma_xbar)

**36 / 36 runs pass.** Real `sfb_crossbar` (4 masters x 3 slaves), real `sfb_sram_slave` x 2, Module 04 `hpc_scratchpad` as TSPM with two vector lanes on its other ports, DataFabric `dma_burst_engine` as a second DMA master, self-checking CPU and vector-stream masters. Memory is initialised and finally read back through the fabric. Tools: icarus: Icarus Verilog version 12.0 (stable) (), verilator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1), yosys: Yosys 0.33 (git sha1 2584903a060), python: 3.13.18

| mode | arbitration | SRAM latency | MAX_OUT | runs | pass | tensor DMA worst wait (cycles) | mean arbitration losses | mean CPU ops | mean vector ops | mean lane ops | mean scratchpad conflict cycles | mean cycles |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `rr_l1` | round robin | 1 | 4 | 6 | 6 | 4 | 834 | 1811 | 2062 | 3879 | 398 | 80541 |
| `rr_l2` | round robin | 2 | 4 | 6 | 6 | 5 | 1187 | 3302 | 3282 | 8344 | 645 | 104665 |
| `rr_l1_mo1` | round robin | 1 | 1 | 6 | 6 | 3 | 277 | 1934 | 2194 | 4130 | 369 | 80973 |
| `fixed_l1` | fixed (tensor DMA lowest) | 1 | 4 | 6 | 6 | 13 | 2052 | 1695 | 1932 | 3589 | 363 | 80036 |
| `rr_hot` | round robin | 1 | 4 | 6 | 6 | 4 | 946 | 2274 | 2298 | 4610 | 294 | 80734 |
| `fixed_hot` | fixed (tensor DMA lowest) | 1 | 4 | 6 | 6 | 13 | 2456 | 2139 | 2157 | 4285 | 211 | 80218 |

`*_hot` modes: every generator requests on every cycle it can (100 %).
