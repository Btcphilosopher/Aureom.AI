"""Test programs for tb_tdma, with expectations from the independent reference model.

Each test is a program (descriptor stream + output tiles + resets + error injections)
written to a directory:  prog.txt  mem_init.hex  mem_exp.hex  tiles.hex  seals.txt
seal_exp.hex  meta.json.  Stage 1 = one sequential 1-D transfer at a time, stage 2 = 2-D
transfers and robustness, stage 3 = double-buffered overlap, prefetch, dependencies, reset.
"""
from __future__ import annotations

import json
import random
from pathlib import Path

from tdma_desc import CODES, F_FENCE, F_SEAL, K_LOAD_A, K_LOAD_B, K_STORE, VERSION, Desc
from tdma_ref import DONTCARE, HwCfg, Ref, Tile, word_list

INJ = {"RD": 1, "WR": 2, "OPERR": 3, "OBERR": 4, "OPTAG": 5}


class Prog:
    def __init__(self, cfg: HwCfg, seed: int):
        self.cfg, self.rng = cfg, random.Random(seed)
        init = [self.rng.randrange(256) for _ in range(cfg.MEM_BYTES)]
        self.ref = Ref(cfg, init)
        self.items: list = []
        self.tile_words: list[int] = []
        self.next_id = 0
        self.parts = 1
        self.injected = False
        self.wrap_ids = False                # IDs only need to be unique among descriptors in flight
        self.meta: dict = {}

    def ea(self, off: int) -> int:
        return self.cfg.MEM_BASE + off

    # ------------------------------------------------------------ program items
    def d(self, kind, src, dst, row_len, rows=1, sstride=0, dstride=None, flags=0, ver=VERSION, rsvd=0) -> int:
        if dstride is None:
            dstride = row_len
        dd = Desc(kind=kind, src=src & 0xFFFF_FFFF, dst=dst & 0xFFFF_FFFF, row_len=row_len & 0xFFFF,
                  rows=rows & 0xFFFF, sstride=sstride & 0xFFFF_FFFF, dstride=dstride & 0xFFFF_FFFF,
                  id=self.next_id & 0xFF, flags=flags, ver=ver, rsvd=rsvd)
        self.next_id += 1
        assert self.wrap_ids or self.next_id <= 256, "more than 256 descriptors in one program"
        self.ref.desc(dd)
        self.items.append(("D", dd, self.ref.res.cpl[-1]))
        return dd.id

    def tile(self, rows=4, cols=4, data=None, delay=0):
        """Queue an output tile for the compute producer model; it starts producing it `delay` cycles after
        it becomes the producer's next tile (the producer is independent of the descriptor stream)."""
        if data is None:
            data = [[self.rng.randrange(1 << 32) for _ in range(cols)] for _ in range(rows)]
        t = Tile(tag=len(self.tile_words) & 0xFFFF, rows=rows, cols=cols, data=data)
        off = len(self.tile_words)
        for r in range(rows):
            self.tile_words.extend(data[r])
        self.ref.tile(t)
        self.items.append(("T", t.tag, rows, cols, off, delay))

    def reset(self):
        self.ref.reset()
        self.parts += 1
        self.items.append(("R",))

    def inject(self, kind: str, arg: int):
        self.ref.set_injection(kind, arg)
        self.injected = True
        self.items.append(("E", INJ[kind], arg))

    def wait(self, n: int):
        self.items.append(("W", n))

    def gap(self, n: int):
        self.items.append(("G", n))

    # ------------------------------------------------------------ helpers for common sequences
    def load_set(self, a=None, b=None, flags=0):
        """a / b = dict(src, dst, len, rows, sstride, dstride); B carries the SEAL."""
        if a:
            self.d(K_LOAD_A, a["src"], a["dst"], a["len"], a.get("rows", 1), a.get("sstride", 0),
                   a.get("dstride"), flags=flags)
        if b:
            self.d(K_LOAD_B, b["src"], b["dst"], b["len"], b.get("rows", 1), b.get("sstride", 0),
                   b.get("dstride"), flags=flags | F_SEAL)

    def store_tile(self, dst, ldc, rows=4, cols=4, flags=0, sub=None):
        """Store a rows x cols INT32 tile from the drain set to dst with row pitch ldc."""
        o_ld = self.cfg.O_LD
        if sub is None:
            self.d(K_STORE, 0, dst, 4 * cols, rows, o_ld, ldc, flags=flags | F_SEAL)
        else:
            for i, (src, dd, ln, rw, ss, ds, fl) in enumerate(sub):
                self.d(K_STORE, src, dst + dd, ln, rw, ss, ds, flags=fl)

    # ------------------------------------------------------------ output
    def write(self, out: Path, plus: dict | None = None, stage: int = 1, tags=()):
        res = self.ref.finish()
        out.mkdir(parents=True, exist_ok=True)
        lines = []
        for it in self.items:
            if it[0] == "D":
                _, dd, rec = it
                def x(v, dflt):  # noqa: E306
                    return dflt if v is None else v
                lines.append([1, dd.id, dd.kind, dd.flags, dd.src, dd.dst, dd.sstride, dd.dstride, dd.row_len, dd.rows,
                              dd.ver, dd.rsvd, rec["code"], x(rec["bytes"], 0xFFFF_FFFF),
                              x(rec["err_addr"], 0xFFFF_FFFF), x(rec["detail"], 0xF), rec["part"],
                              1 if rec.get("optional") else 0])
            elif it[0] == "T":
                lines.append([2, it[1], it[2], it[3], it[4], it[5]] + [0] * 12)
            elif it[0] == "R":
                lines.append([3] + [0] * 17)
            elif it[0] == "E":
                lines.append([4, it[1], it[2]] + [0] * 15)
            elif it[0] == "W":
                lines.append([5, it[1]] + [0] * 16)
            elif it[0] == "G":
                lines.append([6, it[1]] + [0] * 16)
        (out / "prog.txt").write_text("".join(" ".join(f"{v:x}" for v in ln) + "\n" for ln in lines))
        (out / "mem_init.hex").write_text("\n".join(f"{v:02x}" for v in res.mem_init) + "\n")
        (out / "mem_exp.hex").write_text("\n".join("100" if v == DONTCARE else f"{v:03x}" for v in res.mem_exp) + "\n")
        (out / "tiles.hex").write_text("\n".join(f"{v:08x}" for v in (self.tile_words or [0])) + "\n")
        seals = [s for s in res.seals if s["part"] == self.parts]
        (out / "seals.txt").write_text(f"{len(seals)}\n")
        (out / "seal_exp.hex").write_text("".join("100\n" if v == DONTCARE else f"{v:03x}\n"
                                                  for s in seals for v in s["data"]) or "100\n")
        stats = dict(sfb_rd=0, sfb_wr=0, op_wr=0, ob_rd=0)
        for it in self.items:
            if it[0] == "D" and it[2]["code"] == 0:
                dd = it[1]
                sw = len(word_list(dd.src, dd.sstride, dd.row_len, dd.rows, self.cfg.WB))
                dw = len(word_list(dd.dst, dd.dstride, dd.row_len, dd.rows, self.cfg.WB))
                if dd.kind == K_STORE:
                    stats["ob_rd"] += sw
                    stats["sfb_wr"] += dw
                else:
                    stats["sfb_rd"] += sw
                    stats["op_wr"] += dw
        meta = dict(stage=stage, tags=list(tags), parts=self.parts, n_desc=self.next_id, n_seals=len(seals),
                    check_perf=(not self.injected and self.parts == 1), perf=res.perf, stats=stats,
                    plus=plus or {}, **self.meta)
        (out / "meta.json").write_text(json.dumps(meta, indent=1))
        return meta


# =================================================================== test catalogue
def r_geom(rng, cfg: HwCfg, set_bytes: int, max_rows=16, max_len=64):
    """Random 2-D geometry whose local footprint fits in set_bytes."""
    for _ in range(1000):
        rows = rng.randint(1, max_rows)
        ln = rng.randint(1, max_len)
        lstride = ln + rng.choice([0, 0, 1, 2, 3, 5, 8, 13])
        loff = rng.randrange(0, 16)
        if loff + (rows - 1) * lstride + ln <= set_bytes:
            return rows, ln, loff, lstride
    return 1, 1, 0, 1


def ext_region(rng, cfg: HwCfg, rows, ln, stride, lo=0, hi=None):
    hi = cfg.MEM_BYTES if hi is None else hi
    span = (rows - 1) * stride + ln
    return cfg.MEM_BASE + rng.randrange(lo, max(lo + 1, hi - span))


def t_single(cfg, seed):
    p = Prog(cfg, seed)
    p.load_set(a=dict(src=p.ea(0x100), dst=0, len=64), b=dict(src=p.ea(0x200), dst=0, len=16))
    p.load_set(a=dict(src=p.ea(0x301), dst=3, len=5), b=dict(src=p.ea(0x402), dst=1, len=7))
    p.tile()
    p.store_tile(p.ea(0x800), 16, rows=1, cols=4)
    return p


def t_lengths_load(cfg, seed):
    p = Prog(cfg, seed)
    n = 0
    for ln in range(1, 3 * cfg.WB + 2):
        for sa in range(cfg.WB):
            for da in range(cfg.WB):
                if n >= 250:
                    break
                kind = K_LOAD_A if (n % 2 == 0) else K_LOAD_B
                seal = F_SEAL if (n % 8 == 7) else 0
                p.d(kind, p.ea(0x1000 + 64 * n + sa), (n % 8) * 32 + da, ln, flags=seal)
                n += 1
    if n % 8:
        p.d(K_LOAD_B, p.ea(0x40), 0, 1, flags=F_SEAL)
    return p


def t_lengths_store(cfg, seed):
    p = Prog(cfg, seed)
    lens = [1, 2, 3, 4, 5, 7, 8, 9, 13, 16, 17, 31, 32, 33, 47, 64]
    n = 0
    for ln in lens:
        for da in range(4):
            if n >= 60:
                break
            p.tile()
            sa = (ln + da) % 4
            if sa + ln > 64:
                sa = 0
            p.d(K_STORE, sa, p.ea(0x2000 + 96 * n + da), ln, flags=F_SEAL)
            n += 1
    return p


def t_long_1d(cfg, seed):
    p = Prog(cfg, seed)
    p.load_set(a=dict(src=p.ea(0x1003), dst=0, len=cfg.ASB), b=dict(src=p.ea(0x5001), dst=0, len=cfg.BSB))
    p.load_set(a=dict(src=p.ea(0x9002), dst=1, len=cfg.ASB - 1), b=dict(src=p.ea(0xC000), dst=2, len=cfg.BSB - 2))
    p.tile()
    p.store_tile(p.ea(0xE000), 16)
    return p


def t_multirow(cfg, seed):
    p = Prog(cfg, seed)
    rng = p.rng
    for _ in range(6):
        rows, ln, loff, ls = r_geom(rng, cfg, cfg.ASB, 16, 40)
        ss = ln + rng.randint(0, 40)
        a = dict(src=ext_region(rng, cfg, rows, ln, ss), dst=loff, len=ln, rows=rows, sstride=ss, dstride=ls)
        rows, ln, loff, ls = r_geom(rng, cfg, cfg.BSB, 16, 40)
        ss = ln + rng.randint(0, 40)
        b = dict(src=ext_region(rng, cfg, rows, ln, ss), dst=loff, len=ln, rows=rows, sstride=ss, dstride=ls)
        p.load_set(a=a, b=b)
    for i in range(4):
        p.tile()
        ldc = 16 + 4 * rng.randint(0, 8) + rng.choice([0, 1, 2, 3])
        p.store_tile(p.ea(0x8000 + 0x400 * i + rng.randrange(4)), ldc)
    return p


def t_partial(cfg, seed):
    """Row lengths that are not word multiples, odd strides, every source/destination residue."""
    p = Prog(cfg, seed)
    rng = p.rng
    k = 0
    for ln in (1, 3, 5, 6, 7, 9, 11, 29):
        for res in range(cfg.WB):
            rows = rng.randint(2, 6)
            ss = ln + rng.choice([1, 3, 5, 7, 8, 13])
            ds = ln + rng.choice([0, 1, 2, 3])
            dst = (k * 7 + res) % 32
            if dst + (rows - 1) * ds + ln > cfg.ASB:
                dst = res
            kind = K_LOAD_A if k % 2 == 0 else K_LOAD_B
            p.d(kind, p.ea(0x400 + 0x100 * k + res), dst, ln, rows, ss, ds, flags=F_SEAL if k % 4 == 3 else 0)
            k += 1
    if k % 4:
        p.d(K_LOAD_B, p.ea(0x10), 0, 1, flags=F_SEAL)
    for i in range(6):
        p.tile()
        cols = 4
        ldc = 4 * cols + rng.choice([1, 2, 3, 5, 9])        # misaligned C rows
        p.d(K_STORE, rng.choice([0, 1, 2, 3]), p.ea(0xA000 + 0x300 * i + rng.randrange(4)), 13, 4, 16, ldc, flags=F_SEAL)
    return p


def t_src_overlap(cfg, seed):
    p = Prog(cfg, seed)
    p.load_set(a=dict(src=p.ea(0x700), dst=0, len=12, rows=8, sstride=0, dstride=12),          # broadcast a row
               b=dict(src=p.ea(0x900), dst=5, len=20, rows=10, sstride=3, dstride=21))        # overlapping rows
    p.load_set(a=dict(src=p.ea(0x705), dst=2, len=7, rows=16, sstride=1, dstride=8),
               b=dict(src=p.ea(0x903), dst=0, len=4, rows=5, sstride=0, dstride=4))
    p.tile()
    p.d(K_STORE, 4, p.ea(0xB001), 8, 6, 0, 9, flags=F_SEAL)                              # broadcast from the tile
    return p


def random_program(p: Prog, n_desc: int, store_frac=0.3, fence_frac=0.0, overlap=False):
    cfg, rng = p.cfg, p.rng
    lo_half = cfg.MEM_BYTES // 2
    ld_hi = cfg.MEM_BYTES if overlap else lo_half
    st_lo = lo_half if not overlap else lo_half - 0x800
    sealed_tiles = 0
    tiles = 0
    for i in range(n_desc):
        if rng.random() < store_frac:
            if tiles <= sealed_tiles:
                p.tile(rows=rng.randint(1, 4), cols=rng.randint(1, 4))
                tiles += 1
            rows = rng.randint(1, 4)
            ln = rng.randint(1, 16)
            ss = rng.choice([16, ln, ln + 1, 0 if rows == 1 else 16])
            src = rng.randrange(0, 4)
            if src + (rows - 1) * ss + ln > cfg.OSB:
                src, ss = 0, 16
            ds = ln + rng.randint(0, 9)
            seal = rng.random() < 0.6
            dst = ext_region(rng, cfg, rows, ln, ds, lo=st_lo, hi=st_lo + 0x1000 if overlap else None)
            p.d(K_STORE, src, dst, ln, rows, ss, ds,
                flags=(F_SEAL if seal else 0) | (F_FENCE if rng.random() < fence_frac else 0))
            if seal:
                sealed_tiles += 1
        else:
            kind = rng.choice([K_LOAD_A, K_LOAD_B])
            rows, ln, loff, ls = r_geom(rng, cfg, cfg.ASB if kind == K_LOAD_A else cfg.BSB, 12, 48)
            ss = rng.choice([ln, ln + rng.randint(1, 30), rng.randint(0, ln)])
            src = (ext_region(rng, cfg, rows, ln, ss, lo=st_lo, hi=st_lo + 0x1000) if overlap and rng.random() < 0.5
                   else ext_region(rng, cfg, rows, ln, ss, hi=ld_hi))
            p.d(kind, src, loff, ln, rows, ss, ls,
                flags=(F_SEAL if rng.random() < 0.35 else 0) | (F_FENCE if rng.random() < fence_frac else 0))
    # close an open drain session and an open fill session
    if tiles > sealed_tiles:
        p.d(K_STORE, 0, p.ea(lo_half + 0x10), 4, flags=F_SEAL)
    p.d(K_LOAD_B, p.ea(0x20), 0, 4, flags=F_SEAL)


def t_random(cfg, seed, n=60, fence=0.0, overlap=False):
    p = Prog(cfg, seed)
    random_program(p, n, fence_frac=fence, overlap=overlap)
    return p


def t_long_2d(cfg, seed):
    p = Prog(cfg, seed)
    rows = cfg.ASB // 32
    p.load_set(a=dict(src=p.ea(0x10), dst=0, len=31, rows=rows, sstride=97, dstride=32),
               b=dict(src=p.ea(0x6003), dst=1, len=cfg.BSB // 16 - 1, rows=16, sstride=cfg.BSB // 16 + 5,
                      dstride=cfg.BSB // 16))
    p.tile()
    p.store_tile(p.ea(0xF000), 16 + 64)
    return p


def t_invalid(cfg, seed):
    p = Prog(cfg, seed)
    A, B, S = K_LOAD_A, K_LOAD_B, K_STORE
    hi = cfg.MEM_HI
    p.d(A, p.ea(0), 0, 4, ver=VERSION + 1)                         # RSVD: version
    p.d(3, p.ea(0), 0, 4)                                          # RSVD: kind 3
    p.d(A, p.ea(0), 0, 4, flags=1 << 3)                            # RSVD: reserved flag
    p.d(A, p.ea(0), 0, 4, rsvd=1)                                  # RSVD: reserved byte
    p.d(A, p.ea(0), 0, 0)                                          # ZERO: length
    p.d(B, p.ea(0), 0, 4, rows=0)                                  # ZERO: rows
    p.d(A, p.ea(0), 0, 8, rows=2, dstride=7)                       # DST_ROWS
    p.d(S, 0, p.ea(0), 8, rows=2, sstride=16, dstride=4)           # DST_ROWS (store)
    p.d(A, 0xFFFF_FFF0, 0, 32)                                     # EXT_OVF
    p.d(A, p.ea(0x100), 0, 16, rows=0xFFFF, sstride=0x10_0000, dstride=16)  # EXT_OVF via rows*stride
    p.d(A, cfg.MEM_BASE - 4, 0, 8)                                 # EXT_RANGE low
    p.d(B, hi - 3, 0, 4)                                           # EXT_RANGE high
    p.d(S, 0, hi - 2, 4)                                           # EXT_RANGE (store)
    p.d(A, p.ea(0), cfg.ASB - 3, 4)                                # LOC_RANGE A
    p.d(B, p.ea(0), 0, 8, rows=cfg.BSB // 8 + 1, sstride=8, dstride=8)  # LOC_RANGE B
    p.d(S, cfg.OSB - 1, p.ea(0), 2)                                # LOC_RANGE output
    # valid descriptors interleaved: they must be unaffected
    p.load_set(a=dict(src=p.ea(0x300), dst=0, len=16), b=dict(src=p.ea(0x400), dst=0, len=16))
    p.d(A, p.ea(0), 0, 4, ver=0)                                   # RSVD again, between valid ones
    p.tile()
    p.store_tile(p.ea(0x900), 16)
    return p


def t_err(cfg, seed, kind):
    p = Prog(cfg, seed)
    p.load_set(a=dict(src=p.ea(0x100), dst=0, len=24, rows=3, sstride=40, dstride=24),
               b=dict(src=p.ea(0x300), dst=4, len=9, rows=4, sstride=11, dstride=12))
    p.tile()
    p.store_tile(p.ea(0x2000), 20)
    if kind == "RD":
        p.inject("RD", p.ea(0x1010) & ~(cfg.WB - 1))
        p.d(K_LOAD_A, p.ea(0x1001), 0, 40, rows=2, sstride=64, dstride=40)          # word 0x1010 -> RD_BUS
        p.d(K_LOAD_A, p.ea(0x1800), 0, 40, rows=2, sstride=64, dstride=40)          # retry, other source
        p.d(K_LOAD_B, p.ea(0x1900), 0, 16, flags=F_SEAL)
    elif kind == "WR":
        p.tile()
        p.inject("WR", p.ea(0x3044) & ~(cfg.WB - 1))
        p.d(K_STORE, 0, p.ea(0x3001), 16, 4, 16, 0x40, flags=F_SEAL)               # row 1 hits 0x3044 -> WR_BUS
        p.d(K_STORE, 0, p.ea(0x3801), 16, 4, 16, 0x40, flags=F_SEAL)               # retry: same drain set
    elif kind in ("OPERR", "OPTAG"):
        n0 = p.ref.fill_writes
        p.inject(kind, n0 + 5)
        p.d(K_LOAD_A, p.ea(0x1100), 2, 60, rows=2, sstride=70, dstride=64)          # 6th fill write fails
        p.d(K_LOAD_A, p.ea(0x1100), 2, 60, rows=2, sstride=70, dstride=64)          # retry into the open set
        p.d(K_LOAD_B, p.ea(0x1300), 0, 8, flags=F_SEAL)
    elif kind == "OBERR":
        p.tile()
        n0 = p.ref.ob_reads
        p.inject("OBERR", n0 + 3)
        p.d(K_STORE, 0, p.ea(0x3400), 16, 4, 16, 32, flags=F_SEAL)                 # 4th output read fails
        p.d(K_STORE, 0, p.ea(0x3400), 16, 4, 16, 32, flags=F_SEAL)                 # retry
    p.load_set(a=dict(src=p.ea(0x500), dst=0, len=32), b=dict(src=p.ea(0x600), dst=0, len=16))
    p.tile()
    p.store_tile(p.ea(0x4000), 16)
    return p


def t_dbuf(cfg, seed, tiles=8):
    """Tile pipeline: load A and B of tile t into a set, store tile t; with prefetch the next set fills
    while compute holds the current one."""
    p = Prog(cfg, seed)
    rng = p.rng
    for t in range(tiles):
        p.load_set(a=dict(src=p.ea(0x100 + 0x200 * t + t % 4), dst=t % 3, len=48, rows=4, sstride=50, dstride=49),
                   b=dict(src=p.ea(0x2000 + 0x200 * t), dst=1, len=4, rows=48, sstride=5, dstride=4))
        p.tile()
        p.store_tile(p.ea(0x8000 + 0x100 * t + rng.randrange(4)), 20)
    return p


def t_hazard_raw(cfg, seed):
    """STORE to X is submitted before its tile exists; a younger LOAD from X must wait for it (RAW), a younger
    LOAD from a disjoint Y may run ahead."""
    p = Prog(cfg, seed)
    X = p.ea(0x6000)
    p.tile(delay=400)                                                              # produced late
    p.d(K_STORE, 0, X, 64, flags=F_SEAL, rows=1, sstride=0, dstride=64)            # waits for the tile
    p.d(K_LOAD_A, p.ea(0x1000), 0, 32)                                             # disjoint: may overtake
    p.d(K_LOAD_B, p.ea(0x1100), 0, 32, flags=F_SEAL)
    p.d(K_LOAD_A, X + 3, 0, 40)                                                    # overlaps X: must wait
    p.d(K_LOAD_B, X + 8, 0, 16, flags=F_SEAL)
    p.meta["expect_dep_wait"] = True
    return p


def t_hazard_war(cfg, seed):
    """A LOAD from X waits for a FREE operand set (compute holds both); a younger STORE to X must not
    overwrite X before the LOAD has read it (WAR)."""
    p = Prog(cfg, seed)
    X = p.ea(0x6000)
    for i in range(cfg.NS):
        p.load_set(a=dict(src=p.ea(0x100 * i), dst=0, len=16), b=dict(src=p.ea(0x80 + 0x100 * i), dst=0, len=16))
    p.d(K_LOAD_A, X, 0, 64)                                                        # waits for a FREE set
    p.d(K_LOAD_B, X + 64, 0, 32, flags=F_SEAL)
    p.tile()
    p.d(K_STORE, 0, X + 16, 64, flags=F_SEAL)                                      # overlaps X: must wait
    p.meta["expect_dep_wait"] = True
    return p


def t_fence(cfg, seed):
    p = Prog(cfg, seed)
    random_program(p, 40, fence_frac=0.3)
    return p


def t_reset(cfg, seed):
    p = Prog(cfg, seed)
    la = min(200, cfg.ASB // 4)
    for t in range(3):
        p.load_set(a=dict(src=p.ea(0x100 + 0x400 * t), dst=0, len=la, rows=4, sstride=211, dstride=la),
                   b=dict(src=p.ea(0x3000 + 0x400 * t), dst=0, len=min(64, cfg.BSB // 8), rows=8, sstride=70,
                          dstride=min(64, cfg.BSB // 8)))
        p.tile()
        p.store_tile(p.ea(0x8000 + 0x100 * t), 24)
    p.reset()
    # part 2 reads only regions part 1 never wrote
    for t in range(3):
        p.load_set(a=dict(src=p.ea(0x2000 + 0x100 * t + 1), dst=3, len=33, rows=3, sstride=40, dstride=36),
                   b=dict(src=p.ea(0x4800 + 0x80 * t), dst=0, len=12, rows=6, sstride=13, dstride=12))
        p.tile()
        p.store_tile(p.ea(0xA000 + 0x100 * t + 2), 21)
    return p


def t_contention(cfg, seed):
    """Output buffer: the writer fills tile t+1 while the DMA drains tile t from the same scratchpad banks."""
    p = Prog(cfg, seed)
    for t in range(10):
        p.tile()
    for t in range(10):
        p.store_tile(p.ea(0x4000 + 0x100 * t), 16)
    p.meta["expect_ob_conflict"] = True
    return p


# name -> (stage, builder, plusargs, tags)
def catalogue(cfg: HwCfg):
    T = []
    T += [("s1_single", 1, t_single, {}), ("s1_lengths_load", 1, t_lengths_load, {}),
          ("s1_lengths_store", 1, t_lengths_store, {}), ("s1_long_1d", 1, t_long_1d, {})]
    T += [("s2_multirow", 2, t_multirow, {}), ("s2_partial", 2, t_partial, {}),
          ("s2_src_overlap", 2, t_src_overlap, {}), ("s2_long_2d", 2, t_long_2d, {}),
          ("s2_random", 2, t_random, {}),
          ("s2_random_bp", 2, t_random, dict(bp=40, lat_min=1, lat_max=12, cpl_bp=30, gap=3)),
          ("s2_random_xbar", 2, t_random, dict(xbar=1, lat_min=1, lat_max=4)),
          ("s2_invalid", 2, t_invalid, {}),
          ("s2_err_rd", 2, lambda c, s: t_err(c, s, "RD"), dict(lat_min=1, lat_max=6)),
          ("s2_err_wr", 2, lambda c, s: t_err(c, s, "WR"), dict(lat_min=1, lat_max=6)),
          ("s2_err_loc_wr", 2, lambda c, s: t_err(c, s, "OPERR"), {}),
          ("s2_err_loc_rd", 2, lambda c, s: t_err(c, s, "OBERR"), {}),
          ("s2_err_proto", 2, lambda c, s: t_err(c, s, "OPTAG"), {}),
          ("s2_writecpl", 2, t_random, dict(lat_min=8, lat_max=24))]
    for pf in (0, 1):
        m = f"pf{pf}"
        T += [(f"s3_dbuf_{m}", 3, t_dbuf, dict(prefetch=pf, cons_hold=60, cons_dly=2)),
              (f"s3_dbuf_bp_{m}", 3, t_dbuf, dict(prefetch=pf, cons_hold=30, bp=30, lat_min=1, lat_max=8)),
              (f"s3_hazard_raw_{m}", 3, t_hazard_raw, dict(prefetch=pf)),
              (f"s3_hazard_war_{m}", 3, t_hazard_war, dict(prefetch=pf, cons_hold=400)),
              (f"s3_fence_{m}", 3, t_fence, dict(prefetch=pf, lat_min=1, lat_max=6)),
              (f"s3_reset_{m}", 3, t_reset, dict(prefetch=pf, rst_delay=150, lat_min=2, lat_max=6)),
              (f"s3_contention_{m}", 3, t_contention, dict(prefetch=pf, prod_gap=0)),
              (f"s3_mix_{m}", 3, lambda c, s: t_random(c, s, n=120, overlap=True), dict(prefetch=pf, bp=20, lat_min=1, lat_max=10,
                                                                          cons_hold=20, cpl_bp=10))]
    return T


def generate(cfg: HwCfg, outdir: Path, seed: int = 1, stages=(1, 2, 3)):
    metas = {}
    for name, stage, fn, plus in catalogue(cfg):
        if stage not in stages:
            continue
        s = seed * 1000 + sum(map(ord, name))
        p = fn(cfg, s)
        pl = dict(plus)
        pl.setdefault("prefetch", 0)
        pl["parts"] = p.parts
        metas[name] = p.write(outdir / name, plus=pl, stage=stage)
    return metas


if __name__ == "__main__":
    import sys
    m = generate(HwCfg(), Path(sys.argv[1] if len(sys.argv) > 1 else "build/tests"))
    print(f"{len(m)} tests")
