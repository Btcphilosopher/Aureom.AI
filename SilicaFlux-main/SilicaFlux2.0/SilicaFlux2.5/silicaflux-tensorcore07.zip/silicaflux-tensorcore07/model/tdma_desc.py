"""Python mirror of the tensor DMA descriptor ABI (rtl/tdma_defs.svh).

Independent of the RTL: scripts/check_abi.py parses tdma_defs.svh and checks that
every field position and every constant below matches.  Use pack() to build the
192-bit descriptor a host writes (six little-endian 32-bit words).
"""
from __future__ import annotations

from dataclasses import dataclass

DESC_W = 192
VERSION = 0x07

# field: (lsb, width)
FIELDS = {
    "SRC": (0, 32), "DST": (32, 32), "SSTRIDE": (64, 32), "DSTRIDE": (96, 32),
    "ROWLEN": (128, 16), "ROWS": (144, 16), "ID": (160, 8), "KIND": (168, 2),
    "FLAGS": (170, 6), "RSVD": (176, 8), "VER": (184, 8),
}

K_LOAD_A, K_LOAD_B, K_STORE, K_RSVD = 0, 1, 2, 3
F_SEAL, F_FENCE = 1 << 0, 1 << 1
F_RSVD_MASK = 0b111100

CODES = {
    "OK": 0, "RSVD": 1, "ZERO": 2, "DST_ROWS": 3, "EXT_OVF": 4, "EXT_RANGE": 5, "LOC_RANGE": 6,
    "RD_BUS": 7, "WR_BUS": 8, "LOC_RD": 9, "LOC_WR": 10, "PROTO": 11,
}
CODE_NAMES = {v: k for k, v in CODES.items()}

BS = {"FREE": 0, "FILLING": 1, "READY": 2, "IN_USE": 3}

PC_NAMES = ["ACTIVE", "RD_BYTES", "WR_BYTES", "RD_REQ", "WR_REQ", "STALL", "SFB_STALL", "LOC_STALL",
            "OUT_SUM", "OUT_MAX", "BUF_WAIT", "DEP_WAIT", "XFER_ERR", "DESC_OK", "OVERLAP", "CPL_STALL",
            "LD_BUSY", "ST_BUSY"]


@dataclass
class Desc:
    kind: int
    src: int
    dst: int
    row_len: int
    rows: int = 1
    sstride: int = 0
    dstride: int = 0
    id: int = 0
    flags: int = 0
    ver: int = VERSION
    rsvd: int = 0

    @property
    def seal(self) -> bool:
        return bool(self.flags & F_SEAL)

    @property
    def fence(self) -> bool:
        return bool(self.flags & F_FENCE)

    def pack(self) -> int:
        v = 0
        for name, val in (("SRC", self.src), ("DST", self.dst), ("SSTRIDE", self.sstride),
                          ("DSTRIDE", self.dstride), ("ROWLEN", self.row_len), ("ROWS", self.rows),
                          ("ID", self.id), ("KIND", self.kind), ("FLAGS", self.flags),
                          ("RSVD", self.rsvd), ("VER", self.ver)):
            lsb, w = FIELDS[name]
            v |= (val & ((1 << w) - 1)) << lsb
        return v

    def words(self) -> list[int]:
        v = self.pack()
        return [(v >> (32 * i)) & 0xFFFF_FFFF for i in range(6)]


def unpack(v: int) -> Desc:
    f = {n: (v >> lsb) & ((1 << w) - 1) for n, (lsb, w) in FIELDS.items()}
    return Desc(kind=f["KIND"], src=f["SRC"], dst=f["DST"], row_len=f["ROWLEN"], rows=f["ROWS"],
                sstride=f["SSTRIDE"], dstride=f["DSTRIDE"], id=f["ID"], flags=f["FLAGS"], ver=f["VER"],
                rsvd=f["RSVD"])
