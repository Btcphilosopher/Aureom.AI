"""Independent reference model of the tensor DMA adapter (program-order semantics).

Plain Python integers and lists; no code is shared with the RTL.  Given a hardware
configuration and a test program it computes

  * the completion record of every descriptor (code, bytes, error address, detail),
  * the final external memory image (exact bytes, or don't-care where a failed or
    reset-interrupted transfer may or may not have written),
  * the content of every operand set at the moment it becomes READY (one snapshot per
    SEAL), which the testbench compares when the compute model takes the set,
  * the expected performance counters of an error-free run.

Semantics checked against the hardware:
  - descriptors take effect in SUBMISSION ORDER as far as external memory is concerned
    (the adapter's dependency checker must make concurrent channels indistinguishable
    from sequential execution);
  - operand fill sessions alternate over NUM_SETS sets (TC03 strict alternation); one
    session = consecutive LOAD descriptors up to and including a successful SEAL;
  - output tiles are written into output sets in production order (strict alternation);
    drain session n (STORE descriptors up to a successful SEAL) reads tile n;
  - neither set kind is ever cleared, so bytes not written by the current session keep
    their older content (or are unknown);
  - an error never changes ownership: a failed SEAL descriptor leaves the session open.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from tdma_desc import CODES, K_LOAD_A, K_LOAD_B, K_RSVD, K_STORE, VERSION, F_RSVD_MASK, Desc

DONTCARE = -1


@dataclass
class HwCfg:
    WB: int = 4
    NS: int = 2               # TC03 operand sets
    ASB: int = 1024
    BSB: int = 1024
    OS: int = 2               # output sets
    OSB: int = 256
    TILE_M: int = 4
    TILE_N: int = 4
    O_LD: int = 16
    MEM_BASE: int = 0x1000_0000
    MEM_BYTES: int = 1 << 16

    @property
    def REGION(self) -> int:
        return max(self.NS * self.ASB, self.NS * self.BSB)

    @property
    def MEM_LO(self) -> int:
        return self.MEM_BASE

    @property
    def MEM_HI(self) -> int:
        return self.MEM_BASE + self.MEM_BYTES


# ------------------------------------------------------------------ geometry helpers
def row_starts(base: int, stride: int, rows: int) -> list[int]:
    return [base + r * stride for r in range(rows)]


def word_list(base: int, stride: int, length: int, rows: int, wb: int) -> list[tuple[int, int, int]]:
    """(word_address, lo_lane, hi_lane) in issue order."""
    out = []
    for s in row_starts(base, stride, rows):
        first, last = s // wb, (s + length - 1) // wb
        for w in range(first, last + 1):
            lo = s % wb if w == first else 0
            hi = (s + length - 1) % wb if w == last else wb - 1
            out.append((w * wb, lo, hi))
    return out


def byte_list(base: int, stride: int, length: int, rows: int) -> list[int]:
    return [s + i for s in row_starts(base, stride, rows) for i in range(length)]


# ------------------------------------------------------------------ validation (docs/02 §3)
def validate(cfg: HwCfg, d: Desc) -> int:
    if d.ver != VERSION or d.kind == K_RSVD or (d.flags & F_RSVD_MASK) or d.rsvd:
        return CODES["RSVD"]
    if d.row_len == 0 or d.rows == 0:
        return CODES["ZERO"]
    if d.rows > 1 and d.dstride < d.row_len:
        return CODES["DST_ROWS"]
    store = d.kind == K_STORE
    ext_b, ext_s = (d.dst, d.dstride) if store else (d.src, d.sstride)
    loc_b, loc_s = (d.src, d.sstride) if store else (d.dst, d.dstride)
    ext_last = ext_b + (d.rows - 1) * ext_s + d.row_len - 1
    loc_last = loc_b + (d.rows - 1) * loc_s + d.row_len - 1
    if ext_last >= 1 << 32:
        return CODES["EXT_OVF"]
    if ext_b < cfg.MEM_LO or ext_last >= cfg.MEM_HI:
        return CODES["EXT_RANGE"]
    set_bytes = {K_LOAD_A: cfg.ASB, K_LOAD_B: cfg.BSB, K_STORE: cfg.OSB}[d.kind]
    if loc_last >= set_bytes:
        return CODES["LOC_RANGE"]
    return CODES["OK"]


def ext_footprint(d: Desc) -> tuple[int, int]:
    b, s = (d.dst, d.dstride) if d.kind == K_STORE else (d.src, d.sstride)
    return b, b + (d.rows - 1) * s + d.row_len - 1


# ------------------------------------------------------------------ program items
@dataclass
class Tile:
    tag: int
    rows: int
    cols: int
    data: list[list[int]]      # rows x cols INT32 (unsigned 32-bit)


@dataclass
class Result:
    cpl: list = field(default_factory=list)      # per descriptor: dict(id, code, bytes|None, err_addr|None, detail|None, part)
    mem_init: list = field(default_factory=list)
    mem_exp: list = field(default_factory=list)  # int byte or DONTCARE
    seals: list = field(default_factory=list)    # per checked seal: list of A+B region bytes (int or DONTCARE)
    perf: dict = field(default_factory=dict)
    n_fill_sessions: int = 0


class Ref:
    def __init__(self, cfg: HwCfg, mem_init: list[int]):
        self.cfg = cfg
        self.mem = list(mem_init)                 # current byte values (int or DONTCARE)
        self.res = Result(mem_init=list(mem_init))
        self.reset_models()
        self.inject = None                        # (kind, arg)
        self._part_store_bytes: list[int] = []    # external bytes a STORE of the current part may write
        self.part = 1
        self.perf = dict(RD_BYTES=0, WR_BYTES=0, RD_REQ=0, WR_REQ=0, DESC_OK=0, XFER_ERR=0)

    def reset_models(self):
        c = self.cfg
        self.opA = [[DONTCARE] * c.ASB for _ in range(c.NS)]
        self.opB = [[DONTCARE] * c.BSB for _ in range(c.NS)]
        self.fill_set = 0
        self.ob = [[DONTCARE] * c.OSB for _ in range(c.OS)]
        self.tiles: list[Tile] = []
        self.drain_session = 0
        self.drain_open = False
        self.fill_writes = 0                      # TC03 fill responses since reset
        self.ob_reads = 0                         # output-buffer read responses since reset

    # ------------------------------------------------------------ memory access
    def _mi(self, a: int) -> int:
        return a - self.cfg.MEM_BASE

    def rd(self, a: int) -> int:
        return self.mem[self._mi(a)]

    def wr(self, a: int, v: int):
        self.mem[self._mi(a)] = v

    # ------------------------------------------------------------ program items
    def tile(self, t: Tile):
        self.tiles.append(t)

    def reset(self):
        """Hardware reset after part 1: every effect of part 1 on memory is uncertain."""
        for i, c in enumerate(self.res.cpl):
            if c["part"] == self.part:
                c["optional"] = True
        for a in self._part_store_bytes:
            self.wr(a, DONTCARE)
        self._part_store_bytes = []
        self.part += 1
        self.reset_models()
        self.inject = None

    def set_injection(self, kind: str, arg: int):
        self.inject = (kind, arg)

    def desc(self, d: Desc):
        cfg = self.cfg
        code = validate(cfg, d)
        rec = dict(id=d.id, code=code, bytes=0, err_addr=0, detail=0, part=self.part, optional=False, kind=d.kind)
        self.res.cpl.append(rec)
        if code != 0:
            self.perf["XFER_ERR"] += 1
            return
        if d.kind == K_STORE:
            self._store(d, rec)
        else:
            self._load(d, rec)
        if rec["code"] == 0:
            self.perf["DESC_OK"] += 1
        else:
            self.perf["XFER_ERR"] += 1

    # ------------------------------------------------------------ LOAD_A / LOAD_B
    def _load(self, d: Desc, rec: dict):
        cfg = self.cfg
        s = self.fill_set
        region = self.opA[s] if d.kind == K_LOAD_A else self.opB[s]
        win_base = (s * cfg.ASB) if d.kind == K_LOAD_A else (cfg.REGION + s * cfg.BSB)
        src_words = word_list(d.src, d.sstride, d.row_len, d.rows, cfg.WB)
        dst_words = word_list(d.dst, d.dstride, d.row_len, d.rows, cfg.WB)
        fail = None
        if self.inject and self.inject[0] == "RD":
            for (w, _, _) in src_words:
                if w == self.inject[1]:
                    fail = ("RD_BUS", w, 0)
                    break
        n = self.inject[1] if self.inject else 0
        if fail is None and self.inject and self.inject[0] in ("OPERR", "OPTAG"):
            if self.fill_writes <= n < self.fill_writes + len(dst_words):
                w = dst_words[n - self.fill_writes][0]
                fail = ("LOC_WR", win_base + w, 6) if self.inject[0] == "OPERR" else ("PROTO", win_base + w, 0)
        srcb = byte_list(d.src, d.sstride, d.row_len, d.rows)
        dstb = byte_list(d.dst, d.dstride, d.row_len, d.rows)
        if fail is None:
            for a, o in zip(srcb, dstb):
                region[o] = self.rd(a)
            self.fill_writes += len(dst_words)
            rec["bytes"] = len(dstb)
            self.perf["RD_BYTES"] += len(srcb)
            self.perf["WR_BYTES"] += len(dstb)
            self.perf["RD_REQ"] += len(src_words)
            self.perf["WR_REQ"] += len(dst_words)
            if d.seal:
                self.res.seals.append(dict(part=self.part, data=list(self.opA[s]) + list(self.opB[s]), set=s))
                self.res.n_fill_sessions += 1
                self.fill_set = (s + 1) % cfg.NS
        else:
            name, addr, det = fail
            rec.update(code=CODES[name], bytes=None, err_addr=addr, detail=det)
            if name in ("LOC_WR", "PROTO"):          # the n-th write fails: the OK prefix is every write before it
                k = n - self.fill_writes
                rec["bytes"] = sum(hi - lo + 1 for (_, lo, hi) in dst_words[:k])
            for o in dstb:
                region[o] = DONTCARE
            self.inject = None if name != "RD_BUS" else self.inject   # RD stays armed for that word
            if name != "RD_BUS":
                self.fill_writes = 1 << 60                            # one injection per test

    # ------------------------------------------------------------ STORE
    def _store(self, d: Desc, rec: dict):
        cfg = self.cfg
        n = self.drain_session
        s = n % cfg.OS
        if not self.drain_open:
            if n >= len(self.tiles):
                raise ValueError(f"store {d.id}: drain session {n} has no tile")
            t = self.tiles[n]
            for r in range(t.rows):
                for j in range(t.cols):
                    off = r * cfg.O_LD + 4 * j
                    v = t.data[r][j]
                    for b in range(4):
                        self.ob[s][off + b] = (v >> (8 * b)) & 0xFF
            self.drain_open = True
        srcb = byte_list(d.src, d.sstride, d.row_len, d.rows)
        dstb = byte_list(d.dst, d.dstride, d.row_len, d.rows)
        src_words = word_list(d.src, d.sstride, d.row_len, d.rows, cfg.WB)
        dst_words = word_list(d.dst, d.dstride, d.row_len, d.rows, cfg.WB)
        fail = None
        if self.inject and self.inject[0] == "WR":
            for (w, _, _) in dst_words:
                if w == self.inject[1]:
                    fail = ("WR_BUS", w, 0)
                    break
        if fail is None and self.inject and self.inject[0] == "OBERR":
            k = self.inject[1]
            if self.ob_reads <= k < self.ob_reads + len(src_words):
                fail = ("LOC_RD", s * cfg.OSB + src_words[k - self.ob_reads][0], 4)
        self._part_store_bytes.extend(dstb)
        if fail is None:
            for a, o in zip(dstb, srcb):
                self.wr(a, self.ob[s][o])
            self.ob_reads += len(src_words)
            rec["bytes"] = len(dstb)
            self.perf["RD_BYTES"] += len(srcb)
            self.perf["WR_BYTES"] += len(dstb)
            self.perf["RD_REQ"] += len(src_words)
            self.perf["WR_REQ"] += len(dst_words)
            if d.seal:
                self.drain_session += 1
                self.drain_open = False
        else:
            name, addr, det = fail
            rec.update(code=CODES[name], bytes=None, err_addr=addr, detail=det)
            if name == "WR_BUS":                     # first write to the failing word: OK prefix before it
                k = next(i for i, (w, _, _) in enumerate(dst_words) if w == addr)
                rec["bytes"] = sum(hi - lo + 1 for (_, lo, hi) in dst_words[:k])
            for a in dstb:
                self.wr(a, DONTCARE)
            if name == "LOC_RD":
                self.inject = None
                self.ob_reads = 1 << 60

    # ------------------------------------------------------------ results
    def finish(self) -> Result:
        self.res.mem_exp = list(self.mem)
        self.res.perf = dict(self.perf)
        return self.res
