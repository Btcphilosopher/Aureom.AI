"""Programs for tb_tdma_xbar: the tensor DMA on the real DataFabric crossbar under contention.

Memory map (one contiguous 48 KiB window starting at MEM_BASE, three crossbar slaves):
  SRAM0 [ 0K,16K)  tensor LOAD_A sources [0K,8K)  | other-DMA copy source [8K,12K) | CPU private [12K,16K)
  SRAM1 [16K,32K)  tensor STORE targets [16K,20K) | other-DMA copy target [20K,24K) | vector master [24K,32K)
  TSPM  [32K,48K)  tensor LOAD_B sources [32K,36K)| CPU private [36K,40K)          | vector lanes [40K,48K)
The tensor program's expectations come from the DMA reference model; the other-DMA copy target is exact
(= initial source bytes); regions owned by the self-checking CPU / vector generators are don't-care.
"""
from __future__ import annotations

import json
from pathlib import Path

from gen_tests import Prog
from tdma_desc import F_SEAL, K_LOAD_A, K_LOAD_B, K_STORE
from tdma_ref import DONTCARE, HwCfg

K = 1024
XCFG = HwCfg(MEM_BASE=0x1000_0000, MEM_BYTES=48 * K)
COPY_SRC, COPY_DST, COPY_LEN = 8 * K, 20 * K, 4 * K


def xbar_program(out: Path, seed: int, n=60, plus=None):
    p = Prog(XCFG, seed)
    rng, cfg = p.rng, XCFG
    tiles = sealed = 0
    for i in range(n):
        r = rng.random()
        if r < 0.3:
            if tiles <= sealed:
                p.tile(rows=rng.randint(1, 4), cols=rng.randint(1, 4))
                tiles += 1
            rows, ln = rng.randint(1, 4), rng.randint(1, 16)
            ds = ln + rng.randint(0, 9)
            dst = p.ea(16 * K + rng.randrange(0, 4 * K - (rows - 1) * ds - ln))
            seal = rng.random() < 0.6
            p.d(K_STORE, rng.randrange(4), dst, ln, rows, 16, ds, flags=F_SEAL if seal else 0)
            sealed += seal
        else:
            a = r < 0.65
            rows, ln = rng.randint(1, 12), rng.randint(1, 48)
            ss = ln + rng.randint(0, 20)
            ls = ln + rng.randint(0, 5)
            lo, hi = (0, 8 * K) if a else (32 * K, 36 * K)
            src = p.ea(lo + rng.randrange(0, hi - lo - (rows - 1) * ss - ln))
            dst = rng.randrange(0, 8)
            if dst + (rows - 1) * ls + ln > cfg.ASB:
                rows = 1
            p.d(K_LOAD_A if a else K_LOAD_B, src, dst, ln, rows, ss, ls, flags=F_SEAL if rng.random() < 0.35 else 0)
    if tiles > sealed:
        p.d(K_STORE, 0, p.ea(16 * K + 0x10), 4, flags=F_SEAL)
    p.d(K_LOAD_B, p.ea(32 * K), 0, 4, flags=F_SEAL)
    res = p.ref.finish()
    exp = res.mem_exp
    for i in range(COPY_LEN):
        exp[COPY_DST + i] = res.mem_init[COPY_SRC + i]
    for lo, hi in ((12 * K, 16 * K), (24 * K, 32 * K), (36 * K, 40 * K), (40 * K, 48 * K)):
        for i in range(lo, hi):
            exp[i] = DONTCARE
    p.ref.finish = lambda: res              # Prog.write() re-reads the (patched) result
    meta = p.write(out, plus=plus or {}, stage=5)
    meta.update(copy=dict(src=XCFG.MEM_BASE + COPY_SRC, dst=XCFG.MEM_BASE + COPY_DST, len=COPY_LEN))
    (out / "meta.json").write_text(json.dumps(meta, indent=1))
    return meta
