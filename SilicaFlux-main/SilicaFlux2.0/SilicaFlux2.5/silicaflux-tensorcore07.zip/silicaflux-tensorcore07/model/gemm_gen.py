"""Tiled GEMM programs for tb_tdma_gemm: C[M,N] (INT32) = A[M,K] x B[K,N] (INT8), row-major, byte strides.

Every operand block and result tile moves through the tensor DMA adapter: per step (tile m0,n0, chunk k0)
  LOAD_A  eff_m rows x kc bytes   src a + m0*lda + k0, stride lda   -> A region, stride lda_loc
  LOAD_B  kc rows x eff_n bytes   src b + k0*ldb + n0, stride ldb   -> B region, stride 4      (SEAL)
  job     the compute sequencer runs chunk c of the tile on that set
and after the last chunk of a tile
  STORE   eff_m rows x 4*eff_n bytes from the output set (pitch O_LD) -> C + m0*ldc + 4*n0, stride ldc (SEAL)
The expected C comes from a plain-Python integer matmul over the initial memory; the DMA reference model
independently derives the expected final memory from the STORE descriptors.
"""
from __future__ import annotations

import json
from pathlib import Path

from gen_tests import Prog
from tdma_desc import F_SEAL, K_LOAD_A, K_LOAD_B, K_STORE
from tdma_ref import HwCfg


def s8(v: int) -> int:
    return v - 256 if v >= 128 else v


def gemm(cfg: HwCfg, out: Path, M, N, K, KC=64, lda=None, ldb=None, ldc=None, a_off=0x100, b_off=None, c_off=None,
         order="m", seed=1, plus=None, tm=4, tn=4):
    lda = K if lda is None else lda
    ldb = N if ldb is None else ldb
    ldc = 4 * N if ldc is None else ldc
    b_off = a_off + M * lda + 0x40 + 3 if b_off is None else b_off
    c_off = (b_off + K * ldb + 0x80) & ~3 if c_off is None else c_off
    assert c_off + M * ldc <= cfg.MEM_BYTES, "matrices do not fit in the memory model"
    p = Prog(cfg, seed)
    p.wrap_ids = True
    mem = p.ref.mem
    a, b, c = p.ea(a_off), p.ea(b_off), p.ea(c_off)

    def A(m, k):
        return s8(mem[a_off + m * lda + k])

    def B(k, n):
        return s8(mem[b_off + k * ldb + n])

    tiles = [(m0, n0) for m0 in range(0, M, tm) for n0 in range(0, N, tn)]
    if order == "n":
        tiles = [(m0, n0) for n0 in range(0, N, tn) for m0 in range(0, M, tm)]
    nch = (K + KC - 1) // KC
    jobs, macs = [], 0
    for ti, (m0, n0) in enumerate(tiles):
        em, en = min(tm, M - m0), min(tn, N - n0)
        for ci in range(nch):
            k0 = ci * KC
            kc = min(KC, K - k0)
            lda_loc = (kc + 3) & ~3
            if lda_loc % 8 == 0:
                lda_loc += 4                       # odd word stride: A rows start in different TC03 banks
            p.d(K_LOAD_A, a + m0 * lda + k0, 0, kc, em, lda, lda_loc)
            p.d(K_LOAD_B, b + k0 * ldb + n0, 0, en, kc, ldb, 4, flags=F_SEAL)
            jobs.append([ti & 0xFFFF, em, en, kc, K, nch, ci, 0, lda_loc, 0, 4])
            macs += em * en * kc
        data = [[sum(A(m0 + r, k) * B(k, n0 + j) for k in range(K)) & 0xFFFF_FFFF for j in range(en)] for r in range(em)]
        p.tile(rows=em, cols=en, data=data)        # what the compute path must produce (T lines ignored by the TB)
        p.d(K_STORE, 0, c + m0 * ldc + 4 * n0, 4 * en, em, cfg.O_LD, ldc, flags=F_SEAL)
    meta = p.write(out, plus=plus or {}, stage=4)
    (out / "jobs.txt").write_text("".join(" ".join(f"{v:x}" for v in j) + "\n" for j in jobs))
    # independent check: the DMA reference's final C equals the plain matmul
    exp = p.ref.res.mem_exp
    for m in range(M):
        for n in range(N):
            v = sum(A(m, k) * B(k, n) for k in range(K)) & 0xFFFF_FFFF
            got = sum(exp[c_off + m * ldc + 4 * n + i] << (8 * i) for i in range(4))
            assert got == v, (m, n)
    meta.update(M=M, N=N, K=K, KC=KC, tiles=len(tiles), chunks=nch, jobs=len(jobs), macs=macs, order=order)
    (out / "meta.json").write_text(json.dumps(meta, indent=1))
    return meta
