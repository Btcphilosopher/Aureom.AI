# 00 — Repository audit

Scope: every existing block the tensor data-movement subsystem has to reuse or connect to. Sources are the archives
in `btcphilosopher/Aureom.AI` under `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. Nothing was assumed: each
block was read, elaborated and (where it is used) simulated here with the same tools as the earlier modules
(Icarus Verilog 12, Verilator 5.020, Yosys 0.33). As a toolchain check, TENSORCORE 06's own `make quick` was
re-run unchanged in this environment: 18 / 18 runs pass.

## 1. Summary

| Block | Archive | What it is | Used here | How |
|---|---|---|---|---|
| SFB2 bus protocol | `silicaflux-datafabric.zip` (`PROTOCOL.md` rev 2.0) | valid/ready request + response, one beat per transaction, no IDs, in-order, R1–R12 | **yes — the external interface** | the adapter is an SFB2 master; `sfb_protocol_checker` (unmodified) on every link in every test |
| DataFabric crossbar | same (`sfb_crossbar` + decoder, arbiter, mux, router, error slave) | N×M crossbar, round robin / fixed priority, grant lock, one transaction per port (R6) | **yes — arbitration is reused, not re-invented** | contention test: the adapter is master 3 of the real crossbar |
| DataFabric DMA | same (`silicaflux_dma`, `dma_transfer_engine`, `dma_burst_engine`) | 1-D memory-to-memory copy, DW-aligned src/dst only | engines **not** used for tensor tiles (§5); `dma_burst_engine` used unmodified as the "other DMA engine" in the contention test | |
| `dma_fifo` | same | flop FIFO | **yes** — queues, outstanding FIFOs, completion FIFO, gate pending FIFO | unmodified |
| SRAM slave | same (`sfb_sram_slave`) | SFB2 slave on the SRAM Wrapper Library | yes, as real memory in the contention test | unmodified |
| HPC DMA adapter | `silicaflux-hpc-m05-dma-adapter.zip` | wraps the DataFabric engines for the HPC tile: tagged 1-D descriptors, SPM/fabric router | **protocol and conventions reused**, engine not (§5) | completion = all writes acknowledged; codes 1..7 numbering style; queue/credit rules A1–A6 |
| Scratchpad | `silicaflux-hpc-m04-scratchpad.zip` (`hpc_scratchpad`) | banked multi-port SRAM, Module 04 port protocol H1–H7 | **yes, twice**: the storage of the new tensor output buffer, and the TSPM slave in the contention test | unmodified |
| TC03 operand buffer | `silicaflux-tensorcore03.zip` (`tensor_operand_buffer`) | double-buffered A/B sets, write-only fill port (Module 04 protocol), ownership EMPTY→FILL→READY→COMPUTE | **yes — the A / B destination**; its `tob_dbuf_ctrl` is also reused for the output buffer | unmodified |
| TC02 systolic array | `silicaflux-tensorcore02.zip` | output-stationary array, one tile per launch | yes, in the end-to-end GEMM integration | unmodified |
| TC04 accumulator | `silicaflux-tensorcore04.zip` (`tensor_acc_subsystem`) | K-chunk accumulation, commit rows on `osram` / `oquant` / `odma` streams | yes; its `osram` stream feeds the output buffer | unmodified |
| TC06 tile controller | `silicaflux-tensorcore06.zip` | GEMM scheduler with an **embedded** SFB2 tile mover (`ttc_loader`, `ttc_store`, `ttc_sfb_master`) | design reference and performance baseline | not copied (§6) |
| SRAM Wrapper Library | via the archives above | backends for TC03, M04, DataFabric slaves | yes | unmodified |

Every reused file is byte-identical to its archive (`third_party/SHA256SUMS`, `third_party/PROVENANCE.md`). The
SRAM-library files embedded in the DataFabric, TC03 and M04 archives were compared and are identical, so one copy
serves all of them. The TC02/TC03/TC04 files are identical to the copies TC06 vendored.

## 2. The actual bus protocol (SFB2, DataFabric `PROTOCOL.md` rev 2.0)

The rules the adapter is built on (§3 of doc 03 shows where each is met):

| # | Rule | Consequence for the adapter |
|---|---|---|
| R1 | transfer on `valid && ready` | — |
| R2 | a presented request is held, payload unchanged, until accepted; no withdrawal | request register in `tdma_sfb_port`; checked by a monitor (and killed mutant M16) |
| R3 | `req_valid` must not depend on `req_ready` | `req_valid` is a flop |
| R4 | `rsp_ready` must not depend on `req_ready` | `rsp_ready = 1` (credits) |
| R5 | exactly one response per accepted request, in order | outstanding FIFO routes each response to its channel |
| R6 | the crossbar carries at most one transaction per master port | `MAX_OUT >= 2` lets the next request wait in the register (measured, doc 08) |
| R7 | a write response is issued only after the write was performed | **completion is built on write responses** |
| R8 | error response: data 0, write has no side effect | error propagation (doc 03 §5) |
| R9 | addresses are DW-aligned | the AGUs emit word addresses only; byte granularity is in the strobes |
| R10 | one beat per transaction; any strobe pattern; reads return the whole word | partial words via strobes; no word without a transfer byte is read |
| R11 | reset cancels everything | async reset of every flop; no request during reset (checked) |

There is **no burst, no ID and no AXI concept** in SFB2, and none was introduced.

## 3. Local buffer interfaces (Module 04 port protocol)

`hpc_scratchpad` requester ports and TC03's fill port (`tob_dma_port`) speak the same protocol: request
`valid/ready, we, addr (bytes), wdata, wstrb, tag`; response `valid/ready, rdata, err, err_code[2:0], we, tag`;
exactly one response per request in order; a write is acknowledged only after it is in the array (`WRITE_ACK = 1`;
TC03 by construction). TC03's fill port is **write-only** (reads → UNSUP), word-granular, and refuses writes to a
set that is not in FILL (OWNER, no side effect). Its window: A region `[0, NS·A_SET)`, B region from
`REGION = max(NS·A_SET, NS·B_SET)`.

## 4. Operand-buffer ownership (TC03 `tob_dbuf_ctrl`)

Four commands, each accepted only when its precondition holds (ready is a combinational function of the state):
`fill_begin` (EMPTY→FILL), `fill_end` (FILL→READY, requires the fill port idle), `cmp_begin` (READY→COMPUTE),
`cmp_end` (COMPUTE→EMPTY, requires the operand engine drained). Sets are used in strict alternation. **TC03 already
enforces in hardware** that compute cannot start on a set that is not READY and that the DMA cannot write a set
that is not in FILL. The brief's names map 1:1: FREE = EMPTY, FILLING = FILL, READY, IN_USE = COMPUTE
(`tdma_defs.svh` uses the same encoding).

## 5. Why a new data-movement engine, and why it is not "a second incompatible DMA subsystem"

Existing engines and what a tensor transfer needs:

| Need | DataFabric `dma_*_engine` / M05 `hpc_dma_adapter` | TC06 embedded mover |
|---|---|---|
| 2-D strided transfer (rows × length, two strides) | no — 1-D; one descriptor per row (M05: 4 cycles set-up + completion each) | yes, but only for its own A/B/C tile shapes |
| byte-addressed rows at arbitrary alignment (`lda = 29`, unaligned bases) | **no — `SRC_ALIGN` / `DST_ALIGN` reject them**; no byte shifter | only same-residue placement (dst offset ≡ src offset mod 4), dictated by the mover itself |
| independent src / dst alignment (e.g. pack a misaligned row densely) | no | no |
| TC03 fill port as destination, with set ownership | no (scratchpad / fabric only) | yes |
| output-buffer source with ownership | no | no (writes C straight from TC04's stream) |
| descriptor interface with ID, completion status and error status | yes (1-D) | no (one GEMM command) |
| baseline throughput | 1 B/cycle (simple), 1.6–4 B/cycle (buffered) | ~1 word/cycle |

A "verified sequence of 1-D transfers" on the existing engines is therefore **impossible for INT8 tensors**
(unaligned rows are rejected), and TC06's mover is not a reusable DMA (no descriptors, no completion records,
geometry fixed by its scheduler). The new adapter is **compatible** with everything that exists:

* the same SFB2 master protocol and rules (it sits on the same crossbar port type as `silicaflux_dma`);
* the same Module 04 requester protocol toward the buffers (TC03 and `hpc_scratchpad` unchanged);
* the same completion semantics as M05 ("completion = every write acknowledged by its target");
* the same queue / credit discipline (descriptor and completion queues, credits so responses are never refused);
* the same counter and error style, the same RTL coding rules (flat ports, `define headers, no packages in
  synthesizable code, sized literals);
* the same ownership state machine (TC03's `tob_dbuf_ctrl`, reused unmodified for the output side as well).

## 6. The output buffer

No addressable tensor output buffer existed: TC04 delivers committed rows as valid/ready streams
(`osram_*` / `oquant_*` / `odma_*`), and TC06 wrote them straight to memory. The brief's "tensor output buffer to
external memory" direction therefore needs one. `tensor_output_buffer` is built from existing parts only plus two
small new pieces: storage = `hpc_scratchpad` (M04, unmodified), ownership = `tob_dbuf_ctrl` (TC03, unmodified),
new = `tout_gate` (hardware ownership check on each port) and the row writer (TC04 `osram` beats → word writes).

## 7. Consequences for the design

1. One SFB2 master port for all external traffic; arbitration with CPU, vector and other DMA masters is the
   DataFabric crossbar's (round robin by default, proven bounded waiting in DataFabric's formal report).
2. Byte realignment is required (independent src/dst residues): `tdma_realign`.
3. Completion must wait for write acknowledgements on both target kinds (SFB2 R7; TC03 / Module 04 write acks).
4. Ownership is reused, not duplicated: the coordinator only decides when the DMA side issues `fill_begin` /
   `fill_end` (operands) and `rd_begin` / `rd_end` (results); TC03 and `tob_dbuf_ctrl` remain the single source of
   truth.
5. Memory dependencies between concurrently running load and store channels must be tracked (doc 04 §4), because
   prefetch lets a younger load run before an older store has finished.
