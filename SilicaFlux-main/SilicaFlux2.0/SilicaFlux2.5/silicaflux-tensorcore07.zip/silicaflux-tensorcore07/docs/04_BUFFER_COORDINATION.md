# 04 — Double-buffer coordination, prefetch and memory dependencies

## 1. Buffer states

Two bits per set, the same encoding everywhere (`tdma_defs.svh` = TC03 `tob_defs.svh`):

| State | Operand set (TC03) | Output set (`tensor_output_buffer`) |
|---|---|---|
| `FREE` (0) | empty: nobody owns it | empty: nobody owns it |
| `FILLING` (1) | **owned by the DMA**: fill writes allowed, compute refused | **owned by compute** (TC04 row writer) |
| `READY` (2) | completely written, waiting for compute | complete tile, waiting for the DMA |
| `IN_USE` (3) | **owned by compute**: tiles read it, DMA writes refused (OWNER) | **owned by the DMA**: STORE reads it |

```
operand set:  FREE ─fill_begin(DMA)─► FILLING ─fill_end(DMA, all writes acked)─► READY ─cmp_begin(compute)─► IN_USE ─cmp_end(compute, drained)─► FREE
output set:   FREE ─(writer, first row)─► FILLING ─(writer, last row acked)─► READY ─rd_begin(DMA)─► IN_USE ─rd_end(DMA, all writes acked)─► FREE
```

Both state machines are the **unmodified TC03 `tob_dbuf_ctrl`** (one inside TC03, one inside the output buffer).
Its readies are combinational functions of the state, transitions happen only on handshakes, sets are used in
strict alternation, and every command waits (never dropped) while its precondition is false.

## 2. The two rules of the brief, and who enforces them

**"A buffer cannot be overwritten until its compute consumer releases it."**
* Operand set: the DMA opens a set only with `fill_begin`, which TC03 accepts only on a FREE set; a FREE set is
  produced only by `cmp_end` from compute. In addition TC03's fill port refuses any write to a set not in FILLING
  (OWNER, no side effect) — hardware enforcement independent of the adapter. TB check: every TC03 write the adapter
  presents targets a FILLING set.
* Output set: the row writer acquires a set only when it is FREE (it waits otherwise — `ev_wr_wait`), and the
  `tout_gate` on the writer port refuses writes to a set not in FILLING. A FREE output set is produced only by
  `rd_end` from the DMA, after every write of the draining STORE is acknowledged. `tb_tout` step 7 checks that a
  third tile is held back while set 0 is still IN_USE and that set 0 still holds its tile.

**"A compute operation cannot read a buffer until the required DMA transfer has completed."**
* Operand set: compute's `cmp_begin` is accepted only on READY; READY is produced only by the adapter's `fill_end`,
  which it issues only after **every write of the SEAL descriptor (and of all earlier descriptors of the set) has
  been acknowledged by TC03**. TB check: at every `cmp_begin`, the whole set (A and B regions) is compared byte for
  byte with the reference snapshot of that seal — a partially written set would fail.
* Output side (dual): the DMA's `rd_begin` is accepted only on READY, i.e. after the writer has had every row of the
  tile acknowledged; the `tout_gate` on the DMA port refuses reads of a set not IN_USE (`tb_tout` steps 1, 3).

## 3. Who issues what (`tdma_buf_coord`)

| Channel step | Condition | Command |
|---|---|---|
| LOAD acquire | fill set FILLING (continuation, e.g. B after A) | — go |
| | fill set FREE **and policy allows** | `fill_begin` |
| | fill set READY / IN_USE | wait (`BUF_WAIT`) |
| LOAD seal | `SEAL` and the transfer completed OK | `fill_end` |
| STORE acquire | drain set IN_USE (continuation) | — go |
| | drain set READY | `rd_begin` |
| | drain set FREE / FILLING | wait (`BUF_WAIT`): compute has not finished the tile |
| STORE seal | `SEAL` and completed OK | `rd_end` |

A failed transfer never seals: the set stays FILLING / IN_USE and the host may retry into it.

## 4. Prefetch, sequential fallback, and memory dependencies

`cfg_prefetch` selects the mode (change it only while the adapter is idle).

**SEQUENTIAL (0) — fallback.**
* One descriptor at a time, globally in submission order (every descriptor is implicitly FENCEd: it starts only
  after every older descriptor of either channel has produced its completion record).
* An operand fill starts only when compute holds no operand set (no set READY or IN_USE): load → compute → store
  never overlap. Measured: `OVERLAP = 0` in every SEQUENTIAL run (checked), mutant M07 killed.

**PREFETCH (1) — next-tile prefetch.**
* The fill of the next operand set starts as soon as that set is FREE, i.e. while compute still owns the other set
  (TC03 strict alternation bounds it to one tile ahead with two sets).
* The load and store channels run concurrently on the shared SFB2 port.
* **Memory dependencies.** Each descriptor gets a sequence number at intake. A channel's head descriptor waits
  (`DEP_WAIT`) while any **older** descriptor of the **other** channel that is still pending (queued or active) has
  an **overlapping external footprint** (bounding interval `[lo, hi]` from validation):
  * load after an older store to overlapping memory (RAW) → the load waits until the store completed;
  * store after an older load from overlapping memory (WAR) → the store waits until the load completed;
  * same-channel order (WAW of stores, loads) is program order by construction.
  So external memory always behaves as if descriptors executed in submission order. `FENCE` forces "every older
  descriptor completed" for a single descriptor.
* Live data is never overwritten: prefetch can only open a FREE operand set (TC03 rule) — compute's IN_USE set is
  untouchable — and a STORE can only read an output set the writer has completed (READY → IN_USE).

Tests: `s3_hazard_raw_*` (the STORE to X is submitted first and its tile arrives 400 cycles late; a disjoint
load may overtake it, the loads that overlap X must wait and must see the stored data), `s3_hazard_war_*` (a
load from X is stuck waiting for a FREE set while a younger STORE to X is ready: the STORE must wait), `s3_mix_*`
(random mixes with overlapping footprints), `s3_fence_*`. Mutants M08 (dependencies ignored), M09 (active
descriptor ignored), M21 (queued descriptors ignored), M22 (age reversed), M10 / M11 (SEQUENTIAL / FENCE ignored)
are all killed.

## 5. Deadlock freedom (documented operating conditions)

Assumptions: every accepted request is eventually answered (SFB2 R5 / Module 04 H5); compute eventually releases
every set it takes; and **program order respects data flow**: the STORE of a tile is submitted after the LOADs
whose operands produce it.

* The response paths never wait (credits) → every outstanding transaction retires.
* A head descriptor waits only for (a) an older descriptor (dependency / fence) or (b) a buffer state. (a) cannot
  form a cycle: waits always point to strictly older descriptors. (b) operand sets are released by compute, output
  sets by the store channel; a store never waits for a load except by (a), i.e. for an older load, which in turn
  waits only for compute, which does not wait for the store channel. With the data-flow condition the wait graph is
  acyclic.
* Separate load and store queues remove the head-of-line case "store stuck behind a load that waits for a set that
  compute cannot release until its output set is drained".
* In SEQUENTIAL mode the oldest pending descriptor is always startable (its channel is idle), so the program
  advances one descriptor at a time.

Every test and integration run (≈ 1 300 runs, random timing) completes; the TBs have watchdogs.
