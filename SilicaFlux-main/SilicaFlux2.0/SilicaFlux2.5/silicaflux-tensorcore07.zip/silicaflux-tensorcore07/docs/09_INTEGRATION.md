# 09 — Integration guide

## 1. Wiring (`rtl/tdma_tile_system.sv` is the worked example)

| Adapter port group | Connect to | Notes |
|---|---|---|
| `req_*` / `rsp_*` (SFB2 master) | a DataFabric `sfb_crossbar` master port, or directly to an SFB2 slave | `DW = 8·WB`; legal window `MEM_LO`/`MEM_HI` = the memory the DMA may touch (e.g. SRAM + TSPM) |
| `op_req_*` / `op_rsp_*` | TC03 `dma_req_*` / `dma_rsp_*` | TC03 `WORD_BYTES = WB`, `DMA_BASE = OP_BASE` |
| `op_fill_begin/end_*`, `op_fill_set`, `op_set_state` | TC03 `fill_begin/end_*`, `fill_set`, `set_state` | the compute side keeps TC03's `cmp_begin/end` |
| `ob_req_*` / `ob_rsp_*` | `tensor_output_buffer` `d_req_*` / `d_rsp_*` | |
| `ob_rd_begin/end_*`, `ob_rd_set`, `ob_set_state` | `tensor_output_buffer` `rd_begin/end_*`, `rd_set`, `set_state` | |
| `tensor_output_buffer` `in_*` | TC04 `osram_valid/ready` + `o_row, o_col_mask, o_data, o_last, o_tag, o_err, o_ovf` | configure TC04 tiles with `cfg_dest = 3'b001` (output SRAM) |
| parameters | `NUM_SETS, A_SET_BYTES, B_SET_BYTES` = TC03's; `O_SETS, O_SET_BYTES` = the output buffer's | mismatches are a configuration error (the TB checks catch them; there is no cross-module elaboration check) |

As a DataFabric master, the adapter takes a crossbar port like `silicaflux_dma` (memory map: the tensor DMA would be
a new master in `memmap/silicaflux_v_datafabric.yaml`; its access matrix should allow SRAM and TSPM only, as the
existing DMA's does — MMIO side effects of the peripherals have not been reviewed for DMA access).

## 2. Host / scheduler programming sequence

1. Choose the mode: `cfg_prefetch = 1` for overlap (default use), `0` for the strictly sequential fallback.
2. For each operand set (tile step): `LOAD_A` (no flag) then `LOAD_B` with `SEAL`. Destination offsets and strides
   are the layout the compute side will be told (TC03 tile descriptor `a_addr / lda / b_addr / ldb`).
3. Give compute its job; compute's `cmp_begin` waits until the set is READY (i.e. the SEAL completed).
4. After the tile's last K chunk: `STORE` with `SEAL`, source = the tile layout inside the output set
   (`r·O_LD + 4·j`), destination = C with its own stride. The STORE waits until compute has written the tile.
5. Collect completion records (`cpl_*`, or `ev_cpl` / `ev_cpl_id` as an interrupt). A record with code 0 means the
   data is in place.

Ordering rule for deadlock freedom (doc 04 §5): submit a tile's STORE after the LOADs of the steps that produce it.
Use `FENCE` when a later descriptor must not even start before everything older has finished (e.g. software
re-uses a buffer region whose overlap the bounding-interval check cannot see, such as a different address alias of
the same memory).

## 3. Replacing TENSORCORE 06's embedded mover

TC06's controller already computes, per step, exactly the fields of the two LOAD descriptors and, per tile, the
STORE (doc 04 of TC06: `sA = a_base + m0·lda + k0`, rows of `eff_k`; `sB = b_base + k0·ldb + n0`, rows of `eff_n`;
`c_tile = c_base + m0·ldc + 4·n0`). The integration is:

| TC06 today | With the tensor DMA |
|---|---|
| `ttc_loader` issues word reads and TC03 fill writes, `fill_begin/fill_end` | emit `LOAD_A` + `LOAD_B (SEAL)` descriptors; the adapter owns `fill_begin/fill_end` |
| local placement restricted to the source residue mod 4 | any local layout (e.g. dense `lda_loc`, bank-friendly padding) |
| `ttc_store` writes C from TC04's `odma` stream | TC04 `cfg_dest = osram` → `tensor_output_buffer`; emit `STORE (SEAL)` per tile |
| `ttc_sfb_master` (own SFB2 port) | the adapter's SFB2 port |
| completion = all C writes acknowledged | per-descriptor completion records; the GEMM is done when the last STORE record arrives |

The scheduler logic (tile iteration, K chunks, TC04 slot management, reuse decisions) stays in TC06; the reference
`tdma_compute_seq` shows the compute-side handshakes needed. This replacement is **not done** in this module
(doc 10).

## 4. Module 06 command queue

The descriptor is six 32-bit words, so a Module 06 v2 command class (e.g. opcode class `0x5X` "tensor DMA") can
carry it unchanged: the queue's executor port would drive `desc_valid/desc_data` and return `cpl_*` as the
command's completion. Not implemented here.

## 5. Integration checklist

* Same clock, same reset for adapter, TC03, output buffer and fabric (asynchronous assert, synchronous release).
* `hpc_scratchpad` inside the output buffer must keep `QUEUE_DEPTH = 0` (ownership check and bank access at the same
  edge); this is fixed inside `tensor_output_buffer`.
* Crossbar arbitration: round robin on the slaves the DMA uses (doc 05).
* Behind the crossbar use `MAX_OUT ≥ 2` (R6).
* Matrices must live in ordinary memory: whole words are read (R10); bytes next to a row inside its first / last
  word are read and discarded, never written.
