# 01 — Architecture

```
   host / scheduler                                                     compute side (TC06 or tdma_compute_seq)
   192-bit descriptors        completion records {ID, kind, code, detail, err_addr, bytes}
        │                                ▲
┌───────▼────────────────────────────────┴──────────── tensor_dma_adapter ──────────────────────────────────┐
│ intake register ─► tdma_validate (rules, footprint) ─► seq no.                                             │
│        ├──► load queue  (tdma_queue, entries visible) ──► LOAD  channel FSM ──┐                            │
│        └──► store queue (tdma_queue, entries visible) ──► STORE channel FSM ──┤  dependency check:         │
│                                                                              │  age + ext. footprint      │
│        tdma_buf_coord: when to fill_begin / fill_end (TC03), rd_begin / rd_end (output buffer)             │
│                                                                                                           │
│  LOAD  tdma_channel:  rAGU ──rd──► tdma_sfb_port ──► SFB2     rr ─► tdma_realign ─► wAGU ──wr──► tdma_loc_port ─► TC03 fill port
│  STORE tdma_channel:  rAGU ──rd──► tdma_loc_port ─► OBUF      rr ─► tdma_realign ─► wAGU ──wr──► tdma_sfb_port ─► SFB2
│                                       (one SFB2 master port shared by both channels, round robin)          │
│  completion FIFO (dma_fifo) ◄── LOAD / STORE        tdma_perf (18 saturating counters)                     │
└───────────────────────────────────────────────────────────────────────────────────────────────────────────┘
        │ SFB2 master (DataFabric rev 2.0)          │ Module 04 port (write)         │ Module 04 port (read)
        ▼                                           ▼                                ▼
  DataFabric sfb_crossbar / memory      TC03 tensor_operand_buffer        tensor_output_buffer
  (round-robin arbitration with         (A/B sets, ownership in HW)       (M04 hpc_scratchpad + TC03 tob_dbuf_ctrl
   CPU, vector, other DMA masters)                                         + tout_gate + row writer) ◄─ TC04 osram rows
```

## Design principles

* **One protocol per side, both existing.** External: SFB2 master (the adapter can be a DataFabric crossbar master
  exactly like `silicaflux_dma`). Local: Module 04 requester (TC03 and `hpc_scratchpad` are unchanged).
* **Two channels.** Loads (external → operand buffer) and stores (output buffer → external) have separate queues
  and datapaths, so a store never waits behind a load that is waiting for a free operand set (no head-of-line
  deadlock between the directions). They share the SFB2 port. Within a channel, descriptors execute in submission
  order, one at a time.
* **Byte-accurate 2-D transfers with independent alignments.** Each side has its own 2-D address generator; a byte
  realigner between them turns "bytes of source rows in order" into "bytes of destination rows in order". No
  read-modify-write, no word without a transfer byte is ever read, partial words are strobed.
* **Completion = acknowledged.** A record is produced only after every destination write has been acknowledged
  (SFB2 R7, Module 04 / TC03 write acknowledgement) and, for SEAL descriptors, after the ownership hand-over.
* **Ownership is reused.** TC03's and the output buffer's `tob_dbuf_ctrl` are the single source of truth. The
  coordinator never keeps a copy of a set pointer.
* **Credits everywhere.** Every response is always accepted (`rsp_ready = 1`) because a credit was held before the
  request was issued: realigner bytes for reads, meta FIFOs for in-flight transactions, a completion-queue slot
  for every channel. Nothing waits on a response path, so nothing can deadlock behind it.

## Modules (new RTL)

| File | Role |
|---|---|
| `rtl/tensor_dma_adapter.sv` | **primary source**: intake, validation, queues, dependency check, channel FSMs, ports, coordinator, completion queue, counters |
| `rtl/tdma_defs.svh` | **2-D descriptor definition**, kinds, flags, completion codes, buffer states, counter indices (ABI) |
| `rtl/tdma_validate.sv` | validation rules (doc 02 §3), external footprint |
| `rtl/tdma_queue.sv` | descriptor queue with visible entries (for the dependency check) |
| `rtl/tdma_channel.sv` | one channel's datapath: 2 AGUs + realigner + credits + in-order tracking + error / prefix accounting |
| `rtl/tdma_agu.sv` | 2-D strided word-address generator with byte-lane ranges |
| `rtl/tdma_realign.sv` | byte realigner (circular byte FIFO, multi-byte push / pop) |
| `rtl/tdma_sfb_port.sv` | SFB2 master: request register, round robin, outstanding FIFO, response routing |
| `rtl/tdma_loc_port.sv` | Module 04 requester: request register, sequence tags, response tag / direction check |
| `rtl/tdma_buf_coord.sv` | **buffer coordination logic**: SEQUENTIAL / PREFETCH policy, DMA-side ownership commands |
| `rtl/tdma_perf.sv` | saturating counter bank (sum or high-water mark) |
| `rtl/tensor_output_buffer.sv` | tensor output buffer (M04 scratchpad + `tob_dbuf_ctrl` + gates + row writer) |
| `rtl/tout_gate.sv` | hardware ownership gate in front of a scratchpad port (in-order refusals) |
| `rtl/tdma_compute_seq.sv` | reference compute sequencer for the integration tests (jobs → TC03 / TC02 / TC04) |
| `rtl/tdma_tile_system.sv` | integration top: adapter + TC02 + TC03 + TC04 + output buffer + sequencer |

## Parameters (`tensor_dma_adapter`)

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `WB` | 4 | power of two ≥ 2 (tested 4, 8) | bytes per word: SFB2 DW = 8·WB = TC03 / output-buffer word |
| `NUM_SETS`, `A_SET_BYTES`, `B_SET_BYTES`, `OP_BASE` | 2, 512, 512, 0 | must equal TC03's | operand sets and fill window |
| `O_SETS`, `O_SET_BYTES`, `OB_BASE` | 2, 256, 0 | must equal the output buffer's | output sets |
| `MEM_LO`, `MEM_HI` | 0, 2³² | `MEM_LO < MEM_HI` | legal external window (EXT_RANGE) |
| `MAX_OUT` | 4 | 1, 2, 4, 8, 16 | SFB2 transactions in flight (1 = baseline, one at a time) |
| `LOC_OUT` | 4 | 1, 2, 4, 8, 16 | local-port transactions in flight |
| `RCAP` | 32 | power of two ≥ 2·WB | realigner bytes per channel (credit for reads in flight) |
| `QDEPTH` | 4 | power of two 2..16 | descriptors queued per channel |
| `CPL_DEPTH` | 4 | power of two ≥ 2 | completion records buffered |
| `TAG_W`, `CNT_W` | 8, 32 | | local tag width, counter width |

Every illegal value stops elaboration with a message from `tensor_dma_adapter` itself (12 negative tests,
`reports/lint.md`).

## Ports (`tensor_dma_adapter`)

| Group | Signals | Notes |
|---|---|---|
| control | `cfg_prefetch` | 0 SEQUENTIAL, 1 PREFETCH (change only while idle) |
| descriptor | `desc_valid/ready`, `desc_data[191:0]` | `desc_ready` = intake register free or draining (never depends on `desc_valid`) |
| completion | `cpl_valid/ready`, `cpl_id`, `cpl_kind`, `cpl_code`, `cpl_detail[2:0]`, `cpl_err_addr`, `cpl_bytes` | one per descriptor |
| SFB2 master | `req_*`, `rsp_*` | DataFabric PROTOCOL rev 2.0 |
| TC03 fill | `op_req_*`, `op_rsp_*`; `op_fill_begin/end_valid/ready`, `op_fill_set`, `op_set_state` | wire to TC03 `dma_*`, `fill_*`, `fill_set`, `set_state` |
| output buffer | `ob_req_*`, `ob_rsp_*`; `ob_rd_begin/end_valid/ready`, `ob_rd_set`, `ob_set_state` | wire to `tensor_output_buffer` `d_*`, `rd_*` |
| status | `busy`, `ld_state`, `st_state`, `ld_id`, `st_id`, `*_outstanding`, `ev_cpl`, `ev_cpl_id`, `ev_proto` | `ev_cpl` + `ev_cpl_id`: a descriptor finished (interrupt source) |
| counters | `perf_clear`, `perf_cnt[18·CNT_W]` | doc 06 |

## Clock and reset

One clock. Asynchronous active-low reset (as TC03, M04, DataFabric; TC04 and TC02 use synchronous reset and are
reset correctly by the same `rst_n` held for several cycles). Reset discards queued and active descriptors and
pending completion records; no request is presented during reset or afterwards until a new descriptor arrives
(tested: `s3_reset_*`, reset at a point where SFB2 transactions are in flight).
