# 05 — Arbitration, fairness and contention

## 1. Where arbitration happens (nothing new was invented)

| Contention | Arbiter | Policy | Source |
|---|---|---|---|
| tensor DMA vs CPU vs vector engine vs other DMA engines, per memory slave | DataFabric `sfb_crossbar` → `sfb_arbiter` (one per slave) | round robin (`ARB_MODE = 1`, SilicaFlux-V default), pointer moves past the winner on acceptance; grant lock under back-pressure; one transaction per port (R6) | DataFabric, unmodified; bounded waiting (≤ N−1 other acceptances) proven by DataFabric's formal run |
| tile scratchpad banks: vector lanes vs fabric port | Module 04 `hpc_spm_bank_arb` | round robin per bank | Module 04, unmodified |
| output buffer banks: TC04 row writer vs DMA reads | Module 04 `hpc_spm_bank_arb` inside `tensor_output_buffer` | round robin per bank (1RW: one access per bank per cycle) | Module 04, unmodified |
| TC03 banks: DMA fill writes vs compute slice reads | TC03 `tob_bank_arb` | compute first, writes forced after `WR_STARVE_LIMIT` = 8 cycles | TC03, unmodified |
| inside the adapter: load-channel reads vs store-channel writes on the one SFB2 port | `tdma_sfb_port` | round robin (alternates on a tie) | new, 2 requesters |
| completion records from the two channels | adapter | round robin | new |

The adapter is an ordinary SFB2 master: it needs no change to sit on a crossbar port, and it respects R6 (one
transaction in flight per crossbar port) without knowing about it — the crossbar simply does not accept the next
request until the previous response is accepted.

## 2. Starvation

* The adapter itself never starves either channel: two requesters, round robin, and every grant is followed by
  progress (credits are held before a request is issued, so a granted request is never stuck behind a full
  response buffer).
* On the fabric, with round robin the tensor DMA waits at most for the other masters' current transactions at the
  addressed slave. Measured on the real crossbar with all four masters active (`reports/xbar.md`): the tensor DMA's
  longest uninterrupted request wait is **3–5 cycles** with round robin, against **13 cycles** with fixed priority
  (tensor DMA lowest), which also loses arbitration 2–3× as often.
* **Documented operating condition:** round-robin arbitration (`ARB_MODE = 1`) on every slave the adapter uses. With
  fixed priority a lower-priority master can starve under sustained higher-priority traffic (DataFabric
  `benchmark.md` demonstrates it); the adapter would still be correct, only slower.
* Inside TC03, DMA fill writes are guaranteed to complete within `WR_STARVE_LIMIT` cycles of compute reads.
* Inside the output buffer and the tile scratchpad, round-robin bank arbitration bounds every port's wait.

## 3. The contention integration test (`tb/tb_tdma_xbar.sv`)

```
 master 0  CPU            random loads/stores (self-checking shadow) in SRAM0 12-16K and TSPM 36-40K;
                          also initialises all memory and finally reads it ALL back through the fabric
 master 1  vector stream  back-to-back writes then verifying reads, SRAM1 24-32K
 master 2  DataFabric dma_burst_engine (unmodified)   4 KiB copy SRAM0 8-12K -> SRAM1 20-24K, twice
 master 3  tensor_dma_adapter + TC03 + tensor_output_buffer   random 2-D LOAD_A (SRAM0), LOAD_B (TSPM), STORE (SRAM1)
 slaves    SRAM0, SRAM1 = sfb_sram_slave (unmodified)    TSPM = hpc_scratchpad, port 0 on the fabric,
           ports 1-2 = two vector lanes doing random self-checking accesses (bank contention with the DMA's reads)
```

Every run checks: the tensor completions (code, bytes) and every operand set against the reference; every
generator's own data; the copy; the **whole 48 KiB read back through the fabric** (no backdoor); the DataFabric
protocol checker on all four master links; no decode error; every master made progress. Sweep: round robin / fixed
priority × SRAM latency 1 / 2 × `MAX_OUT` 1 / 4 × normal / 100 % traffic × 3 programs × 2 seeds — results in
`reports/xbar.md`.

## 4. Scratchpad contention

* **Output buffer** (1RW banks, `NUM_BANKS` 1–2): the TC04 row writer filling tile t+1 and the DMA draining tile t
  hit the same banks; conflicts are counted (`s3_contention_*` requires them to be non-zero in the 2-set 1RW
  configurations) and results stay exact.
* **Tile scratchpad (TSPM)**: in the contention test the DMA's LOAD_B reads compete with two vector lanes for 4 banks
  (several hundred conflict cycles per run, `reports/xbar.md`).
* **TC03**: in the GEMM integration with 1RW TC03 banks (`stress` configuration) the DMA's fill writes compete with
  the array's slice reads of the other set (SHARED set map).
