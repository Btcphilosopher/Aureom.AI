# 10 — Known limitations and next actions

## 1. Evidence limits

* **Simulation only** (Verilator 5.020, Icarus 12), self-checking against an independent Python reference. No
  formal proof of the new RTL, no gate-level simulation, no FPGA or silicon run.
* **Synthesis is Yosys mapping only**: no place and route, no timing analysis, **no clock frequency claimed**. The
  validation stage holds two 16 × 32-bit multipliers and 64-bit adders in one combinational path from the intake
  register (4 DSP48 on xc7); the dependency check compares the queue heads against every pending entry in one cycle.
  Both are the most likely timing problems; both can be pipelined (one cycle each) without changing the ABI.
* Cycle counts are against testbench memory models (1–24-cycle latency, random back-pressure) and the real
  DataFabric crossbar + SRAM slave; a real SoC's numbers depend on its slaves.

## 2. Functional scope

| Limitation | Consequence | Next action |
|---|---|---|
| One descriptor at a time per channel; a descriptor completes (all writes acknowledged) before the next starts | ≈ 12 cycles per descriptor; 84 % of the port bound on 32 × 32 × 256 (TC06's embedded mover: 92 %) | pipeline descriptors inside a channel (doc 08 §5) |
| One SFB2 port for loads and stores | store writes take bandwidth from operand reads | optional second (write) port, as M05's dual-port engine |
| Dependency check uses bounding intervals of footprints | interleaved but disjoint 2-D footprints are serialised (conservative, never wrong) | exact row-interval test if it matters |
| Address aliases (two addresses for one memory location) are invisible to the dependency check | software must use `FENCE` in that case | — |
| No external→external or buffer→buffer kind | `KIND = 3` is reserved and rejected | add a COPY kind if a use appears |
| Output buffer: one tile per set, INT32 lanes, layout `r·O_LD + 4·j` (`O_LD` a parameter) | requantised (TC05) output is not stored yet | route TC05's output stream into a byte-lane writer; the DMA side is unchanged (it is byte-granular) |
| `tdma_compute_seq` is test infrastructure (one job at a time, no operand reuse, no K-major order) | the integration proves data movement, not scheduling efficiency | integrate the adapter into TC06's scheduler (doc 09 §3) |
| **TC06 not retrofitted**; Module 06 command queue not connected | the adapter is integrated with TC02 / TC03 / TC04 through the reference sequencer only | doc 09 §3 and §4 |
| No abort input | a running transfer stops only on error or reset | add an abort that drains like an error (beat boundary) |
| No watchdog | a target that never answers keeps the channel busy (visible in `ld_state` / `st_state`, `ACTIVE`, `*_outstanding`) — same choice as DataFabric's DMA | optional threshold register |
| Error recovery leaves ownership unchanged | the host must retry (or reset) to release a set after a failed SEAL descriptor | — (deliberate: no partially written set is ever handed over) |
| `cfg_prefetch` is not a per-descriptor property | changing it while busy is not defined | sample it per descriptor if needed |
| Parameter agreement between the adapter and TC03 / the output buffer is not checked at elaboration | a mismatch is a wiring error (tests would fail) | a wrapper that derives both from one parameter set (as `tdma_tile_system` does) |

## 3. Memory-side behaviour

* Reads are whole words (SFB2 R10). Bytes in a row's first / last word that are not part of the row are read and
  discarded (never written anywhere). Matrices must therefore live in ordinary memory, not next to read-sensitive
  registers; no word without a transfer byte is ever read (checked in every run).
* Misaligned rows can cost one extra word per row (e.g. 4-byte B rows at an unaligned base: 2 words each, measured
  +50 % B traffic).

## 4. Verification notes

* Three mutants survive and are analysed as equivalent (redundant interlocks): the local port's outstanding limit
  (the channel's own limit is the same), the read-error data gate (writes are already stopped by the error flag),
  and `fill_begin` on a non-FREE set (TC03 accepts it only on EMPTY). `reports/mutation.md`.
* Byte prefixes after **read-side** errors (`RD_BUS`, `LOC_RD`) depend on timing (how many writes were already
  issued) and are checked as a bound, not exactly; write-side errors are checked exactly.
* Reset tests check the post-reset program exactly; for the interrupted program they check that nothing outside its
  footprints changed and that no stale completion appears (its footprints are don't-care).
