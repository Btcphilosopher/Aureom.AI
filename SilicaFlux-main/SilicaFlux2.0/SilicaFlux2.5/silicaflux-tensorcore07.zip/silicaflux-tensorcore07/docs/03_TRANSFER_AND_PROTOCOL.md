# 03 — Transfer semantics and protocol correctness

## 1. One channel, step by step

```
start ─► rAGU: for each row r, words ⌊s_r/WB⌋ .. ⌊(s_r+L−1)/WB⌋ with lane range [lo, hi]   (s_r = SRC + r·SRC_STRIDE)
          │  issue a read only with credit: realigner bytes  count + reserved + n ≤ RCAP,  reads in flight < MAXR
          ▼
        read responses (in order) ─► realigner: append lanes [lo, lo+n) of the word, in order
          ▼
        wAGU: for each row r, words ⌊d_r/WB⌋ .. with lane range [lo', hi']                  (d_r = DST + r·DST_STRIDE)
          │  issue a write when the realigner holds its k = hi'−lo'+1 bytes, writes in flight < MAXW
          │  wdata = those k bytes placed at lanes [lo', hi'], wstrb = lanes [lo', hi']
          ▼
        write acknowledgements (in order) ─► bytes_ok += k (until the first write error)
done when every read has been answered, every write acknowledged, and every word moved (or an error stopped it)
```

The source side emits exactly the bytes of the source rows, in row order; the destination side consumes exactly
the bytes of the destination rows, in row order. Rows have the same length on both sides, so the byte streams are
identical and **source and destination alignment, stride and padding are fully independent**.

## 2. Row boundaries, partial tiles, non-contiguous rows, byte tails, alignment, capacity

| Requirement | How it is met | Tested by |
|---|---|---|
| Row boundaries | each AGU word belongs to exactly one row; `j == nw−1` closes the row, the next row starts at `s + stride` | every 2-D test; mutant M29 (stride +1) killed |
| Partial tiles | a tile is just `ROWS × ROW_LEN` (eff_m × kc, kc × eff_n, eff_m × 4·eff_n); no padding is read or written | `s2_partial`, GEMMs 5×7×3, 17×13×29, 37×1×5, 1×37×5 |
| Non-contiguous rows | strides are independent byte values; gaps are never read (no word without a row byte is emitted) | TB element map: every SFB2 read word must hold a source byte of the running descriptor |
| Byte tails | last word of a row: `hi = (s + L − 1) mod WB`; strobe covers only the row bytes | `s1_lengths_*` (every length 1..3·WB+1 × every src/dst residue); M04 (no tail mask) killed |
| Alignment | row start `lo = s mod WB`; the realigner shifts to the destination lanes | `s1_lengths_*`, `s2_partial`; M05 / M06 killed |
| Misaligned requests | the bus always sees word addresses (R9); misalignment is in lanes and strobes only | SFB2 R9 monitor in every run |
| Buffer capacity | validation: the whole local footprint must fit the set (`LOC_RANGE`) — a transfer can never spill into the other set | `s2_invalid`; M14 (off by one) killed |
| Long transfers | AGU counters 16-bit rows × 16-bit length, 32-bit addresses; tested up to a whole 1 KiB set in one descriptor, 32×31 and 256×4 2-D | `s1_long_1d`, `s2_long_2d`, perf sweep |
| Overlapping source rows / broadcast | allowed (read-only) | `s2_src_overlap` |

## 3. SFB2 protocol (master side, `tdma_sfb_port`)

| Rule | Implementation | Evidence |
|---|---|---|
| R1 handshake | `req_valid && req_ready` / `rsp_valid && rsp_ready` | DataFabric `sfb_protocol_checker` on the link in every run |
| R2 no withdrawal, stable payload | request register; loaded only when empty or accepted this cycle | TB R2 monitor; mutant M16 killed |
| R3 `req_valid` independent of `req_ready` | `req_valid` is a flop | by construction (Yosys `check -assert`: no combinational loop) |
| R4 response back-pressure | `rsp_ready = 1`; credits guarantee absorption | |
| R5 one response per request, in order | outstanding FIFO `{write, address}` per accepted request; response → owning channel | unsolicited-response assertion; M01 killed |
| R6 crossbar one-outstanding | nothing to do at the master; `MAX_OUT ≥ 2` keeps the next request waiting in the register | contention test on the real crossbar; doc 08 |
| R7 write completion | completion waits for every write response | `s2_writecpl` and every OK completion: each destination byte must have been **performed by that descriptor** before its record (the TB memory performs writes only when it responds, 8–24 cycles late) ; M02 killed |
| R8 errors | read error → data discarded, transfer stops; write error → transfer stops; codes RD_BUS / WR_BUS with the address | `s2_err_rd`, `s2_err_wr` |
| R9 alignment | word addresses only | TB monitor |
| R10 single beat, any strobe | one word per transaction; partial strobes for tails | |
| R11 reset | async reset of every flop; nothing presented during reset | TB check at every reset cycle |

The local ports (`tdma_loc_port`, Module 04 protocol) follow H1–H7 the same way: request register (H2), one
response per request in order (H5), and in addition every response's **tag and direction** are checked against the
oldest outstanding request; a mismatch becomes `PROTO` and its data is never used (`s2_err_proto`, M15 killed).

## 4. Outstanding transactions, buffering, back-pressure

* SFB2 port: up to `MAX_OUT` transactions granted and not answered (1 = baseline, one at a time).
* Each channel: up to `MAXR` reads and `MAXW` writes in flight (meta FIFOs hold `{lo, n}` per read and the byte
  count per write, so every response is matched to its request in order).
* Realigner: `RCAP` bytes; a read is issued only when its bytes fit (`count + reserved + n ≤ RCAP`), so read
  responses can always be absorbed — overflow is impossible (asserted; M17 killed by the assertion).
* Back-pressure: request side `req_ready` (bus) / `req_ready` (local port), held requests, no loss; response side
  never back-pressured. Completion back-pressure (`cpl_ready = 0`) stops a channel only in its CPL state, after the
  transfer: it never stalls a bus.
* Tested with random `req_ready` (30–40 %), random latency 1–24, R6 mode, random completion back-pressure, random
  compute-side holds (`s2_random_bp`, `s3_dbuf_bp_*`, `s3_mix_*`, GEMM `bp`).

## 5. Error propagation

| Event | Effect |
|---|---|
| validation failure | completion with the code; no side effect at all |
| SFB2 read error | `RD_BUS`, `err_addr` = word address; no data of that read is used; no further request; outstanding transactions drain |
| SFB2 write error | `WR_BUS`; the failed write had no side effect (R8); no further request |
| TC03 fill refusal | `LOC_WR` + TC03 code in `cpl_detail` |
| output-buffer refusal / parity | `LOC_RD` + code |
| local tag / direction mismatch | `PROTO` |
| any transfer error | `cpl_bytes` = acknowledged-OK prefix (exact, checked, for write-side failures); **ownership unchanged** (no `fill_end` / `rd_end`), so a retry into the same set is possible |

Errors are injected deterministically: memory-model error words, and fault injectors on the TC03 and output-buffer
response paths (n-th response: error code or flipped tag). Each injection test checks the code, the exact error
address, the exact byte prefix where it is deterministic, and that the retried transfer and everything after it
complete exactly.

## 6. Completion contract (what "done" means)

A completion record with code 0 for descriptor *d* means:

1. every destination byte of *d* has been written **and the write acknowledged** by its target, and each target
   acknowledges a write only after performing it (SFB2 R7; Module 04 `WRITE_ACK = 1`; TC03 acknowledges after the
   bank write) — so a consumer that waits for the record observes the data;
2. for `SEAL`: the ownership hand-over (`fill_end` → READY, or `rd_end` → FREE) has happened;
3. `cpl_bytes = ROW_LEN · ROWS`.

Verified per descriptor in every run: at the record, each destination byte's "last writer" in the TB memory model
(external) or in the TC03 shadow (operand window) must be *d* itself.
