# 06 — Performance counters

`perf_cnt` = 18 saturating counters of `CNT_W` bits (default 32), indices in `tdma_defs.svh`
(`TDMA_PC_*`, mirrored in `model/tdma_desc.py:PC_NAMES`). `perf_clear` zeroes them. Counters saturate at all-ones
and never wrap. `OUT_MAX` is a high-water mark; all others are sums.

| # | Name | Increment per cycle | Brief item |
|---|---|---|---|
| 0 | `ACTIVE` | 1 if a descriptor is in either channel (OPEN .. CPL) | DMA active cycles |
| 1 | `RD_BYTES` | descriptor bytes returned by reads without error (SFB2 for loads, output buffer for stores) | bytes read |
| 2 | `WR_BYTES` | descriptor bytes whose writes were acknowledged without error | bytes written |
| 3 | `RD_REQ` | read transactions accepted (SFB2 + output buffer) | — |
| 4 | `WR_REQ` | write transactions accepted (SFB2 + TC03 fill) | — |
| 5 | `STALL` | 1 if any port presents a request that is not accepted | DMA stall cycles |
| 6 | `SFB_STALL` | ... on the SFB2 port (fabric back-pressure / arbitration) | |
| 7 | `LOC_STALL` | ... on a local port (TC03 / output-buffer bank arbitration or credits) | |
| 8 | `OUT_SUM` | transactions in flight on all ports (average = `OUT_SUM / ACTIVE`) | outstanding requests |
| 9 | `OUT_MAX` | maximum of the same | outstanding requests |
| 10 | `BUF_WAIT` | channels waiting for buffer ownership (fill set not FREE, output set not READY, SEQUENTIAL policy) | buffer waiting cycles |
| 11 | `DEP_WAIT` | ready queue heads held by a memory dependency, a FENCE or SEQUENTIAL ordering | — |
| 12 | `XFER_ERR` | completion records with a non-zero code | transfer errors |
| 13 | `DESC_OK` | completion records with code 0 | — |
| 14 | `OVERLAP` | 1 if a TC03 fill write is accepted while an operand set is IN_USE (DMA running under compute) | (prefetch evidence) |
| 15 | `CPL_STALL` | 1 if a completion record waits for `cpl_ready` | — |
| 16 | `LD_BUSY` | 1 while the load channel is not idle | — |
| 17 | `ST_BUSY` | 1 while the store channel is not idle | — |

## How the counters are verified

For every error-free, reset-free regression run, the regression compares against the reference model **exactly**:
`RD_BYTES`, `WR_BYTES`, `RD_REQ`, `WR_REQ`, `DESC_OK`, `XFER_ERR`, and the bus statistics the testbench counts
itself (SFB2 reads / writes, TC03 writes, output-buffer reads). In addition: `0 < ACTIVE ≤ cycles`;
`OUT_MAX ≤ MAX_OUT + 2·LOC_OUT`; `OVERLAP = 0` in every SEQUENTIAL run and `> 0` in the double-buffered prefetch
runs; `DEP_WAIT > 0` in the dependency tests. Mutant M04 (tail not masked) was first detected by `RD_BYTES`.

The single-transfer throughput sweep (doc 08) uses `LD_BUSY / ST_BUSY − BUF_WAIT` as the transfer time.
