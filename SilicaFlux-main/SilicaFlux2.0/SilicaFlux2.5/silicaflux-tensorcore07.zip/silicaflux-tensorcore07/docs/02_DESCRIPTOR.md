# 02 — The 2-D transfer descriptor

Defined in `rtl/tdma_defs.svh` (RTL) and mirrored in `model/tdma_desc.py` (host / test side). 192 bits = six
little-endian 32-bit words, so a host or a command queue can write it as six word stores.

## 1. Layout

| word | bits | field | meaning |
|---|---|---|---|
| 0 | [31:0] | `SRC` | source byte address of row 0 |
| 1 | [63:32] | `DST` | destination byte address of row 0 |
| 2 | [95:64] | `SRC_STRIDE` | bytes from the start of one source row to the next (any value, incl. 0) |
| 3 | [127:96] | `DST_STRIDE` | bytes from the start of one destination row to the next (≥ `ROW_LEN` if `ROWS` > 1) |
| 4 | [143:128] | `ROW_LEN` | transfer length of one row in bytes, 1 .. 65 535 |
| 4 | [159:144] | `ROWS` | number of rows, 1 .. 65 535 (`ROWS` = 1 is a plain 1-D transfer) |
| 5 | [167:160] | `ID` | transaction identifier, echoed in the completion record |
| 5 | [169:168] | `KIND` | 0 `LOAD_A`, 1 `LOAD_B`, 2 `STORE`, 3 reserved |
| 5 | [175:170] | `FLAGS` | bit 0 `SEAL`, bit 1 `FENCE`, bits 2–5 reserved (must be 0) |
| 5 | [183:176] | `RSVD` | must be 0 |
| 5 | [191:184] | `VERSION` | must be `0x07` |

Row `r` (0 ≤ r < ROWS) covers bytes `[SRC + r·SRC_STRIDE, + ROW_LEN)` and `[DST + r·DST_STRIDE, + ROW_LEN)`.
Bytes moved = `ROW_LEN · ROWS`. **Addresses have no alignment requirement** on either side.

| `KIND` | `SRC` is | `DST` is |
|---|---|---|
| `LOAD_A` | external (SFB2) byte address | byte offset inside the **A region of the operand set being filled** |
| `LOAD_B` | external byte address | byte offset inside the **B region** of that set |
| `STORE` | byte offset inside the **output set being drained** | external byte address |

The adapter adds the base of the set it currently owns (`set · A_SET_BYTES`, `REGION + set · B_SET_BYTES`,
`set · O_SET_BYTES`), so software never needs to know which physical set (ping or pong) is in use.

## 2. Flags

* **`SEAL`** — this descriptor completes the buffer set. LOAD: after all its writes are acknowledged, the operand
  set is handed to compute (`fill_end`: FILLING → READY). STORE: after all its writes to external memory are
  acknowledged, the output set is released (`rd_end`: IN_USE → FREE). Several descriptors may fill (or drain) one
  set; only the last carries `SEAL` (typical: `LOAD_A` without, `LOAD_B` with `SEAL`).
* **`FENCE`** — start only after every older descriptor (both channels) has completed. In SEQUENTIAL mode every
  descriptor is implicitly fenced.

## 3. Validation (`rtl/tdma_validate.sv`)

Checked before the descriptor can touch a bus, a buffer or an ownership state; the first failing rule wins. A
rejected descriptor produces a completion with the code, `bytes = 0`, `err_addr = 0`, and **no side effect at all**
(no bus transaction, no buffer write, no ownership change; `s2_invalid` checks all of them against an exact final
memory and exact transaction counts).

| # | Code | Rule |
|---|---|---|
| 1 | `RSVD` | `VERSION ≠ 0x07`, `KIND = 3`, a reserved flag bit, or `RSVD ≠ 0` |
| 2 | `ZERO` | `ROW_LEN = 0` or `ROWS = 0` |
| 3 | `DST_ROWS` | `ROWS > 1` and `DST_STRIDE < ROW_LEN` — destination rows would overlap (the result would depend on order) |
| 4 | `EXT_OVF` | last external byte ≥ 2³² (64-bit arithmetic: `base + (ROWS−1)·stride + ROW_LEN − 1`) |
| 5 | `EXT_RANGE` | external footprint not inside `[MEM_LO, MEM_HI)` |
| 6 | `LOC_RANGE` | last local byte ≥ the size of the target region (A set, B set, or output set) — a transfer can never cross into the other set |

Source rows may overlap (`SRC_STRIDE < ROW_LEN`, e.g. sliding windows) and a source row may be repeated
(`SRC_STRIDE = 0`, broadcast); both are tested (`s2_src_overlap`).

## 4. Completion record

| field | meaning |
|---|---|
| `cpl_id`, `cpl_kind` | the descriptor's ID and kind |
| `cpl_code` | 0 OK, 1–6 validation (above), 7–11 transfer errors (below) |
| `cpl_detail[2:0]` | for `LOC_RD` / `LOC_WR`: the local port's error code (Module 04 / TC03: 1 RANGE, 2 ALIGN, 4 PARITY, 6 OWNER, 7 UNSUP) |
| `cpl_err_addr` | address of the first failing transaction (external byte address of the word, or local window address) |
| `cpl_bytes` | destination bytes whose writes were acknowledged **without error**, before the first failing write: a contiguous prefix of the destination stream (writes are acknowledged in issue order) |

| Code | Name | Cause |
|---|---|---|
| 7 | `RD_BUS` | LOAD: an SFB2 read answered with `rsp_error` (R8) |
| 8 | `WR_BUS` | STORE: an SFB2 write answered with `rsp_error` (the write had no side effect, R8) |
| 9 | `LOC_RD` | STORE: an output-buffer read refused (OWNER / RANGE / ALIGN / PARITY) |
| 10 | `LOC_WR` | LOAD: a TC03 fill write refused (OWNER / RANGE / ALIGN) |
| 11 | `PROTO` | a local response whose tag or direction does not match the oldest outstanding request (misrouted / duplicated / re-ordered) — its data is never used |

**An error never changes ownership**: a failed `SEAL` descriptor leaves the set FILLING (or IN_USE), so the host
can simply re-issue the transfer into the same set (tested: every `s2_err_*` test retries and then continues).
Records of one channel are in submission order; in SEQUENTIAL mode all records are in submission order. `ID`s need
only be unique among descriptors in flight (at most `2·QDEPTH + 3`).

## 5. Examples

GEMM step of tile (m0, n0), K chunk k0 (from `model/gemm_gen.py`), INT8 row-major A (lda), B (ldb), INT32 C (ldc):

```
LOAD_A  SRC = A + m0·lda + k0     DST = 0   ROW_LEN = kc    ROWS = eff_m  SRC_STRIDE = lda  DST_STRIDE = lda_loc
LOAD_B  SRC = B + k0·ldb + n0     DST = 0   ROW_LEN = eff_n ROWS = kc     SRC_STRIDE = ldb  DST_STRIDE = 4      SEAL
STORE   SRC = 0                   DST = C + m0·ldc + 4·n0   ROW_LEN = 4·eff_n  ROWS = eff_m  SRC_STRIDE = O_LD  DST_STRIDE = ldc  SEAL
```

`lda_loc` is chosen by software (here: kc rounded up to a multiple of 4, +4 if a multiple of 8, so the A rows of a
set start in different TC03 banks); with the realigner the local layout is independent of the source alignment.

Python: `Desc(kind=K_LOAD_A, src=..., dst=0, row_len=29, rows=4, sstride=29, dstride=36, id=5).words()`.
