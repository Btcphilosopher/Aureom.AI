# 08 — Throughput analysis

All numbers are RTL simulation cycles (`reports/perf.json`, `reports/gemm.json`, `reports/xbar.json`) against the
testbench memory model; there is **no clock frequency claim** (no timing analysis). Memory-model convention: a
request accepted at edge *t* is answered so that its response is accepted at edge *t + L + 1* ("lat1" = a 2-cycle
round trip). The real `sfb_sram_slave` (READ_LATENCY 1) used in the crossbar test answers one cycle earlier.

## 1. Bounds

| Resource | Bound |
|---|---|
| SFB2 port (shared by load reads and store writes) | 1 transaction / cycle = WB bytes / cycle |
| TC03 fill port | 1 word write / cycle (when its banks grant) |
| output-buffer DMA port | 1 word read / cycle (scratchpad bank arbitration) |
| words per row | ⌊(s mod WB + L − 1) / WB⌋ + 1 on each side: misalignment costs at most one extra word per row |
| one transaction in flight (`MAX_OUT = 1`) | 1 word per (L + 3) cycles: request register, round trip, credit return |
| `MAX_OUT` transactions in flight | min(1, MAX_OUT / (L + 3)) words / cycle, also limited by the realigner: RCAP / WB words |
| DataFabric crossbar (R6: one transaction per port) | 1 word per round trip, independent of `MAX_OUT ≥ 2` |
| per descriptor | a fixed ≈ 10–13 cycles: queue → acquire → AGU start → first response → last acknowledgement → record |

## 2. Single transfers (measured, 32-bit port; full tables in `reports/perf.md`)

| Transfer | memory | MAX_OUT 1 | 2 | 4 | 8 | 16 | model min(1, MAX_OUT/(L+3)) · 4 |
|---|---|---|---|---|---|---|---|
| 1 KiB aligned load | lat1 | 0.99 | 1.97 | **3.83** | 3.83 | 3.83 | 1.0 / 2.0 / 4 / 4 / 4 |
| 1 KiB **misaligned** load (src +1, dst +3) | lat1 | 0.99 | 1.96 | **3.82** | 3.82 | 3.82 | same: the realigner is free |
| 1 KiB aligned load | lat4 | 0.57 | 1.13 | 2.23 | 3.79 | 3.79 | 0.57 / 1.14 / 2.29 / 4 / 4 |
| 1 KiB aligned load | lat8 | 0.36 | 0.72 | 1.43 | 2.79 | 3.74 | 0.36 / 0.73 / 1.45 / 2.9 / 4 |
| 1 KiB aligned load | lat16 | 0.21 | 0.42 | 0.83 | 1.64 | 2.99 | 0.21 / 0.42 / 0.84 / 1.68 / 3.37 (realigner-limited) |
| 32 × 31 B rows, stride 97 | lat1 | 0.91 | 1.79 | 3.50 | 3.50 | 3.50 | 8 words per 31-byte row |
| 256 × 4 B rows, stride 13 | lat1 | 0.57 | 1.13 | 2.23 | 2.23 | 2.23 | 1.75 words per 4-byte row (misaligned rows span 2 words) |
| 256 B store from the output buffer | lat1 | 0.97 | 1.88 | 3.46 | 3.46 | 3.46 | the output-buffer read latency adds to the round trip |
| 1 KiB aligned load, R6 crossbar | lat1 | 0.99 | 1.96 | 1.96 | 1.96 | 1.96 | one per 2-cycle round trip |
| 1 KiB aligned load, R6 crossbar | lat4 | 0.57 | 0.79 | 0.79 | 0.79 | 0.79 | one per 5-cycle round trip |

Bytes per cycle. The simple model `min(1, MAX_OUT/(L+3))` words/cycle matches the measurements within the fixed
per-descriptor cost (1 KiB = 256 words in 267 cycles at full rate: ≈ 11 cycles of fill / drain). On the 64-bit port
the same transfers reach 7.37 B/cycle (aligned and misaligned).

**Comparison with the existing engines** (M05 `reports/cycles.md`, 4 KiB, its own 1-cycle slave models, so
indicative rather than cycle-identical): DataFabric simple engine
1.00 B/cycle (aligned only); buffered single port 1.60 B/cycle; buffered **dual** port 3.97 B/cycle (two fabric
ports). The tensor DMA matches the simple engine with `MAX_OUT = 1` and reaches 3.8 B/cycle on **one** port with
`MAX_OUT ≥ 4` — including byte-misaligned sources and destinations, which the existing engines reject.

## 3. Tiled GEMMs (4 × 4 array, TILE_K 64, configuration `base`, `reports/gemm.md`)

| Workload | memory | SEQUENTIAL | PREFETCH | speed-up | array utilisation |
|---|---|---|---|---|---|
| 17 × 13 × 29 (misaligned lda / ldb / ldc) | lat1 | 3 903 | 2 155 | 1.81× | 18.6 % |
| 5 × 7 × 3 | lat1 | 397 | 186 | 2.13× | 3.5 % |
| 8 × 8 × 200 (4 K chunks) | lat1 | 4 153 | 3 100 | 1.34× | 25.8 % |
| 32 × 32 × 64 | lat1 | 23 109 | 14 982 | 1.54× | 27.3 % |
| 32 × 32 × 256, aligned | lat1 | 63 557 | **40 069** | 1.59× | 40.9 % |
| 32 × 32 × 256, B base +3 bytes | lat1 | 79 941 | 56 453 | 1.42× | 29.0 % |
| 32 × 32 × 256, aligned | lat8 | 122 693 | 99 205 | 1.24× | 16.5 % |
| 32 × 32 × 256, aligned | R6 crossbar, lat4 | 198 149 | 174 724 | 1.13× | 9.4 % |
| 32 × 32 × 256, aligned | random back-pressure | 101 273 | 77 159 | 1.31× | 21.2 % |

Configuration effects (32 × 32 × 256 aligned, lat1, PREFETCH): `base` 40 069; `single` (one operand set) 60 533 —
with one set only the store / compute overlap remains, as expected; `stress` (16 outstanding, 1RW TC03 banks:
fills contend with slice reads, slower SRAMs) 44 149; `min` (one transaction in flight) 139 906.

### Where the time goes (32 × 32 × 256 aligned, PREFETCH)

* Bus work: A 64 + B 64 words per step × 256 steps = 32 768 reads, plus 1 024 C writes: **33 792 transactions on
  one port** — the lower bound. Measured 40 069 cycles = **84 %** of it. The DMA is the bottleneck (`LD_BUSY`
  39 408 of 40 069 cycles), compute is hidden (`OVERLAP` = 16 320 cycles of fills under compute).
* The remainder is the fixed per-descriptor cost: 512 load descriptors × ≈ 12 cycles ≈ 6 100 cycles. The channel
  completes one descriptor (every write acknowledged) before it starts the next — the conservative choice that makes
  completion, error prefixes and ownership hand-over exact.
* TENSORCORE 06's embedded mover on the same array and memory model: 61 205 → 36 729 cycles (92 % of the bound): it
  streams a step's A and B without a per-transfer completion. The tensor DMA is within 9 % of it while adding
  descriptors, completion records, byte-accurate independent alignment, errors and an output buffer.
* Misaligned B (+3) costs 50 % more B reads (each 4-byte row spans 2 words): 49 152 reads → 56 453 cycles. Aligning
  the matrix rows (or choosing `ldb` ≡ 0 mod 4) removes it; this is a property of the data, not of the DMA.

## 4. Behind the DataFabric crossbar

The crossbar carries one transaction per master port (R6), so the port delivers one word per round trip whatever
`MAX_OUT` is (≥ 2 keeps the next request waiting so it is accepted in the response cycle). With four masters under
round robin the tensor DMA's worst request wait was 3–5 cycles; with fixed priority (DMA lowest) 13 cycles
(`reports/xbar.md`). Throughput behind the crossbar is therefore set by the slave round trip, not by the adapter.

## 5. How to go faster (not implemented; measured motivation above)

| Step | Expected effect |
|---|---|
| Pipeline descriptors inside a channel (start the next descriptor's reads while the previous one drains its acknowledgements; per-descriptor completion counters) | recovers most of the ≈ 12 cycles / descriptor: 32 × 32 × 256 → ≈ 34–35 k cycles (≈ TC06) |
| 64-bit fabric (`WB = 8`, already supported and tested) | 2× bytes per transaction: 7.37 B/cycle measured on single transfers |
| Separate read and write SFB2 ports (as M05's dual-port engine) | load reads and store writes no longer share one port |
| DataFabric ID extension (PROTOCOL.md §8) | lets `MAX_OUT > 1` work through the crossbar |
| Operand reuse (skip the A or B block already resident, as TC06's REUSE) | removes up to half of the operand traffic for some loop orders; a scheduler decision, expressible today by not issuing the descriptor |
