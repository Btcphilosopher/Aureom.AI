# 07 — Verification

Simulation with Verilator 5.020 and Icarus Verilog 12, self-checking against an **independent Python reference**
(`model/tdma_ref.py`, plain integers, no code shared with the RTL). Synthesis checks with Yosys 0.33. Every number
below is reproduced by `make all` and comes from `reports/*.json`.

## 1. Testbenches

| Testbench | DUT | Purpose |
|---|---|---|
| `tb/tb_tdma.sv` | adapter + **real TC03** + **real output buffer** (M04 scratchpad) | the main staged regression; byte-accurate SFB2 memory and TC03 shadow; compute-side consumer / producer models; fault injectors |
| `tb/tb_tdma_gemm.sv` | `tdma_tile_system` (adapter + unmodified TC02 / TC03 / TC04 + output buffer + sequencer) | definition of done: tensor operands and results move through the real interface for whole tiled GEMMs |
| `tb/tb_tdma_xbar.sv` | adapter + TC03 + output buffer on the **real DataFabric crossbar** with real SRAM slaves, M04 TSPM, DataFabric `dma_burst_engine`, CPU / vector / lane traffic | arbitration, fairness, scratchpad contention, fabric integration |
| `tb/tb_tout.sv` | `tensor_output_buffer` | directed ownership-enforcement test (illegal accesses the adapter never issues) |

## 2. Byte-accurate memory models and checks (tb_tdma)

* **Source / destination memory (SFB2 slave)**: a byte array; reads return whole words (R10); a write is performed
  byte by byte under its strobe **only when the slave sends the response** (R7) after a random latency; per-byte
  "last writer" tracking; random `req_ready`; R6 mode; error words.
* **TC03 fill window shadow**: every write TC03 acknowledges is applied byte by byte to a shadow of the whole window
  (A and B regions of both sets), with last-writer tracking.
* **Output buffer**: real; its content reaches memory only through STOREs, which the memory compare checks.
* Checks in every run (all from the reference, the TB never computes a transfer):
  completion records (exactly once; code, bytes, error address, detail; order in SEQUENTIAL mode);
  **write completion** (at each OK record every destination byte must already have been performed by that
  descriptor); **operand sets at compute time** (whole set equals the reference snapshot at `cmp_begin`);
  element maps (every SFB2 read word holds a source byte of the running LOAD; every strobed byte of every SFB2 /
  TC03 write is a destination byte of the running descriptor; no byte written twice by one descriptor; TC03 writes
  only into a FILLING set); FENCE / SEQUENTIAL start order; SFB2 R2 / R9 and DataFabric `sfb_protocol_checker`;
  no request during reset; no completion of a pre-reset descriptor after reset; the **whole external memory** at the
  end; no output-buffer refusal or writer error; and, for error-free runs, the counters and bus statistics against
  the reference exactly.

## 3. Brief §9 → tests

| Brief item | Tests | Also |
|---|---|---|
| single-row transfer | `s1_single`, `s1_lengths_load` (208 one-row loads), `s1_lengths_store` (60 one-row stores) | perf `load1d_*`, `store1d_*` |
| multi-row strided transfer | `s2_multirow`, `s2_long_2d`, `s2_random*` | every GEMM step (A: eff_m rows at lda, B: kc rows at ldb, C: eff_m rows at ldc) |
| partial final row | `s1_lengths_*` (every length 1..3·WB+1: tails of every size), `s2_partial` (lengths 1–29 not word multiples, odd strides) | boundary GEMM tiles 5×7×3, 17×13×29, 37×1×5, 1×37×5 |
| misaligned requests | `s1_lengths_*` (every source × destination residue), `s2_partial` (every residue), misaligned C rows | perf `*_misaligned`; GEMM `g32x32x256u` (B base +3) |
| long transfers | `s1_long_1d` (a whole 1 KiB set per descriptor), `s2_long_2d` (32 rows) | perf 1 KiB at 5 depths × 6 memories; GEMM 32×32×256 (576 descriptors) |
| bus back-pressure | `s2_random_bp` (40 % not ready, latency 1–12, completion back-pressure), `s3_dbuf_bp_*`, `s3_mix_*`, `s2_random_xbar` (R6) | GEMM `bp`, `xbar`; crossbar test |
| scratchpad contention | `s3_contention_*` (output-buffer banks: writer vs DMA), `stress` config (1RW everywhere, single output bank) | crossbar test: TSPM banks vs two vector lanes; GEMM `stress` (TC03 1RW: fills vs slice reads) |
| double-buffer switching | `s3_dbuf_*` (8 tiles ping-pong, SEQUENTIAL and PREFETCH, `OVERLAP > 0` required with prefetch) | all GEMMs with NS = 2; `single` config with NS = 1 |
| reset during transfer | `s3_reset_*` (reset while SFB2 transactions are in flight — asserted by the TB; then an exactly checked second program) | |
| error propagation | `s2_err_rd`, `s2_err_wr`, `s2_err_loc_wr`, `s2_err_loc_rd`, `s2_err_proto`, `s2_invalid` (every validation code, interleaved with valid descriptors) | `tb_tout` (OWNER / UNSUP / RANGE refusals) |
| write-completion semantics | every OK record (last-writer check), `s2_writecpl` (latency 8–24 so a premature record would see unwritten bytes) | mutant M02 (completion without acknowledgements) killed in the first test |
| prefetch / dependencies | `s3_hazard_raw_*`, `s3_hazard_war_*`, `s3_fence_*`, `s3_mix_*` (overlapping footprints) | mutants M08–M11, M21, M22 |

## 4. Staging (the brief's order)

`scripts/run_regress.py` runs **stage 1** (one sequential 1-D transfer at a time; includes the `seq1` baseline: one
set, one transaction in flight, minimum buffering) → **stage 2** (2-D transfers, misalignment, back-pressure,
errors, validation) → **stage 3** (double-buffered overlap, prefetch vs sequential, dependencies, reset,
contention); a failing stage stops the run. Five hardware configurations: `seq1`, `base`, `small` (256-byte sets,
8-byte realigner, 2 outstanding), `wide` (64-bit), `stress` (16 outstanding, 1RW banks, read latency 2, one output
bank). Three seeds per run. Icarus cross-simulates `seq1` and `base`: statistics, cycle counts and counters must be
identical to Verilator's.

## 5. Results

| Check | Result | Report |
|---|---|---|
| Lint: Verilator -Wall (7 parameter sets, 0 warnings in new RTL), Icarus elaboration, 12 illegal parameter sets rejected by the modules' own checks | **19 / 19** | `reports/lint.md` |
| Regression stages 1 → 2 → 3, 5 configurations, 3 seeds, + directed output-buffer test | **582 / 582 runs pass** | `reports/regression.md` |
| Icarus vs Verilator, same seed: identical statistics, cycles, counters | **68 / 68 pairs** | `reports/regression.md` |
| End-to-end GEMMs (11 workloads × 4 hardware configs × 4 memory behaviours × 2 modes) | **328 / 328 runs pass** | `reports/gemm.md` |
| DataFabric crossbar contention (6 modes × 3 programs × 2 seeds) | **36 / 36 runs pass**; tensor DMA worst wait 3–5 cycles (round robin), 13 (fixed priority) | `reports/xbar.md` |
| Mutation testing (30 injected bugs) | **27 / 30 killed**; 3 survivors analysed as equivalent (redundant interlocks) | `reports/mutation.md` |
| Throughput sweep (self-checking runs) | **360 / 360** | `reports/perf.md` |
| Yosys: adapter (2 configs), output buffer, whole integration flattened; no latch, `check -assert` | **6 / 6** | `reports/synth.md` |
| ABI: `tdma_defs.svh` vs `model/tdma_desc.py` | OK | `scripts/check_abi.py` |

## 6. Tool-portability notes learnt here

* Verilator 5.020 `--timing`: a `while (cond) @(posedge clk);` whose condition calls functions containing loops
  did not yield inside an `initial` coroutine (the simulation stopped advancing time). The testbenches compute such
  conditions in a clocked process and wait on a plain variable.
* Verilator with randomised initial values: a reset that starts at 0 has no falling edge, so asynchronous resets do
  not act before the first clock; the testbenches start reset high and drop it at t = 1 ns.
* Icarus 12: no `break`, no `return` from tasks — avoided in the testbenches.
* Yosys 0.33: no `return` in functions (function-name assignment is used), and a sized cast directly after
  `return` is a syntax error. (Earlier modules' rule — no unsized `'1` in parameter overrides — is also followed.)

## 7. What is not claimed

No formal proof of the new RTL, no gate-level simulation, no FPGA or silicon run, no timing closure. The reference
compute sequencer (`tdma_compute_seq`) is test infrastructure for the integration, not a production scheduler.
