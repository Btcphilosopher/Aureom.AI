# third_party — provenance

Every file here is an **unmodified, byte-identical** copy of a file in an earlier SilicaFlux deliverable archive in
`btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. `SHA256SUMS` lists every
file; each hash was compared with the archive copy when it was vendored (0 differences).

| Directory | Source archive | Path inside the archive | Used by |
|---|---|---|---|
| `silicaflux-tensorcore02/rtl/` | `silicaflux-tensorcore02.zip` | `silicaflux-tensorcore02/rtl/` | `tdma_tile_system` (systolic array) |
| `silicaflux-tensorcore03/rtl/` | `silicaflux-tensorcore03.zip` | `silicaflux-tensorcore03/rtl/` | TC03 operand buffer (A/B destination); `tob_dbuf_ctrl` also inside `tensor_output_buffer` |
| `silicaflux-tensorcore04/rtl/` | `silicaflux-tensorcore04.zip` | `silicaflux-tensorcore04/rtl/` | `tdma_tile_system` (accumulator, `osram` row stream) |
| `silicaflux-hpc-m04-scratchpad/rtl/` | `silicaflux-hpc-m04-scratchpad.zip` | `silicaflux-hpc-m04-scratchpad/rtl/` | storage of `tensor_output_buffer`; TSPM slave in `tb_tdma_xbar` |
| `silicaflux-datafabric/rtl/dma/dma_fifo.sv` | `silicaflux-datafabric.zip` | `silicaflux-datafabric/rtl/dma/` | queues / FIFOs of the new RTL |
| `silicaflux-datafabric/rtl/dma/dma_burst_engine.sv`, `dma_validate.sv`, `dma_defs.svh` | same | same | "other DMA engine" master in `tb_tdma_xbar` |
| `silicaflux-datafabric/rtl/interconnect/*` | same | `silicaflux-datafabric/rtl/interconnect/` | `sfb_crossbar` in `tb_tdma_xbar` |
| `silicaflux-datafabric/rtl/mem/sfb_sram_slave.sv` | same | `silicaflux-datafabric/rtl/mem/` | SRAM slaves in `tb_tdma_xbar` |
| `silicaflux-datafabric/tb/common/sfb_protocol_checker.sv` | same | `silicaflux-datafabric/tb/common/` | SFB2 protocol checker on every link in every testbench |
| `silicaflux-datafabric/docs/datafabric/PROTOCOL.md`, `DMA.md` | same | `silicaflux-datafabric/docs/datafabric/` | the bus contract (reference) |
| `silicaflux-sramlib/rtl/mem/*` | `silicaflux-datafabric.zip` | `silicaflux-datafabric/third_party/silicaflux-sramlib/rtl/mem/` | backends of TC03, M04, `sfb_sram_slave`. The same files inside the TC03 and M04 archives were compared: identical. |

The TC02 / TC03 / TC04 files are also identical to the copies TENSORCORE 06 vendored.
