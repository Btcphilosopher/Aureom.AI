"""MODEL A - memory bandwidth / cycle model of the Albion fabric complex.

Architecture facts used (all from docs/albion/transaction_protocol.md and the RTL, none fitted to benchmark output):

  F1  every master has ONE outstanding request and may re-issue in the cycle its response arrives      -> 1 request / cycle / master
  F2  an SRAM bank accepts one request per cycle (pipelined, single port) and responds the next cycle      -> service latency S = 1
  F3  a partial (byte-strobe) write is read-modify-write: the bank is busy two cycles                       -> write period 2
  F4  each slave has a work-conserving round-robin arbiter over the four masters                          -> K saturating masters share a bank 1/K each
  F5  the DMA engine is one read port + one write port + a DEPTH-entry prefetch FIFO; a read may issue only if
      FIFO count + outstanding < DEPTH; a FIFO word is freed when its write is accepted                      -> Little's law bound  P >= round_trip / DEPTH
  F6  host-memory port: one outstanding request, response after L cycles, next request may issue in the response cycle -> period L
  F7  DMA register start -> first request takes 2 cycles (busy, FIFO flush); `done` is visible 1 cycle after the last response

DMA window (cycles from the CTRL write to the cycle `done` is observed), with N words, steady-state period P, read latency S_r, write latency S_w:
    fill :  (N-1)*P + S_w + 3
    copy :  (N-1)*P + S_r + S_w + 4
These are derived by following one word through the pipeline (F1-F7); P is the larger of the port-rate limit and the FIFO limit (F5).

Constants fixed against P90's INDEPENDENTLY PUBLISHED DMA_CYCLES figures (not against this framework's own data): F7's 2- and 1-cycle terms.  The points that
coincide with those published configurations are tagged in_sample.
"""
import math
import random

from .. import metrics as M

S_SRAM = 1
ANCHORS = {   # P90 performance_report.md (published, independent harness): DMA_CYCLES register values
    ("fill", 8192, 1, 4): 2050, ("copy_xbank", 8192, 1, 4): 2052, ("copy_samebank", 8192, 1, 4): 4098,
    ("host_to_sram", 4096, 1, 4): 1028, ("host_to_sram", 4096, 4, 4): 4100, ("host_to_sram", 4096, 16, 4): 16388, ("host_to_sram", 4096, 64, 4): 65540,
}


def dma_period(mode, L, depth):
    if mode == "fill":
        return 1.0
    if mode == "copy_xbank":
        return max(1.0, (S_SRAM + 2) / depth)
    if mode == "copy_samebank":
        return 2.0
    if mode == "host_to_sram":
        return max(float(L), (L + 2) / depth)
    if mode == "sram_to_host":
        return max(float(L), (S_SRAM + 2) / depth)
    raise ValueError(mode)


def dma_window(mode, nwords, L, depth, period_override=None):
    if mode == "copy_samebank" and period_override is None:
        # the single-port bank accepts 2N requests back to back from cycle 2 (reads and writes interleave with no bubble):
        # last accept at 2N+1, response +1, `done` visible +1  ->  2N + 3
        return 2.0 * nwords + 3
    P = period_override if period_override is not None else dma_period(mode, L, depth)
    S_r = L if mode == "host_to_sram" else S_SRAM
    S_w = L if mode == "sram_to_host" else S_SRAM
    if mode == "fill":
        return (nwords - 1) * P + S_w + 3
    return (nwords - 1) * P + S_r + S_w + 4


def dma_beat_latency(mode, L):
    """Mean request latency over read+write beats (first valid -> response)."""
    if mode == "fill":
        return 1.0, 1
    if mode == "copy_xbank":
        return 1.0, 1
    if mode == "copy_samebank":
        return 2.0, 2
    if mode == "host_to_sram":
        return (L + 1) / 2.0, max(L, 1)
    if mode == "sram_to_host":
        return (1 + L) / 2.0, max(L, 1)
    raise ValueError(mode)


def mc_random(allowed, n_ops, draws=6, seed0=7):
    """Expectation of the documented arbitration rules (F1, F2, F4) for K masters issuing uniformly random single-word accesses.
    allowed[m] = banks master m may reach.  Returns mean over `draws` independent realisations."""
    K = len(allowed)
    acc = {"cycles": 0.0, "lat_sum": 0.0, "ops": 0, "stall": 0.0, "conf": 0.0, "lats": []}
    for d in range(draws):
        rng = random.Random(seed0 * 7919 + d)
        nb = 1 + max(max(a) for a in allowed)
        tgt = [rng.choice(allowed[m]) for m in range(K)]
        first = [0] * K
        done = [0] * K
        rr = [0] * nb                      # per-bank pointer over the four master slots
        t = 0
        stall = conf = 0
        lats = []
        active = set(range(K))
        while active:
            req = {}
            for m in active:
                req.setdefault(tgt[m], []).append(m)
            if any(len(ms) > 1 for ms in req.values()):
                conf += 1                      # the RTL event is ONE bit per cycle (any bank with >= 2 requesters)
            for b, ms in req.items():
                grant = None
                for k in range(4):
                    cand = (rr[b] + k) % 4
                    if cand in ms:
                        grant = cand
                        break
                rr[b] = (grant + 1) % 4
                for m in ms:
                    if m != grant:
                        stall += 1
                lats.append(t - first[grant] + 1)
                done[grant] += 1
                first[grant] = t + 1
                if done[grant] >= n_ops:
                    active.discard(grant)
                else:
                    tgt[grant] = rng.choice(allowed[grant])
            t += 1
        acc["cycles"] += t + 1
        acc["stall"] += stall
        acc["conf"] += conf
        acc["lats"] += lats
        acc["ops"] += sum(done)
    lats = sorted(acc["lats"])
    return {"cycles": acc["cycles"] / draws, "stall": acc["stall"] / draws, "conflicts": acc["conf"] / draws,
            "lat_mean": sum(lats) / len(lats), "lat_p99": M.percentile(lats, 99), "lat_max": lats[-1]}


def _allowed_for_random(K, nb):
    out = []
    for m in (0, 1, 2, 3)[:K]:
        lo = 0 if m in (0, 3) else 1
        out.append(list(range(lo, nb)))
    return out


def predict(rec):
    w, hw, p = rec["workload"], rec["hardware"], rec["params"]
    nb = hw["sram_banks"]
    pr, basis, notes = {}, {}, []

    def put(k, v, b="structural"):
        pr[k] = v
        basis[k] = b

    if w in ("sram_seq_read", "sram_seq_write"):
        n = p["nwords"]
        put("clock_cycles", n + 1)
        put("memory_bandwidth_bytes_per_cycle", 4.0 * n / (n + 1))
        put("stall_cycles", 0)
        put("memory_conflicts", 0)
    elif w == "sram_seq_write_partial":
        n = p["nwords"]
        put("clock_cycles", 2 * n)
        put("memory_bandwidth_bytes_per_cycle", 1.0 * n / (2 * n))      # one byte per byte-strobe write
        put("stall_cycles", n - 1)
        put("memory_conflicts", 0)
    elif w in ("sram_bank_conflict", "bus_arbitration") and (w == "sram_bank_conflict" or p["demand"] == "saturating"):
        K, n = p["masters"], p.get("nwords", p.get("nops"))
        same = (w == "bus_arbitration") or p["placement"] == "same"
        if same:
            put("clock_cycles", K * n + 1)
            put("stall_cycles", K * n * (K - 1) - K * (K - 1) // 2)
            put("memory_conflicts", K * n - 1)
            put("transaction_throughput_per_cycle", K * n / (K * n + 1))
        elif K <= nb:
            put("clock_cycles", n + 1)
            put("stall_cycles", 0)
            put("memory_conflicts", 0)
            put("transaction_throughput_per_cycle", K * n / (n + 1))
        else:
            return None
    elif w == "bus_arbitration":                                         # unequal demand: work-conserving bank
        K, n = p["masters"], p["nops"]
        low = max(8, n // 8)
        put("clock_cycles", n + (K - 1) * low + 1)
    elif w in ("sram_random", "concurrent_mem"):
        K, n = p["masters"], p["nops"]
        r = mc_random(_allowed_for_random(K, nb), n)
        put("clock_cycles", r["cycles"], "monte-carlo")
        put("transaction_throughput_per_cycle", K * n / r["cycles"], "monte-carlo")
        put("stall_cycles", r["stall"], "monte-carlo")
        put("memory_conflicts", r["conflicts"], "monte-carlo")
    elif w == "concurrent_dma_interference":
        N = p["length"] // 4
        P = 2.0 if p["placement"] == "same" else 1.0
        put("clock_cycles", dma_window("copy_xbank", N, 1, hw["dma_depth"], period_override=P))
        put("memory_bandwidth_bytes_per_cycle", p["length"] / pr["clock_cycles"])
    elif w in ("dma_bandwidth", "dma_latency"):
        N = p["length"] // 4
        L = hw["host_latency_cycles"] if "host" in p["mode"] else 1
        win = dma_window(p["mode"], N, L, hw["dma_depth"])
        put("clock_cycles", win)
        put("memory_bandwidth_bytes_per_cycle", p["length"] / win)
        put("transaction_throughput_per_cycle", N / win)
    else:
        return None
    key = (p.get("mode"), p.get("length"), hw["host_latency_cycles"] if p.get("mode") and "host" in p["mode"] else 1, hw["dma_depth"])
    in_sample = w == "dma_bandwidth" and key in ANCHORS
    return {"model": "A", "title": "memory bandwidth model", "predictions": pr, "basis": basis, "in_sample": in_sample, "notes": notes}
