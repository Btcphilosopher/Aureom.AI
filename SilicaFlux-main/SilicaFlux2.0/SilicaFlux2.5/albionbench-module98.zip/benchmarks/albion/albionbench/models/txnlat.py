"""MODEL D - transaction-latency model.

Fabric (structural, from F1-F6 of membw.py):
    latency of one request = accept wait + service
    saturating K masters, one bank, round robin  ->  wait = K-1, service = 1, so latency = K for every request (mean = p99 = max)
    partial write                                ->  service = 2 (read-modify-write)
    host memory port                             ->  service = L
    stochastic traffic                           ->  expectation of the abstract round-robin model (membw.mc_random)

Host mailbox (fitted, 2-point calibration, held-out validation):
    RTT = n_mmio * t_mmio + CPI * instret + dma_cycles + c
  n_mmio = 15 host MMIO operations per command (9 writes: 8 command words + doorbell; 6 reads: status, 4 completion words ... pop)
  t_mmio = mean idle host-MMIO latency measured by host_mmio_latency
  instret = ControlCore instructions per command, read from the RTL's own telemetry counter
  dma_cycles = DMA register cycles (Model A) for DMA commands, 0 for PING
CPI and c are fitted on {PING, DMA_FILL 64 B}; every other mailbox / DMA-command point is out-of-sample.
"""
from . import fitting, membw

N_MMIO = 15


def predict(rec):
    w, hw, p = rec["workload"], rec["hardware"], rec["params"]
    nb = hw["sram_banks"]
    pr, basis = {}, {}

    def put(k, v, b="structural"):
        pr[k] = v
        basis[k] = b

    if w in ("sram_seq_read", "sram_seq_write"):
        for k in ("latency_avg_cycles", "latency_p99_cycles", "latency_max_cycles"):
            put(k, 1.0)
    elif w == "sram_seq_write_partial":
        for k in ("latency_avg_cycles", "latency_p99_cycles", "latency_max_cycles"):
            put(k, 2.0)
    elif w in ("sram_bank_conflict", "bus_arbitration") and (w == "sram_bank_conflict" or p["demand"] == "saturating"):
        K = p["masters"]
        same = w == "bus_arbitration" or p["placement"] == "same"
        v = float(K) if same else 1.0
        if not same and K > nb:
            return None
        for k in ("latency_avg_cycles", "latency_p99_cycles", "latency_max_cycles"):
            put(k, v)
    elif w == "host_port_latency":
        K = p["background"] + 1
        for k in ("latency_avg_cycles", "latency_p99_cycles", "latency_max_cycles"):
            put(k, float(K))
    elif w in ("dma_bandwidth", "dma_latency"):
        L = hw["host_latency_cycles"] if "host" in p["mode"] else 1
        mean, mx = membw.dma_beat_latency(p["mode"], L)
        put("latency_avg_cycles", mean)
        put("latency_p99_cycles", float(mx))
        put("latency_max_cycles", float(mx))
    elif w == "concurrent_dma_interference":
        same = p["placement"] == "same"
        put("latency_avg_cycles", 1.5 if same else 1.0)
        put("latency_p99_cycles", 2.0 if same else 1.0)
    elif w in ("sram_random", "concurrent_mem"):
        K, n = p["masters"], p["nops"]
        r = membw.mc_random(membw._allowed_for_random(K, nb), n)
        put("latency_avg_cycles", r["lat_mean"], "monte-carlo")
        put("latency_p99_cycles", float(r["lat_p99"]), "monte-carlo")
        put("latency_max_cycles", float(r["lat_max"]), "monte-carlo")
    else:
        return None
    return {"model": "D", "title": "transaction-latency model", "predictions": pr, "basis": basis, "in_sample": False, "notes": []}


# ---------------------------------------------------------------------------------------------------- host mailbox (fitted)
def _soc_inputs(rec, t_mmio):
    d = rec["detail"]
    instret = d.get("core_instructions_per_command_rtl_telemetry")
    if instret is None:
        return None
    if rec["workload"] == "host_dma_roundtrip":
        n = rec["params"]["length"] // 4
        dma = membw.dma_window("fill", n, 1, 4) - 1                  # DMA_CYCLES register = window - 1
    else:
        dma = 0.0
    return N_MMIO * t_mmio + dma, instret


def predict_soc(records):
    """Returns (calibration_info, {record id: prediction})."""
    recs = {r["id"]: r for r in records if r["status"] == "OK" and r["workload"] in ("host_mailbox_roundtrip", "host_dma_roundtrip")}
    mm = [r for r in records if r["workload"] == "host_mmio_latency" and r["label"] == "read-idle" and r["status"] == "OK"]
    if not mm or not recs:
        return None, {}
    t_mmio = mm[0]["metrics"]["latency_avg_cycles"]
    calib_ids = [i for i in ("host_mailbox_roundtrip|ping", "host_dma_roundtrip|fill-64B") if i in recs]
    if len(calib_ids) < 2:
        return None, {}
    X, y = [], []
    for i in calib_ids:
        fixed, instret = _soc_inputs(recs[i], t_mmio)
        X.append([instret, 1.0])
        y.append(recs[i]["metrics"]["latency_avg_cycles"] - fixed)
    cpi, c = fitting.solve([[X[0][0], 1.0], [X[1][0], 1.0]], y)
    info = {"model": "RTT = 15*t_mmio + CPI*instret + dma_cycles + c", "t_mmio_cycles": t_mmio, "cpi": cpi, "c_cycles": c,
            "calibration_points": calib_ids, "basis": "fitted (2 constants, 2 calibration points)"}
    out = {}
    for i, r in recs.items():
        fixed, instret = _soc_inputs(r, t_mmio)
        out[i] = {"model": "D", "title": "transaction-latency model (host mailbox)", "predictions": {"latency_avg_cycles": fixed + cpi * instret + c},
                  "basis": {"latency_avg_cycles": "fitted"}, "in_sample": i in calib_ids, "notes": []}
    return info, out
