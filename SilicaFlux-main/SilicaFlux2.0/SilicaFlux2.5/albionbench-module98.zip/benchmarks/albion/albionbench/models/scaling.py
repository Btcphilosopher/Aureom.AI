"""MODEL E - workload scaling model.

1. Hockney size scaling   T(n) = T0 + n / r_inf   (r_inf asymptotic rate, T0 fixed cost, n_half = T0 * r_inf the size reaching half the asymptote).
   Fitted on the standard size sweep of each series; the BLIND-VALIDATION sizes of the same series are predicted out of sample, and the largest standard
   size is predicted from a fit that excludes it (extrapolation test).
2. Parallel scaling       T(p) = T_serial + T_parallel / p   (Amdahl) for vector lanes: fitted on p = 1, 2, 4, predicted for p = 8, 16.
3. Parallel efficiency    measured speed-up / ideal for masters (distinct vs shared bank) and banks (random traffic).
"""
from . import fitting


def _series(records, workload, xkey, ykey, filt, label):
    pts = [(xkey(r), ykey(r), r) for r in records if r["workload"] == workload and r["status"] == "OK" and filt(r)]
    pts = sorted({(x, y, r["id"], r["sweep"]) for x, y, r in pts}, key=lambda t: t[0])
    return label, pts


def hockney_series(records):
    base = lambda r: True
    defs = [
        ("sram_seq_read: cycles vs words", "sram_seq_read", lambda r: r["params"]["nwords"], lambda r: r["metrics"]["clock_cycles"], lambda r: r["hardware"]["sram_banks"] == 4),
        ("sram_seq_write: cycles vs words", "sram_seq_write", lambda r: r["params"]["nwords"], lambda r: r["metrics"]["clock_cycles"], lambda r: r["hardware"]["sram_banks"] == 4),
        ("DMA fill: cycles vs words", "dma_bandwidth", lambda r: r["params"]["length"] // 4, lambda r: r["metrics"]["clock_cycles"], lambda r: r["params"]["mode"] == "fill"),
        ("DMA copy (cross-bank): cycles vs words", "dma_bandwidth", lambda r: r["params"]["length"] // 4, lambda r: r["metrics"]["clock_cycles"],
         lambda r: r["params"]["mode"] == "copy_xbank" and r["hardware"]["dma_depth"] == 4 and r["hardware"]["sram_banks"] == 4),
        ("DMA copy (same bank): cycles vs words", "dma_bandwidth", lambda r: r["params"]["length"] // 4, lambda r: r["metrics"]["clock_cycles"],
         lambda r: r["params"]["mode"] == "copy_samebank"),
        ("DMA host->SRAM (L=1): cycles vs words", "dma_bandwidth", lambda r: r["params"]["length"] // 4, lambda r: r["metrics"]["clock_cycles"],
         lambda r: r["params"]["mode"] == "host_to_sram" and r["hardware"]["host_latency_cycles"] == 1 and r["hardware"]["dma_depth"] == 4),
        ("vector INT32 add (4 lanes): cycles/cmd vs elements", "vector_int32", lambda r: r["params"]["vl"], lambda r: r["metrics"]["latency_avg_cycles"],
         lambda r: r["params"]["op"] == "add" and r["hardware"]["vector_lanes"] == 4 and r["hardware"]["compute_ports"] == 1 and r["hardware"]["compute_mem_width_bits"] == 64),
        ("GEMM 4x4 array, M=N=4: cycles/cmd vs K", "gemm_int8", lambda r: r["params"]["shape"][2], lambda r: r["metrics"]["latency_avg_cycles"],
         lambda r: r["params"]["shape"][:2] == [4, 4] and r["hardware"]["tensor_array"] == [4, 4] and r["hardware"]["compute_ports"] == 1
         and r["hardware"]["compute_mem_width_bits"] == 64),
    ]
    out = []
    for label, wl, xk, yk, filt in defs:
        _, pts = _series(records, wl, xk, yk, filt, label)
        std = [(x, y, i) for x, y, i, sw in pts if sw != "blind-validation"]
        blind = [(x, y, i) for x, y, i, sw in pts if sw == "blind-validation"]
        if len(std) < 3:
            continue
        T0, r, nh = fitting.hockney([x for x, _, _ in std], [y for _, y, _ in std])
        o = {"series": label, "T0": T0, "r_inf_per_cycle": r, "n_half": nh, "fit_points": [{"n": x, "measured": y, "predicted": T0 + x / r, "id": i} for x, y, i in std],
             "validation_points": []}
        for x, y, i in blind:
            o["validation_points"].append({"n": x, "measured": y, "predicted": T0 + x / r, "error_pct": fitting.rel_err_pct(T0 + x / r, y), "id": i})
        # extrapolation: drop the largest standard size
        if len(std) >= 4:
            T0b, rb, _ = fitting.hockney([x for x, _, _ in std[:-1]], [y for _, y, _ in std[:-1]])
            x, y, i = std[-1]
            o["extrapolation"] = {"n": x, "measured": y, "predicted": T0b + x / rb, "error_pct": fitting.rel_err_pct(T0b + x / rb, y), "id": i}
        out.append(o)
    return out


def lane_scaling(records):
    pts = {r["hardware"]["vector_lanes"]: r["metrics"]["latency_avg_cycles"] for r in records
           if r["workload"] == "vector_int32" and r["status"] == "OK" and r["params"] == {"op": "add", "vl": 1024} and r["hardware"]["compute_ports"] == 1
           and r["hardware"]["compute_mem_width_bits"] == 64}
    if not {1, 2, 4, 8, 16} <= set(pts):
        return None
    ps = [1, 2, 4]
    Ts, Tp = fitting.lstsq([[1.0, 1.0 / p] for p in ps], [pts[p] for p in ps])
    rows = []
    for p in (1, 2, 4, 8, 16):
        pred = Ts + Tp / p
        rows.append({"lanes": p, "cycles": pts[p], "speedup_measured": pts[1] / pts[p], "speedup_ideal": float(p), "efficiency": pts[1] / pts[p] / p,
                     "predicted_cycles": pred, "error_pct": fitting.rel_err_pct(pred, pts[p]), "in_sample": p in ps})
    return {"model": "T(lanes) = T_serial + T_parallel / lanes", "T_serial": Ts, "T_parallel": Tp, "amdahl_max_speedup": pts[1] / Ts if Ts > 0 else None,
            "fit_on_lanes": ps, "rows": rows}


def master_bank_scaling(records):
    out = {"masters": [], "banks": []}
    by = {}
    for r in records:
        if r["status"] != "OK":
            continue
        if r["workload"] == "sram_bank_conflict":
            by.setdefault(r["params"]["placement"], {})[r["params"]["masters"]] = r
    base = None
    for placement in ("distinct", "same"):
        for K, r in sorted(by.get(placement, {}).items()):
            thr = r["metrics"]["transaction_throughput_per_cycle"]
            out["masters"].append({"placement": placement, "masters": K, "throughput_txn_per_cycle": thr, "speedup_vs_1_master": thr / 1.0,
                                   "efficiency": thr / K, "id": r["id"]})
    rb = {}
    for r in records:
        if r["workload"] == "concurrent_mem" and r["status"] == "OK" and r["params"]["masters"] == 4 and r["hardware"]["sram_banks"] in (2, 3, 4, 8):
            rb[r["hardware"]["sram_banks"]] = r
    for nb, r in sorted(rb.items()):
        thr = r["metrics"]["transaction_throughput_per_cycle"]
        ideal = min(4, nb)
        out["banks"].append({"banks": nb, "throughput_txn_per_cycle": thr, "ideal_ports": ideal, "efficiency_vs_ideal": thr / ideal, "id": r["id"]})
    return out


def analyze(records):
    return {"hockney": hockney_series(records), "lane_scaling": lane_scaling(records), "parallel": master_bank_scaling(records)}
