"""MODEL B - roofline model of the ComputeWorks tile.

    attainable ops/cycle = min( peak_compute ,  AI * peak_bandwidth )          AI = ops / bytes
    peak_compute   GEMM: 2*R*C ops/cycle (one MAC = multiply + add)       vector: `lanes` elements/cycle
    peak_bandwidth compute ports * memory word bytes per cycle (cp * dw/8)

Two arithmetic intensities are reported, because they answer different questions:
    AI_compulsory  operand + result bytes of the operation (what a perfect memory system would move)
    AI_effective   bytes the tile actually moved over its SRAM ports (measured: operand tiles are re-read per block)
and a third bound for a design whose load / compute / store phases do not overlap (ComputeWorks):
    non_overlapped = ops / ( bytes_effective / peak_bandwidth  +  ops / peak_compute )

Nothing here is fitted: every number comes from the configuration, the operation shape and the measured byte counts.
"""


def build(records):
    pts, roofs = [], {}
    for r in records:
        if r["status"] != "OK" or r["workload"] not in ("gemm_int8", "vector_int32") or r["detail"] is None:
            continue
        hw, p, d = r["hardware"], r["params"], r["detail"]
        dwb = hw["compute_mem_width_bits"] // 8
        n = d["commands"]
        bw = hw["compute_ports"] * dwb
        if r["workload"] == "gemm_int8":
            R, C = hw["tensor_array"]
            peak = 2.0 * R * C
            kind = "gemm"
        else:
            peak = float(hw["vector_lanes"])
            kind = "vector"
        ops = d["ops_per_command"]
        comp_b = d["compulsory_bytes"]
        eff_b = r["metrics"]["bytes_transferred"] / n
        meas = ops / r["metrics"]["latency_avg_cycles"]
        ai_c, ai_e = ops / comp_b, ops / eff_b
        att_c, att_e = min(peak, ai_c * bw), min(peak, ai_e * bw)
        nonov = ops / (eff_b / bw + ops / peak)
        key = f"{kind}|peak={peak:g}|bw={bw}"
        roofs[key] = {"kind": kind, "peak_ops_per_cycle": peak, "peak_bytes_per_cycle": bw, "ridge_ops_per_byte": peak / bw,
                      "config": {"array": hw["tensor_array"], "lanes": hw["vector_lanes"], "ports": hw["compute_ports"], "dw": hw["compute_mem_width_bits"]}}
        pts.append({"id": r["id"], "roof": key, "kind": kind, "ops_per_command": ops, "ai_compulsory": ai_c, "ai_effective": ai_e,
                    "attainable_compulsory": att_c, "attainable_effective": att_e, "non_overlapped_bound": nonov, "measured_ops_per_cycle": meas,
                    "efficiency_vs_compulsory_roof": meas / att_c, "efficiency_vs_effective_roof": meas / att_e, "efficiency_vs_non_overlapped": meas / nonov,
                    "bound_compulsory": "compute" if ai_c * bw >= peak else "memory", "bound_effective": "compute" if ai_e * bw >= peak else "memory",
                    "sweep": r["sweep"]})
    return {"roofs": roofs, "points": pts}


def fabric_ceiling(rec):
    """Peak bytes/cycle the Albion fabric workload could reach (per-port 4 B/cycle: 32-bit word, one request per cycle)."""
    w, p, hw = rec["workload"], rec["params"], rec["hardware"]
    if w in ("sram_seq_read", "sram_seq_write"):
        return 4.0
    if w == "sram_seq_write_partial":
        return 4.0
    if w in ("sram_bank_conflict", "bus_arbitration"):
        return 4.0 * (1 if (w == "bus_arbitration" or p["placement"] == "same") else min(p["masters"], hw["sram_banks"]))
    if w in ("sram_random", "concurrent_mem"):
        return 4.0 * min(p["masters"], hw["sram_banks"])
    if w == "dma_bandwidth":
        L = hw["host_latency_cycles"] if "host" in p["mode"] else 1
        if p["mode"] == "copy_samebank":
            return 2.0
        return 4.0 / L
    if w == "concurrent_dma_interference":
        return 4.0
    return None
