"""MODEL C - accelerator utilisation model (ComputeWorks systolic array and vector engine).

Structure (what the tile does, in the order it does it - phases do NOT overlap in this design, see ComputeWorks 06_PERFORMANCE.md):
    GEMM, array R x C, A is M x K, B is K x N (INT8), D is M x N INT32; tiles of R x C outputs ("blocks"), row-blocks rb = ceil(M/R)
        array busy      = sum over blocks of (K + r + c + 1), r x c the ACTUAL block size   [structural: systolic fill + K slices + drain]
        words read      = A tile once per row-block + B tile once per block, each counted as the memory words its byte ranges touch
                          (exact for tile-aligned shapes, approximate otherwise)               [structural-approx]
        words written   = memory words touched by every output row of every block              [structural]
        load phase      = words read    + aB*blocks + aA*rb                  [fitted constants aA, aB]
        compute phase   = array busy    + aC*blocks                          [fitted]
        store phase     = words written + aS*blocks                          [fitted]
        overhead        = o0 + o1*blocks                                     [fitted]
    Vector (INT32 VADD/VMUL), VL elements in chunks of stg/4 elements (the staging buffer):
        words read = sum_chunks ceil(8*len/dwb), written = sum_chunks ceil(4*len/dwb), compute = sum_chunks ceil(len/lanes)
        each phase has a fixed cost per chunk, overhead = o0 + o1*chunks     [fitted]
Fitted constants come from least squares on the calibration set below (phase counters of the tile's own sf_compute_perf); every other point
is out of sample.  Dual-port (cp=2) configurations are NOT modelled (the second port overlaps A/B loads in a data-dependent way).
"""
import math

from . import fitting

GEMM_CALIB = {(4, 4, 4), (4, 4, 64), (8, 8, 64), (16, 16, 64)}          # on the base tile: 4x4 array, 64-bit memory, 1 port
VEC_CALIB = {16, 256, 1024}                                              # on the base tile: 4 lanes
MIN_LOAD_WORDS = 4
BASE = dict(vector_lanes=4, tensor_array=[4, 4], compute_ports=1, compute_mem_width_bits=64)


def config_key(rec):
    """Identity of a measurement's configuration (labels can differ for identical configurations)."""
    import json
    return json.dumps([rec["workload"], rec["params"], rec["hardware"]], sort_keys=True)


def _is_base(hw):
    return all(hw[k] == v for k, v in BASE.items())


def _words(off, ln, dwb):
    """Memory words touched by the byte range [off, off+ln)."""
    return math.ceil((off + ln) / dwb) - off // dwb


def gemm_features(M, N, K, R, C, dwb):
    """Geometry of one GEMM command.  A is M x K, B is K x N (row-major bytes), D is M x N INT32; tiles of R x C outputs."""
    rbs = [min(R, M - i * R) for i in range(math.ceil(M / R))]
    cbs = [min(C, N - j * C) for j in range(math.ceil(N / C))]
    blocks = len(rbs) * len(cbs)
    # array busy uses the ACTUAL block dimensions (verified exactly on partial tiles by the blind-validation shapes)
    array_busy = sum(K + r + c + 1 for r in rbs for c in cbs)
    # words read: A tile once per row-block (>= one 4-word granule), B tile (one word-range per row) once per block.
    # Exact for tile-aligned shapes; an APPROXIMATION for unaligned tiles (the load engine's burst behaviour is not fully reproduced).
    W_rd = 0
    for i, r in enumerate(rbs):
        W_rd += max(MIN_LOAD_WORDS, _words(i * R * K, r * K, dwb))
        for j, c in enumerate(cbs):
            W_rd += sum(_words(k * N + j * C, c, dwb) for k in range(K))
    # words written: exact byte-range count of every output row of every block
    W_out = sum(_words(((i * R + rr) * N + j * C) * 4, 4 * c, dwb) for i, r in enumerate(rbs) for j, c in enumerate(cbs) for rr in range(r))
    return {"blocks": blocks, "rb": len(rbs), "array_busy": array_busy, "W_rd": W_rd, "W_out": W_out}


def vec_features(VL, lanes, dwb, chunk):
    lens = [min(chunk, VL - i * chunk) for i in range(math.ceil(VL / chunk))]
    return {"chunks": len(lens), "W_rd": sum(math.ceil(8 * l / dwb) for l in lens), "W_wr": sum(math.ceil(4 * l / dwb) for l in lens),
            "compute": sum(math.ceil(l / lanes) for l in lens)}


def _per_cmd(rec):
    d = rec["detail"]
    n = d["commands"]
    ph = d["phase_cycles"]
    return {k: ph[k] / n for k in ("load", "compute", "store", "overhead", "busy")}, d["engine_busy_cycles"]["vector"] / n


def calibrate(records):
    gem, vec = [], []
    for r in records:
        if r["status"] != "OK" or r["detail"] is None or not _is_base(r["hardware"]):
            continue
        if r["workload"] == "gemm_int8" and tuple(r["params"]["shape"]) in GEMM_CALIB and r["sweep"] != "blind-validation":
            gem.append(r)
        if r["workload"] == "vector_int32" and r["params"]["op"] == "add" and r["params"]["vl"] in VEC_CALIB and r["sweep"] != "blind-validation":
            vec.append(r)
    # de-duplicate identical configurations
    def uniq(rs, key):
        seen, out = set(), []
        for r in rs:
            k = key(r)
            if k not in seen:
                seen.add(k)
                out.append(r)
        return out
    gem = uniq(gem, lambda r: tuple(r["params"]["shape"]))
    vec = uniq(vec, lambda r: r["params"]["vl"])
    par = {"calibration_points": {"gemm": [r["id"] for r in gem], "vector": [r["id"] for r in vec]}, "basis": "fitted (least squares on phase counters)",
           "_keys": {config_key(r) for r in gem + vec}}
    try:
        if len(gem) < 2:
            raise ValueError("fewer than two GEMM calibration points in this run (partial run: model C not evaluated for GEMM)")
        F = []
        Y = {"load": [], "compute": [], "store": [], "ov": []}
        for r in gem:
            M_, N_, K_ = r["params"]["shape"]
            R, C = r["hardware"]["tensor_array"]
            f = gemm_features(M_, N_, K_, R, C, r["hardware"]["compute_mem_width_bits"] // 8)
            ph, _ = _per_cmd(r)
            F.append(f)
            Y["load"].append(ph["load"] - f["W_rd"])
            Y["compute"].append(ph["compute"] - f["array_busy"])
            Y["store"].append(ph["store"] - f["W_out"])
            Y["ov"].append(ph["overhead"])
        aB, aA = fitting.lstsq([[f["blocks"], f["rb"]] for f in F], Y["load"])
        (aC,) = fitting.lstsq([[f["blocks"]] for f in F], Y["compute"])
        (aS,) = fitting.lstsq([[f["blocks"]] for f in F], Y["store"])
        o0, o1 = fitting.lstsq([[1.0, f["blocks"]] for f in F], Y["ov"])
        par["gemm"] = {"load_per_B_tile": aB, "load_per_A_tile": aA, "compute_per_block": aC, "store_per_block": aS, "overhead_const": o0,
                       "overhead_per_block": o1}
    except (ValueError, ZeroDivisionError, IndexError) as e:
        par["gemm_error"] = str(e)
    try:
        if len(vec) < 2:
            raise ValueError("fewer than two vector calibration points in this run (partial run: model C not evaluated for vectors)")
        F, Y = [], {"load": [], "compute": [], "store": [], "ov": [], "vec": []}
        for r in vec:
            hw = r["hardware"]
            chunk = r["detail"]["tile_config"]["stg"] // 4
            f = vec_features(r["params"]["vl"], hw["vector_lanes"], hw["compute_mem_width_bits"] // 8, chunk)
            ph, va = _per_cmd(r)
            F.append(f)
            Y["load"].append(ph["load"] - f["W_rd"])
            Y["compute"].append(ph["compute"] - f["compute"])
            Y["store"].append(ph["store"] - f["W_wr"])
            Y["ov"].append(ph["overhead"])
            Y["vec"].append(va - f["compute"])
        (a_l,) = fitting.lstsq([[f["chunks"]] for f in F], Y["load"])
        (a_c,) = fitting.lstsq([[f["chunks"]] for f in F], Y["compute"])
        (a_s,) = fitting.lstsq([[f["chunks"]] for f in F], Y["store"])
        (a_v,) = fitting.lstsq([[f["chunks"]] for f in F], Y["vec"])
        o0, o1 = fitting.lstsq([[1.0, f["chunks"]] for f in F], Y["ov"])
        par["vector"] = {"load_per_chunk": a_l, "compute_per_chunk": a_c, "store_per_chunk": a_s, "engine_busy_extra_per_chunk": a_v,
                         "overhead_const": o0, "overhead_per_chunk": o1}
    except (ValueError, ZeroDivisionError, IndexError) as e:
        par["vector_error"] = str(e)
    return par


def predict(rec, par):
    w, hw, p = rec["workload"], rec["hardware"], rec["params"]
    if w not in ("gemm_int8", "vector_int32") or rec["status"] != "OK" or hw["compute_ports"] != 1:
        return None
    dw = hw["compute_mem_width_bits"]
    dwb = dw // 8
    n = rec["detail"]["commands"]
    if w in ("gemm_int8", "compute_mem_contention") and "gemm" in par:
        if w == "compute_mem_contention":
            return None
        g = par["gemm"]
        M_, N_, K_ = p["shape"]
        R, C = hw["tensor_array"]
        f = gemm_features(M_, N_, K_, R, C, dwb)
        ld = f["W_rd"] + g["load_per_B_tile"] * f["blocks"] + g["load_per_A_tile"] * f["rb"]
        cp = f["array_busy"] + g["compute_per_block"] * f["blocks"]
        st = f["W_out"] + g["store_per_block"] * f["blocks"]
        ov = g["overhead_const"] + g["overhead_per_block"] * f["blocks"]
        T = ld + cp + st + ov
        macs = M_ * N_ * K_
        pr = {"latency_avg_cycles": T, "compute_utilization": macs / (R * C * T), "pipeline_utilization": f["array_busy"] / T,
              "bytes_transferred": (f["W_rd"] + f["W_out"]) * dwb * n}
        in_s = config_key(rec) in par["_keys"]
    elif w == "vector_int32" and "vector" in par:
        v = par["vector"]
        chunk = rec["detail"]["tile_config"]["stg"] // 4
        f = vec_features(p["vl"], hw["vector_lanes"], dwb, chunk)
        ld = f["W_rd"] + v["load_per_chunk"] * f["chunks"]
        cp = f["compute"] + v["compute_per_chunk"] * f["chunks"]
        st = f["W_wr"] + v["store_per_chunk"] * f["chunks"]
        ov = v["overhead_const"] + v["overhead_per_chunk"] * f["chunks"]
        T = ld + cp + st + ov
        active = f["compute"] + v["engine_busy_extra_per_chunk"] * f["chunks"]
        pr = {"latency_avg_cycles": T, "compute_utilization": p["vl"] / (hw["vector_lanes"] * T), "pipeline_utilization": active / T,
              "bytes_transferred": (f["W_rd"] + f["W_wr"]) * dwb * n}
        in_s = config_key(rec) in par["_keys"]
    else:
        return None
    return {"model": "C", "title": "accelerator utilisation model", "predictions": pr,
            "basis": {k: ("fitted" if k != "bytes_transferred" else "structural-approx") for k in pr}, "in_sample": in_s, "notes": []}
