"""AlbionBench performance models.

  A  membw    memory bandwidth / cycle model of the Albion fabric complex (SRAM banks, arbitration, DMA)
  B  roofline roofline model of the ComputeWorks tile (compute peak vs memory-port peak)
  C  accel    accelerator utilisation model (systolic array and vector engine, phase by phase)
  D  txnlat   transaction-latency model (arbitration waits, DMA descriptor latency, host MMIO / mailbox)
  E  scaling  workload-scaling model (Hockney r_inf / n_half fits, lane/master/bank scaling efficiency)

Every prediction is tagged with its BASIS:
  structural   derived from the RTL / protocol documentation with no free constant fitted to benchmark output
  monte-carlo  expectation of an abstract queueing model of the documented arbitration rules (stochastic workloads)
  fitted       one or more constants least-squares fitted to a NAMED calibration set (listed in the output)
and with IN_SAMPLE = True when the point being predicted is a member of the calibration set.  Only out-of-sample points count
as validation of a model.
"""
