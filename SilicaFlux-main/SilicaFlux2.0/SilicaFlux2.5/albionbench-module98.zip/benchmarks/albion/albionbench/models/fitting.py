"""Tiny dependency-free numerical helpers (no numpy required)."""
import math


def solve(A, b):
    """Gaussian elimination with partial pivoting.  A: n x n, b: n.  Raises ValueError if singular."""
    n = len(A)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for c in range(n):
        piv = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-12:
            raise ValueError("singular system (calibration set does not span the model's features)")
        M[c], M[piv] = M[piv], M[c]
        for r in range(c + 1, n):
            f = M[r][c] / M[c][c]
            for k in range(c, n + 1):
                M[r][k] -= f * M[c][k]
    x = [0.0] * n
    for r in range(n - 1, -1, -1):
        x[r] = (M[r][n] - sum(M[r][k] * x[k] for k in range(r + 1, n))) / M[r][r]
    return x


def lstsq(X, y):
    """Least squares y ~ X c via the normal equations.  X: m rows of n features."""
    n = len(X[0])
    A = [[sum(X[k][i] * X[k][j] for k in range(len(X))) for j in range(n)] for i in range(n)]
    b = [sum(X[k][i] * y[k] for k in range(len(X))) for i in range(n)]
    return solve(A, b)


def rel_err_pct(pred, meas):
    if pred is None or meas is None:
        return None
    if meas == 0:
        return 0.0 if pred == 0 else float("inf")
    return 100.0 * (pred - meas) / abs(meas)


def hockney(ns, ts):
    """Fit T(n) = T0 + n / r_inf.  Returns (T0, r_inf, n_half) where n_half = T0 * r_inf."""
    c0, c1 = lstsq([[1.0, float(n)] for n in ns], [float(t) for t in ts])
    r = 1.0 / c1 if c1 > 0 else float("inf")
    return c0, r, c0 * r


def round_half_up(x):
    return int(math.floor(x + 0.5))
