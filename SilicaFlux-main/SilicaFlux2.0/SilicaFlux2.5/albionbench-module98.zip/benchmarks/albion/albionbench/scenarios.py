"""Stimulus construction for the Albion fabric-complex workloads, and workload-specific derived analysis.

Address legality (these are *hardware* rules, enforced by the fabric permission unit, not conventions):
  * master 0 (CORE) and master 3 (HOST, with boot_mode set) may reach every SRAM bank;
  * masters 1 and 2 (DMA ports, FIRMWARE domain when used as raw generators) may reach data banks only: bank 0 is firmware-private.
"""
from . import metrics as M

HOSTMEM_BASE = 0x80000000
MASTER_ORDER = [0, 1, 2, 3]


def legal_bank(master, preferred, nb):
    """Map a preferred bank to one the master may legally access."""
    b = preferred % nb
    if master in (1, 2) and b == 0:
        b = 1 + ((master - 1) % max(1, nb - 1))
    return b


def stream(name, m, op, bank, n, pat="seq", nbanks=1, off=0, span=None, wpct=None, gap=0, bg=0, delay=0):
    s = f"name={name},m={m},op={op},bank={bank},nbanks={nbanks},off={off},n={n},pat={pat},gap={gap},bg={bg},delay={delay}"
    if span is not None:
        s += f",span={span}"
    if wpct is not None:
        s += f",wpct={wpct}"
    return s


def _maxcyc(expected_ops, hm_lat=1, factor=64):
    return int(factor * max(1, expected_ops) * max(1, hm_lat) + 200000)


def build(workload, hw, p):
    """Return {workload, streams, dma, hmlat, maxcyc} for the fabric harness."""
    nb = hw["sram_banks"]
    bw = hw["bank_bytes"] // 4                  # words per bank
    bank_bytes = hw["bank_bytes"]
    hml = hw["host_latency_cycles"]
    sc = {"workload": workload, "streams": [], "dma": None, "hmlat": hml}

    if workload == "sram_seq_read":
        sc["streams"] = [stream("rd", 0, "r", 1, p["nwords"])]
        sc["maxcyc"] = _maxcyc(p["nwords"])
    elif workload == "sram_seq_write":
        sc["streams"] = [stream("wr", 0, "w", 1, p["nwords"])]
        sc["maxcyc"] = _maxcyc(p["nwords"])
    elif workload == "sram_seq_write_partial":
        sc["streams"] = [stream("wp", 0, "p", 1, p["nwords"])]
        sc["maxcyc"] = _maxcyc(p["nwords"] * 2)
    elif workload in ("sram_random", "concurrent_mem"):
        K = p["masters"]
        for m in MASTER_ORDER[:K]:
            lo = 0 if m in (0, 3) else 1
            sc["streams"].append(stream(f"m{m}", m, "x", lo, p["nops"], pat="rand", nbanks=nb - lo, wpct=30))
        sc["maxcyc"] = _maxcyc(p["nops"] * K)
    elif workload == "sram_bank_conflict":
        K = p["masters"]
        n = p["nwords"]
        for i, m in enumerate(MASTER_ORDER[:K]):
            if p["placement"] == "same":
                slice_w = max(1, bw // 4)
                sc["streams"].append(stream(f"m{m}", m, "r", 1, n, off=i * slice_w, span=slice_w))
            else:
                sc["streams"].append(stream(f"m{m}", m, "r", legal_bank(m, i, nb), n))
        sc["maxcyc"] = _maxcyc(n * K)
    elif workload == "bus_arbitration":
        K = p["masters"]
        n = p["nops"]
        slice_w = max(1, bw // 4)
        for i, m in enumerate(MASTER_ORDER[:K]):
            if p["demand"] == "saturating":
                sc["streams"].append(stream(f"m{m}", m, "x", 1, n, pat="rand", off=i * slice_w, span=slice_w, wpct=50))
            else:   # unequal: master 0 saturates, the others issue one request per ~9 cycles
                gap = 0 if i == 0 else 7
                nn = n if i == 0 else max(8, n // 8)
                sc["streams"].append(stream(f"m{m}", m, "r", 1, nn, off=i * slice_w, span=slice_w, gap=gap))
        sc["maxcyc"] = _maxcyc(n * K, factor=128)
    elif workload == "concurrent_dma_interference":
        ln = p["length"]
        sc["dma"] = f"mode=copy,src={1 * bank_bytes},dst={2 * bank_bytes},len={ln},domain=2"
        cbank = 1 if p["placement"] == "same" else 0
        sc["streams"] = [stream("core_bg", 0, "r", cbank, 0, bg=1, span=max(1, min(bw, ln // 4)) if cbank == 1 else bw)]
        sc["maxcyc"] = _maxcyc(ln // 4)
    elif workload in ("dma_bandwidth", "dma_latency"):
        ln = p["length"]
        md = p["mode"]
        B = bank_bytes
        if md == "fill":
            sc["dma"] = f"mode=fill,dst={1 * B},len={ln},domain=2,fill=0xA5A5A5A5"
        elif md == "copy_xbank":
            if nb < 3:
                raise ValueError("copy_xbank needs two DMA-reachable data banks: bank 0 is firmware-private, so at least 3 banks")
            sc["dma"] = f"mode=copy,src={1 * B},dst={2 * B},len={ln},domain=2"
        elif md == "copy_samebank":
            if 2 * ln > B:
                raise ValueError("copy_samebank needs 2*len <= bank_bytes")
            sc["dma"] = f"mode=copy,src={1 * B},dst={1 * B + ln},len={ln},domain=2"
        elif md == "host_to_sram":
            sc["dma"] = f"mode=copy,src={HOSTMEM_BASE},dst={1 * B},len={ln},domain=2"
        elif md == "sram_to_host":
            sc["dma"] = f"mode=copy,src={1 * B},dst={HOSTMEM_BASE},len={ln},domain=2"
        else:
            raise ValueError(f"unknown DMA mode {md}")
        if ln > B and md != "host_to_sram" and md != "sram_to_host":
            raise ValueError("length exceeds one bank")
        sc["maxcyc"] = _maxcyc(ln // 4, hml)
    elif workload == "host_port_latency":
        n = p["nops"]
        sc["streams"] = [stream("host", 3, "r", 1, n, off=0, span=max(1, bw // 4))]
        for i in range(p["background"]):
            m = [0, 1, 2][i]
            sc["streams"].append(stream(f"bg{m}", m, "r", 1, 0, bg=1, off=(i + 1) * max(1, bw // 4), span=max(1, bw // 4)))
        sc["maxcyc"] = _maxcyc(n * (p["background"] + 1))
    else:
        raise KeyError(workload)
    return sc


def derive(workload, raw, hw, p):
    """Workload-specific numbers computed from the raw harness document (all measured, none modelled)."""
    if raw.get("status") not in ("OK", "FAIL_CORRECTNESS"):
        return {}
    masters = {m["id"]: m for m in raw["masters"]}
    d = {}
    if workload == "bus_arbitration":
        fg = [s for s in raw["streams"] if not s["background"]]
        shares = {s["name"]: s["completed"] for s in fg}
        win = raw["window"]["cycles"]
        d["per_master_txns"] = shares
        if p["demand"] == "saturating":
            # fairness over the interval in which all masters were active
            d["jain_fairness"] = M.jain_index(list(shares.values()))
            waits = [masters[s["master"]]["accept_wait"] for s in fg]
            d["max_accept_wait_cycles"] = max((w.get("max", 0) for w in waits), default=0)
            d["starvation_bound_cycles"] = p["masters"] - 1
            d["starvation_free"] = d["max_accept_wait_cycles"] <= p["masters"] - 1
        else:
            low = [s for s in fg if s["name"] != "m0"]
            lw = [masters[s["master"]]["accept_wait"].get("max", 0) for s in low]
            d["low_rate_max_accept_wait_cycles"] = max(lw, default=0)
            d["low_rate_masters_not_starved"] = all(s["completed"] >= s["issued"] for s in low)
        d["window_cycles"] = win
    if workload == "host_port_latency":
        h = masters[3]
        d["host_latency_mean"] = h["latency"].get("mean")
        d["host_latency_p99"] = h["latency"].get("p99")
        d["host_latency_max"] = h["latency"].get("max")
        d["background_masters"] = p["background"]
    if workload in ("dma_bandwidth", "dma_latency"):
        dm = raw.get("dma") or {}
        d["dma_cycles_register"] = dm.get("cycles_reg")
        d["dma_window_cycles"] = dm.get("window_cycles")
        d["first_read_accept_cycle"] = dm.get("first_read_accept")
        d["first_write_accept_cycle"] = dm.get("first_write_accept")
        d["done_event_cycle"] = dm.get("done_event_cycle")
        if dm.get("window_cycles"):
            nwords = dm["len"] // 4
            d["cycles_per_word"] = dm["window_cycles"] / nwords
            d["fixed_overhead_cycles_est"] = None   # filled by the scaling model from several lengths
        d["read_beat_latency"] = masters[1]["latency"] if masters[1]["txns"] else None
        d["write_beat_latency"] = masters[2]["latency"] if masters[2]["txns"] else None
        d["write_channel_utilization"] = (dm.get("write_beats", 0) / dm["window_cycles"]) if dm.get("window_cycles") else None
        d["read_channel_utilization"] = (dm.get("read_beats", 0) / dm["window_cycles"]) if dm.get("window_cycles") else None
    return d
