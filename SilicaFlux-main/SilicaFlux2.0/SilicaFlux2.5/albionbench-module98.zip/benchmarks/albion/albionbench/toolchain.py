"""Tool discovery and cached Verilator builds.

Every simulator binary is built from a *content hash* of (RTL files, harness source, parameters, flags, Verilator version), so
a change to any RTL line produces a new binary and an unchanged design is never rebuilt.  Binaries are self-contained
(intermediate objects are deleted: the disk allowance is fixed).
"""
import hashlib
import os
import pathlib
import re
import shutil
import subprocess
import tempfile
import time

from . import paths

# -Wno-CMPCONST: sf_albion_fifo's overflow assertion `count > DEPTH` is a constant-false compare when DEPTH+1 is a power of two (DEPTH=3):
# benign (it is a $error guard, not logic), but fatal under Verilator's default warning policy.  Documented in docs/METHODOLOGY.md.
VERILATOR_FLAGS = ["--cc", "--exe", "--build", "-O2", "--x-assign", "fast", "--x-initial", "unique", "-Wno-UNUSEDPARAM", "-Wno-CMPCONST"]

_FABRIC_RTL = ["sf_albion_regs_pkg.sv", "sf_albion_secded.sv", "sf_albion_sram_macro.sv", "sf_albion_sram_bank.sv",
               "sf_albion_fifo.sv", "sf_albion_datafabric.sv", "sf_albion_dma.sv", "sf_albion_host_if.sv"]


class ToolError(RuntimeError):
    pass


def _run(cmd, cwd=None, timeout=900):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def version_of(cmd):
    """First non-empty line of `cmd` output, or None when the tool is not installed."""
    if not shutil.which(cmd[0]):
        return None
    try:
        _rc, out = _run(cmd, timeout=30)
    except Exception:
        return None
    return next((l.strip() for l in out.splitlines() if l.strip()), None)


def tool_versions():
    """Versions of every tool that can influence a result.  None = not installed."""
    import platform
    import sys
    v = {
        "verilator": version_of(["verilator", "--version"]),
        "yosys": version_of(["yosys", "-V"]),
        "iverilog": version_of(["iverilog", "-V"]),
        "g++": version_of(["g++", "--version"]),
        "clang": version_of(["clang", "--version"]),
        "ld.lld": version_of(["ld.lld", "--version"]),
        "make": version_of(["make", "--version"]),
        "git": version_of(["git", "--version"]),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "cpu_count": os.cpu_count(),
    }
    try:
        import numpy
        v["numpy"] = numpy.__version__
    except Exception:
        v["numpy"] = None
    return v


def require_verilator():
    if not shutil.which("verilator"):
        raise ToolError("verilator not found (developed with 5.020: apt-get install verilator)")
    return version_of(["verilator", "--version"])


def sha256_files(files, extra=b""):
    h = hashlib.sha256()
    for f in files:
        p = pathlib.Path(f)
        h.update(p.name.encode())
        h.update(p.read_bytes())
    h.update(extra)
    return h.hexdigest()


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _build_dir(kind, key):
    d = paths.BUILD / kind / key
    return d


def _finalize(tmp, final, binary_name):
    """Keep only the binary; publish atomically (parallel builders of the same key are harmless)."""
    keep = tmp / binary_name
    for entry in list(tmp.iterdir()):
        if entry.name != binary_name:
            shutil.rmtree(entry) if entry.is_dir() else entry.unlink()
    final.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.rename(tmp, final)
    except OSError:
        shutil.rmtree(tmp, ignore_errors=True)   # someone else published first
    return final / binary_name if keep.exists() or (final / binary_name).exists() else None


# --------------------------------------------------------------------------------------------------- fabric complex
def fabric_sources(soc_root):
    rtl = pathlib.Path(soc_root) / "rtl" / "albion"
    files = [rtl / f for f in _FABRIC_RTL]
    missing = [str(f) for f in files if not f.exists()]
    if missing:
        raise ToolError(f"RTL files missing under {rtl}: {missing}")
    return rtl, files


def build_fabric(soc_root, nb, bank_bytes, dma_depth, nw=8, quiet=True):
    """Build albionbench_fabric_top + harness for one hardware configuration.  Returns (binary, info)."""
    vver = require_verilator()
    rtl, files = fabric_sources(soc_root)
    wrapper = paths.RTL_BENCH / "albionbench_fabric_top.sv"
    harness = paths.HARNESS / "fabric_harness.cpp"
    vlt = [rtl / "lint" / "verilator.vlt", paths.RTL_BENCH / "lint.vlt"]
    params = f"NB={nb};BANK_BYTES={bank_bytes};NW={nw};DMA_DEPTH={dma_depth}"
    key = sha256_files(files + [wrapper, harness] + vlt, extra=(params + str(VERILATOR_FLAGS) + str(vver)).encode())[:20]
    final = _build_dir("fabric", key)
    binp = final / "fabric_sim"
    info = {"kind": "fabric", "key": key, "params": {"NB": nb, "BANK_BYTES": bank_bytes, "NW": nw, "DMA_DEPTH": dma_depth},
            "rtl_files": [f.name for f in files] + [wrapper.name], "verilator": vver,
            "flags": VERILATOR_FLAGS + [f"-GNB={nb}", f"-GBANK_BYTES={bank_bytes}", f"-GNW={nw}", f"-GDMA_DEPTH={dma_depth}"]}
    if binp.exists():
        info["binary_sha256"] = file_sha256(binp)
        info["cached"] = True
        return binp, info
    paths.BUILD.mkdir(parents=True, exist_ok=True)
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="fab_", dir=paths.BUILD))
    cmd = (["verilator"] + VERILATOR_FLAGS + ["-j", "2"] + [str(x) for x in vlt] + [str(f) for f in files] + [str(wrapper), str(harness)]
           + ["--top-module", "albionbench_fabric_top", f"-GNB={nb}", f"-GBANK_BYTES={bank_bytes}", f"-GNW={nw}", f"-GDMA_DEPTH={dma_depth}",
              "-CFLAGS", f"-DAB_NB={nb} -DAB_BANK_BYTES={bank_bytes} -DAB_NW={nw} -DAB_DMA_DEPTH={dma_depth}",
              "-Mdir", str(tmp), "-o", "fabric_sim"])
    t0 = time.time()
    rc, out = _run(cmd, timeout=1200)
    if rc != 0 or not (tmp / "fabric_sim").exists():
        shutil.rmtree(tmp, ignore_errors=True)
        raise ToolError("verilator build of the fabric complex failed:\n" + "\n".join(out.splitlines()[-30:]))
    res = _finalize(tmp, final, "fabric_sim")
    if res is None:
        raise ToolError("fabric build produced no binary")
    info["binary_sha256"] = file_sha256(res)
    info["cached"] = False
    info["build_seconds"] = round(time.time() - t0, 1)
    return res, info


# --------------------------------------------------------------------------------------------------- SoC (cloud top)
def soc_sources(soc_root):
    root = pathlib.Path(soc_root)
    flist = root / "rtl" / "albion" / "sf_albion.f"
    files = [root / l.strip() for l in flist.read_text().splitlines() if l.strip() and not l.startswith("//")]
    return root, flist, files


def build_firmware(soc_root, out_dir=None):
    """Build the RV32I ControlCore firmware.  Returns dict(bin, sha256, built=True/False, tool)."""
    root = pathlib.Path(soc_root)
    fw = root / "firmware" / "albion"
    srcs = sorted((fw / "src").glob("*")) + sorted((fw / "include").glob("*")) + [fw / "link.ld", fw / "Makefile"]
    key = sha256_files(srcs, extra=str(version_of(["clang", "--version"])).encode())[:20]
    out = pathlib.Path(out_dir) if out_dir else _build_dir("firmware", key)
    binp = out / "albion_fw.bin"
    if binp.exists():
        return {"bin": str(binp), "sha256": file_sha256(binp), "built": False, "cached": True, "key": key,
                "toolchain": version_of(["clang", "--version"])}
    if not (shutil.which("clang") and shutil.which("ld.lld") and shutil.which("llvm-objcopy") and shutil.which("make")):
        raise ToolError("clang + ld.lld + llvm-objcopy + make are required to build the ControlCore firmware")
    out.mkdir(parents=True, exist_ok=True)
    rc, o = _run(["make", "-C", str(fw), f"OUT={out}"], timeout=300)
    if rc != 0 or not binp.exists():
        raise ToolError("firmware build failed:\n" + "\n".join(o.splitlines()[-20:]))
    return {"bin": str(binp), "sha256": file_sha256(binp), "built": True, "cached": False, "key": key,
            "toolchain": version_of(["clang", "--version"]), "size_bytes": binp.stat().st_size}


def build_soc_sim(soc_root, config=0, quiet=True):
    """Build the unmodified sf_albion_cloud_top full-chip simulator (the product's own harness, albion_sim.cpp)."""
    vver = require_verilator()
    root, flist, files = soc_sources(soc_root)
    vlt = root / "rtl" / "albion" / "lint" / "verilator.vlt"
    harness = root / "sim" / "albion" / "albion_sim.cpp"
    key = sha256_files(files + [vlt, harness, flist], extra=(f"CONFIG={config};" + str(vver) + str(VERILATOR_FLAGS)).encode())[:20]
    final = _build_dir("soc", key)
    binp = final / "albion_sim"
    info = {"kind": "soc", "key": key, "config": config, "verilator": vver, "top": "sf_albion_cloud_top"}
    if binp.exists():
        info["binary_sha256"] = file_sha256(binp)
        info["cached"] = True
        return binp, info
    paths.BUILD.mkdir(parents=True, exist_ok=True)
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="soc_", dir=paths.BUILD))
    cmd = (["verilator"] + VERILATOR_FLAGS + ["-j", "2", str(vlt), "-f", str(flist), str(harness), "--top-module", "sf_albion_cloud_top",
                                               f"-GCONFIG={config}", "-GBUILD_ID=32'd98", "-Mdir", str(tmp), "-o", "albion_sim"])
    t0 = time.time()
    rc, out = _run(cmd, cwd=str(root), timeout=1800)
    if rc != 0 or not (tmp / "albion_sim").exists():
        shutil.rmtree(tmp, ignore_errors=True)
        raise ToolError("verilator build of sf_albion_cloud_top failed:\n" + "\n".join(out.splitlines()[-30:]))
    res = _finalize(tmp, final, "albion_sim")
    info["binary_sha256"] = file_sha256(res)
    info["cached"] = False
    info["build_seconds"] = round(time.time() - t0, 1)
    return res, info


def rtl_tree_hash(root):
    """Content hash of every RTL/firmware/harness source under a tree (used as the 'RTL revision' in provenance)."""
    h = hashlib.sha256()
    n = 0
    for p in sorted(pathlib.Path(root).rglob("*")):
        if p.is_file() and p.suffix in (".sv", ".svh", ".v", ".vlt", ".f", ".c", ".S", ".h", ".ld", ".cpp", ".py") and "build" not in p.parts \
                and "__pycache__" not in p.parts:
            h.update(p.relative_to(root).as_posix().encode())
            h.update(p.read_bytes())
            n += 1
    return h.hexdigest(), n
