"""A/B comparison: does an RTL change (or a hardware-parameter change) actually improve MEASURED SIMULATED performance?

Both sides run the identical suite, seeds and harness; only the RTL tree (or hardware knob) differs.  The verdict per point comes from
regress.compare (same thresholds as the regression gate), so "improved" and "regressed" mean exactly what they mean in CI.

  python3 -m albionbench ab --variant host_if_reissue_bubble --reverse      # what did the host-interface fix gain?
  python3 -m albionbench ab --candidate-hw dma_depth=3                      # does a 3-entry DMA FIFO cost bandwidth?
  python3 -m albionbench ab --baseline-rtl OLD/albion_soc --candidate-rtl NEW/albion_soc
"""
import copy
import json
import pathlib

from . import analysis, paths, regress, results, runner, toolchain, variants
from . import config as cfgmod


def _parse_hw(s):
    out = {}
    for kv in (s or "").split(","):
        if kv.strip():
            k, v = kv.split("=", 1)
            out[k.strip()] = json.loads(v)
    return out


def run_side(cfg, soc_root, backends, jobs, label, say):
    ctx = runner.Context(rtl_roots={"albion_soc": soc_root}, workers=jobs, progress=lambda m: say(f"[{label}] {m}"))
    records = runner.execute(cfg, ctx, only_backends=set(backends))
    doc = results.assemble(cfg, ctx, records, cfg["seeds"])
    analysis.attach(doc, cfg)
    return doc


HIGHER_BETTER = {"memory_bandwidth_bytes_per_cycle", "transaction_throughput_per_cycle", "pipeline_utilization", "compute_utilization"}


def _headline_change(b, c, th, stochastic):
    """Direction of the workload's HEADLINE metric: +1 improved, -1 regressed, 0 unchanged (beyond the regression-gate threshold)."""
    from . import workloads
    metric = workloads.REGISTRY[c["workload"]].headline
    old, new = b["metrics"].get(metric), c["metrics"].get(metric)
    if old in (None, 0) or new is None:
        return 0, metric, None
    pct = 100.0 * (new - old) / abs(old)
    thr = th["bandwidth_drop_pct"] * (regress.STOCHASTIC_FACTOR if stochastic else 1.0)
    better = pct if metric in HIGHER_BETTER else -pct
    floor = th["min_abs_cycles"] if metric not in HIGHER_BETTER else 0
    if abs(new - old) <= floor:
        return 0, metric, pct
    return (1 if better > thr else -1 if better < -thr else 0), metric, pct


def verdicts(cmp_doc, base, cand):
    """Per point: IMPROVED / REGRESSED / NO CHANGE.

    IMPROVED requires the workload's HEADLINE metric (bandwidth, throughput, latency, cycles ...) to improve beyond the gate threshold and nothing to regress.
    A point whose headline is unchanged but whose secondary metrics (stalls, mean beat latency) moved is NO CHANGE and the secondary shift is noted: fewer stalls
    for the same completion time is not a faster design.  Any failing finding (a regression in ANY metric) makes the point REGRESSED."""
    from . import workloads
    th = cmp_doc["summary"]["thresholds"]
    by = {}
    for f in cmp_doc["findings"]:
        by.setdefault(f["id"], []).append(f)
    bp = {r["id"]: r for r in base["points"]}
    rows = []
    for c in cand["points"]:
        b = bp.get(c["id"])
        if not b:
            continue
        fs = by.get(c["id"], [])
        stoch = not workloads.REGISTRY[c["workload"]].deterministic
        hd, hmetric, hpct = _headline_change(b, c, th, stoch) if (b["status"] == "OK" and c["status"] == "OK") else (0, None, None)
        secondary = sorted({f["category"] for f in fs if f["category"].startswith("IMPROVED")})
        if any(f["severity"] == "FAIL" for f in fs):
            v = "REGRESSED"
        elif hd > 0:
            v = "IMPROVED"
        else:
            v = "NO CHANGE"
        mb, mc = b["metrics"], c["metrics"]
        eb, ec = (b.get("energy") or {}).get("energy_per_byte_pJ"), (c.get("energy") or {}).get("energy_per_byte_pJ")
        rows.append({"id": c["id"], "verdict": v, "status": f"{b['status']}→{c['status']}", "headline_metric": hmetric, "headline_change_pct": hpct,
                     "secondary_only_improvements": secondary if v == "NO CHANGE" else [],
                     "cycles": (mb.get("clock_cycles"), mc.get("clock_cycles")), "bandwidth": (mb.get("memory_bandwidth_bytes_per_cycle"), mc.get("memory_bandwidth_bytes_per_cycle")),
                     "lat_avg": (mb.get("latency_avg_cycles"), mc.get("latency_avg_cycles")), "lat_p99": (mb.get("latency_p99_cycles"), mc.get("latency_p99_cycles")),
                     "stalls": (mb.get("stall_cycles"), mc.get("stall_cycles")), "energy_pJ_per_byte_estimate": (eb, ec), "findings": [f["category"] for f in fs]})
    return rows


def overall(rows):
    n = {k: sum(1 for r in rows if r["verdict"] == k) for k in ("IMPROVED", "REGRESSED", "NO CHANGE")}
    if n["IMPROVED"] and not n["REGRESSED"]:
        v = "IMPROVES measured simulated performance"
    elif n["REGRESSED"] and not n["IMPROVED"]:
        v = "REGRESSES measured simulated performance"
    elif n["REGRESSED"] and n["IMPROVED"]:
        v = "MIXED: improves some workloads and regresses others"
    else:
        v = "NO MEASURABLE CHANGE in any workload"
    return v, n


def _fmt(x, nd=3):
    return "-" if x is None else (f"{x:.{nd}f}" if isinstance(x, float) else str(x))


def render(meta, rows, ov, cmp_doc):
    v, n = ov
    L = ["# AlbionBench A/B report", "", f"**Verdict: {v}.**", "",
         f"{n['IMPROVED']} point(s) improved, {n['REGRESSED']} regressed, {n['NO CHANGE']} unchanged (same seeds, same harness; thresholds {json.dumps(cmp_doc['summary']['thresholds'])}).", "",
         "| | |", "|---|---|"]
    for k, val in meta.items():
        L.append(f"| **{k}** | {str(val).replace('|', '/')} |")
    L += ["", "Energy columns are library-based ESTIMATES from simulation activity (see benchmark_report.md §7); they are not measured.", "",
          "## Points that changed", "", "| point | verdict | cycles | B/cycle | lat avg | lat p99 | stalls | est. pJ/byte | categories |", "|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        if r["verdict"] == "NO CHANGE":
            continue
        L.append(f"| `{r['id']}` | **{r['verdict']}** | {_fmt(r['cycles'][0], 0)} → {_fmt(r['cycles'][1], 0)} | {_fmt(r['bandwidth'][0])} → {_fmt(r['bandwidth'][1])} | "
                 f"{_fmt(r['lat_avg'][0], 2)} → {_fmt(r['lat_avg'][1], 2)} | {_fmt(r['lat_p99'][0], 1)} → {_fmt(r['lat_p99'][1], 1)} | {_fmt(r['stalls'][0], 0)} → {_fmt(r['stalls'][1], 0)} | "
                 f"{_fmt(r['energy_pJ_per_byte_estimate'][0], 2)} → {_fmt(r['energy_pJ_per_byte_estimate'][1], 2)} | {', '.join(r['findings'])} |")
    sec = [r for r in rows if r["verdict"] == "NO CHANGE" and r["secondary_only_improvements"]]
    if sec:
        L += ["", "## Headline unchanged, secondary metrics moved (NOT counted as improvements)", "", "| point | headline | secondary metrics that improved | stalls | lat avg |", "|---|---|---|---|---|"]
        for r in sec:
            L.append(f"| `{r['id']}` | {r['headline_metric']} unchanged ({_fmt(r['headline_change_pct'], 2)}%) | {', '.join(r['secondary_only_improvements'])} | "
                     f"{_fmt(r['stalls'][0], 0)} → {_fmt(r['stalls'][1], 0)} | {_fmt(r['lat_avg'][0], 2)} → {_fmt(r['lat_avg'][1], 2)} |")
    unchanged = [r["id"] for r in rows if r["verdict"] == "NO CHANGE"]
    L += ["", f"## Unchanged ({len(unchanged)})", "", ", ".join(f"`{u}`" for u in unchanged[:80]) + (" ..." if len(unchanged) > 80 else ""), ""]
    return "\n".join(L) + "\n"


def cli(a):
    cfg = cfgmod.load(a.config)
    backends = a.backends.split(",")
    say = lambda m: print(m, flush=True)
    toolchain.require_verilator()
    base_root = a.baseline_rtl or str(paths.RTL_UNDER_TEST / "albion_soc")
    cand_root, vinfo = (a.candidate_rtl, None)
    cand_label = a.candidate_rtl or "vendored"
    if a.variant:
        cand_root, vinfo = variants.materialize(a.variant)
        cand_label = f"variant:{a.variant}"
    if cand_root is None:
        cand_root = base_root                 # hardware-parameter A/B on the same RTL
    base_cfg, cand_cfg = copy.deepcopy(cfg), copy.deepcopy(cfg)
    base_cfg["hardware"].update(_parse_hw(a.baseline_hw))
    cand_cfg["hardware"].update(_parse_hw(a.candidate_hw))
    if a.reverse and a.variant:
        base_root, cand_root = cand_root, base_root
        base_label, cand_label = cand_label, "vendored"
    else:
        base_label = a.baseline_rtl or "vendored"
    out = pathlib.Path(a.out or paths.RESULTS / "ab")
    out.mkdir(parents=True, exist_ok=True)
    base = run_side(base_cfg, base_root, backends, a.jobs, "baseline", say)
    cand = run_side(cand_cfg, cand_root, backends, a.jobs, "candidate", say)
    cmp_doc = regress.compare(base, cand, cfg["thresholds"])
    rows = verdicts(cmp_doc, base, cand)
    ov = overall(rows)
    meta = {"baseline": f"{base_label} (hw override: {a.baseline_hw or 'none'})",
            "candidate": f"{cand_label} (hw override: {a.candidate_hw or 'none'})", "suite": cfg["name"], "seeds": cfg["seeds"], "backends": a.backends,
            "simulator": base["provenance"]["simulator"]["version"], "source revision": base["provenance"]["source_revision"]["git_head"][:12]}
    if vinfo:
        meta["variant"] = f"{vinfo['variant']} ({vinfo['kind']}): {vinfo['description']}; edited {', '.join(vinfo['files_edited'])}"
    (out / "ab.json").write_text(json.dumps({"meta": meta, "verdict": ov[0], "counts": ov[1], "points": rows, "findings": cmp_doc["findings"]}, indent=1, default=str))
    (out / "ab_report.md").write_text(render(meta, rows, ov, cmp_doc))
    results.write_json(base, out / "baseline_results.json")
    results.write_json(cand, out / "candidate_results.json")
    print(f"\nA/B verdict: {ov[0]}  {ov[1]}\nwrote {out}/ab_report.md")
    return 0
