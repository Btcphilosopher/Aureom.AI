"""Filesystem layout (all paths derived from the package location so the framework is relocatable)."""
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent          # benchmarks/albion
PKG = ROOT / "albionbench"
HARNESS = ROOT / "harness"
RTL_BENCH = ROOT / "rtl_bench"
RTL_UNDER_TEST = ROOT / "rtl_under_test"
CONFIGS = ROOT / "configs"
VARIANTS = ROOT / "variants"
BASELINES = ROOT / "baselines"
RESULTS = ROOT / "results"
BUILD = ROOT / "build"                                         # generated; never shipped
DOCS = ROOT / "docs"
