"""RTL variants: a variant is a named list of exact find/replace edits applied to a copy of the vendored Albion SoC RTL.

variants/<name>/variant.json:
  {"name", "description", "kind": "optimization" | "regression-mutant" | "control", "provenance": "...",
   "expected_categories": [...regress categories the detector must raise (for mutants)...],
   "edits": [{"file": "rtl/albion/<file>.sv", "find": "<text occurring exactly once>", "replace": "<new text>"}]}

Each edit must match exactly once: a variant that no longer applies to the RTL fails loudly instead of silently benchmarking the baseline.
"""
import json
import pathlib
import shutil

from . import paths, provenance


def list_variants():
    out = {}
    for d in sorted(paths.VARIANTS.glob("*/variant.json")):
        v = json.loads(d.read_text())
        out[v["name"]] = v
    return out


def load(name):
    vs = list_variants()
    if name not in vs:
        raise KeyError(f"variant {name!r} not found; available: {sorted(vs)}")
    return vs[name]


def materialize(name, base_root=None):
    """Copy the base Albion SoC tree and apply the variant.  Returns (path, info)."""
    v = load(name)
    base = pathlib.Path(base_root or paths.RTL_UNDER_TEST / "albion_soc")
    dest = paths.BUILD / "variants" / name / "albion_soc"
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(base, dest, ignore=shutil.ignore_patterns("build", "__pycache__"))
    applied = []
    for e in v["edits"]:
        f = dest / e["file"]
        text = f.read_text()
        n = text.count(e["find"])
        if n != 1:
            raise ValueError(f"variant {name}: edit for {e['file']} matches {n} times (must be exactly 1): {e['find'][:70]!r}")
        f.write_text(text.replace(e["find"], e["replace"]))
        applied.append(e["file"])
    th, nfiles = provenance.hash_tree(dest, exclude=("build", "__pycache__"))
    return dest, {"variant": name, "kind": v.get("kind"), "description": v.get("description"), "files_edited": applied, "tree_sha256": th,
                  "base_tree_sha256": provenance.hash_tree(base, exclude=("build", "__pycache__"))[0]}
