"""Energy analysis - EXPLICITLY LABELLED ESTIMATES.  No physical power is measured anywhere in AlbionBench.

Three strictly separated layers, each carrying its own label in every output:

  1. ACTIVITY COUNTS      exact counts of events in the RTL simulation (SRAM accesses, MACs, DMA beats, ...).  These are facts about the simulation,
                          not energy.
  2. LIBRARY ESTIMATE     counts x per-event energies from a NAMED library (data/energy_library.json: literature values at 45 nm, with source,
                          confidence and an exclusion list).  Reported as a low / nominal / high band.  An ESTIMATE; dynamic energy only; not scaled
                          to any SilicaFlux process.
  3. MEASURED POWER       always null, with the reason.  Simulated switching activity is never presented as silicon energy.

The estimate's purpose is comparison: whether an RTL change moves ACTIVITY and therefore estimated energy per byte / per op.  Absolute values must not be
used for power budgeting.
"""
import json
import pathlib

LABEL = ("ESTIMATE - library-based energy from RTL-simulation activity counts. NOT measured power or silicon energy; no silicon, FPGA or gate-level "
         "power data exists. Dynamic energy only (no leakage, clock tree, wires or PHY).")
MEASURED_NULL_REASON = ("no silicon, instrumented FPGA board or gate-level/SPEF power analysis exists for any SilicaFlux design; "
                        "simulation provides event counts, which are activity, not energy")


def load_library(path=None):
    p = pathlib.Path(path) if path else pathlib.Path(__file__).parent / "data" / "energy_library.json"
    return json.loads(p.read_text())


def _counts_fabric(r):
    d = r["detail"]
    masters = d.get("masters") or []
    banks = [s for s in d.get("slaves", []) if s["kind"] == "sram"]
    sram = sum(s["rtl_accepts"] for s in banks)
    rmw = sum(s["completed"] for s in (d.get("streams") or []) if s["op"] == "p" and not s["background"])
    dma = d.get("dma") or {}
    hm = d.get("host_memory") or {}
    return {
        "sram_accesses": sram + rmw,                      # a read-modify-write is two bank accesses
        "fabric_transactions": sum(m["txns"] for m in masters),
        "dma_fifo_beats": (dma.get("write_beats", 0) if dma.get("mode") == "copy" else 0),
        "host_port_beats": hm.get("reads", 0) + hm.get("writes", 0),
        "mmio_transactions": 0,
    }


def _counts_compute(r):
    d = r["detail"]
    n = d["commands"]
    dwb = d["tile_config"]["dw"] // 8
    words = d["memory_words"]["read"] + d["memory_words"]["write"]
    c = {"sram_words_64b_equiv": words * dwb / 8.0, "int8_macs": d["macs"], "int32_adds": 0, "int32_muls": 0}
    if r["workload"] == "vector_int32":
        if r["params"]["op"] == "add":
            c["int32_adds"] = d["vector_elements"]
        else:
            c["int32_muls"] = d["vector_elements"]
    return c


def _counts_soc(r):
    d = r["detail"]
    n = r["metrics"]["completed_ops"]
    instr = d.get("core_instructions_per_command_rtl_telemetry")
    mm = {"host_mailbox_roundtrip": 15, "host_dma_roundtrip": 15, "host_mmio_latency": 1}.get(r["workload"], 1)
    return {"controlcore_instructions": (instr or 0) * n, "mmio_transactions": mm * n,
            "fabric_transactions": (mm * n) + (instr or 0) * n * 0.3}      # firmware SRAM traffic ~0.3 accesses/instruction (assumption)


def estimate(r, lib):
    if r["status"] != "OK" or not r.get("detail"):
        return None
    ev = lib["events_pJ"]
    lo_f, hi_f = lib["uncertainty_band"]["low_factor"], lib["uncertainty_band"]["high_factor"]
    be = r["backend"]
    if be == "fabric":
        c = _counts_fabric(r)
        e = (c["sram_accesses"] * ev["sram_access_39b_16KiB"]["nominal"] + c["fabric_transactions"] * ev["fabric_transaction"]["nominal"]
             + c["dma_fifo_beats"] * ev["dma_fifo_beat"]["nominal"] + c["host_port_beats"] * ev["host_port_beat"]["nominal"])
    elif be == "compute":
        c = _counts_compute(r)
        e = (c["sram_words_64b_equiv"] * ev["sram_access_per_64b_word_64KiB_tile"]["nominal"] + c["int8_macs"] * ev["int8_mac"]["nominal"]
             + c["int32_adds"] * ev["int32_add"]["nominal"] + c["int32_muls"] * ev["int32_mul"]["nominal"])
    elif be == "soc":
        c = _counts_soc(r)
        e = (c["controlcore_instructions"] * ev["controlcore_instruction"]["nominal"] + c["mmio_transactions"] * ev["mmio_transaction"]["nominal"]
             + c["fabric_transactions"] * ev["fabric_transaction"]["nominal"])
    else:
        return None
    m = r["metrics"]
    nb, ops, cyc = m.get("bytes_transferred"), m.get("completed_ops"), m.get("clock_cycles")
    mhz = r["metrics_at_assumed_clock"].get("clock_mhz_assumed") if r.get("metrics_at_assumed_clock") else None
    out = {
        "label": LABEL, "evidence_class": "library-estimate", "library": lib["name"],
        "activity_counts": {k: v for k, v in c.items()}, "activity_label": "exact event counts from RTL simulation (not energy)",
        "dynamic_pJ": {"low": e * lo_f, "nominal": e, "high": e * hi_f},
        "total_nJ": e / 1000.0,
        "energy_per_byte_pJ": (e / nb) if nb else None,
        "energy_per_op_pJ": (e / ops) if ops else None,
        "avg_dynamic_power_mW_at_assumed_clock": (e * 1e-12) / (cyc / (mhz * 1e6)) * 1e3 if (cyc and mhz) else None,
        "power_label": "ESTIMATE at the ASSUMED clock; not a power measurement",
        "measured_power": None, "measured_power_unavailable_reason": MEASURED_NULL_REASON,
        "excluded": lib["excluded"],
    }
    return out
