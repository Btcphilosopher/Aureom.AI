"""Post-run analysis: performance models A-E, predicted-vs-RTL validation, energy estimates, data-backed findings."""
import statistics

from . import energy
from .models import accel, fitting, membw, roofline, scaling, txnlat

TOL_PCT = {"structural": 1.0, "structural-approx": 5.0, "fitted": 3.0, "monte-carlo": 5.0}
ABS_TOL = {"clock_cycles": 1.0, "latency_avg_cycles": 0.01, "latency_p99_cycles": 0.5, "latency_max_cycles": 0.5, "stall_cycles": 2.0,
           "memory_conflicts": 2.0}
CYCLE_LIKE = {"clock_cycles", "latency_avg_cycles", "latency_p99_cycles", "latency_max_cycles", "stall_cycles", "memory_conflicts"}
MODEL_TITLES = {"A": "Memory bandwidth model", "B": "Roofline model", "C": "Accelerator utilisation model", "D": "Transaction-latency model",
                "E": "Workload scaling model"}


def _row(r, pred, metric, value, basis, in_sample):
    meas = r["metrics"].get(metric)
    if meas is None:
        return None
    err = fitting.rel_err_pct(value, meas)
    tol = TOL_PCT.get(basis, 3.0)
    abs_tol = ABS_TOL.get(metric, 0.0)
    within = abs(value - meas) <= max(abs_tol, abs(meas) * tol / 100.0) if meas != 0 else abs(value) <= max(abs_tol, 1e-9)
    return {"id": r["id"], "workload": r["workload"], "sweep": r["sweep"], "model": pred["model"], "model_title": pred["title"], "metric": metric,
            "predicted": value, "measured": meas, "error_pct": err, "abs_error": value - meas, "basis": basis, "in_sample": in_sample,
            "tolerance_pct": tol, "tolerance_abs": abs_tol, "within_tolerance": bool(within)}


def validate_models(records, par, soc_pred):
    rows = []
    for r in records:
        if r["status"] != "OK":
            continue
        preds = [membw.predict(r), txnlat.predict(r), accel.predict(r, par) if par else None, soc_pred.get(r["id"])]
        primary = None
        for pr in preds:
            if not pr:
                continue
            for metric, value in pr["predictions"].items():
                row = _row(r, pr, metric, value, pr["basis"].get(metric, "fitted"), pr["in_sample"])
                if row:
                    rows.append(row)
                    if metric == "clock_cycles" and primary is None:
                        primary = row
            if "clock_cycles" not in pr["predictions"] and pr["model"] in ("C", "D") and primary is None and "latency_avg_cycles" in pr["predictions"]:
                pass
        if primary:
            r["model_prediction"] = {"model": primary["model"], "clock_cycles": primary["predicted"], "clock_cycles_error_pct": primary["error_pct"],
                                     "basis": primary["basis"]}
    return rows


def summarize_validation(rows):
    def stat(sel):
        if not sel:
            return None
        errs = [abs(x["error_pct"]) for x in sel if x["error_pct"] is not None and x["error_pct"] != float("inf")]
        return {"n": len(sel), "within_tolerance": sum(x["within_tolerance"] for x in sel),
                "median_abs_error_pct": statistics.median(errs) if errs else None, "max_abs_error_pct": max(errs) if errs else None}
    out = {"overall_out_of_sample": stat([x for x in rows if not x["in_sample"]]), "overall_in_sample": stat([x for x in rows if x["in_sample"]]), "by_model": {}}
    for m in sorted({x["model"] for x in rows}):
        out["by_model"][m] = {"out_of_sample": stat([x for x in rows if x["model"] == m and not x["in_sample"]]),
                              "in_sample": stat([x for x in rows if x["model"] == m and x["in_sample"]]),
                              "blind_validation_only": stat([x for x in rows if x["model"] == m and x["sweep"] == "blind-validation"])}
    out["by_basis"] = {b: stat([x for x in rows if x["basis"] == b and not x["in_sample"]]) for b in sorted({x["basis"] for x in rows})}
    return out


# ------------------------------------------------------------------------------------------------ findings
def _p(records, wl, label):
    return next((r for r in records if r["workload"] == wl and r["label"] == label and r["status"] == "OK"), None)


def findings(records, doc):
    F = []

    def add(title, text, ids, cls="measured"):
        F.append({"title": title, "text": text, "evidence": ids, "evidence_class": cls})
    seq = _p(records, "sram_seq_read", "base")
    part = _p(records, "sram_seq_write_partial", "base")
    if seq and part:
        a, b = seq["metrics"]["memory_bandwidth_bytes_per_cycle"], part["metrics"]["memory_bandwidth_bytes_per_cycle"]
        add("Partial (byte) writes are the SRAM's slow path",
            f"Sequential full-word access reaches {a:.3f} B/cycle (one word per cycle); byte-strobe writes reach {b:.3f} B/cycle because each is a "
            f"read-modify-write that holds the bank two cycles ({a / b:.0f}x lower byte bandwidth, 2x lower transaction rate). Software should coalesce "
            "sub-word stores into full words.", [seq["id"], part["id"]])
    same = [r for r in records if r["workload"] == "sram_bank_conflict" and r["params"].get("placement") == "same" and r["status"] == "OK"]
    dist = {r["params"]["masters"]: r for r in records if r["workload"] == "sram_bank_conflict" and r["params"].get("placement") == "distinct" and r["status"] == "OK"}
    if same and dist:
        K = max(r["params"]["masters"] for r in same if r["params"]["masters"] in dist)
        rs = next(r for r in same if r["params"]["masters"] == K)
        rd = dist[K]
        add("Bank conflicts serialise masters exactly",
            f"{K} masters in ONE bank complete {rs['metrics']['transaction_throughput_per_cycle']:.3f} txn/cycle (latency {rs['metrics']['latency_avg_cycles']:.2f} cycles); "
            f"in {K} different banks {rd['metrics']['transaction_throughput_per_cycle']:.3f} txn/cycle (latency {rd['metrics']['latency_avg_cycles']:.2f}): "
            f"a {rd['metrics']['transaction_throughput_per_cycle'] / rs['metrics']['transaction_throughput_per_cycle']:.1f}x gap. Placement of concurrently used buffers "
            "in different banks is the main software lever; bank 0 is firmware-private, so tenants have NB-1 usable banks.", [rs["id"], rd["id"]])
    arb = [r for r in records if r["workload"] == "bus_arbitration" and r["params"].get("demand") == "saturating" and r["status"] == "OK"]
    if arb:
        worst_j = min(r["detail"]["derived"].get("jain_fairness") or 0 for r in arb)
        sf = all(r["detail"]["derived"].get("starvation_free") for r in arb)
        add("Round-robin arbitration is fair and bounded",
            f"Across {len(arb)} saturating-master configurations the minimum Jain fairness index is {worst_j:.4f} and the worst accept wait never exceeded K-1 cycles "
            f"({'bound held in every case' if sf else 'BOUND VIOLATED in at least one case'}). Low-rate masters beside a saturating one are not starved "
            "(see 'unequal' points).", [r["id"] for r in arb])
    dd = {r["hardware"]["dma_depth"]: r for r in records if r["workload"] == "dma_bandwidth" and r["params"].get("mode") == "copy_xbank" and r["params"].get("length") == 4096
          and r["sweep"] in ("dma_depth", None) and r["status"] == "OK" and r["hardware"]["host_latency_cycles"] == 1 and r["hardware"]["sram_banks"] == 4}
    if len(dd) >= 4:
        tab = ", ".join(f"depth {d}: {dd[d]['metrics']['memory_bandwidth_bytes_per_cycle']:.3f} B/cycle" for d in sorted(dd))
        full = sorted(d for d in dd if dd[d]["metrics"]["memory_bandwidth_bytes_per_cycle"] > 3.95)
        add("DMA prefetch FIFO depth: 3 entries already reach full rate",
            f"{tab}. A word occupies a FIFO slot for a 3-cycle read -> write round trip, so depth >= 3 sustains one word/cycle (Little's law); the shipped depth 4 is "
            f"{'one entry deeper than the knee' if full and full[0] == 3 else 'at or above the knee'}, and depths above 3 gave no measurable bandwidth change on these workloads. "
            "Depth 1-2 would cost 3.0x / 1.5x. (Area, power and the error-path prefetch behaviour of a shallower FIFO are not measured here.)", [dd[d]["id"] for d in sorted(dd)])
    hs = [r for r in records if r["workload"] == "dma_bandwidth" and r["params"].get("mode") == "host_to_sram" and r["params"].get("length") == 4096
          and r["hardware"]["dma_depth"] == 4 and r["status"] == "OK"]
    if len(hs) >= 3:
        hs.sort(key=lambda r: r["hardware"]["host_latency_cycles"])
        tab = ", ".join(f"L={r['hardware']['host_latency_cycles']}: {r['metrics']['memory_bandwidth_bytes_per_cycle']:.4f} B/cycle" for r in hs)
        add("Host DMA is latency-bound (one outstanding request)",
            f"{tab} - bandwidth equals 4/L. Multiple outstanding tagged reads on the host port (which requires a fabric change, since each master is limited to one "
            "outstanding request) are the only way to hide host latency; FIFO depth cannot help.", [r["id"] for r in hs])
    mb = _p(records, "host_mailbox_roundtrip", "ping")
    if mb:
        ph = mb["detail"]["phase_cycles_median"]
        tot = mb["metrics"]["latency_p50_cycles"]
        fw = ph["firmware_turnaround_doorbell_to_irq_seen"]
        add("Host command latency is dominated by firmware",
            f"A PING takes a median {tot:.0f} cycles end to end; {fw:.0f} cycles ({100 * fw / tot:.0f}%) are the ControlCore firmware between doorbell and interrupt "
            f"({mb['detail']['core_instructions_per_command_rtl_telemetry']:.0f} instructions); the host's MMIO traffic is only {ph['submit_mmio'] + ph['completion_retrieval_mmio']:.0f} cycles. "
            "Small commands are firmware-bound; batching or a descriptor ring would amortise it.", [mb["id"]])
    vl = {r["hardware"]["vector_lanes"]: r for r in records if r["workload"] == "vector_int32" and r["params"] == {"op": "add", "vl": 1024} and r["hardware"]["compute_ports"] == 1
          and r["hardware"]["compute_mem_width_bits"] == 64 and r["status"] == "OK"}
    ls = doc.get("models", {}).get("scaling", {}).get("lane_scaling")
    if len(vl) >= 4 and ls:
        sp = vl[16]["metrics"]["latency_avg_cycles"]
        add("Vector throughput is memory-bound, not lane-bound",
            f"16x the lanes gives only {vl[1]['metrics']['latency_avg_cycles'] / sp:.2f}x speed-up (Amdahl ceiling {ls['amdahl_max_speedup']:.2f}x): load and store phases "
            "(12 bytes per element over one 64-bit port) do not overlap compute and do not scale with lanes. A 128-bit memory word or a second compute port helps more than lanes.",
            [vl[k]["id"] for k in sorted(vl)])
    gm = [r for r in records if r["workload"] == "gemm_int8" and r["status"] == "OK" and r["hardware"]["tensor_array"] == [4, 4] and r["hardware"]["compute_ports"] == 1
          and r["hardware"]["compute_mem_width_bits"] == 64 and r["sweep"] != "blind-validation"]
    if gm:
        best = max(gm, key=lambda r: r["metrics"]["compute_utilization"])
        ph = best["detail"]["phase_cycles"]
        add("GEMM leaves most of the array idle because phases do not overlap",
            f"Best MAC utilisation {best['metrics']['compute_utilization']:.1%} ({best['label']}); while computing, the array is {best['detail']['array_utilization_while_busy']:.1%} busy, "
            f"but load is {ph['load'] / ph['busy']:.0%} and store {ph['store'] / ph['busy']:.0%} of command time. Double-buffering the staging memory is the largest available lever "
            "(not built, not measured here).", [best["id"]])
    rl = doc.get("models", {}).get("roofline", {}).get("points", [])
    if rl:
        mem_bound = sum(1 for p in rl if p["bound_effective"] == "memory")
        add("Roofline classification",
            f"{len(rl)} compute points: {len(rl) - mem_bound} are compute-bound and {mem_bound} memory-bound on the EFFECTIVE (measured-traffic) roof; none reaches its roof "
            f"(median {statistics.median(p['efficiency_vs_effective_roof'] for p in rl):.0%} of the effective roof, {statistics.median(p['efficiency_vs_non_overlapped'] for p in rl):.0%} of the "
            "non-overlapped bound), consistent with the serialised load/compute/store design.", [], "modelled+measured")
    return F


def attach(doc, cfg):
    recs = doc["points"]
    par = accel.calibrate(recs)
    soc_info, soc_pred = txnlat.predict_soc(recs)
    rows = validate_models(recs, par, soc_pred)
    scal = scaling.analyze(recs)
    # lane / hockney validation rows (model E)
    erows = []
    for s in scal["hockney"]:
        for v in s["validation_points"]:
            erows.append({"id": v["id"], "workload": s["series"], "sweep": "blind-validation", "model": "E", "model_title": MODEL_TITLES["E"], "metric": "size scaling: " + s["series"],
                          "predicted": v["predicted"], "measured": v["measured"], "error_pct": v["error_pct"], "abs_error": v["predicted"] - v["measured"], "basis": "fitted",
                          "in_sample": False, "tolerance_pct": TOL_PCT["fitted"], "tolerance_abs": 1.0, "within_tolerance": abs(v["error_pct"]) <= TOL_PCT["fitted"]
                          or abs(v["predicted"] - v["measured"]) <= 1.0})
        if s.get("extrapolation"):
            v = s["extrapolation"]
            erows.append({"id": v["id"], "workload": s["series"], "sweep": "extrapolation", "model": "E", "model_title": MODEL_TITLES["E"], "metric": "extrapolation: " + s["series"],
                          "predicted": v["predicted"], "measured": v["measured"], "error_pct": v["error_pct"], "abs_error": v["predicted"] - v["measured"], "basis": "fitted",
                          "in_sample": False, "tolerance_pct": TOL_PCT["fitted"], "tolerance_abs": 1.0, "within_tolerance": abs(v["error_pct"]) <= TOL_PCT["fitted"]
                          or abs(v["predicted"] - v["measured"]) <= 1.0})
    if scal.get("lane_scaling"):
        for row in scal["lane_scaling"]["rows"]:
            erows.append({"id": f"vector_int32|add/vl=1024/lanes={row['lanes']}", "workload": "vector lane scaling", "sweep": "lanes", "model": "E", "model_title": MODEL_TITLES["E"],
                          "metric": "cycles vs lanes (Amdahl)", "predicted": row["predicted_cycles"], "measured": row["cycles"], "error_pct": row["error_pct"],
                          "abs_error": row["predicted_cycles"] - row["cycles"], "basis": "fitted", "in_sample": row["in_sample"], "tolerance_pct": TOL_PCT["fitted"],
                          "tolerance_abs": 1.0, "within_tolerance": abs(row["error_pct"]) <= TOL_PCT["fitted"]})
    rows += erows
    lib = energy.load_library()
    for r in recs:
        r["energy"] = energy.estimate(r, lib)
        if r.get("energy"):
            # roofline-style ceiling for fabric points (efficiency, not a model validation)
            pass
    for r in recs:
        c = roofline.fabric_ceiling(r) if r["backend"] == "fabric" and r["status"] == "OK" else None
        if c and r["metrics"].get("memory_bandwidth_bytes_per_cycle") is not None:
            r["bandwidth_ceiling_bytes_per_cycle"] = c
            r["bandwidth_efficiency_vs_ceiling"] = r["metrics"]["memory_bandwidth_bytes_per_cycle"] / c
    doc["models"] = {
        "titles": MODEL_TITLES,
        "accelerator_calibration": {k: v for k, v in par.items() if not k.startswith("_")},
        "soc_latency_calibration": soc_info,
        "roofline": roofline.build(recs),
        "scaling": scal,
        "tolerances": {"percent_by_basis": TOL_PCT, "absolute": ABS_TOL,
                       "rule": "within tolerance if |predicted - measured| <= max(absolute tolerance, percent tolerance * measured)"},
        "basis_definitions": {"structural": "derived from RTL/protocol analysis; no constant fitted to benchmark output (except anchors to P90's independently published figures)",
                              "structural-approx": "structural formula known to be approximate (words read by the GEMM load engine for tiles that are not word-aligned); 5% tolerance",
                              "monte-carlo": "expectation of an abstract model of the documented arbitration rules", "fitted": "constants least-squares fitted to the named calibration set"},
    }
    doc["model_validation"] = {"rows": rows, "summary": summarize_validation(rows)}
    doc["energy"] = {"label": energy.LABEL, "library": {k: lib[k] for k in ("name", "version", "evidence_class", "process_note", "primary_source", "uncertainty_band", "excluded")},
                     "events_pJ": lib["events_pJ"], "measured_power": None, "measured_power_unavailable_reason": energy.MEASURED_NULL_REASON}
    doc["findings"] = findings(recs, doc)
    return doc
