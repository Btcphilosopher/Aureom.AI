"""AlbionBench - reproducible performance and energy benchmarking for the SilicaFlux cloud-compute architecture.

Module 98.  Everything measured here comes from cycle-accurate RTL simulation (Verilator) of the real SilicaFlux RTL.
Nothing is silicon, FPGA or gate-level measurement; see docs/METHODOLOGY.md and the "Evidence classes" in every report.
"""
__version__ = "1.0.0"
MODULE = "98"
RESULT_SCHEMA = "albionbench.results/1"
