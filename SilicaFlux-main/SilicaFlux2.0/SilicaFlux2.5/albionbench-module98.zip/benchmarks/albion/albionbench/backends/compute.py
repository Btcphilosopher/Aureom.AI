"""ComputeWorks backend (INT32 vector arithmetic, INT8 GEMM): standalone tile benchmarks using ComputeWorks' own verified benchmark code."""
import concurrent.futures as cf
import json
import pathlib
import subprocess
import sys
import tempfile

from .. import metrics as M
from .. import paths, runner, toolchain

RUNNER = paths.HARNESS / "compute_runner.py"
COMMANDS_PER_POINT = 8


def hw_to_cfg(hw):
    """AlbionBench hardware knobs -> ComputeWorks Cfg kwargs (mirrors ComputeWorks' own bench.py conventions)."""
    rows, cols = hw["tensor_array"]
    dw = hw["compute_mem_width_bits"]
    cfg = dict(num_lanes=hw["vector_lanes"], rows=rows, cols=cols, cp=hw["compute_ports"], dw=dw,
               depth=2048 if dw == 64 else 1024, cmd_depth=16, cpl_depth=8)
    if rows * cols >= 64:
        cfg["stg"] = 2048
    return cfg


def spec_for(pt, seed):
    hw, p = pt["hw"], pt["params"]
    cfg = hw_to_cfg(hw)
    w = pt["workload"]
    if w == "gemm_int8":
        return {"kind": "gemm", "cfg": cfg, "shape": p["shape"], "n": COMMANDS_PER_POINT, "seed": seed}
    if w == "compute_mem_contention":
        return {"kind": "contention", "cfg": cfg, "shape": p["shape"], "bg": p.get("bg", 0), "n": COMMANDS_PER_POINT, "seed": seed}
    if w == "vector_int32":
        return {"kind": "vector", "cfg": cfg, "op": p["op"], "vl": p["vl"], "n": COMMANDS_PER_POINT, "seed": seed}
    raise KeyError(w)


def _call(spec, root, build, scratch):
    r = subprocess.run([sys.executable, "-I", str(RUNNER), "--root", str(root), "--build", str(build), "--scratch", str(scratch),
                        "--spec", json.dumps(spec)], capture_output=True, text=True, timeout=3600)
    for line in reversed(r.stdout.splitlines()):
        if line.startswith("ALBIONBENCH_JSON "):
            return json.loads(line[len("ALBIONBENCH_JSON "):])
    return {"status": "ERROR", "error": f"runner produced no result (rc={r.returncode}): {(r.stdout + r.stderr)[-600:]}"}


def metrics_from_row(row, pt):
    hw = pt["hw"]
    cd = row["cfg_detail"]
    dwb = cd["dw"] // 8
    cycles = row["cycles"]
    n = row["n"]
    ex = sorted(row["exec_cycles"])
    kind = row["kind"]
    ops = 2 * row["macs"] + row["vec_elems"]
    nbytes = (row["mem_rd"] + row["mem_wr"]) * dwb
    engine_active = row["array_busy"] if kind in ("gemm", "contention") else row["vec_active"]
    m = {
        "clock_cycles": cycles, "completed_ops": ops, "bytes_transferred": nbytes,
        "latency_avg_cycles": sum(ex) / len(ex), "latency_p50_cycles": M.percentile(ex, 50), "latency_p95_cycles": M.percentile(ex, 95),
        "latency_p99_cycles": M.percentile(ex, 99), "latency_p999_cycles": M.percentile(ex, 99.9), "latency_max_cycles": ex[-1],
        "memory_bandwidth_bytes_per_cycle": nbytes / cycles, "transaction_throughput_per_cycle": n / cycles,
        "pipeline_utilization": engine_active / row["busy"] if row["busy"] else None,
        "stall_cycles": row["mem_stall"], "memory_conflicts": row["bank_conflicts"],
        "compute_utilization": row["mac_util"] if kind in ("gemm", "contention") else row["vec_util"],
    }
    return m


def detail_from_row(row, pt):
    cd = row["cfg_detail"]
    p = pt["params"]
    kind = row["kind"]
    d = {
        "commands": row["n"], "exec_cycles_per_command": row["exec_cycles"], "queue_wait_cycles": row["qwait"],
        "ops_per_cycle": row["ops_per_cycle"], "array_utilization_while_busy": row.get("array_util"), "vector_utilization": row.get("vec_util"),
        "phase_cycles": {"load": row["ph_load"], "compute": row["ph_compute"], "store": row["ph_store"], "overhead": row["overhead"], "busy": row["busy"]},
        "engine_busy_cycles": {"array": row["array_busy"], "vector": row["vec_active"]},
        "memory_words": {"read": row["mem_rd"], "write": row["mem_wr"]}, "macs": row["macs"], "vector_elements": row["vec_elems"],
        "tensor_peak_macs": row["tensor_peak"], "vector_peak_elements": row["vec_peak"], "port_losses": row["port_losses"], "port_stalls": row["port_stalls"],
        "background_dma": row.get("bg"), "tile_config": cd, "evidence": "RTL simulation; results verified bit-exactly against independent reference models",
    }
    if kind in ("gemm", "contention"):
        M_, N_, K_ = p["shape"]
        d["compulsory_bytes"] = M_ * K_ + K_ * N_ + 4 * M_ * N_
        d["ops_per_command"] = 2 * M_ * N_ * K_
    else:
        vl = p["vl"]
        d["compulsory_bytes"] = 12 * vl
        d["ops_per_command"] = vl
    return d


def run_points(pts, cfg, ctx):
    seeds = cfg["seeds"][:2] if len(cfg["seeds"]) > 2 else cfg["seeds"]     # compute timing is data-independent; two seeds prove it
    build = paths.BUILD / "compute"
    build.mkdir(parents=True, exist_ok=True)
    scratch_root = pathlib.Path(tempfile.mkdtemp(prefix="cw_", dir=paths.BUILD))
    root = ctx.cw_root
    from ..runner import make_record
    ctx.extra["computeworks_build"] = {"verilator": toolchain.version_of(["verilator", "--version"]), "cache": str(build)}

    def one(pt):
        per_seed = []
        rows = []
        for si, s in enumerate(seeds):
            res = _call(spec_for(pt, s), root, build, scratch_root / f"{abs(hash(pt['workload'] + pt['label'])) % 10**8}_{si}")
            if res["status"] != "OK":
                return make_record(pt, res["status"], {k: None for k in M.METRIC_KEYS}, {"error": res.get("error")}, [], cfg)
            rows.append(res["row"])
            per_seed.append({"seed": s, "status": "OK", "metrics": metrics_from_row(res["row"], pt)})
        det = detail_from_row(rows[0], pt)
        notes = []
        status = "OK"
        sig = {(r["cycles"], r["mem_stall"], r["bank_conflicts"]) for r in rows}
        if len(sig) > 1 and pt["workload"] != "compute_mem_contention":
            status = "FAIL_INSTRUMENTATION"
            notes.append(f"NONDETERMINISM: timing depends on operand data/seed: {sorted(sig)}")
        return make_record(pt, status, runner.aggregate(per_seed), det, per_seed, cfg, notes, deterministic=True)

    # one build per distinct configuration happens inside the first call that needs it; serialise per config to avoid duplicate builds
    out = []
    groups = {}
    for pt in pts:
        groups.setdefault(json.dumps(hw_to_cfg(pt["hw"]), sort_keys=True), []).append(pt)
    with cf.ThreadPoolExecutor(max_workers=ctx.workers) as ex:
        futs = [ex.submit(lambda g=g: [one(p) for p in g]) for g in groups.values()]
        for f in futs:
            out.extend(f.result())
    return out
