"""Fabric-complex backend: runs the C++/Verilator harness for one benchmark point and normalises its output."""
import json
import subprocess

from .. import metrics as M

# conservative wall-clock limit per process (the simulated-cycle watchdog inside the harness fires long before this)
PROC_TIMEOUT_S = 900


def run_raw(binary, scenario, seed, hm_latency, maxcyc):
    cmd = [str(binary), f"--workload={scenario['workload']}", f"--seed={seed}", f"--maxcyc={maxcyc}", f"--hmlat={hm_latency}"]
    for s in scenario.get("streams", []):
        cmd += ["--stream", s]
    if scenario.get("dma"):
        cmd += ["--dma", scenario["dma"]]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=PROC_TIMEOUT_S)
    except subprocess.TimeoutExpired:
        return {"status": "DEADLOCK", "error": f"harness wall-clock timeout ({PROC_TIMEOUT_S}s)", "cmd": cmd}
    try:
        doc = json.loads(r.stdout)
    except Exception:
        return {"status": "ERROR", "error": f"harness produced no JSON (rc={r.returncode}): {(r.stdout + r.stderr)[-400:]}", "cmd": cmd}
    doc["cmd"] = cmd
    return doc


def _fg_masters(raw):
    fg = {s["master"] for s in raw.get("streams", []) if not s.get("background")}
    if raw.get("dma"):
        fg |= {1, 2}
    return sorted(fg)


def instrumentation_check(raw):
    """Monitor-vs-RTL consistency: independent port monitor vs the fabric's own event outputs, DMA register cycles vs window."""
    bad = []
    for m in raw.get("masters", []):
        if m["txns"] != m["rtl_txns"]:
            bad.append(f"master {m['name']}: monitor txns {m['txns']} != RTL ev_txn {m['rtl_txns']}")
        if m["stall_cycles"] != m["rtl_stall_cycles"]:
            bad.append(f"master {m['name']}: monitor stalls {m['stall_cycles']} != RTL ev_stall {m['rtl_stall_cycles']}")
        if m.get("protocol_violations"):
            bad.append(f"master {m['name']}: {m['protocol_violations']} response(s) with no outstanding request")
    f = raw.get("fabric", {})
    if f.get("bank_conflict_cycles_mon") != f.get("bank_conflict_cycles_rtl"):
        bad.append(f"bank-conflict cycles: monitor {f.get('bank_conflict_cycles_mon')} != RTL {f.get('bank_conflict_cycles_rtl')}")
    for s in raw.get("slaves", []):
        if s["kind"] == "sram" and s["mon_accepts"] != s["rtl_accepts"]:
            bad.append(f"bank {s['id']}: monitor accepts {s['mon_accepts']} != RTL ev_s_txn {s['rtl_accepts']}")
    d = raw.get("dma")
    if d and d.get("done") and d["window_cycles"] != d["cycles_reg"] + 1:
        bad.append(f"DMA window {d['window_cycles']} != DMA_CYCLES register {d['cycles_reg']} + 1 (done-observation delay)")
    return bad


def correctness(raw, expect_dma_len=None):
    c = raw.get("checks", {})
    issues = []
    for k in ("stream_read_mismatches", "stream_response_errors", "readback_mismatches", "dma_mismatches"):
        if c.get(k):
            issues.append(f"{k}={c[k]}")
    f = raw.get("fabric", {})
    for k in ("perm_violations", "decode_errors", "ecc_ue_cycles"):
        if f.get(k):
            issues.append(f"{k}={f[k]}")
    d = raw.get("dma")
    if d:
        if not d.get("done"):
            issues.append("DMA did not complete")
        elif d["bytes_done"] != d["len"]:
            issues.append(f"DMA bytes_done {d['bytes_done']} != len {d['len']}")
        elif d["status"] & 4:
            issues.append("DMA reported an error status")
    return issues


def normalise(raw, kind):
    """Raw harness JSON -> (status, metrics, detail).  kind: 'stream' | 'dma' | 'mixed'."""
    status = raw.get("status", "ERROR")
    if status in ("DEADLOCK", "ERROR"):
        return status, {k: None for k in M.METRIC_KEYS}, {"error": raw.get("error"), "deadlock_diag": raw.get("deadlock_diag")}
    fg = _fg_masters(raw)
    masters = {m["id"]: m for m in raw["masters"]}
    d = raw.get("dma")
    if d:
        cycles = d["window_cycles"]
        ops = d["write_beats"]
        nbytes = d["bytes_done"]
        # foreground generator streams during a DMA are interference sources and do not add to the DMA payload
        if kind == "mixed":
            pass
    else:
        cycles = raw["window"]["cycles"]
        fgs = [s for s in raw["streams"] if not s["background"]]
        ops = sum(s["completed"] for s in fgs)
        nbytes = sum(s["bytes"] for s in fgs)
    lat = M.merge_latency([masters[i]["latency"] for i in fg])
    stalls = sum(masters[i]["stall_cycles"] for i in fg)
    banks = [s for s in raw["slaves"] if s["kind"] == "sram" and s["rtl_accepts"] > 0]
    util = (sum(s["rtl_accepts"] for s in banks) / (len(banks) * cycles)) if banks and cycles else None
    m = {
        "clock_cycles": cycles, "completed_ops": ops, "bytes_transferred": nbytes,
        "memory_bandwidth_bytes_per_cycle": nbytes / cycles if cycles else None,
        "transaction_throughput_per_cycle": ops / cycles if cycles else None,
        "pipeline_utilization": util, "stall_cycles": stalls,
        "memory_conflicts": raw["fabric"]["bank_conflict_cycles_rtl"], "compute_utilization": None,
    }
    m.update(M.lat_to_metrics(lat))
    detail = {
        "latency_tail_exact": lat.get("tail_exact"), "masters": [mm for mm in raw["masters"] if mm["txns"]], "streams": raw.get("streams"),
        "slaves": raw["slaves"], "fabric": raw["fabric"], "dma": raw.get("dma"), "host_memory": raw.get("host_memory"),
        "latency_hist": {str(k): v for k, v in sorted(lat.get("hist", {}).items())} if lat.get("hist") else None,
        "accept_wait": M.merge_latency([masters[i]["accept_wait"] for i in fg]),
        "build": raw.get("build"), "checks": raw.get("checks"),
    }
    issues = correctness(raw)
    instr = instrumentation_check(raw)
    detail["correctness_issues"] = issues
    detail["instrumentation_mismatches"] = instr
    if issues:
        status = "FAIL_CORRECTNESS"
    return status, m, detail
